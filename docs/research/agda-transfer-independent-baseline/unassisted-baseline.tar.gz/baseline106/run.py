from pathlib import Path
import sys, subprocess, json, datetime, shutil
root=Path(__file__).resolve().parent
number, category, purpose, *cmd=sys.argv[1:]
out=root/'cycles'/number
out.mkdir(exist_ok=False)
for p in (root/'work').glob('*'):
 if p.is_file(): shutil.copyfile(p,out/(p.name+'.txt'))
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(out/'output.txt').write_text(p.stdout)
(out/'record.json').write_text(json.dumps(dict(cycle=int(number),category=category,purpose=purpose,command=cmd,start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode),indent=2)+'\n')
print(p.stdout); print(f'Cycle {number}; exit {p.returncode}')
