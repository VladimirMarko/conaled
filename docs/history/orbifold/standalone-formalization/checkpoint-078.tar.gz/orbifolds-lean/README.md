# Orbifolds in Lean: checked external fragments

Target paper: David Jaz Myers, *Orbifolds as microlinear types in synthetic
differential cohesive homotopy type theory*, arXiv:2205.15887v1.
Primary source: https://arxiv.org/abs/2205.15887

This archive contains a verified, incomplete formalization effort. It includes
68 mathematical/supporting Lean modules, an aggregate import, 85 registered
declarations, a complete 199-item paper inventory, and precisely scoped
external coverage. These numbers are not counts of formalized paper theorems.

**The full internal cohesive HoTT theory and the main theorem 6.3.7 remain
unimplemented. Proposition 6.1.7 is false as printed; both its counterexample
and an explicitly corrected external theorem are checked here.**

## Build and audit

Install elan from https://github.com/leanprover/elan, then in this directory run:

```sh
elan toolchain install leanprover/lean4:v4.33.0-rc1
lake build
lake env lean Audit.lean
lake env lean FullAudit.lean
```

The exact minimum requested toolchain is pinned in `lean-toolchain`.
The development uses only Lean's bundled standard library; there are no
third-party package dependencies. The installed release has commit
`62eed1db4d67327ec8120be05f1a1b0847d74561`.

On Linux x86-64, an alternative to elan is:

```sh
python3 scripts/bootstrap.py
```

That script requires Python 3.11 or later, `tar`, and Zstandard support. It
downloads the pinned official release, verifies the recorded SHA-256, extracts
it into `.toolchain`, and builds the source. Other platforms should use elan.
The release checksum and installation evidence are in `docs/TOOLCHAIN.json`.

`Audit.lean` checks the registered result roots. `FullAudit.lean` enumerates
all project-owned declarations in Lean's checked environment, including
generated declarations, and reports their transitive axiom dependencies.
The captured exhaustive audit covers 337 declarations and finds only the
standard `propext`, `Quot.sound`, and `Classical.choice` dependencies where
listed, with no project axioms, `sorryAx`, unsafe declarations, or partial
declarations. Generated declaration counts do not measure paper coverage.

## What is proved

- The external constructive association characterization with the source's
  uniqueness direction explicitly corrected; its transfer property; the
  subfinite-enumerability embedding criterion; and all six external closure
  clauses of Proposition 6.1.9.
- The ordinary action groupoid, automorphism and stabilizer groups, an example
  with two distinct automorphism arrows, and the ordinary equivariant torsor
  evaluation equivalence underlying Lemma 2.1.13.
- The ordinary inertia groupoid and preservation of properly finite arrows.
- Specified constructive logical DP-compactness and properness results,
  Penon predicates, and compactness-to-closedness with explicit separatedness.
- Ordinary categorical orthogonality support for binary products, pullbacks,
  and retracts, together with foundational guards against invalid native
  translations.

The exact declarations and boundaries are listed in `docs/COVERAGE.md` and
`docs/COVERAGE.json`. In particular, the native DP-compactness formula becomes
true of every native type under classical reasoning; the constructive
derivations here are not a geometric semantic model.

## Honest scope

This is an ongoing formalization, not a completed formalization of the paper.
Native Lean equality is proof-irrelevant. The paper's higher identity types and
synthetic differential functions cannot simply be interpreted by native Lean
equality and arbitrary Lean functions. The full theory needs an explicit
semantic model or a deep embedding of its object theory with checked
derivations. No paper theorem is introduced as an axiom.

## Checkpoints and source integrity

Every accepted result and supporting milestone is packaged as a cumulative
source archive, durably saved, and exposed immediately after confirmation.
Local commits alone are not treated as backups. `docs/CHECKPOINT_HISTORY.json`
and `.md`, when present, record the previous confirmed archives and their
SHA-256 digests. The containing archive's own upload confirmation is supplied
with its download link; it cannot contain its own archive hash recursively.

`SOURCE_MANIFEST.json` hashes the files in its particular checkpoint before
archiving. `CHECKPOINT.json` records the toolchain and successful verification
statuses. Build outputs and toolchain binaries are excluded from the source
archive; they are reproducible from the pinned release and included sources.

## Reading guide

| File or directory | Purpose |
| --- | --- |
| `Orbifolds/Finiteness/` | Constructive finite-ordinal and finite-quotient arguments, corrections, and counterexample. |
| `Orbifolds/External/` | Ordinary groups, actions, torsors, groupoids, and inertia. |
| `Orbifolds/External/Compactness/` | Precisely scoped external logical compactness and properness. |
| `Orbifolds/Category/` | Ordinary universal-property and orthogonality support. |
| `Orbifolds/Foundations/` | Native equality and native SDG interpretation guards. |
| `docs/paper_inventory.md` and `.json` | All 199 numbered source items, dependencies, and open scope. |
| `docs/COVERAGE.md` and `.json` | Exact external source-to-Lean correspondence. |
| `docs/RESULTS.json` | Per-checkpoint declaration ledger. |
| `docs/*REVIEW*.md` | Foundation and source-fidelity reviews. |
| `docs/FULL_AUDIT_REPORT.md` | Exhaustive proof-dependency audit method and results. |
| `verification/` | Actual build and audit output and verification evidence. |

See `docs/STATUS.md` for exact progress, assumptions, and known source issues.
