import Orbifolds.Category.Probe

/-!
# Retracts preserve ordinary categorical orthogonality

A retraction is given by two actual morphisms whose composite on the
smaller object is its identity. An extension into the larger object can
be projected to the retract. The section and retraction laws also
transfer uniqueness of that extension.

This is ordinary categorical support for unique-extension arguments. It
does not assert any unproved internal or higher microlinearity theorem.
-/

set_option autoImplicit false

universe u v

namespace Orbifolds.Category

/-- Data exhibiting `small` as a retract of `large`. -/
structure Retract (C : Cat.{u, v}) (small large : C.Obj) where
  inclusion : C.Hom small large
  retraction : C.Hom large small
  section_retraction : C.comp inclusion retraction = C.id small

/-- Objects orthogonal to a probe are closed under retracts. -/
theorem orthogonal_retract
    {C : Cat.{u, v}} (p : Probe C) {small large : C.Obj}
    (r : Retract C small large) (hLarge : Orthogonal p large) :
    Orthogonal p small := by
  intro f
  obtain ⟨g, hg, ug⟩ := hLarge (C.comp f r.inclusion)
  refine ⟨C.comp g r.retraction, ?_, ?_⟩
  · calc
      C.comp p.map (C.comp g r.retraction) =
          C.comp (C.comp p.map g) r.retraction :=
        (C.assoc p.map g r.retraction).symm
      _ = C.comp (C.comp f r.inclusion) r.retraction :=
        congrArg (fun k => C.comp k r.retraction) hg
      _ = C.comp f (C.comp r.inclusion r.retraction) :=
        C.assoc f r.inclusion r.retraction
      _ = C.comp f (C.id small) := congrArg (C.comp f) r.section_retraction
      _ = f := C.comp_id f
  · intro candidate restriction
    have extended : C.comp candidate r.inclusion = g :=
      ug (C.comp candidate r.inclusion) (by rw [← C.assoc, restriction])
    calc
      candidate = C.comp candidate (C.id small) := (C.comp_id candidate).symm
      _ = C.comp candidate (C.comp r.inclusion r.retraction) :=
        congrArg (C.comp candidate) r.section_retraction.symm
      _ = C.comp (C.comp candidate r.inclusion) r.retraction :=
        (C.assoc candidate r.inclusion r.retraction).symm
      _ = C.comp g r.retraction :=
        congrArg (fun k => C.comp k r.retraction) extended

end Orbifolds.Category
