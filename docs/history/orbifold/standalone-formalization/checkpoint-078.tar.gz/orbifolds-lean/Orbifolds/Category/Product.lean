import Orbifolds.Category.Probe

/-!
# Products preserve ordinary categorical orthogonality

The product structure below contains the actual universal property:
every pair of maps has a lift, the projections of that lift are the
given maps, and the projections jointly determine a map. Orthogonality
of the product is derived from these data, not included as a field.

This is ordinary categorical support for the closure argument underlying
Myers, arXiv:2205.15887, Lemma 4.3.10 and Proposition 5.0.1. The internal
and higher semantic identifications discussed in `Probe.lean` remain
separate work.
-/

set_option autoImplicit false

universe u v

namespace Orbifolds.Category

/-- A chosen binary product together with its universal property. -/
structure BinaryProduct (C : Cat.{u, v}) (X Y : C.Obj) where
  obj : C.Obj
  fst : C.Hom obj X
  snd : C.Hom obj Y
  lift : {Z : C.Obj} → C.Hom Z X → C.Hom Z Y → C.Hom Z obj
  lift_fst : ∀ {Z : C.Obj} (f : C.Hom Z X) (g : C.Hom Z Y),
    C.comp (lift f g) fst = f
  lift_snd : ∀ {Z : C.Obj} (f : C.Hom Z X) (g : C.Hom Z Y),
    C.comp (lift f g) snd = g
  hom_ext : ∀ {Z : C.Obj} (f g : C.Hom Z obj),
    C.comp f fst = C.comp g fst →
    C.comp f snd = C.comp g snd → f = g

/-- Objects orthogonal to a probe are closed under binary products. -/
theorem orthogonal_binaryProduct
    {C : Cat.{u, v}} (p : Probe C) {X Y : C.Obj}
    (P : BinaryProduct C X Y)
    (hX : Orthogonal p X) (hY : Orthogonal p Y) :
    Orthogonal p P.obj := by
  intro f
  obtain ⟨gx, hx, ux⟩ := hX (C.comp f P.fst)
  obtain ⟨gy, hy, uy⟩ := hY (C.comp f P.snd)
  refine ⟨P.lift gx gy, ?_, ?_⟩
  · apply P.hom_ext
    · rw [C.assoc, P.lift_fst]
      exact hx
    · rw [C.assoc, P.lift_snd]
      exact hy
  · intro candidate restriction
    apply P.hom_ext
    · calc
        C.comp candidate P.fst = gx :=
          ux (C.comp candidate P.fst) (by rw [← C.assoc, restriction])
        _ = C.comp (P.lift gx gy) P.fst := (P.lift_fst gx gy).symm
    · calc
        C.comp candidate P.snd = gy :=
          uy (C.comp candidate P.snd) (by rw [← C.assoc, restriction])
        _ = C.comp (P.lift gx gy) P.snd := (P.lift_snd gx gy).symm

end Orbifolds.Category
