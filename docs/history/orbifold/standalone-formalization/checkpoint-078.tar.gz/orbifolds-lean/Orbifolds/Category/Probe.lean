import Std

/-!
# Ordinary categorical probes

This module records ordinary categories and unique extension along a
test arrow. Morphisms are Type-valued data; equality is used only for
the laws between those morphisms. No object-level paths are represented
by native equality between objects.

This is supporting infrastructure for a possible semantic treatment of
the lifting conditions in Myers, arXiv:2205.15887, section 4.3. It is not
a definition or a model of the paper's microlinearity. Ordinary hom-set
orthogonality tests global maps. An internal smooth interpretation needs
all generalized contexts, or internal function objects; the higher
theory additionally needs mapping spaces and homotopy universal
properties.
-/

set_option autoImplicit false

universe u v w

namespace Orbifolds.Category

/-- An ordinary category, with composition written in diagram order. -/
structure Cat where
  Obj : Type u
  Hom : Obj → Obj → Type v
  id : (X : Obj) → Hom X X
  comp : {X Y Z : Obj} → Hom X Y → Hom Y Z → Hom X Z
  id_comp : ∀ {X Y : Obj} (f : Hom X Y), comp (id X) f = f
  comp_id : ∀ {X Y : Obj} (f : Hom X Y), comp f (id Y) = f
  assoc : ∀ {W X Y Z : Obj} (f : Hom W X) (g : Hom X Y) (h : Hom Y Z),
    comp (comp f g) h = comp f (comp g h)

/-- A test arrow, including its domain and codomain. -/
structure Probe (C : Cat.{u, v}) where
  source : C.Obj
  target : C.Obj
  map : C.Hom source target

/-- A map from a probe's domain has exactly one extension to its codomain. -/
def HasUniqueExtension {C : Cat.{u, v}} (p : Probe C) {X : C.Obj}
    (f : C.Hom p.source X) : Prop :=
  ∃ g : C.Hom p.target X,
    C.comp p.map g = f ∧
    ∀ h : C.Hom p.target X, C.comp p.map h = f → h = g

/-- Ordinary hom-set orthogonality of an object to a test arrow. -/
def Orthogonal {C : Cat.{u, v}} (p : Probe C) (X : C.Obj) : Prop :=
  ∀ f : C.Hom p.source X, HasUniqueExtension p f

/-- An object is local for a family when it is orthogonal to every probe. -/
def LocalFor {C : Cat.{u, v}} {I : Type w} (tests : I → Probe C)
    (X : C.Obj) : Prop :=
  ∀ i : I, Orthogonal (tests i) X

end Orbifolds.Category
