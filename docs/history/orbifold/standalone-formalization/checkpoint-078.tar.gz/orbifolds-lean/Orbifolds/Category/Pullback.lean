import Orbifolds.Category.Probe

/-!
# Pullbacks preserve ordinary categorical orthogonality

The pullback structure records its commuting square and genuine
universal property. The closure proof first extends both projected
maps. Uniqueness of extension into the common codomain makes those
extensions compatible, so the universal property supplies the required
map to the pullback. Its uniqueness is then detected by the projections.

This is ordinary categorical support for Myers, arXiv:2205.15887,
Lemma 4.3.10 and Proposition 5.0.1. It does not identify ordinary
pullbacks with the paper's internal or homotopy pullbacks.
-/

set_option autoImplicit false

universe u v

namespace Orbifolds.Category

/-- A chosen pullback with its commuting square and universal property. -/
structure Pullback (C : Cat.{u, v}) {X Y Z : C.Obj}
    (s : C.Hom X Z) (t : C.Hom Y Z) where
  obj : C.Obj
  fst : C.Hom obj X
  snd : C.Hom obj Y
  comm : C.comp fst s = C.comp snd t
  lift : {W : C.Obj} →
    (a : C.Hom W X) → (b : C.Hom W Y) →
    C.comp a s = C.comp b t → C.Hom W obj
  lift_fst : ∀ {W : C.Obj} (a : C.Hom W X) (b : C.Hom W Y)
    (h : C.comp a s = C.comp b t), C.comp (lift a b h) fst = a
  lift_snd : ∀ {W : C.Obj} (a : C.Hom W X) (b : C.Hom W Y)
    (h : C.comp a s = C.comp b t), C.comp (lift a b h) snd = b
  hom_ext : ∀ {W : C.Obj} (a b : C.Hom W obj),
    C.comp a fst = C.comp b fst →
    C.comp a snd = C.comp b snd → a = b

/-- Objects orthogonal to a probe are closed under pullbacks. -/
theorem orthogonal_pullback
    {C : Cat.{u, v}} (p : Probe C) {X Y Z : C.Obj}
    {s : C.Hom X Z} {t : C.Hom Y Z}
    (P : Pullback C s t)
    (hX : Orthogonal p X) (hY : Orthogonal p Y)
    (hZ : Orthogonal p Z) :
    Orthogonal p P.obj := by
  intro a
  obtain ⟨gx, hx, ux⟩ := hX (C.comp a P.fst)
  obtain ⟨gy, hy, uy⟩ := hY (C.comp a P.snd)
  obtain ⟨gz, _, uz⟩ := hZ (C.comp (C.comp a P.fst) s)
  have leftRestriction :
      C.comp p.map (C.comp gx s) = C.comp (C.comp a P.fst) s := by
    rw [← C.assoc, hx]
  have rightRestriction :
      C.comp p.map (C.comp gy t) = C.comp (C.comp a P.fst) s := by
    calc
      C.comp p.map (C.comp gy t) = C.comp (C.comp p.map gy) t :=
        (C.assoc p.map gy t).symm
      _ = C.comp (C.comp a P.snd) t :=
        congrArg (fun k => C.comp k t) hy
      _ = C.comp a (C.comp P.snd t) := C.assoc a P.snd t
      _ = C.comp a (C.comp P.fst s) := congrArg (C.comp a) P.comm.symm
      _ = C.comp (C.comp a P.fst) s := (C.assoc a P.fst s).symm
  have compatibility : C.comp gx s = C.comp gy t :=
    (uz (C.comp gx s) leftRestriction).trans
      (uz (C.comp gy t) rightRestriction).symm
  refine ⟨P.lift gx gy compatibility, ?_, ?_⟩
  · apply P.hom_ext
    · rw [C.assoc, P.lift_fst]
      exact hx
    · rw [C.assoc, P.lift_snd]
      exact hy
  · intro candidate restriction
    apply P.hom_ext
    · calc
        C.comp candidate P.fst = gx :=
          ux (C.comp candidate P.fst) (by rw [← C.assoc, restriction])
        _ = C.comp (P.lift gx gy compatibility) P.fst :=
          (P.lift_fst gx gy compatibility).symm
    · calc
        C.comp candidate P.snd = gy :=
          uy (C.comp candidate P.snd) (by rw [← C.assoc, restriction])
        _ = C.comp (P.lift gx gy compatibility) P.snd :=
          (P.lift_snd gx gy compatibility).symm

end Orbifolds.Category
