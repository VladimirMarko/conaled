import Orbifolds.Finiteness.Sum
import Orbifolds.Finiteness.SurjectionClosure

/-!
# Finite unions in an ordinary type with decidable equality

The binary case of the external constructive content of Proposition 6.1.9(6).
The union is the surjective image of the disjoint union. Neither a decision
of membership in the two subsets nor a chosen summand is required.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- Two properly finite subsets of a decidable-equality type have a properly
finite union. -/
theorem properlyFinite_union {Y : Type u} (U V : Y → Prop)
    (hU : ProperlyFinite {y : Y // U y})
    (hV : ProperlyFinite {y : Y // V y})
    (hY : HasDecidableEquality Y) :
    ProperlyFinite {y : Y // U y ∨ V y} := by
  let q : {y : Y // U y} ⊕ {y : Y // V y} → {y : Y // U y ∨ V y} :=
    fun z => match z with
      | Sum.inl y => ⟨y.val, Or.inl y.property⟩
      | Sum.inr y => ⟨y.val, Or.inr y.property⟩
  have hq : Function.Surjective q := by
    intro y
    cases y.property with
    | inl h => exact ⟨Sum.inl ⟨y.val, h⟩, rfl⟩
    | inr h => exact ⟨Sum.inr ⟨y.val, h⟩, rfl⟩
  refine ⟨subfinitelyEnumerable_of_surjective q hq (properlyFinite_sum hU hV).1, ?_⟩
  intro a b
  cases hY a.val b.val with
  | inl h => exact Or.inl (Subtype.ext h)
  | inr h => exact Or.inr (fun hab => h (congrArg Subtype.val hab))

end Orbifolds.Finiteness
