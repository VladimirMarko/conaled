import Orbifolds.Finiteness.Definitions

/-!
# Corrected association characterization (Proposition 6.1.7)

The uniqueness direction is corrected explicitly: a finite index represents
at most one point. Both directions below are constructive. This is the
ordinary set-level theorem, not a claim to implement cohesive internal logic.
Source: https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- A quotient of a subfinite type is exactly a type with a corrected association. -/
theorem subfinitelyEnumerable_iff_association (X : Type u) :
    SubfinitelyEnumerable X ↔
      ∃ n : Nat, ∃ r : X → Fin n → Prop, Association r := by
  constructor
  · rintro ⟨S, ⟨n, e, he⟩, q, hq⟩
    refine ⟨n, (fun x i => ∃ s : S, q s = x ∧ e s = i), ?_⟩
    constructor
    · intro x
      obtain ⟨s, hs⟩ := hq x
      exact ⟨e s, s, hs, rfl⟩
    · intro x y i hx hy
      obtain ⟨s, hs, hsi⟩ := hx
      obtain ⟨t, ht, hti⟩ := hy
      have hst : s = t := he (hsi.trans hti.symm)
      exact hs.symm.trans ((congrArg q hst).trans ht)
  · rintro ⟨n, r, hr⟩
    let S := {z : X × Fin n // r z.1 z.2}
    refine ⟨S, ?_, (fun z => z.val.1), ?_⟩
    · refine ⟨n, (fun z => z.val.2), ?_⟩
      intro a b hab
      change a.val.2 = b.val.2 at hab
      apply Subtype.ext
      apply Prod.ext
      · have hb : r b.val.1 a.val.2 := by
          rw [hab]
          exact b.property
        exact hr.uniqueLeft a.val.1 b.val.1 a.val.2 a.property hb
      · exact hab
    · intro x
      obtain ⟨i, hi⟩ := hr.total x
      exact ⟨⟨(x, i), hi⟩, rfl⟩

end Orbifolds.Finiteness
