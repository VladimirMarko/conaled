import Orbifolds.Finiteness.InjectionClosure

/-!
# Subfinite enumerability as an embedding into an enumerable type

External constructive content of Lemma 6.1.8:
https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm8.

For a subfinite type `S`, an injection `e : S → Fin n`, and a surjection
`q : S → X`, form the quotient of `X ⊕ Fin n` identifying `q s` with `e s`.
The finite ordinal surjects onto this quotient. A predicate-valued invariant
of the generating relation shows that distinct points of `X` remain distinct.
No preimage-selection function is chosen.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- A type is subfinitely enumerable exactly when it embeds into a finitely
enumerable ordinary type of the same universe. -/
theorem subfinitelyEnumerable_iff_embeds_finitelyEnumerable (X : Type u) :
    SubfinitelyEnumerable X ↔
      ∃ Y : Type u, FinitelyEnumerable Y ∧
        ∃ f : X → Y, Function.Injective f := by
  constructor
  · rintro ⟨S, ⟨n, e, he⟩, q, hq⟩
    let edge : X ⊕ Fin n → X ⊕ Fin n → Prop :=
      fun a b => ∃ s : S, a = Sum.inl (q s) ∧ b = Sum.inr (e s)
    refine ⟨Quot edge, ⟨n, (fun i => Quot.mk edge (Sum.inr i)), ?_⟩,
      (fun x => Quot.mk edge (Sum.inl x)), ?_⟩
    · intro z
      refine Quot.inductionOn z ?_
      intro a
      cases a with
      | inl x =>
        obtain ⟨s, hs⟩ := hq x
        refine ⟨e s, ?_⟩
        calc
          Quot.mk edge (Sum.inr (e s)) = Quot.mk edge (Sum.inl (q s)) :=
            (Quot.sound (show edge (Sum.inl (q s)) (Sum.inr (e s)) from
              ⟨s, rfl, rfl⟩)).symm
          _ = Quot.mk edge (Sum.inl x) :=
            congrArg (fun y => Quot.mk edge (Sum.inl y)) hs
      | inr i => exact ⟨i, rfl⟩
    · let predicate : X ⊕ Fin n → X → Prop
        | Sum.inl a => fun x => a = x
        | Sum.inr i => fun x => ∃ s : S, e s = i ∧ q s = x
      have respects : ∀ a b, edge a b → predicate a = predicate b := by
        intro a b hab
        obtain ⟨s, ha, hb⟩ := hab
        subst a
        subst b
        funext x
        apply propext
        constructor
        · intro hx
          exact ⟨s, rfl, hx⟩
        · rintro ⟨t, ht, htx⟩
          have hts : t = s := he ht
          subst t
          exact htx
      let quotientPredicate : Quot edge → X → Prop := Quot.lift predicate respects
      intro x y hxy
      have predicatesEqual : predicate (Sum.inl x) = predicate (Sum.inl y) :=
        congrArg quotientPredicate hxy
      have hyx : y = x := Eq.mp (congrFun predicatesEqual x) rfl
      exact hyx.symm
  · rintro ⟨Y, ⟨n, q, hq⟩, f, hf⟩
    apply subfinitelyEnumerable_of_injective f hf
    refine ⟨ULift.{u} (Fin n), ⟨n, ULift.down, ?_⟩, (fun i => q i.down), ?_⟩
    · intro i j hij
      cases i
      cases j
      cases hij
      rfl
    · intro y
      obtain ⟨i, hi⟩ := hq y
      exact ⟨⟨i⟩, hi⟩

end Orbifolds.Finiteness
