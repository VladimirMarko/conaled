import Orbifolds.Finiteness.InjectionClosure

/-!
# Proper finiteness is inherited by embedded types

External constructive content of Proposition 6.1.9(1).
A subset is the special case in which the injection is subtype inclusion.
Source: https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- Proper finiteness pulls back along any injective function. -/
theorem properlyFinite_of_injective {X : Type u} {Y : Type v}
    (f : X → Y) (hf : Function.Injective f) (hY : ProperlyFinite Y) :
    ProperlyFinite X := by
  refine ⟨subfinitelyEnumerable_of_injective f hf hY.1, ?_⟩
  intro x y
  cases hY.2 (f x) (f y) with
  | inl h => exact Or.inl (hf h)
  | inr h => exact Or.inr (fun hxy => h (congrArg f hxy))

end Orbifolds.Finiteness
