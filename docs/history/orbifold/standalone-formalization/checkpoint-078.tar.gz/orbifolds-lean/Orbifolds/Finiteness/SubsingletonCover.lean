import Orbifolds.Finiteness.AssociationTransfer

/-!
# The combinatorial finiteness step in a subsingleton cover

This is the external constructive combinatorial step used near the end of
Lemma 6.2.21. It assumes an already supplied cover by subsingletons with a
subfinitely enumerable index type. It does not assert the existence of the
cover, the required refinement of manifold opens, or the theorem's geometric
and cohesive hypotheses.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- A decidable-equality type covered by subsingletons indexed by a
subfinitely enumerable type is properly finite. -/
theorem properlyFinite_of_subsingleton_cover {K : Type u} {I : Type v}
    (U : I → K → Prop)
    (cover : ∀ k : K, ∃ i : I, U i k)
    (small : ∀ i : I, ∀ x y : K, U i x → U i y → x = y)
    (hI : SubfinitelyEnumerable I)
    (hK : HasDecidableEquality K) : ProperlyFinite K := by
  refine ⟨subfinitelyEnumerable_of_association (fun k i => U i k) ?_ hI, hK⟩
  constructor
  · exact cover
  · intro x y i hx hy
    exact small i x y hx hy

end Orbifolds.Finiteness
