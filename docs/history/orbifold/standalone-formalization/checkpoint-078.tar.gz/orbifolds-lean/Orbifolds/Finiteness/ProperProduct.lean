import Orbifolds.Finiteness.Definitions
import Orbifolds.Finiteness.FiniteProductCode

/-!
# Products of properly finite sets

External constructive content of Proposition 6.1.9(2).
The quotient witnesses and finite product code are exhibited explicitly.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- Properly finite types are closed under binary products. -/
theorem properlyFinite_product {X : Type u} {Y : Type v}
    (hX : ProperlyFinite X) (hY : ProperlyFinite Y) :
    ProperlyFinite (X × Y) := by
  obtain ⟨S, ⟨m, e, he⟩, q, hq⟩ := hX.1
  obtain ⟨T, ⟨n, f, hf⟩, r, hr⟩ := hY.1
  refine ⟨⟨S × T, ⟨m * n, (fun p => finPair (e p.1, f p.2)), ?_⟩,
    (fun p => (q p.1, r p.2)), ?_⟩, ?_⟩
  · intro a b hab
    have hp := finPair_injective m n hab
    exact Prod.ext (he (congrArg Prod.fst hp)) (hf (congrArg Prod.snd hp))
  · intro p
    obtain ⟨s, hs⟩ := hq p.1
    obtain ⟨t, ht⟩ := hr p.2
    exact ⟨(s, t), Prod.ext hs ht⟩
  · intro a b
    cases hX.2 a.1 b.1 with
    | inl hx =>
      cases hY.2 a.2 b.2 with
      | inl hy => exact Or.inl (Prod.ext hx hy)
      | inr hy => exact Or.inr (fun h => hy (congrArg Prod.snd h))
    | inr hx => exact Or.inr (fun h => hx (congrArg Prod.fst h))

end Orbifolds.Finiteness
