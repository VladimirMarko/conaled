import Orbifolds.Finiteness.Sum
import Orbifolds.Finiteness.ProperInjectionClosure
import Orbifolds.Finiteness.SubfiniteProper

/-!
# Properly finite disjoint unions indexed by a finite ordinal

External constructive content of Proposition 6.1.9(4), for an explicitly
finite index type `Fin n`:
https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9.

The proof splits off the zeroth fiber and reindexes the remaining fibers by
successor.  The two maps of dependent sums are given explicitly, so neither
selection of a family of witnesses nor classical choice is needed.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- A dependent disjoint union of `n` properly finite ordinary types is
properly finite. -/
theorem properlyFinite_finSigma {n : Nat} (F : Fin n → Type u)
    (hF : ∀ i, ProperlyFinite (F i)) : ProperlyFinite (Sigma F) := by
  induction n with
  | zero =>
    apply subfinite_properlyFinite
    refine ⟨0, (fun z => Fin.elim0 z.1), ?_⟩
    intro a b hab
    exact Fin.elim0 a.1
  | succ n ih =>
    let split : Sigma F → F 0 ⊕ Sigma (fun i : Fin n => F i.succ) :=
      fun z => Fin.cases
        (motive := fun i => F i → F 0 ⊕ Sigma (fun j : Fin n => F j.succ))
        (fun x => Sum.inl x)
        (fun i x => Sum.inr ⟨i, x⟩) z.1 z.2
    let join : F 0 ⊕ Sigma (fun i : Fin n => F i.succ) → Sigma F
      | Sum.inl x => ⟨0, x⟩
      | Sum.inr ⟨i, x⟩ => ⟨i.succ, x⟩
    have join_split (z : Sigma F) : join (split z) = z := by
      obtain ⟨i, x⟩ := z
      exact Fin.cases
        (motive := fun i => ∀ x : F i, join (split ⟨i, x⟩) = ⟨i, x⟩)
        (fun x => rfl)
        (fun i x => rfl) i x
    have hsplit : Function.Injective split := by
      intro a b h
      exact (join_split a).symm.trans ((congrArg join h).trans (join_split b))
    exact properlyFinite_of_injective split hsplit
      (properlyFinite_sum (hF 0) (ih (fun i : Fin n => F i.succ) (fun i => hF i.succ)))

end Orbifolds.Finiteness
