import Orbifolds.Finiteness.ProperProduct
import Orbifolds.Finiteness.ProperInjectionClosure

/-!
# Pullbacks of properly finite sets

External constructive content of Proposition 6.1.9(3). The pullback is the
explicit subtype of pairs satisfying the equality of their images.
-/

set_option autoImplicit false
universe u v w
namespace Orbifolds.Finiteness

/-- A set-level pullback of two properly finite types is properly finite. -/
theorem properlyFinite_pullback {X : Type u} {Y : Type v} {Z : Type w}
    (f : X → Z) (g : Y → Z) (hX : ProperlyFinite X) (hY : ProperlyFinite Y) :
    ProperlyFinite {p : X × Y // f p.1 = g p.2} := by
  apply properlyFinite_of_injective
    (fun p : {p : X × Y // f p.1 = g p.2} => p.val)
  · intro a b h
    exact Subtype.ext h
  · exact properlyFinite_product hX hY

end Orbifolds.Finiteness
