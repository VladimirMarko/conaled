import Std

/-! A constructive bound for a finite family of natural numbers.
This supports the explicit counterexample to printed Proposition 6.1.7. -/

set_option autoImplicit false
namespace Orbifolds.Finiteness

/-- Every finite family of natural numbers has a strict common upper bound. -/
theorem finiteNatFamilyBounded (n : Nat) (f : Fin n → Nat) :
    ∃ bound : Nat, ∀ i : Fin n, f i < bound := by
  induction n with
  | zero =>
    exact ⟨0, fun i => Fin.elim0 i⟩
  | succ n ih =>
    obtain ⟨bound, hbound⟩ := ih (fun i => f i.castSucc)
    refine ⟨max bound (f (Fin.last n) + 1), ?_⟩
    intro i
    by_cases hi : i.val < n
    · have h := hbound ⟨i.val, hi⟩
      have heq : (⟨i.val, hi⟩ : Fin n).castSucc = i := Fin.ext rfl
      rw [heq] at h
      exact Nat.lt_of_lt_of_le h (Nat.le_max_left _ _)
    · have heq : i = Fin.last n := by
        apply Fin.ext
        simp only [Fin.val_last]
        omega
      rw [heq]
      exact Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (Nat.le_max_right _ _)

end Orbifolds.Finiteness
