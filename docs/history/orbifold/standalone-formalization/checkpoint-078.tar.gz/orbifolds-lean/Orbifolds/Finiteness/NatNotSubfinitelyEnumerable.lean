import Orbifolds.Finiteness.Definitions
import Orbifolds.Finiteness.FiniteNatBound

/-!
# Natural numbers are not a quotient of a subfinite type

This external classical counterexample does not assume any theorem of the
paper. An embedding into Fin n lets us bound all values of a proposed
surjection to Nat, contradicting surjectivity. Classical selection is used
only to extend a partial finite family to a total family.
-/

set_option autoImplicit false
namespace Orbifolds.Finiteness

/-- Nat cannot be a surjective image of a subfinite type. -/
theorem nat_not_subfinitelyEnumerable : ¬ SubfinitelyEnumerable Nat := by
  classical
  rintro ⟨S, ⟨n, e, he⟩, q, hq⟩
  let f : Fin n → Nat := fun i =>
    if h : ∃ s : S, e s = i then q (Classical.choose h) else 0
  obtain ⟨bound, hbound⟩ := finiteNatFamilyBounded n f
  obtain ⟨s, hs⟩ := hq bound
  have hf : f (e s) = q s := by
    have hex : ∃ t : S, e t = e s := ⟨s, rfl⟩
    dsimp only [f]
    rw [dif_pos hex]
    exact congrArg q (he (Classical.choose_spec hex))
  have impossible := hbound (e s)
  rw [hf, hs] at impossible
  exact Nat.lt_irrefl bound impossible

end Orbifolds.Finiteness
