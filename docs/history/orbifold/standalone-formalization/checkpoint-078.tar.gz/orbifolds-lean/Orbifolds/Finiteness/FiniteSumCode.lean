import Std

/-!
# An injective code for a sum of finite ordinals

The left summand uses the indices below `m`; the right summand uses
indices `m + j`. The two ranges are disjoint. This arithmetic supports
ordinary set-level disjoint-union arguments in Proposition 6.1.9 of
arXiv:2205.15887, without introducing any classical choice.
-/

set_option autoImplicit false

namespace Orbifolds.Finiteness

/-- Encode two disjoint finite ordinals in consecutive ranges. -/
def finSum {m n : Nat} : Fin m ⊕ Fin n → Fin (m + n)
  | Sum.inl i =>
      ⟨i.val, Nat.lt_of_lt_of_le i.isLt (Nat.le_add_right m n)⟩
  | Sum.inr j =>
      ⟨m + j.val, Nat.add_lt_add_left j.isLt m⟩

/-- The finite sum code is injective, including empty summands. -/
theorem finSum_injective (m n : Nat) :
    Function.Injective (@finSum m n) := by
  intro a b h
  cases a with
  | inl i =>
    cases b with
    | inl j =>
      have values : i.val = j.val :=
        congrArg (fun z : Fin (m + n) => z.val) h
      exact congrArg Sum.inl (Fin.ext values)
    | inr j =>
      have values : i.val = m + j.val := congrArg Fin.val h
      have tooSmall : m + j.val < m := values ▸ i.isLt
      exact False.elim (Nat.lt_irrefl m
        (Nat.lt_of_le_of_lt (Nat.le_add_right m j.val) tooSmall))
  | inr i =>
    cases b with
    | inl j =>
      have values : m + i.val = j.val := congrArg Fin.val h
      have tooSmall : m + i.val < m := values.symm ▸ j.isLt
      exact False.elim (Nat.lt_irrefl m
        (Nat.lt_of_le_of_lt (Nat.le_add_right m i.val) tooSmall))
    | inr j =>
      have values : m + i.val = m + j.val := congrArg Fin.val h
      exact congrArg Sum.inr (Fin.ext (Nat.add_left_cancel values))

end Orbifolds.Finiteness
