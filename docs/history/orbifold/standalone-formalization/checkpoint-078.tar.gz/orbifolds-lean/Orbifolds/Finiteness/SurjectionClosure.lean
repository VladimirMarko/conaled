import Orbifolds.Finiteness.AssociationCharacterization

/-!
# Subfinite enumerability is preserved by surjections

A constructive quotient argument underlying Proposition 6.1.9(5).
The association representation keeps the statement valid across universes.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- Surjective images of subfinitely enumerable types are subfinitely enumerable. -/
theorem subfinitelyEnumerable_of_surjective {X : Type u} {Y : Type v}
    (f : X → Y) (hf : Function.Surjective f) (hX : SubfinitelyEnumerable X) :
    SubfinitelyEnumerable Y := by
  obtain ⟨n, r, hr⟩ := (subfinitelyEnumerable_iff_association X).mp hX
  apply (subfinitelyEnumerable_iff_association Y).mpr
  refine ⟨n, (fun y i => ∃ x : X, f x = y ∧ r x i), ?_⟩
  constructor
  · intro y
    obtain ⟨x, hx⟩ := hf y
    obtain ⟨i, hi⟩ := hr.total x
    exact ⟨i, x, hx, hi⟩
  · intro y z i hy hz
    obtain ⟨a, ha, hai⟩ := hy
    obtain ⟨b, hb, hbi⟩ := hz
    have hab : a = b := hr.uniqueLeft a b i hai hbi
    exact ha.symm.trans ((congrArg f hab).trans hb)

end Orbifolds.Finiteness
