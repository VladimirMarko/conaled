import Orbifolds.Finiteness.AssociationCharacterization

/-!
# Subfinite enumerability pulls back along injections

The constructive subobject argument underlying Proposition 6.1.9(1).
The proof uses the corrected association theorem and works across universes.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- A type embedded in a subfinitely enumerable type is subfinitely enumerable. -/
theorem subfinitelyEnumerable_of_injective {X : Type u} {Y : Type v}
    (f : X → Y) (hf : Function.Injective f) (hY : SubfinitelyEnumerable Y) :
    SubfinitelyEnumerable X := by
  obtain ⟨n, r, hr⟩ := (subfinitelyEnumerable_iff_association Y).mp hY
  apply (subfinitelyEnumerable_iff_association X).mpr
  refine ⟨n, (fun x i => r (f x) i), ?_⟩
  constructor
  · intro x
    exact hr.total (f x)
  · intro x y i hx hy
    exact hf (hr.uniqueLeft (f x) (f y) i hx hy)

end Orbifolds.Finiteness
