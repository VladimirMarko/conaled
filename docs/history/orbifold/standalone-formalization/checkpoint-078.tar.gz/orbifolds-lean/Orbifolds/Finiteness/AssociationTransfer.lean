import Orbifolds.Finiteness.AssociationCharacterization

/-!
# Composition of corrected associations

External constructive content of the second assertion of Proposition 6.1.7,
with the association uniqueness direction corrected as documented in the
characterization and the counterexample to the printed statement.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- A total relation assigning at most one source point to each target label
transfers subfinite enumerability from its target to its source. -/
theorem subfinitelyEnumerable_of_association {X : Type u} {Y : Type v}
    (r : X → Y → Prop) (hr : Association r)
    (hY : SubfinitelyEnumerable Y) : SubfinitelyEnumerable X := by
  obtain ⟨n, s, hs⟩ := (subfinitelyEnumerable_iff_association Y).mp hY
  apply (subfinitelyEnumerable_iff_association X).mpr
  refine ⟨n, (fun x i => ∃ y : Y, r x y ∧ s y i), ?_⟩
  constructor
  · intro x
    obtain ⟨y, hy⟩ := hr.total x
    obtain ⟨i, hi⟩ := hs.total y
    exact ⟨i, y, hy, hi⟩
  · intro x x' i hx hx'
    obtain ⟨y, hxy, hyi⟩ := hx
    obtain ⟨y', hx'y', hy'i⟩ := hx'
    have hyy' : y = y' := hs.uniqueLeft y y' i hyi hy'i
    subst y'
    exact hr.uniqueLeft x x' y hxy hx'y'

end Orbifolds.Finiteness
