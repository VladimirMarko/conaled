import Orbifolds.Finiteness.FinSigma
import Orbifolds.Finiteness.SurjectionClosure

/-!
# Finite unions indexed by a finite ordinal

External constructive content of Proposition 6.1.9(6), for a family indexed
by `Fin n`:
https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9.

The union is a surjective image of the dependent disjoint union. The proof
uses membership witnesses only inside propositions and does not choose an
index as a function of a point of the union.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- The union of `n` properly finite subsets of an ordinary type with
decidable equality is properly finite. -/
theorem properlyFinite_finUnion {Y : Type u} {n : Nat} (U : Fin n → Y → Prop)
    (hU : ∀ i, ProperlyFinite {y : Y // U i y})
    (hY : HasDecidableEquality Y) :
    ProperlyFinite {y : Y // ∃ i, U i y} := by
  let q : (Sigma fun i : Fin n => {y : Y // U i y}) →
      {y : Y // ∃ i, U i y} :=
    fun z => ⟨z.2.val, z.1, z.2.property⟩
  have hq : Function.Surjective q := by
    intro y
    obtain ⟨i, hi⟩ := y.property
    exact ⟨⟨i, ⟨y.val, hi⟩⟩, rfl⟩
  refine ⟨subfinitelyEnumerable_of_surjective q hq
    (properlyFinite_finSigma (fun i => {y : Y // U i y}) hU).1, ?_⟩
  intro a b
  cases hY a.val b.val with
  | inl h => exact Or.inl (Subtype.ext h)
  | inr h => exact Or.inr (fun hab => h (congrArg Subtype.val hab))

end Orbifolds.Finiteness
