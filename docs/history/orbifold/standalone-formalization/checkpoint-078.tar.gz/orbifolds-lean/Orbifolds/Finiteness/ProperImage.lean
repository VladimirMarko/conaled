import Orbifolds.Finiteness.SurjectionClosure

/-!
# Proper finiteness of images in a set with decidable equality

External constructive content of Proposition 6.1.9(5).
The image consists of values with merely existential preimages; no selected
preimages or classical choice are required.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.Finiteness

/-- An image of a subfinitely enumerable type in a decidable-equality type
is properly finite. -/
theorem properlyFinite_image {X : Type u} {Y : Type v}
    (f : X → Y) (hX : SubfinitelyEnumerable X) (hY : HasDecidableEquality Y) :
    ProperlyFinite {y : Y // ∃ x : X, f x = y} := by
  let q : X → {y : Y // ∃ x : X, f x = y} :=
    fun x => ⟨f x, x, rfl⟩
  have hq : Function.Surjective q := by
    intro y
    obtain ⟨x, hx⟩ := y.property
    exact ⟨x, Subtype.ext hx⟩
  refine ⟨subfinitelyEnumerable_of_surjective q hq hX, ?_⟩
  intro a b
  cases hY a.val b.val with
  | inl h => exact Or.inl (Subtype.ext h)
  | inr h => exact Or.inr (fun hab => h (congrArg Subtype.val hab))

end Orbifolds.Finiteness
