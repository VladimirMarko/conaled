import Orbifolds.Finiteness.Definitions
import Orbifolds.Finiteness.FiniteSumCode

/-!
# Binary disjoint unions of properly finite ordinary sets

This is the binary case of the external constructive content of
Proposition 6.1.9(4) in arXiv:2205.15887. A surjection from each subfinite
witness combines into a surjection from their disjoint union. The finite
sum code combines the two injections. Equality is decided by inspecting
the summand tags and using the given equality decisions within each
summand. No classical choice is used.
-/

set_option autoImplicit false

universe u v

namespace Orbifolds.Finiteness

/-- A binary disjoint union of properly finite ordinary types is properly finite. -/
theorem properlyFinite_sum {X : Type u} {Y : Type v}
    (hX : ProperlyFinite X) (hY : ProperlyFinite Y) :
    ProperlyFinite (X ⊕ Y) := by
  obtain ⟨S, ⟨m, e, he⟩, q, hq⟩ := hX.1
  obtain ⟨T, ⟨n, f, hf⟩, r, hr⟩ := hY.1
  refine ⟨?_, ?_⟩
  · refine ⟨S ⊕ T,
      ⟨m + n, (fun z => finSum (Sum.map e f z)), ?_⟩,
      Sum.map q r, ?_⟩
    · intro a b hab
      have tags : Sum.map e f a = Sum.map e f b :=
        finSum_injective m n hab
      cases a with
      | inl s =>
        cases b with
        | inl s' => exact congrArg Sum.inl (he (Sum.inl.inj tags))
        | inr _ => cases tags
      | inr t =>
        cases b with
        | inl _ => cases tags
        | inr t' => exact congrArg Sum.inr (hf (Sum.inr.inj tags))
    · intro z
      cases z with
      | inl x =>
        obtain ⟨s, hs⟩ := hq x
        exact ⟨Sum.inl s, congrArg Sum.inl hs⟩
      | inr y =>
        obtain ⟨t, ht⟩ := hr y
        exact ⟨Sum.inr t, congrArg Sum.inr ht⟩
  · intro a b
    cases a with
    | inl x =>
      cases b with
      | inl x' =>
        cases hX.2 x x' with
        | inl h => exact Or.inl (congrArg Sum.inl h)
        | inr h => exact Or.inr (fun h' => h (Sum.inl.inj h'))
      | inr _ => exact Or.inr (by intro h; cases h)
    | inr y =>
      cases b with
      | inl _ => exact Or.inr (by intro h; cases h)
      | inr y' =>
        cases hY.2 y y' with
        | inl h => exact Or.inl (congrArg Sum.inr h)
        | inr h => exact Or.inr (fun h' => h (Sum.inr.inj h'))

end Orbifolds.Finiteness
