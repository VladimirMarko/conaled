import Orbifolds.Finiteness.Definitions

/-!
# The printed association condition imposes no finiteness bound

Proposition 6.1.7, https://arxiv.org/pdf/2205.15887, printed page 54,
requires totality and uniqueness of the label for each point. The always-true
relation with the one-element finite ordinal satisfies exactly those printed
conditions for every type. The corrected `Association` has the other direction
of uniqueness. This theorem alone is the first half of the counterexample;
the non-subfinite-enumerability of Nat is established separately.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- The literal condition printed in Proposition 6.1.7 holds for every type. -/
theorem everyTypeHasPrintedAssociation (X : Type u) :
    PrintedAssociation (fun (_ : X) (_ : Fin 1) => True) where
  total := fun _ => ⟨⟨0, by decide⟩, True.intro⟩
  uniqueRight := by
    intro _ i j _ _
    apply Fin.ext
    omega

end Orbifolds.Finiteness
