import Orbifolds.Finiteness.Definitions

/-!
# Subfinite sets are properly finite

External constructive content of Lemma 6.1.5:
https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm5.
The equality decision uses only equality on the witnessing finite ordinal.
-/

set_option autoImplicit false
universe u
namespace Orbifolds.Finiteness

/-- Lemma 6.1.5, as a constructive statement about explicit ordinary sets. -/
theorem subfinite_properlyFinite {X : Type u} (hX : Subfinite X) :
    ProperlyFinite X := by
  obtain ⟨n, e, he⟩ := hX
  refine ⟨⟨X, ⟨n, e, he⟩, (fun x => x), ?_⟩, ?_⟩
  · intro x
    exact ⟨x, rfl⟩
  · intro x y
    by_cases h : e x = e y
    · exact Or.inl (he h)
    · exact Or.inr (fun hxy => h (congrArg e hxy))

end Orbifolds.Finiteness
