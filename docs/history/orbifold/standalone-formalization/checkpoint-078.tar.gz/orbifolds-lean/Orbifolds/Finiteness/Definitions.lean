import Std

/-!
# Constructive finiteness for ordinary sets

External set-level formulations of Definitions 6.1.1 and 6.1.3 of
https://arxiv.org/html/2205.15887v1#S6.SS1.

These are ordinary Lean propositions about explicit finite-ordinal witnesses.
No classical choice or excluded middle is used in these definitions or assumed
internally. The definitions do not supply the paper's cohesive discreteness.
`Association` uses the corrected uniqueness direction for Proposition 6.1.7.
`PrintedAssociation` records the different condition actually printed there.
-/

set_option autoImplicit false

universe u v

namespace Orbifolds.Finiteness

/-- An explicit bijection onto some finite ordinal exists. -/
def Finite (X : Type u) : Prop :=
  ∃ n : Nat, ∃ e : X → Fin n, Function.Injective e ∧ Function.Surjective e

/-- An explicit embedding into a finite ordinal exists. -/
def Subfinite (X : Type u) : Prop :=
  ∃ n : Nat, ∃ e : X → Fin n, Function.Injective e

/-- A finite ordinal surjects onto the type. -/
def FinitelyEnumerable (X : Type u) : Prop :=
  ∃ n : Nat, ∃ q : Fin n → X, Function.Surjective q

/-- A subfinite type surjects onto the type. -/
def SubfinitelyEnumerable (X : Type u) : Prop :=
  ∃ S : Type u, Subfinite S ∧ ∃ q : S → X, Function.Surjective q

/-- Decidable equality is kept as an explicit logical condition. -/
def HasDecidableEquality (X : Type u) : Prop :=
  ∀ x y : X, x = y ∨ x ≠ y

/-- The ordinary set-level content of Definition 6.1.3. -/
def ProperlyFinite (X : Type u) : Prop :=
  SubfinitelyEnumerable X ∧ HasDecidableEquality X

/-- The literal (incorrect for the claimed criterion) printed direction. -/
structure PrintedAssociation {X : Type u} {Y : Type v} (r : X → Y → Prop) : Prop where
  total : ∀ x, ∃ y, r x y
  uniqueRight : ∀ x y z, r x y → r x z → y = z

/-- Corrected association: each label represents at most one point. -/
structure Association {X : Type u} {Y : Type v} (r : X → Y → Prop) : Prop where
  total : ∀ x, ∃ y, r x y
  uniqueLeft : ∀ x x' y, r x y → r x' y → x = x'

end Orbifolds.Finiteness
