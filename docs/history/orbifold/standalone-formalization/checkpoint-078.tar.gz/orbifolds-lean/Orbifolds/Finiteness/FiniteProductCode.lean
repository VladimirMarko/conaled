import Std

/-!
# An injective code for a product of finite ordinals

The code for `(i, j) : Fin m × Fin n` is `n * i + j`, with codomain
`Fin (m * n)`. Its quotient on division by `n` recovers `i`, and
cancellation then recovers `j`. When a pair exists, its second coordinate
itself proves `0 < n`; no separate nonemptiness or positivity assumption
is imposed on the theorem.

This constructive arithmetic supports ordinary set-level product closure
arguments associated with Proposition 6.1.9 of arXiv:2205.15887.
-/

set_option autoImplicit false

namespace Orbifolds.Finiteness

/-- Encode a pair of finite indices by `n * i + j`. -/
def finPair {m n : Nat} (p : Fin m × Fin n) : Fin (m * n) :=
  ⟨n * p.1.val + p.2.val, by
    have withinBlock : n * p.1.val + p.2.val < n * (p.1.val + 1) := by
      calc
        n * p.1.val + p.2.val < n * p.1.val + n :=
          Nat.add_lt_add_left p.2.isLt _
        _ = n * (p.1.val + 1) := (Nat.mul_succ n p.1.val).symm
    have blockBound : n * (p.1.val + 1) ≤ n * m :=
      Nat.mul_le_mul_left n (Nat.succ_le_of_lt p.1.isLt)
    have bound := Nat.lt_of_lt_of_le withinBlock blockBound
    rw [Nat.mul_comm n m] at bound
    exact bound⟩

/-- The finite product code is injective, including the empty-index cases. -/
theorem finPair_injective (m n : Nat) :
    Function.Injective (@finPair m n) := by
  intro a b h
  have values : n * a.1.val + a.2.val = n * b.1.val + b.2.val :=
    congrArg Fin.val h
  have nPositive : 0 < n := Nat.zero_lt_of_lt a.2.isLt
  have quotients := congrArg (fun k : Nat => k / n) values
  have first : a.1.val = b.1.val := by
    simpa only [Nat.mul_add_div nPositive, Nat.div_eq_of_lt a.2.isLt,
      Nat.div_eq_of_lt b.2.isLt, Nat.add_zero] using quotients
  have second : a.2.val = b.2.val := by
    rw [first] at values
    exact Nat.add_left_cancel values
  exact Prod.ext (Fin.ext first) (Fin.ext second)

end Orbifolds.Finiteness
