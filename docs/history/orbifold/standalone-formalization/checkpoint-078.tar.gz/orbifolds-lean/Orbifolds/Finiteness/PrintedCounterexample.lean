import Orbifolds.Finiteness.PrintedAssociation
import Orbifolds.Finiteness.NatNotSubfinitelyEnumerable

/-!
# Counterexample to the literal Proposition 6.1.7

Source: https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7.
Nat satisfies the exact printed relation condition but not the claimed
finiteness conclusion. The corrected theorem lives in
`AssociationCharacterization.lean` and is kept distinct.
-/

namespace Orbifolds.Finiteness

/-- Nat is a counterexample to the characterization printed in Proposition 6.1.7. -/
theorem printedAssociation_nat_counterexample :
    (∃ n : Nat, ∃ r : Nat → Fin n → Prop, PrintedAssociation r) ∧
      ¬ SubfinitelyEnumerable Nat :=
  ⟨⟨1, (fun _ _ => True), everyTypeHasPrintedAssociation Nat⟩,
    nat_not_subfinitelyEnumerable⟩

end Orbifolds.Finiteness
