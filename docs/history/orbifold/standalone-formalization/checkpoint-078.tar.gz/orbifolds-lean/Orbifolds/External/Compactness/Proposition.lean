import Orbifolds.External.Compactness.DPCompact

/-!
# Compactness of a proposition is equivalent to its decidability

External constructive logical content of Warning 6.2.3:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm3

The conclusion uses logical decidability `P ∨ ¬ P`, not a global excluded-middle
assumption. In the converse direction that disjunction is an explicit input.
-/

namespace Orbifolds.External.Compactness

/-- A proposition is DP compact exactly when that proposition is decidable. -/
theorem dpCompact_prop_iff_decidable (P : Prop) :
    DPCompact P ↔ P ∨ ¬ P := by
  constructor
  · intro hP
    exact hP P (fun _ => False) (fun p => Or.inl p)
  · intro hP A B h
    cases hP with
    | inl p =>
      cases h p with
      | inl hA => exact Or.inl hA
      | inr hB => exact Or.inr (fun _ => hB)
    | inr hnP => exact Or.inr (fun p => False.elim (hnP p))

end Orbifolds.External.Compactness
