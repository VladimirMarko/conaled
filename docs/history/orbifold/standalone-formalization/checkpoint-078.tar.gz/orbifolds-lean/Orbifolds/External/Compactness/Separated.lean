import Std

/-!
# Dubuc-Penon separatedness, as an external predicate

Proposition 6.2.17 in David Jaz Myers, arXiv:2205.15887v1, states this
separatedness condition explicitly. Keeping it as a hypothesis avoids
silently supplying classical excluded middle in the compact-closed proof.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm17
-/

namespace Orbifolds.External.Compactness

universe u

/-- Inequality is cotransitive in the explicit sense used in Proposition
6.2.17. This uses ordinary Lean equality, not a cohesive identity type. -/
def DPSeparated (X : Sort u) : Prop :=
  ∀ x y : X, x ≠ y → ∀ z : X, x ≠ z ∨ z ≠ y

end Orbifolds.External.Compactness
