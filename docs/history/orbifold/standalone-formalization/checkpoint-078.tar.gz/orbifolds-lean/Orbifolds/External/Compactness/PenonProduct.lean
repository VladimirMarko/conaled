import Orbifolds.External.Compactness.Penon

/-!
# Products of Penon-open predicates

This is the external constructive logical content of Lemma 6.2.9 in
David Jaz Myers, arXiv:2205.15887v1. Both openness hypotheses are explicit;
the proof uses only cases on their disjunctions and equality projections.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm9
-/

namespace Orbifolds.External.Compactness

universe u v

theorem penonOpen_product {X : Type u} {Y : Type v}
    {U : X → Prop} {V : Y → Prop}
    (hU : PenonOpen U) (hV : PenonOpen V) :
    PenonOpen (fun xy : X × Y => U xy.1 ∧ V xy.2) := by
  intro x hx y
  cases hU x.1 hx.1 y.1 with
  | inl hne =>
    exact Or.inl (fun hxy => hne (congrArg Prod.fst hxy))
  | inr hu =>
    cases hV x.2 hx.2 y.2 with
    | inl hne =>
      exact Or.inl (fun hxy => hne (congrArg Prod.snd hxy))
    | inr hv =>
      exact Or.inr ⟨hu, hv⟩

end Orbifolds.External.Compactness
