import Orbifolds.External.Compactness.DPCompact

/-!
# Surjective images preserve Dubuc-Penon compactness

External constructive logical content of Lemma 6.2.2, clause 2:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2

The explicit surjectivity witnesses are eliminated only into propositions.
No choice function or excluded middle is needed.
-/

namespace Orbifolds.External.Compactness

universe u v

/-- A surjective image of a DP compact sort is DP compact. -/
theorem dpCompact_surjective {K : Sort u} {X : Sort v}
    (f : K → X) (hK : DPCompact K) (hf : Function.Surjective f) :
    DPCompact X := by
  intro A B h
  cases hK A (fun k => B (f k)) (fun k => h (f k)) with
  | inl hA => exact Or.inl hA
  | inr hB =>
    apply Or.inr
    intro x
    cases hf x with
    | intro k hk => exact hk ▸ hB k

end Orbifolds.External.Compactness
