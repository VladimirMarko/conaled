import Orbifolds.External.GroupData
import Orbifolds.External.Groupoid

/-!
# Automorphism groups of explicit ordinary groupoids

These automorphisms are arrows in an external groupoid, not self-equalities
of an ordinary Lean term.
-/

namespace Orbifolds.External

universe u v

/-- Endomorphisms of a point of a groupoid form an ordinary group. -/
def GroupoidData.automorphismGroup {X : Type u} (C : GroupoidData.{u, v} X)
    (x : X) : GroupData (C.Hom x x) where
  one := C.id x
  mul := C.comp
  inv := C.inv
  mul_assoc a b c := (C.comp_assoc a b c).symm
  one_mul := C.id_comp
  mul_one := C.comp_id
  inv_mul := C.inv_comp
  mul_inv := C.comp_inv

end Orbifolds.External
