import Orbifolds.External.RegularAction
import Orbifolds.External.EquivariantMap

namespace Orbifolds.External

universe u v

/-- The ordinary left action on equivariant maps from the regular action,
given by precomposing with right multiplication: `(g • f)(k) = f(k * g)`. -/
def Action.regularMapAction {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) : Action S (EquivariantMap S.regularAction A) where
  act g f := ⟨fun k => f.val (S.mul k g), fun k h => by
    calc
      f.val (S.mul (S.mul k h) g) = f.val (S.mul k (S.mul h g)) :=
        congrArg f.val (S.mul_assoc k h g)
      _ = A.act k (f.val (S.mul h g)) := f.property k (S.mul h g)⟩
  one_act f := Subtype.eq (funext (fun k => congrArg f.val (S.mul_one k)))
  mul_act g h f :=
    Subtype.eq (funext (fun k => congrArg f.val (S.mul_assoc k g h).symm))

end Orbifolds.External
