import Orbifolds.External.TrivialBooleanAction
import Orbifolds.External.ActionGroupoid

/-!
# A concrete ordinary groupoid with nontrivial isotropy

Unlike equality proofs for a Lean term, the arrows of the action groupoid
are data and need not all coincide. This example verifies that the current
external presentation actually retains the two symmetries of the one-point
action of the two-element group. It is not the construction of a synthetic
smooth orbifold or of a delooping in Lean's identity types.
-/

namespace Orbifolds.External

/-- The action groupoid of the trivial two-element action has two distinct
automorphisms of its unique object. -/
theorem trivialBooleanAction_has_distinct_loops :
    ∃ f g : trivialBooleanAction.groupoid.Hom () (), f ≠ g := by
  refine ⟨⟨false, rfl⟩, ⟨true, rfl⟩, ?_⟩
  intro h
  have impossible : false = true := congrArg Subtype.val h
  cases impossible

end Orbifolds.External
