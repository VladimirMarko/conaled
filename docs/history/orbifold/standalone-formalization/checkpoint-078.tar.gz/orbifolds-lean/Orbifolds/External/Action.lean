import Orbifolds.External.GroupData

/-!
# Ordinary actions: supporting structure

These are ordinary algebraic left actions on Lean types. This supporting
definition does not identify a Lean type with a delooping, nor a function out
of a delooping with a homotopy-coherent group action.
-/

namespace Orbifolds.External

universe u v

/-- A left action with explicit unit and composition laws. -/
structure Action {G : Type u} (S : GroupData G) (X : Type v) where
  act : G → X → X
  one_act : ∀ x, act S.one x = x
  mul_act : ∀ g h x, act (S.mul g h) x = act g (act h x)

end Orbifolds.External
