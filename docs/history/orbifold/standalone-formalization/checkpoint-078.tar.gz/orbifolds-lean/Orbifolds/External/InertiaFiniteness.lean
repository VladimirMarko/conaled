import Orbifolds.External.Inertia
import Orbifolds.Finiteness.ProperInjectionClosure

/-!
# Properly finite arrow types in an ordinary inertia groupoid

This proves the external arrow-finiteness part of Corollary 6.4.4.
The commuting arrows embed into the original arrow type, so their proper
finiteness follows constructively from Proposition 6.1.9(1).
The assertion that the inertia type is microlinear, and hence the full
orbifold corollary, are not asserted by this ordinary groupoid theorem.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.External

/-- Inertia preserves proper finiteness of the explicit arrow types. -/
theorem GroupoidData.inertia_homs_properlyFinite {X : Type u}
    (C : GroupoidData.{u, v} X)
    (hC : ∀ x y : X, Orbifolds.Finiteness.ProperlyFinite (C.Hom x y)) :
    ∀ a b : (Σ x : X, C.Hom x x),
      Orbifolds.Finiteness.ProperlyFinite (C.inertia.Hom a b) := by
  intro a b
  apply Orbifolds.Finiteness.properlyFinite_of_injective
    (fun f : C.inertia.Hom a b => f.val)
  · intro f g hfg
    exact Subtype.ext hfg
  · exact hC a.1 b.1

end Orbifolds.External
