import Orbifolds.External.TorsorEvaluationEquivariant

/-!
# The source of ordinary torsor evaluation is a torsor

The right-translation action on equivariant bijections from the regular
action to an ordinary torsor is itself a torsor. With the equivalence and
equivariance proved in the imported files, this completes the external
ordinary algebraic counterpart of Lemma 2.1.13 in arXiv:2205.15887v1.
No univalent identification type of torsors is constructed here.
-/

namespace Orbifolds.External

universe u v

/-- Equivariant bijections from the regular action to an ordinary torsor,
with right translation, form an ordinary torsor. -/
theorem Action.regularBijectionAction_isTorsor {G : Type u} {S : GroupData G}
    {X : Type v} (A : Action S X) (hT : A.IsTorsor) :
    A.regularBijectionAction.IsTorsor := by
  let e := A.torsorEvaluationIso hT
  have hinj : Function.Injective e.toFun :=
    Function.LeftInverse.injective e.left_inv
  constructor
  · obtain ⟨x⟩ := hT.1
    exact ⟨e.invFun x⟩
  · intro f
    constructor
    · intro g h eq
      apply (hT.2 (e.toFun f)).1
      calc
        A.act g (e.toFun f) = e.toFun (A.regularBijectionAction.act g f) :=
          (A.torsorEvaluation_equivariant hT g f).symm
        _ = e.toFun (A.regularBijectionAction.act h f) := congrArg e.toFun eq
        _ = A.act h (e.toFun f) := A.torsorEvaluation_equivariant hT h f
    · intro f'
      obtain ⟨g, hg⟩ := (hT.2 (e.toFun f)).2 (e.toFun f')
      refine ⟨g, hinj ?_⟩
      calc
        e.toFun (A.regularBijectionAction.act g f) = A.act g (e.toFun f) :=
          A.torsorEvaluation_equivariant hT g f
        _ = e.toFun f' := hg

end Orbifolds.External
