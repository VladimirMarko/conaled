import Orbifolds.External.RegularAction
import Orbifolds.External.EquivariantMap
import Orbifolds.External.TypeIso

/-!
# Equivariant maps out of the regular action

This is the ordinary algebraic fact used in the proof of Lemma 2.1.13 of
arXiv:2205.15887v1: an equivariant function out of `G` is determined by its
value at the identity. The present result holds for every ordinary action,
without a torsor assumption. The torsor case additionally requires the
equivariant function to be a bijection.
-/

namespace Orbifolds.External

universe u v

/-- Evaluation at the identity, with the orbit map as its inverse. -/
def Action.regularEvaluationIso {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) : TypeIso (EquivariantMap S.regularAction A) X where
  toFun f := f.val S.one
  invFun x := ⟨fun g => A.act g x, fun g h => A.mul_act g h x⟩
  left_inv f := Subtype.eq (funext (fun g => by
    calc
      A.act g (f.val S.one) = f.val (S.mul g S.one) :=
        (f.property g S.one).symm
      _ = f.val g := congrArg f.val (S.mul_one g)))
  right_inv x := A.one_act x

end Orbifolds.External
