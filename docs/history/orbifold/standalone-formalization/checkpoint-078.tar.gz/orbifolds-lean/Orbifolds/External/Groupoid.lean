import Std

/-!
# Explicit ordinary groupoids: supporting structure

The arrows below are stored in `Type`, rather than being Lean equality proofs
in `Prop`. Distinct automorphisms can therefore remain distinct data. This is
an external groupoid presentation and is not a construction of a homotopy
quotient inside a univalent or cohesive type theory.
-/

namespace Orbifolds.External

universe u v

/-- An ordinary groupoid with the objects and arrows given explicitly. -/
structure GroupoidData (X : Type u) where
  Hom : X → X → Type v
  id : ∀ x, Hom x x
  comp : {x y z : X} → Hom y z → Hom x y → Hom x z
  inv : {x y : X} → Hom x y → Hom y x
  id_comp : ∀ {x y} (f : Hom x y), comp (id y) f = f
  comp_id : ∀ {x y} (f : Hom x y), comp f (id x) = f
  comp_assoc : ∀ {w x y z} (h : Hom y z) (g : Hom x y) (f : Hom w x),
    comp h (comp g f) = comp (comp h g) f
  inv_comp : ∀ {x y} (f : Hom x y), comp (inv f) f = id x
  comp_inv : ∀ {x y} (f : Hom x y), comp f (inv f) = id y

end Orbifolds.External
