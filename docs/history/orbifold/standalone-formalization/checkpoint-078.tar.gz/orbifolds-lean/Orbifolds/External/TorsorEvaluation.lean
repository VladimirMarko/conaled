import Orbifolds.External.RegularAction
import Orbifolds.External.EquivariantBijection
import Orbifolds.External.Torsor
import Orbifolds.External.TypeIso

/-!
# Torsor evaluation: external algebraic counterpart of Lemma 2.1.13

For an ordinary torsor `T`, evaluation at the identity is an explicit
equivalence between equivariant bijections `G → T` and the points of `T`.
Its inverse sends a point to its orbit map. This formalizes the algebraic
argument in Lemma 2.1.13 of arXiv:2205.15887v1, not the paper's statement
about identifications in a univalent type of torsors. The result below is an
equivalence of ordinary types; no claim about a transported torsor action is
made by this declaration alone.
-/

namespace Orbifolds.External

universe u v

/-- Evaluation at the identity identifies equivariant bijections from the
regular action with points of an ordinary torsor. -/
def Action.torsorEvaluationIso {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) (hT : A.IsTorsor) :
    TypeIso (EquivariantBijection S.regularAction A) X where
  toFun f := f.val S.one
  invFun x := ⟨fun g => A.act g x, ⟨fun g h => A.mul_act g h x, hT.2 x⟩⟩
  left_inv f := Subtype.eq (funext (fun g => by
    calc
      A.act g (f.val S.one) = f.val (S.mul g S.one) :=
        (f.property.1 g S.one).symm
      _ = f.val g := congrArg f.val (S.mul_one g)))
  right_inv x := A.one_act x

end Orbifolds.External
