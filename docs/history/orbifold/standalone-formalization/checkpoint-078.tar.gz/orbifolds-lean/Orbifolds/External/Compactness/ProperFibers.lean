import Orbifolds.External.Compactness.Proper
import Orbifolds.External.Compactness.Sigma
import Orbifolds.External.Compactness.SurjectiveImage

/-!
# DP properness is equivalent to compact fibers

This is the principal assertion of Proposition 6.2.4 in David Jaz Myers,
arXiv:2205.15887v1, for ordinary Lean subtypes and equality fibers. The
reverse implication uses compact dependent sums and surjective images.
The witnesses of surjectivity are explicit; no choice principle is used.
This file does not identify equality fibers with cohesive homotopy fibers.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4
-/

namespace Orbifolds.External.Compactness

universe u v

theorem dpProper_iff_fibers {X : Type u} {Y : Type v} (f : X → Y) :
    DPProper f ↔ ∀ y : Y, DPCompact {x : X // f x = y} := by
  constructor
  · intro hf y
    have hSingleton : DPCompact {z : Y // z = y} := by
      intro A B h
      cases h ⟨y, rfl⟩ with
      | inl hA => exact Or.inl hA
      | inr hB =>
        apply Or.inr
        intro z
        cases z with
        | mk z hz =>
          cases hz
          exact hB
    exact hf (fun z => z = y) hSingleton
  · intro hFibers K hK
    let g : (Σ y : {y : Y // K y}, {x : X // f x = y.val}) →
        {x : X // K (f x)} :=
      fun p => ⟨p.2.val, p.2.property.symm ▸ p.1.property⟩
    apply dpCompact_surjective g
      (dpCompact_sigma hK (fun y => hFibers y.val))
    intro x
    exact ⟨⟨⟨f x.val, x.property⟩, ⟨x.val, rfl⟩⟩, rfl⟩

end Orbifolds.External.Compactness
