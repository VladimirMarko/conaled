import Orbifolds.External.Compactness.Sigma
import Orbifolds.External.Compactness.SurjectiveImage

/-!
# Products of DP-compact types

This records the explicit product corollary in Proposition 6.2.5 in
David Jaz Myers, arXiv:2205.15887v1, using Lean's native product type.
It follows from the dependent-sum theorem by an explicit surjection.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm5
-/

namespace Orbifolds.External.Compactness

universe u v

theorem dpCompact_product {X : Type u} {Y : Type v}
    (hX : DPCompact X) (hY : DPCompact Y) : DPCompact (X × Y) := by
  apply dpCompact_surjective (fun p : Σ _ : X, Y => (p.1, p.2))
    (dpCompact_sigma hX (fun _ => hY))
  intro p
  exact ⟨⟨p.1, p.2⟩, rfl⟩

end Orbifolds.External.Compactness
