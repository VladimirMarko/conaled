import Std

/-!
# Explicit equivalences of ordinary Lean types

This elementary structure records two inverse functions. It does not provide
univalence or convert such equivalences into identity types of a higher
universe.
-/

namespace Orbifolds.External

universe u v

/-- Two mutually inverse functions between ordinary Lean types. -/
structure TypeIso (X : Type u) (Y : Type v) where
  toFun : X → Y
  invFun : Y → X
  left_inv : ∀ x, invFun (toFun x) = x
  right_inv : ∀ y, toFun (invFun y) = y

end Orbifolds.External
