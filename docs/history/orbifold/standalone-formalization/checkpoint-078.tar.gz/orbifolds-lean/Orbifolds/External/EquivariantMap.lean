import Orbifolds.External.Action

namespace Orbifolds.External

universe u v w

/-- An ordinary equivariant function between two actions of the same group. -/
def EquivariantMap {G : Type u} {S : GroupData G} {X : Type v} {Y : Type w}
    (A : Action S X) (B : Action S Y) :=
  {f : X → Y // ∀ g x, f (A.act g x) = B.act g (f x)}

end Orbifolds.External
