import Orbifolds.External.Action

/-!
# Ordinary torsors

The definition records a nonempty ordinary action for which every orbit map
is bijective, equivalently an action that is free and transitive. It has no
chosen base point and assumes no global choice principle.
-/

namespace Orbifolds.External

universe u v

/-- An ordinary torsor is nonempty and each of its orbit maps is bijective. -/
def Action.IsTorsor {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) : Prop :=
  Nonempty X ∧ ∀ x,
    Function.Injective (fun g => A.act g x) ∧
    Function.Surjective (fun g => A.act g x)

end Orbifolds.External
