import Orbifolds.External.Compactness.DPCompact
import Orbifolds.External.Compactness.Penon
import Orbifolds.External.Compactness.Separated

/-!
# DP-compact predicates in a DP-separated type are Penon closed

This follows the logical argument of Proposition 6.2.17 in David Jaz
Myers, arXiv:2205.15887v1. Compactness and separatedness remain explicit
hypotheses, and the proof does not use classical choice or excluded middle.
All predicates here have the ordinary Lean interpretation documented in
their definition files; no cohesive-model claim is made.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm17
-/

namespace Orbifolds.External.Compactness

universe u

theorem dpCompact_penonClosed {X : Type u} {K : X → Prop}
    (hSeparated : DPSeparated X) (hCompact : DPCompact {x : X // K x}) :
    PenonClosed K := by
  intro x hx z
  have hAll : ∀ k : {k : X // K k}, x ≠ z ∨ z ≠ k.val := by
    intro k
    apply hSeparated x k.val
    intro hxk
    exact hx (hxk.symm ▸ k.property)
  cases hCompact (x ≠ z) (fun k => z ≠ k.val) hAll with
  | inl hxz => exact Or.inl hxz
  | inr hzk => exact Or.inr (fun hz => hzk ⟨z, hz⟩ rfl)

end Orbifolds.External.Compactness
