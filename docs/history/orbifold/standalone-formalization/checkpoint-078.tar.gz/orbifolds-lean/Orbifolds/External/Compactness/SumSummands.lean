import Orbifolds.External.Compactness.DPCompact

/-!
# Compact coproducts have compact summands

External constructive logical content of Lemma 6.2.2, clause 3:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2

A predicate on one summand is extended by `True` on the other. Thus the proof
does not require either summand to be inhabited and never chooses a retraction.
-/

namespace Orbifolds.External.Compactness

universe u v

/-- DP compactness of a coproduct implies compactness of both summands. -/
theorem dpCompact_sum_summands {X : Type u} {Y : Type v}
    (hSum : DPCompact (X ⊕ Y)) : DPCompact X ∧ DPCompact Y := by
  constructor
  · intro A B h
    have hAll : ∀ z : X ⊕ Y, A ∨ Sum.elim B (fun _ => True) z := by
      intro z
      cases z with
      | inl x => exact h x
      | inr _ => exact Or.inr True.intro
    cases hSum A (Sum.elim B (fun _ => True)) hAll with
    | inl hA => exact Or.inl hA
    | inr hB => exact Or.inr (fun x => hB (Sum.inl x))
  · intro A B h
    have hAll : ∀ z : X ⊕ Y, A ∨ Sum.elim (fun _ => True) B z := by
      intro z
      cases z with
      | inl _ => exact Or.inr True.intro
      | inr y => exact h y
    cases hSum A (Sum.elim (fun _ => True) B) hAll with
    | inl hA => exact Or.inl hA
    | inr hB => exact Or.inr (fun y => hB (Sum.inr y))

end Orbifolds.External.Compactness
