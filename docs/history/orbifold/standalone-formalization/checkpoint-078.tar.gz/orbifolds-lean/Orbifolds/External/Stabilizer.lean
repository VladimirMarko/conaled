import Orbifolds.External.ActionGroupoid
import Orbifolds.External.AutomorphismGroup

/-!
# Stabilizers as automorphism groups

This is the external ordinary groupoid counterpart of Corollary 2.3.3 in
arXiv:2205.15887v1. The automorphism arrows in the action groupoid are
definitionally the stabilizer subtype, and the construction below equips
that subtype with its inherited group law. It does not identify stabilizers
with self-equalities of Lean terms.
-/

namespace Orbifolds.External

universe u v

/-- The stabilizer group is the automorphism group at `x` in the action
groupoid; its multiplication and inverses retain their underlying elements. -/
def Action.stabilizerGroup {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) (x : X) : GroupData {g : G // A.act g x = x} :=
  A.groupoid.automorphismGroup x

end Orbifolds.External
