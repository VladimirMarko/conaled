import Std

/-!
# Ordinary algebraic groups: supporting structure

This file is part of an external, ordinary groupoid fragment of David Jaz
Myers, *Orbifolds as microlinear types in synthetic differential cohesive
homotopy type theory*, arXiv:2205.15887v1, sections 2.1--2.3.

`GroupData` is explicit ordinary algebraic group data. The law fields are
assumptions on an input structure, not axioms added to Lean. No delooping,
univalence, cohesive modality, or synthetic differential structure is claimed.
-/

namespace Orbifolds.External

universe u

/-- Ordinary algebraic group operations and their laws, supplied explicitly. -/
structure GroupData (G : Type u) where
  one : G
  mul : G → G → G
  inv : G → G
  mul_assoc : ∀ a b c, mul (mul a b) c = mul a (mul b c)
  one_mul : ∀ a, mul one a = a
  mul_one : ∀ a, mul a one = a
  inv_mul : ∀ a, mul (inv a) a = one
  mul_inv : ∀ a, mul a (inv a) = one

end Orbifolds.External
