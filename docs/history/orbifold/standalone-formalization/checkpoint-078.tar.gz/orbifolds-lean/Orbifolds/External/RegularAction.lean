import Orbifolds.External.Action

namespace Orbifolds.External

universe u

/-- The ordinary left regular action of an algebraic group on itself. -/
def GroupData.regularAction {G : Type u} (S : GroupData G) : Action S G where
  act := S.mul
  one_act := S.one_mul
  mul_act := S.mul_assoc

end Orbifolds.External
