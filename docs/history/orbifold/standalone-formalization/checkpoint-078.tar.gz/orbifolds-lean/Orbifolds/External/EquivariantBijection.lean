import Orbifolds.External.Action

namespace Orbifolds.External

universe u v w

/-- An ordinary equivariant function that is bijective on the underlying
types. No equality of action structures or univalence is asserted. -/
def EquivariantBijection {G : Type u} {S : GroupData G} {X : Type v} {Y : Type w}
    (A : Action S X) (B : Action S Y) :=
  {f : X → Y // (∀ g x, f (A.act g x) = B.act g (f x)) ∧
    Function.Injective f ∧ Function.Surjective f}

end Orbifolds.External
