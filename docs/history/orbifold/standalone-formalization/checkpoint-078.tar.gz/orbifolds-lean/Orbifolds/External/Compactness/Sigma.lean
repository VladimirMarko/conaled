import Orbifolds.External.Compactness.DPCompact

/-!
# Dependent sums of Dubuc-Penon compact types

External constructive logical content of Proposition 6.2.5:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm5

The proof distributes the fixed proposition first through each fiber and
then through the base. Both compactness assumptions remain explicit.
No classical case split, choice, or cohesive-model assumption is used.
-/

namespace Orbifolds.External.Compactness

universe u v

/-- DP compactness is preserved by a dependent sum with compact base and fibers. -/
theorem dpCompact_sigma {K : Type u} {F : K → Type v}
    (hK : DPCompact K) (hF : ∀ k : K, DPCompact (F k)) :
    DPCompact (Sigma F) := by
  intro A B h
  have hInner : ∀ k : K, A ∨ ∀ x : F k, B ⟨k, x⟩ :=
    fun k => hF k A (fun x => B ⟨k, x⟩) (fun x => h ⟨k, x⟩)
  cases hK A (fun k => ∀ x : F k, B ⟨k, x⟩) hInner with
  | inl hA => exact Or.inl hA
  | inr hB => exact Or.inr (fun x => hB x.1 x.2)

end Orbifolds.External.Compactness
