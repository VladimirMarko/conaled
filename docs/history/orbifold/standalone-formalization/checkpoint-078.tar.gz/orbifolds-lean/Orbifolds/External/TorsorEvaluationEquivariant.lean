import Orbifolds.External.TorsorEvaluation
import Orbifolds.External.RegularBijectionAction

/-!
# Equivariance of the ordinary torsor evaluation equivalence

Together with `Action.torsorEvaluationIso`, this proves that evaluation is an
equivariant equivalence for the explicit right-translation action on the
ordinary equivariant bijections `G → T`. This is the external ordinary
algebraic counterpart of the equivariance assertion in Lemma 2.1.13 of
arXiv:2205.15887v1. It does not identify these bijections with an identity type
in a univalent universe.
-/

namespace Orbifolds.External

universe u v

/-- The ordinary torsor evaluation equivalence is equivariant. -/
theorem Action.torsorEvaluation_equivariant {G : Type u} {S : GroupData G}
    {X : Type v} (A : Action S X) (hT : A.IsTorsor) (g : G)
    (f : EquivariantBijection S.regularAction A) :
    (A.torsorEvaluationIso hT).toFun (A.regularBijectionAction.act g f) =
      A.act g ((A.torsorEvaluationIso hT).toFun f) := by
  change f.val (S.mul S.one g) = A.act g (f.val S.one)
  calc
    f.val (S.mul S.one g) = f.val g := congrArg f.val (S.one_mul g)
    _ = f.val (S.mul g S.one) := congrArg f.val (S.mul_one g).symm
    _ = A.act g (f.val S.one) := f.property.1 g S.one

end Orbifolds.External
