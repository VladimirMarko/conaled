import Orbifolds.External.Compactness.DPCompact

/-!
# External DP-properness

Definition 6.2.1 in David Jaz Myers, arXiv:2205.15887v1, calls a map DP
proper when the inverse image of every DP-compact subtype is DP compact.
This definition preserves those quantifiers using ordinary Lean subtypes.
It does not supply a cohesive interpretation of the ambient types.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm1
-/

namespace Orbifolds.External.Compactness

universe u v

def DPProper {X : Type u} {Y : Type v} (f : X → Y) : Prop :=
  ∀ K : Y → Prop, DPCompact {y : Y // K y} →
    DPCompact {x : X // K (f x)}

end Orbifolds.External.Compactness
