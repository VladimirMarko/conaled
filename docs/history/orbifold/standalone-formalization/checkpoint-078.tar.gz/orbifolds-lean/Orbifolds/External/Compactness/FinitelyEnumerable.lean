import Orbifolds.Finiteness.Definitions
import Orbifolds.External.Compactness.FiniteOrdinal
import Orbifolds.External.Compactness.SurjectiveImage

/-!
# Finitely enumerable types are Dubuc-Penon compact

External constructive logical content of Lemma 6.2.2, clause 1:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2

The input is the project's explicit finite-surjection definition from 6.1.1.
The witnesses are eliminated into the proposition of compactness, with no
classical choice or decidable equality assumption on the target.
-/

namespace Orbifolds.External.Compactness

universe u

/-- Finite enumerability suffices for DP compactness without decidable equality. -/
theorem dpCompact_finitelyEnumerable {X : Type u}
    (hX : Orbifolds.Finiteness.FinitelyEnumerable X) : DPCompact X := by
  cases hX with
  | intro n hn =>
    cases hn with
    | intro f hf => exact dpCompact_surjective f (dpCompact_fin n) hf

end Orbifolds.External.Compactness
