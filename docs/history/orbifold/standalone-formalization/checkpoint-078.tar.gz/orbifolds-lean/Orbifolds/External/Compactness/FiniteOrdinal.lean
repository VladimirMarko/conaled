import Orbifolds.External.Compactness.DPCompact

/-!
# Finite ordinals are Dubuc-Penon compact

The finite-ordinal step in Lemma 6.2.2, clause 1:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2

This proof is induction on the finite ordinal. Its case splits use only
disjunctions supplied by the premise and by the induction hypothesis.
-/

namespace Orbifolds.External.Compactness

/-- Every standard finite ordinal satisfies the DP compactness formula. -/
theorem dpCompact_fin (n : Nat) : DPCompact (Fin n) := by
  induction n with
  | zero =>
    intro A B _
    exact Or.inr (fun i => Fin.elim0 i)
  | succ n ih =>
    intro A B h
    cases h 0 with
    | inl hA => exact Or.inl hA
    | inr hZero =>
      cases ih A (fun i => B i.succ) (fun i => h i.succ) with
      | inl hA => exact Or.inl hA
      | inr hSucc => exact Or.inr (Fin.cases hZero hSucc)

end Orbifolds.External.Compactness
