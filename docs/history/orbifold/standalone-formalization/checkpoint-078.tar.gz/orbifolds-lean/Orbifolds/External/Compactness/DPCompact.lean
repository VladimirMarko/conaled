import Std

/-!
# The logical formula for Dubuc-Penon compactness

This is an external logical fragment of Definition 6.2.1 in David Jaz Myers,
*Orbifolds as microlinear types in synthetic differential cohesive homotopy
type theory*, arXiv:2205.15887v1:
https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm1

The quantifier order is significant: `A` is one fixed proposition, while
`B` may vary over `K`.  This declaration introduces no axioms.  Later closure
proofs use intuitionistic reasoning with an explicit `DPCompact` hypothesis.

Lean's ambient logic admits classical reasoning; this definition alone
therefore does not model the paper's constructive cohesive internal language.
In particular, no smooth-real compactness or sheaf-model claim is made here.
-/

namespace Orbifolds.External.Compactness

universe u

/-- A fixed disjunction distributes through universal quantification over `K`.
    This is the literal logical formula of Definition 6.2.1, externally encoded. -/
def DPCompact (K : Sort u) : Prop :=
  ∀ (A : Prop) (B : K → Prop),
    (∀ k : K, A ∨ B k) → A ∨ ∀ k : K, B k

end Orbifolds.External.Compactness
