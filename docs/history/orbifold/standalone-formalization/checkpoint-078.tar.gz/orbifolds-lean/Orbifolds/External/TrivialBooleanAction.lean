import Orbifolds.External.BooleanGroup
import Orbifolds.External.Action

namespace Orbifolds.External

/-- The two-element group acting on a single point. Its action groupoid will
retain two arrows at that point, illustrating ordinary isotropy. -/
def trivialBooleanAction : Action booleanGroup Unit where
  act _ _ := ()
  one_act x := by cases x; rfl
  mul_act _ _ _ := rfl

end Orbifolds.External
