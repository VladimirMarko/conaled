import Orbifolds.External.Groupoid

/-!
# Inertia of an ordinary groupoid

The ordinary groupoid counterpart of Definition 6.4.3 in arXiv:2205.15887,
supporting the finiteness component of Corollary 6.4.4.
Objects are pairs of an object and its automorphism. Arrows are original
arrows commuting with the two automorphisms. All groupoid laws are proved.
This does not construct a free loop type inside cohesive HoTT, and makes no
assertion of microlinearity or the existence of a semantic interpretation.
-/

set_option autoImplicit false
universe u v
namespace Orbifolds.External

/-- The ordinary inertia groupoid, with commuting arrows stored as data. -/
def GroupoidData.inertia {X : Type u} (C : GroupoidData.{u, v} X) :
    GroupoidData (Σ x : X, C.Hom x x) where
  Hom a b := {f : C.Hom a.1 b.1 // C.comp f a.2 = C.comp b.2 f}
  id a := ⟨C.id a.1, (C.id_comp a.2).trans (C.comp_id a.2).symm⟩
  comp {a} {b} {c} g f := ⟨C.comp g.val f.val, by
    calc
      C.comp (C.comp g.val f.val) a.2 = C.comp g.val (C.comp f.val a.2) :=
        (C.comp_assoc g.val f.val a.2).symm
      _ = C.comp g.val (C.comp b.2 f.val) :=
        congrArg (fun t => C.comp g.val t) f.property
      _ = C.comp (C.comp g.val b.2) f.val := C.comp_assoc g.val b.2 f.val
      _ = C.comp (C.comp c.2 g.val) f.val :=
        congrArg (fun t => C.comp t f.val) g.property
      _ = C.comp c.2 (C.comp g.val f.val) :=
        (C.comp_assoc c.2 g.val f.val).symm⟩
  inv {a} {b} f := ⟨C.inv f.val, by
    calc
      C.comp (C.inv f.val) b.2 =
          C.comp (C.inv f.val) (C.comp b.2 (C.id b.1)) :=
        congrArg (fun t => C.comp (C.inv f.val) t) (C.comp_id b.2).symm
      _ = C.comp (C.inv f.val) (C.comp b.2 (C.comp f.val (C.inv f.val))) :=
        congrArg (fun t => C.comp (C.inv f.val) (C.comp b.2 t)) (C.comp_inv f.val).symm
      _ = C.comp (C.inv f.val) (C.comp (C.comp b.2 f.val) (C.inv f.val)) :=
        congrArg (fun t => C.comp (C.inv f.val) t) (C.comp_assoc b.2 f.val (C.inv f.val))
      _ = C.comp (C.inv f.val) (C.comp (C.comp f.val a.2) (C.inv f.val)) :=
        congrArg (fun t => C.comp (C.inv f.val) (C.comp t (C.inv f.val))) f.property.symm
      _ = C.comp (C.comp (C.inv f.val) (C.comp f.val a.2)) (C.inv f.val) :=
        C.comp_assoc (C.inv f.val) (C.comp f.val a.2) (C.inv f.val)
      _ = C.comp (C.comp (C.comp (C.inv f.val) f.val) a.2) (C.inv f.val) :=
        congrArg (fun t => C.comp t (C.inv f.val)) (C.comp_assoc (C.inv f.val) f.val a.2)
      _ = C.comp (C.comp (C.id a.1) a.2) (C.inv f.val) :=
        congrArg (fun t => C.comp (C.comp t a.2) (C.inv f.val)) (C.inv_comp f.val)
      _ = C.comp a.2 (C.inv f.val) :=
        congrArg (fun t => C.comp t (C.inv f.val)) (C.id_comp a.2)⟩
  id_comp f := Subtype.ext (C.id_comp f.val)
  comp_id f := Subtype.ext (C.comp_id f.val)
  comp_assoc h g f := Subtype.ext (C.comp_assoc h.val g.val f.val)
  inv_comp f := Subtype.ext (C.inv_comp f.val)
  comp_inv f := Subtype.ext (C.comp_inv f.val)

end Orbifolds.External
