import Orbifolds.External.Action
import Orbifolds.External.Groupoid

/-!
# The ordinary action groupoid

This is the external ordinary groupoid counterpart of the arrow description
in Lemma 2.3.2 of arXiv:2205.15887v1. Its loops have the stabilizer subtype
described in Corollary 2.3.3 by definition. This construction proves all of the
ordinary groupoid laws; it does not assert the paper's equivalence concerning
identifications in a homotopy quotient.
-/

namespace Orbifolds.External

universe u v

/-- The action groupoid has an arrow for each group element carrying its
source to its target. Composition retains the witnessing group element. -/
def Action.groupoid {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) : GroupoidData X where
  Hom x y := {g : G // A.act g x = y}
  id x := ⟨S.one, A.one_act x⟩
  comp {x} {y} {z} g f := ⟨S.mul g.val f.val, by
    calc
      A.act (S.mul g.val f.val) x = A.act g.val (A.act f.val x) :=
        A.mul_act g.val f.val x
      _ = A.act g.val y := congrArg (A.act g.val) f.property
      _ = z := g.property⟩
  inv {x} {y} f := ⟨S.inv f.val, by
    calc
      A.act (S.inv f.val) y = A.act (S.inv f.val) (A.act f.val x) :=
        congrArg (A.act (S.inv f.val)) f.property.symm
      _ = A.act (S.mul (S.inv f.val) f.val) x :=
        (A.mul_act (S.inv f.val) f.val x).symm
      _ = A.act S.one x :=
        congrArg (fun g => A.act g x) (S.inv_mul f.val)
      _ = x := A.one_act x⟩
  id_comp f := Subtype.eq (S.one_mul f.val)
  comp_id f := Subtype.eq (S.mul_one f.val)
  comp_assoc h g f := Subtype.eq (S.mul_assoc h.val g.val f.val).symm
  inv_comp f := Subtype.eq (S.inv_mul f.val)
  comp_inv f := Subtype.eq (S.mul_inv f.val)

end Orbifolds.External
