import Orbifolds.External.Compactness.ProperFibers

/-!
# Pullback stability of DP-proper maps

This is the remaining assertion of Proposition 6.2.4 in David Jaz Myers,
arXiv:2205.15887v1. A pullback is represented by an ordinary subtype of a
product, with the equality of its two images supplied as a field. The map
on each fiber has an explicit preimage witness. No cohesive or homotopy
pullback semantics are claimed by this external theorem.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4
-/

namespace Orbifolds.External.Compactness

universe u v w

theorem dpProper_pullback {X : Type u} {Y : Type v} {Z : Type w}
    {f : X → Y} (hf : DPProper f) (g : Z → Y) :
    DPProper (fun p : {zx : Z × X // g zx.1 = f zx.2} => p.val.1) := by
  apply (dpProper_iff_fibers _).mpr
  intro z
  let q : {x : X // f x = g z} →
      {p : {zx : Z × X // g zx.1 = f zx.2} // p.val.1 = z} :=
    fun x => ⟨⟨⟨z, x.val⟩, x.property.symm⟩, rfl⟩
  have hCompact := (dpProper_iff_fibers f).mp hf (g z)
  apply dpCompact_surjective q hCompact
  intro p
  cases p with
  | mk p hz =>
    cases p with
    | mk zx hzx =>
      cases zx with
      | mk z' x =>
        change z' = z at hz
        cases hz
        exact ⟨⟨x, hzx.symm⟩, rfl⟩

end Orbifolds.External.Compactness
