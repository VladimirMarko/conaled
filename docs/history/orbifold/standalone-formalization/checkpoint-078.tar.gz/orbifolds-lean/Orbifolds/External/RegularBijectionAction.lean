import Orbifolds.External.RegularTorsor
import Orbifolds.External.RegularMapAction
import Orbifolds.External.EquivariantBijection

namespace Orbifolds.External

universe u v

/-- Right multiplication acts by precomposition on equivariant bijections
out of the regular action. This action retains the bijectivity proofs. -/
def Action.regularBijectionAction {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) : Action S (EquivariantBijection S.regularAction A) where
  act g f := ⟨fun k => f.val (S.mul k g),
    ⟨(A.regularMapAction.act g ⟨f.val, f.property.1⟩).property,
      Function.Injective.comp f.property.2.1 (S.regularAction_isTorsor.2 g).1,
      Function.Surjective.comp f.property.2.2 (S.regularAction_isTorsor.2 g).2⟩⟩
  one_act f := Subtype.eq (funext (fun k => congrArg f.val (S.mul_one k)))
  mul_act g h f :=
    Subtype.eq (funext (fun k => congrArg f.val (S.mul_assoc k g h).symm))

end Orbifolds.External
