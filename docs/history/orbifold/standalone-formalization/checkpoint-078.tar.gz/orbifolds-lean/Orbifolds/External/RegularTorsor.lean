import Orbifolds.External.RegularAction
import Orbifolds.External.Torsor

namespace Orbifolds.External

universe u

/-- The ordinary regular action is a torsor. -/
theorem GroupData.regularAction_isTorsor {G : Type u} (S : GroupData G) :
    S.regularAction.IsTorsor := by
  refine ⟨⟨S.one⟩, ?_⟩
  intro x
  constructor
  · intro g h e
    change S.mul g x = S.mul h x at e
    calc
      g = S.mul (S.mul g x) (S.inv x) := by
        symm
        calc
          S.mul (S.mul g x) (S.inv x) = S.mul g (S.mul x (S.inv x)) :=
            S.mul_assoc g x (S.inv x)
          _ = S.mul g S.one := congrArg (S.mul g) (S.mul_inv x)
          _ = g := S.mul_one g
      _ = S.mul (S.mul h x) (S.inv x) :=
        congrArg (fun k => S.mul k (S.inv x)) e
      _ = S.mul h (S.mul x (S.inv x)) := S.mul_assoc h x (S.inv x)
      _ = S.mul h S.one := congrArg (S.mul h) (S.mul_inv x)
      _ = h := S.mul_one h
  · intro y
    refine ⟨S.mul y (S.inv x), ?_⟩
    change S.mul (S.mul y (S.inv x)) x = y
    calc
      S.mul (S.mul y (S.inv x)) x = S.mul y (S.mul (S.inv x) x) :=
        S.mul_assoc y (S.inv x) x
      _ = S.mul y S.one := congrArg (S.mul y) (S.inv_mul x)
      _ = y := S.mul_one y

end Orbifolds.External
