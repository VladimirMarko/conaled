import Std

/-!
# External logical predicates for Penon openness and closedness

These are the two quantified predicates of Definition 6.2.6 in David Jaz
Myers, *Orbifolds as microlinear types in synthetic differential cohesive
homotopy type theory*, arXiv:2205.15887v1.

Source: https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm6

They use ordinary Lean propositions and equality. This file does not provide
a model of the paper's cohesive type theory or its internal Penon topology.
-/

namespace Orbifolds.External.Compactness

universe u

/-- A point in `U` can be distinguished from any other point, or that point
also belongs to `U`. -/
def PenonOpen {X : Sort u} (U : X → Prop) : Prop :=
  ∀ x : X, U x → ∀ y : X, x ≠ y ∨ U y

/-- A predicate is Penon closed when its complement is Penon open. -/
def PenonClosed {X : Sort u} (K : X → Prop) : Prop :=
  PenonOpen (fun x => ¬ K x)

end Orbifolds.External.Compactness
