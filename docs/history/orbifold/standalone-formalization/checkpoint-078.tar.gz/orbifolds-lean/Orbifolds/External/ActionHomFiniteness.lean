import Orbifolds.External.ActionGroupoid
import Orbifolds.Finiteness.SubfiniteProper

/-!
# Proper finiteness of ordinary action-groupoid arrows

This proves the external set-level finiteness component of the argument in
Theorem 6.4.1 of arXiv:2205.15887v1: arrows from `x` to `y` form a subtype of
the acting group. Here `ProperlyFinite` has the explicit ordinary set-level
meaning defined in `Orbifolds.Finiteness.Definitions`. No microlinearity,
cohesive discreteness, or synthetic orbifold conclusion is asserted.
-/

namespace Orbifolds.External

universe u v

/-- A subfinite ordinary acting group gives properly finite arrow types in
the ordinary action groupoid, including its stabilizer loops. -/
theorem Action.homs_properlyFinite {G : Type u} {S : GroupData G} {X : Type v}
    (A : Action S X) (hG : Orbifolds.Finiteness.Subfinite G) (x y : X) :
    Orbifolds.Finiteness.ProperlyFinite (A.groupoid.Hom x y) := by
  apply Orbifolds.Finiteness.subfinite_properlyFinite
  obtain ⟨n, e, he⟩ := hG
  refine ⟨n, (fun f => e f.val), ?_⟩
  intro f g h
  exact Subtype.eq (he h)

end Orbifolds.External
