import Orbifolds.External.GroupData

namespace Orbifolds.External

/-- The ordinary two-element group, represented by Boolean exclusive-or. -/
def booleanGroup : GroupData Bool where
  one := false
  mul := Bool.xor
  inv := id
  mul_assoc := by decide
  one_mul := by decide
  mul_one := by decide
  inv_mul := by decide
  mul_inv := by decide

end Orbifolds.External
