import Std

/-!
# A native classical carrier cannot satisfy Kock and Kock--Lawvere

The first-order Kock--Lawvere property says that every map from the
square-zero infinitesimals to the smooth line has a unique affine slope.
Myers, arXiv:2205.15887, discusses this consequence on pages 5 and 28;
the Kock field property and general Kock--Lawvere postulate appear in
Axiom 3 on pages 29--30.

Here the carrier, its infinitesimals, and ALL functions between them are
native Lean types and functions. With classical logic, even the minimal
algebraic fragment stated below makes that interpretation impossible.
All algebraic and Kock--Lawvere assumptions are local hypotheses of an
impossibility theorem. No model, new axiom, or synthetic theorem is
postulated.

This does not contradict synthetic differential geometry in an internal
intuitionistic logic: its smooth line and internal maps must instead be
interpreted as objects and morphisms in a suitable semantic category.
-/

set_option autoImplicit false

universe u

namespace Orbifolds.Foundations

/--
There is no nontrivial native classical carrier satisfying the listed
algebraic laws, the one-variable Kock field property, and the first-order
Kock--Lawvere property for all native maps on its square-zero elements.

The last hypothesis spells out existence and uniqueness of an affine
slope: `b` is a slope for `f`, and every other slope `c` equals `b`.
Its distinguished zero infinitesimal is justified by `zero_mul zero`.
-/
theorem noNativeClassicalKockLawvereCarrier
    (R : Type u)
    (zero one : R)
    (add mul : R → R → R)
    (zero_ne_one : zero ≠ one)
    (add_zero : ∀ x : R, add x zero = x)
    (mul_zero : ∀ x : R, mul x zero = zero)
    (zero_mul : ∀ x : R, mul zero x = zero)
    (mul_one : ∀ x : R, mul x one = x)
    (mul_assoc : ∀ x y z : R, mul (mul x y) z = mul x (mul y z))
    (kock : ∀ x : R, x ≠ zero → ∃ y : R, mul x y = one)
    (kl : ∀ f : {d : R // mul d d = zero} → R,
      ∃ b : R,
        (∀ d, f d = add (f ⟨zero, zero_mul zero⟩) (mul b d.val)) ∧
        ∀ c : R,
          (∀ d, f d = add (f ⟨zero, zero_mul zero⟩) (mul c d.val)) →
          c = b) :
    False := by
  classical
  have nilsquare_eq_zero (d : R) (hd : mul d d = zero) : d = zero := by
    by_cases hz : d = zero
    · exact hz
    · obtain ⟨i, hi⟩ := kock d hz
      calc
        d = mul d one := (mul_one d).symm
        _ = mul d (mul d i) := congrArg (mul d) hi.symm
        _ = mul (mul d d) i := (mul_assoc d d i).symm
        _ = mul zero i := congrArg (fun z : R => mul z i) hd
        _ = zero := zero_mul i
  obtain ⟨slope, _, uniqueSlope⟩ := kl (fun _ => zero)
  have everySlope (c : R) :
      ∀ d : {d : R // mul d d = zero},
        zero = add zero (mul c d.val) := by
    intro d
    rw [nilsquare_eq_zero d.val d.property, mul_zero c, add_zero zero]
  have zero_eq_slope : zero = slope := uniqueSlope zero (everySlope zero)
  have one_eq_slope : one = slope := uniqueSlope one (everySlope one)
  exact zero_ne_one (zero_eq_slope.trans one_eq_slope.symm)

end Orbifolds.Foundations

#print axioms Orbifolds.Foundations.noNativeClassicalKockLawvereCarrier
