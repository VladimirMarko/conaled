import Std

/-!
# Boolean negation cannot be native equality transport

This is a concrete obstruction to reading the paper's univalent
identifications as native Lean equality. Boolean negation exchanges the
two Boolean values and is a bijection, whereas transport along any
native equality `Bool = Bool` fixes both values by proof irrelevance.

The theorem concerns native equality only. It places no restriction on
an explicit semantic representation of paths in a model of HoTT.

Reference: Lean Language Reference, "Propositional Equality":
https://lean-lang.org/doc/reference/latest/Basic-Propositions/Propositional-Equality/
-/

set_option autoImplicit false

namespace Orbifolds.Foundations

/-- Transport along a native self-equality of `Bool` cannot be negation. -/
theorem nativeBoolTransportCannotNegate (p : Bool = Bool) :
    (fun b : Bool => Eq.mp p b) ≠ Bool.not := by
  intro h
  have impossible : false = true := congrFun h false
  cases impossible

end Orbifolds.Foundations

#print axioms Orbifolds.Foundations.nativeBoolTransportCannotNegate
