import Std

/-!
# Native Lean equality has unique proofs

This is a guard for the formalization of Myers, arXiv:2205.15887.
The paper's homotopy-theoretic identification types must not be replaced
by native Lean equality: native equality is a proposition, and Lean has
definitional proof irrelevance. In particular, its self-identifications
cannot represent a nontrivial isotropy group.

Reference: Lean Language Reference, "Propositional Equality", section
"Uniqueness of Equality Proofs":
https://lean-lang.org/doc/reference/latest/Basic-Propositions/Propositional-Equality/
-/

set_option autoImplicit false

universe u

namespace Orbifolds.Foundations

/-- Any two proofs of one native Lean equality are equal. -/
theorem nativeEqUIP {α : Sort u} {x y : α} (p q : x = y) : p = q := rfl

end Orbifolds.Foundations

#print axioms Orbifolds.Foundations.nativeEqUIP
