import Lean
import Orbifolds

/-!
Exhaustive axiom audit of the imported project environment.

Run from the project using `lake env lean /absolute/path/to/FullAudit.lean`.
The JSON output includes every declaration whose user-visible name has the
`Orbifolds` prefix, and every declaration originating in an `Orbifolds` module.
This second criterion also includes private and generated declarations whose
kernel names do not begin with `Orbifolds`.

`Lean.collectAxioms` is the same transitive dependency collector used by
`#print axioms`. The imported kernel environment, rather than a manually
maintained list of theorem roots, supplies the declarations to inspect.
-/

open Lean Elab Command

set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let constants := env.checked.get.constants.toList.toArray
  let moduleOf := fun name =>
    match env.getModuleIdxFor? name with
    | some idx => env.header.moduleNames[idx.toNat]!
    | none => env.mainModule
  let hasProjectName := fun name => (`Orbifolds).isPrefixOf (privateToUserName name)
  let hasProjectModule := fun name => (`Orbifolds).isPrefixOf (moduleOf name)
  let project := (constants.filter fun (name, _) =>
    hasProjectName name || hasProjectModule name).qsort (fun a b => Name.lt a.1 b.1)
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut records : Array Json := #[]
  let mut unexpected : Array Json := #[]
  for (name, info) in project do
    let axioms ← collectAxioms name
    let bad := axioms.filter fun ax => !allowed.contains ax
    let kind := match info with
      | .axiomInfo _ => "axiom"
      | .defnInfo _ => "definition"
      | .thmInfo _ => "theorem"
      | .opaqueInfo _ => "opaque"
      | .quotInfo _ => "quotient_primitive"
      | .inductInfo _ => "inductive"
      | .ctorInfo _ => "constructor"
      | .recInfo _ => "recursor"
    records := records.push <| Json.mkObj [
      ("name", toJson name.toString),
      ("user_name", toJson (privateToUserName name).toString),
      ("module", toJson (moduleOf name).toString),
      ("kind", toJson kind),
      ("project_name", toJson (hasProjectName name)),
      ("project_module", toJson (hasProjectModule name)),
      ("unsafe", toJson info.isUnsafe),
      ("partial", toJson info.isPartial),
      ("axioms", toJson (axioms.map Name.toString))
    ]
    unless bad.isEmpty do
      unexpected := unexpected.push <| Json.mkObj [
        ("name", toJson name.toString),
        ("unexpected_axioms", toJson (bad.map Name.toString))
      ]
  let output := Json.mkObj [
    ("schema_version", toJson (1 : Nat)),
    ("lean_version", toJson Lean.versionString),
    ("lean_commit", toJson Lean.githash),
    ("environment_declarations", toJson constants.size),
    ("environment_theorem_declarations", toJson (constants.filter (fun p => p.2.isTheorem)).size),
    ("project_declarations", toJson project.size),
    ("project_theorem_declarations", toJson (project.filter (fun p => p.2.isTheorem)).size),
    ("project_modules", toJson ((env.header.moduleNames.filter fun n =>
      (`Orbifolds).isPrefixOf n).map Name.toString)),
    ("allowed_axioms", toJson (allowed.map Name.toString)),
    ("unexpected_dependencies", Json.arr unexpected),
    ("declarations", Json.arr records)
  ]
  liftIO <| IO.println output.pretty
  unless unexpected.isEmpty do
    throwError "Project declarations depend on axioms outside the permitted standard set"
