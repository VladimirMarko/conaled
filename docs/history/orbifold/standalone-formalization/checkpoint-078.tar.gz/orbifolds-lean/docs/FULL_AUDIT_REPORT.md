# Exhaustive Lean environment axiom audit

## Result and frozen scope

The audit passed for source checkpoint **073**. It inspected
**337 project declarations**, including **156 theorem
declarations**, and found **no project axioms and no dependency outside
`propext`, `Quot.sound`, and `Classical.choice`**.

The loaded environment contained 206981 declarations in total,
of which 89538 were theorem declarations. The project
contributed 69 imported modules, matching the 69
Lean source modules captured in the source manifest. The registered-results audit had
85 declaration roots. This exhaustive audit additionally inspected
252 declarations beyond those roots; those additional declarations
include generated code, projections, recursors, and intermediate proof declarations.

These counts are counts of Lean environment declarations, not claims about how many
numbered paper theorems have been formalized. In particular, generated theorem declarations
must not be counted as separately formalized paper results.

## Method

`FullAudit.lean` imports `Lean` and the complete `Orbifolds` aggregate module, then
enumerates constants from `env.checked.get.constants`. A declaration is included if
its user-facing name is in `Orbifolds`, or its defining module is an `Orbifolds`
module. Module ownership covers generated and private names that a prefix-only filter
could miss. Every registered result root is checked for presence in this enumeration.

For each included constant, the script invokes `Lean.collectAxioms`, the transitive
dependency collector also used by `#print axioms`. Lean 4.33.0-rc1 computes
and exports imported declarations' axiom dependency data when their modules are built;
the collector uses that data and traverses current-module bodies as appropriate.
The report also records each declaration's kind, module, safety flag, and partiality flag.

The runner holds the same checkpoint lock as the integration script, records SHA-256
digests of every project Lean source, and verifies those digests after the audit. It
does not edit the stable project. The exact command, timestamp, source checkpoint,
toolchain commit, and source hashes are retained in `full-audit-summary.json`.

## Declaration kinds

| Kind | Count |
| --- | ---: |
| constructor | 11 |
| definition | 148 |
| inductive | 11 |
| recursor | 11 |
| theorem | 156 |

## Transitive axiom dependency sets

| Axiom set | Project declarations |
| --- | ---: |
| Quot.sound | 16 |
| none | 293 |
| propext | 17 |
| propext, Classical.choice, Quot.sound | 3 |
| propext, Quot.sound | 8 |

These standard logical dependencies are reported transparently. `Classical.choice`
dependencies occur in explicitly classical supporting arguments; their presence does
not turn the paper's internal constructive theory into an implemented model. The audit
checks proof trust dependencies and does not establish source fidelity or fill missing
cohesive, univalent, differential, or higher-categorical foundations.

## Additional checks and exact evidence

- Project axiom declarations: 0.
- Unexpected transitive axiom dependencies: 0.
- Missing registered result roots: 0.
- Unsafe declarations: 0.
- Partial declarations: 0.
- Project-owned names outside the literal namespace prefix: 0.
- Lean toolchain: `4.33.0-rc1`, commit `62eed1db4d67327ec8120be05f1a1b0847d74561`.
- Audit script SHA-256: `71353f31f1757499508a07afe537b6b5149fa51e22650bced0c5616f02ac2357`.
- Captured stdout SHA-256: `956414c47e8de990fde97be0b9f1c5622b815fd309fd7aa1744103ae8d3bc9bc`.

`full-audit.json` gives every inspected declaration and its exact axiom set.
`full-audit.stdout.log` and `full-audit.stderr.log` preserve the actual Lean process
output. `full-audit-summary.json` gives counts and the frozen source manifest.

## Primary implementation references

- Lean distribution source: `Lean/Util/CollectAxioms.lean`, including `collectAxioms`
  and the exported-axiom persistent environment extension.
- Lean distribution source: `Lean/Elab/Print.lean`, where `#print axioms` uses the
  same collector.
- Lean distribution source: `Lean/Environment.lean`, kernel constants and
  `getModuleIdxFor?`.

## Reproduce from the delivered source archive

Run `lake build`, then `lake env lean FullAudit.lean` in the extracted project.
The archived captured results are in `verification/exhaustive_audit/`. The
source-checkpoint and workspace paths in the captured summary identify the
original audit process; the direct command above is portable. The capture
runner was temporary orchestration, and the complete Lean auditor is supplied
as `FullAudit.lean`.
