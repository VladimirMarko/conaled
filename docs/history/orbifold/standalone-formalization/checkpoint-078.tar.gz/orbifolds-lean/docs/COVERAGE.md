# Paper-to-Lean coverage

The full 199-item inventory is in `paper_inventory.md` and `.json`. This file records exactly where checked external mathematics relates to that inventory. It does not claim a completed internal cohesive HoTT theorem.

There are 27 explicit item mappings below. A mapping can be a definition, a fragment, generic support, or a counterexample; it is not a theorem count. Every unmapped item remains open in this development.

## Scope map

| Paper item | Checked scope | Remaining boundary |
| --- | --- | --- |
| [Definition 2.1.2](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm2) | ordinary support (checkpoints 003) | Ordinary group operations and laws only; pointed connected deloopings are not implemented. |
| [Proposition 2.1.3](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm3) | ordinary support (checkpoints 052, 062) | The ordinary torsor predicate and regular torsor are constructed; the univalent delooping theorem is not proved. |
| [Lemma 2.1.13](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm13) | ordinary counterpart proved (checkpoints 039, 042, 045, 048, 052, 056, 059, 062, 065, 068, 071, 072) | Evaluation at the identity is an explicitly invertible, equivariant map between ordinary torsors. Identifications in a univalent torsor universe are not constructed. |
| [Definition 2.2.4](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm4) | ordinary support (checkpoints 007) | Ordinary group actions with proved laws; no pointed map between deloopings is asserted. |
| [Lemma 2.3.2](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm2) | ordinary counterpart constructed (checkpoints 016) | The action groupoid stores an arrow for each group element carrying the source to the target, with every groupoid law proved. No HoTT quotient identity-space equivalence is proved. |
| [Corollary 2.3.3](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm3) | ordinary counterpart constructed (checkpoints 030, 032) | Automorphism arrows form a group, and action-groupoid loops give the stabilizer group. A native equality proof is not used as an arrow. |
| [Axiom 3](https://arxiv.org/html/2205.15887v1#Thmaxiom3) | invalid interpretation excluded (checkpoints 009) | A local-hypothesis theorem refutes the proposed classical native carrier with the stated Kock and first-order Kock-Lawvere conditions. It does not refute internal SDG or postulate a model. |
| [Lemma 4.3.10](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm10) | categorical support (checkpoints 015) | Ordinary unique-extension and orthogonality definitions are available. No equivalence with internal microlinearity is proved. |
| [Proposition 5.0.1](https://arxiv.org/html/2205.15887v1#S5.SS0.Thmthm1) | categorical support (checkpoints 020, 027, 029) | Ordinary hom-set orthogonality is closed under binary products, pullbacks, and retracts. Arbitrary homotopy limits, exponentiation, and the semantic microlinearity bridge remain open. |
| [Definition 6.1.1](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm1) | external definitions (checkpoints 006) | Four native finiteness predicates are defined by finite ordinals, injections, and surjections. These are not interpreted internal cohesive predicates. |
| [Definition 6.1.3](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm3) | external definitions (checkpoints 006) | Proper finiteness is subfinite enumerability plus proposition-valued decidable equality. Its identification with cohesive discreteness is not proved. |
| [Lemma 6.1.5](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm5) | external constructive implication proved (checkpoints 028) | Subfinite ordinary types are properly finite. The finite case follows by forgetting the surjectivity component of a finite witness. |
| [Proposition 6.1.7](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7) | printed statement refuted; corrected counterpart proved (checkpoints 008, 014, 019, 023, 026, 060) | The printed uniqueness direction has a checked Nat counterexample. With at most one source point per finite label, the characterization and association-transfer assertion are proved constructively. |
| [Lemma 6.1.8](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm8) | external constructive counterpart proved (checkpoints 066) | Subfinite enumerability is equivalent to embedding into a finitely enumerable ordinary type. The quotient and separating predicate invariant avoid selecting preimages. |
| [Proposition 6.1.9](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9) | all six external constructive clauses proved (checkpoints 034, 035, 040, 043, 046, 049, 050, 053, 054, 057, 058, 070) | Subobjects, binary products, pullbacks, Fin-indexed dependent disjoint unions, images into decidable-equality types, and Fin-indexed unions in such a type are covered. Source relation arguments are explicitly corrected. |
| [Definition 6.2.1](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm1) | external definitions (checkpoints 012, 051) | The native logical DP-compactness and inverse-image properness formulas are defined. Native classical logic makes this compactness formula true of every native type, so no geometric-model claim is made. |
| [Lemma 6.2.2](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2) | all three external constructive clauses proved (checkpoints 017, 021, 024, 031) | Finitely enumerable types are DP compact; surjections preserve compactness; compact binary sums have compact summands, for the specified native formulas. |
| [Warning 6.2.3](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm3) | external equivalence proved (checkpoints 033) | A proposition is DP compact exactly when it is decidable. No undecidable native proposition or internal counterexample is exhibited. |
| [Proposition 6.2.4](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4) | both external constructive clauses proved (checkpoints 055, 061) | DP properness is equivalent to compact native equality fibers and is stable under native subtype pullback. The source base-change codomain is corrected to the target. |
| [Proposition 6.2.5](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm5) | external constructive counterpart proved (checkpoints 013, 064) | A dependent sum with compact base and compact fibers is DP compact; binary products are also explicit. |
| [Definition 6.2.6](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm6) | external definitions (checkpoints 038) | Native logical predicates for Penon openness and closedness are defined. |
| [Lemma 6.2.9](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm9) | external constructive counterpart proved (checkpoints 041) | Products of Penon-open native predicates are Penon open. |
| [Proposition 6.2.17](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm17) | external constructive counterpart proved (checkpoints 044, 047) | A DP-compact native subtype of a DP-separated type is Penon closed, with separatedness an explicit hypothesis. |
| [Lemma 6.2.21](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm21) | combinatorial step proved (checkpoints 063) | A supplied subsingleton cover with subfinitely enumerable index gives proper finiteness when the ambient type has decidable equality. The geometric construction of the cover and all manifold hypotheses remain open. |
| [Theorem 6.4.1](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm1) | ordinary arrow-finiteness step proved (checkpoints 036) | An ordinary action of a subfinite group has properly finite action-groupoid arrow types. Microlinearity, crisp discreteness, and the full quotient orbifold theorem remain open. |
| [Definition 6.4.3](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm3) | ordinary counterpart constructed (checkpoints 067) | The inertia groupoid has object-automorphism pairs and commuting arrows, with all groupoid laws proved. A free homotopy-loop type is not constructed. |
| [Corollary 6.4.4](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm4) | ordinary arrow-finiteness step proved (checkpoints 069) | Inertia preserves proper finiteness of explicit groupoid arrows. The internal inertia identification and microlinearity conclusion remain open. |

## Exact declaration index

Namespaces below are the names accepted by Lean. `COVERAGE.json` contains the same machine-readable map. A supporting checkpoint may supply definitions shared by several paper items.

### Definition 2.1.2

- `Orbifolds.External.GroupData`

### Proposition 2.1.3

- `Orbifolds.External.Action.IsTorsor`
- `Orbifolds.External.GroupData.regularAction_isTorsor`

### Lemma 2.1.13

- `Orbifolds.External.TypeIso`
- `Orbifolds.External.GroupData.regularAction`
- `Orbifolds.External.EquivariantMap`
- `Orbifolds.External.Action.regularEvaluationIso`
- `Orbifolds.External.Action.IsTorsor`
- `Orbifolds.External.EquivariantBijection`
- `Orbifolds.External.Action.torsorEvaluationIso`
- `Orbifolds.External.GroupData.regularAction_isTorsor`
- `Orbifolds.External.Action.regularMapAction`
- `Orbifolds.External.Action.regularBijectionAction`
- `Orbifolds.External.Action.torsorEvaluation_equivariant`
- `Orbifolds.External.Action.regularBijectionAction_isTorsor`

### Definition 2.2.4

- `Orbifolds.External.Action`

### Lemma 2.3.2

- `Orbifolds.External.Action.groupoid`

### Corollary 2.3.3

- `Orbifolds.External.GroupoidData.automorphismGroup`
- `Orbifolds.External.Action.stabilizerGroup`

### Axiom 3

- `Orbifolds.Foundations.noNativeClassicalKockLawvereCarrier`

### Lemma 4.3.10

- `Orbifolds.Category.Cat`
- `Orbifolds.Category.Probe`
- `Orbifolds.Category.HasUniqueExtension`
- `Orbifolds.Category.Orthogonal`
- `Orbifolds.Category.LocalFor`

### Proposition 5.0.1

- `Orbifolds.Category.BinaryProduct`
- `Orbifolds.Category.orthogonal_binaryProduct`
- `Orbifolds.Category.Pullback`
- `Orbifolds.Category.orthogonal_pullback`
- `Orbifolds.Category.Retract`
- `Orbifolds.Category.orthogonal_retract`

### Definition 6.1.1

- `Orbifolds.Finiteness.Finite`
- `Orbifolds.Finiteness.Subfinite`
- `Orbifolds.Finiteness.FinitelyEnumerable`
- `Orbifolds.Finiteness.SubfinitelyEnumerable`

### Definition 6.1.3

- `Orbifolds.Finiteness.HasDecidableEquality`
- `Orbifolds.Finiteness.ProperlyFinite`

### Lemma 6.1.5

- `Orbifolds.Finiteness.subfinite_properlyFinite`

### Proposition 6.1.7

- `Orbifolds.Finiteness.everyTypeHasPrintedAssociation`
- `Orbifolds.Finiteness.subfinitelyEnumerable_iff_association`
- `Orbifolds.Finiteness.finiteNatFamilyBounded`
- `Orbifolds.Finiteness.nat_not_subfinitelyEnumerable`
- `Orbifolds.Finiteness.printedAssociation_nat_counterexample`
- `Orbifolds.Finiteness.subfinitelyEnumerable_of_association`

### Lemma 6.1.8

- `Orbifolds.Finiteness.subfinitelyEnumerable_iff_embeds_finitelyEnumerable`

### Proposition 6.1.9

- `Orbifolds.Finiteness.subfinitelyEnumerable_of_injective`
- `Orbifolds.Finiteness.properlyFinite_of_injective`
- `Orbifolds.Finiteness.finPair`
- `Orbifolds.Finiteness.finPair_injective`
- `Orbifolds.Finiteness.subfinitelyEnumerable_of_surjective`
- `Orbifolds.Finiteness.properlyFinite_product`
- `Orbifolds.Finiteness.properlyFinite_pullback`
- `Orbifolds.Finiteness.finSum`
- `Orbifolds.Finiteness.finSum_injective`
- `Orbifolds.Finiteness.properlyFinite_image`
- `Orbifolds.Finiteness.properlyFinite_sum`
- `Orbifolds.Finiteness.properlyFinite_union`
- `Orbifolds.Finiteness.properlyFinite_finSigma`
- `Orbifolds.Finiteness.properlyFinite_finUnion`

### Definition 6.2.1

- `Orbifolds.External.Compactness.DPCompact`
- `Orbifolds.External.Compactness.DPProper`

### Lemma 6.2.2

- `Orbifolds.External.Compactness.dpCompact_surjective`
- `Orbifolds.External.Compactness.dpCompact_fin`
- `Orbifolds.External.Compactness.dpCompact_finitelyEnumerable`
- `Orbifolds.External.Compactness.dpCompact_sum_summands`

### Warning 6.2.3

- `Orbifolds.External.Compactness.dpCompact_prop_iff_decidable`

### Proposition 6.2.4

- `Orbifolds.External.Compactness.dpProper_iff_fibers`
- `Orbifolds.External.Compactness.dpProper_pullback`

### Proposition 6.2.5

- `Orbifolds.External.Compactness.dpCompact_sigma`
- `Orbifolds.External.Compactness.dpCompact_product`

### Definition 6.2.6

- `Orbifolds.External.Compactness.PenonOpen`
- `Orbifolds.External.Compactness.PenonClosed`

### Lemma 6.2.9

- `Orbifolds.External.Compactness.penonOpen_product`

### Proposition 6.2.17

- `Orbifolds.External.Compactness.DPSeparated`
- `Orbifolds.External.Compactness.dpCompact_penonClosed`

### Lemma 6.2.21

- `Orbifolds.Finiteness.properlyFinite_of_subsingleton_cover`

### Theorem 6.4.1

- `Orbifolds.External.Action.homs_properlyFinite`

### Definition 6.4.3

- `Orbifolds.External.GroupoidData.inertia`

### Corollary 6.4.4

- `Orbifolds.External.GroupoidData.inertia_homs_properlyFinite`

## Additional checked support

Native equality and Boolean transport guards prevent an invalid identity-space translation. The concrete Boolean action groupoid has two distinct automorphisms of its sole object. These supporting results are listed in `RESULTS.json`; the Boolean example is not represented as one of the paper's unproved smooth examples.

## Main theorem remains open

Theorem 6.3.7 needs the microlinearity result 5.4.9, the discreteness result 6.3.4, and the geometric compactness-to-finiteness result 6.2.21. None of these complete internal results is proved here. The supplied-cover finiteness step does not replace the geometric hypotheses or their derivation.
