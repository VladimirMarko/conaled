# Complete paper inventory

Orbifolds as microlinear types in synthetic differential cohesive homotopy type theory

Primary sources: [arXiv HTML](https://arxiv.org/html/2205.15887v1) and [arXiv PDF](https://arxiv.org/pdf/2205.15887).

Complete census and original summaries of all 199 numbered items; all sections and Appendix A read.

**The status column refers to each complete internal paper item, all of which remain `not_formalized` here.** Checked external counterparts, fragments, categorical support, and the source counterexample are mapped explicitly in [COVERAGE.md](COVERAGE.md) and [COVERAGE.json](COVERAGE.json); the JSON inventory also records those mappings per entry. All summaries are original paraphrases. Remarks and warnings are included because some contain substantive claims.

## Foundational scope

The paper works internally in constructive, univalent homotopy type theory, augmented by a crisp context calculus, cohesive modalities, localizations, synthetic differential geometry, and tiny types. Its higher identities and mapping types cannot be identified with ordinary Lean `Eq` and unrestricted Lean function spaces. A faithful Lean development must model the relevant internal language or a suitable semantic category.

## Confirmed high-impact source error

Proposition 6.1.7 prints a relation condition that is functional from X into a finite ordinal. The constant relation to a singleton satisfies those printed conditions for every X, so the printed characterization cannot imply subfinite enumerability. The proof needs the opposite uniqueness condition: each finite index relates to at most one x. This wording is confirmed in the original PDF extraction, lines 3037–3042 (PDF page index 53, printed page 54), as well as the HTML. A corrected theorem must be labeled as a repair, and the printed version must not be admitted as an axiom.

## Census

| Kind | Number of numbered items |
|---|---:|
| Informal Definition | 1 |
| Definition | 45 |
| Remark | 26 |
| Theorem | 26 |
| Proposition | 22 |
| Example | 15 |
| Lemma | 42 |
| Corollary | 10 |
| Axiom | 5 |
| Warning | 7 |

The 199 entries are numbered environments, not a theorem count. Some contain several separate claims, definitions, or examples; some remarks record open questions. Formalization coverage must track their subclaims as well.

## Additional unnumbered foundations

- Constructive univalent homotopy type theory with function extensionality, propositional and higher truncations, dependent sums, homotopy pushouts, sequential colimits, and suitable localization constructors.
- Crisp context rules and flat induction/computation; codiscrete sharp modality used in section 5.2.
- Infinitesimal inverse function theorem assumed separately in Corollary 5.2.12.
- External cited results on modalities, orthogonal factorization, coverings, Yoneda/Rezk completion, join construction, and sequential localization.

## Main dependency structure

The central orbifold theorem 6.3.7 combines microlinearity of crisp etale groupoids (5.4.9) with finite identity types obtained from crystalline discreteness (6.3.4) and compactness-to-proper-finiteness (6.2.21). The microlinearity branch uses descent (4.3.13), modal etale descent (5.4.7), and tiny-type colimit preservation (5.4.8, A.0.9). The finiteness branch uses the corrected relation characterization (6.1.7), Penon compactness and covers (6.2.8, 6.2.13, 6.2.14), and ordinary manifold local structure.

Section 2 action and torsor algebra, the logical distribution proofs in 6.2, and the algebraic part of finite-ordinal closure can be developed independently as external fragments in Lean. They do not by themselves establish the cohesive higher-type theorems. The paper itself leaves general microlinearity of deloopings open (5.5.4).

## Numbered items


### Section 1.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Informal Definition 1.1.1](https://arxiv.org/html/2205.15887v1#S1.SS1.Thmthm1) | `not_formalized` | Smooth space whose points have finite isotropy groups. **Notes:** Informal motivation. |
| [Definition 1.1.2](https://arxiv.org/html/2205.15887v1#S1.SS1.Thmthm2) | `not_formalized` | Microlinear type with properly finite identity types between all pairs of points. **Depends on:** Definition 4.2.12, Definition 6.1.3. |

### Section 1.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Remark 1.3.1](https://arxiv.org/html/2205.15887v1#S1.SS3.Thmthm1) | `not_formalized` | Ordinary finiteness of isotropy would make the inertia projection a covering with locally constant isotropy cardinality. **Depends on:** Modal covering theory. |

### Section 2.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Theorem 2.1.1](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm1) | `not_formalized` | A pointed map between connected types is an equivalence exactly when its induced loop map is an equivalence. **Depends on:** Identity types, connectedness, fibers. |
| [Definition 2.1.2](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm2) | `not_formalized` | Higher group specified by a pointed connected delooping; n-groups have n-truncated deloopings. **Notes:** Requires homotopical identity types. |
| [Proposition 2.1.3](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm3) | `not_formalized` | The type of inhabited free transitive actions of an ordinary group is its delooping. **Depends on:** Univalence, group actions. |
| [Definition 2.1.4](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm4) | `not_formalized` | Elements of a delooping are exemplars; its chosen base point is the canonical exemplar. **Notes:** Terminology. |
| [Definition 2.1.5](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm5) | `not_formalized` | The connected component of x in X deloops the automorphism type of x. **Depends on:** Propositional truncation, identity types. |
| [Example 2.1.6](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm6) | `not_formalized` | The type of n-element sets deloops the symmetric group. **Depends on:** Definition 2.1.5, univalence. |
| [Example 2.1.7](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm7) | `not_formalized` | Finite dimensional Hermitian spaces provide deloopings of unitary groups. **Depends on:** Linear algebra, univalence. **Notes:** Displayed normalization formula appears to omit a square root; HTML confirmed, mathematical correction required. |
| [Example 2.1.8](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm8) | `not_formalized` | Appropriately structured real vector spaces provide deloopings of GL, SL, O and symplectic groups. **Depends on:** Linear algebra, univalence. |
| [Example 2.1.9](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm9) | `not_formalized` | Affine spaces deloop additive vector groups; pairs of vector and affine spaces deloop full affine groups. **Depends on:** Torsors, affine spaces. |
| [Proposition 2.1.10](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm10) | `not_formalized` | The associated-torsor construction identifies any ordinary-group delooping with its torsor type. **Depends on:** Proposition 2.1.3, univalence. |
| [Remark 2.1.11](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm11) | `not_formalized` | Higher torsor analogues are discussed, with a general theory left undeveloped. **Notes:** Does not supply a general higher-torsor theorem. |
| [Remark 2.1.12](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm12) | `not_formalized` | For GL, associated torsors are frames, and associated principal bundles are frame bundles. **Depends on:** Proposition 2.1.10. |
| [Lemma 2.1.13](https://arxiv.org/html/2205.15887v1#S2.SS1.Thmthm13) | `not_formalized` | Equivariant identifications from the regular G-torsor to T correspond to points of T by evaluation at the identity. **Depends on:** Torsor freeness and transitivity, univalence. |

### Section 2.2

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 2.2.1](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm1) | `not_formalized` | A higher-group homomorphism is a pointed map between deloopings. **Depends on:** Definition 2.1.2. |
| [Proposition 2.2.2](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm2) | `not_formalized` | Extension of scalars on torsors deloops an ordinary-group homomorphism. **Depends on:** Balanced quotient, torsors, univalence. |
| [Example 2.2.3](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm3) | `not_formalized` | The fiber of a delooped surjective homomorphism deloops its kernel; determinant gives the SL example. **Depends on:** Proposition 2.2.2, fiber sequences. |
| [Definition 2.2.4](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm4) | `not_formalized` | An action is a pointed map from a delooping to the connected component of the acted-on object. **Depends on:** Definition 2.1.5, Definition 2.2.1. |
| [Lemma 2.2.5](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm5) | `not_formalized` | The action on a fiber is transport in its classifying family. **Depends on:** Identity elimination, transport. |
| [Proposition 2.2.6](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm6) | `not_formalized` | Twisting a set action by a torsor gives its delooped family. **Depends on:** Balanced quotient, univalence. |
| [Remark 2.2.7](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm7) | `not_formalized` | The chosen left torsor and left action conventions account for inverse elements in the tensor formula. **Depends on:** Proposition 2.2.6. |
| [Example 2.2.8](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm8) | `not_formalized` | The permutation representation sends a finite set F to the real vector space of functions on F. **Depends on:** Example 2.1.6. |
| [Example 2.2.9](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm9) | `not_formalized` | Cyclic rotations of the plane can be described through root-of-unity structures on Hermitian lines. **Depends on:** Example 2.1.7, Definition 2.2.10. |
| [Definition 2.2.10](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm10) | `not_formalized` | Cycles in a Hermitian line are intended to give exemplars for the group of nth roots of unity. **Depends on:** Hermitian lines, roots of unity. **Notes:** Listed conditions admit the empty subset; the following connectedness proof needs inhabitation or cardinality n. Confirmed omission in HTML. |
| [Definition 2.2.11](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm11) | `not_formalized` | A subgroup subtorsor is an invariant subset whose restricted action is inhabited, free and transitive. **Depends on:** Group actions. |
| [Lemma 2.2.12](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm12) | `not_formalized` | The stated transport operation on subtorsors sends T to the inverse translate by g. **Depends on:** Transport in predicate families. **Notes:** Action and inverse conventions need careful semantic review. |
| [Proposition 2.2.13](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm13) | `not_formalized` | A subgroup delooping is built from group exemplars equipped with subgroup subtorsors; projection deloops inclusion. **Depends on:** Proposition 2.1.10, Lemma 2.2.12. |

### Section 2.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 2.3.1](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm1) | `not_formalized` | The homotopy quotient is the dependent sum of the family over the group delooping. **Depends on:** Definition 2.2.4. |
| [Lemma 2.3.2](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm2) | `not_formalized` | Identifications between quotient images correspond to an element g and an identification g acting on x with y. **Depends on:** Lemma 2.2.5, identity type of a dependent sum. |
| [Corollary 2.3.3](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm3) | `not_formalized` | Automorphisms of a quotient point are its stabilizer. **Depends on:** Lemma 2.3.2. |
| [Remark 2.3.4](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm4) | `not_formalized` | Explains the relation of this dependent-sum construction to homotopy quotients. **Depends on:** Definition 2.3.1. |
| [Theorem 2.3.5](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm5) | `not_formalized` | A map equipped with G-torsor structures on its fibers is a homotopy quotient for an induced G-action. **Depends on:** Lemma 2.1.13, dependent-sum substitution. |

### Section 2.4

| Item | Status | Statement and dependencies |
|---|---|---|
| [Remark 2.4.1](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm1) | `not_formalized` | Relates forthcoming etale groupoids to ordinary orbifold presentations. **Depends on:** Definition 5.4.6, Theorem 6.3.7. |
| [Example 2.4.2](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm2) | `not_formalized` | The cyclic plane quotient presents an elliptic orbifold point of order n. **Depends on:** Example 2.2.9, Definition 2.3.1. |
| [Example 2.4.3](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm3) | `not_formalized` | Finite orthogonal quotient charts are encoded using Euclidean spaces, subgroup frame subtorsors and vectors. **Depends on:** Proposition 2.2.13, Remark 2.1.12. |
| [Example 2.4.4](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm4) | `not_formalized` | Unordered n-tuples in X are pairs of an n-element set F and a map F to X. **Depends on:** Example 2.1.6, Definition 2.3.1. |
| [Example 2.4.5](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm5) | `not_formalized` | Elliptic moduli is introduced as complex lattices modulo nonzero scalar multiplication. **Depends on:** Definition 2.4.7. |
| [Definition 2.4.6](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm6) | `not_formalized` | A lattice is a metrically discrete additive subgroup of full rank in a finite dimensional real vector space. |
| [Definition 2.4.7](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm7) | `not_formalized` | The elliptic moduli type consists of complex lines equipped with lattices. **Depends on:** Definition 2.4.6. **Notes:** Several internal cross-references incorrectly cite Definition 2.4.6 for this definition. |
| [Proposition 2.4.8](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm8) | `not_formalized` | The upper-half-plane map to elliptic moduli has SL2(Z)-torsor fibers and presents its homotopy quotient. **Depends on:** Theorem 2.3.5, lattice bases, Mobius transformations. **Notes:** The written proof swaps coefficients of z and z times sigma; determinant positivity needs an orientation argument. Formal proof must reconstruct these steps. |
| [Example 2.4.9](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm9) | `not_formalized` | The pillowcase is a lattice torus modulo inversion, expressed using real inner-product lines. **Depends on:** Definition 2.3.1, Definition 2.4.6. |
| [Example 2.4.10](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm10) | `not_formalized` | The Kummer example is a four-torus modulo simultaneous conjugation, using quadratic real extensions as exemplars. **Depends on:** Field extensions, Definition 2.3.1. |
| [Example 2.4.11](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm11) | `not_formalized` | Tensor powers of Hermitian lines describe weighted circle actions, the teardrop and weighted projective quotients. **Depends on:** Example 2.1.7, Definition 2.3.1. |
| [Example 2.4.12](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm12) | `not_formalized` | Finite integral linear actions on tori are described using lattice spaces and subgroup frame subtorsors. **Depends on:** Definition 2.4.6, Proposition 2.2.13. |

### Section 3.0

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 3.0.1](https://arxiv.org/html/2205.15887v1#S3.SS0.Thmthm1) | `not_formalized` | Shape is real-line nullification; n-shape additionally imposes n-truncation by sphere nullification. **Depends on:** Higher inductive localization. |

### Section 3.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Axiom 1](https://arxiv.org/html/2205.15887v1#Thmaxiom1) | `not_formalized` | Excluded middle holds for crisp propositions. **Depends on:** Crisp context calculus. **Notes:** Must not be replaced by unrestricted internal excluded middle. |
| [Definition 3.1.1](https://arxiv.org/html/2205.15887v1#S3.SS1.Thmthm1) | `not_formalized` | A crisp type is discrete when its flat counit is an equivalence. **Depends on:** Flat comodality. |
| [Axiom 2](https://arxiv.org/html/2205.15887v1#Thmaxiom2) | `not_formalized` | For crisp types, flat discreteness agrees with real-line nullity. **Depends on:** Flat, smooth real line, shape. |
| [Theorem 3.1.2](https://arxiv.org/html/2205.15887v1#S3.SS1.Thmthm2) | `not_formalized` | Shape and flat satisfy an adjunction on crisp types. **Depends on:** Cohesive HoTT. **Notes:** Quoted from external reference 30, Theorem 9.15. |

### Section 3.2

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 3.2.1](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm1) | `not_formalized` | A modal etale map has a pullback square of modality units. **Depends on:** Modality, pullback. |
| [Definition 3.2.2](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm2) | `not_formalized` | A covering is a shape1-etale map with set fibers. **Depends on:** Definition 3.2.1, Definition 3.0.1. |
| [Theorem 3.2.3](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm3) | `not_formalized` | Modal equivalences and modal etale maps form an orthogonal factorization system. **Depends on:** Modal HoTT. **Notes:** Quoted from external reference 10, Theorem 7.2. |
| [Theorem 3.2.4](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm4) | `not_formalized` | Coverings of X are equivalent to discrete-set-valued families on its fundamental groupoid. **Depends on:** Cohesive covering theory. **Notes:** Quoted from external reference 22, Theorem 9.2. |
| [Remark 3.2.5](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm5) | `not_formalized` | For a pointed connected space, the covering classification becomes fundamental-group monodromy. **Depends on:** Theorem 3.2.4. |
| [Theorem 3.2.6](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm6) | `not_formalized` | Elliptic moduli has shape BSL2(Z), and the upper-half-plane map is its universal cover. **Depends on:** Proposition 2.4.8, external good-fibration theory. |
| [Theorem 3.2.7](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm7) | `not_formalized` | For a discrete group delooping and a shape-connected acted-on type, the quotient projection is a shape unit. **Depends on:** Modal connectedness, Definition 2.3.1. |
| [Theorem 3.2.8](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm8) | `not_formalized` | Shape of a quotient by a crisp higher group is the quotient of shapes by the induced action. **Depends on:** External shape-of-delooping and separated-modality results. |
| [Corollary 3.2.9](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9) | `not_formalized` | A torus quotient by a crisp finite integral linear group has shape the delooping of its crystallographic group extension. **Depends on:** Theorem 3.2.8, shape of tori, fiber sequence. |

### Section 3.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Proposition 3.3.1](https://arxiv.org/html/2205.15887v1#S3.SS3.Thmthm1) | `not_formalized` | Maps into unordered n-tuples correspond to n-fold covers equipped with maps to the underlying type. **Depends on:** Example 2.4.4, Theorem 3.2.4. |
| [Proposition 3.3.2](https://arxiv.org/html/2205.15887v1#S3.SS3.Thmthm2) | `not_formalized` | Maps into a homotopy quotient correspond to principal bundles with equivariant maps from their total spaces. **Depends on:** Torsor classification, dependent sums. |

### Section 4.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Axiom 3](https://arxiv.org/html/2205.15887v1#Thmaxiom3) | `not_formalized` | Smooth reals satisfy Kock-field, strict-order, Archimedean, exponential, covering, constancy, tiny-type and Kock-Lawvere postulates. **Depends on:** Definitions 4.1.1, 4.2.1, 4.2.3, A.0.1. **Notes:** Seven named postulate groups: K, O (five clauses), Exp, E, Principle of Constancy, W, J. |
| [Definition 4.1.1](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm1) | `not_formalized` | Weil algebra is an augmented finitely presented algebra with finitely generated nilpotent augmentation ideal. |
| [Remark 4.1.2](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm2) | `not_formalized` | Distinguishes Weil algebras from Weyl algebras. **Notes:** Terminology. |
| [Lemma 4.1.3](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm3) | `not_formalized` | A finitely presented augmented algebra admits a polynomial presentation whose augmentation evaluates variables at zero. **Depends on:** Polynomial change of variables. |
| [Remark 4.1.4](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm4) | `not_formalized` | Dual numbers with zero augmentation give a basic Weil algebra. **Depends on:** Definition 4.1.1. |
| [Definition 4.1.5](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm5) | `not_formalized` | The synthetic spectrum of an R-algebra is its type of R-algebra maps to R. |
| [Remark 4.1.6](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm6) | `not_formalized` | Finitely presented spectra are polynomial zero loci; dual-number spectrum is the nilsquare infinitesimal type. **Depends on:** Definition 4.1.5, Axiom 3 (J). |
| [Lemma 4.1.7](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm7) | `not_formalized` | Every smooth-real function has a unique derivative characterized by nilsquare increments. **Depends on:** Axiom 3 (J). |
| [Definition 4.1.8](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm8) | `not_formalized` | Tangent vectors at x are pointed maps from nilsquare infinitesimals; their dependent sum forms the tangent bundle. **Depends on:** Definition 4.1.5. |
| [Lemma 4.1.9](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm9) | `not_formalized` | The unit-circle tangent space at the identity is equivalent to the real line. **Depends on:** Axiom 3 (J), complex algebra. |
| [Remark 4.1.10](https://arxiv.org/html/2205.15887v1#S4.SS1.Thmthm10) | `not_formalized` | Point isotropy acts on the tangent space through the tangent family. **Depends on:** Definition 4.1.8, Definition 2.2.4. |

### Section 4.2

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 4.2.1](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm1) | `not_formalized` | Infinitesimal varieties are pointed types represented by spectra of Weil algebras. **Depends on:** Definition 4.1.1, Definition 4.1.5. |
| [Lemma 4.2.2](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm2) | `not_formalized` | Infinitesimal varieties are contravariantly equivalent to Weil algebras. **Depends on:** Axiom 3 (J), evaluation adjunction. |
| [Definition 4.2.3](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm3) | `not_formalized` | Neighbor relation is double negated equality; infinitesimal neighborhoods collect neighbors of a chosen point. **Notes:** Use an internal constructive identity/equality notion. |
| [Remark 4.2.4](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm4) | `not_formalized` | In the Dubuc model, the infinitesimal type is represented by smooth germs at zero. **Notes:** Quoted model fact. |
| [Remark 4.2.5](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm5) | `not_formalized` | Claims an Archimedean characterization of infinitesimals by reciprocal bounds. **Depends on:** Axiom 3 (O). **Notes:** Printed formula lacks an absolute value or lower bound and allows n=0; false literally, for instance at x=-1 with positive n. Confirmed in HTML; PDF extraction independently noted by foundations reviewer. |
| [Lemma 4.2.6](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm6) | `not_formalized` | Every function preserves the neighbor relation and induces maps on infinitesimal neighborhoods. **Depends on:** Double-negation functoriality. |
| [Lemma 4.2.7](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm7) | `not_formalized` | The infinitesimal neighborhood of zero in finite real powers consists of coordinatewise infinitesimals. **Depends on:** Axiom 3 (K). |
| [Remark 4.2.8](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm8) | `not_formalized` | Relates the finite-coordinate neighborhood calculation to Kock-field axioms. **Depends on:** Lemma 4.2.7. |
| [Lemma 4.2.9](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm9) | `not_formalized` | Each infinitesimal variety admits a pointed polynomial zero-locus presentation inside a finite infinitesimal power. **Depends on:** Lemma 4.1.3, nilpotence, Definition 4.2.3. |
| [Definition 4.2.10](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm10) | `not_formalized` | An X-pushout is a square sent to a pullback by mapping into X. |
| [Definition 4.2.11](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm11) | `not_formalized` | An infinitesimal real-pushout is a crisp pointed square of infinitesimal varieties that is a real-pushout. **Depends on:** Definition 4.2.1, Definition 4.2.10. |
| [Definition 4.2.12](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm12) | `not_formalized` | A type is microlinear when each infinitesimal real-pushout is also its pushout in the testing sense. **Depends on:** Definition 4.2.11. |
| [Definition 4.2.13](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm13) | `not_formalized` | The first-order patch D(n) consists of vectors with every pairwise coordinate product zero. |
| [Lemma 4.2.14](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm14) | `not_formalized` | First-order patches define a fully faithful functor from finite free real modules to infinitesimal varieties. **Depends on:** Axiom 3 (J), matrix algebra. |
| [Lemma 4.2.15](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm15) | `not_formalized` | Joining coordinate first-order patches at zero yields an infinitesimal real-pushout; D sends finite-free coproducts to such squares. **Depends on:** Axiom 3 (J), Definition 4.2.13. |
| [Definition 4.2.16](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm16) | `not_formalized` | Infinitesimal linearity requires the first-order coordinate-patch test squares to map to pullbacks. **Depends on:** Lemma 4.2.15. |
| [Remark 4.2.17](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm17) | `not_formalized` | Microlinearity implies infinitesimal linearity. **Depends on:** Lemma 4.2.15, Definition 4.2.12. |
| [Remark 4.2.18](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm18) | `not_formalized` | Explains different uses of microlinear and infinitesimally linear terminology in the literature. **Notes:** Terminology. |
| [Theorem 4.2.19](https://arxiv.org/html/2205.15887v1#S4.SS2.Thmthm19) | `not_formalized` | An infinitesimally linear type has coherent real-module structures on its tangent types. **Depends on:** Lemma 4.2.14, Lemma 4.2.15, Lawvere theories. **Notes:** Final proof sentence says algebras where modules is intended; proof written for microlinear X uses only first-order test squares. |

### Section 4.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 4.3.1](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm1) | `not_formalized` | The crystalline modality is nullification at the type of all infinitesimals. **Depends on:** Definition 4.2.3, higher inductive localization. |
| [Remark 4.3.2](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm2) | `not_formalized` | Compares the crystalline modality with infinitesimal shape and de Rham stacks in other models. **Notes:** Model terminology; equality with nullification at all infinitesimal varieties is not claimed in the Dubuc model. |
| [Axiom 4](https://arxiv.org/html/2205.15887v1#Thmaxiom4) | `not_formalized` | Crystalline localization preserves crisp pullback squares. **Depends on:** Definition 4.3.1. **Notes:** This is restricted to crisp diagrams, not unrestricted left exactness. |
| [Remark 4.3.3](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm3) | `not_formalized` | The intended external model has an adjoint triple around crystalline localization. **Notes:** The extra comodalities are not added to the paper's formal system. |
| [Lemma 4.3.4](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm4) | `not_formalized` | Crisp infinitesimal varieties are crystalline-connected. **Depends on:** Lemma 4.2.9, Axiom 4. |
| [Proposition 4.3.5](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm5) | `not_formalized` | Crystalline-etale maps induce equivalences on generalized tangent types for crisp infinitesimal test varieties. **Depends on:** Lemma 4.3.4, Theorem 3.2.3. |
| [Remark 4.3.6](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm6) | `not_formalized` | Discusses whether lifting against the base point of the infinitesimal type characterizes crystalline-etale maps. **Notes:** Left as a question, not proved generally. |
| [Lemma 4.3.7](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm7) | `not_formalized` | Discrete types are crystalline; corresponding modal, etale, connected and equivalence classes satisfy the stated inclusions. **Depends on:** Real contraction of infinitesimals, external modal comparison theorem. **Notes:** Four subsidiary implications must be tracked separately in formalization. |
| [Remark 4.3.8](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm8) | `not_formalized` | The upper-half-plane map to elliptic moduli is crystalline-etale and preserves tangent types. **Depends on:** Lemma 4.3.7, Proposition 4.3.5, Theorem 3.2.6. |
| [Warning 4.3.9](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm9) | `not_formalized` | Unrestricted left exactness of the crystalline modality would collapse infinitesimals. **Depends on:** Lemma 4.3.7, nontrivial Kock-Lawvere theory. **Notes:** Distinguishes crisp preservation from internal left exactness. |
| [Lemma 4.3.10](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm10) | `not_formalized` | Microlinearity is orthogonality to codiagonal maps of infinitesimal real-pushout squares. **Depends on:** Definition 4.2.12, homotopy pushout universal property. |
| [Lemma 4.3.11](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm11) | `not_formalized` | Microlinearity ascends along crystalline-etale maps. **Depends on:** Lemma 4.3.10, Lemma 4.3.4. |
| [Lemma 4.3.12](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm12) | `not_formalized` | For any modality, connected types are closed under homotopy pushouts. **Depends on:** Mapping-out universal property, modal connectedness. |
| [Theorem 4.3.13](https://arxiv.org/html/2205.15887v1#S4.SS3.Thmthm13) | `not_formalized` | Microlinearity descends along surjective crystalline-etale maps. **Depends on:** Lemma 4.3.10, Lemma 4.3.12, lifting and fiber calculations. |

### Section 5.0

| Item | Status | Statement and dependencies |
|---|---|---|
| [Proposition 5.0.1](https://arxiv.org/html/2205.15887v1#S5.SS0.Thmthm1) | `not_formalized` | Microlinear types are closed under limits and arbitrary exponentiation. **Depends on:** Lemma 4.3.10. |
| [Proposition 5.0.2](https://arxiv.org/html/2205.15887v1#S5.SS0.Thmthm2) | `not_formalized` | Zero loci of arbitrary maps between powers of the smooth reals are microlinear. **Depends on:** Proposition 5.0.1, microlinearity of smooth reals. |

### Section 5.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 5.1.1](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm1) | `not_formalized` | Constructive regularity, T0, regular Hausdorff and Hausdorff separation properties are specified. **Notes:** Regularity clause informally refers to a neighborhood of U where a neighborhood of x is needed. |
| [Lemma 5.1.2](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm2) | `not_formalized` | Constructive regular Hausdorff spaces are Hausdorff. **Depends on:** Definition 5.1.1. |
| [Lemma 5.1.3](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm3) | `not_formalized` | Open subsets of regular spaces are closed under passage to infinitesimal neighbors. **Depends on:** Definition 5.1.1, Definition 4.2.3. |
| [Definition 5.1.4](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm4) | `not_formalized` | Metric openness in finite smooth-real powers is defined by positive-radius Euclidean balls. **Depends on:** Axiom 3 (O). |
| [Theorem 5.1.5](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm5) | `not_formalized` | The metric topology on finite smooth-real powers is regular Hausdorff. **Depends on:** Axiom 3 (K,O), Definition 5.1.4. **Notes:** Written one-dimensional proof reverses a reciprocal inequality; formal proof needs the corrected direction. |
| [Definition 5.1.6](https://arxiv.org/html/2205.15887v1#S5.SS1.Thmthm6) | `not_formalized` | Ordinary manifolds are regular Hausdorff spaces with local Euclidean charts and a countable chart basis. **Depends on:** Definition 5.1.1, Definition 5.1.4. |

### Section 5.2

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 5.2.1](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm1) | `not_formalized` | A Penon manifold has pointed infinitesimal neighborhoods locally equivalent to finite powers of the infinitesimal type. **Depends on:** Definition 4.2.3. |
| [Proposition 5.2.2](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm2) | `not_formalized` | Ordinary manifolds are Penon manifolds. **Depends on:** Lemma 5.1.3, Lemma 4.2.6, Definition 5.1.6. |
| [Lemma 5.2.3](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm3) | `not_formalized` | Microlinearity is equivalent to microlinearity of every infinitesimal neighborhood. **Depends on:** Lemma 4.3.10, infinitesimal stability of test maps. |
| [Theorem 5.2.4](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm4) | `not_formalized` | Penon manifolds, and consequently ordinary manifolds, are microlinear. **Depends on:** Lemma 5.2.3, Lemma 4.2.7, Proposition 5.2.2. |
| [Definition 5.2.5](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm5) | `not_formalized` | A Penon-etale map induces equivalences on all infinitesimal neighborhoods. **Depends on:** Definition 4.2.3. |
| [Definition 5.2.6](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm6) | `not_formalized` | A crystalline disk is the fiber of the crystalline unit over the image of a point. **Depends on:** Definition 4.3.1. |
| [Lemma 5.2.7](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm7) | `not_formalized` | Crystalline localization of a crisp set is a set. **Depends on:** Axiom 4, diagonal pullback criterion for truncation. |
| [Lemma 5.2.8](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm8) | `not_formalized` | Codiscrete types are crystalline, giving a factorization of codiscrete units through crystalline units. **Depends on:** Flat-sharp cohesion, crisp excluded middle. **Notes:** The text calls the factor a sharp-counit; unit/factor convention needs review. |
| [Lemma 5.2.9](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm9) | `not_formalized` | On a crisp Penon manifold, infinitesimal neighborhoods and crystalline disks agree over the manifold. **Depends on:** Lemma 5.2.7, Lemma 5.2.8, codiscrete double-negation characterization. |
| [Theorem 5.2.10](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm10) | `not_formalized` | For maps between crisp Penon manifolds, Penon-etale and crystalline-etale are equivalent. **Depends on:** Lemma 5.2.9, external disk criterion for modal etaleness. **Notes:** The map itself need not be crisp. |
| [Corollary 5.2.11](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm11) | `not_formalized` | An infinitesimally stable crisp subset of a Penon manifold has crystalline-etale inclusion. **Depends on:** Theorem 5.2.10. |
| [Corollary 5.2.12](https://arxiv.org/html/2205.15887v1#S5.SS2.Thmthm12) | `not_formalized` | Under an infinitesimal inverse-function assumption, crystalline etaleness between crisp manifolds is equivalent to a pullback square of tangent bundles. **Depends on:** Theorem 5.2.10, external Penon result, infinitesimal inverse function theorem. **Notes:** The inverse function theorem is an additional explicit hypothesis, not among Axioms 1-5. |

### Section 5.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 5.3.1](https://arxiv.org/html/2205.15887v1#S5.SS3.Thmthm1) | `not_formalized` | A Schreiber manifold has a jointly surjective etale atlas with etale coordinate embeddings into a discrete family of model types. **Depends on:** Definition 3.2.1. |
| [Definition 5.3.2](https://arxiv.org/html/2205.15887v1#S5.SS3.Thmthm2) | `not_formalized` | Schreiber-Satake orbifolds use finite orthogonal quotient types as coordinate models. **Depends on:** Definition 5.3.1, Example 2.4.3. |
| [Lemma 5.3.3](https://arxiv.org/html/2205.15887v1#S5.SS3.Thmthm3) | `not_formalized` | Dependent sums of crystalline-etale fiber maps over crystalline index types are crystalline-etale. **Depends on:** Modal dependent sums, pullback fibers. **Notes:** The formula for the map should include its base component k(a). |
| [Lemma 5.3.4](https://arxiv.org/html/2205.15887v1#S5.SS3.Thmthm4) | `not_formalized` | Dependent sums of microlinear types over a crystalline type are microlinear. **Depends on:** Lemma 4.3.10, Lemma 4.3.12. |
| [Theorem 5.3.5](https://arxiv.org/html/2205.15887v1#S5.SS3.Thmthm5) | `not_formalized` | A Schreiber manifold with microlinear coordinate types is microlinear. **Depends on:** Lemma 5.3.3, Lemma 5.3.4, Lemma 4.3.11, Theorem 4.3.13. |

### Section 5.4

| Item | Status | Statement and dependencies |
|---|---|---|
| [Theorem 5.4.1](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm1) | `not_formalized` | A homotopy quotient of a microlinear type by a crisply discrete group is microlinear. **Depends on:** External good-fibration theorem, Lemma 4.3.7, Theorem 4.3.13. |
| [Corollary 5.4.2](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm2) | `not_formalized` | A crisp pointed path-connected type is microlinear if its universal cover is microlinear. **Depends on:** Theorem 5.4.1, universal-cover monodromy. |
| [Definition 5.4.3](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm3) | `not_formalized` | Precategories have object types, hom sets, identities and composition; pregroupoids invert all arrows; categories satisfy id-to-isomorphism univalence. **Notes:** Ordinary Lean categories model the external precategory structure but not automatically categorical univalence. |
| [Remark 5.4.4](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm4) | `not_formalized` | A univalent pregroupoid is determined by its object 1-type. **Notes:** Requires homotopical identity types. |
| [Definition 5.4.5](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm5) | `not_formalized` | Rezk completion is the essential image of the Yoneda embedding in a univalent presheaf category. **Depends on:** Univalence, presheaves, Yoneda. |
| [Definition 5.4.6](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm6) | `not_formalized` | An etale pregroupoid has microlinear objects and crystalline-etale source; etale groupoids are their Rezk completions. **Depends on:** Definition 5.4.3, Definition 5.4.5, Definition 4.2.12. |
| [Theorem 5.4.7](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm7) | `not_formalized` | For a modality preserving the indicated crisp colimits, a crisp surjection with inhabited domain is etale when its self-pullback is etale. **Depends on:** Surjective modality units, preservation of empty type, crisp pushouts and sequential colimits, Lemmas 5.4.10-12, join construction. |
| [Theorem 5.4.8](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm8) | `not_formalized` | Crystalline localization preserves crisp pushouts and crisp sequential colimits. **Depends on:** Axiom 3 (W), Theorem A.0.9. |
| [Theorem 5.4.9](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm9) | `not_formalized` | Crisp etale groupoids are microlinear. **Depends on:** Theorem 5.4.7, Theorem 5.4.8, Yoneda, Theorem 4.3.13. **Notes:** Empty-object presentations need a separate case before invoking the inhabited-domain form of 5.4.7. |
| [Lemma 5.4.10](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm10) | `not_formalized` | In a crisp pushout with two etale incoming legs, both outgoing legs are etale. **Depends on:** Modality preserving crisp pushouts, Mather cube descent. |
| [Lemma 5.4.11](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm11) | `not_formalized` | For a crisp sequence of etale maps, the colimit cocone maps are etale. **Depends on:** Modality preserving crisp sequential colimits, sequential descent. |
| [Lemma 5.4.12](https://arxiv.org/html/2205.15887v1#S5.SS4.Thmthm12) | `not_formalized` | Etaleness cancels from f and g composed with f to g when the modality image of f is surjective. **Depends on:** Pullback cancellation under surjective base change. **Notes:** The printed type of g is B to A, while its diagram and uses require the general codomain C. |

### Section 5.5

| Item | Status | Statement and dependencies |
|---|---|---|
| [Lemma 5.5.1](https://arxiv.org/html/2205.15887v1#S5.SS5.Thmthm1) | `not_formalized` | A looped pullback square of higher-group maps deloop to a pullback if one specified loop map is surjective. **Depends on:** Theorem 2.1.1, connected fiber calculations. |
| [Warning 5.5.2](https://arxiv.org/html/2205.15887v1#S5.SS5.Thmthm2) | `not_formalized` | The doubling map of integers shows the surjectivity assumption in the delooping pullback criterion is necessary. **Depends on:** Lemma 5.5.1, integer doubling. |
| [Theorem 5.5.3](https://arxiv.org/html/2205.15887v1#S5.SS5.Thmthm3) | `not_formalized` | Deloopings of crisp infinitesimally linear higher groups are infinitesimally linear. **Depends on:** Axiom 3 (W), Corollary A.0.8, Lemma 5.5.1. |
| [Remark 5.5.4](https://arxiv.org/html/2205.15887v1#S5.SS5.Thmthm4) | `not_formalized` | The same argument does not settle microlinearity of deloopings of general microlinear groups. **Notes:** The paper explicitly leaves this question open. |
| [Corollary 5.5.5](https://arxiv.org/html/2205.15887v1#S5.SS5.Thmthm5) | `not_formalized` | The tangent higher group at the identity deloops to the tangent type at the delooping base point, which is a higher real module. **Depends on:** Theorem 5.5.3, Theorem 4.2.19, Corollary A.0.8. |

### Section 6.1

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 6.1.1](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm1) | `not_formalized` | Four finiteness notions are defined using finite ordinals: finite, subfinite, finitely enumerable and subfinitely enumerable. **Notes:** These constructive distinctions collapse under unrestricted excluded middle. |
| [Proposition 6.1.2](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm2) | `not_formalized` | A crisp subfinitely enumerable set is finite. **Depends on:** Axiom 1, decidable subsets and quotients of finite sets. **Notes:** Crisp excluded middle is used only for crisp data. |
| [Definition 6.1.3](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm3) | `not_formalized` | Proper finiteness means subfinite enumerability together with decidable equality, equivalently discreteness in the cohesive setting. **Depends on:** Definition 6.1.1, external discrete-set criterion. |
| [Remark 6.1.4](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm4) | `not_formalized` | Discrete finitely enumerable sets are finite; the converse comparison between proper finiteness and subfiniteness is left open. **Notes:** The second claim is an open question in the paper. |
| [Lemma 6.1.5](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm5) | `not_formalized` | Subfinite sets, hence finite sets, are properly finite. **Depends on:** Definition 6.1.3, equality inherited from finite ordinals. |
| [Warning 6.1.6](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm6) | `not_formalized` | A two-point quotient varying with a real equality illustrates that finite enumerability need not imply proper finiteness. **Depends on:** Variable real equality, quotient types. **Notes:** This is a family refuting a uniform implication, not a claim that every individual specialization is non-discrete. |
| [Proposition 6.1.7](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7) | `not_formalized` | Intended characterization of subfinite enumerability by a total relation to a finite ordinal, with uniqueness of the represented element at each index; associations compose. **Depends on:** Definition 6.1.1, relational composition. **Notes:** CONFIRMED FALSE AS PRINTED: uniqueness is written in the opposite direction in both PDF and HTML. Only an explicitly corrected version can be formalized consistently. |
| [Lemma 6.1.8](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm8) | `not_formalized` | Subfinitely enumerable sets are exactly subobjects of finitely enumerable sets. **Depends on:** Pushouts and pullbacks of sets. |
| [Proposition 6.1.9](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9) | `not_formalized` | Proper finiteness is preserved by subsets, binary products, pullbacks, finite disjoint unions, images in discrete sets and finite unions inside a discrete set. **Depends on:** Corrected Proposition 6.1.7, Definition 6.1.3. **Notes:** Contains six separate closure claims; the written association arguments inherit the direction error of 6.1.7 and must be repaired. |

### Section 6.2

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition 6.2.1](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm1) | `not_formalized` | Dubuc-Penon compactness is distribution of a fixed disjunction across universal quantification; proper maps preserve compactness under inverse image. **Notes:** The quantifiers are internal; replacing them by classical reasoning trivializes this property. |
| [Axiom 5](https://arxiv.org/html/2205.15887v1#Thmaxiom5) | `not_formalized` | The closed unit interval is Dubuc-Penon compact. **Depends on:** Definition 6.2.1. |
| [Lemma 6.2.2](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2) | `not_formalized` | Finitely enumerable sets are DP compact; surjective images preserve DP compactness; compact coproducts have compact summands. **Depends on:** Definition 6.2.1, finite disjunction distribution. **Notes:** Contains three separate claims. |
| [Warning 6.2.3](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm3) | `not_formalized` | For a proposition P, DP compactness is equivalent to decidability; subfinite sets need not be DP compact. **Depends on:** Definition 6.2.1. **Notes:** This is an intuitionistic logical claim. |
| [Proposition 6.2.4](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4) | `not_formalized` | A map is DP proper exactly when its fibers are DP compact; DP proper maps are stable under pullback. **Depends on:** Definition 6.2.1, compact dependent sums. **Notes:** The proof's base-change map should have codomain the target Y. |
| [Proposition 6.2.5](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm5) | `not_formalized` | A dependent sum with DP compact base and DP compact fibers is DP compact; consequently binary products of DP compact types are DP compact. **Depends on:** Definition 6.2.1. |
| [Definition 6.2.6](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm6) | `not_formalized` | A subset is Penon open when membership propagates to each point or that point is distinct; Penon closed means complement Penon open. |
| [Lemma 6.2.7](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm7) | `not_formalized` | Every open subset of a regular topological space is Penon open. **Depends on:** Definition 5.1.1, Definition 6.2.6. |
| [Theorem 6.2.8](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm8) | `not_formalized` | A Penon-open relation on a DP compact type times the real line has a uniform real neighborhood around a universally related point. **Depends on:** Definition 6.2.1, Axiom 3 (E), Definition 6.2.6. |
| [Lemma 6.2.9](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm9) | `not_formalized` | Products of Penon-open subsets are Penon open. **Depends on:** Definition 6.2.6, intuitionistic propositional reasoning. |
| [Corollary 6.2.10](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm10) | `not_formalized` | Positive real functions on DP compact types have a positive uniform lower bound; arbitrary real functions are bounded in absolute value. **Depends on:** Theorem 6.2.8, Axiom 3 (Exp). **Notes:** Contains two claims. The written logarithm-sign argument has sign errors; the intended boundedness follows using negative logarithms. |
| [Definition 6.2.11](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm11) | `not_formalized` | Five cover-based notions are specified: compact, countably compact, subcompact, subcountably subcompact and refinement subcompact. **Depends on:** Definition 6.1.1. |
| [Remark 6.2.12](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm12) | `not_formalized` | Records implication relationships among the five cover-based compactness notions. **Depends on:** Definition 6.2.11. **Notes:** Countable compactness and subcountable subcompactness are not identified. |
| [Theorem 6.2.13](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm13) | `not_formalized` | DP compact types have bounded-index subcovers for subcountably indexed Penon-open covers, hence countable compactness and subcountable subcompactness. **Depends on:** Theorem 6.2.8, Lemma 6.2.9, Axiom 3 (O). **Notes:** The written proof divides by a possibly zero index; use positive indexing such as i+1. A bounded subset of natural indices is subfinite, not automatically finite internally. |
| [Corollary 6.2.14](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm14) | `not_formalized` | A DP compact subset of a second-countable space with Penon-open opens is refinement subcompact. **Depends on:** Theorem 6.2.13, countable basis. |
| [Proposition 6.2.15](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm15) | `not_formalized` | A crisp refinement-subcompact space has finite subcovers for crisp open covers. **Depends on:** Proposition 6.1.2, finite choice. |
| [Remark 6.2.16](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm16) | `not_formalized` | For crisp ordinary manifolds, the preceding results recover the external compactness consequence of DP compactness. **Depends on:** Corollary 6.2.14, Proposition 6.2.15. |
| [Proposition 6.2.17](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm17) | `not_formalized` | DP compact subsets of a Dubuc-Penon-separated type are Penon closed. **Depends on:** Definition 6.2.1, Definition 6.2.6. |
| [Lemma 6.2.18](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm18) | `not_formalized` | The smooth reals satisfy Dubuc-Penon separatedness. **Depends on:** Axiom 3 (K). |
| [Theorem 6.2.19](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm19) | `not_formalized` | DP compact subsets of the smooth real line are Penon closed and bounded. **Depends on:** Corollary 6.2.10, Proposition 6.2.17, Lemma 6.2.18. |
| [Warning 6.2.20](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm20) | `not_formalized` | Families depending on undecidable real equalities refute general closed-bounded-implies-DP-compact and closed-subset compactness principles. **Depends on:** Warning 6.2.3, Axiom 3 (K). **Notes:** The crisp closed-and-bounded case is left open; do not assert failure for every specialization. |
| [Lemma 6.2.21](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm21) | `not_formalized` | Discrete DP compact subsets of ordinary manifolds are properly finite. **Depends on:** Corollary 6.2.14, corrected Proposition 6.1.7, singleton cover. **Notes:** Formalization must justify compatibility of the cover topology with the Penon-open singleton refinement used in the proof. |

### Section 6.3

| Item | Status | Statement and dependencies |
|---|---|---|
| [Lemma 6.3.1](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm1) | `not_formalized` | Crystalline subsets of finite smooth-real powers are discrete. **Depends on:** Axiom 3 (Principle of Constancy), coordinatewise paths. |
| [Lemma 6.3.2](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm2) | `not_formalized` | Pulling a crystalline type back along a crystalline-etale map yields a crystalline total type. **Depends on:** Pullback stability of modal etaleness. **Notes:** The statement refers to the pullback map as crystalline, but the proof establishes that its domain is crystalline. |
| [Proposition 6.3.3](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm3) | `not_formalized` | A two-subset cover of the real line with both subsets nonempty has nonempty intersection in the negative constructive sense. **Depends on:** Real cohesion, discreteness of the two-element type. **Notes:** Nonempty here must be distinguished from inhabited; the proof establishes that the intersection cannot be empty. |
| [Lemma 6.3.4](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm4) | `not_formalized` | Crystalline subsets of crisp ordinary manifolds are discrete. **Depends on:** Lemma 6.3.1, Lemma 6.3.2, Lemma 5.2.9, Corollary 5.2.11, Theorem 6.2.13, Axiom 5, Proposition 6.3.3. **Notes:** Proof-review concerns: chart-preimage domains can be disconnected, and the finite-cover propagation argument needs a precise chain lemma. These are reconstruction tasks, not a claimed counterexample. |
| [Warning 6.3.5](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm5) | `not_formalized` | Explains obstacles to proving local constancy globally and to closure of discrete subsets under unions; suggests interval compactness may be inessential. **Depends on:** Lemma 6.3.4, variable two-point quotient. **Notes:** Includes open questions and constructive distinctions rather than only theorems. |
| [Definition 6.3.6](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm6) | `not_formalized` | An ordinary proper etale pregroupoid has ordinary manifold objects and arrows, crystalline-etale source, and DP proper source-target map. **Depends on:** Definition 5.4.3, Definition 5.1.6, Definition 6.2.1. **Notes:** Identification with ordinary local diffeomorphisms additionally uses the inverse-function assumption of Corollary 5.2.12. |
| [Theorem 6.3.7](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm7) | `not_formalized` | The Rezk completion of a crisp ordinary proper etale pregroupoid is an orbifold. **Depends on:** Theorem 5.4.9, Lemma 6.3.4, Lemma 6.2.21, Yoneda, Definition 1.1.2. **Notes:** The main theorem; the preceding foundational and proof-review dependencies remain substantive work. |

### Section 6.4

| Item | Status | Statement and dependencies |
|---|---|---|
| [Theorem 6.4.1](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm1) | `not_formalized` | Quotients of microlinear sets by crisp finite groups are orbifolds. **Depends on:** Theorem 5.4.1, Lemma 2.3.2, Lemma 6.1.5. |
| [Proposition 6.4.2](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm2) | `not_formalized` | Orbifolds are closed under homotopy pullback. **Depends on:** Proposition 5.0.1, Proposition 6.1.9, dependent-sum identity calculation. |
| [Definition 6.4.3](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm3) | `not_formalized` | The inertia type is the dependent sum of point automorphism types, equivalently the free homotopy-loop type. **Depends on:** Homotopy circle, dependent sums. |
| [Corollary 6.4.4](https://arxiv.org/html/2205.15887v1#S6.SS4.Thmthm4) | `not_formalized` | The inertia type of an orbifold is an orbifold. **Depends on:** Proposition 6.4.2, self-pullback of the diagonal. |

### Section A.0

| Item | Status | Statement and dependencies |
|---|---|---|
| [Definition A.0.1](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm1) | `not_formalized` | A crisp type is tiny when exponentiation by it has a right adjoint for crisp maps, expressed using flat-equivalences. **Depends on:** Crisp context calculus, flat comodality. **Notes:** The adjunction is externalized, not an unrestricted internal function-space adjunction. |
| [Warning A.0.2](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm2) | `not_formalized` | The right adjoint supplied by tinyness need not be stable under noncrisp base change. **Depends on:** Definition A.0.1. |
| [Remark A.0.3](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm3) | `not_formalized` | The chosen tiny-type encoding uses existing cohesive syntax; a dedicated type theory is left for future work. **Depends on:** Definition A.0.1. |
| [Lemma A.0.4](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm4) | `not_formalized` | The tiny-type adjunction comparison is natural under precomposition by a crisp map. **Depends on:** Definition A.0.1, function composition. |
| [Proposition A.0.5](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm5) | `not_formalized` | Exponentiation by a tiny type preserves crisp colimits, including coequalizers, pushouts and sequential colimits. **Depends on:** Definition A.0.1, Lemma A.0.4, colimit universal properties. **Notes:** General statement plus three explicitly named cases. |
| [Lemma A.0.6](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm6) | `not_formalized` | Exponentiation by T commutes with a dependent sum when the base is T-null. **Depends on:** Nullity, dependent-sum mapping equivalence. |
| [Theorem A.0.7](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm7) | `not_formalized` | Tiny-type exponentiation commutes with localization at suitable crisp sequentially compact null families, and hence with truncation of crisp types. **Depends on:** Proposition A.0.5, Lemma A.0.6, external sequential localization construction. **Notes:** The index type is crisply discrete and T-null; source and target types of localization maps are also T-null and sequentially compact. |
| [Corollary A.0.8](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm8) | `not_formalized` | Exponentiation by a tiny type preserves connectedness of crisp types and corresponding iterated deloopings. **Depends on:** Theorem A.0.7. |
| [Theorem A.0.9](https://arxiv.org/html/2205.15887v1#A1.SS0.Thmthm9) | `not_formalized` | Nullification at a crisply discrete family of tiny types preserves crisp colimits, particularly pushouts and sequential colimits. **Depends on:** Proposition A.0.5, localization universal property. |
