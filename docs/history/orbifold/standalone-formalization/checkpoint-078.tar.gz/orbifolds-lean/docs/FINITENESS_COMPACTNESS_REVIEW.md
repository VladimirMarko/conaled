# Finiteness and compactness: source and proof review

## Scope and conclusion

This review compares the 22 modules under `Orbifolds/Finiteness/` and the
15 modules under `Orbifolds/External/Compactness/` with the original paper.
It includes the new finite-union result from checkpoint 070 and the checked
sources and axiom log present at checkpoint 071. The companion JSON records
the exact reviewed file hashes and declaration audit lines. The reviewer
also authored the compactness modules; the finiteness review is independent
of their implementation.

**No incorrect ordinary theorem statement or missing ordinary hypothesis
was found in these 37 files.** They provide an external logical fragment.
They do not implement the paper's internal cohesive type theory, and their
success must not change full internal-theorem statuses to `formalized`.

The most consequential limitation is concrete: **with classical excluded
middle, the native predicate `DPCompact K` holds for every Lean sort `K`.**
For its fixed proposition `A`, if `A` holds the left disjunct suffices;
otherwise every premise `A ∨ B k` supplies `B k`. Consequently, the native
`DPProper` predicate also holds for every map classically. The checked
closure proofs avoid that argument and preserve the intended constructive
quantifiers, but this does not turn native Lean propositions into the
paper's internal propositions. A semantic model or a checked object-theory
embedding is still needed to recover the intended nontrivial geometry.

## Source coverage

All rows below mean ordinary external formulations, not internal cohesive
theorems. Source: David Jaz Myers, [arXiv:2205.15887v1](https://arxiv.org/html/2205.15887v1).

| Paper item | Checked content and boundary |
| --- | --- |
| [Definitions 6.1.1 and 6.1.3](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm1) | Explicit finite-ordinal witnesses define the four finiteness predicates; proper finiteness is subfinite enumerability plus the exact logical equality condition `x = y ∨ x ≠ y`. No identification with cohesive discreteness is claimed. |
| [Lemma 6.1.5](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm5) | `subfinite_properlyFinite` derives both components from an injection into `Fin n`; it decides only equality of finite labels. |
| [Proposition 6.1.7](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7) | The corrected association characterization and transfer theorem are proved. The literal printed condition is separately encoded and refuted by an explicit natural-number counterexample. These are deliberately different statements. |
| [Lemma 6.1.8](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm8) | `subfinitelyEnumerable_iff_embeds_finitelyEnumerable` proves both directions. Its forward construction uses an ordinary quotient of `X ⊕ Fin n`; a predicate invariant proves the map from `X` is injective. It does not assert a higher pushout construction. |
| [Proposition 6.1.9, all six clauses](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm9) | Closure under injections, products, ordinary pullbacks, `Fin n`-indexed dependent disjoint unions, images in an explicitly decidable-equality type, and `Fin n`-indexed unions. Binary sum and union lemmas are also present. The finite-index formulations match the paper's proof. |
| [Definition 6.2.1](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm1) | `DPCompact` has the exact fixed-`A`, variable-`B` quantifier order. `DPProper` quantifies over every compact subtype of the codomain and its inverse image. Axiom 5 about the smooth unit interval is not implemented. |
| [Lemma 6.2.2, all three clauses](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm2) | Finitely enumerable types are compact; surjective images preserve compactness; compact coproducts have two compact summands. A finite-ordinal induction supplies the first clause. No summand inhabitance or target equality decision is assumed. |
| [Warning 6.2.3](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm3) | Exactly `DPCompact P ↔ P ∨ ¬ P` is proved. This is not a construction of an undecidable internal proposition or an internal noncompact subfinite example. |
| [Proposition 6.2.4, both claims](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4) | DP properness is equivalent to compact native equality fibers; it is stable under the explicit subtype pullback. The base-change map has the required codomain `Y`, correcting the printed proof's codomain typo. Native equality fibers are not asserted to be cohesive homotopy fibers. |
| [Proposition 6.2.5](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm5) | Both compact dependent sums and the explicit native binary-product corollary are proved. Base and fiber compactness remain hypotheses. |
| [Definition 6.2.6 and Lemma 6.2.9](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm6) | Exact Penon-open and Penon-closed predicates, and product preservation of openness. No manifold topology or internal topological model is constructed. |
| [Proposition 6.2.17](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm17) | Compact subtypes are Penon closed under the explicit cotransitive-inequality condition `DPSeparated`. The proof uses the compactness disjunction with one fixed proposition `x ≠ z`. |
| [Lemma 6.2.21, combinatorial step only](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm21) | `properlyFinite_of_subsingleton_cover` assumes a supplied subsingleton cover, subfinitely enumerable index type, and decidable equality. It proves the resulting proper finiteness. It does not construct the cover or prove the theorem's geometric refinement and compactness prerequisites. |

## The association correction

The [original PDF](https://arxiv.org/pdf/2205.15887), printed page 54, and
the HTML both give uniqueness of the finite label *at a fixed point* in
Proposition 6.1.7. The always-true relation with `Fin 1` satisfies that
condition for every type. Thus it cannot characterize subfinite
enumerability. This is confirmed by extracted PDF text; this review does
not claim an independent visual inspection of the PDF page.

The corrected predicate requires uniqueness of the represented point *at
a fixed label*. The relation then embeds into the finite ordinal and
surjects onto the original type, exactly as the paper's intended proof
requires. The characterization, composition, injection, surjection, and
subsingleton-cover arguments consistently use this corrected direction.
No false printed proposition is assumed as an axiom or reused as a theorem.

## Axiom and assumption audit

The inspected [axiom log](../verification/axioms.log) records 47 declarations
in the two reviewed namespaces. The accompanying source builds passed with
Lean 4.33.0-rc1. Review used the existing kernel-check and axiom evidence;
it did not add redundant tests or uncheckpointed proof declarations.

| Namespace | Declarations | No axiom dependencies | Standard extensionality/quotient dependencies, without choice | Includes `Classical.choice` |
| --- | ---: | ---: | ---: | ---: |
| `Orbifolds.Finiteness` | 31 | 18 | 11 | 2 |
| `Orbifolds.External.Compactness` | 16 | 14 | 2 | 0 |

The two compactness exceptions depend only on `propext`: finite-ordinal
compactness and its finitely-enumerable consequence. The finiteness proofs
otherwise use at most `propext` and `Quot.sound`, except for
`nat_not_subfinitelyEnumerable` and the counterexample that imports it.
Those two explicitly use classical selection to complete a partially
specified finite family. They are correctly separated from the constructive
closure results. No reviewed declaration depends on `sorryAx` or a newly
postulated paper theorem.

Surjectivity witnesses are eliminated into propositions rather than used
to select global preimage functions. The new finite-union theorem also
uses its membership witnesses only inside propositions. Empty finite
ordinals, empty summands, and empty fibers are covered by the existing
proofs; no hidden inhabitance requirement was found. Ordinary pullbacks
require no equality decision on their codomain. Decidable equality remains
an explicit ambient hypothesis for the image and union results.

## Remaining interpretation work

These declarations use Lean's proof-irrelevant native equality, native
subtypes and quotients, and ordinary proposition quantification. They do
not supply crisp contexts, cohesive modalities, higher identity types,
smooth reals or infinitesimals, microlinearity, the covering property, or
the geometric construction required in Lemma 6.2.21. In particular, the
review does not validate the paper's orbifold or microlinearity theorems.
The 199-item paper inventory must retain this separation between external
fragment coverage and completion of the original internal statements.

One citation-only correction is required: `SubsingletonCover.lean` and the
checkpoint-063 ledger call item 6.2.21 a theorem, while the source calls it
**Lemma 6.2.21**. The controller identified this during reconciliation and
is correcting that metadata; the mathematical statement is unchanged.

No further repair to the reviewed Lean proofs is requested. Later source
changes should be reviewed against the companion manifest rather than
silently treated as part of this snapshot.
