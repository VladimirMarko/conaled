# Review of the ordinary groupoid, torsor, and inertia fragment

Reviewed on 2026-10-19, through checkpoint 072. The Lean implementation uses
Lean 4.33.0-rc1 and the bundled `Std` library. The source comparison uses
David Jaz Myers, [arXiv:2205.15887v1](https://arxiv.org/abs/2205.15887v1),
especially Sections 2.1, 2.3, and 6.4.

## Verdict and scope

The reviewed declarations correctly implement the stated **ordinary
algebraic and groupoid results**. The construction of the action groupoid,
its stabilizer groups, the concrete nontrivial-isotropy example, and the
ordinary torsor evaluation equivalence are kernel checked. Independent
review of `Inertia.lean` and `InertiaFiniteness.lean` found no defect in their
ordinary groupoid definitions, laws, or finiteness argument.

The external algebraic counterpart of Lemma 2.1.13 is complete: the source
has the canonical right-translation action, that action is a torsor, and
evaluation at the identity has an explicit inverse and is equivariant.
These facts are exported in separate declarations. They do **not** give
the paper's identification in a univalent type of torsors, nor construct a
delooping. No microlinearity or cohesive orbifold theorem is proved by this
fragment.

## Source correspondence

All declaration names in the table are in `Orbifolds.External`.

| Source location | Implemented declarations | Exact extent |
| --- | --- | --- |
| Algebraic argument of Lemma 2.1.13 | `Action.regularEvaluationIso` | Equivariant functions from the ordinary regular action to any ordinary action are explicitly equivalent to the target's underlying type. |
| Ordinary algebraic counterpart of Lemma 2.1.13 | `Action.torsorEvaluationIso`, `Action.regularBijectionAction`, `Action.torsorEvaluation_equivariant`, `Action.regularBijectionAction_isTorsor` | Evaluation is an equivariant equivalence from the ordinary torsor of equivariant bijections to the given torsor. No identification type of torsor structures is used. |
| Arrow description associated with Lemma 2.3.2 | `Action.groupoid` | Explicit ordinary arrows are group elements carrying the source to the target; all groupoid laws are proved. No equivalence involving equality in a homotopy quotient is asserted. |
| Ordinary counterpart of Corollary 2.3.3 | `GroupoidData.automorphismGroup`, `Action.stabilizerGroup` | The stabilizer subtype receives the automorphism group structure at the chosen action-groupoid object. |
| Set-level finiteness component associated with Theorem 6.4.1 | `Action.homs_properlyFinite` | A subfinite ordinary acting group gives properly finite ordinary arrow types. The meaning of proper finiteness is the explicit set-level definition in this project. |
| Ordinary groupoid counterpart of Definition 6.4.3 | `GroupoidData.inertia` | Objects are pairs of an object and one of its automorphisms. Arrows are commuting arrows in the original groupoid. |
| Ordinary arrow-finiteness component associated with Corollary 6.4.4 | `GroupoidData.inertia_homs_properlyFinite` | Proper finiteness of original hom types passes to inertia hom types. No microlinearity, free-loop-type equivalence, or orbifold conclusion is included. |

The concrete declarations `booleanGroup`, `trivialBooleanAction`, and
`trivialBooleanAction_has_distinct_loops` are supporting examples. The last
theorem exhibits two distinct ordinary automorphism arrows at the unique
object. It does not claim two distinct proofs of a Lean equality.

## Group multiplication and composition conventions

The implementation makes its conventions explicit:

- `C.comp g f` means **g after f**.
- `S.mul g h` acts on the left by applying `h` and then `g`:
  `A.act (S.mul g h) x = A.act g (A.act h x)`.
- Composition in the action groupoid therefore uses the group element
  `S.mul g.val f.val`.
- An equivariant function from the regular action satisfies
  `f (S.mul g h) = A.act g (f h)`.
- The action on these functions is right translation of the input:
  `(g · f)(k) = f(k * g)`.

The last formula gives a left action with the conventions above:
`g · (h · f)` evaluates at `k` to `f((k * g) * h)`, which equals
`f(k * (g * h))`. This is the stated action of `g * h`. Precomposition by
left multiplication would generally fail to preserve equivariance for a
noncommutative group; the implementation uses the correct side.

The `GroupData` law fields are hypotheses supplied with an ordinary
algebraic group. They are not newly declared global axioms. The code does
not attempt to identify this multiplication convention with a native Lean
equality-path concatenation convention.

## Torsor hypotheses and equivalence review

`Action.IsTorsor` means that the action is nonempty and every orbit map
`g ↦ A.act g x` is injective and surjective. It supplies no chosen point of
the torsor and requires no classical choice.

`Action.regularBijectionAction` itself has **no torsor hypothesis on the
target action**. Its only inputs are an ordinary group and an ordinary
action. Right multiplication on the group is bijective because
`GroupData.regularAction_isTorsor` has already been proved from the group
laws. Composing that bijection with an equivariant bijection preserves
bijectivity. Thus this action remains defined even when the type of
equivariant bijections is empty.

The target-torsor hypothesis is needed in the following places:

1. `torsorEvaluationIso` uses it to ensure that the inverse construction,
   `x ↦ (g ↦ A.act g x)`, is an equivariant **bijection**.
2. `regularBijectionAction_isTorsor` uses it to prove nonemptiness,
   injectivity of each orbit map, and surjectivity of each orbit map for
   the source action.

No finite-group, decidable-equality, commutativity, or chosen-base-point
assumption has been added. `torsorEvaluation_equivariant` proves
equivariance for the explicit canonical action. The two inverse laws are
in `torsorEvaluationIso`; together these declarations provide an action
equivalence under the usual convention that an action equivalence is an
equivariant map with an inverse on underlying types. The project does not
export a separately bundled record named `TorsorEquiv`, and no such extra
declaration is being counted.

## Action groupoid and stabilizer review

`Action.groupoid` uses the hom type
`{g : G // A.act g x = y}`. It stores the witnessing group element in
`Type`; the proof that the element carries one point to the other lives
in `Prop`. Consequently distinct witnessing elements remain distinct
arrows.

The identity is witnessed by the group unit. Composition uses the action
law. Inversion applies the inverse group element and uses the inverse and
unit laws. Each groupoid equality is then proved by equality of the
underlying group elements; proof irrelevance for the predicate witnesses
does not discard those elements.

`GroupoidData.automorphismGroup` transfers the groupoid composition,
identity, and inversion laws to its loops. The direction of associativity
is correctly reversed when passing from the chosen groupoid-law field to
the group-law field. The `Action.stabilizerGroup` carrier is definitionally
the stabilizer subtype, so this construction preserves both the carrier
and its group operations.

`Action.homs_properlyFinite` embeds each arrow subtype into the finite
ordinal witnessing subfiniteness of the acting group. This gives
subfiniteness of the arrows, after which the project's constructive
`subfinite_properlyFinite` theorem applies. This argument needs no decision
procedure for the predicate `A.act g x = y`.

## Independent inertia review

The current inertia construction has objects `(x, a)` with
`a : C.Hom x x`. For objects `(x, a)` and `(y, b)`, its arrows are exactly
the `f : C.Hom x y` satisfying

`C.comp f a = C.comp b f`.

This is the ordinary commuting-square condition. The identity satisfies
it by the left and right identity laws. The composition proof combines
the two commuting-square equations using associativity in the correct
order. The inverse proof derives the corresponding equation for
`C.inv f` by inserting `f` followed by its inverse and then canceling
the inverse followed by `f`. It does not assume the automorphisms commute
or that the underlying groupoid has a unique arrow between objects.

All five remaining groupoid laws follow by subtype extensionality from
the corresponding laws of `C`. They preserve the original arrow data.
The construction works at independent object and hom universes.

`InertiaFiniteness.lean` applies
`Orbifolds.Finiteness.properlyFinite_of_injective` to the map forgetting
the commuting-square proof. That map is injective by subtype
extensionality, and its codomain is precisely `C.Hom x y`, to which the
hypothesis applies. The imported closure theorem supplies both explicit
subfinite enumerability and the project's set-level decidable-equality
condition. This proves the stated ordinary hom-finiteness result.

The source-number correction has been checked: **Definition 6.4.3**
defines inertia and **Corollary 6.4.4** asserts orbifold closure.
**Proposition 6.4.2** concerns pullbacks. For documentation, the clearest
description of these Lean files is "ordinary groupoid counterpart of
Definition 6.4.3, with the ordinary arrow-finiteness component associated
with Corollary 6.4.4." The paper proves its corollary via a diagonal
pullback; this implementation does not formalize that internal HoTT
pullback argument.

## Verification and remaining boundaries

Every successful declaration in this workstream was followed by a
confirmed external source checkpoint before proceeding to the next
declaration. Checkpoint 072 contains the completed torsor chain, along
with the earlier action-groupoid, isotropy, stabilizer, finiteness, and
inertia work. The checkpoint pipeline compiled the complete project and
ran the registered declaration axiom audit.

The audit entries for the reviewed fragment depend either on no axioms
or only on Lean's standard `Quot.sound`, used by function extensionality
in the function-valued equivalences and actions. None of these reviewed
entries depends on `Classical.choice`, `propext`, `sorryAx`, or a newly
declared custom axiom. This statement is about this reviewed fragment;
other project modules have their own recorded audit entries.

The ordinary results are useful supporting mathematics for a future
semantic development. They do not supply univalence, cohesive modalities,
the synthetic differential axioms, a Rezk completion, a semantic
interpretation of the paper's theory, or the smooth/orbifold conclusions
that require those foundations. The original request to formalize the
whole paper is therefore still substantially incomplete.

The unused draft `RegularEvaluationEquivariant.lean` in the workstream was
not added to the verified project and is not counted as a checked result.
The required torsor-specialized equivariance theorem is already checked
and included.
