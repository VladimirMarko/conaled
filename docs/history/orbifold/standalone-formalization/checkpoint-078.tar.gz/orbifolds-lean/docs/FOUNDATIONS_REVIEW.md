# Foundations and proof-fidelity review

## Finding and review basis

The development is a checked collection of external mathematics and foundational safeguards. It is **not a completed formalization of the paper's internal cohesive homotopy type theory or its main orbifold theorems**.

This review inspected the Lean sources through checkpoint 034, their registered result descriptions, and the dependency audit for 45 registered declarations. A declaration count includes structures and definitions; it is not a count of formalized paper theorems. The observations below are a mathematical review of that snapshot, not additional registered Lean theorems.

No mismatch was found between the reviewed declarations and their stated external scopes. In particular, the development does not replace nontrivial path spaces with native equality, introduce an inconsistent native smooth-real model, or assume a microlinearity closure theorem as a structure field.

## Meaning of the checked components

| Component | What its declarations establish | Scope still requiring a bridge |
| --- | --- | --- |
| `Orbifolds/Foundations` | Native equality has unique proofs; Boolean negation cannot be native equality transport; a specified classical native Kock/Kock--Lawvere carrier is impossible. | These are safeguards, not a construction of HoTT or SDG. |
| `Orbifolds/Finiteness` | Explicit finite-ordinal, injection, and surjection formulations; the corrected association theorem; the printed-condition counterexample; specified subobject and proper-finiteness arguments. | No crisp contexts or internal cohesive discreteness are supplied. |
| `Orbifolds/External/Compactness` | The external logical DP-compactness formula and constructive derivations of the registered closure and proposition results. | This does not supply a smooth or sheaf interpretation of compactness. |
| `Orbifolds/External` groupoid files | Genuine group and groupoid operations, the action groupoid, automorphism and stabilizer groups, and a concrete example with distinct loops. | No homotopy quotient, univalent delooping, Rezk completion, or smooth orbifold is constructed. |
| `Orbifolds/Category` | Ordinary hom-set orthogonality and its product, pullback, and retract closure, derived from actual universal-property or retraction data. | No internal function objects, generalized-context interpretation, or homotopy universal properties are implemented. |

The action-groupoid arrows are `{g : G // act g x = y}`. Composition retains the group element, and the singleton Boolean action has two provably distinct automorphisms. Thus the construction preserves ordinary isotropy rather than discarding it in an orbit set. Its ordinary arrow description is still distinct from proving an identity-space computation for a homotopy quotient.

The two ordinary categorical APIs use different, internally consistent composition conventions: `GroupoidData.comp` takes the later arrow first; `Category.Cat.comp` takes the earlier arrow first. No adapter between the APIs is currently supplied.

## Foundational limits that must remain visible

**Native equality.** Lean's `Eq` lives in proof-irrelevant `Prop`; its official reference explicitly derives UIP and axiom K. The native guard proofs make this restriction concrete. This does not prevent Lean from formalizing a different object theory or its models. [Lean reference: Propositional Equality](https://lean-lang.org/doc/reference/latest/Basic-Propositions/Propositional-Equality/)

**Native classical smooth geometry.** The Kock/Kock--Lawvere guard takes its algebraic and first-order KL conditions as local hypotheses of an impossibility theorem. It does not postulate their simultaneous existence. Classically, the Kock inverse condition forces square-zero elements to vanish, so the constant-zero map has both zero and one as slopes. The contradiction concerns native carriers and all native functions; internal SDG uses a different logical interpretation. [Paper, section 4.1](https://arxiv.org/html/2205.15887v1#S4.SS1)

**Constructive formulas in a classical ambient system.** The recorded constructive proofs do not use `Classical.choice`; some use Lean's extensionality infrastructure. Nevertheless, Lean permits classical reasoning about those same definitions. Classically, the external `DPCompact K` formula holds for every native `K`: split on its fixed proposition `A`. Likewise, classical choice collapses the finiteness distinctions. Accordingly these modules provide specific constructive logical derivations, not a semantic model in which the paper's noncrisp distinctions remain nontrivial. [Lean: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/)

**Global versus internal maps.** A bijection of ordinary global hom sets is insufficient to certify the paper's internal function-object pullback. An ordinary categorical semantic route must handle all generalized contexts, or use internal function objects with the required universal properties. The higher theory also requires mapping spaces and homotopy limits. The current product and pullback closure proofs are therefore genuine categorical support, without being complete proofs of Proposition 5.0.1. [Paper, definitions 4.2.10--4.2.12](https://arxiv.org/html/2205.15887v1#S4.SS2)

## Two legitimate routes to the full theory

1. **Semantic formalization.** Construct a suitable interpretation of the internal language using explicit categorical and higher structures. Interpret the smooth line, maps, paths, modalities, and crisp restrictions there. An ordinary groupoid or a category of global hom sets covers only part of the required structure.

2. **Deep embedding of the object theory.** Define syntax and judgments for a distinct dependent type theory, with its own identity types, typing and substitution rules, crisp contexts, and stated foundational postulates. Lean can then check derivations in that theory. Object-level univalence would be a specified object-theory rule, not an inconsistent axiom about native `Eq`. This route needs actual well-formed judgments and derivations; listing the paper's target conclusions as axiom constructors would not constitute their formalization. A semantic soundness result would be valuable additional assurance, rather than a substitute for the derivations.

Neither route has been implemented in this snapshot. The checked external modules may support either route, but the necessary interpretation theorems have not been proved.

## Remaining substantial bridges

The full theory still needs a treatment of univalent higher identities, truncations and higher inductive constructions; crisp contexts and cohesive modalities; an internal smooth ring, Weil spectra and infinitesimal test objects; internal microlinearity and coherent tangent structure; crystalline and tiny-type machinery; and the manifold, compactness, descent, and Rezk-completion arguments connecting these ingredients. In particular, the full comparisons and orbifold closure results in sections 5.4, 6.3, and 6.4 remain open in this development. The detailed item and dependency register is `docs/paper_inventory.md`.

## Source corrections and proof trust

The literal association criterion of Proposition 6.1.7 admits a constant relation from `Nat` to `Fin 1`. The development proves both that fact and the non-subfinite-enumerability of `Nat`, then records their counterexample together. The separately proved correction makes each finite index represent at most one point. This correction is explicit and is not counted as a proof of the false printed condition. Other potential source errors and reconstruction concerns retain the qualifications recorded in the inventory. [Paper, section 6.1](https://arxiv.org/html/2205.15887v1#S6.SS1)

The reviewed dependency audit contains only Lean's standard `propext`, `Quot.sound`, and `Classical.choice` where reported; it contains no additional project axioms or `sorryAx`. In particular, the categorical closure theorems and the ordinary action-groupoid construction have no axiom dependencies reported by `#print axioms`. Kernel proof irrelevance remains part of Lean itself even when that command reports no axioms. Exact per-declaration evidence is in `verification/axioms.log`; exact milestone classifications are in `docs/RESULTS.json`.

Coverage should continue to distinguish a whole internal paper result, an external fragment, categorical support, a corrected statement, and a counterexample. An unproved bridge must remain a stated gap rather than becoming a field that assumes the desired paper theorem.
