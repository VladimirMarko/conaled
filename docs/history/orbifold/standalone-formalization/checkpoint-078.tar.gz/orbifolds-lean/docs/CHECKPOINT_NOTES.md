# Checkpoint bookkeeping notes

Every exposed archive has a separately confirmed successful durable upload.
Archives are cumulative source snapshots. A local source archive or local
commit is not treated as a durable save by itself.

## Corrected transient audit bookkeeping

An early checkpoint-script version appended a result record before completing
the axiom audit. One attempted standalone checkpoint for
`subfinitelyEnumerable_of_surjective` passed its individual source check but
the subsequent audit could not resolve that declaration through the umbrella
import. That attempt produced no archive and no claimed durable upload.

The next successful cumulative archive, checkpoint 040 (finite product code),
contained the source and a successful full audit including this declaration.
Its early results ledger retained an extra record from the rejected attempt.
That ledger entry has now been replaced by an independently successful
standalone checkpoint for the same surjection theorem. The Lean proof itself
did not require a change.

The script now rehashes source files for each Lake build and writes new result
records only after the complete axiom audit succeeds. Previous downloadable
archives remain immutable. Their source content and successful audit records
remain available; this note makes the historical ledger correction explicit.

## Source reference corrections after checkpoint 067

The current ledger corrects two citation labels: the generic categorical probes
in checkpoint 015 support Lemma 4.3.10 and Proposition 5.0.1; the inertia
construction in checkpoint 067 corresponds to Definition 6.4.3 and the arrow
calculation underlying Corollary 6.4.4. The Lean definitions and proofs are
unchanged. Earlier confirmed archives remain immutable historical snapshots.

## Citation-kind correction after checkpoint 072

Item 6.2.21 is a lemma in the paper. The SubsingletonCover source comment
and checkpoint-063 ledger now use Lemma 6.2.21. This changes no theorem
statement or proof. The finiteness/compactness review manifest records the
preceding source-comment hash and explicitly calls out this correction.
The inertia comment was also refined to say ordinary counterpart supporting
the finiteness component, without suggesting the source gives our exact
commuting-arrow calculation.

## Final coverage-review clarification

The coverage and inventory descriptions of Proposition 6.2.5 now state both
compactness hypotheses: compact base and compact fibers. The Lean theorem
already had both hypotheses and was not changed. The Definition 6.1.1 and
6.1.3 declaration lists were narrowed to their own predicates rather than
repeating every declaration from the shared checkpoint 006.

The first scaffold checkpoint (000) predates the standardized local receipt
files. Its original durable save was confirmed in the conversation. Its
confirmed file identity remains attached to the local archive; that identity,
its byte count, and its SHA-256 are now included in the unified history.
The newer transport-level file identifier is not reconstructed or invented.
