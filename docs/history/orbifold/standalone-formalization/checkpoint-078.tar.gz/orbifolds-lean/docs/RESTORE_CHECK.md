# Clean source-archive rebuild

The source archive from checkpoint **077** was extracted into a new directory
without a `.lake` build cache. Its SHA-256 was verified before extraction:

`eeab3d6b4879e72aa2d7e2f537b604fcdd788f766f2db6213676e3682e981883`

Every one of the **101 files** in that checkpoint's source manifest matched
its recorded hash. The extraction accepted only ordinary files and directories
under the project root, with no absolute paths or parent-directory traversal.

The following commands then succeeded using the installed official
Lean 4.33.0-rc1 release:

```sh
lake --rehash build
lake env lean Audit.lean
lake env lean FullAudit.lean
```

The first command rebuilt the 68 mathematical/supporting modules and aggregate
import from source. The registered audit covered all 85 declared roots. The
exhaustive audit covered all 337 project-owned declarations, including
generated declarations. Its complete JSON process output was byte-for-byte
identical to the earlier frozen audit, with SHA-256:

`956414c47e8de990fde97be0b9f1c5622b815fd309fd7aa1744103ae8d3bc9bc`

The current handoff contains exactly the same 69 mathematical source files,
checked by SHA-256 against the exhaustive-audit manifest. Changes after the
tested archive are documentation, checkpoint-history reconciliation, and the
captured verification evidence. No mathematical statement or proof changed.

Exact commands, process exits, hashes, and output are retained in
`verification/restore/RESTORE_REPORT.json` and its neighboring `.log` files.
The restored source used the installed pinned toolchain; it did not redownload
the 575 MB toolchain archive. The official archive digest was already checked
during setup and remains recorded in `TOOLCHAIN.json`.

This verifies source reproducibility and proof dependencies. It does not turn
the scoped external formalizations into the paper's still-unimplemented
internal cohesive HoTT theorems. See `COVERAGE.md` and `STATUS.md` for scope.
