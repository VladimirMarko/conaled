# Formalization status

## Completed infrastructure

Lean 4.33.0-rc1 is installed and pinned. The official release archive's SHA-256
was checked. Every accepted source checkpoint passes `lake build`, scans for
proof placeholders and added axioms, and audits the dependencies of its
registered declarations. See `CHECKPOINT.json`, `docs/RESULTS.json`, and
`verification/axioms.log` for the exact state of this particular archive.

The full paper and Appendix A have been read. `docs/paper_inventory.md` and
its JSON counterpart enumerate all 199 numbered items with their dependencies.
The inventory is a scope register, not a claim that every item is formalized.
`docs/COVERAGE.md` and `.json` reconcile 27 items with the exact scoped
external declarations. All complete internal-item statuses remain open.

## What the checked development contains

- Native-foundation guard theorems: equality proof irrelevance, the Boolean
  transport obstruction, and the classical native Kock--Lawvere obstruction.
- Explicit ordinary algebraic groups, actions, and Type-valued groupoid arrows.
- A concrete groupoid example with two distinct automorphisms at one object.
- Constructive finiteness definitions and theorems about ordinary sets.
- A proof and counterexample addressing the printed association error.
- Constructive logical fragments of Dubuc--Penon compactness.
- Categorical universal-property and orthogonality support.

The source contains 68 mathematical/supporting modules plus an aggregate
import and 85 registered declarations. The exhaustive environment audit
inspects 337 project declarations, including generated projections, recursors,
and proof declarations. None of these counts is a paper-theorem count.

The finiteness fragment now includes the constructive external embedding
criterion of Lemma 6.1.8 and all six clauses of Proposition 6.1.9, including
finite dependent disjoint unions and finite unions indexed by `Fin n`.
The torsor fragment proves both inverse laws, equivariance, and the source
torsor property for ordinary regular-action evaluation. The ordinary inertia
construction includes every groupoid law and its arrow-finiteness closure.

All of these are precisely scoped external results or supporting mathematics.
The full internal cohesive HoTT theory is not yet implemented.

## Clean reproduction evidence

Checkpoint 077 was extracted into a new directory, all 101 source-manifest
entries were verified, and the project rebuilt without a prior build cache.
The registered and exhaustive Lean audits both passed. The complete exhaustive
audit output was identical to the earlier frozen capture. All 69 mathematical
source hashes in the current handoff are unchanged from that successful
rebuild. See `docs/RESTORE_CHECK.md` and `verification/restore/`.

## Confirmed source error

Proposition 6.1.7, printed page 54 of the PDF, gives the wrong direction of
uniqueness for its association relation. Its printed condition is satisfied by
Nat, although Nat is not subfinitely enumerable. Both assertions, and their
combined counterexample, are checked. The corrected association theorem is
proved separately and explicitly labeled as a correction.

## Main open work

The paper's identity types, higher inductive types, univalent universes,
crisp contexts, modalities, internal smooth ring and function objects, tiny
types, and their interaction need an explicit semantic model or a deep object
theory embedding with verified derivations. These have not been supplied.

Consequently the full microlinearity and descent results, smooth examples,
elliptic moduli, proper etale comparison theorem 6.3.7, and full orbifold
closure theorems remain unproved here. Ordinary groupoid finiteness or
categorical orthogonality must not be counted as those missing proofs.

## Coverage conventions

- `external-constructive-theorem`: specified ordinary set/logical content,
  with no classical choice; no claim of a cohesive model.
- `external-groupoid-fragment`: an explicit ordinary groupoid counterpart.
- `categorical-support`: genuine categorical reasoning, not the paper's
  internal microlinearity without the required semantic bridge.
- `corrected-external-theorem`: a stated repair to a source condition.
- `refuted-printed-statement`: a checked counterexample to the literal claim.
- `foundational-guard`: prevents a mathematically invalid native translation.
- `not_formalized`: no proof of the complete paper item is claimed.
