#!/usr/bin/env python3
"""Install the pinned official Linux x86-64 Lean release and build this project."""
from pathlib import Path
import hashlib
import platform
import subprocess
import urllib.request

VERSION = "4.33.0-rc1"
SHA256 = "25e7b3e18ec75a4e2529fc23194be8e3cc3183df99b553f870d8a111c7488210"
ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / ".toolchain"
NAME = f"lean-{VERSION}-linux.tar.zst"
URL = f"https://github.com/leanprover/lean4/releases/download/v{VERSION}/{NAME}"

def main():
    if platform.system() != "Linux" or platform.machine() not in {"x86_64", "amd64"}:
        raise SystemExit("Use elan on this platform; see README.md.")
    DEST.mkdir(exist_ok=True)
    archive = DEST / NAME
    if not archive.exists():
        urllib.request.urlretrieve(URL, archive)
    with archive.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != SHA256:
        raise SystemExit(f"Release digest mismatch: {actual}")
    subprocess.run(["tar", "--no-same-owner", "--zstd", "-xf", str(archive),
                    "-C", str(DEST)], check=True)
    bindir = DEST / f"lean-{VERSION}-linux" / "bin"
    subprocess.run([str(bindir / "lean"), "--version"], check=True)
    subprocess.run([str(bindir / "lake"), "build"], cwd=ROOT, check=True)

if __name__ == "__main__":
    main()
