#!/usr/bin/env python3
"""Build, audit, archive, and durably save a single completed milestone.

The upload helper is a caller-supplied current authenticated file-saving helper;
it is not vendored here. Upload success is required before this command succeeds.
Use --archive-only for local archives, which are explicitly NOT durable backups.
The development controller exposes each confirmed archive to the user.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--label", required=True)
    p.add_argument("--lean-bin", required=True)
    p.add_argument("--upload-helper")
    p.add_argument("--archive-only", action="store_true")
    p.add_argument("--source")
    p.add_argument("--destination")
    p.add_argument("--declaration", action="append", default=[])
    p.add_argument("--paper", default="supporting work")
    p.add_argument("--classification", default="supporting")
    args = p.parse_args()
    if not args.archive_only and not args.upload_helper:
        p.error("Durable mode requires --upload-helper")
    if bool(args.source) != bool(args.destination):
        p.error("Supply --source and --destination together")
    out = ROOT.parent / "checkpoints"
    out.mkdir(exist_ok=True)
    with (out / "checkpoint.lock").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        numbers = [int(m.group(1)) for x in out.glob("orbifolds-checkpoint-*.tar.gz")
                   if (m := re.match(r"orbifolds-checkpoint-(\d+)-", x.name))]
        number = max(numbers, default=-1) + 1
        if args.source:
            preflight = subprocess.run([str(Path(args.lean_bin) / "lake"), "env", "lean", args.source],
                                       cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT)
            if preflight.returncode:
                print(preflight.stdout)
                raise SystemExit("Draft did not compile; stable sources were not changed")
            relative = Path(args.destination)
            if relative.is_absolute() or ".." in relative.parts:
                p.error("Destination must stay inside the source project")
            target = ROOT / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(args.source, target)
        modules = sorted(".".join(x.relative_to(ROOT).with_suffix("").parts)
                         for x in (ROOT / "Orbifolds").rglob("*.lean"))
        (ROOT / "Orbifolds.lean").write_text(
            "import Std\n" + "".join(f"import {m}\n" for m in modules))
        for source in [ROOT / "Orbifolds.lean", *(ROOT / "Orbifolds").rglob("*.lean")]:
            body = re.sub(r"/-.*?-/", "", source.read_text(), flags=re.S)
            body = re.sub(r"--[^\n]*", "", body)
            if re.search(r"\b(sorry|admit|axiom)\b", body):
                raise SystemExit(f"Untrusted placeholder or axiom in {source}")
        bindir = Path(args.lean_bin)
        version = subprocess.check_output([str(bindir / "lean"), "--version"], text=True).strip()
        built = subprocess.run([str(bindir / "lake"), "--rehash", "build"], cwd=ROOT,
                               text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if built.returncode:
            print(built.stdout)
            raise SystemExit("Build failed; no successful checkpoint claimed")
        previous = ROOT / "docs" / "RESULTS.json"
        results = json.loads(previous.read_text()) if previous.exists() else []
        results.append({"checkpoint": number, "label": args.label,
                        "declarations": args.declaration, "paper": args.paper,
                        "classification": args.classification})
        all_decls = list(dict.fromkeys(d for r in results for d in r["declarations"]))
        audit_path = ROOT / "Audit.lean"
        audit_path.write_text("import Orbifolds\n" + "".join(f"#print axioms {d}\n" for d in all_decls))
        audit = subprocess.run([str(bindir / "lake"), "env", "lean", "Audit.lean"], cwd=ROOT,
                               text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if audit.returncode or "sorryAx" in audit.stdout:
            print(audit.stdout)
            raise SystemExit("Axiom audit failed; no successful checkpoint claimed")
        proofdeps = re.findall(r"depends on axioms:\s*\[([^]]*)\]", audit.stdout)
        allowed = {"propext", "Classical.choice", "Quot.sound"}
        for deps in proofdeps:
            unexpected = {x.strip() for x in deps.split(",") if x.strip()} - allowed
            if unexpected:
                raise SystemExit(f"Unexpected axiom dependencies: {unexpected}")
        previous.write_text(json.dumps(results, indent=2) + "\n")
        verification = ROOT / "verification"
        verification.mkdir(exist_ok=True)
        (verification / "build.log").write_text(built.stdout)
        (verification / "axioms.log").write_text(audit.stdout)
        stamp = {"number": number, "label": args.label,
                 "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 "lean_version": version, "build_exit": built.returncode,
                 "axiom_audit_exit": audit.returncode, "declarations_audited": len(all_decls),
                 "durability": "See separately confirmed upload receipt; an archive alone is not proof of upload."}
        (ROOT / "CHECKPOINT.json").write_text(json.dumps(stamp, indent=2) + "\n")
        files = [x for x in ROOT.rglob("*") if x.is_file()
                 and not any(t in {".lake", ".toolchain", ".git", "__pycache__"}
                             for t in x.relative_to(ROOT).parts)]
        manifest = {str(x.relative_to(ROOT)): hashlib.sha256(x.read_bytes()).hexdigest()
                    for x in sorted(files) if x.name != "SOURCE_MANIFEST.json"}
        (ROOT / "SOURCE_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
        slug = re.sub(r"[^a-z0-9]+", "-", args.label.lower()).strip("-")[:80]
        archive = out / f"orbifolds-checkpoint-{number:03d}-{slug}.tar.gz"
        def include(info):
            return None if any(t in {".lake", ".toolchain", ".git", "__pycache__"}
                               for t in Path(info.name).parts) else info
        with tarfile.open(archive, "w:gz") as tar:
            tar.add(ROOT, arcname=ROOT.name, filter=include)
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        summary = {"checkpoint": number, "archive": str(archive),
                   "sha256": digest, "size_bytes": archive.stat().st_size,
                   "declarations": args.declaration, "label": args.label,
                   "durable": False}
        if not args.archive_only:
            request = {"uploads": [{"local_path": str(archive), "purpose": "create_library_file",
                                    "library_artifact_type": "other"}]}
            upload = subprocess.run([sys.executable, args.upload_helper],
                                    input=json.dumps(request), text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (out / f"receipt-{number:03d}.log").write_text(upload.stdout + upload.stderr)
            parsed = None
            for line in upload.stdout.splitlines():
                try:
                    candidate = json.loads(line)
                    if "results" in candidate:
                        parsed = candidate
                except (json.JSONDecodeError, TypeError):
                    pass
            if (upload.returncode or not parsed or len(parsed["results"]) != 1 or
                parsed["results"][0].get("status") != "succeeded"):
                print(json.dumps(summary))
                raise SystemExit("Durable save not confirmed; inspect receipt before any retry")
            result = parsed["results"][0]
            if not result.get("local_metadata_applied"):
                raise SystemExit("Upload succeeded but local identity metadata was not confirmed")
            summary.update(durable=True, file_id=result["file_id"],
                           library_file_id=result["library_file_id"])
        (out / f"summary-{number:03d}.json").write_text(json.dumps(summary, indent=2) + "\n")
        print(json.dumps(summary))

if __name__ == "__main__":
    main()
