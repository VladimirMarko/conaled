#!/usr/bin/env python3
"""Regenerate the explicit, conservatively scoped paper-to-Lean coverage map."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

# This map is deliberately curated. A shared word or a dependency is not a
# proof of the full item. Numbers identify immutable source milestones.
COVERAGE = [
    ("Definition 2.1.2", [3], "ordinary support", "Ordinary group operations and laws only; pointed connected deloopings are not implemented."),
    ("Proposition 2.1.3", [52, 62], "ordinary support", "The ordinary torsor predicate and regular torsor are constructed; the univalent delooping theorem is not proved."),
    ("Lemma 2.1.13", [39, 42, 45, 48, 52, 56, 59, 62, 65, 68, 71, 72], "ordinary counterpart proved", "Evaluation at the identity is an explicitly invertible, equivariant map between ordinary torsors. Identifications in a univalent torsor universe are not constructed."),
    ("Definition 2.2.4", [7], "ordinary support", "Ordinary group actions with proved laws; no pointed map between deloopings is asserted."),
    ("Lemma 2.3.2", [16], "ordinary counterpart constructed", "The action groupoid stores an arrow for each group element carrying the source to the target, with every groupoid law proved. No HoTT quotient identity-space equivalence is proved."),
    ("Corollary 2.3.3", [30, 32], "ordinary counterpart constructed", "Automorphism arrows form a group, and action-groupoid loops give the stabilizer group. A native equality proof is not used as an arrow."),
    ("Axiom 3", [9], "invalid interpretation excluded", "A local-hypothesis theorem refutes the proposed classical native carrier with the stated Kock and first-order Kock-Lawvere conditions. It does not refute internal SDG or postulate a model."),
    ("Lemma 4.3.10", [15], "categorical support", "Ordinary unique-extension and orthogonality definitions are available. No equivalence with internal microlinearity is proved."),
    ("Proposition 5.0.1", [20, 27, 29], "categorical support", "Ordinary hom-set orthogonality is closed under binary products, pullbacks, and retracts. Arbitrary homotopy limits, exponentiation, and the semantic microlinearity bridge remain open."),
    ("Definition 6.1.1", [6], "external definitions", "Four native finiteness predicates are defined by finite ordinals, injections, and surjections. These are not interpreted internal cohesive predicates."),
    ("Definition 6.1.3", [6], "external definitions", "Proper finiteness is subfinite enumerability plus proposition-valued decidable equality. Its identification with cohesive discreteness is not proved."),
    ("Lemma 6.1.5", [28], "external constructive implication proved", "Subfinite ordinary types are properly finite. The finite case follows by forgetting the surjectivity component of a finite witness."),
    ("Proposition 6.1.7", [8, 14, 19, 23, 26, 60], "printed statement refuted; corrected counterpart proved", "The printed uniqueness direction has a checked Nat counterexample. With at most one source point per finite label, the characterization and association-transfer assertion are proved constructively."),
    ("Lemma 6.1.8", [66], "external constructive counterpart proved", "Subfinite enumerability is equivalent to embedding into a finitely enumerable ordinary type. The quotient and separating predicate invariant avoid selecting preimages."),
    ("Proposition 6.1.9", [34, 35, 40, 43, 46, 49, 50, 53, 54, 57, 58, 70], "all six external constructive clauses proved", "Subobjects, binary products, pullbacks, Fin-indexed dependent disjoint unions, images into decidable-equality types, and Fin-indexed unions in such a type are covered. Source relation arguments are explicitly corrected."),
    ("Definition 6.2.1", [12, 51], "external definitions", "The native logical DP-compactness and inverse-image properness formulas are defined. Native classical logic makes this compactness formula true of every native type, so no geometric-model claim is made."),
    ("Lemma 6.2.2", [17, 21, 24, 31], "all three external constructive clauses proved", "Finitely enumerable types are DP compact; surjections preserve compactness; compact binary sums have compact summands, for the specified native formulas."),
    ("Warning 6.2.3", [33], "external equivalence proved", "A proposition is DP compact exactly when it is decidable. No undecidable native proposition or internal counterexample is exhibited."),
    ("Proposition 6.2.4", [55, 61], "both external constructive clauses proved", "DP properness is equivalent to compact native equality fibers and is stable under native subtype pullback. The source base-change codomain is corrected to the target."),
    ("Proposition 6.2.5", [13, 64], "external constructive counterpart proved", "A dependent sum with compact base and compact fibers is DP compact; binary products are also explicit."),
    ("Definition 6.2.6", [38], "external definitions", "Native logical predicates for Penon openness and closedness are defined."),
    ("Lemma 6.2.9", [41], "external constructive counterpart proved", "Products of Penon-open native predicates are Penon open."),
    ("Proposition 6.2.17", [44, 47], "external constructive counterpart proved", "A DP-compact native subtype of a DP-separated type is Penon closed, with separatedness an explicit hypothesis."),
    ("Lemma 6.2.21", [63], "combinatorial step proved", "A supplied subsingleton cover with subfinitely enumerable index gives proper finiteness when the ambient type has decidable equality. The geometric construction of the cover and all manifold hypotheses remain open."),
    ("Theorem 6.4.1", [36], "ordinary arrow-finiteness step proved", "An ordinary action of a subfinite group has properly finite action-groupoid arrow types. Microlinearity, crisp discreteness, and the full quotient orbifold theorem remain open."),
    ("Definition 6.4.3", [67], "ordinary counterpart constructed", "The inertia groupoid has object-automorphism pairs and commuting arrows, with all groupoid laws proved. A free homotopy-loop type is not constructed."),
    ("Corollary 6.4.4", [69], "ordinary arrow-finiteness step proved", "Inertia preserves proper finiteness of explicit groupoid arrows. The internal inertia identification and microlinearity conclusion remain open."),
]

def main():
    results = json.loads((ROOT / "docs/RESULTS.json").read_text())
    by_checkpoint = {r["checkpoint"]: r for r in results}
    inventory_path = ROOT / "docs/paper_inventory.json"
    inventory = json.loads(inventory_path.read_text())
    by_label = {e["label"]: e for e in inventory["entries"]}
    entries = []
    for label, checkpoints, scope, detail in COVERAGE:
        original = by_label[label]
        declarations = list(dict.fromkeys(d for n in checkpoints
                                          for d in by_checkpoint[n]["declarations"]))
        if label == "Definition 6.1.1":
            declarations = ["Orbifolds.Finiteness." + n for n in
                ["Finite", "Subfinite", "FinitelyEnumerable", "SubfinitelyEnumerable"]]
        if label == "Definition 6.1.3":
            declarations = ["Orbifolds.Finiteness.HasDecidableEquality", "Orbifolds.Finiteness.ProperlyFinite"]
        entry = {"paper_item": label, "source_url": original["source_url"],
                 "full_internal_item_status": "not_formalized",
                 "external_scope": scope, "details": detail,
                 "checkpoints": checkpoints, "declarations": declarations}
        entries.append(entry)
        original["external_coverage"] = {k: entry[k] for k in
            ["external_scope", "details", "checkpoints", "declarations"]}
    inventory["formalization_status"] = (
        "The complete internal paper items remain not_formalized. The external_coverage "
        "fields record checked external counterparts, fragments, support, and the "
        "counterexample to Proposition 6.1.7; these do not certify a cohesive interpretation.")
    inventory_path.write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n")
    data = {"paper_numbered_items": len(inventory["entries"]),
            "items_with_explicit_external_mapping": len(entries),
            "complete_internal_paper_theorems_claimed": 0,
            "scope_warning": "An external mapping is not a completed internal paper item.",
            "entries": entries}
    (ROOT / "docs/COVERAGE.json").write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    lines = ["# Paper-to-Lean coverage", "",
        "The full 199-item inventory is in `paper_inventory.md` and `.json`. "
        "This file records exactly where checked external mathematics relates to that inventory. "
        "It does not claim a completed internal cohesive HoTT theorem.", "",
        "There are 27 explicit item mappings below. A mapping can be a definition, "
        "a fragment, generic support, or a counterexample; it is not a theorem count. "
        "Every unmapped item remains open in this development.", "",
        "## Scope map", "", "| Paper item | Checked scope | Remaining boundary |",
        "| --- | --- | --- |"]
    for entry in entries:
        label = entry["paper_item"]
        nums = ", ".join(f"{n:03d}" for n in entry["checkpoints"])
        lines.append(f"| [{label}]({entry['source_url']}) | {entry['external_scope']} (checkpoints {nums}) | {entry['details']} |")
    lines += ["", "## Exact declaration index", "",
        "Namespaces below are the names accepted by Lean. `COVERAGE.json` contains the same machine-readable map. "
        "A supporting checkpoint may supply definitions shared by several paper items.", ""]
    for entry in entries:
        lines += [f"### {entry['paper_item']}", ""]
        lines += [f"- `{d}`" for d in entry["declarations"]]
        lines.append("")
    lines += ["## Additional checked support", "",
        "Native equality and Boolean transport guards prevent an invalid identity-space translation. "
        "The concrete Boolean action groupoid has two distinct automorphisms of its sole object. "
        "These supporting results are listed in `RESULTS.json`; the Boolean example is not "
        "represented as one of the paper's unproved smooth examples.", "",
        "## Main theorem remains open", "",
        "Theorem 6.3.7 needs the microlinearity result 5.4.9, the discreteness result 6.3.4, "
        "and the geometric compactness-to-finiteness result 6.2.21. None of these complete "
        "internal results is proved here. The supplied-cover finiteness step does not replace "
        "the geometric hypotheses or their derivation.", ""]
    (ROOT / "docs/COVERAGE.md").write_text("\n".join(lines))
    assert len(entries) == 27
    print(json.dumps({"numbered_items": len(inventory["entries"]), "explicit_external_mappings": len(entries)}))

if __name__ == "__main__":
    main()
