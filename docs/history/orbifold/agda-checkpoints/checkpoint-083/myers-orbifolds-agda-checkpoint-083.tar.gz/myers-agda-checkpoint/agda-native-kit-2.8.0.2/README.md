# Native Agda kit

**Kit 1.0.1 · Agda 2.8.0.2 · Linux x86-64 · 4 November 2026**

This kit installs and runs the unchanged official Agda type checker in a
writable local directory. It needs no root installation, GHC, Cabal, dynamic
loader shim, or global Agda configuration. It follows the supplied Lean kit's
approach of exact toolchain pins, isolated runtime state, real checker tests,
and recoverable installation.

The kit is a small setup archive. The compiler release, external mathematical
libraries, and project proof sources are acquired or restored separately.
Agda's embedded primitive modules are available after setup; the Agda standard
library and other external libraries are not included.

## Quick start

Extract the delivered archive, then run these commands from its parent
directory:

```sh
AGDA_KIT="$(pwd -P)/agda-native-kit-2.8.0.2"
AGDA_STATE="$(pwd -P)/agda-state"
python3 "$AGDA_KIT/agda_native.py" verify
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" setup
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" doctor
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" smoke
```

Keep `AGDA_STATE` outside the kit directory. The kit content manifest describes
immutable delivered files; setup data, checker interfaces, and logs belong in
writable state or the proof project. Pass `--state` before the subcommand.

For a project whose top-level module is `Everything.agda` in `src`:

```sh
AGDA_PROJECT="/absolute/path/to/project"
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" \
  check "$AGDA_PROJECT/src/Everything.agda" --safe -i "$AGDA_PROJECT/src"
```

`check` runs `doctor`, adds `--safe`, rejects flags that weaken the main proof
checks, and rejects unsolved metas and incomplete matches. The explicit
`--safe` in the example is redundant and documents the intended proof policy.

By default the launcher supplies `--no-libraries`, so imports must be reachable through
explicit `-i` paths. An ambient `defaults` or `libraries` file cannot silently
select a different dependency. The built-in and primitive modules remain
available. See the [official library options](https://agda.readthedocs.io/en/v2.8.0.2/tools/command-line-options.html#imports-and-libraries).

For libraries such as Cubical that require scoped compiler flags, instead
create an explicit registry listing only pinned `.agda-lib` files and use:

```sh
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" \
  --library-file /absolute/path/to/project/libraries \
  check "$AGDA_PROJECT/src/Everything.agda" -i "$AGDA_PROJECT/src"
```

This mode supplies `--no-default-libraries` and the explicit registry; it honors
the project and dependency manifests without consulting ambient default
libraries. Do not copy Cubical's flags onto the global command line: doing so
also applies them to Agda's builtins, whose requirements differ. In particular,
global `--no-import-sorts` breaks builtin modules and global `--cubical` can
make `Sigma` incompatible with erased cubical primitive modules. If such an
attempt has already produced interfaces, remove only those generated
`.agdai` files and repeat the scoped check. No source changes are needed.

Version 1.0.1 adds this explicitly selected library mode. The compiler and
embedded setup-data pins are unchanged; a valid 1.0.0 runtime can be reused.

## Requirements and storage

- Linux x86-64 and Python 3.11 or later.
- HTTPS access to the official release for online setup, or a local copy of
  the exact pinned archive for offline setup.
- Approximately 100 MiB of free disk space for a fresh setup, with additional
  room for the proof project and any external libraries. The compiler alone is
  about 55 MiB installed. These are planning estimates, not project quotas.
- Writable state and project directories. No system package manager is used.

The official Linux executable is statically linked. Agda's
[installation instructions](https://agda.readthedocs.io/en/v2.8.0.2/getting-started/installation.html)
confirm that it can check Agda without GHC. The Haskell backend needs a separate
GHC installation to produce native executables; this kit does not bundle or
validate that backend toolchain.

## Exact compiler identity

| Item | Pinned value |
| --- | --- |
| Agda version | `2.8.0.2` |
| Release archive | `Agda-v2.8.0.2-linux.tar.xz` |
| Archive bytes | `8529008` |
| Archive SHA-256 | `2bcf24bb561b1be859bba841e5d67962d1616b3251bc147f878e4f60a2fbd9f7` |
| Executable bytes | `57419152` |
| Executable SHA-256 | `3fe070780fa370f5b74e5716ebe42fb60ec6b0ad90d13f8ab45d2903abf39b84` |

The upstream source is the
[official release](https://github.com/agda/agda/releases/tag/v2.8.0.2), with
download URL
<https://github.com/agda/agda/releases/download/v2.8.0.2/Agda-v2.8.0.2-linux.tar.xz>.
Machine-readable pins and retained release metadata accompany the kit. A
checksum mismatch is an error; changing the expected checksum to accommodate
different bytes is not recovery.

## Commands

All examples below use the same `AGDA_KIT` and `AGDA_STATE` as above.

| Command | Purpose |
| --- | --- |
| `verify` | Verify delivered kit files against the kit content manifest. |
| `setup` | Acquire the pinned release, create isolated runtime state, and run smoke checks. |
| `setup --archive PATH --offline` | Install from an existing exact release archive without downloading. |
| `doctor` | Check the installed compiler and runtime configuration. |
| `smoke` | Run the kit's genuine positive and negative checker examples. |
| `check FILE [AGDA_OPTIONS ...]` | Verify state and type-check a source file in safe mode. |
| `run -- AGDA_OPTIONS ...` | Forward arguments directly to the installed Agda executable. |

`run` is an Agda argument forwarder, not a general shell-command runner. For
example:

```sh
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" run -- --version
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" \
  run -- --print-agda-data-dir
```

The smoke suite accepts an inductive proof of right addition by zero and a
Cubical Agda reflexivity proof. It rejects a false equality, an unsolved hole,
a user postulate, and a `TERMINATING` override in safe mode. Its per-test report
records the actual exit status and diagnostics. A subsequent project proof
check remains a separate obligation.

The state contains `bin/agda`, `data`, `config`, `tmp`, and `logs` directories.
The launcher sets `Agda_datadir` to the existing `data` directory and `AGDA_DIR`
to `config`. This Agda build adds its version directory beneath the data base.
Creating the base directory before `--setup` is essential: an absent override
directory can cause Agda to warn and fall back to user data storage. The kit
performs this preparation. The documented environment variables and setup
option are described in the
[official command-line reference](https://agda.readthedocs.io/en/v2.8.0.2/tools/command-line-options.html#setup-and-information).

Logs record actual checker output and exit status in `logs/latest.json` and
`logs/latest.log`; the log retains at most the last two million characters of
output. `logs/smoke.json` contains the latest smoke report. These records replace
previous results rather than accumulating a history. Save a relevant failure
report before another invocation overwrites it.

## Offline installation and relocation

For offline recovery, retain the exact upstream release archive separately:

```sh
AGDA_ARCHIVE="/absolute/path/to/Agda-v2.8.0.2-linux.tar.xz"
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" \
  setup --archive "$AGDA_ARCHIVE" --offline
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" smoke
```

The thin kit alone cannot supply compiler bytes without network access.
External library source archives must likewise be retained separately if the
proof project requires offline reconstruction.

After moving the kit, state, or project, set the explicit paths again and run
`doctor` and `smoke`, followed by the project's full check. If the old state is
incomplete or inconsistent, use a new state directory and install from the
pinned archive. See [RECOVERY.md](RECOVERY.md).

## External libraries and proof policy

Supply each mathematical dependency at an exact version or commit, preserve
its license and source archive, and add its source directory with `-i`. This
kit does not choose or fetch a mathematical setting. For example, a project
using a separately restored standard-library source tree would add
`-i /absolute/path/to/agda-stdlib/src` to its check command.

Use `--safe` for accepted proof modules and retain normal termination,
positivity, and unsolved-meta checks. A successful toolchain smoke test does
not establish any claim about a later paper formalization. That project must
record its statements, assumptions, checked modules, and outstanding work
separately.

## Recovery checkpoints

Keep the immutable toolchain kit and the latest project checkpoint as separate
deliverables. A useful project checkpoint contains the current sources,
dependency pins, exact check command, latest validation result, and a concise
continuation note. Do not nest prior checkpoints or copy accumulated logs into
the next archive. Reusable compiler and dependency archives can be retained
once and identified by checksum. This keeps checkpoint size proportional to
the current project rather than the number of work sessions.

See [NOTICE.md](NOTICE.md) for upstream provenance and
[the design review](provenance/design-review.md) for the rationale inherited
from the supplied Lean kit.
