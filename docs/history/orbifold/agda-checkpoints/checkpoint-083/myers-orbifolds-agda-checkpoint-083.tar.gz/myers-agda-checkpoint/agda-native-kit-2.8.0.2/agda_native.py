#!/usr/bin/env python3
"""Pinned, rootless Agda checker kit. Python 3.11+, Linux x86-64."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request

KIT = Path(__file__).resolve().parent
PINS = json.loads((KIT / 'pins.json').read_text())

def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def exact(path, size, sha):
    if not path.is_file() or path.stat().st_size != size or digest(path) != sha:
        raise RuntimeError(f'Pinned identity mismatch: {path}')

def available_bytes(path):
    stats = os.statvfs(path)
    # A process already running as uid 0 can use reserved filesystem blocks.
    # No privilege changes or permission changes are performed by this kit.
    blocks = stats.f_bfree if os.geteuid() == 0 else stats.f_bavail
    return blocks * stats.f_frsize

def verify():
    entries = (KIT / 'SHA256SUMS').read_text().splitlines()
    for line in entries:
        sha, name = line.split('  ', 1)
        path = KIT / name
        if not path.resolve().is_relative_to(KIT) or digest(path) != sha:
            raise RuntimeError(f'Kit checksum mismatch: {name}')
    print(f'Kit checksums verified: {len(entries)} files')

def environment(state):
    env = os.environ.copy()
    # Do not repurpose HOME. Every Agda-owned writable location is explicit.
    for name, subdir in [('Agda_datadir', 'data'), ('AGDA_DIR', 'config'), ('TMPDIR', 'tmp')]:
        path = state / subdir
        path.mkdir(parents=True, exist_ok=True)
        env[name] = str(path)
    env.pop('GHC_PACKAGE_PATH', None)
    env.pop('GHC_ENVIRONMENT', None)
    return env

def binary(state):
    path = state / 'bin/agda'
    exact(path, PINS['binary_bytes'], PINS['binary_sha256'])
    return path

def invoke(state, args, label='command', quiet=False, library_file=None):
    exe = binary(state)
    library_args = ['--no-libraries']
    if library_file is not None:
        library_file = Path(library_file).resolve()
        if not library_file.is_file():
            raise RuntimeError('Explicit library registry does not exist')
        library_args = ['--no-default-libraries', '--library-file', str(library_file)]
    cmd = [str(exe), *library_args, *args]
    start = time.monotonic()
    proc = subprocess.run(cmd, env=environment(state), text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logs = state / 'logs'
    logs.mkdir(exist_ok=True)
    # Bounded: one latest command and one smoke report, no accumulating history.
    record = {'command': cmd, 'cwd': str(Path.cwd()), 'exit_code': proc.returncode,
              'elapsed_seconds': round(time.monotonic() - start, 3), 'label': label,
              'agda_binary_sha256': PINS['binary_sha256']}
    (logs / 'latest.json').write_text(json.dumps(record, indent=2) + '\n')
    (logs / 'latest.log').write_text(proc.stdout[-2000000:])
    if not quiet:
        print(proc.stdout, end='', flush=True)
    return proc.returncode, proc.stdout, record

def setup(state, archive, offline):
    if platform.system() != 'Linux' or platform.machine() not in ('x86_64', 'amd64'):
        raise RuntimeError('This pinned release is Linux x86-64 only')
    state.mkdir(parents=True, exist_ok=True)
    exe = state / 'bin/agda'
    if exe.exists():
        binary(state)  # Never replace an unexpected pre-existing executable.
    else:
        if archive:
            source = Path(archive).resolve()
        else:
            source = state / PINS['archive_name']
            if not source.exists():
                if offline:
                    raise RuntimeError('Offline setup requires --archive or a cached exact archive')
                free = available_bytes(state)
                needed = PINS['archive_bytes'] + PINS['binary_bytes'] + 2 * 1024 * 1024
                if free < needed:
                    raise RuntimeError(f'Need at least {needed} free bytes for acquisition/extraction; have {free}')
                part = source.with_suffix(source.suffix + '.part')
                with urllib.request.urlopen(PINS['archive_url'], timeout=60) as src, part.open('wb') as dst:
                    shutil.copyfileobj(src, dst)
                exact(part, PINS['archive_bytes'], PINS['archive_sha256'])
                part.replace(source)
        exact(source, PINS['archive_bytes'], PINS['archive_sha256'])
        if available_bytes(state) < PINS['binary_bytes'] + 1024 * 1024:
            raise RuntimeError('Insufficient disk space for the unchanged binary')
        exe.parent.mkdir(exist_ok=True)
        temp = exe.with_suffix('.part')
        with tarfile.open(source, 'r:xz') as tar:
            members = tar.getmembers()
            if len(members) != 1 or members[0].name != PINS['binary_member'] or not members[0].isreg():
                raise RuntimeError('Unexpected release archive structure')
            with tar.extractfile(members[0]) as src, temp.open('wb') as dst:
                shutil.copyfileobj(src, dst)
        exact(temp, PINS['binary_bytes'], PINS['binary_sha256'])
        temp.chmod(0o755)
        temp.replace(exe)
    environment(state)  # Crucial: pre-create datadir before Agda --setup.
    code, _, _ = invoke(state, ['--setup'], 'setup')
    if code:
        return code
    code, version, _ = invoke(state, ['--numeric-version'], 'version', quiet=True)
    if code or version.strip() != PINS['agda_version']:
        raise RuntimeError('Unexpected compiler version')
    sources = {str(p.relative_to(state)): digest(p)
               for p in sorted((state / 'data').rglob('*')) if p.is_file() and p.suffix != '.agdai'}
    (state / 'receipt.json').write_text(json.dumps({'pins': PINS, 'setup_files': sources}, indent=2) + '\n')
    print('Installed and verified Agda ' + version.strip())
    return smoke(state)

def doctor(state):
    binary(state)
    receipt = json.loads((state / 'receipt.json').read_text())
    if any(receipt['pins'].get(k) != v for k, v in PINS.items() if k != 'kit_version'):
        raise RuntimeError('State receipt was produced by a different pin set')
    for name, sha in receipt['setup_files'].items():
        path = state / name
        if not path.resolve().is_relative_to(state) or digest(path) != sha:
            raise RuntimeError(f'Setup data mismatch: {name}')
    code, output, _ = invoke(state, ['--print-agda-data-dir'], 'doctor', quiet=True)
    expected = state / 'data' / PINS['agda_version']
    if code or Path(output.strip()).resolve() != expected:
        raise RuntimeError('Agda did not select the isolated data directory')
    print('Compiler, embedded setup data, receipt and isolated data path verified')

def smoke(state):
    directory = state / 'smoke'
    directory.mkdir(exist_ok=True)
    prelude = 'open import Agda.Builtin.Nat\nopen import Agda.Builtin.Equality\n'
    tests = {
      'Positive': (True, prelude + '''
cong : {A B : Set} (f : A -> B) {x y : A} -> x ≡ y -> f x ≡ f y
cong f refl = refl
plus-zero : (n : Nat) -> n + zero ≡ n
plus-zero zero = refl
plus-zero (suc n) = cong suc (plus-zero n)
'''),
      'FalseEquality': (False, prelude + 'bad : zero ≡ suc zero\nbad = refl\n'),
      'UnsolvedHole': (False, prelude + 'bad : Nat\nbad = ?\n'),
      'Postulate': (False, 'postulate bad : Set\n'),
      'Nonterminating': (False, prelude + '{-# TERMINATING #-}\nbad : Nat\nbad = bad\n'),
      'Cubical': (True, '''{-# OPTIONS --cubical #-}
open import Agda.Primitive.Cubical
open import Agda.Builtin.Cubical.Path
path-id : {A : Set} (x : A) -> x ≡ x
path-id x i = x
''')}
    report = []
    for name, (accept, body) in tests.items():
        path = directory / (name + '.agda')
        path.write_text(body.replace('{-# OPTIONS --cubical #-}\n', '') if name != 'Cubical' else body)
        code, output, rec = invoke(state, ['--safe', '--ignore-interfaces', '-i', str(directory), str(path)], name, quiet=True)
        # Agda reports rejected source with 42; a signal/crash is not a successful
        # rejection test. Also require a nonempty diagnostic mentioning this file.
        expected_errors = {'FalseEquality': '[UnequalTerms]', 'UnsolvedHole': '[UnsolvedInteractionMetas]',
                           'Postulate': '[SafeFlagPostulate]', 'Nonterminating': '[SafeFlagTerminating]'}
        passed = code == 0 if accept else code == 42 and expected_errors[name] in output
        report.append({'name': name, 'expected_acceptance': accept, 'exit_code': code,
                       'passed': passed, 'output': output, 'elapsed_seconds': rec['elapsed_seconds']})
        print(f'{name}: {"PASS" if passed else "FAIL"} (exit {code}, expected {"accept" if accept else "reject"})')
    (state / 'logs/smoke.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0 if all(r['passed'] for r in report) else 1

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, default=KIT.parent / 'agda-state')
    parser.add_argument('--library-file', type=Path,
                        help='Explicit dependency registry; honors library-scoped flags, disables ambient defaults')
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ['verify', 'doctor', 'smoke']:
        sub.add_parser(name)
    setup_parser = sub.add_parser('setup')
    setup_parser.add_argument('--archive')
    setup_parser.add_argument('--offline', action='store_true')
    for name in ['run', 'check']:
        sub.add_parser(name).add_argument('args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    state = args.state.resolve()
    if args.command == 'verify':
        verify()
        return 0
    if state.is_relative_to(KIT):
        raise RuntimeError('Keep mutable state outside the immutable kit')
    if args.command == 'setup':
        return setup(state, args.archive, args.offline)
    if args.command == 'doctor':
        doctor(state)
        return 0
    if args.command == 'smoke':
        return smoke(state)
    forwarded = args.args
    if forwarded and forwarded[0] == '--':
        forwarded = forwarded[1:]
    if args.command == 'check':
        forbidden = ['--only-scope-checking', '--allow-unsolved-metas', '--allow-incomplete-matches',
                     '--no-termination-check', '--no-positivity-check', '--type-in-type', '--omega-in-omega',
                     '--version', '--numeric-version', '--help', '--setup', '--print-agda-dir',
                     '--print-agda-app-dir', '--print-agda-data-dir', '--emacs-mode',
                     '--interaction', '--interaction-json', '--interactive', '-V', '-I', '-?']
        if any(a.split('=')[0] in forbidden for a in forwarded):
            raise RuntimeError('check refuses flags which weaken proof checking')
        if not any(Path(a).is_file() and (a.endswith('.agda') or '.lagda' in a) for a in forwarded if not a.startswith('-')):
            raise RuntimeError('check requires an existing Agda source file')
        doctor(state)
        forwarded = ['--safe', '--no-allow-unsolved-metas', '--no-allow-incomplete-matches', *forwarded]
    return invoke(state, forwarded, args.command, library_file=args.library_file)[0]

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(2)
