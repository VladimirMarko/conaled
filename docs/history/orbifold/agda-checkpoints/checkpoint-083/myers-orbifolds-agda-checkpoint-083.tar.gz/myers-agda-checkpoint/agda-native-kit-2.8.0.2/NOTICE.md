# Provenance and redistribution notice

This kit was assembled on 2026-11-04 for reproducible local Agda proof checking.
Its launcher, examples, documentation, and validation records describe a
specific deployment of the official Agda 2.8.0.2 Linux x86-64 executable.

## Agda

Agda is developed by the Agda Team and contributors. The compiler is acquired
unchanged from the [official release](https://github.com/agda/agda/releases/tag/v2.8.0.2).
Upstream source and licensing information are available in the
[Agda repository at the pinned release](https://github.com/agda/agda/tree/v2.8.0.2),
including its [LICENSE file](https://github.com/agda/agda/blob/v2.8.0.2/LICENSE).

The thin kit does not redistribute the compiler executable, GHC, the standard
library, or other external mathematical libraries. If retaining or
redistributing those separately, preserve their upstream notices and comply
with their respective licenses, including those of linked third-party
components. This notice does not replace or alter any upstream license.

The kit pins both the downloaded release archive and the extracted executable
by size and SHA-256. Those identities, together with the retained release
metadata, establish which bytes were selected; they are not a claim of an
independent compiler implementation or a proof of compiler correctness.

## Supplied Lean kit

The user supplied
`conaled-unified-native-kit-lean-4.35.0-2026-11-03.tar.gz` as a design reference.
The review retained its ideas of exact acquisition pins, isolated runtime
state, real positive and negative checker tests, and explicit recovery
instructions. This Agda kit does not contain Lean, Lake, Mathlib cache objects,
or the Lean kit's executable-path compatibility adapter.

## Scope of validation

Successful native startup and proof-checking smoke tests establish the recorded
toolchain behavior on the tested environment. They do not certify a later
formalization's mathematical scope or establish native executable compilation
through the unbundled GHC backend. Each proof project must retain its own
statements, assumptions, dependency identities, and check results.
