# Native Agda kit design review

Review date: 2026-11-04. Scope: toolchain bootstrapping and recovery only; no
paper statements or formalization were examined during this phase.

## Selected architecture

Use the unchanged official Agda 2.8.0.2 Linux x86-64 release executable.
The [official installation instructions](https://agda.readthedocs.io/en/v2.8.0.2/getting-started/installation.html)
describe this binary as statically linked and usable without GHC. GHC is needed
only if a later task requires the Haskell backend to build native executables.
Proof checking itself does not require that backend.

Since Agda 2.8, the binary embeds its setup data, including primitive Agda
sources. Use `--setup` and an explicit writable `Agda_datadir` inside the state
directory. Set `AGDA_DIR` to an isolated configuration directory. These are
documented in the [Agda command-line reference](https://agda.readthedocs.io/en/v2.8.0.2/tools/command-line-options.html).
Pass dependency source directories explicitly or maintain a state-local
`libraries` file; do not depend on the user's ambient global defaults.

The initial pin reported from the official release API is:

- Version: `2.8.0.2`.
- Archive: `Agda-v2.8.0.2-linux.tar.xz`.
- Source: <https://github.com/agda/agda/releases/tag/v2.8.0.2>.
- Archive size: `8529008` bytes.
- SHA-256: `2bcf24bb561b1be859bba841e5d67962d1616b3251bc147f878e4f60a2fbd9f7`.

The acquisition process must check downloaded bytes against the pin before
extracting and record the executable's own digest. A pin is provenance, not a
claim that this review has independently rerun the compiler.

## What transfers from the supplied Lean kit

Retain exact artifact identities, an immutable kit separated from mutable
state, safe extraction, explicit environment configuration, actual subprocess
exit codes, reproducible smoke checks, and concise recovery instructions.
Keep generated interface files and evolving project sources out of the
toolchain content manifest. Recovery checkpoints should contain the latest
source state, proof status, restore commands, and dependency pins rather than
nesting previous archives or carrying unbounded logs.

The Lean-specific executable-path adapter, cache relinker, Lake wrappers, and
Mathlib build trees do not transfer automatically. The supplied
`lib/app_path.c` only handles one exact numeric `/proc/<pid>/exe` lookup after
`ENOENT`, and its `ld.so --preload` mechanism targets dynamically linked ELF
programs. It is not an appropriate default for Agda's static binary. Test the
unchanged executable first. A permission error must remain an error; no
compatibility change should manufacture access or weaken proof checking.

## Acceptance checks

1. Verify kit and downloaded artifact hashes and check the expected version.
2. Run setup with writable, isolated data/config directories.
3. Check a genuine recursive theorem with normal termination and positivity
   checking enabled, using `--safe`.
4. Confirm that a deliberately false equality is rejected with nonzero status.
5. Confirm that an unsolved hole and a user postulate are rejected in safe mode.
6. If external libraries are bundled or acquired, import a representative
   module from their exact pinned source revision.
7. Recheck from a relocated kit/state arrangement to detect baked-in paths.

Only actual checker invocations establish these results; mock tests and a
successful version command do not. A release can accurately claim successful
type checking without claiming Haskell compilation or native executable
generation.

## Optional standard library

The [official standard-library installation guide](https://github.com/agda/agda-stdlib/blob/master/doc/installation-guide.md)
currently recommends standard library v2.4 for Agda 2.8.0. Pin the selected
archive or full commit and verify an import rather than following a moving
branch. A later mathematical library may require a different compatible pin;
record and test that choice explicitly.

## Limits

This review recommends Linux x86-64 only. Reported filesystem free space was
small during initial inspection; do not infer usable storage from a successful
download alone. Setup, primitive interfaces, optional libraries, and proof
checking require additional writable space. Static linking avoids host shared
library dependencies but does not guarantee compatibility with every kernel
or restricted runtime. The kit's recorded real smoke results are the relevant
evidence for this environment.
