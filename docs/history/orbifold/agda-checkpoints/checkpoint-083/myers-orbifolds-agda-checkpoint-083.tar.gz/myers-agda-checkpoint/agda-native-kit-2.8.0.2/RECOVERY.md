# Recovery and continuation

These instructions assume the paths `AGDA_KIT`, `AGDA_STATE`, and, where needed,
`AGDA_PROJECT` have been set as in [README.md](README.md). Preserve the latest
relevant output before another command replaces the bounded log files.

## Recover on a fresh workspace

1. Restore this kit and verify its delivered content manifest.
2. Restore the most recent proof-source checkpoint, including its dependency
   pins and continuation note.
3. Choose a writable state directory outside the kit and project sources.
4. Run online setup, or provide the exact retained compiler archive with
   `setup --archive PATH --offline`.
5. Run `doctor` and `smoke`.
6. Restore any project-specific library sources at their recorded versions,
   then run the project's documented full check.

Compiler setup is independent of mathematical proof status. If only a subset
of the paper was checked in the checkpoint, restoring the toolchain does not
turn the remaining statements into completed proofs.

## Download unavailable or interrupted

Retry setup against the same pinned official release when connectivity is
available. Alternatively, use a separately acquired copy of
`Agda-v2.8.0.2-linux.tar.xz` with `--archive` and `--offline`. The archive must
have exactly the size and SHA-256 recorded in `pins.json` and the README.

Do not substitute another release or relax the checksum check. A corrupt or
incomplete archive cannot establish the installed compiler's identity. Keep
the failed archive separately if it is needed to investigate the interruption;
use a clean download or a new state directory for recovery.

## Missing data directory or unexpected user data path

The launcher must create its `data` base directory before assigning
`Agda_datadir` and invoking `--setup`. With this build, a nonexistent override
directory can trigger a warning and fallback to user data storage. The compiler
adds its version directory beneath the selected base.

Use the launcher to inspect the effective path:

```sh
python3 "$AGDA_KIT/agda_native.py" --state "$AGDA_STATE" \
  run -- --print-agda-data-dir
```

The result should be inside the chosen state directory. Rerun setup to create
the expected directories and embedded primitive sources. If an earlier manual
invocation created data elsewhere, that data is not a replacement for the
state-local setup; do not delete unrelated user directories as a repair.

## Hash mismatch or changed installed executable

Stop using the inconsistent state. Retain its diagnostic output and create a
new state directory from the verified pinned release. Do not edit the expected
executable hash, adopt an arbitrary binary from `PATH`, or rename a different
compiler version to make the check pass. Keep project proof sources intact.

If the delivered kit manifest itself fails, re-extract the original kit
archive to a fresh directory and verify it. Legitimate changes to the launcher
belong in a separately versioned and revalidated kit.

## Full disk or incomplete generated interfaces

A fresh setup needs roughly 100 MiB free. The installed compiler alone is
about 55 MiB, and project interfaces and mathematical libraries need further
space. Move the state or project to a sufficiently large writable directory
when necessary.

Generated `.agdai` interfaces are caches, not proof-source checkpoints. Keep
the `.agda` sources and dependency pins. After an interrupted check, use the
same pinned compiler and rerun the project check. If interface state remains
suspect, use Agda's `--ignore-interfaces` for a fresh check of project and
library sources. Removing only positively identified disposable interfaces is
also possible, but this kit does not delete unrelated caches to obtain space.

## Missing external imports

The launcher always supplies `--no-libraries`; it does not consult global
library registration files. Restore each dependency specified by the project
and provide its source root through `-i`. Do not change project imports merely
to make an incomplete environment appear healthy.

The compiler's built-in and primitive modules come from `--setup`; the Agda
standard library, Cubical library, and other mathematical libraries are
separate dependencies. This kit does not include any of them.

## Relocation or changed host

Set all paths again, then run `doctor`, `smoke`, and the project's check. The
supported target is Linux x86-64. The official static binary avoids host shared
library discovery but still needs a compatible execution environment and
writable data directories.

Permission failures are not missing-path compatibility cases. This kit does
not preload a procfs adapter, change access controls, or weaken checking.

## Bounded checkpoint contents

Preserve a current snapshot containing:

- Proof sources, required local dependency sources or exact retrievable pins,
  and build/check scripts.
- The toolchain kit identity and checksum, plus a reference to the retained
  compiler archive when offline recovery is required.
- The latest meaningful validation result, including any failed obligations.
- A short continuation note describing completed work, remaining statements,
  assumptions, and the next useful check.

Exclude prior snapshot archives, redundant compiler installations, generated
interface caches, and unbounded command histories. Replace the checkpoint
contents with the current state as work progresses. A checkpoint is a recovery
snapshot, not a mathematical completion certificate.

## Official references

- [Agda 2.8.0.2 installation](https://agda.readthedocs.io/en/v2.8.0.2/getting-started/installation.html).
- [Setup, data paths, imports, and interface options](https://agda.readthedocs.io/en/v2.8.0.2/tools/command-line-options.html).
- [Pinned upstream release](https://github.com/agda/agda/releases/tag/v2.8.0.2).
