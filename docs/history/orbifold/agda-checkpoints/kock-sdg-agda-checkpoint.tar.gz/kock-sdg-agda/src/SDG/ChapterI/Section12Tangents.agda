{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12Tangents where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Algebras
open import SDG.Algebra.DualNumbers using (RingHom)
import SDG.Algebra.Derivations as Der
import SDG.Algebra.RelativeDerivations as RD
import SDG.Algebra.RelativeDual as Dual
open import SDG.Axiom
import SDG.Calculus.Slope as SL
import SDG.ChapterI.Section01 as S1
import SDG.ChapterI.Section01Algebra as S1A
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8
import SDG.Schemes.Reflexivity as Ref
open import SDG.Schemes.Extensionality
open import SDG.Schemes.Isomorphism

-- I.12.4, I.12.5 and Exercise I.12.2. These statements need only KL and
-- reflexivity of M. The comprehensive axiom supplies reflexivity of affine
-- schemes in Section12; KL is kept explicit until its derivation in I.16.
module Comparison {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext : FunExt ℓ ℓ) (M : Set ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open SL.Results A K
  open S1.Results A K using (slope-affine; affine-at-zero)
  open S7.Basics A setR
  open S8.Basics A setR hiding (Isomorphism)
  open S7L.ModuleMap
  open Ref.Reflexivity A ext setR

  Functions : RAlgebra A ℓ
  Functions = functionAlgebra A M ext

  FunctionModule : RModule A ℓ
  FunctionModule = Der.algebraModule A (ring Functions) (unit Functions)

  LinearFunctional : Set ℓ
  LinearFunctional = S7L.ModuleMap A FunctionModule (scalarModule A)

  PointDerivation : M → Set ℓ
  PointDerivation m = RD.Relative.Derivation A Functions (scalarAlgebra A) (evaluation A M ext m)

  module Algebraic = Dual.Correspondence A Functions (scalarAlgebra A)
  module FirstOrder = S1A.Results.Extensional A K ext

  dual-to-functions : AlgHom (dualAlgebra (scalarAlgebra A)) (functionAlgebra A D ext)
  dual-to-functions = algebra-hom FirstOrder.alpha-hom
    (λ r → ext (S1A.Results.encode-scalar A K r))

  functions-to-dual : AlgHom (functionAlgebra A D ext) (dualAlgebra (scalarAlgebra A))
  functions-to-dual = algebra-hom FirstOrder.inverse-hom
    (λ r → cong (r ,_) (slope-constant r))

  -- The map of Exercise 12.2 / equation (12.5), with its R-algebra laws.
  path-dual : (D → M) → AlgHom Functions (dualAlgebra (scalarAlgebra A))
  path-dual t = composeAlgHom functions-to-dual (precomposition A ext t)

  base-functional : (D → M) → LinearFunctional
  apply (base-functional t) f = f (t zeroD)
  preserves-zero (base-functional t) = refl
  preserves-add (base-functional t) f g = refl
  preserves-scale (base-functional t) r f = refl

  slope-functional : (D → M) → LinearFunctional
  apply (slope-functional t) f = slope (f ∘ t)
  preserves-zero (slope-functional t) = slope-constant 0r
  preserves-add (slope-functional t) f g = slope-add (f ∘ t) (g ∘ t)
  preserves-scale (slope-functional t) r f = slope-scale r (f ∘ t)

  path-observations : (D → M) → LinearFunctional × LinearFunctional
  path-observations t = base-functional t , slope-functional t

  tangent-derivation : {m : M} → Tangent M m → PointDerivation m
  tangent-derivation {m} t = Algebraic.fromDualOver (evaluation A M ext m)
    (path-dual (curve t)) (λ f → cong f (based t))

  tangent-derivation-evaluates : {m : M} (t : Tangent M m) (f : M → R) →
    RD.Relative.run (tangent-derivation t) f ≡ slope (f ∘ curve t)
  tangent-derivation-evaluates t f = refl

  module ReflexiveComparison (reflexive : Reflexive M) where
    private
      setM : isSet M
      setM = reflexive-set reflexive

    path-observations-injective : (t u : D → M) → path-observations t ≡ path-observations u → t ≡ u
    path-observations-injective t u p = ext (λ d → points-detected reflexive (t d) (u d) (λ f →
      trans (expansion (f ∘ t) d)
        (trans (cong₂ _+_ (cong (λ z → apply (fst z) f) p)
          (cong (value d *_) (cong (λ z → apply (snd z) f) p)))
          (sym (expansion (f ∘ u) d)))))

    path-dual-injective : (t u : D → M) → path-dual t ≡ path-dual u → t ≡ u
    path-dual-injective t u p = ext (λ d → points-detected reflexive (t d) (u d) (λ f →
      trans (expansion (f ∘ t) d)
        (trans (cong₂ _+_ (cong (λ h → fst (algMap h f)) p)
          (cong (value d *_) (cong (λ h → snd (algMap h f)) p)))
          (sym (expansion (f ∘ u) d)))))

    derivation-hom : (m : M) → PointDerivation m → AlgHom Functions (functionAlgebra A D ext)
    derivation-hom m δ = composeAlgHom dual-to-functions (Algebraic.encode (evaluation A M ext m) δ)

    derivation-path : (m : M) → PointDerivation m → D → M
    derivation-path m δ = maps-from-hom reflexive D (derivation-hom m δ)

    derivation-path-evaluates : (m : M) (δ : PointDerivation m) (f : M → R) (d : D) →
      f (derivation-path m δ d) ≡ f m + value d * RD.Relative.run δ f
    derivation-path-evaluates m δ f d = cong (λ h → algMap h f d)
      (precomposition-from-hom reflexive D (derivation-hom m δ))

    derivation-based : (m : M) (δ : PointDerivation m) → derivation-path m δ zeroD ≡ m
    derivation-based m δ = points-detected reflexive (derivation-path m δ zeroD) m (λ f →
      trans (derivation-path-evaluates m δ f zeroD) (affine-at-zero (f m) (RD.Relative.run δ f)))

    derivation-tangent : (m : M) → PointDerivation m → Tangent M m
    derivation-tangent m δ = tangent (derivation-path m δ) (derivation-based m δ)

    derivation-roundtrip : (m : M) (δ : PointDerivation m) → tangent-derivation (derivation-tangent m δ) ≡ δ
    derivation-roundtrip m δ = RD.Native.derivation-ext A Functions (scalarAlgebra A)
      (evaluation A M ext m) ext ext ext setR (λ f →
        trans (slope-cong (f ∘ derivation-path m δ)
          (λ d → f m + value d * RD.Relative.run δ f) (derivation-path-evaluates m δ f))
          (slope-affine (f m) (RD.Relative.run δ f)))

    tangent-roundtrip : {m : M} (t : Tangent M m) → derivation-tangent m (tangent-derivation t) ≡ t
    tangent-roundtrip {m} t = tangent-ext ext setM (λ d →
      points-detected reflexive (derivation-path m (tangent-derivation t) d) (curve t d) (λ f →
        trans (derivation-path-evaluates m (tangent-derivation t) f d)
          (trans (cong (_+ (value d * slope (f ∘ curve t))) (sym (cong f (based t))))
            (sym (expansion (f ∘ curve t) d)))))

    -- Corollary 12.4 as an identity-valued isomorphism of the actual fiber.
    tangent-derivation-isomorphism : (m : M) → Isomorphism (Tangent M m) (PointDerivation m)
    tangent-derivation-isomorphism m = isomorphism tangent-derivation (derivation-tangent m)
      tangent-roundtrip (derivation-roundtrip m)

    module Diff = Der.Derivations A (ring Functions) (unit Functions)

    evaluate-derivation : Diff.Derivation → (m : M) → PointDerivation m
    RD.Relative.run (evaluate-derivation δ m) f = Diff.apply δ f m
    RD.Relative.additive (evaluate-derivation δ m) f g = cong (λ h → h m) (Diff.additive δ f g)
    RD.Relative.homogeneous (evaluate-derivation δ m) r f = cong (λ h → h m) (Diff.homogeneous δ r f)
    RD.Relative.leibniz (evaluate-derivation δ m) f g = cong (λ h → h m) (Diff.leibniz δ f g)

    field-derivation : VectorField M → Diff.Derivation
    Diff.Op.run (Diff.operator (field-derivation X)) f m =
      RD.Relative.run (tangent-derivation (field-section X m)) f
    Diff.Op.additive (Diff.operator (field-derivation X)) f g =
      ext (λ m → RD.Relative.additive (tangent-derivation (field-section X m)) f g)
    Diff.Op.homogeneous (Diff.operator (field-derivation X)) r f =
      ext (λ m → RD.Relative.homogeneous (tangent-derivation (field-section X m)) r f)
    Diff.leibniz (field-derivation X) f g =
      ext (λ m → RD.Relative.leibniz (tangent-derivation (field-section X m)) f g)

    derivation-field : Diff.Derivation → VectorField M
    derivation-field δ = section-field (λ m → derivation-tangent m (evaluate-derivation δ m))

    derivation-field-roundtrip : (δ : Diff.Derivation) → field-derivation (derivation-field δ) ≡ δ
    derivation-field-roundtrip δ = Der.Native.derivation-ext A (ring Functions) (unit Functions)
      ext ext (function-set ext (λ _ → setR)) (λ f → ext (λ m →
        cong (λ q → RD.Relative.run q f) (derivation-roundtrip m (evaluate-derivation δ m))))

    field-derivation-roundtrip : (X : VectorField M) → derivation-field (field-derivation X) ≡ X
    field-derivation-roundtrip X = field-ext ext setM (λ m d →
      trans (cong (λ δ → curve (derivation-tangent m δ) d)
        (RD.Native.derivation-ext A Functions (scalarAlgebra A) (evaluation A M ext m)
          ext ext ext setR
          {δ = evaluate-derivation (field-derivation X) m}
          {ε = tangent-derivation (field-section X m)} (λ f → refl)))
        (cong (λ t → curve t d) (tangent-roundtrip (field-section X m))))

    -- Corollary 12.5. This comparison has the exact underlying operator
    -- X ↦ (f ↦ (m ↦ slope(d ↦ f(X(m,d))))) used in (11.7).
    vectorfield-derivation-isomorphism : Isomorphism (VectorField M) Diff.Derivation
    vectorfield-derivation-isomorphism = isomorphism field-derivation derivation-field
      field-derivation-roundtrip derivation-field-roundtrip

    comparison-formula : (X : VectorField M) (f : M → R) (m : M) →
      Diff.apply (field-derivation X) f m ≡ slope (λ d → f (run X m d))
    comparison-formula X f m = refl
