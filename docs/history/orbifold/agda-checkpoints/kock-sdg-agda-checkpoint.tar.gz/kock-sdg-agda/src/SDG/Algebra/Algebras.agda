{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Algebras where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom; ring-hom; module DualNumbers)
open import SDG.Algebra.FunctionRing using (functionRing)

identityRingHom : {a : Level} (A : CRing a) → RingHom A A
identityRingHom A = record
  { hom = id; pres-0 = refl; pres-1 = refl
  ; pres-+ = λ _ _ → refl; pres-* = λ _ _ → refl; pres-neg = λ _ → refl }

composeRingHom : {a b c : Level} {A : CRing a} {B : CRing b} {C : CRing c} →
  RingHom B C → RingHom A B → RingHom A C
composeRingHom g f = record
  { hom = λ x → RingHom.hom g (RingHom.hom f x)
  ; pres-0 = trans (cong (RingHom.hom g) (RingHom.pres-0 f)) (RingHom.pres-0 g)
  ; pres-1 = trans (cong (RingHom.hom g) (RingHom.pres-1 f)) (RingHom.pres-1 g)
  ; pres-+ = λ x y → trans (cong (RingHom.hom g) (RingHom.pres-+ f x y))
      (RingHom.pres-+ g (RingHom.hom f x) (RingHom.hom f y))
  ; pres-* = λ x y → trans (cong (RingHom.hom g) (RingHom.pres-* f x y))
      (RingHom.pres-* g (RingHom.hom f x) (RingHom.hom f y))
  ; pres-neg = λ x → trans (cong (RingHom.hom g) (RingHom.pres-neg f x))
      (RingHom.pres-neg g (RingHom.hom f x))
  }

record RAlgebra {a : Level} (A : CRing a) (c : Level) : Set (lsuc (a ⊔ c)) where
  constructor algebra
  field
    ring : CRing c
    unit : RingHom A ring
open RAlgebra public

record AlgHom {a c d : Level} {A : CRing a}
  (C : RAlgebra A c) (D : RAlgebra A d) : Set (a ⊔ c ⊔ d) where
  constructor algebra-hom
  field
    ringHom : RingHom (ring C) (ring D)
    commutes : (r : CRing.R A) →
      RingHom.hom ringHom (RingHom.hom (unit C) r) ≡ RingHom.hom (unit D) r
open AlgHom public

algMap : {a c d : Level} {A : CRing a} {C : RAlgebra A c} {D : RAlgebra A d} →
  AlgHom C D → CRing.R (ring C) → CRing.R (ring D)
algMap f = RingHom.hom (ringHom f)

identityAlgHom : {a c : Level} {A : CRing a} (C : RAlgebra A c) → AlgHom C C
identityAlgHom C = algebra-hom (identityRingHom (ring C)) (λ _ → refl)

composeAlgHom : {a b c d : Level} {A : CRing a}
  {B : RAlgebra A b} {C : RAlgebra A c} {D : RAlgebra A d} →
  AlgHom C D → AlgHom B C → AlgHom B D
composeAlgHom g f = algebra-hom (composeRingHom (ringHom g) (ringHom f))
  (λ r → trans (cong (algMap g) (commutes f r)) (commutes g r))

ringHom-path : {c d : Level} {C : CRing c} {D : CRing d} →
  FunExt c d → FunExt c (c ⊔ d) → isSet (CRing.R D) →
  {f g : RingHom C D} → RingHom.hom f ≡ RingHom.hom g → f ≡ g
ringHom-path ext ext₂ setD {ring-hom f p₀ p₁ pa pm pn} {ring-hom .f q₀ q₁ qa qm qn} refl
  with setD _ _ p₀ q₀ | setD _ _ p₁ q₁ |
       ext₂ (λ x → ext (λ y → setD _ _ (pa x y) (qa x y))) |
       ext₂ (λ x → ext (λ y → setD _ _ (pm x y) (qm x y))) |
       ext (λ x → setD _ _ (pn x) (qn x))
... | refl | refl | refl | refl | refl = refl

ringHom-ext : {c d : Level} {C : CRing c} {D : CRing d} →
  FunExt c d → FunExt c (c ⊔ d) → isSet (CRing.R D) → {f g : RingHom C D} →
  ((x : CRing.R C) → RingHom.hom f x ≡ RingHom.hom g x) → f ≡ g
ringHom-ext ext ext₂ setD p = ringHom-path ext ext₂ setD (ext p)

algHom-path : {a c d : Level} {A : CRing a} {C : RAlgebra A c} {D : RAlgebra A d} →
  FunExt a d → isSet (CRing.R (ring D)) → {f g : AlgHom C D} → ringHom f ≡ ringHom g → f ≡ g
algHom-path ext setD {algebra-hom f p} {algebra-hom .f q} refl =
  cong (algebra-hom f) (ext (λ r → setD _ _ (p r) (q r)))

algHom-ext : {a c d : Level} {A : CRing a} {C : RAlgebra A c} {D : RAlgebra A d} →
  FunExt c d → FunExt c (c ⊔ d) → FunExt a d → isSet (CRing.R (ring D)) → {f g : AlgHom C D} →
  ((x : CRing.R (ring C)) → algMap f x ≡ algMap g x) → f ≡ g
algHom-ext extC ext₂ extA setD p = algHom-path extA setD (ringHom-ext extC ext₂ setD p)

scalarAlgebra : {a : Level} (A : CRing a) → RAlgebra A a
scalarAlgebra A = algebra A (identityRingHom A)

functionAlgebra : {a : Level} (A : CRing a) (X : Set a) → FunExt a a → RAlgebra A a
functionAlgebra A X ext = algebra (functionRing A X ext) record
  { hom = λ r _ → r
  ; pres-0 = refl; pres-1 = refl
  ; pres-+ = λ _ _ → refl; pres-* = λ _ _ → refl; pres-neg = λ _ → refl }

dualAlgebra : {a c : Level} {A : CRing a} → RAlgebra A c → RAlgebra A c
dualAlgebra C = algebra (DualNumbers.dualRing (ring C))
  (composeRingHom (DualNumbers.scalar-hom (ring C)) (unit C))

dualBase : {a c : Level} {A : CRing a} (C : RAlgebra A c) → AlgHom (dualAlgebra C) C
dualBase C = algebra-hom (DualNumbers.constant-part (ring C)) (λ _ → refl)

evaluation : {a : Level} (A : CRing a) (X : Set a) (ext : FunExt a a)
  (x : X) → AlgHom (functionAlgebra A X ext) (scalarAlgebra A)
evaluation A X ext x = algebra-hom record
  { hom = λ f → f x
  ; pres-0 = refl; pres-1 = refl
  ; pres-+ = λ _ _ → refl; pres-* = λ _ _ → refl; pres-neg = λ _ → refl }
  (λ _ → refl)

precomposition : {a : Level} (A : CRing a) {X Y : Set a} (ext : FunExt a a) →
  (X → Y) → AlgHom (functionAlgebra A Y ext) (functionAlgebra A X ext)
precomposition A ext h = algebra-hom record
  { hom = λ f x → f (h x)
  ; pres-0 = refl; pres-1 = refl
  ; pres-+ = λ _ _ → refl; pres-* = λ _ _ → refl; pres-neg = λ _ → refl }
  (λ _ → refl)
