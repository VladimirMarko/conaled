{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.LieTransfer where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Endomorphisms using (LieAlgebra)
import SDG.Algebra.Endomorphisms as E

-- Transport of the proved operator Lie identities through a faithful linear
-- representation. The source bracket is given, but none of its laws is assumed.
module Transfer {a u v : Level} (A : CRing a) (Umod : RModule A u) (Vmod : RModule A v)
  (embedding : RModule.V Umod → E.Endomorphisms.End A Vmod)
  (br : RModule.V Umod → RModule.V Umod → RModule.V Umod)
  (preserves-zero : E.Endomorphisms._≈_ A Vmod (embedding (RModule.0v Umod)) (E.Endomorphisms.zeroEnd A Vmod))
  (preserves-add : (x y : RModule.V Umod) → E.Endomorphisms._≈_ A Vmod
    (embedding (RModule._+v_ Umod x y)) (E.Endomorphisms.add A Vmod (embedding x) (embedding y)))
  (preserves-scale : (r : CRing.R A) (x : RModule.V Umod) → E.Endomorphisms._≈_ A Vmod
    (embedding (RModule._•_ Umod r x)) (E.Endomorphisms.scale A Vmod r (embedding x)))
  (preserves-bracket : (x y : RModule.V Umod) → E.Endomorphisms._≈_ A Vmod
    (embedding (br x y)) (E.Endomorphisms.bracket A Vmod (embedding x) (embedding y)))
  (faithful : (x y : RModule.V Umod) →
    E.Endomorphisms._≈_ A Vmod (embedding x) (embedding y) → x ≡ y) where
  open ModuleLemmas A Umod
  module Op = E.Endomorphisms A Vmod
  module T = RModule Vmod

  -- Keep proof bodies opaque when this generic result is instantiated.
  abstract
    bracket-addˡ : (x y z : V) → br (x +v y) z ≡ br x z +v br y z
    bracket-addˡ x y z = faithful (br (x +v y) z) (br x z +v br y z) (λ w →
      trans (preserves-bracket (x +v y) z w)
        (trans (Op.bracket-cong {f = embedding (x +v y)} {f′ = Op.add (embedding x) (embedding y)}
          {g = embedding z} {g′ = embedding z} (preserves-add x y) (λ _ → refl) w)
          (trans (Op.bracket-addˡ (embedding x) (embedding y) (embedding z) w)
            (sym (trans (preserves-add (br x z) (br y z) w)
              (cong₂ T._+v_ (preserves-bracket x z w) (preserves-bracket y z w)))))))

    bracket-addʳ : (x y z : V) → br x (y +v z) ≡ br x y +v br x z
    bracket-addʳ x y z = faithful (br x (y +v z)) (br x y +v br x z) (λ w →
      trans (preserves-bracket x (y +v z) w)
        (trans (Op.bracket-cong {f = embedding x} {f′ = embedding x}
          {g = embedding (y +v z)} {g′ = Op.add (embedding y) (embedding z)}
          (λ _ → refl) (preserves-add y z) w)
          (trans (Op.bracket-addʳ (embedding x) (embedding y) (embedding z) w)
            (sym (trans (preserves-add (br x y) (br x z) w)
              (cong₂ T._+v_ (preserves-bracket x y w) (preserves-bracket x z w)))))))

    bracket-scaleˡ : (r : R) (x y : V) → br (r • x) y ≡ r • br x y
    bracket-scaleˡ r x y = faithful (br (r • x) y) (r • br x y) (λ w →
      trans (preserves-bracket (r • x) y w)
        (trans (Op.bracket-cong {f = embedding (r • x)} {f′ = Op.scale r (embedding x)}
          {g = embedding y} {g′ = embedding y} (preserves-scale r x) (λ _ → refl) w)
          (trans (Op.bracket-scaleˡ r (embedding x) (embedding y) w)
            (sym (trans (preserves-scale r (br x y) w)
              (cong (T._•_ r) (preserves-bracket x y w)))))))

    bracket-scaleʳ : (r : R) (x y : V) → br x (r • y) ≡ r • br x y
    bracket-scaleʳ r x y = faithful (br x (r • y)) (r • br x y) (λ w →
      trans (preserves-bracket x (r • y) w)
        (trans (Op.bracket-cong {f = embedding x} {f′ = embedding x}
          {g = embedding (r • y)} {g′ = Op.scale r (embedding y)}
          (λ _ → refl) (preserves-scale r y) w)
          (trans (Op.bracket-scaleʳ r (embedding x) (embedding y) w)
            (sym (trans (preserves-scale r (br x y) w)
              (cong (T._•_ r) (preserves-bracket x y w)))))))

    alternating : (x : V) → br x x ≡ 0v
    alternating x = faithful (br x x) 0v (λ w → trans (preserves-bracket x x w)
      (trans (Op.bracket-alternating (embedding x) w) (sym (preserves-zero w))))

    skew : (x y : V) → br x y +v br y x ≡ 0v
    skew x y = faithful (br x y +v br y x) 0v (λ w →
      trans (preserves-add (br x y) (br y x) w)
        (trans (cong₂ T._+v_ (preserves-bracket x y w) (preserves-bracket y x w))
          (trans (Op.bracket-skew (embedding x) (embedding y) w) (sym (preserves-zero w)))))

    nested : (x y z : V) → embedding (br x (br y z)) Op.≈
      Op.bracket (embedding x) (Op.bracket (embedding y) (embedding z))
    nested x y z w = trans (preserves-bracket x (br y z) w)
      (Op.bracket-cong {f = embedding x} {f′ = embedding x}
        {g = embedding (br y z)} {g′ = Op.bracket (embedding y) (embedding z)}
        (λ _ → refl) (preserves-bracket y z) w)

    jacobi : (x y z : V) → (br x (br y z) +v br y (br z x)) +v br z (br x y) ≡ 0v
    jacobi x y z = faithful ((br x (br y z) +v br y (br z x)) +v br z (br x y)) 0v (λ w →
      trans (preserves-add (br x (br y z) +v br y (br z x)) (br z (br x y)) w)
        (trans (cong (λ t → T._+v_ t (Op.run (embedding (br z (br x y))) w))
          (preserves-add (br x (br y z)) (br y (br z x)) w))
          (trans (cong₂ T._+v_ (cong₂ T._+v_ (nested x y z w) (nested y z x w)) (nested z x y w))
            (trans (Op.bracket-jacobi (embedding x) (embedding y) (embedding z) w)
              (sym (preserves-zero w))))))

  lieAlgebra : LieAlgebra A Umod
  lieAlgebra = record
    { bracket = br
    ; bracket-addˡ = bracket-addˡ
    ; bracket-addʳ = bracket-addʳ
    ; bracket-scaleˡ = bracket-scaleˡ
    ; bracket-scaleʳ = bracket-scaleʳ
    ; alternating = alternating
    ; skew = skew
    ; jacobi = jacobi
    }

