{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16Comparison where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Finite using (Fin)
open import SDG.Schemes.Extensionality
open import SDG.Schemes.Isomorphism
import SDG.ChapterI.Section12 as S12

-- The algebraic comparison argument underlying Theorem 16.1. The inputs
-- describe an actual algebraic realization of a finite presentation:
-- generators satisfying its equations, evaluation at each scalar
-- solution, and algebraic generation. They contain no assumption about
-- arbitrary functions on the spectrum. The inverse to their evaluation
-- map is constructed from Axiom 2 below.
module Comparison {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
  open Presentations k
  open S12.Comprehensive k A base ext ext0 setR
  open Consequences Ax
  open Axiom2 Ax

  record AlgebraicRealization (B : Presentation) : Set (lsuc ℓ) where
    field
      model-algebra : RAlgebra A ℓ
      set-carrier : isSet (CRing.R (ring model-algebra))
      generic-point : SpecC model-algebra B
      character : (x : Affine B) → AlgHom model-algebra (scalarAlgebra A)
      evaluate-generator : (x : Affine B) (i : Fin (generators B)) →
        algMap (character x) (coordinates generic-point i) ≡ coordinates x i
      generated : (f g : AlgHom model-algebra model-algebra) →
        ((i : Fin (generators B)) →
          algMap f (coordinates generic-point i) ≡ algMap g (coordinates generic-point i)) → f ≡ g
  open AlgebraicRealization public

  module Realized (B : Presentation) (E : AlgebraicRealization B) where
    private
      C = model-algebra E
      Functions = functionAlgebra A (Affine B) ext

    alpha : AlgHom C Functions
    RingHom.hom (ringHom alpha) c x = algMap (character E x) c
    RingHom.pres-0 (ringHom alpha) = ext (λ x → RingHom.pres-0 (ringHom (character E x)))
    RingHom.pres-1 (ringHom alpha) = ext (λ x → RingHom.pres-1 (ringHom (character E x)))
    RingHom.pres-+ (ringHom alpha) c d = ext (λ x → RingHom.pres-+ (ringHom (character E x)) c d)
    RingHom.pres-* (ringHom alpha) c d = ext (λ x → RingHom.pres-* (ringHom (character E x)) c d)
    RingHom.pres-neg (ringHom alpha) c = ext (λ x → RingHom.pres-neg (ringHom (character E x)) c)
    commutes alpha r = ext (λ x → commutes (character E x) r)

    beta : AlgHom Functions C
    beta = inverse-canonical B C (set-carrier E) (generic-point E)

    alpha-generator : (i : Fin (generators B)) →
      algMap alpha (coordinates (generic-point E) i) ≡ coordinate-function B i
    alpha-generator i = ext (λ x → evaluate-generator E x i)

    beta-generator : (i : Fin (generators B)) →
      algMap beta (coordinate-function B i) ≡ coordinates (generic-point E) i
    beta-generator i = cong (λ x → coordinates x i)
      (canonical-inverse B C (set-carrier E) (generic-point E))

    alpha-beta : composeAlgHom alpha beta ≡ identityAlgHom Functions
    alpha-beta = canonical-injective B Functions (function-set ext (λ _ → setR))
      (spec-path ext0 (function-set ext (λ _ → setR)) (λ i →
        trans (cong (algMap alpha) (beta-generator i)) (alpha-generator i)))

    beta-alpha : composeAlgHom beta alpha ≡ identityAlgHom C
    beta-alpha = generated E (composeAlgHom beta alpha) (identityAlgHom C)
      (λ i → trans (cong (algMap beta) (alpha-generator i)) (beta-generator i))

    comparison-isomorphism : Isomorphism (CRing.R (ring C)) (Affine B → CRing.R A)
    comparison-isomorphism = isomorphism (algMap alpha) (algMap beta)
      (λ c → cong (λ h → algMap h c) beta-alpha)
      (λ f → cong (λ h → algMap h f) alpha-beta)
