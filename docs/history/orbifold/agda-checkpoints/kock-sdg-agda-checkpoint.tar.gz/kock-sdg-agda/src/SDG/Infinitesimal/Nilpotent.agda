{-# OPTIONS --safe --without-K #-}
module SDG.Infinitesimal.Nilpotent where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (_+ℕ_)
import SDG.ChapterI.Section03 as S3
import SDG.Algebra.Nilradical as NR

-- The union of finite-order infinitesimals is represented by witnesses,
-- with equality given by their underlying scalar values. No function on
-- the raw witnesses is treated as a function on the union unless it
-- explicitly respects this equivalence.
module Times {ℓ : Level} (A : CRing ℓ) where
  open S3.HigherInfinitesimals A
  open NR.Results A using (nilpotent-sum; nilpotent-neg)

  record D∞ : Set ℓ where
    constructor witnessed
    field
      bound : ℕ
      element : DK bound
  open D∞ public

  scalar : D∞ → R
  scalar d = valueK (element d)

  infix 4 _≈∞_
  _≈∞_ : D∞ → D∞ → Set ℓ
  d ≈∞ e = scalar d ≡ scalar e

  ≈∞-refl : (d : D∞) → d ≈∞ d
  ≈∞-refl d = refl

  ≈∞-sym : {d e : D∞} → d ≈∞ e → e ≈∞ d
  ≈∞-sym = sym

  ≈∞-trans : {d e f : D∞} → d ≈∞ e → e ≈∞ f → d ≈∞ f
  ≈∞-trans = trans

  Respects∞ : {a : Level} {M : Set a} → (D∞ → M) → Set (ℓ ⊔ a)
  Respects∞ f = (d e : D∞) → d ≈∞ e → f d ≡ f e

  zero∞ : D∞
  zero∞ = witnessed zero (zeroK zero)

  add∞ : D∞ → D∞ → D∞
  add∞ (witnessed k d) (witnessed l e) = witnessed (k +ℕ suc l)
    (nilpotent (valueK d + valueK e)
      (nilpotent-sum (valueK d) (valueK e) k l (nilpotence d) (nilpotence e)))

  neg∞ : D∞ → D∞
  neg∞ (witnessed k d) = witnessed k
    (nilpotent (- valueK d) (nilpotent-neg (valueK d) k (nilpotence d)))

  scale∞ : R → D∞ → D∞
  scale∞ r (witnessed k d) = witnessed k (scaleK d r)

  add∞-respects : {d d′ e e′ : D∞} →
    d ≈∞ d′ → e ≈∞ e′ → add∞ d e ≈∞ add∞ d′ e′
  add∞-respects = cong₂ _+_

  neg∞-respects : {d e : D∞} → d ≈∞ e → neg∞ d ≈∞ neg∞ e
  neg∞-respects = cong (λ x → - x)

  scale∞-respects : (r : R) {d e : D∞} → d ≈∞ e → scale∞ r d ≈∞ scale∞ r e
  scale∞-respects r = cong (_* r)

  injectK : {n : ℕ} → DK n → D∞
  injectK {n} d = witnessed n d

  injectK-value : {n : ℕ} (d : DK n) → scalar (injectK d) ≡ valueK d
  injectK-value d = refl

  inject-weaken : {n : ℕ} (d : DK n) → injectK (weakenK d) ≈∞ injectK d
  inject-weaken d = refl

  add∞-assoc : (d e f : D∞) → add∞ (add∞ d e) f ≈∞ add∞ d (add∞ e f)
  add∞-assoc d e f = +-assoc (scalar d) (scalar e) (scalar f)

  add∞-comm : (d e : D∞) → add∞ d e ≈∞ add∞ e d
  add∞-comm d e = +-comm (scalar d) (scalar e)

  add∞-zeroˡ : (d : D∞) → add∞ zero∞ d ≈∞ d
  add∞-zeroˡ d = +-identityˡ (scalar d)

  add∞-zeroʳ : (d : D∞) → add∞ d zero∞ ≈∞ d
  add∞-zeroʳ d = +-identityʳ (scalar d)

  add∞-inverseˡ : (d : D∞) → add∞ (neg∞ d) d ≈∞ zero∞
  add∞-inverseˡ d = +-inverseˡ (scalar d)

  add∞-inverseʳ : (d : D∞) → add∞ d (neg∞ d) ≈∞ zero∞
  add∞-inverseʳ d = +-inverseʳ (scalar d)
