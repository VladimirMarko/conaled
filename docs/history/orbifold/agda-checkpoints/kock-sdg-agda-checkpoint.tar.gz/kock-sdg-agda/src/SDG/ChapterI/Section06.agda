{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; Vec; zero; suc)
open import SDG.Infinitesimal.Jets

-- Definition I.6.3, exactly in dimensions two and higher. Extension laws
-- and uniqueness are pointwise; no equality of functions is assumed here.
module Linear {ℓ : Level} (A : CRing ℓ) where
  open Infinitesimals A
  open Jets A

  record InfinitesimallyLinear {a : Level} (M : Set a) : Set (ℓ ⊔ a) where
    field
      extension : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M) →
        ((i : Fin (suc (suc n))) → ts i zeroD ≡ x) → Jet1 (suc (suc n)) → M
      axes : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M)
        (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x) →
        (i : Fin (suc (suc n))) (d : D) → extension n x ts base (axis i d) ≡ ts i d
      uniqueness : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M)
        (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x) →
        (candidate : Jet1 (suc (suc n)) → M) →
        ((i : Fin (suc (suc n))) (d : D) → candidate (axis i d) ≡ ts i d) →
        (p : Jet1 (suc (suc n))) → candidate p ≡ extension n x ts base p
