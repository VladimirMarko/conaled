{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section14TwoForms where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; head; tail; Fin; fzero; fsuc; swapFirst; permute-swapFirst; permute)
open import SDG.Forms.Basic
open import SDG.Forms.QuadraticCubes using (two)
open import SDG.Combinatorics.Signature
import SDG.Forms.QuadraticCubes as QC
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section10 as S10
import SDG.ChapterI.Section07 as S7
import SDG.Combinatorics.TwoPermutations as P2
import SDG.Forms.TangentTuples as TT
import SDG.Forms.Axes as AX
import SDG.Forms.Module as FM

-- Exercise I.14.2. The mixed coefficient is eliminated by the actual
-- alternating-form law, with invertibility of 2 explicit.
module TwoForms {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (ext : FunExt ℓ ℓ)
  (Umod Vmod : RModule A ℓ)
  (KU : V5.VectorInfinitesimals.VectorKL A Umod)
  (KV : V5.VectorInfinitesimals.VectorKL A Vmod)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A) where
  open Extra A Vmod
  module U = ModuleLemmas A Umod
  module Q = QC.Quadratic A Umod KU
  open Infinitesimals A
  open Cubes A
  open ModuleForms A Vmod
  open Sign A
  module H = S10.Homogeneity A K setR (FiniteModules.finiteModule A Umod two) Vmod KV

  coefficientValue : Form two U.V → U.V → U.V → U.V → U.V → V
  coefficientValue ω x a b c = evaluate ω (Q.quad x a b c)

  first-block : Form two U.V → U.V → U.V → Vec U.V two → V
  first-block ω x b (a ∷ c ∷ []) = coefficientValue ω x a b c

  second-block : Form two U.V → U.V → U.V → Vec U.V two → V
  second-block ω x a (b ∷ c ∷ []) = coefficientValue ω x a b c

  first-homogeneous : (ω : Form two U.V) (x b : U.V) → H.Homogeneous (first-block ω x b)
  first-homogeneous ω x b r (a ∷ c ∷ []) = trans
    (cong (evaluate ω) (sym (ext (Q.quad-scale-first x a b c r))))
    (homogeneous ω (Q.quad x a b c) fzero r)

  second-homogeneous : (ω : Form two U.V) (x a : U.V) → H.Homogeneous (second-block ω x a)
  second-homogeneous ω x a r (b ∷ c ∷ []) = trans
    (cong (evaluate ω) (sym (ext (Q.quad-scale-second x a b c r))))
    (homogeneous ω (Q.quad x a b c) (fsuc fzero) r)

  first-add : (ω : Form two U.V) (x a a′ b c c′ : U.V) →
    coefficientValue ω x (U._+v_ a a′) b (U._+v_ c c′) ≡
      coefficientValue ω x a b c +v coefficientValue ω x a′ b c′
  first-add ω x a a′ b c c′ = H.homogeneous-add (first-block ω x b)
    (λ d → first-homogeneous ω x b (value d)) (a ∷ c ∷ []) (a′ ∷ c′ ∷ [])

  second-add : (ω : Form two U.V) (x a b b′ c c′ : U.V) →
    coefficientValue ω x a (U._+v_ b b′) (U._+v_ c c′) ≡
      coefficientValue ω x a b c +v coefficientValue ω x a b′ c′
  second-add ω x a b b′ c c′ = H.homogeneous-add (second-block ω x a)
    (λ d → second-homogeneous ω x a (value d)) (b ∷ c ∷ []) (b′ ∷ c′ ∷ [])

  first-zero : (ω : Form two U.V) (x b : U.V) → coefficientValue ω x U.0v b U.0v ≡ 0v
  first-zero ω x b = H.homogeneous-zero (first-block ω x b) (λ d → first-homogeneous ω x b (value d))

  first-split : (ω : Form two U.V) (x a b c : U.V) →
    coefficientValue ω x a b c ≡ coefficientValue ω x a b U.0v +v coefficientValue ω x U.0v b c
  first-split ω x a b c = trans
    (cong₂ (λ aa cc → coefficientValue ω x aa b cc) (sym (U.add-zeroʳ a)) (sym (U.add-zeroˡ c)))
    (first-add ω x a U.0v b U.0v c)

  second-split : (ω : Form two U.V) (x b c : U.V) →
    coefficientValue ω x U.0v b c ≡ coefficientValue ω x U.0v U.0v c
  second-split ω x b c = trans
    (cong₂ (coefficientValue ω x U.0v) (sym (U.add-zeroʳ b)) (sym (U.add-zeroˡ c)))
    (trans (second-add ω x U.0v b U.0v U.0v c)
      (trans (cong (_+v coefficientValue ω x U.0v U.0v c) (first-zero ω x b))
        (add-zeroˡ (coefficientValue ω x U.0v U.0v c))))

  mixed-shape : (x c : U.V) (d e : D) →
    Q.quad x U.0v U.0v c (d ∷ e ∷ []) ≡ U._+v_ x (U._•_ (value d * value e) c)
  mixed-shape x c d e = cong₂ U._+v_
    (trans (cong (U._+v_ x) (U.scalar-zero (value d))) (U.add-zeroʳ x))
    (trans (cong (U._+v_ (U._•_ (value e) U.0v)) refl)
      (trans (cong (λ z → U._+v_ z (U._•_ (value d * value e) c)) (U.scalar-zero (value e)))
        (U.add-zeroˡ (U._•_ (value d * value e) c))))

  mixed-symmetric : (x c : U.V) → permute-cube (Q.quad x U.0v U.0v c) swapFirst ≡ Q.quad x U.0v U.0v c
  mixed-symmetric x c = ext (λ { (d ∷ e ∷ []) → trans
    (cong (Q.quad x U.0v U.0v c) (permute-swapFirst d e []))
    (trans (mixed-shape x c e d)
      (trans (cong (λ r → U._+v_ x (U._•_ r c)) (*-comm (value e) (value d)))
        (sym (mixed-shape x c d e)))) })

  swap-sign : signature (swapFirst {zero}) ≡ (- 1r)
  swap-sign = *-identityʳ (- 1r)

  mixed-negative : (ω : Form two U.V) (x c : U.V) →
    coefficientValue ω x U.0v U.0v c ≡ (-v coefficientValue ω x U.0v U.0v c)
  mixed-negative ω x c = trans (sym (cong (evaluate ω) (mixed-symmetric x c)))
    (trans (alternating ω (Q.quad x U.0v U.0v c) swapFirst)
      (trans (cong (_• coefficientValue ω x U.0v U.0v c) swap-sign)
        (trans (neg-scalar 1r (coefficientValue ω x U.0v U.0v c))
          (cong -v_ (scalar-one (coefficientValue ω x U.0v U.0v c))))))

  two-torsion-free : (v : V) → v +v v ≡ 0v → v ≡ 0v
  two-torsion-free v twice = trans (sym (scalar-one v))
    (trans (cong (_• v) (sym (trans (*-comm half (1r + 1r)) half-law)))
      (trans (scalar-assoc half (1r + 1r) v)
        (trans (cong (half •_) (trans (scalar-add 1r 1r v)
          (trans (cong₂ _+v_ (scalar-one v) (scalar-one v)) twice))) (scalar-zero half))))

  mixed-zero : (ω : Form two U.V) (x c : U.V) → coefficientValue ω x U.0v U.0v c ≡ 0v
  mixed-zero ω x c = two-torsion-free z
    (trans (cong (z +v_) (mixed-negative ω x c)) (add-inverseʳ z))
    where z = coefficientValue ω x U.0v U.0v c

  independent-of-mixed : (ω : Form two U.V) (x a b c : U.V) →
    coefficientValue ω x a b c ≡ coefficientValue ω x a b U.0v
  independent-of-mixed ω x a b c = trans (first-split ω x a b c)
    (trans (cong (coefficientValue ω x a b U.0v +v_)
      (trans (second-split ω x b c) (mixed-zero ω x c)))
      (add-zeroʳ (coefficientValue ω x a b U.0v)))

  axes-determine : (ω : Form two U.V) (τ : Cube two U.V) →
    evaluate ω τ ≡ coefficientValue ω (Q.base τ) (Q.first τ) (Q.second τ) U.0v
  axes-determine ω τ = trans (cong (evaluate ω) (ext (Q.reconstruction τ)))
    (independent-of-mixed ω (Q.base τ) (Q.first τ) (Q.second τ) (Q.mixed τ))

  open S7.Basics A setR using (Tangent; curve; based; speed)
  module T = TT.Definitions A setR (moduleAction A Vmod)

  principal : {x : U.V} → Tangent U.V x → U.V
  principal t = V5.VectorInfinitesimals.VectorKL.slopeV KU (curve t)

  principal-speed : {x : U.V} (r : R) (t : Tangent U.V x) → principal (speed r t) ≡ U._•_ r (principal t)
  principal-speed r t = V5.VectorInfinitesimals.VectorKL.uniqueSlopeV KU (curve (speed r t)) (U._•_ r (principal t))
    (λ d → trans (V5.VectorInfinitesimals.VectorKL.expansionV KU (curve t) (scaleD d r))
      (cong₂ U._+v_ (cong (curve t) (sym (S7.Basics.scale-zero A setR r))) (U.scalar-assoc (value d) r (principal t))))

  principal-curve : {x : U.V} (t : Tangent U.V x) (d : D) → U._+v_ x (U._•_ (value d) (principal t)) ≡ curve t d
  principal-curve t d = trans (cong (λ z → U._+v_ z (U._•_ (value d) (principal t))) (sym (based t)))
    (sym (V5.VectorInfinitesimals.VectorKL.expansionV KU (curve t) d))

  principal-first-hom : (ω : Form two U.V) (x a b : U.V) (r : R) →
    coefficientValue ω x (U._•_ r a) b U.0v ≡ r • coefficientValue ω x a b U.0v
  principal-first-hom ω x a b r = trans
    (cong (coefficientValue ω x (U._•_ r a) b) (sym (U.scalar-zero r)))
    (first-homogeneous ω x b r (a ∷ U.0v ∷ []))

  principal-second-hom : (ω : Form two U.V) (x a b : U.V) (r : R) →
    coefficientValue ω x a (U._•_ r b) U.0v ≡ r • coefficientValue ω x a b U.0v
  principal-second-hom ω x a b r = trans
    (cong (coefficientValue ω x a (U._•_ r b)) (sym (U.scalar-zero r)))
    (second-homogeneous ω x a r (b ∷ U.0v ∷ []))

  swapped-value : (ω : Form two U.V) (x a b : U.V) →
    coefficientValue ω x b a U.0v ≡ (- 1r) • coefficientValue ω x a b U.0v
  swapped-value ω x a b = trans
    (cong (evaluate ω) (sym (ext (Q.quad-swap x a b U.0v))))
    (trans (alternating ω (Q.quad x a b U.0v) swapFirst)
      (cong (_• coefficientValue ω x a b U.0v) swap-sign))

  tupleValue : Form two U.V → (x : U.V) → Vec (Tangent U.V x) two → V
  tupleValue ω x (t ∷ u ∷ []) = coefficientValue ω x (principal t) (principal u) U.0v

  recovered : Form two U.V → T.TupleForm two U.V
  T.evaluate (recovered ω) = tupleValue ω
  T.homogeneous (recovered ω) x (t ∷ u ∷ []) fzero r = trans
    (cong (λ a → coefficientValue ω x a (principal u) U.0v) (principal-speed r t))
    (principal-first-hom ω x (principal t) (principal u) r)
  T.homogeneous (recovered ω) x (t ∷ u ∷ []) (fsuc fzero) r = trans
    (cong (λ b → coefficientValue ω x (principal t) b U.0v) (principal-speed r u))
    (principal-second-hom ω x (principal t) (principal u) r)
  T.alternating (recovered ω) x (t ∷ u ∷ []) p with P2.classify p
  ... | P2.fixed a b = trans (cong (tupleValue ω x) (P2.permute-fixed p a b (t ∷ u ∷ [])))
    (sym (trans (cong (_• coefficientValue ω x (principal t) (principal u) U.0v) (P2.Signs.fixed-sign A p a b))
      (scalar-one (coefficientValue ω x (principal t) (principal u) U.0v))))
  ... | P2.swapped a b = trans (cong (tupleValue ω x) (P2.permute-swapped p a b t u))
    (trans (swapped-value ω x (principal t) (principal u))
      (cong (_• coefficientValue ω x (principal t) (principal u) U.0v) (sym (P2.Signs.swapped-sign A p a b))))

  module Correspondence (setU : isSet U.V) where
    module Axes = AX.CoordinateAxes A setR
    module Comparison = AX.Comparison A setR (moduleAction A Vmod) ext U.V setU

    cubical-roundtrip : (ω : Form two U.V) (τ : Cube two U.V) → evaluate (Comparison.cubical (recovered ω)) τ ≡ evaluate ω τ
    cubical-roundtrip ω τ = sym (axes-determine ω τ)

    tuple-roundtrip : (ω : T.TupleForm two U.V) (x : U.V) (ts : Vec (Tangent U.V x) two) →
      T.evaluate (recovered (Comparison.cubical ω)) x ts ≡ T.evaluate ω x ts
    tuple-roundtrip ω x (t ∷ u ∷ []) = Comparison.evaluate-cong ω
      (Q.quad-base x (principal t) (principal u) U.0v) curves
      where
      τ = Q.quad x (principal t) (principal u) U.0v
      curves : (i : Fin two) (d : D) → curve (SDG.Finite.lookup (Axes.axes τ) i) d ≡ curve (SDG.Finite.lookup (t ∷ u ∷ []) i) d
      curves fzero d = trans (Axes.axis-curve τ fzero d)
        (trans (Q.quad-axis-first x (principal t) (principal u) U.0v d) (principal-curve t d))
      curves (fsuc fzero) d = trans (Axes.axis-curve τ (fsuc fzero) d)
        (trans (Q.quad-axis-second x (principal t) (principal u) U.0v d) (principal-curve u d))

    native-cubical-roundtrip : (ext0 : FunExt lzero ℓ) (setV : isSet V) (ω : Form two U.V) →
      Comparison.cubical (recovered ω) ≡ ω
    native-cubical-roundtrip ext0 setV ω = FM.Native.form-ext A Vmod ext0 ext setV (cubical-roundtrip ω)

    native-tuple-roundtrip : (ext0 : FunExt lzero ℓ) (setV : isSet V) (ω : T.TupleForm two U.V) →
      recovered (Comparison.cubical ω) ≡ ω
    native-tuple-roundtrip ext0 setV ω = T.Native.tuple-form-ext ext0 ext setV (tuple-roundtrip ω)
