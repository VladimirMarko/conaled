{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section15Subdivision where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
open import SDG.Finite using (Fin; lookup; update)
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section15 as S15
import SDG.Integration.BoxSubdivision as BS

module Results {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setR : isSet (CRing.R A)) where
  open S15.Stokes A K O J ext0 ext setR public
  module Sub = BS.Subdivision A K O J

  -- Equation (15.3) in every coordinate and every dimension. The two
  -- subbox currents are pushed into their common ambient box explicitly.
  current-subdivision : {n : ℕ} (ss : Box n) (i : Fin n) (p : Sub.Split (lookup ss i)) →
    canonicalCurrent ss ≡ add-current
      (pushforward (Sub.leftMap ss i p) (canonicalCurrent (update ss i (Sub.leftSegment p))))
      (pushforward (Sub.rightMap ss i p) (canonicalCurrent (update ss i (Sub.rightSegment p))))
  current-subdivision ss i p = current-ext (λ ω →
    trans (Sub.integral-subdivision ss i p (density ω))
      (cong₂ _+_
        (integral-congruence (update ss i (Sub.leftSegment p)) _ _
          (λ xs → cong (evaluate ω) (sym (ext (Sub.left-canonical ss i p xs)))))
        (integral-congruence (update ss i (Sub.rightSegment p)) _ _
          (λ xs → cong (evaluate ω) (sym (ext (Sub.right-canonical ss i p xs)))))))
