{-# OPTIONS --safe --without-K #-}
module SDG.Forms.JetTuples where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup; tabulate; lookup-tabulate; vec-ext)
open import SDG.Infinitesimal.Jets
open import SDG.Schemes.Isomorphism
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7

-- The common-base n-fold tangent pullback is M^D(n) for an IL object.
-- Dimensions zero and one are proved directly, not omitted from the claim.
module Comparison {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (M : Set ℓ) (setM : isSet M)
  (IL : S6.Linear.InfinitesimallyLinear A M) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR using (Tangent; tangent; curve; based; tangent-ext; d-path)
  open S6.Linear.InfinitesimallyLinear IL renaming (axes to extend-axes)

  Tuple : ℕ → Set ℓ
  Tuple n = Σ M (λ x → Vec (Tangent M x) n)

  tuple-ext : {n : ℕ} {p q : Tuple n} → fst p ≡ fst q →
    ((i : Fin n) (d : D) → curve (lookup (snd p) i) d ≡ curve (lookup (snd q) i) d) → p ≡ q
  tuple-ext {p = x , ts} {q = .x , us} refl equality = cong (x ,_)
    (vec-ext (λ i → tangent-ext ext setM (equality i)))

  origin : (n : ℕ) → Jet1 n
  origin n = zeroJet (suc zero) n

  restriction-tangent : {n : ℕ} (f : Jet1 n → M) → Fin n → Tangent M (f (origin n))
  restriction-tangent f i = tangent (f ∘ axis i) (cong f (axis-zero setR ext0 i))

  restrict : {n : ℕ} → (Jet1 n → M) → Tuple n
  restrict {n} f = f (origin n) , tabulate (restriction-tangent f)

  restriction-curve : {n : ℕ} (f : Jet1 n → M) (i : Fin n) (d : D) →
    curve (lookup (snd (restrict f)) i) d ≡ f (axis i d)
  restriction-curve f i d = cong (λ t → curve t d) (lookup-tabulate (restriction-tangent f) i)

  extend : {n : ℕ} → Tuple n → Jet1 n → M
  extend {zero} (x , []) p = x
  extend {suc zero} (x , t ∷ []) p = curve t (coordinateD p fzero)
  extend {suc (suc n)} (x , ts) = extension n x
    (λ i → curve (lookup ts i)) (λ i → based (lookup ts i))

  extension-axis : {n : ℕ} (t : Tuple n) (i : Fin n) (d : D) → extend t (axis i d) ≡ curve (lookup (snd t) i) d
  extension-axis {zero} t () d
  extension-axis {suc zero} (x , t ∷ []) fzero d = cong (curve t) (d-path (axis-own {n = suc zero} fzero d))
  extension-axis {suc (suc n)} (x , ts) i d = extend-axes n x
    (λ j → curve (lookup ts j)) (λ j → based (lookup ts j)) i d

  extension-base : {n : ℕ} (t : Tuple n) → extend t (origin n) ≡ fst t
  extension-base {zero} (x , []) = refl
  extension-base {suc zero} (x , t ∷ []) = trans (cong (curve t) (d-path {d = coordinateD (origin (suc zero)) fzero} {e = zeroD} refl)) (based t)
  extension-base {suc (suc n)} (x , ts) = trans
    (cong (extend (x , ts)) (sym (axis-zero setR ext0 fzero)))
    (trans (extension-axis (x , ts) fzero zeroD) (based (lookup ts fzero)))

  zero-jet : (p : Jet1 zero) → p ≡ origin zero
  zero-jet p = jet-path setR ext0 (vec-ext (λ ()))

  one-jet : (p : Jet1 (suc zero)) → axis fzero (coordinateD p fzero) ≡ p
  one-jet p = jet-path setR ext0 (vec-ext λ { fzero → axis-own {n = suc zero} fzero (coordinateD p fzero) })

  extend-restrict-pointwise : {n : ℕ} (f : Jet1 n → M) (p : Jet1 n) → extend (restrict f) p ≡ f p
  extend-restrict-pointwise {zero} f p = cong f (sym (zero-jet p))
  extend-restrict-pointwise {suc zero} f p = cong f (one-jet p)
  extend-restrict-pointwise {suc (suc n)} f p = sym
    (uniqueness n (f (origin (suc (suc n))))
      (λ i → curve (lookup (snd (restrict f)) i)) (λ i → based (lookup (snd (restrict f)) i))
      f (λ i d → sym (restriction-curve f i d)) p)

  extend-restrict : {n : ℕ} (f : Jet1 n → M) → extend (restrict f) ≡ f
  extend-restrict f = ext (extend-restrict-pointwise f)

  restrict-extend : {n : ℕ} (t : Tuple n) → restrict (extend t) ≡ t
  restrict-extend t = tuple-ext (extension-base t)
    (λ i d → trans (restriction-curve (extend t) i d) (extension-axis t i d))

  jet-tuple-isomorphism : (n : ℕ) → Isomorphism (Jet1 n → M) (Tuple n)
  jet-tuple-isomorphism n = isomorphism restrict extend extend-restrict restrict-extend
