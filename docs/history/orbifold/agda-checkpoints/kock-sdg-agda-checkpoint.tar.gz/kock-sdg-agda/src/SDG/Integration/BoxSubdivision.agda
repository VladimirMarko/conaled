{-# OPTIONS --safe --without-K #-}

module SDG.Integration.BoxSubdivision where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; update)
import SDG.Integration.Boxes as IB
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section13Transformation as T13

module Subdivision {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) where
  open IB.Boxes A K O J public
  open Infinitesimals A
  module T = T13.Results A K O J

  record Split (s : Segment) : Set ℓ where
    constructor cut
    field
      middle : R
      lower-middle : lower s ≤ middle
      middle-upper : middle ≤ upper s
  open Split public

  leftSegment rightSegment : {s : Segment} → Split s → Segment
  leftSegment {s} p = segment (lower s) (middle p) (lower-middle p)
  rightSegment {s} p = segment (middle p) (upper s) (middle-upper p)

  leftInclusion : {s : Segment} (p : Split s) → Carrier (leftSegment p) → Carrier s
  leftInclusion {s} p = T.inclusion (reflexive (lower s)) (middle-upper p)

  rightInclusion : {s : Segment} (p : Split s) → Carrier (rightSegment p) → Carrier s
  rightInclusion {s} p = T.inclusion (lower-middle p) (reflexive (upper s))

  segment-subdivision : {s : Segment} (p : Split s) (f : Carrier s → R) →
    Line.integral s f ≡ Line.integral (leftSegment p) (f ∘ leftInclusion p) +
      Line.integral (rightSegment p) (f ∘ rightInclusion p)
  segment-subdivision {s} p f = trans
    (cong (λ order → Over.integral order f)
      (relation-prop (lower s) (upper s) (ordered s) (transitive (lower-middle p) (middle-upper p))))
    (T.subdivision (lower-middle p) (middle-upper p) f)

  mapCoordinate : {n : ℕ} (ss : Box n) (i : Fin n) (t : Segment) →
    (Carrier t → Carrier (lookup ss i)) → Point (update ss i t) → Point ss
  mapCoordinate (s ∷ ss) fzero t f (x ∷p xs) = f x ∷p xs
  mapCoordinate (s ∷ ss) (fsuc i) t f (x ∷p xs) = x ∷p mapCoordinate ss i t f xs

  leftMap : {n : ℕ} (ss : Box n) (i : Fin n) (p : Split (lookup ss i)) →
    Point (update ss i (leftSegment p)) → Point ss
  leftMap ss i p = mapCoordinate ss i (leftSegment p) (leftInclusion p)

  rightMap : {n : ℕ} (ss : Box n) (i : Fin n) (p : Split (lookup ss i)) →
    Point (update ss i (rightSegment p)) → Point ss
  rightMap ss i p = mapCoordinate ss i (rightSegment p) (rightInclusion p)

  integral-subdivision : {n : ℕ} (ss : Box n) (i : Fin n) (p : Split (lookup ss i)) (f : Point ss → R) →
    integralBox ss f ≡ integralBox (update ss i (leftSegment p)) (f ∘ leftMap ss i p) +
      integralBox (update ss i (rightSegment p)) (f ∘ rightMap ss i p)
  integral-subdivision (s ∷ ss) fzero p f =
    trans (integral-congruence ss _ _ (λ xs → segment-subdivision p (λ x → f (x ∷p xs))))
      (integral-additivity ss
        (λ xs → Line.integral (leftSegment p) (λ x → f (leftInclusion p x ∷p xs)))
        (λ xs → Line.integral (rightSegment p) (λ x → f (rightInclusion p x ∷p xs))))
  integral-subdivision (s ∷ ss) (fsuc i) p f =
    integral-subdivision ss i p (λ xs → Line.integral s (λ x → f (x ∷p xs)))

  map-canonical : {n : ℕ} (ss : Box n) (i : Fin n) (t : Segment)
    (f : Carrier t → Carrier (lookup ss i)) →
    ((x : Carrier t) (d : D) → f (shift x d) ≡ shift (f x) d) →
    (xs : Point (update ss i t)) (ds : Vec D n) →
    mapCoordinate ss i t f (canonicalCube xs ds) ≡ canonicalCube (mapCoordinate ss i t f xs) ds
  map-canonical (s ∷ ss) fzero t f stable (x ∷p xs) (d ∷ ds) =
    cong (_∷p canonicalCube xs ds) (stable x d)
  map-canonical (s ∷ ss) (fsuc i) t f stable (x ∷p xs) (d ∷ ds) =
    cong (shift x d ∷p_) (map-canonical ss i t f stable xs ds)

  left-canonical : {n : ℕ} (ss : Box n) (i : Fin n) (p : Split (lookup ss i))
    (xs : Point (update ss i (leftSegment p))) (ds : Vec D n) →
    leftMap ss i p (canonicalCube xs ds) ≡ canonicalCube (leftMap ss i p xs) ds
  left-canonical ss i p = map-canonical ss i (leftSegment p) (leftInclusion p) (λ x d → interval-ext refl)

  right-canonical : {n : ℕ} (ss : Box n) (i : Fin n) (p : Split (lookup ss i))
    (xs : Point (update ss i (rightSegment p))) (ds : Vec D n) →
    rightMap ss i p (canonicalCube xs ds) ≡ canonicalCube (rightMap ss i p xs) ds
  right-canonical ss i p = map-canonical ss i (rightSegment p) (rightInclusion p) (λ x d → interval-ext refl)
