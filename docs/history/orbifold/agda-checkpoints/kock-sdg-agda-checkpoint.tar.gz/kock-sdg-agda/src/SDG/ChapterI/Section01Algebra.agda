{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section01Algebra where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Algebra.DualNumbers using (RingHom; module DualNumbers)
open import SDG.Algebra.FunctionRing
import SDG.ChapterI.Section01 as S1
import SDG.Calculus.Slope as Slope

module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open S1.Results A K
  open Slope.Results A K
  module DN = DualNumbers A

  -- An arbitrary scalar-valued function on D ignores nilpotence witnesses.
  scalar-extensional : (g : D → R) {u v : D} →
    value u ≡ value v → g u ≡ g v
  scalar-extensional g {u} {v} p =
    trans (expansion g u)
      (trans (cong (λ x → g zeroD + x * slope g) p) (sym (expansion g v)))

  encode-neg : (p : Dual) (d : D) → encode (DN.neg p) d ≡ (- encode p d)
  encode-neg (a , b) d =
    trans (cong ((- a) +_) (neg-mulʳ (value d) b))
      (sym (neg-add a (value d * b)))

  encode-scalar : (r : R) (d : D) → encode (DN.scalar r) d ≡ r
  encode-scalar r d =
    trans (cong (r +_) (*-zeroʳ (value d))) (+-identityʳ r)

  -- beta (evaluation at zero) and gamma (slope) are R-linear.
  beta-add : (f g : D → R) → (λ d → f d + g d) zeroD ≡ f zeroD + g zeroD
  beta-add f g = refl

  beta-scale : (r : R) (f : D → R) → (λ d → r * f d) zeroD ≡ r * f zeroD
  beta-scale r f = refl

  gamma-add : (f g : D → R) → slope (λ d → f d + g d) ≡ slope f + slope g
  gamma-add = slope-add

  gamma-scale : (r : R) (f : D → R) → slope (λ d → r * f d) ≡ r * slope f
  gamma-scale = slope-scale

  module Extensional (ext : FunExt ℓ ℓ) where
    functions : CRing ℓ
    functions = functionRing A D ext

    alpha-hom : RingHom DN.dualRing functions
    alpha-hom = record
      { hom = encode
      ; pres-0 = ext encode-zero
      ; pres-1 = ext encode-one
      ; pres-+ = λ p q → ext (encode-sum p q)
      ; pres-* = λ p q → ext (encode-product p q)
      ; pres-neg = λ p → ext (encode-neg p)
      }

    inverse-hom : RingHom functions DN.dualRing
    inverse-hom = record
      { hom = decode
      ; pres-0 = cong (0r ,_) (slope-constant 0r)
      ; pres-1 = cong (1r ,_) (slope-constant 1r)
      ; pres-+ = λ f g → cong ((f zeroD + g zeroD) ,_) (slope-add f g)
      ; pres-* = λ f g → cong ((f zeroD * g zeroD) ,_) (slope-product f g)
      ; pres-neg = λ f → cong ((- f zeroD) ,_) (slope-neg f)
      }

    -- Corollary I.1.2 as an actual identity-valued ring isomorphism.
    -- encode-scalar above additionally supplies the R-algebra compatibility.
    dual-function-isomorphism : RingIso DN.dualRing functions
    dual-function-isomorphism = record
      { forward = alpha-hom
      ; backward = inverse-hom
      ; left-inverse = decode-encode
      ; right-inverse = λ f → ext (encode-decode f)
      }

