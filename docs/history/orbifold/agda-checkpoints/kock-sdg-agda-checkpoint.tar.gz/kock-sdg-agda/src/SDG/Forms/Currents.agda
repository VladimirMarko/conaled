{-# OPTIONS --safe --without-K #-}
module SDG.Forms.Currents where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
open import SDG.Finite using (Vec)
open import SDG.Forms.Basic
import SDG.Forms.Module as FM

module Currents {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setV : isSet (RModule.V Vmod)) where
  open Extra A Vmod
  open Infinitesimals A
  open Cubes A
  open FM.Native A Vmod ext0 ext setV public

  -- Definition 14.3: linear functionals on the actual module of forms.
  record Current (n : ℕ) (M : Set ℓ) : Set ℓ where
    constructor current
    field
      integrate : Form n M → V
      additive : (ω θ : Form n M) → integrate (add-form ω θ) ≡ integrate ω +v integrate θ
      homogeneous-current : (r : R) (ω : Form n M) → integrate (scale-form r ω) ≡ r • integrate ω
  open Current public

  private
    current-path : {n : ℕ} {M : Set ℓ} {γ δ : Current n M} → integrate γ ≡ integrate δ → γ ≡ δ
    current-path {γ = current f p q} {current .f p′ q′} refl = cong₂ (current f)
      (ext (λ ω → ext (λ θ → setV _ _ (p ω θ) (p′ ω θ))))
      (ext (λ r → ext (λ ω → setV _ _ (q r ω) (q′ r ω))))

  current-ext : {n : ℕ} {M : Set ℓ} {γ δ : Current n M} →
    ((ω : Form n M) → integrate γ ω ≡ integrate δ ω) → γ ≡ δ
  current-ext p = current-path (ext p)

  zero-current : {n : ℕ} {M : Set ℓ} → Current n M
  integrate zero-current ω = 0v
  additive zero-current ω θ = sym (add-zeroˡ 0v)
  homogeneous-current zero-current r ω = sym (scalar-zero r)

  add-current : {n : ℕ} {M : Set ℓ} → Current n M → Current n M → Current n M
  integrate (add-current γ δ) ω = integrate γ ω +v integrate δ ω
  additive (add-current γ δ) ω θ = trans (cong₂ _+v_ (additive γ ω θ) (additive δ ω θ))
    (add-shuffle (integrate γ ω) (integrate γ θ) (integrate δ ω) (integrate δ θ))
  homogeneous-current (add-current γ δ) r ω =
    trans (cong₂ _+v_ (homogeneous-current γ r ω) (homogeneous-current δ r ω))
      (sym (scalar-distrib r (integrate γ ω) (integrate δ ω)))

  scale-current : {n : ℕ} {M : Set ℓ} → R → Current n M → Current n M
  integrate (scale-current r γ) ω = r • integrate γ ω
  additive (scale-current r γ) ω θ = trans (cong (r •_) (additive γ ω θ))
    (scalar-distrib r (integrate γ ω) (integrate γ θ))
  homogeneous-current (scale-current r γ) s ω =
    trans (cong (r •_) (homogeneous-current γ s ω)) (scalar-commute r s (integrate γ ω))

  negate-current : {n : ℕ} {M : Set ℓ} → Current n M → Current n M
  integrate (negate-current γ) ω = -v integrate γ ω
  additive (negate-current γ) ω θ = trans (cong -v_ (additive γ ω θ))
    (v-neg-add (integrate γ ω) (integrate γ θ))
  homogeneous-current (negate-current γ) r ω =
    trans (cong -v_ (homogeneous-current γ r ω)) (sym (scalar-neg r (integrate γ ω)))

  currentsModule : (n : ℕ) (M : Set ℓ) → RModule A ℓ
  currentsModule n M = record
    { V = Current n M
    ; 0v = zero-current
    ; _+v_ = add-current
    ; -v_ = negate-current
    ; _•_ = scale-current
    ; add-assoc = λ γ δ η → current-ext (λ ω → add-assoc (integrate γ ω) (integrate δ ω) (integrate η ω))
    ; add-comm = λ γ δ → current-ext (λ ω → add-comm (integrate γ ω) (integrate δ ω))
    ; add-zeroˡ = λ γ → current-ext (λ ω → add-zeroˡ (integrate γ ω))
    ; add-inverseˡ = λ γ → current-ext (λ ω → add-inverseˡ (integrate γ ω))
    ; scalar-one = λ γ → current-ext (λ ω → scalar-one (integrate γ ω))
    ; scalar-assoc = λ r s γ → current-ext (λ ω → scalar-assoc r s (integrate γ ω))
    ; scalar-add = λ r s γ → current-ext (λ ω → scalar-add r s (integrate γ ω))
    ; scalar-distrib = λ r γ δ → current-ext (λ ω → scalar-distrib r (integrate γ ω) (integrate δ ω))
    }

  pushforward : {n : ℕ} {M N : Set ℓ} → (M → N) → Current n M → Current n N
  integrate (pushforward f γ) ω = integrate γ (pullback f ω)
  additive (pushforward f γ) ω θ = trans (cong (integrate γ) (pullback-add f ω θ))
    (additive γ (pullback f ω) (pullback f θ))
  homogeneous-current (pushforward f γ) r ω = trans (cong (integrate γ) (pullback-scale f r ω))
    (homogeneous-current γ r (pullback f ω))

  pushforward-identity : {n : ℕ} {M : Set ℓ} (γ : Current n M) → pushforward id γ ≡ γ
  pushforward-identity γ = current-ext (λ ω → cong (integrate γ) (pullback-id ω))

  pushforward-compose : {n : ℕ} {L M N : Set ℓ} (f : L → M) (g : M → N) (γ : Current n L) →
    pushforward (g ∘ f) γ ≡ pushforward g (pushforward f γ)
  pushforward-compose f g γ = current-ext (λ ω → cong (integrate γ) (pullback-composition f g ω))

  rectangle : {n : ℕ} {M : Set ℓ} → Cube n M → Vec D n → Current n M
  integrate (rectangle τ ds) ω = productD ds • evaluate ω τ
  additive (rectangle τ ds) ω θ = scalar-distrib (productD ds) (evaluate ω τ) (evaluate θ τ)
  homogeneous-current (rectangle τ ds) r ω = scalar-commute (productD ds) r (evaluate ω τ)

  rectangle-natural : {n : ℕ} {M N : Set ℓ} (f : M → N) (τ : Cube n M) (ds : Vec D n) →
    pushforward f (rectangle τ ds) ≡ rectangle (map-cube f τ) ds
  rectangle-natural f τ ds = current-ext (λ _ → refl)

