{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section09Invariant where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section09 as S9

record Monoid {ℓ : Level} (G : Set ℓ) : Set ℓ where
  infixl 7 _·_
  field
    unit : G
    _·_ : G → G → G
    assoc : (a b c : G) → (a · b) · c ≡ a · (b · c)
    identityˡ : (g : G) → unit · g ≡ g
    identityʳ : (g : G) → g · unit ≡ g

-- Exercises I.9.2--I.9.4: monoids suffice for left-invariant fields.
module Invariant {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {G : Set ℓ} (Gmon : Monoid G)
  (IL : S6.Linear.InfinitesimallyLinear A G)
  (W : S4.Results.PropertyW A K G) where
  open RingLemmas A
  open Infinitesimals A
  open Monoid Gmon
  open S7.Basics A setR
  open S8.Basics A setR
  open S9.Lie A K setR IL W
  open S9.Naturality A K setR IL W IL W using (bracket-natural)

  LeftInvariant : VectorField G → Set ℓ
  LeftInvariant X = (a b : G) (d : D) → a · run X b d ≡ run X (a · b) d

  invariant-bracket : (X Y : VectorField G) → LeftInvariant X → LeftInvariant Y →
    LeftInvariant (bracket X Y)
  invariant-bracket X Y px py a =
    bracket-natural (a ·_) X Y X Y (px a) (py a)

  invariant-zero : LeftInvariant zero-field
  invariant-zero a b d = refl

  invariant-scale : (r : R) (X : VectorField G) → LeftInvariant X →
    LeftInvariant (scale-field (λ _ → r) X)
  invariant-scale r X p a b d = p a b (scaleD d r)

  invariant-negative : (X : VectorField G) → LeftInvariant X → LeftInvariant (negative-field X)
  invariant-negative X p a b d = p a b (negateD d)

  field-from-tangent : Tangent G unit → VectorField G
  run (field-from-tangent t) g d = g · curve t d
  run-zero (field-from-tangent t) g =
    trans (cong (g ·_) (based t)) (identityʳ g)

  tangent-field-invariant : (t : Tangent G unit) → LeftInvariant (field-from-tangent t)
  tangent-field-invariant t a b d = sym (assoc a b (curve t d))

  tangent-at-unit : VectorField G → Tangent G unit
  tangent-at-unit X = tangent (run X unit) (run-zero X unit)

  tangent-field-roundtrip : (t : Tangent G unit) (d : D) →
    curve (tangent-at-unit (field-from-tangent t)) d ≡ curve t d
  tangent-field-roundtrip t d = identityˡ (curve t d)

  field-tangent-roundtrip : (X : VectorField G) → LeftInvariant X →
    (g : G) (d : D) → run (field-from-tangent (tangent-at-unit X)) g d ≡ run X g d
  field-tangent-roundtrip X p g d =
    trans (p g unit d) (cong (λ h → run X h d) (identityʳ g))

  tangent-field-bijection-left : (ext : FunExt ℓ ℓ) → isSet G →
    (t : Tangent G unit) → tangent-at-unit (field-from-tangent t) ≡ t
  tangent-field-bijection-left ext setG t = tangent-ext ext setG (tangent-field-roundtrip t)

  bracket-at-unit : Tangent G unit → Tangent G unit → Tangent G unit
  bracket-at-unit t u = tangent-at-unit (bracket (field-from-tangent t) (field-from-tangent u))

  bracket-field-compatibility : (t u : Tangent G unit) (g : G) (d : D) →
    run (field-from-tangent (bracket-at-unit t u)) g d ≡
      run (bracket (field-from-tangent t) (field-from-tangent u)) g d
  bracket-field-compatibility t u =
    field-tangent-roundtrip (bracket (field-from-tangent t) (field-from-tangent u))
      (invariant-bracket (field-from-tangent t) (field-from-tangent u)
        (tangent-field-invariant t) (tangent-field-invariant u))

-- The neutral tangent space of the endomorphism monoid is the type of vector
-- fields, as pointwise maps. This part does not need group inverses.
module Endomorphisms {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext : FunExt ℓ ℓ) (M : Set ℓ) where
  open Infinitesimals A
  open S7.Basics A setR
  open S8.Basics A setR

  endomorphismMonoid : Monoid (M → M)
  endomorphismMonoid = record
    { unit = λ m → m
    ; _·_ = λ f g m → f (g m)
    ; assoc = λ f g h → refl
    ; identityˡ = λ f → refl
    ; identityʳ = λ f → refl
    }

  field-to-tangent : VectorField M → Tangent (M → M) (λ m → m)
  field-to-tangent X = tangent (λ d m → run X m d) (ext (run-zero X))

  tangent-to-field : Tangent (M → M) (λ m → m) → VectorField M
  run (tangent-to-field t) m d = curve t d m
  run-zero (tangent-to-field t) m = cong (λ f → f m) (based t)

  field-roundtrip : (X : VectorField M) (m : M) (d : D) →
    run (tangent-to-field (field-to-tangent X)) m d ≡ run X m d
  field-roundtrip X m d = refl

  tangent-roundtrip : (t : Tangent (M → M) (λ m → m)) (d : D) (m : M) →
    curve (field-to-tangent (tangent-to-field t)) d m ≡ curve t d m
  tangent-roundtrip t d m = refl

