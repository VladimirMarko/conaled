{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08Module where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.FunctionRing
open import SDG.Axiom
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8

-- Proposition I.8.3. The module laws are lifted from the proved tangent
-- module laws, with equality of vector-field records checked explicitly.
module Fields {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR
  open S8.Basics A setR
  module Tangents = S7L.Construction A setR ext0 M IL

  field-add : VectorField M → VectorField M → VectorField M
  field-add X Y = section-field
    (λ m → Tangents.add (field-section X m) (field-section Y m))

  field-negate : VectorField M → VectorField M
  field-negate = scale-field (λ _ → - 1r)

  -- These proof terms stay opaque during later module specializations.
  abstract
    field-add-assoc : (X Y Z : VectorField M) →
      field-add (field-add X Y) Z ≡ field-add X (field-add Y Z)
    field-add-assoc X Y Z = field-ext ext setM
      (λ m d → Tangents.add-assoc (field-section X m) (field-section Y m) (field-section Z m) d)

    field-add-comm : (X Y : VectorField M) → field-add X Y ≡ field-add Y X
    field-add-comm X Y = field-ext ext setM
      (λ m d → Tangents.add-comm (field-section X m) (field-section Y m) d)

    field-add-zero : (X : VectorField M) → field-add zero-field X ≡ X
    field-add-zero X = field-ext ext setM
      (λ m d → Tangents.add-zeroˡ (field-section X m) d)

    field-add-inverse : (X : VectorField M) → field-add (field-negate X) X ≡ zero-field
    field-add-inverse X = field-ext ext setM
      (λ m d → Tangents.add-inverseˡ (field-section X m) d)

    field-scale-one : (X : VectorField M) → scale-field (λ _ → 1r) X ≡ X
    field-scale-one X = field-ext ext setM (scale-field-one X)

    field-scale-assoc : (f g : M → R) (X : VectorField M) →
      scale-field (λ m → f m * g m) X ≡ scale-field f (scale-field g X)
    field-scale-assoc f g X = field-ext ext setM (scale-field-assoc f g X)

    field-scale-add : (f g : M → R) (X : VectorField M) →
      scale-field (λ m → f m + g m) X ≡ field-add (scale-field f X) (scale-field g X)
    field-scale-add f g X = field-ext ext setM
      (λ m d → Tangents.speed-add-scalars (f m) (g m) (field-section X m) d)

    field-scale-distrib : (f : M → R) (X Y : VectorField M) →
      scale-field f (field-add X Y) ≡ field-add (scale-field f X) (scale-field f Y)
    field-scale-distrib f X Y = field-ext ext setM
      (λ m d → Tangents.speed-add-vectors (f m) (field-section X m) (field-section Y m) d)

  vectorFieldsModule : RModule (functionRing A M ext) ℓ
  vectorFieldsModule = record
    { V = VectorField M
    ; 0v = zero-field
    ; _+v_ = field-add
    ; -v_ = field-negate
    ; _•_ = scale-field
    ; add-assoc = field-add-assoc
    ; add-comm = field-add-comm
    ; add-zeroˡ = field-add-zero
    ; add-inverseˡ = field-add-inverse
    ; scalar-one = field-scale-one
    ; scalar-assoc = field-scale-assoc
    ; scalar-add = field-scale-add
    ; scalar-distrib = field-scale-distrib
    }

  negative-field-is-module-negation : (X : VectorField M) → negative-field X ≡ field-negate X
  negative-field-is-module-negation X = field-ext ext setM (negative-is-scale X)

