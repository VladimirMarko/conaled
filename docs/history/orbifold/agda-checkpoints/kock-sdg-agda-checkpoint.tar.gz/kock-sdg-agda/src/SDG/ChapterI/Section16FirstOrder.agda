{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16FirstOrder where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Algebra.DualNumbers using (RingHom; module DualNumbers)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Algebra.RelativeDual using (product-isSet)
open import SDG.Finite using (Fin; fzero; fsuc)
import SDG.ChapterI.Section12 as S12
import SDG.ChapterI.Section16Comparison as Comparison

-- Theorem 12.1, first-order case, now proved from Axiom 2. The dual
-- algebra, its nilpotent generator, and every evaluation law are
-- constructed algebraically before the comparison theorem is applied.
module FirstOrder {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
  open RingLemmas A
  open Infinitesimals A
  open Presentations k
  open S12.Comprehensive k A base ext ext0 setR
  open Comparison.Comparison k A base ext ext0 setR Ax
  module Dual = DualNumbers A

  dual-algebra : RAlgebra A ℓ
  dual-algebra = dualAlgebra (scalarAlgebra A)

  dual-point : SpecC dual-algebra dualLine
  coordinates dual-point i = Dual.ε
  satisfies dual-point j = Dual.ε-square-zero

  to-spectrum : D → Affine dualLine
  coordinates (to-spectrum d) i = value d
  satisfies (to-spectrum d) j = square-zero d

  from-spectrum : Affine dualLine → D
  from-spectrum x = infinitesimal (coordinates x fzero) (satisfies x fzero)

  from-to-spectrum : (d : D) → from-spectrum (to-spectrum d) ≡ d
  from-to-spectrum d = refl

  to-from-spectrum : (x : Affine dualLine) → to-spectrum (from-spectrum x) ≡ x
  to-from-spectrum x = spec-path ext0 setR λ { fzero → refl ; (fsuc ()) }

  affine-evaluate : D → Dual.Dual → R
  affine-evaluate d p = fst p + value d * snd p

  affine-evaluate-scalar : (d : D) (r : R) → affine-evaluate d (Dual.scalar r) ≡ r
  affine-evaluate-scalar d r = trans (cong (r +_) (*-zeroʳ (value d))) (+-identityʳ r)

  dual-character : D → AlgHom dual-algebra (scalarAlgebra A)
  RingHom.hom (ringHom (dual-character d)) = affine-evaluate d
  RingHom.pres-0 (ringHom (dual-character d)) = affine-evaluate-scalar d 0r
  RingHom.pres-1 (ringHom (dual-character d)) = affine-evaluate-scalar d 1r
  RingHom.pres-+ (ringHom (dual-character d)) (a , b) (c , e) =
    trans (cong ((a + c) +_) (distribˡ (value d) b e)) (+-shuffle a c (value d * b) (value d * e))
  RingHom.pres-* (ringHom (dual-character d)) (a , b) (c , e) =
    sym (affine-product (value d) a b c e (square-zero d))
  RingHom.pres-neg (ringHom (dual-character d)) (a , b) =
    trans (cong ((- a) +_) (neg-mulʳ (value d) b)) (sym (neg-add a (value d * b)))
  commutes (dual-character d) r = affine-evaluate-scalar d r

  character-generator : (d : D) → algMap (dual-character d) Dual.ε ≡ value d
  character-generator d = trans (+-identityˡ (value d * 1r)) (*-identityʳ (value d))

  hom-normal-form : (f : AlgHom dual-algebra dual-algebra) (p : Dual.Dual) →
    algMap f p ≡ Dual.add (Dual.scalar (fst p)) (Dual.mul (algMap f Dual.ε) (Dual.scalar (snd p)))
  hom-normal-form f p =
    trans (cong (algMap f) (sym (Dual.normal-form p)))
      (trans (RingHom.pres-+ (ringHom f) (Dual.scalar (fst p)) (Dual.mul Dual.ε (Dual.scalar (snd p))))
        (cong₂ Dual.add (commutes f (fst p))
          (trans (RingHom.pres-* (ringHom f) Dual.ε (Dual.scalar (snd p)))
            (cong (Dual.mul (algMap f Dual.ε)) (commutes f (snd p))))))

  dual-generated : (f g : AlgHom dual-algebra dual-algebra) → algMap f Dual.ε ≡ algMap g Dual.ε → f ≡ g
  dual-generated f g eq = algHom-ext ext ext ext (product-isSet setR setR)
    (λ p → trans (hom-normal-form f p)
      (trans (cong (λ e → Dual.add (Dual.scalar (fst p)) (Dual.mul e (Dual.scalar (snd p)))) eq)
        (sym (hom-normal-form g p))))

  dual-realization : AlgebraicRealization dualLine
  model-algebra dual-realization = dual-algebra
  set-carrier dual-realization = product-isSet setR setR
  generic-point dual-realization = dual-point
  character dual-realization x = dual-character (from-spectrum x)
  evaluate-generator dual-realization x fzero = character-generator (from-spectrum x)
  evaluate-generator dual-realization x (fsuc ())
  generated dual-realization f g eq = dual-generated f g (eq fzero)

  module Iso = Realized dualLine dual-realization

  coefficients : (D → R) → Dual.Dual
  coefficients f = algMap Iso.beta (λ x → f (from-spectrum x))

  affine-reconstruction : (f : D → R) (d : D) →
    f d ≡ fst (coefficients f) + value d * snd (coefficients f)
  affine-reconstruction f d = sym (cong (λ h → algMap h (λ x → f (from-spectrum x)) (to-spectrum d)) Iso.alpha-beta)

  constant-coefficient : (f : D → R) → fst (coefficients f) ≡ f zeroD
  constant-coefficient f = sym
    (trans (affine-reconstruction f zeroD)
      (trans (cong (fst (coefficients f) +_) (*-zeroˡ (snd (coefficients f)))) (+-identityʳ (fst (coefficients f)))))

  slope : (D → R) → R
  slope f = snd (coefficients f)

  expansion : (f : D → R) (d : D) → f d ≡ f zeroD + value d * slope f
  expansion f d = trans (affine-reconstruction f d)
    (cong (_+ (value d * slope f)) (constant-coefficient f))

  uniqueness : (f : D → R) (b : R) → ((d : D) → f d ≡ f zeroD + value d * b) → slope f ≡ b
  uniqueness f b eq = cong snd
    (trans (cong (algMap Iso.beta) (ext (λ x → eq (from-spectrum x))))
      (cong (λ h → algMap h (f zeroD , b)) Iso.beta-alpha))

  axiom2-first-order : KockLawvere
  KockLawvere.slope axiom2-first-order = slope
  KockLawvere.expansion axiom2-first-order = expansion
  KockLawvere.uniqueness axiom2-first-order = uniqueness
