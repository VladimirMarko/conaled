{-# OPTIONS --safe --without-K #-}
module SDG.Flows.CommutingActions where

open import SDG.Prelude
open import SDG.Finite using (Fin; fzero; fsuc; fsuc-injective;
  compareFin; same; different; Vec; []; _∷_; lookup; update; delete;
  lookup-update-same; lookup-update-other; vec-ext;
  Permutation; permutation; to; from; from-to; to-from; identityPerm; composePerm;
  permute; lookup-permute; permute-identity; permute-compose)

private
  fin-empty : Fin zero → ⊥
  fin-empty ()

  compareFin-self : {n : ℕ} (i : Fin n) → compareFin i i ≡ same
  compareFin-self fzero = refl
  compareFin-self (fsuc i) rewrite compareFin-self i = refl

-- Transpose the first index with any selected index.
swapZero : {n : ℕ} → Fin (suc n) → Fin (suc n) → Fin (suc n)
swapZero fzero i = i
swapZero (fsuc j) fzero = fsuc j
swapZero (fsuc j) (fsuc i) with compareFin i j
... | same = fzero
... | different ne = fsuc i

swapZero-pivot : {n : ℕ} (j : Fin (suc n)) → swapZero j j ≡ fzero
swapZero-pivot fzero = refl
swapZero-pivot (fsuc j) rewrite compareFin-self j = refl

swapZero-other : {n : ℕ} (i j : Fin n) → (i ≡ j → Fin zero) →
  swapZero (fsuc j) (fsuc i) ≡ fsuc i
swapZero-other i j ne with compareFin i j
... | same = ⊥-elim (fin-empty (ne refl))
... | different q = refl

swapZero-involutive : {n : ℕ} (j i : Fin (suc n)) → swapZero j (swapZero j i) ≡ i
swapZero-involutive fzero i = refl
swapZero-involutive (fsuc j) fzero = swapZero-pivot (fsuc j)
swapZero-involutive (fsuc j) (fsuc i) with compareFin i j
... | same = refl
... | different ne = swapZero-other i j ne

swapPermutation : {n : ℕ} → Fin (suc n) → Permutation (suc n)
swapPermutation j = permutation (swapZero j) (swapZero j)
  (swapZero-involutive j) (swapZero-involutive j)

private
  predecessor : {n : ℕ} (i : Fin (suc n)) → i ≢ fzero → Fin n
  predecessor fzero ne = ⊥-elim (ne refl)
  predecessor (fsuc i) ne = i

  predecessor-reconstruct : {n : ℕ} (i : Fin (suc n)) (ne : i ≢ fzero) →
    fsuc (predecessor i ne) ≡ i
  predecessor-reconstruct fzero ne = ⊥-elim (ne refl)
  predecessor-reconstruct (fsuc i) ne = refl

  inverse-fixes-zero : {n : ℕ} (p : Permutation (suc n)) →
    to p fzero ≡ fzero → from p fzero ≡ fzero
  inverse-fixes-zero p fixes = trans (sym (cong (from p) fixes)) (from-to p fzero)

  to-nonzero : {n : ℕ} (p : Permutation (suc n)) → to p fzero ≡ fzero →
    (i : Fin n) → to p (fsuc i) ≢ fzero
  to-nonzero p fixes i q = impossible
    (trans (sym (from-to p (fsuc i)))
      (trans (cong (from p) q) (inverse-fixes-zero p fixes)))
    where
    impossible : fsuc i ≢ fzero
    impossible ()

  from-nonzero : {n : ℕ} (p : Permutation (suc n)) → to p fzero ≡ fzero →
    (i : Fin n) → from p (fsuc i) ≢ fzero
  from-nonzero p fixes i q = impossible
    (trans (sym (to-from p (fsuc i))) (trans (cong (to p) q) fixes))
    where
    impossible : fsuc i ≢ fzero
    impossible ()

tailPermutation : {n : ℕ} (p : Permutation (suc n)) →
  to p fzero ≡ fzero → Permutation n
tailPermutation p fixes = permutation forward backward left right
  where
  forward backward : Fin _ → Fin _
  forward i = predecessor (to p (fsuc i)) (to-nonzero p fixes i)
  backward i = predecessor (from p (fsuc i)) (from-nonzero p fixes i)

  forward-reconstruct : (i : Fin _) → fsuc (forward i) ≡ to p (fsuc i)
  forward-reconstruct i = predecessor-reconstruct (to p (fsuc i)) (to-nonzero p fixes i)

  backward-reconstruct : (i : Fin _) → fsuc (backward i) ≡ from p (fsuc i)
  backward-reconstruct i = predecessor-reconstruct (from p (fsuc i)) (from-nonzero p fixes i)

  left : (i : Fin _) → backward (forward i) ≡ i
  left i = fsuc-injective
    (trans (backward-reconstruct (forward i))
      (trans (cong (from p) (forward-reconstruct i)) (from-to p (fsuc i))))

  right : (i : Fin _) → forward (backward i) ≡ i
  right i = fsuc-injective
    (trans (forward-reconstruct (backward i))
      (trans (cong (to p) (backward-reconstruct i)) (to-from p (fsuc i))))

tailPermutation-forward : {n : ℕ} (p : Permutation (suc n))
  (fixes : to p fzero ≡ fzero) (i : Fin n) →
  fsuc (to (tailPermutation p fixes) i) ≡ to p (fsuc i)
tailPermutation-forward p fixes i =
  predecessor-reconstruct (to p (fsuc i)) (to-nonzero p fixes i)

permute-fixed : {a : Level} {A : Set a} {n : ℕ} (p : Permutation (suc n))
  (fixes : to p fzero ≡ fzero) (x : A) (xs : Vec A n) →
  permute p (x ∷ xs) ≡ x ∷ permute (tailPermutation p fixes) xs
permute-fixed p fixes x xs = vec-ext λ
  { fzero → trans (lookup-permute p (x ∷ xs) fzero) (cong (lookup (x ∷ xs)) fixes)
  ; (fsuc i) → trans (lookup-permute p (x ∷ xs) (fsuc i))
      (trans (cong (lookup (x ∷ xs)) (sym (tailPermutation-forward p fixes i)))
        (sym (lookup-permute (tailPermutation p fixes) xs i))) }

permute-decompose : {a : Level} {A : Set a} {n : ℕ} (p : Permutation (suc n)) (xs : Vec A (suc n)) →
  permute p xs ≡ permute (composePerm (swapPermutation (to p fzero)) p)
    (permute (swapPermutation (to p fzero)) xs)
permute-decompose p xs = vec-ext (λ i →
  trans (lookup-permute p xs i)
    (trans (cong (lookup xs) (sym (swapZero-involutive (to p fzero) (to p i))))
      (trans (sym (lookup-permute (swapPermutation (to p fzero)) xs
        (to (composePerm (swapPermutation (to p fzero)) p) i)))
        (sym (lookup-permute (composePerm (swapPermutation (to p fzero)) p)
          (permute (swapPermutation (to p fzero)) xs) i)))))

private
  delete-update : {a : Level} {A : Set a} {n : ℕ}
    (xs : Vec A (suc n)) (i : Fin (suc n)) (x : A) →
    delete (update xs i x) i ≡ delete xs i
  delete-update (y ∷ ys) fzero x = refl
  delete-update {n = suc n} (y ∷ ys) (fsuc i) x = cong (y ∷_) (delete-update ys i x)

  swapVector : {a : Level} {A : Set a} {n : ℕ} → Fin (suc n) → Vec A (suc n) → Vec A (suc n)
  swapVector fzero xs = xs
  swapVector (fsuc i) (x ∷ xs) = lookup xs i ∷ update xs i x

  permute-swap : {a : Level} {A : Set a} {n : ℕ}
    (i : Fin (suc n)) (xs : Vec A (suc n)) →
    permute (swapPermutation i) xs ≡ swapVector i xs
  permute-swap fzero xs = permute-identity xs
  permute-swap (fsuc i) (x ∷ xs) = vec-ext (λ j →
    trans (lookup-permute (swapPermutation (fsuc i)) (x ∷ xs) j) (lookup-swap j))
    where
    lookup-swap : (j : Fin _) →
      lookup (x ∷ xs) (swapZero (fsuc i) j) ≡ lookup (lookup xs i ∷ update xs i x) j
    lookup-swap fzero = refl
    lookup-swap (fsuc j) with compareFin j i
    ... | same = sym (lookup-update-same xs i x)
    ... | different ne = sym (lookup-update-other xs i j x (λ q → ne (sym q)))

-- Finite sequences of pairwise commuting transformations are symmetric.
-- This theorem is independent of SDG and supplies the combinatorial step
-- in extending an infinitesimal flow along the finite summation maps.
module Actions {a b : Level} (D : Set a) (M : Set b)
  (act : D → M → M)
  (commute : (d e : D) (m : M) → act d (act e m) ≡ act e (act d m)) where

  sequence : {n : ℕ} → Vec D n → M → M
  sequence [] m = m
  sequence (d ∷ ds) m = act d (sequence ds m)

  sequence-extract : {n : ℕ} (ds : Vec D (suc n)) (i : Fin (suc n)) (m : M) →
    sequence ds m ≡ act (lookup ds i) (sequence (delete ds i) m)
  sequence-extract (d ∷ ds) fzero m = refl
  sequence-extract {n = suc n} (d ∷ ds) (fsuc i) m =
    trans (cong (act d) (sequence-extract ds i m))
      (commute d (lookup ds i) (sequence (delete ds i) m))

  sequence-swap : {n : ℕ} (i : Fin (suc n)) (ds : Vec D (suc n)) (m : M) →
    sequence (permute (swapPermutation i) ds) m ≡ sequence ds m
  sequence-swap fzero ds m = cong (λ es → sequence es m) (permute-swap fzero ds)
  sequence-swap {n = suc n} (fsuc i) (d ∷ ds) m =
    trans (cong (λ es → sequence es m) (permute-swap (fsuc i) (d ∷ ds)))
      (trans (cong (act (lookup ds i)) (sequence-extract (update ds i d) i m))
        (trans (cong (λ e → act (lookup ds i) (act e (sequence (delete (update ds i d) i) m)))
          (lookup-update-same ds i d))
          (trans (cong (λ es → act (lookup ds i) (act d (sequence es m)))
            (delete-update ds i d))
            (trans (commute (lookup ds i) d (sequence (delete ds i) m))
              (cong (act d) (sym (sequence-extract ds i m)))))))

  sequence-permute : {n : ℕ} (p : Permutation n) (ds : Vec D n) (m : M) →
    sequence (permute p ds) m ≡ sequence ds m
  sequence-permute {zero} p [] m = refl
  sequence-permute {suc n} p ds m =
    trans (cong (λ es → sequence es m) (permute-decompose p ds))
      (trans (fixed-invariant (composePerm (swapPermutation (to p fzero)) p)
        (swapZero-pivot (to p fzero)) (permute (swapPermutation (to p fzero)) ds))
        (sequence-swap (to p fzero) ds m))
    where
    fixed-invariant : (q : Permutation (suc n)) (fixes : to q fzero ≡ fzero)
      (es : Vec D (suc n)) → sequence (permute q es) m ≡ sequence es m
    fixed-invariant q fixes (e ∷ es) =
      trans (cong (λ fs → sequence fs m) (permute-fixed q fixes e es))
        (cong (act e) (sequence-permute (tailPermutation q fixes) es m))

