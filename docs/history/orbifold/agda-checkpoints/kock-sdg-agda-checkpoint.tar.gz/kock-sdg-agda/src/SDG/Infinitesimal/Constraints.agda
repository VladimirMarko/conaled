{-# OPTIONS --safe --without-K #-}

module SDG.Infinitesimal.Constraints where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Vec; []; _∷_; Fin; lookup)
open import SDG.Infinitesimal.Jets

module Constraints {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Jets A

  monomial : {n q : ℕ} → Vec R n → Vec (Fin n) q → R
  monomial xs [] = 1r
  monomial xs (i ∷ is) = lookup xs i * monomial xs is

  products-to-monomials : {n q : ℕ} (xs : Vec R n) (r : R) →
    ProductsZero xs q r → (is : Vec (Fin n) q) → r * monomial xs is ≡ 0r
  products-to-monomials xs r p [] = trans (*-identityʳ r) p
  products-to-monomials xs r p (i ∷ is) =
    trans (sym (*-assoc r (lookup xs i) (monomial xs is)))
      (products-to-monomials xs (r * lookup xs i) (p i) is)

  monomials-to-products : {n : ℕ} (xs : Vec R n) (q : ℕ) (r : R) →
    ((is : Vec (Fin n) q) → r * monomial xs is ≡ 0r) → ProductsZero xs q r
  monomials-to-products xs zero r p = trans (sym (*-identityʳ r)) (p [])
  monomials-to-products xs (suc q) r p i =
    monomials-to-products xs q (r * lookup xs i)
      (λ is → trans (*-assoc r (lookup xs i) (monomial xs is)) (p (i ∷ is)))

  jet-monomial-zero : {k n : ℕ} (d : DJet k n) (is : Vec (Fin n) (suc k)) →
    monomial (coords d) is ≡ 0r
  jet-monomial-zero d is =
    trans (sym (*-identityˡ (monomial (coords d) is)))
      (products-to-monomials (coords d) 1r (vanish d) is)

  makeJet : {k n : ℕ} (xs : Vec R n) →
    ((is : Vec (Fin n) (suc k)) → monomial xs is ≡ 0r) → DJet k n
  makeJet {k} xs p = jet xs (monomials-to-products xs (suc k) 1r
    (λ is → trans (*-identityˡ (monomial xs is)) (p is)))
