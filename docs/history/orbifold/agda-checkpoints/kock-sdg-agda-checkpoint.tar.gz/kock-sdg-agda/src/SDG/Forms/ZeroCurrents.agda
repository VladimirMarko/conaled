{-# OPTIONS --safe --without-K #-}
module SDG.Forms.ZeroCurrents where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Forms.Basic
import SDG.Forms.Currents as FC
import SDG.ChapterI.Section07Linear as L

-- The identification of zero-currents with distributions stated in I.14.
module Distributions {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setV : isSet (RModule.V Vmod)) (M : Set ℓ) where
  open ModuleLemmas A Vmod
  open FC.Currents A Vmod ext0 ext setV
  open L.ModuleMap

  Distribution : Set ℓ
  Distribution = L.ModuleMap A (functionModule A Vmod M ext) Vmod

  current-zero : (γ : Current zero M) → integrate γ zero-form ≡ 0v
  current-zero γ = trans (cong (integrate γ)
    (form-ext (λ τ → sym (zero-scalar 0v))))
    (trans (homogeneous-current γ 0r zero-form) (zero-scalar (integrate γ zero-form)))

  to-distribution : Current zero M → Distribution
  apply (to-distribution γ) f = integrate γ (function-form f)
  preserves-zero (to-distribution γ) = trans
    (cong (integrate γ) (form-ext (λ _ → refl))) (current-zero γ)
  preserves-add (to-distribution γ) f g = trans
    (cong (integrate γ) (form-ext (λ _ → refl))) (additive γ (function-form f) (function-form g))
  preserves-scale (to-distribution γ) r f = trans
    (cong (integrate γ) (form-ext (λ _ → refl))) (homogeneous-current γ r (function-form f))

  from-distribution : Distribution → Current zero M
  integrate (from-distribution δ) ω = apply δ (form-function ω)
  additive (from-distribution δ) ω θ = preserves-add δ (form-function ω) (form-function θ)
  homogeneous-current (from-distribution δ) r ω = preserves-scale δ r (form-function ω)

  current-roundtrip : (γ : Current zero M) → from-distribution (to-distribution γ) ≡ γ
  current-roundtrip γ = current-ext (λ ω → cong (integrate γ)
    (form-ext (zero-form-roundtrip ext ω)))

  distribution-roundtrip : (δ : Distribution) (f : M → V) →
    apply (to-distribution (from-distribution δ)) f ≡ apply δ f
  distribution-roundtrip δ f = refl
