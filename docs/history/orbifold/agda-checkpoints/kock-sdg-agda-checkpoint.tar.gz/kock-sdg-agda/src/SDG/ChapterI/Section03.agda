{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section03 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; head; tail; map; zipWith; Fin; fzero; fsuc;
   finToNat; lookup; tabulate; lookup-tabulate; vec-ext;
   nat-add-zeroʳ; nat-add-sucʳ)
import SDG.ChapterI.Section01 as S1
import SDG.ChapterI.Section02 as S2

-- Kock I.3. The coefficient interface below is exactly the polynomial
-- existence-and-uniqueness assumption (Axiom 1′); Taylor's theorem is not
-- a field of this interface.
module HigherInfinitesimals {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A public
  open Infinitesimals A using (D; value; square-zero)

  record DK (k : ℕ) : Set ℓ where
    constructor nilpotent
    field
      valueK : R
      nilpotence : valueK ^ suc k ≡ 0r
  open DK public

  zeroK : (k : ℕ) → DK k
  zeroK k = nilpotent 0r (zero-positive-power k)

  scaleK : {k : ℕ} → DK k → R → DK k
  scaleK {k} d r = nilpotent (valueK d * r)
    (nilpotent-scaled (valueK d) r (suc k) (nilpotence d))

  weakenK : {k : ℕ} → DK k → DK (suc k)
  weakenK d = nilpotent (valueK d)
    (trans (cong (valueK d *_) (nilpotence d)) (*-zeroʳ (valueK d)))

  inclusionK : {k : ℕ} → DK k → (m : ℕ) → DK (k +ℕ m)
  inclusionK {k} d m = nilpotent (valueK d)
    (nilpotent-monotone (valueK d) (suc k) m (nilpotence d))

  fromD : D → DK (suc zero)
  fromD d = nilpotent (value d) (trans (power-two (value d)) (square-zero d))

  toD : DK (suc zero) → D
  toD d = Infinitesimals.infinitesimal (valueK d)
    (trans (sym (power-two (valueK d))) (nilpotence d))

  private
    cancel-path-left : {x y z : R} (p : x ≡ y) (q : y ≡ z) →
      trans (sym p) (trans p q) ≡ q
    cancel-path-left refl q = refl

  toD-fromD : (d : D) → toD (fromD d) ≡ d
  toD-fromD d = cong (Infinitesimals.infinitesimal (value d))
    (cancel-path-left (power-two (value d)) (square-zero d))

  sumD2 : D → D → DK (suc (suc zero))
  sumD2 d e = nilpotent (value d + value e)
    (trans (cong ((value d + value e) *_) (power-two (value d + value e)))
      (trans (sym (*-assoc (value d + value e) (value d + value e) (value d + value e)))
        (square-zero-sum-cube (value d) (value e) (square-zero d) (square-zero e))))

  shiftK : {k : ℕ} → DK k → D → DK (suc k)
  shiftK {k} a d = nilpotent (valueK a + value d)
    (trans (power-first-order (valueK a) (value d) (suc k) (square-zero d))
      (trans (cong₂ _+_
        (trans (cong (valueK a *_) (nilpotence a)) (*-zeroʳ (valueK a)))
        (trans (cong (value d *_)
          (trans (cong (fromℕ (suc (suc k)) *_) (nilpotence a))
            (*-zeroʳ (fromℕ (suc (suc k)))))) (*-zeroʳ (value d))))
        (+-identityˡ 0r)))

  -- Vectors list coefficients in ascending order, starting at degree zero.
  eval : {n : ℕ} → Vec R n → R → R
  eval [] x = 0r
  eval (a ∷ as) x = a + x * eval as x

  eval-zero : {n : ℕ} (as : Vec R (suc n)) → eval as 0r ≡ head as
  eval-zero (a ∷ as) =
    trans (cong (a +_) (*-zeroˡ (eval as 0r))) (+-identityʳ a)

  eval-constant : (a x : R) → eval (a ∷ []) x ≡ a
  eval-constant a x = trans (cong (a +_) (*-zeroʳ x)) (+-identityʳ a)

  eval-linear : (a b x : R) → eval (a ∷ b ∷ []) x ≡ a + x * b
  eval-linear a b x = cong (λ z → a + x * z) (eval-constant b x)

  eval-quadratic : (a b c x : R) →
    eval (a ∷ b ∷ c ∷ []) x ≡ (a + x * b) + (x * x) * c
  eval-quadratic a b c x =
    begin
      eval (a ∷ b ∷ c ∷ []) x
    ≡⟨ cong (λ z → a + x * z) (eval-linear b c x) ⟩
      a + x * (b + x * c)
    ≡⟨ cong (a +_) (distribˡ x b (x * c)) ⟩
      a + ((x * b) + (x * (x * c)))
    ≡⟨ cong (λ z → a + ((x * b) + z)) (sym (*-assoc x x c)) ⟩
      a + ((x * b) + ((x * x) * c))
    ≡⟨ sym (+-assoc a (x * b) ((x * x) * c)) ⟩
      (a + x * b) + (x * x) * c ∎

  eval-scale : {n : ℕ} (r : R) (as : Vec R n) (x : R) →
    eval (map (r *_) as) x ≡ r * eval as x
  eval-scale r [] x = sym (*-zeroʳ r)
  eval-scale r (a ∷ as) x =
    begin
      (r * a) + x * eval (map (r *_) as) x
    ≡⟨ cong (λ z → (r * a) + x * z) (eval-scale r as x) ⟩
      (r * a) + x * (r * eval as x)
    ≡⟨ cong ((r * a) +_) (*-swap x r (eval as x)) ⟩
      (r * a) + r * (x * eval as x)
    ≡⟨ sym (distribˡ r a (x * eval as x)) ⟩
      r * (a + x * eval as x) ∎

  eval-add : {n : ℕ} (as bs : Vec R n) (x : R) →
    eval (zipWith _+_ as bs) x ≡ eval as x + eval bs x
  eval-add [] [] x = sym (+-identityˡ 0r)
  eval-add (a ∷ as) (b ∷ bs) x =
    trans (cong (λ z → (a + b) + x * z) (eval-add as bs x))
      (trans (cong ((a + b) +_) (distribˡ x (eval as x) (eval bs x)))
        (+-shuffle a b (x * eval as x) (x * eval bs x)))

  weightFrom : {n : ℕ} → ℕ → Vec R n → Vec R n
  weightFrom m [] = []
  weightFrom m (a ∷ as) = fromℕ m * a ∷ weightFrom (suc m) as

  weight-step : {n : ℕ} (m : ℕ) (as : Vec R n) →
    weightFrom (suc m) as ≡ zipWith _+_ as (weightFrom m as)
  weight-step m [] = refl
  weight-step m (a ∷ as) = cong₂ _∷_
    (trans (distribʳ 1r (fromℕ m) a) (cong (_+ (fromℕ m * a)) (*-identityˡ a)))
    (weight-step (suc m) as)

  lookup-weight : {n : ℕ} (m : ℕ) (as : Vec R n) (i : Fin n) →
    lookup (weightFrom m as) i ≡ fromℕ (m +ℕ finToNat i) * lookup as i
  lookup-weight m (a ∷ as) fzero = cong (λ k → fromℕ k * a) (sym (nat-add-zeroʳ m))
  lookup-weight m (a ∷ as) (fsuc i) =
    trans (lookup-weight (suc m) as i)
      (cong (λ k → fromℕ k * lookup as i) (sym (nat-add-sucʳ m (finToNat i))))

  differentiate : {n : ℕ} → Vec R (suc n) → Vec R n
  differentiate (a ∷ as) = weightFrom (suc zero) as

  differentiate-recurrence : {n : ℕ} (a b : R) (as : Vec R n) →
    differentiate (a ∷ b ∷ as) ≡
      zipWith _+_ (b ∷ as) (0r ∷ differentiate (b ∷ as))
  differentiate-recurrence a b as = cong₂ _∷_
    (trans (cong (_* b) fromℕ-one)
      (trans (*-identityˡ b) (sym (+-identityʳ b))))
    (weight-step (suc zero) as)

  eval-differentiate : {n : ℕ} (a b : R) (as : Vec R n) (x : R) →
    eval (differentiate (a ∷ b ∷ as)) x ≡
      eval (b ∷ as) x + x * eval (differentiate (b ∷ as)) x
  eval-differentiate a b as x =
    trans (cong (λ cs → eval cs x) (differentiate-recurrence a b as))
      (trans (eval-add (b ∷ as) (0r ∷ differentiate (b ∷ as)) x)
        (cong (eval (b ∷ as) x +_)
          (+-identityˡ (x * eval (differentiate (b ∷ as)) x))))

  horner-first-order : (a x d b c : R) → d * d ≡ 0r →
    a + (x + d) * (b + d * c) ≡ (a + x * b) + d * (b + x * c)
  horner-first-order a x d b c dd =
    begin
      a + (x + d) * (b + d * c)
    ≡⟨ cong (λ z → a + z * (b + d * c)) (cong (x +_) (sym (*-identityʳ d))) ⟩
      a + (x + d * 1r) * (b + d * c)
    ≡⟨ cong (a +_) (affine-product d x 1r b c dd) ⟩
      a + ((x * b) + d * ((x * c) + (b * 1r)))
    ≡⟨ sym (+-assoc a (x * b) (d * ((x * c) + (b * 1r)))) ⟩
      (a + x * b) + d * ((x * c) + (b * 1r))
    ≡⟨ cong (λ z → (a + x * b) + d * z)
          (trans (cong ((x * c) +_) (*-identityʳ b)) (+-comm (x * c) b)) ⟩
      (a + x * b) + d * (b + x * c) ∎

  polynomial-first-order : {n : ℕ} (as : Vec R (suc n)) (x : R) (d : D) →
    eval as (x + value d) ≡ eval as x + value d * eval (differentiate as) x
  polynomial-first-order (a ∷ []) x d =
    trans (eval-constant a (x + value d))
      (sym (trans (cong₂ _+_ (eval-constant a x) (*-zeroʳ (value d))) (+-identityʳ a)))
  polynomial-first-order (a ∷ b ∷ as) x d =
    trans (cong (λ z → a + (x + value d) * z) (polynomial-first-order (b ∷ as) x d))
      (trans (horner-first-order a x (value d) (eval (b ∷ as) x)
        (eval (differentiate (b ∷ as)) x) (square-zero d))
        (cong (λ z → eval (a ∷ b ∷ as) x + value d * z)
          (sym (eval-differentiate a b as x))))

  -- Direct monomial sum: the coefficient at offset j contributes x^j * a.
  monomialSum : {n : ℕ} → Vec R n → R → ℕ → R
  monomialSum [] x j = 0r
  monomialSum (a ∷ as) x j = (x ^ j) * a + monomialSum as x (suc j)

  monomialSum-shift : {n : ℕ} (as : Vec R n) (x : R) (j : ℕ) →
    monomialSum as x (suc j) ≡ x * monomialSum as x j
  monomialSum-shift [] x j = sym (*-zeroʳ x)
  monomialSum-shift (a ∷ as) x j =
    trans (cong₂ _+_ (*-assoc x (x ^ j) a) (monomialSum-shift as x (suc j)))
      (sym (distribˡ x ((x ^ j) * a) (monomialSum as x (suc j))))

  eval-as-sum : {n : ℕ} (as : Vec R n) (x : R) → eval as x ≡ monomialSum as x zero
  eval-as-sum [] x = refl
  eval-as-sum (a ∷ as) x =
    trans (cong (λ z → a + x * z) (eval-as-sum as x))
      (cong₂ _+_ (sym (*-identityˡ a)) (sym (monomialSum-shift as x zero)))

  record HigherKockLawvere : Set (lsuc ℓ) where
    field
      -- n indexes degree n + 1; the axiom is imposed only in positive degree.
      coefficients : (n : ℕ) → (DK (suc n) → R) → Vec R (suc (suc n))
      reconstruction : (n : ℕ) (g : DK (suc n) → R) (d : DK (suc n)) →
        g d ≡ eval (coefficients n g) (valueK d)
      uniqueness : (n : ℕ) (g : DK (suc n) → R) (as : Vec R (suc (suc n))) →
        ((d : DK (suc n)) → g d ≡ eval as (valueK d)) → coefficients n g ≡ as

  module PolynomialConsequences (H : HigherKockLawvere) where
    open HigherKockLawvere H

    constant-coefficient : (n : ℕ) (g : DK (suc n) → R) →
      head (coefficients n g) ≡ g (zeroK (suc n))
    constant-coefficient n g =
      trans (sym (eval-zero (coefficients n g)))
        (sym (reconstruction n g (zeroK (suc n))))

    recover-polynomial : (n : ℕ) (as : Vec R (suc (suc n))) →
      coefficients n (λ d → eval as (valueK d)) ≡ as
    recover-polynomial n as = uniqueness n (λ d → eval as (valueK d)) as (λ _ → refl)

    coefficient-extensionality : (n : ℕ) (as bs : Vec R (suc (suc n))) →
      ((d : DK (suc n)) → eval as (valueK d) ≡ eval bs (valueK d)) → as ≡ bs
    coefficient-extensionality n as bs p =
      trans (sym (recover-polynomial n as))
        (uniqueness n (λ d → eval as (valueK d)) bs p)

    polynomial-identity : (n : ℕ) (g h : DK (suc n) → R) →
      ((d : DK (suc n)) → g d ≡ h d) → coefficients n g ≡ coefficients n h
    polynomial-identity n g h p = uniqueness n g (coefficients n h)
      (λ d → trans (p d) (reconstruction n h d))

  -- The precise algebraic assumption used to divide a Taylor coefficient.
  -- An inhabitant must be supplied; no ordinary real field is instantiated.
  record PositiveNaturalsInvertible : Set ℓ where
    field
      reciprocal : ℕ → R
      reciprocal-law : (n : ℕ) → fromℕ (suc n) * reciprocal n ≡ 1r

-- Axiom 1′ really strengthens Axiom 1. The proof does not identify
-- arbitrary nilpotence witnesses: toD-fromD is proved by path cancellation.
module FirstOrderFromHigher {ℓ : Level} (A : CRing ℓ)
  (H : HigherInfinitesimals.HigherKockLawvere A) where
  open HigherInfinitesimals A
  open Infinitesimals A
  open HigherKockLawvere H

  firstJet : (D → R) → Vec R (suc (suc zero))
  firstJet g = coefficients zero (λ d → g (toD d))

  linear-normal-form : (as : Vec R (suc (suc zero))) (x : R) →
    eval as x ≡ head as + x * head (tail as)
  linear-normal-form (a ∷ b ∷ []) x = eval-linear a b x

  first-constant : (g : D → R) → head (firstJet g) ≡ g zeroD
  first-constant g =
    trans (sym (eval-zero (firstJet g)))
      (trans (sym (reconstruction zero (λ d → g (toD d)) (fromD zeroD)))
        (cong g (toD-fromD zeroD)))

  first-expansion : (g : D → R) (d : D) →
    g d ≡ g zeroD + value d * head (tail (firstJet g))
  first-expansion g d =
    trans (cong g (sym (toD-fromD d)))
      (trans (reconstruction zero (λ e → g (toD e)) (fromD d))
        (trans (linear-normal-form (firstJet g) (value d))
          (cong (_+ (value d * head (tail (firstJet g)))) (first-constant g))))

  first-unique : (g : D → R) (b : R) →
    ((d : D) → g d ≡ g zeroD + value d * b) → head (tail (firstJet g)) ≡ b
  first-unique g b p = cong (λ as → head (tail as))
    (uniqueness zero (λ d → g (toD d)) (g zeroD ∷ b ∷ [])
      (λ d → trans (p (toD d)) (sym (eval-linear (g zeroD) b (valueK d)))))

  firstOrder : KockLawvere
  KockLawvere.slope firstOrder g = head (tail (firstJet g))
  KockLawvere.expansion firstOrder = first-expansion
  KockLawvere.uniqueness firstOrder = first-unique

-- Theorem I.3.1 for k = 2, which is the case whose proof Kock gives
-- explicitly. Both coefficients are identified by proofs; the Taylor
-- formula itself is not an assumption in HigherKockLawvere.
module QuadraticTaylor {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (H : HigherInfinitesimals.HigherKockLawvere A) where
  open HigherInfinitesimals A
  open Infinitesimals A
  open HigherKockLawvere H
  open PolynomialConsequences H
  open S1.Results A K using (cancel-infinitesimals)
  open S2.Results A K using (derivative; derivative-unique; taylor-two)

  jet : (R → R) → R → Vec R (suc (suc (suc zero)))
  jet f x = coefficients (suc zero) (λ d → f (x + valueK d))

  b₀ b₁ b₂ : (R → R) → R → R
  b₀ f x = head (jet f x)
  b₁ f x = head (tail (jet f x))
  b₂ f x = head (tail (tail (jet f x)))

  jet-constant : (f : R → R) (x : R) → b₀ f x ≡ f x
  jet-constant f x = trans (constant-coefficient (suc zero) (λ d → f (x + valueK d)))
    (cong f (+-identityʳ x))

  quadratic-normal-form : (as : Vec R (suc (suc (suc zero)))) (x : R) →
    eval as x ≡ (head as + x * head (tail as)) + (x * x) * head (tail (tail as))
  quadratic-normal-form (a ∷ b ∷ c ∷ []) x = eval-quadratic a b c x

  jet-expansion : (f : R → R) (x : R) (d : DK (suc (suc zero))) →
    f (x + valueK d) ≡ (f x + valueK d * b₁ f x) +
      (valueK d * valueK d) * b₂ f x
  jet-expansion f x d =
    trans (reconstruction (suc zero) (λ e → f (x + valueK e)) d)
      (trans (quadratic-normal-form (jet f x) (valueK d))
        (cong (λ z → (z + valueK d * b₁ f x) + (valueK d * valueK d) * b₂ f x)
          (jet-constant f x)))

  linear-coefficient : (f : R → R) (x : R) → b₁ f x ≡ derivative f x
  linear-coefficient f x = sym (derivative-unique f x (b₁ f x)
    (λ d → trans (jet-expansion f x (weakenK (fromD d)))
      (trans (cong ((f x + value d * b₁ f x) +_)
        (trans (cong (_* b₂ f x) (square-zero d)) (*-zeroˡ (b₂ f x))))
        (+-identityʳ (f x + value d * b₁ f x)))))

  jet-linearized : (f : R → R) (x : R) (d : DK (suc (suc zero))) →
    f (x + valueK d) ≡ (f x + valueK d * derivative f x) +
      (valueK d * valueK d) * b₂ f x
  jet-linearized f x d = trans (jet-expansion f x d)
    (cong (λ z → (f x + valueK d * z) + (valueK d * valueK d) * b₂ f x)
      (linear-coefficient f x))

  cancel-two-infinitesimals : (b c : R) →
    ((d e : D) → (value d * value e) * b ≡ (value d * value e) * c) → b ≡ c
  cancel-two-infinitesimals b c p = cancel-infinitesimals b c
    (λ d → cancel-infinitesimals (value d * b) (value d * c)
      (λ e → trans (sym (*-assoc (value e) (value d) b))
        (trans (p e d) (*-assoc (value e) (value d) c))))

  quadratic-coefficient-times-two : (f : R → R) (x : R) →
    (1r + 1r) * b₂ f x ≡ derivative (derivative f) x
  quadratic-coefficient-times-two f x =
    cancel-two-infinitesimals ((1r + 1r) * b₂ f x) (derivative (derivative f) x)
      (λ d e → trans (sym (rearrange d e))
        (+-cancelˡ (f x + (value d + value e) * derivative f x)
          (trans (sym (jet-linearized f x (sumD2 d e))) (taylor-two f x d e))))
    where
    rearrange : (d e : D) →
      ((value d + value e) * (value d + value e)) * b₂ f x ≡
      (value d * value e) * ((1r + 1r) * b₂ f x)
    rearrange d e =
      trans (cong (_* b₂ f x)
        (square-zero-sum-square (value d) (value e) (square-zero d) (square-zero e)))
        (trans (*-assoc (1r + 1r) (value d * value e) (b₂ f x))
          (*-swap (1r + 1r) (value d * value e) (b₂ f x)))

  quadratic-coefficient : (half : R) → (1r + 1r) * half ≡ 1r →
    (f : R → R) (x : R) → b₂ f x ≡ half * derivative (derivative f) x
  quadratic-coefficient half half-law f x =
    begin
      b₂ f x
    ≡⟨ sym (*-identityˡ (b₂ f x)) ⟩
      1r * b₂ f x
    ≡⟨ cong (_* b₂ f x) (sym (trans (*-comm half (1r + 1r)) half-law)) ⟩
      (half * (1r + 1r)) * b₂ f x
    ≡⟨ *-assoc half (1r + 1r) (b₂ f x) ⟩
      half * ((1r + 1r) * b₂ f x)
    ≡⟨ cong (half *_) (quadratic-coefficient-times-two f x) ⟩
      half * derivative (derivative f) x ∎

  taylor-D2 : (half : R) → (1r + 1r) * half ≡ 1r →
    (f : R → R) (x : R) (d : DK (suc (suc zero))) →
    f (x + valueK d) ≡ (f x + valueK d * derivative f x) +
      (((valueK d * valueK d) * half) * derivative (derivative f) x)
  taylor-D2 half half-law f x d = trans (jet-linearized f x d)
    (cong ((f x + valueK d * derivative f x) +_)
      (trans (cong ((valueK d * valueK d) *_) (quadratic-coefficient half half-law f x))
        (sym (*-assoc (valueK d * valueK d) half (derivative (derivative f) x)))))

-- A polynomial identity on D_(n+1) differentiates to an identity on D_n.
-- This establishes the coefficient part of Taylor's theorem at every
-- order, using Axiom 1 and the algebraic shiftK construction alone.
module PolynomialDescent {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open HigherInfinitesimals A
  open Infinitesimals A
  open S1.Results A K using (cancel-infinitesimals)
  open S2.Results A K using (derivative; iterate; taylor)

  Expansion : (n : ℕ) → (R → R) → R → Vec R (suc n) → Set ℓ
  Expansion n f x as = (d : DK n) → f (x + valueK d) ≡ eval as (valueK d)

  differentiate-expansion : {n : ℕ} (f : R → R) (x : R) (as : Vec R (suc (suc n))) →
    Expansion (suc n) f x as → Expansion n (derivative f) x (differentiate as)
  differentiate-expansion f x as p a =
    cancel-infinitesimals (derivative f (x + valueK a)) (eval (differentiate as) (valueK a))
      (λ d → +-cancelˡ (f (x + valueK a))
        (trans (sym (taylor f (x + valueK a) d))
          (trans (cong f (+-assoc x (valueK a) (value d)))
            (trans (p (shiftK a d))
              (trans (polynomial-first-order as (valueK a) d)
                (cong (_+ (value d * eval (differentiate as) (valueK a)))
                  (sym (p (weakenK a)))))))))

  constant-from-expansion : (n : ℕ) (f : R → R) (x : R) (as : Vec R (suc n)) →
    Expansion n f x as → head as ≡ f x
  constant-from-expansion n f x as p =
    trans (sym (eval-zero as)) (trans (sym (p (zeroK n))) (cong f (+-identityʳ x)))

  iterate-derivative : (n : ℕ) (f : R → R) →
    iterate n (derivative f) ≡ iterate (suc n) f
  iterate-derivative zero f = refl
  iterate-derivative (suc n) f = cong derivative (iterate-derivative n f)

  coefficient-derivatives : {n : ℕ} (f : R → R) (x : R) (as : Vec R (suc n)) →
    Expansion n f x as → (i : Fin (suc n)) →
    factorial (finToNat i) * lookup as i ≡ iterate (finToNat i) f x
  coefficient-derivatives {n} f x (a ∷ as) p fzero =
    trans (*-identityˡ a) (constant-from-expansion n f x (a ∷ as) p)
  coefficient-derivatives {suc n} f x (a ∷ as) p (fsuc i) =
    begin
      (fromℕ (suc (finToNat i)) * factorial (finToNat i)) * lookup as i
    ≡⟨ *-assoc (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i) ⟩
      fromℕ (suc (finToNat i)) * (factorial (finToNat i) * lookup as i)
    ≡⟨ *-swap (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i) ⟩
      factorial (finToNat i) * (fromℕ (suc (finToNat i)) * lookup as i)
    ≡⟨ cong (factorial (finToNat i) *_) (sym (lookup-weight (suc zero) as i)) ⟩
      factorial (finToNat i) * lookup (differentiate (a ∷ as)) i
    ≡⟨ coefficient-derivatives (derivative f) x (differentiate (a ∷ as))
          (differentiate-expansion f x (a ∷ as) p) i ⟩
      iterate (finToNat i) (derivative f) x
    ≡⟨ cong (λ g → g x) (iterate-derivative (finToNat i) f) ⟩
      iterate (suc (finToNat i)) f x ∎

-- Full Theorem I.3.1 for every finite order. The conclusion is supplied in
-- both Horner form and the finite sum of delta^i * (f^(i)(x) / i!).
module GeneralTaylor {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (H : HigherInfinitesimals.HigherKockLawvere A)
  (Q : HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open HigherInfinitesimals A
  open HigherKockLawvere H
  open PositiveNaturalsInvertible Q
  open PolynomialDescent A K
  open S2.Results A K using (iterate)

  inverseFactorial : ℕ → R
  inverseFactorial zero = 1r
  inverseFactorial (suc n) = reciprocal n * inverseFactorial n

  factorial-inverse : (n : ℕ) → factorial n * inverseFactorial n ≡ 1r
  factorial-inverse zero = *-identityˡ 1r
  factorial-inverse (suc n) =
    trans (*-shuffle (fromℕ (suc n)) (factorial n) (reciprocal n) (inverseFactorial n))
      (trans (cong₂ _*_ (reciprocal-law n) (factorial-inverse n)) (*-identityˡ 1r))

  inverse-factorial-left : (n : ℕ) → inverseFactorial n * factorial n ≡ 1r
  inverse-factorial-left n =
    trans (*-comm (inverseFactorial n) (factorial n)) (factorial-inverse n)

  taylorCoefficients : (n : ℕ) → (R → R) → R → Vec R (suc n)
  taylorCoefficients n f x = tabulate
    (λ i → inverseFactorial (finToNat i) * iterate (finToNat i) f x)

  identify-coefficients : {n : ℕ} (f : R → R) (x : R) (as : Vec R (suc n)) →
    Expansion n f x as → as ≡ taylorCoefficients n f x
  identify-coefficients f x as p = vec-ext (λ i →
    begin
      lookup as i
    ≡⟨ sym (*-identityˡ (lookup as i)) ⟩
      1r * lookup as i
    ≡⟨ cong (_* lookup as i) (sym (inverse-factorial-left (finToNat i))) ⟩
      (inverseFactorial (finToNat i) * factorial (finToNat i)) * lookup as i
    ≡⟨ *-assoc (inverseFactorial (finToNat i)) (factorial (finToNat i)) (lookup as i) ⟩
      inverseFactorial (finToNat i) * (factorial (finToNat i) * lookup as i)
    ≡⟨ cong (inverseFactorial (finToNat i) *_) (coefficient-derivatives f x as p i) ⟩
      inverseFactorial (finToNat i) * iterate (finToNat i) f x
    ≡⟨ sym (lookup-tabulate
          (λ j → inverseFactorial (finToNat j) * iterate (finToNat j) f x) i) ⟩
      lookup (taylorCoefficients _ f x) i ∎)

  taylor-all-orders : (n : ℕ) (f : R → R) (x : R) (d : DK n) →
    f (x + valueK d) ≡ eval (taylorCoefficients n f x) (valueK d)
  taylor-all-orders zero f x d =
    trans (cong (λ z → f (x + z)) (trans (sym (power-one (valueK d))) (nilpotence d)))
      (trans (cong f (+-identityʳ x))
        (sym (trans (eval-constant (1r * f x) (valueK d)) (*-identityˡ (f x)))))
  taylor-all-orders (suc n) f x d =
    trans (reconstruction n (λ a → f (x + valueK a)) d)
      (cong (λ as → eval as (valueK d))
        (identify-coefficients f x (coefficients n (λ a → f (x + valueK a)))
          (reconstruction n (λ a → f (x + valueK a)))))

  taylor-all-orders-sum : (n : ℕ) (f : R → R) (x : R) (d : DK n) →
    f (x + valueK d) ≡ monomialSum (taylorCoefficients n f x) (valueK d) zero
  taylor-all-orders-sum n f x d =
    trans (taylor-all-orders n f x d) (eval-as-sum (taylorCoefficients n f x) (valueK d))
