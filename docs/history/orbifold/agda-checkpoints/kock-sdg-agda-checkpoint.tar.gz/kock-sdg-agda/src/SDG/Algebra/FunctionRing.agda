{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.FunctionRing where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)

-- Ordinary identity-valued ring laws on a function type require function
-- extensionality. The parameter is explicit and never postulated.
functionRing : {ℓ : Level} (A : CRing ℓ) (X : Set ℓ) →
  FunExt ℓ ℓ → CRing ℓ
functionRing A X ext = record
  { R = X → R
  ; 0r = λ _ → 0r
  ; 1r = λ _ → 1r
  ; _+_ = λ f g x → f x + g x
  ; _*_ = λ f g x → f x * g x
  ; -_ = λ f x → - f x
  ; +-assoc = λ f g h → ext (λ x → +-assoc (f x) (g x) (h x))
  ; +-comm = λ f g → ext (λ x → +-comm (f x) (g x))
  ; +-identityˡ = λ f → ext (λ x → +-identityˡ (f x))
  ; +-identityʳ = λ f → ext (λ x → +-identityʳ (f x))
  ; +-inverseˡ = λ f → ext (λ x → +-inverseˡ (f x))
  ; +-inverseʳ = λ f → ext (λ x → +-inverseʳ (f x))
  ; *-assoc = λ f g h → ext (λ x → *-assoc (f x) (g x) (h x))
  ; *-comm = λ f g → ext (λ x → *-comm (f x) (g x))
  ; *-identityˡ = λ f → ext (λ x → *-identityˡ (f x))
  ; *-identityʳ = λ f → ext (λ x → *-identityʳ (f x))
  ; distribˡ = λ f g h → ext (λ x → distribˡ (f x) (g x) (h x))
  ; distribʳ = λ f g h → ext (λ x → distribʳ (f x) (g x) (h x))
  }
  where open CRing A

record RingIso {a b : Level} (A : CRing a) (B : CRing b) : Set (a ⊔ b) where
  field
    forward : RingHom A B
    backward : RingHom B A
    left-inverse : (x : CRing.R A) →
      RingHom.hom backward (RingHom.hom forward x) ≡ x
    right-inverse : (y : CRing.R B) →
      RingHom.hom forward (RingHom.hom backward y) ≡ y

