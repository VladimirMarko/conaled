{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section09LieLaws where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Endomorphisms using (LieAlgebra)
open import SDG.Algebra.Group
open import SDG.Algebra.Automorphisms using (Aut; forward; backward; backward-forward; forward-backward)
import SDG.Algebra.Automorphisms as Auto
open import SDG.Axiom
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section01Exercises as E1
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section08FormalFlows as S8F
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section09LieLawsGroup as Groups
import SDG.ChapterI.Section11Hall as Hall

-- The purely geometric Lie laws. The only geometric hypotheses are
-- first-order KL, infinitesimal linearity, and Property W. No faithful
-- representation by scalar differential operators is assumed.
module Geometry {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR using (d-path; negateD; negateD-involutive)
  open S7L using (twoN; i₀; i₁)
  open S7L.Geometry A setR ext0 using
    (coordinate-axis-own; coordinate-axis-off; coordinate-diagonal)
  open S8.Basics A setR hiding (transform; transform-zero)
  open S8.Linear A setR IL using (inverse-right; inverse-left)
  open S8M.Fields A setR ext0 ext M setM IL
  open S4.Results A K using (productD)
  open S9.Lie A K setR IL W hiding (bracket)
  module Book = S9.Lie A K setR IL W
  module Tangent = S7L.Construction A setR ext0 M IL
  module Autos = Auto.Automorphisms M ext setM
  module G = GroupLemmas Autos.automorphismGroup
  module GI = Groups.Identities Autos.automorphismGroup
  module GH = Hall.Hall Autos.automorphismGroup

  abstract
    -- An opaque name for exactly the book's geometric bracket keeps
    -- nested commutators from expanding all W witnesses during checking.
    bracket : VectorField M → VectorField M → VectorField M
    bracket = Book.bracket

    bracket-agrees : (X Y : VectorField M) → bracket X Y ≡ Book.bracket X Y
    bracket-agrees X Y = refl

    transform : VectorField M → D → Auto.Aut M
    forward (transform X d) m = run X m d
    backward (transform X d) m = run X m (negateD d)
    backward-forward (transform X d) m = inverse-right X m d
    forward-backward (transform X d) m = inverse-left X m d

    forward-transform : (X : VectorField M) (d : D) (m : M) → forward (transform X d) m ≡ run X m d
    forward-transform X d m = refl

    transform-zero : (X : VectorField M) → transform X zeroD ≡ G.unit
    transform-zero X = Autos.aut-ext (λ m → trans (run-zero X m) (sym (Autos.forward-unit m)))

    transform-zero-field : (d : D) → transform zero-field d ≡ G.unit
    transform-zero-field d = Autos.aut-ext (λ m → sym (Autos.forward-unit m))

    -- An infinitesimal sum is composition with the same parameter.
    run-add : (X Y : VectorField M) (m : M) (d : D) →
      run (field-add X Y) m d ≡ run Y (run X m d) d
    run-add X Y m d = trans
      (sym (Tangent.extend-unique (field-section X m) (field-section Y m) circuit onAxis₀ onAxis₁ (diagonal d)))
      (cong₂ (λ e f → run Y (run X m e) f) (coordinate-diagonal d i₀) (coordinate-diagonal d i₁))
      where
      circuit : Jet1 twoN → M
      circuit p = run Y (run X m (coordinateD p i₀)) (coordinateD p i₁)
      onAxis₀ : (e : D) → circuit (axis i₀ e) ≡ run X m e
      onAxis₀ e = trans (cong₂ (λ f g → run Y (run X m f) g)
        (coordinate-axis-own i₀ e) (coordinate-axis-off i₀ i₁ (λ ()) e)) (run-zero Y (run X m e))
      onAxis₁ : (e : D) → circuit (axis i₁ e) ≡ run Y m e
      onAxis₁ e = trans (cong₂ (λ f g → run Y (run X m f) g)
        (coordinate-axis-off i₁ i₀ (λ ()) e) (coordinate-axis-own i₁ e))
        (cong (λ q → run Y q e) (run-zero X m))

    transform-add : (X Y : VectorField M) (d : D) →
      transform (field-add X Y) d ≡ G._·_ (transform X d) (transform Y d)
    transform-add X Y d = Autos.aut-ext (λ m → trans (run-add X Y m d)
      (sym (Autos.forward-multiply (transform X d) (transform Y d) m)))

    transform-scale : (r : R) (X : VectorField M) (d : D) →
      transform (scale-field (λ _ → r) X) d ≡ transform X (scaleD d r)
    transform-scale r X d = Autos.aut-ext (λ _ → refl)

    group-bracket : (X Y : VectorField M) (d e : D) →
      GI.commutator (transform X d) (transform Y e) ≡ transform (bracket X Y) (productD d e)
    group-bracket X Y d e = Autos.aut-ext (λ m →
      trans (cong (λ q → forward q m) (GI.commutator-agrees (transform X d) (transform Y e)))
      (trans (Autos.forward-commutator (transform X d) (transform Y e) m)
      (trans (sym (cong₂ (λ f g → run Y (run X (run Y (run X m (negateD d)) (negateD e)) f) g)
        (negateD-involutive d) (negateD-involutive e)))
        (trans (sym (bracket-characterization X Y m (negateD d) (negateD e)))
          (cong (run (bracket X Y) m) (d-path (neg-mul-neg (value d) (value e))))))))

  commutator-vanishes : (X Y : VectorField M) (d e : D) → value d * value e ≡ 0r →
    GI.commutator (transform X d) (transform Y e) ≡ G.unit
  commutator-vanishes X Y d e p = trans (group-bracket X Y d e)
    (trans (cong (transform (bracket X Y)) (d-path p)) (transform-zero (bracket X Y)))

  abstract
    fields-detected : (X Y : VectorField M) →
      ((d e : D) → transform X (productD d e) ≡ transform Y (productD d e)) → X ≡ Y
    fields-detected X Y p = field-ext ext setM (λ m → detect (run X m) (run Y m)
      (λ d e → cong (λ f → forward f m) (p d e)))

    triple-detect : (t u : D → M) →
      ((d e f : D) → t (productD d (productD e f)) ≡ u (productD d (productD e f))) →
      (d : D) → t d ≡ u d
    triple-detect t u p = detect t u (λ d e →
      detect (λ q → t (productD d q)) (λ q → u (productD d q)) (p d) e)

  product-rotate : (d e f : D) → productD d (productD e f) ≡ productD e (productD f d)
  product-rotate d e f = d-path
    (trans (*-swap (value d) (value e) (value f))
      (cong (value e *_) (*-comm (value d) (value f))))

  overlap-left : (d e : D) → (value d * value e) * value d ≡ 0r
  overlap-left d e = trans (*-assoc (value d) (value e) (value d))
    (trans (*-swap (value d) (value e) (value d))
      (trans (cong (value e *_) (square-zero d)) (*-zeroʳ (value e))))

  overlap-right : (d e : D) → (value d * value e) * value e ≡ 0r
  overlap-right d e = trans (*-assoc (value d) (value e) (value e))
    (trans (cong (value d *_) (square-zero e)) (*-zeroʳ (value d)))
