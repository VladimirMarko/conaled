{-# OPTIONS --safe --without-K #-}

module SDG.Forms.AffineCharts where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; tail; update; replicate)
import SDG.ChapterI.Section05Vector as V5
import SDG.Forms.QuadraticCubes as QC

-- An embedded subspace of a module which is closed under infinitesimal
-- translations. The sole geometric structure is the stated closure;
-- all affine and quadratic identities below follow by injectivity.
record AffineChart {ℓ : Level} (A : CRing ℓ) (W : RModule A ℓ) : Set (lsuc ℓ) where
  open ModuleLemmas A W
  open Infinitesimals A
  field
    Carrier : Set ℓ
    coordinates : Carrier → V
    coordinates-injective : {x y : Carrier} → coordinates x ≡ coordinates y → x ≡ y
    move : Carrier → D → V → Carrier
    moved-coordinates : (x : Carrier) (d : D) (v : V) → coordinates (move x d v) ≡ coordinates x +v value d • v

module Geometry {ℓ : Level} (A : CRing ℓ) (W : RModule A ℓ)
  (KW : V5.VectorInfinitesimals.VectorKL A W) (U : AffineChart A W) where
  open Extra A W public
  open Infinitesimals A
  open AffineChart U public
  open V5.VectorInfinitesimals.VectorKL KW
  module Q = QC.Quadratic A W KW

  move-zero : (x : Carrier) (v : V) → move x zeroD v ≡ x
  move-zero x v = coordinates-injective (trans (moved-coordinates x zeroD v)
    (trans (cong (coordinates x +v_) (zero-scalar v)) (add-zeroʳ (coordinates x))))

  move-zero-vector : (x : Carrier) (d : D) → move x d 0v ≡ x
  move-zero-vector x d = coordinates-injective (trans (moved-coordinates x d 0v)
    (trans (cong (coordinates x +v_) (scalar-zero (value d))) (add-zeroʳ (coordinates x))))

  move-rescale : (x : Carrier) (d : D) (r : R) (v : V) → move x (scaleD d r) v ≡ move x d (r • v)
  move-rescale x d r v = coordinates-injective (trans (moved-coordinates x (scaleD d r) v)
    (trans (cong (coordinates x +v_) (scalar-assoc (value d) r v)) (sym (moved-coordinates x d (r • v)))))

  move-expansion : (t : D → Carrier) (d : D) → t d ≡ move (t zeroD) d (slopeV (coordinates ∘ t))
  move-expansion t d = coordinates-injective
    (trans (expansionV (coordinates ∘ t) d) (sym (moved-coordinates (t zeroD) d (slopeV (coordinates ∘ t)))))

  quad : Carrier → V → V → V → D → D → Carrier
  quad x a b c d e = move (move x d a) e (b +v value d • c)

  quad-coordinates : (x : Carrier) (a b c : V) (d e : D) →
    coordinates (quad x a b c d e) ≡ Q.quad (coordinates x) a b c (d ∷ e ∷ [])
  quad-coordinates x a b c d e = trans (moved-coordinates (move x d a) e (b +v value d • c))
    (trans (cong (_+v (value e • (b +v value d • c))) (moved-coordinates x d a))
      (cong ((coordinates x +v value d • a) +v_)
        (trans (scalar-distrib (value e) b (value d • c))
          (cong ((value e • b) +v_)
            (trans (scalar-commute (value e) (value d) c) (sym (scalar-assoc (value d) (value e) c)))))))

  quad-rescale-first : (x : Carrier) (a b c : V) (r : R) (d e : D) →
    quad x a b c (scaleD d r) e ≡ quad x (r • a) b (r • c) d e
  quad-rescale-first x a b c r d e = coordinates-injective
    (trans (quad-coordinates x a b c (scaleD d r) e)
      (trans (Q.quad-scale-first (coordinates x) a b c r (d ∷ e ∷ []))
        (sym (quad-coordinates x (r • a) b (r • c) d e))))

  quad-rescale-second : (x : Carrier) (a b c : V) (r : R) (d e : D) →
    quad x a b c d (scaleD e r) ≡ quad x a (r • b) (r • c) d e
  quad-rescale-second x a b c r d e = coordinates-injective
    (trans (quad-coordinates x a b c d (scaleD e r))
      (trans (Q.quad-scale-second (coordinates x) a b c r (d ∷ e ∷ []))
        (sym (quad-coordinates x a (r • b) (r • c) d e))))

  mixed-coordinates : (x : Carrier) (c : V) (d e : D) →
    coordinates (quad x 0v 0v c d e) ≡ coordinates x +v (value d * value e) • c
  mixed-coordinates x c d e = trans (quad-coordinates x 0v 0v c d e)
    (cong₂ _+v_
      (trans (cong (coordinates x +v_) (scalar-zero (value d))) (add-zeroʳ (coordinates x)))
      (trans (cong (_+v ((value d * value e) • c)) (scalar-zero (value e)))
        (add-zeroˡ ((value d * value e) • c))))

  mixed-symmetric : (x : Carrier) (c : V) (d e : D) → quad x 0v 0v c d e ≡ quad x 0v 0v c e d
  mixed-symmetric x c d e = coordinates-injective (trans (mixed-coordinates x c d e)
    (trans (cong (λ r → coordinates x +v r • c) (*-comm (value d) (value e)))
      (sym (mixed-coordinates x c e d))))

  head-slice-reconstruction : (a : D → Carrier) (b : D → V) (d e : D) →
    move (a e) d (b e) ≡ quad (a zeroD) (b zeroD) (slopeV (coordinates ∘ a)) (slopeV b) d e
  head-slice-reconstruction a b d e = coordinates-injective
    (trans (moved-coordinates (a e) d (b e))
      (trans (cong₂ _+v_ (expansionV (coordinates ∘ a) e) (cong (value d •_) (expansionV b e)))
        (trans (cong ((coordinates (a zeroD) +v value e • slopeV (coordinates ∘ a)) +v_)
          (trans (scalar-distrib (value d) (b zeroD) (value e • slopeV b))
            (cong ((value d • b zeroD) +v_) (sym (scalar-assoc (value d) (value e) (slopeV b))))))
          (trans (add-shuffle (coordinates (a zeroD)) (value e • slopeV (coordinates ∘ a))
            (value d • b zeroD) ((value d * value e) • slopeV b))
            (sym (quad-coordinates (a zeroD) (b zeroD) (slopeV (coordinates ∘ a)) (slopeV b) d e))))))

  head-slice-frozen : (a : D → Carrier) (b : V) (d e : D) →
    move (a e) d b ≡ quad (a zeroD) b (slopeV (coordinates ∘ a)) 0v d e
  head-slice-frozen a b d e = coordinates-injective
    (trans (moved-coordinates (a e) d b)
      (trans (cong (_+v (value d • b)) (expansionV (coordinates ∘ a) e))
        (trans (add-assoc (coordinates (a zeroD)) (value e • slopeV (coordinates ∘ a)) (value d • b))
          (trans (cong (coordinates (a zeroD) +v_) (add-comm (value e • slopeV (coordinates ∘ a)) (value d • b)))
            (trans (sym (add-assoc (coordinates (a zeroD)) (value d • b) (value e • slopeV (coordinates ∘ a))))
              (sym (trans (quad-coordinates (a zeroD) b (slopeV (coordinates ∘ a)) 0v d e)
                (cong ((coordinates (a zeroD) +v value d • b) +v_)
                  (trans (cong ((value e • slopeV (coordinates ∘ a)) +v_) (scalar-zero (value d * value e)))
                    (add-zeroʳ (value e • slopeV (coordinates ∘ a))))))))))))

-- A purely finite-product lemma: invariance under setting any one
-- coordinate to the chosen base point implies dependence only on the
-- value at the all-base-point tuple.
module Collapse {ℓ : Level} (X W V : Set ℓ) (z : X) (ext : FunExt ℓ ℓ) where
  collapse : (n : ℕ) (F : (Vec X n → W) → V) →
    ((b : Vec X n → W) (i : Fin n) → F b ≡ F (λ xs → b (update xs i z))) →
    (b : Vec X n → W) → F b ≡ F (λ _ → b (replicate z))
  collapse zero F invariant b = cong F (ext (λ { [] → refl }))
  collapse (suc n) F invariant b = trans (invariant b fzero)
    (trans (cong F (ext (λ { (x ∷ xs) → refl })))
      (collapse n (λ c → F (c ∘ tail))
        (λ c i → trans (invariant (c ∘ tail) (fsuc i))
          (cong F (ext (λ { (x ∷ xs) → refl }))))
        (λ xs → b (z ∷ xs))))
