{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section13Transformation where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section02Exercises as E2
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section13Intervals as SI

module Results {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) where
  open SI.Results A K O J public
  open E2.DifferenceAlgebra A using (subtract-zero)

  -- Substitution in its endpoint form. No monotonicity or injectivity of
  -- the map is used; only that it takes values in the target interval.
  pullback-integral : {a b c d : R} (ab : a ≤ b) (cd : c ≤ d)
    (f : Interval c d → R) (φ : Interval a b → Interval c d) →
    Over.integral ab (λ x → f (φ x) * On.derivative a b (coordinate ∘ φ) x) ≡
    Over.intervalPrimitive cd f (φ (right-endpoint ab)) -
    Over.intervalPrimitive cd f (φ (left-endpoint ab))
  pullback-integral {a} {b} {c} {d} ab cd f φ =
    trans (Over.integral-cong ab _ (On.derivative a b (Over.intervalPrimitive cd f ∘ φ))
      (λ x → sym (trans
        (Local.Chain.derivative-chain A K (intervalDomain c d) (intervalDomain a b)
          (Over.intervalPrimitive cd f) φ x)
        (cong (_* On.derivative a b (coordinate ∘ φ) x)
          (Over.interval-primitive-derivative cd f (φ x))))))
      (Over.integral-derivative ab (Over.intervalPrimitive cd f ∘ φ))

  -- Equation I.13.7, the change-of-variable formula.
  substitution : {a b c d : R} (ab : a ≤ b) (cd : c ≤ d)
    (f : Interval c d → R) (φ : Interval a b → Interval c d) →
    φ (left-endpoint ab) ≡ left-endpoint cd →
    φ (right-endpoint ab) ≡ right-endpoint cd →
    Over.integral cd f ≡ Over.integral ab (λ x → f (φ x) * On.derivative a b (coordinate ∘ φ) x)
  substitution ab cd f φ at-left at-right = sym
    (trans (pullback-integral ab cd f φ)
      (trans (cong₂ _-_ (cong (Over.intervalPrimitive cd f) at-right)
        (trans (cong (Over.intervalPrimitive cd f) at-left) (Over.interval-primitive-zero cd f)))
        (subtract-zero (Over.integral cd f))))

  inclusion : {a b u v : R} → a ≤ u → v ≤ b → Interval u v → Interval a b
  inclusion lower upper (x , ux , xv) = x , transitive lower ux , transitive xv upper

  inclusion-derivative : {a b u v : R} (lower : a ≤ u) (upper : v ≤ b) (x : Interval u v) →
    On.derivative u v (coordinate ∘ inclusion lower upper) x ≡ 1r
  inclusion-derivative {u = u} {v} lower upper = On.derivative-coordinate u v

  restriction-integral : {a b u v : R} (ab : a ≤ b) (uv : u ≤ v)
    (lower : a ≤ u) (upper : v ≤ b) (f : Interval a b → R) →
    Over.integral uv (f ∘ inclusion lower upper) ≡
    Over.intervalPrimitive ab f (inclusion lower upper (right-endpoint uv)) -
    Over.intervalPrimitive ab f (inclusion lower upper (left-endpoint uv))
  restriction-integral {u = u} {v} ab uv lower upper f =
    trans (Over.integral-cong uv _
      (λ x → f (inclusion lower upper x) * On.derivative u v (coordinate ∘ inclusion lower upper) x)
      (λ x → sym (trans (cong (f (inclusion lower upper x) *_) (inclusion-derivative lower upper x))
        (*-identityʳ (f (inclusion lower upper x))))))
      (pullback-integral uv ab f (inclusion lower upper))

  difference-chain : (x y z : R) → (y - x) + (z - y) ≡ z - x
  difference-chain x y z = trans (+-comm (y - x) (z - y))
    (trans (+-assoc z (- y) (y + (- x))) (cong (z +_) (+-inverse-cancelˡ y (- x))))

  -- Equation I.13.5. The functions on the two subintervals are literal
  -- restrictions, with their inclusions and all endpoint identifications.
  subdivision : {a b c : R} (ab : a ≤ b) (bc : b ≤ c) (f : Interval a c → R) →
    Over.integral (transitive ab bc) f ≡
    Over.integral ab (f ∘ inclusion (reflexive a) bc) +
    Over.integral bc (f ∘ inclusion ab (reflexive c))
  subdivision {a} {b} {c} ab bc f = sym
    (trans (cong₂ _+_
      (trans (restriction-integral ac ab (reflexive a) bc f)
        (cong₂ _-_ (cong H (interval-ext refl)) (cong H (interval-ext refl))))
      (trans (restriction-integral ac bc ab (reflexive c) f)
        (cong₂ _-_ (cong H (interval-ext refl)) (cong H (interval-ext refl)))))
      (trans (difference-chain (H (left-endpoint ac)) (H middle) (H (right-endpoint ac)))
        (trans (cong (λ z → H (right-endpoint ac) - z) (Over.interval-primitive-zero ac f))
          (subtract-zero (H (right-endpoint ac))))))
    where
    ac : a ≤ c
    ac = transitive ab bc
    H : Interval a c → R
    H = Over.intervalPrimitive ac f
    middle : Interval a c
    middle = b , ab , bc

  module VariableEndpoint {a b : R} (ab : a ≤ b) where
    module I = Over ab

    variableIntegral : (Interval a b → R) → Interval a b → R
    variableIntegral f (x , ax , xb) = Over.integral ax (f ∘ inclusion (reflexive a) xb)

    variable-integral-is-primitive : (f : Interval a b → R) (x : Interval a b) →
      variableIntegral f x ≡ I.intervalPrimitive f x
    variable-integral-is-primitive f (x , ax , xb) =
      trans (restriction-integral ab ax (reflexive a) xb f)
        (trans (cong₂ _-_
          (cong (I.intervalPrimitive f) (interval-ext refl))
          (trans (cong (I.intervalPrimitive f) (interval-ext refl)) (I.interval-primitive-zero f)))
          (subtract-zero (I.intervalPrimitive f (x , ax , xb))))

    -- Equation I.13.6, with the varying subinterval constructed explicitly.
    variable-integral-derivative : (f : Interval a b → R) (x : Interval a b) →
      On.derivative a b (variableIntegral f) x ≡ f x
    variable-integral-derivative f x = trans
      (On.derivative-cong a b (variableIntegral f) (I.intervalPrimitive f)
        (variable-integral-is-primitive f) x) (I.interval-primitive-derivative f x)

  -- Exercise I.13.5, on any two ordered intervals. Uniqueness of the
  -- normalized primitive and differentiation under the integral prove
  -- the interchange; Fubini is not assumed as a property of integration.
  fubini : {a b c d : R} (ab : a ≤ b) (cd : c ≤ d)
    (f : Interval a b → Interval c d → R) →
    Over.integral ab (λ x → Over.integral cd (f x)) ≡
    Over.integral cd (λ y → Over.integral ab (λ x → f x y))
  fubini {a} {b} {c} {d} ab cd f = sym
    (I.interval-primitive-unique (λ x → Q.integral (f x)) H H-derivative H-zero I.right)
    where
    module I = Over ab
    module Q = Over cd
    module P = Q.Parameter (intervalDomain a b)
    H : Interval a b → R
    H x = Q.integral (λ y → I.intervalPrimitive (λ z → f z y) x)
    H-derivative : (x : Interval a b) → On.derivative a b H x ≡ Q.integral (f x)
    H-derivative x = trans
      (P.differentiate-integral (λ z y → I.intervalPrimitive (λ u → f u y) z) x)
      (Q.integral-cong _ (f x) (λ y → I.interval-primitive-derivative (λ u → f u y) x))
    H-zero : H I.left ≡ 0r
    H-zero = trans (Q.integral-cong _ (λ _ → 0r) (λ y → I.interval-primitive-zero (λ u → f u y))) Q.integral-zero
