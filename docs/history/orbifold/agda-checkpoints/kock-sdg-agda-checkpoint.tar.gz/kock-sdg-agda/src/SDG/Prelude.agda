{-# OPTIONS --safe --without-K #-}

module SDG.Prelude where

open import Agda.Primitive public using (Level; lzero; lsuc; _⊔_)
open import Agda.Builtin.Equality public using (_≡_; refl)
open import Agda.Builtin.Sigma public using (Σ; _,_; fst; snd)
open import Agda.Builtin.Nat public using (zero; suc) renaming (Nat to ℕ)
open import Agda.Builtin.Unit public using (⊤; tt)

private
  variable
    a b c : Level
    A : Set a
    B : Set b
    C : Set c

infixr 4 _×_
_×_ : Set a → Set b → Set (a ⊔ b)
A × B = Σ A (λ _ → B)

data ⊥ : Set where

⊥-elim : ⊥ → A
⊥-elim ()

¬_ : Set a → Set a
¬ A = A → ⊥

infix 4 _≢_
_≢_ : A → A → Set _
x ≢ y = ¬ (x ≡ y)

data Dec (A : Set a) : Set a where
  yes : A → Dec A
  no  : ¬ A → Dec A

id : A → A
id x = x

const : A → B → A
const x _ = x

infixr 9 _∘_
_∘_ : (B → C) → (A → B) → A → C
(f ∘ g) x = f (g x)

sym : {x y : A} → x ≡ y → y ≡ x
sym refl = refl

trans : {x y z : A} → x ≡ y → y ≡ z → x ≡ z
trans refl q = q

cong : (f : A → B) {x y : A} → x ≡ y → f x ≡ f y
cong f refl = refl

cong₂ : (f : A → B → C) {x x′ : A} {y y′ : B} →
        x ≡ x′ → y ≡ y′ → f x y ≡ f x′ y′
cong₂ f refl refl = refl

subst : (P : A → Set b) {x y : A} → x ≡ y → P x → P y
subst P refl p = p

subst₂ : (P : A → B → Set c) {x x′ : A} {y y′ : B} →
         x ≡ x′ → y ≡ y′ → P x y → P x′ y′
subst₂ P refl refl p = p

infix 1 begin_
infixr 2 _≡⟨_⟩_ _≡⟨⟩_
infix 3 _∎

begin_ : {x y : A} → x ≡ y → x ≡ y
begin p = p

_≡⟨_⟩_ : (x : A) {y z : A} → x ≡ y → y ≡ z → x ≡ z
_ ≡⟨ p ⟩ q = trans p q

_≡⟨⟩_ : (x : A) {y : A} → x ≡ y → x ≡ y
_ ≡⟨⟩ p = p

_∎ : (x : A) → x ≡ x
x ∎ = refl

-- Extensionality is a named type, not an axiom asserted by this module.
FunExt : (a b : Level) → Set (lsuc (a ⊔ b))
FunExt a b = {A : Set a} {B : A → Set b} {f g : (x : A) → B x} →
             ((x : A) → f x ≡ g x) → f ≡ g

isProp : Set a → Set a
isProp A = (x y : A) → x ≡ y

isSet : Set a → Set a
isSet A = (x y : A) → isProp (x ≡ y)
