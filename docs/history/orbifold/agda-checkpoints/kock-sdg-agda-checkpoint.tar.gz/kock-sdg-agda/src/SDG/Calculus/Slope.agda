{-# OPTIONS --safe --without-K #-}
module SDG.Calculus.Slope where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.ChapterI.Section01 as S1

module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open S1.Results A K using (slope-affine)

  slope-cong : (f g : D → R) →
    ((d : D) → f d ≡ g d) → slope f ≡ slope g
  slope-cong f g p = uniqueness f (slope g)
    (λ d → trans (p d) (trans (expansion g d)
      (cong (_+ (value d * slope g)) (sym (p zeroD)))))

  -- R-valued functions cannot distinguish infinitesimals with equal scalar
  -- values; this follows from KL, without identifying proof components of D.
  value-cong : (f : D → R) (d e : D) → value d ≡ value e → f d ≡ f e
  value-cong f d e p = trans (expansion f d)
    (trans (cong (λ x → f zeroD + x * slope f) p) (sym (expansion f e)))

  slope-constant : (c : R) → slope (λ _ → c) ≡ 0r
  slope-constant c = uniqueness (λ _ → c) 0r
    (λ d → sym (trans (cong (c +_) (*-zeroʳ (value d))) (+-identityʳ c)))

  slope-value : slope value ≡ 1r
  slope-value = uniqueness value 1r
    (λ d → sym (trans (+-identityˡ (value d * 1r)) (*-identityʳ (value d))))

  slope-add : (f g : D → R) →
    slope (λ d → f d + g d) ≡ slope f + slope g
  slope-add f g = uniqueness (λ d → f d + g d) (slope f + slope g)
    (λ d → trans (cong₂ _+_ (expansion f d) (expansion g d))
      (trans (+-shuffle (f zeroD) (value d * slope f)
                          (g zeroD) (value d * slope g))
        (cong ((f zeroD + g zeroD) +_)
          (sym (distribˡ (value d) (slope f) (slope g))))))

  slope-scale : (r : R) (f : D → R) →
    slope (λ d → r * f d) ≡ r * slope f
  slope-scale r f = uniqueness (λ d → r * f d) (r * slope f)
    (λ d → trans (cong (r *_) (expansion f d))
      (trans (distribˡ r (f zeroD) (value d * slope f))
        (cong ((r * f zeroD) +_) (*-swap r (value d) (slope f)))))

  slope-scaleʳ : (f : D → R) (r : R) →
    slope (λ d → f d * r) ≡ slope f * r
  slope-scaleʳ f r =
    trans (slope-cong (λ d → f d * r) (λ d → r * f d)
      (λ d → *-comm (f d) r))
      (trans (slope-scale r f) (*-comm r (slope f)))

  slope-neg : (f : D → R) → slope (λ d → - f d) ≡ - slope f
  slope-neg f = uniqueness (λ d → - f d) (- slope f)
    (λ d → trans (cong -_ (expansion f d))
      (trans (neg-add (f zeroD) (value d * slope f))
        (cong ((- f zeroD) +_) (sym (neg-mulʳ (value d) (slope f))))))

  slope-product : (f g : D → R) →
    slope (λ d → f d * g d) ≡ f zeroD * slope g + g zeroD * slope f
  slope-product f g = uniqueness (λ d → f d * g d)
    (f zeroD * slope g + g zeroD * slope f)
    (λ d → trans (cong₂ _*_ (expansion f d) (expansion g d))
      (affine-product (value d) (f zeroD) (slope f)
        (g zeroD) (slope g) (square-zero d)))

  -- Interchanging two infinitesimal coefficient extractions is proved by
  -- applying slope-linearity to the first Kock--Lawvere expansion.
  mixed-slope : (f : D → D → R) →
    slope (λ e → slope (λ d → f d e)) ≡
    slope (λ d → slope (λ e → f d e))
  mixed-slope f = sym (uniqueness (λ d → slope (f d))
    (slope (λ e → slope (λ d → f d e)))
    (λ d →
      trans (slope-cong (f d)
        (λ e → f zeroD e + value d * slope (λ d′ → f d′ e))
        (λ e → expansion (λ d′ → f d′ e) d))
        (trans (slope-add (f zeroD)
          (λ e → value d * slope (λ d′ → f d′ e)))
          (cong (slope (f zeroD) +_)
            (slope-scale (value d) (λ e → slope (λ d′ → f d′ e)))))))

