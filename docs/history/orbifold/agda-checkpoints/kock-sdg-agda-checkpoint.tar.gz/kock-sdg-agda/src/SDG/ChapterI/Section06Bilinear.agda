{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Bilinear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Bilinear
open import SDG.Finite using (Vec; Fin; lookup)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section01Exercises as E1

-- Exercise I.6.4. The coordinate expansion of every bilinear map is
-- proved in Algebra.Bilinear, rather than included as an extra hypothesis.
module Results {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open BilinearAlgebra A
  open Jets A using (Jet1; coords; coordinate)

  record DoubleJet (n : ℕ) : Set ℓ where
    field
      d e : Jet1 n
      mixed-zero : (i j : Fin n) →
        (coordinate d i * coordinate e j) + (coordinate d j * coordinate e i) ≡ 0r
  open DoubleJet public

  cross-sum-zero : {n : ℕ} {b : Vec R n → Vec R n → R} → Bilinear b →
    (ds es : Vec R n) →
    ((i j : Fin n) → (lookup ds i * lookup es j) + (lookup ds j * lookup es i) ≡ 0r) →
    b ds es + b es ds ≡ 0r
  cross-sum-zero {n} {b} B ds es cross =
    trans (cong₂ _+_ (bilinear-expansion B ds es) (bilinear-expansion B es ds))
      (trans (sym (Sum.sum-add
        (λ i → Sum.sum (λ j → (lookup ds i * lookup es j) * b (basis i) (basis j)))
        (λ i → Sum.sum (λ j → (lookup es i * lookup ds j) * b (basis i) (basis j)))))
        (trans (Sum.sum-cong (λ i →
          trans (sym (Sum.sum-add
            (λ j → (lookup ds i * lookup es j) * b (basis i) (basis j))
            (λ j → (lookup es i * lookup ds j) * b (basis i) (basis j))))
            (trans (Sum.sum-cong (λ j →
              trans (cong (((lookup ds i * lookup es j) * b (basis i) (basis j)) +_)
                (cong (_* b (basis i) (basis j)) (*-comm (lookup es i) (lookup ds j))))
                (trans (sym (distribʳ (lookup ds i * lookup es j)
                  (lookup ds j * lookup es i) (b (basis i) (basis j))))
                  (trans (cong (_* b (basis i) (basis j)) (cross i j))
                    (*-zeroˡ (b (basis i) (basis j)))))))
              (Sum.sum-zero n)))) (Sum.sum-zero n)))

  symmetric-bilinear-vanishes : {n : ℕ} (H : E1.Algebraic.TwoInvertible A)
    (b : Vec R n → Vec R n → R) → Bilinear b →
    ((ds es : Vec R n) → b ds es ≡ b es ds) →
    (p : DoubleJet n) → b (coords (d p)) (coords (e p)) ≡ 0r
  symmetric-bilinear-vanishes H b B symmetric p =
    E1.Algebraic.WithHalf.cancel-two-zero A H (b (coords (d p)) (coords (e p)))
      (trans (double-mul (b (coords (d p)) (coords (e p))))
        (trans (cong ((b (coords (d p)) (coords (e p))) +_) (symmetric (coords (d p)) (coords (e p))))
          (cross-sum-zero B (coords (d p)) (coords (e p)) (mixed-zero p))))
