{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section11Hall where

open import SDG.Prelude
open import SDG.Algebra.Group
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Maybe using (Maybe; nothing; just)

-- A small verified group-word normalizer. Its correctness is proved from
-- group laws; reduction of the concrete 42-letter Hall word is by refl.
data Label : Set where
  x y z : Label

data Atom : Set where
  px nx py ny pz nz : Atom

flip : Atom → Atom
flip px = nx
flip nx = px
flip py = ny
flip ny = py
flip pz = nz
flip nz = pz

positive : Label → Atom
positive x = px
positive y = py
positive z = pz

infixr 5 _++_
_++_ : {a : Level} {A : Set a} → List A → List A → List A
[] ++ bs = bs
(a ∷ as) ++ bs = a ∷ (as ++ bs)

invert-word : List Atom → List Atom
invert-word [] = []
invert-word (a ∷ as) = invert-word as ++ (flip a ∷ [])

data Expr : Set where
  neutral : Expr
  var : Label → Expr
  multiply : Expr → Expr → Expr
  invert : Expr → Expr

flatten : Expr → List Atom
flatten neutral = []
flatten (var l) = positive l ∷ []
flatten (multiply e f) = flatten e ++ flatten f
flatten (invert e) = invert-word (flatten e)

cancel-match : (a b : Atom) → Maybe (b ≡ flip a)
cancel-match px nx = just refl
cancel-match nx px = just refl
cancel-match py ny = just refl
cancel-match ny py = just refl
cancel-match pz nz = just refl
cancel-match nz pz = just refl
cancel-match a b = nothing

insert : Atom → List Atom → List Atom
insert a [] = a ∷ []
insert a (b ∷ bs) with cancel-match a b
... | just p = bs
... | nothing = a ∷ b ∷ bs

normalize : List Atom → List Atom
normalize [] = []
normalize (a ∷ as) = insert a (normalize as)

commutator-expr : Expr → Expr → Expr
commutator-expr a b = multiply (multiply (multiply (invert a) (invert b)) a) b

conjugate-expr : Expr → Expr → Expr
conjugate-expr a b = multiply (multiply (invert b) a) b

hall-expr : Expr
hall-expr = multiply
  (multiply
    (commutator-expr (conjugate-expr (var x) (var y))
      (commutator-expr (var y) (var z)))
    (commutator-expr (conjugate-expr (var y) (var z))
      (commutator-expr (var z) (var x))))
  (commutator-expr (conjugate-expr (var z) (var x))
    (commutator-expr (var x) (var y)))

hall-word-reduces : normalize (flatten hall-expr) ≡ []
hall-word-reduces = refl

module Correctness {ℓ : Level} {G : Set ℓ} (H : Group G) (environment : Label → G) where
  open GroupLemmas H

  atom-value : Atom → G
  atom-value px = environment x
  atom-value nx = inverse (environment x)
  atom-value py = environment y
  atom-value ny = inverse (environment y)
  atom-value pz = environment z
  atom-value nz = inverse (environment z)

  positive-value : (l : Label) → atom-value (positive l) ≡ environment l
  positive-value x = refl
  positive-value y = refl
  positive-value z = refl

  flip-value : (a : Atom) → atom-value (flip a) ≡ inverse (atom-value a)
  flip-value px = refl
  flip-value nx = sym (inverse-involutive (environment x))
  flip-value py = refl
  flip-value ny = sym (inverse-involutive (environment y))
  flip-value pz = refl
  flip-value nz = sym (inverse-involutive (environment z))

  word-value : List Atom → G
  word-value [] = unit
  word-value (a ∷ as) = atom-value a · word-value as

  expr-value : Expr → G
  expr-value neutral = unit
  expr-value (var l) = environment l
  expr-value (multiply e f) = expr-value e · expr-value f
  expr-value (invert e) = inverse (expr-value e)

  append-value : (as bs : List Atom) → word-value (as ++ bs) ≡ word-value as · word-value bs
  append-value [] bs = sym (identityˡ (word-value bs))
  append-value (a ∷ as) bs = trans (cong (atom-value a ·_) (append-value as bs))
    (sym (assoc (atom-value a) (word-value as) (word-value bs)))

  invert-word-value : (as : List Atom) → word-value (invert-word as) ≡ inverse (word-value as)
  invert-word-value [] = sym inverse-unit
  invert-word-value (a ∷ as) = trans (append-value (invert-word as) (flip a ∷ []))
    (trans (cong₂ _·_ (invert-word-value as)
      (trans (identityʳ (atom-value (flip a))) (flip-value a)))
      (sym (inverse-product (atom-value a) (word-value as))))

  flatten-correct : (e : Expr) → word-value (flatten e) ≡ expr-value e
  flatten-correct neutral = refl
  flatten-correct (var l) = trans (identityʳ (atom-value (positive l))) (positive-value l)
  flatten-correct (multiply e f) = trans (append-value (flatten e) (flatten f))
    (cong₂ _·_ (flatten-correct e) (flatten-correct f))
  flatten-correct (invert e) = trans (invert-word-value (flatten e)) (cong inverse (flatten-correct e))

  matched-product : (a b : Atom) → b ≡ flip a → atom-value a · atom-value b ≡ unit
  matched-product a b p = trans (cong (atom-value a ·_) (cong atom-value p))
    (trans (cong (atom-value a ·_) (flip-value a)) (inverseʳ (atom-value a)))

  insert-correct : (a : Atom) (as : List Atom) →
    word-value (insert a as) ≡ atom-value a · word-value as
  insert-correct a [] = refl
  insert-correct a (b ∷ bs) with cancel-match a b
  ... | nothing = refl
  ... | just p = sym (trans (sym (assoc (atom-value a) (atom-value b) (word-value bs)))
    (trans (cong (_· word-value bs) (matched-product a b p)) (identityˡ (word-value bs))))

  normalize-correct : (as : List Atom) → word-value (normalize as) ≡ word-value as
  normalize-correct [] = refl
  normalize-correct (a ∷ as) = trans (insert-correct a (normalize as))
    (cong (atom-value a ·_) (normalize-correct as))

  hall-expression-identity : expr-value hall-expr ≡ unit
  hall-expression-identity = trans (sym (flatten-correct hall-expr))
    (trans (sym (normalize-correct (flatten hall-expr))) (cong word-value hall-word-reduces))

-- Exercise I.11.1, with exactly the book's conjugation and commutator conventions.
module Hall {ℓ : Level} {G : Set ℓ} (H : Group G) where
  open GroupLemmas H

  abstract
    hall-identity : (a b c : G) →
      (commutator (conjugate a b) (commutator b c) ·
        commutator (conjugate b c) (commutator c a)) ·
        commutator (conjugate c a) (commutator a b) ≡ unit
    hall-identity a b c = Correctness.hall-expression-identity H
      (λ { x → a ; y → b ; z → c })

