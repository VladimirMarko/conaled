{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08FreeMonoid where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Permutation; permute)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as S3E
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08FlowExtension as E
import SDG.ChapterI.Section08FormalFlows as F
import SDG.ChapterI.Section09Invariant as I
import SDG.Infinitesimal.Nilpotent as NI

-- Exercise I.8.4, finite-orbit assertion. The orbit is specified by its
-- universal property among targets with the symmetric-functions property.
-- The equations are pointwise, so function extensionality is not required.
module FiniteOrbits {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ}
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) M) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open S3E.SumMap A
  open S4.Results A K using (Symmetric; SymmetricDescent)
  module Q = E.FiniteExtension A K setR SFP (S8.Basics.zero-field A setR)
    (λ d e m → refl)

  record InvariantMap (n : ℕ) : Set ℓ where
    constructor invariant-map
    field
      mapping : Vec D n → M
      invariant : (p : Permutation n) (ds : Vec D n) →
        mapping (permute p ds) ≡ mapping ds
  open InvariantMap public

  restrict : (n : ℕ) → (DK n → M) → InvariantMap n
  mapping (restrict n g) ds = g (summation ds)
  invariant (restrict n g) p ds = cong g (Q.summation-permute p ds)

  descend : (n : ℕ) → InvariantMap n → DK n → M
  descend zero f d = mapping f []
  descend (suc n) f = SymmetricDescent.descend (SFP n) (mapping f) (invariant f)

  restrict-descend : (n : ℕ) (f : InvariantMap n) (ds : Vec D n) →
    mapping (restrict n (descend n f)) ds ≡ mapping f ds
  restrict-descend zero f [] = refl
  restrict-descend (suc n) f ds =
    sym (SymmetricDescent.factor (SFP n) (mapping f) (invariant f) ds)

  descend-restrict : (n : ℕ) (g : DK n → M) (d : DK n) →
    descend n (restrict n g) d ≡ g d
  descend-restrict zero g d = Q.detect zero
    (λ _ → g (summation [])) g (λ { [] → refl }) d
  descend-restrict (suc n) g d = sym
    (SymmetricDescent.unique (SFP n) (mapping (restrict (suc n) g))
      (invariant (restrict (suc n) g)) g (λ ds → refl) d)

  orbit-factorization-unique : (n : ℕ) (f : InvariantMap n)
    (g : DK n → M) →
    ((ds : Vec D n) → mapping f ds ≡ g (summation ds)) →
    (d : DK n) → g d ≡ descend n f d
  orbit-factorization-unique zero f g p = Q.detect zero g (descend zero f)
    (λ { [] → sym (p []) })
  orbit-factorization-unique (suc n) f g p =
    SymmetricDescent.unique (SFP n) (mapping f) (invariant f) g p

-- Universal extension for a pointed path whose values commute. The two
-- corollaries below discharge commutation under different hypotheses.
module PointedExtensions {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {G : Set ℓ} (Gmon : I.Monoid G)
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) G) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open S3E.SumMap A
  open NI.Times A
  open I.Monoid Gmon
  open S8.Basics A setR
  open E.Structures A

  record Homomorphism : Set ℓ where
    field
      mapping : D∞ → G
      respects : Respects∞ mapping
      preserves-zero : mapping zero∞ ≡ unit
      preserves-add : (d e : D∞) → mapping (add∞ d e) ≡ mapping d · mapping e
  open Homomorphism public

  module Generated (f : D → G) (pointed : f zeroD ≡ unit)
    (products-commute : (d e : D) → f d · f e ≡ f e · f d) where
    translation-field : VectorField G
    run translation-field g d = g · f d
    run-zero translation-field g = trans (cong (g ·_) pointed) (identityʳ g)

    module Flow = E.FiniteExtension A K setR SFP translation-field
      (λ d e g → trans (assoc g (f e) (f d))
        (trans (cong (g ·_) (products-commute e d)) (sym (assoc g (f d) (f e)))))
    open Flow using (flow; flow-respects; flow-zero; flow-add; flow-restricts;
      flowAt; flowAt-factor; detect; formal-flow-unique)
    open Flow.C using (sequence)

    private
      sequence-left : {n : ℕ} (ds : Vec D n) (a b : G) →
        sequence ds (a · b) ≡ a · sequence ds b
      sequence-left [] a b = refl
      sequence-left (d ∷ ds) a b =
        trans (cong (_· f d) (sequence-left ds a b)) (assoc a (sequence ds b) (f d))

      finite-left : (n : ℕ) (a b : G) (t : DK n) →
        flowAt n (a · b) t ≡ a · flowAt n b t
      finite-left n a b = detect n (flowAt n (a · b)) (λ t → a · flowAt n b t)
        (λ ds → trans (sym (flowAt-factor (a · b) ds))
          (trans (sequence-left ds a b) (cong (a ·_) (flowAt-factor b ds))))

    flow-left : (a b : G) (t : D∞) → flow (a · b) t ≡ a · flow b t
    flow-left a b (witnessed n t) = finite-left n a b t

    extension : D∞ → G
    extension = flow unit

    extension-respects : Respects∞ extension
    extension-respects = flow-respects unit

    extension-zero : extension zero∞ ≡ unit
    extension-zero = flow-zero unit

    extension-add : (d e : D∞) → extension (add∞ d e) ≡ extension d · extension e
    extension-add d e = trans (flow-add unit d e)
      (trans (cong (λ g → flow g e) (sym (identityʳ (extension d))))
        (flow-left (extension d) unit e))

    extension-restricts : (d : D) → extension (injectK (fromD d)) ≡ f d
    extension-restricts d = trans (flow-restricts unit d) (identityˡ (f d))

    extend : Homomorphism
    mapping extend = extension
    respects extend = extension-respects
    preserves-zero extend = extension-zero
    preserves-add extend = extension-add

    extension-unique : (h : Homomorphism) →
      ((d : D) → mapping h (injectK (fromD d)) ≡ f d) →
      (t : D∞) → mapping h t ≡ extension t
    extension-unique h restriction t =
      trans (sym (identityˡ (mapping h t)))
        (formal-flow-unique candidate-flow restriction-action unit t)
      where
      candidate-flow : FormalFlow G
      act∞ candidate-flow g t = g · mapping h t
      respects-time candidate-flow g d e p = cong (g ·_) (respects h d e p)
      at-zero candidate-flow g = trans (cong (g ·_) (preserves-zero h)) (identityʳ g)
      at-sum candidate-flow g d e =
        trans (cong (g ·_) (preserves-add h d e))
          (sym (assoc g (mapping h d) (mapping h e)))

      restriction-action : (g : G) (d : D) →
        act∞ candidate-flow g (injectK (fromD d)) ≡ run translation-field g d
      restriction-action g d = cong (g ·_) (restriction d)

    image-commutes : (d e : D∞) → extension d · extension e ≡ extension e · extension d
    image-commutes d e = trans (sym (extension-add d e))
      (trans (extension-respects (add∞ d e) (add∞ e d) (add∞-comm d e))
        (extension-add e d))

-- Exact free commutative pointed-monoid property. SFP alone suffices for
-- commutative targets; neither IL nor W is added to these assumptions.
module FreeCommutativePointedMonoid {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {G : Set ℓ} (Gmon : I.Monoid G)
  (commutative : (a b : G) → I.Monoid._·_ Gmon a b ≡ I.Monoid._·_ Gmon b a)
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) G) where
  open Infinitesimals A
  open I.Monoid Gmon
  open PointedExtensions A K setR Gmon SFP public using (Homomorphism; mapping;
    respects; preserves-zero; preserves-add)

  module Generated (f : D → G) (pointed : f zeroD ≡ unit) where
    open PointedExtensions.Generated A K setR Gmon SFP f pointed
      (λ d e → commutative (f d) (f e)) public

-- The free arbitrary pointed-monoid assertion, for IL targets.
-- IL is the extra hypothesis in the correction to Exercise I.8.3;
-- Exercise I.8.4's printed definition of E_s omits it. This module does
-- not claim to derive IL from SFP and W, or hide that strengthened scope.
module FreePointedMonoid {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {G : Set ℓ} (Gmon : I.Monoid G)
  (IL : S6.Linear.InfinitesimallyLinear A G)
  (W : S4.Results.PropertyW A K G)
  (half : CRing.R A)
  (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A)
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) G) where
  open Infinitesimals A
  open I.Monoid Gmon
  open S8.Basics A setR
  open F.SelfCommutation A K setR IL W half half-law
  open PointedExtensions A K setR Gmon SFP public using (Homomorphism; mapping;
    respects; preserves-zero; preserves-add)

  module Generated (f : D → G) (pointed : f zeroD ≡ unit) where
    private
      translation : VectorField G
      run translation g d = g · f d
      run-zero translation g = trans (cong (g ·_) pointed) (identityʳ g)

      products-commute : (d e : D) → f d · f e ≡ f e · f d
      products-commute d e =
        trans (cong (_· f e) (sym (identityˡ (f d))))
          (trans (self-transformations-commute translation unit d e)
            (cong (_· f d) (identityˡ (f e))))

    open PointedExtensions.Generated A K setR Gmon SFP f pointed products-commute public
