{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12Closure where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Algebras
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Axiom
open import SDG.Finite using (Fin; Vec; Permutation; permute)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section06PropertyClosures as P6
import SDG.Schemes.Reflexivity as Ref

-- Exercise I.12.1. A reflexive object inherits every one of the extension
-- properties considered in I.6 from R. The proof constructs the extension
-- on all scalar observations and proves, using uniqueness, that the result
-- is an R-algebra map. Reflexivity then recovers the required point.
module DescentTransfer {ℓ x y i : Level} (A : CRing ℓ)
  (ext : FunExt ℓ ℓ) (setR : isSet (CRing.R A))
  (M : Set ℓ) (reflexive : Ref.Reflexivity.Reflexive A ext setR M)
  (X : Set x) (Y : Set y) (I : Set i) (q : X → Y) (left right : I → X)
  (scalar-property : P6.Descent.Property X Y I q left right (CRing.R A)) where
  open CRing A
  open Ref.Reflexivity A ext setR
  open P6.Descent X Y I q left right
  module Scalar = Property scalar-property

  module Extension (f : X → M) (compatible : Compatible f) where
    observe : (M → R) → Y → R
    observe g = Scalar.lift (g ∘ f) (λ s → cong g (compatible s))

    observes-on-image : (g : M → R) (z : X) → g (f z) ≡ observe g (q z)
    observes-on-image g = Scalar.factor (g ∘ f) (λ s → cong g (compatible s))

    constant-observation : (r : R) (z : Y) → observe (λ _ → r) z ≡ r
    constant-observation r z = sym (Scalar.unique (λ _ → r) (λ s → cong (λ _ → r) (compatible s))
      (λ _ → r) (λ _ → refl) z)

    unary-observation : (op : R → R) (g : M → R) (z : Y) →
      observe (op ∘ g) z ≡ op (observe g z)
    unary-observation op g z = sym
      (Scalar.unique (op ∘ g ∘ f) (λ s → cong (op ∘ g) (compatible s))
        (op ∘ observe g) (λ t → cong op (observes-on-image g t)) z)

    binary-observation : (op : R → R → R) (g h : M → R) (z : Y) →
      observe (λ m → op (g m) (h m)) z ≡ op (observe g z) (observe h z)
    binary-observation op g h z = sym
      (Scalar.unique (λ t → op (g (f t)) (h (f t)))
        (λ s → cong (λ m → op (g m) (h m)) (compatible s))
        (λ t → op (observe g t) (observe h t))
        (λ t → cong₂ op (observes-on-image g t) (observes-on-image h t)) z)

    observed-point : Y → DoubleDual M
    RingHom.hom (ringHom (observed-point z)) g = observe g z
    RingHom.pres-0 (ringHom (observed-point z)) = constant-observation 0r z
    RingHom.pres-1 (ringHom (observed-point z)) = constant-observation 1r z
    RingHom.pres-+ (ringHom (observed-point z)) g h = binary-observation _+_ g h z
    RingHom.pres-* (ringHom (observed-point z)) g h = binary-observation _*_ g h z
    RingHom.pres-neg (ringHom (observed-point z)) g = unary-observation -_ g z
    commutes (observed-point z) r = constant-observation r z

    extension : Y → M
    extension z = recover reflexive (observed-point z)

    extension-evaluation : (g : M → R) (z : Y) → g (extension z) ≡ observe g z
    extension-evaluation g z = cong (λ h → algMap h g) (evaluation-recover reflexive (observed-point z))

    extension-factor : (z : X) → f z ≡ extension (q z)
    extension-factor z = points-detected reflexive (f z) (extension (q z))
      (λ g → trans (observes-on-image g z) (sym (extension-evaluation g (q z))))

    extension-unique : (candidate : Y → M) → ((z : X) → f z ≡ candidate (q z)) →
      (z : Y) → candidate z ≡ extension z
    extension-unique candidate p z = points-detected reflexive (candidate z) (extension z)
      (λ g → trans (Scalar.unique (g ∘ f) (λ s → cong g (compatible s))
        (g ∘ candidate) (λ t → cong g (p t)) z) (sym (extension-evaluation g z)))

  reflexive-property : Property M
  Property.lift reflexive-property = Extension.extension
  Property.factor reflexive-property = Extension.extension-factor
  Property.unique reflexive-property = Extension.extension-unique

module Properties {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (ext : FunExt ℓ ℓ)
  (setR : isSet (CRing.R A)) (M : Set ℓ)
  (reflexive : Ref.Reflexivity.Reflexive A ext setR M) where
  open Infinitesimals A
  open Jets A
  open S4.Results A K using (PropertyW; SymmetricDescent; productD)
  open S6.Linear A

  reflexive-W : PropertyW (CRing.R A) → PropertyW M
  reflexive-W WR = P6.WClosure.from-descent A K
    (DescentTransfer.reflexive-property A ext setR M reflexive
      (D × D) D (D × D) (λ p → productD (fst p) (snd p))
      (λ p → fst p , zeroD) (λ p → zeroD , snd p)
      (P6.WClosure.to-descent A K WR))

  reflexive-symmetric : {n : ℕ} {Y : Set ℓ} (q : Vec D n → Y) →
    SymmetricDescent Y q (CRing.R A) → SymmetricDescent Y q M
  reflexive-symmetric {n} {Y} q SR = P6.SymmetricClosure.from-descent A K q
    (DescentTransfer.reflexive-property A ext setR M reflexive
      (Vec D n) Y (Permutation n × Vec D n) q
      (λ p → permute (fst p) (snd p)) snd
      (P6.SymmetricClosure.to-descent A K q SR))

  reflexive-linear : InfinitesimallyLinear (CRing.R A) → InfinitesimallyLinear M
  reflexive-linear LR = P6.LinearClosure.from-descent A (λ n →
    DescentTransfer.reflexive-property A ext setR M reflexive
      (Fin (suc (suc n)) × D) (Jet1 (suc (suc n)))
      (Fin (suc (suc n)) × Fin (suc (suc n)))
      (λ p → axis (fst p) (snd p)) (λ p → fst p , zeroD) (λ p → snd p , zeroD)
      (P6.LinearClosure.AtOrder.to-descent A n LR))
