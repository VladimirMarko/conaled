{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Closure where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; Fin; zero; suc; lookup; tabulate; lookup-tabulate; vec-ext)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section06 as S6

-- Exercise I.6.5: products, equalizers, and function objects.
module Closure {ℓ : Level} (A : CRing ℓ) where
  open Infinitesimals A
  open Jets A
  open S6.Linear A

  product-linear : {a b : Level} {M : Set a} {N : Set b} →
    InfinitesimallyLinear M → InfinitesimallyLinear N → InfinitesimallyLinear (M × N)
  InfinitesimallyLinear.extension (product-linear LM LN) n x ts base p =
    InfinitesimallyLinear.extension LM n (fst x) (λ i d → fst (ts i d))
      (λ i → cong fst (base i)) p ,
    InfinitesimallyLinear.extension LN n (snd x) (λ i d → snd (ts i d))
      (λ i → cong snd (base i)) p
  InfinitesimallyLinear.axes (product-linear LM LN) n x ts base i d = cong₂ _,_
    (InfinitesimallyLinear.axes LM n (fst x) (λ j e → fst (ts j e))
      (λ j → cong fst (base j)) i d)
    (InfinitesimallyLinear.axes LN n (snd x) (λ j e → snd (ts j e))
      (λ j → cong snd (base j)) i d)
  InfinitesimallyLinear.uniqueness (product-linear LM LN) n x ts base candidate p d = cong₂ _,_
    (InfinitesimallyLinear.uniqueness LM n (fst x) (λ j e → fst (ts j e))
      (λ j → cong fst (base j)) (λ e → fst (candidate e))
      (λ j e → cong fst (p j e)) d)
    (InfinitesimallyLinear.uniqueness LN n (snd x) (λ j e → snd (ts j e))
      (λ j → cong snd (base j)) (λ e → snd (candidate e))
      (λ j e → cong snd (p j e)) d)

  terminal-linear : InfinitesimallyLinear ⊤
  InfinitesimallyLinear.extension terminal-linear n x ts base p = tt
  InfinitesimallyLinear.axes terminal-linear n x ts base i d with ts i d
  ... | tt = refl
  InfinitesimallyLinear.uniqueness terminal-linear n x ts base candidate p d with candidate d
  ... | tt = refl

  function-linear : {a b : Level} {M : Set a} (X : Set b) →
    FunExt b a → InfinitesimallyLinear M → InfinitesimallyLinear (X → M)
  InfinitesimallyLinear.extension (function-linear X ext LM) n x ts base p z =
    InfinitesimallyLinear.extension LM n (x z) (λ i d → ts i d z)
      (λ i → cong (λ f → f z) (base i)) p
  InfinitesimallyLinear.axes (function-linear X ext LM) n x ts base i d = ext (λ z →
    InfinitesimallyLinear.axes LM n (x z) (λ j e → ts j e z)
      (λ j → cong (λ f → f z) (base j)) i d)
  InfinitesimallyLinear.uniqueness (function-linear X ext LM) n x ts base candidate p d = ext (λ z →
    InfinitesimallyLinear.uniqueness LM n (x z) (λ j e → ts j e z)
      (λ j → cong (λ f → f z) (base j)) (λ e → candidate e z)
      (λ j e → cong (λ f → f z) (p j e)) d)

  vector-linear : {a : Level} {M : Set a} → InfinitesimallyLinear M →
    (m : ℕ) → InfinitesimallyLinear (Vec M m)
  InfinitesimallyLinear.extension (vector-linear LM m) n x ts base p = tabulate (λ j →
    InfinitesimallyLinear.extension LM n (lookup x j) (λ i d → lookup (ts i d) j)
      (λ i → cong (λ xs → lookup xs j) (base i)) p)
  InfinitesimallyLinear.axes (vector-linear LM m) n x ts base i d = vec-ext (λ j →
    trans (lookup-tabulate
      (λ k → InfinitesimallyLinear.extension LM n (lookup x k) (λ l e → lookup (ts l e) k)
        (λ l → cong (λ xs → lookup xs k) (base l)) (axis i d)) j)
      (InfinitesimallyLinear.axes LM n (lookup x j) (λ l e → lookup (ts l e) j)
        (λ l → cong (λ xs → lookup xs j) (base l)) i d))
  InfinitesimallyLinear.uniqueness (vector-linear LM m) n x ts base candidate p d = vec-ext (λ j →
    trans (InfinitesimallyLinear.uniqueness LM n (lookup x j) (λ l e → lookup (ts l e) j)
      (λ l → cong (λ xs → lookup xs j) (base l)) (λ e → lookup (candidate e) j)
      (λ l e → cong (λ xs → lookup xs j) (p l e)) d)
      (sym (lookup-tabulate
        (λ k → InfinitesimallyLinear.extension LM n (lookup x k) (λ l e → lookup (ts l e) k)
          (λ l → cong (λ xs → lookup xs k) (base l)) d) j)))

  subtype-path : {a b : Level} {M : Set a} {P : M → Set b} →
    ((x : M) → isProp (P x)) → {u v : Σ M P} → fst u ≡ fst v → u ≡ v
  subtype-path prop {u = x , p} {v = .x , q} refl = cong (x ,_) (prop x p q)

  module Equalizer {a b : Level} {M : Set a} {P : Set b}
    (LM : InfinitesimallyLinear M) (LP : InfinitesimallyLinear P)
    (F G : M → P) (fiber-prop : (x : M) → isProp (F x ≡ G x)) where

    Equalizer : Set (a ⊔ b)
    Equalizer = Σ M (λ x → F x ≡ G x)

    base-extension : (n : ℕ) (x : Equalizer)
      (ts : Fin (suc (suc n)) → D → Equalizer) →
      ((i : Fin (suc (suc n))) → ts i zeroD ≡ x) → Jet1 (suc (suc n)) → M
    base-extension n x ts base = InfinitesimallyLinear.extension LM n (fst x)
      (λ i d → fst (ts i d)) (λ i → cong fst (base i))

    extension-equalizes : (n : ℕ) (x : Equalizer)
      (ts : Fin (suc (suc n)) → D → Equalizer)
      (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x)
      (p : Jet1 (suc (suc n))) →
      F (base-extension n x ts base p) ≡ G (base-extension n x ts base p)
    extension-equalizes n x ts base p = trans
      (InfinitesimallyLinear.uniqueness LP n (F (fst x)) target target-base
        (λ q → F (base-extension n x ts base q)) factor-F p)
      (sym (InfinitesimallyLinear.uniqueness LP n (F (fst x)) target target-base
        (λ q → G (base-extension n x ts base q)) factor-G p))
      where
      target : Fin (suc (suc n)) → D → P
      target i d = F (fst (ts i d))

      target-base : (i : Fin (suc (suc n))) → target i zeroD ≡ F (fst x)
      target-base i = cong (λ y → F (fst y)) (base i)

      factor-F : (i : Fin (suc (suc n))) (d : D) →
        F (base-extension n x ts base (axis i d)) ≡ target i d
      factor-F i d = cong F (InfinitesimallyLinear.axes LM n (fst x)
        (λ j e → fst (ts j e)) (λ j → cong fst (base j)) i d)

      factor-G : (i : Fin (suc (suc n))) (d : D) →
        G (base-extension n x ts base (axis i d)) ≡ target i d
      factor-G i d = trans (cong G (InfinitesimallyLinear.axes LM n (fst x)
        (λ j e → fst (ts j e)) (λ j → cong fst (base j)) i d)) (sym (snd (ts i d)))

    equalizer-linear : InfinitesimallyLinear Equalizer
    InfinitesimallyLinear.extension equalizer-linear n x ts base p =
      base-extension n x ts base p , extension-equalizes n x ts base p
    InfinitesimallyLinear.axes equalizer-linear n x ts base i d = subtype-path fiber-prop
      (InfinitesimallyLinear.axes LM n (fst x) (λ j e → fst (ts j e))
        (λ j → cong fst (base j)) i d)
    InfinitesimallyLinear.uniqueness equalizer-linear n x ts base candidate p d = subtype-path fiber-prop
      (InfinitesimallyLinear.uniqueness LM n (fst x) (λ j e → fst (ts j e))
        (λ j → cong fst (base j)) (λ q → fst (candidate q))
        (λ j e → cong fst (p j e)) d)
