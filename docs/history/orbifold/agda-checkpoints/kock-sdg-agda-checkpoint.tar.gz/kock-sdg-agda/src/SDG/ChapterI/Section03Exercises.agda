{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section03Exercises where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Algebra.Powers
open import SDG.Algebra.Symmetric
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; finToNat;
  lookup; replicate; lookup-replicate; vec-ext)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section02 as S2

-- Exercise I.3.1: the summation map D^n -> D_n in arbitrary finite dimension.
-- The power formula and the nilpotence proof are supplied by ring algebra,
-- not by an added axiom about infinitesimals.
module SumMap {ℓ : Level} (A : CRing ℓ) where
  open Infinitesimals A
  open S3.HigherInfinitesimals A
  open InfinitesimalSums A public

  summation : {n : ℕ} → Vec D n → DK n
  summation ds = nilpotent (sumD ds) (sum-nilpotent ds)

-- Exercise I.3.2. Higher KL and positive integer inverses imply that sums
-- of first-order infinitesimals detect all scalar-valued maps on D_k.
-- This is NOT a claim that the summation map is surjective as an Agda type.
module Detection {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open S3.HigherInfinitesimals A
  open HigherKockLawvere H
  open Infinitesimals A
  open SumMap A

  K : KockLawvere
  K = S3.FirstOrderFromHigher.firstOrder A H

  module Calculus = S2.Results A K
  module Descent = S3.PolynomialDescent A K
  module Taylor = S3.GeneralTaylor A K H Q
  open Calculus using (derivative; derivative-unique; iterate)

  ZeroOnSums : (n : ℕ) → (R → R) → Set ℓ
  ZeroOnSums n f = (ds : Vec D n) → f (sumD ds) ≡ 0r

  sum-zero-vector : (n : ℕ) → sumD (replicate {n = n} zeroD) ≡ 0r
  sum-zero-vector zero = refl
  sum-zero-vector (suc n) =
    trans (+-identityˡ (sumD (replicate {n = n} zeroD))) (sum-zero-vector n)

  zero-on-sums-at-origin : {n : ℕ} (f : R → R) → ZeroOnSums n f → f 0r ≡ 0r
  zero-on-sums-at-origin {n} f p =
    trans (sym (cong f (sum-zero-vector n))) (p (replicate zeroD))

  derivative-zero-on-sums : {n : ℕ} (f : R → R) →
    ZeroOnSums (suc n) f → ZeroOnSums n (derivative f)
  derivative-zero-on-sums f p ds = derivative-unique f (sumD ds) 0r
    (λ d → trans (cong f (+-comm (sumD ds) (value d)))
      (trans (p (d ∷ ds))
        (sym (trans (cong (f (sumD ds) +_) (*-zeroʳ (value d)))
          (trans (+-identityʳ (f (sumD ds))) base-zero)))))
    where
      base-zero : f (sumD ds) ≡ 0r
      base-zero = trans (sym (cong f (+-identityˡ (sumD ds)))) (p (zeroD ∷ ds))

  iterates-zero-at-origin : {n : ℕ} (f : R → R) → ZeroOnSums n f →
    (i : Fin (suc n)) → iterate (finToNat i) f 0r ≡ 0r
  iterates-zero-at-origin f p fzero = zero-on-sums-at-origin f p
  iterates-zero-at-origin {suc n} f p (fsuc i) =
    trans (sym (cong (λ g → g 0r) (Descent.iterate-derivative (finToNat i) f)))
      (iterates-zero-at-origin (derivative f) (derivative-zero-on-sums f p) i)

  coefficients-zero-on-sums : {n : ℕ} (as : Vec R (suc n)) →
    ZeroOnSums n (eval as) → as ≡ replicate 0r
  coefficients-zero-on-sums {n} as p = vec-ext (λ i →
    trans (coefficient-zero i) (sym (lookup-replicate 0r i)))
    where
      coefficient-zero : (i : Fin (suc n)) → lookup as i ≡ 0r
      coefficient-zero i =
        begin
          lookup as i
        ≡⟨ sym (*-identityˡ (lookup as i)) ⟩
          1r * lookup as i
        ≡⟨ cong (_* lookup as i) (sym (Taylor.inverse-factorial-left (finToNat i))) ⟩
          (Taylor.inverseFactorial (finToNat i) * factorial (finToNat i)) * lookup as i
        ≡⟨ *-assoc (Taylor.inverseFactorial (finToNat i)) (factorial (finToNat i)) (lookup as i) ⟩
          Taylor.inverseFactorial (finToNat i) * (factorial (finToNat i) * lookup as i)
        ≡⟨ cong (Taylor.inverseFactorial (finToNat i) *_)
            (Descent.coefficient-derivatives (eval as) 0r as
              (λ d → cong (eval as) (+-identityˡ (valueK d))) i) ⟩
          Taylor.inverseFactorial (finToNat i) * iterate (finToNat i) (eval as) 0r
        ≡⟨ cong (Taylor.inverseFactorial (finToNat i) *_)
            (iterates-zero-at-origin (eval as) p i) ⟩
          Taylor.inverseFactorial (finToNat i) * 0r
        ≡⟨ *-zeroʳ (Taylor.inverseFactorial (finToNat i)) ⟩
          0r ∎

  eval-zero-vector : (n : ℕ) (x : R) → eval (replicate {n = n} 0r) x ≡ 0r
  eval-zero-vector zero x = refl
  eval-zero-vector (suc n) x =
    trans (+-identityˡ (x * eval (replicate {n = n} 0r) x))
      (trans (cong (x *_) (eval-zero-vector n x)) (*-zeroʳ x))

  polynomial-detected : {n : ℕ} (as : Vec R (suc n)) →
    ZeroOnSums n (eval as) → (x : R) → eval as x ≡ 0r
  polynomial-detected {n} as p x =
    trans (cong (λ cs → eval cs x) (coefficients-zero-on-sums as p))
      (eval-zero-vector (suc n) x)

  nilpotent-value-cong : (n : ℕ) (f : DK (suc n) → R) {d e : DK (suc n)} →
    valueK d ≡ valueK e → f d ≡ f e
  nilpotent-value-cong n f {d} {e} p =
    trans (reconstruction n f d)
      (trans (cong (eval (coefficients n f)) p) (sym (reconstruction n f e)))

  scalar-functions-detected : (n : ℕ) (f : DK (suc n) → R) →
    ((ds : Vec D (suc n)) → f (summation ds) ≡ 0r) →
    (d : DK (suc n)) → f d ≡ 0r
  scalar-functions-detected n f p d =
    trans (reconstruction n f d)
      (polynomial-detected (coefficients n f)
        (λ ds → trans (sym (reconstruction n f (summation ds))) (p ds)) (valueK d))

  scalar-functions-agree : (n : ℕ) (f g : DK (suc n) → R) →
    ((ds : Vec D (suc n)) → f (summation ds) ≡ g (summation ds)) →
    (d : DK (suc n)) → f d ≡ g d
  scalar-functions-agree n f g p d = +-cancelʳ (- g d)
    (trans (scalar-functions-detected n (λ e → f e - g e)
      (λ ds → trans (cong (_- g (summation ds)) (p ds))
        (+-inverseʳ (g (summation ds)))) d)
      (sym (+-inverseʳ (g d))))
