{-# OPTIONS --safe --without-K #-}
module SDG.Forms.Module where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Forms.Basic

module Native {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setV : isSet (RModule.V Vmod)) where
  open Extra A Vmod
  open Cubes A
  open ModuleForms A Vmod public

  private
    form-path : {n : ℕ} {M : Set ℓ} {ω θ : Form n M} → evaluate ω ≡ evaluate θ → ω ≡ θ
    form-path {ω = form f h p} {form .f k q} refl = cong₂ (form f)
      (ext (λ τ → ext0 (λ i → ext (λ r → setV _ _ (h τ i r) (k τ i r)))))
      (ext (λ τ → ext0 (λ σ → setV _ _ (p τ σ) (q τ σ))))

  form-ext : {n : ℕ} {M : Set ℓ} {ω θ : Form n M} →
    ((τ : Cube n M) → evaluate ω τ ≡ evaluate θ τ) → ω ≡ θ
  form-ext p = form-path (ext p)

  negate-form : {n : ℕ} {M : Set ℓ} → Form n M → Form n M
  evaluate (negate-form ω) τ = -v evaluate ω τ
  homogeneous (negate-form ω) τ i r = trans (cong -v_ (homogeneous ω τ i r))
    (sym (scalar-neg r (evaluate ω τ)))
  alternating (negate-form ω) τ p = trans (cong -v_ (alternating ω τ p))
    (sym (scalar-neg _ (evaluate ω τ)))

  abstract
    forms-add-assoc : {n : ℕ} {M : Set ℓ} (ω θ η : Form n M) →
      add-form (add-form ω θ) η ≡ add-form ω (add-form θ η)
    forms-add-assoc ω θ η = form-ext (λ τ → add-assoc (evaluate ω τ) (evaluate θ τ) (evaluate η τ))

    forms-add-comm : {n : ℕ} {M : Set ℓ} (ω θ : Form n M) → add-form ω θ ≡ add-form θ ω
    forms-add-comm ω θ = form-ext (λ τ → add-comm (evaluate ω τ) (evaluate θ τ))

    forms-add-zero : {n : ℕ} {M : Set ℓ} (ω : Form n M) → add-form zero-form ω ≡ ω
    forms-add-zero ω = form-ext (λ τ → add-zeroˡ (evaluate ω τ))

    forms-add-inverse : {n : ℕ} {M : Set ℓ} (ω : Form n M) → add-form (negate-form ω) ω ≡ zero-form
    forms-add-inverse ω = form-ext (λ τ → add-inverseˡ (evaluate ω τ))

    forms-scale-one : {n : ℕ} {M : Set ℓ} (ω : Form n M) → scale-form 1r ω ≡ ω
    forms-scale-one ω = form-ext (λ τ → scalar-one (evaluate ω τ))

    forms-scale-assoc : {n : ℕ} {M : Set ℓ} (r s : R) (ω : Form n M) →
      scale-form (r * s) ω ≡ scale-form r (scale-form s ω)
    forms-scale-assoc r s ω = form-ext (λ τ → scalar-assoc r s (evaluate ω τ))

    forms-scale-add : {n : ℕ} {M : Set ℓ} (r s : R) (ω : Form n M) →
      scale-form (r + s) ω ≡ add-form (scale-form r ω) (scale-form s ω)
    forms-scale-add r s ω = form-ext (λ τ → scalar-add r s (evaluate ω τ))

    forms-scale-distrib : {n : ℕ} {M : Set ℓ} (r : R) (ω θ : Form n M) →
      scale-form r (add-form ω θ) ≡ add-form (scale-form r ω) (scale-form r θ)
    forms-scale-distrib r ω θ = form-ext (λ τ → scalar-distrib r (evaluate ω τ) (evaluate θ τ))

  formsModule : (n : ℕ) (M : Set ℓ) → RModule A ℓ
  formsModule n M = record
    { V = Form n M
    ; 0v = zero-form
    ; _+v_ = add-form
    ; -v_ = negate-form
    ; _•_ = scale-form
    ; add-assoc = forms-add-assoc
    ; add-comm = forms-add-comm
    ; add-zeroˡ = forms-add-zero
    ; add-inverseˡ = forms-add-inverse
    ; scalar-one = forms-scale-one
    ; scalar-assoc = forms-scale-assoc
    ; scalar-add = forms-scale-add
    ; scalar-distrib = forms-scale-distrib
    }

  pullback-zero : {n : ℕ} {M N : Set ℓ} (f : M → N) → pullback {n} f zero-form ≡ zero-form
  pullback-zero f = form-ext (λ _ → refl)

  pullback-add : {n : ℕ} {M N : Set ℓ} (f : M → N) (ω θ : Form n N) →
    pullback f (add-form ω θ) ≡ add-form (pullback f ω) (pullback f θ)
  pullback-add f ω θ = form-ext (λ _ → refl)

  pullback-scale : {n : ℕ} {M N : Set ℓ} (f : M → N) (r : R) (ω : Form n N) →
    pullback f (scale-form r ω) ≡ scale-form r (pullback f ω)
  pullback-scale f r ω = form-ext (λ _ → refl)

  pullback-id : {n : ℕ} {M : Set ℓ} (ω : Form n M) → pullback id ω ≡ ω
  pullback-id ω = form-ext (λ _ → refl)

  pullback-composition : {n : ℕ} {L M N : Set ℓ} (f : L → M) (g : M → N) (ω : Form n N) →
    pullback (g ∘ f) ω ≡ pullback f (pullback g ω)
  pullback-composition f g ω = form-ext (λ _ → refl)

