{-# OPTIONS --safe --without-K #-}

-- The algebraic content of Kock I.11, equations (11.1)--(11.6).
module SDG.Algebra.Derivations where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Endomorphisms using (LieAlgebra)
import SDG.Algebra.Endomorphisms as E

algebraModule : {a c : Level} (A : CRing a) (C : CRing c) → RingHom A C → RModule A c
algebraModule A C ι = record
  { V = R
  ; 0v = 0r
  ; _+v_ = _+_
  ; -v_ = -_
  ; _•_ = λ r x → hom r * x
  ; add-assoc = +-assoc
  ; add-comm = +-comm
  ; add-zeroˡ = +-identityˡ
  ; add-inverseˡ = +-inverseˡ
  ; scalar-one = λ x → trans (cong (_* x) pres-1) (*-identityˡ x)
  ; scalar-assoc = λ r s x → trans (cong (_* x) (pres-* r s)) (*-assoc (hom r) (hom s) x)
  ; scalar-add = λ r s x → trans (cong (_* x) (pres-+ r s)) (distribʳ (hom r) (hom s) x)
  ; scalar-distrib = λ r x y → distribˡ (hom r) x y
  }
  where
  open CRing C
  open RingHom ι

module Derivations {a c : Level} (A : CRing a) (C : CRing c) (ι : RingHom A C) where
  open RingLemmas C public
  module Base = CRing A
  open RingHom ι renaming (hom to embed)
  module Op = E.Endomorphisms A (algebraModule A C ι)
  module G = Extra C (scalarModule C)

  record Derivation : Set (a ⊔ c) where
    constructor derive
    field
      operator : Op.End
      leibniz : (x y : R) → Op.run operator (x * y) ≡
        Op.run operator x * y + x * Op.run operator y
  open Derivation public

  apply : Derivation → R → R
  apply δ = Op.run (operator δ)

  additive : (δ : Derivation) (x y : R) → apply δ (x + y) ≡ apply δ x + apply δ y
  additive δ = Op.additive (operator δ)

  homogeneous : (δ : Derivation) (r : Base.R) (x : R) →
    apply δ (embed r * x) ≡ embed r * apply δ x
  homogeneous δ = Op.homogeneous (operator δ)

  infix 4 _≈_
  _≈_ : Derivation → Derivation → Set c
  δ ≈ ε = (x : R) → apply δ x ≡ apply ε x

  zeroD : Derivation
  operator zeroD = Op.zeroEnd
  leibniz zeroD x y = sym
    (trans (cong₂ _+_ (*-zeroˡ y) (*-zeroʳ x)) (+-identityˡ 0r))

  add : Derivation → Derivation → Derivation
  operator (add δ ε) = Op.add (operator δ) (operator ε)
  leibniz (add δ ε) x y =
    trans (cong₂ _+_ (leibniz δ x y) (leibniz ε x y))
      (trans (+-shuffle (apply δ x * y) (x * apply δ y) (apply ε x * y) (x * apply ε y))
        (cong₂ _+_ (sym (distribʳ (apply δ x) (apply ε x) y))
          (sym (distribˡ x (apply δ y) (apply ε y)))))

  neg : Derivation → Derivation
  operator (neg δ) = Op.neg (operator δ)
  leibniz (neg δ) x y =
    trans (cong -_ (leibniz δ x y))
      (trans (neg-add (apply δ x * y) (x * apply δ y))
        (cong₂ _+_ (sym (neg-mulˡ (apply δ x) y)) (sym (neg-mulʳ x (apply δ y)))))

  sub : Derivation → Derivation → Derivation
  sub δ ε = add δ (neg ε)

  multiply-operator : R → Derivation → Op.End
  Op.run (multiply-operator r δ) x = r * apply δ x
  Op.additive (multiply-operator r δ) x y =
    trans (cong (r *_) (additive δ x y)) (distribˡ r (apply δ x) (apply δ y))
  Op.homogeneous (multiply-operator r δ) s x =
    trans (cong (r *_) (homogeneous δ s x)) (*-swap r (embed s) (apply δ x))

  multiply : R → Derivation → Derivation
  operator (multiply r δ) = multiply-operator r δ
  leibniz (multiply r δ) x y =
    trans (cong (r *_) (leibniz δ x y))
      (trans (distribˡ r (apply δ x * y) (x * apply δ y))
        (cong₂ _+_ (sym (*-assoc r (apply δ x) y)) (*-swap r x (apply δ y))))

  scale : Base.R → Derivation → Derivation
  operator (scale r δ) = Op.scale r (operator δ)
  leibniz (scale r δ) = leibniz (multiply (embed r) δ)

  derive-zero : (δ : Derivation) → apply δ 0r ≡ 0r
  derive-zero δ = Op.run-zero (operator δ)

  derive-one : (δ : Derivation) → apply δ 1r ≡ 0r
  derive-one δ = +-cancelˡ (apply δ 1r)
    (trans (sym doubled) (sym (+-identityʳ (apply δ 1r))))
    where
    doubled : apply δ 1r ≡ apply δ 1r + apply δ 1r
    doubled = trans (cong (apply δ) (sym (*-identityˡ 1r)))
      (trans (leibniz δ 1r 1r)
        (cong₂ _+_ (*-identityʳ (apply δ 1r)) (*-identityˡ (apply δ 1r))))

  derive-scalar : (δ : Derivation) (r : Base.R) → apply δ (embed r) ≡ 0r
  derive-scalar δ r = trans (cong (apply δ) (sym (*-identityʳ (embed r))))
    (trans (homogeneous δ r 1r)
      (trans (cong (embed r *_) (derive-one δ)) (*-zeroʳ (embed r))))

  four-regroup : (a b c d : R) → (a + b) + (c + d) ≡ (a + d) + (b + c)
  four-regroup a b c d = trans (cong ((a + b) +_) (+-comm c d)) (+-shuffle a b d c)

  cancel-cross-terms : (a b c d e f : R) →
    ((a + b) + (c + d)) - ((e + c) + (b + f)) ≡ (a - e) + (d - f)
  cancel-cross-terms a b c d e f =
    trans (cong₂ _-_ (four-regroup a b c d)
      (trans (four-regroup e c b f) (cong ((e + f) +_) (+-comm c b))))
      (trans (G.sub-common-right (a + d) (e + f) (b + c)) (G.sub-add-pairs a d e f))

  second-leibniz : (δ ε : Derivation) (x y : R) →
    apply δ (apply ε (x * y)) ≡
    (apply δ (apply ε x) * y + apply ε x * apply δ y) +
    (apply δ x * apply ε y + x * apply δ (apply ε y))
  second-leibniz δ ε x y =
    trans (cong (apply δ) (leibniz ε x y))
      (trans (additive δ (apply ε x * y) (x * apply ε y))
        (cong₂ _+_ (leibniz δ (apply ε x) y) (leibniz δ x (apply ε y))))

  mul-subˡ : (x y z : R) → x * (y - z) ≡ x * y - x * z
  mul-subˡ x y z = trans (distribˡ x y (- z)) (cong (x * y +_) (neg-mulʳ x z))

  mul-subʳ : (x y z : R) → (x - y) * z ≡ x * z - y * z
  mul-subʳ x y z = trans (distribʳ x (- y) z) (cong (x * z +_) (neg-mulˡ y z))

  bracket : Derivation → Derivation → Derivation
  operator (bracket δ ε) = Op.bracket (operator δ) (operator ε)
  leibniz (bracket δ ε) x y =
    trans (cong₂ _-_ (second-leibniz δ ε x y) (second-leibniz ε δ x y))
      (trans (cancel-cross-terms (apply δ (apply ε x) * y) (apply ε x * apply δ y)
        (apply δ x * apply ε y) (x * apply δ (apply ε y))
        (apply ε (apply δ x) * y) (x * apply ε (apply δ y)))
        (cong₂ _+_ (sym (mul-subʳ (apply δ (apply ε x)) (apply ε (apply δ x)) y))
          (sym (mul-subˡ x (apply δ (apply ε y)) (apply ε (apply δ y))))))

  bracket-addˡ : (δ ε η : Derivation) → bracket (add δ ε) η ≈ add (bracket δ η) (bracket ε η)
  bracket-addˡ δ ε η = Op.bracket-addˡ (operator δ) (operator ε) (operator η)

  bracket-addʳ : (δ ε η : Derivation) → bracket δ (add ε η) ≈ add (bracket δ ε) (bracket δ η)
  bracket-addʳ δ ε η = Op.bracket-addʳ (operator δ) (operator ε) (operator η)

  bracket-scaleˡ : (r : Base.R) (δ ε : Derivation) → bracket (scale r δ) ε ≈ scale r (bracket δ ε)
  bracket-scaleˡ r δ ε = Op.bracket-scaleˡ r (operator δ) (operator ε)

  bracket-scaleʳ : (r : Base.R) (δ ε : Derivation) → bracket δ (scale r ε) ≈ scale r (bracket δ ε)
  bracket-scaleʳ r δ ε = Op.bracket-scaleʳ r (operator δ) (operator ε)

  alternating : (δ : Derivation) → bracket δ δ ≈ zeroD
  alternating δ = Op.bracket-alternating (operator δ)

  skew : (δ ε : Derivation) → add (bracket δ ε) (bracket ε δ) ≈ zeroD
  skew δ ε = Op.bracket-skew (operator δ) (operator ε)

  jacobi : (δ ε η : Derivation) →
    add (add (bracket δ (bracket ε η)) (bracket ε (bracket η δ))) (bracket η (bracket δ ε)) ≈ zeroD
  jacobi δ ε η = Op.bracket-jacobi (operator δ) (operator ε) (operator η)

  -- Equation (11.6): the scalar in C need not be constant over the base R.
  bracket-multiply : (δ ε : Derivation) (r : R) →
    bracket δ (multiply r ε) ≈ add (multiply (apply δ r) ε) (multiply r (bracket δ ε))
  bracket-multiply δ ε r x =
    trans (cong (λ z → z - r * apply ε (apply δ x)) (leibniz δ r (apply ε x)))
      (trans (+-assoc (apply δ r * apply ε x) (r * apply δ (apply ε x)) (- (r * apply ε (apply δ x))))
        (cong (apply δ r * apply ε x +_) (sym (mul-subˡ r (apply δ (apply ε x)) (apply ε (apply δ x))))))

  multiply-addˡ : (r s : R) (δ : Derivation) → multiply (r + s) δ ≈ add (multiply r δ) (multiply s δ)
  multiply-addˡ r s δ x = distribʳ r s (apply δ x)

  multiply-addʳ : (r : R) (δ ε : Derivation) → multiply r (add δ ε) ≈ add (multiply r δ) (multiply r ε)
  multiply-addʳ r δ ε x = distribˡ r (apply δ x) (apply ε x)

  multiply-base-scaleˡ : (s : Base.R) (r : R) (δ : Derivation) →
    multiply (embed s * r) δ ≈ scale s (multiply r δ)
  multiply-base-scaleˡ s r δ x = *-assoc (embed s) r (apply δ x)

  multiply-base-scaleʳ : (s : Base.R) (r : R) (δ : Derivation) →
    multiply r (scale s δ) ≈ scale s (multiply r δ)
  multiply-base-scaleʳ s r δ x = *-swap r (embed s) (apply δ x)

  -- Evaluation is R-bilinear: its first variable uses the pointwise
  -- operations above, and its second uses the defining linearity proofs.
  evaluation-addˡ : (δ ε : Derivation) (x : R) → apply (add δ ε) x ≡ apply δ x + apply ε x
  evaluation-addˡ δ ε x = refl

  evaluation-scaleˡ : (r : Base.R) (δ : Derivation) (x : R) →
    apply (scale r δ) x ≡ embed r * apply δ x
  evaluation-scaleˡ r δ x = refl

  evaluation-addʳ : (δ : Derivation) (x y : R) → apply δ (x + y) ≡ apply δ x + apply δ y
  evaluation-addʳ = additive

  evaluation-scaleʳ : (δ : Derivation) (r : Base.R) (x : R) →
    apply δ (embed r * x) ≡ embed r * apply δ x
  evaluation-scaleʳ = homogeneous

module Native {a c : Level} (A : CRing a) (C : CRing c) (ι : RingHom A C)
  (extC : FunExt c c) (extA : FunExt a c) (setC : isSet (CRing.R C)) where
  open Derivations A C ι
  module Eq = E.EndEquality A (algebraModule A C ι) extC extA setC

  derivation-path : {δ ε : Derivation} → operator δ ≡ operator ε → δ ≡ ε
  derivation-path {derive f p} {derive .f q} refl = cong (derive f)
    (extC (λ x → extC (λ y → setC _ _ (p x y) (q x y))))

  derivation-ext : {δ ε : Derivation} → δ ≈ ε → δ ≡ ε
  derivation-ext {δ} {ε} p = derivation-path (Eq.end-ext {operator δ} {operator ε} p)

  derivationModule : RModule A (a ⊔ c)
  derivationModule = record
    { V = Derivation
    ; 0v = zeroD
    ; _+v_ = add
    ; -v_ = neg
    ; _•_ = scale
    ; add-assoc = λ δ ε η → derivation-ext (λ x → +-assoc (apply δ x) (apply ε x) (apply η x))
    ; add-comm = λ δ ε → derivation-ext (λ x → +-comm (apply δ x) (apply ε x))
    ; add-zeroˡ = λ δ → derivation-ext (λ x → +-identityˡ (apply δ x))
    ; add-inverseˡ = λ δ → derivation-ext (λ x → +-inverseˡ (apply δ x))
    ; scalar-one = λ δ → derivation-ext (λ x → RModule.scalar-one (algebraModule A C ι) (apply δ x))
    ; scalar-assoc = λ r s δ → derivation-ext (λ x → RModule.scalar-assoc (algebraModule A C ι) r s (apply δ x))
    ; scalar-add = λ r s δ → derivation-ext (λ x → RModule.scalar-add (algebraModule A C ι) r s (apply δ x))
    ; scalar-distrib = λ r δ ε → derivation-ext (λ x → RModule.scalar-distrib (algebraModule A C ι) r (apply δ x) (apply ε x))
    }

  coefficientModule : RModule C (a ⊔ c)
  coefficientModule = record
    { V = Derivation
    ; 0v = zeroD
    ; _+v_ = add
    ; -v_ = neg
    ; _•_ = multiply
    ; add-assoc = λ δ ε η → derivation-ext (λ x → +-assoc (apply δ x) (apply ε x) (apply η x))
    ; add-comm = λ δ ε → derivation-ext (λ x → +-comm (apply δ x) (apply ε x))
    ; add-zeroˡ = λ δ → derivation-ext (λ x → +-identityˡ (apply δ x))
    ; add-inverseˡ = λ δ → derivation-ext (λ x → +-inverseˡ (apply δ x))
    ; scalar-one = λ δ → derivation-ext (λ x → *-identityˡ (apply δ x))
    ; scalar-assoc = λ r s δ → derivation-ext (λ x → *-assoc r s (apply δ x))
    ; scalar-add = λ r s δ → derivation-ext (multiply-addˡ r s δ)
    ; scalar-distrib = λ r δ ε → derivation-ext (multiply-addʳ r δ ε)
    }

  derivationLieAlgebra : LieAlgebra A derivationModule
  derivationLieAlgebra = record
    { bracket = bracket
    ; bracket-addˡ = λ δ ε η → derivation-ext (bracket-addˡ δ ε η)
    ; bracket-addʳ = λ δ ε η → derivation-ext (bracket-addʳ δ ε η)
    ; bracket-scaleˡ = λ r δ ε → derivation-ext (bracket-scaleˡ r δ ε)
    ; bracket-scaleʳ = λ r δ ε → derivation-ext (bracket-scaleʳ r δ ε)
    ; alternating = λ δ → derivation-ext (alternating δ)
    ; skew = λ δ ε → derivation-ext (skew δ ε)
    ; jacobi = λ δ ε η → derivation-ext (jacobi δ ε η)
    }

  lie-module-law : (δ ε : Derivation) (r : R) →
    bracket δ (multiply r ε) ≡ add (multiply (apply δ r) ε) (multiply r (bracket δ ε))
  lie-module-law δ ε r = derivation-ext (bracket-multiply δ ε r)
