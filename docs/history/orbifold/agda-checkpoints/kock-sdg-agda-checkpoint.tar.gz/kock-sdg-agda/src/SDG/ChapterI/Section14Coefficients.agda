{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section14Coefficients where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; Fin; lookup; update; Permutation)
open import SDG.Forms.Basic
open import SDG.Combinatorics.Signature
import SDG.Forms.InfinitesimalCoefficients as IC
import SDG.Forms.Module as FM
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07 as S7

-- Proposition I.14.4, all finite dimensions and general vector KL targets.
module Representation {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (Vmod : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A Vmod) where
  open ModuleLemmas A Vmod
  open Infinitesimals A
  open Cubes A
  open ModuleForms A Vmod
  open Sign A
  open IC.Coefficients A Vmod KV

  record RectangleLaw (n : ℕ) (M : Set ℓ) : Set ℓ where
    constructor rectangle-law
    field
      value-on : Cube n M → Vec D n → V
      cube-homogeneous : (τ : Cube n M) (ds : Vec D n) (i : Fin n) (r : R) →
        value-on (scale-cube τ i r) ds ≡ r • value-on τ ds
      coordinate-homogeneous : (τ : Cube n M) (ds : Vec D n) (i : Fin n) (r : R) →
        value-on τ (scale-coordinates ds i r) ≡ r • value-on τ ds
      cube-alternating : (τ : Cube n M) (ds : Vec D n) (p : Permutation n) →
        value-on (permute-cube τ p) ds ≡ signature p • value-on τ ds
  open RectangleLaw public

  zero-coordinate : {n : ℕ} (ds : Vec D n) (i : Fin n) →
    scale-coordinates ds i 0r ≡ update ds i zeroD
  zero-coordinate ds i = cong (update ds i)
    (S7.Basics.d-path A setR (*-zeroʳ (value (lookup ds i))))

  law-vanishes : {n : ℕ} {M : Set ℓ} (φ : RectangleLaw n M) (τ : Cube n M) →
    VanishesOnFaces (value-on φ τ)
  law-vanishes φ τ ds i = trans (cong (value-on φ τ) (sym (zero-coordinate ds i)))
    (trans (coordinate-homogeneous φ τ ds i 0r) (zero-scalar (value-on φ τ ds)))

  represented-form : {n : ℕ} {M : Set ℓ} → RectangleLaw n M → Form n M
  evaluate (represented-form {n} φ) τ = coefficient n (value-on φ τ)
  homogeneous (represented-form {n} φ) τ i r =
    trans (coefficient-cong n (value-on φ (scale-cube τ i r))
      (λ ds → r • value-on φ τ ds) (λ ds → cube-homogeneous φ τ ds i r))
      (coefficient-scale n r (value-on φ τ))
  alternating (represented-form {n} φ) τ p =
    trans (coefficient-cong n (value-on φ (permute-cube τ p))
      (λ ds → signature p • value-on φ τ ds) (λ ds → cube-alternating φ τ ds p))
      (coefficient-scale n (signature p) (value-on φ τ))

  representation : {n : ℕ} {M : Set ℓ} (φ : RectangleLaw n M)
    (τ : Cube n M) (ds : Vec D n) →
    value-on φ τ ds ≡ productD ds • evaluate (represented-form φ) τ
  representation {n} φ τ = factor n (value-on φ τ) (law-vanishes φ τ)

  representation-unique : {n : ℕ} {M : Set ℓ} (φ : RectangleLaw n M) (ω : Form n M) →
    ((τ : Cube n M) (ds : Vec D n) → value-on φ τ ds ≡ productD ds • evaluate ω τ) →
    (τ : Cube n M) → evaluate (represented-form φ) τ ≡ evaluate ω τ
  representation-unique {n} φ ω p τ = factor-unique n (value-on φ τ) (law-vanishes φ τ)
    (evaluate ω τ) (p τ)

  -- Conversely the infinitesimal rectangle pairing has all three properties.
  form-law : {n : ℕ} {M : Set ℓ} → Form n M → RectangleLaw n M
  value-on (form-law ω) τ ds = productD ds • evaluate ω τ
  cube-homogeneous (form-law ω) τ ds i r =
    trans (cong (productD ds •_) (homogeneous ω τ i r))
      (scalar-commute (productD ds) r (evaluate ω τ))
  coordinate-homogeneous (form-law ω) τ ds i r =
    trans (cong (_• evaluate ω τ) (product-scaled-coordinate ds i r))
      (scalar-assoc r (productD ds) (evaluate ω τ))
  cube-alternating (form-law ω) τ ds p =
    trans (cong (productD ds •_) (alternating ω τ p))
      (scalar-commute (productD ds) (signature p) (evaluate ω τ))

  form-roundtrip : {n : ℕ} {M : Set ℓ} (ω : Form n M) (τ : Cube n M) →
    evaluate (represented-form (form-law ω)) τ ≡ evaluate ω τ
  form-roundtrip ω = representation-unique (form-law ω) ω (λ _ _ → refl)

  law-roundtrip : {n : ℕ} {M : Set ℓ} (φ : RectangleLaw n M) (τ : Cube n M) (ds : Vec D n) →
    value-on (form-law (represented-form φ)) τ ds ≡ value-on φ τ ds
  law-roundtrip φ τ ds = sym (representation φ τ ds)

  native-uniqueness : (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) → isSet V →
    {n : ℕ} {M : Set ℓ} (φ : RectangleLaw n M) (ω : Form n M) →
    ((τ : Cube n M) (ds : Vec D n) → value-on φ τ ds ≡ productD ds • evaluate ω τ) →
    represented-form φ ≡ ω
  native-uniqueness ext0 ext setV φ ω p = FM.Native.form-ext A Vmod ext0 ext setV
    (representation-unique φ ω p)

