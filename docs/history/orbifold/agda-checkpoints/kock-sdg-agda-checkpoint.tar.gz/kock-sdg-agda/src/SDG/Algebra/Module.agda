{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Module where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Vec; []; _∷_; map; zipWith; replicate)

-- An ordinary unital module, with its additive abelian-group laws explicit.
record RModule {a : Level} (A : CRing a) (v : Level) : Set (lsuc (a ⊔ v)) where
  private
    module S = CRing A
  infixl 6 _+v_
  infixl 7 _•_
  infix 8 -v_
  field
    V : Set v
    0v : V
    _+v_ : V → V → V
    -v_ : V → V
    _•_ : S.R → V → V
    add-assoc : (x y z : V) → (x +v y) +v z ≡ x +v (y +v z)
    add-comm : (x y : V) → x +v y ≡ y +v x
    add-zeroˡ : (x : V) → 0v +v x ≡ x
    add-inverseˡ : (x : V) → (-v x) +v x ≡ 0v
    scalar-one : (x : V) → S.1r • x ≡ x
    scalar-assoc : (r s : S.R) (x : V) → (r S.* s) • x ≡ r • (s • x)
    scalar-add : (r s : S.R) (x : V) → (r S.+ s) • x ≡ (r • x) +v (s • x)
    scalar-distrib : (r : S.R) (x y : V) → r • (x +v y) ≡ (r • x) +v (r • y)

module ModuleLemmas {a v : Level} (A : CRing a) (M : RModule A v) where
  open RingLemmas A public
  open RModule M public

  add-zeroʳ : (x : V) → x +v 0v ≡ x
  add-zeroʳ x = trans (add-comm x 0v) (add-zeroˡ x)

  add-inverseʳ : (x : V) → x +v (-v x) ≡ 0v
  add-inverseʳ x = trans (add-comm x (-v x)) (add-inverseˡ x)

  add-inverse-cancel : (x y : V) → (-v x) +v (x +v y) ≡ y
  add-inverse-cancel x y =
    trans (sym (add-assoc (-v x) x y))
      (trans (cong (_+v y) (add-inverseˡ x)) (add-zeroˡ y))

  add-cancelˡ : (x : V) {y z : V} → x +v y ≡ x +v z → y ≡ z
  add-cancelˡ x {y} {z} p =
    trans (sym (add-inverse-cancel x y))
      (trans (cong ((-v x) +v_) p) (add-inverse-cancel x z))

  add-swap : (x y z : V) → x +v (y +v z) ≡ y +v (x +v z)
  add-swap x y z =
    trans (sym (add-assoc x y z))
      (trans (cong (_+v z) (add-comm x y)) (add-assoc y x z))

  add-shuffle : (a b c d : V) → (a +v b) +v (c +v d) ≡ (a +v c) +v (b +v d)
  add-shuffle a b c d = trans (add-assoc a b (c +v d))
    (trans (cong (a +v_) (add-swap b c d)) (sym (add-assoc a c (b +v d))))

  zero-scalar : (x : V) → 0r • x ≡ 0v
  zero-scalar x = add-cancelˡ (0r • x)
    (trans (sym (scalar-add 0r 0r x))
      (trans (cong (_• x) (+-identityˡ 0r)) (sym (add-zeroʳ (0r • x)))))

  scalar-zero : (r : R) → r • 0v ≡ 0v
  scalar-zero r = add-cancelˡ (r • 0v)
    (trans (sym (scalar-distrib r 0v 0v))
      (trans (cong (r •_) (add-zeroˡ 0v)) (sym (add-zeroʳ (r • 0v)))))

  scalar-commute : (r s : R) (x : V) → r • (s • x) ≡ s • (r • x)
  scalar-commute r s x =
    trans (sym (scalar-assoc r s x))
      (trans (cong (_• x) (*-comm r s)) (scalar-assoc s r x))

  scalar-square-zero : (d : R) → d * d ≡ 0r → (x : V) → d • (d • x) ≡ 0v
  scalar-square-zero d dd x = trans (sym (scalar-assoc d d x))
    (trans (cong (_• x) dd) (zero-scalar x))

scalarModule : {a : Level} (A : CRing a) → RModule A a
scalarModule A = record
  { V = CRing.R A
  ; 0v = CRing.0r A
  ; _+v_ = CRing._+_ A
  ; -v_ = CRing.-_ A
  ; _•_ = CRing._*_ A
  ; add-assoc = CRing.+-assoc A
  ; add-comm = CRing.+-comm A
  ; add-zeroˡ = CRing.+-identityˡ A
  ; add-inverseˡ = CRing.+-inverseˡ A
  ; scalar-one = CRing.*-identityˡ A
  ; scalar-assoc = CRing.*-assoc A
  ; scalar-add = CRing.distribʳ A
  ; scalar-distrib = CRing.distribˡ A
  }

module FiniteModules {a v : Level} (A : CRing a) (M : RModule A v) where
  open ModuleLemmas A M

  add : {n : ℕ} → Vec V n → Vec V n → Vec V n
  add = zipWith _+v_

  scale : {n : ℕ} → R → Vec V n → Vec V n
  scale r = map (r •_)

  add-associative : {n : ℕ} (xs ys zs : Vec V n) → add (add xs ys) zs ≡ add xs (add ys zs)
  add-associative [] [] [] = refl
  add-associative (x ∷ xs) (y ∷ ys) (z ∷ zs) =
    cong₂ _∷_ (add-assoc x y z) (add-associative xs ys zs)

  add-commutative : {n : ℕ} (xs ys : Vec V n) → add xs ys ≡ add ys xs
  add-commutative [] [] = refl
  add-commutative (x ∷ xs) (y ∷ ys) = cong₂ _∷_ (add-comm x y) (add-commutative xs ys)

  add-zero-left : {n : ℕ} (xs : Vec V n) → add (replicate 0v) xs ≡ xs
  add-zero-left [] = refl
  add-zero-left (x ∷ xs) = cong₂ _∷_ (add-zeroˡ x) (add-zero-left xs)

  add-inverse-left : {n : ℕ} (xs : Vec V n) → add (map -v_ xs) xs ≡ replicate 0v
  add-inverse-left [] = refl
  add-inverse-left (x ∷ xs) = cong₂ _∷_ (add-inverseˡ x) (add-inverse-left xs)

  scale-one : {n : ℕ} (xs : Vec V n) → scale 1r xs ≡ xs
  scale-one [] = refl
  scale-one (x ∷ xs) = cong₂ _∷_ (scalar-one x) (scale-one xs)

  scale-associative : {n : ℕ} (r s : R) (xs : Vec V n) → scale (r * s) xs ≡ scale r (scale s xs)
  scale-associative r s [] = refl
  scale-associative r s (x ∷ xs) = cong₂ _∷_ (scalar-assoc r s x) (scale-associative r s xs)

  scale-add : {n : ℕ} (r s : R) (xs : Vec V n) → scale (r + s) xs ≡ add (scale r xs) (scale s xs)
  scale-add r s [] = refl
  scale-add r s (x ∷ xs) = cong₂ _∷_ (scalar-add r s x) (scale-add r s xs)

  scale-distrib : {n : ℕ} (r : R) (xs ys : Vec V n) →
    scale r (add xs ys) ≡ add (scale r xs) (scale r ys)
  scale-distrib r [] [] = refl
  scale-distrib r (x ∷ xs) (y ∷ ys) =
    cong₂ _∷_ (scalar-distrib r x y) (scale-distrib r xs ys)

  finiteModule : (n : ℕ) → RModule A v
  finiteModule n = record
    { V = Vec V n
    ; 0v = replicate 0v
    ; _+v_ = add
    ; -v_ = map -v_
    ; _•_ = scale
    ; add-assoc = add-associative
    ; add-comm = add-commutative
    ; add-zeroˡ = add-zero-left
    ; add-inverseˡ = add-inverse-left
    ; scalar-one = scale-one
    ; scalar-assoc = scale-associative
    ; scalar-add = scale-add
    ; scalar-distrib = scale-distrib
    }

finiteScalarModule : {a : Level} (A : CRing a) → ℕ → RModule A a
finiteScalarModule A = FiniteModules.finiteModule A (scalarModule A)

-- Equality-valued function modules require extensionality, explicitly supplied.
functionModule : {a v x : Level} (A : CRing a) (M : RModule A v)
  (X : Set x) → FunExt x v → RModule A (x ⊔ v)
functionModule A M X ext = record
  { V = X → V
  ; 0v = λ _ → 0v
  ; _+v_ = λ f g x → f x +v g x
  ; -v_ = λ f x → -v f x
  ; _•_ = λ r f x → r • f x
  ; add-assoc = λ f g h → ext (λ x → add-assoc (f x) (g x) (h x))
  ; add-comm = λ f g → ext (λ x → add-comm (f x) (g x))
  ; add-zeroˡ = λ f → ext (λ x → add-zeroˡ (f x))
  ; add-inverseˡ = λ f → ext (λ x → add-inverseˡ (f x))
  ; scalar-one = λ f → ext (λ x → scalar-one (f x))
  ; scalar-assoc = λ r s f → ext (λ x → scalar-assoc r s (f x))
  ; scalar-add = λ r s f → ext (λ x → scalar-add r s (f x))
  ; scalar-distrib = λ r f g → ext (λ x → scalar-distrib r (f x) (g x))
  }
  where open RModule M
