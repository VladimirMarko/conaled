{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section09LieLawsGroup where

open import SDG.Prelude
open import SDG.Algebra.Group
import SDG.ChapterI.Section11Hall as Words

-- The commutator identities used by the geometric Lie proof are proved
-- by the same verified word normalizer as Hall's identity.
module Identities {ℓ : Level} {G : Set ℓ} (H : Group G) where
  open GroupLemmas H hiding (commutator; conjugate)
  module Native = GroupLemmas H

  environment : G → G → G → Words.Label → G
  environment a b c Words.x = a
  environment a b c Words.y = b
  environment a b c Words.z = c

  word-equation : (e f : Words.Expr) →
    Words.normalize (Words.flatten e) ≡ Words.normalize (Words.flatten f) →
    (a b c : G) →
    Words.Correctness.expr-value H (environment a b c) e ≡
    Words.Correctness.expr-value H (environment a b c) f
  word-equation e f p a b c =
    trans (sym (W.flatten-correct e))
      (trans (sym (W.normalize-correct (Words.flatten e)))
        (trans (cong W.word-value p)
          (trans (W.normalize-correct (Words.flatten f)) (W.flatten-correct f))))
    where
    module W = Words.Correctness H (environment a b c)

  private
    x y z : Words.Expr
    x = Words.var Words.x
    y = Words.var Words.y
    z = Words.var Words.z

  abstract
    -- Opaque group-word operations prevent exponential expansion of
    -- proof-relevant automorphism records in nested commutators.
    commutator : G → G → G
    commutator = Native.commutator

    conjugate : G → G → G
    conjugate = Native.conjugate

    commutator-agrees : (a b : G) → commutator a b ≡ Native.commutator a b
    commutator-agrees a b = refl

    conjugate-as-product : (a b : G) → conjugate a b ≡ a · commutator a b
    conjugate-as-product a b = word-equation (Words.conjugate-expr x y)
      (Words.multiply x (Words.commutator-expr x y)) refl a b unit

    commutator-productˡ : (a b c : G) →
      commutator (a · b) c ≡ conjugate (commutator a c) b · commutator b c
    commutator-productˡ = word-equation (Words.commutator-expr (Words.multiply x y) z)
      (Words.multiply (Words.conjugate-expr (Words.commutator-expr x z) y)
        (Words.commutator-expr y z)) refl

    commutator-productʳ : (a b c : G) →
      commutator a (b · c) ≡ commutator a c · conjugate (commutator a b) c
    commutator-productʳ = word-equation (Words.commutator-expr x (Words.multiply y z))
      (Words.multiply (Words.commutator-expr x z)
        (Words.conjugate-expr (Words.commutator-expr x y) z)) refl

    conjugate-trivial : (a b : G) → commutator a b ≡ unit → conjugate a b ≡ a
    conjugate-trivial a b p = trans (conjugate-as-product a b)
      (trans (cong (a ·_) p) (identityʳ a))

    -- The two correction commutators are the repeated-infinitesimal terms
    -- which vanish in the use of Hall's identity below.
    conjugated-commutator : (a b c : G) →
      commutator (commutator a b) c ≡ unit →
      commutator (commutator a c) (commutator a b) ≡ unit →
      commutator (conjugate a b) c ≡ commutator a c
    conjugated-commutator a b c p q =
      trans (cong (λ t → commutator t c) (conjugate-as-product a b))
        (trans (commutator-productˡ a (commutator a b) c)
          (trans (cong₂ _·_ (conjugate-trivial (commutator a c) (commutator a b) q) p)
            (identityʳ (commutator a c))))

    hall-identity : (a b c : G) →
      (commutator (conjugate a b) (commutator b c) ·
        commutator (conjugate b c) (commutator c a)) ·
        commutator (conjugate c a) (commutator a b) ≡ unit
    hall-identity = Words.Hall.hall-identity H
