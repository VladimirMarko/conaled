{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16Higher where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Algebra.PresentedJets
import SDG.Algebra.TruncatedPolynomials as Trunc
open import SDG.Finite using (Vec; []; _∷_; fzero; fsuc)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section12 as S12
import SDG.ChapterI.Section16Comparison as Comparison

-- All-order Theorem 12.1. The concrete truncated convolution algebra
-- R[X]/(X^(k+1)) was proved to be a ring in TruncatedPolynomials; here
-- its polynomial presentation and nilpotent spectrum are identified.
module Higher {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
  open S3.HigherInfinitesimals A
  open Presentations k
  open JetPresentations k
  open S12.Comprehensive k A base ext ext0 setR
  open Comparison.Comparison k A base ext ext0 setR Ax
  module T = Trunc.Polynomials A

  evaluation-conversion : {n : ℕ} (as : Vec R n) (x : R) → T.evaluate as x ≡ eval as x
  evaluation-conversion [] x = refl
  evaluation-conversion (a ∷ as) x = cong (λ b → a + x * b) (evaluation-conversion as x)

  module Degree (degree : ℕ) where
    C : RAlgebra A ℓ
    C = T.truncatedAlgebra (suc degree)

    baseC : RingHom k (ring C)
    baseC = composeRingHom (unit C) base

    generic-root : SpecC C (truncated-line degree)
    coordinates generic-root i = T.epsilon (suc degree)
    satisfies generic-root j = trans
      (evaluate-power (ring C) baseC (var fzero) (suc degree) (λ _ → T.epsilon (suc degree)))
      (T.epsilon-nilpotent-native (suc degree))

    to-spectrum : DK degree → Affine (truncated-line degree)
    coordinates (to-spectrum d) i = valueK d
    satisfies (to-spectrum d) j =
      trans (evaluate-power A base (var fzero) (suc degree) (λ _ → valueK d)) (nilpotence d)

    from-spectrum : Affine (truncated-line degree) → DK degree
    from-spectrum x = nilpotent (coordinates x fzero)
      (trans (sym (evaluate-power A base (var fzero) (suc degree) (coordinates x))) (satisfies x fzero))

    from-to-spectrum : (d : DK degree) → from-spectrum (to-spectrum d) ≡ d
    from-to-spectrum d = cong (nilpotent (valueK d)) (setR _ _ _ _)

    truncated-realization : AlgebraicRealization (truncated-line degree)
    model-algebra truncated-realization = C
    set-carrier truncated-realization = T.poly-isSet ext0 setR (suc degree)
    generic-point truncated-realization = generic-root
    character truncated-realization x = T.evalAlgHom degree (valueK (from-spectrum x)) (nilpotence (from-spectrum x))
    evaluate-generator truncated-realization x fzero =
      T.evaluate-epsilon degree (valueK (from-spectrum x)) (nilpotence (from-spectrum x))
    evaluate-generator truncated-realization x (fsuc ())
    generated truncated-realization f g eq = T.generated-native ext ext0 setR (suc degree) f g (eq fzero)

    module Iso = Realized (truncated-line degree) truncated-realization

    coefficients : (DK degree → R) → Vec R (suc degree)
    coefficients f = algMap Iso.beta (λ x → f (from-spectrum x))

    reconstruction : (f : DK degree → R) (d : DK degree) → f d ≡ eval (coefficients f) (valueK d)
    reconstruction f d = trans (cong f (sym (from-to-spectrum d)))
      (trans (sym (cong (λ h → algMap h (λ x → f (from-spectrum x)) (to-spectrum d)) Iso.alpha-beta))
        (evaluation-conversion (coefficients f) (valueK d)))

    unique : (f : DK degree → R) (as : Vec R (suc degree)) →
      ((d : DK degree) → f d ≡ eval as (valueK d)) → coefficients f ≡ as
    unique f as eq = trans (cong (algMap Iso.beta) (ext (λ x →
      trans (eq (from-spectrum x)) (sym (evaluation-conversion as (valueK (from-spectrum x)))))))
      (cong (λ h → algMap h as) Iso.beta-alpha)

  axiom2-higher-order : HigherKockLawvere
  HigherKockLawvere.coefficients axiom2-higher-order n = Degree.coefficients (suc n)
  HigherKockLawvere.reconstruction axiom2-higher-order n = Degree.reconstruction (suc n)
  HigherKockLawvere.uniqueness axiom2-higher-order n = Degree.unique (suc n)
