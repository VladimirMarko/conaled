{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section13Intervals where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section02Exercises as E2
import SDG.ChapterI.Section13 as S13

module Results {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) where
  open S13.Results A K O J public
    renaming (integral to unit-integral; integral-cong to unit-integral-cong;
      integral-add to unit-integral-add; integral-scale to unit-integral-scale;
      integral-neg to unit-integral-neg; integral-sub to unit-integral-sub;
      integral-zero to unit-integral-zero; integral-constant to unit-integral-constant;
      integral-derivative to unit-integral-derivative;
      integration-by-parts to unit-integration-by-parts)
  open Infinitesimals A
  open E2.DifferenceAlgebra A using (subtract-zero; subtract-self; multiply-difference; difference-multiply; subtract-sums)

  multiply-reverse : (r s t : R) → r * (s * t) ≡ t * (s * r)
  multiply-reverse r s t = trans (sym (*-assoc r s t))
    (trans (*-comm (r * s) t) (cong (t *_) (*-comm r s)))

  module Over {a b : R} (ab : a ≤ b) where
    module C = On a b
    module P = Parameters (intervalDomain a b)

    left right : Interval a b
    left = left-endpoint ab
    right = right-endpoint ab

    gap : Interval a b → R
    gap x = coordinate x - a

    gap-derivative : (x : Interval a b) → C.derivative gap x ≡ 1r
    gap-derivative x = trans (C.derivative-add coordinate (λ _ → - a) x)
      (trans (cong₂ _+_ (C.derivative-coordinate x) (C.derivative-constant (- a) x)) (+-identityʳ 1r))

    path-target-derivative : (x : Interval a b) (t : UnitInterval) →
      C.derivative (λ y → coordinate (path left y t)) x ≡ coordinate t
    path-target-derivative x t =
      trans (C.derivative-add (λ _ → a) (λ y → coordinate t * gap y) x)
        (trans (cong₂ _+_ (C.derivative-constant a x)
          (trans (C.derivative-scale (coordinate t) gap x)
            (trans (cong (coordinate t *_) (gap-derivative x)) (*-identityʳ (coordinate t)))))
          (+-identityˡ (coordinate t)))

    row : (Interval a b → R) → Interval a b → UnitInterval → R
    row f x t = f (path left x t)

    row-target-derivative : (f : Interval a b → R) (x : Interval a b) (t : UnitInterval) →
      C.derivative (λ y → row f y t) x ≡ C.derivative f (path left x t) * coordinate t
    row-target-derivative f x t =
      trans (Local.Chain.derivative-chain A K (intervalDomain a b) (intervalDomain a b)
        f (λ y → path left y t) x)
        (cong (C.derivative f (path left x t) *_) (path-target-derivative x t))

    row-source-derivative : (f : Interval a b → R) (x : Interval a b) (t : UnitInterval) →
      Unit.derivative (row f x) t ≡ C.derivative f (path left x t) * gap x
    row-source-derivative f x t =
      trans (Local.Chain.derivative-chain A K (intervalDomain a b) (intervalDomain 0r 1r)
        f (path left x) t)
        (cong (C.derivative f (path left x t) *_) (path-derivative left x t))

    integral-row-derivative : (f : Interval a b → R) (x : Interval a b) →
      C.derivative (λ y → unit-integral (row f y)) x ≡
      unit-integral (λ t → C.derivative f (path left x t) * coordinate t)
    integral-row-derivative f x = trans (P.differentiate-integral (row f) x)
      (unit-integral-cong _ _ (row-target-derivative f x))

    -- This construction uses only the unit-interval axiom and never divides
    -- by b-a. It therefore also covers infinitesimal or degenerate lengths.
    intervalPrimitive : (Interval a b → R) → Interval a b → R
    intervalPrimitive f x = gap x * unit-integral (row f x)

    interval-primitive-zero : (f : Interval a b → R) → intervalPrimitive f left ≡ 0r
    interval-primitive-zero f = trans
      (cong (_* unit-integral (row f left)) (+-inverseʳ a)) (*-zeroˡ (unit-integral (row f left)))

    endpoint-integral : (f : Interval a b → R) (x : Interval a b) →
      unit-integral (λ t → gap x * (C.derivative f (path left x t) * coordinate t) + row f x t) ≡ f x
    endpoint-integral f x =
      trans (unit-integral-cong _ (Unit.derivative (λ t → coordinate t * row f x t)) integrand)
        (trans (unit-integral-derivative (λ t → coordinate t * row f x t))
          (trans (cong₂ _-_
            (trans (*-identityˡ (row f x one-point)) (cong f (path-one left x)))
            (*-zeroˡ (row f x zero-point))) (subtract-zero (f x))))
      where
      integrand : (t : UnitInterval) →
        gap x * (C.derivative f (path left x t) * coordinate t) + row f x t ≡
        Unit.derivative (λ s → coordinate s * row f x s) t
      integrand t = sym (trans (Unit.derivative-product coordinate (row f x) t)
        (trans (cong₂ _+_
          (cong (coordinate t *_) (row-source-derivative f x t))
          (trans (cong (row f x t *_) (Unit.derivative-coordinate t)) (*-identityʳ (row f x t))))
          (cong (_+ row f x t) (multiply-reverse (coordinate t) (C.derivative f (path left x t)) (gap x)))))

    -- Theorem I.13.2: existence, obtained from the axiom only on [0,1].
    interval-primitive-derivative : (f : Interval a b → R) (x : Interval a b) →
      C.derivative (intervalPrimitive f) x ≡ f x
    interval-primitive-derivative f x =
      trans (C.derivative-product gap (λ y → unit-integral (row f y)) x)
        (trans (cong₂ _+_
          (cong (gap x *_) (integral-row-derivative f x))
          (trans (cong (unit-integral (row f x) *_) (gap-derivative x)) (*-identityʳ (unit-integral (row f x)))))
          (trans (cong (_+ unit-integral (row f x))
            (sym (unit-integral-scale (gap x) (λ t → C.derivative f (path left x t) * coordinate t))))
            (trans (sym (unit-integral-add
              (λ t → gap x * (C.derivative f (path left x t) * coordinate t)) (row f x)))
              (endpoint-integral f x))))

    equal-derivatives-differences : (f g : Interval a b → R) →
      ((z : Interval a b) → C.derivative f z ≡ C.derivative g z) →
      (x y : Interval a b) → f y - f x ≡ g y - g x
    equal-derivatives-differences f g p x y = trans (hadamard f x y)
      (trans (cong ((coordinate y - coordinate x) *_)
        (unit-integral-cong _ _ (λ t → p (path x y t)))) (sym (hadamard g x y)))

    interval-primitive-unique : (f g : Interval a b → R) →
      ((z : Interval a b) → C.derivative g z ≡ f z) → g left ≡ 0r →
      (x : Interval a b) → g x ≡ intervalPrimitive f x
    interval-primitive-unique f g p base x =
      trans (sym (trans (cong (λ z → g x - z) base) (subtract-zero (g x))))
        (trans (equal-derivatives-differences g (intervalPrimitive f)
          (λ z → trans (p z) (sym (interval-primitive-derivative f z))) left x)
          (trans (cong (λ z → intervalPrimitive f x - z) (interval-primitive-zero f))
            (subtract-zero (intervalPrimitive f x))))

    interval-primitive-cong : (f g : Interval a b → R) → ((x : Interval a b) → f x ≡ g x) →
      (x : Interval a b) → intervalPrimitive f x ≡ intervalPrimitive g x
    interval-primitive-cong f g p = interval-primitive-unique g (intervalPrimitive f)
      (λ x → trans (interval-primitive-derivative f x) (p x)) (interval-primitive-zero f)

    interval-primitive-add : (f g : Interval a b → R) (x : Interval a b) →
      intervalPrimitive (λ y → f y + g y) x ≡ intervalPrimitive f x + intervalPrimitive g x
    interval-primitive-add f g x = sym (interval-primitive-unique (λ y → f y + g y)
      (λ y → intervalPrimitive f y + intervalPrimitive g y)
      (λ y → trans (C.derivative-add (intervalPrimitive f) (intervalPrimitive g) y)
        (cong₂ _+_ (interval-primitive-derivative f y) (interval-primitive-derivative g y)))
      (trans (cong₂ _+_ (interval-primitive-zero f) (interval-primitive-zero g)) (+-identityˡ 0r)) x)

    interval-primitive-scale : (r : R) (f : Interval a b → R) (x : Interval a b) →
      intervalPrimitive (λ y → r * f y) x ≡ r * intervalPrimitive f x
    interval-primitive-scale r f x = sym (interval-primitive-unique (λ y → r * f y)
      (λ y → r * intervalPrimitive f y)
      (λ y → trans (C.derivative-scale r (intervalPrimitive f) y)
        (cong (r *_) (interval-primitive-derivative f y)))
      (trans (cong (r *_) (interval-primitive-zero f)) (*-zeroʳ r)) x)

    interval-primitive-neg : (f : Interval a b → R) (x : Interval a b) →
      intervalPrimitive (λ y → - f y) x ≡ (- intervalPrimitive f x)
    interval-primitive-neg f x = sym (interval-primitive-unique (λ y → - f y)
      (λ y → - intervalPrimitive f y)
      (λ y → trans (C.derivative-neg (intervalPrimitive f) y)
        (cong -_ (interval-primitive-derivative f y)))
      (trans (cong -_ (interval-primitive-zero f)) neg-zero) x)

    interval-primitive-of-zero : (x : Interval a b) → intervalPrimitive (λ _ → 0r) x ≡ 0r
    interval-primitive-of-zero x = sym (interval-primitive-unique (λ _ → 0r) (λ _ → 0r)
      (C.derivative-constant 0r) refl x)

    interval-primitive-of-derivative : (h : Interval a b → R) (x : Interval a b) →
      intervalPrimitive (C.derivative h) x ≡ h x - h left
    interval-primitive-of-derivative h x = sym (interval-primitive-unique (C.derivative h)
      (λ y → h y - h left)
      (λ y → trans (C.derivative-add h (λ _ → - h left) y)
        (trans (cong (C.derivative h y +_) (C.derivative-constant (- h left) y)) (+-identityʳ (C.derivative h y))))
      (+-inverseʳ (h left)) x)

    integral : (Interval a b → R) → R
    integral f = intervalPrimitive f right

    integral-cong : (f g : Interval a b → R) → ((x : Interval a b) → f x ≡ g x) → integral f ≡ integral g
    integral-cong f g p = interval-primitive-cong f g p right

    integral-add : (f g : Interval a b → R) → integral (λ x → f x + g x) ≡ integral f + integral g
    integral-add f g = interval-primitive-add f g right

    integral-scale : (r : R) (f : Interval a b → R) → integral (λ x → r * f x) ≡ r * integral f
    integral-scale r f = interval-primitive-scale r f right

    integral-neg : (f : Interval a b → R) → integral (λ x → - f x) ≡ (- integral f)
    integral-neg f = interval-primitive-neg f right

    integral-sub : (f g : Interval a b → R) → integral (λ x → f x - g x) ≡ integral f - integral g
    integral-sub f g = trans (integral-add f (λ x → - g x)) (cong (integral f +_) (integral-neg g))

    integral-zero : integral (λ _ → 0r) ≡ 0r
    integral-zero = interval-primitive-of-zero right

    integral-derivative : (h : Interval a b → R) → integral (C.derivative h) ≡ h right - h left
    integral-derivative h = interval-primitive-of-derivative h right

    integral-constant : (r : R) → integral (λ _ → r) ≡ (b - a) * r
    integral-constant r = cong ((b - a) *_) (unit-integral-constant r)

    integration-by-parts : (f g : Interval a b → R) →
      integral (λ t → f t * C.derivative g t) + integral (λ t → g t * C.derivative f t) ≡
      f right * g right - f left * g left
    integration-by-parts f g = trans
      (sym (integral-add (λ t → f t * C.derivative g t) (λ t → g t * C.derivative f t)))
      (trans (integral-cong _ _ (λ t → sym (C.derivative-product f g t)))
        (integral-derivative (λ t → f t * g t)))

    module Parameter (U : Local.StableDomain A) where
      module Q = Local.Calculus A K U

      differentiate-integral : (f : Q.Carrier → Interval a b → R) (x : Q.Carrier) →
        Q.derivative (λ y → integral (f y)) x ≡ integral (λ t → Q.derivative (λ y → f y t) x)
      differentiate-integral f x = Q.derivative-unique (λ y → integral (f y)) x
        (integral (λ t → Q.derivative (λ y → f y t) x)) (λ d →
          trans (integral-cong (f (Q.shift x d))
            (λ t → f x t + value d * Q.derivative (λ y → f y t) x)
            (λ t → Q.taylor (λ y → f y t) x d))
            (trans (integral-add (f x) (λ t → value d * Q.derivative (λ y → f y t) x))
              (cong (integral (f x) +_) (integral-scale (value d) (λ t → Q.derivative (λ y → f y t) x)))))

  unit-interval-consistency : (f : UnitInterval → R) (x : UnitInterval) →
    Over.intervalPrimitive zero-one f x ≡ primitiveOf f x
  unit-interval-consistency f = primitive-unique f (Over.intervalPrimitive zero-one f)
    (Over.interval-primitive-derivative zero-one f) (Over.interval-primitive-zero zero-one f)

  unit-integral-consistency : (f : UnitInterval → R) → Over.integral zero-one f ≡ unit-integral f
  unit-integral-consistency f = unit-interval-consistency f one-point
