{-# OPTIONS --safe --without-K #-}

module SDG.Infinitesimal.JetAlgebra where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; replicate; lookup-replicate;
   map; lookup-map; zipWith; lookup-zipWith; vec-ext; nat-add-zeroʳ; nat-add-sucʳ; _+ℕ_; _*ℕ_)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.Polynomial
import SDG.ChapterI.Section03 as S3

module JetAlgebra {ℓ : Level} (A : CRing ℓ) where
  open S3.HigherInfinitesimals A
  open Jets A
  open Polynomials A using (InIdeal; ideal-zero; generator; ideal-scale; ideal-cons; ideal-products)

  products-scaleʳ : {n : ℕ} (xs : Vec R n) (q : ℕ) (a r : R) →
    ProductsZero xs q a → ProductsZero xs q (a * r)
  products-scaleʳ xs q a r p =
    subst (ProductsZero xs q) (*-comm r a) (products-scale xs q r a p)

  -- Sharp product bound. A product of k+l+1 coordinate sums contains
  -- either k+1 factors from xs or l+1 factors from ys. The induction
  -- performs that argument directly, without a combinatorial axiom.
  products-sum : {n : ℕ} (xs ys : Vec R n) (k l : ℕ) (a : R) →
    ProductsZero xs (suc k) a → ProductsZero ys (suc l) a →
    ProductsZero (zipWith _+_ xs ys) (suc (k +ℕ l)) a
  products-sum xs ys zero zero a px py i =
    trans (cong (a *_) (lookup-zipWith _+_ xs ys i))
      (trans (distribˡ a (lookup xs i) (lookup ys i))
        (trans (cong₂ _+_ (px i) (py i)) (+-identityˡ 0r)))
  products-sum xs ys zero (suc l) a px py i =
    subst (ProductsZero (zipWith _+_ xs ys) (suc l)) (sym reduce)
      (products-sum xs ys zero l (a * lookup ys i)
        (products-scaleʳ xs (suc zero) a (lookup ys i) px) (py i))
    where
    reduce : a * lookup (zipWith _+_ xs ys) i ≡ a * lookup ys i
    reduce = trans (cong (a *_) (lookup-zipWith _+_ xs ys i))
      (trans (distribˡ a (lookup xs i) (lookup ys i))
        (trans (cong (_+ (a * lookup ys i)) (px i)) (+-identityˡ (a * lookup ys i))))
  products-sum xs ys (suc k) zero a px py i =
    subst (ProductsZero (zipWith _+_ xs ys) (suc (k +ℕ zero))) (sym reduce)
      (products-sum xs ys k zero (a * lookup xs i) (px i)
        (products-scaleʳ ys (suc zero) a (lookup xs i) py))
    where
    reduce : a * lookup (zipWith _+_ xs ys) i ≡ a * lookup xs i
    reduce = trans (cong (a *_) (lookup-zipWith _+_ xs ys i))
      (trans (distribˡ a (lookup xs i) (lookup ys i))
        (trans (cong ((a * lookup xs i) +_) (py i)) (+-identityʳ (a * lookup xs i))))
  products-sum xs ys (suc k) (suc l) a px py i =
    subst (ProductsZero (zipWith _+_ xs ys) (suc (k +ℕ suc l)))
      (sym (trans (cong (a *_) (lookup-zipWith _+_ xs ys i))
        (distribˡ a (lookup xs i) (lookup ys i))))
      (products-add (zipWith _+_ xs ys) (suc (k +ℕ suc l))
        (a * lookup xs i) (a * lookup ys i)
        (products-sum xs ys k (suc l) (a * lookup xs i) (px i)
          (products-scaleʳ ys (suc (suc l)) a (lookup xs i) py))
        (subst (λ q → ProductsZero (zipWith _+_ xs ys) q (a * lookup ys i))
          (sym (cong suc (nat-add-sucʳ k l)))
          (products-sum xs ys (suc k) l (a * lookup ys i)
            (products-scaleʳ xs (suc (suc k)) a (lookup ys i) px) (py i))))

  addJets : {k l n : ℕ} → DJet k n → DJet l n → DJet (k +ℕ l) n
  addJets {k} {l} p q = jet (zipWith _+_ (coords p) (coords q))
    (products-sum (coords p) (coords q) k l 1r (vanish p) (vanish q))

  append : {a : Level} {X : Set a} {n m : ℕ} → Vec X n → Vec X m → Vec X (n +ℕ m)
  append [] ys = ys
  append (x ∷ xs) ys = x ∷ append xs ys

  left-members : {n : ℕ} (xs : Vec R n) (m : ℕ) →
    (i : Fin (n +ℕ m)) → InIdeal xs (lookup (append xs (replicate {n = m} 0r)) i)
  left-members [] m i = subst (InIdeal []) (sym (lookup-replicate 0r i)) ideal-zero
  left-members (x ∷ xs) m fzero = generator fzero
  left-members (x ∷ xs) m (fsuc i) = ideal-cons x xs (left-members xs m i)

  right-members : {m : ℕ} (n : ℕ) (ys : Vec R m) →
    (i : Fin (n +ℕ m)) → InIdeal ys (lookup (append (replicate {n = n} 0r) ys) i)
  right-members zero ys i = generator i
  right-members (suc n) ys fzero = ideal-zero
  right-members (suc n) ys (fsuc i) = right-members n ys i

  padLeft : {k n : ℕ} → DJet k n → (m : ℕ) → DJet k (n +ℕ m)
  padLeft {k} d m = jet (append (coords d) (replicate 0r))
    (ideal-products (coords d) (append (coords d) (replicate 0r)) (suc k) 1r
      (left-members (coords d) m) (vanish d))

  padRight : {k m : ℕ} → (n : ℕ) → DJet k m → DJet k (n +ℕ m)
  padRight {k} n d = jet (append (replicate 0r) (coords d))
    (ideal-products (coords d) (append (replicate 0r) (coords d)) (suc k) 1r
      (right-members n (coords d)) (vanish d))

  zip-zeroˡ : {n : ℕ} (xs : Vec R n) → zipWith _+_ (replicate 0r) xs ≡ xs
  zip-zeroˡ [] = refl
  zip-zeroˡ (x ∷ xs) = cong₂ _∷_ (+-identityˡ x) (zip-zeroˡ xs)

  append-added : {n m : ℕ} (xs : Vec R n) (ys : Vec R m) →
    zipWith _+_ (append xs (replicate 0r)) (append (replicate 0r) ys) ≡ append xs ys
  append-added [] ys = zip-zeroˡ ys
  append-added (x ∷ xs) ys = cong₂ _∷_ (+-identityʳ x) (append-added xs ys)

  -- Exercise I.6.3, first assertion, with the precise k+l bound.
  concatenate : {k l n m : ℕ} → DJet k n → DJet l m → DJet (k +ℕ l) (n +ℕ m)
  concatenate {k} {l} {n} {m} p q = jet (append (coords p) (coords q))
    (subst (λ xs → ProductsZero xs (suc (k +ℕ l)) 1r) (append-added (coords p) (coords q))
      (vanish (addJets (padLeft p m) (padRight n q))))

  repeat-build : (x : R) (q : ℕ) (r : R) →
    r * (x ^ q) ≡ 0r → ProductsZero (x ∷ []) q r
  repeat-build x zero r p = trans (sym (*-identityʳ r)) p
  repeat-build x (suc q) r p fzero =
    repeat-build x q (r * x) (trans (*-assoc r x (x ^ q)) p)

  singletonK : {k : ℕ} → DK k → DJet k (suc zero)
  singletonK {k} d = jet (valueK d ∷ [])
    (repeat-build (valueK d) (suc k) 1r (trans (*-identityˡ (valueK d ^ suc k)) (nilpotence d)))

  -- The inclusion (D_k)^n -> D_(n*k)(n), including k=0 and n=0.
  rectangle : {k n : ℕ} → Vec (DK k) n → DJet (n *ℕ k) n
  rectangle {k} [] = zeroJet zero zero
  rectangle {k} (d ∷ ds) = concatenate (singletonK d) (rectangle ds)

  scalarJet : {k n : ℕ} → R → DJet k n → DJet k n
  scalarJet {k} r d = jet (map (r *_) (coords d))
    (ideal-products (coords d) (map (r *_) (coords d)) (suc k) 1r
      (λ i → subst (InIdeal (coords d)) (sym (lookup-map (r *_) (coords d) i))
        (ideal-scale r (generator i))) (vanish d))

  negateJet : {k n : ℕ} → DJet k n → DJet k n
  negateJet {k} d = jet (map -_ (coords d))
    (ideal-products (coords d) (map -_ (coords d)) (suc k) 1r
      (λ i → subst (InIdeal (coords d))
        (trans (neg-mulˡ 1r (coordinate d i))
          (trans (cong -_ (*-identityˡ (coordinate d i))) (sym (lookup-map -_ (coords d) i))))
        (ideal-scale (- 1r) (generator i))) (vanish d))

  zero-order-coordinates : {n : ℕ} (d : DJet zero n) → coords d ≡ replicate 0r
  zero-order-coordinates d = vec-ext (λ i →
    trans (sym (*-identityˡ (coordinate d i)))
      (trans (vanish d i) (sym (lookup-replicate 0r i))))
