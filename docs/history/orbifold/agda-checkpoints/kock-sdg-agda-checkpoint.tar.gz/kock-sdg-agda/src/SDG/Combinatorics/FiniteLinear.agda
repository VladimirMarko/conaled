{-# OPTIONS --safe --without-K #-}
module SDG.Combinatorics.FiniteLinear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Fin; fzero; fsuc)
import SDG.Combinatorics.FiniteSums as FS

module Coordinates {ℓ : Level} (A : CRing ℓ) (ext0 : FunExt lzero ℓ) where
  open RingLemmas A
  open FS.Sums A

  Tuple : ℕ → Set ℓ
  Tuple n = Fin n → R

  record Linear {n : ℕ} (f : Tuple n → R) : Set ℓ where
    field
      map-zero : f (λ _ → 0r) ≡ 0r
      map-add : (x y : Tuple n) → f (λ i → x i + y i) ≡ f x + f y
      map-scale : (r : R) (x : Tuple n) → f (λ i → r * x i) ≡ r * f x
  open Linear public

  linear-sum : {n m : ℕ} {f : Tuple n → R} → Linear f → (x : Fin m → Tuple n) →
    f (λ i → sum (λ j → x j i)) ≡ sum (λ j → f (x j))
  linear-sum {m = zero} L x = map-zero L
  linear-sum {m = suc m} L x = trans (map-add L (x fzero) (λ i → sum (λ j → x (fsuc j) i)))
    (cong (_ +_) (linear-sum L (λ j → x (fsuc j))))

  linear-basis : {n : ℕ} {f : Tuple n → R} → Linear f → (x : Tuple n) →
    f x ≡ sum (λ i → x i * f (delta i))
  linear-basis {f = f} L x =
    trans (cong f (ext0 (λ j → sym (basis-expansion x j))))
      (trans (linear-sum L (λ i j → x i * delta i j))
        (sum-cong (λ i → map-scale L (x i) (delta i))))

  linear-ext : {n : ℕ} {f g : Tuple n → R} → Linear f → Linear g →
    ((i : Fin n) → f (delta i) ≡ g (delta i)) → (x : Tuple n) → f x ≡ g x
  linear-ext L M eq x = trans (linear-basis L x)
    (trans (sum-cong (λ i → cong (x i *_) (eq i))) (sym (linear-basis M x)))

  compose-linear : {n m : ℕ} {f : Tuple m → R} {g : Tuple n → Tuple m} →
    Linear f → ((j : Fin m) → Linear (λ x → g x j)) → Linear (λ x → f (g x))
  map-zero (compose-linear {f = f} L G) = trans (cong f (ext0 (λ j → map-zero (G j)))) (map-zero L)
  map-add (compose-linear {f = f} L G) x y = trans (cong f (ext0 (λ j → map-add (G j) x y))) (map-add L _ _)
  map-scale (compose-linear {f = f} L G) r x = trans (cong f (ext0 (λ j → map-scale (G j) r x))) (map-scale L r _)

  right-output : {n : ℕ} {f : Tuple n → R} (r : R) → Linear f → Linear (λ x → f x * r)
  map-zero (right-output r L) = trans (cong (_* r) (map-zero L)) (*-zeroˡ r)
  map-add (right-output r L) x y = trans (cong (_* r) (map-add L x y)) (distribʳ _ _ r)
  map-scale (right-output r L) s x = trans (cong (_* r) (map-scale L s x)) (*-assoc s _ r)

  left-output : {n : ℕ} {f : Tuple n → R} (r : R) → Linear f → Linear (λ x → r * f x)
  map-zero (left-output r L) = trans (cong (r *_) (map-zero L)) (*-zeroʳ r)
  map-add (left-output r L) x y = trans (cong (r *_) (map-add L x y)) (distribˡ r _ _)
  map-scale (left-output r L) s x = trans (cong (r *_) (map-scale L s x)) (*-swap r s _)

  bilinear-ext : {n : ℕ} (f g : Tuple n → Tuple n → R) →
    ((y : Tuple n) → Linear (λ x → f x y)) → ((x : Tuple n) → Linear (f x)) →
    ((y : Tuple n) → Linear (λ x → g x y)) → ((x : Tuple n) → Linear (g x)) →
    ((i j : Fin n) → f (delta i) (delta j) ≡ g (delta i) (delta j)) →
    (x y : Tuple n) → f x y ≡ g x y
  bilinear-ext f g f₁ f₂ g₁ g₂ eq x y =
    linear-ext (f₁ y) (g₁ y) (λ i → linear-ext (f₂ (delta i)) (g₂ (delta i)) (eq i) y) x

  trilinear-ext : {n : ℕ} (f g : Tuple n → Tuple n → Tuple n → R) →
    ((y z : Tuple n) → Linear (λ x → f x y z)) →
    ((x z : Tuple n) → Linear (λ y → f x y z)) →
    ((x y : Tuple n) → Linear (f x y)) →
    ((y z : Tuple n) → Linear (λ x → g x y z)) →
    ((x z : Tuple n) → Linear (λ y → g x y z)) →
    ((x y : Tuple n) → Linear (g x y)) →
    ((i j k : Fin n) → f (delta i) (delta j) (delta k) ≡ g (delta i) (delta j) (delta k)) →
    (x y z : Tuple n) → f x y z ≡ g x y z
  trilinear-ext f g f₁ f₂ f₃ g₁ g₂ g₃ eq x y z =
    linear-ext (f₁ y z) (g₁ y z)
      (λ i → linear-ext (f₂ (delta i) z) (g₂ (delta i) z)
        (λ j → linear-ext (f₃ (delta i) (delta j)) (g₃ (delta i) (delta j)) (eq i j) z) y) x
