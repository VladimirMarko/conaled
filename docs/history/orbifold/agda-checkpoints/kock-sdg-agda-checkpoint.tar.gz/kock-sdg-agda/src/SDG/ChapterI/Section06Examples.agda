{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Examples where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section01Exercises as E1
import SDG.ChapterI.Section04 as S4

module Examples {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A

  -- Exercise I.6.1: (d,e) |-> (d,d*e) lands in D(2).
  liouvillePair : D → D → Jet1 (suc (suc zero))
  liouvillePair d e = makeJet1 (value d ∷ value d * value e ∷ []) pairs
    where
    cross : value d * (value d * value e) ≡ 0r
    cross = trans (sym (*-assoc (value d) (value d) (value e)))
      (trans (cong (_* value e) (square-zero d)) (*-zeroˡ (value e)))

    pairs : (i j : Fin (suc (suc zero))) →
      lookup (value d ∷ value d * value e ∷ []) i *
      lookup (value d ∷ value d * value e ∷ []) j ≡ 0r
    pairs fzero fzero = square-zero d
    pairs fzero (fsuc fzero) = cross
    pairs (fsuc fzero) fzero = trans (*-comm (value d * value e) (value d)) cross
    pairs (fsuc fzero) (fsuc fzero) = square-zero-scaled (value d) (value e) (square-zero d)

  liouville : D → D → D
  liouville d e = sumJet (liouvillePair d e)

  liouville-formula : (d e : D) → value (liouville d e) ≡ value d + value d * value e
  liouville-formula d e = cong (value d +_) (+-identityʳ (value d * value e))

  -- Exercise I.6.2: the stated preimage characterization is represented
  -- by two maps between its defining predicates.
  pairFromProductZero : (d e : D) → value d * value e ≡ 0r → Jet1 (suc (suc zero))
  pairFromProductZero d e cross = makeJet1 (value d ∷ value e ∷ [])
    (λ { fzero fzero → square-zero d
       ; fzero (fsuc fzero) → cross
       ; (fsuc fzero) fzero → trans (*-comm (value e) (value d)) cross
       ; (fsuc fzero) (fsuc fzero) → square-zero e })

  sum-in-D-iff-cross-zero : (H : E1.Algebraic.TwoInvertible A) (d e : D) →
    (((value d + value e) * (value d + value e) ≡ 0r) → value d * value e ≡ 0r) ×
    ((value d * value e ≡ 0r) → (value d + value e) * (value d + value e) ≡ 0r)
  sum-in-D-iff-cross-zero H d e =
    E1.Algebraic.WithHalf.sum-square-zero-implies-product-zero A H d e ,
    E1.Algebraic.product-zero-implies-sum-square-zero A d e

  -- The special infinitesimal object displayed in equation (6.6).
  record Dc : Set ℓ where
    constructor dc
    field
      x y : R
      xy-zero : x * y ≡ 0r
      same-squares : x * x ≡ y * y
  open Dc public

  Dc-to-D2 : Dc → DJet (suc (suc zero)) (suc (suc zero))
  Dc-to-D2 p = jet (x p ∷ y p ∷ []) (λ i j k →
    trans (cong (λ z → (z * lookup (x p ∷ y p ∷ []) j) * lookup (x p ∷ y p ∷ []) k)
      (*-identityˡ (lookup (x p ∷ y p ∷ []) i))) (triple i j k))
    where
    yx-zero : y p * x p ≡ 0r
    yx-zero = trans (*-comm (y p) (x p)) (xy-zero p)

    triple : (i j k : Fin (suc (suc zero))) →
      (lookup (x p ∷ y p ∷ []) i * lookup (x p ∷ y p ∷ []) j) *
      lookup (x p ∷ y p ∷ []) k ≡ 0r
    triple fzero fzero fzero =
      trans (cong (_* x p) (same-squares p))
        (trans (*-assoc (y p) (y p) (x p))
          (trans (cong (y p *_) yx-zero) (*-zeroʳ (y p))))
    triple fzero fzero (fsuc fzero) =
      trans (*-assoc (x p) (x p) (y p))
        (trans (cong (x p *_) (xy-zero p)) (*-zeroʳ (x p)))
    triple fzero (fsuc fzero) fzero = trans (cong (_* x p) (xy-zero p)) (*-zeroˡ (x p))
    triple fzero (fsuc fzero) (fsuc fzero) = trans (cong (_* y p) (xy-zero p)) (*-zeroˡ (y p))
    triple (fsuc fzero) fzero fzero = trans (cong (_* x p) yx-zero) (*-zeroˡ (x p))
    triple (fsuc fzero) fzero (fsuc fzero) = trans (cong (_* y p) yx-zero) (*-zeroˡ (y p))
    triple (fsuc fzero) (fsuc fzero) fzero =
      trans (*-assoc (y p) (y p) (x p))
        (trans (cong (y p *_) yx-zero) (*-zeroʳ (y p)))
    triple (fsuc fzero) (fsuc fzero) (fsuc fzero) =
      trans (cong (_* y p) (sym (same-squares p)))
        (trans (*-assoc (x p) (x p) (y p))
          (trans (cong (x p *_) (xy-zero p)) (*-zeroʳ (x p))))

module NontrivialLiouville {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open Examples A
  open S4.Results A K using (universal-products-nonzero)

  liouville-is-not-projection : 0r ≢ 1r →
    ((d e : D) → value (liouville d e) ≡ value d) → ⊥
  liouville-is-not-projection nontrivial projection = universal-products-nonzero nontrivial
    (λ d e → +-cancelˡ (value d)
      (trans (sym (liouville-formula d e))
        (trans (projection d e) (sym (+-identityʳ (value d))))))
