{-# OPTIONS --safe --without-K #-}

-- Exercise I.3.3 (Dubuc--Joyal): symmetric functions of independent
-- square-zero infinitesimals descend uniquely along their sum.
-- The proof integrates the first partial slope recursively, rather than
-- assuming a fundamental theorem about symmetric polynomials.
module SDG.ChapterI.Section03Symmetric where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; lookup; replicate; Permutation; to; permute;
   lookup-permute; liftPerm; permute-lift; swapFirst; permute-swapFirst)
import SDG.Combinatorics.FiniteSums as FS
import SDG.Calculus.Slope as SL
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as E3
import SDG.ChapterI.Section04 as S4

module SymmetricPolynomials {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open S3.HigherInfinitesimals A
  open PositiveNaturalsInvertible Q
  open Infinitesimals A
  open KockLawvere K
  open SL.Results A K using (slope-cong)
  open S4.Results A K using (Symmetric)
  open E3.SumMap A using (sumD; summation)
  module FiniteSum = FS.Sums A

  sumD-finite : {n : ℕ} (ds : Vec D n) →
    sumD ds ≡ FiniteSum.sum (λ i → value (lookup ds i))
  sumD-finite [] = refl
  sumD-finite (d ∷ ds) = cong (value d +_) (sumD-finite ds)

  sumD-permute : {n : ℕ} (p : Permutation n) (ds : Vec D n) →
    sumD (permute p ds) ≡ sumD ds
  sumD-permute p ds =
    trans (sumD-finite (permute p ds))
      (trans (FiniteSum.sum-cong (λ i → cong value (lookup-permute p ds i)))
        (trans (FiniteSum.sum-permute p (λ i → value (lookup ds i)))
          (sym (sumD-finite ds))))

  sumD-zero : (n : ℕ) → sumD {n} (replicate zeroD) ≡ 0r
  sumD-zero zero = refl
  sumD-zero (suc n) = trans (cong (0r +_) (sumD-zero n)) (+-identityˡ 0r)

  restrict-symmetric : {n : ℕ} (f : Vec D (suc n) → R) → Symmetric f →
    (d : D) → Symmetric (λ ds → f (d ∷ ds))
  restrict-symmetric f symmetric d p ds =
    trans (cong f (sym (permute-lift p d ds))) (symmetric (liftPerm p) (d ∷ ds))

  first-slope : {n : ℕ} → (Vec D (suc n) → R) → Vec D n → R
  first-slope f ds = slope (λ d → f (d ∷ ds))

  first-slope-symmetric : {n : ℕ} (f : Vec D (suc n) → R) →
    Symmetric f → Symmetric (first-slope f)
  first-slope-symmetric f symmetric p ds =
    slope-cong (λ d → f (d ∷ permute p ds)) (λ d → f (d ∷ ds))
      (λ d → restrict-symmetric f symmetric d p ds)

  swap-law : {n : ℕ} (f : Vec D (suc (suc n)) → R) → Symmetric f →
    (d e : D) (ds : Vec D n) → f (d ∷ e ∷ ds) ≡ f (e ∷ d ∷ ds)
  swap-law f symmetric d e ds =
    trans (sym (symmetric swapFirst (d ∷ e ∷ ds)))
      (cong f (permute-swapFirst d e ds))

  -- A symmetric map is determined by its value at zero and its first
  -- partial slope; permutation symmetry supplies all the other slopes.
  symmetric-determined : {n : ℕ} (f g : Vec D (suc n) → R) →
    Symmetric f → Symmetric g →
    f (replicate zeroD) ≡ g (replicate zeroD) →
    ((ds : Vec D n) → first-slope f ds ≡ first-slope g ds) →
    (ds : Vec D (suc n)) → f ds ≡ g ds
  symmetric-determined {zero} f g sf sg base slopes (d ∷ []) =
    trans (expansion (λ e → f (e ∷ [])) d)
      (trans (cong₂ _+_ base (cong (value d *_) (slopes [])))
        (sym (expansion (λ e → g (e ∷ [])) d)))
  symmetric-determined {suc n} f g sf sg base slopes (d ∷ ds) =
    trans (expansion (λ e → f (e ∷ ds)) d)
      (trans (cong₂ _+_ (lower ds) (cong (value d *_) (slopes ds)))
        (sym (expansion (λ e → g (e ∷ ds)) d)))
    where
    lower-slopes : (es : Vec D n) →
      slope (λ e → f (zeroD ∷ e ∷ es)) ≡ slope (λ e → g (zeroD ∷ e ∷ es))
    lower-slopes es =
      trans (slope-cong (λ e → f (zeroD ∷ e ∷ es)) (λ e → f (e ∷ zeroD ∷ es))
        (λ e → swap-law f sf zeroD e es))
        (trans (slopes (zeroD ∷ es))
          (sym (slope-cong (λ e → g (zeroD ∷ e ∷ es)) (λ e → g (e ∷ zeroD ∷ es))
            (λ e → swap-law g sg zeroD e es))))

    lower : (es : Vec D (suc n)) → f (zeroD ∷ es) ≡ g (zeroD ∷ es)
    lower = symmetric-determined (λ es → f (zeroD ∷ es)) (λ es → g (zeroD ∷ es))
      (restrict-symmetric f sf zeroD) (restrict-symmetric g sg zeroD) base lower-slopes

  integrateWeights : {n : ℕ} → ℕ → Vec R n → Vec R n
  integrateWeights j [] = []
  integrateWeights j (a ∷ as) = (reciprocal j * a) ∷ integrateWeights (suc j) as

  weight-integral : {n : ℕ} (j : ℕ) (as : Vec R n) →
    weightFrom (suc j) (integrateWeights j as) ≡ as
  weight-integral j [] = refl
  weight-integral j (a ∷ as) = cong₂ _∷_
    (trans (sym (*-assoc (fromℕ (suc j)) (reciprocal j) a))
      (trans (cong (_* a) (reciprocal-law j)) (*-identityˡ a)))
    (weight-integral (suc j) as)

  differentiate-integral : {n : ℕ} (a : R) (as : Vec R (suc n)) →
    differentiate (a ∷ integrateWeights zero as) ≡ as
  differentiate-integral a as = weight-integral zero as

  polynomial-symmetric : {n : ℕ} (as : Vec R (suc n)) →
    Symmetric (λ (ds : Vec D n) → eval as (sumD ds))
  polynomial-symmetric as p ds = cong (eval as) (sumD-permute p ds)

  polynomial-first-slope : {n : ℕ} (as : Vec R (suc (suc n))) (ds : Vec D n) →
    first-slope (λ es → eval as (sumD es)) ds ≡ eval (differentiate as) (sumD ds)
  polynomial-first-slope as ds =
    uniqueness (λ d → eval as (value d + sumD ds)) (eval (differentiate as) (sumD ds))
      (λ d → trans (cong (eval as) (+-comm (value d) (sumD ds)))
        (trans (polynomial-first-order as (sumD ds) d)
          (cong (_+ (value d * eval (differentiate as) (sumD ds)))
            (sym (cong (eval as) (+-identityˡ (sumD ds)))))))

  Representation : {n : ℕ} → (Vec D n → R) → Set ℓ
  Representation {n} f = Σ (Vec R (suc n))
    (λ as → (ds : Vec D n) → f ds ≡ eval as (sumD ds))

  representation : {n : ℕ} (f : Vec D n → R) → Symmetric f → Representation f
  representation {zero} f symmetric = (f [] ∷ []) , (λ { [] → sym (eval-constant (f []) 0r) })
  representation {suc n} f symmetric = as , correct
    where
    lower : Representation (first-slope f)
    lower = representation (first-slope f) (first-slope-symmetric f symmetric)

    as : Vec R (suc (suc n))
    as = f (replicate zeroD) ∷ integrateWeights zero (fst lower)

    base : f (replicate zeroD) ≡ eval as (sumD {suc n} (replicate zeroD))
    base = sym (trans (cong (eval as) (sumD-zero (suc n))) (eval-zero as))

    slopes : (ds : Vec D n) → first-slope f ds ≡ first-slope (λ es → eval as (sumD es)) ds
    slopes ds = trans (snd lower ds)
      (sym (trans (polynomial-first-slope as ds)
        (cong (λ bs → eval bs (sumD ds)) (differentiate-integral (f (replicate zeroD)) (fst lower)))))

    correct : (ds : Vec D (suc n)) → f ds ≡ eval as (sumD ds)
    correct = symmetric-determined f (λ ds → eval as (sumD ds)) symmetric
      (polynomial-symmetric as) base slopes

-- Existence and uniqueness for the actual addition map D^n -> D_n.
-- Positive n matches the quantified higher-order KL axiom. No truncation,
-- excluded middle, function extensionality, or proof irrelevance is needed.
module Descent {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  private
    K : KockLawvere
    K = S3.FirstOrderFromHigher.firstOrder A H
  open S4.Results A K using (Symmetric; SymmetricDescent)
  open E3.SumMap A using (sumD; summation)
  open E3.Detection A H Q using (scalar-functions-agree; nilpotent-value-cong)
  open SymmetricPolynomials A K Q

  extension : {n : ℕ} (f : Vec D n → R) → Symmetric f → DK n → R
  extension f symmetric d = eval (fst (representation f symmetric)) (valueK d)

  factorization : {n : ℕ} (f : Vec D n → R) (symmetric : Symmetric f) →
    (ds : Vec D n) → f ds ≡ extension f symmetric (summation ds)
  factorization f symmetric = snd (representation f symmetric)

  extension-unique : (n : ℕ) (f : Vec D (suc n) → R) (symmetric : Symmetric f) →
    (t : DK (suc n) → R) → ((ds : Vec D (suc n)) → f ds ≡ t (summation ds)) →
    (d : DK (suc n)) → t d ≡ extension f symmetric d
  extension-unique n f symmetric t p =
    scalar-functions-agree n t (extension f symmetric)
      (λ ds → trans (sym (p ds)) (factorization f symmetric ds))

  factorization-implies-symmetric : (n : ℕ) (f : Vec D (suc n) → R) →
    (t : DK (suc n) → R) → ((ds : Vec D (suc n)) → f ds ≡ t (summation ds)) → Symmetric f
  factorization-implies-symmetric n f t p perm ds =
    trans (p (permute perm ds))
      (trans (nilpotent-value-cong n t (sumD-permute perm ds)) (sym (p ds)))

  symmetric-iff-factorization : (n : ℕ) (f : Vec D (suc n) → R) →
    (Symmetric f → Σ (DK (suc n) → R)
      (λ t → (ds : Vec D (suc n)) → f ds ≡ t (summation ds))) ×
    ((Σ (DK (suc n) → R)
      (λ t → (ds : Vec D (suc n)) → f ds ≡ t (summation ds))) → Symmetric f)
  symmetric-iff-factorization n f =
    (λ symmetric → extension f symmetric , factorization f symmetric) ,
    (λ { (t , p) → factorization-implies-symmetric n f t p })

  -- The scalar instance requested by Exercise I.4.4. Its stability under
  -- equalizers is proved separately in Section04.SymmetricEqualizers.
  scalar-symmetric-descent : (n : ℕ) → SymmetricDescent (DK (suc n)) summation R
  SymmetricDescent.descend (scalar-symmetric-descent n) = extension
  SymmetricDescent.factor (scalar-symmetric-descent n) = factorization
  SymmetricDescent.unique (scalar-symmetric-descent n) = extension-unique n
