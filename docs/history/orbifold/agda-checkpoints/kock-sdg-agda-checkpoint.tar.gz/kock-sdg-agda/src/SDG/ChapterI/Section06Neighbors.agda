{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Neighbors where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; replicate; lookup-replicate;
   map; lookup-map; zipWith; lookup-zipWith; vec-ext; _+ℕ_)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.JetAlgebra
open import SDG.Infinitesimal.Polynomial
import SDG.ChapterI.Section03 as S3
import SDG.Algebra.Nilradical as NR

module Relations {ℓ : Level} (A : CRing ℓ) where
  open S3.HigherInfinitesimals A
  open Jets A
  open JetAlgebra A

  difference : {n : ℕ} → Vec R n → Vec R n → Vec R n
  difference = zipWith _-_

  Neighbor : {n : ℕ} → ℕ → Vec R n → Vec R n → Set ℓ
  Neighbor k xs ys = ProductsZero (difference xs ys) (suc k) 1r

  difference-self : {n : ℕ} (xs : Vec R n) → difference xs xs ≡ replicate 0r
  difference-self xs = vec-ext (λ i →
    trans (lookup-zipWith _-_ xs xs i)
      (trans (+-inverseʳ (lookup xs i)) (sym (lookup-replicate 0r i))))

  neighbor-refl : {n : ℕ} (k : ℕ) (xs : Vec R n) → Neighbor k xs xs
  neighbor-refl {n} k xs = subst (λ zs → ProductsZero zs (suc k) 1r)
    (sym (difference-self xs)) (vanish (zeroJet k n))

  neg-difference : (x y : R) → (- (x - y)) ≡ y - x
  neg-difference x y = trans (neg-add x (- y))
    (trans (cong ((- x) +_) (neg-involutive y)) (+-comm (- x) y))

  difference-reverse : {n : ℕ} (xs ys : Vec R n) →
    map -_ (difference xs ys) ≡ difference ys xs
  difference-reverse xs ys = vec-ext (λ i →
    trans (lookup-map -_ (difference xs ys) i)
      (trans (cong -_ (lookup-zipWith _-_ xs ys i))
        (trans (neg-difference (lookup xs i) (lookup ys i))
          (sym (lookup-zipWith _-_ ys xs i)))))

  neighbor-sym : {n : ℕ} (k : ℕ) (xs ys : Vec R n) → Neighbor k xs ys → Neighbor k ys xs
  neighbor-sym k xs ys p = subst (λ zs → ProductsZero zs (suc k) 1r)
    (difference-reverse xs ys) (vanish (negateJet (jet (difference xs ys) p)))

  difference-chain : (x y z : R) → (x - y) + (y - z) ≡ x - z
  difference-chain x y z = trans (+-assoc x (- y) (y - z))
    (cong (x +_) (+-inverse-cancelˡ y (- z)))

  differences-compose : {n : ℕ} (xs ys zs : Vec R n) →
    zipWith _+_ (difference xs ys) (difference ys zs) ≡ difference xs zs
  differences-compose xs ys zs = vec-ext (λ i →
    trans (lookup-zipWith _+_ (difference xs ys) (difference ys zs) i)
      (trans (cong₂ _+_ (lookup-zipWith _-_ xs ys i) (lookup-zipWith _-_ ys zs i))
        (trans (difference-chain (lookup xs i) (lookup ys i) (lookup zs i))
          (sym (lookup-zipWith _-_ xs zs i)))))

  neighbor-compose : {n : ℕ} (k l : ℕ) (xs ys zs : Vec R n) →
    Neighbor k xs ys → Neighbor l ys zs → Neighbor (k +ℕ l) xs zs
  neighbor-compose k l xs ys zs p q = subst (λ ws → ProductsZero ws (suc (k +ℕ l)) 1r)
    (differences-compose xs ys zs)
    (vanish (addJets (jet (difference xs ys) p) (jet (difference ys zs) q)))

  Neighbor∞ : {n : ℕ} → Vec R n → Vec R n → Set ℓ
  Neighbor∞ xs ys = Σ ℕ (λ k → Neighbor k xs ys)

  infinity-refl : {n : ℕ} (xs : Vec R n) → Neighbor∞ xs xs
  infinity-refl xs = zero , neighbor-refl zero xs

  infinity-sym : {n : ℕ} (xs ys : Vec R n) → Neighbor∞ xs ys → Neighbor∞ ys xs
  infinity-sym xs ys (k , p) = k , neighbor-sym k xs ys p

  infinity-trans : {n : ℕ} (xs ys zs : Vec R n) →
    Neighbor∞ xs ys → Neighbor∞ ys zs → Neighbor∞ xs zs
  infinity-trans xs ys zs (k , p) (l , q) = (k +ℕ l) , neighbor-compose k l xs ys zs p q

  SomeJet : {n : ℕ} → Vec R n → Set ℓ
  SomeJet xs = Σ ℕ (λ k → ProductsZero xs (suc k) 1r)

  jets-to-coordinate-nilpotents : {n : ℕ} (xs : Vec R n) → SomeJet xs → NR.Results.NilpotentVector A xs
  jets-to-coordinate-nilpotents xs (k , p) i = k , nilpotence (coordinateK (jet xs p) i)

  coordinate-nilpotents-to-jet : {n : ℕ} (xs : Vec R n) → NR.Results.NilpotentVector A xs → SomeJet xs
  coordinate-nilpotents-to-jet [] p = zero , vanish (zeroJet zero zero)
  coordinate-nilpotents-to-jet (x ∷ xs) p with p fzero | coordinate-nilpotents-to-jet xs (λ i → p (fsuc i))
  ... | (k , px) | (l , ps) = (k +ℕ l) , vanish
    (concatenate (singletonK (nilpotent x px)) (jet xs ps))

  -- Finite products commute with the increasing union: from a separately
  -- witnessed bound for each coordinate, this constructs one common bound.
  -- No choice principle or proposition truncation is used for finite Vec.
  UniformCoordinateNilpotence : {n : ℕ} → Vec R n → Set ℓ
  UniformCoordinateNilpotence {n} xs =
    Σ ℕ (λ k → (i : Fin n) → lookup xs i ^ suc k ≡ 0r)

  coordinate-nilpotents-to-uniform : {n : ℕ} (xs : Vec R n) →
    NR.Results.NilpotentVector A xs → UniformCoordinateNilpotence xs
  coordinate-nilpotents-to-uniform xs p with coordinate-nilpotents-to-jet xs p
  ... | k , q = k , λ i → nilpotence (coordinateK (jet xs q) i)

  uniform-to-coordinate-nilpotents : {n : ℕ} (xs : Vec R n) →
    UniformCoordinateNilpotence xs → NR.Results.NilpotentVector A xs
  uniform-to-coordinate-nilpotents xs (k , p) i = k , p i

  -- A monad is presented by the difference x-y, as in the text.
  monadPoint : {n : ℕ} (k : ℕ) (x : Vec R n) → Set ℓ
  monadPoint k x = Σ (Vec R _) (Neighbor k x)

  translate : {k n : ℕ} → Vec R n → DJet k n → Vec R n
  translate xs d = difference xs (coords d)

  subtract-twice : (x y : R) → x - (x - y) ≡ y
  subtract-twice x y =
    trans (cong (x +_) (neg-difference x y))
      (trans (cong (x +_) (+-comm y (- x)))
        (trans (sym (+-assoc x (- x) y))
          (trans (cong (_+ y) (+-inverseʳ x)) (+-identityˡ y))))

  translate-recover : {n : ℕ} (xs ys : Vec R n) → difference xs (difference xs ys) ≡ ys
  translate-recover xs ys = vec-ext (λ i →
    trans (lookup-zipWith _-_ xs (difference xs ys) i)
      (trans (cong (λ z → lookup xs i - z) (lookup-zipWith _-_ xs ys i))
        (subtract-twice (lookup xs i) (lookup ys i))))

  translate-zero : {n : ℕ} (k : ℕ) (xs : Vec R n) → translate xs (zeroJet k n) ≡ xs
  translate-zero k xs = vec-ext (λ i →
    trans (lookup-zipWith _-_ xs (replicate 0r) i)
      (trans (cong (λ z → lookup xs i - z) (lookup-replicate 0r i))
        (trans (cong (lookup xs i +_) neg-zero) (+-identityʳ (lookup xs i)))))

  translated-neighbor : {k n : ℕ} (xs : Vec R n) (d : DJet k n) → Neighbor k xs (translate xs d)
  translated-neighbor {k} xs d = subst (λ ys → ProductsZero ys (suc k) 1r)
    (sym (translate-recover xs (coords d))) (vanish d)

  as-monad : {k n : ℕ} (xs : Vec R n) → DJet k n → monadPoint k xs
  as-monad xs d = translate xs d , translated-neighbor xs d

module Preservation {ℓ : Level} (A : CRing ℓ)
  (T : Polynomials.TotalKockLawvere A) where
  open S3.HigherInfinitesimals A
  open Jets A
  open Polynomials A
  open TotalConsequences T
  open Relations A

  -- Intrinsic Corollary I.6.5: every map defined on a k-monad has image
  -- inside the k-monad of its base value. This is already a local theorem.
  monad-preservation : (k n : ℕ) {m : ℕ}
    (f : DJet (suc k) (suc n) → Vec R m) (d : DJet (suc k) (suc n)) →
    Neighbor (suc k) (f (zeroJet (suc k) (suc n))) (f d)
  monad-preservation k n f d = vanish (zero-map k n
    (λ e → difference (f (zeroJet (suc k) (suc n))) (f e))
    (difference-self (f (zeroJet (suc k) (suc n)))) d)

  preserve-neighbors : (k n : ℕ) {m : ℕ} (f : Vec R (suc n) → Vec R m)
    (xs ys : Vec R (suc n)) → Neighbor (suc k) xs ys → Neighbor (suc k) (f xs) (f ys)
  preserve-neighbors k n f xs ys p =
    subst (λ pair → Neighbor (suc k) (fst pair) (snd pair))
      (cong₂ _,_ (cong f (translate-zero (suc k) xs)) (cong f (translate-recover xs ys)))
      (monad-preservation k n (λ d → f (translate xs d)) (jet (difference xs ys) p))
