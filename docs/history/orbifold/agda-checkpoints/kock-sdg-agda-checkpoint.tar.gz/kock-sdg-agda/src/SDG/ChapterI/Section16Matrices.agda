{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16Matrices where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Fin; tabulate; lookup-tabulate; lookup-zipWith)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section01Exercises as E1
import SDG.ChapterI.Section06Neighbors as Neighbors

module Matrices {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Jets A
  open Neighbors.Relations A using (Neighbor; difference)

  Matrix : ℕ → ℕ → Set ℓ
  Matrix p n = Fin p → Fin n → R

  AlternatingRelations : {p n : ℕ} → Matrix p n → Set ℓ
  AlternatingRelations {p} {n} a = (i l : Fin p) (j k : Fin n) →
    a i j * a l k + a i k * a l j ≡ 0r

  -- The literal polynomial equations defining the spectrum of W(p,n).
  record Dtilde (p n : ℕ) : Set ℓ where
    constructor alternating-matrix
    field
      entries : Matrix p n
      relations : AlternatingRelations entries
  open Dtilde public

  row-square-zero : {p n : ℕ} (half : E1.Algebraic.TwoInvertible A) (a : Dtilde p n)
    (i : Fin p) (j k : Fin n) → entries a i j * entries a i k ≡ 0r
  row-square-zero half a i j k = E1.Algebraic.WithHalf.cancel-two-zero A half _
    (trans (double-mul (entries a i j * entries a i k))
      (trans (cong ((entries a i j * entries a i k) +_) (*-comm (entries a i j) (entries a i k)))
        (relations a i i j k)))

  row : {p n : ℕ} → E1.Algebraic.TwoInvertible A → Dtilde p n → Fin p → Jet1 n
  row half a i = makeJet1 (tabulate (entries a i)) (λ j k →
    trans (cong₂ _*_ (lookup-tabulate (entries a i) j) (lookup-tabulate (entries a i) k))
      (row-square-zero half a i j k))

  difference-product : (a b c d : R) → a * c ≡ 0r → b * d ≡ 0r →
    (a - b) * (c - d) ≡ - (a * d + c * b)
  difference-product a b c d ac bd =
    trans (expand-product a (- b) c (- d))
      (trans (cong₂ _+_
        (trans (cong₂ _+_ ac (neg-mulʳ a d)) (+-identityˡ (- (a * d))))
        (trans (cong₂ _+_
          (trans (neg-mulˡ b c) (cong -_ (*-comm b c))) (trans (neg-mul-neg b d) bd))
          (+-identityʳ (- (c * b)))))
        (sym (neg-add (a * d) (c * b))))

  difference-cross : {n : ℕ} (d e : Jet1 n) (j k : Fin n) →
    (coordinate d j - coordinate e j) * (coordinate d k - coordinate e k) ≡
      - (coordinate d j * coordinate e k + coordinate d k * coordinate e j)
  difference-cross d e j k = difference-product (coordinate d j) (coordinate e j)
    (coordinate d k) (coordinate e k) (pair-zero d j k) (pair-zero e j k)

  cross-to-neighbor : {n : ℕ} (d e : Jet1 n) →
    ((j k : Fin n) → coordinate d j * coordinate e k + coordinate d k * coordinate e j ≡ 0r) →
    Neighbor (suc zero) (coords d) (coords e)
  cross-to-neighbor d e cross j k =
    trans (cong₂ _*_
      (trans (*-identityˡ _) (lookup-zipWith _-_ (coords d) (coords e) j))
      (lookup-zipWith _-_ (coords d) (coords e) k))
      (trans (difference-cross d e j k) (trans (cong -_ (cross j k)) neg-zero))

  neighbor-to-cross : {n : ℕ} (d e : Jet1 n) → Neighbor (suc zero) (coords d) (coords e) →
    (j k : Fin n) → coordinate d j * coordinate e k + coordinate d k * coordinate e j ≡ 0r
  neighbor-to-cross d e neighboring j k = trans (sym (neg-involutive _))
    (trans (cong -_ (trans (sym (difference-cross d e j k))
      (trans (sym (cong₂ _*_
        (trans (*-identityˡ _) (lookup-zipWith _-_ (coords d) (coords e) j))
        (lookup-zipWith _-_ (coords d) (coords e) k))) (neighboring j k)))) neg-zero)

  -- Proposition 16.5 for every finite number of rows and columns. The
  -- rows are already in D(n), exactly as assumed in the proposition;
  -- no invertibility of 2 is needed for this equivalence itself.
  proposition16-5 : {p n : ℕ} (ds : Fin p → Jet1 n) →
    (AlternatingRelations (λ i j → coordinate (ds i) j) →
      (i l : Fin p) → Neighbor (suc zero) (coords (ds i)) (coords (ds l))) ×
    (((i l : Fin p) → Neighbor (suc zero) (coords (ds i)) (coords (ds l))) →
      AlternatingRelations (λ i j → coordinate (ds i) j))
  proposition16-5 ds = (λ cross i l → cross-to-neighbor (ds i) (ds l) (cross i l)) ,
    (λ neighboring i l → neighbor-to-cross (ds i) (ds l) (neighboring i l))
