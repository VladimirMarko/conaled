{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section09LieLawsInvariant where

open import SDG.Prelude
open import SDG.Setness using (function-isSet)
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Group using (Group)
open import SDG.Algebra.Endomorphisms using (LieAlgebra)
import SDG.Algebra.LiePullback as Pullback
open import SDG.Axiom
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section06Closure as C6
import SDG.ChapterI.Section06PropertyClosures as P6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section09Invariant as I9
import SDG.ChapterI.Section09LieLaws as Base
import SDG.ChapterI.Section09LieLawsProofs as L9

groupMonoid : {ℓ : Level} {G : Set ℓ} → Group G → I9.Monoid G
groupMonoid H = record
  { unit = Group.unit H; _·_ = Group._·_ H; assoc = Group.assoc H
  ; identityˡ = Group.identityˡ H; identityʳ = Group.identityʳ H }

-- Exercises I.9.2 and I.9.3, simultaneously generalized to monoids (I.9.4).
module Invariants {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (G : Set ℓ) (setG : isSet G) (Gmon : I9.Monoid G)
  (IL : S6.Linear.InfinitesimallyLinear A G) (W : S4.Results.PropertyW A K G)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A) where
  open RingLemmas A
  open Infinitesimals A
  open I9.Monoid Gmon
  open S7.Basics A setR
  open S8.Basics A setR
  open S8M.Fields A setR ext0 ext G setG IL
  open S9.Lie A K setR IL W using (bracket)
  open I9.Invariant A K setR Gmon IL W
  module T = S7L.Construction A setR ext0 G IL
  module Laws = L9.Laws A K setR ext0 ext G setG IL W
  open Base.Geometry A K setR ext0 ext G setG IL W using (run-add; bracket-agrees)

  abstract
    invariant-add : (X Y : VectorField G) → LeftInvariant X → LeftInvariant Y → LeftInvariant (field-add X Y)
    invariant-add X Y px py a b d =
      trans (cong (a ·_) (run-add X Y b d))
        (trans (py a (run X b d) d)
          (trans (cong (λ g → run Y g d) (px a b d)) (sym (run-add X Y (a · b) d))))

    invariant-prop : (X : VectorField G) → isProp (LeftInvariant X)
    invariant-prop X p q = ext (λ a → ext (λ b → ext (λ d → setG _ _ (p a b d) (q a b d))))

  InvariantField : Set ℓ
  InvariantField = Σ (VectorField G) LeftInvariant

  invariant-path : {X Y : InvariantField} → fst X ≡ fst Y → X ≡ Y
  invariant-path {X , p} {.X , q} refl = cong (X ,_) (invariant-prop X p q)

  invariantZero : InvariantField
  invariantZero = zero-field , invariant-zero

  invariantAdd : InvariantField → InvariantField → InvariantField
  invariantAdd (X , p) (Y , q) = field-add X Y , invariant-add X Y p q

  invariantScale : R → InvariantField → InvariantField
  invariantScale r (X , p) = scale-field (λ _ → r) X , invariant-scale r X p

  invariantNeg : InvariantField → InvariantField
  invariantNeg = invariantScale (- 1r)

  invariantBracket : InvariantField → InvariantField → InvariantField
  invariantBracket (X , p) (Y , q) = bracket X Y , invariant-bracket X Y p q

  invariantModule : RModule A ℓ
  invariantModule = record
    { V = InvariantField; 0v = invariantZero; _+v_ = invariantAdd
    ; -v_ = invariantNeg; _•_ = invariantScale
    ; add-assoc = λ X Y Z → invariant-path (field-add-assoc (fst X) (fst Y) (fst Z))
    ; add-comm = λ X Y → invariant-path (field-add-comm (fst X) (fst Y))
    ; add-zeroˡ = λ X → invariant-path (field-add-zero (fst X))
    ; add-inverseˡ = λ X → invariant-path (field-add-inverse (fst X))
    ; scalar-one = λ X → invariant-path (field-scale-one (fst X))
    ; scalar-assoc = λ r s X → invariant-path (field-scale-assoc (λ _ → r) (λ _ → s) (fst X))
    ; scalar-add = λ r s X → invariant-path (field-scale-add (λ _ → r) (λ _ → s) (fst X))
    ; scalar-distrib = λ r X Y → invariant-path (field-scale-distrib (λ _ → r) (fst X) (fst Y))
    }

  module SubLie = Pullback.Pullback A invariantModule Laws.scalarFieldsModule
    (Laws.geometricLieAlgebra half half-law) invariantBracket fst refl
    (λ _ _ → refl) (λ _ _ → refl)
    (λ X Y → sym (bracket-agrees (fst X) (fst Y))) invariant-path

  invariantLieAlgebra : LieAlgebra A invariantModule
  invariantLieAlgebra = SubLie.lieAlgebra

  fromTangent : Tangent G unit → InvariantField
  fromTangent t = field-from-tangent t , tangent-field-invariant t

  toTangent : InvariantField → Tangent G unit
  toTangent (X , p) = tangent-at-unit X

  abstract
    tangent-invariant-roundtrip : (t : Tangent G unit) → toTangent (fromTangent t) ≡ t
    tangent-invariant-roundtrip = tangent-field-bijection-left ext setG

    invariant-tangent-roundtrip : (X : InvariantField) → fromTangent (toTangent X) ≡ X
    invariant-tangent-roundtrip (X , p) = invariant-path (field-ext ext setG (field-tangent-roundtrip X p))

    tangent-embedding-injective : {t u : Tangent G unit} → field-from-tangent t ≡ field-from-tangent u → t ≡ u
    tangent-embedding-injective {t} {u} p =
      trans (sym (tangent-field-bijection-left ext setG t))
        (trans (cong tangent-at-unit p) (tangent-field-bijection-left ext setG u))

    tangent-zero-preserved : field-from-tangent (zero-tangent unit) ≡ zero-field
    tangent-zero-preserved = field-ext ext setG (λ g d → identityʳ g)

    tangent-scale-preserved : (r : R) (t : Tangent G unit) →
      field-from-tangent (speed r t) ≡ scale-field (λ _ → r) (field-from-tangent t)
    tangent-scale-preserved r t = field-ext ext setG (λ _ _ → refl)

    tangent-add-at-unit : (t u : Tangent G unit) →
      tangent-at-unit (field-add (field-from-tangent t) (field-from-tangent u)) ≡ T.add t u
    tangent-add-at-unit t u = tangent-ext ext setG (T.add-cong
      (tangent-at-unit (field-from-tangent t)) (tangent-at-unit (field-from-tangent u)) t u
      (tangent-field-roundtrip t) (tangent-field-roundtrip u))

    tangent-add-preserved : (t u : Tangent G unit) →
      field-from-tangent (T.add t u) ≡ field-add (field-from-tangent t) (field-from-tangent u)
    tangent-add-preserved t u =
      trans (cong field-from-tangent (sym (tangent-add-at-unit t u)))
        (field-ext ext setG (field-tangent-roundtrip
          (field-add (field-from-tangent t) (field-from-tangent u))
          (invariant-add (field-from-tangent t) (field-from-tangent u)
            (tangent-field-invariant t) (tangent-field-invariant u))))

    tangent-bracket-preserved : (t u : Tangent G unit) →
      field-from-tangent (bracket-at-unit t u) ≡ bracket (field-from-tangent t) (field-from-tangent u)
    tangent-bracket-preserved t u = field-ext ext setG (bracket-field-compatibility t u)

  module TangentLie = Pullback.Pullback A (T.fiberModule ext setG unit) Laws.scalarFieldsModule
    (Laws.geometricLieAlgebra half half-law) bracket-at-unit field-from-tangent
    tangent-zero-preserved tangent-add-preserved tangent-scale-preserved
    (λ t u → trans (tangent-bracket-preserved t u)
      (sym (bracket-agrees (field-from-tangent t) (field-from-tangent u)))) tangent-embedding-injective

  tangentLieAlgebra : LieAlgebra A (T.fiberModule ext setG unit)
  tangentLieAlgebra = TangentLie.lieAlgebra

  fromTangent-bracket : (t u : Tangent G unit) →
    fromTangent (bracket-at-unit t u) ≡ invariantBracket (fromTangent t) (fromTangent u)
  fromTangent-bracket t u = invariant-path (tangent-bracket-preserved t u)

-- The final assertion of Exercise I.9.4. Multiplication of transformations
-- is in traversal order (f · g = g ∘ f), the convention used by the
-- geometric commutator. With opposite multiplication one obtains the
-- opposite Lie algebra. The vector-field/tangent identification itself is
-- ordinary currying, with native inverse and structure-preservation laws.
module EndomorphismIdentification {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR
  open S8.Basics A setR
  open S8M.Fields A setR ext0 ext M setM IL
  open S9.Lie A K setR IL W using (bracket)
  open I9.Endomorphisms A setR ext M using (field-to-tangent; tangent-to-field)

  traversalMonoid : I9.Monoid (M → M)
  traversalMonoid = record
    { unit = id; _·_ = λ f g → g ∘ f
    ; assoc = λ _ _ _ → refl; identityˡ = λ _ → refl; identityʳ = λ _ → refl }

  endSet : isSet (M → M)
  endSet = function-isSet ext setM

  endIL : S6.Linear.InfinitesimallyLinear A (M → M)
  endIL = C6.Closure.function-linear A M ext IL

  endW : S4.Results.PropertyW A K (M → M)
  endW = P6.WClosure.function-W A K M ext W

  module EndInvariant = I9.Invariant A K setR traversalMonoid endIL endW
  module Inherited = Invariants A K setR ext0 ext (M → M) endSet traversalMonoid endIL endW half half-law
  module TE = S7L.Construction A setR ext0 (M → M) endIL
  module TM = S7L.Construction A setR ext0 M IL

  endomorphismTangentLie : LieAlgebra A (TE.fiberModule ext endSet id)
  endomorphismTangentLie = Inherited.tangentLieAlgebra

  abstract
    field-roundtrip : (X : VectorField M) → tangent-to-field (field-to-tangent X) ≡ X
    field-roundtrip X = field-ext ext setM (λ _ _ → refl)

    tangent-roundtrip : (t : Tangent (M → M) id) → field-to-tangent (tangent-to-field t) ≡ t
    tangent-roundtrip t = tangent-ext ext endSet (λ _ → ext (λ _ → refl))

    zero-preserved : field-to-tangent zero-field ≡ zero-tangent id
    zero-preserved = tangent-ext ext endSet (λ _ → ext (λ _ → refl))

    scale-preserved : (r : R) (X : VectorField M) →
      field-to-tangent (scale-field (λ _ → r) X) ≡ speed r (field-to-tangent X)
    scale-preserved r X = tangent-ext ext endSet (λ _ → ext (λ _ → refl))

    add-preserved : (X Y : VectorField M) →
      field-to-tangent (field-add X Y) ≡ TE.add (field-to-tangent X) (field-to-tangent Y)
    add-preserved X Y = tangent-ext ext endSet (λ d → ext (λ m → sym
      (trans (S7L.Naturality.addition-natural A setR ext0 (M → M) M endIL IL (λ f → f m)
        (field-to-tangent X) (field-to-tangent Y) d)
        (TM.add-cong
          (tangent-map (λ f → f m) (field-to-tangent X))
          (tangent-map (λ f → f m) (field-to-tangent Y))
          (field-section X m) (field-section Y m) (λ _ → refl) (λ _ → refl) d))))

    bracket-preserved : (X Y : VectorField M) →
      field-to-tangent (bracket X Y) ≡ EndInvariant.bracket-at-unit (field-to-tangent X) (field-to-tangent Y)
    bracket-preserved X Y = tangent-ext ext endSet (λ d → ext (λ m → sym
      (S9.Naturality.bracket-natural A K setR endIL endW IL W (λ f → f m)
        (EndInvariant.field-from-tangent (field-to-tangent X))
        (EndInvariant.field-from-tangent (field-to-tangent Y)) X Y
        (λ _ _ → refl) (λ _ _ → refl) id d)))
