{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section07Exercises where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section01 as S1
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as L7

-- Exercise I.7.1. The canonical twist is not the identity natural
-- transformation: its component on the line already acts nontrivially.
-- An individual component need not be nontrivial (take M to be terminal).
module TwistNontrivial {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (nontrivial : CRing.0r A ≢ CRing.1r A) where
  open RingLemmas A
  open Infinitesimals A
  open S1.Results A K
  open S7.Basics A setR

  first-coordinate : Bundle (Bundle R)
  first-coordinate d e = value d

  twist-moves-first-coordinate : twist first-coordinate ≢ first-coordinate
  twist-moves-first-coordinate p = nontrivial
    (cancel-infinitesimals 0r 1r (λ d →
      trans (*-zeroʳ (value d))
        (trans (cong (λ t → t d zeroD) p) (sym (*-identityʳ (value d))))))

  twist-not-identity : ¬ ((t : Bundle (Bundle R)) → twist t ≡ t)
  twist-not-identity p = twist-moves-first-coordinate (p first-coordinate)

-- Exercise I.7.2. The fiber product of two tangent bundles is represented
-- by pairs of based curves. Infinitesimal linearity identifies it with
-- maps from D(2), and the axes map is exactly restriction along D(2)⊆D².
module Restriction {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (M : Set ℓ)
  (IL : S6.Linear.InfinitesimallyLinear A M) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR
  open L7 using (twoN; i₀; i₁)
  open L7.Geometry A setR ext0
  module T = L7.Construction A setR ext0 M IL

  pair-ext : (ext : FunExt ℓ ℓ) → isSet M → {p q : TangentPair M} →
    base p ≡ base q →
    ((d : D) → curve (first p) d ≡ curve (first q) d) →
    ((d : D) → curve (second p) d ≡ curve (second q) d) → p ≡ q
  pair-ext ext setM {tangent-pair x t u} {tangent-pair .x v w} refl p q =
    cong₂ (tangent-pair x) (tangent-ext ext setM p) (tangent-ext ext setM q)

  jet-to-pair : (Jet1 twoN → M) → TangentPair M
  jet-to-pair f = tangent-pair (f (zeroJet (suc zero) twoN))
    (tangent (λ d → f (axis i₀ d)) (cong f (axis-zero setR ext0 i₀)))
    (tangent (λ d → f (axis i₁ d)) (cong f (axis-zero setR ext0 i₁)))

  pair-to-jet : TangentPair M → Jet1 twoN → M
  pair-to-jet p = T.extend (first p) (second p)

  jet-roundtrip : (f : Jet1 twoN → M) (p : Jet1 twoN) →
    pair-to-jet (jet-to-pair f) p ≡ f p
  jet-roundtrip f p = sym (T.extend-unique
    (first (jet-to-pair f)) (second (jet-to-pair f)) f
    (λ _ → refl) (λ _ → refl) p)

  pair-to-jet-origin : (p : TangentPair M) →
    pair-to-jet p (zeroJet (suc zero) twoN) ≡ base p
  pair-to-jet-origin p =
    trans (cong (pair-to-jet p) (sym (axis-zero setR ext0 i₀)))
      (trans (T.extend-axis₀ (first p) (second p) zeroD) (based (first p)))

  pair-roundtrip : (ext : FunExt ℓ ℓ) → isSet M → (p : TangentPair M) →
    jet-to-pair (pair-to-jet p) ≡ p
  pair-roundtrip ext setM p = pair-ext ext setM (pair-to-jet-origin p)
    (T.extend-axis₀ (first p) (second p)) (T.extend-axis₁ (first p) (second p))

  restrict : Bundle (Bundle M) → Jet1 twoN → M
  restrict t p = t (coordinateD p i₀) (coordinateD p i₁)

  restrict-origin : (t : Bundle (Bundle M)) →
    restrict t (zeroJet (suc zero) twoN) ≡ t zeroD zeroD
  restrict-origin t = cong₂ t (d-path refl) (d-path refl)

  restrict-axis₀ : (t : Bundle (Bundle M)) (d : D) → restrict t (axis i₀ d) ≡ t d zeroD
  restrict-axis₀ t d = cong₂ t
    (coordinate-axis-own i₀ d) (coordinate-axis-off i₀ i₁ (λ ()) d)

  restrict-axis₁ : (t : Bundle (Bundle M)) (d : D) → restrict t (axis i₁ d) ≡ t zeroD d
  restrict-axis₁ t d = cong₂ t
    (coordinate-axis-off i₁ i₀ (λ ()) d) (coordinate-axis-own i₁ d)

  restriction-is-axes : (t : Bundle (Bundle M)) (p : Jet1 twoN) →
    restrict t p ≡ pair-to-jet (axes t) p
  restriction-is-axes t = T.extend-unique (first (axes t)) (second (axes t))
    (restrict t) (restrict-axis₀ t) (restrict-axis₁ t)

  axes-is-restriction : (ext : FunExt ℓ ℓ) → isSet M → (t : Bundle (Bundle M)) →
    jet-to-pair (restrict t) ≡ axes t
  axes-is-restriction ext setM t = pair-ext ext setM
    (restrict-origin t) (restrict-axis₀ t) (restrict-axis₁ t)

  record AxesSection : Set ℓ where
    field
      complete : TangentPair M → Bundle (Bundle M)
      section : (p : TangentPair M) → axes (complete p) ≡ p

  record RestrictionSection : Set ℓ where
    field
      fill : (Jet1 twoN → M) → Bundle (Bundle M)
      section : (f : Jet1 twoN → M) (p : Jet1 twoN) → restrict (fill f) p ≡ f p

  axes-to-restriction : AxesSection → RestrictionSection
  RestrictionSection.fill (axes-to-restriction C) f = AxesSection.complete C (jet-to-pair f)
  RestrictionSection.section (axes-to-restriction C) f p =
    trans (restriction-is-axes (AxesSection.complete C (jet-to-pair f)) p)
      (trans (cong (λ q → pair-to-jet q p) (AxesSection.section C (jet-to-pair f)))
        (jet-roundtrip f p))

  restriction-to-axes : (ext : FunExt ℓ ℓ) → isSet M → RestrictionSection → AxesSection
  AxesSection.complete (restriction-to-axes ext setM C) p = RestrictionSection.fill C (pair-to-jet p)
  AxesSection.section (restriction-to-axes ext setM C) p =
    trans (sym (axes-is-restriction ext setM (RestrictionSection.fill C (pair-to-jet p))))
      (trans (cong jet-to-pair (ext (RestrictionSection.section C (pair-to-jet p))))
        (pair-roundtrip ext setM p))

  axes-sections-roundtrip : (ext : FunExt ℓ ℓ) (setM : isSet M)
    (C : AxesSection) (p : TangentPair M) →
    AxesSection.complete (restriction-to-axes ext setM (axes-to-restriction C)) p ≡
    AxesSection.complete C p
  axes-sections-roundtrip ext setM C p =
    cong (AxesSection.complete C) (pair-roundtrip ext setM p)

  restriction-sections-roundtrip : (ext : FunExt ℓ ℓ) (setM : isSet M)
    (C : RestrictionSection) (f : Jet1 twoN → M) →
    RestrictionSection.fill (axes-to-restriction (restriction-to-axes ext setM C)) f ≡
    RestrictionSection.fill C f
  restriction-sections-roundtrip ext setM C f =
    cong (RestrictionSection.fill C) (ext (jet-roundtrip f))

-- Restriction commutes with arbitrary maps of ambient spaces. This agrees
-- with the already proved naturality of the axes map in Section07.
module RestrictionNaturality {ℓ : Level} (A : CRing ℓ)
  (setR : isSet (CRing.R A)) where
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR
  open L7 using (twoN; i₀; i₁)

  restrict-natural : {M N : Set ℓ} (f : M → N)
    (t : Bundle (Bundle M)) (p : Jet1 twoN) →
    bundle-map (bundle-map f) t (coordinateD p i₀) (coordinateD p i₁) ≡
    f (t (coordinateD p i₀) (coordinateD p i₁))
  restrict-natural f t p = refl
