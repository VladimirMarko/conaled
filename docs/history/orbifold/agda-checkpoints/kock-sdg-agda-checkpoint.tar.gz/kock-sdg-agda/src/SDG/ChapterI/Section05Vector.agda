{-# OPTIONS --safe --without-K #-}

-- Kock I.5, Exercises 5.3 and 5.4: module-valued KL and calculus.
module SDG.ChapterI.Section05Vector where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Powers
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; head; tail; map; zipWith;
  Fin; fzero; fsuc; finToNat; lookup; tabulate; replicate; vec-ext;
  lookup-tabulate; lookup-map; lookup-zipWith; lookup-replicate;
  nat-add-zeroʳ; nat-add-sucʳ; tabulate-cong)
import SDG.ChapterI.Section03 as S3

module VectorInfinitesimals {a v : Level} (A : CRing a) (M : RModule A v) where
  open ModuleLemmas A M public
  open S3.HigherInfinitesimals A using (DK; valueK)
  open Infinitesimals A using (D; zeroD; value)

  evalV : {n : ℕ} → Vec V n → R → V
  evalV [] x = 0v
  evalV (a ∷ as) x = a +v x • evalV as x

  evalV-zero : {n : ℕ} (as : Vec V (suc n)) → evalV as 0r ≡ head as
  evalV-zero (a ∷ as) =
    trans (cong (a +v_) (zero-scalar (evalV as 0r))) (add-zeroʳ a)

  evalV-constant : (a : V) (x : R) → evalV (a ∷ []) x ≡ a
  evalV-constant a x = trans (cong (a +v_) (scalar-zero x)) (add-zeroʳ a)

  evalV-linear : (a b : V) (x : R) → evalV (a ∷ b ∷ []) x ≡ a +v x • b
  evalV-linear a b x = cong (λ z → a +v x • z) (evalV-constant b x)

  evalV-cong : {n : ℕ} {as bs : Vec V n} → as ≡ bs → (x : R) → evalV as x ≡ evalV bs x
  evalV-cong p x = cong (λ cs → evalV cs x) p

  record HigherVectorKL : Set (lsuc (a ⊔ v)) where
    field
      coefficientsV : (n : ℕ) → (DK (suc n) → V) → Vec V (suc (suc n))
      reconstructionV : (n : ℕ) (f : DK (suc n) → V) (d : DK (suc n)) →
        f d ≡ evalV (coefficientsV n f) (valueK d)
      uniquenessV : (n : ℕ) (f : DK (suc n) → V) (as : Vec V (suc (suc n))) →
        ((d : DK (suc n)) → f d ≡ evalV as (valueK d)) → coefficientsV n f ≡ as

  record VectorKL : Set (lsuc (a ⊔ v)) where
    field
      slopeV : (D → V) → V
      expansionV : (g : D → V) (d : D) → g d ≡ g zeroD +v value d • slopeV g
      uniqueSlopeV : (g : D → V) (b : V) →
        ((d : D) → g d ≡ g zeroD +v value d • b) → slopeV g ≡ b

-- The scalar instance is obtained from precisely the higher KL axiom of I.3.
module ScalarInstance {a : Level} (A : CRing a)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A) where
  open S3.HigherInfinitesimals A
  open HigherKockLawvere H
  module V = VectorInfinitesimals A (scalarModule A)

  scalar-evaluation : {n : ℕ} (as : Vec R n) (x : R) → V.evalV as x ≡ eval as x
  scalar-evaluation [] x = refl
  scalar-evaluation (a ∷ as) x = cong (λ z → a + x * z) (scalar-evaluation as x)

  scalarKL : V.HigherVectorKL
  scalarKL = record
    { coefficientsV = coefficients
    ; reconstructionV = λ n f d → trans (reconstruction n f d)
        (sym (scalar-evaluation (coefficients n f) (valueK d)))
    ; uniquenessV = λ n f as p → uniqueness n f as
        (λ d → trans (p d) (scalar-evaluation as (valueK d)))
    }

-- Higher vector KL is preserved by every finite product, including dimension 0.
-- In particular, taking M=scalarModule gives the R^m part of Exercise I.5.3.
module FinitePowers {a v : Level} (A : CRing a) (M : RModule A v)
  (H : VectorInfinitesimals.HigherVectorKL A M) (m : ℕ) where
  open ModuleLemmas A M
  open S3.HigherInfinitesimals A using (DK; valueK)
  module Source = VectorInfinitesimals A M
  module Target = VectorInfinitesimals A (FiniteModules.finiteModule A M m)
  open Source.HigherVectorKL H

  coordinate : Vec V m → Fin m → V
  coordinate = lookup

  eval-coordinate : {n : ℕ} (as : Vec (Vec V m) n) (x : R) (j : Fin m) →
    lookup (Target.evalV as x) j ≡ Source.evalV (map (λ ys → lookup ys j) as) x
  eval-coordinate [] x j = lookup-replicate 0v j
  eval-coordinate (a ∷ as) x j =
    trans (lookup-zipWith _+v_ a (map (x •_) (Target.evalV as x)) j)
      (cong (lookup a j +v_)
        (trans (lookup-map (x •_) (Target.evalV as x) j)
          (cong (x •_) (eval-coordinate as x j))))

  finite-coefficients : (n : ℕ) → (DK (suc n) → Vec V m) → Vec (Vec V m) (suc (suc n))
  finite-coefficients n f = tabulate
    (λ i → tabulate (λ j → lookup (coefficientsV n (λ d → lookup (f d) j)) i))

  coefficient-at : (n : ℕ) (f : DK (suc n) → Vec V m)
    (i : Fin (suc (suc n))) (j : Fin m) →
    lookup (lookup (finite-coefficients n f) i) j ≡
      lookup (coefficientsV n (λ d → lookup (f d) j)) i
  coefficient-at n f i j =
    trans (cong (λ ys → lookup ys j)
      (lookup-tabulate (λ k → tabulate
        (λ l → lookup (coefficientsV n (λ d → lookup (f d) l)) k)) i))
      (lookup-tabulate (λ l → lookup (coefficientsV n (λ d → lookup (f d) l)) i) j)

  coordinate-coefficients : (n : ℕ) (f : DK (suc n) → Vec V m) (j : Fin m) →
    map (λ ys → lookup ys j) (finite-coefficients n f) ≡
      coefficientsV n (λ d → lookup (f d) j)
  coordinate-coefficients n f j = vec-ext (λ i →
    trans (lookup-map (λ ys → lookup ys j) (finite-coefficients n f) i)
      (coefficient-at n f i j))

  finiteKL : Target.HigherVectorKL
  finiteKL = record
    { coefficientsV = finite-coefficients
    ; reconstructionV = λ n f d → vec-ext (λ j →
        trans (reconstructionV n (λ e → lookup (f e) j) d)
          (trans (Source.evalV-cong (sym (coordinate-coefficients n f j)) (valueK d))
            (sym (eval-coordinate (finite-coefficients n f) (valueK d) j))))
    ; uniquenessV = λ n f as p → vec-ext (λ i → vec-ext (λ j →
        trans (coefficient-at n f i j)
          (trans (cong (λ cs → lookup cs i)
            (uniquenessV n (λ d → lookup (f d) j) (map (λ ys → lookup ys j) as)
              (λ d → trans (cong (λ ys → lookup ys j) (p d)) (eval-coordinate as (valueK d) j))))
            (lookup-map (λ ys → lookup ys j) as i))))
    }

-- Closure under function spaces, with extensionality made an explicit input
-- exactly where pointwise identities are turned into function identities.
module FunctionPowers {a v x : Level} (A : CRing a) (M : RModule A v)
  (H : VectorInfinitesimals.HigherVectorKL A M) (X : Set x) (ext : FunExt x v) where
  open ModuleLemmas A M
  open S3.HigherInfinitesimals A using (DK; valueK)
  module Source = VectorInfinitesimals A M
  module Target = VectorInfinitesimals A (functionModule A M X ext)
  open Source.HigherVectorKL H

  eval-at : {n : ℕ} (as : Vec (X → V) n) (r : R) (x : X) →
    Target.evalV as r x ≡ Source.evalV (map (λ f → f x) as) r
  eval-at [] r x = refl
  eval-at (a ∷ as) r x = cong (λ y → a x +v r • y) (eval-at as r x)

  function-coefficients : (n : ℕ) → (DK (suc n) → X → V) → Vec (X → V) (suc (suc n))
  function-coefficients n f = tabulate
    (λ i x → lookup (coefficientsV n (λ d → f d x)) i)

  coefficient-at : (n : ℕ) (f : DK (suc n) → X → V)
    (i : Fin (suc (suc n))) (x : X) →
    lookup (function-coefficients n f) i x ≡ lookup (coefficientsV n (λ d → f d x)) i
  coefficient-at n f i x = cong (λ g → g x)
    (lookup-tabulate (λ j y → lookup (coefficientsV n (λ d → f d y)) j) i)

  evaluation-coefficients : (n : ℕ) (f : DK (suc n) → X → V) (x : X) →
    map (λ g → g x) (function-coefficients n f) ≡ coefficientsV n (λ d → f d x)
  evaluation-coefficients n f x = vec-ext (λ i →
    trans (lookup-map (λ g → g x) (function-coefficients n f) i) (coefficient-at n f i x))

  functionKL : Target.HigherVectorKL
  functionKL = record
    { coefficientsV = function-coefficients
    ; reconstructionV = λ n f d → ext (λ x →
        trans (reconstructionV n (λ e → f e x) d)
          (trans (Source.evalV-cong (sym (evaluation-coefficients n f x)) (valueK d))
            (sym (eval-at (function-coefficients n f) (valueK d) x))))
    ; uniquenessV = λ n f as p → vec-ext (λ i → ext (λ x →
        trans (coefficient-at n f i x)
          (trans (cong (λ cs → lookup cs i)
            (uniquenessV n (λ d → f d x) (map (λ g → g x) as)
              (λ d → trans (cong (λ g → g x) (p d)) (eval-at as (valueK d) x))))
            (lookup-map (λ g → g x) as i))))
    }

finite-scalars-KL : {a : Level} (A : CRing a)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A) (m : ℕ) →
  VectorInfinitesimals.HigherVectorKL A (finiteScalarModule A m)
finite-scalars-KL A H m = FinitePowers.finiteKL A (scalarModule A) (ScalarInstance.scalarKL A H) m

module VectorFirstOrder {a v : Level} (A : CRing a) (M : RModule A v)
  (H : VectorInfinitesimals.HigherVectorKL A M) where
  open VectorInfinitesimals A M
  open HigherVectorKL H
  open Infinitesimals A
  open S3.HigherInfinitesimals A using (DK; valueK; fromD; toD; toD-fromD)

  firstJet : (D → V) → Vec V (suc (suc zero))
  firstJet g = coefficientsV zero (λ d → g (toD d))

  linear-normal-form : (as : Vec V (suc (suc zero))) (x : R) →
    evalV as x ≡ head as +v x • head (tail as)
  linear-normal-form (a ∷ b ∷ []) x = evalV-linear a b x

  first-constant : (g : D → V) → head (firstJet g) ≡ g zeroD
  first-constant g =
    trans (sym (evalV-zero (firstJet g)))
      (trans (sym (reconstructionV zero (λ d → g (toD d)) (fromD zeroD)))
        (cong g (toD-fromD zeroD)))

  first-expansion : (g : D → V) (d : D) →
    g d ≡ g zeroD +v value d • head (tail (firstJet g))
  first-expansion g d =
    trans (cong g (sym (toD-fromD d)))
      (trans (reconstructionV zero (λ e → g (toD e)) (fromD d))
        (trans (linear-normal-form (firstJet g) (value d))
          (cong (_+v (value d • head (tail (firstJet g)))) (first-constant g))))

  first-unique : (g : D → V) (b : V) →
    ((d : D) → g d ≡ g zeroD +v value d • b) → head (tail (firstJet g)) ≡ b
  first-unique g b p = cong (λ as → head (tail as))
    (uniquenessV zero (λ d → g (toD d)) (g zeroD ∷ b ∷ [])
      (λ d → trans (p (toD d)) (sym (evalV-linear (g zeroD) b (valueK d)))))

  firstOrderV : VectorKL
  firstOrderV = record
    { slopeV = λ g → head (tail (firstJet g))
    ; expansionV = first-expansion
    ; uniqueSlopeV = first-unique
    }

module VectorCalculus {a v : Level} (A : CRing a) (M : RModule A v)
  (K : VectorInfinitesimals.VectorKL A M) where
  open VectorInfinitesimals A M
  open VectorKL K
  open Infinitesimals A

  slope-cong : (f g : D → V) → ((d : D) → f d ≡ g d) → slopeV f ≡ slopeV g
  slope-cong f g p = uniqueSlopeV f (slopeV g)
    (λ d → trans (p d) (trans (expansionV g d)
      (cong (_+v (value d • slopeV g)) (sym (p zeroD)))))

  cancel-infinitesimals : (b c : V) →
    ((d : D) → value d • b ≡ value d • c) → b ≡ c
  cancel-infinitesimals b c p =
    trans (sym (uniqueSlopeV (λ d → value d • b) b
      (λ d → sym (trans (cong (_+v (value d • b)) (zero-scalar b))
        (add-zeroˡ (value d • b))))))
      (uniqueSlopeV (λ d → value d • b) c
        (λ d → trans (p d)
          (sym (trans (cong (_+v (value d • c)) (zero-scalar b))
            (add-zeroˡ (value d • c))))))

  slope-add : (f g : D → V) → slopeV (λ d → f d +v g d) ≡ slopeV f +v slopeV g
  slope-add f g = uniqueSlopeV (λ d → f d +v g d) (slopeV f +v slopeV g)
    (λ d → trans (cong₂ _+v_ (expansionV f d) (expansionV g d))
      (trans (add-shuffle (f zeroD) (value d • slopeV f) (g zeroD) (value d • slopeV g))
        (cong ((f zeroD +v g zeroD) +v_)
          (sym (scalar-distrib (value d) (slopeV f) (slopeV g))))))

  slope-scale : (r : R) (f : D → V) → slopeV (λ d → r • f d) ≡ r • slopeV f
  slope-scale r f = uniqueSlopeV (λ d → r • f d) (r • slopeV f)
    (λ d → trans (cong (r •_) (expansionV f d))
      (trans (scalar-distrib r (f zeroD) (value d • slopeV f))
        (cong ((r • f zeroD) +v_) (scalar-commute r (value d) (slopeV f)))))

  mixed-slope : (f : D → D → V) →
    slopeV (λ e → slopeV (λ d → f d e)) ≡ slopeV (λ d → slopeV (λ e → f d e))
  mixed-slope f = sym (uniqueSlopeV (λ d → slopeV (f d))
    (slopeV (λ e → slopeV (λ d → f d e)))
    (λ d → trans (slope-cong (f d)
      (λ e → f zeroD e +v value d • slopeV (λ d′ → f d′ e))
      (λ e → expansionV (λ d′ → f d′ e) d))
      (trans (slope-add (f zeroD) (λ e → value d • slopeV (λ d′ → f d′ e)))
        (cong (slopeV (f zeroD) +v_)
          (slope-scale (value d) (λ e → slopeV (λ d′ → f d′ e)))))))

  derivative : (R → V) → R → V
  derivative f x = slopeV (λ d → f (x + value d))

  taylor : (f : R → V) (x : R) (d : D) → f (x + value d) ≡ f x +v value d • derivative f x
  taylor f x d = trans (expansionV (λ e → f (x + value e)) d)
    (cong (_+v (value d • derivative f x)) (cong f (+-identityʳ x)))

  derivative-unique : (f : R → V) (x : R) (b : V) →
    ((d : D) → f (x + value d) ≡ f x +v value d • b) → derivative f x ≡ b
  derivative-unique f x b p = uniqueSlopeV (λ d → f (x + value d)) b
    (λ d → trans (p d) (cong (_+v (value d • b)) (cong f (sym (+-identityʳ x)))))

  derivative-cong : (f g : R → V) → ((x : R) → f x ≡ g x) →
    (x : R) → derivative f x ≡ derivative g x
  derivative-cong f g p x = slope-cong
    (λ d → f (x + value d)) (λ d → g (x + value d)) (λ d → p (x + value d))

  derivative-add : (f g : R → V) (x : R) →
    derivative (λ t → f t +v g t) x ≡ derivative f x +v derivative g x
  derivative-add f g x = slope-add (λ d → f (x + value d)) (λ d → g (x + value d))

  derivative-scale : (r : R) (f : R → V) (x : R) →
    derivative (λ t → r • f t) x ≡ r • derivative f x
  derivative-scale r f x = slope-scale r (λ d → f (x + value d))

  iterate : ℕ → (R → V) → R → V
  iterate zero f = f
  iterate (suc n) f = derivative (iterate n f)

  shift : {n : ℕ} → Vec R n → Fin n → D → Vec R n
  shift (x ∷ xs) fzero d = (x + value d) ∷ xs
  shift (x ∷ xs) (fsuc i) d = x ∷ shift xs i d

  shift-zero : {n : ℕ} (xs : Vec R n) (i : Fin n) → shift xs i zeroD ≡ xs
  shift-zero (x ∷ xs) fzero = cong (_∷ xs) (+-identityʳ x)
  shift-zero (x ∷ xs) (fsuc i) = cong (x ∷_) (shift-zero xs i)

  partial : {n : ℕ} → (Vec R n → V) → Fin n → Vec R n → V
  partial f i xs = slopeV (λ d → f (shift xs i d))

  partial-taylor : {n : ℕ} (f : Vec R n → V) (i : Fin n) (xs : Vec R n) (d : D) →
    f (shift xs i d) ≡ f xs +v value d • partial f i xs
  partial-taylor f i xs d = trans (expansionV (λ e → f (shift xs i e)) d)
    (cong (_+v (value d • partial f i xs)) (cong f (shift-zero xs i)))

  shift-commute : {n : ℕ} (xs : Vec R n) (i j : Fin n) (d e : D) →
    shift (shift xs i d) j e ≡ shift (shift xs j e) i d
  shift-commute (x ∷ xs) fzero fzero d e = cong (_∷ xs)
    (trans (+-assoc x (value d) (value e))
      (trans (cong (x +_) (+-comm (value d) (value e)))
        (sym (+-assoc x (value e) (value d)))))
  shift-commute (x ∷ xs) fzero (fsuc j) d e = refl
  shift-commute (x ∷ xs) (fsuc i) fzero d e = refl
  shift-commute (x ∷ xs) (fsuc i) (fsuc j) d e = cong (x ∷_) (shift-commute xs i j d e)

  mixed-partials : {n : ℕ} (f : Vec R n → V) (i j : Fin n) (xs : Vec R n) →
    partial (partial f i) j xs ≡ partial (partial f j) i xs
  mixed-partials f i j xs =
    trans (slope-cong
      (λ e → slopeV (λ d → f (shift (shift xs j e) i d)))
      (λ e → slopeV (λ d → f (shift (shift xs i d) j e)))
      (λ e → slope-cong
        (λ d → f (shift (shift xs j e) i d))
        (λ d → f (shift (shift xs i d) j e))
        (λ d → cong f (shift-commute xs j i e d))))
      (mixed-slope (λ d e → f (shift (shift xs i d) j e)))

-- Polynomial differentiation over a module. Every identity is proved from
-- module laws, so the codomain need not carry multiplication of vectors.
module VectorPolynomials {a v : Level} (A : CRing a) (M : RModule A v) where
  open VectorInfinitesimals A M
  open Infinitesimals A
  open PowerLemmas A using (fromℕ; fromℕ-one; _^_)

  eval-add : {n : ℕ} (as bs : Vec V n) (x : R) →
    evalV (zipWith _+v_ as bs) x ≡ evalV as x +v evalV bs x
  eval-add [] [] x = sym (add-zeroˡ 0v)
  eval-add (a ∷ as) (b ∷ bs) x =
    trans (cong (λ z → (a +v b) +v x • z) (eval-add as bs x))
      (trans (cong ((a +v b) +v_) (scalar-distrib x (evalV as x) (evalV bs x)))
        (add-shuffle a b (x • evalV as x) (x • evalV bs x)))

  weightFrom : {n : ℕ} → ℕ → Vec V n → Vec V n
  weightFrom m [] = []
  weightFrom m (a ∷ as) = (fromℕ m • a) ∷ weightFrom (suc m) as

  weight-step : {n : ℕ} (m : ℕ) (as : Vec V n) →
    weightFrom (suc m) as ≡ zipWith _+v_ as (weightFrom m as)
  weight-step m [] = refl
  weight-step m (a ∷ as) = cong₂ _∷_
    (trans (scalar-add 1r (fromℕ m) a) (cong (_+v (fromℕ m • a)) (scalar-one a)))
    (weight-step (suc m) as)

  lookup-weight : {n : ℕ} (m : ℕ) (as : Vec V n) (i : Fin n) →
    lookup (weightFrom m as) i ≡ fromℕ (m +ℕ finToNat i) • lookup as i
  lookup-weight m (a ∷ as) fzero = cong (λ k → fromℕ k • a) (sym (nat-add-zeroʳ m))
  lookup-weight m (a ∷ as) (fsuc i) = trans (lookup-weight (suc m) as i)
    (cong (λ k → fromℕ k • lookup as i) (sym (nat-add-sucʳ m (finToNat i))))

  differentiate : {n : ℕ} → Vec V (suc n) → Vec V n
  differentiate (a ∷ as) = weightFrom (suc zero) as

  differentiate-recurrence : {n : ℕ} (a b : V) (as : Vec V n) →
    differentiate (a ∷ b ∷ as) ≡ zipWith _+v_ (b ∷ as) (0v ∷ differentiate (b ∷ as))
  differentiate-recurrence a b as = cong₂ _∷_
    (trans (cong (_• b) fromℕ-one) (trans (scalar-one b) (sym (add-zeroʳ b))))
    (weight-step (suc zero) as)

  eval-differentiate : {n : ℕ} (a b : V) (as : Vec V n) (x : R) →
    evalV (differentiate (a ∷ b ∷ as)) x ≡
      evalV (b ∷ as) x +v x • evalV (differentiate (b ∷ as)) x
  eval-differentiate a b as x =
    trans (evalV-cong (differentiate-recurrence a b as) x)
      (trans (eval-add (b ∷ as) (0v ∷ differentiate (b ∷ as)) x)
        (cong (evalV (b ∷ as) x +v_)
          (add-zeroˡ (x • evalV (differentiate (b ∷ as)) x))))

  horner-first-order : (a : V) (x d : R) (b c : V) → d * d ≡ 0r →
    a +v (x + d) • (b +v d • c) ≡ (a +v x • b) +v d • (b +v x • c)
  horner-first-order a x d b c dd =
    begin
      a +v (x + d) • (b +v d • c)
    ≡⟨ cong (a +v_) (scalar-add x d (b +v d • c)) ⟩
      a +v ((x • (b +v d • c)) +v (d • (b +v d • c)))
    ≡⟨ cong (a +v_) (cong₂ _+v_ (scalar-distrib x b (d • c)) (scalar-distrib d b (d • c))) ⟩
      a +v (((x • b) +v (x • (d • c))) +v ((d • b) +v (d • (d • c))))
    ≡⟨ cong (a +v_) (cong₂ _+v_
        (cong ((x • b) +v_) (scalar-commute x d c))
        (trans (cong ((d • b) +v_) (scalar-square-zero d dd c)) (add-zeroʳ (d • b)))) ⟩
      a +v (((x • b) +v (d • (x • c))) +v (d • b))
    ≡⟨ cong (a +v_) (add-assoc (x • b) (d • (x • c)) (d • b)) ⟩
      a +v ((x • b) +v ((d • (x • c)) +v (d • b)))
    ≡⟨ cong (λ z → a +v ((x • b) +v z))
        (trans (sym (scalar-distrib d (x • c) b)) (cong (d •_) (add-comm (x • c) b))) ⟩
      a +v ((x • b) +v (d • (b +v x • c)))
    ≡⟨ sym (add-assoc a (x • b) (d • (b +v x • c))) ⟩
      (a +v x • b) +v d • (b +v x • c) ∎

  polynomial-first-order : {n : ℕ} (as : Vec V (suc n)) (x : R) (d : D) →
    evalV as (x + value d) ≡ evalV as x +v value d • evalV (differentiate as) x
  polynomial-first-order (a ∷ []) x d = trans (evalV-constant a (x + value d))
    (sym (trans (cong₂ _+v_ (evalV-constant a x) (scalar-zero (value d))) (add-zeroʳ a)))
  polynomial-first-order (a ∷ b ∷ as) x d =
    trans (cong (λ z → a +v (x + value d) • z) (polynomial-first-order (b ∷ as) x d))
      (trans (horner-first-order a x (value d) (evalV (b ∷ as) x)
        (evalV (differentiate (b ∷ as)) x) (square-zero d))
        (cong (λ z → evalV (a ∷ b ∷ as) x +v value d • z)
          (sym (eval-differentiate a b as x))))

  monomialSum : {n : ℕ} → Vec V n → R → ℕ → V
  monomialSum [] x j = 0v
  monomialSum (a ∷ as) x j = (x ^ j) • a +v monomialSum as x (suc j)

  monomialSum-shift : {n : ℕ} (as : Vec V n) (x : R) (j : ℕ) →
    monomialSum as x (suc j) ≡ x • monomialSum as x j
  monomialSum-shift [] x j = sym (scalar-zero x)
  monomialSum-shift (a ∷ as) x j =
    trans (cong₂ _+v_ (scalar-assoc x (x ^ j) a) (monomialSum-shift as x (suc j)))
      (sym (scalar-distrib x ((x ^ j) • a) (monomialSum as x (suc j))))

  eval-as-sum : {n : ℕ} (as : Vec V n) (x : R) → evalV as x ≡ monomialSum as x zero
  eval-as-sum [] x = refl
  eval-as-sum (a ∷ as) x =
    trans (cong (λ z → a +v x • z) (eval-as-sum as x))
      (cong₂ _+v_ (sym (scalar-one a)) (sym (monomialSum-shift as x zero)))

module VectorDescent {a v : Level} (A : CRing a) (M : RModule A v)
  (K : VectorInfinitesimals.VectorKL A M) where
  open VectorInfinitesimals A M
  open VectorPolynomials A M
  open VectorCalculus A M K
  open PowerLemmas A using (factorial; fromℕ)
  open Infinitesimals A using (D; value)
  open S3.HigherInfinitesimals A using (DK; valueK; zeroK; shiftK; weakenK)

  Expansion : ℕ → (R → V) → R → {n : ℕ} → Vec V n → Set (a ⊔ v)
  Expansion k f x as = (d : DK k) → f (x + valueK d) ≡ evalV as (valueK d)

  differentiate-expansion : {n : ℕ} (f : R → V) (x : R) (as : Vec V (suc (suc n))) →
    Expansion (suc n) f x as → Expansion n (derivative f) x (differentiate as)
  differentiate-expansion f x as p a =
    cancel-infinitesimals (derivative f (x + valueK a)) (evalV (differentiate as) (valueK a))
      (λ d → add-cancelˡ (f (x + valueK a))
        (trans (sym (taylor f (x + valueK a) d))
          (trans (cong f (+-assoc x (valueK a) (value d)))
            (trans (p (shiftK a d))
              (trans (polynomial-first-order as (valueK a) d)
                (cong (_+v (value d • evalV (differentiate as) (valueK a)))
                  (sym (p (weakenK a)))))))))

  constant-from-expansion : (n : ℕ) (f : R → V) (x : R) (as : Vec V (suc n)) →
    Expansion n f x as → head as ≡ f x
  constant-from-expansion n f x as p =
    trans (sym (evalV-zero as)) (trans (sym (p (zeroK n))) (cong f (+-identityʳ x)))

  iterate-derivative : (n : ℕ) (f : R → V) → iterate n (derivative f) ≡ iterate (suc n) f
  iterate-derivative zero f = refl
  iterate-derivative (suc n) f = cong derivative (iterate-derivative n f)

  coefficient-derivatives : {n : ℕ} (f : R → V) (x : R) (as : Vec V (suc n)) →
    Expansion n f x as → (i : Fin (suc n)) →
    factorial (finToNat i) • lookup as i ≡ iterate (finToNat i) f x
  coefficient-derivatives {n} f x (a ∷ as) p fzero =
    trans (scalar-one a) (constant-from-expansion n f x (a ∷ as) p)
  coefficient-derivatives {suc n} f x (a ∷ as) p (fsuc i) =
    begin
      (fromℕ (suc (finToNat i)) * factorial (finToNat i)) • lookup as i
    ≡⟨ scalar-assoc (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i) ⟩
      fromℕ (suc (finToNat i)) • (factorial (finToNat i) • lookup as i)
    ≡⟨ scalar-commute (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i) ⟩
      factorial (finToNat i) • (fromℕ (suc (finToNat i)) • lookup as i)
    ≡⟨ cong (factorial (finToNat i) •_) (sym (lookup-weight (suc zero) as i)) ⟩
      factorial (finToNat i) • lookup (differentiate (a ∷ as)) i
    ≡⟨ coefficient-derivatives (derivative f) x (differentiate (a ∷ as))
        (differentiate-expansion f x (a ∷ as) p) i ⟩
      iterate (finToNat i) (derivative f) x
    ≡⟨ cong (λ g → g x) (iterate-derivative (finToNat i) f) ⟩
      iterate (suc (finToNat i)) f x ∎

module VectorTaylor {a v : Level} (A : CRing a) (M : RModule A v)
  (H : VectorInfinitesimals.HigherVectorKL A M)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open VectorInfinitesimals A M
  open HigherVectorKL H
  open VectorFirstOrder A M H using (firstOrderV)
  open VectorCalculus A M firstOrderV public using (derivative; iterate; partial; partial-taylor)
  open VectorDescent A M firstOrderV
  open VectorPolynomials A M using (monomialSum; eval-as-sum)
  open PowerLemmas A using (fromℕ; factorial; power-one)
  open S3.HigherInfinitesimals A using (DK; valueK; nilpotence; PositiveNaturalsInvertible)
  open PositiveNaturalsInvertible Q

  inverseFactorial : ℕ → R
  inverseFactorial zero = 1r
  inverseFactorial (suc n) = reciprocal n * inverseFactorial n

  factorial-inverse : (n : ℕ) → factorial n * inverseFactorial n ≡ 1r
  factorial-inverse zero = *-identityˡ 1r
  factorial-inverse (suc n) =
    trans (*-shuffle (fromℕ (suc n)) (factorial n) (reciprocal n) (inverseFactorial n))
      (trans (cong₂ _*_ (reciprocal-law n) (factorial-inverse n)) (*-identityˡ 1r))

  inverse-factorial-left : (n : ℕ) → inverseFactorial n * factorial n ≡ 1r
  inverse-factorial-left n =
    trans (*-comm (inverseFactorial n) (factorial n)) (factorial-inverse n)

  taylorCoefficients : (n : ℕ) → (R → V) → R → Vec V (suc n)
  taylorCoefficients n f x = tabulate
    (λ i → inverseFactorial (finToNat i) • iterate (finToNat i) f x)

  identify-coefficients : {n : ℕ} (f : R → V) (x : R) (as : Vec V (suc n)) →
    Expansion n f x as → as ≡ taylorCoefficients n f x
  identify-coefficients f x as p = vec-ext (λ i →
    begin
      lookup as i
    ≡⟨ sym (scalar-one (lookup as i)) ⟩
      1r • lookup as i
    ≡⟨ cong (_• lookup as i) (sym (inverse-factorial-left (finToNat i))) ⟩
      (inverseFactorial (finToNat i) * factorial (finToNat i)) • lookup as i
    ≡⟨ scalar-assoc (inverseFactorial (finToNat i)) (factorial (finToNat i)) (lookup as i) ⟩
      inverseFactorial (finToNat i) • (factorial (finToNat i) • lookup as i)
    ≡⟨ cong (inverseFactorial (finToNat i) •_) (coefficient-derivatives f x as p i) ⟩
      inverseFactorial (finToNat i) • iterate (finToNat i) f x
    ≡⟨ sym (lookup-tabulate (λ j → inverseFactorial (finToNat j) • iterate (finToNat j) f x) i) ⟩
      lookup (taylorCoefficients _ f x) i ∎)

  taylor-all-orders : (n : ℕ) (f : R → V) (x : R) (d : DK n) →
    f (x + valueK d) ≡ evalV (taylorCoefficients n f x) (valueK d)
  taylor-all-orders zero f x d =
    trans (cong (λ z → f (x + z)) (trans (sym (power-one (valueK d))) (nilpotence d)))
      (trans (cong f (+-identityʳ x))
        (sym (trans (evalV-constant (1r • f x) (valueK d)) (scalar-one (f x)))))
  taylor-all-orders (suc n) f x d =
    trans (reconstructionV n (λ a → f (x + valueK a)) d)
      (evalV-cong (identify-coefficients f x
        (coefficientsV n (λ a → f (x + valueK a)))
        (reconstructionV n (λ a → f (x + valueK a)))) (valueK d))

  taylor-all-orders-sum : (n : ℕ) (f : R → V) (x : R) (d : DK n) →
    f (x + valueK d) ≡ monomialSum (taylorCoefficients n f x) (valueK d) zero
  taylor-all-orders-sum n f x d =
    trans (taylor-all-orders n f x d) (eval-as-sum (taylorCoefficients n f x) (valueK d))

-- The multivariable counterpart requested by Exercise I.5.4, for the
-- exercise's maps R^n -> V and arbitrary coordinatewise truncation orders.
-- The right side is written as nested finite monomial sums. At each axis,
-- the coefficient is the corresponding iterated partial divided by i!;
-- recursively this is the usual multi-index Taylor expression.
module VectorRectangularTaylor {a v : Level} (A : CRing a) (M : RModule A v)
  (H : VectorInfinitesimals.HigherVectorKL A M)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open VectorInfinitesimals A M
  open S3.HigherInfinitesimals A using (DK; valueK)
  open VectorTaylor A M H Q
  open VectorPolynomials A M using (monomialSum)

  infixr 5 _∷B_
  data Box : {n : ℕ} → Vec ℕ n → Set a where
    []B : Box []
    _∷B_ : {n k : ℕ} {ks : Vec ℕ n} → DK k → Box ks → Box (k ∷ ks)

  shifted : {n : ℕ} {ks : Vec ℕ n} → Vec R n → Box ks → Vec R n
  shifted [] []B = []
  shifted (x ∷ xs) (d ∷B ds) = (x + valueK d) ∷ shifted xs ds

  -- Holding all other coordinates fixed turns iteration into a coordinate
  -- partial of the displayed function, without requiring a product on V.
  coordinateIterate : {n : ℕ} → ℕ → (Vec R (suc n) → V) → R → Vec R n → V
  coordinateIterate i f x ys = iterate i (λ t → f (t ∷ ys)) x

  rectangularExpression : {n : ℕ} (ks : Vec ℕ n) →
    (Vec R n → V) → Vec R n → Box ks → V
  rectangularExpression [] f [] []B = f []
  rectangularExpression (k ∷ ks) f (x ∷ xs) (d ∷B ds) =
    monomialSum (tabulate {n = suc k} (λ i → inverseFactorial (finToNat i) •
      rectangularExpression ks (coordinateIterate (finToNat i) f x) xs ds)) (valueK d) zero

  rectangular-taylor : {n : ℕ} (ks : Vec ℕ n) (f : Vec R n → V)
    (xs : Vec R n) (ds : Box ks) →
    f (shifted xs ds) ≡ rectangularExpression ks f xs ds
  rectangular-taylor [] f [] []B = refl
  rectangular-taylor (k ∷ ks) f (x ∷ xs) (d ∷B ds) =
    trans (taylor-all-orders-sum k (λ t → f (t ∷ shifted xs ds)) x d)
      (cong (λ as → monomialSum as (valueK d) zero)
        (tabulate-cong {n = suc k} (λ i → cong (inverseFactorial (finToNat i) •_)
          (rectangular-taylor ks (coordinateIterate (finToNat i) f x) xs ds))))
