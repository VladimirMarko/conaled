{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section13Linear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Order
open import SDG.ChapterI.Section07Linear using (ModuleMap)
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section13Intervals as SI

-- Native module maps witnessing the source's R-linearity assertions.
-- Function extensionality is used only to package the function-space
-- module's laws; all integral equalities were proved pointwise without it.
module LinearMaps {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) (ext : FunExt ℓ ℓ) where
  open SI.Results A K O J

  unitIntegralMap : ModuleMap A (functionModule A (scalarModule A) UnitInterval ext) (scalarModule A)
  unitIntegralMap = record
    { apply = unit-integral
    ; preserves-zero = unit-integral-zero
    ; preserves-add = unit-integral-add
    ; preserves-scale = unit-integral-scale
    }

  unitPrimitiveMap : (t : UnitInterval) →
    ModuleMap A (functionModule A (scalarModule A) UnitInterval ext) (scalarModule A)
  unitPrimitiveMap t = record
    { apply = λ f → primitiveOf f t
    ; preserves-zero = primitive-of-zero t
    ; preserves-add = λ f g → primitive-add f g t
    ; preserves-scale = λ r f → primitive-scale r f t
    }

  intervalIntegralMap : {a b : R} (ab : a ≤ b) →
    ModuleMap A (functionModule A (scalarModule A) (Interval a b) ext) (scalarModule A)
  intervalIntegralMap ab = record
    { apply = Over.integral ab
    ; preserves-zero = Over.integral-zero ab
    ; preserves-add = Over.integral-add ab
    ; preserves-scale = Over.integral-scale ab
    }

  intervalPrimitiveMap : {a b : R} (ab : a ≤ b) (x : Interval a b) →
    ModuleMap A (functionModule A (scalarModule A) (Interval a b) ext) (scalarModule A)
  intervalPrimitiveMap ab x = record
    { apply = λ f → Over.intervalPrimitive ab f x
    ; preserves-zero = Over.interval-primitive-of-zero ab x
    ; preserves-add = λ f g → Over.interval-primitive-add ab f g x
    ; preserves-scale = λ r f → Over.interval-primitive-scale ab r f x
    }
