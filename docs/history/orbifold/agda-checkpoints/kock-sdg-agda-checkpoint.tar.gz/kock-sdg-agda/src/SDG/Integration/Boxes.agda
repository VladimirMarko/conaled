{-# OPTIONS --safe --without-K #-}

module SDG.Integration.Boxes where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; delete; replicate)
open import SDG.Forms.CubicalGeometry using (insert)
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section13Intervals as SI

module Boxes {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) where
  open SI.Results A K O J public
  open Infinitesimals A

  record Segment : Set ℓ where
    constructor segment
    field
      lower upper : R
      ordered : lower ≤ upper
  open Segment public

  Carrier : Segment → Set ℓ
  Carrier s = Interval (lower s) (upper s)

  module Line (s : Segment) = Over (ordered s)

  Box : ℕ → Set ℓ
  Box n = Vec Segment n

  -- The dependent product retains the actual endpoint labels of each
  -- factor. The empty product is represented at the ambient universe.
  data Point : {n : ℕ} → Box n → Set ℓ where
    point0 : Point []
    _∷p_ : {n : ℕ} {s : Segment} {ss : Box n} → Carrier s → Point ss → Point (s ∷ ss)
  infixr 5 _∷p_

  lookupPoint : {n : ℕ} (ss : Box n) → Point ss → (i : Fin n) → Carrier (lookup ss i)
  lookupPoint (s ∷ ss) (x ∷p xs) fzero = x
  lookupPoint (s ∷ ss) (x ∷p xs) (fsuc i) = lookupPoint ss xs i

  deletePoint : {n : ℕ} (ss : Box (suc n)) → Point ss → (i : Fin (suc n)) → Point (delete ss i)
  deletePoint (s ∷ ss) (x ∷p xs) fzero = xs
  deletePoint {suc n} (s ∷ ss) (x ∷p xs) (fsuc i) = x ∷p deletePoint ss xs i

  insertPoint : {n : ℕ} (ss : Box (suc n)) (i : Fin (suc n)) →
    Carrier (lookup ss i) → Point (delete ss i) → Point ss
  insertPoint (s ∷ ss) fzero x xs = x ∷p xs
  insertPoint {suc n} (s ∷ ss) (fsuc i) x (y ∷p ys) = y ∷p insertPoint ss i x ys

  point-reconstruction : {n : ℕ} (ss : Box (suc n)) (xs : Point ss) (i : Fin (suc n)) →
    insertPoint ss i (lookupPoint ss xs i) (deletePoint ss xs i) ≡ xs
  point-reconstruction (s ∷ ss) (x ∷p xs) fzero = refl
  point-reconstruction {suc n} (s ∷ ss) (x ∷p xs) (fsuc i) = cong (x ∷p_) (point-reconstruction ss xs i)

  canonicalCube : {n : ℕ} {ss : Box n} → Point ss → Vec D n → Point ss
  canonicalCube point0 [] = point0
  canonicalCube (x ∷p xs) (d ∷ ds) = shift x d ∷p canonicalCube xs ds

  canonical-face : {n : ℕ} (ss : Box (suc n)) (xs : Point ss) (i : Fin (suc n)) (d : D) (ds : Vec D n) →
    canonicalCube xs (insert i d ds) ≡
    insertPoint ss i (shift (lookupPoint ss xs i) d) (canonicalCube (deletePoint ss xs i) ds)
  canonical-face (s ∷ ss) (x ∷p xs) fzero d ds = refl
  canonical-face {suc n} (s ∷ ss) (x ∷p xs) (fsuc i) d (e ∷ ds) =
    cong (shift x e ∷p_) (canonical-face ss xs i d ds)

  -- Integration order is the source's order: the first coordinate is
  -- integrated innermost and the final coordinate outermost.
  integralBox : {n : ℕ} (ss : Box n) → (Point ss → R) → R
  integralBox [] f = f point0
  integralBox (s ∷ ss) f = integralBox ss (λ xs → Line.integral s (λ x → f (x ∷p xs)))

  integral-congruence : {n : ℕ} (ss : Box n) (f g : Point ss → R) →
    ((xs : Point ss) → f xs ≡ g xs) → integralBox ss f ≡ integralBox ss g
  integral-congruence [] f g p = p point0
  integral-congruence (s ∷ ss) f g p = integral-congruence ss _ _
    (λ xs → Line.integral-cong s _ _ (λ x → p (x ∷p xs)))

  integral-additivity : {n : ℕ} (ss : Box n) (f g : Point ss → R) →
    integralBox ss (λ xs → f xs + g xs) ≡ integralBox ss f + integralBox ss g
  integral-additivity [] f g = refl
  integral-additivity (s ∷ ss) f g = trans (integral-congruence ss _ _
    (λ xs → Line.integral-add s (λ x → f (x ∷p xs)) (λ x → g (x ∷p xs))))
    (integral-additivity ss (λ xs → Line.integral s (λ x → f (x ∷p xs)))
      (λ xs → Line.integral s (λ x → g (x ∷p xs))))

  integral-scaling : {n : ℕ} (ss : Box n) (r : R) (f : Point ss → R) →
    integralBox ss (λ xs → r * f xs) ≡ r * integralBox ss f
  integral-scaling [] r f = refl
  integral-scaling (s ∷ ss) r f = trans (integral-congruence ss _ _
    (λ xs → Line.integral-scale s r (λ x → f (x ∷p xs))))
    (integral-scaling ss r (λ xs → Line.integral s (λ x → f (x ∷p xs))))

  integral-negative : {n : ℕ} (ss : Box n) (f : Point ss → R) →
    integralBox ss (λ xs → - f xs) ≡ (- integralBox ss f)
  integral-negative [] f = refl
  integral-negative (s ∷ ss) f = trans (integral-congruence ss _ _
    (λ xs → Line.integral-neg s (λ x → f (x ∷p xs))))
    (integral-negative ss (λ xs → Line.integral s (λ x → f (x ∷p xs))))

  integral-difference : {n : ℕ} (ss : Box n) (f g : Point ss → R) →
    integralBox ss (λ xs → f xs - g xs) ≡ integralBox ss f - integralBox ss g
  integral-difference ss f g = trans (integral-additivity ss f (λ xs → - g xs))
    (cong (integralBox ss f +_) (integral-negative ss g))

  integral-of-zero : {n : ℕ} (ss : Box n) → integralBox ss (λ _ → 0r) ≡ 0r
  integral-of-zero [] = refl
  integral-of-zero (s ∷ ss) = trans (integral-congruence ss _ (λ _ → 0r)
    (λ _ → Line.integral-zero s)) (integral-of-zero ss)

  sectionDerivative : {n : ℕ} (ss : Box (suc n)) (i : Fin (suc n)) →
    (Point (delete ss i) → Carrier (lookup ss i) → R) → Point ss → R
  sectionDerivative ss i f xs = Line.C.derivative (lookup ss i) (f (deletePoint ss xs i)) (lookupPoint ss xs i)

  -- The fundamental theorem in any selected coordinate of an arbitrary
  -- finite box. The induction moves that derivative past the earlier
  -- integrals using the proved parameter differentiation theorem.
  coordinate-fundamental-theorem : {n : ℕ} (ss : Box (suc n)) (i : Fin (suc n))
    (f : Point (delete ss i) → Carrier (lookup ss i) → R) →
    integralBox ss (sectionDerivative ss i f) ≡ integralBox (delete ss i)
      (λ xs → f xs (Line.right (lookup ss i)) - f xs (Line.left (lookup ss i)))
  coordinate-fundamental-theorem (s ∷ ss) fzero f = integral-congruence ss _ _
    (λ xs → Line.integral-derivative s (f xs))
  coordinate-fundamental-theorem {suc n} (s ∷ ss) (fsuc i) f =
    trans (integral-congruence ss _ (sectionDerivative ss i g)
      (λ xs → sym (Line.Parameter.differentiate-integral s
        (intervalDomain (lower (lookup ss i)) (upper (lookup ss i)))
        (λ y x → f (x ∷p deletePoint ss xs i) y) (lookupPoint ss xs i))))
      (trans (coordinate-fundamental-theorem ss i g)
        (integral-congruence (delete ss i) _ _ (λ xs → sym (Line.integral-sub s
          (λ x → f (x ∷p xs) (Line.right (lookup ss i)))
          (λ x → f (x ∷p xs) (Line.left (lookup ss i)))))))
    where
    g : Point (delete ss i) → Carrier (lookup ss i) → R
    g xs y = Line.integral s (λ x → f (x ∷p xs) y)

  unitSegment : Segment
  unitSegment = segment 0r 1r zero-one

  unitBox : (n : ℕ) → Box n
  unitBox n = replicate {n = n} unitSegment

  smallSegment : R → D → Segment
  smallSegment a d = segment a (a + value d) (nilpotent-add-above a (value d) (square-zero-nilpotent d))

  -- The integral over a first-order infinitesimal interval is its length
  -- times the initial value, by Taylor expansion of the constructed primitive.
  infinitesimal-integral : (a : R) (d : D) (f : Carrier (smallSegment a d) → R) →
    Line.integral (smallSegment a d) f ≡ value d * f (Line.left (smallSegment a d))
  infinitesimal-integral a d f = trans
    (cong (Line.intervalPrimitive s f) (interval-ext refl))
    (trans (Line.C.taylor s (Line.intervalPrimitive s f) (Line.left s) d)
      (trans (cong₂ _+_ (Line.interval-primitive-zero s f)
        (cong (value d *_) (Line.interval-primitive-derivative s f (Line.left s))))
        (+-identityˡ (value d * f (Line.left s)))))
    where s : Segment
          s = smallSegment a d
