{-# OPTIONS --safe --without-K #-}

-- Finite coordinates used in multivariable calculus.
-- Everything in this module is constructive and independent of SDG axioms.
module SDG.Finite where

open import Agda.Primitive using (Level; _⊔_)
open import Agda.Builtin.Nat public using (Nat; zero; suc)
  renaming (_+_ to _+ℕ_; _*_ to _*ℕ_)
open import Agda.Builtin.Equality using (_≡_; refl)

private
  variable
    a b c : Level
    A : Set a
    B : Set b
    C : Set c
    n m : Nat

  eq-cong : {x y : A} (f : A → B) → x ≡ y → f x ≡ f y
  eq-cong f refl = refl

  eq-cong₂ : {x y : A} {u v : B} (f : A → B → C) →
             x ≡ y → u ≡ v → f x u ≡ f y v
  eq-cong₂ f refl refl = refl

  eq-trans : {x y z : A} → x ≡ y → y ≡ z → x ≡ z
  eq-trans refl p = p

  eq-sym : {x y : A} → x ≡ y → y ≡ x
  eq-sym refl = refl

-- Fin n is the type of coordinate positions in n-dimensional space.
data Fin : Nat → Set where
  fzero : {n : Nat} → Fin (suc n)
  fsuc  : {n : Nat} → Fin n → Fin (suc n)

finToNat : Fin n → Nat
finToNat fzero = zero
finToNat (fsuc i) = suc (finToNat i)

fsuc-injective : {i j : Fin n} → fsuc i ≡ fsuc j → i ≡ j
fsuc-injective refl = refl

-- An explicit decidable comparison without imposing decidability on scalars.
data FinComparison {n : Nat} (i : Fin n) : Fin n → Set where
  same : FinComparison i i
  different : {j : Fin n} → (i ≡ j → Fin zero) → FinComparison i j

compareFin : (i j : Fin n) → FinComparison i j
compareFin fzero fzero = same
compareFin fzero (fsuc j) = different (λ ())
compareFin (fsuc i) fzero = different (λ ())
compareFin (fsuc i) (fsuc j) with compareFin i j
... | same = same
... | different p = different (λ q → p (fsuc-injective q))

-- Length-indexed lists, with no function extensionality requirement.
infixr 5 _∷_
data Vec (A : Set a) : Nat → Set a where
  []  : Vec A zero
  _∷_ : {n : Nat} → A → Vec A n → Vec A (suc n)

head : Vec A (suc n) → A
head (x ∷ xs) = x

tail : Vec A (suc n) → Vec A n
tail (x ∷ xs) = xs

snoc : Vec A n → A → Vec A (suc n)
snoc [] x = x ∷ []
snoc (y ∷ ys) x = y ∷ snoc ys x

initial : Vec A (suc n) → Vec A n
initial {n = zero} (x ∷ xs) = []
initial {n = suc n} (x ∷ xs) = x ∷ initial xs

last : Vec A (suc n) → A
last {n = zero} (x ∷ xs) = x
last {n = suc n} (x ∷ xs) = last xs

snoc-initial-last : (xs : Vec A (suc n)) → snoc (initial xs) (last xs) ≡ xs
snoc-initial-last (x ∷ []) = refl
snoc-initial-last (x ∷ y ∷ ys) = eq-cong (x ∷_) (snoc-initial-last (y ∷ ys))

initial-snoc : (xs : Vec A n) (x : A) → initial (snoc xs x) ≡ xs
initial-snoc [] x = refl
initial-snoc (y ∷ ys) x = eq-cong (y ∷_) (initial-snoc ys x)

last-snoc : (xs : Vec A n) (x : A) → last (snoc xs x) ≡ x
last-snoc [] x = refl
last-snoc (y ∷ ys) x = last-snoc ys x

lookup : Vec A n → Fin n → A
lookup (x ∷ xs) fzero = x
lookup (x ∷ xs) (fsuc i) = lookup xs i

tabulate : {n : Nat} → (Fin n → A) → Vec A n
tabulate {n = zero} f = []
tabulate {n = suc n} f = f fzero ∷ tabulate (λ i → f (fsuc i))

lookup-tabulate : (f : Fin n → A) (i : Fin n) →
                  lookup (tabulate f) i ≡ f i
lookup-tabulate f fzero = refl
lookup-tabulate f (fsuc i) = lookup-tabulate (λ j → f (fsuc j)) i

tabulate-lookup : (xs : Vec A n) → tabulate (lookup xs) ≡ xs
tabulate-lookup [] = refl
tabulate-lookup (x ∷ xs) = eq-cong (x ∷_) (tabulate-lookup xs)

vec-ext : {xs ys : Vec A n} →
          ((i : Fin n) → lookup xs i ≡ lookup ys i) → xs ≡ ys
vec-ext {xs = []} {ys = []} p = refl
vec-ext {xs = x ∷ xs} {ys = y ∷ ys} p =
  eq-cong₂ _∷_ (p fzero) (vec-ext (λ i → p (fsuc i)))

tabulate-cong : {f g : Fin n → A} →
                ((i : Fin n) → f i ≡ g i) → tabulate f ≡ tabulate g
tabulate-cong {n = zero} p = refl
tabulate-cong {n = suc n} p =
  eq-cong₂ _∷_ (p fzero) (tabulate-cong (λ i → p (fsuc i)))

map : (A → B) → Vec A n → Vec B n
map f [] = []
map f (x ∷ xs) = f x ∷ map f xs

lookup-map : (f : A → B) (xs : Vec A n) (i : Fin n) →
             lookup (map f xs) i ≡ f (lookup xs i)
lookup-map f (x ∷ xs) fzero = refl
lookup-map f (x ∷ xs) (fsuc i) = lookup-map f xs i

map-id : (xs : Vec A n) → map (λ x → x) xs ≡ xs
map-id [] = refl
map-id (x ∷ xs) = eq-cong (x ∷_) (map-id xs)

map-compose : (g : B → C) (f : A → B) (xs : Vec A n) →
              map g (map f xs) ≡ map (λ x → g (f x)) xs
map-compose g f [] = refl
map-compose g f (x ∷ xs) = eq-cong (g (f x) ∷_) (map-compose g f xs)

map-tabulate : (f : A → B) (g : Fin n → A) →
               map f (tabulate g) ≡ tabulate (λ i → f (g i))
map-tabulate {n = zero} f g = refl
map-tabulate {n = suc n} f g =
  eq-cong (f (g fzero) ∷_) (map-tabulate f (λ i → g (fsuc i)))

zipWith : (A → B → C) → Vec A n → Vec B n → Vec C n
zipWith f [] [] = []
zipWith f (x ∷ xs) (y ∷ ys) = f x y ∷ zipWith f xs ys

lookup-zipWith : (f : A → B → C) (xs : Vec A n) (ys : Vec B n)
                 (i : Fin n) →
                 lookup (zipWith f xs ys) i ≡ f (lookup xs i) (lookup ys i)
lookup-zipWith f (x ∷ xs) (y ∷ ys) fzero = refl
lookup-zipWith f (x ∷ xs) (y ∷ ys) (fsuc i) = lookup-zipWith f xs ys i

replicate : {n : Nat} → A → Vec A n
replicate {n = zero} x = []
replicate {n = suc n} x = x ∷ replicate x

lookup-replicate : (x : A) (i : Fin n) → lookup (replicate x) i ≡ x
lookup-replicate x fzero = refl
lookup-replicate x (fsuc i) = lookup-replicate x i

-- Updating one coordinate is the basic operation for partial derivatives.
update : Vec A n → Fin n → A → Vec A n
update (x ∷ xs) fzero y = y ∷ xs
update (x ∷ xs) (fsuc i) y = x ∷ update xs i y

lookup-update-same : (xs : Vec A n) (i : Fin n) (x : A) →
                     lookup (update xs i x) i ≡ x
lookup-update-same (y ∷ ys) fzero x = refl
lookup-update-same (y ∷ ys) (fsuc i) x = lookup-update-same ys i x

lookup-update-other : (xs : Vec A n) (i j : Fin n) (x : A) →
                      (i ≡ j → Fin zero) →
                      lookup (update xs i x) j ≡ lookup xs j
lookup-update-other (y ∷ ys) fzero fzero x ne with ne refl
... | ()
lookup-update-other (y ∷ ys) fzero (fsuc j) x ne = refl
lookup-update-other (y ∷ ys) (fsuc i) fzero x ne = refl
lookup-update-other (y ∷ ys) (fsuc i) (fsuc j) x ne =
  lookup-update-other ys i j x (λ p → ne (eq-cong fsuc p))

update-identity : (xs : Vec A n) (i : Fin n) →
                   update xs i (lookup xs i) ≡ xs
update-identity (x ∷ xs) fzero = refl
update-identity (x ∷ xs) (fsuc i) = eq-cong (x ∷_) (update-identity xs i)

update-overwrite : (xs : Vec A n) (i : Fin n) (x y : A) →
                    update (update xs i x) i y ≡ update xs i y
update-overwrite (z ∷ zs) fzero x y = refl
update-overwrite (z ∷ zs) (fsuc i) x y =
  eq-cong (z ∷_) (update-overwrite zs i x y)

update-commute : (xs : Vec A n) (i j : Fin n) (x y : A) →
                  (i ≡ j → Fin zero) →
                  update (update xs i x) j y ≡ update (update xs j y) i x
update-commute (z ∷ zs) fzero fzero x y ne with ne refl
... | ()
update-commute (z ∷ zs) fzero (fsuc j) x y ne = refl
update-commute (z ∷ zs) (fsuc i) fzero x y ne = refl
update-commute (z ∷ zs) (fsuc i) (fsuc j) x y ne =
  eq-cong (z ∷_) (update-commute zs i j x y (λ p → ne (eq-cong fsuc p)))

map-update : (f : A → B) (xs : Vec A n) (i : Fin n) (x : A) →
              map f (update xs i x) ≡ update (map f xs) i (f x)
map-update f (y ∷ ys) fzero x = refl
map-update f (y ∷ ys) (fsuc i) x = eq-cong (f y ∷_) (map-update f ys i x)

-- Functional coordinates are convenient for R^n. No equality of functions
-- is asserted here: coordinate equations are proved at each finite index.
Tuple : Set a → Nat → Set a
Tuple A n = Fin n → A

tupleUpdate : Tuple A n → Fin n → A → Tuple A n
tupleUpdate xs i x j = lookup (update (tabulate xs) i x) j

tupleUpdate-same : (xs : Tuple A n) (i : Fin n) (x : A) →
                   tupleUpdate xs i x i ≡ x
tupleUpdate-same xs i x = lookup-update-same (tabulate xs) i x

tupleUpdate-other : (xs : Tuple A n) (i j : Fin n) (x : A) →
                    (i ≡ j → Fin zero) → tupleUpdate xs i x j ≡ xs j
tupleUpdate-other xs i j x ne =
  eq-trans (lookup-update-other (tabulate xs) i j x ne) (lookup-tabulate xs j)

tupleUpdate-identity : (xs : Tuple A n) (i j : Fin n) →
                       tupleUpdate xs i (xs i) j ≡ xs j
tupleUpdate-identity xs i j =
  eq-trans
    (eq-cong (λ z → lookup (update (tabulate xs) i z) j)
      (eq-sym (lookup-tabulate xs i)))
    (eq-trans
      (eq-cong (λ ys → lookup ys j) (update-identity (tabulate xs) i))
      (lookup-tabulate xs j))

-- Faces delete one coordinate; they supply cubical boundary combinatorics.
delete : Vec A (suc n) → Fin (suc n) → Vec A n
delete (x ∷ xs) fzero = xs
delete {n = suc n} (x ∷ xs) (fsuc i) = x ∷ delete xs i

-- Injection of the remaining indices past the deleted position.
skip : (i : Fin (suc n)) → Fin n → Fin (suc n)
skip fzero j = fsuc j
skip {n = suc n} (fsuc i) fzero = fzero
skip {n = suc n} (fsuc i) (fsuc j) = fsuc (skip i j)

lookup-delete : (xs : Vec A (suc n)) (i : Fin (suc n)) (j : Fin n) →
                lookup (delete xs i) j ≡ lookup xs (skip i j)
lookup-delete (x ∷ xs) fzero j = refl
lookup-delete {n = suc n} (x ∷ xs) (fsuc i) fzero = refl
lookup-delete {n = suc n} (x ∷ xs) (fsuc i) (fsuc j) =
  lookup-delete xs i j

-- Finite coordinate permutations, with explicit inverse witnesses.
record Permutation (n : Nat) : Set where
  constructor permutation
  field
    to from : Fin n → Fin n
    from-to : (i : Fin n) → from (to i) ≡ i
    to-from : (i : Fin n) → to (from i) ≡ i
open Permutation public

identityPerm : {n : Nat} → Permutation n
identityPerm = permutation (λ i → i) (λ i → i) (λ i → refl) (λ i → refl)

inversePerm : Permutation n → Permutation n
inversePerm p = permutation (from p) (to p) (to-from p) (from-to p)

composePerm : Permutation n → Permutation n → Permutation n
composePerm p q = permutation (λ i → to p (to q i)) (λ i → from q (from p i))
  (λ i → eq-trans (eq-cong (from q) (from-to p (to q i))) (from-to q i))
  (λ i → eq-trans (eq-cong (to p) (to-from q (from p i))) (to-from p i))

liftPerm : Permutation n → Permutation (suc n)
liftPerm p = permutation f g gf fg
  where
  f : Fin (suc _) → Fin (suc _)
  f fzero = fzero
  f (fsuc i) = fsuc (to p i)

  g : Fin (suc _) → Fin (suc _)
  g fzero = fzero
  g (fsuc i) = fsuc (from p i)

  gf : (i : Fin (suc _)) → g (f i) ≡ i
  gf fzero = refl
  gf (fsuc i) = eq-cong fsuc (from-to p i)

  fg : (i : Fin (suc _)) → f (g i) ≡ i
  fg fzero = refl
  fg (fsuc i) = eq-cong fsuc (to-from p i)

swapFirst : {n : Nat} → Permutation (suc (suc n))
swapFirst {n} = permutation swap swap involution involution
  where
  swap : Fin (suc (suc n)) → Fin (suc (suc n))
  swap fzero = fsuc fzero
  swap (fsuc fzero) = fzero
  swap (fsuc (fsuc i)) = fsuc (fsuc i)

  involution : (i : Fin (suc (suc n))) → swap (swap i) ≡ i
  involution fzero = refl
  involution (fsuc fzero) = refl
  involution (fsuc (fsuc i)) = refl

permute : Permutation n → Vec A n → Vec A n
permute p xs = tabulate (λ i → lookup xs (to p i))

lookup-permute : (p : Permutation n) (xs : Vec A n) (i : Fin n) →
  lookup (permute p xs) i ≡ lookup xs (to p i)
lookup-permute p xs = lookup-tabulate (λ i → lookup xs (to p i))

permute-identity : (xs : Vec A n) → permute identityPerm xs ≡ xs
permute-identity = tabulate-lookup

permute-compose : (p q : Permutation n) (xs : Vec A n) →
  permute p (permute q xs) ≡ permute (composePerm q p) xs
permute-compose p q xs = vec-ext (λ i →
  eq-trans (lookup-permute p (permute q xs) i)
    (eq-trans (lookup-permute q xs (to p i))
      (eq-sym (lookup-permute (composePerm q p) xs i))))

permute-inverse : (p : Permutation n) (xs : Vec A n) →
  permute (inversePerm p) (permute p xs) ≡ xs
permute-inverse p xs = vec-ext (λ i →
  eq-trans (lookup-permute (inversePerm p) (permute p xs) i)
    (eq-trans (lookup-permute p xs (from p i))
      (eq-cong (lookup xs) (to-from p i))))

permute-lift : (p : Permutation n) (x : A) (xs : Vec A n) →
  permute (liftPerm p) (x ∷ xs) ≡ x ∷ permute p xs
permute-lift p x xs = refl

permute-swapFirst : (x y : A) (xs : Vec A n) →
  permute swapFirst (x ∷ y ∷ xs) ≡ y ∷ x ∷ xs
permute-swapFirst x y xs = eq-cong (λ zs → y ∷ x ∷ zs) (tabulate-lookup xs)

-- Elementary natural-number facts and factorial for Taylor coefficients.
nat-add-zeroʳ : (n : Nat) → n +ℕ zero ≡ n
nat-add-zeroʳ zero = refl
nat-add-zeroʳ (suc n) = eq-cong suc (nat-add-zeroʳ n)

nat-add-sucʳ : (n m : Nat) → n +ℕ suc m ≡ suc (n +ℕ m)
nat-add-sucʳ zero m = refl
nat-add-sucʳ (suc n) m = eq-cong suc (nat-add-sucʳ n m)

nat-add-assoc : (n m k : Nat) → (n +ℕ m) +ℕ k ≡ n +ℕ (m +ℕ k)
nat-add-assoc zero m k = refl
nat-add-assoc (suc n) m k = eq-cong suc (nat-add-assoc n m k)

nat-add-comm : (n m : Nat) → n +ℕ m ≡ m +ℕ n
nat-add-comm zero m = eq-sym (nat-add-zeroʳ m)
nat-add-comm (suc n) m =
  eq-trans (eq-cong suc (nat-add-comm n m)) (eq-sym (nat-add-sucʳ m n))

nat-suc-injective : {n m : Nat} → suc n ≡ suc m → n ≡ m
nat-suc-injective refl = refl

nat-add-cancelˡ : (k : Nat) {n m : Nat} → k +ℕ n ≡ k +ℕ m → n ≡ m
nat-add-cancelˡ zero p = p
nat-add-cancelˡ (suc k) p = nat-add-cancelˡ k (nat-suc-injective p)

factorial : Nat → Nat
factorial zero = suc zero
factorial (suc n) = suc n *ℕ factorial n

-- Pascal recursion, with zero outside the triangular range.
binomial : Nat → Nat → Nat
binomial zero zero = suc zero
binomial zero (suc k) = zero
binomial (suc n) zero = suc zero
binomial (suc n) (suc k) = binomial n k +ℕ binomial n (suc k)

binomial-zero : (n : Nat) → binomial n zero ≡ suc zero
binomial-zero zero = refl
binomial-zero (suc n) = refl

