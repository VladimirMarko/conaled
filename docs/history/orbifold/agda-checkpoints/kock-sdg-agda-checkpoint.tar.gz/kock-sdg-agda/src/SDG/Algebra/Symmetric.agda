{-# OPTIONS --safe --without-K #-}

-- Elementary symmetric polynomials and the square-zero sum formula.
-- This module uses commutative ring laws only; no KL or rational inverses.
module SDG.Algebra.Symmetric where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; map)

infix 4 _≤_
data _≤_ : ℕ → ℕ → Set where
  z≤n : {n : ℕ} → zero ≤ n
  s≤s : {m n : ℕ} → m ≤ n → suc m ≤ suc n

≤-refl : (n : ℕ) → n ≤ n
≤-refl zero = z≤n
≤-refl (suc n) = s≤s (≤-refl n)

≤-step : {m n : ℕ} → m ≤ n → m ≤ suc n
≤-step z≤n = z≤n
≤-step (s≤s p) = s≤s (≤-step p)

module Elementary {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  vectorSum : {n : ℕ} → Vec R n → R
  vectorSum [] = 0r
  vectorSum (x ∷ xs) = x + vectorSum xs

  -- The recurrence enumerates subsets without introducing ordered tuples
  -- with repeated indices. Degree zero has the empty product as its value.
  elementary : {n : ℕ} → ℕ → Vec R n → R
  elementary zero xs = 1r
  elementary (suc q) [] = 0r
  elementary (suc q) (x ∷ xs) = elementary (suc q) xs + x * elementary q xs

  elementary-above-dimension : {n : ℕ} (q : ℕ) (xs : Vec R n) →
    suc n ≤ q → elementary q xs ≡ 0r
  elementary-above-dimension zero xs ()
  elementary-above-dimension (suc q) [] p = refl
  elementary-above-dimension (suc q) (x ∷ xs) (s≤s p) =
    trans (cong₂ _+_
      (elementary-above-dimension (suc q) xs (≤-step p))
      (trans (cong (x *_) (elementary-above-dimension q xs p)) (*-zeroʳ x)))
      (+-identityˡ 0r)

  elementary-first : {n : ℕ} (xs : Vec R n) → elementary (suc zero) xs ≡ vectorSum xs
  elementary-first [] = refl
  elementary-first (x ∷ xs) =
    trans (cong₂ _+_ (elementary-first xs) (*-identityʳ x))
      (+-comm (vectorSum xs) x)

  product : {n : ℕ} → Vec R n → R
  product [] = 1r
  product (x ∷ xs) = x * product xs

  elementary-top : {n : ℕ} (xs : Vec R n) → elementary n xs ≡ product xs
  elementary-top [] = refl
  elementary-top {suc n} (x ∷ xs) =
    trans (cong₂ _+_
      (elementary-above-dimension (suc n) xs (≤-refl (suc n)))
      (cong (x *_) (elementary-top xs)))
      (+-identityˡ (x * product xs))

module InfinitesimalSums {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A
  open Infinitesimals A
  open Elementary A

  scalarValues : {n : ℕ} → Vec D n → Vec R n
  scalarValues = map value

  sumD : {n : ℕ} → Vec D n → R
  sumD ds = vectorSum (scalarValues ds)

  sigmaD : {n : ℕ} → ℕ → Vec D n → R
  sigmaD q ds = elementary q (scalarValues ds)

  -- Exercise I.3.1: a stronger uniform statement, valid also above degree n.
  -- At high degrees sigmaD vanishes, giving the stated zero-power clause.
  sum-power : {n : ℕ} (ds : Vec D n) (q : ℕ) →
    sumD ds ^ q ≡ factorial q * sigmaD q ds
  sum-power [] zero = sym (*-identityˡ 1r)
  sum-power [] (suc q) =
    trans (zero-positive-power q) (sym (*-zeroʳ (factorial (suc q))))
  sum-power (d ∷ ds) zero = sym (*-identityˡ 1r)
  sum-power (d ∷ ds) (suc q) =
    begin
      (value d + sumD ds) ^ suc q
    ≡⟨ cong (_^ suc q) (+-comm (value d) (sumD ds)) ⟩
      (sumD ds + value d) ^ suc q
    ≡⟨ power-first-order (sumD ds) (value d) q (square-zero d) ⟩
      (sumD ds ^ suc q) + value d * (fromℕ (suc q) * (sumD ds ^ q))
    ≡⟨ cong₂ _+_ (sum-power ds (suc q))
        (cong (λ z → value d * (fromℕ (suc q) * z)) (sum-power ds q)) ⟩
      (factorial (suc q) * sigmaD (suc q) ds) +
        value d * (fromℕ (suc q) * (factorial q * sigmaD q ds))
    ≡⟨ cong ((factorial (suc q) * sigmaD (suc q) ds) +_)
        (trans (cong (value d *_) (sym (*-assoc (fromℕ (suc q)) (factorial q) (sigmaD q ds))))
          (*-swap (value d) (factorial (suc q)) (sigmaD q ds))) ⟩
      (factorial (suc q) * sigmaD (suc q) ds) +
        factorial (suc q) * (value d * sigmaD q ds)
    ≡⟨ sym (distribˡ (factorial (suc q)) (sigmaD (suc q) ds) (value d * sigmaD q ds)) ⟩
      factorial (suc q) * sigmaD (suc q) (d ∷ ds) ∎

  sum-power-above-dimension : {n : ℕ} (ds : Vec D n) (q : ℕ) →
    suc n ≤ q → sumD ds ^ q ≡ 0r
  sum-power-above-dimension ds q p =
    trans (sum-power ds q)
      (trans (cong (factorial q *_) (elementary-above-dimension q (scalarValues ds) p))
        (*-zeroʳ (factorial q)))

  sum-nilpotent : {n : ℕ} (ds : Vec D n) → sumD ds ^ suc n ≡ 0r
  sum-nilpotent {n} ds = sum-power-above-dimension ds (suc n) (≤-refl (suc n))

  sum-top-power : {n : ℕ} (ds : Vec D n) →
    sumD ds ^ n ≡ factorial n * product (scalarValues ds)
  sum-top-power {n} ds =
    trans (sum-power ds n) (cong (factorial n *_) (elementary-top (scalarValues ds)))
