{-# OPTIONS --safe --without-K #-}

module SDG.Forms.CubicalGeometry where

open import SDG.Prelude
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; fsuc-injective;
  lookup; update; delete; skip; vec-ext; Permutation; permutation; to; from;
  from-to; to-from; permute; lookup-permute)
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Forms.Basic

-- Generic coordinate insertion. The deleted coordinate occupies its
-- original position; all remaining coordinates keep their relative order.
insert : {a : Level} {X : Set a} {n : ℕ} → Fin (suc n) → X → Vec X n → Vec X (suc n)
insert fzero x xs = x ∷ xs
insert {n = suc n} (fsuc i) x (y ∷ ys) = y ∷ insert i x ys

lookup-insert-own : {a : Level} {X : Set a} {n : ℕ}
  (i : Fin (suc n)) (x : X) (xs : Vec X n) → lookup (insert i x xs) i ≡ x
lookup-insert-own fzero x xs = refl
lookup-insert-own {n = suc n} (fsuc i) x (y ∷ ys) = lookup-insert-own i x ys

lookup-insert-other : {a : Level} {X : Set a} {n : ℕ}
  (i : Fin (suc n)) (x : X) (xs : Vec X n) (j : Fin n) → lookup (insert i x xs) (skip i j) ≡ lookup xs j
lookup-insert-other fzero x xs j = refl
lookup-insert-other {n = suc n} (fsuc i) x (y ∷ ys) fzero = refl
lookup-insert-other {n = suc n} (fsuc i) x (y ∷ ys) (fsuc j) = lookup-insert-other i x ys j

delete-insert : {a : Level} {X : Set a} {n : ℕ}
  (i : Fin (suc n)) (x : X) (xs : Vec X n) → delete (insert i x xs) i ≡ xs
delete-insert fzero x xs = refl
delete-insert {n = suc n} (fsuc i) x (y ∷ ys) = cong (y ∷_) (delete-insert i x ys)

insert-delete : {a : Level} {X : Set a} {n : ℕ} (xs : Vec X (suc n)) (i : Fin (suc n)) →
  insert i (lookup xs i) (delete xs i) ≡ xs
insert-delete (x ∷ xs) fzero = refl
insert-delete {n = suc n} (x ∷ xs) (fsuc i) = cong (x ∷_) (insert-delete xs i)

update-insert-own : {a : Level} {X : Set a} {n : ℕ}
  (i : Fin (suc n)) (x y : X) (xs : Vec X n) → update (insert i x xs) i y ≡ insert i y xs
update-insert-own fzero x y xs = refl
update-insert-own {n = suc n} (fsuc i) x y (z ∷ zs) = cong (z ∷_) (update-insert-own i x y zs)

update-insert-other : {a : Level} {X : Set a} {n : ℕ}
  (i : Fin (suc n)) (x : X) (xs : Vec X n) (j : Fin n) (y : X) →
  update (insert i x xs) (skip i j) y ≡ insert i x (update xs j y)
update-insert-other fzero x xs j y = refl
update-insert-other {n = suc n} (fsuc i) x (z ∷ zs) fzero y = refl
update-insert-other {n = suc n} (fsuc i) x (z ∷ zs) (fsuc j) y = cong (z ∷_) (update-insert-other i x zs j y)

skip-injective : {n : ℕ} (i : Fin (suc n)) {j k : Fin n} → skip i j ≡ skip i k → j ≡ k
skip-injective fzero p = fsuc-injective p
skip-injective {n = suc n} (fsuc i) {fzero} {fzero} p = refl
skip-injective {n = suc n} (fsuc i) {fzero} {fsuc k} ()
skip-injective {n = suc n} (fsuc i) {fsuc j} {fzero} ()
skip-injective {n = suc n} (fsuc i) {fsuc j} {fsuc k} p = cong fsuc (skip-injective i (fsuc-injective p))

skip-distinct : {n : ℕ} (i : Fin (suc n)) (j : Fin n) → skip i j ≢ i
skip-distinct fzero j ()
skip-distinct {n = suc n} (fsuc i) fzero ()
skip-distinct {n = suc n} (fsuc i) (fsuc j) p = skip-distinct i j (fsuc-injective p)

data Position {n : ℕ} (i : Fin (suc n)) : Fin (suc n) → Set where
  selected : Position i i
  remaining : (j : Fin n) → Position i (skip i j)

position : {n : ℕ} (i j : Fin (suc n)) → Position i j
position fzero fzero = selected
position fzero (fsuc j) = remaining j
position {n = suc n} (fsuc i) fzero = remaining fzero
position {n = suc n} (fsuc i) (fsuc j) with position i j
... | selected = selected
... | remaining k = remaining (fsuc k)

index-cases : {a : Level} {n : ℕ} (i : Fin (suc n)) (P : Fin (suc n) → Set a) →
  P i → ((j : Fin n) → P (skip i j)) → (k : Fin (suc n)) → P k
index-cases i P selected-case remaining-case k with position i k
... | selected = selected-case
... | remaining j = remaining-case j

unskip : {n : ℕ} (i j : Fin (suc n)) → j ≢ i → Fin n
unskip fzero fzero ne = ⊥-elim (ne refl)
unskip fzero (fsuc j) ne = j
unskip {n = suc n} (fsuc i) fzero ne = fzero
unskip {n = suc n} (fsuc i) (fsuc j) ne = fsuc (unskip i j (λ p → ne (cong fsuc p)))

skip-unskip : {n : ℕ} (i j : Fin (suc n)) (ne : j ≢ i) → skip i (unskip i j ne) ≡ j
skip-unskip fzero fzero ne = ⊥-elim (ne refl)
skip-unskip fzero (fsuc j) ne = refl
skip-unskip {n = suc n} (fsuc i) fzero ne = refl
skip-unskip {n = suc n} (fsuc i) (fsuc j) ne = cong fsuc (skip-unskip i j (λ p → ne (cong fsuc p)))

unskip-skip : {n : ℕ} (i : Fin (suc n)) (j : Fin n) (ne : skip i j ≢ i) → unskip i (skip i j) ne ≡ j
unskip-skip i j ne = skip-injective i (skip-unskip i (skip i j) ne)

-- The permutation induced on a face. For p and the coordinate i removed
-- from its input, the removed output coordinate is from p i.
module Minor {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) where
  removed : Fin (suc n)
  removed = from p i

  forward-distinct : (k : Fin n) → to p (skip removed k) ≢ i
  forward-distinct k eq = skip-distinct removed k
    (trans (sym (from-to p (skip removed k))) (cong (from p) eq))

  backward-distinct : (k : Fin n) → from p (skip i k) ≢ removed
  backward-distinct k eq = skip-distinct i k
    (trans (sym (to-from p (skip i k))) (trans (cong (to p) eq) (to-from p i)))

  forward backward : Fin n → Fin n
  forward k = unskip i (to p (skip removed k)) (forward-distinct k)
  backward k = unskip removed (from p (skip i k)) (backward-distinct k)

  forward-reconstruct : (k : Fin n) → skip i (forward k) ≡ to p (skip removed k)
  forward-reconstruct k = skip-unskip i (to p (skip removed k)) (forward-distinct k)

  backward-reconstruct : (k : Fin n) → skip removed (backward k) ≡ from p (skip i k)
  backward-reconstruct k = skip-unskip removed (from p (skip i k)) (backward-distinct k)

  backward-forward : (k : Fin n) → backward (forward k) ≡ k
  backward-forward k = skip-injective removed
    (trans (backward-reconstruct (forward k))
      (trans (cong (from p) (forward-reconstruct k)) (from-to p (skip removed k))))

  forward-backward : (k : Fin n) → forward (backward k) ≡ k
  forward-backward k = skip-injective i
    (trans (forward-reconstruct (backward k))
      (trans (cong (to p) (backward-reconstruct k)) (to-from p (skip i k))))

  minor : Permutation n
  minor = permutation forward backward backward-forward forward-backward

  permute-insert : {a : Level} {X : Set a} (x : X) (xs : Vec X n) →
    permute p (insert i x xs) ≡ insert removed x (permute minor xs)
  permute-insert x xs = vec-ext (index-cases removed
    (λ k → lookup (permute p (insert i x xs)) k ≡ lookup (insert removed x (permute minor xs)) k)
    (trans (lookup-permute p (insert i x xs) removed)
      (trans (cong (lookup (insert i x xs)) (to-from p i))
        (trans (lookup-insert-own i x xs) (sym (lookup-insert-own removed x (permute minor xs))))))
    (λ k → trans (lookup-permute p (insert i x xs) (skip removed k))
      (trans (cong (lookup (insert i x xs)) (sym (forward-reconstruct k)))
        (trans (lookup-insert-other i x xs (forward k))
          (trans (sym (lookup-permute minor xs k)) (sym (lookup-insert-other removed x (permute minor xs) k)))))))

minor : {n : ℕ} → Permutation (suc n) → Fin (suc n) → Permutation n
minor = Minor.minor

module Faces {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Cubes A public

  face : {n : ℕ} {M : Set ℓ} → Cube (suc n) M → Fin (suc n) → D → Cube n M
  face τ i d ds = τ (insert i d ds)

  scale-insert-own : {n : ℕ} (i : Fin (suc n)) (d : D) (ds : Vec D n) (r : R) →
    scale-coordinates (insert i d ds) i r ≡ insert i (scaleD d r) ds
  scale-insert-own i d ds r = trans
    (cong (update (insert i d ds) i) (cong (λ e → scaleD e r) (lookup-insert-own i d ds)))
    (update-insert-own i d (scaleD d r) ds)

  scale-insert-other : {n : ℕ} (i : Fin (suc n)) (d : D) (ds : Vec D n) (j : Fin n) (r : R) →
    scale-coordinates (insert i d ds) (skip i j) r ≡ insert i d (scale-coordinates ds j r)
  scale-insert-other i d ds j r = trans
    (cong (update (insert i d ds) (skip i j)) (cong (λ e → scaleD e r) (lookup-insert-other i d ds j)))
    (update-insert-other i d ds j (scaleD (lookup ds j) r))

  face-scale-own : (ext : FunExt ℓ ℓ) {n : ℕ} {M : Set ℓ}
    (τ : Cube (suc n) M) (i : Fin (suc n)) (r : R) (d : D) →
    face (scale-cube τ i r) i d ≡ face τ i (scaleD d r)
  face-scale-own ext τ i r d = ext (λ ds → cong τ (scale-insert-own i d ds r))

  face-scale-other : (ext : FunExt ℓ ℓ) {n : ℕ} {M : Set ℓ}
    (τ : Cube (suc n) M) (i : Fin (suc n)) (j : Fin n) (r : R) (d : D) →
    face (scale-cube τ (skip i j) r) i d ≡ scale-cube (face τ i d) j r
  face-scale-other ext τ i j r d = ext (λ ds → cong τ (scale-insert-other i d ds j r))

  face-permute : (ext : FunExt ℓ ℓ) {n : ℕ} {M : Set ℓ}
    (τ : Cube (suc n) M) (p : Permutation (suc n)) (i : Fin (suc n)) (d : D) →
    face (permute-cube τ p) i d ≡ permute-cube (face τ (from p i) d) (minor p i)
  face-permute ext τ p i d = ext (λ ds → cong τ (Minor.permute-insert p i d ds))

  face-map : {n : ℕ} {M N : Set ℓ} (f : M → N) (τ : Cube (suc n) M)
    (i : Fin (suc n)) (d : D) → face (map-cube f τ) i d ≡ map-cube f (face τ i d)
  face-map f τ i d = refl
