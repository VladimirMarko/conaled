{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Finite using (Fin; fzero; fsuc)
open import SDG.Schemes.Isomorphism
open import SDG.Schemes.Extensionality
import SDG.Schemes.Reflexivity as Ref

-- Internal-language formulation of I.12 for set-valued objects. The base
-- coefficient ring k may live in a different universe. Equation witnesses
-- in Spec are proof-irrelevant because the algebra carrier is a set; this
-- is explicit under --without-K. Arbitrary-category semantics is separate.
module Comprehensive {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A)) where
  open CRing A using (R)
  open Presentations k
  open Ref.Reflexivity A ext setR

  coefficient-map : (C : RAlgebra A ℓ) → CRing.R k → CRing.R (ring C)
  coefficient-map C a = RingHom.hom (unit C) (RingHom.hom base a)

  SpecC : RAlgebra A ℓ → Presentation → Set ℓ
  SpecC C B = Spec (ring C) (coefficient-map C) B

  Affine : Presentation → Set ℓ
  Affine B = Spec A (RingHom.hom base) B

  affine-set : (B : Presentation) → isSet (Affine B)
  affine-set B = injection-set coordinates
    (λ eq → spec-path ext0 setR (λ i → cong (λ xs → xs i) eq))
    (function-set ext0 (λ _ → setR))

  coordinate-function : (B : Presentation) → Fin (generators B) → Affine B → R
  coordinate-function B i x = coordinates x i

  evaluate-functions : (X : Set ℓ) {n : ℕ} (p : Polynomial n)
    (xs : Fin n → X → R) (x : X) →
    evaluate (ring (functionAlgebra A X ext)) (coefficient-map (functionAlgebra A X ext)) p xs x ≡
      evaluate A (RingHom.hom base) p (λ i → xs i x)
  evaluate-functions X (coefficient a) xs x = refl
  evaluate-functions X (var i) xs x = refl
  evaluate-functions X (p ⊕ q) xs x =
    cong₂ (CRing._+_ A) (evaluate-functions X p xs x) (evaluate-functions X q xs x)
  evaluate-functions X (p ⊗ q) xs x =
    cong₂ (CRing._*_ A) (evaluate-functions X p xs x) (evaluate-functions X q xs x)
  evaluate-functions X (negative p) xs x = cong (CRing.-_ A) (evaluate-functions X p xs x)

  -- The canonical map of (12.2) is constructed from coordinate functions.
  -- Polynomial equations are verified using preservation by the algebra
  -- homomorphism, rather than supplied in an axiom field.
  canonical : (B : Presentation) (C : RAlgebra A ℓ) →
    AlgHom (functionAlgebra A (Affine B) ext) C → SpecC C B
  coordinates (canonical B C h) i = algMap h (coordinate-function B i)
  satisfies (canonical B C h) j =
    trans (sym (evaluate-hom (ring (functionAlgebra A (Affine B) ext)) (ring C)
      (coefficient-map (functionAlgebra A (Affine B) ext)) (coefficient-map C)
      (ringHom h) (λ a → commutes h (RingHom.hom base a))
      (equations B j) (coordinate-function B)))
      (trans (cong (algMap h) (ext (λ x →
        trans (evaluate-functions (Affine B) (equations B j) (coordinate-function B) x)
          (satisfies x j)))) (RingHom.pres-0 (ringHom h)))

  -- Axiom 2_k asserts exactly that the displayed canonical map is
  -- invertible. No reflexivity, tangent, or free-algebra consequence is
  -- included among its fields.
  record Axiom2 : Set (lsuc (κ ⊔ ℓ)) where
    field
      inverse-canonical : (B : Presentation) (C : RAlgebra A ℓ) →
        isSet (CRing.R (ring C)) → SpecC C B → AlgHom (functionAlgebra A (Affine B) ext) C
      canonical-inverse : (B : Presentation) (C : RAlgebra A ℓ)
        (setC : isSet (CRing.R (ring C))) (x : SpecC C B) →
        canonical B C (inverse-canonical B C setC x) ≡ x
      inverse-canonical-law : (B : Presentation) (C : RAlgebra A ℓ)
        (setC : isSet (CRing.R (ring C)))
        (h : AlgHom (functionAlgebra A (Affine B) ext) C) →
        inverse-canonical B C setC (canonical B C h) ≡ h

  -- The preliminary identity Spec_(R^X)(B) ≅ Spec_R(B)^X, explicitly.
  spec-evaluate : (B : Presentation) (X : Set ℓ) → SpecC (functionAlgebra A X ext) B → X → Affine B
  coordinates (spec-evaluate B X p x) i = coordinates p i x
  satisfies (spec-evaluate B X p x) j =
    trans (sym (evaluate-functions X (equations B j) (coordinates p) x))
      (cong (λ f → f x) (satisfies p j))

  spec-assemble : (B : Presentation) (X : Set ℓ) → (X → Affine B) → SpecC (functionAlgebra A X ext) B
  coordinates (spec-assemble B X f) i x = coordinates (f x) i
  satisfies (spec-assemble B X f) j = ext (λ x →
    trans (evaluate-functions X (equations B j) (λ i y → coordinates (f y) i) x)
      (satisfies (f x) j))

  spec-evaluate-assemble : (B : Presentation) (X : Set ℓ) (f : X → Affine B) →
    spec-evaluate B X (spec-assemble B X f) ≡ f
  spec-evaluate-assemble B X f = ext (λ x → spec-path ext0 setR (λ i → refl))

  spec-assemble-evaluate : (B : Presentation) (X : Set ℓ)
    (p : SpecC (functionAlgebra A X ext) B) → spec-assemble B X (spec-evaluate B X p) ≡ p
  spec-assemble-evaluate B X p = spec-path ext0 (function-set ext (λ _ → setR)) (λ i → refl)

  spec-exponential : (B : Presentation) (X : Set ℓ) →
    Isomorphism (SpecC (functionAlgebra A X ext) B) (X → Affine B)
  spec-exponential B X = isomorphism (spec-evaluate B X) (spec-assemble B X)
    (spec-assemble-evaluate B X) (spec-evaluate-assemble B X)

  canonical-precomposition : (B : Presentation) (X : Set ℓ) (f : X → Affine B) →
    canonical B (functionAlgebra A X ext) (precomposition A ext f) ≡ spec-assemble B X f
  canonical-precomposition B X f = spec-path ext0 (function-set ext (λ _ → setR)) (λ i → refl)

  module Consequences (Ax : Axiom2) where
    open Axiom2 Ax

    canonical-injective : (B : Presentation) (C : RAlgebra A ℓ)
      (setC : isSet (CRing.R (ring C)))
      {f g : AlgHom (functionAlgebra A (Affine B) ext) C} →
      canonical B C f ≡ canonical B C g → f ≡ g
    canonical-injective B C setC {f} {g} p =
      trans (sym (inverse-canonical-law B C setC f))
        (trans (cong (inverse-canonical B C setC) p) (inverse-canonical-law B C setC g))

    -- Corollary 12.3, with evaluation itself as the forward map.
    affine-reflexive : (B : Presentation) → Reflexive (Affine B)
    recover (affine-reflexive B) = canonical B (scalarAlgebra A)
    recover-evaluation (affine-reflexive B) m = spec-path ext0 setR (λ i → refl)
    evaluation-recover (affine-reflexive B) h = canonical-injective B (scalarAlgebra A) setR
      (spec-path ext0 setR (λ i → refl))

    reflexivity-isomorphism : (B : Presentation) → Isomorphism (Affine B) (DoubleDual (Affine B))
    reflexivity-isomorphism B = reflexive-isomorphism (affine-reflexive B)

    -- Theorem 12.2. The inverse is fully constructed; its forward map is
    -- exactly f ↦ (g ↦ g ∘ f), including all algebra-homomorphism laws.
    affine-map-isomorphism : (B : Presentation) (X : Set ℓ) →
      Isomorphism (X → Affine B)
        (AlgHom (functionAlgebra A (Affine B) ext) (functionAlgebra A X ext))
    affine-map-isomorphism B X = parameterized-isomorphism (affine-reflexive B) X

    -- Proposition 12.6: freeness on id_R, derived from the line presentation.
    free-extension : (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C))) →
      CRing.R (ring C) → AlgHom (functionAlgebra A R ext) C
    free-extension C setC c = composeAlgHom
      (inverse-canonical line C setC (line-point (ring C) (coefficient-map C) c))
      (precomposition A ext (line-value {C = A} {ι = RingHom.hom base}))

    free-extension-generator : (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C)))
      (c : CRing.R (ring C)) → algMap (free-extension C setC c) id ≡ c
    free-extension-generator C setC c = cong line-value
      (canonical-inverse line C setC (line-point (ring C) (coefficient-map C) c))

    generator-detects : (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C)))
      (f g : AlgHom (functionAlgebra A R ext) C) → algMap f id ≡ algMap g id → f ≡ g
    generator-detects C setC f g p = algHom-ext ext ext ext setC
      (λ h → cong (λ α → algMap α (λ x → h (line-value x)))
        (canonical-injective line C setC
          {f = composeAlgHom f (precomposition A ext (line-point A (RingHom.hom base)))}
          {g = composeAlgHom g (precomposition A ext (line-point A (RingHom.hom base)))}
          (spec-path ext0 setC λ { fzero → p ; (fsuc ()) })))

    free-algebra-isomorphism : (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C))) →
      Isomorphism (AlgHom (functionAlgebra A R ext) C) (CRing.R (ring C))
    free-algebra-isomorphism C setC = isomorphism (λ h → algMap h id) (free-extension C setC)
      (λ h → generator-detects C setC (free-extension C setC (algMap h id)) h
        (free-extension-generator C setC (algMap h id)))
      (free-extension-generator C setC)
