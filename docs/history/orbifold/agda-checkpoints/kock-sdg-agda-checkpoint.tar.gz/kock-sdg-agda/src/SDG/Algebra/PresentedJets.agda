{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.PresentedJets where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Presented
open import SDG.Finite using (Fin; fzero)
open import SDG.Schemes.FiniteBlocks

module JetPresentations {κ : Level} (k : CRing κ) where
  open Presentations k

  polynomial-power : {n : ℕ} → Polynomial n → ℕ → Polynomial n
  polynomial-power p zero = oneP
  polynomial-power p (suc q) = p ⊗ polynomial-power p q

  evaluate-power : {c : Level} (C : CRing c) (ι : RingHom k C)
    {n : ℕ} (p : Polynomial n) (q : ℕ) (xs : Fin n → CRing.R C) →
    evaluate C (RingHom.hom ι) (polynomial-power p q) xs ≡ PowerLemmas._^_ C (evaluate C (RingHom.hom ι) p xs) q
  evaluate-power C ι p zero xs = RingHom.pres-1 ι
  evaluate-power C ι p (suc q) xs = cong (CRing._*_ C (evaluate C (RingHom.hom ι) p xs))
    (evaluate-power C ι p q xs)

  truncated-line : ℕ → Presentation
  truncated-line k = presented (suc zero) (suc zero) (λ _ → polynomial-power (var fzero) (suc k))

  pair-sizes : (n : ℕ) → Fin n → ℕ
  pair-sizes n i = n

  first-order : ℕ → Presentation
  first-order n = presented n (total (pair-sizes n)) (λ j →
    var (fst (splitIndex (pair-sizes n) j)) ⊗ var (snd (splitIndex (pair-sizes n) j)))

  pair-equation : (n : ℕ) (i j : Fin n) →
    equations (first-order n) (injectIndex (pair-sizes n) i j) ≡ var i ⊗ var j
  pair-equation n i j = cong (λ ij → var (fst ij) ⊗ var (snd ij)) (split-inject (pair-sizes n) i j)
