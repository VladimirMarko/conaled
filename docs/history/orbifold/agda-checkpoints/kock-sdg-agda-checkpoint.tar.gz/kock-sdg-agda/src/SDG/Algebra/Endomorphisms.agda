{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Endomorphisms where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra

record LieAlgebra {a v : Level} (A : CRing a) (M : RModule A v) : Set (a ⊔ v) where
  open RModule M
  field
    bracket : V → V → V
    bracket-addˡ : (x y z : V) → bracket (x +v y) z ≡ bracket x z +v bracket y z
    bracket-addʳ : (x y z : V) → bracket x (y +v z) ≡ bracket x y +v bracket x z
    bracket-scaleˡ : (r : CRing.R A) (x y : V) → bracket (r • x) y ≡ r • bracket x y
    bracket-scaleʳ : (r : CRing.R A) (x y : V) → bracket x (r • y) ≡ r • bracket x y
    alternating : (x : V) → bracket x x ≡ 0v
    skew : (x y : V) → bracket x y +v bracket y x ≡ 0v
    jacobi : (x y z : V) →
      (bracket x (bracket y z) +v bracket y (bracket z x)) +v bracket z (bracket x y) ≡ 0v

-- No extensionality or proof irrelevance is needed for these pointwise
-- algebraic identities. Native equality-valued structures are packaged
-- separately at the end, with their logical hypotheses explicit.
module Endomorphisms {a v : Level} (A : CRing a) (M : RModule A v) where
  open Extra A M public

  record End : Set (a ⊔ v) where
    constructor linear
    field
      run : V → V
      additive : (x y : V) → run (x +v y) ≡ run x +v run y
      homogeneous : (r : R) (x : V) → run (r • x) ≡ r • run x
  open End public

  infix 4 _≈_
  _≈_ : End → End → Set v
  f ≈ g = (x : V) → run f x ≡ run g x

  zeroEnd : End
  run zeroEnd x = 0v
  additive zeroEnd x y = sym (add-zeroˡ 0v)
  homogeneous zeroEnd r x = sym (scalar-zero r)

  identity : End
  run identity x = x
  additive identity x y = refl
  homogeneous identity r x = refl

  add : End → End → End
  run (add f g) x = run f x +v run g x
  additive (add f g) x y =
    trans (cong₂ _+v_ (additive f x y) (additive g x y))
      (add-shuffle (run f x) (run f y) (run g x) (run g y))
  homogeneous (add f g) r x =
    trans (cong₂ _+v_ (homogeneous f r x) (homogeneous g r x))
      (sym (scalar-distrib r (run f x) (run g x)))

  neg : End → End
  run (neg f) x = -v run f x
  additive (neg f) x y = trans (cong -v_ (additive f x y)) (v-neg-add (run f x) (run f y))
  homogeneous (neg f) r x = trans (cong -v_ (homogeneous f r x)) (sym (scalar-neg r (run f x)))

  sub : End → End → End
  sub f g = add f (neg g)

  scale : R → End → End
  run (scale r f) x = r • run f x
  additive (scale r f) x y = trans (cong (r •_) (additive f x y))
    (scalar-distrib r (run f x) (run f y))
  homogeneous (scale r f) s x = trans (cong (r •_) (homogeneous f s x))
    (scalar-commute r s (run f x))

  compose : End → End → End
  run (compose f g) x = run f (run g x)
  additive (compose f g) x y = trans (cong (run f) (additive g x y))
    (additive f (run g x) (run g y))
  homogeneous (compose f g) r x = trans (cong (run f) (homogeneous g r x))
    (homogeneous f r (run g x))

  bracket : End → End → End
  bracket f g = sub (compose f g) (compose g f)

  run-zero : (f : End) → run f 0v ≡ 0v
  run-zero f = trans (cong (run f) (sym (scalar-zero 0r)))
    (trans (homogeneous f 0r 0v) (zero-scalar (run f 0v)))

  run-neg : (f : End) (x : V) → run f (-v x) ≡ (-v run f x)
  run-neg f x = v-neg-unique (run f x) (run f (-v x))
    (trans (sym (additive f x (-v x)))
      (trans (cong (run f) (add-inverseʳ x)) (run-zero f)))

  run-sub : (f : End) (x y : V) → run f (x -v y) ≡ run f x -v run f y
  run-sub f x y = trans (additive f x (-v y)) (cong (run f x +v_) (run-neg f y))

  add-cong : {f f′ g g′ : End} → f ≈ f′ → g ≈ g′ → add f g ≈ add f′ g′
  add-cong p q x = cong₂ _+v_ (p x) (q x)

  neg-cong : {f g : End} → f ≈ g → neg f ≈ neg g
  neg-cong p x = cong -v_ (p x)

  scale-cong : (r : R) {f g : End} → f ≈ g → scale r f ≈ scale r g
  scale-cong r p x = cong (r •_) (p x)

  compose-cong : {f f′ g g′ : End} → f ≈ f′ → g ≈ g′ → compose f g ≈ compose f′ g′
  compose-cong {f′ = f′} {g = g} p q x = trans (p (run g x)) (cong (run f′) (q x))

  bracket-cong : {f f′ g g′ : End} → f ≈ f′ → g ≈ g′ → bracket f g ≈ bracket f′ g′
  bracket-cong {f} {f′} {g} {g′} p q x = cong₂ _-v_
    (compose-cong {f = f} {f′} {g} {g′} p q x)
    (compose-cong {f = g} {f′ = g′} {g = f} {g′ = f′} q p x)

  bracket-addˡ : (f g h : End) → bracket (add f g) h ≈ add (bracket f h) (bracket g h)
  bracket-addˡ f g h x =
    trans (cong (λ z → (run f (run h x) +v run g (run h x)) -v z) (additive h (run f x) (run g x)))
      (sub-add-pairs (run f (run h x)) (run g (run h x)) (run h (run f x)) (run h (run g x)))

  bracket-addʳ : (f g h : End) → bracket f (add g h) ≈ add (bracket f g) (bracket f h)
  bracket-addʳ f g h x =
    trans (cong (_-v (run g (run f x) +v run h (run f x))) (additive f (run g x) (run h x)))
      (sub-add-pairs (run f (run g x)) (run f (run h x)) (run g (run f x)) (run h (run f x)))

  bracket-scaleˡ : (r : R) (f g : End) → bracket (scale r f) g ≈ scale r (bracket f g)
  bracket-scaleˡ r f g x = trans (cong (λ z → (r • run f (run g x)) -v z) (homogeneous g r (run f x)))
    (sym (scalar-sub r (run f (run g x)) (run g (run f x))))

  bracket-scaleʳ : (r : R) (f g : End) → bracket f (scale r g) ≈ scale r (bracket f g)
  bracket-scaleʳ r f g x = trans (cong (_-v (r • run g (run f x))) (homogeneous f r (run g x)))
    (sym (scalar-sub r (run f (run g x)) (run g (run f x))))

  sub-chain : (x y z : V) → (x -v y) +v (y -v z) ≡ x -v z
  sub-chain x y z = trans (add-assoc x (-v y) (y -v z))
    (cong (x +v_) (add-inverse-cancel y (-v z)))

  sub-opposite : (x y : V) → (x -v y) +v (y -v x) ≡ 0v
  sub-opposite x y = trans (sub-chain x y x) (sub-self x)

  bracket-alternating : (f : End) → bracket f f ≈ zeroEnd
  bracket-alternating f x = sub-self (run f (run f x))

  bracket-skew : (f g : End) → add (bracket f g) (bracket g f) ≈ zeroEnd
  bracket-skew f g x = sub-opposite (run f (run g x)) (run g (run f x))

  sub-sub : (a b c d : V) → (a -v b) -v (c -v d) ≡ (a -v c) +v (d -v b)
  sub-sub a b c d = trans (sub-add-pairs a (-v b) c (-v d))
    (cong ((a -v c) +v_) (negative-difference b d))

  jacobi-cancellation : (a b c d e f : V) →
    (((a -v b) -v (c -v d)) +v ((c -v e) -v (f -v b))) +v
      ((f -v d) -v (a -v e)) ≡ 0v
  jacobi-cancellation a b c d e f =
    trans (cong₂ _+v_
      (cong₂ _+v_ (sub-sub a b c d) (sub-sub c e f b)) (sub-sub f d a e))
      (trans (cong (_+v ((f -v a) +v (e -v d)))
        (add-shuffle (a -v c) (d -v b) (c -v f) (b -v e)))
        (trans (add-shuffle ((a -v c) +v (c -v f)) ((d -v b) +v (b -v e)) (f -v a) (e -v d))
          (trans (cong₂ _+v_
            (trans (cong (_+v (f -v a)) (sub-chain a c f)) (sub-opposite a f))
            (trans (cong (_+v (e -v d)) (sub-chain d b e)) (sub-opposite d e)))
            (add-zeroˡ 0v))))

  nested-bracket : (f g h : End) (x : V) →
    run (bracket f (bracket g h)) x ≡
      (run f (run g (run h x)) -v run f (run h (run g x))) -v
      (run g (run h (run f x)) -v run h (run g (run f x)))
  nested-bracket f g h x = cong
    (_-v (run g (run h (run f x)) -v run h (run g (run f x))))
    (run-sub f (run g (run h x)) (run h (run g x)))

  bracket-jacobi : (f g h : End) →
    add (add (bracket f (bracket g h)) (bracket g (bracket h f))) (bracket h (bracket f g)) ≈ zeroEnd
  bracket-jacobi f g h x =
    trans (cong₂ _+v_ (cong₂ _+v_ (nested-bracket f g h x) (nested-bracket g h f x))
      (nested-bracket h f g x))
      (jacobi-cancellation (run f (run g (run h x))) (run f (run h (run g x)))
        (run g (run h (run f x))) (run h (run g (run f x)))
        (run g (run f (run h x))) (run h (run f (run g x))))

module EndEquality {a v : Level} (A : CRing a) (M : RModule A v)
  (extV : FunExt v v) (extA : FunExt a v) (setV : isSet (RModule.V M)) where
  open Endomorphisms A M

  end-path : {f g : End} → run f ≡ run g → f ≡ g
  end-path {linear f a s} {linear .f b t} refl = cong₂ (linear f)
    (extV (λ x → extV (λ y → setV _ _ (a x y) (b x y))))
    (extA (λ r → extV (λ x → setV _ _ (s r x) (t r x))))

  end-ext : {f g : End} → f ≈ g → f ≡ g
  end-ext p = end-path (extV p)

  endomorphismModule : RModule A (a ⊔ v)
  endomorphismModule = record
    { V = End
    ; 0v = zeroEnd
    ; _+v_ = add
    ; -v_ = neg
    ; _•_ = scale
    ; add-assoc = λ f g h → end-ext (λ x → add-assoc (run f x) (run g x) (run h x))
    ; add-comm = λ f g → end-ext (λ x → add-comm (run f x) (run g x))
    ; add-zeroˡ = λ f → end-ext (λ x → add-zeroˡ (run f x))
    ; add-inverseˡ = λ f → end-ext (λ x → add-inverseˡ (run f x))
    ; scalar-one = λ f → end-ext (λ x → scalar-one (run f x))
    ; scalar-assoc = λ r s f → end-ext (λ x → scalar-assoc r s (run f x))
    ; scalar-add = λ r s f → end-ext (λ x → scalar-add r s (run f x))
    ; scalar-distrib = λ r f g → end-ext (λ x → scalar-distrib r (run f x) (run g x))
    }

  operatorLieAlgebra : LieAlgebra A endomorphismModule
  operatorLieAlgebra = record
    { bracket = bracket
    ; bracket-addˡ = λ f g h → end-ext (bracket-addˡ f g h)
    ; bracket-addʳ = λ f g h → end-ext (bracket-addʳ f g h)
    ; bracket-scaleˡ = λ r f g → end-ext (bracket-scaleˡ r f g)
    ; bracket-scaleʳ = λ r f g → end-ext (bracket-scaleʳ r f g)
    ; alternating = λ f → end-ext (bracket-alternating f)
    ; skew = λ f g → end-ext (bracket-skew f g)
    ; jacobi = λ f g h → end-ext (bracket-jacobi f g h)
    }
