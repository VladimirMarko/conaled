{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Linear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tabulate; lookup-tabulate)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.Polynomial
import SDG.Combinatorics.FiniteSums as FS
import SDG.ChapterI.Section06 as S6

module FirstOrderFromTotal {ℓ : Level} (A : CRing ℓ)
  (T : Polynomials.TotalKockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Polynomials A
  open TotalKockLawvere T

  singleton : D → Jet1 (suc zero)
  singleton d = makeJet1 (value d ∷ []) (λ { fzero fzero → square-zero d })

  extract : Jet1 (suc zero) → D
  extract p = coordinateD p fzero

  private
    cancel-path : {x y z : R} (p : x ≡ y) (q : y ≡ z) → trans (sym p) (trans p q) ≡ q
    cancel-path refl q = refl

  extract-singleton : (d : D) → extract (singleton d) ≡ d
  extract-singleton d = cong (infinitesimal (value d))
    (cancel-path (cong (_* value d) (*-identityˡ (value d))) (square-zero d))

  linearCoefficient : Polynomial (suc zero) (suc zero) → R
  linearCoefficient (horner (scalar a) (constantP b)) = b

  linear-evaluate : (p : Polynomial (suc zero) (suc zero)) (xs : Vec R (suc zero)) →
    evaluate p xs ≡ constantTerm p + lookup xs fzero * linearCoefficient p
  linear-evaluate (horner (scalar a) (constantP b)) (x ∷ []) = refl

  jetFor : (D → R) → Polynomial (suc zero) (suc zero)
  jetFor g = coefficients zero zero (λ p → g (extract p))

  constant-correct : (g : D → R) → constantTerm (jetFor g) ≡ g zeroD
  constant-correct g =
    trans (sym (trans (cong (constantTerm (jetFor g) +_) (*-zeroˡ (linearCoefficient (jetFor g))))
      (+-identityʳ (constantTerm (jetFor g)))))
      (trans (sym (linear-evaluate (jetFor g) (coords (singleton zeroD))))
        (trans (sym (reconstruction zero zero (λ p → g (extract p)) (singleton zeroD)))
          (cong g (extract-singleton zeroD))))

  expansion₁ : (g : D → R) (d : D) →
    g d ≡ g zeroD + value d * linearCoefficient (jetFor g)
  expansion₁ g d =
    trans (cong g (sym (extract-singleton d)))
      (trans (reconstruction zero zero (λ p → g (extract p)) (singleton d))
        (trans (linear-evaluate (jetFor g) (coords (singleton d)))
          (cong (_+ (value d * linearCoefficient (jetFor g))) (constant-correct g))))

  unique₁ : (g : D → R) (b : R) →
    ((d : D) → g d ≡ g zeroD + value d * b) → linearCoefficient (jetFor g) ≡ b
  unique₁ g b p = cong linearCoefficient
    (uniqueness zero zero (λ e → g (extract e)) (horner (scalar (g zeroD)) (constantP b))
      (λ e → trans (p (extract e))
        (sym (linear-evaluate (horner (scalar (g zeroD)) (constantP b)) (coords e)))))

  firstOrder : KockLawvere
  KockLawvere.slope firstOrder g = linearCoefficient (jetFor g)
  KockLawvere.expansion firstOrder = expansion₁
  KockLawvere.uniqueness firstOrder = unique₁

module Affine {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Polynomials A

  weights : {n : ℕ} → Polynomial n (suc zero) → Vec R n
  weights (scalar a) = []
  weights (horner p (constantP b)) = b ∷ weights p

  affine-evaluation : {n : ℕ} (p : Polynomial n (suc zero)) (xs : Vec R n) →
    evaluate p xs ≡ constantTerm p + Sum.sum (λ i → lookup xs i * lookup (weights p) i)
  affine-evaluation (scalar a) [] = sym (+-identityʳ a)
  affine-evaluation (horner p (constantP b)) (x ∷ xs) =
    trans (cong (_+ (x * b)) (affine-evaluation p xs))
      (trans (+-assoc (constantTerm p) (Sum.sum (λ i → lookup xs i * lookup (weights p) i)) (x * b))
        (cong (constantTerm p +_) (+-comm (Sum.sum (λ i → lookup xs i * lookup (weights p) i)) (x * b))))

  axis-dot : {n : ℕ} (bs : Fin n → R) (i : Fin n) (d : D) →
    Sum.sum (λ j → coordinate (axis i d) j * bs j) ≡ value d * bs i
  axis-dot bs i d =
    trans (Sum.sum-cong (λ j →
      trans (cong (_* bs j) (axis-coordinate i j d))
        (trans (*-assoc (Sum.delta j i) (value d) (bs j))
          (trans (*-swap (Sum.delta j i) (value d) (bs j))
            (cong (λ z → value d * (z * bs j)) (Sum.delta-sym j i))))))
      (trans (Sum.sum-scaleˡ (value d) (λ j → Sum.delta i j * bs j))
        (cong (value d *_) (Sum.sum-delta bs i)))

-- Proposition I.6.4, derived from Axiom 1″. The first-order KL structure
-- used in the construction is itself derived above from this same axiom.
module ScalarLinearity {ℓ : Level} (A : CRing ℓ)
  (T : Polynomials.TotalKockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Polynomials A
  open TotalKockLawvere T
  open Affine A
  open S6.Linear A
  private
    K : KockLawvere
    K = FirstOrderFromTotal.firstOrder A T
  open KockLawvere K renaming (uniqueness to slope-unique)

  extend : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R) →
    ((i : Fin (suc (suc n))) → ts i zeroD ≡ x) → Jet1 (suc (suc n)) → R
  extend n x ts base p = x + Sum.sum (λ i → coordinate p i * slope (ts i))

  extend-axis : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R)
    (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x)
    (i : Fin (suc (suc n))) (d : D) → extend n x ts base (axis i d) ≡ ts i d
  extend-axis n x ts base i d =
    trans (cong (x +_) (axis-dot (λ j → slope (ts j)) i d))
      (trans (cong (_+ (value d * slope (ts i))) (sym (base i))) (sym (expansion (ts i) d)))

  extend-unique : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R)
    (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x)
    (candidate : Jet1 (suc (suc n)) → R) →
    ((i : Fin (suc (suc n))) (d : D) → candidate (axis i d) ≡ ts i d) →
    (p : Jet1 (suc (suc n))) → candidate p ≡ extend n x ts base p
  extend-unique n x ts base candidate agrees p =
    trans (reconstruction zero (suc n) candidate p)
      (trans (affine-evaluation poly (coords p))
        (cong₂ _+_ base-correct (Sum.sum-cong (λ i → cong (coordinate p i *_) (coefficient-correct i)))))
    where
    poly : Polynomial (suc (suc n)) (suc zero)
    poly = coefficients zero (suc n) candidate

    on-axis : (i : Fin (suc (suc n))) (d : D) →
      candidate (axis i d) ≡ constantTerm poly + value d * lookup (weights poly) i
    on-axis i d = trans (reconstruction zero (suc n) candidate (axis i d))
      (trans (affine-evaluation poly (coords (axis i d)))
        (cong (constantTerm poly +_) (axis-dot (lookup (weights poly)) i d)))

    base-correct : constantTerm poly ≡ x
    base-correct = trans
      (sym (trans (on-axis fzero zeroD)
        (trans (cong (constantTerm poly +_) (*-zeroˡ (lookup (weights poly) fzero)))
          (+-identityʳ (constantTerm poly)))))
      (trans (agrees fzero zeroD) (base fzero))

    coefficient-correct : (i : Fin (suc (suc n))) → lookup (weights poly) i ≡ slope (ts i)
    coefficient-correct i = sym (slope-unique (ts i) (lookup (weights poly) i)
      (λ d → trans (sym (agrees i d))
        (trans (on-axis i d)
          (cong (_+ (value d * lookup (weights poly) i))
            (trans base-correct (sym (base i)))))))

  scalar-linear : InfinitesimallyLinear R
  InfinitesimallyLinear.extension scalar-linear = extend
  InfinitesimallyLinear.axes scalar-linear = extend-axis
  InfinitesimallyLinear.uniqueness scalar-linear = extend-unique
