{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section05Local where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tabulate; map;
   lookup-map; lookup-tabulate; vec-ext; finToNat; head)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section05 as S5
import SDG.Calculus.Slope as SL

-- Intrinsic derivatives on finite nilpotent neighborhoods. Each derivative
-- lowers the allowed order by one. This allows genuinely local Taylor
-- theorems without assuming that a local function extends to all of R^n.
module LocalTaylor {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open KockLawvere K
  open S5.Rectangular A H setR
  open S3.GeneralTaylor A K H Q using (inverseFactorial; inverse-factorial-left)
  open SL.Results A K using (slope-cong; slope-scale)

  local-derivative : {n : ℕ} → (DK (suc n) → R) → DK n → R
  local-derivative g a = slope (λ d → g (shiftK a d))

  local-derivative-cong : {n : ℕ} (f g : DK (suc n) → R) →
    ((a : DK (suc n)) → f a ≡ g a) → (a : DK n) →
    local-derivative f a ≡ local-derivative g a
  local-derivative-cong f g p a = slope-cong
    (λ d → f (shiftK a d)) (λ d → g (shiftK a d)) (λ d → p (shiftK a d))

  local-derivative-scale : {n : ℕ} (r : R) (g : DK (suc n) → R) (a : DK n) →
    local-derivative (λ b → r * g b) a ≡ r * local-derivative g a
  local-derivative-scale r g a = slope-scale r (λ d → g (shiftK a d))

  -- Derivative coefficient extraction agrees with formal polynomial
  -- differentiation. Only polynomial expansion and first-order KL are used.
  descent : {n : ℕ} (g : DK (suc n) → R) (as : Vec R (suc (suc n))) →
    ((b : DK (suc n)) → g b ≡ eval as (valueK b)) →
    (a : DK n) → local-derivative g a ≡ eval (differentiate as) (valueK a)
  descent g as p a = uniqueness (λ d → g (shiftK a d))
    (eval (differentiate as) (valueK a))
    (λ d → trans (p (shiftK a d))
      (trans (polynomial-first-order as (valueK a) d)
        (cong (_+ (value d * eval (differentiate as) (valueK a))) (sym base))))
    where
    base : g (shiftK a zeroD) ≡ eval as (valueK a)
    base = trans (p (shiftK a zeroD)) (cong (eval as) (+-identityʳ (valueK a)))

  derivative-at-zero : {n : ℕ} → Fin (suc n) → (DK n → R) → R
  derivative-at-zero {n} fzero g = g (zeroK n)
  derivative-at-zero {suc n} (fsuc i) g = derivative-at-zero i (local-derivative g)

  derivative-at-cong : {n : ℕ} (i : Fin (suc n)) (f g : DK n → R) →
    ((a : DK n) → f a ≡ g a) → derivative-at-zero i f ≡ derivative-at-zero i g
  derivative-at-cong {n} fzero f g p = p (zeroK n)
  derivative-at-cong {suc n} (fsuc i) f g p =
    derivative-at-cong i (local-derivative f) (local-derivative g) (local-derivative-cong f g p)

  derivative-at-scale : {n : ℕ} (i : Fin (suc n)) (r : R) (g : DK n → R) →
    derivative-at-zero i (λ a → r * g a) ≡ r * derivative-at-zero i g
  derivative-at-scale fzero r g = refl
  derivative-at-scale {suc n} (fsuc i) r g =
    trans
      (derivative-at-cong i (local-derivative (λ a → r * g a))
        (λ a → r * local-derivative g a) (local-derivative-scale r g))
      (derivative-at-scale i r (local-derivative g))

  coefficient-derivative : {n : ℕ} (g : DK n → R) (as : Vec R (suc n)) →
    ((a : DK n) → g a ≡ eval as (valueK a)) →
    (i : Fin (suc n)) →
    factorial (finToNat i) * lookup as i ≡ derivative-at-zero i g
  coefficient-derivative {n} g (a ∷ as) p fzero =
    trans (*-identityˡ a)
      (trans (sym (eval-zero (a ∷ as))) (sym (p (zeroK n))))
  coefficient-derivative {suc n} g (a ∷ as) p (fsuc i) =
    trans (*-assoc (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i))
      (trans (*-swap (fromℕ (suc (finToNat i))) (factorial (finToNat i)) (lookup as i))
        (trans
          (cong (factorial (finToNat i) *_) (sym (lookup-weight (suc zero) as i)))
          (coefficient-derivative (local-derivative g) (differentiate (a ∷ as))
            (descent g (a ∷ as) p) i)))

  local-coefficients : (n : ℕ) → (DK n → R) → Vec R (suc n)
  local-coefficients n g =
    tabulate (λ i → inverseFactorial (finToNat i) * derivative-at-zero i g)

  identify-local-coefficients : (n : ℕ) (g : DK n → R) →
    coefficients-all n g ≡ local-coefficients n g
  identify-local-coefficients n g = vec-ext (λ i →
    trans (sym (*-identityˡ (lookup (coefficients-all n g) i)))
      (trans
        (cong (_* lookup (coefficients-all n g) i)
          (sym (inverse-factorial-left (finToNat i))))
        (trans (*-assoc (inverseFactorial (finToNat i)) (factorial (finToNat i))
          (lookup (coefficients-all n g) i))
          (trans
            (cong (inverseFactorial (finToNat i) *_)
              (coefficient-derivative g (coefficients-all n g) (reconstruction-all n g) i))
            (sym (lookup-tabulate
              (λ j → inverseFactorial (finToNat j) * derivative-at-zero j g) i))))))

  local-taylor : (n : ℕ) (g : DK n → R) (a : DK n) →
    g a ≡ eval (local-coefficients n g) (valueK a)
  local-taylor n g a =
    trans (reconstruction-all n g a)
      (cong (λ as → eval as (valueK a)) (identify-local-coefficients n g))

  local-tensor : {n : ℕ} (ks : Vec ℕ n) → (Points ks → R) → Coefficients ks
  local-tensor [] f = f one
  local-tensor (k ∷ ks) f = tabulate (λ i →
    local-tensor ks (λ ds → inverseFactorial (finToNat i) *
      derivative-at-zero i (λ d → f (d , ds))))

  -- Theorem I.5.2 on the rectangular neighborhood itself.
  local-taylor-rectangle : {n : ℕ} (ks : Vec ℕ n)
    (f : Points ks → R) (ds : Points ks) →
    f ds ≡ evaluate (local-tensor ks f) ds
  local-taylor-rectangle [] f one = refl
  local-taylor-rectangle (k ∷ ks) f (d , ds) =
    trans (local-taylor k (λ e → f (e , ds)) d)
      (cong (λ as → eval as (valueK d)) (sym values))
    where
    coeff : Fin (suc k) → Points ks → R
    coeff i es = inverseFactorial (finToNat i) *
      derivative-at-zero i (λ e → f (e , es))
    values :
      map (λ a → evaluate {ks = ks} a ds) (local-tensor (k ∷ ks) f) ≡
      local-coefficients k (λ e → f (e , ds))
    values = vec-ext (λ i →
      trans (lookup-map (λ a → evaluate {ks = ks} a ds) (local-tensor (k ∷ ks) f) i)
        (trans
          (cong (λ a → evaluate {ks = ks} a ds)
            (lookup-tabulate (λ j → local-tensor ks (coeff j)) i))
          (trans (sym (local-taylor-rectangle ks (coeff i) ds))
            (sym (lookup-tabulate
              (λ j → inverseFactorial (finToNat j) *
                derivative-at-zero j (λ e → f (e , ds))) i)))))

  open S5.Taylor A K H Q setR using
    (Indices; degrees; lookup-tensor; inverse-multifactorial; translate)

  local-mixed : {n : ℕ} {ks : Vec ℕ n} → Indices ks → (Points ks → R) → R
  local-mixed {ks = []} tt f = f one
  local-mixed {ks = k ∷ ks} (i , is) f =
    local-mixed {ks = ks} is (λ ds → derivative-at-zero i (λ d → f (d , ds)))

  local-mixed-cong : {n : ℕ} {ks : Vec ℕ n} (is : Indices ks) (f g : Points ks → R) →
    ((ds : Points ks) → f ds ≡ g ds) → local-mixed is f ≡ local-mixed is g
  local-mixed-cong {ks = []} tt f g p = p one
  local-mixed-cong {ks = k ∷ ks} (i , is) f g p =
    local-mixed-cong {ks = ks} is
      (λ ds → derivative-at-zero i (λ d → f (d , ds)))
      (λ ds → derivative-at-zero i (λ d → g (d , ds)))
      (λ ds → derivative-at-cong i (λ d → f (d , ds)) (λ d → g (d , ds)) (λ d → p (d , ds)))

  local-mixed-scale : {n : ℕ} {ks : Vec ℕ n} (is : Indices ks) (r : R) (f : Points ks → R) →
    local-mixed is (λ ds → r * f ds) ≡ r * local-mixed is f
  local-mixed-scale {ks = []} tt r f = refl
  local-mixed-scale {ks = k ∷ ks} (i , is) r f =
    trans
      (local-mixed-cong {ks = ks} is
        (λ ds → derivative-at-zero i (λ d → r * f (d , ds)))
        (λ ds → r * derivative-at-zero i (λ d → f (d , ds)))
        (λ ds → derivative-at-scale i r (λ d → f (d , ds))))
      (local-mixed-scale {ks = ks} is r
        (λ ds → derivative-at-zero i (λ d → f (d , ds))))

  local-tensor-coefficient : {n : ℕ} (ks : Vec ℕ n)
    (f : Points ks → R) (is : Indices ks) →
    lookup-tensor {ks = ks} (local-tensor ks f) is ≡
      inverse-multifactorial (degrees {ks = ks} is) * local-mixed is f
  local-tensor-coefficient [] f tt = sym (*-identityˡ (f one))
  local-tensor-coefficient (k ∷ ks) f (i , is) =
    trans
      (cong (λ a → lookup-tensor {ks = ks} a is)
        (lookup-tabulate
          (λ j → local-tensor ks (λ ds → inverseFactorial (finToNat j) *
            derivative-at-zero j (λ d → f (d , ds)))) i))
      (trans
        (local-tensor-coefficient ks
          (λ ds → inverseFactorial (finToNat i) * derivative-at-zero i (λ d → f (d , ds))) is)
        (trans
          (cong (inverse-multifactorial (degrees {ks = ks} is) *_)
            (local-mixed-scale {ks = ks} is (inverseFactorial (finToNat i))
              (λ ds → derivative-at-zero i (λ d → f (d , ds)))))
          (trans
            (*-swap (inverse-multifactorial (degrees {ks = ks} is))
              (inverseFactorial (finToNat i))
              (local-mixed {ks = ks} is (λ ds → derivative-at-zero i (λ d → f (d , ds)))))
            (sym (*-assoc (inverseFactorial (finToNat i))
              (inverse-multifactorial (degrees {ks = ks} is))
              (local-mixed {ks = ks} is (λ ds → derivative-at-zero i (λ d → f (d , ds)))))))))

  -- A local function on U is only required to be defined on the requested
  -- translated rectangle. No extension to the ambient affine space is used.
  on-domain : {n : ℕ} (ks : Vec ℕ n) (U : Vec R n → Set ℓ) →
    (f : Σ (Vec R n) U → R) (xs : Vec R n) →
    (inside : (ds : Points ks) → U (translate xs ds)) →
    (ds : Points ks) →
    f (translate xs ds , inside ds) ≡
      evaluate (local-tensor ks (λ es → f (translate xs es , inside es))) ds
  on-domain ks U f xs inside ds =
    local-taylor-rectangle ks (λ es → f (translate xs es , inside es)) ds

