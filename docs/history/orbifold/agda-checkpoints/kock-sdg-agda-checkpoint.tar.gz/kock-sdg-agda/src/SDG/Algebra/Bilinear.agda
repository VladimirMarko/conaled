{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Bilinear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tabulate; lookup-tabulate;
   map; lookup-map; zipWith; lookup-zipWith; replicate; lookup-replicate; vec-ext)
import SDG.Combinatorics.FiniteSums as FS

module BilinearAlgebra {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  module Sum = FS.Sums A

  record Linear {n : ℕ} (f : Vec R n → R) : Set ℓ where
    field
      at-zero : f (replicate 0r) ≡ 0r
      additive : (xs ys : Vec R n) → f (zipWith _+_ xs ys) ≡ f xs + f ys
      homogeneous : (r : R) (xs : Vec R n) → f (map (r *_) xs) ≡ r * f xs

  record Bilinear {n m : ℕ} (b : Vec R n → Vec R m → R) : Set ℓ where
    field
      left-linear : (ys : Vec R m) → Linear (λ xs → b xs ys)
      right-linear : (xs : Vec R n) → Linear (b xs)

  basis : {n : ℕ} → Fin n → Vec R n
  basis i = tabulate (Sum.delta i)

  sumVectors : {m n : ℕ} → (Fin m → Vec R n) → Vec R n
  sumVectors {zero} f = replicate 0r
  sumVectors {suc m} f = zipWith _+_ (f fzero) (sumVectors (λ i → f (fsuc i)))

  lookup-sumVectors : {m n : ℕ} (f : Fin m → Vec R n) (j : Fin n) →
    lookup (sumVectors f) j ≡ Sum.sum (λ i → lookup (f i) j)
  lookup-sumVectors {zero} f j = lookup-replicate 0r j
  lookup-sumVectors {suc m} f j =
    trans (lookup-zipWith _+_ (f fzero) (sumVectors (λ i → f (fsuc i))) j)
      (cong (lookup (f fzero) j +_) (lookup-sumVectors (λ i → f (fsuc i)) j))

  basis-decomposition : {n : ℕ} (xs : Vec R n) →
    sumVectors (λ i → map (lookup xs i *_) (basis i)) ≡ xs
  basis-decomposition xs = vec-ext (λ j →
    trans (lookup-sumVectors (λ i → map (lookup xs i *_) (basis i)) j)
      (trans (Sum.sum-cong (λ i →
        trans (lookup-map (lookup xs i *_) (basis i) j)
          (trans (cong (lookup xs i *_) (lookup-tabulate (Sum.delta i) j))
            (trans (*-comm (lookup xs i) (Sum.delta i j))
              (cong (_* lookup xs i) (Sum.delta-sym i j))))))
        (Sum.sum-delta (lookup xs) j)))

  linear-sum : {m n : ℕ} {f : Vec R n → R} → Linear f → (xs : Fin m → Vec R n) →
    f (sumVectors xs) ≡ Sum.sum (λ i → f (xs i))
  linear-sum {zero} L xs = Linear.at-zero L
  linear-sum {suc m} L xs =
    trans (Linear.additive L (xs fzero) (sumVectors (λ i → xs (fsuc i))))
      (cong (_ +_) (linear-sum L (λ i → xs (fsuc i))))

  linear-expansion : {n : ℕ} {f : Vec R n → R} → Linear f → (xs : Vec R n) →
    f xs ≡ Sum.sum (λ i → lookup xs i * f (basis i))
  linear-expansion {f = f} L xs =
    trans (cong f (sym (basis-decomposition xs)))
      (trans (linear-sum L (λ i → map (lookup xs i *_) (basis i)))
        (Sum.sum-cong (λ i → Linear.homogeneous L (lookup xs i) (basis i))))

  bilinear-expansion : {n m : ℕ} {b : Vec R n → Vec R m → R} → Bilinear b →
    (xs : Vec R n) (ys : Vec R m) →
    b xs ys ≡ Sum.sum (λ i → Sum.sum (λ j → (lookup xs i * lookup ys j) * b (basis i) (basis j)))
  bilinear-expansion {b = b} B xs ys =
    trans (linear-expansion (Bilinear.left-linear B ys) xs)
      (Sum.sum-cong (λ i →
        trans (cong (lookup xs i *_) (linear-expansion (Bilinear.right-linear B (basis i)) ys))
          (trans (sym (Sum.sum-scaleˡ (lookup xs i) (λ j → lookup ys j * b (basis i) (basis j))))
            (Sum.sum-cong (λ j → sym (*-assoc (lookup xs i) (lookup ys j) (b (basis i) (basis j))))))))
