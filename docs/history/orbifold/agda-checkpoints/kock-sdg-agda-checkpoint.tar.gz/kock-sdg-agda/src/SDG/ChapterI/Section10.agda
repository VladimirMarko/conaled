{-# OPTIONS --safe --without-K #-}

-- Kock I.10: directional calculus and the synthetic homogeneity theorem.
module SDG.ChapterI.Section10 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8

scalar-vectorKL : {ℓ : Level} (A : CRing ℓ) →
  Infinitesimals.KockLawvere A → V5.VectorInfinitesimals.VectorKL A (scalarModule A)
scalar-vectorKL A K = record
  { slopeV = Infinitesimals.KockLawvere.slope K
  ; expansionV = Infinitesimals.KockLawvere.expansion K
  ; uniqueSlopeV = Infinitesimals.KockLawvere.uniqueness K
  }

module Calculus {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (W : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A W) where
  open Extra A W
  open Infinitesimals A
  open KockLawvere K
  open V5.VectorInfinitesimals.VectorKL KV
  open V5.VectorCalculus A W KV
  open S8.Basics A setR

  slope-reparameterized : (g : D → V) (r : R) →
    slopeV (λ d → g (scaleD d r)) ≡ r • slopeV g
  slope-reparameterized g r = uniqueSlopeV (λ d → g (scaleD d r)) (r • slopeV g)
    (λ d → trans (expansionV g (scaleD d r))
      (cong₂ _+v_ (cong g (sym (S7.Basics.scale-zero A setR r)))
        (scalar-assoc (value d) r (slopeV g))))

  directional : {M : Set ℓ} → VectorField M → (M → V) → M → V
  directional X f m = slopeV (λ d → f (run X m d))

  directional-scalar : {M : Set ℓ} → VectorField M → (M → R) → M → R
  directional-scalar X f m = slope (λ d → f (run X m d))

  directional-taylor : {M : Set ℓ} (X : VectorField M) (f : M → V)
    (m : M) (d : D) → f (run X m d) ≡ f m +v value d • directional X f m
  directional-taylor X f m d =
    trans (expansionV (λ e → f (run X m e)) d)
      (cong (_+v (value d • directional X f m)) (cong f (run-zero X m)))

  scalar-taylor : {M : Set ℓ} (X : VectorField M) (f : M → R)
    (m : M) (d : D) → f (run X m d) ≡ f m + value d * directional-scalar X f m
  scalar-taylor X f m d =
    trans (expansion (λ e → f (run X m e)) d)
      (cong (_+ (value d * directional-scalar X f m)) (cong f (run-zero X m)))

  directional-unique : {M : Set ℓ} (X : VectorField M) (f : M → V)
    (m : M) (b : V) →
    ((d : D) → f (run X m d) ≡ f m +v value d • b) → directional X f m ≡ b
  directional-unique X f m b p = uniqueSlopeV (λ d → f (run X m d)) b
    (λ d → trans (p d)
      (cong (_+v (value d • b)) (cong f (sym (run-zero X m)))))

  directional-cong : {M : Set ℓ} (X : VectorField M) (f g : M → V) →
    ((m : M) → f m ≡ g m) → (m : M) → directional X f m ≡ directional X g m
  directional-cong X f g p m = slope-cong
    (λ d → f (run X m d)) (λ d → g (run X m d)) (λ d → p (run X m d))

  -- Theorem 10.1(i,ii).
  directional-scale : {M : Set ℓ} (X : VectorField M) (r : R)
    (f : M → V) (m : M) → directional X (λ x → r • f x) m ≡ r • directional X f m
  directional-scale X r f m = slope-scale r (λ d → f (run X m d))

  directional-add : {M : Set ℓ} (X : VectorField M) (f g : M → V) (m : M) →
    directional X (λ x → f x +v g x) m ≡ directional X f m +v directional X g m
  directional-add X f g m = slope-add (λ d → f (run X m d)) (λ d → g (run X m d))

  -- Theorem 10.1(iii), with a scalar function and a module-valued function.
  directional-product : {M : Set ℓ} (X : VectorField M) (φ : M → R)
    (f : M → V) (m : M) →
    directional X (λ x → φ x • f x) m ≡
      directional-scalar X φ m • f m +v φ m • directional X f m
  directional-product X φ f m = directional-unique X (λ x → φ x • f x) m
    (directional-scalar X φ m • f m +v φ m • directional X f m)
    (λ d → trans (cong₂ _•_ (scalar-taylor X φ m d) (directional-taylor X f m d))
      (affine-action (value d) (φ m) (directional-scalar X φ m)
        (f m) (directional X f m) (square-zero d)))

  directional-constant : {M : Set ℓ} (X : VectorField M) (v : V) (m : M) →
    directional X (λ _ → v) m ≡ 0v
  directional-constant X v m = directional-unique X (λ _ → v) m 0v
    (λ d → sym (trans (cong (v +v_) (scalar-zero (value d))) (add-zeroʳ v)))

  directional-neg : {M : Set ℓ} (X : VectorField M) (f : M → V) (m : M) →
    directional X (λ x → -v f x) m ≡ (-v directional X f m)
  directional-neg X f m = directional-unique X (λ x → -v f x) m (-v directional X f m)
    (λ d → trans (cong -v_ (directional-taylor X f m d))
      (trans (v-neg-add (f m) (value d • directional X f m))
        (cong ((-v f m) +v_) (sym (scalar-neg (value d) (directional X f m))))))

  directional-sub : {M : Set ℓ} (X : VectorField M) (f g : M → V) (m : M) →
    directional X (λ x → f x -v g x) m ≡ directional X f m -v directional X g m
  directional-sub X f g m = trans (directional-add X f (λ x → -v g x) m)
    (cong (directional X f m +v_) (directional-neg X g m))

  FirstIntegral : {M : Set ℓ} → VectorField M → (M → V) → Set ℓ
  FirstIntegral X f = ∀ m → directional X f m ≡ 0v

  Invariant : {M : Set ℓ} → VectorField M → (M → V) → Set ℓ
  Invariant X f = ∀ m d → f (run X m d) ≡ f m

  integral-invariant : {M : Set ℓ} (X : VectorField M) (f : M → V) →
    FirstIntegral X f → Invariant X f
  integral-invariant X f p m d = trans (directional-taylor X f m d)
    (trans (cong (λ z → f m +v value d • z) (p m))
      (trans (cong (f m +v_) (scalar-zero (value d))) (add-zeroʳ (f m))))

  invariant-integral : {M : Set ℓ} (X : VectorField M) (f : M → V) →
    Invariant X f → FirstIntegral X f
  invariant-integral X f p m = directional-unique X f m 0v
    (λ d → trans (p m d)
      (sym (trans (cong (f m +v_) (scalar-zero (value d))) (add-zeroʳ (f m)))))

  -- Exercise 10.3: the same equivalence expressed in the category of fields.
  integral-morphism : {M : Set ℓ} (X : VectorField M) (f : M → V) →
    FirstIntegral X f → Morphism X zero-field
  integral-morphism X f p = field-morphism f (integral-invariant X f p)

  morphism-integral : {M : Set ℓ} (X : VectorField M) (F : Morphism X zero-field) →
    FirstIntegral X (Morphism.map F)
  morphism-integral X F = invariant-integral X (Morphism.map F) (Morphism.commutes F)

  -- Theorem 10.3(i) needs neither infinitesimal linearity nor Property W.
  scaled-field-derivative : {M : Set ℓ} (φ : M → R) (X : VectorField M)
    (f : M → V) (m : M) →
    directional (scale-field φ X) f m ≡ φ m • directional X f m
  scaled-field-derivative φ X f m = directional-unique (scale-field φ X) f m
    (φ m • directional X f m) (λ d →
      trans (directional-taylor X f m (scaleD d (φ m)))
        (cong (f m +v_) (scalar-assoc (value d) (φ m) (directional X f m))))

module Homogeneity {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (Umod W : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A W) where
  open Extra A W
  module U = ModuleLemmas A Umod
  open Infinitesimals A
  open S8.Basics A setR
  open V5.VectorCalculus A W KV
  open Calculus A K setR W KV

  translation : U.V → VectorField U.V
  run (translation y) u d = U._+v_ u (U._•_ (value d) y)
  run-zero (translation y) u = trans (cong (U._+v_ u) (U.zero-scalar y)) (U.add-zeroʳ u)

  delta : U.V → (U.V → V) → U.V → V
  delta y = directional (translation y)

  translation-taylor : (f : U.V → V) (u y : U.V) (d : D) →
    f (U._+v_ u (U._•_ (value d) y)) ≡ f u +v value d • delta y f u
  translation-taylor f u y = directional-taylor (translation y) f u

  origin-taylor : (f : U.V → V) (y : U.V) (d : D) →
    f (U._•_ (value d) y) ≡ f U.0v +v value d • delta y f U.0v
  origin-taylor f y d = trans (cong f (sym (U.add-zeroˡ (U._•_ (value d) y))))
    (translation-taylor f U.0v y d)

  InfinitesimallyHomogeneous : (U.V → V) → Set ℓ
  InfinitesimallyHomogeneous f = ∀ d u → f (U._•_ (value d) u) ≡ value d • f u

  Homogeneous : (U.V → V) → Set ℓ
  Homogeneous f = ∀ r u → f (U._•_ r u) ≡ r • f u

  homogeneous-zero : (f : U.V → V) → InfinitesimallyHomogeneous f → f U.0v ≡ 0v
  homogeneous-zero f h = trans (cong f (sym (U.zero-scalar U.0v)))
    (trans (h zeroD U.0v) (zero-scalar (f U.0v)))

  homogeneous-origin : (f : U.V → V) → InfinitesimallyHomogeneous f →
    (y : U.V) → delta y f U.0v ≡ f y
  homogeneous-origin f h y = cancel-infinitesimals (delta y f U.0v) (f y)
    (λ d → trans
      (sym (trans (origin-taylor f y d)
        (trans (cong (_+v (value d • delta y f U.0v)) (homogeneous-zero f h))
          (add-zeroˡ (value d • delta y f U.0v))))) (h d y))

  multiplied-origin-taylor : (g : U.V → V) (x : U.V) (d : D) →
    value d • g (U._•_ (value d) x) ≡ value d • g U.0v
  multiplied-origin-taylor g x d = trans (cong (value d •_) (origin-taylor g x d))
    (trans (scalar-distrib (value d) (g U.0v) (value d • delta x g U.0v))
      (trans (cong ((value d • g U.0v) +v_)
        (scalar-square-zero (value d) (square-zero d) (delta x g U.0v)))
        (add-zeroʳ (value d • g U.0v))))

  -- Proposition 10.2: even infinitesimal homogeneity already forces additivity.
  homogeneous-add : (f : U.V → V) → InfinitesimallyHomogeneous f →
    (x y : U.V) → f (U._+v_ x y) ≡ f x +v f y
  homogeneous-add f h x y = cancel-infinitesimals (f (U._+v_ x y)) (f x +v f y)
    (λ d → begin
      value d • f (U._+v_ x y)
    ≡⟨ sym (h d (U._+v_ x y)) ⟩
      f (U._•_ (value d) (U._+v_ x y))
    ≡⟨ cong f (U.scalar-distrib (value d) x y) ⟩
      f (U._+v_ (U._•_ (value d) x) (U._•_ (value d) y))
    ≡⟨ translation-taylor f (U._•_ (value d) x) y d ⟩
      f (U._•_ (value d) x) +v value d • delta y f (U._•_ (value d) x)
    ≡⟨ cong₂ _+v_ (h d x) (multiplied-origin-taylor (delta y f) x d) ⟩
      value d • f x +v value d • delta y f U.0v
    ≡⟨ cong (λ z → value d • f x +v value d • z) (homogeneous-origin f h y) ⟩
      value d • f x +v value d • f y
    ≡⟨ sym (scalar-distrib (value d) (f x) (f y)) ⟩
      value d • (f x +v f y) ∎)

  homogeneous-linear : (f : U.V → V) → Homogeneous f → S7L.ModuleMap A Umod W
  homogeneous-linear f h = record
    { apply = f
    ; preserves-zero = homogeneous-zero f (λ d → h (value d))
    ; preserves-add = homogeneous-add f (λ d → h (value d))
    ; preserves-scale = h
    }

  -- Exercise 10.2 keeps the extra hypothesis about zero derivatives explicit.
  ZeroDerivativeConstant : Set ℓ
  ZeroDerivativeConstant = (g : R → V) → ((r : R) → derivative g r ≡ 0v) →
    (r : R) → g r ≡ g 0r

  infinitesimal-to-full-homogeneity : ZeroDerivativeConstant →
    (f : U.V → V) → InfinitesimallyHomogeneous f → Homogeneous f
  infinitesimal-to-full-homogeneity zdc f h r u = sub-zero-equal (f (U._•_ r u)) (r • f u)
    (trans (zdc g g-derivative r) g-zero)
    where
    g : R → V
    g s = f (U._•_ s u) -v s • f u

    g-invariant : (s : R) (d : D) → g (s + value d) ≡ g s
    g-invariant s d =
      trans (cong₂ _-v_
        (trans (cong f (U.scalar-add s (value d) u))
          (trans (homogeneous-add f h (U._•_ s u) (U._•_ (value d) u))
            (cong (f (U._•_ s u) +v_) (h d u))))
        (scalar-add s (value d) (f u)))
        (sub-common-right (f (U._•_ s u)) (s • f u) (value d • f u))

    g-derivative : (s : R) → derivative g s ≡ 0v
    g-derivative s = derivative-unique g s 0v (λ d → trans (g-invariant s d)
      (sym (trans (cong (g s +v_) (scalar-zero (value d))) (add-zeroʳ (g s)))))

    g-zero : g 0r ≡ 0v
    g-zero = trans (cong₂ _-v_ (trans (cong f (U.zero-scalar u)) (homogeneous-zero f h))
      (zero-scalar (f u))) (sub-self 0v)

  infinitesimally-homogeneous-linear : ZeroDerivativeConstant →
    (f : U.V → V) → InfinitesimallyHomogeneous f → S7L.ModuleMap A Umod W
  infinitesimally-homogeneous-linear zdc f h =
    homogeneous-linear f (infinitesimal-to-full-homogeneity zdc f h)

