{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.PresentedBaseChange where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Presented
open import SDG.Finite using (Fin)

-- Coefficient change on actual finite presentations. In particular the
-- generators and relation count are preserved; only coefficients in the
-- defining polynomials are transported through the given ring map.
module Change {κ κ′ : Level} (k : CRing κ) (K : CRing κ′) (σ : RingHom k K) where
  private
    module P = Presentations k
    module Q = Presentations K

  polynomial : {n : ℕ} → P.Polynomial n → Q.Polynomial n
  polynomial (P.coefficient a) = Q.coefficient (RingHom.hom σ a)
  polynomial (P.var i) = Q.var i
  polynomial (p P.⊕ q) = polynomial p Q.⊕ polynomial q
  polynomial (p P.⊗ q) = polynomial p Q.⊗ polynomial q
  polynomial (P.negative p) = Q.negative (polynomial p)

  presentation : P.Presentation → Q.Presentation
  presentation B = Q.presented (P.generators B) (P.relations B) (λ j → polynomial (P.equations B j))

  evaluate-polynomial : {c : Level} (C : CRing c) (ι : CRing.R K → CRing.R C)
    {n : ℕ} (p : P.Polynomial n) (xs : Fin n → CRing.R C) →
    Q.evaluate C ι (polynomial p) xs ≡ P.evaluate C (λ a → ι (RingHom.hom σ a)) p xs
  evaluate-polynomial C ι (P.coefficient a) xs = refl
  evaluate-polynomial C ι (P.var i) xs = refl
  evaluate-polynomial C ι (p P.⊕ q) xs =
    cong₂ (CRing._+_ C) (evaluate-polynomial C ι p xs) (evaluate-polynomial C ι q xs)
  evaluate-polynomial C ι (p P.⊗ q) xs =
    cong₂ (CRing._*_ C) (evaluate-polynomial C ι p xs) (evaluate-polynomial C ι q xs)
  evaluate-polynomial C ι (P.negative p) xs = cong (CRing.-_ C) (evaluate-polynomial C ι p xs)

  forward : {c : Level} (C : CRing c) (ι : CRing.R K → CRing.R C) {B : P.Presentation} →
    P.Spec C (λ a → ι (RingHom.hom σ a)) B → Q.Spec C ι (presentation B)
  Q.coordinates (forward C ι x) = P.coordinates x
  Q.satisfies (forward C ι {B} x) j =
    trans (evaluate-polynomial C ι (P.equations B j) (P.coordinates x)) (P.satisfies x j)

  backward : {c : Level} (C : CRing c) (ι : CRing.R K → CRing.R C) {B : P.Presentation} →
    Q.Spec C ι (presentation B) → P.Spec C (λ a → ι (RingHom.hom σ a)) B
  P.coordinates (backward C ι x) = Q.coordinates x
  P.satisfies (backward C ι {B} x) j =
    trans (sym (evaluate-polynomial C ι (P.equations B j) (Q.coordinates x))) (Q.satisfies x j)

  backward-forward : {c : Level} (C : CRing c) (ι : CRing.R K → CRing.R C)
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) {B : P.Presentation}
    (x : P.Spec C (λ a → ι (RingHom.hom σ a)) B) → backward C ι (forward C ι x) ≡ x
  backward-forward C ι ext setC x = P.spec-path ext setC (λ i → refl)

  forward-backward : {c : Level} (C : CRing c) (ι : CRing.R K → CRing.R C)
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) {B : P.Presentation}
    (x : Q.Spec C ι (presentation B)) → forward C ι (backward C ι {B} x) ≡ x
  forward-backward C ι ext setC x = Q.spec-path ext setC (λ i → refl)
