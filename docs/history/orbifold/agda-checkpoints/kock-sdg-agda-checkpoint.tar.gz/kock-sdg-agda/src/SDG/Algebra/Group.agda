{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.Group where

open import SDG.Prelude

record Group {ℓ : Level} (G : Set ℓ) : Set ℓ where
  infixl 7 _·_
  field
    unit : G
    _·_ : G → G → G
    inverse : G → G
    assoc : (a b c : G) → (a · b) · c ≡ a · (b · c)
    identityˡ : (a : G) → unit · a ≡ a
    identityʳ : (a : G) → a · unit ≡ a
    inverseˡ : (a : G) → inverse a · a ≡ unit
    inverseʳ : (a : G) → a · inverse a ≡ unit

module GroupLemmas {ℓ : Level} {G : Set ℓ} (H : Group G) where
  open Group H public

  inverse-unique : (a b : G) → a · b ≡ unit → b ≡ inverse a
  inverse-unique a b p =
    begin
      b
    ≡⟨ sym (identityˡ b) ⟩
      unit · b
    ≡⟨ cong (_· b) (sym (inverseˡ a)) ⟩
      (inverse a · a) · b
    ≡⟨ assoc (inverse a) a b ⟩
      inverse a · (a · b)
    ≡⟨ cong (inverse a ·_) p ⟩
      inverse a · unit
    ≡⟨ identityʳ (inverse a) ⟩
      inverse a ∎

  inverse-unit : inverse unit ≡ unit
  inverse-unit = sym (inverse-unique unit unit (identityˡ unit))

  inverse-involutive : (a : G) → inverse (inverse a) ≡ a
  inverse-involutive a = sym (inverse-unique (inverse a) a (inverseˡ a))

  inverse-product : (a b : G) → inverse (a · b) ≡ inverse b · inverse a
  inverse-product a b = sym (inverse-unique (a · b) (inverse b · inverse a)
    (trans (assoc a b (inverse b · inverse a))
      (trans (cong (a ·_) (sym (assoc b (inverse b) (inverse a))))
        (trans (cong (λ z → a · (z · inverse a)) (inverseʳ b))
          (trans (cong (a ·_) (identityˡ (inverse a))) (inverseʳ a))))))

  commutator : G → G → G
  commutator a b = ((inverse a · inverse b) · a) · b

  conjugate : G → G → G
  conjugate a b = (inverse b · a) · b

