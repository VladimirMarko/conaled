{-# OPTIONS --safe --without-K #-}
module SDG.Forms.QuadraticCubes where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; swapFirst; permute-swapFirst)
open import SDG.Forms.Basic
import SDG.ChapterI.Section05Vector as V5

two four : ℕ
two = suc (suc zero)
four = suc (suc two)

-- The M^(D×D) ≅ M^4 calculation in Exercise I.14.2 is derived
-- from vector KL, including recovery and uniqueness of all four entries.
module Quadratic {ℓ : Level} (A : CRing ℓ) (M : RModule A ℓ)
  (K : V5.VectorInfinitesimals.VectorKL A M) where
  open ModuleLemmas A M
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL K
  open V5.VectorCalculus A M K
  open Cubes A

  quad : V → V → V → V → Cube two V
  quad x a b c (d ∷ e ∷ []) = (x +v value d • a) +v (value e • b +v (value d * value e) • c)

  base first second mixed : Cube two V → V
  base τ = τ (zeroD ∷ zeroD ∷ [])
  first τ = slopeV (λ d → τ (d ∷ zeroD ∷ []))
  second τ = slopeV (λ e → τ (zeroD ∷ e ∷ []))
  mixed τ = slopeV (λ e → slopeV (λ d → τ (d ∷ e ∷ [])))

  reconstruction : (τ : Cube two V) (ds : Vec D two) →
    τ ds ≡ quad (base τ) (first τ) (second τ) (mixed τ) ds
  reconstruction τ (d ∷ e ∷ []) = trans (expansionV (λ q → τ (q ∷ e ∷ [])) d)
    (trans (cong₂ _+v_ (expansionV (λ q → τ (zeroD ∷ q ∷ [])) e)
      (cong (value d •_) (expansionV (λ q → slopeV (λ p → τ (p ∷ q ∷ []))) e)))
      (trans (cong ((base τ +v value e • second τ) +v_)
        (trans (scalar-distrib (value d) (first τ) (value e • mixed τ))
          (cong ((value d • first τ) +v_) (sym (scalar-assoc (value d) (value e) (mixed τ))))))
        (add-shuffle (base τ) (value e • second τ) (value d • first τ) ((value d * value e) • mixed τ))))

  quad-axis-first : (x a b c : V) (d : D) → quad x a b c (d ∷ zeroD ∷ []) ≡ x +v value d • a
  quad-axis-first x a b c d = trans
    (cong ((x +v value d • a) +v_)
      (trans (cong₂ _+v_ (zero-scalar b)
        (trans (cong (_• c) (*-zeroʳ (value d))) (zero-scalar c))) (add-zeroˡ 0v)))
    (add-zeroʳ (x +v value d • a))

  quad-axis-second : (x a b c : V) (e : D) → quad x a b c (zeroD ∷ e ∷ []) ≡ x +v value e • b
  quad-axis-second x a b c e = cong₂ _+v_
    (trans (cong (x +v_) (zero-scalar a)) (add-zeroʳ x))
    (trans (cong ((value e • b) +v_)
      (trans (cong (_• c) (*-zeroˡ (value e))) (zero-scalar c))) (add-zeroʳ (value e • b)))

  quad-base : (x a b c : V) → base (quad x a b c) ≡ x
  quad-base x a b c = trans (quad-axis-first x a b c zeroD)
    (trans (cong (x +v_) (zero-scalar a)) (add-zeroʳ x))

  affine-slope : (x a : V) → slopeV (λ d → x +v value d • a) ≡ a
  affine-slope x a = uniqueSlopeV (λ d → x +v value d • a) a
    (λ d → cong (_+v (value d • a))
      (sym (trans (cong (x +v_) (zero-scalar a)) (add-zeroʳ x))))

  quad-first : (x a b c : V) → first (quad x a b c) ≡ a
  quad-first x a b c = trans
    (slope-cong (λ d → quad x a b c (d ∷ zeroD ∷ [])) (λ d → x +v value d • a) (quad-axis-first x a b c))
    (affine-slope x a)

  quad-second : (x a b c : V) → second (quad x a b c) ≡ b
  quad-second x a b c = trans
    (slope-cong (λ e → quad x a b c (zeroD ∷ e ∷ [])) (λ e → x +v value e • b) (quad-axis-second x a b c))
    (affine-slope x b)

  first-slope : (x a b c : V) (e : D) → slopeV (λ d → quad x a b c (d ∷ e ∷ [])) ≡ a +v value e • c
  first-slope x a b c e = uniqueSlopeV (λ d → quad x a b c (d ∷ e ∷ [])) (a +v value e • c)
    (λ d → trans
      (trans (add-shuffle x (value d • a) (value e • b) ((value d * value e) • c))
        (cong ((x +v value e • b) +v_)
          (trans (cong ((value d • a) +v_) (scalar-assoc (value d) (value e) c))
            (sym (scalar-distrib (value d) a (value e • c))))))
      (cong (_+v (value d • (a +v value e • c))) (sym (quad-axis-second x a b c e))))

  quad-mixed : (x a b c : V) → mixed (quad x a b c) ≡ c
  quad-mixed x a b c = trans
    (slope-cong (λ e → slopeV (λ d → quad x a b c (d ∷ e ∷ [])))
      (λ e → a +v value e • c) (first-slope x a b c)) (affine-slope a c)

  encode : Vec V four → Cube two V
  encode (x ∷ a ∷ b ∷ c ∷ []) = quad x a b c

  decode : Cube two V → Vec V four
  decode τ = base τ ∷ first τ ∷ second τ ∷ mixed τ ∷ []

  decode-encode : (cs : Vec V four) → decode (encode cs) ≡ cs
  decode-encode (x ∷ a ∷ b ∷ c ∷ []) = cong₂ _∷_ (quad-base x a b c)
    (cong₂ _∷_ (quad-first x a b c) (cong₂ _∷_ (quad-second x a b c) (cong (_∷ []) (quad-mixed x a b c))))

  encode-decode : (τ : Cube two V) (ds : Vec D two) → encode (decode τ) ds ≡ τ ds
  encode-decode τ ds = sym (reconstruction τ ds)

  native-encode-decode : FunExt ℓ ℓ → (τ : Cube two V) → encode (decode τ) ≡ τ
  native-encode-decode ext τ = ext (encode-decode τ)

  quad-scale-first : (x a b c : V) (r : R) (ds : Vec D two) →
    scale-cube (quad x a b c) fzero r ds ≡ quad x (r • a) b (r • c) ds
  quad-scale-first x a b c r (d ∷ e ∷ []) = cong₂ _+v_
    (cong (x +v_) (scalar-assoc (value d) r a))
    (cong ((value e • b) +v_)
      (trans (cong (_• c) (trans (*-assoc (value d) r (value e))
        (trans (cong (value d *_) (*-comm r (value e))) (sym (*-assoc (value d) (value e) r)))))
        (scalar-assoc (value d * value e) r c)))

  quad-scale-second : (x a b c : V) (r : R) (ds : Vec D two) →
    scale-cube (quad x a b c) (fsuc fzero) r ds ≡ quad x a (r • b) (r • c) ds
  quad-scale-second x a b c r (d ∷ e ∷ []) = cong ((x +v value d • a) +v_)
    (cong₂ _+v_ (scalar-assoc (value e) r b)
      (trans (cong (_• c) (sym (*-assoc (value d) (value e) r))) (scalar-assoc (value d * value e) r c)))

  quad-swap : (x a b c : V) (ds : Vec D two) →
    permute-cube (quad x a b c) swapFirst ds ≡ quad x b a c ds
  quad-swap x a b c (d ∷ e ∷ []) = trans
    (cong (quad x a b c) (permute-swapFirst d e []))
    (trans (add-shuffle x (value e • a) (value d • b) ((value e * value d) • c))
      (cong ((x +v value d • b) +v_) (cong ((value e • a) +v_)
        (cong (_• c) (*-comm (value e) (value d))))))
