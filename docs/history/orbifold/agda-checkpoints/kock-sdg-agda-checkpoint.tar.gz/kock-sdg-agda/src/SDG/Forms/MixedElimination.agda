{-# OPTIONS --safe --without-K #-}
module SDG.Forms.MixedElimination where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_)
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section10 as S10

-- The algebraic core of Exercise I.14.2. It applies to ambient direction
-- modules even when the base space of a form is only a stable subobject.
module Elimination {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (Umod Vmod : RModule A ℓ)
  (KV : V5.VectorInfinitesimals.VectorKL A Vmod)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A)
  (F : RModule.V Umod → RModule.V Umod → RModule.V Umod → RModule.V Vmod)
  (first-hom : (r : CRing.R A) (a b c : RModule.V Umod) →
    F (RModule._•_ Umod r a) b (RModule._•_ Umod r c) ≡ RModule._•_ Vmod r (F a b c))
  (second-hom : (r : CRing.R A) (a b c : RModule.V Umod) →
    F a (RModule._•_ Umod r b) (RModule._•_ Umod r c) ≡ RModule._•_ Vmod r (F a b c))
  (mixed-antisymmetric : (c : RModule.V Umod) → F (RModule.0v Umod) (RModule.0v Umod) c ≡
    RModule.-v_ Vmod (F (RModule.0v Umod) (RModule.0v Umod) c)) where
  open Extra A Vmod
  module U = ModuleLemmas A Umod
  open Infinitesimals A
  private
    two = suc (suc zero)
  module H = S10.Homogeneity A K setR (FiniteModules.finiteModule A Umod two) Vmod KV

  first-block : U.V → Vec U.V two → V
  first-block b (a ∷ c ∷ []) = F a b c

  second-block : U.V → Vec U.V two → V
  second-block a (b ∷ c ∷ []) = F a b c

  first-homogeneous : (b : U.V) → H.Homogeneous (first-block b)
  first-homogeneous b r (a ∷ c ∷ []) = first-hom r a b c

  second-homogeneous : (a : U.V) → H.Homogeneous (second-block a)
  second-homogeneous a r (b ∷ c ∷ []) = second-hom r a b c

  first-add : (a a′ b c c′ : U.V) →
    F (U._+v_ a a′) b (U._+v_ c c′) ≡ F a b c +v F a′ b c′
  first-add a a′ b c c′ = H.homogeneous-add (first-block b)
    (λ d → first-homogeneous b (value d)) (a ∷ c ∷ []) (a′ ∷ c′ ∷ [])

  second-add : (a b b′ c c′ : U.V) →
    F a (U._+v_ b b′) (U._+v_ c c′) ≡ F a b c +v F a b′ c′
  second-add a b b′ c c′ = H.homogeneous-add (second-block a)
    (λ d → second-homogeneous a (value d)) (b ∷ c ∷ []) (b′ ∷ c′ ∷ [])

  first-zero : (b : U.V) → F U.0v b U.0v ≡ 0v
  first-zero b = H.homogeneous-zero (first-block b) (λ d → first-homogeneous b (value d))

  first-split : (a b c : U.V) → F a b c ≡ F a b U.0v +v F U.0v b c
  first-split a b c = trans
    (cong₂ (λ aa cc → F aa b cc) (sym (U.add-zeroʳ a)) (sym (U.add-zeroˡ c)))
    (first-add a U.0v b U.0v c)

  second-split : (b c : U.V) → F U.0v b c ≡ F U.0v U.0v c
  second-split b c = trans
    (cong₂ (F U.0v) (sym (U.add-zeroʳ b)) (sym (U.add-zeroˡ c)))
    (trans (second-add U.0v b U.0v U.0v c)
      (trans (cong (_+v F U.0v U.0v c) (first-zero b)) (add-zeroˡ (F U.0v U.0v c))))

  two-torsion-free : (v : V) → v +v v ≡ 0v → v ≡ 0v
  two-torsion-free v twice = trans (sym (scalar-one v))
    (trans (cong (_• v) (sym (trans (*-comm half (1r + 1r)) half-law)))
      (trans (scalar-assoc half (1r + 1r) v)
        (trans (cong (half •_) (trans (scalar-add 1r 1r v)
          (trans (cong₂ _+v_ (scalar-one v) (scalar-one v)) twice))) (scalar-zero half))))

  mixed-zero : (c : U.V) → F U.0v U.0v c ≡ 0v
  mixed-zero c = two-torsion-free (F U.0v U.0v c)
    (trans (cong (F U.0v U.0v c +v_) (mixed-antisymmetric c)) (add-inverseʳ (F U.0v U.0v c)))

  independent-of-mixed : (a b c : U.V) → F a b c ≡ F a b U.0v
  independent-of-mixed a b c = trans (first-split a b c)
    (trans (cong (F a b U.0v +v_) (trans (second-split b c) (mixed-zero c))) (add-zeroʳ (F a b U.0v)))
