{-# OPTIONS --safe --without-K #-}
module SDG.Forms.TangentTuples where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup; update;
  lookup-update-same; update-overwrite; Permutation; permute; inversePerm)
open import SDG.Forms.Basic using (ScalarAction; moduleAction)
open import SDG.Combinatorics.Signature
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section10 as S10

-- Definition I.14.1 retains the common base point explicitly.
-- Only a multiplicative scalar action is needed for this definition.
module Tuples {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open S7.Basics A setR

  scale-tuple : {n : ℕ} {M : Set ℓ} {x : M} → Vec (Tangent M x) n → Fin n → R → Vec (Tangent M x) n
  scale-tuple ts i r = update ts i (speed r (lookup ts i))

  replace-speed : {n : ℕ} {M : Set ℓ} {x : M}
    (ts : Vec (Tangent M x) n) (i : Fin n) (r : R) (t : Tangent M x) →
    scale-tuple (update ts i t) i r ≡ update ts i (speed r t)
  replace-speed ts i r t = trans
    (cong (λ u → update (update ts i t) i (speed r u)) (lookup-update-same ts i t))
    (update-overwrite ts i t (speed r t))

module Definitions {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  {V : Set ℓ} (action : ScalarAction A V) where
  open RingLemmas A
  open ScalarAction action
  open S7.Basics A setR
  open Tuples A setR
  open Sign A

  record TupleForm (n : ℕ) (M : Set ℓ) : Set ℓ where
    constructor tuple-form
    field
      evaluate : (x : M) → Vec (Tangent M x) n → V
      homogeneous : (x : M) (ts : Vec (Tangent M x) n) (i : Fin n) (r : R) →
        evaluate x (scale-tuple ts i r) ≡ act r (evaluate x ts)
      alternating : (x : M) (ts : Vec (Tangent M x) n) (p : Permutation n) →
        evaluate x (permute p ts) ≡ act (signature p) (evaluate x ts)
  open TupleForm public

  function-form : {M : Set ℓ} → (M → V) → TupleForm zero M
  evaluate (function-form f) x ts = f x
  homogeneous (function-form f) x ts () r
  alternating (function-form f) x ts p = sym (act-one (f x))

  form-function : {M : Set ℓ} → TupleForm zero M → M → V
  form-function ω x = evaluate ω x []

  function-roundtrip : {M : Set ℓ} (f : M → V) (x : M) → form-function (function-form f) x ≡ f x
  function-roundtrip f x = refl

  zero-form-roundtrip : {M : Set ℓ} (ω : TupleForm zero M) (x : M) (ts : Vec (Tangent M x) zero) →
    evaluate (function-form (form-function ω)) x ts ≡ evaluate ω x ts
  zero-form-roundtrip ω x [] = refl

  module Native (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setV : isSet V) where
    private
      tuple-form-path : {n : ℕ} {M : Set ℓ} {ω θ : TupleForm n M} → evaluate ω ≡ evaluate θ → ω ≡ θ
      tuple-form-path {ω = tuple-form f h p} {tuple-form .f k q} refl = cong₂ (tuple-form f)
        (ext (λ x → ext (λ ts → ext0 (λ i → ext (λ r → setV _ _ (h x ts i r) (k x ts i r))))))
        (ext (λ x → ext (λ ts → ext0 (λ σ → setV _ _ (p x ts σ) (q x ts σ)))))

    tuple-form-ext : {n : ℕ} {M : Set ℓ} {ω θ : TupleForm n M} →
      ((x : M) (ts : Vec (Tangent M x) n) → evaluate ω x ts ≡ evaluate θ x ts) → ω ≡ θ
    tuple-form-ext equality = tuple-form-path (ext (λ x → ext (equality x)))

-- The source's claim that homogeneity implies multilinearity is derived
-- coordinate by coordinate using Proposition I.10.2 and the actual tangent
-- fiber module from I.7. No additivity field is added to TupleForm.
module Multilinearity {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M)
  (Vmod : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A Vmod) where
  open ModuleLemmas A Vmod
  open S7.Basics A setR
  open Tuples A setR
  open Definitions A setR (moduleAction A Vmod)
  module T = S7L.Construction A setR ext0 M IL

  coordinate : {n : ℕ} → TupleForm n M → (x : M) → Vec (Tangent M x) n → Fin n → Tangent M x → V
  coordinate ω x ts i t = evaluate ω x (update ts i t)

  coordinate-homogeneous : {n : ℕ} (ω : TupleForm n M) (x : M)
    (ts : Vec (Tangent M x) n) (i : Fin n) (r : R) (t : Tangent M x) →
    coordinate ω x ts i (speed r t) ≡ r • coordinate ω x ts i t
  coordinate-homogeneous ω x ts i r t = trans
    (cong (evaluate ω x) (sym (replace-speed ts i r t))) (homogeneous ω x (update ts i t) i r)

  coordinate-linear : {n : ℕ} (ω : TupleForm n M) (x : M)
    (ts : Vec (Tangent M x) n) (i : Fin n) →
    S7L.ModuleMap A (T.fiberModule ext setM x) Vmod
  coordinate-linear ω x ts i = S10.Homogeneity.homogeneous-linear A K setR
    (T.fiberModule ext setM x) Vmod KV (coordinate ω x ts i) (coordinate-homogeneous ω x ts i)

  coordinate-additive : {n : ℕ} (ω : TupleForm n M) (x : M)
    (ts : Vec (Tangent M x) n) (i : Fin n) (t u : Tangent M x) →
    evaluate ω x (update ts i (T.add t u)) ≡ evaluate ω x (update ts i t) +v evaluate ω x (update ts i u)
  coordinate-additive ω x ts i = S7L.ModuleMap.preserves-add (coordinate-linear ω x ts i)

  coordinate-zero : {n : ℕ} (ω : TupleForm n M) (x : M)
    (ts : Vec (Tangent M x) n) (i : Fin n) → evaluate ω x (update ts i (zero-tangent x)) ≡ 0v
  coordinate-zero ω x ts i = S7L.ModuleMap.preserves-zero (coordinate-linear ω x ts i)
