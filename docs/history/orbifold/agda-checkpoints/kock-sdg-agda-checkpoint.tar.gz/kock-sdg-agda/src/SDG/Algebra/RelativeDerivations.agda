{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.RelativeDerivations where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Derivations using (algebraModule)

-- The relative derivations Der^i_R(C,D) from the opening of I.11.
-- All three structures are used: the two R-algebras and the specified
-- algebra map i against which the Leibniz rule is interpreted.
module Relative {a c d : Level} (A : CRing a)
  (C : RAlgebra A c) (D : RAlgebra A d) (i : AlgHom C D) where
  module S = RingLemmas (ring C)
  module Base = CRing A
  open RingLemmas (ring D) public

  sourceScalar : Base.R → S.R
  sourceScalar = RingHom.hom (unit C)

  targetScalar : Base.R → R
  targetScalar = RingHom.hom (unit D)

  record Derivation : Set (a ⊔ c ⊔ d) where
    constructor relative
    field
      run : S.R → R
      additive : (x y : S.R) → run (S._+_ x y) ≡ run x + run y
      homogeneous : (r : Base.R) (x : S.R) →
        run (S._*_ (sourceScalar r) x) ≡ targetScalar r * run x
      leibniz : (x y : S.R) → run (S._*_ x y) ≡ run x * algMap i y + algMap i x * run y
  open Derivation public

  infix 4 _≈_
  _≈_ : Derivation → Derivation → Set (c ⊔ d)
  δ ≈ ε = (x : S.R) → run δ x ≡ run ε x

  zeroD : Derivation
  run zeroD x = 0r
  additive zeroD x y = sym (+-identityˡ 0r)
  homogeneous zeroD r x = sym (*-zeroʳ (targetScalar r))
  leibniz zeroD x y = sym
    (trans (cong₂ _+_ (*-zeroˡ (algMap i y)) (*-zeroʳ (algMap i x))) (+-identityˡ 0r))

  add : Derivation → Derivation → Derivation
  run (add δ ε) x = run δ x + run ε x
  additive (add δ ε) x y = trans (cong₂ _+_ (additive δ x y) (additive ε x y))
    (+-shuffle (run δ x) (run δ y) (run ε x) (run ε y))
  homogeneous (add δ ε) r x = trans (cong₂ _+_ (homogeneous δ r x) (homogeneous ε r x))
    (sym (distribˡ (targetScalar r) (run δ x) (run ε x)))
  leibniz (add δ ε) x y =
    trans (cong₂ _+_ (leibniz δ x y) (leibniz ε x y))
      (trans (+-shuffle (run δ x * algMap i y) (algMap i x * run δ y)
        (run ε x * algMap i y) (algMap i x * run ε y))
        (cong₂ _+_ (sym (distribʳ (run δ x) (run ε x) (algMap i y)))
          (sym (distribˡ (algMap i x) (run δ y) (run ε y)))))

  neg : Derivation → Derivation
  run (neg δ) x = - run δ x
  additive (neg δ) x y = trans (cong -_ (additive δ x y)) (neg-add (run δ x) (run δ y))
  homogeneous (neg δ) r x = trans (cong -_ (homogeneous δ r x))
    (sym (neg-mulʳ (targetScalar r) (run δ x)))
  leibniz (neg δ) x y = trans (cong -_ (leibniz δ x y))
    (trans (neg-add (run δ x * algMap i y) (algMap i x * run δ y))
      (cong₂ _+_ (sym (neg-mulˡ (run δ x) (algMap i y)))
        (sym (neg-mulʳ (algMap i x) (run δ y)))))

  multiply : R → Derivation → Derivation
  run (multiply r δ) x = r * run δ x
  additive (multiply r δ) x y = trans (cong (r *_) (additive δ x y))
    (distribˡ r (run δ x) (run δ y))
  homogeneous (multiply r δ) s x = trans (cong (r *_) (homogeneous δ s x))
    (*-swap r (targetScalar s) (run δ x))
  leibniz (multiply r δ) x y = trans (cong (r *_) (leibniz δ x y))
    (trans (distribˡ r (run δ x * algMap i y) (algMap i x * run δ y))
      (cong₂ _+_ (sym (*-assoc r (run δ x) (algMap i y)))
        (*-swap r (algMap i x) (run δ y))))

  scale : Base.R → Derivation → Derivation
  scale r = multiply (targetScalar r)

  derive-zero : (δ : Derivation) → run δ S.0r ≡ 0r
  derive-zero δ = +-cancelˡ (run δ S.0r)
    (trans (sym (additive δ S.0r S.0r))
      (trans (cong (run δ) (S.+-identityˡ S.0r)) (sym (+-identityʳ (run δ S.0r)))))

  derive-one : (δ : Derivation) → run δ S.1r ≡ 0r
  derive-one δ = +-cancelˡ (run δ S.1r)
    (trans (sym doubled) (sym (+-identityʳ (run δ S.1r))))
    where
    doubled : run δ S.1r ≡ run δ S.1r + run δ S.1r
    doubled = trans (cong (run δ) (sym (S.*-identityˡ S.1r)))
      (trans (leibniz δ S.1r S.1r)
        (cong₂ _+_
          (trans (cong (run δ S.1r *_) (RingHom.pres-1 (ringHom i))) (*-identityʳ (run δ S.1r)))
          (trans (cong (_* run δ S.1r) (RingHom.pres-1 (ringHom i))) (*-identityˡ (run δ S.1r)))))

  derive-scalar : (δ : Derivation) (r : Base.R) → run δ (sourceScalar r) ≡ 0r
  derive-scalar δ r = trans (cong (run δ) (sym (S.*-identityʳ (sourceScalar r))))
    (trans (homogeneous δ r S.1r)
      (trans (cong (targetScalar r *_) (derive-one δ)) (*-zeroʳ (targetScalar r))))

  derive-neg : (δ : Derivation) (x : S.R) → run δ (S.- x) ≡ (- run δ x)
  derive-neg δ x = neg-unique (run δ x) (run δ (S.- x))
    (trans (sym (additive δ x (S.- x)))
      (trans (cong (run δ) (S.+-inverseʳ x)) (derive-zero δ)))

module Native {a c d : Level} (A : CRing a)
  (C : RAlgebra A c) (D : RAlgebra A d) (i : AlgHom C D)
  (ext : FunExt c d) (ext₂ : FunExt c (c ⊔ d)) (extA : FunExt a (c ⊔ d))
  (setD : isSet (CRing.R (ring D))) where
  open Relative A C D i

  derivation-path : {δ ε : Derivation} → run δ ≡ run ε → δ ≡ ε
  derivation-path {relative f p₁ p₂ p₃} {relative .f q₁ q₂ q₃} refl
    with ext₂ (λ x → ext (λ y → setD _ _ (p₁ x y) (q₁ x y))) |
      extA (λ r → ext (λ x → setD _ _ (p₂ r x) (q₂ r x))) |
      ext₂ (λ x → ext (λ y → setD _ _ (p₃ x y) (q₃ x y)))
  ... | refl | refl | refl = refl

  derivation-ext : {δ ε : Derivation} → δ ≈ ε → δ ≡ ε
  derivation-ext p = derivation-path (ext p)

  relativeModule : RModule A (a ⊔ c ⊔ d)
  relativeModule = record
    { V = Derivation; 0v = zeroD; _+v_ = add; -v_ = neg; _•_ = scale
    ; add-assoc = λ δ ε η → derivation-ext (λ x → +-assoc (run δ x) (run ε x) (run η x))
    ; add-comm = λ δ ε → derivation-ext (λ x → +-comm (run δ x) (run ε x))
    ; add-zeroˡ = λ δ → derivation-ext (λ x → +-identityˡ (run δ x))
    ; add-inverseˡ = λ δ → derivation-ext (λ x → +-inverseˡ (run δ x))
    ; scalar-one = λ δ → derivation-ext (λ x → RModule.scalar-one (algebraModule A (ring D) (unit D)) (run δ x))
    ; scalar-assoc = λ r s δ → derivation-ext (λ x → RModule.scalar-assoc (algebraModule A (ring D) (unit D)) r s (run δ x))
    ; scalar-add = λ r s δ → derivation-ext (λ x → RModule.scalar-add (algebraModule A (ring D) (unit D)) r s (run δ x))
    ; scalar-distrib = λ r δ ε → derivation-ext (λ x → distribˡ (targetScalar r) (run δ x) (run ε x))
    }

  coefficientModule : RModule (ring D) (a ⊔ c ⊔ d)
  coefficientModule = record
    { V = Derivation; 0v = zeroD; _+v_ = add; -v_ = neg; _•_ = multiply
    ; add-assoc = λ δ ε η → derivation-ext (λ x → +-assoc (run δ x) (run ε x) (run η x))
    ; add-comm = λ δ ε → derivation-ext (λ x → +-comm (run δ x) (run ε x))
    ; add-zeroˡ = λ δ → derivation-ext (λ x → +-identityˡ (run δ x))
    ; add-inverseˡ = λ δ → derivation-ext (λ x → +-inverseˡ (run δ x))
    ; scalar-one = λ δ → derivation-ext (λ x → *-identityˡ (run δ x))
    ; scalar-assoc = λ r s δ → derivation-ext (λ x → *-assoc r s (run δ x))
    ; scalar-add = λ r s δ → derivation-ext (λ x → distribʳ r s (run δ x))
    ; scalar-distrib = λ r δ ε → derivation-ext (λ x → distribˡ r (run δ x) (run ε x))
    }
