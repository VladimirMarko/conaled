{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section04 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup; update;
  tabulate; lookup-tabulate; vec-ext; replicate; lookup-replicate;
  update-identity; update-overwrite; Permutation; permute)
import SDG.ChapterI.Section01 as S1
import SDG.Calculus.Slope as SL

-- Kock I.4: multiaffine expansion and symmetry of partial derivatives.
module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open S1.Results A K using (cancel-infinitesimals)
  open SL.Results A K

  -- The two branches at each variable encode the subsets which omit/include
  -- that variable. Thus this tree has 2^n scalar leaves. This is a recursive
  -- square-free polynomial representation, not an assumed expansion.
  Coefficients : ℕ → Set ℓ
  Coefficients zero = R
  Coefficients (suc n) = Coefficients n × Coefficients n

  evaluate : {n : ℕ} → Coefficients n → Vec D n → R
  evaluate {zero} a [] = a
  evaluate {suc n} (a , b) (d ∷ ds) = evaluate a ds + value d * evaluate b ds

  coefficients : {n : ℕ} → (Vec D n → R) → Coefficients n
  coefficients {zero} f = f []
  coefficients {suc n} f =
    coefficients (λ ds → f (zeroD ∷ ds)) ,
    coefficients (λ ds → slope (λ d → f (d ∷ ds)))

  -- Proposition I.4.1, existence, for every finite dimension.
  multiaffine-expansion : {n : ℕ} (f : Vec D n → R) (ds : Vec D n) →
    f ds ≡ evaluate (coefficients f) ds
  multiaffine-expansion {zero} f [] = refl
  multiaffine-expansion {suc n} f (d ∷ ds) =
    trans (expansion (λ e → f (e ∷ ds)) d)
      (cong₂ _+_
        (multiaffine-expansion (λ es → f (zeroD ∷ es)) ds)
        (cong (value d *_)
          (multiaffine-expansion (λ es → slope (λ e → f (e ∷ es))) ds)))

  evaluate-at-zero : {n : ℕ} (a b : Coefficients n) (ds : Vec D n) →
    evaluate (a , b) (zeroD ∷ ds) ≡ evaluate a ds
  evaluate-at-zero a b ds =
    trans (cong (evaluate a ds +_) (*-zeroˡ (evaluate b ds)))
      (+-identityʳ (evaluate a ds))

  -- Proposition I.4.1, uniqueness. Both the constant and the linear branches
  -- are recovered; no decidable equality on R or function extensionality.
  evaluate-injective : {n : ℕ} (a b : Coefficients n) →
    ((ds : Vec D n) → evaluate a ds ≡ evaluate b ds) → a ≡ b
  evaluate-injective {zero} a b p = p []
  evaluate-injective {suc n} (a₀ , a₁) (b₀ , b₁) p =
    cong₂ _,_ (evaluate-injective a₀ b₀ constants)
      (evaluate-injective a₁ b₁ linear)
    where
    constants : (ds : Vec D n) → evaluate a₀ ds ≡ evaluate b₀ ds
    constants ds =
      trans (sym (evaluate-at-zero a₀ a₁ ds))
        (trans (p (zeroD ∷ ds)) (evaluate-at-zero b₀ b₁ ds))

    linear : (ds : Vec D n) → evaluate a₁ ds ≡ evaluate b₁ ds
    linear ds = cancel-infinitesimals (evaluate a₁ ds) (evaluate b₁ ds)
      (λ d → +-cancelˡ (evaluate a₀ ds)
        (trans (p (d ∷ ds))
          (cong (_+ (value d * evaluate b₁ ds)) (sym (constants ds)))))

  coefficients-unique : {n : ℕ} (f : Vec D n → R) (a : Coefficients n) →
    ((ds : Vec D n) → f ds ≡ evaluate a ds) → coefficients f ≡ a
  coefficients-unique f a p = evaluate-injective (coefficients f) a
    (λ ds → trans (sym (multiaffine-expansion f ds)) (p ds))

  coefficients-evaluate : {n : ℕ} (a : Coefficients n) →
    coefficients {n} (evaluate {n} a) ≡ a
  coefficients-evaluate {n} a = coefficients-unique {n} (evaluate {n} a) a (λ ds → refl)

  -- Coordinate translation, kept recursive so coordinate laws do not need
  -- equality of functions representing tuples.
  shift : {n : ℕ} → Vec R n → Fin n → D → Vec R n
  shift (x ∷ xs) fzero d = (x + value d) ∷ xs
  shift (x ∷ xs) (fsuc i) d = x ∷ shift xs i d

  shift-zero : {n : ℕ} (xs : Vec R n) (i : Fin n) → shift xs i zeroD ≡ xs
  shift-zero (x ∷ xs) fzero = cong (_∷ xs) (+-identityʳ x)
  shift-zero (x ∷ xs) (fsuc i) = cong (x ∷_) (shift-zero xs i)

  shift-as-update : {n : ℕ} (xs : Vec R n) (i : Fin n) (d : D) →
    shift xs i d ≡ update xs i (lookup xs i + value d)
  shift-as-update (x ∷ xs) fzero d = refl
  shift-as-update (x ∷ xs) (fsuc i) d = cong (x ∷_) (shift-as-update xs i d)

  shift-commute : {n : ℕ} (xs : Vec R n) (i j : Fin n) (d e : D) →
    shift (shift xs i d) j e ≡ shift (shift xs j e) i d
  shift-commute (x ∷ xs) fzero fzero d e =
    cong (_∷ xs) (trans (+-assoc x (value d) (value e))
      (trans (cong (x +_) (+-comm (value d) (value e)))
        (sym (+-assoc x (value e) (value d)))))
  shift-commute (x ∷ xs) fzero (fsuc j) d e = refl
  shift-commute (x ∷ xs) (fsuc i) fzero d e = refl
  shift-commute (x ∷ xs) (fsuc i) (fsuc j) d e =
    cong (x ∷_) (shift-commute xs i j d e)

  partial : {n : ℕ} → (Vec R n → R) → Fin n → Vec R n → R
  partial f i xs = slope (λ d → f (shift xs i d))

  partial-taylor : {n : ℕ} (f : Vec R n → R) (i : Fin n)
    (xs : Vec R n) (d : D) →
    f (shift xs i d) ≡ f xs + value d * partial f i xs
  partial-taylor f i xs d =
    trans (expansion (λ e → f (shift xs i e)) d)
      (cong (_+ (value d * partial f i xs)) (cong f (shift-zero xs i)))

  partial-unique : {n : ℕ} (f : Vec R n → R) (i : Fin n)
    (xs : Vec R n) (b : R) →
    ((d : D) → f (shift xs i d) ≡ f xs + value d * b) →
    partial f i xs ≡ b
  partial-unique f i xs b p = uniqueness (λ d → f (shift xs i d)) b
    (λ d → trans (p d)
      (cong (_+ (value d * b)) (sym (cong f (shift-zero xs i)))))

  partial-cong : {n : ℕ} (f g : Vec R n → R) →
    ((xs : Vec R n) → f xs ≡ g xs) →
    (i : Fin n) (xs : Vec R n) → partial f i xs ≡ partial g i xs
  partial-cong f g p i xs =
    slope-cong (λ d → f (shift xs i d)) (λ d → g (shift xs i d))
      (λ d → p (shift xs i d))

  -- Proposition I.4.2 for the whole R^n, including i = j.
  mixed-partials : {n : ℕ} (f : Vec R n → R) (i j : Fin n)
    (xs : Vec R n) →
    partial (partial f i) j xs ≡ partial (partial f j) i xs
  mixed-partials f i j xs =
    trans (slope-cong
      (λ e → slope (λ d → f (shift (shift xs j e) i d)))
      (λ e → slope (λ d → f (shift (shift xs i d) j e)))
      (λ e → slope-cong
        (λ d → f (shift (shift xs j e) i d))
        (λ d → f (shift (shift xs i d) j e))
        (λ d → cong f (shift-commute xs j i e d))))
      (mixed-slope (λ d e → f (shift (shift xs i d) j e)))

  private
    subtype-path : {a b : Level} {X : Set a} {U : X → Set b} →
      ((x : X) → isProp (U x)) → {x y : Σ X U} → fst x ≡ fst y → x ≡ y
    subtype-path prop {x , px} {y , py} refl = cong (x ,_) (prop x px py)

  -- Proposition I.4.2 on an arbitrary local domain. The two neighborhood
  -- hypotheses say exactly that the displayed second partials are defined.
  -- Proposition-valued membership represents an actual subobject of R^n.
  local-mixed-partials : {n : ℕ} {U : Vec R n → Set ℓ} →
    ((xs : Vec R n) → isProp (U xs)) →
    (f : Σ (Vec R n) U → R) (xs : Vec R n) (i j : Fin n) →
    (inside-ij : (d e : D) → U (shift (shift xs i d) j e)) →
    (inside-ji : (e d : D) → U (shift (shift xs j e) i d)) →
    slope (λ e → slope (λ d → f (shift (shift xs j e) i d , inside-ji e d))) ≡
    slope (λ d → slope (λ e → f (shift (shift xs i d) j e , inside-ij d e)))
  local-mixed-partials prop f xs i j inside-ij inside-ji =
    trans (slope-cong
      (λ e → slope (λ d → f (shift (shift xs j e) i d , inside-ji e d)))
      (λ e → slope (λ d → f (shift (shift xs i d) j e , inside-ij d e)))
      (λ e → slope-cong
        (λ d → f (shift (shift xs j e) i d , inside-ji e d))
        (λ d → f (shift (shift xs i d) j e , inside-ij d e))
        (λ d → cong f (subtype-path prop (shift-commute xs j i e d)))))
      (mixed-slope (λ d e → f (shift (shift xs i d) j e , inside-ij d e)))

  -- Exercise I.4.1, stated for any two selected coordinates in any R^n.
  two-coordinate-taylor : {n : ℕ} (f : Vec R n → R) (xs : Vec R n)
    (i j : Fin n) (d e : D) →
    f (shift (shift xs i d) j e) ≡
      ((f xs + value d * partial f i xs) + value e * partial f j xs) +
      (value d * value e) * partial (partial f j) i xs
  two-coordinate-taylor f xs i j d e =
    trans (partial-taylor f j (shift xs i d) e)
      (trans (cong₂ _+_ (partial-taylor f i xs d)
        (cong (value e *_) (partial-taylor (partial f j) i xs d)))
        (trans (cong ((f xs + value d * partial f i xs) +_)
          (distribˡ (value e) (partial f j xs)
            (value d * partial (partial f j) i xs)))
          (trans (sym (+-assoc (f xs + value d * partial f i xs)
            (value e * partial f j xs)
            (value e * (value d * partial (partial f j) i xs))))
            (cong (((f xs + value d * partial f i xs) + value e * partial f j xs) +_)
              (trans (*-swap (value e) (value d) (partial (partial f j) i xs))
                (sym (*-assoc (value d) (value e) (partial (partial f j) i xs))))))))

  partial-add : {n : ℕ} (f g : Vec R n → R) (i : Fin n) (xs : Vec R n) →
    partial (λ ys → f ys + g ys) i xs ≡ partial f i xs + partial g i xs
  partial-add f g i xs = slope-add (λ d → f (shift xs i d)) (λ d → g (shift xs i d))

  partial-scale : {n : ℕ} (r : R) (f : Vec R n → R) (i : Fin n) (xs : Vec R n) →
    partial (λ ys → r * f ys) i xs ≡ r * partial f i xs
  partial-scale r f i xs = slope-scale r (λ d → f (shift xs i d))

  partial-product : {n : ℕ} (f g : Vec R n → R) (i : Fin n) (xs : Vec R n) →
    partial (λ ys → f ys * g ys) i xs ≡
    f xs * partial g i xs + g xs * partial f i xs
  partial-product f g i xs =
    trans (slope-product (λ d → f (shift xs i d)) (λ d → g (shift xs i d)))
      (cong₂ _+_
        (cong (_* partial g i xs) (cong f (shift-zero xs i)))
        (cong (_* partial f i xs) (cong g (shift-zero xs i))))

  -- Exercise I.4.6: it is impossible that every product of two universal
  -- infinitesimals vanishes, if the scalar ring is nontrivial.
  universal-products-nonzero : 0r ≢ 1r →
    ¬ ((d e : D) → value d * value e ≡ 0r)
  universal-products-nonzero nontrivial all-zero = nontrivial
    (cancel-infinitesimals 0r 1r (λ e →
      trans (*-zeroʳ (value e))
        (trans (sym (cancel-infinitesimals (value e) 0r
          (λ d → trans (all-zero d e) (sym (*-zeroʳ (value d))))))
          (sym (*-identityʳ (value e))))))

  -- Exercise I.4.2: the scalar version of Property W.
  productD : D → D → D
  productD d e = scaleD d (value e)

  W-extension : (D → D → R) → D → R
  W-extension f z = f zeroD zeroD + value z * slope (λ e → slope (λ d → f d e))

  W-factorization : (f : D → D → R) →
    ((d : D) → f d zeroD ≡ f zeroD zeroD) →
    ((e : D) → f zeroD e ≡ f zeroD zeroD) →
    (d e : D) → f d e ≡ W-extension f (productD d e)
  W-factorization f axis₁ axis₂ d e =
    begin
      f d e
    ≡⟨ expansion (λ d′ → f d′ e) d ⟩
      f zeroD e + value d * slope (λ d′ → f d′ e)
    ≡⟨ cong₂ _+_ (axis₂ e)
         (cong (value d *_) (expansion (λ e′ → slope (λ d′ → f d′ e′)) e)) ⟩
      f zeroD zeroD + value d *
        (slope (λ d′ → f d′ zeroD) + value e * slope (λ e′ → slope (λ d′ → f d′ e′)))
    ≡⟨ cong (λ z → f zeroD zeroD + value d *
          (z + value e * slope (λ e′ → slope (λ d′ → f d′ e′))))
        (trans (slope-cong (λ d′ → f d′ zeroD) (λ _ → f zeroD zeroD) axis₁)
          (slope-constant (f zeroD zeroD))) ⟩
      f zeroD zeroD + value d *
        (0r + value e * slope (λ e′ → slope (λ d′ → f d′ e′)))
    ≡⟨ cong (λ z → f zeroD zeroD + value d * z)
        (+-identityˡ (value e * slope (λ e′ → slope (λ d′ → f d′ e′)))) ⟩
      f zeroD zeroD + value d *
        (value e * slope (λ e′ → slope (λ d′ → f d′ e′)))
    ≡⟨ cong (f zeroD zeroD +_)
        (sym (*-assoc (value d) (value e) (slope (λ e′ → slope (λ d′ → f d′ e′))))) ⟩
      W-extension f (productD d e) ∎

  products-determine : (f g : D → R) →
    ((d e : D) → f (productD d e) ≡ g (productD d e)) →
    (z : D) → f z ≡ g z
  products-determine f g p z =
    trans (expansion f z)
      (trans (cong₂ _+_ same-base (cong (value z *_) same-slope))
        (sym (expansion g z)))
    where
    same-base : f zeroD ≡ g zeroD
    same-base =
      trans (sym (value-cong f (productD zeroD zeroD) zeroD (*-zeroˡ 0r)))
        (trans (p zeroD zeroD)
          (value-cong g (productD zeroD zeroD) zeroD (*-zeroˡ 0r)))

    same-product : (d e : D) →
      (value d * value e) * slope f ≡ (value d * value e) * slope g
    same-product d e = +-cancelˡ (f zeroD)
      (trans (sym (expansion f (productD d e)))
        (trans (p d e)
          (trans (expansion g (productD d e))
            (cong (_+ ((value d * value e) * slope g)) (sym same-base)))))

    same-slope : slope f ≡ slope g
    same-slope = cancel-infinitesimals (slope f) (slope g)
      (λ e → cancel-infinitesimals (value e * slope f) (value e * slope g)
        (λ d → trans (sym (*-assoc (value d) (value e) (slope f)))
          (trans (same-product d e) (*-assoc (value d) (value e) (slope g)))))

  W-unique : (f : D → D → R) →
    ((d : D) → f d zeroD ≡ f zeroD zeroD) →
    ((e : D) → f zeroD e ≡ f zeroD zeroD) →
    (t : D → R) → ((d e : D) → f d e ≡ t (productD d e)) →
    (z : D) → t z ≡ W-extension f z
  W-unique f axis₁ axis₂ t p = products-determine t (W-extension f)
    (λ d e → trans (sym (p d e)) (W-factorization f axis₁ axis₂ d e))

  W-vector-extension : {n : ℕ} → (D → D → Vec R n) → D → Vec R n
  W-vector-extension f z = tabulate (λ i → W-extension (λ d e → lookup (f d e) i) z)

  W-vector-factorization : {n : ℕ} (f : D → D → Vec R n) →
    ((d : D) → f d zeroD ≡ f zeroD zeroD) →
    ((e : D) → f zeroD e ≡ f zeroD zeroD) →
    (d e : D) → f d e ≡ W-vector-extension f (productD d e)
  W-vector-factorization f axis₁ axis₂ d e = vec-ext (λ i →
    trans (W-factorization (λ d′ e′ → lookup (f d′ e′) i)
      (λ d′ → cong (λ xs → lookup xs i) (axis₁ d′))
      (λ e′ → cong (λ xs → lookup xs i) (axis₂ e′)) d e)
      (sym (lookup-tabulate (λ j → W-extension (λ d′ e′ → lookup (f d′ e′) j)
        (productD d e)) i)))

  W-vector-unique : {n : ℕ} (f : D → D → Vec R n) →
    ((d : D) → f d zeroD ≡ f zeroD zeroD) →
    ((e : D) → f zeroD e ≡ f zeroD zeroD) →
    (t : D → Vec R n) → ((d e : D) → f d e ≡ t (productD d e)) →
    (z : D) → t z ≡ W-vector-extension f z
  W-vector-unique f axis₁ axis₂ t p z = vec-ext (λ i →
    products-determine (λ d → lookup (t d) i)
      (λ d → lookup (W-vector-extension f d) i)
      (λ d e → cong (λ xs → lookup xs i)
        (trans (sym (p d e)) (W-vector-factorization f axis₁ axis₂ d e))) z)

  -- Exercise I.4.5. First isolate the homogeneous case in every dimension.
  product : {n : ℕ} → Vec D n → R
  product [] = 1r
  product (d ∷ ds) = value d * product ds

  top-coefficient : {n : ℕ} → (Vec D n → R) → R
  top-coefficient {zero} f = f []
  top-coefficient {suc n} f = top-coefficient (λ ds → slope (λ d → f (d ∷ ds)))

  ZeroFaces : {n : ℕ} → (Vec D n → R) → Set ℓ
  ZeroFaces {n} f = (i : Fin n) (ds : Vec D n) → f (update ds i zeroD) ≡ 0r

  multilinear-factor : {n : ℕ} (f : Vec D n → R) → ZeroFaces f →
    (ds : Vec D n) → f ds ≡ product ds * top-coefficient f
  multilinear-factor {zero} f faces [] = sym (*-identityˡ (f []))
  multilinear-factor {suc n} f faces (d ∷ ds) =
    trans (expansion (λ e → f (e ∷ ds)) d)
      (trans (cong (_+ (value d * slope (λ e → f (e ∷ ds))))
        (faces fzero (d ∷ ds)))
        (trans (+-identityˡ (value d * slope (λ e → f (e ∷ ds))))
          (trans (cong (value d *_) (multilinear-factor
            (λ es → slope (λ e → f (e ∷ es))) tail-faces ds))
            (sym (*-assoc (value d) (product ds)
              (top-coefficient (λ es → slope (λ e → f (e ∷ es)))))))))
    where
    tail-faces : ZeroFaces (λ es → slope (λ e → f (e ∷ es)))
    tail-faces i es =
      trans (slope-cong (λ e → f (e ∷ update es i zeroD)) (λ _ → 0r)
        (λ e → faces (fsuc i) (e ∷ es))) (slope-constant 0r)

  cancel-products : (n : ℕ) (b c : R) →
    ((ds : Vec D n) → product ds * b ≡ product ds * c) → b ≡ c
  cancel-products zero b c p = trans (sym (*-identityˡ b))
    (trans (p []) (*-identityˡ c))
  cancel-products (suc n) b c p = cancel-products n b c
    (λ ds → cancel-infinitesimals (product ds * b) (product ds * c)
      (λ d → trans (sym (*-assoc (value d) (product ds) b))
        (trans (p (d ∷ ds)) (*-assoc (value d) (product ds) c))))

  CommonFaces : {n : ℕ} → (Vec D n → R) → Set ℓ
  CommonFaces {n} f = (ds : Vec D n) (i j : Fin n) →
    f (update ds i zeroD) ≡ f (update ds j zeroD)

  private
    erase-all : {n : ℕ} (f : Vec D n → R) →
      ((ds : Vec D n) (i : Fin n) → f ds ≡ f (update ds i zeroD)) →
      (ds : Vec D n) → f ds ≡ f (replicate zeroD)
    erase-all {zero} f invariant [] = refl
    erase-all {suc n} f invariant (d ∷ ds) =
      trans (invariant (d ∷ ds) fzero)
        (erase-all (λ es → f (zeroD ∷ es))
          (λ es i → invariant (zeroD ∷ es) (fsuc i)) ds)

    update-zero-vector : {n : ℕ} (i : Fin n) →
      update (replicate zeroD) i zeroD ≡ replicate zeroD
    update-zero-vector i =
      trans (cong (update (replicate zeroD) i) (sym (lookup-replicate zeroD i)))
        (update-identity (replicate zeroD) i)

    add-back : (a x : R) → a + (x - a) ≡ x
    add-back a x = trans (+-swap a x (- a))
      (trans (cong (x +_) (+-inverseʳ a)) (+-identityʳ x))

  common-faces-constant : {n : ℕ} (f : Vec D n → R) → CommonFaces f →
    (ds : Vec D n) (i : Fin n) → f (update ds i zeroD) ≡ f (replicate zeroD)
  common-faces-constant f common ds i =
    trans (erase-all (λ es → f (update es i zeroD))
      (λ es j → trans (common es i j)
        (trans (sym (cong f (update-overwrite es j zeroD zeroD)))
          (common (update es j zeroD) j i))) ds)
      (cong f (update-zero-vector i))

  Wn-coefficient : {n : ℕ} → (Vec D n → R) → R
  Wn-coefficient f = top-coefficient (λ ds → f ds - f (replicate zeroD))

  Wn-expansion : {n : ℕ} (f : Vec D n → R) → CommonFaces f →
    (ds : Vec D n) → f ds ≡ f (replicate zeroD) + product ds * Wn-coefficient f
  Wn-expansion f common ds =
    trans (sym (add-back (f (replicate zeroD)) (f ds)))
      (cong (f (replicate zeroD) +_)
        (multilinear-factor (λ es → f es - f (replicate zeroD))
          (λ i es → trans (cong (_- f (replicate zeroD))
            (common-faces-constant f common es i))
            (+-inverseʳ (f (replicate zeroD)))) ds))

  product-zero-vector : {n : ℕ} → product {suc n} (replicate zeroD) ≡ 0r
  product-zero-vector {n} = *-zeroˡ (product {n} (replicate zeroD))

  affine-products-injective : {n : ℕ} (a b c e : R) →
    ((ds : Vec D (suc n)) → a + product ds * b ≡ c + product ds * e) →
    (a , b) ≡ (c , e)
  affine-products-injective {n} a b c e p = cong₂ _,_ same-base same-coefficient
    where
    at-zero : (x y : R) → x + product {suc n} (replicate zeroD) * y ≡ x
    at-zero x y = trans (cong (λ z → x + z * y) (product-zero-vector {n}))
      (trans (cong (x +_) (*-zeroˡ y)) (+-identityʳ x))

    same-base : a ≡ c
    same-base = trans (sym (at-zero a b))
      (trans (p (replicate zeroD)) (at-zero c e))

    same-coefficient : b ≡ e
    same-coefficient = cancel-products (suc n) b e
      (λ ds → +-cancelˡ a (trans (p ds)
        (cong (_+ (product ds * e)) (sym same-base))))

  Wn-unique : {n : ℕ} (f : Vec D (suc n) → R) → CommonFaces f →
    (a b : R) → ((ds : Vec D (suc n)) → f ds ≡ a + product ds * b) →
    (f (replicate zeroD) , Wn-coefficient f) ≡ (a , b)
  Wn-unique {n} f common a b p =
    affine-products-injective {n} (f (replicate zeroD)) (Wn-coefficient f) a b
      (λ ds → trans (sym (Wn-expansion f common ds)) (p ds))

  -- The abstract Property W used in Exercise I.4.3. Its uniqueness field is
  -- pointwise. Scalar and finite-product instances above require only KL.
  Axis₁ : {a : Level} {M : Set a} → (D → D → M) → Set (ℓ ⊔ a)
  Axis₁ f = (d : D) → f d zeroD ≡ f zeroD zeroD

  Axis₂ : {a : Level} {M : Set a} → (D → D → M) → Set (ℓ ⊔ a)
  Axis₂ f = (e : D) → f zeroD e ≡ f zeroD zeroD

  record PropertyW {a : Level} (M : Set a) : Set (ℓ ⊔ a) where
    field
      lift : (f : D → D → M) → Axis₁ f → Axis₂ f → D → M
      factor : (f : D → D → M) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
        (d e : D) → f d e ≡ lift f axis₁ axis₂ (productD d e)
      unique : (f : D → D → M) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
        (t : D → M) → ((d e : D) → f d e ≡ t (productD d e)) →
        (z : D) → t z ≡ lift f axis₁ axis₂ z

  scalar-W : PropertyW R
  PropertyW.lift scalar-W f _ _ = W-extension f
  PropertyW.factor scalar-W = W-factorization
  PropertyW.unique scalar-W = W-unique

  vector-W : (n : ℕ) → PropertyW (Vec R n)
  PropertyW.lift (vector-W n) f _ _ = W-vector-extension f
  PropertyW.factor (vector-W n) = W-vector-factorization
  PropertyW.unique (vector-W n) = W-vector-unique

  -- Equalizers preserve Property W. Proposition-valued equalizer fibers
  -- express the subobject condition; in particular isSet P implies it.
  module Equalizers {a b : Level} {M : Set a} {P : Set b}
    (WM : PropertyW M) (WP : PropertyW P) (F G : M → P)
    (fiber-prop : (x : M) → isProp (F x ≡ G x)) where

    N : Set (a ⊔ b)
    N = Σ M (λ x → F x ≡ G x)

    base-map : (D → D → N) → D → D → M
    base-map f d e = fst (f d e)

    base-axis₁ : (f : D → D → N) → Axis₁ f → Axis₁ (base-map f)
    base-axis₁ f axis₁ d = cong fst (axis₁ d)

    base-axis₂ : (f : D → D → N) → Axis₂ f → Axis₂ (base-map f)
    base-axis₂ f axis₂ e = cong fst (axis₂ e)

    base-lift : (f : D → D → N) → Axis₁ f → Axis₂ f → D → M
    base-lift f axis₁ axis₂ = PropertyW.lift WM (base-map f)
      (base-axis₁ f axis₁) (base-axis₂ f axis₂)

    base-factor : (f : D → D → N) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
      (d e : D) → fst (f d e) ≡ base-lift f axis₁ axis₂ (productD d e)
    base-factor f axis₁ axis₂ = PropertyW.factor WM (base-map f)
      (base-axis₁ f axis₁) (base-axis₂ f axis₂)

    lift-equalizes : (f : D → D → N) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
      (z : D) → F (base-lift f axis₁ axis₂ z) ≡ G (base-lift f axis₁ axis₂ z)
    lift-equalizes f axis₁ axis₂ z =
      trans (PropertyW.unique WP target-map target-axis₁ target-axis₂
        (λ d → F (base-lift f axis₁ axis₂ d)) factor-F z)
        (sym (PropertyW.unique WP target-map target-axis₁ target-axis₂
          (λ d → G (base-lift f axis₁ axis₂ d)) factor-G z))
      where
      target-map : D → D → P
      target-map d e = F (fst (f d e))

      target-axis₁ : Axis₁ target-map
      target-axis₁ d = cong (λ q → F (fst q)) (axis₁ d)

      target-axis₂ : Axis₂ target-map
      target-axis₂ e = cong (λ q → F (fst q)) (axis₂ e)

      factor-F : (d e : D) →
        target-map d e ≡ F (base-lift f axis₁ axis₂ (productD d e))
      factor-F d e = cong F (base-factor f axis₁ axis₂ d e)

      factor-G : (d e : D) →
        target-map d e ≡ G (base-lift f axis₁ axis₂ (productD d e))
      factor-G d e = trans (snd (f d e)) (cong G (base-factor f axis₁ axis₂ d e))

    equalizer-lift : (f : D → D → N) → Axis₁ f → Axis₂ f → D → N
    equalizer-lift f axis₁ axis₂ z =
      base-lift f axis₁ axis₂ z , lift-equalizes f axis₁ axis₂ z

    equalizer-factor : (f : D → D → N) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
      (d e : D) → f d e ≡ equalizer-lift f axis₁ axis₂ (productD d e)
    equalizer-factor f axis₁ axis₂ d e =
      subtype-path fiber-prop (base-factor f axis₁ axis₂ d e)

    equalizer-unique : (f : D → D → N) (axis₁ : Axis₁ f) (axis₂ : Axis₂ f) →
      (t : D → N) → ((d e : D) → f d e ≡ t (productD d e)) →
      (z : D) → t z ≡ equalizer-lift f axis₁ axis₂ z
    equalizer-unique f axis₁ axis₂ t p z = subtype-path fiber-prop
      (PropertyW.unique WM (base-map f) (base-axis₁ f axis₁) (base-axis₂ f axis₂)
        (λ d → fst (t d)) (λ d e → cong fst (p d e)) z)

    equalizer-W : PropertyW N
    PropertyW.lift equalizer-W = equalizer-lift
    PropertyW.factor equalizer-W = equalizer-factor
    PropertyW.unique equalizer-W = equalizer-unique

  -- Exercise I.4.7: the classical sum-of-squares implication is incompatible
  -- with KL and a nontrivial ring in which 2 is invertible.
  private
    nilpotent-sum-square : (d e : R) → d * d ≡ 0r → e * e ≡ 0r →
      (d + e) * (d + e) ≡ d * e + d * e
    nilpotent-sum-square d e dd ee =
      trans (expand-product d e d e)
        (trans (cong₂ _+_
          (trans (cong (_+ (d * e)) dd) (+-identityˡ (d * e)))
          (trans (cong ((e * d) +_) ee) (+-identityʳ (e * d))))
          (cong ((d * e) +_) (*-comm e d)))

    nilpotent-sum-of-squares : (d e : D) →
      (value d + value e) * (value d + value e) +
      (value d - value e) * (value d - value e) ≡ 0r
    nilpotent-sum-of-squares d e =
      trans (cong₂ _+_
        (nilpotent-sum-square (value d) (value e) (square-zero d) (square-zero e))
        (trans (nilpotent-sum-square (value d) (- value e) (square-zero d)
          (trans (neg-mul-neg (value e) (value e)) (square-zero e)))
          (cong₂ _+_ (neg-mulʳ (value d) (value e))
                     (neg-mulʳ (value d) (value e)))))
        (trans (+-shuffle (value d * value e) (value d * value e)
                          (- (value d * value e)) (- (value d * value e)))
          (trans (cong₂ _+_ (+-inverseʳ (value d * value e))
                             (+-inverseʳ (value d * value e))) (+-identityˡ 0r)))

    cancel-double-zero : (half : R) → (1r + 1r) * half ≡ 1r →
      (x : R) → x + x ≡ 0r → x ≡ 0r
    cancel-double-zero half inverse x twice-zero =
      begin
        x
      ≡⟨ sym (*-identityˡ x) ⟩
        1r * x
      ≡⟨ cong (_* x) (sym inverse) ⟩
        ((1r + 1r) * half) * x
      ≡⟨ *-assoc (1r + 1r) half x ⟩
        (1r + 1r) * (half * x)
      ≡⟨ *-swap (1r + 1r) half x ⟩
        half * ((1r + 1r) * x)
      ≡⟨ cong (half *_) (distribʳ 1r 1r x) ⟩
        half * (1r * x + 1r * x)
      ≡⟨ cong (half *_) (cong₂ _+_ (*-identityˡ x) (*-identityˡ x)) ⟩
        half * (x + x)
      ≡⟨ cong (half *_) twice-zero ⟩
        half * 0r
      ≡⟨ *-zeroʳ half ⟩
        0r ∎

  sum-of-squares-obstruction : 0r ≢ 1r →
    (half : R) → (1r + 1r) * half ≡ 1r →
    ¬ ((x y : R) → x * x + y * y ≡ 0r → x * x ≡ 0r)
  sum-of-squares-obstruction nontrivial half inverse classical-rule =
    universal-products-nonzero nontrivial
      (λ d e → cancel-double-zero half inverse (value d * value e)
        (trans (sym (nilpotent-sum-square (value d) (value e)
          (square-zero d) (square-zero e)))
          (classical-rule (value d + value e) (value d - value e)
            (nilpotent-sum-of-squares d e))))

  -- Exercise I.4.4, stability part. The scalar instance requires the
  -- symmetric-function descent theorem I.3.3 and is not assumed here.
  Symmetric : {a : Level} {M : Set a} {n : ℕ} → (Vec D n → M) → Set (ℓ ⊔ a)
  Symmetric {n = n} f = (p : Permutation n) (ds : Vec D n) →
    f (permute p ds) ≡ f ds

  symmetric-map : {a b : Level} {M : Set a} {P : Set b} {n : ℕ}
    (f : Vec D n → M) (g : M → P) → Symmetric f → Symmetric (λ ds → g (f ds))
  symmetric-map f g symmetric p ds = cong g (symmetric p ds)

  record SymmetricDescent {a : Level} {n : ℕ} (Y : Set ℓ)
    (q : Vec D n → Y) (M : Set a) : Set (ℓ ⊔ a) where
    field
      descend : (f : Vec D n → M) → Symmetric f → Y → M
      factor : (f : Vec D n → M) (symmetric : Symmetric f) →
        (ds : Vec D n) → f ds ≡ descend f symmetric (q ds)
      unique : (f : Vec D n → M) (symmetric : Symmetric f) →
        (t : Y → M) → ((ds : Vec D n) → f ds ≡ t (q ds)) →
        (y : Y) → t y ≡ descend f symmetric y

  module SymmetricEqualizers {a b : Level} {n : ℕ} {Y : Set ℓ}
    (q : Vec D n → Y) {M : Set a} {P : Set b}
    (WM : SymmetricDescent Y q M) (WP : SymmetricDescent Y q P)
    (F G : M → P) (fiber-prop : (x : M) → isProp (F x ≡ G x)) where

    N : Set (a ⊔ b)
    N = Σ M (λ x → F x ≡ G x)

    base-map : (Vec D n → N) → Vec D n → M
    base-map f ds = fst (f ds)

    base-symmetric : (f : Vec D n → N) → Symmetric f → Symmetric (base-map f)
    base-symmetric f symmetric = symmetric-map f fst symmetric

    base-descent : (f : Vec D n → N) → Symmetric f → Y → M
    base-descent f symmetric =
      SymmetricDescent.descend WM (base-map f) (base-symmetric f symmetric)

    base-factor : (f : Vec D n → N) (symmetric : Symmetric f) →
      (ds : Vec D n) → fst (f ds) ≡ base-descent f symmetric (q ds)
    base-factor f symmetric =
      SymmetricDescent.factor WM (base-map f) (base-symmetric f symmetric)

    descent-equalizes : (f : Vec D n → N) (symmetric : Symmetric f) →
      (y : Y) → F (base-descent f symmetric y) ≡ G (base-descent f symmetric y)
    descent-equalizes f symmetric y =
      trans (SymmetricDescent.unique WP target target-symmetric
        (λ z → F (base-descent f symmetric z)) factor-F y)
        (sym (SymmetricDescent.unique WP target target-symmetric
          (λ z → G (base-descent f symmetric z)) factor-G y))
      where
      target : Vec D n → P
      target ds = F (fst (f ds))

      target-symmetric : Symmetric target
      target-symmetric = symmetric-map f (λ z → F (fst z)) symmetric

      factor-F : (ds : Vec D n) → target ds ≡ F (base-descent f symmetric (q ds))
      factor-F ds = cong F (base-factor f symmetric ds)

      factor-G : (ds : Vec D n) → target ds ≡ G (base-descent f symmetric (q ds))
      factor-G ds = trans (snd (f ds)) (cong G (base-factor f symmetric ds))

    equalizer-descent : (f : Vec D n → N) → Symmetric f → Y → N
    equalizer-descent f symmetric y =
      base-descent f symmetric y , descent-equalizes f symmetric y

    equalizer-factor : (f : Vec D n → N) (symmetric : Symmetric f) →
      (ds : Vec D n) → f ds ≡ equalizer-descent f symmetric (q ds)
    equalizer-factor f symmetric ds =
      subtype-path fiber-prop (base-factor f symmetric ds)

    equalizer-unique : (f : Vec D n → N) (symmetric : Symmetric f) →
      (t : Y → N) → ((ds : Vec D n) → f ds ≡ t (q ds)) →
      (y : Y) → t y ≡ equalizer-descent f symmetric y
    equalizer-unique f symmetric t p y = subtype-path fiber-prop
      (SymmetricDescent.unique WM (base-map f) (base-symmetric f symmetric)
        (λ z → fst (t z)) (λ ds → cong fst (p ds)) y)

    equalizer-symmetric-descent : SymmetricDescent Y q N
    SymmetricDescent.descend equalizer-symmetric-descent = equalizer-descent
    SymmetricDescent.factor equalizer-symmetric-descent = equalizer-factor
    SymmetricDescent.unique equalizer-symmetric-descent = equalizer-unique






