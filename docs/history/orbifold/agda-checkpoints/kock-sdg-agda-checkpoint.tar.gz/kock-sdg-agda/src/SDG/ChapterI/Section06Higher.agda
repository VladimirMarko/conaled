{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Higher where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; lookup; _+ℕ_; nat-add-zeroʳ; nat-add-sucʳ)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.JetAlgebra
open import SDG.Infinitesimal.Polynomial
open import SDG.Algebra.Symmetric using (_≤_; z≤n; s≤s)
import SDG.ChapterI.Section03 as S3

module Inclusions {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Jets A

  raise-products : {n : ℕ} (xs : Vec R n) (q m : ℕ) (r : R) →
    ProductsZero xs q r → ProductsZero xs (q +ℕ m) r
  raise-products xs q zero r p = subst (λ k → ProductsZero xs k r) (sym (nat-add-zeroʳ q)) p
  raise-products xs q (suc m) r p = subst (λ k → ProductsZero xs k r) (sym (nat-add-sucʳ q m))
    (products-weaken xs (q +ℕ m) r (raise-products xs q m r p))

  includeBy : {k n : ℕ} → DJet k n → (m : ℕ) → DJet (k +ℕ m) n
  includeBy {k} d m = jet (coords d) (raise-products (coords d) (suc k) m 1r (vanish d))

  le-difference : {k l : ℕ} → k ≤ l → Σ ℕ (λ m → k +ℕ m ≡ l)
  le-difference {l = l} z≤n = l , refl
  le-difference (s≤s p) with le-difference p
  ... | (m , e) = m , cong suc e

  includeLE : {k l n : ℕ} → k ≤ l → DJet k n → DJet l n
  includeLE {k} p d with le-difference p
  ... | (m , e) = jet (coords d)
    (subst (λ j → ProductsZero (coords d) (suc j) 1r) e (vanish (includeBy d m)))

-- Axiom 1″ implies Axiom 1′. The scalar object is an ordinary set, so
-- equal nilpotent values determine equal DK elements. No extensionality
-- of function spaces is required for this implication.
module HigherFromTotal {ℓ : Level} (A : CRing ℓ)
  (T : Polynomials.TotalKockLawvere A) (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open Jets A
  open JetAlgebra A
  open Polynomials A using (Polynomial; scalar; constantP; horner; evaluate; TotalKockLawvere)
  open TotalKockLawvere T

  coefficientVector : {k : ℕ} → Polynomial (suc zero) k → Vec R (suc k)
  coefficientVector (constantP a) = a ∷ []
  coefficientVector (horner (scalar a) p) = a ∷ coefficientVector p

  polynomialOfVector : {k : ℕ} → Vec R (suc k) → Polynomial (suc zero) k
  polynomialOfVector (a ∷ []) = constantP a
  polynomialOfVector (a ∷ b ∷ as) = horner (scalar a) (polynomialOfVector (b ∷ as))

  vector-retract : {k : ℕ} (as : Vec R (suc k)) → coefficientVector (polynomialOfVector as) ≡ as
  vector-retract (a ∷ []) = refl
  vector-retract (a ∷ b ∷ as) = cong (a ∷_) (vector-retract (b ∷ as))

  evaluation-conversion : {k : ℕ} (p : Polynomial (suc zero) k) (xs : Vec R (suc zero)) →
    evaluate p xs ≡ eval (coefficientVector p) (lookup xs fzero)
  evaluation-conversion (constantP a) (x ∷ []) = sym (eval-constant a x)
  evaluation-conversion (horner (scalar a) p) (x ∷ []) =
    cong (λ z → a + x * z) (evaluation-conversion p (x ∷ []))

  extractK : {k : ℕ} → DJet k (suc zero) → DK k
  extractK d = coordinateK d fzero

  extract-singleton : {k : ℕ} (d : DK k) → extractK (singletonK d) ≡ d
  extract-singleton {k} d = cong (nilpotent (valueK d))
    (setR (valueK d ^ suc k) 0r (nilpotence (extractK (singletonK d))) (nilpotence d))

  higher-coefficients : (k : ℕ) → (DK (suc k) → R) → Vec R (suc (suc k))
  higher-coefficients k g = coefficientVector (coefficients k zero (λ d → g (extractK d)))

  higher-reconstruction : (k : ℕ) (g : DK (suc k) → R) (d : DK (suc k)) →
    g d ≡ eval (higher-coefficients k g) (valueK d)
  higher-reconstruction k g d =
    trans (cong g (sym (extract-singleton d)))
      (trans (reconstruction k zero (λ e → g (extractK e)) (singletonK d))
        (evaluation-conversion (coefficients k zero (λ e → g (extractK e))) (valueK d ∷ [])))

  higher-uniqueness : (k : ℕ) (g : DK (suc k) → R) (as : Vec R (suc (suc k))) →
    ((d : DK (suc k)) → g d ≡ eval as (valueK d)) → higher-coefficients k g ≡ as
  higher-uniqueness k g as p =
    trans (cong coefficientVector (uniqueness k zero (λ e → g (extractK e)) (polynomialOfVector as)
      (λ d → trans (p (extractK d))
        (sym (trans (evaluation-conversion (polynomialOfVector as) (coords d))
          (cong (λ bs → eval bs (coordinate d fzero)) (vector-retract as)))))))
      (vector-retract as)

  higher : HigherKockLawvere
  HigherKockLawvere.coefficients higher = higher-coefficients
  HigherKockLawvere.reconstruction higher = higher-reconstruction
  HigherKockLawvere.uniqueness higher = higher-uniqueness
