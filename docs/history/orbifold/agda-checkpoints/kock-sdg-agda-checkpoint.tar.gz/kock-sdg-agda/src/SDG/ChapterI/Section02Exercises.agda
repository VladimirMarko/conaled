{-# OPTIONS --safe --without-K #-}

-- Kock I.2, Exercise 2.1: Fermat's axiom is an alternative to KL.
-- This module never assumes KockLawvere or a cancellation rule for an
-- individual difference x-y. All cancellation is derived from uniqueness.
module SDG.ChapterI.Section02Exercises where

open import SDG.Prelude
open import SDG.Algebra

module DifferenceAlgebra {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  subtract-zero : (x : R) → x - 0r ≡ x
  subtract-zero x = trans (cong (x +_) neg-zero) (+-identityʳ x)

  subtract-self : (x : R) → x - x ≡ 0r
  subtract-self = +-inverseʳ

  subtract-zero-implies-equal : (x y : R) → x - y ≡ 0r → x ≡ y
  subtract-zero-implies-equal x y p =
    +-cancelʳ (- y) (trans p (sym (+-inverseʳ y)))

  subtract-sums : (a b c d : R) →
    (a + b) - (c + d) ≡ (a - c) + (b - d)
  subtract-sums a b c d =
    trans (cong ((a + b) +_) (neg-add c d)) (+-shuffle a b (- c) (- d))

  multiply-difference : (r x y : R) → r * (x - y) ≡ (r * x) - (r * y)
  multiply-difference r x y =
    trans (distribˡ r x (- y)) (cong ((r * x) +_) (neg-mulʳ r y))

  difference-multiply : (x y r : R) → (x - y) * r ≡ (x * r) - (y * r)
  difference-multiply x y r =
    trans (distribʳ x (- y) r) (cong ((x * r) +_) (neg-mulˡ y r))

  subtract-products : (a b c d : R) →
    (a * b) - (c * d) ≡ ((a - c) * b) + (c * (b - d))
  subtract-products a b c d = sym
    (begin
      ((a - c) * b) + (c * (b - d))
    ≡⟨ cong₂ _+_ (difference-multiply a c b) (multiply-difference c b d) ⟩
      ((a * b) + (- (c * b))) + ((c * b) + (- (c * d)))
    ≡⟨ +-assoc (a * b) (- (c * b)) ((c * b) + (- (c * d))) ⟩
      (a * b) + ((- (c * b)) + ((c * b) + (- (c * d))))
    ≡⟨ cong ((a * b) +_) (+-inverse-cancelˡ (c * b) (- (c * d))) ⟩
      (a * b) - (c * d) ∎)

module Primitive {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  -- The quotient has two scalar arguments, i.e. is a curried map R*R -> R.
  -- Uniqueness is pointwise and therefore assumes no function extensionality.
  record Fermat : Set (lsuc ℓ) where
    field
      quotient : (R → R) → R → R → R
      decomposition : (f : R → R) (x y : R) →
        f x - f y ≡ (x - y) * quotient f x y
      uniqueness : (f : R → R) (h : R → R → R) →
        ((x y : R) → f x - f y ≡ (x - y) * h x y) →
        (x y : R) → quotient f x y ≡ h x y

module Results {ℓ : Level} (A : CRing ℓ) (F : Primitive.Fermat A) where
  open RingLemmas A
  open DifferenceAlgebra A
  open Primitive.Fermat F

  derivative : (R → R) → R → R
  derivative f x = quotient f x x

  quotient-constant : (r x y : R) → quotient (λ _ → r) x y ≡ 0r
  quotient-constant r = uniqueness (λ _ → r) (λ _ _ → 0r)
    (λ x y → trans (subtract-self r) (sym (*-zeroʳ (x - y))))

  quotient-identity : (x y : R) → quotient id x y ≡ 1r
  quotient-identity = uniqueness id (λ _ _ → 1r)
    (λ x y → sym (*-identityʳ (x - y)))

  quotient-add : (f g : R → R) (x y : R) →
    quotient (λ t → f t + g t) x y ≡ quotient f x y + quotient g x y
  quotient-add f g = uniqueness (λ t → f t + g t)
    (λ x y → quotient f x y + quotient g x y)
    (λ x y →
      trans (subtract-sums (f x) (g x) (f y) (g y))
        (trans (cong₂ _+_ (decomposition f x y) (decomposition g x y))
          (sym (distribˡ (x - y) (quotient f x y) (quotient g x y)))))

  quotient-scale : (r : R) (f : R → R) (x y : R) →
    quotient (λ t → r * f t) x y ≡ r * quotient f x y
  quotient-scale r f = uniqueness (λ t → r * f t)
    (λ x y → r * quotient f x y)
    (λ x y → trans (sym (multiply-difference r (f x) (f y)))
      (trans (cong (r *_) (decomposition f x y))
        (*-swap r (x - y) (quotient f x y))))

  quotient-product : (f g : R → R) (x y : R) →
    quotient (λ t → f t * g t) x y ≡
      quotient f x y * g x + f y * quotient g x y
  quotient-product f g = uniqueness (λ t → f t * g t)
    (λ x y → quotient f x y * g x + f y * quotient g x y)
    (λ x y →
      trans (subtract-products (f x) (g x) (f y) (g y))
        (trans (cong₂ _+_
          (cong (_* g x) (decomposition f x y))
          (cong (f y *_) (decomposition g x y)))
          (trans (cong₂ _+_
            (*-assoc (x - y) (quotient f x y) (g x))
            (*-swap (f y) (x - y) (quotient g x y)))
            (sym (distribˡ (x - y)
              (quotient f x y * g x) (f y * quotient g x y))))))

  quotient-chain : (f g : R → R) (x y : R) →
    quotient (f ∘ g) x y ≡ quotient f (g x) (g y) * quotient g x y
  quotient-chain f g = uniqueness (f ∘ g)
    (λ x y → quotient f (g x) (g y) * quotient g x y)
    (λ x y → trans (decomposition f (g x) (g y))
      (trans (cong (_* quotient f (g x) (g y)) (decomposition g x y))
        (trans (*-assoc (x - y) (quotient g x y) (quotient f (g x) (g y)))
          (cong ((x - y) *_) (*-comm (quotient g x y) (quotient f (g x) (g y)))))))

  -- All six clauses of Theorem I.2.2, derived from the alternative axiom.
  derivative-add : (f g : R → R) (x : R) →
    derivative (λ t → f t + g t) x ≡ derivative f x + derivative g x
  derivative-add f g x = quotient-add f g x x

  derivative-scale : (r : R) (f : R → R) (x : R) →
    derivative (λ t → r * f t) x ≡ r * derivative f x
  derivative-scale r f x = quotient-scale r f x x

  derivative-product : (f g : R → R) (x : R) →
    derivative (λ t → f t * g t) x ≡
      derivative f x * g x + f x * derivative g x
  derivative-product f g x = quotient-product f g x x

  derivative-chain : (f g : R → R) (x : R) →
    derivative (f ∘ g) x ≡ derivative f (g x) * derivative g x
  derivative-chain f g x = quotient-chain f g x x

  derivative-identity : (x : R) → derivative id x ≡ 1r
  derivative-identity x = quotient-identity x x

  derivative-constant : (r x : R) → derivative (λ _ → r) x ≡ 0r
  derivative-constant r x = quotient-constant r x x

  quotient-cong : (f g : R → R) → ((x : R) → f x ≡ g x) →
    (x y : R) → quotient f x y ≡ quotient g x y
  quotient-cong f g p = uniqueness f (quotient g)
    (λ x y → trans (cong₂ _-_ (p x) (p y)) (decomposition g x y))

  derivative-cong : (f g : R → R) → ((x : R) → f x ≡ g x) →
    (x : R) → derivative f x ≡ derivative g x
  derivative-cong f g p x = quotient-cong f g p x x

  -- Universally quantified differences may be cancelled even on the diagonal.
  -- This is a THEOREM: uniqueness for the constant-zero divided difference
  -- rules out any nonzero function annihilated by all coordinate differences.
  cancel-universal-differences : (h k : R → R → R) →
    ((x y : R) → (x - y) * h x y ≡ (x - y) * k x y) →
    (x y : R) → h x y ≡ k x y
  cancel-universal-differences h k p x y = subtract-zero-implies-equal (h x y) (k x y)
    (trans (sym (uniqueness (λ _ → 0r) (λ u v → h u v - k u v)
      difference-zero x y)) (quotient-constant 0r x y))
    where
      difference-zero : (u v : R) →
        0r - 0r ≡ (u - v) * (h u v - k u v)
      difference-zero u v = trans (subtract-self 0r)
        (sym (trans (multiply-difference (u - v) (h u v) (k u v))
          (trans (cong (_- ((u - v) * k u v)) (p u v))
            (subtract-self ((u - v) * k u v)))))

  -- Under zero-decidability, the diagonal indicator supplies two different
  -- divided differences of the zero function. This contradicts uniqueness.
  module ClassicalContradiction (nontrivial : 0r ≢ 1r)
    (decide-zero : (x : R) → Dec (x ≡ 0r)) where

    diagonal : R → R → R
    diagonal x y with decide-zero (x - y)
    ... | yes _ = 1r
    ... | no _ = 0r

    diagonal-on-zero-difference : (x y : R) → x - y ≡ 0r → diagonal x y ≡ 1r
    diagonal-on-zero-difference x y p with decide-zero (x - y)
    ... | yes _ = refl
    ... | no np = ⊥-elim (np p)

    difference-times-diagonal : (x y : R) → (x - y) * diagonal x y ≡ 0r
    difference-times-diagonal x y with decide-zero (x - y)
    ... | yes p = trans (cong (_* 1r) p) (*-zeroˡ 1r)
    ... | no _ = *-zeroʳ (x - y)

    diagonal-is-quotient-of-zero : (x y : R) →
      quotient (λ _ → 0r) x y ≡ diagonal x y
    diagonal-is-quotient-of-zero = uniqueness (λ _ → 0r) diagonal
      (λ x y → trans (subtract-self 0r) (sym (difference-times-diagonal x y)))

    contradiction : ⊥
    contradiction = nontrivial
      (trans (sym (quotient-constant 0r 0r 0r))
        (trans (diagonal-is-quotient-of-zero 0r 0r)
          (diagonal-on-zero-difference 0r 0r (subtract-self 0r))))

  zero-decidability-impossible : 0r ≢ 1r →
    ((x : R) → Dec (x ≡ 0r)) → ⊥
  zero-decidability-impossible = ClassicalContradiction.contradiction

  excluded-middle-impossible : 0r ≢ 1r → ((P : Set ℓ) → Dec P) → ⊥
  excluded-middle-impossible nontrivial em =
    zero-decidability-impossible nontrivial (λ x → em (x ≡ 0r))
