{-# OPTIONS --safe --without-K #-}

module SDG.Infinitesimal.Jets where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tabulate; lookup-tabulate;
   replicate; lookup-replicate; vec-ext)
import SDG.Combinatorics.FiniteSums as FS
import SDG.ChapterI.Section03 as S3

module Jets {ℓ : Level} (A : CRing ℓ) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  module Sum = FS.Sums A

  -- ProductsZero xs q r states that r times every product of q listed
  -- coordinates vanishes. Repetitions of coordinate indices are allowed.
  ProductsZero : {n : ℕ} → Vec R n → ℕ → R → Set ℓ
  ProductsZero xs zero r = r ≡ 0r
  ProductsZero {n} xs (suc q) r = (i : Fin n) → ProductsZero xs q (r * lookup xs i)

  zero-products : {n : ℕ} (xs : Vec R n) (q : ℕ) → ProductsZero xs q 0r
  zero-products xs zero = refl
  zero-products xs (suc q) i =
    subst (ProductsZero xs q) (sym (*-zeroˡ (lookup xs i))) (zero-products xs q)

  products-scale : {n : ℕ} (xs : Vec R n) (q : ℕ) (r a : R) →
    ProductsZero xs q a → ProductsZero xs q (r * a)
  products-scale xs zero r a p = trans (cong (r *_) p) (*-zeroʳ r)
  products-scale xs (suc q) r a p i =
    subst (ProductsZero xs q) (sym (*-assoc r a (lookup xs i)))
      (products-scale xs q r (a * lookup xs i) (p i))

  products-add : {n : ℕ} (xs : Vec R n) (q : ℕ) (a b : R) →
    ProductsZero xs q a → ProductsZero xs q b → ProductsZero xs q (a + b)
  products-add xs zero a b p s = trans (cong₂ _+_ p s) (+-identityˡ 0r)
  products-add xs (suc q) a b p s i =
    subst (ProductsZero xs q) (sym (distribʳ a b (lookup xs i)))
      (products-add xs q (a * lookup xs i) (b * lookup xs i) (p i) (s i))

  products-weaken : {n : ℕ} (xs : Vec R n) (q : ℕ) (r : R) →
    ProductsZero xs q r → ProductsZero xs (suc q) r
  products-weaken xs zero r p i = trans (cong (_* lookup xs i) p) (*-zeroˡ (lookup xs i))
  products-weaken xs (suc q) r p i = products-weaken xs q (r * lookup xs i) (p i)

  repeat-annihilate : {n : ℕ} (xs : Vec R n) (i : Fin n) (q : ℕ) (r : R) →
    ProductsZero xs q r → r * (lookup xs i ^ q) ≡ 0r
  repeat-annihilate xs i zero r p = trans (*-identityʳ r) p
  repeat-annihilate xs i (suc q) r p =
    trans (sym (*-assoc r (lookup xs i) (lookup xs i ^ q)))
      (repeat-annihilate xs i q (r * lookup xs i) (p i))

  record DJet (k n : ℕ) : Set ℓ where
    constructor jet
    field
      coords : Vec R n
      vanish : ProductsZero coords (suc k) 1r
  open DJet public

  Jet1 : ℕ → Set ℓ
  Jet1 = DJet (suc zero)

  coordinate : {k n : ℕ} → DJet k n → Fin n → R
  coordinate d = lookup (coords d)

  weakenJet : {k n : ℕ} → DJet k n → DJet (suc k) n
  weakenJet {k} d = jet (coords d) (products-weaken (coords d) (suc k) 1r (vanish d))

  coordinateK : {k n : ℕ} → DJet k n → Fin n → DK k
  coordinateK {k} d i = nilpotent (coordinate d i)
    (trans (sym (*-identityˡ (coordinate d i ^ suc k)))
      (repeat-annihilate (coords d) i (suc k) 1r (vanish d)))

  makeJet1 : {n : ℕ} (xs : Vec R n) →
    ((i j : Fin n) → lookup xs i * lookup xs j ≡ 0r) → Jet1 n
  makeJet1 xs p = jet xs (λ i j →
    trans (cong (_* lookup xs j) (*-identityˡ (lookup xs i))) (p i j))

  pair-zero : {n : ℕ} (d : Jet1 n) (i j : Fin n) → coordinate d i * coordinate d j ≡ 0r
  pair-zero d i j = trans (sym (cong (_* coordinate d j) (*-identityˡ (coordinate d i))))
    (vanish d i j)

  coordinateD : {n : ℕ} → Jet1 n → Fin n → D
  coordinateD d i = infinitesimal (coordinate d i) (pair-zero d i i)

  zeroJet : (k n : ℕ) → DJet k n
  zeroJet k n = jet (replicate 0r) (λ i →
    subst (ProductsZero (replicate 0r) k)
      (sym (trans (cong (1r *_) (lookup-replicate 0r i)) (*-zeroʳ 1r)))
      (zero-products (replicate 0r) k))

  axis : {n : ℕ} → Fin n → D → Jet1 n
  axis {n} i d = makeJet1 (tabulate (λ j → Sum.delta j i * value d))
    (λ j k →
      trans (cong₂ _*_ (lookup-tabulate (λ l → Sum.delta l i * value d) j)
        (lookup-tabulate (λ l → Sum.delta l i * value d) k))
        (trans (*-shuffle (Sum.delta j i) (value d) (Sum.delta k i) (value d))
          (trans (cong ((Sum.delta j i * Sum.delta k i) *_) (square-zero d))
            (*-zeroʳ (Sum.delta j i * Sum.delta k i)))))

  axis-coordinate : {n : ℕ} (i j : Fin n) (d : D) →
    coordinate (axis i d) j ≡ Sum.delta j i * value d
  axis-coordinate i j d = lookup-tabulate (λ k → Sum.delta k i * value d) j

  axis-own : {n : ℕ} (i : Fin n) (d : D) → coordinate (axis i d) i ≡ value d
  axis-own i d = trans (axis-coordinate i i d)
    (trans (cong (_* value d) (Sum.delta-same i)) (*-identityˡ (value d)))

  diagonal : {n : ℕ} → D → Jet1 n
  diagonal d = makeJet1 (replicate (value d))
    (λ i j → trans (cong₂ _*_ (lookup-replicate (value d) i) (lookup-replicate (value d) j))
      (square-zero d))

  diagonal-coordinate : {n : ℕ} (d : D) (i : Fin n) → coordinate (diagonal d) i ≡ value d
  diagonal-coordinate d i = lookup-replicate (value d) i

  reindex-products : {n m : ℕ} (ρ : Fin m → Fin n) (xs : Vec R n) (q : ℕ) (r : R) →
    ProductsZero xs q r → ProductsZero (tabulate (λ i → lookup xs (ρ i))) q r
  reindex-products ρ xs zero r p = p
  reindex-products ρ xs (suc q) r p i =
    subst (ProductsZero (tabulate (λ j → lookup xs (ρ j))) q)
      (sym (cong (r *_) (lookup-tabulate (λ j → lookup xs (ρ j)) i)))
      (reindex-products ρ xs q (r * lookup xs (ρ i)) (p (ρ i)))

  reindex : {k n m : ℕ} → (Fin m → Fin n) → DJet k n → DJet k m
  reindex {k} ρ d = jet (tabulate (λ i → coordinate d (ρ i)))
    (reindex-products ρ (coords d) (suc k) 1r (vanish d))

  duplicate-first : Jet1 (suc (suc zero)) → Jet1 (suc (suc (suc zero)))
  duplicate-first d = reindex indices d
    where
    indices : Fin (suc (suc (suc zero))) → Fin (suc (suc zero))
    indices fzero = fzero
    indices (fsuc fzero) = fzero
    indices (fsuc (fsuc fzero)) = fsuc fzero

  incl12 : Jet1 (suc (suc zero)) → Jet1 (suc (suc (suc zero)))
  incl12 d = makeJet1 (coordinate d fzero ∷ coordinate d (fsuc fzero) ∷ 0r ∷ []) proof
    where
    proof : (i j : Fin (suc (suc (suc zero)))) →
      lookup (coordinate d fzero ∷ coordinate d (fsuc fzero) ∷ 0r ∷ []) i *
      lookup (coordinate d fzero ∷ coordinate d (fsuc fzero) ∷ 0r ∷ []) j ≡ 0r
    proof fzero fzero = pair-zero d fzero fzero
    proof fzero (fsuc fzero) = pair-zero d fzero (fsuc fzero)
    proof fzero (fsuc (fsuc fzero)) = *-zeroʳ (coordinate d fzero)
    proof (fsuc fzero) fzero = pair-zero d (fsuc fzero) fzero
    proof (fsuc fzero) (fsuc fzero) = pair-zero d (fsuc fzero) (fsuc fzero)
    proof (fsuc fzero) (fsuc (fsuc fzero)) = *-zeroʳ (coordinate d (fsuc fzero))
    proof (fsuc (fsuc fzero)) fzero = *-zeroˡ (coordinate d fzero)
    proof (fsuc (fsuc fzero)) (fsuc fzero) = *-zeroˡ (coordinate d (fsuc fzero))
    proof (fsuc (fsuc fzero)) (fsuc (fsuc fzero)) = *-zeroˡ 0r

  sumJet : {n : ℕ} → Jet1 n → D
  sumJet {n} d = infinitesimal (Sum.sum (coordinate d))
    (trans (sym (Sum.sum-scaleʳ (coordinate d) (Sum.sum (coordinate d))))
      (trans (Sum.sum-cong (λ i →
        trans (sym (Sum.sum-scaleˡ (coordinate d i) (coordinate d)))
          (trans (Sum.sum-cong (pair-zero d i)) (Sum.sum-zero n))))
        (Sum.sum-zero n)))

  weightJet : {n : ℕ} → Vec R n → Jet1 n → Jet1 n
  weightJet weights d = makeJet1 (tabulate (λ i → coordinate d i * lookup weights i))
    (λ i j → trans
      (cong₂ _*_ (lookup-tabulate (λ k → coordinate d k * lookup weights k) i)
        (lookup-tabulate (λ k → coordinate d k * lookup weights k) j))
      (trans (*-shuffle (coordinate d i) (lookup weights i) (coordinate d j) (lookup weights j))
        (trans (cong (_* (lookup weights i * lookup weights j)) (pair-zero d i j))
          (*-zeroˡ (lookup weights i * lookup weights j)))))

  weightedD : {n : ℕ} → Vec R n → Jet1 n → D
  weightedD weights d = sumJet (weightJet weights d)

  weightedD-value : {n : ℕ} (weights : Vec R n) (d : Jet1 n) →
    value (weightedD weights d) ≡ Sum.sum (λ i → coordinate d i * lookup weights i)
  weightedD-value weights d = Sum.sum-cong
    (lookup-tabulate (λ i → coordinate d i * lookup weights i))

  scaleJet : {n : ℕ} → R → Jet1 n → Jet1 n
  scaleJet r d = weightJet (replicate r) d

  scaleJet-coordinate : {n : ℕ} (r : R) (d : Jet1 n) (i : Fin n) →
    coordinate (scaleJet r d) i ≡ coordinate d i * r
  scaleJet-coordinate r d i =
    trans (lookup-tabulate (λ j → coordinate d j * lookup (replicate r) j) i)
      (cong (coordinate d i *_) (lookup-replicate r i))

  -- Extensional identity for a subtype of the scalar set. This structural
  -- lemma is the only place where equality of vanishing witnesses is used.
  products-prop : (setR : isSet R) → FunExt lzero ℓ →
    {n : ℕ} (xs : Vec R n) (q : ℕ) (r : R) → isProp (ProductsZero xs q r)
  products-prop setR ext xs zero r = setR r 0r
  products-prop setR ext xs (suc q) r p s = ext
    (λ i → products-prop setR ext xs q (r * lookup xs i) (p i) (s i))

  jet-path : (setR : isSet R) → FunExt lzero ℓ → {k n : ℕ} {p q : DJet k n} →
    coords p ≡ coords q → p ≡ q
  jet-path setR ext {k} {p = jet xs p} {q = jet .xs q} refl =
    cong (jet xs) (products-prop setR ext xs (suc k) 1r p q)

  axis-zero : (setR : isSet R) → (ext : FunExt lzero ℓ) →
    {n : ℕ} (i : Fin n) → axis i zeroD ≡ zeroJet (suc zero) n
  axis-zero setR ext i = jet-path setR ext (vec-ext (λ j →
    trans (axis-coordinate i j zeroD)
      (trans (*-zeroʳ (Sum.delta j i)) (sym (lookup-replicate 0r j)))))

  diagonal-zero : (setR : isSet R) → (ext : FunExt lzero ℓ) →
    {n : ℕ} → diagonal {n} zeroD ≡ zeroJet (suc zero) n
  diagonal-zero setR ext = jet-path setR ext refl
