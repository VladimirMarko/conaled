{-# OPTIONS --safe --without-K #-}

module SDG.Forms.SignedSums where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Algebra.Powers
open import SDG.Finite using (Fin; fzero; fsuc; finToNat; Permutation; to; from)
import SDG.Combinatorics.FiniteSums as FS

module Sums {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ) where
  open Extra A Vmod public
  open PowerLemmas A using (_^_)
  module Scalar = FS.Sums A

  sum : {n : ℕ} → (Fin n → V) → V
  sum {zero} f = 0v
  sum {suc n} f = f fzero +v sum (λ i → f (fsuc i))

  sum-cong : {n : ℕ} {f g : Fin n → V} → ((i : Fin n) → f i ≡ g i) → sum f ≡ sum g
  sum-cong {zero} p = refl
  sum-cong {suc n} p = cong₂ _+v_ (p fzero) (sum-cong (λ i → p (fsuc i)))

  sum-zero : (n : ℕ) → sum {n} (λ _ → 0v) ≡ 0v
  sum-zero zero = refl
  sum-zero (suc n) = trans (cong (0v +v_) (sum-zero n)) (add-zeroˡ 0v)

  sum-add : {n : ℕ} (f g : Fin n → V) → sum (λ i → f i +v g i) ≡ sum f +v sum g
  sum-add {zero} f g = sym (add-zeroˡ 0v)
  sum-add {suc n} f g = trans (cong ((f fzero +v g fzero) +v_) (sum-add (f ∘ fsuc) (g ∘ fsuc)))
    (add-shuffle (f fzero) (g fzero) (sum (f ∘ fsuc)) (sum (g ∘ fsuc)))

  sum-scale : {n : ℕ} (r : R) (f : Fin n → V) → sum (λ i → r • f i) ≡ r • sum f
  sum-scale {zero} r f = sym (scalar-zero r)
  sum-scale {suc n} r f = trans (cong ((r • f fzero) +v_) (sum-scale r (f ∘ fsuc)))
    (sym (scalar-distrib r (f fzero) (sum (f ∘ fsuc))))

  sum-coefficients : {n : ℕ} (f : Fin n → R) (v : V) → sum (λ i → f i • v) ≡ Scalar.sum f • v
  sum-coefficients {zero} f v = sym (zero-scalar v)
  sum-coefficients {suc n} f v = trans (cong ((f fzero • v) +v_) (sum-coefficients (f ∘ fsuc) v))
    (sym (scalar-add (f fzero) (Scalar.sum (f ∘ fsuc)) v))

  sum-swap : {n m : ℕ} (f : Fin n → Fin m → V) → sum (λ i → sum (f i)) ≡ sum (λ j → sum (λ i → f i j))
  sum-swap {zero} {m} f = sym (sum-zero m)
  sum-swap {suc n} f = trans (cong (sum (f fzero) +v_) (sum-swap (λ i j → f (fsuc i) j)))
    (sym (sum-add (f fzero) (λ j → sum (λ i → f (fsuc i) j))))

  sum-delta : {n : ℕ} (f : Fin n → V) (i : Fin n) → sum (λ j → Scalar.delta i j • f j) ≡ f i
  sum-delta {suc n} f fzero = trans (cong₂ _+v_ (scalar-one (f fzero))
    (trans (sum-cong (λ i → zero-scalar (f (fsuc i)))) (sum-zero n))) (add-zeroʳ (f fzero))
  sum-delta f (fsuc i) = trans (cong₂ _+v_ (zero-scalar (f fzero)) (sum-delta (f ∘ fsuc) i))
    (add-zeroˡ (f (fsuc i)))

  sum-permute : {n : ℕ} (p : Permutation n) (f : Fin n → V) → sum (λ i → f (to p i)) ≡ sum f
  sum-permute p f = trans (sum-cong (λ i → sym (sum-delta f (to p i))))
    (trans (sum-swap (λ i j → Scalar.delta (to p i) j • f j))
      (sum-cong (λ j → trans (sum-cong (λ i → cong (_• f j) (Scalar.delta-permute-one p i j)))
        (trans (sum-coefficients (λ i → Scalar.delta i (from p j)) (f j))
          (trans (cong (_• f j) (Scalar.sum-delta-one (from p j))) (scalar-one (f j)))))))

  indexSign : {n : ℕ} → Fin n → R
  indexSign i = (- 1r) ^ finToNat i

  signedSum : {n : ℕ} → (Fin n → V) → V
  signedSum f = sum (λ i → indexSign i • f i)

  signed-cong : {n : ℕ} {f g : Fin n → V} → ((i : Fin n) → f i ≡ g i) → signedSum f ≡ signedSum g
  signed-cong p = sum-cong (λ i → cong (indexSign i •_) (p i))

  signed-zero : (n : ℕ) → signedSum {n} (λ _ → 0v) ≡ 0v
  signed-zero n = trans (sum-cong {n = n} (λ i → scalar-zero (indexSign i))) (sum-zero n)

  signed-add : {n : ℕ} (f g : Fin n → V) → signedSum (λ i → f i +v g i) ≡ signedSum f +v signedSum g
  signed-add f g = trans (sum-cong (λ i → scalar-distrib (indexSign i) (f i) (g i)))
    (sum-add (λ i → indexSign i • f i) (λ i → indexSign i • g i))

  signed-scale : {n : ℕ} (r : R) (f : Fin n → V) → signedSum (λ i → r • f i) ≡ r • signedSum f
  signed-scale r f = trans (sum-cong (λ i → scalar-commute (indexSign i) r (f i)))
    (sum-scale r (λ i → indexSign i • f i))

  signed-head : {n : ℕ} (f : Fin (suc n) → V) → signedSum f ≡ f fzero +v (- 1r) • signedSum (f ∘ fsuc)
  signed-head f = trans (cong₂ _+v_ (scalar-one (f fzero))
    (trans (sum-cong (λ i → scalar-assoc (- 1r) (indexSign i) (f (fsuc i))))
      (sum-scale (- 1r) (λ i → indexSign i • f (fsuc i))))) refl
