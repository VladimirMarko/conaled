{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Automorphisms where

open import SDG.Prelude
open import SDG.Algebra.Group

record Aut {ℓ : Level} (M : Set ℓ) : Set ℓ where
  constructor automorphism
  field
    forward backward : M → M
    backward-forward : (m : M) → backward (forward m) ≡ m
    forward-backward : (m : M) → forward (backward m) ≡ m
open Aut public

module Automorphisms {ℓ : Level} (M : Set ℓ) (ext : FunExt ℓ ℓ) (setM : isSet M) where
  aut-path : {f g : Aut M} → forward f ≡ forward g → backward f ≡ backward g → f ≡ g
  aut-path {automorphism f fi p q} {automorphism .f .fi r s} refl refl =
    cong₂ (automorphism f fi) (ext (λ m → setM _ _ (p m) (r m)))
      (ext (λ m → setM _ _ (q m) (s m)))

  aut-ext : {f g : Aut M} → ((m : M) → forward f m ≡ forward g m) → f ≡ g
  aut-ext {f} {g} p = aut-path (ext p) (ext (λ m →
    trans (sym (backward-forward g (backward f m)))
      (trans (cong (backward g) (sym (p (backward f m))))
        (cong (backward g) (forward-backward f m)))))

  identity : Aut M
  identity = automorphism id id (λ _ → refl) (λ _ → refl)

  -- Reverse composition: f · g first applies f, then g. This convention
  -- matches the traversal of an infinitesimal commutator circuit.
  multiply : Aut M → Aut M → Aut M
  forward (multiply f g) m = forward g (forward f m)
  backward (multiply f g) m = backward f (backward g m)
  backward-forward (multiply f g) m =
    trans (cong (backward f) (backward-forward g (forward f m))) (backward-forward f m)
  forward-backward (multiply f g) m =
    trans (cong (forward g) (forward-backward f (backward g m))) (forward-backward g m)

  inverse : Aut M → Aut M
  inverse f = automorphism (backward f) (forward f) (forward-backward f) (backward-forward f)

  -- Keep the bundled group opaque. Otherwise an abstract group word
  -- expands all inverse witnesses during native equality checking.
  abstract
    automorphismGroup : Group (Aut M)
    automorphismGroup = record
      { unit = identity; _·_ = multiply; inverse = inverse
      ; assoc = λ f g h → aut-ext (λ _ → refl)
      ; identityˡ = λ f → aut-ext (λ _ → refl)
      ; identityʳ = λ f → aut-ext (λ _ → refl)
      ; inverseˡ = λ f → aut-ext (forward-backward f)
      ; inverseʳ = λ f → aut-ext (backward-forward f)
      }

    forward-unit : (m : M) → forward (Group.unit automorphismGroup) m ≡ m
    forward-unit m = refl

    forward-multiply : (f g : Aut M) (m : M) →
      forward (Group._·_ automorphismGroup f g) m ≡ forward g (forward f m)
    forward-multiply f g m = refl

    forward-commutator : (f g : Aut M) (m : M) →
      forward (GroupLemmas.commutator automorphismGroup f g) m ≡
      forward g (forward f (backward g (backward f m)))
    forward-commutator f g m = refl
