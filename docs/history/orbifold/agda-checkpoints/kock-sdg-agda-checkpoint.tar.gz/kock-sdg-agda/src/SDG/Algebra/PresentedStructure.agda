{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.PresentedStructure where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Presented
open import SDG.Algebra.StructureConstants
open import SDG.Finite using (Fin; fzero; fsuc)
open import SDG.Schemes.FiniteBlocks
import SDG.Combinatorics.FiniteSums as FS

module StructurePresentation {κ : Level} (k : CRing κ) where
  open Presentations k

  polynomial-sum : {m n : ℕ} → (Fin m → Polynomial n) → Polynomial n
  polynomial-sum {zero} p = zeroP
  polynomial-sum {suc m} p = p fzero ⊕ polynomial-sum (λ i → p (fsuc i))

  evaluate-sum : {c : Level} (C : CRing c) (ι : RingHom k C)
    {m n : ℕ} (p : Fin m → Polynomial n) (xs : Fin n → CRing.R C) →
    evaluate C (RingHom.hom ι) (polynomial-sum p) xs ≡ FS.Sums.sum C (λ i → evaluate C (RingHom.hom ι) (p i) xs)
  evaluate-sum C ι {zero} p xs = RingHom.pres-0 ι
  evaluate-sum C ι {suc m} p xs = cong (CRing._+_ C (evaluate C (RingHom.hom ι) (p fzero) xs))
    (evaluate-sum C ι (λ i → p (fsuc i)) xs)

  module At (n : ℕ) (T : Tables.Table k n) where
    private
      I = Fin (suc n)
      γ = Tables.constants T

    pair-sizes : I → ℕ
    pair-sizes i = suc n

    multiplication-polynomial : I → I → Polynomial (suc n)
    multiplication-polynomial j l = polynomial-sum (λ i → coefficient (γ i j l) ⊗ var i)

    pair-polynomial : I → I → Polynomial (suc n)
    pair-polynomial j l = (var j ⊗ var l) ⊕ negative (multiplication-polynomial j l)

    defining-equations : Fin (suc (total pair-sizes)) → Polynomial (suc n)
    defining-equations fzero = var fzero ⊕ negative oneP
    defining-equations (fsuc j) = pair-polynomial (fst (splitIndex pair-sizes j)) (snd (splitIndex pair-sizes j))

    -- The unit relation X_0 = 1 is necessary for unital algebra maps.
    -- Without it, the displayed multiplication relations on their own
    -- also admit the all-zero tuple. It is included explicitly here.
    presentation : Presentation
    presentation = presented (suc n) (suc (total pair-sizes)) defining-equations

    pair-equation : (i j : I) → equations presentation (fsuc (injectIndex pair-sizes i j)) ≡ pair-polynomial i j
    pair-equation i j = cong (λ ij → pair-polynomial (fst ij) (snd ij)) (split-inject pair-sizes i j)
