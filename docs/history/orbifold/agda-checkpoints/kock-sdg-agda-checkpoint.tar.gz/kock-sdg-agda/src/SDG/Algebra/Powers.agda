{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.Powers where

open import SDG.Prelude
open import SDG.Algebra
open import Agda.Builtin.Nat public using ()
  renaming (_+_ to _+ℕ_; _*_ to _*ℕ_)

module PowerLemmas {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A public

  infixr 8 _^_
  _^_ : R → ℕ → R
  x ^ zero = 1r
  x ^ suc n = x * (x ^ n)

  fromℕ : ℕ → R
  fromℕ zero = 0r
  fromℕ (suc n) = 1r + fromℕ n

  factorial : ℕ → R
  factorial zero = 1r
  factorial (suc n) = fromℕ (suc n) * factorial n

  fromℕ-one : fromℕ (suc zero) ≡ 1r
  fromℕ-one = +-identityʳ 1r

  fromℕ-add : (m n : ℕ) → fromℕ (m +ℕ n) ≡ fromℕ m + fromℕ n
  fromℕ-add zero n = sym (+-identityˡ (fromℕ n))
  fromℕ-add (suc m) n =
    trans (cong (1r +_) (fromℕ-add m n))
      (sym (+-assoc 1r (fromℕ m) (fromℕ n)))

  fromℕ-mul : (m n : ℕ) → fromℕ (m *ℕ n) ≡ fromℕ m * fromℕ n
  fromℕ-mul zero n = sym (*-zeroˡ (fromℕ n))
  fromℕ-mul (suc m) n =
    begin
      fromℕ (n +ℕ (m *ℕ n))
    ≡⟨ fromℕ-add n (m *ℕ n) ⟩
      fromℕ n + fromℕ (m *ℕ n)
    ≡⟨ cong (fromℕ n +_) (fromℕ-mul m n) ⟩
      fromℕ n + (fromℕ m * fromℕ n)
    ≡⟨ cong (_+ (fromℕ m * fromℕ n)) (sym (*-identityˡ (fromℕ n))) ⟩
      (1r * fromℕ n) + (fromℕ m * fromℕ n)
    ≡⟨ sym (distribʳ 1r (fromℕ m) (fromℕ n)) ⟩
      (1r + fromℕ m) * fromℕ n ∎

  power-one : (x : R) → x ^ suc zero ≡ x
  power-one = *-identityʳ

  power-two : (x : R) → x ^ suc (suc zero) ≡ x * x
  power-two x = cong (x *_) (power-one x)

  power-add : (x : R) (m n : ℕ) → x ^ (m +ℕ n) ≡ (x ^ m) * (x ^ n)
  power-add x zero n = sym (*-identityˡ (x ^ n))
  power-add x (suc m) n =
    trans (cong (x *_) (power-add x m n))
      (sym (*-assoc x (x ^ m) (x ^ n)))

  power-product : (x y : R) (n : ℕ) → (x * y) ^ n ≡ (x ^ n) * (y ^ n)
  power-product x y zero = sym (*-identityˡ 1r)
  power-product x y (suc n) =
    trans (cong ((x * y) *_) (power-product x y n))
      (*-shuffle x y (x ^ n) (y ^ n))

  power-mul : (x : R) (m n : ℕ) → x ^ (m *ℕ n) ≡ (x ^ n) ^ m
  power-mul x zero n = refl
  power-mul x (suc m) n =
    trans (power-add x n (m *ℕ n)) (cong ((x ^ n) *_) (power-mul x m n))

  one-power : (n : ℕ) → 1r ^ n ≡ 1r
  one-power zero = refl
  one-power (suc n) = trans (*-identityˡ (1r ^ n)) (one-power n)

  zero-positive-power : (n : ℕ) → 0r ^ suc n ≡ 0r
  zero-positive-power n = *-zeroˡ (0r ^ n)

  nilpotent-monotone : (x : R) (m n : ℕ) → x ^ m ≡ 0r → x ^ (m +ℕ n) ≡ 0r
  nilpotent-monotone x m n p =
    trans (power-add x m n) (trans (cong (_* (x ^ n)) p) (*-zeroˡ (x ^ n)))

  nilpotent-scaled : (x r : R) (n : ℕ) → x ^ n ≡ 0r → (x * r) ^ n ≡ 0r
  nilpotent-scaled x r n p =
    trans (power-product x r n)
      (trans (cong (_* (r ^ n)) p) (*-zeroˡ (r ^ n)))

  -- The first-order binomial formula is algebraic: no SDG axiom is used.
  power-first-order : (x d : R) (n : ℕ) → d * d ≡ 0r →
    (x + d) ^ suc n ≡ (x ^ suc n) + d * (fromℕ (suc n) * (x ^ n))
  power-first-order x d zero dd =
    trans (power-one (x + d))
      (sym (cong₂ _+_ (power-one x)
        (trans (cong (d *_) (trans (cong (_* 1r) fromℕ-one) (*-identityʳ 1r)))
          (*-identityʳ d))))
  power-first-order x d (suc n) dd =
    begin
      (x + d) * ((x + d) ^ suc n)
    ≡⟨ cong ((x + d) *_) (power-first-order x d n dd) ⟩
      (x + d) * ((x ^ suc n) + d * (fromℕ (suc n) * (x ^ n)))
    ≡⟨ cong (_* ((x ^ suc n) + d * (fromℕ (suc n) * (x ^ n))))
          (cong (x +_) (sym (*-identityʳ d))) ⟩
      (x + d * 1r) * ((x ^ suc n) + d * (fromℕ (suc n) * (x ^ n)))
    ≡⟨ affine-product d x 1r (x ^ suc n) (fromℕ (suc n) * (x ^ n)) dd ⟩
      (x * (x ^ suc n)) +
        d * ((x * (fromℕ (suc n) * (x ^ n))) + ((x ^ suc n) * 1r))
    ≡⟨ cong (λ z → (x * (x ^ suc n)) + d * z)
          (cong₂ _+_ (*-swap x (fromℕ (suc n)) (x ^ n)) (*-identityʳ (x ^ suc n))) ⟩
      (x * (x ^ suc n)) +
        d * ((fromℕ (suc n) * (x ^ suc n)) + (x ^ suc n))
    ≡⟨ cong (λ z → (x * (x ^ suc n)) + d * z)
          (trans (+-comm (fromℕ (suc n) * (x ^ suc n)) (x ^ suc n))
            (trans (cong (_+ (fromℕ (suc n) * (x ^ suc n)))
                    (sym (*-identityˡ (x ^ suc n))))
              (sym (distribʳ 1r (fromℕ (suc n)) (x ^ suc n))))) ⟩
      (x ^ suc (suc n)) + d * (fromℕ (suc (suc n)) * (x ^ suc n)) ∎

  -- sum f n is the sum indexed by 0 ≤ i < n.
  sum : (ℕ → R) → ℕ → R
  sum f zero = 0r
  sum f (suc n) = sum f n + f n

  sum-cong : {f g : ℕ → R} → ((i : ℕ) → f i ≡ g i) →
             (n : ℕ) → sum f n ≡ sum g n
  sum-cong p zero = refl
  sum-cong p (suc n) = cong₂ _+_ (sum-cong p n) (p n)

  sum-zero : (n : ℕ) → sum (λ _ → 0r) n ≡ 0r
  sum-zero zero = refl
  sum-zero (suc n) = trans (cong (_+ 0r) (sum-zero n)) (+-identityˡ 0r)

  sum-add : (f g : ℕ → R) (n : ℕ) →
            sum (λ i → f i + g i) n ≡ sum f n + sum g n
  sum-add f g zero = sym (+-identityˡ 0r)
  sum-add f g (suc n) =
    trans (cong (_+ (f n + g n)) (sum-add f g n))
      (+-shuffle (sum f n) (sum g n) (f n) (g n))

  sum-scale : (a : R) (f : ℕ → R) (n : ℕ) →
              sum (λ i → a * f i) n ≡ a * sum f n
  sum-scale a f zero = sym (*-zeroʳ a)
  sum-scale a f (suc n) =
    trans (cong (_+ (a * f n)) (sum-scale a f n))
      (sym (distribˡ a (sum f n) (f n)))

  sum-neg : (f : ℕ → R) (n : ℕ) → sum (λ i → - f i) n ≡ (- sum f n)
  sum-neg f zero = sym neg-zero
  sum-neg f (suc n) =
    trans (cong (_+ (- f n)) (sum-neg f n)) (sym (neg-add (sum f n) (f n)))

  sum-constant : (a : R) (n : ℕ) → sum (λ _ → a) n ≡ fromℕ n * a
  sum-constant a zero = sym (*-zeroˡ a)
  sum-constant a (suc n) =
    begin
      sum (λ _ → a) n + a
    ≡⟨ cong (_+ a) (sum-constant a n) ⟩
      (fromℕ n * a) + a
    ≡⟨ +-comm (fromℕ n * a) a ⟩
      a + (fromℕ n * a)
    ≡⟨ cong (_+ (fromℕ n * a)) (sym (*-identityˡ a)) ⟩
      (1r * a) + (fromℕ n * a)
    ≡⟨ sym (distribʳ 1r (fromℕ n) a) ⟩
      (1r + fromℕ n) * a ∎
