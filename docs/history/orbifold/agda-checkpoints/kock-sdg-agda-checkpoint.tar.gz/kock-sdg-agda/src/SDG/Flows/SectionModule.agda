{-# OPTIONS --safe --without-K #-}
module SDG.Flows.SectionModule where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.FunctionRing

-- Sections of a family of R-modules form a module over R-valued functions.
-- This algebraic construction will be instantiated by the proved tangent
-- module structure, rather than supplying that structure as a conclusion.
sectionModule : {ℓ : Level} (A : CRing ℓ) (X : Set ℓ)
  (ext : FunExt ℓ ℓ) → ((x : X) → RModule A ℓ) →
  RModule (functionRing A X ext) ℓ
sectionModule A X ext fibers = record
  { V = (x : X) → RModule.V (fibers x)
  ; 0v = λ x → RModule.0v (fibers x)
  ; _+v_ = λ f g x → RModule._+v_ (fibers x) (f x) (g x)
  ; -v_ = λ f x → RModule.-v_ (fibers x) (f x)
  ; _•_ = λ r f x → RModule._•_ (fibers x) (r x) (f x)
  ; add-assoc = λ f g h → ext (λ x → RModule.add-assoc (fibers x) (f x) (g x) (h x))
  ; add-comm = λ f g → ext (λ x → RModule.add-comm (fibers x) (f x) (g x))
  ; add-zeroˡ = λ f → ext (λ x → RModule.add-zeroˡ (fibers x) (f x))
  ; add-inverseˡ = λ f → ext (λ x → RModule.add-inverseˡ (fibers x) (f x))
  ; scalar-one = λ f → ext (λ x → RModule.scalar-one (fibers x) (f x))
  ; scalar-assoc = λ r s f → ext (λ x → RModule.scalar-assoc (fibers x) (r x) (s x) (f x))
  ; scalar-add = λ r s f → ext (λ x → RModule.scalar-add (fibers x) (r x) (s x) (f x))
  ; scalar-distrib = λ r f g → ext (λ x → RModule.scalar-distrib (fibers x) (r x) (f x) (g x))
  }

