{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section11 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Algebras
open import SDG.Axiom
import SDG.Algebra.Derivations as Der
import SDG.Algebra.Endomorphisms as End
import SDG.Algebra.LieTransfer as Transfer
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section10 as S10
import SDG.ChapterI.Section10Linear as L10
import SDG.ChapterI.Section10Bracket as B10

-- Theorem I.11.1. The injectivity premise is precisely the book's premise;
-- all Lie identities are obtained from the proved operator identities.
module Functional {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M) where
  open RingLemmas A
  open Infinitesimals A
  open S8.Basics A setR
  open S8M.Fields A setR ext0 ext M setM IL
  open S9.Lie A K setR IL W renaming (bracket to book-bracket)
  open S10.Calculus A K setR (scalarModule A) (S10.scalar-vectorKL A K)
  open L10.Linearity A K setR ext0 ext (scalarModule A) (S10.scalar-vectorKL A K) M setM IL
    using (added-field-derivative)
  open B10.BracketDerivative A K setR (scalarModule A) (S10.scalar-vectorKL A K) IL W
    using (bracket-derivative)

  Functions : RAlgebra A ℓ
  Functions = functionAlgebra A M ext

  FunctionModule : RModule A ℓ
  FunctionModule = Der.algebraModule A (ring Functions) (unit Functions)

  module Op = End.Endomorphisms A FunctionModule
  module Diff = Der.Derivations A (ring Functions) (unit Functions)

  scalarFieldsModule : RModule A ℓ
  scalarFieldsModule = record
    { V = VectorField M
    ; 0v = zero-field
    ; _+v_ = field-add
    ; -v_ = field-negate
    ; _•_ = λ r → scale-field (λ _ → r)
    ; add-assoc = field-add-assoc
    ; add-comm = field-add-comm
    ; add-zeroˡ = field-add-zero
    ; add-inverseˡ = field-add-inverse
    ; scalar-one = field-scale-one
    ; scalar-assoc = λ r s → field-scale-assoc (λ _ → r) (λ _ → s)
    ; scalar-add = λ r s → field-scale-add (λ _ → r) (λ _ → s)
    ; scalar-distrib = λ r → field-scale-distrib (λ _ → r)
    }

  abstract
    bracket : VectorField M → VectorField M → VectorField M
    bracket = book-bracket

    bracket-agrees : (X Y : VectorField M) → bracket X Y ≡ book-bracket X Y
    bracket-agrees X Y = refl

    operator : VectorField M → Op.End
    Op.run (operator X) f = directional X f
    Op.additive (operator X) f g = ext (directional-add X f g)
    Op.homogeneous (operator X) r f = ext (directional-scale X r f)

    -- Equation (11.7) lands in derivations, including the Leibniz proof.
    comparison : VectorField M → Diff.Derivation
    Diff.operator (comparison X) = operator X
    Diff.leibniz (comparison X) f g = ext (directional-product X f g)

    operator-zero : operator zero-field Op.≈ Op.zeroEnd
    operator-zero f = ext (λ m → directional-constant zero-field (f m) m)

    operator-add : (X Y : VectorField M) → operator (field-add X Y) Op.≈ Op.add (operator X) (operator Y)
    operator-add X Y f = ext (added-field-derivative X Y f)

    operator-scale : (r : R) (X : VectorField M) →
      operator (scale-field (λ _ → r) X) Op.≈ Op.scale r (operator X)
    operator-scale r X f = ext (scaled-field-derivative (λ _ → r) X f)

    operator-multiply : (φ : M → R) (X : VectorField M) →
      operator (scale-field φ X) Op.≈ Diff.operator (Diff.multiply φ (comparison X))
    operator-multiply φ X f = ext (scaled-field-derivative φ X f)

    operator-bracket : (X Y : VectorField M) → operator (bracket X Y) Op.≈ Op.bracket (operator X) (operator Y)
    operator-bracket X Y f = ext (bracket-derivative X Y f)

    comparison-add : (X Y : VectorField M) →
      comparison (field-add X Y) Diff.≈ Diff.add (comparison X) (comparison Y)
    comparison-add = operator-add

    comparison-multiply : (φ : M → R) (X : VectorField M) →
      comparison (scale-field φ X) Diff.≈ Diff.multiply φ (comparison X)
    comparison-multiply = operator-multiply

    comparison-bracket : (X Y : VectorField M) →
      comparison (bracket X Y) Diff.≈ Diff.bracket (comparison X) (comparison Y)
    comparison-bracket = operator-bracket

    run-operator : (X : VectorField M) (f : M → R) → Op.run (operator X) f ≡ directional X f
    run-operator X f = refl

    -- Equation (11.8) at the operator level.
    operator-lie-module : (X Y : VectorField M) (φ : M → R) →
      operator (bracket X (scale-field φ Y)) Op.≈
        operator (field-add (scale-field (directional X φ) Y) (scale-field φ (bracket X Y)))
    operator-lie-module X Y φ f =
          trans (operator-bracket X (scale-field φ Y) f)
          (trans (Op.bracket-cong {f = operator X} {f′ = operator X}
            {g = operator (scale-field φ Y)} {g′ = Diff.operator (Diff.multiply φ (comparison Y))}
            (λ _ → refl) (operator-multiply φ Y) f)
            (trans (Diff.bracket-multiply (comparison X) (comparison Y) φ f)
              (sym (right-side f))))
      where
      right-side : (f : M → R) →
        directional (field-add (scale-field (directional X φ) Y) (scale-field φ (bracket X Y))) f ≡
        (λ m → directional X φ m * directional Y f m + φ m *
          (directional X (directional Y f) m - directional Y (directional X f) m))
      right-side f = trans
        (operator-add (scale-field (directional X φ) Y) (scale-field φ (bracket X Y)) f)
        (cong₂ (CRing._+_ (ring Functions)) (operator-multiply (directional X φ) Y f)
          (trans (operator-multiply φ (bracket X Y) f)
            (cong (CRing._*_ (ring Functions) φ) (operator-bracket X Y f))))


  OperatorInjective : Set ℓ
  OperatorInjective = (X Y : VectorField M) → operator X Op.≈ operator Y → X ≡ Y

  DirectionalInjective : Set ℓ
  DirectionalInjective = (X Y : VectorField M) →
    ((f : M → R) (m : M) → directional X f m ≡ directional Y f m) → X ≡ Y

  directional-injectivity-suffices : DirectionalInjective → OperatorInjective
  directional-injectivity-suffices faithful X Y equality = faithful X Y (λ f m →
    cong (λ g → g m) (trans (sym (run-operator X f))
      (trans (equality f) (run-operator Y f))))

  module Faithful (faithful : OperatorInjective) where
    vectorFieldsLieAlgebra : End.LieAlgebra A scalarFieldsModule
    vectorFieldsLieAlgebra = Transfer.Transfer.lieAlgebra A scalarFieldsModule FunctionModule operator bracket
      operator-zero operator-add operator-scale operator-bracket faithful

    jacobi : (X Y Z : VectorField M) →
      field-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
        (bracket Z (bracket X Y)) ≡ zero-field
    jacobi = End.LieAlgebra.jacobi vectorFieldsLieAlgebra

    lie-module-law : (X Y : VectorField M) (φ : M → R) →
      bracket X (scale-field φ Y) ≡
        field-add (scale-field (directional X φ) Y) (scale-field φ (bracket X Y))
    lie-module-law X Y φ = faithful (bracket X (scale-field φ Y))
      (field-add (scale-field (directional X φ) Y) (scale-field φ (bracket X Y)))
      (operator-lie-module X Y φ)

