{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.Weil where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
import SDG.Algebra.StructureConstants as SC
import SDG.Combinatorics.FiniteSums as FS
import SDG.Combinatorics.FiniteLinear as FL
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup)

module Ideals {ℓ : Level} (A : CRing ℓ) (ext0 : FunExt lzero ℓ)
  (n : ℕ) (T : SC.Tables.Table A n) where
  open RingLemmas A
  module C = SC.Tables.Build A ext0 n T
  module CL = PowerLemmas C.coordinate-ring
  module S = FS.Sums A
  module CS = FS.Sums C.coordinate-ring
  open FL.Coordinates A ext0

  data InIdeal : C.Carrier → Set ℓ where
    ideal-zero : InIdeal C.zeroC
    ideal-generator : (i : Fin n) → InIdeal (S.delta (fsuc i))
    ideal-add : {x y : C.Carrier} → InIdeal x → InIdeal y → InIdeal (C.add x y)
    ideal-scale : (r : R) {x : C.Carrier} → InIdeal x → InIdeal (C.scale r x)

  ideal-coordinate : {x : C.Carrier} → InIdeal x → x fzero ≡ 0r
  ideal-coordinate ideal-zero = refl
  ideal-coordinate (ideal-generator i) = refl
  ideal-coordinate (ideal-add p q) = trans (cong₂ _+_ (ideal-coordinate p) (ideal-coordinate q)) (+-identityˡ 0r)
  ideal-coordinate (ideal-scale r p) = trans (cong (r *_) (ideal-coordinate p)) (*-zeroʳ r)

  sum-coordinate : {m : ℕ} (f : Fin m → C.Carrier) (i : Fin (suc n)) →
    CS.sum f i ≡ S.sum (λ j → f j i)
  sum-coordinate {zero} f i = refl
  sum-coordinate {suc m} f i = cong (f fzero i +_) (sum-coordinate (λ j → f (fsuc j)) i)

  ideal-sum : {m : ℕ} (f : Fin m → C.Carrier) → ((i : Fin m) → InIdeal (f i)) → InIdeal (CS.sum f)
  ideal-sum {zero} f p = ideal-zero
  ideal-sum {suc m} f p = ideal-add (p fzero) (ideal-sum (λ i → f (fsuc i)) (λ i → p (fsuc i)))

  positive-basis : (x : C.Carrier) → x fzero ≡ 0r →
    CS.sum (λ i → C.scale (x (fsuc i)) (S.delta (fsuc i))) ≡ x
  positive-basis x eq = ext0 (λ where
    fzero → trans (sum-coordinate (λ i → C.scale (x (fsuc i)) (S.delta (fsuc i))) fzero)
      (trans (S.sum-cong {n = n} (λ i → *-zeroʳ (x (fsuc i)))) (trans (S.sum-zero n) (sym eq)))
    (fsuc j) → trans (sum-coordinate (λ i → C.scale (x (fsuc i)) (S.delta (fsuc i))) (fsuc j))
      (S.basis-expansion (λ i → x (fsuc i)) j))

  coordinate-ideal : (x : C.Carrier) → x fzero ≡ 0r → InIdeal x
  coordinate-ideal x eq = subst InIdeal (positive-basis x eq)
    (ideal-sum (λ i → C.scale (x (fsuc i)) (S.delta (fsuc i)))
      (λ i → ideal-scale (x (fsuc i)) (ideal-generator i)))

  -- A finite equational condition on structure constants: every product
  -- of q nonconstant basis vectors vanishes after the prefactor a.
  BasisProductsZero : ℕ → C.Carrier → Set ℓ
  BasisProductsZero zero a = a ≡ C.zeroC
  BasisProductsZero (suc q) a = (i : Fin n) → BasisProductsZero q (C.multiply a (S.delta (fsuc i)))

  zero-products : (q : ℕ) → BasisProductsZero q C.zeroC
  zero-products zero = refl
  zero-products (suc q) i = subst (BasisProductsZero q)
    (sym (ext0 (λ j → map-zero (C.left-linear (S.delta (fsuc i)) j)))) (zero-products q)

  products-add : (q : ℕ) (a b : C.Carrier) → BasisProductsZero q a → BasisProductsZero q b →
    BasisProductsZero q (C.add a b)
  products-add zero a b p r = trans (cong₂ C.add p r) (CL.+-identityˡ C.zeroC)
  products-add (suc q) a b p r i = subst (BasisProductsZero q)
    (sym (CL.distribʳ a b (S.delta (fsuc i))))
    (products-add q (C.multiply a (S.delta (fsuc i))) (C.multiply b (S.delta (fsuc i))) (p i) (r i))

  products-scale : (q : ℕ) (r : R) (a : C.Carrier) → BasisProductsZero q a → BasisProductsZero q (C.scale r a)
  products-scale zero r a p = trans (cong (C.scale r) p) (ext0 (λ i → *-zeroʳ r))
  products-scale (suc q) r a p i = subst (BasisProductsZero q)
    (sym (ext0 (λ j → map-scale (C.left-linear (S.delta (fsuc i)) j) r a)))
    (products-scale q r (C.multiply a (S.delta (fsuc i))) (p i))

  ideal-multiply : (q : ℕ) (a : C.Carrier) {x : C.Carrier} →
    BasisProductsZero (suc q) a → InIdeal x → BasisProductsZero q (C.multiply a x)
  ideal-multiply q a p ideal-zero = subst (BasisProductsZero q)
    (sym (ext0 (λ i → map-zero (C.right-linear a i)))) (zero-products q)
  ideal-multiply q a p (ideal-generator i) = p i
  ideal-multiply q a p (ideal-add {x} {y} u v) = subst (BasisProductsZero q)
    (sym (CL.distribˡ a x y))
    (products-add q (C.multiply a x) (C.multiply a y) (ideal-multiply q a p u) (ideal-multiply q a p v))
  ideal-multiply q a p (ideal-scale r {x} u) = subst (BasisProductsZero q)
    (sym (ext0 (λ i → map-scale (C.right-linear a i) r x)))
    (products-scale q r (C.multiply a x) (ideal-multiply q a p u))

  annihilate-power : (q : ℕ) (a x : C.Carrier) → BasisProductsZero q a → InIdeal x →
    C.multiply a (CL._^_ x q) ≡ C.zeroC
  annihilate-power zero a x p u = trans (CL.*-identityʳ a) p
  annihilate-power (suc q) a x p u = trans (sym (CL.*-assoc a x (CL._^_ x q)))
    (annihilate-power q (C.multiply a x) x (ideal-multiply q a p u) u)

  nilpotent : BasisProductsZero (suc n) C.oneC → (x : C.Carrier) → x fzero ≡ 0r → CL._^_ x (suc n) ≡ C.zeroC
  nilpotent nil x eq = trans (sym (CL.*-identityˡ (CL._^_ x (suc n))))
    (annihilate-power (suc n) C.oneC x nil (coordinate-ideal x eq))

  product : {m : ℕ} → Vec C.Carrier m → C.Carrier
  product [] = C.oneC
  product (x ∷ xs) = C.multiply x (product xs)

  annihilate-product : {m : ℕ} (a : C.Carrier) (xs : Vec C.Carrier m) → BasisProductsZero m a →
    ((i : Fin m) → lookup xs i fzero ≡ 0r) → C.multiply a (product xs) ≡ C.zeroC
  annihilate-product a [] p u = trans (CL.*-identityʳ a) p
  annihilate-product a (x ∷ xs) p u = trans (sym (CL.*-assoc a x (product xs)))
    (annihilate-product (C.multiply a x) xs (ideal-multiply _ a p (coordinate-ideal x (u fzero))) (λ i → u (fsuc i)))

  ideal-power-zero : BasisProductsZero (suc n) C.oneC → (xs : Vec C.Carrier (suc n)) →
    ((i : Fin (suc n)) → lookup xs i fzero ≡ 0r) → product xs ≡ C.zeroC
  ideal-power-zero nil xs u = trans (sym (CL.*-identityˡ (product xs))) (annihilate-product C.oneC xs nil u)

  module Augmentation
    (augment : (j l : Fin (suc n)) → SC.Tables.constants T fzero j l ≡ S.delta fzero j * S.delta fzero l) where
    coordinate-linear : Linear (λ (x : C.Carrier) → x fzero)
    map-zero coordinate-linear = refl
    map-add coordinate-linear x y = refl
    map-scale coordinate-linear r x = refl

    augmentation-product : (x y : C.Carrier) → C.multiply x y fzero ≡ x fzero * y fzero
    augmentation-product = bilinear-ext (λ x y → C.multiply x y fzero) (λ x y → x fzero * y fzero)
      (λ y → C.left-linear y fzero) (λ x → C.right-linear x fzero)
      (λ y → right-output (y fzero) coordinate-linear) (λ x → left-output (x fzero) coordinate-linear)
      (λ j l → trans (C.multiply-basis j l fzero)
        (trans (augment j l) (cong₂ _*_ (S.delta-sym fzero j) (S.delta-sym fzero l))))

    augmentation : AlgHom C.coordinate-algebra (scalarAlgebra A)
    RingHom.hom (ringHom augmentation) x = x fzero
    RingHom.pres-0 (ringHom augmentation) = refl
    RingHom.pres-1 (ringHom augmentation) = refl
    RingHom.pres-+ (ringHom augmentation) x y = refl
    RingHom.pres-* (ringHom augmentation) = augmentation-product
    RingHom.pres-neg (ringHom augmentation) x = refl
    commutes augmentation r = *-identityʳ r

-- Faithful finite-coordinate Weil data: dimension n+1, unital table,
-- first-coordinate augmentation, and the equational nilpotence condition.
-- Ideals.ideal-power-zero proves the book's full I^(n+1)=0 statement.
module Weils {ℓ : Level} (A : CRing ℓ) (ext0 : FunExt lzero ℓ) where
  module S = FS.Sums A
  record WeilAlgebra (n : ℕ) : Set ℓ where
    field
      table : SC.Tables.Table A n
      augmentation-constants : (j l : Fin (suc n)) →
        SC.Tables.constants table fzero j l ≡ CRing._*_ A (S.delta fzero j) (S.delta fzero l)
      nilpotence-constants : Ideals.BasisProductsZero A ext0 n table (suc n)
        (SC.Tables.Build.oneC A ext0 n table)
  open WeilAlgebra public

module Change {a b : Level} (A : CRing a) (B : CRing b)
  (extA : FunExt lzero a) (extB : FunExt lzero b) (h : RingHom A B)
  (n : ℕ) (T : SC.Tables.Table A n) where
  module AC = SC.Tables.Build A extA n T
  module BC = SC.Tables.Build B extB n (SC.Change.change-table A B h T)
  module AS = FS.Sums A
  module BS = FS.Sums B
  module AI = Ideals A extA n T
  module BI = Ideals B extB n (SC.Change.change-table A B h T)
  module Hom = SC.Change A B h
  open RingHom h

  coordinate-map : RingHom AC.coordinate-ring BC.coordinate-ring
  RingHom.hom coordinate-map x i = hom (x i)
  RingHom.pres-0 coordinate-map = extB (λ i → pres-0)
  RingHom.pres-1 coordinate-map = extB (λ i → Hom.map-delta fzero i)
  RingHom.pres-+ coordinate-map x y = extB (λ i → pres-+ (x i) (y i))
  RingHom.pres-neg coordinate-map x = extB (λ i → pres-neg (x i))
  RingHom.pres-* coordinate-map x y = extB (λ i →
    trans (Hom.map-sum (λ j → CRing._*_ A (x j) (AS.sum (λ l → CRing._*_ A (y l) (SC.Tables.constants T i j l)))))
      (BS.sum-cong (λ j → trans (pres-* (x j) (AS.sum (λ l → CRing._*_ A (y l) (SC.Tables.constants T i j l))))
        (cong (CRing._*_ B (hom (x j)))
          (trans (Hom.map-sum (λ l → CRing._*_ A (y l) (SC.Tables.constants T i j l)))
            (BS.sum-cong (λ l → pres-* (y l) (SC.Tables.constants T i j l))))))))

  map-basis : (i : Fin (suc n)) → RingHom.hom coordinate-map (AS.delta i) ≡ BS.delta i
  map-basis i = extB (Hom.map-delta i)

  transfer-products : (q : ℕ) (x : AC.Carrier) → AI.BasisProductsZero q x →
    BI.BasisProductsZero q (RingHom.hom coordinate-map x)
  transfer-products zero x p = trans (cong (RingHom.hom coordinate-map) p) (RingHom.pres-0 coordinate-map)
  transfer-products (suc q) x p i = subst (BI.BasisProductsZero q)
    (trans (RingHom.pres-* coordinate-map x (AS.delta (fsuc i)))
      (cong (BC.multiply (RingHom.hom coordinate-map x)) (map-basis (fsuc i))))
    (transfer-products q (AC.multiply x (AS.delta (fsuc i))) (p i))

  transfer-nilpotence : AI.BasisProductsZero (suc n) AC.oneC → BI.BasisProductsZero (suc n) BC.oneC
  transfer-nilpotence p = subst (BI.BasisProductsZero (suc n)) (RingHom.pres-1 coordinate-map)
    (transfer-products (suc n) AC.oneC p)

  transfer-augmentation :
    ((j l : Fin (suc n)) → SC.Tables.constants T fzero j l ≡ CRing._*_ A (AS.delta fzero j) (AS.delta fzero l)) →
    (j l : Fin (suc n)) → SC.Tables.constants (SC.Change.change-table A B h T) fzero j l ≡
      CRing._*_ B (BS.delta fzero j) (BS.delta fzero l)
  transfer-augmentation aug j l = trans (cong hom (aug j l))
    (trans (pres-* (AS.delta fzero j) (AS.delta fzero l))
      (cong₂ (CRing._*_ B) (Hom.map-delta fzero j) (Hom.map-delta fzero l)))

change-weil : {a b : Level} (A : CRing a) (B : CRing b)
  (extA : FunExt lzero a) (extB : FunExt lzero b) (h : RingHom A B)
  {n : ℕ} → Weils.WeilAlgebra A extA n → Weils.WeilAlgebra B extB n
Weils.table (change-weil A B extA extB h W) = SC.Change.change-table A B h (Weils.table W)
Weils.augmentation-constants (change-weil A B extA extB h {n} W) =
  Change.transfer-augmentation A B extA extB h n (Weils.table W) (Weils.augmentation-constants W)
Weils.nilpotence-constants (change-weil A B extA extB h {n} W) =
  Change.transfer-nilpotence A B extA extB h n (Weils.table W) (Weils.nilpotence-constants W)
