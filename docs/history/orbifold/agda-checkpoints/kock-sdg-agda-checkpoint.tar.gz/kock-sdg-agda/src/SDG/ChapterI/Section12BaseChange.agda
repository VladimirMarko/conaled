{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12BaseChange where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
import SDG.Algebra.PresentedBaseChange as BC
import SDG.ChapterI.Section12 as S12

-- The base-change remark following Axiom 2: for k → K → R,
-- Axiom 2_K implies Axiom 2_k. The inverse of the small-base canonical
-- map is explicitly transported through polynomial coefficient change.
module Transport {κ κ′ ℓ : Level} (k : CRing κ) (K : CRing κ′) (A : CRing ℓ)
  (σ : RingHom k K) (ρ : RingHom K A)
  (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ) (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 K A ρ ext ext0 setR) where
  module Small = S12.Comprehensive k A (composeRingHom ρ σ) ext ext0 setR
  module Large = S12.Comprehensive K A ρ ext ext0 setR
  module Change = BC.Change k K σ
  module P = Presentations k
  module Q = Presentations K
  open Large.Axiom2 Ax

  raise : {B : P.Presentation} → Small.Affine B → Large.Affine (Change.presentation B)
  raise = Change.forward A (RingHom.hom ρ)

  lower : {B : P.Presentation} → Large.Affine (Change.presentation B) → Small.Affine B
  lower = Change.backward A (RingHom.hom ρ)

  raised-point : (B : P.Presentation) (C : RAlgebra A ℓ) → Small.SpecC C B → Large.SpecC C (Change.presentation B)
  raised-point B C = Change.forward (ring C) (Large.coefficient-map C)

  lower-hom : (B : P.Presentation) (C : RAlgebra A ℓ) →
    AlgHom (functionAlgebra A (Large.Affine (Change.presentation B)) ext) C →
      AlgHom (functionAlgebra A (Small.Affine B) ext) C
  lower-hom B C h = composeAlgHom h (precomposition A ext (lower {B}))

  raise-hom : (B : P.Presentation) (C : RAlgebra A ℓ) →
    AlgHom (functionAlgebra A (Small.Affine B) ext) C →
      AlgHom (functionAlgebra A (Large.Affine (Change.presentation B)) ext) C
  raise-hom B C h = composeAlgHom h (precomposition A ext (raise {B}))

  canonical-raised : (B : P.Presentation) (C : RAlgebra A ℓ)
    (setC : isSet (CRing.R (ring C))) (h : AlgHom (functionAlgebra A (Small.Affine B) ext) C) →
    Large.canonical (Change.presentation B) C (raise-hom B C h) ≡ raised-point B C (Small.canonical B C h)
  canonical-raised B C setC h = Q.spec-path ext0 setC (λ i → refl)

  inverse : (B : P.Presentation) (C : RAlgebra A ℓ) →
    isSet (CRing.R (ring C)) → Small.SpecC C B → AlgHom (functionAlgebra A (Small.Affine B) ext) C
  inverse B C setC x = lower-hom B C
    (inverse-canonical (Change.presentation B) C setC (raised-point B C x))

  canonical-inverse-small : (B : P.Presentation) (C : RAlgebra A ℓ)
    (setC : isSet (CRing.R (ring C))) (x : Small.SpecC C B) → Small.canonical B C (inverse B C setC x) ≡ x
  canonical-inverse-small B C setC x = P.spec-path ext0 setC (λ i →
    cong (λ y → Q.coordinates y i)
      (canonical-inverse (Change.presentation B) C setC (raised-point B C x)))

  inverse-canonical-small : (B : P.Presentation) (C : RAlgebra A ℓ)
    (setC : isSet (CRing.R (ring C))) (h : AlgHom (functionAlgebra A (Small.Affine B) ext) C) →
    inverse B C setC (Small.canonical B C h) ≡ h
  inverse-canonical-small B C setC h =
    trans (cong (lower-hom B C)
      (trans (cong (inverse-canonical (Change.presentation B) C setC) (sym (canonical-raised B C setC h)))
        (inverse-canonical-law (Change.presentation B) C setC (raise-hom B C h))))
      (algHom-ext ext ext ext setC (λ f → cong (algMap h) (ext (λ x → cong f
        (Change.backward-forward A (RingHom.hom ρ) ext0 setR x)))))

  axiom2-base-change : Small.Axiom2
  Small.Axiom2.inverse-canonical axiom2-base-change = inverse
  Small.Axiom2.canonical-inverse axiom2-base-change = canonical-inverse-small
  Small.Axiom2.inverse-canonical-law axiom2-base-change = inverse-canonical-small
