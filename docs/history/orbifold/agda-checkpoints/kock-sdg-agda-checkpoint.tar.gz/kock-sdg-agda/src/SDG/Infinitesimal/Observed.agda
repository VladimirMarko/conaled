{-# OPTIONS --safe --without-K #-}

module SDG.Infinitesimal.Observed where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; Fin; lookup; map; tabulate; lookup-map; lookup-tabulate; vec-ext;
   Permutation; permute)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section03 as S3

-- A witnessed presentation of a subobject uses equality of observations.
-- These records are the three geometric properties in that setoid, with
-- an explicit congruence law for their constructed extension maps.
-- They make no assertion that different witnesses are equal as Agda data.
module Properties {ℓ : Level} (A : CRing ℓ) where
  open Infinitesimals A
  open Jets A
  open S3.HigherInfinitesimals A using (DK; valueK)

  record ObservedInfinitesimallyLinear {a b : Level}
    (M : Set a) {S : Set b} (observe : M → S) : Set (ℓ ⊔ a ⊔ b) where
    field
      extension : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M) →
        ((i : Fin (suc (suc n))) → observe (ts i zeroD) ≡ observe x) →
        Jet1 (suc (suc n)) → M
      axes : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M)
        (base : (i : Fin (suc (suc n))) → observe (ts i zeroD) ≡ observe x)
        (i : Fin (suc (suc n))) (d : D) →
        observe (extension n x ts base (axis i d)) ≡ observe (ts i d)
      uniqueness : (n : ℕ) (x : M) (ts : Fin (suc (suc n)) → D → M)
        (base : (i : Fin (suc (suc n))) → observe (ts i zeroD) ≡ observe x)
        (t : Jet1 (suc (suc n)) → M) →
        ((i : Fin (suc (suc n))) (d : D) → observe (t (axis i d)) ≡ observe (ts i d)) →
        (p : Jet1 (suc (suc n))) → observe (t p) ≡ observe (extension n x ts base p)
      extension-cong : (n : ℕ) (x y : M)
        (ts us : Fin (suc (suc n)) → D → M)
        (base : (i : Fin (suc (suc n))) → observe (ts i zeroD) ≡ observe x)
        (base′ : (i : Fin (suc (suc n))) → observe (us i zeroD) ≡ observe y)
        (p q : Jet1 (suc (suc n))) → observe x ≡ observe y →
        ((i : Fin (suc (suc n))) (d : D) → observe (ts i d) ≡ observe (us i d)) →
        coords p ≡ coords q → observe (extension n x ts base p) ≡ observe (extension n y us base′ q)

  productD : D → D → D
  productD d e = scaleD d (value e)

  record ObservedPropertyW {a b : Level}
    (M : Set a) {S : Set b} (observe : M → S) : Set (ℓ ⊔ a ⊔ b) where
    field
      lift : (f : D → D → M) →
        ((d : D) → observe (f d zeroD) ≡ observe (f zeroD zeroD)) →
        ((e : D) → observe (f zeroD e) ≡ observe (f zeroD zeroD)) → D → M
      factor : (f : D → D → M)
        (a : (d : D) → observe (f d zeroD) ≡ observe (f zeroD zeroD))
        (b : (e : D) → observe (f zeroD e) ≡ observe (f zeroD zeroD))
        (d e : D) → observe (f d e) ≡ observe (lift f a b (productD d e))
      unique : (f : D → D → M)
        (a : (d : D) → observe (f d zeroD) ≡ observe (f zeroD zeroD))
        (b : (e : D) → observe (f zeroD e) ≡ observe (f zeroD zeroD))
        (t : D → M) → ((d e : D) → observe (f d e) ≡ observe (t (productD d e))) →
        (z : D) → observe (t z) ≡ observe (lift f a b z)
      lift-cong : (f g : D → D → M)
        (a : (d : D) → observe (f d zeroD) ≡ observe (f zeroD zeroD))
        (b : (e : D) → observe (f zeroD e) ≡ observe (f zeroD zeroD))
        (a′ : (d : D) → observe (g d zeroD) ≡ observe (g zeroD zeroD))
        (b′ : (e : D) → observe (g zeroD e) ≡ observe (g zeroD zeroD))
        (z w : D) → ((d e : D) → observe (f d e) ≡ observe (g d e)) → value z ≡ value w →
        observe (lift f a b z) ≡ observe (lift g a′ b′ w)

  SymmetricObserved : {a b : Level} {M : Set a} {S : Set b}
    (observe : M → S) {n : ℕ} → (Vec D n → M) → Set (ℓ ⊔ b)
  SymmetricObserved observe {n} f = (p : Permutation n) (ds : Vec D n) →
    observe (f (permute p ds)) ≡ observe (f ds)

  record ObservedSymmetricDescent {a b : Level} (n : ℕ)
    (q : Vec D (suc n) → DK (suc n))
    (M : Set a) {S : Set b} (observe : M → S) : Set (ℓ ⊔ a ⊔ b) where
    field
      descend : (f : Vec D (suc n) → M) → SymmetricObserved observe f → DK (suc n) → M
      factor : (f : Vec D (suc n) → M) (s : SymmetricObserved observe f)
        (ds : Vec D (suc n)) → observe (f ds) ≡ observe (descend f s (q ds))
      unique : (f : Vec D (suc n) → M) (s : SymmetricObserved observe f)
        (t : DK (suc n) → M) → ((ds : Vec D (suc n)) → observe (f ds) ≡ observe (t (q ds))) →
        (d : DK (suc n)) → observe (t d) ≡ observe (descend f s d)
      descend-cong : (f g : Vec D (suc n) → M)
        (s : SymmetricObserved observe f) (s′ : SymmetricObserved observe g)
        (d e : DK (suc n)) → ((ds : Vec D (suc n)) → observe (f ds) ≡ observe (g ds)) →
        valueK d ≡ valueK e → observe (descend f s d) ≡ observe (descend g s′ e)

module VectorClosure {ℓ : Level} (A : CRing ℓ) {a b : Level}
  {M : Set a} {S : Set b} (observe : M → S) where
  open Properties A
  open Infinitesimals A
  open Jets A
  open S3.HigherInfinitesimals A using (DK; valueK)

  observations : {m : ℕ} → Vec M m → Vec S m
  observations = map observe

  project : {m : ℕ} {xs ys : Vec M m} → observations xs ≡ observations ys →
    (j : Fin m) → observe (lookup xs j) ≡ observe (lookup ys j)
  project {xs = xs} {ys} p j =
    trans (sym (lookup-map observe xs j))
      (trans (cong (λ zs → lookup zs j) p) (lookup-map observe ys j))

  observation-ext : {m : ℕ} {xs ys : Vec M m} →
    ((j : Fin m) → observe (lookup xs j) ≡ observe (lookup ys j)) → observations xs ≡ observations ys
  observation-ext {xs = xs} {ys} p = vec-ext (λ j →
    trans (lookup-map observe xs j) (trans (p j) (sym (lookup-map observe ys j))))

  tabulated : {m : ℕ} (f : Fin m → M) (j : Fin m) →
    observe (lookup (tabulate f) j) ≡ observe (f j)
  tabulated f j = cong observe (lookup-tabulate f j)

  vector-linear : ObservedInfinitesimallyLinear M observe → (m : ℕ) →
    ObservedInfinitesimallyLinear (Vec M m) observations
  ObservedInfinitesimallyLinear.extension (vector-linear L m) n x ts base p =
    tabulate (λ j → ObservedInfinitesimallyLinear.extension L n (lookup x j)
      (λ i d → lookup (ts i d) j) (λ i → project (base i) j) p)
  ObservedInfinitesimallyLinear.axes (vector-linear L m) n x ts base i d = observation-ext (λ j →
    trans (tabulated _ j) (ObservedInfinitesimallyLinear.axes L n (lookup x j)
      (λ i d → lookup (ts i d) j) (λ i → project (base i) j) i d))
  ObservedInfinitesimallyLinear.uniqueness (vector-linear L m) n x ts base t p d = observation-ext (λ j →
    trans (ObservedInfinitesimallyLinear.uniqueness L n (lookup x j)
      (λ i d → lookup (ts i d) j) (λ i → project (base i) j)
      (λ q → lookup (t q) j) (λ i e → project (p i e) j) d)
      (sym (tabulated _ j)))
  ObservedInfinitesimallyLinear.extension-cong (vector-linear L m) n x y ts us base base′ p q xy tu pq =
    observation-ext (λ j → trans (tabulated _ j)
      (trans (ObservedInfinitesimallyLinear.extension-cong L n (lookup x j) (lookup y j)
        (λ i d → lookup (ts i d) j) (λ i d → lookup (us i d) j)
        (λ i → project (base i) j) (λ i → project (base′ i) j) p q
        (project xy j) (λ i d → project (tu i d) j) pq) (sym (tabulated _ j))))

  vector-W : ObservedPropertyW M observe → (m : ℕ) → ObservedPropertyW (Vec M m) observations
  ObservedPropertyW.lift (vector-W W m) f a b z = tabulate (λ j →
    ObservedPropertyW.lift W (λ d e → lookup (f d e) j)
      (λ d → project (a d) j) (λ e → project (b e) j) z)
  ObservedPropertyW.factor (vector-W W m) f a b d e = observation-ext (λ j →
    trans (ObservedPropertyW.factor W (λ d e → lookup (f d e) j)
      (λ d → project (a d) j) (λ e → project (b e) j) d e) (sym (tabulated _ j)))
  ObservedPropertyW.unique (vector-W W m) f a b t p z = observation-ext (λ j →
    trans (ObservedPropertyW.unique W (λ d e → lookup (f d e) j)
      (λ d → project (a d) j) (λ e → project (b e) j) (λ d → lookup (t d) j)
      (λ d e → project (p d e) j) z) (sym (tabulated _ j)))
  ObservedPropertyW.lift-cong (vector-W W m) f g a b a′ b′ z w fg zw = observation-ext (λ j →
    trans (tabulated _ j) (trans (ObservedPropertyW.lift-cong W
      (λ d e → lookup (f d e) j) (λ d e → lookup (g d e) j)
      (λ d → project (a d) j) (λ e → project (b e) j)
      (λ d → project (a′ d) j) (λ e → project (b′ e) j) z w
      (λ d e → project (fg d e) j) zw) (sym (tabulated _ j))))

  vector-symmetric : {n : ℕ} {q : Vec D (suc n) → DK (suc n)} →
    ObservedSymmetricDescent n q M observe → (m : ℕ) →
    ObservedSymmetricDescent n q (Vec M m) observations
  ObservedSymmetricDescent.descend (vector-symmetric S m) f s d = tabulate (λ j →
    ObservedSymmetricDescent.descend S (λ ds → lookup (f ds) j)
      (λ p ds → project (s p ds) j) d)
  ObservedSymmetricDescent.factor (vector-symmetric S m) f s ds = observation-ext (λ j →
    trans (ObservedSymmetricDescent.factor S (λ es → lookup (f es) j)
      (λ p es → project (s p es) j) ds) (sym (tabulated _ j)))
  ObservedSymmetricDescent.unique (vector-symmetric S m) f s t p d = observation-ext (λ j →
    trans (ObservedSymmetricDescent.unique S (λ es → lookup (f es) j)
      (λ p es → project (s p es) j) (λ e → lookup (t e) j)
      (λ es → project (p es) j) d) (sym (tabulated _ j)))
  ObservedSymmetricDescent.descend-cong (vector-symmetric S m) f g s s′ d e fg de = observation-ext (λ j →
    trans (tabulated _ j) (trans (ObservedSymmetricDescent.descend-cong S
      (λ es → lookup (f es) j) (λ es → lookup (g es) j)
      (λ p es → project (s p es) j) (λ p es → project (s′ p es) j) d e
      (λ es → project (fg es) j) de) (sym (tabulated _ j))))
