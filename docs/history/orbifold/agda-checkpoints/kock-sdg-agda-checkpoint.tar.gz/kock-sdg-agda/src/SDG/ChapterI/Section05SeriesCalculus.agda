{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section05SeriesCalculus where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; finToNat; lookup; tabulate; map;
   lookup-map; lookup-tabulate; vec-ext; snoc; _+ℕ_)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section05 as S5
import SDG.ChapterI.Section05Local as L5
import SDG.ChapterI.Section05Series as F5

-- Explicit bridge between the formal series and local differential calculus.
module Coefficients {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open S5.Rectangular A H setR
  open S5.Taylor A K H Q setR using
    (Indices; degrees; lookup-tensor; inverse-multifactorial)
  open L5.LocalTaylor A K H Q setR
  open F5.Results A H setR

  prefix-cons : (α : ℕ → R) (n : ℕ) →
    prefix α (suc n) ≡ α zero ∷ prefix (λ k → α (suc k)) n
  prefix-cons α zero = refl
  prefix-cons α (suc n) = cong (λ as → snoc as (α (suc n))) (prefix-cons α n)

  lookup-prefix : (α : ℕ → R) {n : ℕ} (i : Fin n) →
    lookup (prefix α n) i ≡ α (finToNat i)
  lookup-prefix α {suc n} fzero = cong (λ as → lookup as fzero) (prefix-cons α n)
  lookup-prefix α {suc n} (fsuc i) =
    trans (cong (λ as → lookup as (fsuc i)) (prefix-cons α n))
      (lookup-prefix (λ k → α (suc k)) i)

  include-rectangle : {n : ℕ} {ks : Vec ℕ n} → Points ks → Points∞ n
  include-rectangle {ks = []} one = []
  include-rectangle {ks = k ∷ ks} (d , ds) = witnessed k d ∷ include-rectangle ds

  prefix-tensor : {n : ℕ} → FormalSeries n → (ks : Vec ℕ n) → Coefficients ks
  prefix-tensor α [] = α []
  prefix-tensor α (k ∷ ks) =
    tabulate (λ i → prefix-tensor (λ es → α (finToNat i ∷ es)) ks)

  prefix-tensor-evaluation : {n : ℕ} (α : FormalSeries n) (ks : Vec ℕ n) (ds : Points ks) →
    evaluate (prefix-tensor α ks) ds ≡ evaluateFormal α (include-rectangle ds)
  prefix-tensor-evaluation α [] one = refl
  prefix-tensor-evaluation α (k ∷ ks) (d , ds) = cong (λ as → eval as (valueK d)) coefficient-values
    where
    coefficient-values : map (λ a → evaluate {ks = ks} a ds) (prefix-tensor α (k ∷ ks)) ≡
      prefix (λ j → evaluateFormal (λ es → α (j ∷ es)) (include-rectangle ds)) (suc k)
    coefficient-values = vec-ext (λ i →
      trans (lookup-map (λ a → evaluate {ks = ks} a ds) (prefix-tensor α (k ∷ ks)) i)
        (trans (cong (λ a → evaluate {ks = ks} a ds)
          (lookup-tabulate (λ j → prefix-tensor (λ es → α (finToNat j ∷ es)) ks) i))
          (trans (prefix-tensor-evaluation (λ es → α (finToNat i ∷ es)) ks ds)
            (sym (lookup-prefix (λ j → evaluateFormal (λ es → α (j ∷ es))
              (include-rectangle ds)) i)))))

  prefix-tensor-coefficient : {n : ℕ} (α : FormalSeries n) (ks : Vec ℕ n) (is : Indices ks) →
    lookup-tensor {ks = ks} (prefix-tensor α ks) is ≡ α (degrees {ks = ks} is)
  prefix-tensor-coefficient α [] tt = refl
  prefix-tensor-coefficient α (k ∷ ks) (i , is) =
    trans (cong (λ as → lookup-tensor {ks = ks} as is)
      (lookup-tabulate (λ j → prefix-tensor (λ es → α (finToNat j ∷ es)) ks) i))
      (prefix-tensor-coefficient (λ es → α (finToNat i ∷ es)) ks is)

  series-finite-tensor : {n : ℕ} (f : Points∞ n → R) → Respects f → (ks : Vec ℕ n) →
    coefficient-tensor {ks = ks} (λ ds → f (include-rectangle ds)) ≡
      prefix-tensor (representingSeries f) ks
  series-finite-tensor f respects ks = uniqueness-tensor
    (λ ds → f (include-rectangle ds)) (prefix-tensor (representingSeries f) ks)
    (λ ds → trans (formal-representation f respects (include-rectangle ds))
      (sym (prefix-tensor-evaluation (representingSeries f) ks ds)))

  local-finite-tensor : {n : ℕ} (ks : Vec ℕ n) (f : Points ks → R) →
    coefficient-tensor f ≡ local-tensor ks f
  local-finite-tensor ks f = uniqueness-tensor f (local-tensor ks f) (local-taylor-rectangle ks f)

  -- Each formal coefficient is the indicated local mixed derivative / α!.
  formal-coefficient-derivative : {n : ℕ} (f : Points∞ n → R) → Respects f →
    (ks : Vec ℕ n) (is : Indices ks) →
    representingSeries f (degrees {ks = ks} is) ≡
      inverse-multifactorial (degrees {ks = ks} is) *
        local-mixed is (λ ds → f (include-rectangle ds))
  formal-coefficient-derivative f respects ks is =
    trans (sym (prefix-tensor-coefficient (representingSeries f) ks is))
      (trans (cong (λ as → lookup-tensor {ks = ks} as is) (sym (series-finite-tensor f respects ks)))
        (trans (cong (λ as → lookup-tensor {ks = ks} as is)
          (local-finite-tensor ks (λ ds → f (include-rectangle ds))))
          (local-tensor-coefficient ks (λ ds → f (include-rectangle ds)) is)))

  last-index : (k : ℕ) → Fin (suc k)
  last-index zero = fzero
  last-index (suc k) = fsuc (last-index k)

  last-index-value : (k : ℕ) → finToNat (last-index k) ≡ k
  last-index-value zero = refl
  last-index-value (suc k) = cong suc (last-index-value k)

  top-indices : {n : ℕ} (ks : Vec ℕ n) → Indices ks
  top-indices [] = tt
  top-indices (k ∷ ks) = last-index k , top-indices ks

  top-degrees : {n : ℕ} (ks : Vec ℕ n) → degrees {ks = ks} (top-indices ks) ≡ ks
  top-degrees [] = refl
  top-degrees (k ∷ ks) = cong₂ _∷_ (last-index-value k) (top-degrees ks)

  every-formal-coefficient : {n : ℕ} (f : Points∞ n → R) → Respects f →
    (α : Vec ℕ n) → representingSeries f α ≡
      inverse-multifactorial α * local-mixed (top-indices α) (λ ds → f (include-rectangle ds))
  every-formal-coefficient f respects α =
    trans (cong (representingSeries f) (sym (top-degrees α)))
      (trans (formal-coefficient-derivative f respects α (top-indices α))
        (cong (λ es → inverse-multifactorial es *
          local-mixed (top-indices α) (λ ds → f (include-rectangle ds))) (top-degrees α)))

  -- The comment following (5.1): every term outside a rectangular degree
  -- bound vanishes. A strictly larger exponent is exhibited as k+1+q.
  monomial : {n : ℕ} {ks : Vec ℕ n} → Vec ℕ n → Points ks → R
  monomial {ks = []} [] one = 1r
  monomial {ks = k ∷ ks} (e ∷ es) (d , ds) = valueK d ^ e * monomial es ds

  above-bound-monomial-zero : {n : ℕ} (ks es : Vec ℕ n) (ds : Points ks)
    (i : Fin n) (q : ℕ) → lookup es i ≡ suc (lookup ks i) +ℕ q → monomial es ds ≡ 0r
  above-bound-monomial-zero (k ∷ ks) (e ∷ es) (d , ds) fzero q higher =
    trans (cong (_* monomial es ds)
      (trans (cong (valueK d ^_) higher)
        (nilpotent-monotone (valueK d) (suc k) q (nilpotence d))))
      (*-zeroˡ (monomial es ds))
  above-bound-monomial-zero (k ∷ ks) (e ∷ es) (d , ds) (fsuc i) q higher =
    trans (cong ((valueK d ^ e) *_) (above-bound-monomial-zero ks es ds i q higher))
      (*-zeroʳ (valueK d ^ e))

  above-bound-term-zero : {n : ℕ} (a : R) (ks es : Vec ℕ n) (ds : Points ks)
    (i : Fin n) (q : ℕ) → lookup es i ≡ suc (lookup ks i) +ℕ q → a * monomial es ds ≡ 0r
  above-bound-term-zero a ks es ds i q higher =
    trans (cong (a *_) (above-bound-monomial-zero ks es ds i q higher)) (*-zeroʳ a)

