{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.Presented where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Finite using (Fin; fzero; fsuc)

-- Finite polynomial presentations, with coefficients in an external ring.
-- Polynomial expressions may have redundant syntax. Their interpretation
-- uses genuine ring operations; equations in a presentation are imposed on
-- tuples, rather than being inserted as assumed properties of a scheme.
module Presentations {κ : Level} (k : CRing κ) where
  private module K = CRing k

  infixl 6 _⊕_
  infixl 7 _⊗_
  data Polynomial (n : ℕ) : Set κ where
    coefficient : K.R → Polynomial n
    var : Fin n → Polynomial n
    _⊕_ _⊗_ : Polynomial n → Polynomial n → Polynomial n
    negative : Polynomial n → Polynomial n

  zeroP oneP : {n : ℕ} → Polynomial n
  zeroP = coefficient K.0r
  oneP = coefficient K.1r

  evaluate : {c : Level} (C : CRing c) → (K.R → CRing.R C) →
    {n : ℕ} → Polynomial n → (Fin n → CRing.R C) → CRing.R C
  evaluate C ι (coefficient a) xs = ι a
  evaluate C ι (var i) xs = xs i
  evaluate C ι (p ⊕ q) xs = CRing._+_ C (evaluate C ι p xs) (evaluate C ι q xs)
  evaluate C ι (p ⊗ q) xs = CRing._*_ C (evaluate C ι p xs) (evaluate C ι q xs)
  evaluate C ι (negative p) xs = CRing.-_ C (evaluate C ι p xs)

  evaluate-cong : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C))
    {n : ℕ} (p : Polynomial n) {xs ys : Fin n → CRing.R C} →
    ((i : Fin n) → xs i ≡ ys i) → evaluate C ι p xs ≡ evaluate C ι p ys
  evaluate-cong C ι (coefficient a) eq = refl
  evaluate-cong C ι (var i) eq = eq i
  evaluate-cong C ι (p ⊕ q) eq =
    cong₂ (CRing._+_ C) (evaluate-cong C ι p eq) (evaluate-cong C ι q eq)
  evaluate-cong C ι (p ⊗ q) eq =
    cong₂ (CRing._*_ C) (evaluate-cong C ι p eq) (evaluate-cong C ι q eq)
  evaluate-cong C ι (negative p) eq = cong (CRing.-_ C) (evaluate-cong C ι p eq)

  evaluate-hom : {c d : Level} (C : CRing c) (D : CRing d)
    (ι : (K.R → CRing.R C)) (κD : (K.R → CRing.R D)) (h : RingHom C D) →
    ((a : K.R) → RingHom.hom h (ι a) ≡ κD a) →
    {n : ℕ} (p : Polynomial n) (xs : Fin n → CRing.R C) →
    RingHom.hom h (evaluate C ι p xs) ≡
      evaluate D κD p (λ i → RingHom.hom h (xs i))
  evaluate-hom C D ι κD h coherent (coefficient a) xs = coherent a
  evaluate-hom C D ι κD h coherent (var i) xs = refl
  evaluate-hom C D ι κD h coherent (p ⊕ q) xs =
    trans (RingHom.pres-+ h (evaluate C ι p xs) (evaluate C ι q xs))
      (cong₂ (CRing._+_ D) (evaluate-hom C D ι κD h coherent p xs)
        (evaluate-hom C D ι κD h coherent q xs))
  evaluate-hom C D ι κD h coherent (p ⊗ q) xs =
    trans (RingHom.pres-* h (evaluate C ι p xs) (evaluate C ι q xs))
      (cong₂ (CRing._*_ D) (evaluate-hom C D ι κD h coherent p xs)
        (evaluate-hom C D ι κD h coherent q xs))
  evaluate-hom C D ι κD h coherent (negative p) xs =
    trans (RingHom.pres-neg h (evaluate C ι p xs))
      (cong (CRing.-_ D) (evaluate-hom C D ι κD h coherent p xs))

  substitute : {n m : ℕ} → (Fin n → Polynomial m) → Polynomial n → Polynomial m
  substitute σ (coefficient a) = coefficient a
  substitute σ (var i) = σ i
  substitute σ (p ⊕ q) = substitute σ p ⊕ substitute σ q
  substitute σ (p ⊗ q) = substitute σ p ⊗ substitute σ q
  substitute σ (negative p) = negative (substitute σ p)

  substitute-identity : {n : ℕ} (p : Polynomial n) → substitute var p ≡ p
  substitute-identity (coefficient a) = refl
  substitute-identity (var i) = refl
  substitute-identity (p ⊕ q) = cong₂ _⊕_ (substitute-identity p) (substitute-identity q)
  substitute-identity (p ⊗ q) = cong₂ _⊗_ (substitute-identity p) (substitute-identity q)
  substitute-identity (negative p) = cong negative (substitute-identity p)

  substitute-compose : {n m r : ℕ} (σ : Fin n → Polynomial m) (τ : Fin m → Polynomial r)
    (p : Polynomial n) → substitute τ (substitute σ p) ≡ substitute (λ i → substitute τ (σ i)) p
  substitute-compose σ τ (coefficient a) = refl
  substitute-compose σ τ (var i) = refl
  substitute-compose σ τ (p ⊕ q) =
    cong₂ _⊕_ (substitute-compose σ τ p) (substitute-compose σ τ q)
  substitute-compose σ τ (p ⊗ q) =
    cong₂ _⊗_ (substitute-compose σ τ p) (substitute-compose σ τ q)
  substitute-compose σ τ (negative p) = cong negative (substitute-compose σ τ p)

  evaluate-substitute : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C))
    {n m : ℕ} (σ : Fin n → Polynomial m) (p : Polynomial n) (xs : Fin m → CRing.R C) →
    evaluate C ι (substitute σ p) xs ≡ evaluate C ι p (λ i → evaluate C ι (σ i) xs)
  evaluate-substitute C ι σ (coefficient a) xs = refl
  evaluate-substitute C ι σ (var i) xs = refl
  evaluate-substitute C ι σ (p ⊕ q) xs =
    cong₂ (CRing._+_ C) (evaluate-substitute C ι σ p xs) (evaluate-substitute C ι σ q xs)
  evaluate-substitute C ι σ (p ⊗ q) xs =
    cong₂ (CRing._*_ C) (evaluate-substitute C ι σ p xs) (evaluate-substitute C ι σ q xs)
  evaluate-substitute C ι σ (negative p) xs =
    cong (CRing.-_ C) (evaluate-substitute C ι σ p xs)

  record Presentation : Set κ where
    constructor presented
    field
      generators relations : ℕ
      equations : Fin relations → Polynomial generators
  open Presentation public

  record Spec {c : Level} (C : CRing c) (ι : (K.R → CRing.R C)) (B : Presentation) : Set c where
    constructor solution
    field
      coordinates : Fin (generators B) → CRing.R C
      satisfies : (j : Fin (relations B)) → evaluate C ι (equations B j) coordinates ≡ CRing.0r C
  open Spec public

  spec-path : {c : Level} {C : CRing c} {ι : (K.R → CRing.R C)} {B : Presentation} →
    FunExt lzero c → isSet (CRing.R C) → {p q : Spec C ι B} →
    ((i : Fin (generators B)) → coordinates p i ≡ coordinates q i) → p ≡ q
  spec-path {C = C} {ι} {B} ext setC {solution xs p} {solution ys q} eq = aux (ext eq)
    where
    aux : xs ≡ ys → solution xs p ≡ solution ys q
    aux refl = cong (solution xs)
      (ext (λ j → setC (evaluate C ι (equations B j) xs) (CRing.0r C) (p j) (q j)))

  free : ℕ → Presentation
  free n = presented n zero (λ ())

  line : Presentation
  line = free 1

  dualLine : Presentation
  dualLine = presented 1 1 (λ _ → var fzero ⊗ var fzero)

  circle : Presentation
  circle = presented 2 1 (λ _ →
    ((var fzero ⊗ var fzero) ⊕ (var (fsuc fzero) ⊗ var (fsuc fzero)))
      ⊕ negative oneP)

  free-point : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C)) {n : ℕ} →
    (Fin n → CRing.R C) → Spec C ι (free n)
  free-point C ι xs = solution xs (λ ())

  line-point : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C)) → CRing.R C → Spec C ι line
  line-point C ι x = free-point C ι (λ _ → x)

  line-value : {c : Level} {C : CRing c} {ι : (K.R → CRing.R C)} → Spec C ι line → CRing.R C
  line-value p = coordinates p fzero

  line-value-point : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C)) (x : CRing.R C) →
    line-value (line-point C ι x) ≡ x
  line-value-point C ι x = refl

  line-point-value : {c : Level} (C : CRing c) (ι : (K.R → CRing.R C))
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) (p : Spec C ι line) →
    line-point C ι (line-value p) ≡ p
  line-point-value C ι ext setC p = spec-path ext setC λ
    { fzero → refl ; (fsuc ()) }
