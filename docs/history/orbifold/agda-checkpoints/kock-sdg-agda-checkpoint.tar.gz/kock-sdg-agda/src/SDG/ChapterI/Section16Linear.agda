{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16Linear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Algebra.Module
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Algebra.PresentedJets
open import SDG.Algebra.RelativeDual using (product-isSet)
import SDG.Algebra.SquareZero as SZ
import SDG.Combinatorics.FiniteSums as FS
open import SDG.Finite using (Fin; fzero; fsuc; lookup; tabulate; lookup-tabulate; vec-ext)
open import SDG.Infinitesimal.Jets
open import SDG.Schemes.Extensionality
open import SDG.Schemes.FiniteBlocks using (splitIndex; injectIndex)
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section06Linear as S6L
import SDG.ChapterI.Section12 as S12
import SDG.ChapterI.Section16Comparison as Comparison
import SDG.ChapterI.Section16FirstOrder as FirstOrder

-- The explicit square-zero Weil algebra R ⊕ R^n represents D(n).
-- Axiom 2 therefore yields affine reconstruction in every dimension,
-- and hence the infinitesimal linearity assertion in Proposition 16.2.
module Linearity {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Presentations k
  open JetPresentations k
  open S12.Comprehensive k A base ext ext0 setR
  open Comparison.Comparison k A base ext ext0 setR Ax

  module Dimension (n : ℕ) where
    module C = SZ.Extension A (functionModule A (scalarModule A) (Fin n) ext0)
    module CS = FS.Sums C.square-zero-ring

    epsilon : Fin n → C.Carrier
    epsilon i = C.ideal (Sum.delta i)

    generic-jet : SpecC C.square-zero-algebra (first-order n)
    coordinates generic-jet = epsilon
    satisfies generic-jet j = C.ideal-square-zero
      (Sum.delta (fst (splitIndex (pair-sizes n) j))) (Sum.delta (snd (splitIndex (pair-sizes n) j)))

    to-spectrum : Jet1 n → Affine (first-order n)
    coordinates (to-spectrum d) = coordinate d
    satisfies (to-spectrum d) j = pair-zero d
      (fst (splitIndex (pair-sizes n) j)) (snd (splitIndex (pair-sizes n) j))

    spectrum-pairs : (x : Affine (first-order n)) (i j : Fin n) → coordinates x i * coordinates x j ≡ 0r
    spectrum-pairs x i j =
      trans (sym (cong (λ p → evaluate A (RingHom.hom base) p (coordinates x)) (pair-equation n i j)))
        (satisfies x (injectIndex (pair-sizes n) i j))

    from-spectrum : Affine (first-order n) → Jet1 n
    from-spectrum x = makeJet1 (tabulate (coordinates x))
      (λ i j → trans (cong₂ _*_ (lookup-tabulate (coordinates x) i) (lookup-tabulate (coordinates x) j))
        (spectrum-pairs x i j))

    from-to-spectrum : (d : Jet1 n) → from-spectrum (to-spectrum d) ≡ d
    from-to-spectrum d = jet-path setR ext0 (vec-ext (lookup-tabulate (coordinate d)))

    dot : (Fin n → R) → (Fin n → R) → R
    dot x u = Sum.sum (λ i → x i * u i)

    dot-zero : (x : Fin n → R) → dot x (λ _ → 0r) ≡ 0r
    dot-zero x = trans (Sum.sum-cong (λ i → *-zeroʳ (x i))) (Sum.sum-zero n)

    dot-add : (x u v : Fin n → R) → dot x (λ i → u i + v i) ≡ dot x u + dot x v
    dot-add x u v = trans (Sum.sum-cong (λ i → distribˡ (x i) (u i) (v i)))
      (Sum.sum-add (λ i → x i * u i) (λ i → x i * v i))

    dot-scale : (x : Fin n → R) (a : R) (u : Fin n → R) → dot x (λ i → a * u i) ≡ a * dot x u
    dot-scale x a u = trans (Sum.sum-cong (λ i → *-swap (x i) a (u i)))
      (Sum.sum-scaleˡ a (λ i → x i * u i))

    dot-neg : (x u : Fin n → R) → dot x (λ i → - u i) ≡ - dot x u
    dot-neg x u = trans (Sum.sum-cong (λ i → neg-mulʳ (x i) (u i))) (Sum.sum-neg (λ i → x i * u i))

    dot-products-zero : (x : Affine (first-order n)) (u v : Fin n → R) →
      dot (coordinates x) u * dot (coordinates x) v ≡ 0r
    dot-products-zero x u v =
      trans (sym (Sum.sum-scaleʳ (λ i → coordinates x i * u i) (dot (coordinates x) v)))
        (trans (Sum.sum-cong (λ i →
          trans (sym (Sum.sum-scaleˡ (coordinates x i * u i) (λ j → coordinates x j * v j)))
            (trans (Sum.sum-cong (λ j →
              trans (*-shuffle (coordinates x i) (u i) (coordinates x j) (v j))
                (trans (cong (_* (u i * v j)) (spectrum-pairs x i j)) (*-zeroˡ (u i * v j)))))
              (Sum.sum-zero n)))) (Sum.sum-zero n))

    nil-product : (a b u v : R) → u * v ≡ 0r → (a + u) * (b + v) ≡ a * b + (a * v + b * u)
    nil-product a b u v uv =
      trans (distribʳ a u (b + v))
        (trans (cong₂ _+_ (distribˡ a b v)
          (trans (distribˡ u b v) (trans (cong₂ _+_ (*-comm u b) uv) (+-identityʳ (b * u)))))
          (+-assoc (a * b) (a * v) (b * u)))

    evaluate-scalar : (x : Affine (first-order n)) (r : R) → r + dot (coordinates x) (λ _ → 0r) ≡ r
    evaluate-scalar x r = trans (cong (r +_) (dot-zero (coordinates x))) (+-identityʳ r)

    jet-character : (x : Affine (first-order n)) → AlgHom C.square-zero-algebra (scalarAlgebra A)
    RingHom.hom (ringHom (jet-character x)) p = fst p + dot (coordinates x) (snd p)
    RingHom.pres-0 (ringHom (jet-character x)) = evaluate-scalar x 0r
    RingHom.pres-1 (ringHom (jet-character x)) = evaluate-scalar x 1r
    RingHom.pres-+ (ringHom (jet-character x)) (a , u) (b , v) =
      trans (cong ((a + b) +_) (dot-add (coordinates x) u v))
        (+-shuffle a b (dot (coordinates x) u) (dot (coordinates x) v))
    RingHom.pres-* (ringHom (jet-character x)) (a , u) (b , v) =
      trans (cong ((a * b) +_)
        (trans (dot-add (coordinates x) (λ i → a * v i) (λ i → b * u i))
          (cong₂ _+_ (dot-scale (coordinates x) a v) (dot-scale (coordinates x) b u))))
        (sym (nil-product a b (dot (coordinates x) u) (dot (coordinates x) v) (dot-products-zero x u v)))
    RingHom.pres-neg (ringHom (jet-character x)) (a , u) =
      trans (cong ((- a) +_) (dot-neg (coordinates x) u)) (sym (neg-add a (dot (coordinates x) u)))
    commutes (jet-character x) r = evaluate-scalar x r

    character-epsilon : (x : Affine (first-order n)) (i : Fin n) → algMap (jet-character x) (epsilon i) ≡ coordinates x i
    character-epsilon x i = trans (+-identityˡ (dot (coordinates x) (Sum.delta i)))
      (trans (Sum.sum-cong (λ j → *-comm (coordinates x j) (Sum.delta i j))) (Sum.sum-delta (coordinates x) i))

    sum-ideal : {m : ℕ} (v : Fin m → Fin n → R) →
      CS.sum (λ i → C.ideal (v i)) ≡ C.ideal (λ j → Sum.sum (λ i → v i j))
    sum-ideal {zero} v = refl
    sum-ideal {suc m} v = trans (cong (C.add (C.ideal (v fzero))) (sum-ideal (λ i → v (fsuc i))))
      (cong (λ r → r , (λ j → v fzero j + Sum.sum (λ i → v (fsuc i) j))) (+-identityˡ 0r))

    ideal-basis : (u : Fin n → R) → CS.sum (λ i → C.multiply (C.scalar (u i)) (epsilon i)) ≡ C.ideal u
    ideal-basis u = trans (CS.sum-cong (λ i → C.scalar-ideal (u i) (Sum.delta i)))
      (trans (sum-ideal (λ i j → u i * Sum.delta i j))
        (cong C.ideal (ext0 (λ j → Sum.basis-expansion u j))))

    basis-normal-form : (p : C.Carrier) →
      C.add (C.scalar (fst p)) (CS.sum (λ i → C.multiply (C.scalar (snd p i)) (epsilon i))) ≡ p
    basis-normal-form p = trans (cong (C.add (C.scalar (fst p))) (ideal-basis (snd p))) (C.normal-form p)

    hom-sum : (f : AlgHom C.square-zero-algebra C.square-zero-algebra) {m : ℕ} (u : Fin m → C.Carrier) →
      algMap f (CS.sum u) ≡ CS.sum (λ i → algMap f (u i))
    hom-sum f {zero} u = RingHom.pres-0 (ringHom f)
    hom-sum f {suc m} u = trans (RingHom.pres-+ (ringHom f) (u fzero) (CS.sum (λ i → u (fsuc i))))
      (cong (C.add (algMap f (u fzero))) (hom-sum f (λ i → u (fsuc i))))

    hom-normal-form : (f : AlgHom C.square-zero-algebra C.square-zero-algebra) (p : C.Carrier) →
      algMap f p ≡ C.add (C.scalar (fst p))
        (CS.sum (λ i → C.multiply (C.scalar (snd p i)) (algMap f (epsilon i))))
    hom-normal-form f p = trans (cong (algMap f) (sym (basis-normal-form p)))
      (trans (RingHom.pres-+ (ringHom f) (C.scalar (fst p))
        (CS.sum (λ i → C.multiply (C.scalar (snd p i)) (epsilon i))))
        (cong₂ C.add (commutes f (fst p))
          (trans (hom-sum f (λ i → C.multiply (C.scalar (snd p i)) (epsilon i)))
            (CS.sum-cong (λ i → trans (RingHom.pres-* (ringHom f) (C.scalar (snd p i)) (epsilon i))
              (cong (λ c → C.multiply c (algMap f (epsilon i))) (commutes f (snd p i))))))))

    carrier-set : isSet C.Carrier
    carrier-set = product-isSet setR (function-set ext0 (λ _ → setR))

    jet-generated : (f g : AlgHom C.square-zero-algebra C.square-zero-algebra) →
      ((i : Fin n) → algMap f (epsilon i) ≡ algMap g (epsilon i)) → f ≡ g
    jet-generated f g eq = algHom-ext ext ext ext carrier-set (λ p → trans (hom-normal-form f p)
      (trans (cong (C.add (C.scalar (fst p)))
        (CS.sum-cong (λ i → cong (C.multiply (C.scalar (snd p i))) (eq i)))) (sym (hom-normal-form g p))))

    jet-realization : AlgebraicRealization (first-order n)
    model-algebra jet-realization = C.square-zero-algebra
    set-carrier jet-realization = carrier-set
    generic-point jet-realization = generic-jet
    character jet-realization = jet-character
    evaluate-generator jet-realization = character-epsilon
    generated jet-realization = jet-generated

    module Iso = Realized (first-order n) jet-realization

    coefficients : (Jet1 n → R) → C.Carrier
    coefficients f = algMap Iso.beta (λ x → f (from-spectrum x))

    affine-reconstruction : (f : Jet1 n → R) (d : Jet1 n) →
      f d ≡ fst (coefficients f) + Sum.sum (λ i → coordinate d i * snd (coefficients f) i)
    affine-reconstruction f d = trans (cong f (sym (from-to-spectrum d)))
      (sym (cong (λ h → algMap h (λ x → f (from-spectrum x)) (to-spectrum d)) Iso.alpha-beta))

  K : KockLawvere
  K = FirstOrder.FirstOrder.axiom2-first-order k A base ext ext0 setR Ax
  open KockLawvere K
  open S6.Linear A
  open S6L.Affine A using (axis-dot)

  extend : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R) →
    ((i : Fin (suc (suc n))) → ts i zeroD ≡ x) → Jet1 (suc (suc n)) → R
  extend n x ts base p = x + Sum.sum (λ i → coordinate p i * slope (ts i))

  extend-axis : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R)
    (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x) (i : Fin (suc (suc n))) (d : D) →
    extend n x ts base (axis i d) ≡ ts i d
  extend-axis n x ts base i d = trans (cong (x +_) (axis-dot (λ j → slope (ts j)) i d))
    (trans (cong (_+ (value d * slope (ts i))) (sym (base i))) (sym (expansion (ts i) d)))

  extend-unique : (n : ℕ) (x : R) (ts : Fin (suc (suc n)) → D → R)
    (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x)
    (candidate : Jet1 (suc (suc n)) → R) →
    ((i : Fin (suc (suc n))) (d : D) → candidate (axis i d) ≡ ts i d) →
    (p : Jet1 (suc (suc n))) → candidate p ≡ extend n x ts base p
  extend-unique n x ts base candidate agrees p = trans (Dim.affine-reconstruction candidate p)
    (cong₂ _+_ base-correct (Sum.sum-cong (λ i → cong (coordinate p i *_) (coefficient-correct i))))
    where
    module Dim = Dimension (suc (suc n))
    a : R
    a = fst (Dim.coefficients candidate)
    bs : Fin (suc (suc n)) → R
    bs = snd (Dim.coefficients candidate)
    on-axis : (i : Fin (suc (suc n))) (d : D) → candidate (axis i d) ≡ a + value d * bs i
    on-axis i d = trans (Dim.affine-reconstruction candidate (axis i d)) (cong (a +_) (axis-dot bs i d))
    base-correct : a ≡ x
    base-correct = trans (sym (trans (on-axis fzero zeroD)
      (trans (cong (a +_) (*-zeroˡ (bs fzero))) (+-identityʳ a))))
      (trans (agrees fzero zeroD) (base fzero))
    coefficient-correct : (i : Fin (suc (suc n))) → bs i ≡ slope (ts i)
    coefficient-correct i = sym (uniqueness (ts i) (bs i) (λ d → trans (sym (agrees i d))
      (trans (on-axis i d) (cong (_+ (value d * bs i)) (trans base-correct (sym (base i)))))))

  axiom2-infinitesimally-linear : InfinitesimallyLinear R
  InfinitesimallyLinear.extension axiom2-infinitesimally-linear = extend
  InfinitesimallyLinear.axes axiom2-infinitesimally-linear = extend-axis
  InfinitesimallyLinear.uniqueness axiom2-infinitesimally-linear = extend-unique
