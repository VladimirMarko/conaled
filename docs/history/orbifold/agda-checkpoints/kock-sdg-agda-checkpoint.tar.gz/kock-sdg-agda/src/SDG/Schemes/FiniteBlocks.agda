{-# OPTIONS --safe --without-K #-}
module SDG.Schemes.FiniteBlocks where

open import SDG.Prelude
open import SDG.Finite using (Fin; fzero; fsuc; _+ℕ_)

data EitherFin (m n : ℕ) : Set where
  in-left : Fin m → EitherFin m n
  in-right : Fin n → EitherFin m n

left-index : {m n : ℕ} → Fin m → Fin (m +ℕ n)
left-index fzero = fzero
left-index (fsuc i) = fsuc (left-index i)

right-index : (m : ℕ) {n : ℕ} → Fin n → Fin (m +ℕ n)
right-index zero i = i
right-index (suc m) i = fsuc (right-index m i)

shift-left : {m n : ℕ} → EitherFin m n → EitherFin (suc m) n
shift-left (in-left i) = in-left (fsuc i)
shift-left (in-right i) = in-right i

split : (m : ℕ) {n : ℕ} → Fin (m +ℕ n) → EitherFin m n
split zero i = in-right i
split (suc m) fzero = in-left fzero
split (suc m) (fsuc i) = shift-left (split m i)

merge : {m n : ℕ} → EitherFin m n → Fin (m +ℕ n)
merge (in-left i) = left-index i
merge {m} (in-right i) = right-index m i

split-left : {m n : ℕ} (i : Fin m) → split m (left-index {n = n} i) ≡ in-left i
split-left fzero = refl
split-left (fsuc i) = cong shift-left (split-left i)

split-right : (m : ℕ) {n : ℕ} (i : Fin n) → split m (right-index m i) ≡ in-right i
split-right zero i = refl
split-right (suc m) i = cong shift-left (split-right m i)

merge-split : (m : ℕ) {n : ℕ} (i : Fin (m +ℕ n)) → merge (split m i) ≡ i
merge-split zero i = refl
merge-split (suc m) fzero = refl
merge-split (suc m) (fsuc i) with split m i | merge-split m i
... | in-left j | p = cong fsuc p
... | in-right j | p = cong fsuc p

total : {n : ℕ} → (Fin n → ℕ) → ℕ
total {zero} sizes = zero
total {suc n} sizes = sizes fzero +ℕ total (sizes ∘ fsuc)

Index : {n : ℕ} → (Fin n → ℕ) → Set
Index {n} sizes = Σ (Fin n) (λ i → Fin (sizes i))

injectIndex : {n : ℕ} (sizes : Fin n → ℕ) (i : Fin n) → Fin (sizes i) → Fin (total sizes)
injectIndex {suc n} sizes fzero j = left-index j
injectIndex {suc n} sizes (fsuc i) j = right-index (sizes fzero) (injectIndex (sizes ∘ fsuc) i j)

shiftIndex : {n : ℕ} {sizes : Fin (suc n) → ℕ} → Index (sizes ∘ fsuc) → Index sizes
shiftIndex (i , j) = fsuc i , j

splitIndex : {n : ℕ} (sizes : Fin n → ℕ) → Fin (total sizes) → Index sizes
splitIndex {zero} sizes ()
splitIndex {suc n} sizes i with split (sizes fzero) i
... | in-left j = fzero , j
... | in-right j = shiftIndex (splitIndex (sizes ∘ fsuc) j)

split-inject : {n : ℕ} (sizes : Fin n → ℕ) (i : Fin n) (j : Fin (sizes i)) →
  splitIndex sizes (injectIndex sizes i j) ≡ (i , j)
split-inject {suc n} sizes fzero j rewrite split-left {n = total (sizes ∘ fsuc)} j = refl
split-inject {suc n} sizes (fsuc i) j rewrite split-right (sizes fzero) (injectIndex (sizes ∘ fsuc) i j) =
  cong shiftIndex (split-inject (sizes ∘ fsuc) i j)

inject-split : {n : ℕ} (sizes : Fin n → ℕ) (i : Fin (total sizes)) →
  injectIndex sizes (fst (splitIndex sizes i)) (snd (splitIndex sizes i)) ≡ i
inject-split {zero} sizes ()
inject-split {suc n} sizes i with split (sizes fzero) i | merge-split (sizes fzero) i
... | in-left j | p = p
... | in-right j | p with splitIndex (sizes ∘ fsuc) j | inject-split (sizes ∘ fsuc) j
... | a , b | r = trans (cong (right-index (sizes fzero)) r) p

assemble : {a : Level} {A : Set a} {n : ℕ} (sizes : Fin n → ℕ) →
  ((i : Fin n) → Fin (sizes i) → A) → Fin (total sizes) → A
assemble sizes f i = f (fst (splitIndex sizes i)) (snd (splitIndex sizes i))

assemble-inject : {a : Level} {A : Set a} {n : ℕ} (sizes : Fin n → ℕ)
  (f : (i : Fin n) → Fin (sizes i) → A) (i : Fin n) (j : Fin (sizes i)) →
  assemble sizes f (injectIndex sizes i j) ≡ f i j
assemble-inject sizes f i j = cong (λ z → f (fst z) (snd z)) (split-inject sizes i j)

assemble-restrict : {a : Level} {A : Set a} {n : ℕ} (sizes : Fin n → ℕ)
  (f : Fin (total sizes) → A) (i : Fin (total sizes)) →
  assemble sizes (λ j k → f (injectIndex sizes j k)) i ≡ f i
assemble-restrict sizes f i = cong f (inject-split sizes i)
