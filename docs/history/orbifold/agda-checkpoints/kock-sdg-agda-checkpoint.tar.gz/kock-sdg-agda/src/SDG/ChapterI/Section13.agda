{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section13 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Order
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section02 as S2
import SDG.ChapterI.Section02Exercises as E2

module Setup {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) where
  open Intervals A O public
  module On (a b : R) = Local.Calculus A K (intervalDomain a b)
  module Unit = On 0r 1r

  -- Exactly the source's axiom on [0,1]. Other intervals and all integral
  -- identities are derived below or in Section13Intervals.
  record Integration : Set (lsuc ℓ) where
    field
      primitiveOf : (UnitInterval → R) → UnitInterval → R
      primitive-derivative : (f : UnitInterval → R) (t : UnitInterval) → Unit.derivative (primitiveOf f) t ≡ f t
      primitive-zero : (f : UnitInterval → R) → primitiveOf f zero-point ≡ 0r
      primitive-unique : (f g : UnitInterval → R) →
        ((t : UnitInterval) → Unit.derivative g t ≡ f t) → g zero-point ≡ 0r →
        (t : UnitInterval) → g t ≡ primitiveOf f t

module Results {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : Setup.Integration A K O) where
  open Setup A K O public
  open Integration J public
  open Infinitesimals A
  open E2.DifferenceAlgebra A using (subtract-zero-implies-equal)

  integral : (UnitInterval → R) → R
  integral f = primitiveOf f one-point

  primitive-cong : (f g : UnitInterval → R) → ((t : UnitInterval) → f t ≡ g t) →
    (t : UnitInterval) → primitiveOf f t ≡ primitiveOf g t
  primitive-cong f g p = primitive-unique g (primitiveOf f)
    (λ t → trans (primitive-derivative f t) (p t)) (primitive-zero f)

  primitive-add : (f g : UnitInterval → R) (t : UnitInterval) →
    primitiveOf (λ s → f s + g s) t ≡ primitiveOf f t + primitiveOf g t
  primitive-add f g t = sym (primitive-unique (λ s → f s + g s)
    (λ s → primitiveOf f s + primitiveOf g s)
    (λ s → trans (Unit.derivative-add (primitiveOf f) (primitiveOf g) s)
      (cong₂ _+_ (primitive-derivative f s) (primitive-derivative g s)))
    (trans (cong₂ _+_ (primitive-zero f) (primitive-zero g)) (+-identityˡ 0r)) t)

  primitive-scale : (r : R) (f : UnitInterval → R) (t : UnitInterval) →
    primitiveOf (λ s → r * f s) t ≡ r * primitiveOf f t
  primitive-scale r f t = sym (primitive-unique (λ s → r * f s) (λ s → r * primitiveOf f s)
    (λ s → trans (Unit.derivative-scale r (primitiveOf f) s) (cong (r *_) (primitive-derivative f s)))
    (trans (cong (r *_) (primitive-zero f)) (*-zeroʳ r)) t)

  primitive-neg : (f : UnitInterval → R) (t : UnitInterval) →
    primitiveOf (λ s → - f s) t ≡ (- primitiveOf f t)
  primitive-neg f t = sym (primitive-unique (λ s → - f s) (λ s → - primitiveOf f s)
    (λ s → trans (Unit.derivative-neg (primitiveOf f) s) (cong -_ (primitive-derivative f s)))
    (trans (cong -_ (primitive-zero f)) neg-zero) t)

  primitive-of-zero : (t : UnitInterval) → primitiveOf (λ _ → 0r) t ≡ 0r
  primitive-of-zero t = sym (primitive-unique (λ _ → 0r) (λ _ → 0r)
    (Unit.derivative-constant 0r) refl t)

  primitive-constant : (r : R) (t : UnitInterval) → primitiveOf (λ _ → r) t ≡ r * coordinate t
  primitive-constant r t = sym (primitive-unique (λ _ → r) (λ s → r * coordinate s)
    (λ s → trans (Unit.derivative-scale r coordinate s)
      (trans (cong (r *_) (Unit.derivative-coordinate s)) (*-identityʳ r))) (*-zeroʳ r) t)

  integral-cong : (f g : UnitInterval → R) → ((t : UnitInterval) → f t ≡ g t) → integral f ≡ integral g
  integral-cong f g p = primitive-cong f g p one-point

  integral-add : (f g : UnitInterval → R) → integral (λ t → f t + g t) ≡ integral f + integral g
  integral-add f g = primitive-add f g one-point

  integral-scale : (r : R) (f : UnitInterval → R) → integral (λ t → r * f t) ≡ r * integral f
  integral-scale r f = primitive-scale r f one-point

  integral-neg : (f : UnitInterval → R) → integral (λ t → - f t) ≡ (- integral f)
  integral-neg f = primitive-neg f one-point

  integral-sub : (f g : UnitInterval → R) → integral (λ t → f t - g t) ≡ integral f - integral g
  integral-sub f g = trans (integral-add f (λ t → - g t)) (cong (integral f +_) (integral-neg g))

  integral-zero : integral (λ _ → 0r) ≡ 0r
  integral-zero = primitive-of-zero one-point

  integral-constant : (r : R) → integral (λ _ → r) ≡ r
  integral-constant r = trans (primitive-constant r one-point) (*-identityʳ r)

  -- The normalized primitiveOf of a derivative is explicitly h-h(0).
  primitive-of-derivative : (h : UnitInterval → R) (t : UnitInterval) →
    primitiveOf (Unit.derivative h) t ≡ h t - h zero-point
  primitive-of-derivative h t = sym (primitive-unique (Unit.derivative h)
    (λ s → h s - h zero-point)
    (λ s → trans (Unit.derivative-add h (λ _ → - h zero-point) s)
      (trans (cong (Unit.derivative h s +_) (Unit.derivative-constant (- h zero-point) s))
        (+-identityʳ (Unit.derivative h s)))) (+-inverseʳ (h zero-point)) t)

  -- Equation (13.3), the fundamental theorem on the unit interval.
  integral-derivative : (h : UnitInterval → R) → integral (Unit.derivative h) ≡ h one-point - h zero-point
  integral-derivative h = primitive-of-derivative h one-point

  zero-derivative-constant : (h : UnitInterval → R) →
    ((t : UnitInterval) → Unit.derivative h t ≡ 0r) → (t : UnitInterval) → h t ≡ h zero-point
  zero-derivative-constant h p t = subtract-zero-implies-equal (h t) (h zero-point)
    (trans (sym (primitive-of-derivative h t))
      (trans (primitive-cong (Unit.derivative h) (λ _ → 0r) p t) (primitive-of-zero t)))

  integration-by-parts : (f g : UnitInterval → R) →
    integral (λ t → f t * Unit.derivative g t) + integral (λ t → g t * Unit.derivative f t) ≡
    (f one-point * g one-point) - (f zero-point * g zero-point)
  integration-by-parts f g = trans
    (sym (integral-add (λ t → f t * Unit.derivative g t) (λ t → g t * Unit.derivative f t)))
    (trans (integral-cong _ _ (λ t → sym (Unit.derivative-product f g t)))
      (integral-derivative (λ t → f t * g t)))

  module Parameters (U : Local.StableDomain A) where
    module C = Local.Calculus A K U

    -- Differentiation under the integral follows from proved linearity,
    -- using first-order Taylor uniformly in the integration variable.
    differentiate-integral : (f : C.Carrier → UnitInterval → R) (x : C.Carrier) →
      C.derivative (λ y → integral (f y)) x ≡ integral (λ t → C.derivative (λ y → f y t) x)
    differentiate-integral f x = C.derivative-unique (λ y → integral (f y)) x
      (integral (λ t → C.derivative (λ y → f y t) x)) (λ d →
        trans (integral-cong (f (C.shift x d))
          (λ t → f x t + value d * C.derivative (λ y → f y t) x)
          (λ t → C.taylor (λ y → f y t) x d))
          (trans (integral-add (f x) (λ t → value d * C.derivative (λ y → f y t) x))
            (cong (integral (f x) +_) (integral-scale (value d) (λ t → C.derivative (λ y → f y t) x)))))

    differentiate-primitive : (f : C.Carrier → UnitInterval → R) (x : C.Carrier) (t : UnitInterval) →
      C.derivative (λ y → primitiveOf (f y) t) x ≡ primitiveOf (λ s → C.derivative (λ y → f y s) x) t
    differentiate-primitive f x t = C.derivative-unique (λ y → primitiveOf (f y) t) x
      (primitiveOf (λ s → C.derivative (λ y → f y s) x) t) (λ d →
        trans (primitive-cong (f (C.shift x d))
          (λ s → f x s + value d * C.derivative (λ y → f y s) x)
          (λ s → C.taylor (λ y → f y s) x d) t)
          (trans (primitive-add (f x) (λ s → value d * C.derivative (λ y → f y s) x) t)
            (cong (primitiveOf (f x) t +_)
              (primitive-scale (value d) (λ s → C.derivative (λ y → f y s) x) t))))

  affine-derivative : (x y : R) (t : UnitInterval) →
    Unit.derivative (λ s → blend x y (coordinate s)) t ≡ y - x
  affine-derivative x y t = Unit.derivative-unique (λ s → blend x y (coordinate s)) t (y - x)
    (λ d → trans (cong (x +_) (distribʳ (coordinate t) (value d) (y - x)))
      (sym (+-assoc x (coordinate t * (y - x)) (value d * (y - x)))))

  path-derivative : {a b : R} (x y : Interval a b) (t : UnitInterval) →
    Unit.derivative (coordinate ∘ path x y) t ≡ coordinate y - coordinate x
  path-derivative x y = affine-derivative (coordinate x) (coordinate y)

  -- Proposition I.13.1. No ordering between x and y is required.
  hadamard : {a b : R} (f : Interval a b → R) (x y : Interval a b) →
    f y - f x ≡ (coordinate y - coordinate x) * integral (On.derivative a b f ∘ path x y)
  hadamard {a} {b} f x y =
    trans (sym (trans (integral-derivative (f ∘ path x y))
      (cong₂ _-_ (cong f (path-one x y)) (cong f (path-zero x y)))))
      (trans (integral-cong (Unit.derivative (f ∘ path x y))
        (λ t → (coordinate y - coordinate x) * On.derivative a b f (path x y t))
        (λ t → trans (Local.Chain.derivative-chain A K (intervalDomain a b) (intervalDomain 0r 1r) f (path x y) t)
          (trans (cong (On.derivative a b f (path x y t) *_) (path-derivative x y t))
            (*-comm (On.derivative a b f (path x y t)) (coordinate y - coordinate x)))))
        (integral-scale (coordinate y - coordinate x) (On.derivative a b f ∘ path x y)))

  global-hadamard : (f : R → R) (x y : R) →
    f y - f x ≡ (y - x) * integral (λ t → S2.Results.derivative A K f (blend x y (coordinate t)))
  global-hadamard f x y =
    trans (sym (trans (integral-derivative (λ t → f (blend x y (coordinate t))))
      (cong₂ _-_ (cong f (blend-one x y)) (cong f (blend-zero x y)))))
      (trans (integral-cong (Unit.derivative (λ t → f (blend x y (coordinate t))))
        (λ t → (y - x) * S2.Results.derivative A K f (blend x y (coordinate t)))
        (λ t → trans (Local.Chain.derivative-chain A K (Local.wholeLine A) (intervalDomain 0r 1r)
          f (λ s → blend x y (coordinate s)) t)
          (trans (cong (S2.Results.derivative A K f (blend x y (coordinate t)) *_) (affine-derivative x y t))
            (*-comm (S2.Results.derivative A K f (blend x y (coordinate t))) (y - x)))))
        (integral-scale (y - x) (λ t → S2.Results.derivative A K f (blend x y (coordinate t)))))

  -- Exercise I.13.1, with the argument order used in formula (13.8).
  dividedDifference : (R → R) → R → R → R
  dividedDifference f x y = integral (λ t → S2.Results.derivative A K f (blend y x (coordinate t)))

  divided-difference-equation : (f : R → R) (x y : R) → f x - f y ≡ (x - y) * dividedDifference f x y
  divided-difference-equation f x y = global-hadamard f y x
