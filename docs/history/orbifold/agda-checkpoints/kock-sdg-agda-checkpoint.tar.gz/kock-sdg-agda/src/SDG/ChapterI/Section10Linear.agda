{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section10Linear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section10 as S10

-- Theorem 10.3(ii). The key map on a tangent fiber is homogeneous;
-- Proposition 10.2 then proves its additivity. No infinitesimal-linearity
-- assumption on the target module is smuggled into vector KL.
module Linearity {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (W : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A W)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M) where
  open ModuleLemmas A W
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL KV
  open S7.Basics A setR
  open S8.Basics A setR
  open S10.Calculus A K setR W KV
  open S8M.Fields A setR ext0 ext M setM IL using (field-add)
  module T = S7L.Construction A setR ext0 M IL

  evaluate-tangent : (f : M → V) {m : M} → Tangent M m → V
  evaluate-tangent f t = slopeV (λ d → f (curve t d))

  evaluate-speed : (f : M → V) {m : M} (r : R) (t : Tangent M m) →
    evaluate-tangent f (speed r t) ≡ r • evaluate-tangent f t
  evaluate-speed f r t = slope-reparameterized (λ d → f (curve t d)) r

  evaluate-add : (f : M → V) {m : M} (t u : Tangent M m) →
    evaluate-tangent f (T.add t u) ≡ evaluate-tangent f t +v evaluate-tangent f u
  evaluate-add f {m} =
    S10.Homogeneity.homogeneous-add A K setR (T.fiberModule ext setM m) W KV
      (evaluate-tangent f) (λ d t → evaluate-speed f (value d) t)

  added-field-derivative : (X Y : VectorField M) (f : M → V) (m : M) →
    directional (field-add X Y) f m ≡ directional X f m +v directional Y f m
  added-field-derivative X Y f m = evaluate-add f (field-section X m) (field-section Y m)

