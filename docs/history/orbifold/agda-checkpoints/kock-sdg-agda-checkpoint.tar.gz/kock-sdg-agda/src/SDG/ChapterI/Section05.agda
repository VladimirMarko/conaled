{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section05 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tabulate; map;
   lookup-map; lookup-tabulate; vec-ext; finToNat)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section02 as S2

-- Section I.5.1: a rectangular tensor of polynomial coefficients.
-- The carrier-set assumption makes DK 0 the actual singleton subobject.
-- It is not a global UIP axiom and is explicit at every use of this module.
module Rectangular {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open HigherKockLawvere H
  open PolynomialConsequences H

  dk-path : {k : ℕ} {d e : DK k} → valueK d ≡ valueK e → d ≡ e
  dk-path {d = nilpotent x p} {nilpotent .x q} refl =
    cong (nilpotent x) (setR _ _ p q)

  zero-order-contractible : (d : DK zero) → d ≡ zeroK zero
  zero-order-contractible d = dk-path
    (trans (sym (power-one (valueK d))) (nilpotence d))

  -- Extend the genuine positive-order axiom to the elementary k=0 case.
  coefficients-all : (k : ℕ) → (DK k → R) → Vec R (suc k)
  coefficients-all zero g = g (zeroK zero) ∷ []
  coefficients-all (suc n) g = coefficients n g

  reconstruction-all : (k : ℕ) (g : DK k → R) (d : DK k) →
    g d ≡ eval (coefficients-all k g) (valueK d)
  reconstruction-all zero g d =
    trans (cong g (zero-order-contractible d))
      (sym (eval-constant (g (zeroK zero)) (valueK d)))
  reconstruction-all (suc n) = reconstruction n

  uniqueness-all : (k : ℕ) (g : DK k → R) (as : Vec R (suc k)) →
    ((d : DK k) → g d ≡ eval as (valueK d)) → coefficients-all k g ≡ as
  uniqueness-all zero g (a ∷ []) p =
    cong (_∷ []) (trans (p (zeroK zero)) (eval-constant a 0r))
  uniqueness-all (suc n) = uniqueness n

  coefficients-all-eval : (k : ℕ) (as : Vec R (suc k)) →
    coefficients-all k (λ d → eval as (valueK d)) ≡ as
  coefficients-all-eval k as = uniqueness-all k (λ d → eval as (valueK d)) as (λ d → refl)

  coefficient-extensionality-all : (k : ℕ) (as bs : Vec R (suc k)) →
    ((d : DK k) → eval as (valueK d) ≡ eval bs (valueK d)) → as ≡ bs
  coefficient-extensionality-all k as bs p =
    trans (sym (coefficients-all-eval k as))
      (uniqueness-all k (λ d → eval as (valueK d)) bs p)

  data One : Set ℓ where
    one : One

  Points : {n : ℕ} → Vec ℕ n → Set ℓ
  Points [] = One
  Points (k ∷ ks) = DK k × Points ks

  Coefficients : {n : ℕ} → Vec ℕ n → Set ℓ
  Coefficients [] = R
  Coefficients (k ∷ ks) = Vec (Coefficients ks) (suc k)

  evaluate : {n : ℕ} {ks : Vec ℕ n} → Coefficients ks → Points ks → R
  evaluate {ks = []} a one = a
  evaluate {ks = k ∷ ks} as (d , ds) =
    eval (map (λ a → evaluate {ks = ks} a ds) as) (valueK d)

  coefficient-tensor : {n : ℕ} {ks : Vec ℕ n} →
    (Points ks → R) → Coefficients ks
  coefficient-tensor {ks = []} f = f one
  coefficient-tensor {ks = k ∷ ks} f =
    tabulate (λ i → coefficient-tensor {ks = ks}
      (λ ds → lookup (coefficients-all k (λ d → f (d , ds))) i))

  reconstruction-tensor : {n : ℕ} {ks : Vec ℕ n}
    (f : Points ks → R) (ds : Points ks) → f ds ≡ evaluate (coefficient-tensor f) ds
  reconstruction-tensor {ks = []} f one = refl
  reconstruction-tensor {ks = k ∷ ks} f (d , ds) =
    trans (reconstruction-all k (λ e → f (e , ds)) d)
      (cong (λ as → eval as (valueK d)) (sym values))
    where
    values :
      map (λ a → evaluate {ks = ks} a ds) (coefficient-tensor f) ≡
      coefficients-all k (λ e → f (e , ds))
    values = vec-ext (λ i →
      trans (lookup-map (λ a → evaluate {ks = ks} a ds) (coefficient-tensor f) i)
        (trans
          (cong (λ a → evaluate {ks = ks} a ds)
            (lookup-tabulate
              (λ j → coefficient-tensor {ks = ks}
                (λ es → lookup (coefficients-all k (λ e → f (e , es))) j)) i))
          (sym (reconstruction-tensor {ks = ks}
            (λ es → lookup (coefficients-all k (λ e → f (e , es))) i) ds))))

  evaluate-injective : {n : ℕ} {ks : Vec ℕ n} (as bs : Coefficients ks) →
    ((ds : Points ks) → evaluate as ds ≡ evaluate bs ds) → as ≡ bs
  evaluate-injective {ks = []} a b p = p one
  evaluate-injective {ks = k ∷ ks} as bs p = vec-ext (λ i →
    evaluate-injective {ks = ks} (lookup as i) (lookup bs i) (λ ds →
      trans (sym (lookup-map (λ a → evaluate {ks = ks} a ds) as i))
        (trans
          (cong (λ cs → lookup cs i)
            (coefficient-extensionality-all k
              (map (λ a → evaluate {ks = ks} a ds) as)
              (map (λ b → evaluate {ks = ks} b ds) bs)
              (λ d → p (d , ds))))
          (lookup-map (λ b → evaluate {ks = ks} b ds) bs i))))

  -- Proposition I.5.1, all dimensions and all nonnegative coordinate bounds.
  uniqueness-tensor : {n : ℕ} {ks : Vec ℕ n}
    (f : Points ks → R) (as : Coefficients ks) →
    ((ds : Points ks) → f ds ≡ evaluate as ds) → coefficient-tensor f ≡ as
  uniqueness-tensor f as p = evaluate-injective (coefficient-tensor f) as
    (λ ds → trans (sym (reconstruction-tensor f ds)) (p ds))

  recover-tensor : {n : ℕ} {ks : Vec ℕ n} (as : Coefficients ks) →
    coefficient-tensor {ks = ks} (evaluate {ks = ks} as) ≡ as
  recover-tensor {ks = ks} as = uniqueness-tensor {ks = ks}
    (evaluate {ks = ks} as) as (λ ds → refl)

-- Theorem I.5.2 for maps defined on the whole affine space. A separate
-- local-domain theorem is required when no global extension is supplied.
module Taylor {ℓ : Level} (A : CRing ℓ)
  (K : SDG.Axiom.Infinitesimals.KockLawvere A)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open Rectangular A H setR
  open S3.GeneralTaylor A K H Q
  open S2.Results A K using (derivative; iterate; derivative-cong; derivative-scale)

  translate : {n : ℕ} {ks : Vec ℕ n} → Vec R n → Points ks → Vec R n
  translate {ks = []} [] one = []
  translate {ks = k ∷ ks} (x ∷ xs) (d , ds) = (x + valueK d) ∷ translate xs ds

  taylor-tensor : {n : ℕ} (ks : Vec ℕ n) → (Vec R n → R) → Vec R n → Coefficients ks
  taylor-tensor [] f [] = f []
  taylor-tensor (k ∷ ks) f (x ∷ xs) = tabulate (λ i →
    taylor-tensor ks
      (λ ys → inverseFactorial (finToNat i) *
        iterate (finToNat i) (λ t → f (t ∷ ys)) x) xs)

  taylor-rectangle : {n : ℕ} (ks : Vec ℕ n)
    (f : Vec R n → R) (xs : Vec R n) (ds : Points ks) →
    f (translate xs ds) ≡ evaluate (taylor-tensor ks f xs) ds
  taylor-rectangle [] f [] one = refl
  taylor-rectangle (k ∷ ks) f (x ∷ xs) (d , ds) =
    trans (taylor-all-orders k (λ t → f (t ∷ translate xs ds)) x d)
      (cong (λ as → eval as (valueK d)) (sym values))
    where
    coeff : Fin (suc k) → Vec R _ → R
    coeff i ys = inverseFactorial (finToNat i) *
      iterate (finToNat i) (λ t → f (t ∷ ys)) x
    values :
      map (λ a → evaluate {ks = ks} a ds) (taylor-tensor (k ∷ ks) f (x ∷ xs)) ≡
      taylorCoefficients k (λ t → f (t ∷ translate xs ds)) x
    values = vec-ext (λ i →
      trans (lookup-map (λ a → evaluate {ks = ks} a ds)
        (taylor-tensor (k ∷ ks) f (x ∷ xs)) i)
        (trans
          (cong (λ a → evaluate {ks = ks} a ds)
            (lookup-tabulate (λ j → taylor-tensor ks (coeff j) xs) i))
          (trans (sym (taylor-rectangle ks (coeff i) xs ds))
            (sym (lookup-tabulate
              (λ j → inverseFactorial (finToNat j) *
                iterate (finToNat j) (λ t → f (t ∷ translate xs ds)) x) i)))))

  Indices : {n : ℕ} → Vec ℕ n → Set
  Indices [] = ⊤
  Indices (k ∷ ks) = Fin (suc k) × Indices ks

  degrees : {n : ℕ} {ks : Vec ℕ n} → Indices ks → Vec ℕ n
  degrees {ks = []} tt = []
  degrees {ks = k ∷ ks} (i , is) = finToNat i ∷ degrees {ks = ks} is

  lookup-tensor : {n : ℕ} {ks : Vec ℕ n} → Coefficients ks → Indices ks → R
  lookup-tensor {ks = []} a tt = a
  lookup-tensor {ks = k ∷ ks} as (i , is) = lookup-tensor {ks = ks} (lookup as i) is

  mixed-derivative : {n : ℕ} → Vec ℕ n → (Vec R n → R) → Vec R n → R
  mixed-derivative [] f [] = f []
  mixed-derivative (i ∷ is) f (x ∷ xs) =
    mixed-derivative is (λ ys → iterate i (λ t → f (t ∷ ys)) x) xs

  inverse-multifactorial : {n : ℕ} → Vec ℕ n → R
  inverse-multifactorial [] = 1r
  inverse-multifactorial (i ∷ is) = inverseFactorial i * inverse-multifactorial is

  iterate-cong : (n : ℕ) (f g : R → R) →
    ((x : R) → f x ≡ g x) → (x : R) → iterate n f x ≡ iterate n g x
  iterate-cong zero f g p x = p x
  iterate-cong (suc n) f g p x =
    derivative-cong (iterate n f) (iterate n g) (iterate-cong n f g p) x

  iterate-scale : (n : ℕ) (r : R) (f : R → R) (x : R) →
    iterate n (λ t → r * f t) x ≡ r * iterate n f x
  iterate-scale zero r f x = refl
  iterate-scale (suc n) r f x =
    trans (derivative-cong (iterate n (λ t → r * f t))
      (λ t → r * iterate n f t) (iterate-scale n r f) x)
      (derivative-scale r (iterate n f) x)

  mixed-cong : {n : ℕ} (is : Vec ℕ n) (f g : Vec R n → R) →
    ((xs : Vec R n) → f xs ≡ g xs) → (xs : Vec R n) →
    mixed-derivative is f xs ≡ mixed-derivative is g xs
  mixed-cong [] f g p [] = p []
  mixed-cong (i ∷ is) f g p (x ∷ xs) =
    mixed-cong is
      (λ ys → iterate i (λ t → f (t ∷ ys)) x)
      (λ ys → iterate i (λ t → g (t ∷ ys)) x)
      (λ ys → iterate-cong i (λ t → f (t ∷ ys))
        (λ t → g (t ∷ ys)) (λ t → p (t ∷ ys)) x) xs

  mixed-scale : {n : ℕ} (is : Vec ℕ n) (r : R) (f : Vec R n → R) (xs : Vec R n) →
    mixed-derivative is (λ ys → r * f ys) xs ≡ r * mixed-derivative is f xs
  mixed-scale [] r f [] = refl
  mixed-scale (i ∷ is) r f (x ∷ xs) =
    trans
      (mixed-cong is
        (λ ys → iterate i (λ t → r * f (t ∷ ys)) x)
        (λ ys → r * iterate i (λ t → f (t ∷ ys)) x)
        (λ ys → iterate-scale i r (λ t → f (t ∷ ys)) x) xs)
      (mixed-scale is r (λ ys → iterate i (λ t → f (t ∷ ys)) x) xs)

  -- The recursive tensor really has the familiar partial^alpha f / alpha!
  -- coefficients, rather than merely unspecified polynomial coefficients.
  taylor-coefficient : {n : ℕ} (ks : Vec ℕ n) (f : Vec R n → R) (xs : Vec R n)
    (is : Indices ks) →
    lookup-tensor {ks = ks} (taylor-tensor ks f xs) is ≡
      inverse-multifactorial (degrees {ks = ks} is) *
      mixed-derivative (degrees {ks = ks} is) f xs
  taylor-coefficient [] f [] tt = sym (*-identityˡ (f []))
  taylor-coefficient (k ∷ ks) f (x ∷ xs) (i , is) =
    trans
      (cong (λ a → lookup-tensor {ks = ks} a is)
        (lookup-tabulate
          (λ j → taylor-tensor ks
            (λ ys → inverseFactorial (finToNat j) *
              iterate (finToNat j) (λ t → f (t ∷ ys)) x) xs) i))
      (trans
        (taylor-coefficient ks
          (λ ys → inverseFactorial (finToNat i) *
            iterate (finToNat i) (λ t → f (t ∷ ys)) x) xs is)
        (trans
          (cong (inverse-multifactorial (degrees {ks = ks} is) *_)
            (mixed-scale (degrees {ks = ks} is) (inverseFactorial (finToNat i))
              (λ ys → iterate (finToNat i) (λ t → f (t ∷ ys)) x) xs))
          (trans
            (*-swap (inverse-multifactorial (degrees {ks = ks} is))
              (inverseFactorial (finToNat i))
              (mixed-derivative (degrees {ks = ks} is)
                (λ ys → iterate (finToNat i) (λ t → f (t ∷ ys)) x) xs))
            (sym (*-assoc (inverseFactorial (finToNat i))
              (inverse-multifactorial (degrees {ks = ks} is))
              (mixed-derivative (degrees {ks = ks} is)
                (λ ys → iterate (finToNat i) (λ t → f (t ∷ ys)) x) xs))))))


