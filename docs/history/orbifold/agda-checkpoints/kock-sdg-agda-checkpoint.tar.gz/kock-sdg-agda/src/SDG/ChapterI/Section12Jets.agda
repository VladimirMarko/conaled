{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12Jets where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Algebras
import SDG.Algebra.Derivations as Der
open import SDG.Finite using (Fin; Vec; []; _∷_; map; zipWith; replicate;
  lookup; lookup-map; lookup-zipWith; lookup-replicate; vec-ext)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section05 as S5
import SDG.ChapterI.Section07Linear as S7L
import SDG.Schemes.Reflexivity as Ref

-- Exercise I.12.3. The k+1 functionals are the actual coefficients of
-- f ∘ t. Their linearity is proved from uniqueness of KL polynomials.
module JetObservations {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (setR : isSet (CRing.R A)) (ext : FunExt ℓ ℓ) (M : Set ℓ) where
  open S3.HigherInfinitesimals A
  open S5.Rectangular A H setR using (coefficients-all; reconstruction-all; uniqueness-all)
  open Ref.Reflexivity A ext setR
  open S7L.ModuleMap

  Functions : RAlgebra A ℓ
  Functions = functionAlgebra A M ext

  FunctionModule : RModule A ℓ
  FunctionModule = Der.algebraModule A (ring Functions) (unit Functions)

  LinearFunctional : Set ℓ
  LinearFunctional = S7L.ModuleMap A FunctionModule (scalarModule A)

  private
    eval-zero-vector : (n : ℕ) (x : R) → eval (replicate {n = n} 0r) x ≡ 0r
    eval-zero-vector zero x = refl
    eval-zero-vector (suc n) x =
      trans (cong (0r +_) (trans (cong (x *_) (eval-zero-vector n x)) (*-zeroʳ x)))
        (+-identityˡ 0r)

  coefficients-zero : (k : ℕ) → coefficients-all k (λ _ → 0r) ≡ replicate 0r
  coefficients-zero k = uniqueness-all k (λ _ → 0r) (replicate 0r)
    (λ d → sym (eval-zero-vector (suc k) (valueK d)))

  coefficients-add : (k : ℕ) (f g : DK k → R) →
    coefficients-all k (λ d → f d + g d) ≡ zipWith _+_ (coefficients-all k f) (coefficients-all k g)
  coefficients-add k f g = uniqueness-all k (λ d → f d + g d)
    (zipWith _+_ (coefficients-all k f) (coefficients-all k g))
    (λ d → trans (cong₂ _+_ (reconstruction-all k f d) (reconstruction-all k g d))
      (sym (eval-add (coefficients-all k f) (coefficients-all k g) (valueK d))))

  coefficients-scale : (k : ℕ) (r : R) (f : DK k → R) →
    coefficients-all k (λ d → r * f d) ≡ map (r *_) (coefficients-all k f)
  coefficients-scale k r f = uniqueness-all k (λ d → r * f d)
    (map (r *_) (coefficients-all k f))
    (λ d → trans (cong (r *_) (reconstruction-all k f d))
      (sym (eval-scale r (coefficients-all k f) (valueK d))))

  coefficient-functional : (k : ℕ) → (DK k → M) → Fin (suc k) → LinearFunctional
  apply (coefficient-functional k t i) f = lookup (coefficients-all k (f ∘ t)) i
  preserves-zero (coefficient-functional k t i) =
    trans (cong (λ as → lookup as i) (coefficients-zero k)) (lookup-replicate 0r i)
  preserves-add (coefficient-functional k t i) f g =
    trans (cong (λ as → lookup as i) (coefficients-add k (f ∘ t) (g ∘ t)))
      (lookup-zipWith _+_ (coefficients-all k (f ∘ t)) (coefficients-all k (g ∘ t)) i)
  preserves-scale (coefficient-functional k t i) r f =
    trans (cong (λ as → lookup as i) (coefficients-scale k r (f ∘ t)))
      (lookup-map (r *_) (coefficients-all k (f ∘ t)) i)

  observations : (k : ℕ) → (DK k → M) → Fin (suc k) → LinearFunctional
  observations = coefficient-functional

  observations-injective : Reflexive M → (k : ℕ) (t u : DK k → M) →
    observations k t ≡ observations k u → t ≡ u
  observations-injective reflexive k t u p = ext (λ d →
    points-detected reflexive (t d) (u d) (λ f →
      trans (reconstruction-all k (f ∘ t) d)
        (trans (cong (λ as → eval as (valueK d))
          (vec-ext {xs = coefficients-all k (f ∘ t)} {ys = coefficients-all k (f ∘ u)}
            (λ i → cong (λ fs → apply (fs i) f) p)))
          (sym (reconstruction-all k (f ∘ u) d)))))
