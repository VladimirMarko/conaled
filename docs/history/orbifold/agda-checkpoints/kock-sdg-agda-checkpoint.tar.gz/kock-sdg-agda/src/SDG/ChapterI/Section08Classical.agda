{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08Classical where

open import SDG.Prelude
open import SDG.Algebra

data OrderComparison {ℓ : Level} {A : Set ℓ} (_<_ : A → A → Set ℓ)
  (x y : A) : Set ℓ where
  less : x < y → OrderComparison _<_ x y
  equal : x ≡ y → OrderComparison _<_ x y
  greater : y < x → OrderComparison _<_ x y

-- Exercise I.8.7 is explicitly classical. This ordered field is a separate
-- parameter; no ordering or field structure is imposed on the SDG ring R.
-- Density is exposed as a standard order property, so the analytic proof
-- needs neither a chosen construction of the real numbers nor completeness.
record ClassicalField (ℓ : Level) : Set (lsuc ℓ) where
  field
    ring : CRing ℓ
  open RingLemmas ring public
  field
    setR : isSet R
    _<_ : R → R → Set ℓ
    <-prop : (x y : R) → isProp (x < y)
    compare : (x y : R) → OrderComparison _<_ x y
    <-irrefl : (x : R) → ¬ (x < x)
    <-trans : {x y z : R} → x < y → y < z → x < z
    <-translate : {x y : R} → x < y → (z : R) → (x + z) < (y + z)
    positive-product : {x y : R} → 0r < x → 0r < y → 0r < (x * y)
    positive-one : 0r < 1r
    dense : {x y : R} → x < y → Σ R (λ z → (x < z) × (z < y))
    inverse : (x : R) → x ≢ 0r → R
    inverse-law : (x : R) (nonzero : x ≢ 0r) → x * inverse x nonzero ≡ 1r

module Interval {ℓ : Level} (F : ClassicalField ℓ)
  (radius : ClassicalField.R F) (positive : ClassicalField._<_ F (ClassicalField.0r F) radius) where
  open ClassicalField F

  negative-radius : (- radius) < 0r
  negative-radius = subst₂ _<_ (+-identityˡ (- radius)) (+-inverseʳ radius)
    (<-translate positive (- radius))

  Point : Set ℓ
  Point = Σ R (λ t → ((- radius) < t) × (t < radius))

  time : Point → R
  time = fst

  origin : Point
  origin = 0r , negative-radius , positive

  zero-not-one : 0r ≢ 1r
  zero-not-one p = <-irrefl 0r (subst (0r <_) (sym p) positive-one)

  positive-nonzero : {t : R} → 0r < t → t ≢ 0r
  positive-nonzero p q = <-irrefl 0r (subst (0r <_) q p)

  interior-positive : Σ Point (λ t → 0r < time t)
  interior-positive with dense positive
  ... | t , left , right = (t , <-trans negative-radius left , right) , left

  -- Ordinary differentiation is a relation on interval functions. The
  -- rules below are the usual constant, identity, sum and product rules.
  -- The one analytic uniqueness premise is the general zero-initial-data
  -- uniqueness theorem for homogeneous linear ODEs with differentiable
  -- coefficient. The Riccati blow-up statement is not an assumed field.
  record Calculus : Set (lsuc ℓ) where
    field
      HasDerivative : (Point → R) → (Point → R) → Set ℓ
      derivative-cong : {f g df dg : Point → R} →
        ((t : Point) → f t ≡ g t) → ((t : Point) → df t ≡ dg t) →
        HasDerivative f df → HasDerivative g dg
      constant : (c : R) → HasDerivative (λ _ → c) (λ _ → 0r)
      coordinate : HasDerivative time (λ _ → 1r)
      add : {f g df dg : Point → R} → HasDerivative f df → HasDerivative g dg →
        HasDerivative (λ t → f t + g t) (λ t → df t + dg t)
      negate : {f df : Point → R} → HasDerivative f df →
        HasDerivative (λ t → - f t) (λ t → - df t)
      product : {f g df dg : Point → R} → HasDerivative f df → HasDerivative g dg →
        HasDerivative (λ t → f t * g t) (λ t → (df t * g t) + (f t * dg t))
      linear-zero-unique : (a da z : Point → R) →
        HasDerivative a da → HasDerivative z (λ t → a t * z t) →
        z origin ≡ 0r → (t : Point) → z t ≡ 0r

  module Riccati (C : Calculus) where
    open Calculus C

    record Solution (x : R) : Set ℓ where
      field
        curve : Point → R
        initial : curve origin ≡ x
        equation : HasDerivative curve (λ t → curve t * curve t)
    open Solution public

    denominator : R → Point → R
    denominator x t = 1r - x * time t

    private
      denominator-derivative : (x : R) →
        HasDerivative (denominator x) (λ t → - x)
      denominator-derivative x = derivative-cong (λ t → refl)
        (λ t → trans (+-identityˡ (- ((0r * time t) + (x * 1r))))
          (cong -_ (trans (cong₂ _+_ (*-zeroˡ (time t)) (*-identityʳ x))
            (+-identityˡ x))))
        (add (constant 1r) (negate (product (constant x) coordinate)))

      denominator-origin : (x : R) → denominator x origin ≡ 1r
      denominator-origin x = trans (cong (λ z → 1r - z) (*-zeroʳ x))
        (trans (cong (1r +_) neg-zero) (+-identityʳ 1r))

      riccati-factor : (x q y : R) →
        ((- x) * y) + (q * (y * y)) ≡ y * ((q * y) - x)
      riccati-factor x q y = sym
        (trans (distribˡ y (q * y) (- x))
          (trans (cong₂ _+_ (*-swap y q y) (*-comm y (- x)))
            (+-comm (q * (y * y)) ((- x) * y))))

    defect : {x : R} → Solution x → Point → R
    defect {x} s t = (denominator x t * curve s t) - x

    defect-derivative : {x : R} (s : Solution x) →
      HasDerivative (defect s) (λ t → curve s t * defect s t)
    defect-derivative {x} s = derivative-cong (λ t → refl)
      (λ t → trans (cong (((- x) * curve s t) + (denominator x t * (curve s t * curve s t)) +_)
          neg-zero)
        (trans (+-identityʳ (((- x) * curve s t) + (denominator x t * (curve s t * curve s t))))
          (riccati-factor x (denominator x t) (curve s t))))
      (add (product (denominator-derivative x) (equation s)) (negate (constant x)))

    defect-origin : {x : R} (s : Solution x) → defect s origin ≡ 0r
    defect-origin {x} s =
      trans (cong (λ z → z - x) (cong₂ _*_ (denominator-origin x) (initial s)))
        (trans (cong (λ z → z - x) (*-identityˡ x)) (+-inverseʳ x))

    defect-zero : {x : R} (s : Solution x) (t : Point) → defect s t ≡ 0r
    defect-zero s = linear-zero-unique (curve s) (λ t → curve s t * curve s t)
      (defect s) (equation s) (defect-derivative s) (defect-origin s)

    solution-identity : {x : R} (s : Solution x) (t : Point) →
      denominator x t * curve s t ≡ x
    solution-identity {x} s t = +-cancelʳ (- x)
      (trans (defect-zero s t) (sym (+-inverseʳ x)))

    -- The familiar rational formula is derived wherever its denominator
    -- is nonzero; it is not supplied as an ODE axiom.
    solution-formula : {x : R} (s : Solution x) (t : Point)
      (nonzero : denominator x t ≢ 0r) →
      curve s t ≡ x * inverse (denominator x t) nonzero
    solution-formula {x} s t nonzero =
      trans (sym (*-identityˡ (curve s t)))
        (trans (cong (_* curve s t) (sym
          (trans (*-comm (inverse (denominator x t) nonzero) (denominator x t))
            (inverse-law (denominator x t) nonzero))))
          (trans (*-assoc (inverse (denominator x t) nonzero) (denominator x t) (curve s t))
            (trans (cong (inverse (denominator x t) nonzero *_) (solution-identity s t))
              (*-comm (inverse (denominator x t) nonzero) x))))

    no-solution-at-pole : (x : R) (t : Point) → x * time t ≡ 1r → ¬ Solution x
    no-solution-at-pole x t pole s = zero-not-one
      (trans (sym (*-zeroˡ (time t)))
        (trans (cong (_* time t) (sym x-zero)) pole))
      where
      denominator-zero : denominator x t ≡ 0r
      denominator-zero = trans (cong (λ z → 1r - z) pole) (+-inverseʳ 1r)

      x-zero : x ≡ 0r
      x-zero = trans (sym (solution-identity s t))
        (trans (cong (_* curve s t) denominator-zero) (*-zeroˡ (curve s t)))

    obstructed-initial-value : Σ R (λ x → ¬ Solution x)
    obstructed-initial-value with interior-positive
    ... | t , positive-time =
      inverse (time t) (positive-nonzero positive-time) ,
      no-solution-at-pole (inverse (time t) (positive-nonzero positive-time)) t
        (trans (*-comm (inverse (time t) (positive-nonzero positive-time)) (time t))
          (inverse-law (time t) (positive-nonzero positive-time)))

    no-common-interval : ¬ ((x : R) → Solution x)
    no-common-interval solutions = snd obstructed-initial-value (solutions (fst obstructed-initial-value))
