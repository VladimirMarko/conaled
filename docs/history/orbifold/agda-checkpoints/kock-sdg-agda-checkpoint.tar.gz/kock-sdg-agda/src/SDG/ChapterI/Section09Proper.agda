{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section09Proper where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; []; _∷_; lookup)
open import SDG.Infinitesimal.Jets
import SDG.Calculus.Slope as Slope
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section09 as S9

-- Exercise I.9.6. A proper field detects its infinitesimal parameter.
-- All equalities of fields below are pointwise; no function extensionality
-- or coordinates on the ambient space are needed for the criterion.
module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open Jets A
  open S7.Basics A setR using (d-path; negateD)
  open S8.Basics A setR
  module Flow = S8.Linear A setR IL
  module Lie = S9.Lie A K setR IL W
  open S4.Results A K using (productD)
  open Slope.Results A K using (slope-cong; slope-value)

  Proper : VectorField M → Set ℓ
  Proper X = (m : M) (d e : D) → run X m d ≡ run X m e → d ≡ e

  Neighbors : VectorField M → M → M → Set ℓ
  Neighbors X m n = Σ D (λ d → run X m d ≡ n)

  neighbor-parameter-unique : (X : VectorField M) → Proper X →
    (m n : M) (p q : Neighbors X m n) → fst p ≡ fst q
  neighbor-parameter-unique X proper m n p q = proper m (fst p) (fst q)
    (trans (snd p) (sym (snd q)))

  neighbors-prop : isSet M → (X : VectorField M) → Proper X →
    (m n : M) → isProp (Neighbors X m n)
  neighbors-prop setM X proper m n (d , p) (e , q) with proper m d e (trans p (sym q))
  ... | refl = cong (d ,_) (setM _ _ p q)

  PreservesNeighbors : VectorField M → VectorField M → Set ℓ
  PreservesNeighbors X Y = (e : D) (m n : M) → Neighbors X m n →
    Neighbors X (run Y m e) (run Y n e)

  Proportional : VectorField M → VectorField M → (M → R) → Set ℓ
  Proportional X Y ρ = (m : M) (d : D) →
    run (Lie.bracket X Y) m d ≡ run (scale-field ρ X) m d

  Admits : VectorField M → VectorField M → Set ℓ
  Admits X Y = Σ (M → R) (Proportional X Y)

  private
    pair : (d e : D) → value d * value e ≡ 0r → Jet1 2
    pair d e compatible = makeJet1 (value d ∷ value e ∷ []) proof
      where
      proof : (i j : Fin 2) →
        lookup (value d ∷ value e ∷ []) i * lookup (value d ∷ value e ∷ []) j ≡ 0r
      proof fzero fzero = square-zero d
      proof fzero (fsuc fzero) = compatible
      proof (fsuc fzero) fzero = trans (*-comm (value e) (value d)) compatible
      proof (fsuc fzero) (fsuc fzero) = square-zero e

  combine : (X : VectorField M) (m : M) (d e z : D) →
    value d * value e ≡ 0r → value d + value e ≡ value z →
    run X (run X m d) e ≡ run X m z
  combine X m d e z compatible total =
    trans (cong₂ (λ a b → run X (run X m a) b)
      (sym (d-path {d = Flow.first (pair d e compatible)} {e = d} refl))
      (sym (d-path {d = Flow.second (pair d e compatible)} {e = e} refl)))
      (trans (Flow.flow-law X m (pair d e compatible))
        (cong (run X m) (d-path
          (trans (cong (value d +_) (+-identityʳ (value e))) total))))

  compatible-commute : (X Y : VectorField M) (m : M) (d e : D) →
    value d * value e ≡ 0r →
    run Y (run X m d) e ≡ run X (run Y m e) d
  compatible-commute X Y m d e compatible =
    trans (cong₂ (λ a b → run Y (run X m a) b)
      (sym (d-path {d = Flow.first (pair d e compatible)} {e = d} refl))
      (sym (d-path {d = Flow.second (pair d e compatible)} {e = e} refl)))
      (trans (Flow.compatible-commute X Y m (pair d e compatible))
        (cong₂ (λ a b → run X (run Y m b) a)
          (d-path {d = Flow.first (pair d e compatible)} {e = d} refl)
          (d-path {d = Flow.second (pair d e compatible)} {e = e} refl)))

  correction : D → D → R → D
  correction d e r = scaleD (productD d e) r

  transported : D → D → R → D
  transported d e r = scaleD d (1r + value e * r)

  correction-annihilates-first : (d e : D) (r : R) → value (correction d e r) * value d ≡ 0r
  correction-annihilates-first d e r =
    trans (*-assoc (value d * value e) r (value d))
      (trans (cong ((value d * value e) *_) (*-comm r (value d)))
        (trans (*-shuffle (value d) (value e) (value d) r)
          (trans (cong (_* (value e * r)) (square-zero d)) (*-zeroˡ (value e * r)))))

  correction-annihilates-second : (d e : D) (r : R) → value (correction d e r) * value e ≡ 0r
  correction-annihilates-second d e r =
    trans (cong (λ z → (z * r) * value e) (*-comm (value d) (value e)))
      (correction-annihilates-first e d r)

  correction-sum : (d e : D) (r : R) → value (correction d e r) + value d ≡ value (transported d e r)
  correction-sum d e r =
    trans (+-comm (value (correction d e r)) (value d))
      (sym (trans (distribˡ (value d) 1r (value e * r))
        (cong₂ _+_ (*-identityʳ (value d)) (sym (*-assoc (value d) (value e) r)))))

  combine-correction : (X : VectorField M) (m : M) (d e : D) (r : R) →
    run X (run X m (correction d e r)) d ≡ run X m (transported d e r)
  combine-correction X m d e r = combine X m (correction d e r) d (transported d e r)
    (correction-annihilates-first d e r) (correction-sum d e r)

  TransportLaw : VectorField M → VectorField M → (M → R) → Set ℓ
  TransportLaw X Y ρ = (m : M) (d e : D) →
    run Y (run X m d) e ≡ run X (run Y m e) (transported d e (ρ m))

  commutator-recovery : (X Y : VectorField M) (m : M) (d e : D) →
    run X (run Y (Lie.commutator X Y m d e) e) d ≡ run Y (run X m d) e
  commutator-recovery X Y m d e =
    trans (cong (λ q → run X q d)
      (Flow.inverse-left Y (run X (run Y (run X m d) e) (negateD d)) e))
      (Flow.inverse-left X (run Y (run X m d) e) d)

  proportional-to-transport : (X Y : VectorField M) (ρ : M → R) →
    Proportional X Y ρ → TransportLaw X Y ρ
  proportional-to-transport X Y ρ proportional m d e =
    trans (sym (commutator-recovery X Y m d e))
      (trans (cong (λ q → run X (run Y q e) d)
        (trans (sym (Lie.bracket-characterization X Y m d e)) (proportional m (productD d e))))
        (trans (cong (λ q → run X q d)
          (compatible-commute X Y m (correction d e (ρ m)) e (correction-annihilates-second d e (ρ m))))
          (combine-correction X (run Y m e) d e (ρ m))))

  transport-to-commutator : (X Y : VectorField M) (ρ : M → R) → TransportLaw X Y ρ →
    (m : M) (d e : D) → Lie.commutator X Y m d e ≡ run X m (correction d e (ρ m))
  transport-to-commutator X Y ρ transport m d e =
    trans (cong (λ q → run Y (run X q (negateD d)) (negateD e)) (transport m d e))
      (trans (cong (λ q → run Y (run X q (negateD d)) (negateD e))
        (sym (combine-correction X (run Y m e) d e (ρ m))))
        (trans (cong (λ q → run Y q (negateD e))
          (Flow.inverse-right X (run X (run Y m e) (correction d e (ρ m))) d))
          (trans (compatible-commute X Y (run Y m e) (correction d e (ρ m)) (negateD e)
            (trans (neg-mulʳ (value (correction d e (ρ m))) (value e))
              (trans (cong -_ (correction-annihilates-second d e (ρ m))) neg-zero)))
            (cong (λ q → run X q (correction d e (ρ m))) (Flow.inverse-right Y m e)))))

  transport-to-proportional : (X Y : VectorField M) (ρ : M → R) →
    TransportLaw X Y ρ → Proportional X Y ρ
  transport-to-proportional X Y ρ transport m =
    Lie.detect (run (Lie.bracket X Y) m) (run (scale-field ρ X) m)
      (λ d e → trans (Lie.bracket-characterization X Y m d e)
        (transport-to-commutator X Y ρ transport m d e))

  proportional-preserves-neighbors : (X Y : VectorField M) (ρ : M → R) →
    Proportional X Y ρ → PreservesNeighbors X Y
  proportional-preserves-neighbors X Y ρ proportional e m n (d , p) =
    transported d e (ρ m) , trans (sym (proportional-to-transport X Y ρ proportional m d e))
      (cong (λ q → run Y q e) p)

  module TransportParameters (X Y : VectorField M) (proper : Proper X)
    (preserves : PreservesNeighbors X Y) where

    parameter : M → D → D → D
    parameter m d e = fst (preserves e m (run X m d) (d , refl))

    parameter-law : (m : M) (d e : D) →
      run X (run Y m e) (parameter m d e) ≡ run Y (run X m d) e
    parameter-law m d e = snd (preserves e m (run X m d) (d , refl))

    parameter-first-zero : (m : M) (e : D) → parameter m zeroD e ≡ zeroD
    parameter-first-zero m e = proper (run Y m e) (parameter m zeroD e) zeroD
      (trans (parameter-law m zeroD e)
        (trans (cong (λ q → run Y q e) (run-zero X m)) (sym (run-zero X (run Y m e)))))

    parameter-second-zero : (m : M) (d : D) → parameter m d zeroD ≡ d
    parameter-second-zero m d = proper m (parameter m d zeroD) d
      (trans (cong (λ q → run X q (parameter m d zeroD)) (sym (run-zero Y m)))
        (trans (parameter-law m d zeroD) (run-zero Y (run X m d))))

    firstSlope : M → D → R
    firstSlope m e = slope (λ d → value (parameter m d e))

    firstSlope-at-zero : (m : M) → firstSlope m zeroD ≡ 1r
    firstSlope-at-zero m =
      trans (slope-cong (λ d → value (parameter m d zeroD)) value
        (λ d → cong value (parameter-second-zero m d))) slope-value

    coefficient : M → R
    coefficient m = slope (firstSlope m)

    parameter-value : (m : M) (d e : D) →
      value (parameter m d e) ≡ value d * (1r + value e * coefficient m)
    parameter-value m d e =
      trans (expansion (λ a → value (parameter m a e)) d)
        (trans (cong (_+ (value d * firstSlope m e)) (cong value (parameter-first-zero m e)))
          (trans (+-identityˡ (value d * firstSlope m e))
            (trans (cong (value d *_) (expansion (firstSlope m) e))
              (cong (λ r → value d * (r + value e * coefficient m)) (firstSlope-at-zero m)))))

    parameter-normal-form : (m : M) (d e : D) → parameter m d e ≡ transported d e (coefficient m)
    parameter-normal-form m d e = d-path (parameter-value m d e)

    transport-law : TransportLaw X Y coefficient
    transport-law m d e = trans (sym (parameter-law m d e))
      (cong (run X (run Y m e)) (parameter-normal-form m d e))

    proportional : Proportional X Y coefficient
    proportional = transport-to-proportional X Y coefficient transport-law

  preservation-implies-admission : (X Y : VectorField M) → Proper X →
    PreservesNeighbors X Y → Admits X Y
  preservation-implies-admission X Y proper preserves =
    TransportParameters.coefficient X Y proper preserves ,
    TransportParameters.proportional X Y proper preserves

  admission-implies-preservation : (X Y : VectorField M) → Admits X Y → PreservesNeighbors X Y
  admission-implies-preservation X Y (ρ , p) = proportional-preserves-neighbors X Y ρ p

  -- Both implications of the source's criterion. The forward implication
  -- in fact does not require properness; the reverse one does.
  proper-admission-criterion : (X Y : VectorField M) → Proper X →
    (Admits X Y → PreservesNeighbors X Y) × (PreservesNeighbors X Y → Admits X Y)
  proper-admission-criterion X Y proper =
    admission-implies-preservation X Y , preservation-implies-admission X Y proper

  -- Identity-valued equality of vector-field records, when desired.
  AdmitsEquality : VectorField M → VectorField M → Set ℓ
  AdmitsEquality X Y = Σ (M → R) (λ ρ → Lie.bracket X Y ≡ scale-field ρ X)

  proper-admission-equality-criterion : (ext : FunExt ℓ ℓ) → isSet M →
    (X Y : VectorField M) → Proper X →
    (AdmitsEquality X Y → PreservesNeighbors X Y) ×
    (PreservesNeighbors X Y → AdmitsEquality X Y)
  proper-admission-equality-criterion ext setM X Y proper =
    (λ { (ρ , p) → proportional-preserves-neighbors X Y ρ
      (λ m d → cong (λ Z → run Z m d) p) }) ,
    (λ preserves → TransportParameters.coefficient X Y proper preserves ,
      field-ext ext setM (TransportParameters.proportional X Y proper preserves))
