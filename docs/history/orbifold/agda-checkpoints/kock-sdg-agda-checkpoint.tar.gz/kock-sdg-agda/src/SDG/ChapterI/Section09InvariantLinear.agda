{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section09InvariantLinear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section09Invariant as I9

module Linearity {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  {G : Set ℓ} (setG : isSet G) (Gmon : I9.Monoid G)
  (IL : S6.Linear.InfinitesimallyLinear A G)
  (W : S4.Results.PropertyW A K G) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A using (diagonal)
  open I9.Monoid Gmon
  open S7.Basics A setR
  open S8.Basics A setR
  open I9.Invariant A K setR Gmon IL W
  open S8M.Fields A setR ext0 ext G setG IL using (field-add)
  module T = S7L.Construction A setR ext0 G IL

  invariant-add : (X Y : VectorField G) → LeftInvariant X → LeftInvariant Y →
    LeftInvariant (field-add X Y)
  invariant-add X Y px py a b d =
    trans (S7L.Naturality.addition-natural A setR ext0 G G IL IL (a ·_)
      (field-section X b) (field-section Y b) d)
      (T.add-cong (tangent-map (a ·_) (field-section X b))
        (tangent-map (a ·_) (field-section Y b))
        (field-section X (a · b)) (field-section Y (a · b)) (px a b) (py a b) d)

  tangent-field-add : (t u : Tangent G unit) (g : G) (d : D) →
    run (field-from-tangent (T.add t u)) g d ≡
      run (field-add (field-from-tangent t) (field-from-tangent u)) g d
  tangent-field-add t u g d = T.extend-unique
    (field-section (field-from-tangent t) g) (field-section (field-from-tangent u) g)
    (λ p → g · T.extend t u p)
    (λ e → cong (g ·_) (T.extend-axis₀ t u e))
    (λ e → cong (g ·_) (T.extend-axis₁ t u e)) (diagonal d)

  tangent-field-scale : (r : R) (t : Tangent G unit) (g : G) (d : D) →
    run (field-from-tangent (speed r t)) g d ≡
      run (scale-field (λ _ → r) (field-from-tangent t)) g d
  tangent-field-scale r t g d = refl

  tangent-field-zero : (g : G) (d : D) → run (field-from-tangent (zero-tangent unit)) g d ≡ g
  tangent-field-zero g d = identityʳ g

  tangent-at-unit-add : (X Y : VectorField G) →
    tangent-at-unit (field-add X Y) ≡ T.add (tangent-at-unit X) (tangent-at-unit Y)
  tangent-at-unit-add X Y = tangent-ext ext setG (λ d → refl)

  tangent-at-unit-scale : (r : R) (X : VectorField G) →
    tangent-at-unit (scale-field (λ _ → r) X) ≡ speed r (tangent-at-unit X)
  tangent-at-unit-scale r X = tangent-ext ext setG (λ d → refl)

