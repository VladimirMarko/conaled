{-# OPTIONS --safe --without-K #-}
module SDG.Combinatorics.TwoPermutations where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; Permutation; to; from; from-to; permute)
open import SDG.Combinatorics.Signature

two : ℕ
two = suc (suc zero)

first last : Fin two
first = fzero
last = fsuc fzero

to-injective : {n : ℕ} (p : Permutation n) {i j : Fin n} → to p i ≡ to p j → i ≡ j
to-injective p {i} {j} eq = trans (sym (from-to p i)) (trans (cong (from p) eq) (from-to p j))

data TwoCase (p : Permutation two) : Set where
  fixed : to p first ≡ first → to p last ≡ last → TwoCase p
  swapped : to p first ≡ last → to p last ≡ first → TwoCase p

classify : (p : Permutation two) → TwoCase p
classify p with to p first in a | to p last in b
... | fzero | fzero = impossible (to-injective p (trans a (sym b)))
  where
  impossible : first ≡ last → TwoCase p
  impossible ()
... | fzero | fsuc fzero = fixed a b
... | fsuc fzero | fzero = swapped a b
... | fsuc fzero | fsuc fzero = impossible (to-injective p (trans a (sym b)))
  where
  impossible : first ≡ last → TwoCase p
  impossible ()

permute-fixed : {a : Level} {X : Set a} (p : Permutation two) →
  to p first ≡ first → to p last ≡ last → (xs : Vec X two) → permute p xs ≡ xs
permute-fixed p a b (x ∷ y ∷ []) rewrite a | b = refl

permute-swapped : {a : Level} {X : Set a} (p : Permutation two) →
  to p first ≡ last → to p last ≡ first → (x y : X) → permute p (x ∷ y ∷ []) ≡ y ∷ x ∷ []
permute-swapped p a b x y rewrite a | b = refl

module Signs {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Sign A

  fixed-sign : (p : Permutation two) → to p first ≡ first → to p last ≡ last → signature p ≡ 1r
  fixed-sign p a b rewrite a | b = refl

  swapped-sign : (p : Permutation two) → to p first ≡ last → to p last ≡ first → signature p ≡ (- 1r)
  swapped-sign p a b rewrite a | b = *-identityʳ (- 1r)
