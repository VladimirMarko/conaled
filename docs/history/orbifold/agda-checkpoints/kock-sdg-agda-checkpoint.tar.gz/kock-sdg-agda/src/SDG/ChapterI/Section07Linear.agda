{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section07Linear where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Infinitesimal.Jets
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup; vec-ext; tabulate;
  map; zipWith; lookup-map; lookup-zipWith; lookup-tabulate)
import SDG.Combinatorics.FiniteSums as FS
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section05Vector as V5

twoN threeN : ℕ
twoN = suc (suc zero)
threeN = suc twoN

i₀ i₁ : Fin twoN
i₀ = fzero
i₁ = fsuc fzero

j₀ j₁ j₂ : Fin threeN
j₀ = fzero
j₁ = fsuc fzero
j₂ = fsuc (fsuc fzero)

module Geometry {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR

  axis-off : {n : ℕ} (i j : Fin n) → i ≢ j → (d : D) → coordinate (axis i d) j ≡ 0r
  axis-off i j ne d = trans (axis-coordinate i j d)
    (trans (cong (_* value d) (Sum.delta-other j i (λ p → ne (sym p)))) (*-zeroˡ (value d)))

  coordinate-axis-own : {n : ℕ} (i : Fin n) (d : D) → coordinateD (axis i d) i ≡ d
  coordinate-axis-own i d = d-path (axis-own i d)

  coordinate-axis-off : {n : ℕ} (i j : Fin n) → i ≢ j → (d : D) → coordinateD (axis i d) j ≡ zeroD
  coordinate-axis-off i j ne d = d-path (axis-off i j ne d)

  coordinate-diagonal : {n : ℕ} (d : D) (i : Fin n) → coordinateD (diagonal d) i ≡ d
  coordinate-diagonal d i = d-path (diagonal-coordinate d i)

  switch : Fin twoN → Fin twoN
  switch fzero = i₁
  switch (fsuc fzero) = i₀

  swap : Jet1 twoN → Jet1 twoN
  swap = reindex switch

  swap-axis₀ : (d : D) → swap (axis i₀ d) ≡ axis i₁ d
  swap-axis₀ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-off i₀ i₁ (λ ()) d) (sym (axis-off i₁ i₀ (λ ()) d))
    ; (fsuc fzero) → trans (axis-own i₀ d) (sym (axis-own i₁ d)) })

  swap-axis₁ : (d : D) → swap (axis i₁ d) ≡ axis i₀ d
  swap-axis₁ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-own i₁ d) (sym (axis-own i₀ d))
    ; (fsuc fzero) → trans (axis-off i₁ i₀ (λ ()) d) (sym (axis-off i₀ i₁ (λ ()) d)) })

  swap-diagonal : (d : D) → swap (diagonal d) ≡ diagonal d
  swap-diagonal d = jet-path setR ext0 refl

  scale-axis : {n : ℕ} (r : R) (i : Fin n) (d : D) →
    scaleJet r (axis i d) ≡ axis i (scaleD d r)
  scale-axis r i d = jet-path setR ext0 (vec-ext (λ j →
    trans (scaleJet-coordinate r (axis i d) j)
      (trans (cong (_* r) (axis-coordinate i j d))
        (trans (*-assoc (Sum.delta j i) (value d) r) (sym (axis-coordinate i j (scaleD d r)))))))

  scale-diagonal : {n : ℕ} (r : R) (d : D) →
    scaleJet r (diagonal {n} d) ≡ diagonal (scaleD d r)
  scale-diagonal r d = jet-path setR ext0 (vec-ext (λ j →
    trans (scaleJet-coordinate r (diagonal d) j)
      (trans (cong (_* r) (diagonal-coordinate d j)) (sym (diagonal-coordinate (scaleD d r) j)))))

  weighted-axis : {n : ℕ} (weights : Vec R n) (i : Fin n) (d : D) →
    weightedD weights (axis i d) ≡ scaleD d (lookup weights i)
  weighted-axis weights i d = d-path
    (trans (weightedD-value weights (axis i d))
      (trans (Sum.sum-cong (λ j →
        trans (cong (_* lookup weights j) (axis-coordinate i j d))
          (trans (*-assoc (Sum.delta j i) (value d) (lookup weights j))
            (trans (*-swap (Sum.delta j i) (value d) (lookup weights j))
              (cong (value d *_) (*-comm (Sum.delta j i) (lookup weights j)))))))
        (trans (Sum.sum-scaleˡ (value d) (λ j → lookup weights j * Sum.delta j i))
          (cong (value d *_) (Sum.basis-expansion (lookup weights) i)))))

  weighted-diagonal : (r s : R) (d : D) →
    weightedD (r ∷ s ∷ []) (diagonal d) ≡ scaleD d (r + s)
  weighted-diagonal r s d = d-path
    (trans (weightedD-value (r ∷ s ∷ []) (diagonal d))
      (trans (cong ((value d * r) +_) (+-identityʳ (value d * s)))
        (sym (distribˡ (value d) r s))))

  incl23 : Jet1 twoN → Jet1 threeN
  incl23 p = makeJet1 (0r ∷ coordinate p i₀ ∷ coordinate p i₁ ∷ []) proof
    where
    proof : (i j : Fin threeN) →
      lookup (0r ∷ coordinate p i₀ ∷ coordinate p i₁ ∷ []) i *
      lookup (0r ∷ coordinate p i₀ ∷ coordinate p i₁ ∷ []) j ≡ 0r
    proof fzero j = *-zeroˡ (lookup (0r ∷ coordinate p i₀ ∷ coordinate p i₁ ∷ []) j)
    proof (fsuc i) fzero = *-zeroʳ (lookup (coordinate p i₀ ∷ coordinate p i₁ ∷ []) i)
    proof (fsuc fzero) (fsuc fzero) = pair-zero p i₀ i₀
    proof (fsuc fzero) (fsuc (fsuc fzero)) = pair-zero p i₀ i₁
    proof (fsuc (fsuc fzero)) (fsuc fzero) = pair-zero p i₁ i₀
    proof (fsuc (fsuc fzero)) (fsuc (fsuc fzero)) = pair-zero p i₁ i₁

  lastIndices : Fin threeN → Fin twoN
  lastIndices fzero = i₀
  lastIndices (fsuc fzero) = i₁
  lastIndices (fsuc (fsuc fzero)) = i₁

  duplicate-last : Jet1 twoN → Jet1 threeN
  duplicate-last = reindex lastIndices

  incl12-axis₀ : (d : D) → incl12 (axis i₀ d) ≡ axis j₀ d
  incl12-axis₀ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-own i₀ d) (sym (axis-own j₀ d))
    ; (fsuc fzero) → trans (axis-off i₀ i₁ (λ ()) d) (sym (axis-off j₀ j₁ (λ ()) d))
    ; (fsuc (fsuc fzero)) → sym (axis-off j₀ j₂ (λ ()) d) })

  incl12-axis₁ : (d : D) → incl12 (axis i₁ d) ≡ axis j₁ d
  incl12-axis₁ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-off i₁ i₀ (λ ()) d) (sym (axis-off j₁ j₀ (λ ()) d))
    ; (fsuc fzero) → trans (axis-own i₁ d) (sym (axis-own j₁ d))
    ; (fsuc (fsuc fzero)) → sym (axis-off j₁ j₂ (λ ()) d) })

  incl23-axis₀ : (d : D) → incl23 (axis i₀ d) ≡ axis j₁ d
  incl23-axis₀ d = jet-path setR ext0 (vec-ext λ
    { fzero → sym (axis-off j₁ j₀ (λ ()) d)
    ; (fsuc fzero) → trans (axis-own i₀ d) (sym (axis-own j₁ d))
    ; (fsuc (fsuc fzero)) → trans (axis-off i₀ i₁ (λ ()) d) (sym (axis-off j₁ j₂ (λ ()) d)) })

  incl23-axis₁ : (d : D) → incl23 (axis i₁ d) ≡ axis j₂ d
  incl23-axis₁ d = jet-path setR ext0 (vec-ext λ
    { fzero → sym (axis-off j₂ j₀ (λ ()) d)
    ; (fsuc fzero) → trans (axis-off i₁ i₀ (λ ()) d) (sym (axis-off j₂ j₁ (λ ()) d))
    ; (fsuc (fsuc fzero)) → trans (axis-own i₁ d) (sym (axis-own j₂ d)) })

  duplicate-first-axis₀ : (d : D) → duplicate-first (axis i₀ d) ≡ incl12 (diagonal d)
  duplicate-first-axis₀ d = jet-path setR ext0 (vec-ext λ
    { fzero → axis-own i₀ d
    ; (fsuc fzero) → axis-own i₀ d
    ; (fsuc (fsuc fzero)) → axis-off i₀ i₁ (λ ()) d })

  duplicate-first-axis₁ : (d : D) → duplicate-first (axis i₁ d) ≡ axis j₂ d
  duplicate-first-axis₁ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-off i₁ i₀ (λ ()) d) (sym (axis-off j₂ j₀ (λ ()) d))
    ; (fsuc fzero) → trans (axis-off i₁ i₀ (λ ()) d) (sym (axis-off j₂ j₁ (λ ()) d))
    ; (fsuc (fsuc fzero)) → trans (axis-own i₁ d) (sym (axis-own j₂ d)) })

  duplicate-last-axis₀ : (d : D) → duplicate-last (axis i₀ d) ≡ axis j₀ d
  duplicate-last-axis₀ d = jet-path setR ext0 (vec-ext λ
    { fzero → trans (axis-own i₀ d) (sym (axis-own j₀ d))
    ; (fsuc fzero) → trans (axis-off i₀ i₁ (λ ()) d) (sym (axis-off j₀ j₁ (λ ()) d))
    ; (fsuc (fsuc fzero)) → trans (axis-off i₀ i₁ (λ ()) d) (sym (axis-off j₀ j₂ (λ ()) d)) })

  duplicate-last-axis₁ : (d : D) → duplicate-last (axis i₁ d) ≡ incl23 (diagonal d)
  duplicate-last-axis₁ d = jet-path setR ext0 (vec-ext λ
    { fzero → axis-off i₁ i₀ (λ ()) d
    ; (fsuc fzero) → axis-own i₁ d
    ; (fsuc (fsuc fzero)) → axis-own i₁ d })

  duplicate-first-diagonal : (d : D) → duplicate-first (diagonal d) ≡ diagonal d
  duplicate-first-diagonal d = jet-path setR ext0 refl

  duplicate-last-diagonal : (d : D) → duplicate-last (diagonal d) ≡ diagonal d
  duplicate-last-diagonal d = jet-path setR ext0 refl

module Construction {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (M : Set ℓ) (IL : S6.Linear.InfinitesimallyLinear A M) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR
  open Geometry A setR ext0
  open S6.Linear.InfinitesimallyLinear IL renaming (axes to extension-axes)

  jet-extensional : (n : ℕ) (f g : Jet1 (suc (suc n)) → M) →
    ((i : Fin (suc (suc n))) (d : D) → f (axis i d) ≡ g (axis i d)) →
    (p : Jet1 (suc (suc n))) → f p ≡ g p
  jet-extensional n f g agree p =
    trans (uniqueness n x ts axesBase f (λ _ _ → refl) p)
      (sym (uniqueness n x ts axesBase g (λ i d → sym (agree i d)) p))
    where
      x = f (zeroJet (suc zero) (suc (suc n)))
      ts = λ i d → f (axis i d)
      axesBase = λ i → cong f (axis-zero setR ext0 i)

  twoCurves : {x : M} → Tangent M x → Tangent M x → Fin twoN → D → M
  twoCurves t u fzero = curve t
  twoCurves t u (fsuc fzero) = curve u

  twoBase : {x : M} (t u : Tangent M x) → (i : Fin twoN) → twoCurves t u i zeroD ≡ x
  twoBase t u fzero = based t
  twoBase t u (fsuc fzero) = based u

  extend : {x : M} → Tangent M x → Tangent M x → Jet1 twoN → M
  extend {x} t u = extension zero x (twoCurves t u) (twoBase t u)

  extend-axis₀ : {x : M} (t u : Tangent M x) (d : D) → extend t u (axis i₀ d) ≡ curve t d
  extend-axis₀ {x} t u = extension-axes zero x (twoCurves t u) (twoBase t u) i₀

  extend-axis₁ : {x : M} (t u : Tangent M x) (d : D) → extend t u (axis i₁ d) ≡ curve u d
  extend-axis₁ {x} t u = extension-axes zero x (twoCurves t u) (twoBase t u) i₁

  extend-unique : {x : M} (t u : Tangent M x) (f : Jet1 twoN → M) →
    ((d : D) → f (axis i₀ d) ≡ curve t d) →
    ((d : D) → f (axis i₁ d) ≡ curve u d) → (p : Jet1 twoN) → f p ≡ extend t u p
  extend-unique {x} t u f p q = uniqueness zero x (twoCurves t u) (twoBase t u) f
    (λ { fzero → p ; (fsuc fzero) → q })

  add : {x : M} → Tangent M x → Tangent M x → Tangent M x
  add {x} t u = tangent (λ d → extend t u (diagonal d))
    (trans (cong (extend t u)
      (trans (diagonal-zero setR ext0) (sym (axis-zero setR ext0 i₀))))
      (trans (extend-axis₀ t u zeroD) (based t)))

  add-cong : {x : M} (t u t′ u′ : Tangent M x) →
    ((d : D) → curve t d ≡ curve t′ d) → ((d : D) → curve u d ≡ curve u′ d) →
    (d : D) → curve (add t u) d ≡ curve (add t′ u′) d
  add-cong t u t′ u′ p q d = jet-extensional zero (extend t u) (extend t′ u′)
    (λ { fzero e → trans (extend-axis₀ t u e) (trans (p e) (sym (extend-axis₀ t′ u′ e)))
       ; (fsuc fzero) e → trans (extend-axis₁ t u e) (trans (q e) (sym (extend-axis₁ t′ u′ e))) })
    (diagonal d)

  add-comm : {x : M} (t u : Tangent M x) (d : D) → curve (add t u) d ≡ curve (add u t) d
  add-comm t u d = trans (cong (extend t u) (sym (swap-diagonal d)))
    (extend-unique u t (extend t u ∘ swap)
      (λ e → trans (cong (extend t u) (swap-axis₀ e)) (extend-axis₁ t u e))
      (λ e → trans (cong (extend t u) (swap-axis₁ e)) (extend-axis₀ t u e)) (diagonal d))

  add-zeroˡ : {x : M} (t : Tangent M x) (d : D) → curve (add (zero-tangent x) t) d ≡ curve t d
  add-zeroˡ {x} t d =
    trans (sym (extend-unique (zero-tangent x) t (λ p → curve t (coordinateD p i₁))
      (λ e → trans (cong (curve t) (coordinate-axis-off i₀ i₁ (λ ()) e)) (based t))
      (λ e → cong (curve t) (coordinate-axis-own i₁ e)) (diagonal d)))
      (cong (curve t) (coordinate-diagonal d i₁))

  speed-add-vectors : {x : M} (r : R) (t u : Tangent M x) (d : D) →
    curve (speed r (add t u)) d ≡ curve (add (speed r t) (speed r u)) d
  speed-add-vectors r t u d =
    trans (cong (extend t u) (sym (scale-diagonal r d)))
      (extend-unique (speed r t) (speed r u) (extend t u ∘ scaleJet r)
        (λ e → trans (cong (extend t u) (scale-axis r i₀ e)) (extend-axis₀ t u (scaleD e r)))
        (λ e → trans (cong (extend t u) (scale-axis r i₁ e)) (extend-axis₁ t u (scaleD e r)))
        (diagonal d))

  speed-add-scalars : {x : M} (r s : R) (t : Tangent M x) (d : D) →
    curve (speed (r + s) t) d ≡ curve (add (speed r t) (speed s t)) d
  speed-add-scalars r s t d =
    trans (cong (curve t) (sym (weighted-diagonal r s d)))
      (extend-unique (speed r t) (speed s t) (curve t ∘ weightedD (r ∷ s ∷ []))
        (λ e → cong (curve t) (weighted-axis (r ∷ s ∷ []) i₀ e))
        (λ e → cong (curve t) (weighted-axis (r ∷ s ∷ []) i₁ e)) (diagonal d))

  speed-zero : {x : M} (t : Tangent M x) (d : D) → curve (speed 0r t) d ≡ x
  speed-zero t d = trans (cong (curve t) (d-path (*-zeroʳ (value d)))) (based t)

  negate : {x : M} → Tangent M x → Tangent M x
  negate = speed (- 1r)

  add-inverseˡ : {x : M} (t : Tangent M x) (d : D) → curve (add (negate t) t) d ≡ x
  add-inverseˡ t d =
    trans (add-cong (negate t) t (negate t) (speed 1r t) (λ _ → refl) (λ e → sym (speed-one t e)) d)
      (trans (sym (speed-add-scalars (- 1r) 1r t d))
        (trans (cong (λ r → curve (speed r t) d) (+-inverseˡ 1r)) (speed-zero t d)))

  threeCurves : {x : M} → Tangent M x → Tangent M x → Tangent M x → Fin threeN → D → M
  threeCurves t u v fzero = curve t
  threeCurves t u v (fsuc fzero) = curve u
  threeCurves t u v (fsuc (fsuc fzero)) = curve v

  threeBase : {x : M} (t u v : Tangent M x) →
    (i : Fin threeN) → threeCurves t u v i zeroD ≡ x
  threeBase t u v fzero = based t
  threeBase t u v (fsuc fzero) = based u
  threeBase t u v (fsuc (fsuc fzero)) = based v

  extend3 : {x : M} → Tangent M x → Tangent M x → Tangent M x → Jet1 threeN → M
  extend3 {x} t u v = extension (suc zero) x (threeCurves t u v) (threeBase t u v)

  extend3-axis : {x : M} (t u v : Tangent M x) (i : Fin threeN) (d : D) →
    extend3 t u v (axis i d) ≡ threeCurves t u v i d
  extend3-axis {x} t u v = extension-axes (suc zero) x (threeCurves t u v) (threeBase t u v)

  restriction12 : {x : M} (t u v : Tangent M x) (p : Jet1 twoN) →
    extend3 t u v (incl12 p) ≡ extend t u p
  restriction12 t u v = extend-unique t u (extend3 t u v ∘ incl12)
    (λ d → trans (cong (extend3 t u v) (incl12-axis₀ d)) (extend3-axis t u v j₀ d))
    (λ d → trans (cong (extend3 t u v) (incl12-axis₁ d)) (extend3-axis t u v j₁ d))

  restriction23 : {x : M} (t u v : Tangent M x) (p : Jet1 twoN) →
    extend3 t u v (incl23 p) ≡ extend u v p
  restriction23 t u v = extend-unique u v (extend3 t u v ∘ incl23)
    (λ d → trans (cong (extend3 t u v) (incl23-axis₀ d)) (extend3-axis t u v j₁ d))
    (λ d → trans (cong (extend3 t u v) (incl23-axis₁ d)) (extend3-axis t u v j₂ d))

  left-associated : {x : M} (t u v : Tangent M x) (d : D) →
    curve (add (add t u) v) d ≡ extend3 t u v (diagonal d)
  left-associated t u v d =
    trans (sym (extend-unique (add t u) v (extend3 t u v ∘ duplicate-first)
      (λ e → trans (cong (extend3 t u v) (duplicate-first-axis₀ e))
        (restriction12 t u v (diagonal e)))
      (λ e → trans (cong (extend3 t u v) (duplicate-first-axis₁ e)) (extend3-axis t u v j₂ e))
      (diagonal d)))
      (cong (extend3 t u v) (duplicate-first-diagonal d))

  right-associated : {x : M} (t u v : Tangent M x) (d : D) →
    curve (add t (add u v)) d ≡ extend3 t u v (diagonal d)
  right-associated t u v d =
    trans (sym (extend-unique t (add u v) (extend3 t u v ∘ duplicate-last)
      (λ e → trans (cong (extend3 t u v) (duplicate-last-axis₀ e)) (extend3-axis t u v j₀ e))
      (λ e → trans (cong (extend3 t u v) (duplicate-last-axis₁ e))
        (restriction23 t u v (diagonal e)))
      (diagonal d)))
      (cong (extend3 t u v) (duplicate-last-diagonal d))

  add-assoc : {x : M} (t u v : Tangent M x) (d : D) →
    curve (add (add t u) v) d ≡ curve (add t (add u v)) d
  add-assoc t u v d = trans (left-associated t u v d) (sym (right-associated t u v d))

  -- Proposition 7.2. Pointwise laws need no extensionality for M.
  -- Packaging those laws as equality of based curves makes the precise
  -- extensionality and proof-irrelevance requirements explicit.
  fiberModule : (ext : FunExt ℓ ℓ) → isSet M → (x : M) → RModule A ℓ
  fiberModule ext setM x = record
    { V = Tangent M x
    ; 0v = zero-tangent x
    ; _+v_ = add
    ; -v_ = negate
    ; _•_ = speed
    ; add-assoc = λ t u v → tangent-ext ext setM (add-assoc t u v)
    ; add-comm = λ t u → tangent-ext ext setM (add-comm t u)
    ; add-zeroˡ = λ t → tangent-ext ext setM (add-zeroˡ t)
    ; add-inverseˡ = λ t → tangent-ext ext setM (add-inverseˡ t)
    ; scalar-one = λ t → tangent-ext ext setM (speed-one t)
    ; scalar-assoc = λ r s t → tangent-ext ext setM (speed-assoc r s t)
    ; scalar-add = λ r s t → tangent-ext ext setM (speed-add-scalars r s t)
    ; scalar-distrib = λ r t u → tangent-ext ext setM (speed-add-vectors r t u)
    }

record ModuleMap {a v w : Level} (A : CRing a)
  (U : RModule A v) (W : RModule A w) : Set (a ⊔ v ⊔ w) where
  private
    module U = RModule U
    module W = RModule W
  field
    apply : U.V → W.V
    preserves-zero : apply U.0v ≡ W.0v
    preserves-add : (u v : U.V) → apply (u U.+v v) ≡ apply u W.+v apply v
    preserves-scale : (r : CRing.R A) (u : U.V) → apply (r U.• u) ≡ r W.• apply u

module Naturality {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (M N : Set ℓ)
  (ILM : S6.Linear.InfinitesimallyLinear A M)
  (ILN : S6.Linear.InfinitesimallyLinear A N) (f : M → N) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR
  module Source = Construction A setR ext0 M ILM
  module Target = Construction A setR ext0 N ILN

  addition-natural : {x : M} (t u : Tangent M x) (d : D) →
    curve (tangent-map f (Source.add t u)) d ≡
    curve (Target.add (tangent-map f t) (tangent-map f u)) d
  addition-natural t u d =
    Target.extend-unique (tangent-map f t) (tangent-map f u) (f ∘ Source.extend t u)
      (λ e → cong f (Source.extend-axis₀ t u e))
      (λ e → cong f (Source.extend-axis₁ t u e)) (diagonal d)

  tangentModuleMap : (ext : FunExt ℓ ℓ) (setM : isSet M) (setN : isSet N)
    (x : M) → ModuleMap A (Source.fiberModule ext setM x) (Target.fiberModule ext setN (f x))
  tangentModuleMap ext setM setN x = record
    { apply = tangent-map f
    ; preserves-zero = tangent-ext ext setN (λ _ → refl)
    ; preserves-add = λ t u → tangent-ext ext setN (addition-natural t u)
    ; preserves-scale = λ r t → tangent-ext ext setN (speed-natural f r t)
    }

-- Proposition 7.3 uses both hypotheses appearing in the book: vector KL
-- supplies principal parts, while infinitesimal linearity supplies addition.
module VectorPrincipal {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (W : RModule A ℓ)
  (K : V5.VectorInfinitesimals.VectorKL A W)
  (IL : S6.Linear.InfinitesimallyLinear A (RModule.V W)) where
  open ModuleLemmas A W
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR
  open Geometry A setR ext0
  open V5.VectorInfinitesimals.VectorKL K
  module T = Construction A setR ext0 V IL

  principal : {x : V} → Tangent V x → V
  principal t = slopeV (curve t)

  affineV : V → V → D → V
  affineV x b d = x +v value d • b

  affineV-at-zero : (x b : V) → affineV x b zeroD ≡ x
  affineV-at-zero x b = trans (cong (x +v_) (zero-scalar b)) (add-zeroʳ x)

  straight : (x b : V) → Tangent V x
  straight x b = tangent (affineV x b) (affineV-at-zero x b)

  principal-straight : (x b : V) → principal (straight x b) ≡ b
  principal-straight x b = uniqueSlopeV (affineV x b) b
    (λ d → cong (_+v (value d • b)) (sym (affineV-at-zero x b)))

  straight-principal : {x : V} (t : Tangent V x) (d : D) →
    curve (straight x (principal t)) d ≡ curve t d
  straight-principal t d =
    trans (cong (_+v (value d • principal t)) (sym (based t))) (sym (expansionV (curve t) d))

  principal-zero : (x : V) → principal (zero-tangent x) ≡ 0v
  principal-zero x = uniqueSlopeV (λ _ → x) 0v
    (λ d → sym (trans (cong (x +v_) (scalar-zero (value d))) (add-zeroʳ x)))

  principal-speed : {x : V} (r : R) (t : Tangent V x) →
    principal (speed r t) ≡ r • principal t
  principal-speed r t = uniqueSlopeV (curve (speed r t)) (r • principal t) (λ d →
    trans (expansionV (curve t) (scaleD d r))
      (trans (cong (curve t zeroD +v_) (scalar-assoc (value d) r (principal t)))
        (cong (_+v (value d • (r • principal t))) (sym (cong (curve t) (scale-zero r))))))

  bivariate : V → V → V → Jet1 twoN → V
  bivariate x b c p = (x +v coordinate p i₀ • b) +v coordinate p i₁ • c

  bivariate-axis₀ : (x b c : V) (d : D) → bivariate x b c (axis i₀ d) ≡ affineV x b d
  bivariate-axis₀ x b c d =
    trans (cong₂ (λ r s → (x +v r • b) +v s • c)
      (axis-own i₀ d) (axis-off i₀ i₁ (λ ()) d))
      (trans (cong ((x +v value d • b) +v_) (zero-scalar c)) (add-zeroʳ (x +v value d • b)))

  bivariate-axis₁ : (x b c : V) (d : D) → bivariate x b c (axis i₁ d) ≡ affineV x c d
  bivariate-axis₁ x b c d =
    trans (cong₂ (λ r s → (x +v r • b) +v s • c)
      (axis-off i₁ i₀ (λ ()) d) (axis-own i₁ d))
      (cong (_+v (value d • c)) (affineV-at-zero x b))

  bivariate-diagonal : (x b c : V) (d : D) →
    bivariate x b c (diagonal d) ≡ affineV x (b +v c) d
  bivariate-diagonal x b c d = trans (add-assoc x (value d • b) (value d • c))
    (cong (x +v_) (sym (scalar-distrib (value d) b c)))

  addition-affine : {x : V} (t u : Tangent V x) (d : D) →
    curve (T.add t u) d ≡ affineV x (principal t +v principal u) d
  addition-affine {x} t u d =
    trans (sym (T.extend-unique t u (bivariate x (principal t) (principal u))
      (λ e → trans (bivariate-axis₀ x (principal t) (principal u) e) (straight-principal t e))
      (λ e → trans (bivariate-axis₁ x (principal t) (principal u) e) (straight-principal u e))
      (diagonal d)))
      (bivariate-diagonal x (principal t) (principal u) d)

  principal-add : {x : V} (t u : Tangent V x) →
    principal (T.add t u) ≡ principal t +v principal u
  principal-add t u = uniqueSlopeV (curve (T.add t u)) (principal t +v principal u)
    (λ d → trans (addition-affine t u d)
      (cong (_+v (value d • (principal t +v principal u))) (sym (based (T.add t u)))))

  principalModuleMap : (ext : FunExt ℓ ℓ) (setV : isSet V) (x : V) →
    ModuleMap A (T.fiberModule ext setV x) W
  principalModuleMap ext setV x = record
    { apply = principal
    ; preserves-zero = principal-zero x
    ; preserves-add = principal-add
    ; preserves-scale = principal-speed
    }

  principal-injective : (ext : FunExt ℓ ℓ) (setV : isSet V) {x : V}
    (t u : Tangent V x) → principal t ≡ principal u → t ≡ u
  principal-injective ext setV {x} t u p = tangent-ext ext setV (λ d →
    trans (sym (straight-principal t d))
      (trans (cong (λ b → affineV x b d) p) (straight-principal u d)))

  straight-principal-equality : (ext : FunExt ℓ ℓ) (setV : isSet V)
    {x : V} (t : Tangent V x) → straight x (principal t) ≡ t
  straight-principal-equality ext setV t = tangent-ext ext setV (straight-principal t)

  straightModuleMap : (ext : FunExt ℓ ℓ) (setV : isSet V) (x : V) →
    ModuleMap A W (T.fiberModule ext setV x)
  straightModuleMap ext setV x = record
    { apply = straight x
    ; preserves-zero = principal-injective ext setV (straight x 0v) (zero-tangent x)
        (trans (principal-straight x 0v) (sym (principal-zero x)))
    ; preserves-add = λ b c → principal-injective ext setV
        (straight x (b +v c)) (T.add (straight x b) (straight x c))
        (trans (principal-straight x (b +v c))
          (sym (trans (principal-add (straight x b) (straight x c))
            (cong₂ _+v_ (principal-straight x b) (principal-straight x c)))))
    ; preserves-scale = λ r b → principal-injective ext setV
        (straight x (r • b)) (speed r (straight x b))
        (trans (principal-straight x (r • b))
          (sym (trans (principal-speed r (straight x b)) (cong (r •_) (principal-straight x b)))))
    }

-- The example R^n in I.7 needs only first-order KL. These constructions
-- do not pass through the stronger higher-order axiom from I.5.
scalar-vectorKL : {ℓ : Level} (A : CRing ℓ) → Infinitesimals.KockLawvere A →
  V5.VectorInfinitesimals.VectorKL A (scalarModule A)
scalar-vectorKL A K = record
  { slopeV = Infinitesimals.KockLawvere.slope K
  ; expansionV = Infinitesimals.KockLawvere.expansion K
  ; uniqueSlopeV = Infinitesimals.KockLawvere.uniqueness K
  }

module FirstOrderFinitePowers {a v : Level} (A : CRing a) (W : RModule A v)
  (K : V5.VectorInfinitesimals.VectorKL A W) (n : ℕ) where
  open ModuleLemmas A W
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL K
  module Target = V5.VectorInfinitesimals A (FiniteModules.finiteModule A W n)

  finite-slope : (D → Vec V n) → Vec V n
  finite-slope f = tabulate (λ i → slopeV (λ d → lookup (f d) i))

  affine-coordinate : (f : D → Vec V n) (bs : Vec V n) (d : D) (i : Fin n) →
    lookup (zipWith _+v_ (f zeroD) (map (value d •_) bs)) i ≡
    lookup (f zeroD) i +v value d • lookup bs i
  affine-coordinate f bs d i = trans (lookup-zipWith _+v_ (f zeroD) (map (value d •_) bs) i)
    (cong (lookup (f zeroD) i +v_) (lookup-map (value d •_) bs i))

  finite-expansion : (f : D → Vec V n) (d : D) →
    f d ≡ f zeroD Target.+v (value d Target.• finite-slope f)
  finite-expansion f d = vec-ext (λ i → trans (expansionV (λ e → lookup (f e) i) d)
    (sym (trans (affine-coordinate f (finite-slope f) d i)
      (cong (λ b → lookup (f zeroD) i +v value d • b)
        (lookup-tabulate (λ j → slopeV (λ e → lookup (f e) j)) i)))))

  finite-unique : (f : D → Vec V n) (bs : Vec V n) →
    ((d : D) → f d ≡ f zeroD Target.+v (value d Target.• bs)) → finite-slope f ≡ bs
  finite-unique f bs p = vec-ext (λ i →
    trans (lookup-tabulate (λ j → slopeV (λ e → lookup (f e) j)) i)
      (uniqueSlopeV (λ d → lookup (f d) i) (lookup bs i)
        (λ d → trans (cong (λ xs → lookup xs i) (p d)) (affine-coordinate f bs d i))))

  firstOrderFiniteKL : Target.VectorKL
  firstOrderFiniteKL = record
    { slopeV = finite-slope
    ; expansionV = finite-expansion
    ; uniqueSlopeV = finite-unique
    }

module FirstOrderFunctionPowers {a v x : Level} (A : CRing a) (W : RModule A v)
  (K : V5.VectorInfinitesimals.VectorKL A W) (X : Set x) (ext : FunExt x v) where
  open ModuleLemmas A W
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL K
  module Target = V5.VectorInfinitesimals A (functionModule A W X ext)

  firstOrderFunctionKL : Target.VectorKL
  firstOrderFunctionKL = record
    { slopeV = λ f x → slopeV (λ d → f d x)
    ; expansionV = λ f d → ext (λ x → expansionV (λ e → f e x) d)
    ; uniqueSlopeV = λ f bs p → ext (λ x → uniqueSlopeV (λ d → f d x) (bs x)
        (λ d → cong (λ g → g x) (p d)))
    }

finite-scalars-vectorKL : {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (n : ℕ) → V5.VectorInfinitesimals.VectorKL A (finiteScalarModule A n)
finite-scalars-vectorKL A K n = FirstOrderFinitePowers.firstOrderFiniteKL A (scalarModule A) (scalar-vectorKL A K) n
