{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section12Colimits where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Algebra.PresentedMorphisms
import SDG.Algebra.PresentedColimits as PC
open import SDG.Finite using (Fin)
open import SDG.Schemes.Extensionality
import SDG.ChapterI.Section12 as S12

-- Proposition 12.7. A diagram is given by finitely many vertices and
-- arrows. The explicit presentation colimit works also for the empty
-- diagram and parallel arrows. Its image has the actual universal
-- property among internal R-algebras with set-valued carriers.
module Preservation {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
  open Presentations k
  open Morphisms k
  open S12.Comprehensive k A base ext ext0 setR
  open Consequences Ax
  open Axiom2 Ax

  Functions : Presentation → RAlgebra A ℓ
  Functions B = functionAlgebra A (Affine B) ext

  coordinate-map : {B T : Presentation} → Hom B T → AlgHom (Functions B) (Functions T)
  coordinate-map h = precomposition A ext (spec-map A base h)

  coordinate-identity : (B : Presentation) → coordinate-map (identity B) ≡ identityAlgHom (Functions B)
  coordinate-identity B = algHom-ext ext ext ext (function-set ext (λ _ → setR))
    (λ f → ext (λ x → cong f (spec-identity A base ext0 setR B x)))

  coordinate-compose : {B T U : Presentation} (f : Hom B T) (g : Hom T U) →
    coordinate-map (compose g f) ≡ composeAlgHom (coordinate-map g) (coordinate-map f)
  coordinate-compose f g = algHom-ext ext ext ext (function-set ext (λ _ → setR))
    (λ p → ext (λ x → cong p (spec-compose A base ext0 setR f g x)))

  coordinate-cong : {B T : Presentation} (f g : Hom B T) → HomEqual f g → coordinate-map f ≡ coordinate-map g
  coordinate-cong f g p = algHom-ext ext ext ext (function-set ext (λ _ → setR))
    (λ q → ext (λ x → cong q (spec-map-cong A base ext0 setR f g p x)))

  -- Naturality of the specific canonical map of Axiom 2, proved by
  -- interpreting the polynomial images of the source generators.
  canonical-naturality : {B T : Presentation} (h : Hom B T)
    (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C)))
    (α : AlgHom (Functions T) C) →
    canonical B C (composeAlgHom α (coordinate-map h)) ≡
      spec-map (ring C) (composeRingHom (unit C) base) h (canonical T C α)
  canonical-naturality {T = T} h C setC α = spec-path ext0 setC (λ i →
    trans (cong (algMap α) (sym (ext (λ x →
      evaluate-functions (Affine T) (images h i) (coordinate-function T) x))))
      (evaluate-hom (ring (Functions T)) (ring C)
        (coefficient-map (Functions T)) (coefficient-map C)
        (ringHom α) (λ a → commutes α (RingHom.hom base a))
        (images h i) (coordinate-function T)))

  module Diagram (objects edges : ℕ) (B : Fin objects → Presentation)
    (source target : Fin edges → Fin objects)
    (arrow : (e : Fin edges) → Hom (B (source e)) (B (target e))) where
    module Col = PC.FiniteColimit k objects edges B source target arrow

    record AlgebraCocone (C : RAlgebra A ℓ) : Set ℓ where
      constructor algebra-cocone
      field
        legs : (i : Fin objects) → AlgHom (Functions (B i)) C
        compatible : (e : Fin edges) → legs (source e) ≡
          composeAlgHom (legs (target e)) (coordinate-map (arrow e))
    open AlgebraCocone public

    coordinate-cocone : AlgebraCocone (Functions Col.colimit)
    legs coordinate-cocone i = coordinate-map (Col.inclusion i)
    compatible coordinate-cocone e =
      trans (coordinate-cong (Col.inclusion (source e))
        (compose (Col.inclusion (target e)) (arrow e)) (Col.inclusions-commute e))
        (coordinate-compose (arrow e) (Col.inclusion (target e)))

    module Target (C : RAlgebra A ℓ) (setC : isSet (CRing.R (ring C))) where
      module Sol = Col.Solutions (ring C) (composeRingHom (unit C) base) ext0 setC

      canonical-cone : AlgebraCocone C → Sol.SolutionCone
      Sol.points (canonical-cone cone) i = canonical (B i) C (legs cone i)
      Sol.compatible (canonical-cone cone) e j = cong (λ x → coordinates x j)
        (trans (cong (canonical (B (source e)) C) (compatible cone e))
          (canonical-naturality (arrow e) C setC (legs cone (target e))))

      factor : AlgebraCocone C → AlgHom (Functions Col.colimit) C
      factor cone = inverse-canonical Col.colimit C setC
        (Sol.assemble-solution (canonical-cone cone))

      factorizes : (cone : AlgebraCocone C) (i : Fin objects) →
        composeAlgHom (factor cone) (coordinate-map (Col.inclusion i)) ≡ legs cone i
      factorizes cone i = canonical-injective (B i) C setC
        (trans (canonical-naturality (Col.inclusion i) C setC (factor cone))
          (trans (cong (spec-map (ring C) (composeRingHom (unit C) base) (Col.inclusion i))
            (canonical-inverse Col.colimit C setC (Sol.assemble-solution (canonical-cone cone))))
            (cong (λ c → Sol.points c i) (Sol.restrict-assemble (canonical-cone cone)))))

      unique : (cone : AlgebraCocone C) (candidate : AlgHom (Functions Col.colimit) C) →
        ((i : Fin objects) → composeAlgHom candidate (coordinate-map (Col.inclusion i)) ≡ legs cone i) →
        candidate ≡ factor cone
      unique cone candidate eq = canonical-injective Col.colimit C setC
        (trans (sym (Sol.assemble-after-restrict (canonical Col.colimit C candidate)))
          (trans (cong Sol.assemble-solution restriction-law)
            (sym (canonical-inverse Col.colimit C setC (Sol.assemble-solution (canonical-cone cone))))))
        where
        restriction-law : Sol.restrict-solution (canonical Col.colimit C candidate) ≡ canonical-cone cone
        restriction-law = Sol.solution-cone-path (λ i j → cong (λ x → coordinates x j)
          (trans (sym (canonical-naturality (Col.inclusion i) C setC candidate))
            (cong (canonical (B i) C) (eq i))))

      -- Existence together with native uniqueness is the finite-colimit
      -- universal property. All maps, equations, and comparisons above
      -- are derived; the sole geometric premise is Axiom 2 itself.
      preserves-finite-colimit : (cone : AlgebraCocone C) →
        Σ (AlgHom (Functions Col.colimit) C) (λ h →
          (((i : Fin objects) → composeAlgHom h (coordinate-map (Col.inclusion i)) ≡ legs cone i) ×
           ((g : AlgHom (Functions Col.colimit) C) →
             ((i : Fin objects) → composeAlgHom g (coordinate-map (Col.inclusion i)) ≡ legs cone i) → g ≡ h)))
      preserves-finite-colimit cone = factor cone , (factorizes cone , unique cone)
