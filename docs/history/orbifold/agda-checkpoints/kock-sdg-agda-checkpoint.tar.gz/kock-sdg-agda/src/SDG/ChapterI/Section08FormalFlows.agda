{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08FormalFlows where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (fzero; fsuc)
open import SDG.Infinitesimal.Jets
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as S3E
import SDG.ChapterI.Section08FlowExtension as Extension

-- Exercise I.8.3, first assertion: self-transformations commute. The book's
-- Notes 2006, note 15 (printed p.94), explicitly adds infinitesimal linearity
-- to this exercise. The scalar inverse of 2 is part of its Q-algebra context.
-- The finite extensions, their compatibility, and the value-respecting
-- union action are constructed in Section08FlowExtension below.
module SelfCommutation {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR using (d-path; negateD)
  open S8.Basics A setR
  open S8.Linear A setR IL using (flow-law; inverse-left; first; second)
  open S9.Lie A K setR IL W

  private
    half-add : half + half ≡ 1r
    half-add = trans (sym (cong₂ _+_ (*-identityˡ half) (*-identityˡ half)))
      (trans (sym (distribʳ 1r 1r half)) half-law)

    sum-half-diagonal : (d : D) → sumJet (diagonal {n = 2} (scaleD d half)) ≡ d
    sum-half-diagonal d = d-path
      (trans (cong ((value d * half) +_) (+-identityʳ (value d * half)))
        (trans (sym (distribˡ (value d) half half))
          (trans (cong (value d *_) half-add) (*-identityʳ (value d)))))

    double-step : (X : VectorField M) (m : M) (d : D) →
      run X (run X m d) d ≡ run X m (sumJet (diagonal {n = 2} d))
    double-step X m d =
      trans (cong₂ (λ e f → run X (run X m e) f)
        (sym (d-path (diagonal-coordinate {n = 2} d fzero)))
        (sym (d-path (diagonal-coordinate {n = 2} d (fsuc fzero)))))
        (flow-law X m (diagonal d))

  self-negative-is-zero : (X : VectorField M) →
    ((m : M) (d : D) → run X m d ≡ run X m (negateD d)) →
    (m : M) (d : D) → run X m d ≡ m
  self-negative-is-zero X self-negative m d =
    trans (cong (run X m) (sym (sum-half-diagonal d)))
      (trans (sym (double-step X m (scaleD d half)))
        (trans (cong (λ n → run X n (scaleD d half))
          (self-negative m (scaleD d half))) (inverse-left X m (scaleD d half))))

  self-bracket-zero : (X : VectorField M) → BracketZero X X
  self-bracket-zero X = self-negative-is-zero (bracket X X) (bracket-antisymmetric X X)

  self-transformations-commute : (X : VectorField M) → TransformationsCommute X X
  self-transformations-commute X = zero-implies-commute X X (self-bracket-zero X)

-- Complete corrected Exercise I.8.3: every vector field generates a unique
-- formal flow. The union is the common witnessed-nilpotent setoid used by
-- Sections I.5 and I.6, and its action respects equality of scalar values.
module FormalFlows {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M)
  (half : CRing.R A) (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A)
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) M) where
  open S8.Basics A setR
  open SelfCommutation A K setR IL W half half-law

  module Generated (X : VectorField M) where
    open Extension.FiniteExtension A K setR SFP X
      (λ d e m → self-transformations-commute X m e d) public

