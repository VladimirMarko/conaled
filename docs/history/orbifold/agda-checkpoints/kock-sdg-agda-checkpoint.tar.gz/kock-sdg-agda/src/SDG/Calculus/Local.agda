{-# OPTIONS --safe --without-K #-}
module SDG.Calculus.Local where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.Calculus.Slope as Slope
import SDG.ChapterI.Section02 as Global

-- An actual embedded infinitesimally stable subspace of the line.
-- injective ensures proof witnesses for a point cannot affect scalar functions.
record StableDomain {ℓ : Level} (A : CRing ℓ) : Set (lsuc ℓ) where
  open RingLemmas A
  open Infinitesimals A
  field
    Carrier : Set ℓ
    coordinate : Carrier → R
    injective : {x y : Carrier} → coordinate x ≡ coordinate y → x ≡ y
    shift : Carrier → D → Carrier
    shifted-coordinate : (x : Carrier) (d : D) →
      coordinate (shift x d) ≡ coordinate x + value d

module DomainLemmas {ℓ : Level} (A : CRing ℓ) (U : StableDomain A) where
  open RingLemmas A
  open Infinitesimals A
  open StableDomain U public

  shift-zero : (x : Carrier) → shift x zeroD ≡ x
  shift-zero x = injective (trans (shifted-coordinate x zeroD) (+-identityʳ (coordinate x)))

  shifted-twice-coordinate : (x : Carrier) (d e : D) →
    coordinate (shift (shift x d) e) ≡ coordinate x + (value d + value e)
  shifted-twice-coordinate x d e =
    trans (shifted-coordinate (shift x d) e)
      (trans (cong (_+ value e) (shifted-coordinate x d))
        (+-assoc (coordinate x) (value d) (value e)))

  shift-commute : (x : Carrier) (d e : D) →
    shift (shift x d) e ≡ shift (shift x e) d
  shift-commute x d e = injective
    (trans (shifted-twice-coordinate x d e)
      (trans (cong (coordinate x +_) (+-comm (value d) (value e)))
        (sym (shifted-twice-coordinate x e d))))

wholeLine : {ℓ : Level} (A : CRing ℓ) → StableDomain A
wholeLine A = record
  { Carrier = R
  ; coordinate = λ x → x
  ; injective = λ p → p
  ; shift = λ x d → x + value d
  ; shifted-coordinate = λ x d → refl
  }
  where
  open RingLemmas A
  open Infinitesimals A

module Calculus {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (U : StableDomain A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open DomainLemmas A U public
  open Slope.Results A K

  derivative : (Carrier → R) → Carrier → R
  derivative f x = slope (λ d → f (shift x d))

  taylor : (f : Carrier → R) (x : Carrier) (d : D) →
    f (shift x d) ≡ f x + value d * derivative f x
  taylor f x d =
    trans (expansion (λ e → f (shift x e)) d)
      (cong (_+ (value d * derivative f x)) (cong f (shift-zero x)))

  derivative-unique : (f : Carrier → R) (x : Carrier) (b : R) →
    ((d : D) → f (shift x d) ≡ f x + value d * b) →
    derivative f x ≡ b
  derivative-unique f x b p =
    uniqueness (λ d → f (shift x d)) b
      (λ d → trans (p d)
        (cong (_+ (value d * b)) (cong f (sym (shift-zero x)))))

  derivative-cong : (f g : Carrier → R) →
    ((x : Carrier) → f x ≡ g x) → (x : Carrier) →
    derivative f x ≡ derivative g x
  derivative-cong f g p x = slope-cong
    (λ d → f (shift x d)) (λ d → g (shift x d)) (λ d → p (shift x d))

  derivative-constant : (r : R) (x : Carrier) → derivative (λ _ → r) x ≡ 0r
  derivative-constant r x = slope-constant r

  derivative-coordinate : (x : Carrier) → derivative coordinate x ≡ 1r
  derivative-coordinate x = derivative-unique coordinate x 1r
    (λ d → trans (shifted-coordinate x d)
      (cong (coordinate x +_) (sym (*-identityʳ (value d)))))

  derivative-add : (f g : Carrier → R) (x : Carrier) →
    derivative (λ t → f t + g t) x ≡ derivative f x + derivative g x
  derivative-add f g x = slope-add (λ d → f (shift x d)) (λ d → g (shift x d))

  derivative-scale : (r : R) (f : Carrier → R) (x : Carrier) →
    derivative (λ t → r * f t) x ≡ r * derivative f x
  derivative-scale r f x = slope-scale r (λ d → f (shift x d))

  derivative-neg : (f : Carrier → R) (x : Carrier) →
    derivative (λ t → - f t) x ≡ (- derivative f x)
  derivative-neg f x = slope-neg (λ d → f (shift x d))

  derivative-product : (f g : Carrier → R) (x : Carrier) →
    derivative (λ t → f t * g t) x ≡ f x * derivative g x + g x * derivative f x
  derivative-product f g x =
    derivative-unique (λ t → f t * g t) x
      (f x * derivative g x + g x * derivative f x)
      (λ d → trans (cong₂ _*_ (taylor f x d) (taylor g x d))
        (affine-product (value d) (f x) (derivative f x)
          (g x) (derivative g x) (square-zero d)))

  iterate : ℕ → (Carrier → R) → Carrier → R
  iterate zero f = f
  iterate (suc n) f = derivative (iterate n f)

  taylor-two-shifts : (f : Carrier → R) (x : Carrier) (d e : D) →
    f (shift (shift x d) e) ≡
      (f x + (value d + value e) * derivative f x) +
      (value d * value e) * derivative (derivative f) x
  taylor-two-shifts f x d e =
    begin
      f (shift (shift x d) e)
    ≡⟨ taylor f (shift x d) e ⟩
      f (shift x d) + value e * derivative f (shift x d)
    ≡⟨ cong₂ _+_ (taylor f x d) (cong (value e *_) (taylor (derivative f) x d)) ⟩
      (f x + value d * derivative f x) +
        value e * (derivative f x + value d * derivative (derivative f) x)
    ≡⟨ cong ((f x + value d * derivative f x) +_)
          (distribˡ (value e) (derivative f x) (value d * derivative (derivative f) x)) ⟩
      (f x + value d * derivative f x) +
        (value e * derivative f x + value e * (value d * derivative (derivative f) x))
    ≡⟨ sym (+-assoc (f x + value d * derivative f x)
          (value e * derivative f x) (value e * (value d * derivative (derivative f) x))) ⟩
      ((f x + value d * derivative f x) + value e * derivative f x) +
        value e * (value d * derivative (derivative f) x)
    ≡⟨ cong₂ _+_
          (trans (+-assoc (f x) (value d * derivative f x) (value e * derivative f x))
            (cong (f x +_) (sym (distribʳ (value d) (value e) (derivative f x)))))
          (trans (*-swap (value e) (value d) (derivative (derivative f) x))
            (sym (*-assoc (value d) (value e) (derivative (derivative f) x)))) ⟩
      (f x + (value d + value e) * derivative f x) +
        (value d * value e) * derivative (derivative f) x ∎

  taylor-two : (f : Carrier → R) (x y : Carrier) (d e : D) →
    coordinate y ≡ coordinate x + (value d + value e) →
    f y ≡ (f x + (value d + value e) * derivative f x) +
      (value d * value e) * derivative (derivative f) x
  taylor-two f x y d e p =
    trans (cong f (injective (trans p (sym (shifted-twice-coordinate x d e)))))
      (taylor-two-shifts f x d e)

  taylor-two-factorial : (half : R) → (1r + 1r) * half ≡ 1r →
    (f : Carrier → R) (x y : Carrier) (d e : D) →
    coordinate y ≡ coordinate x + (value d + value e) →
    f y ≡ (f x + (value d + value e) * derivative f x) +
      (((value d + value e) * (value d + value e)) * half) *
        derivative (derivative f) x
  taylor-two-factorial half h f x y d e p =
    trans (taylor-two f x y d e p)
      (cong ((f x + (value d + value e) * derivative f x) +_)
        (cong (_* derivative (derivative f) x) (sym coefficient)))
    where
    coefficient :
      ((value d + value e) * (value d + value e)) * half ≡ value d * value e
    coefficient =
      trans (cong (_* half) (Global.Results.square-sum A K d e))
        (trans (*-assoc (1r + 1r) (value d * value e) half)
          (trans (cong ((1r + 1r) *_) (*-comm (value d * value e) half))
            (trans (sym (*-assoc (1r + 1r) half (value d * value e)))
              (trans (cong (_* (value d * value e)) h) (*-identityˡ (value d * value e))))))

module Chain {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (U V : StableDomain A) where
  open RingLemmas A
  open Infinitesimals A
  module U = Calculus A K U
  module V = Calculus A K V

  image-shift : (g : V.Carrier → U.Carrier) (x : V.Carrier) (d : D) →
    g (V.shift x d) ≡ U.shift (g x) (scaleD d (V.derivative (U.coordinate ∘ g) x))
  image-shift g x d = U.injective
    (trans (V.taylor (U.coordinate ∘ g) x d)
      (sym (U.shifted-coordinate (g x) (scaleD d (V.derivative (U.coordinate ∘ g) x)))))

  derivative-chain : (f : U.Carrier → R) (g : V.Carrier → U.Carrier) (x : V.Carrier) →
    V.derivative (f ∘ g) x ≡ U.derivative f (g x) * V.derivative (U.coordinate ∘ g) x
  derivative-chain f g x =
    V.derivative-unique (f ∘ g) x
      (U.derivative f (g x) * V.derivative (U.coordinate ∘ g) x)
      (λ d → trans (cong f (image-shift g x d))
        (trans (U.taylor f (g x) (scaleD d (V.derivative (U.coordinate ∘ g) x)))
          (cong (f (g x) +_)
            (trans (*-assoc (value d) (V.derivative (U.coordinate ∘ g) x) (U.derivative f (g x)))
              (cong (value d *_) (*-comm (V.derivative (U.coordinate ∘ g) x) (U.derivative f (g x))))))))

