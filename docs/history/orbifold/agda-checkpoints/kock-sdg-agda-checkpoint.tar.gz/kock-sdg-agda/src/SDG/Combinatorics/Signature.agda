{-# OPTIONS --safe --without-K #-}
module SDG.Combinatorics.Signature where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Finite using (Fin; fzero; fsuc; Permutation; to; _+ℕ_)
open import Agda.Builtin.Bool using (Bool; true; false)

_and_ : Bool → Bool → Bool
true and b = b
false and b = false

less : {n : ℕ} → Fin n → Fin n → Bool
less fzero fzero = false
less fzero (fsuc j) = true
less (fsuc i) fzero = false
less (fsuc i) (fsuc j) = less i j

count : {n : ℕ} → (Fin n → Bool) → ℕ
count {zero} p = zero
count {suc n} p with p fzero
... | true = suc (count (λ i → p (fsuc i)))
... | false = count (λ i → p (fsuc i))

sum-natural : {n : ℕ} → (Fin n → ℕ) → ℕ
sum-natural {zero} f = zero
sum-natural {suc n} f = f fzero +ℕ sum-natural (λ i → f (fsuc i))

-- This is the ordinary inversion-count definition of permutation parity.
inversions : {n : ℕ} → Permutation n → ℕ
inversions p = sum-natural (λ i → count (λ j → less i j and less (to p j) (to p i)))

module Sign {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A

  signature : {n : ℕ} → Permutation n → R
  signature p = (- 1r) ^ inversions p

  signature-zero : (p : Permutation zero) → signature p ≡ 1r
  signature-zero p = refl

  signature-one : (p : Permutation (suc zero)) → signature p ≡ 1r
  signature-one p = refl

