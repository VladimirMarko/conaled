{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section07 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.ChapterI.Section01 as S1
import SDG.ChapterI.Section02 as S2
import SDG.Calculus.Slope as SL

module Basics {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A

  d-path : {d e : D} → value d ≡ value e → d ≡ e
  d-path {infinitesimal x p} {infinitesimal .x q} refl =
    cong (infinitesimal x) (setR _ _ p q)

  scale-zero : (r : R) → scaleD zeroD r ≡ zeroD
  scale-zero r = d-path (*-zeroˡ r)

  scale-one : (d : D) → scaleD d 1r ≡ d
  scale-one d = d-path (*-identityʳ (value d))

  scale-assoc : (d : D) (r s : R) → scaleD d (r * s) ≡ scaleD (scaleD d r) s
  scale-assoc d r s = d-path (sym (*-assoc (value d) r s))

  negateD : D → D
  negateD d = infinitesimal (- value d)
    (trans (neg-mul-neg (value d) (value d)) (square-zero d))

  negateD-involutive : (d : D) → negateD (negateD d) ≡ d
  negateD-involutive d = d-path (neg-involutive (value d))

  -- Definition I.7.1, with the base-point equation retained explicitly.
  record Tangent (M : Set ℓ) (x : M) : Set ℓ where
    constructor tangent
    field
      curve : D → M
      based : curve zeroD ≡ x
  open Tangent public

  Bundle : Set ℓ → Set ℓ
  Bundle M = D → M

  projection : {M : Set ℓ} → Bundle M → M
  projection t = t zeroD

  tangent-map : {M N : Set ℓ} (f : M → N) {x : M} → Tangent M x → Tangent N (f x)
  tangent-map f (tangent t p) = tangent (f ∘ t) (cong f p)

  bundle-map : {M N : Set ℓ} → (M → N) → Bundle M → Bundle N
  bundle-map f t = f ∘ t

  bundle-identity : {M : Set ℓ} (t : Bundle M) → bundle-map (λ x → x) t ≡ t
  bundle-identity t = refl

  bundle-composition : {M N P : Set ℓ} (f : M → N) (g : N → P) (t : Bundle M) →
    bundle-map (g ∘ f) t ≡ bundle-map g (bundle-map f t)
  bundle-composition f g t = refl

  projection-natural : {M N : Set ℓ} (f : M → N) (t : Bundle M) →
    projection (bundle-map f t) ≡ f (projection t)
  projection-natural f t = refl

  zero-tangent : {M : Set ℓ} (x : M) → Tangent M x
  zero-tangent x = tangent (λ _ → x) refl

  speed : {M : Set ℓ} {x : M} → R → Tangent M x → Tangent M x
  speed r (tangent t p) = tangent (λ d → t (scaleD d r))
    (trans (cong t (scale-zero r)) p)

  speed-one : {M : Set ℓ} {x : M} (t : Tangent M x) (d : D) →
    curve (speed 1r t) d ≡ curve t d
  speed-one t d = cong (curve t) (scale-one d)

  speed-assoc : {M : Set ℓ} {x : M} (r s : R) (t : Tangent M x) (d : D) →
    curve (speed (r * s) t) d ≡ curve (speed r (speed s t)) d
  speed-assoc r s t d = cong (curve t) (scale-assoc d r s)

  speed-natural : {M N : Set ℓ} (f : M → N) {x : M}
    (r : R) (t : Tangent M x) (d : D) →
    curve (tangent-map f (speed r t)) d ≡ curve (speed r (tangent-map f t)) d
  speed-natural f r t d = refl

  private
    tangent-path : {M : Set ℓ} → isSet M → {x : M} {t u : Tangent M x} →
      curve t ≡ curve u → t ≡ u
    tangent-path setM {t = tangent t p} {tangent .t q} refl =
      cong (tangent t) (setM _ _ p q)

  tangent-ext : (ext : FunExt ℓ ℓ) {M : Set ℓ} → isSet M →
    {x : M} {t u : Tangent M x} →
    ((d : D) → curve t d ≡ curve u d) → t ≡ u
  tangent-ext ext setM p = tangent-path setM (ext p)

  -- Exercise I.7.1: the canonical involution of the double tangent bundle.
  twist : {M : Set ℓ} → Bundle (Bundle M) → Bundle (Bundle M)
  twist t d e = t e d

  twist-involution : {M : Set ℓ} (t : Bundle (Bundle M)) → twist (twist t) ≡ t
  twist-involution t = refl

  twist-natural : {M N : Set ℓ} (f : M → N) (t : Bundle (Bundle M)) →
    twist (bundle-map (bundle-map f) t) ≡ bundle-map (bundle-map f) (twist t)
  twist-natural f t = refl

  -- Exercise I.7.2: the two axes of an infinitesimal square have the same base.
  record TangentPair (M : Set ℓ) : Set ℓ where
    constructor tangent-pair
    field
      base : M
      first second : Tangent M base
  open TangentPair public

  axes : {M : Set ℓ} → Bundle (Bundle M) → TangentPair M
  axes t = tangent-pair (t zeroD zeroD)
    (tangent (λ d → t d zeroD) refl)
    (tangent (λ d → t zeroD d) refl)

  axes-map : {M N : Set ℓ} (f : M → N) → TangentPair M → TangentPair N
  axes-map f (tangent-pair x u v) = tangent-pair (f x) (tangent-map f u) (tangent-map f v)

  axes-natural : {M N : Set ℓ} (f : M → N) (t : Bundle (Bundle M)) →
    axes (bundle-map (bundle-map f) t) ≡ axes-map f (axes t)
  axes-natural f t = refl

  -- Exercise I.7.3: exponential interchange, with genuine inverse laws.
  exchange : {M X : Set ℓ} → (X → Bundle M) → Bundle (X → M)
  exchange t d x = t x d

  unexchange : {M X : Set ℓ} → Bundle (X → M) → X → Bundle M
  unexchange t x d = t d x

  exchange-left : {M X : Set ℓ} (t : X → Bundle M) → unexchange (exchange t) ≡ t
  exchange-left t = refl

  exchange-right : {M X : Set ℓ} (t : Bundle (X → M)) → exchange (unexchange t) ≡ t
  exchange-right t = refl

module ScalarPrincipal {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open Basics A setR
  open S1.Results A K
  open S2.Results A K using (derivative; taylor)
  open SL.Results A K using (slope-cong)

  principal : {x : R} → Tangent R x → R
  principal t = slope (curve t)

  straight : (x b : R) → Tangent R x
  straight x b = tangent (affine x b) (affine-at-zero x b)

  principal-straight : (x b : R) → principal (straight x b) ≡ b
  principal-straight = slope-affine

  straight-principal : {x : R} (t : Tangent R x) (d : D) →
    curve (straight x (principal t)) d ≡ curve t d
  straight-principal {x} t d =
    trans (cong (_+ (value d * principal t)) (sym (based t)))
      (sym (expansion (curve t) d))

  principal-speed : {x : R} (r : R) (t : Tangent R x) →
    principal (speed r t) ≡ r * principal t
  principal-speed {x} r t = uniqueness (curve (speed r t)) (r * principal t)
    (λ d → trans (expansion (curve t) (scaleD d r))
      (cong₂ _+_ (cong (curve t) (sym (scale-zero r)))
        (*-assoc (value d) r (principal t))))

  tangent-chain : (f : R → R) {x : R} (t : Tangent R x) →
    principal (tangent-map f t) ≡ derivative f x * principal t
  tangent-chain f {x} t =
    trans
      (slope-cong (f ∘ curve t) (affine (f x) (derivative f x * principal t))
        (λ d → trans (cong f (sym (straight-principal t d)))
          (trans (taylor f x (scaleD d (principal t)))
            (cong (f x +_)
              (trans (*-assoc (value d) (principal t) (derivative f x))
                (cong (value d *_) (*-comm (principal t) (derivative f x))))))))
      (slope-affine (f x) (derivative f x * principal t))

