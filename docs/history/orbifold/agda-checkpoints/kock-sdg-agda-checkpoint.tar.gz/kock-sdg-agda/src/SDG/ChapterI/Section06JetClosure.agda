{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06JetClosure where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Vec; Fin; lookup; tabulate; lookup-tabulate; vec-ext)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.Constraints
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section06Closure as C6
import SDG.ChapterI.Section04 as S4

-- Exercise I.6.7 for D_k(n) and finite powers. These are finite systems
-- of polynomial equations. Every constraint on the inherited extension
-- follows from scalar uniqueness, and jet-path identifies its witnesses.
module InfinitesimalLinearJets {ℓ : Level} (A : CRing ℓ)
  (setR : isSet (CRing.R A)) (ext0 : FunExt lzero ℓ)
  (LR : S6.Linear.InfinitesimallyLinear A (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Constraints A
  open S6.Linear A
  open C6.Closure A using (vector-linear)

  module Fixed (k m : ℕ) where
    private
      LV : InfinitesimallyLinear (Vec R m)
      LV = vector-linear LR m

    underlying : (n : ℕ) (x : DJet k m) (ts : Fin (suc (suc n)) → D → DJet k m) →
      ((i : Fin (suc (suc n))) → ts i zeroD ≡ x) → Jet1 (suc (suc n)) → Vec R m
    underlying n x ts base = InfinitesimallyLinear.extension LV n (coords x)
      (λ i d → coords (ts i d)) (λ i → cong coords (base i))

    all-constraints : (n : ℕ) (x : DJet k m) (ts : Fin (suc (suc n)) → D → DJet k m)
      (base : (i : Fin (suc (suc n))) → ts i zeroD ≡ x)
      (p : Jet1 (suc (suc n))) (is : Vec (Fin m) (suc k)) →
      monomial (underlying n x ts base p) is ≡ 0r
    all-constraints n x ts base p is =
      trans (InfinitesimallyLinear.uniqueness LR n 0r (λ _ _ → 0r) (λ _ → refl)
        (λ q → monomial (underlying n x ts base q) is) factors p)
        (sym (InfinitesimallyLinear.uniqueness LR n 0r (λ _ _ → 0r) (λ _ → refl)
          (λ _ → 0r) (λ _ _ → refl) p))
      where
      factors : (i : Fin (suc (suc n))) (d : D) → monomial (underlying n x ts base (axis i d)) is ≡ 0r
      factors i d = trans (cong (λ xs → monomial xs is)
        (InfinitesimallyLinear.axes LV n (coords x) (λ j e → coords (ts j e))
          (λ j → cong coords (base j)) i d)) (jet-monomial-zero (ts i d) is)

    jet-linear : InfinitesimallyLinear (DJet k m)
    InfinitesimallyLinear.extension jet-linear n x ts base p =
      makeJet (underlying n x ts base p) (all-constraints n x ts base p)
    InfinitesimallyLinear.axes jet-linear n x ts base i d = jet-path setR ext0
      (InfinitesimallyLinear.axes LV n (coords x) (λ j e → coords (ts j e))
        (λ j → cong coords (base j)) i d)
    InfinitesimallyLinear.uniqueness jet-linear n x ts base candidate p d = jet-path setR ext0
      (InfinitesimallyLinear.uniqueness LV n (coords x) (λ j e → coords (ts j e))
        (λ j → cong coords (base j)) (λ q → coords (candidate q))
        (λ j e → cong coords (p j e)) d)

  jet-power-linear : (k n m : ℕ) → InfinitesimallyLinear (Vec (DJet k n) m)
  jet-power-linear k n m = vector-linear (Fixed.jet-linear k n) m

module WJets {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (ext0 : FunExt lzero ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Constraints A
  open S4.Results A K using (PropertyW; Axis₁; Axis₂; productD; scalar-W; vector-W)

  module Fixed (k m : ℕ) where
    underlying : (f : D → D → DJet k m) → Axis₁ f → Axis₂ f → D → Vec R m
    underlying f a b = PropertyW.lift (vector-W m) (λ d e → coords (f d e))
      (λ d → cong coords (a d)) (λ e → cong coords (b e))

    all-constraints : (f : D → D → DJet k m) (a : Axis₁ f) (b : Axis₂ f)
      (z : D) (is : Vec (Fin m) (suc k)) → monomial (underlying f a b z) is ≡ 0r
    all-constraints f a b z is =
      trans (PropertyW.unique scalar-W (λ _ _ → 0r) (λ _ → refl) (λ _ → refl)
        (λ d → monomial (underlying f a b d) is) factors z)
        (sym (PropertyW.unique scalar-W (λ _ _ → 0r) (λ _ → refl) (λ _ → refl)
          (λ _ → 0r) (λ _ _ → refl) z))
      where
      factors : (d e : D) → 0r ≡ monomial (underlying f a b (productD d e)) is
      factors d e = trans (sym (jet-monomial-zero (f d e) is))
        (cong (λ xs → monomial xs is) (PropertyW.factor (vector-W m) (λ c h → coords (f c h))
          (λ c → cong coords (a c)) (λ h → cong coords (b h)) d e))

    jet-W : PropertyW (DJet k m)
    PropertyW.lift jet-W f a b z = makeJet (underlying f a b z) (all-constraints f a b z)
    PropertyW.factor jet-W f a b d e = jet-path setR ext0
      (PropertyW.factor (vector-W m) (λ c h → coords (f c h))
        (λ c → cong coords (a c)) (λ h → cong coords (b h)) d e)
    PropertyW.unique jet-W f a b t p z = jet-path setR ext0
      (PropertyW.unique (vector-W m) (λ c h → coords (f c h))
        (λ c → cong coords (a c)) (λ h → cong coords (b h)) (λ d → coords (t d))
        (λ c h → cong coords (p c h)) z)

module SymmetricJets {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (ext0 : FunExt lzero ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Constraints A
  open S4.Results A K using (Symmetric; SymmetricDescent)

  module Given {h : ℕ} (Y : Set ℓ) (q : Vec D h → Y)
    (SR : SymmetricDescent Y q R) where

    vector-descent : (m : ℕ) → SymmetricDescent Y q (Vec R m)
    SymmetricDescent.descend (vector-descent m) f symmetric y = tabulate (λ i →
      SymmetricDescent.descend SR (λ ds → lookup (f ds) i)
        (λ p ds → cong (λ xs → lookup xs i) (symmetric p ds)) y)
    SymmetricDescent.factor (vector-descent m) f symmetric ds = vec-ext (λ i →
      trans (SymmetricDescent.factor SR (λ es → lookup (f es) i)
        (λ p es → cong (λ xs → lookup xs i) (symmetric p es)) ds)
        (sym (lookup-tabulate
          (λ j → SymmetricDescent.descend SR (λ es → lookup (f es) j)
            (λ p es → cong (λ xs → lookup xs j) (symmetric p es)) (q ds)) i)))
    SymmetricDescent.unique (vector-descent m) f symmetric t p y = vec-ext (λ i →
      trans (SymmetricDescent.unique SR (λ ds → lookup (f ds) i)
        (λ perm ds → cong (λ xs → lookup xs i) (symmetric perm ds)) (λ z → lookup (t z) i)
        (λ ds → cong (λ xs → lookup xs i) (p ds)) y)
        (sym (lookup-tabulate
          (λ j → SymmetricDescent.descend SR (λ ds → lookup (f ds) j)
            (λ perm ds → cong (λ xs → lookup xs j) (symmetric perm ds)) y) i)))

    module Fixed (k m : ℕ) where
      underlying : (f : Vec D h → DJet k m) → Symmetric f → Y → Vec R m
      underlying f symmetric = SymmetricDescent.descend (vector-descent m) (λ ds → coords (f ds))
        (λ p ds → cong coords (symmetric p ds))

      all-constraints : (f : Vec D h → DJet k m) (symmetric : Symmetric f)
        (y : Y) (is : Vec (Fin m) (suc k)) → monomial (underlying f symmetric y) is ≡ 0r
      all-constraints f symmetric y is =
        trans (SymmetricDescent.unique SR (λ _ → 0r) (λ _ _ → refl)
          (λ z → monomial (underlying f symmetric z) is) factors y)
          (sym (SymmetricDescent.unique SR (λ _ → 0r) (λ _ _ → refl)
            (λ _ → 0r) (λ _ → refl) y))
        where
        factors : (ds : Vec D h) → 0r ≡ monomial (underlying f symmetric (q ds)) is
        factors ds = trans (sym (jet-monomial-zero (f ds) is))
          (cong (λ xs → monomial xs is) (SymmetricDescent.factor (vector-descent m)
            (λ es → coords (f es)) (λ p es → cong coords (symmetric p es)) ds))

      jet-symmetric : SymmetricDescent Y q (DJet k m)
      SymmetricDescent.descend jet-symmetric f symmetric y =
        makeJet (underlying f symmetric y) (all-constraints f symmetric y)
      SymmetricDescent.factor jet-symmetric f symmetric ds = jet-path setR ext0
        (SymmetricDescent.factor (vector-descent m) (λ es → coords (f es))
          (λ p es → cong coords (symmetric p es)) ds)
      SymmetricDescent.unique jet-symmetric f symmetric t p y = jet-path setR ext0
        (SymmetricDescent.unique (vector-descent m) (λ ds → coords (f ds))
          (λ perm ds → cong coords (symmetric perm ds)) (λ z → coords (t z))
          (λ ds → cong coords (p ds)) y)
