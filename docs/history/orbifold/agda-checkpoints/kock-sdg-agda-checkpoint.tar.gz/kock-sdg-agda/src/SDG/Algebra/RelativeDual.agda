{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.RelativeDual where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom; module DualNumbers)
open import SDG.Algebra.Algebras
import SDG.Algebra.RelativeDerivations as RD

-- Algebra maps to dual numbers are exactly a base algebra map and a
-- derivation relative to it. This is the algebraic step in I.12.4.
module Correspondence {a c d : Level} (A : CRing a)
  (C : RAlgebra A c) (D : RAlgebra A d) where
  module S = RingLemmas (ring C)
  open RingLemmas (ring D)
  module Dual = DualNumbers (ring D)

  encode : (i : AlgHom C D) → RD.Relative.Derivation A C D i → AlgHom C (dualAlgebra D)
  encode i δ = algebra-hom record
    { hom = λ x → algMap i x , run δ x
    ; pres-0 = cong₂ _,_ (RingHom.pres-0 (ringHom i)) (derive-zero δ)
    ; pres-1 = cong₂ _,_ (RingHom.pres-1 (ringHom i)) (derive-one δ)
    ; pres-+ = λ x y → cong₂ _,_ (RingHom.pres-+ (ringHom i) x y) (additive δ x y)
    ; pres-* = λ x y → cong₂ _,_ (RingHom.pres-* (ringHom i) x y)
        (trans (leibniz δ x y)
          (trans (+-comm (run δ x * algMap i y) (algMap i x * run δ y))
            (cong (algMap i x * run δ y +_) (*-comm (run δ x) (algMap i y)))))
    ; pres-neg = λ x → cong₂ _,_ (RingHom.pres-neg (ringHom i) x) (derive-neg δ x)
    }
    (λ r → cong₂ _,_ (commutes i r) (derive-scalar δ r))
    where
    open RD.Relative A C D i using
      (run; additive; leibniz; derive-zero; derive-one; derive-neg; derive-scalar)

  base : AlgHom C (dualAlgebra D) → AlgHom C D
  base F = composeAlgHom (dualBase D) F

  slope : (F : AlgHom C (dualAlgebra D)) → RD.Relative.Derivation A C D (base F)
  slope F = record
    { run = λ x → snd (algMap F x)
    ; additive = λ x y → cong snd (RingHom.pres-+ (ringHom F) x y)
    ; homogeneous = λ r x →
        trans (cong snd (trans (RingHom.pres-* (ringHom F) (RingHom.hom (unit C) r) x)
          (cong (λ p → Dual.mul p (algMap F x)) (commutes F r))))
          (trans (cong (RingHom.hom (unit D) r * snd (algMap F x) +_) (*-zeroʳ (fst (algMap F x))))
            (+-identityʳ (RingHom.hom (unit D) r * snd (algMap F x))))
    ; leibniz = λ x y → trans (cong snd (RingHom.pres-* (ringHom F) x y))
        (trans (+-comm (fst (algMap F x) * snd (algMap F y)) (fst (algMap F y) * snd (algMap F x)))
          (cong (_+ (fst (algMap F x) * snd (algMap F y))) (*-comm (fst (algMap F y)) (snd (algMap F x)))))
    }

  Data : Set (a ⊔ c ⊔ d)
  Data = Σ (AlgHom C D) (RD.Relative.Derivation A C D)

  decode : AlgHom C (dualAlgebra D) → Data
  decode F = base F , slope F

  encode-decode : (F : AlgHom C (dualAlgebra D)) (x : S.R) →
    algMap (encode (base F) (slope F)) x ≡ algMap F x
  encode-decode F x = refl

  decode-encode-base : (i : AlgHom C D) (δ : RD.Relative.Derivation A C D i) (x : S.R) →
    algMap (base (encode i δ)) x ≡ algMap i x
  decode-encode-base i δ x = refl

  decode-encode-slope : (i : AlgHom C D) (δ : RD.Relative.Derivation A C D i) (x : S.R) →
    RD.Relative.run (slope (encode i δ)) x ≡ RD.Relative.run δ x
  decode-encode-slope i δ x = refl

  -- Fixed-base fibers avoid identifying different algebra-map records by
  -- fiat. The supplied equation is the actual fiber condition.
  Over : AlgHom C D → Set (a ⊔ c ⊔ d)
  Over i = Σ (AlgHom C (dualAlgebra D)) (λ F → (x : S.R) → fst (algMap F x) ≡ algMap i x)

  fromDualOver : (i : AlgHom C D) (F : AlgHom C (dualAlgebra D)) →
    ((x : S.R) → fst (algMap F x) ≡ algMap i x) → RD.Relative.Derivation A C D i
  fromDualOver i F p = record
    { run = λ x → snd (algMap F x)
    ; additive = RD.Relative.additive (slope F)
    ; homogeneous = RD.Relative.homogeneous (slope F)
    ; leibniz = λ x y → trans (RD.Relative.leibniz (slope F) x y)
        (cong₂ _+_ (cong (snd (algMap F x) *_) (p y)) (cong (_* snd (algMap F y)) (p x)))
    }

  encodeOver : (i : AlgHom C D) → RD.Relative.Derivation A C D i → Over i
  encodeOver i δ = encode i δ , λ _ → refl

  decodeOver : (i : AlgHom C D) → Over i → RD.Relative.Derivation A C D i
  decodeOver i (F , p) = fromDualOver i F p

  fixed-encode-decode : (i : AlgHom C D) (F : AlgHom C (dualAlgebra D))
    (p : (x : S.R) → fst (algMap F x) ≡ algMap i x) (x : S.R) →
    algMap (encode i (fromDualOver i F p)) x ≡ algMap F x
  fixed-encode-decode i F p x = cong₂ _,_ (sym (p x)) refl

  fixed-decode-encode : (i : AlgHom C D) (δ : RD.Relative.Derivation A C D i) (x : S.R) →
    RD.Relative.run (decodeOver i (encodeOver i δ)) x ≡ RD.Relative.run δ x
  fixed-decode-encode i δ x = refl

-- Setness of ordinary products follows from setness of their factors.
-- The path reconstruction proof is by equality elimination, without K.
pair-path-η : {a b : Level} {X : Set a} {Y : Set b} {u v : X × Y}
  (p : u ≡ v) → cong₂ _,_ (cong fst p) (cong snd p) ≡ p
pair-path-η refl = refl

product-isSet : {a b : Level} {X : Set a} {Y : Set b} → isSet X → isSet Y → isSet (X × Y)
product-isSet setX setY u v p q = trans (sym (pair-path-η p))
  (trans (cong₂ (cong₂ _,_) (setX (fst u) (fst v) (cong fst p) (cong fst q))
    (setY (snd u) (snd v) (cong snd p) (cong snd q))) (pair-path-η q))

module Native {a c d : Level} (A : CRing a)
  (C : RAlgebra A c) (D : RAlgebra A d)
  (ext : FunExt c d) (ext₂ : FunExt c (c ⊔ d))
  (extBase : FunExt a d) (extA : FunExt a (c ⊔ d))
  (setD : isSet (CRing.R (ring D))) where
  open Correspondence A C D

  algebra-roundtrip : (F : AlgHom C (dualAlgebra D)) → encode (base F) (slope F) ≡ F
  algebra-roundtrip F = algHom-ext ext ext₂ extBase (product-isSet setD setD) (encode-decode F)

  derivation-roundtrip : (i : AlgHom C D) (δ : RD.Relative.Derivation A C D i) →
    decodeOver i (encodeOver i δ) ≡ δ
  derivation-roundtrip i δ = RD.Native.derivation-ext A C D i ext ext₂ extA setD
    (fixed-decode-encode i δ)

  private
    subtype-path : {u v : Level} {X : Set u} {P : X → Set v} →
      ((x : X) → isProp (P x)) → {p q : Σ X P} → fst p ≡ fst q → p ≡ q
    subtype-path prop {p = x , a} {q = .x , b} refl = cong (x ,_) (prop x a b)

  fiber-roundtrip : (i : AlgHom C D) (z : Over i) → encodeOver i (decodeOver i z) ≡ z
  fiber-roundtrip i (F , p) = subtype-path (λ G r s → ext (λ x → setD _ _ (r x) (s x)))
    (algHom-ext ext ext₂ extBase (product-isSet setD setD) (fixed-encode-decode i F p))
