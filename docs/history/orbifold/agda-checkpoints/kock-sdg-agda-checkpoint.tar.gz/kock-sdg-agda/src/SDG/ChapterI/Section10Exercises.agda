{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section10Exercises where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc)
import SDG.ChapterI.Section02 as S2
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section10 as S10

-- Exercise 10.1(i) is independent of Kock--Lawvere, as the book observes.
module Coordinates {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open S8.Basics A setR

  shift : {n : ℕ} → Vec R n → Fin n → D → Vec R n
  shift (x ∷ xs) fzero d = (x + value d) ∷ xs
  shift (x ∷ xs) (fsuc i) d = x ∷ shift xs i d

  shift-zero : {n : ℕ} (xs : Vec R n) (i : Fin n) → shift xs i zeroD ≡ xs
  shift-zero (x ∷ xs) fzero = cong (_∷ xs) (+-identityʳ x)
  shift-zero (x ∷ xs) (fsuc i) = cong (x ∷_) (shift-zero xs i)

  shift-commute : {n : ℕ} (xs : Vec R n) (i j : Fin n) (d e : D) →
    shift (shift xs i d) j e ≡ shift (shift xs j e) i d
  shift-commute (x ∷ xs) fzero fzero d e = cong (_∷ xs)
    (trans (+-assoc x (value d) (value e))
      (trans (cong (x +_) (+-comm (value d) (value e)))
        (sym (+-assoc x (value e) (value d)))))
  shift-commute (x ∷ xs) fzero (fsuc j) d e = refl
  shift-commute (x ∷ xs) (fsuc i) fzero d e = refl
  shift-commute (x ∷ xs) (fsuc i) (fsuc j) d e = cong (x ∷_) (shift-commute xs i j d e)

  coordinate-field : {n : ℕ} → Fin n → VectorField (Vec R n)
  run (coordinate-field i) xs d = shift xs i d
  run-zero (coordinate-field i) xs = shift-zero xs i

  coordinate-fields-commute : {n : ℕ} (i j : Fin n) (xs : Vec R n) (d e : D) →
    run (coordinate-field j) (run (coordinate-field i) xs d) e ≡
    run (coordinate-field i) (run (coordinate-field j) xs e) d
  coordinate-fields-commute i j xs = shift-commute xs i j

  line-field : VectorField R
  run line-field x d = x + value d
  run-zero line-field = +-identityʳ

module VectorComparison {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (W : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A W) where
  open ModuleLemmas A W
  open Infinitesimals A
  open Coordinates A setR
  open V5.VectorInfinitesimals.VectorKL KV
  module VC = V5.VectorCalculus A W KV
  open S10.Calculus A K setR W KV

  same-shift : {n : ℕ} (xs : Vec R n) (i : Fin n) (d : D) →
    shift xs i d ≡ VC.shift xs i d
  same-shift (x ∷ xs) fzero d = refl
  same-shift (x ∷ xs) (fsuc i) d = cong (x ∷_) (same-shift xs i d)

  -- Exercise 10.1(ii), in the full module-valued form.
  coordinate-derivative-is-partial : {n : ℕ} (f : Vec R n → V) (i : Fin n) (xs : Vec R n) →
    directional (coordinate-field i) f xs ≡ VC.partial f i xs
  coordinate-derivative-is-partial f i xs = VC.slope-cong
    (λ d → f (shift xs i d)) (λ d → f (VC.shift xs i d))
    (λ d → cong f (same-shift xs i d))

  line-derivative : (f : R → V) (x : R) → directional line-field f x ≡ VC.derivative f x
  line-derivative f x = refl

module ScalarComparison {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open Coordinates A setR
  module C = S10.Calculus A K setR (scalarModule A) (S10.scalar-vectorKL A K)

  same-scalar-shift : {n : ℕ} (xs : Vec R n) (i : Fin n) (d : D) →
    shift xs i d ≡ S4.Results.shift A K xs i d
  same-scalar-shift (x ∷ xs) fzero d = refl
  same-scalar-shift (x ∷ xs) (fsuc i) d = cong (x ∷_) (same-scalar-shift xs i d)

  coordinate-derivative-is-partial : {n : ℕ} (f : Vec R n → R) (i : Fin n) (xs : Vec R n) →
    C.directional (coordinate-field i) f xs ≡ S4.Results.partial A K f i xs
  coordinate-derivative-is-partial f i xs =
    V5.VectorCalculus.slope-cong A (scalarModule A) (S10.scalar-vectorKL A K)
      (λ d → f (shift xs i d)) (λ d → f (S4.Results.shift A K xs i d))
      (λ d → cong f (same-scalar-shift xs i d))

  line-derivative : (f : R → R) (x : R) → C.directional line-field f x ≡ S2.Results.derivative A K f x
  line-derivative f x = refl

