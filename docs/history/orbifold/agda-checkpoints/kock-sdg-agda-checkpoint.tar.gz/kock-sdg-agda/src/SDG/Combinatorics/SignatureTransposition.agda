{-# OPTIONS --safe --without-K #-}
module SDG.Combinatorics.SignatureTransposition where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Finite using (Fin; fzero; fsuc; fsuc-injective; finToNat;
  Permutation; to; from; from-to; skip; liftPerm)
open import Agda.Builtin.Bool using (false)
open import SDG.Combinatorics.Signature
open import SDG.Combinatorics.SignatureCofactor
open import SDG.Forms.CubicalGeometry using (minor; module Minor; skip-distinct; skip-injective)
open import SDG.Flows.CommutingActions using (swapPermutation; swapZero-other)

less-opposite : {n : ℕ} (i j : Fin n) → (less i j and less j i) ≡ false
less-opposite fzero fzero = refl
less-opposite fzero (fsuc j) = refl
less-opposite (fsuc i) fzero = refl
less-opposite (fsuc i) (fsuc j) = less-opposite i j

module Transposition {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A
  open Sign A
  open Cofactor A

  signature-cong : {n : ℕ} (p q : Permutation n) →
    ((i : Fin n) → to p i ≡ to q i) → signature p ≡ signature q
  signature-cong p q eq = trans (signature-product p)
    (trans (product-cong (λ i → product-cong (λ j →
      cong (λ b → flip (less i j and b)) (cong₂ less (eq j) (eq i))))) (sym (signature-product q)))

  signature-lift : {n : ℕ} (p : Permutation n) → signature (liftPerm p) ≡ signature p
  signature-lift p = trans (signature-delete (liftPerm p) fzero)
    (trans (cong₂ _*_ (*-identityˡ 1r)
      (signature-cong (minor (liftPerm p) fzero) p
        (λ i → fsuc-injective (Minor.forward-reconstruct (liftPerm p) fzero i))))
      (*-identityˡ (signature p)))

  signature-fixed : {n : ℕ} (p : Permutation n) → ((i : Fin n) → to p i ≡ i) → signature p ≡ 1r
  signature-fixed {n} p fixes = trans (signature-product p)
    (trans (product-cong {n = n} (λ i →
      trans (product-cong {n = n} (λ j →
        trans (cong (λ b → flip (less i j and b)) (cong₂ less (fixes j) (fixes i)))
          (cong flip (less-opposite i j)))) (product-one n))) (product-one n))

  module Removed {n : ℕ} (j : Fin (suc n)) where
    p : Permutation (suc (suc n))
    p = swapPermutation (fsuc j)

    q : Permutation (suc n)
    q = minor p fzero

    q-first : to q fzero ≡ j
    q-first = fsuc-injective (Minor.forward-reconstruct p fzero fzero)

    q-from-pivot : from q j ≡ fzero
    q-from-pivot = trans (sym (cong (from q) q-first)) (from-to q fzero)

    q-rest : (i : Fin n) → to q (fsuc i) ≡ skip j i
    q-rest i = fsuc-injective
      (trans (Minor.forward-reconstruct p fzero (fsuc i))
        (swapZero-other (skip j i) j (λ eq → ⊥-elim (skip-distinct j i eq))))

    double-minor-fixed : (i : Fin n) → to (minor q j) i ≡ i
    double-minor-fixed i = skip-injective j
      (trans (Minor.forward-reconstruct q j i)
        (trans (cong (to q) (cong (λ r → skip r i) q-from-pivot)) (q-rest i)))

    q-signature : signature q ≡ sign-index j
    q-signature = trans (signature-delete q j)
      (trans (cong₂ _*_
        (trans (cong (_* sign-index j) (cong sign-index q-from-pivot)) (*-identityˡ (sign-index j)))
        (signature-fixed (minor q j) double-minor-fixed)) (*-identityʳ (sign-index j)))

  signature-swap-zero : {n : ℕ} (j : Fin (suc n)) → signature (swapPermutation (fsuc j)) ≡ - 1r
  signature-swap-zero j = trans (signature-delete (swapPermutation (fsuc j)) fzero)
    (trans (cong₂ _*_ (*-identityʳ (sign-index (fsuc j))) (Removed.q-signature j))
      (trans (*-assoc (- 1r) (sign-index j) (sign-index j))
        (trans (cong ((- 1r) *_) (sign-index-square j)) (*-identityʳ (- 1r)))))
