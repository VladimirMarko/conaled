{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section02Subsets where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.Calculus.Local as Local
import SDG.Calculus.Slope as Slope
import SDG.ChapterI.Section01Algebra as S1
import SDG.ChapterI.Section02 as S2

-- The unnumbered local-domain paragraph preceding Theorem I.2.2.
-- U need not be stable: differentiation is defined precisely on points
-- whose entire first-order infinitesimal neighborhood belongs to U.
module Subsets {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open Slope.Results A K using (slope-cong)

  Domain : (R → Set ℓ) → Set ℓ
  Domain U = Σ R U

  Neighborhood : (R → Set ℓ) → R → Set ℓ
  Neighborhood U x = (d : D) → U (x + value d)

  Interior : (R → Set ℓ) → Set ℓ
  Interior U = Σ R (Neighborhood U)

  include : {U : R → Set ℓ} → Interior U → Domain U
  include {U} (x , inside) = x , subst U (+-identityʳ x) (inside zeroD)

  shifted : {U : R → Set ℓ} → Interior U → D → Domain U
  shifted (x , inside) d = (x + value d) , inside d

  subtype-path : {U : R → Set ℓ} → ((x : R) → isProp (U x)) →
    {p q : Domain U} → fst p ≡ fst q → p ≡ q
  subtype-path prop {x , p} {.x , q} refl = cong (x ,_) (prop x p q)

  derivative : {U : R → Set ℓ} → (Domain U → R) → Interior U → R
  derivative f p = slope (λ d → f (shifted p d))

  shifted-zero : {U : R → Set ℓ} → ((x : R) → isProp (U x)) →
    (p : Interior U) → shifted p zeroD ≡ include p
  shifted-zero prop (x , inside) = subtype-path prop (+-identityʳ x)

  taylor : {U : R → Set ℓ} (prop : (x : R) → isProp (U x))
    (f : Domain U → R) (p : Interior U) (d : D) →
    f (shifted p d) ≡ f (include p) + value d * derivative f p
  taylor prop f p d = trans (expansion (λ e → f (shifted p e)) d)
    (cong (_+ (value d * derivative f p)) (cong f (shifted-zero prop p)))

  derivative-unique : {U : R → Set ℓ} (prop : (x : R) → isProp (U x))
    (f : Domain U → R) (p : Interior U) (b : R) →
    ((d : D) → f (shifted p d) ≡ f (include p) + value d * b) → derivative f p ≡ b
  derivative-unique prop f p b equation = uniqueness (λ d → f (shifted p d)) b
    (λ d → trans (equation d)
      (cong (_+ (value d * b)) (sym (cong f (shifted-zero prop p)))))

  -- The derivative is independent of neighborhood witnesses, even without
  -- function extensionality identifying the witnesses themselves.
  derivative-point-cong : {U : R → Set ℓ} (prop : (x : R) → isProp (U x))
    (f : Domain U → R) {p q : Interior U} → fst p ≡ fst q → derivative f p ≡ derivative f q
  derivative-point-cong prop f {x , p} {.x , q} refl =
    slope-cong (λ d → f (shifted (x , p) d)) (λ d → f (shifted (x , q) d))
      (λ d → cong f (subtype-path prop refl))

  neighborhood-prop : (ext : FunExt ℓ ℓ) {U : R → Set ℓ} →
    ((x : R) → isProp (U x)) → (x : R) → isProp (Neighborhood U x)
  neighborhood-prop ext prop x p q = ext (λ d → prop (x + value d) (p d) (q d))

  Stable : (R → Set ℓ) → Set ℓ
  Stable U = (x : R) → U x → Neighborhood U x

  stable-interior : {U : R → Set ℓ} → Stable U → Domain U → Interior U
  stable-interior stable (x , p) = x , stable x p

  stable-include : {U : R → Set ℓ} (prop : (x : R) → isProp (U x))
    (stable : Stable U) (p : Domain U) → include (stable-interior stable p) ≡ p
  stable-include prop stable p = subtype-path prop refl

  InteriorCovers : (R → Set ℓ) → Set ℓ
  InteriorCovers U = (p : Domain U) → Σ (Interior U) (λ q → include q ≡ p)

  stable-iff-interior-covers : {U : R → Set ℓ} → ((x : R) → isProp (U x)) →
    (Stable U → InteriorCovers U) × (InteriorCovers U → Stable U)
  stable-iff-interior-covers {U} prop =
    (λ stable p → stable-interior stable p , stable-include prop stable p) ,
    (λ covers x px → subst (Neighborhood U) (cong fst (snd (covers (x , px))))
      (snd (fst (covers (x , px)))))

  stableDomain : (U : R → Set ℓ) → ((x : R) → isProp (U x)) → Stable U → Local.StableDomain A
  stableDomain U prop stable = record
    { Carrier = Domain U
    ; coordinate = fst
    ; injective = subtype-path prop
    ; shift = λ p d → (fst p + value d) , stable (fst p) (snd p) d
    ; shifted-coordinate = λ _ _ → refl
    }

  derivative-stable : (U : R → Set ℓ) (prop : (x : R) → isProp (U x))
    (stable : Stable U) (f : Domain U → R) (p : Domain U) →
    derivative f (stable-interior stable p) ≡
    Local.Calculus.derivative A K (stableDomain U prop stable) f p
  derivative-stable U prop stable f p = refl

  -- In the global case this construction is the derivative of Section02.
  derivative-restriction : {U : R → Set ℓ} (f : R → R) (p : Interior U) →
    derivative {U = U} (λ q → f (fst q)) p ≡ S2.Results.derivative A K f (fst p)
  derivative-restriction f p = refl

-- The source's particular example g:D→R has a derivative at 0, equal
-- to the slope supplied by KL. Equality of nilpotence proofs is not needed.
module InfinitesimalExample {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open Subsets A K
  open Slope.Results A K using (slope-cong)
  open S1.Results A K using (scalar-extensional)

  SquareZero : R → Set ℓ
  SquareZero x = x * x ≡ 0r

  origin : Interior SquareZero
  origin = 0r , (λ d → trans
    (cong₂ _*_ (+-identityˡ (value d)) (+-identityˡ (value d))) (square-zero d))

  from-subset : Domain SquareZero → D
  from-subset (x , proof) = infinitesimal x proof

  derivative-at-origin : (g : D → R) → derivative (g ∘ from-subset) origin ≡ slope g
  derivative-at-origin g = slope-cong
    (λ d → g (from-subset (shifted origin d))) g
    (λ d → scalar-extensional g (+-identityˡ (value d)))
