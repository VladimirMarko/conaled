{-# OPTIONS --safe --without-K #-}

module SDG.Forms.Linearization where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; tail; update; delete; replicate;
  lookup-update-same; lookup-update-other; vec-ext; compareFin; same; different;
  Permutation; permute; lookup-permute; liftPerm; permute-lift)
open import SDG.Forms.Basic
open import SDG.Forms.CubicalGeometry using (insert; insert-delete; update-insert-own)
open import SDG.Forms.AffineCharts
open import SDG.Flows.CommutingActions using (swapPermutation; swapZero)
import SDG.Combinatorics.SignatureTransposition as ST
import SDG.Forms.MixedElimination as ME
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07Linear as S7L

private
  delete-update : {a : Level} {X : Set a} {n : ℕ} (xs : Vec X (suc n)) (i : Fin (suc n)) (x : X) →
    delete (update xs i x) i ≡ delete xs i
  delete-update (y ∷ ys) fzero x = refl
  delete-update {n = suc n} (y ∷ ys) (fsuc i) x = cong (y ∷_) (delete-update ys i x)

  update-as-insert : {a : Level} {X : Set a} {n : ℕ} (xs : Vec X (suc n)) (i : Fin (suc n)) (x : X) →
    update xs i x ≡ insert i x (delete xs i)
  update-as-insert xs i x = trans (cong (λ ys → update ys i x) (sym (insert-delete xs i)))
    (update-insert-own i (lookup xs i) x (delete xs i))

  permute-swap-head : {a : Level} {X : Set a} {n : ℕ} (j : Fin (suc n)) (x : X) (xs : Vec X (suc n)) →
    permute (swapPermutation (fsuc j)) (x ∷ xs) ≡ lookup xs j ∷ update xs j x
  permute-swap-head j x xs = vec-ext (λ i →
    trans (lookup-permute (swapPermutation (fsuc j)) (x ∷ xs) i) (lookup-swap i))
    where
    lookup-swap : (i : Fin _) → lookup (x ∷ xs) (swapZero (fsuc j) i) ≡ lookup (lookup xs j ∷ update xs j x) i
    lookup-swap fzero = refl
    lookup-swap (fsuc i) with compareFin i j
    ... | same = sym (lookup-update-same xs i x)
    ... | different ne = sym (lookup-update-other xs j i x (λ p → ne (sym p)))

-- The higher cubical form depends only on its base and first-order
-- tangent directions. We prove this on every stable affine chart, rather
-- than assuming that the underlying space itself is a vector module.
module Linearize {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (W : RModule A ℓ)
  (KW : V5.VectorInfinitesimals.VectorKL A W) (U : AffineChart A W)
  (ext : FunExt ℓ ℓ) (half : CRing.R A)
  (half-law : CRing._*_ A (CRing._+_ A (CRing.1r A) (CRing.1r A)) half ≡ CRing.1r A) where
  open Geometry A W KW U public
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL KW
  open Cubes A
  open ModuleForms A (scalarModule A) using (Form; evaluate; homogeneous; alternating)
  module Signs = ST.Transposition A

  headCube : {n : ℕ} → (Vec D n → Carrier) → (Vec D n → V) → Cube (suc n) Carrier
  headCube a b (d ∷ ds) = move (a ds) d (b ds)

  module Pair {n : ℕ} (j : Fin (suc n)) (x : Vec D n → Carrier)
    (θ : Form (suc (suc n)) Carrier) where
    Directions : Set ℓ
    Directions = Vec D n → V

    q : Directions → Directions → Directions → Cube (suc (suc n)) Carrier
    q a b c (d ∷ ds) = quad (x (delete ds j)) (a (delete ds j)) (b (delete ds j)) (c (delete ds j)) d (lookup ds j)

    F : Directions → Directions → Directions → R
    F a b c = evaluate θ (q a b c)

    q-scale-first : (a b c : Directions) (r : R) (ds : Vec D (suc (suc n))) →
      scale-cube (q a b c) fzero r ds ≡ q (λ es → r • a es) b (λ es → r • c es) ds
    q-scale-first a b c r (d ∷ ds) = quad-rescale-first
      (x (delete ds j)) (a (delete ds j)) (b (delete ds j)) (c (delete ds j)) r d (lookup ds j)

    q-scale-second : (a b c : Directions) (r : R) (ds : Vec D (suc (suc n))) →
      scale-cube (q a b c) (fsuc j) r ds ≡ q a (λ es → r • b es) (λ es → r • c es) ds
    q-scale-second a b c r (d ∷ ds) =
      trans (cong₂ (λ es e → quad (x es) (a es) (b es) (c es) d e)
        (delete-update ds j (scaleD (lookup ds j) r))
        (lookup-update-same ds j (scaleD (lookup ds j) r)))
        (quad-rescale-second (x (delete ds j)) (a (delete ds j)) (b (delete ds j)) (c (delete ds j)) r d (lookup ds j))

    first-hom : (r : R) (a b c : Directions) → F (λ es → r • a es) b (λ es → r • c es) ≡ r * F a b c
    first-hom r a b c = trans (cong (evaluate θ) (sym (ext (q-scale-first a b c r))))
      (homogeneous θ (q a b c) fzero r)

    second-hom : (r : R) (a b c : Directions) → F a (λ es → r • b es) (λ es → r • c es) ≡ r * F a b c
    second-hom r a b c = trans (cong (evaluate θ) (sym (ext (q-scale-second a b c r))))
      (homogeneous θ (q a b c) (fsuc j) r)

    mixed-swap : (c : Directions) (ds : Vec D (suc (suc n))) →
      permute-cube (q (λ _ → 0v) (λ _ → 0v) c) (swapPermutation (fsuc j)) ds ≡ q (λ _ → 0v) (λ _ → 0v) c ds
    mixed-swap c (d ∷ ds) = trans (cong (q (λ _ → 0v) (λ _ → 0v) c) (permute-swap-head j d ds))
      (trans (cong₂ (λ es e → quad (x es) 0v 0v (c es) (lookup ds j) e)
        (delete-update ds j d) (lookup-update-same ds j d))
        (mixed-symmetric (x (delete ds j)) (c (delete ds j)) (lookup ds j) d))

    mixed-antisymmetric : (c : Directions) → F (λ _ → 0v) (λ _ → 0v) c ≡ (- F (λ _ → 0v) (λ _ → 0v) c)
    mixed-antisymmetric c = trans (cong (evaluate θ) (sym (ext (mixed-swap c))))
      (trans (alternating θ (q (λ _ → 0v) (λ _ → 0v) c) (swapPermutation (fsuc j)))
        (trans (cong (_* F (λ _ → 0v) (λ _ → 0v) c) (Signs.signature-swap-zero j))
          (trans (neg-mulˡ 1r (F (λ _ → 0v) (λ _ → 0v) c))
            (cong -_ (*-identityˡ (F (λ _ → 0v) (λ _ → 0v) c))))))

    independent : (a b c : Directions) → F a b c ≡ F a b (λ _ → 0v)
    independent = ME.Elimination.independent-of-mixed A K setR
      (functionModule A W (Vec D n) ext) (scalarModule A) (S7L.scalar-vectorKL A K)
      half half-law F first-hom second-hom mixed-antisymmetric

  head-erase : {n : ℕ} (θ : Form (suc n) Carrier) (a : Vec D n → Carrier) (b : Vec D n → V) (j : Fin n) →
    evaluate θ (headCube a b) ≡ evaluate θ (headCube a (λ ds → b (update ds j zeroD)))
  head-erase {zero} θ a b ()
  head-erase {suc n} θ a b j = trans (cong (evaluate θ) (ext head-reconstruct))
    (trans (P.independent first second mixed) (sym (cong (evaluate θ) (ext frozen-reconstruct))))
    where
    base : Vec D n → Carrier
    base ds = a (insert j zeroD ds)
    first second mixed : Vec D n → V
    first ds = b (insert j zeroD ds)
    second ds = slopeV (λ d → coordinates (a (insert j d ds)))
    mixed ds = slopeV (λ d → b (insert j d ds))
    module P = Pair j base θ

    head-reconstruct : (ds : Vec D (suc (suc n))) → headCube a b ds ≡ P.q first second mixed ds
    head-reconstruct (d ∷ ds) = trans
      (cong (λ es → move (a es) d (b es)) (sym (insert-delete ds j)))
      (head-slice-reconstruction (λ e → a (insert j e (delete ds j))) (λ e → b (insert j e (delete ds j))) d (lookup ds j))

    frozen-reconstruct : (ds : Vec D (suc (suc n))) →
      headCube a (λ es → b (update es j zeroD)) ds ≡ P.q first second (λ _ → 0v) ds
    frozen-reconstruct (d ∷ ds) = trans (cong (move (a ds) d) (cong b (update-as-insert ds j zeroD)))
      (trans (cong (λ es → move (a es) d (first (delete ds j))) (sym (insert-delete ds j)))
        (head-slice-frozen (λ e → a (insert j e (delete ds j))) (first (delete ds j)) d (lookup ds j)))

  head-freeze : {n : ℕ} (θ : Form (suc n) Carrier) (a : Vec D n → Carrier) (b : Vec D n → V) →
    evaluate θ (headCube a b) ≡ evaluate θ (headCube a (λ _ → b (replicate zeroD)))
  head-freeze {n} θ a = Collapse.collapse D V R zeroD ext n
    (λ b → evaluate θ (headCube a b)) (head-erase θ a)

  contraction : {n : ℕ} → Form (suc n) Carrier → V → Form n Carrier
  evaluate (contraction θ v) τ = evaluate θ (headCube τ (λ _ → v))
  homogeneous (contraction θ v) τ i r = trans (cong (evaluate θ)
    (ext (λ { (d ∷ ds) → refl }))) (homogeneous θ (headCube τ (λ _ → v)) (fsuc i) r)
  alternating (contraction θ v) τ p = trans (cong (evaluate θ)
    (ext (λ { (d ∷ ds) → refl })))
    (trans (alternating θ (headCube τ (λ _ → v)) (liftPerm p))
      (cong (_* evaluate θ (headCube τ (λ _ → v))) (Signs.signature-lift p)))

  cubeBase : {n : ℕ} → Cube n Carrier → Carrier
  cubeBase τ = τ (replicate zeroD)

  directions : {n : ℕ} → Cube n Carrier → Vec V n
  directions {zero} τ = []
  directions {suc n} τ = slopeV (λ d → coordinates (τ (d ∷ replicate zeroD))) ∷ directions (λ ds → τ (zeroD ∷ ds))

  affineCube : {n : ℕ} → Carrier → Vec V n → Cube n Carrier
  affineCube x [] [] = x
  affineCube x (v ∷ vs) (d ∷ ds) = move (affineCube x vs ds) d v

  linearization : {n : ℕ} (θ : Form n Carrier) (τ : Cube n Carrier) →
    evaluate θ τ ≡ evaluate θ (affineCube (cubeBase τ) (directions τ))
  linearization {zero} θ τ = cong (evaluate θ) (ext (λ { [] → refl }))
  linearization {suc n} θ τ = trans (cong (evaluate θ) (ext (λ { (d ∷ ds) → move-expansion (λ e → τ (e ∷ ds)) d })))
    (trans (head-freeze θ a b)
      (trans (linearization (contraction θ (b (replicate zeroD))) a)
        (cong (evaluate θ) (ext (λ { (d ∷ ds) → refl })))))
    where
    a : Vec D n → Carrier
    a ds = τ (zeroD ∷ ds)
    b : Vec D n → V
    b ds = slopeV (λ d → coordinates (τ (d ∷ ds)))
