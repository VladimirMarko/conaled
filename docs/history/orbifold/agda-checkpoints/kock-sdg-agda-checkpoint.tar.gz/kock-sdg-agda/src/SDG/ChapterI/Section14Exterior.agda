{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section14Exterior where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; delete; skip; Permutation; from; inversePerm)
open import SDG.Forms.Basic
open import SDG.Forms.CubicalGeometry
open import SDG.Combinatorics.Signature
import SDG.Combinatorics.SignatureCofactor as SC
import SDG.Forms.Module as FM
import SDG.Forms.SignedSums as SS
import SDG.Forms.InfinitesimalCoefficients as IC
import SDG.Forms.Currents as FC
import SDG.ChapterI.Section05Vector as V5

module Cubical {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ)
  (KV : V5.VectorInfinitesimals.VectorKL A Vmod) (ext : FunExt ℓ ℓ) where
  open SS.Sums A Vmod public
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL KV
  open V5.VectorCalculus A Vmod KV
  open Faces A
  open ModuleForms A Vmod
  open Sign A
  module Coefficients = IC.Coefficients A Vmod KV

  product-remove : {n : ℕ} (ds : Vec D (suc n)) (i : Fin (suc n)) →
    productD ds ≡ value (lookup ds i) * productD (delete ds i)
  product-remove (d ∷ ds) fzero = refl
  product-remove {suc n} (d ∷ ds) (fsuc i) = trans (cong (value d *_) (product-remove ds i))
    (*-swap (value d) (value (lookup ds i)) (productD (delete ds i)))

  faceCurve : {n : ℕ} {M : Set ℓ} → Form n M → Cube (suc n) M → Fin (suc n) → D → V
  faceCurve θ τ i d = evaluate θ (face τ i d)

  faceSlope : {n : ℕ} {M : Set ℓ} → Form n M → Cube (suc n) M → Fin (suc n) → V
  faceSlope θ τ i = slopeV (faceCurve θ τ i)

  -- The signed sum agrees with (-1)^(i+alpha), for source indices
  -- i=1,...,n+1: the upper face minus the lower face has sign (-1)^(i-1).
  boundaryValue : {n : ℕ} {M : Set ℓ} → Form n M → Cube (suc n) M → Vec D (suc n) → V
  boundaryValue θ τ ds = signedSum (λ i → productD (delete ds i) •
    (faceCurve θ τ i (lookup ds i) -v faceCurve θ τ i zeroD))

  exteriorValue : {n : ℕ} {M : Set ℓ} → Form n M → Cube (suc n) M → V
  exteriorValue θ τ = signedSum (faceSlope θ τ)

  face-factor : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (ds : Vec D (suc n)) (i : Fin (suc n)) →
    productD (delete ds i) • (faceCurve θ τ i (lookup ds i) -v faceCurve θ τ i zeroD) ≡
    productD ds • faceSlope θ τ i
  face-factor θ τ ds i =
    trans (cong (productD (delete ds i) •_)
      (trans (cong (λ v → v -v faceCurve θ τ i zeroD) (expansionV (faceCurve θ τ i) (lookup ds i)))
        (added-sub-base (faceCurve θ τ i zeroD) (value (lookup ds i) • faceSlope θ τ i))))
      (trans (sym (scalar-assoc (productD (delete ds i)) (value (lookup ds i)) (faceSlope θ τ i)))
        (cong (_• faceSlope θ τ i)
          (trans (*-comm (productD (delete ds i)) (value (lookup ds i))) (sym (product-remove ds i)))))

  -- Exact infinitesimal Stokes identity in every finite dimension.
  -- At this stage exteriorValue is a function on cubes; its form laws
  -- are established separately, rather than included as assumptions.
  boundary-factor : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M) (ds : Vec D (suc n)) →
    boundaryValue θ τ ds ≡ productD ds • exteriorValue θ τ
  boundary-factor θ τ ds = trans (signed-cong (face-factor θ τ ds)) (signed-scale (productD ds) (faceSlope θ τ))

  exterior-value-unique : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M) (v : V) →
    ((ds : Vec D (suc n)) → boundaryValue θ τ ds ≡ productD ds • v) → exteriorValue θ τ ≡ v
  exterior-value-unique {n} θ τ v p = Coefficients.cancel-products (suc n) (exteriorValue θ τ) v
    (λ ds → trans (sym (boundary-factor θ τ ds)) (p ds))

  exterior-add : {n : ℕ} {M : Set ℓ} (θ η : Form n M) (τ : Cube (suc n) M) →
    exteriorValue (add-form θ η) τ ≡ exteriorValue θ τ +v exteriorValue η τ
  exterior-add θ η τ = trans (signed-cong (λ i → slope-add (faceCurve θ τ i) (faceCurve η τ i)))
    (signed-add (faceSlope θ τ) (faceSlope η τ))

  exterior-scale : {n : ℕ} {M : Set ℓ} (r : R) (θ : Form n M) (τ : Cube (suc n) M) →
    exteriorValue (scale-form r θ) τ ≡ r • exteriorValue θ τ
  exterior-scale r θ τ = trans (signed-cong (λ i → slope-scale r (faceCurve θ τ i)))
    (signed-scale r (faceSlope θ τ))

  zero-slope : slopeV (λ _ → 0v) ≡ 0v
  zero-slope = uniqueSlopeV (λ _ → 0v) 0v
    (λ d → sym (trans (cong (0v +v_) (scalar-zero (value d))) (add-zeroˡ 0v)))

  exterior-zero : {n : ℕ} {M : Set ℓ} (τ : Cube (suc n) M) → exteriorValue zero-form τ ≡ 0v
  exterior-zero {n} τ = trans (signed-cong {n = suc n} (λ _ → zero-slope)) (signed-zero (suc n))

  exterior-natural : {n : ℕ} {M N : Set ℓ} (f : M → N) (θ : Form n N) (τ : Cube (suc n) M) →
    exteriorValue (pullback f θ) τ ≡ exteriorValue θ (map-cube f τ)
  exterior-natural f θ τ = refl

  slope-rescale : (f : D → V) (r : R) → slopeV (λ d → f (scaleD d r)) ≡ r • slopeV f
  slope-rescale f r = uniqueSlopeV (λ d → f (scaleD d r)) (r • slopeV f)
    (λ d → trans (expansionV f (scaleD d r))
      (trans (cong (f zeroD +v_) (scalar-assoc (value d) r (slopeV f)))
        (cong (_+v (value d • (r • slopeV f))) (sym base))))
    where
    base : f (scaleD zeroD r) ≡ f zeroD
    base = trans (expansionV f (scaleD zeroD r))
      (trans (cong (f zeroD +v_)
        (trans (cong (_• slopeV f) (*-zeroˡ r)) (zero-scalar (slopeV f)))) (add-zeroʳ (f zeroD)))

  face-slope-own : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (i : Fin (suc n)) (r : R) → faceSlope θ (scale-cube τ i r) i ≡ r • faceSlope θ τ i
  face-slope-own θ τ i r = trans (slope-cong (faceCurve θ (scale-cube τ i r) i)
    (λ d → faceCurve θ τ i (scaleD d r))
    (λ d → cong (evaluate θ) (face-scale-own ext τ i r d))) (slope-rescale (faceCurve θ τ i) r)

  face-slope-other : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (i : Fin (suc n)) (j : Fin n) (r : R) → faceSlope θ (scale-cube τ (skip i j) r) i ≡ r • faceSlope θ τ i
  face-slope-other θ τ i j r = trans (slope-cong (faceCurve θ (scale-cube τ (skip i j) r) i)
    (λ d → r • faceCurve θ τ i d)
    (λ d → trans (cong (evaluate θ) (face-scale-other ext τ i j r d)) (homogeneous θ (face τ i d) j r)))
    (slope-scale r (faceCurve θ τ i))

  face-slope-homogeneous : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (i j : Fin (suc n)) (r : R) → faceSlope θ (scale-cube τ j r) i ≡ r • faceSlope θ τ i
  face-slope-homogeneous θ τ i j r = index-cases i
    (λ k → faceSlope θ (scale-cube τ k r) i ≡ r • faceSlope θ τ i)
    (face-slope-own θ τ i r) (λ k → face-slope-other θ τ i k r) j

  exterior-homogeneous : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (i : Fin (suc n)) (r : R) → exteriorValue θ (scale-cube τ i r) ≡ r • exteriorValue θ τ
  exterior-homogeneous θ τ i r = trans (signed-cong (λ j → face-slope-homogeneous θ τ j i r))
    (signed-scale r (faceSlope θ τ))

  face-slope-permutation : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (p : Permutation (suc n)) (i : Fin (suc n)) →
    faceSlope θ (permute-cube τ p) i ≡ signature (minor p i) • faceSlope θ τ (from p i)
  face-slope-permutation θ τ p i = trans (slope-cong (faceCurve θ (permute-cube τ p) i)
    (λ d → signature (minor p i) • faceCurve θ τ (from p i) d)
    (λ d → trans (cong (evaluate θ) (face-permute ext τ p i d))
      (alternating θ (face τ (from p i) d) (minor p i))))
    (slope-scale (signature (minor p i)) (faceCurve θ τ (from p i)))

  -- The cofactor-sign identity uses the ordinary inversion-count sign.
  -- It reindexes the signed face sum under every finite permutation.
  exterior-alternating : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (p : Permutation (suc n)) → exteriorValue θ (permute-cube τ p) ≡ signature p • exteriorValue θ τ
  exterior-alternating θ τ p = trans (sum-cong (λ i →
    trans (cong (indexSign i •_) (face-slope-permutation θ τ p i))
      (trans (sym (scalar-assoc (indexSign i) (signature (minor p i)) (faceSlope θ τ (from p i))))
        (trans (cong (_• faceSlope θ τ (from p i)) (SC.Cofactor.signature-cofactor A p i))
          (scalar-assoc (signature p) (indexSign (from p i)) (faceSlope θ τ (from p i)))))))
    (trans (sum-scale (signature p) (λ i → indexSign (from p i) • faceSlope θ τ (from p i)))
      (cong (signature p •_) (sum-permute (inversePerm p) (λ i → indexSign i • faceSlope θ τ i))))

  -- Theorem I.14.5: a genuine form in every dimension, with all
  -- homogeneity and permutation laws proved from vector KL.
  exterior : {n : ℕ} {M : Set ℓ} → Form n M → Form (suc n) M
  evaluate (exterior θ) = exteriorValue θ
  homogeneous (exterior θ) = exterior-homogeneous θ
  alternating (exterior θ) = exterior-alternating θ

  infinitesimal-stokes : {n : ℕ} {M : Set ℓ} (θ : Form n M)
    (τ : Cube (suc n) M) (ds : Vec D (suc n)) →
    boundaryValue θ τ ds ≡ productD ds • evaluate (exterior θ) τ
  infinitesimal-stokes = boundary-factor

  exterior-unique : {n : ℕ} {M : Set ℓ} (θ : Form n M) (ω : Form (suc n) M) →
    ((τ : Cube (suc n) M) (ds : Vec D (suc n)) → boundaryValue θ τ ds ≡ productD ds • evaluate ω τ) →
    (τ : Cube (suc n) M) → evaluate (exterior θ) τ ≡ evaluate ω τ
  exterior-unique θ ω p τ = exterior-value-unique θ τ (evaluate ω τ) (p τ)

  boundary-cube-homogeneous : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (ds : Vec D (suc n)) (i : Fin (suc n)) (r : R) →
    boundaryValue θ (scale-cube τ i r) ds ≡ r • boundaryValue θ τ ds
  boundary-cube-homogeneous θ τ ds i r = trans (boundary-factor θ (scale-cube τ i r) ds)
    (trans (cong (productD ds •_) (exterior-homogeneous θ τ i r))
      (trans (scalar-commute (productD ds) r (exteriorValue θ τ))
        (cong (r •_) (sym (boundary-factor θ τ ds)))))

  boundary-coordinate-homogeneous : {n : ℕ} {M : Set ℓ} (θ : Form n M) (τ : Cube (suc n) M)
    (ds : Vec D (suc n)) (i : Fin (suc n)) (r : R) →
    boundaryValue θ τ (scale-coordinates ds i r) ≡ r • boundaryValue θ τ ds
  boundary-coordinate-homogeneous θ τ ds i r = trans (boundary-factor θ τ (scale-coordinates ds i r))
    (trans (cong (_• exteriorValue θ τ) (product-scaled-coordinate ds i r))
      (trans (scalar-assoc r (productD ds) (exteriorValue θ τ))
        (cong (r •_) (sym (boundary-factor θ τ ds)))))

  module Native (ext0 : FunExt lzero ℓ) (setV : isSet V) where
    open FC.Currents A Vmod ext0 ext setV public using
      (Current; current; integrate; additive; homogeneous-current; current-ext; currentsModule;
       zero-current; add-current; scale-current; negate-current; rectangle; pushforward)
    module CurrentSums (n : ℕ) (M : Set ℓ) = SS.Sums A (currentsModule n M)

    face-current : {n : ℕ} {M : Set ℓ} → Cube (suc n) M → Vec D (suc n) → Fin (suc n) → D → Current n M
    face-current τ ds i d = rectangle (face τ i d) (delete ds i)

    geometricBoundary : {n : ℕ} {M : Set ℓ} → Cube (suc n) M → Vec D (suc n) → Current n M
    geometricBoundary {n} {M} τ ds = CurrentSums.signedSum n M (λ i →
      add-current (face-current τ ds i (lookup ds i)) (negate-current (face-current τ ds i zeroD)))

    sum-evaluation : {n m : ℕ} {M : Set ℓ} (f : Fin m → Current n M) (θ : Form n M) →
      integrate (CurrentSums.sum n M f) θ ≡ sum (λ i → integrate (f i) θ)
    sum-evaluation {m = zero} f θ = refl
    sum-evaluation {m = suc m} f θ = cong (integrate (f fzero) θ +v_) (sum-evaluation (f ∘ fsuc) θ)

    signed-evaluation : {n m : ℕ} {M : Set ℓ} (f : Fin m → Current n M) (θ : Form n M) →
      integrate (CurrentSums.signedSum n M f) θ ≡ signedSum (λ i → integrate (f i) θ)
    signed-evaluation f θ = sum-evaluation (λ i → scale-current (indexSign i) (f i)) θ

    geometric-boundary-evaluation : {n : ℕ} {M : Set ℓ} (τ : Cube (suc n) M)
      (ds : Vec D (suc n)) (θ : Form n M) → integrate (geometricBoundary τ ds) θ ≡ boundaryValue θ τ ds
    geometric-boundary-evaluation τ ds θ = trans (signed-evaluation
      (λ i → add-current (face-current τ ds i (lookup ds i)) (negate-current (face-current τ ds i zeroD))) θ)
      (signed-cong (λ i → sym (scalar-sub (productD (delete ds i))
        (faceCurve θ τ i (lookup ds i)) (faceCurve θ τ i zeroD))))

    geometric-boundary-factor : {n : ℕ} {M : Set ℓ} (τ : Cube (suc n) M)
      (ds : Vec D (suc n)) (θ : Form n M) → integrate (geometricBoundary τ ds) θ ≡ productD ds • exteriorValue θ τ
    geometric-boundary-factor τ ds θ = trans (geometric-boundary-evaluation τ ds θ) (boundary-factor θ τ ds)

    exterior-add-equality : {n : ℕ} {M : Set ℓ} (θ η : Form n M) →
      exterior (add-form θ η) ≡ add-form (exterior θ) (exterior η)
    exterior-add-equality θ η = FM.Native.form-ext A Vmod ext0 ext setV (exterior-add θ η)

    exterior-scale-equality : {n : ℕ} {M : Set ℓ} (r : R) (θ : Form n M) →
      exterior (scale-form r θ) ≡ scale-form r (exterior θ)
    exterior-scale-equality r θ = FM.Native.form-ext A Vmod ext0 ext setV (exterior-scale r θ)

    exterior-natural-equality : {n : ℕ} {M N : Set ℓ} (f : M → N) (θ : Form n N) →
      exterior (pullback f θ) ≡ pullback f (exterior θ)
    exterior-natural-equality f θ = FM.Native.form-ext A Vmod ext0 ext setV (exterior-natural f θ)

    exterior-native-unique : {n : ℕ} {M : Set ℓ} (θ : Form n M) (ω : Form (suc n) M) →
      ((τ : Cube (suc n) M) (ds : Vec D (suc n)) → integrate (geometricBoundary τ ds) θ ≡ integrate (rectangle τ ds) ω) →
      exterior θ ≡ ω
    exterior-native-unique θ ω p = FM.Native.form-ext A Vmod ext0 ext setV
      (exterior-unique θ ω (λ τ ds → trans (sym (geometric-boundary-evaluation τ ds θ)) (p τ ds)))

    -- Current-theoretic boundary on all currents, after the independently
    -- constructed geometric boundary has produced the exterior derivative.
    currentBoundary : {n : ℕ} {M : Set ℓ} → Current (suc n) M → Current n M
    integrate (currentBoundary γ) θ = integrate γ (exterior θ)
    additive (currentBoundary γ) θ η = trans (cong (integrate γ) (exterior-add-equality θ η))
      (additive γ (exterior θ) (exterior η))
    homogeneous-current (currentBoundary γ) r θ = trans (cong (integrate γ) (exterior-scale-equality r θ))
      (homogeneous-current γ r (exterior θ))

    infinitesimal-current-stokes : {n : ℕ} {M : Set ℓ} (τ : Cube (suc n) M) (ds : Vec D (suc n)) →
      currentBoundary (rectangle τ ds) ≡ geometricBoundary τ ds
    infinitesimal-current-stokes τ ds = current-ext (λ θ → sym (geometric-boundary-factor τ ds θ))

    boundary-natural : {n : ℕ} {M N : Set ℓ} (f : M → N) (γ : Current (suc n) M) →
      currentBoundary (pushforward f γ) ≡ pushforward f (currentBoundary γ)
    boundary-natural f γ = current-ext (λ θ → cong (integrate γ) (sym (exterior-natural-equality f θ)))
