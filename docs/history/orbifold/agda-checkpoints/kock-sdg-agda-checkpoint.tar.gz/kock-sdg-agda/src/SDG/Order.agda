{-# OPTIONS --safe --without-K #-}

module SDG.Order where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.Algebra.Nilradical as NR
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section01 as S1

-- The order structure assumed in Kock I.13, equations (13.1)--(13.2).
-- It is a proposition-valued preorder. Antisymmetry is deliberately absent.
record CompatiblePreorder {ℓ : Level} (A : CRing ℓ) : Set (lsuc ℓ) where
  open CRing A
  infix 4 _≤_
  field
    _≤_ : R → R → Set ℓ
    relation-prop : (x y : R) → isProp (x ≤ y)
    reflexive : (x : R) → x ≤ x
    transitive : {x y z : R} → x ≤ y → y ≤ z → x ≤ z
    add-right : {x y : R} → x ≤ y → (z : R) → (x + z) ≤ (y + z)
    multiply-positive : {x y : R} → x ≤ y → (t : R) → 0r ≤ t → (x * t) ≤ (y * t)
    zero-one : 0r ≤ 1r
    nilpotent-order : (x : R) → NR.Results.Nilpotent A x → (0r ≤ x) × (x ≤ 0r)

module Intervals {ℓ : Level} (A : CRing ℓ) (O : CompatiblePreorder A) where
  open RingLemmas A public
  open CompatiblePreorder O public
  open Infinitesimals A
  module N = NR.Results A

  order-cong : {x y x′ y′ : R} → x ≡ x′ → y ≡ y′ → x ≤ y → x′ ≤ y′
  order-cong refl refl p = p

  add-left : {x y : R} → x ≤ y → (z : R) → (z + x) ≤ (z + y)
  add-left {x} {y} p z = order-cong (+-comm x z) (+-comm y z) (add-right p z)

  add-both : {x y u v : R} → x ≤ y → u ≤ v → (x + u) ≤ (y + v)
  add-both {y = y} {u} p q = transitive (add-right p u) (add-left q y)

  multiply-positive-left : {x y : R} → x ≤ y → (t : R) → 0r ≤ t → (t * x) ≤ (t * y)
  multiply-positive-left {x} {y} p t positive =
    order-cong (*-comm x t) (*-comm y t) (multiply-positive p t positive)

  difference-nonnegative : {x y : R} → x ≤ y → 0r ≤ (y - x)
  difference-nonnegative {x} p = order-cong (+-inverseʳ x) refl (add-right p (- x))

  nilpotent-add-above : (x d : R) → N.Nilpotent d → x ≤ (x + d)
  nilpotent-add-above x d nil =
    order-cong (+-identityʳ x) refl (add-left (fst (nilpotent-order d nil)) x)

  nilpotent-add-below : (x d : R) → N.Nilpotent d → (x + d) ≤ x
  nilpotent-add-below x d nil =
    order-cong refl (+-identityʳ x) (add-left (snd (nilpotent-order d nil)) x)

  square-zero-nilpotent : (d : D) → N.Nilpotent (value d)
  square-zero-nilpotent d = suc zero , trans (N.power-two (value d)) (square-zero d)

  Member : R → R → R → Set ℓ
  Member a b x = (a ≤ x) × (x ≤ b)

  member-prop : (a b x : R) → isProp (Member a b x)
  member-prop a b x (p , q) (p′ , q′) =
    cong₂ _,_ (relation-prop a x p p′) (relation-prop x b q q′)

  Interval : R → R → Set ℓ
  Interval a b = Σ R (Member a b)

  coordinate : {a b : R} → Interval a b → R
  coordinate = fst

  interval-ext : {a b : R} {x y : Interval a b} → coordinate x ≡ coordinate y → x ≡ y
  interval-ext {a} {b} {x , p} {.x , q} refl = cong (x ,_) (member-prop a b x p q)

  left-endpoint : {a b : R} → a ≤ b → Interval a b
  left-endpoint {a} p = a , reflexive a , p

  right-endpoint : {a b : R} → a ≤ b → Interval a b
  right-endpoint {b = b} p = b , p , reflexive b

  member-nilpotent-shift : {a b x : R} → Member a b x → (d : R) → N.Nilpotent d → Member a b (x + d)
  member-nilpotent-shift {x = x} (lower , upper) d nil =
    transitive lower (nilpotent-add-above x d nil) , transitive (nilpotent-add-below x d nil) upper

  shift : {a b : R} → Interval a b → D → Interval a b
  shift (x , p) d = (x + value d) , member-nilpotent-shift p (value d) (square-zero-nilpotent d)

  intervalDomain : (a b : R) → Local.StableDomain A
  intervalDomain a b = record
    { Carrier = Interval a b
    ; coordinate = coordinate
    ; injective = interval-ext
    ; shift = shift
    ; shifted-coordinate = λ _ _ → refl
    }

  upper-endpoint-forward : {a b x : R} (d : R) → N.Nilpotent d → Member a b x → Member a (b + d) x
  upper-endpoint-forward {b = b} d nil (p , q) = p , transitive q (nilpotent-add-above b d nil)

  upper-endpoint-backward : {a b x : R} (d : R) → N.Nilpotent d → Member a (b + d) x → Member a b x
  upper-endpoint-backward {b = b} d nil (p , q) = p , transitive q (nilpotent-add-below b d nil)

  -- Equality of these intervals is equality of membership predicates;
  -- the endpoint labels are still retained in the types of the intervals.
  interval-endpoint-invariance : (a b d x : R) → N.Nilpotent d →
    (Member a b x → Member a (b + d) x) × (Member a (b + d) x → Member a b x)
  interval-endpoint-invariance a b d x nil = upper-endpoint-forward d nil , upper-endpoint-backward d nil

  blend : R → R → R → R
  blend x y t = x + t * (y - x)

  difference-add-back : (x y : R) → x + (y - x) ≡ y
  difference-add-back x y = trans (+-swap x y (- x))
    (trans (cong (y +_) (+-inverseʳ x)) (+-identityʳ y))

  blend-zero : (x y : R) → blend x y 0r ≡ x
  blend-zero x y = trans (cong (x +_) (*-zeroˡ (y - x))) (+-identityʳ x)

  blend-one : (x y : R) → blend x y 1r ≡ y
  blend-one x y = trans (cong (x +_) (*-identityˡ (y - x))) (difference-add-back x y)

  weighted-to-blend : (x y t : R) → (1r - t) * x + t * y ≡ blend x y t
  weighted-to-blend x y t =
    trans (cong (_+ (t * y)) (distribʳ 1r (- t) x))
      (trans (cong (λ z → (z + (- t) * x) + t * y) (*-identityˡ x))
        (trans (+-assoc x ((- t) * x) (t * y))
          (cong (x +_)
            (trans (+-comm ((- t) * x) (t * y))
              (trans (cong ((t * y) +_)
                (trans (neg-mulˡ t x) (sym (neg-mulʳ t x))))
                (sym (distribˡ t y (- x))))))))

  weights-sum : (x t : R) → (1r - t) * x + t * x ≡ x
  weights-sum x t = trans (sym (distribʳ (1r - t) t x))
    (trans (cong (_* x)
      (trans (+-assoc 1r (- t) t)
        (trans (cong (1r +_) (+-inverseˡ t)) (+-identityʳ 1r)))) (*-identityˡ x))

  convex : {a b x y t : R} → Member a b x → Member a b y → Member 0r 1r t → Member a b (blend x y t)
  convex {a} {b} {x} {y} {t} (ax , xb) (ay , yb) (t0 , t1) =
    order-cong (weights-sum a t) (weighted-to-blend x y t)
      (add-both (multiply-positive-left ax (1r - t) (difference-nonnegative t1))
        (multiply-positive-left ay t t0)) ,
    order-cong (weighted-to-blend x y t) (weights-sum b t)
      (add-both (multiply-positive-left xb (1r - t) (difference-nonnegative t1))
        (multiply-positive-left yb t t0))

  UnitInterval : Set ℓ
  UnitInterval = Interval 0r 1r

  zero-point one-point : UnitInterval
  zero-point = left-endpoint zero-one
  one-point = right-endpoint zero-one

  path : {a b : R} → Interval a b → Interval a b → UnitInterval → Interval a b
  path (x , px) (y , py) (t , pt) = blend x y t , convex px py pt

  path-zero : {a b : R} (x y : Interval a b) → path x y zero-point ≡ x
  path-zero x y = interval-ext (blend-zero (coordinate x) (coordinate y))

  path-one : {a b : R} (x y : Interval a b) → path x y one-point ≡ y
  path-one x y = interval-ext (blend-one (coordinate x) (coordinate y))

  antisymmetry-impossible : (K : KockLawvere) → 0r ≢ 1r →
    ¬ ((x y : R) → x ≤ y → y ≤ x → x ≡ y)
  antisymmetry-impossible K nontrivial antisymmetric = nontrivial
    (S1.Results.cancel-infinitesimals A K 0r 1r (λ d →
      trans (*-zeroʳ (value d))
        (trans (sym (antisymmetric (value d) 0r
          (snd (nilpotent-order (value d) (square-zero-nilpotent d)))
          (fst (nilpotent-order (value d) (square-zero-nilpotent d)))))
          (sym (*-identityʳ (value d))))))
