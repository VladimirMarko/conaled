{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section01 where

open import Agda.Primitive using (Level)
open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom

-- Kock I.1: affine maps on square-zero infinitesimals.
module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K

  affine : R → R → D → R
  affine a b d = a + value d * b

  affine-at-zero : (a b : R) → affine a b zeroD ≡ a
  affine-at-zero a b =
    trans (cong (a +_) (*-zeroˡ b)) (+-identityʳ a)

  slope-affine : (a b : R) → slope (affine a b) ≡ b
  slope-affine a b = uniqueness (affine a b) b
    (λ d → cong (_+ (value d * b)) (sym (affine-at-zero a b)))

  -- Universally quantified infinitesimals can be cancelled.
  cancel-infinitesimals : (b c : R) →
    ((d : D) → value d * b ≡ value d * c) → b ≡ c
  cancel-infinitesimals b c p =
    trans (sym (uniqueness (λ d → value d * b) b
      (λ d → sym (trans (cong (_+ (value d * b)) (*-zeroˡ b))
        (+-identityˡ (value d * b))))))
      (uniqueness (λ d → value d * b) c
        (λ d → trans (p d)
          (sym (trans (cong (_+ (value d * c)) (*-zeroˡ b))
            (+-identityˡ (value d * c))))))

  Dual : Set ℓ
  Dual = R × R

  encode : Dual → D → R
  encode (a , b) = affine a b

  decode : (D → R) → Dual
  decode g = g zeroD , slope g

  decode-encode : (p : Dual) → decode (encode p) ≡ p
  decode-encode (a , b) =
    cong₂ _,_ (affine-at-zero a b) (slope-affine a b)

  -- The function-space inverse law is pointwise: no funext is assumed.
  encode-decode : (g : D → R) (d : D) → encode (decode g) d ≡ g d
  encode-decode g d = sym (expansion g d)

  dual-add : Dual → Dual → Dual
  dual-add (a , b) (c , e) = (a + c) , (b + e)

  dual-mul : Dual → Dual → Dual
  dual-mul (a , b) (c , e) = (a * c) , (a * e + c * b)

  -- Proposition I.1.1, multiplication part.
  encode-product : (p q : Dual) (d : D) →
    encode (dual-mul p q) d ≡ encode p d * encode q d
  encode-product (a , b) (c , e) d =
    sym (affine-product (value d) a b c e (square-zero d))

  encode-sum : (p q : Dual) (d : D) →
    encode (dual-add p q) d ≡ encode p d + encode q d
  encode-sum (a , b) (c , e) d =
    trans (cong ((a + c) +_) (distribˡ (value d) b e))
      (+-shuffle a c (value d * b) (value d * e))

  encode-one : (d : D) → encode (1r , 0r) d ≡ 1r
  encode-one d =
    trans (cong (1r +_) (*-zeroʳ (value d))) (+-identityʳ 1r)

  encode-zero : (d : D) → encode (0r , 0r) d ≡ 0r
  encode-zero d =
    trans (+-identityˡ (value d * 0r)) (*-zeroʳ (value d))

