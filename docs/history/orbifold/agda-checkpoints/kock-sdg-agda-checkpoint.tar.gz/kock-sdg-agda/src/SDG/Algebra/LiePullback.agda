{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.LiePullback where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Endomorphisms using (LieAlgebra)

-- Lie identities pull back along an injective linear bracket-preserving
-- map. This is a theorem about a given target Lie algebra, not a source
-- Lie-law assumption.
module Pullback {a u v : Level} (A : CRing a)
  (Umod : RModule A u) (Vmod : RModule A v) (L : LieAlgebra A Vmod)
  (br : RModule.V Umod → RModule.V Umod → RModule.V Umod)
  (map : RModule.V Umod → RModule.V Vmod)
  (map-zero : map (RModule.0v Umod) ≡ RModule.0v Vmod)
  (map-add : (x y : RModule.V Umod) →
    map (RModule._+v_ Umod x y) ≡ RModule._+v_ Vmod (map x) (map y))
  (map-scale : (r : CRing.R A) (x : RModule.V Umod) →
    map (RModule._•_ Umod r x) ≡ RModule._•_ Vmod r (map x))
  (map-bracket : (x y : RModule.V Umod) →
    map (br x y) ≡ LieAlgebra.bracket L (map x) (map y))
  (injective : {x y : RModule.V Umod} → map x ≡ map y → x ≡ y) where
  open RModule Umod
  module T = RModule Vmod
  module L = LieAlgebra L

  abstract
    add-left : (x y z : V) → br (x +v y) z ≡ br x z +v br y z
    add-left x y z = injective
      (trans (map-bracket (x +v y) z)
        (trans (cong (λ w → L.bracket w (map z)) (map-add x y))
          (trans (L.bracket-addˡ (map x) (map y) (map z))
            (sym (trans (map-add (br x z) (br y z))
              (cong₂ T._+v_ (map-bracket x z) (map-bracket y z)))))))

    add-right : (x y z : V) → br x (y +v z) ≡ br x y +v br x z
    add-right x y z = injective
      (trans (map-bracket x (y +v z))
        (trans (cong (L.bracket (map x)) (map-add y z))
          (trans (L.bracket-addʳ (map x) (map y) (map z))
            (sym (trans (map-add (br x y) (br x z))
              (cong₂ T._+v_ (map-bracket x y) (map-bracket x z)))))))

    scale-left : (r : CRing.R A) (x y : V) → br (r • x) y ≡ r • br x y
    scale-left r x y = injective
      (trans (map-bracket (r • x) y)
        (trans (cong (λ w → L.bracket w (map y)) (map-scale r x))
          (trans (L.bracket-scaleˡ r (map x) (map y))
            (sym (trans (map-scale r (br x y)) (cong (T._•_ r) (map-bracket x y)))))))

    scale-right : (r : CRing.R A) (x y : V) → br x (r • y) ≡ r • br x y
    scale-right r x y = injective
      (trans (map-bracket x (r • y))
        (trans (cong (L.bracket (map x)) (map-scale r y))
          (trans (L.bracket-scaleʳ r (map x) (map y))
            (sym (trans (map-scale r (br x y)) (cong (T._•_ r) (map-bracket x y)))))))

    alternating : (x : V) → br x x ≡ 0v
    alternating x = injective (trans (map-bracket x x) (trans (L.alternating (map x)) (sym map-zero)))

    skew : (x y : V) → br x y +v br y x ≡ 0v
    skew x y = injective (trans (map-add (br x y) (br y x))
      (trans (cong₂ T._+v_ (map-bracket x y) (map-bracket y x))
        (trans (L.skew (map x) (map y)) (sym map-zero))))

    nested : (x y z : V) → map (br x (br y z)) ≡ L.bracket (map x) (L.bracket (map y) (map z))
    nested x y z = trans (map-bracket x (br y z)) (cong (L.bracket (map x)) (map-bracket y z))

    jacobi : (x y z : V) → (br x (br y z) +v br y (br z x)) +v br z (br x y) ≡ 0v
    jacobi x y z = injective
      (trans (map-add (br x (br y z) +v br y (br z x)) (br z (br x y)))
        (trans (cong (λ w → T._+v_ w (map (br z (br x y))))
          (map-add (br x (br y z)) (br y (br z x))))
          (trans (cong₂ T._+v_ (cong₂ T._+v_ (nested x y z) (nested y z x)) (nested z x y))
            (trans (L.jacobi (map x) (map y) (map z)) (sym map-zero)))))

  lieAlgebra : LieAlgebra A Umod
  lieAlgebra = record
    { bracket = br; bracket-addˡ = add-left; bracket-addʳ = add-right
    ; bracket-scaleˡ = scale-left; bracket-scaleʳ = scale-right
    ; alternating = alternating; skew = skew; jacobi = jacobi }
