{-# OPTIONS --safe --without-K #-}
module SDG.Schemes.Reflexivity where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Algebras
open import SDG.Schemes.Isomorphism
open import SDG.Schemes.Extensionality

module Reflexivity {ℓ : Level} (A : CRing ℓ) (ext : FunExt ℓ ℓ)
  (setR : isSet (CRing.R A)) where
  open CRing A using (R)

  DoubleDual : Set ℓ → Set ℓ
  DoubleDual M = AlgHom (functionAlgebra A M ext) (scalarAlgebra A)

  record Reflexive (M : Set ℓ) : Set ℓ where
    field
      recover : DoubleDual M → M
      recover-evaluation : (m : M) → recover (evaluation A M ext m) ≡ m
      evaluation-recover : (h : DoubleDual M) → evaluation A M ext (recover h) ≡ h
  open Reflexive public

  reflexive-isomorphism : {M : Set ℓ} → Reflexive M → Isomorphism M (DoubleDual M)
  reflexive-isomorphism {M} r = isomorphism (evaluation A M ext) (recover r)
    (recover-evaluation r) (evaluation-recover r)

  points-detected : {M : Set ℓ} → Reflexive M → (x y : M) →
    ((f : M → R) → f x ≡ f y) → x ≡ y
  points-detected {M} r x y p =
    trans (sym (recover-evaluation r x))
      (trans (cong (recover r) (algHom-ext ext ext ext setR p)) (recover-evaluation r y))

  doubledual-set : (M : Set ℓ) → isSet (DoubleDual M)
  doubledual-set M = injection-set algMap
    (λ eq → algHom-ext ext ext ext setR (λ f → cong (λ h → h f) eq))
    (function-set ext (λ _ → setR))

  reflexive-set : {M : Set ℓ} → Reflexive M → isSet M
  reflexive-set {M} r = injection-set (evaluation A M ext)
    (λ {x} {y} p → trans (sym (recover-evaluation r x))
      (trans (cong (recover r) p) (recover-evaluation r y))) (doubledual-set M)

  -- Reflexivity also recovers parameterized maps, with all equations
  -- tracked on the actual precomposition homomorphism.
  maps-from-hom : {M : Set ℓ} → Reflexive M → (X : Set ℓ) →
    AlgHom (functionAlgebra A M ext) (functionAlgebra A X ext) → X → M
  maps-from-hom r X h x = recover r (composeAlgHom (evaluation A X ext x) h)

  precomposition-from-hom : {M : Set ℓ} (r : Reflexive M) (X : Set ℓ)
    (h : AlgHom (functionAlgebra A M ext) (functionAlgebra A X ext)) →
    precomposition A ext (maps-from-hom r X h) ≡ h
  precomposition-from-hom r X h = algHom-ext ext ext ext (function-set ext (λ _ → setR))
    (λ f → ext (λ x → cong (λ q → algMap q f)
      (evaluation-recover r (composeAlgHom (evaluation A X ext x) h))))

  from-hom-precomposition : {M : Set ℓ} (r : Reflexive M) (X : Set ℓ) (f : X → M) →
    maps-from-hom r X (precomposition A ext f) ≡ f
  from-hom-precomposition r X f = ext (λ x →
    trans (cong (recover r) (algHom-ext ext ext ext setR (λ g → refl)))
      (recover-evaluation r (f x)))

  parameterized-isomorphism : {M : Set ℓ} (r : Reflexive M) (X : Set ℓ) →
    Isomorphism (X → M) (AlgHom (functionAlgebra A M ext) (functionAlgebra A X ext))
  parameterized-isomorphism r X = isomorphism (precomposition A ext) (maps-from-hom r X)
    (from-hom-precomposition r X) (precomposition-from-hom r X)
