{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section10Bracket where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section10 as S10

-- Theorem 10.3(iii), obtained from the actual geometric commutator.
module BracketDerivative {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (Vmod : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A Vmod)
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M)
  (SpaceW : S4.Results.PropertyW A K M) where
  open Extra A Vmod
  open Infinitesimals A
  open S7.Basics A setR using (negateD)
  open S8.Basics A setR
  open S8.Linear A setR IL using (inverse-right)
  open V5.VectorCalculus A Vmod KV using (cancel-infinitesimals)
  open S10.Calculus A K setR Vmod KV
  open S9.Lie A K setR IL SpaceW using (bracket; commutator; bracket-characterization)
  open S4.Results A K using (productD)

  increment : (X : VectorField M) (f : M → V) (m : M) (d : D) →
    f (run X m d) -v f m ≡ value d • directional X f m
  increment X f m d = trans (cong (λ z → z -v f m) (directional-taylor X f m d))
    (added-sub-base (f m) (value d • directional X f m))

  decrement : (X : VectorField M) (f : M → V) (m : M) (d : D) →
    f m -v f (run X m d) ≡ (- value d) • directional X f m
  decrement X f m d = trans (cong (λ z → f m -v z) (directional-taylor X f m d))
    (trans (base-sub-added (f m) (value d • directional X f m))
      (sym (neg-scalar (value d) (directional X f m))))

  annihilate-movement : (X : VectorField M) (g : M → V) (m : M) (d : D) →
    value d • g (run X m d) ≡ value d • g m
  annihilate-movement X g m d = trans (cong (value d •_) (directional-taylor X g m d))
    (trans (scalar-distrib (value d) (g m) (value d • directional X g m))
      (trans (cong ((value d • g m) +v_)
        (scalar-square-zero (value d) (square-zero d) (directional X g m)))
        (add-zeroʳ (value d • g m))))

  product-annihilate-one : (X : VectorField M) (g : M → V) (m : M) (d e : D) →
    (value d * value e) • g (run X m d) ≡ (value d * value e) • g m
  product-annihilate-one X g m d e =
    trans (scalar-assoc (value d) (value e) (g (run X m d)))
      (trans (scalar-commute (value d) (value e) (g (run X m d)))
        (trans (cong (value e •_) (annihilate-movement X g m d))
          (trans (scalar-commute (value e) (value d) (g m))
            (sym (scalar-assoc (value d) (value e) (g m))))))

  product-annihilate-two : (X Y : VectorField M) (g : M → V) (m : M) (d e : D) →
    (value d * value e) • g (run Y (run X m d) e) ≡ (value d * value e) • g m
  product-annihilate-two X Y g m d e =
    trans (scalar-assoc (value d) (value e) (g (run Y (run X m d) e)))
      (trans (cong (value d •_) (annihilate-movement Y g (run X m d) e))
        (trans (sym (scalar-assoc (value d) (value e) (g (run X m d))))
          (product-annihilate-one X g m d e)))

  negated-scalar-difference : (r : R) (a b : V) →
    ((- r) • a) -v ((- r) • b) ≡ r • (b -v a)
  negated-scalar-difference r a b =
    trans (cong₂ _-v_ (neg-scalar r a) (neg-scalar r b))
      (trans (negative-difference (r • a) (r • b)) (sym (scalar-sub r b a)))

  commutator-difference : (X Y : VectorField M) (f : M → V) (m : M) (d e : D) →
    f (commutator X Y m d e) -v f m ≡
      (value d * value e) • (directional X (directional Y f) m -v directional Y (directional X f) m)
  commutator-difference X Y f m d e =
    begin
      f (commutator X Y m d e) -v f m
    ≡⟨ cong₂ _-v_ forward-circuit reverse-circuit ⟩
      ((f p +v (- value d) • xf p) +v (- value e) • yf q) -v
        ((f p +v (- value e) • yf p) +v (- value d) • xf n)
    ≡⟨ sub-from-common (f p) ((- value d) • xf p) ((- value e) • yf q)
          ((- value e) • yf p) ((- value d) • xf n) ⟩
      (((- value d) • xf p) -v ((- value d) • xf n)) +v
        (((- value e) • yf q) -v ((- value e) • yf p))
    ≡⟨ cong₂ _+v_ (negated-scalar-difference (value d) (xf p) (xf n))
          (negated-scalar-difference (value e) (yf q) (yf p)) ⟩
      value d • (xf n -v xf p) +v value e • (yf p -v yf q)
    ≡⟨ cong₂ _+v_ (cong (value d •_) (decrement Y xf n e))
          (cong (value e •_) (trans (decrement X yf p (negateD d))
            (cong (_• directional X yf p) (neg-involutive (value d))))) ⟩
      value d • ((- value e) • yxf n) +v value e • (value d • xyf p)
    ≡⟨ cong₂ _+v_ first-term second-term ⟩
      (-v ((value d * value e) • yxf m)) +v (value d * value e) • xyf m
    ≡⟨ add-comm (-v ((value d * value e) • yxf m)) ((value d * value e) • xyf m) ⟩
      ((value d * value e) • xyf m) -v ((value d * value e) • yxf m)
    ≡⟨ sym (scalar-sub (value d * value e) (xyf m) (yxf m)) ⟩
      (value d * value e) • (xyf m -v yxf m) ∎
    where
    n = run X m d
    p = run Y n e
    q = run X p (negateD d)
    xf = directional X f
    yf = directional Y f
    xyf = directional X yf
    yxf = directional Y xf

    forward-circuit : f (commutator X Y m d e) ≡
      (f p +v (- value d) • xf p) +v (- value e) • yf q
    forward-circuit = trans (directional-taylor Y f q (negateD e))
      (cong (_+v ((- value e) • yf q)) (directional-taylor X f p (negateD d)))

    reverse-circuit : f m ≡ (f p +v (- value e) • yf p) +v (- value d) • xf n
    reverse-circuit = trans (cong f (sym (inverse-right X m d)))
      (trans (directional-taylor X f n (negateD d))
        (cong (_+v ((- value d) • xf n))
          (trans (cong f (sym (inverse-right Y n e))) (directional-taylor Y f p (negateD e)))))

    first-term : value d • ((- value e) • yxf n) ≡ (-v ((value d * value e) • yxf m))
    first-term = trans (cong (value d •_) (neg-scalar (value e) (yxf n)))
      (trans (scalar-neg (value d) (value e • yxf n))
        (cong -v_ (trans (sym (scalar-assoc (value d) (value e) (yxf n)))
          (product-annihilate-one X yxf m d e))))

    second-term : value e • (value d • xyf p) ≡ (value d * value e) • xyf m
    second-term = trans (scalar-commute (value e) (value d) (xyf p))
      (trans (sym (scalar-assoc (value d) (value e) (xyf p)))
        (product-annihilate-two X Y xyf m d e))

  bracket-derivative : (X Y : VectorField M) (f : M → V) (m : M) →
    directional (bracket X Y) f m ≡
      directional X (directional Y f) m -v directional Y (directional X f) m
  bracket-derivative X Y f m = cancel-infinitesimals b c (λ e →
    cancel-infinitesimals (value e • b) (value e • c) (λ d →
      trans (sym (scalar-assoc (value d) (value e) b))
        (trans (comparison d e) (scalar-assoc (value d) (value e) c))))
    where
    b = directional (bracket X Y) f m
    c = directional X (directional Y f) m -v directional Y (directional X f) m
    comparison : (d e : D) → (value d * value e) • b ≡ (value d * value e) • c
    comparison d e =
      trans (sym (increment (bracket X Y) f m (productD d e)))
        (trans (cong (λ z → f z -v f m) (bracket-characterization X Y m d e))
          (commutator-difference X Y f m d e))

