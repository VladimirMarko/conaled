{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section02 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.ChapterI.Section01 as S1

-- Global-line cases of I.2.1--I.2.3. Stable-domain versions are separate.
module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open S1.Results A K using (cancel-infinitesimals)

  derivative : (R → R) → R → R
  derivative f x = slope (λ d → f (x + value d))

  taylor : (f : R → R) (x : R) (d : D) →
    f (x + value d) ≡ f x + value d * derivative f x
  taylor f x d =
    trans (expansion (λ e → f (x + value e)) d)
      (cong (_+ (value d * derivative f x)) (cong f (+-identityʳ x)))

  derivative-unique : (f : R → R) (x b : R) →
    ((d : D) → f (x + value d) ≡ f x + value d * b) →
    derivative f x ≡ b
  derivative-unique f x b p =
    uniqueness (λ d → f (x + value d)) b
      (λ d → trans (p d)
        (cong (_+ (value d * b)) (cong f (sym (+-identityʳ x)))))

  derivative-cong : (f g : R → R) →
    ((x : R) → f x ≡ g x) → (x : R) → derivative f x ≡ derivative g x
  derivative-cong f g p x = derivative-unique f x (derivative g x)
    (λ d → trans (p (x + value d))
      (trans (taylor g x d)
        (cong (_+ (value d * derivative g x)) (sym (p x)))))

  derivative-constant : (r x : R) → derivative (λ _ → r) x ≡ 0r
  derivative-constant r x = derivative-unique (λ _ → r) x 0r
    (λ d → sym (trans (cong (r +_) (*-zeroʳ (value d))) (+-identityʳ r)))

  derivative-identity : (x : R) → derivative (λ t → t) x ≡ 1r
  derivative-identity x = derivative-unique (λ t → t) x 1r
    (λ d → cong (x +_) (sym (*-identityʳ (value d))))

  derivative-add : (f g : R → R) (x : R) →
    derivative (λ t → f t + g t) x ≡ derivative f x + derivative g x
  derivative-add f g x =
    derivative-unique (λ t → f t + g t) x (derivative f x + derivative g x)
      (λ d →
        trans (cong₂ _+_ (taylor f x d) (taylor g x d))
          (trans (+-shuffle (f x) (value d * derivative f x)
                    (g x) (value d * derivative g x))
            (cong ((f x + g x) +_)
              (sym (distribˡ (value d) (derivative f x) (derivative g x))))))

  derivative-scale : (r : R) (f : R → R) (x : R) →
    derivative (λ t → r * f t) x ≡ r * derivative f x
  derivative-scale r f x =
    derivative-unique (λ t → r * f t) x (r * derivative f x)
      (λ d → trans (cong (r *_) (taylor f x d))
        (trans (distribˡ r (f x) (value d * derivative f x))
          (cong ((r * f x) +_) (*-swap r (value d) (derivative f x)))))

  derivative-product : (f g : R → R) (x : R) →
    derivative (λ t → f t * g t) x ≡
      f x * derivative g x + g x * derivative f x
  derivative-product f g x =
    derivative-unique (λ t → f t * g t) x
      (f x * derivative g x + g x * derivative f x)
      (λ d → trans (cong₂ _*_ (taylor f x d) (taylor g x d))
        (affine-product (value d) (f x) (derivative f x)
          (g x) (derivative g x) (square-zero d)))

  leibniz : (f g : R → R) (x : R) →
    derivative (λ t → f t * g t) x ≡
      derivative f x * g x + f x * derivative g x
  leibniz f g x =
    trans (derivative-product f g x)
      (trans (+-comm (f x * derivative g x) (g x * derivative f x))
        (cong (_+ (f x * derivative g x)) (*-comm (g x) (derivative f x))))

  derivative-chain : (f g : R → R) (x : R) →
    derivative (f ∘ g) x ≡ derivative f (g x) * derivative g x
  derivative-chain f g x =
    derivative-unique (f ∘ g) x (derivative f (g x) * derivative g x)
      (λ d → trans (cong f (taylor g x d))
        (trans (taylor f (g x) (scaleD d (derivative g x)))
          (cong (f (g x) +_)
            (trans (*-assoc (value d) (derivative g x) (derivative f (g x)))
              (cong (value d *_) (*-comm (derivative g x) (derivative f (g x))))))))

  derivative-neg : (f : R → R) (x : R) →
    derivative (λ t → - f t) x ≡ (- derivative f x)
  derivative-neg f x =
    derivative-unique (λ t → - f t) x (- derivative f x)
      (λ d → trans (cong -_ (taylor f x d))
        (trans (neg-add (f x) (value d * derivative f x))
          (cong ((- f x) +_) (sym (neg-mulʳ (value d) (derivative f x))))))

  iterate : ℕ → (R → R) → R → R
  iterate zero f = f
  iterate (suc n) f = derivative (iterate n f)

  -- The second-order formula before division by 2; only Axiom 1 is needed.
  taylor-two : (f : R → R) (x : R) (d e : D) →
    f (x + (value d + value e)) ≡
      (f x + (value d + value e) * derivative f x) +
      (value d * value e) * derivative (derivative f) x
  taylor-two f x d e =
    begin
      f (x + (value d + value e))
    ≡⟨ cong f (sym (+-assoc x (value d) (value e))) ⟩
      f ((x + value d) + value e)
    ≡⟨ taylor f (x + value d) e ⟩
      f (x + value d) + value e * derivative f (x + value d)
    ≡⟨ cong₂ _+_ (taylor f x d)
          (cong (value e *_) (taylor (derivative f) x d)) ⟩
      (f x + value d * derivative f x) +
        value e * (derivative f x + value d * derivative (derivative f) x)
    ≡⟨ cong ((f x + value d * derivative f x) +_)
          (distribˡ (value e) (derivative f x)
            (value d * derivative (derivative f) x)) ⟩
      (f x + value d * derivative f x) +
        (value e * derivative f x + value e * (value d * derivative (derivative f) x))
    ≡⟨ sym (+-assoc (f x + value d * derivative f x)
          (value e * derivative f x) (value e * (value d * derivative (derivative f) x))) ⟩
      ((f x + value d * derivative f x) + value e * derivative f x) +
        value e * (value d * derivative (derivative f) x)
    ≡⟨ cong₂ _+_
          (trans (+-assoc (f x) (value d * derivative f x) (value e * derivative f x))
            (cong (f x +_) (sym (distribʳ (value d) (value e) (derivative f x)))))
          (trans (*-swap (value e) (value d) (derivative (derivative f) x))
            (sym (*-assoc (value d) (value e) (derivative (derivative f) x)))) ⟩
      (f x + (value d + value e) * derivative f x) +
        (value d * value e) * derivative (derivative f) x ∎

  square-sum : (d e : D) →
    (value d + value e) * (value d + value e) ≡
      (1r + 1r) * (value d * value e)
  square-sum d e =
    trans (expand-product (value d) (value e) (value d) (value e))
      (trans
        (cong₂ _+_
          (trans (cong (_+ (value d * value e)) (square-zero d))
            (+-identityˡ (value d * value e)))
          (trans (cong ((value e * value d) +_) (square-zero e))
            (trans (+-identityʳ (value e * value d)) (*-comm (value e) (value d)))))
        (sym (trans (distribʳ 1r 1r (value d * value e))
          (cong₂ _+_ (*-identityˡ (value d * value e)) (*-identityˡ (value d * value e))))))

  -- Proposition I.2.3 in the book's factorial form, for the whole line.
  taylor-two-factorial : (half : R) → (1r + 1r) * half ≡ 1r →
    (f : R → R) (x : R) (d e : D) →
    f (x + (value d + value e)) ≡
      (f x + (value d + value e) * derivative f x) +
      (((value d + value e) * (value d + value e)) * half) *
        derivative (derivative f) x
  taylor-two-factorial half half-law f x d e =
    trans (taylor-two f x d e)
      (cong ((f x + (value d + value e) * derivative f x) +_)
        (cong (_* derivative (derivative f) x) (sym coefficient)))
    where
    coefficient :
      ((value d + value e) * (value d + value e)) * half ≡ value d * value e
    coefficient =
      trans (cong (_* half) (square-sum d e))
        (trans (*-assoc (1r + 1r) (value d * value e) half)
          (trans (cong ((1r + 1r) *_) (*-comm (value d * value e) half))
            (trans (sym (*-assoc (1r + 1r) half (value d * value e)))
              (trans (cong (_* (value d * value e)) half-law)
                (*-identityˡ (value d * value e))))))

