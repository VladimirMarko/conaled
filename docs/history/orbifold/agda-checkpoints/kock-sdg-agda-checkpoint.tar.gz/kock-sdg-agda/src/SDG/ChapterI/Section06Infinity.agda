{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06Infinity where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Vec; Fin; tabulate; lookup; lookup-tabulate; map; replicate; tail)
open import SDG.Infinitesimal.Jets
open import SDG.Infinitesimal.Polynomial
open import SDG.Infinitesimal.Nilpotent
open import SDG.Infinitesimal.Observed
import SDG.Calculus.Slope as SL
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as E3
import SDG.ChapterI.Section03Symmetric as S3S
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06Linear as S6L

-- Exercise I.6.7 for the union of nilpotents, presented as a scalar-value
-- setoid. The extensions below are actual witnessed nilpotents; their
-- geometric laws and uniqueness hold for equality of scalar values.
-- A quotient/subobject presentation with native equality would require
-- additional categorical quotient infrastructure, and is not asserted here.
module Presentation {ℓ : Level} (A : CRing ℓ) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open Times A public

  injectD : D → D∞
  injectD d = injectK (fromD d)

  Points∞ : ℕ → Set ℓ
  Points∞ n = Vec D∞ n

  values : {n : ℕ} → Points∞ n → Vec R n
  values = map scalar

module Linearity {ℓ : Level} (A : CRing ℓ)
  (T : Polynomials.TotalKockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open Properties A
  open Presentation A
  private
    K : KockLawvere
    K = S6L.FirstOrderFromTotal.firstOrder A T
  open KockLawvere K using (slope)
  open SL.Results A K using (slope-cong)
  module Scalar = S6L.ScalarLinearity A T

  slopes : {n : ℕ} → (Fin n → D → D∞) → Vec R n
  slopes ts = tabulate (λ i → slope (λ d → scalar (ts i d)))

  extend : (n : ℕ) (x : D∞) (ts : Fin (suc (suc n)) → D → D∞) →
    ((i : Fin (suc (suc n))) → ts i zeroD ≈∞ x) → Jet1 (suc (suc n)) → D∞
  extend n x ts base p = add∞ x (injectD (weightedD (slopes ts) p))

  value-extend : (n : ℕ) (x : D∞) (ts : Fin (suc (suc n)) → D → D∞)
    (base : (i : Fin (suc (suc n))) → ts i zeroD ≈∞ x) (p : Jet1 (suc (suc n))) →
    scalar (extend n x ts base p) ≡ Scalar.extend n (scalar x) (λ i d → scalar (ts i d)) base p
  value-extend n x ts base p = cong (scalar x +_)
    (trans (weightedD-value (slopes ts) p)
      (Sum.sum-cong (λ i → cong (coordinate p i *_)
        (lookup-tabulate (λ j → slope (λ d → scalar (ts j d))) i))))

  infinity-linear : ObservedInfinitesimallyLinear D∞ scalar
  ObservedInfinitesimallyLinear.extension infinity-linear = extend
  ObservedInfinitesimallyLinear.axes infinity-linear n x ts base i d =
    trans (value-extend n x ts base (axis i d))
      (Scalar.extend-axis n (scalar x) (λ j e → scalar (ts j e)) base i d)
  ObservedInfinitesimallyLinear.uniqueness infinity-linear n x ts base t p d =
    trans (Scalar.extend-unique n (scalar x) (λ i e → scalar (ts i e)) base
      (λ q → scalar (t q)) p d) (sym (value-extend n x ts base d))
  ObservedInfinitesimallyLinear.extension-cong infinity-linear n x y ts us base base′ p q xy tu pq =
    trans (value-extend n x ts base p)
      (trans (cong₂ _+_ xy (Sum.sum-cong (λ i → cong₂ _*_
        (cong (λ xs → lookup xs i) pq)
        (slope-cong (λ d → scalar (ts i d)) (λ d → scalar (us i d)) (tu i)))))
        (sym (value-extend n y us base′ q)))

  infinity-powers-linear : (m : ℕ) → ObservedInfinitesimallyLinear (Points∞ m) values
  infinity-powers-linear = VectorClosure.vector-linear A scalar infinity-linear

module WProperty {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K using (slope)
  open SL.Results A K using (slope-cong)
  open Properties A
  open Presentation A
  open S4.Results A K using (W-extension; W-factorization; W-unique)

  coefficient : (D → D → D∞) → R
  coefficient f = slope (λ e → slope (λ d → scalar (f d e)))

  lift : (f : D → D → D∞) →
    ((d : D) → f d zeroD ≈∞ f zeroD zeroD) →
    ((e : D) → f zeroD e ≈∞ f zeroD zeroD) → D → D∞
  lift f a b z = add∞ (f zeroD zeroD) (injectD (scaleD z (coefficient f)))

  infinity-W : ObservedPropertyW D∞ scalar
  ObservedPropertyW.lift infinity-W = lift
  ObservedPropertyW.factor infinity-W f a b = W-factorization (λ d e → scalar (f d e)) a b
  ObservedPropertyW.unique infinity-W f a b t p = W-unique (λ d e → scalar (f d e)) a b
    (λ d → scalar (t d)) p
  ObservedPropertyW.lift-cong infinity-W f g a b a′ b′ z w fg zw =
    cong₂ _+_ (fg zeroD zeroD) (cong₂ _*_ zw
      (slope-cong (λ e → slope (λ d → scalar (f d e)))
        (λ e → slope (λ d → scalar (g d e)))
        (λ e → slope-cong (λ d → scalar (f d e)) (λ d → scalar (g d e)) (λ d → fg d e))))

  infinity-powers-W : (m : ℕ) → ObservedPropertyW (Points∞ m) values
  infinity-powers-W = VectorClosure.vector-W A scalar infinity-W

module SymmetricProperty {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open Properties A
  open Presentation A
  private
    K : KockLawvere
    K = S3.FirstOrderFromHigher.firstOrder A H
  module P = S3S.SymmetricPolynomials A K Q
  module Desc = S3S.Descent A H Q
  open E3.SumMap A using (summation)

  descend : (n : ℕ) (f : Vec D (suc n) → D∞) →
    SymmetricObserved scalar f → DK (suc n) → D∞
  descend n f s d = add∞ (f (replicate zeroD))
    (scale∞ (eval (tail (fst (P.representation (λ ds → scalar (f ds)) s))) (valueK d)) (injectK d))

  value-descend : (n : ℕ) (f : Vec D (suc n) → D∞)
    (s : SymmetricObserved scalar f) (d : DK (suc n)) →
    scalar (descend n f s d) ≡ Desc.extension (λ ds → scalar (f ds)) s d
  value-descend n f s d = refl

  infinity-symmetric : (n : ℕ) → ObservedSymmetricDescent n summation D∞ scalar
  ObservedSymmetricDescent.descend (infinity-symmetric n) = descend n
  ObservedSymmetricDescent.factor (infinity-symmetric n) f s ds =
    trans (Desc.factorization (λ es → scalar (f es)) s ds)
      (sym (value-descend n f s (summation ds)))
  ObservedSymmetricDescent.unique (infinity-symmetric n) f s t p d =
    trans (Desc.extension-unique n (λ ds → scalar (f ds)) s (λ e → scalar (t e)) p d)
      (sym (value-descend n f s d))
  ObservedSymmetricDescent.descend-cong (infinity-symmetric n) f g s s′ d e fg de =
    trans (value-descend n f s d)
      (trans (Desc.extension-unique n (λ ds → scalar (g ds)) s′
        (Desc.extension (λ ds → scalar (f ds)) s)
        (λ ds → trans (sym (fg ds)) (Desc.factorization (λ es → scalar (f es)) s ds)) d)
        (trans (cong (eval (fst (P.representation (λ ds → scalar (g ds)) s′))) de)
          (sym (value-descend n g s′ e))))

  infinity-powers-symmetric : (n m : ℕ) →
    ObservedSymmetricDescent n summation (Points∞ m) values
  infinity-powers-symmetric n = VectorClosure.vector-symmetric A scalar (infinity-symmetric n)
