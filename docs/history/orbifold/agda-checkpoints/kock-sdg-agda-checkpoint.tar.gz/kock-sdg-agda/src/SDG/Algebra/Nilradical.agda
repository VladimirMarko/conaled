{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.Nilradical where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Finite using (Vec; Fin; lookup; map; zipWith; replicate;
  lookup-map; lookup-zipWith; lookup-replicate; nat-add-sucʳ)

module Results {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A public

  -- The strengthened annihilator statement gives the nilpotent-sum bound
  -- constructively, without division or a pre-existing binomial theorem.
  annihilate-sum : (x y a : R) (m n : ℕ) →
    a * (x ^ m) ≡ 0r → a * (y ^ n) ≡ 0r →
    a * ((x + y) ^ (m +ℕ n)) ≡ 0r
  annihilate-sum x y a zero n ax ay =
    trans (cong (_* ((x + y) ^ n)) (trans (sym (*-identityʳ a)) ax))
      (*-zeroˡ ((x + y) ^ n))
  annihilate-sum x y a (suc m) zero ax ay =
    trans (cong (_* ((x + y) ^ (suc m +ℕ zero)))
      (trans (sym (*-identityʳ a)) ay))
      (*-zeroˡ ((x + y) ^ (suc m +ℕ zero)))
  annihilate-sum x y a (suc m) (suc n) ax ay =
    begin
      a * ((x + y) * ((x + y) ^ (m +ℕ suc n)))
    ≡⟨ sym (*-assoc a (x + y) ((x + y) ^ (m +ℕ suc n))) ⟩
      (a * (x + y)) * ((x + y) ^ (m +ℕ suc n))
    ≡⟨ cong (_* ((x + y) ^ (m +ℕ suc n))) (distribˡ a x y) ⟩
      ((a * x) + (a * y)) * ((x + y) ^ (m +ℕ suc n))
    ≡⟨ distribʳ (a * x) (a * y) ((x + y) ^ (m +ℕ suc n)) ⟩
      (a * x) * ((x + y) ^ (m +ℕ suc n)) +
      (a * y) * ((x + y) ^ (m +ℕ suc n))
    ≡⟨ cong₂ _+_
        (annihilate-sum x y (a * x) m (suc n)
          (trans (*-assoc a x (x ^ m)) ax)
          (trans (*-assoc a x (y ^ suc n))
            (trans (*-swap a x (y ^ suc n))
              (trans (cong (x *_) ay) (*-zeroʳ x)))))
        (trans (cong (λ k → (a * y) * ((x + y) ^ k)) (nat-add-sucʳ m n))
          (annihilate-sum x y (a * y) (suc m) n
            (trans (*-assoc a y (x ^ suc m))
              (trans (*-swap a y (x ^ suc m))
                (trans (cong (y *_) ax) (*-zeroʳ y))))
            (trans (*-assoc a y (y ^ n)) ay))) ⟩
      0r + 0r
    ≡⟨ +-identityˡ 0r ⟩
      0r ∎

  nilpotent-sum : (x y : R) (k l : ℕ) →
    x ^ suc k ≡ 0r → y ^ suc l ≡ 0r →
    (x + y) ^ suc (k +ℕ suc l) ≡ 0r
  nilpotent-sum x y k l px py =
    trans (sym (*-identityˡ ((x + y) ^ suc (k +ℕ suc l))))
      (annihilate-sum x y 1r (suc k) (suc l)
        (trans (*-identityˡ (x ^ suc k)) px)
        (trans (*-identityˡ (y ^ suc l)) py))

  nilpotent-neg : (x : R) (k : ℕ) →
    x ^ suc k ≡ 0r → (- x) ^ suc k ≡ 0r
  nilpotent-neg x k p =
    trans (cong (_^ suc k)
      (sym (trans (neg-mulʳ x 1r) (cong -_ (*-identityʳ x)))))
      (nilpotent-scaled x (- 1r) (suc k) p)

  -- A witness is data; later D∞ maps must respect equality of scalar values.
  Nilpotent : R → Set ℓ
  Nilpotent x = Σ ℕ (λ k → x ^ suc k ≡ 0r)

  zero-nilpotent : Nilpotent 0r
  zero-nilpotent = zero , zero-positive-power zero

  add-nilpotent : {x y : R} → Nilpotent x → Nilpotent y → Nilpotent (x + y)
  add-nilpotent {x} {y} (k , px) (l , py) =
    (k +ℕ suc l) , nilpotent-sum x y k l px py

  neg-nilpotent : {x : R} → Nilpotent x → Nilpotent (- x)
  neg-nilpotent {x} (k , p) = k , nilpotent-neg x k p

  scale-nilpotent : (r : R) {x : R} → Nilpotent x → Nilpotent (r * x)
  scale-nilpotent r {x} (k , p) = k ,
    trans (cong (_^ suc k) (*-comm r x)) (nilpotent-scaled x r (suc k) p)

  -- Exercise I.5.1: componentwise nilpotents form an R-submodule of R^n.
  NilpotentVector : {n : ℕ} → Vec R n → Set ℓ
  NilpotentVector {n} xs = (i : Fin n) → Nilpotent (lookup xs i)

  zero-vector : (n : ℕ) → NilpotentVector (replicate {n = n} 0r)
  zero-vector n i = subst Nilpotent (sym (lookup-replicate 0r i)) zero-nilpotent

  add-vectors : {n : ℕ} (xs ys : Vec R n) →
    NilpotentVector xs → NilpotentVector ys → NilpotentVector (zipWith _+_ xs ys)
  add-vectors xs ys nx ny i = subst Nilpotent
    (sym (lookup-zipWith _+_ xs ys i)) (add-nilpotent (nx i) (ny i))

  neg-vector : {n : ℕ} (xs : Vec R n) →
    NilpotentVector xs → NilpotentVector (map -_ xs)
  neg-vector xs nx i = subst Nilpotent
    (sym (lookup-map -_ xs i)) (neg-nilpotent (nx i))

  scale-vector : {n : ℕ} (r : R) (xs : Vec R n) →
    NilpotentVector xs → NilpotentVector (map (r *_) xs)
  scale-vector r xs nx i = subst Nilpotent
    (sym (lookup-map (r *_) xs i)) (scale-nilpotent r (nx i))

