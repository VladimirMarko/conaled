{-# OPTIONS --safe --without-K #-}

module SDG.Setness where

open import SDG.Prelude

inverse-path-cancel : {a : Level} {X : Set a} {x y : X} (p : x ≡ y) → trans (sym p) p ≡ refl
inverse-path-cancel refl = refl

-- Even a function-extensionality witness with no supplied computation
-- rule suffices: normalize its reflexivity path before comparing paths.
-- This derives setness of function objects without postulating a beta law.
module Functions {a b : Level} (ext : FunExt a b)
  {X : Set a} {Y : X → Set b} (setY : (x : X) → isSet (Y x)) where

  Pointwise : ((x : X) → Y x) → ((x : X) → Y x) → Set (a ⊔ b)
  Pointwise f g = (x : X) → f x ≡ g x

  apply-path : {f g : (x : X) → Y x} → f ≡ g → Pointwise f g
  apply-path p x = cong (λ h → h x) p

  pointwise-prop : (f g : (x : X) → Y x) → isProp (Pointwise f g)
  pointwise-prop f g p q = ext (λ x → setY x (f x) (g x) (p x) (q x))

  normalize : {f g : (x : X) → Y x} → f ≡ g → f ≡ g
  normalize {f} p = trans (sym (ext {f = f} {g = f} (λ _ → refl))) (ext (apply-path p))

  normalize-η : {f g : (x : X) → Y x} (p : f ≡ g) → normalize p ≡ p
  normalize-η {f} refl = inverse-path-cancel (ext {f = f} {g = f} (λ _ → refl))

  function-isSet : isSet ((x : X) → Y x)
  function-isSet f g p q = trans (sym (normalize-η p))
    (trans (cong (λ h → trans (sym (ext {f = f} {g = f} (λ _ → refl))) (ext h))
      (pointwise-prop f g (apply-path p) (apply-path q))) (normalize-η q))

function-isSet : {a b : Level} {X : Set a} {Y : Set b} →
  FunExt a b → isSet Y → isSet (X → Y)
function-isSet ext setY = Functions.function-isSet ext (λ _ → setY)

-- A retract of a set is a set; the retraction need only hold propositionally.
module Retractions {a b : Level} {X : Set a} {Y : Set b}
  (embed : X → Y) (retract : Y → X) (roundtrip : (x : X) → retract (embed x) ≡ x) where

  decode : {x y : X} → embed x ≡ embed y → x ≡ y
  decode {x} {y} p = trans (sym (roundtrip x)) (trans (cong retract p) (roundtrip y))

  decode-encode : {x y : X} (p : x ≡ y) → decode (cong embed p) ≡ p
  decode-encode {x} refl = inverse-path-cancel (roundtrip x)

  retraction-isSet : isSet Y → isSet X
  retraction-isSet setY x y p q = trans (sym (decode-encode p))
    (trans (cong decode (setY (embed x) (embed y) (cong embed p) (cong embed q))) (decode-encode q))
