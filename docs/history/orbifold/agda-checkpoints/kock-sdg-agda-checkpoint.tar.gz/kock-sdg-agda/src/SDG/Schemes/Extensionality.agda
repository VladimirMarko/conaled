{-# OPTIONS --safe --without-K #-}
module SDG.Schemes.Extensionality where

open import SDG.Prelude

private
  inverse-cancel : {a : Level} {A : Set a} {x y : A} (p : x ≡ y) → trans (sym p) p ≡ refl
  inverse-cancel refl = refl

-- Derive set-truncation of dependent function types from the supplied
-- extensionality principle. No additional UIP or K principle is used.
function-set : {a b : Level} {X : Set a} {Y : X → Set b} →
  FunExt a b → ((x : X) → isSet (Y x)) → isSet ((x : X) → Y x)
function-set {X = X} {Y} ext sets f g p q =
  trans (sym (reconstruct p))
    (trans (cong normal (ext (λ x → sets x (f x) (g x) (cong (λ h → h x) p) (cong (λ h → h x) q))))
      (reconstruct q))
  where
  normal : ((x : X) → f x ≡ g x) → f ≡ g
  normal h = trans (sym (ext {f = f} {g = f} (λ x → refl))) (ext h)

  reconstruct : (r : f ≡ g) → normal (λ x → cong (λ h → h x) r) ≡ r
  reconstruct refl = inverse-cancel (ext {f = f} {g = f} (λ x → refl))

injection-set : {a b : Level} {A : Set a} {B : Set b} (f : A → B) →
  ({x y : A} → f x ≡ f y → x ≡ y) → isSet B → isSet A
injection-set {A = A} f injective setB x y p q =
  trans (sym (reconstruct p))
    (trans (cong normal (setB (f x) (f y) (cong f p) (cong f q))) (reconstruct q))
  where
  normal : f x ≡ f y → x ≡ y
  normal r = trans (sym (injective {x = x} {y = x} refl)) (injective r)

  reconstruct : (r : x ≡ y) → normal (cong f r) ≡ r
  reconstruct refl = inverse-cancel (injective {x = x} {y = x} refl)
