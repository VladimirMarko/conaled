{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section14Differential where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.ModuleExtra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_; lookup; vec-ext;
  Permutation; to; permute; lookup-permute)
open import SDG.Forms.Basic
open import SDG.Combinatorics.Signature
import SDG.Forms.Module as FM
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section14Exterior as E14

-- The degree-zero exterior derivative and Exercise I.14.1 need only
-- first-order vector KL, not a scalar higher-order axiom.
module Differential {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  (Vmod : RModule A ℓ) (KV : V5.VectorInfinitesimals.VectorKL A Vmod) where
  open Extra A Vmod
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL KV
  open V5.VectorCalculus A Vmod KV
  open Cubes A
  open ModuleForms A Vmod
  open Sign A

  one-index : (i : Fin (suc zero)) → i ≡ fzero
  one-index fzero = refl

  one-permutation : (p : Permutation (suc zero)) (d : D) → permute p (d ∷ []) ≡ d ∷ []
  one-permutation p d = vec-ext (λ i → trans (lookup-permute p (d ∷ []) i)
    (trans (cong (lookup (d ∷ [])) (one-index (to p i)))
      (sym (cong (lookup (d ∷ [])) (one-index i)))))

  slope-reparameterized : (g : D → V) (r : R) →
    slopeV (λ d → g (scaleD d r)) ≡ r • slopeV g
  slope-reparameterized g r = uniqueSlopeV (λ d → g (scaleD d r)) (r • slopeV g)
    (λ d → trans (expansionV g (scaleD d r))
      (cong₂ _+v_ (cong g (sym (S7.Basics.scale-zero A setR r)))
        (scalar-assoc (value d) r (slopeV g))))

  differential : {M : Set ℓ} → (M → V) → Form (suc zero) M
  evaluate (differential f) τ = slopeV (λ d → f (τ (d ∷ [])))
  homogeneous (differential f) τ fzero r = slope-reparameterized (λ d → f (τ (d ∷ []))) r
  homogeneous (differential f) τ (fsuc ()) r
  alternating (differential f) τ p = trans
    (slope-cong (λ d → f (τ (permute p (d ∷ [])))) (λ d → f (τ (d ∷ [])))
      (λ d → cong (f ∘ τ) (one-permutation p d)))
    (sym (scalar-one (slopeV (λ d → f (τ (d ∷ []))))))

  differential-taylor : {M : Set ℓ} (f : M → V) (τ : Cube (suc zero) M) (d : D) →
    f (τ (d ∷ [])) ≡ f (τ (zeroD ∷ [])) +v value d • evaluate (differential f) τ
  differential-taylor f τ = expansionV (λ d → f (τ (d ∷ [])))

  differential-increment : {M : Set ℓ} (f : M → V) (τ : Cube (suc zero) M) (d : D) →
    f (τ (d ∷ [])) -v f (τ (zeroD ∷ [])) ≡ value d • evaluate (differential f) τ
  differential-increment f τ d = trans
    (cong (λ x → x -v f (τ (zeroD ∷ []))) (differential-taylor f τ d))
    (added-sub-base (f (τ (zeroD ∷ []))) (value d • evaluate (differential f) τ))

  differential-unique : {M : Set ℓ} (f : M → V) (ω : Form (suc zero) M) →
    ((τ : Cube (suc zero) M) (d : D) →
      f (τ (d ∷ [])) -v f (τ (zeroD ∷ [])) ≡ value d • evaluate ω τ) →
    (τ : Cube (suc zero) M) → evaluate (differential f) τ ≡ evaluate ω τ
  differential-unique f ω law τ = cancel-infinitesimals
    (evaluate (differential f) τ) (evaluate ω τ)
    (λ d → trans (sym (differential-increment f τ d)) (law τ d))

  -- The principal-part form γ on V is exactly d(id_V).
  principal-form : Form (suc zero) V
  principal-form = differential id

  principal-part : (τ : Cube (suc zero) V) → evaluate principal-form τ ≡ slopeV (λ d → τ (d ∷ []))
  principal-part τ = refl

  differential-pullback : {M N : Set ℓ} (f : M → N) (g : N → V) (τ : Cube (suc zero) M) →
    evaluate (differential (g ∘ f)) τ ≡ evaluate (pullback f (differential g)) τ
  differential-pullback f g τ = refl

  differential-principal : {M : Set ℓ} (f : M → V) (τ : Cube (suc zero) M) →
    evaluate (differential f) τ ≡ evaluate (pullback f principal-form) τ
  differential-principal f τ = refl

  differential-add : {M : Set ℓ} (f g : M → V) (τ : Cube (suc zero) M) →
    evaluate (differential (λ m → f m +v g m)) τ ≡ evaluate (add-form (differential f) (differential g)) τ
  differential-add f g τ = slope-add (λ d → f (τ (d ∷ []))) (λ d → g (τ (d ∷ [])))

  differential-scale : {M : Set ℓ} (r : R) (f : M → V) (τ : Cube (suc zero) M) →
    evaluate (differential (λ m → r • f m)) τ ≡ evaluate (scale-form r (differential f)) τ
  differential-scale r f τ = slope-scale r (λ d → f (τ (d ∷ [])))

  module Native (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setV : isSet V) where
    open FM.Native A Vmod ext0 ext setV using (form-ext)
    module Exterior = E14.Cubical A Vmod KV ext

    exterior-is-differential : {M : Set ℓ} (f : M → V) →
      Exterior.exterior (function-form f) ≡ differential f
    exterior-is-differential f = form-ext (λ τ → trans
      (cong (_+v 0v) (scalar-one (evaluate (differential f) τ)))
      (add-zeroʳ (evaluate (differential f) τ)))

    df-is-pullback-principal : {M : Set ℓ} (f : M → V) → differential f ≡ pullback f principal-form
    df-is-pullback-principal f = form-ext (differential-principal f)

    naturality : {M N : Set ℓ} (f : M → N) (g : N → V) →
      differential (g ∘ f) ≡ pullback f (differential g)
    naturality f g = form-ext (differential-pullback f g)

    uniqueness : {M : Set ℓ} (f : M → V) (ω : Form (suc zero) M) →
      ((τ : Cube (suc zero) M) (d : D) →
        f (τ (d ∷ [])) -v f (τ (zeroD ∷ [])) ≡ value d • evaluate ω τ) → differential f ≡ ω
    uniqueness f ω law = form-ext (differential-unique f ω law)
