{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section06PropertyClosures where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using
  (Fin; fzero; fsuc; Vec; lookup; tabulate; lookup-tabulate; vec-ext; Permutation; permute)
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as E3
import SDG.ChapterI.Section03Symmetric as Sym3
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section06JetClosure as JetClosure
open import SDG.Infinitesimal.Jets

-- A finite diagram is presented by its objects and arrows. A point of its
-- limit is a compatible tuple. No restriction to discrete diagrams is made.
module FiniteLimit {a : Level} (n m : ℕ) (Object : Fin n → Set a)
  (source target : Fin m → Fin n)
  (arrow : (e : Fin m) → Object (source e) → Object (target e))
  (ext0 : FunExt lzero a) (sets : (j : Fin n) → isSet (Object j)) where

  record Point : Set a where
    constructor point
    field
      component : (j : Fin n) → Object j
      commutes : (e : Fin m) → arrow e (component (source e)) ≡ component (target e)
  open Point public

  private
    point-path : {p q : Point} → component p ≡ component q → p ≡ q
    point-path {point xs p} {point .xs q} refl =
      cong (point xs) (ext0 (λ e → sets (target e) _ _ (p e) (q e)))

  point-ext : {p q : Point} → ((j : Fin n) → component p j ≡ component q j) → p ≡ q
  point-ext p = point-path (ext0 p)

  -- The actual universal property of this finite inverse limit.
  factor : {b : Level} {Z : Set b} (cone : (j : Fin n) → Z → Object j) →
    ((e : Fin m) (z : Z) → arrow e (cone (source e) z) ≡ cone (target e) z) → Z → Point
  factor cone coherent z = point (λ j → cone j z) (λ e → coherent e z)

  factor-projection : {b : Level} {Z : Set b} (cone : (j : Fin n) → Z → Object j)
    (coherent : (e : Fin m) (z : Z) → arrow e (cone (source e) z) ≡ cone (target e) z)
    (j : Fin n) (z : Z) → component (factor cone coherent z) j ≡ cone j z
  factor-projection cone coherent j z = refl

  factor-unique : {b : Level} {Z : Set b} (cone : (j : Fin n) → Z → Object j)
    (coherent : (e : Fin m) (z : Z) → arrow e (cone (source e) z) ≡ cone (target e) z)
    (candidate : Z → Point) →
    ((j : Fin n) (z : Z) → component (candidate z) j ≡ cone j z) →
    (z : Z) → candidate z ≡ factor cone coherent z
  factor-unique cone coherent candidate projections z = point-ext (λ j → projections j z)

-- The common mechanism for Property W, symmetric descent, and
-- infinitesimal linearity: maps compatible with two given arrows extend
-- uniquely across q. Compatibility is an equalizer, hence a finite limit.
module Descent {x y i : Level} (X : Set x) (Y : Set y) (I : Set i)
  (q : X → Y) (left right : I → X) where

  Compatible : {a : Level} {M : Set a} → (X → M) → Set (i ⊔ a)
  Compatible f = (s : I) → f (left s) ≡ f (right s)

  record Property {a : Level} (M : Set a) : Set (x ⊔ y ⊔ i ⊔ a) where
    field
      lift : (f : X → M) → Compatible f → Y → M
      factor : (f : X → M) (compatible : Compatible f) (z : X) →
        f z ≡ lift f compatible (q z)
      unique : (f : X → M) (compatible : Compatible f)
        (candidate : Y → M) → ((z : X) → f z ≡ candidate (q z)) →
        (z : Y) → candidate z ≡ lift f compatible z

  terminal : Property ⊤
  Property.lift terminal f compatible z = tt
  Property.factor terminal f compatible z with f z
  ... | tt = refl
  Property.unique terminal f compatible candidate p z with candidate z
  ... | tt = refl

  product : {a b : Level} {M : Set a} {N : Set b} →
    Property M → Property N → Property (M × N)
  Property.lift (product PM PN) f compatible z =
    Property.lift PM (fst ∘ f) (λ s → cong fst (compatible s)) z ,
    Property.lift PN (snd ∘ f) (λ s → cong snd (compatible s)) z
  Property.factor (product PM PN) f compatible z = cong₂ _,_
    (Property.factor PM (fst ∘ f) (λ s → cong fst (compatible s)) z)
    (Property.factor PN (snd ∘ f) (λ s → cong snd (compatible s)) z)
  Property.unique (product PM PN) f compatible candidate p z = cong₂ _,_
    (Property.unique PM (fst ∘ f) (λ s → cong fst (compatible s))
      (fst ∘ candidate) (λ s → cong fst (p s)) z)
    (Property.unique PN (snd ∘ f) (λ s → cong snd (compatible s))
      (snd ∘ candidate) (λ s → cong snd (p s)) z)

  dependent-product : {a b : Level} (Z : Set b) (M : Z → Set a) →
    FunExt b a → ((z : Z) → Property (M z)) → Property ((z : Z) → M z)
  Property.lift (dependent-product Z M ext PM) f compatible y z =
    Property.lift (PM z) (λ s → f s z) (λ s → cong (λ g → g z) (compatible s)) y
  Property.factor (dependent-product Z M ext PM) f compatible s = ext (λ z →
    Property.factor (PM z) (λ t → f t z) (λ t → cong (λ g → g z) (compatible t)) s)
  Property.unique (dependent-product Z M ext PM) f compatible candidate p y = ext (λ z →
    Property.unique (PM z) (λ t → f t z) (λ t → cong (λ g → g z) (compatible t))
      (λ t → candidate t z) (λ t → cong (λ g → g z) (p t)) y)

  function : {a b : Level} {M : Set a} (Z : Set b) →
    FunExt b a → Property M → Property (Z → M)
  function Z ext PM = dependent-product Z (λ _ → _) ext (λ _ → PM)

  vector : {a : Level} {M : Set a} → Property M → (n : ℕ) → Property (Vec M n)
  Property.lift (vector PM n) f compatible y = tabulate (λ j →
    Property.lift PM (λ s → lookup (f s) j) (λ s → cong (λ xs → lookup xs j) (compatible s)) y)
  Property.factor (vector PM n) f compatible s = vec-ext (λ j →
    trans (Property.factor PM (λ t → lookup (f t) j)
      (λ t → cong (λ xs → lookup xs j) (compatible t)) s)
      (sym (lookup-tabulate (λ k → Property.lift PM (λ t → lookup (f t) k)
        (λ t → cong (λ xs → lookup xs k) (compatible t)) (q s)) j)))
  Property.unique (vector PM n) f compatible candidate p y = vec-ext (λ j →
    trans (Property.unique PM (λ t → lookup (f t) j)
      (λ t → cong (λ xs → lookup xs j) (compatible t))
      (λ t → lookup (candidate t) j) (λ t → cong (λ xs → lookup xs j) (p t)) y)
      (sym (lookup-tabulate (λ k → Property.lift PM (λ t → lookup (f t) k)
        (λ t → cong (λ xs → lookup xs k) (compatible t)) y) j)))

  module Limits {a : Level} (n m : ℕ) (Object : Fin n → Set a)
    (source target : Fin m → Fin n)
    (arrow : (e : Fin m) → Object (source e) → Object (target e))
    (ext0 : FunExt lzero a) (sets : (j : Fin n) → isSet (Object j))
    (properties : (j : Fin n) → Property (Object j)) where
    open FiniteLimit n m Object source target arrow ext0 sets public

    component-lift : (f : X → Point) → Compatible f → Y → (j : Fin n) → Object j
    component-lift f compatible z j = Property.lift (properties j)
      (λ s → component (f s) j) (λ s → cong (λ p → component p j) (compatible s)) z

    lift-coherent : (f : X → Point) (compatible : Compatible f) (z : Y) (e : Fin m) →
      arrow e (component-lift f compatible z (source e)) ≡ component-lift f compatible z (target e)
    lift-coherent f compatible z e = Property.unique (properties (target e))
      (λ s → component (f s) (target e))
      (λ s → cong (λ p → component p (target e)) (compatible s))
      (λ y → arrow e (component-lift f compatible y (source e)))
      (λ s → trans (sym (commutes (f s) e))
        (cong (arrow e) (Property.factor (properties (source e))
          (λ t → component (f t) (source e))
          (λ t → cong (λ p → component p (source e)) (compatible t)) s))) z

    limit-property : Property Point
    Property.lift limit-property f compatible z =
      point (component-lift f compatible z) (lift-coherent f compatible z)
    Property.factor limit-property f compatible s = point-ext (λ j →
      Property.factor (properties j) (λ t → component (f t) j)
        (λ t → cong (λ p → component p j) (compatible t)) s)
    Property.unique limit-property f compatible candidate p z = point-ext (λ j →
      Property.unique (properties j) (λ t → component (f t) j)
        (λ t → cong (λ p → component p j) (compatible t))
        (λ t → component (candidate t) j) (λ t → cong (λ p → component p j) (p t)) z)

  record Solution {a : Level} (M : Set a) : Set (x ⊔ i ⊔ a) where
    constructor solution
    field
      run : X → M
      compatible : Compatible run
  open Solution public

  -- This is the equalizer of the two precomposition maps M^X ⇉ M^I.
  module EqualizerDiagram {a : Level} (M : Set a)
    (extX : FunExt x a) (extI : FunExt i a) (setM : isSet M) where

    private
      solution-path : {s t : Solution M} → run s ≡ run t → s ≡ t
      solution-path {solution f p} {solution .f q} refl =
        cong (solution f) (extI (λ s → setM _ _ (p s) (q s)))

    solution-ext : {s t : Solution M} → ((z : X) → run s z ≡ run t z) → s ≡ t
    solution-ext p = solution-path (extX p)

    equalizer-equation : (s : Solution M) → run s ∘ left ≡ run s ∘ right
    equalizer-equation s = extI (compatible s)

    equalizer-factor : {b : Level} {Z : Set b} (f : Z → X → M) →
      ((z : Z) → f z ∘ left ≡ f z ∘ right) → Z → Solution M
    equalizer-factor f commutes z = solution (f z) (λ s → cong (λ g → g s) (commutes z))

    equalizer-factor-projection : {b : Level} {Z : Set b} (f : Z → X → M)
      (commutes : (z : Z) → f z ∘ left ≡ f z ∘ right) (z : Z) →
      run (equalizer-factor f commutes z) ≡ f z
    equalizer-factor-projection f commutes z = refl

    equalizer-factor-unique : {b : Level} {Z : Set b} (f : Z → X → M)
      (commutes : (z : Z) → f z ∘ left ≡ f z ∘ right) (candidate : Z → Solution M) →
      ((z : Z) → run (candidate z) ≡ f z) → (z : Z) → candidate z ≡ equalizer-factor f commutes z
    equalizer-factor-unique f commutes candidate p z = solution-path (p z)

  module Comparison {a : Level} (M : Set a) (coherent : (s : I) → q (left s) ≡ q (right s))
    (extX : FunExt x a) (extY : FunExt y a) (extI : FunExt i a) (setM : isSet M) where
    open EqualizerDiagram M extX extI setM

    restrict : (Y → M) → Solution M
    restrict f = solution (f ∘ q) (λ s → cong f (coherent s))

    record Isomorphism : Set (x ⊔ y ⊔ i ⊔ a) where
      field
        inverse : Solution M → Y → M
        inverse-restrict : (f : Y → M) → inverse (restrict f) ≡ f
        restrict-inverse : (s : Solution M) → restrict (inverse s) ≡ s

    property-is-isomorphism : Property M → Isomorphism
    Isomorphism.inverse (property-is-isomorphism PM) s = Property.lift PM (run s) (compatible s)
    Isomorphism.inverse-restrict (property-is-isomorphism PM) f = extY (λ z →
      sym (Property.unique PM (f ∘ q) (λ s → cong f (coherent s)) f (λ _ → refl) z))
    Isomorphism.restrict-inverse (property-is-isomorphism PM) s =
      solution-ext (λ z → sym (Property.factor PM (run s) (compatible s) z))

    isomorphism-is-property : Isomorphism → Property M
    Property.lift (isomorphism-is-property iso) f p = Isomorphism.inverse iso (solution f p)
    Property.factor (isomorphism-is-property iso) f p z =
      sym (cong (λ s → run s z) (Isomorphism.restrict-inverse iso (solution f p)))
    Property.unique (isomorphism-is-property iso) f p candidate equation z =
      trans (sym (cong (λ g → g z) (Isomorphism.inverse-restrict iso candidate)))
        (cong (λ s → Isomorphism.inverse iso s z) (solution-ext (λ t → sym (equation t))))

module WClosure {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A) where
  open Infinitesimals A
  open S4.Results A K using (PropertyW; Axis₁; Axis₂; productD)
  module G = Descent (D × D) D (D × D)
    (λ p → productD (fst p) (snd p)) (λ p → fst p , zeroD) (λ p → zeroD , snd p)

  to-descent : {a : Level} {M : Set a} → PropertyW M → G.Property M
  G.Property.lift (to-descent WM) f p = PropertyW.lift WM (λ d e → f (d , e))
    (λ d → p (d , zeroD)) (λ e → sym (p (zeroD , e)))
  G.Property.factor (to-descent WM) f p (d , e) =
    PropertyW.factor WM (λ d e → f (d , e))
      (λ d → p (d , zeroD)) (λ e → sym (p (zeroD , e))) d e
  G.Property.unique (to-descent WM) f p candidate equation =
    PropertyW.unique WM (λ d e → f (d , e))
      (λ d → p (d , zeroD)) (λ e → sym (p (zeroD , e))) candidate
      (λ d e → equation (d , e))

  from-descent : {a : Level} {M : Set a} → G.Property M → PropertyW M
  PropertyW.lift (from-descent PM) f p r = G.Property.lift PM
    (λ z → f (fst z) (snd z)) (λ z → trans (p (fst z)) (sym (r (snd z))))
  PropertyW.factor (from-descent PM) f p r d e = G.Property.factor PM
    (λ z → f (fst z) (snd z)) (λ z → trans (p (fst z)) (sym (r (snd z)))) (d , e)
  PropertyW.unique (from-descent PM) f p r candidate equation = G.Property.unique PM
    (λ z → f (fst z) (snd z)) (λ z → trans (p (fst z)) (sym (r (snd z))))
    candidate (λ z → equation (fst z) (snd z))

  terminal-W : PropertyW ⊤
  terminal-W = from-descent G.terminal

  product-W : {a b : Level} {M : Set a} {N : Set b} →
    PropertyW M → PropertyW N → PropertyW (M × N)
  product-W WM WN = from-descent (G.product (to-descent WM) (to-descent WN))

  function-W : {a b : Level} {M : Set a} (X : Set b) →
    FunExt b a → PropertyW M → PropertyW (X → M)
  function-W X ext WM = from-descent (G.function X ext (to-descent WM))

  vector-W-from : {a : Level} {M : Set a} → PropertyW M → (n : ℕ) → PropertyW (Vec M n)
  vector-W-from WM n = from-descent (G.vector (to-descent WM) n)

  module Limits {a : Level} (n m : ℕ) (Object : Fin n → Set a)
    (source target : Fin m → Fin n)
    (arrow : (e : Fin m) → Object (source e) → Object (target e))
    (ext0 : FunExt lzero a) (sets : (j : Fin n) → isSet (Object j))
    (properties : (j : Fin n) → PropertyW (Object j)) where
    module L = G.Limits n m Object source target arrow ext0 sets (λ j → to-descent (properties j))
    open FiniteLimit n m Object source target arrow ext0 sets public

    finite-limit-W : PropertyW Point
    finite-limit-W = from-descent L.limit-property

  module Characterization {a : Level} (M : Set a) (setR : isSet (CRing.R A))
    (ext : FunExt ℓ a) (setM : isSet M) where
    open RingLemmas A
    private
      d-path : {d e : D} → value d ≡ value e → d ≡ e
      d-path {infinitesimal x p} {infinitesimal .x q} refl =
        cong (infinitesimal x) (setR _ _ p q)
      coherent : (p : D × D) → productD (fst p) zeroD ≡ productD zeroD (snd p)
      coherent (d , e) = d-path (trans (*-zeroʳ (value d)) (sym (*-zeroˡ (value e))))
    open G.EqualizerDiagram M ext ext setM public
    module C = G.Comparison M coherent ext ext ext setM
    open C public using (Isomorphism; restrict)

    W-gives-equalizer-isomorphism : PropertyW M → Isomorphism
    W-gives-equalizer-isomorphism WM = C.property-is-isomorphism (to-descent WM)

    equalizer-isomorphism-gives-W : Isomorphism → PropertyW M
    equalizer-isomorphism-gives-W iso = from-descent (C.isomorphism-is-property iso)

module SymmetricClosure {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  {n : ℕ} {Y : Set ℓ} (q : Vec (Infinitesimals.D A) n → Y) where
  open Infinitesimals A
  open S4.Results A K using (Symmetric; SymmetricDescent)
  module G = Descent (Vec D n) Y (Permutation n × Vec D n) q
    (λ p → permute (fst p) (snd p)) snd

  to-descent : {a : Level} {M : Set a} → SymmetricDescent Y q M → G.Property M
  G.Property.lift (to-descent SM) f p = SymmetricDescent.descend SM f (λ perm ds → p (perm , ds))
  G.Property.factor (to-descent SM) f p = SymmetricDescent.factor SM f (λ perm ds → p (perm , ds))
  G.Property.unique (to-descent SM) f p = SymmetricDescent.unique SM f (λ perm ds → p (perm , ds))

  from-descent : {a : Level} {M : Set a} → G.Property M → SymmetricDescent Y q M
  SymmetricDescent.descend (from-descent PM) f p = G.Property.lift PM f (λ s → p (fst s) (snd s))
  SymmetricDescent.factor (from-descent PM) f p = G.Property.factor PM f (λ s → p (fst s) (snd s))
  SymmetricDescent.unique (from-descent PM) f p = G.Property.unique PM f (λ s → p (fst s) (snd s))

  terminal-symmetric : SymmetricDescent Y q ⊤
  terminal-symmetric = from-descent G.terminal

  product-symmetric : {a b : Level} {M : Set a} {N : Set b} →
    SymmetricDescent Y q M → SymmetricDescent Y q N → SymmetricDescent Y q (M × N)
  product-symmetric SM SN = from-descent (G.product (to-descent SM) (to-descent SN))

  function-symmetric : {a b : Level} {M : Set a} (X : Set b) →
    FunExt b a → SymmetricDescent Y q M → SymmetricDescent Y q (X → M)
  function-symmetric X ext SM = from-descent (G.function X ext (to-descent SM))

  vector-symmetric : {a : Level} {M : Set a} →
    SymmetricDescent Y q M → (m : ℕ) → SymmetricDescent Y q (Vec M m)
  vector-symmetric SM m = from-descent (G.vector (to-descent SM) m)

  module Limits {a : Level} (objects edges : ℕ) (Object : Fin objects → Set a)
    (source target : Fin edges → Fin objects)
    (arrow : (e : Fin edges) → Object (source e) → Object (target e))
    (ext0 : FunExt lzero a) (sets : (j : Fin objects) → isSet (Object j))
    (properties : (j : Fin objects) → SymmetricDescent Y q (Object j)) where
    module L = G.Limits objects edges Object source target arrow ext0 sets (λ j → to-descent (properties j))
    open FiniteLimit objects edges Object source target arrow ext0 sets public

    finite-limit-symmetric : SymmetricDescent Y q Point
    finite-limit-symmetric = from-descent L.limit-property

  module Characterization {a : Level} (M : Set a)
    (q-symmetric : (p : Permutation n) (ds : Vec D n) → q (permute p ds) ≡ q ds)
    (ext : FunExt ℓ a) (setM : isSet M) where
    open G.EqualizerDiagram M ext ext setM public
    module C = G.Comparison M (λ s → q-symmetric (fst s) (snd s)) ext ext ext setM
    open C public using (Isomorphism; restrict)

    symmetry-gives-equalizer-isomorphism : SymmetricDescent Y q M → Isomorphism
    symmetry-gives-equalizer-isomorphism SM = C.property-is-isomorphism (to-descent SM)

    equalizer-isomorphism-gives-symmetry : Isomorphism → SymmetricDescent Y q M
    equalizer-isomorphism-gives-symmetry iso = from-descent (C.isomorphism-is-property iso)

-- The concrete symmetric-functions diagram uses the addition D^n→D_n.
module SumCharacterization {ℓ a : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A)
  (setR : isSet (CRing.R A)) (n : ℕ) (M : Set a)
  (ext : FunExt ℓ a) (setM : isSet M) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open E3.SumMap A using (summation)
  open Sym3.SymmetricPolynomials A K Q using (sumD-permute)
  private
    dk-path : {d e : DK n} → valueK d ≡ valueK e → d ≡ e
    dk-path {nilpotent x p} {nilpotent .x q} refl = cong (nilpotent x) (setR _ _ p q)
    sum-symmetric : (p : Permutation n) (ds : Vec D n) → summation (permute p ds) ≡ summation ds
    sum-symmetric p ds = dk-path (sumD-permute p ds)
  open SymmetricClosure.Characterization A K summation M sum-symmetric ext setM public

-- Exercise I.6.5, its finite-limit and comparison-map formulations.
module LinearClosure {ℓ : Level} (A : CRing ℓ) where
  open Infinitesimals A
  open Jets A
  open S6.Linear A

  module AtOrder (n : ℕ) where
    size : ℕ
    size = suc (suc n)
    module G = Descent (Fin size × D) (Jet1 size) (Fin size × Fin size)
      (λ p → axis (fst p) (snd p)) (λ p → fst p , zeroD) (λ p → snd p , zeroD)

    to-descent : {a : Level} {M : Set a} → InfinitesimallyLinear M → G.Property M
    G.Property.lift (to-descent LM) f compatible = InfinitesimallyLinear.extension LM
      n (f (fzero , zeroD)) (λ i d → f (i , d)) (λ i → compatible (i , fzero))
    G.Property.factor (to-descent LM) f compatible (i , d) =
      sym (InfinitesimallyLinear.axes LM n (f (fzero , zeroD))
        (λ i d → f (i , d)) (λ i → compatible (i , fzero)) i d)
    G.Property.unique (to-descent LM) f compatible candidate equation =
      InfinitesimallyLinear.uniqueness LM n (f (fzero , zeroD))
        (λ i d → f (i , d)) (λ i → compatible (i , fzero)) candidate
        (λ i d → sym (equation (i , d)))

  from-descent : {a : Level} {M : Set a} →
    ((n : ℕ) → AtOrder.G.Property n M) → InfinitesimallyLinear M
  InfinitesimallyLinear.extension (from-descent PM) n x ts base =
    G.Property.lift (PM n) (λ p → ts (fst p) (snd p))
      (λ p → trans (base (fst p)) (sym (base (snd p))))
    where module G = AtOrder.G n
  InfinitesimallyLinear.axes (from-descent PM) n x ts base i d =
    sym (G.Property.factor (PM n) (λ p → ts (fst p) (snd p))
      (λ p → trans (base (fst p)) (sym (base (snd p)))) (i , d))
    where module G = AtOrder.G n
  InfinitesimallyLinear.uniqueness (from-descent PM) n x ts base candidate equation =
    G.Property.unique (PM n) (λ p → ts (fst p) (snd p))
      (λ p → trans (base (fst p)) (sym (base (snd p)))) candidate
      (λ p → sym (equation (fst p) (snd p)))
    where module G = AtOrder.G n

  module Limits {a : Level} (objects edges : ℕ) (Object : Fin objects → Set a)
    (source target : Fin edges → Fin objects)
    (arrow : (e : Fin edges) → Object (source e) → Object (target e))
    (ext0 : FunExt lzero a) (sets : (j : Fin objects) → isSet (Object j))
    (properties : (j : Fin objects) → InfinitesimallyLinear (Object j)) where
    open FiniteLimit objects edges Object source target arrow ext0 sets public

    finite-limit-linear : InfinitesimallyLinear Point
    finite-limit-linear = from-descent (λ n →
      AtOrder.G.Limits.limit-property n objects edges Object source target arrow ext0 sets
        (λ j → AtOrder.to-descent n (properties j)))

  module Characterization {a : Level} (M : Set a) (setR : isSet (CRing.R A))
    (ext0R : FunExt lzero ℓ) (ext : FunExt ℓ a) (ext0M : FunExt lzero a) (setM : isSet M) where
    module Order (n : ℕ) where
      open AtOrder n
      private
        coherent : (p : Fin size × Fin size) → axis (fst p) zeroD ≡ axis (snd p) zeroD
        coherent (i , j) = trans (axis-zero setR ext0R i) (sym (axis-zero setR ext0R j))
      open G.EqualizerDiagram M ext ext0M setM public
      module C = G.Comparison M coherent ext ext ext0M setM
      open C public using (Isomorphism; restrict)

      -- This equalizer is also the size-fold pullback of evaluation at 0.
      -- Its universal property is given directly in terms of matching curves.
      MatchingAxes : Set (ℓ ⊔ a)
      MatchingAxes = G.Solution M

      curve : MatchingAxes → Fin size → D → M
      curve p j d = G.Solution.run p (j , d)

      common-base : (p : MatchingAxes) (j k : Fin size) → curve p j zeroD ≡ curve p k zeroD
      common-base p j k = G.Solution.compatible p (j , k)

      pullback-factor : {b : Level} {Z : Set b}
        (curves : Fin size → Z → D → M) →
        ((j k : Fin size) (z : Z) → curves j z zeroD ≡ curves k z zeroD) → Z → MatchingAxes
      pullback-factor curves matching z = G.solution
        (λ p → curves (fst p) z (snd p)) (λ p → matching (fst p) (snd p) z)

      pullback-projection : {b : Level} {Z : Set b}
        (curves : Fin size → Z → D → M)
        (matching : (j k : Fin size) (z : Z) → curves j z zeroD ≡ curves k z zeroD)
        (j : Fin size) (z : Z) (d : D) → curve (pullback-factor curves matching z) j d ≡ curves j z d
      pullback-projection curves matching j z d = refl

      pullback-unique : {b : Level} {Z : Set b}
        (curves : Fin size → Z → D → M)
        (matching : (j k : Fin size) (z : Z) → curves j z zeroD ≡ curves k z zeroD)
        (candidate : Z → MatchingAxes) →
        ((j : Fin size) (z : Z) (d : D) → curve (candidate z) j d ≡ curves j z d) →
        (z : Z) → candidate z ≡ pullback-factor curves matching z
      pullback-unique curves matching candidate equation z = solution-ext
        (λ p → equation (fst p) z (snd p))

    linearity-gives-pullback-isomorphisms : InfinitesimallyLinear M → (n : ℕ) → Order.Isomorphism n
    linearity-gives-pullback-isomorphisms LM n = Order.C.property-is-isomorphism n (AtOrder.to-descent n LM)

    pullback-isomorphisms-give-linearity : ((n : ℕ) → Order.Isomorphism n) → InfinitesimallyLinear M
    pullback-isomorphisms-give-linearity iso = from-descent
      (λ n → Order.C.isomorphism-is-property n (iso n))

-- Exercise I.6.7: finite Cartesian powers of the already constructed
-- constrained-jet instances retain W and symmetric descent.
module JetPowers {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (setR : isSet (CRing.R A)) (ext0 : FunExt lzero ℓ) where
  open Infinitesimals A
  open Jets A
  open S4.Results A K using (PropertyW; SymmetricDescent)

  jet-powers-W : (k n m : ℕ) → PropertyW (Vec (DJet k n) m)
  jet-powers-W k n m = WClosure.vector-W-from A K
    (JetClosure.WJets.Fixed.jet-W A K setR ext0 k n) m

  jet-powers-symmetric : {h : ℕ} (Y : Set ℓ) (q : Vec D h → Y) →
    SymmetricDescent Y q (CRing.R A) → (k n m : ℕ) → SymmetricDescent Y q (Vec (DJet k n) m)
  jet-powers-symmetric Y q SR k n m = SymmetricClosure.vector-symmetric A K q
    (JetClosure.SymmetricJets.Given.Fixed.jet-symmetric A K setR ext0 Y q SR k n) m
