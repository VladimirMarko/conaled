{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.StructureConstants where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Finite using (Fin; fzero; fsuc)
import SDG.Combinatorics.FiniteSums as FS
import SDG.Combinatorics.FiniteLinear as FL

-- A multiplication table on a finite free module, with the first basis
-- vector as unit. These are precisely the coefficient identities for a
-- commutative associative unital algebra; no geometric axiom occurs.
module Tables {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open FS.Sums A

  record Table (n : ℕ) : Set ℓ where
    field
      constants : Fin (suc n) → Fin (suc n) → Fin (suc n) → R
      unit-constants : (i j : Fin (suc n)) → constants i fzero j ≡ delta i j
      symmetric-constants : (i j k : Fin (suc n)) → constants i j k ≡ constants i k j
      associative-constants : (i j k l : Fin (suc n)) →
        sum (λ m → constants m j k * constants i m l) ≡
          sum (λ m → constants m k l * constants i j m)
  open Table public

  module Build (ext0 : FunExt lzero ℓ) (n : ℕ) (T : Table n) where
    open FL.Coordinates A ext0
    private
      I = Fin (suc n)
      γ = constants T

    Carrier : Set ℓ
    Carrier = I → R

    zeroC oneC : Carrier
    zeroC i = 0r
    oneC = delta fzero

    add : Carrier → Carrier → Carrier
    add x y i = x i + y i

    negate : Carrier → Carrier
    negate x i = - x i

    scale : R → Carrier → Carrier
    scale r x i = r * x i

    multiply : Carrier → Carrier → Carrier
    multiply x y i = sum (λ j → x j * sum (λ k → y k * γ i j k))

    left-linear : (y : Carrier) (i : I) → Linear (λ x → multiply x y i)
    map-zero (left-linear y i) = trans (sum-cong {n = suc n}
      (λ j → *-zeroˡ (sum (λ k → y k * γ i j k)))) (sum-zero (suc n))
    map-add (left-linear y i) x z = dot-addˡ x z (λ j → sum (λ k → y k * γ i j k))
    map-scale (left-linear y i) r x = dot-scaleˡ r x (λ j → sum (λ k → y k * γ i j k))

    right-linear : (x : Carrier) (i : I) → Linear (λ y → multiply x y i)
    map-zero (right-linear x i) = trans (sum-cong (λ j →
      trans (cong (x j *_) (trans (sum-cong (λ k → *-zeroˡ (γ i j k))) (sum-zero (suc n)))) (*-zeroʳ (x j))))
      (sum-zero (suc n))
    map-add (right-linear x i) y z = trans (sum-cong (λ j →
      cong (x j *_) (dot-addˡ y z (γ i j))))
      (dot-addʳ x (λ j → sum (λ k → y k * γ i j k)) (λ j → sum (λ k → z k * γ i j k)))
    map-scale (right-linear x i) r y = trans (sum-cong (λ j →
      cong (x j *_) (dot-scaleˡ r y (γ i j))))
      (dot-scaleʳ r x (λ j → sum (λ k → y k * γ i j k)))

    multiply-basis-left : (j : I) (y : Carrier) (i : I) →
      multiply (delta j) y i ≡ sum (λ k → y k * γ i j k)
    multiply-basis-left j y i = sum-delta (λ l → sum (λ k → y k * γ i l k)) j

    multiply-basis-right : (x : Carrier) (k i : I) → multiply x (delta k) i ≡ sum (λ j → x j * γ i j k)
    multiply-basis-right x k i = sum-cong (λ j → cong (x j *_) (sum-delta (γ i j) k))

    multiply-basis : (j k i : I) → multiply (delta j) (delta k) i ≡ γ i j k
    multiply-basis j k i = trans (multiply-basis-left j (delta k) i) (sum-delta (γ i j) k)

    basis-assoc : (j k l i : I) →
      multiply (multiply (delta j) (delta k)) (delta l) i ≡ multiply (delta j) (multiply (delta k) (delta l)) i
    basis-assoc j k l i =
      trans (multiply-basis-right (multiply (delta j) (delta k)) l i)
        (trans (sum-cong (λ m → cong (_* γ i m l) (multiply-basis j k m)))
          (trans (associative-constants T i j k l)
            (sym (trans (multiply-basis-left j (multiply (delta k) (delta l)) i)
              (sum-cong (λ m → cong (_* γ i j m) (multiply-basis k l m)))))))

    multiplication-assoc : (x y z : Carrier) → multiply (multiply x y) z ≡ multiply x (multiply y z)
    multiplication-assoc x y z = ext0 (λ i →
      trilinear-ext (λ x y z → multiply (multiply x y) z i) (λ x y z → multiply x (multiply y z) i)
        (λ y z → compose-linear (left-linear z i) (left-linear y))
        (λ x z → compose-linear (left-linear z i) (right-linear x))
        (λ x y → right-linear (multiply x y) i)
        (λ y z → left-linear (multiply y z) i)
        (λ x z → compose-linear (right-linear x i) (left-linear z))
        (λ x y → compose-linear (right-linear x i) (right-linear y))
        (λ j k l → basis-assoc j k l i) x y z)

    multiplication-comm : (x y : Carrier) → multiply x y ≡ multiply y x
    multiplication-comm x y = ext0 (λ i →
      trans (sum-cong (λ j → sym (sum-scaleˡ (x j) (λ k → y k * γ i j k))))
        (trans (sum-swap (λ j k → x j * (y k * γ i j k)))
          (trans (sum-cong (λ k → trans (sum-cong (λ j →
            trans (*-swap (x j) (y k) (γ i j k))
              (cong (λ c → y k * (x j * c)) (symmetric-constants T i j k))))
            (sum-scaleˡ (y k) (λ j → x j * γ i k j)))) refl)))

    multiplication-one : (x : Carrier) → multiply oneC x ≡ x
    multiplication-one x = ext0 (λ i →
      trans (multiply-basis-left fzero x i)
        (trans (sum-cong (λ j → trans (cong (x j *_) (unit-constants T i j)) (*-comm (x j) (delta i j))))
          (sum-delta x i)))

    coordinate-ring : CRing ℓ
    coordinate-ring = record
      { R = Carrier; 0r = zeroC; 1r = oneC; _+_ = add; _*_ = multiply; -_ = negate
      ; +-assoc = λ x y z → ext0 (λ i → +-assoc (x i) (y i) (z i))
      ; +-comm = λ x y → ext0 (λ i → +-comm (x i) (y i))
      ; +-identityˡ = λ x → ext0 (λ i → +-identityˡ (x i))
      ; +-identityʳ = λ x → ext0 (λ i → +-identityʳ (x i))
      ; +-inverseˡ = λ x → ext0 (λ i → +-inverseˡ (x i))
      ; +-inverseʳ = λ x → ext0 (λ i → +-inverseʳ (x i))
      ; *-assoc = multiplication-assoc; *-comm = multiplication-comm
      ; *-identityˡ = multiplication-one
      ; *-identityʳ = λ x → trans (multiplication-comm x oneC) (multiplication-one x)
      ; distribˡ = λ x y z → ext0 (λ i → map-add (right-linear x i) y z)
      ; distribʳ = λ x y z → ext0 (λ i → map-add (left-linear z i) x y) }

    scalar : R → Carrier
    scalar r = scale r oneC

    scalar-hom : RingHom A coordinate-ring
    scalar-hom = record
      { hom = scalar
      ; pres-0 = ext0 (λ i → *-zeroˡ (oneC i))
      ; pres-1 = ext0 (λ i → *-identityˡ (oneC i))
      ; pres-+ = λ r s → ext0 (λ i → distribʳ r s (oneC i))
      ; pres-* = λ r s → sym (ext0 (λ i →
          trans (map-scale (left-linear (scalar s) i) r oneC)
            (trans (cong (r *_) (cong (λ x → x i) (multiplication-one (scalar s))))
              (sym (*-assoc r s (oneC i))))))
      ; pres-neg = λ r → ext0 (λ i → neg-mulˡ r (oneC i)) }

    coordinate-algebra : RAlgebra A ℓ
    coordinate-algebra = algebra coordinate-ring scalar-hom

module Change {a b : Level} (A : CRing a) (B : CRing b) (h : RingHom A B) where
  private
    module A = RingLemmas A
    module B = RingLemmas B
    module SA = FS.Sums A
    module SB = FS.Sums B
  open RingHom h

  map-sum : {n : ℕ} (f : Fin n → A.R) → hom (SA.sum f) ≡ SB.sum (λ i → hom (f i))
  map-sum {zero} f = pres-0
  map-sum {suc n} f = trans (pres-+ (f fzero) (SA.sum (λ i → f (fsuc i))))
    (cong (B._+_ (hom (f fzero))) (map-sum (λ i → f (fsuc i))))

  map-delta : {n : ℕ} (i j : Fin n) → hom (SA.delta i j) ≡ SB.delta i j
  map-delta fzero fzero = pres-1
  map-delta fzero (fsuc j) = pres-0
  map-delta (fsuc i) fzero = pres-0
  map-delta (fsuc i) (fsuc j) = map-delta i j

  change-table : {n : ℕ} → Tables.Table A n → Tables.Table B n
  Tables.constants (change-table T) i j k = hom (Tables.constants T i j k)
  Tables.unit-constants (change-table T) i j = trans (cong hom (Tables.unit-constants T i j)) (map-delta i j)
  Tables.symmetric-constants (change-table T) i j k = cong hom (Tables.symmetric-constants T i j k)
  Tables.associative-constants (change-table T) i j k l =
    trans (sym (trans (map-sum (λ m → Tables.constants T m j k A.* Tables.constants T i m l))
      (SB.sum-cong (λ m → pres-* (Tables.constants T m j k) (Tables.constants T i m l)))))
      (trans (cong hom (Tables.associative-constants T i j k l))
        (trans (map-sum (λ m → Tables.constants T m k l A.* Tables.constants T i j m))
          (SB.sum-cong (λ m → pres-* (Tables.constants T m k l) (Tables.constants T i j m)))))
