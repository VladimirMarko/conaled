{-# OPTIONS --safe --without-K #-}
module SDG.Forms.Basic where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; update; permute; Permutation)
open import SDG.Combinatorics.Signature
import SDG.ChapterI.Section07 as S7

record ScalarAction {ℓ : Level} (A : CRing ℓ) (V : Set ℓ) : Set ℓ where
  field
    act : CRing.R A → V → V
    act-one : (v : V) → act (CRing.1r A) v ≡ v
    act-product : (r s : CRing.R A) (v : V) → act (CRing._*_ A r s) v ≡ act r (act s v)

moduleAction : {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ) → ScalarAction A (RModule.V Vmod)
moduleAction A Vmod = record
  { act = RModule._•_ Vmod
  ; act-one = RModule.scalar-one Vmod
  ; act-product = RModule.scalar-assoc Vmod
  }

module Cubes {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A

  Cube : ℕ → Set ℓ → Set ℓ
  Cube n M = Vec D n → M

  productD : {n : ℕ} → Vec D n → R
  productD [] = 1r
  productD (d ∷ ds) = value d * productD ds

  scale-coordinates : {n : ℕ} → Vec D n → Fin n → R → Vec D n
  scale-coordinates ds i r = update ds i (scaleD (lookup ds i) r)

  product-scaled-coordinate : {n : ℕ} (ds : Vec D n) (i : Fin n) (r : R) →
    productD (scale-coordinates ds i r) ≡ r * productD ds
  product-scaled-coordinate (d ∷ ds) fzero r =
    trans (cong (_* productD ds) (*-comm (value d) r)) (*-assoc r (value d) (productD ds))
  product-scaled-coordinate (d ∷ ds) (fsuc i) r =
    trans (cong (value d *_) (product-scaled-coordinate ds i r)) (*-swap (value d) r (productD ds))

  scale-cube : {n : ℕ} {M : Set ℓ} → Cube n M → Fin n → R → Cube n M
  scale-cube τ i r ds = τ (scale-coordinates ds i r)

  permute-cube : {n : ℕ} {M : Set ℓ} → Cube n M → Permutation n → Cube n M
  permute-cube τ p ds = τ (permute p ds)

  map-cube : {n : ℕ} {M N : Set ℓ} → (M → N) → Cube n M → Cube n N
  map-cube f τ ds = f (τ ds)

module Definitions {ℓ : Level} (A : CRing ℓ) {V : Set ℓ} (action : ScalarAction A V) where
  open RingLemmas A
  open Infinitesimals A
  open ScalarAction action
  open Sign A
  open Cubes A

  -- Definition 14.2: the full all-permutation condition is explicit.
  record Form (n : ℕ) (M : Set ℓ) : Set ℓ where
    constructor form
    field
      evaluate : Cube n M → V
      homogeneous : (τ : Cube n M) (i : Fin n) (r : R) → evaluate (scale-cube τ i r) ≡ act r (evaluate τ)
      alternating : (τ : Cube n M) (p : Permutation n) → evaluate (permute-cube τ p) ≡ act (signature p) (evaluate τ)
  open Form public

  pullback : {n : ℕ} {M N : Set ℓ} → (M → N) → Form n N → Form n M
  evaluate (pullback f ω) τ = evaluate ω (map-cube f τ)
  homogeneous (pullback f ω) τ i r = homogeneous ω (map-cube f τ) i r
  alternating (pullback f ω) τ p = alternating ω (map-cube f τ) p

  pullback-identity : {n : ℕ} {M : Set ℓ} (ω : Form n M) (τ : Cube n M) →
    evaluate (pullback id ω) τ ≡ evaluate ω τ
  pullback-identity ω τ = refl

  pullback-compose : {n : ℕ} {L M N : Set ℓ} (f : L → M) (g : M → N)
    (ω : Form n N) (τ : Cube n L) →
    evaluate (pullback (g ∘ f) ω) τ ≡ evaluate (pullback f (pullback g ω)) τ
  pullback-compose f g ω τ = refl

  function-form : {M : Set ℓ} → (M → V) → Form zero M
  evaluate (function-form f) τ = f (τ [])
  homogeneous (function-form f) τ () r
  alternating (function-form f) τ p = sym (act-one (f (τ [])))

  form-function : {M : Set ℓ} → Form zero M → M → V
  form-function ω m = evaluate ω (λ _ → m)

  function-roundtrip : {M : Set ℓ} (f : M → V) (m : M) → form-function (function-form f) m ≡ f m
  function-roundtrip f m = refl

  zero-form-roundtrip : (ext : FunExt ℓ ℓ) {M : Set ℓ} (ω : Form zero M) (τ : Cube zero M) →
    evaluate (function-form (form-function ω)) τ ≡ evaluate ω τ
  zero-form-roundtrip ext ω τ = cong (evaluate ω) (ext (λ { [] → refl }))

module ModuleForms {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ) where
  open ModuleLemmas A Vmod
  open Cubes A
  open Definitions A (moduleAction A Vmod) public
  open Sign A

  zero-form : {n : ℕ} {M : Set ℓ} → Form n M
  evaluate zero-form τ = 0v
  homogeneous zero-form τ i r = sym (scalar-zero r)
  alternating zero-form τ p = sym (scalar-zero (signature p))

  add-form : {n : ℕ} {M : Set ℓ} → Form n M → Form n M → Form n M
  evaluate (add-form ω θ) τ = evaluate ω τ +v evaluate θ τ
  homogeneous (add-form ω θ) τ i r = trans (cong₂ _+v_ (homogeneous ω τ i r) (homogeneous θ τ i r))
    (sym (scalar-distrib r (evaluate ω τ) (evaluate θ τ)))
  alternating (add-form ω θ) τ p = trans (cong₂ _+v_ (alternating ω τ p) (alternating θ τ p))
    (sym (scalar-distrib (signature p) (evaluate ω τ) (evaluate θ τ)))

  scale-form : {n : ℕ} {M : Set ℓ} → R → Form n M → Form n M
  evaluate (scale-form r ω) τ = r • evaluate ω τ
  homogeneous (scale-form r ω) τ i s = trans (cong (r •_) (homogeneous ω τ i s))
    (scalar-commute r s (evaluate ω τ))
  alternating (scale-form r ω) τ p = trans (cong (r •_) (alternating ω τ p))
    (scalar-commute r (signature p) (evaluate ω τ))

