{-# OPTIONS --safe --without-K #-}

module SDG.Algebra where

open import SDG.Prelude

-- Only the ordinary commutative-ring laws are supplied as fields.
-- All algebra used below, including the nilpotent product identities,
-- is derived from those laws.
record CRing (ℓ : Level) : Set (lsuc ℓ) where
  infixl 6 _+_
  infixl 7 _*_
  infix 8 -_
  field
    R : Set ℓ
    0r 1r : R
    _+_ _*_ : R → R → R
    -_ : R → R
    +-assoc : (x y z : R) → (x + y) + z ≡ x + (y + z)
    +-comm : (x y : R) → x + y ≡ y + x
    +-identityˡ : (x : R) → 0r + x ≡ x
    +-identityʳ : (x : R) → x + 0r ≡ x
    +-inverseˡ : (x : R) → (- x) + x ≡ 0r
    +-inverseʳ : (x : R) → x + (- x) ≡ 0r
    *-assoc : (x y z : R) → (x * y) * z ≡ x * (y * z)
    *-comm : (x y : R) → x * y ≡ y * x
    *-identityˡ : (x : R) → 1r * x ≡ x
    *-identityʳ : (x : R) → x * 1r ≡ x
    distribˡ : (x y z : R) → x * (y + z) ≡ (x * y) + (x * z)
    distribʳ : (x y z : R) → (x + y) * z ≡ (x * z) + (y * z)

module RingLemmas {ℓ : Level} (A : CRing ℓ) where
  open CRing A public

  infixl 6 _-_
  _-_ : R → R → R
  x - y = x + (- y)

  +-inverse-cancelˡ : (a b : R) → (- a) + (a + b) ≡ b
  +-inverse-cancelˡ a b =
    begin
      (- a) + (a + b)
    ≡⟨ sym (+-assoc (- a) a b) ⟩
      ((- a) + a) + b
    ≡⟨ cong (_+ b) (+-inverseˡ a) ⟩
      0r + b
    ≡⟨ +-identityˡ b ⟩
      b ∎

  +-inverse-cancelʳ : (a b : R) → (a + b) + (- b) ≡ a
  +-inverse-cancelʳ a b =
    trans (+-assoc a b (- b))
      (trans (cong (a +_) (+-inverseʳ b)) (+-identityʳ a))

  +-cancelˡ : (a : R) {b c : R} → a + b ≡ a + c → b ≡ c
  +-cancelˡ a {b} {c} p =
    trans (sym (+-inverse-cancelˡ a b))
      (trans (cong ((- a) +_) p) (+-inverse-cancelˡ a c))

  +-cancelʳ : (a : R) {b c : R} → b + a ≡ c + a → b ≡ c
  +-cancelʳ a {b} {c} p =
    +-cancelˡ a (trans (+-comm a b) (trans p (+-comm c a)))

  *-zeroʳ : (x : R) → x * 0r ≡ 0r
  *-zeroʳ x = +-cancelˡ (x * 0r)
    (begin
       (x * 0r) + (x * 0r)
     ≡⟨ sym (distribˡ x 0r 0r) ⟩
       x * (0r + 0r)
     ≡⟨ cong (x *_) (+-identityˡ 0r) ⟩
       x * 0r
     ≡⟨ sym (+-identityʳ (x * 0r)) ⟩
       (x * 0r) + 0r ∎)

  *-zeroˡ : (x : R) → 0r * x ≡ 0r
  *-zeroˡ x = trans (*-comm 0r x) (*-zeroʳ x)

  +-swap : (a b c : R) → a + (b + c) ≡ b + (a + c)
  +-swap a b c =
    trans (sym (+-assoc a b c))
      (trans (cong (_+ c) (+-comm a b)) (+-assoc b a c))

  +-shuffle : (a b c d : R) → (a + b) + (c + d) ≡ (a + c) + (b + d)
  +-shuffle a b c d =
    trans (+-assoc a b (c + d))
      (trans (cong (a +_) (+-swap b c d)) (sym (+-assoc a c (b + d))))

  *-swap : (a b c : R) → a * (b * c) ≡ b * (a * c)
  *-swap a b c =
    trans (sym (*-assoc a b c))
      (trans (cong (_* c) (*-comm a b)) (*-assoc b a c))

  *-shuffle : (a b c d : R) → (a * b) * (c * d) ≡ (a * c) * (b * d)
  *-shuffle a b c d =
    trans (*-assoc a b (c * d))
      (trans (cong (a *_) (*-swap b c d)) (sym (*-assoc a c (b * d))))

  neg-unique : (x y : R) → x + y ≡ 0r → y ≡ (- x)
  neg-unique x y p = +-cancelˡ x (trans p (sym (+-inverseʳ x)))

  neg-zero : (- 0r) ≡ 0r
  neg-zero = sym (neg-unique 0r 0r (+-identityˡ 0r))

  neg-involutive : (x : R) → (- (- x)) ≡ x
  neg-involutive x = sym (neg-unique (- x) x (+-inverseˡ x))

  neg-add : (x y : R) → (- (x + y)) ≡ (- x) + (- y)
  neg-add x y = sym (neg-unique (x + y) ((- x) + (- y))
    (trans (+-shuffle x y (- x) (- y))
      (trans (cong₂ _+_ (+-inverseʳ x) (+-inverseʳ y)) (+-identityˡ 0r))))

  neg-mulˡ : (x y : R) → (- x) * y ≡ (- (x * y))
  neg-mulˡ x y = neg-unique (x * y) ((- x) * y)
    (trans (sym (distribʳ x (- x) y))
      (trans (cong (_* y) (+-inverseʳ x)) (*-zeroˡ y)))

  neg-mulʳ : (x y : R) → x * (- y) ≡ (- (x * y))
  neg-mulʳ x y = neg-unique (x * y) (x * (- y))
    (trans (sym (distribˡ x y (- y)))
      (trans (cong (x *_) (+-inverseʳ y)) (*-zeroʳ x)))

  neg-mul-neg : (x y : R) → (- x) * (- y) ≡ x * y
  neg-mul-neg x y =
    trans (neg-mulˡ x (- y))
      (trans (cong -_ (neg-mulʳ x y)) (neg-involutive (x * y)))

  expand-product : (a b c d : R) →
    (a + b) * (c + d) ≡ ((a * c) + (a * d)) + ((b * c) + (b * d))
  expand-product a b c d =
    trans (distribʳ a b (c + d))
      (cong₂ _+_ (distribˡ a c d) (distribˡ b c d))

  square-zero-scaled : (d r : R) → d * d ≡ 0r → (d * r) * (d * r) ≡ 0r
  square-zero-scaled d r dd =
    trans (*-shuffle d r d r)
      (trans (cong (_* (r * r)) dd) (*-zeroˡ (r * r)))

  square-zero-product : (d b e : R) → d * d ≡ 0r → (d * b) * (d * e) ≡ 0r
  square-zero-product d b e dd =
    trans (*-shuffle d b d e)
      (trans (cong (_* (b * e)) dd) (*-zeroˡ (b * e)))

  affine-product : (d a b c e : R) → d * d ≡ 0r →
    (a + (d * b)) * (c + (d * e)) ≡ (a * c) + (d * ((a * e) + (c * b)))
  affine-product d a b c e dd =
    begin
      (a + (d * b)) * (c + (d * e))
    ≡⟨ expand-product a (d * b) c (d * e) ⟩
      ((a * c) + (a * (d * e))) + (((d * b) * c) + ((d * b) * (d * e)))
    ≡⟨ cong ((a * c) + (a * (d * e)) +_)
          (trans (cong (((d * b) * c) +_) (square-zero-product d b e dd))
            (+-identityʳ ((d * b) * c))) ⟩
      ((a * c) + (a * (d * e))) + ((d * b) * c)
    ≡⟨ +-assoc (a * c) (a * (d * e)) ((d * b) * c) ⟩
      (a * c) + ((a * (d * e)) + ((d * b) * c))
    ≡⟨ cong ((a * c) +_)
          (cong₂ _+_ (*-swap a d e)
            (trans (*-assoc d b c) (cong (d *_) (*-comm b c)))) ⟩
      (a * c) + ((d * (a * e)) + (d * (c * b)))
    ≡⟨ cong ((a * c) +_) (sym (distribˡ d (a * e) (c * b))) ⟩
      (a * c) + (d * ((a * e) + (c * b))) ∎

  double-mul : (x : R) → (1r + 1r) * x ≡ x + x
  double-mul x = trans (distribʳ 1r 1r x)
    (cong₂ _+_ (*-identityˡ x) (*-identityˡ x))

  square-zero-sum-square : (d e : R) → d * d ≡ 0r → e * e ≡ 0r →
    (d + e) * (d + e) ≡ (1r + 1r) * (d * e)
  square-zero-sum-square d e dd ee =
    begin
      (d + e) * (d + e)
    ≡⟨ expand-product d e d e ⟩
      ((d * d) + (d * e)) + ((e * d) + (e * e))
    ≡⟨ cong₂ _+_ (trans (cong (_+ (d * e)) dd) (+-identityˡ (d * e)))
          (trans (cong ((e * d) +_) ee) (+-identityʳ (e * d))) ⟩
      (d * e) + (e * d)
    ≡⟨ cong ((d * e) +_) (*-comm e d) ⟩
      (d * e) + (d * e)
    ≡⟨ sym (double-mul (d * e)) ⟩
      (1r + 1r) * (d * e) ∎

  square-zero-sum-cube : (d e : R) → d * d ≡ 0r → e * e ≡ 0r →
    ((d + e) * (d + e)) * (d + e) ≡ 0r
  square-zero-sum-cube d e dd ee =
    begin
      ((d + e) * (d + e)) * (d + e)
    ≡⟨ cong (_* (d + e)) (square-zero-sum-square d e dd ee) ⟩
      ((1r + 1r) * (d * e)) * (d + e)
    ≡⟨ *-assoc (1r + 1r) (d * e) (d + e) ⟩
      (1r + 1r) * ((d * e) * (d + e))
    ≡⟨ cong ((1r + 1r) *_) (distribˡ (d * e) d e) ⟩
      (1r + 1r) * (((d * e) * d) + ((d * e) * e))
    ≡⟨ cong ((1r + 1r) *_)
          (cong₂ _+_
            (trans (*-assoc d e d)
              (trans (cong (d *_) (*-comm e d))
                (trans (sym (*-assoc d d e))
                  (trans (cong (_* e) dd) (*-zeroˡ e)))))
            (trans (*-assoc d e e) (trans (cong (d *_) ee) (*-zeroʳ d)))) ⟩
      (1r + 1r) * (0r + 0r)
    ≡⟨ cong ((1r + 1r) *_) (+-identityˡ 0r) ⟩
      (1r + 1r) * 0r
    ≡⟨ *-zeroʳ (1r + 1r) ⟩
      0r ∎
