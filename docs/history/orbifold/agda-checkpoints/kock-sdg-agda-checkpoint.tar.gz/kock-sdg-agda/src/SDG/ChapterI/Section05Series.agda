{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section05Series where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Finite using (Vec; []; _∷_; head; tail; map; snoc; initial; last;
  snoc-initial-last; last-snoc; nat-add-zeroʳ; nat-add-sucʳ; nat-add-comm; _+ℕ_)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section05 as S5
import SDG.Algebra.Nilradical as NR
import SDG.Infinitesimal.Nilpotent as NI

-- D∞ is presented by witnessed nilpotents and equality of their scalar
-- values. Functions used in the representation theorem explicitly respect
-- that equivalence. A witness-dependent function is never treated as a map
-- out of the union subobject.
module Results {ℓ : Level} (A : CRing ℓ)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open S5.Rectangular A H setR using
    (coefficients-all; reconstruction-all; uniqueness-all;
     coefficient-extensionality-all)
  open NR.Results A using (nilpotent-sum; nilpotent-neg)

  open NI.Times A public

  -- Initial coefficients of a formal power series, in ascending order.
  prefix : (ℕ → R) → (n : ℕ) → Vec R n
  prefix α zero = []
  prefix α (suc n) = snoc (prefix α n) (α n)

  prefix-cong : (α β : ℕ → R) → ((i : ℕ) → α i ≡ β i) →
    (n : ℕ) → prefix α n ≡ prefix β n
  prefix-cong α β p zero = refl
  prefix-cong α β p (suc n) = cong₂ snoc (prefix-cong α β p n) (p n)

  last-prefix : (α : ℕ → R) (n : ℕ) → last (prefix α (suc n)) ≡ α n
  last-prefix α n = last-snoc (prefix α n) (α n)

  eval-snoc : {n : ℕ} (as : Vec R n) (a x : R) →
    eval (snoc as a) x ≡ eval as x + (x ^ n) * a
  eval-snoc [] a x = trans (eval-constant a x)
    (sym (trans (+-identityˡ (1r * a)) (*-identityˡ a)))
  eval-snoc {suc n} (b ∷ bs) a x =
    trans (cong (λ z → b + x * z) (eval-snoc bs a x))
      (trans (cong (b +_) (distribˡ x (eval bs x) ((x ^ n) * a)))
        (trans (sym (+-assoc b (x * eval bs x) (x * ((x ^ n) * a))))
          (cong ((b + x * eval bs x) +_) (sym (*-assoc x (x ^ n) a)))))

  eval-initial-last : {n : ℕ} (as : Vec R (suc n)) (x : R) →
    eval as x ≡ eval (initial as) x + (x ^ n) * last as
  eval-initial-last as x =
    trans (cong (λ bs → eval bs x) (sym (snoc-initial-last as)))
      (eval-snoc (initial as) (last as) x)

  eval-truncate : {n : ℕ} (as : Vec R (suc n)) (x : R) →
    x ^ n ≡ 0r → eval as x ≡ eval (initial as) x
  eval-truncate {n} as x nil =
    trans (eval-initial-last as x)
      (trans (cong (eval (initial as) x +_)
        (trans (cong (_* last as) nil) (*-zeroˡ (last as))))
        (+-identityʳ (eval (initial as) x)))

  jet : (D∞ → R) → (k : ℕ) → Vec R (suc k)
  jet f k = coefficients-all k (λ d → f (witnessed k d))

  -- Compatibility is derived from uniqueness of the KL polynomial; it is
  -- not a field supplied with a formal power series or with a function.
  jet-compatible : (f : D∞ → R) → Respects∞ f → (k : ℕ) →
    initial (jet f (suc k)) ≡ jet f k
  jet-compatible f respects k = coefficient-extensionality-all k
    (initial (jet f (suc k))) (jet f k) (λ d →
      trans (sym (eval-truncate (jet f (suc k)) (valueK d) (nilpotence d)))
        (trans (sym (reconstruction-all (suc k)
          (λ e → f (witnessed (suc k) e)) (weakenK d)))
          (trans (respects (witnessed (suc k) (weakenK d)) (witnessed k d) refl)
            (reconstruction-all k (λ e → f (witnessed k e)) d))))

  seriesOf : (D∞ → R) → ℕ → R
  seriesOf f k = last (jet f k)

  prefix-jet : (f : D∞ → R) → Respects∞ f → (k : ℕ) →
    prefix (seriesOf f) (suc k) ≡ jet f k
  prefix-jet f respects zero = snoc-initial-last (jet f zero)
  prefix-jet f respects (suc k) =
    trans (cong (λ as → snoc as (seriesOf f (suc k))) (prefix-jet f respects k))
      (trans (cong (λ as → snoc as (seriesOf f (suc k)))
        (sym (jet-compatible f respects k))) (snoc-initial-last (jet f (suc k))))

  evaluateSeries : (ℕ → R) → D∞ → R
  evaluateSeries α (witnessed k d) = eval (prefix α (suc k)) (valueK d)

  evaluateSeries-cong : (α β : ℕ → R) → ((i : ℕ) → α i ≡ β i) →
    (d : D∞) → evaluateSeries α d ≡ evaluateSeries β d
  evaluateSeries-cong α β p (witnessed k d) =
    cong (λ as → eval as (valueK d)) (prefix-cong α β p (suc k))

  representation-one : (f : D∞ → R) → Respects∞ f →
    (d : D∞) → f d ≡ evaluateSeries (seriesOf f) d
  representation-one f respects (witnessed k d) =
    trans (reconstruction-all k (λ e → f (witnessed k e)) d)
      (cong (λ as → eval as (valueK d)) (sym (prefix-jet f respects k)))

  seriesOf-cong : (f g : D∞ → R) → ((d : D∞) → f d ≡ g d) →
    (k : ℕ) → seriesOf f k ≡ seriesOf g k
  seriesOf-cong f g p k = cong last (uniqueness-all k
    (λ d → f (witnessed k d)) (jet g k) (λ d →
      trans (p (witnessed k d))
        (reconstruction-all k (λ e → g (witnessed k e)) d)))

  unique-one : (f : D∞ → R) (α : ℕ → R) →
    ((d : D∞) → f d ≡ evaluateSeries α d) →
    (k : ℕ) → seriesOf f k ≡ α k
  unique-one f α represents k =
    trans (cong last (uniqueness-all k (λ d → f (witnessed k d))
      (prefix α (suc k)) (λ d → represents (witnessed k d)))) (last-prefix α k)

  series-injective : (α β : ℕ → R) →
    ((d : D∞) → evaluateSeries α d ≡ evaluateSeries β d) →
    (k : ℕ) → α k ≡ β k
  series-injective α β p k =
    trans (sym (last-prefix α k))
      (trans (cong last (coefficient-extensionality-all k
        (prefix α (suc k)) (prefix β (suc k)) (λ d → p (witnessed k d))))
        (last-prefix β k))

  -- A longer polynomial prefix has the same value after the first
  -- vanishing power. This proves independence of the nilpotence witness.
  prefix-cutoff : (α : ℕ → R) (x : R) (n m : ℕ) → x ^ n ≡ 0r →
    eval (prefix α (n +ℕ m)) x ≡ eval (prefix α n) x
  prefix-cutoff α x n zero nil = cong (λ k → eval (prefix α k) x) (nat-add-zeroʳ n)
  prefix-cutoff α x n (suc m) nil =
    trans (cong (λ k → eval (prefix α k) x) (nat-add-sucʳ n m))
      (trans (eval-snoc (prefix α (n +ℕ m)) (α (n +ℕ m)) x)
        (trans (cong (eval (prefix α (n +ℕ m)) x +_)
          (trans (cong (_* α (n +ℕ m)) (nilpotent-monotone x n m nil))
            (*-zeroˡ (α (n +ℕ m)))))
          (trans (+-identityʳ (eval (prefix α (n +ℕ m)) x))
            (prefix-cutoff α x n m nil))))

  evaluateSeries-respects : (α : ℕ → R) → Respects∞ (evaluateSeries α)
  evaluateSeries-respects α (witnessed k d) (witnessed l e) same-value =
    trans (cong (eval (prefix α (suc k))) same-value)
      (trans (sym (prefix-cutoff α (valueK e) (suc k) (suc l)
        (trans (cong (_^ suc k) (sym same-value)) (nilpotence d))))
        (trans (cong (λ n → eval (prefix α n) (valueK e))
          (nat-add-comm (suc k) (suc l)))
          (prefix-cutoff α (valueK e) (suc l) (suc k) (nilpotence e))))

  -- Finite products of the witnessed union, with equality of scalar vectors.
  Points∞ : ℕ → Set ℓ
  Points∞ n = Vec D∞ n

  values : {n : ℕ} → Points∞ n → Vec R n
  values = map scalar

  Respects : {n : ℕ} → (Points∞ n → R) → Set ℓ
  Respects {n} f = (ds es : Points∞ n) → values ds ≡ values es → f ds ≡ f es

  FormalSeries : ℕ → Set ℓ
  FormalSeries n = Vec ℕ n → R

  evaluateFormal : {n : ℕ} → FormalSeries n → Points∞ n → R
  evaluateFormal {zero} α [] = α []
  evaluateFormal {suc n} α (d ∷ ds) =
    evaluateSeries (λ k → evaluateFormal (λ ks → α (k ∷ ks)) ds) d

  evaluateFormal-cong : {n : ℕ} (α β : FormalSeries n) →
    ((ks : Vec ℕ n) → α ks ≡ β ks) →
    (ds : Points∞ n) → evaluateFormal α ds ≡ evaluateFormal β ds
  evaluateFormal-cong {zero} α β p [] = p []
  evaluateFormal-cong {suc n} α β p (d ∷ ds) =
    evaluateSeries-cong
      (λ k → evaluateFormal (λ ks → α (k ∷ ks)) ds)
      (λ k → evaluateFormal (λ ks → β (k ∷ ks)) ds)
      (λ k → evaluateFormal-cong (λ ks → α (k ∷ ks)) (λ ks → β (k ∷ ks))
        (λ ks → p (k ∷ ks)) ds) d

  -- Formal evaluation is a map on the setoid, independent in every
  -- coordinate of the chosen bound and the nilpotence proof.
  evaluateFormal-respects : {n : ℕ} (α : FormalSeries n) →
    Respects (evaluateFormal α)
  evaluateFormal-respects {zero} α [] [] same-values = refl
  evaluateFormal-respects {suc n} α (d ∷ ds) (e ∷ es) same-values =
    trans (evaluateSeries-respects
      (λ k → evaluateFormal (λ ks → α (k ∷ ks)) ds) d e (cong head same-values))
      (evaluateSeries-cong
        (λ k → evaluateFormal (λ ks → α (k ∷ ks)) ds)
        (λ k → evaluateFormal (λ ks → α (k ∷ ks)) es)
        (λ k → evaluateFormal-respects (λ ks → α (k ∷ ks))
          ds es (cong tail same-values)) e)

  coefficientFunction : {n : ℕ} → (Points∞ (suc n) → R) → ℕ → Points∞ n → R
  coefficientFunction f k ds = seriesOf (λ d → f (d ∷ ds)) k

  coefficientFunction-respects : {n : ℕ} (f : Points∞ (suc n) → R) →
    Respects f → (k : ℕ) → Respects (coefficientFunction f k)
  coefficientFunction-respects f respects k ds es same-values =
    seriesOf-cong (λ d → f (d ∷ ds)) (λ d → f (d ∷ es))
      (λ d → respects (d ∷ ds) (d ∷ es) (cong (scalar d ∷_) same-values)) k

  row-respects : {n : ℕ} (f : Points∞ (suc n) → R) →
    Respects f → (ds : Points∞ n) → Respects∞ (λ d → f (d ∷ ds))
  row-respects f respects ds d e same-value =
    respects (d ∷ ds) (e ∷ ds) (cong (_∷ values ds) same-value)

  representingSeries : {n : ℕ} → (Points∞ n → R) → FormalSeries n
  representingSeries {zero} f [] = f []
  representingSeries {suc n} f (k ∷ ks) =
    representingSeries (coefficientFunction f k) ks

  -- Theorem I.5.3, existence in every finite dimension. Each coefficient
  -- is extracted from a finite KL jet and all evaluation is finite.
  formal-representation : {n : ℕ} (f : Points∞ n → R) → Respects f →
    (ds : Points∞ n) → f ds ≡ evaluateFormal (representingSeries f) ds
  formal-representation {zero} f respects [] = refl
  formal-representation {suc n} f respects (d ∷ ds) =
    trans (representation-one (λ e → f (e ∷ ds)) (row-respects f respects ds) d)
      (evaluateSeries-cong (λ k → seriesOf (λ e → f (e ∷ ds)) k)
        (λ k → evaluateFormal (representingSeries (coefficientFunction f k)) ds)
        (λ k → formal-representation (coefficientFunction f k)
          (coefficientFunction-respects f respects k) ds) d)

  -- Theorem I.5.3, uniqueness, coefficient by coefficient. No function
  -- extensionality is needed to conclude equality at every multi-index.
  formal-injective : {n : ℕ} (α β : FormalSeries n) →
    ((ds : Points∞ n) → evaluateFormal α ds ≡ evaluateFormal β ds) →
    (ks : Vec ℕ n) → α ks ≡ β ks
  formal-injective {zero} α β p [] = p []
  formal-injective {suc n} α β p (k ∷ ks) =
    formal-injective (λ js → α (k ∷ js)) (λ js → β (k ∷ js))
      (λ ds → series-injective
        (λ j → evaluateFormal (λ js → α (j ∷ js)) ds)
        (λ j → evaluateFormal (λ js → β (j ∷ js)) ds)
        (λ d → p (d ∷ ds)) k) ks

  formal-unique : {n : ℕ} (f : Points∞ n → R) → Respects f →
    (α : FormalSeries n) → ((ds : Points∞ n) → f ds ≡ evaluateFormal α ds) →
    (ks : Vec ℕ n) → representingSeries f ks ≡ α ks
  formal-unique f respects α represents =
    formal-injective (representingSeries f) α
      (λ ds → trans (sym (formal-representation f respects ds)) (represents ds))

  recover-formal : {n : ℕ} (α : FormalSeries n) (ks : Vec ℕ n) →
    representingSeries (evaluateFormal α) ks ≡ α ks
  recover-formal α =
    formal-unique (evaluateFormal α) (evaluateFormal-respects α) α (λ ds → refl)

  -- Exercise I.5.2. A function preserving the origin preserves each finite
  -- nilpotence order, rather than merely mapping nilpotents to nilpotents.
  jet-constant : (f : D∞ → R) → Respects∞ f → (k : ℕ) →
    head (jet f k) ≡ f zero∞
  jet-constant f respects k =
    trans (sym (eval-zero (jet f k)))
      (trans (sym (reconstruction-all k (λ d → f (witnessed k d)) (zeroK k)))
        (respects (witnessed k (zeroK k)) zero∞ refl))

  private
    eval-head-tail : {n : ℕ} (as : Vec R (suc n)) (x : R) →
      eval as x ≡ head as + x * eval (tail as) x
    eval-head-tail (a ∷ as) x = refl

  origin-factorization : (f : D∞ → R) → Respects∞ f → f zero∞ ≡ 0r →
    (k : ℕ) (d : DK k) →
    f (witnessed k d) ≡ valueK d * eval (tail (jet f k)) (valueK d)
  origin-factorization f respects origin k d =
    trans (reconstruction-all k (λ e → f (witnessed k e)) d)
      (trans (eval-head-tail (jet f k) (valueK d))
        (trans (cong (_+ (valueK d * eval (tail (jet f k)) (valueK d)))
          (trans (jet-constant f respects k) origin))
          (+-identityˡ (valueK d * eval (tail (jet f k)) (valueK d)))))

  preserves-nilpotence-order : (f : D∞ → R) → Respects∞ f → f zero∞ ≡ 0r →
    (k : ℕ) (d : DK k) → f (witnessed k d) ^ suc k ≡ 0r
  preserves-nilpotence-order f respects origin k d =
    trans (cong (_^ suc k) (origin-factorization f respects origin k d))
      (nilpotent-scaled (valueK d) (eval (tail (jet f k)) (valueK d))
        (suc k) (nilpotence d))

  origin-map : (f : D∞ → R) → Respects∞ f → f zero∞ ≡ 0r → D∞ → D∞
  origin-map f respects origin (witnessed k d) = witnessed k
    (nilpotent (f (witnessed k d)) (preserves-nilpotence-order f respects origin k d))

  origin-map-respects : (f : D∞ → R) (respects : Respects∞ f) (origin : f zero∞ ≡ 0r) →
    (d e : D∞) → d ≈∞ e → origin-map f respects origin d ≈∞ origin-map f respects origin e
  origin-map-respects f respects origin = respects


