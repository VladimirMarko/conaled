{-# OPTIONS --safe --without-K #-}
module SDG.Combinatorics.SignatureCofactor where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Finite using (Fin; fzero; fsuc; finToNat; skip;
  Permutation; to; from; from-to; to-from; inversePerm)
open import Agda.Builtin.Bool using (Bool; true; false)
open import SDG.Combinatorics.Signature
open import SDG.Forms.CubicalGeometry using (minor; module Minor; skip-distinct)

not : Bool → Bool
not true = false
not false = true

and-comm : (a b : Bool) → (a and b) ≡ (b and a)
and-comm true true = refl
and-comm true false = refl
and-comm false true = refl
and-comm false false = refl

less-self : {n : ℕ} (i : Fin n) → less i i ≡ false
less-self fzero = refl
less-self (fsuc i) = less-self i

less-zero : {n : ℕ} (i : Fin (suc n)) → less i fzero ≡ false
less-zero fzero = refl
less-zero (fsuc i) = refl

less-complement : {n : ℕ} (i j : Fin n) → i ≢ j → less i j ≡ not (less j i)
less-complement fzero fzero ne = ⊥-elim (ne refl)
less-complement fzero (fsuc j) ne = refl
less-complement (fsuc i) fzero ne = refl
less-complement (fsuc i) (fsuc j) ne = less-complement i j (λ p → ne (cong fsuc p))

less-skip : {n : ℕ} (r : Fin (suc n)) (i j : Fin n) → less (skip r i) (skip r j) ≡ less i j
less-skip fzero i j = refl
less-skip {n = suc n} (fsuc r) fzero fzero = refl
less-skip {n = suc n} (fsuc r) fzero (fsuc j) = refl
less-skip {n = suc n} (fsuc r) (fsuc i) fzero = refl
less-skip {n = suc n} (fsuc r) (fsuc i) (fsuc j) = less-skip r i j

module Cofactor {ℓ : Level} (A : CRing ℓ) where
  open PowerLemmas A
  open Sign A

  product : {n : ℕ} → (Fin n → R) → R
  product {zero} f = 1r
  product {suc n} f = f fzero * product (λ i → f (fsuc i))

  product-cong : {n : ℕ} {f g : Fin n → R} → ((i : Fin n) → f i ≡ g i) → product f ≡ product g
  product-cong {zero} eq = refl
  product-cong {suc n} eq = cong₂ _*_ (eq fzero) (product-cong (λ i → eq (fsuc i)))

  product-one : (n : ℕ) → product {n} (λ _ → 1r) ≡ 1r
  product-one zero = refl
  product-one (suc n) = trans (*-identityˡ _) (product-one n)

  product-multiply : {n : ℕ} (f g : Fin n → R) →
    product (λ i → f i * g i) ≡ product f * product g
  product-multiply {zero} f g = sym (*-identityˡ 1r)
  product-multiply {suc n} f g =
    trans (cong ((f fzero * g fzero) *_) (product-multiply (λ i → f (fsuc i)) (λ i → g (fsuc i))))
      (*-shuffle (f fzero) (g fzero) (product (λ i → f (fsuc i))) (product (λ i → g (fsuc i))))

  product-swap : {n m : ℕ} (f : Fin n → Fin m → R) →
    product (λ i → product (f i)) ≡ product (λ j → product (λ i → f i j))
  product-swap {zero} {m} f = sym (product-one m)
  product-swap {suc n} f =
    trans (cong (product (f fzero) *_) (product-swap (λ i j → f (fsuc i) j)))
      (sym (product-multiply (f fzero) (λ j → product (λ i → f (fsuc i) j))))

  product-remove : {n : ℕ} (f : Fin (suc n) → R) (i : Fin (suc n)) →
    product f ≡ f i * product (λ j → f (skip i j))
  product-remove f fzero = refl
  product-remove {suc n} f (fsuc i) =
    trans (cong (f fzero *_) (product-remove (λ j → f (fsuc j)) i))
      (*-swap (f fzero) (f (fsuc i)) (product (λ j → f (fsuc (skip i j)))))

  product-omit-one : {n : ℕ} (f : Fin (suc n) → R) (i : Fin (suc n)) →
    f i ≡ 1r → product (λ j → f (skip i j)) ≡ product f
  product-omit-one f i eq = sym
    (trans (product-remove f i) (trans (cong (_* product (λ j → f (skip i j))) eq) (*-identityˡ _)))

  product-permute : {n : ℕ} (p : Permutation n) (f : Fin n → R) →
    product (λ i → f (to p i)) ≡ product f
  product-permute {zero} p f = refl
  product-permute {suc n} p f =
    trans (cong (f (to p fzero) *_) (product-cong (λ j → cong f (sym (tail-reconstruct j)))))
      (trans (cong (f (to p fzero) *_)
        (product-permute (minor p (to p fzero)) (λ j → f (skip (to p fzero) j))))
        (sym (product-remove f (to p fzero))))
    where
    tail-reconstruct : (j : Fin n) →
      skip (to p fzero) (to (minor p (to p fzero)) j) ≡ to p (fsuc j)
    tail-reconstruct j = trans (Minor.forward-reconstruct p (to p fzero) j)
      (cong (to p) (cong (λ r → skip r j) (from-to p fzero)))

  flip : Bool → R
  flip true = - 1r
  flip false = 1r

  sign-index : {n : ℕ} → Fin n → R
  sign-index i = (- 1r) ^ finToNat i

  negative-one-square : (- 1r) * (- 1r) ≡ 1r
  negative-one-square = trans (neg-mul-neg 1r 1r) (*-identityˡ 1r)

  sign-index-square : {n : ℕ} (i : Fin n) → sign-index i * sign-index i ≡ 1r
  sign-index-square i = trans (sym (power-product (- 1r) (- 1r) (finToNat i)))
    (trans (cong (_^ finToNat i) negative-one-square) (one-power (finToNat i)))

  product-count : {n : ℕ} (f : Fin n → Bool) → (- 1r) ^ count f ≡ product (λ i → flip (f i))
  product-count {zero} f = refl
  product-count {suc n} f with f fzero
  ... | true = cong ((- 1r) *_) (product-count (λ i → f (fsuc i)))
  ... | false = trans (product-count (λ i → f (fsuc i))) (sym (*-identityˡ _))

  product-natural-sum : {n : ℕ} (f : Fin n → ℕ) →
    (- 1r) ^ sum-natural f ≡ product (λ i → (- 1r) ^ f i)
  product-natural-sum {zero} f = refl
  product-natural-sum {suc n} f =
    trans (power-add (- 1r) (f fzero) (sum-natural (λ i → f (fsuc i))))
      (cong (((- 1r) ^ f fzero) *_) (product-natural-sum (λ i → f (fsuc i))))

  inversion-factor : {n : ℕ} → Permutation n → Fin n → Fin n → R
  inversion-factor p i j = flip (less i j and less (to p j) (to p i))

  signature-product : {n : ℕ} (p : Permutation n) →
    signature p ≡ product (λ i → product (inversion-factor p i))
  signature-product p =
    trans (product-natural-sum (λ i → count (λ j → less i j and less (to p j) (to p i))))
      (product-cong (λ i → product-count (λ j → less i j and less (to p j) (to p i))))

  -- Removing the selected row and column from a finite product matrix.
  matrix-remove : {n : ℕ} (f : Fin (suc n) → Fin (suc n) → R) (r : Fin (suc n)) → f r r ≡ 1r →
    product (λ i → product (f i)) ≡
      product (λ j → f r (skip r j) * f (skip r j) r) *
        product (λ i → product (λ j → f (skip r i) (skip r j)))
  matrix-remove f r eq =
    begin
      product (λ i → product (f i))
    ≡⟨ product-remove (λ i → product (f i)) r ⟩
      product (f r) * product (λ i → product (f (skip r i)))
    ≡⟨ cong₂ _*_ (product-remove (f r) r)
          (product-cong (λ i → product-remove (f (skip r i)) r)) ⟩
      (f r r * product (λ j → f r (skip r j))) *
        product (λ i → f (skip r i) r * product (λ j → f (skip r i) (skip r j)))
    ≡⟨ cong₂ _*_ (trans (cong (_* product (λ j → f r (skip r j))) eq) (*-identityˡ _))
          (product-multiply (λ i → f (skip r i) r) (λ i → product (λ j → f (skip r i) (skip r j)))) ⟩
      product (λ j → f r (skip r j)) *
        (product (λ i → f (skip r i) r) * product (λ i → product (λ j → f (skip r i) (skip r j))))
    ≡⟨ sym (*-assoc (product (λ j → f r (skip r j)))
          (product (λ i → f (skip r i) r)) (product (λ i → product (λ j → f (skip r i) (skip r j))))) ⟩
      (product (λ j → f r (skip r j)) * product (λ i → f (skip r i) r)) *
        product (λ i → product (λ j → f (skip r i) (skip r j)))
    ≡⟨ cong (_* product (λ i → product (λ j → f (skip r i) (skip r j))))
          (sym (product-multiply (λ j → f r (skip r j)) (λ j → f (skip r j) r))) ⟩
      product (λ j → f r (skip r j) * f (skip r j) r) *
        product (λ i → product (λ j → f (skip r i) (skip r j))) ∎

  threshold-product : {n : ℕ} (i : Fin n) → product (λ j → flip (less j i)) ≡ sign-index i
  threshold-product {suc n} fzero =
    trans (product-cong {n = suc n} (λ j → cong flip (less-zero j))) (product-one (suc n))
  threshold-product {suc n} (fsuc i) = cong ((- 1r) *_) (threshold-product i)

  crossing-boolean : (a b : Bool) →
    flip (a and b) * flip (not a and not b) ≡ flip (not a) * flip b
  crossing-boolean true true = trans (*-identityʳ (- 1r)) (sym (*-identityˡ (- 1r)))
  crossing-boolean true false = refl
  crossing-boolean false true = trans (*-identityˡ 1r) (sym negative-one-square)
  crossing-boolean false false = trans (*-identityˡ (- 1r)) (sym (*-identityʳ (- 1r)))

  crossing-factor : {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) (j : Fin n) →
    inversion-factor p (from p i) (skip (from p i) j) *
      inversion-factor p (skip (from p i) j) (from p i) ≡
      flip (less (skip (from p i) j) (from p i)) *
        flip (less (to p (skip (from p i) j)) i)
  crossing-factor p i j =
    trans (cong₂ _*_
      (cong (λ x → flip (less (from p i) (skip (from p i) j) and
        less (to p (skip (from p i) j)) x)) (to-from p i))
      (cong (λ x → flip (less (skip (from p i) j) (from p i) and
        less x (to p (skip (from p i) j)))) (to-from p i)))
      (trans (cong₂ _*_ refl
        (cong₂ (λ a b → flip (a and b))
          (less-complement (skip (from p i) j) (from p i) (skip-distinct (from p i) j))
          (less-complement i (to p (skip (from p i) j)) (λ eq → Minor.forward-distinct p i j (sym eq)))))
        (trans (crossing-boolean (less (from p i) (skip (from p i) j))
          (less (to p (skip (from p i) j)) i))
          (cong (_* flip (less (to p (skip (from p i) j)) i))
            (cong flip (sym (less-complement (skip (from p i) j) (from p i)
              (skip-distinct (from p i) j)))))))

  minor-factor : {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) (j k : Fin n) →
    inversion-factor p (skip (from p i) j) (skip (from p i) k) ≡ inversion-factor (minor p i) j k
  minor-factor p i j k = cong₂ (λ a b → flip (a and b))
    (less-skip (from p i) j k)
    (trans (cong₂ less (sym (Minor.forward-reconstruct p i k)) (sym (Minor.forward-reconstruct p i j)))
      (less-skip i (to (minor p i) k) (to (minor p i) j)))

  crossing-product : {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) →
    product (λ j → inversion-factor p (from p i) (skip (from p i) j) *
      inversion-factor p (skip (from p i) j) (from p i)) ≡ sign-index (from p i) * sign-index i
  crossing-product p i =
    trans (product-cong (crossing-factor p i))
      (trans (product-multiply (λ j → flip (less (skip (from p i) j) (from p i)))
        (λ j → flip (less (to p (skip (from p i) j)) i)))
        (cong₂ _*_
          (trans (product-omit-one (λ j → flip (less j (from p i))) (from p i)
            (cong flip (less-self (from p i)))) (threshold-product (from p i)))
          (trans (product-omit-one (λ j → flip (less (to p j) i)) (from p i)
            (cong flip (trans (cong (λ x → less x i) (to-from p i)) (less-self i))))
            (trans (product-permute p (λ j → flip (less j i))) (threshold-product i)))))

  signature-delete : {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) →
    signature p ≡ (sign-index (from p i) * sign-index i) * signature (minor p i)
  signature-delete p i =
    trans (signature-product p)
      (trans (matrix-remove (inversion-factor p) (from p i)
        (cong (λ b → flip (b and less (to p (from p i)) (to p (from p i))))
          (less-self (from p i))))
        (cong₂ _*_ (crossing-product p i)
          (trans (product-cong (λ j → product-cong (minor-factor p i j)))
            (sym (signature-product (minor p i))))))

  -- The exact cofactor identity needed when an alternating cube is
  -- restricted to a face. Signature is still its original inversion
  -- count definition; no permutation-sign axiom is introduced.
  signature-cofactor : {n : ℕ} (p : Permutation (suc n)) (i : Fin (suc n)) →
    sign-index i * signature (minor p i) ≡ signature p * sign-index (from p i)
  signature-cofactor p i = sym
    (trans (cong (_* sign-index (from p i)) (signature-delete p i))
      (reduce (sign-index (from p i)) (sign-index i) (signature (minor p i)) (sign-index-square (from p i))))
    where
    reduce : (a b c : R) → a * a ≡ 1r → ((a * b) * c) * a ≡ b * c
    reduce a b c aa =
      trans (*-comm ((a * b) * c) a)
        (trans (sym (*-assoc a (a * b) c))
          (trans (cong (_* c) (sym (*-assoc a a b)))
            (trans (*-assoc (a * a) b c)
              (trans (cong (_* (b * c)) aa) (*-identityˡ (b * c))))))

  signature-inverse : {n : ℕ} (p : Permutation n) → signature (inversePerm p) ≡ signature p
  signature-inverse p =
    trans (signature-product (inversePerm p))
      (trans (sym (product-permute p (λ i → product (inversion-factor (inversePerm p) i))))
        (trans (product-cong (λ i → sym (product-permute p (inversion-factor (inversePerm p) (to p i)))))
          (trans (product-cong (λ i → product-cong (λ j →
            trans (cong (λ b → flip (less (to p i) (to p j) and b))
              (cong₂ less (from-to p j) (from-to p i)))
              (cong flip (and-comm (less (to p i) (to p j)) (less j i))))))
            (trans (product-swap (λ i j → inversion-factor p j i)) (sym (signature-product p))))))
