{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.PresentedMorphisms where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Presented
open import SDG.Finite using (Fin)

-- The presented algebra is represented by its explicit generated ring
-- congruence, not by equality of polynomial expressions. Thus a morphism
-- is a polynomial image for every generator, respecting the actual
-- presentation equations modulo ring laws and the target relations.
module Morphisms {κ : Level} (k : CRing κ) where
  open Presentations k
  private module K = CRing k
  infix 4 _⊢_≈_

  data _⊢_≈_ (B : Presentation) : Polynomial (generators B) → Polynomial (generators B) → Set κ where
    reflexive : {p : Polynomial (generators B)} → B ⊢ p ≈ p
    symmetric : {p q : Polynomial (generators B)} → B ⊢ p ≈ q → B ⊢ q ≈ p
    transitive : {p q r : Polynomial (generators B)} → B ⊢ p ≈ q → B ⊢ q ≈ r → B ⊢ p ≈ r
    additive : {p p′ q q′ : Polynomial (generators B)} → B ⊢ p ≈ p′ → B ⊢ q ≈ q′ → B ⊢ (p ⊕ q) ≈ (p′ ⊕ q′)
    multiplicative : {p p′ q q′ : Polynomial (generators B)} → B ⊢ p ≈ p′ → B ⊢ q ≈ q′ → B ⊢ (p ⊗ q) ≈ (p′ ⊗ q′)
    negative-cong : {p q : Polynomial (generators B)} → B ⊢ p ≈ q → B ⊢ negative p ≈ negative q
    coefficient-add : (a b : K.R) → B ⊢ coefficient (a K.+ b) ≈ (coefficient a ⊕ coefficient b)
    coefficient-multiply : (a b : K.R) → B ⊢ coefficient (a K.* b) ≈ (coefficient a ⊗ coefficient b)
    coefficient-negative : (a : K.R) → B ⊢ coefficient (K.- a) ≈ negative (coefficient a)
    add-assoc : (p q r : Polynomial (generators B)) → B ⊢ ((p ⊕ q) ⊕ r) ≈ (p ⊕ (q ⊕ r))
    add-comm : (p q : Polynomial (generators B)) → B ⊢ (p ⊕ q) ≈ (q ⊕ p)
    add-zero : (p : Polynomial (generators B)) → B ⊢ (zeroP ⊕ p) ≈ p
    add-inverse : (p : Polynomial (generators B)) → B ⊢ (negative p ⊕ p) ≈ zeroP
    mul-assoc : (p q r : Polynomial (generators B)) → B ⊢ ((p ⊗ q) ⊗ r) ≈ (p ⊗ (q ⊗ r))
    mul-comm : (p q : Polynomial (generators B)) → B ⊢ (p ⊗ q) ≈ (q ⊗ p)
    mul-one : (p : Polynomial (generators B)) → B ⊢ (oneP ⊗ p) ≈ p
    distribute : (p q r : Polynomial (generators B)) → B ⊢ (p ⊗ (q ⊕ r)) ≈ ((p ⊗ q) ⊕ (p ⊗ r))
    relation : (j : Fin (relations B)) → B ⊢ equations B j ≈ zeroP

  from-equality : {B : Presentation} {p q : Polynomial (generators B)} → p ≡ q → B ⊢ p ≈ q
  from-equality refl = reflexive

  sound : {c : Level} {B : Presentation} (C : CRing c) (ι : RingHom k C)
    (x : Spec C (RingHom.hom ι) B) {p q : Polynomial (generators B)} →
    B ⊢ p ≈ q → evaluate C (RingHom.hom ι) p (coordinates x) ≡ evaluate C (RingHom.hom ι) q (coordinates x)
  sound C ι x reflexive = refl
  sound C ι x (symmetric p) = sym (sound C ι x p)
  sound C ι x (transitive p q) = trans (sound C ι x p) (sound C ι x q)
  sound C ι x (additive p q) = cong₂ (CRing._+_ C) (sound C ι x p) (sound C ι x q)
  sound C ι x (multiplicative p q) = cong₂ (CRing._*_ C) (sound C ι x p) (sound C ι x q)
  sound C ι x (negative-cong p) = cong (CRing.-_ C) (sound C ι x p)
  sound C ι x (coefficient-add a b) = RingHom.pres-+ ι a b
  sound C ι x (coefficient-multiply a b) = RingHom.pres-* ι a b
  sound C ι x (coefficient-negative a) = RingHom.pres-neg ι a
  sound C ι x (add-assoc p q r) = CRing.+-assoc C _ _ _
  sound C ι x (add-comm p q) = CRing.+-comm C _ _
  sound C ι x (add-zero p) =
    trans (cong (λ z → CRing._+_ C z (evaluate C (RingHom.hom ι) p (coordinates x))) (RingHom.pres-0 ι))
      (CRing.+-identityˡ C _)
  sound C ι x (add-inverse p) = trans (CRing.+-inverseˡ C _) (sym (RingHom.pres-0 ι))
  sound C ι x (mul-assoc p q r) = CRing.*-assoc C _ _ _
  sound C ι x (mul-comm p q) = CRing.*-comm C _ _
  sound C ι x (mul-one p) =
    trans (cong (λ z → CRing._*_ C z (evaluate C (RingHom.hom ι) p (coordinates x))) (RingHom.pres-1 ι))
      (CRing.*-identityˡ C _)
  sound C ι x (distribute p q r) = CRing.distribˡ C _ _ _
  sound C ι x (relation j) = trans (satisfies x j) (sym (RingHom.pres-0 ι))

  record Hom (B C : Presentation) : Set κ where
    constructor presentation-hom
    field
      images : Fin (generators B) → Polynomial (generators C)
      respects : (j : Fin (relations B)) → C ⊢ substitute images (equations B j) ≈ zeroP
  open Hom public

  substitute-respects : {B C : Presentation} (h : Hom B C)
    {p q : Polynomial (generators B)} → B ⊢ p ≈ q → C ⊢ substitute (images h) p ≈ substitute (images h) q
  substitute-respects h reflexive = reflexive
  substitute-respects h (symmetric p) = symmetric (substitute-respects h p)
  substitute-respects h (transitive p q) = transitive (substitute-respects h p) (substitute-respects h q)
  substitute-respects h (additive p q) = additive (substitute-respects h p) (substitute-respects h q)
  substitute-respects h (multiplicative p q) = multiplicative (substitute-respects h p) (substitute-respects h q)
  substitute-respects h (negative-cong p) = negative-cong (substitute-respects h p)
  substitute-respects h (coefficient-add a b) = coefficient-add a b
  substitute-respects h (coefficient-multiply a b) = coefficient-multiply a b
  substitute-respects h (coefficient-negative a) = coefficient-negative a
  substitute-respects h (add-assoc p q r) = add-assoc _ _ _
  substitute-respects h (add-comm p q) = add-comm _ _
  substitute-respects h (add-zero p) = add-zero _
  substitute-respects h (add-inverse p) = add-inverse _
  substitute-respects h (mul-assoc p q r) = mul-assoc _ _ _
  substitute-respects h (mul-comm p q) = mul-comm _ _
  substitute-respects h (mul-one p) = mul-one _
  substitute-respects h (distribute p q r) = distribute _ _ _
  substitute-respects h (relation j) = respects h j

  identity : (B : Presentation) → Hom B B
  images (identity B) = var
  respects (identity B) j = transitive (from-equality (substitute-identity (equations B j))) (relation j)

  compose : {B C D : Presentation} → Hom C D → Hom B C → Hom B D
  images (compose g f) i = substitute (images g) (images f i)
  respects (compose {B = B} g f) j =
    transitive (from-equality (sym (substitute-compose (images f) (images g) (equations B j))))
    (substitute-respects g (respects f j))

  HomEqual : {B C : Presentation} → Hom B C → Hom B C → Set κ
  HomEqual {C = C} f g = (i : Fin _) → C ⊢ images f i ≈ images g i

  substitute-cong : {B : Presentation} {n : ℕ}
    (σ τ : Fin n → Polynomial (generators B)) → ((i : Fin n) → B ⊢ σ i ≈ τ i) →
    (p : Polynomial n) → B ⊢ substitute σ p ≈ substitute τ p
  substitute-cong σ τ p (coefficient a) = reflexive
  substitute-cong σ τ p (var i) = p i
  substitute-cong σ τ p (f ⊕ g) = additive (substitute-cong σ τ p f) (substitute-cong σ τ p g)
  substitute-cong σ τ p (f ⊗ g) = multiplicative (substitute-cong σ τ p f) (substitute-cong σ τ p g)
  substitute-cong σ τ p (negative f) = negative-cong (substitute-cong σ τ p f)

  identity-left : {B C : Presentation} (f : Hom B C) → HomEqual (compose (identity C) f) f
  identity-left f i = from-equality (substitute-identity (images f i))

  identity-right : {B C : Presentation} (f : Hom B C) → HomEqual (compose f (identity B)) f
  identity-right f i = reflexive

  composition-assoc : {B C D E : Presentation} (f : Hom B C) (g : Hom C D) (h : Hom D E) →
    HomEqual (compose h (compose g f)) (compose (compose h g) f)
  composition-assoc f g h i = from-equality (substitute-compose (images g) (images h) (images f i))

  spec-map : {c : Level} (C : CRing c) (ι : RingHom k C) {B T : Presentation} →
    Hom B T → Spec C (RingHom.hom ι) T → Spec C (RingHom.hom ι) B
  coordinates (spec-map C ι h x) i = evaluate C (RingHom.hom ι) (images h i) (coordinates x)
  satisfies (spec-map C ι {B = B} h x) j =
    trans (sym (evaluate-substitute C (RingHom.hom ι) (images h) (equations B j) (coordinates x)))
      (trans (sound C ι x (respects h j)) (RingHom.pres-0 ι))

  spec-identity : {c : Level} (C : CRing c) (ι : RingHom k C)
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) (B : Presentation) (x : Spec C (RingHom.hom ι) B) →
    spec-map C ι (identity B) x ≡ x
  spec-identity C ι ext setC B x = spec-path ext setC (λ i → refl)

  spec-compose : {c : Level} (C : CRing c) (ι : RingHom k C)
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) {B T U : Presentation}
    (f : Hom B T) (g : Hom T U) (x : Spec C (RingHom.hom ι) U) →
    spec-map C ι (compose g f) x ≡ spec-map C ι f (spec-map C ι g x)
  spec-compose C ι ext setC f g x = spec-path ext setC
    (λ i → evaluate-substitute C (RingHom.hom ι) (images g) (images f i) (coordinates x))

  spec-map-cong : {c : Level} (C : CRing c) (ι : RingHom k C)
    (ext : FunExt lzero c) (setC : isSet (CRing.R C)) {B T : Presentation}
    (f g : Hom B T) → HomEqual f g → (x : Spec C (RingHom.hom ι) T) → spec-map C ι f x ≡ spec-map C ι g x
  spec-map-cong C ι ext setC f g p x = spec-path ext setC (λ i → sound C ι x (p i))

  difference-zero : {B : Presentation} (p q : Polynomial (generators B)) →
    B ⊢ (p ⊕ negative q) ≈ zeroP → B ⊢ p ≈ q
  difference-zero p q eq = transitive
    (symmetric (transitive (add-assoc p (negative q) q)
      (transitive (additive reflexive (add-inverse q))
        (transitive (add-comm p zeroP) (add-zero p)))))
    (transitive (additive eq reflexive) (add-zero q))
