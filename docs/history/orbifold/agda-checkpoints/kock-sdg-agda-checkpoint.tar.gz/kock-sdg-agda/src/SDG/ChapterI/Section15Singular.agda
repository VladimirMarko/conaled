{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section15Singular where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Order
open import SDG.Finite using (Fin; fzero; fsuc; lookup; delete; replicate; _∷_)
import SDG.Forms.Currents as FC
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section15 as S15

module Results {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setR : isSet (CRing.R A)) where
  open S15.Stokes A K O J ext0 ext setR public
  module AllCurrents = FC.Currents A (scalarModule A) ext0 ext setR

  delete-unit-box : {n : ℕ} (i : Fin (suc n)) → delete (unitBox (suc n)) i ≡ unitBox n
  delete-unit-box fzero = refl
  delete-unit-box {suc n} (fsuc i) = cong (unitSegment ∷_) (delete-unit-box i)

  castPoint : {n : ℕ} {ss tt : Box n} → ss ≡ tt → Point ss → Point tt
  castPoint refl xs = xs

  transport-pushforward : {n : ℕ} {M : Set ℓ} {ss tt : Box n} (p : ss ≡ tt) (f : Point ss → M) →
    pushforward f (canonicalCurrent ss) ≡ pushforward (f ∘ castPoint (sym p)) (canonicalCurrent tt)
  transport-pushforward refl f = refl

  singularFace : {n : ℕ} {M : Set ℓ} → (Point (unitBox (suc n)) → M) →
    (i : Fin (suc n)) → Carrier (lookup (unitBox (suc n)) i) → Point (unitBox n) → M
  singularFace {n} f i x = f ∘ insertPoint (unitBox (suc n)) i x ∘ castPoint (sym (delete-unit-box i))

  face-is-singular : {n : ℕ} {M : Set ℓ} (f : Point (unitBox (suc n)) → M)
    (i : Fin (suc n)) (x : Carrier (lookup (unitBox (suc n)) i)) →
    pushforward f (faceCurrent (unitBox (suc n)) i x) ≡ singularCurrent (singularFace f i x)
  face-is-singular {n} f i x = trans
    (sym (AllCurrents.pushforward-compose (insertPoint (unitBox (suc n)) i x) f
      (canonicalCurrent (delete (unitBox (suc n)) i))))
    (transport-pushforward (delete-unit-box i) (f ∘ insertPoint (unitBox (suc n)) i x))

  pushforward-signed-sum : {n m : ℕ} {M N : Set ℓ} (f : M → N) (γ : Fin m → Current n M) →
    pushforward f (C.CurrentSums.signedSum n M γ) ≡ C.CurrentSums.signedSum n N (λ i → pushforward f (γ i))
  pushforward-signed-sum f γ = current-ext (λ θ → trans (C.signed-evaluation γ (pullback f θ))
    (sym (C.signed-evaluation (λ i → pushforward f (γ i)) θ)))

  -- The geometric boundary of a singular cube is literally the signed
  -- sum of 2(n+1) singular n-cube currents, each with standard unit-box
  -- domain. The deleted-factor/domain identifications are constructed.
  singular-boundary-faces : {n : ℕ} {M : Set ℓ} (f : Point (unitBox (suc n)) → M) →
    singularBoundary f ≡ C.CurrentSums.signedSum n M (λ i →
      add-current (singularCurrent (singularFace f i (Line.right (lookup (unitBox (suc n)) i))))
        (negate-current (singularCurrent (singularFace f i (Line.left (lookup (unitBox (suc n)) i))))))
  singular-boundary-faces {n} {M} f = trans
    (pushforward-signed-sum f (λ i → add-current
      (faceCurrent (unitBox (suc n)) i (Line.right (lookup (unitBox (suc n)) i)))
      (negate-current (faceCurrent (unitBox (suc n)) i (Line.left (lookup (unitBox (suc n)) i))))))
    (C.CurrentSums.signed-cong n M {f = source} {g = target} (λ i → current-ext (λ θ → cong₂ _-_
      (cong (λ γ → integrate γ θ) (face-is-singular f i (Line.right (lookup (unitBox (suc n)) i))))
      (cong (λ γ → integrate γ θ) (face-is-singular f i (Line.left (lookup (unitBox (suc n)) i)))))))
    where
    source target : Fin (suc n) → Current n M
    source i = pushforward f (add-current
      (faceCurrent (unitBox (suc n)) i (Line.right (lookup (unitBox (suc n)) i)))
      (negate-current (faceCurrent (unitBox (suc n)) i (Line.left (lookup (unitBox (suc n)) i)))))
    target i = add-current
      (singularCurrent (singularFace f i (Line.right (lookup (unitBox (suc n)) i))))
      (negate-current (singularCurrent (singularFace f i (Line.left (lookup (unitBox (suc n)) i)))))
