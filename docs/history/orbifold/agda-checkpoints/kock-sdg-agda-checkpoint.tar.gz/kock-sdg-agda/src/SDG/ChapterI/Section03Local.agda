{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section03Local where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Vec; Fin; fzero; fsuc; finToNat; lookup; tabulate; lookup-tabulate; vec-ext)
import SDG.Calculus.Slope as Slope
import SDG.ChapterI.Section02 as S2
import SDG.ChapterI.Section02Subsets as Sub
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section05 as S5
import SDG.ChapterI.Section05Local as L5

-- The local-domain qualification in Theorem I.3.1. Only the requested
-- nilpotent neighborhood of the center must lie in the domain.
module Results {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (H : S3.HigherInfinitesimals.HigherKockLawvere A)
  (Q : S3.HigherInfinitesimals.PositiveNaturalsInvertible A)
  (setR : isSet (CRing.R A)) where
  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open Sub.Subsets A K using (Domain; Interior; Neighborhood; subtype-path)
  open Slope.Results A K using (slope-cong)
  module Subset = Sub.Subsets A K
  module Local = L5.LocalTaylor A K H Q setR
  module Rect = S5.Rectangular A H setR
  module Global = S3.GeneralTaylor A K H Q
  module Descent = S3.PolynomialDescent A K
  module Calculus = S2.Results A K

  NeighborhoodK : (R → Set ℓ) → ℕ → R → Set ℓ
  NeighborhoodK U n x = (d : DK n) → U (x + valueK d)

  restriction : {U : R → Set ℓ} {n : ℕ} →
    (Domain U → R) → (x : R) → NeighborhoodK U n x → DK n → R
  restriction f x inside d = f ((x + valueK d) , inside d)

  center : {U : R → Set ℓ} {n : ℕ} (x : R) → NeighborhoodK U n x → Domain U
  center {U} {n} x inside = x , subst U (+-identityʳ x) (inside (zeroK n))

  local-iterate : {U : R → Set ℓ} {n : ℕ} →
    (Domain U → R) → (x : R) → NeighborhoodK U n x → Fin (suc n) → R
  local-iterate f x inside i = Local.derivative-at-zero i (restriction f x inside)

  local-iterate-zero : {U : R → Set ℓ} (prop : (x : R) → isProp (U x))
    {n : ℕ} (f : Domain U → R) (x : R) (inside : NeighborhoodK U n x) →
    local-iterate f x inside fzero ≡ f (center x inside)
  local-iterate-zero prop f x inside = cong f (subtype-path prop (+-identityʳ x))

  first-neighborhood : {U : R → Set ℓ} {n : ℕ} (x : R) →
    NeighborhoodK U (suc n) x → Neighborhood U x
  first-neighborhood {U} {n} x inside d = subst U (cong (x +_) (+-identityˡ (value d)))
    (inside (shiftK (zeroK n) d))

  first-local-is-subset-derivative : {U : R → Set ℓ}
    (prop : (x : R) → isProp (U x)) {n : ℕ}
    (f : Domain U → R) (x : R) (inside : NeighborhoodK U (suc n) x) →
    local-iterate f x inside (fsuc fzero) ≡
    Subset.derivative f (x , first-neighborhood {U} x inside)
  first-local-is-subset-derivative {U} prop {n} f x inside = slope-cong
    (λ d → restriction f x inside (shiftK (zeroK n) d))
    (λ d → f (Subset.shifted (x , first-neighborhood {U} x inside) d))
    (λ d → cong f (subtype-path prop (cong (x +_) (+-identityˡ (value d)))))

  local-iterate-independent : {U : R → Set ℓ}
    (prop : (x : R) → isProp (U x)) {n : ℕ} (f : Domain U → R) (x : R)
    (inside other : NeighborhoodK U n x) (i : Fin (suc n)) →
    local-iterate f x inside i ≡ local-iterate f x other i
  local-iterate-independent prop f x inside other i =
    Local.derivative-at-cong i (restriction f x inside) (restriction f x other)
      (λ d → cong f (subtype-path prop refl))

  -- Every coefficient is an actual iterated local derivative divided by i!.
  localTaylorCoefficients : {U : R → Set ℓ} (n : ℕ) →
    (Domain U → R) → (x : R) → NeighborhoodK U n x → Vec R (suc n)
  localTaylorCoefficients n f x inside = tabulate
    (λ i → Global.inverseFactorial (finToNat i) * local-iterate f x inside i)

  local-taylor : {U : R → Set ℓ} (n : ℕ) (f : Domain U → R) (x : R)
    (inside : NeighborhoodK U n x) (d : DK n) →
    f ((x + valueK d) , inside d) ≡ eval (localTaylorCoefficients n f x inside) (valueK d)
  local-taylor n f x inside d = Local.local-taylor n (restriction f x inside) d

  local-taylor-sum : {U : R → Set ℓ} (n : ℕ) (f : Domain U → R) (x : R)
    (inside : NeighborhoodK U n x) (d : DK n) →
    f ((x + valueK d) , inside d) ≡
    monomialSum (localTaylorCoefficients n f x inside) (valueK d) zero
  local-taylor-sum n f x inside d = trans (local-taylor n f x inside d)
    (eval-as-sum (localTaylorCoefficients n f x inside) (valueK d))

  -- When a global function is available the intrinsic local iterates
  -- agree with the derivatives already defined in Section02, at every order.
  local-global-iterate : (n : ℕ) (f : R → R) (x : R) (i : Fin (suc n)) →
    Local.derivative-at-zero i (λ d → f (x + valueK d)) ≡ Calculus.iterate (finToNat i) f x
  local-global-iterate n f x i =
    trans (sym (Local.coefficient-derivative g coefficients expansion i))
      (Descent.coefficient-derivatives f x coefficients expansion i)
    where
    g : DK n → R
    g d = f (x + valueK d)
    coefficients : Vec R (suc n)
    coefficients = Rect.coefficients-all n g
    expansion : (d : DK n) → g d ≡ eval coefficients (valueK d)
    expansion = Rect.reconstruction-all n g

  local-global-coefficients : (n : ℕ) (f : R → R) (x : R) →
    Local.local-coefficients n (λ d → f (x + valueK d)) ≡ Global.taylorCoefficients n f x
  local-global-coefficients n f x = vec-ext (λ i →
    trans (lookup-tabulate
      (λ j → Global.inverseFactorial (finToNat j) *
        Local.derivative-at-zero j (λ d → f (x + valueK d))) i)
      (trans (cong (Global.inverseFactorial (finToNat i) *_) (local-global-iterate n f x i))
        (sym (lookup-tabulate
          (λ j → Global.inverseFactorial (finToNat j) * Calculus.iterate (finToNat j) f x) i))))
