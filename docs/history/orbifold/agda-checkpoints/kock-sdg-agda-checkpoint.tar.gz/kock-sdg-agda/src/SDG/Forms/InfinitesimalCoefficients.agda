{-# OPTIONS --safe --without-K #-}
module SDG.Forms.InfinitesimalCoefficients where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; update)
import SDG.ChapterI.Section05Vector as V5
import SDG.Forms.Basic as Basic

-- The vector-valued Property W_n used in Proposition I.14.4. It is derived
-- by iteration of vector KL, for every finite arity (including zero).
module Coefficients {ℓ : Level} (A : CRing ℓ) (Vmod : RModule A ℓ)
  (KV : V5.VectorInfinitesimals.VectorKL A Vmod) where
  open ModuleLemmas A Vmod
  open Infinitesimals A
  open V5.VectorInfinitesimals.VectorKL KV
  open V5.VectorCalculus A Vmod KV

  product : {n : ℕ} → Vec D n → R
  product = Basic.Cubes.productD A

  VanishesOnFaces : {n : ℕ} → (Vec D n → V) → Set ℓ
  VanishesOnFaces {n} f = (ds : Vec D n) (i : Fin n) → f (update ds i zeroD) ≡ 0v

  head-slope : {n : ℕ} → (Vec D (suc n) → V) → Vec D n → V
  head-slope f ds = slopeV (λ d → f (d ∷ ds))

  coefficient : (n : ℕ) → (Vec D n → V) → V
  coefficient zero f = f []
  coefficient (suc n) f = coefficient n (head-slope f)

  slope-vanishes : (g : D → V) → ((d : D) → g d ≡ 0v) → slopeV g ≡ 0v
  slope-vanishes g p = uniqueSlopeV g 0v (λ d → trans (p d)
    (sym (trans (cong₂ _+v_ (p zeroD) (scalar-zero (value d))) (add-zeroˡ 0v))))

  head-slope-faces : {n : ℕ} (f : Vec D (suc n) → V) →
    VanishesOnFaces f → VanishesOnFaces (head-slope f)
  head-slope-faces f p ds i = slope-vanishes (λ d → f (d ∷ update ds i zeroD))
    (λ d → p (d ∷ ds) (fsuc i))

  head-factor : {n : ℕ} (f : Vec D (suc n) → V) → VanishesOnFaces f →
    (d : D) (ds : Vec D n) → f (d ∷ ds) ≡ value d • head-slope f ds
  head-factor f p d ds = trans (expansionV (λ e → f (e ∷ ds)) d)
    (trans (cong (_+v (value d • head-slope f ds)) (p (d ∷ ds) fzero))
      (add-zeroˡ (value d • head-slope f ds)))

  factor : (n : ℕ) (f : Vec D n → V) → VanishesOnFaces f →
    (ds : Vec D n) → f ds ≡ product ds • coefficient n f
  factor zero f p [] = sym (scalar-one (f []))
  factor (suc n) f p (d ∷ ds) = trans (head-factor f p d ds)
    (trans (cong (value d •_) (factor n (head-slope f) (head-slope-faces f p) ds))
      (sym (scalar-assoc (value d) (product ds) (coefficient n (head-slope f)))))

  cancel-products : (n : ℕ) (a b : V) →
    ((ds : Vec D n) → product ds • a ≡ product ds • b) → a ≡ b
  cancel-products zero a b p = trans (sym (scalar-one a)) (trans (p []) (scalar-one b))
  cancel-products (suc n) a b p = cancel-products n a b (λ ds →
    cancel-infinitesimals (product ds • a) (product ds • b) (λ d →
      trans (sym (scalar-assoc (value d) (product ds) a))
        (trans (p (d ∷ ds)) (scalar-assoc (value d) (product ds) b))))

  factor-unique : (n : ℕ) (f : Vec D n → V) → VanishesOnFaces f → (b : V) →
    ((ds : Vec D n) → f ds ≡ product ds • b) → coefficient n f ≡ b
  factor-unique n f p b q = cancel-products n (coefficient n f) b
    (λ ds → trans (sym (factor n f p ds)) (q ds))

  coefficient-cong : (n : ℕ) (f g : Vec D n → V) →
    ((ds : Vec D n) → f ds ≡ g ds) → coefficient n f ≡ coefficient n g
  coefficient-cong zero f g p = p []
  coefficient-cong (suc n) f g p = coefficient-cong n (head-slope f) (head-slope g)
    (λ ds → slope-cong (λ d → f (d ∷ ds)) (λ d → g (d ∷ ds)) (λ d → p (d ∷ ds)))

  coefficient-add : (n : ℕ) (f g : Vec D n → V) →
    coefficient n (λ ds → f ds +v g ds) ≡ coefficient n f +v coefficient n g
  coefficient-add zero f g = refl
  coefficient-add (suc n) f g = trans
    (coefficient-cong n (head-slope (λ ds → f ds +v g ds))
      (λ ds → head-slope f ds +v head-slope g ds)
      (λ ds → slope-add (λ d → f (d ∷ ds)) (λ d → g (d ∷ ds))))
    (coefficient-add n (head-slope f) (head-slope g))

  coefficient-scale : (n : ℕ) (r : R) (f : Vec D n → V) →
    coefficient n (λ ds → r • f ds) ≡ r • coefficient n f
  coefficient-scale zero r f = refl
  coefficient-scale (suc n) r f = trans
    (coefficient-cong n (head-slope (λ ds → r • f ds))
      (λ ds → r • head-slope f ds) (λ ds → slope-scale r (λ d → f (d ∷ ds))))
    (coefficient-scale n r (head-slope f))

