{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section09 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8

module Lie {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR using (d-path; negateD)
  open S8.Basics A setR
  open S8.Linear A setR IL using (inverse-right; inverse-left)
  open S4.Results A K using (productD; Axis₁; Axis₂; PropertyW)
  module W = PropertyW W

  product-zeroʳ : (d : D) → productD d zeroD ≡ zeroD
  product-zeroʳ d = d-path (*-zeroʳ (value d))

  product-zeroˡ : (d : D) → productD zeroD d ≡ zeroD
  product-zeroˡ d = d-path (*-zeroˡ (value d))

  product-commute : (d e : D) → productD d e ≡ productD e d
  product-commute d e = d-path (*-comm (value d) (value e))

  run-negative-zero : (X : VectorField M) (m : M) → run X m (negateD zeroD) ≡ m
  run-negative-zero X m = trans (cong (run X m) (d-path neg-zero)) (run-zero X m)

  -- The group commutator uses actual infinitesimal transformations.
  commutator : VectorField M → VectorField M → M → D → D → M
  commutator X Y m d e =
    run Y (run X (run Y (run X m d) e) (negateD d)) (negateD e)

  commutator-zeroʳ : (X Y : VectorField M) (m : M) (d : D) →
    commutator X Y m d zeroD ≡ m
  commutator-zeroʳ X Y m d =
    trans (run-negative-zero Y (run X (run Y (run X m d) zeroD) (negateD d)))
      (trans (cong (λ q → run X q (negateD d)) (run-zero Y (run X m d)))
        (inverse-right X m d))

  commutator-zeroˡ : (X Y : VectorField M) (m : M) (e : D) →
    commutator X Y m zeroD e ≡ m
  commutator-zeroˡ X Y m e =
    trans
      (cong (λ q → run Y (run X (run Y q e) (negateD zeroD)) (negateD e))
        (run-zero X m))
      (trans (cong (λ q → run Y q (negateD e)) (run-negative-zero X (run Y m e)))
        (inverse-right Y m e))

  axis₁ : (X Y : VectorField M) (m : M) → Axis₁ (commutator X Y m)
  axis₁ X Y m d = trans (commutator-zeroʳ X Y m d) (sym (commutator-zeroʳ X Y m zeroD))

  axis₂ : (X Y : VectorField M) (m : M) → Axis₂ (commutator X Y m)
  axis₂ X Y m e = trans (commutator-zeroˡ X Y m e) (sym (commutator-zeroʳ X Y m zeroD))

  bracket : VectorField M → VectorField M → VectorField M
  run (bracket X Y) m = W.lift (commutator X Y m) (axis₁ X Y m) (axis₂ X Y m)
  run-zero (bracket X Y) m =
    trans
      (cong (W.lift (commutator X Y m) (axis₁ X Y m) (axis₂ X Y m))
        (sym (product-zeroʳ zeroD)))
      (trans (sym (W.factor (commutator X Y m) (axis₁ X Y m) (axis₂ X Y m) zeroD zeroD))
        (commutator-zeroʳ X Y m zeroD))

  bracket-characterization : (X Y : VectorField M) (m : M) (d e : D) →
    run (bracket X Y) m (productD d e) ≡ commutator X Y m d e
  bracket-characterization X Y m d e =
    sym (W.factor (commutator X Y m) (axis₁ X Y m) (axis₂ X Y m) d e)

  -- Property W detects arbitrary M-valued maps on D from universal products.
  detect : (t u : D → M) →
    ((d e : D) → t (productD d e) ≡ u (productD d e)) →
    (z : D) → t z ≡ u z
  detect t u p z =
    trans (W.unique f left right t (λ d e → refl) z)
      (sym (W.unique f left right u p z))
    where
    f : D → D → M
    f d e = t (productD d e)
    left : Axis₁ f
    left d = cong t (trans (product-zeroʳ d) (sym (product-zeroʳ zeroD)))
    right : Axis₂ f
    right e = cong t (trans (product-zeroˡ e) (sym (product-zeroʳ zeroD)))

  bracket-unique : (X Y Z : VectorField M) →
    ((m : M) (d e : D) → run Z m (productD d e) ≡ commutator X Y m d e) →
    (m : M) (z : D) → run Z m z ≡ run (bracket X Y) m z
  bracket-unique X Y Z p m = detect (run Z m) (run (bracket X Y) m)
    (λ d e → trans (p m d e) (sym (bracket-characterization X Y m d e)))

  -- Inverse identity for the two opposite commutators, proved by four
  -- cancellations of the actual transformations; no abstract Lie law assumed.
  opposite-commutators : (X Y : VectorField M) (m : M) (d e : D) →
    commutator Y X (commutator X Y m d e) e d ≡ m
  opposite-commutators X Y m d e =
    trans
      (cong (λ q → run X (run Y (run X q d) (negateD e)) (negateD d))
        (inverse-left Y (run X (run Y (run X m d) e) (negateD d)) e))
      (trans
        (cong (λ q → run X (run Y q (negateD e)) (negateD d))
          (inverse-left X (run Y (run X m d) e) d))
        (trans (cong (λ q → run X q (negateD d)) (inverse-right Y (run X m d) e))
          (inverse-right X m d)))

  -- Proposition I.9.1, pointwise equality of the two vector fields.
  bracket-antisymmetric : (X Y : VectorField M) (m : M) (z : D) →
    run (bracket X Y) m z ≡ run (negative-field (bracket Y X)) m z
  bracket-antisymmetric X Y m =
    detect (run (bracket X Y) m) (run (negative-field (bracket Y X)) m)
      (λ d e → trans (bracket-characterization X Y m d e)
        (trans (sym (inverse-right (bracket Y X) (commutator X Y m d e) (productD d e)))
          (cong (λ q → run (bracket Y X) q (negateD (productD d e)))
            (trans
              (cong (run (bracket Y X) (commutator X Y m d e)) (product-commute d e))
              (trans (bracket-characterization Y X (commutator X Y m d e) e d)
                (opposite-commutators X Y m d e))))))

  -- Exercise I.9.1: swapping the infinitesimal parameters has no effect.
  commutator-parameters : (X Y : VectorField M) (m : M) (d e : D) →
    commutator X Y m d e ≡ commutator X Y m e d
  commutator-parameters X Y m d e =
    trans (sym (bracket-characterization X Y m d e))
      (trans (cong (run (bracket X Y) m) (product-commute d e))
        (bracket-characterization X Y m e d))

  same-parameter-commutator : (X Y : VectorField M) (m : M) (d : D) →
    commutator X Y m d d ≡ m
  same-parameter-commutator X Y m d =
    trans (sym (bracket-characterization X Y m d d))
      (trans (cong (run (bracket X Y) m) (d-path (square-zero d))) (run-zero (bracket X Y) m))

  commutator-zero-to-commute : (X Y : VectorField M) (m : M) (d e : D) →
    commutator X Y m d e ≡ m →
    run Y (run X m d) e ≡ run X (run Y m e) d
  commutator-zero-to-commute X Y m d e p =
    trans
      (sym
        (trans (cong (λ q → run X q d)
          (inverse-left Y (run X (run Y (run X m d) e) (negateD d)) e))
          (inverse-left X (run Y (run X m d) e) d)))
      (cong (λ q → run X (run Y q e) d) p)

  commute-to-commutator-zero : (X Y : VectorField M) (m : M) (d e : D) →
    run Y (run X m d) e ≡ run X (run Y m e) d →
    commutator X Y m d e ≡ m
  commute-to-commutator-zero X Y m d e p =
    trans (cong (λ q → run Y (run X q (negateD d)) (negateD e)) p)
      (trans (cong (λ q → run Y q (negateD e)) (inverse-right X (run Y m e) d))
        (inverse-right Y m e))

  same-parameter-commute : (X Y : VectorField M) (m : M) (d : D) →
    run Y (run X m d) d ≡ run X (run Y m d) d
  same-parameter-commute X Y m d =
    commutator-zero-to-commute X Y m d d (same-parameter-commutator X Y m d)

  BracketZero : VectorField M → VectorField M → Set ℓ
  BracketZero X Y = (m : M) (z : D) → run (bracket X Y) m z ≡ m

  TransformationsCommute : VectorField M → VectorField M → Set ℓ
  TransformationsCommute X Y = (m : M) (d e : D) →
    run Y (run X m d) e ≡ run X (run Y m e) d

  -- Exercise I.9.5 (i) iff (ii); condition (iii) is the reversed equation
  -- of the following transformations, exposed as actual Morphism records.
  zero-implies-commute : (X Y : VectorField M) → BracketZero X Y → TransformationsCommute X Y
  zero-implies-commute X Y p m d e =
    commutator-zero-to-commute X Y m d e
      (trans (sym (bracket-characterization X Y m d e)) (p m (productD d e)))

  commute-implies-zero : (X Y : VectorField M) → TransformationsCommute X Y → BracketZero X Y
  commute-implies-zero X Y p m = detect (run (bracket X Y) m) (λ _ → m)
    (λ d e → trans (bracket-characterization X Y m d e)
      (commute-to-commutator-zero X Y m d e (p m d e)))

  commuting-endomorphism : (X Y : VectorField M) → TransformationsCommute X Y →
    (d : D) → Morphism Y Y
  Morphism.map (commuting-endomorphism X Y p d) m = run X m d
  Morphism.commutes (commuting-endomorphism X Y p d) m e = sym (p m d e)

  endomorphisms-imply-commute : (X Y : VectorField M) →
    ((m : M) (d e : D) → run X (run Y m e) d ≡ run Y (run X m d) e) →
    TransformationsCommute X Y
  endomorphisms-imply-commute X Y p m d e = sym (p m d e)

module Naturality {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M N : Set ℓ}
  (ILM : S6.Linear.InfinitesimallyLinear A M) (WM : S4.Results.PropertyW A K M)
  (ILN : S6.Linear.InfinitesimallyLinear A N) (WN : S4.Results.PropertyW A K N) where
  open Infinitesimals A
  open S7.Basics A setR using (negateD)
  open S8.Basics A setR
  module LM = Lie A K setR ILM WM
  module LN = Lie A K setR ILN WN

  commutator-natural : (h : M → N)
    (X Y : VectorField M) (X′ Y′ : VectorField N) →
    ((m : M) (d : D) → h (run X m d) ≡ run X′ (h m) d) →
    ((m : M) (d : D) → h (run Y m d) ≡ run Y′ (h m) d) →
    (m : M) (d e : D) →
    h (LM.commutator X Y m d e) ≡ LN.commutator X′ Y′ (h m) d e
  commutator-natural h X Y X′ Y′ px py m d e =
    trans (py (run X (run Y (run X m d) e) (negateD d)) (negateD e))
      (cong (λ q → run Y′ q (negateD e))
        (trans (px (run Y (run X m d) e) (negateD d))
          (cong (λ q → run X′ q (negateD d))
            (trans (py (run X m d) e)
              (cong (λ q → run Y′ q e) (px m d))))))

  bracket-natural : (h : M → N)
    (X Y : VectorField M) (X′ Y′ : VectorField N) →
    ((m : M) (d : D) → h (run X m d) ≡ run X′ (h m) d) →
    ((m : M) (d : D) → h (run Y m d) ≡ run Y′ (h m) d) →
    (m : M) (z : D) →
    h (run (LM.bracket X Y) m z) ≡ run (LN.bracket X′ Y′) (h m) z
  bracket-natural h X Y X′ Y′ px py m =
    LN.detect (λ z → h (run (LM.bracket X Y) m z)) (run (LN.bracket X′ Y′) (h m))
      (λ d e → trans (cong h (LM.bracket-characterization X Y m d e))
        (trans (commutator-natural h X Y X′ Y′ px py m d e)
          (sym (LN.bracket-characterization X′ Y′ (h m) d e))))


