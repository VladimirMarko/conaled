{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.ModuleExtra where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module

module Extra {a v : Level} (A : CRing a) (Vmod : RModule A v) where
  open ModuleLemmas A Vmod public

  infixl 6 _-v_
  _-v_ : V → V → V
  x -v y = x +v (-v y)

  v-neg-unique : (x y : V) → x +v y ≡ 0v → y ≡ (-v x)
  v-neg-unique x y p = add-cancelˡ x (trans p (sym (add-inverseʳ x)))

  v-neg-zero : (-v 0v) ≡ 0v
  v-neg-zero = sym (v-neg-unique 0v 0v (add-zeroˡ 0v))

  v-neg-involutive : (x : V) → (-v (-v x)) ≡ x
  v-neg-involutive x = sym (v-neg-unique (-v x) x (add-inverseˡ x))

  v-neg-add : (x y : V) → (-v (x +v y)) ≡ (-v x) +v (-v y)
  v-neg-add x y = sym (v-neg-unique (x +v y) ((-v x) +v (-v y))
    (trans (add-shuffle x y (-v x) (-v y))
      (trans (cong₂ _+v_ (add-inverseʳ x) (add-inverseʳ y)) (add-zeroˡ 0v))))

  scalar-neg : (r : R) (x : V) → r • (-v x) ≡ (-v (r • x))
  scalar-neg r x = v-neg-unique (r • x) (r • (-v x))
    (trans (sym (scalar-distrib r x (-v x)))
      (trans (cong (r •_) (add-inverseʳ x)) (scalar-zero r)))

  neg-scalar : (r : R) (x : V) → (- r) • x ≡ (-v (r • x))
  neg-scalar r x = v-neg-unique (r • x) ((- r) • x)
    (trans (sym (scalar-add r (- r) x))
      (trans (cong (_• x) (+-inverseʳ r)) (zero-scalar x)))

  scalar-sub : (r : R) (x y : V) → r • (x -v y) ≡ (r • x) -v (r • y)
  scalar-sub r x y =
    trans (scalar-distrib r x (-v y)) (cong ((r • x) +v_) (scalar-neg r y))

  sub-self : (x : V) → x -v x ≡ 0v
  sub-self = add-inverseʳ

  add-sub-cancel : (x y : V) → (x +v y) -v y ≡ x
  add-sub-cancel x y =
    trans (add-assoc x y (-v y)) (trans (cong (x +v_) (add-inverseʳ y)) (add-zeroʳ x))

  sub-add-cancel : (x y : V) → (x -v y) +v y ≡ x
  sub-add-cancel x y =
    trans (add-assoc x (-v y) y) (trans (cong (x +v_) (add-inverseˡ y)) (add-zeroʳ x))

  sub-zero-equal : (x y : V) → x -v y ≡ 0v → x ≡ y
  sub-zero-equal x y p = trans (sym (sub-add-cancel x y))
    (trans (cong (_+v y) p) (add-zeroˡ y))

  sub-add-pairs : (a b c d : V) →
    (a +v b) -v (c +v d) ≡ (a -v c) +v (b -v d)
  sub-add-pairs a b c d =
    trans (cong ((a +v b) +v_) (v-neg-add c d)) (add-shuffle a b (-v c) (-v d))

  sub-common-right : (a b c : V) → (a +v c) -v (b +v c) ≡ a -v b
  sub-common-right a b c = trans (sub-add-pairs a c b c)
    (trans (cong ((a -v b) +v_) (sub-self c)) (add-zeroʳ (a -v b)))

  sub-common-left : (a b c : V) → (a +v b) -v (a +v c) ≡ b -v c
  sub-common-left a b c = trans (sub-add-pairs a b a c)
    (trans (cong (_+v (b -v c)) (sub-self a)) (add-zeroˡ (b -v c)))

  added-sub-base : (a b : V) → (a +v b) -v a ≡ b
  added-sub-base a b = trans (cong (λ z → z -v a) (add-comm a b)) (add-sub-cancel b a)

  base-sub-added : (a b : V) → a -v (a +v b) ≡ (-v b)
  base-sub-added a b = trans (cong (λ z → z -v (a +v b)) (sym (add-zeroʳ a)))
    (trans (sub-common-left a 0v b) (add-zeroˡ (-v b)))

  negative-difference : (a b : V) → (-v a) -v (-v b) ≡ b -v a
  negative-difference a b =
    trans (cong ((-v a) +v_) (v-neg-involutive b)) (add-comm (-v a) b)

  sub-from-common : (w a b c d : V) →
    ((w +v a) +v b) -v ((w +v c) +v d) ≡ (a -v d) +v (b -v c)
  sub-from-common w a b c d =
    trans (cong₂ _-v_ (add-assoc w a b) (add-assoc w c d))
      (trans (sub-common-left w (a +v b) (c +v d))
        (trans (cong (λ z → (a +v b) -v z) (add-comm c d)) (sub-add-pairs a b d c)))

  -- An affine scalar times an affine vector on a square-zero direction.
  affine-action : (d a b : R) (v w : V) → d * d ≡ 0r →
    (a + d * b) • (v +v d • w) ≡
      a • v +v d • (b • v +v a • w)
  affine-action d a b v w dd =
    begin
      (a + d * b) • (v +v d • w)
    ≡⟨ scalar-add a (d * b) (v +v d • w) ⟩
      a • (v +v d • w) +v (d * b) • (v +v d • w)
    ≡⟨ cong₂ _+v_ (scalar-distrib a v (d • w)) (scalar-distrib (d * b) v (d • w)) ⟩
      (a • v +v a • (d • w)) +v ((d * b) • v +v (d * b) • (d • w))
    ≡⟨ cong₂ _+v_ (cong ((a • v) +v_) (scalar-commute a d w))
          (cong₂ _+v_ (scalar-assoc d b v)
            (trans (scalar-assoc d b (d • w))
              (trans (cong (d •_) (scalar-commute b d w)) (scalar-square-zero d dd (b • w))))) ⟩
      (a • v +v d • (a • w)) +v (d • (b • v) +v 0v)
    ≡⟨ cong ((a • v +v d • (a • w)) +v_) (add-zeroʳ (d • (b • v))) ⟩
      (a • v +v d • (a • w)) +v d • (b • v)
    ≡⟨ add-assoc (a • v) (d • (a • w)) (d • (b • v)) ⟩
      a • v +v (d • (a • w) +v d • (b • v))
    ≡⟨ cong ((a • v) +v_)
          (trans (add-comm (d • (a • w)) (d • (b • v)))
            (sym (scalar-distrib d (b • v) (a • w)))) ⟩
      a • v +v d • (b • v +v a • w) ∎

