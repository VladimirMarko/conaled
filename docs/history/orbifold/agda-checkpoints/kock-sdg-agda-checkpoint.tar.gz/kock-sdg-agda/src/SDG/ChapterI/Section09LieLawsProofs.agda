{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section09LieLawsProofs where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.Endomorphisms using (LieAlgebra)
open import SDG.Algebra.Automorphisms using (forward)
open import SDG.Axiom
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7
import SDG.ChapterI.Section08 as S8
import SDG.ChapterI.Section08Module as S8M
import SDG.ChapterI.Section08FormalFlows as S8F
import SDG.ChapterI.Section09 as S9
import SDG.ChapterI.Section09LieLaws as Foundation

module Laws {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) (IL : S6.Linear.InfinitesimallyLinear A M)
  (W : S4.Results.PropertyW A K M) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR using (d-path)
  open S8.Basics A setR hiding (transform; transform-zero)
  open S8M.Fields A setR ext0 ext M setM IL
  open S4.Results A K using (productD)
  open S9.Lie A K setR IL W using (bracket-antisymmetric)
  module F = Foundation.Geometry A K setR ext0 ext M setM IL W
  open F using
    (bracket; bracket-agrees; transform; transform-zero; transform-add; transform-scale; group-bracket;
     commutator-vanishes; fields-detected; triple-detect; product-rotate;
     overlap-left; overlap-right)
  module G = F.G
  module GI = F.GI
  module GH = F.GH

  abstract
    bracket-addˡ : (X Y Z : VectorField M) →
      bracket (field-add X Y) Z ≡ field-add (bracket X Z) (bracket Y Z)
    bracket-addˡ X Y Z = fields-detected (bracket (field-add X Y) Z)
      (field-add (bracket X Z) (bracket Y Z)) (λ d e →
        trans (sym (group-bracket (field-add X Y) Z d e))
          (trans (cong (λ p → GI.commutator p (transform Z e)) (transform-add X Y d))
            (trans (GI.commutator-productˡ (transform X d) (transform Y d) (transform Z e))
              (trans (cong (λ p → G._·_ p (GI.commutator (transform Y d) (transform Z e)))
                (GI.conjugate-trivial (GI.commutator (transform X d) (transform Z e)) (transform Y d)
                  (trans (cong (λ p → GI.commutator p (transform Y d)) (group-bracket X Z d e))
                    (commutator-vanishes (bracket X Z) Y (productD d e) d (overlap-left d e)))))
                (trans (cong₂ G._·_ (group-bracket X Z d e) (group-bracket Y Z d e))
                  (sym (transform-add (bracket X Z) (bracket Y Z) (productD d e))))))))

    bracket-addʳ : (X Y Z : VectorField M) →
      bracket X (field-add Y Z) ≡ field-add (bracket X Y) (bracket X Z)
    bracket-addʳ X Y Z = fields-detected (bracket X (field-add Y Z))
      (field-add (bracket X Y) (bracket X Z)) (λ d e →
        trans (sym (group-bracket X (field-add Y Z) d e))
          (trans (cong (GI.commutator (transform X d)) (transform-add Y Z e))
            (trans (GI.commutator-productʳ (transform X d) (transform Y e) (transform Z e))
              (trans (cong (G._·_ (GI.commutator (transform X d) (transform Z e)))
                (GI.conjugate-trivial (GI.commutator (transform X d) (transform Y e)) (transform Z e)
                  (trans (cong (λ p → GI.commutator p (transform Z e)) (group-bracket X Y d e))
                    (commutator-vanishes (bracket X Y) Z (productD d e) e (overlap-right d e)))))
                (trans (cong₂ G._·_ (group-bracket X Z d e) (group-bracket X Y d e))
                  (trans (sym (transform-add (bracket X Z) (bracket X Y) (productD d e)))
                    (cong (λ U → transform U (productD d e)) (field-add-comm (bracket X Z) (bracket X Y)))))))))

    bracket-scaleˡ : (r : R) (X Y : VectorField M) →
      bracket (scale-field (λ _ → r) X) Y ≡ scale-field (λ _ → r) (bracket X Y)
    bracket-scaleˡ r X Y = fields-detected (bracket (scale-field (λ _ → r) X) Y)
      (scale-field (λ _ → r) (bracket X Y)) (λ d e →
        trans (sym (group-bracket (scale-field (λ _ → r) X) Y d e))
          (trans (cong (λ p → GI.commutator p (transform Y e)) (transform-scale r X d))
            (trans (group-bracket X Y (scaleD d r) e)
              (trans (cong (transform (bracket X Y)) (d-path
                (trans (*-assoc (value d) r (value e))
                  (trans (cong (value d *_) (*-comm r (value e)))
                    (sym (*-assoc (value d) (value e) r))))))
                (sym (transform-scale r (bracket X Y) (productD d e)))))))

    bracket-scaleʳ : (r : R) (X Y : VectorField M) →
      bracket X (scale-field (λ _ → r) Y) ≡ scale-field (λ _ → r) (bracket X Y)
    bracket-scaleʳ r X Y = fields-detected (bracket X (scale-field (λ _ → r) Y))
      (scale-field (λ _ → r) (bracket X Y)) (λ d e →
        trans (sym (group-bracket X (scale-field (λ _ → r) Y) d e))
          (trans (cong (GI.commutator (transform X d)) (transform-scale r Y e))
            (trans (group-bracket X Y d (scaleD e r))
              (trans (cong (transform (bracket X Y)) (d-path (sym (*-assoc (value d) (value e) r))))
                (sym (transform-scale r (bracket X Y) (productD d e)))))))

    nested-commutator : (X Y Z : VectorField M) (d e f : D) →
      GI.commutator (transform X d) (GI.commutator (transform Y e) (transform Z f)) ≡
      transform (bracket X (bracket Y Z)) (productD d (productD e f))
    nested-commutator X Y Z d e f =
      trans (cong (GI.commutator (transform X d)) (group-bracket Y Z e f))
        (group-bracket X (bracket Y Z) d (productD e f))

    hall-correction : (X Y Z : VectorField M) (d e f : D) →
      GI.commutator (GI.conjugate (transform X d) (transform Y e))
        (GI.commutator (transform Y e) (transform Z f)) ≡
      GI.commutator (transform X d) (GI.commutator (transform Y e) (transform Z f))
    hall-correction X Y Z d e f = GI.conjugated-commutator
      (transform X d) (transform Y e) (GI.commutator (transform Y e) (transform Z f))
      first-correction second-correction
      where
      first-correction : GI.commutator (GI.commutator (transform X d) (transform Y e))
        (GI.commutator (transform Y e) (transform Z f)) ≡ G.unit
      first-correction =
        trans (cong₂ GI.commutator (group-bracket X Y d e) (group-bracket Y Z e f))
          (commutator-vanishes (bracket X Y) (bracket Y Z) (productD d e) (productD e f)
            (trans (cong (_* (value e * value f)) (*-comm (value d) (value e)))
              (square-zero-product (value e) (value d) (value f) (square-zero e))))

      second-correction :
        GI.commutator (GI.commutator (transform X d) (GI.commutator (transform Y e) (transform Z f)))
          (GI.commutator (transform X d) (transform Y e)) ≡ G.unit
      second-correction =
        trans (cong₂ GI.commutator (nested-commutator X Y Z d e f) (group-bracket X Y d e))
          (commutator-vanishes (bracket X (bracket Y Z)) (bracket X Y)
            (productD d (productD e f)) (productD d e)
            (square-zero-product (value d) (value e * value f) (value e) (square-zero d)))

    geometric-hall : (X Y Z : VectorField M) (d e f : D) →
      G._·_ (G._·_
        (GI.commutator (transform X d) (GI.commutator (transform Y e) (transform Z f)))
        (GI.commutator (transform Y e) (GI.commutator (transform Z f) (transform X d))))
        (GI.commutator (transform Z f) (GI.commutator (transform X d) (transform Y e))) ≡ G.unit
    geometric-hall X Y Z d e f =
      trans (sym (cong₂ G._·_ (cong₂ G._·_
        (hall-correction X Y Z d e f) (hall-correction Y Z X e f d))
        (hall-correction Z X Y f d e)))
        (GI.hall-identity (transform X d) (transform Y e) (transform Z f))

    jacobi-transform : (X Y Z : VectorField M) (d e f : D) →
      transform
        (field-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
          (bracket Z (bracket X Y))) (productD d (productD e f)) ≡ G.unit
    jacobi-transform X Y Z d e f =
      trans (transform-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
        (bracket Z (bracket X Y)) p)
        (trans (cong (λ q → G._·_ q (transform (bracket Z (bracket X Y)) p))
          (transform-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)) p))
          (trans (sym (cong₂ G._·_ (cong₂ G._·_ first-term second-term) third-term))
            (geometric-hall X Y Z d e f)))
      where
      p : D
      p = productD d (productD e f)
      first-term : GI.commutator (transform X d) (GI.commutator (transform Y e) (transform Z f)) ≡
        transform (bracket X (bracket Y Z)) p
      first-term = nested-commutator X Y Z d e f
      second-term : GI.commutator (transform Y e) (GI.commutator (transform Z f) (transform X d)) ≡
        transform (bracket Y (bracket Z X)) p
      second-term = trans (nested-commutator Y Z X e f d)
        (cong (transform (bracket Y (bracket Z X))) (sym (product-rotate d e f)))
      third-term : GI.commutator (transform Z f) (GI.commutator (transform X d) (transform Y e)) ≡
        transform (bracket Z (bracket X Y)) p
      third-term = trans (nested-commutator Z X Y f d e)
        (cong (transform (bracket Z (bracket X Y)))
          (sym (trans (product-rotate d e f) (product-rotate e f d))))

    -- The repeated use of W cancels three universally quantified
    -- infinitesimal factors. No coordinate functions on M enter this proof.
    jacobi : (X Y Z : VectorField M) →
      field-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
        (bracket Z (bracket X Y)) ≡ zero-field
    jacobi X Y Z = field-ext ext setM (λ m →
      triple-detect
        (run (field-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
          (bracket Z (bracket X Y))) m)
        (λ _ → m)
        (λ d e f → trans
          (sym (F.forward-transform
            (field-add (field-add (bracket X (bracket Y Z)) (bracket Y (bracket Z X)))
              (bracket Z (bracket X Y))) (productD d (productD e f)) m))
          (trans (cong (λ q → forward q m) (jacobi-transform X Y Z d e f))
            (F.Autos.forward-unit m))))

    skew : (X Y : VectorField M) → field-add (bracket X Y) (bracket Y X) ≡ zero-field
    skew X Y = trans (cong (λ U → field-add U (bracket Y X))
      (trans (bracket-agrees X Y)
        (trans (field-ext ext setM (bracket-antisymmetric X Y))
          (trans (cong negative-field (sym (bracket-agrees Y X)))
            (negative-field-is-module-negation (bracket Y X)))))) (field-add-inverse (bracket Y X))

  scalarFieldsModule : RModule A ℓ
  scalarFieldsModule = record
    { V = VectorField M; 0v = zero-field; _+v_ = field-add; -v_ = field-negate
    ; _•_ = λ r → scale-field (λ _ → r)
    ; add-assoc = field-add-assoc; add-comm = field-add-comm
    ; add-zeroˡ = field-add-zero; add-inverseˡ = field-add-inverse
    ; scalar-one = field-scale-one
    ; scalar-assoc = λ r s → field-scale-assoc (λ _ → r) (λ _ → s)
    ; scalar-add = λ r s → field-scale-add (λ _ → r) (λ _ → s)
    ; scalar-distrib = λ r → field-scale-distrib (λ _ → r)
    }

  -- The book works over a rational algebra. Only invertibility of 2 is
  -- required to add the alternating law to skew-symmetry and Jacobi here.
  geometricLieAlgebra : (half : R) → (1r + 1r) * half ≡ 1r → LieAlgebra A scalarFieldsModule
  geometricLieAlgebra half half-law = record
    { bracket = bracket
    ; bracket-addˡ = bracket-addˡ; bracket-addʳ = bracket-addʳ
    ; bracket-scaleˡ = bracket-scaleˡ; bracket-scaleʳ = bracket-scaleʳ
    ; alternating = λ X → trans (bracket-agrees X X) (field-ext ext setM
        (S8F.SelfCommutation.self-bracket-zero A K setR IL W half half-law X))
    ; skew = skew; jacobi = jacobi
    }
