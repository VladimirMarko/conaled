{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.SquareZero where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras

-- The square-zero extension R ⊕ V of an actual R-module. This supplies
-- the finite-dimensional Weil algebra for D(n) when V = R^n.
module Extension {ℓ : Level} (A : CRing ℓ) (M : RModule A ℓ) where
  open ModuleLemmas A M

  Carrier : Set ℓ
  Carrier = R × V

  add : Carrier → Carrier → Carrier
  add (a , u) (b , v) = (a + b) , (u +v v)

  multiply : Carrier → Carrier → Carrier
  multiply (a , u) (b , v) = (a * b) , ((a • v) +v (b • u))

  negate : Carrier → Carrier
  negate (a , u) = (- a) , (-v u)

  zeroC oneC : Carrier
  zeroC = 0r , 0v
  oneC = 1r , 0v

  multiplication-assoc : (p q r : Carrier) → multiply (multiply p q) r ≡ multiply p (multiply q r)
  multiplication-assoc (a , u) (b , v) (c , w) = cong₂ _,_ (*-assoc a b c)
    (begin
      ((a * b) • w) +v (c • ((a • v) +v (b • u)))
    ≡⟨ cong₂ _+v_ (scalar-assoc a b w) (scalar-distrib c (a • v) (b • u)) ⟩
      (a • (b • w)) +v ((c • (a • v)) +v (c • (b • u)))
    ≡⟨ cong ((a • (b • w)) +v_)
          (cong₂ _+v_ (scalar-commute c a v)
            (trans (scalar-commute c b u) (sym (scalar-assoc b c u)))) ⟩
      (a • (b • w)) +v ((a • (c • v)) +v ((b * c) • u))
    ≡⟨ sym (add-assoc (a • (b • w)) (a • (c • v)) ((b * c) • u)) ⟩
      ((a • (b • w)) +v (a • (c • v))) +v ((b * c) • u)
    ≡⟨ cong (_+v ((b * c) • u)) (sym (scalar-distrib a (b • w) (c • v))) ⟩
      (a • ((b • w) +v (c • v))) +v ((b * c) • u) ∎)

  multiplication-comm : (p q : Carrier) → multiply p q ≡ multiply q p
  multiplication-comm (a , u) (b , v) = cong₂ _,_ (*-comm a b) (add-comm (a • v) (b • u))

  multiplication-one : (p : Carrier) → multiply oneC p ≡ p
  multiplication-one (a , u) = cong₂ _,_ (*-identityˡ a)
    (trans (cong₂ _+v_ (scalar-one u) (scalar-zero a)) (add-zeroʳ u))

  multiplication-distrib : (p q r : Carrier) → multiply p (add q r) ≡ add (multiply p q) (multiply p r)
  multiplication-distrib (a , u) (b , v) (c , w) = cong₂ _,_ (distribˡ a b c)
    (trans (cong₂ _+v_ (scalar-distrib a v w) (scalar-add b c u))
      (add-shuffle (a • v) (a • w) (b • u) (c • u)))

  square-zero-ring : CRing ℓ
  square-zero-ring = record
    { R = Carrier; 0r = zeroC; 1r = oneC; _+_ = add; _*_ = multiply; -_ = negate
    ; +-assoc = λ p q r → cong₂ _,_ (+-assoc (fst p) (fst q) (fst r)) (add-assoc (snd p) (snd q) (snd r))
    ; +-comm = λ p q → cong₂ _,_ (+-comm (fst p) (fst q)) (add-comm (snd p) (snd q))
    ; +-identityˡ = λ p → cong₂ _,_ (+-identityˡ (fst p)) (add-zeroˡ (snd p))
    ; +-identityʳ = λ p → cong₂ _,_ (+-identityʳ (fst p)) (add-zeroʳ (snd p))
    ; +-inverseˡ = λ p → cong₂ _,_ (+-inverseˡ (fst p)) (add-inverseˡ (snd p))
    ; +-inverseʳ = λ p → cong₂ _,_ (+-inverseʳ (fst p)) (add-inverseʳ (snd p))
    ; *-assoc = multiplication-assoc; *-comm = multiplication-comm
    ; *-identityˡ = multiplication-one
    ; *-identityʳ = λ p → trans (multiplication-comm p oneC) (multiplication-one p)
    ; distribˡ = multiplication-distrib
    ; distribʳ = λ p q r → trans (multiplication-comm (add p q) r)
        (trans (multiplication-distrib r p q)
          (cong₂ add (multiplication-comm r p) (multiplication-comm r q))) }

  scalar : R → Carrier
  scalar r = r , 0v

  scalar-hom : RingHom A square-zero-ring
  scalar-hom = record
    { hom = scalar; pres-0 = refl; pres-1 = refl
    ; pres-+ = λ r s → cong ((r + s) ,_) (sym (add-zeroˡ 0v))
    ; pres-* = λ r s → cong ((r * s) ,_)
        (sym (trans (cong₂ _+v_ (scalar-zero r) (scalar-zero s)) (add-zeroˡ 0v)))
    ; pres-neg = λ r → cong ((- r) ,_) (sym zero-neg) }
    where
    zero-neg : (-v 0v) ≡ 0v
    zero-neg = trans (sym (add-zeroʳ (-v 0v))) (add-inverseˡ 0v)

  square-zero-algebra : RAlgebra A ℓ
  square-zero-algebra = algebra square-zero-ring scalar-hom

  ideal : V → Carrier
  ideal v = 0r , v

  ideal-square-zero : (u v : V) → multiply (ideal u) (ideal v) ≡ zeroC
  ideal-square-zero u v = cong₂ _,_ (*-zeroˡ 0r)
    (trans (cong₂ _+v_ (zero-scalar v) (zero-scalar u)) (add-zeroˡ 0v))

  scalar-ideal : (r : R) (v : V) → multiply (scalar r) (ideal v) ≡ ideal (r • v)
  scalar-ideal r v = cong₂ _,_ (*-zeroʳ r)
    (trans (cong ((r • v) +v_) (zero-scalar 0v)) (add-zeroʳ (r • v)))

  normal-form : (p : Carrier) → add (scalar (fst p)) (ideal (snd p)) ≡ p
  normal-form p = cong₂ _,_ (+-identityʳ (fst p)) (add-zeroˡ (snd p))

  augmentation : AlgHom square-zero-algebra (scalarAlgebra A)
  RingHom.hom (ringHom augmentation) = fst
  RingHom.pres-0 (ringHom augmentation) = refl
  RingHom.pres-1 (ringHom augmentation) = refl
  RingHom.pres-+ (ringHom augmentation) p q = refl
  RingHom.pres-* (ringHom augmentation) p q = refl
  RingHom.pres-neg (ringHom augmentation) p = refl
  commutes augmentation r = refl
