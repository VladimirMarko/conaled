{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16Weil where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
import SDG.Algebra.StructureConstants as SC
import SDG.Algebra.Weil as W
open import SDG.Finite using (Fin; fzero)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section12 as S12
import SDG.ChapterI.Section16 as S16

module WeilTheory {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (extk : FunExt lzero κ)
  (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ) (setR : isSet (CRing.R A)) where
  open PowerLemmas A
  open Presentations k
  open S12.Comprehensive k A base ext ext0 setR
  module KW = W.Weils k extk
  module AW = W.Weils A ext0

  module For (n : ℕ) (Weil : KW.WeilAlgebra n) where
    module Data = S16.FiniteFreeData k A base ext ext0 setR n (KW.table Weil)
    module C = Data.C
    module Ideal = W.Ideals A ext0 n (SC.Change.change-table k A base (KW.table Weil))

    scalar-extension : AW.WeilAlgebra n
    scalar-extension = W.change-weil k A extk ext0 base Weil

    augmentation : AlgHom Data.tensor-algebra (scalarAlgebra A)
    augmentation = Ideal.Augmentation.augmentation (AW.augmentation-constants scalar-extension)

    Infinitesimal : Set ℓ
    Infinitesimal = Affine Data.P.presentation

    -- Spec of the augmentation, constructed directly from the generic
    -- basis solution. Its i-th coordinate is delta(i,0).
    base-point : Infinitesimal
    coordinates base-point i = algMap augmentation (coordinates Data.generic-basis i)
    satisfies base-point j = trans
      (sym (evaluate-hom C.coordinate-ring A (coefficient-map Data.tensor-algebra) (RingHom.hom base)
        (ringHom augmentation) (λ r → commutes augmentation (RingHom.hom base r))
        (equations Data.P.presentation j) (coordinates Data.generic-basis)))
      (trans (cong (algMap augmentation) (satisfies Data.generic-basis j)) (RingHom.pres-0 (ringHom augmentation)))

    alpha : C.Carrier → Infinitesimal → R
    alpha c x = Data.scalar-evaluation x c

    Functions : RAlgebra A ℓ
    Functions = functionAlgebra A Infinitesimal ext

    alpha-hom : AlgHom Data.tensor-algebra Functions
    RingHom.hom (ringHom alpha-hom) = alpha
    RingHom.pres-0 (ringHom alpha-hom) = ext (λ x → RingHom.pres-0 (ringHom (Data.evaluation-hom x)))
    RingHom.pres-1 (ringHom alpha-hom) = ext (λ x → RingHom.pres-1 (ringHom (Data.evaluation-hom x)))
    RingHom.pres-+ (ringHom alpha-hom) c d = ext (λ x → RingHom.pres-+ (ringHom (Data.evaluation-hom x)) c d)
    RingHom.pres-* (ringHom alpha-hom) c d = ext (λ x → RingHom.pres-* (ringHom (Data.evaluation-hom x)) c d)
    RingHom.pres-neg (ringHom alpha-hom) c = ext (λ x → RingHom.pres-neg (ringHom (Data.evaluation-hom x)) c)
    commutes alpha-hom r = ext (λ x → commutes (Data.evaluation-hom x) r)

    -- Axiom 1^W for this particular Weil algebra asserts exactly the
    -- invertibility of the displayed canonical algebra map alpha.
    record Axiom1For : Set ℓ where
      field
        inverse : AlgHom Functions Data.tensor-algebra
        left-inverse : (c : C.Carrier) → algMap inverse (alpha c) ≡ c
        right-inverse : (f : Infinitesimal → R) (x : Infinitesimal) → alpha (algMap inverse f) x ≡ f x
    open Axiom1For public

    from-axiom2 : Axiom2 → Axiom1For
    inverse (from-axiom2 Ax) = From.Iso.beta
      where module From = Data.FromAxiom Ax
    left-inverse (from-axiom2 Ax) c = cong (λ h → algMap h c) From.Iso.beta-alpha
      where module From = Data.FromAxiom Ax
    right-inverse (from-axiom2 Ax) f x = cong (λ h → algMap h f x) From.Iso.alpha-beta
      where module From = Data.FromAxiom Ax

    evaluate-base : (c : C.Carrier) → alpha c base-point ≡ c fzero
    evaluate-base c = Data.Sum.basis-expansion c fzero

    evaluation-power : (x : Infinitesimal) (c : C.Carrier) (q : ℕ) →
      alpha (Ideal.CL._^_ c q) x ≡ alpha c x ^ q
    evaluation-power x c zero = RingHom.pres-1 (ringHom (Data.evaluation-hom x))
    evaluation-power x c (suc q) = trans (RingHom.pres-* (ringHom (Data.evaluation-hom x)) c (Ideal.CL._^_ c q))
      (cong (alpha c x *_) (evaluation-power x c q))

    module NilpotentValues (H : Axiom1For) where
      coefficient-zero : (f : Infinitesimal → R) → f base-point ≡ 0r → algMap (inverse H) f fzero ≡ 0r
      coefficient-zero f based = trans (sym (evaluate-base (algMap (inverse H) f)))
        (trans (right-inverse H f base-point) based)

      -- Proposition 16.3, with the uniform bound n determined by the
      -- Weil algebra's dimension n+1. The hypothesis mentions only the
      -- base-point value; nilpotence of every value is the conclusion.
      nilpotent-value : (f : Infinitesimal → R) → f base-point ≡ 0r → (x : Infinitesimal) → f x ^ suc n ≡ 0r
      nilpotent-value f based x =
        trans (cong (_^ suc n) (sym (right-inverse H f x)))
          (trans (sym (evaluation-power x (algMap (inverse H) f) (suc n)))
            (trans (cong (λ c → alpha c x)
              (Ideal.nilpotent (AW.nilpotence-constants scalar-extension) (algMap (inverse H) f) (coefficient-zero f based)))
              (RingHom.pres-0 (ringHom (Data.evaluation-hom x)))))

      factor-through-DK : (f : Infinitesimal → R) → f base-point ≡ 0r → Infinitesimal → S3.HigherInfinitesimals.DK A n
      factor-through-DK f based x = S3.HigherInfinitesimals.nilpotent (f x) (nilpotent-value f based x)

      factorization : (f : Infinitesimal → R) (based : f base-point ≡ 0r) (x : Infinitesimal) →
        S3.HigherInfinitesimals.valueK (factor-through-DK f based x) ≡ f x
      factorization f based x = refl

      parametrized-factorization : (X : Set ℓ) (g : X → Infinitesimal → R) →
        ((x : X) → g x base-point ≡ 0r) → X → Infinitesimal → S3.HigherInfinitesimals.DK A n
      parametrized-factorization X g based x = factor-through-DK (g x) (based x)

  Axiom1W : Set (κ ⊔ ℓ)
  Axiom1W = (n : ℕ) (Weil : KW.WeilAlgebra n) → For.Axiom1For n Weil

  -- Theorem 16.1 for every actual Weil algebra represented by its finite
  -- structure constants. Scalar extension and ideal nilpotence were
  -- established algebraically in Algebra.Weil, not assumed here.
  axiom2-weil : Axiom2 → Axiom1W
  axiom2-weil Ax n Weil = For.from-axiom2 n Weil Ax
