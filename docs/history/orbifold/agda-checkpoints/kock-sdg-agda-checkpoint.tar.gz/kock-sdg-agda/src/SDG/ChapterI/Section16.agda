{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section16 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras
open import SDG.Algebra.Presented
open import SDG.Algebra.PresentedStructure
import SDG.Algebra.StructureConstants as SC
import SDG.Combinatorics.FiniteSums as FS
import SDG.Combinatorics.FiniteLinear as FL
open import SDG.Finite using (Fin; fzero; fsuc)
open import SDG.Schemes.Extensionality
open import SDG.Schemes.Isomorphism
open import SDG.Schemes.FiniteBlocks using (splitIndex; injectIndex)
import SDG.ChapterI.Section12 as S12
import SDG.ChapterI.Section16Comparison as Comparison

-- Theorem 16.1, in the stronger finite-free form: nilpotence is not used
-- for the comparison itself. Starting with structure constants over k,
-- the tensor extension algebra on R^(n+1) and the finitely presented
-- spectrum are constructed. Their canonical evaluation map is then
-- proved invertible from Axiom 2, without a representability premise.
module FiniteFreeData {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (n : ℕ) (T : SC.Tables.Table k n) where
  open RingLemmas A
  open Presentations k
  open S12.Comprehensive k A base ext ext0 setR
  open FL.Coordinates A ext0
  module Sum = FS.Sums A
  module P = StructurePresentation.At k n T
  module C = SC.Tables.Build A ext0 n (SC.Change.change-table k A base T)
  module CS = FS.Sums C.coordinate-ring
  module CL = RingLemmas C.coordinate-ring
  private
    I = Fin (suc n)
    γ = SC.Tables.constants T

  tensor-algebra : RAlgebra A ℓ
  tensor-algebra = C.coordinate-algebra

  coefficient-ring-map : RingHom k C.coordinate-ring
  coefficient-ring-map = composeRingHom C.scalar-hom base

  scalar-times : (r : R) (x : C.Carrier) → C.multiply (C.scalar r) x ≡ C.scale r x
  scalar-times r x = ext0 (λ i → trans (map-scale (C.left-linear x i) r C.oneC)
    (cong (r *_) (cong (λ y → y i) (C.multiplication-one x))))

  sum-coordinate : {m : ℕ} (f : Fin m → C.Carrier) (i : I) →
    CS.sum f i ≡ Sum.sum (λ j → f j i)
  sum-coordinate {zero} f i = refl
  sum-coordinate {suc m} f i = cong (f fzero i +_) (sum-coordinate (λ j → f (fsuc j)) i)

  basis-normal-form : (x : C.Carrier) → CS.sum (λ j → C.multiply (C.scalar (x j)) (Sum.delta j)) ≡ x
  basis-normal-form x = ext0 (λ i → trans (sum-coordinate (λ j → C.multiply (C.scalar (x j)) (Sum.delta j)) i)
    (trans (Sum.sum-cong (λ j → cong (λ v → v i) (scalar-times (x j) (Sum.delta j))))
      (Sum.basis-expansion x i)))

  multiplication-normal-form : (j l : I) →
    CS.sum (λ i → C.multiply (C.scalar (RingHom.hom base (γ i j l))) (Sum.delta i)) ≡
      C.multiply (Sum.delta j) (Sum.delta l)
  multiplication-normal-form j l = trans (CS.sum-cong (λ i →
    cong (λ r → C.multiply (C.scalar r) (Sum.delta i)) (sym (C.multiply-basis j l i))))
    (basis-normal-form (C.multiply (Sum.delta j) (Sum.delta l)))

  generator-product : (j l : I) →
    evaluate C.coordinate-ring (RingHom.hom coefficient-ring-map) (P.pair-polynomial j l) Sum.delta ≡ C.zeroC
  generator-product j l = trans (cong (λ v → C.add (C.multiply (Sum.delta j) (Sum.delta l)) (C.negate v))
    (trans (StructurePresentation.evaluate-sum k C.coordinate-ring coefficient-ring-map
      (λ i → coefficient (γ i j l) ⊗ var i) Sum.delta) (multiplication-normal-form j l)))
    (CL.+-inverseʳ (C.multiply (Sum.delta j) (Sum.delta l)))

  generic-basis : SpecC tensor-algebra P.presentation
  coordinates generic-basis = Sum.delta
  satisfies generic-basis fzero = trans (cong (λ c → C.add C.oneC (C.negate c)) (RingHom.pres-1 coefficient-ring-map))
    (CL.+-inverseʳ C.oneC)
  satisfies generic-basis (fsuc j) = generator-product (fst (splitIndex P.pair-sizes j)) (snd (splitIndex P.pair-sizes j))

  subtract-zero : (a b : R) → a + (- b) ≡ 0r → a ≡ b
  subtract-zero a b eq = +-cancelʳ (- b) (trans eq (sym (+-inverseʳ b)))

  point-unit : (x : Affine P.presentation) → coordinates x fzero ≡ 1r
  point-unit x = subtract-zero (coordinates x fzero) 1r
    (trans (cong (λ r → coordinates x fzero + (- r)) (sym (RingHom.pres-1 base))) (satisfies x fzero))

  point-product : (x : Affine P.presentation) (j l : I) →
    coordinates x j * coordinates x l ≡ Sum.sum (λ i → RingHom.hom base (γ i j l) * coordinates x i)
  point-product x j l = subtract-zero (coordinates x j * coordinates x l)
    (Sum.sum (λ i → RingHom.hom base (γ i j l) * coordinates x i))
    (trans (cong (λ r → (coordinates x j * coordinates x l) + (- r))
      (sym (StructurePresentation.evaluate-sum k A base (λ i → coefficient (γ i j l) ⊗ var i) (coordinates x))))
      (trans (cong (λ p → evaluate A (RingHom.hom base) p (coordinates x)) (sym (P.pair-equation j l)))
        (satisfies x (fsuc (injectIndex P.pair-sizes j l)))))

  scalar-evaluation : (x : Affine P.presentation) → C.Carrier → R
  scalar-evaluation x c = Sum.sum (λ i → c i * coordinates x i)

  evaluation-linear : (x : Affine P.presentation) → Linear (scalar-evaluation x)
  map-zero (evaluation-linear x) = trans (Sum.sum-cong {n = suc n} (λ i → *-zeroˡ (coordinates x i))) (Sum.sum-zero (suc n))
  map-add (evaluation-linear x) = λ c d → Sum.dot-addˡ c d (coordinates x)
  map-scale (evaluation-linear x) = λ r c → Sum.dot-scaleˡ r c (coordinates x)

  evaluation-basis : (x : Affine P.presentation) (i : I) → scalar-evaluation x (Sum.delta i) ≡ coordinates x i
  evaluation-basis x i = Sum.sum-delta (coordinates x) i

  evaluation-product : (x : Affine P.presentation) (c d : C.Carrier) →
    scalar-evaluation x (C.multiply c d) ≡ scalar-evaluation x c * scalar-evaluation x d
  evaluation-product x = bilinear-ext
    (λ c d → scalar-evaluation x (C.multiply c d)) (λ c d → scalar-evaluation x c * scalar-evaluation x d)
    (λ d → compose-linear (evaluation-linear x) (C.left-linear d))
    (λ c → compose-linear (evaluation-linear x) (C.right-linear c))
    (λ d → right-output (scalar-evaluation x d) (evaluation-linear x))
    (λ c → left-output (scalar-evaluation x c) (evaluation-linear x))
    (λ j l → trans (Sum.sum-cong (λ i → cong (_* coordinates x i) (C.multiply-basis j l i)))
      (trans (sym (point-product x j l)) (cong₂ _*_ (sym (evaluation-basis x j)) (sym (evaluation-basis x l)))))

  evaluation-scalar : (x : Affine P.presentation) (r : R) → scalar-evaluation x (C.scalar r) ≡ r
  evaluation-scalar x r = trans (map-scale (evaluation-linear x) r C.oneC)
    (trans (cong (r *_) (trans (evaluation-basis x fzero) (point-unit x))) (*-identityʳ r))

  evaluation-hom : (x : Affine P.presentation) → AlgHom tensor-algebra (scalarAlgebra A)
  RingHom.hom (ringHom (evaluation-hom x)) = scalar-evaluation x
  RingHom.pres-0 (ringHom (evaluation-hom x)) = map-zero (evaluation-linear x)
  RingHom.pres-1 (ringHom (evaluation-hom x)) = trans (evaluation-basis x fzero) (point-unit x)
  RingHom.pres-+ (ringHom (evaluation-hom x)) = map-add (evaluation-linear x)
  RingHom.pres-* (ringHom (evaluation-hom x)) = evaluation-product x
  RingHom.pres-neg (ringHom (evaluation-hom x)) c = trans (Sum.sum-cong (λ i → neg-mulˡ (c i) (coordinates x i)))
    (Sum.sum-neg (λ i → c i * coordinates x i))
  commutes (evaluation-hom x) = evaluation-scalar x

  hom-sum : (f : AlgHom tensor-algebra tensor-algebra) {m : ℕ} (x : Fin m → C.Carrier) →
    algMap f (CS.sum x) ≡ CS.sum (λ i → algMap f (x i))
  hom-sum f {zero} x = RingHom.pres-0 (ringHom f)
  hom-sum f {suc m} x = trans (RingHom.pres-+ (ringHom f) (x fzero) (CS.sum (λ i → x (fsuc i))))
    (cong (C.add (algMap f (x fzero))) (hom-sum f (λ i → x (fsuc i))))

  hom-normal-form : (f : AlgHom tensor-algebra tensor-algebra) (x : C.Carrier) →
    algMap f x ≡ CS.sum (λ i → C.multiply (C.scalar (x i)) (algMap f (Sum.delta i)))
  hom-normal-form f x = trans (cong (algMap f) (sym (basis-normal-form x)))
    (trans (hom-sum f (λ i → C.multiply (C.scalar (x i)) (Sum.delta i)))
      (CS.sum-cong (λ i → trans (RingHom.pres-* (ringHom f) (C.scalar (x i)) (Sum.delta i))
        (cong (λ c → C.multiply c (algMap f (Sum.delta i))) (commutes f (x i))))))

  basis-generated : (f g : AlgHom tensor-algebra tensor-algebra) →
    ((i : I) → algMap f (Sum.delta i) ≡ algMap g (Sum.delta i)) → f ≡ g
  basis-generated f g eq = algHom-ext ext ext ext (function-set ext0 (λ _ → setR))
    (λ x → trans (hom-normal-form f x)
      (trans (CS.sum-cong (λ i → cong (C.multiply (C.scalar (x i))) (eq i))) (sym (hom-normal-form g x))))

  module FromAxiom (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR) where
    open Comparison.Comparison k A base ext ext0 setR Ax
    table-realization : AlgebraicRealization P.presentation
    model-algebra table-realization = tensor-algebra
    set-carrier table-realization = function-set ext0 (λ _ → setR)
    generic-point table-realization = generic-basis
    character table-realization = evaluation-hom
    evaluate-generator table-realization = evaluation-basis
    generated table-realization = basis-generated

    module Iso = Realized P.presentation table-realization

    -- Actual alpha and beta are R-algebra maps, with both native inverse
    -- laws. Its formula is precisely the coefficient/basis evaluation
    -- formula (16.5), for the canonical basis-generator presentation.
    axiom2-finite-free-comparison : Isomorphism C.Carrier (Affine P.presentation → R)
    axiom2-finite-free-comparison = Iso.comparison-isomorphism

    comparison-formula : (c : C.Carrier) (x : Affine P.presentation) →
      algMap Iso.alpha c x ≡ Sum.sum (λ i → c i * coordinates x i)
    comparison-formula c x = refl

-- The original public entry point, preserving the theorem interface.
module FiniteFreeComparison {κ ℓ : Level} (k : CRing κ) (A : CRing ℓ)
  (base : RingHom k A) (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ)
  (setR : isSet (CRing.R A))
  (Ax : S12.Comprehensive.Axiom2 k A base ext ext0 setR)
  (n : ℕ) (T : SC.Tables.Table k n) where
  open FiniteFreeData k A base ext ext0 setR n T public
  open FromAxiom Ax public
