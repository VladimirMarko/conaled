{-# OPTIONS --safe --without-K #-}
module SDG.Forms.CubeActions where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; Vec; lookup; update; lookup-update-same;
  update-overwrite; update-identity; Permutation; identityPerm; composePerm;
  permute-identity; permute-compose)
open import SDG.Forms.Basic
import SDG.ChapterI.Section07 as S7

module Actions {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) (ext : FunExt ℓ ℓ) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR using (scale-one; scale-assoc)
  open Cubes A

  coordinate-one : {n : ℕ} (ds : Vec D n) (i : Fin n) → scale-coordinates ds i 1r ≡ ds
  coordinate-one ds i = trans (cong (update ds i) (scale-one (lookup ds i))) (update-identity ds i)

  coordinate-product : {n : ℕ} (ds : Vec D n) (i : Fin n) (r s : R) →
    scale-coordinates ds i (r * s) ≡ scale-coordinates (scale-coordinates ds i r) i s
  coordinate-product ds i r s = trans (cong (update ds i) (scale-assoc (lookup ds i) r s))
    (sym (trans
      (cong (λ d → update (scale-coordinates ds i r) i (scaleD d s))
        (lookup-update-same ds i (scaleD (lookup ds i) r)))
      (update-overwrite ds i (scaleD (lookup ds i) r) (scaleD (scaleD (lookup ds i) r) s))))

  cube-action : {n : ℕ} {M : Set ℓ} → Fin n → ScalarAction A (Cube n M)
  ScalarAction.act (cube-action i) r τ = scale-cube τ i r
  ScalarAction.act-one (cube-action i) τ = ext (λ ds → cong τ (coordinate-one ds i))
  ScalarAction.act-product (cube-action i) r s τ = ext (λ ds → cong τ (coordinate-product ds i r s))

  permutation-identity : {n : ℕ} {M : Set ℓ} (τ : Cube n M) → permute-cube τ identityPerm ≡ τ
  permutation-identity τ = ext (λ ds → cong τ (permute-identity ds))

  permutation-composition : {n : ℕ} {M : Set ℓ} (τ : Cube n M) (p q : Permutation n) →
    permute-cube (permute-cube τ p) q ≡ permute-cube τ (composePerm q p)
  permutation-composition τ p q = ext (λ ds → cong τ (permute-compose p q ds))

  map-scale : {n : ℕ} {M N : Set ℓ} (f : M → N) (τ : Cube n M) (i : Fin n) (r : R) →
    map-cube f (scale-cube τ i r) ≡ scale-cube (map-cube f τ) i r
  map-scale f τ i r = refl

  map-permutation : {n : ℕ} {M N : Set ℓ} (f : M → N) (τ : Cube n M) (p : Permutation n) →
    map-cube f (permute-cube τ p) ≡ permute-cube (map-cube f τ) p
  map-permutation f τ p = refl
