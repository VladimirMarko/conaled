{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section01Exercises where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc)
open import SDG.Algebra.DualNumbers using (RingHom; module DualNumbers)
import SDG.ChapterI.Section01 as Section01

-- I.1.2 and I.1.3 are algebraic facts: KL is not a hypothesis here.
module Algebraic {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A

  sub-zero : (x : R) → x - 0r ≡ x
  sub-zero x = trans (cong (x +_) neg-zero) (+-identityʳ x)

  zero-sub : (x : R) → 0r - x ≡ - x
  zero-sub x = +-identityˡ (- x)

  -- Circle of radius one centered at (0,1), with no appeal to a metric model.
  UnitCircleAt01 : R → R → Set ℓ
  UnitCircleAt01 x y =
    ((x - 0r) * (x - 0r)) + ((y - 1r) * (y - 1r)) ≡ 1r * 1r

  circle-on-axis-normalize : (x : R) →
    ((x - 0r) * (x - 0r)) + ((0r - 1r) * (0r - 1r)) ≡ (x * x) + 1r
  circle-on-axis-normalize x = cong₂ _+_
    (cong₂ _*_ (sub-zero x) (sub-zero x))
    (trans (cong₂ _*_ (zero-sub 1r) (zero-sub 1r))
      (trans (neg-mul-neg 1r 1r) (*-identityʳ 1r)))

  -- Exercise I.1.2: both directions of the intersection description.
  square-zero-to-circle : (x : R) → x * x ≡ 0r → UnitCircleAt01 x 0r
  square-zero-to-circle x p =
    trans (circle-on-axis-normalize x)
      (trans (cong (_+ 1r) p)
        (trans (+-identityˡ 1r) (sym (*-identityʳ 1r))))

  circle-to-square-zero : (x : R) → UnitCircleAt01 x 0r → x * x ≡ 0r
  circle-to-square-zero x p = +-cancelʳ 1r
    (trans (sym (circle-on-axis-normalize x))
      (trans p (trans (*-identityʳ 1r) (sym (+-identityˡ 1r)))))

  two : R
  two = 1r + 1r

  double : (x : R) → two * x ≡ x + x
  double x = trans (distribʳ 1r 1r x)
    (cong₂ _+_ (*-identityˡ x) (*-identityˡ x))

  -- Exercise I.1.3, scalar closure (the underlying construction is scaleD).
  scaled-is-square-zero : (d : D) (r : R) →
    (value d * r) * (value d * r) ≡ 0r
  scaled-is-square-zero d r = square-zero-scaled (value d) r (square-zero d)

  sum-square : (d e : D) →
    (value d + value e) * (value d + value e) ≡ two * (value d * value e)
  sum-square d e =
    begin
      (value d + value e) * (value d + value e)
    ≡⟨ expand-product (value d) (value e) (value d) (value e) ⟩
      ((value d * value d) + (value d * value e)) +
        ((value e * value d) + (value e * value e))
    ≡⟨ cong₂ _+_
          (trans (cong (_+ (value d * value e)) (square-zero d))
            (+-identityˡ (value d * value e)))
          (trans (cong ((value e * value d) +_) (square-zero e))
            (trans (+-identityʳ (value e * value d)) (*-comm (value e) (value d)))) ⟩
      (value d * value e) + (value d * value e)
    ≡⟨ sym (double (value d * value e)) ⟩
      two * (value d * value e) ∎

  product-zero-implies-sum-square-zero : (d e : D) →
    value d * value e ≡ 0r →
    (value d + value e) * (value d + value e) ≡ 0r
  product-zero-implies-sum-square-zero d e p =
    trans (sum-square d e) (trans (cong (two *_) p) (*-zeroʳ two))

  record TwoInvertible : Set ℓ where
    field
      half : R
      two-half : two * half ≡ 1r

  module WithHalf (H : TwoInvertible) where
    open TwoInvertible H

    cancel-two-zero : (x : R) → two * x ≡ 0r → x ≡ 0r
    cancel-two-zero x p =
      begin
        x
      ≡⟨ sym (*-identityˡ x) ⟩
        1r * x
      ≡⟨ cong (_* x) (sym (trans (*-comm half two) two-half)) ⟩
        (half * two) * x
      ≡⟨ *-assoc half two x ⟩
        half * (two * x)
      ≡⟨ cong (half *_) p ⟩
        half * 0r
      ≡⟨ *-zeroʳ half ⟩
        0r ∎

    sum-square-zero-implies-product-zero : (d e : D) →
      (value d + value e) * (value d + value e) ≡ 0r →
      value d * value e ≡ 0r
    sum-square-zero-implies-product-zero d e p =
      cancel-two-zero (value d * value e) (trans (sym (sum-square d e)) p)

-- Exercise I.1.1 (Schanuel): scalar zero-decidability is already impossible.
-- The proof is constructive in the hypothetical decision function. It does
-- not assume that double negation can be eliminated to exhibit a nonzero d.
module Schanuel {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A)
  (nontrivial : CRing.0r A ≢ CRing.1r A)
  (decide-zero : (x : CRing.R A) → Dec (x ≡ CRing.0r A)) where
  open RingLemmas A
  open Infinitesimals A
  open KockLawvere K
  open Section01.Results A K using (cancel-infinitesimals)

  characteristic : D → R
  characteristic d with decide-zero (value d)
  ... | yes _ = 0r
  ... | no  _ = 1r

  characteristic-at-zero : (d : D) → value d ≡ 0r → characteristic d ≡ 0r
  characteristic-at-zero d p with decide-zero (value d)
  ... | yes _ = refl
  ... | no np = ⊥-elim (np p)

  characteristic-at-nonzero : (d : D) → value d ≢ 0r → characteristic d ≡ 1r
  characteristic-at-nonzero d np with decide-zero (value d)
  ... | yes p = ⊥-elim (np p)
  ... | no _ = refl

  nonzero-impossible : (d : D) → value d ≢ 0r → ⊥
  nonzero-impossible d np = nontrivial (sym one-is-zero)
    where
      one-is-product : 1r ≡ value d * slope characteristic
      one-is-product =
        trans (sym (characteristic-at-nonzero d np))
          (trans (expansion characteristic d)
            (trans (cong (_+ (value d * slope characteristic))
              (characteristic-at-zero zeroD refl))
              (+-identityˡ (value d * slope characteristic))))

      one-is-zero : 1r ≡ 0r
      one-is-zero =
        trans (sym (*-identityʳ 1r))
          (trans (cong (λ x → x * x) one-is-product)
            (square-zero-scaled (value d) (slope characteristic) (square-zero d)))

  every-infinitesimal-zero : (d : D) → value d ≡ 0r
  every-infinitesimal-zero d with decide-zero (value d)
  ... | yes p = p
  ... | no np = ⊥-elim (nonzero-impossible d np)

  contradiction : ⊥
  contradiction = nontrivial (cancel-infinitesimals 0r 1r
    (λ d → trans (*-zeroʳ (value d))
      (sym (trans (*-identityʳ (value d)) (every-infinitesimal-zero d)))))

zero-decidability-impossible : {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) →
  CRing.0r A ≢ CRing.1r A →
  ((x : CRing.R A) → Dec (x ≡ CRing.0r A)) → ⊥
zero-decidability-impossible A K nontrivial decide-zero =
  Schanuel.contradiction A K nontrivial decide-zero

-- Exercise I.1.4: the existence half of KL on E is sufficient. No theorem
-- about square-zero values is assumed. E need not even be given as a subtype:
-- this more general statement applies to its inclusion into R in particular.
module AffineDomain {ℓ ε : Level} (A : CRing ℓ)
  (E : Set ε) (point : E → CRing.R A) (origin : E)
  (point-origin : point origin ≡ CRing.0r A)
  (negateE : E → E)
  (point-negate : (e : E) → point (negateE e) ≡ CRing.-_ A (point e))
  (H : Algebraic.TwoInvertible A)
  (coefficient : (E → CRing.R A) → CRing.R A)
  (affine-expansion : (g : E → CRing.R A) (e : E) →
    g e ≡ CRing._+_ A (g origin) (CRing._*_ A (point e) (coefficient g))) where
  open RingLemmas A
  open Algebraic A using (two; double)
  open Algebraic.WithHalf A H using (cancel-two-zero)

  square : E → R
  square e = point e * point e

  square-origin : square origin ≡ 0r
  square-origin = trans (cong₂ _*_ point-origin point-origin) (*-zeroˡ 0r)

  b : R
  b = coefficient square

  square-is-linear : (e : E) → square e ≡ point e * b
  square-is-linear e = trans (affine-expansion square e)
    (trans (cong (_+ (point e * b)) square-origin) (+-identityˡ (point e * b)))

  square-is-even : (e : E) → square (negateE e) ≡ square e
  square-is-even e = trans (cong₂ _*_ (point-negate e) (point-negate e))
    (neg-mul-neg (point e) (point e))

  linear-is-own-negative : (e : E) → point e * b ≡ - (point e * b)
  linear-is-own-negative e =
    trans (sym (square-is-linear e))
      (trans (sym (square-is-even e))
        (trans (square-is-linear (negateE e))
          (trans (cong (_* b) (point-negate e)) (neg-mulˡ (point e) b))))

  every-point-square-zero : (e : E) → point e * point e ≡ 0r
  every-point-square-zero e = trans (square-is-linear e)
    (cancel-two-zero (point e * b)
      (trans (double (point e * b))
        (trans (cong ((point e * b) +_) (linear-is-own-negative e))
          (+-inverseʳ (point e * b)))))

-- Exercise I.1.5. Integer-polynomial expressions are generated by variables,
-- 0, 1, addition, multiplication and negation. No normal form or equality
-- decision for scalars is required. These expressions represent arbitrary
-- multivariable polynomials with integer coefficients.
data IntegerPolynomial (n : ℕ) : Set where
  varP : Fin n → IntegerPolynomial n
  zeroP oneP : IntegerPolynomial n
  addP mulP : IntegerPolynomial n → IntegerPolynomial n → IntegerPolynomial n
  negP : IntegerPolynomial n → IntegerPolynomial n

module PolynomialEvaluation {ℓ : Level} (A : CRing ℓ) where
  open CRing A

  evaluate : {n : ℕ} → IntegerPolynomial n → (Fin n → R) → R
  evaluate (varP i) xs = xs i
  evaluate zeroP xs = 0r
  evaluate oneP xs = 1r
  evaluate (addP p q) xs = evaluate p xs + evaluate q xs
  evaluate (mulP p q) xs = evaluate p xs * evaluate q xs
  evaluate (negP p) xs = - evaluate p xs

  -- Polynomial evaluation in a function ring, stated pointwise so that
  -- no functional-extensionality axiom is needed to package that ring.
  evaluate-functions : {ε : Level} {X : Set ε} {n : ℕ} →
    IntegerPolynomial n → (Fin n → X → R) → X → R
  evaluate-functions (varP i) xs x = xs i x
  evaluate-functions zeroP xs x = 0r
  evaluate-functions oneP xs x = 1r
  evaluate-functions (addP p q) xs x =
    evaluate-functions p xs x + evaluate-functions q xs x
  evaluate-functions (mulP p q) xs x =
    evaluate-functions p xs x * evaluate-functions q xs x
  evaluate-functions (negP p) xs x = - evaluate-functions p xs x

  evaluate-functions-pointwise : {ε : Level} {X : Set ε} {n : ℕ}
    (p : IntegerPolynomial n) (xs : Fin n → X → R) (x : X) →
    evaluate-functions p xs x ≡ evaluate p (λ i → xs i x)
  evaluate-functions-pointwise (varP i) xs x = refl
  evaluate-functions-pointwise zeroP xs x = refl
  evaluate-functions-pointwise oneP xs x = refl
  evaluate-functions-pointwise (addP p q) xs x =
    cong₂ _+_ (evaluate-functions-pointwise p xs x) (evaluate-functions-pointwise q xs x)
  evaluate-functions-pointwise (mulP p q) xs x =
    cong₂ _*_ (evaluate-functions-pointwise p xs x) (evaluate-functions-pointwise q xs x)
  evaluate-functions-pointwise (negP p) xs x =
    cong -_ (evaluate-functions-pointwise p xs x)

module PolynomialHomomorphisms {a b : Level} (A : CRing a) (B : CRing b) where
  private
    module A = CRing A
    module B = CRing B
    module EA = PolynomialEvaluation A
    module EB = PolynomialEvaluation B

  PreservesPolynomials : (A.R → B.R) → Set (a ⊔ b)
  PreservesPolynomials h = {n : ℕ} (p : IntegerPolynomial n) (xs : Fin n → A.R) →
    h (EA.evaluate p xs) ≡ EB.evaluate p (λ i → h (xs i))

  hom-preserves-polynomials : (h : RingHom A B) → PreservesPolynomials (RingHom.hom h)
  hom-preserves-polynomials h (varP i) xs = refl
  hom-preserves-polynomials h zeroP xs = RingHom.pres-0 h
  hom-preserves-polynomials h oneP xs = RingHom.pres-1 h
  hom-preserves-polynomials h (addP p q) xs =
    trans (RingHom.pres-+ h (EA.evaluate p xs) (EA.evaluate q xs))
      (cong₂ B._+_ (hom-preserves-polynomials h p xs) (hom-preserves-polynomials h q xs))
  hom-preserves-polynomials h (mulP p q) xs =
    trans (RingHom.pres-* h (EA.evaluate p xs) (EA.evaluate q xs))
      (cong₂ B._*_ (hom-preserves-polynomials h p xs) (hom-preserves-polynomials h q xs))
  hom-preserves-polynomials h (negP p) xs =
    trans (RingHom.pres-neg h (EA.evaluate p xs))
      (cong B.-_ (hom-preserves-polynomials h p xs))

  pair-environment : A.R → A.R → Fin (suc (suc zero)) → A.R
  pair-environment x y fzero = x
  pair-environment x y (fsuc fzero) = y

  polynomial-preservation-is-hom : (h : A.R → B.R) →
    PreservesPolynomials h → RingHom A B
  polynomial-preservation-is-hom h preserves = record
    { hom = h
    ; pres-0 = preserves {zero} zeroP (λ ())
    ; pres-1 = preserves {zero} oneP (λ ())
    ; pres-+ = λ x y → preserves
        (addP (varP fzero) (varP (fsuc fzero))) (pair-environment x y)
    ; pres-* = λ x y → preserves
        (mulP (varP fzero) (varP (fsuc fzero))) (pair-environment x y)
    ; pres-neg = λ x → preserves (negP (varP fzero)) (pair-environment x x)
    }

-- The polynomial compatibility square for alpha, evaluated at any d:D.
-- This part uses ring identities and d*d=0 only, not the KL axiom.
module DualPolynomialCompatibility {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open Infinitesimals A
  module Dual = DualNumbers A
  module EDual = PolynomialEvaluation Dual.dualRing
  module ER = PolynomialEvaluation A
  module Homs = PolynomialHomomorphisms Dual.dualRing A

  alpha-at : D → Dual.Dual → R
  alpha-at d (a , b) = a + value d * b

  alpha-at-hom : (d : D) → RingHom Dual.dualRing A
  alpha-at-hom d = record
    { hom = alpha-at d
    ; pres-0 = trans (+-identityˡ (value d * 0r)) (*-zeroʳ (value d))
    ; pres-1 = trans (cong (1r +_) (*-zeroʳ (value d))) (+-identityʳ 1r)
    ; pres-+ = λ { (a , b) (c , e) →
        trans (cong ((a + c) +_) (distribˡ (value d) b e))
          (+-shuffle a c (value d * b) (value d * e)) }
    ; pres-* = λ { (a , b) (c , e) →
        sym (affine-product (value d) a b c e (square-zero d)) }
    ; pres-neg = λ { (a , b) →
        trans (cong ((- a) +_) (neg-mulʳ (value d) b))
          (sym (neg-add a (value d * b))) }
    }

  alpha-at-scalar : (d : D) (r : R) → alpha-at d (Dual.scalar r) ≡ r
  alpha-at-scalar d r =
    trans (cong (r +_) (*-zeroʳ (value d))) (+-identityʳ r)

  alpha-polynomial : {n : ℕ} (p : IntegerPolynomial n)
    (xs : Fin n → Dual.Dual) (d : D) →
    alpha-at d (EDual.evaluate p xs) ≡ ER.evaluate p (λ i → alpha-at d (xs i))
  alpha-polynomial p xs d = Homs.hom-preserves-polynomials (alpha-at-hom d) p xs
