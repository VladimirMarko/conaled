{-# OPTIONS --safe --without-K #-}

module SDG.Combinatorics.Enumeration where

open import SDG.Prelude
open import SDG.Finite using (Fin; fzero; fsuc; compareFin; same; different;
  Permutation; to; identityPerm; composePerm; liftPerm)
open import SDG.Forms.CubicalGeometry using (unskip; skip-unskip)
open import SDG.Flows.CommutingActions using (swapZero; swapZero-involutive; swapPermutation)

-- A repeated coordinate is exhibited at its earliest recursive prefix.
-- This presentation supports induction through contractions of forms.
data Repeated {a : Level} {X : Set a} : {m : ℕ} → (Fin m → X) → Set a where
  at-head : {m : ℕ} {f : Fin (suc m) → X} →
    (j : Fin m) → f fzero ≡ f (fsuc j) → Repeated f
  in-tail : {m : ℕ} {f : Fin (suc m) → X} →
    Repeated (λ j → f (fsuc j)) → Repeated f

repeated-map : {a b : Level} {X : Set a} {Y : Set b} {m : ℕ}
  {f : Fin m → X} (h : X → Y) → Repeated f → Repeated (h ∘ f)
repeated-map h (at-head j p) = at-head j (cong h p)
repeated-map h (in-tail r) = in-tail (repeated-map h r)

repeated-cong : {a : Level} {X : Set a} {m : ℕ} {f g : Fin m → X} →
  ((i : Fin m) → f i ≡ g i) → Repeated f → Repeated g
repeated-cong eq (at-head j p) = at-head j (trans (sym (eq fzero)) (trans p (eq (fsuc j))))
repeated-cong eq (in-tail r) = in-tail (repeated-cong (λ j → eq (fsuc j)) r)

private
  impossible : Fin zero → ⊥
  impossible ()

  data Search {k m : ℕ} (i : Fin k) (f : Fin m → Fin k) : Set where
    found : (j : Fin m) → f j ≡ i → Search i f
    absent : ((j : Fin m) → f j ≢ i) → Search i f

  search : {k m : ℕ} (i : Fin k) (f : Fin m → Fin k) → Search i f
  search {m = zero} i f = absent (λ ())
  search {m = suc m} i f with compareFin (f fzero) i
  ... | same = found fzero refl
  ... | different ne with search i (λ j → f (fsuc j))
  ...   | found j p = found (fsuc j) p
  ...   | absent missing = absent (λ { fzero p → impossible (ne p); (fsuc j) p → missing j p })

  swap-head : {n : ℕ} (i : Fin (suc n)) → swapZero i fzero ≡ i
  swap-head fzero = refl
  swap-head (fsuc i) = refl

data Enumeration {n : ℕ} (f : Fin n → Fin n) : Set where
  duplicate : Repeated f → Enumeration f
  exhaustive : (p : Permutation n) → ((i : Fin n) → f i ≡ to p i) → Enumeration f

-- Constructive pigeonhole dichotomy for a square finite index list.
-- Only finite indices are compared; no scalar equality is decided.
enumerate : {n : ℕ} (f : Fin n → Fin n) → Enumeration f
enumerate {zero} f = exhaustive identityPerm (λ ())
enumerate {suc n} f with search (f fzero) (λ j → f (fsuc j))
... | found j p = duplicate (at-head j (sym p))
... | absent ne = descend (enumerate smaller)
  where
  pivot : Fin (suc n)
  pivot = f fzero

  away-from-zero : (j : Fin n) → swapZero pivot (f (fsuc j)) ≢ fzero
  away-from-zero j p = ne j (trans (sym (swapZero-involutive pivot (f (fsuc j))))
    (trans (cong (swapZero pivot) p) (swap-head pivot)))

  smaller : Fin n → Fin n
  smaller j = unskip fzero (swapZero pivot (f (fsuc j))) (away-from-zero j)

  reconstruct : (j : Fin n) → swapZero pivot (fsuc (smaller j)) ≡ f (fsuc j)
  reconstruct j = trans (cong (swapZero pivot)
    (skip-unskip fzero (swapZero pivot (f (fsuc j))) (away-from-zero j)))
    (swapZero-involutive pivot (f (fsuc j)))

  descend : Enumeration smaller → Enumeration f
  descend (duplicate r) = duplicate (in-tail
    (repeated-cong reconstruct (repeated-map (λ i → swapZero pivot (fsuc i)) r)))
  descend (exhaustive p eq) = exhaustive (composePerm (swapPermutation pivot) (liftPerm p))
    (λ { fzero → sym (swap-head pivot)
       ; (fsuc j) → trans (sym (reconstruct j)) (cong (λ i → swapZero pivot (fsuc i)) (eq j)) })
