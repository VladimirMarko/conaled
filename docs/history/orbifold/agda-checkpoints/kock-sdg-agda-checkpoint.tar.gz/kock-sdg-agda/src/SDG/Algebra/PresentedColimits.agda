{-# OPTIONS --safe --without-K #-}
module SDG.Algebra.PresentedColimits where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Presented
open import SDG.Algebra.PresentedMorphisms
open import SDG.Finite using (Fin; _+ℕ_)
open import SDG.Schemes.FiniteBlocks
open import SDG.Schemes.Isomorphism

-- An arbitrary finite diagram, including non-discrete diagrams. The
-- colimit has all object generators and relations, together with one
-- relation per arrow and generator identifying its source and target.
module FiniteColimit {κ : Level} (k : CRing κ)
  (objects edges : ℕ) (B : Fin objects → Presentations.Presentation k)
  (source target : Fin edges → Fin objects)
  (arrow : (e : Fin edges) → Morphisms.Hom k (B (source e)) (B (target e))) where
  open Presentations k
  open Morphisms k

  variable-sizes : Fin objects → ℕ
  variable-sizes i = generators (B i)

  relation-sizes : Fin objects → ℕ
  relation-sizes i = relations (B i)

  arrow-sizes : Fin edges → ℕ
  arrow-sizes e = generators (B (source e))

  include-variable : (i : Fin objects) → Fin (generators (B i)) → Polynomial (total variable-sizes)
  include-variable i j = var (injectIndex variable-sizes i j)

  object-equations : Fin (total relation-sizes) → Polynomial (total variable-sizes)
  object-equations = assemble relation-sizes (λ i j → substitute (include-variable i) (equations (B i) j))

  arrow-equations : Fin (total arrow-sizes) → Polynomial (total variable-sizes)
  arrow-equations = assemble arrow-sizes (λ e j →
    include-variable (source e) j ⊕ negative (substitute (include-variable (target e)) (images (arrow e) j)))

  all-equations : Fin (total relation-sizes +ℕ total arrow-sizes) → Polynomial (total variable-sizes)
  all-equations i with split (total relation-sizes) i
  ... | in-left j = object-equations j
  ... | in-right j = arrow-equations j

  colimit : Presentation
  colimit = presented (total variable-sizes) (total relation-sizes +ℕ total arrow-sizes) all-equations

  object-equation : (i : Fin objects) (j : Fin (relations (B i))) →
    equations colimit (left-index (injectIndex relation-sizes i j)) ≡
      substitute (include-variable i) (equations (B i) j)
  object-equation i j rewrite split-left {n = total arrow-sizes} (injectIndex relation-sizes i j) =
    assemble-inject relation-sizes (λ i j → substitute (include-variable i) (equations (B i) j)) i j

  arrow-equation : (e : Fin edges) (j : Fin (generators (B (source e)))) →
    equations colimit (right-index (total relation-sizes) (injectIndex arrow-sizes e j)) ≡
      (include-variable (source e) j ⊕ negative (substitute (include-variable (target e)) (images (arrow e) j)))
  arrow-equation e j rewrite split-right (total relation-sizes) (injectIndex arrow-sizes e j) =
    assemble-inject arrow-sizes (λ e j →
      include-variable (source e) j ⊕ negative (substitute (include-variable (target e)) (images (arrow e) j))) e j

  inclusion : (i : Fin objects) → Hom (B i) colimit
  images (inclusion i) = include-variable i
  respects (inclusion i) j = transitive (from-equality (sym (object-equation i j)))
    (relation (left-index (injectIndex relation-sizes i j)))

  inclusions-commute : (e : Fin edges) → HomEqual (inclusion (source e)) (compose (inclusion (target e)) (arrow e))
  inclusions-commute e j = difference-zero (include-variable (source e) j)
    (substitute (include-variable (target e)) (images (arrow e) j))
    (transitive (from-equality (sym (arrow-equation e j)))
      (relation (right-index (total relation-sizes) (injectIndex arrow-sizes e j))))

  record Cocone (T : Presentation) : Set κ where
    constructor cocone
    field
      maps : (i : Fin objects) → Hom (B i) T
      commutes : (e : Fin edges) → HomEqual (maps (source e)) (compose (maps (target e)) (arrow e))
  open Cocone public

  combined-images : {T : Presentation} → Cocone T → Fin (generators colimit) → Polynomial (generators T)
  combined-images cone = assemble variable-sizes (λ i → images (maps cone i))

  substitution-inclusion : {T : Presentation} (cone : Cocone T) (i : Fin objects)
    (p : Polynomial (generators (B i))) →
    T ⊢ substitute (combined-images cone) (substitute (include-variable i) p) ≈
      substitute (images (maps cone i)) p
  substitution-inclusion cone i p = transitive
    (from-equality (substitute-compose (include-variable i) (combined-images cone) p))
    (substitute-cong _ _ (λ j → from-equality
      (assemble-inject variable-sizes (λ l → images (maps cone l)) i j)) p)

  combined-respects : {T : Presentation} (cone : Cocone T) (j : Fin (relations colimit)) →
    T ⊢ substitute (combined-images cone) (equations colimit j) ≈ zeroP
  combined-respects cone j with split (total relation-sizes) j
  ... | in-left r with splitIndex relation-sizes r
  ... | i , j = transitive (substitution-inclusion cone i (equations (B i) j)) (respects (maps cone i) j)
  combined-respects cone j | in-right r with splitIndex arrow-sizes r
  ... | e , i = transitive
    (additive (from-equality (assemble-inject variable-sizes (λ l → images (maps cone l)) (source e) i))
      (negative-cong (substitution-inclusion cone (target e) (images (arrow e) i))))
    (transitive (additive (commutes cone e i) reflexive)
      (transitive (add-comm _ _) (add-inverse _)))

  factor : {T : Presentation} → Cocone T → Hom colimit T
  images (factor cone) = combined-images cone
  respects (factor cone) = combined-respects cone

  factor-inclusion : {T : Presentation} (cone : Cocone T) (i : Fin objects) →
    HomEqual (compose (factor cone) (inclusion i)) (maps cone i)
  factor-inclusion cone i j = from-equality
    (assemble-inject variable-sizes (λ l → images (maps cone l)) i j)

  factor-unique : {T : Presentation} (cone : Cocone T) (candidate : Hom colimit T) →
    ((i : Fin objects) → HomEqual (compose candidate (inclusion i)) (maps cone i)) →
    HomEqual candidate (factor cone)
  factor-unique cone candidate p j = transitive
    (from-equality (cong (images candidate) (sym (inject-split variable-sizes j))))
    (p (fst (splitIndex variable-sizes j)) (snd (splitIndex variable-sizes j)))

  -- The same explicit construction is interpreted in any k-algebra C,
  -- including an internal algebra object, to prove preservation of finite
  -- limits by Spec. A cone is an actual compatible family of solutions.
  module Solutions {c : Level} (C : CRing c) (ι : RingHom k C)
    (ext0 : FunExt lzero c) (setC : isSet (CRing.R C)) where
    open RingLemmas C renaming (R to Carrier)

    record SolutionCone : Set c where
      constructor compatible-family
      field
        points : (i : Fin objects) → Spec C (RingHom.hom ι) (B i)
        compatible : (e : Fin edges) (j : Fin (generators (B (source e)))) →
          coordinates (points (source e)) j ≡
            evaluate C (RingHom.hom ι) (images (arrow e) j) (coordinates (points (target e)))
    open SolutionCone public

    solution-cone-path : {u v : SolutionCone} →
      ((i : Fin objects) (j : Fin (generators (B i))) → coordinates (points u i) j ≡ coordinates (points v i) j) → u ≡ v
    solution-cone-path {compatible-family u p} {compatible-family v r} eq = aux
      (ext0 (λ i → spec-path ext0 setC (eq i)))
      where
      aux : u ≡ v → compatible-family u p ≡ compatible-family v r
      aux refl = cong (compatible-family u)
        (ext0 (λ e → ext0 (λ j → setC _ _ (p e j) (r e j))))

    restrict-solution : Spec C (RingHom.hom ι) colimit → SolutionCone
    points (restrict-solution x) i = spec-map C ι (inclusion i) x
    compatible (restrict-solution x) e j =
      trans (sound C ι x (inclusions-commute e j))
        (evaluate-substitute C (RingHom.hom ι) (include-variable (target e)) (images (arrow e) j) (coordinates x))

    combined-coordinates : SolutionCone → Fin (generators colimit) → Carrier
    combined-coordinates cone = assemble variable-sizes (λ i → coordinates (points cone i))

    evaluate-inclusion : (cone : SolutionCone) (i : Fin objects) (p : Polynomial (generators (B i))) →
      evaluate C (RingHom.hom ι) (substitute (include-variable i) p) (combined-coordinates cone) ≡
        evaluate C (RingHom.hom ι) p (coordinates (points cone i))
    evaluate-inclusion cone i p =
      trans (evaluate-substitute C (RingHom.hom ι) (include-variable i) p (combined-coordinates cone))
        (evaluate-cong C (RingHom.hom ι) p
          (λ j → assemble-inject variable-sizes (λ l → coordinates (points cone l)) i j))

    combined-satisfies : (cone : SolutionCone) (j : Fin (relations colimit)) →
      evaluate C (RingHom.hom ι) (equations colimit j) (combined-coordinates cone) ≡ 0r
    combined-satisfies cone j with split (total relation-sizes) j
    ... | in-left r with splitIndex relation-sizes r
    ... | i , j = trans (evaluate-inclusion cone i (equations (B i) j)) (satisfies (points cone i) j)
    combined-satisfies cone j | in-right r with splitIndex arrow-sizes r
    ... | e , i =
      trans (cong₂ _+_
        (assemble-inject variable-sizes (λ l → coordinates (points cone l)) (source e) i)
        (cong -_ (evaluate-inclusion cone (target e) (images (arrow e) i))))
        (trans (cong (_+ (- evaluate C (RingHom.hom ι) (images (arrow e) i) (coordinates (points cone (target e)))))
          (compatible cone e i)) (+-inverseʳ _))

    assemble-solution : SolutionCone → Spec C (RingHom.hom ι) colimit
    coordinates (assemble-solution cone) = combined-coordinates cone
    satisfies (assemble-solution cone) = combined-satisfies cone

    restrict-assemble : (cone : SolutionCone) → restrict-solution (assemble-solution cone) ≡ cone
    restrict-assemble cone = solution-cone-path
      (λ i j → assemble-inject variable-sizes (λ l → coordinates (points cone l)) i j)

    assemble-after-restrict : (x : Spec C (RingHom.hom ι) colimit) → assemble-solution (restrict-solution x) ≡ x
    assemble-after-restrict x = spec-path ext0 setC (assemble-restrict-coordinates x)
      where
      assemble-restrict-coordinates : (x : Spec C (RingHom.hom ι) colimit) (j : Fin (generators colimit)) →
        coordinates (assemble-solution (restrict-solution x)) j ≡ coordinates x j
      assemble-restrict-coordinates x = SDG.Schemes.FiniteBlocks.assemble-restrict variable-sizes (coordinates x)

    spec-colimit-isomorphism : Isomorphism (Spec C (RingHom.hom ι) colimit) SolutionCone
    spec-colimit-isomorphism = isomorphism restrict-solution assemble-solution assemble-after-restrict restrict-assemble
