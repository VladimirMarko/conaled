{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section15 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Module
open import SDG.Axiom
open import SDG.Order
open import SDG.Finite using (Vec; []; _∷_; Fin; fzero; fsuc; lookup; delete)
open import SDG.Forms.Basic
import SDG.Forms.SignedSums as SS
import SDG.Integration.Boxes as IB
import SDG.ChapterI.Section05Vector as V5
import SDG.ChapterI.Section07Linear as S7L
import SDG.ChapterI.Section13 as S13
import SDG.ChapterI.Section14Exterior as S14

module Stokes {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O)
  (ext0 : FunExt lzero ℓ) (ext : FunExt ℓ ℓ) (setR : isSet (CRing.R A)) where
  open IB.Boxes A K O J public
  open Infinitesimals A
  open Cubes A
  open ModuleForms A (scalarModule A) public
  module Sum = SS.Sums A (scalarModule A)
  module E = S14.Cubical A (scalarModule A) (S7L.scalar-vectorKL A K) ext
  module C = E.Native ext0 setR
  open C public using
    (Current; integrate; additive; homogeneous-current; current-ext; pushforward; rectangle;
     add-current; scale-current; negate-current; currentBoundary)

  integral-sum : {n m : ℕ} (ss : Box n) (f : Fin m → Point ss → R) →
    integralBox ss (λ xs → Sum.sum (λ i → f i xs)) ≡ Sum.sum (λ i → integralBox ss (f i))
  integral-sum {m = zero} ss f = integral-of-zero ss
  integral-sum {m = suc m} ss f = trans
    (integral-additivity ss (f fzero) (λ xs → Sum.sum (λ i → f (fsuc i) xs)))
    (cong (integralBox ss (f fzero) +_) (integral-sum ss (f ∘ fsuc)))

  integral-signed-sum : {n m : ℕ} (ss : Box n) (f : Fin m → Point ss → R) →
    integralBox ss (λ xs → Sum.signedSum (λ i → f i xs)) ≡ Sum.signedSum (λ i → integralBox ss (f i))
  integral-signed-sum ss f = trans (integral-sum ss (λ i xs → Sum.indexSign i * f i xs))
    (Sum.sum-cong (λ i → integral-scaling ss (Sum.indexSign i) (f i)))

  density : {n : ℕ} {ss : Box n} → Form n (Point ss) → Point ss → R
  density ω xs = evaluate ω (canonicalCube xs)

  -- The canonical current (15.2), with precisely the source's iterated
  -- integral order and a genuine R-linear functional on native forms.
  canonicalCurrent : {n : ℕ} (ss : Box n) → Current n (Point ss)
  integrate (canonicalCurrent ss) ω = integralBox ss (density ω)
  additive (canonicalCurrent ss) ω θ = integral-additivity ss (density ω) (density θ)
  homogeneous-current (canonicalCurrent ss) r ω = integral-scaling ss r (density ω)

  faceTrace : {n : ℕ} (ss : Box (suc n)) → Form n (Point ss) → (i : Fin (suc n)) →
    Point (delete ss i) → Carrier (lookup ss i) → R
  faceTrace ss θ i xs x = evaluate θ (map-cube (insertPoint ss i x) (canonicalCube xs))

  faceCurrent : {n : ℕ} (ss : Box (suc n)) (i : Fin (suc n)) → Carrier (lookup ss i) → Current n (Point ss)
  faceCurrent ss i x = pushforward (insertPoint ss i x) (canonicalCurrent (delete ss i))

  -- An independently defined signed sum of the 2(n+1) pushed-forward
  -- ordinary box currents. This is the geometric, not definitional,
  -- boundary appearing on the right hand side of Stokes' theorem.
  boxBoundary : {n : ℕ} (ss : Box (suc n)) → Current n (Point ss)
  boxBoundary {n} ss = C.CurrentSums.signedSum n (Point ss) (λ i →
    add-current (faceCurrent ss i (Line.right (lookup ss i)))
      (negate-current (faceCurrent ss i (Line.left (lookup ss i)))))

  box-boundary-evaluation : {n : ℕ} (ss : Box (suc n)) (θ : Form n (Point ss)) →
    integrate (boxBoundary ss) θ ≡ Sum.signedSum (λ i →
      integralBox (delete ss i) (λ xs → faceTrace ss θ i xs (Line.right (lookup ss i))) -
      integralBox (delete ss i) (λ xs → faceTrace ss θ i xs (Line.left (lookup ss i))))
  box-boundary-evaluation ss θ = C.signed-evaluation
    (λ i → add-current (faceCurrent ss i (Line.right (lookup ss i)))
      (negate-current (faceCurrent ss i (Line.left (lookup ss i))))) θ

  face-slope-coordinate : {n : ℕ} (ss : Box (suc n)) (θ : Form n (Point ss)) (xs : Point ss) (i : Fin (suc n)) →
    E.faceSlope θ (canonicalCube xs) i ≡ sectionDerivative ss i (faceTrace ss θ i) xs
  face-slope-coordinate ss θ xs i =
    V5.VectorCalculus.slope-cong A (scalarModule A) (S7L.scalar-vectorKL A K)
      (E.faceCurve θ (canonicalCube xs) i)
      (λ d → faceTrace ss θ i (deletePoint ss xs i) (shift (lookupPoint ss xs i) d))
      (λ d → cong (evaluate θ) (ext (λ ds → canonical-face ss xs i d ds)))

  -- Theorem I.15.1 in every finite dimension, not merely the n=2 case
  -- worked in the text. Each term is the one-coordinate FTC, after
  -- moving the derivative through preceding integrals.
  stokes-pairing : {n : ℕ} (ss : Box (suc n)) (θ : Form n (Point ss)) →
    integrate (canonicalCurrent ss) (E.exterior θ) ≡ integrate (boxBoundary ss) θ
  stokes-pairing ss θ = trans (integral-signed-sum ss (λ i xs → E.faceSlope θ (canonicalCube xs) i))
    (trans (Sum.signed-cong (λ i →
      trans (integral-congruence ss _ (sectionDerivative ss i (faceTrace ss θ i))
        (λ xs → face-slope-coordinate ss θ xs i))
        (trans (coordinate-fundamental-theorem ss i (faceTrace ss θ i))
          (integral-difference (delete ss i)
            (λ xs → faceTrace ss θ i xs (Line.right (lookup ss i)))
            (λ xs → faceTrace ss θ i xs (Line.left (lookup ss i)))))))
      (sym (box-boundary-evaluation ss θ)))

  stokes : {n : ℕ} (ss : Box (suc n)) → currentBoundary (canonicalCurrent ss) ≡ boxBoundary ss
  stokes ss = current-ext (stokes-pairing ss)

  singularCurrent : {n : ℕ} {M : Set ℓ} → (Point (unitBox n) → M) → Current n M
  singularCurrent {n} f = pushforward f (canonicalCurrent (unitBox n))

  singularBoundary : {n : ℕ} {M : Set ℓ} → (Point (unitBox (suc n)) → M) → Current n M
  singularBoundary {n} f = pushforward f (boxBoundary (unitBox (suc n)))

  singular-stokes : {n : ℕ} {M : Set ℓ} (f : Point (unitBox (suc n)) → M) →
    currentBoundary (singularCurrent f) ≡ singularBoundary f
  singular-stokes {n} f = trans (C.boundary-natural f (canonicalCurrent (unitBox (suc n))))
    (cong (pushforward f) (stokes (unitBox (suc n))))

  -- Corollary I.15.2 for arbitrary singular cubes and arbitrary targets M.
  singular-stokes-pairing : {n : ℕ} {M : Set ℓ} (f : Point (unitBox (suc n)) → M) (θ : Form n M) →
    integrate (singularCurrent f) (E.exterior θ) ≡ integrate (singularBoundary f) θ
  singular-stokes-pairing f θ = cong (λ γ → integrate γ θ) (singular-stokes f)

  smallBox : {n : ℕ} → Vec R n → Vec D n → Box n
  smallBox [] [] = []
  smallBox (a ∷ as) (d ∷ ds) = smallSegment a d ∷ smallBox as ds

  lowerCorner : {n : ℕ} (as : Vec R n) (ds : Vec D n) → Point (smallBox as ds)
  lowerCorner [] [] = point0
  lowerCorner (a ∷ as) (d ∷ ds) = Line.left (smallSegment a d) ∷p lowerCorner as ds

  infinitesimal-box-integral : {n : ℕ} (as : Vec R n) (ds : Vec D n) (f : Point (smallBox as ds) → R) →
    integralBox (smallBox as ds) f ≡ productD ds * f (lowerCorner as ds)
  infinitesimal-box-integral [] [] f = sym (*-identityˡ (f point0))
  infinitesimal-box-integral (a ∷ as) (d ∷ ds) f =
    trans (integral-congruence (smallBox as ds) _ _ (λ xs → infinitesimal-integral a d (λ x → f (x ∷p xs))))
      (trans (integral-scaling (smallBox as ds) (value d) (λ xs → f (Line.left (smallSegment a d) ∷p xs)))
        (trans (cong (value d *_) (infinitesimal-box-integral as ds (λ xs → f (Line.left (smallSegment a d) ∷p xs))))
          (sym (*-assoc (value d) (productD ds) (f (lowerCorner (a ∷ as) (d ∷ ds)))))))

  -- The equality of infinitesimal ordinary boxes and infinitesimal
  -- rectangle currents used in the source proof is also established.
  infinitesimal-box-current : {n : ℕ} (as : Vec R n) (ds : Vec D n) →
    canonicalCurrent (smallBox as ds) ≡ rectangle (canonicalCube (lowerCorner as ds)) ds
  infinitesimal-box-current as ds = current-ext (λ ω → infinitesimal-box-integral as ds (density ω))

  infinitesimal-box-boundary : {n : ℕ} (as : Vec R (suc n)) (ds : Vec D (suc n)) →
    boxBoundary (smallBox as ds) ≡ C.geometricBoundary (canonicalCube (lowerCorner as ds)) ds
  infinitesimal-box-boundary as ds = trans (sym (stokes (smallBox as ds)))
    (trans (cong currentBoundary (infinitesimal-box-current as ds))
      (C.infinitesimal-current-stokes (canonicalCube (lowerCorner as ds)) ds))
