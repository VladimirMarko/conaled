{-# OPTIONS --safe --without-K #-}
module SDG.Forms.Axes where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; FinComparison; same; different; compareFin;
  Vec; []; _∷_; lookup; update; lookup-update-same; lookup-update-other;
  update-identity; update-overwrite; update-commute; replicate; lookup-replicate;
  tabulate; lookup-tabulate; vec-ext; Permutation; to; from; from-to; to-from;
  permute; lookup-permute; inversePerm)
open import SDG.Forms.Basic
import SDG.Forms.TangentTuples as TT
import SDG.Combinatorics.SignatureCofactor as SC
import SDG.ChapterI.Section07 as S7

module CoordinateAxes {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR hiding (axes)
  open Cubes A

  zeros : {n : ℕ} → Vec D n
  zeros = replicate zeroD

  axisD : {n : ℕ} → Fin n → D → Vec D n
  axisD i d = update zeros i d

  axis-zero : {n : ℕ} (i : Fin n) → axisD i zeroD ≡ zeros
  axis-zero i = trans (cong (update zeros i) (sym (lookup-replicate zeroD i))) (update-identity zeros i)

  axis-own : {n : ℕ} (i : Fin n) (d : D) → lookup (axisD i d) i ≡ d
  axis-own i d = lookup-update-same zeros i d

  axis-other : {n : ℕ} (i j : Fin n) → i ≢ j → (d : D) → lookup (axisD i d) j ≡ zeroD
  axis-other i j ne d = trans (lookup-update-other zeros i j d (λ p → ⊥-elim (ne p))) (lookup-replicate zeroD j)

  scale-zeros : {n : ℕ} (i : Fin n) (r : R) → scale-coordinates zeros i r ≡ zeros
  scale-zeros i r = trans
    (cong (update zeros i) (trans (cong (λ d → scaleD d r) (lookup-replicate zeroD i)) (scale-zero r)))
    (axis-zero i)

  scale-axis-own : {n : ℕ} (i : Fin n) (r : R) (d : D) →
    scale-coordinates (axisD i d) i r ≡ axisD i (scaleD d r)
  scale-axis-own i r d = trans
    (cong (λ e → update (axisD i d) i (scaleD e r)) (axis-own i d))
    (update-overwrite zeros i d (scaleD d r))

  scale-axis-other : {n : ℕ} (i j : Fin n) → i ≢ j → (r : R) (d : D) →
    scale-coordinates (axisD i d) j r ≡ axisD i d
  scale-axis-other i j ne r d = trans
    (cong (update (axisD i d) j) (trans (cong (λ e → scaleD e r) (axis-other i j ne d)) (scale-zero r)))
    (trans (update-commute zeros i j d zeroD (λ p → ⊥-elim (ne p))) (cong (λ ds → update ds i d) (axis-zero j)))

  permute-zeros : {n : ℕ} (p : Permutation n) → permute p zeros ≡ zeros
  permute-zeros p = vec-ext (λ i → trans (lookup-permute p zeros i)
    (trans (lookup-replicate zeroD (to p i)) (sym (lookup-replicate zeroD i))))

  permute-axis : {n : ℕ} (p : Permutation n) (i : Fin n) (d : D) →
    permute p (axisD i d) ≡ axisD (from p i) d
  permute-axis p i d = vec-ext coordinate
    where
    coordinate : (j : Fin _) → lookup (permute p (axisD i d)) j ≡ lookup (axisD (from p i) d) j
    coordinate j with compareFin (from p i) j
    ... | same = trans (lookup-permute p (axisD i d) (from p i))
      (trans (cong (lookup (axisD i d)) (to-from p i))
        (trans (axis-own i d) (sym (axis-own (from p i) d))))
    ... | different ne = trans (lookup-permute p (axisD i d) j)
      (trans (axis-other i (to p j) (λ eq → fin-empty (ne (trans (cong (from p) eq) (from-to p j)))) d)
        (sym (axis-other (from p i) j (λ eq → fin-empty (ne eq)) d)))
      where
      fin-empty : Fin zero → ⊥
      fin-empty ()

  axis-tangent : {n : ℕ} {M : Set ℓ} (τ : Cube n M) → Fin n → Tangent M (τ zeros)
  axis-tangent τ i = tangent (λ d → τ (axisD i d)) (cong τ (axis-zero i))

  axes : {n : ℕ} {M : Set ℓ} (τ : Cube n M) → Vec (Tangent M (τ zeros)) n
  axes τ = tabulate (axis-tangent τ)

  axis-curve : {n : ℕ} {M : Set ℓ} (τ : Cube n M) (i : Fin n) (d : D) →
    curve (lookup (axes τ) i) d ≡ τ (axisD i d)
  axis-curve τ i d = cong (λ t → curve t d) (lookup-tabulate (axis-tangent τ) i)

module Comparison {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  {V : Set ℓ} (action : ScalarAction A V) (ext : FunExt ℓ ℓ)
  (M : Set ℓ) (setM : isSet M) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR hiding (axes)
  open Cubes A
  open CoordinateAxes A setR
  open TT.Tuples A setR
  module T = TT.Definitions A setR action
  module C = Definitions A action

  evaluate-cong : {n : ℕ} (ω : T.TupleForm n M) {x y : M}
    {ts : Vec (Tangent M x) n} {us : Vec (Tangent M y) n} → x ≡ y →
    ((i : Fin n) (d : D) → curve (lookup ts i) d ≡ curve (lookup us i) d) → T.evaluate ω x ts ≡ T.evaluate ω y us
  evaluate-cong ω refl q = cong (T.evaluate ω _) (vec-ext (λ i → tangent-ext ext setM (q i)))

  scaling-axes : {n : ℕ} (τ : Cube n M) (j : Fin n) (r : R) (i : Fin n) (d : D) →
    curve (lookup (axes (scale-cube τ j r)) i) d ≡ curve (lookup (scale-tuple (axes τ) j r) i) d
  scaling-axes τ j r i d with compareFin j i
  ... | same = trans (axis-curve (scale-cube τ j r) j d)
    (trans (cong τ (scale-axis-own j r d))
      (sym (trans (cong (λ t → curve t d) (lookup-update-same (axes τ) j (speed r (lookup (axes τ) j))))
        (axis-curve τ j (scaleD d r)))))
  ... | different ne = trans (axis-curve (scale-cube τ j r) i d)
    (trans (cong τ (scale-axis-other i j (λ p → fin-empty (ne (sym p))) r d))
      (sym (trans (cong (λ t → curve t d)
        (lookup-update-other (axes τ) j i (speed r (lookup (axes τ) j)) ne))
        (axis-curve τ i d))))
    where
    fin-empty : Fin zero → ⊥
    fin-empty ()

  permutation-axes : {n : ℕ} (τ : Cube n M) (p : Permutation n) (i : Fin n) (d : D) →
    curve (lookup (axes (permute-cube τ p)) i) d ≡ curve (lookup (permute (inversePerm p) (axes τ)) i) d
  permutation-axes τ p i d = trans (axis-curve (permute-cube τ p) i d)
    (trans (cong τ (permute-axis p i d))
      (sym (trans (cong (λ t → curve t d) (lookup-permute (inversePerm p) (axes τ) i))
        (axis-curve τ (from p i) d))))

  -- The canonical map from tangent-tuple forms to cubical forms is defined
  -- by restricting a cube to its axes. No surjectivity is assumed.
  cubical : {n : ℕ} → T.TupleForm n M → C.Form n M
  C.evaluate (cubical ω) τ = T.evaluate ω (τ zeros) (axes τ)
  C.homogeneous (cubical ω) τ i r = trans
    (evaluate-cong ω (cong τ (scale-zeros i r)) (scaling-axes τ i r))
    (T.homogeneous ω (τ zeros) (axes τ) i r)
  C.alternating (cubical ω) τ p = trans
    (evaluate-cong ω (cong τ (permute-zeros p)) (permutation-axes τ p))
    (trans (T.alternating ω (τ zeros) (axes τ) (inversePerm p))
      (cong (λ s → ScalarAction.act action s (T.evaluate ω (τ zeros) (axes τ))) (SC.Cofactor.signature-inverse A p)))
