{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.TruncatedPolynomials where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Algebra.Powers using (module PowerLemmas)
open import SDG.Setness using (function-isSet; module Retractions)
open import SDG.Algebra.DualNumbers using (RingHom)
open import SDG.Algebra.Algebras using
  (RAlgebra; algebra; AlgHom; algebra-hom; scalarAlgebra; algMap; ringHom; commutes; algHom-ext)
open import SDG.Finite using
  (Vec; []; _∷_; head; tail; initial; snoc; last; replicate; map; zipWith;
   Fin; fzero; fsuc; lookup; tabulate; tabulate-lookup; vec-ext; initial-snoc; snoc-initial-last)

-- Coefficients are in ascending degree. There are n coefficients, so
-- this is the concrete algebra A[t]/(t^n), including the trivial n=0 case.
-- Multiplication is finite Horner convolution; no quotient is postulated.
module Polynomials {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A
  open PowerLemmas A using (_^_; power-one)

  Poly : ℕ → Set ℓ
  Poly n = Vec R n

  poly-isSet : FunExt lzero ℓ → isSet R → (n : ℕ) → isSet (Poly n)
  poly-isSet ext setR n = Retractions.retraction-isSet lookup tabulate tabulate-lookup
    (function-isSet ext setR)

  zeroP : {n : ℕ} → Poly n
  zeroP = replicate 0r

  add : {n : ℕ} → Poly n → Poly n → Poly n
  add = zipWith _+_

  neg : {n : ℕ} → Poly n → Poly n
  neg = map (-_)

  scale : {n : ℕ} → R → Poly n → Poly n
  scale r = map (r *_)

  constant : (n : ℕ) → R → Poly n
  constant zero a = []
  constant (suc n) a = a ∷ zeroP

  raise : {n : ℕ} → Poly n → Poly (suc n)
  raise p = 0r ∷ p

  mul : {n : ℕ} → Poly n → Poly n → Poly n
  mul [] [] = []
  mul (a ∷ as) bs = add (scale a bs) (raise (mul as (initial bs)))

  abstract
    add-assoc : {n : ℕ} (p q r : Poly n) → add (add p q) r ≡ add p (add q r)
    add-assoc [] [] [] = refl
    add-assoc (a ∷ as) (b ∷ bs) (c ∷ cs) =
      cong₂ _∷_ (+-assoc a b c) (add-assoc as bs cs)

    add-comm : {n : ℕ} (p q : Poly n) → add p q ≡ add q p
    add-comm [] [] = refl
    add-comm (a ∷ as) (b ∷ bs) = cong₂ _∷_ (+-comm a b) (add-comm as bs)

    add-zeroˡ : {n : ℕ} (p : Poly n) → add zeroP p ≡ p
    add-zeroˡ [] = refl
    add-zeroˡ (a ∷ as) = cong₂ _∷_ (+-identityˡ a) (add-zeroˡ as)

    add-zeroʳ : {n : ℕ} (p : Poly n) → add p zeroP ≡ p
    add-zeroʳ p = trans (add-comm p zeroP) (add-zeroˡ p)

    add-inverseˡ : {n : ℕ} (p : Poly n) → add (neg p) p ≡ zeroP
    add-inverseˡ [] = refl
    add-inverseˡ (a ∷ as) = cong₂ _∷_ (+-inverseˡ a) (add-inverseˡ as)

    add-inverseʳ : {n : ℕ} (p : Poly n) → add p (neg p) ≡ zeroP
    add-inverseʳ p = trans (add-comm p (neg p)) (add-inverseˡ p)

    add-shuffle : {n : ℕ} (p q r s : Poly n) →
      add (add p q) (add r s) ≡ add (add p r) (add q s)
    add-shuffle [] [] [] [] = refl
    add-shuffle (a ∷ as) (b ∷ bs) (c ∷ cs) (d ∷ ds) =
      cong₂ _∷_ (+-shuffle a b c d) (add-shuffle as bs cs ds)

    scale-zero : {n : ℕ} (p : Poly n) → scale 0r p ≡ zeroP
    scale-zero [] = refl
    scale-zero (a ∷ as) = cong₂ _∷_ (*-zeroˡ a) (scale-zero as)

    scale-zeroP : (n : ℕ) (r : R) → scale r (zeroP {n}) ≡ zeroP
    scale-zeroP zero r = refl
    scale-zeroP (suc n) r = cong₂ _∷_ (*-zeroʳ r) (scale-zeroP n r)

    scale-one : {n : ℕ} (p : Poly n) → scale 1r p ≡ p
    scale-one [] = refl
    scale-one (a ∷ as) = cong₂ _∷_ (*-identityˡ a) (scale-one as)

    scale-assoc : {n : ℕ} (r s : R) (p : Poly n) → scale (r * s) p ≡ scale r (scale s p)
    scale-assoc r s [] = refl
    scale-assoc r s (a ∷ as) = cong₂ _∷_ (*-assoc r s a) (scale-assoc r s as)

    scale-add : {n : ℕ} (r s : R) (p : Poly n) → scale (r + s) p ≡ add (scale r p) (scale s p)
    scale-add r s [] = refl
    scale-add r s (a ∷ as) = cong₂ _∷_ (distribʳ r s a) (scale-add r s as)

    scale-distrib : {n : ℕ} (r : R) (p q : Poly n) → scale r (add p q) ≡ add (scale r p) (scale r q)
    scale-distrib r [] [] = refl
    scale-distrib r (a ∷ as) (b ∷ bs) = cong₂ _∷_ (distribˡ r a b) (scale-distrib r as bs)

    scale-raise : {n : ℕ} (r : R) (p : Poly n) → scale r (raise p) ≡ raise (scale r p)
    scale-raise r p = cong (_∷ scale r p) (*-zeroʳ r)

    raise-add : {n : ℕ} (p q : Poly n) → raise (add p q) ≡ add (raise p) (raise q)
    raise-add p q = cong (_∷ add p q) (sym (+-identityˡ 0r))

    cut-add : {n : ℕ} (p q : Poly (suc n)) → initial (add p q) ≡ add (initial p) (initial q)
    cut-add (a ∷ []) (b ∷ []) = refl
    cut-add (a ∷ b ∷ as) (c ∷ d ∷ bs) = cong ((a + c) ∷_) (cut-add (b ∷ as) (d ∷ bs))

    cut-scale : {n : ℕ} (r : R) (p : Poly (suc n)) → initial (scale r p) ≡ scale r (initial p)
    cut-scale r (a ∷ []) = refl
    cut-scale r (a ∷ b ∷ as) = cong ((r * a) ∷_) (cut-scale r (b ∷ as))

    cut-zero : (n : ℕ) → initial (zeroP {suc n}) ≡ zeroP
    cut-zero zero = refl
    cut-zero (suc n) = cong (0r ∷_) (cut-zero n)

    mul-zeroˡ : {n : ℕ} (p : Poly n) → mul zeroP p ≡ zeroP
    mul-zeroˡ [] = refl
    mul-zeroˡ (a ∷ as) =
      trans (cong₂ add (scale-zero (a ∷ as)) (cong raise (mul-zeroˡ (initial (a ∷ as)))))
        (add-zeroˡ zeroP)

    mul-zeroʳ : {n : ℕ} (p : Poly n) → mul p zeroP ≡ zeroP
    mul-zeroʳ [] = refl
    mul-zeroʳ {suc n} (a ∷ as) =
      trans (cong₂ add (scale-zeroP (suc n) a)
        (cong raise (trans (cong (mul as) (cut-zero n)) (mul-zeroʳ as))))
        (add-zeroˡ zeroP)

    mul-raiseˡ : {n : ℕ} (p : Poly n) (q : Poly (suc n)) →
      mul (raise p) q ≡ raise (mul p (initial q))
    mul-raiseˡ p q = trans (cong (λ z → add z (raise (mul p (initial q)))) (scale-zero q))
      (add-zeroˡ (raise (mul p (initial q))))

    mul-distribˡ : {n : ℕ} (p q r : Poly n) → mul p (add q r) ≡ add (mul p q) (mul p r)
    mul-distribˡ [] [] [] = refl
    mul-distribˡ (a ∷ as) q r =
      trans (cong₂ add (scale-distrib a q r)
        (cong raise (trans (cong (mul as) (cut-add q r))
          (mul-distribˡ as (initial q) (initial r)))))
        (trans (cong (add (add (scale a q) (scale a r)))
          (raise-add (mul as (initial q)) (mul as (initial r))))
          (add-shuffle (scale a q) (scale a r)
            (raise (mul as (initial q))) (raise (mul as (initial r)))))

    mul-distribʳ : {n : ℕ} (p q r : Poly n) → mul (add p q) r ≡ add (mul p r) (mul q r)
    mul-distribʳ [] [] [] = refl
    mul-distribʳ (a ∷ as) (b ∷ bs) r =
      trans (cong₂ add (scale-add a b r)
        (cong raise (mul-distribʳ as bs (initial r))))
        (trans (cong (add (add (scale a r) (scale b r)))
          (raise-add (mul as (initial r)) (mul bs (initial r))))
          (add-shuffle (scale a r) (scale b r)
            (raise (mul as (initial r))) (raise (mul bs (initial r)))))

    mul-scaleˡ : {n : ℕ} (r : R) (p q : Poly n) → mul (scale r p) q ≡ scale r (mul p q)
    mul-scaleˡ r [] [] = refl
    mul-scaleˡ r (a ∷ as) q =
      trans (cong₂ add (scale-assoc r a q)
        (trans (cong raise (mul-scaleˡ r as (initial q)))
          (sym (scale-raise r (mul as (initial q))))))
        (sym (scale-distrib r (scale a q) (raise (mul as (initial q)))))

    cut-mul : {n : ℕ} (p q : Poly (suc n)) → initial (mul p q) ≡ mul (initial p) (initial q)
    cut-mul (a ∷ []) (b ∷ []) = refl
    cut-mul (a ∷ b ∷ as) (c ∷ d ∷ bs) =
      trans (cut-add (scale a (c ∷ d ∷ bs)) (raise (mul (b ∷ as) (initial (c ∷ d ∷ bs)))))
        (cong₂ add (cut-scale a (c ∷ d ∷ bs))
          (cong raise (cut-mul (b ∷ as) (initial (c ∷ d ∷ bs)))))

    mul-assoc : {n : ℕ} (p q r : Poly n) → mul (mul p q) r ≡ mul p (mul q r)
    mul-assoc [] [] [] = refl
    mul-assoc (a ∷ as) q r =
      trans (mul-distribʳ (scale a q) (raise (mul as (initial q))) r)
        (trans (cong₂ add (mul-scaleˡ a q r) (mul-raiseˡ (mul as (initial q)) r))
          (cong (add (scale a (mul q r))) (cong raise
            (trans (mul-assoc as (initial q) (initial r))
              (cong (mul as) (sym (cut-mul q r)))))))

    combine-constant : {n : ℕ} (a : R) (p : Poly n) →
      add (constant (suc n) a) (raise p) ≡ a ∷ p
    combine-constant a p = cong₂ _∷_ (+-identityʳ a) (add-zeroˡ p)

    cut-constant : (n : ℕ) (a : R) → initial (constant (suc n) a) ≡ constant n a
    cut-constant zero a = refl
    cut-constant (suc n) a = cong (a ∷_) (cut-zero n)

    scale-constant : (n : ℕ) (r a : R) → scale r (constant n a) ≡ constant n (r * a)
    scale-constant zero r a = refl
    scale-constant (suc n) r a = cong ((r * a) ∷_) (scale-zeroP n r)

    mul-constantˡ : {n : ℕ} (r : R) (p : Poly n) → mul (constant n r) p ≡ scale r p
    mul-constantˡ r [] = refl
    mul-constantˡ r (a ∷ as) =
      trans (cong (add (scale r (a ∷ as))) (cong raise (mul-zeroˡ (initial (a ∷ as)))))
        (add-zeroʳ (scale r (a ∷ as)))

    mul-constantʳ : {n : ℕ} (p : Poly n) (r : R) → mul p (constant n r) ≡ scale r p
    mul-constantʳ [] r = refl
    mul-constantʳ {suc n} (a ∷ as) r =
      trans (cong₂ add (scale-constant (suc n) a r)
        (cong raise (trans (cong (mul as) (cut-constant n r)) (mul-constantʳ as r))))
        (trans (combine-constant (a * r) (scale r as)) (cong (_∷ scale r as) (*-comm a r)))

    mul-raiseʳ : {n : ℕ} (p : Poly (suc n)) (q : Poly n) →
      mul p (raise q) ≡ raise (mul (initial p) q)
    mul-raiseʳ (a ∷ []) [] = cong (_∷ [])
      (trans (cong (_+ 0r) (*-zeroʳ a)) (+-identityˡ 0r))
    mul-raiseʳ {suc n} (a ∷ as) q =
      trans (cong₂ add (scale-raise a q)
        (cong raise (mul-raiseʳ as (initial q))))
        (cong (_∷ add (scale a q) (raise (mul (initial as) (initial q)))) (+-identityˡ 0r))

    mul-comm : {n : ℕ} (p q : Poly n) → mul p q ≡ mul q p
    mul-comm [] [] = refl
    mul-comm {suc n} (a ∷ as) q =
      trans (cong (add (scale a q)) (cong raise (mul-comm as (initial q))))
        (trans (cong₂ add (sym (mul-constantʳ q a)) (sym (mul-raiseʳ q as)))
          (trans (sym (mul-distribˡ q (constant (suc n) a) (raise as)))
            (cong (mul q) (combine-constant a as))))

    mul-oneˡ : {n : ℕ} (p : Poly n) → mul (constant n 1r) p ≡ p
    mul-oneˡ p = trans (mul-constantˡ 1r p) (scale-one p)

    mul-oneʳ : {n : ℕ} (p : Poly n) → mul p (constant n 1r) ≡ p
    mul-oneʳ p = trans (mul-constantʳ p 1r) (scale-one p)

  truncatedRing : (n : ℕ) → CRing ℓ
  truncatedRing n = record
    { R = Poly n; 0r = zeroP; 1r = constant n 1r
    ; _+_ = add; _*_ = mul; -_ = neg
    ; +-assoc = add-assoc; +-comm = add-comm
    ; +-identityˡ = add-zeroˡ; +-identityʳ = add-zeroʳ
    ; +-inverseˡ = add-inverseˡ; +-inverseʳ = add-inverseʳ
    ; *-assoc = mul-assoc; *-comm = mul-comm
    ; *-identityˡ = mul-oneˡ; *-identityʳ = mul-oneʳ
    ; distribˡ = mul-distribˡ; distribʳ = mul-distribʳ }

  abstract
    constant-zero : (n : ℕ) → constant n 0r ≡ zeroP
    constant-zero zero = refl
    constant-zero (suc n) = refl

    constant-add : (n : ℕ) (r s : R) → constant n (r + s) ≡ add (constant n r) (constant n s)
    constant-add zero r s = refl
    constant-add (suc n) r s = cong ((r + s) ∷_) (sym (add-zeroˡ zeroP))

    constant-neg : (n : ℕ) (r : R) → constant n (- r) ≡ neg (constant n r)
    constant-neg zero r = refl
    constant-neg (suc n) r = cong ((- r) ∷_) (zero-neg n)
      where
      zero-neg : (n : ℕ) → zeroP {n} ≡ neg zeroP
      zero-neg zero = refl
      zero-neg (suc n) = cong₂ _∷_ (sym neg-zero) (zero-neg n)

    constant-mul : (n : ℕ) (r s : R) → constant n (r * s) ≡ mul (constant n r) (constant n s)
    constant-mul n r s = sym (trans (mul-constantˡ r (constant n s)) (scale-constant n r s))

  constantHom : (n : ℕ) → RingHom A (truncatedRing n)
  constantHom n = record
    { hom = constant n; pres-0 = constant-zero n; pres-1 = refl
    ; pres-+ = constant-add n; pres-* = constant-mul n; pres-neg = constant-neg n }

  truncatedAlgebra : (n : ℕ) → RAlgebra A ℓ
  truncatedAlgebra n = algebra (truncatedRing n) (constantHom n)

  epsilon : (n : ℕ) → Poly n
  epsilon zero = []
  epsilon (suc n) = raise (constant n 1r)

  power : {n : ℕ} → Poly n → ℕ → Poly n
  power {n} p zero = constant n 1r
  power p (suc k) = mul p (power p k)

  abstract
    epsilon-mul : {n : ℕ} (p : Poly (suc n)) →
      mul (epsilon (suc n)) p ≡ raise (initial p)
    epsilon-mul {n} p = trans (mul-raiseˡ (constant n 1r) p) (cong raise (mul-oneˡ (initial p)))

    cut-epsilon : (n : ℕ) → initial (epsilon (suc n)) ≡ epsilon n
    cut-epsilon zero = refl
    cut-epsilon (suc n) = cong raise (cut-constant n 1r)

    cut-power : {n : ℕ} (p : Poly (suc n)) (k : ℕ) →
      initial (power p k) ≡ power (initial p) k
    cut-power {n} p zero = cut-constant n 1r
    cut-power p (suc k) = trans (cut-mul p (power p k)) (cong (mul (initial p)) (cut-power p k))

    epsilon-step : (n k : ℕ) → power (epsilon (suc n)) (suc k) ≡ raise (power (epsilon n) k)
    epsilon-step n k = trans (epsilon-mul (power (epsilon (suc n)) k))
      (cong raise (trans (cut-power (epsilon (suc n)) k)
        (cong (λ q → power q k) (cut-epsilon n))))

    epsilon-nilpotent : (n : ℕ) → power (epsilon n) n ≡ zeroP
    epsilon-nilpotent zero = refl
    epsilon-nilpotent (suc n) = trans (epsilon-step n n) (cong raise (epsilon-nilpotent n))

  -- Interpret an arbitrary finite coefficient vector in a fixed truncation.
  -- This is also a convenient finite expression witnessing generation by t.
  interpret : {k : ℕ} → (n : ℕ) → Poly k → Poly n
  interpret n [] = zeroP
  interpret n (a ∷ as) = add (constant n a) (mul (epsilon n) (interpret n as))

  abstract
    cut-interpret : {k : ℕ} (n : ℕ) (p : Poly k) → initial (interpret (suc n) p) ≡ interpret n p
    cut-interpret n [] = cut-zero n
    cut-interpret n (a ∷ as) =
      trans (cut-add (constant (suc n) a) (mul (epsilon (suc n)) (interpret (suc n) as)))
        (cong₂ add (cut-constant n a)
          (trans (cut-mul (epsilon (suc n)) (interpret (suc n) as))
            (cong₂ mul (cut-epsilon n) (cut-interpret n as))))

    interpret-exact : {n : ℕ} (p : Poly n) → interpret n p ≡ p
    interpret-exact [] = refl
    interpret-exact {suc n} (a ∷ as) =
      trans (cong (add (constant (suc n) a))
        (trans (epsilon-mul (interpret (suc n) as))
          (cong raise (trans (cut-interpret n as) (interpret-exact as)))))
        (combine-constant a as)

    generated-interpret : {n k : ℕ} (F G : AlgHom (truncatedAlgebra n) (truncatedAlgebra n)) →
      algMap F (epsilon n) ≡ algMap G (epsilon n) → (p : Poly k) →
      algMap F (interpret n p) ≡ algMap G (interpret n p)
    generated-interpret F G ep [] =
      trans (RingHom.pres-0 (ringHom F)) (sym (RingHom.pres-0 (ringHom G)))
    generated-interpret {n} F G ep (a ∷ as) =
      trans (RingHom.pres-+ (ringHom F) (constant n a) (mul (epsilon n) (interpret n as)))
        (trans (cong₂ add (trans (commutes F a) (sym (commutes G a)))
          (trans (RingHom.pres-* (ringHom F) (epsilon n) (interpret n as))
            (trans (cong₂ mul ep (generated-interpret F G ep as))
              (sym (RingHom.pres-* (ringHom G) (epsilon n) (interpret n as))))))
          (sym (RingHom.pres-+ (ringHom G) (constant n a) (mul (epsilon n) (interpret n as)))))

    generated-pointwise : {n : ℕ} (F G : AlgHom (truncatedAlgebra n) (truncatedAlgebra n)) →
      algMap F (epsilon n) ≡ algMap G (epsilon n) → (p : Poly n) → algMap F p ≡ algMap G p
    generated-pointwise F G ep p = trans (cong (algMap F) (sym (interpret-exact p)))
      (trans (generated-interpret F G ep p) (cong (algMap G) (interpret-exact p)))

    generated-native : (ext : FunExt ℓ ℓ) (ext0 : FunExt lzero ℓ) (setR : isSet R) (n : ℕ)
      (F G : AlgHom (truncatedAlgebra n) (truncatedAlgebra n)) →
      algMap F (epsilon n) ≡ algMap G (epsilon n) → F ≡ G
    generated-native ext ext0 setR n F G ep =
      algHom-ext ext ext ext (poly-isSet ext0 setR n) (generated-pointwise F G ep)

    power-agrees : {n : ℕ} (p : Poly n) (k : ℕ) → power p k ≡ PowerLemmas._^_ (truncatedRing n) p k
    power-agrees p zero = refl
    power-agrees p (suc k) = cong (mul p) (power-agrees p k)

    epsilon-nilpotent-native : (n : ℕ) → PowerLemmas._^_ (truncatedRing n) (epsilon n) n ≡ zeroP
    epsilon-nilpotent-native n = trans (sym (power-agrees (epsilon n) n)) (epsilon-nilpotent n)

  evaluate : {n : ℕ} → Poly n → R → R
  evaluate [] x = 0r
  evaluate (a ∷ as) x = a + x * evaluate as x

  abstract
    evaluate-zero : (n : ℕ) (x : R) → evaluate (zeroP {n}) x ≡ 0r
    evaluate-zero zero x = refl
    evaluate-zero (suc n) x =
      trans (cong (λ z → 0r + x * z) (evaluate-zero n x))
        (trans (cong (0r +_) (*-zeroʳ x)) (+-identityˡ 0r))

    evaluate-constant : (n : ℕ) (a x : R) → evaluate (constant (suc n) a) x ≡ a
    evaluate-constant n a x =
      trans (cong (λ z → a + x * z) (evaluate-zero n x))
        (trans (cong (a +_) (*-zeroʳ x)) (+-identityʳ a))

    evaluate-add : {n : ℕ} (p q : Poly n) (x : R) →
      evaluate (add p q) x ≡ evaluate p x + evaluate q x
    evaluate-add [] [] x = sym (+-identityˡ 0r)
    evaluate-add (a ∷ as) (b ∷ bs) x =
      trans (cong (λ z → (a + b) + x * z) (evaluate-add as bs x))
        (trans (cong ((a + b) +_) (distribˡ x (evaluate as x) (evaluate bs x)))
          (+-shuffle a b (x * evaluate as x) (x * evaluate bs x)))

    evaluate-scale : {n : ℕ} (r : R) (p : Poly n) (x : R) → evaluate (scale r p) x ≡ r * evaluate p x
    evaluate-scale r [] x = sym (*-zeroʳ r)
    evaluate-scale r (a ∷ as) x =
      trans (cong (λ z → (r * a) + x * z) (evaluate-scale r as x))
        (trans (cong ((r * a) +_) (*-swap x r (evaluate as x)))
          (sym (distribˡ r a (x * evaluate as x))))

    evaluate-neg : {n : ℕ} (p : Poly n) (x : R) → evaluate (neg p) x ≡ - evaluate p x
    evaluate-neg [] x = sym neg-zero
    evaluate-neg (a ∷ as) x =
      trans (cong (λ z → (- a) + x * z) (evaluate-neg as x))
        (trans (cong ((- a) +_) (neg-mulʳ x (evaluate as x)))
          (sym (neg-add a (x * evaluate as x))))

    evaluate-raise : {n : ℕ} (p : Poly n) (x : R) → evaluate (raise p) x ≡ x * evaluate p x
    evaluate-raise p x = +-identityˡ (x * evaluate p x)

    evaluate-snoc : {n : ℕ} (p : Poly n) (a x : R) →
      evaluate (snoc p a) x ≡ evaluate p x + (x ^ n) * a
    evaluate-snoc [] a x = trans (evaluate-constant zero a x)
      (sym (trans (+-identityˡ (1r * a)) (*-identityˡ a)))
    evaluate-snoc {suc n} (a ∷ as) b x =
      trans (cong (λ z → a + x * z) (evaluate-snoc as b x))
        (trans (cong (a +_) (distribˡ x (evaluate as x) ((x ^ n) * b)))
          (trans (sym (+-assoc a (x * evaluate as x) (x * ((x ^ n) * b))))
            (cong ((a + x * evaluate as x) +_) (sym (*-assoc x (x ^ n) b)))))

    evaluate-cut : {n : ℕ} (p : Poly (suc n)) (x : R) →
      evaluate p x ≡ evaluate (initial p) x + (x ^ n) * last p
    evaluate-cut p x = trans (cong (λ q → evaluate q x) (sym (snoc-initial-last p)))
      (evaluate-snoc (initial p) (last p) x)

    weighted-cut : {n : ℕ} (p : Poly (suc n)) (w x : R) → w * (x ^ n) ≡ 0r →
      w * evaluate p x ≡ w * evaluate (initial p) x
    weighted-cut {n} p w x nil =
      trans (cong (w *_) (evaluate-cut p x))
        (trans (distribˡ w (evaluate (initial p) x) ((x ^ n) * last p))
          (trans (cong ((w * evaluate (initial p) x) +_)
            (trans (sym (*-assoc w (x ^ n) (last p)))
              (trans (cong (_* last p) nil) (*-zeroˡ (last p)))))
            (+-identityʳ (w * evaluate (initial p) x))))

    weighted-horner : (w x a b c : R) →
      w * (a * c) + (w * x) * (b * c) ≡ w * ((a + x * b) * c)
    weighted-horner w x a b c =
      trans (cong ((w * (a * c)) +_) (*-assoc w x (b * c)))
        (trans (sym (distribˡ w (a * c) (x * (b * c))))
          (cong (w *_) (trans (cong ((a * c) +_) (sym (*-assoc x b c)))
            (sym (distribʳ a (x * b) c)))))

    -- The induction keeps the nilpotent weight explicit. Dropping a high
    -- coefficient is justified by this weight, never by a smaller-order
    -- nilpotence hypothesis on x.
    weighted-product : {n : ℕ} (p q : Poly n) (w x : R) → w * (x ^ n) ≡ 0r →
      w * evaluate (mul p q) x ≡ w * (evaluate p x * evaluate q x)
    weighted-product [] [] w x nil = cong (w *_) (sym (*-zeroˡ 0r))
    weighted-product {suc n} (a ∷ as) q w x nil =
      begin
        w * evaluate (mul (a ∷ as) q) x
      ≡⟨ cong (w *_) (trans (evaluate-add (scale a q) (raise (mul as (initial q))) x)
            (cong₂ _+_ (evaluate-scale a q x) (evaluate-raise (mul as (initial q)) x))) ⟩
        w * (a * evaluate q x + x * evaluate (mul as (initial q)) x)
      ≡⟨ distribˡ w (a * evaluate q x) (x * evaluate (mul as (initial q)) x) ⟩
        w * (a * evaluate q x) + w * (x * evaluate (mul as (initial q)) x)
      ≡⟨ cong ((w * (a * evaluate q x)) +_) (sym (*-assoc w x (evaluate (mul as (initial q)) x))) ⟩
        w * (a * evaluate q x) + (w * x) * evaluate (mul as (initial q)) x
      ≡⟨ cong ((w * (a * evaluate q x)) +_) (weighted-product as (initial q) (w * x) x nil-step) ⟩
        w * (a * evaluate q x) + (w * x) * (evaluate as x * evaluate (initial q) x)
      ≡⟨ cong ((w * (a * evaluate q x)) +_)
            (trans (sym (*-assoc (w * x) (evaluate as x) (evaluate (initial q) x)))
              (trans (sym (weighted-cut q ((w * x) * evaluate as x) x nil-tail))
                (*-assoc (w * x) (evaluate as x) (evaluate q x)))) ⟩
        w * (a * evaluate q x) + (w * x) * (evaluate as x * evaluate q x)
      ≡⟨ weighted-horner w x a (evaluate as x) (evaluate q x) ⟩
        w * ((a + x * evaluate as x) * evaluate q x) ∎
      where
      nil-step : (w * x) * (x ^ n) ≡ 0r
      nil-step = trans (*-assoc w x (x ^ n)) nil
      nil-tail : ((w * x) * evaluate as x) * (x ^ n) ≡ 0r
      nil-tail = trans (*-assoc (w * x) (evaluate as x) (x ^ n))
        (trans (cong ((w * x) *_) (*-comm (evaluate as x) (x ^ n)))
          (trans (sym (*-assoc (w * x) (x ^ n) (evaluate as x)))
            (trans (cong (_* evaluate as x) nil-step) (*-zeroˡ (evaluate as x)))))

    evaluate-product : {n : ℕ} (p q : Poly n) (x : R) → x ^ n ≡ 0r →
      evaluate (mul p q) x ≡ evaluate p x * evaluate q x
    evaluate-product {n} p q x nil =
      trans (sym (*-identityˡ (evaluate (mul p q) x)))
        (trans (weighted-product p q 1r x (trans (*-identityˡ (x ^ n)) nil))
          (*-identityˡ (evaluate p x * evaluate q x)))

  evalHom : (k : ℕ) (x : R) → x ^ suc k ≡ 0r → RingHom (truncatedRing (suc k)) A
  evalHom k x nil = record
    { hom = λ p → evaluate p x
    ; pres-0 = evaluate-zero (suc k) x; pres-1 = evaluate-constant k 1r x
    ; pres-+ = λ p q → evaluate-add p q x
    ; pres-* = λ p q → evaluate-product p q x nil
    ; pres-neg = λ p → evaluate-neg p x }

  evalAlgHom : (k : ℕ) (x : R) → x ^ suc k ≡ 0r → AlgHom (truncatedAlgebra (suc k)) (scalarAlgebra A)
  evalAlgHom k x nil = algebra-hom (evalHom k x nil) (λ a → evaluate-constant k a x)

  abstract
    evaluate-epsilon : (k : ℕ) (x : R) → x ^ suc k ≡ 0r → evaluate (epsilon (suc k)) x ≡ x
    evaluate-epsilon zero x nil = trans (evaluate-zero (suc zero) x)
      (sym (trans (sym (power-one x)) nil))
    evaluate-epsilon (suc k) x nil = trans (evaluate-raise (constant (suc k) 1r) x)
      (trans (cong (x *_) (evaluate-constant k 1r x)) (*-identityʳ x))
