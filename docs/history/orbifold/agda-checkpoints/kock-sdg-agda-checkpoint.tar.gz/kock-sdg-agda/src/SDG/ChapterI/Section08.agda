{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08 where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Fin; fzero; fsuc; Vec; []; _∷_)
open import SDG.Infinitesimal.Jets
import SDG.Combinatorics.FiniteSums as FS
import SDG.ChapterI.Section02 as S2
import SDG.ChapterI.Section06 as S6
import SDG.ChapterI.Section07 as S7

module Basics {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open S7.Basics A setR hiding (first; second)

  record VectorField (M : Set ℓ) : Set ℓ where
    constructor vector-field
    field
      run : M → D → M
      run-zero : (m : M) → run m zeroD ≡ m
  open VectorField public

  private
    field-path : (ext : FunExt ℓ ℓ) {M : Set ℓ} → isSet M →
      {X Y : VectorField M} → run X ≡ run Y → X ≡ Y
    field-path ext setM {X = vector-field f p} {vector-field .f q} refl =
      cong (vector-field f) (ext (λ m → setM (f m zeroD) m (p m) (q m)))

  field-ext : (ext : FunExt ℓ ℓ) {M : Set ℓ} → isSet M →
    {X Y : VectorField M} →
    ((m : M) (d : D) → run X m d ≡ run Y m d) → X ≡ Y
  field-ext ext setM p = field-path ext setM (ext (λ m → ext (p m)))

  -- The three descriptions (8.1)--(8.3) are explicit currying operations.
  Section : (M : Set ℓ) → Set ℓ
  Section M = (m : M) → Tangent M m

  field-section : {M : Set ℓ} → VectorField M → Section M
  field-section X m = tangent (run X m) (run-zero X m)

  section-field : {M : Set ℓ} → Section M → VectorField M
  run (section-field s) m = curve (s m)
  run-zero (section-field s) m = based (s m)

  section-field-roundtrip : {M : Set ℓ} (X : VectorField M) →
    section-field (field-section X) ≡ X
  section-field-roundtrip X = refl

  field-section-roundtrip : {M : Set ℓ} (s : Section M) (m : M) →
    field-section (section-field s) m ≡ s m
  field-section-roundtrip s m = refl

  record TransformationPath (M : Set ℓ) : Set ℓ where
    constructor transformation-path
    field
      transform : D → M → M
      transform-zero : (m : M) → transform zeroD m ≡ m
  open TransformationPath public

  field-transformations : {M : Set ℓ} → VectorField M → TransformationPath M
  transform (field-transformations X) d m = run X m d
  transform-zero (field-transformations X) = run-zero X

  transformations-field : {M : Set ℓ} → TransformationPath M → VectorField M
  run (transformations-field X) m d = transform X d m
  run-zero (transformations-field X) = transform-zero X

  field-transformations-roundtrip : {M : Set ℓ} (X : VectorField M) →
    transformations-field (field-transformations X) ≡ X
  field-transformations-roundtrip X = refl

  transformations-field-roundtrip : {M : Set ℓ} (X : TransformationPath M) →
    field-transformations (transformations-field X) ≡ X
  transformations-field-roundtrip X = refl

  zero-field : {M : Set ℓ} → VectorField M
  run zero-field m d = m
  run-zero zero-field m = refl

  scale-field : {M : Set ℓ} → (M → R) → VectorField M → VectorField M
  run (scale-field f X) m d = run X m (scaleD d (f m))
  run-zero (scale-field f X) m =
    trans (cong (run X m) (scale-zero (f m))) (run-zero X m)

  scale-field-one : {M : Set ℓ} (X : VectorField M) (m : M) (d : D) →
    run (scale-field (λ _ → 1r) X) m d ≡ run X m d
  scale-field-one X m d = cong (run X m) (scale-one d)

  scale-field-assoc : {M : Set ℓ} (f g : M → R) (X : VectorField M) (m : M) (d : D) →
    run (scale-field (λ x → f x * g x) X) m d ≡
    run (scale-field f (scale-field g X)) m d
  scale-field-assoc f g X m d = cong (run X m) (scale-assoc d (f m) (g m))

  scale-field-zero : {M : Set ℓ} (X : VectorField M) (m : M) (d : D) →
    run (scale-field (λ _ → 0r) X) m d ≡ m
  scale-field-zero X m d =
    trans (cong (run X m) (d-path (*-zeroʳ (value d)))) (run-zero X m)

  negative-field : {M : Set ℓ} → VectorField M → VectorField M
  run (negative-field X) m d = run X m (negateD d)
  run-zero (negative-field X) m =
    trans (cong (run X m) (d-path neg-zero)) (run-zero X m)

  negative-is-scale : {M : Set ℓ} (X : VectorField M) (m : M) (d : D) →
    run (negative-field X) m d ≡ run (scale-field (λ _ → - 1r) X) m d
  negative-is-scale X m d = cong (run X m)
    (d-path (sym (trans (neg-mulʳ (value d) 1r) (cong (λ x → - x) (*-identityʳ (value d))))))

  record Isomorphism (M N : Set ℓ) : Set ℓ where
    constructor isomorphism
    field
      forward : M → N
      backward : N → M
      backward-forward : (m : M) → backward (forward m) ≡ m
      forward-backward : (n : N) → forward (backward n) ≡ n

  -- Exercise I.8.1: flows and their exponential adjoints as monoid maps.
  record GlobalFlow (M : Set ℓ) : Set ℓ where
    field
      act : M → R → M
      act-zero : (m : M) → act m 0r ≡ m
      act-add : (m : M) (r s : R) → act (act m r) s ≡ act m (r + s)
  open GlobalFlow public

  record AdditiveMonoidAction (M : Set ℓ) : Set ℓ where
    field
      action : R → M → M
      action-zero : (m : M) → action 0r m ≡ m
      action-add : (r s : R) (m : M) → action (r + s) m ≡ action r (action s m)
  open AdditiveMonoidAction public

  flow-to-action : {M : Set ℓ} → GlobalFlow M → AdditiveMonoidAction M
  action (flow-to-action X) r m = act X m r
  action-zero (flow-to-action X) = act-zero X
  action-add (flow-to-action X) r s m =
    trans (cong (act X m) (+-comm r s)) (sym (act-add X m s r))

  action-to-flow : {M : Set ℓ} → AdditiveMonoidAction M → GlobalFlow M
  act (action-to-flow X) m r = action X r m
  act-zero (action-to-flow X) = action-zero X
  act-add (action-to-flow X) m r s =
    trans (sym (action-add X s r m)) (cong (λ t → action X t m) (+-comm s r))

  flow-action-roundtrip : {M : Set ℓ} (X : GlobalFlow M) (m : M) (r : R) →
    act (action-to-flow (flow-to-action X)) m r ≡ act X m r
  flow-action-roundtrip X m r = refl

  action-flow-roundtrip : {M : Set ℓ} (X : AdditiveMonoidAction M) (r : R) (m : M) →
    action (flow-to-action (action-to-flow X)) r m ≡ action X r m
  action-flow-roundtrip X r m = refl

  -- Exercise I.8.2: the category of objects equipped with vector fields.
  record Morphism {M N : Set ℓ} (X : VectorField M) (Y : VectorField N) : Set ℓ where
    constructor field-morphism
    field
      map : M → N
      commutes : (m : M) (d : D) → map (run X m d) ≡ run Y (map m) d
  open Morphism public

  identity-morphism : {M : Set ℓ} (X : VectorField M) → Morphism X X
  map (identity-morphism X) m = m
  commutes (identity-morphism X) m d = refl

  compose-morphism : {M N P : Set ℓ}
    {X : VectorField M} {Y : VectorField N} {Z : VectorField P} →
    Morphism Y Z → Morphism X Y → Morphism X Z
  map (compose-morphism g f) m = map g (map f m)
  commutes (compose-morphism g f) m d =
    trans (cong (map g) (commutes f m d)) (commutes g (map f m) d)

  HomEqual : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N} →
    Morphism X Y → Morphism X Y → Set ℓ
  HomEqual f g = (m : _) → map f m ≡ map g m

  hom-refl : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N}
    (f : Morphism X Y) → HomEqual f f
  hom-refl f m = refl

  hom-sym : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N}
    {f g : Morphism X Y} → HomEqual f g → HomEqual g f
  hom-sym p m = sym (p m)

  hom-trans : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N}
    {f g h : Morphism X Y} → HomEqual f g → HomEqual g h → HomEqual f h
  hom-trans p q m = trans (p m) (q m)

  hom-left-identity : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N}
    (f : Morphism X Y) → HomEqual (compose-morphism (identity-morphism Y) f) f
  hom-left-identity f m = refl

  hom-right-identity : {M N : Set ℓ} {X : VectorField M} {Y : VectorField N}
    (f : Morphism X Y) → HomEqual (compose-morphism f (identity-morphism X)) f
  hom-right-identity f m = refl

  hom-assoc : {L M N P : Set ℓ}
    {W : VectorField L} {X : VectorField M} {Y : VectorField N} {Z : VectorField P}
    (h : Morphism Y Z) (g : Morphism X Y) (f : Morphism W X) →
    HomEqual (compose-morphism (compose-morphism h g) f)
             (compose-morphism h (compose-morphism g f))
  hom-assoc h g f m = refl

  hom-compose-cong : {M N P : Set ℓ}
    {X : VectorField M} {Y : VectorField N} {Z : VectorField P}
    {g g′ : Morphism Y Z} {f f′ : Morphism X Y} →
    HomEqual g g′ → HomEqual f f′ →
    HomEqual (compose-morphism g f) (compose-morphism g′ f′)
  hom-compose-cong {g′ = g′} p q m = trans (p _) (cong (map g′) (q m))

  -- Exercise I.8.6: the Liouville field on the tangent bundle M^D.
  liouville-parameter : D → D → D
  liouville-parameter d e = scaleD d (1r + value e)

  liouville-value : (d e : D) →
    value (liouville-parameter d e) ≡ value d + value d * value e
  liouville-value d e = trans (distribˡ (value d) 1r (value e))
    (cong (_+ (value d * value e)) (*-identityʳ (value d)))

  liouville-zero : (d : D) → liouville-parameter d zeroD ≡ d
  liouville-zero d = d-path
    (trans (cong (value d *_) (+-identityʳ 1r)) (*-identityʳ (value d)))

  liouville : FunExt ℓ ℓ → {M : Set ℓ} → VectorField (D → M)
  run (liouville ext) t e d = t (liouville-parameter d e)
  run-zero (liouville ext) t = ext (λ d → cong t (liouville-zero d))

module Linear {ℓ : Level} (A : CRing ℓ) (setR : isSet (CRing.R A))
  {M : Set ℓ} (IL : S6.Linear.InfinitesimallyLinear A M) where
  open RingLemmas A
  open Infinitesimals A
  open Jets A
  open S7.Basics A setR hiding (first; second)
  open Basics A setR
  module Lin = S6.Linear.InfinitesimallyLinear IL

  first second : Jet1 2 → D
  first p = coordinateD p fzero
  second p = coordinateD p (fsuc fzero)

  private
    first-axis₁ : (d : D) → first (axis fzero d) ≡ d
    first-axis₁ d = d-path (axis-own {n = 2} fzero d)

    second-axis₂ : (d : D) → second (axis (fsuc fzero) d) ≡ d
    second-axis₂ d = d-path (axis-own {n = 2} (fsuc fzero) d)

    first-axis₂ : (d : D) → first (axis (fsuc fzero) d) ≡ zeroD
    first-axis₂ d = d-path
      (trans (axis-coordinate {n = 2} (fsuc fzero) fzero d) (*-zeroˡ (value d)))

    second-axis₁ : (d : D) → second (axis fzero d) ≡ zeroD
    second-axis₁ d = d-path
      (trans (axis-coordinate {n = 2} fzero (fsuc fzero) d) (*-zeroˡ (value d)))

    sum-axis : (i : Fin 2) (d : D) → sumJet (axis i d) ≡ d
    sum-axis i d = d-path
      (trans (Sum.sum-cong (λ j → axis-coordinate i j d))
        (trans (Sum.sum-scaleʳ (λ j → Sum.delta j i) (value d))
          (trans (cong (_* value d) (Sum.sum-delta-one i)) (*-identityˡ (value d)))))

  -- Proposition I.8.1: only infinitesimal linearity's uniqueness is used.
  flow-law : (X : VectorField M) (m : M) (p : Jet1 2) →
    run X (run X m (first p)) (second p) ≡ run X m (sumJet p)
  flow-law X m p = trans
    (Lin.uniqueness zero m (λ _ d → run X m d) (λ _ → run-zero X m)
      composed composed-axes p)
    (sym (Lin.uniqueness zero m (λ _ d → run X m d) (λ _ → run-zero X m)
      summed (λ i d → cong (run X m) (sum-axis i d)) p))
    where
    composed summed : Jet1 2 → M
    composed q = run X (run X m (first q)) (second q)
    summed q = run X m (sumJet q)

    composed-axes : (i : Fin 2) (d : D) → composed (axis i d) ≡ run X m d
    composed-axes fzero d =
      trans (cong₂ (λ e f → run X (run X m e) f) (first-axis₁ d) (second-axis₁ d))
        (run-zero X (run X m d))
    composed-axes (fsuc fzero) d =
      trans (cong₂ (λ e f → run X (run X m e) f) (first-axis₂ d) (second-axis₂ d))
        (cong (λ n → run X n d) (run-zero X m))

  -- More generally two fields commute for mutually annihilating parameters.
  -- This is useful in I.9 and does not assert commutation for arbitrary D².
  compatible-commute : (X Y : VectorField M) (m : M) (p : Jet1 2) →
    run Y (run X m (first p)) (second p) ≡
    run X (run Y m (second p)) (first p)
  compatible-commute X Y m p =
    trans (Lin.uniqueness zero m axes-fields bases composedXY xy-axes p)
      (sym (Lin.uniqueness zero m axes-fields bases composedYX yx-axes p))
    where
    axes-fields : Fin 2 → D → M
    axes-fields fzero d = run X m d
    axes-fields (fsuc fzero) d = run Y m d

    bases : (i : Fin 2) → axes-fields i zeroD ≡ m
    bases fzero = run-zero X m
    bases (fsuc fzero) = run-zero Y m

    composedXY composedYX : Jet1 2 → M
    composedXY q = run Y (run X m (first q)) (second q)
    composedYX q = run X (run Y m (second q)) (first q)

    xy-axes : (i : Fin 2) (d : D) → composedXY (axis i d) ≡ axes-fields i d
    xy-axes fzero d =
      trans (cong₂ (λ e f → run Y (run X m e) f) (first-axis₁ d) (second-axis₁ d))
        (run-zero Y (run X m d))
    xy-axes (fsuc fzero) d =
      trans (cong₂ (λ e f → run Y (run X m e) f) (first-axis₂ d) (second-axis₂ d))
        (cong (λ n → run Y n d) (run-zero X m))

    yx-axes : (i : Fin 2) (d : D) → composedYX (axis i d) ≡ axes-fields i d
    yx-axes fzero d =
      trans (cong₂ (λ e f → run X (run Y m f) e) (first-axis₁ d) (second-axis₁ d))
        (cong (λ n → run X n d) (run-zero Y m))
    yx-axes (fsuc fzero) d =
      trans (cong₂ (λ e f → run X (run Y m f) e) (first-axis₂ d) (second-axis₂ d))
        (run-zero X (run Y m d))

  same-parameter-commute : (X Y : VectorField M) (m : M) (d : D) →
    run Y (run X m d) d ≡ run X (run Y m d) d
  same-parameter-commute X Y m d =
    trans (cong₂ (λ e f → run Y (run X m e) f)
      (sym (d-path (diagonal-coordinate {n = 2} d fzero)))
      (sym (d-path (diagonal-coordinate {n = 2} d (fsuc fzero)))))
      (trans (compatible-commute X Y m (diagonal d))
        (cong₂ (λ e f → run X (run Y m f) e)
          (d-path (diagonal-coordinate {n = 2} d fzero))
          (d-path (diagonal-coordinate {n = 2} d (fsuc fzero)))))

  opposite-pair : D → Jet1 2
  opposite-pair d = makeJet1 (value d ∷ (- value d) ∷ []) proof
    where
    proof : (i j : Fin 2) →
      SDG.Finite.lookup (value d ∷ (- value d) ∷ []) i *
      SDG.Finite.lookup (value d ∷ (- value d) ∷ []) j ≡ 0r
    proof fzero fzero = square-zero d
    proof fzero (fsuc fzero) =
      trans (neg-mulʳ (value d) (value d)) (trans (cong -_ (square-zero d)) neg-zero)
    proof (fsuc fzero) fzero =
      trans (neg-mulˡ (value d) (value d)) (trans (cong -_ (square-zero d)) neg-zero)
    proof (fsuc fzero) (fsuc fzero) =
      trans (neg-mul-neg (value d) (value d)) (square-zero d)

  opposite-sum : (d : D) → sumJet (opposite-pair d) ≡ zeroD
  opposite-sum d = d-path
    (trans (cong (value d +_) (+-identityʳ (- value d))) (+-inverseʳ (value d)))

  -- Corollary I.8.2 and Exercise I.8.5.
  inverse-right : (X : VectorField M) (m : M) (d : D) →
    run X (run X m d) (negateD d) ≡ m
  inverse-right X m d =
    trans (cong₂ (λ e f → run X (run X m e) f)
      (sym (d-path {d = first (opposite-pair d)} {e = d} refl))
      (sym (d-path {d = second (opposite-pair d)} {e = negateD d} refl)))
      (trans (flow-law X m (opposite-pair d))
        (trans (cong (run X m) (opposite-sum d)) (run-zero X m)))

  inverse-left : (X : VectorField M) (m : M) (d : D) →
    run X (run X m (negateD d)) d ≡ m
  inverse-left X m d =
    trans (cong (run X (run X m (negateD d))) (sym (negateD-involutive d)))
      (inverse-right X m (negateD d))

  transformation-isomorphism : (X : VectorField M) (d : D) → Isomorphism M M
  Isomorphism.forward (transformation-isomorphism X d) m = run X m d
  Isomorphism.backward (transformation-isomorphism X d) m = run X m (negateD d)
  Isomorphism.backward-forward (transformation-isomorphism X d) m = inverse-right X m d
  Isomorphism.forward-backward (transformation-isomorphism X d) m = inverse-left X m d

  negative-is-inverse : (X : VectorField M) (m : M) (d : D) →
    run (negative-field X) (run X m d) d ≡ m
  negative-is-inverse = inverse-right

module Scalar {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A)) where
  open RingLemmas A
  open Infinitesimals A
  open Basics A setR
  open S2.Results A K using (derivative; derivative-unique; taylor)

  unit-field : VectorField R
  run unit-field x d = x + value d
  run-zero unit-field = +-identityʳ

  -- Exercise I.8.2, the scalar endomorphism characterization.
  endomorphism-derivative-one : (f : Morphism unit-field unit-field) (x : R) →
    derivative (map f) x ≡ 1r
  endomorphism-derivative-one f x = derivative-unique (map f) x 1r
    (λ d → trans (commutes f x d)
      (cong (map f x +_) (sym (*-identityʳ (value d)))))

  derivative-one-endomorphism : (f : R → R) →
    ((x : R) → derivative f x ≡ 1r) → Morphism unit-field unit-field
  map (derivative-one-endomorphism f p) = f
  commutes (derivative-one-endomorphism f p) x d =
    trans (taylor f x d)
      (cong (f x +_) (trans (cong (value d *_) (p x)) (*-identityʳ (value d))))

