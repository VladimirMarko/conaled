{-# OPTIONS --safe --without-K #-}

module SDG.Algebra.DualNumbers where

open import SDG.Prelude
open import SDG.Algebra

-- Morphisms preserve the displayed structure; no homomorphism law is inferred
-- from a name or from an unverified algebraic simplification.
record RingHom {a b : Level} (A : CRing a) (B : CRing b) : Set (a ⊔ b) where
  constructor ring-hom
  private
    module A = CRing A
    module B = CRing B
  field
    hom : A.R → B.R
    pres-0 : hom A.0r ≡ B.0r
    pres-1 : hom A.1r ≡ B.1r
    pres-+ : (x y : A.R) → hom (x A.+ y) ≡ hom x B.+ hom y
    pres-* : (x y : A.R) → hom (x A.* y) ≡ hom x B.* hom y
    pres-neg : (x : A.R) → hom (A.- x) ≡ B.- hom x

module DualNumbers {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  Dual : Set ℓ
  Dual = R × R

  add : Dual → Dual → Dual
  add (a , b) (c , e) = (a + c) , (b + e)

  mul : Dual → Dual → Dual
  mul (a , b) (c , e) = (a * c) , ((a * e) + (c * b))

  neg : Dual → Dual
  neg (a , b) = (- a) , (- b)

  zeroDual oneDual : Dual
  zeroDual = 0r , 0r
  oneDual  = 1r , 0r

  add-assoc : (p q r : Dual) → add (add p q) r ≡ add p (add q r)
  add-assoc (a , b) (c , d) (e , f) =
    cong₂ _,_ (+-assoc a c e) (+-assoc b d f)

  add-comm : (p q : Dual) → add p q ≡ add q p
  add-comm (a , b) (c , d) = cong₂ _,_ (+-comm a c) (+-comm b d)

  add-zeroˡ : (p : Dual) → add zeroDual p ≡ p
  add-zeroˡ (a , b) = cong₂ _,_ (+-identityˡ a) (+-identityˡ b)

  add-zeroʳ : (p : Dual) → add p zeroDual ≡ p
  add-zeroʳ (a , b) = cong₂ _,_ (+-identityʳ a) (+-identityʳ b)

  add-inverseˡ : (p : Dual) → add (neg p) p ≡ zeroDual
  add-inverseˡ (a , b) = cong₂ _,_ (+-inverseˡ a) (+-inverseˡ b)

  add-inverseʳ : (p : Dual) → add p (neg p) ≡ zeroDual
  add-inverseʳ (a , b) = cong₂ _,_ (+-inverseʳ a) (+-inverseʳ b)

  mul-assoc : (p q r : Dual) → mul (mul p q) r ≡ mul p (mul q r)
  mul-assoc (a , b) (c , d) (e , f) = cong₂ _,_ (*-assoc a c e)
    (begin
       ((a * c) * f) + (e * ((a * d) + (c * b)))
     ≡⟨ cong₂ _+_ (*-assoc a c f) (distribˡ e (a * d) (c * b)) ⟩
       (a * (c * f)) + ((e * (a * d)) + (e * (c * b)))
     ≡⟨ cong ((a * (c * f)) +_)
           (cong₂ _+_ (*-swap e a d)
             (trans (*-swap e c b) (sym (*-assoc c e b)))) ⟩
       (a * (c * f)) + ((a * (e * d)) + ((c * e) * b))
     ≡⟨ sym (+-assoc (a * (c * f)) (a * (e * d)) ((c * e) * b)) ⟩
       ((a * (c * f)) + (a * (e * d))) + ((c * e) * b)
     ≡⟨ cong (_+ ((c * e) * b)) (sym (distribˡ a (c * f) (e * d))) ⟩
       (a * ((c * f) + (e * d))) + ((c * e) * b) ∎)

  mul-comm : (p q : Dual) → mul p q ≡ mul q p
  mul-comm (a , b) (c , d) =
    cong₂ _,_ (*-comm a c) (+-comm (a * d) (c * b))

  mul-oneˡ : (p : Dual) → mul oneDual p ≡ p
  mul-oneˡ (a , b) = cong₂ _,_ (*-identityˡ a)
    (trans (cong₂ _+_ (*-identityˡ b) (*-zeroʳ a)) (+-identityʳ b))

  mul-oneʳ : (p : Dual) → mul p oneDual ≡ p
  mul-oneʳ p = trans (mul-comm p oneDual) (mul-oneˡ p)

  mul-distribˡ : (p q r : Dual) → mul p (add q r) ≡ add (mul p q) (mul p r)
  mul-distribˡ (a , b) (c , d) (e , f) = cong₂ _,_ (distribˡ a c e)
    (trans (cong₂ _+_ (distribˡ a d f) (distribʳ c e b))
      (+-shuffle (a * d) (a * f) (c * b) (e * b)))

  mul-distribʳ : (p q r : Dual) → mul (add p q) r ≡ add (mul p r) (mul q r)
  mul-distribʳ p q r =
    trans (mul-comm (add p q) r)
      (trans (mul-distribˡ r p q) (cong₂ add (mul-comm r p) (mul-comm r q)))

  dualRing : CRing ℓ
  dualRing = record
    { R = Dual
    ; 0r = zeroDual
    ; 1r = oneDual
    ; _+_ = add
    ; _*_ = mul
    ; -_ = neg
    ; +-assoc = add-assoc
    ; +-comm = add-comm
    ; +-identityˡ = add-zeroˡ
    ; +-identityʳ = add-zeroʳ
    ; +-inverseˡ = add-inverseˡ
    ; +-inverseʳ = add-inverseʳ
    ; *-assoc = mul-assoc
    ; *-comm = mul-comm
    ; *-identityˡ = mul-oneˡ
    ; *-identityʳ = mul-oneʳ
    ; distribˡ = mul-distribˡ
    ; distribʳ = mul-distribʳ
    }

  scalar : R → Dual
  scalar a = a , 0r

  scalar-hom : RingHom A dualRing
  scalar-hom = record
    { hom = scalar
    ; pres-0 = refl
    ; pres-1 = refl
    ; pres-+ = λ a b → cong (λ c → (a + b) , c) (sym (+-identityˡ 0r))
    ; pres-* = λ a b → cong (λ c → (a * b) , c)
        (sym (trans (cong₂ _+_ (*-zeroʳ a) (*-zeroʳ b)) (+-identityˡ 0r)))
    ; pres-neg = λ a → cong (λ c → (- a) , c) (sym neg-zero)
    }

  constant-part : RingHom dualRing A
  constant-part = record
    { hom = fst
    ; pres-0 = refl
    ; pres-1 = refl
    ; pres-+ = λ p q → refl
    ; pres-* = λ p q → refl
    ; pres-neg = λ p → refl
    }

  scale : R → Dual → Dual
  scale r (a , b) = (r * a) , (r * b)

  scalar-action : (r : R) (p : Dual) → mul (scalar r) p ≡ scale r p
  scalar-action r (a , b) = cong (λ c → (r * a) , c)
    (trans (cong ((r * b) +_) (*-zeroʳ a)) (+-identityʳ (r * b)))

  ε : Dual
  ε = 0r , 1r

  ε-square-zero : mul ε ε ≡ zeroDual
  ε-square-zero = cong₂ _,_ (*-zeroˡ 0r)
    (trans (cong₂ _+_ (*-zeroˡ 1r) (*-zeroˡ 1r)) (+-identityˡ 0r))

  normal-form : (p : Dual) → add (scalar (fst p)) (mul ε (scalar (snd p))) ≡ p
  normal-form (a , b) = cong₂ _,_
    (trans (cong (a +_) (*-zeroˡ b)) (+-identityʳ a))
    (trans (+-identityˡ ((0r * 0r) + (b * 1r)))
      (trans (cong₂ _+_ (*-zeroˡ 0r) (*-identityʳ b)) (+-identityˡ b)))
