{-# OPTIONS --safe --without-K #-}
module SDG.Axiom where

open import Agda.Primitive using (Level; lsuc)
open import SDG.Prelude
open import SDG.Algebra

-- The ONLY differential-geometric assumption used by Sections I.1 and I.2.
-- This is a parameter interface, not an inhabitant/model or a theorem.
module Infinitesimals {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  record D : Set ℓ where
    constructor infinitesimal
    field
      value : R
      square-zero : value * value ≡ 0r
  open D public

  zeroD : D
  zeroD = infinitesimal 0r (*-zeroˡ 0r)

  scaleD : D → R → D
  scaleD d r = infinitesimal (value d * r)
    (square-zero-scaled (value d) r (square-zero d))

  record KockLawvere : Set (lsuc ℓ) where
    field
      slope : (D → R) → R
      expansion : (g : D → R) (d : D) →
        g d ≡ g zeroD + value d * slope g
      uniqueness : (g : D → R) (b : R) →
        ((d : D) → g d ≡ g zeroD + value d * b) →
        slope g ≡ b

