{-# OPTIONS --safe --without-K #-}
module SDG.Schemes.Isomorphism where

open import SDG.Prelude

record Isomorphism {a b : Level} (A : Set a) (B : Set b) : Set (a ⊔ b) where
  constructor isomorphism
  field
    forward : A → B
    backward : B → A
    backward-forward : (x : A) → backward (forward x) ≡ x
    forward-backward : (y : B) → forward (backward y) ≡ y
open Isomorphism public
