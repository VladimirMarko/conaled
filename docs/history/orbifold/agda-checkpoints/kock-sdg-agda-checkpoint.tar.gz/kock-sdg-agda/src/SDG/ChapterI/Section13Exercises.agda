{-# OPTIONS --safe --without-K #-}

module SDG.ChapterI.Section13Exercises where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
import SDG.Algebra.Powers as Powers
open import SDG.Order
import SDG.Calculus.Local as Local
import SDG.ChapterI.Section02 as S2
import SDG.ChapterI.Section02Exercises as E2
import SDG.ChapterI.Section13 as S13

module Hypotheses {ℓ : Level} (A : CRing ℓ) where
  open RingLemmas A

  -- Formula (13.8), without its uniqueness conclusion.
  record HadamardExistence : Set (lsuc ℓ) where
    field
      quotient : (R → R) → R → R → R
      factorization : (f : R → R) (x y : R) → f x - f y ≡ (x - y) * quotient f x y

  -- Formula (13.9). This cancels a universally varying scalar, not an
  -- individual possibly noninvertible or nilpotent ring element.
  Cancellation : Set ℓ
  Cancellation = (h : R → R) → ((x : R) → x * h x ≡ 0r) → (x : R) → h x ≡ 0r

module UniqueQuotients {ℓ : Level} (A : CRing ℓ)
  (H : Hypotheses.HadamardExistence A) (cancel : Hypotheses.Cancellation A) where
  open RingLemmas A
  open E2.DifferenceAlgebra A using (subtract-zero-implies-equal; multiply-difference; subtract-self)
  open Hypotheses.HadamardExistence H

  translate-back : (x y : R) → (x - y) + y ≡ x
  translate-back x y = trans (+-assoc x (- y) y)
    (trans (cong (x +_) (+-inverseˡ y)) (+-identityʳ x))

  cancel-differences : (h k : R → R → R) →
    ((x y : R) → (x - y) * h x y ≡ (x - y) * k x y) → (x y : R) → h x y ≡ k x y
  cancel-differences h k p x y = subtract-zero-implies-equal (h x y) (k x y)
    (trans (sym (cong (λ z → h z y - k z y) (translate-back x y)))
      (cancel (λ z → h (z + y) y - k (z + y) y) annihilated (x - y)))
    where
    annihilated : (z : R) → z * (h (z + y) y - k (z + y) y) ≡ 0r
    annihilated z = trans (cong (_* (h (z + y) y - k (z + y) y))
      (sym (+-inverse-cancelʳ z y)))
      (trans (multiply-difference ((z + y) - y) (h (z + y) y) (k (z + y) y))
        (trans (cong (λ w → w - (((z + y) - y) * k (z + y) y)) (p (z + y) y))
          (subtract-self (((z + y) - y) * k (z + y) y))))

  -- Exercise I.13.2: the existence principle plus (13.9) gives Fermat's
  -- complete axiom. Neither KL nor integration is needed for this step.
  fermat : E2.Primitive.Fermat A
  fermat = record
    { quotient = quotient
    ; decomposition = factorization
    ; uniqueness = λ f h p → cancel-differences (quotient f) h
        (λ x y → trans (sym (factorization f x y)) (p x y))
    }

module FermatCalculus {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (F : E2.Primitive.Fermat A) where
  open RingLemmas A
  open E2.Primitive.Fermat F
  open E2.DifferenceAlgebra A using (subtract-zero; subtract-zero-implies-equal)
  module G = S2.Results A K
  module Q = E2.Results A F

  derivative-subtract-constant : (f : R → R) (c x : R) →
    G.derivative (λ y → f y - c) x ≡ G.derivative f x
  derivative-subtract-constant f c x = trans (G.derivative-add f (λ _ → - c) x)
    (trans (cong (G.derivative f x +_) (G.derivative-constant (- c) x)) (+-identityʳ (G.derivative f x)))

  derivative-difference : (c x : R) → G.derivative (λ y → y - c) x ≡ 1r
  derivative-difference c x = trans (derivative-subtract-constant id c x) (G.derivative-identity x)

  vanishing-product-derivative : (x : R) (h : R → R) →
    G.derivative (λ y → (y - x) * h y) x ≡ h x
  vanishing-product-derivative x h = trans (G.derivative-product (λ y → y - x) h x)
    (trans (cong₂ _+_
      (trans (cong (_* G.derivative h x) (+-inverseʳ x)) (*-zeroˡ (G.derivative h x)))
      (trans (cong (h x *_) (derivative-difference x x)) (*-identityʳ (h x)))) (+-identityˡ (h x)))

  -- Exercise I.13.3, first clause: the KL and divided-difference
  -- derivatives coincide, rather than defining a different derivative.
  diagonal-quotient : (f : R → R) (x : R) → G.derivative f x ≡ quotient f x x
  diagonal-quotient f x = trans (sym (derivative-subtract-constant f (f x) x))
    (trans (G.derivative-cong (λ y → f y - f x) (λ y → (y - x) * quotient f y x)
      (λ y → decomposition f y x) x) (vanishing-product-derivative x (λ y → quotient f y x)))

  quotient-add-back : (f : R → R) (x y : R) →
    quotient f y x ≡ quotient f x x + (y - x) * quotient (λ z → quotient f z x) y x
  quotient-add-back f x y =
    trans (sym (+-inverse-cancelʳ (quotient f y x) (- quotient f x x)))
      (trans (cong (λ z → z + (- (- quotient f x x))) (decomposition (λ z → quotient f z x) y x))
        (trans (cong (((y - x) * quotient (λ z → quotient f z x) y x) +_) (neg-involutive (quotient f x x)))
          (+-comm ((y - x) * quotient (λ z → quotient f z x) y x) (quotient f x x))))

  secondRemainder : (R → R) → R → R → R
  secondRemainder f x y = quotient (λ z → quotient f z x) y x

  second-remainder-formula : (f : R → R) (x y : R) →
    f y - f x ≡ (y - x) * G.derivative f x + ((y - x) * (y - x)) * secondRemainder f x y
  second-remainder-formula f x y = trans (decomposition f y x)
    (trans (cong ((y - x) *_) (quotient-add-back f x y))
      (trans (distribˡ (y - x) (quotient f x x) ((y - x) * secondRemainder f x y))
        (cong₂ _+_ (cong ((y - x) *_) (sym (diagonal-quotient f x)))
          (sym (*-assoc (y - x) (y - x) (secondRemainder f x y))))))

  cancel-squared-differences : (h k : R → R → R) →
    ((x y : R) → ((x - y) * (x - y)) * h x y ≡ ((x - y) * (x - y)) * k x y) →
    (x y : R) → h x y ≡ k x y
  cancel-squared-differences h k p = Q.cancel-universal-differences h k
    (Q.cancel-universal-differences (λ x y → (x - y) * h x y) (λ x y → (x - y) * k x y)
      (λ x y → trans (sym (*-assoc (x - y) (x - y) (h x y)))
        (trans (p x y) (*-assoc (x - y) (x - y) (k x y)))))

  second-remainder-unique : (f : R → R) (h : R → R → R) →
    ((x y : R) → f y - f x ≡ (y - x) * G.derivative f x + ((y - x) * (y - x)) * h x y) →
    (x y : R) → secondRemainder f x y ≡ h x y
  second-remainder-unique f h p x y = cancel-squared-differences
    (λ u v → secondRemainder f v u) (λ u v → h v u)
    (λ u v → +-cancelˡ ((u - v) * G.derivative f v)
      (trans (sym (second-remainder-formula f v u)) (p v u))) y x

  first-derivative-factorization : (f : R → R) (x y : R) →
    G.derivative f y ≡ (y - x) * G.derivative (λ z → quotient f z x) y + quotient f y x
  first-derivative-factorization f x y = trans (sym (derivative-subtract-constant f (f x) y))
    (trans (G.derivative-cong (λ z → f z - f x) (λ z → (z - x) * quotient f z x)
      (λ z → decomposition f z x) y)
      (trans (G.derivative-product (λ z → z - x) (λ z → quotient f z x) y)
        (cong (((y - x) * G.derivative (λ z → quotient f z x) y) +_)
          (trans (cong (quotient f y x *_) (derivative-difference x y)) (*-identityʳ (quotient f y x))))))

  second-remainder-double : (f : R → R) (x : R) →
    G.derivative (G.derivative f) x ≡ (1r + 1r) * secondRemainder f x x
  second-remainder-double f x =
    trans (G.derivative-cong (G.derivative f)
      (λ y → (y - x) * G.derivative q y + q y) (first-derivative-factorization f x) x)
      (trans (G.derivative-add (λ y → (y - x) * G.derivative q y) q x)
        (trans (cong (_+ G.derivative q x) (vanishing-product-derivative x (G.derivative q)))
          (trans (cong₂ _+_ (diagonal-quotient q x) (diagonal-quotient q x))
            (sym (trans (distribʳ 1r 1r (secondRemainder f x x))
              (cong₂ _+_ (*-identityˡ (secondRemainder f x x)) (*-identityˡ (secondRemainder f x x))))))))
    where q : R → R
          q y = quotient f y x

  second-remainder-diagonal : (half : R) → (1r + 1r) * half ≡ 1r →
    (f : R → R) (x : R) → secondRemainder f x x ≡ half * G.derivative (G.derivative f) x
  second-remainder-diagonal half half-law f x = sym
    (trans (cong (half *_) (second-remainder-double f x))
      (trans (sym (*-assoc half (1r + 1r) (secondRemainder f x x)))
        (trans (cong (_* secondRemainder f x x) (trans (*-comm half (1r + 1r)) half-law))
          (*-identityˡ (secondRemainder f x x)))))

-- Exercise I.13.3 under precisely its stated foundation: KL, existence
-- (13.8), and cancellation (13.9), with division by two explicit only
-- for its final factorial-normalized equality.
module Exercise13-3 {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (H : Hypotheses.HadamardExistence A) (C : Hypotheses.Cancellation A) where
  open FermatCalculus A K (UniqueQuotients.fermat A H C) public

module IntegrationConsequences {ℓ : Level} (A : CRing ℓ) (K : Infinitesimals.KockLawvere A)
  (O : CompatiblePreorder A) (J : S13.Setup.Integration A K O) where
  open S13.Results A K O J
  module G = S2.Results A K

  existence : Hypotheses.HadamardExistence A
  existence = record { quotient = dividedDifference ; factorization = divided-difference-equation }

  derivative-scaled-coordinate : (r : R) (t : UnitInterval) →
    Unit.derivative (λ s → coordinate s * r) t ≡ r
  derivative-scaled-coordinate r t = Unit.derivative-unique (λ s → coordinate s * r) t r
    (λ d → distribʳ (coordinate t) (Infinitesimals.value d) r)

  zero-product-derivative : (h : R → R) → ((x : R) → x * h x ≡ 0r) →
    (x : R) → x * G.derivative h x + h x ≡ 0r
  zero-product-derivative h annihilated x =
    trans (sym (trans (G.derivative-product id h x)
      (cong (x * G.derivative h x +_)
        (trans (cong (h x *_) (G.derivative-identity x)) (*-identityʳ (h x))))))
      (trans (G.derivative-cong (λ y → y * h y) (λ _ → 0r) annihilated x) (G.derivative-constant 0r x))

  -- Notes 2006, correction 24: (13.9) follows from integration. For fixed
  -- r, the function t*h(t*r) has zero derivative and value zero at t=0.
  cancellation : Hypotheses.Cancellation A
  cancellation h annihilated r =
    trans (sym (trans (*-identityˡ (h (1r * r))) (cong h (*-identityˡ r))))
      (trans (zero-derivative-constant q q-derivative one-point) (*-zeroˡ (h (0r * r))))
    where
    q : UnitInterval → R
    q t = coordinate t * h (coordinate t * r)
    q-derivative : (t : UnitInterval) → Unit.derivative q t ≡ 0r
    q-derivative t = trans (Unit.derivative-product coordinate (λ s → h (coordinate s * r)) t)
      (trans (cong₂ _+_
        (cong (coordinate t *_)
          (trans (Local.Chain.derivative-chain A K (Local.wholeLine A) (intervalDomain 0r 1r)
            h (λ s → coordinate s * r) t)
            (cong (G.derivative h (coordinate t * r) *_) (derivative-scaled-coordinate r t))))
        (trans (cong (h (coordinate t * r) *_) (Unit.derivative-coordinate t)) (*-identityʳ (h (coordinate t * r)))))
        (trans (cong (_+ h (coordinate t * r))
          (trans (cong (coordinate t *_) (*-comm (G.derivative h (coordinate t * r)) r))
            (sym (*-assoc (coordinate t) r (G.derivative h (coordinate t * r))))))
          (zero-product-derivative h annihilated (coordinate t * r))))

  integrationFermat : E2.Primitive.Fermat A
  integrationFermat = UniqueQuotients.fermat A existence cancellation

  module DifferentialRemainders = FermatCalculus A K integrationFermat

-- The parenthetical assertion after (13.10): Hadamard factorization can
-- be iterated to every finite order, with a uniquely determined remainder.
-- Polynomial coefficients here are the successive diagonal quotients;
-- the preceding module identifies the first two with derivatives.
module RepeatedHadamard {ℓ : Level} (A : CRing ℓ) (F : E2.Primitive.Fermat A) where
  open Powers.PowerLemmas A
  open E2.Primitive.Fermat F
  module Q = E2.Results A F

  next : (R → R) → R → R → R
  next f x y = quotient f y x

  add-back : (f : R → R) (x y : R) → f y ≡ f x + (y - x) * next f x y
  add-back f x y =
    trans (sym (+-inverse-cancelʳ (f y) (- f x)))
      (trans (cong (λ z → z + (- (- f x))) (decomposition f y x))
        (trans (cong (((y - x) * next f x y) +_) (neg-involutive (f x)))
          (+-comm ((y - x) * next f x y) (f x))))

  remainder : ℕ → (R → R) → R → R → R
  remainder zero f x y = f y
  remainder (suc n) f x y = remainder n (next f x) x y

  polynomial : ℕ → (R → R) → R → R → R
  polynomial zero f x y = 0r
  polynomial (suc n) f x y = f x + (y - x) * polynomial n (next f x) x y

  expansion : (n : ℕ) (f : R → R) (x y : R) →
    f y ≡ polynomial n f x y + ((y - x) ^ n) * remainder n f x y
  expansion zero f x y = sym (trans (+-identityˡ (1r * f y)) (*-identityˡ (f y)))
  expansion (suc n) f x y = trans (add-back f x y)
    (trans (cong (λ z → f x + (y - x) * z) (expansion n (next f x) x y))
      (trans (cong (f x +_) (distribˡ (y - x) (polynomial n (next f x) x y)
        (((y - x) ^ n) * remainder n (next f x) x y)))
        (trans (sym (+-assoc (f x) ((y - x) * polynomial n (next f x) x y)
          ((y - x) * (((y - x) ^ n) * remainder n (next f x) x y))))
          (cong (polynomial (suc n) f x y +_)
            (sym (*-assoc (y - x) ((y - x) ^ n) (remainder n (next f x) x y)))))))

  cancel-power-differences : (n : ℕ) (h k : R → R → R) →
    ((x y : R) → ((x - y) ^ n) * h x y ≡ ((x - y) ^ n) * k x y) →
    (x y : R) → h x y ≡ k x y
  cancel-power-differences zero h k p x y = trans (sym (*-identityˡ (h x y)))
    (trans (p x y) (*-identityˡ (k x y)))
  cancel-power-differences (suc n) h k p = cancel-power-differences n h k
    (Q.cancel-universal-differences (λ x y → ((x - y) ^ n) * h x y)
      (λ x y → ((x - y) ^ n) * k x y)
      (λ x y → trans (sym (*-assoc (x - y) ((x - y) ^ n) (h x y)))
        (trans (p x y) (*-assoc (x - y) ((x - y) ^ n) (k x y)))))

  remainder-unique : (n : ℕ) (f : R → R) (h : R → R → R) →
    ((x y : R) → f y ≡ polynomial n f x y + ((y - x) ^ n) * h x y) →
    (x y : R) → remainder n f x y ≡ h x y
  remainder-unique n f h p x y = cancel-power-differences n
    (λ u v → remainder n f v u) (λ u v → h v u)
    (λ u v → +-cancelˡ (polynomial n f v u) (trans (sym (expansion n f v u)) (p v u))) y x
