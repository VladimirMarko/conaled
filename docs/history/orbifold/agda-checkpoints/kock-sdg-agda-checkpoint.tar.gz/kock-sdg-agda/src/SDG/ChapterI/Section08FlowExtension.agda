{-# OPTIONS --safe --without-K #-}
module SDG.ChapterI.Section08FlowExtension where

open import SDG.Prelude
open import SDG.Algebra
open import SDG.Axiom
open import SDG.Finite using (Vec; []; _∷_; replicate; Permutation; permute;
  _+ℕ_; nat-add-comm)
import SDG.ChapterI.Section03 as S3
import SDG.ChapterI.Section03Exercises as S3E
import SDG.ChapterI.Section04 as S4
import SDG.ChapterI.Section08 as S8
import SDG.Flows.CommutingActions as CA
import SDG.Infinitesimal.Nilpotent as NI

module Structures {ℓ : Level} (A : CRing ℓ) where
  open NI.Times A

  -- A monoid action by the nilpotent union, including the required
  -- independence of the witness used to present a time parameter.
  record FormalFlow (M : Set ℓ) : Set ℓ where
    field
      act∞ : M → D∞ → M
      respects-time : (m : M) → Respects∞ (act∞ m)
      at-zero : (m : M) → act∞ m zero∞ ≡ m
      at-sum : (m : M) (d e : D∞) →
        act∞ m (add∞ d e) ≡ act∞ (act∞ m d) e
  open FormalFlow public

-- The extension part of Exercise I.8.3. Its only descent premise is the
-- symmetric-functions property stated in the book. Pairwise commutation
-- is supplied by Section08FormalFlows under the corrected hypotheses.
module FiniteExtension {ℓ : Level} (A : CRing ℓ)
  (K : Infinitesimals.KockLawvere A) (setR : isSet (CRing.R A))
  {M : Set ℓ}
  (SFP : (n : ℕ) → S4.Results.SymmetricDescent A K
    (S3.HigherInfinitesimals.DK A (suc n)) (S3E.SumMap.summation A) M)
  (X : S8.Basics.VectorField A setR M)
  (commute : (d e : Infinitesimals.D A) (m : M) →
    S8.Basics.run X (S8.Basics.run X m e) d ≡
    S8.Basics.run X (S8.Basics.run X m d) e) where

  open S3.HigherInfinitesimals A
  open Infinitesimals A
  open S3E.SumMap A
  open S4.Results A K using (Symmetric; SymmetricDescent)
  open S8.Basics A setR
  open NI.Times A
  open Structures A
  module C = CA.Actions D M (λ d m → run X m d) commute
  open C using (sequence; sequence-permute)

  dk-path : {n : ℕ} {d e : DK n} → valueK d ≡ valueK e → d ≡ e
  dk-path {n} {nilpotent x p} {nilpotent .x q} refl =
    cong (nilpotent x) (setR (x ^ suc n) 0r p q)

  private
    module Addition = CA.Actions D R (λ d r → value d + r)
      (λ d e r → +-swap (value d) (value e) r)

    sum-as-sequence : {n : ℕ} (ds : Vec D n) →
      sumD ds ≡ Addition.sequence ds 0r
    sum-as-sequence [] = refl
    sum-as-sequence (d ∷ ds) = cong (value d +_) (sum-as-sequence ds)

    zero-value : (d : DK zero) → valueK d ≡ 0r
    zero-value d = trans (sym (*-identityʳ (valueK d))) (nilpotence d)

  summation-permute : {n : ℕ} (p : Permutation n) (ds : Vec D n) →
    summation (permute p ds) ≡ summation ds
  summation-permute p ds = dk-path
    (trans (sum-as-sequence (permute p ds))
      (trans (Addition.sequence-permute p ds 0r) (sym (sum-as-sequence ds))))

  sequence-symmetric : {n : ℕ} (m : M) → Symmetric (λ (ds : Vec D n) → sequence ds m)
  sequence-symmetric m p ds = sequence-permute p ds m

  flowAt : (n : ℕ) → M → DK n → M
  flowAt zero m d = m
  flowAt (suc n) m = SymmetricDescent.descend (SFP n)
    (λ ds → sequence ds m) (sequence-symmetric m)

  flowAt-factor : {n : ℕ} (m : M) (ds : Vec D n) →
    sequence ds m ≡ flowAt n m (summation ds)
  flowAt-factor m [] = refl
  flowAt-factor {suc n} m ds = SymmetricDescent.factor (SFP n)
    (λ es → sequence es m) (sequence-symmetric m) ds

  -- SFP gives detection on the finite summation maps, without claiming
  -- that an arbitrary nilpotent has a chosen tuple decomposition.
  detect : (n : ℕ) (f g : DK n → M) →
    ((ds : Vec D n) → f (summation ds) ≡ g (summation ds)) →
    (d : DK n) → f d ≡ g d
  detect zero f g p d =
    trans (cong f (dk-path (zero-value d)))
      (trans (p []) (cong g (dk-path (sym (zero-value d)))))
  detect (suc n) f g p d =
    trans (SymmetricDescent.unique (SFP n) (λ ds → f (summation ds))
      (λ q ds → cong f (summation-permute q ds)) f (λ ds → refl) d)
      (sym (SymmetricDescent.unique (SFP n) (λ ds → f (summation ds))
        (λ q ds → cong f (summation-permute q ds)) g p d))

  flowAt-unique : (n : ℕ) (m : M) (f : DK n → M) →
    ((ds : Vec D n) → sequence ds m ≡ f (summation ds)) →
    (d : DK n) → f d ≡ flowAt n m d
  flowAt-unique n m f p = detect n f (flowAt n m)
    (λ ds → trans (sym (p ds)) (flowAt-factor m ds))

  private
    sum-zero-vector : (n : ℕ) → sumD (replicate {n = n} zeroD) ≡ 0r
    sum-zero-vector zero = refl
    sum-zero-vector (suc n) = trans (+-identityˡ _) (sum-zero-vector n)

    sequence-zero : (n : ℕ) (m : M) → sequence (replicate {n = n} zeroD) m ≡ m
    sequence-zero zero m = refl
    sequence-zero (suc n) m = trans (run-zero X _) (sequence-zero n m)

  flowAt-zero : (n : ℕ) (m : M) → flowAt n m (zeroK n) ≡ m
  flowAt-zero n m =
    trans (cong (flowAt n m) (dk-path {e = summation (replicate {n = n} zeroD)}
      (sym (sum-zero-vector n))))
      (trans (sym (flowAt-factor m (replicate {n = n} zeroD))) (sequence-zero n m))

  weaken-compatible : (n : ℕ) (m : M) (d : DK n) →
    flowAt (suc n) m (weakenK d) ≡ flowAt n m d
  weaken-compatible n m = detect n
    (λ d → flowAt (suc n) m (weakenK d)) (flowAt n m) (λ ds →
      trans (cong (flowAt (suc n) m) (dk-path (sym (+-identityˡ (sumD ds)))))
        (trans (sym (flowAt-factor m (zeroD ∷ ds)))
          (trans (run-zero X (sequence ds m)) (flowAt-factor m ds))))

  shift-compatible : (n : ℕ) (m : M) (t : DK n) (d : D) →
    flowAt (suc n) m (shiftK t d) ≡ run X (flowAt n m t) d
  shift-compatible n m t d = detect n
    (λ e → flowAt (suc n) m (shiftK e d))
    (λ e → run X (flowAt n m e) d)
    (λ ds → trans (cong (flowAt (suc n) m)
        (dk-path (+-comm (sumD ds) (value d))))
      (trans (sym (flowAt-factor m (d ∷ ds)))
        (cong (λ z → run X z d) (flowAt-factor m ds)))) t

  raise : {n : ℕ} (k : ℕ) → DK n → DK (k +ℕ n)
  raise zero d = d
  raise (suc k) d = weakenK (raise k d)

  raise-value : {n : ℕ} (k : ℕ) (d : DK n) → valueK (raise k d) ≡ valueK d
  raise-value zero d = refl
  raise-value (suc k) d = raise-value k d

  raise-compatible : (n k : ℕ) (m : M) (d : DK n) →
    flowAt (k +ℕ n) m (raise k d) ≡ flowAt n m d
  raise-compatible n zero m d = refl
  raise-compatible n (suc k) m d =
    trans (weaken-compatible (k +ℕ n) m (raise k d)) (raise-compatible n k m d)

  castDK : {n k : ℕ} → n ≡ k → DK n → DK k
  castDK refl d = d

  cast-value : {n k : ℕ} (p : n ≡ k) (d : DK n) → valueK (castDK p d) ≡ valueK d
  cast-value refl d = refl

  cast-compatible : {n k : ℕ} (p : n ≡ k) (m : M) (d : DK n) →
    flowAt k m (castDK p d) ≡ flowAt n m d
  cast-compatible refl m d = refl

  -- Compatibility and equality of scalar values suffice to compare any
  -- two witnesses, regardless of their nilpotence bounds.
  bound-independent : (n k : ℕ) (m : M) (d : DK n) (e : DK k) →
    valueK d ≡ valueK e → flowAt n m d ≡ flowAt k m e
  bound-independent n k m d e p =
    trans (sym (raise-compatible n k m d))
      (trans (sym (cast-compatible (nat-add-comm k n) m (raise k d)))
        (trans (cong (flowAt (n +ℕ k) m) (dk-path
          (trans (cast-value (nat-add-comm k n) (raise k d))
            (trans (raise-value k d) (trans p (sym (raise-value n e)))))))
          (raise-compatible k n m e)))

  flow : M → D∞ → M
  flow m (witnessed n d) = flowAt n m d

  flow-respects : (m : M) → Respects∞ (flow m)
  flow-respects m (witnessed n d) (witnessed k e) p = bound-independent n k m d e p

  flow-zero : (m : M) → flow m zero∞ ≡ m
  flow-zero m = refl

  flow-restricts : (m : M) (d : D) → flow m (injectK (fromD d)) ≡ run X m d
  flow-restricts m d =
    trans (cong (flowAt 1 m) (dk-path (sym (+-identityʳ (value d)))))
      (sym (flowAt-factor m (d ∷ [])))

  flow-shift : (m : M) (t : D∞) (d : D) →
    flow m (add∞ t (injectK (fromD d))) ≡ run X (flow m t) d
  flow-shift m (witnessed n t) d =
    trans (flow-respects m (add∞ (witnessed n t) (injectK (fromD d)))
      (injectK (shiftK t d)) refl)
      (shift-compatible n m t d)

  private
    sequence-translation : {n : ℕ} (m : M) (t : D∞) (ds : Vec D n) →
      flow m (add∞ t (injectK (summation ds))) ≡ sequence ds (flow m t)
    sequence-translation m t [] =
      flow-respects m (add∞ t (injectK (summation []))) t (+-identityʳ (scalar t))
    sequence-translation m t (d ∷ ds) =
      trans (flow-respects m (add∞ t (injectK (summation (d ∷ ds))))
        (add∞ (add∞ t (injectK (summation ds))) (injectK (fromD d)))
        (trans (cong (scalar t +_) (+-comm (value d) (sumD ds)))
          (sym (+-assoc (scalar t) (sumD ds) (value d)))))
        (trans (flow-shift m (add∞ t (injectK (summation ds))) d)
          (cong (λ z → run X z d) (sequence-translation m t ds)))

  flow-add : (m : M) (t u : D∞) → flow m (add∞ t u) ≡ flow (flow m t) u
  flow-add m t (witnessed n u) = detect n
    (λ e → flow m (add∞ t (injectK e))) (flowAt n (flow m t))
    (λ ds → trans (sequence-translation m t ds) (flowAt-factor (flow m t) ds)) u

  formal-flow : FormalFlow M
  act∞ formal-flow = flow
  respects-time formal-flow = flow-respects
  at-zero formal-flow = flow-zero
  at-sum formal-flow = flow-add

  -- Every formal action restricting to X agrees with the constructed one.
  -- The proof uses SFP detection; no chosen decomposition of a nilpotent
  -- into square-zero summands is introduced.
  formal-flow-unique : (F : FormalFlow M) →
    ((m : M) (d : D) → act∞ F m (injectK (fromD d)) ≡ run X m d) →
    (m : M) (t : D∞) → act∞ F m t ≡ flow m t
  formal-flow-unique F restricts m (witnessed n t) =
    flowAt-unique n m (λ d → act∞ F m (injectK d))
      (λ ds → sym (sequence-factor ds)) t
    where
    sequence-factor : {k : ℕ} (ds : Vec D k) →
      act∞ F m (injectK (summation ds)) ≡ sequence ds m
    sequence-factor [] =
      trans (respects-time F m _ zero∞ refl) (at-zero F m)
    sequence-factor (d ∷ ds) =
      trans (respects-time F m _ (add∞ (injectK (summation ds)) (injectK (fromD d)))
        (+-comm (value d) (sumD ds)))
        (trans (at-sum F m (injectK (summation ds)) (injectK (fromD d)))
          (trans (restricts (act∞ F m (injectK (summation ds))) d)
            (cong (λ z → run X z d) (sequence-factor ds))))
