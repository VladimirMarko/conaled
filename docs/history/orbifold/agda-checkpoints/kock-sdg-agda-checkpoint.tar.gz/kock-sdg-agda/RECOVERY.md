# Recovery and continuation

## Restore

1. Extract the latest `kock-sdg-agda-checkpoint.tar.gz`.
2. Restore the supplied native Agda kit and the separately saved offline toolchain bundle.
   The bundle contains that unchanged kit plus the exact official compiler archive.
3. From the directory containing both the kit and project, run:

```sh
python3 agda-native-kit-2.8.0.2/agda_native.py verify
python3 agda-native-kit-2.8.0.2/agda_native.py --state ./agda-state setup --archive ./Agda-v2.8.0.2-linux.tar.xz --offline
python3 agda-native-kit-2.8.0.2/agda_native.py --state ./agda-state doctor
python3 agda-native-kit-2.8.0.2/agda_native.py --state ./agda-state smoke
cd kock-sdg-agda
python3 scripts/check.py --kit ../agda-native-kit-2.8.0.2 --state ../agda-state --fresh
```

The compiler archive SHA-256 is
`2bcf24bb561b1be859bba841e5d67962d1616b3251bc147f878e4f60a2fbd9f7`.
No external mathematical library is needed.

`MANIFEST.json` in the snapshot records SHA-256 hashes of its current files.
Source status is in `STATUS.json`; mathematical obligations and book coverage
are in `docs/BOOK-MAP.md`. Read these before extending anything. A successful
restored check only certifies the files listed in its report.

## Current continuation

Start with Part I. Do not skip unmet early obligations by adding them as axiom
fields. Keep a separate entry for each book theorem/exercise and record narrowed
statements honestly. The source development is incomplete.

Current checked coverage is recorded section-by-section in STATUS.json.
I.1–I.5, I.7, I.9–I.14 have checked main results and exercises; the
qualifications for I.6 and I.8 remain explicit. I.9 geometric Jacobi, native
Lie structures, invariant fields and tangent-at-unit transfer are checked.
I.11 faithful directional-derivative transfer is checked. I.12's deferred
Axiom2⇒first/higher KL bridge is now proved using concrete algebras in I.16.
I.14 includes the tangent-tuple comparison and native two-form equivalence.
I.15 ordinary Stokes, singular faces and subdivision are checked in all finite
dimensions, while its unnumbered density classification remains active.
I.16 has the actual Weil comparison, parametrized nilpotence and matrix
neighbor criterion; its remaining algebraic exercises are listed explicitly.
I.17 formal manifolds is beginning with parametrized etale lifting and a
proof-irrelevant nilpotent subobject. No full part of the book is complete.
Read docs/COVERAGE-I-06-16.md for the additional declaration inventory.

If a checkpoint includes `pending/`, it preserves current unverified source
drafts separately from accepted modules. Read pending/CURRENT.json and
restore each file to its original path before checking it; these drafts
must not be counted as proofs. This contains current work only, never a
history of successive attempts.

The 2006 notes form part of the target. In particular, note 15 adds
infinitesimal linearity to Exercise I.8.3; using that hypothesis is faithful
to the corrected statement, not an extra simplification.

## Checkpoint discipline

Replace the current checkpoint item after meaningful verified milestones.
Never include previous checkpoints, runtime installations, generated `.agdai`
files, downloaded textbook copies, or accumulating logs. Keep only latest
validation. The offline toolchain is a separate immutable companion.

For a checkpoint during concurrent editing, run from the project directory:

```sh
python3 scripts/stage-checkpoint.py --kit ../agda-native-kit-2.8.0.2 --state ../agda-state
```

This checks a temporary isolated copy with fresh interfaces, writes the
archive only after a successful check, and removes the temporary copy. A
failed check leaves the preceding recovery archive intact.

User authorization: continue the textbook formalization chapter by chapter,
and upload bounded recovery checkpoints as work progresses. No additional
approval is needed for those uploads.

