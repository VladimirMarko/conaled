#!/usr/bin/env python3
"""Check an isolated current-source copy before replacing the recovery archive.

Concurrent development can continue: the accepted snapshot itself is immutable
during validation. Temporary staging is removed on success and on failure.
"""
import argparse
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile

p = argparse.ArgumentParser()
p.add_argument('--kit', default='../agda-native-kit-2.8.0.2')
p.add_argument('--state', default='../agda-state')
p.add_argument('--output', default='../checkpoints/kock-sdg-agda-checkpoint.tar.gz')
p.add_argument('--pending', action='append', default=[], metavar='SOURCE',
               help='Preserve this unverified source as a labeled draft outside the checked source tree.')
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
kit = pathlib.Path(a.kit).resolve()
state = pathlib.Path(a.state).resolve()
output = pathlib.Path(a.output).resolve()
output.parent.mkdir(parents=True, exist_ok=True)
pending = {pathlib.Path(x) for x in a.pending}
for rel in pending:
    if rel.is_absolute() or '..' in rel.parts or rel.parts[0] != 'src' or not (root / rel).is_file():
        raise SystemExit(f'Invalid pending source: {rel}')
with tempfile.TemporaryDirectory(prefix='sdg-verified-', dir=output.parent) as temp:
    stage = pathlib.Path(temp) / 'project'
    stage.mkdir()
    for f in sorted(root.rglob('*')):
        if not f.is_file():
            continue
        rel = f.relative_to(root)
        if any(x in ('.git', '_build', '__pycache__', 'validation') for x in rel.parts):
            continue
        if f.suffix not in ('.agda', '.md', '.json', '.py', '.agda-lib', '.txt'):
            continue
        dest = stage / ('pending' if rel in pending else '') / rel
        if rel in pending:
            dest = dest.with_suffix('.agda.txt')
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, dest)
    if pending:
        (stage / 'pending' / 'README.md').write_text(
            '# Current unverified drafts\n\n'
            'These files preserve unfinished work for recovery. They are NOT part of the accepted Agda source set.\n'
            'Restore each to its original src path, removing only the final .txt suffix, then check it before promotion.\n'
            'The accepted validation report covers src/**/*.agda only.\n')
        (stage / 'pending' / 'CURRENT.json').write_text(json.dumps({
            'status': 'unverified_drafts_not_counted_as_proofs',
            'original_paths': sorted(str(x) for x in pending)}, indent=2) + '\n')
    subprocess.run([sys.executable, str(stage / 'scripts/check.py'),
                    '--kit', str(kit), '--state', str(state), '--fresh'],
                   cwd=stage, check=True)
    subprocess.run([sys.executable, str(stage / 'scripts/checkpoint.py'),
                    '--output', str(output)], cwd=stage, check=True)
