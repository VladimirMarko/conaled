#!/usr/bin/env python3
"""Create a bounded current-source recovery snapshot, never a history archive."""
import argparse, hashlib, io, json, pathlib, tarfile
p=argparse.ArgumentParser()
p.add_argument("--output", default="../checkpoints/kock-sdg-agda-checkpoint.tar.gz")
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]
output=pathlib.Path(a.output).resolve()
output.parent.mkdir(parents=True,exist_ok=True)
files=[]
for f in sorted(root.rglob("*")):
    if not f.is_file(): continue
    rel=f.relative_to(root)
    if any(part in (".git","_build","__pycache__") for part in rel.parts): continue
    if f.suffix not in (".agda",".md",".json",".py",".log",".agda-lib",".txt"): continue
    files.append(f)
manifest={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
validation=json.loads((root/'validation/latest.json').read_text())
actual_sources={k:v for k,v in manifest.items() if k.endswith('.agda')}
if not validation.get('accepted') or actual_sources != validation.get('source_sha256'):
    raise SystemExit('Refusing checkpoint: current sources do not match a successful full check.')
data=(json.dumps({"format":1,"files":manifest},indent=2)+"\n").encode()
with tarfile.open(output,"w:gz") as t:
    for f in files: t.add(f,arcname="kock-sdg-agda/"+str(f.relative_to(root)),recursive=False)
    info=tarfile.TarInfo("kock-sdg-agda/MANIFEST.json")
    info.size=len(data)
    t.addfile(info,io.BytesIO(data))
print(json.dumps({"path":str(output),"bytes":output.stat().st_size,
                  "sha256":hashlib.sha256(output.read_bytes()).hexdigest(),"files":len(files)}))

