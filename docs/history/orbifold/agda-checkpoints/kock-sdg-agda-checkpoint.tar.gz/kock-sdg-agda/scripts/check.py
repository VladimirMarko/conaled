#!/usr/bin/env python3
"""Check every current source with the pinned, unmodified native Agda kit."""
import argparse, hashlib, json, pathlib, re, subprocess, sys, datetime
p = argparse.ArgumentParser()
p.add_argument("--kit", default="../agda-native-kit-2.8.0.2")
p.add_argument("--state", default="../agda-state")
p.add_argument("--fresh", action="store_true")
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
kit = pathlib.Path(a.kit).resolve()
state = pathlib.Path(a.state).resolve()
src = root / "src"
modules = sorted(f for f in src.rglob("*.agda") if f.name != "Everything.agda")
imports = []
for f in modules:
    text = f.read_text()
    code = re.sub(r"--[^\n]*", "", text)
    forbidden = [r"\bpostulate\b", r"\bTERMINATING\b", r"\bNON_TERMINATING\b",
                 r"\bNO_POSITIVITY_CHECK\b", r"\ballow-unsolved-metas\b",
                 r"Agda\.Builtin\.TrustMe", r"Agda\.Builtin\.Equality\.Erase",
                 r"\{!!?"]
    for pattern in forbidden:
        if re.search(pattern, code):
            raise SystemExit(f"Forbidden proof escape in {f.relative_to(root)}: {pattern}")
    imports.append("import " + ".".join(f.relative_to(src).with_suffix("").parts))
top = src / "Everything.agda"
top.write_text("{-# OPTIONS --safe --without-K #-}\nmodule Everything where\n\n" +
               "\n".join(imports) + "\n")
cmd = [sys.executable, str(kit / "agda_native.py"), "--state", str(state),
       "check", str(top), "--safe", "--without-K", "-i", str(src)]
if a.fresh:
    cmd.append("--ignore-interfaces")
before = {str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest()
          for f in sorted(src.rglob("*.agda"))}
result = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
out = root / "validation"
out.mkdir(exist_ok=True)
(out / "latest.log").write_text(result.stdout)
sources = {str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest()
           for f in sorted(src.rglob("*.agda"))}
report = {
    "checked_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "compiler": "Agda 2.8.0.2",
    "command": cmd,
    "flags": ["--safe", "--without-K"],
    "fresh_check": a.fresh,
    "exit_code": result.returncode,
    "accepted": result.returncode == 0 and sources == before,
    "sources_unchanged_during_check": sources == before,
    "module_count": len(sources),
    "source_sha256": sources,
    "scope_warning": "Accepted modules prove conditional results; this is not full-book completion or a model of the axiom records."
}
(out / "latest.json").write_text(json.dumps(report, indent=2) + "\n")
print(result.stdout, end="")
print(json.dumps({k: report[k] for k in ("accepted", "module_count", "exit_code", "fresh_check")}))
sys.exit(result.returncode if result.returncode else (0 if sources == before else 2))

