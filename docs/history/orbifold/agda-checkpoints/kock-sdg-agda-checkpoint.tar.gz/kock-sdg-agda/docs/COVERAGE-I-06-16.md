# Part I, sections 6–16: declaration inventory

Source: Anders Kock, *Synthetic Differential Geometry*, second edition,
author's March 2006 text, <https://users-math.au.dk/kock/sdg99.pdf>.
Numbering below is the printed book numbering. This document is a current
coverage ledger, not a history. The latest fresh-check report in each
checkpoint determines which sources are accepted.

All modules are under `SDG`. Every statement is conditional on the parameters
shown in its Agda declaration. In particular, geometric axioms, setness of
carriers, function extensionality, inverses of integers, the compatible order
and integration are not covertly installed as global postulates. No model of
these axioms has yet been constructed. The later categorical interpretation
and model chapters remain required work.

## I.6 — Infinitesimal objects and geometric properties

| Source content | Checked implementation | Qualification |
| --- | --- | --- |
| `D_k(n)`, canonical maps, polynomial preservation (6.1) | `Infinitesimal.Jets`, `Infinitesimal.Polynomial`, `Infinitesimal.JetAlgebra` | Arbitrary finite dimension/order; actual monomial constraints. |
| Arbitrary zero-preserving maps, 6.2; scalar linearity, 6.4 | `ChapterI.Section06Linear` | Uses explicitly supplied total-degree KL. Derivation from Weil axioms is work in I.16. |
| Neighbor relations and coordinate invariance, 6.5 | `ChapterI.Section06Neighbors` | Finite and nilpotent-neighbor forms; intrinsic monad statement included. |
| Products, equalizers, function spaces and finite limits | `ChapterI.Section06Closure`; `Section06PropertyClosures.LinearClosure.finite-limit-linear`, `WClosure.finite-limit-W`, `SymmetricClosure.finite-limit-symmetric` | Actual finite graph-limit object and factorization/uniqueness, not closure axioms. |
| Geometric-property equalizer/pullback descriptions | `Section06PropertyClosures.*-gives-*-isomorphism` and converse declarations | Native isomorphisms with extensionality/setness explicit. |
| Exercises 6.1–6.4, addition and rectangular bounds | `Section06Examples`, `Section06Bilinear`, `Section06Higher`, `Section06JetClosure` | Bounds proved for arbitrary finite coordinates; symmetric bilinear vanishing included. |
| Properties of finite jet objects and their powers | `Infinitesimal.Constraints`, `Section06JetClosure`, `Section06PropertyClosures.JetPowers` | Actual carrier equalities, with proof-irrelevant polynomial equations from `isSet R`. |
| Properties of `D∞` and its finite powers | `Infinitesimal.Observed`, `Section06Infinity` | Currently at explicit scalar-value setoid equality. Native nilpotent subobject remains pending. |

## I.7 — Tangent bundles

| Source content | Checked implementation |
| --- | --- |
| Tangents, bundle, functor, scalar speed | `ChapterI.Section07` |
| 7.2 tangent fiber module and linear tangent maps | `Section07Linear.Construction.fiberModule` and tangent-map declarations |
| 7.3 principal parts for vector-KL modules | `Section07Linear` principal-part/inverse maps and module laws |
| Exercise 7.1 twist and nonidentity | `Section07`, `Section07Exercises.TwistNontrivial.twist-not-identity` |
| Exercise 7.2 axes/restriction descriptions | `Section07Exercises.Restriction.jet-roundtrip`, `pair-roundtrip`, `axes-is-restriction`, section roundtrips |
| Exercise 7.3 exponential interchange/naturality | `Section07`, `Section07Exercises.RestrictionNaturality` |

All fiber structures use the actual synthetic tangent carrier. There is no
replacement of that carrier by an assumed module.

## I.8 — Vector fields and infinitesimal flows

| Source content | Checked implementation | Qualification |
| --- | --- | --- |
| Fields as sections/transformations, 8.1–8.2 flow law/inverses | `ChapterI.Section08` | Infinitesimal linearity explicit. |
| 8.3 module over the ring of functions | `Section08Module`, `Flows.SectionModule` | Native module with all laws. |
| Exercises 8.1, 8.2, 8.5, 8.6 | `Section08`, `Flows.CommutingActions` | Field morphisms and commuting actions. |
| Corrected Exercise 8.3 formal flow and uniqueness | `Section08FormalFlows`, `Section08FlowExtension` | Uses IL, W, symmetric descent and inverse2; 2006 note15 explicitly adds IL. Nilpotent domain is currently a setoid. |
| Exercise 8.4 finite symmetric orbit universal property | `Section08FreeMonoid.FiniteOrbits.orbit-factorization-unique` | All finite orders, not just order2. |
| Exercise 8.4 pointed monoid extension | `Section08FreeMonoid.FreeCommutativePointedMonoid`, `FreePointedMonoid` | Commutative target under SFP; general target proof currently also needs IL. Printed unrestricted target class remains unresolved. |
| Exercise 8.7 classical Riccati example | `Section08Classical.solution-identity`, `solution-formula`, `no-common-interval` | Conditional on the explicit ordinary ordered-field calculus and linear-ODE uniqueness interface. No real model or proof of that external analytic theorem yet. |

## I.9 — Lie brackets

| Source content | Checked implementation |
| --- | --- |
| Bracket constructed from commutators using W; uniqueness, skew | `ChapterI.Section09` |
| Full Lie laws, including geometric Jacobi | `Section09LieLawsProofs.Laws.jacobi`, `.skew`, `.geometricLieAlgebra`; `Section09LieLawsGroup` |
| Naturality and invariant fields | `Section09Invariant`, `Section09InvariantLinear` |
| Invariant sub-Lie algebra; tangent-at-unit bracket and correspondence | `Section09LieLawsInvariant.Invariants.invariantLieAlgebra`, `.tangentLieAlgebra`, tangent/invariant roundtrips |
| Endomorphism tangent identification and bracket compatibility | `Section09LieLawsInvariant.EndomorphismIdentification`, especially `.bracket-preserved` |
| Proper fields and Exercise 9.6 | `Section09Proper.Results.proper-admission-criterion`, `.proper-admission-equality-criterion` |

The six exercises are implemented across these modules. Jacobi is proved
geometrically from actual automorphisms, commutator identities and the Hall
identity. It does not assume injectivity of the action on scalar functions.
The alternating Lie structure uses explicit inverse2. Abstract wrappers used
to keep normalization feasible have proved equalities to the source operations.
The endomorphism correspondence uses traversal multiplication `f·g=g∘f`;
the ordinary composition convention reverses the bracket, as documented.

## I.10 — Directional derivatives

| Source content | Checked implementation |
| --- | --- |
| Derivative/Taylor characterization; sum, scale, product; first integrals | `ChapterI.Section10` |
| 10.2 infinitesimal homogeneity implies additivity | `Section10Linear` | 
| 10.3 field addition/scaling and actual bracket derivative | `Section10Bracket` |
| Exercise 10.1 coordinate fields and partial derivatives | `Section10Exercises` |
| Exercise 10.2 full linearity with zero-derivative-constant premise | `Section10Exercises` |
| Exercise 10.3 first integrals as morphisms to zero field | `Section10Exercises` |

The bracket derivative proof uses universally quantified infinitesimal
cancellation, not cancellation by an individual nilpotent.

## I.11 — Algebraic derivations

| Source content | Checked implementation |
| --- | --- |
| Endomorphism commutator Lie algebra and derivations | `Algebra.Endomorphisms`, `Algebra.Derivations` |
| Coefficient module and Lie-module identity | `Algebra.Derivations`; `ChapterI.Section11.Functional.operator-lie-module` |
| 11.7 field-to-derivation comparison | `Section11.Functional.comparison`, comparison add/multiply/bracket laws |
| 11.1 faithful operator premise and native field Lie structure | `Section11.Functional.Faithful.vectorFieldsLieAlgebra`, `.jacobi`, `.lie-module-law` |
| Relative derivations and dual-number algebra maps | `Algebra.RelativeDerivations`, `Algebra.RelativeDual` |
| Group Hall identity exercise | `Section11Hall.Hall.hall-identity` |

The transfer keeps the actual native vector-field module. An opaque bracket
wrapper is accompanied by `bracket-agrees`, identifying it with I.9's bracket.
This is a normalization boundary, not a different mathematical operation.

## I.12 — The comprehensive axiom

`Section12.Comprehensive.Axiom2` asserts invertibility only of the canonical
map for actual finite polynomial presentations. It does not package the
desired geometric conclusions as assumptions.

| Source content | Checked declaration/module |
| --- | --- |
| Spectrum/exponential comparison | `Section12.Comprehensive.spec-exponential` |
| 12.1 first/higher KL from Axiom2 | `Section16FirstOrder.FirstOrder.axiom2-first-order`; `Section16Higher.Higher.axiom2-higher-order` |
| 12.2 affine map isomorphism | `Section12.Comprehensive.Consequences.affine-map-isomorphism` |
| 12.3 reflexivity | `Section12` declarations `affine-reflexive`, `reflexivity-isomorphism` |
| 12.4 tangent/relative derivation comparison | `Section12Tangents.Comparison.ReflexiveComparison.tangent-derivation-isomorphism` |
| 12.5 vector-field/derivation comparison | `Section12Tangents` declarations `vectorfield-derivation-isomorphism`, `comparison-formula` |
| 12.6 free algebras | `Section12` declarations `free-algebra-isomorphism`, `free-extension-generator`, `generator-detects` |
| 12.7 finite colimit preservation | `Section12Colimits.Preservation.Diagram.Target.preserves-finite-colimit` |
| Exercise 12.1 inherited geometric properties | `Section12Closure.Properties.reflexive-W`, `reflexive-symmetric`, `reflexive-linear` |
| Exercise 12.2 path observations | `Section12Tangents` declaration `path-observations-injective` |
| Exercise 12.3 higher observations | `Section12Jets.JetObservations.observations-injective` |
| Change of base ring `k→K→R` | `Section12BaseChange` |

Finite colimit presentations, their generated congruence and universal
properties are constructed in `Algebra.Presented*`. The internal-language
proofs still require the later categorical semantics for arbitrary ambient
categories. Appendix D microlinearity is not claimed here.

## I.13 — Integration

The assumption `Section13.Setup.Integration` contains only the normalized
unit-interval primitive, its derivative, and uniqueness. Arbitrary intervals
and every listed rule below are derived. The compatible preorder is not
assumed total or antisymmetric.

| Source content | Checked declaration/module |
| --- | --- |
| Infinitesimal interval stability and convexity | `Order`; antisymmetry contradiction under nontrivial KL |
| 13.1 Hadamard lemma | `Section13.Setup.Unit` Hadamard/globalHadamard declarations |
| 13.2 arbitrary-interval primitive | `Section13Intervals.Arbitrary.intervalPrimitive`, `interval-primitive-derivative`, uniqueness |
| 13.3 FTC, linearity, parts | `Section13`, `Section13Intervals` |
| 13.5 subdivision | `Section13Transformation.subdivision` |
| 13.6 variable endpoint | `Section13Transformation.Variable.variable-integral-derivative` |
| 13.7 substitution | `Section13Transformation.substitution` |
| Exercise 13.1 zero derivative implies constant | `Section13` zero-derivative-constant consequences |
| Exercise 13.2 cancellation and unique Hadamard quotient | `Section13Exercises.UniqueQuotients` |
| Exercise 13.3 second and higher remainders | `Section13Exercises.FermatCalculus`; `RepeatedHadamard.expansion`, `.remainder-unique` |
| Exercise 13.4 parameter differentiation | `Section13`, `Section13Intervals` parameter differentiation |
| Exercise 13.5 Fubini | `Section13Transformation.fubini` |
| 2006 note24: cancellation from integration | `Section13Exercises.IntegrationConsequences.cancellation` |
| Native linear maps for integral/primitive operators | `Section13Linear` |

Arbitrary-interval constructions never divide by the interval length.
Infinitesimally perturbed intervals have equivalent membership predicates;
equality of types is not asserted without univalence.

## I.14 — Forms and currents

| Source content | Checked declaration/module |
| --- | --- |
| Definition14.1 common-base tangent-tuple forms | `Forms.TangentTuples.Definitions.TupleForm` |
| Derived coordinate multilinearity | `Forms.TangentTuples.Multilinearity.coordinate-linear`, `.coordinate-additive` |
| `M^D(n)`/common-base tuple comparison, including n=0,1 | `Forms.JetTuples.Comparison.jet-tuple-isomorphism` |
| Cubical forms and actual permutation signatures | `Forms.Basic`; `Combinatorics.Signature`, `SignatureCofactor` |
| Coordinate and permutation actions | `Forms.CubeActions.Actions` |
| Axis restriction from tuple forms | `Forms.Axes.Comparison.cubical` |
| Form/current modules, pullback/pushforward | `Forms.Module`, `Forms.Currents` |
| Zero-currents as distributions | `Forms.ZeroCurrents.Distributions` |
| 14.4 infinitesimal integral/coefficient uniqueness | `ChapterI.Section14Coefficients`; `Forms.InfinitesimalCoefficients` |
| 14.5 exterior derivative in every finite dimension | `Section14Exterior.Cubical.exterior` and full form laws |
| Infinitesimal Stokes, naturality and linearity | `Section14Exterior` native current boundary and identities |
| Exercise14.1 `df` as principal-part pullback | `Section14Differential`, `exterior-is-differential` |
| Exercise14.2 two-form equivalence | `Section14TwoForms.TwoForms.Correspondence.native-cubical-roundtrip`, `.native-tuple-roundtrip` |

The last comparison applies to vector-KL domains as requested, with inverse2
explicit. `Forms.QuadraticCubes` proves the four-coefficient description of a
2-cube; `Forms.MixedElimination` proves that alternating forms ignore its
mixed second-order coefficient. Exterior differentiation is the alternating
sum of actual geometric face derivatives. No Stokes law is assumed as an
axiom of an abstract boundary operator.

## I.15 — Stokes' theorem

| Source content | Implementation/status |
| --- | --- |
| Iterated box integration, arbitrary-coordinate FTC | Checked: `Integration.Boxes` |
| Canonical box current and oriented face currents | Checked: `Section15.Stokes.canonicalCurrent`, `.faceCurrent`, `.boxBoundary` |
| 15.1 Stokes in arbitrary finite dimension | Checked: `Section15.Stokes.stokes-pairing`, `.stokes` |
| Singular cube Stokes into any target | Checked: `Section15.Stokes.singular-stokes`, `.singular-stokes-pairing` |
| Boundary as the signed sum of all 2n singular faces | Checked: `Section15Singular.Results.singular-boundary-faces` |
| 15.3 subdivision in every coordinate | Checked: `Integration.BoxSubdivision`, `Section15Subdivision` |
| Nilpotent integration box agrees with infinitesimal current/boundary | Checked: `Section15.Stokes.infinitesimal-box-current`, `.infinitesimal-box-boundary` |
| All-n elimination of higher cube coefficients on affine charts | Checked: `Forms.AffineCharts`, `Forms.Linearization` |
| Unique density representation of top forms on infinitesimal-stable subsets of R^n | **Pending**: finite alternating-basis theorem and stable-subset realization of the affine chart. |

The last assertion is substantial even though the text quotes an external
reference for it. It remains a proof obligation. It is not assumed by the
checked Stokes proof.

## I.16 — Weil algebras

| Source content | Implementation/status |
| --- | --- |
| Finite free structure-constant algebra and presentation | Checked: `Algebra.StructureConstants`, `PresentedStructure`, `Section16Comparison` |
| Actual Weil algebras, augmentation ideal, uniform nilpotence | Checked: `Algebra.Weil` |
| Scalar extension of Weil algebras | Checked: `Algebra.Weil.change-weil` |
| 16.1 Axiom2 implies Axiom1W | Checked: `Section16Weil.WeilTheory.axiom2-weil` |
| 16.5 coefficient formula in general finite free algebra comparison | Checked: `Section16.FiniteFreeComparison`; canonical algebra maps and native inverse identities |
| 16.2 first and all-order KL, scalar IL from Axiom2 | Checked: `Section16FirstOrder`, `Section16Higher`, `Section16Linear` |
| 16.2 all stated consequences under Axiom1W alone | **Pending**, including all-n total-degree model and bridges. |
| 16.3 uniform parametrized nilpotent values | Checked: `Section16Weil.WeilTheory.For.NilpotentValues.nilpotent-value`, `.parametrized-factorization`; only Axiom1For is needed. |
| 16.4 minor/determinant basis and coefficient correspondence16.7 | **Pending**, along with the exterior-algebra proof in Exercise16.4. |
| 16.5 quadratic matrix equations and neighbor rows | Checked: `Section16Matrices`; inverse2 explicit. |
| Exercise16.1 concrete infinitesimal Weil models | Partial: dual numbers, square-zero n-space and truncated line checked; total-degree and remaining quadratic models pending. |
| Exercise16.2 tensor products are Weil | **Pending**. |
| Exercise16.3 inverse systems and annihilator algebra | **Pending**. |

The concrete truncated-polynomial ring includes convolution laws, generator
nilpotence, evaluation homomorphisms and uniqueness, proved in
`Algebra.TruncatedPolynomials`. The presentation of a unital multiplication
table includes `X_1−1`; this essential unit relation is omitted in the source's
displayed argument on printed page63. It is an explicit local correction,
not an additional geometric axiom.

## Next sections and noncompletion

I.17 formal manifolds requires parametrized lifting and image/cover exactness.
An external jointly epic atlas must not silently become a chosen chart for
every point. Native propositional truncation, or an equivalent categorical
image treatment, is needed before the nilpotent setoid and gluing results can
be claimed as the book's subobjects. I.17–I.21, all of Parts II–III, and
Appendices A–D remain outside the accepted coverage above.
