# Kock synthetic differential geometry in Agda

Target: Anders Kock, *Synthetic Differential Geometry*, second edition (2006).
Primary source: https://users-math.au.dk/kock/sdg99.pdf

This is an **in-progress formalization**, not a completed formalization of the book.
The intended target includes all three parts and Appendices A–D, with exercises
tracked separately. See docs/BOOK-MAP.md and STATUS.json.

## Proof policy

All accepted source modules must check with the unchanged Agda 2.8.0.2 compiler,
`--safe --without-K`, no holes, no postulates, no termination/positivity bypass,
and no ambient external libraries. Definitions and proved conditional results
are counted separately from assumed structures. No model of the geometric
axioms is yet constructed. In particular, a safe parameterized theorem is not
a consistency proof of the axiom parameters.

The geometric line is an abstract commutative ring. Kock–Lawvere coefficient
existence and uniqueness are explicit parameters, corresponding to the book's
Axiom 1; no excluded middle or decidable equality of the line is assumed.
Function equalities are pointwise unless an extensionality hypothesis is
explicitly supplied.

## Recovery

Restore this project checkpoint, the supplied native kit, and the separately
saved official compiler archive. Set up the runtime using the kit's README,
then run `python3 scripts/check.py --kit ../agda-native-kit-2.8.0.2 --state ../agda-state`.
See RECOVERY.md for exact commands and current continuation instructions.

Checkpoints retain current sources, build scripts, source/dependency pins,
current proof coverage, and the latest validation. They exclude interfaces,
previous archives, command history, runtime binaries, and downloaded textbook
copies. This keeps their growth tied to current sources, not work history.

