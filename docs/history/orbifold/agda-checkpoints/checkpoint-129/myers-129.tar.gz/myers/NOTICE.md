# Source and dependency notice

`src/` contains the supplied project’s original Agda, including its current pending
work. Cleanup did not rewrite these files or assign them a new license.

`vendor/cubical` is the pinned Cubical library; its upstream license and citation
file are retained. `vendor/agda.tar.xz` is the unchanged, hash-pinned official Agda
binary distribution needed for offline setup. Runtime extraction is disposable.

`references/conaled` and `references/mathlib` contain selected unmodified upstream
source and research files at the pins in `environment.json`. They are excerpts,
not complete checkouts or locally rebuilt Lean proofs. Preserve their source
headers and upstream notices; inclusion does not relicense the material.

`tools/native` retains the exact supplied native verification helper bytes. The
workspace entry point wraps them rather than weakening their checking protocol.
`evidence` contains selected unmodified proof receipts and logs for current source
closures. Dates and absolute paths inside those raw records describe the recorded
run; they are not current setup instructions or claims of a new verification run.

Mathematical notes consolidate supplied project writing and identify cited paper
and upstream material. A paper argument, manual interpretation, bounded source
review, and native proof have distinct evidentiary scopes.
