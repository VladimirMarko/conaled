# Current effort

The full formalization and joint interpretation remain unfinished. This file owns
the current mathematical queue and blockers. Exact acceptance belongs only to
`state.json` and its applicable raw receipts. Setup and checking are in
[environment.md](environment.md), preservation and loss recovery in
[checkpoints.md](checkpoints.md), and the full goal and trust boundaries in
[project.md](project.md). Mathematical arguments belong to their topical owners,
not to a chronology here. The adopted conaled documentation patch is not an
outstanding request.

## Current quotient-coherence construction

The user approved continuing the full formalization after the checkpoint audit.
The first local step extends the existing
`OrdinaryGroupoidCompletionCoherence` owner with the actual quotient-object
computation equations for its abstract identity and composition corrections.
Both equations are proved in the original abstract blocks; they export
propositional computation without changing the correction maps or introducing
a duplicate recursor. The complete native owner gate passed in 67.397 seconds,
maximum RSS 711860 KiB, with successful guards, stable matching source/copies,
its own Finished marker and no warnings. The unchanged NaturalityLaws gate
then passed in 2.552 seconds, maximum RSS 259096 KiB, with successful guards,
stable matching sources/copies, its own Finished marker and no warnings;
its current closure also accepts Naturality. TransformationComparison then
passed its own fresh gate in 2.335 seconds, maximum RSS 244044 KiB, with
successful guards, stable matching sources/copies, its own Finished marker
and no warnings. All three unchanged consumers are again accepted against
the actual extended owner. `OrdinaryGroupoidCompletionWhiskering` now
constructs the ordinary pre/post transformations and their actual
completion squares, retaining exact endpoint functors and the common
universe level. Its object equations use the actual composition correction
exports and morphism paths; quotient induction compares paths without making
the paths themselves propositions. Its complete native gate passed in
5.534 seconds, maximum RSS 483284 KiB, with successful guards, stable matching
source/copies, its own Finished marker and no warnings. Hold it fixed.
`OrdinaryGroupoidCompletionCoherenceLaws` now supplies source-written unit
and associativity laws for the chosen corrections, using actual
identity-component transformations rather than equality of functor proof
records. Its revised source now gives representative normalization a named
`Representatives` abstraction boundary before the quotient eliminator. The
outer proof and representative export use one exact typed motive at explicit
start/end maps; literal public statements remain typed delegates. This
preceding complete 6G/600-second gate explicitly exhausted the configured
6442450944-byte heap after 381.330 seconds, native/wrapper 251, maximum RSS
6633224 KiB, with stable matching sources/copies, no guard refusal and no own
Finished marker. The guard success chain was false; no acceptance follows.
Uploaded 124 preserves those source bytes and the applicable receipt.
The current source now delegates all three quotient extensions to the
accepted HomotopyExtensionality.compare with the identical explicit maps,
paths and Representatives.at-object equations. All representative calculations,
corrections, literal law statements and existing facades remain unchanged.
This revised gate is pending; the preceding receipt does not apply to it.
Verified uploaded 120 preserves the earlier source
and its native -9/wrapper 247 diagnostic after 108.905 seconds, maximum RSS
6432020 KiB, with stable matching sources/copies and no identified cause or
own Finished marker. That diagnostic does not apply to the revised source;
no declaration hotspot or cost improvement is inferred. Bundle
specializations remain behind their own pending comparison gates.

`OrdinaryGroupoidCompletionNaturalityInverses` now constructs both inverse
laws for the completed homotopies of actual opposite natural transformations.
Its inputs are their two ordinary component-arrow inverse equations; the
completed equations follow from the checked vertical-composition,
transformation-comparison and identity laws at the same literal endpoint
functors. Its independent native gate passed in 3.243 seconds, maximum RSS
333128 KiB, with successful guards, stable matching sources/copies, its own
Finished marker and no warnings. The two whole-function laws name their
actual endomorphism-path function spaces explicitly. Hold the source fixed.
It imports no pending bundle target and assumes no completed inverse law.

`OrdinaryGroupoidCompletionHorizontalComposition` is source-written and
pending, with all existing prerequisites accepted. Its preceding complete 6G/600-second
gate explicitly exhausted the 6442450944-byte heap after 401.925 seconds,
native/wrapper 251, maximum RSS 6726916 KiB, with stable matching sources/copies,
no guard refusal and no own Finished marker. Its guard success chain was false.
Uploaded 125 preserves those source bytes and the exact receipt. The current
source now factors the two duplicate normalization chains through a private
abstract PathPasting.paste for seven arbitrary paths and their two adjacent
square equations. Both original whiskering squares, actual paths, correction
aliases, public statements and initial vertical-comparison steps are retained.
Its revised gate is pending; the preceding receipt does not apply to it.
No declaration hotspot or checking-cost improvement has been established.
It constructs both actual
whiskering/vertical presentations for eta:F⇒G and theta:H⇒K, derives their
ordinary component equality from theta's naturality at eta, and compares their
completed homotopies and both normalized paths. The original kappa(H,F),
kappa(K,G) and matching middle corrections remain literal aliases. It depends
on the accepted Whiskering, NaturalityLaws and TransformationComparison owners,
not the pending CoherenceLaws. No full pseudofunctor record is claimed.
`OrdinaryGroupoidCompletionHomotopyExtensionality` has passed its complete
native gate in 2.475 seconds, maximum RSS 266976 KiB, with zero native/wrapper
exits, successful guards, stable matching sources/copies, its own Finished
marker and no warnings. Hold it fixed. For actual supplied maps and homotopies between completions,
equality at quotient objects extends to all objects by proposition elimination
of equality between paths in the target groupoid. It constructs no replacement
correction recursor. Uploaded 124 preserved this acceptance before the
unit/associativity owner adopted that exact abstraction at its three existing
representative equations. The revised concrete law gate remains separate;
no checking-cost improvement is asserted.

## Controlled resource allowance and focused interfaces

`Orbifolds.Intensional.TrivialActionTorsorMaps` passed its complete ordinary
native gate in 10.421 seconds, maximum RSS 398200 KiB. Native and wrapper
exits were zero; successful guards, stable matching canonical/staged source
hashes, all 13 closure entries, its own Finished marker and absence of warnings
were reviewed. The actual invocation uses the pinned safe ordinary flags,
including without-K, with no Cubical library or cohesion flag. Hold it fixed.
This accepts literal G×Z torsor maps and their stated equations, with actual
continuity/equivariance/anchor data; it does not accept the separate pending
finite-action comparison or nontrivial gluing. The argument and hypothesis
boundary are in [Descent](../math/descent.md#literal-trivial-torsors-and-arrow-families).

The user approved a modest resource increase followed by measured, local
proof-interface improvements. `environment.json` owns the actual 6G allowance.
The runtime handoff needed a minimal correction: `tools/myers.py` supplied that
setting, but `tools/native/run_check.py` replaced it with a literal 4G. The runner
now accepts one validated positive M/G allowance from the single configuration.
Its reviewed change affects only that argument and GHCRTS construction; compiler,
library, streaming checker, guard, leases, mode flags, timeout and acceptance
conditions are unchanged. The helper has an explicit new pin. Existing receipts
retain their actual historical settings. Regression tests exercise the real
runner's outgoing environment and malformed allowances, including nonacceptance
without a receipt.

The unchanged-source baselines explicitly exhausted 6G: the full pullback functor
in 411.963 seconds, and the identity-family public target in 444.950 seconds.
The former included cold dependencies; the latter was warm. Their exact sources
and receipts survive in the verified uploaded 094–096 checkpoints. They provide
no evidence of previous successful versions of those full targets. Subsequent
SIGKILL diagnostics contain no heap-exhaustion message, no guard refusal and no
identified sender or cause, and finished before the configured deadlines. Do not
infer an OOM kill, environment downscale or performance improvement from them.
A bounded declaration/profile attempt used `tc.decl:5` and definition profiling,
produced no declaration trace or final table, and its options were removed.
The pinned [declaration-checker source](https://hackage-content.haskell.org/package/Agda-2.8.0.2/docs/src/Agda.TypeChecking.Rules.Decl.html)
puts general declaration entry at level 10; level 5 covers selected named actions.
These declaration-verbosity reports require a DEBUG-enabled binary, as shown in the pinned
[debug implementation](https://hackage-content.haskell.org/package/Agda-2.8.0.2/docs/src/Agda.TypeChecking.Monad.Debug.html).
The supplied resource handoff and a direct inspection of the same pinned
executable establish that its version reports optimise-heavily and
use-xdg-data-home, with no debug flag; its help says that verbosity requires
a debug build. Do not repeat unsupported higher-verbosity attempts or infer
a declaration location from an absent end-of-run table. No compiler hotspot
has been established. No old interface cache was copied during the restored
dependency rebuild. Definition profiling's final table is not a live trace
and cannot be produced after an unhandled SIGKILL.
The new substantive checks use the runner's existing import trace and RTS
allocation/GC statistics. These give module boundaries and whole-process
measurements, not a declaration hotspot.

Hold `LocallyTrivialPrincipalBundleFunctor` fixed. Its complete native gate passed
in 4.962 seconds, maximum RSS 428844 KiB, with successful guards, stable source,
an exact checked-copy match and its target Finished marker. It constructs both
whole-arrow laws and the final record from actual object/whole-arrow maps and
pointwise equations. Its data projections remain transparent, with explicit
computation equations. It was verified and uploaded in 096 before use.

`LocallyTrivialPrincipalBundleHomExtensionality` has passed its complete native gate.
For arbitrary actual bundles and whole continuous equivariant arrows, its
abstract `ordinary-hom-ext` composes the accepted Cubical Hom extensionality
with `pathToId` before any concrete pullback specialization. The gate finished
in 64.933 seconds, maximum RSS 2010004 KiB, including cold bundle dependencies,
with successful guards, stable matching sources/copies and its own Finished
marker. Hold it fixed. No category value, desired whole-arrow law or
continuity conclusion is supplied as an input. The accepted bundle, arrow,
value and generic-functor owners remain fixed. Both concrete law proofs now
instantiate this checked ordinary equality interface at their exact original
whole-arrow endpoints, using the unchanged accepted value equations. Their
revised IdentityLaw gate explicitly exhausted the configured 6442450944-byte
heap after 297.276 seconds, native and wrapper exit 251, maximum RSS
6530740 KiB, with stable matching sources/copies, no guard refusal and no own
Finished marker. It remains pending; do not repeat this unchanged gate.
The revised CompositionLaw gate remains pending. The generic success does
not accept either concrete law, and no declaration hotspot is established.

The concrete whole-arrow identity and composition proofs now have independent
owners, `CechTorsorBundlePullbackIdentityLaw` and
`CechTorsorBundlePullbackCompositionLaw`. Each uses the accepted value equation
and checked ordinary whole-Hom extensionality, with both whole-arrow
endpoints supplied explicitly. The helper owns the original successor-level
path conversion. Neither supplies a category value to a generic functor
constructor or assumes a whole-arrow law. Verified uploaded 120 preserves
the preceding sources and their native -9/wrapper 247 diagnostics; those
receipts do not apply to these revised proofs. No resource improvement or
declaration hotspot is inferred. `CechTorsorBundlePullbackLaws` retains its literal statements as typed
delegates. The public `CechTorsorBundlePullbackFunctor` source remains unchanged,
with its literal object/arrow aliases and transparent copattern fields. Its gate
and the revised Laws facade remain pending until the actual prerequisites pass.

Verified uploaded 105 preserves the previous combined Laws source and completed
6G diagnostic: native -9/wrapper 247 after 294.858 seconds, maximum RSS
6032520 KiB, stable matching sources, no heap-exhaustion message, no target
Finished marker and no identified kill cause. That receipt does not apply to
the changed facade. The separation gives two meaningful theorem boundaries;
no declaration hotspot or performance improvement has been established.
`CechTorsorBundlePullbackValues` passed its complete native gate in 32.131 seconds,
maximum RSS 468400 KiB, with successful guards, stable matching source/copies and
its own target Finished marker. Hold it fixed. It evaluates arbitrary actual
restricted arrows and derives identity/composition values from that equation;
the evaluation proof has its own named-module opacity boundary. Verified
uploaded 099 preserved its acceptance before it was used by the concrete
functor. Its success alone does not accept the concrete functor.

`DependentSheafIdentityReflexivity` retains the literal actual section. Its
certificate proof has been revised through the explicit proposition-family
section comparison described under Mechanized source admission below.
Its certified pair remains in the named abstract child
`Certified`, with a whole-term `term-construction` equality to that exact pair.
The original certified decoding equation and proof remain outside the child.
This intentionally replaces external judgmental pair reduction with explicit
whole-term computation. Review found no current caller requiring that reduction;
the actual section, certificate statement, public term type and decoded value
are retained. The preceding source's complete 6G/900-second gate ended with
native -9/wrapper 247 after
293.928 seconds, maximum RSS 6250384 KiB, stable matching sources and no target
Finished marker. There was no heap-exhaustion message or identified cause of
the kill. Uploaded 122 preserves that source and receipt; they do not apply
to the current changed certificate proof. Verified uploaded 100 preserves the
earlier transparent-pair source and its separate diagnostic.
The existing public `DependentSheafIdentityFamilies` reexports the same API and
retains the literal ordinary identity-elimination and full term/equality
inverse-law bodies. Both targets remain pending. The full public target was
not rerun because the actual constructor remains pending. No declaration
hotspot or cost improvement is inferred. The unchanged independent chart-code
target has also been tested under the current allowance, as recorded below.
The constant-count construction now has a separate actual context-comparison
owner, followed by the displayed-family and term owner described below. Both
new gates remain pending; the context gate's current diagnostic is recorded
below and the family gate remains blocked behind it. The accepted repeated-
term-pairing theorem is preserved in uploaded 110; the separate certified-term
substitution-law source has also been revised through those pairing equations
and has now passed its complete native gate as described below.

These changes retire no source path and alter no accepted construction owner.
The actual section map, all theorem statements, particular display/factor
triangles and universe bounds are retained. The mathematical arguments and
opacity rule are in Presheaves and Descent. Inherited UnsupportedIndexedMatch
warnings remain visible; no unrestricted computation on transports is claimed.

## Completed concrete dependent truncation elimination

The concrete relative-image eliminator has passed its complete native gate.
Hold `SheafTruncationImage`, `SheafTruncationMotive`,
`RelativeSheafImageSections`, `RelativeSheafImageTerms`,
`RelativeSheafImageTermSubstitution`, `DependentFamilyTotalNaturality`,
`DependentSheafTruncationConstruction`, `DependentSheafTruncationEliminationCore`,
`DependentSheafTruncationElimination`, `MonicPresheafDisplays`,
`MonicPresheafSectionTerms`, and `DependentPresheafSections` fixed.

The complete public gate finished in 3308.302 seconds, with successful guards,
stable sources, matching checked copies and its target Finished marker.
It checks the actual Context specialization, certified computation, uniqueness,
both section/branch inverse laws, motive restriction and actual source-family
substitution. The general term and source-change theorems and concrete Core
also have applicable completed evidence. Exact identities and acceptance belong
to the ledger and raw receipts, not these timings or the archive serial.

The restricted recursor takes an actual sheaf display with explicit
proposition-valued component fibers and supplies an over-base map and triangle.
The concrete Context supplies `Image.Into.extend`; `section-from-over` uses
that one particular extension. Section, beta, uniqueness and substitution are
outputs. No arbitrary-categorical-monic-to-pointwise-proposition converse,
equality of unrelated witnesses, source universe or desired model is assumed.

The canonical generic owners are RelativeSheafImageSections,
RelativeSheafImageTerms and RelativeSheafImageTermSubstitution. The public
module supplies the actual data and maps. Its unit-square uses associativity,
totalMap-compose, the existing inverse-point-square and the checked total-map
naturality lemma. The independently pulled branch uses the actual motive
pullback and comparison inverse. Compiler, helper, mode and heap settings were
not changed. The unused contingency split was not applied.

Identity/composite source-substitution comparison adapters remain separate
future work; the exact image-chain and family-transport boundaries are in
[Presheaves](../math/presheaves.md#repeated-source-substitution-comparison-boundary).
The optional SheafTruncationExtension/Sections route and the stronger
SheafTruncationCategoricalImage adapter retain their own pending gates and
are not premises of this checked constructor. Continue with the bridge below.

## Approved finite-branch source/model/classical bridge

Continue with the actual bundle and quotient constructions:

1. Keep the `OrdinaryGroupoidCompletionNaturalityLaws` and
   `OrdinaryGroupoidCompletionTransformationComparison` proof bodies fixed.
   NaturalityLaws has passed its fresh native gate after the deliberate
   Coherence computation-export addition above, including Naturality in
   its exact closure. TransformationComparison has also passed its own
   fresh gate against that changed dependency. The former
   checks identity and vertical composition for the constructed
   natural-transformation homotopies.
   The latter lifts actual component
   equations between transformations of the same two functors to equality of
   their completed homotopies, including quotient-object computation.
   Generic pre/postcomposition compatibility is now accepted in
   `OrdinaryGroupoidCompletionWhiskering`, using the checked
   object-computation exports of the existing abstract map corrections.
   The corrections' unit/associativity laws and bundle/sitewise coherence
   remain separate.
2. Hold `LocallyTrivialPrincipalBundleGroupoid` and
   `LocallyTrivialPrincipalBundleCompletion` fixed: both complete native gates
   and strict raw-evidence reviews passed. The former constructs continuous
   inverse bundle arrows under explicit mere coverage; the latter completes
   this actual groupoid at its stated universe level. Each has its own target
   evidence, beyond the bundle category and generic completion.
3. Hold `CechTorsorBundlePullbackArrows` fixed: its complete native gate and
   strict raw-evidence review passed. It owns the actual restricted-arrow,
   cone and continuity construction. `CechTorsorBundlePullbackFunctor` reexports
   it through typed aliases and retains both whole-arrow functor laws and the
   functor record. Independent IdentityLaw and CompositionLaw owners specialize
   Hom extensionality with the checked pointwise equations; the Laws facade
   delegates to them. Those gates and the transparent public functor assembly
   remain pending. All actual construction APIs remain in the accepted arrow
   owner. No continuity or whole-arrow functor law is assumed, and no compiler
   hotspot has been established.
4. Check the source-written `CechTorsorBundlePullbackIdentity` and
   `CechTorsorBundlePullbackComposition` after their pullback-functor dependency.
   Both construct continuous arrows, whole-Hom inverse laws and natural
   transformations, retaining explicit base openness and locality. The composite
   uses the direct cone and two successive reverse cones. The separately
   source-written unit/triple `CechTorsorBundlePullbackCoherence` target retains
   its own pending gate.
5. Hold `CechTorsorBundleBaseChange` fixed. The actual five-line scope correction
   passed its complete native gate and strict raw-evidence review. It renames
   the two nested carrier facades `Fine` to `Refined` and their three Carrier
   references, retaining every proof body and original owner/parameter tuple.
   It is not a prerequisite of the pullback functor or its comparisons; those
   two comparison gates were skipped for their still-pending Functor dependency.
6. Check the independently reviewed, source-written
   `CechTorsorBundlePullbackCoherence` after its actual comparison prerequisites.
   Its two unit and triple equations assign each actual component a common
   whole-Hom type before extensionality, with canonical continuity certificates
   and explicit base capabilities. It does not identify arbitrary topology or
   functor proof records.
7. Connect those actual comparison arrows to quotient-map homotopies and the
   categorical local-data/bundle comparison, retaining total projections,
   independent anchors, selected arrows, refinement and parameter squares.

Hold `LocallyTrivialPrincipalBundleIsotropyControl` fixed: its complete native
gate passed with applicable raw evidence. It explicitly constructs the
regular bundle on a one-point/full-open cover, whole continuous left-action
arrows and unit-evaluation separation, then a nontrivial completed loop using
the checked hom/path inverse laws. Its concrete instance uses the existing
nonidentity permutation. The topology and continuity fields are constructed,
and its constant anchor has only the explicit preservation law; it supplies
no anchored category or action-quotient comparison.

The isotropy run retains the redundant `HLevels` import warning for
`isProp→isSet` in unchanged `CechTorsorControls`. Its actual source and warning
match that dependency's accepted receipt in the supplied 056 archive; the
symbol is imported from `Prelude` and its use is checked. The auxiliary
zero-export-warning assertion flagged this inherited warning after the native
success; explicit review verified every canonical guard, checked-source match,
zero native/wrapper exit and the target's Finished marker. No warning was
suppressed, checker changed or accepted dependency edited.

The constructions and comparison design are in
[Descent](../math/descent.md#independent-pulled-total-topology-and-continuous-cones).
The quotient arguments are in [Source interpretation](../math/source-interpretation.md).
The bundle completion works at `suc ell` and retains the corresponding bounded
`Code` and `Truth` levels. It supplies neither finite branch charts nor an action
target and does not resize the quotient. Restricted set-model admission and
realizing nontrivial isotropy are distinct obligations.

### Mechanized source admission

The three-file ordinary-source audit is already in
[Source interpretation, Section 5](../math/source-interpretation.md).
The first concrete admission boundary is the actual code-valued `predicate`
field of `chart-subfinite-witness`: construct small sum and identity codes,
their decoding comparisons and compatibility with contextual substitution.
An external family with the desired fibers is not this source judgment.

The proposition-code construction and restricted classification now have
complete native evidence. Hold the checked sources fixed:

- `SieveCodeExtensionality`, `ExternalPropositionCodes`,
  `ExternalPropositionCodeSums` and `ExternalPropositionCodeSumCongruence`:
  actual closed-sieve codes, their small decodings, inverse laws,
  all-probe sum construction and transported decoder comparisons.
- `ExternalPropositionCodeAmalgamation`, `MixedLevelSheaves` and
  `PropositionCodeSheaves`: actual code gluing and both code/decoded sheaves
  with distinct value levels, their display and its specified small fibers.
- `ExternalPropositionCodeSumComparison`, `DependentSheafSumBaseChange` and
  `ExternalPropositionCodeSumSubstitution`: actual sum-family/code comparison,
  chosen first/second-family base change, and code substitution with its
  decoder square naming the actual inverse map.
- `PropositionCodeFamilyPullback`: the actual small total as a heterogeneous
  pullback, with arbitrary value-level test presheaves, both triangles and
  uniqueness.
- `PropositionCodeDecodingFamily` and `PropositionCodeClassification`: the
  actual small family from a code map, its own total-sheaf certificate,
  whole code-map recovery and family-isomorphism recovery with both inverse
  laws and actual total/display comparisons.

The listed code/sheaf/comparison gates completed with successful guards,
stable sources, matching checked copies and their own target Finished markers.
Their scope is the specified small proposition families over a fixed small
context. Code values stay at `suc ell`, decoded fibers at `ell`, and their
record levels remain explicit. Family recovery is an isomorphism retaining
sheafhood certificates; no arbitrary-monomorphism converse, general resizing,
full source universe, CwF, J or extra contextual coherence is supplied.
The arguments and exact operations are in Source interpretation.

The independently reviewed identity ownership split is source-written.
`DependentSheafIdentityFiberComparison` passed its full native gate and strict
raw-evidence review; hold it fixed. It owns the complete actual
equalizer/display construction through `Pair.reflect`, including the encoding,
decoding, both inverse laws, propositionhood and certified-term reflection.
`DependentSheafIdentityReflexivity` retains the literal section, the opaque
certified pair with its explicit whole-term computation, and the unchanged
decoded computation. Its certificate proof now constructs a proposition-family
term from the actual identity encoder at refl, compares its whole section map
with the existing equalizer/factor-based section, and transports the constructed
certificate along that comparison. The original section's base computation is
proved before, and independently of, either certificate. The only new prerequisite,
`DependentPropositionFamilySections`, constructs naturality, a global section,+a certified term, component/value equations and uniqueness from an actual
proposition-valued family and explicit elements at every stage/context point.
It assumes no choice from mere inhabitance or desired certified term. Its
complete native gate passed in 6.710 seconds, maximum RSS 391792 KiB, with
zero native/wrapper exits, successful guards, stable matching sources/copies
and its own Finished marker. The full log retains 13 inherited
UnsupportedIndexedMatch warnings from accepted CompactSeparation,
FiniteEnumeration and FiniteSupportSums, repeated in the final warning summary;
no warning originates in the new owner. They limit computation of the named
indexed-pattern functions on transports and were not suppressed. Hold the
source fixed. The revised concrete
reflexivity constructor now has accepted prerequisites and retains its own gate.
The former source and its diagnostic are preserved in uploaded 122 and do not
apply to this changed certificate proof. The existing
`DependentSheafIdentityFamilies` reexports these operations and retains the
literal ordinary identity-elimination and whole-term-equivalence bodies.
Both new constructor and public gates remain pending. No desired family,
section or equivalence is an input to either constructor.

The public reflexivity/equivalence target remains pending; the current
constructor boundary is described above. The actual section map and full
statements stay fixed, and no desired
term is an input. `ExternalPropositionIdentityCodes` passed its own full native
gate and strict raw-evidence review after redirecting only its identity import
to the checked fiber theorem. Hold this caller fixed. BaseChange still needs the
full Public reflexivity theorem. This is a useful mathematical ownership
boundary, not a claim about a located compiler hotspot; the compiler,
proof-mode boundaries and safety checks remain fixed.

After the Public gate, check `DependentSheafIdentityBaseChange` and
`ExternalPropositionIdentityCodeSubstitution`. The latter retains both endpoint
paths in substitution; the separate identity-code constructor is already checked
as stated above. These two substitution targets remain pending. The independently reviewed
`ExternalPropositionChartPredicateCodes` and
`ExternalPropositionChartPredicateSubstitution` are source-written and pending.
The unchanged code constructor's 6G/900-second gate ended with native -9 and
wrapper 247 after 685.409 seconds, maximum RSS 5004376 KiB, with stable matching
sources and no target Finished marker. There was no heap-exhaustion message or
identified cause of the kill. This replaces the old 4G timeout as its current
applicable diagnostic; no source change or performance improvement is inferred.
It retains all public statements and
constructor/decoder/map bodies, opens the actual checked fiber owner directly,
and keeps the same identity characteristic code and substitution endpoint.
These modules construct the actual domain-and-endpoint-equality
code, explicit decoder/encoder, mixed natural map and substitution square,
retaining both endpoint paths and the identity-probe transport. Their actual
families and certified terms are inputs to this restricted constructor, not an
assumed interpretation of the generic source context. Admission of that typed
source judgment remains further work; there is still no code for arbitrary Y
or a constructed full source universe.

Hold `DedekindFiniteLabelFamilies` fixed: its complete native gate and strict
raw-evidence review passed. It constructs the actual varying finite-label
display on the Dedekind site, its pullback along an arbitrary branch-count map,
the exact stage-fiber equivalences, and the certified generic variable with
its pair-variable equation. The total label set uses general Sigma sethood;
Fin fibers are not assumed proposition-valued. Values stay at level 2 and
sheaf/family records at level 3.

Three additional restricted adapters are now source-written and pending.
`DedekindFiniteLabelContextBaseChange` constructs actual lifted label-context
maps, their display squares, the direct/iterated family and total-sheaf
isomorphisms, both inverse laws and the certified variable. Every existing
prerequisite is accepted. Its complete 6G/600-second gate timed out after
599.890 seconds, maximum RSS 2032992 KiB, native -15/wrapper 124, with stable
matching sources/copies, no guard refusal and no own Finished marker. No
heap-exhaustion message or declaration timing was reported. It remains pending;
do not repeat the unchanged gate or infer a declaration hotspot.
`DedekindFiniteLabelChartPredicate` constructs both endpoint weakenings,
a certified target from an actual natural section, the literal proposition,
its specialized code and both decoding inverse laws, including a canonical
variable endpoint instance. `DedekindFiniteLabelChartPredicateSubstitution`
constructs the actual label/domain lifts, endpoint comparisons, code and
decoder squares, and direct/iterated label-code comparison. The latter two
retain pending chart-code/substitution prerequisites; the substitution owner
now uses the accepted certified-term substitution laws. All three were
reviewed for preservation, not native acceptance. Small contexts and decoded
predicate values are at level 2, sheaf/family records at level 3, and the
proposition codes retain their successor level. DirectCodes compares generic
chart substitution along the actual direct lift; comparison with an
independently rebuilt PredicateBase.Context on B′ with Y[τ] and endpoint[τ],
full identity/composition coherence and generic BranchChart admission remain
further work. These adapters do not depend on the failed constant-count gate.

`DedekindConstantCountLabels` passed its complete native gate in 6.557 seconds,
maximum RSS 416272 KiB, with successful guards, stable matching source/copies
and its own target Finished marker. Hold it fixed. It constructs the actual
label pullback/Fin equivalence, the Fin small-set certificate by a retract,
and both whole inverse laws for its locally constant sheaf maps.
`DependentPresheafComprehensionComputation` passed its complete native gate in
3.244 seconds, maximum RSS 258024 KiB, with successful guards, stable matching
source/copies and its own target Finished marker. Hold it fixed. It computes
the existing read term's
value from its actual over-base equation, removing only its certificate loop
by the context presheaf's value-set. Both small prerequisites are now checked.

`DedekindConstantCountContexts` now owns the actual construction through
label-computation: the constant count, actual family/context/projection,
terminal-leg pullback change, direct display-base-change comparison, context
isomorphism, both inverse laws, display equations and original-label equation.
Its only mathematical input is k:Nat. Data and maps remain transparent.
TerminalChange specializes the accepted generic constructor. The current
revision replaces only the private categorical isomorphism tower and its
four projected inverse proofs by componentwise cancellation using the actual
accepted TerminalChange, LocalPullback, Labels and Change inverse equations,
followed by PS.nat-ext. All public maps, statements, sheaves, sheafhood
certificates and levels remain unchanged; inverse-law proof terms are
deliberately replaced, not asserted judgmentally identical. fromNatInverse
still packages the actual sheaf isomorphism. Its revised complete
6G/900-second gate ended with native -9/wrapper 247 after 580.951 seconds,
maximum RSS 6427628 KiB, with stable matching sources/copies, no guard refusal
and no own Finished marker. The run rebuilt the real/sheaf dependencies,
including DependentPresheafSections, and their Finished markers are present.
There is no heap-exhaustion message or identified kill cause, and no
per-declaration timing. The target remains pending; do not repeat this
unchanged gate. Verified uploaded 120 preserves the preceding source and
its different diagnostic, which does not apply here. No hotspot or cost
improvement is inferred from either the source review or these runs.

`DedekindConstantCountFamilies` reexports every prior public context result and
retains the literal constantFamily-through-end proof bodies: the displayed-
family isomorphism, stage equivalence with locally constant Fin-k sections,
certified read term, computation, uniqueness and original-variable compatibility.
The exact Along.Variable and Variable APIs are specialized only here. The
context owner's support exports are the actual intermediate pullback, maps and
inverse laws; the family Change facade uses the identical accepted tuple.
No construction is supplied as a desired output or duplicated. The full gate
remains pending behind the context gate. Values and sheaf/family record levels
remain 2 and 3 respectively; differently reindexed families are not identified.

Verified uploaded 111 preserves the complete source before this ownership split
and its applicable full 6G/900-second diagnostic: native -9/wrapper 247 after
49.733 seconds, maximum RSS 4123340 KiB, stable matching sources, no guard
refusal, no target Finished marker, no heap-exhaustion message and no identified
kill cause. That receipt does not apply to either revised gate. Verified uploaded
107 retains the earlier source's explicit 6G heap exhaustion. The new checking
boundary establishes no declaration hotspot or performance improvement.
All previously accepted owners remain fixed.

`SheafPullbackLegIsomorphism` passed its complete native gate in 1.648 seconds,
maximum RSS 151988 KiB, with successful guards, stable matching sources/copies
and its own target Finished marker. Hold it fixed. From the
actual four sheaves, three cospan arrows, one leg isomorphism and one commuting
equation, it constructs both actual pullback lifts, their four projection
triangles, both whole inverse laws and the resulting isomorphism. The inverse
leg square is derived, not supplied. Verified uploaded 107 preserved its
acceptance before the concrete specialization changed. The argument and
equality-witness boundary are in
[Presheaves](../math/presheaves.md#changing-one-leg-of-an-actual-sheaf-pullback).
No hotspot or performance benefit is inferred before the concrete gate.

The construction and the pending restricted context/endpoint adapters are in
[Source interpretation](../math/source-interpretation.md#varying-finite-labels-and-the-actual-endpoint-variable).
`DependentTermPairComposition` passed its complete native gate in 26.856 seconds,
maximum RSS 600260 KiB, with successful guards, stable matching sources/copies
and its own target Finished marker. Hold it fixed. It proves both whole pairing
equations through the actual single/repeated-family comparison maps. Its
component argument retains the section's actual output base; no computation of
its section certificate is assumed. The argument is in
[Presheaves](../math/presheaves.md#pairing-across-repeated-reindexing).
`DependentTermSubstitutionLaws` now retains its exact public identity/composition
statements but uses actual whole pairing maps. Identity compares the family-map
section with the identity comprehension pair, then uses substitution-pair and
right identity. Composition uses the accepted PairComposition inverse equation,
the two actual substitution-pair equations, associativity and comprehension
pair-injectivity; the accepted term-map forward-inverse law returns through the
same actual once/twice family comparison. All prerequisites, including
DependentTermPairComposition and DependentTermMapLaws, are accepted. Its revised
complete 6G/900-second native gate passed in 515.680 seconds, maximum RSS
1156228 KiB, with zero native/wrapper exits, successful guards, stable matching
sources/copies, all 31 closure hashes and its own Finished marker. Hold it fixed.
Thirteen inherited UnsupportedIndexedMatch warnings from CompactSeparation,
FiniteEnumeration and FiniteSupportSums remain in the log and final warning
summary; none originates in this owner. Uploaded 122 preserves the former source and its
599.873-second timeout (native -15/wrapper 124, maximum RSS 550936 KiB); that
receipt does not apply to these revised bytes. Source review establishes no
declaration hotspot or checking-cost improvement. These generic laws do not
accept the pending concrete count or chart-code constructions.
The endpoint adapter still needs the chart-code gates above; its generic
endpoint composite-weakening law is now accepted. These constructions do not admit the
larger generic universe-valued BranchChart context or supply an NNO eliminator.

`DependentTermSubstitutionEquality` is now source-written and pending its
complete native gate. For an actual equality p:sigma=tau of context maps, it
proves that the actual contextMap(p) sends the complete substituted term
along sigma to the complete substituted term along tau, in the literal
target family A[tau]. Ordinary identity elimination leaves the accepted
term-map identity law at refl; it needs no K or strict identification of
family records. All existing prerequisites are accepted, and it does not
import SubstitutionLaws. It is one precise missing middle step in the
independently rebuilt finite-label context proof plan in Source interpretation;
the full reconstruction adapter, code comparison and admission remain separate.

`UnivalentUniverseSetBoundary` passed its full native gate with successful
guards, stable sources, an exact checked-copy match and target Finished marker.
Hold its source fixed. From a supplied self-path/automorphism equivalence
at one code, it derives equality of whole automorphism witnesses when the code
loops are propositions; two explicitly distinct automorphisms then obstruct
sethood of the code type. Code and value levels remain separate. It is a
conditional universe audit, with no Boolean-sheaf existence, resizing, source
universe or model construction input hidden in the statement.

Typed admission must cover the actual declarations and proof: dependent
functions/types, inductive identity and J, finite indexing, explicit lifts,
function extensionality and the specified bounded truncation. Do not supply
the missing universe or operation-preservation laws as an assumed model.
The user's current-source and GitHub-issue review is complete. The selected
conaled reference is refreshed to the resolved, rechecked master tip; exact
commit and all 76 selected blob identities are in `environment.json`. All 50
previously retained files are unchanged. The new #528 compositional univalence
and dependent-transport owners, their example/report, mixed-change interfaces
and generic manifold/action comparison prerequisites are retained and reviewed.
The supplied upstream acceptance report is distinct from a local Lean build or
an Agda interpretation; our source ledger stays 977 accepted / 60 pending.

The prioritized upstream handoff is existing open #529: arbitrary larger-context
Sigma/Pi/Path codes, decoding/filling/substitution and dependent pair/function
transport, with an actual varying finite-label nested Sigma/Path client. The
signature-level gap, exact client, complete copyable prompt, secondary generic
finite-action adapter and already-completed work are recorded in
[the handoff](../math/conaled.md#compositional-univalence-and-selected-transport).
No upstream message, issue, comment, commit or fresh local Lean build was made.
This review adds reusable reference mathematics; it accepts no pending Agda
target and does not change the crisp, universe or properness boundaries.

Then construct the smooth/formal instances, finite-action geometric inputs,
atlas lifts and classical comparison. Preserve ineffective isotropy and the
absence of a global chart choice. The trivial-group real-line control must not
require unrestricted internal DP-properness of its diagonal. The broader goal
still includes the stated manifold microlinearity, higher quotient/descent and
general proper-etale finite-bisection construction.

## Separate joint-foundation audit

`DedekindBooleanUniverseSetBoundary` passed its complete native gate in
5.234 seconds, maximum RSS 284420 KiB, with successful guards, stable sources,
exact checked-copy match and its own target Finished marker. Hold it fixed.
It takes one
explicit code, a decoding equivalence to the actual whole-open Boolean section
type, and a self-path/self-equivalence comparison. The checked equivalence
conjugation transports both actual distinct automorphisms and their separation;
the existing conditional boundary then forbids proposition-valued code loops
and sethood of the code type. No code, decoder comparison, univalence rule or
model is constructed or silently assumed as an achieved result. Code and value
levels remain independent, with the actual section level fixed at 2.

`DedekindBooleanSheafAutomorphisms` passed its complete native gate in
209.440 seconds, maximum RSS 1220528 KiB, including a cold rebuild of its
real-analysis dependencies. The raw receipt has successful guards, stable
sources, an exact checked-copy match and the target's own Finished marker.
Hold its source fixed. It constructs the actual lifted-Boolean locally constant sheaf,
identity and flip self-isomorphisms, both inverse laws, and their separation by
the constant-false section evaluated at zero in the whole open. Its whole-open
section type also has two explicitly distinct whole self-equivalences. It uses
the accepted constant-sheaf functor and leaves that owner fixed. This supplies
no universe code or self-path comparison, and must not be substituted for an
internal decoder premise. The argument and universe bounds are in
[Source interpretation](../math/source-interpretation.md).

The inherited CompactSeparation, FiniteEnumeration and FiniteSupportSums
UnsupportedIndexedMatch warnings remain in the log. The observation equations
are the checked concrete whole-open/zero-point computations; no unrestricted
computation on transports is claimed, and no warning or safe check was removed.

Keep the checked `WeilShapePowerComparisonObstruction`,
`TinySelectedSourceRetraction`, and `WeilSelectedSourceIncompatibility` sources
fixed. They retain the actual comparison collision, its exact tininess
implication, and the smaller five-comparison selected-root left inverse and
Weil specialization. The argument and separation of premises are in
[Joint obstruction](../math/joint-obstruction.md) and
[Real sheaves](../math/real-sheaves.md#five-comparisons-for-a-left-inverse).

The remaining interpretation work must account for native crisp dependence
and substitution, the crisp identity rule and computation, actual modal/higher
constructions and their universe levels. A revised foundation must state which
premise or derivation of that same comparison changes. These conditional
incompatibilities do not construct a corrected model or refute the independent
finite-action theorem.

For a proposed revised tininess interpretation, audit the actual
`TinySelectedTargetLocality.Context.comparison Z ω v = evaluate (ω ∘ v)`.
Here `Compared Z = isEquiv (flat-map (comparison Z))`; retain this Flat
boundary rather than replacing it by an unflattened comparison.
At X = T and source Shape(T → T), determine which of the selected-root
`FiveComparisons` the interpretation derives: at-root, at-root-product,
at-paths, at-paths-product and at-source, with their exact universes and
computation/substitution laws. The checked selected-source incompatibility
prevents supplying all five under its unchanged remaining premises. The
new sheaf and certified-term results supply no revised interpretation and
do not identify a failed comparison field.

## Other constructor comparisons still required

`DependentFamilyDisplayTermSubstitution` retains the actual family/display
term-substitution square and term equivalence. Its full 6G/900-second gate
exhausted the configured 6442450944-byte heap after 295.131 seconds, native
and wrapper exit 251, maximum RSS 6793576 KiB. The completed receipt has stable
matching source/copies, no guard refusal and no target Finished marker.
It remains pending; do not repeat the unchanged gate. Its four-step term proof
uses the accepted map naturality/composition and actual encode-substitution
square; it does not depend on the pending generic
`DependentTermSubstitutionSquare` or the now-accepted term-substitution laws.

The user supplied the complete resource-005 handoff, 12257203 bytes, SHA256
`a560e9e055ae2db789e6f2b0281b19fb2b89ca7ddf2ad61ebd429830023e7ba9`,
and its source patch, SHA256
`451f3940dbf8fa521b424ef8ede36042910af727f1c75845b1e4d42cbc963c6a`.
The verified archive is an independent continuation from 115. Its only Agda
change relative to that base is the reviewed `SheafFamilyDisplayRecovery`
repair. Adopt its exact source
`7a8e94c3dd8b17ec57e6791e35cbd5c9f7e731fa392c428fac0d38d92f4bf455`;
retain this continuation's newer work, ledger, tools and checkpoint sequence.
The environment and all four native helpers are byte-identical. Its optional
diagnostic-progress and resource-archive-name packaging changes are unnecessary
for this integration and are not adopted.

The actual Recovery maps and theorem endpoints remain. Generic FamilyMap.lift
checks total-map conversion while both sheaf families are variables. Explicit
inverseIso retains the existing comparison isomorphism's maps, inverse laws and
distinct sheaf certificates. Component projection in the original presheaf
carriers followed by nat-ext proves the same two complete map equalities.
The complete receiving-tree 6G/600-second gate passed in 49.248 seconds,
maximum RSS 1633032 KiB, with native/wrapper exit zero, successful guards,
stable matching source/copies and its own Finished marker. All 37 closure
hashes were reviewed. The 13 inherited UnsupportedIndexedMatch warnings from
CompactSeparation, FiniteEnumeration and FiniteSupportSums remain; none
originates in this target. Hold the accepted Recovery source fixed.
Uploaded 126 retains the old
source and its exact 6G heap-exhaustion receipt; that receipt does not apply
to the changed source. No declaration hotspot is inferred from the repair.

The supplied branch's full Recovery and Comparison gates passed at 6G, but
their acceptance was not copied into this ledger. Both now have fresh
complete receiving-tree gates.
The supplied Comparison log also
contains a ModuleDoesntExport warning for `using (Context)`: Context is a
module. After verified uploaded 127 preserved Recovery, the single selector
was changed to `using (module Context)`, following the existing accepted
truncation facade. The complete receiving-tree Comparison gate passed in
99.566 seconds, maximum RSS 2378308 KiB, under the unchanged 6G/600-second
bound. Native/wrapper exits are zero, guards succeeded, source/copy hashes
match, and its own Finished marker is present. The ModuleDoesntExport warning
is absent; the 13 inherited UnsupportedIndexedMatch warnings remain.
All other Comparison source bytes and actual constructions are unchanged.
Hold both accepted owners fixed. This adopts the concrete resource repair
without claiming that other pending resource failures have been resolved.
A family-level square
or presheaf equivalence does not certify the separate whole certified-term
substitution equation or a full model.

Connect the constructed display-based identity eliminator to the actual
category-of-elements comprehension, existing identity family and simultaneous
substitution. The endpoint, compatibility, identity-context, arbitrary-motive J,
substitution and reflexivity targets remain distinct. Use the actual pullback
comparison and equalizer universal properties with explicit maps and triangles;
do not identify the representations silently or replace higher identities by
propositions. The arguments are in [Presheaves](../math/presheaves.md).

`DependentReindexedTotalExtensionality` passed its complete native gate in
1.690 seconds, maximum RSS 198940 KiB, with zero native/wrapper exits,
successful guards, stable matching sources/copies and its own Finished marker.
Hold it fixed. The log retains 13 inherited UnsupportedIndexedMatch warnings
from accepted CompactSeparation, FiniteEnumeration and FiniteSupportSums,
repeated in the final warning summary; none originates in this owner.
From the actual reindexed-total pullback comparison and its constructed
injectivity, it proves joint monicity of the actual display/lift at values
and then equality of whole natural maps. It assumes no joint-monicity
conclusion. The separate IdentityEndpoints gate remains a prerequisite
for endpoint compatibility and its sheaf specialization; neither identity
interpretation nor arbitrary-motive J follows from this helper alone.
Its unchanged complete 6G/600-second gate timed out after 599.841 seconds,
native -15/wrapper 124, maximum RSS 668412 KiB, with stable matching sources
and checked copies, no guard refusal and no own Finished marker. The guard
success chain was false. The repeated-context prerequisite finished; there
was no heap-exhaustion message or declaration timing. The endpoint source
remains pending; do not retry it unchanged.

The product/sum/term and Cartesian-open/smooth/action queues remain visible in
the source ledger. They are not discharged by truncation or bundle milestones.

## Applicable diagnostic blockers

These entries describe retained current diagnostics, not acceptance. Read their
raw evidence before choosing another attempt.

| Target | Retained diagnostic | Consequence |
| --- | --- | --- |
| `DependentTermSubstitutionSquare` | Completed 179.254-second timeout; wrapper 124; stable source and exact checked-copy match. | Resolve a concrete source/interface issue before repeating the same bound. |
| `SheafTruncationExtension` | Completed 899.842-second timeout; wrapper 124; stable source and exact checked-copy match. | Optional route; do not make it block the direct constructor. |
| `FiniteActionTrivialTorsorComparison` | Completed unsuccessful run at 41.668 seconds; wrapper 247; stable source and exact checked-copy match. | No completed target proof; determine the actual failure before another attempt. |

`DedekindCartesianOpenCategory` remains pending after earlier nested elaboration
work; the current ledger retains no applicable pending-attempt receipt for it.
Do not treat old timing reports as current evidence. Replace these observations
when new applicable results complete; remove superseded diagnostics instead of
appending another chronology. Source, helper, proof-mode and universe boundaries
remain governed by [project.md](project.md) and [environment.md](environment.md).

## Recovery baseline and unresolved archive identity

The current recovery used the user-attached complete checkpoint 115:
12,253,689 bytes, SHA-256
`c9ee6280d3af264b6498cc9821b46c211920c2bca236638a530661993c392c2c`.
Exact snapshot verification, offline pinned setup, doctor and status succeeded.
The recovered ledger had 1,026 sources, 967 accepted and 59 pending. No later
source or proof receipt has been recovered from a separate conversation;
the user's subsequent diagnostic report is context, not native evidence.
This recovery itself establishes no new mathematical acceptance. Current
acceptance continues to belong only to the source-bound ledger and receipts.

The preceding recovery used the user-attached complete checkpoint 093:
12,200,884 bytes, SHA-256
`8ef1d3b917ebb89bbe8f4587b081a5c4f254331a210ab88c4dd1fea90679de54`.
Its manifest and applicable raw evidence were verified directly. The live
workspace had an earlier 1,004-source/949-accepted ledger, with nine source
files absent and four different source files relative to 093; it had no
additional source files. After establishing that both operation and compiler
leases were free, that workspace was retained outside the canonical project
and 093 was restored to the single `myers/` root. Snapshot verification,
pinned setup and doctor succeeded. That restoration began with 1,013 sources,
959 accepted and 54 pending. At recovery, no post-093 proof acceptance had been
established; restoration itself was not mathematical progress. Subsequent
acceptance belongs only to the current ledger and applicable raw receipts.

The original continuation baseline remains the following verified recovery.
The workspace was lost after complete checkpoint 056. The user supplied its
actual archive: 12,002,387 bytes, SHA-256
`e00eae96592db49d68ce0d329b298243b49ce60a3cf3dde0e57b8203e30fe9ae`.
Exact snapshot verification succeeded after restoration to the single canonical
`myers/` root; pinned setup and doctor also succeeded. The post-056 direct-beta
extension attempt has no recovered completed receipt and receives no acceptance.
The later extension edit, BaseChange alias reduction and source-admission
clarification were not recovered as bytes; they were deliberately reapplied
from this verified baseline, not credited as recovered work. Subsequent native
acceptance remains solely in the current ledger and applicable receipts.

The unresolved 035 conflict has two different exact identities. The actual
attached archive was 11,849,540 bytes, SHA-256
`a831566a1b6eb7e0367d3fe213bb0a5e34dd15135783488b297f0e00e905478e`,
from the separate [automation conversation](https://chatgpt.com/c/6af47d58-ce8c-8327-9b92-37636e265f4d).
The later reported same-name archive was 11,905,900 bytes, SHA-256
`db6fc8491edbfdd71fae8218352096f4e2cc4994bfb9af4a57f02ef895a52554`.
The latter bytes remain unavailable here; its reported 950-source state is
neither recovered nor accepted. Preserve both identities without overwriting
by serial number.

The 036 reconciliation used 034's checked source/evidence baseline plus the
recovered `LocallyTrivialPrincipalBundles` module. That source choice is already
incorporated in the current complete project; do not restore 034 as a second
source tree. The attached 035's shared `DependentPresheafTotal` abstraction and
endpoint-export changes, with their receipts, remain in that original archive.
Do not transfer the repeated-context or other receipt across changed shared
source bytes; a deliberate adoption requires rechecking affected closures.
The user confirmed the conversation-linked 035 and reconciled 036 downloadable
in Library. That confirmation does not recover the conflicting reported archive.

Publication, actual upload deadlines, and the mandatory stop/request gate after
loss remain solely in [checkpoints.md](checkpoints.md). No upstream write is
authorized by this queue.
