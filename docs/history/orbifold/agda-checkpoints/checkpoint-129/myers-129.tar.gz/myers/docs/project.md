# Project direction and rules

## Goal

Complete the Myers-oriented Agda development and an actual, explicit bridge to
external smooth/orbifold mathematics. Retain the existing internal results at their
stated hypotheses; build interpretation, substitution and transport rather than
renaming an abstract interface as a model. The paper is a source and comparison
target, not a requirement to preserve a disproved statement or an unsuitable
foundation. A revised theory needs its own explicit definitions and theorems.

Completion requires actual source contexts/types/terms/substitutions and constructor
preservation, coherent universe and modal/crisp interpretations where admitted,
smooth/formal/manifold instances, higher quotient and descent constructions, and
precise external transport. An ambient Rezk quotient, ordinary set-valued sheaf
category, bounded diagram, paper proof, or source review alone is not that result.
The paper correspondence map describes scoped statements and corrections, not a
completion percentage or full semantic soundness theorem.

## Mathematics first; the environment is a means

Research, formalization and the actual source/model/classical bridge are the work.
The execution environment and checkpoint process exist to support that work, not
to become a competing project. Use the documented bounded restore/check path after
an interruption; preserve useful source and evidence promptly, then return to a
specific mathematical obligation. Do not spend repeated work cycles diagnosing
cloud failures, redesigning runners, adding hardening or chasing a perfect runtime.
Fix only what is concretely necessary to restore checking or prevent imminent loss.
When a check is blocked, retain its exact pending status and advance another
mathematical task. This priority never permits weakening proof checks or claiming
success without evidence. A UI status or remembered success is not a receipt.

## Proof discipline

Do not add holes, postulates, unsolved metas, incomplete matches, unsafe compiler
flags, hidden classical principles, resizing, or fields that merely assume the
desired conclusion. Keep logical and geometric hypotheses visible. Do not silently
replace a higher object by its set quotient, finite-free rank by a weaker rank,
crisp binders by ordinary arguments, or a selected cover by all covers.

Construct actual maps, both inverse laws when claimed, their computation equations,
and the relevant restriction/substitution/naturality coherence. Track size and
universe restrictions. A bounded theorem must remain bounded. Explicit classical
premises in an external point-set branch do not become premises of another branch
merely because both files are in the same repository.

Preserve the exact properness obstruction: external `IsProperMap` cannot simply be
identified with unrestricted internal `DPProper` under the displayed synthetic
assumptions. `Compact.ProperData` is another explicitly named predicate, not an
implicit identification with either. A revised transport theorem must name the
admitted predicates and interpretation, the direction transported, and all extra
hypotheses. The obstruction does not refute the external finite-action theorem or
all possible foundations. See the mathematics chapters for the argument.

## Source and evidence ownership

`src/` is the only project Agda tree, including current pending modules. Keep one
current version per module. The original source language modes must stay separated.
The exact pins and native helper identities are in `environment.json`; execution
and packaging procedures are owned by their separate guides, not this document.

`state.json` alone classifies current source bytes as accepted or pending. Retained
raw receipts/logs support that ledger. Missing final receipts, expired checks,
intermediate Finished markers, hashes without source bytes, reports of lost success,
and favorable mathematical review are not acceptance. An incomplete check cannot
be promoted. Existing warnings do not imply unrestricted transport computation or
operational adequacy. Source-level checking is not a consistency or model proof.

Keep useful mathematical arguments in the topical `math/` chapter, not in run logs.
Update `docs/work.md` in place. Do not create successive continuation files. Research
references and selected Lean code remain comparison material unless an actual
verified translation is constructed. Do not send messages, create issues or post
comments to conaled without a user instruction to do so.

## Workspace continuity

Preserve the [checkpoint purpose and structural contract](checkpoints.md) while
advancing this project. That contract protects current useful original source,
mathematics, pending constructions and evidence; it does not freeze definitions or
require retaining a disproved claim. Correct or replace them explicitly, preserving
the scope of the correction and the evidence needed to resume. Mathematical
honesty and the full completion goal are not traded for a smaller archive or a
higher accepted-source count.
