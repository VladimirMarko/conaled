# Checkpoint purpose and preservation contract

This is the sole checkpoint policy, structural preservation contract and creation
procedure. Read it before changing packaging, reorganizing the workspace, or
removing material. It governs the current snapshot, not an accumulating history.

The mathematics-first priority in [project.md](project.md) governs recovery and
packaging too. Avoid environment-hardening detours; preserve actual useful work,
then resume the mathematics. This paragraph is a pointer, not a second work policy.

## Purpose comes first

A checkpoint exists to **prevent loss of substantive work when the execution
environment disappears, and let a new worker resume the actual full formalization
and cross-setting bridge from one coherent, usable, mathematically honest state**.
It must preserve the original current source, useful unfinished work and research,
exact evidence and trust boundaries, necessary environment inputs, and enough
current direction to continue without the preceding conversation or workspace.
It must be independently restorable, inspectable, and runnable on the documented
platform. A source hash without its bytes is not durability.

Everything about checkpoint packaging and organization is secondary to this
purpose: names, serials, compression, size targets, directory choices, convenience,
automation, and even the present structural rules may change when a sufficiently
strong purpose-serving reason warrants it. **Smallness is not a license to lose
code, mathematics, pending work or the evidence needed to interpret them.** Nor is
regular publication an objective in itself. These priorities do not authorize
false proof claims, weakened assumptions, or actions beyond the user's permission.

The defaults below are preserved across successors unless deliberately replaced
through the migration procedure below. They are not a demand to freeze mathematical
content: proofs, definitions, research and priorities must advance. Preserve their
meaning and provenance through an explicit correction or replacement, not an
unnoticed deletion or change of scope.

## Protected organization and single owners

The archive name is short, `myers-NNN.tar.gz`, and its stable root is `myers/`.
There is one current version per concern, never a chain of continuation documents.
The root README is navigation only. The following are concrete preservation
obligations, not optional categories to discard during a cleanup.

| Area / current organization | What must survive; sole owner |
| --- | --- |
| Original formalization | `src/` contains actual authored Agda, accepted and pending together, one canonical module per file/path. Original cohesion, ordinary `Orbifolds.Intensional`, and local Cubical `Orbifolds.SemanticBridge` modes remain distinct. No alternative accepted/candidate/snapshot trees. A future authored Lean component requires an explicit layout/build migration; selected upstream Lean remains under `references/`. |
| Mathematical purpose and discipline | `docs/project.md` owns the full completion goal, axioms/hypotheses, source-mode boundaries, mathematical working rules and external-action permissions. It must not be narrowed to merely checking the current queue. |
| Environment | `docs/environment.md` owns setup/restoration/checking/diagnostics. `environment.json` alone owns exact compiler, Cubical, conaled, Mathlib, native-helper and runtime pins. `vendor/` retains the offline inputs needed by those instructions. Never silently change a pin to an unexamined branch tip or substitute an available compiler. |
| Current effort | `docs/work.md` alone owns the active next steps, blockers and current attempts. Replace stale observations in place. It is neither an acceptance ledger nor a history log. Useful pending constructions survive with their actual bytes. |
| Paper mathematics | `math/` owns current topical arguments, counterexamples, definitions, paper proofs and explicitly incomplete designs. `math/index.md` owns navigation; `math/paper-map.json` alone owns the numbered paper correspondence and scoped corrections. Every current topic remains indexed. |
| Proof status and evidence | `state.json` alone binds current source hashes to accepted/pending status. `evidence/` holds sufficient exact raw receipts/logs for that ledger and useful current diagnostics. A report, interruption, hash, dependency Finished marker or review never substitutes for completed target evidence. Keep warnings and bounded scope honest. |
| External organizations and trust domains | Myers's paper is the source/comparison target, Agda and Cubical supply the pinned checking setting, and VladimirMarko/conaled with Lean/Mathlib supplies separately scoped external comparison material. Preserve these distinctions: copied Lean is not an Agda proof; an upstream report is not our fresh build; an external axiom is not an implicit premise in the internal branch. |
| References and outward handoff | `references/conaled` and `references/mathlib` hold only selected, commit-bound upstream text/code. `math/conaled.md` is the one outward-facing handoff. Keep source attribution, licenses/notices, reviewed scope and unresolved interfaces. No second assessment chain. |
| Operations and integrity | `tools/myers.py` is the entry point; `tools/tests.py` tests it; pinned `tools/native/` helpers retain their identities. `manifest.json` is generated packaging integrity and last-publication progress identity, never another proof ledger. `.build/` is disposable and excluded. |
| Packaging policy itself | This document alone owns purpose, preservation, cadence, inclusion and migration. Do not create separate constitutions, policies, packaging readmes or versioned resume instructions. |

The four guides are exactly `environment.md`, `checkpoints.md`, `project.md`, and
`work.md`. Adding a topic to mathematics is legitimate; creating a fifth competing
operational guide is not. README links are navigation, not duplicated rules.

## Protected mathematical content and principles

Preserve the current useful arguments in all these areas, not just the next run's
import closure: crisp/modal foundations; coherent diagrams and tiny colimits;
Weil/synthetic differential geometry and manifolds; internal compactness/properness;
finite presentations, torsors, coverings and descent; integral-affine, complex-
lattice, elliptic-moduli and torus constructions; actual Dedekind-real analysis and
real sheaves; presheaves/dependent families, source interpretation and universes;
external/topological models, scalar extension and constructive transfer; and the
corrections and joint-obstruction chapters. The paper map's existing 199 numbered
environments, including bounded nonresults and missing definitions, must not
silently shrink. The count is a coverage floor for this paper version, not a proof
completion measure or a reason to fabricate correspondence.

In particular, retain the exact quantifiers and hypotheses of the real-line
diagonal obstruction: unrestricted internal `DPProper`, `Compact.ProperData`, and
Mathlib `IsProperMap` are distinct. Preserve the Kock/KL and crisp/modal boundaries,
finite-free versus weaker rank distinctions, higher versus set-level scope, and
selected-cover versus all-cover scope. Do not suppress a counterexample to make a
bridge appear complete. The canonical proof rules in `docs/project.md` remain in
force: no holes, hidden axioms, resizing, unsafe flags or conclusion-as-input
fields; actual maps, inverse laws, substitution/restriction coherence and explicit
universe/admission conditions are required where claimed.

Do not delete current pending code because it has not passed, or paper mathematics
because it is not executable. Do not retain superseded alternatives just to avoid
making a decision: integrate the useful content into its current authoritative
owner, and identify an unresolved competing mathematical possibility there if
that possibility genuinely matters. Preserve original code and raw supporting
evidence, rather than replacing them with prose summaries or source hashes.

## Deliberate change without drift

Before a structural or destructive change, state its concrete benefit to recovery
and continued proof work, identify affected owners/content, and identify where the
needed information will live afterward. Use the current effort note for the active
rationale, not a new ADR/history/continuation tree. Carry over useful statements,
proofs, counterexamples, pending obligations and attribution; do not silently
weaken trust or acceptance. Update affected links, instructions, pins, schemas and
tests together, then verify a fresh restoration and the affected operations.

The packer rejects accidental source/mathematics retirement relative to the last
manifest, including lost paper-map entries. A deliberate removal or merge must be
acknowledged by exact identity with `--retire` and explained by `--purpose-reason`:

```sh
python3 -B tools/myers.py checkpoint --output ../myers-025.tar.gz \
  --retire math/old-topic.md \
  --purpose-reason 'Merged its still-useful arguments into math/current-topic.md; checked the links and preservation.'
```

Use actual paths, not this illustrative pair. A removed paper environment uses
`--retire paper:<identifier>`. The supplied set must exactly match the detected
retirements; a blanket bypass is not accepted. Only this snapshot's migration
rationale is retained in the generated manifest, not a cumulative change log.
An acknowledgment is evidence of a deliberate operation, **not a machine proof of
semantic equivalence**. The responsible worker must review the preserved content.
Changes to the protected layout itself require updating this contract and the
matching validator/tests; adding a bypass flag is not a substitute.

Original proof sources may be improved deliberately; exact hash-based acceptance
must then be recomputed. Do not rewrite receipts to make them fit altered source.
Preserve sound old evidence while applicable; retire invalidated or redundant
material only after the current ledger is fully supported. Compiler/helper or
source-mode changes need an explicit trust review and applicable rechecking, not
just updated hash strings.

## When to publish: packing and upload are one obligation

**Immediately after newly accepting a substantive mathematical result, verify
its applicable completed raw receipt, update the current owners, and complete
both a verified checkpoint and its actual durable upload before beginning the
next mathematical step.** This is an additional publication trigger, not a
replacement for the time limit below. The acceptance must come from the current
source-bound ledger and raw evidence; a review, successful dependency, interrupted
run or checkpoint serial does not trigger a claim that the target was accepted.
Do not batch newly accepted work behind further proof attempts or long checks.

While work is active and substantive changes remain unuploaded, **complete both
the verified archive and its actual durable upload within two active hours of
the first unuploaded substantive change**. Repeat this duty for subsequent work.
Also complete both steps before a risky environment transition, source
reorganization, long check that could overrun the deadline, or session handoff
with substantive unuploaded work. Do not postpone preservation until a proof
passes: retain useful pending source and its honest, applicable diagnostics.

Durability means the complete archive bytes were successfully uploaded to the
personal-root destination described below. A local archive, sandbox/chat link,
Page reference, source hash, scheduled prompt, pending upload, or promise to
upload later does **not** discharge the upload obligation. The cadence and this
meaning of completion apply to manual work and every periodic checkpoint
invocation. A schedule does not itself prove that a worker ran or an upload
succeeded. Report only operations and outcomes actually observed.

No unuploaded substantive progress means **no redundant archive or routine
no-progress notification**. This exception never suppresses a loss/blocker
notice, a required request for the recovery archive, or an upload-failure report.

Progress includes changed source, honestly labeled incomplete proofs, useful new
mathematics/design, genuinely new exact native evidence, missing substantive bytes
recovered from loss, or material tooling/environment improvements. A timestamp,
new archive number, repeated setup/doctor, status-only note, or equivalent rerun is
not progress. A substantive correction to this preservation contract is progress.
Record mathematical discoveries in `math/`; `docs/work.md` is the
current queue, not a place to hide the only copy of an argument. Do not checkpoint
merely to advertise work, or stop actual formalization in favor of routine packing.

## Mandatory stop and request after workspace loss

On every resume or runtime change, first establish that the canonical workspace
and the required source/evidence bytes are actually present and usable. If the
workspace has disappeared, been wiped, or cannot be verified, **stop
workspace-dependent mathematical edits and native checks immediately**. State
the loss and last confirmed recoverable checkpoint; do not imply that checks or
background work are continuing. Do not infer recovery or progress from a serial,
earlier chat claim, unavailable archive, old process identifier, or interrupted
check. An interrupted check has no acceptance without its applicable completed
raw receipt.

Use an already available, authorized complete archive if one exists. Otherwise
**explicitly ask the user to attach the latest required checkpoint and wait for
its bytes before resuming mathematical work**. Name the known checkpoint and
explain that the workspace was lost. Do not silently fall back to an older
snapshot, reconstruct missing source or acceptance from conversation summaries,
or assume a Library/chat link grants access to the archive. If recovery can only
use an older available snapshot, disclose exactly which later work is missing
and obtain the user's direction before substituting that baseline.

Keep diagnosis bounded: one focused availability/recovery check should establish
the actionable blocker. Repeated probing, another empty status archive, or a
claim of future automatic continuation is not recovery. This stop/request rule
also governs periodic checkpoint invocations, even when there is no new progress
to package. An unavailable runtime is a blocker to report, not permission to
continue blindly or remain silent.

After the archive is supplied, follow [environment.md](environment.md): verify
the actual archive and manifest, read README and all four guides before editing,
and restore/setup/check the pinned environment as required. Derive acceptance
only from `state.json` and applicable raw receipts. Record the recovered baseline
and any missing work in the existing current-effort owner, `docs/work.md`; do not
create a second recovery policy or continuation ledger. Resume mathematics only
after this recovery gate has been satisfied.

## Build from the canonical project

Stop edits and ensure no check is active. From the `myers/` root:

```sh
python3 -B tools/myers.py sync
python3 -B tools/myers.py verify
python3 -B tools/tests.py
python3 -B tools/myers.py checkpoint --output ../myers-024.tar.gz
```

Use the next unused short serial. Write outside the project and do not overwrite a
published archive. The packer validates the protected organization and exact
source/evidence/dependency bindings, checks retirements, and compares substantive
progress with the last manifest. No material change produces no archive. Proof
identity ignores timings, dates, process IDs, repeated logs and equivalent reruns;
README/current-work status-only edits do not trigger publication by themselves.

The packer freezes an inventory, writes a temporary archive, audits every archived
byte and unique member, checks for concurrent changes, then installs the output
and current manifest. Publish only after success. Never infer a successful audit
from an interrupted tool. A newly generated manifest is integrity metadata, not
independent proof evidence.

## Primary publication destination: personal-root Space / Library

The primary preservation goal is actual complete archive bytes in the user's
personal-root Space/Library, not merely a local file, Page reference, or chat
status. Earlier complete final-response outputs were user-confirmed visible and
downloadable there, including 036 and 040. The later running-link test was visible
and downloadable in the conversation's outputs but NOT present in Space. The
experiment does not establish automatic Space ingestion for every commentary
link, every turn duration, or every session. Never claim such a guarantee.

The exact direct `create_library_file` operation has now been tested on the
verified complete 047 checkpoint containing the strengthened upload/recovery
instructions. It returned `status: succeeded`,
`directory_id: personal-root:v1`, `file_size_bytes: 11952667`, and
`library_file_id: libfile_fde3_f-de6b611c0fd48191b902fd154751879d_bcb09d6951dc8191bbb29f2ba3c27d9d`.
The local archive's SHA-256 was
`4abf1b088f9dedabc19201c7dbb5c6f093febd692b994cbc0c63e2fca794ff8e`;
the service returned the same byte count but did not return a byte digest.
The local Library identity/version metadata was applied successfully. This is
service-confirmed personal-root storage, not a claim of user-confirmed Space
visibility or download. The raw upload receipt stays outside the mathematical
payload, and this paragraph is the single current capability-test result.

For future checkpoints use that actual callable operation when available,
with the current schema and the verified complete archive. Retain its returned
identity, destination and size, and compare byte identity when the operation
makes that possible. A previous success is not a guarantee that a later tool is
available or a later upload succeeded. Inspect the actual result for success,
destination, file identity and matching byte size; retain the raw result outside
the mathematical payload and apply any required local file identity metadata.
A service-confirmed upload is distinct from user-confirmed UI visibility or
download. Do not substitute Page helpers or change proof acceptance based on
storage results.

**Do not use `ChatGPT_Space.write_page_reference`, Page-file uploads, or multipart
Page workarounds for this project.** Their receipts did not make the B/C test
files accessible to the user in top-level Space/Library. The Page helper's limit
is not a general Library limit. Do not start another upload-diagnostic project;
use a bounded capability check and state a specific blocker. Mathematics may
resume only in a usable, verified workspace; this guidance never overrides the
mandatory stop/request gate above.

If an upload fails or actual personal-root upload is unavailable, report the
specific failure and last confirmed durable checkpoint. Do not count the upload
duty or its deadline as satisfied. Expose any verified complete local archive as
a generated conversation file and explicitly state that this is chat
output delivery, not newly confirmed personal-root storage. Emit the real sandbox
link in a user-visible running commentary update immediately after successful
creation, and repeat it in the final response. This supplies an additional recovery
opportunity; it does NOT establish that the Library received it. Do not leave all
substantive work behind a long unfinished response: finish shorter mathematical
milestones with actual deliverable files when mid-turn preservation is uncertain.

Use short, nonoverwritten `myers-NNN.tar.gz` names outside the project. Check the
final file's existence, exact byte size, SHA-256, and archived payload before
linking or uploading it. Failed commands, a filename in an automation prompt,
missing final receipts, a hash without bytes, and a promise to upload later are
not publication. A failed packaging operation must never be followed by a link
to its nonexistent output. No independent archive is claimed without an actual
verified file. Expose files already created, not inferred locations.

No additional continuation or publication-history tree belongs inside the
checkpoint. `manifest.json` owns packaging integrity; `state.json` owns current
source acceptance; `docs/work.md` owns the mathematical queue. Keep each current
checkpoint coherent and independently restorable. With a usable verified
workspace, personal-root capability or UI diagnosis must remain bounded so that
mathematics can continue. A missing workspace or required recovery archive is a
different blocker: obey the stop/request gate, rather than continuing without it.

## Publication identity across conversations

The automation can have its own associated conversation; a checkpoint appearing
there is not proof that it reached the main conversation or top-level Library.
Identify an archive by full SHA-256 and byte size, not its serial name or an
automation prompt. Conflicting same-name archives must remain immutable and
distinct until their actual source/evidence bytes are compared. Preserve raw
incoming archives outside the current source checkpoint; never nest them inside it.
Recover useful work selectively without transferring acceptance across changed
dependencies. An unavailable archive named in a status report is not recovered.

The attached 036 archive is user-confirmed secured in top-level Space/Library.
The observed delivery facts and preferred personal-root test are defined above. Disposable upload tests and their
raw diagnostics stay outside mathematical checkpoints. Preserve the current
archive-conflict facts in `docs/work.md`; do not create competing guides or
infer progress from a later serial in the separate automation conversation.

## Inclusion, exclusion and usability

The allowlist and structural checks are implemented in `tools/myers.py`. Include
only current owned documents, ledgers, mathematics, authored source, tooling,
selected upstream references, pinned offline dependencies and applicable evidence.
Never include `.build/`, interfaces/binaries, Git/history trees, old checkpoints,
source snapshots, duplicate pending trees, superseded attempts, review packets or
continuation-note chains. The sole nested archive is `vendor/agda.tar.xz`, the
pinned offline compiler distribution, not a prior checkpoint. Raw evidence's old
execution paths are provenance, not instructions to recreate that environment.

Unknown files, misplaced formalization source, duplicate module declarations,
competing operational guides, broken local document links or paper-map chapter
anchors, symlinks and cache or archive files in payload areas are rejected. Mechanical checks cannot detect every
semantic deletion or disguised history note; review purpose and content as well.

Extract the completed archive into a fresh empty directory and follow the sole
environment guide's verification/setup/doctor. Exercise changed tooling and
checking modes. A successful restore is not new theorem acceptance. If the live
workspace vanished, obey the stop/request gate above and restore the latest
available authorized complete snapshot; a supplement is justified
only for newly recovered substantive bytes absent from it, and must explicitly
name its required base. Never publish status-only recovery supplements.
