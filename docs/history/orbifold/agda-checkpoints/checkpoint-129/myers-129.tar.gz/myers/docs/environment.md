# Environment and checking

This is the sole setup and execution guide. Exact pins and mode configuration
live in `../environment.json`; do not maintain a second pins file.

## Restore offline

Use Linux x86-64, Python 3.11 or newer, and ordinary POSIX system tools. The
included compiler distribution is for that platform. No global Agda installation,
Cabal, network download, or Lean installation is needed for this Agda workspace.
Allow enough free memory for the GHC heap configured in `environment.json`,
plus runtime overhead. The native runner receives that exact allowance through
its validated `--maximum-heap` argument and records the actual proof child's
`GHCRTS` in each invocation and receipt.

Extract the checkpoint into an empty directory, then run from its `myers/` root:

```sh
python3 -B tools/myers.py verify --snapshot
python3 -B tools/myers.py setup
python3 -B tools/myers.py doctor
python3 -B tools/myers.py status
```

The first command checks the complete payload against `manifest.json`, the current
source ledger, exact retained evidence closures, and pinned dependency/helper
identities. `setup` verifies and extracts the included official compiler, installs
its own embedded data, creates an isolated configuration, and makes a disposable
copy of the pinned Cubical sources. `doctor` checks the actual native installation.
Setup, archive integrity, and a successful doctor are **not proof acceptance**.

All generated files, library registries, compiler interfaces, source stages and
attempt directories live under `.build/`. The wrapper constructs legacy paths
required by the unchanged native helpers there; they are not alternate project
sources. There are no hardcoded restoration paths to a previous machine.

## Check an actual target

```sh
python3 -B tools/myers.py check Orbifolds.Intensional.LabelledActionPullbackTopology --budget 60
```

Supply a module name, not a file path. The budget is in seconds. Mode is inferred
from the namespace: `Orbifolds.Intensional.*` is ordinary without-K;
`Orbifolds.SemanticBridge.*` is local Cubical without cohesion; the original branch
uses its native cohesion configuration. The optional `--mode` is an assertion,
not a way to change a theorem's context. Cross-mode imports are checked. The bridge may additionally import the explicitly
reviewed, cohesion-free shared source listed under its mode in `environment.json`: 
`Orbifolds.GroupoidCompletion`. That module uses ordinary Cubical Rezk completion
without a cohesion option or crisp binder. Its namespace is not an authorization
to import other original-branch sources. The actual bridge check still supplies
`--without-K` and never adds `--cohesion`; all compiler safety flags are unchanged.

The pinned native supervisor/checker/guard chain enforces safe and completeness
flags, the actual pinned proof child, a shared compiler lease, bounded execution,
stable source hashes, and the target's complete `Finished` marker. A fresh success
also requires the successful outer result and exact copied-source binding. No
source mutation is permitted during a check. One operation lock serializes setup,
checking, synchronization and packaging; the guard's compiler lease survives with
an active proof child, preventing a second process from replacing its stage.

An interrupted, timed-out or erroneous target remains pending. Dependency progress
is not target completion. A failed rerun never downgrades a previous valid positive
receipt for identical source bytes; its attempt stays in disposable `.build/`.
For an otherwise unverified target, the latest exact-source diagnostic is retained
as a pending attempt, not a proof. Individual successes do not certify a combined
aggregate or unimported modules.

`environment.json` lists the three aggregate target names. Each aggregate covers
its actual import closure only; newly pending modules are not automatically added
to old aggregate files. Do not change an aggregate merely to inflate a count.

## Edit and synchronize

Edit only canonical `src/` files, not a staging copy. After deliberate edits:

```sh
python3 -B tools/myers.py sync
python3 -B tools/myers.py check Orbifolds.SemanticBridge.YourTarget --budget 600
python3 -B tools/myers.py verify
```

`sync` rehashes the current tree, discards evidence invalidated by changed imports
or source bytes, and derives acceptance solely from surviving positive evidence.
All uncovered modules become pending. It never infers success from a filename,
source review, earlier version, or an old note. Save worthwhile current diagnostics
before resetting `.build/`, but do not preserve superseded source variants there.

After edits, use `verify`, not `verify --snapshot`: the latter intentionally rejects
any divergence from the last packaged snapshot. The next successful checkpoint
replaces that manifest. Proof status is `state.json`; the manifest is integrity only.

## Repairs and operational tests

```sh
python3 -B tools/tests.py
```

These are tooling tests, not Agda proofs. If the runtime is damaged, first establish
that no proof child is alive or holding its lease. Only then remove `.build/` and
run `setup` again. Do not send signals to remembered process IDs from another
runtime. A missing or corrupt compiler/dependency is an error, not permission to
substitute an unpinned tool or weaken checking flags.

The bundled `references/conaled` and `references/mathlib` are selected excerpts,
not buildable Lean checkouts. Their actual reference pins are recorded in
`environment.json`; no Lean theorem is imported as an Agda proof.

## Refresh an upstream reference without changing proof trust

Resolve the actual `master` object of VladimirMarko/conaled through authenticated
repository access or a working public endpoint. Fetch selected files at that exact
commit, never a mixture of branch-tip versions. Stage them under `.build/`, compare
the previous selected sources and reports, and read relevant new implementations,
validation and scope/axiom statements. At minimum retain and re-examine the finite-
action presentation and properness-obstruction reports plus the source, substitution
and descent interfaces used by the bridge. Select additional current files when
they affect the work; omit upstream history trees, binary caches and irrelevant
experiments.

Update `references/conaled` and its single `environment.json` entry together, with
the resolved commit/time and recomputed tree digest. Update the current handoff
`math/conaled.md` and queue in place. Do not reuse an ancestor's acceptance claim
for changed files, call a source review a fresh Lean build, or conflate a newly
verified pin with a joint Agda interpretation. Recheck the branch tip before
calling it current; a later upstream move does not change the selected immutable
commit. If access fails, leave the pin unchanged and record that the requested
refresh is blocked, not completed. No upstream write is authorized by a refresh.
