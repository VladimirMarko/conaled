{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.GroupoidEtale where

-- The canonical Rezk object-map square in Theorem 5.4.9.  Its pullback
-- equivalence is constructed from the proved identity/hom equivalence,
-- and source etaleness is transferred across that actual equivalence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Categories.Category using (Category)
open import Cubical.Functions.Surjection
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.GroupoidCompletion
open import Orbifolds.GroupoidOrbifold using (module FiniteCompletion)
import Orbifolds.JoinResolution as JR
import Orbifolds.ModalEtaleOperations as EO
import Orbifolds.ModalEtaleDescent as ED
import Orbifolds.Microlinearity as ML
import Orbifolds.MicrolinearModal as MM
import Orbifolds.Orbifold as O

module Presentation {ℓ : Level} (C : Category ℓ ℓ) (invertible : AllInvertible C) where
  -- These are definitionally the same arrow-space projections as
  -- GroupoidGeometry.ArrowSpace, without importing its analytic layer.
  Objects : Type ℓ
  Objects = Category.ob C

  Hom : Objects → Objects → Type ℓ
  Hom = Category.Hom[_,_] C

  Arrows : Type ℓ
  Arrows = Σ[ xy ∈ Objects × Objects ] Hom (xy .fst) (xy .snd)

  source target : Arrows → Objects
  source a = a .fst .fst
  target a = a .fst .snd

  sourceTarget : Arrows → Objects × Objects
  sourceTarget = fst
  module Completed = Completion C invertible
  module Kernel = JR.FiberedJoin Completed.object Completed.object

  kernel-pair-comparison : Arrows → Kernel.Pullback
  kernel-pair-comparison ((x , y) , h) = x , y , Completed.morphismPath h

  kernel-pair-inverse : Kernel.Pullback → Arrows
  kernel-pair-inverse (x , y , p) = (x , y) , Completed.pathMorphism p

  kernel-pair-section : (z : Kernel.Pullback)
    → kernel-pair-comparison (kernel-pair-inverse z) ≡ z
  kernel-pair-section (x , y , p) =
    cong (λ q → x , y , q) (Completed.morphismPath-pathMorphism p)

  kernel-pair-retraction : (z : Arrows)
    → kernel-pair-inverse (kernel-pair-comparison z) ≡ z
  kernel-pair-retraction ((x , y) , h) =
    cong (λ k → (x , y) , k) (Completed.pathMorphism-morphismPath h)

  arrows≃kernel-pair : Arrows ≃ Kernel.Pullback
  arrows≃kernel-pair = isoToEquiv
    (iso kernel-pair-comparison kernel-pair-inverse kernel-pair-section kernel-pair-retraction)

  source-square : (a : Arrows)
    → Kernel.left (kernel-pair-comparison a) ≡ source a
  source-square a = refl

  target-square : (a : Arrows)
    → Kernel.right (kernel-pair-comparison a) ≡ target a
  target-square a = refl

  quotient-square : (a : Arrows)
    → Completed.object (source a) ≡ Completed.object (target a)
  quotient-square ((x , y) , h) = Completed.morphismPath h

  -- Precisely the canonical comparison criterion for the source/target
  -- square to be a homotopy pullback.  No quotient-identities field is
  -- assumed in a proposed groupoid presentation.
  quotient-square-cartesian : isEquiv kernel-pair-comparison
  quotient-square-cartesian = arrows≃kernel-pair .snd

  -- Intersect a source fiber with a target singleton.  This explicit
  -- equivalence will transfer modal structure to the genuine hom type.
  SourceTargetFiber : Objects → Objects → Type ℓ
  SourceTargetFiber x y = Σ[ a ∈ fiber source x ] target (a .fst) ≡ y

  double-fiber≃pair-fiber : (x y : Objects)
    → SourceTargetFiber x y ≃ fiber sourceTarget (x , y)
  double-fiber≃pair-fiber x y = isoToEquiv
    (iso (λ ((a , p) , q) → a , λ i → p i , q i)
      (λ (a , p) → (a , cong fst p) , cong snd p)
      (λ (a , p) → refl) (λ ((a , p) , q) → refl))

  hom≃source-target-fiber : (x y : Objects) → Hom x y ≃ SourceTargetFiber x y
  hom≃source-target-fiber x y = compEquiv
    (fiberProjEquiv (Objects × Objects) (λ xy → Hom (xy .fst) (xy .snd)) (x , y))
    (invEquiv (double-fiber≃pair-fiber x y))

  module Modal (M : Modality ℓ) where
    open EO.Theory M
    module Descent = ED.Theory.Map M Completed.object

    kernel-source-etale : Etale source → Etale Kernel.left
    kernel-source-etale sourceEtale =
      etale-precompose-equivalence (invEquiv arrows≃kernel-pair) source sourceEtale

    kernel-target-etale : Etale target → Etale Kernel.right
    kernel-target-etale targetEtale =
      etale-precompose-equivalence (invEquiv arrows≃kernel-pair) target targetEtale

    -- Modal fibers follow from the actual etale unit square. With set
    -- objects, imposing a target equality is a propositional subtype.
    -- The proposition-modal premise is an ambient modality property;
    -- crystalline nullification proves it without an additional axiom.
    hom-modal :
      ((P : Type ℓ) → isProp P → isModal P)
      → isSet Objects → Etale source → (x y : Objects) → isModal (Hom x y)
    hom-modal propositions-modal setObjects sourceEtale x y =
      equivPreservesIsModal (invEquiv (hom≃source-target-fiber x y))
        (Σ-isModal (λ a → target (a .fst) ≡ y)
          (etale-modal-fibres source sourceEtale x)
          (λ a → propositions-modal (target (a .fst) ≡ y)
            (setObjects (target (a .fst)) y)))

    -- The actual source square above identifies the self-pullback
    -- projection of the canonical Rezk map with the groupoid source.
    -- Theorem 5.4.7 then proves its etaleness.  The two preservation
    -- fields concern exactly the canonical positive join pushouts and
    -- positive sequential colimit, never the desired etaleness itself.
    canonical-object-etale :
      ((X : Type ℓ) → isSurjection (η {X}))
      → Descent.PreservesJoinDiagrams
      → Etale source → Etale Completed.object
    canonical-object-etale units preservation sourceEtale =
      Descent.Descent.self-pullback-descent units preservation
        (kernel-source-etale sourceEtale) Completed.object-surjective

    module Geometry {ℓi : Level} {Index : Type ℓi}
      (test : Index → ML.TestSquare ℓ)
      (connected-tests : (t : Index) → MM.Theory.ConnectedSquare M (test t)) where
      module Family = MM.Theory.Family M test connected-tests
      module Orb = O.Geometry test
      module Finite = FiniteCompletion C invertible
      module FiniteGeometry = Finite.ModalGeometry M test connected-tests

      -- Theorem 5.4.9 over its exact modal assumptions.  Microlinearity
      -- descends along the canonical object map, whose surjectivity and
      -- etaleness are both proved.  No inhabitedness of Objects is used.
      completion-microlinear :
        ((X : Type ℓ) → isSurjection (η {X}))
        → Descent.PreservesJoinDiagrams
        → Etale source → Family.Microlinear Objects
        → Family.Microlinear Completed.Object
      completion-microlinear units preservation sourceEtale =
        Family.microlinear-descends Completed.object Completed.object-surjective
          (canonical-object-etale units preservation sourceEtale)

      completion-orbifold :
        ((X : Type ℓ) → isSurjection (η {X}))
        → Descent.PreservesJoinDiagrams
        → Etale source → Family.Microlinear Objects
        → Finite.ProperlyFiniteHoms → Orb.Orbifold Completed.Object
      completion-orbifold units preservation sourceEtale ml finiteHoms =
        FiniteGeometry.completionOrbifoldFromModalEtale finiteHoms ml
          (canonical-object-etale units preservation sourceEtale)
