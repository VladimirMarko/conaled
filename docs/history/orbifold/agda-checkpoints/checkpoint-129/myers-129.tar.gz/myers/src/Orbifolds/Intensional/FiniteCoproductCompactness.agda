{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteCoproductCompactness where

-- Actual finite subcovers for finite coproducts. The list of labels is
-- supplied as finite enumeration data; the subcover operation is built
-- by concatenation, without any choice principle or compact ambient space.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat; zero; suc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin; fzero; fsuc)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; OpenFragment; IsOpen )
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; Some; here; there; FiniteSubcover; CompactData
  ; preimage; Continuous; ProperData )
open import Orbifolds.Intensional.OpenSubspaces using (sumOpenFragment)
open import Orbifolds.Intensional.FiniteEnumeration using
  ( Member; ListCover; Some-map; map-list; Some-map-list )

private variable ℓ : Level

append : {I : Set ℓ} → List I → List I → List I
append [] ys = ys
append (i ∷ xs) ys = i ∷ append xs ys

some-append-left : {I : Set ℓ} {P : I → Set ℓ} {xs : List I}
  → (ys : List I) → Some P xs → Some P (append xs ys)
some-append-left ys (here p) = here p
some-append-left ys (there p) = there (some-append-left ys p)

some-append-right : {I : Set ℓ} {P : I → Set ℓ} {ys : List I}
  → (xs : List I) → Some P ys → Some P (append xs ys)
some-append-right [] p = p
some-append-right (i ∷ xs) p = there (some-append-right xs p)

enumerateFin : (n : Nat) → List (Fin {ℓ} n)
enumerateFin zero = []
enumerateFin (suc n) = fzero ∷ map-list fsuc (enumerateFin n)

enumerateFin-covers : (n : Nat) → ListCover (enumerateFin {ℓ} n)
enumerateFin-covers zero ()
enumerateFin-covers (suc n) fzero = here refl
enumerateFin-covers (suc n) (fsuc i) = there
  (Some-map-list fsuc (λ j → j ≡ fsuc i)
    (Some-map (λ j p → cong fsuc p) (enumerateFin-covers n i)))

enumerate : {G : Set ℓ} {n : Nat} → Equiv G (Fin {ℓ} n) → List G
enumerate {n = n} e = map-list (backward e) (enumerateFin n)

enumerate-covers : {G : Set ℓ} {n : Nat} (e : Equiv G (Fin {ℓ} n))
  → ListCover (enumerate e)
enumerate-covers {n = n} e g =
  Some-map-list (backward e) (λ h → h ≡ g)
    (Some-map (λ j p → cong (backward e) p ∙ retraction e g)
      (enumerateFin-covers n (forward e g)))

module Combine {ℓ : Level} {G I : Set ℓ} {A : G → Set ℓ}
    (K : Subset (Σ G A)) (U : I → Subset (Σ G A))
    (finite : (g : G) → FiniteSubcover
      (preimage (λ a → g , a) K)
      (λ i → preimage (λ a → g , a) (U i))) where

  indices : List G → List I
  indices [] = []
  indices (g ∷ labels) = append (fst (finite g)) (indices labels)

  covers : (labels : List G) (g : G) → Member g labels
    → (a : A g) → member K (g , a)
    → Some (λ i → member (U i) (g , a)) (indices labels)
  covers [] g () a inside
  covers (g ∷ labels) .g (here refl) a inside =
    some-append-left (indices labels) (snd (finite g) a inside)
  covers (h ∷ labels) g (there present) a inside =
    some-append-right (fst (finite h)) (covers labels g present a inside)

finite-coproduct-compact : {G : Set ℓ} {A : G → Set ℓ}
  → (labels : List G) → ListCover labels
  → (O : (g : G) → OpenFragment (A g)) → (K : Subset (Σ G A))
  → ((g : G) → CompactData (O g) (preimage (λ a → g , a) K))
  → CompactData (sumOpenFragment O) K
finite-coproduct-compact {G = G} labels listed O K compact {I} U opens cover =
  C.indices labels , λ { (g , a) inside → C.covers labels g (listed g) a inside }
  where
  finite : (g : G) → FiniteSubcover (preimage (λ a → g , a) K)
    (λ i → preimage (λ a → g , a) (U i))
  finite g = compact g (λ i → preimage (λ a → g , a) (U i))
    (λ i → opens i g) (λ a inside → cover (g , a) inside)

  module C = Combine K U finite

coproduct-continuous : {G B : Set ℓ} {A : G → Set ℓ}
  → (OA : (g : G) → OpenFragment (A g)) → (OB : OpenFragment B)
  → (f : (g : G) → A g → B)
  → ((g : G) → Continuous (OA g) OB (f g))
  → Continuous (sumOpenFragment OA) OB (λ z → f (fst z) (snd z))
coproduct-continuous OA OB f continuous U open-U g = continuous g U open-U

finite-coproduct-proper : {G B : Set ℓ} {A : G → Set ℓ}
  → (labels : List G) → ListCover labels
  → (OA : (g : G) → OpenFragment (A g)) → (OB : OpenFragment B)
  → (f : (g : G) → A g → B)
  → ((g : G) → ProperData (OA g) OB (f g))
  → ProperData (sumOpenFragment OA) OB (λ z → f (fst z) (snd z))
finite-coproduct-proper labels listed OA OB f proper K compact =
  finite-coproduct-compact labels listed OA
    (preimage (λ z → f (fst z) (snd z)) K) (λ g → proper g K compact)

finite-coproduct-projection-proper : {G A : Set ℓ}
  → (labels : List G) → ListCover labels → (O : OpenFragment A)
  → ProperData (sumOpenFragment (λ (_ : G) → O)) O snd
finite-coproduct-projection-proper labels listed O =
  finite-coproduct-proper labels listed (λ _ → O) O (λ _ a → a)
    (λ _ K compact → compact)
