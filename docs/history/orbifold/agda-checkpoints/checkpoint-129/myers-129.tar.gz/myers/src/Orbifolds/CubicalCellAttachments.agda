{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalCellAttachments where

-- Attaching actual sphere cells freely adds complete cubical fillers.
-- The typed cocone is defined independently of the pushout, and its
-- mapping universal property is derived. All comparisons use the actual
-- attachment map, pushout constructors and shell evaluation.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.HITs.Pushout as PO
import Orbifolds.MappingColimits as Mapping
open import Orbifolds.CubicalShells using (Shell)
open import Orbifolds.CubicalShellSpheres using (SphereBoundary; evaluate-shell)
open import Orbifolds.CubicalShellFillers using (Filler)
open import Orbifolds.CubicalShellMaps using (map-shell; evaluate-natural)
open import Orbifolds.CubicalFillerNullhomotopies using
  (Nullhomotopy; filler-nullhomotopy; fill-from-nullhomotopy; nullhomotopy-computation)

module Attachment {ℓ : Level} (A Cells : Type ℓ) (dimension : Cells → ℕ)
    (boundary-data : (c : Cells) → Shell (dimension c) A) where

  Boundary : Type ℓ
  Boundary = Σ[ c ∈ Cells ] SphereBoundary (dimension c)

  attach : Boundary → A
  attach (c , s) = evaluate-shell (dimension c) (boundary-data c) s

  boundary : Boundary → Cells
  boundary = fst

  Realize : Type ℓ
  Realize = PO.Pushout attach boundary

  include : A → Realize
  include = PO.inl

  center : Cells → Realize
  center = PO.inr

  attached-shell : (c : Cells) → Shell (dimension c) Realize
  attached-shell c = map-shell (dimension c) include (boundary-data c)

  attachment-nullhomotopy : (c : Cells)
    → Nullhomotopy (dimension c) (attached-shell c)
  attachment-nullhomotopy c = center c ,
    (evaluate-natural (dimension c) include (boundary-data c)
      ∙ (λ i s → PO.push (c , s) i))

  attached-filler : (c : Cells) → Filler (dimension c) (attached-shell c)
  attached-filler c = fill-from-nullhomotopy (dimension c) (attached-shell c)
    (attachment-nullhomotopy c)

  attached-filler-computation : (c : Cells)
    → filler-nullhomotopy (dimension c) (attached-shell c) .fst (attached-filler c)
      ≡ attachment-nullhomotopy c
  attached-filler-computation c = nullhomotopy-computation
    (dimension c) (attached-shell c) (attachment-nullhomotopy c)

  module MappingOut {ℓy : Level} (Y : Type ℓy) where
    module Ordinary = Mapping.Span attach boundary Y

    TypedCocone : Type (ℓ-max ℓ ℓy)
    TypedCocone = Σ[ f ∈ (A → Y) ]
      ((c : Cells) → Filler (dimension c)
        (map-shell (dimension c) f (boundary-data c)))

    module Fixed (f : A → Y) where
      RawCellData : Type (ℓ-max ℓ ℓy)
      RawCellData = Σ[ g ∈ (Cells → Y) ] (f ∘ attach ≡ g ∘ boundary)

      Pointwise : Type (ℓ-max ℓ ℓy)
      Pointwise = (c : Cells) → Σ[ y ∈ Y ]
        (f ∘ evaluate-shell (dimension c) (boundary-data c) ≡ (λ _ → y))

      split : RawCellData → Pointwise
      split (g , p) c = g c , (λ i s → p i (c , s))

      join : Pointwise → RawCellData
      join h = (λ c → h c .fst) , (λ i cs → h (cs .fst) .snd i (cs .snd))

      split-equivalence : RawCellData ≃ Pointwise
      split-equivalence = isoToEquiv (iso split join (λ _ → refl) (λ _ → refl))

      cell-nullhomotopy : (c : Cells)
        → (Σ[ y ∈ Y ] (f ∘ evaluate-shell (dimension c) (boundary-data c) ≡ (λ _ → y)))
          ≃ Nullhomotopy (dimension c) (map-shell (dimension c) f (boundary-data c))
      cell-nullhomotopy c = Σ-cong-equiv-snd λ y →
        compPathlEquiv (evaluate-natural (dimension c) f (boundary-data c))

      cell-filler : (c : Cells)
        → (Σ[ y ∈ Y ] (f ∘ evaluate-shell (dimension c) (boundary-data c) ≡ (λ _ → y)))
          ≃ Filler (dimension c) (map-shell (dimension c) f (boundary-data c))
      cell-filler c = cell-nullhomotopy c ∙ₑ
        invEquiv (filler-nullhomotopy (dimension c) (map-shell (dimension c) f (boundary-data c)))

      cells-equivalence : RawCellData ≃
        ((c : Cells) → Filler (dimension c) (map-shell (dimension c) f (boundary-data c)))
      cells-equivalence = split-equivalence ∙ₑ equivΠCod cell-filler

    cocone-equivalence : Ordinary.Cocone ≃ TypedCocone
    cocone-equivalence = Σ-cong-equiv-snd Fixed.cells-equivalence

    universal : (Realize → Y) ≃ TypedCocone
    universal = Ordinary.universal ∙ₑ cocone-equivalence

    restrict : (Realize → Y) → TypedCocone
    restrict = universal .fst

    assemble : TypedCocone → Realize → Y
    assemble = invEq universal

    original-computation : (h : Realize → Y) → restrict h .fst ≡ h ∘ include
    original-computation h = refl

    cell-computation : (h : Realize → Y) (c : Cells)
      → restrict h .snd c
        ≡ fill-from-nullhomotopy (dimension c)
          (map-shell (dimension c) (h ∘ include) (boundary-data c))
          (h (center c) ,
            (evaluate-natural (dimension c) (h ∘ include) (boundary-data c)
              ∙ (λ i s → h (PO.push (c , s) i))))
    cell-computation h c = refl

    assemble-restrict : (h : Realize → Y) → assemble (restrict h) ≡ h
    assemble-restrict = retEq universal

    restrict-assemble : (c : TypedCocone) → restrict (assemble c) ≡ c
    restrict-assemble = secEq universal

  canonical-cocone : MappingOut.TypedCocone Realize
  canonical-cocone = include , attached-filler

  canonical-computation : MappingOut.restrict Realize (idfun Realize) ≡ canonical-cocone
  canonical-computation = refl
