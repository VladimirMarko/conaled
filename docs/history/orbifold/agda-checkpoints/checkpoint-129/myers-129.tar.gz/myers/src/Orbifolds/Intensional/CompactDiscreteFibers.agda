{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CompactDiscreteFibers where

-- Finite numbering is derived from genuine compact-cover data and local
-- injectivity. The external point-set theorem then constructs every
-- finite branch chart from properness and the displayed local geometry.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (Fiber; Σ-path-equivalence)
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin; LocalBranchChart)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; OpenFragment; IsOpen; Hom; Product
  ; RectangleBasis; FiniteFiberNeighborhoods; module BranchConstruction )
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; Some; here; Covers; FiniteSubcover; CompactData
  ; preimage; PropositionalEM; em→dne; Continuous; ProperData
  ; ChosenHausdorff; ChosenLocallyCompact; proper→closed )
open import Orbifolds.Intensional.FiniteEnumeration using
  ( Some-map; em-set-list-cover→finite )
open import Orbifolds.Intensional.FiniteSeparation using
  ( SourceNeighborhood; ChosenSourceNeighborhoods; chosen-local-fiber-neighborhoods )

private variable ℓ : Level

singleton : {B : Set ℓ} → isSet B → B → Subset B
member (singleton setB b) y = y ≡ b
member-prop (singleton setB b) y = setB y b

singleton-compact : {B : Set ℓ} (O : OpenFragment B) (setB : isSet B) (b : B)
  → CompactData O (singleton setB b)
singleton-compact O setB b U opens covers =
  (fst chosen ∷ []) , λ y at-b → here (subst (member (U (fst chosen))) (sym at-b) (snd chosen))
  where
  chosen = covers b refl

-- Cover the actual fiber by the selected source neighborhoods. Each
-- chosen open meets that fiber in at most one point. Compactness therefore
-- provides a finite list of actual fiber points covering the whole fiber.
compact-locally-injective-fiber : {A B : Set ℓ}
  → (OA : OpenFragment A) → (setA : isSet A) → (setB : isSet B)
  → PropositionalEM ℓ → (f : A → B) → ChosenSourceNeighborhoods OA f
  → (b : B) → CompactData OA (preimage f (singleton setB b))
  → Σ Nat (λ n → Equiv (Fiber f b) (Fin {ℓ} n))
compact-locally-injective-fiber {ℓ} {A} {B} OA setA setB classical f local b compact =
  em-set-list-cover→finite (isSetΣProp setA path-prop) classical indices cover-list
  where
  path-prop : (a : A) → isProp (f a ≡ b)
  path-prop a = setB (f a) b

  K : Subset A
  K = preimage f (singleton setB b)

  patches : Fiber f b → Subset A
  patches point = SourceNeighborhood.neighborhood (local (fst point))

  patches-open : (point : Fiber f b) → IsOpen OA (patches point)
  patches-open point = SourceNeighborhood.neighborhood-open (local (fst point))

  patches-cover : Covers K patches
  patches-cover a at-b = (a , at-b) , SourceNeighborhood.neighborhood-center (local a)

  finite : FiniteSubcover K patches
  finite = compact patches patches-open patches-cover

  indices : List (Fiber f b)
  indices = fst finite

  covering-point-equal : (point chosen : Fiber f b)
    → member (patches chosen) (fst point) → chosen ≡ point
  covering-point-equal (a , at-b) (c , ct-b) in-patch =
    Σ-path-prop path-prop
      (SourceNeighborhood.injective-source (local c) c a
        (SourceNeighborhood.neighborhood-center (local c)) in-patch
        (ct-b ∙ sym at-b))

  cover-list : (point : Fiber f b) → Some (λ chosen → chosen ≡ point) indices
  cover-list point = Some-map (covering-point-equal point)
    (snd finite (fst point) (snd point))

proper-locally-injective-fibers : {A B : Set ℓ}
  → (OA : OpenFragment A) → (OB : OpenFragment B)
  → isSet A → isSet B → PropositionalEM ℓ
  → (f : A → B) → ProperData OA OB f → ChosenSourceNeighborhoods OA f
  → (b : B) → Σ Nat (λ n → Equiv (Fiber f b) (Fin {ℓ} n))
proper-locally-injective-fibers OA OB setA setB classical f proper local b =
  compact-locally-injective-fiber OA setA setB classical f local b
    (proper (singleton setB b) (singleton-compact OB setB b))

isProp-from-equivalence : {A B : Set ℓ} → Equiv A B → isProp B → isProp A
isProp-from-equivalence e prop x y =
  sym (retraction e x) ∙ cong (backward e) (prop (forward e x) (forward e y)) ∙ retraction e y

isSetΣ : {A : Set ℓ} {B : A → Set ℓ}
  → isSet A → ((a : A) → isSet (B a)) → isSet (Σ A B)
isSetΣ {B = B} setA setB u v =
  isProp-from-equivalence (Σ-path-equivalence u v)
    (isPropΣ (setA (fst u) (fst v))
      (λ p → setB (fst v) (subst B p (snd u)) (snd v)))

product-path : {X Y : Set ℓ} {x x' : X} {y y' : Y}
  → x ≡ x' → y ≡ y' → (x , y) ≡ (x' , y')
product-path refl refl = refl

hom-anchor-equivalence : {A X Y : Set ℓ}
  → (s : A → X) → (t : A → Y) → isSet X → isSet Y
  → (x : X) → (y : Y) → Equiv (Hom s t x y) (Fiber (λ a → s a , t a) (x , y))
hom-anchor-equivalence s t setX setY x y = equiv
  (λ { (a , px , py) → a , product-path px py })
  (λ { (a , p) → a , cong fst p , cong snd p })
  (λ h → Σ-path-prop (λ a → isSetΣ setX (λ _ → setY) (s a , t a) (x , y)) refl)
  (λ h → Σ-path-prop (λ a → isPropΣ (setX (s a) x) (λ _ → setY (t a) y)) refl)

anchor-neighborhoods : {A X Y : Set ℓ}
  → (OA : OpenFragment A) → (s : A → X) → (t : A → Y)
  → ChosenSourceNeighborhoods OA s → ChosenSourceNeighborhoods OA (λ a → s a , t a)
anchor-neighborhoods OA s t local a = record
  { neighborhood = SourceNeighborhood.neighborhood (local a)
  ; neighborhood-open = SourceNeighborhood.neighborhood-open (local a)
  ; neighborhood-center = SourceNeighborhood.neighborhood-center (local a)
  ; injective-source = λ b c in-b in-c equal →
      SourceNeighborhood.injective-source (local a) b c in-b in-c (cong fst equal)
  }

module ProperBranchConstruction {ℓ : Level} {A X Y : Set ℓ}
    (ext : FunExt ℓ ℓ) (classical : PropositionalEM ℓ)
    (OA : OpenFragment A) (OX : OpenFragment X) (OY : OpenFragment Y)
    (OXY : OpenFragment (Product X Y))
    (setA : isSet A) (setX : isSet X) (setY : isSet Y)
    (arrow-separated : ChosenHausdorff OA)
    (product-separated : ChosenHausdorff OXY)
    (product-compact-neighborhoods : ChosenLocallyCompact OXY)
    (s : A → X) (t : A → Y)
    (continuous : Continuous OA OXY (λ a → s a , t a))
    (proper : ProperData OA OXY (λ a → s a , t a))
    (local-source : ChosenSourceNeighborhoods OA s)
    (rectangles : RectangleBasis OX OY OXY) where

  anchor : A → Product X Y
  anchor a = s a , t a

  set-product : isSet (Product X Y)
  set-product = isSetΣ setX (λ _ → setY)

  fiber-numbering : (x : X) (y : Y)
    → Σ Nat (λ n → Equiv (Hom s t x y) (Fin {ℓ} n))
  fiber-numbering x y = fst numbered ,
    compEquiv (hom-anchor-equivalence s t setX setY x y) (snd numbered)
    where
    numbered = proper-locally-injective-fibers OA OXY setA set-product classical
      anchor proper (anchor-neighborhoods OA s t local-source) (x , y)

  fiber-neighborhoods : (x : X) (y : Y) → FiniteFiberNeighborhoods OA s t x y
  fiber-neighborhoods x y = chosen-local-fiber-neighborhoods OA arrow-separated
    s t setX setY local-source x y (fst (fiber-numbering x y)) (snd (fiber-numbering x y))

  module Branches = BranchConstruction ext (em→dne classical) OA OX OY OXY s t setX setY
    (proper→closed ext classical OA OXY product-separated product-compact-neighborhoods
      anchor continuous proper) rectangles

  -- No finite fiber, disjoint branch family, closed-map property, or
  -- completed branch equivalence is an input to this assembly.
  proper-local-branch-chart : (x : X) (y : Y) → LocalBranchChart (Hom s t) x y
  proper-local-branch-chart x y = Branches.finite-bisections-local-chart x y (fiber-neighborhoods x y)
