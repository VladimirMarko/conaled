{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarCoconeFunctoriality where

-- The constructed finite cocone action is a strict functor in its target.
-- All laws follow from its checked raw-cube computation and finite-stage
-- extensionality. The ordinary-index strict function-extensionality rule
-- remains an explicit ambient-model parameter.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
open import Orbifolds.Coherent.EnrichedBarConeData using (LawPair)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.EnrichedMappingDiagrams as Mapping
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
import Orbifolds.Coherent.EnrichedBarFiniteStages as Finite
import Orbifolds.Coherent.EnrichedBarFiniteTransformations as Transformations
import Orbifolds.Coherent.EnrichedBarFiniteExtensionality as Extensionality
import Orbifolds.Coherent.EnrichedBarConeData as Data

module Functoriality {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  open Category C
  open Chains (Opposite C)
  open StrictFunctionExtensionality F

  Cocone : Type ℓ → Dim → Type ℓ
  Cocone Y n = Finite.Finite.Carrier (Opposite C) (Mapping.Mapping.Into D Y) E n

  postcompose : (n : Dim) {Y Z : Type ℓ} → (Y → Z) → Cocone Y n → Cocone Z n
  postcompose n {Y} {Z} k = Transformations.Action.stage-map
    (Mapping.Mapping.Into D Y) (Mapping.Mapping.Into D Z) (Mapping.Mapping.Postcompose D k) E n

  top : (Y : Type ℓ) (n : Dim)
    → Data.Data.Top (Opposite C) (Mapping.Mapping.Into D Y) n (Cocone Y n)
  top Y n = Data.Data.top (Opposite C) (Mapping.Mapping.Into D Y) n
    (Finite.Finite.families (Opposite C) (Mapping.Mapping.Into D Y) E n)

  top-identity : (n : Dim) (Y : Type ℓ) (s : Cocone Y n)
    (y : Obj) (c : Chain n y)
    → outer (top Y n (postcompose n (idfun Y) s) y c) ≡ˢ outer (top Y n s y c)
  top-identity n Y s y c = strict-trans
    (strict-sym (Transformations.Action.stage-top-natural
      (Mapping.Mapping.Into D Y) (Mapping.Mapping.Into D Y)
      (Mapping.Mapping.Postcompose D (idfun Y)) E n s y c))
    (Cubes.Extensional.map-identity E n (top Y n s y c))

  identity-agreement : (n : Dim) (Y : Type ℓ) (s : Cocone Y n)
    → Extensionality.Extensionality.Agreement
      (Opposite C) (Mapping.Mapping.Into D Y) E F n (postcompose n (idfun Y) s) s
  identity-agreement ozero Y s = top-identity ozero Y s
  LawPair.earlier (identity-agreement (osuc n) Y s) = identity-agreement n Y (s .fst)
  LawPair.current (identity-agreement (osuc n) Y s) = top-identity (osuc n) Y s

  postcompose-identity : (n : Dim) (Y : Type ℓ) (s : Cocone Y n)
    → outer (postcompose n (idfun Y) s) ≡ˢ outer s
  postcompose-identity n Y s = Extensionality.Extensionality.stage-extensionality
    (Opposite C) (Mapping.Mapping.Into D Y) E F n (postcompose n (idfun Y) s) s
    (identity-agreement n Y s)

  top-compose : (n : Dim) {Y Z W : Type ℓ} (f : Y → Z) (g : Z → W)
    (s : Cocone Y n) (y : Obj) (c : Chain n y)
    → outer (top W n (postcompose n g (postcompose n f s)) y c)
      ≡ˢ outer (top W n (postcompose n (g ∘ f) s) y c)
  top-compose n {Y} {Z} {W} f g s y c = strict-trans
    (strict-sym (Transformations.Action.stage-top-natural
      (Mapping.Mapping.Into D Z) (Mapping.Mapping.Into D W)
      (Mapping.Mapping.Postcompose D g) E n (postcompose n f s) y c))
    (strict-trans
      (strict-cong (λ q → outer (map-cube n (λ h → g ∘ h) (inner q)))
        (strict-sym (Transformations.Action.stage-top-natural
          (Mapping.Mapping.Into D Y) (Mapping.Mapping.Into D Z)
          (Mapping.Mapping.Postcompose D f) E n s y c)))
      (strict-trans
        (Cubes.Extensional.map-compose E n (λ h → g ∘ h) (λ h → f ∘ h) (top Y n s y c))
        (Transformations.Action.stage-top-natural
          (Mapping.Mapping.Into D Y) (Mapping.Mapping.Into D W)
          (Mapping.Mapping.Postcompose D (g ∘ f)) E n s y c)))

  compose-agreement : (n : Dim) {Y Z W : Type ℓ} (f : Y → Z) (g : Z → W)
    (s : Cocone Y n)
    → Extensionality.Extensionality.Agreement
      (Opposite C) (Mapping.Mapping.Into D W) E F n
      (postcompose n g (postcompose n f s)) (postcompose n (g ∘ f) s)
  compose-agreement ozero f g s = top-compose ozero f g s
  LawPair.earlier (compose-agreement (osuc n) f g s) = compose-agreement n f g (s .fst)
  LawPair.current (compose-agreement (osuc n) f g s) = top-compose (osuc n) f g s

  postcompose-compose : (n : Dim) {Y Z W : Type ℓ} (f : Y → Z) (g : Z → W)
    (s : Cocone Y n)
    → outer (postcompose n g (postcompose n f s)) ≡ˢ outer (postcompose n (g ∘ f) s)
  postcompose-compose n {W = W} f g s = Extensionality.Extensionality.stage-extensionality
    (Opposite C) (Mapping.Mapping.Into D W) E F n
    (postcompose n g (postcompose n f s)) (postcompose n (g ∘ f) s)
    (compose-agreement n f g s)

  identity-function : (n : Dim) (Y : Type ℓ)
    → outer (postcompose n (idfun Y)) ≡ˢ outer (idfun (Cocone Y n))
  identity-function n Y = function-ext (postcompose-identity n Y)

  compose-function : (n : Dim) {Y Z W : Type ℓ} (f : Y → Z) (g : Z → W)
    → outer (postcompose n g ∘ postcompose n f) ≡ˢ outer (postcompose n (g ∘ f))
  compose-function n f g = function-ext (postcompose-compose n f g)
