{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CompactRealSubspaces where

-- A concrete geometric improvement of the one-dimensional case of
-- Lemma 6.2.21: a DP-compact type with decidable equality embedded in R
-- is locally isolated in the actual interval/Penon topology.
--
-- Remove a chosen point by decidability; the complement stays compact.
-- Its squared-distance function is positive, hence bounded away from zero.
-- The resulting open squared-distance neighborhood isolates the point.
-- No isolation premise is assumed.  Proper finiteness then needs only an
-- ambient countable basis, whose rational-interval construction is separate.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; Dec; yes; no; Discrete; Discrete→isSet)
open import Cubical.Functions.Embedding using (isEmbedding; isEmbedding→Inj; EmbeddingΣProp)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.SyntheticBounds using (module Bounds)
open import Orbifolds.IntervalTopology using (module Intervals)
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.CompactSubspaces using (WithoutPoint; complementSingletonDPCompact)
open import Orbifolds.Penon using (inverseImagePenonOpen)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
open import Orbifolds.Topology using (Predicate; IsOpen)
open import Orbifolds.SubspaceBases using (CountableBasis; LocallyIsolatedMap; module PullbackBasis)
open import Orbifolds.ProperFiniteness using (ProperlyFinite)

module RealSubspaces {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open OrderedRingCompatibility compatibility
  open RealProbe R kock order compatibility
    using (PositiveRadius; intervalBalls; realCountableProbe)
  open Bounds R kock order compatibility using (positiveFunctionBoundAwayZero)
  open Intervals R kock order compatibility using (realTopology; regularIntervals)

  negativeSquare : (d : Carrier) → (- d) · (- d) ≡ d · d
  negativeSquare d = solve! R

  nonzeroSquarePositive : (d : Carrier) → ¬ (d ≡ 0r) → 0r < (d · d)
  nonzeroSquarePositive d nonzero = PT.rec (less-isProp 0r (d · d))
    (Sum.rec
      (λ negative → subst (0r <_) (negativeSquare d)
        (positive-multiply (negPositive negative) (negPositive negative)))
      (λ positive → positive-multiply positive positive))
    (nonzero-sign d nonzero)
    where
    negPositive : d < 0r → 0r < (- d)
    negPositive negative = subst (0r <_) (+IdL (- d))
      (less→positiveDifference negative)

  SquaredDistance : Carrier → Carrier → Carrier
  SquaredDistance x y = (x - y) · (x - y)

  squaredDistanceSelf : (x : Carrier) → SquaredDistance x x ≡ 0r
  squaredDistanceSelf x = solve! R

  squaredDistancePositive : {x y : Carrier} → ¬ (x ≡ y) → 0r < SquaredDistance x y
  squaredDistancePositive {x} {y} distinct =
    nonzeroSquarePositive (x - y) (λ vanishes → distinct (equalByDifference x y vanishes))

  compactRealEmbeddingIsolated : CoveringProperty intervalBalls →
    {K : Type ℓ} → DPCompact K → Discrete K →
    (f : K → Carrier) → isEmbedding f → LocallyIsolatedMap realTopology f
  compactRealEmbeddingIsolated covering {K = K} compactK decide f embedding x =
    PT.map finish (positiveFunctionBoundAwayZero covering
      (complementSingletonDPCompact compactK decide x)
      (λ other → SquaredDistance (f x) (f (other .fst)))
      (λ other → squaredDistancePositive
        (λ path → other .snd (isEmbedding→Inj embedding x (other .fst) path))))
    where
    finish : (Σ[ ε ∈ PositiveRadius ]
      ((other : WithoutPoint x) → ε .fst < SquaredDistance (f x) (f (other .fst)))) →
      Σ[ U ∈ Predicate Carrier ]
        (IsOpen realTopology U ×
          (U (f x) .fst × ((y : K) → U (f y) .fst → x ≡ y)))
    finish (ε , lowerBound) = U , openU , contains , (λ y → unique y (decide x y))
      where
      U : Predicate Carrier
      U z = (SquaredDistance (f x) z < ε .fst) ,
        less-isProp (SquaredDistance (f x) z) (ε .fst)

      openU : IsOpen realTopology U
      openU = inverseImagePenonOpen (SquaredDistance (f x))
        (UpperRay (ε .fst)) (upperRayPenonOpen (ε .fst))

      contains : U (f x) .fst
      contains = subst (_< ε .fst) (sym (squaredDistanceSelf (f x))) (ε .snd)

      unique : (y : K) → Dec (x ≡ y) → U (f y) .fst → x ≡ y
      unique y (yes path) member = path
      unique y (no distinct) member =
        Empty.rec (lessAsym (lowerBound (y , distinct)) member)

  -- The one-dimensional finiteness theorem.  The countable-basis input
  -- is purely ambient and independent of K, compactness, or finiteness.
  compactRealEmbeddingProperlyFinite : CoveringProperty intervalBalls →
    CountableBasis realTopology → {K : Type ℓ} → DPCompact K → Discrete K →
    (f : K → Carrier) → isEmbedding f → ProperlyFinite K
  compactRealEmbeddingProperlyFinite covering basis compactK decide f embedding =
    Subspace.compactIsolatedProperlyFinite intervalBalls covering realCountableProbe compactK
      (compactRealEmbeddingIsolated covering compactK decide f embedding)
    where
    module Subspace = PullbackBasis realTopology basis (regularIntervals covering)
      f (Discrete→isSet decide)

  compactDiscreteRealSubtypeProperlyFinite : CoveringProperty intervalBalls →
    CountableBasis realTopology → (U : Predicate Carrier) →
    DPCompact (Σ[ x ∈ Carrier ] U x .fst) → Discrete (Σ[ x ∈ Carrier ] U x .fst) →
    ProperlyFinite (Σ[ x ∈ Carrier ] U x .fst)
  compactDiscreteRealSubtypeProperlyFinite covering basis U compactU decide =
    compactRealEmbeddingProperlyFinite covering basis compactU decide fst
      (EmbeddingΣProp (λ x → U x .snd) .snd)

