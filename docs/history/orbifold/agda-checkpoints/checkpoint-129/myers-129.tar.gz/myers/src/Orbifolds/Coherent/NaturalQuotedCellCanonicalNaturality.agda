{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellCanonicalNaturality where

-- Seal the already constructed canonical cell-map path before a large
-- diagram is substituted.  Its strict construction equality and its
-- first-projection computation remain explicit, so later transition
-- coherence uses the actual path and its actual lower coordinate.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments
import Orbifolds.Coherent.NaturalQuotedCellInterface as Original
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.CubicalShells as CS

module Naturality {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A B Index : Type ℓ) (SourceCoefficient TargetCoefficient : Index → Type ℓ)
    (source-boundary : (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → A))
    (target-boundary : (c : Index) → CS.Shell (toNat n) (TargetCoefficient c → B))
    (base-map : A → B) (coefficient-map : (c : Index) → SourceCoefficient c → TargetCoefficient c)
    (boundary-path : (c : Index)
      → Shells.Action.map-shell E n (λ v → base-map ∘ v) (source-boundary c)
        ≡ Shells.Action.map-shell E n (λ v → v ∘ coefficient-map c) (target-boundary c)) where
  module Source = Attachments.Attachment E n A Index SourceCoefficient source-boundary
    using (Cocone; module Target)
  module Target = Attachments.Attachment E n B Index TargetCoefficient target-boundary
    using (Realize; canonical-cocone; include)

  abstract
    canonical-naturality : PathP (λ _ → Source.Cocone Target.Realize)
      (Source.Target.restrict Target.Realize
        (Original.Map.induced E n A B Index SourceCoefficient TargetCoefficient
          source-boundary target-boundary base-map coefficient-map boundary-path))
      (Original.Map.TargetSpace.pullback E n A B Index SourceCoefficient TargetCoefficient
        source-boundary target-boundary base-map coefficient-map boundary-path
        Target.Realize Target.canonical-cocone)
    canonical-naturality = Original.Map.canonical-naturality E n A B Index
      SourceCoefficient TargetCoefficient source-boundary target-boundary
      base-map coefficient-map boundary-path

    construction : outer canonical-naturality
      ≡ˢ outer (Original.Map.canonical-naturality E n A B Index
        SourceCoefficient TargetCoefficient source-boundary target-boundary
        base-map coefficient-map boundary-path)
    construction = reflˢ

    original-computation : cong fst canonical-naturality
      ≡ (refl {x = Target.include ∘ base-map})
    original-computation = refl
