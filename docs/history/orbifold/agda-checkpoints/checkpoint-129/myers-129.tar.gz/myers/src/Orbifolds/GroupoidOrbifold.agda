{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- From morphism finiteness of an actual groupoid to finite identities in
-- its actual Rezk completion.  The geometric inputs to microlinearity are
-- displayed separately, as lifting or modal-etaleness hypotheses.
module Orbifolds.GroupoidOrbifold where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Categories.Category using (Category)
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.GroupoidCompletion
open import Orbifolds.ProperFiniteness
open import Orbifolds.Orbifold using (LocallyProperlyFinite)
import Orbifolds.Orbifold as O
import Orbifolds.Microlinearity as ML
import Orbifolds.MicrolinearModal as MM

private
  variable
    ℓ ℓi : Level

module FiniteCompletion (C : Category ℓ ℓ) (invertible : AllInvertible C) where
  open Completion C invertible

  ProperlyFiniteHoms : Type (ℓ-suc ℓ)
  ProperlyFiniteHoms =
    (x y : Category.ob C) → ProperlyFinite (Category.Hom[_,_] C x y)

  -- The final finite-identity calculation in Theorem 6.3.7 is now a theorem
  -- about the pinned library's Rezk construction.  Identity ≃ hom is proved
  -- in GroupoidCompletion, and induction reaches every completed point.
  completionLocallyProperlyFinite : ProperlyFiniteHoms → LocallyProperlyFinite Object
  completionLocallyProperlyFinite finiteHoms =
    proposition-induction₂ (λ u v → ProperlyFinite (u ≡ v))
      (λ _ _ → isPropProperlyFinite)
      (λ x y → equivProperlyFinite (hom≃identification x y) (finiteHoms x y))

  module Geometry {Index : Type ℓi} (test : Index → ML.TestSquare ℓ) where
    module Micro = ML.Theory test
    module Orb = O.Geometry test

    -- Substantial hypotheses are expressed as properties of the actual
    -- input groupoid and its canonical completion map.  No completed
    -- microlinearity or completed finite-identity conclusion is assumed.
    completionOrbifoldFromLifting : ProperlyFiniteHoms
      → Micro.Microlinear (Category.ob C)
      → Micro.InfinitesimallyEtale object
      → Orb.Orbifold Object
    completionOrbifoldFromLifting finiteHoms ml etale = record
      { microlinear = Micro.microlinear-descends object object-surjective etale ml
      ; finite-identifications = completionLocallyProperlyFinite finiteHoms
      }

  module ModalGeometry (M : Modality ℓ) {Index : Type ℓi}
    (test : Index → ML.TestSquare ℓ)
    (connected-tests : (t : Index) → MM.Theory.ConnectedSquare M (test t)) where
    module Modal = MM.Theory M
    module Family = Modal.Family test connected-tests
    module Orb = O.Geometry test

    -- This version uses the genuine homotopy-pullback condition on the
    -- modal-unit square.  Orthogonality is derived by MicrolinearModal.
    -- Proving this condition from an ordinary étale groupoid presentation
    -- still belongs to the geometric interpretation of the paper.
    completionOrbifoldFromModalEtale : ProperlyFiniteHoms
      → Family.Microlinear (Category.ob C)
      → Modal.Etale object
      → Orb.Orbifold Object
    completionOrbifoldFromModalEtale finiteHoms ml etale = record
      { microlinear = Family.microlinear-descends object object-surjective etale ml
      ; finite-identifications = completionLocallyProperlyFinite finiteHoms
      }
