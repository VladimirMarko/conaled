{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FirstOrderWeilSquare where

-- D = R + R epsilon and D(2) = R + R epsilon1 + R epsilon2.
-- All products of infinitesimal directions are zero. The comparison
-- D(2) -> D x_R D and its inverse are actual coordinate functions;
-- their inverse laws and algebra/module compatibility are proved.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv; equiv→isEquiv)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (Not)
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportPullbacks using (Pullback; pullback-path)
open import Orbifolds.Intensional.SquareZeroAlgebra

module Construction {ℓ : Level} (R : CommutativeSemiring ℓ) where
  private module R = CommutativeSemiring R

  coefficients : Semimodule R
  coefficients = regular-module R

  two-directions : Semimodule R
  two-directions = product-module coefficients coefficients

  module D = Extension R coefficients
  module D2 = Extension R two-directions
  module First = Induced R two-directions coefficients (first-linear coefficients coefficients)
  module Second = Induced R two-directions coefficients (second-linear coefficients coefficients)

  first : D2.E → D.E
  first z = fst z , fst (snd z)

  second : D2.E → D.E
  second z = fst z , snd (snd z)

  first-linear-map : LinearMap D2.E-module D.E-module
  first-linear-map = First.induced-linear

  second-linear-map : LinearMap D2.E-module D.E-module
  second-linear-map = Second.induced-linear

  first-semiring-map : IsSemiringMap D2.E-semiring D.E-semiring first
  first-semiring-map = First.induced-map

  second-semiring-map : IsSemiringMap D2.E-semiring D.E-semiring second
  second-semiring-map = Second.induced-map

  first-augmentation : (z : D2.E) → D.augmentation (first z) ≡ D2.augmentation z
  first-augmentation z = refl

  second-augmentation : (z : D2.E) → D.augmentation (second z) ≡ D2.augmentation z
  second-augmentation z = refl

  first-scalars : (r : R.Carrier) → first (D2.include-scalar r) ≡ D.include-scalar r
  first-scalars r = refl

  second-scalars : (r : R.Carrier) → second (D2.include-scalar r) ≡ D.include-scalar r
  second-scalars r = refl

  P : Set ℓ
  P = Pullback D.augmentation D.augmentation

  comparison : D2.E → P
  comparison z = first z , (second z , refl)

  assemble : P → D2.E
  assemble ((r , u) , ((s , v) , same)) = r , (u , v)

  comparison-assemble : (z : P) → comparison (assemble z) ≡ z
  comparison-assemble ((r , u) , ((s , v) , same)) =
    pullback-path R.carrier-set refl (pair-path (sym same) refl)

  assemble-comparison : (z : D2.E) → assemble (comparison z) ≡ z
  assemble-comparison z = refl

  comparison-equivalence : Equiv D2.E P
  comparison-equivalence = equiv comparison assemble comparison-assemble assemble-comparison

  comparison-isEquiv : isEquiv comparison
  comparison-isEquiv = equiv→isEquiv comparison-equivalence

  -- The coordinatewise operations on the literal pullback are exposed,
  -- so this is an algebra comparison as well as an equivalence of sets.
  left : P → D.E
  left = fst

  right : P → D.E
  right z = fst (snd z)

  matching : (z : P) → D.augmentation (right z) ≡ D.augmentation (left z)
  matching z = snd (snd z)

  P-path : {u v : P} → left u ≡ left v → right u ≡ right v → u ≡ v
  P-path = pullback-path R.carrier-set

  P-path-η : {u v : P} (p : u ≡ v) → P-path (cong left p) (cong right p) ≡ p
  P-path-η {u = a , (b , p)} refl = cong (cong (λ q → a , (b , q)))
    (isProp→isSet (R.carrier-set (D.augmentation b) (D.augmentation a)) p p
      (R.carrier-set (D.augmentation b) (D.augmentation a) p p) refl)

  P-set : isSet P
  P-set u v p q = sym (P-path-η p)
    ∙ cong₂ (P-path {u = u} {v = v})
        (Semimodule.carrier-set D.E-module (left u) (left v) (cong left p) (cong left q))
        (Semimodule.carrier-set D.E-module (right u) (right v) (cong right p) (cong right q))
    ∙ P-path-η q

  zeroP : P
  zeroP = D.zeroE , (D.zeroE , refl)

  oneP : P
  oneP = D.oneE , (D.oneE , refl)

  addP : P → P → P
  addP u v = D.add (left u) (left v) ,
    (D.add (right u) (right v) , cong₂ R._+_ (matching u) (matching v))

  multiplyP : P → P → P
  multiplyP u v = D.multiply (left u) (left v) ,
    (D.multiply (right u) (right v) , cong₂ R._*_ (matching u) (matching v))

  scaleP : R.Carrier → P → P
  scaleP r u = D.scale r (left u) ,
    (D.scale r (right u) , cong (R._*_ r) (matching u))

  P-additive : AdditiveMonoid ℓ
  AdditiveMonoid.Carrier P-additive = P
  AdditiveMonoid.carrier-set P-additive = P-set
  AdditiveMonoid.zero P-additive = zeroP
  AdditiveMonoid._+_ P-additive = addP
  AdditiveMonoid.+-assoc P-additive u v w = P-path
    (AdditiveMonoid.+-assoc D.E-additive (left u) (left v) (left w))
    (AdditiveMonoid.+-assoc D.E-additive (right u) (right v) (right w))
  AdditiveMonoid.+-comm P-additive u v = P-path
    (AdditiveMonoid.+-comm D.E-additive (left u) (left v))
    (AdditiveMonoid.+-comm D.E-additive (right u) (right v))
  AdditiveMonoid.+-zero-left P-additive u = P-path
    (AdditiveMonoid.+-zero-left D.E-additive (left u))
    (AdditiveMonoid.+-zero-left D.E-additive (right u))
  AdditiveMonoid.+-zero-right P-additive u = P-path
    (AdditiveMonoid.+-zero-right D.E-additive (left u))
    (AdditiveMonoid.+-zero-right D.E-additive (right u))

  P-semiring : CommutativeSemiring ℓ
  CommutativeSemiring.additive P-semiring = P-additive
  CommutativeSemiring.one P-semiring = oneP
  CommutativeSemiring._*_ P-semiring = multiplyP
  CommutativeSemiring.*-assoc P-semiring u v w = P-path
    (D.multiply-assoc (left u) (left v) (left w)) (D.multiply-assoc (right u) (right v) (right w))
  CommutativeSemiring.*-comm P-semiring u v = P-path
    (D.multiply-comm (left u) (left v)) (D.multiply-comm (right u) (right v))
  CommutativeSemiring.*-one-left P-semiring u = P-path
    (D.multiply-one-left (left u)) (D.multiply-one-left (right u))
  CommutativeSemiring.*-one-right P-semiring u = P-path
    (D.multiply-one-right (left u)) (D.multiply-one-right (right u))
  CommutativeSemiring.*-zero-left P-semiring u = P-path
    (D.multiply-zero-left (left u)) (D.multiply-zero-left (right u))
  CommutativeSemiring.*-zero-right P-semiring u = P-path
    (D.multiply-zero-right (left u)) (D.multiply-zero-right (right u))
  CommutativeSemiring.*-add-left P-semiring u v w = P-path
    (D.multiply-add-left (left u) (left v) (left w)) (D.multiply-add-left (right u) (right v) (right w))
  CommutativeSemiring.*-add-right P-semiring u v w = P-path
    (D.multiply-add-right (left u) (left v) (left w)) (D.multiply-add-right (right u) (right v) (right w))

  P-module : Semimodule R
  Semimodule.additive P-module = P-additive
  Semimodule._•_ P-module = scaleP
  Semimodule.•-one P-module u = P-path
    (Semimodule.•-one D.E-module (left u)) (Semimodule.•-one D.E-module (right u))
  Semimodule.•-assoc P-module r s u = P-path
    (Semimodule.•-assoc D.E-module r s (left u)) (Semimodule.•-assoc D.E-module r s (right u))
  Semimodule.•-zero P-module r = P-path (Semimodule.•-zero D.E-module r) (Semimodule.•-zero D.E-module r)
  Semimodule.zero-• P-module u = P-path
    (Semimodule.zero-• D.E-module (left u)) (Semimodule.zero-• D.E-module (right u))
  Semimodule.•-add P-module r u v = P-path
    (Semimodule.•-add D.E-module r (left u) (left v)) (Semimodule.•-add D.E-module r (right u) (right v))
  Semimodule.add-• P-module r s u = P-path
    (Semimodule.add-• D.E-module r s (left u)) (Semimodule.add-• D.E-module r s (right u))

  comparison-linear : LinearMap D2.E-module P-module
  comparison-linear = comparison ,
    ((P-path refl refl , λ u v → P-path refl refl) , λ r u → P-path refl refl)

  assemble-linear : LinearMap P-module D2.E-module
  assemble-linear = assemble , ((refl , λ u v → refl) , λ r u → refl)

  comparison-map : IsSemiringMap D2.E-semiring P-semiring comparison
  IsSemiringMap.map-zero comparison-map = P-path refl refl
  IsSemiringMap.map-one comparison-map = P-path refl refl
  IsSemiringMap.map-add comparison-map u v = P-path refl refl
  IsSemiringMap.map-mul comparison-map u v = P-path refl refl

  assemble-map : IsSemiringMap P-semiring D2.E-semiring assemble
  IsSemiringMap.map-zero assemble-map = refl
  IsSemiringMap.map-one assemble-map = refl
  IsSemiringMap.map-add assemble-map u v = refl
  IsSemiringMap.map-mul assemble-map u v = pair-path refl (pair-path refl
    (cong₂ R._+_
      (cong (λ r → r R.* snd (right v)) (matching u))
      (cong (λ r → r R.* snd (right u)) (matching v))))

  -- These nilpotents are nonzero whenever the coefficient unit is.
  epsilon : D.E
  epsilon = D.pure R.one

  epsilon1 : D2.E
  epsilon1 = D2.pure (R.one , R.zero)

  epsilon2 : D2.E
  epsilon2 = D2.pure (R.zero , R.one)

  epsilon-square : D.multiply epsilon epsilon ≡ D.zeroE
  epsilon-square = D.pure-product-zero R.one R.one

  epsilon1-square : D2.multiply epsilon1 epsilon1 ≡ D2.zeroE
  epsilon1-square = D2.pure-product-zero (R.one , R.zero) (R.one , R.zero)

  epsilon2-square : D2.multiply epsilon2 epsilon2 ≡ D2.zeroE
  epsilon2-square = D2.pure-product-zero (R.zero , R.one) (R.zero , R.one)

  epsilon12-product : D2.multiply epsilon1 epsilon2 ≡ D2.zeroE
  epsilon12-product = D2.pure-product-zero (R.one , R.zero) (R.zero , R.one)

  epsilon21-product : D2.multiply epsilon2 epsilon1 ≡ D2.zeroE
  epsilon21-product = D2.pure-product-zero (R.zero , R.one) (R.one , R.zero)

  epsilon-nonzero : Not (R.one ≡ R.zero) → Not (epsilon ≡ D.zeroE)
  epsilon-nonzero nontrivial equal = nontrivial (cong snd equal)

  epsilon1-nonzero : Not (R.one ≡ R.zero) → Not (epsilon1 ≡ D2.zeroE)
  epsilon1-nonzero nontrivial equal = nontrivial (cong (λ z → fst (snd z)) equal)

  epsilon2-nonzero : Not (R.one ≡ R.zero) → Not (epsilon2 ≡ D2.zeroE)
  epsilon2-nonzero nontrivial equal = nontrivial (cong (λ z → snd (snd z)) equal)

  directions-distinct : Not (R.one ≡ R.zero) → Not (epsilon1 ≡ epsilon2)
  directions-distinct nontrivial equal = nontrivial (cong (λ z → fst (snd z)) equal)

  -- A cone has an explicitly constructed lift, with pointwise
  -- uniqueness. The original comparison equivalence is not an input.
  module Cone {Z : Set ℓ} (f g : Z → D.E)
      (commute : (z : Z) → D.augmentation (g z) ≡ D.augmentation (f z)) where

    cone-lift : Z → D2.E
    cone-lift z = assemble (f z , (g z , commute z))

    first-lift : (z : Z) → first (cone-lift z) ≡ f z
    first-lift z = refl

    second-lift : (z : Z) → second (cone-lift z) ≡ g z
    second-lift z = pair-path (sym (commute z)) refl

    unique : (h : Z → D2.E)
      → ((z : Z) → first (h z) ≡ f z) → ((z : Z) → second (h z) ≡ g z)
      → (z : Z) → h z ≡ cone-lift z
    unique h first-h second-h z = pair-path (cong fst (first-h z))
      (pair-path (cong snd (first-h z)) (cong snd (second-h z)))
