{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispNaturals where

-- Natural-number parameters can be made crisp using ordinary induction.
-- This construction does not pattern-match on a crisp argument and does
-- not assume a general crisp-induction principle for higher types.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Crisp

flat-natural : ℕ → Flat ℕ
flat-natural zero = box zero
flat-natural (suc n) = flat-map suc (flat-natural n)

counit-flat-natural : (n : ℕ) → counit (flat-natural n) ≡ n
counit-flat-natural zero = refl
counit-flat-natural (suc n) = counit-natural suc (flat-natural n)
  ∙ cong suc (counit-flat-natural n)

-- The motive may depend on ordinary context.  A theorem proved with a
-- crisp numeral therefore applies uniformly at ordinary stage indices,
-- e.g. the join-pushouts field in ModalEtaleDescent.
natural-crisp-elim : {ℓ : Level} (P : ℕ → Type ℓ)
  → ((@♭ n : ℕ) → P n) → (n : ℕ) → P n
natural-crisp-elim P step n = subst P (counit-flat-natural n)
  (flat-elim (λ k → P (counit k)) step (flat-natural n))
