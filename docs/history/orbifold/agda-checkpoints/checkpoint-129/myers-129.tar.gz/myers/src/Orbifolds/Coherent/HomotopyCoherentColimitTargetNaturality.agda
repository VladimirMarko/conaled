{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitTargetNaturality where

-- Target naturality of the actual full bar mapping universal map.
-- The inner coinductive witness carries the complete transition square;
-- finite strict proofs are converted before ordinary-natural iteration.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.GroupoidLaws using (cong-∙)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictHomotopySquares using (adjust-path)
open import Orbifolds.Coherent.StrictHomotopyNaturality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentConeMaps as ConeMaps
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Colimits
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.CellularPresentations as CP
import Orbifolds.CoinductiveTowerSquares as Generic
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC

module Naturality {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    {Y Z : Type ℓ} (k : Y → Z) where
  module MappingD = Mapping.Mapping C D E F using (Into; Postcompose)
  module Bar = Colimits.Construction C D E F
    using (Colimit; state; Stage; inclusion; presentation; module MappingOut)
  module R = Represented.Induction C D E F using (Represented; module Represented; initial)
  module MY = Bar.MappingOut Y
  module MZ = Bar.MappingOut Z
  module Post = ConeMaps.Action (Opposite C) (MappingD.Into Y) (MappingD.Into Z) (MappingD.Postcompose k) E
  open StrictFunctionExtensionality F

  record State : Type (ℓ-suc ℓ) where
    field
      A QY QZ : Type ℓ
      presentation : CP.Presentation A
      SY : Post.Source.Schedule QY
      SZ : Post.Target.Schedule QZ
      representation-Y : MY.Witnesses.Witness presentation (QY , SY)
      representation-Z : MZ.Witnesses.Witness presentation (QZ , SZ)
      map : QY → QZ
      morphism : Post.Morphism SY SZ map

  advance : State → State
  State.A (advance s) = PO.Pushout (CP.Presentation.attach (State.presentation s))
    (CP.Presentation.boundary (State.presentation s))
  State.QY (advance s) = Post.Source.Schedule.Next (State.SY s)
  State.QZ (advance s) = Post.Target.Schedule.Next (State.SZ s)
  State.presentation (advance s) = CP.Presentation.next (State.presentation s)
  State.SY (advance s) = Post.Source.Schedule.tail (State.SY s)
  State.SZ (advance s) = Post.Target.Schedule.tail (State.SZ s)
  State.representation-Y (advance s) = MY.Witnesses.Witness.tail (State.representation-Y s)
  State.representation-Z (advance s) = MZ.Witnesses.Witness.tail (State.representation-Z s)
  State.map (advance s) x = State.map s (x .fst) ,
    Post.Morphism.fiber-map (State.morphism s) (x .fst) (x .snd)
  State.morphism (advance s) = Post.Morphism.tail (State.morphism s)

  left right : (s : State) → (State.A s → Y) → State.QZ s
  left s h = State.map s (MY.Witnesses.Witness.current (State.representation-Y s) .fst h)
  right s h = MZ.Witnesses.Witness.current (State.representation-Z s) .fst (k ∘ h)

  source-drop : (s : State) → (State.A (advance s) → Y) → (State.A s → Y)
  source-drop s h = h ∘ PO.inl

  target-drop : (s : State) → State.QZ (advance s) → State.QZ s
  target-drop s = fst

  left-square : (s : State) → (target-drop s ∘ left (advance s)) ≡ (left s ∘ source-drop s)
  left-square s i h = cong (State.map s)
    (MY.Witnesses.Witness.square (State.representation-Y s) h) i

  right-square : (s : State) → (target-drop s ∘ right (advance s)) ≡ (right s ∘ source-drop s)
  right-square s i h = MZ.Witnesses.Witness.square (State.representation-Z s) (k ∘ h) i

  module Squares = Generic.Squares State (λ s → State.A s → Y) State.QZ advance
    source-drop target-drop left right left-square right-square
  open Squares using (Witness)

  finite-state : (n : Dim) → R.Represented n → State
  State.A (finite-state n previous) = R.Represented.Space previous
  State.QY (finite-state n previous) = Post.SourceFinite.Carrier n
  State.QZ (finite-state n previous) = Post.TargetFinite.Carrier n
  State.presentation (finite-state n previous) = Bar.presentation n previous
  State.SY (finite-state n previous) = Post.SourceFinite.finite-state n .snd
  State.SZ (finite-state n previous) = Post.TargetFinite.finite-state n .snd
  State.representation-Y (finite-state n previous) = MY.finite-witness n previous
  State.representation-Z (finite-state n previous) = MZ.finite-witness n previous
  State.map (finite-state n previous) = Post.FiniteAction.stage-map n
  State.morphism (finite-state n previous) = Post.finite-morphism n

  finite-naturality : (n : Dim) (previous : R.Represented n)
    → outer (left (finite-state n previous)) ≡ˢ outer (right (finite-state n previous))
  finite-naturality n previous = function-ext (R.Represented.restrict-natural previous k)

  abstract
    finite-witness : (n : Dim) (previous : R.Represented n)
      → Witness (finite-state n previous) (strict-to-path (finite-naturality n previous))
    Witness.next (finite-witness n previous) =
      strict-to-path (finite-naturality (osuc n) (Stages.Construction.Step.next C D E F n previous))
    Witness.square (finite-witness n previous) i j h = adjust-path
      (cong-strict-path (Post.FiniteAction.stage-map n)
        (Stages.Construction.Step.transition-computation C D E F n previous Y h))
      (strict-square-pointwise (λ h → h ∘ PO.inl) fst
        (finite-naturality n previous)
        (finite-naturality (osuc n) (Stages.Construction.Step.next C D E F n previous))
        (λ h → strict-cong (λ c → outer (Post.FiniteAction.stage-map n (inner c)))
          (Stages.Construction.Step.transition-computation C D E F n previous Y h))
        (λ h → Stages.Construction.Step.transition-computation C D E F n previous Z (k ∘ h)) h)
      refl i j
    Witness.tail (finite-witness n previous) = finite-witness (osuc n)
      (Stages.Construction.Step.next C D E F n previous)

  actual-state : ℕ → State
  State.A (actual-state n) = Bar.Stage n
  State.QY (actual-state n) = Post.Source.PartialCone n
  State.QZ (actual-state n) = Post.Target.PartialCone n
  State.presentation (actual-state n) = Bar.state n .snd
  State.SY (actual-state n) = Post.Source.stage-schedule n
  State.SZ (actual-state n) = Post.Target.stage-schedule n
  State.representation-Y (actual-state n) = MY.witness-at n
  State.representation-Z (actual-state n) = MZ.witness-at n
  State.map (actual-state n) = Post.partial-map n
  State.morphism (actual-state n) = Post.morphism-at n

  mutual
    stage-naturality : (n : ℕ) → left (actual-state n) ≡ right (actual-state n)
    stage-naturality zero = strict-to-path (finite-naturality ozero R.initial)
    stage-naturality (suc n) = Witness.next (witness-at n)

    witness-at : (n : ℕ) → Witness (actual-state n) (stage-naturality n)
    witness-at zero = finite-witness ozero R.initial
    witness-at (suc n) = Witness.tail (witness-at n)

  source-edge : (h : Bar.Colimit → Y) (n : ℕ)
    → (h ∘ SC.incl {n = suc n} ∘ Bar.inclusion n) ≡ (h ∘ SC.incl {n = n})
  source-edge h n i x = h (SC.push {n = n} x (~ i))

  coherence : (h : Bar.Colimit → Y) (n : ℕ)
    → PathP (λ i → Post.Target.drop n (stage-naturality (suc n) i (h ∘ SC.incl {n = suc n}))
        ≡ stage-naturality n i (h ∘ SC.incl {n = n}))
      (cong (Post.partial-map n) (MY.restrict h .snd n))
      (MZ.restrict (k ∘ h) .snd n)
  coherence h n = adjust-path
    (cong (cong (Post.partial-map n)) (MY.compatibility-computation h n)
      ∙ cong-∙ (Post.partial-map n) (MY.stage-square n (h ∘ SC.incl {n = suc n}))
        (cong (MY.stage-universal n .fst) (source-edge h n)))
    (λ i → (λ j → Witness.square (witness-at n) i j (h ∘ SC.incl {n = suc n}))
      ∙ cong (stage-naturality n i) (source-edge h n))
    (sym (MZ.compatibility-computation (k ∘ h) n))

  restrict-natural : (h : Bar.Colimit → Y)
    → Post.cone-map (MY.restrict h) ≡ MZ.restrict (k ∘ h)
  restrict-natural h i .fst n = stage-naturality n i (h ∘ SC.incl {n = n})
  restrict-natural h i .snd n = coherence h n i
