{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConditionalMetricLattices where

-- The conditional integer groups are actual metrically discrete
-- subgroups of the canonical complex line. Their metric witnesses are
-- inherited from the proved standard lattice for every inner product.
-- A finite-free basis for these actual subgroups decides the ordinary
-- proposition. Uniform basis completion is impossible under K + KL.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Powerset
open import Cubical.Data.Sigma
open import Cubical.Relation.Nullary using (Dec; isPropDec)
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using
  (makeIsGroupHom; compGroupEquiv; invGroupEquiv)
import Cubical.Algebra.Group.Subgroup as SG
open import Cubical.Functions.Embedding
import Cubical.Functions.Fibration as Fib
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexLatticeStructures as LM
import Orbifolds.ConditionalIntegerLattices as CL

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  module Moduli = LM.Geometry R kock order compatibility
  module Standard = Moduli.Standard
  module Canonical = Moduli.Canonical
  module C = Moduli.C
  module H = Moduli.H
  open CommRingStr (R .snd) using (0r; 1r; is-set)
  open SF.RingContext.StrictOrder order using (zero<one)

  module Proposition (P : Type ℓ) (propP : isProp P) where
    module Conditional = CL.Proposition P propP

    module At (τ : H.UpperHalfPlane) where
      inclusion : GroupHom Conditional.GroupH₂ Canonical.Additive
      inclusion .fst x = Standard.standard τ (Conditional.inclusion .fst x)
      inclusion .snd = makeIsGroupHom λ x y → Standard.standard-additive τ
        (Conditional.inclusion .fst x) (Conditional.inclusion .fst y)

      inclusion-embedding : isEmbedding (inclusion .fst)
      inclusion-embedding = injEmbedding C.complex-isSet
        (λ p → isEmbedding→Inj Conditional.inclusion-embedding _ _
          (Standard.standard-injective τ p))

      Member : C.Complex → Type ℓ
      Member z = fiber (inclusion .fst) z

      member-prop : (z : C.Complex) → isProp (Member z)
      member-prop = isEmbedding→hasPropFibers inclusion-embedding

      subset : ℙ C.Complex
      subset z = Member z , member-prop z

      subgroup : Canonical.Subgroup
      subgroup .fst = subset
      SG.isSubgroup.id-closed (subgroup .snd) =
        GroupStr.1g (Conditional.GroupH₂ .snd) , IsGroupHom.pres1 (inclusion .snd)
      SG.isSubgroup.op-closed (subgroup .snd) (x , px) (y , py) =
        GroupStr._·_ (Conditional.GroupH₂ .snd) x y ,
        IsGroupHom.pres· (inclusion .snd) x y ∙ cong₂ C._+c_ px py
      SG.isSubgroup.inv-closed (subgroup .snd) (x , px) =
        GroupStr.inv (Conditional.GroupH₂ .snd) x ,
        IsGroupHom.presinv (inclusion .snd) x ∙ cong C.-c_ px

      LatticeGroup : Group ℓ
      LatticeGroup = SG.Subgroup→Group Canonical.Additive subgroup

      conditional-group-equivalence : GroupEquiv Conditional.GroupH₂ LatticeGroup
      conditional-group-equivalence = Fib.totalEquiv (inclusion .fst) ,
        makeIsGroupHom (λ x y → Σ≡Prop member-prop (IsGroupHom.pres· (inclusion .snd) x y))

      contained-in-standard : (z : C.Complex) → Member z → Standard.Member τ z
      contained-in-standard z (x , p) = Conditional.inclusion .fst x , p

      metrically-discrete : Canonical.MetricallyDiscrete subgroup
      metrically-discrete form = PT.map
        (λ { (q , rational-positive , real-positive , separates) →
          q , rational-positive , real-positive ,
          λ z member below → separates z (contained-in-standard z member) below })
        (Moduli.standard-metric τ form)

      integral-basis→decidable : Canonical.HasIntegralBasis subgroup → Dec P
      integral-basis→decidable = PT.rec (isPropDec propP)
        (λ basis → Conditional.integral-basis→decidable
          (compGroupEquiv basis (invGroupEquiv conditional-group-equivalence)))

  imaginary-point : H.UpperHalfPlane
  imaginary-point = (0r , 1r) , zero<one

  UniformBasisCompletion : Type (ℓ-suc ℓ)
  UniformBasisCompletion = (P : Type ℓ) (propP : isProp P)
    → Canonical.HasIntegralBasis (Proposition.At.subgroup P propP imaginary-point)

  no-uniform-basis-completion : SD.FirstOrder.FirstOrderKL R
    → UniformBasisCompletion → Empty.⊥
  no-uniform-basis-completion kl bases =
    SF.RingContext.Differential.no-decidable-equality R kock kl
      (λ x y → Proposition.At.integral-basis→decidable (x ≡ y) (is-set x y) imaginary-point
        (bases (x ≡ y) (is-set x y)))
