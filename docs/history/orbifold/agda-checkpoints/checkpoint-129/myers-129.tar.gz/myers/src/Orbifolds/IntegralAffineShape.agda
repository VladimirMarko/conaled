{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineShape where

-- Actual shape of the integer affine semidirect quotient. Finite H is
-- R-null; the integer lattice is R-null by native crisp induction. The
-- torsor classifier is therefore null at its own larger universe.
-- Actual connected real-coordinate fibers give the projection theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.FinSet using (isFinSet)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispIntegerNullity as IN
import Orbifolds.CrispFiniteModal as FM
import Orbifolds.TorsorShape as TS
import Orbifolds.Torsors as Torsors
import Orbifolds.EquivariantBundles as EB
import Orbifolds.GeneralLinearMatrices as GL
import Orbifolds.IntegralAffineActions as IA
import Orbifolds.Crystalline as CR
import Orbifolds.ModalPullbacks as MP
import Orbifolds.NullSigmaReflection as NS

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ upper-identity-rules : CI.CrispIdentityInduction {ℓ-suc ℓ})
    (@♭ n : ℕ) (@♭ H : Group ℓ)
    (@♭ ρ : GroupHom H (GL.Ring.Dimension.GeneralLinear ℤCommRing n)) where
  open CommRingStr (R .snd) using (0r)
  module Coordinates = IA.Coordinates R n
  module Affine = Coordinates.Representation H ρ
  module Integers = IN.Context (R .fst) 0r identity-rules
  module Finite = FM.Context (R .fst) 0r identity-rules
  module Classifier = TS.Context (R .fst) upper-identity-rules Affine.AffineGroup
  module T = Torsors.Theory Affine.AffineGroup
  module F = EB.Theory.Action Affine.AffineGroup Affine.Combined.combined
  module Real = CR.Ring R
  module Shape = MP.Theory Real.ShapeModality

  LowerRealFlat = Integers.RealFlat
  UpperRealFlat = Classifier.RealFlatAt

  integer-vector-null : LowerRealFlat
    → NB.isNull Real.ShapeGenerator Coordinates.IntegerVector
  integer-vector-null lower-flat = NP.isNullΠ (λ _ → Integers.integers-null lower-flat)

  lattice-null : LowerRealFlat
    → NB.isNull Real.ShapeGenerator (Coordinates.LatticeGroup .fst)
  lattice-null lower-flat = NP.equivPreservesIsNull LiftEquiv
    (integer-vector-null lower-flat)

  affine-group-null : LowerRealFlat → isFinSet (H .fst)
    → NB.isNull Real.ShapeGenerator (Affine.AffineGroup .fst)
  affine-group-null lower-flat finite = NP.isNullΣ (lattice-null lower-flat)
    (λ _ → Finite.finite-null lower-flat finite)

  classifying-type-null : LowerRealFlat → UpperRealFlat → isFinSet (H .fst)
    → NB.isNull Real.ShapeGenerator T.Torsor
  classifying-type-null lower-flat upper-flat finite =
    Classifier.classifier-null upper-flat (affine-group-null lower-flat finite)

  coordinate-shape-connected : Real.Shape.Connected Coordinates.Vector
  coordinate-shape-connected = Shape.connected-finite-power Real.real-shape-connected n

  regular-fiber-connected : Real.Shape.Connected (F.Bundle T.regular-torsor)
  regular-fiber-connected = Shape.connected-equiv (invEquiv F.regular-coordinates)
    coordinate-shape-connected

  all-fibers-connected : (t : T.Torsor) → Real.Shape.Connected (F.Bundle t)
  all-fibers-connected t = PT.rec isPropIsContr
    (λ p → subst (λ u → Real.Shape.Connected (F.Bundle u)) p regular-fiber-connected)
    (T.torsor-connected t)

  module Modal (lower-flat : LowerRealFlat) (upper-flat : UpperRealFlat)
      (finite : isFinSet (H .fst)) where
    module Reflection = NS.Theory.Over Real.ShapeGenerator T.Torsor
      (classifying-type-null lower-flat upper-flat finite) F.Bundle
    module Connected = Reflection.ConnectedFibers all-fibers-connected

    shape-affine-quotient≃classifying-type : NB.Null Real.ShapeGenerator F.Family.Quotient ≃ T.Torsor
    shape-affine-quotient≃classifying-type = Connected.reflection≃base

    projection-unit : (z : F.Family.Quotient)
      → shape-affine-quotient≃classifying-type .fst NB.∣ z ∣ ≡ z .fst
    projection-unit = Reflection.projection-unit

    orbit-point-triangle : (x : Coordinates.Vector)
      → shape-affine-quotient≃classifying-type .fst
          NB.∣ F.Family.quotient (F.orbit x) ∣ ≡ T.regular-torsor
    orbit-point-triangle x = refl
