{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictPathNormalization where

-- Normalize a compatibility path with a strict endpoint computation to
-- a literal endpoint-cast path. This separates ordinary path-composition
-- coherence from the pointwise strict cube comparisons used by bar maps.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.GroupoidLaws using (lUnit; rUnit)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)

strict-concat-left : ∀ {ℓ} {A : Type ℓ} {a b c : A}
  (e : outer a ≡ˢ outer b) (p : b ≡ c)
  → strict-to-path e ∙ p ≡ strict-end-path (λ i → p i) (strict-sym e) reflˢ
strict-concat-left reflˢ p = sym (lUnit p)

strict-concat-right : ∀ {ℓ} {A : Type ℓ} {a b c : A}
  (p : a ≡ b) (e : outer b ≡ˢ outer c)
  → p ∙ strict-to-path e ≡ strict-end-path (λ i → p i) reflˢ e
strict-concat-right p reflˢ = sym (rUnit p)

map-strict-end-path : ∀ {ℓ ℓ'} {A : Type ℓ} {B : Type ℓ'}
  (f : A → B) (p : I → A) {a b : A}
  (e₀ : outer (p i0) ≡ˢ outer a) (e₁ : outer (p i1) ≡ˢ outer b)
  → outer (cong f (strict-end-path p e₀ e₁))
    ≡ˢ outer (strict-end-path (λ i → f (p i))
      (strict-cong (λ x → outer (f (inner x))) e₀)
      (strict-cong (λ x → outer (f (inner x))) e₁))
map-strict-end-path f p reflˢ reflˢ = reflˢ

map-normal-form : ∀ {ℓ ℓ'} {A : Type ℓ} {B : Type ℓ'}
  (f : A → B) {a b c : A} (e : outer a ≡ˢ outer b) (p : b ≡ c)
  → cong f (strict-to-path e ∙ p)
    ≡ strict-end-path (λ i → f (p i))
      (strict-cong (λ x → outer (f (inner x))) (strict-sym e)) reflˢ
map-normal-form f e p = cong (cong f) (strict-concat-left e p)
  ∙ strict-to-path (map-strict-end-path f (λ i → p i) (strict-sym e) reflˢ)
