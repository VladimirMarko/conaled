{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalCubicalFillerRepresentation where

-- A natural equivalence between actual endpoint-typed fillers and
-- sphere nullhomotopies. Inverse evaluation is aligned through the
-- contractible fibers of quotation, retaining its boundary coherence.
-- The evaluation-naturality path below is the one used throughout;
-- no equality with a separately chosen inverse comparison is assumed.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Transport using
  (substCommSlice; constSubstCommSlice; substEquiv)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
import Orbifolds.Coherent.StrictCubicalFillerMaps as FM
import Orbifolds.Coherent.StrictCubicalShellMaps as SM
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as SR
import Orbifolds.Coherent.NaturalCubicalFillerBoundary as NB
import Orbifolds.Coherent.NaturalQuotedFillers as QF
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)

module Natural {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module F = FM.Action E
  module S = SM.Action E
  module R = SR.Representation E
  module Q = QF.Natural E
  open R using (evaluate) public

  QuoteFiber : (n : Dim) {X : Type ℓ} → CS.Shell (toNat n) X → Type ℓ
  QuoteFiber n b = fiber (R.quote-shell n) b

  canonical-fiber : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X) → QuoteFiber n b
  canonical-fiber n b = evaluate n b , R.quote-evaluate n b

  map-fiber : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → QuoteFiber n b → QuoteFiber n (S.map-shell n f b)
  map-fiber n f b (h , p) = (f ∘ h) , strict-end-path
    (λ i → S.map-shell n f (p i)) (R.quote-natural n f h) reflˢ

  fiber-fill : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    (z : QuoteFiber n b) → Q.SphereNull n (z .fst) → CF.Filler (toNat n) b
  fiber-fill n b (h , p) u = subst (CF.Filler (toNat n)) p (Q.quoted-fill n h u)

  fiber-fill-equivalence : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    (z : QuoteFiber n b) → Q.SphereNull n (z .fst) ≃ CF.Filler (toNat n) b
  fiber-fill-equivalence n b (h , p) = Q.quoted-fill-equivalence n h
    ∙ₑ substEquiv (CF.Filler (toNat n)) p

  fiber-fill-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    (z : QuoteFiber n b) (u : Q.SphereNull n (z .fst))
    → F.map-filler n f b (fiber-fill n b z u)
      ≡ fiber-fill n (S.map-shell n f b) (map-fiber n f b z)
          (Q.map-sphere-null n f (z .fst) u)
  fiber-fill-natural n f b (h , p) u =
    sym (substCommSlice (CF.Filler (toNat n))
      (λ a → CF.Filler (toNat n) (S.map-shell n f a))
      (F.map-filler n f) p (Q.quoted-fill n h u))
    ∙ NB.subst-filler-strict-start n (R.quote-natural n f h)
        (λ i → S.map-shell n f (p i))
        (F.map-filler n f (R.quote-shell n h) (Q.quoted-fill n h u))
    ∙ cong (subst (CF.Filler (toNat n))
        (strict-end-path (λ i → S.map-shell n f (p i))
          (R.quote-natural n f h) reflˢ))
        (Q.quoted-fill-natural n f h u)

  fiber-alignment : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → canonical-fiber n (S.map-shell n f b) ≡ map-fiber n f b (canonical-fiber n b)
  fiber-alignment n {Y = Y} f b = R.quote-isEquiv n Y .equiv-proof
    (S.map-shell n f b) .snd (map-fiber n f b (canonical-fiber n b))

  evaluate-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → evaluate n (S.map-shell n f b) ≡ f ∘ evaluate n b
  evaluate-natural n f b i = fiber-alignment n f b i .fst

  Nullhomotopy : (n : Dim) {X : Type ℓ} → CS.Shell (toNat n) X → Type ℓ
  Nullhomotopy n b = Q.SphereNull n (evaluate n b)

  map-nullhomotopy : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → Nullhomotopy n b → Nullhomotopy n (S.map-shell n f b)
  map-nullhomotopy n f b (x , p) = f x ,
    (evaluate-natural n f b ∙ (λ i s → f (p i s)))

  fill-nullhomotopy : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → Nullhomotopy n b → CF.Filler (toNat n) b
  fill-nullhomotopy n b = fiber-fill n b (canonical-fiber n b)

  nullhomotopy-filler : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → Nullhomotopy n b ≃ CF.Filler (toNat n) b
  nullhomotopy-filler n b = fiber-fill-equivalence n b (canonical-fiber n b)

  filler-nullhomotopy : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → CF.Filler (toNat n) b ≃ Nullhomotopy n b
  filler-nullhomotopy n b = invEquiv (nullhomotopy-filler n b)

  fill-nullhomotopy-computation : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    (u : Nullhomotopy n b)
    → invEq (filler-nullhomotopy n b) u ≡ fill-nullhomotopy n b u
  fill-nullhomotopy-computation n b u = refl

  alignment-transport : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    (u : Nullhomotopy n b)
    → subst (λ z → Q.SphereNull n (z .fst)) (sym (fiber-alignment n f b))
        (Q.map-sphere-null n f (evaluate n b) u)
      ≡ map-nullhomotopy n f b u
  alignment-transport n f b (x , p) = fromPathP
    (λ i → f x , compPath-filler' (evaluate-natural n f b) (λ j s → f (p j s)) i)

  fill-nullhomotopy-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (b : CS.Shell (toNat n) X) (u : Nullhomotopy n b)
    → F.map-filler n f b (fill-nullhomotopy n b u)
      ≡ fill-nullhomotopy n (S.map-shell n f b) (map-nullhomotopy n f b u)
  fill-nullhomotopy-natural n f b u =
    fiber-fill-natural n f b (canonical-fiber n b) u
    ∙ constSubstCommSlice (λ z → Q.SphereNull n (z .fst))
        (CF.Filler (toNat n) (S.map-shell n f b))
        (fiber-fill n (S.map-shell n f b))
        (sym (fiber-alignment n f b)) (Q.map-sphere-null n f (evaluate n b) u)
    ∙ cong (fill-nullhomotopy n (S.map-shell n f b)) (alignment-transport n f b u)

  filler-nullhomotopy-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (b : CS.Shell (toNat n) X) (c : CF.Filler (toNat n) b)
    → filler-nullhomotopy n (S.map-shell n f b) .fst (F.map-filler n f b c)
      ≡ map-nullhomotopy n f b (filler-nullhomotopy n b .fst c)
  filler-nullhomotopy-natural n f b c =
    cong (filler-nullhomotopy n (S.map-shell n f b) .fst)
      (sym (cong (F.map-filler n f b) (secEq (nullhomotopy-filler n b) c))
        ∙ fill-nullhomotopy-natural n f b (filler-nullhomotopy n b .fst c))
    ∙ retEq (nullhomotopy-filler n (S.map-shell n f b))
        (map-nullhomotopy n f b (filler-nullhomotopy n b .fst c))
