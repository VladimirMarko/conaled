{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FinalTopology where

-- Actual final open fragment for a small family of maps. No quotient topology
-- or continuity theorem is an input. No proof-irrelevance of openness is used.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  (Subset; member; OpenFragment; IsOpen; open-full; open-transfer; open-intersection; open-local)
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)

module Construction {ℓ : Level} {I Q : Set ℓ} {A : I → Set ℓ}
    (OA : (i : I) → OpenFragment (A i)) (chart : (i : I) → A i → Q) where

  topology : OpenFragment Q
  IsOpen topology P = (i : I) → IsOpen (OA i) (preimage (chart i) P)
  open-full topology i = open-full (OA i)
  open-transfer topology to from opens i = open-transfer (OA i)
    (λ a → to (chart i a)) (λ a → from (chart i a)) (opens i)
  open-intersection topology opens-P opens-Q i =
    open-intersection (OA i) (opens-P i) (opens-Q i)
  open-local topology P local i = open-local (OA i) (preimage (chart i) P)
    (λ a p →
      let chosen = local (chart i a) p
          U = fst chosen
          open-U = fst (snd chosen)
          at-center = fst (snd (snd chosen))
          inside = snd (snd (snd chosen))
      in preimage (chart i) U , (open-U i , (at-center ,
        (λ b u → inside (chart i b) u))))

  chart-continuous : (i : I) → Continuous (OA i) topology (chart i)
  chart-continuous i P opens = opens i

  continuous-from-charts : {Y : Set ℓ} (OY : OpenFragment Y) (f : Q → Y)
    → ((i : I) → Continuous (OA i) OY (λ a → f (chart i a)))
    → Continuous topology OY f
  continuous-from-charts OY f local P open-P i = local i P open-P

  continuous-to-charts : {Y : Set ℓ} (OY : OpenFragment Y) (f : Q → Y)
    → Continuous topology OY f
    → (i : I) → Continuous (OA i) OY (λ a → f (chart i a))
  continuous-to-charts OY f global i P open-P = global P open-P i

-- With no jointly-surjective family this remains a final topology but is not
-- asserted to be a covered quotient presentation. Coverage is a separate fact.

  module Restricted (V : Subset Q) (open-V : IsOpen topology V) where
    import Orbifolds.Intensional.OpenSubspaces as OS

    restricted-domain : (i : I) → Subset (A i)
    restricted-domain i = preimage (chart i) V

    domain-topology : (i : I) → OpenFragment (OS.Carrier (restricted-domain i))
    domain-topology i = OS.openSubspace (OA i) (restricted-domain i) (open-V i)

    subspace-topology : OpenFragment (OS.Carrier V)
    subspace-topology = OS.openSubspace topology V open-V

    restricted-chart : (i : I) → OS.Carrier (restricted-domain i) → OS.Carrier V
    restricted-chart i (a , v) = chart i a , v

    continuous-from-restricted-charts : {Y : Set ℓ} (OY : OpenFragment Y) (f : OS.Carrier V → Y)
      → ((i : I) → Continuous (domain-topology i) OY (λ a → f (restricted-chart i a)))
      → Continuous subspace-topology OY f
    continuous-from-restricted-charts OY f local P open-P i = local i P open-P

    continuous-to-restricted-charts : {Y : Set ℓ} (OY : OpenFragment Y) (f : OS.Carrier V → Y)
      → Continuous subspace-topology OY f
      → (i : I) → Continuous (domain-topology i) OY (λ a → f (restricted-chart i a))
    continuous-to-restricted-charts OY f global i P open-P = global P open-P i
