{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

-- Countable Flat products from the explicit ambient crisp rules and
-- R-flat. No countable-choice or Flat-product preservation axiom is used.
-- The index is represented by Flat Ix so every fibre Flat (A i) is formed
-- at a genuinely crisp i. Nat is reindexed to ordinary stage indices.
module Orbifolds.CrispProducts where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Univalence
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispNaturalDiscreteness as CN

-- The forward map is literally restriction of a dependent section.
dependent-restriction : ∀ {ℓi ℓa} {Ix Jx : Type ℓi}
  (e : Jx ≃ Ix) (A : Ix → Type ℓa)
  → isEquiv (λ (f : (i : Ix) → A i) (j : Jx) → f (equivFun e j))
dependent-restriction {ℓa = ℓa} {Ix = Ix} = EquivJ
  (λ Jx e → (A : Ix → Type ℓa)
    → isEquiv (λ (f : (i : Ix) → A i) (j : Jx) → f (equivFun e j)))
  (λ A → idIsEquiv ((i : Ix) → A i))

-- Null types are closed under arbitrary dependent products; this is a
-- direct mapping-space calculation and uses no crisp structure.
null-product : ∀ {ℓi ℓa ℓr} {Ix : Type ℓi} {A : Ix → Type ℓa} {R : Type ℓr}
  → ((i : Ix) → isEquiv (const :> (A i → (R → A i))))
  → isEquiv (const :> (((i : Ix) → A i) → (R → (i : Ix) → A i)))
null-product {Ix = Ix} {A = A} {R = R} nullA = snd
  (compEquiv (equivΠCod (λ i → const , nullA i))
    (isoToEquiv (iso (λ f r i → f i r) (λ f i r → f r i)
      (λ _ → refl) (λ _ → refl))))

module Family {@♭ ℓ : Level} (@♭ Ix : Type₀) (@♭ A : Ix → Type ℓ) where
  Full : Type ℓ
  Full = (i : Ix) → A i

  FlatFamily : Flat Ix → Type ℓ
  FlatFamily (box i) = Flat (A i)

  Product : Type ℓ
  Product = (u : Flat Ix) → FlatFamily u

  Restricted : Type ℓ
  Restricted = (u : Flat Ix) → A (counit u)

  restrict : Full → Restricted
  restrict f u = f (counit u)

  restriction-equivalence : (@♭ discrete-Ix : CrisplyDiscrete Ix) → Full ≃ Restricted
  restriction-equivalence discrete-Ix = restrict
    , dependent-restriction (counit , discrete-Ix) A

  unbox-section : Product → Restricted
  unbox-section p (box i) = counit (p (box i))

  restricted-comparison : Flat Restricted → Product
  restricted-comparison (box f) (box i) = box (f (box i))

  comparison : Flat Full → Product
  comparison (box f) (box i) = box (f i)

  unbox-comparison : (@♭ f : Restricted)
    → unbox-section (restricted-comparison (box f)) ≡ f
  unbox-comparison f = funExt λ { (box i) → refl }

  module WithCohesion
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ R : Type ℓ)
    (real-flat : (@♭ X : Type ℓ)
      → CrisplyDiscrete X ≃ isEquiv (const :> (X → (R → X)))) where
    module Identity = CI.Theory identity-rules
    module FlatTheory = CF.Theory flat-induction flat-computation

    crisp-box-counit : {@♭ X : Type ℓ} (@♭ u : Flat X) → box (counit u) ≡ u
    crisp-box-counit u = cong (flat-map counit)
      (sym (FlatTheory.crisp-duplicate-eta u)) ∙ map-counit-duplicate u

    null-fibre : (u : Flat Ix)
      → isEquiv (const :> (FlatFamily u → (R → FlatFamily u)))
    null-fibre (box i) = equivFun (real-flat (Flat (A i)))
      (FlatTheory.flat-is-discrete {A = A i})

    product-null : isEquiv (const :> (Product → (R → Product)))
    product-null = null-product null-fibre

    product-discrete : CrisplyDiscrete Product
    product-discrete = invEq (real-flat Product) product-null

    product-counit : Flat Product ≃ Product
    product-counit = counit , product-discrete

    backward : Product → Flat Restricted
    backward p = flat-map unbox-section (invEq product-counit p)

    rebox-section : (p : Flat Product)
      → restricted-comparison (flat-map unbox-section p) ≡ counit p
    rebox-section (box p) = funExt λ { (box i) → crisp-box-counit (p (box i)) }

    right-inverse : (p : Product) → restricted-comparison (backward p) ≡ p
    right-inverse p = rebox-section (invEq product-counit p) ∙ secEq product-counit p

    left-inverse : (f : Flat Restricted) → backward (restricted-comparison f) ≡ f
    left-inverse (box f) = cong (flat-map unbox-section)
      (retEq product-counit (box (restricted-comparison (box f))))
      ∙ Identity.box-path (unbox-section (restricted-comparison (box f))) f
          (unbox-comparison f)

    abstract
      restricted-isEquiv : isEquiv restricted-comparison
      restricted-isEquiv = isoToIsEquiv
        (iso restricted-comparison backward right-inverse left-inverse)

    restricted-equivalence : Flat Restricted ≃ Product
    restricted-equivalence = restricted-comparison , restricted-isEquiv

    module DiscreteIndex (@♭ discrete-Ix : CrisplyDiscrete Ix) where
      composite : Flat Full ≃ Product
      composite = compEquiv (Identity.flat-equivalence (restriction-equivalence discrete-Ix))
        restricted-equivalence

      comparison-agrees : (f : Flat Full) → equivFun composite f ≡ comparison f
      comparison-agrees (box f) = funExt λ { (box i) → refl }

      comparison-isEquiv : isEquiv comparison
      comparison-isEquiv = subst isEquiv (funExt comparison-agrees) (snd composite)

      flat-product-equivalence : Flat Full ≃ Product
      flat-product-equivalence = comparison , comparison-isEquiv

module NatProducts {@♭ ℓ : Level}
  (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
  (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
  (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
  (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
  (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
  (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
  (@♭ R : Type ℓ)
  (real-flat : (@♭ X : Type ℓ)
    → CrisplyDiscrete X ≃ isEquiv (const :> (X → (R → X))))
  (@♭ A : ℕ → Type ℓ) where
  module Naturals = CN.Theory identity-zero flat-zero flat-zero-computation
  module F = Family ℕ A
  module Core = F.WithCohesion identity-rules flat-induction flat-computation R real-flat
  module Discrete = Core.DiscreteIndex
    (CN.Theory.naturals-discrete identity-zero flat-zero flat-zero-computation)

  lift-naturals-equivalence : ℕ ≃ Flat ℕ
  lift-naturals-equivalence = isoToEquiv
    (iso flat-natural counit Naturals.flat-natural-counit counit-flat-natural)

  OrdinaryProduct : Type ℓ
  OrdinaryProduct = (n : ℕ) → F.FlatFamily (flat-natural n)

  comparison : Flat ((n : ℕ) → A n) → OrdinaryProduct
  comparison f n = F.comparison f (flat-natural n)

  flat-product-equivalence : Flat ((n : ℕ) → A n) ≃ OrdinaryProduct
  flat-product-equivalence = compEquiv Discrete.flat-product-equivalence
    ((λ (p : F.Product) (n : ℕ) → p (flat-natural n))
      , dependent-restriction lift-naturals-equivalence F.FlatFamily)
