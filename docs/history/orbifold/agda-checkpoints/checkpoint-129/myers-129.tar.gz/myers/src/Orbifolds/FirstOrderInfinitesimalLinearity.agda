{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderInfinitesimalLinearity where

-- Definitions 4.2.13 and 4.2.16, and the D(n) specialization of the
-- delooping theorem.  D(n) is the actual pairwise-square-zero locus in
-- R^n.  The two inclusions insert zero coordinates in the other block.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_; inl; inr)
open import Cubical.Data.Nat using (ℕ; _+_)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispNaturalDiscreteness as CN
import Orbifolds.CrispPropositions as CP
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyNullificationColimits as NC
import Orbifolds.DeloopingInfinitesimalLinearity as DL
import Orbifolds.Quotients as Q

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd) using (0r; _·_; is-set)
  open RingTheory (CommRing→Ring R)

  PairwiseZero : {n : ℕ} → (FD.Fin n → R .fst) → Type ℓ
  PairwiseZero x = ∀ i j → x i · x j ≡ 0r

  pairwise-zero-isProp : {n : ℕ} (x : FD.Fin n → R .fst)
    → isProp (PairwiseZero x)
  pairwise-zero-isProp x = isPropΠ2 λ _ _ → is-set _ _

  D : ℕ → Type ℓ
  D n = Σ (FD.Fin n → R .fst) PairwiseZero

  zeroD : (n : ℕ) → D n
  zeroD n = const 0r , λ _ _ → 0RightAnnihilates 0r

  module Axes (n m : ℕ) where
    split : FD.Fin (n + m) → FD.Fin n ⊎ FD.Fin m
    split = FD.FinSumChar.inv n m

    left-values : D n → FD.Fin n ⊎ FD.Fin m → R .fst
    left-values x (inl i) = x .fst i
    left-values x (inr j) = 0r

    right-values : D m → FD.Fin n ⊎ FD.Fin m → R .fst
    right-values y (inl i) = 0r
    right-values y (inr j) = y .fst j

    left-products : (x : D n) (i j : FD.Fin n ⊎ FD.Fin m)
      → left-values x i · left-values x j ≡ 0r
    left-products x (inl i) (inl j) = x .snd i j
    left-products x (inl i) (inr j) = 0RightAnnihilates (x .fst i)
    left-products x (inr i) j = 0LeftAnnihilates (left-values x j)

    right-products : (y : D m) (i j : FD.Fin n ⊎ FD.Fin m)
      → right-values y i · right-values y j ≡ 0r
    right-products y (inl i) j = 0LeftAnnihilates (right-values y j)
    right-products y (inr i) (inl j) = 0RightAnnihilates (y .fst i)
    right-products y (inr i) (inr j) = y .snd i j

    left : D n → D (n + m)
    left x = left-values x ∘ split , λ i j → left-products x (split i) (split j)

    right : D m → D (n + m)
    right y = right-values y ∘ split , λ i j → right-products y (split i) (split j)

    left-at-left : (x : D n) (i : FD.Fin n)
      → left x .fst (FD.FinSumChar.fun n m (inl i)) ≡ x .fst i
    left-at-left x i = cong (left-values x) (FD.FinSumChar.ret n m (inl i))

    left-at-right : (x : D n) (j : FD.Fin m)
      → left x .fst (FD.FinSumChar.fun n m (inr j)) ≡ 0r
    left-at-right x j = cong (left-values x) (FD.FinSumChar.ret n m (inr j))

    right-at-left : (y : D m) (i : FD.Fin n)
      → right y .fst (FD.FinSumChar.fun n m (inl i)) ≡ 0r
    right-at-left y i = cong (right-values y) (FD.FinSumChar.ret n m (inl i))

    right-at-right : (y : D m) (j : FD.Fin m)
      → right y .fst (FD.FinSumChar.fun n m (inr j)) ≡ y .fst j
    right-at-right y j = cong (right-values y) (FD.FinSumChar.ret n m (inr j))

    left-zero-coordinate : (i : FD.Fin n ⊎ FD.Fin m)
      → left-values (zeroD n) i ≡ 0r
    left-zero-coordinate (inl i) = refl
    left-zero-coordinate (inr i) = refl

    right-zero-coordinate : (i : FD.Fin n ⊎ FD.Fin m)
      → right-values (zeroD m) i ≡ 0r
    right-zero-coordinate (inl i) = refl
    right-zero-coordinate (inr i) = refl

    left-origin : left (zeroD n) ≡ zeroD (n + m)
    left-origin = Σ≡Prop pairwise-zero-isProp (funExt λ i → left-zero-coordinate (split i))

    right-origin : right (zeroD m) ≡ zeroD (n + m)
    right-origin = Σ≡Prop pairwise-zero-isProp (funExt λ i → right-zero-coordinate (split i))

    diagram : DL.PointedAxes ℓ
    DL.PointedAxes.leftTest diagram = D n
    DL.PointedAxes.rightTest diagram = D m
    DL.PointedAxes.unionTest diagram = D (n + m)
    DL.PointedAxes.leftOrigin diagram = zeroD n
    DL.PointedAxes.rightOrigin diagram = zeroD m
    DL.PointedAxes.leftInclusion diagram = left
    DL.PointedAxes.rightInclusion diagram = right
    DL.PointedAxes.originsAgree diagram = left-origin ∙ sym right-origin

    module Maps = DL.Mapping diagram

  InfinitesimallyLinear : Type ℓ → Type ℓ
  InfinitesimallyLinear X = (n m : ℕ) → Axes.Maps.IsLinear n m X

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CI.CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero) where
  open CommRingStr (R .snd) using (0r)
  module Disks = Ring R
  module Naturals = CN.Theory identity-zero flat-zero flat-zero-computation
  module Propositions = CP.Context (R .fst) 0r
  module Deloopings = DL.Context rules identity-zero flat-zero flat-zero-computation (R .fst) 0r
  open Propositions using (RealFlat)

  -- The restriction of Postulate W needed by this theorem.  A future
  -- presentation of D(n) by square-zero Weil algebras can discharge this
  -- from a single global W assumption.  No colimit, connectedness, or
  -- delooping preservation is included in this assumption.
  TinyDisks : Type (ℓ-suc ℓ)
  TinyDisks = (@♭ n : ℕ) → TT.External.Tiny (Disks.D n)

  preserves-infinitesimal-linearity : RealFlat → TinyDisks
    → (@♭ G : Q.Delooping ℓ)
    → Disks.InfinitesimallyLinear (Q.Loop G)
    → Disks.InfinitesimallyLinear (Q.BG G)
  preserves-infinitesimal-linearity real-flat tiny G linear =
    NC.discrete-index-elim Naturals.naturals-discrete
      (λ n → (m : ℕ) → Disks.Axes.Maps.IsLinear n m (Q.BG G))
      (λ n → NC.discrete-index-elim Naturals.naturals-discrete
        (λ m → Disks.Axes.Maps.IsLinear n m (Q.BG G))
        (λ m → Deloopings.Diagram.preserves-linearity (Disks.Axes.diagram n m) G
          real-flat (tiny n) (tiny m) (tiny (n + m)) (linear n m)))
