{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalShellCurrying where

-- Actual currying of complete cubes, shells and dependent fillers.
-- Cubes exchange interval and parameter arguments literally. Shells use
-- their proved sphere representation, with the restriction and point
-- evaluation comparisons proved explicitly. No truncation is involved.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Univalence using (pathToEquiv)
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.CubicalShells using (Cube; Shell; restriction; origin)
import Orbifolds.CubicalShellSpheres as SS
open SS using (SphereBoundary; evaluate-shell; restriction-computation)
open import Orbifolds.CubicalShellMaps using (map-shell)
open import Orbifolds.CubicalShellFillers using (Filler)
import Orbifolds.CubicalFillerFunctionTypes as FF

module Curry {ℓt ℓx : Level} (T : Type ℓt) (X : Type ℓx) where
  cube-curry : (n : ℕ) → (T → Cube n X) → Cube n (T → X)
  cube-curry zero f = f
  cube-curry (suc n) f i = cube-curry n (λ t → f t i)

  cube-uncurry : (n : ℕ) → Cube n (T → X) → T → Cube n X
  cube-uncurry zero f = f
  cube-uncurry (suc n) f t i = cube-uncurry n (f i) t

  cube-curry-uncurry : (n : ℕ) (c : Cube n (T → X))
    → cube-curry n (cube-uncurry n c) ≡ c
  cube-curry-uncurry zero c = refl
  cube-curry-uncurry (suc n) c j i = cube-curry-uncurry n (c i) j

  cube-uncurry-curry : (n : ℕ) (f : T → Cube n X)
    → cube-uncurry n (cube-curry n f) ≡ f
  cube-uncurry-curry zero f = refl
  cube-uncurry-curry (suc n) f j t i = cube-uncurry-curry n (λ t → f t i) j t

  cube-equivalence : (n : ℕ) → (T → Cube n X) ≃ Cube n (T → X)
  cube-equivalence n = isoToEquiv (iso (cube-curry n) (cube-uncurry n)
    (cube-curry-uncurry n) (cube-uncurry-curry n))

  cube-origin : (n : ℕ) (f : T → Cube n X)
    → origin n (cube-curry n f) ≡ (λ t → origin n (f t))
  cube-origin zero f = refl
  cube-origin (suc n) f = cube-origin n (λ t → f t i0)

  swap : (n : ℕ) → (T → SphereBoundary n → X) ≃ (SphereBoundary n → T → X)
  swap n = isoToEquiv (iso (λ f s t → f t s) (λ f t s → f s t)
    (λ _ → refl) (λ _ → refl))

  shell-equivalence : (n : ℕ) → (T → Shell n X) ≃ Shell n (T → X)
  shell-equivalence n = equivΠCod (λ _ → SS.shell-equivalence n X)
    ∙ₑ swap n ∙ₑ invEquiv (SS.shell-equivalence n (T → X))

  shell-curry : (n : ℕ) → (T → Shell n X) → Shell n (T → X)
  shell-curry n = shell-equivalence n .fst

  shell-uncurry : (n : ℕ) → Shell n (T → X) → T → Shell n X
  shell-uncurry n = invEq (shell-equivalence n)

  shell-curry-uncurry : (n : ℕ) (b : Shell n (T → X))
    → shell-curry n (shell-uncurry n b) ≡ b
  shell-curry-uncurry n = secEq (shell-equivalence n)

  shell-uncurry-curry : (n : ℕ) (b : T → Shell n X)
    → shell-uncurry n (shell-curry n b) ≡ b
  shell-uncurry-curry n = retEq (shell-equivalence n)

  evaluate-curry : (n : ℕ) (b : T → Shell n X)
    → evaluate-shell n (shell-curry n b) ≡ (λ s t → evaluate-shell n (b t) s)
  evaluate-curry n b = secEq (SS.shell-equivalence n (T → X))
    (λ s t → evaluate-shell n (b t) s)

  point-shell : (n : ℕ) (b : T → Shell n X) (t : T)
    → map-shell n (λ f → f t) (shell-curry n b) ≡ b t
  point-shell n b t = cong (λ h → invEq (SS.shell-equivalence n X)
      (λ s → h s t)) (evaluate-curry n b)
    ∙ retEq (SS.shell-equivalence n X) (b t)

  restriction-square : (n : ℕ) (c : T → Cube n X)
    → shell-curry n (λ t → restriction n (c t)) ≡ restriction n (cube-curry n c)
  restriction-square n c = invEq
    (congEquiv (SS.shell-equivalence n (T → X)))
    (evaluate-curry n (λ t → restriction n (c t))
      ∙ (λ i s t → restriction-computation n X (c t) i s)
      ∙ cong (λ f (_ : SphereBoundary n) → f) (sym (cube-origin n c))
      ∙ sym (restriction-computation n (T → X) (cube-curry n c)))

  filler-uncurry-equivalence : (n : ℕ) (b : T → Shell n X)
    → Filler n (shell-curry n b) ≃ ((t : T) → Filler n (b t))
  filler-uncurry-equivalence n b = FF.At.equivalence n T X (shell-curry n b)
    ∙ₑ equivΠCod (λ t → pathToEquiv (cong (Filler n) (point-shell n b t)))

  filler-equivalence : (n : ℕ) (b : T → Shell n X)
    → ((t : T) → Filler n (b t)) ≃ Filler n (shell-curry n b)
  filler-equivalence n b = invEquiv (filler-uncurry-equivalence n b)

  filler-curry : (n : ℕ) (b : T → Shell n X)
    → ((t : T) → Filler n (b t)) → Filler n (shell-curry n b)
  filler-curry n b = filler-equivalence n b .fst

  filler-uncurry : (n : ℕ) (b : T → Shell n X)
    → Filler n (shell-curry n b) → (t : T) → Filler n (b t)
  filler-uncurry n b = filler-uncurry-equivalence n b .fst

  filler-curry-uncurry : (n : ℕ) (b : T → Shell n X)
    (f : Filler n (shell-curry n b)) → filler-curry n b (filler-uncurry n b f) ≡ f
  filler-curry-uncurry n b = retEq (filler-uncurry-equivalence n b)

  filler-uncurry-curry : (n : ℕ) (b : T → Shell n X)
    (f : (t : T) → Filler n (b t)) → filler-uncurry n b (filler-curry n b f) ≡ f
  filler-uncurry-curry n b = secEq (filler-uncurry-equivalence n b)
