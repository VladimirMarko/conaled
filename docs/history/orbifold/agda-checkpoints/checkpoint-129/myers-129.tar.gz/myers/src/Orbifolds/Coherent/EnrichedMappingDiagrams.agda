{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedMappingDiagrams where

-- Cocones are cones of the actual opposite mapping diagram. The
-- postcomposition maps are strict natural transformations, derived from
-- ordinary function composition rather than a naturality assumption.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Orbifolds.Coherent.StrictEnriched

Opposite : ∀ {ℓo ℓh} → Category ℓo ℓh → Category ℓo ℓh
Category.Obj (Opposite C) = Category.Obj C
Category.Hom (Opposite C) x y = Category.Hom C y x
Category.ident (Opposite C) = Category.ident C
Category.compose (Opposite C) g f = Category.compose C f g
Category.assoc (Opposite C) h g f = strict-sym (Category.assoc C f g h)
Category.left (Opposite C) f = Category.right C f
Category.right (Opposite C) f = Category.left C f

record Transformation {ℓo ℓh ℓa ℓb : Level} {C : Category ℓo ℓh}
    (D : Diagram C ℓa) (E : Diagram C ℓb)
    : SSet (ℓ-max ℓo (ℓ-max ℓh (ℓ-max ℓa ℓb))) where
  field
    component : (x : Category.Obj C) → Diagram.Value D x → Diagram.Value E x
    natural : {x y : Category.Obj C} (f : Category.Hom C x y)
      → outer (Diagram.action E f ∘ component x)
        ≡ˢ outer (component y ∘ Diagram.action D f)

module Mapping {ℓo ℓh ℓa : Level} {C : Category ℓo ℓh} (D : Diagram C ℓa) where
  open Category C
  open Diagram D

  Into : ∀ {ℓy} → Type ℓy → Diagram (Opposite C) (ℓ-max ℓa ℓy)
  Diagram.Value (Into Y) x = Value x → Y
  Diagram.action (Into Y) f h = h ∘ action f
  Diagram.action-compose (Into Y) g f = strict-cong
    (λ q → outer (λ h x → h (inner q x))) (action-compose f g)
  Diagram.action-id (Into Y) x = strict-cong
    (λ q → outer (λ h a → h (inner q a))) (action-id x)

  Postcompose : ∀ {ℓy ℓz} {Y : Type ℓy} {Z : Type ℓz}
    → (Y → Z) → Transformation (Into Y) (Into Z)
  Transformation.component (Postcompose k) x h = k ∘ h
  Transformation.natural (Postcompose k) f = reflˢ

  postcompose-identity : ∀ {ℓy} {Y : Type ℓy} (x : Obj) (h : Value x → Y)
    → outer (Transformation.component (Postcompose (idfun Y)) x h) ≡ˢ outer h
  postcompose-identity x h = reflˢ

  postcompose-compose : ∀ {ℓy ℓz ℓw} {Y : Type ℓy} {Z : Type ℓz} {W : Type ℓw}
    (f : Y → Z) (g : Z → W) (x : Obj) (h : Value x → Y)
    → outer (Transformation.component (Postcompose g) x
      (Transformation.component (Postcompose f) x h))
      ≡ˢ outer (Transformation.component (Postcompose (g ∘ f)) x h)
  postcompose-compose f g x h = reflˢ
