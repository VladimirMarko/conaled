{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispDiscrete where

-- A precise crisp instance of decidable equality for discrete sets.
-- The ambient R-flat axiom and crisp excluded middle are explicit inputs.
-- This does not assert the stronger rule for an arbitrary noncrisp family.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Relation.Nullary using (Discrete; Dec; yes; no)
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
import Orbifolds.CrispGeometry as CG

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (real-flat : CG.Context.RealFlatAxiom R)
    (excluded-middle : CrispExcludedMiddle {ℓ = ℓ}) where
  module G = CG.Context R

  module Set {@♭ X : Type ℓ} (@♭ setX : isSet X) where
    decide-counits : (x y : Flat X) → Dec (counit x ≡ counit y)
    decide-counits (box x) (box y) = excluded-middle ((x ≡ y) , setX x y)

    crisp-discrete→decidable-equality : CrisplyDiscrete X → Discrete X
    crisp-discrete→decidable-equality discrete x y with
      decide-counits (invEq (counit , discrete) x) (invEq (counit , discrete) y)
    ... | yes p = yes (sym (secEq (counit , discrete) x) ∙ p ∙ secEq (counit , discrete) y)
    ... | no p = no (λ path → p
      (secEq (counit , discrete) x ∙ path ∙ sym (secEq (counit , discrete) y)))

    shape-modal→decidable-equality : G.Infinitesimal.IsShapeModal X → Discrete X
    shape-modal→decidable-equality modalX = crisp-discrete→decidable-equality
      (invEq (real-flat X)
        (G.Infinitesimal.Shape.connected-constant
          G.Infinitesimal.real-shape-connected modalX))
