{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispCovariantYonedaEndpoints where

-- The covariant external Yoneda argument uses only its two endpoints.
-- No comparison for every crisp test object is required as an input.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Crisp

module Map {@♭ ℓ : Level} {@♭ A B : Type ℓ} (@♭ f : A → B) where
  postcompose : (@♭ Z : Type ℓ) → (Z → A) → (Z → B)
  postcompose Z g = f ∘ g

  proves-equivalence : isEquiv (flat-map (postcompose A))
    → isEquiv (flat-map (postcompose B)) → isEquiv f
  proves-equivalence externalA externalB =
    from-inverse (equivCtr mapsB (box (idfun B)))
    where
    mapsA : Flat (A → A) ≃ Flat (A → B)
    mapsA = flat-map (postcompose A) , externalA

    mapsB : Flat (B → A) ≃ Flat (B → B)
    mapsB = flat-map (postcompose B) , externalB

    injectiveA : (u v : Flat (A → A))
      → equivFun mapsA u ≡ equivFun mapsA v → u ≡ v
    injectiveA u v p = sym (retEq mapsA u)
      ∙ cong (invEq mapsA) p ∙ retEq mapsA v

    from-inverse : fiber (flat-map (postcompose B)) (box (idfun B))
      → isEquiv f
    from-inverse (box g , p) = isoToIsEquiv
      (iso f g (funExt⁻ (cong counit p))
        (funExt⁻ (cong counit left-law-flat)))
      where
      left-law-flat : box (g ∘ f) ≡ box (idfun A)
      left-law-flat = injectiveA (box (g ∘ f)) (box (idfun A))
        (cong (flat-map (_∘ f)) p)
