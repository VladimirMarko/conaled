{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CompactSubspaces where

-- Decidable subtypes of DP-compact types are compact.  This includes
-- removing a single point when equality is decidable.  The decidability
-- hypothesis is essential and does not assert compactness of arbitrary
-- closed subtypes (which would imply excluded middle: Warning 6.2.20).

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; isProp¬; Dec; yes; no; Discrete)
open import Cubical.HITs.PropositionalTruncation using (∣_∣₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Compactness using (_∨_; DPCompact)

private variable ℓ : Level

decidableSubtypeDPCompact : {K : Type ℓ} → DPCompact K →
  (U : K → hProp ℓ) → ((k : K) → Dec (U k .fst)) →
  DPCompact (Σ[ k ∈ K ] U k .fst)
decidableSubtypeDPCompact {ℓ = ℓ} {K = K} compactK U decideU A B cover =
  PT.map (Sum.map (λ a → a) (λ allK member → allK (member .fst) (member .snd)))
    (compactK A extended coverExtended)
  where
  extended : K → hProp ℓ
  extended k = ((u : U k .fst) → B (k , u) .fst) , isPropΠ (λ u → B (k , u) .snd)

  pointCover : (k : K) → Dec (U k .fst) → (A .fst) ∨ (extended k .fst)
  pointCover k (yes u) = PT.map
    (Sum.map (λ a → a) (λ belongs u' →
      subst (λ v → B (k , v) .fst) (U k .snd u u') belongs))
    (cover (k , u))
  pointCover k (no outside) = ∣ inr (λ u → Empty.rec (outside u)) ∣₁

  coverExtended : (k : K) → (A .fst) ∨ (extended k .fst)
  coverExtended k = pointCover k (decideU k)

WithoutPoint : {K : Type ℓ} → K → Type ℓ
WithoutPoint {K = K} x = Σ[ y ∈ K ] (¬ (x ≡ y))

negateDecision : {P : Type ℓ} → Dec P → Dec (¬ P)
negateDecision (yes p) = no (λ notP → notP p)
negateDecision (no notP) = yes notP

complementSingletonDPCompact : {K : Type ℓ} → DPCompact K → Discrete K →
  (x : K) → DPCompact (WithoutPoint x)
complementSingletonDPCompact compactK decide x =
  decidableSubtypeDPCompact compactK (λ y → (¬ (x ≡ y)) , isProp¬ _)
    (λ y → negateDecision (decide x y))

