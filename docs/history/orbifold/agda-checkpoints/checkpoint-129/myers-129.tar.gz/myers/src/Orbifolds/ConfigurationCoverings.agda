{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConfigurationCoverings where

-- The full covering statement of Myers 3.3.1. FiniteCoverings proves
-- shape-one etaleness of the literal finite-fiber maps, so this result
-- has no covering hypothesis hidden in the data it classifies.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base using (CommRing)
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.ConfigurationBundles as Config
import Orbifolds.FiniteCoverings as Finite
import Orbifolds.ShapeCoverings as Covers

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
  (@♭ rules : CrispIdentityInduction {ℓ})
  (@♭ upper-rules : CrispIdentityInduction {ℓ-suc ℓ}) where
  module F = Finite.Context R rules upper-rules
  open F using (RealFlat; UpperRealFlat)

  module Number {ℓX : Level} (n : ℕ) (X : Type ℓX) (A : Type ℓ)
    (real-flat : RealFlat) (upper-real-flat : UpperRealFlat) where

    module C = Config.Finite {ℓ = ℓ} n X
    module Pure = C.Over A
    module Cover = Covers.Ring.Base R A

    Total : Cover.Coverings → Type ℓ
    Total c = c .fst .fst .fst

    projection : (c : Cover.Coverings) → Total c → A
    projection c = c .fst .fst .snd

    NFoldCoveringsWithMap : Type (ℓ-max (ℓ-suc ℓ) ℓX)
    NFoldCoveringsWithMap = Σ[ c ∈ Cover.Coverings ]
      (((a : A) → C.FiniteFiber (fiber (projection c) a)) × (Total c → X))

    add-cover : Pure.FiniteBundlesWithMap → NFoldCoveringsWithMap
    add-cover (P , π , finite , f) =
      ((((P , π) , F.finite-fibers-etale real-flat upper-real-flat n π finite)
        , F.finite-fibers-sets n π finite) , finite , f)

    forget-cover : NFoldCoveringsWithMap → Pure.FiniteBundlesWithMap
    forget-cover (c , finite , f) = Total c , projection c , finite , f

    forget-add : (b : Pure.FiniteBundlesWithMap) → forget-cover (add-cover b) ≡ b
    forget-add _ = refl

    add-forget : (b : NFoldCoveringsWithMap) → add-cover (forget-cover b) ≡ b
    add-forget ((((P , π) , etale) , sets) , finite , f) i =
      ((((P , π) , isPropIsEquiv _
        (F.finite-fibers-etale real-flat upper-real-flat n π finite) etale i)
        , isPropΠ (λ _ → isPropIsSet) (F.finite-fibers-sets n π finite) sets i)
        , finite , f)

    finite-bundles≃nfold-coverings :
      Pure.FiniteBundlesWithMap ≃ NFoldCoveringsWithMap
    finite-bundles≃nfold-coverings = isoToEquiv
      (iso add-cover forget-cover add-forget forget-add)

    maps-to-configuration≃nfold-coverings :
      (A → C.Configuration) ≃ NFoldCoveringsWithMap
    maps-to-configuration≃nfold-coverings = compEquiv
      Pure.maps-to-configuration≃finite-bundles finite-bundles≃nfold-coverings
