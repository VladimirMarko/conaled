{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.CanonicalCoconeRepresentation where

-- Transfer an actual represented cell functor along a proved natural
-- equivalence. The resulting restriction is literally the target action
-- on the image of the constructed universal cell. Keeping this ordinary
-- argument separate avoids unfolding finite cubical implementation data
-- during the higher-dimensional bar induction.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv

module Transfer {ℓ : Level} (R : Type ℓ) (Cells Cones : Type ℓ → Type ℓ)
    (cell-action : {X Y : Type ℓ} → (X → Y) → Cells X → Cells Y)
    (cone-action : {X Y : Type ℓ} → (X → Y) → Cones X → Cones Y)
    (compare : (Y : Type ℓ) → Cells Y → Cones Y)
    (compare-isEquiv : (Y : Type ℓ) → isEquiv (compare Y))
    (compare-natural : {X Y : Type ℓ} (h : X → Y) (s : Cells X)
      → cone-action h (compare X s) ≡ compare Y (cell-action h s))
    (cell-universal : (Y : Type ℓ) → (R → Y) ≃ Cells Y)
    (cell-cocone : Cells R)
    (cell-natural : (Y : Type ℓ) (h : R → Y)
      → cell-action h cell-cocone ≡ cell-universal Y .fst h) where

  canonical-cocone : Cones R
  canonical-cocone = compare R cell-cocone

  restrict : (Y : Type ℓ) → (R → Y) → Cones Y
  restrict Y h = cone-action h canonical-cocone

  constructed-restriction : (Y : Type ℓ) → (R → Y) → Cones Y
  constructed-restriction Y h = compare Y (cell-universal Y .fst h)

  comparison : (Y : Type ℓ) (h : R → Y) → restrict Y h ≡ constructed-restriction Y h
  comparison Y h = compare-natural h cell-cocone ∙ cong (compare Y) (cell-natural Y h)

  abstract
    restriction-isEquiv : (Y : Type ℓ) → isEquiv (restrict Y)
    restriction-isEquiv Y = subst isEquiv (sym (funExt (comparison Y)))
      ((cell-universal Y ∙ₑ (compare Y , compare-isEquiv Y)) .snd)

  universal : (Y : Type ℓ) → (R → Y) ≃ Cones Y
  universal Y = restrict Y , restriction-isEquiv Y
