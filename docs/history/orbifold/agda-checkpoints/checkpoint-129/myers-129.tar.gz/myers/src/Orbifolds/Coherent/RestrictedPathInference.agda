{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.RestrictedPathInference where

-- Excluded elaboration contingency. The reflected candidate is the ordinary
-- composition of the two supplied paths. inferType checks a fully applied
-- ordinary helper, including its reflexivity argument, in the restricted
-- reduction scope. That argument assigns the existing goal metavariable.
-- There is no call to unify, no unchecked assignment, and no generated axiom.

import Agda.Builtin.Reflection as R
open import Agda.Builtin.Bool using (false)
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Sigma using (_,_)
open import Agda.Builtin.Unit using (⊤; tt)
open import Cubical.Foundations.Prelude using (Level; Type; _∙_)
open import Orbifolds.Coherent.StrictEnriched using (outer; _≡ˢ_; reflˢ)

demand-equality : ∀ {ℓ : Level} (A : Type ℓ) (x y : A)
  → outer x ≡ˢ outer y → ⊤
demand-equality A x .x reflˢ = tt

visible-argument : R.Term → R.Arg R.Term
visible-argument t =
  R.arg (R.arg-info R.visible (R.modality R.relevant R.quantity-ω)) t

hidden-argument : R.Term → R.Arg R.Term
hidden-argument t =
  R.arg (R.arg-info R.hidden (R.modality R.relevant R.quantity-ω)) t

-- _∙_ has the hidden parameters ℓ, A, x, y, z, followed by its two paths.
-- All five unknowns must be solved by ordinary argument checking.
composition-term : R.Term → R.Term → R.Term
composition-term p q = R.def (quote _∙_)
  (hidden-argument R.unknown ∷ hidden-argument R.unknown ∷
   hidden-argument R.unknown ∷ hidden-argument R.unknown ∷
   hidden-argument R.unknown ∷ visible-argument p ∷ visible-argument q ∷ [])

demand-term : R.Term → R.Term → R.Term → R.Term
demand-term goal hole candidate = R.def (quote demand-equality)
  (hidden-argument R.unknown ∷ visible-argument goal ∷
   visible-argument hole ∷ visible-argument candidate ∷
   visible-argument (R.con (quote reflˢ) []) ∷ [])

check-frozen : List R.Name → R.Term → R.TC ⊤
check-frozen names candidate =
  R.withNormalisation false
    (R.withReconstructed false
      (R.withReduceDefs (false , names)
        (R.noConstraints
          (R.bindTC (R.inferType candidate) (λ _ → R.returnTC tt)))))

assign-frozen : List R.Name → R.Term → R.Term → R.TC ⊤
assign-frozen names candidate hole =
  R.withNormalisation false
    (R.withReconstructed false
      (R.withReduceDefs (false , names)
        (R.noConstraints
          (R.bindTC (R.inferType hole) (λ goal →
            R.bindTC (R.inferType (demand-term goal hole candidate))
              (λ _ → R.returnTC tt))))))

macro
  inference-frozen-compose : R.Name → R.Name
    → R.Term → R.Term → R.Term → R.TC ⊤
  inference-frozen-compose first-name second-name p q hole =
    assign-frozen (first-name ∷ second-name ∷ [])
      (composition-term p q) hole
