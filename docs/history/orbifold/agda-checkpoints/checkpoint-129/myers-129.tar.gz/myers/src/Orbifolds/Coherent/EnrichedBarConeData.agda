{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarConeData where

-- Actual finite bar-cone data for a strict Type-enriched diagram. A
-- layer records cubes on every composable chain. Its two face formulae
-- are deletion of a vertex and action by the remaining suffix.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; Faces; OTop; star)
import Orbifolds.Coherent.OuterBarCuts as Cuts

record LawPair {ℓ} (A B : SSet ℓ) : SSet ℓ where
  constructor law-pair
  field earlier : A
        current : B

module Data {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ) where
  open Category C
  open Diagram D
  open Chains C

  Top : Dim → Type ℓ → Type ℓ
  Top n P = (s : P) (y : Obj) → Chain n y → Cube n (Value y)

  Families : Dim → Type ℓ → Type ℓ
  Families ozero P = Top ozero P
  Families (osuc n) P = Families n P × Top (osuc n) P

  top : (n : Dim) {P : Type ℓ} → Families n P → Top n P
  top ozero F = F
  top (osuc n) F = F .snd

  one-face : (n : Dim) {P : Type ℓ} (F : Families n P) (s : P)
    (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y) → Cube n (Value y)
  one-face n F s pzero c = map-cube n (action (last-arrow n c))
    (top n F s (last-source n c) (prefix n c))
  one-face (osuc n) F s (psuc p) c i = map-cube n (action (last-arrow (osuc n) c))
    (one-face n (F .fst) s p (prefix (osuc n) c))

  bar-faces : (n : Dim) {P : Type ℓ} (F : Families n P) (s : P)
    {y : Obj} (c : Chain (osuc n) y) → Faces (osuc n) (Value y)
  bar-faces n F s {y} c p low = top n F s y (face n p c)
  bar-faces n F s c p high = one-face n F s p c

  record LayerLaws (n : Dim) {P : Type ℓ}
      (F : Families n P) (next : Top (osuc n) P) : SSet ℓ where
    field
      zero-face : (s : P) (y : Obj) (c : Chain (osuc n) y) (p : Position (osuc n))
        → outer (coordinate-face n p i0 (next s y c))
          ≡ˢ outer (top n F s y (face n p c))
      one-face-law : (s : P) (y : Obj) (c : Chain (osuc n) y) (p : Position (osuc n))
        → outer (coordinate-face n p i1 (next s y c))
          ≡ˢ outer (one-face n F s p c)

  Coherent : (n : Dim) {P : Type ℓ} → Families n P → SSet ℓ
  Coherent ozero F = OTop ℓ
  Coherent (osuc n) F = LawPair (Coherent n (F .fst)) (LayerLaws n (F .fst) (F .snd))

  reindex : (n : Dim) {P Q : Type ℓ} → Families n P → (Q → P) → Families n Q
  reindex ozero F f s = F (f s)
  reindex (osuc n) F f = reindex n (F .fst) f , (λ s → F .snd (f s))

  top-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P) (f : Q → P)
    (s : Q) (y : Obj) (c : Chain n y)
    → outer (top n (reindex n F f) s y c) ≡ˢ outer (top n F (f s) y c)
  top-reindex ozero F f s y c = reflˢ
  top-reindex (osuc n) F f s y c = reflˢ

  module Coherence (E : StrictCubicalExtensionality ℓ) where
    open StrictCubicalExtensionality E
    open Cubes.Extensional E
    open Cuts.Cuts C

    action-compose-cube : (n : Dim) {x y z : Obj} (g : Hom y z) (f : Hom x y)
      (c : Cube n (Value x))
      → outer (map-cube n (action (compose g f)) c)
        ≡ˢ outer (map-cube n (action g) (map-cube n (action f) c))
    action-compose-cube n g f c = strict-trans
      (strict-cong (λ a → outer (map-cube n (inner a) c)) (action-compose g f))
      (strict-sym (map-compose n (action g) (action f) c))

    one-extend : (n : Dim) {P : Type ℓ} (F : Families n P) (s : P)
      (p : Position (osuc n)) {x y : Obj} (g : Hom x y) (c : Chain (osuc n) x)
      → outer (one-face n F s p (extend-suffix n g c))
        ≡ˢ outer (map-cube n (action g) (one-face n F s p c))
    one-extend n F s pzero g c = action-compose-cube n g (last-arrow n c)
      (top n F s (last-source n c) (prefix n c))
    one-extend (osuc n) F s (psuc p) g c = interval-ext λ i →
      action-compose-cube n g (last-arrow (osuc n) c)
        (one-face n (F .fst) s p (prefix (osuc n) c))

    one-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P) (f : Q → P)
      (s : Q) (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
      → outer (one-face n (reindex n F f) s p c) ≡ˢ outer (one-face n F (f s) p c)
    one-reindex n F f s pzero c = strict-cong
      (λ k → outer (map-cube n (action (last-arrow n c)) (inner k)))
      (top-reindex n F f s (last-source n c) (prefix n c))
    one-reindex (osuc n) F f s (psuc p) c = interval-ext λ i →
      strict-cong (λ k → outer (map-cube n (action (last-arrow (osuc n) c)) (inner k)))
        (one-reindex n (F .fst) f s p (prefix (osuc n) c))

    coherent-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P)
      → Coherent n F → (f : Q → P) → Coherent n (reindex n F f)
    coherent-reindex ozero F coherent f = star
    LawPair.earlier (coherent-reindex (osuc n) F coherent f) =
      coherent-reindex n (F .fst) (LawPair.earlier coherent) f
    LayerLaws.zero-face (LawPair.current (coherent-reindex (osuc n) F coherent f)) s y c p =
      strict-trans (LayerLaws.zero-face (LawPair.current coherent) (f s) y c p)
        (strict-sym (top-reindex n (F .fst) f s y (face n p c)))
    LayerLaws.one-face-law (LawPair.current (coherent-reindex (osuc n) F coherent f)) s y c p =
      strict-trans (LayerLaws.one-face-law (LawPair.current coherent) (f s) y c p)
        (strict-sym (one-reindex n (F .fst) f s p c))
