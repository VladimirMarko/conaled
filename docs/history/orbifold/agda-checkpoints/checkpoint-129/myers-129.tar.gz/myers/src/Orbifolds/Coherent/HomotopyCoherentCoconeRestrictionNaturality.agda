{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionNaturality where

-- Finite cocone restriction commutes with actual target postcomposition.
-- Equality of full typed stages is derived from the raw cube formulas.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.HomotopyCoherentActionData using (LawPair)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Maps
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentMappingContravariance as Coefficients
import Orbifolds.Coherent.HomotopyCoherentFiniteTransformations as FiniteMaps
import Orbifolds.Coherent.HomotopyCoherentFiniteExtensionality as Extensionality
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction

module Naturality {ℓ : Level} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
    (α : Maps.ForCategory.Transformation C D G) (E : StrictCubicalExtensionality ℓ)
    (F : StrictFunctionExtensionality ℓ) where
  open Category C
  open Chains (Opposite C)
  open StrictFunctionExtensionality F
  module H = HC.ForCategory C
  module D = H.Diagram D
  module G = H.Diagram G
  module Transformations = Maps.ForCategory C
  module α = Transformations.Transformation α
  module DM = Mapping.Mapping C D E F
  module GM = Mapping.Mapping C G E F
  module Coeff = Coefficients.Contravariance C D G α E F
  module CD = Cocones.Functoriality C D E F
  module CG = Cocones.Functoriality C G E F
  module R (Y : Type ℓ) = Restriction.Restriction C D G α E F Y

  top-square : (n : Dim) {Y Z : Type ℓ} (k : Y → Z) (s : CG.Cocone Y n)
    (y : Obj) (c : Chain n y)
    → outer (CD.top Z n (CD.postcompose n k (R.finite-restriction Y n s)) y c)
      ≡ˢ outer (CD.top Z n (R.finite-restriction Z n (CG.postcompose n k s)) y c)
  top-square n {Y} {Z} k s y c = strict-trans
    (strict-sym (FiniteMaps.Action.stage-top-natural
      (DM.Into Y) (DM.Into Z) (DM.Postcompose k) E n (R.finite-restriction Y n s) y c))
    (strict-trans
      (strict-cong (λ q → outer (map-cube n (λ h → k ∘ h) (inner q)))
        (strict-sym (FiniteMaps.Action.stage-top-natural
          (GM.Into Y) (DM.Into Y) (Coeff.Precompose Y) E n s y c)))
      (strict-trans
        (Cubes.Extensional.map-compose E n (λ h → k ∘ h) (λ h → h ∘ α.component y) (CG.top Y n s y c))
        (strict-trans
          (strict-sym (Cubes.Extensional.map-compose E n (λ h → h ∘ α.component y) (λ h → k ∘ h) (CG.top Y n s y c)))
          (strict-trans
            (strict-cong (λ q → outer (map-cube n (λ h → h ∘ α.component y) (inner q)))
              (FiniteMaps.Action.stage-top-natural
                (GM.Into Y) (GM.Into Z) (GM.Postcompose k) E n s y c))
            (FiniteMaps.Action.stage-top-natural
              (GM.Into Z) (DM.Into Z) (Coeff.Precompose Z) E n (CG.postcompose n k s) y c)))))

  agreement : (n : Dim) {Y Z : Type ℓ} (k : Y → Z) (s : CG.Cocone Y n)
    → Extensionality.Extensionality.Agreement (Opposite C) (DM.Into Z) E F n
      (CD.postcompose n k (R.finite-restriction Y n s))
      (R.finite-restriction Z n (CG.postcompose n k s))
  agreement ozero k s = top-square ozero k s
  LawPair.earlier (agreement (osuc n) k s) = agreement n k (s .fst)
  LawPair.current (agreement (osuc n) k s) = top-square (osuc n) k s

  square : (n : Dim) {Y Z : Type ℓ} (k : Y → Z) (s : CG.Cocone Y n)
    → outer (CD.postcompose n k (R.finite-restriction Y n s))
      ≡ˢ outer (R.finite-restriction Z n (CG.postcompose n k s))
  square n {Z = Z} k s = Extensionality.Extensionality.stage-extensionality
    (Opposite C) (DM.Into Z) E F n _ _ (agreement n k s)

  function-square : (n : Dim) {Y Z : Type ℓ} (k : Y → Z)
    → outer (CD.postcompose n k ∘ R.finite-restriction Y n)
      ≡ˢ outer (R.finite-restriction Z n ∘ CG.postcompose n k)
  function-square n k = function-ext (square n k)
