{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CountableRealProbe where

-- Constructs the analytic CountableProbe used in Theorem 6.2.13 from a
-- Kock field, the literal StrictOrder/Archimedean data, and the explicit
-- additional OrderedRingCompatibility bridge in SyntheticOrder.
-- Threshold i is (i+1)*t < 1, avoiding an undefined reciprocal at i=0.
-- A point t=epsilon/2 in each zero-ball has only finitely many thresholds:
-- an Archimedean bound on 1/t supplies a bound on i.  No choice is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ; suc)
import Cubical.Data.Nat.Order as NatOrder
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.Penon using (PenonOpen; inverseImagePenonOpen)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.CountableCovers
  using (CountableProbe; SubcountableIndex; Covers; BoundedSubcover;
         subcountableCoverBound)

module RealProbe {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open Field kock
  open OrderedRingCompatibility compatibility

  PositiveRadius : Type ℓ
  PositiveRadius = Σ[ ε ∈ Carrier ] 0r < ε

  intervalBalls : BallStructure ℓ
  BallStructure.Carrier intervalBalls = Carrier
  BallStructure.PositiveRadius intervalBalls = PositiveRadius
  BallStructure.ball intervalBalls x ε y =
    (((x - ε .fst) < y) × (y < (x + ε .fst))) ,
    isProp× (less-isProp (x - ε .fst) y) (less-isProp y (x + ε .fst))
  BallStructure.centerInBall intervalBalls x ε =
    positiveDifference→less
      (subst (0r <_) (sym leftDifference) (ε .snd)) ,
    positiveDifference→less
      (subst (0r <_) (sym rightDifference) (ε .snd))
    where
    leftDifference : x - (x - ε .fst) ≡ ε .fst
    leftDifference = solve! R
    rightDifference : (x + ε .fst) - x ≡ ε .fst
    rightDifference = solve! R

  Threshold : ℕ → Carrier → hProp ℓ
  Threshold i t = ((nat (suc i) · t) < 1r) , less-isProp (nat (suc i) · t) 1r

  thresholdPenonOpen : (i : ℕ) → PenonOpen (Threshold i)
  thresholdPenonOpen i = inverseImagePenonOpen
    (λ t → nat (suc i) · t) (UpperRay 1r) (upperRayPenonOpen 1r)

  thresholdAtZero : (i : ℕ) → Threshold i 0r .fst
  thresholdAtZero i = subst (_< 1r) (sym (0RightAnnihilates (nat (suc i)))) zero<one

  subtractNegativeZero : (a b : Carrier) → a - (0r - b) ≡ a + b
  subtractNegativeZero a b = solve! R

  halfRadiusInBall : (ε : PositiveRadius) →
    BallStructure.ball intervalBalls 0r ε (half · ε .fst) .fst
  halfRadiusInBall ε =
    positiveDifference→less
      (subst (0r <_) (sym difference)
        (positive-add (halfScalePositive (ε .snd)) (ε .snd))) ,
    subst ((half · ε .fst) <_) (sym (+IdL (ε .fst))) (halfScaleLess (ε .snd))
    where
    difference : (half · ε .fst) - (0r - ε .fst) ≡ (half · ε .fst) + ε .fst
    difference = subtractNegativeZero (half · ε .fst) (ε .fst)

  -- A single positive test point and an Archimedean bound determine a
  -- natural-number cutoff.  Decidability used here is solely that of ℕ.
  realCountableProbe : CountableProbe intervalBalls
  CountableProbe.origin realCountableProbe = 0r
  CountableProbe.threshold realCountableProbe = Threshold
  CountableProbe.thresholdOpen realCountableProbe = thresholdPenonOpen
  CountableProbe.thresholdAtOrigin realCountableProbe = thresholdAtZero
  CountableProbe.probe realCountableProbe ε = PT.map finish
    (archimedean (reciprocal .fst))
    where
    t : Carrier
    t = half · ε .fst

    tPositive : 0r < t
    tPositive = halfScalePositive (ε .snd)

    reciprocal : Σ[ u ∈ Carrier ] ((0r < u) × (t · u ≡ 1r))
    reciprocal = positiveInverse t tPositive

    cutoff : (n : ℕ) → reciprocal .fst < nat n →
      (i : ℕ) → Threshold i t .fst → i NatOrder.< n
    cutoff n inverseBelow i threshold = Sum.rec (λ below → below)
      (λ above → Empty.rec (lessAsym threshold (tooLarge above)))
      (NatOrder.splitℕ-< i n)
      where
      tooLarge : n NatOrder.≤ i → 1r < (nat (suc i) · t)
      tooLarge above = subst (_< (nat (suc i) · t))
        (·Comm (reciprocal .fst) t ∙ reciprocal .snd .snd)
        (multiplyLessRightPositive tPositive
          (lessTrans inverseBelow (nat≤→strictNext above)))

    finish : (Σ[ n ∈ ℕ ] reciprocal .fst < nat n) →
      Σ[ x ∈ Carrier ]
        (BallStructure.ball intervalBalls 0r ε x .fst ×
          (Σ[ n ∈ ℕ ] ((i : ℕ) → Threshold i x .fst → i NatOrder.< n)))
    finish (n , inverseBelow) = t , halfRadiusInBall ε , n , cutoff n inverseBelow

  -- Theorem 6.2.13 with the analytic probe discharged.  The hypotheses
  -- that remain are K, O, the explicitly recorded order compatibility,
  -- and the interval-ball form of Postulate E, plus DP compactness.
  orderedRealSubcountableCoverBound : CoveringProperty intervalBalls →
    {K : Type ℓ} → DPCompact K →
    (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
    ((i : SubcountableIndex J) → PenonOpen (U i)) → Covers U → BoundedSubcover J U
  orderedRealSubcountableCoverBound covering =
    subcountableCoverBound intervalBalls covering realCountableProbe

