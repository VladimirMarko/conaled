{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrispShapeDeloopings where

-- The connected crisp-base bridge needed by Theorem 3.2.8.  The actual
-- separated reflection is nullification at Susp R.  Its R-null paths
-- and connectedness make it R-null by the checked Flat-counit argument.
-- Cross-universe nullification recursion then descends small modal
-- families without a universe-resizing or upper-universe R-flat axiom.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv.Fiberwise using (recognizeId)
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Foundations.Pointed.Base using (_≃∙_)
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base using (CommRing; CommRingStr)
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Cubical.HITs.Nullification.Topological as NT
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispPropositions as CP
import Orbifolds.CrispConnectedModal as CC
import Orbifolds.SuspensionNullity as SN
import Orbifolds.Crystalline as CR
import Orbifolds.Quotients as Q

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CommRingStr (R .snd) using (0r)
  open CR.Ring R using (Carrier; ShapeGenerator; shape; IsShapeModal; module Shape)
  module Propositions = CP.Context Carrier 0r
  module Suspension = SN.Nullity Carrier
  module Connected = CC.Ring R rules
  open Propositions using (RealFlat) public

  shape-modal-proposition : {P : Type ℓ} → isProp P → IsShapeModal P
  shape-modal-proposition prop _ = fromIsEquiv const
    (isoToIsEquiv (iso const (λ f → f 0r)
      (λ f → funExt λ t → prop (f 0r) (f t)) (λ _ → refl)))

  ModalTypes : Type (ℓ-suc ℓ)
  ModalTypes = Σ[ X ∈ Type ℓ ] IsShapeModal X

  modal-universe-separated : (X Y : ModalTypes)
    → NB.isNull ShapeGenerator (X ≡ Y)
  modal-universe-separated = NT.NullType≡isNull ShapeGenerator {ℓ = ℓ}

  modal-universe-suspension-null : NB.isNull Suspension.SuspendedGenerator ModalTypes
  modal-universe-suspension-null =
    Suspension.paths-null→suspension-null modal-universe-separated

  module Pointed (@♭ X : Type ℓ) (@♭ x₀ : X) where
    module Separate = Suspension.Reflection X

    shape-suspension-null : NB.isNull Suspension.SuspendedGenerator (shape X)
    shape-suspension-null = Suspension.paths-null→suspension-null
      (λ _ _ → NP.isNull≡ (NB.isNull-Null ShapeGenerator))

    module Proof (real-flat : RealFlat)
        (connected : (x : X) → PT.∥ x₀ ≡ x ∥₁) where
      separated-reflection-modal : IsShapeModal Separate.SeparatedReflection
      separated-reflection-modal = Connected.shape-separated-connected→shape-modal
        real-flat (Separate.unit x₀) (Separate.connected x₀ connected) Separate.paths-null

      to-separated : shape X → Separate.SeparatedReflection
      to-separated = NP.rec separated-reflection-modal Separate.unit

      from-separated : Separate.SeparatedReflection → shape X
      from-separated = NP.rec shape-suspension-null Shape.η

      from-to : (z : shape X) → from-separated (to-separated z) ≡ z
      from-to = NP.elim (λ _ → NP.isNull≡ (NB.isNull-Null ShapeGenerator)) (λ _ → refl)

      to-from : (z : Separate.SeparatedReflection) → to-separated (from-separated z) ≡ z
      to-from = NP.elim
        (λ _ → NP.isNull≡ (NB.isNull-Null Suspension.SuspendedGenerator)) (λ _ → refl)

      separated≃shape : Separate.SeparatedReflection ≃ shape X
      separated≃shape = isoToEquiv (iso from-separated to-separated from-to to-from)

      separation-unit-triangle : (x : X) → from-separated (Separate.unit x) ≡ Shape.η x
      separation-unit-triangle _ = refl

      restriction : (shape X → ModalTypes) → (X → ModalTypes)
      restriction f = f ∘ Shape.η

      restriction-equivalence : (shape X → ModalTypes) ≃ (X → ModalTypes)
      restriction-equivalence = compEquiv (preCompEquiv separated≃shape)
        (NP.NullRecEquiv modal-universe-suspension-null)

      module Family (A : X → Type ℓ) where
        reflected-family : X → ModalTypes
        reflected-family x = shape (A x) , NB.isNull-Null ShapeGenerator

        separated-family : Separate.SeparatedReflection → ModalTypes
        separated-family = NP.rec modal-universe-suspension-null reflected-family

        descended-family : shape X → ModalTypes
        descended-family = separated-family ∘ to-separated

        Descended : shape X → Type ℓ
        Descended z = descended-family z .fst

        descended-modal : (z : shape X) → IsShapeModal (Descended z)
        descended-modal z = descended-family z .snd

        family-unit : (x : X) → Descended (Shape.η x) ≡ shape (A x)
        family-unit _ = refl

        extension-witness : fiber restriction reflected-family
        extension-witness = descended-family , refl

        extension-unique : isContr (fiber restriction reflected-family)
        extension-unique = equiv-proof (restriction-equivalence .snd) reflected-family

      reflected-connected : (z : shape X) → PT.∥ Shape.η x₀ ≡ z ∥₁
      reflected-connected = Shape.◯-elim (λ _ → shape-modal-proposition PT.squash₁)
        (λ x → PT.map (cong Shape.η) (connected x))

      reflected-delooping : Q.Delooping ℓ
      Q.Delooping.BG reflected-delooping = shape X
      Q.Delooping.point reflected-delooping = Shape.η x₀
      Q.Delooping.connected reflected-delooping = reflected-connected

      -- Descend the actual reflected path family. Its total space is
      -- contractible, so it recognizes the identities of the reflected
      -- base. This also identifies the reflected loop group canonically.
      module Paths = Family (λ x → x₀ ≡ x)

      Code : shape X → Type ℓ
      Code = Paths.Descended

      TotalCode : Type ℓ
      TotalCode = Σ (shape X) Code

      total-code-modal : IsShapeModal TotalCode
      total-code-modal = Shape.Σ-isModal Code Shape.◯-isModal Paths.descended-modal

      code-center : TotalCode
      code-center = Shape.η x₀ , Shape.η refl

      code-contracts-unit : (x : X) (p : shape (x₀ ≡ x))
        → code-center ≡ (Shape.η x , p)
      code-contracts-unit x = Shape.◯-elim
        (λ _ → Shape.isModal≡ total-code-modal)
        (J (λ x p → code-center ≡ (Shape.η x , Shape.η p)) refl)

      total-code-contractible : isContr TotalCode
      total-code-contractible .fst = code-center
      total-code-contractible .snd (z , p) = Shape.◯-elim
        {B = λ z → (p : Code z) → code-center ≡ (z , p)}
        (λ z → Shape.Π-isModal {A = Code z}
          (λ p → Shape.isModal≡ total-code-modal {x = code-center} {y = z , p}))
        code-contracts-unit z p

      identity≃code : (z : shape X) → (Shape.η x₀ ≡ z) ≃ Code z
      identity≃code = recognizeId Code (Shape.η refl) total-code-contractible

      encode-unit : {x : X} (p : x₀ ≡ x)
        → equivFun (identity≃code (Shape.η x)) (cong Shape.η p) ≡ Shape.η p
      encode-unit = J
        (λ x p → equivFun (identity≃code (Shape.η x)) (cong Shape.η p) ≡ Shape.η p)
        (JRefl {x = Shape.η x₀} (λ z _ → Code z) (Shape.η refl))

      reflected-loops≃loops : shape (x₀ ≡ x₀) ≃ Q.Loop reflected-delooping
      reflected-loops≃loops = invEquiv (identity≃code (Shape.η x₀))

      reflected-loop-unit : (p : x₀ ≡ x₀)
        → equivFun reflected-loops≃loops (Shape.η p) ≡ cong Shape.η p
      reflected-loop-unit p =
        cong (invEq (identity≃code (Shape.η x₀))) (sym (encode-unit p))
        ∙ retEq (identity≃code (Shape.η x₀)) (cong Shape.η p)

      pointed-loop-equivalence : (shape (x₀ ≡ x₀) , Shape.η refl)
        ≃∙ (Q.Loop reflected-delooping , refl)
      pointed-loop-equivalence = reflected-loops≃loops , reflected-loop-unit refl

  module Group (@♭ G : Q.Delooping ℓ) (real-flat : RealFlat) =
    Pointed.Proof (Q.Delooping.BG G) (Q.Delooping.point G) real-flat (Q.Delooping.connected G)
