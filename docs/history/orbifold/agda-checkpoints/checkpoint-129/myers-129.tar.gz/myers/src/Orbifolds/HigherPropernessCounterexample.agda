{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.HigherPropernessCounterexample where

-- The unrestricted higher-codomain reading of Proposition 6.2.4 is
-- false. The point map into the actual delooping of the additive real
-- group is subtype-proper, but its fiber is the noncompact real line.
-- The set-codomain theorem in ProperMaps remains valid and unchanged.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Unit
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Base using (Ring→Group)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Compactness
open import Orbifolds.ProperMaps
import Orbifolds.Torsors as T
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.SyntheticBounds as SB
import Orbifolds.CountableRealProbe as CR
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)

-- Restrict a compactness test universe by explicit lifting. This is not
-- a resizing axiom: only lower-universe test propositions are used.
lower-compact-tests : {ℓ ℓX : Level} {X : Type ℓX}
  → DPCompactAt (ℓ-suc ℓ) X → DPCompactAt ℓ X
lower-compact-tests {ℓ} compact A B h = PT.map
  (Sum.rec (λ a → inl (lower a)) (λ b → inr (λ x → lower (b x))))
  (compact (Lift {j = ℓ-suc ℓ} (A .fst) , (λ a b i → lift (A .snd (lower a) (lower b) i)))
    (λ x → Lift {j = ℓ-suc ℓ} (B x .fst) , (λ a b i → lift (B x .snd (lower a) (lower b) i)))
    (λ x → PT.map (Sum.rec (λ a → inl (lift a)) (λ b → inr (lift b))) (h x)))

module Ring {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
    (covering : CoveringProperty (CR.RealProbe.intervalBalls R kock order compatibility)) where
  open SF.RingContext.StrictOrder order using (irreflexive)
  module Bounds = SB.Bounds R kock order compatibility
  module Torsors = T.Theory (Ring→Group (CommRing→Ring R))

  real-line-not-compact : DPCompact (R .fst) → Empty.⊥
  real-line-not-compact compact = PT.rec Empty.isProp⊥
    (λ { (B , bounded) → irreflexive (B .fst) (bounded (B .fst) .snd) })
    (Bounds.boundedRealFunction covering compact (idfun _))

  Base : Type (ℓ-suc ℓ)
  Base = Torsors.Torsor

  point : Base
  point = Torsors.regular-torsor

  point-map : Unit* {ℓ = ℓ-suc ℓ} → Base
  point-map _ = point

  point-map-proper : DPProper point-map
  point-map-proper = pointMapProper point (λ y → PT.map sym (Torsors.torsor-connected y))

  point-fiber-not-compact : DPCompact (fiber point-map point) → Empty.⊥
  point-fiber-not-compact compact = real-line-not-compact (lower-compact-tests
    (equivDPCompact Torsors.torsor-loops
      (surjectiveImageDPCompact compact snd (λ p → PT.∣ (tt* , p) , refl ∣₁))))

  point-map-not-compact-fibers : CompactFibers point-map → Empty.⊥
  point-map-not-compact-fibers compact = point-fiber-not-compact (compact point)

  unrestricted-fiber-converse-is-false : UnrestrictedFiberConverse (ℓ-suc ℓ) → Empty.⊥
  unrestricted-fiber-converse-is-false converse =
    point-map-not-compact-fibers (converse point-map point-map-proper)

  -- The pullback of this same proper point map along itself is not proper.
  -- Its base is the unit type; testing its entire codomain would compactify
  -- its real-valued fiber. Thus unrestricted pullback stability also fails.
  self-pullback-not-proper : DPProper (pullbackProjection {f = point-map} {g = point-map}) → Empty.⊥
  self-pullback-not-proper proper = point-fiber-not-compact
    (surjectiveImageDPCompact
      (proper (λ _ → Unit* , isPropUnit*)
        (productDPCompact (contractibleDPCompact isContrUnit*) (contractibleDPCompact isContrUnit*)))
      (λ z → z .fst .snd)
      (λ p → PT.∣ ((tt* , p) , tt*) , refl ∣₁))
