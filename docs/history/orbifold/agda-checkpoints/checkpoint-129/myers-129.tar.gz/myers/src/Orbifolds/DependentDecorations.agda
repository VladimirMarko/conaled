{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DependentDecorations where

-- Expected-type-neutral constructors. Concrete algebraic certificates
-- are supplied only after the dependent pair is checked generically.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma

pair : {ℓa ℓp : Level} (A : Type ℓa) (P : A → Type ℓp)
  → (x : A) → P x → Σ A P
pair A P x p = x , p

decorate : {ℓa ℓp ℓq : Level} (A : Type ℓa) (P : A → Type ℓp) (Q : A → Type ℓq)
  → (x : A) → P x → Q x → Σ[ y ∈ A ] P y × Q y
decorate A P Q x p q = x , p , q

combine : {ℓa ℓp ℓq : Level} (A : Type ℓa) (P : A → Type ℓp) (Q : A → Type ℓq)
  → (p : Σ A P) (q : Σ A Q) → p .fst ≡ q .fst
  → Σ[ x ∈ A ] P x × Q x
combine A P Q p q equal = p .fst , p .snd , subst Q (sym equal) (q .snd)

combine-first : {ℓa ℓp ℓq : Level} (A : Type ℓa) (P : A → Type ℓp) (Q : A → Type ℓq)
  (p : Σ A P) (q : Σ A Q) (equal : p .fst ≡ q .fst)
  → combine A P Q p q equal .fst ≡ p .fst
combine-first A P Q p q equal = refl
