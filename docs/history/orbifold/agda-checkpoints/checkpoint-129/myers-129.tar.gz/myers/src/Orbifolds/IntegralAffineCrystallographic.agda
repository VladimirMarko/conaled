{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineCrystallographic where

-- Geometric realization of the actual integral affine semidirect group.
-- The concrete proof uses qualified declarations rather than repeatedly
-- instantiating the large matrix/quotient module namespaces. Its result
-- is an actual embedded isometry group with open isolation and a compact
-- fundamental cover; no internal DPProper assertion is made.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.FinSet using (isFinSet)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Functions.Embedding using (isEmbedding)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.ProperFiniteness using (ProperlyFinite)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.CompactIntervals as CI
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.ModuleInnerProducts as MI
import Orbifolds.GeneralLinearMatrices as GL
import Orbifolds.IntegralAffineActions as IA
import Orbifolds.IntegralAffineInnerProducts as IP
import Orbifolds.IntegralAffineFaithfulness as Faithfulness
import Orbifolds.IntegralAffineSeparation as Separation
import Orbifolds.IntegralAffineTransporters as Transporters
import Orbifolds.IntegralAffineCocompactness as Cocompactness
import Orbifolds.CrystallographicActions as GeometricActions

module Geometry {ℓ : Level} (R : CommRing ℓ)
  (kock : SF.RingContext.KockField R)
  (order : SF.RingContext.StrictOrder R)
  (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
  (n : ℕ) where
  open CommRingStr (R .snd)

  Vector : Type ℓ
  Vector = FD.Fin n → R .fst

  InnerProduct : Type ℓ
  InnerProduct = MI.Theory.InnerProduct R order (LM.Ring.Free R n)

  squared-distance : InnerProduct → Vector → Vector → R .fst
  squared-distance = IP.Geometry.Dimension.squared-distance R kock order compatibility n

  UnitIntervalCompact : Type (ℓ-suc ℓ)
  UnitIntervalCompact = CI.Interpolation.UnitIntervalCompact R kock order compatibility

  module Subgroup (H : Group ℓ)
    (ρ : GroupHom H (GL.Ring.Dimension.GeneralLinear ℤCommRing n))
    (embedding : isEmbedding (ρ .fst)) where

    AffineGroup : Group ℓ
    AffineGroup = IA.Coordinates.Representation.AffineGroup R n H ρ

    affine : AffineGroup .fst → Vector → Vector
    affine = IA.Coordinates.Representation.affine R n H ρ

    affine-unit : (x : Vector) → affine (GroupStr.1g (AffineGroup .snd)) x ≡ x
    affine-unit = IA.Coordinates.Representation.Combined.combined-unit R n H ρ

    affine-compose : (g h : AffineGroup .fst) (x : Vector)
      → affine (GroupStr._·_ (AffineGroup .snd) g h) x ≡ affine g (affine h x)
    affine-compose = IA.Coordinates.Representation.Combined.combined-compose R n H ρ

    module Geometric = GeometricActions.Action AffineGroup Vector (isSetΠ λ _ → is-set)
      affine affine-unit affine-compose

    Isometric : InnerProduct → Type ℓ
    Isometric = IP.Geometry.Dimension.Representation.Isometric R kock order compatibility n H ρ

    abstract
      faithful : isEmbedding affine
      faithful = Faithfulness.Coordinates.Subgroup.affine-action-embedding R order n H ρ embedding

      open-isolation : Geometric.OpenIsolation
      open-isolation g =
        Separation.Geometry.Subgroup.FrameNeighborhood R kock order compatibility n H ρ embedding g ,
        Separation.Geometry.Subgroup.frame-neighborhood-open R kock order compatibility n H ρ embedding g ,
        Separation.Geometry.Subgroup.frame-neighborhood-contains R kock order compatibility n H ρ embedding g ,
        Separation.Geometry.Subgroup.frame-neighborhood-isolates R kock order compatibility n H ρ embedding g

      compact-fundamental-cover : UnitIntervalCompact → Geometric.CompactFundamentalCover
      compact-fundamental-cover compact =
        Cocompactness.Geometry.FundamentalRegion R kock order compatibility n ,
        Cocompactness.Geometry.region-inclusion R kock order compatibility n ,
        Cocompactness.Geometry.fundamental-region-compact R kock order compatibility n compact ,
        Cocompactness.Geometry.Representation.compact-region-translates-cover R kock order compatibility n H ρ

    properly-finite-transporters : isFinSet (H .fst) → (x y : Vector)
      → ProperlyFinite (Transporters.Coordinates.Representation.Transporter R order n H ρ x y)
    properly-finite-transporters =
      Transporters.Coordinates.Representation.transporters-properly-finite R order n H ρ

    module WithMetric (form : InnerProduct) (isometric : Isometric form) where
      module MetricAction = Geometric.Metric (R .fst) is-set (squared-distance form) isometric
      module Isometries = MetricAction.Isometries
      module Realization = MetricAction.Realization

      IsCrystallographic : Type (ℓ-suc ℓ)
      IsCrystallographic = MetricAction.IsCrystallographic

      abstract
        certificate : UnitIntervalCompact → IsCrystallographic
        certificate compact = MetricAction.realize faithful open-isolation
          (compact-fundamental-cover compact)

    CrystallographicStructure : Type (ℓ-suc ℓ)
    CrystallographicStructure = Σ[ form ∈ InnerProduct ]
      Σ[ isometric ∈ Isometric form ] WithMetric.IsCrystallographic form isometric

    abstract
      assemble : UnitIntervalCompact → (Σ[ form ∈ InnerProduct ] Isometric form)
        → CrystallographicStructure
      assemble compact (form , isometric) =
        form , isometric , WithMetric.certificate form isometric compact

    finite-integral-affine-crystallographic : isFinSet (H .fst)
      → UnitIntervalCompact → PT.∥ CrystallographicStructure ∥₁
    finite-integral-affine-crystallographic finite compact = PT.map
      (assemble compact)
      (IP.Geometry.Dimension.Representation.finite-affine-isometric
        R kock order compatibility n H ρ finite)
