{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.AtlasMorphisms where

-- Presentation changes for actual maps between effective atlases.
-- Full faithfulness concerns the supplied hom map, whose action on
-- identity paths must agree with the actual map and its atlas square.
-- Mere essential surjectivity uses only the existing bounded truncation.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Equivalence
open import Orbifolds.Intensional.BoundedTruncation
open import Orbifolds.Intensional.FiniteBranchAtlas using (module Finiteness; InverseData)

private variable ℓ : Level

right-concat-equivalence : {A : Set ℓ} {y z : A} (p : y ≡ z) (x : A)
  → Equiv (x ≡ y) (x ≡ z)
right-concat-equivalence p x = equiv (λ q → q ∙ p) (λ q → q ∙ sym p)
  (λ q → ∙-assoc q (sym p) p
    ∙ cong (λ r → q ∙ r) (∙-inverse-left p)
    ∙ ∙-right-unit q)
  (λ q → ∙-inverse-cancel-right q p)

path-whisker-equivalence : {A : Set ℓ} {x x' y y' : A}
  → (p : x ≡ x') → (q : y ≡ y') → Equiv (x' ≡ y') (x ≡ y)
path-whisker-equivalence {x' = x'} {y = y} p q =
  compEquiv (right-concat-equivalence (sym q) x') (left-concat-equivalence p y)

module Comparison {ℓ : Level} (T : BoundedTruncation ℓ) (ext : FunExt ℓ ℓ) where
  module P = Truncation T
  module F = Finiteness T
  module S = Surjections T
  open F.EffectiveAtlas

  private variable A B X Y : Set ℓ

  record AtlasMorphism (Q : F.EffectiveAtlas A X) (R : F.EffectiveAtlas B Y)
      : Set ℓ where
    field
      object-map : A → B
      map : X → Y
      square : (a : A) → map (atlas Q a) ≡ atlas R (object-map a)
      hom-map : (a b : A) → hom Q a b → hom R (object-map a) (object-map b)
      hom-path-computation : (a b : A) (h : hom Q a b)
        → cong map (forward (hom-path Q a b) h)
        ≡ square a
          ∙ forward (hom-path R (object-map a) (object-map b)) (hom-map a b h)
          ∙ sym (square b)

  open AtlasMorphism public

  FullyFaithful : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → AtlasMorphism Q R → Set ℓ
  FullyFaithful {A = A} m = (a b : A) → isEquiv (hom-map m a b)

  EssentiallySurjective : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → AtlasMorphism Q R → Set (Truth ℓ)
  EssentiallySurjective {A = A} {B = B} {R = R} m =
    (b : B) → P.Mere (Σ A (λ a → hom R (object-map m a) b))

  included-path-isEquiv : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → (a b : A)
    → isEquiv (λ (p : atlas Q a ≡ atlas Q b) → cong (map m) p)
  included-path-isEquiv {Q = Q} {R = R} m ff a b =
    homotopy-isEquiv (forward through-homs) (λ p → cong (map m) p)
      (λ p → sym (hom-path-computation m a b (backward source p))
        ∙ cong (cong (map m)) (section source p))
      (equiv→isEquiv through-homs)
    where
    source = hom-path Q a b
    target = compEquiv (hom-path R (object-map m a) (object-map m b))
      (path-whisker-equivalence (square m a) (square m b))
    through-homs = compEquiv (invEquiv source)
      (compEquiv (isEquiv→Equiv (hom-map m a b) (ff a b)) target)

  PathFullyFaithful : {X Y : Set ℓ} → (X → Y) → Set ℓ
  PathFullyFaithful {X = X} f =
    (x y : X) → isEquiv (λ (p : x ≡ y) → cong f p)

  fully-faithful→path-fully-faithful :
    {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → PathFullyFaithful (map m)
  fully-faithful→path-fully-faithful {Q = Q} m ff x y =
    P.mere-rec-low (isPropIsEquiv ext (λ (p : x ≡ y) → cong (map m) p))
      (λ { (a , p) →
        P.mere-rec-low (isPropIsEquiv ext (λ (r : x ≡ y) → cong (map m) r))
          (λ { (b , q) →
            subst (λ u → isEquiv (λ (r : u ≡ y) → cong (map m) r)) p
              (subst (λ v → isEquiv (λ (r : atlas Q a ≡ v) → cong (map m) r)) q
                (included-path-isEquiv m ff a b)) })
          (atlas-surjective Q y) })
      (atlas-surjective Q x)

  fully-faithful→embedding : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → isEmbedding (map m)
  fully-faithful→embedding m ff =
    path-isEquiv→isEmbedding (map m) (fully-faithful→path-fully-faithful m ff)

  essentially-surjective→surjection :
    {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → EssentiallySurjective m → P.Surjective (map m)
  essentially-surjective→surjection {Q = Q} {R = R} m es y =
    P.mere-rec (P.mere-prop (Fiber (map m) y))
      (λ { (b , p) → P.mere-map
        (λ { (a , h) → atlas Q a ,
          square m a ∙ forward (hom-path R (object-map m a) b) h ∙ p })
        (es b) })
      (atlas-surjective R y)

  -- The central theorem concludes equivalence of the supplied map.
  -- It assumes no inverse of that map and no independent equivalence
  -- between X and Y. Truncated witnesses are eliminated into propositions.
  atlas-morphism-isEquiv : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → EssentiallySurjective m
    → isEquiv (map m)
  atlas-morphism-isEquiv m ff es =
    S.embedding-surjection→isEquiv (map m)
      (fully-faithful→embedding m ff) (essentially-surjective→surjection m es)

  atlas-morphism-equivalence : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → EssentiallySurjective m → Equiv X Y
  atlas-morphism-equivalence m ff es =
    isEquiv→Equiv (map m) (atlas-morphism-isEquiv m ff es)

  atlas-morphism-equivalence-map :
    {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → (ff : FullyFaithful m) → (es : EssentiallySurjective m)
    → (x : X) → forward (atlas-morphism-equivalence m ff es) x ≡ map m x
  atlas-morphism-equivalence-map m ff es x = refl

  atlas-morphism-inverse-data : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → FullyFaithful m → EssentiallySurjective m
    → InverseData (map m)
  atlas-morphism-inverse-data m ff es =
    isEquiv→InverseData (map m) (atlas-morphism-isEquiv m ff es)

  -- The converse computations characterize the same hom map and the
  -- same presentation data. No high-universe function-extensionality
  -- principle is needed to package them as implications.
  isEquiv→fully-faithful : {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → isEquiv (map m) → FullyFaithful m
  isEquiv→fully-faithful {Q = Q} {R = R} m e a b =
    cancel-right-isEquiv (hom-map m a b) (forward target)
      (homotopy-isEquiv
        (λ h → cong (map m) (forward source h))
        (λ h → forward target (hom-map m a b h))
        (hom-path-computation m a b)
        (comp-isEquiv (forward source) (λ p → cong (map m) p)
          (equiv→isEquiv source) (isEquiv-cong (map m) e (atlas Q a) (atlas Q b))))
      (equiv→isEquiv target)
    where
    source = hom-path Q a b
    target = compEquiv (hom-path R (object-map m a) (object-map m b))
      (path-whisker-equivalence (square m a) (square m b))

  isEquiv→essentially-surjective :
    {Q : F.EffectiveAtlas A X} {R : F.EffectiveAtlas B Y}
    → (m : AtlasMorphism Q R) → isEquiv (map m) → EssentiallySurjective m
  isEquiv→essentially-surjective {Q = Q} {R = R} m e b =
    P.mere-map
      (λ { (a , q) → a , backward (hom-path R (object-map m a) b)
        (sym (square m a) ∙ cong (map m) q ∙ comparison) })
      (atlas-surjective Q preimage)
    where
    preimage = fst (fst (e (atlas R b)))
    comparison = snd (fst (e (atlas R b)))
