{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarConeTransformations where

-- Strict enriched transformations act on every finite bar-cone layer.
-- The action on actual bar faces and every coherence equation is derived.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; star)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Transformation)
open import Orbifolds.Coherent.EnrichedBarConeData using (LawPair)
import Orbifolds.Coherent.EnrichedBarConeData as Bar

module Action {ℓ : Level} {C : Category ℓ ℓ} (D D' : Diagram C ℓ)
    (η : Transformation D D') (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Chains C
  open Transformation η
  open StrictCubicalExtensionality E
  open Cubes.Extensional E
  module Source = Bar.Data C D
  module Target = Bar.Data C D'

  map-families : (n : Dim) {P : Type ℓ} → Source.Families n P → Target.Families n P
  map-families ozero F s y c = component y (F s y c)
  map-families (osuc n) F = map-families n (F .fst) ,
    (λ s y c → map-cube (osuc n) (component y) (F .snd s y c))

  top-map : (n : Dim) {P : Type ℓ} (F : Source.Families n P)
    (s : P) (y : Obj) (c : Chain n y)
    → outer (Target.top n (map-families n F) s y c)
      ≡ˢ outer (map-cube n (component y) (Source.top n F s y c))
  top-map ozero F s y c = reflˢ
  top-map (osuc n) F s y c = reflˢ

  action-natural-cube : (n : Dim) {x y : Obj} (f : Hom x y)
    (c : Cube n (Diagram.Value D x))
    → outer (map-cube n (component y) (map-cube n (Diagram.action D f) c))
      ≡ˢ outer (map-cube n (Diagram.action D' f) (map-cube n (component x) c))
  action-natural-cube n f c = strict-trans
    (map-compose n (component _) (Diagram.action D f) c)
    (strict-trans
      (strict-sym (strict-cong (λ z → outer (map-cube n (inner z) c)) (natural f)))
      (strict-sym (map-compose n (Diagram.action D' f) (component _) c)))

  one-map : (n : Dim) {P : Type ℓ} (F : Source.Families n P) (s : P)
    (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
    → outer (map-cube n (component y) (Source.one-face n F s p c))
      ≡ˢ outer (Target.one-face n (map-families n F) s p c)
  one-map n F s pzero c = strict-trans
    (action-natural-cube n (last-arrow n c)
      (Source.top n F s (last-source n c) (prefix n c)))
    (strict-cong (λ z → outer (map-cube n (Diagram.action D' (last-arrow n c)) (inner z)))
      (strict-sym (top-map n F s (last-source n c) (prefix n c))))
  one-map (osuc n) F s (psuc p) c = interval-ext λ i → strict-trans
    (action-natural-cube n (last-arrow (osuc n) c)
      (Source.one-face n (F .fst) s p (prefix (osuc n) c)))
    (strict-cong (λ z → outer (map-cube n (Diagram.action D' (last-arrow (osuc n) c)) (inner z)))
      (one-map n (F .fst) s p (prefix (osuc n) c)))

  bar-faces-map : (n : Dim) {P : Type ℓ} (F : Source.Families n P) (s : P)
    {y : Obj} (c : Chain (osuc n) y) (p : Position (osuc n)) (e : Endpoint)
    → outer (map-cube n (component y) (Source.bar-faces n F s c p e))
      ≡ˢ outer (Target.bar-faces n (map-families n F) s c p e)
  bar-faces-map n F s c p low = strict-sym (top-map n F s _ (face n p c))
  bar-faces-map n F s c p high = one-map n F s p c

  map-coherent : (n : Dim) {P : Type ℓ} (F : Source.Families n P)
    → Source.Coherent n F → Target.Coherent n (map-families n F)
  map-coherent ozero F coherent = star
  LawPair.earlier (map-coherent (osuc n) F coherent) =
    map-coherent n (F .fst) (LawPair.earlier coherent)
  Target.LayerLaws.zero-face (LawPair.current (map-coherent (osuc n) F coherent)) s y c p =
    strict-trans
      (strict-sym (map-face n p i0 (component y) (F .snd s y c)))
      (strict-trans
        (strict-cong (λ z → outer (map-cube n (component y) (inner z)))
          (Source.LayerLaws.zero-face (LawPair.current coherent) s y c p))
        (strict-sym (top-map n (F .fst) s y (face n p c))))
  Target.LayerLaws.one-face-law (LawPair.current (map-coherent (osuc n) F coherent)) s y c p =
    strict-trans
      (strict-sym (map-face n p i1 (component y) (F .snd s y c)))
      (strict-trans
        (strict-cong (λ z → outer (map-cube n (component y) (inner z)))
          (Source.LayerLaws.one-face-law (LawPair.current coherent) s y c p))
        (one-map n (F .fst) s p c))

  map-reindex : (n : Dim) {P Q : Type ℓ} (F : Source.Families n P) (f : Q → P)
    → outer (map-families n (Source.reindex n F f))
      ≡ˢ outer (Target.reindex n (map-families n F) f)
  map-reindex ozero F f = reflˢ
  map-reindex (osuc n) F f = strict-cong
    (λ z → outer (inner z , (λ s y c → map-cube (osuc n) (component y) (F .snd (f s) y c))))
    (map-reindex n (F .fst) f)
