{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitStages where

-- Construct every finite homotopy-coherent bar colimit stage. The successor is a literal
-- pushout, and its actual canonical cocone represents the full next
-- coherent cocone type. Naturality comes from the constructed action,
-- explicit quotation fibers, and proved strict boundary comparisons.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as StageComparison
import Orbifolds.Coherent.HomotopyCoherentColimitSuccessor as Successor

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module R = Represented.Induction C D E F
  open Cocones.Functoriality C D E F using (Cocone; postcompose)

  module Step (n : Dim) (previous : R.Represented n) =
    Successor.Successor C D E F n previous

  stage : (n : Dim) → R.Represented n
  stage ozero = R.initial
  stage (osuc n) = Step.next n (stage n)

  Space : Dim → Type ℓ
  Space n = R.Represented.Space (stage n)

  universal-cocone : (n : Dim) → Cocone (Space n) n
  universal-cocone n = R.Represented.universal-cocone (stage n)

  universal : (n : Dim) (Y : Type ℓ) → (Space n → Y) ≃ Cocone Y n
  universal n = R.Represented.universal (stage n)

  include : (n : Dim) → Space n → Space (osuc n)
  include n = Step.Cell.include n (stage n)

  restriction-computation : (n : Dim) (Y : Type ℓ) (h : Space n → Y)
    → universal n Y .fst h ≡ postcompose n h (universal-cocone n)
  restriction-computation n Y h = refl

  transition-computation : (n : Dim) (Y : Type ℓ) (h : Space (osuc n) → Y)
    → outer (Finite.Finite.transition (Opposite C) (Mapping.Mapping.Into C D E F Y) E n
        (universal (osuc n) Y .fst h))
      ≡ˢ outer (universal n Y .fst (h ∘ include n))
  transition-computation n Y h = Step.transition-computation n (stage n) Y h
