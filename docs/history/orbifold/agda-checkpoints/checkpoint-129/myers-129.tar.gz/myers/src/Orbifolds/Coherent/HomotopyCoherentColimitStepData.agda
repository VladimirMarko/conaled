{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitStepData where

-- Literal successor data with explicit types. This interface does not
-- instantiate the complete successor proof namespace in its consumers.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitCells as Cells
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Cubical.HITs.Pushout as PO

module Step {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where

  Previous : Type ℓ
  Previous = Cells.Construction.Space C D E F previous

  module Cell where
    Cell : Type ℓ
    Cell = Cells.Construction.Cells C D E F n

    Boundary : Type ℓ
    Boundary = Cells.Construction.Boundary C D E F n

    attach : Boundary → Previous
    attach = Cells.Construction.attach C D E F n previous

    boundary : Boundary → Cell
    boundary = Cells.Construction.boundary C D E F n

  Realize : Type ℓ
  Realize = PO.Pushout Cell.attach Cell.boundary

  next : Represented.Induction.Represented C D E F (osuc n)
  next = Cells.Construction.next C D E F n previous

  canonical-cocone : Cocones.Functoriality.Cocone C D E F Realize (osuc n)
  canonical-cocone = Stages.Construction.Step.canonical-cocone C D E F n previous

  include : Previous → Realize
  include = PO.inl

