{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalShellAssembly where

-- A finite, all-dimensional construction of the complete cubical shell
-- from its faces and strict overlap equations. The only structural input
-- beyond native Cubical Agda is the explicitly named extensionality rule.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using
  (Dim; ozero; osuc; toNat; Position; pzero; psuc; weaken; _≤ᵖ_; pzero≤; psuc≤)
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face)
import Orbifolds.CubicalShells as CS

data Endpoint : SSet where
  low high : Endpoint

endpoint : Endpoint → I
endpoint low = i0
endpoint high = i1

record OTop (ℓ : Level) : SSet ℓ where
  constructor star

Faces : ∀ {ℓ} → Dim → Type ℓ → SSet ℓ
Faces {ℓ} ozero X = OTop ℓ
Faces (osuc n) X = Position (osuc n) → Endpoint → Cube n X

Compatible : ∀ {ℓ} (n : Dim) {X : Type ℓ} → Faces n X → SSet ℓ
Compatible {ℓ} ozero F = OTop ℓ
Compatible {ℓ} (osuc ozero) F = OTop ℓ
Compatible (osuc (osuc n)) F =
  (p q : Position (osuc n)) → p ≤ᵖ q → (e f : Endpoint)
  → outer (coordinate-face n p (endpoint e) (F (psuc q) f))
    ≡ˢ outer (coordinate-face n q (endpoint f) (F (weaken p) e))

Agrees : ∀ {ℓ} (n : Dim) {X : Type ℓ} → Faces n X → Cube n X → SSet ℓ
Agrees {ℓ} ozero F c = OTop ℓ
Agrees (osuc n) F c = (p : Position (osuc n)) (e : Endpoint)
  → outer (F p e) ≡ˢ outer (coordinate-face n p (endpoint e) c)

slice-faces : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  → Faces (osuc n) X → I → Faces n X
slice-faces ozero F i = star
slice-faces (osuc n) F i p e = F (psuc p) e i

slice-compatible : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (F : Faces (osuc n) X) → Compatible (osuc n) F
  → (i : I) → Compatible n (slice-faces n F i)
slice-compatible ozero F compatible i = star
slice-compatible (osuc ozero) F compatible i = star
slice-compatible (osuc (osuc n)) F compatible i p q le e f =
  strict-cong (λ c → outer (inner c i))
    (compatible (psuc p) (psuc q) (psuc≤ le) e f)

slice-agrees : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (F : Faces (osuc n) X) (c : Cube (osuc n) X)
  → Agrees (osuc n) F c → (i : I)
  → Agrees n (slice-faces n F i) (c i)
slice-agrees ozero F c agree i = star
slice-agrees (osuc n) F c agree i p e =
  strict-cong (λ d → outer (inner d i)) (agree (psuc p) e)

end-agrees : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (F : Faces (osuc n) X) → Compatible (osuc n) F → (e : Endpoint)
  → Agrees n (slice-faces n F (endpoint e)) (F pzero e)
end-agrees ozero F compatible e = star
end-agrees (osuc n) F compatible e p f = compatible pzero p pzero≤ e f

strict-end-path : ∀ {ℓ} {A : Type ℓ} {x y : A} (q : I → A)
  → outer (q i0) ≡ˢ outer x → outer (q i1) ≡ˢ outer y → x ≡ y
strict-end-path q reflˢ reflˢ i = q i

strict-end-path-value : ∀ {ℓ} {A : Type ℓ} {x y : A} (q : I → A)
  (at-zero : outer (q i0) ≡ˢ outer x) (at-one : outer (q i1) ≡ˢ outer y)
  (i : I) → outer (strict-end-path q at-zero at-one i) ≡ˢ outer (q i)
strict-end-path-value q reflˢ reflˢ i = reflˢ

shell-face : ∀ {ℓ} (n : Dim) → Position (osuc n) → Endpoint → {X : Type ℓ}
  → CS.Shell (toNat (osuc n)) X → Cube n X
shell-face n pzero low b = b .fst .fst
shell-face n pzero high b = b .fst .snd
shell-face (osuc n) (psuc p) e b i = shell-face n p e (b .snd i)

record Assembler {ℓ} (n : Dim) (X : Type ℓ) : SSet ℓ where
  field
    assemble : (F : Faces n X) → Compatible n F → CS.Shell (toNat n) X
    correct : (F : Faces n X) (compatible : Compatible n F) (c : Cube n X)
      → Agrees n F c
      → outer (assemble F compatible) ≡ˢ outer (CS.restriction (toNat n) c)

module Construction {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  -- The endpoint casts are strict equality eliminations. Their choice
  -- does not add a coherence parameter: strict equality has UIP.
  strict-end-path-correct : {A : Type ℓ} {x y : A}
    (q : I → A) (p : x ≡ y)
    (at-zero : outer (q i0) ≡ˢ outer x)
    (at-one : outer (q i1) ≡ˢ outer y)
    → ((i : I) → outer (q i) ≡ˢ outer (p i))
    → outer (strict-end-path q at-zero at-one) ≡ˢ outer p
  strict-end-path-correct q p at-zero at-one agree with interval-ext agree
  ... | reflˢ with strict-uip at-zero reflˢ | strict-uip at-one reflˢ
  ... | reflˢ | reflˢ = reflˢ

  shell-correct : (n : Dim) {X : Type ℓ}
    (lo hi : Cube n X) (q : I → CS.Shell (toNat n) X)
    (at-zero : outer (q i0) ≡ˢ outer (CS.restriction (toNat n) lo))
    (at-one : outer (q i1) ≡ˢ outer (CS.restriction (toNat n) hi))
    (c : Cube (osuc n) X)
    → outer lo ≡ˢ outer (c i0) → outer hi ≡ˢ outer (c i1)
    → ((i : I) → outer (q i) ≡ˢ outer (CS.restriction (toNat n) (c i)))
    → outer ((lo , hi) , strict-end-path q at-zero at-one)
      ≡ˢ outer (CS.restriction (toNat (osuc n)) c)
  shell-correct n lo hi q at-zero at-one c reflˢ reflˢ agree =
    strict-cong (λ p → outer ((lo , hi) , inner p))
      (strict-end-path-correct q (λ i → CS.restriction (toNat n) (c i))
        at-zero at-one agree)

  base : (X : Type ℓ) → Assembler ozero X
  Assembler.assemble (base X) F compatible = lift tt
  Assembler.correct (base X) F compatible c agree = reflˢ

  module Step (n : Dim) (X : Type ℓ) (previous : Assembler n X) where
    open Assembler previous renaming (assemble to build; correct to build-correct)

    side-shell : (F : Faces (osuc n) X) (compatible : Compatible (osuc n) F)
      → I → CS.Shell (toNat n) X
    side-shell F compatible i = build (slice-faces n F i)
      (slice-compatible n F compatible i)

    side-at-end : (F : Faces (osuc n) X) (compatible : Compatible (osuc n) F)
      (e : Endpoint)
      → outer (side-shell F compatible (endpoint e))
        ≡ˢ outer (CS.restriction (toNat n) (F pzero e))
    side-at-end F compatible e = build-correct
      (slice-faces n F (endpoint e))
      (slice-compatible n F compatible (endpoint e))
      (F pzero e) (end-agrees n F compatible e)

    successor-shell : (F : Faces (osuc n) X) → Compatible (osuc n) F
      → CS.Shell (toNat (osuc n)) X
    successor-shell F compatible = (F pzero low , F pzero high) ,
      strict-end-path (side-shell F compatible)
        (side-at-end F compatible low) (side-at-end F compatible high)

    successor-correct : (F : Faces (osuc n) X) (compatible : Compatible (osuc n) F)
      (c : Cube (osuc n) X) → Agrees (osuc n) F c
      → outer (successor-shell F compatible)
        ≡ˢ outer (CS.restriction (toNat (osuc n)) c)
    successor-correct F compatible c agree = shell-correct n
      (F pzero low) (F pzero high) (side-shell F compatible)
      (side-at-end F compatible low) (side-at-end F compatible high) c
      (agree pzero low) (agree pzero high)
      (λ i → build-correct (slice-faces n F i)
        (slice-compatible n F compatible i) (c i) (slice-agrees n F c agree i))

    result : Assembler (osuc n) X
    Assembler.assemble result = successor-shell
    Assembler.correct result = successor-correct

  assembler : (n : Dim) (X : Type ℓ) → Assembler n X
  assembler ozero X = base X
  assembler (osuc n) X = Step.result n X (assembler n X)

  assemble : (n : Dim) {X : Type ℓ} (F : Faces n X)
    → Compatible n F → CS.Shell (toNat n) X
  assemble n {X} = Assembler.assemble (assembler n X)

  assemble-restriction : (n : Dim) {X : Type ℓ} (F : Faces n X)
    (compatible : Compatible n F) (c : Cube n X) → Agrees n F c
    → outer (assemble n F compatible) ≡ˢ outer (CS.restriction (toNat n) c)
  assemble-restriction n {X} = Assembler.correct (assembler n X)

  -- Every original face is retained by the constructed shell. This is
  -- stronger than merely comparing shells which already have a filler.
  assemble-face : (n : Dim) {X : Type ℓ} (F : Faces (osuc n) X)
    (compatible : Compatible (osuc n) F) (p : Position (osuc n)) (e : Endpoint)
    → outer (shell-face n p e (assemble (osuc n) F compatible)) ≡ˢ outer (F p e)
  assemble-face n F compatible pzero low = reflˢ
  assemble-face n F compatible pzero high = reflˢ
  assemble-face (osuc n) {X} F compatible (psuc p) e = interval-ext λ i →
    strict-trans
      (strict-cong (λ b → outer (shell-face n p e (inner b)))
        (strict-end-path-value
          (Step.side-shell (osuc n) X (assembler (osuc n) X) F compatible)
          (Step.side-at-end (osuc n) X (assembler (osuc n) X) F compatible low)
          (Step.side-at-end (osuc n) X (assembler (osuc n) X) F compatible high) i))
      (assemble-face n (slice-faces (osuc n) F i)
        (slice-compatible (osuc n) F compatible i) p e)

  restriction-face : (n : Dim) {X : Type ℓ} (p : Position (osuc n))
    (e : Endpoint) (c : Cube (osuc n) X)
    → outer (shell-face n p e (CS.restriction (toNat (osuc n)) c))
      ≡ˢ outer (coordinate-face n p (endpoint e) c)
  restriction-face n pzero low c = reflˢ
  restriction-face n pzero high c = reflˢ
  restriction-face (osuc n) (psuc p) e c = interval-ext λ i →
    restriction-face n p e (c i)
