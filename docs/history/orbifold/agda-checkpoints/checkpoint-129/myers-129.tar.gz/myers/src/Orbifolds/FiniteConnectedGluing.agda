{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.FiniteConnectedGluing where

-- The finite-cover negative-equality step needed in Lemma 6.3.4.
-- Local constancy on the actual cover members plus binary connectedness
-- gives double-negated global equality.  The proof decides only a finite
-- family of propositions under double negation; it never assumes LEM,
-- double-negation elimination, or an untruncated choice principle.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc)
open import Cubical.Data.Bool using (Bool; true; false; true≢false)
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; Dec; yes; no; isProp¬; isPropDec)
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Compactness using (_∨_)
open import Orbifolds.Penon using (Neighbors)
open import Orbifolds.Topology using (Predicate)

private variable ℓ : Level

-- A form of Proposition 6.3.3 sufficient for the gluing argument.
-- Both sides are merely inhabited; their overlap is only nonempty
-- (double-negated inhabitedness), exactly as constructive reasoning permits.
BinaryOverlap : Type ℓ → Type (ℓ-suc ℓ)
BinaryOverlap X = (U V : Predicate X) →
  ((x : X) → (U x .fst) ∨ (V x .fst)) →
  ∥ Σ[ x ∈ X ] U x .fst ∥₁ → ∥ Σ[ x ∈ X ] V x .fst ∥₁ →
  ¬ ¬ ∥ Σ[ x ∈ X ] (U x .fst × V x .fst) ∥₁

NoBooleanVariation : Type ℓ → Type ℓ
NoBooleanVariation X = (f : X → Bool) → (x y : X) → f x ≡ f y

noBooleanVariation→BinaryOverlap : {X : Type ℓ} → NoBooleanVariation X → BinaryOverlap X
noBooleanVariation→BinaryOverlap {X = X} constant U V cover inhabitedU inhabitedV emptyOverlap =
  PT.rec Empty.isProp⊥ (λ { (x , ux) → PT.rec Empty.isProp⊥
    (λ { (y , vy) → true≢false
      (sym (colorU x ux) ∙ constant color x y ∙ colorV y vy) }) inhabitedV }) inhabitedU
  where
  disjoint : (x : X) → U x .fst → V x .fst → Empty.⊥
  disjoint x ux vx = emptyOverlap ∣ x , ux , vx ∣₁

  decide : (x : X) → Dec (U x .fst)
  decide x = PT.rec (isPropDec (U x .snd))
    (Sum.rec yes (λ vx → no (λ ux → disjoint x ux vx))) (cover x)

  color : X → Bool
  color x with decide x
  ... | yes _ = true
  ... | no _ = false

  colorU : (x : X) → U x .fst → color x ≡ true
  colorU x ux with decide x
  ... | yes _ = refl
  ... | no absent = Empty.rec (absent ux)

  colorV : (x : X) → V x .fst → color x ≡ false
  colorV x vx with decide x
  ... | yes ux = Empty.rec (disjoint x ux vx)
  ... | no _ = refl

doubleNegatedDecision : (P : Type ℓ) → ¬ ¬ Dec P
doubleNegatedDecision P reject = reject (no (λ p → reject (yes p)))

finiteDoubleNegatedDecisions : (n : ℕ) (P : Fin n → Type ℓ) →
  ¬ ¬ ((i : Fin n) → Dec (P i))
finiteDoubleNegatedDecisions zero P reject = reject (λ ())
finiteDoubleNegatedDecisions (suc n) P reject = doubleNegatedDecision (P fzero)
  (λ first → finiteDoubleNegatedDecisions n (λ i → P (fsuc i))
    (λ rest → reject (λ { fzero → first ; (fsuc i) → rest i })))

ConstantOn : {X Y : Type ℓ} → (X → Y) → Predicate X → Type ℓ
ConstantOn {X = X} f U = (x y : X) → U x .fst → U y .fst → f x ≡ f y

finiteConstantCoverNeighbors : {X Y : Type ℓ} → isSet Y → BinaryOverlap X →
  (n : ℕ) (f : X → Y) (U : Fin n → Predicate X) →
  ((x : X) → ∥ Σ[ i ∈ Fin n ] U i x .fst ∥₁) →
  ((i : Fin n) → ConstantOn f (U i)) →
  (base x : X) → Neighbors (f base) (f x)
finiteConstantCoverNeighbors {ℓ = ℓ} {X = X} {Y = Y} setY connected n f U cover localConstant base x distinct =
  finiteDoubleNegatedDecisions n (λ i → EntireMember i .fst)
    (λ decisions → connected EqualBase UnequalBase (binaryCover decisions)
      ∣ base , refl ∣₁ ∣ x , distinct ∣₁
      (PT.rec Empty.isProp⊥ (λ { (y , equal , unequal) → unequal equal })))
  where
  EqualBase UnequalBase : Predicate X
  EqualBase y = (f base ≡ f y) , setY (f base) (f y)
  UnequalBase y = (¬ (f base ≡ f y)) , isProp¬ _

  EntireMember : Fin n → hProp ℓ
  EntireMember i = ((y : X) → U i y .fst → f base ≡ f y) ,
    isPropΠ2 (λ y _ → setY (f base) (f y))

  binaryCover : ((i : Fin n) → Dec (EntireMember i .fst)) →
    (y : X) → (EqualBase y .fst) ∨ (UnequalBase y .fst)
  binaryCover decisions y = PT.rec squash₁ classify (cover y)
    where
    classify : (Σ[ i ∈ Fin n ] U i y .fst) →
      (EqualBase y .fst) ∨ (UnequalBase y .fst)
    classify (i , member) with decisions i
    ... | yes allEqual = ∣ inl (allEqual y member) ∣₁
    ... | no notAll = ∣ inr (λ equal → notAll
      (λ z uz → equal ∙ localConstant i y z member uz)) ∣₁

finiteConstantCoverConstant : {X Y : Type ℓ} → isSet Y → BinaryOverlap X →
  ((y z : Y) → Neighbors y z → y ≡ z) →
  (n : ℕ) (f : X → Y) (U : Fin n → Predicate X) →
  ((x : X) → ∥ Σ[ i ∈ Fin n ] U i x .fst ∥₁) →
  ((i : Fin n) → ConstantOn f (U i)) → (x y : X) → f x ≡ f y
finiteConstantCoverConstant setY connected separated n f U cover localConstant x y =
  separated (f x) (f y) (finiteConstantCoverNeighbors setY connected n f U cover localConstant x y)

