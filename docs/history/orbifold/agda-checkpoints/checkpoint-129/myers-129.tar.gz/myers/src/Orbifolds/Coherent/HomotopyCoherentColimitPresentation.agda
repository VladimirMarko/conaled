{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitPresentation where

-- An actual cellular presentation and full mapping universal property
-- for a homotopy-coherent diagram. All finite representatives and their
-- attaching maps are constructed. A coinductive proof witness transfers
-- them to the ordinary-natural tower, without quantifying over outer
-- natural numbers in an inner type or assuming a presentation theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as ColimitStages
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as FiniteStages
import Orbifolds.Coherent.HomotopyCoherentConeStages as Cones
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularCoconeRepresentation as Representation

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module R = Represented.Induction C D E F
  module Stages = ColimitStages.Construction C D E F

  presentation : (n : Dim) (previous : R.Represented n)
    → CP.Presentation (R.Represented.Space previous)
  CP.Presentation.Boundary (presentation n previous) = Stages.Step.Cell.Boundary n previous
  CP.Presentation.Cells (presentation n previous) = Stages.Step.Cell.Cell n previous
  CP.Presentation.attach (presentation n previous) = Stages.Step.Cell.attach n previous
  CP.Presentation.boundary (presentation n previous) = Stages.Step.Cell.boundary n previous
  CP.Presentation.next (presentation n previous) = presentation (osuc n) (Stages.Step.next n previous)

  Initial : Type ℓ
  Initial = R.Represented.Space R.initial

  bar-presentation : CP.Presentation Initial
  bar-presentation = presentation ozero R.initial

  module Realization = CP.Realization Initial bar-presentation

  Colimit : Type ℓ
  Colimit = Realization.Realize

  module MappingOut (Y : Type ℓ) where
    module B = Cones.Construction (Opposite C) (Mapping.Mapping.Into C D E F Y) E
    module Finite = FiniteStages.Finite (Opposite C) (Mapping.Mapping.Into C D E F Y) E
    module Witnesses = Representation.Coinductive {ℓa = ℓ} Y B.State fst B.advance (λ q → fst)

    finite-witness : (n : Dim) (previous : R.Represented n)
      → Witnesses.Witness (presentation n previous) (Finite.finite-state n)
    Witnesses.Witness.current (finite-witness n previous) = R.Represented.universal previous Y
    Witnesses.Witness.tail (finite-witness n previous) = finite-witness (osuc n) (Stages.Step.next n previous)
    Witnesses.Witness.square (finite-witness n previous) h =
      strict-to-path {A = Finite.Carrier n}
        {x = Finite.transition n (R.Represented.universal (Stages.Step.next n previous) Y .fst h)}
        {y = R.Represented.universal previous Y .fst (h ∘ Stages.Step.Cell.include n previous)}
        (Stages.Step.transition-computation n previous Y h)

    witness-at : (n : ℕ) → Witnesses.Witness (Realization.state n .snd) (B.state n)
    witness-at zero = finite-witness ozero R.initial
    witness-at (suc n) = Witnesses.Witness.tail (witness-at n)

    stage-universal : (n : ℕ) → (Realization.Stage n → Y) ≃ B.PartialCone n
    stage-universal n = Witnesses.Witness.current (witness-at n)

    stage-square : (n : ℕ) (h : Realization.Stage (suc n) → Y)
      → B.drop n (stage-universal (suc n) .fst h)
        ≡ stage-universal n .fst (h ∘ Realization.inclusion n)
    stage-square n = Witnesses.Witness.square (witness-at n)

    module Universal = Representation.SequenceRepresentation Realization.stages Y
      B.PartialCone B.drop stage-universal stage-square

    Cocone : Type ℓ
    Cocone = B.Limit

    universal : (Colimit → Y) ≃ Cocone
    universal = Universal.universal

    restrict : (Colimit → Y) → Cocone
    restrict = Universal.restrict

    assemble : Cocone → Colimit → Y
    assemble = Universal.assemble

    open Universal using (stage-computation; compatibility-computation) public

  canonical-cocone : MappingOut.Cocone Colimit
  canonical-cocone = MappingOut.restrict Colimit (idfun Colimit)
