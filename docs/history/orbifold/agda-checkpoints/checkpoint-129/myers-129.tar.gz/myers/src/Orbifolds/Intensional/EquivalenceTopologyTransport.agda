{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.EquivalenceTopologyTransport where

-- Transport the actual open-set and finite-cover operations along an
-- explicit equivalence. No choice, excluded middle or compactness result
-- is supplied beyond the particular compact operation being transported.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; Included; OpenFragment; IsOpen
  ; open-full; open-transfer; open-intersection; open-local )
open import Orbifolds.Intensional.CompactSeparation using
  ( Some; Covers; FiniteSubcover; CompactData; preimage; Continuous; ProperData )
import Orbifolds.Intensional.OpenSubspaces as OS

compact-preimage-homeomorphism : {ℓ : Level} {A B : Set ℓ}
  {OA : OpenFragment A} {OB : OpenFragment B}
  (h : OS.Homeomorphism OA OB) (K : Subset B)
  → CompactData OB K
  → CompactData OA (preimage (forward (OS.underlying h)) K)
compact-preimage-homeomorphism {A = A} {B} {OA} {OB}
    h K compact {I} U opens covers =
  fst finite , λ a inside →
    subst (λ z → Some (λ i → member (U i) z) (fst finite))
      (retraction e a) (snd finite (forward e a) inside)
  where
  e : Equiv A B
  e = OS.underlying h

  patches : I → Subset B
  patches i = preimage (backward e) (U i)

  patches-open : (i : I) → IsOpen OB (patches i)
  patches-open i = OS.backward-continuous h (U i) (opens i)

  patches-cover : Covers K patches
  patches-cover b inside = covers (backward e b)
    (subst (member K) (sym (section e b)) inside)

  finite : FiniteSubcover K patches
  finite = compact patches patches-open patches-cover

module Transport {ℓ : Level} {A B : Set ℓ}
    (e : Equiv A B) (OB : OpenFragment B) where

  topology : OpenFragment A
  IsOpen topology P = IsOpen OB (preimage (backward e) P)
  open-full topology = open-full OB
  open-transfer topology {P} {Q} to from = open-transfer OB
    {P = preimage (backward e) P} {Q = preimage (backward e) Q}
    (λ b → to (backward e b)) (λ b → from (backward e b))
  open-intersection topology {P} {Q} open-P open-Q =
    open-intersection OB
      {P = preimage (backward e) P} {Q = preimage (backward e) Q} open-P open-Q
  open-local topology P local = open-local OB (preimage (backward e) P)
    (λ b inside →
      let chosen = local (backward e b) inside
          U = fst chosen
          open-U = fst (snd chosen)
          at-center = fst (snd (snd chosen))
          included = snd (snd (snd chosen))
      in preimage (backward e) U , open-U , at-center ,
        (λ c → included (backward e c)))

  forward-continuous : Continuous topology OB (forward e)
  forward-continuous P open-P = open-transfer OB
    {P = P} {Q = preimage (backward e) (preimage (forward e) P)}
    (λ b inside → subst (member P) (sym (section e b)) inside)
    (λ b inside → subst (member P) (section e b) inside)
    open-P

  backward-continuous : Continuous OB topology (backward e)
  backward-continuous P open-P = open-P

  homeomorphism : OS.Homeomorphism topology OB
  OS.underlying homeomorphism = e
  OS.forward-continuous homeomorphism = forward-continuous
  OS.backward-continuous homeomorphism = backward-continuous

  compact-preimage : (K : Subset B) → CompactData OB K
    → CompactData topology (preimage (forward e) K)
  compact-preimage = compact-preimage-homeomorphism {OA = topology} {OB = OB} homeomorphism

  proper-precompose : {C : Set ℓ} (OC : OpenFragment C) (f : B → C)
    → ProperData OB OC f
    → ProperData topology OC (λ a → f (forward e a))
  proper-precompose OC f proper K compact =
    compact-preimage (preimage f K) (proper K compact)

  continuous-precompose : {C : Set ℓ} (OC : OpenFragment C) (f : B → C)
    → Continuous OB OC f
    → Continuous topology OC (λ a → f (forward e a))
  continuous-precompose OC f continuous = OS.compose-continuous
    topology OB OC (forward e) f forward-continuous continuous

-- The finite list selected on B is retained verbatim. Its membership
-- certificates return to A by the equivalence's actual retraction path.
-- Neither sethood of A/B nor a decision procedure for membership is used.
