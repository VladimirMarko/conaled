{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellAttachments where

-- A literal pushout representing a family of complete typed cells. The
-- chosen quotation fiber is mapped from the original boundary, retaining
-- its sphere map judgmentally. This gives the actual target naturality
-- of the full mapping equivalence without an extra coherence premise.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalShellFunctor as ShellFunctor
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.Coherent.NaturalQuoteFiberFunctor as FiberFunctor
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)
import Orbifolds.MappingColimits as Mapping
import Cubical.HITs.Pushout as PO

module Attachment {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A Index : Type ℓ) (Coefficient : Index → Type ℓ)
    (original-boundary : (c : Index) → CS.Shell (toNat n) (Coefficient c → A)) where
  module S = Shells.Action E
  module SF = ShellFunctor.Functoriality E
  module F = Fillers.Action E
  module N = Natural.Natural E
  module NF = FiberFunctor.Functoriality E

  Cell : Type ℓ
  Cell = Σ Index Coefficient

  Boundary : Type ℓ
  Boundary = Cell × SphereBoundary (toNat n)

  attach : Boundary → A
  attach ((c , x) , s) = N.evaluate n (original-boundary c) s x

  boundary : Boundary → Cell
  boundary = fst

  Realize : Type ℓ
  Realize = PO.Pushout attach boundary

  include : A → Realize
  include = PO.inl

  center : Cell → Realize
  center = PO.inr

  mapped-boundary : (Y : Type ℓ) → (A → Y) → (c : Index)
    → CS.Shell (toNat n) (Coefficient c → Y)
  mapped-boundary Y h c = S.map-shell n (λ v → h ∘ v) (original-boundary c)

  Cocone : Type ℓ → Type ℓ
  Cocone Y = Σ[ h ∈ (A → Y) ] ((c : Index) → CF.Filler (toNat n) (mapped-boundary Y h c))

  module Target (Y : Type ℓ) where
    module Ordinary = Mapping.Span attach boundary Y

    module Fixed (h : A → Y) where
      RawCells : Type ℓ
      RawCells = Σ[ g ∈ (Cell → Y) ] (h ∘ attach ≡ g ∘ boundary)

      composed-boundary : (c : Index) → SphereBoundary (toNat n) → Coefficient c → Y
      composed-boundary c s x = h (N.evaluate n (original-boundary c) s x)

      constant-boundary : (c : Index) → (Coefficient c → Y)
        → SphereBoundary (toNat n) → Coefficient c → Y
      constant-boundary c k s = k

      Coefficientwise : Type ℓ
      Coefficientwise = (c : Index) → Σ[ k ∈ (Coefficient c → Y) ]
        (composed-boundary c ≡ constant-boundary c k)

      split : RawCells → Coefficientwise
      split (g , p) c = (λ x → g (c , x)) , (λ i s x → p i ((c , x) , s))

      join : Coefficientwise → RawCells
      join q = (λ cx → q (cx .fst) .fst (cx .snd)) ,
        (λ i cs → q (cs .fst .fst) .snd i (cs .snd) (cs .fst .snd))

      split-equivalence : RawCells ≃ Coefficientwise
      split-equivalence = isoToEquiv (iso split join (λ _ → refl) (λ _ → refl))

      cell-equivalence : (c : Index)
        → (Σ[ k ∈ (Coefficient c → Y) ]
            (composed-boundary c ≡ constant-boundary c k))
          ≃ CF.Filler (toNat n) (mapped-boundary Y h c)
      cell-equivalence c = N.fiber-fill-equivalence n (mapped-boundary Y h c)
        (N.map-fiber n (λ v → h ∘ v) (original-boundary c)
          (N.canonical-fiber n (original-boundary c)))

      cells-equivalence : RawCells ≃ ((c : Index) → CF.Filler (toNat n) (mapped-boundary Y h c))
      cells-equivalence = split-equivalence ∙ₑ equivΠCod cell-equivalence

    cocone-equivalence : Ordinary.Cocone ≃ Cocone Y
    cocone-equivalence = Σ-cong-equiv-snd Fixed.cells-equivalence

    universal : (Realize → Y) ≃ Cocone Y
    universal = Ordinary.universal ∙ₑ cocone-equivalence

    restrict : (Realize → Y) → Cocone Y
    restrict = universal .fst

    original-computation : (h : Realize → Y) → restrict h .fst ≡ h ∘ include
    original-computation h = refl

    cell-computation : (h : Realize → Y) (c : Index)
      → restrict h .snd c ≡ N.fiber-fill n (mapped-boundary Y (h ∘ include) c)
          (N.map-fiber n (λ v → h ∘ include ∘ v) (original-boundary c)
            (N.canonical-fiber n (original-boundary c)))
          ((λ x → h (center (c , x))) , (λ i s x → h (PO.push ((c , x) , s) i)))
    cell-computation h c = refl

  postcompose : {Y Z : Type ℓ} → (Y → Z) → Cocone Y → Cocone Z
  postcompose k (h , fs) = k ∘ h , λ c → cast-filler n
    (SF.map-compose n (λ v → k ∘ v) (λ v → h ∘ v) (original-boundary c))
    (F.map-filler n (λ v → k ∘ v) (mapped-boundary _ h c) (fs c))

  restrict-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Realize → Y)
    → postcompose k (Target.restrict Y h) ≡ Target.restrict Z (k ∘ h)
  restrict-natural k h = ΣPathP (refl , funExt λ c →
    NF.map-fiber-fill-compose n (λ v → k ∘ v) (λ v → h ∘ include ∘ v)
      (original-boundary c) (N.canonical-fiber n (original-boundary c))
      ((λ x → h (center (c , x))) , (λ i s x → h (PO.push ((c , x) , s) i))))

  canonical-cocone : Cocone Realize
  canonical-cocone = Target.restrict Realize (idfun Realize)

  canonical-restriction : (Y : Type ℓ) → (Realize → Y) → Cocone Y
  canonical-restriction Y h = postcompose h canonical-cocone

  canonical-restriction-isEquiv : (Y : Type ℓ) → isEquiv (canonical-restriction Y)
  canonical-restriction-isEquiv Y = subst isEquiv
    (sym (funExt λ h → restrict-natural h (idfun Realize))) (Target.universal Y .snd)
