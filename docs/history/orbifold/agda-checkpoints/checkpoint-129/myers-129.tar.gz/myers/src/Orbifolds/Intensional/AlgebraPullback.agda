{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.AlgebraPullback where

-- The carrier is the literal set pullback already used by
-- FiniteSupportScalarExtension. Operations and their closure proofs
-- are coordinatewise; projections and comparison are actual algebra
-- maps, not maps replaced by an unrelated carrier equivalence.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteSupportPullbacks using (Pullback; pullback-path)
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor
open import Orbifolds.Intensional.CommutativeAlgebraCore

private variable ℓ : Level

module PullbackAlgebra {ℓ : Level} (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
    (A B C : CommutativeAlgebra R) (f : AlgebraHom A C) (g : AlgebraHom B C) where

  private module A = CommutativeAlgebra A
  private module B = CommutativeAlgebra B
  private module C = CommutativeAlgebra C
  private module AS = CommutativeSemiring A.semiring
  private module BS = CommutativeSemiring B.semiring
  private module F = AlgebraHom f
  private module G = AlgebraHom g

  P : Set ℓ
  P = Pullback F.map G.map

  path : {u v : P} → fst u ≡ fst v → fst (snd u) ≡ fst (snd v) → u ≡ v
  path = pullback-path {f = F.map} {g = G.map} C.carrier-set

  path-η : {u v : P} (p : u ≡ v)
    → path (cong fst p) (cong (λ z → fst (snd z)) p) ≡ p
  path-η {u = a , (b , e)} refl =
    cong (cong (λ q → a , (b , q)))
      (isProp→isSet (C.carrier-set (G.map b) (F.map a)) e e
        (C.carrier-set (G.map b) (F.map a) e e) refl)

  carrier-set : isSet P
  carrier-set u v p q = sym (path-η p)
    ∙ cong₂ (path {u = u} {v = v})
      (A.carrier-set (fst u) (fst v) (cong fst p) (cong fst q))
      (B.carrier-set (fst (snd u)) (fst (snd v))
        (cong (λ z → fst (snd z)) p) (cong (λ z → fst (snd z)) q))
    ∙ path-η q

  zero : P
  zero = A.zero , (B.zero , G.map-zero ∙ sym F.map-zero)

  add : P → P → P
  add (a , (b , p)) (a' , (b' , q)) = (a A.+ a') , ((b B.+ b') ,
    (G.map-add b b' ∙ cong₂ C._+_ p q ∙ sym (F.map-add a a')))

  scale : CommutativeSemiring.Carrier R → P → P
  scale r (a , (b , p)) = (r A.• a) , ((r B.• b) ,
    (G.map-scalar r b ∙ cong (C._•_ r) p ∙ sym (F.map-scalar r a)))

  additive : AdditiveMonoid ℓ
  AdditiveMonoid.Carrier additive = P
  AdditiveMonoid.carrier-set additive = carrier-set
  AdditiveMonoid.zero additive = zero
  AdditiveMonoid._+_ additive = add
  AdditiveMonoid.+-assoc additive u v w = path
    (A.+-assoc (fst u) (fst v) (fst w))
    (B.+-assoc (fst (snd u)) (fst (snd v)) (fst (snd w)))
  AdditiveMonoid.+-comm additive u v = path
    (A.+-comm (fst u) (fst v)) (B.+-comm (fst (snd u)) (fst (snd v)))
  AdditiveMonoid.+-zero-left additive u = path
    (A.+-zero-left (fst u)) (B.+-zero-left (fst (snd u)))
  AdditiveMonoid.+-zero-right additive u = path
    (A.+-zero-right (fst u)) (B.+-zero-right (fst (snd u)))

  moduleR : Semimodule R
  Semimodule.additive moduleR = additive
  Semimodule._•_ moduleR = scale
  Semimodule.•-one moduleR u = path (A.•-one (fst u)) (B.•-one (fst (snd u)))
  Semimodule.•-assoc moduleR r s u = path
    (A.•-assoc r s (fst u)) (B.•-assoc r s (fst (snd u)))
  Semimodule.•-zero moduleR r = path (A.•-zero r) (B.•-zero r)
  Semimodule.zero-• moduleR u = path (A.zero-• (fst u)) (B.zero-• (fst (snd u)))
  Semimodule.•-add moduleR r u v = path
    (A.•-add r (fst u) (fst v)) (B.•-add r (fst (snd u)) (fst (snd v)))
  Semimodule.add-• moduleR r s u = path
    (A.add-• r s (fst u)) (B.add-• r s (fst (snd u)))

  one : P
  one = A.one , (B.one , G.map-one ∙ sym F.map-one)

  multiply : P → P → P
  multiply (a , (b , p)) (a' , (b' , q)) = (a A.* a') , ((b B.* b') ,
    (G.map-mul b b' ∙ cong₂ C._*_ p q ∙ sym (F.map-mul a a')))

  left-multiply : (u : P) → LinearMap moduleR moduleR
  left-multiply u = multiply u ,
    ((path (AS.*-zero-right (fst u)) (BS.*-zero-right (fst (snd u))) ,
      λ v w → path (AS.*-add-right (fst u) (fst v) (fst w))
        (BS.*-add-right (fst (snd u)) (fst (snd v)) (fst (snd w)))) ,
      λ r v → path
        (linear-scalar {M = A.moduleR} {N = A.moduleR} (A.left-multiply (fst u)) r (fst v))
        (linear-scalar {M = B.moduleR} {N = B.moduleR} (B.left-multiply (fst (snd u))) r (fst (snd v))))

  right-multiply : (v : P) → LinearMap moduleR moduleR
  right-multiply v = (λ u → multiply u v) ,
    ((path (AS.*-zero-left (fst v)) (BS.*-zero-left (fst (snd v))) ,
      λ u w → path (AS.*-add-left (fst u) (fst w) (fst v))
        (BS.*-add-left (fst (snd u)) (fst (snd w)) (fst (snd v)))) ,
      λ r u → path
        (linear-scalar {M = A.moduleR} {N = A.moduleR} (A.right-multiply (fst v)) r (fst u))
        (linear-scalar {M = B.moduleR} {N = B.moduleR} (B.right-multiply (fst (snd v))) r (fst (snd u))))

  multiplication : BilinearMap moduleR moduleR moduleR
  multiplication = multiply , ((λ v → snd (right-multiply v)) , λ u → snd (left-multiply u))

  algebra : CommutativeAlgebra R
  CommutativeAlgebra.moduleR algebra = moduleR
  CommutativeAlgebra.one algebra = one
  CommutativeAlgebra.multiplication algebra = multiplication
  CommutativeAlgebra.*-assoc algebra u v w = path
    (A.*-assoc (fst u) (fst v) (fst w)) (B.*-assoc (fst (snd u)) (fst (snd v)) (fst (snd w)))
  CommutativeAlgebra.*-comm algebra u v = path
    (A.*-comm (fst u) (fst v)) (B.*-comm (fst (snd u)) (fst (snd v)))
  CommutativeAlgebra.*-one-left algebra u = path
    (A.*-one-left (fst u)) (B.*-one-left (fst (snd u)))

  first : AlgebraHom algebra A
  AlgebraHom.linear first = fst , ((refl , λ u v → refl) , λ r v → refl)
  AlgebraHom.map-one first = refl
  AlgebraHom.map-mul first u v = refl

  second : AlgebraHom algebra B
  AlgebraHom.linear second = (λ z → fst (snd z)) , ((refl , λ u v → refl) , λ r v → refl)
  AlgebraHom.map-one second = refl
  AlgebraHom.map-mul second u v = refl

  commutes : (z : P) → G.map (AlgebraHom.map second z) ≡ F.map (AlgebraHom.map first z)
  commutes z = snd (snd z)

  module Comparison (D : CommutativeAlgebra R) (u : AlgebraHom D A) (v : AlgebraHom D B)
      (commute : (d : CommutativeAlgebra.Carrier D)
        → G.map (AlgebraHom.map v d) ≡ F.map (AlgebraHom.map u d)) where

    private module D = CommutativeAlgebra D
    private module U = AlgebraHom u
    private module V = AlgebraHom v

    comparison : D.Carrier → P
    comparison d = U.map d , (V.map d , commute d)

    comparison-hom : AlgebraHom D algebra
    AlgebraHom.linear comparison-hom = comparison ,
      ((path U.map-zero V.map-zero , λ a b → path (U.map-add a b) (V.map-add a b)) ,
        λ r a → path (U.map-scalar r a) (V.map-scalar r a))
    AlgebraHom.map-one comparison-hom = path U.map-one V.map-one
    AlgebraHom.map-mul comparison-hom a b = path (U.map-mul a b) (V.map-mul a b)

    first-comparison : (d : D.Carrier) → AlgebraHom.map first (comparison d) ≡ U.map d
    first-comparison d = refl

    second-comparison : (d : D.Carrier) → AlgebraHom.map second (comparison d) ≡ V.map d
    second-comparison d = refl

    abstract
      unique : (k : AlgebraHom D algebra)
        → ((d : D.Carrier) → AlgebraHom.map first (AlgebraHom.map k d) ≡ U.map d)
        → ((d : D.Carrier) → AlgebraHom.map second (AlgebraHom.map k d) ≡ V.map d)
        → k ≡ comparison-hom
      unique k first-agrees second-agrees = algebra-hom-path ext {A = D} {B = algebra}
        {h = k} {k = comparison-hom}
        (linear-path ext {M = D.moduleR} {N = moduleR}
          {h = AlgebraHom.linear k} {k = AlgebraHom.linear comparison-hom}
          (ext (λ d → path (first-agrees d) (second-agrees d))))
