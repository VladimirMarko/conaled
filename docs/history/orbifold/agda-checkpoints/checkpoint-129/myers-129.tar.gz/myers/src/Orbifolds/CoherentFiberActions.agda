{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CoherentFiberActions where

-- Coherent invariance of an actual map gives an actual action on its
-- literal fibers. An explicit small fiber equivalence then transfers
-- this action without assuming any universe-resizing principle.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Path
open import Cubical.Foundations.Transport
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Functions.Surjection using (isSurjection)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Torsors as Torsors

module Action {ℓg ℓx ℓy : Level} (G : Group ℓg) (X : Type ℓx)
    (act : G .fst → X → X)
    (unit : (x : X) → act (GroupStr.1g (G .snd)) x ≡ x)
    (compose : (g h : G .fst) (x : X)
      → act (GroupStr._·_ (G .snd) g h) x ≡ act g (act h x))
    {Y : Type ℓy} (q : X → Y)
    (invariance : (g : G .fst) (x : X) → q (act g x) ≡ q x)
    (invariance-unit : (x : X)
      → invariance (GroupStr.1g (G .snd)) x ≡ cong q (unit x))
    (invariance-compose : (g h : G .fst) (x : X)
      → invariance (GroupStr._·_ (G .snd) g h) x
        ≡ cong q (compose g h x) ∙ (invariance g (act h x) ∙ invariance h x)) where
  open GroupStr (G .snd)
  module T = Torsors.Theory G

  fiber-action : (y : Y) → G .fst → fiber q y → fiber q y
  fiber-action y g (x , p) = act g x , invariance g x ∙ p

  fiber-unit : (y : Y) (z : fiber q y) → fiber-action y 1g z ≡ z
  fiber-unit y (x , p) = equivFun (ΣPathTransport≃PathΣ _ _) (unit x ,
    substInPathsR (cong q (unit x)) (invariance 1g x ∙ p)
    ∙ cong (sym (cong q (unit x)) ∙_) (cong (_∙ p) (invariance-unit x))
    ∙ compPathl-cancel (sym (cong q (unit x))) p)

  fiber-compose : (y : Y) (g h : G .fst) (z : fiber q y)
    → fiber-action y (g · h) z ≡ fiber-action y g (fiber-action y h z)
  fiber-compose y g h (x , p) = equivFun (ΣPathTransport≃PathΣ _ _) (compose g h x ,
    substInPathsR (cong q (compose g h x)) (invariance (g · h) x ∙ p)
    ∙ cong (sym (cong q (compose g h x)) ∙_) (cong (_∙ p) (invariance-compose g h x))
    ∙ cong (sym (cong q (compose g h x)) ∙_)
        (sym (assoc (cong q (compose g h x)) (invariance g (act h x) ∙ invariance h x) p))
    ∙ compPathl-cancel (sym (cong q (compose g h x)))
        ((invariance g (act h x) ∙ invariance h x) ∙ p)
    ∙ sym (assoc (invariance g (act h x)) (invariance h x) p))

  module Small (Carrier : Y → Type ℓg)
      (coordinates : (y : Y) → Carrier y ≃ fiber q y)
      (carrier-set : (y : Y) → isSet (Carrier y)) where

    small-action : (y : Y) → G .fst → Carrier y → Carrier y
    small-action y g z = invEq (coordinates y) (fiber-action y g (coordinates y .fst z))

    coordinate-action : (y : Y) (g : G .fst) (z : Carrier y)
      → coordinates y .fst (small-action y g z)
        ≡ fiber-action y g (coordinates y .fst z)
    coordinate-action y g z = secEq (coordinates y) (fiber-action y g (coordinates y .fst z))

    coordinate-equivariance : (y : Y) (g : G .fst) (z : Carrier y)
      → coordinates y .fst (small-action y g z) .fst ≡ act g (coordinates y .fst z .fst)
    coordinate-equivariance y g z = cong fst (coordinate-action y g z)

    small-unit : (y : Y) (z : Carrier y) → small-action y 1g z ≡ z
    small-unit y z = invEq (congEquiv (coordinates y))
      (coordinate-action y 1g z ∙ fiber-unit y (coordinates y .fst z))

    small-compose : (y : Y) (g h : G .fst) (z : Carrier y)
      → small-action y (g · h) z ≡ small-action y g (small-action y h z)
    small-compose y g h z = invEq (congEquiv (coordinates y))
      (coordinate-action y (g · h) z
        ∙ fiber-compose y g h (coordinates y .fst z)
        ∙ cong (fiber-action y g) (sym (coordinate-action y h z))
        ∙ sym (coordinate-action y g (small-action y h z)))

    small-action-structure : (y : Y) → T.Action
    small-action-structure y = (Carrier y , small-action y) , carrier-set y , small-unit y , small-compose y

    small-orbit-isEquiv : (y : Y) (z : Carrier y)
      → isEquiv (λ g → fiber-action y g (coordinates y .fst z))
      → isEquiv (λ g → small-action y g z)
    small-orbit-isEquiv y z orbit = compEquiv
      ((λ g → fiber-action y g (coordinates y .fst z)) , orbit)
      (invEquiv (coordinates y)) .snd

    torsors : isSurjection q
      → ((y : Y) (z : fiber q y) → isEquiv (λ g → fiber-action y g z))
      → (y : Y) → T.Torsor
    torsors surjective orbits y = small-action-structure y ,
      PT.map (invEq (coordinates y)) (surjective y) ,
      (λ z → small-orbit-isEquiv y z (orbits y (coordinates y .fst z)))
