{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.FiniteIntervalChains where

-- Constructive gluing along a finite cover by open intervals.
-- Only the interval endpoints need decidable comparison. The ambient
-- ordered space need not have decidable equality or decidable order.
-- Selection predicates on the finite family remain arbitrary types.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc)
open import Cubical.Relation.Nullary using (Dec; yes; no; ¬_)
import Cubical.Data.Empty as Empty
import Cubical.HITs.PropositionalTruncation as PT

-- Delete an arbitrary member, retaining an explicit inverse on all
-- the remaining members. This is constructive finite combinatorics.
skip : {n : ℕ} → Fin (suc n) → Fin n → Fin (suc n)
skip {zero} fzero ()
skip {suc n} fzero j = fsuc j
skip {suc n} (fsuc i) fzero = fzero
skip {suc n} (fsuc i) (fsuc j) = fsuc (skip i j)

split-skip : {n : ℕ} (i j : Fin (suc n))
  → (j ≡ i) ⊎ (Σ[ k ∈ Fin n ] skip i k ≡ j)
split-skip {zero} fzero fzero = inl refl
split-skip {suc n} fzero fzero = inl refl
split-skip {suc n} fzero (fsuc j) = inr (j , refl)
split-skip {suc n} (fsuc i) fzero = inr (fzero , refl)
split-skip {suc n} (fsuc i) (fsuc j) with split-skip i j
... | inl equal = inl (cong fsuc equal)
... | inr (k , equal) = inr (fsuc k , cong fsuc equal)

record DenseOrder {ℓx : Level} (X : Type ℓx) (ℓr : Level)
    : Type (ℓ-max ℓx (ℓ-suc ℓr)) where
  infix 4 _<_ _≤_
  field
    _<_ _≤_ : X → X → Type ℓr
    ≤-refl : (x : X) → x ≤ x
    <-weaken : {x y : X} → x < y → x ≤ y
    ≤-trans : {x y z : X} → x ≤ y → y ≤ z → x ≤ z
    <-trans : {x y z : X} → x < y → y < z → x < z
    <≤-trans : {x y z : X} → x < y → y ≤ z → x < z
    ≤<-trans : {x y z : X} → x ≤ y → y < z → x < z
    incompatible : {x y : X} → x < y → y ≤ x → Empty.⊥
    notLess→reverseWeak : {x y : X} → ¬ (x < y) → y ≤ x
    dense : {x y : X} → x < y → Σ[ z ∈ X ] ((x < z) × (z < y))

module Chains {ℓx ℓq ℓr ℓy ℓp : Level} {X : Type ℓx}
    (order : DenseOrder X ℓr) {Q : Type ℓq} (point : Q → X)
    (endpoint-comparison : (a b : Q) → Dec (DenseOrder._<_ order (point a) (point b)))
    {Y : Type ℓy} (setY : isSet Y) (f : X → Y) where
  open DenseOrder order

  Within : Q → Q → X → Type ℓr
  Within lower upper x = (point lower < x) × (x < point upper)

  overlap-point : (l₁ u₁ l₂ u₂ : Q)
    → point l₁ < point u₁ → point l₂ < point u₁ → point u₁ < point u₂
    → Σ[ x ∈ X ] (Within l₁ u₁ x × Within l₂ u₂ x)
  overlap-point l₁ u₁ l₂ u₂ l₁u₁ l₂u₁ u₁u₂ with endpoint-comparison l₁ l₂
  ... | yes lower = z , (<-trans lower left , right) , (left , <-trans right u₁u₂)
    where
    middle = dense l₂u₁
    z = middle .fst
    left = middle .snd .fst
    right = middle .snd .snd
  ... | no lower = z , (left , right) ,
    (≤<-trans (notLess→reverseWeak lower) left , <-trans right u₁u₂)
    where
    middle = dense l₁u₁
    z = middle .fst
    left = middle .snd .fst
    right = middle .snd .snd

  finite-interval-constancy : (n : ℕ) (lower upper : Fin n → Q)
    (Selected : Fin n → Type ℓp)
    → ((i : Fin n) → Selected i → (x y : X)
        → Within (lower i) (upper i) x → Within (lower i) (upper i) y → f x ≡ f y)
    → (a b : Q) → point a ≤ point b
    → ((z : Q) → point a ≤ point z → point z ≤ point b
        → PT.∥ Σ[ i ∈ Fin n ] (Selected i × Within (lower i) (upper i) (point z)) ∥₁)
    → f (point a) ≡ f (point b)
  finite-interval-constancy zero lower upper Selected constant a b ab cover =
    PT.rec (setY _ _) (λ ()) (cover a (≤-refl (point a)) ab)
  finite-interval-constancy (suc n) lower upper Selected constant a b ab cover =
    PT.rec (setY _ _) start (cover a (≤-refl (point a)) ab)
    where
    start : (Σ[ i ∈ Fin (suc n) ]
      (Selected i × Within (lower i) (upper i) (point a))) → f (point a) ≡ f (point b)
    start (i , selected , contains-a) with endpoint-comparison b (upper i)
    ... | yes below = constant i selected (point a) (point b) contains-a
      (<≤-trans (contains-a .fst) ab , below)
    ... | no below = PT.rec (setY _ _) cross
      (cover (upper i) (<-weaken (contains-a .snd)) upper≤b)
      where
      upper≤b : point (upper i) ≤ point b
      upper≤b = notLess→reverseWeak below

      remaining-cover : (z : Q) → point (upper i) ≤ point z → point z ≤ point b
        → PT.∥ Σ[ k ∈ Fin n ]
          (Selected (skip i k) × Within (lower (skip i k)) (upper (skip i k)) (point z)) ∥₁
      remaining-cover z uz zb = PT.rec PT.squash₁ choose
        (cover z (≤-trans (<-weaken (contains-a .snd)) uz) zb)
        where
        choose : (Σ[ j ∈ Fin (suc n) ]
          (Selected j × Within (lower j) (upper j) (point z)))
          → PT.∥ Σ[ k ∈ Fin n ]
            (Selected (skip i k) × Within (lower (skip i k)) (upper (skip i k)) (point z)) ∥₁
        choose (j , chosen , member) with split-skip i j
        ... | inl equal = Empty.rec
          (incompatible (subst (λ h → point z < point (upper h)) equal (member .snd)) uz)
        ... | inr (k , equal) = PT.∣ k , subst
          (λ h → Selected h × Within (lower h) (upper h) (point z))
          (sym equal) (chosen , member) ∣₁

      cross : (Σ[ j ∈ Fin (suc n) ]
        (Selected j × Within (lower j) (upper j) (point (upper i))))
        → f (point a) ≡ f (point b)
      cross (j , chosen , member) =
        constant i selected (point a) middle contains-a (common .snd .fst)
        ∙ constant j chosen middle (point (upper i)) (common .snd .snd) member
        ∙ finite-interval-constancy n (lower ∘ skip i) (upper ∘ skip i)
          (Selected ∘ skip i) (constant ∘ skip i) (upper i) b upper≤b remaining-cover
        where
        common = overlap-point (lower i) (upper i) (lower j) (upper j)
          (<-trans (contains-a .fst) (contains-a .snd)) (member .fst) (member .snd)
        middle = common .fst
