{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportSums where

-- Actual finite sums for the finite-support representation. The list
-- evaluator erases a coordinate after visiting it, so duplicate indices
-- do not count twice. A sum is obtained from its unique-value predicate
-- by explicit propositional DNE; no support list is selected from NN.

open import Agda.Primitive using (Level; Set; lsuc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Not; empty-elim; PropositionalDNE )
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; here; there; inl; inr )
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( _++_; member-append-left; member-append-right; nn-unit; nn-map; nn-map₂
  ; SupportBound; SupportWitness; Supported; FiniteSupport
  ; finite-support-path; finite-support-isSet; zero-support )

private variable ℓ : Level

cong₂ : {A B C : Set ℓ} (f : A → B → C)
  → {a a' : A} {b b' : B} → a ≡ a' → b ≡ b' → f a b ≡ f a' b'
cong₂ f refl refl = refl

record AdditiveMonoid (ℓ : Level) : Set (lsuc ℓ) where
  field
    Carrier : Set ℓ
    carrier-set : isSet Carrier
    zero : Carrier
    _+_ : Carrier → Carrier → Carrier
    +-assoc : (a b c : Carrier) → (a + b) + c ≡ a + (b + c)
    +-comm : (a b : Carrier) → a + b ≡ b + a
    +-zero-left : (a : Carrier) → zero + a ≡ a
    +-zero-right : (a : Carrier) → a + zero ≡ a

module Sums {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) (M : AdditiveMonoid ℓ) where

  open AdditiveMonoid M renaming (Carrier to N; carrier-set to setN; zero to z; _+_ to _⊕_)

  +-exchange : (a b c : N) → a ⊕ (b ⊕ c) ≡ b ⊕ (a ⊕ c)
  +-exchange a b c = sym (+-assoc a b c)
    ∙ cong (λ x → x ⊕ c) (+-comm a b) ∙ +-assoc b a c

  +-interchange : (a b c d : N) → (a ⊕ b) ⊕ (c ⊕ d) ≡ (a ⊕ c) ⊕ (b ⊕ d)
  +-interchange a b c d = +-assoc a b (c ⊕ d)
    ∙ cong (λ x → a ⊕ x) (+-exchange b c d) ∙ sym (+-assoc a c (b ⊕ d))

  erase : I → (I → N) → I → N
  erase a f i with equality i a
  ... | inl equal = z
  ... | inr different = f i

  erase-at : (a : I) (f : I → N) → erase a f a ≡ z
  erase-at a f with equality a a
  ... | inl equal = refl
  ... | inr different = empty-elim (different refl)

  erase-away : (a : I) (f : I → N) (i : I) → Not (i ≡ a) → erase a f i ≡ f i
  erase-away a f i different with equality i a
  ... | inl equal = empty-elim (different equal)
  ... | inr other = refl

  erase-equal : (a : I) (f : I → N) (i : I) → i ≡ a → erase a f i ≡ z
  erase-equal a f i equal = cong (erase a f) equal ∙ erase-at a f

  erase-cong : (a : I) (f g : I → N)
    → ((i : I) → f i ≡ g i) → (i : I) → erase a f i ≡ erase a g i
  erase-cong a f g same i with equality i a
  ... | inl equal = refl
  ... | inr different = same i

  erase-zero : (a : I) (f : I → N)
    → ((i : I) → f i ≡ z) → (i : I) → erase a f i ≡ z
  erase-zero a f all-zero i with equality i a
  ... | inl equal = refl
  ... | inr different = all-zero i

  erase-idempotent : (a : I) (f : I → N) (i : I)
    → erase a (erase a f) i ≡ erase a f i
  erase-idempotent a f i with equality i a
  ... | inl equal = refl
  ... | inr different = erase-away a f i different

  erase-commute : (a b : I) (f : I → N) (i : I)
    → erase a (erase b f) i ≡ erase b (erase a f) i
  erase-commute a b f i with equality i a | equality i b
  ... | inl first | inl second = refl
  ... | inl first | inr second = sym (erase-equal a f i first)
  ... | inr first | inl second = erase-equal b f i second
  ... | inr first | inr second = erase-away b f i second ∙ sym (erase-away a f i first)

  list-sum : List I → (I → N) → N
  list-sum [] f = z
  list-sum (a ∷ xs) f = f a ⊕ list-sum xs (erase a f)

  list-sum-cong : (xs : List I) (f g : I → N)
    → ((i : I) → f i ≡ g i) → list-sum xs f ≡ list-sum xs g
  list-sum-cong [] f g same = refl
  list-sum-cong (a ∷ xs) f g same = cong₂ _⊕_ (same a)
    (list-sum-cong xs (erase a f) (erase a g) (erase-cong a f g same))

  list-sum-zero : (xs : List I) (f : I → N)
    → ((i : I) → f i ≡ z) → list-sum xs f ≡ z
  list-sum-zero [] f all-zero = refl
  list-sum-zero (a ∷ xs) f all-zero =
    cong₂ _⊕_ (all-zero a) (list-sum-zero xs (erase a f) (erase-zero a f all-zero))
      ∙ +-zero-left z

  support-tail : (a : I) (f : I → N) (xs : List I)
    → SupportBound z f (a ∷ xs) → SupportBound z (erase a f) xs
  support-tail a f xs bound i absent with equality i a
  ... | inl equal = refl
  ... | inr different = bound i λ
    { (here equal) → different (sym equal)
    ; (there present) → absent present
    }

  support-erased : (a : I) (f : I → N) (xs : List I)
    → SupportBound z f xs → SupportBound z (erase a f) xs
  support-erased a f xs bound i absent with equality i a
  ... | inl equal = refl
  ... | inr different = bound i absent

  -- Every supported coordinate can be extracted, whether or not its
  -- index occurs in the supplied list: an absent coordinate is zero.
  list-sum-extract : (xs : List I) (f : I → N) (a : I)
    → SupportBound z f xs → list-sum xs f ≡ f a ⊕ list-sum xs (erase a f)
  list-sum-extract [] f a bound = sym (+-zero-right (f a) ∙ bound a (λ ()))
  list-sum-extract (b ∷ xs) f a bound with equality b a
  ... | inl refl = cong (λ q → f b ⊕ q) (sym
    (cong₂ _⊕_ refl
      (list-sum-cong xs (erase b (erase b f)) (erase b f) (erase-idempotent b f))
      ∙ +-zero-left (list-sum xs (erase b f))))
  ... | inr different =
    cong (λ q → f b ⊕ q)
      (list-sum-extract xs (erase b f) a (support-tail b f xs bound))
    ∙ cong (λ q → f b ⊕ q)
      (cong₂ _⊕_ (erase-away b f a (λ equal → different (sym equal)))
        (list-sum-cong xs (erase a (erase b f)) (erase b (erase a f))
          (erase-commute a b f)))
    ∙ +-exchange (f b) (f a) (list-sum xs (erase b (erase a f)))

  list-sum-independent : (xs ys : List I) (f : I → N)
    → SupportBound z f xs → SupportBound z f ys → list-sum xs f ≡ list-sum ys f
  list-sum-independent [] ys f bound-xs bound-ys =
    sym (list-sum-zero ys f (λ i → bound-xs i (λ ())))
  list-sum-independent (a ∷ xs) ys f bound-xs bound-ys =
    cong (λ q → f a ⊕ q)
      (list-sum-independent xs ys (erase a f)
        (support-tail a f xs bound-xs) (support-erased a f ys bound-ys))
      ∙ sym (list-sum-extract ys f a bound-ys)

  SumProperty : (I → N) → N → Set ℓ
  SumProperty f n = (xs : List I) → SupportBound z f xs → list-sum xs f ≡ n

  sum-property-prop : (f : I → N) (n : N) → isProp (SumProperty f n)
  sum-property-prop f n = isPropΠ ext (λ xs → isPropΠ ext (λ bound → setN _ n))

  SumValue : (I → N) → Set ℓ
  SumValue f = Σ N (SumProperty f)

  sum-value-prop : (f : I → N) → Supported z f → isProp (SumValue f)
  sum-value-prop f supported first second = Σ-path-prop (sum-property-prop f)
    (classical (setN (fst first) (fst second))
      (nn-map (λ { (xs , bound) → sym (snd first xs bound) ∙ snd second xs bound }) supported))

  candidate-sum : (f : I → N) → SupportWitness z f → SumValue f
  candidate-sum f (xs , bound) = list-sum xs f ,
    (λ ys other → list-sum-independent ys xs f other bound)

  -- The public equations are the computation interface. Downstream
  -- unification must not expand the proof of uniqueness passed to DNE.
  abstract
    sum-value : (w : FiniteSupport I z) → SumValue (fst w)
    sum-value w = classical (sum-value-prop (fst w) (snd w))
      (nn-map (candidate-sum (fst w)) (snd w))

    Sum : FiniteSupport I z → N
    Sum w = fst (sum-value w)

    sum-on-bound : (w : FiniteSupport I z) (xs : List I)
      → SupportBound z (fst w) xs → Sum w ≡ list-sum xs (fst w)
    sum-on-bound w xs bound = sym (snd (sum-value w) xs bound)

    sum-zero : Sum (zero-support z) ≡ z
    sum-zero = sum-on-bound (zero-support z) [] (λ i absent → refl)

  add-support : (f g : I → N)
    → SupportWitness z f → SupportWitness z g
    → SupportWitness z (λ i → f i ⊕ g i)
  add-support f g (xs , bound-f) (ys , bound-g) = xs ++ ys ,
    (λ i absent → cong₂ _⊕_
      (bound-f i (λ present → absent (member-append-left present)))
      (bound-g i (λ present → absent (member-append-right xs present))) ∙ +-zero-left z)

  add : FiniteSupport I z → FiniteSupport I z → FiniteSupport I z
  add u v = (λ i → fst u i ⊕ fst v i) ,
    nn-map₂ (add-support (fst u) (fst v)) (snd u) (snd v)

  erase-add : (a : I) (f g : I → N) (i : I)
    → erase a (λ j → f j ⊕ g j) i ≡ erase a f i ⊕ erase a g i
  erase-add a f g i with equality i a
  ... | inl equal = sym (+-zero-left z)
  ... | inr different = refl

  list-sum-add : (xs : List I) (f g : I → N)
    → list-sum xs (λ i → f i ⊕ g i) ≡ list-sum xs f ⊕ list-sum xs g
  list-sum-add [] f g = sym (+-zero-left z)
  list-sum-add (a ∷ xs) f g =
    cong (λ q → (f a ⊕ g a) ⊕ q)
      (list-sum-cong xs (erase a (λ i → f i ⊕ g i))
        (λ i → erase a f i ⊕ erase a g i) (erase-add a f g)
        ∙ list-sum-add xs (erase a f) (erase a g))
    ∙ +-interchange (f a) (g a) (list-sum xs (erase a f)) (list-sum xs (erase a g))

  sum-add : (u v : FiniteSupport I z) → Sum (add u v) ≡ Sum u ⊕ Sum v
  sum-add u v = classical (setN _ _)
    (nn-map₂ equation (snd u) (snd v))
    where
    equation : SupportWitness z (fst u) → SupportWitness z (fst v)
      → Sum (add u v) ≡ Sum u ⊕ Sum v
    equation (xs , bound-u) (ys , bound-v) =
      sum-on-bound (add u v) (xs ++ ys)
        (λ i absent → cong₂ _⊕_ (bound-U i absent) (bound-V i absent) ∙ +-zero-left z)
      ∙ list-sum-add (xs ++ ys) (fst u) (fst v)
      ∙ cong₂ _⊕_ (sym (sum-on-bound u (xs ++ ys) bound-U))
        (sym (sum-on-bound v (xs ++ ys) bound-V))
      where
      bound-U : SupportBound z (fst u) (xs ++ ys)
      bound-U i absent = bound-u i (λ present → absent (member-append-left present))
      bound-V : SupportBound z (fst v) (xs ++ ys)
      bound-V i absent = bound-v i (λ present → absent (member-append-right xs present))

  finite-support-monoid : AdditiveMonoid ℓ
  AdditiveMonoid.Carrier finite-support-monoid = FiniteSupport I z
  AdditiveMonoid.carrier-set finite-support-monoid = finite-support-isSet ext setN
  AdditiveMonoid.zero finite-support-monoid = zero-support z
  AdditiveMonoid._+_ finite-support-monoid = add
  AdditiveMonoid.+-assoc finite-support-monoid u v w =
    finite-support-path ext (ext (λ i → +-assoc (fst u i) (fst v i) (fst w i)))
  AdditiveMonoid.+-comm finite-support-monoid u v =
    finite-support-path ext (ext (λ i → +-comm (fst u i) (fst v i)))
  AdditiveMonoid.+-zero-left finite-support-monoid u =
    finite-support-path ext (ext (λ i → +-zero-left (fst u i)))
  AdditiveMonoid.+-zero-right finite-support-monoid u =
    finite-support-path ext (ext (λ i → +-zero-right (fst u i)))

  delta : I → N → I → N
  delta a v i with equality i a
  ... | inl equal = v
  ... | inr different = z

  delta-at : (a : I) (v : N) → delta a v a ≡ v
  delta-at a v with equality a a
  ... | inl equal = refl
  ... | inr different = empty-elim (different refl)

  delta-zero : (a i : I) → delta a z i ≡ z
  delta-zero a i with equality i a
  ... | inl equal = refl
  ... | inr different = refl

  delta-support : (a : I) (v : N) → SupportBound z (delta a v) (a ∷ [])
  delta-support a v i absent with equality i a
  ... | inl equal = empty-elim (absent (here (sym equal)))
  ... | inr different = refl

  single : I → N → FiniteSupport I z
  single a v = delta a v , nn-unit ((a ∷ []) , delta-support a v)

  single-zero : (a : I) → single a z ≡ zero-support z
  single-zero a = finite-support-path ext (ext (delta-zero a))

  delta-add : (a : I) (v w : N) (i : I)
    → delta a (v ⊕ w) i ≡ delta a v i ⊕ delta a w i
  delta-add a v w i with equality i a
  ... | inl equal = refl
  ... | inr different = sym (+-zero-left z)

  single-add : (a : I) (v w : N) → single a (v ⊕ w) ≡ add (single a v) (single a w)
  single-add a v w = finite-support-path ext (ext (delta-add a v w))

  sum-single : (a : I) (v : N) → Sum (single a v) ≡ v
  sum-single a v = sum-on-bound (single a v) (a ∷ []) (delta-support a v)
    ∙ cong (λ q → q ⊕ z) (delta-at a v) ∙ +-zero-right v

  erase-finite : I → FiniteSupport I z → FiniteSupport I z
  erase-finite a u = erase a (fst u) ,
    nn-map (λ { (xs , bound) → xs , support-erased a (fst u) xs bound }) (snd u)

  split-coordinate : (a : I) (f : I → N) (i : I)
    → f i ≡ delta a (f a) i ⊕ erase a f i
  split-coordinate a f i with equality i a
  ... | inl equal = cong f equal ∙ sym (+-zero-right (f a))
  ... | inr different = sym (+-zero-left (f i))

  split-finite : (a : I) (u : FiniteSupport I z)
    → u ≡ add (single a (fst u a)) (erase-finite a u)
  split-finite a u = finite-support-path ext (ext (split-coordinate a (fst u)))
