{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictInnerFunctionExtensionality where

-- An explicit additional rule of the ambient two-level model. This is
-- strict dependent function extensionality over ordinary inner types,
-- not Cubical funExt and not a theorem about diagrams or colimits.
-- Finite bar stages need it for their object-indexed vertices and for
-- the chain-indexed families of typed fillers at every successor.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched using (Outer; outer; _≡ˢ_)

record StrictFunctionExtensionality (ℓ : Level) : SSet (ℓ-suc ℓ) where
  field
    function-ext : {A : Type ℓ} {B : A → Type ℓ}
      {f g : (a : A) → B a}
      → ((a : A) → outer (f a) ≡ˢ outer (g a))
      → outer f ≡ˢ outer g
