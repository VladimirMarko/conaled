{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.OuterBarCuts where

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; map-cube; coordinate-face; StrictCubicalExtensionality)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes

cutLength : (n : Dim) → Position (osuc n) → Dim
cutLength n pzero = n
cutLength (osuc n) (psuc p) = cutLength n p

-- A coordinate before the final vertex remains a coordinate after adding
-- one later vertex. The corresponding retained prefix becomes one longer.
cutLength-weaken : (n : Dim) (p : Position (osuc n))
  → cutLength (osuc n) (weaken p) ≡ˢ osuc (cutLength n p)
cutLength-weaken n pzero = reflˢ
cutLength-weaken (osuc n) (psuc p) = cutLength-weaken n p

-- An earlier coordinate, viewed within the prefix retained by the cut.
residual : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
  → Position (osuc (cutLength n p))
residual n pzero q pzero≤ = q
residual (osuc n) (psuc p) (psuc q) (psuc≤ le) = residual n p q le

residual-cutLength : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → cutLength (cutLength n p) (residual n p q le) ≡ˢ cutLength n q
residual-cutLength n pzero q pzero≤ = reflˢ
residual-cutLength (osuc n) (psuc p) (psuc q) (psuc≤ le) = residual-cutLength n p q le

module Cuts {ℓo ℓh : Level} (C : Category ℓo ℓh) where
  open Category C
  open Chains C

  -- A cut retains the initial chain and composes its entire final suffix.
  extend-suffix : (n : Dim) {x y : Obj} → Hom x y
    → Chain (osuc n) x → Chain (osuc n) y
  extend-suffix n f c = last-source n c , compose f (last-arrow n c) , prefix n c

  cut : (n : Dim) (p : Position (osuc n)) {y : Obj}
    → Chain (osuc n) y → Chain (osuc (cutLength n p)) y
  cut n pzero c = c
  cut (osuc n) (psuc p) c = extend-suffix (cutLength n p)
    (last-arrow (osuc n) c) (cut n p (prefix (osuc n) c))

  cut-vertex : (n : Dim) (p : Position (osuc n)) {y : Obj}
    → Chain (osuc n) y → Obj
  cut-vertex n p c = last-source (cutLength n p) (cut n p c)

  cut-prefix : (n : Dim) (p : Position (osuc n)) {y : Obj}
    (c : Chain (osuc n) y) → Chain (cutLength n p) (cut-vertex n p c)
  cut-prefix n p c = prefix (cutLength n p) (cut n p c)

  cut-suffix : (n : Dim) (p : Position (osuc n)) {y : Obj}
    (c : Chain (osuc n) y) → Hom (cut-vertex n p c) y
  cut-suffix n p c = last-arrow (cutLength n p) (cut n p c)

  extend-compose : (n : Dim) {x y z : Obj} (g : Hom y z) (f : Hom x y)
    (c : Chain (osuc n) x)
    → outer (extend-suffix n g (extend-suffix n f c))
      ≡ˢ outer (extend-suffix n (compose g f) c)
  extend-compose n g f c = strict-cong
    (λ q → outer (append n (inner q) (prefix n c)))
    (assoc g f (last-arrow n c))

  extend-face : (n : Dim) (p : Position (osuc (osuc n))) {x y : Obj}
    (g : Hom x y) (c : Chain (osuc (osuc n)) x)
    → outer (face (osuc n) p (extend-suffix (osuc n) g c))
      ≡ˢ outer (extend-suffix n g (face (osuc n) p c))
  extend-face n pzero g c = strict-cong
    (λ q → outer (append n (inner q) (prefix n (prefix (osuc n) c))))
    (strict-sym (assoc g (last-arrow (osuc n) c) (last-arrow n (prefix (osuc n) c))))
  extend-face n (psuc p) g c = reflˢ

  -- If a removed vertex lies later than the cut, only the composite
  -- suffix changes its parenthesization; this equality keeps all prefix data.
  cut-face-suffix : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (cut n q (face (osuc n) (weaken p) c))
      ≡ˢ outer (cut (osuc n) (psuc q) c)
  cut-face-suffix n pzero pzero pzero≤ c = reflˢ
  cut-face-suffix (osuc n) pzero (psuc q) pzero≤ c = strict-sym
    (extend-compose (cutLength n q)
      (last-arrow (osuc (osuc n)) c)
      (last-arrow (osuc n) (prefix (osuc (osuc n)) c))
      (cut n q (prefix (osuc n) (prefix (osuc (osuc n)) c))))
  cut-face-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-cong
    (λ z → outer (extend-suffix (cutLength n q)
      (last-arrow (osuc (osuc n)) c) (inner z)))
    (cut-face-suffix n p q le (prefix (osuc (osuc n)) c))

  cast-snoc : {m n : Dim} {y : Obj} → m ≡ˢ n
    → Chain (osuc m) y → Chain (osuc n) y
  cast-snoc reflˢ c = c

  cast-extend : {m n : Dim} (e : m ≡ˢ n) {x y : Obj}
    (g : Hom x y) (c : Chain (osuc m) x)
    → outer (cast-snoc e (extend-suffix m g c))
      ≡ˢ outer (extend-suffix n g (cast-snoc e c))
  cast-extend reflˢ g c = reflˢ

  -- If the removed vertex lies earlier than the cut, it is removed in
  -- the retained prefix. This is the other mixed zero/one face identity.
  cut-face-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (cut n p (face (osuc n) (psuc q) c))
      ≡ˢ outer (face (osuc (cutLength n p)) (psuc (residual n p q le))
        (cast-snoc (cutLength-weaken n p) (cut (osuc n) (weaken p) c)))
  cut-face-prefix n pzero q pzero≤ c = reflˢ
  cut-face-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer (extend-suffix (cutLength n p) (last-arrow (osuc (osuc n)) c) (inner z)))
      (cut-face-prefix n p q le (prefix (osuc (osuc n)) c)))
    (strict-sym (strict-cong
      (λ z → outer (face (osuc (cutLength n p)) (psuc (residual n p q le)) (inner z)))
      (cast-extend (cutLength-weaken n p) (last-arrow (osuc (osuc n)) c)
        (cut (osuc n) (weaken p) (prefix (osuc (osuc n)) c)))))

  cut-extend : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (g : Hom x y) (c : Chain (osuc n) x)
    → outer (cut n p (extend-suffix n g c))
      ≡ˢ outer (extend-suffix (cutLength n p) g (cut n p c))
  cut-extend n pzero g c = reflˢ
  cut-extend (osuc n) (psuc p) g c = strict-sym
    (extend-compose (cutLength n p) g (last-arrow (osuc n) c)
      (cut n p (prefix (osuc n) c)))

  -- Cutting the retained prefix composes the two suffix maps and gives
  -- the same complete cut as cutting the original chain once.
  cut-cut : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (cast-snoc (residual-cutLength n p q le)
        (cut (osuc (cutLength n p)) (psuc (residual n p q le))
          (cast-snoc (cutLength-weaken n p) (cut (osuc n) (weaken p) c))))
      ≡ˢ outer (cut (osuc n) (psuc q) c)
  cut-cut n pzero q pzero≤ c = reflˢ
  cut-cut (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer (cast-snoc e₂ (cut (osuc k) (psuc r) (inner z))))
      (cast-extend e₁ g z))
    (strict-trans
      (strict-cong (λ z → outer (cast-snoc e₂ (inner z)))
        (cut-extend (osuc k) (psuc r) g (cast-snoc e₁ z)))
      (strict-trans
        (cast-extend e₂ g (cut (osuc k) (psuc r) (cast-snoc e₁ z)))
        (strict-cong
          (λ z → outer (extend-suffix (cutLength n q) g (inner z)))
          (cut-cut n p q le (prefix (osuc (osuc n)) c)))))
    where
    k = cutLength n p
    r = residual n p q le
    e₁ = cutLength-weaken n p
    e₂ = residual-cutLength n p q le
    g = last-arrow (osuc (osuc n)) c
    z = cut (osuc n) (weaken p) (prefix (osuc (osuc n)) c)

-- Coordinates after the cut do not affect the prefix cube. In reverse
-- vertex order they occur first, so the operation inserts constant coordinates.
inflate-cut : ∀ {ℓ} (n : Dim) (p : Position (osuc n)) {X : Type ℓ}
  → Cube (cutLength n p) X → Cube n X
inflate-cut n pzero c = c
inflate-cut (osuc n) (psuc p) c i = inflate-cut n p c

cast-cube : ∀ {ℓ} {m n : Dim} {X : Type ℓ} → m ≡ˢ n → Cube m X → Cube n X
cast-cube reflˢ c = c

cast-cube-map : ∀ {ℓ ℓ'} {m n : Dim} (e : m ≡ˢ n)
  {X : Type ℓ} {Y : Type ℓ'} (f : X → Y) (c : Cube m X)
  → outer (cast-cube e (map-cube m f c))
    ≡ˢ outer (map-cube n f (cast-cube e c))
cast-cube-map reflˢ f c = reflˢ

module Inflation {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  -- Every coordinate later than the cut is ignored by the inflated cube.
  inflate-face-later : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
    → (i : I) {X : Type ℓ} (c : Cube (cutLength n q) X)
    → outer (coordinate-face n p i (inflate-cut (osuc n) (psuc q) c))
      ≡ˢ outer (inflate-cut n q c)
  inflate-face-later n pzero q pzero≤ i c = reflˢ
  inflate-face-later (osuc n) (psuc p) (psuc q) (psuc≤ le) i c = interval-ext
    (λ j → inflate-face-later n p q le i c)

  inflate-map : ∀ {ℓx} (n : Dim) (p : Position (osuc n)) {X : Type ℓx} {Y : Type ℓ}
    (f : X → Y) (c : Cube (cutLength n p) X)
    → outer (map-cube n f (inflate-cut n p c))
      ≡ˢ outer (inflate-cut n p (map-cube (cutLength n p) f c))
  inflate-map n pzero f c = reflˢ
  inflate-map (osuc n) (psuc p) f c = interval-ext (λ i → inflate-map n p f c)

  -- Restricting an earlier coordinate restricts the retained prefix cube.
  inflate-face-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    → (i : I) {X : Type ℓ} (c : Cube (cutLength (osuc n) (weaken p)) X)
    → outer (coordinate-face n q i (inflate-cut (osuc n) (weaken p) c))
      ≡ˢ outer (inflate-cut n p
        (coordinate-face (cutLength n p) (residual n p q le) i
          (cast-cube (cutLength-weaken n p) c)))
  inflate-face-prefix n pzero q pzero≤ i c = reflˢ
  inflate-face-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) i c = interval-ext
    (λ j → inflate-face-prefix n p q le i c)

  -- Inflating through two nested prefixes is the direct inflation.
  inflate-inflate : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    → {X : Type ℓ} (c : Cube (cutLength (cutLength n p) (residual n p q le)) X)
    → outer (inflate-cut n p (inflate-cut (cutLength n p) (residual n p q le) c))
      ≡ˢ outer (inflate-cut n q (cast-cube (residual-cutLength n p q le) c))
  inflate-inflate n pzero q pzero≤ c = reflˢ
  inflate-inflate (osuc n) (psuc p) (psuc q) (psuc≤ le) c = interval-ext
    (λ i → inflate-inflate n p q le c)

module DiagramCuts {ℓo ℓh ℓ : Level} {C : Category ℓo ℓh}
    (D : Diagram C ℓ) where
  open Category C
  open Diagram D
  open Chains C
  open Cuts C

  -- The actual 1-face of the bar cone: act by the composite suffix on
  -- the already specified prefix cone, ignoring all later coordinates.
  one-face : (n : Dim) (p : Position (osuc n)) {y : Obj}
    (c : Chain (osuc n) y)
    → Cube (cutLength n p) (Value (cut-vertex n p c)) → Cube n (Value y)
  one-face n p c k = inflate-cut n p
    (map-cube (cutLength n p) (action (cut-suffix n p c)) k)

  recursive-one-face : (n : Dim) (p : Position (osuc n)) {y : Obj}
    (c : Chain (osuc n) y)
    → Cube (cutLength n p) (Value (cut-vertex n p c)) → Cube n (Value y)
  recursive-one-face n pzero c k = map-cube n (action (last-arrow n c)) k
  recursive-one-face (osuc n) (psuc p) c k i = map-cube n (action (last-arrow (osuc n) c))
    (recursive-one-face n p (prefix (osuc n) c) k)

  module Coherent (E : StrictCubicalExtensionality ℓ) where
    open StrictCubicalExtensionality E
    open Cubes.Extensional E
    open Inflation E

    recursive-is-composite : (n : Dim) (p : Position (osuc n)) {y : Obj}
      (c : Chain (osuc n) y)
      (k : Cube (cutLength n p) (Value (cut-vertex n p c)))
      → outer (recursive-one-face n p c k) ≡ˢ outer (one-face n p c k)
    recursive-is-composite n pzero c k = reflˢ
    recursive-is-composite (osuc n) (psuc p) c k = interval-ext λ i →
      strict-trans
        (strict-cong (λ z → outer (map-cube n (action g) (inner z)))
          (recursive-is-composite n p (prefix (osuc n) c) k))
        (strict-trans
          (inflate-map n p (action g) (map-cube (cutLength n p) (action f) k))
          (strict-cong (λ z → outer (inflate-cut n p (inner z)))
            (strict-trans
              (map-compose (cutLength n p) (action g) (action f) k)
              (strict-sym (strict-cong
                (λ z → outer (map-cube (cutLength n p) (inner z) k))
                (action-compose g f))))))
      where
      g = last-arrow (osuc n) c
      f = cut-suffix n p (prefix (osuc n) c)
