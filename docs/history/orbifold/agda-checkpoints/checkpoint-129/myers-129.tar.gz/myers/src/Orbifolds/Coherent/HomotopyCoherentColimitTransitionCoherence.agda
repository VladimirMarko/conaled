{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitTransitionCoherence where

-- The canonical finite representability triangle retains precisely the
-- transition homotopy used by the full inverse-tower universal property.
-- This is a statement about the constructed triangle, not merely a
-- second path between its endpoints.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictPathCoherence
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  module R = Represented.Induction C D E F
  module CD = Cocones.Functoriality C D E F
  module Step = Stages.Construction.Step C D E F n previous
  module Original = Canonical.Canonical E (osuc n) (R.Represented.Space previous)
    Step.Comparison.Index Step.Comparison.Coefficient Step.Comparison.original-boundary

  u : CD.Cocone (R.Represented.Space previous) n
  u = R.Represented.universal-cocone previous

  first-equality : (Y : Type ℓ) (h : Step.Realize → Y)
    → outer (CD.postcompose n h (CD.postcompose n (Step.cell-cocone .fst) u))
      ≡ˢ outer (CD.postcompose n (h ∘ Step.cell-cocone .fst) u)
  first-equality Y h = CD.postcompose-compose n (Step.cell-cocone .fst) h u

  second-equality : (Y : Type ℓ) (h : Step.Realize → Y)
    → outer (CD.postcompose n (h ∘ Step.cell-cocone .fst) u)
      ≡ˢ outer (CD.postcompose n (h ∘ Step.Cell.include) u)
  second-equality Y h = strict-cong
    (λ f → outer (CD.postcompose n (h ∘ inner f) u)) Step.cell-original-computation

  first-prefix : (Y : Type ℓ) (h : Step.Realize → Y)
    → cong fst (Step.canonical-first Y h) ≡ strict-to-path (first-equality Y h)
  first-prefix Y h = strict-path-congruence fst
    (Step.Comparison.compare-natural {Y = Step.Realize} {Z = Y} h Step.cell-cocone)
    (first-equality Y h)

  second-prefix : (Y : Type ℓ) (h : Step.Realize → Y)
    → cong fst (Step.canonical-second Y h) ≡ strict-to-path (second-equality Y h)
  second-prefix Y h =
    cong (cong (λ k → CD.postcompose n k u)) (Original.natural-original h)
    ∙ strict-path-congruence (λ k → CD.postcompose n k u)
      (strict-cong (λ k → outer (h ∘ inner k)) Step.cell-original-computation)
      (second-equality Y h)

  canonical-transition-coherence : (Y : Type ℓ) (h : Step.Realize → Y)
    → cong fst (Step.canonical-restriction-comparison Y h)
      ≡ strict-to-path (Step.transition-computation Y h)
  canonical-transition-coherence Y h =
    cong-∙ fst (Step.canonical-first Y h) (Step.canonical-second Y h)
    ∙ cong₂ _∙_ (first-prefix Y h) (second-prefix Y h)
    ∙ strict-path-composite (first-equality Y h) (second-equality Y h)
