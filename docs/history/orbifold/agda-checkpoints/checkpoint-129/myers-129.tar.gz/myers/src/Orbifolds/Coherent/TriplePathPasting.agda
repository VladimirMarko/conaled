{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TriplePathPasting where

-- Seal path composition and its complete projected-path law before a
-- large carrier is substituted. Every field is derived here; consumers
-- provide only the actual three composable paths and the projection.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.GroupoidLaws using (cong-∙)
open import Orbifolds.Coherent.StrictEnriched using (outer; _≡ˢ_; reflˢ)

module Pasting {ℓ ℓ′ : Level} (A : Type ℓ) (B : Type ℓ′)
    (f : A → B) (x y z w : A)
    (p : x ≡ y) (q : y ≡ z) (r : z ≡ w) where
  abstract
    value : x ≡ w
    value = p ∙ (q ∙ r)

    constructed : outer value ≡ˢ outer (p ∙ (q ∙ r))
    constructed = reflˢ

    prefix : cong f value ≡ cong f p ∙ (cong f q ∙ cong f r)
    prefix = cong-∙ f p (q ∙ r)
      ∙ cong₂ _∙_ refl (cong-∙ f q r)
