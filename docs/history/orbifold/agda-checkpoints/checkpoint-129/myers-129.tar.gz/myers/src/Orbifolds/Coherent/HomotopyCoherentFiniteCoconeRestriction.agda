{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction where

-- A small explicitly typed interface to the actual finite restriction.
-- It imports no full cone map, infinite witness, or colimit presentation.
-- Its displayed domains are the canonical finite cocone carriers.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc; toNat; module Chains)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentMappingContravariance as Coefficients
import Orbifolds.Coherent.HomotopyCoherentFiniteTransformations as FiniteMaps
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.CubicalShells as CS

module Restriction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  open Category C
  open Chains (Opposite C)
  module H = HC.ForCategory C
  module D = H.Diagram D
  module G = H.Diagram G
  module Maps = Transformations.ForCategory C
  module α = Maps.Transformation α using (component)
  module DM = Mapping.Mapping C D E F using (Into)
  module GM = Mapping.Mapping C G E F using (Into)
  module Coeff = Coefficients.Contravariance C D G α E F using (Precompose)
  module CD = Cocones.Functoriality C D E F using (Cocone; top)
  module CG = Cocones.Functoriality C G E F using (Cocone; top)

  finite-restriction : (Y : Type ℓ) (n : Dim) → CG.Cocone Y n → CD.Cocone Y n
  finite-restriction Y n = FiniteMaps.Action.stage-map
    (GM.Into Y) (DM.Into Y) (Coeff.Precompose Y) E n

  Cells : Dim → Type ℓ
  Cells n = Σ Obj (Chain (osuc n))

  source-boundary : (Y : Type ℓ) (n : Dim) → CG.Cocone Y n → (c : Cells n)
    → CS.Shell (toNat (osuc n)) (G.Value (c .fst) → Y)
  source-boundary Y n = Finite.Finite.At.boundary-data (Opposite C) (GM.Into Y) E n

  target-boundary : (Y : Type ℓ) (n : Dim) → CD.Cocone Y n → (c : Cells n)
    → CS.Shell (toNat (osuc n)) (D.Value (c .fst) → Y)
  target-boundary Y n = Finite.Finite.At.boundary-data (Opposite C) (DM.Into Y) E n

  source-boundary-natural : (Y : Type ℓ) (n : Dim) (s : CG.Cocone Y n) (c : Cells n)
    → outer (Shells.Action.map-shell E (osuc n) (λ h → h ∘ α.component (c .fst))
        (source-boundary Y n s c))
      ≡ˢ outer (target-boundary Y n (finite-restriction Y n s) c)
  source-boundary-natural Y n s c = FiniteMaps.Action.stage-boundary-natural
    (GM.Into Y) (DM.Into Y) (Coeff.Precompose Y) E n s (c .fst) (c .snd)

  raw-cube-natural : (Y : Type ℓ) (n : Dim) (s : CG.Cocone Y n) (y : Obj) (c : Chain n y)
    → outer (map-cube n (λ h → h ∘ α.component y) (CG.top Y n s y c))
      ≡ˢ outer (CD.top Y n (finite-restriction Y n s) y c)
  raw-cube-natural Y n = FiniteMaps.Action.stage-top-natural
    (GM.Into Y) (DM.Into Y) (Coeff.Precompose Y) E n

  transition-natural : (Y : Type ℓ) (n : Dim) (s : CG.Cocone Y (osuc n))
    → outer (finite-restriction Y (osuc n) s .fst)
      ≡ˢ outer (finite-restriction Y n (s .fst))
  transition-natural Y n s = reflˢ
