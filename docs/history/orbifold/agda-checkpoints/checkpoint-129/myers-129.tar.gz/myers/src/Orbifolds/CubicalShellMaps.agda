{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalShellMaps where

-- The explicit action of a function on a complete shell, transported
-- through the proved sphere representation. Evaluation and restriction
-- naturality are proved from the actual maps and their inverse laws.
-- No judgmental identification with another facewise implementation is
-- claimed: a client using one must prove that comparison.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.CubicalShells using (Cube; Shell; restriction; origin; constant-cube)
import Orbifolds.CubicalShellSpheres as SS

map-cube : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  → (X → Y) → Cube n X → Cube n Y
map-cube zero f c = f c
map-cube (suc n) f c i = map-cube n f (c i)

map-cube-origin : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) (c : Cube n X) → origin n (map-cube n f c) ≡ f (origin n c)
map-cube-origin zero f c = refl
map-cube-origin (suc n) f c = map-cube-origin n f (c i0)

map-cube-constant : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) (x : X) → map-cube n f (constant-cube n x) ≡ constant-cube n (f x)
map-cube-constant zero f x = refl
map-cube-constant (suc n) f x j i = map-cube-constant n f x j

map-shell : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  → (X → Y) → Shell n X → Shell n Y
map-shell n {Y = Y} f b = invEq (SS.shell-equivalence n Y) (f ∘ SS.evaluate-shell n b)

evaluate-natural : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) (b : Shell n X)
  → SS.evaluate-shell n (map-shell n f b) ≡ f ∘ SS.evaluate-shell n b
evaluate-natural n {Y = Y} f b = secEq (SS.shell-equivalence n Y) (f ∘ SS.evaluate-shell n b)

evaluate-point : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) (b : Shell n X) (s : SS.SphereBoundary n)
  → SS.evaluate-shell n (map-shell n f b) s ≡ f (SS.evaluate-shell n b s)
evaluate-point n f b s = funExt⁻ (evaluate-natural n f b) s

restriction-natural : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) (c : Cube n X)
  → map-shell n f (restriction n c) ≡ restriction n (map-cube n f c)
restriction-natural n {X = X} {Y = Y} f c =
  cong (invEq (SS.shell-equivalence n Y))
    (cong (f ∘_) (SS.restriction-computation n X c)
      ∙ cong (λ y (_ : SS.SphereBoundary n) → y) (sym (map-cube-origin n f c))
      ∙ sym (SS.restriction-computation n Y (map-cube n f c)))
  ∙ retEq (SS.shell-equivalence n Y) (restriction n (map-cube n f c))

map-shell-id : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → map-shell n (idfun X) b ≡ b
map-shell-id n {X} b = retEq (SS.shell-equivalence n X) b

map-shell-compose : ∀ {ℓx ℓy ℓz} (n : ℕ)
  {X : Type ℓx} {Y : Type ℓy} {Z : Type ℓz}
  (f : X → Y) (g : Y → Z) (b : Shell n X)
  → map-shell n g (map-shell n f b) ≡ map-shell n (g ∘ f) b
map-shell-compose n {Z = Z} f g b = cong
  (λ v → invEq (SS.shell-equivalence n Z) (g ∘ v))
  (evaluate-natural n f b)

shell-map-equivalence : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (e : X ≃ Y) → Shell n X ≃ Shell n Y
shell-map-equivalence n {X} {Y} e = SS.shell-equivalence n X ∙ₑ
  postCompEquiv e ∙ₑ invEquiv (SS.shell-equivalence n Y)

map-shell-isEquiv : ∀ {ℓx ℓy} (n : ℕ) {X : Type ℓx} {Y : Type ℓy}
  (f : X → Y) → isEquiv f → isEquiv (map-shell n f)
map-shell-isEquiv n f equivalent = shell-map-equivalence n (f , equivalent) .snd
