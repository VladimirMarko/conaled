{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictEnriched where

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude

record Outer {ℓ} (A : Type ℓ) : SSet ℓ where
  constructor outer
  field inner : A
open Outer public

infix 4 _≡ˢ_
data _≡ˢ_ {ℓ} {A : SSet ℓ} (x : A) : A → SSet ℓ where
  reflˢ : x ≡ˢ x

strict-cong : ∀ {ℓ ℓ'} {A : SSet ℓ} {B : SSet ℓ'}
  (f : A → B) {x y : A} → x ≡ˢ y → f x ≡ˢ f y
strict-cong f reflˢ = reflˢ

strict-to-path : ∀ {ℓ} {A : Type ℓ} {x y : A}
  → outer x ≡ˢ outer y → x ≡ y
strict-to-path reflˢ = refl

strict-sym : ∀ {ℓ} {A : SSet ℓ} {x y : A} → x ≡ˢ y → y ≡ˢ x
strict-sym reflˢ = reflˢ

strict-trans : ∀ {ℓ} {A : SSet ℓ} {x y z : A}
  → x ≡ˢ y → y ≡ˢ z → x ≡ˢ z
strict-trans reflˢ q = q

strict-uip : ∀ {ℓ} {A : SSet ℓ} {x y : A} (p q : x ≡ˢ y) → p ≡ˢ q
strict-uip reflˢ reflˢ = reflˢ

record Category (ℓo ℓh : Level) : SSet (ℓ-suc (ℓ-max ℓo ℓh)) where
  field
    Obj : Type ℓo
    Hom : Obj → Obj → Type ℓh
    ident : (x : Obj) → Hom x x
    compose : {x y z : Obj} → Hom y z → Hom x y → Hom x z
    assoc : {w x y z : Obj} (h : Hom y z) (g : Hom x y) (f : Hom w x)
      → outer (compose h (compose g f)) ≡ˢ outer (compose (compose h g) f)
    left : {x y : Obj} (f : Hom x y) → outer (compose (ident y) f) ≡ˢ outer f
    right : {x y : Obj} (f : Hom x y) → outer (compose f (ident x)) ≡ˢ outer f

record Diagram {ℓo ℓh : Level} (C : Category ℓo ℓh) (ℓ : Level)
  : SSet (ℓ-suc (ℓ-max ℓ (ℓ-max ℓo ℓh))) where
  open Category C
  field
    Value : Obj → Type ℓ
    action : {x y : Obj} → Hom x y → Value x → Value y
    action-compose : {x y z : Obj} (g : Hom y z) (f : Hom x y)
      → outer (action (compose g f)) ≡ˢ outer (λ v → action g (action f v))
    action-id : (x : Obj) → outer (action (ident x)) ≡ˢ outer (λ v → v)

  action-compose-point : {x y z : Obj} (g : Hom y z) (f : Hom x y) (v : Value x)
    → outer (action (compose g f) v) ≡ˢ outer (action g (action f v))
  action-compose-point g f v = strict-cong (λ q → outer (inner q v)) (action-compose g f)

  action-id-point : (x : Obj) (v : Value x)
    → outer (action (ident x) v) ≡ˢ outer v
  action-id-point x v = strict-cong (λ q → outer (inner q v)) (action-id x)

Types : (ℓ : Level) → Category (ℓ-suc ℓ) ℓ
Category.Obj (Types ℓ) = Type ℓ
Category.Hom (Types ℓ) A B = A → B
Category.ident (Types ℓ) A x = x
Category.compose (Types ℓ) g f x = g (f x)
Category.assoc (Types ℓ) h g f = reflˢ
Category.left (Types ℓ) f = reflˢ
Category.right (Types ℓ) f = reflˢ

Identity : (ℓ : Level) → Diagram (Types ℓ) ℓ
Diagram.Value (Identity ℓ) A = A
Diagram.action (Identity ℓ) f x = f x
Diagram.action-compose (Identity ℓ) g f = reflˢ
Diagram.action-id (Identity ℓ) A = reflˢ

module _ {ℓo ℓh ℓ ℓt : Level} {C : Category ℓo ℓh}
    (D : Diagram C ℓ) (T : Type ℓt) where
  open Category C
  open Diagram D

  Power : Diagram C (ℓ-max ℓt ℓ)
  Diagram.Value Power x = T → Value x
  Diagram.action Power f v t = action f (v t)
  Diagram.action-compose Power g f = strict-cong
    (λ q → outer (λ (v : T → Value _) t → inner q (v t)))
    (action-compose g f)
  Diagram.action-id Power x = strict-cong
    (λ q → outer (λ (v : T → Value x) t → inner q (v t)))
    (action-id x)
