{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteStages where

-- An outer finite-degree view of the already constructed inner bar
-- stages. This is derived by actual iteration of Step. Its comparison
-- with the ordinary-natural tower is strict, so no extra representation
-- or coherence assumption is introduced for finite-stage induction.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentConeData as BC
import Orbifolds.Coherent.HomotopyCoherentConeStages as Stages

module Finite {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) where
  module B = Stages.Construction C D E
  module Data = BC.Data C D

  record Stage (n : Dim) : SSet (ℓ-suc ℓ) where
    field
      Carrier : Type ℓ
      families : Data.Families n Carrier
      coherent : Data.Coherent n families

  initial : Stage ozero
  Stage.Carrier initial = B.Vertices
  Stage.families initial = B.initial-families
  Stage.coherent initial = B.initial-coherent

  extend : (n : Dim) → Stage n → Stage (osuc n)
  Stage.Carrier (extend n s) = B.Step.Next n (Stage.Carrier s)
    (Stage.families s) (Stage.coherent s)
  Stage.families (extend n s) = B.Step.next-families n (Stage.Carrier s)
    (Stage.families s) (Stage.coherent s)
  Stage.coherent (extend n s) = B.Step.next-coherent n (Stage.Carrier s)
    (Stage.families s) (Stage.coherent s)

  stage : (n : Dim) → Stage n
  stage ozero = initial
  stage (osuc n) = extend n (stage n)

  Carrier : Dim → Type ℓ
  Carrier n = Stage.Carrier (stage n)

  families : (n : Dim) → Data.Families n (Carrier n)
  families n = Stage.families (stage n)

  coherent : (n : Dim) → Data.Coherent n (families n)
  coherent n = Stage.coherent (stage n)

  finite-state : Dim → B.State
  finite-state n = Carrier n , B.bar-schedule n (Carrier n) (families n) (coherent n)

  state-strict : (n : Dim)
    → outer (finite-state n) ≡ˢ outer (B.state (toNat n))
  state-strict ozero = reflˢ
  state-strict (osuc n) = strict-cong (λ s → outer (B.advance (inner s)))
    (state-strict n)

  carrier-strict : (n : Dim)
    → outer (Carrier n) ≡ˢ outer (B.PartialCone (toNat n))
  carrier-strict n = strict-cong (λ s → outer (inner s .fst)) (state-strict n)

  carrier-path : (n : Dim) → Carrier n ≡ B.PartialCone (toNat n)
  carrier-path n = strict-to-path (carrier-strict n)

  transition : (n : Dim) → Carrier (osuc n) → Carrier n
  transition n = fst

  module At (n : Dim) where
    module Attachment = B.Step n (Carrier n) (families n) (coherent n)
    open Attachment using (Cells; dimension; target; Coefficient; boundary-data;
      filler; ExtensionCone; extension-universal; assemble-forget; assemble-filler) public

    carrier-is-actual-next : Carrier (osuc n) ≡ Attachment.Next
    carrier-is-actual-next = refl

    transition-is-forget : transition n ≡ Attachment.forget
    transition-is-forget = refl

    next-family-computation : families (osuc n) ≡ Attachment.next-families
    next-family-computation = refl

    next-coherence-computation : coherent (osuc n) ≡ˢ Attachment.next-coherent
    next-coherence-computation = reflˢ
