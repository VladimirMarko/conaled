{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalShells where

-- Inner cubical shells in every dimension. A successor shell consists
-- of its two opposite free cubes and a path between their complete
-- lower-dimensional boundaries. Thus corner and higher overlap data
-- are retained; no strict-equality subtype is used.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Unit using (Unit; tt)
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

Cube : ∀ {ℓ} → ℕ → Type ℓ → Type ℓ
Cube zero X = X
Cube (suc n) X = I → Cube n X

mutual
  Shell : ∀ {ℓ} → ℕ → Type ℓ → Type ℓ
  Shell {ℓ} zero X = Lift {j = ℓ} Unit
  Shell (suc n) X = Σ[ ends ∈ (Cube n X × Cube n X) ]
    (restriction n (ends .fst) ≡ restriction n (ends .snd))

  restriction : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Cube n X → Shell n X
  restriction zero x = lift tt
  restriction (suc n) c = (c i0 , c i1) , (λ i → restriction n (c i))

constant-cube : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → X → Cube n X
constant-cube zero x = x
constant-cube (suc n) x i = constant-cube n x

origin : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Cube n X → X
origin zero c = c
origin (suc n) c = origin n (c i0)

origin-constant : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (x : X)
  → origin n (constant-cube n x) ≡ x
origin-constant zero x = refl
origin-constant (suc n) x = origin-constant n x

contract-cube : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (c : Cube n X)
  → constant-cube n (origin n c) ≡ c
contract-cube zero c = refl
contract-cube (suc n) c j i = contract-cube n (c (i ∧ j)) j

cube-equivalence : ∀ {ℓ} (n : ℕ) (X : Type ℓ) → Cube n X ≃ X
cube-equivalence n X = isoToEquiv
  (iso (origin n) (constant-cube n) (origin-constant n) (contract-cube n))

shell-constant-homotopy : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (c : Cube n X)
  → restriction n (constant-cube n (origin n c)) ≡ restriction n c
shell-constant-homotopy n c = cong (restriction n) (contract-cube n c)

module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
    (test : Index → Micro.TestSquare ℓw) where
  module M = Micro.Theory test
  module Closure = ML.Limits test

  cube-microlinear : ∀ {ℓ} (n : ℕ) {X : Type ℓ}
    → M.Microlinear X → M.Microlinear (Cube n X)
  cube-microlinear n {X} micro = Closure.microlinear-equiv
    (invEquiv (cube-equivalence n X)) micro

  shell-microlinear : ∀ {ℓ} (n : ℕ) {X : Type ℓ}
    → M.Microlinear X → M.Microlinear (Shell n X)
  shell-microlinear zero {X} micro = Closure.microlinear-equiv
    (isoToEquiv (iso lift lower (λ _ → refl) (λ _ → refl)))
    Closure.microlinear-unit
  shell-microlinear (suc n) micro = Closure.microlinear-pullback
    (restriction n) (restriction n)
    (cube-microlinear n micro) (cube-microlinear n micro)
    (shell-microlinear n micro)
