{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentCubeTensors where

open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken; _≤ᵖ_; pzero≤; psuc≤)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face; map-cube; StrictCubicalExtensionality)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken; in-prefix; in-suffix;
  middle-degree; prefix-prefix; prefix-suffix; suffix-prefix; suffix-suffix)
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)

cast-cube : ∀ {ℓ} {m n : Dim} → m ≡ˢ n → {X : Type ℓ} → Cube m X → Cube n X
cast-cube reflˢ c = c

cast-cube-suc : ∀ {ℓ} {m n : Dim} (e : m ≡ˢ n) {X : Type ℓ}
  (c : Cube (osuc m) X) (i : I)
  → outer (cast-cube (strict-cong osuc e) c i) ≡ˢ outer (cast-cube e (c i))
cast-cube-suc reflˢ c i = reflˢ

cast-cube-suc-sym : ∀ {ℓ} {m n : Dim} (e : m ≡ˢ n) {X : Type ℓ}
  (c : Cube (osuc n) X) (i : I)
  → outer (cast-cube (strict-sym (strict-cong osuc e)) c i)
    ≡ˢ outer (cast-cube (strict-sym e) (c i))
cast-cube-suc-sym reflˢ c i = reflˢ

module Tensor {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  open Cubes.Extensional E

  map-pointwise : (n : Dim) {A B : Type ℓ} (f g : A → B)
    → ((a : A) → outer (f a) ≡ˢ outer (g a)) → (c : Cube n A)
    → outer (map-cube n f c) ≡ˢ outer (map-cube n g c)
  map-pointwise ozero f g e c = e c
  map-pointwise (osuc n) f g e c = interval-ext λ i → map-pointwise n f g e (c i)

  tensor-pointwise : (n : Dim) (p : Position (osuc n)) {A B C : Type ℓ}
    (g g' : B → Cube (suffix-degree n p) C)
    (f f' : A → Cube (prefix-degree n p) B)
    → ((b : B) → outer (g b) ≡ˢ outer (g' b))
    → ((a : A) → outer (f a) ≡ˢ outer (f' a)) → (a : A)
    → outer (tensor-action n p g f a) ≡ˢ outer (tensor-action n p g' f' a)
  tensor-pointwise n pzero g g' f f' eg ef a = strict-trans
    (strict-cong (λ c → outer (map-cube n g (inner c))) (ef a))
    (map-pointwise n g g' eg (f' a))
  tensor-pointwise (osuc n) (psuc p) g g' f f' eg ef a = interval-ext λ i →
    tensor-pointwise n p (λ b → g b i) (λ b → g' b i) f f'
      (λ b → strict-cong (λ c → outer (inner c i)) (eg b)) ef a

  tensor-face-suffix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    (i : I) {A B C : Type ℓ}
    (g : B → Cube (osuc (suffix-degree n q)) C)
    (f : A → Cube (prefix-degree n q) B) (a : A)
    → outer (coordinate-face n p i (tensor-action (osuc n) (psuc q) g f a))
      ≡ˢ outer (tensor-action n q
        (λ b → coordinate-face (suffix-degree n q) (in-suffix n p q le) i (g b)) f a)
  tensor-face-suffix n pzero q pzero≤ i g f a = reflˢ
  tensor-face-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) i g f a = interval-ext λ j →
    tensor-face-suffix n p q le i (λ b → g b j) f a

  tensor-face-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    (i : I) {A B C : Type ℓ}
    (g : B → Cube (suffix-degree (osuc n) (weaken p)) C)
    (f : A → Cube (prefix-degree (osuc n) (weaken p)) B) (a : A)
    → outer (coordinate-face n q i (tensor-action (osuc n) (weaken p) g f a))
      ≡ˢ outer (tensor-action n p
        (λ b → cast-cube (suffix-weaken n p) (g b))
        (λ a → coordinate-face (prefix-degree n p) (in-prefix n p q le) i
          (cast-cube (prefix-weaken n p) (f a))) a)
  tensor-face-prefix n pzero q pzero≤ i g f a = strict-sym (map-face n q i g (f a))
  tensor-face-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) i g f a = interval-ext λ j →
    strict-trans
      (tensor-face-prefix n p q le i (λ b → g b j) f a)
      (tensor-pointwise n p
        (λ b → cast-cube (suffix-weaken n p) (g b j))
        (λ b → cast-cube (strict-cong osuc (suffix-weaken n p)) (g b) j)
        (λ a → coordinate-face (prefix-degree n p) (in-prefix n p q le) i
          (cast-cube (prefix-weaken n p) (f a)))
        (λ a → coordinate-face (prefix-degree n p) (in-prefix n p q le) i
          (cast-cube (prefix-weaken n p) (f a)))
        (λ b → strict-sym (cast-cube-suc (suffix-weaken n p) (g b) j))
        (λ a → reflˢ) a)

  map-tensor : (n : Dim) (p : Position (osuc n)) {A B C D : Type ℓ}
    (h : C → D) (g : B → Cube (suffix-degree n p) C)
    (f : A → Cube (prefix-degree n p) B) (a : A)
    → outer (map-cube n h (tensor-action n p g f a))
      ≡ˢ outer (tensor-action n p (λ b → map-cube (suffix-degree n p) h (g b)) f a)
  map-tensor n pzero h g f a = map-compose n h g (f a)
  map-tensor (osuc n) (psuc p) h g f a = interval-ext λ i →
    map-tensor n p h (λ b → g b i) f a

  tensor-prefix-first : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {A B C D : Type ℓ}
    → (C → Cube (suffix-degree n p) D)
    → (B → Cube (middle-degree n p q le) C)
    → (A → Cube (prefix-degree n q) B) → A → Cube n D
  tensor-prefix-first n p q le h g f a = tensor-action n p h
    (λ a → tensor-action (prefix-degree n p) (in-prefix n p q le)
      (λ b → cast-cube (strict-sym (prefix-suffix n p q le)) (g b))
      (λ a → cast-cube (strict-sym (prefix-prefix n p q le)) (f a)) a) a

  tensor-suffix-first : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {A B C D : Type ℓ}
    → (C → Cube (suffix-degree n p) D)
    → (B → Cube (middle-degree n p q le) C)
    → (A → Cube (prefix-degree n q) B) → A → Cube n D
  tensor-suffix-first n p q le h g f a = tensor-action n q
    (λ b → tensor-action (suffix-degree n q) (in-suffix n p q le)
      (λ c → cast-cube (strict-sym (suffix-suffix n p q le)) (h c))
      (λ b → cast-cube (strict-sym (suffix-prefix n p q le)) (g b)) b) f a

  tensor-associativity : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {A B C D : Type ℓ}
    (h : C → Cube (suffix-degree n p) D)
    (g : B → Cube (middle-degree n p q le) C)
    (f : A → Cube (prefix-degree n q) B) (a : A)
    → outer (tensor-prefix-first n p q le h g f a)
      ≡ˢ outer (tensor-suffix-first n p q le h g f a)
  tensor-associativity n pzero q pzero≤ h g f a = map-tensor n q h g f a
  tensor-associativity (osuc n) (psuc p) (psuc q) (psuc≤ le) h g f a = interval-ext λ i →
    strict-trans
      (tensor-associativity n p q le (λ c → h c i) g f a)
      (tensor-pointwise n q _ _ f f
        (λ b → tensor-pointwise (suffix-degree n q) (in-suffix n p q le)
          (λ c → cast-cube (strict-sym (suffix-suffix n p q le)) (h c i))
          (λ c → cast-cube (strict-sym (strict-cong osuc (suffix-suffix n p q le))) (h c) i)
          (λ b → cast-cube (strict-sym (suffix-prefix n p q le)) (g b))
          (λ b → cast-cube (strict-sym (suffix-prefix n p q le)) (g b))
          (λ c → strict-sym (cast-cube-suc-sym (suffix-suffix n p q le) (h c) i))
          (λ b → reflˢ) b)
        (λ a → reflˢ) a)
