{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ContinuousActionLocalCharts where

-- The algebraic unit, inverse and action equations construct each
-- action homeomorphism. The source and target charts are then the
-- actual open label slices, with explicit continuous inverse maps.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( OpenFragment; Product; RectangleBasis )
open import Orbifolds.Intensional.CompactSeparation using
  ( Continuous; PropositionalEM; ProperData; ChosenHausdorff )
open import Orbifolds.Intensional.OpenSubspaces using
  ( Homeomorphism; underlying; forward-continuous; backward-continuous )
import Orbifolds.Intensional.CoproductHomeomorphismCharts as Coproduct
import Orbifolds.Intensional.FiniteLabelledGraphProperness as Proper

module Action {ℓ : Level} {G X : Set ℓ}
    (setG : isSet G) (O : OpenFragment X)
    (unit : G) (multiply : G → G → G) (inverse : G → G)
    (inverse-left : (g : G) → multiply (inverse g) g ≡ unit)
    (inverse-right : (g : G) → multiply g (inverse g) ≡ unit)
    (act : G → X → X)
    (act-unit : (x : X) → act unit x ≡ x)
    (act-multiply : (g h : G) (x : X) → act (multiply g h) x ≡ act g (act h x))
    (act-continuous : (g : G) → Continuous O O (act g)) where

  act-inverse-left : (g : G) (x : X) → act (inverse g) (act g x) ≡ x
  act-inverse-left g x = sym (act-multiply (inverse g) g x)
    ∙ cong (λ h → act h x) (inverse-left g) ∙ act-unit x

  act-inverse-right : (g : G) (x : X) → act g (act (inverse g) x) ≡ x
  act-inverse-right g x = sym (act-multiply g (inverse g) x)
    ∙ cong (λ h → act h x) (inverse-right g) ∙ act-unit x

  action-homeomorphism : G → Homeomorphism O O
  underlying (action-homeomorphism g) = equiv (act g) (act (inverse g))
    (act-inverse-right g) (act-inverse-left g)
  forward-continuous (action-homeomorphism g) = act-continuous g
  backward-continuous (action-homeomorphism g) = act-continuous (inverse g)

  module Geometry = Coproduct.Charts setG O O action-homeomorphism
  open Geometry public using
    ( arrowTopology; source; target; source-continuous; target-continuous
    ; source-local-homeomorphisms; target-local-homeomorphisms )

  source-computation : (g : G) (x : X) → source (g , x) ≡ x
  source-computation g x = refl

  target-computation : (g : G) (x : X) → target (g , x) ≡ act g x
  target-computation g x = refl

  anchor : Product G X → Product X X
  anchor z = source z , target z

  module Finite (ext : FunExt ℓ ℓ) (classical : PropositionalEM ℓ)
      {n : Nat} (numbering : Equiv G (Fin {ℓ} n))
      (OXX : OpenFragment (Product X X))
      (setX : isSet X) (separated : ChosenHausdorff O)
      (first-continuous : Continuous OXX O fst)
      (second-continuous : Continuous OXX O snd) where

    module Graphs = Proper.Enumerated ext classical numbering O O OXX
      setX separated first-continuous second-continuous act act-continuous

    anchor-proper : ProperData arrowTopology OXX anchor
    anchor-proper = Graphs.anchor-proper

    anchor-continuous : RectangleBasis O O OXX → Continuous arrowTopology OXX anchor
    anchor-continuous = Graphs.anchor-continuous
