{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DirichletApproximation where

-- A constructive small integer linear combination for every smooth real.
-- Only finite choice, overlapping open grids and finite pigeonhole are used.
-- No floor function, real-order decision procedure or countable choice.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.Data.Nat as N
open import Cubical.Data.Int using (ℤ; pos)
import Cubical.Data.Int as Z
import Cubical.Data.Fin as F
open import Cubical.Relation.Nullary using (¬_)
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.SyntheticBounds as SB
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.RationalCoefficients as RC
import Orbifolds.RealCountableBasis as RB
import Orbifolds.RationalGridOrder as GO
import Orbifolds.FiniteApproximation as FA

module Ordered {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext R using (nat)
  open SF.RingContext.StrictOrder order
  open SO.OrderTheory R order
  open Compatible compatibility
  open SB.Bounds R kock order compatibility using (negateLess)
  module Coeff = IC.Ring R
  open Coeff using (integer)
  module Hom = IsCommRingHom (Coeff.ring-homomorphism .snd)
  module Rationals = RC.Ordered R kock order compatibility
  module Basis = RB.RealBasis R kock order compatibility
  module GridOrder = GO.GridOrder R kock order compatibility
  module Finite = FA.Ordered R kock order compatibility

  two : R .fst
  two = 1r + 1r

  integer-difference : (m n : ℤ) → integer (m Z.- n) ≡ integer m - integer n
  integer-difference m n = Hom.pres+ m (Z.- n) ∙ cong (integer m +_) (Hom.pres- n)

  step-zero : Basis.step zero ≡ 1r
  step-zero = sym (·IdL (Basis.step zero))
    ∙ cong (_· Basis.step zero) (sym (+IdL 1r)) ∙ Basis.denominatorStep zero

  grid-lower-integer : (m k : ℕ)
    → Basis.GridLower zero m k ≡ integer (pos k Z.- pos m)
  grid-lower-integer m k = cong ((nat k - nat m) ·_) step-zero
    ∙ ·IdR (nat k - nat m)
    ∙ sym (integer-difference (pos k) (pos m)
      ∙ cong₂ _-_ (Rationals.integer-natural k) (Rationals.integer-natural m))

  grid-unit-width : (m k : ℕ)
    → Basis.GridUpper zero m k - Basis.GridLower zero m k ≡ two
  grid-unit-width m k = Basis.gridWidth (nat k) (nat m) (Basis.step zero)
    ∙ cong (two ·_) step-zero ∙ ·IdR two

  Residue : R .fst → Type ℓ
  Residue x = Σ[ z ∈ ℤ ] ((0r < (x - integer z)) × ((x - integer z) < two))

  integer-residue : (x : R .fst) → PT.∥ Residue x ∥₁
  integer-residue x = PT.map finish (Basis.gridAround zero x)
    where
    finish : (Σ[ m ∈ ℕ ] Σ[ k ∈ ℕ ] Basis.Grid (zero , m , k) x .fst) → Residue x
    finish (m , k , below , above) = (pos k Z.- pos m) ,
      subst2 _<_ (+InvR (Basis.GridLower zero m k))
        (cong (λ y → x - y) (grid-lower-integer m k))
        (translateLess below (- Basis.GridLower zero m k)) ,
      subst2 _<_ (cong (λ y → x - y) (grid-lower-integer m k)) (grid-unit-width m k)
        (translateLess above (- Basis.GridLower zero m k))

  SmallCombination : (α ε : R .fst) → Type ℓ
  SmallCombination α ε = Σ[ m ∈ ℤ ] Σ[ n ∈ ℤ ]
    (¬ (m ≡ pos zero)) ×
    (((- ε) < (integer m · α + integer n)) × ((integer m · α + integer n) < ε))

  abstract
    double-product : (d : R .fst) → two · d ≡ d + d
    double-product d = solve! R

    cancel-difference : (x y d u : R .fst) → d · u ≡ 1r
      → ((x · d) - (y · d)) · u ≡ x - y
    cancel-difference x y d u inverse = rearrange
      ∙ cong ((x - y) ·_) inverse ∙ ·IdR (x - y)
      where
      rearrange : ((x · d) - (y · d)) · u ≡ (x - y) · (d · u)
      rearrange = solve! R

    negative-product : (x y : R .fst) → (- x) · y ≡ - (x · y)
    negative-product x y = solve! R

    residual-algebra : (a b x y α : R .fst)
      → ((a - b) · α + (y - x)) ≡ ((a · α - x) - (b · α - y))
    residual-algebra a b x y α = solve! R

  dirichlet : (α ε : R .fst) → 0r < ε → PT.∥ SmallCombination α ε ∥₁
  dirichlet α ε positive = PT.rec PT.squash₁
    (λ { (n , narrow) → at-step n narrow })
    (Basis.arbitrarilySmallStep (ε , positive))
    where
    at-step : (n : ℕ) → (two · Basis.step n) < ε → PT.∥ SmallCombination α ε ∥₁
    at-step n narrow = PT.rec PT.squash₁ finish
      (Finite.finite-choice (λ i → Residue (integer (pos (i .fst)) · α))
        (λ i → integer-residue (integer (pos (i .fst)) · α)))
      where
      L = suc n N.+ suc n
      Index = F.Fin (suc L)
      d = nat (suc n)
      u = Basis.step n

      finish : ((i : Index) → Residue (integer (pos (i .fst)) · α))
        → PT.∥ SmallCombination α ε ∥₁
      finish chosen = PT.map collision
        (Finite.bounded-pigeonhole L scaled scaled-positive scaled-bound)
        where
        residue : Index → R .fst
        residue i = integer (pos (i .fst)) · α - integer (chosen i .fst)

        scaled : Index → R .fst
        scaled i = residue i · d

        scaled-positive : (i : Index) → 0r < scaled i
        scaled-positive i = positive-multiply (chosen i .snd .fst) (natPositive n)

        scaled-bound : (i : Index) → scaled i < nat L
        scaled-bound i = subst (scaled i <_)
          (double-product d ∙ sym (GridOrder.natAdd (suc n) (suc n)))
          (multiplyLessRightPositive (natPositive n) (chosen i .snd .snd))

        collision : (Σ[ i ∈ Index ] Σ[ j ∈ Index ] (¬ (i ≡ j)) ×
          (((- two) < (scaled i - scaled j)) × ((scaled i - scaled j) < two)))
          → SmallCombination α ε
        collision (i , j , different , lower , upper) =
          (pos (i .fst) Z.- pos (j .fst)) , (chosen j .fst Z.- chosen i .fst) ,
          (λ p → different (F.toℕ-injective
            (Z.injPos (Z.-≡0 (pos (i .fst)) (pos (j .fst)) p)))) ,
          subst ((- ε) <_) (sym combination)
            (lessTrans (negateLess narrow)
              (subst2 _<_ (negative-product two u) cancel
                (multiplyLessRightPositive (Basis.stepPositive n) lower))) ,
          subst (_< ε) (sym combination)
            (lessTrans (subst (_< (two · u)) cancel
              (multiplyLessRightPositive (Basis.stepPositive n) upper)) narrow)
          where
          cancel : (scaled i - scaled j) · u ≡ residue i - residue j
          cancel = cancel-difference (residue i) (residue j) d u (Basis.denominatorStep n)

          combination : integer (pos (i .fst) Z.- pos (j .fst)) · α
              + integer (chosen j .fst Z.- chosen i .fst)
            ≡ residue i - residue j
          combination = cong₂ _+_
            (cong (_· α) (integer-difference (pos (i .fst)) (pos (j .fst))))
            (integer-difference (chosen j .fst) (chosen i .fst))
            ∙ residual-algebra (integer (pos (i .fst))) (integer (pos (j .fst)))
              (integer (chosen i .fst)) (integer (chosen j .fst)) α
