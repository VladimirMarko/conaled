{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FirstOrderWeilBasedTensor where

-- The first-order tensor comparison over the actual parameter A.
-- Its target uses the actual two augmentation maps A tensor D -> A,
-- not merely a pullback over an unidentified A tensor R object.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using
  ( isEquiv; comp-isEquiv; homotopy-isEquiv )
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( Pullback; pullback-path; finite-support-isSet )
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportScalarExtension
import Orbifolds.Intensional.PullbackBaseChange as BaseChange
import Orbifolds.Intensional.FirstOrderWeilSquare as FirstOrder
import Orbifolds.Intensional.FirstOrderWeilTensor as FirstTensor

module Comparison {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) (R : CommutativeSemiring ℓ)
    (A : Semimodule R) (basis : BasedExtension.Basis ext classical equality A) where

  Parameter = FirstTensor.Construction.Parameter ext classical equality R
  PlaneTensor = FirstTensor.Construction.PlaneTensor ext classical equality R
  DualTensor = FirstTensor.Construction.DualTensor ext classical equality R
  ScalarTensor = FirstTensor.Construction.ScalarTensor ext classical equality R
  dual-module = FirstOrder.Construction.D.E-module R
  dual-epsilon = FirstOrder.Construction.D.augmentation-linear R

  first = FirstTensor.Construction.extended-first ext classical equality R
  second = FirstTensor.Construction.extended-second ext classical equality R
  epsilon = FirstTensor.Construction.extended-augmentation ext classical equality R
  tensor-comparison = FirstTensor.Construction.first-order-tensor-comparison ext classical equality R

  augmentation : LinearMap DualTensor A
  augmentation = FirstTensor.Construction.AtParameter.WithBasis.dual-augmentation
    ext classical equality R A basis

  basis-equivalence : Equiv (Semimodule.Carrier ScalarTensor) (Semimodule.Carrier A)
  basis-equivalence = equiv
    (fst (LinearEquivalence.to-linear basis)) (fst (LinearEquivalence.from-linear basis))
    (LinearEquivalence.to-from basis) (LinearEquivalence.from-to basis)

  augmentation-commutes : (u : Semimodule.Carrier DualTensor)
    → fst augmentation u ≡ forward basis-equivalence (fst epsilon u)
  augmentation-commutes = BasedExtension.WithBasis.Augmentation.augmentation-evaluation
    ext classical equality A basis dual-module dual-epsilon

  module B = BaseChange.Change
    (finite-support-isSet ext (CommutativeSemiring.carrier-set R)) (Semimodule.carrier-set A)
    basis-equivalence (fst epsilon) (fst epsilon) (fst augmentation) (fst augmentation)
    augmentation-commutes augmentation-commutes

  factor : Semimodule.Carrier PlaneTensor → Pullback (fst augmentation) (fst augmentation)
  factor u = B.to-new-base (tensor-comparison u)

  comparison : Semimodule.Carrier PlaneTensor → Pullback (fst augmentation) (fst augmentation)
  comparison u = fst first u , (fst second u ,
    FirstTensor.Construction.AtParameter.WithBasis.parameter-second-route
      ext classical equality R A basis u
    ∙ sym (FirstTensor.Construction.AtParameter.WithBasis.parameter-first-route
      ext classical equality R A basis u))

  factor-computation : (u : Semimodule.Carrier PlaneTensor) → factor u ≡ comparison u
  factor-computation u = pullback-path (Semimodule.carrier-set A)
    {u = factor u} {v = comparison u} refl refl

  comparison-isEquiv : isEquiv comparison
  comparison-isEquiv = homotopy-isEquiv factor comparison factor-computation
    (comp-isEquiv tensor-comparison B.to-new-base
      (FirstTensor.Construction.first-order-tensor-comparison-isEquiv ext classical equality R)
      B.base-change-isEquiv)
