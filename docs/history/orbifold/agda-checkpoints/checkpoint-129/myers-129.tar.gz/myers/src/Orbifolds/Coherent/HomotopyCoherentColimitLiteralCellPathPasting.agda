{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitLiteralCellPathPasting where

-- Align the literal thin cell-cocone carrier and restriction before a
-- concrete target cell map is substituted. The paths are exactly the
-- previously constructed paste, including its complete prefix law.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments
import Orbifolds.Coherent.HomotopyCoherentColimitCellPathPasting as Original

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  module Data = Comparison.Comparison C D E F n previous
    using (Index; Coefficient; original-boundary)

  Previous : Type ℓ
  Previous = Represented.Induction.Represented.Space previous

  module Cell = Attachments.Attachment E (osuc n) Previous Data.Index
    Data.Coefficient Data.original-boundary using (Realize; Cocone; module Target)

  Realize : Type ℓ
  Realize = Cell.Realize

  -- Result types are solved from the accepted proofs. The mandatory
  -- no-unsolved-metas gate verifies that these aliases are complete.
  module Instance (Y : Type ℓ) (h : Realize → Y) (s : Cell.Cocone Y)
      (p : Cell.Target.restrict Y h ≡ s) where
    original-h : Stages.Construction.Step.Realize C D E F n previous → Y
    original-h = h

    original-s : Original.Construction.CellCocone C D E F n previous Y
    original-s = s

    original-p : Stages.Construction.Step.cell-restrict C D E F n previous Y original-h
      ≡ original-s
    original-p = p

    value : _
    value = Original.Construction.paste-cell C D E F n previous Y original-h original-s original-p

    prefix : _
    prefix = Original.Construction.paste-cell-prefix C D E F n previous Y original-h original-s original-p

    constructed : _
    constructed = Original.Construction.construction C D E F n previous Y original-h original-s original-p

  paste-cell : _
  paste-cell = Instance.value

  paste-cell-prefix : _
  paste-cell-prefix = Instance.prefix

  construction : _
  construction = Instance.constructed
