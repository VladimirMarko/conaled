{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ContinuousLabelRecovery where

-- Converse to assembling continuous maps from locally constant labels.
-- Openness of a label slice is constructed in the literal coproduct topology.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using (OpenFragment)
open import Orbifolds.Intensional.CompactSeparation using (Continuous)
import Orbifolds.Intensional.OpenSubspaces as OS
import Orbifolds.Intensional.ContinuousActionArrowFamilies as Labels

sum-label-locally-constant : {ℓ : Level} {G : Set ℓ} {A : G → Set ℓ}
  (setG : isSet G) (OA : (g : G) → OpenFragment (A g))
  → Labels.LocallyConstant setG (OS.sumOpenFragment OA) fst
sum-label-locally-constant setG OA g h = Labels.locally-constant-constant setG (OA h) h g

label-of-continuous : {ℓ : Level} {G Z : Set ℓ} {A : G → Set ℓ}
  (setG : isSet G) (OZ : OpenFragment Z) (OA : (g : G) → OpenFragment (A g))
  (f : Z → Σ G A) → Continuous OZ (OS.sumOpenFragment OA) f
  → Labels.LocallyConstant setG OZ (λ z → fst (f z))
label-of-continuous setG OZ OA f continuous =
  Labels.locally-constant-restrict setG (OS.sumOpenFragment OA) OZ f continuous fst
    (sum-label-locally-constant setG OA)
