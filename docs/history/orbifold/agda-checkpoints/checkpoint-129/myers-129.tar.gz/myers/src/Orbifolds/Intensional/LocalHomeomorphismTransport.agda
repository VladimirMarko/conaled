{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LocalHomeomorphismTransport where

-- Pull a chosen chart back along an actual homeomorphism. Its source
-- patch is the inverse image of the original source patch, its target
-- patch is unchanged, and both maps and both round trips are constructed.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; OpenFragment; IsOpen )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
import Orbifolds.Intensional.OpenSubspaces as OS
import Orbifolds.Intensional.LocalHomeomorphisms as LH

module Restriction {ℓ : Level} {A B : Set ℓ}
    {OA : OpenFragment A} {OB : OpenFragment B}
    (h : OS.Homeomorphism OA OB) (D : Subset B) (open-D : IsOpen OB D) where

  e : Equiv A B
  e = OS.underlying h

  pullback-patch : Subset A
  pullback-patch = preimage (forward e) D

  pullback-open : IsOpen OA pullback-patch
  pullback-open = OS.forward-continuous h D open-D

  source-topology : OpenFragment (OS.Carrier pullback-patch)
  source-topology = OS.openSubspace OA pullback-patch pullback-open

  target-topology : OpenFragment (OS.Carrier D)
  target-topology = OS.openSubspace OB D open-D

  to-patch : OS.Carrier pullback-patch → OS.Carrier D
  to-patch u = forward e (fst u) , snd u

  from-lands : (v : OS.Carrier D)
    → member pullback-patch (backward e (fst v))
  from-lands v = subst (member D) (sym (section e (fst v))) (snd v)

  from-patch : OS.Carrier D → OS.Carrier pullback-patch
  from-patch v = backward e (fst v) , from-lands v

  to-from : (v : OS.Carrier D) → to-patch (from-patch v) ≡ v
  to-from v = Σ-path-prop (member-prop D) (section e (fst v))

  from-to : (u : OS.Carrier pullback-patch) → from-patch (to-patch u) ≡ u
  from-to u = Σ-path-prop (member-prop pullback-patch) (retraction e (fst u))

  to-continuous : Continuous source-topology target-topology to-patch
  to-continuous = OS.corestrict-continuous source-topology OB D open-D
    (λ u → forward e (fst u))
    (OS.restrict-continuous OA OB pullback-patch pullback-open
      (forward e) (OS.forward-continuous h))
    (λ u → snd u)

  from-continuous : Continuous target-topology source-topology from-patch
  from-continuous = OS.corestrict-continuous target-topology OA
    pullback-patch pullback-open (λ v → backward e (fst v))
    (OS.restrict-continuous OB OA D open-D
      (backward e) (OS.backward-continuous h)) from-lands

  homeomorphism : OS.Homeomorphism source-topology target-topology
  OS.underlying homeomorphism = equiv to-patch from-patch to-from from-to
  OS.forward-continuous homeomorphism = to-continuous
  OS.backward-continuous homeomorphism = from-continuous

precompose-chart : {ℓ : Level} {A B C : Set ℓ}
  {OA : OpenFragment A} {OB : OpenFragment B} {OC : OpenFragment C}
  (h : OS.Homeomorphism OA OB) (f : B → C) (a : A)
  → LH.LocalHomeomorphismChart OB OC f (forward (OS.underlying h) a)
  → LH.LocalHomeomorphismChart OA OC (λ x → f (forward (OS.underlying h) x)) a
precompose-chart {OA = OA} {OB} {OC} h f a chart = record
  { source-patch = R.pullback-patch
  ; target-patch = L.target-patch
  ; source-patch-open = R.pullback-open
  ; target-patch-open = L.target-patch-open
  ; source-center = L.source-center
  ; restriction-lands = λ u → L.restriction-lands (R.to-patch u)
  ; local-inverse = λ v → R.from-patch (L.local-inverse v)
  ; inverse-right-law = λ v →
      cong Ch.restriction (R.to-from (L.local-inverse v)) ∙ L.inverse-right-law v
  ; inverse-left-law = λ u →
      cong R.from-patch (L.inverse-left-law (R.to-patch u)) ∙ R.from-to u
  ; restriction-continuous = OS.compose-continuous
      R.source-topology R.target-topology Ch.target-topology
      R.to-patch Ch.restriction R.to-continuous L.restriction-continuous
  ; local-inverse-continuous = OS.compose-continuous
      Ch.target-topology R.target-topology R.source-topology
      L.local-inverse R.from-patch L.local-inverse-continuous R.from-continuous
  }
  where
  module L = LH.LocalHomeomorphismChart chart
  module R = Restriction h L.source-patch L.source-patch-open
  module Ch = LH.Chart OB OC f (forward (OS.underlying h) a) chart

precompose-local-homeomorphisms : {ℓ : Level} {A B C : Set ℓ}
  {OA : OpenFragment A} {OB : OpenFragment B} {OC : OpenFragment C}
  (h : OS.Homeomorphism OA OB) (f : B → C)
  → LH.ChosenLocalHomeomorphisms OB OC f
  → LH.ChosenLocalHomeomorphisms OA OC (λ a → f (forward (OS.underlying h) a))
precompose-local-homeomorphisms h f charts a =
  precompose-chart h f a (charts (forward (OS.underlying h) a))

-- Membership proofs are propositions, so the restricted round trips
-- follow from the actual ambient round trips. No sethood, function
-- extensionality, excluded middle, or new chart premise is required.
