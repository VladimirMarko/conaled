{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteMapLaws where

-- Finite typed cone maps depend functorially on the actual component
-- maps.  Higher naturality certificates are retained in the map
-- construction; equality is proved from its full raw-cube computation.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.HomotopyCoherentActionData using (LawPair)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Maps
import Orbifolds.Coherent.HomotopyCoherentFiniteTransformations as Actions
import Orbifolds.Coherent.HomotopyCoherentFiniteExtensionality as Extensionality

module Composition {ℓ : Level} (C : Category ℓ ℓ)
    (D G H : HC.ForCategory.Diagram C)
    (α : Maps.ForCategory.Transformation C D G)
    (β : Maps.ForCategory.Transformation C G H)
    (γ : Maps.ForCategory.Transformation C D H)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Maps.ForCategory.Transformation.component β x ∘ Maps.ForCategory.Transformation.component α x)
        ≡ˢ outer (Maps.ForCategory.Transformation.component γ x)) where
  open Category C
  open Chains C
  open StrictFunctionExtensionality F
  module Transformations = Maps.ForCategory C
  module α = Transformations.Transformation α
  module β = Transformations.Transformation β
  module γ = Transformations.Transformation γ
  module A = Actions.Action D G α E
  module B = Actions.Action G H β E
  module K = Actions.Action D H γ E
  module Ext = Extensionality.Extensionality C H E F

  top-composition : (n : Dim) (s : A.SourceFinite.Carrier n) (y : Obj) (c : Chain n y)
    → outer (B.Target.top n (B.TargetFinite.families n) (B.stage-map n (A.stage-map n s)) y c)
      ≡ˢ outer (K.Target.top n (K.TargetFinite.families n) (K.stage-map n s) y c)
  top-composition n s y c = strict-trans
    (strict-sym (B.stage-top-natural n (A.stage-map n s) y c))
    (strict-trans
      (strict-cong (λ q → outer (map-cube n (β.component y) (inner q)))
        (strict-sym (A.stage-top-natural n s y c)))
      (strict-trans
        (Cubes.Extensional.map-compose E n (β.component y) (α.component y)
          (A.Source.top n (A.SourceFinite.families n) s y c))
        (strict-trans
          (strict-cong (λ q → outer (map-cube n (inner q)
            (A.Source.top n (A.SourceFinite.families n) s y c))) (components y))
          (K.stage-top-natural n s y c))))

  agreement : (n : Dim) (s : A.SourceFinite.Carrier n)
    → Ext.Agreement n (B.stage-map n (A.stage-map n s)) (K.stage-map n s)
  agreement ozero s = top-composition ozero s
  LawPair.earlier (agreement (osuc n) s) = agreement n (s .fst)
  LawPair.current (agreement (osuc n) s) = top-composition (osuc n) s

  stage-composition : (n : Dim) (s : A.SourceFinite.Carrier n)
    → outer (B.stage-map n (A.stage-map n s)) ≡ˢ outer (K.stage-map n s)
  stage-composition n s = Ext.stage-extensionality n _ _ (agreement n s)

  function-composition : (n : Dim)
    → outer (B.stage-map n ∘ A.stage-map n) ≡ˢ outer (K.stage-map n)
  function-composition n = function-ext (stage-composition n)

module Identity {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (α : Maps.ForCategory.Transformation C D D)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Maps.ForCategory.Transformation.component α x) ≡ˢ outer (idfun _)) where
  open Category C
  open Chains C
  open StrictFunctionExtensionality F
  module Transformations = Maps.ForCategory C
  module α = Transformations.Transformation α
  module A = Actions.Action D D α E
  module Ext = Extensionality.Extensionality C D E F

  top-identity : (n : Dim) (s : A.SourceFinite.Carrier n) (y : Obj) (c : Chain n y)
    → outer (A.Target.top n (A.TargetFinite.families n) (A.stage-map n s) y c)
      ≡ˢ outer (A.Source.top n (A.SourceFinite.families n) s y c)
  top-identity n s y c = strict-trans
    (strict-sym (A.stage-top-natural n s y c))
    (strict-trans
      (strict-cong (λ q → outer (map-cube n (inner q)
        (A.Source.top n (A.SourceFinite.families n) s y c))) (components y))
      (Cubes.Extensional.map-identity E n (A.Source.top n (A.SourceFinite.families n) s y c)))

  agreement : (n : Dim) (s : A.SourceFinite.Carrier n)
    → Ext.Agreement n (A.stage-map n s) s
  agreement ozero s = top-identity ozero s
  LawPair.earlier (agreement (osuc n) s) = agreement n (s .fst)
  LawPair.current (agreement (osuc n) s) = top-identity (osuc n) s

  stage-identity : (n : Dim) (s : A.SourceFinite.Carrier n)
    → outer (A.stage-map n s) ≡ˢ outer s
  stage-identity n s = Ext.stage-extensionality n _ _ (agreement n s)

  function-identity : (n : Dim)
    → outer (A.stage-map n) ≡ˢ outer (idfun (A.SourceFinite.Carrier n))
  function-identity n = function-ext (stage-identity n)
