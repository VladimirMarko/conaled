{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularTransformations where

-- Canonical transformation of an unbounded cellular presentation.
-- New boundary lifts are explicit homotopy fibers. Consequently the
-- transformed data is defined without any preservation proof or choice
-- of an inverse; preservation is proved afterward from local primitives.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sequence using (Sequence; SequenceMap; SequenceEquiv; sequencemap)
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC
import Cubical.HITs.SequentialColimit.Properties as SP
import Orbifolds.CellularPresentations as CP

mapSequence : {ℓ : Level} (F : Type ℓ → Type ℓ)
  → ({A B : Type ℓ} → (A → B) → F A → F B) → Sequence ℓ → Sequence ℓ
Sequence.obj (mapSequence F map S) n = F (Sequence.obj S n)
Sequence.map (mapSequence F map S) = map (Sequence.map S)

record Operations (ℓ : Level) : Type (ℓ-suc ℓ) where
  field
    F : Type ℓ → Type ℓ
    map : {A B : Type ℓ} → (A → B) → F A → F B
    pushout-comparison : {B A C : Type ℓ} (f : B → A) (b : B → C)
      → PO.Pushout (map f) (map b) → F (PO.Pushout f b)
    pushout-left : {B A C : Type ℓ} (f : B → A) (b : B → C) (x : F A)
      → pushout-comparison f b (PO.inl x) ≡ map (PO.inl {f = f} {g = b}) x
    pushout-right : {B A C : Type ℓ} (f : B → A) (b : B → C) (x : F C)
      → pushout-comparison f b (PO.inr x) ≡ map (PO.inr {f = f} {g = b}) x

    sequence-comparison : (S : Sequence ℓ)
      → SC.SeqColim (mapSequence F map S) → F (SC.SeqColim S)
    sequence-point : (S : Sequence ℓ) (n : ℕ) (x : F (Sequence.obj S n))
      → sequence-comparison S (SC.incl {n = n} x) ≡ map (SC.incl {n = n}) x

  mapped-sequence : Sequence ℓ → Sequence ℓ
  mapped-sequence = mapSequence F map

module Theory {ℓ : Level} (O : Operations ℓ) where
  open Operations O

  module Step {B A C : Type ℓ} (f : B → A) (b : B → C)
      (Q : Type ℓ) (comparison : Q → F A) where
    BoundaryLift : Type ℓ
    BoundaryLift = Σ[ v ∈ F B ] fiber comparison (map f v)

    left : BoundaryLift → Q
    left u = u .snd .fst

    right : BoundaryLift → F C
    right u = map b (u .fst)

    Result : Type ℓ
    Result = PO.Pushout left right

    left-square : comparison ∘ left ≡ map f ∘ fst
    left-square i u = u .snd .snd i

    span-comparison : Result → PO.Pushout (map f) (map b)
    span-comparison = PO.Pushout→ left right (map f) (map b)
      fst comparison (idfun (F C)) left-square refl

    next-comparison : Result → F (PO.Pushout f b)
    next-comparison = pushout-comparison f b ∘ span-comparison

    left-computation : (x : Q)
      → next-comparison (PO.inl x) ≡ map (PO.inl {f = f} {g = b}) (comparison x)
    left-computation x = pushout-left f b (comparison x)

    right-computation : (x : F C)
      → next-comparison (PO.inr x) ≡ map (PO.inr {f = f} {g = b}) x
    right-computation = pushout-right f b

    attachment-computation : (u : BoundaryLift) (i : I)
      → next-comparison (PO.push u i)
        ≡ pushout-comparison f b
          (((λ j → PO.inl (u .snd .snd j)) ∙∙ PO.push (u .fst) ∙∙ refl) i)
    attachment-computation u i = refl

    -- The extra lift is a contractible choice precisely when the
    -- already constructed comparison of lower skeleta is equivalent.
    boundary-equivalence : isEquiv comparison → BoundaryLift ≃ F B
    boundary-equivalence equivalent = Σ-contractSnd
      (λ v → equivalent .equiv-proof (map f v))

    span-comparison-agrees : (equivalent : isEquiv comparison) (x : Result)
      → PO.pushoutEquiv left right (map f) (map b)
          (boundary-equivalence equivalent) (comparison , equivalent) (idEquiv (F C))
          left-square refl .fst x ≡ span-comparison x
    span-comparison-agrees equivalent (PO.inl x) = refl
    span-comparison-agrees equivalent (PO.inr x) = refl
    span-comparison-agrees equivalent (PO.push u i) = refl

    span-preserved : isEquiv comparison → isEquiv span-comparison
    span-preserved equivalent = subst isEquiv (funExt (span-comparison-agrees equivalent))
      (PO.pushoutEquiv left right (map f) (map b)
        (boundary-equivalence equivalent) (comparison , equivalent) (idEquiv (F C))
        left-square refl .snd)

    preservation : isEquiv comparison → isEquiv (pushout-comparison f b)
      → isEquiv next-comparison
    preservation equivalent preserved = compEquiv
      (span-comparison , span-preserved equivalent)
      (pushout-comparison f b , preserved) .snd

  module Presentation (A : Type ℓ) (P : CP.Presentation A) where
    module Original = CP.Realization A P
    open Original using (Stage; boundary-type; cell-type; attaching-map; boundary-map; inclusion)

    state : (n : ℕ) → Σ[ Q ∈ Type ℓ ] (Q → F (Stage n))
    state zero = F A , idfun (F A)
    state (suc n) .fst = Step.Result (attaching-map n) (boundary-map n)
      (state n .fst) (state n .snd)
    state (suc n) .snd = Step.next-comparison (attaching-map n) (boundary-map n)
      (state n .fst) (state n .snd)

    TransformedStage : ℕ → Type ℓ
    TransformedStage n = state n .fst

    stage-comparison : (n : ℕ) → TransformedStage n → F (Stage n)
    stage-comparison n = state n .snd

    module Attachment (n : ℕ) = Step (attaching-map n) (boundary-map n)
      (TransformedStage n) (stage-comparison n)

    transformed-stages : Sequence ℓ
    Sequence.obj transformed-stages = TransformedStage
    Sequence.map transformed-stages {n} = PO.inl

    Transformed : Type ℓ
    Transformed = SC.SeqColim transformed-stages

    -- Each transformed successor is a literal pushout. The following
    -- coinductive tail records its complete cellular attachment data.
    transformed-tail : (n : ℕ) → CP.Presentation (TransformedStage n)
    CP.Presentation.Boundary (transformed-tail n) = Attachment.BoundaryLift n
    CP.Presentation.Cells (transformed-tail n) = F (cell-type n)
    CP.Presentation.attach (transformed-tail n) = Attachment.left n
    CP.Presentation.boundary (transformed-tail n) = Attachment.right n
    CP.Presentation.next (transformed-tail n) = transformed-tail (suc n)

    stage-map : SequenceMap transformed-stages (mapped-sequence Original.stages)
    SequenceMap.map stage-map = stage-comparison
    SequenceMap.comm stage-map n x = sym (Attachment.left-computation n x)

    comparison : Transformed → F Original.Realize
    comparison = sequence-comparison Original.stages ∘ SC.realiseSequenceMap stage-map

    stage-computation : (n : ℕ) (x : TransformedStage n)
      → comparison (SC.incl {n = n} x)
        ≡ map (SC.incl {n = n}) (stage-comparison n x)
    stage-computation n x = sequence-point Original.stages n (stage-comparison n x)

    sequence-computation : (n : ℕ) (x : TransformedStage n) (i : I)
      → comparison (SC.push {n = n} x i)
        ≡ sequence-comparison Original.stages
          ((SC.push (stage-comparison n x)
            ∙ cong SC.incl (sym (Attachment.left-computation n x))) i)
    sequence-computation n x i = refl

    LocalPushoutsPreserved : Type ℓ
    LocalPushoutsPreserved = (n : ℕ)
      → isEquiv (pushout-comparison (attaching-map n) (boundary-map n))

    stages-preserved : LocalPushoutsPreserved → (n : ℕ) → isEquiv (stage-comparison n)
    stages-preserved local zero = idEquiv _ .snd
    stages-preserved local (suc n) = Attachment.preservation n
      (stages-preserved local n) (local n)

    boundary-lifts-equivalent : LocalPushoutsPreserved → (n : ℕ)
      → Attachment.BoundaryLift n ≃ F (boundary-type n)
    boundary-lifts-equivalent local n = Attachment.boundary-equivalence n
      (stages-preserved local n)

    preservation : LocalPushoutsPreserved
      → isEquiv (sequence-comparison Original.stages)
      → isEquiv comparison
    preservation local sequence-preserved = compEquiv
      (isoToEquiv (SP.sequenceEquiv→ColimIso (stage-map , stages-preserved local)))
      (sequence-comparison Original.stages , sequence-preserved) .snd
