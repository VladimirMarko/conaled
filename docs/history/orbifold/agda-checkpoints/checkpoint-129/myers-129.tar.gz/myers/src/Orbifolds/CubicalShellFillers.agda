{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalShellFillers where

-- Boundary-typed cubical fillers in every dimension. The endpoints of a
-- successor filler are part of its PathP type, so their compatibility is
-- retained as actual cubical boundary data. The equivalence with the
-- homotopy fiber of restriction is proved, not supplied as a field.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Unit using (Unit; tt)
open import Orbifolds.CubicalShells using (Cube; Shell; restriction)

mutual
  Filler : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Shell n X → Type ℓ
  Filler zero {X} b = X
  Filler (suc n) ((low , high) , boundary-path) =
    PathP (λ i → Filler n (boundary-path i))
      (canonical-filler n low) (canonical-filler n high)

  canonical-filler : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (c : Cube n X)
    → Filler n (restriction n c)
  canonical-filler zero c = c
  canonical-filler (suc n) c i = canonical-filler n (c i)

Total : ∀ {ℓ} → ℕ → Type ℓ → Type ℓ
Total n X = Σ (Shell n X) (Filler n)

canonical : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Cube n X → Total n X
canonical n c = restriction n c , canonical-filler n c

-- This projection reads the literal PathP coordinates. It is preferable
-- to a chosen equivalence inverse when subsequent boundary formulae
-- need to evaluate a particular face.
forget-filler : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → Filler n b → Cube n X
forget-filler zero b c = c
forget-filler (suc n) ((low , high) , p) c i = forget-filler n (p i) (c i)

forget-canonical : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (c : Cube n X)
  → forget-filler n (restriction n c) (canonical-filler n c) ≡ c
forget-canonical zero c = refl
forget-canonical (suc n) c j i = forget-canonical n (c i) j

-- A free path is exactly two arbitrary endpoints and a path between
-- those endpoints. Both directions retain the literal cubical path.
free-path-equiv : ∀ {ℓ} (A : Type ℓ)
  → (I → A) ≃ (Σ[ ends ∈ (A × A) ] (ends .fst ≡ ends .snd))
free-path-equiv A = isoToEquiv (iso
  (λ p → (p i0 , p i1) , (λ i → p i))
  (λ p i → p .snd i)
  (λ _ → refl) (λ _ → refl))

mutual
  canonical-isEquiv : ∀ {ℓ} (n : ℕ) {X : Type ℓ}
    → isEquiv (canonical n {X})
  canonical-isEquiv zero = isoToIsEquiv (iso
    (canonical zero) snd (λ _ → refl) (λ _ → refl))
  canonical-isEquiv (suc n) {X} = successor-equivalence .snd
    where
    pair-equivalence : (ends : Cube n X × Cube n X)
      → (ends .fst ≡ ends .snd)
        ≃ (Σ[ p ∈ (restriction n (ends .fst) ≡ restriction n (ends .snd)) ]
          PathP (λ i → Filler n (p i))
            (canonical-filler n (ends .fst)) (canonical-filler n (ends .snd)))
    pair-equivalence ends = congEquiv (canonical n , canonical-isEquiv n)
      ∙ₑ invEquiv ΣPath≃PathΣ

    successor-equivalence : Cube (suc n) X ≃ Total (suc n) X
    successor-equivalence = free-path-equiv (Cube n X)
      ∙ₑ Σ-cong-equiv-snd pair-equivalence
      ∙ₑ invEquiv Σ-assoc-≃

  canonical-equivalence : ∀ {ℓ} (n : ℕ) (X : Type ℓ)
    → Cube n X ≃ Total n X
  canonical-equivalence n X = canonical n , canonical-isEquiv n

forget-total : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Total n X → Cube n X
forget-total n (b , c) = forget-filler n b c

forget-is-inverse : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (z : Total n X)
  → forget-total n z ≡ invEq (canonical-equivalence n X) z
forget-is-inverse n {X} z =
  cong (forget-total n) (sym (secEq (canonical-equivalence n X) z))
  ∙ forget-canonical n (invEq (canonical-equivalence n X) z)

reconstructed-total : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (z : Total n X)
  → canonical n (forget-total n z) ≡ z
reconstructed-total n {X} z = cong (canonical n) (forget-is-inverse n z)
  ∙ secEq (canonical-equivalence n X) z

forget-boundary : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (c : Filler n b) → restriction n (forget-filler n b c) ≡ b
forget-boundary n b c = cong fst (reconstructed-total n (b , c))

-- The comparison is over the literal shell projection. Consequently
-- its equivalence restricts to each homotopy fiber, without a separate
-- coherence or presentation hypothesis.
fiber-total-equivalence : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → fiber (restriction n) b ≃ fiber (fst {B = Filler n}) b
fiber-total-equivalence n {X} b =
  Σ-cong-equiv (canonical-equivalence n X) (λ _ → idEquiv _)

fiber-filler-equivalence : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → fiber (restriction n) b ≃ Filler n b
fiber-filler-equivalence n {X} b = fiber-total-equivalence n b
  ∙ₑ invEquiv (fiberProjEquiv (Shell n X) (Filler n) b)

filler-fiber-equivalence : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → Filler n b ≃ fiber (restriction n) b
filler-fiber-equivalence n b = invEquiv (fiber-filler-equivalence n b)

strictify : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → fiber (restriction n) b → Filler n b
strictify n b = equivFun (fiber-filler-equivalence n b)

strictify-computation : ∀ {ℓ} (n : ℕ) {X : Type ℓ}
  (b : Shell n X) (c : Cube n X) (p : restriction n c ≡ b)
  → strictify n b (c , p) ≡ subst (Filler n) p (canonical-filler n c)
strictify-computation n b c p = refl

underlying-cube : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → Filler n b → Cube n X
underlying-cube n b c = equivFun (filler-fiber-equivalence n b) c .fst

underlying-boundary : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (c : Filler n b) → restriction n (underlying-cube n b c) ≡ b
underlying-boundary n b c = equivFun (filler-fiber-equivalence n b) c .snd

strictify-underlying : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (c : Filler n b)
  → strictify n b (underlying-cube n b c , underlying-boundary n b c) ≡ c
strictify-underlying n b c = secEq (fiber-filler-equivalence n b) c

underlying-strictify : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (c : fiber (restriction n) b)
  → equivFun (filler-fiber-equivalence n b) (strictify n b c) ≡ c
underlying-strictify n b c = retEq (fiber-filler-equivalence n b) c
