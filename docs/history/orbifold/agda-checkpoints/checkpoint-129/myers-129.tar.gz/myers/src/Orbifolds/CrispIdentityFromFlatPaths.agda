{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispIdentityFromFlatPaths where

-- A conditional reconstruction of the existing crisp identity rule.
-- The uniform Flat/path equivalence is an independent crisp input.
-- No result from CrispIdentity.Theory is used to construct the rule.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv using (_≃_; invEquiv)
open import Cubical.Foundations.HLevels using (isOfHLevelRespectEquiv)
open import Cubical.Foundations.GroupoidLaws using (lCancel)
open import Cubical.Data.Sigma.Properties using (Σ-cong-equiv-snd)
open import Orbifolds.Crisp using (Flat; box)
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)

FlatPathEquivalences : {@♭ ℓ : Level} → Type (ℓ-suc ℓ)
FlatPathEquivalences {ℓ} = (@♭ A : Type ℓ) (@♭ x y : A)
  → Flat (x ≡ y) ≃ (box x ≡ box y)

module Construction {@♭ ℓ : Level} (@♭ E : FlatPathEquivalences {ℓ}) where

  -- Both arguments are ordinary Flat values. Their constructor arguments
  -- become crisp by ordinary Flat elimination, without crisp path splitting.
  Code : {@♭ A : Type ℓ} → Flat A → Flat A → Type ℓ
  Code (box x) (box y) = Flat (x ≡ y)

  module At (@♭ A : Type ℓ) (@♭ x : A) where

    Total : Type ℓ
    Total = Σ[ v ∈ Flat A ] Code (box x) v

    point : Total
    point = box x , box refl

    fiber-equivalence : (v : Flat A)
      → Code (box x) v ≃ (box x ≡ v)
    fiber-equivalence (box y) = E A x y

    total-equivalence : Total ≃ singl (box x)
    total-equivalence = Σ-cong-equiv-snd fiber-equivalence

    contraction : isContr Total
    contraction = isOfHLevelRespectEquiv 0 (invEquiv total-equivalence)
      (isContrSingl (box x))

    -- Recenter explicitly: E is not assumed to preserve reflexivity.
    from-point : (z : Total) → point ≡ z
    from-point z = sym (contraction .snd point) ∙ contraction .snd z

    from-point-refl : from-point point ≡ refl
    from-point-refl = lCancel (contraction .snd point)

    module Motive
        (@♭ P : (@♭ u v : A) → (@♭ p : u ≡ v) → Type ℓ)
        (@♭ d : (@♭ u : A) → P u u refl) where

      -- The path supplied to P comes from the ordinary Flat fiber.
      -- No ordinary equality is converted into a crisp argument.
      Family : Total → Type ℓ
      Family (box y , box p) = P x y p

      eliminate : (@♭ y : A) (@♭ p : x ≡ y) → P x y p
      eliminate y p = subst Family (from-point (box y , box p)) (d x)

      eliminate-refl : eliminate x refl ≡ d x
      eliminate-refl =
        cong (λ q → subst Family q (d x)) from-point-refl
        ∙ substRefl {B = Family} (d x)

  crisp-identity-induction : CrispIdentityInduction {ℓ}
  crisp-identity-induction = record
    { crisp-J = λ A P d x y p → At.Motive.eliminate A x P d y p
    ; crisp-J-refl = λ A P d x → At.Motive.eliminate-refl A x P d
    }

-- This supplies neither the independent input E nor a semantic model.
-- Equality throughout is the existing Cubical Path equality; the final
-- computation field is a path, not a new judgmental reduction rule.
