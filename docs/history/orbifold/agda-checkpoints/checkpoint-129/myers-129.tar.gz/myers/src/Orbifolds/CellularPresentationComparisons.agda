{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularPresentationComparisons where

-- Comparisons between two supplied cellular presentations under a type
-- operation. Every successor map is constructed from the actual maps of
-- boundaries and cells, including both boundary squares. No comparison
-- equivalence, cocone equivalence, or presentation-existence field is
-- part of the data. This is intended to consume the explicit skeleta of
-- a coherent diagram; it does not supply that diagram representation.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sequence using (SequenceMap)
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC
import Cubical.HITs.SequentialColimit.Properties as SP
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularTransformations as CT

module Theory {ℓ : Level} (O : CT.Operations ℓ) where
  open CT.Operations O renaming (map to mapF)

  module Step {A B : Type ℓ} (P : CP.Presentation A) (Q : CP.Presentation B)
      (previous : B → F A)
      (on-boundary : CP.Presentation.Boundary Q → F (CP.Presentation.Boundary P))
      (on-cell : CP.Presentation.Cells Q → F (CP.Presentation.Cells P))
      (attachment-square : previous ∘ CP.Presentation.attach Q
        ≡ mapF (CP.Presentation.attach P) ∘ on-boundary)
      (boundary-square : on-cell ∘ CP.Presentation.boundary Q
        ≡ mapF (CP.Presentation.boundary P) ∘ on-boundary) where
    private
      original-attach = CP.Presentation.attach P
      original-boundary = CP.Presentation.boundary P
      supplied-attach = CP.Presentation.attach Q
      supplied-boundary = CP.Presentation.boundary Q

    span-map : PO.Pushout supplied-attach supplied-boundary
      → PO.Pushout (mapF original-attach) (mapF original-boundary)
    span-map = PO.Pushout→ supplied-attach supplied-boundary
      (mapF original-attach) (mapF original-boundary)
      on-boundary previous on-cell attachment-square boundary-square

    next-map : PO.Pushout supplied-attach supplied-boundary
      → F (PO.Pushout original-attach original-boundary)
    next-map = pushout-comparison original-attach original-boundary ∘ span-map

    left-computation : (x : B)
      → next-map (PO.inl x)
        ≡ mapF (PO.inl {f = original-attach} {g = original-boundary}) (previous x)
    left-computation x = pushout-left original-attach original-boundary (previous x)

    right-computation : (x : CP.Presentation.Cells Q)
      → next-map (PO.inr x)
        ≡ mapF (PO.inr {f = original-attach} {g = original-boundary}) (on-cell x)
    right-computation x = pushout-right original-attach original-boundary (on-cell x)

    attachment-computation : (u : CP.Presentation.Boundary Q) (i : I)
      → next-map (PO.push u i)
        ≡ pushout-comparison original-attach original-boundary
          (((λ j → PO.inl (attachment-square j u)) ∙∙ PO.push (on-boundary u)
              ∙∙ (λ j → PO.inr (boundary-square (~ j) u))) i)
    attachment-computation u i = refl

    span-map-agrees : (boundary-equivalent : isEquiv on-boundary)
      (previous-equivalent : isEquiv previous) (cell-equivalent : isEquiv on-cell)
      (x : PO.Pushout supplied-attach supplied-boundary)
      → PO.pushoutEquiv supplied-attach supplied-boundary
          (mapF original-attach) (mapF original-boundary)
          (on-boundary , boundary-equivalent) (previous , previous-equivalent)
          (on-cell , cell-equivalent) attachment-square boundary-square .fst x
        ≡ span-map x
    span-map-agrees boundary-equivalent previous-equivalent cell-equivalent (PO.inl x) = refl
    span-map-agrees boundary-equivalent previous-equivalent cell-equivalent (PO.inr x) = refl
    span-map-agrees boundary-equivalent previous-equivalent cell-equivalent (PO.push u i) = refl

    span-isEquiv : isEquiv on-boundary → isEquiv previous → isEquiv on-cell
      → isEquiv span-map
    span-isEquiv boundary-equivalent previous-equivalent cell-equivalent =
      subst isEquiv (funExt (span-map-agrees boundary-equivalent previous-equivalent cell-equivalent))
        (PO.pushoutEquiv supplied-attach supplied-boundary
          (mapF original-attach) (mapF original-boundary)
          (on-boundary , boundary-equivalent) (previous , previous-equivalent)
          (on-cell , cell-equivalent) attachment-square boundary-square .snd)

    next-isEquiv : isEquiv on-boundary → isEquiv previous → isEquiv on-cell
      → isEquiv (pushout-comparison original-attach original-boundary)
      → isEquiv next-map
    next-isEquiv boundary-equivalent previous-equivalent cell-equivalent primitive-preserved =
      compEquiv
        (span-map , span-isEquiv boundary-equivalent previous-equivalent cell-equivalent)
        (pushout-comparison original-attach original-boundary , primitive-preserved) .snd

  record RelativeMap {A B : Type ℓ} (P : CP.Presentation A) (Q : CP.Presentation B)
      (previous : B → F A) : Type (ℓ-suc ℓ) where
    coinductive
    field
      on-boundary : CP.Presentation.Boundary Q → F (CP.Presentation.Boundary P)
      on-cell : CP.Presentation.Cells Q → F (CP.Presentation.Cells P)
      attachment-square : previous ∘ CP.Presentation.attach Q
        ≡ mapF (CP.Presentation.attach P) ∘ on-boundary
      boundary-square : on-cell ∘ CP.Presentation.boundary Q
        ≡ mapF (CP.Presentation.boundary P) ∘ on-boundary

    successor : PO.Pushout (CP.Presentation.attach Q) (CP.Presentation.boundary Q)
      → F (PO.Pushout (CP.Presentation.attach P) (CP.Presentation.boundary P))
    successor = Step.next-map P Q previous on-boundary on-cell attachment-square boundary-square

    field
      next : RelativeMap (CP.Presentation.next P) (CP.Presentation.next Q) successor

  module Realization {A B : Type ℓ} (P : CP.Presentation A) (Q : CP.Presentation B)
      (initial : B → F A) (M : RelativeMap P Q initial) where
    module Original = CP.Realization A P
    module Supplied = CP.Realization B Q

    state : (n : ℕ) → Σ[ m ∈ (Supplied.Stage n → F (Original.Stage n)) ]
      RelativeMap (Original.state n .snd) (Supplied.state n .snd) m
    state zero = initial , M
    state (suc n) .fst = RelativeMap.successor (state n .snd)
    state (suc n) .snd = RelativeMap.next (state n .snd)

    stage-map : (n : ℕ) → Supplied.Stage n → F (Original.Stage n)
    stage-map n = state n .fst

    boundary-map : (n : ℕ) → Supplied.boundary-type n → F (Original.boundary-type n)
    boundary-map n = RelativeMap.on-boundary (state n .snd)

    cell-map : (n : ℕ) → Supplied.cell-type n → F (Original.cell-type n)
    cell-map n = RelativeMap.on-cell (state n .snd)

    module Attachment (n : ℕ) = Step (Original.state n .snd) (Supplied.state n .snd)
      (stage-map n) (boundary-map n) (cell-map n)
      (RelativeMap.attachment-square (state n .snd))
      (RelativeMap.boundary-square (state n .snd))

    sequence-map : SequenceMap Supplied.stages (mapped-sequence Original.stages)
    SequenceMap.map sequence-map = stage-map
    SequenceMap.comm sequence-map n x = sym (Attachment.left-computation n x)

    comparison : Supplied.Realize → F Original.Realize
    comparison = sequence-comparison Original.stages ∘ SC.realiseSequenceMap sequence-map

    stage-computation : (n : ℕ) (x : Supplied.Stage n)
      → comparison (SC.incl {n = n} x)
        ≡ mapF (SC.incl {n = n}) (stage-map n x)
    stage-computation n x = sequence-point Original.stages n (stage-map n x)

    sequence-computation : (n : ℕ) (x : Supplied.Stage n) (i : I)
      → comparison (SC.push {n = n} x i)
        ≡ sequence-comparison Original.stages
          ((SC.push (stage-map n x)
            ∙ cong SC.incl (sym (Attachment.left-computation n x))) i)
    sequence-computation n x i = refl

    LocalCellsEquivalent : Type ℓ
    LocalCellsEquivalent = (n : ℕ) → isEquiv (boundary-map n) × isEquiv (cell-map n)

    LocalPushoutsPreserved : Type ℓ
    LocalPushoutsPreserved = (n : ℕ)
      → isEquiv (pushout-comparison (Original.attaching-map n) (Original.boundary-map n))

    stages-isEquiv : isEquiv initial → LocalCellsEquivalent → LocalPushoutsPreserved
      → (n : ℕ) → isEquiv (stage-map n)
    stages-isEquiv initial-equivalent cells local zero = initial-equivalent
    stages-isEquiv initial-equivalent cells local (suc n) = Attachment.next-isEquiv n
      (cells n .fst) (stages-isEquiv initial-equivalent cells local n)
      (cells n .snd) (local n)

    comparison-isEquiv : isEquiv initial → LocalCellsEquivalent → LocalPushoutsPreserved
      → isEquiv (sequence-comparison Original.stages) → isEquiv comparison
    comparison-isEquiv initial-equivalent cells local sequence-preserved = compEquiv
      (isoToEquiv (SP.sequenceEquiv→ColimIso
        (sequence-map , stages-isEquiv initial-equivalent cells local)))
      (sequence-comparison Original.stages , sequence-preserved) .snd

    realization-equivalence : isEquiv initial → LocalCellsEquivalent → LocalPushoutsPreserved
      → isEquiv (sequence-comparison Original.stages) → Supplied.Realize ≃ F Original.Realize
    realization-equivalence initial-equivalent cells local sequence-preserved =
      comparison , comparison-isEquiv initial-equivalent cells local sequence-preserved
