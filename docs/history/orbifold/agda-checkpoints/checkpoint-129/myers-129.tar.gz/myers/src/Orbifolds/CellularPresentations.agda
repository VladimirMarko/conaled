{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularPresentations where

-- An unbounded sequence of literal relative cell attachments. Boundary
-- maps are maps from arbitrary higher types and retain their complete
-- coherence. This supplies a model of cellular presentations; it does
-- not assert that every infinity-category diagram has such a model.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sequence using (Sequence)
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC
import Orbifolds.MappingColimits as Mapping

record Presentation {ℓ : Level} (A : Type ℓ) : Type (ℓ-suc ℓ) where
  coinductive
  field
    Boundary Cells : Type ℓ
    attach : Boundary → A
    boundary : Boundary → Cells
    next : Presentation (PO.Pushout attach boundary)
open Presentation

module Realization {ℓ : Level} (A : Type ℓ) (P : Presentation A) where
  State : Type (ℓ-suc ℓ)
  State = Σ[ B ∈ Type ℓ ] Presentation B

  advance : State → State
  advance s .fst = PO.Pushout (attach (s .snd)) (boundary (s .snd))
  advance s .snd = next (s .snd)

  state : ℕ → State
  state zero = A , P
  state (suc n) = advance (state n)

  Stage : ℕ → Type ℓ
  Stage n = state n .fst

  boundary-type cell-type : ℕ → Type ℓ
  boundary-type n = Boundary (state n .snd)
  cell-type n = Cells (state n .snd)

  attaching-map : (n : ℕ) → boundary-type n → Stage n
  attaching-map n = attach (state n .snd)

  boundary-map : (n : ℕ) → boundary-type n → cell-type n
  boundary-map n = boundary (state n .snd)

  inclusion : (n : ℕ) → Stage n → Stage (suc n)
  inclusion n = PO.inl

  stages : Sequence ℓ
  Sequence.obj stages = Stage
  Sequence.map stages {n} = inclusion n

  Realize : Type ℓ
  Realize = SC.SeqColim stages

  module MappingOut {ℓw : Level} (W : Type ℓw) where
    -- A partial cocone is defined from its lower-stage data and the
    -- new cell values and boundary filler. It is not defined as a map
    -- out of a realization. The assembly map is constructed recursively.
    mutual
      PartialCocone : ℕ → Type (ℓ-max ℓ ℓw)
      PartialCocone zero = A → W
      PartialCocone (suc n) = Σ[ c ∈ PartialCocone n ]
        Σ[ k ∈ (cell-type n → W) ]
          (assemble n c ∘ attaching-map n ≡ k ∘ boundary-map n)

      assemble : (n : ℕ) → PartialCocone n → Stage n → W
      assemble zero c = c
      assemble (suc n) (c , k , p) =
        Mapping.Span.glue (attaching-map n) (boundary-map n) W (assemble n c , k , p)

    drop : (n : ℕ) → PartialCocone (suc n) → PartialCocone n
    drop n = fst

    assemble-drop : (n : ℕ) (c : PartialCocone (suc n))
      → assemble n (drop n c) ≡ assemble (suc n) c ∘ inclusion n
    assemble-drop n c = refl

    assembly-equivalence : (n : ℕ) → PartialCocone n ≃ (Stage n → W)
    assembly-equivalence n .fst = assemble n
    assembly-equivalence zero .snd = idEquiv _ .snd
    assembly-equivalence (suc n) .snd = compEquiv
      (Σ-cong-equiv (assembly-equivalence n) (λ _ → idEquiv _))
      (invEquiv (Mapping.Span.universal (attaching-map n) (boundary-map n) W)) .snd

    assembly-computation : (n : ℕ) (c : PartialCocone n)
      → assembly-equivalence n .fst c ≡ assemble n c
    assembly-computation n c = refl

    -- Recursive maps above and equivalence maps have the same literal
    -- implementation. This separate proposition keeps future consumers
    -- from unfolding recursive equivalence certificates.
    assemble-isEquiv : (n : ℕ) → isEquiv (assemble n)
    assemble-isEquiv n = assembly-equivalence n .snd

    PartialEquiv : (n : ℕ) → PartialCocone n ≃ (Stage n → W)
    PartialEquiv n = assemble n , assemble-isEquiv n

    Cocone : Type (ℓ-max ℓ ℓw)
    Cocone = Σ[ c ∈ ((n : ℕ) → PartialCocone n) ]
      ((n : ℕ) → c n ≡ drop n (c (suc n)))

    module SequenceMaps = Mapping.SequenceCone stages W

    cocone≃sequence-cocone : Cocone ≃ SequenceMaps.Cocone
    cocone≃sequence-cocone = Σ-cong-equiv
      (equivΠCod PartialEquiv)
      (λ _ → equivΠCod (λ n → congEquiv (PartialEquiv n)))

    assemble-all : Cocone → Realize → W
    assemble-all c = SequenceMaps.glue (cocone≃sequence-cocone .fst c)

    mapping-universal : (Realize → W) ≃ Cocone
    mapping-universal = compEquiv SequenceMaps.universal (invEquiv cocone≃sequence-cocone)

    assemble-all-isEquiv : isEquiv assemble-all
    assemble-all-isEquiv = compEquiv cocone≃sequence-cocone
      (invEquiv SequenceMaps.universal) .snd

    stage-computation : (c : Cocone) (n : ℕ) (x : Stage n)
      → assemble-all c (SC.incl {n = n} x) ≡ assemble n (c .fst n) x
    stage-computation c n x = refl

    cell-computation : (c : Cocone) (n : ℕ) (x : cell-type n)
      → assemble-all c (SC.incl {n = suc n} (PO.inr x))
        ≡ c .fst (suc n) .snd .fst x
    cell-computation c n x = refl

    attachment-computation : (c : Cocone) (n : ℕ) (b : boundary-type n) (i : I)
      → assemble-all c (SC.incl {n = suc n} (PO.push b i))
        ≡ c .fst (suc n) .snd .snd i b
    attachment-computation c n b i = refl

    sequence-computation : (c : Cocone) (n : ℕ) (x : Stage n) (i : I)
      → assemble-all c (SC.push {n = n} x i)
        ≡ assemble n (c .snd n i) x
    sequence-computation c n x i = refl
