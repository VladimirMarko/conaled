{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportUniversal where

-- A constructed direct-sum universal property for the finite-support
-- carrier. The extension evaluates the unique finite sum constructed
-- in FiniteSupportSums; it does not select a support representative.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; inl; inr )
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( nn-map; SupportBound; SupportWitness; FiniteSupport
  ; finite-support-path; zero-support )
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; module Sums)

private variable ℓ : Level

IsAdditive : (M N : AdditiveMonoid ℓ)
  → (AdditiveMonoid.Carrier M → AdditiveMonoid.Carrier N) → Set ℓ
IsAdditive M N f =
  Σ (f (AdditiveMonoid.zero M) ≡ AdditiveMonoid.zero N) λ _ →
    (x y : AdditiveMonoid.Carrier M) →
      f (AdditiveMonoid._+_ M x y) ≡ AdditiveMonoid._+_ N (f x) (f y)

AddHom : (M N : AdditiveMonoid ℓ) → Set ℓ
AddHom M N = Σ (AdditiveMonoid.Carrier M → AdditiveMonoid.Carrier N) (IsAdditive M N)

additive-zero : {M N : AdditiveMonoid ℓ} (h : AddHom M N)
  → fst h (AdditiveMonoid.zero M) ≡ AdditiveMonoid.zero N
additive-zero h = fst (snd h)

additive-add : {M N : AdditiveMonoid ℓ} (h : AddHom M N)
  → (x y : AdditiveMonoid.Carrier M)
  → fst h (AdditiveMonoid._+_ M x y) ≡ AdditiveMonoid._+_ N (fst h x) (fst h y)
additive-add h = snd (snd h)

additive-prop : (ext : FunExt ℓ ℓ) (M N : AdditiveMonoid ℓ)
  → (f : AdditiveMonoid.Carrier M → AdditiveMonoid.Carrier N) → isProp (IsAdditive M N f)
additive-prop ext M N f = isPropΣ (AdditiveMonoid.carrier-set N _ _)
  (λ _ → isPropΠ ext (λ x → isPropΠ ext (λ y → AdditiveMonoid.carrier-set N _ _)))

add-hom-path : (ext : FunExt ℓ ℓ) {M N : AdditiveMonoid ℓ}
  → {h k : AddHom M N} → fst h ≡ fst k → h ≡ k
add-hom-path ext {M = M} {N = N} = Σ-path-prop (additive-prop ext M N)

identity-add-hom : (M : AdditiveMonoid ℓ) → AddHom M M
identity-add-hom M = (λ x → x) , (refl , λ x y → refl)

compose-add-hom : {M N P : AdditiveMonoid ℓ}
  → AddHom N P → AddHom M N → AddHom M P
compose-add-hom {M = M} {N = N} {P = P} g f = (λ x → fst g (fst f x)) ,
  ((cong (fst g) (additive-zero {M = M} {N = N} f) ∙ additive-zero {M = N} {N = P} g) ,
    (λ x y → cong (fst g) (additive-add {M = M} {N = N} f x y)
      ∙ additive-add {M = N} {N = P} g (fst f x) (fst f y)))

module DirectSum {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I)
    (M N : AdditiveMonoid ℓ) where

  module SM = Sums ext classical equality M
  module SN = Sums ext classical equality N

  V = AdditiveMonoid.Carrier M
  W = AdditiveMonoid.Carrier N
  zeroV = AdditiveMonoid.zero M
  zeroW = AdditiveMonoid.zero N
  _+W_ = AdditiveMonoid._+_ N
  FS-M = SM.finite-support-monoid

  map-family-bound : (h : I → AddHom M N) (f : I → V) (xs : List I)
    → SupportBound zeroV f xs → SupportBound zeroW (λ i → fst (h i) (f i)) xs
  map-family-bound h f xs bound i absent =
    cong (fst (h i)) (bound i absent) ∙ additive-zero {M = M} {N = N} (h i)

  map-family : (I → AddHom M N) → FiniteSupport I zeroV → FiniteSupport I zeroW
  map-family h u = (λ i → fst (h i) (fst u i)) ,
    nn-map (λ { (xs , bound) → xs , map-family-bound h (fst u) xs bound }) (snd u)

  map-family-zero : (h : I → AddHom M N)
    → map-family h (zero-support zeroV) ≡ zero-support zeroW
  map-family-zero h = finite-support-path ext (ext (λ i → additive-zero {M = M} {N = N} (h i)))

  map-family-add : (h : I → AddHom M N) (u v : FiniteSupport I zeroV)
    → map-family h (SM.add u v) ≡ SN.add (map-family h u) (map-family h v)
  map-family-add h u v = finite-support-path ext
    (ext (λ i → additive-add {M = M} {N = N} (h i) (fst u i) (fst v i)))

  extension : (I → AddHom M N) → AddHom FS-M N
  extension h = (λ u → SN.Sum (map-family h u)) ,
    ((cong SN.Sum (map-family-zero h) ∙ SN.sum-zero) ,
      (λ u v → cong SN.Sum (map-family-add h u v)
        ∙ SN.sum-add (map-family h u) (map-family h v)))

  single-hom : I → AddHom M FS-M
  single-hom i = SM.single i , (SM.single-zero i , SM.single-add i)

  restriction : AddHom FS-M N → I → AddHom M N
  restriction k i = compose-add-hom {M = M} {N = FS-M} {P = N} k (single-hom i)

  map-single-coordinate : (h : I → AddHom M N) (i : I) (v : V) (j : I)
    → fst (h j) (SM.delta i v j) ≡ SN.delta i (fst (h i) v) j
  map-single-coordinate h i v j with equality j i
  ... | inl equal = cong (λ index → fst (h index) v) equal
  ... | inr different = additive-zero {M = M} {N = N} (h j)

  extension-on-single : (h : I → AddHom M N) (i : I) (v : V)
    → fst (extension h) (SM.single i v) ≡ fst (h i) v
  extension-on-single h i v =
    cong SN.Sum (finite-support-path ext
      {u = map-family h (SM.single i v)} {v = SN.single i (fst (h i) v)}
      (ext (map-single-coordinate h i v)))
    ∙ SN.sum-single i (fst (h i) v)

  hom-erased-coordinate : (k : AddHom FS-M N)
    → (a : I) (u : FiniteSupport I zeroV) (i : I)
    → fst k (SM.single i (SM.erase a (fst u) i))
      ≡ SN.erase a (λ j → fst k (SM.single j (fst u j))) i
  hom-erased-coordinate k a u i with equality i a
  ... | inl equal = cong (fst k) (SM.single-zero i) ∙ additive-zero {M = FS-M} {N = N} k
  ... | inr different = refl

  -- This induction uses a given support witness only to prove an
  -- equality. The global evaluator below eliminates NN into that
  -- proposition using the displayed classical parameter.
  hom-on-bound : (k : AddHom FS-M N) (u : FiniteSupport I zeroV) (xs : List I)
    → SupportBound zeroV (fst u) xs
    → fst k u ≡ SN.list-sum xs (λ i → fst k (SM.single i (fst u i)))
  hom-on-bound k u [] bound =
    cong (fst k) (finite-support-path ext {u = u} {v = zero-support zeroV}
      (ext (λ i → bound i (λ ()))))
    ∙ additive-zero {M = FS-M} {N = N} k
  hom-on-bound k u (a ∷ xs) bound =
    cong (fst k) (SM.split-finite a u)
    ∙ additive-add {M = FS-M} {N = N} k (SM.single a (fst u a)) (SM.erase-finite a u)
    ∙ cong (λ q → fst k (SM.single a (fst u a)) +W q)
      (hom-on-bound k (SM.erase-finite a u) xs (SM.support-tail a (fst u) xs bound)
        ∙ SN.list-sum-cong xs
          (λ i → fst k (SM.single i (SM.erase a (fst u) i)))
          (SN.erase a (λ i → fst k (SM.single i (fst u i))))
          (hom-erased-coordinate k a u))

  extension-restriction : (k : AddHom FS-M N) (u : FiniteSupport I zeroV)
    → fst (extension (restriction k)) u ≡ fst k u
  extension-restriction k u = classical (AdditiveMonoid.carrier-set N _ _)
    (nn-map (λ { (xs , bound) →
      SN.sum-on-bound (map-family (restriction k) u) xs
        (map-family-bound (restriction k) (fst u) xs bound)
      ∙ sym (hom-on-bound k u xs bound) }) (snd u))

  direct-sum-universal : Equiv (AddHom FS-M N) (I → AddHom M N)
  direct-sum-universal = equiv restriction extension
    (λ h → ext (λ i → add-hom-path ext {M = M} {N = N} (ext (extension-on-single h i))))
    (λ k → add-hom-path ext {M = FS-M} {N = N} (ext (extension-restriction k)))

  hom-determined-on-singles : (k l : AddHom FS-M N)
    → ((i : I) (v : V) → fst k (SM.single i v) ≡ fst l (SM.single i v))
    → k ≡ l
  hom-determined-on-singles k l same =
    sym (retraction direct-sum-universal k)
    ∙ cong extension {x = restriction k} {y = restriction l}
      (ext (λ i → add-hom-path ext {M = M} {N = N}
        {h = restriction k i} {k = restriction l i} (ext (same i))))
    ∙ retraction direct-sum-universal l
