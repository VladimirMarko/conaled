{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrystallineManifoldFibers where

-- Fibers of a crystalline-etale map between manifolds are shape-modal.
-- Ordinary charts supply local constancy. The actual Penon disk map
-- supplies separated equality in a fiber, so the compact interval
-- argument gives equality, not just double-negated equality.
-- No decidable-equality conclusion is inferred from shape modality.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Functions.Embedding
open import Cubical.Algebra.CommRing.Base
open import Cubical.Categories.Category using (Category)

open import Orbifolds.Topology using (Topology; Regular)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
open import Orbifolds.GroupoidCompletion using (AllInvertible)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallineEuclidean as CE
import Orbifolds.OrdinaryCharts as OC
import Orbifolds.PenonManifolds as PM
import Orbifolds.CountableRealProbe as RP
import Orbifolds.CompactIntervals as IC
import Orbifolds.IntervalParameterization as IP
import Orbifolds.CrystallineManifoldCurves as MC
import Orbifolds.CrystallinePenonEtale as PE
import Orbifolds.GroupoidEtale as GE

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
    (constancy : CE.Ring.PrincipleOfConstancy R) where
  open CR.Ring R
  open CommRingStr (R .snd) using (0r)
  module Probe = RP.RealProbe R kock order compatibility
  module Intervals = IC.Interpolation R kock order compatibility
  module Param = IP.Parameterization R kock order compatibility
  module Curves = MC.Geometry R kock order compatibility constancy
  module Penon = PM.Geometry R
  module CrystalOperations = CE.Ring.Operations R

  shape-modal-propositions : {P : Type ℓ} → isProp P → IsShapeModal P
  shape-modal-propositions prop _ = fromIsEquiv const
    (isoToIsEquiv (iso const (λ f → f 0r)
      (λ f → funExt λ t → prop (f 0r) (f t)) (λ _ → refl)))

  shape-modal-subtype : {X : Type ℓ} → IsShapeModal X
    → (P : X → hProp ℓ) → IsShapeModal (Σ[ x ∈ X ] P x .fst)
  shape-modal-subtype modalX P = Shape.Σ-isModal (λ x → P x .fst)
    modalX (λ x → shape-modal-propositions (P x .snd))

  module Map {X Y : Type ℓ} (n m : ℕ)
      (euclidean-topology : Topology (FD.Fin n → Carrier))
      (euclidean-regular : Regular euclidean-topology)
      (source-manifold : OC.Geometry.OrdinaryManifold R n X euclidean-topology)
      (target-manifold : Penon.PenonManifold Y m) (f : X → Y) where
    module SourceCharts = OC.Geometry R n
    source-penon : Penon.PenonManifold X n
    source-penon = SourceCharts.ordinary-is-penon
      euclidean-topology euclidean-regular source-manifold

    module Disks = PE.Ring.Map R source-penon target-manifold f
    module ManifoldCurves = Curves.Manifold n euclidean-topology source-manifold

    fiber-embedding : (y : Y) → fiber f y ↪ X
    fiber-embedding y = EmbeddingΣProp
      (λ x → Penon.PenonManifold.points-set target-manifold (f x) y)

    crystalline-etale-fibers-shape-modal : CoveringProperty Probe.intervalBalls
      → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
      → Crystal.Etale f → (y : Y) → IsShapeModal (fiber f y)
    crystalline-etale-fibers-shape-modal covering compact-interval exponential etale y =
      ManifoldCurves.Subspace.crystalline-separated-shape-modal
        (fiber-embedding y) (CrystalOperations.etale-modal-fibres f etale y)
        covering compact-interval exponential
        (Disks.crystalline-etale-fibers-separated etale y)

  -- For a groupoid, its genuine hom type is the propositional target
  -- subtype of a source fiber. All points x,y remain ordinary variables.
  module Groupoid (C : Category ℓ ℓ) (invertible : AllInvertible C)
      (n m : ℕ)
      (euclidean-topology : Topology (FD.Fin n → Carrier))
      (euclidean-regular : Regular euclidean-topology)
      (arrow-manifold : OC.Geometry.OrdinaryManifold R n
        (GE.Presentation.Arrows C invertible) euclidean-topology)
      (object-manifold : Penon.PenonManifold (Category.ob C) m) where
    module Presentation = GE.Presentation C invertible
    open Presentation using (Objects; Hom; source; target; hom≃source-target-fiber)
    module Fibers = Map n m euclidean-topology euclidean-regular
      arrow-manifold object-manifold source

    crystalline-etale-homs-shape-modal : CoveringProperty Probe.intervalBalls
      → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
      → Crystal.Etale source → (x y : Objects) → IsShapeModal (Hom x y)
    crystalline-etale-homs-shape-modal covering compact-interval exponential etale x y =
      Shape.equivPreservesIsModal (invEquiv (hom≃source-target-fiber x y))
        (shape-modal-subtype
          (Fibers.crystalline-etale-fibers-shape-modal covering compact-interval exponential etale x)
          (λ a → (target (a .fst) ≡ y) ,
            Penon.PenonManifold.points-set object-manifold (target (a .fst)) y))
