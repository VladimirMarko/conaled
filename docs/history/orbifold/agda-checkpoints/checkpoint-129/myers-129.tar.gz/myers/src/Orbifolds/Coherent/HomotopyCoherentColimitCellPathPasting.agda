{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitCellPathPasting where

-- Compose the constructed source-stage restriction triangle with an
-- actual cell-cocone path before a large target diagram/map is substituted.
-- The middle endpoint is the original Step.cell-restrict constant. The
-- exact constructed path and its full first-projection law are retained.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.GroupoidLaws using (cong-∙)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle as RestrictionTriangle

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  module CD = Cocones.Functoriality C D E F using (Cocone; postcompose)
  module Step = Stages.Construction.Step C D E F n previous
    using (Realize; canonical-cocone; cell-restrict; transition-computation)
  module Triangle = RestrictionTriangle.Construction C D E F n previous
    using (canonical-restriction-comparison; canonical-transition-coherence)

  Previous : Type ℓ
  Previous = Represented.Induction.Represented.Space previous

  previous-cocone : CD.Cocone Previous n
  previous-cocone = Represented.Induction.Represented.universal-cocone previous

  CellCocone : Type ℓ → Type ℓ
  CellCocone = Stages.Construction.Step.Cell.Cocone C D E F n previous

  compare : (Y : Type ℓ) → CellCocone Y → CD.Cocone Y (osuc n)
  compare = Stages.Construction.Step.Comparison.compare C D E F n previous

  -- Infer the result from these exact constructed paths before sealing.
  -- The mandatory no-unsolved-metas gate closes both inferred annotations.
  paste-cell-impl : (Y : Type ℓ) (h : Step.Realize → Y) (s : CellCocone Y)
    (p : Step.cell-restrict Y h ≡ s) → _
  paste-cell-impl Y h s p = Triangle.canonical-restriction-comparison Y h
    ∙ cong {A = CellCocone Y} {B = λ _ → CD.Cocone Y (osuc n)} (compare Y) p

  abstract
    paste-cell : RestrictionTriangle.typeOf paste-cell-impl
    paste-cell = paste-cell-impl

    construction : (Y : Type ℓ) (h : Step.Realize → Y) (s : CellCocone Y)
      (p : Step.cell-restrict Y h ≡ s)
      → outer (paste-cell Y h s p)
        ≡ˢ outer (paste-cell-impl Y h s p)
    construction Y h s p = reflˢ

    paste-cell-prefix : (Y : Type ℓ) (h : Step.Realize → Y) (s : CellCocone Y)
      (p : Step.cell-restrict Y h ≡ s)
      → cong {A = CD.Cocone Y (osuc n)} {B = λ _ → CD.Cocone Y n}
          fst (paste-cell Y h s p)
        ≡ strict-to-path {A = CD.Cocone Y n} (Step.transition-computation Y h)
          ∙ cong {A = Previous → Y} {B = λ _ → CD.Cocone Y n}
              (λ k → CD.postcompose n {Y = Previous} {Z = Y} k previous-cocone)
              (cong {A = CellCocone Y} {B = λ _ → Previous → Y} fst p)
    paste-cell-prefix Y h s p =
      cong-∙ fst (Triangle.canonical-restriction-comparison Y h)
        (cong {A = CellCocone Y} {B = λ _ → CD.Cocone Y (osuc n)} (compare Y) p)
      ∙ cong₂ _∙_ (Triangle.canonical-transition-coherence Y h) refl
