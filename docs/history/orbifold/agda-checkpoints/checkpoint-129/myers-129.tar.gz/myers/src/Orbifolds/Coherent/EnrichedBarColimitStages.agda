{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarColimitStages where

-- Construct every finite bar colimit stage. The successor is a literal
-- pushout, and its actual canonical cocone represents the full next
-- coherent cocone type. Naturality comes from the constructed action,
-- explicit quotation fibers, and proved strict boundary comparisons.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.EnrichedMappingDiagrams as Mapping
import Orbifolds.Coherent.EnrichedBarFiniteStages as Finite
import Orbifolds.Coherent.EnrichedBarRepresentedStages as Represented
import Orbifolds.Coherent.EnrichedBarCoconeFunctoriality as Cocones
import Orbifolds.Coherent.EnrichedBarCellStageComparison as StageComparison

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module R = Represented.Induction C D E F
  open Cocones.Functoriality C D E F using (Cocone; postcompose)

  module Step (n : Dim) (previous : R.Represented n) where
    module Comparison = StageComparison.Comparison C D E F n previous
    module Cell = Comparison.Cell

    Realize : Type ℓ
    Realize = Cell.Realize

    canonical-cocone : Cocone Realize (osuc n)
    canonical-cocone = Comparison.compare Realize Cell.canonical-cocone

    constructed-universal : (Y : Type ℓ) → (Realize → Y) ≃ Cocone Y (osuc n)
    constructed-universal Y = Cell.Target.universal Y ∙ₑ Comparison.comparison Y

    canonical-restriction-comparison : (Y : Type ℓ) (h : Realize → Y)
      → postcompose (osuc n) h canonical-cocone ≡ constructed-universal Y .fst h
    canonical-restriction-comparison Y h =
      strict-to-path (Comparison.compare-natural h Cell.canonical-cocone)
      ∙ cong (Comparison.compare Y) (Cell.restrict-natural h (idfun Realize))

    next : R.Represented (osuc n)
    R.Represented.Space next = Realize
    R.Represented.universal-cocone next = canonical-cocone
    R.Represented.restriction-isEquiv next Y = subst isEquiv
      (sym (funExt (canonical-restriction-comparison Y))) (constructed-universal Y .snd)

  stage : (n : Dim) → R.Represented n
  stage ozero = R.initial
  stage (osuc n) = Step.next n (stage n)

  Space : Dim → Type ℓ
  Space n = R.Represented.Space (stage n)

  universal-cocone : (n : Dim) → Cocone (Space n) n
  universal-cocone n = R.Represented.universal-cocone (stage n)

  universal : (n : Dim) (Y : Type ℓ) → (Space n → Y) ≃ Cocone Y n
  universal n = R.Represented.universal (stage n)

  include : (n : Dim) → Space n → Space (osuc n)
  include n = Step.Cell.include n (stage n)

  restriction-computation : (n : Dim) (Y : Type ℓ) (h : Space n → Y)
    → universal n Y .fst h ≡ postcompose n h (universal-cocone n)
  restriction-computation n Y h = refl

  transition-computation : (n : Dim) (Y : Type ℓ) (h : Space (osuc n) → Y)
    → outer (Finite.Finite.transition (Opposite C) (Mapping.Mapping.Into D Y) E n
        (universal (osuc n) Y .fst h))
      ≡ˢ outer (universal n Y .fst (h ∘ include n))
  transition-computation n Y h = Cocones.Functoriality.postcompose-compose C D E F n
    (include n) h (universal-cocone n)
