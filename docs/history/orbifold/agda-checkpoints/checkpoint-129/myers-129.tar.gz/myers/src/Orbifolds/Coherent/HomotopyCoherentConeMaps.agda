{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentConeMaps where

-- Exact coherent transformations act on the actual full cone type.
-- A coinductive witness transfers constructed finite stage maps to
-- the ordinary-natural inverse tower, retaining every square.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties using (congEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalFillerCastCoherence using (cast-filler-equivalence)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentFiniteTransformations as FiniteMaps
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentConeStages as Stages
import Orbifolds.Coherent.NaturalCubicalFillerEquivalences as Fillers
import Orbifolds.CubicalShellFillers as CF

module Action {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) where
  module Maps = Transformations.ForCategory C
  module α = Maps.Transformation α
  module Source = Stages.Construction C D E
  module Target = Stages.Construction C G E
  module SourceFinite = Finite.Finite C D E
  module TargetFinite = Finite.Finite C G E
  module FiniteAction = FiniteMaps.Action D G α E
  SourceFiber : {P : Type ℓ} → Source.Schedule P → P → Type ℓ
  SourceFiber S s = (c : Source.Schedule.Cells S) → CF.Filler
    (Source.Schedule.dimension S c) (Source.Schedule.boundary S s c)

  TargetFiber : {Q : Type ℓ} → Target.Schedule Q → Q → Type ℓ
  TargetFiber T t = (c : Target.Schedule.Cells T) → CF.Filler
    (Target.Schedule.dimension T c) (Target.Schedule.boundary T t c)

  record Morphism {P Q : Type ℓ} (S : Source.Schedule P) (T : Target.Schedule Q)
      (f : P → Q) : Type ℓ where
    coinductive
    field
      fiber-map : (s : P) → SourceFiber S s → TargetFiber T (f s)
      tail : Morphism (Source.Schedule.tail S) (Target.Schedule.tail T)
        (λ s → f (s .fst) , fiber-map (s .fst) (s .snd))

  finite-morphism : (n : Dim) → Morphism
    (SourceFinite.finite-state n .snd) (TargetFinite.finite-state n .snd) (FiniteAction.stage-map n)
  Morphism.fiber-map (finite-morphism n) s cs = FiniteAction.stage-map (osuc n) (s , cs) .snd
  Morphism.tail (finite-morphism n) = finite-morphism (osuc n)

  mutual
    partial-map : (n : ℕ) → Source.PartialCone n → Target.PartialCone n
    partial-map zero = FiniteAction.stage-map ozero
    partial-map (suc n) s = partial-map n (s .fst) ,
      Morphism.fiber-map (morphism-at n) (s .fst) (s .snd)

    morphism-at : (n : ℕ) → Morphism (Source.stage-schedule n) (Target.stage-schedule n) (partial-map n)
    morphism-at zero = finite-morphism ozero
    morphism-at (suc n) = Morphism.tail (morphism-at n)

  partial-square : (n : ℕ) (s : Source.PartialCone (suc n))
    → Target.drop n (partial-map (suc n) s) ≡ partial-map n (Source.drop n s)
  partial-square n s = refl

  cone-map : Source.Limit → Target.Limit
  cone-map s .fst n = partial-map n (s .fst n)
  cone-map s .snd n i = partial-map n (s .snd n i)

  projection-computation : (s : Source.Limit) (n : ℕ)
    → Target.projection n (cone-map s) ≡ partial-map n (Source.projection n s)
  projection-computation s n = refl

  compatibility-computation : (s : Source.Limit) (n : ℕ)
    → Target.projection-square n (cone-map s)
      ≡ cong (partial-map n) (Source.projection-square n s)
  compatibility-computation s n = refl

  record EquivalenceWitness {P Q : Type ℓ} {S : Source.Schedule P} {T : Target.Schedule Q}
      {f : P → Q} (m : Morphism S T f) : Type ℓ where
    coinductive
    field
      current-isEquiv : isEquiv f
      tail : EquivalenceWitness (Morphism.tail m)

  module Equivalence (pointwise : (x : Category.Obj C) → isEquiv (α.component x)) where
    module Filler = Fillers.Equivalences E

    finite-isEquiv : (n : Dim) → isEquiv (FiniteAction.stage-map n)
    finite-isEquiv ozero = equivΠCod (λ x → α.component x , pointwise x) .snd
    finite-isEquiv (osuc n) = Σ-cong-equiv
      (FiniteAction.stage-map n , finite-isEquiv n)
      (λ s → equivΠCod λ { (y , c) →
        Filler.map-filler-equivalence (osuc n) (α.component y , pointwise y)
          (SourceFinite.At.boundary-data n s (y , c))
        ∙ₑ cast-filler-equivalence (osuc n)
          (FiniteAction.boundary-related n (SourceFinite.families n) (TargetFinite.families n)
            (SourceFinite.coherent n) (TargetFinite.coherent n)
            s (FiniteAction.stage-map n s) (FiniteAction.stage-related n s) y c) }) .snd

    finite-equivalence-witness : (n : Dim) → EquivalenceWitness (finite-morphism n)
    EquivalenceWitness.current-isEquiv (finite-equivalence-witness n) = finite-isEquiv n
    EquivalenceWitness.tail (finite-equivalence-witness n) = finite-equivalence-witness (osuc n)

    equivalence-witness-at : (n : ℕ) → EquivalenceWitness (morphism-at n)
    equivalence-witness-at zero = finite-equivalence-witness ozero
    equivalence-witness-at (suc n) = EquivalenceWitness.tail (equivalence-witness-at n)

    partial-isEquiv : (n : ℕ) → isEquiv (partial-map n)
    partial-isEquiv n = EquivalenceWitness.current-isEquiv (equivalence-witness-at n)

    cone-map-isEquiv : isEquiv cone-map
    cone-map-isEquiv = Σ-cong-equiv (equivΠCod (λ n → partial-map n , partial-isEquiv n))
      (λ s → equivΠCod λ n → congEquiv (partial-map n , partial-isEquiv n)) .snd
