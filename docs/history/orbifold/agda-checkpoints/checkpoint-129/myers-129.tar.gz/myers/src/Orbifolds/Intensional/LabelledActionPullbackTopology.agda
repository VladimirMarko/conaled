{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LabelledActionPullbackTopology where

-- The topology on G x (G x X) is an iterated coproduct. Its pullback
-- property is proved for arbitrary continuous cones by open label slices.
-- Uniqueness concerns underlying maps, not their continuity certificates.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity hiding (lift)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; Included; Product; full; intersection
  ; OpenFragment; IsOpen; open-full; open-transfer; open-intersection; open-local )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
import Orbifolds.Intensional.OpenSubspaces as OS

continuous-pointwise : {ℓ : Level} {A B : Set ℓ}
  (OA : OpenFragment A) (OB : OpenFragment B) (f g : A → B)
  → ((a : A) → f a ≡ g a) → Continuous OA OB f → Continuous OA OB g
continuous-pointwise OA OB f g equal continuous U open-U =
  open-transfer OA {P = preimage f U} {Q = preimage g U}
    (λ a inside → subst (member U) (equal a) inside)
    (λ a inside → subst (member U) (sym (equal a)) inside)
    (continuous U open-U)

module Construction {ℓ : Level} {G X : Set ℓ}
    (setG : isSet G) (OX : OpenFragment X) (act : G → X → X)
    (act-continuous : (g : G) → Continuous OX OX (act g)) where

  Arrows : Set ℓ
  Arrows = Product G X

  Pairs : Set ℓ
  Pairs = Product G Arrows

  arrowTopology : OpenFragment Arrows
  arrowTopology = OS.sumOpenFragment (λ (_ : G) → OX)

  pairTopology : OpenFragment Pairs
  pairTopology = OS.sumOpenFragment (λ (_ : G) → arrowTopology)

  source : Arrows → X
  source = snd

  target : Arrows → X
  target a = act (fst a) (snd a)

  source-continuous : Continuous arrowTopology OX source
  source-continuous U open-U g = open-U

  target-continuous : Continuous arrowTopology OX target
  target-continuous U open-U g = act-continuous g U open-U

  first : Pairs → Arrows
  first = snd

  second : Pairs → Arrows
  second p = fst p , target (snd p)

  square : (p : Pairs) → target (first p) ≡ source (second p)
  square p = refl

  first-continuous : Continuous pairTopology arrowTopology first
  first-continuous U open-U h = open-U

  second-continuous : Continuous pairTopology arrowTopology second
  second-continuous U open-U h g =
    act-continuous g (preimage (λ x → h , x) U) (open-U h)

  label-slice : G → Subset Arrows
  member (label-slice g) a = fst a ≡ g
  member-prop (label-slice g) a = setG (fst a) g

  label-slice-open : (g : G) → IsOpen arrowTopology (label-slice g)
  label-slice-open g h =
    open-local OX (preimage (λ x → h , x) (label-slice g))
      (λ x equal → full , open-full OX , tt , (λ y _ → equal))

  module Cone {Z : Set ℓ} (OZ : OpenFragment Z) (u v : Z → Arrows)
      (u-continuous : Continuous OZ arrowTopology u)
      (v-continuous : Continuous OZ arrowTopology v)
      (commute : (z : Z) → target (u z) ≡ source (v z)) where

    lift : Z → Pairs
    lift z = fst (v z) , u z

    lift-first : (z : Z) → first (lift z) ≡ u z
    lift-first z = refl

    lift-second : (z : Z) → second (lift z) ≡ v z
    lift-second z = cong (λ x → fst (v z) , x) (commute z)

    lift-unique : (k : Z → Pairs)
      → ((z : Z) → first (k z) ≡ u z)
      → ((z : Z) → second (k z) ≡ v z)
      → (z : Z) → k z ≡ lift z
    lift-unique k first-law second-law z =
      cong (λ h → h , first (k z)) (cong fst (second-law z))
      ∙ cong (λ a → fst (v z) , a) (first-law z)

    lift-continuous : Continuous OZ pairTopology lift
    lift-continuous W open-W = open-local OZ (preimage lift W) neighborhood
      where
      neighborhood : (z : Z) → member W (lift z)
        → Σ (Subset Z) (λ N → Σ (IsOpen OZ N)
          (λ _ → Σ (member N z) (λ _ → Included N (preimage lift W))))
      neighborhood z at-W = N , open-N , at-N , inside-N
        where
        h₀ g₀ : G
        h₀ = fst (v z)
        g₀ = fst (u z)

        slice-W : Subset X
        slice-W = preimage (λ x → h₀ , g₀ , x) W

        slice-W-open : IsOpen OX slice-W
        slice-W-open = open-W h₀ g₀

        first-patch : Subset Arrows
        first-patch = intersection (label-slice g₀) (preimage source slice-W)

        first-patch-open : IsOpen arrowTopology first-patch
        first-patch-open = open-intersection arrowTopology
          {P = label-slice g₀} {Q = preimage source slice-W}
          (label-slice-open g₀) (source-continuous slice-W slice-W-open)

        N : Subset Z
        N = intersection (preimage u first-patch) (preimage v (label-slice h₀))

        open-N : IsOpen OZ N
        open-N = open-intersection OZ
          {P = preimage u first-patch} {Q = preimage v (label-slice h₀)}
          (u-continuous first-patch first-patch-open)
          (v-continuous (label-slice h₀) (label-slice-open h₀))

        at-N : member N z
        at-N = (refl , at-W) , refl

        fixed-labels : (w : Z) → fst (u w) ≡ g₀ → fst (v w) ≡ h₀
          → lift w ≡ (h₀ , g₀ , source (u w))
        fixed-labels w first-label second-label =
          cong (λ h → h , u w) second-label
          ∙ cong (λ g → h₀ , g , source (u w)) first-label

        inside-N : Included N (preimage lift W)
        inside-N w ((first-label , inside) , second-label) =
          subst (member W) (sym (fixed-labels w first-label second-label)) inside

-- IsOpen pairTopology W quantifies only over the small label carriers G.
-- The proof uses the existing open-local field; it does not resize the
-- type of arbitrary rectangle witnesses into an IsOpen proposition.
