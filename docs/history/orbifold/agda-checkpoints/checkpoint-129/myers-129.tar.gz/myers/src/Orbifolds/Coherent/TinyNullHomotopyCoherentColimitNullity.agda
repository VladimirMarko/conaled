{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyNullHomotopyCoherentColimitNullity where

-- Specialize the proved actual coherent-colimit closure theorem to the
-- fully constructed native nullification diagram. Its vertices are null
-- by the native HIT theorem. No preservation premise is supplied.

open import Cubical.Foundations.Prelude
import Cubical.HITs.Nullification.Base as NB
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as PP
import Orbifolds.TinyTypes as TT
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentNullification as Reflection
import Orbifolds.Coherent.HomotopyCoherentColimitCells as BarCells
import Orbifolds.Coherent.TinyNullHomotopyCoherentColimitClosure as Closure

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ Ix : Type₀) (@♭ S : Ix → Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C)
    (@♭ E : StrictCubicalExtensionality ℓ) (@♭ F : StrictFunctionExtensionality ℓ) where
  open Category C

  reflected : HC.ForCategory.Diagram C
  reflected = Reflection.Reflection.reflected C D S E

  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = PP.Context.RealFlat R r₀

  TinyFamily : Type (ℓ-suc ℓ)
  TinyFamily = (@♭ i : Ix) → TT.External.Tiny (S i)

  vertices-null : (x : Obj) → NB.isNull S (HC.ForCategory.Diagram.Value reflected x)
  vertices-null x = NB.isNull-Null S

  module Proof (real-flat : RealFlat) (discrete-generators : CrisplyDiscrete Ix)
      (tiny : TinyFamily) (discrete-objects : CrisplyDiscrete Obj)
      (discrete-homs : (@♭ x y : Obj) → CrisplyDiscrete (Hom x y)) where

    colimit-null : NB.isNull S (BarCells.Construction.Colimit C reflected E F)
    colimit-null = Closure.Context.Proof.colimit-null
      identity-rules flat-induction flat-computation
      identity-zero flat-zero flat-zero-computation R r₀ Ix S C reflected E F
      real-flat discrete-generators tiny discrete-objects discrete-homs vertices-null
