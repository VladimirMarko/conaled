{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderWeilPushouts where

-- Transport the actual axis squares to actual square-zero Weil
-- spectra.  The entire pointed square is transported coherently;
-- its canonical mapping comparison therefore remains the one tested
-- by the project's definition of microlinearity.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Pointed
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; _+_)
open import Cubical.Algebra.CommRing.Base
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML
import Orbifolds.WeilAlgebras as WA
import Orbifolds.WeilDiagrams as WD
import Orbifolds.SquareZeroWeil as SW
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.FirstOrderRealPushouts as RP
import Orbifolds.TangentProducts as TP
import Orbifolds.CrispGeometry as CG
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispNaturalDiscreteness as CN
import Orbifolds.CrispPropositions as CP
import Orbifolds.TinyNullificationColimits as NC
open import Orbifolds.Crisp

record PointedSquare {ℓ : Level} (A B C D : Pointed ℓ) : Type ℓ where
  field
    north : A →∙ B
    west : A →∙ C
    east : B →∙ D
    south : C →∙ D
    commutes : (a : typ A) → east .fst (north .fst a) ≡ south .fst (west .fst a)

  square : Micro.TestSquare ℓ
  square = record
    { NW = typ A ; NE = typ B ; SW = typ C ; SE = typ D
    ; north = north .fst ; west = west .fst ; east = east .fst ; south = south .fst
    ; commutes = commutes ; north-point = pt A }

module Ring {ℓ : Level} (R : CommRing ℓ) where
  module W = WA.Weil R
  module Geometry = WD.Geometry R
  module Disks = IL.Ring R
  module Based = TP.Ring R (R .fst) (CommRingStr.0r (R .snd))

  pointed-spectrum : ℕ → Pointed ℓ
  pointed-spectrum n = W.Spec (SW.Coordinates.weil R n) , W.origin (SW.Coordinates.weil R n)

  pointed-disk : ℕ → Pointed ℓ
  pointed-disk n = Disks.D n , Disks.zeroD n

  coordinate-path : (n : ℕ) → pointed-spectrum n ≡ pointed-disk n
  coordinate-path n = ua∙ (SW.Coordinates.spectrum≃disk R n) (SW.Coordinates.spectrum-origin R n)

  module Diagram (n m : ℕ) where
    module Axes = Disks.Axes n m

    disk-square : PointedSquare (pointed-disk 0) (pointed-disk n)
      (pointed-disk m) (pointed-disk (n + m))
    PointedSquare.north disk-square = const (Disks.zeroD n) , refl
    PointedSquare.west disk-square = const (Disks.zeroD m) , refl
    PointedSquare.east disk-square = Axes.left , Axes.left-origin
    PointedSquare.south disk-square = Axes.right , Axes.right-origin
    PointedSquare.commutes disk-square _ = Axes.left-origin ∙ sym Axes.right-origin

    module DiskSquare = Micro.Square (PointedSquare.square disk-square)

    cocone-equivalence : (X : Type ℓ) → DiskSquare.Cocone X
      ≃ ML.Pullback (Axes.Maps.evaluate-left X) (Axes.Maps.evaluate-right X)
    cocone-equivalence X = isoToEquiv (iso
      (λ { (u , v , p) → (u , v) , p (Disks.zeroD 0) })
      (λ { ((u , v) , p) → u , v , const p })
      (λ _ → refl)
      (λ { (u , v , p) i → u , v ,
        (λ d → cong p (Based.zero-disk-contractible .snd d) i) }))

    pushout→linear : {X : Type ℓ} → DiskSquare.IsPushoutFor X → Axes.Maps.IsLinear X
    pushout→linear {X} preserved = snd
      (compEquiv (DiskSquare.comparison , preserved) (cocone-equivalence X))

    linear→pushout : {X : Type ℓ} → Axes.Maps.IsLinear X → DiskSquare.IsPushoutFor X
    linear→pushout {X} preserved = isEquiv[equivFunA≃B∘f]→isEquiv[f]
      DiskSquare.comparison (cocone-equivalence X) preserved

    square-type-path : PointedSquare (pointed-disk 0) (pointed-disk n)
      (pointed-disk m) (pointed-disk (n + m))
      ≡ PointedSquare (pointed-spectrum 0) (pointed-spectrum n)
        (pointed-spectrum m) (pointed-spectrum (n + m))
    square-type-path i = PointedSquare (coordinate-path 0 (~ i)) (coordinate-path n (~ i))
      (coordinate-path m (~ i)) (coordinate-path (n + m) (~ i))

    spectrum-square : PointedSquare (pointed-spectrum 0) (pointed-spectrum n)
      (pointed-spectrum m) (pointed-spectrum (n + m))
    spectrum-square = transport square-type-path disk-square

    diagram : Geometry.WeilDiagram
    WD.Geometry.WeilDiagram.WNW diagram = SW.Coordinates.weil R 0
    WD.Geometry.WeilDiagram.WNE diagram = SW.Coordinates.weil R n
    WD.Geometry.WeilDiagram.WSW diagram = SW.Coordinates.weil R m
    WD.Geometry.WeilDiagram.WSE diagram = SW.Coordinates.weil R (n + m)
    WD.Geometry.WeilDiagram.north diagram = PointedSquare.north spectrum-square .fst
    WD.Geometry.WeilDiagram.west diagram = PointedSquare.west spectrum-square .fst
    WD.Geometry.WeilDiagram.east diagram = PointedSquare.east spectrum-square .fst
    WD.Geometry.WeilDiagram.south diagram = PointedSquare.south spectrum-square .fst
    WD.Geometry.WeilDiagram.north-based diagram = PointedSquare.north spectrum-square .snd
    WD.Geometry.WeilDiagram.west-based diagram = PointedSquare.west spectrum-square .snd
    WD.Geometry.WeilDiagram.east-based diagram = PointedSquare.east spectrum-square .snd
    WD.Geometry.WeilDiagram.south-based diagram = PointedSquare.south spectrum-square .snd
    WD.Geometry.WeilDiagram.commutes diagram = PointedSquare.commutes spectrum-square

    square-path : PointedSquare.square disk-square ≡ Geometry.square diagram
    square-path i = PointedSquare.square (transport-filler square-type-path disk-square i)

    weil-pushout→linear : {X : Type ℓ}
      → Micro.Square.IsPushoutFor (Geometry.square diagram) X → Axes.Maps.IsLinear X
    weil-pushout→linear {X} preserved = pushout→linear
      (subst (λ square → Micro.Square.IsPushoutFor square X) (sym square-path) preserved)

    real-proof : WA.Weil.KockLawvere R
      → Micro.Square.IsPushoutFor (Geometry.square diagram) (R .fst)
    real-proof kock-lawvere =
      subst (λ square → Micro.Square.IsPushoutFor square (R .fst)) square-path
        (linear→pushout (RP.Ring.Binary.real-pullback R kock-lawvere n m))

    real-pushout : WA.Weil.KockLawvere R → Geometry.WeilRealPushout
    WD.Geometry.WeilRealPushout.diagram (real-pushout kock-lawvere) = diagram
    WD.Geometry.WeilRealPushout.real-pushout (real-pushout kock-lawvere) = real-proof kock-lawvere

  AllWeilMicrolinear : Type ℓ → Type (ℓ-suc ℓ)
  AllWeilMicrolinear X = (d : Geometry.WeilRealPushout)
    → Micro.Square.IsPushoutFor (Geometry.test-square d) X

  all-weil-microlinear→infinitesimally-linear : WA.Weil.KockLawvere R
    → {X : Type ℓ} → AllWeilMicrolinear X → Disks.InfinitesimallyLinear X
  all-weil-microlinear→infinitesimally-linear kock-lawvere micro n m =
    Diagram.weil-pushout→linear n m (micro (Diagram.real-pushout n m kock-lawvere))

-- Exact bridge for the project's native-crisp diagram family. The
-- ordinary Kock--Lawvere proof is promoted only at the small proposition
-- asserting the fixed crisp diagram's real-pushout property. No upper-
-- universe R-flatness or crispness of the global KL witness is required.
module CrispContext {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero) where
  module Geometry = CG.Context R
  module Axes = Ring R
  module Disks = IL.Ring R
  module Naturals = CN.Theory identity-zero flat-zero flat-zero-computation
  module Propositions = CP.Context (R .fst) (CommRingStr.0r (R .snd))
  open Propositions using (RealFlat)

  module Pair (@♭ n m : ℕ) where
    module Instance = Axes.Diagram n m

    RealProof : Type ℓ
    RealProof = Micro.Square.IsPushoutFor (Axes.Geometry.square Instance.diagram) (R .fst)

    finish : RealFlat → WA.Weil.KockLawvere R → {X : Type ℓ}
      → Geometry.Microlinear X → Disks.Axes.Maps.IsLinear n m X
    finish real-flat kock-lawvere {X} micro = flat-elim
      (λ _ → Disks.Axes.Maps.IsLinear n m X)
      (λ proof → Instance.weil-pushout→linear
        (micro (box (record { diagram = Instance.diagram ; real-pushout = proof }))))
      (Propositions.promote-proof real-flat RealProof (isPropIsEquiv _)
        (Instance.real-proof kock-lawvere))

  microlinear→infinitesimally-linear : RealFlat → WA.Weil.KockLawvere R
    → {X : Type ℓ} → Geometry.Microlinear X → Disks.InfinitesimallyLinear X
  microlinear→infinitesimally-linear real-flat kock-lawvere {X} micro =
    NC.discrete-index-elim Naturals.naturals-discrete
      (λ n → (m : ℕ) → Disks.Axes.Maps.IsLinear n m X)
      (λ n → NC.discrete-index-elim Naturals.naturals-discrete
        (λ m → Disks.Axes.Maps.IsLinear n m X)
        (λ m → Pair.finish n m real-flat kock-lawvere micro))
