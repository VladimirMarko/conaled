{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LocalDiffeomorphisms where

-- Smoothness of the actual local restrictions and their actual inverses.
-- The main lifting lemma proves that a continuous lift of a smooth map
-- through such a local diffeomorphism is smooth, using source locality.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; OpenFragment; IsOpen )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
open import Orbifolds.Intensional.OpenSubspaces using (Carrier; openSubspace)
open import Orbifolds.Intensional.LocalPlots using (PlotProbes; Neighborhood; near; near-open; near-center)
import Orbifolds.Intensional.LocalPlots as LP
import Orbifolds.Intensional.LocalHomeomorphisms as LH

module Theory {ℓ : Level} (ext : FunExt ℓ ℓ) (probes : PlotProbes ℓ) where

  module P = LP.Theory ext probes
  open P

  record LocalDiffeomorphismChart {A X : Set ℓ}
      {OA : OpenFragment A} {OX : OpenFragment X}
      (SA : LocalPlotStructure OA) (SX : LocalPlotStructure OX)
      (s : A → X) (a : A) : Set (Code ℓ) where
    field
      source-patch : Subset A
      target-patch : Subset X
      source-patch-open : IsOpen OA source-patch
      target-patch-open : IsOpen OX target-patch
      source-center : member source-patch a
      restriction-lands : (u : Carrier source-patch) → member target-patch (s (fst u))
      local-inverse : Carrier target-patch → Carrier source-patch
      inverse-right-law : (v : Carrier target-patch)
        → (s (fst (local-inverse v)) , restriction-lands (local-inverse v)) ≡ v
      inverse-left-law : (u : Carrier source-patch)
        → local-inverse (s (fst u) , restriction-lands u) ≡ u
      restriction-smooth :
        Smooth (openPlotStructure SA source-patch source-patch-open)
          (openPlotStructure SX target-patch target-patch-open)
          (λ u → s (fst u) , restriction-lands u)
      local-inverse-smooth :
        Smooth (openPlotStructure SX target-patch target-patch-open)
          (openPlotStructure SA source-patch source-patch-open) local-inverse

  ChosenLocalDiffeomorphisms : {A X : Set ℓ}
    → {OA : OpenFragment A} {OX : OpenFragment X}
    → LocalPlotStructure OA → LocalPlotStructure OX → (A → X) → Set (Code ℓ)
  ChosenLocalDiffeomorphisms {A = A} SA SX s = (a : A) → LocalDiffeomorphismChart SA SX s a

  module Chart {A X : Set ℓ} {OA : OpenFragment A} {OX : OpenFragment X}
      (SA : LocalPlotStructure OA) (SX : LocalPlotStructure OX)
      (s : A → X) (a : A) (chart : LocalDiffeomorphismChart SA SX s a) where

    open LocalDiffeomorphismChart chart

    source-topology : OpenFragment (Carrier source-patch)
    source-topology = openSubspace OA source-patch source-patch-open

    target-topology : OpenFragment (Carrier target-patch)
    target-topology = openSubspace OX target-patch target-patch-open

    source-plots : LocalPlotStructure source-topology
    source-plots = openPlotStructure SA source-patch source-patch-open

    target-plots : LocalPlotStructure target-topology
    target-plots = openPlotStructure SX target-patch target-patch-open

    restriction : Carrier source-patch → Carrier target-patch
    restriction u = s (fst u) , restriction-lands u

    restriction-diffeomorphism : Diffeomorphism source-plots target-plots
    equivalence restriction-diffeomorphism =
      equiv restriction local-inverse inverse-right-law inverse-left-law
    smooth-forward restriction-diffeomorphism = restriction-smooth
    smooth-backward restriction-diffeomorphism = local-inverse-smooth

    topological-chart : LH.LocalHomeomorphismChart OA OX s a
    LH.LocalHomeomorphismChart.source-patch topological-chart = source-patch
    LH.LocalHomeomorphismChart.target-patch topological-chart = target-patch
    LH.LocalHomeomorphismChart.source-patch-open topological-chart = source-patch-open
    LH.LocalHomeomorphismChart.target-patch-open topological-chart = target-patch-open
    LH.LocalHomeomorphismChart.source-center topological-chart = source-center
    LH.LocalHomeomorphismChart.restriction-lands topological-chart = restriction-lands
    LH.LocalHomeomorphismChart.local-inverse topological-chart = local-inverse
    LH.LocalHomeomorphismChart.inverse-right-law topological-chart = inverse-right-law
    LH.LocalHomeomorphismChart.inverse-left-law topological-chart = inverse-left-law
    LH.LocalHomeomorphismChart.restriction-continuous topological-chart =
      smooth-continuous restriction-smooth
    LH.LocalHomeomorphismChart.local-inverse-continuous topological-chart =
      smooth-continuous local-inverse-smooth

    source-restriction-smooth : Smooth source-plots SX (λ u → s (fst u))
    source-restriction-smooth = compose-smooth restriction fst
      restriction-smooth (inclusion-smooth SX target-patch target-patch-open)

  chosen-topological-charts : {A X : Set ℓ} {OA : OpenFragment A} {OX : OpenFragment X}
    → (SA : LocalPlotStructure OA) (SX : LocalPlotStructure OX) (s : A → X)
    → ChosenLocalDiffeomorphisms SA SX s → LH.ChosenLocalHomeomorphisms OA OX s
  chosen-topological-charts SA SX s charts a = Chart.topological-chart SA SX s a (charts a)

  local-diffeomorphism-smooth : {A X : Set ℓ}
    → {OA : OpenFragment A} {OX : OpenFragment X}
    → (SA : LocalPlotStructure OA) (SX : LocalPlotStructure OX) (s : A → X)
    → ChosenLocalDiffeomorphisms SA SX s → Smooth SA SX s
  local-diffeomorphism-smooth {OA = OA} SA SX s charts = local-smooth s neighborhood
    where
    neighborhood : (a : _) → Σ (Neighborhood OA a)
      (λ N → Smooth (openPlotStructure SA (near N) (near-open N)) SX (λ z → s (fst z)))
    neighborhood a = N , Chart.source-restriction-smooth SA SX s a chart
      where
      chart = charts a
      N : Neighborhood OA a
      near N = LocalDiffeomorphismChart.source-patch chart
      near-open N = LocalDiffeomorphismChart.source-patch-open chart
      near-center N = LocalDiffeomorphismChart.source-center chart

  -- A standard local-diffeomorphism fact proved for the actual lift.
  -- The lift's smoothness is a conclusion, not part of its input data.
  continuous-lift-smooth : {A X B : Set ℓ}
    → {OA : OpenFragment A} {OX : OpenFragment X} {OB : OpenFragment B}
    → (SA : LocalPlotStructure OA) (SX : LocalPlotStructure OX) (SB : LocalPlotStructure OB)
    → (s : A → X) → ChosenLocalDiffeomorphisms SA SX s
    → (g : B → A) → Continuous OB OA g
    → (f : B → X) → Smooth SB SX f
    → ((b : B) → s (g b) ≡ f b) → Smooth SB SA g
  continuous-lift-smooth {OA = OA} {OX} {OB} SA SX SB s charts g continuous-g f smooth-f commute =
    local-smooth g neighborhood
    where
    neighborhood : (b : _) → Σ (Neighborhood OB b)
      (λ N → Smooth (openPlotStructure SB (near N) (near-open N)) SA (λ z → g (fst z)))
    neighborhood b = N , smooth-respects candidate (λ z → g (fst z)) candidate-equal candidate-smooth
      where
      chart = charts (g b)
      C = LocalDiffeomorphismChart.source-patch chart
      V = LocalDiffeomorphismChart.target-patch chart
      open-C = LocalDiffeomorphismChart.source-patch-open chart
      open-V = LocalDiffeomorphismChart.target-patch-open chart
      inv = LocalDiffeomorphismChart.local-inverse chart
      lands = LocalDiffeomorphismChart.restriction-lands chart

      W = preimage g C
      open-W = continuous-g C open-C

      N : Neighborhood OB b
      near N = W
      near-open N = open-W
      near-center N = LocalDiffeomorphismChart.source-center chart

      lands-V : (z : Carrier W) → member V (f (fst z))
      lands-V z = subst (member V) (commute (fst z)) (lands (g (fst z) , snd z))

      into-V : Carrier W → Carrier V
      into-V z = f (fst z) , lands-V z

      into-V-smooth : Smooth (openPlotStructure SB W open-W)
        (openPlotStructure SX V open-V) into-V
      into-V-smooth = corestrict-smooth V open-V (λ z → f (fst z))
        (restrict-smooth W open-W f smooth-f) lands-V

      candidate : Carrier W → _
      candidate z = fst (inv (into-V z))

      candidate-smooth : Smooth (openPlotStructure SB W open-W) SA candidate
      candidate-smooth = compose-smooth (λ z → inv (into-V z)) fst
        (compose-smooth into-V inv into-V-smooth (LocalDiffeomorphismChart.local-inverse-smooth chart))
        (inclusion-smooth SA C open-C)

      candidate-equal : (z : Carrier W) → candidate z ≡ g (fst z)
      candidate-equal z = cong fst
        (sym (cong inv (Σ-path-prop (member-prop V) (commute (fst z))))
          ∙ LocalDiffeomorphismChart.inverse-left-law chart (g (fst z) , snd z))
