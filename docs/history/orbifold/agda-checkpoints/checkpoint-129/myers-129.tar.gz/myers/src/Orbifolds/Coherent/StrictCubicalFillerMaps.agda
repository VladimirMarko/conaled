{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalFillerMaps where

-- Literal action on endpoint-typed cubical fillers. Total fillers are
-- mapped recursively as paths in the preceding total space; the boundary
-- comparison and all canonical/raw-cube computations are derived.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
import Orbifolds.Coherent.StrictCubicalShellMaps as ShellMaps
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

cast-filler : ∀ {ℓ} (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
  → outer b ≡ˢ outer b' → CF.Filler (toNat n) b → CF.Filler (toNat n) b'
cast-filler n reflˢ c = c

cast-filler-compose : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  {a b c : CS.Shell (toNat n) X} (p : outer a ≡ˢ outer b) (q : outer b ≡ˢ outer c)
  (u : CF.Filler (toNat n) a)
  → outer (cast-filler n q (cast-filler n p u))
    ≡ˢ outer (cast-filler n (strict-trans p q) u)
cast-filler-compose n reflˢ reflˢ u = reflˢ

cast-forget : ∀ {ℓ} (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
  (p : outer b ≡ˢ outer b') (c : CF.Filler (toNat n) b)
  → outer (CF.forget-filler (toNat n) b' (cast-filler n p c))
    ≡ˢ outer (CF.forget-filler (toNat n) b c)
cast-forget n reflˢ c = reflˢ

cast-second : ∀ {ℓ} (n : Dim) {X : Type ℓ} (z z' : CF.Total (toNat n) X)
  → outer z ≡ˢ outer z' → (p : outer (z .fst) ≡ˢ outer (z' .fst))
  → outer (cast-filler n p (z .snd)) ≡ˢ outer (z' .snd)
cast-second n z .z reflˢ p with strict-uip p reflˢ
... | reflˢ = reflˢ

assemble-total : ∀ {ℓ} (n : Dim) {X : Type ℓ} (lo hi : Cube n X)
  → CF.canonical (toNat n) lo ≡ CF.canonical (toNat n) hi
  → CF.Total (toNat (osuc n)) X
assemble-total n lo hi p = ((lo , hi) , (λ i → p i .fst)) , (λ i → p i .snd)

module Action {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module Assemble = Assembly.Construction E
  module Filler = Fillers.Boundary E
  module Shell = ShellMaps.Action E

  mutual
    map-total : (n : Dim) {X Y : Type ℓ} → (X → Y)
      → CF.Total (toNat n) X → CF.Total (toNat n) Y
    map-total ozero f (b , c) = lift tt , f c
    map-total (osuc n) f (((lo , hi) , p) , c) = assemble-total n
      (map-cube n f lo) (map-cube n f hi)
      (strict-end-path (λ i → map-total n f (p i , c i))
        (map-total-canonical n f lo) (map-total-canonical n f hi))

    map-total-canonical : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X)
      → outer (map-total n f (CF.canonical (toNat n) c))
        ≡ˢ outer (CF.canonical (toNat n) (map-cube n f c))
    map-total-canonical ozero f c = reflˢ
    map-total-canonical (osuc n) f c = strict-cong
      (λ q → outer (assemble-total n (map-cube n f (c i0)) (map-cube n f (c i1)) (inner q)))
      (Assemble.strict-end-path-correct
        (λ i → map-total n f (CF.canonical (toNat n) (c i)))
        (λ i → CF.canonical (toNat n) (map-cube n f (c i)))
        (map-total-canonical n f (c i0)) (map-total-canonical n f (c i1))
        (λ i → map-total-canonical n f (c i)))

  map-total-boundary : (n : Dim) {X Y : Type ℓ} (f : X → Y) (z : CF.Total (toNat n) X)
    → outer (map-total n f z .fst) ≡ˢ outer (Shell.map-shell n f (z .fst))
  map-total-boundary ozero f z = reflˢ
  map-total-boundary (osuc n) f (((lo , hi) , p) , c) = Filler.shell-equality n
    (map-cube n f lo) (map-cube n f hi) (map-cube n f lo) (map-cube n f hi)
    (map-total (osuc n) f (((lo , hi) , p) , c) .fst .snd)
    (Shell.map-shell (osuc n) f ((lo , hi) , p) .snd)
    reflˢ reflˢ
    (λ i → strict-trans
      (strict-cong (λ z → outer (inner z .fst))
        (strict-end-path-value (λ j → map-total n f (p j , c j))
          (map-total-canonical n f lo) (map-total-canonical n f hi) i))
      (strict-trans
        (map-total-boundary n f (p i , c i))
        (strict-sym (Shell.side-computation n f ((lo , hi) , p) i))))

  map-total-forget : (n : Dim) {X Y : Type ℓ} (f : X → Y) (z : CF.Total (toNat n) X)
    → outer (CF.forget-total (toNat n) (map-total n f z))
      ≡ˢ outer (map-cube n f (CF.forget-total (toNat n) z))
  map-total-forget ozero f z = reflˢ
  map-total-forget (osuc n) f (((lo , hi) , p) , c) = interval-ext λ i → strict-trans
    (strict-cong (λ z → outer (CF.forget-total (toNat n) (inner z)))
      (strict-end-path-value (λ j → map-total n f (p j , c j))
        (map-total-canonical n f lo) (map-total-canonical n f hi) i))
    (map-total-forget n f (p i , c i))

  map-filler : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → CF.Filler (toNat n) b → CF.Filler (toNat n) (Shell.map-shell n f b)
  map-filler n f b c = cast-filler n (map-total-boundary n f (b , c))
    (map-total n f (b , c) .snd)

  map-filler-forget : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    (c : CF.Filler (toNat n) b)
    → outer (CF.forget-filler (toNat n) (Shell.map-shell n f b) (map-filler n f b c))
      ≡ˢ outer (map-cube n f (CF.forget-filler (toNat n) b c))
  map-filler-forget n f b c = strict-trans
    (cast-forget n (map-total-boundary n f (b , c)) (map-total n f (b , c) .snd))
    (map-total-forget n f (b , c))

  map-canonical-filler : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X)
    → outer (cast-filler n (Shell.restriction-natural n f c)
        (map-filler n f (CS.restriction (toNat n) c) (CF.canonical-filler (toNat n) c)))
      ≡ˢ outer (CF.canonical-filler (toNat n) (map-cube n f c))
  map-canonical-filler n f c = strict-trans
    (cast-filler-compose n (map-total-boundary n f (CF.canonical (toNat n) c))
      (Shell.restriction-natural n f c) (map-total n f (CF.canonical (toNat n) c) .snd))
    (cast-second n (map-total n f (CF.canonical (toNat n) c))
      (CF.canonical (toNat n) (map-cube n f c))
      (map-total-canonical n f c)
      (strict-trans (map-total-boundary n f (CF.canonical (toNat n) c))
        (Shell.restriction-natural n f c)))

  filler-extensionality : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    {c d : CF.Filler (toNat n) b}
    → outer (CF.forget-filler (toNat n) b c) ≡ˢ outer (CF.forget-filler (toNat n) b d)
    → outer c ≡ˢ outer d
  filler-extensionality ozero b p = p
  filler-extensionality (osuc n) b p = path-ext λ i →
    filler-extensionality n (b .snd i) (strict-cong (λ z → outer (inner z i)) p)
