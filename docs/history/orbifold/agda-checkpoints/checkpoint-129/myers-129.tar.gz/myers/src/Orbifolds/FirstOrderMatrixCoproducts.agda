{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderMatrixCoproducts where

-- Actual finite coproducts of coordinate free modules, and agreement
-- of their disk images with the specified zero-padding axis maps.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc; _+_)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.FinData as FD
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
import Cubical.Algebra.Ring.BigOps as BO
open import Cubical.Categories.Category.Base
open import Cubical.Categories.Functor.Base
import Cubical.Categories.Limits.BinCoproduct as BC
import Cubical.Categories.Limits.Initial as Initial
import Orbifolds.FirstOrderLinearMaps as LM

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd) renaming (_+_ to _+R_)
  module Linear = LM.Ring R
  module S = BO.Sum (CommRing→Ring R)
  module K = BO.KroneckerDelta (CommRing→Ring R)
  module Disks = Linear.Disks
  open Linear using (Mat; compose; MatrixCategory)

  sum-blocks : (n m : ℕ) (v : FD.Fin (n + m) → R .fst)
    → S.∑ v ≡ S.∑ (λ i → v (FD.FinSumChar.fun n m (inl i)))
                +R S.∑ (λ j → v (FD.FinSumChar.fun n m (inr j)))
  sum-blocks zero m v = sym (+IdL (S.∑ v))
  sum-blocks (suc n) m v = cong (v FD.zero +R_) (sum-blocks n m (v ∘ FD.suc))
    ∙ +Assoc (v FD.zero) _ _

  module Binary (n m : ℕ) where
    module Axes = Disks.Axes n m

    split : FD.Fin (n + m) → FD.Fin n ⊎ FD.Fin m
    split = FD.FinSumChar.inv n m

    left-row : FD.Fin n ⊎ FD.Fin m → FD.Fin n → R .fst
    left-row (inl i) j = K.δ i j
    left-row (inr i) j = 0r

    right-row : FD.Fin n ⊎ FD.Fin m → FD.Fin m → R .fst
    right-row (inl i) j = 0r
    right-row (inr i) j = K.δ i j

    left-injection : Mat n (n + m)
    left-injection i = left-row (split i)

    right-injection : Mat m (n + m)
    right-injection i = right-row (split i)

    left-inl : (i j : FD.Fin n)
      → left-injection (FD.FinSumChar.fun n m (inl i)) j ≡ K.δ i j
    left-inl i j = cong (λ s → left-row s j) (FD.FinSumChar.ret n m (inl i))

    left-inr : (i : FD.Fin m) (j : FD.Fin n)
      → left-injection (FD.FinSumChar.fun n m (inr i)) j ≡ 0r
    left-inr i j = cong (λ s → left-row s j) (FD.FinSumChar.ret n m (inr i))

    right-inl : (i : FD.Fin n) (j : FD.Fin m)
      → right-injection (FD.FinSumChar.fun n m (inl i)) j ≡ 0r
    right-inl i j = cong (λ s → right-row s j) (FD.FinSumChar.ret n m (inl i))

    right-inr : (i j : FD.Fin m)
      → right-injection (FD.FinSumChar.fun n m (inr i)) j ≡ K.δ i j
    right-inr i j = cong (λ s → right-row s j) (FD.FinSumChar.ret n m (inr i))

    left-composite : {k : ℕ} (a : Mat (n + m) k)
      → compose left-injection a ≡ (λ i j → a i (FD.FinSumChar.fun n m (inl j)))
    left-composite a = funExt λ i → funExt λ j →
      sum-blocks n m (λ s → a i s · left-injection s j)
      ∙ cong₂ _+R_
        (S.∑Ext (λ s → cong (a i (FD.FinSumChar.fun n m (inl s)) ·_) (left-inl s j))
          ∙ S.∑Mulr1 n (λ s → a i (FD.FinSumChar.fun n m (inl s))) j)
        (S.∑Ext (λ s → cong (a i (FD.FinSumChar.fun n m (inr s)) ·_) (left-inr s j))
          ∙ S.∑Mulr0 (λ s → a i (FD.FinSumChar.fun n m (inr s))))
      ∙ +IdR _

    right-composite : {k : ℕ} (a : Mat (n + m) k)
      → compose right-injection a ≡ (λ i j → a i (FD.FinSumChar.fun n m (inr j)))
    right-composite a = funExt λ i → funExt λ j →
      sum-blocks n m (λ s → a i s · right-injection s j)
      ∙ cong₂ _+R_
        (S.∑Ext (λ s → cong (a i (FD.FinSumChar.fun n m (inl s)) ·_) (right-inl s j))
          ∙ S.∑Mulr0 (λ s → a i (FD.FinSumChar.fun n m (inl s))))
        (S.∑Ext (λ s → cong (a i (FD.FinSumChar.fun n m (inr s)) ·_) (right-inr s j))
          ∙ S.∑Mulr1 m (λ s → a i (FD.FinSumChar.fun n m (inr s))) j)
      ∙ +IdL _

    module Target (k : ℕ) where
      restrict : Mat (n + m) k → Mat n k × Mat m k
      restrict a = (λ i j → a i (FD.FinSumChar.fun n m (inl j))) ,
        (λ i j → a i (FD.FinSumChar.fun n m (inr j)))

      join-row : (a : Mat n k) (b : Mat m k) → FD.Fin k → FD.Fin n ⊎ FD.Fin m → R .fst
      join-row a b i (inl j) = a i j
      join-row a b i (inr j) = b i j

      join : Mat n k × Mat m k → Mat (n + m) k
      join (a , b) i j = join-row a b i (split j)

      restrict-join : (ab : Mat n k × Mat m k) → restrict (join ab) ≡ ab
      restrict-join (a , b) i =
        (λ r s → cong (join-row a b r) (FD.FinSumChar.ret n m (inl s)) i) ,
        (λ r s → cong (join-row a b r) (FD.FinSumChar.ret n m (inr s)) i)

      join-restrict-at : (a : Mat (n + m) k) (i : FD.Fin k) (s : FD.Fin n ⊎ FD.Fin m)
        → join-row (restrict a .fst) (restrict a .snd) i s ≡ a i (FD.FinSumChar.fun n m s)
      join-restrict-at a i (inl j) = refl
      join-restrict-at a i (inr j) = refl

      join-restrict : (a : Mat (n + m) k) → join (restrict a) ≡ a
      join-restrict a = funExt λ i → funExt λ j →
        join-restrict-at a i (split j) ∙ cong (a i) (FD.FinSumChar.sec n m j)

      block-equivalence : Mat (n + m) k ≃ (Mat n k × Mat m k)
      block-equivalence = isoToEquiv (iso restrict join restrict-join join-restrict)

      comparison : Mat (n + m) k → Mat n k × Mat m k
      comparison a = compose left-injection a , compose right-injection a

      comparison-coherence : comparison ≡ restrict
      comparison-coherence = funExt λ a i → left-composite a i , right-composite a i

      comparison-isEquiv : isEquiv comparison
      comparison-isEquiv = subst isEquiv (sym comparison-coherence) (snd block-equivalence)

      universal : (a : Mat n k) (b : Mat m k)
        → isContr (Σ[ h ∈ Mat (n + m) k ]
          (compose left-injection h ≡ a) × (compose right-injection h ≡ b))
      universal a b = isOfHLevelRespectEquiv 0 split-path
        (comparison-isEquiv .equiv-proof (a , b))
        where
        split-path : fiber comparison (a , b) ≃
          (Σ[ h ∈ Mat (n + m) k ]
            (compose left-injection h ≡ a) × (compose right-injection h ≡ b))
        split-path = isoToEquiv (iso
          (λ { (h , p) → h , cong fst p , cong snd p })
          (λ { (h , p , q) → h , (λ i → p i , q i) })
          (λ _ → refl) (λ _ → refl))

    coproduct : BC.BinCoproduct MatrixCategory n m
    BC.BinCoproduct.binCoprodOb coproduct = n + m
    BC.BinCoproduct.binCoprodInj₁ coproduct = left-injection
    BC.BinCoproduct.binCoprodInj₂ coproduct = right-injection
    BC.BinCoproduct.univProp coproduct = Target.universal _

    left-action : (x : Disks.D n) (s : FD.Fin n ⊎ FD.Fin m)
      → S.∑ (λ j → left-row s j · x .fst j) ≡ Axes.left-values x s
    left-action x (inl i) = S.∑Mul1r n (x .fst) i
    left-action x (inr i) = S.∑Mul0r (x .fst)

    right-action : (x : Disks.D m) (s : FD.Fin n ⊎ FD.Fin m)
      → S.∑ (λ j → right-row s j · x .fst j) ≡ Axes.right-values x s
    right-action x (inl i) = S.∑Mul0r (x .fst)
    right-action x (inr i) = S.∑Mul1r m (x .fst) i

    disk-left : Linear.disk-map left-injection ≡ Axes.left
    disk-left = funExt λ x → Σ≡Prop Disks.pairwise-zero-isProp
      (funExt λ i → left-action x (split i))

    disk-right : Linear.disk-map right-injection ≡ Axes.right
    disk-right = funExt λ x → Σ≡Prop Disks.pairwise-zero-isProp
      (funExt λ i → right-action x (split i))

    pointed-disk-left : Functor.F-hom Linear.disk-functor left-injection
      ≡ (Axes.left , Axes.left-origin)
    pointed-disk-left = Σ≡Prop (λ _ → Linear.disk-isSet (n + m) _ _) disk-left

    pointed-disk-right : Functor.F-hom Linear.disk-functor right-injection
      ≡ (Axes.right , Axes.right-origin)
    pointed-disk-right = Σ≡Prop (λ _ → Linear.disk-isSet (n + m) _ _) disk-right

  coproducts : BC.BinCoproducts MatrixCategory
  coproducts = Binary.coproduct

  initial : Initial.Initial MatrixCategory
  initial = 0 , λ k → (λ _ _ → 0r) ,
    λ a → funExt λ i → funExt λ j → Empty.rec (FD.¬Fin0 j)
