{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ContinuousActionArrowFamilies where

-- Varying labels are locally constant: every actual label fiber is open.
-- They construct continuous maps to the literal categorical arrow space.
-- No continuity certificate is declared proof-irrelevant for OpenFragment.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity hiding (lift)
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; Included; Product; full; intersection
  ; OpenFragment; IsOpen; open-full; open-transfer; open-intersection; open-local )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
import Orbifolds.Intensional.OpenSubspaces as OS
import Orbifolds.Intensional.ActionGroupoidTopologicalStructure as Structure
import Orbifolds.Intensional.LabelledActionPullbackTopology as Labelled

private variable ℓ : Level

label-fiber : {G Z : Set ℓ} → isSet G → (Z → G) → G → Subset Z
member (label-fiber setG f g) z = f z ≡ g
member-prop (label-fiber setG f g) z = setG (f z) g

LocallyConstant : {G Z : Set ℓ} → isSet G → OpenFragment Z → (Z → G) → Set ℓ
LocallyConstant {G = G} setG OZ f = (g : G) → IsOpen OZ (label-fiber setG f g)

OpenIsProp : {Z : Set ℓ} → OpenFragment Z → Set (Code ℓ)
OpenIsProp {Z = Z} OZ = (U : Subset Z) → isProp (IsOpen OZ U)

locally-constant-pointwise : {G Z : Set ℓ} (setG : isSet G)
  (OZ : OpenFragment Z) (f g : Z → G)
  → ((z : Z) → f z ≡ g z) → LocallyConstant setG OZ f → LocallyConstant setG OZ g
locally-constant-pointwise setG OZ f g equal local h = open-transfer OZ
  {P = label-fiber setG f h} {Q = label-fiber setG g h}
  (λ z p → sym (equal z) ∙ p) (λ z q → equal z ∙ q) (local h)

locally-constant-constant : {G Z : Set ℓ} (setG : isSet G)
  (OZ : OpenFragment Z) (g : G) → LocallyConstant setG OZ (λ _ → g)
locally-constant-constant setG OZ g h = open-local OZ (label-fiber setG (λ _ → g) h)
  (λ z p → full , open-full OZ , tt , (λ w _ → p))

locally-constant-map : {G H Z : Set ℓ} (setG : isSet G) (setH : isSet H)
  (OZ : OpenFragment Z) (f : Z → G) (k : G → H)
  → LocallyConstant setG OZ f → LocallyConstant setH OZ (λ z → k (f z))
locally-constant-map setG setH OZ f k local h =
  open-local OZ (label-fiber setH (λ z → k (f z)) h)
    (λ z p → label-fiber setG f (f z) , local (f z) , refl ,
      (λ w q → cong k q ∙ p))

locally-constant-binary : {G Z : Set ℓ} (setG : isSet G)
  (OZ : OpenFragment Z) (f g : Z → G) (k : G → G → G)
  → LocallyConstant setG OZ f → LocallyConstant setG OZ g
  → LocallyConstant setG OZ (λ z → k (f z) (g z))
locally-constant-binary setG OZ f g k local-f local-g h =
  open-local OZ (label-fiber setG (λ z → k (f z) (g z)) h)
    (λ z p → intersection (label-fiber setG f (f z)) (label-fiber setG g (g z)) ,
      open-intersection OZ
        {P = label-fiber setG f (f z)} {Q = label-fiber setG g (g z)}
        (local-f (f z)) (local-g (g z)) , (refl , refl) ,
      (λ w q → cong (λ a → k a (g w)) (fst q)
        ∙ cong (k (f z)) (snd q) ∙ p))

locally-constant-restrict : {G Z V : Set ℓ} (setG : isSet G)
  (OZ : OpenFragment Z) (OV : OpenFragment V) (r : V → Z)
  → Continuous OV OZ r → (f : Z → G) → LocallyConstant setG OZ f
  → LocallyConstant setG OV (λ v → f (r v))
locally-constant-restrict setG OZ OV r continuous f local g =
  continuous (label-fiber setG f g) (local g)

-- The local proof uses the actual varying label and one open component.
label-map-continuous : {G X Z : Set ℓ} (setG : isSet G)
  (OX : OpenFragment X) (OZ : OpenFragment Z) (g : Z → G) (m : Z → X)
  → LocallyConstant setG OZ g → Continuous OZ OX m
  → Continuous OZ (OS.sumOpenFragment (λ (_ : G) → OX)) (λ z → g z , m z)
label-map-continuous {X = X} {Z = Z} setG OX OZ g m local continuous U open-U =
  open-local OZ (preimage (λ z → g z , m z) U) neighborhood
  where
  neighborhood : (z : Z) → member U (g z , m z)
    → Σ (Subset Z) (λ N → Σ (IsOpen OZ N)
      (λ _ → Σ (member N z) (λ _ → Included N (preimage (λ w → g w , m w) U))))
  neighborhood z at-U = N , open-N , (refl , at-U) , inside
    where
    slice : Subset X
    slice = preimage (λ x → g z , x) U
    N : Subset Z
    N = intersection (label-fiber setG g (g z)) (preimage m slice)
    open-N : IsOpen OZ N
    open-N = open-intersection OZ
      {P = label-fiber setG g (g z)} {Q = preimage m slice}
      (local (g z)) (continuous slice (open-U (g z)))
    inside : Included N (preimage (λ w → g w , m w) U)
    inside w (equal , at-slice) =
      subst (member U) (cong (λ h → h , m w) (sym equal)) at-slice

module Action {ℓ : Level} {G X : Set ℓ}
    (setG : isSet G) (setX : isSet X)
    (unit : G) (multiply : G → G → G) (inverse : G → G)
    (unit-left : (g : G) → multiply unit g ≡ g)
    (unit-right : (g : G) → multiply g unit ≡ g)
    (multiply-associative : (g h k : G)
      → multiply (multiply g h) k ≡ multiply g (multiply h k))
    (inverse-left : (g : G) → multiply (inverse g) g ≡ unit)
    (inverse-right : (g : G) → multiply g (inverse g) ≡ unit)
    (act : G → X → X)
    (act-unit : (x : X) → act unit x ≡ x)
    (act-multiply : (g h : G) (x : X)
      → act (multiply g h) x ≡ act g (act h x)) where

  module Actual = Structure.Action setG setX unit multiply inverse
    unit-left unit-right multiply-associative inverse-left inverse-right
    act act-unit act-multiply
  module Algebra = Actual.Algebra

  module Topological (OX : OpenFragment X)
      (act-continuous : (g : G) → Continuous OX OX (act g)) where
    module Topology = Actual.Topological OX act-continuous

    LabelledFamily : {Z : Set ℓ} → OpenFragment Z → (Z → X) → (Z → X) → Set ℓ
    LabelledFamily {Z} OZ m n = Σ ((z : Z) → Algebra.Hom (m z) (n z))
      (λ f → LocallyConstant setG OZ (λ z → fst (f z)))

    ArrowConditions : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      → (Z → Algebra.ArrowSpace) → Set (Code ℓ)
    ArrowConditions {Z} OZ m n a = Σ (Continuous OZ Topology.arrowTopology a)
      (λ _ → Σ ((z : Z) → Algebra.source (a z) ≡ m z)
        (λ _ → (z : Z) → Algebra.target (a z) ≡ n z))

    ArrowFamily : {Z : Set ℓ} → OpenFragment Z → (Z → X) → (Z → X) → Set (Code ℓ)
    ArrowFamily {Z} OZ m n = Σ (Z → Algebra.ArrowSpace) (ArrowConditions OZ m n)

    toArrows : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      → Continuous OZ OX m → LabelledFamily OZ m n → ArrowFamily OZ m n
    toArrows OZ m n continuous f =
      (λ z → m z , n z , fst f z) ,
      Topology.through-arrow-coordinates OZ (λ z → m z , n z , fst f z)
        (λ z → fst (fst f z) , m z) (λ z → refl)
        (label-map-continuous setG OX OZ (λ z → fst (fst f z)) m (snd f) continuous) ,
      (λ z → refl) , (λ z → refl)

    fromArrows : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      → ArrowFamily OZ m n → LabelledFamily OZ m n
    fromArrows {Z} OZ m n a = hom , local
      where
      labels : Z → G
      labels z = fst (Algebra.coordinates (fst a z))
      hom : (z : Z) → Algebra.Hom (m z) (n z)
      hom z = labels z ,
        cong (act (labels z)) (sym (fst (snd (snd a)) z))
        ∙ sym (Algebra.target-coordinates (fst a z)) ∙ snd (snd (snd a)) z
      local : LocallyConstant setG OZ labels
      local g = fst (snd a)
        (preimage Algebra.coordinates (Topology.Coordinate.label-slice g))
        (Topology.ArrowTransport.forward-continuous (Topology.Coordinate.label-slice g)
          (Topology.Coordinate.label-slice-open g))

    from-to-pointwise : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      (continuous : Continuous OZ OX m) (f : LabelledFamily OZ m n) (z : Z)
      → fst (fromArrows OZ m n (toArrows OZ m n continuous f)) z ≡ fst f z
    from-to-pointwise OZ m n continuous f z = Algebra.hom-ext {m z} {n z} refl

    to-from-pointwise : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      (continuous : Continuous OZ OX m) (a : ArrowFamily OZ m n) (z : Z)
      → fst (toArrows OZ m n continuous (fromArrows OZ m n a)) z ≡ fst a z
    to-from-pointwise OZ m n continuous a z = Actual.arrow-coordinate-injective
      (cong (λ x → fst (Algebra.coordinates (fst a z)) , x)
        (sym (fst (snd (snd a)) z)))

    restrictLabelled : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) → Continuous OV OZ r → {m n : Z → X}
      → LabelledFamily OZ m n → LabelledFamily OV (λ v → m (r v)) (λ v → n (r v))
    restrictLabelled OZ OV r continuous f = (λ v → fst f (r v)) ,
      locally-constant-restrict setG OZ OV r continuous (λ z → fst (fst f z)) (snd f)

    restrictArrows : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) → Continuous OV OZ r → {m n : Z → X}
      → ArrowFamily OZ m n → ArrowFamily OV (λ v → m (r v)) (λ v → n (r v))
    restrictArrows OZ OV r continuous a = (λ v → fst a (r v)) ,
      OS.compose-continuous OV OZ Topology.arrowTopology r (fst a) continuous (fst (snd a)) ,
      (λ v → fst (snd (snd a)) (r v)) , (λ v → snd (snd (snd a)) (r v))

    toArrows-restrict-pointwise : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) (cr : Continuous OV OZ r) (m n : Z → X)
      (cm : Continuous OZ OX m) (f : LabelledFamily OZ m n) (v : V)
      → fst (toArrows OV (λ v → m (r v)) (λ v → n (r v))
          (OS.compose-continuous OV OZ OX r m cr cm) (restrictLabelled OZ OV r cr f)) v
        ≡ fst (restrictArrows OZ OV r cr (toArrows OZ m n cm f)) v
    toArrows-restrict-pointwise OZ OV r cr m n cm f v = refl

    fromArrows-restrict-pointwise : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) (cr : Continuous OV OZ r) (m n : Z → X)
      (a : ArrowFamily OZ m n) (v : V)
      → fst (fromArrows OV (λ v → m (r v)) (λ v → n (r v))
          (restrictArrows OZ OV r cr a)) v
        ≡ fst (restrictLabelled OZ OV r cr (fromArrows OZ m n a)) v
    fromArrows-restrict-pointwise OZ OV r cr m n a v = refl

    identityFamily : {Z : Set ℓ} (OZ : OpenFragment Z) (m : Z → X) → LabelledFamily OZ m m
    identityFamily OZ m = (λ z → Algebra.identity {m z}) ,
      locally-constant-constant setG OZ unit

    inverseFamily : {Z : Set ℓ} (OZ : OpenFragment Z) {m n : Z → X}
      → LabelledFamily OZ m n → LabelledFamily OZ n m
    inverseFamily OZ {m} {n} f = (λ z → Algebra.inverse-arrow {m z} {n z} (fst f z)) ,
      locally-constant-map setG setG OZ (λ z → fst (fst f z)) inverse (snd f)

    composeFamily : {Z : Set ℓ} (OZ : OpenFragment Z) {m n p : Z → X}
      → LabelledFamily OZ n p → LabelledFamily OZ m n → LabelledFamily OZ m p
    composeFamily OZ {m} {n} {p} g f =
      (λ z → Algebra.compose {m z} {n z} {p z} (fst g z) (fst f z)) ,
      locally-constant-binary setG OZ (λ z → fst (fst g z)) (λ z → fst (fst f z))
        multiply (snd g) (snd f)

    compose-label : {Z : Set ℓ} (OZ : OpenFragment Z) {m n p : Z → X}
      (g : LabelledFamily OZ n p) (f : LabelledFamily OZ m n) (z : Z)
      → fst (fst (composeFamily OZ g f) z) ≡ multiply (fst (fst g z)) (fst (fst f z))
    compose-label OZ g f z = refl

    toArrows-identity : {Z : Set ℓ} (OZ : OpenFragment Z) (m : Z → X)
      (cm : Continuous OZ OX m) (z : Z)
      → fst (toArrows OZ m m cm (identityFamily OZ m)) z ≡ Actual.unit-map (m z)
    toArrows-identity OZ m cm z = refl

    toArrows-inverse : {Z : Set ℓ} (OZ : OpenFragment Z) (m n : Z → X)
      (cm : Continuous OZ OX m) (cn : Continuous OZ OX n)
      (f : LabelledFamily OZ m n) (z : Z)
      → fst (toArrows OZ n m cn (inverseFamily OZ f)) z
        ≡ Actual.inverse-map (fst (toArrows OZ m n cm f) z)
    toArrows-inverse OZ m n cm cn f z = refl

    toArrows-compose : {Z : Set ℓ} (OZ : OpenFragment Z) (m n p : Z → X)
      (cm : Continuous OZ OX m) (g : LabelledFamily OZ n p) (f : LabelledFamily OZ m n) (z : Z)
      → fst (toArrows OZ m p cm (composeFamily OZ g f)) z
        ≡ Actual.compose-map (m z , n z , p z , fst g z , fst f z)
    toArrows-compose OZ m n p cm g f z = refl

    restrict-inverse-pointwise : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) (cr : Continuous OV OZ r) {m n : Z → X}
      (f : LabelledFamily OZ m n) (v : V)
      → fst (restrictLabelled OZ OV r cr (inverseFamily OZ f)) v
        ≡ fst (inverseFamily OV (restrictLabelled OZ OV r cr f)) v
    restrict-inverse-pointwise OZ OV r cr f v = refl

    restrict-compose-pointwise : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
      (r : V → Z) (cr : Continuous OV OZ r) {m n p : Z → X}
      (g : LabelledFamily OZ n p) (f : LabelledFamily OZ m n) (v : V)
      → fst (restrictLabelled OZ OV r cr (composeFamily OZ g f)) v
        ≡ fst (composeFamily OV (restrictLabelled OZ OV r cr g)
          (restrictLabelled OZ OV r cr f)) v
    restrict-compose-pointwise OZ OV r cr g f v = refl

    -- Exactly the missing hypotheses for equality of bundled certificates.
    -- No proof irrelevance of a general OpenFragment is inferred.
    module Extensional (ext : FunExt ℓ ℓ) (ext-large : FunExt (Code ℓ) ℓ) where

      local-prop : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → (g : Z → G) → isProp (LocallyConstant setG OZ g)
      local-prop OZ open-prop g = isPropΠ ext (λ h → open-prop (label-fiber setG g h))

      labelled-ext : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → {m n : Z → X} {f g : LabelledFamily OZ m n}
        → ((z : Z) → fst f z ≡ fst g z) → f ≡ g
      labelled-ext OZ open-prop equal =
        Σ-path-prop (λ f → local-prop OZ open-prop (λ z → fst (f z))) (ext equal)

      continuous-prop : {Z A : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → (OA : OpenFragment A) (a : Z → A) → isProp (Continuous OZ OA a)
      continuous-prop OZ open-prop OA a =
        isPropΠ ext-large (λ U → isPropΠ ext (λ _ → open-prop (preimage a U)))

      conditions-prop : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → (m n : Z → X) (a : Z → Algebra.ArrowSpace) → isProp (ArrowConditions OZ m n a)
      conditions-prop OZ open-prop m n a =
        isPropΣ (continuous-prop OZ open-prop Topology.arrowTopology a)
          (λ _ → isPropΣ (isPropΠ ext (λ z → setX (Algebra.source (a z)) (m z)))
            (λ _ → isPropΠ ext (λ z → setX (Algebra.target (a z)) (n z))))

      arrows-ext : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → {m n : Z → X} {a b : ArrowFamily OZ m n}
        → ((z : Z) → fst a z ≡ fst b z) → a ≡ b
      arrows-ext OZ open-prop {m} {n} equal =
        Σ-path-prop (conditions-prop OZ open-prop m n) (ext equal)

      family-equivalence : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → (m n : Z → X) → Continuous OZ OX m
        → Equiv (LabelledFamily OZ m n) (ArrowFamily OZ m n)
      family-equivalence OZ open-prop m n cm = equiv (toArrows OZ m n cm) (fromArrows OZ m n)
        (λ a → arrows-ext OZ open-prop (to-from-pointwise OZ m n cm a))
        (λ f → labelled-ext OZ open-prop (from-to-pointwise OZ m n cm f))

      toArrows-restrict : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
        → OpenIsProp OV → (r : V → Z) (cr : Continuous OV OZ r) (m n : Z → X)
        (cm : Continuous OZ OX m) (f : LabelledFamily OZ m n)
        → toArrows OV (λ v → m (r v)) (λ v → n (r v))
            (OS.compose-continuous OV OZ OX r m cr cm) (restrictLabelled OZ OV r cr f)
          ≡ restrictArrows OZ OV r cr (toArrows OZ m n cm f)
      toArrows-restrict OZ OV open-prop r cr m n cm f =
        arrows-ext OV open-prop (toArrows-restrict-pointwise OZ OV r cr m n cm f)

      fromArrows-restrict : {Z V : Set ℓ} (OZ : OpenFragment Z) (OV : OpenFragment V)
        → OpenIsProp OV → (r : V → Z) (cr : Continuous OV OZ r) (m n : Z → X)
        (a : ArrowFamily OZ m n)
        → fromArrows OV (λ v → m (r v)) (λ v → n (r v)) (restrictArrows OZ OV r cr a)
          ≡ restrictLabelled OZ OV r cr (fromArrows OZ m n a)
      fromArrows-restrict OZ OV open-prop r cr m n a =
        labelled-ext OV open-prop (fromArrows-restrict-pointwise OZ OV r cr m n a)

      restrictLabelled-id : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → {m n : Z → X} (f : LabelledFamily OZ m n)
        → restrictLabelled OZ OZ (λ z → z) (OS.identity-continuous OZ) f ≡ f
      restrictLabelled-id OZ open-prop f = labelled-ext OZ open-prop (λ z → refl)

      restrictLabelled-comp : {Z V W : Set ℓ}
        (OZ : OpenFragment Z) (OV : OpenFragment V) (OW : OpenFragment W)
        → OpenIsProp OW → (r : V → Z) (s : W → V)
        (cr : Continuous OV OZ r) (cs : Continuous OW OV s)
        → {m n : Z → X} (f : LabelledFamily OZ m n)
        → restrictLabelled OV OW s cs (restrictLabelled OZ OV r cr f)
          ≡ restrictLabelled OZ OW (λ w → r (s w))
            (OS.compose-continuous OW OV OZ s r cs cr) f
      restrictLabelled-comp OZ OV OW open-prop r s cr cs f =
        labelled-ext OW open-prop (λ w → refl)

      restrictArrows-id : {Z : Set ℓ} (OZ : OpenFragment Z) → OpenIsProp OZ
        → {m n : Z → X} (a : ArrowFamily OZ m n)
        → restrictArrows OZ OZ (λ z → z) (OS.identity-continuous OZ) a ≡ a
      restrictArrows-id OZ open-prop a = arrows-ext OZ open-prop (λ z → refl)

      restrictArrows-comp : {Z V W : Set ℓ}
        (OZ : OpenFragment Z) (OV : OpenFragment V) (OW : OpenFragment W)
        → OpenIsProp OW → (r : V → Z) (s : W → V)
        (cr : Continuous OV OZ r) (cs : Continuous OW OV s)
        → {m n : Z → X} (a : ArrowFamily OZ m n)
        → restrictArrows OV OW s cs (restrictArrows OZ OV r cr a)
          ≡ restrictArrows OZ OW (λ w → r (s w))
            (OS.compose-continuous OW OV OZ s r cs cr) a
      restrictArrows-comp OZ OV OW open-prop r s cr cs a =
        arrows-ext OW open-prop (λ w → refl)

-- Maps and pointwise computations use no finiteness, EM, FunExt or
-- proof-irrelevant openness. The final bundled equivalence states its
-- extra extensionality/openness hypotheses, with no universe resizing.
