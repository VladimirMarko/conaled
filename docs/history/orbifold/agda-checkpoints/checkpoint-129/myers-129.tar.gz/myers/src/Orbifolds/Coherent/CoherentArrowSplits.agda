{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentArrowSplits where

-- Exact finite split identities for the cubical resolution of a category.
-- All indices are outer; every actual chain remains an inner fibrant type.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken; _≤ᵖ_; pzero≤; psuc≤)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC

prefix-weaken : (n : Dim) (p : Position (osuc n))
  → prefix-degree (osuc n) (weaken p) ≡ˢ osuc (prefix-degree n p)
prefix-weaken n pzero = reflˢ
prefix-weaken (osuc n) (psuc p) = prefix-weaken n p

suffix-weaken : (n : Dim) (p : Position (osuc n))
  → suffix-degree (osuc n) (weaken p) ≡ˢ suffix-degree n p
suffix-weaken n pzero = reflˢ
suffix-weaken (osuc n) (psuc p) = strict-cong osuc (suffix-weaken n p)

in-prefix : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
  → Position (osuc (prefix-degree n p))
in-prefix n pzero q pzero≤ = q
in-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) = in-prefix n p q le

in-suffix : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
  → Position (osuc (suffix-degree n q))
in-suffix n pzero q pzero≤ = pzero
in-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) = psuc (in-suffix n p q le)

middle-degree : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q → Dim
middle-degree n pzero q pzero≤ = suffix-degree n q
middle-degree (osuc n) (psuc p) (psuc q) (psuc≤ le) = middle-degree n p q le

prefix-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → prefix-degree (prefix-degree n p) (in-prefix n p q le) ≡ˢ prefix-degree n q
prefix-prefix n pzero q pzero≤ = reflˢ
prefix-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) = prefix-prefix n p q le

prefix-suffix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → suffix-degree (prefix-degree n p) (in-prefix n p q le) ≡ˢ middle-degree n p q le
prefix-suffix n pzero q pzero≤ = reflˢ
prefix-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) = prefix-suffix n p q le

suffix-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → prefix-degree (suffix-degree n q) (in-suffix n p q le) ≡ˢ middle-degree n p q le
suffix-prefix n pzero q pzero≤ = reflˢ
suffix-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) = suffix-prefix n p q le

suffix-suffix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → suffix-degree (suffix-degree n q) (in-suffix n p q le) ≡ˢ suffix-degree n p
suffix-suffix n pzero q pzero≤ = reflˢ
suffix-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) = strict-cong osuc (suffix-suffix n p q le)

module Splits {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C
  open AC.Arrows C

  cast-chain : {m n : Dim} → m ≡ˢ n → {x y : Obj} → Chain m x y → Chain n x y
  cast-chain reflˢ c = c

  cast-append : {m n : Dim} (e : m ≡ˢ n) {x y z : Obj}
    (g : Hom y z) (c : Chain m x y)
    → outer (cast-chain (strict-cong osuc e) (append m g c))
      ≡ˢ outer (append n g (cast-chain e c))
  cast-append reflˢ g c = reflˢ

  cut-face-suffix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {x y : Obj} (c : Chain (osuc (osuc n)) x y)
    → outer (split n q (face (osuc n) (weaken p) c))
      ≡ˢ outer
        ( split-vertex (osuc n) (psuc q) c
        , face (suffix-degree n q) (in-suffix n p q le)
            (split-suffix (osuc n) (psuc q) c)
        , split-prefix (osuc n) (psuc q) c )
  cut-face-suffix n pzero pzero pzero≤ c = reflˢ
  cut-face-suffix (osuc n) pzero (psuc q) pzero≤ c = reflˢ
  cut-face-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-cong
    (λ z → outer
      ( inner z .fst
      , append (suffix-degree n q) (last-arrow (osuc (osuc n)) c) (inner z .snd .fst)
      , inner z .snd .snd ))
    (cut-face-suffix n p q le (before-last (osuc (osuc n)) c))

  NormalSplit : (n : Dim) → Position (osuc n) → Obj → Obj → Type ℓ
  NormalSplit n p x y = Σ[ z ∈ Obj ]
    (Chain (suffix-degree n p) z y × Chain (osuc (prefix-degree n p)) x z)

  -- Same cut after one extra vertex, with the block lengths normalized.
  normalized : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    → Chain (osuc (osuc n)) x y → NormalSplit n p x y
  normalized n p c =
    split-vertex (osuc n) (weaken p) c ,
    cast-chain (suffix-weaken n p) (split-suffix (osuc n) (weaken p) c) ,
    cast-chain (prefix-weaken n p) (split-prefix (osuc n) (weaken p) c)

  normalized-snoc : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (c : Chain (osuc (osuc (osuc n))) x y)
    → outer (normalized (osuc n) (psuc p) c)
      ≡ˢ outer
        ( normalized n p (before-last (osuc (osuc n)) c) .fst
        , append (suffix-degree n p) (last-arrow (osuc (osuc n)) c)
            (normalized n p (before-last (osuc (osuc n)) c) .snd .fst)
        , normalized n p (before-last (osuc (osuc n)) c) .snd .snd )
  normalized-snoc n p c = strict-cong
    (λ s → outer (split-vertex (osuc (osuc n)) (psuc (weaken p)) c , inner s ,
      cast-chain (prefix-weaken n p)
        (split-prefix (osuc n) (weaken p) (before-last (osuc (osuc n)) c))))
    (cast-append (suffix-weaken n p) (last-arrow (osuc (osuc n)) c)
      (split-suffix (osuc n) (weaken p) (before-last (osuc (osuc n)) c)))

  reduce-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {x y : Obj} → NormalSplit n p x y → Split n p x y
  reduce-prefix n p q le z = z .fst , z .snd .fst ,
    face (prefix-degree n p) (in-prefix n p q le) (z .snd .snd)

  cut-face-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {x y : Obj} (c : Chain (osuc (osuc n)) x y)
    → outer (split n p (face (osuc n) (psuc q) c))
      ≡ˢ outer (reduce-prefix n p q le (normalized n p c))
  cut-face-prefix n pzero q pzero≤ c = reflˢ
  cut-face-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer
        ( inner z .fst
        , append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .fst)
        , inner z .snd .snd ))
      (cut-face-prefix n p q le (before-last (osuc (osuc n)) c)))
    (strict-sym (strict-cong
      (λ z → outer (reduce-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) (inner z)))
      (normalized-snoc n p c)))

  Triple : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q → Obj → Obj → Type ℓ
  Triple n p q le x y = Σ[ z ∈ Obj ] Σ[ w ∈ Obj ]
    (Chain (suffix-degree n p) z y ×
      (Chain (middle-degree n p q le) w z × Chain (prefix-degree n q) x w))

  triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    → Chain (osuc (osuc n)) x y → Triple n p q le x y
  triple n pzero q pzero≤ c =
    last-source (osuc n) c ,
    split-vertex n q (before-last (osuc n) c) ,
    last-arrow (osuc n) c ,
    split-suffix n q (before-last (osuc n) c) ,
    split-prefix n q (before-last (osuc n) c)
  triple (osuc n) (psuc p) (psuc q) (psuc≤ le) c =
    z .fst , z .snd .fst ,
    append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (z .snd .snd .fst) ,
    z .snd .snd .snd
    where z = triple n p q le (before-last (osuc (osuc n)) c)

  prefix-triple-of : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    → NormalSplit n p x y → Triple n p q le x y
  prefix-triple-of n p q le z =
    z .fst , split-vertex (prefix-degree n p) (in-prefix n p q le) (z .snd .snd) ,
    z .snd .fst ,
    cast-chain (prefix-suffix n p q le)
      (split-suffix (prefix-degree n p) (in-prefix n p q le) (z .snd .snd)) ,
    cast-chain (prefix-prefix n p q le)
      (split-prefix (prefix-degree n p) (in-prefix n p q le) (z .snd .snd))

  prefix-triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y)
    → outer (prefix-triple-of n p q le (normalized n p c)) ≡ˢ outer (triple n p q le c)
  prefix-triple n pzero q pzero≤ c = reflˢ
  prefix-triple (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer (prefix-triple-of (osuc n) (psuc p) (psuc q) (psuc≤ le) (inner z)))
      (normalized-snoc n p c))
    (strict-cong
      (λ z → outer (inner z .fst , inner z .snd .fst ,
        append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .snd .fst) ,
        inner z .snd .snd .snd))
      (prefix-triple n p q le (before-last (osuc (osuc n)) c)))

  suffix-triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    → Chain (osuc (osuc n)) x y → Triple n p q le x y
  suffix-triple n p q le c =
    split-vertex (suffix-degree n q) (in-suffix n p q le) s ,
    split-vertex (osuc n) (psuc q) c ,
    cast-chain (suffix-suffix n p q le)
      (split-suffix (suffix-degree n q) (in-suffix n p q le) s) ,
    cast-chain (suffix-prefix n p q le)
      (split-prefix (suffix-degree n q) (in-suffix n p q le) s) ,
    split-prefix (osuc n) (psuc q) c
    where s = split-suffix (osuc n) (psuc q) c

  suffix-triple-correct : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y)
    → outer (suffix-triple n p q le c) ≡ˢ outer (triple n p q le c)
  suffix-triple-correct n pzero q pzero≤ c = reflˢ
  suffix-triple-correct (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer
        ( suffix-triple n p q le (before-last (osuc (osuc n)) c) .fst
        , suffix-triple n p q le (before-last (osuc (osuc n)) c) .snd .fst
        , inner z
        , suffix-triple n p q le (before-last (osuc (osuc n)) c) .snd .snd .snd ))
      (cast-append (suffix-suffix n p q le) (last-arrow (osuc (osuc n)) c)
        (split-suffix (suffix-degree n q) (in-suffix n p q le)
          (split-suffix (osuc n) (psuc q) (before-last (osuc (osuc n)) c)))))
    (strict-cong
      (λ z → outer (inner z .fst , inner z .snd .fst ,
        append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .snd .fst) ,
        inner z .snd .snd .snd))
      (suffix-triple-correct n p q le (before-last (osuc (osuc n)) c)))
