{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.PowerPushoutEvaluation where

-- The literal powered-span comparison evaluates to the literal map of
-- pushouts at each parameter, including the entire attaching path.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.GroupoidLaws using (cong-∙∙)
import Cubical.HITs.Pushout as PO
import Orbifolds.ExponentiationColimits as Power

module Comparison {ℓ : Level} (T : Type ℓ)
    {A₀ A₁ A₂ B₀ B₁ B₂ : Type ℓ}
    (a₁ : A₀ → A₁) (a₂ : A₀ → A₂) (b₁ : B₀ → B₁) (b₂ : B₀ → B₂)
    (f₀ : B₀ → T → A₀) (f₁ : B₁ → T → A₁) (f₂ : B₂ → T → A₂)
    (left-square : f₁ ∘ b₁ ≡ (λ v → a₁ ∘ v) ∘ f₀)
    (right-square : f₂ ∘ b₂ ≡ (λ v → a₂ ∘ v) ∘ f₀) where

  comparison : PO.Pushout b₁ b₂ → T → PO.Pushout a₁ a₂
  comparison = Power.Pushout.comparison T a₁ a₂ ∘
    PO.Pushout→ b₁ b₂ (λ v → a₁ ∘ v) (λ v → a₂ ∘ v)
      f₀ f₁ f₂ left-square right-square

  evaluated : (t : T) → PO.Pushout b₁ b₂ → PO.Pushout a₁ a₂
  evaluated t = PO.Pushout→ b₁ b₂ a₁ a₂
    (λ z → f₀ z t) (λ z → f₁ z t) (λ z → f₂ z t)
    (λ i z → left-square i z t) (λ i z → right-square i z t)

  evaluation-computation : (t : T) (z : PO.Pushout b₁ b₂) → comparison z t ≡ evaluated t z
  evaluation-computation t (PO.inl x) = refl
  evaluation-computation t (PO.inr x) = refl
  evaluation-computation t (PO.push z i) j = cong-∙∙
    (λ u → Power.Pushout.comparison T a₁ a₂ u t)
    (λ k → PO.inl (left-square k z))
    (PO.push (f₀ z)) (λ k → PO.inr (right-square (~ k) z)) j i
