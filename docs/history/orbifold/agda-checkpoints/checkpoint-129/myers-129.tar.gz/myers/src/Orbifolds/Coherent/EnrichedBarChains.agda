{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarChains where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Nat using (ℕ; zero; suc; _+_)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (Unit; tt)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
open import Cubical.Data.Empty using (⊥)
open import Orbifolds.Coherent.StrictEnriched

-- Finite positions are a recursive sum, so their eliminators compute on
-- transports. No indexed-pattern-match extension is used.
module Fin where
  Fin : ℕ → Type₀
  Fin zero = ⊥
  Fin (suc n) = Unit ⊎ Fin n

  pattern fzero = inl tt
  pattern fsuc i = inr i

  fromℕ : (n : ℕ) → Fin (suc n)
  fromℕ zero = inl tt
  fromℕ (suc n) = inr (fromℕ n)

  weakenFin : {n : ℕ} → Fin n → Fin (suc n)
  weakenFin {zero} ()
  weakenFin {suc n} (inl tt) = inl tt
  weakenFin {suc n} (inr i) = inr (weakenFin i)

  Order : (n : ℕ) → Fin n → Fin n → Type₀
  Order zero () j
  Order (suc n) (inl tt) j = Unit
  Order (suc n) (inr i) (inl tt) = ⊥
  Order (suc n) (inr i) (inr j) = Order n i j

module Chains {ℓo ℓh : Level} (C : Category ℓo ℓh) where
  open Category C
  ℓc = ℓ-max ℓo ℓh

  -- Endpoints are fixed in the family. An n-chain has n arrows and n+1 vertices.
  Chain : ℕ → Obj → Type ℓc
  Chain zero y = Lift {j = ℓc} Unit
  Chain (suc n) y = Σ[ x ∈ Obj ] (Hom x y × Chain n x)

  zero-chain : (x : Obj) → Chain zero x
  zero-chain x = lift tt

  last-source : (n : ℕ) {y : Obj} → Chain (suc n) y → Obj
  last-source n c = c .fst

  last-arrow : (n : ℕ) {y : Obj} (c : Chain (suc n) y) → Hom (last-source n c) y
  last-arrow n c = c .snd .fst

  prefix : (n : ℕ) {y : Obj} (c : Chain (suc n) y) → Chain n (last-source n c)
  prefix n c = c .snd .snd

  source : (n : ℕ) {y : Obj} → Chain n y → Obj
  source zero {y} c = y
  source (suc n) c = source n (prefix n c)

  whole : (n : ℕ) {y : Obj} (c : Chain n y) → Hom (source n c) y
  whole zero {y} c = ident y
  whole (suc n) c = compose (last-arrow n c) (whole n (prefix n c))

  append : (n : ℕ) {x y : Obj} → Hom x y → Chain n x → Chain (suc n) y
  append n {x} f c = x , f , c

  -- Reverse order of deleted vertices: 0 deletes the penultimate vertex.
  -- The final vertex is never removed; its face is the diagram action.
  face : (n : ℕ) → Fin.Fin (suc n) → {y : Obj} → Chain (suc n) y → Chain n y
  face zero Fin.fzero c = lift tt
  face zero (Fin.fsuc ()) c
  face (suc n) Fin.fzero c =
    prefix (suc n) c .fst ,
    compose (last-arrow (suc n) c) (last-arrow n (prefix (suc n) c)) ,
    prefix n (prefix (suc n) c)
  face (suc n) (Fin.fsuc i) c =
    last-source (suc n) c , last-arrow (suc n) c , face n i (prefix (suc n) c)

  drop-source : (n : ℕ) {y : Obj} → Chain (suc n) y → Chain n y
  drop-source zero c = lift tt
  drop-source (suc n) c = append n (last-arrow (suc n) c)
    (drop-source n (prefix (suc n) c))

  face-last-is-drop-source : (n : ℕ) {y : Obj} (c : Chain (suc n) y)
    → face n (Fin.fromℕ n) c ≡ drop-source n c
  face-last-is-drop-source zero c = refl
  face-last-is-drop-source (suc n) c = cong
    (append n (last-arrow (suc n) c))
    (face-last-is-drop-source n (prefix (suc n) c))

  -- Remove an arbitrary initial block while retaining the final endpoint.
  suffix : (a b : ℕ) {y : Obj} → Chain (a + b) y → Chain b y
  suffix zero b c = c
  suffix (suc a) b c = suffix a b (drop-source (a + b) c)

  suffix-zero : (a : ℕ) {y : Obj} (c : Chain (a + zero) y)
    → suffix a zero c ≡ zero-chain y
  suffix-zero zero c = refl
  suffix-zero (suc a) c = suffix-zero a (drop-source (a + zero) c)

  Index : ℕ → Type ℓc
  Index n = Σ[ y ∈ Obj ] Chain n y

  -- The order relation restricts the simplicial face identity to i ≤ j.
  _≤ᶠ_ : {n : ℕ} → Fin.Fin n → Fin.Fin n → Type₀
  _≤ᶠ_ {n} = Fin.Order n

  face-face : (n : ℕ) (i j : Fin.Fin (suc n)) → i ≤ᶠ j
    → {y : Obj} (c : Chain (suc (suc n)) y)
    → face n i (face (suc n) (Fin.fsuc j) c)
      ≡ face n j (face (suc n) (Fin.weakenFin i) c)
  face-face zero Fin.fzero Fin.fzero le c = refl
  face-face zero Fin.fzero (Fin.fsuc ()) le c
  face-face zero (Fin.fsuc ()) j le c
  face-face (suc n) Fin.fzero Fin.fzero le c =
    cong (λ f → append n f (prefix n (prefix (suc n) (prefix (suc (suc n)) c))))
      (strict-to-path (assoc
        (last-arrow (suc (suc n)) c)
        (last-arrow (suc n) (prefix (suc (suc n)) c))
        (last-arrow n (prefix (suc n) (prefix (suc (suc n)) c)))))
  face-face (suc n) Fin.fzero (Fin.fsuc j) le c = refl
  face-face (suc n) (Fin.fsuc i) Fin.fzero () c
  face-face (suc n) (Fin.fsuc i) (Fin.fsuc j) le c =
    cong (append n (last-arrow (suc (suc n)) c))
      (face-face n i j le (prefix (suc (suc n)) c))

module Cochains {ℓo ℓh ℓ : Level} {C : Category ℓo ℓh}
    (D : Diagram C ℓ) where
  open Category C
  open Diagram D
  open Chains C

  Cochain : ℕ → Type (ℓ-max ℓ (ℓ-max ℓo ℓh))
  Cochain n = (y : Obj) → Chain n y → Value y

  -- The missing final vertex is evaluated with the actual functor action.
  action-face : (n : ℕ) → Cochain n → Cochain (suc n)
  action-face n h y c = action (last-arrow n c)
    (h (last-source n c) (prefix n c))

  other-face : (n : ℕ) → Fin.Fin (suc n) → Cochain n → Cochain (suc n)
  other-face n i h y c = h y (face n i c)

  -- The overlap of two final action faces is the functor composition law.
  action-action : (n : ℕ) (h : Cochain n)
    → other-face (suc n) Fin.fzero (action-face n h)
      ≡ action-face (suc n) (action-face n h)
  action-action n h = funExt λ y → funExt λ c → strict-to-path
    (action-compose-point
      (last-arrow (suc n) c)
      (last-arrow n (prefix (suc n) c))
      (h (last-source n (prefix (suc n) c)) (prefix n (prefix (suc n) c))))

  action-other : (n : ℕ) (i : Fin.Fin (suc n)) (h : Cochain n)
    → other-face (suc n) (Fin.fsuc i) (action-face n h)
      ≡ action-face (suc n) (other-face n i h)
  action-other n i h = refl

  other-other : (n : ℕ) (i j : Fin.Fin (suc n)) → i ≤ᶠ j
    → (h : Cochain n)
    → other-face (suc n) (Fin.fsuc j) (other-face n i h)
      ≡ other-face (suc n) (Fin.weakenFin i) (other-face n j h)
  other-other n i j le h = funExt λ y → funExt λ c →
    cong (h y) (face-face n i j le c)

  Point : Type (ℓ-max ℓ ℓo)
  Point = (y : Obj) → Value y

  point-to-cochain : Point → Cochain zero
  point-to-cochain p y c = p y

  cochain-to-point : Cochain zero → Point
  cochain-to-point h y = h y (zero-chain y)

  point-roundtrip : (p : Point) → cochain-to-point (point-to-cochain p) ≡ p
  point-roundtrip p = refl

  cochain-roundtrip : (h : Cochain zero) → point-to-cochain (cochain-to-point h) ≡ h
  cochain-roundtrip h = refl
