{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.EffectiveAtlasSetTarget where

-- The actual EffectiveAtlas hom/path equivalence forces proposition-valued
-- homs when its quotient target is a set. The source theorem itself assumes
-- sethood of the atlas object type, not of that quotient target.
-- This control distinguishes restricted set-model instances from atlases
-- retaining nontrivial isotropy; it does not reject restricted set models.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (BoundedTruncation)
open import Orbifolds.Intensional.FiniteBranchAtlas using (module Finiteness)

module At {ℓ : Level} (T : BoundedTruncation ℓ) where
  module F = Finiteness T
  open F.EffectiveAtlas

  set-target-homs-prop :
    {A X : Set ℓ} (Q : F.EffectiveAtlas A X) → isSet X
    → (a b : A) → isProp (hom Q a b)
  set-target-homs-prop Q setX a b h k =
    sym (retraction (hom-path Q a b) h)
    ∙ cong (backward (hom-path Q a b))
        (setX (atlas Q a) (atlas Q b)
          (forward (hom-path Q a b) h)
          (forward (hom-path Q a b) k))
    ∙ retraction (hom-path Q a b) k

-- Only hom-path and the additional isSet X premise are used. In particular,
-- no truncation elimination, function extensionality, properness or resizing
-- is required. Set ℓ above denotes a universe, not a sethood premise.
