{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexBasisNormalization where

-- An actual real basis of the complex plane can merely be put in the
-- form (lambda*tau,lambda), with tau in the upper half-plane, after
-- possibly interchanging its two integral generators.  This is the
-- normalization step for the literal finite-free lattice moduli map.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Relation.Nullary using (¬_)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.SyntheticSeparated as SS
import Orbifolds.ComplexPairs as CP
import Orbifolds.UpperHalfPlane as UH
import Orbifolds.RealLatticeSpanning as LS

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext R using (Invertible)
  open SF.RingContext.StrictOrder order
  open SO.OrderTheory R order
  open Compatible compatibility
  open Field kock
  module C = CP.Ring R
  module H = UH.Geometry R kock order compatibility
  module Spanning = LS.Geometry R kock order compatibility
  open C using (Complex; _*c_)

  cross-imaginary : Complex → Complex → R .fst
  cross-imaginary u v = u .snd · v .fst - u .fst · v .snd

  abstract
    cross-zero-right : (u : Complex) → cross-imaginary u C.zero ≡ 0r
    cross-zero-right u = solve! R

    cross-determinant : (u v : Complex)
      → cross-imaginary u v ≡ - Spanning.determinant u v
    cross-determinant u v = solve! R

    cross-swapped : (u v : Complex)
      → cross-imaginary v u ≡ Spanning.determinant u v
    cross-swapped u v = solve! R

    inverse-imaginary : (u v : Complex) (t : R .fst)
      → C.im (C.inverse-with-norm v t *c u) ≡ cross-imaginary u v · t
    inverse-imaginary u v t = solve! R

    zero-difference : (d : R .fst) → 0r - d ≡ - d
    zero-difference d = solve! R

  module Positive (u v : Complex) (positive : 0r < cross-imaginary u v) where
    v-nonzero : ¬ (v ≡ C.zero)
    v-nonzero vanishes = positiveNonzero positive
      (cong (cross-imaginary u) vanishes ∙ cross-zero-right u)

    reciprocal : Σ[ t ∈ R .fst ] (0r < t) × (C.norm v · t ≡ 1r)
    reciprocal = positiveInverse (C.norm v) (H.complex-norm-positive v v-nonzero)

    inverse : Complex
    inverse = C.inverse-with-norm v (reciprocal .fst)

    unit : v *c inverse ≡ C.one
    unit = C.inverse-with-norm-right v (reciprocal .fst) (reciprocal .snd .snd)

    value : Complex
    value = inverse *c u

    value-positive : 0r < C.im value
    value-positive = subst (0r <_) (sym (inverse-imaginary u v (reciprocal .fst)))
      (positive-multiply positive (reciprocal .snd .fst))

    parameter : H.UpperHalfPlane
    parameter = value , value-positive

    equation : v *c parameter .fst ≡ u
    equation = C.multiply-associative v inverse u
      ∙ cong (_*c u) unit
      ∙ C.multiply-commutative C.one u ∙ C.multiply-right-unit u

  NormalizedBasis : Complex → Complex → Type ℓ
  NormalizedBasis u v = Σ[ τ ∈ H.UpperHalfPlane ]
    Σ[ scalar ∈ Complex ] Σ[ inverse ∈ Complex ]
      (scalar *c inverse ≡ C.one) ×
      (((scalar *c τ .fst ≡ u) × (scalar ≡ v)) ⊎
       ((scalar *c τ .fst ≡ v) × (scalar ≡ u)))

  normalize : (u v : Complex) → Invertible (Spanning.determinant u v)
    → PT.∥ NormalizedBasis u v ∥₁
  normalize u v determinant-unit = PT.map (Sum.rec negative positive)
    (nonzero-sign (Spanning.determinant u v)
      (SS.Separation.invertibleNonzero R kock _ determinant-unit))
    where
    negative : Spanning.determinant u v < 0r → NormalizedBasis u v
    negative below = N.parameter , v , N.inverse , N.unit , inl (N.equation , refl)
      where
      cross-positive : 0r < cross-imaginary u v
      cross-positive = subst (0r <_) (sym (cross-determinant u v))
        (subst (0r <_) (zero-difference (Spanning.determinant u v))
          (SO.OrderTheory.OrderedRingCompatibility.less→positiveDifference compatibility below))
      module N = Positive u v cross-positive

    positive : 0r < Spanning.determinant u v → NormalizedBasis u v
    positive above = N.parameter , u , N.inverse , N.unit , inr (N.equation , refl)
      where
      module N = Positive v u (subst (0r <_) (sym (cross-swapped u v)) above)
