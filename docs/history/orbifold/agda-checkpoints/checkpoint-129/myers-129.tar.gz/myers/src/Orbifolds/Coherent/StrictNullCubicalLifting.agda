{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictNullCubicalLifting where

-- Relative nullification lifting with an arbitrary specified cube on
-- generators. The specified cube can carry all original coherences;
-- it need not be constant. Every filler is constructed by Null.elim.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc; toNat; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; endpoint; Faces; Compatible)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Cubical.HITs.Nullification.Base as NB
import Orbifolds.NullCubicalExtensions as NC
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Lifting {ℓ : Level} {Ix : Type₀} (S : Ix → Type ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  module Null = NC.Nullification S
  module Fill = Fillers.Boundary E

  module Extension (n : Dim) (X Y : Type ℓ) (nullY : NB.isNull S Y)
      (boundary : NB.Null S X → CS.Shell (toNat n) Y)
      (unit-cube : X → Cube n Y)
      (boundary-at-unit : (x : X)
        → outer (boundary NB.∣ x ∣) ≡ˢ outer (CS.restriction (toNat n) (unit-cube x))) where

    base : (x : X) → CF.Filler (toNat n) (boundary NB.∣ x ∣)
    base x = cast-filler n (strict-sym (boundary-at-unit x))
      (CF.canonical-filler (toNat n) (unit-cube x))

    module ExtensionSpace = Null.Cubical X Y nullY (toNat n) boundary

    filler : (a : NB.Null S X) → CF.Filler (toNat n) (boundary a)
    filler = ExtensionSpace.extend base

    filler-unit : (x : X) → outer (filler NB.∣ x ∣) ≡ˢ outer (base x)
    filler-unit x = reflˢ

    cube : NB.Null S X → Cube n Y
    cube a = CF.forget-filler (toNat n) (boundary a) (filler a)

    cube-boundary : (a : NB.Null S X)
      → outer (CS.restriction (toNat n) (cube a)) ≡ˢ outer (boundary a)
    cube-boundary a = Fill.forget-boundary-strict n (boundary a) (filler a)

    cube-unit : (x : X) → outer (cube NB.∣ x ∣) ≡ˢ outer (unit-cube x)
    cube-unit x = strict-trans
      (cast-forget n (strict-sym (boundary-at-unit x)) (CF.canonical-filler (toNat n) (unit-cube x)))
      (Fill.forget-canonical-strict n (unit-cube x))

    extensions-contractible : isContr (ExtensionSpace.extension-space base)
    extensions-contractible = ExtensionSpace.extensions-contractible base

  module Assembled (n : Dim) (X Y : Type ℓ) (nullY : NB.isNull S Y)
      (faces : (a : NB.Null S X) → Faces (osuc n) Y)
      (compatible : (a : NB.Null S X) → Compatible (osuc n) (faces a))
      (unit-cube : X → Cube (osuc n) Y)
      (unit-faces : (x : X) (p : Position (osuc n)) (e : Endpoint)
        → outer (faces NB.∣ x ∣ p e)
          ≡ˢ outer (coordinate-face n p (endpoint e) (unit-cube x))) where

    boundary : NB.Null S X → CS.Shell (toNat (osuc n)) Y
    boundary a = Assembly.Construction.assemble E (osuc n) (faces a) (compatible a)

    boundary-at-unit : (x : X)
      → outer (boundary NB.∣ x ∣) ≡ˢ outer (CS.restriction (toNat (osuc n)) (unit-cube x))
    boundary-at-unit x = Assembly.Construction.assemble-restriction E (osuc n)
      (faces NB.∣ x ∣) (compatible NB.∣ x ∣) (unit-cube x) (unit-faces x)

    module Extended = Extension (osuc n) X Y nullY boundary unit-cube boundary-at-unit
    open Extended using (base; filler; filler-unit; cube; cube-boundary; cube-unit;
      extensions-contractible) public

    cube-face : (a : NB.Null S X) (p : Position (osuc n)) (e : Endpoint)
      → outer (coordinate-face n p (endpoint e) (cube a)) ≡ˢ outer (faces a p e)
    cube-face a p e = Fill.assembled-filler-face n (faces a) (compatible a) (filler a) p e
