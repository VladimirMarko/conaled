{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.Coherent.PowerCellularCoconeNaturality where

-- A presentation-only canonical-comparison theorem. The finite mapping
-- homotopies and their actual transition squares yield equality of the
-- complete sequential cocones. Applications construct these finite data
-- with an inner coinductive witness; no diagram representation, global
-- canonicality, or comparison equivalence is assumed here.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.HITs.SequentialColimit as SC
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularPresentationComparisons as Comparisons
import Orbifolds.TinyCellularPresentations as Operations
import Orbifolds.ExponentiationColimits as Exponentiation
import Orbifolds.CellularConeMicrolinearity as Towers

module Power {ℓ : Level} (T : Type ℓ) {A B : Type ℓ}
    (P : CP.Presentation A) (Q : CP.Presentation B) (initial : B → T → A)
    (cells : Comparisons.Theory.RelativeMap (Operations.Power.operations T) P Q initial) where
  module Comparison = Comparisons.Theory.Realization (Operations.Power.operations T) P Q initial cells
  module Original = Comparison.Original
  module Powered = Comparison.Supplied
  open Comparison using (comparison; stage-map) public

  direct-evaluation : (t : T) → Powered.Realize → Original.Realize
  direct-evaluation t (SC.incl {n} x) = SC.incl {n = n} (stage-map n x t)
  direct-evaluation t (SC.push {n} x i) = SC.push {n = n} (stage-map n x t) i

  evaluation-computation : (t : T) (z : Powered.Realize)
    → comparison z t ≡ direct-evaluation t z
  evaluation-computation t (SC.incl x) = refl
  evaluation-computation t (SC.push {n} x i) j =
    Exponentiation.SequenceColimit.comparison {ℓ = ℓ} T Original.stages
      (compPath-filler
        (SC.push {X = Exponentiation.SequenceColimit.PoweredSequence {ℓ = ℓ} T Original.stages}
          {n = n} (stage-map n x)) refl (~ j) i) t

  module Mapping (Y : Type ℓ) (t : T)
      (V W : ℕ → Type ℓ)
      (drop-V : (n : ℕ) → V (suc n) → V n)
      (drop-W : (n : ℕ) → W (suc n) → W n)
      (original-stage : (n : ℕ) → (Original.Stage n → Y) → V n)
      (powered-stage : (n : ℕ) → (Powered.Stage n → Y) → W n)
      (powered-square : (n : ℕ) (h : Powered.Stage (suc n) → Y)
        → drop-W n (powered-stage (suc n) h)
          ≡ powered-stage n (h ∘ Powered.inclusion n))
      (restriction : (n : ℕ) → V n → W n)
      (right-square : (n : ℕ) (h : Original.Stage (suc n) → Y)
        → drop-W n (restriction (suc n) (original-stage (suc n) h))
          ≡ restriction n (original-stage n (h ∘ Original.inclusion n))) where
    module Target = Towers.InverseTower W drop-W

    left right : (n : ℕ) → (Original.Stage n → Y) → W n
    left n h = powered-stage n (λ x → h (stage-map n x t))
    right n h = restriction n (original-stage n h)

    powered-restrict : (Powered.Realize → Y) → Target.Limit
    powered-restrict h .fst n = powered-stage n (h ∘ SC.incl {n = n})
    powered-restrict h .snd n = powered-square n (h ∘ SC.incl {n = suc n})
      ∙ cong (powered-stage n) (λ i x → h (SC.push {n = n} x (~ i)))

    source-edge : (h : Original.Realize → Y) (n : ℕ)
      → (h ∘ SC.incl {n = suc n} ∘ Original.inclusion n) ≡ (h ∘ SC.incl {n = n})
    source-edge h n i x = h (SC.push {n = n} x (~ i))

    restricted-original : (Original.Realize → Y) → Target.Limit
    restricted-original h .fst n = right n (h ∘ SC.incl {n = n})
    restricted-original h .snd n = right-square n (h ∘ SC.incl {n = suc n})
      ∙ cong (right n) (source-edge h n)

    module Homotopy (stage-homotopy : (n : ℕ) → left n ≡ right n)
        (stage-square : (n : ℕ) (h : Original.Stage (suc n) → Y)
          → PathP (λ i → drop-W n (stage-homotopy (suc n) i h)
              ≡ stage-homotopy n i (h ∘ Original.inclusion n))
            (powered-square n (λ x → h (stage-map (suc n) x t)))
            (right-square n h)) where

      direct-restrict-natural : (h : Original.Realize → Y)
        → powered-restrict (h ∘ direct-evaluation t) ≡ restricted-original h
      direct-restrict-natural h i .fst n = stage-homotopy n i (h ∘ SC.incl {n = n})
      direct-restrict-natural h i .snd n =
        (λ j → stage-square n (h ∘ SC.incl {n = suc n}) i j)
        ∙ cong (stage-homotopy n i) (source-edge h n)

      restrict-natural : (h : Original.Realize → Y)
        → powered-restrict (λ z → h (comparison z t)) ≡ restricted-original h
      restrict-natural h = cong powered-restrict (funExt λ z → cong h (evaluation-computation t z))
        ∙ direct-restrict-natural h
