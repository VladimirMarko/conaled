{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispCompactCovers where

-- The actual second-countable refinement theorem feeds the actual crisp
-- finite-subcover theorem. This is the universe-bounded topological
-- consequence in Remark 6.2.16; no decidability of ordinary families is
-- inferred. The constructed Penon basis uses exactly the topology's opens.

open import Cubical.Foundations.Prelude hiding (J)
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.SubFinSet using (isSubFinSet→isSet)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.CountableCovers using (CountableProbe; Covers)
open import Orbifolds.Penon using (PenonOpen)
open import Orbifolds.Refinements
  using (CountablePenonBasis; SubfiniteRefinement; secondCountableRefinement)
open import Orbifolds.Topology using (Topology; IsOpen; Regular; regularOpen→PenonOpen)
import Orbifolds.SubspaceBases as SB
open import Orbifolds.ProperFiniteness using (subfiniteProperlyFinite; enumerable)
open import Orbifolds.CrispFiniteCovers
  using (OpenEnumerableRefinement; FiniteSubcover; RefinementSubcompact)
import Orbifolds.CrispFiniteCovers as FC
import Orbifolds.CrispPropositions as CP

module Basis {ℓ : Level} {K : Type ℓ}
    (topology : Topology K) (basis : CountablePenonBasis K)
    (basis→topology : (U : K → hProp ℓ)
      → CountablePenonBasis.Open basis U → IsOpen topology U) where
  module ForCover {I : Type ℓ} (U : I → K → hProp ℓ) where
    from-basis-refinement : SubfiniteRefinement basis U
      → OpenEnumerableRefinement topology U
    from-basis-refinement refinement = record
      { Index = V.Index
      ; index-isSet = isSubFinSet→isSet V.indexSubfinite
      ; index-enumerable = enumerable (subfiniteProperlyFinite V.indexSubfinite)
      ; member = V.member
      ; member-open = λ j → basis→topology (V.member j) (V.memberOpen j)
      ; covers = V.covers
      ; refines = V.refines
      }
      where
      module V = SubfiniteRefinement refinement

  refinement-subcompact : (balls : BallStructure ℓ)
    → CoveringProperty balls → CountableProbe balls → DPCompact K
    → ((U : K → hProp ℓ) → IsOpen topology U → CountablePenonBasis.Open basis U)
    → RefinementSubcompact topology
  refinement-subcompact balls covering probes compactK topology→basis I setI U openU coversU =
    PT.map (ForCover.from-basis-refinement U)
      (secondCountableRefinement balls covering probes compactK basis U
        (λ i → topology→basis (U i) (openU i)) coversU)

module TopologicalBasis {ℓ : Level} {K : Type ℓ}
    (topology : Topology K) (basis : SB.CountableBasis topology)
    (opens-penon : (U : K → hProp ℓ) → IsOpen topology U → PenonOpen U) where
  penon-basis : CountablePenonBasis K
  penon-basis = record
    { Open = IsOpen topology
    ; basic = SB.CountableBasis.basic basis
    ; basicOpen = SB.CountableBasis.basicOpen basis
    ; open→PenonOpen = opens-penon
    ; localBasis = SB.CountableBasis.localBasis basis
    }

  module Adapter = Basis topology penon-basis (λ _ p → p)

  refinement-subcompact : (balls : BallStructure ℓ)
    → CoveringProperty balls → CountableProbe balls → DPCompact K
    → RefinementSubcompact topology
  refinement-subcompact balls covering probes compactK =
    Adapter.refinement-subcompact balls covering probes compactK (λ _ p → p)

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    {@♭ K : Type ℓ} (@♭ topology : Topology K)
    (@♭ basis : SB.CountableBasis topology)
    (@♭ opens-penon : (U : K → hProp ℓ) → IsOpen topology U → PenonOpen U)
    (@♭ balls : BallStructure ℓ) (@♭ covering : CoveringProperty balls)
    (@♭ probes : CountableProbe balls) (@♭ compactK : DPCompact K) where
  module Propositions = CP.Context R r₀
  module Refinement = TopologicalBasis topology basis opens-penon

  derived-refinement-subcompact : RefinementSubcompact topology
  derived-refinement-subcompact = Refinement.refinement-subcompact
    balls covering probes compactK

  module Cover {@♭ I : Type ℓ} (@♭ setI : isSet I)
      (@♭ U : I → K → hProp ℓ)
      (@♭ openU : (i : I) → IsOpen topology (U i))
      (@♭ coversU : Covers U) where
    module Finite = FC.Context.Cover R r₀ topology setI U

    finite-subcover : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → FlatTruncationDistribution {ℓ = ℓ}
      → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
      → PT.∥ FiniteSubcover U ∥₁
    finite-subcover real-flat excluded-middle distribute distribute-upper =
      Finite.crisp-subcompact→finite-subcover real-flat excluded-middle
        distribute distribute-upper derived-refinement-subcompact openU coversU

-- Ordinary manifolds already supply a countable basis and regularity.
-- This specialization derives the required Penon openness of all opens.
module RegularContext {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    {@♭ K : Type ℓ} (@♭ topology : Topology K)
    (@♭ basis : SB.CountableBasis topology) (@♭ regular : Regular topology)
    (@♭ balls : BallStructure ℓ) (@♭ covering : CoveringProperty balls)
    (@♭ probes : CountableProbe balls) (@♭ compactK : DPCompact K) where
  module Proof = Context R r₀ topology basis
    (regularOpen→PenonOpen topology regular) balls covering probes compactK
  open Proof public
