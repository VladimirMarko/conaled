{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CoherentTriangleLimits where

-- A fixed coherent triangle, including its specified composition
-- 2-cell. The full cone coherence is retained as a square, not truncated.
-- This is a finite diagram shape, not a model of arbitrary infinity
-- categories or of diagrams with unbounded coherence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module Diagram {ℓx ℓy ℓz : Level}
    (X : Type ℓx) (Y : Type ℓy) (Z : Type ℓz)
    (f : X → Y) (g : Y → Z) (h : X → Z)
    (composition : (x : X) → g (f x) ≡ h x) where

  -- The square says that the f-then-g cone path agrees with the
  -- h-cone path after the specified composition homotopy.
  Coherence : (x : X) (y : Y) (z : Z)
    → f x ≡ y → g y ≡ z → h x ≡ z → Type ℓz
  Coherence x y z p q r = Square (cong g p) r (composition x) q

  Completion : X → Type (ℓ-max ℓy ℓz)
  Completion x = Σ[ yp ∈ singl (f x) ]
    Σ[ zq ∈ singl (g (yp .fst)) ]
    Σ[ r ∈ (h x ≡ zq .fst) ]
      Coherence x (yp .fst) (zq .fst) (yp .snd) (zq .snd) r

  completion-contractible : (x : X) → isContr (Completion x)
  completion-contractible x = isContrΣ (isContrSingl (f x)) λ yp →
    isContrΣ (isContrSingl (g (yp .fst))) λ zq →
      isContrSinglP (λ i → composition x i ≡ zq .snd i) (cong g (yp .snd))

  Limit : Type (ℓ-max ℓx (ℓ-max ℓy ℓz))
  Limit = Σ X Completion

  project-X : Limit → X
  project-X = fst

  project-Y : Limit → Y
  project-Y u = u .snd .fst .fst

  project-Z : Limit → Z
  project-Z u = u .snd .snd .fst .fst

  project-f : (u : Limit) → f (project-X u) ≡ project-Y u
  project-f u = u .snd .fst .snd

  project-g : (u : Limit) → g (project-Y u) ≡ project-Z u
  project-g u = u .snd .snd .fst .snd

  project-h : (u : Limit) → h (project-X u) ≡ project-Z u
  project-h u = u .snd .snd .snd .fst

  project-coherence : (u : Limit)
    → Coherence (project-X u) (project-Y u) (project-Z u)
        (project-f u) (project-g u) (project-h u)
  project-coherence u = u .snd .snd .snd .snd

  canonical-completion : (x : X) → Completion x
  canonical-completion x = (f x , refl) , (g (f x) , refl) ,
    sym (composition x) , (λ i j → composition x (i ∧ ~ j))

  insert : X → Limit
  insert x = x , canonical-completion x

  insert-project : (u : Limit) → insert (project-X u) ≡ u
  insert-project (x , c) = cong (x ,_)
    (isContr→isProp (completion-contractible x) (canonical-completion x) c)

  -- The forward map is the literal first-vertex projection. Its inverse
  -- has the literal f and g∘f legs, and the supplied composition 2-cell.
  limit≃initial : Limit ≃ X
  limit≃initial = isoToEquiv (iso project-X insert (λ _ → refl) insert-project)

  record Cone {ℓa : Level} (A : Type ℓa)
      : Type (ℓ-max ℓa (ℓ-max ℓx (ℓ-max ℓy ℓz))) where
    field
      leg-X : A → X
      leg-Y : A → Y
      leg-Z : A → Z
      commutes-f : (a : A) → f (leg-X a) ≡ leg-Y a
      commutes-g : (a : A) → g (leg-Y a) ≡ leg-Z a
      commutes-h : (a : A) → h (leg-X a) ≡ leg-Z a
      coherence : (a : A)
        → Coherence (leg-X a) (leg-Y a) (leg-Z a)
            (commutes-f a) (commutes-g a) (commutes-h a)
  open Cone

  restrict : {ℓa : Level} {A : Type ℓa} → (A → Limit) → Cone A
  restrict u .leg-X = project-X ∘ u
  restrict u .leg-Y = project-Y ∘ u
  restrict u .leg-Z = project-Z ∘ u
  restrict u .commutes-f = project-f ∘ u
  restrict u .commutes-g = project-g ∘ u
  restrict u .commutes-h = project-h ∘ u
  restrict u .coherence = project-coherence ∘ u

  assemble : {ℓa : Level} {A : Type ℓa} → Cone A → A → Limit
  assemble c a = leg-X c a , (leg-Y c a , commutes-f c a) ,
    (leg-Z c a , commutes-g c a) , commutes-h c a , coherence c a

  -- The pointwise path and square fields retain their complete higher
  -- identity types. Both inverse laws include the square field.
  universal : {ℓa : Level} (A : Type ℓa) → (A → Limit) ≃ Cone A
  universal A = isoToEquiv (iso restrict assemble (λ _ → refl) (λ _ → refl))

  precompose-cone : {ℓa ℓb : Level} {A : Type ℓa} {B : Type ℓb}
    → Cone A → (B → A) → Cone B
  precompose-cone c k = restrict (assemble c ∘ k)

  universal-natural : {ℓa ℓb : Level} {A : Type ℓa} {B : Type ℓb}
    (u : A → Limit) (k : B → A)
    → restrict (u ∘ k) ≡ precompose-cone (restrict u) k
  universal-natural u k = refl

  initial-cone : Cone X
  initial-cone = restrict insert

  initial-universal : {ℓa : Level} (A : Type ℓa) → (A → X) ≃ Cone A
  initial-universal A = compEquiv (postCompEquiv (invEquiv limit≃initial)) (universal A)

  initial-universal-computation : {ℓa : Level} {A : Type ℓa} (u : A → X)
    → initial-universal A .fst u ≡ precompose-cone initial-cone u
  initial-universal-computation u = refl

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw) where
    module M = Micro.Theory test
    module Closure = ML.Limits test

    -- Only the initial vertex is needed, since the actual coherent
    -- limit is equivalent to it. This applies to every infinitesimal
    -- test family, including the full pointed-variety formulation.
    limit-microlinear : M.Microlinear X → M.Microlinear Limit
    limit-microlinear micro = Closure.microlinear-equiv (invEquiv limit≃initial) micro
