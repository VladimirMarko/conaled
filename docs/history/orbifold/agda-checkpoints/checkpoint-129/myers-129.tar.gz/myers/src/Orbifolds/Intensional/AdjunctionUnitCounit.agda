{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.AdjunctionUnitCounit where

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.CategoricalTransfer

-- Unit, counit, their naturalities and both triangles follow from the
-- existing hom-equivalence definition of an ordinary adjunction.

module On {o h : Level} (E C : Category o h)
    (L : Functor E C) (U : Functor C E) (adj : Adjunction L U) where
  private
    module E = Category E
    module C = Category C
    module L = Functor L
    module U = Functor U
    module A = Adjunction adj

  transpose : {X : E.Obj} {Y : C.Obj} → C.Hom (L.object X) Y → E.Hom X (U.object Y)
  transpose {X} {Y} = forward (A.hom-equivalence X Y)

  transpose-injective : {X : E.Obj} {Y : C.Obj} {f g : C.Hom (L.object X) Y}
    → transpose {X = X} {Y = Y} f ≡ transpose {X = X} {Y = Y} g → f ≡ g
  transpose-injective {X} {Y} {f} {g} same =
    sym (retraction (A.hom-equivalence X Y) f)
    ∙ cong (backward (A.hom-equivalence X Y)) same
    ∙ retraction (A.hom-equivalence X Y) g

  unit : (X : E.Obj) → E.Hom X (U.object (L.object X))
  unit X = transpose {X = X} {Y = L.object X} (C.identity {X = L.object X})

  counit : (Y : C.Obj) → C.Hom (L.object (U.object Y)) Y
  counit Y = backward (A.hom-equivalence (U.object Y) Y) (E.identity {X = U.object Y})

  transpose-counit : (Y : C.Obj)
    → transpose {X = U.object Y} {Y = Y} (counit Y) ≡ E.identity {X = U.object Y}
  transpose-counit Y = section (A.hom-equivalence (U.object Y) Y) (E.identity {X = U.object Y})

  transpose-by-unit : {X : E.Obj} {Y : C.Obj} (f : C.Hom (L.object X) Y)
    → transpose {X = X} {Y = Y} f ≡ E.compose (U.arrow f) (unit X)
  transpose-by-unit {X} {Y} f =
    cong (transpose {X = X} {Y = Y}) (sym (C.identity-right {X = L.object X} {Y = Y} f))
    ∙ A.natural-target {X = X} {Y = L.object X} {Z = Y} f (C.identity {X = L.object X})

  unit-natural : {W X : E.Obj} (s : E.Hom W X)
    → E.compose (U.arrow (L.arrow s)) (unit W) ≡ E.compose (unit X) s
  unit-natural {W} {X} s =
    sym (transpose-by-unit {X = W} {Y = L.object X} (L.arrow s))
    ∙ cong (transpose {X = W} {Y = L.object X})
      (sym (C.identity-left {X = L.object W} {Y = L.object X} (L.arrow s)))
    ∙ A.natural-source {W = W} {X = X} {Y = L.object X} s (C.identity {X = L.object X})

  counit-natural : {Y Z : C.Obj} (t : C.Hom Y Z)
    → C.compose t (counit Y) ≡ C.compose (counit Z) (L.arrow (U.arrow t))
  counit-natural {Y} {Z} t = transpose-injective {X = U.object Y} {Y = Z}
    (A.natural-target {X = U.object Y} {Y = Y} {Z = Z} t (counit Y)
      ∙ cong (λ q → E.compose (U.arrow t) q) (transpose-counit Y)
      ∙ E.identity-right {X = U.object Y} {Y = U.object Z} (U.arrow t)
      ∙ sym (A.natural-source {W = U.object Y} {X = U.object Z} {Y = Z} (U.arrow t) (counit Z)
        ∙ cong (λ q → E.compose q (U.arrow t)) (transpose-counit Z)
        ∙ E.identity-left {X = U.object Y} {Y = U.object Z} (U.arrow t)))

  left-triangle : (X : E.Obj)
    → C.compose (counit (L.object X)) (L.arrow (unit X)) ≡ C.identity {X = L.object X}
  left-triangle X = transpose-injective {X = X} {Y = L.object X}
    (A.natural-source {W = X} {X = U.object (L.object X)} {Y = L.object X}
      (unit X) (counit (L.object X))
      ∙ cong (λ q → E.compose q (unit X)) (transpose-counit (L.object X))
      ∙ E.identity-left {X = X} {Y = U.object (L.object X)} (unit X))

  right-triangle : (Y : C.Obj)
    → E.compose (U.arrow (counit Y)) (unit (U.object Y)) ≡ E.identity {X = U.object Y}
  right-triangle Y = sym (transpose-by-unit {X = U.object Y} {Y = Y} (counit Y))
    ∙ transpose-counit Y
