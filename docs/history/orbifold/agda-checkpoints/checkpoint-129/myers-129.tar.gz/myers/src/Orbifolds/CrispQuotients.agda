{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispQuotients where

-- Theorem 5.4.1 for actual crisp pointed connected deloopings. The
-- modal-delooping premise is derived from discrete loops and the crisp
-- point-pullback axiom, not added to the action data.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Unit
open import Cubical.Data.FinSet using (isFinSet; isFinSet→Discrete)
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
open import Orbifolds.Quotients using (Delooping; BG; point; Loop)
import Orbifolds.CrispGeometry as CG
import Orbifolds.CrispWeil as CW
import Orbifolds.SyntheticField as SF
import Orbifolds.ModalDelooping as MD
import Orbifolds.QuotientMicrolinear as QM
import Orbifolds.Quotients as Q
import Orbifolds.DecidableDiscrete as DD
import Orbifolds.Orbifold as O

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R) (@♭ G : Delooping ℓ) where
  open CG.Context R
  module Deloopings = MD.Theory Infinitesimal.CrystallineModality
    Infinitesimal.crystalline-unit-surjective
  module Group = Deloopings.Group G

  module Proof (distribute : FlatTruncationDistribution {ℓ = ℓ})
      (preserve : CrispPullbackPreservation) (real-flat : RealFlatAxiom)
      (discrete-group : CrisplyDiscrete (Loop G)) where
    module WeilConnected = CW.Context.Proof R kock distribute preserve

    loop-crystalline : Infinitesimal.IsCrystalline (Loop G)
    loop-crystalline = Infinitesimal.shape-modal→crystalline
      (λ _ → fromIsEquiv const (equivFun (real-flat (Loop G)) discrete-group))

    delooping-crystalline : Infinitesimal.IsCrystalline (BG G)
    delooping-crystalline = Group.Preserved.delooping-modal
      (crisp-fibre-preservation preserve (Unit* {ℓ = ℓ}) (BG G)
        Group.point-map (point G)) loop-crystalline

    module Action (A : BG G → Type ℓ) where
      module Quotient = QM.Theory.Action Infinitesimal.CrystallineModality G A
        delooping-crystalline
      module Checked = Quotient.ForTests
        (λ d → WeilTests.WeilRealPushout.test-square (underlying-diagram d))
        WeilConnected.WeilModal.connected-tests

      open Quotient using (quotient-etale) public
      open Checked using (quotient-microlinear) public

  -- The finite-group case needs no extra real-flat or constancy input:
  -- decidable loop equality already implies crystalline nullity.
  module FiniteProof (distribute : FlatTruncationDistribution {ℓ = ℓ})
      (preserve : CrispPullbackPreservation) (finite-group : isFinSet (Loop G)) where
    module WeilConnected = CW.Context.Proof R kock distribute preserve

    loop-crystalline : Infinitesimal.IsCrystalline (Loop G)
    loop-crystalline = DD.Ring.Set.decidable-crystalline R (isFinSet→Discrete finite-group)

    delooping-crystalline : Infinitesimal.IsCrystalline (BG G)
    delooping-crystalline = Group.Preserved.delooping-modal
      (crisp-fibre-preservation preserve (Unit* {ℓ = ℓ}) (BG G)
        Group.point-map (point G)) loop-crystalline

    module Action (A : BG G → Type ℓ) where
      module Quot = Q.FamilyAction G A
      module Quotient = QM.Theory.Action Infinitesimal.CrystallineModality G A
        delooping-crystalline
      module Checked = Quotient.ForTests
        (λ d → WeilTests.WeilRealPushout.test-square (underlying-diagram d))
        WeilConnected.WeilModal.connected-tests
      module Orb = O.Geometry
        (λ d → WeilTests.WeilRealPushout.test-square (underlying-diagram d))

      -- Theorem 6.4.1, with the complete geometric and finite-identity
      -- conclusions both derived for the actual homotopy quotient.
      finite-group-quotient-orbifold : isSet Quot.Fibre → Microlinear Quot.Fibre
        → Orb.Orbifold Quot.Quotient
      Orb.Orbifold.microlinear (finite-group-quotient-orbifold setFibre ml) =
        Checked.quotient-microlinear ml
      Orb.Orbifold.finite-identifications (finite-group-quotient-orbifold setFibre ml) =
        O.QuotientFiniteness.finiteGroupQuotientLocallyProperlyFinite G A finite-group setFibre
