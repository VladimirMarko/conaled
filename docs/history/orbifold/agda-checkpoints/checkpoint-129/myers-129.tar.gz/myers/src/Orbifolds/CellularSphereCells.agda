{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularSphereCells where

-- Indexed cells of arbitrary finite dimension, with arbitrary higher
-- coefficient types. Their boundaries are actual spheres (empty in
-- dimension zero), and the resulting presentation has no dimension or
-- number-of-stages bound. Fixed-index power comparisons require the
-- actual crisply discrete index hypothesis; it is never implicit.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.Data.Empty as Empty
open import Cubical.HITs.Sn.Base using (S₊)
import Cubical.HITs.Pushout as PO
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as PP
import Orbifolds.TinyTypes as TT
import Orbifolds.TinySpheres as TS
import Orbifolds.TinyDiscreteIndices as TI
import Orbifolds.GraphColimits as GC
import Orbifolds.CellularPresentations as CP

BoundarySphere : {ℓ : Level} → ℕ → Type ℓ
BoundarySphere {ℓ} zero = Lift {j = ℓ} Empty.⊥
BoundarySphere {ℓ} (suc n) = Lift {j = ℓ} (S₊ n)

module Cells {ℓ : Level} (Index : Type ℓ) (dimension : Index → ℕ)
    (Coefficient : Index → Type ℓ) where
  Boundary : Type ℓ
  Boundary = Σ[ c ∈ Index ] (BoundarySphere {ℓ} (dimension c) × Coefficient c)

  Interior : Type ℓ
  Interior = Σ Index Coefficient

  boundary : Boundary → Interior
  boundary (c , s , x) = c , x

record SpherePresentation {ℓ : Level} (A : Type ℓ) : Type (ℓ-suc ℓ) where
  coinductive
  field
    Index : Type ℓ
    dimension : Index → ℕ
    Coefficient : Index → Type ℓ
    attaching : Cells.Boundary Index dimension Coefficient → A
    next : SpherePresentation
      (PO.Pushout attaching (Cells.boundary Index dimension Coefficient))

to-presentation : {ℓ : Level} {A : Type ℓ} → SpherePresentation A → CP.Presentation A
CP.Presentation.Boundary (to-presentation P) = Cells.Boundary
  (SpherePresentation.Index P) (SpherePresentation.dimension P) (SpherePresentation.Coefficient P)
CP.Presentation.Cells (to-presentation P) = Cells.Interior
  (SpherePresentation.Index P) (SpherePresentation.dimension P) (SpherePresentation.Coefficient P)
CP.Presentation.attach (to-presentation P) = SpherePresentation.attaching P
CP.Presentation.boundary (to-presentation P) = Cells.boundary
  (SpherePresentation.Index P) (SpherePresentation.dimension P) (SpherePresentation.Coefficient P)
CP.Presentation.next (to-presentation P) = to-presentation (SpherePresentation.next P)

module Exponentiation {ℓ : Level} (T : Type ℓ)
    (Index : Type ℓ) (dimension : Index → ℕ) (Coefficient : Index → Type ℓ) where
  module Original = Cells Index dimension Coefficient
  module Powered = Cells Index dimension (λ c → T → Coefficient c)

  cell-comparison : Powered.Interior → (T → Original.Interior)
  cell-comparison (c , v) t = c , v t

  boundary-comparison : Powered.Boundary → (T → Original.Boundary)
  boundary-comparison (c , s , v) t = c , s , v t

  boundary-square : (u : Powered.Boundary)
    → Original.boundary ∘ boundary-comparison u
      ≡ cell-comparison (Powered.boundary u)
  boundary-square u = refl

  module NullIndices
      (null-index : isEquiv (const :> (Index → (T → Index))))
      (null-spheres : (c : Index)
        → isEquiv (const :> (BoundarySphere {ℓ} (dimension c)
          → (T → BoundarySphere {ℓ} (dimension c))))) where
    cells-preserved : isEquiv cell-comparison
    cells-preserved = GC.Coproduct.preserves T Index Coefficient null-index

    boundary-fiber : (c : Index)
      → (BoundarySphere {ℓ} (dimension c) × (T → Coefficient c))
        ≃ (T → (BoundarySphere {ℓ} (dimension c) × Coefficient c))
    boundary-fiber c = GC.Coproduct.comparison T (BoundarySphere {ℓ} (dimension c))
        (λ _ → Coefficient c) ,
      GC.Coproduct.preserves T (BoundarySphere {ℓ} (dimension c))
        (λ _ → Coefficient c) (null-spheres c)

    boundaries-preserved : isEquiv boundary-comparison
    boundaries-preserved = compEquiv
      (Σ-cong-equiv-snd boundary-fiber)
      (GC.Coproduct.comparison T Index
          (λ c → BoundarySphere {ℓ} (dimension c) × Coefficient c) ,
        GC.Coproduct.preserves T Index
          (λ c → BoundarySphere {ℓ} (dimension c) × Coefficient c) null-index) .snd

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ) where
  module Propositions = PP.Context R r₀
  module Spheres = TS.Context identity-rules identity-zero flat-zero flat-zero-computation T
  open Propositions using (RealFlat) public

  sphere-null : TT.External.Tiny T → (n : ℕ)
    → isEquiv (const :> (BoundarySphere {ℓ} n → (T → BoundarySphere {ℓ} n)))
  sphere-null tiny zero = Spheres.empty-null tiny
  sphere-null tiny (suc n) = Spheres.spheres-null tiny n

  module Indexed (@♭ Index : Type ℓ) (dimension : Index → ℕ)
      (Coefficient : Index → Type ℓ) where
    module Power = Exponentiation T Index dimension Coefficient

    cells-preserved : RealFlat → CrisplyDiscrete Index → TT.External.Tiny T
      → isEquiv Power.cell-comparison
    cells-preserved real-flat discrete tiny = Power.NullIndices.cells-preserved
      (TI.Context.Index.null-index identity-rules flat-induction flat-computation
        R r₀ T Index real-flat discrete tiny)
      (λ c → sphere-null tiny (dimension c))

    boundaries-preserved : RealFlat → CrisplyDiscrete Index → TT.External.Tiny T
      → isEquiv Power.boundary-comparison
    boundaries-preserved real-flat discrete tiny = Power.NullIndices.boundaries-preserved
      (TI.Context.Index.null-index identity-rules flat-induction flat-computation
        R r₀ T Index real-flat discrete tiny)
      (λ c → sphere-null tiny (dimension c))
