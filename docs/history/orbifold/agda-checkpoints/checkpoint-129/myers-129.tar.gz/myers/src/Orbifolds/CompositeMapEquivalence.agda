{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.CompositeMapEquivalence where

-- Keep the elementary equivalence certificate at fixed source, middle,
-- and target types. Concrete clients retain their actual comparison map
-- and only supply a proved homotopy to the composite of two equivalences.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv

abstract
  homotopic-composite-isEquiv : ∀ {ℓa ℓb ℓc}
    {A : Type ℓa} {B : Type ℓb} {C : Type ℓc}
    (f : A → B) (g : B → C)
    → isEquiv f → isEquiv g
    → (k : A → C) → ((x : A) → k x ≡ g (f x))
    → isEquiv k
  homotopic-composite-isEquiv {A = A} {C = C} f g f-equiv g-equiv k square =
    subst (λ (h : A → C) → isEquiv {A = A} {B = C} h)
      (sym (funExt square)) (((f , f-equiv) ∙ₑ (g , g-equiv)) .snd)
