{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellInterface where

-- A small declaration interface to the already proved literal cell map.
-- Qualified calls retain its exact computations without copying the
-- whole proof namespace into each large HCD instantiation.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments
import Orbifolds.Coherent.NaturalQuotedCellMap as Maps
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Map {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A B Index : Type ℓ) (SourceCoefficient TargetCoefficient : Index → Type ℓ)
    (source-boundary : (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → A))
    (target-boundary : (c : Index) → CS.Shell (toNat n) (TargetCoefficient c → B))
    (base-map : A → B) (coefficient-map : (c : Index) → SourceCoefficient c → TargetCoefficient c)
    (boundary-path : (c : Index)
      → Shells.Action.map-shell E n (λ v → base-map ∘ v) (source-boundary c)
        ≡ Shells.Action.map-shell E n (λ v → v ∘ coefficient-map c) (target-boundary c)) where
  module Source = Attachments.Attachment E n A Index SourceCoefficient source-boundary
  module Target = Attachments.Attachment E n B Index TargetCoefficient target-boundary

  cell-map : Source.Cell → Target.Cell
  cell-map (c , x) = c , coefficient-map c x

  boundary-map : Source.Boundary → Target.Boundary
  boundary-map (cx , s) = cell-map cx , s

  attachment-square : base-map ∘ Source.attach ≡ Target.attach ∘ boundary-map
  attachment-square = Maps.Map.attachment-square E n A B Index SourceCoefficient TargetCoefficient
    source-boundary target-boundary base-map coefficient-map boundary-path

  boundary-square : cell-map ∘ Source.boundary ≡ Target.boundary ∘ boundary-map
  boundary-square = refl

  induced : Source.Realize → Target.Realize
  induced = Maps.Map.induced E n A B Index SourceCoefficient TargetCoefficient
    source-boundary target-boundary base-map coefficient-map boundary-path

  include-computation : (a : A) → induced (Source.include a) ≡ Target.include (base-map a)
  include-computation a = refl

  module TargetSpace (Y : Type ℓ) where
    mapped-boundary-path : (h : B → Y) (c : Index)
      → Source.mapped-boundary Y (h ∘ base-map) c
        ≡ Shells.Action.map-shell E n (λ v → v ∘ coefficient-map c)
            (Target.mapped-boundary Y h c)
    mapped-boundary-path = Maps.Map.TargetSpace.mapped-boundary-path E n A B Index
      SourceCoefficient TargetCoefficient source-boundary target-boundary base-map coefficient-map boundary-path Y

    mapped-boundary-value : (h : B → Y) (c : Index) (i : I)
      → outer (mapped-boundary-path h c i)
        ≡ˢ outer (Shells.Action.map-shell E n (λ v → h ∘ v) (boundary-path c i))
    mapped-boundary-value = Maps.Map.TargetSpace.mapped-boundary-value E n A B Index
      SourceCoefficient TargetCoefficient source-boundary target-boundary base-map coefficient-map boundary-path Y

    pullback : Target.Cocone Y → Source.Cocone Y
    pullback (h , fs) = (h ∘ base-map) , λ c → subst
      (CF.Filler (toNat n) {X = SourceCoefficient c → Y})
      (sym (mapped-boundary-path h c))
      (Fillers.Action.map-filler E n
        {X = TargetCoefficient c → Y} {Y = SourceCoefficient c → Y}
        (λ v → v ∘ coefficient-map c) (Target.mapped-boundary Y h c) (fs c))

    pullback-computation : (s : Target.Cocone Y)
      → outer (pullback s)
        ≡ˢ outer (Maps.Map.TargetSpace.pullback E n A B Index
          SourceCoefficient TargetCoefficient source-boundary target-boundary base-map coefficient-map boundary-path Y s)
    pullback-computation (h , fs) = reflˢ

    restrict-natural : (k : Target.Realize → Y)
      → Source.Target.restrict Y (k ∘ induced) ≡ pullback (Target.Target.restrict Y k)
    restrict-natural = Maps.Map.TargetSpace.restrict-natural E n A B Index
      SourceCoefficient TargetCoefficient source-boundary target-boundary base-map coefficient-map boundary-path Y

  canonical-naturality : Source.Target.restrict Target.Realize induced
    ≡ TargetSpace.pullback Target.Realize Target.canonical-cocone
  canonical-naturality = Maps.Map.canonical-naturality E n A B Index
    SourceCoefficient TargetCoefficient source-boundary target-boundary base-map coefficient-map boundary-path
