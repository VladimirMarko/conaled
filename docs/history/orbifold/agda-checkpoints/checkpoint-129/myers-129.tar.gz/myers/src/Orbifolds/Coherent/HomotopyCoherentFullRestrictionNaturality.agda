{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFullRestrictionNaturality where

-- Target naturality of actual full cocone restriction. Finite strict
-- equalities are packaged with their full inner commuting squares in
-- a coinductive witness, then consumed by ordinary-natural recursion.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.GroupoidLaws using (lUnit)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictHomotopySquares
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentMappingContravariance as Coefficients
import Orbifolds.Coherent.HomotopyCoherentConeMaps as ConeMaps
import Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionNaturality as FiniteNaturality
import Orbifolds.CoinductiveTowerSquares as Generic

module Naturality {ℓ : Level} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    {Y Z : Type ℓ} (k : Y → Z) where
  module DM = Mapping.Mapping C D E F
  module GM = Mapping.Mapping C G E F
  module Coeff = Coefficients.Contravariance C D G α E F
  module RY = ConeMaps.Action (Opposite C) (GM.Into Y) (DM.Into Y) (Coeff.Precompose Y) E
  module RZ = ConeMaps.Action (Opposite C) (GM.Into Z) (DM.Into Z) (Coeff.Precompose Z) E
  module PG = ConeMaps.Action (Opposite C) (GM.Into Y) (GM.Into Z) (GM.Postcompose k) E
  module PD = ConeMaps.Action (Opposite C) (DM.Into Y) (DM.Into Z) (DM.Postcompose k) E
  module Finite = FiniteNaturality.Naturality C D G α E F

  record State : Type (ℓ-suc ℓ) where
    field
      A₀ A₁ A₂ A₃ : Type ℓ
      S₀ : RY.Source.Schedule A₀
      S₁ : RY.Target.Schedule A₁
      S₂ : PG.Target.Schedule A₂
      S₃ : PD.Target.Schedule A₃
      f : A₀ → A₁
      g : A₁ → A₃
      h : A₀ → A₂
      l : A₂ → A₃
      mf : RY.Morphism S₀ S₁ f
      mg : PD.Morphism S₁ S₃ g
      mh : PG.Morphism S₀ S₂ h
      ml : RZ.Morphism S₂ S₃ l

  advance : State → State
  State.A₀ (advance s) = RY.Source.Schedule.Next (State.S₀ s)
  State.A₁ (advance s) = RY.Target.Schedule.Next (State.S₁ s)
  State.A₂ (advance s) = PG.Target.Schedule.Next (State.S₂ s)
  State.A₃ (advance s) = PD.Target.Schedule.Next (State.S₃ s)
  State.S₀ (advance s) = RY.Source.Schedule.tail (State.S₀ s)
  State.S₁ (advance s) = RY.Target.Schedule.tail (State.S₁ s)
  State.S₂ (advance s) = PG.Target.Schedule.tail (State.S₂ s)
  State.S₃ (advance s) = PD.Target.Schedule.tail (State.S₃ s)
  State.f (advance s) x = State.f s (x .fst) , RY.Morphism.fiber-map (State.mf s) (x .fst) (x .snd)
  State.g (advance s) x = State.g s (x .fst) , PD.Morphism.fiber-map (State.mg s) (x .fst) (x .snd)
  State.h (advance s) x = State.h s (x .fst) , PG.Morphism.fiber-map (State.mh s) (x .fst) (x .snd)
  State.l (advance s) x = State.l s (x .fst) , RZ.Morphism.fiber-map (State.ml s) (x .fst) (x .snd)
  State.mf (advance s) = RY.Morphism.tail (State.mf s)
  State.mg (advance s) = PD.Morphism.tail (State.mg s)
  State.mh (advance s) = PG.Morphism.tail (State.mh s)
  State.ml (advance s) = RZ.Morphism.tail (State.ml s)

  left right : (s : State) → State.A₀ s → State.A₃ s
  left s = State.g s ∘ State.f s
  right s = State.l s ∘ State.h s

  module Squares = Generic.Squares State State.A₀ State.A₃ advance
    (λ s → fst) (λ s → fst) left right (λ s → refl) (λ s → refl)
  open Squares using (Witness)

  finite-state : Dim → State
  State.A₀ (finite-state n) = RY.SourceFinite.Carrier n
  State.A₁ (finite-state n) = RY.TargetFinite.Carrier n
  State.A₂ (finite-state n) = PG.TargetFinite.Carrier n
  State.A₃ (finite-state n) = PD.TargetFinite.Carrier n
  State.S₀ (finite-state n) = RY.SourceFinite.finite-state n .snd
  State.S₁ (finite-state n) = RY.TargetFinite.finite-state n .snd
  State.S₂ (finite-state n) = PG.TargetFinite.finite-state n .snd
  State.S₃ (finite-state n) = PD.TargetFinite.finite-state n .snd
  State.f (finite-state n) = RY.FiniteAction.stage-map n
  State.g (finite-state n) = PD.FiniteAction.stage-map n
  State.h (finite-state n) = PG.FiniteAction.stage-map n
  State.l (finite-state n) = RZ.FiniteAction.stage-map n
  State.mf (finite-state n) = RY.finite-morphism n
  State.mg (finite-state n) = PD.finite-morphism n
  State.mh (finite-state n) = PG.finite-morphism n
  State.ml (finite-state n) = RZ.finite-morphism n

  actual-state : ℕ → State
  State.A₀ (actual-state n) = RY.Source.PartialCone n
  State.A₁ (actual-state n) = RY.Target.PartialCone n
  State.A₂ (actual-state n) = PG.Target.PartialCone n
  State.A₃ (actual-state n) = PD.Target.PartialCone n
  State.S₀ (actual-state n) = RY.Source.stage-schedule n
  State.S₁ (actual-state n) = RY.Target.stage-schedule n
  State.S₂ (actual-state n) = PG.Target.stage-schedule n
  State.S₃ (actual-state n) = PD.Target.stage-schedule n
  State.f (actual-state n) = RY.partial-map n
  State.g (actual-state n) = PD.partial-map n
  State.h (actual-state n) = PG.partial-map n
  State.l (actual-state n) = RZ.partial-map n
  State.mf (actual-state n) = RY.morphism-at n
  State.mg (actual-state n) = PD.morphism-at n
  State.mh (actual-state n) = PG.morphism-at n
  State.ml (actual-state n) = RZ.morphism-at n

  abstract
    finite-witness : (n : Dim) → Witness (finite-state n)
      (strict-to-path (Finite.function-square n k))
    Witness.next (finite-witness n) = strict-to-path (Finite.function-square (osuc n) k)
    Witness.square (finite-witness n) = strict-square fst fst
      (Finite.function-square n k) (Finite.function-square (osuc n) k) reflˢ reflˢ
    Witness.tail (finite-witness n) = finite-witness (osuc n)

  mutual
    partial-naturality : (n : ℕ)
      → (PD.partial-map n ∘ RY.partial-map n) ≡ (RZ.partial-map n ∘ PG.partial-map n)
    partial-naturality zero = strict-to-path (Finite.function-square ozero k)
    partial-naturality (suc n) = Witness.next (witness-at n)

    witness-at : (n : ℕ) → Witness (actual-state n) (partial-naturality n)
    witness-at zero = finite-witness ozero
    witness-at (suc n) = Witness.tail (witness-at n)

  coherence : (s : RY.Source.Limit) (n : ℕ)
    → PathP (λ i → PD.Target.drop n (partial-naturality (suc n) i (s .fst (suc n)))
        ≡ partial-naturality n i (s .fst n))
      (cong (PD.partial-map n ∘ RY.partial-map n) (s .snd n))
      (cong (RZ.partial-map n ∘ PG.partial-map n) (s .snd n))
  coherence s n = adjust-path
    (lUnit (cong (PD.partial-map n ∘ RY.partial-map n) (s .snd n)))
    (λ i → (λ j → Witness.square (witness-at n) i j (s .fst (suc n)))
      ∙ cong (partial-naturality n i) (s .snd n))
    (sym (lUnit (cong (RZ.partial-map n ∘ PG.partial-map n) (s .snd n))))

  full-square : (s : RY.Source.Limit)
    → PD.cone-map (RY.cone-map s) ≡ RZ.cone-map (PG.cone-map s)
  full-square s i .fst n = partial-naturality n i (s .fst n)
  full-square s i .snd n = coherence s n i
