{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderFullFaithfulness where

-- Lemma 4.2.14: the first-order patch functor is fully faithful. All
-- infinitesimal-variety witnesses come from actual finite Weil algebras.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Categories.Category.Base
open import Cubical.Categories.Functor.Base
import Orbifolds.WeilAlgebras as WA
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.FirstOrderKockLawvere as KL
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.SquareZeroWeil as SW

module Ring {ℓ : Level} (R : CommRing ℓ) (kock-lawvere : WA.Weil.KockLawvere R) where
  open CommRingStr (R .snd) using (is-set)
  module W = WA.Weil R
  module Linear = LM.Ring R
  module Disks = IL.Ring R
  module Coordinates = KL.Ring R kock-lawvere
  open Linear using (Mat; MatrixCategory; disk-functor; disk-isSet)
  open Functor disk-functor using (F-ob; F-hom)

  PointedMaps : ℕ → ℕ → Type ℓ
  PointedMaps n m = LM.PointedSets ℓ [ F-ob n , F-ob m ]

  coordinate : {n m : ℕ} → PointedMaps n m → FD.Fin m → Coordinates.Dimension.PointedFunctions n
  coordinate f i = (λ d → f .fst d .fst i) , cong (λ x → x .fst i) (f .snd)

  coefficients : {n m : ℕ} → PointedMaps n m → Mat n m
  coefficients {n} f i = Coordinates.Dimension.coefficients n (coordinate f i)

  matrix-coordinates : {n m : ℕ} (a : Mat n m) (i : FD.Fin m)
    → coordinate (F-hom a) i ≡ Coordinates.Dimension.linear-pointed n (a i)
  matrix-coordinates a i = Σ≡Prop (λ _ → is-set _ _) refl

  coefficients-matrix : {n m : ℕ} (a : Mat n m) → coefficients (F-hom a) ≡ a
  coefficients-matrix {n} a = funExt λ i →
    cong (Coordinates.Dimension.coefficients n) (matrix-coordinates a i)
    ∙ Coordinates.Dimension.coefficients-linear n (a i)

  reconstruct : {n m : ℕ} (f : PointedMaps n m) → F-hom (coefficients f) ≡ f
  reconstruct {n} {m} f = Σ≡Prop (λ _ → disk-isSet m _ _) (funExt λ d →
    Σ≡Prop Disks.pairwise-zero-isProp (funExt λ i →
      cong (λ h → h .fst d) (Coordinates.Dimension.linear-reconstruction n (coordinate f i))))

  pointed-map-equivalence : (n m : ℕ) → Mat n m ≃ PointedMaps n m
  pointed-map-equivalence n m = isoToEquiv (iso F-hom coefficients reconstruct coefficients-matrix)

  disk-fully-faithful : Functor.isFullyFaithful disk-functor
  disk-fully-faithful n m = pointed-map-equivalence n m .snd

  -- The full subcategory of pointed sets spanned by actual infinitesimal
  -- varieties. A witness is a mere pointed equivalence with a Weil spectrum.
  InfinitesimalVarieties : Category (ℓ-suc ℓ) ℓ
  Category.ob InfinitesimalVarieties = Σ[ A ∈ Category.ob (LM.PointedSets ℓ) ]
    W.InfinitesimalVariety (A .fst .fst) (A .snd)
  Category.Hom[_,_] InfinitesimalVarieties A B = LM.PointedSets ℓ [ A .fst , B .fst ]
  Category.id InfinitesimalVarieties {x = A} = Category.id (LM.PointedSets ℓ) {x = A .fst}
  Category._⋆_ InfinitesimalVarieties {x = A} {y = B} {z = C} =
    Category._⋆_ (LM.PointedSets ℓ) {x = A .fst} {y = B .fst} {z = C .fst}
  Category.⋆IdL InfinitesimalVarieties {x = A} {y = B} =
    Category.⋆IdL (LM.PointedSets ℓ) {x = A .fst} {y = B .fst}
  Category.⋆IdR InfinitesimalVarieties {x = A} {y = B} =
    Category.⋆IdR (LM.PointedSets ℓ) {x = A .fst} {y = B .fst}
  Category.⋆Assoc InfinitesimalVarieties {x = A} {y = B} {z = C} {w = D} =
    Category.⋆Assoc (LM.PointedSets ℓ) {x = A .fst} {y = B .fst} {z = C .fst} {w = D .fst}
  Category.isSetHom InfinitesimalVarieties {x = A} {y = B} =
    Category.isSetHom (LM.PointedSets ℓ) {x = A .fst} {y = B .fst}

  infinitesimal-functor : Functor MatrixCategory InfinitesimalVarieties
  Functor.F-ob infinitesimal-functor n = F-ob n , SW.Coordinates.disk-is-infinitesimal R n
  Functor.F-hom infinitesimal-functor = F-hom
  Functor.F-id infinitesimal-functor = Functor.F-id disk-functor
  Functor.F-seq infinitesimal-functor = Functor.F-seq disk-functor

  infinitesimal-fully-faithful : Functor.isFullyFaithful infinitesimal-functor
  infinitesimal-fully-faithful = disk-fully-faithful
