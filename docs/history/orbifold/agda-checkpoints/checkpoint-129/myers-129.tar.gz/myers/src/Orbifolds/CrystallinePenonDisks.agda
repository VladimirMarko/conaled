{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrystallinePenonDisks where

-- Penon disks are the actual fibers of crystalline reflection on a
-- Penon manifold. The proof uses the constructive separated quotient
-- from CrystallineSeparation, not sharp or a crisp chart selection.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Univalence using (pathToEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Modalities.Modality using (Modality)
open import Cubical.Algebra.CommRing.Base using (CommRing)
import Cubical.Foundations.Equiv.Fiberwise as FW
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.ModalEtaleClosure as EC
import Orbifolds.CrystallineZeroLoci as CZ
import Orbifolds.CrystallineSeparation as CS
import Orbifolds.PenonManifolds as PM
open import Orbifolds.Penon
open import Orbifolds.StableNeighborhoods using (center)

-- General fact for any modality: a connected pointed etale domain is
-- the unit fiber at the image of its point. The equivalence is over X.
module ConnectedEtale {ℓ : Level} (M : Modality ℓ)
    {D X : Type ℓ} (j : D → X)
    (etale : EC.Theory.Etale M j)
    (connected : EC.Theory.Connected M D) (d₀ : D) where
  open EC.Theory M

  centered : isContr (◯ D)
  centered = η d₀ , isContr→isProp connected (η d₀)

  comparison-on-fibers : (x : X)
    → fiber (◯-map j) (η x) ≃ (η x ≡ η (j d₀))
  comparison-on-fibers x = compEquiv (Σ-contractFst centered)
    (compEquiv
      (pathToEquiv (cong (λ z → z ≡ η x) (◯-map-β j d₀)))
      (isoToEquiv (iso sym sym (λ _ → refl) (λ _ → refl))))

  unit-fiber-equivalence : D ≃ fiber η (η (j d₀))
  unit-fiber-equivalence = compEquiv (unit-gap j , etale)
    (Σ-cong-equiv-snd comparison-on-fibers)

  unit-fiber-over : (d : D) → equivFun unit-fiber-equivalence d .fst ≡ j d
  unit-fiber-over d = refl

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CZ.Ring R
  open PM.Geometry R using (PenonManifold)

  module Manifold {X : Type ℓ} {n : ℕ} (manifold : PenonManifold X n) where
    open PenonManifold manifold
    module Separate = CS.Ring.For R X

    neighborhood-connected : (x : X) → Crystal.Connected (InfinitesimalNeighborhood x)
    neighborhood-connected x = PT.rec isPropIsContr
      (λ model → Connected.connected-equiv (invEquiv (model .fst)) (power-connected n))
      (local-model x)

    module At (x : X) where
      module Identification = ConnectedEtale CrystallineModality
        (fst {B = λ y → Neighbors y x})
        (Separate.neighborhood-inclusion-etale x)
        (neighborhood-connected x) (center x)

      neighborhood≃unit-fiber : InfinitesimalNeighborhood x
        ≃ fiber crystalline-unit (crystalline-unit x)
      neighborhood≃unit-fiber = Identification.unit-fiber-equivalence

      neighborhood-over : (d : InfinitesimalNeighborhood x)
        → equivFun neighborhood≃unit-fiber d .fst ≡ d .fst
      neighborhood-over d = refl

      neighbor→unit-path : (y : X) → Neighbors y x
        → crystalline-unit y ≡ crystalline-unit x
      neighbor→unit-path y near = equivFun neighborhood≃unit-fiber (y , near) .snd

      -- The total equivalence keeps the base point judgmentally, so its
      -- individual fiber maps are equivalences, not merely implications.
      neighbor≃unit-path : (y : X)
        → Neighbors y x ≃ (crystalline-unit y ≡ crystalline-unit x)
      neighbor≃unit-path y = neighbor→unit-path y , FW.fiberEquiv
        (λ y → Neighbors y x) (λ y → crystalline-unit y ≡ crystalline-unit x)
        neighbor→unit-path (snd neighborhood≃unit-fiber) y

      unit-path-proposition : (y : X)
        → isProp (crystalline-unit y ≡ crystalline-unit x)
      unit-path-proposition y = isOfHLevelRespectEquiv 1 (neighbor≃unit-path y)
        isPropNeighbors

      neighborhood-pointed : equivFun neighborhood≃unit-fiber (center x) ≡ (x , refl)
      neighborhood-pointed = Σ≡Prop unit-path-proposition refl

    -- Units are merely surjective for this actual pointed nullification.
    -- Eliminating the two truncations into propositionhood extends the
    -- local path result to all points of the reflected type.
    reflection-isSet : isSet (Im X)
    reflection-isSet u v = PT.rec isPropIsProp
      (λ (x , p) → PT.rec isPropIsProp
        (λ (y , q) → subst2 (λ a b → isProp (a ≡ b)) p q
          (At.unit-path-proposition y x))
        (crystalline-unit-surjective v))
      (crystalline-unit-surjective u)
