{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictReturnedCompositeNormalization where

-- Normalize the actual returned first path using its own checked endpoint.
-- Every strict witness is a supplied proof; no reflection or postulate is
-- used in this neutral path calculation.
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
open import Orbifolds.Coherent.StrictRetaggedPathIndependence
  using (retagged-strict-path-independent)

normalize-returned : ∀ {ℓ} {B : Type ℓ} {x y z : B}
  (b : outer x ≡ˢ outer y) (e : outer y ≡ˢ outer z)
  (p : x ≡ z)
  (shape : outer p ≡ˢ outer (strict-end-path {A = B} {x = x} {y = z}
    (λ i → strict-to-path b i) reflˢ e))
  → p ≡ strict-to-path (strict-trans b e)
normalize-returned b e p shape =
  strict-to-path shape
  ∙ retagged-strict-path-independent b e (strict-trans b e)

normalize-composite : ∀ {ℓ} {B : Type ℓ} {x y w v z : B}
  (b : outer x ≡ˢ outer y) (e : outer y ≡ˢ outer w)
  (first : x ≡ w)
  (shape : outer first ≡ˢ outer (strict-end-path {A = B} {x = x} {y = w}
    (λ i → strict-to-path b i) reflˢ e))
  (middle public-middle : w ≡ v) (last : v ≡ z)
  (r : x ≡ z)
  (law : r ≡ first ∙ (middle ∙ last))
  (lower-equality : outer public-middle ≡ˢ outer middle)
  → r ≡ strict-to-path (strict-trans b e) ∙ (public-middle ∙ last)
normalize-composite b e first shape middle public-middle last r law lower-equality =
  law ∙ cong₂ _∙_ (normalize-returned b e first shape)
    (cong (λ m → m ∙ last) (sym (strict-to-path lower-equality)))

-- Transport a projected-path law along a strict equality of path values.
-- This operation leaves the returned path unchanged.
replace-projected-path : ∀ {ℓ} {A B : Type ℓ} (project : A → B)
  {x z : A} (public-path raw-path : x ≡ z)
  (same : outer public-path ≡ˢ outer raw-path)
  (returned : project x ≡ project z)
  (law : cong project raw-path ≡ returned)
  → cong project public-path ≡ returned
replace-projected-path project public-path raw-path same returned law =
  cong (λ p → cong project p) (strict-to-path same) ∙ law
