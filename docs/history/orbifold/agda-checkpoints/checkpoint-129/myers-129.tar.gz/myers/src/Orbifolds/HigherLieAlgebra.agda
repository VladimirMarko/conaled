{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.HigherLieAlgebra where

-- Corollary 5.5.5 assembled from global Weil tininess, delooping
-- infinitesimal linearity, the actual tangent delooping, and the
-- product-preserving representable R-module model of Theorem 4.2.19.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Pointed
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as CP
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.FirstOrderTangentDelooping as TD
import Orbifolds.TinyFirstOrderDisks as W
import Orbifolds.HigherTangentModules as HM
import Orbifolds.Quotients as Q

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CI.CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero) where
  module Disks = IL.Ring R
  module Global = W.Context R rules
  module Consequences = Global.Consequences identity-zero flat-zero flat-zero-computation
  module Tangents = TD.Context R rules identity-zero flat-zero flat-zero-computation
  module Modules = HM.Ring R
  module Propositions = CP.Context (R .fst) (CommRingStr.0r (R .snd))
  open Global using (WeilTinyness) public
  open Propositions using (RealFlat) public

  module Group (@♭ G : Q.Delooping ℓ) where
    module Concrete = Tangents.HigherGroup G
    open Concrete using (LieAlgebra; lie-algebra-point) public

    tangent-delooping : RealFlat → WeilTinyness → Q.Delooping ℓ
    tangent-delooping real-flat tiny = Consequences.tangent-delooping real-flat tiny G

    lie-algebra-loops : (real-flat : RealFlat) (tiny : WeilTinyness)
      → Q.Loop (tangent-delooping real-flat tiny) ≃ LieAlgebra
    lie-algebra-loops real-flat tiny = Consequences.lie-algebra-loops real-flat tiny G

    lie-algebra-loops-pointed : (real-flat : RealFlat) (tiny : WeilTinyness)
      → (Q.Loop (tangent-delooping real-flat tiny) , refl)
        ≃∙ (LieAlgebra , lie-algebra-point)
    lie-algebra-loops-pointed real-flat tiny =
      Concrete.lie-algebra-loops-pointed real-flat (Global.disks-tiny tiny)

    module-presentation : RealFlat → WeilTinyness
      → Disks.InfinitesimallyLinear (Q.Loop G) → Modules.RepresentableModule
    module-presentation real-flat tiny linear =
      Modules.tangent-module (Q.BG G) (Q.point G)
        (Consequences.preserves-infinitesimal-linearity real-flat tiny G linear)

    module-carrier≃delooping : (real-flat : RealFlat) (tiny : WeilTinyness)
      (linear : Disks.InfinitesimallyLinear (Q.Loop G))
      → Modules.underlying (module-presentation real-flat tiny linear)
        ≃ Q.BG (tangent-delooping real-flat tiny)
    module-carrier≃delooping real-flat tiny linear =
      Modules.Model.rank-one (Q.BG G , Q.point G)

    pointed-module-carrier≃delooping : (real-flat : RealFlat) (tiny : WeilTinyness)
      (linear : Disks.InfinitesimallyLinear (Q.Loop G))
      → (Modules.underlying (module-presentation real-flat tiny linear) , (const (Q.point G) , refl))
        ≃∙ (Q.BG (tangent-delooping real-flat tiny) , Q.point (tangent-delooping real-flat tiny))
    pointed-module-carrier≃delooping real-flat tiny linear =
      Modules.Model.rank-one-pointed (Q.BG G , Q.point G)
