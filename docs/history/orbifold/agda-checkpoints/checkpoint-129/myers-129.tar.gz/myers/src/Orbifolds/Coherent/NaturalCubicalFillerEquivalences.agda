{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalCubicalFillerEquivalences where

-- The actual direct filler map preserves equivalences. The identity
-- computation follows from literal raw cubes; native univalence then
-- reduces the general equivalence case to that proved identity case.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Univalence using (EquivJ)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
open import Orbifolds.Coherent.StrictCubicalFillerCastCoherence using (cast-filler-isEquiv)
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalShellFunctor as Functor
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Equivalences {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module F = Fillers.Action E
  module S = Shells.Action E
  module Laws = Functor.Functoriality E

  filler-identity : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    (c : CF.Filler (toNat n) b)
    → outer (cast-filler n (Laws.map-identity n b) (F.map-filler n (idfun X) b c))
      ≡ˢ outer c
  filler-identity n {X} b c = F.filler-extensionality n b
    (strict-trans
      (cast-forget n (Laws.map-identity n b) (F.map-filler n (idfun X) b c))
      (strict-trans (F.map-filler-forget n (idfun X) b c)
        (Cubes.Extensional.map-identity E n (CF.forget-filler (toNat n) b c))))

  identity-isEquiv : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → isEquiv (F.map-filler n (idfun X) b)
  identity-isEquiv n {X} b = composesToId→Equiv
    (cast-filler n (Laws.map-identity n b)) (F.map-filler n (idfun X) b)
    (funExt λ c → strict-to-path (filler-identity n b c))
    (cast-filler-isEquiv n (Laws.map-identity n b))

  map-filler-isEquiv : (n : Dim) {X Y : Type ℓ} (e : X ≃ Y)
    (b : CS.Shell (toNat n) X) → isEquiv (F.map-filler n (e .fst) b)
  map-filler-isEquiv n {Y = Y} e = EquivJ
    (λ X e → (b : CS.Shell (toNat n) X) → isEquiv (F.map-filler n (e .fst) b))
    (identity-isEquiv n {X = Y}) e

  map-filler-equivalence : (n : Dim) {X Y : Type ℓ} (e : X ≃ Y)
    (b : CS.Shell (toNat n) X)
    → CF.Filler (toNat n) b ≃ CF.Filler (toNat n) (S.map-shell n (e .fst) b)
  map-filler-equivalence n e b = F.map-filler n (e .fst) b , map-filler-isEquiv n e b

  map-shell-isEquiv : (n : Dim) {X Y : Type ℓ} (e : X ≃ Y)
    → isEquiv (S.map-shell n (e .fst))
  map-shell-isEquiv n {Y = Y} e = EquivJ
    (λ X e → isEquiv (S.map-shell n (e .fst)))
    (subst isEquiv (sym (funExt λ b → strict-to-path (Laws.map-identity n b)))
      (idEquiv (CS.Shell (toNat n) Y) .snd)) e
