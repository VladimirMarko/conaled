{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentConeChains where

-- Mixed chains have one implicit initial cone arrow followed by ordinary
-- C arrows. Splitting retains a cone prefix and a full nonempty arrow
-- suffix; this is the augmented cubical resolution, in every dimension.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken; in-prefix; in-suffix;
  middle-degree; prefix-prefix; prefix-suffix; suffix-prefix; suffix-suffix)
import Orbifolds.Coherent.CoherentArrowSplits as AS

module Splits {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C
  open Chains C
  module Arrow = AC.Arrows C
  module ArrowCast = AS.Splits C

  cast-chain : {m n : Dim} → m ≡ˢ n → {y : Obj} → Chain m y → Chain n y
  cast-chain reflˢ c = c

  Split : (n : Dim) → Position (osuc n) → Obj → Type ℓ
  Split n p y = Σ[ z ∈ Obj ]
    (Arrow.Chain (suffix-degree n p) z y × Chain (prefix-degree n p) z)

  split : (n : Dim) (p : Position (osuc n)) {y : Obj} → Chain (osuc n) y → Split n p y
  split n pzero c = last-source n c , last-arrow n c , prefix n c
  split (osuc n) (psuc p) c =
    split n p (prefix (osuc n) c) .fst ,
    Arrow.append (suffix-degree n p) (last-arrow (osuc n) c)
      (split n p (prefix (osuc n) c) .snd .fst) ,
    split n p (prefix (osuc n) c) .snd .snd

  split-vertex : (n : Dim) (p : Position (osuc n)) {y : Obj} → Chain (osuc n) y → Obj
  split-vertex n p c = split n p c .fst

  split-prefix : (n : Dim) (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
    → Chain (prefix-degree n p) (split-vertex n p c)
  split-prefix n p c = split n p c .snd .snd

  split-suffix : (n : Dim) (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
    → Arrow.Chain (suffix-degree n p) (split-vertex n p c) y
  split-suffix n p c = split n p c .snd .fst

  cut-face-suffix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (split n q (face (osuc n) (weaken p) c))
      ≡ˢ outer
        ( split-vertex (osuc n) (psuc q) c
        , Arrow.face (suffix-degree n q) (in-suffix n p q le)
            (split-suffix (osuc n) (psuc q) c)
        , split-prefix (osuc n) (psuc q) c )
  cut-face-suffix n pzero pzero pzero≤ c = reflˢ
  cut-face-suffix (osuc n) pzero (psuc q) pzero≤ c = reflˢ
  cut-face-suffix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-cong
    (λ z → outer
      ( inner z .fst
      , Arrow.append (suffix-degree n q) (last-arrow (osuc (osuc n)) c) (inner z .snd .fst)
      , inner z .snd .snd ))
    (cut-face-suffix n p q le (prefix (osuc (osuc n)) c))

  NormalSplit : (n : Dim) → Position (osuc n) → Obj → Type ℓ
  NormalSplit n p y = Σ[ z ∈ Obj ]
    (Arrow.Chain (suffix-degree n p) z y × Chain (osuc (prefix-degree n p)) z)

  normalized : (n : Dim) (p : Position (osuc n)) {y : Obj}
    → Chain (osuc (osuc n)) y → NormalSplit n p y
  normalized n p c =
    split-vertex (osuc n) (weaken p) c ,
    ArrowCast.cast-chain (suffix-weaken n p) (split-suffix (osuc n) (weaken p) c) ,
    cast-chain (prefix-weaken n p) (split-prefix (osuc n) (weaken p) c)

  normalized-snoc : (n : Dim) (p : Position (osuc n)) {y : Obj}
    (c : Chain (osuc (osuc (osuc n))) y)
    → outer (normalized (osuc n) (psuc p) c)
      ≡ˢ outer
        ( normalized n p (prefix (osuc (osuc n)) c) .fst
        , Arrow.append (suffix-degree n p) (last-arrow (osuc (osuc n)) c)
            (normalized n p (prefix (osuc (osuc n)) c) .snd .fst)
        , normalized n p (prefix (osuc (osuc n)) c) .snd .snd )
  normalized-snoc n p c = strict-cong
    (λ s → outer (split-vertex (osuc (osuc n)) (psuc (weaken p)) c , inner s ,
      cast-chain (prefix-weaken n p)
        (split-prefix (osuc n) (weaken p) (prefix (osuc (osuc n)) c))))
    (ArrowCast.cast-append (suffix-weaken n p) (last-arrow (osuc (osuc n)) c)
      (split-suffix (osuc n) (weaken p) (prefix (osuc (osuc n)) c)))

  reduce-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {y : Obj} → NormalSplit n p y → Split n p y
  reduce-prefix n p q le z = z .fst , z .snd .fst ,
    face (prefix-degree n p) (in-prefix n p q le) (z .snd .snd)

  cut-face-prefix : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
    {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (split n p (face (osuc n) (psuc q) c))
      ≡ˢ outer (reduce-prefix n p q le (normalized n p c))
  cut-face-prefix n pzero q pzero≤ c = reflˢ
  cut-face-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer
        ( inner z .fst
        , Arrow.append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .fst)
        , inner z .snd .snd ))
      (cut-face-prefix n p q le (prefix (osuc (osuc n)) c)))
    (strict-sym (strict-cong
      (λ z → outer (reduce-prefix (osuc n) (psuc p) (psuc q) (psuc≤ le) (inner z)))
      (normalized-snoc n p c)))

  Triple : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q → Obj → Type ℓ
  Triple n p q le y = Σ[ z ∈ Obj ] Σ[ w ∈ Obj ]
    (Arrow.Chain (suffix-degree n p) z y ×
      (Arrow.Chain (middle-degree n p q le) w z × Chain (prefix-degree n q) w))

  triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    → Chain (osuc (osuc n)) y → Triple n p q le y
  triple n pzero q pzero≤ c =
    last-source (osuc n) c ,
    split-vertex n q (prefix (osuc n) c) ,
    last-arrow (osuc n) c ,
    split-suffix n q (prefix (osuc n) c) ,
    split-prefix n q (prefix (osuc n) c)
  triple (osuc n) (psuc p) (psuc q) (psuc≤ le) c =
    z .fst , z .snd .fst ,
    Arrow.append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (z .snd .snd .fst) ,
    z .snd .snd .snd
    where z = triple n p q le (prefix (osuc (osuc n)) c)

  prefix-triple-of : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    → NormalSplit n p y → Triple n p q le y
  prefix-triple-of n p q le z =
    z .fst , split-vertex (prefix-degree n p) (in-prefix n p q le) (z .snd .snd) ,
    z .snd .fst ,
    ArrowCast.cast-chain (prefix-suffix n p q le)
      (split-suffix (prefix-degree n p) (in-prefix n p q le) (z .snd .snd)) ,
    cast-chain (prefix-prefix n p q le)
      (split-prefix (prefix-degree n p) (in-prefix n p q le) (z .snd .snd))

  prefix-triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y)
    → outer (prefix-triple-of n p q le (normalized n p c)) ≡ˢ outer (triple n p q le c)
  prefix-triple n pzero q pzero≤ c = reflˢ
  prefix-triple (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer (prefix-triple-of (osuc n) (psuc p) (psuc q) (psuc≤ le) (inner z)))
      (normalized-snoc n p c))
    (strict-cong
      (λ z → outer (inner z .fst , inner z .snd .fst ,
        Arrow.append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .snd .fst) ,
        inner z .snd .snd .snd))
      (prefix-triple n p q le (prefix (osuc (osuc n)) c)))

  suffix-triple : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    → Chain (osuc (osuc n)) y → Triple n p q le y
  suffix-triple n p q le c =
    Arrow.split-vertex (suffix-degree n q) (in-suffix n p q le) s ,
    split-vertex (osuc n) (psuc q) c ,
    ArrowCast.cast-chain (suffix-suffix n p q le)
      (Arrow.split-suffix (suffix-degree n q) (in-suffix n p q le) s) ,
    ArrowCast.cast-chain (suffix-prefix n p q le)
      (Arrow.split-prefix (suffix-degree n q) (in-suffix n p q le) s) ,
    split-prefix (osuc n) (psuc q) c
    where s = split-suffix (osuc n) (psuc q) c

  suffix-triple-correct : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y)
    → outer (suffix-triple n p q le c) ≡ˢ outer (triple n p q le c)
  suffix-triple-correct n pzero q pzero≤ c = reflˢ
  suffix-triple-correct (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-trans
    (strict-cong
      (λ z → outer
        ( suffix-triple n p q le (prefix (osuc (osuc n)) c) .fst
        , suffix-triple n p q le (prefix (osuc (osuc n)) c) .snd .fst
        , inner z
        , suffix-triple n p q le (prefix (osuc (osuc n)) c) .snd .snd .snd ))
      (ArrowCast.cast-append (suffix-suffix n p q le) (last-arrow (osuc (osuc n)) c)
        (Arrow.split-suffix (suffix-degree n q) (in-suffix n p q le)
          (split-suffix (osuc n) (psuc q) (prefix (osuc (osuc n)) c)))))
    (strict-cong
      (λ z → outer (inner z .fst , inner z .snd .fst ,
        Arrow.append (suffix-degree n p) (last-arrow (osuc (osuc n)) c) (inner z .snd .snd .fst) ,
        inner z .snd .snd .snd))
      (suffix-triple-correct n p q le (prefix (osuc (osuc n)) c)))
