{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CoproductPlots where

-- The coproduct plot structure is generated from the component plots
-- by actual reparametrization and open-local gluing. Its continuity and
-- smooth mapping operations are proved by induction on those certificates.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; OpenFragment; IsOpen )
open import Orbifolds.Intensional.CompactSeparation using (Continuous)
open import Orbifolds.Intensional.OpenSubspaces using
  ( Carrier; openSubspace; sumOpenFragment; injection-continuous
  ; compose-continuous; sum-map-continuous )
open import Orbifolds.Intensional.LocalPlots using
  ( PlotProbes; DomainPatch; patch-domain; patch-open; patch-map )
import Orbifolds.Intensional.LocalPlots as LP

private variable ℓ : Level

sum-map : {I : Set ℓ} {A B : I → Set ℓ}
  → ((k : I) → A k → B k) → Σ I A → Σ I B
sum-map f (k , a) = k , f k a

sum-elim : {I C : Set ℓ} {A : I → Set ℓ}
  → ((k : I) → A k → C) → Σ I A → C
sum-elim f (k , a) = f k a

module Theory {ℓ : Level} (ext : FunExt ℓ ℓ) (probes : PlotProbes ℓ) where

  module P = LP.Theory ext probes
  open P
  open PlotProbes probes

  data SumPlots {I : Set ℓ} {A : I → Set ℓ}
      (OA : (k : I) → OpenFragment (A k))
      (SA : (k : I) → LocalPlotStructure (OA k))
      : (i : Probe) (U : Subset (Points i))
        → (Carrier U → Σ I A) → Set (Code ℓ) where
    component-plot : {i : Probe} {U : Subset (Points i)}
      → (k : I) (p : Carrier U → A k) → Plots (SA k) i U p
      → SumPlots OA SA i U (λ u → k , p u)
    reparam-plot : {i j : Probe}
      → {U : Subset (Points i)} {V : Subset (Points j)}
      → IsOpen (probe-topology i) U → IsOpen (probe-topology j) V
      → (f : Carrier U → Carrier V) → Reparam U V f
      → (p : Carrier V → Σ I A) → SumPlots OA SA j V p
      → SumPlots OA SA i U (λ u → p (f u))
    local-plot : {i : Probe} {U : Subset (Points i)} {p : Carrier U → Σ I A}
      → IsOpen (probe-topology i) U
      → ((u : Carrier U) → Σ (DomainPatch (probe-topology i) U u)
        (λ patch → SumPlots OA SA i (patch-domain patch) (λ v → p (patch-map patch v))))
      → SumPlots OA SA i U p

  sum-plots-continuous : {I : Set ℓ} {A : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → (SA : (k : I) → LocalPlotStructure (OA k))
    → (i : Probe) (U : Subset (Points i)) (open-U : IsOpen (probe-topology i) U)
    → (p : Carrier U → Σ I A) → SumPlots OA SA i U p
    → Continuous (openSubspace (probe-topology i) U open-U) (sumOpenFragment OA) p
  sum-plots-continuous OA SA i U open-U p (component-plot k q plot) =
    compose-continuous (openSubspace (probe-topology i) U open-U)
      (OA k) (sumOpenFragment OA) q (λ a → k , a)
      (plot-continuous (SA k) i U open-U q plot) (injection-continuous OA k)
  sum-plots-continuous OA SA i U open-U p
      (reparam-plot {j = j} {V = V} open-U' open-V f rf q plot) =
    compose-continuous (openSubspace (probe-topology i) U open-U)
      (openSubspace (probe-topology j) V open-V) (sumOpenFragment OA) f q
      (reparam-continuous U V open-U open-V f rf)
      (sum-plots-continuous OA SA j V open-V q plot)
  sum-plots-continuous OA SA i U open-U p (local-plot open-U' local) =
    domain-local-continuous (sumOpenFragment OA) i U open-U p
      (λ u →
        let chosen = local u
            patch = fst chosen
        in patch , sum-plots-continuous OA SA i (patch-domain patch) (patch-open patch)
          (λ v → p (patch-map patch v)) (snd chosen))

  sumPlotStructure : {I : Set ℓ} {A : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → ((k : I) → LocalPlotStructure (OA k))
    → LocalPlotStructure (sumOpenFragment OA)
  Plots (sumPlotStructure OA SA) = SumPlots OA SA
  plot-constant (sumPlotStructure OA SA) i U open-U (k , a) =
    component-plot k (λ _ → a) (plot-constant (SA k) i U open-U a)
  plot-reparam (sumPlotStructure OA SA) U V open-U open-V f rf p plot =
    reparam-plot open-U open-V f rf p plot
  plot-local (sumPlotStructure OA SA) i U open-U p local = local-plot open-U local
  plot-continuous (sumPlotStructure OA SA) = sum-plots-continuous OA SA

  injection-smooth : {I : Set ℓ} {A : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → (SA : (k : I) → LocalPlotStructure (OA k)) → (k : I)
    → Smooth (SA k) (sumPlotStructure OA SA) (λ a → k , a)
  smooth-continuous (injection-smooth OA SA k) = injection-continuous OA k
  preserves-plots (injection-smooth OA SA k) i U open-U p plot = component-plot k p plot

  sum-map-plots : {I : Set ℓ} {A B : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → (OB : (k : I) → OpenFragment (B k))
    → (SA : (k : I) → LocalPlotStructure (OA k))
    → (SB : (k : I) → LocalPlotStructure (OB k))
    → (f : (k : I) → A k → B k) → ((k : I) → Smooth (SA k) (SB k) (f k))
    → (i : Probe) (U : Subset (Points i)) → IsOpen (probe-topology i) U
    → (p : Carrier U → Σ I A) → SumPlots OA SA i U p
    → SumPlots OB SB i U (λ u → sum-map f (p u))
  sum-map-plots OA OB SA SB f sf i U open-U p (component-plot k q plot) =
    component-plot k (λ u → f k (q u)) (preserves-plots (sf k) i U open-U q plot)
  sum-map-plots OA OB SA SB f sf i U open-U p
      (reparam-plot {j = j} {V = V} open-U' open-V r rr q plot) =
    reparam-plot open-U open-V r rr (λ v → sum-map f (q v))
      (sum-map-plots OA OB SA SB f sf j V open-V q plot)
  sum-map-plots OA OB SA SB f sf i U open-U p (local-plot open-U' local) =
    local-plot open-U
      (λ u →
        let chosen = local u
            patch = fst chosen
        in patch , sum-map-plots OA OB SA SB f sf i (patch-domain patch) (patch-open patch)
          (λ v → p (patch-map patch v)) (snd chosen))

  sum-map-smooth : {I : Set ℓ} {A B : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → (OB : (k : I) → OpenFragment (B k))
    → (SA : (k : I) → LocalPlotStructure (OA k))
    → (SB : (k : I) → LocalPlotStructure (OB k))
    → (f : (k : I) → A k → B k) → ((k : I) → Smooth (SA k) (SB k) (f k))
    → Smooth (sumPlotStructure OA SA) (sumPlotStructure OB SB) (sum-map f)
  smooth-continuous (sum-map-smooth OA OB SA SB f sf) =
    sum-map-continuous OA OB f (λ k → smooth-continuous (sf k))
  preserves-plots (sum-map-smooth OA OB SA SB f sf) = sum-map-plots OA OB SA SB f sf

  sum-elim-plots : {I C : Set ℓ} {A : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k)) → (OC : OpenFragment C)
    → (SA : (k : I) → LocalPlotStructure (OA k)) → (SC : LocalPlotStructure OC)
    → (f : (k : I) → A k → C) → ((k : I) → Smooth (SA k) SC (f k))
    → (i : Probe) (U : Subset (Points i)) → IsOpen (probe-topology i) U
    → (p : Carrier U → Σ I A) → SumPlots OA SA i U p
    → Plots SC i U (λ u → sum-elim f (p u))
  sum-elim-plots OA OC SA SC f sf i U open-U p (component-plot k q plot) =
    preserves-plots (sf k) i U open-U q plot
  sum-elim-plots OA OC SA SC f sf i U open-U p
      (reparam-plot {j = j} {V = V} open-U' open-V r rr q plot) =
    plot-reparam SC U V open-U open-V r rr (λ v → sum-elim f (q v))
      (sum-elim-plots OA OC SA SC f sf j V open-V q plot)
  sum-elim-plots OA OC SA SC f sf i U open-U p (local-plot open-U' local) =
    plot-local SC i U open-U (λ u → sum-elim f (p u))
      (λ u →
        let chosen = local u
            patch = fst chosen
        in patch , sum-elim-plots OA OC SA SC f sf i (patch-domain patch) (patch-open patch)
          (λ v → p (patch-map patch v)) (snd chosen))

  sum-elim-smooth : {I C : Set ℓ} {A : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k)) → (OC : OpenFragment C)
    → (SA : (k : I) → LocalPlotStructure (OA k)) → (SC : LocalPlotStructure OC)
    → (f : (k : I) → A k → C) → ((k : I) → Smooth (SA k) SC (f k))
    → Smooth (sumPlotStructure OA SA) SC (sum-elim f)
  smooth-continuous (sum-elim-smooth OA OC SA SC f sf) W open-W k =
    smooth-continuous (sf k) W open-W
  preserves-plots (sum-elim-smooth OA OC SA SC f sf) = sum-elim-plots OA OC SA SC f sf

  sum-diffeomorphism : {I : Set ℓ} {A B : I → Set ℓ}
    → (OA : (k : I) → OpenFragment (A k))
    → (OB : (k : I) → OpenFragment (B k))
    → (SA : (k : I) → LocalPlotStructure (OA k))
    → (SB : (k : I) → LocalPlotStructure (OB k))
    → ((k : I) → Diffeomorphism (SA k) (SB k))
    → Diffeomorphism (sumPlotStructure OA SA) (sumPlotStructure OB SB)
  equivalence (sum-diffeomorphism OA OB SA SB d) = equiv
    (sum-map (λ k → forward (equivalence (d k))))
    (sum-map (λ k → backward (equivalence (d k))))
    (λ { (k , b) → cong (λ z → k , z) (section (equivalence (d k)) b) })
    (λ { (k , a) → cong (λ z → k , z) (retraction (equivalence (d k)) a) })
  smooth-forward (sum-diffeomorphism OA OB SA SB d) =
    sum-map-smooth OA OB SA SB (λ k → forward (equivalence (d k)))
      (λ k → smooth-forward (d k))
  smooth-backward (sum-diffeomorphism OA OB SA SB d) =
    sum-map-smooth OB OA SB SA (λ k → backward (equivalence (d k)))
      (λ k → smooth-backward (d k))
