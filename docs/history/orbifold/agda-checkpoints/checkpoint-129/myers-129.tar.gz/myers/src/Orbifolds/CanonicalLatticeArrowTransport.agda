{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CanonicalLatticeArrowTransport where

-- The actual inverse scalar-arrow coordinate takes the entire
-- dependent pair. This retains its exact inverse and vector-transport
-- equations without projecting a concrete scalar certificate first.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Algebra.CommRing.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexPairs as CP
import Orbifolds.ComplexLines as CL
import Orbifolds.ComplexLatticeStructures as LS
import Orbifolds.CanonicalLatticeIdentities as LI
import Orbifolds.CanonicalLatticeScalarTransport as CST

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  Complex = CP.Ring.Complex R
  canonical = CL.Complex.canonical-line R
  Unit = CL.Complex.Unit R
  Moduli = LS.Geometry.FiniteFreeModuli R kock order compatibility
  Lattice = LS.Geometry.FiniteFreeLattice R kock order compatibility canonical

  module At (Λ Γ : Lattice) where
    Arrow : Type ℓ
    Arrow = Σ[ u ∈ Unit ] CST.Geometry.At.Preserves R kock order compatibility Λ Γ u

    abstract
      arrow-path : Arrow → Path Moduli (canonical , Λ) (canonical , Γ)
      arrow-path a = CST.Geometry.At.scalar-path R kock order compatibility Λ Γ (a .fst) (a .snd)

      inverse-computation : (a : Arrow)
        → invEq (LI.Geometry.Canonical.scalar-identities R kock order compatibility Λ Γ) a
          ≡ arrow-path a
      inverse-computation a = CST.Geometry.At.inverse-computation R kock order compatibility
        Λ Γ (a .fst) (a .snd)

      line-transport : (a : Arrow) (z : Complex)
        → subst (CL.Complex.Carrier R) (cong fst (arrow-path a)) z
          ≡ CP.Ring._*c_ R (a .fst .fst) z
      line-transport a = CST.Geometry.At.line-transport R kock order compatibility
        Λ Γ (a .fst) (a .snd)
