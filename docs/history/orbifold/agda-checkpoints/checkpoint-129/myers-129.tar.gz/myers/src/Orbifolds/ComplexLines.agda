{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexLines where

-- Actual rank-one module exemplars, with structured univalent identities.
-- Specialization to the constructed complex ring gives complex lines.
-- No chosen basis is stored in a line: existence is only truncated.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties using (module RingTheory)
open import Cubical.Algebra.Module.Base
open import Cubical.Algebra.Module.Properties using (idLeftModuleHom)
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.ComplexPairs as CP
import Orbifolds.Quotients as Quotients

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open SF.RingContext R using (Invertible; invertible-isProp)

  Module : Type (ℓ-suc ℓ)
  Module = LeftModule (CommRing→Ring R) ℓ

  standard : Module
  standard .fst = R .fst
  standard .snd .LeftModuleStr.0m = 0r
  standard .snd .LeftModuleStr._+_ = _+_
  standard .snd .LeftModuleStr.-_ = -_
  standard .snd .LeftModuleStr._⋆_ = _·_
  standard .snd .LeftModuleStr.isLeftModule = makeIsLeftModule is-set
    +Assoc +IdR +InvR +Comm (λ r s x → sym (·Assoc r s x)) ·DistR+ ·DistL+ ·IdL

  hom-laws-prop : (M N : Module) (f : M .fst → N .fst)
    → isProp (IsLeftModuleHom (M .snd) f (N .snd))
  IsLeftModuleHom.pres0 (hom-laws-prop M N f p q i) =
    LeftModuleStr.is-set (N .snd) _ _ (p .IsLeftModuleHom.pres0) (q .IsLeftModuleHom.pres0) i
  IsLeftModuleHom.pres+ (hom-laws-prop M N f p q i) x y =
    LeftModuleStr.is-set (N .snd) _ _ (p .IsLeftModuleHom.pres+ x y) (q .IsLeftModuleHom.pres+ x y) i
  IsLeftModuleHom.pres- (hom-laws-prop M N f p q i) x =
    LeftModuleStr.is-set (N .snd) _ _ (p .IsLeftModuleHom.pres- x) (q .IsLeftModuleHom.pres- x) i
  IsLeftModuleHom.pres⋆ (hom-laws-prop M N f p q i) r x =
    LeftModuleStr.is-set (N .snd) _ _ (p .IsLeftModuleHom.pres⋆ r x) (q .IsLeftModuleHom.pres⋆ r x) i

  module-equivalences-set : (M N : Module) → isSet (LeftModuleEquiv M N)
  module-equivalences-set M N = isSetΣSndProp
    (isOfHLevel≃ 2 (LeftModuleStr.is-set (M .snd)) (LeftModuleStr.is-set (N .snd)))
    (λ e → hom-laws-prop M N (e .fst))

  IsLine : Module → Type ℓ
  IsLine M = PT.∥ LeftModuleEquiv standard M ∥₁

  Line : Type (ℓ-suc ℓ)
  Line = Σ Module IsLine

  canonical-line : Line
  canonical-line = standard , PT.∣ idEquiv (R .fst) , idLeftModuleHom standard .snd ∣₁

  Carrier : Line → Type ℓ
  Carrier L = L .fst .fst

  line-identities : (L M : Line) → LeftModuleEquiv (L .fst) (M .fst) ≃ (L ≡ M)
  line-identities L M = LeftModulePath (L .fst) (M .fst)
    ∙ₑ Σ≡PropEquiv (λ _ → PT.squash₁)

  line-groupoid : isGroupoid Line
  line-groupoid L M = isOfHLevelRespectEquiv 2 (line-identities L M)
    (module-equivalences-set (L .fst) (M .fst))

  line-connected : (L : Line) → PT.∥ canonical-line ≡ L ∥₁
  line-connected L = PT.map (equivFun (line-identities canonical-line L)) (L .snd)

  module-path-carrier : (M N : Module) (e : LeftModuleEquiv M N)
    → cong fst (equivFun (LeftModulePath M N) e) ≡ ua (e .fst)
  module-path-carrier M N e = refl

  line-path-first : (L M : Line) (e : LeftModuleEquiv (L .fst) (M .fst))
    → cong fst (equivFun (line-identities L M) e)
      ≡ equivFun (LeftModulePath (L .fst) (M .fst)) e
  line-path-first L M e = secEq
    (cong fst , isEmbeddingFstΣProp (λ _ → PT.squash₁) {u = L} {v = M})
    (equivFun (LeftModulePath (L .fst) (M .fst)) e)

  line-path-carrier : (L M : Line) (e : LeftModuleEquiv (L .fst) (M .fst))
    → cong Carrier (equivFun (line-identities L M) e) ≡ ua (e .fst)
  line-path-carrier L M e = cong (cong fst) (line-path-first L M e)
    ∙ module-path-carrier (L .fst) (M .fst) e

  line-path-transport : (L M : Line) (e : LeftModuleEquiv (L .fst) (M .fst))
    (x : Carrier L)
    → subst Carrier (equivFun (line-identities L M) e) x ≡ e .fst .fst x
  line-path-transport L M e x = cong (λ p → transport p x) (line-path-carrier L M e)
    ∙ uaβ (e .fst) x

  line-delooping : Quotients.Delooping (ℓ-suc ℓ)
  Quotients.Delooping.BG line-delooping = Line
  Quotients.Delooping.point line-delooping = canonical-line
  Quotients.Delooping.connected line-delooping = line-connected

  scale : R .fst → R .fst → R .fst
  scale u x = u · x

  scale-hom : (u : R .fst) → LeftModuleHom standard standard
  scale-hom u .fst = scale u
  IsLeftModuleHom.pres0 (scale-hom u .snd) = 0RightAnnihilates u
  IsLeftModuleHom.pres+ (scale-hom u .snd) = ·DistR+ u
  IsLeftModuleHom.pres- (scale-hom u .snd) x = solve! R
  IsLeftModuleHom.pres⋆ (scale-hom u .snd) r x = solve! R

  hom-is-scaling : (f : LeftModuleHom standard standard) (x : R .fst)
    → f .fst x ≡ scale (f .fst 1r) x
  hom-is-scaling f x = cong (f .fst) (sym (·IdR x))
    ∙ f .snd .IsLeftModuleHom.pres⋆ x 1r ∙ ·Comm x (f .fst 1r)

  hom-evaluation : LeftModuleHom standard standard ≃ R .fst
  hom-evaluation = isoToEquiv (iso (λ f → f .fst 1r) scale-hom ·IdR
    (λ f → Σ≡Prop (hom-laws-prop standard standard)
      (funExt λ x → sym (hom-is-scaling f x))))

  Unit : Type ℓ
  Unit = Σ (R .fst) Invertible

  unit-isSet : isSet Unit
  unit-isSet = isSetΣSndProp is-set invertible-isProp

  unit-equivalence : (u : Unit) → LeftModuleEquiv standard standard
  unit-equivalence (u , v , uv) =
    isoToEquiv (iso (scale u) (scale v)
      (λ x → ·Assoc u v x ∙ cong (_· x) uv ∙ ·IdL x)
      (λ x → ·Assoc v u x ∙ cong (_· x) (·Comm v u ∙ uv) ∙ ·IdL x))
    , scale-hom u .snd

  equivalence-unit : LeftModuleEquiv standard standard → Unit
  equivalence-unit e = e .fst .fst 1r , invEq (e .fst) 1r ,
    sym (hom-is-scaling (e .fst .fst , e .snd) (invEq (e .fst) 1r))
      ∙ secEq (e .fst) 1r

  automorphisms≃units : LeftModuleEquiv standard standard ≃ Unit
  automorphisms≃units = isoToEquiv (iso equivalence-unit unit-equivalence
    (λ u → Σ≡Prop invertible-isProp (·IdR (u .fst)))
    (λ e → Σ≡Prop (λ f → hom-laws-prop standard standard (f .fst))
      (Σ≡Prop isPropIsEquiv (funExt λ x → sym (hom-is-scaling (e .fst .fst , e .snd) x)))))

  line-loops≃units : (canonical-line ≡ canonical-line) ≃ Unit
  line-loops≃units = invEquiv (line-identities canonical-line canonical-line)
    ∙ₑ automorphisms≃units

  unit-loop : Unit → canonical-line ≡ canonical-line
  unit-loop u = equivFun (line-identities canonical-line canonical-line) (unit-equivalence u)

  unit-loop-transport : (u : Unit) (x : R .fst)
    → subst Carrier (unit-loop u) x ≡ u .fst · x
  unit-loop-transport u = line-path-transport canonical-line canonical-line (unit-equivalence u)

module Complex {ℓ : Level} (R : CommRing ℓ) where
  module Pairs = CP.Ring R
  open Ring Pairs.ComplexRing public
