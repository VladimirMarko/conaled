{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentUnifiedLiteralFiniteCellMaps where

-- The actual finite cell map and all its dependent fillers are the checked
-- Core construction. Its comparison is given an explicit literal pullback
-- endpoint, retaining the original path and its complete first projection.
open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.HomotopyCoherentFiniteCellMaps as Core
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module Boundary = Core.Construction C D G α E F n source target f triangle
    using (boundary-path)
  open Boundary public using (boundary-path)

  module Cell where
    module Maps = Core.Construction.Cell C D G α E F n source target f triangle
      using (induced; attachment-square)
    open Maps public using (induced; attachment-square)
    module TargetSpace (Y : Type ℓ) = Core.Construction.Cell.TargetSpace
      C D G α E F n source target f triangle Y using (pullback)

  module At (Y : Type ℓ) where
    module Paths = Core.Construction.At C D G α E F n source target f triangle Y
      using (lower-path; lower-path-value)
    open Paths public using (lower-path; lower-path-value)

    comparison-type : (s : Core.Construction.TargetCell.Cocone C D G α E F n source target f triangle Y)
      → Type ℓ
    comparison-type s =
      Core.Construction.SD.compare C D G α E F n source target f triangle Y
        (Literal.Map.TargetSpace.pullback E (osuc n)
          (Core.Construction.A C D G α E F n source target f triangle)
          (Core.Construction.B C D G α E F n source target f triangle)
          (Core.Construction.SD.Index C D G α E F n source target f triangle)
          (Core.Construction.SD.Coefficient C D G α E F n source target f triangle)
          (Core.Construction.TG.Coefficient C D G α E F n source target f triangle)
          (Core.Construction.SD.original-boundary C D G α E F n source target f triangle)
          (Core.Construction.TG.original-boundary C D G α E F n source target f triangle)
          f (λ c → Transformations.ForCategory.Transformation.component α (c .fst))
          (Core.Construction.boundary-path C D G α E F n source target f triangle) Y s)
        ≡ Core.Construction.R.finite-restriction C D G α E F n source target f triangle Y (osuc n)
          (Core.Construction.TG.compare C D G α E F n source target f triangle Y s)

    abstract
      comparison-square : (s : Core.Construction.TargetCell.Cocone C D G α E F n source target f triangle Y)
        → comparison-type s
      comparison-square s = Core.Construction.At.comparison-square C D G α E F n source target f triangle Y s

      comparison-prefix : (s : Core.Construction.TargetCell.Cocone C D G α E F n source target f triangle Y)
        → cong fst (comparison-square s)
          ≡ Core.Construction.At.lower-path C D G α E F n source target f triangle Y (s .fst)
      comparison-prefix s = refl

