{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalFillerFunctionTypes where

-- A function-valued complete cubical filler is equivalent to its family
-- of pointwise fillers. The full boundary paths are distributed using
-- literal function extensionality, and the shell evaluation comparison
-- is the proved one for the representable shell action.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.CubicalShells using (Shell)
open import Orbifolds.CubicalShellSpheres using (SphereBoundary; evaluate-shell)
open import Orbifolds.CubicalShellMaps using (map-shell; evaluate-natural)
open import Orbifolds.CubicalShellFillers using (Filler)
open import Orbifolds.CubicalFillerNullhomotopies using (Nullhomotopy; filler-nullhomotopy)

module At {ℓa ℓy : Level} (n : ℕ) (A : Type ℓa) (Y : Type ℓy)
    (b : Shell n (A → Y)) where
  evaluation : A → (A → Y) → Y
  evaluation a h = h a

  point-shell : A → Shell n Y
  point-shell a = map-shell n (evaluation a) b

  RawPointwise : Type (ℓ-max ℓa ℓy)
  RawPointwise = (a : A) → Σ[ y ∈ Y ]
    ((λ s → evaluate-shell n b s a) ≡ (λ (_ : SphereBoundary n) → y))

  split : Nullhomotopy n b → RawPointwise
  split (h , p) a = h a , (λ i s → p i s a)

  join : RawPointwise → Nullhomotopy n b
  join q = (λ a → q a .fst) , (λ i s a → q a .snd i s)

  split-equivalence : Nullhomotopy n b ≃ RawPointwise
  split-equivalence = isoToEquiv (iso split join (λ _ → refl) (λ _ → refl))

  point-nullhomotopy : (a : A)
    → (Σ[ y ∈ Y ] ((λ s → evaluate-shell n b s a) ≡ (λ (_ : SphereBoundary n) → y)))
      ≃ Nullhomotopy n (point-shell a)
  point-nullhomotopy a = Σ-cong-equiv-snd λ y →
    compPathlEquiv (evaluate-natural n (evaluation a) b)

  point-filler : (a : A)
    → (Σ[ y ∈ Y ] ((λ s → evaluate-shell n b s a) ≡ (λ (_ : SphereBoundary n) → y)))
      ≃ Filler n (point-shell a)
  point-filler a = point-nullhomotopy a ∙ₑ invEquiv (filler-nullhomotopy n (point-shell a))

  equivalence : Filler n b ≃ ((a : A) → Filler n (point-shell a))
  equivalence = filler-nullhomotopy n b ∙ₑ split-equivalence ∙ₑ equivΠCod point-filler

  pointwise : Filler n b → (a : A) → Filler n (point-shell a)
  pointwise = equivalence .fst

  assemble : ((a : A) → Filler n (point-shell a)) → Filler n b
  assemble = invEq equivalence

  pointwise-assemble : (q : (a : A) → Filler n (point-shell a))
    → pointwise (assemble q) ≡ q
  pointwise-assemble = secEq equivalence

  assemble-pointwise : (q : Filler n b) → assemble (pointwise q) ≡ q
  assemble-pointwise = retEq equivalence

  pointwise-nullhomotopy : (q : Filler n b) (a : A)
    → filler-nullhomotopy n (point-shell a) .fst (pointwise q a)
      ≡ (point-nullhomotopy a .fst (split (filler-nullhomotopy n b .fst q) a))
  pointwise-nullhomotopy q a = secEq (filler-nullhomotopy n (point-shell a))
    (point-nullhomotopy a .fst (split (filler-nullhomotopy n b .fst q) a))
