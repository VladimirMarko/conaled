{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Myers, arXiv:2205.15887v1, Proposition 6.1.7, with the uniqueness
-- condition corrected: one index names at most one point.  All existential
-- claims below use propositional truncation; no choice principle is assumed.
module Orbifolds.Association where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.SumFin using (Fin)
open import Cubical.Data.SubFinSet using (isSubFinSet)
open import Cubical.Functions.Embedding
open import Cubical.Functions.Surjection
open import Cubical.HITs.PropositionalTruncation as PT
  using (∥_∥₁; ∣_∣₁; squash₁)

private
  variable
    ℓ ℓ' ℓ'' ρ σ : Level

-- A total relation whose fibers over the label type are subsingletons.
-- It may assign several labels to the same point.
record Association (X : Type ℓ) (Y : Type ℓ') (ρ : Level)
    : Type (ℓ-max (ℓ-max ℓ ℓ') (ℓ-suc ρ)) where
  field
    rel : X → Y → Type ρ
    rel-isProp : (x : X) (y : Y) → isProp (rel x y)
    total : (x : X) → ∥ Σ[ y ∈ Y ] rel x y ∥₁
    left-unique : {x x' : X} {y : Y} → rel x y → rel x' y → x ≡ x'

open Association public

-- Relational composition preserves the corrected property.  The set
-- hypothesis is explicit because truncations are eliminated into x = x'.
composeAssociation : {X : Type ℓ} {Y : Type ℓ'} {Z : Type ℓ''}
  → isSet X → Association X Y ρ → Association Y Z σ
  → Association X Z (ℓ-max ℓ' (ℓ-max ρ σ))
rel (composeAssociation {Y = Y} setX R S) x z =
  ∥ Σ[ y ∈ Y ] (rel R x y × rel S y z) ∥₁
rel-isProp (composeAssociation setX R S) x z = squash₁
total (composeAssociation setX R S) x =
  PT.rec squash₁
    (λ { (y , r) → PT.map (λ { (z , s) → z , ∣ y , r , s ∣₁ }) (total S y) })
    (total R x)
left-unique (composeAssociation setX R S) {x} {x'} {z} =
  PT.rec2 (setX x x')
    (λ { (y , r , s) (y' , r' , s') →
      left-unique R r (subst (rel R x') (sym (left-unique S s s')) r') })

-- Definition 6.1.1(4), with a specific bound retained.  The middle object is
-- an actual type embedded in Fin n, and its map onto X is genuinely surjective.
record SubfiniteSpan (X : Type ℓ) (n : ℕ) : Type (ℓ-suc ℓ) where
  field
    Domain : Type ℓ
    inclusion : Domain ↪ Fin n
    cover : Domain ↠ X

open SubfiniteSpan public

SubfinitelyEnumerable : Type ℓ → Type (ℓ-suc ℓ)
SubfinitelyEnumerable X = ∥ Σ[ n ∈ ℕ ] SubfiniteSpan X n ∥₁

HasFiniteAssociation : (X : Type ℓ) → Type (ℓ-suc ℓ)
HasFiniteAssociation {ℓ = ℓ} X =
  ∥ Σ[ n ∈ ℕ ] Association X (Fin n) ℓ ∥₁

-- The relation's graph projects injectively to Fin n precisely because
-- uniqueness is in the X coordinate, not in the finite-label coordinate.
association→span : {X : Type ℓ} {n : ℕ}
  → Association X (Fin n) ℓ → SubfiniteSpan X n
Domain (association→span {X = X} {n = n} R) =
  Σ[ i ∈ Fin n ] Σ[ x ∈ X ] rel R x i
inclusion (association→span R) = EmbeddingΣProp
  (λ i (x , r) (x' , r') →
    Σ≡Prop (λ x → rel-isProp R x i) (left-unique R r r'))
cover (association→span R) =
  (λ { (i , x , r) → x }) ,
  (λ x → PT.map (λ { (i , r) → (i , x , r) , refl }) (total R x))

-- Conversely, take the image relation of the two maps in the span.
span→association : {X : Type ℓ} {n : ℕ}
  → isSet X → SubfiniteSpan X n → Association X (Fin n) ℓ
rel (span→association setX W) x i =
  ∥ Σ[ a ∈ Domain W ] ((inclusion W .fst a ≡ i) × (cover W .fst a ≡ x)) ∥₁
rel-isProp (span→association setX W) x i = squash₁
total (span→association setX W) x =
  PT.map
    (λ { (a , p) → inclusion W .fst a , ∣ a , refl , p ∣₁ })
    (cover W .snd x)
left-unique (span→association setX W) {x} {x'} {i} =
  PT.rec2 (setX x x')
    (λ { (a , ea , qa) (b , eb , qb) →
      sym qa ∙ cong (cover W .fst)
        (isEmbedding→Inj (inclusion W .snd) a b (ea ∙ sym eb)) ∙ qb })

-- A proposition-level equivalence for each bound, and then the unbounded
-- characterization asserted by the repaired Proposition 6.1.7.
bounded-association-characterization : {X : Type ℓ} (setX : isSet X) (n : ℕ)
  → ∥ Association X (Fin n) ℓ ∥₁ ≃ ∥ SubfiniteSpan X n ∥₁
bounded-association-characterization setX n = propBiimpl→Equiv squash₁ squash₁
  (PT.map association→span) (PT.map (span→association setX))

association-characterization : {X : Type ℓ} → isSet X
  → HasFiniteAssociation X ≃ SubfinitelyEnumerable X
association-characterization setX = propBiimpl→Equiv squash₁ squash₁
  (PT.map (λ { (n , R) → n , association→span R }))
  (PT.map (λ { (n , W) → n , span→association setX W }))

-- Explicit bridge to the pinned Cubical library's existing subfinite-set
-- predicate, so the middle object is not a novel notion of subfiniteness.
SubfiniteSurjection : Type ℓ → Type (ℓ-suc ℓ)
SubfiniteSurjection {ℓ = ℓ} X =
  ∥ Σ[ A ∈ Type ℓ ] (isSubFinSet A × (A ↠ X)) ∥₁

span→subfinite-surjection : {X : Type ℓ} → SubfinitelyEnumerable X
  → SubfiniteSurjection X
span→subfinite-surjection = PT.map
  (λ { (n , W) → Domain W , ∣ n , inclusion W ∣₁ , cover W })

subfinite-surjection→span : {X : Type ℓ} → SubfiniteSurjection X
  → SubfinitelyEnumerable X
subfinite-surjection→span = PT.rec squash₁
  (λ { (A , subfiniteA , q) → PT.map
    (λ { (n , e) → n , record { Domain = A ; inclusion = e ; cover = q } })
    subfiniteA })

subfinite-surjection-characterization : {X : Type ℓ}
  → SubfiniteSurjection X ≃ SubfinitelyEnumerable X
subfinite-surjection-characterization = propBiimpl→Equiv squash₁ squash₁
  subfinite-surjection→span span→subfinite-surjection

-- The second sentence of corrected Proposition 6.1.7.
association-pulls-back-enumerability : {X Y : Type ℓ}
  → isSet X → isSet Y → Association X Y ℓ
  → SubfinitelyEnumerable Y → SubfinitelyEnumerable X
association-pulls-back-enumerability setX setY R = PT.map
  (λ { (n , W) → n , association→span
    (composeAssociation setX R (span→association setY W)) })

-- Combinatorial final step of Lemma 6.2.21.  The existence and smallness of
-- the subsingleton cover are explicit hypotheses, not claimed consequences
-- of manifold geometry in this module.
subsingleton-cover→enumerability : {X Y : Type ℓ}
  → isSet X → isSet Y
  → (U : Y → X → Type ℓ)
  → ((y : Y) (x : X) → isProp (U y x))
  → ((x : X) → ∥ Σ[ y ∈ Y ] U y x ∥₁)
  → ((y : Y) {x x' : X} → U y x → U y x' → x ≡ x')
  → SubfinitelyEnumerable Y → SubfinitelyEnumerable X
subsingleton-cover→enumerability setX setY U propU covers singleton =
  association-pulls-back-enumerability setX setY record
    { rel = λ x y → U y x
    ; rel-isProp = λ x y → propU y x
    ; total = covers
    ; left-unique = λ {x} {x'} {y} → singleton y
    }
