{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCoconeRestriction where

-- Actual restriction of full coherent cocones along an exact diagram
-- transformation. Pointwise equivalence of the coefficient restriction
-- maps implies equivalence of this complete, unbounded cocone map.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties using (isEquivPreComp)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentMappingContravariance as Contravariance
import Orbifolds.Coherent.HomotopyCoherentConeMaps as ConeMaps

module Restriction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (Y : Type ℓ) where
  module H = HC.ForCategory C
  module D = H.Diagram D
  module G = H.Diagram G
  module Maps = Transformations.ForCategory C
  module α = Maps.Transformation α
  module DM = Mapping.Mapping C D E F
  module GM = Mapping.Mapping C G E F
  module Coefficients = Contravariance.Contravariance C D G α E F
  module Action = ConeMaps.Action (Opposite C) (GM.Into Y) (DM.Into Y) (Coefficients.Precompose Y) E

  SourceCocone TargetCocone : Type ℓ
  SourceCocone = Action.Source.Limit
  TargetCocone = Action.Target.Limit

  restrict : SourceCocone → TargetCocone
  restrict = Action.cone-map

  finite-restriction : (n : Dim) → Action.SourceFinite.Carrier n → Action.TargetFinite.Carrier n
  finite-restriction = Action.FiniteAction.stage-map

  open Action using (partial-map; partial-square; projection-computation; compatibility-computation) public

  coefficient-equivalences : ((x : Category.Obj C)
      → isEquiv (λ (h : G.Value x → Y) → h ∘ α.component x))
    → isEquiv restrict
  coefficient-equivalences = Action.Equivalence.cone-map-isEquiv

  pointwise-equivalences : ((x : Category.Obj C) → isEquiv (α.component x)) → isEquiv restrict
  pointwise-equivalences pointwise = coefficient-equivalences λ x →
    isEquivPreComp (α.component x , pointwise x)
