{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.EllipticModuliShape where

-- The actual finite-free complex-lattice moduli and its specified q map.
-- The exact Mobius quotient equivalence is constructed, not assumed.
-- Rank means the explicit mere integral Z² basis in the lattice setting.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Pointed.Base using (_≃∙_)
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
import Cubical.HITs.Nullification.Base as N
import Cubical.HITs.Nullification.Properties as NP
import Orbifolds.CrispIdentity as CI
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.IntervalParameterization as IP
import Orbifolds.Crystalline as CR
import Orbifolds.ShapeOne as S1
import Orbifolds.UpperHalfPlane as H
import Orbifolds.SpecialLinearTorsorShape as SS
import Orbifolds.EllipticModuliQuotient as Q
import Orbifolds.MobiusQuotientShape as MQ
import Orbifolds.MobiusUniversalCover as MC
import Orbifolds.NullUnitEquivalences as UE

module Geometry {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (@♭ order : SF.RingContext.StrictOrder R)
    (@♭ compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ upper-identity-rules : CI.CrispIdentityInduction {ℓ-suc ℓ}) where
  UpperHalfPlane : Type ℓ
  UpperHalfPlane = Q.Geometry.UpperHalfPlane R kock order compatibility

  Moduli : Type (ℓ-suc ℓ)
  Moduli = Q.Geometry.Moduli R kock order compatibility

  MobiusQuotient : Type (ℓ-suc ℓ)
  MobiusQuotient = Q.Geometry.MobiusQuotient R kock order compatibility

  BSL₂ℤ : Type (ℓ-suc ℓ)
  BSL₂ℤ = MQ.Geometry.BSL₂ℤ R kock order compatibility identity-rules upper-identity-rules

  q : UpperHalfPlane → Moduli
  q = Q.Geometry.q R kock order compatibility

  orbit : UpperHalfPlane → MobiusQuotient
  orbit = Q.Geometry.orbit R kock order compatibility

  quotient≃moduli : MobiusQuotient ≃ Moduli
  quotient≃moduli = Q.Geometry.quotient≃moduli R kock order compatibility

  quotient-triangle : (τ : UpperHalfPlane) → quotient≃moduli .fst (orbit τ) ≡ q τ
  quotient-triangle = Q.Geometry.quotient-triangle R kock order compatibility

  inverse-triangle : (τ : UpperHalfPlane) → invEq quotient≃moduli (q τ) ≡ orbit τ
  inverse-triangle τ = cong (invEq quotient≃moduli) (sym (quotient-triangle τ))
    ∙ retEq quotient≃moduli (orbit τ)

  shape-unit : Moduli → N.Null (CR.Ring.ShapeGenerator R) Moduli
  shape-unit x = N.∣ x ∣

  quotient-shape-unit : MobiusQuotient → N.Null (CR.Ring.ShapeGenerator R) MobiusQuotient
  quotient-shape-unit x = N.∣ x ∣

  shape-one-unit : Moduli → N.Null (S1.Ring.Generator R) Moduli
  shape-one-unit x = N.∣ x ∣

  module Exponential
      (exponential : IP.Parameterization.PositiveLineEquivalence R kock order compatibility)
      (lower-flat : SS.Geometry.LowerRealFlat R kock order compatibility identity-rules upper-identity-rules)
      (upper-flat : SS.Geometry.UpperRealFlat R kock order compatibility identity-rules upper-identity-rules) where

    abstract
      shape-moduli≃BSL₂ℤ : N.Null (CR.Ring.ShapeGenerator R) Moduli ≃ BSL₂ℤ
      shape-moduli≃BSL₂ℤ = NP.nullPreservesEquiv (CR.Ring.ShapeGenerator R)
        (invEquiv quotient≃moduli) ∙ₑ
        MQ.Geometry.Exponential.Modal.shape-mobius-quotient≃BSL₂ℤ
          R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat

      shape-point : (τ : UpperHalfPlane)
        → shape-moduli≃BSL₂ℤ .fst (shape-unit (q τ))
          ≡ H.Geometry.IntegerActions.regular-torsor R kock order compatibility
      shape-point τ = cong
        (MQ.Geometry.Exponential.Modal.shape-mobius-quotient≃BSL₂ℤ
          R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat .fst)
        (cong quotient-shape-unit (inverse-triangle τ))
        ∙ MQ.Geometry.Exponential.Modal.orbit-point-triangle
          R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat τ

    pointed-shape-equivalence : (τ : UpperHalfPlane)
      → (N.Null (CR.Ring.ShapeGenerator R) Moduli , shape-unit (q τ))
        ≃∙ (BSL₂ℤ , H.Geometry.IntegerActions.regular-torsor R kock order compatibility)
    pointed-shape-equivalence τ = shape-moduli≃BSL₂ℤ , shape-point τ

    shape-loops≃SL₂ℤ : (τ : UpperHalfPlane)
      → Path (N.Null (CR.Ring.ShapeGenerator R) Moduli) (shape-unit (q τ)) (shape-unit (q τ))
        ≃ H.Geometry.IntegerGroup R kock order compatibility .fst
    shape-loops≃SL₂ℤ τ = congEquiv shape-moduli≃BSL₂ℤ ∙ₑ
      conjugatePathEquiv (shape-point τ) ∙ₑ
      H.Geometry.IntegerActions.torsor-loops R kock order compatibility

    abstract
      shape-one-moduli≃BSL₂ℤ : N.Null (S1.Ring.Generator R) Moduli ≃ BSL₂ℤ
      shape-one-moduli≃BSL₂ℤ = NP.nullPreservesEquiv (S1.Ring.Generator R)
        (invEquiv quotient≃moduli) ∙ₑ
        MC.Geometry.Exponential.shape-one≃BSL₂ℤ
          R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat

    module Based (τ₀ : UpperHalfPlane) where
      UniversalCover : Type (ℓ-suc ℓ)
      UniversalCover = fiber shape-one-unit (shape-one-unit (q τ₀))

      cover : UniversalCover → Moduli
      cover = fst

      abstract
        upper-half-plane≃universal-cover : UpperHalfPlane ≃ UniversalCover
        upper-half-plane≃universal-cover =
          MC.Geometry.Exponential.Based.upper-half-plane≃universal-cover
            R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat τ₀
          ∙ₑ UE.Theory.Along.unit-fiber-at (S1.Ring.Generator R) quotient≃moduli
            (orbit τ₀) (q τ₀) (quotient-triangle τ₀)

        universal-cover≃upper-half-plane : UniversalCover ≃ UpperHalfPlane
        universal-cover≃upper-half-plane = invEquiv upper-half-plane≃universal-cover

        cover-triangle : (τ : UpperHalfPlane)
          → cover (upper-half-plane≃universal-cover .fst τ) ≡ q τ
        cover-triangle τ = UE.Theory.Along.coordinate-at
          (S1.Ring.Generator R) quotient≃moduli (orbit τ₀) (q τ₀) (quotient-triangle τ₀)
          (MC.Geometry.Exponential.Based.upper-half-plane≃universal-cover
            R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat τ₀ .fst τ)
          ∙ cong (quotient≃moduli .fst)
            (MC.Geometry.Exponential.Based.cover-triangle
              R kock order compatibility identity-rules upper-identity-rules exponential lower-flat upper-flat τ₀ τ)
          ∙ quotient-triangle τ

      q-is-universal-cover : Σ[ e ∈ (UpperHalfPlane ≃ UniversalCover) ] (cover ∘ e .fst ≡ q)
      q-is-universal-cover = upper-half-plane≃universal-cover , funExt cover-triangle
