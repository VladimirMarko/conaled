{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.DerivedAtlasOrbifold where

-- A bounded family of actual pushout tests. The source comparison and
-- the four vertex lifting assumptions are inputs; source locality and
-- the two completed atlas lifting fields are derived below.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Equivalence
open import Orbifolds.Intensional.BoundedTruncation using (BoundedTruncation; Code)
open import Orbifolds.Intensional.FiniteBranchAtlas
  using (PointedGap; module Finiteness; module Geometry)
open import Orbifolds.Intensional.LiftingCancellation using (precompose; postcompose)
import Orbifolds.Intensional.PushoutLifting as P

private variable ℓ : Level

-- The record deliberately imposes no algebraic Weil condition. Such a
-- condition belongs to the external geometric instance of these data.
record PointedPushoutTest (ℓ : Level) : Set (Code ℓ) where
  field
    NW NE SW SE : Set ℓ
    north : NW → NE
    west : NW → SW
    boundary : P.PushoutBoundary north west
    universal : P.IsPushout boundary
    origin : NW
    target-cocone : P.Cocone north west SE

open PointedPushoutTest

module Test {ℓ : Level} (d : PointedPushoutTest ℓ) where

  baseNW : Unit {ℓ} → NW d
  baseNW _ = origin d

  module Chosen = P.Gap (north d) (west d) (boundary d) (universal d)
    baseNW (target-cocone d)

  pointed-gap : PointedGap ℓ
  PointedGap.Boundary pointed-gap = P.PushoutBoundary.Carrier (boundary d)
  PointedGap.Codomain pointed-gap = SE d
  PointedGap.gap pointed-gap = Chosen.gap
  PointedGap.basepoint pointed-gap = Chosen.baseB tt

  -- The actual four-vertex comparison, with its specified gluing path.
  -- Equivalence of an arbitrary map between these types would not do.
  mapping-comparison : (Z : Set ℓ)
    → (SE d → Z) → P.Cocone (north d) (west d) Z
  mapping-comparison Z h = P.post-cocone h (target-cocone d)

  gap-section : P.restriction (boundary d) (SE d) Chosen.gap ≡ target-cocone d
  gap-section = section
    (isEquiv→Equiv (P.restriction (boundary d) (SE d)) (universal d (SE d)))
    (target-cocone d)

  -- This is an equality in the entire cocone type. The third component
  -- is proved by cong-compose, so no raw funext computation law is used.
  restriction-naturality : (Z : Set ℓ) (h : SE d → Z)
    → P.restriction (boundary d) Z (precompose Chosen.gap h)
      ≡ P.post-cocone h (P.restriction (boundary d) (SE d) Chosen.gap)
  restriction-naturality Z h =
    cong (λ path →
      precompose (P.PushoutBoundary.left-leg (boundary d)) (precompose Chosen.gap h) ,
      (precompose (P.PushoutBoundary.right-leg (boundary d)) (precompose Chosen.gap h) , path))
      (cong-compose (postcompose h) (postcompose Chosen.gap)
        (P.PushoutBoundary.glue (boundary d)))

  comparison-computation : (Z : Set ℓ) (h : SE d → Z)
    → P.restriction (boundary d) Z (precompose Chosen.gap h) ≡ mapping-comparison Z h
  comparison-computation Z h =
    restriction-naturality Z h ∙ cong (P.post-cocone h) gap-section

  mapping-square-local : (Z : Set ℓ) → isEquiv (mapping-comparison Z)
    → isEquiv (precompose {X = Z} Chosen.gap)
  mapping-square-local Z square =
    cancel-right-isEquiv (precompose Chosen.gap) (P.restriction (boundary d) Z)
      (homotopy-isEquiv (mapping-comparison Z)
        (λ h → P.restriction (boundary d) Z (precompose Chosen.gap h))
        (λ h → sym (comparison-computation Z h)) square)
      (universal d Z)

derived-test : PointedPushoutTest ℓ → PointedGap ℓ
derived-test = Test.pointed-gap

module Theory {ℓ : Level} (T : BoundedTruncation ℓ) (ext : FunExt ℓ ℓ) where
  module G = Geometry T ext
  module F = Finiteness T
  module Lifting = P.Existing T ext

  record VertexLifting {A X : Set ℓ} (d : PointedPushoutTest ℓ) (q : A → X) : Set ℓ where
    field
      at-NW : G.RightOrthogonal (Test.baseNW d) q
      at-NE : G.RightOrthogonal (λ (_ : Unit {ℓ}) → north d (origin d)) q
      at-SW : G.RightOrthogonal (λ (_ : Unit {ℓ}) → west d (origin d)) q
      at-SE : G.RightOrthogonal
        (λ (_ : Unit {ℓ}) → fst (target-cocone d) (north d (origin d))) q

  module Family {Index : Set ℓ} (tests : Index → PointedPushoutTest ℓ) where
    module O = G.Tests (λ i → derived-test (tests i))

    ObjectSquares : Set ℓ → Set ℓ
    ObjectSquares A = (i : Index) → isEquiv (Test.mapping-comparison (tests i) A)

    source-locality : {A : Set ℓ} → ObjectSquares A → O.Microlinear A
    source-locality {A = A} squares i =
      Test.mapping-square-local (tests i) A (squares i)

    vertex-lifting→etale : {A X : Set ℓ} (q : A → X)
      → ((i : Index) → VertexLifting (tests i) q) → O.InfinitesimallyEtale q
    O.InfinitesimallyEtale.lift-base (vertex-lifting→etale q vertices) i =
      Lifting.pushout-base-lifting (north d) (west d) (boundary d) (universal d)
        (Test.baseNW d) q
        (VertexLifting.at-NW (vertices i))
        (VertexLifting.at-NE (vertices i))
        (VertexLifting.at-SW (vertices i))
      where
      d = tests i
    O.InfinitesimallyEtale.lift-gap (vertex-lifting→etale q vertices) i =
      Lifting.pushout-gap-lifting (north d) (west d) (boundary d) (universal d)
        (Test.baseNW d) (target-cocone d) q
        (VertexLifting.at-NW (vertices i))
        (VertexLifting.at-NE (vertices i))
        (VertexLifting.at-SW (vertices i))
        (VertexLifting.at-SE (vertices i))
      where
      d = tests i

    -- The conclusion is relative to the derived family of actual gaps.
    -- No preassembled source-locality or atlas-etaleness field is an input.
    finite-branch-pushout-atlas-orbifold : {A X : Set ℓ} (Q : F.EffectiveAtlas A X)
      → isSet A → F.LocalBranchCharts (F.EffectiveAtlas.hom Q)
      → ObjectSquares A
      → ((i : Index) → VertexLifting (tests i) (F.EffectiveAtlas.atlas Q))
      → O.ReducedOrbifold X
    finite-branch-pushout-atlas-orbifold Q setA charts squares vertices =
      O.finite-branch-atlas-orbifold Q setA charts (source-locality squares)
        (vertex-lifting→etale (F.EffectiveAtlas.atlas Q) vertices)
