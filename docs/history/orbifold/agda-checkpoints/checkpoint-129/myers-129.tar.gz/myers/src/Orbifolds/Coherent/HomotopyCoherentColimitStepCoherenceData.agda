{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitStepCoherenceData where

-- The precise canonical-cell and transition computations, with explicit
-- ambient types.  These are aliases of the constructed successor laws;
-- this interface does not copy its equivalence-proof namespace.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStepData as Data
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages

module Step {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  open module Successor = Data.Step C D E F n previous
    using (Previous; Realize; next; canonical-cocone; include) public

  cell-cocone : Stages.Construction.Step.Cell.Cocone C D E F n previous Realize
  cell-cocone = Stages.Construction.Step.cell-cocone C D E F n previous

  cell-original-computation : outer {A = Previous → Realize} (cell-cocone .fst)
    ≡ˢ outer {A = Previous → Realize} include
  cell-original-computation = Stages.Construction.Step.cell-original-computation C D E F n previous

  transition-computation : (Y : Type ℓ) (h : Realize → Y)
    → outer {A = Cocones.Functoriality.Cocone C D E F Y n}
        (Cocones.Functoriality.postcompose C D E F (osuc n) h canonical-cocone .fst)
      ≡ˢ outer {A = Cocones.Functoriality.Cocone C D E F Y n}
        (Cocones.Functoriality.postcompose C D E F n (h ∘ include)
          (Represented.Induction.Represented.universal-cocone previous))
  transition-computation = Stages.Construction.Step.transition-computation C D E F n previous
