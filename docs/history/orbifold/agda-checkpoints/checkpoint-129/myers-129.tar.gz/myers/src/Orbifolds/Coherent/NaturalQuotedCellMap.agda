{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellMap where

-- Literal maps between the actual quoted-cell pushouts. The boundary
-- comparison is an ordinary path of shells. Its lift to the contractible
-- quotation fibers determines the attaching homotopy together with the
-- higher coherence needed for the canonical typed fillers.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.GroupoidLaws using (cong-∙∙; leftright)
open import Cubical.Foundations.Transport using (subst⁻Subst)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalShellFunctor as ShellFunctor
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as Representation
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.Coherent.NaturalQuoteFiberFunctor as FiberFunctor
import Orbifolds.Coherent.NaturalQuoteFiberTransport as FiberTransport
import Orbifolds.Coherent.NaturalQuoteFiberDependentTransport as DependentFiberTransport
import Orbifolds.Coherent.NaturalQuotedFillers as Quoted
import Orbifolds.Coherent.NaturalQuotedCellAttachments as Attachments
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)
import Cubical.HITs.Pushout as PO

module FiberCoherence {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module S = Shells.Action E
  module SF = ShellFunctor.Functoriality E
  module N = Natural.Natural E
  module NF = FiberFunctor.Functoriality E

  Total : (n : Dim) → Type ℓ → Type ℓ
  Total n X = Σ[ b ∈ CS.Shell (toNat n) X ] N.QuoteFiber n b

  strict-total-pair : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    {z : N.QuoteFiber n b} {z' : N.QuoteFiber n b'} (e : outer b ≡ˢ outer b')
    → outer (NF.cast-fiber n e z) ≡ˢ outer z' → outer (b , z) ≡ˢ outer (b' , z')
  strict-total-pair n {b = b} reflˢ p = strict-cong (λ z → outer (b , inner z)) p

  map-total : (n : Dim) {X Y : Type ℓ} → (X → Y) → Total n X → Total n Y
  map-total n f (b , z) = S.map-shell n f b , N.map-fiber n f b z

  map-total-compose : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y) (u : Total n X)
    → outer (map-total n g (map-total n f u)) ≡ˢ outer (map-total n (g ∘ f) u)
  map-total-compose n g f (b , z) = strict-total-pair n (SF.map-compose n g f b)
    (NF.map-fiber-compose n g f b z)

module Map {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A B Index : Type ℓ) (SourceCoefficient TargetCoefficient : Index → Type ℓ)
    (source-boundary : (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → A))
    (target-boundary : (c : Index) → CS.Shell (toNat n) (TargetCoefficient c → B))
    (base-map : A → B) (coefficient-map : (c : Index) → SourceCoefficient c → TargetCoefficient c)
    (boundary-path : (c : Index)
      → Shells.Action.map-shell E n (λ v → base-map ∘ v) (source-boundary c)
        ≡ Shells.Action.map-shell E n (λ v → v ∘ coefficient-map c) (target-boundary c)) where
  open StrictCubicalExtensionality E
  module S = Shells.Action E
  module SF = ShellFunctor.Functoriality E
  module F = Fillers.Action E
  module R = Representation.Representation E
  module N = Natural.Natural E
  module NF = FiberFunctor.Functoriality E
  module NT = FiberTransport.Transport E
  module DT = DependentFiberTransport.Transport E
  module Q = Quoted.Natural E
  module T = FiberCoherence E
  module Source = Attachments.Attachment E n A Index SourceCoefficient source-boundary
  module Target = Attachments.Attachment E n B Index TargetCoefficient target-boundary

  source-fiber : (c : Index) → N.QuoteFiber n
    (S.map-shell n (λ v → base-map ∘ v) (source-boundary c))
  source-fiber c = N.map-fiber n (λ v → base-map ∘ v) (source-boundary c)
    (N.canonical-fiber n (source-boundary c))

  target-fiber : (c : Index) → N.QuoteFiber n
    (S.map-shell n (λ v → v ∘ coefficient-map c) (target-boundary c))
  target-fiber c = N.map-fiber n (λ v → v ∘ coefficient-map c) (target-boundary c)
    (N.canonical-fiber n (target-boundary c))

  fiber-bridge : (c : Index)
    → PathP (λ i → N.QuoteFiber n (boundary-path c i)) (source-fiber c) (target-fiber c)
  fiber-bridge c = toPathP (isContr→isProp
    (R.quote-isEquiv n (SourceCoefficient c → B) .equiv-proof _)
    (subst (N.QuoteFiber n) (boundary-path c) (source-fiber c)) (target-fiber c))

  cell-map : Source.Cell → Target.Cell
  cell-map (c , x) = c , coefficient-map c x

  boundary-map : Source.Boundary → Target.Boundary
  boundary-map (cx , s) = cell-map cx , s

  attachment-square : base-map ∘ Source.attach ≡ Target.attach ∘ boundary-map
  attachment-square i ((c , x) , s) = fiber-bridge c i .fst s x

  boundary-square : cell-map ∘ Source.boundary ≡ Target.boundary ∘ boundary-map
  boundary-square = refl

  induced : Source.Realize → Target.Realize
  induced = PO.Pushout→ Source.attach Source.boundary Target.attach Target.boundary
    boundary-map base-map cell-map attachment-square boundary-square

  include-computation : (a : A) → induced (Source.include a) ≡ Target.include (base-map a)
  include-computation a = refl

  center-computation : (cx : Source.Cell) → induced (Source.center cx) ≡ Target.center (cell-map cx)
  center-computation cx = refl

  attachment-computation : (z : Source.Boundary) (i : I)
    → induced (PO.push z i)
      ≡ ((λ j → Target.include (attachment-square j z)) ∙∙ PO.push (boundary-map z) ∙∙ refl) i
  attachment-computation z i = refl

  module TargetSpace (Y : Type ℓ) where
    source-mapped : (B → Y) → (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → Y)
    source-mapped h c = Source.mapped-boundary Y (h ∘ base-map) c

    target-mapped : (B → Y) → (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → Y)
    target-mapped h c = S.map-shell n (λ v → v ∘ coefficient-map c) (Target.mapped-boundary Y h c)

    source-mapped-fiber : (h : B → Y) (c : Index) → N.QuoteFiber n (source-mapped h c)
    source-mapped-fiber h c = N.map-fiber n (λ v → h ∘ base-map ∘ v) (source-boundary c)
      (N.canonical-fiber n (source-boundary c))

    target-mapped-fiber : (h : B → Y) (c : Index) → N.QuoteFiber n (target-mapped h c)
    target-mapped-fiber h c = N.map-fiber n (λ v → v ∘ coefficient-map c) (Target.mapped-boundary Y h c)
      (N.map-fiber n (λ v → h ∘ v) (target-boundary c) (N.canonical-fiber n (target-boundary c)))

    raw-total-path : (h : B → Y) (c : Index)
      → T.map-total n (λ v → h ∘ v) (_ , source-fiber c)
        ≡ T.map-total n (λ v → h ∘ v) (_ , target-fiber c)
    raw-total-path h c i = T.map-total n (λ v → h ∘ v) (boundary-path c i , fiber-bridge c i)

    source-endpoint : (h : B → Y) (c : Index)
      → outer (T.map-total n (λ v → h ∘ v) (_ , source-fiber c))
        ≡ˢ outer (source-mapped h c , source-mapped-fiber h c)
    source-endpoint h c = T.map-total-compose n (λ v → h ∘ v) (λ v → base-map ∘ v)
      (source-boundary c , N.canonical-fiber n (source-boundary c))

    target-endpoint : (h : B → Y) (c : Index)
      → outer (T.map-total n (λ v → h ∘ v) (_ , target-fiber c))
        ≡ˢ outer (target-mapped h c , target-mapped-fiber h c)
    target-endpoint h c = strict-trans
      (T.map-total-compose n (λ v → h ∘ v) (λ v → v ∘ coefficient-map c)
        (target-boundary c , N.canonical-fiber n (target-boundary c)))
      (strict-sym (T.map-total-compose n (λ v → v ∘ coefficient-map c) (λ v → h ∘ v)
        (target-boundary c , N.canonical-fiber n (target-boundary c))))

    aligned-total-path : (h : B → Y) (c : Index)
      → (source-mapped h c , source-mapped-fiber h c)
        ≡ (target-mapped h c , target-mapped-fiber h c)
    aligned-total-path h c = strict-end-path (λ i → raw-total-path h c i) (source-endpoint h c) (target-endpoint h c)

    mapped-boundary-path : (h : B → Y) (c : Index) → source-mapped h c ≡ target-mapped h c
    mapped-boundary-path h c i = aligned-total-path h c i .fst

    mapped-fiber-bridge : (h : B → Y) (c : Index)
      → PathP (λ i → N.QuoteFiber n (mapped-boundary-path h c i))
          (source-mapped-fiber h c) (target-mapped-fiber h c)
    mapped-fiber-bridge h c i = aligned-total-path h c i .snd

    mapped-boundary-value : (h : B → Y) (c : Index) (i : I)
      → outer (mapped-boundary-path h c i) ≡ˢ outer (S.map-shell n (λ v → h ∘ v) (boundary-path c i))
    mapped-boundary-value h c i = strict-cong (λ z → outer (inner z .fst))
      (strict-end-path-value (λ i → raw-total-path h c i) (source-endpoint h c) (target-endpoint h c) i)

    mapped-sphere-value : (h : B → Y) (c : Index) (i : I)
      → outer (mapped-fiber-bridge h c i .fst) ≡ˢ outer (λ s x → h (fiber-bridge c i .fst s x))
    mapped-sphere-value h c i = strict-cong (λ z → outer (inner z .snd .fst))
      (strict-end-path-value (λ i → raw-total-path h c i) (source-endpoint h c) (target-endpoint h c) i)

    mapped-sphere-path : (h : B → Y) (c : Index)
      → (λ i → mapped-fiber-bridge h c i .fst) ≡ (λ i s x → h (fiber-bridge c i .fst s x))
    mapped-sphere-path h c = strict-to-path (path-ext (mapped-sphere-value h c))

    pullback : Target.Cocone Y → Source.Cocone Y
    pullback (h , fs) = (h ∘ base-map) , λ c → subst (CF.Filler (toNat n))
      (sym (mapped-boundary-path h c))
      (F.map-filler n (λ v → v ∘ coefficient-map c) (Target.mapped-boundary Y h c) (fs c))

    module Restriction (k : Target.Realize → Y) where
      previous : B → Y
      previous = k ∘ Target.include

      target-null : (c : Index)
        → Q.SphereNull n (N.map-fiber n (λ v → previous ∘ v) (target-boundary c)
            (N.canonical-fiber n (target-boundary c)) .fst)
      target-null c = (λ x → k (Target.center (c , x))) ,
        (λ i s x → k (PO.push ((c , x) , s) i))

      pulled-null : (c : Index) → Q.SphereNull n (target-mapped-fiber previous c .fst)
      pulled-null c = Q.map-sphere-null n (λ v → v ∘ coefficient-map c)
        (N.map-fiber n (λ v → previous ∘ v) (target-boundary c)
          (N.canonical-fiber n (target-boundary c)) .fst) (target-null c)

      source-null : (c : Index) → Q.SphereNull n (source-mapped-fiber previous c .fst)
      source-null c = (λ x → k (induced (Source.center (c , x)))) ,
        (λ i s x → k (induced (PO.push ((c , x) , s) i)))

      bridged-null : (c : Index) → Q.SphereNull n (source-mapped-fiber previous c .fst)
      bridged-null c = pulled-null c .fst ,
        ((λ i → mapped-fiber-bridge previous c i .fst) ∙ pulled-null c .snd)

      raw-path-computation : (c : Index)
        → source-null c .snd
          ≡ (λ i s x → previous (fiber-bridge c i .fst s x)) ∙ pulled-null c .snd
      raw-path-computation c j i s x =
        (cong-∙∙ k (λ i → Target.include (attachment-square i ((c , x) , s)))
          (PO.push ((c , coefficient-map c x) , s)) refl
          ∙ sym (leftright
            (λ i → k (Target.include (attachment-square i ((c , x) , s))))
            (λ i → k (PO.push ((c , coefficient-map c x) , s) i)))) j i

      null-computation : (c : Index) → source-null c ≡ bridged-null c
      null-computation c = ΣPathP (refl ,
        (raw-path-computation c ∙ cong (λ p → p ∙ pulled-null c .snd)
          (sym (mapped-sphere-path previous c))))

      filler-computation : (c : Index)
        → Source.Target.restrict Y (k ∘ induced) .snd c
          ≡ pullback (Target.Target.restrict Y k) .snd c
      filler-computation c =
        cong (N.fiber-fill n (source-mapped previous c) (source-mapped-fiber previous c)) (null-computation c)
        ∙ sym (subst⁻Subst (CF.Filler (toNat n)) (mapped-boundary-path previous c)
          (N.fiber-fill n (source-mapped previous c) (source-mapped-fiber previous c) (bridged-null c)))
        ∙ cong (subst (CF.Filler (toNat n)) (sym (mapped-boundary-path previous c)))
          (DT.fiber-fill-dependent-path n (mapped-boundary-path previous c)
            (mapped-fiber-bridge previous c) (pulled-null c))
        ∙ cong (subst (CF.Filler (toNat n)) (sym (mapped-boundary-path previous c)))
          (sym (N.fiber-fill-natural n (λ v → v ∘ coefficient-map c)
            (Target.mapped-boundary Y previous c)
            (N.map-fiber n (λ v → previous ∘ v) (target-boundary c)
              (N.canonical-fiber n (target-boundary c))) (target-null c)))

    restrict-natural : (k : Target.Realize → Y)
      → Source.Target.restrict Y (k ∘ induced) ≡ pullback (Target.Target.restrict Y k)
    restrict-natural k = ΣPathP (refl , funExt (Restriction.filler-computation k))

  canonical-naturality : Source.Target.restrict Target.Realize induced
    ≡ TargetSpace.pullback Target.Realize Target.canonical-cocone
  canonical-naturality = TargetSpace.restrict-natural Target.Realize (idfun Target.Realize)

  induced-is-equivalence : isEquiv boundary-map → isEquiv base-map → isEquiv cell-map → isEquiv induced
  induced-is-equivalence boundary-equivalent base-equivalent cell-equivalent =
    subst isEquiv (funExt agrees)
      (PO.pushoutEquiv Source.attach Source.boundary Target.attach Target.boundary
        (boundary-map , boundary-equivalent) (base-map , base-equivalent) (cell-map , cell-equivalent)
        attachment-square boundary-square .snd)
    where
    agrees : (z : Source.Realize)
      → PO.pushoutEquiv Source.attach Source.boundary Target.attach Target.boundary
          (boundary-map , boundary-equivalent) (base-map , base-equivalent) (cell-map , cell-equivalent)
          attachment-square boundary-square .fst z ≡ induced z
    agrees (PO.inl x) = refl
    agrees (PO.inr x) = refl
    agrees (PO.push z i) = refl
