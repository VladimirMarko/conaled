{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.GraphColimits where

-- Small homotopy colimits of graph diagrams, presented by the genuine
-- coequalizer of their two incidence maps.  The graph has no supplied
-- higher-category composition coherences.  The library graph HIT is
-- identified with this small presentation, including its path generators.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
import Cubical.Data.Graph as G
import Cubical.HITs.Colimit.Base as C
import Orbifolds.Coequalizers as CQ
import Orbifolds.CoequalizerEquivalences as CE
import Orbifolds.TinyTypes as TT

record Diagram (ℓ : Level) : Type (ℓ-suc ℓ) where
  field
    Vertex Edge : Type ℓ
    source target : Edge → Vertex
    Object : Vertex → Type ℓ
    arrow : (e : Edge) → Object (source e) → Object (target e)

module Presentation {ℓ : Level} (D : Diagram ℓ) where
  open Diagram D

  Vertices : Type ℓ
  Vertices = Σ Vertex Object

  Edges : Type ℓ
  Edges = Σ[ e ∈ Edge ] Object (source e)

  left right : Edges → Vertices
  left (e , x) = source e , x
  right (e , x) = target e , arrow e x

  Colimit : Type ℓ
  Colimit = CQ.Coeq left right

  module Mapping {ℓy : Level} (Y : Type ℓy) where
    Cocone : Type (ℓ-max ℓ ℓy)
    Cocone = Σ[ leg ∈ ((v : Vertex) → Object v → Y) ]
      ((e : Edge) (x : Object (source e)) → leg (source e) x ≡ leg (target e) (arrow e x))

    restrict : (Colimit → Y) → Cocone
    restrict h = (λ v x → h (CQ.point (v , x))) , λ e x i → h (CQ.edge (e , x) i)

    glue : Cocone → Colimit → Y
    glue (leg , com) (CQ.point (v , x)) = leg v x
    glue (leg , com) (CQ.edge (e , x) i) = com e x i

    eta : (h : Colimit → Y) → glue (restrict h) ≡ h
    eta h i (CQ.point (v , x)) = h (CQ.point (v , x))
    eta h i (CQ.edge (e , x) j) = h (CQ.edge (e , x) j)

    universal : (Colimit → Y) ≃ Cocone
    universal = isoToEquiv (iso restrict glue (λ _ → refl) eta)

module Library {ℓ : Level} {I : G.Graph ℓ ℓ} (F : G.Diag ℓ I) where
  diagram : Diagram ℓ
  Diagram.Vertex diagram = G.Node I
  Diagram.Edge diagram = Σ[ v ∈ G.Node I ] Σ[ w ∈ G.Node I ] G.Edge I v w
  Diagram.source diagram = fst
  Diagram.target diagram e = e .snd .fst
  Diagram.Object diagram = G._$g_ F
  Diagram.arrow diagram e = G._<$g>_ F (e .snd .snd)

  module Small = Presentation diagram

  to-library : Small.Colimit → C.colim F
  to-library (CQ.point (v , x)) = C.colim-leg v x
  to-library (CQ.edge ((v , w , e) , x) i) = C.colim-com e (~ i) x

  from-library : C.colim F → Small.Colimit
  from-library (C.colim-leg v x) = CQ.point (v , x)
  from-library (C.colim-com {j = v} {k = w} e i x) = CQ.edge ((v , w , e) , x) (~ i)

  right-inverse : (z : C.colim F) → to-library (from-library z) ≡ z
  right-inverse (C.colim-leg v x) = refl
  right-inverse (C.colim-com e i x) = refl

  left-inverse : (z : Small.Colimit) → from-library (to-library z) ≡ z
  left-inverse (CQ.point (v , x)) = refl
  left-inverse (CQ.edge ((v , w , e) , x) i) = refl

  small≃library : Small.Colimit ≃ C.colim F
  small≃library = isoToEquiv (iso to-library from-library right-inverse left-inverse)

module Exponentiation {ℓ : Level} (T : Type ℓ) (D : Diagram ℓ) where
  open Diagram D
  module Original = Presentation D

  powered-diagram : Diagram ℓ
  Diagram.Vertex powered-diagram = Vertex
  Diagram.Edge powered-diagram = Edge
  Diagram.source powered-diagram = source
  Diagram.target powered-diagram = target
  Diagram.Object powered-diagram v = T → Object v
  Diagram.arrow powered-diagram e f = arrow e ∘ f

  module Powered = Presentation powered-diagram

  comparison : Powered.Colimit → (T → Original.Colimit)
  comparison (CQ.point (v , f)) t = CQ.point (v , f t)
  comparison (CQ.edge (e , f) i) t = CQ.edge (e , f t) i

  Preserved : Type ℓ
  Preserved = isEquiv comparison

  module NullVertices
      (null : (v : Vertex) → isEquiv (const :> (Object v → (T → Object v)))) where
    constant-vertices : Original.Vertices ≃ Powered.Vertices
    constant-vertices = Σ-cong-equiv-snd (λ v → const , null v)

    constant-edges : Original.Edges ≃ Powered.Edges
    constant-edges = Σ-cong-equiv-snd (λ e → const , null (source e))

    constant-colimit : Original.Colimit ≃ Powered.Colimit
    constant-colimit = CE.comparison-equivalence constant-edges constant-vertices
      Original.left Original.right Powered.left Powered.right (λ _ → refl) (λ _ → refl)

    comparison-constant : (z : Original.Colimit)
      → comparison (equivFun constant-colimit z) ≡ const z
    comparison-constant (CQ.point (v , x)) = refl
    comparison-constant (CQ.edge (e , x) i) j t = comparison
      (doubleCompPath-filler refl (CQ.edge (e , const x)) refl (~ j) i) t

    colimit-null : Preserved → isEquiv (const :> (Original.Colimit → (T → Original.Colimit)))
    colimit-null preserved = subst isEquiv (funExt comparison-constant)
      (compEquiv constant-colimit (comparison , preserved) .snd)

module Coproduct {ℓ : Level} (T : Type ℓ) (Ix : Type ℓ) (A : Ix → Type ℓ) where
  comparison : (Σ[ i ∈ Ix ] (T → A i)) → (T → Σ Ix A)
  comparison (i , f) t = i , f t

  preserves : isEquiv (const :> (Ix → (T → Ix))) → isEquiv comparison
  preserves null-index = compEquiv
    (Σ-cong-equiv (const , null-index) (λ _ → idEquiv _))
    (invEquiv (TT.Distribution.split-maps T Ix A null-index)) .snd
