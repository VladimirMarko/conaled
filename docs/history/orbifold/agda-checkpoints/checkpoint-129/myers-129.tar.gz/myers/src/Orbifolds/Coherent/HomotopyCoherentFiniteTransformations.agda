{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteTransformations where

-- Actual maps between finite coherent bar stages. Previous stages and
-- actual typed fillers are mapped recursively; the necessary boundary
-- equality and the resulting raw-family naturality are proved together.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.CoherentTensorNaturality as Tensors
import Orbifolds.Coherent.CoherentConeChains as CC
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
open import Orbifolds.Coherent.HomotopyCoherentActionData using (LawPair; _≤ᵈ_; same; lower; prefix-bound)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.HomotopyCoherentConeData as Data
import Orbifolds.Coherent.HomotopyCoherentConeCompatibility as Compatibility
import Orbifolds.Coherent.HomotopyCoherentConeStages as Stages
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.CubicalShellFillers as CF

module Action {ℓ : Level} {C : Category ℓ ℓ} (D D' : HC.ForCategory.Diagram C)
    (η : Transformations.ForCategory.Transformation C D D') (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Chains C
  module Maps = Transformations.ForCategory C
  open Maps.Transformation η
  open CC.Splits C
  open Tensors.Naturality E
  open StrictCubicalExtensionality E
  module Source = Data.Data C D
  module Target = Data.Data C D'
  module SourceStages = Stages.Construction C D E
  module TargetStages = Stages.Construction C D' E
  module SourceFinite = Finite.Finite C D E
  module TargetFinite = Finite.Finite C D' E
  module Shell = Shells.Action E
  module Filler = Fillers.Action E

  Related : (n : Dim) {P Q : Type ℓ}
    → Source.Families n P → Target.Families n Q → P → Q → SSet ℓ
  Related ozero F G s t = (y : Obj) (c : Chain ozero y)
    → outer (component y (F s y c)) ≡ˢ outer (G t y c)
  Related (osuc n) F G s t = LawPair (Related n (F .fst) (G .fst) s t)
    ((y : Obj) (c : Chain (osuc n) y)
      → outer (map-cube (osuc n) (component y) (F .snd s y c)) ≡ˢ outer (G .snd t y c))

  top-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → (y : Obj) (c : Chain n y)
    → outer (map-cube n (component y) (Source.top n F s y c))
      ≡ˢ outer (Target.top n G t y c)
  top-related ozero F G s t r = r
  top-related (osuc n) F G s t r = LawPair.current r

  reindex-related : (n : Dim) {P Q P' Q' : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (f : P' → P) (g : Q' → Q)
    (s : P') (t : Q') → Related n F G (f s) (g t)
    → Related n (Source.reindex n F f) (Target.reindex n G g) s t
  reindex-related ozero F G f g s t r = r
  LawPair.earlier (reindex-related (osuc n) F G f g s t r) =
    reindex-related n (F .fst) (G .fst) f g s t (LawPair.earlier r)
  LawPair.current (reindex-related (osuc n) F G f g s t r) = LawPair.current r

  at-related : {m n : Dim} {P Q : Type ℓ} (bound : m ≤ᵈ n)
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → (y : Obj) (c : Chain m y)
    → outer (map-cube m (component y) (Source.at bound F s y c))
      ≡ˢ outer (Target.at bound G t y c)
  at-related {m} same F G s t r = top-related m F G s t r
  at-related (lower bound) F G s t r =
    at-related bound (F .fst) (G .fst) s t (LawPair.earlier r)

  one-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
    → outer (map-cube n (component y) (Source.one-face n F s p c))
      ≡ˢ outer (Target.one-face n G t p c)
  one-related n F G s t r p {y} c = strict-sym (tensor-natural n p
    (λ _ → t) (component (split-vertex n p c)) (component y)
    (HC.ForCategory.Diagram.action D (suffix-degree n p) (split-suffix n p c))
    (λ s → Source.at (prefix-bound n p) F s (split-vertex n p c) (split-prefix n p c))
    (HC.ForCategory.Diagram.action D' (suffix-degree n p) (split-suffix n p c))
    (λ t → Target.at (prefix-bound n p) G t (split-vertex n p c) (split-prefix n p c)) s
    (strict-sym (at-related (prefix-bound n p) F G s t r
      (split-vertex n p c) (split-prefix n p c)))
    (λ b → strict-sym (naturality (suffix-degree n p) (split-suffix n p c) b)))

  faces-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → {y : Obj} (c : Chain (osuc n) y)
    → (p : Position (osuc n)) (e : Endpoint)
    → outer (map-cube n (component y) (Source.bar-faces n F s c p e))
      ≡ˢ outer (Target.bar-faces n G t c p e)
  faces-related n F G s t r {y} c p low = top-related n F G s t r y (face n p c)
  faces-related n F G s t r c p high = one-related n F G s t r p c

  boundary-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q)
    (coherent-F : Source.Coherent n F) (coherent-G : Target.Coherent n G)
    (s : P) (t : Q) → Related n F G s t → (y : Obj) (c : Chain (osuc n) y)
    → outer (Shell.map-shell (osuc n) (component y)
        (SourceStages.Step.boundary-data n P F coherent-F s (y , c)))
      ≡ˢ outer (TargetStages.Step.boundary-data n Q G coherent-G t (y , c))
  boundary-related n F G coherent-F coherent-G s t r y c =
    Shell.assemble-natural-facewise (osuc n) (component y)
      (Source.bar-faces n F s c)
      (Compatibility.Compatibility.bar-compatible C D E n F coherent-F s c)
      (Target.bar-faces n G t c)
      (Compatibility.Compatibility.bar-compatible C D' E n G coherent-G t c)
      (faces-related n F G s t r c)

  mutual
    stage-map : (n : Dim) → SourceFinite.Carrier n → TargetFinite.Carrier n
    stage-map ozero s y = component y (s y)
    stage-map (osuc n) s = stage-map n (s .fst) , λ { (y , c) →
      cast-filler (osuc n)
        (boundary-related n (SourceFinite.families n) (TargetFinite.families n)
          (SourceFinite.coherent n) (TargetFinite.coherent n)
          (s .fst) (stage-map n (s .fst)) (stage-related n (s .fst)) y c)
        (Filler.map-filler (osuc n) (component y)
          (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))) }

    stage-related : (n : Dim) (s : SourceFinite.Carrier n)
      → Related n (SourceFinite.families n) (TargetFinite.families n) s (stage-map n s)
    stage-related ozero s y c = reflˢ
    LawPair.earlier (stage-related (osuc n) s) = reindex-related n
      (SourceFinite.families n) (TargetFinite.families n)
      (SourceFinite.transition n) (TargetFinite.transition n) s (stage-map (osuc n) s)
      (stage-related n (s .fst))
    LawPair.current (stage-related (osuc n) s) y c = strict-sym (strict-trans
      (cast-forget (osuc n)
        (boundary-related n (SourceFinite.families n) (TargetFinite.families n)
          (SourceFinite.coherent n) (TargetFinite.coherent n)
          (s .fst) (stage-map n (s .fst)) (stage-related n (s .fst)) y c)
        (Filler.map-filler (osuc n) (component y)
          (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))))
      (Filler.map-filler-forget (osuc n) (component y)
        (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))))

  transition-natural : (n : Dim) (s : SourceFinite.Carrier (osuc n))
    → outer (TargetFinite.transition n (stage-map (osuc n) s))
      ≡ˢ outer (stage-map n (SourceFinite.transition n s))
  transition-natural n s = reflˢ

  stage-top-natural : (n : Dim) (s : SourceFinite.Carrier n) (y : Obj) (c : Chain n y)
    → outer (map-cube n (component y) (Source.top n (SourceFinite.families n) s y c))
      ≡ˢ outer (Target.top n (TargetFinite.families n) (stage-map n s) y c)
  stage-top-natural n s = top-related n (SourceFinite.families n) (TargetFinite.families n)
    s (stage-map n s) (stage-related n s)

  stage-boundary-natural : (n : Dim) (s : SourceFinite.Carrier n) (y : Obj)
    (c : Chain (osuc n) y)
    → outer (Shell.map-shell (osuc n) (component y) (SourceFinite.At.boundary-data n s (y , c)))
      ≡ˢ outer (TargetFinite.At.boundary-data n (stage-map n s) (y , c))
  stage-boundary-natural n s y c = boundary-related n
    (SourceFinite.families n) (TargetFinite.families n)
    (SourceFinite.coherent n) (TargetFinite.coherent n)
    s (stage-map n s) (stage-related n s) y c
