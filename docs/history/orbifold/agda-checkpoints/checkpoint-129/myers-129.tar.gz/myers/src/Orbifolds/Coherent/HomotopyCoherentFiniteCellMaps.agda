{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellMaps where

-- A finite canonical-cocone triangle determines a literal map of the
-- next sphere-cell pushouts. The entire next typed-cocone square is
-- proved, retaining the previous triangle as a dependent base path.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
open import Orbifolds.Coherent.StrictCubicalFillerPathTransport
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as FiniteRestriction
import Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionNaturality as Naturality
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.NaturalQuotedCellInterface as CellMaps
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as AttachmentInterface
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.StrictCubicalFillerCastCoherence as Casts
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module RD = Represented.Induction C D E F using (module Represented)
  module RG = Represented.Induction C G E F using (module Represented)
  module CD = Cocones.Functoriality C D E F using (Cocone; postcompose; postcompose-compose)
  module CG = Cocones.Functoriality C G E F using (Cocone; postcompose; postcompose-compose)
  module SD = Comparison.Comparison C D E F n source
    using (Index; Coefficient; actual-boundary; original-boundary; boundary-natural; compare)
  module TG = Comparison.Comparison C G E F n target
    using (Index; Coefficient; actual-boundary; original-boundary; boundary-natural; compare)
  module R (Y : Type ℓ) where
    finite-restriction : (m : Dim) → CG.Cocone Y m → CD.Cocone Y m
    finite-restriction m = FiniteRestriction.Restriction.finite-restriction C D G α E F Y m

  module N where
    square : (m : Dim) {Y Z : Type ℓ} (h : Y → Z) (s : CG.Cocone Y m)
      → outer (CD.postcompose m h (R.finite-restriction Y m s))
        ≡ˢ outer (R.finite-restriction Z m (CG.postcompose m h s))
    square = Naturality.Naturality.square C D G α E F
  module Maps = Transformations.ForCategory C using (module Transformation)
  module α = Maps.Transformation α using (component)
  module S = Shells.Action E using (map-shell)
  module FM = Fillers.Action E using (map-filler)
  module Cast = Casts.Coherence E using (paste-map-cast)

  A B : Type ℓ
  A = RD.Represented.Space source
  B = RG.Represented.Space target

  uD : CD.Cocone A n
  uD = RD.Represented.universal-cocone source

  uG : CG.Cocone B n
  uG = RG.Represented.universal-cocone target

  restriction-boundary : (Y : Type ℓ) (s : CG.Cocone Y n) (c : SD.Index)
    → outer (S.map-shell (osuc n) (λ v → v ∘ α.component (c .fst))
        (TG.actual-boundary Y s c))
      ≡ˢ outer (SD.actual-boundary Y (R.finite-restriction Y n s) c)
  restriction-boundary Y s c = FiniteRestriction.Restriction.source-boundary-natural C D G α E F Y n s c

  boundary-path : (c : SD.Index)
    → S.map-shell (osuc n) (λ v → f ∘ v) (SD.original-boundary c)
      ≡ S.map-shell (osuc n) (λ v → v ∘ α.component (c .fst)) (TG.original-boundary c)
  boundary-path c = strict-end-path {A = CS.Shell (toNat (osuc n)) (SD.Coefficient c → B)}
    (λ i → SD.actual-boundary B (triangle i) c)
    (strict-sym (SD.boundary-natural B f c))
    (strict-sym (restriction-boundary B uG c))

  boundary-path-value : (c : SD.Index) (i : I)
    → outer (boundary-path c i) ≡ˢ outer (SD.actual-boundary B (triangle i) c)
  boundary-path-value c i = strict-end-path-value
    {A = CS.Shell (toNat (osuc n)) (SD.Coefficient c → B)}
    (λ i → SD.actual-boundary B (triangle i) c)
    (strict-sym (SD.boundary-natural B f c))
    (strict-sym (restriction-boundary B uG c)) i

  module TargetCell = AttachmentInterface.Attachment E (osuc n) B TG.Index TG.Coefficient TG.original-boundary

  module Cell = CellMaps.Map E (osuc n) A B SD.Index SD.Coefficient TG.Coefficient
    SD.original-boundary TG.original-boundary f (λ c → α.component (c .fst)) boundary-path

  module At (Y : Type ℓ) where
    module CellY = Cell.TargetSpace Y using (pullback; mapped-boundary-path; mapped-boundary-value)

    lower-path : (h : B → Y)
      → CD.postcompose n (h ∘ f) uD
        ≡ R.finite-restriction Y n (CG.postcompose n h uG)
    lower-path h = strict-end-path {A = CD.Cocone Y n} (λ i → CD.postcompose n h (triangle i))
      (CD.postcompose-compose n f h uD) (N.square n h uG)

    lower-path-value : (h : B → Y) (i : I)
      → outer (lower-path h i) ≡ˢ outer (CD.postcompose n h (triangle i))
    lower-path-value h i = strict-end-path-value {A = CD.Cocone Y n} (λ i → CD.postcompose n h (triangle i))
      (CD.postcompose-compose n f h uD) (N.square n h uG) i

    boundary-agreement : (h : B → Y) (c : SD.Index) (i : I)
      → outer (CellY.mapped-boundary-path h c i)
        ≡ˢ outer (SD.actual-boundary Y (lower-path h i) c)
    boundary-agreement h c i = strict-trans
      {A = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
      (CellY.mapped-boundary-value h c i)
      (strict-trans
        {A = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
        (strict-cong
          {A = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → B))}
          {B = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
          (λ b → outer (S.map-shell (osuc n)
            {X = SD.Coefficient c → B} {Y = SD.Coefficient c → Y}
            (λ v → h ∘ v) (inner b)))
          (boundary-path-value c i))
        (strict-trans
          {A = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
          (Comparison.Comparison.actual-map-boundary C D E F n source {Y = B} {Z = Y} h (triangle i) c)
          (strict-cong
            {A = Outer (CD.Cocone Y n)}
            {B = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
            (λ s → outer (SD.actual-boundary Y (inner s) c))
            (strict-sym (lower-path-value h i)))))

    raw-filler-path : (h : B → Y)
      (fs : (c : TG.Index) → CF.Filler (toNat (osuc n)) (TargetCell.mapped-boundary Y h c))
      (c : SD.Index)
      → PathP (λ i → CF.Filler (toNat (osuc n)) (SD.actual-boundary Y (lower-path h i) c))
          (cast-filler (osuc n) {X = SD.Coefficient c → Y} (boundary-agreement h c i0)
            (CellY.pullback (h , fs) .snd c))
          (cast-filler (osuc n) {X = SD.Coefficient c → Y} (boundary-agreement h c i1)
            (FM.map-filler (osuc n)
              {X = TG.Coefficient c → Y} {Y = SD.Coefficient c → Y}
              (λ v → v ∘ α.component (c .fst))
              (TargetCell.mapped-boundary Y h c) (fs c)))
    raw-filler-path h fs c = path-along-strict-shells (osuc n) {X = SD.Coefficient c → Y}
      (λ i → CellY.mapped-boundary-path h c i)
      (λ i → SD.actual-boundary Y (lower-path h i) c)
      (boundary-agreement h c)
      (FM.map-filler (osuc n)
        {X = TG.Coefficient c → Y} {Y = SD.Coefficient c → Y}
        (λ v → v ∘ α.component (c .fst))
        (TargetCell.mapped-boundary Y h c) (fs c))

    filler-path : (h : B → Y)
      (fs : (c : TG.Index) → CF.Filler (toNat (osuc n)) (TargetCell.mapped-boundary Y h c))
      (c : SD.Index)
      → PathP (λ i → CF.Filler (toNat (osuc n)) (SD.actual-boundary Y (lower-path h i) c))
          (SD.compare Y (CellY.pullback (h , fs)) .snd c)
          (R.finite-restriction Y (osuc n) (TG.compare Y (h , fs)) .snd c)
    filler-path h fs c = strict-end-dependent-path
      {A = λ i → CF.Filler (toNat (osuc n)) (SD.actual-boundary Y (lower-path h i) c)}
      (λ i → raw-filler-path h fs c i)
      {x = SD.compare Y (CellY.pullback (h , fs)) .snd c}
      {y = R.finite-restriction Y (osuc n) (TG.compare Y (h , fs)) .snd c}
      (strict-cong
        {A = outer (Cell.Source.mapped-boundary Y (h ∘ f) c)
          ≡ˢ outer (SD.actual-boundary Y (CD.postcompose n (h ∘ f) uD) c)}
        {B = Outer (CF.Filler (toNat (osuc n))
          (SD.actual-boundary Y (CD.postcompose n (h ∘ f) uD) c))}
        (λ e → outer (cast-filler (osuc n) {X = SD.Coefficient c → Y}
          e (CellY.pullback (h , fs) .snd c)))
        (strict-uip {A = Outer (CS.Shell (toNat (osuc n)) (SD.Coefficient c → Y))}
          (boundary-agreement h c i0) (SD.boundary-natural Y (h ∘ f) c)))
      (strict-sym (Cast.paste-map-cast (osuc n)
        {X = TG.Coefficient c → Y} {Y = SD.Coefficient c → Y}
        (λ v → v ∘ α.component (c .fst))
        {a = TargetCell.mapped-boundary Y h c}
        {b = TG.actual-boundary Y (CG.postcompose n h uG) c}
        {c = SD.actual-boundary Y (R.finite-restriction Y n (CG.postcompose n h uG)) c}
        {d = SD.actual-boundary Y (R.finite-restriction Y n (CG.postcompose n h uG)) c}
        (TG.boundary-natural Y h c)
        (restriction-boundary Y (CG.postcompose n h uG) c) reflˢ
        (boundary-agreement h c i1) (fs c)))

    comparison-square : (s : TargetCell.Cocone Y)
      → SD.compare Y (CellY.pullback s)
        ≡ R.finite-restriction Y (osuc n) (TG.compare Y s)
    comparison-square (h , fs) i = lower-path h i , λ c → filler-path h fs c i
