{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Theorem 5.3.5: an etale atlas by microlinear models is microlinear.
-- All uses of etale below mean the actual modal-unit pullback condition.
module Orbifolds.EtaleAtlas where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Functions.Surjection
open import Cubical.Modalities.Modality
import Orbifolds.ModalEtaleSums as ES
import Orbifolds.MicrolinearSums as MS
import Orbifolds.MicrolinearModal as MM
import Orbifolds.Microlinearity as ML

module Theory {ℓ : Level} (M : Modality ℓ)
  {ℓi : Level} {Index : Type ℓi}
  (test : Index → ML.TestSquare ℓ)
  (connected-tests : (t : Index) → MM.Theory.ConnectedSquare M (test t)) where

  open ES.Theory M
  module Micro = ML.Theory test
  module Descent = MM.Theory.Family M test connected-tests
  module Sums = MS.Theory.ForTests M test connected-tests

  module Atlas (A Ix X : Type ℓ)
    (modalA : isModal A) (modalIx : isModal Ix)
    (U : A → Type ℓ) (V : Ix → Type ℓ) (k : A → Ix)
    (chart : (a : A) → U a → V (k a))
    (include : (a : A) → U a → X)
    (chart-etale : (a : A) → Etale (chart a))
    (include-etale : (a : A) → Etale (include a))
    (jointly-surjective : isSurjection (λ (z : Σ A U) → include (fst z) (snd z)))
    (models-microlinear : (i : Ix) → Micro.Microlinear (V i)) where

    module Charts = Indexed A Ix U V k chart
    module Cover = CommonTarget A X U include

    models-total-microlinear : Micro.Microlinear (Σ Ix V)
    models-total-microlinear = Sums.microlinear-Σ modalIx V models-microlinear

    charts-total-etale : Etale Charts.sum-map
    charts-total-etale = Charts.sum-etale modalA modalIx chart-etale

    cover-total-etale : Etale Cover.total-map
    cover-total-etale = Cover.total-etale modalA include-etale

    domain-microlinear : Micro.Microlinear (Σ A U)
    domain-microlinear = Descent.microlinear-ascends Charts.sum-map
      charts-total-etale models-total-microlinear

    atlas-microlinear : Micro.Microlinear X
    atlas-microlinear = Descent.microlinear-descends Cover.total-map
      jointly-surjective cover-total-etale domain-microlinear
