{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LocalHomeomorphisms where

-- Standard chosen local homeomorphism charts for a specified map.
-- The fields concern only its actual restriction on open patches.
-- Source injectivity, continuous local sections, and global continuity
-- are derived; no finite branch or properness conclusion is a field.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; Included; intersection
  ; OpenFragment; IsOpen; open-local )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
open import Orbifolds.Intensional.FiniteSeparation using
  ( SourceNeighborhood; ChosenSourceNeighborhoods )
open import Orbifolds.Intensional.OpenBranchDomains using
  ( LocalContinuousSection; ChosenLocalContinuousSections; PartialContinuous )
open import Orbifolds.Intensional.OpenSubspaces using
  ( Carrier; openSubspace; inclusion-continuous; compose-continuous
  ; Homeomorphism; underlying; forward-continuous; backward-continuous )

private variable ℓ : Level

record LocalHomeomorphismChart {A X : Set ℓ}
    (OA : OpenFragment A) (OX : OpenFragment X) (s : A → X) (a : A)
    : Set (Code ℓ) where
  field
    source-patch : Subset A
    target-patch : Subset X
    source-patch-open : IsOpen OA source-patch
    target-patch-open : IsOpen OX target-patch
    source-center : member source-patch a
    restriction-lands : (u : Carrier source-patch) → member target-patch (s (fst u))
    local-inverse : Carrier target-patch → Carrier source-patch
    inverse-right-law : (v : Carrier target-patch)
      → (s (fst (local-inverse v)) , restriction-lands (local-inverse v)) ≡ v
    inverse-left-law : (u : Carrier source-patch)
      → local-inverse (s (fst u) , restriction-lands u) ≡ u
    restriction-continuous :
      Continuous (openSubspace OA source-patch source-patch-open)
        (openSubspace OX target-patch target-patch-open)
        (λ u → s (fst u) , restriction-lands u)
    local-inverse-continuous :
      Continuous (openSubspace OX target-patch target-patch-open)
        (openSubspace OA source-patch source-patch-open) local-inverse

ChosenLocalHomeomorphisms : {A X : Set ℓ}
  → OpenFragment A → OpenFragment X → (A → X) → Set (Code ℓ)
ChosenLocalHomeomorphisms {A = A} OA OX s =
  (a : A) → LocalHomeomorphismChart OA OX s a

module Chart {ℓ : Level} {A X : Set ℓ}
    (OA : OpenFragment A) (OX : OpenFragment X) (s : A → X) (a : A)
    (chart : LocalHomeomorphismChart OA OX s a) where

  open LocalHomeomorphismChart chart

  source-topology : OpenFragment (Carrier source-patch)
  source-topology = openSubspace OA source-patch source-patch-open

  target-topology : OpenFragment (Carrier target-patch)
  target-topology = openSubspace OX target-patch target-patch-open

  restriction : Carrier source-patch → Carrier target-patch
  restriction u = s (fst u) , restriction-lands u

  restriction-homeomorphism : Homeomorphism source-topology target-topology
  underlying restriction-homeomorphism =
    equiv restriction local-inverse inverse-right-law inverse-left-law
  forward-continuous restriction-homeomorphism = restriction-continuous
  backward-continuous restriction-homeomorphism = local-inverse-continuous

  restriction-injective : (b c : A)
    → member source-patch b → member source-patch c → s b ≡ s c → b ≡ c
  restriction-injective b c in-b in-c equal = cong fst
    (sym (inverse-left-law (b , in-b))
      ∙ cong local-inverse (Σ-path-prop (member-prop target-patch) equal)
      ∙ inverse-left-law (c , in-c))

  source-neighborhood : SourceNeighborhood OA s a
  SourceNeighborhood.neighborhood source-neighborhood = source-patch
  SourceNeighborhood.neighborhood-open source-neighborhood = source-patch-open
  SourceNeighborhood.neighborhood-center source-neighborhood = source-center
  SourceNeighborhood.injective-source source-neighborhood = restriction-injective

  target-center : member target-patch (s a)
  target-center = restriction-lands (a , source-center)

  local-section : (x : X) → member target-patch x → A
  local-section x d = fst (local-inverse (x , d))

  section-continuous : PartialContinuous OX OA target-patch local-section
  section-continuous = compose-continuous target-topology source-topology OA
    local-inverse fst local-inverse-continuous
    (inclusion-continuous OA source-patch source-patch-open)

  section-data : LocalContinuousSection OA OX s a
  LocalContinuousSection.neighborhood section-data = target-patch
  LocalContinuousSection.neighborhood-open section-data = target-patch-open
  LocalContinuousSection.center section-data = target-center
  LocalContinuousSection.local-section section-data = local-section
  LocalContinuousSection.source-section section-data x d =
    cong fst (inverse-right-law (x , d))
  LocalContinuousSection.section-at-center section-data =
    cong fst (inverse-left-law (a , source-center))
  LocalContinuousSection.section-continuous section-data = section-continuous

  -- The local forward preimage is the actual ambient intersection.
  -- Its openness is derived using continuity of the restricted map and
  -- the inclusion of the open target patch into the target space.
  local-preimage-open : (P : Subset X) → IsOpen OX P
    → IsOpen OA (intersection source-patch (preimage s P))
  local-preimage-open P open-P = restriction-continuous (preimage fst P)
    (inclusion-continuous OX target-patch target-patch-open P open-P)

local-homeomorphism-source-neighborhoods : {A X : Set ℓ}
  → (OA : OpenFragment A) (OX : OpenFragment X) (s : A → X)
  → ChosenLocalHomeomorphisms OA OX s → ChosenSourceNeighborhoods OA s
local-homeomorphism-source-neighborhoods OA OX s charts a =
  Chart.source-neighborhood OA OX s a (charts a)

local-homeomorphism-sections : {A X : Set ℓ}
  → (OA : OpenFragment A) (OX : OpenFragment X) (s : A → X)
  → ChosenLocalHomeomorphisms OA OX s → ChosenLocalContinuousSections OA OX s
local-homeomorphism-sections OA OX s charts a =
  Chart.section-data OA OX s a (charts a)

local-homeomorphism-continuous : {A X : Set ℓ}
  → (OA : OpenFragment A) (OX : OpenFragment X) (s : A → X)
  → ChosenLocalHomeomorphisms OA OX s → Continuous OA OX s
local-homeomorphism-continuous OA OX s charts P open-P =
  open-local OA (preimage s P)
    (λ a in-P →
      let chart = charts a
          U = LocalHomeomorphismChart.source-patch chart
      in intersection U (preimage s P) ,
        (Chart.local-preimage-open OA OX s a chart P open-P ,
          ((LocalHomeomorphismChart.source-center chart , in-P) ,
            (λ b witness → snd witness))))
