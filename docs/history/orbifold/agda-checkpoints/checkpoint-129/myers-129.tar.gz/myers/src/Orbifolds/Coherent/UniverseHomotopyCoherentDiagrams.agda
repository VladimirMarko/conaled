{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.UniverseHomotopyCoherentDiagrams where

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face)
open import Orbifolds.Coherent.UniverseCoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.UniverseCoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)

module ForCategory {ℓo ℓh : Level} (C : Category ℓo ℓh) where
  open Category C
  open Chains.Arrows C

  record Diagram (ℓv : Level) : SSet (ℓ-suc (ℓ-max ℓo (ℓ-max ℓh ℓv))) where
    field
      Value : Obj → Type ℓv
      action : (n : Dim) {x y : Obj} → Chain n x y → Value x → Cube n (Value y)
      zero-face : (n : Dim) (p : Position (osuc n)) {x y : Obj}
        (c : Chain (osuc n) x y) (a : Value x)
        → outer (coordinate-face n p i0 (action (osuc n) c a))
          ≡ˢ outer (action n (face n p c) a)
      one-face : (n : Dim) (p : Position (osuc n)) {x y : Obj}
        (c : Chain (osuc n) x y) (a : Value x)
        → outer (coordinate-face n p i1 (action (osuc n) c a))
          ≡ˢ outer (tensor-action n p
            (action (suffix-degree n p) (split-suffix n p c))
            (action (prefix-degree n p) (split-prefix n p c)) a)
      unit : (x : Obj) → action ozero (lift (ident x)) ≡ (λ a → a)

    unit-is-equivalence : (x : Obj) → isEquiv (action ozero (lift (ident x)))
    unit-is-equivalence x = subst isEquiv (sym (unit x)) (idEquiv (Value x) .snd)
