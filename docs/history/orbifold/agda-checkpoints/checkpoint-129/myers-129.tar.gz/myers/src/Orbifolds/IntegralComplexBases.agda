{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralComplexBases where

-- A metrically discrete embedded additive copy of Z² in C is merely
-- the scalar multiple of an actual standard upper-half-plane lattice.
-- The real-spanning and orientation steps are derived in imported
-- theorems.  The conclusion is an equivalence of the literal fibers.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ)
open import Cubical.Data.Sum using (inl; inr)
open import Cubical.Functions.Embedding
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexPairs as CP
import Orbifolds.ComplexIntegerLinearMaps as IL
import Orbifolds.IntegerPairMatrices as IP
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.SpecialLinearTwo as SL
import Orbifolds.StandardComplexLattice as ST
import Orbifolds.UpperHalfPlane as UH
import Orbifolds.RealLatticeSpanning as RS
import Orbifolds.ComplexBasisNormalization as BN

swap-coordinates : (ℤ × ℤ) ≃ (ℤ × ℤ)
swap-coordinates = isoToEquiv (iso (λ v → v .snd , v .fst)
  (λ v → v .snd , v .fst) (λ _ → refl) (λ _ → refl))

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  module C = CP.Ring R
  module Linear = IL.Ring R
  module I = IC.Ring R
  module Standard = ST.Geometry R kock order compatibility
  module H = UH.Geometry R kock order compatibility
  module Spanning = RS.Geometry R kock order compatibility
  module Normalize = BN.Geometry R kock order compatibility
  open C using (Complex; real; _+c_; _*c_)

  abstract
    distribute-scalar : (λc τ : Complex) (m n : R .fst)
      → λc *c (real m *c τ +c real n)
        ≡ (real m *c (λc *c τ)) +c (real n *c λc)
    distribute-scalar λc τ m n = cong₂ _,_ (solve! R) (solve! R)

  module EmbeddedMap (f : GroupHom IP.Pairs Linear.Additive)
      (embedded : {v w : ℤ × ℤ} → f .fst v ≡ f .fst w → v ≡ w) where
    u v : Complex
    u = f .fst SL.Integers.basis₁
    v = f .fst SL.Integers.basis₂

    linear-equation : (z : ℤ × ℤ) → f .fst z ≡ Spanning.combination u v z
    linear-equation = Linear.homomorphism-coordinate-linear f

    real-embedded : Spanning.Embedded u v
    real-embedded {z} {w} equal = embedded
      (linear-equation z ∙ equal ∙ sym (linear-equation w))

    image-isProp : (z : Complex) → isProp (fiber (f .fst) z)
    image-isProp = isEmbedding→hasPropFibers (injEmbedding C.complex-isSet embedded)

    StandardPresentation : Type ℓ
    StandardPresentation = Σ[ τ ∈ H.UpperHalfPlane ]
      Σ[ scalar ∈ Complex ] Σ[ inverse ∈ Complex ]
        (scalar *c inverse ≡ C.one) ×
        ((z : Complex) → Standard.Member τ z ≃ fiber (f .fst) (scalar *c z))

    module Matched (τ : H.UpperHalfPlane) (scalar inverse : Complex)
        (unit : scalar *c inverse ≡ C.one)
        (coefficients : (ℤ × ℤ) ≃ (ℤ × ℤ))
        (matches : (w : ℤ × ℤ)
          → scalar *c Standard.standard τ w ≡ f .fst (coefficients .fst w)) where
      forward : (z : Complex) → Standard.Member τ z → fiber (f .fst) (scalar *c z)
      forward z (w , equality) = coefficients .fst w ,
        sym (matches w) ∙ cong (scalar *c_) equality

      backward : (z : Complex) → fiber (f .fst) (scalar *c z) → Standard.Member τ z
      backward z (w , equality) = invEq coefficients w ,
        C.multiply-cancel-unit scalar inverse unit
          (matches (invEq coefficients w) ∙ cong (f .fst) (secEq coefficients w) ∙ equality)

      equivalence : (z : Complex) → Standard.Member τ z ≃ fiber (f .fst) (scalar *c z)
      equivalence z = propBiimpl→Equiv (Standard.member-isProp τ z)
        (image-isProp (scalar *c z)) (forward z) (backward z)

    from-normalization : Normalize.NormalizedBasis u v → StandardPresentation
    from-normalization (τ , scalar , inverse , unit , inl (first , second)) =
      τ , scalar , inverse , unit , Comparison.equivalence
      where
      matches : (w : ℤ × ℤ) → scalar *c Standard.standard τ w ≡ f .fst w
      matches (m , n) = distribute-scalar scalar (τ .fst) (I.integer m) (I.integer n)
        ∙ cong₂ (λ a b → (real (I.integer m) *c a) +c (real (I.integer n) *c b)) first second
        ∙ sym (Linear.homomorphism-linear f (m , n))
      module Comparison = Matched τ scalar inverse unit (idEquiv (ℤ × ℤ)) matches
    from-normalization (τ , scalar , inverse , unit , inr (first , second)) =
      τ , scalar , inverse , unit , Comparison.equivalence
      where
      matches : (w : ℤ × ℤ) → scalar *c Standard.standard τ w ≡ f .fst (w .snd , w .fst)
      matches (m , n) = distribute-scalar scalar (τ .fst) (I.integer m) (I.integer n)
        ∙ cong₂ (λ a b → (real (I.integer m) *c a) +c (real (I.integer n) *c b)) first second
        ∙ C.add-commutative (real (I.integer m) *c v) (real (I.integer n) *c u)
        ∙ sym (Linear.homomorphism-linear f (n , m))
      module Comparison = Matched τ scalar inverse unit swap-coordinates matches

    Isolated : (ε : R .fst) → Type ℓ
    Isolated ε = (z : ℤ × ℤ) → C.norm (f .fst z) < ε → f .fst z ≡ C.zero

    presentation : (ε : R .fst) → 0r < ε → Isolated ε → PT.∥ StandardPresentation ∥₁
    presentation ε positive isolated = PT.map from-normalization
      (Normalize.normalize u v
        (Spanning.lattice-determinant-invertible u v real-embedded ε positive
          (λ z below → sym (linear-equation z)
            ∙ isolated z (subst (λ w → C.norm w < ε) (sym (linear-equation z)) below))))
