{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalCubicalShellRepresentation where

-- A natural sphere representation for the actual finite coordinate
-- shell action. Quotation is constructed first from sphere constructors;
-- its equivalence is proved by finite induction. Evaluation naturality
-- then follows from quotation naturality and actual inverse laws.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
import Cubical.HITs.Susp as S
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
import Orbifolds.Coherent.StrictCubicalShellMaps as Direct
import Orbifolds.Coherent.StrictCubicalShellQuotation as Q
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellSpheres as SS

cast-path-equivalence : ∀ {ℓ} {A : Type ℓ} {x y x' y' : A}
  (px : outer x ≡ˢ outer x') (py : outer y ≡ˢ outer y')
  → (x ≡ y) ≃ (x' ≡ y')
cast-path-equivalence reflˢ reflˢ = idEquiv _

cast-path-computation : ∀ {ℓ} {A : Type ℓ} {x y x' y' : A}
  (px : outer x ≡ˢ outer x') (py : outer y ≡ˢ outer y') (p : x ≡ y)
  → cast-path-equivalence px py .fst p ≡ strict-end-path (λ i → p i) px py
cast-path-computation reflˢ reflˢ p = refl

module Representation {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module Quote = Q.Quotation E
  module Map = Direct.Action E
  open Quote using (quote-shell; quote-constant; quote-natural) public

  constant-equivalence : (n : Dim) (X : Type ℓ) → X ≃ Cube n X
  constant-equivalence n X = isoToEquiv
    (iso (CS.constant-cube (toNat n)) (CS.origin (toNat n))
      (CS.contract-cube (toNat n)) (CS.origin-constant (toNat n)))

  mutual
    quote-isEquiv : (n : Dim) (X : Type ℓ) → isEquiv (quote-shell n {X})
    quote-isEquiv ozero X = isoToIsEquiv
      (iso (quote-shell ozero) (λ _ ()) (λ _ → refl) (λ f → funExt (λ ())))
    quote-isEquiv (osuc n) X = subst isEquiv (funExt comparison)
      (successor-equivalence .snd)
      where
      path-equivalence : (ends : X × X)
        → ((λ (_ : SS.SphereBoundary (toNat n)) → ends .fst)
          ≡ (λ _ → ends .snd))
          ≃ (CS.restriction (toNat n) (CS.constant-cube (toNat n) (ends .fst))
            ≡ CS.restriction (toNat n) (CS.constant-cube (toNat n) (ends .snd)))
      path-equivalence ends = congEquiv
        {x = (λ _ → ends .fst)} {y = (λ _ → ends .snd)}
        (quote-shell n , quote-isEquiv n X) ∙ₑ
        cast-path-equivalence (quote-constant n (ends .fst)) (quote-constant n (ends .snd))

      successor-equivalence : (SS.SphereBoundary (toNat (osuc n)) → X)
        ≃ CS.Shell (toNat (osuc n)) X
      successor-equivalence = invEquiv (SS.SuspensionMapping.universal
          (SS.SphereBoundary (toNat n)) X)
        ∙ₑ Σ-cong-equiv (≃-× (constant-equivalence n X) (constant-equivalence n X))
          path-equivalence

      comparison : (h : SS.SphereBoundary (toNat (osuc n)) → X)
        → successor-equivalence .fst h ≡ quote-shell (osuc n) h
      comparison h = ΣPathP (refl , cast-path-computation
        (quote-constant n (h S.north))
        (quote-constant n (h S.south))
        (λ i → quote-shell n (λ s → h (S.merid s i))))

    quote-equivalence : (n : Dim) (X : Type ℓ)
      → (SS.SphereBoundary (toNat n) → X) ≃ CS.Shell (toNat n) X
    quote-equivalence n X = quote-shell n , quote-isEquiv n X

  evaluation-equivalence : (n : Dim) (X : Type ℓ)
    → CS.Shell (toNat n) X ≃ (SS.SphereBoundary (toNat n) → X)
  evaluation-equivalence n X = invEquiv (quote-equivalence n X)

  evaluate : (n : Dim) {X : Type ℓ}
    → CS.Shell (toNat n) X → SS.SphereBoundary (toNat n) → X
  evaluate n {X} = invEq (quote-equivalence n X)

  evaluate-quote : (n : Dim) {X : Type ℓ} (h : SS.SphereBoundary (toNat n) → X)
    → evaluate n (quote-shell n h) ≡ h
  evaluate-quote n {X} = retEq (quote-equivalence n X)

  quote-evaluate : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → quote-shell n (evaluate n b) ≡ b
  quote-evaluate n {X} = secEq (quote-equivalence n X)

  evaluate-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → evaluate n (Map.map-shell n f b) ≡ f ∘ evaluate n b
  evaluate-natural n {X} {Y} f b =
    cong (evaluate n)
      (sym (cong (Map.map-shell n f) (quote-evaluate n b))
        ∙ strict-to-path (quote-natural n f (evaluate n b)))
      ∙ evaluate-quote n (f ∘ evaluate n b)

  constant-computation : (n : Dim) {X : Type ℓ} (x : X)
    → evaluate n (CS.restriction (toNat n) (CS.constant-cube (toNat n) x))
      ≡ (λ _ → x)
  constant-computation n x =
    cong (evaluate n) (sym (strict-to-path (quote-constant n x)))
      ∙ evaluate-quote n (λ _ → x)

  restriction-computation : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → evaluate n (CS.restriction (toNat n) c) ≡ (λ _ → CS.origin (toNat n) c)
  restriction-computation n c =
    cong (evaluate n) (sym (CS.shell-constant-homotopy (toNat n) c))
      ∙ constant-computation n (CS.origin (toNat n) c)
