{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellCanonical where

-- Keep the large, explicitly constructed identity cocone opaque to
-- clients. Its actual value, first component, and full mapping behavior
-- remain proved. This controls conversion cost without changing a map.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedCellAttachments as Attachments
import Orbifolds.CubicalShells as CS

module Canonical {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A Index : Type ℓ) (Coefficient : Index → Type ℓ)
    (original-boundary : (c : Index) → CS.Shell (toNat n) (Coefficient c → A)) where
  module Cell = Attachments.Attachment E n A Index Coefficient original-boundary

  abstract
    cocone : Cell.Cocone Cell.Realize
    cocone = Cell.canonical-cocone

    constructed : outer cocone ≡ˢ outer Cell.canonical-cocone
    constructed = reflˢ

    original-computation : outer (cocone .fst) ≡ˢ outer Cell.include
    original-computation = reflˢ

    natural : {Y : Type ℓ} (h : Cell.Realize → Y)
      → Cell.postcompose h cocone ≡ Cell.Target.restrict Y h
    natural h = Cell.restrict-natural h (idfun Cell.Realize)

    natural-original : {Y : Type ℓ} (h : Cell.Realize → Y)
      → cong fst (natural h)
        ≡ strict-to-path (strict-cong
            (λ k → outer (h ∘ inner k)) original-computation)
    natural-original h = refl
