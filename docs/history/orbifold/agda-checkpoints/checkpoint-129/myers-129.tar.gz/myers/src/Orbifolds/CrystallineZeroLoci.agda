{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Finite powers of the actual generator and the precisely scoped
-- preservation hypothesis used in Lemma 4.3.4. No global Lex record.
module Orbifolds.CrystallineZeroLoci where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
import Orbifolds.Crystalline as CR
import Orbifolds.ModalPullbacks as MP

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R public
  module Connected = MP.Theory CrystallineModality

  InfinitesimalPower : ℕ → Type ℓ
  InfinitesimalPower n = FD.Fin n → 𝔇

  zero-power : (n : ℕ) → InfinitesimalPower n
  zero-power n _ = zero𝔇

  power-connected : (n : ℕ) → Crystal.Connected (InfinitesimalPower n)
  power-connected = Connected.connected-finite-power infinitesimal-connected

  module ZeroLocus (n m : ℕ) (f : InfinitesimalPower n → InfinitesimalPower m) where
    module Diagram = Connected.FibreDiagram f (zero-power m)

    -- A crisp interpretation supplies this only for the crisp zero-locus
    -- diagram in question. Nothing here quantifies over all diagrams.
    PreservationForThisDiagram : Type ℓ
    PreservationForThisDiagram = Diagram.Preserved

    zero-locus-connected : PreservationForThisDiagram → Crystal.Connected (fiber f (zero-power m))
    zero-locus-connected preserved = Diagram.connected-fibre preserved
      (power-connected n) (power-connected m)

    presented-type-connected : {X : Type ℓ}
      → X ≃ fiber f (zero-power m) → PreservationForThisDiagram → Crystal.Connected X
    presented-type-connected presentation preserved = Connected.connected-equiv
      (invEquiv presentation) (zero-locus-connected preserved)
