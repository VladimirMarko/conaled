{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitSuccessor where

-- One genuinely constructed successor. Its generic universal-element
-- argument is proved before instantiating the large coherent diagram,
-- preserving the literal canonical restriction while bounding conversion.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as StageComparison
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical
import Orbifolds.Coherent.NaturalQuotedCellRestriction as CellRepresentation
import Orbifolds.CompositeMapEquivalence as Universal

module Successor {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  module R = Represented.Induction C D E F
  module Comparison = StageComparison.Comparison C D E F n previous
  module Cell = Comparison.Cell
  open Cocones.Functoriality C D E F using (Cocone; postcompose)

  Realize : Type ℓ
  Realize = Cell.Realize

  cell-cocone : Cell.Cocone Realize
  cell-cocone = Canonical.Canonical.cocone E (osuc n) (R.Represented.Space previous)
    Comparison.Index Comparison.Coefficient Comparison.original-boundary

  cell-original-computation : outer (cell-cocone .fst) ≡ˢ outer Cell.include
  cell-original-computation = Canonical.Canonical.original-computation E (osuc n)
    (R.Represented.Space previous) Comparison.Index Comparison.Coefficient Comparison.original-boundary

  cell-restrict : (Y : Type ℓ) → (Realize → Y) → Cell.Cocone Y
  cell-restrict = CellRepresentation.Representation.restrict E (osuc n)
    (R.Represented.Space previous) Comparison.Index Comparison.Coefficient Comparison.original-boundary

  cell-universal : (Y : Type ℓ) → (Realize → Y) ≃ Cell.Cocone Y
  cell-universal Y = cell-restrict Y , CellRepresentation.Representation.restriction-isEquiv
    E (osuc n) (R.Represented.Space previous)
    Comparison.Index Comparison.Coefficient Comparison.original-boundary Y

  cell-cocone-natural : (Y : Type ℓ) (h : Realize → Y)
    → PathP (λ _ → Cell.Cocone Y) (Cell.postcompose h cell-cocone) (cell-restrict Y h)
  cell-cocone-natural = CellRepresentation.Representation.canonical-natural E (osuc n)
    (R.Represented.Space previous) Comparison.Index Comparison.Coefficient Comparison.original-boundary

  abstract
    compare-isEquiv : (Y : Type ℓ)
      → isEquiv {A = Cell.Cocone Y} {B = Cocone Y (osuc n)} (Comparison.compare Y)
    compare-isEquiv Y = subst
      (λ (k : Cell.Cocone Y → Cocone Y (osuc n))
        → isEquiv {A = Cell.Cocone Y} {B = Cocone Y (osuc n)} k)
      (funExt (Comparison.comparison-computation Y)) (Comparison.comparison Y .snd)

  compare-natural : {X Y : Type ℓ} (h : X → Y) (s : Cell.Cocone X)
    → PathP (λ _ → Cocone Y (osuc n))
      (postcompose (osuc n) h (Comparison.compare X s))
      (Comparison.compare Y (Cell.postcompose h s))
  compare-natural {X} {Y} h s = strict-to-path
    {A = Cocone Y (osuc n)}
    {x = postcompose (osuc n) h (Comparison.compare X s)}
    {y = Comparison.compare Y (Cell.postcompose h s)}
    (Comparison.compare-natural {Y = X} {Z = Y} h s)

  canonical-cocone : Cocone Realize (osuc n)
  canonical-cocone = Comparison.compare Realize cell-cocone

  restrict : (Y : Type ℓ) → (Realize → Y) → Cocone Y (osuc n)
  restrict Y h = postcompose (osuc n) h canonical-cocone

  canonical-first : (Y : Type ℓ) (h : Realize → Y)
    → PathP (λ _ → Cocone Y (osuc n))
      (restrict Y h) (Comparison.compare Y (Cell.postcompose h cell-cocone))
  canonical-first Y h = compare-natural {X = Realize} {Y = Y} h cell-cocone

  canonical-second : (Y : Type ℓ) (h : Realize → Y)
    → PathP (λ _ → Cocone Y (osuc n))
      (Comparison.compare Y (Cell.postcompose h cell-cocone))
      (Comparison.compare Y (cell-restrict Y h))
  canonical-second Y h = cong {A = Cell.Cocone Y} {B = λ _ → Cocone Y (osuc n)}
    (Comparison.compare Y) (cell-cocone-natural Y h)

  canonical-restriction-comparison : (Y : Type ℓ) (h : Realize → Y)
    → PathP (λ _ → Cocone Y (osuc n))
      (postcompose (osuc n) h canonical-cocone)
      (Comparison.compare Y (cell-restrict Y h))
  canonical-restriction-comparison Y h = canonical-first Y h ∙ canonical-second Y h

  abstract
    restriction-isEquiv : (Y : Type ℓ)
      → isEquiv {A = Realize → Y} {B = Cocone Y (osuc n)} (restrict Y)
    restriction-isEquiv Y = Universal.homotopic-composite-isEquiv
      {A = Realize → Y} {B = Cell.Cocone Y} {C = Cocone Y (osuc n)}
      (cell-restrict Y) (Comparison.compare Y)
      (cell-universal Y .snd) (compare-isEquiv Y)
      (restrict Y) (canonical-restriction-comparison Y)

  universal : (Y : Type ℓ) → (Realize → Y) ≃ Cocone Y (osuc n)
  universal Y = restrict Y , restriction-isEquiv Y

  next : R.Represented (osuc n)
  next = record
    { Space = Realize
    ; universal-cocone = canonical-cocone
    ; restriction-isEquiv = restriction-isEquiv
    }

  transition-computation : (Y : Type ℓ) (h : Realize → Y)
    → outer {A = Cocone Y n}
        (Finite.Finite.transition (Opposite C) (Mapping.Mapping.Into C D E F Y) E n (restrict Y h))
      ≡ˢ outer {A = Cocone Y n} (R.Represented.universal previous Y .fst (h ∘ Cell.include))
  transition-computation Y h = strict-trans {A = Outer (Cocone Y n)}
    {x = outer (postcompose n h (postcompose n (cell-cocone .fst)
      (R.Represented.universal-cocone previous)))}
    {y = outer (postcompose n (h ∘ cell-cocone .fst)
      (R.Represented.universal-cocone previous))}
    {z = outer (postcompose n (h ∘ Cell.include)
      (R.Represented.universal-cocone previous))}
    (Cocones.Functoriality.postcompose-compose C D E F n
      (cell-cocone .fst) h (R.Represented.universal-cocone previous))
    (strict-cong {A = Outer (R.Represented.Space previous → Realize)}
      {B = Outer (Cocone Y n)}
      (λ f → outer (postcompose n (h ∘ inner f)
        (R.Represented.universal-cocone previous))) cell-original-computation)
