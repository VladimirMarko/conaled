{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FullProperEtaleOrbifolds where

-- The checked internal main theorem expressed using every crisp pointed
-- infinitesimal-variety square. Qualified constants avoid copying the
-- large geometric proof namespace when assembling this corollary.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base using (CommRing)
open import Cubical.Categories.Category using (Category)
open import Orbifolds.Crisp using (CrispExcludedMiddle)
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
open import Orbifolds.CrispFlat using (CrispFlatInduction; CrispFlatComputation)
open import Orbifolds.CrispTruncation using (FlatTruncationDistribution)
open import Orbifolds.GroupoidCompletion using (AllInvertible)
open import Orbifolds.ProperMaps using (DPProper)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.CrystallineEuclidean as CE
import Orbifolds.OrdinaryCharts as OC
import Orbifolds.EuclideanTopology as ET
import Orbifolds.TinyTypes as TT
import Orbifolds.CrispGeometry as CG
import Orbifolds.Crystalline as CR
import Orbifolds.GroupoidGeometry as GG
import Orbifolds.GroupoidCompletion as GC
import Orbifolds.CountableRealProbe as RP
import Orbifolds.CompactIntervals as IC
import Orbifolds.IntervalParameterization as IP
import Orbifolds.ProperEtaleManifoldOrbifolds as Core
import Orbifolds.FullInfinitesimalMicrolinearity as Full

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (@♭ rules : CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CrispFlatComputation flat-zero) where

  module Presentation (@♭ C : Category ℓ ℓ) (@♭ invertible : AllInvertible C) where
    module Ordinary
        (order : SF.RingContext.StrictOrder R)
        (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
        (constancy : CE.Ring.PrincipleOfConstancy R)
        (object-dimension arrow-dimension : ℕ)
        (object-manifold : OC.Geometry.OrdinaryManifold R object-dimension (Category.ob C)
          (ET.Euclidean.dataTopology R kock order compatibility object-dimension))
        (arrow-manifold : OC.Geometry.OrdinaryManifold R arrow-dimension (GG.ArrowSpace.Arrows C)
          (ET.Euclidean.dataTopology R kock order compatibility arrow-dimension)) where

      proper-etale-completion-orbifold : CG.Context.RealFlatAxiom R
        → CrispExcludedMiddle {ℓ = ℓ}
        → TT.External.Tiny (CR.Ring.𝔇 R)
        → FlatTruncationDistribution {ℓ = ℓ}
        → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
        → CG.Context.CrispPullbackPreservation R
        → CoveringProperty (RP.RealProbe.intervalBalls R kock order compatibility)
        → IC.Interpolation.UnitIntervalCompact R kock order compatibility
        → IP.Parameterization.PositiveLineEquivalence R kock order compatibility
        → DPProper (GG.ArrowSpace.sourceTarget C)
        → CR.Ring.Crystal.Etale R (GG.ArrowSpace.source C)
        → Full.Context.FullOrbifolds.Orbifold R (GC.Completion.Object C invertible)
      proper-etale-completion-orbifold real-flat excluded-middle tiny
          distribute upper-distribute preserve covering compact-interval
          exponential proper source-etale =
        Full.Context.Presentations.spectrum-orbifold→full R upper-distribute
          (Core.Context.Presentation.Ordinary.proper-etale-completion-orbifold
            R kock rules identity-zero flat-zero flat-zero-computation C invertible
            order compatibility constancy object-dimension arrow-dimension
            object-manifold arrow-manifold real-flat excluded-middle tiny
            distribute preserve covering compact-interval exponential proper source-etale)
