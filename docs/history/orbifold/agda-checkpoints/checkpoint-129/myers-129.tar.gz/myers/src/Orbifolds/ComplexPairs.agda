{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexPairs where

-- The complex plane in real coordinates, with its actual ring structure.
-- This layer is purely polynomial over a commutative ring.  Positivity,
-- existence of reciprocals, and the upper half-plane are separate results.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SpecialLinearTwo as SL

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  module Mat = SL.Ring R

  Scalar = R .fst

  Complex : Type ℓ
  Complex = Scalar × Scalar

  re im : Complex → Scalar
  re = fst
  im = snd

  complex-isSet : isSet Complex
  complex-isSet = isSet× is-set is-set

  zero one imaginary-unit : Complex
  zero = 0r , 0r
  one = 1r , 0r
  imaginary-unit = 0r , 1r

  real : Scalar → Complex
  real x = x , 0r

  _+c_ _*c_ : Complex → Complex → Complex
  (x , y) +c (u , v) = (x + u) , (y + v)
  (x , y) *c (u , v) = (x · u + (- (y · v))) , (x · v + y · u)

  -c_ : Complex → Complex
  -c (x , y) = (- x) , (- y)

  infixl 6 _+c_
  infixl 7 _*c_
  infix 8 -c_

  conjugate : Complex → Complex
  conjugate (x , y) = x , (- y)

  norm : Complex → Scalar
  norm (x , y) = x · x + y · y

  abstract
    add-associative : (z w v : Complex) → z +c (w +c v) ≡ (z +c w) +c v
    add-associative z w v = cong₂ _,_ (solve! R) (solve! R)

    add-right-unit : (z : Complex) → z +c zero ≡ z
    add-right-unit z = cong₂ _,_ (solve! R) (solve! R)

    add-right-inverse : (z : Complex) → z +c (-c z) ≡ zero
    add-right-inverse z = cong₂ _,_ (solve! R) (solve! R)

    add-commutative : (z w : Complex) → z +c w ≡ w +c z
    add-commutative z w = cong₂ _,_ (solve! R) (solve! R)

    multiply-associative : (z w v : Complex) → z *c (w *c v) ≡ (z *c w) *c v
    multiply-associative z w v = cong₂ _,_ (solve! R) (solve! R)

    multiply-right-unit : (z : Complex) → z *c one ≡ z
    multiply-right-unit z = cong₂ _,_ (solve! R) (solve! R)

    multiply-distributive : (z w v : Complex) → z *c (w +c v) ≡ (z *c w) +c (z *c v)
    multiply-distributive z w v = cong₂ _,_ (solve! R) (solve! R)

    multiply-commutative : (z w : Complex) → z *c w ≡ w *c z
    multiply-commutative z w = cong₂ _,_ (solve! R) (solve! R)

  ComplexRing : CommRing ℓ
  ComplexRing = makeCommRing zero one _+c_ _*c_ -c_ complex-isSet
    add-associative add-right-unit add-right-inverse add-commutative
    multiply-associative multiply-right-unit multiply-distributive
    multiply-commutative

  real-homomorphism : CommRingHom R ComplexRing
  real-homomorphism .fst = real
  IsCommRingHom.pres0 (real-homomorphism .snd) = refl
  IsCommRingHom.pres1 (real-homomorphism .snd) = refl
  IsCommRingHom.pres+ (real-homomorphism .snd) x y = cong₂ _,_ refl (solve! R)
  IsCommRingHom.pres· (real-homomorphism .snd) x y = cong₂ _,_ (solve! R) (solve! R)
  IsCommRingHom.pres- (real-homomorphism .snd) x = cong₂ _,_ refl (solve! R)

  conjugate-homomorphism : CommRingHom ComplexRing ComplexRing
  conjugate-homomorphism .fst = conjugate
  IsCommRingHom.pres0 (conjugate-homomorphism .snd) = cong₂ _,_ refl (solve! R)
  IsCommRingHom.pres1 (conjugate-homomorphism .snd) = cong₂ _,_ refl (solve! R)
  IsCommRingHom.pres+ (conjugate-homomorphism .snd) z w = cong₂ _,_ refl (solve! R)
  IsCommRingHom.pres· (conjugate-homomorphism .snd) z w = cong₂ _,_ (solve! R) (solve! R)
  IsCommRingHom.pres- (conjugate-homomorphism .snd) z = refl

  abstract
    conjugate-involution : (z : Complex) → conjugate (conjugate z) ≡ z
    conjugate-involution z = cong₂ _,_ refl (solve! R)

    imaginary-square : imaginary-unit *c imaginary-unit ≡ -c one
    imaginary-square = cong₂ _,_ (solve! R) (solve! R)

    real-imaginary-expansion : (z : Complex) → z ≡ real (re z) +c (real (im z) *c imaginary-unit)
    real-imaginary-expansion z = cong₂ _,_ (solve! R) (solve! R)

    norm-conjugate : (z : Complex) → norm (conjugate z) ≡ norm z
    norm-conjugate z = solve! R

    norm-multiply : (z w : Complex) → norm (z *c w) ≡ norm z · norm w
    norm-multiply z w = solve! R

    multiply-conjugate : (z : Complex) → z *c conjugate z ≡ real (norm z)
    multiply-conjugate z = cong₂ _,_ (solve! R) (solve! R)

    norm-zero : norm zero ≡ 0r
    norm-zero = solve! R

    norm-one : norm one ≡ 1r
    norm-one = solve! R

  inverse-with-norm : Complex → Scalar → Complex
  inverse-with-norm z t = real t *c conjugate z

  abstract
    inverse-with-norm-right : (z : Complex) (t : Scalar) → norm z · t ≡ 1r
      → z *c inverse-with-norm z t ≡ one
    inverse-with-norm-right z t p = cong₂ _,_
      ((solve! R) ∙ p) (solve! R)

    inverse-with-norm-left : (z : Complex) (t : Scalar) → norm z · t ≡ 1r
      → inverse-with-norm z t *c z ≡ one
    inverse-with-norm-left z t p = multiply-commutative (inverse-with-norm z t) z
      ∙ inverse-with-norm-right z t p

    multiply-cancel-unit : (u u' : Complex) → u *c u' ≡ one
      → {z w : Complex} → u *c z ≡ u *c w → z ≡ w
    multiply-cancel-unit u u' inverse {z} {w} equal =
      sym (multiply-right-unit z)
      ∙ cong (z *c_) (sym inverse)
      ∙ cong₂ _,_ (solve! R) (solve! R)
      ∙ cong (_*c u') equal
      ∙ cong₂ _,_ (solve! R) (solve! R)
      ∙ cong (w *c_) inverse
      ∙ multiply-right-unit w

  numerator denominator : Mat.Matrix → Complex → Complex
  numerator M z = real (Mat.a M) *c z +c real (Mat.b M)
  denominator M z = real (Mat.c M) *c z +c real (Mat.d M)

  quotient-with-norm : Mat.Matrix → Complex → Scalar → Complex
  quotient-with-norm M z t = numerator M z *c inverse-with-norm (denominator M z) t

  abstract
    denominator-coordinates : (M : Mat.Matrix) (z : Complex)
      → denominator M z ≡ ((Mat.c M · re z + Mat.d M) , (Mat.c M · im z))
    denominator-coordinates M z = cong₂ _,_ (solve! R) (solve! R)

    imaginary-cross-product : (M : Mat.Matrix) (z : Complex)
      → im (numerator M z *c conjugate (denominator M z)) ≡ Mat.determinant M · im z
    imaginary-cross-product M z = solve! R

    imaginary-quotient : (M : Mat.Matrix) (z : Complex) (t : Scalar)
      → im (quotient-with-norm M z t) ≡ (Mat.determinant M · im z) · t
    imaginary-quotient M z t = solve! R

    imaginary-special-quotient : (M : Mat.SL₂) (z : Complex) (t : Scalar)
      → im (quotient-with-norm (M .fst) z t) ≡ im z · t
    imaginary-special-quotient M z t = imaginary-quotient (M .fst) z t
      ∙ cong (λ e → (e · im z) · t) (M .snd)
      ∙ cong (_· t) (·IdL (im z))

    quotient-equation : (M : Mat.Matrix) (z : Complex) (t : Scalar)
      → norm (denominator M z) · t ≡ 1r
      → denominator M z *c quotient-with-norm M z t ≡ numerator M z
    quotient-equation M z t p =
      cong₂ _,_ (solve! R) (solve! R)
      ∙ cong (numerator M z *c_) (inverse-with-norm-right (denominator M z) t p)
      ∙ multiply-right-unit (numerator M z)
