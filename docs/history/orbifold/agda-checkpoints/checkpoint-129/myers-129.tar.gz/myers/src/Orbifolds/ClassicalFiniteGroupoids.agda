{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.ClassicalFiniteGroupoids where

-- A separate classical comparison of the algebraic finiteness fragment.
-- Ordinary excluded middle is an explicit LOCAL parameter.  It is not
-- installed in the differential-cohesive theory, whose smooth-real axioms
-- are incompatible with ordinary decidable equality of the real object.
-- No semantic model of that larger theory is asserted by this module.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.SumFin as SF
import Cubical.Data.Empty as Empty
open import Cubical.Data.FinSet
open import Cubical.Data.FinSet.Constructors using (isFinSetΣ)
open import Cubical.Functions.Embedding
import Cubical.Functions.Fibration as Fibration
open import Cubical.Relation.Nullary using (Dec; yes; no)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Association
open import Orbifolds.ProperFiniteness
open import Orbifolds.Compactness using (DPCompactAt; DPCompact)
open import Orbifolds.ProperMaps using (DPProper)
open import Orbifolds.Orbifold
  using (LocallyProperlyFinite; isPropLocallyProperlyFinite;
    setLocallyProperlyFinite; module QuotientFiniteness)
open import Orbifolds.Quotients using (Delooping; BG; Loop; module FamilyAction)
import Orbifolds.FiniteSurjectiveQuotient as FQ

private variable ℓ p : Level

OrdinaryExcludedMiddle : (ℓ : Level) → Type (ℓ-suc ℓ)
OrdinaryExcludedMiddle ℓ = (P : hProp ℓ) → Dec (P .fst)

-- This is finite hom sets, not a bound on the number of objects or
-- connected components and not a condition on any smooth atlas.
LocallyFinite : Type ℓ → Type ℓ
LocallyFinite X = (x y : X) → isFinSet (x ≡ y)

FiniteIsotropy : Type ℓ → Type ℓ
FiniteIsotropy X = (x : X) → isFinSet (x ≡ x)

isPropLocallyFinite : {X : Type ℓ} → isProp (LocallyFinite X)
isPropLocallyFinite = isPropΠ2 (λ _ _ → isPropIsFinSet)

isPropFiniteIsotropy : {X : Type ℓ} → isProp (FiniteIsotropy X)
isPropFiniteIsotropy = isPropΠ (λ _ → isPropIsFinSet)

locallyFinite→finiteIsotropy : {X : Type ℓ}
  → LocallyFinite X → FiniteIsotropy X
locallyFinite→finiteIsotropy finitePaths x = finitePaths x x

locallyFinite→isGroupoid : {X : Type ℓ} → LocallyFinite X → isGroupoid X
locallyFinite→isGroupoid finitePaths x y = isFinSet→isSet (finitePaths x y)

locallyFinite→locallyProperlyFinite : {X : Type ℓ}
  → LocallyFinite X → LocallyProperlyFinite X
locallyFinite→locallyProperlyFinite finitePaths x y =
  finiteProperlyFinite (finitePaths x y)

module Classical {ℓ : Level} (excluded-middle : OrdinaryExcludedMiddle ℓ) where
  -- Decide membership in the finite ambient ordinal.  The domain is
  -- recovered as the total space of the actual embedding's fibers.
  span-domain-finite : {X : Type ℓ} {n : ℕ}
    → (W : SubfiniteSpan X n) → isFinSet (Domain W)
  span-domain-finite {n = n} W = EquivPresIsFinSet
    (invEquiv (Fibration.totalEquiv (inclusion W .fst)))
    (isFinSetΣ (SF.Fin n , isFinSetFin)
      (λ i → fiber (inclusion W .fst) i , isDecProp→isFinSet
        (isEmbedding→hasPropFibers (inclusion W .snd) i)
        (excluded-middle (fiber (inclusion W .fst) i ,
          isEmbedding→hasPropFibers (inclusion W .snd) i))))

  span-finite : {X : Type ℓ} {n : ℕ}
    → isSet X → SubfiniteSpan X n → isFinSet X
  span-finite setX W = FQ.Image.finite-surjective-image setX (cover W)
    (span-domain-finite W)
    (λ a b → excluded-middle
      ((cover W .fst a ≡ cover W .fst b) ,
        setX (cover W .fst a) (cover W .fst b)))

  subfinitelyEnumerable-set→finite : {X : Type ℓ}
    → isSet X → SubfinitelyEnumerable X → isFinSet X
  subfinitelyEnumerable-set→finite setX = PT.rec isPropIsFinSet
    (λ witness → span-finite setX (witness .snd))

  properlyFinite→finite : {X : Type ℓ} → ProperlyFinite X → isFinSet X
  properlyFinite→finite finiteX = subfinitelyEnumerable-set→finite
    (properlyFinite→isSet finiteX) (enumerable finiteX)

  properlyFinite≃finite : {X : Type ℓ} → ProperlyFinite X ≃ isFinSet X
  properlyFinite≃finite = propBiimpl→Equiv isPropProperlyFinite isPropIsFinSet
    properlyFinite→finite finiteProperlyFinite

  locallyProperlyFinite→locallyFinite : {X : Type ℓ}
    → LocallyProperlyFinite X → LocallyFinite X
  locallyProperlyFinite→locallyFinite finitePaths x y =
    properlyFinite→finite (finitePaths x y)

  locallyProperlyFinite≃locallyFinite : {X : Type ℓ}
    → LocallyProperlyFinite X ≃ LocallyFinite X
  locallyProperlyFinite≃locallyFinite = propBiimpl→Equiv
    isPropLocallyProperlyFinite isPropLocallyFinite
    locallyProperlyFinite→locallyFinite locallyFinite→locallyProperlyFinite

  -- A hom type is empty or, after a merely supplied identification, is
  -- equivalent to an automorphism type. The elimination targets only
  -- the proposition isFinSet; no representative or global choice is kept.
  finiteIsotropy→locallyFinite : {X : Type ℓ}
    → FiniteIsotropy X → LocallyFinite X
  finiteIsotropy→locallyFinite finiteLoops x y
    with excluded-middle (PT.∥ x ≡ y ∥₁ , PT.squash₁)
  ... | yes related = PT.rec isPropIsFinSet
    (λ path → subst (λ z → isFinSet (x ≡ z)) path (finiteLoops x)) related
  ... | no unrelated = 0 , PT.∣ Empty.uninhabEquiv
    (λ path → unrelated PT.∣ path ∣₁) (λ z → z) ∣₁

  locallyFinite≃finiteIsotropy : {X : Type ℓ}
    → LocallyFinite X ≃ FiniteIsotropy X
  locallyFinite≃finiteIsotropy = propBiimpl→Equiv
    isPropLocallyFinite isPropFiniteIsotropy
    locallyFinite→finiteIsotropy finiteIsotropy→locallyFinite

  locallyProperlyFinite≃finiteIsotropy : {X : Type ℓ}
    → LocallyProperlyFinite X ≃ FiniteIsotropy X
  locallyProperlyFinite≃finiteIsotropy = compEquiv
    locallyProperlyFinite≃locallyFinite locallyFinite≃finiteIsotropy

  set-locally-finite : {X : Type ℓ} → isSet X → LocallyFinite X
  set-locally-finite setX = locallyProperlyFinite→locallyFinite
    (setLocallyProperlyFinite setX)

  -- The quotient is the actual homotopy quotient, retaining isotropy.
  finite-group-quotient-locally-finite : (G : Delooping ℓ)
    → (F : BG G → Type ℓ) → isFinSet (Loop G)
    → isSet (FamilyAction.Fibre G F)
    → LocallyFinite (FamilyAction.Quotient G F)
  finite-group-quotient-locally-finite G F finiteG setFibre =
    locallyProperlyFinite→locallyFinite
      (QuotientFiniteness.finiteGroupQuotientLocallyProperlyFinite
        G F finiteG setFibre)

-- The purely logical DP predicate loses geometric compactness in a
-- Boolean interpretation: decide A once, then discharge every B(x).
-- Both proposition and object universes are exposed; no resizing occurs.
classical-all-types-DPCompact : OrdinaryExcludedMiddle p
  → (K : Type ℓ) → DPCompactAt p K
classical-all-types-DPCompact excluded-middle K A B hypothesis
  with excluded-middle A
... | yes a = PT.∣ inl a ∣₁
... | no absent = PT.∣ inr (λ k → PT.rec (B k .snd)
  (λ { (inl a) → Empty.rec (absent a) ; (inr b) → b })
  (hypothesis k)) ∣₁

classical-all-maps-DPProper : OrdinaryExcludedMiddle ℓ
  → {X Y : Type ℓ} → (f : X → Y) → DPProper f
classical-all-maps-DPProper excluded-middle f U compactU =
  classical-all-types-DPCompact excluded-middle _
