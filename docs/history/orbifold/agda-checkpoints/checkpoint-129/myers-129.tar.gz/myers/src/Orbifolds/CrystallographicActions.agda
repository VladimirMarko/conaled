{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrystallographicActions where

-- Generic geometric packaging. A faithful action, actual ambient open
-- isolation neighborhoods, and a compact fundamental cover become a
-- discrete cocompact subgroup of the actual isometry group whenever the
-- action preserves the specified squared distance.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Functions.Embedding using (isEmbedding; _↪_)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Penon using (PenonOpen; inverseImagePenonOpen)
open import Orbifolds.Compactness using (DPCompact)
import Orbifolds.SquaredIsometryGroups as IsometryGroups

module Action {ℓ : Level} (G : Group ℓ) (X : Type ℓ) (setX : isSet X)
  (act : G .fst → X → X)
  (unit-law : (x : X) → act (GroupStr.1g (G .snd)) x ≡ x)
  (compose-law : (g h : G .fst) (x : X)
    → act (GroupStr._·_ (G .snd) g h) x ≡ act g (act h x)) where

  OpenIsolation : Type (ℓ-suc ℓ)
  OpenIsolation = (g : G .fst) → Σ[ U ∈ ((X → X) → hProp ℓ) ]
    PenonOpen U × (U (act g) .fst × ((h : G .fst) → U (act h) .fst → h ≡ g))

  CompactFundamentalCover : Type (ℓ-suc ℓ)
  CompactFundamentalCover = Σ[ K ∈ Type ℓ ] Σ[ inclusion ∈ (K ↪ X) ]
    DPCompact K × ((x : X) → PT.∥ Σ[ k ∈ K ] Σ[ g ∈ G .fst ]
      act g (inclusion .fst k) ≡ x ∥₁)

  module Metric (D : Type ℓ) (setD : isSet D) (distance : X → X → D)
    (preserves : (g : G .fst) (x y : X)
      → distance (act g x) (act g y) ≡ distance x y) where

    module Isometries = IsometryGroups.Space X setX D setD distance
    module Realization = Isometries.Action G act unit-law compose-law preserves

    record IsCrystallographic : Type (ℓ-suc ℓ) where
      field
        faithful-isometry-subgroup : isEmbedding (Realization.homomorphism .fst)
        isolating-neighborhoods : (g : G .fst)
          → Σ[ U ∈ (Isometries.Isometry → hProp ℓ) ]
            PenonOpen U × (U (Realization.homomorphism .fst g) .fst ×
              ((h : G .fst) → U (Realization.homomorphism .fst h) .fst → h ≡ g))
        compact-fundamental-cover : CompactFundamentalCover

    abstract
      realize : isEmbedding act → OpenIsolation → CompactFundamentalCover
        → IsCrystallographic
      IsCrystallographic.faithful-isometry-subgroup (realize faithful isolation compact-cover) =
        Realization.homomorphism-embedding faithful
      IsCrystallographic.isolating-neighborhoods (realize faithful isolation compact-cover) g =
        (λ e → isolation g .fst (e .fst .fst)) ,
        inverseImagePenonOpen (λ e → e .fst .fst) (isolation g .fst)
          (isolation g .snd .fst) ,
        isolation g .snd .snd .fst , isolation g .snd .snd .snd
      IsCrystallographic.compact-fundamental-cover (realize faithful isolation compact-cover) =
        compact-cover
