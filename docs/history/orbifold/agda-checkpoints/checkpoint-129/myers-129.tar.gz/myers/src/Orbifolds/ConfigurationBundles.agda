{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConfigurationBundles where

-- The univalent, non-modal part of Myers 3.3.1. Finite fibers are actual
-- fibers of a supplied map, with mere equivalences to the fixed ordinal.
-- The separate covering theorem adds shape-one etaleness; it is not
-- silently included in the definition below.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.SumFin using (Fin; isSetFin)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Quotients as Q
import Orbifolds.StructuredBundles as SB

module Labels {ℓ ℓX : Level} (K : Type ℓ) (X : Type ℓX) where

  HasLabels : Type ℓ → Type ℓ
  HasLabels E = PT.∥ E ≃ K ∥₁

  Exemplar : Type (ℓ-suc ℓ)
  Exemplar = Σ[ E ∈ Type ℓ ] HasLabels E

  canonical : Exemplar
  canonical = K , PT.∣ idEquiv K ∣₁

  exemplar-connected : (e : Exemplar) → PT.∥ canonical ≡ e ∥₁
  exemplar-connected (E , p) = PT.map
    (λ e → Σ≡Prop (λ _ → PT.squash₁) (ua (invEquiv e))) p

  symmetry-delooping : Q.Delooping (ℓ-suc ℓ)
  Q.BG symmetry-delooping = Exemplar
  Q.point symmetry-delooping = canonical
  Q.connected symmetry-delooping = exemplar-connected

  loops≃permutations : Q.Loop symmetry-delooping ≃ (K ≃ K)
  loops≃permutations = compEquiv
    (invEquiv (Σ≡PropEquiv (λ _ → PT.squash₁))) univalence

  exemplar-isSet : isSet K → (e : Exemplar) → isSet (e .fst)
  exemplar-isSet setK (E , p) = PT.rec isPropIsSet
    (λ e → isOfHLevelRespectEquiv 2 (invEquiv e) setK) p

  configuration-family : Exemplar → Type (ℓ-max ℓ ℓX)
  configuration-family e = e .fst → X

  module Action = Q.FamilyAction symmetry-delooping configuration-family

  Configuration : Type (ℓ-max (ℓ-suc ℓ) ℓX)
  Configuration = Action.Quotient

  -- This is the actual covariant function-family transport. The inverse
  -- on the carrier is necessary; the predicate-transport issue in 2.2.12
  -- does not enter this calculation.
  function-transport : {e f : Exemplar} (p : e ≡ f)
    (x : e .fst → X) (v : f .fst)
    → subst configuration-family p x v ≡ x (subst fst (sym p) v)
  function-transport {e} p = J
    (λ f p → (x : e .fst → X) (v : f .fst)
      → subst configuration-family p x v ≡ x (subst fst (sym p) v))
    (λ x v → cong (λ h → h v) (transportRefl x)
      ∙ cong x (sym (transportRefl v))) p

  module Over (A : Type ℓ) where
    module C = SB.Classification A HasLabels configuration-family

    BundlesWithMap : Type (ℓ-max (ℓ-suc ℓ) ℓX)
    BundlesWithMap = Σ[ P ∈ Type ℓ ] Σ[ π ∈ (P → A) ]
      (((a : A) → HasLabels (fiber π a)) × (P → X))

    fiberwise≃total : C.Bundles ≃ BundlesWithMap
    fiberwise≃total = Σ-cong-equiv-snd λ P →
      Σ-cong-equiv-snd λ π → Σ-cong-equiv-snd λ labels →
        SB.TotalMaps.fiberwise-maps≃total-maps π X

    maps-to-configuration≃bundles : (A → Configuration) ≃ BundlesWithMap
    maps-to-configuration≃bundles = compEquiv C.maps≃bundles fiberwise≃total

module Finite {ℓ ℓX : Level} (n : ℕ) (X : Type ℓX) where
  Ordinal = Lift {ℓ-zero} {ℓ} (Fin n)
  module L = Labels Ordinal X
  open L public using
    (Exemplar; canonical; symmetry-delooping; loops≃permutations;
     configuration-family; Configuration; function-transport)

  ordinal-isSet : isSet Ordinal
  ordinal-isSet = isOfHLevelLift 2 isSetFin

  FiniteFiber : Type ℓ → Type ℓ
  FiniteFiber E = PT.∥ E ≃ Fin n ∥₁

  finite-fiber≃labels : (E : Type ℓ) → FiniteFiber E ≃ L.HasLabels E
  finite-fiber≃labels E = propBiimpl→Equiv PT.squash₁ PT.squash₁
    (PT.map (λ e → compEquiv e LiftEquiv))
    (PT.map (λ e → compEquiv e (invEquiv LiftEquiv)))

  finite-fiber-isSet : (E : Type ℓ) → FiniteFiber E → isSet E
  finite-fiber-isSet E p = L.exemplar-isSet ordinal-isSet
    (E , finite-fiber≃labels E .fst p)

  module Over (A : Type ℓ) where
    module C = L.Over A

    FiniteBundlesWithMap : Type (ℓ-max (ℓ-suc ℓ) ℓX)
    FiniteBundlesWithMap = Σ[ P ∈ Type ℓ ] Σ[ π ∈ (P → A) ]
      (((a : A) → FiniteFiber (fiber π a)) × (P → X))

    finite≃labelled : FiniteBundlesWithMap ≃ C.BundlesWithMap
    finite≃labelled = Σ-cong-equiv-snd λ P → Σ-cong-equiv-snd λ π →
      Σ-cong-equiv-fst (equivΠCod (λ a → finite-fiber≃labels (fiber π a)))

    maps-to-configuration≃finite-bundles :
      (A → Configuration) ≃ FiniteBundlesWithMap
    maps-to-configuration≃finite-bundles = compEquiv
      C.maps-to-configuration≃bundles (invEquiv finite≃labelled)
