{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrispShapeQuotients where

-- Theorem 3.2.8 for a native-crisp higher group and an ordinary action.
-- The reflected action is the unique extension of the actual fiberwise
-- shape family to the actual reflected delooping. Its dependent-sum
-- quotient is canonically equivalent to the shape of the original one.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Pointed.Base using (_≃∙_)
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base using (CommRing)

open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.Crystalline as CR
import Orbifolds.CrispShapeDeloopings as CD
import Orbifolds.Quotients as Q

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CR.Ring R using (shape; IsShapeModal; module Shape)
  module Deloopings = CD.Context R rules
  open Deloopings using (RealFlat) public

  module Action (@♭ G : Q.Delooping ℓ) (A : Q.BG G → Type ℓ)
      (real-flat : RealFlat) where
    module Original = Q.FamilyAction G A
    module Base = Deloopings.Group G real-flat
    module Fibres = Base.Family A

    ReflectedGroup : Q.Delooping ℓ
    ReflectedGroup = Base.reflected-delooping

    module Reflected = Q.FamilyAction ReflectedGroup Fibres.Descended

    reflected-group-equivalence : shape (Q.Loop G) ≃ Q.Loop ReflectedGroup
    reflected-group-equivalence = Base.reflected-loops≃loops

    reflected-group-unit : (g : Q.Loop G)
      → equivFun reflected-group-equivalence (Shape.η g) ≡ cong Shape.η g
    reflected-group-unit = Base.reflected-loop-unit

    pointed-group-equivalence : (shape (Q.Loop G) , Shape.η refl)
      ≃∙ (Q.Loop ReflectedGroup , refl)
    pointed-group-equivalence = Base.pointed-loop-equivalence

    reflected-fibre-equivalence : shape Original.Fibre ≃ Reflected.Fibre
    reflected-fibre-equivalence = idEquiv _

    -- Uniqueness is coherent extension of the reflected action family,
    -- including its unit identification, rather than mere equality of
    -- the resulting unstructured quotient types.
    unique-reflected-action : isContr (fiber Base.restriction Fibres.reflected-family)
    unique-reflected-action = Fibres.extension-unique

    reflected-action-witness : fiber Base.restriction Fibres.reflected-family
    reflected-action-witness = Fibres.extension-witness

    reflected-quotient-modal : IsShapeModal Reflected.Quotient
    reflected-quotient-modal = Shape.Σ-isModal Fibres.Descended
      Shape.◯-isModal Fibres.descended-modal

    quotient-unit : Original.Quotient → Reflected.Quotient
    quotient-unit (b , a) = Shape.η b , Shape.η a

    comparison : shape Original.Quotient → Reflected.Quotient
    comparison = Shape.◯-rec reflected-quotient-modal quotient-unit

    comparison-unit : (x : Original.Quotient)
      → comparison (Shape.η x) ≡ quotient-unit x
    comparison-unit = Shape.◯-rec-β reflected-quotient-modal quotient-unit

    backward : Reflected.Quotient → shape Original.Quotient
    backward (b , a) = Shape.◯-elim
      {B = λ b → Fibres.Descended b → shape Original.Quotient}
      (λ b → Shape.Π-isModal {A = Fibres.Descended b} (λ _ → Shape.◯-isModal))
      (λ b → Shape.◯-rec Shape.◯-isModal (λ a → Shape.η (b , a))) b a

    backward-unit : (x : Original.Quotient) → backward (quotient-unit x) ≡ Shape.η x
    backward-unit _ = refl

    comparison-backward : (x : Reflected.Quotient) → comparison (backward x) ≡ x
    comparison-backward (b , a) = Shape.◯-elim
      {B = λ b → (a : Fibres.Descended b) → comparison (backward (b , a)) ≡ (b , a)}
      (λ b → Shape.Π-isModal {A = Fibres.Descended b}
        (λ a → Shape.isModal≡ reflected-quotient-modal
          {x = comparison (backward (b , a))} {y = b , a}))
      (λ b → Shape.◯-elim
        (λ a → Shape.isModal≡ reflected-quotient-modal)
        (λ a → cong comparison (backward-unit (b , a)) ∙ comparison-unit (b , a))) b a

    backward-comparison : (x : shape Original.Quotient) → backward (comparison x) ≡ x
    backward-comparison = Shape.◯-elim (λ _ → Shape.◯-=-isModal _ _)
      (λ x → cong backward (comparison-unit x) ∙ backward-unit x)

    shape-quotient-equivalence : shape Original.Quotient ≃ Reflected.Quotient
    shape-quotient-equivalence = isoToEquiv
      (iso comparison backward comparison-backward backward-comparison)

    shape-quotient-unit : (x : Original.Quotient)
      → equivFun shape-quotient-equivalence (Shape.η x) ≡ quotient-unit x
    shape-quotient-unit = comparison-unit

    comparison-over-base : (x : shape Original.Quotient)
      → fst (comparison x) ≡ Shape.◯-map fst x
    comparison-over-base = Shape.◯-elim (λ _ → Shape.◯-=-isModal _ _)
      (λ x → cong fst (comparison-unit x) ∙ sym (Shape.◯-map-β fst x))

    orbit-point-triangle : (x : Original.Fibre)
      → comparison (Shape.η (Original.quotient x)) ≡ Reflected.quotient (Shape.η x)
    orbit-point-triangle x = comparison-unit (Original.quotient x)

    pointed-quotient-equivalence : (x : Original.Fibre)
      → (shape Original.Quotient , Shape.η (Original.quotient x))
        ≃∙ (Reflected.Quotient , Reflected.quotient (Shape.η x))
    pointed-quotient-equivalence x = shape-quotient-equivalence , orbit-point-triangle x

    -- The fiberwise shape unit intertwines transport along every
    -- original group element with the reflected action on its image.
    action-unit-triangle : (g : Q.Loop G) (x : Original.Fibre)
      → Reflected.act (cong Shape.η g) (Shape.η x) ≡ Shape.η (Original.act g x)
    action-unit-triangle g x = J
      (λ b p → subst Fibres.Descended (cong Shape.η p) (Shape.η x)
        ≡ Shape.η (subst A p x))
      (substRefl {B = Fibres.Descended} {x = Shape.η (Q.point G)} (Shape.η x)
        ∙ cong Shape.η (sym (substRefl {B = A} {x = Q.point G} x))) g

    reflected-action-unit-triangle : (g : Q.Loop G) (x : Original.Fibre)
      → Reflected.act (equivFun reflected-group-equivalence (Shape.η g)) (Shape.η x)
        ≡ Shape.η (Original.act g x)
    reflected-action-unit-triangle g x =
      cong (λ h → Reflected.act h (Shape.η x)) (reflected-group-unit g)
      ∙ action-unit-triangle g x
