{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.RelativePresentationEquivalenceWitness where

-- Coinductive proof data connects externally indexed finite bar steps
-- to the actual ordinary-natural realization sequence. Final diagram
-- theorems construct this witness; it does not supply a presentation or
-- assert preservation of any pushout or sequential colimit.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularTransformations as CT
import Orbifolds.CellularPresentationComparisons as CC

module Theory {ℓ : Level} (O : CT.Operations ℓ) where
  open CT.Operations O using (F)
  module Comparison = CC.Theory O

  record LocalEquivalences {A B : Type ℓ}
      (P : CP.Presentation A) (Q : CP.Presentation B) (previous : B → F A)
      (M : Comparison.RelativeMap P Q previous) : Type ℓ where
    coinductive
    field
      boundary-isEquiv : isEquiv (Comparison.RelativeMap.on-boundary M)
      cell-isEquiv : isEquiv (Comparison.RelativeMap.on-cell M)
      next : LocalEquivalences (CP.Presentation.next P) (CP.Presentation.next Q)
        (Comparison.RelativeMap.successor M) (Comparison.RelativeMap.next M)

  module Realization {A B : Type ℓ}
      (P : CP.Presentation A) (Q : CP.Presentation B) (initial : B → F A)
      (M : Comparison.RelativeMap P Q initial) (witness : LocalEquivalences P Q initial M) where
    module R = Comparison.Realization P Q initial M
    module Original = CP.Realization A P
    module Supplied = CP.Realization B Q

    stage : (n : ℕ) → LocalEquivalences (Original.state n .snd) (Supplied.state n .snd)
      (R.state n .fst) (R.state n .snd)
    stage zero = witness
    stage (suc n) = LocalEquivalences.next (stage n)

    local-cells-equivalent : R.LocalCellsEquivalent
    local-cells-equivalent n = LocalEquivalences.boundary-isEquiv (stage n) ,
      LocalEquivalences.cell-isEquiv (stage n)
