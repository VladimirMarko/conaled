{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CoproductHomeomorphismCharts where

-- Explicit local charts for the source and target of a labelled family
-- of homeomorphisms. Each label slice is an actual open subset of the
-- coproduct. Neither finiteness nor excluded middle is needed here.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; full; OpenFragment; IsOpen; open-full
  ; open-local; Product )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
open import Orbifolds.Intensional.OpenSubspaces using
  ( Carrier; openSubspace; sumOpenFragment; injection-continuous
  ; restrict-continuous; corestrict-continuous; compose-continuous
  ; Homeomorphism; underlying; forward-continuous; backward-continuous )
open import Orbifolds.Intensional.LocalHomeomorphisms using
  ( LocalHomeomorphismChart; ChosenLocalHomeomorphisms )
open import Orbifolds.Intensional.FiniteCoproductCompactness using (coproduct-continuous)

module Charts {ℓ : Level} {G X Y : Set ℓ}
    (setG : isSet G) (OX : OpenFragment X) (OY : OpenFragment Y)
    (H : G → Homeomorphism OX OY) where

  arrowTopology : OpenFragment (Product G X)
  arrowTopology = sumOpenFragment (λ _ → OX)

  source : Product G X → X
  source = snd

  target : Product G X → Y
  target z = forward (underlying (H (fst z))) (snd z)

  source-continuous : Continuous arrowTopology OX source
  source-continuous U open-U g = open-U

  target-continuous : Continuous arrowTopology OY target
  target-continuous = coproduct-continuous (λ _ → OX) OY
    (λ g → forward (underlying (H g))) (λ g → forward-continuous (H g))

  module Slice (g : G) where

    patch : Subset (Product G X)
    member patch z = fst z ≡ g
    member-prop patch z = setG (fst z) g

    -- The equality proposition is constant on each component. Its
    -- openness follows locally from an inhabitant, without deciding it.
    patch-open : IsOpen arrowTopology patch
    patch-open h = open-local OX (preimage (λ x → h , x) patch)
      (λ x equal → full , open-full OX , tt , (λ y _ → equal))

    topology : OpenFragment (Carrier patch)
    topology = openSubspace arrowTopology patch patch-open

    forget : Carrier patch → X
    forget u = snd (fst u)

    insert : X → Carrier patch
    insert x = (g , x) , refl

    insert-forget : (u : Carrier patch) → insert (forget u) ≡ u
    insert-forget ((h , x) , equal) = Σ-path-prop (member-prop patch)
      (cong (λ k → k , x) (sym equal))

    forget-continuous : Continuous topology OX forget
    forget-continuous = restrict-continuous arrowTopology OX patch patch-open
      source source-continuous

    insert-continuous : Continuous OX topology insert
    insert-continuous = corestrict-continuous OX arrowTopology patch patch-open
      (λ x → g , x) (injection-continuous (λ _ → OX) g) (λ _ → refl)

    slice-homeomorphism : Homeomorphism topology OX
    underlying slice-homeomorphism = equiv forget insert (λ _ → refl) insert-forget
    forward-continuous slice-homeomorphism = forget-continuous
    backward-continuous slice-homeomorphism = insert-continuous

    target-on-slice : (u : Carrier patch)
      → target (fst u) ≡ forward (underlying (H g)) (forget u)
    target-on-slice ((h , x) , equal) =
      cong (λ k → forward (underlying (H k)) x) equal

    target-inverse : Y → Carrier patch
    target-inverse y = insert (backward (underlying (H g)) y)

    target-inverse-right : (y : Y) → target (fst (target-inverse y)) ≡ y
    target-inverse-right = section (underlying (H g))

    target-inverse-left : (u : Carrier patch) → target-inverse (target (fst u)) ≡ u
    target-inverse-left u = cong target-inverse (target-on-slice u)
      ∙ cong insert (retraction (underlying (H g)) (forget u))
      ∙ insert-forget u

    target-inverse-continuous : Continuous OY topology target-inverse
    target-inverse-continuous = compose-continuous OY OX topology
      (backward (underlying (H g))) insert
      (backward-continuous (H g)) insert-continuous

  module At (g : G) (x : X) where
    module S = Slice g

    source-chart : LocalHomeomorphismChart arrowTopology OX source (g , x)
    source-chart = record
      { source-patch = S.patch
      ; target-patch = full
      ; source-patch-open = S.patch-open
      ; target-patch-open = open-full OX
      ; source-center = refl
      ; restriction-lands = λ _ → tt
      ; local-inverse = λ v → S.insert (fst v)
      ; inverse-right-law = λ v → Σ-path-prop (member-prop full) refl
      ; inverse-left-law = S.insert-forget
      ; restriction-continuous = corestrict-continuous S.topology OX full (open-full OX)
          S.forget S.forget-continuous (λ _ → tt)
      ; local-inverse-continuous = restrict-continuous OX S.topology full (open-full OX)
          S.insert S.insert-continuous
      }

    target-chart : LocalHomeomorphismChart arrowTopology OY target (g , x)
    target-chart = record
      { source-patch = S.patch
      ; target-patch = full
      ; source-patch-open = S.patch-open
      ; target-patch-open = open-full OY
      ; source-center = refl
      ; restriction-lands = λ _ → tt
      ; local-inverse = λ v → S.target-inverse (fst v)
      ; inverse-right-law = λ v → Σ-path-prop (member-prop full)
          (S.target-inverse-right (fst v))
      ; inverse-left-law = S.target-inverse-left
      ; restriction-continuous = corestrict-continuous S.topology OY full (open-full OY)
          (λ u → target (fst u))
          (restrict-continuous arrowTopology OY S.patch S.patch-open target target-continuous)
          (λ _ → tt)
      ; local-inverse-continuous = restrict-continuous OY S.topology full (open-full OY)
          S.target-inverse S.target-inverse-continuous
      }

  source-local-homeomorphisms : ChosenLocalHomeomorphisms arrowTopology OX source
  source-local-homeomorphisms (g , x) = At.source-chart g x

  target-local-homeomorphisms : ChosenLocalHomeomorphisms arrowTopology OY target
  target-local-homeomorphisms (g , x) = At.target-chart g x
