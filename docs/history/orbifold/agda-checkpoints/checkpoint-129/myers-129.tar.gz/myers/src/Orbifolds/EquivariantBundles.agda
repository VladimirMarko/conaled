{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.EquivariantBundles where

-- A set action gives an actual family over the algebraic torsor
-- delooping. This presentation uses equivariant functions; its comparison
-- with the balanced tensor quotient is a separate theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Transport
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms using (IsGroupHom)
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Quotients as Q
import Orbifolds.Torsors as Torsors

module Theory {ℓ : Level} (G : Group ℓ) where
  module T = Torsors.Theory G
  open GroupStr (G .snd)
  open GroupTheory G using (invInv)

  module Action (A : T.Action) where
    X = T.Carrier A

    Bundle : T.Torsor → Type ℓ
    Bundle t = Σ[ f ∈ (T.TorsorCarrier t → X) ]
      T.Equivariant (t .fst .fst) (A .fst) f

    bundle-set : (t : T.Torsor) → isSet (Bundle t)
    bundle-set t = isSetΣ (isSetΠ λ _ → T.carrier-set A)
      (λ f → isProp→isSet (T.isPropEquivariant (t .fst) A f))

    evaluate : Bundle T.regular-torsor → X
    evaluate f = f .fst 1g

    orbit : X → Bundle T.regular-torsor
    orbit x = (λ g → T.act A g x) , (λ g h → T.act-compose A g h x)

    evaluate-orbit : (x : X) → evaluate (orbit x) ≡ x
    evaluate-orbit = T.act-unit A

    orbit-evaluate : (f : Bundle T.regular-torsor) → orbit (evaluate f) ≡ f
    orbit-evaluate f = Σ≡Prop (T.isPropEquivariant T.regular-action A)
      (funExt λ g → sym (f .snd g 1g) ∙ cong (f .fst) (·IdR g))

    regular-coordinates : Bundle T.regular-torsor ≃ X
    regular-coordinates = isoToEquiv (iso evaluate orbit evaluate-orbit orbit-evaluate)

    transport-bundle : {t u : T.Torsor} (p : t ≡ u)
      (f : Bundle t) (x : T.TorsorCarrier u)
      → subst Bundle p f .fst x ≡ f .fst (subst T.TorsorCarrier (sym p) x)
    transport-bundle {t} p = J
      (λ u p → (f : Bundle t) (x : T.TorsorCarrier u)
        → subst Bundle p f .fst x ≡ f .fst (subst T.TorsorCarrier (sym p) x))
      (λ f x → cong (λ z → z .fst x) (transportRefl f)
        ∙ cong (f .fst) (sym (transportRefl x))) p

    -- Inverting the evaluation coordinate matches the reversed loop
    -- product used for left family actions in Quotients.
    group-loop : G .fst → Q.Loop T.torsor-delooping
    group-loop g = T.element-loop (inv g)

    inverse-loop-coordinate : (g : G .fst)
      → subst T.TorsorCarrier (sym (group-loop g)) 1g ≡ g
    inverse-loop-coordinate g =
      IsGroupHom.presinv (T.torsor-loop-group-equivalence .snd) (group-loop g)
      ∙ cong inv (secEq (T.transport-identifications T.regular-torsor) (inv g))
      ∙ invInv g

    module Family = Q.FamilyAction T.torsor-delooping Bundle

    action-transport : (g : G .fst) (x : X)
      → evaluate (Family.act (group-loop g) (orbit x)) ≡ T.act A g x
    action-transport g x = transport-bundle (group-loop g) (orbit x) 1g
      ∙ cong (λ h → T.act A h x) (inverse-loop-coordinate g)

    classify-action : T.Torsor → Q.BG (Q.automorphismDelooping (Type ℓ) X)
    classify-action t = Bundle t , PT.map
      (λ p → sym (ua regular-coordinates) ∙ cong Bundle p) (T.torsor-connected t)

    classify-action-point : classify-action T.regular-torsor
      ≡ Q.point (Q.automorphismDelooping (Type ℓ) X)
    classify-action-point = Σ≡Prop (λ _ → PT.squash₁) (ua regular-coordinates)

    act-inverse-right : (t : T.Action) (g : G .fst) (x : T.Carrier t)
      → T.act t g (T.act t (inv g) x) ≡ x
    act-inverse-right t g x = sym (T.act-compose t g (inv g) x)
      ∙ cong (λ h → T.act t h x) (·InvR g) ∙ T.act-unit t x

    act-inverse-left : (t : T.Action) (g : G .fst) (x : T.Carrier t)
      → T.act t (inv g) (T.act t g x) ≡ x
    act-inverse-left t g x = sym (T.act-compose t (inv g) g x)
      ∙ cong (λ h → T.act t h x) (·InvL g) ∙ T.act-unit t x

    action-equivalence : (g : G .fst) → X ≃ X
    action-equivalence g = isoToEquiv (iso (T.act A g) (T.act A (inv g))
      (act-inverse-right A g) (act-inverse-left A g))

    evaluate-at : (t : T.Torsor) (x : T.TorsorCarrier t) → Bundle t → X
    evaluate-at t x f = f .fst x

    regular-evaluate-at : (g : G .fst) → isEquiv (evaluate-at T.regular-torsor g)
    regular-evaluate-at g = subst isEquiv
      (sym (funExt λ f → sym (cong (f .fst) (·IdR g)) ∙ f .snd g 1g))
      (compEquiv regular-coordinates (action-equivalence g) .snd)

    evaluation-at-isEquiv : (t : T.Torsor) (x : T.TorsorCarrier t)
      → isEquiv (evaluate-at t x)
    evaluation-at-isEquiv t = PT.rec (isPropΠ λ x → isPropIsEquiv _)
      (λ p → subst (λ u → (x : T.TorsorCarrier u)
        → isEquiv (evaluate-at u x)) p regular-evaluate-at)
      (T.torsor-connected t)

    evaluation-at-equivalence : (t : T.Torsor) (x : T.TorsorCarrier t)
      → Bundle t ≃ X
    evaluation-at-equivalence t x = evaluate-at t x , evaluation-at-isEquiv t x
