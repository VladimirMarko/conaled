{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConnectedFibers where

-- A connected pointed source and a surjective based loop map give a
-- connected actual homotopy fiber.  Its loop-fiber comparison is the
-- literal transposition of the dependent equality coordinate.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (Unit*; tt*)
open import Cubical.Functions.Surjection
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.ConnectedPullbacks as PB
import Orbifolds.MicrolinearityLimits as ML

module Map {ℓ : Level} {A B : Type ℓ} (f : A → B) (a₀ : A) where
  Fiber : Type ℓ
  Fiber = fiber f (f a₀)

  base : Fiber
  base = a₀ , refl

  loop-map : (a₀ ≡ a₀) → (f a₀ ≡ f a₀)
  loop-map = cong f

  loop-fiber : (base ≡ base) ≃ fiber loop-map refl
  loop-fiber = isoToEquiv (iso
    (λ p → (λ i → p i .fst) , (λ j i → p i .snd j))
    (λ { (p , q) i → p i , (λ j → q j i) })
    (λ _ → refl) (λ _ → refl))

  pullback : Type ℓ
  pullback = ML.Pullback (const (f a₀) :> (Unit* {ℓ = ℓ} → B)) f

  pullback-base : pullback
  pullback-base = (tt* , a₀) , refl

  module Span = PB.Span (const (f a₀) :> (Unit* {ℓ = ℓ} → B)) f pullback-base

  pullback-to-fiber : pullback ≃ Fiber
  pullback-to-fiber = isoToEquiv (iso
    (λ { ((_ , a) , p) → a , sym p })
    (λ { (a , p) → (tt* , a) , sym p })
    (λ _ → refl) (λ _ → refl))

  connected-fiber : ((a : A) → PT.∥ a₀ ≡ a ∥₁)
    → isSurjection loop-map → (z : Fiber) → PT.∥ base ≡ z ∥₁
  connected-fiber connected surjective (a , p) =
    PT.map (cong (equivFun pullback-to-fiber))
      (Span.Connected.connected-pullback
        (λ _ → PT.∣ refl ∣₁) connected surjective ((tt* , a) , sym p))
