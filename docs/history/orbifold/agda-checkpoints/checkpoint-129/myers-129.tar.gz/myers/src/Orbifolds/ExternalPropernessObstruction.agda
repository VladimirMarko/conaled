{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.ExternalPropernessObstruction where

-- A precise obstruction to a properness-preserving interpretation.
-- This is not a construction of semantics for Agda, nor a proof that
-- every possible external interpretation of synthetic orbifolds fails.
-- The obstruction concerns literal DPProper and a represented smooth
-- real diagonal. Equivalent choices of its domain/codomain do not help.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism using (iso; isoToEquiv)
open import Cubical.Data.Sigma
open import Cubical.Relation.Nullary using (Dec; Discrete)
open import Cubical.Categories.Category using (Category; isiso)
open import Cubical.Categories.Instances.Discrete using (DiscreteCategory)
open import Cubical.Algebra.CommRing.Base using (CommRing; CommRingStr)
import Cubical.Data.Empty as Empty

open import Orbifolds.Compactness
  using (DPCompact; contractibleDPCompact; compactProposition→Dec;
         decidablePropositionDPCompact)
open import Orbifolds.ProperMaps
  using (DPProper; isPropDPProper; compactFibers→Proper; composeProper)
open import Orbifolds.GroupoidCompletion using (AllInvertible)
import Orbifolds.GroupoidGeometry as GG
import Orbifolds.ProperCompactDecisions as Decisions
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticDifferential as SD

private variable ℓ : Level

-- Properness respects actual equivalences without a setness assumption.
equivalence-DP-proper : {X Y : Type ℓ} (e : X ≃ Y) → DPProper (equivFun e)
equivalence-DP-proper e = compactFibers→Proper (equivFun e)
  (λ y → contractibleDPCompact (e .snd .equiv-proof y))

-- Transport along a homotopy-commuting square with equivalences on both
-- sides. No unproved preservation property of a semantic functor is used.
proper-along-equivalences : {A B X Y : Type ℓ}
  (f : A → B) (g : X → Y) (a : A ≃ X) (b : B ≃ Y)
  → ((z : A) → equivFun b (f z) ≡ g (equivFun a z))
  → DPProper f → DPProper g
proper-along-equivalences f g a b square properF =
  subst DPProper (funExt (λ x →
    square (invEq a x) ∙ cong g (secEq a x)))
    (composeProper (f ∘ invEq a) (equivFun b)
      (composeProper (invEq a) f (equivalence-DP-proper (invEquiv a)) properF)
      (equivalence-DP-proper b))

properness-commuting-equivalences : {A B X Y : Type ℓ}
  (f : A → B) (g : X → Y) (a : A ≃ X) (b : B ≃ Y)
  → ((z : A) → equivFun b (f z) ≡ g (equivFun a z))
  → DPProper f ≃ DPProper g
properness-commuting-equivalences f g a b square =
  propBiimpl→Equiv isPropDPProper isPropDPProper
    (proper-along-equivalences f g a b square)
    (proper-along-equivalences g f (invEquiv a) (invEquiv b)
      (λ x → cong (invEq b)
        (sym (square (invEq a x) ∙ cong g (secEq a x)))
        ∙ retEq b (f (invEq a x))))

-- The chosen representation need only agree with the diagonal up to the
-- displayed homotopy. It need not be definitionally the same map.
record DiagonalRepresentation {A B : Type ℓ} (X : Type ℓ) (f : A → B)
    : Type ℓ where
  field
    domain-equivalence : A ≃ X
    codomain-equivalence : B ≃ (X × X)
    diagonal-square : (z : A)
      → equivFun codomain-equivalence (f z)
        ≡ (equivFun domain-equivalence z , equivFun domain-equivalence z)

open DiagonalRepresentation

represented-diagonal-proper≃discrete : {A B X : Type ℓ}
  (setX : isSet X) (f : A → B) → DiagonalRepresentation X f
  → DPProper f ≃ Discrete X
represented-diagonal-proper≃discrete setX f represented =
  compEquiv
    (properness-commuting-equivalences f Diagonal.diagonal
      (domain-equivalence represented) (codomain-equivalence represented)
      (diagonal-square represented))
    Diagonal.proper-diagonal≃discrete
  where
  module Diagonal = Decisions.Diagonal setX

-- The empty-or-point observation does yield compactness at a decided
-- pair. The obstruction is to supplying this uniformly at all ordinary
-- varying pairs of smooth real points.
compact-equality-at-decided-pair : {X : Type ℓ} (setX : isSet X)
  (x y : X) → Dec (x ≡ y) → DPCompact (x ≡ y)
compact-equality-at-decided-pair setX x y =
  decidablePropositionDPCompact ((x ≡ y) , setX x y)

-- The actual unit groupoid on a set, using equality as its hom-family.
-- Its total arrow space and source-target map are the same constructions
-- used by the main groupoid theorem, not a substitute predicate.
module IdentityPresentation {X : Type ℓ} (setX : isSet X) where
  category : Category ℓ ℓ
  category = DiscreteCategory (X , isSet→isGroupoid setX)

  all-invertible : AllInvertible category
  all-invertible x y p = isiso (sym p)
    (setX y y (sym p ∙ p) refl)
    (setX x x (p ∙ sym p) refl)

  module Arrows = GG.ArrowSpace category
  open Arrows using (source; sourceTarget)

  source-equivalence : Arrows.Arrows ≃ X
  source-equivalence = isoToEquiv (iso source
    (λ x → (x , x) , refl)
    (λ x → refl)
    (λ { ((x , y) , p) i → (x , p i) , (λ j → p (i ∧ j)) }))

  source-target-represents-diagonal : DiagonalRepresentation X sourceTarget
  domain-equivalence source-target-represents-diagonal = source-equivalence
  codomain-equivalence source-target-represents-diagonal = idEquiv (X × X)
  diagonal-square source-target-represents-diagonal ((x , y) , p) i =
    x , p (~ i)

  source-target-proper≃discrete : DPProper sourceTarget ≃ Discrete X
  source-target-proper≃discrete = represented-diagonal-proper≃discrete setX
    sourceTarget source-target-represents-diagonal

module SmoothReals (R : CommRing ℓ) (kock : SF.RingContext.KockField R)
    (kl : SD.FirstOrder.FirstOrderKL R) where
  open CommRingStr (R .snd) using (is-set)
  Carrier : Type ℓ
  Carrier = R .fst
  module Differential = SF.RingContext.Differential R kock kl
  module UnitGroupoid = IdentityPresentation is-set

  equality-fibers-not-uniformly-compact :
    ((x y : Carrier) → DPCompact (x ≡ y)) → Empty.⊥
  equality-fibers-not-uniformly-compact compact =
    Differential.no-decidable-equality (λ x y →
      compactProposition→Dec ((x ≡ y) , is-set x y) (compact x y))

  represented-diagonal-not-DP-proper : {A B : Type ℓ} (f : A → B)
    → DiagonalRepresentation Carrier f → DPProper f → Empty.⊥
  represented-diagonal-not-DP-proper f represented proper =
    Differential.no-decidable-equality
      (equivFun (represented-diagonal-proper≃discrete is-set f represented) proper)

  unit-groupoid-source-target-not-DP-proper :
    DPProper UnitGroupoid.Arrows.sourceTarget → Empty.⊥
  unit-groupoid-source-target-not-DP-proper =
    represented-diagonal-not-DP-proper UnitGroupoid.Arrows.sourceTarget
      UnitGroupoid.source-target-represents-diagonal

-- An abstract, independently specified class of external maps and a
-- proposed assignment of internal objects/maps. This interface does not
-- assert soundness for the whole type theory. Every semantics offering
-- the claimed mapwise comparison would have to supply these particular
-- data, so refuting them gives a necessary-condition obstruction.
module MapClass
    {o a p ℓ : Level}
    (Object : Type o)
    (Arrow : Object → Object → Type a)
    (Proper : {X Y : Object} → Arrow X Y → Type p)
    (object-image : Object → Type ℓ)
    (arrow-image : {X Y : Object} → Arrow X Y
      → object-image X → object-image Y) where

  PreservesProperness : Type (ℓ-max o (ℓ-max a (ℓ-max p (ℓ-suc ℓ))))
  PreservesProperness = {X Y : Object} (f : Arrow X Y)
    → Proper f → DPProper (arrow-image f)

  module SmoothLine (R : CommRing ℓ) (kock : SF.RingContext.KockField R)
      (kl : SD.FirstOrder.FirstOrderKL R) where
    module Obstruction = SmoothReals R kock kl

    -- The externally proper distinguished arrow is a hypothesis, not a
    -- postulated theorem about classical topology. Classical diagonal
    -- properness is justified separately in EXTERNAL-PROPERNESS-OBSTRUCTION.md.
    no-comparison-at-represented-line-diagonal :
      {Line Plane : Object} (delta : Arrow Line Plane)
      → Proper delta
      → DiagonalRepresentation (R .fst) (arrow-image delta)
      → (Proper delta → DPProper (arrow-image delta))
      → Empty.⊥
    no-comparison-at-represented-line-diagonal delta properDelta represented comparison =
      Obstruction.represented-diagonal-not-DP-proper
        (arrow-image delta) represented (comparison properDelta)

    no-properness-preserving-interpretation :
      {Line Plane : Object} (delta : Arrow Line Plane)
      → Proper delta
      → DiagonalRepresentation (R .fst) (arrow-image delta)
      → PreservesProperness → Empty.⊥
    no-properness-preserving-interpretation delta properDelta represented comparison =
      no-comparison-at-represented-line-diagonal delta properDelta represented
        (comparison delta)
