{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.InfinitesimalInverseFunction where

-- The exact additional infinitesimal inverse function hypothesis from
-- Theorem 5.2.12 concerns self-maps of full Penon disks.  Its consequence
-- for maps of different dimensions is derived by applying it to both
-- composites with a linear extension of the inverse derivative.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Pointed
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.WeilAlgebras as WA
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.PenonFirstOrder as PF
import Orbifolds.PenonTangentCoordinates as TC
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.FirstOrderMatrixInverses as MI

private variable ℓa ℓb : Level

both-composites-equivalent : {A : Type ℓa} {B : Type ℓb}
  (f : A → B) (g : B → A) → isEquiv (g ∘ f) → isEquiv (f ∘ g) → isEquiv f
both-composites-equivalent f g gf fg = isoToIsEquiv (iso f back right left)
  where
  back = g ∘ invEq (_ , fg)
  right : (y : _) → f (back y) ≡ y
  right = secEq (_ , fg)
  left : (x : _) → back (f x) ≡ x
  left x = invEq (congEquiv (_ , gf)) (cong g (right (f x)))

module Ring {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (kock-lawvere : WA.Weil.KockLawvere R) where
  module Disks = PF.Ring R kock kock-lawvere
  module Coordinates = TC.Ring R kock kock-lawvere
  module Linear = LM.Ring R
  module Differential = SD.FirstOrder R
  open Disks using (full; small; restriction; restriction-matrix; linear-full)

  InfinitesimalInverseFunctionTheorem : Type ℓ
  InfinitesimalInverseFunctionTheorem =
    (n : ℕ) (f : full n →∙ full n)
    → isEquiv (restriction f .fst) → isEquiv (f .fst)

  module Map {n m : ℕ} (f : full n →∙ full m)
      (tangent-equivalence : isEquiv
        (λ (v : (Differential.D , Differential.zeroD) →∙ full n) → f ∘∙ v)) where
    module Inverse = MI.Ring.Inverse R (restriction-matrix f)
      (Coordinates.tangent-detects-matrix-equivalence f tangent-equivalence)

    inverse-extension : full m →∙ full n
    inverse-extension = linear-full Inverse.inverse-matrix

    restriction-equivalent : isEquiv (restriction f .fst)
    restriction-equivalent = Inverse.disk-equivalence .snd

    inverse-restriction-equivalent : isEquiv (restriction inverse-extension .fst)
    inverse-restriction-equivalent = subst isEquiv
      (sym (cong fst (Disks.restriction-linear Inverse.inverse-matrix)))
      (Inverse.inverse-disk-equivalence .snd)

    left-composite-restriction : isEquiv (restriction (inverse-extension ∘∙ f) .fst)
    left-composite-restriction = subst isEquiv
      (sym (cong fst (Disks.restriction-composition f inverse-extension)))
      (compEquiv (_ , restriction-equivalent) (_ , inverse-restriction-equivalent) .snd)

    right-composite-restriction : isEquiv (restriction (f ∘∙ inverse-extension) .fst)
    right-composite-restriction = subst isEquiv
      (sym (cong fst (Disks.restriction-composition inverse-extension f)))
      (compEquiv (_ , inverse-restriction-equivalent) (_ , restriction-equivalent) .snd)

    from-self-map-axiom : InfinitesimalInverseFunctionTheorem → isEquiv (f .fst)
    from-self-map-axiom infinitesimal-inverse = both-composites-equivalent
      (f .fst) (inverse-extension .fst)
      (infinitesimal-inverse n (inverse-extension ∘∙ f) left-composite-restriction)
      (infinitesimal-inverse m (f ∘∙ inverse-extension) right-composite-restriction)
