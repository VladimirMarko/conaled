{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NullCoherentCoconeRestriction where

-- The constructed native unit induces an equivalence on full cocones
-- into every null target. This is an equivalence of the actual cocone
-- restriction map, derived from native dependent Null elimination.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentNullification as Null
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Cubical.HITs.Nullification.Base as NB
import Orbifolds.NullCubicalExtensions as Extension

module UnitRestriction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    {Ix : Type₀} (S : Ix → Type ℓ) (E : StrictCubicalExtensionality ℓ)
    (F : StrictFunctionExtensionality ℓ) (Y : Type ℓ) (nullY : NB.isNull S Y) where
  module H = HC.ForCategory C
  module D = H.Diagram D
  module Reflected = Null.Reflection C D S E
  module R = Restriction.Restriction C D Reflected.reflected Reflected.unit-transformation E F Y
  module Extensions = Extension.Nullification S

  open R using (SourceCocone; TargetCocone; restrict; finite-restriction;
    partial-map; partial-square; projection-computation; compatibility-computation) public

  restrict-isEquiv : isEquiv restrict
  restrict-isEquiv = R.coefficient-equivalences λ x →
    Extensions.Dependent.restriction-equivalence (D.Value x) (λ _ → Y) (λ _ → nullY) .snd

  restriction-equivalence : SourceCocone ≃ TargetCocone
  restriction-equivalence = restrict , restrict-isEquiv
