{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CoverRefinement where

-- Selected site data sufficient for restriction of sheaves. Every source
-- covering sieve has a specified small family inside it. Its image covers
-- by universal containment, without constructing a truncated image sieve.
-- The selected overlaps are actual target pullbacks against all objects.

open import Agda.Primitive using (Level; Set; lsuc)
open import Orbifolds.Intensional.Identity hiding (lift)
open import Orbifolds.Intensional.CategoricalTransfer
open import Orbifolds.Intensional.SmallSites using (Sieve; GrothendieckTopology)

private variable ℓ : Level

record PreservedPullback (C D : Category ℓ ℓ) (i : Functor C D)
    {a b c : Category.Obj C} (u : Category.Hom C a c) (h : Category.Hom C b c)
    : Set ℓ where
  private
    module C = Category C
    module D = Category D
    module i = Functor i
  field
    apex : C.Obj
    first : C.Hom apex a
    second : C.Hom apex b
    square : C.compose u first ≡ C.compose h second
    lift : (d : D.Obj) (f : D.Hom d (i.object a)) (g : D.Hom d (i.object b))
      → D.compose (i.arrow u) f ≡ D.compose (i.arrow h) g → D.Hom d (i.object apex)
    lift-first : (d : D.Obj) (f : D.Hom d (i.object a)) (g : D.Hom d (i.object b))
      (p : D.compose (i.arrow u) f ≡ D.compose (i.arrow h) g)
      → D.compose (i.arrow first) (lift d f g p) ≡ f
    lift-second : (d : D.Obj) (f : D.Hom d (i.object a)) (g : D.Hom d (i.object b))
      (p : D.compose (i.arrow u) f ≡ D.compose (i.arrow h) g)
      → D.compose (i.arrow second) (lift d f g p) ≡ g
    lift-unique : (d : D.Obj) (f : D.Hom d (i.object a)) (g : D.Hom d (i.object b))
      (p : D.compose (i.arrow u) f ≡ D.compose (i.arrow h) g)
      (k : D.Hom d (i.object apex))
      → D.compose (i.arrow first) k ≡ f → D.compose (i.arrow second) k ≡ g
      → lift d f g p ≡ k

  image-square : D.compose (i.arrow u) (i.arrow first)
    ≡ D.compose (i.arrow h) (i.arrow second)
  image-square = sym (i.arrow-compose u first) ∙ cong i.arrow square ∙ i.arrow-compose h second

record CoverRefinement (C D : Category ℓ ℓ) (i : Functor C D)
    (K : GrothendieckTopology D) {c : Category.Obj C} (S : Sieve C c)
    : Set (lsuc ℓ) where
  private
    module C = Category C
    module D = Category D
    module i = Functor i
  field
    Index : Set ℓ
    domain : Index → C.Obj
    arrow : (j : Index) → C.Hom (domain j) c
    belongs : (j : Index) → Sieve.contains S (arrow j)
    image-covers : (T : Sieve D (i.object c))
      → ((j : Index) → Sieve.contains T (i.arrow (arrow j)))
      → GrothendieckTopology.Cover K T
    overlaps : (j : Index) {y : C.Obj} (h : C.Hom y c)
      → PreservedPullback C D i (arrow j) h

SelectedCoverRefinements : (C D : Category ℓ ℓ) (i : Functor C D)
  → GrothendieckTopology C → GrothendieckTopology D → Set (lsuc ℓ)
SelectedCoverRefinements C D i J K = (c : Category.Obj C) (S : Sieve C c)
  → GrothendieckTopology.Cover J S → CoverRefinement C D i K S
