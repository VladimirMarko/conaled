{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictConstantPathCoherence where

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)

strict-path-value : ∀ {ℓ} {A : Type ℓ} {x y : A}
  (p : outer x ≡ˢ outer y) (i : I)
  → outer (strict-to-path p i) ≡ˢ outer x
strict-path-value reflˢ i = reflˢ

module Extensional {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  constant-path : {A : Type ℓ} {x y : A} (p : x ≡ y) (z : A)
    (constant : (i : I) → outer (p i) ≡ˢ outer z)
    → outer p ≡ˢ outer (strict-to-path (strict-trans (constant i0) (strict-sym (constant i1))))
  constant-path p z constant = path-ext λ i → strict-trans (constant i)
    (strict-sym (strict-trans
      (strict-path-value (strict-trans (constant i0) (strict-sym (constant i1))) i)
      (constant i0)))
