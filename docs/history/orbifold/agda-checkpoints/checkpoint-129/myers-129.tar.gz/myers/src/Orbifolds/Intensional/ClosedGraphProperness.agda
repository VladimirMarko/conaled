{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ClosedGraphProperness where

-- A continuous graph into a Hausdorff target is closed. Intersecting
-- an arbitrary compact subset of the product with this proved closed
-- graph and projecting its finite subcover gives actual ProperData.
-- No compactness or local compactness of either ambient space is used.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; Included; intersection; complement
  ; OpenFragment; IsOpen; open-intersection; open-local; Product )
open import Orbifolds.Intensional.CompactSeparation using
  ( Covers; FiniteSubcover; CompactData; preimage; Continuous; ProperData
  ; PropositionalEM; ChosenHausdorff; SeparatedNeighborhoods; closed-subset-compact )

module Graph {ℓ : Level} {X Y : Set ℓ}
    (ext : FunExt ℓ ℓ)
    (OX : OpenFragment X) (OY : OpenFragment Y)
    (OXY : OpenFragment (Product X Y))
    (setY : isSet Y) (separated : ChosenHausdorff OY)
    (first-continuous : Continuous OXY OX fst)
    (second-continuous : Continuous OXY OY snd)
    (f : X → Y) (continuous : Continuous OX OY f) where

  graphMap : X → Product X Y
  graphMap x = x , f x

  graphSubset : Subset (Product X Y)
  member graphSubset z = f (fst z) ≡ snd z
  member-prop graphSubset z = setY (f (fst z)) (snd z)

  on-graph : (z : Product X Y) → member graphSubset z → graphMap (fst z) ≡ z
  on-graph (x , y) p = cong (λ w → x , w) p

  closed-graph : IsOpen OXY (complement ext graphSubset)
  closed-graph = open-local OXY (complement ext graphSubset) neighborhood
    where
    neighborhood : (z : Product X Y) → member (complement ext graphSubset) z
      → Σ (Subset (Product X Y)) (λ U → Σ (IsOpen OXY U)
        (λ _ → Σ (member U z) (λ _ → Included U (complement ext graphSubset))))
    neighborhood z outside = U , open-U , center-U , included-U
      where
      N : SeparatedNeighborhoods OY (f (fst z)) (snd z)
      N = separated (f (fst z)) (snd z) outside

      L R : Subset Y
      L = SeparatedNeighborhoods.near-left N
      R = SeparatedNeighborhoods.near-right N

      U : Subset (Product X Y)
      U = intersection (preimage (λ w → f (fst w)) L) (preimage snd R)

      open-U : IsOpen OXY U
      open-U = open-intersection OXY
        (first-continuous (preimage f L)
          (continuous L (SeparatedNeighborhoods.left-open N)))
        (second-continuous R (SeparatedNeighborhoods.right-open N))

      center-U : member U z
      center-U = SeparatedNeighborhoods.left-center N , SeparatedNeighborhoods.right-center N

      included-U : Included U (complement ext graphSubset)
      included-U w (left , right) equal =
        SeparatedNeighborhoods.disjoint N (f (fst w)) left
          (subst (member R) (sym equal) right)

  graph-proper : PropositionalEM ℓ → ProperData OX OXY graphMap
  graph-proper classical K compact {I} U opens covers =
    fst finite , λ x inside → snd finite (graphMap x) (inside , refl)
    where
    closed-part : Subset (Product X Y)
    closed-part = intersection K graphSubset

    compact-part : CompactData OXY closed-part
    compact-part = closed-subset-compact ext classical OXY K graphSubset compact closed-graph

    patches : I → Subset (Product X Y)
    patches i = preimage fst (U i)

    patches-open : (i : I) → IsOpen OXY (patches i)
    patches-open i = first-continuous (U i) (opens i)

    patches-cover : Covers closed-part patches
    patches-cover z (inside , equal) =
      covers (fst z) (subst (member K) (sym (on-graph z equal)) inside)

    finite : FiniteSubcover closed-part patches
    finite = compact-part patches patches-open patches-cover
