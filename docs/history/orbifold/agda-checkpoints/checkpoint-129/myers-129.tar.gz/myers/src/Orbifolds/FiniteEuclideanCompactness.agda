{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.FiniteEuclideanCompactness where

-- Lemma 6.2.21 for subsets of every finite real power.
-- No countable-basis, singleton-openness, isolation, or finite-cover
-- assumption remains.  These are constructed from squared norms and
-- explicitly enumerated rational boxes.  The general manifold case is
-- still separate, as is the cohesive bridge from shape-discreteness to
-- the decidable equality used explicitly here.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (Dec; yes; no; Discrete; Discrete→isSet)
open import Cubical.Functions.Embedding using (isEmbedding; isEmbedding→Inj; EmbeddingΣProp)
open import Cubical.Algebra.CommRing.Base
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.SyntheticBounds using (module Bounds)
open import Orbifolds.EuclideanNorms using (module Norms)
open import Orbifolds.CountableBoxes using (module Boxes)
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.CompactSubspaces using (WithoutPoint; complementSingletonDPCompact)
open import Orbifolds.CompactFiniteness using (compactSubcountableSingletonCover→ProperlyFinite)
open import Orbifolds.CountableCovers using (SubcountableIndex; Covers)
open import Orbifolds.Penon using (PenonOpen; inverseImagePenonOpen)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
open import Orbifolds.Topology using (Predicate)
open import Orbifolds.ProperFiniteness using (ProperlyFinite)

module FinitePowers {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open RealProbe R kock order compatibility
    using (PositiveRadius; intervalBalls; realCountableProbe)
  open Bounds R kock order compatibility using (positiveFunctionBoundAwayZero)
  open Norms R kock order compatibility using (Vector; squaredDistance; distancePositive)
  open Boxes R kock order compatibility using (BasicBox; basicBoxPenonOpen; normBallBasicBox)

  isolatingBasicBox : CoveringProperty intervalBalls →
    (n : ℕ) → {K : Type ℓ} → DPCompact K → Discrete K →
    (f : K → Vector n) → isEmbedding f → (x : K) →
    ∥ Σ[ code ∈ ℕ ] (BasicBox n code (f x) .fst ×
      ((y : K) → BasicBox n code (f y) .fst → x ≡ y)) ∥₁
  isolatingBasicBox covering n {K = K} compactK decide f embedding x =
    PT.rec squash₁
      (λ { (ε , lowerBound) → PT.map (finish ε lowerBound)
        (normBallBasicBox covering n (f x) ε) })
      (positiveFunctionBoundAwayZero covering
        (complementSingletonDPCompact compactK decide x)
        (λ other → squaredDistance n (f x) (f (other .fst)))
        (λ other → distancePositive n
          (λ path → other .snd (isEmbedding→Inj embedding x (other .fst) path))))
    where
    finish : (ε : PositiveRadius) →
      ((other : WithoutPoint x) → ε .fst < squaredDistance n (f x) (f (other .fst))) →
      (Σ[ code ∈ ℕ ] (BasicBox n code (f x) .fst ×
        ((v : Vector n) → BasicBox n code v .fst → squaredDistance n (f x) v < ε .fst))) →
      Σ[ code ∈ ℕ ] (BasicBox n code (f x) .fst ×
        ((y : K) → BasicBox n code (f y) .fst → x ≡ y))
    finish ε lowerBound (code , contains , included) =
      code , contains , (λ y → unique y (decide x y))
      where
      unique : (y : K) → Dec (x ≡ y) → BasicBox n code (f y) .fst → x ≡ y
      unique y (yes path) member = path
      unique y (no distinct) member =
        Empty.rec (lessAsym (lowerBound (y , distinct)) (included (f y) member))

  -- Select precisely those rational boxes whose intersections with K
  -- are subsingletons.  This is a proposition-valued subtype of ℕ; each
  -- point is covered because the preceding theorem constructs an
  -- isolating basic box.  The bound theorem and corrected association
  -- then construct a genuine finite span onto K.
  compactDiscreteFinitePowerEmbeddingProperlyFinite : CoveringProperty intervalBalls →
    (n : ℕ) → {K : Type ℓ} → DPCompact K → Discrete K →
    (f : K → Vector n) → isEmbedding f → ProperlyFinite K
  compactDiscreteFinitePowerEmbeddingProperlyFinite covering n {K = K} compactK decide f embedding =
    compactSubcountableSingletonCover→ProperlyFinite intervalBalls covering realCountableProbe
      compactK decide Selected U openU coversU
      (λ index {x} {y} → index .snd x y)
    where
    Selected : ℕ → hProp ℓ
    Selected code =
      ((x y : K) → BasicBox n code (f x) .fst → BasicBox n code (f y) .fst → x ≡ y) ,
      isPropΠ4 (λ x y _ _ → Discrete→isSet decide x y)

    U : SubcountableIndex Selected → K → hProp ℓ
    U index x = BasicBox n (index .fst) (f x)

    openU : (index : SubcountableIndex Selected) → PenonOpen (U index)
    openU index = inverseImagePenonOpen f (BasicBox n (index .fst))
      (basicBoxPenonOpen n (index .fst))

    coversU : Covers U
    coversU x = PT.map
      (λ { (code , contains , unique) →
        (code , (λ y z memberY memberZ → sym (unique y memberY) ∙ unique z memberZ)) , contains })
      (isolatingBasicBox covering n compactK decide f embedding x)

  compactDiscreteFinitePowerSubsetProperlyFinite : CoveringProperty intervalBalls →
    (n : ℕ) → (U : Predicate (Vector n)) →
    DPCompact (Σ[ x ∈ Vector n ] U x .fst) → Discrete (Σ[ x ∈ Vector n ] U x .fst) →
    ProperlyFinite (Σ[ x ∈ Vector n ] U x .fst)
  compactDiscreteFinitePowerSubsetProperlyFinite covering n U compactU decide =
    compactDiscreteFinitePowerEmbeddingProperlyFinite covering n compactU decide fst
      (EmbeddingΣProp (λ x → U x .snd) .snd)

