{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.InfinitesimalVarietyDiagrams where

-- Actual pointed infinitesimal-variety squares and their spectrum
-- presentations. The normalizing square is obtained by univalent
-- transport of the entire pointed square, retaining its commutativity
-- path. No square-coherence or pushout preservation is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Pointed.Base
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.WeilAlgebras as WA
import Orbifolds.WeilDiagrams as WD
import Orbifolds.Microlinearity as ML

module Ring {ℓ : Level} (R : CommRing ℓ) where
  module W = WA.Weil R
  module Spectra = WD.Geometry R

  record Frame : Type (ℓ-suc ℓ) where
    field
      NW NE SW SE : Pointed ℓ

  record Diagram (frame : Frame) : Type ℓ where
    open Frame frame
    field
      north : NW →∙ NE
      west : NW →∙ SW
      east : NE →∙ SE
      south : SW →∙ SE
      commutes : (x : NW .fst)
        → east .fst (north .fst x) ≡ south .fst (west .fst x)

  TotalDiagram : Type (ℓ-suc ℓ)
  TotalDiagram = Σ Frame Diagram

  test-square : TotalDiagram → ML.TestSquare ℓ
  ML.TestSquare.NW (test-square (frame , d)) = Frame.NW frame .fst
  ML.TestSquare.NE (test-square (frame , d)) = Frame.NE frame .fst
  ML.TestSquare.SW (test-square (frame , d)) = Frame.SW frame .fst
  ML.TestSquare.SE (test-square (frame , d)) = Frame.SE frame .fst
  ML.TestSquare.north (test-square (frame , d)) = Diagram.north d .fst
  ML.TestSquare.west (test-square (frame , d)) = Diagram.west d .fst
  ML.TestSquare.east (test-square (frame , d)) = Diagram.east d .fst
  ML.TestSquare.south (test-square (frame , d)) = Diagram.south d .fst
  ML.TestSquare.commutes (test-square (frame , d)) = Diagram.commutes d
  ML.TestSquare.north-point (test-square (frame , d)) = Frame.NW frame .snd

  Presentation : Pointed ℓ → Type (ℓ-suc ℓ)
  Presentation X = Σ[ A ∈ W.WeilAlgebra ] X ≃∙ (W.Spec A , W.origin A)

  record InfinitesimalRealPushout : Type (ℓ-suc ℓ) where
    field
      frame : Frame
      diagram : Diagram frame
      infinitesimal-NW : PT.∥ Presentation (Frame.NW frame) ∥₁
      infinitesimal-NE : PT.∥ Presentation (Frame.NE frame) ∥₁
      infinitesimal-SW : PT.∥ Presentation (Frame.SW frame) ∥₁
      infinitesimal-SE : PT.∥ Presentation (Frame.SE frame) ∥₁
      real-pushout : ML.Square.IsPushoutFor (test-square (frame , diagram)) (R .fst)

    total : TotalDiagram
    total = frame , diagram

    square : ML.TestSquare ℓ
    square = test-square total

  spectrum-frame : W.WeilAlgebra → W.WeilAlgebra → W.WeilAlgebra → W.WeilAlgebra → Frame
  Frame.NW (spectrum-frame A B C D) = W.Spec A , W.origin A
  Frame.NE (spectrum-frame A B C D) = W.Spec B , W.origin B
  Frame.SW (spectrum-frame A B C D) = W.Spec C , W.origin C
  Frame.SE (spectrum-frame A B C D) = W.Spec D , W.origin D

  from-spectrum-diagram : (d : Spectra.WeilDiagram)
    → Diagram (spectrum-frame (Spectra.WNW d) (Spectra.WNE d) (Spectra.WSW d) (Spectra.WSE d))
  Diagram.north (from-spectrum-diagram d) = Spectra.north d , Spectra.north-based d
  Diagram.west (from-spectrum-diagram d) = Spectra.west d , Spectra.west-based d
  Diagram.east (from-spectrum-diagram d) = Spectra.east d , Spectra.east-based d
  Diagram.south (from-spectrum-diagram d) = Spectra.south d , Spectra.south-based d
  Diagram.commutes (from-spectrum-diagram d) = Spectra.commutes d

  from-spectra : Spectra.WeilRealPushout → InfinitesimalRealPushout
  InfinitesimalRealPushout.frame (from-spectra s) = spectrum-frame
    (Spectra.WNW (Spectra.diagram s)) (Spectra.WNE (Spectra.diagram s))
    (Spectra.WSW (Spectra.diagram s)) (Spectra.WSE (Spectra.diagram s))
  InfinitesimalRealPushout.diagram (from-spectra s) = from-spectrum-diagram (Spectra.diagram s)
  InfinitesimalRealPushout.infinitesimal-NW (from-spectra s) =
    W.spectrum-infinitesimal (Spectra.WNW (Spectra.diagram s))
  InfinitesimalRealPushout.infinitesimal-NE (from-spectra s) =
    W.spectrum-infinitesimal (Spectra.WNE (Spectra.diagram s))
  InfinitesimalRealPushout.infinitesimal-SW (from-spectra s) =
    W.spectrum-infinitesimal (Spectra.WSW (Spectra.diagram s))
  InfinitesimalRealPushout.infinitesimal-SE (from-spectra s) =
    W.spectrum-infinitesimal (Spectra.WSE (Spectra.diagram s))
  InfinitesimalRealPushout.real-pushout (from-spectra s) = Spectra.real-pushout s

  to-spectrum-diagram : (A B C D : W.WeilAlgebra)
    → Diagram (spectrum-frame A B C D) → Spectra.WeilDiagram
  Spectra.WeilDiagram.WNW (to-spectrum-diagram A B C D s) = A
  Spectra.WeilDiagram.WNE (to-spectrum-diagram A B C D s) = B
  Spectra.WeilDiagram.WSW (to-spectrum-diagram A B C D s) = C
  Spectra.WeilDiagram.WSE (to-spectrum-diagram A B C D s) = D
  Spectra.WeilDiagram.north (to-spectrum-diagram A B C D s) = Diagram.north s .fst
  Spectra.WeilDiagram.west (to-spectrum-diagram A B C D s) = Diagram.west s .fst
  Spectra.WeilDiagram.east (to-spectrum-diagram A B C D s) = Diagram.east s .fst
  Spectra.WeilDiagram.south (to-spectrum-diagram A B C D s) = Diagram.south s .fst
  Spectra.WeilDiagram.north-based (to-spectrum-diagram A B C D s) = Diagram.north s .snd
  Spectra.WeilDiagram.west-based (to-spectrum-diagram A B C D s) = Diagram.west s .snd
  Spectra.WeilDiagram.east-based (to-spectrum-diagram A B C D s) = Diagram.east s .snd
  Spectra.WeilDiagram.south-based (to-spectrum-diagram A B C D s) = Diagram.south s .snd
  Spectra.WeilDiagram.commutes (to-spectrum-diagram A B C D s) = Diagram.commutes s

  module Normalize (s : InfinitesimalRealPushout)
      (pNW : Presentation (Frame.NW (InfinitesimalRealPushout.frame s)))
      (pNE : Presentation (Frame.NE (InfinitesimalRealPushout.frame s)))
      (pSW : Presentation (Frame.SW (InfinitesimalRealPushout.frame s)))
      (pSE : Presentation (Frame.SE (InfinitesimalRealPushout.frame s))) where
    private
      original = InfinitesimalRealPushout.frame s
      A = pNW .fst
      B = pNE .fst
      C = pSW .fst
      D = pSE .fst

    frame-path : original ≡ spectrum-frame A B C D
    Frame.NW (frame-path i) = ua∙ (pNW .snd .fst) (pNW .snd .snd) i
    Frame.NE (frame-path i) = ua∙ (pNE .snd .fst) (pNE .snd .snd) i
    Frame.SW (frame-path i) = ua∙ (pSW .snd .fst) (pSW .snd .snd) i
    Frame.SE (frame-path i) = ua∙ (pSE .snd .fst) (pSE .snd .snd) i

    rebased : Diagram (spectrum-frame A B C D)
    rebased = subst Diagram frame-path (InfinitesimalRealPushout.diagram s)

    total-path : InfinitesimalRealPushout.total s ≡ (spectrum-frame A B C D , rebased)
    total-path = ΣPathP (frame-path ,
      subst-filler Diagram frame-path (InfinitesimalRealPushout.diagram s))

    spectrum-diagram : Spectra.WeilDiagram
    spectrum-diagram = to-spectrum-diagram A B C D rebased

    square-path : InfinitesimalRealPushout.square s ≡ Spectra.square spectrum-diagram
    square-path = cong test-square total-path

    real-pushout : Spectra.WeilRealPushout
    Spectra.WeilRealPushout.diagram real-pushout = spectrum-diagram
    Spectra.WeilRealPushout.real-pushout real-pushout =
      subst (λ q → ML.Square.IsPushoutFor q (R .fst)) square-path
        (InfinitesimalRealPushout.real-pushout s)

    transfer : {ℓx : Level} (X : Type ℓx)
      → ML.Square.IsPushoutFor (Spectra.test-square real-pushout) X
      → ML.Square.IsPushoutFor (InfinitesimalRealPushout.square s) X
    transfer X = subst (λ q → ML.Square.IsPushoutFor q X) (sym square-path)
