{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexLineInnerProducts where

-- Real inner products on actual complex lines. Scalars are restricted
-- along the actual real ring homomorphism. On the canonical line,
-- this is equivalent to the already checked literal-plane definition,
-- with both directions preserving the pairing judgmentally.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Module.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.ComplexPairs as CP
import Orbifolds.ComplexLines as CL
import Orbifolds.ScalarRestriction as SR
import Orbifolds.ModuleInnerProducts as MI
import Orbifolds.RealInnerProducts as RI

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (order : SF.RingContext.StrictOrder R) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  module C = CP.Ring R
  module Lines = CL.Complex R
  module Plane = RI.Plane R order
  module Restrict = SR.Along (CommRing→Ring R) (CommRing→Ring C.ComplexRing)
    (CommRingHom→RingHom C.real-homomorphism)
  module Change = MI.ChangeCoordinates {ℓm = ℓ} R order

  RealModule : Lines.Line → LeftModule (CommRing→Ring R) ℓ
  RealModule L = Restrict.restrict (L .fst)

  InnerProduct : Lines.Line → Type ℓ
  InnerProduct L = MI.Theory.InnerProduct R order (RealModule L)

  pairing : {L : Lines.Line} → InnerProduct L
    → Lines.Carrier L → Lines.Carrier L → R .fst
  pairing = MI.Theory.InnerProduct.pairing

  norm : {L : Lines.Line} → InnerProduct L → Lines.Carrier L → R .fst
  norm {L} form x = pairing {L} form x x

  real-equivalence : {L M : Lines.Line} → LeftModuleEquiv (L .fst) (M .fst)
    → LeftModuleEquiv (RealModule L) (RealModule M)
  real-equivalence {L} {M} = Restrict.equivalence {M = L .fst} {N = M .fst}

  pullback : {L M : Lines.Line} → LeftModuleEquiv (L .fst) (M .fst)
    → InnerProduct M → InnerProduct L
  pullback {L} {M} e = Change.pullback {M = RealModule L} {N = RealModule M}
    (real-equivalence {L} {M} e)

  forms-equivalence : {L M : Lines.Line} → LeftModuleEquiv (L .fst) (M .fst)
    → InnerProduct M ≃ InnerProduct L
  forms-equivalence {L} {M} e = Change.forms-equivalence {M = RealModule L} {N = RealModule M}
    (real-equivalence {L} {M} e)

  module Canonical = MI.Theory R order (RealModule Lines.canonical-line)

  canonical-to-plane : InnerProduct Lines.canonical-line → Plane.InnerProduct
  Plane.InnerProduct.pairing (canonical-to-plane form) = Canonical.InnerProduct.pairing form
  Plane.InnerProduct.symmetric (canonical-to-plane form) = Canonical.InnerProduct.symmetric form
  Plane.InnerProduct.additive-left (canonical-to-plane form) = Canonical.InnerProduct.additive-left form
  Plane.InnerProduct.homogeneous-left (canonical-to-plane form) r z w =
    cong (λ v → Canonical.InnerProduct.pairing form v w) (Plane.scale-real-product r z)
      ∙ Canonical.InnerProduct.homogeneous-left form r z w
  Plane.InnerProduct.positive (canonical-to-plane form) = Canonical.InnerProduct.positive form

  plane-to-canonical : Plane.InnerProduct → InnerProduct Lines.canonical-line
  Canonical.InnerProduct.pairing (plane-to-canonical form) = Plane.InnerProduct.pairing form
  Canonical.InnerProduct.symmetric (plane-to-canonical form) = Plane.InnerProduct.symmetric form
  Canonical.InnerProduct.additive-left (plane-to-canonical form) = Plane.InnerProduct.additive-left form
  Canonical.InnerProduct.homogeneous-left (plane-to-canonical form) r z w =
    cong (λ v → Plane.InnerProduct.pairing form v w) (sym (Plane.scale-real-product r z))
      ∙ Plane.InnerProduct.homogeneous-left form r z w
  Canonical.InnerProduct.positive (plane-to-canonical form) = Plane.InnerProduct.positive form

  plane-section : (form : Plane.InnerProduct)
    → canonical-to-plane (plane-to-canonical form) ≡ form
  Plane.InnerProduct.pairing (plane-section form i) = Plane.InnerProduct.pairing form
  Plane.InnerProduct.symmetric (plane-section form i) =
    isPropΠ2 (λ z w → is-set _ _)
      (Plane.InnerProduct.symmetric (canonical-to-plane (plane-to-canonical form)))
      (Plane.InnerProduct.symmetric form) i
  Plane.InnerProduct.additive-left (plane-section form i) =
    isPropΠ3 (λ z w v → is-set _ _)
      (Plane.InnerProduct.additive-left (canonical-to-plane (plane-to-canonical form)))
      (Plane.InnerProduct.additive-left form) i
  Plane.InnerProduct.homogeneous-left (plane-section form i) =
    isPropΠ3 (λ r z w → is-set _ _)
      (Plane.InnerProduct.homogeneous-left (canonical-to-plane (plane-to-canonical form)))
      (Plane.InnerProduct.homogeneous-left form) i
  Plane.InnerProduct.positive (plane-section form i) =
    isPropΠ2 (λ z nonzero → less-isProp _ _)
      (Plane.InnerProduct.positive (canonical-to-plane (plane-to-canonical form)))
      (Plane.InnerProduct.positive form) i

  canonical-retraction : (form : InnerProduct Lines.canonical-line)
    → plane-to-canonical (canonical-to-plane form) ≡ form
  canonical-retraction form = Canonical.form-path _ form refl

  canonical-forms : InnerProduct Lines.canonical-line ≃ Plane.InnerProduct
  canonical-forms = isoToEquiv (iso canonical-to-plane plane-to-canonical
    plane-section canonical-retraction)

  canonical-pairing : (form : InnerProduct Lines.canonical-line) (z w : C.Complex)
    → Plane.InnerProduct.pairing (canonical-forms .fst form) z w
      ≡ pairing {Lines.canonical-line} form z w
  canonical-pairing form z w = refl

  canonical-inverse-pairing : (form : Plane.InnerProduct) (z w : C.Complex)
    → pairing {Lines.canonical-line} (invEq canonical-forms form) z w
      ≡ Plane.InnerProduct.pairing form z w
  canonical-inverse-pairing form z w = refl
