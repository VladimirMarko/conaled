{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispIntegerNullity where

-- Native integer induction derives crisp representatives.  Combined
-- with R-flatness and the identity rule, the actual integers and the
-- actual determinant-one integer matrix group are R-null.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ; pos; negsuc; isSetℤ)
open import Cubical.Functions.Surjection using (isSurjection; isEmbedding×isSurjection→isEquiv)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFiniteModal as FM
import Orbifolds.SpecialLinearTwo as SL

integer-crisp-elim : {ℓp : Level} (P : ℤ → Type ℓp)
  → ((@♭ z : ℤ) → P z) → (z : ℤ) → P z
integer-crisp-elim P step (pos n) = natural-crisp-elim (λ n → P (pos n)) (λ n → step (pos n)) n
integer-crisp-elim P step (negsuc n) = natural-crisp-elim (λ n → P (negsuc n)) (λ n → step (negsuc n)) n

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    (@♭ rules : CI.CrispIdentityInduction {ℓ}) where
  module Finite = FM.Context R r₀ rules
  open Finite using (RealFlat; Generator) public

  LiftedIntegers : Type ℓ
  LiftedIntegers = Lift {j = ℓ} ℤ

  counit-surjective : isSurjection (counit {A = LiftedIntegers})
  counit-surjective (lift z) = integer-crisp-elim
    (λ z → PT.∥ fiber (counit {A = LiftedIntegers}) (lift z) ∥₁)
    (λ z → PT.∣ box (lift z) , refl ∣₁) z

  lifted-integers-discrete : RealFlat → CrisplyDiscrete LiftedIntegers
  lifted-integers-discrete real-flat = isEmbedding×isSurjection→isEquiv
    (Finite.counit-set-embedding real-flat (isOfHLevelLift 2 isSetℤ) , counit-surjective)

  lifted-integers-null : RealFlat → NB.isNull Generator LiftedIntegers
  lifted-integers-null real-flat _ = fromIsEquiv const
    (equivFun (real-flat LiftedIntegers) (lifted-integers-discrete real-flat))

  integers-null : RealFlat → NB.isNull Generator ℤ
  integers-null real-flat = NP.equivPreservesIsNull (invEquiv LiftEquiv)
    (lifted-integers-null real-flat)

  pairs-null : RealFlat → NB.isNull Generator (ℤ × ℤ)
  pairs-null real-flat = NP.isNullΣ (integers-null real-flat) (λ _ → integers-null real-flat)

  matrices-null : RealFlat → NB.isNull Generator SL.Integers.Matrix
  matrices-null real-flat = NP.isNullΣ (pairs-null real-flat) (λ _ → pairs-null real-flat)

  special-linear-null : RealFlat → NB.isNull Generator SL.Integers.SL₂
  special-linear-null real-flat = NP.isNullΣ (matrices-null real-flat)
    (λ M → NP.isNull≡ (integers-null real-flat))

  lifted-special-linear-null : RealFlat → NB.isNull Generator (Lift {j = ℓ} SL.Integers.SL₂)
  lifted-special-linear-null real-flat = NP.equivPreservesIsNull LiftEquiv (special-linear-null real-flat)
