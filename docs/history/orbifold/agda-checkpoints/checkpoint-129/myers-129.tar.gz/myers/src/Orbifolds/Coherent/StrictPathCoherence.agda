{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictPathCoherence where

-- Coherence of the actual conversion from outer equality to inner paths.
-- These laws only eliminate strict equality; no extensionality is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.GroupoidLaws
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)

strict-path-congruence : ∀ {ℓ ℓ'} {A : Type ℓ} {B : Type ℓ'}
  (f : A → B) {x y : A} (p : outer x ≡ˢ outer y)
  (q : outer (f x) ≡ˢ outer (f y))
  → cong f (strict-to-path p) ≡ strict-to-path q
strict-path-congruence f reflˢ q with strict-uip q reflˢ
... | reflˢ = refl

strict-path-composite : ∀ {ℓ} {A : Type ℓ} {x y z : A}
  (p : outer x ≡ˢ outer y) (q : outer y ≡ˢ outer z)
  → strict-to-path p ∙ strict-to-path q ≡ strict-to-path (strict-trans p q)
strict-path-composite reflˢ reflˢ = sym (lUnit refl)

strict-path-proof-independent : ∀ {ℓ} {A : Type ℓ} {x y : A}
  (p q : outer x ≡ˢ outer y)
  → strict-to-path p ≡ strict-to-path q
strict-path-proof-independent p q = strict-to-path
  (strict-cong (λ r → outer (strict-to-path r)) (strict-uip p q))

strict-path-paste : ∀ {ℓ} {A : Type ℓ} {x x' y' y : A}
  (q : I → A) (at-zero : outer (q i0) ≡ˢ outer x')
  (at-one : outer (q i1) ≡ˢ outer y')
  (left : outer x ≡ˢ outer x') (right : outer y' ≡ˢ outer y)
  → strict-to-path left ∙ strict-end-path q at-zero at-one ∙ strict-to-path right
    ≡ strict-end-path q (strict-trans at-zero (strict-sym left)) (strict-trans at-one right)
strict-path-paste q reflˢ reflˢ reflˢ reflˢ =
  cong (refl ∙_) (sym (rUnit (λ i → q i))) ∙ sym (lUnit (λ i → q i))
