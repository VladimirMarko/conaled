{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CompactIntervals where

-- The explicit closed unit interval of Axiom 5 and affine interpolation.
-- Compactness is a named function argument, not a postulate.  An affine
-- image of this interval lies inside any prescribed open interval and
-- contains a smaller open interval around its center.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Relation.Nullary using (¬_; isProp¬)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.SyntheticBounds using (module Bounds)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.EuclideanNorms using (module Norms)
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.PenonNeighborhoods using (BallStructure)

module Interpolation {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open Field kock
  open OrderedRingCompatibility compatibility
  open Bounds R kock order compatibility using (scaleCancel)
  open RealProbe R kock order compatibility using (PositiveRadius; intervalBalls)
  open Norms R kock order compatibility using (Nonnegative; positiveAddNonnegative)

  UnitInterval : Type ℓ
  UnitInterval = Σ[ t ∈ Carrier ] ((¬ (t < 0r)) × (¬ (1r < t)))

  UnitIntervalCompact : Type (ℓ-suc ℓ)
  UnitIntervalCompact = DPCompact UnitInterval

  scaledNonnegative : {a b : Carrier} → 0r < a → Nonnegative b → Nonnegative (a · b)
  scaledNonnegative {a} {b} positive nonnegative negative = nonnegative
    (subst2 _<_ (scaleCancel a (inverse .fst) b (inverse .snd .snd))
      (0LeftAnnihilates (inverse .fst))
      (multiplyLessRightPositive (inverse .snd .fst) negative))
    where
    inverse = positiveInverse a positive

  subtractAdd : (a b : Carrier) → (a - b) + b ≡ a
  subtractAdd a b = solve! R

  oneMinusNonnegative : (t : UnitInterval) → Nonnegative (1r - t .fst)
  oneMinusNonnegative t negative = t .snd .snd
    (subst2 _<_ (subtractAdd 1r (t .fst)) (+IdL (t .fst))
      (translateLess negative (t .fst)))

  segment : (x : Carrier) → PositiveRadius → UnitInterval → Carrier
  segment x r t = x + (((r .fst + r .fst) · t .fst) - r .fst)

  lowerSegmentDifference : (x r t : Carrier) →
    (x + (((r + r) · t) - r)) - (x - (r + r)) ≡ r + ((r + r) · t)
  lowerSegmentDifference x r t = solve! R

  upperSegmentDifference : (x r t : Carrier) →
    (x + (r + r)) - (x + (((r + r) · t) - r)) ≡ r + ((r + r) · (1r - t))
  upperSegmentDifference x r t = solve! R

  segmentInDoubleBall : (x : Carrier) (r : PositiveRadius) (t : UnitInterval) →
    BallStructure.ball intervalBalls x
      (r .fst + r .fst , positive-add (r .snd) (r .snd)) (segment x r t) .fst
  segmentInDoubleBall x r t =
    positiveDifference→less
      (subst (0r <_) (sym (lowerSegmentDifference x (r .fst) (t .fst)))
        (positiveAddNonnegative (r .snd)
          (scaledNonnegative (positive-add (r .snd) (r .snd)) (t .snd .fst)))) ,
    positiveDifference→less
      (subst (0r <_) (sym (upperSegmentDifference x (r .fst) (t .fst)))
        (positiveAddNonnegative (r .snd)
          (scaledNonnegative (positive-add (r .snd) (r .snd)) (oneMinusNonnegative t))))

  numeratorIdentity : (x y r : Carrier) → y - (x - r) ≡ (y - x) + r
  numeratorIdentity x y r = solve! R

  upperNumeratorIdentity : (x y r : Carrier) →
    (r + r) - ((y - x) + r) ≡ (x + r) - y
  upperNumeratorIdentity x y r = solve! R

  cancelMiddle : (a u z : Carrier) → a · u ≡ 1r → a · (z · u) ≡ z
  cancelMiddle a u z inverse = rearrange ∙ cong (_· z) inverse ∙ ·IdL z
    where
    rearrange : a · (z · u) ≡ (a · u) · z
    rearrange = solve! R

  reconstructionIdentity : (x y r : Carrier) → x + (((y - x) + r) - r) ≡ y
  reconstructionIdentity x y r = solve! R

  representInnerBall : (x : Carrier) (r : PositiveRadius) (y : Carrier) →
    BallStructure.ball intervalBalls x r y .fst → Σ[ t ∈ UnitInterval ] segment x r t ≡ y
  representInnerBall x r y (lower , upper) = parameter , reconstruction
    where
    denominator : Carrier
    denominator = r .fst + r .fst

    inverse : Σ[ u ∈ Carrier ] ((0r < u) × (denominator · u ≡ 1r))
    inverse = positiveInverse denominator (positive-add (r .snd) (r .snd))

    numerator : Carrier
    numerator = (y - x) + r .fst

    numeratorPositive : 0r < numerator
    numeratorPositive = subst (0r <_) (numeratorIdentity x y (r .fst))
      (less→positiveDifference lower)

    numeratorBelow : numerator < denominator
    numeratorBelow = positiveDifference→less
      (subst (0r <_) (sym (upperNumeratorIdentity x y (r .fst)))
        (less→positiveDifference upper))

    t : Carrier
    t = numerator · inverse .fst

    tPositive : 0r < t
    tPositive = positive-multiply numeratorPositive (inverse .snd .fst)

    tBelowOne : t < 1r
    tBelowOne = subst (t <_) (inverse .snd .snd)
      (multiplyLessRightPositive (inverse .snd .fst) numeratorBelow)

    parameter : UnitInterval
    parameter = t , lessAsym tPositive , lessAsym tBelowOne

    reconstruction : segment x r parameter ≡ y
    reconstruction = cong (λ z → x + (z - r .fst))
      (cancelMiddle denominator (inverse .fst) numerator (inverse .snd .snd))
      ∙ reconstructionIdentity x y (r .fst)

  record Window (x : Carrier) (ε : PositiveRadius) : Type ℓ where
    field
      innerRadius : PositiveRadius
      point : UnitInterval → Carrier
      inside : (t : UnitInterval) → BallStructure.ball intervalBalls x ε (point t) .fst
      represents : (y : Carrier) → BallStructure.ball intervalBalls x innerRadius y .fst →
        Σ[ t ∈ UnitInterval ] point t ≡ y

  open Window

  halfScaleTwice : (ε : Carrier) → (half · ε) + (half · ε) ≡ ε
  halfScaleTwice ε = sym (·DistL+ half half ε)
    ∙ cong (_· ε) twoHalves ∙ ·IdL ε

  intervalWindow : (x : Carrier) (ε : PositiveRadius) → Window x ε
  innerRadius (intervalWindow x ε) = half · ε .fst , halfScalePositive (ε .snd)
  point (intervalWindow x ε) = segment x (innerRadius (intervalWindow x ε))
  inside (intervalWindow x ε) t =
    subst (λ r → ((x - r) < point (intervalWindow x ε) t) ×
      (point (intervalWindow x ε) t < (x + r)))
      (halfScaleTwice (ε .fst))
      (segmentInDoubleBall x (innerRadius (intervalWindow x ε)) t)
  represents (intervalWindow x ε) = representInnerBall x (innerRadius (intervalWindow x ε))

