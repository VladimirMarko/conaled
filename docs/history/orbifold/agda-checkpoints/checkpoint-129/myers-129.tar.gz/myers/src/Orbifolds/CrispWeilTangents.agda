{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispWeilTangents where

-- Proposition 4.3.5 at the actual crystalline modality and every
-- actual crisp infinitesimal variety. Connectedness is derived from
-- the polynomial presentation theorem and crisp pullback preservation.

open import Cubical.Foundations.Prelude
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.CrispTruncation
import Orbifolds.SyntheticField as SF
import Orbifolds.CrispGeometry as CG
import Orbifolds.CrispWeil as CW
import Orbifolds.TangentEtale as TE
import Orbifolds.WeilAlgebras as WA

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (distribute : FlatTruncationDistribution {ℓ = ℓ})
    (preserve : CG.Context.CrispPullbackPreservation R) where
  module Geometry = CG.Context R
  module Connected = CW.Context.Proof R kock distribute preserve
  module W = WA.Weil R

  module Variety (@♭ D : Type ℓ) (@♭ zeroD : D)
      (@♭ variety : WA.Weil.InfinitesimalVariety R D zeroD) where
    open TE.Theory Geometry.Infinitesimal.CrystallineModality D zeroD
      (Connected.crisp-variety-connected D zeroD variety)
      using (Tangent; derivative; Etale; tangent-pushforward-isEquiv; tangent-pushforward) public

  module Spectrum (@♭ algebra : WA.Weil.WeilAlgebra R) where
    open TE.Theory Geometry.Infinitesimal.CrystallineModality
      (W.Spec algebra) (W.origin algebra) (Connected.crisp-weil-connected algebra)
      using (Tangent; derivative; Etale; tangent-pushforward-isEquiv; tangent-pushforward) public
