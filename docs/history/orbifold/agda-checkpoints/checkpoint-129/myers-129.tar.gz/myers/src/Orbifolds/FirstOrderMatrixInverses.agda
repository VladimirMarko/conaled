{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderMatrixInverses where

-- An equivalence of the underlying coordinate maps has a linear
-- inverse.  Rectangular matrices are allowed; no rank-equality or
-- invariant-basis-number axiom is required.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Module
open import Cubical.Categories.Functor.Base
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.FirstOrderInfinitesimalLinearity as IL

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open LM.Ring R

  module Inverse {n m : ℕ} (a : Mat n m) (equivalent : isEquiv (action a)) where
    equivalence : Vector n ≃ Vector m
    equivalence = action a , equivalent

    backwards : Vector m → Vector n
    backwards = invEq equivalence

    injective : {x y : Vector n} → action a x ≡ action a y → x ≡ y
    injective = invEq (congEquiv equivalence)

    backwards-linear : IsLeftModuleHom (Free m .snd) backwards (Free n .snd)
    IsLeftModuleHom.pres0 backwards-linear = injective
      (secEq equivalence (const 0r) ∙ sym (action-zero a))
    IsLeftModuleHom.pres+ backwards-linear x y = injective
      (secEq equivalence (λ i → x i + y i)
        ∙ sym (IsLeftModuleHom.pres+ (action-linear a) (backwards x) (backwards y)
          ∙ cong₂ (λ u v i → u i + v i) (secEq equivalence x) (secEq equivalence y)))
    IsLeftModuleHom.pres- backwards-linear x = injective
      (secEq equivalence (λ i → - x i)
        ∙ sym (IsLeftModuleHom.pres- (action-linear a) (backwards x)
          ∙ cong (λ u i → - u i) (secEq equivalence x)))
    IsLeftModuleHom.pres⋆ backwards-linear r x = injective
      (secEq equivalence (λ i → r · x i)
        ∙ sym (IsLeftModuleHom.pres⋆ (action-linear a) r (backwards x)
          ∙ cong (λ u i → r · u i) (secEq equivalence x)))

    backwards-hom : LeftModuleHom (Free m) (Free n)
    backwards-hom = backwards , backwards-linear

    inverse-matrix : Mat m n
    inverse-matrix = coefficients backwards-hom

    inverse-action : (y : Vector m) → action inverse-matrix y ≡ backwards y
    inverse-action y = sym (linear-is-matrix backwards-hom y)

    left-inverse : (x : Vector n) → action inverse-matrix (action a x) ≡ x
    left-inverse x = inverse-action (action a x) ∙ retEq equivalence x

    right-inverse : (y : Vector m) → action a (action inverse-matrix y) ≡ y
    right-inverse y = cong (action a) (inverse-action y) ∙ secEq equivalence y

    disk-equivalence : Disks.D n ≃ Disks.D m
    disk-equivalence = isoToEquiv (iso (disk-map a) (disk-map inverse-matrix)
      (λ d → Σ≡Prop Disks.pairwise-zero-isProp (right-inverse (d .fst)))
      (λ d → Σ≡Prop Disks.pairwise-zero-isProp (left-inverse (d .fst))))

    inverse-disk-equivalence : Disks.D m ≃ Disks.D n
    inverse-disk-equivalence = isoToEquiv (iso (disk-map inverse-matrix) (disk-map a)
      (λ d → Σ≡Prop Disks.pairwise-zero-isProp (left-inverse (d .fst)))
      (λ d → Σ≡Prop Disks.pairwise-zero-isProp (right-inverse (d .fst))))
