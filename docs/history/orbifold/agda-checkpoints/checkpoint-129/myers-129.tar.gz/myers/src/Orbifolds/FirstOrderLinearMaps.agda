{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderLinearMaps where

-- The actual category of finite free coordinate modules, its matrix
-- presentation, and the pointed first-order disk functor. Full
-- faithfulness of the disk functor additionally requires Kock--Lawvere.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
import Cubical.Algebra.Ring.BigOps as BO
import Cubical.Algebra.Matrix as Matrix
open import Cubical.Algebra.Module
open import Cubical.Algebra.Module.Instances.FinVec
open import Cubical.Categories.Category.Base
open import Cubical.Categories.Functor.Base
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.SquareZeroWeil as SW

PointedSets : (ℓ : Level) → Category (ℓ-suc ℓ) ℓ
Category.ob (PointedSets ℓ) = Σ[ A ∈ hSet ℓ ] A .fst
Category.Hom[_,_] (PointedSets ℓ) A B =
  Σ[ f ∈ (A .fst .fst → B .fst .fst) ] f (A .snd) ≡ B .snd
Category.id (PointedSets ℓ) = idfun _ , refl
Category._⋆_ (PointedSets ℓ) f g = g .fst ∘ f .fst , cong (g .fst) (f .snd) ∙ g .snd
Category.⋆IdL (PointedSets ℓ) {y = B} f = Σ≡Prop (λ _ → B .fst .snd _ _) refl
Category.⋆IdR (PointedSets ℓ) {y = B} f = Σ≡Prop (λ _ → B .fst .snd _ _) refl
Category.⋆Assoc (PointedSets ℓ) {w = B} f g h = Σ≡Prop (λ _ → B .fst .snd _ _) refl
Category.isSetHom (PointedSets ℓ) {y = B} =
  isSetΣ (isSetΠ (λ _ → B .fst .snd)) (λ _ → isProp→isSet (B .fst .snd _ _))

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  module S = BO.Sum (CommRing→Ring R)
  module K = BO.KroneckerDelta (CommRing→Ring R)
  module Disks = IL.Ring R

  Vector : ℕ → Type ℓ
  Vector n = FD.Fin n → R .fst

  Mat : ℕ → ℕ → Type ℓ
  Mat n m = Matrix.FinMatrix (R .fst) m n

  Free : ℕ → LeftModule (CommRing→Ring R) ℓ
  Free n = FinVecLeftModule (CommRing→Ring R) {n}

  column : {n : ℕ} → Vector n → Matrix.FinMatrix (R .fst) n 1
  column x i _ = x i

  action : {n m : ℕ} → Mat n m → Vector n → Vector m
  action a x i = S.∑ (λ j → a i j · x j)

  identity : {n : ℕ} → Mat n n
  identity = Matrix.oneFinMatrix (CommRing→Ring R)

  compose : {n m k : ℕ} → Mat n m → Mat m k → Mat n k
  compose a b = Matrix.mulFinMatrix (CommRing→Ring R) b a

  action-identity : {n : ℕ} (x : Vector n) → action identity x ≡ x
  action-identity x = funExt λ i → S.∑Mul1r _ x i

  action-compose : {n m k : ℕ} (a : Mat n m) (b : Mat m k) (x : Vector n)
    → action (compose a b) x ≡ action b (action a x)
  action-compose a b x = funExt λ i → cong (λ z → z i FD.zero)
    (sym (Matrix.mulFinMatrixAssoc (CommRing→Ring R) b a (column x)))

  action-zero : {n m : ℕ} (a : Mat n m) → action a (const 0r) ≡ const 0r
  action-zero a = funExt λ i → S.∑Mulr0 (a i)

  action-linear : {n m : ℕ} (a : Mat n m) → IsLeftModuleHom (Free n .snd) (action a) (Free m .snd)
  IsLeftModuleHom.pres0 (action-linear a) = action-zero a
  IsLeftModuleHom.pres+ (action-linear a) x y = funExt λ i →
    S.∑Ext (λ j → ·DistR+ (a i j) (x j) (y j))
    ∙ S.∑Split (λ j → a i j · x j) (λ j → a i j · y j)
  IsLeftModuleHom.pres- (action-linear a) x = funExt λ i →
    S.∑Ext (λ j → -DistR· (a i j) (x j)) ∙ S.∑Dist- (λ j → a i j · x j)
  IsLeftModuleHom.pres⋆ (action-linear a) r x = funExt λ i →
    S.∑Ext (λ j → ·Assoc (a i j) r (x j)
      ∙ cong (_· x j) (·Comm (a i j) r) ∙ sym (·Assoc r (a i j) (x j)))
    ∙ sym (S.∑Mulrdist r (λ j → a i j · x j))

  module-hom : {n m : ℕ} → Mat n m → LeftModuleHom (Free n) (Free m)
  module-hom a = action a , action-linear a

  module-laws-isProp : {n m : ℕ} (f : Vector n → Vector m)
    → isProp (IsLeftModuleHom (Free n .snd) f (Free m .snd))
  IsLeftModuleHom.pres0 (module-laws-isProp f p q i) = isSetΠ (λ _ → is-set) _ _ (p .IsLeftModuleHom.pres0) (q .IsLeftModuleHom.pres0) i
  IsLeftModuleHom.pres+ (module-laws-isProp f p q i) x y = isSetΠ (λ _ → is-set) _ _ (p .IsLeftModuleHom.pres+ x y) (q .IsLeftModuleHom.pres+ x y) i
  IsLeftModuleHom.pres- (module-laws-isProp f p q i) x = isSetΠ (λ _ → is-set) _ _ (p .IsLeftModuleHom.pres- x) (q .IsLeftModuleHom.pres- x) i
  IsLeftModuleHom.pres⋆ (module-laws-isProp f p q i) r x = isSetΠ (λ _ → is-set) _ _ (p .IsLeftModuleHom.pres⋆ r x) (q .IsLeftModuleHom.pres⋆ r x) i

  basis : {n : ℕ} → FD.Fin n → Vector n
  basis j i = K.δ i j

  vector-sum : {n k : ℕ} → (FD.Fin k → Vector n) → Vector n
  vector-sum v i = S.∑ (λ j → v j i)

  basis-expansion : {n : ℕ} (x : Vector n)
    → vector-sum (λ j i → x j · basis j i) ≡ x
  basis-expansion x = funExt λ i →
    S.∑Ext (λ j → ·Comm (x j) (K.δ i j)) ∙ S.∑Mul1r _ x i

  linear-preserves-sum : {n m : ℕ} (f : LeftModuleHom (Free n) (Free m))
    → (k : ℕ) (v : FD.Fin k → Vector n)
    → f .fst (vector-sum v) ≡ vector-sum (f .fst ∘ v)
  linear-preserves-sum f zero v = f .snd .IsLeftModuleHom.pres0
  linear-preserves-sum f (suc k) v =
    f .snd .IsLeftModuleHom.pres+ (v FD.zero) (vector-sum (v ∘ FD.suc))
    ∙ cong (λ y i → f .fst (v FD.zero) i + y i)
        (linear-preserves-sum f k (v ∘ FD.suc))

  coefficients : {n m : ℕ} → LeftModuleHom (Free n) (Free m) → Mat n m
  coefficients f i j = f .fst (basis j) i

  linear-is-matrix : {n m : ℕ} (f : LeftModuleHom (Free n) (Free m)) (x : Vector n)
    → f .fst x ≡ action (coefficients f) x
  linear-is-matrix {n} f x =
    cong (f .fst) (sym (basis-expansion x))
    ∙ linear-preserves-sum f n (λ j i → x j · basis j i)
    ∙ funExt (λ i → S.∑Ext (λ j →
      cong (λ y → y i) (f .snd .IsLeftModuleHom.pres⋆ (x j) (basis j))
      ∙ ·Comm (x j) (f .fst (basis j) i)))

  matrix≃module-hom : {n m : ℕ} → Mat n m ≃ LeftModuleHom (Free n) (Free m)
  matrix≃module-hom = isoToEquiv (iso module-hom coefficients
    (λ f → Σ≡Prop module-laws-isProp (funExt (λ x → sym (linear-is-matrix f x))))
    (λ a → funExt λ i → funExt λ j → S.∑Mulr1 _ (a i) j))

  MatrixCategory : Category ℓ-zero ℓ
  Category.ob MatrixCategory = ℕ
  Category.Hom[_,_] MatrixCategory = Mat
  Category.id MatrixCategory = identity
  Category._⋆_ MatrixCategory = compose
  Category.⋆IdL MatrixCategory a = Matrix.mulFinMatrixr1 (CommRing→Ring R) a
  Category.⋆IdR MatrixCategory a = Matrix.mulFinMatrix1r (CommRing→Ring R) a
  Category.⋆Assoc MatrixCategory a b c = Matrix.mulFinMatrixAssoc (CommRing→Ring R) c b a
  Category.isSetHom MatrixCategory = isSetΠ2 λ _ _ → is-set

  ModuleCategory : Category ℓ-zero ℓ
  Category.ob ModuleCategory = ℕ
  Category.Hom[_,_] ModuleCategory n m = LeftModuleHom (Free n) (Free m)
  Category.id ModuleCategory = idLeftModuleHom (Free _)
  Category._⋆_ ModuleCategory = compLeftModuleHom
  Category.⋆IdL ModuleCategory f = Σ≡Prop module-laws-isProp refl
  Category.⋆IdR ModuleCategory f = Σ≡Prop module-laws-isProp refl
  Category.⋆Assoc ModuleCategory f g h = Σ≡Prop module-laws-isProp refl
  Category.isSetHom ModuleCategory = isSetΣ
    (isSetΠ (λ _ → isSetΠ (λ _ → is-set)))
    (λ f → isProp→isSet (module-laws-isProp f))

  matrix-functor : Functor MatrixCategory ModuleCategory
  Functor.F-ob matrix-functor = idfun ℕ
  Functor.F-hom matrix-functor = module-hom
  Functor.F-id matrix-functor = Σ≡Prop module-laws-isProp (funExt action-identity)
  Functor.F-seq matrix-functor a b = Σ≡Prop module-laws-isProp (funExt (action-compose a b))

  matrix-fully-faithful : Functor.isFullyFaithful matrix-functor
  matrix-fully-faithful n m = matrix≃module-hom .snd

  disk-isSet : (n : ℕ) → isSet (Disks.D n)
  disk-isSet n = isSetΣ (isSetΠ (λ _ → is-set))
    (λ x → isProp→isSet (Disks.pairwise-zero-isProp x))

  disk-map : {n m : ℕ} → Mat n m → Disks.D n → Disks.D m
  disk-map {n} a x = action a (x .fst) , λ i j →
    SW.LinearProducts.linear-products-zero R n (x .fst) (x .snd)
      (action a (x .fst) i) (action a (x .fst) j)
      PT.∣ a i , refl ∣₁ PT.∣ a j , refl ∣₁

  disk-map-origin : {n m : ℕ} (a : Mat n m)
    → disk-map a (Disks.zeroD n) ≡ Disks.zeroD m
  disk-map-origin a = Σ≡Prop Disks.pairwise-zero-isProp (action-zero a)

  disk-functor : Functor MatrixCategory (PointedSets ℓ)
  Functor.F-ob disk-functor n = (Disks.D n , disk-isSet n) , Disks.zeroD n
  Functor.F-hom disk-functor a = disk-map a , disk-map-origin a
  Functor.F-id disk-functor = Σ≡Prop (λ _ → disk-isSet _ _ _)
    (funExt (λ x → Σ≡Prop Disks.pairwise-zero-isProp (action-identity (x .fst))))
  Functor.F-seq disk-functor a b = Σ≡Prop (λ _ → disk-isSet _ _ _)
    (funExt (λ x → Σ≡Prop Disks.pairwise-zero-isProp (action-compose a b (x .fst))))
