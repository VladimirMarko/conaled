{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularTransformationPresentations where

-- The recursive transformed skeleta are the literal realization of
-- their coinductive attachment presentation. Consequently maps out of
-- the transformed colimit are classified by the independently defined
-- recursive cocones, including every boundary and tower coherence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sequence using (Sequence)
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularTransformations as CT

module Theory {ℓ : Level} (O : CT.Operations ℓ)
    (A : Type ℓ) (P : CP.Presentation A) where
  open CT.Operations O using (F)
  module Construction = CT.Theory.Presentation O A P
  module Actual = CP.Realization (F A) (Construction.transformed-tail zero)

  state-path : (n : ℕ)
    → Actual.state n ≡ (Construction.TransformedStage n , Construction.transformed-tail n)
  state-path zero = refl
  state-path (suc n) = cong Actual.advance (state-path n)

  sequence-path : Actual.stages ≡ Construction.transformed-stages
  Sequence.obj (sequence-path i) n = state-path n i .fst
  Sequence.map (sequence-path i) {n} = PO.inl

  realization-equivalence : Actual.Realize ≃ Construction.Transformed
  realization-equivalence = pathToEquiv (cong SC.SeqColim sequence-path)

  module MappingOut {ℓw : Level} (W : Type ℓw) where
    module Recursive = Actual.MappingOut W
    open Recursive using (PartialCocone; Cocone) public

    mapping-universal : (Construction.Transformed → W) ≃ Cocone
    mapping-universal = compEquiv (preCompEquiv realization-equivalence)
      Recursive.mapping-universal

    assemble : Cocone → Construction.Transformed → W
    assemble = invEq mapping-universal

    assembly-isEquiv : isEquiv assemble
    assembly-isEquiv = invEquiv mapping-universal .snd
