{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispIndexedProducts where

-- Flat products at arbitrary same-universe crisply discrete indices.
-- The index-discreteness proof may be ordinary: only its propositional
-- restriction-equivalence certificate is promoted through derived rules.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Orbifolds.Crisp
open import Orbifolds.CrispProducts using (dependent-restriction; null-product)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as PP

module Family {@♭ ℓ : Level} (@♭ Ix : Type ℓ) (@♭ A : Ix → Type ℓ) where
  Full : Type ℓ
  Full = (i : Ix) → A i

  FlatFamily : Flat Ix → Type ℓ
  FlatFamily (box i) = Flat (A i)

  Product : Type ℓ
  Product = (u : Flat Ix) → FlatFamily u

  Restricted : Type ℓ
  Restricted = (u : Flat Ix) → A (counit u)

  restrict : Full → Restricted
  restrict f u = f (counit u)

  restriction-equivalence : (@♭ discrete-Ix : CrisplyDiscrete Ix) → Full ≃ Restricted
  restriction-equivalence discrete-Ix = restrict
    , dependent-restriction (counit , discrete-Ix) A

  unbox-section : Product → Restricted
  unbox-section p (box i) = counit (p (box i))

  restricted-comparison : Flat Restricted → Product
  restricted-comparison (box f) (box i) = box (f (box i))

  comparison : Flat Full → Product
  comparison (box f) (box i) = box (f i)

  unbox-comparison : (@♭ f : Restricted)
    → unbox-section (restricted-comparison (box f)) ≡ f
  unbox-comparison f = funExt λ { (box i) → refl }

  module WithCohesion
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ R : Type ℓ) (@♭ r₀ : R)
    (real-flat : (@♭ X : Type ℓ)
      → CrisplyDiscrete X ≃ isEquiv (const :> (X → (R → X)))) where
    module Identity = CI.Theory identity-rules
    module FlatTheory = CF.Theory flat-induction flat-computation
    module Propositions = PP.Context.WithIdentity R r₀ identity-rules

    crisp-box-counit : {@♭ X : Type ℓ} (@♭ u : Flat X) → box (counit u) ≡ u
    crisp-box-counit u = cong (flat-map counit)
      (sym (FlatTheory.crisp-duplicate-eta u)) ∙ map-counit-duplicate u

    null-fibre : (u : Flat Ix)
      → isEquiv (const :> (FlatFamily u → (R → FlatFamily u)))
    null-fibre (box i) = equivFun (real-flat (Flat (A i)))
      (FlatTheory.flat-is-discrete {A = A i})

    product-null : isEquiv (const :> (Product → (R → Product)))
    product-null = null-product null-fibre

    product-discrete : CrisplyDiscrete Product
    product-discrete = invEq (real-flat Product) product-null

    product-counit : Flat Product ≃ Product
    product-counit = counit , product-discrete

    backward : Product → Flat Restricted
    backward p = flat-map unbox-section (invEq product-counit p)

    rebox-section : (p : Flat Product)
      → restricted-comparison (flat-map unbox-section p) ≡ counit p
    rebox-section (box p) = funExt λ { (box i) → crisp-box-counit (p (box i)) }

    right-inverse : (p : Product) → restricted-comparison (backward p) ≡ p
    right-inverse p = rebox-section (invEq product-counit p) ∙ secEq product-counit p

    left-inverse : (f : Flat Restricted) → backward (restricted-comparison f) ≡ f
    left-inverse (box f) = cong (flat-map unbox-section)
      (retEq product-counit (box (restricted-comparison (box f))))
      ∙ Identity.box-path (unbox-section (restricted-comparison (box f))) f
          (unbox-comparison f)

    abstract
      restricted-isEquiv : isEquiv restricted-comparison
      restricted-isEquiv = isoToIsEquiv
        (iso restricted-comparison backward right-inverse left-inverse)

    restricted-equivalence : Flat Restricted ≃ Product
    restricted-equivalence = restricted-comparison , restricted-isEquiv

    module DiscreteIndex (discrete-Ix : CrisplyDiscrete Ix) where
      composite : Flat Full ≃ Product
      composite = compEquiv (Propositions.flat-equivalence real-flat restrict
          (dependent-restriction (counit , discrete-Ix) A))
        restricted-equivalence

      comparison-agrees : (f : Flat Full) → equivFun composite f ≡ comparison f
      comparison-agrees (box f) = funExt λ { (box i) → refl }

      comparison-isEquiv : isEquiv comparison
      comparison-isEquiv = subst isEquiv (funExt comparison-agrees) (snd composite)

      flat-product-equivalence : Flat Full ≃ Product
      flat-product-equivalence = comparison , comparison-isEquiv

module Functions {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ Ix : Type ℓ) where
  module Propositions = PP.Context R r₀
  open Propositions using (RealFlat) public

  module At (@♭ X : Type ℓ) where
    module Constants = Family Ix (λ _ → X)

    flatten : Constants.Product ≃ (Flat Ix → Flat X)
    flatten = equivΠCod λ { (box i) → idEquiv (Flat X) }

    comparison : Flat (Ix → X) → (Flat Ix → Flat X)
    comparison (box f) (box i) = box (f i)

    module Proof (real-flat : RealFlat) (discrete : CrisplyDiscrete Ix) where
      module Products = Constants.WithCohesion identity-rules flat-induction flat-computation
        R r₀ real-flat
      module Discrete = Products.DiscreteIndex discrete

      derived-equivalence : Flat (Ix → X) ≃ (Flat Ix → Flat X)
      derived-equivalence = Discrete.flat-product-equivalence ∙ₑ flatten

      comparison-agrees : (f : Flat (Ix → X)) → equivFun derived-equivalence f ≡ comparison f
      comparison-agrees (box f) = funExt λ { (box i) → refl }

      equivalence : Flat (Ix → X) ≃ (Flat Ix → Flat X)
      equivalence = comparison , subst isEquiv (funExt comparison-agrees) (derived-equivalence .snd)

  module Map {@♭ X Y : Type ℓ} (@♭ h : X → Y) where
    postcompose : (Ix → X) → (Ix → Y)
    postcompose f = h ∘ f

    pointwise : (Flat Ix → Flat X) → (Flat Ix → Flat Y)
    pointwise f i = flat-map h (f i)

    naturality : (f : Flat (Ix → X))
      → At.comparison Y (flat-map postcompose f) ≡ pointwise (At.comparison X f)
    naturality (box f) = funExt λ { (box i) → refl }

    external-power-preservation : RealFlat → CrisplyDiscrete Ix
      → isEquiv (flat-map h) → isEquiv (flat-map postcompose)
    external-power-preservation real-flat discrete equivalent =
      isEquiv[equivFunA≃B∘f]→isEquiv[f] (flat-map postcompose)
        (At.Proof.equivalence Y real-flat discrete)
        (subst isEquiv (sym (funExt naturality))
          (compEquiv (At.Proof.equivalence X real-flat discrete)
            (equivΠCod (λ _ → flat-map h , equivalent)) .snd))
