{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DecidableDiscrete where

-- Decidable equality implies crystalline nullity directly. With K and
-- the Principle of Constancy it also implies real-line nullity, via the
-- actual characteristic-function embedding into a power of the reals.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Functions.Embedding
open import Cubical.Relation.Nullary using (Discrete; yes; no)
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Penon
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallineEuclidean as CE
import Orbifolds.SyntheticField as SF

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R
  open CommRingStr (R .snd)
  module Field = SF.RingContext R
  module Euclidean = CE.Ring R

  generator-neighbor : (x : 𝔇) → Neighbors x zero𝔇
  generator-neighbor x not-equal = x .snd
    (λ p → not-equal (Σ≡Prop (λ _ → isPropNeighbors) p))

  module Set {X : Type ℓ} (decide : Discrete X) where
    neighboring-equality : {x y : X} → Neighbors x y → x ≡ y
    neighboring-equality {x} {y} near with decide x y
    ... | yes p = p
    ... | no p = Empty.rec (near p)

    decidable-crystalline : IsCrystalline X
    decidable-crystalline _ = fromIsEquiv const (isoToIsEquiv
      (iso const (λ f → f zero𝔇)
        (λ f → funExt λ d → sym
          (neighboring-equality (preservesNeighbors f (generator-neighbor d))))
        (λ _ → refl)))

    characteristic : X → X → Carrier
    characteristic x y with decide x y
    ... | yes _ = 1r
    ... | no _ = 0r

    characteristic-reflexive : (x : X) → characteristic x x ≡ 1r
    characteristic-reflexive x with decide x x
    ... | yes _ = refl
    ... | no p = Empty.rec (p refl)

    module Nontrivial (kock : Field.KockField) where
      characteristic-detects : (x y : X) → characteristic x y ≡ 1r → x ≡ y
      characteristic-detects x y path with decide x y
      ... | yes p = p
      ... | no p = Empty.rec (Field.nontrivial kock path)

      characteristic-injective : (x y : X) → characteristic x ≡ characteristic y → x ≡ y
      characteristic-injective x y p = sym (characteristic-detects y x
        (sym (funExt⁻ p x) ∙ characteristic-reflexive x))

      characteristic-embedding : X ↪ (X → Carrier)
      characteristic-embedding = characteristic ,
        injEmbedding (isSetΠ (λ _ → is-set)) (λ {x} {y} → characteristic-injective x y)

      decidable-shape-modal : Euclidean.PrincipleOfConstancy → IsShapeModal X
      decidable-shape-modal constancy =
        Euclidean.real-power-subspace-crystalline→shape-modal kock constancy
          characteristic-embedding decidable-crystalline
