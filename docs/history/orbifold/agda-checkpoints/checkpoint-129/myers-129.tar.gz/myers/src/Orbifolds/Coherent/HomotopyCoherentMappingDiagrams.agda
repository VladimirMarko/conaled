{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentMappingDiagrams where

-- The actual opposite mapping diagram of an arbitrary HCD. Both the
-- arrow chain and all cubical coordinates are reversed. Its one-face
-- law retains the complete prefix/suffix coherences.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position)
open import Orbifolds.Coherent.OuterCubicalFaces
open import Orbifolds.Coherent.OuterCoordinateReversal
open import Orbifolds.Coherent.ReversedCoordinateBlocks
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
import Orbifolds.Coherent.CoherentArrowReversal as Arrows
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations

module Mapping {ℓ : Level} (C : Category ℓ ℓ) (D : HCD.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (FExt : StrictFunctionExtensionality ℓ) where
  open Category C
  module OriginalDiagram = HCD.ForCategory C
  module D = OriginalDiagram.Diagram D
  module Original = Chains.Arrows C
  module Source = Chains.Arrows (Opposite C)
  module R = Arrows.Reversal C
  module HC = HCD.ForCategory (Opposite C)
  module Maps = Transformations.ForCategory (Opposite C)
  open Extensional E
  open StrictFunctionExtensionality FExt

  action : {Y : Type ℓ} (n : Dim) {x y : Obj}
    → Source.Chain n x y → (D.Value x → Y) → Cube n (D.Value y → Y)
  action n c h = abstract-cube n λ xs a →
    h (evaluate n (D.action n (R.reverse n c) a) (reverse-coordinates n xs))

  action-point : {Y : Type ℓ} (n : Dim) {x y : Obj} (c : Source.Chain n x y)
    (h : D.Value x → Y) (xs : Coordinates n) (a : D.Value y)
    → outer (evaluate n (action n c h) xs a)
      ≡ˢ outer (h (evaluate n (D.action n (R.reverse n c) a) (reverse-coordinates n xs)))
  action-point {Y} n {y = y} c h xs a = strict-cong (λ (f : Outer (D.Value y → Y)) → outer (inner f a))
    (evaluate-abstract n {X = D.Value y → Y}
      (λ ys a → h (evaluate n (D.action n (R.reverse n c) a) (reverse-coordinates n ys))) xs)

  face-point : {Y : Type ℓ} (n : Dim) (p : Position (osuc n)) (i : I)
    {x y : Obj} (c : Source.Chain (osuc n) x y) (h : D.Value x → Y)
    (xs : Coordinates n) (a : D.Value y)
    → outer (evaluate n (coordinate-face n p i (action (osuc n) c h)) xs a)
      ≡ˢ outer (h (evaluate n
        (coordinate-face n (reverse-position n p) i (D.action (osuc n) (R.reverse (osuc n) c) a))
        (reverse-coordinates n xs)))
  face-point n p i c h xs a = strict-trans
    (strict-cong (λ f → outer (inner f a)) (face-evaluation n p i (action (osuc n) c h) xs))
    (strict-trans
      (action-point (osuc n) c h (insert n p i xs) a)
      (strict-trans
        (strict-cong (λ ys → outer (h (evaluate (osuc n) (D.action (osuc n) (R.reverse (osuc n) c) a) ys)))
          (reverse-insert n p i xs))
        (strict-cong (λ b → outer (h (inner b)))
          (strict-sym (face-evaluation n (reverse-position n p) i
            (D.action (osuc n) (R.reverse (osuc n) c) a) (reverse-coordinates n xs))))))

  evaluate-both : (s p : Dim) {x y : Obj} → R.Both s p x y
    → Coordinates s → Coordinates p → D.Value x → D.Value y
  evaluate-both s p z ss ps a = evaluate s
    (D.action s (z .snd .fst) (evaluate p (D.action p (z .snd .snd) a) ps)) ss

  changed-evaluation : {s s' p p' : Dim} (es : s ≡ˢ s') (ep : p ≡ˢ p')
    {x y : Obj} (z : R.Both s p x y) (ss : Coordinates s) (ps : Coordinates p) (a : D.Value x)
    → outer (evaluate-both s' p' (R.change-split es ep z)
        (cast-coordinates es ss) (cast-coordinates ep ps) a)
      ≡ˢ outer (evaluate-both s p z ss ps a)
  changed-evaluation reflˢ reflˢ z ss ps a = reflˢ

  reversed-composite : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (c : Source.Chain (osuc n) x y) (xs : Coordinates n) (a : D.Value y)
    → outer (evaluate n (tensor-action n (reverse-position n p)
        (D.action (suffix-degree n (reverse-position n p))
          (Original.split-suffix n (reverse-position n p) (R.reverse (osuc n) c)))
        (D.action (prefix-degree n (reverse-position n p))
          (Original.split-prefix n (reverse-position n p) (R.reverse (osuc n) c))) a)
        (reverse-coordinates n xs))
      ≡ˢ outer (evaluate (prefix-degree n p)
        (D.action (prefix-degree n p) (R.reverse (prefix-degree n p) (Source.split-prefix n p c))
          (evaluate (suffix-degree n p)
            (D.action (suffix-degree n p) (R.reverse (suffix-degree n p) (Source.split-suffix n p c)) a)
            (reverse-coordinates (suffix-degree n p) (suffix-coordinates n p xs))))
        (reverse-coordinates (prefix-degree n p) (prefix-coordinates n p xs)))
  reversed-composite n p c xs a = strict-trans
    (tensor-evaluation n (reverse-position n p)
      (D.action (suffix-degree n (reverse-position n p))
        (Original.split-suffix n (reverse-position n p) (R.reverse (osuc n) c)))
      (D.action (prefix-degree n (reverse-position n p))
        (Original.split-prefix n (reverse-position n p) (R.reverse (osuc n) c))) a
      (reverse-coordinates n xs))
    (strict-trans
      (strict-sym (changed-evaluation (reverse-suffix-degree n p) (reverse-prefix-degree n p)
        (Original.split n (reverse-position n p) (R.reverse (osuc n) c))
        (suffix-coordinates n (reverse-position n p) (reverse-coordinates n xs))
        (prefix-coordinates n (reverse-position n p) (reverse-coordinates n xs)) a))
      (strict-trans
        (strict-cong (λ ss → outer (evaluate-both (prefix-degree n p) (suffix-degree n p)
          (R.reversed-split n p c) ss
          (cast-coordinates (reverse-prefix-degree n p)
            (prefix-coordinates n (reverse-position n p) (reverse-coordinates n xs))) a))
          (reverse-suffix-coordinates n p xs))
        (strict-trans
          (strict-cong (λ ps → outer (evaluate-both (prefix-degree n p) (suffix-degree n p)
            (R.reversed-split n p c)
            (reverse-coordinates (prefix-degree n p) (prefix-coordinates n p xs)) ps a))
            (reverse-prefix-coordinates n p xs))
          (strict-cong (λ z → outer (evaluate-both (prefix-degree n p) (suffix-degree n p) (inner z)
            (reverse-coordinates (prefix-degree n p) (prefix-coordinates n p xs))
            (reverse-coordinates (suffix-degree n p) (suffix-coordinates n p xs)) a))
            (R.reverse-split n p c)))))

  tensor-point : {Y : Type ℓ} (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (c : Source.Chain (osuc n) x y) (h : D.Value x → Y) (xs : Coordinates n) (a : D.Value y)
    → outer (evaluate n (tensor-action n p
        (action (suffix-degree n p) (Source.split-suffix n p c))
        (action (prefix-degree n p) (Source.split-prefix n p c)) h) xs a)
      ≡ˢ outer (h (evaluate (prefix-degree n p)
        (D.action (prefix-degree n p) (R.reverse (prefix-degree n p) (Source.split-prefix n p c))
          (evaluate (suffix-degree n p)
            (D.action (suffix-degree n p) (R.reverse (suffix-degree n p) (Source.split-suffix n p c)) a)
            (reverse-coordinates (suffix-degree n p) (suffix-coordinates n p xs))))
        (reverse-coordinates (prefix-degree n p) (prefix-coordinates n p xs))))
  tensor-point n p c h xs a = strict-trans
    (strict-cong (λ f → outer (inner f a))
      (tensor-evaluation n p (action (suffix-degree n p) (Source.split-suffix n p c))
        (action (prefix-degree n p) (Source.split-prefix n p c)) h xs))
    (strict-trans
      (action-point (suffix-degree n p) (Source.split-suffix n p c)
        (evaluate (prefix-degree n p) (action (prefix-degree n p) (Source.split-prefix n p c) h)
          (prefix-coordinates n p xs)) (suffix-coordinates n p xs) a)
      (action-point (prefix-degree n p) (Source.split-prefix n p c) h (prefix-coordinates n p xs)
        (evaluate (suffix-degree n p)
          (D.action (suffix-degree n p) (R.reverse (suffix-degree n p) (Source.split-suffix n p c)) a)
          (reverse-coordinates (suffix-degree n p) (suffix-coordinates n p xs)))))

  Into : Type ℓ → HC.Diagram
  HC.Diagram.Value (Into Y) x = D.Value x → Y
  HC.Diagram.action (Into Y) n = action n
  HC.Diagram.zero-face (Into Y) n p c h = cube-extensionality n λ xs → function-ext λ a → strict-trans
    (face-point n p i0 c h xs a)
    (strict-trans
      (strict-cong (λ q → outer (h (evaluate n (inner q) (reverse-coordinates n xs))))
        (D.zero-face n (reverse-position n p) (R.reverse (osuc n) c) a))
      (strict-trans
        (strict-cong (λ c' → outer (h (evaluate n (D.action n (inner c') a) (reverse-coordinates n xs))))
          (strict-sym (R.reverse-face n p c)))
        (strict-sym (action-point n (Source.face n p c) h xs a))))
  HC.Diagram.one-face (Into Y) n p c h = cube-extensionality n λ xs → function-ext λ a → strict-trans
    (face-point n p i1 c h xs a)
    (strict-trans
      (strict-cong (λ q → outer (h (evaluate n (inner q) (reverse-coordinates n xs))))
        (D.one-face n (reverse-position n p) (R.reverse (osuc n) c) a))
      (strict-trans
        (strict-cong (λ b → outer (h (inner b))) (reversed-composite n p c xs a))
        (strict-sym (tensor-point n p c h xs a))))
  HC.Diagram.unit (Into Y) x i h a = h (D.unit x i a)

  Postcompose : {Y Z : Type ℓ} → (Y → Z) → Maps.Transformation (Into Y) (Into Z)
  Maps.Transformation.component (Postcompose k) x h = k ∘ h
  Maps.Transformation.naturality (Postcompose k) n c h = cube-extensionality n λ xs → function-ext λ a → strict-trans
    (strict-cong (λ f → outer (inner f a)) (map-evaluation n (λ f → k ∘ f) (action n c h) xs))
    (strict-trans
      (strict-cong (λ z → outer (k (inner z))) (action-point n c h xs a))
      (strict-sym (action-point n c (k ∘ h) xs a)))

  postcompose-identity : {Y : Type ℓ} (x : Obj) (h : D.Value x → Y)
    → outer (Maps.Transformation.component (Postcompose (idfun Y)) x h) ≡ˢ outer h
  postcompose-identity x h = reflˢ

  postcompose-compose : {Y Z W : Type ℓ} (f : Y → Z) (g : Z → W) (x : Obj) (h : D.Value x → Y)
    → outer (Maps.Transformation.component (Postcompose g) x (Maps.Transformation.component (Postcompose f) x h))
      ≡ˢ outer (Maps.Transformation.component (Postcompose (g ∘ f)) x h)
  postcompose-compose f g x h = reflˢ
