{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps where

-- The actual full bar-colimit map induced by a coherent transformation.
-- It is constructed from actual cocone restriction and the checked
-- mapping universal property; its complete cocone triangle is proved.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Colimits
import Cubical.HITs.SequentialColimit as SC

module Map {ℓ : Level} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module H = HC.ForCategory C
  module D = H.Diagram D using (Value)
  module G = H.Diagram G using (Value)
  module Maps = Transformations.ForCategory C
  module α = Maps.Transformation α using (component)
  module Source = Colimits.Construction C D E F using (Colimit; canonical-cocone; module MappingOut)
  module Target = Colimits.Construction C G E F using (Colimit; canonical-cocone; module MappingOut)

  restriction : Target.MappingOut.Cocone Target.Colimit → Source.MappingOut.Cocone Target.Colimit
  restriction = Restriction.Restriction.restrict C D G α E F Target.Colimit

  partial-restriction : (n : ℕ)
    → Target.MappingOut.PartialCocone Target.Colimit n → Source.MappingOut.PartialCocone Target.Colimit n
  partial-restriction = Restriction.Restriction.partial-map C D G α E F Target.Colimit

  abstract
    induced : Source.Colimit → Target.Colimit
    induced = Source.MappingOut.assemble Target.Colimit (restriction Target.canonical-cocone)

    canonical-triangle : PathP (λ _ → Source.MappingOut.Cocone Target.Colimit)
      (Source.MappingOut.restrict Target.Colimit induced) (restriction Target.canonical-cocone)
    canonical-triangle = secEq (Source.MappingOut.universal Target.Colimit)
      (restriction Target.canonical-cocone)

  source-generator : (x : Category.Obj C) → D.Value x → Source.Colimit
  source-generator x a = SC.incl {n = zero} (x , a)

  target-generator : (x : Category.Obj C) → G.Value x → Target.Colimit
  target-generator x a = SC.incl {n = zero} (x , a)

  generator-computation : (x : Category.Obj C) (a : D.Value x)
    → induced (source-generator x a) ≡ target-generator x (α.component x a)
  generator-computation x a = cong (λ c → c .fst zero x a) canonical-triangle

  stage-computation : (n : ℕ)
    → Source.MappingOut.stage-universal Target.Colimit n .fst (induced ∘ SC.incl {n = n})
      ≡ partial-restriction n (Target.MappingOut.stage-universal Target.Colimit n .fst (SC.incl {n = n}))
  stage-computation n = cong (λ c → c .fst n) canonical-triangle
