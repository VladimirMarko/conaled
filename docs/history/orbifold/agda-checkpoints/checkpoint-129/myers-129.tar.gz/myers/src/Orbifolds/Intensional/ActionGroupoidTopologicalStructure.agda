{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ActionGroupoidTopologicalStructure where

-- Literal categorical unit, inverse and composition maps are continuous.
-- The actual composable carrier is equivalent to the ordinary pullback
-- carrier and to G x (G x X). Its continuous-cone property is transferred
-- from the proved labelled pullback; it is not a topology or UP premise.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity hiding (lift)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Product; OpenFragment )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
import Orbifolds.Intensional.ActionGroupoids as Groupoids
import Orbifolds.Intensional.OpenSubspaces as OS
import Orbifolds.Intensional.EquivalenceTopologyTransport as Transport
import Orbifolds.Intensional.LabelledActionPullbackTopology as Labelled

module Action {ℓ : Level} {G X : Set ℓ}
    (setG : isSet G) (setX : isSet X)
    (unit : G) (multiply : G → G → G) (inverse : G → G)
    (unit-left : (g : G) → multiply unit g ≡ g)
    (unit-right : (g : G) → multiply g unit ≡ g)
    (multiply-associative : (g h k : G)
      → multiply (multiply g h) k ≡ multiply g (multiply h k))
    (inverse-left : (g : G) → multiply (inverse g) g ≡ unit)
    (inverse-right : (g : G) → multiply g (inverse g) ≡ unit)
    (act : G → X → X)
    (act-unit : (x : X) → act unit x ≡ x)
    (act-multiply : (g h : G) (x : X)
      → act (multiply g h) x ≡ act g (act h x)) where

  module Algebra = Groupoids.Action setG setX unit multiply inverse
    unit-left unit-right multiply-associative inverse-left inverse-right
    act act-unit act-multiply

  unit-map : X → Algebra.ArrowSpace
  unit-map x = x , x , Algebra.identity {x}

  inverse-map : Algebra.ArrowSpace → Algebra.ArrowSpace
  inverse-map (x , y , f) = y , x , Algebra.inverse-arrow {x} {y} f

  Composable : Set ℓ
  Composable = Σ X (λ x → Σ X (λ y → Σ X (λ z →
    Product (Algebra.Hom y z) (Algebra.Hom x y))))

  first-arrow second-arrow : Composable → Algebra.ArrowSpace
  first-arrow (x , y , z , k , f) = x , y , f
  second-arrow (x , y , z , k , f) = y , z , k

  composable-square : (c : Composable)
    → Algebra.target (first-arrow c) ≡ Algebra.source (second-arrow c)
  composable-square (x , y , z , k , f) = refl

  compose-map : Composable → Algebra.ArrowSpace
  compose-map (x , y , z , k , f) = x , z , Algebra.compose {x} {y} {z} k f

  PullbackCarrier : Set ℓ
  PullbackCarrier = Σ Algebra.ArrowSpace (λ a → Σ Algebra.ArrowSpace
    (λ b → Algebra.target a ≡ Algebra.source b))

  to-pullback : Composable → PullbackCarrier
  to-pullback c = first-arrow c , second-arrow c , composable-square c

  from-pullback : PullbackCarrier → Composable
  from-pullback ((x , y , f) , (w , z , k) , p) =
    x , y , z , subst (λ t → Algebra.Hom t z) (sym p) k , f

  pullback-section : (p : PullbackCarrier) → to-pullback (from-pullback p) ≡ p
  pullback-section ((x , y , f) , (w , z , k) , p) =
    J (λ w p → (k : Algebra.Hom w z) →
        to-pullback (from-pullback ((x , y , f) , (w , z , k) , p))
          ≡ ((x , y , f) , (w , z , k) , p))
      (λ k → refl) p k

  pullback-retraction : (c : Composable) → from-pullback (to-pullback c) ≡ c
  pullback-retraction (x , y , z , k , f) = refl

  composable-pullback-equivalence : Equiv Composable PullbackCarrier
  composable-pullback-equivalence = equiv to-pullback from-pullback
    pullback-section pullback-retraction

  PairCoordinates : Set ℓ
  PairCoordinates = Product G (Product G X)

  pair-coordinates : Composable → PairCoordinates
  pair-coordinates (x , y , z , k , f) = fst k , fst f , x

  from-pair-coordinates : PairCoordinates → Composable
  from-pair-coordinates (h , g , x) =
    x , act g x , act h (act g x) , (h , refl) , (g , refl)

  pair-section : (p : PairCoordinates)
    → pair-coordinates (from-pair-coordinates p) ≡ p
  pair-section (h , g , x) = refl

  pair-retraction : (c : Composable)
    → from-pair-coordinates (pair-coordinates c) ≡ c
  pair-retraction (x , y , z , (h , q) , (g , p)) =
    J (λ y p → (z : X) (q : act h y ≡ z) →
        from-pair-coordinates (h , g , x) ≡ (x , y , z , (h , q) , (g , p)))
      (λ z q → J
        (λ z q → from-pair-coordinates (h , g , x)
          ≡ (x , act g x , z , (h , q) , (g , refl)))
        refl q)
      p z q

  composable-coordinate-equivalence : Equiv Composable PairCoordinates
  composable-coordinate-equivalence = equiv pair-coordinates from-pair-coordinates
    pair-section pair-retraction

  coordinate-unit : X → Product G X
  coordinate-unit x = unit , x

  coordinate-inverse : Product G X → Product G X
  coordinate-inverse (g , x) = inverse g , act g x

  coordinate-first coordinate-second coordinate-compose : PairCoordinates → Product G X
  coordinate-first = snd
  coordinate-second p = fst p , act (fst (snd p)) (snd (snd p))
  coordinate-compose p = multiply (fst p) (fst (snd p)) , snd (snd p)

  unit-comparison : (x : X) → Algebra.coordinates (unit-map x) ≡ coordinate-unit x
  unit-comparison x = refl

  inverse-comparison : (a : Algebra.ArrowSpace)
    → Algebra.coordinates (inverse-map a) ≡ coordinate-inverse (Algebra.coordinates a)
  inverse-comparison (x , y , g , p) = cong (λ z → inverse g , z) (sym p)

  first-comparison : (c : Composable)
    → Algebra.coordinates (first-arrow c) ≡ coordinate-first (pair-coordinates c)
  first-comparison (x , y , z , k , f) = refl

  second-comparison : (c : Composable)
    → Algebra.coordinates (second-arrow c) ≡ coordinate-second (pair-coordinates c)
  second-comparison (x , y , z , (h , q) , (g , p)) =
    cong (λ w → h , w) (sym p)

  compose-comparison : (c : Composable)
    → Algebra.coordinates (compose-map c) ≡ coordinate-compose (pair-coordinates c)
  compose-comparison (x , y , z , (h , q) , (g , p)) = refl

  arrow-coordinate-injective : {a b : Algebra.ArrowSpace}
    → Algebra.coordinates a ≡ Algebra.coordinates b → a ≡ b
  arrow-coordinate-injective {a} {b} p =
    sym (Algebra.coordinates-retraction a)
    ∙ cong Algebra.from-coordinates p ∙ Algebra.coordinates-retraction b

  module Topological (OX : OpenFragment X)
      (act-continuous : (g : G) → Continuous OX OX (act g)) where

    module Coordinate = Labelled.Construction setG OX act act-continuous
    module ArrowTransport = Transport.Transport
      Algebra.arrow-space-equivalence Coordinate.arrowTopology
    module PairTransport = Transport.Transport
      composable-coordinate-equivalence Coordinate.pairTopology

    arrowTopology : OpenFragment Algebra.ArrowSpace
    arrowTopology = ArrowTransport.topology

    pairTopology : OpenFragment Composable
    pairTopology = PairTransport.topology

    arrow-homeomorphism : OS.Homeomorphism arrowTopology Coordinate.arrowTopology
    arrow-homeomorphism = ArrowTransport.homeomorphism

    pair-homeomorphism : OS.Homeomorphism pairTopology Coordinate.pairTopology
    pair-homeomorphism = PairTransport.homeomorphism

    source-continuous : Continuous arrowTopology OX Algebra.source
    source-continuous = Labelled.continuous-pointwise arrowTopology OX
      (λ a → Coordinate.source (Algebra.coordinates a)) Algebra.source
      (λ a → sym (Algebra.source-coordinates a))
      (OS.compose-continuous arrowTopology Coordinate.arrowTopology OX
        Algebra.coordinates Coordinate.source ArrowTransport.forward-continuous
        Coordinate.source-continuous)

    target-continuous : Continuous arrowTopology OX Algebra.target
    target-continuous = Labelled.continuous-pointwise arrowTopology OX
      (λ a → Coordinate.target (Algebra.coordinates a)) Algebra.target
      (λ a → sym (Algebra.target-coordinates a))
      (OS.compose-continuous arrowTopology Coordinate.arrowTopology OX
        Algebra.coordinates Coordinate.target ArrowTransport.forward-continuous
        Coordinate.target-continuous)

    through-arrow-coordinates : {Z : Set ℓ} (OZ : OpenFragment Z)
      (f : Z → Algebra.ArrowSpace) (coordinate-f : Z → Coordinate.Arrows)
      → ((z : Z) → Algebra.coordinates (f z) ≡ coordinate-f z)
      → Continuous OZ Coordinate.arrowTopology coordinate-f
      → Continuous OZ arrowTopology f
    through-arrow-coordinates OZ f coordinate-f equal continuous =
      Labelled.continuous-pointwise OZ arrowTopology
        (λ z → Algebra.from-coordinates (coordinate-f z)) f
        (λ z → sym (cong Algebra.from-coordinates (equal z))
          ∙ Algebra.coordinates-retraction (f z))
        (OS.compose-continuous OZ Coordinate.arrowTopology arrowTopology
          coordinate-f Algebra.from-coordinates continuous ArrowTransport.backward-continuous)

    coordinate-unit-continuous : Continuous OX Coordinate.arrowTopology coordinate-unit
    coordinate-unit-continuous U open-U = open-U unit

    coordinate-inverse-continuous :
      Continuous Coordinate.arrowTopology Coordinate.arrowTopology coordinate-inverse
    coordinate-inverse-continuous U open-U g =
      act-continuous g (preimage (λ x → inverse g , x) U) (open-U (inverse g))

    coordinate-compose-continuous :
      Continuous Coordinate.pairTopology Coordinate.arrowTopology coordinate-compose
    coordinate-compose-continuous U open-U h g = open-U (multiply h g)

    unit-continuous : Continuous OX arrowTopology unit-map
    unit-continuous = through-arrow-coordinates OX unit-map coordinate-unit
      unit-comparison coordinate-unit-continuous

    inverse-continuous : Continuous arrowTopology arrowTopology inverse-map
    inverse-continuous = through-arrow-coordinates arrowTopology inverse-map
      (λ a → coordinate-inverse (Algebra.coordinates a)) inverse-comparison
      (OS.compose-continuous arrowTopology Coordinate.arrowTopology Coordinate.arrowTopology
        Algebra.coordinates coordinate-inverse ArrowTransport.forward-continuous
        coordinate-inverse-continuous)

    first-continuous : Continuous pairTopology arrowTopology first-arrow
    first-continuous = through-arrow-coordinates pairTopology first-arrow
      (λ c → Coordinate.first (pair-coordinates c)) first-comparison
      (OS.compose-continuous pairTopology Coordinate.pairTopology Coordinate.arrowTopology
        pair-coordinates Coordinate.first PairTransport.forward-continuous
        Coordinate.first-continuous)

    second-continuous : Continuous pairTopology arrowTopology second-arrow
    second-continuous = through-arrow-coordinates pairTopology second-arrow
      (λ c → Coordinate.second (pair-coordinates c)) second-comparison
      (OS.compose-continuous pairTopology Coordinate.pairTopology Coordinate.arrowTopology
        pair-coordinates Coordinate.second PairTransport.forward-continuous
        Coordinate.second-continuous)

    compose-continuous : Continuous pairTopology arrowTopology compose-map
    compose-continuous = through-arrow-coordinates pairTopology compose-map
      (λ c → coordinate-compose (pair-coordinates c)) compose-comparison
      (OS.compose-continuous pairTopology Coordinate.pairTopology Coordinate.arrowTopology
        pair-coordinates coordinate-compose PairTransport.forward-continuous
        coordinate-compose-continuous)

    module Cone {Z : Set ℓ} (OZ : OpenFragment Z)
        (u v : Z → Algebra.ArrowSpace)
        (u-continuous : Continuous OZ arrowTopology u)
        (v-continuous : Continuous OZ arrowTopology v)
        (commute : (z : Z) → Algebra.target (u z) ≡ Algebra.source (v z)) where

      coordinate-u coordinate-v : Z → Coordinate.Arrows
      coordinate-u z = Algebra.coordinates (u z)
      coordinate-v z = Algebra.coordinates (v z)

      coordinate-u-continuous : Continuous OZ Coordinate.arrowTopology coordinate-u
      coordinate-u-continuous = OS.compose-continuous OZ arrowTopology Coordinate.arrowTopology
        u Algebra.coordinates u-continuous ArrowTransport.forward-continuous

      coordinate-v-continuous : Continuous OZ Coordinate.arrowTopology coordinate-v
      coordinate-v-continuous = OS.compose-continuous OZ arrowTopology Coordinate.arrowTopology
        v Algebra.coordinates v-continuous ArrowTransport.forward-continuous

      coordinate-commute : (z : Z)
        → Coordinate.target (coordinate-u z) ≡ Coordinate.source (coordinate-v z)
      coordinate-commute z = sym (Algebra.target-coordinates (u z))
        ∙ commute z ∙ Algebra.source-coordinates (v z)

      module Actual = Coordinate.Cone OZ coordinate-u coordinate-v
        coordinate-u-continuous coordinate-v-continuous coordinate-commute

      lift : Z → Composable
      lift z = from-pair-coordinates (Actual.lift z)

      lift-continuous : Continuous OZ pairTopology lift
      lift-continuous = OS.compose-continuous OZ Coordinate.pairTopology pairTopology
        Actual.lift from-pair-coordinates Actual.lift-continuous PairTransport.backward-continuous

      lift-first : (z : Z) → first-arrow (lift z) ≡ u z
      lift-first z = arrow-coordinate-injective
        (first-comparison (lift z)
          ∙ cong Coordinate.first (pair-section (Actual.lift z)) ∙ Actual.lift-first z)

      lift-second : (z : Z) → second-arrow (lift z) ≡ v z
      lift-second z = arrow-coordinate-injective
        (second-comparison (lift z)
          ∙ cong Coordinate.second (pair-section (Actual.lift z)) ∙ Actual.lift-second z)

      lift-unique : (k : Z → Composable)
        → ((z : Z) → first-arrow (k z) ≡ u z)
        → ((z : Z) → second-arrow (k z) ≡ v z)
        → (z : Z) → k z ≡ lift z
      lift-unique k first-law second-law z = sym (pair-retraction (k z))
        ∙ cong from-pair-coordinates
          (Actual.lift-unique (λ w → pair-coordinates (k w))
            (λ w → sym (first-comparison (k w)) ∙ cong Algebra.coordinates (first-law w))
            (λ w → sym (second-comparison (k w)) ∙ cong Algebra.coordinates (second-law w)) z)

-- No finite enumeration, compactness, EM, FunExt, or proof-irrelevance of
-- IsOpen is used. The continuous-cone theorem proves unique underlying
-- maps pointwise; it does not assert equality of raw continuity evidence.
