{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.Coequalizers where

-- A genuine homotopy coequalizer. No set-truncation constructor occurs.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Univalence using (EquivJ)
open import Cubical.Foundations.GroupoidLaws using (rUnit)
open import Cubical.Data.Sigma

data Coeq {ℓa ℓb : Level} {A : Type ℓa} {B : Type ℓb}
    (f g : A → B) : Type (ℓ-max ℓa ℓb) where
  point : B → Coeq f g
  edge : (a : A) → point (f a) ≡ point (g a)

module Mapping {ℓa ℓb ℓy : Level} {A : Type ℓa} {B : Type ℓb}
    (f g : A → B) (Y : Type ℓy) where
  Cocone : Type (ℓ-max (ℓ-max ℓa ℓb) ℓy)
  Cocone = Σ[ b ∈ (B → Y) ] b ∘ f ≡ b ∘ g

  restrict : (Coeq f g → Y) → Cocone
  restrict h = h ∘ point , λ i a → h (edge a i)

  glue : Cocone → Coeq f g → Y
  glue (b , p) (point x) = b x
  glue (b , p) (edge a i) = p i a

  universal : (Coeq f g → Y) ≃ Cocone
  universal = isoToEquiv (iso restrict glue (λ _ → refl) eta)
    where
    eta : (h : Coeq f g → Y) → glue (restrict h) ≡ h
    eta h i (point b) = h (point b)
    eta h i (edge a j) = h (edge a j)

-- The conjugacy form needed for the id/successor presentation of a
-- sequential colimit. Its forward map is explicitly defined on points
-- and edges; equivalence induction proves it is an equivalence.
module Endomorphism {ℓ : Level} {A B : Type ℓ}
    (s : A → A) (t : B → B) (e : A → B)
    (commute : (a : A) → e (s a) ≡ t (e a)) where
  Source : Type ℓ
  Source = Coeq (idfun A) s

  Target : Type ℓ
  Target = Coeq (idfun B) t

  map : Source → Target
  map (point a) = point (e a)
  map (edge a i) = (edge (e a) ∙ sym (cong point (commute a))) i

module EndomorphismIdentity {ℓ : Level} {A : Type ℓ} (s : A → A) where
  module Identity = Endomorphism s s (idfun A) (λ _ → refl)

  map-identity : (x : Identity.Source) → Identity.map x ≡ x
  map-identity (point a) = refl
  map-identity (edge a i) j = sym (rUnit (edge a)) j i

  map-isEquiv : isEquiv Identity.map
  map-isEquiv = subst isEquiv (sym (funExt map-identity)) (idEquiv _ .snd)

endomorphism-map-isEquiv : {ℓ : Level} {A B : Type ℓ}
  (e : A ≃ B) (s : A → A) (t : B → B)
  (commute : (a : A) → equivFun e (s a) ≡ t (equivFun e a))
  → isEquiv (Endomorphism.map s t (equivFun e) commute)
endomorphism-map-isEquiv {B = B} = EquivJ
  (λ A e → (s : A → A) (t : B → B)
    (commute : (a : A) → equivFun e (s a) ≡ t (equivFun e a))
    → isEquiv (Endomorphism.map s t (equivFun e) commute))
  (λ s t commute → J
    (λ t p → isEquiv (Endomorphism.map s t (idfun B) (funExt⁻ p)))
    (EndomorphismIdentity.map-isEquiv s) (funExt commute))

endomorphism-equivalence : {ℓ : Level} {A B : Type ℓ}
  (e : A ≃ B) (s : A → A) (t : B → B)
  (commute : (a : A) → equivFun e (s a) ≡ t (equivFun e a))
  → Coeq (idfun A) s ≃ Coeq (idfun B) t
endomorphism-equivalence e s t commute =
  Endomorphism.map s t (equivFun e) commute , endomorphism-map-isEquiv e s t commute
