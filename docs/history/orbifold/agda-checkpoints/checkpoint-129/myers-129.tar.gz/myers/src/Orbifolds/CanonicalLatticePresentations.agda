{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CanonicalLatticePresentations where

-- Every actual finite-free lattice in the canonical complex line is
-- merely carried to an actual standard lattice by a complex unit.
-- The integral basis and metric radius are taken from the literal
-- lattice structure; real spanning is not added as an assumption.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ)
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
import Cubical.Algebra.Group.Subgroup as SG
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexLatticeStructures as LS
import Orbifolds.ComplexIntegerLinearMaps as IL
import Orbifolds.IntegerPairMatrices as IP
import Orbifolds.IntegralComplexBases as IB
import Orbifolds.StandardComplexLattice as ST

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  module L = LS.Geometry R kock order compatibility
  open L using (module C; module Lines; module Forms; module H; module Standard; module Metric; module Canonical; module Rationals)
  module Linear = IL.Ring R
  module Presentations = IB.Geometry R kock order compatibility
  open C using (Complex; _*c_)

  Normalized : Canonical.FiniteFreeLattice → Type ℓ
  Normalized Λ = Σ[ τ ∈ H.UpperHalfPlane ]
    Σ[ scalar ∈ Complex ] Σ[ inverse ∈ Complex ]
      (scalar *c inverse ≡ C.one) ×
      ((z : Complex) → Standard.Member τ z ≃ Canonical.Member (Λ .fst) (scalar *c z))

  module Basis (Λ : Canonical.FiniteFreeLattice)
      (basis : GroupEquiv ST.IntegerPairs (SG.Subgroup→Group Canonical.Additive (Λ .fst))) where
    member-isProp : (z : Complex) → isProp (Canonical.Member (Λ .fst) z)
    member-isProp z = Λ .fst .fst z .snd

    map : GroupHom IP.Pairs Linear.Additive
    map .fst z = basis .fst .fst z .fst
    map .snd = makeIsGroupHom (λ z w → cong fst (IsGroupHom.pres· (basis .snd) z w))

    injective : {z w : ℤ × ℤ} → map .fst z ≡ map .fst w → z ≡ w
    injective {z} {w} equal = sym (retEq (basis .fst) z)
      ∙ cong (invEq (basis .fst)) (Σ≡Prop member-isProp equal) ∙ retEq (basis .fst) w

    module Embedded = Presentations.EmbeddedMap map injective

    fiber→member : (z : Complex) → fiber (map .fst) z → Canonical.Member (Λ .fst) z
    fiber→member z (w , equal) = subst (Canonical.Member (Λ .fst)) equal (basis .fst .fst w .snd)

    member→fiber : (z : Complex) → Canonical.Member (Λ .fst) z → fiber (map .fst) z
    member→fiber z member = invEq (basis .fst) (z , member) , cong fst (secEq (basis .fst) (z , member))

    fiber-equivalence : (z : Complex) → fiber (map .fst) z ≃ Canonical.Member (Λ .fst) z
    fiber-equivalence z = propBiimpl→Equiv (Embedded.image-isProp z) (member-isProp z)
      (fiber→member z) (member→fiber z)

    translate : Embedded.StandardPresentation → Normalized Λ
    translate (τ , scalar , inverse , unit , same-image) =
      τ , scalar , inverse , unit , λ z → same-image z ∙ₑ fiber-equivalence (scalar *c z)

    euclidean : Forms.InnerProduct Lines.canonical-line
    euclidean = Forms.plane-to-canonical Metric.standard-inner-product

    from-radius : Canonical.Radius (Λ .fst) euclidean → PT.∥ Normalized Λ ∥₁
    from-radius (q , q-positive , real-positive , isolated) = PT.map translate
      (Embedded.presentation (Rationals.rational q) real-positive
        (λ z below → isolated (map .fst z) (basis .fst .fst z .snd) below))

    normalized : PT.∥ Normalized Λ ∥₁
    normalized = PT.rec PT.squash₁ from-radius (Λ .snd .fst euclidean)

  normalized : (Λ : Canonical.FiniteFreeLattice) → PT.∥ Normalized Λ ∥₁
  normalized Λ = PT.rec PT.squash₁ (Basis.normalized Λ) (Λ .snd .snd)
