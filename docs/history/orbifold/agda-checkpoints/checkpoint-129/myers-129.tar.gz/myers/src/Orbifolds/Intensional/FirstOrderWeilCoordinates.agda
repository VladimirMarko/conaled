{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FirstOrderWeilCoordinates where

-- Explicit finite free coordinates for the dual numbers and the
-- first-order plane. No choice of a basis, real-analysis result or
-- finite-support tensor implementation is assumed here.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin; fzero; fsuc)
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportPullbacks using (function-isSet)
open import Orbifolds.Intensional.SquareZeroAlgebra using (Pair; pair-path)
import Orbifolds.Intensional.FirstOrderWeilSquare as FirstOrder

module FiniteCoordinates {ℓ : Level} (ext : FunExt ℓ ℓ) (R : CommutativeSemiring ℓ) where
  private module R = CommutativeSemiring R
  module W = FirstOrder.Construction R

  coordinate-additive : (n : Nat) → AdditiveMonoid ℓ
  AdditiveMonoid.Carrier (coordinate-additive n) = Fin {ℓ} n → R.Carrier
  AdditiveMonoid.carrier-set (coordinate-additive n) = function-isSet ext (λ _ → R.carrier-set)
  AdditiveMonoid.zero (coordinate-additive n) = λ _ → R.zero
  AdditiveMonoid._+_ (coordinate-additive n) u v i = (u i) R.+ (v i)
  AdditiveMonoid.+-assoc (coordinate-additive n) u v w = ext (λ i → R.+-assoc (u i) (v i) (w i))
  AdditiveMonoid.+-comm (coordinate-additive n) u v = ext (λ i → R.+-comm (u i) (v i))
  AdditiveMonoid.+-zero-left (coordinate-additive n) u = ext (λ i → R.+-zero-left (u i))
  AdditiveMonoid.+-zero-right (coordinate-additive n) u = ext (λ i → R.+-zero-right (u i))

  coordinate-module : (n : Nat) → Semimodule R
  Semimodule.additive (coordinate-module n) = coordinate-additive n
  Semimodule._•_ (coordinate-module n) r u i = r R.* (u i)
  Semimodule.•-one (coordinate-module n) u = ext (λ i → R.*-one-left (u i))
  Semimodule.•-assoc (coordinate-module n) r s u = ext (λ i → R.*-assoc r s (u i))
  Semimodule.•-zero (coordinate-module n) r = ext (λ i → R.*-zero-right r)
  Semimodule.zero-• (coordinate-module n) u = ext (λ i → R.*-zero-left (u i))
  Semimodule.•-add (coordinate-module n) r u v = ext (λ i → R.*-add-right r (u i) (v i))
  Semimodule.add-• (coordinate-module n) r s u = ext (λ i → R.*-add-left r s (u i))

  two-ext : {f g : Fin {ℓ} 2 → R.Carrier}
    → f fzero ≡ g fzero → f (fsuc fzero) ≡ g (fsuc fzero) → f ≡ g
  two-ext p q = ext λ { fzero → p ; (fsuc fzero) → q ; (fsuc (fsuc ())) }

  three-ext : {f g : Fin {ℓ} 3 → R.Carrier}
    → f fzero ≡ g fzero → f (fsuc fzero) ≡ g (fsuc fzero)
    → f (fsuc (fsuc fzero)) ≡ g (fsuc (fsuc fzero)) → f ≡ g
  three-ext p q r = ext λ
    { fzero → p ; (fsuc fzero) → q ; (fsuc (fsuc fzero)) → r ; (fsuc (fsuc (fsuc ()))) }

  dual-coordinates : W.D.E → Fin {ℓ} 2 → R.Carrier
  dual-coordinates z fzero = fst z
  dual-coordinates z (fsuc fzero) = snd z
  dual-coordinates z (fsuc (fsuc ()))

  realize-dual : (Fin {ℓ} 2 → R.Carrier) → W.D.E
  realize-dual f = f fzero , f (fsuc fzero)

  dual-coordinate-linear : LinearMap W.D.E-module (coordinate-module 2)
  dual-coordinate-linear = dual-coordinates ,
    ((two-ext refl refl , λ u v → two-ext refl refl) , λ r u → two-ext refl refl)

  dual-realize-linear : LinearMap (coordinate-module 2) W.D.E-module
  dual-realize-linear = realize-dual , ((refl , λ u v → refl) , λ r u → refl)

  dual-coordinate-equivalence : Equiv W.D.E (Fin {ℓ} 2 → R.Carrier)
  dual-coordinate-equivalence = equiv dual-coordinates realize-dual
    (λ f → two-ext refl refl) (λ z → refl)

  plane-coordinates : W.D2.E → Fin {ℓ} 3 → R.Carrier
  plane-coordinates z fzero = fst z
  plane-coordinates z (fsuc fzero) = fst (snd z)
  plane-coordinates z (fsuc (fsuc fzero)) = snd (snd z)
  plane-coordinates z (fsuc (fsuc (fsuc ())))

  realize-plane : (Fin {ℓ} 3 → R.Carrier) → W.D2.E
  realize-plane f = f fzero , (f (fsuc fzero) , f (fsuc (fsuc fzero)))

  plane-coordinate-linear : LinearMap W.D2.E-module (coordinate-module 3)
  plane-coordinate-linear = plane-coordinates ,
    ((three-ext refl refl refl , λ u v → three-ext refl refl refl) , λ r u → three-ext refl refl refl)

  plane-realize-linear : LinearMap (coordinate-module 3) W.D2.E-module
  plane-realize-linear = realize-plane , ((refl , λ u v → refl) , λ r u → refl)

  plane-coordinate-equivalence : Equiv W.D2.E (Fin {ℓ} 3 → R.Carrier)
  plane-coordinate-equivalence = equiv plane-coordinates realize-plane
    (λ f → three-ext refl refl refl) (λ z → refl)

  dual-expansion : (z : W.D.E)
    → W.D.add (W.D.scale (fst z) W.D.oneE) (W.D.scale (snd z) W.epsilon) ≡ z
  dual-expansion (r , u) = pair-path
    (cong₂ R._+_ (R.*-one-right r) (R.*-zero-right u) ∙ R.+-zero-right r)
    (cong₂ R._+_ (R.*-zero-right r) (R.*-one-right u) ∙ R.+-zero-left u)

  plane-expansion : (z : W.D2.E)
    → W.D2.add (W.D2.scale (fst z) W.D2.oneE)
        (W.D2.add (W.D2.scale (fst (snd z)) W.epsilon1)
          (W.D2.scale (snd (snd z)) W.epsilon2)) ≡ z
  plane-expansion (r , (u , v)) = pair-path
    (cong₂ R._+_ (R.*-one-right r)
      (cong₂ R._+_ (R.*-zero-right u) (R.*-zero-right v) ∙ R.+-zero-left R.zero)
      ∙ R.+-zero-right r)
    (pair-path
      (cong₂ R._+_ (R.*-zero-right r)
        (cong₂ R._+_ (R.*-one-right u) (R.*-zero-right v) ∙ R.+-zero-right u)
        ∙ R.+-zero-left u)
      (cong₂ R._+_ (R.*-zero-right r)
        (cong₂ R._+_ (R.*-zero-right u) (R.*-one-right v) ∙ R.+-zero-left v)
        ∙ R.+-zero-left v))

  dual-independence : (r u : R.Carrier)
    → W.D.add (W.D.scale r W.D.oneE) (W.D.scale u W.epsilon) ≡ W.D.zeroE
    → Pair (r ≡ R.zero) (u ≡ R.zero)
  dual-independence r u equal =
    cong fst (sym (dual-expansion (r , u)) ∙ equal) ,
    cong snd (sym (dual-expansion (r , u)) ∙ equal)

  plane-independence : (r u v : R.Carrier)
    → W.D2.add (W.D2.scale r W.D2.oneE)
        (W.D2.add (W.D2.scale u W.epsilon1) (W.D2.scale v W.epsilon2)) ≡ W.D2.zeroE
    → Pair (r ≡ R.zero) (Pair (u ≡ R.zero) (v ≡ R.zero))
  plane-independence r u v equal =
    cong fst coefficients-zero ,
      (cong (λ z → fst (snd z)) coefficients-zero , cong (λ z → snd (snd z)) coefficients-zero)
    where
    coefficients-zero : (r , (u , v)) ≡ W.D2.zeroE
    coefficients-zero = sym (plane-expansion (r , (u , v))) ∙ equal
