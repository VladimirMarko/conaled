{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IdentityFiberOrbits where

-- A proved identity classification of a map gives equivalences for
-- its literal fiber orbit maps. The comparison with the supplied
-- invariance path is explicit, so an unrelated type equivalence
-- cannot stand in for freeness and transitivity of the action.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma

module Classification {ℓg ℓx ℓy : Level} (G : Type ℓg) (X : Type ℓx)
    (act : G → X → X) {Y : Type ℓy} (q : X → Y)
    (identities : (s t : X) → (q s ≡ q t) ≃ (Σ[ g ∈ G ] act g t ≡ s))
    (invariance : (g : G) (x : X) → q (act g x) ≡ q x)
    (inverse-computation : (g : G) (x : X)
      → invEq (identities (act g x) x) (g , refl) ≡ invariance g x) where

  total-arrows≃group : (x : X)
    → (Σ[ s ∈ X ] Σ[ g ∈ G ] act g x ≡ s) ≃ G
  total-arrows≃group x = isoToEquiv (iso
    (λ z → z .snd .fst) (λ g → act g x , g , refl)
    (λ g → refl) (λ (s , g , p) i → p i , g , λ j → p (i ∧ j)))

  base-fiber≃group : (x : X) → fiber q (q x) ≃ G
  base-fiber≃group x = compEquiv
    (Σ-cong-equiv-snd (λ s → identities s x)) (total-arrows≃group x)

  base-orbit : (x : X) → G → fiber q (q x)
  base-orbit x g = act g x , invariance g x

  inverse-base-computation : (x : X) (g : G)
    → invEq (base-fiber≃group x) g ≡ base-orbit x g
  inverse-base-computation x g = ΣPathP (refl , inverse-computation g x)

  base-orbit-isEquiv : (x : X) → isEquiv (base-orbit x)
  base-orbit-isEquiv x = subst isEquiv (funExt (inverse-base-computation x))
    (invEquiv (base-fiber≃group x) .snd)

  fiber-orbit : (y : Y) (z : fiber q y) → G → fiber q y
  fiber-orbit y (x , p) g = act g x , invariance g x ∙ p

  orbit-isEquiv : (y : Y) (z : fiber q y) → isEquiv (fiber-orbit y z)
  orbit-isEquiv y (x , p) = compEquiv (base-orbit x , base-orbit-isEquiv x)
    (Σ-cong-equiv-snd (λ _ → compPathrEquiv p)) .snd
