{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarCanonical where

-- Identify the literal cellular power comparison with the full
-- universal-property-induced evaluation map. The proof passes complete
-- finite squares through an inner coinductive witness, and retains the
-- path-valued compatibility component of every unbounded cocone.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (idfun; _∘_)
open import Cubical.Foundations.GroupoidLaws using (cong-∙)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties using (congEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictHomotopySquares using (adjust-path)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowerBarComparison as PowerComparison
import Orbifolds.Coherent.HomotopyCoherentPowerBarInterface as PowerInterface
import Orbifolds.Coherent.HomotopyCoherentPowerBarNaturality as FiniteNaturality
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as CanonicalMaps
import Orbifolds.CellularPresentations as CP
import Orbifolds.CoinductiveTowerSquares as Generic
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC

import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (_∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.InferredGoalPathInference using (assign-frozen-inferred)
import Orbifolds.CellularPresentationComparisons as CellularComparisons
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones

private
  macro
    frozen-next-map-value : Reflection.Term → Reflection.Term → Reflection.TC ⊤
    frozen-next-map-value candidate hole = assign-frozen-inferred
      ((quote Cocones.Functoriality.postcompose) ∷
       (quote CellularComparisons.Theory.Step.next-map) ∷ []) candidate hole

open import Orbifolds.Coherent.RestrictedPathInference using (hidden-argument; visible-argument)

transpose-pointwise-square : ∀ {ℓa ℓb : Level}
  {A : Type ℓa} {B : Type ℓb}
  (l r : I → A → B)
  (s : (a : A) → l i0 a ≡ r i0 a)
  (t : (a : A) → l i1 a ≡ r i1 a)
  (sq : (a : A) → PathP (λ i → l i a ≡ r i a) (s a) (t a))
  → PathP (λ i → l i ≡ r i) (funExt s) (funExt t)
transpose-pointwise-square l r s t sq i j a = sq a i j

-- This body is also definitionally the Prelude expression
-- congP (λ i → funExt) (funExt sq). No FunExtEquiv import is needed.

private
  square-hidden : Reflection.Arg Reflection.Term
  square-hidden = hidden-argument Reflection.unknown

  square-inferred : Reflection.Arg Reflection.Term
  square-inferred = visible-argument Reflection.unknown

  macro
    infer-transposed-square : Reflection.Term → Reflection.Term → Reflection.TC ⊤
    infer-transposed-square sq hole = assign-frozen-inferred
      ((quote Cocones.Functoriality.postcompose) ∷
       (quote CellularComparisons.Theory.Step.next-map) ∷ [])
      (Reflection.def (quote transpose-pointwise-square)
        (square-hidden ∷ square-hidden ∷ square-hidden ∷ square-hidden ∷
         square-inferred ∷ square-inferred ∷ square-inferred ∷ square-inferred ∷
         visible-argument sq ∷ [])) hole


module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module Maps = PowerComparison.Construction C D E F T
    using (relative-map; stage-map; comparison; direct-evaluation;
      module Original; module Powered; module Comparison; module Realization; module Core)
  module B = PowerInterface.Construction C D E F T
    using (State; module State; initial; advance; module RD; module RP; module R;
      module Power; module OriginalStages; module PoweredStages)
  module Original = Maps.Original
  module Powered = Maps.Powered

  module At (Y : Type ℓ) (t : T) where
    module RO = Original.MappingOut Y
    module RP = Powered.MappingOut Y
    module Restriction = B.R t Y
    module Action = Restriction.Action
    module Natural = FiniteNaturality.Construction C D E F T Y t
      using (triangle)

    record State : Type (ℓ-suc ℓ) where
      field
        A B V W : Type ℓ
        original-presentation : CP.Presentation A
        powered-presentation : CP.Presentation B
        current-map : B → T → A
        cell-map : Maps.Comparison.RelativeMap original-presentation powered-presentation current-map
        original-schedule : Action.Source.Schedule V
        powered-schedule : Action.Target.Schedule W
        original-representation : RO.Witnesses.Witness original-presentation (V , original-schedule)
        powered-representation : RP.Witnesses.Witness powered-presentation (W , powered-schedule)
        restriction : V → W
        restriction-morphism : Action.Morphism original-schedule powered-schedule restriction

    advance : State → State
    State.A (advance s) = PO.Pushout (CP.Presentation.attach (State.original-presentation s))
      (CP.Presentation.boundary (State.original-presentation s))
    State.B (advance s) = PO.Pushout (CP.Presentation.attach (State.powered-presentation s))
      (CP.Presentation.boundary (State.powered-presentation s))
    State.V (advance s) = Action.Source.Schedule.Next (State.original-schedule s)
    State.W (advance s) = Action.Target.Schedule.Next (State.powered-schedule s)
    State.original-presentation (advance s) = CP.Presentation.next (State.original-presentation s)
    State.powered-presentation (advance s) = CP.Presentation.next (State.powered-presentation s)
    State.current-map (advance s) = Maps.Comparison.RelativeMap.successor (State.cell-map s)
    State.cell-map (advance s) = Maps.Comparison.RelativeMap.next (State.cell-map s)
    State.original-schedule (advance s) = Action.Source.Schedule.tail (State.original-schedule s)
    State.powered-schedule (advance s) = Action.Target.Schedule.tail (State.powered-schedule s)
    State.original-representation (advance s) = RO.Witnesses.Witness.tail (State.original-representation s)
    State.powered-representation (advance s) = RP.Witnesses.Witness.tail (State.powered-representation s)
    State.restriction (advance s) x = State.restriction s (x .fst) ,
      Action.Morphism.fiber-map (State.restriction-morphism s) (x .fst) (x .snd)
    State.restriction-morphism (advance s) = Action.Morphism.tail (State.restriction-morphism s)

    left right : (s : State) → (State.A s → Y) → State.W s
    left s h = RP.Witnesses.Witness.current (State.powered-representation s) .fst
      (λ x → h (State.current-map s x t))
    right s h = State.restriction s
      (RO.Witnesses.Witness.current (State.original-representation s) .fst h)

    source-drop : (s : State) → (State.A (advance s) → Y) → (State.A s → Y)
    source-drop s h = h ∘ PO.inl

    target-drop : (s : State) → State.W (advance s) → State.W s
    target-drop s = fst

    left-square : (s : State) → (target-drop s ∘ left (advance s)) ≡ (left s ∘ source-drop s)
    left-square s i h = RP.Witnesses.Witness.square (State.powered-representation s)
      (λ x → h (State.current-map (advance s) x t)) i

    right-square : (s : State) → (target-drop s ∘ right (advance s)) ≡ (right s ∘ source-drop s)
    right-square s i h = cong (State.restriction s)
      (RO.Witnesses.Witness.square (State.original-representation s) h) i

    module Squares = Generic.Squares State (λ s → State.A s → Y) State.W advance
      source-drop target-drop left right left-square right-square
    open Squares using (Witness; module Witness)

    finite-state : (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
      → B.State n original powered → State
    State.A (finite-state n original powered s) = B.RD.Represented.Space original
    State.B (finite-state n original powered s) = B.RP.Represented.Space powered
    State.V (finite-state n original powered s) = Action.SourceFinite.Carrier n
    State.W (finite-state n original powered s) = Action.TargetFinite.Carrier n
    State.original-presentation (finite-state n original powered s) = Original.presentation n original
    State.powered-presentation (finite-state n original powered s) = Powered.presentation n powered
    State.current-map (finite-state n original powered s) = B.State.q s
    State.cell-map (finite-state n original powered s) = Maps.relative-map n original powered s
    State.original-schedule (finite-state n original powered s) = Action.SourceFinite.finite-state n .snd
    State.powered-schedule (finite-state n original powered s) = Action.TargetFinite.finite-state n .snd
    State.original-representation (finite-state n original powered s) = RO.finite-witness n original
    State.powered-representation (finite-state n original powered s) = RP.finite-witness n powered
    State.restriction (finite-state n original powered s) = Restriction.finite-restriction n
    State.restriction-morphism (finite-state n original powered s) = Action.finite-morphism n

    finite-naturality : (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
      (s : B.State n original powered)
      → left (finite-state n original powered s) ≡ right (finite-state n original powered s)
    finite-naturality n original powered s i h = Natural.triangle n original powered s h i

    -- Infer the exact original RHS before comparison with the advanced State.
    next-naturality-candidate : (n : Dim) (original : B.RD.Represented n)
      (powered : B.RP.Represented n) (s : B.State n original powered) → _
    next-naturality-candidate n original powered s = finite-naturality (osuc n)
      (B.OriginalStages.Step.next n original)
      (B.PoweredStages.Step.next n powered)
      (B.advance n original powered s)

    next-naturality : (n : Dim) (original : B.RD.Represented n)
      (powered : B.RP.Represented n) (s : B.State n original powered)
      → left (advance (finite-state n original powered s))
        ≡ right (advance (finite-state n original powered s))
    next-naturality n original powered s = frozen-next-map-value
      (next-naturality-candidate n original powered s)


    -- Infer the named original pointwise-square function in its own type.
    pointwise-square-candidate : (n : Dim) (original : B.RD.Represented n)
      (powered : B.RP.Represented n) (s : B.State n original powered) → _
    pointwise-square-candidate n original powered s =
      FiniteNaturality.Construction.Step.triangle-square
        C D E F T Y t n original powered s

    -- Infer the ordinary transposition at that square's own boundaries.
    transposed-square-candidate : (n : Dim) (original : B.RD.Represented n)
      (powered : B.RP.Represented n) (s : B.State n original powered) → _
    transposed-square-candidate n original powered s = infer-transposed-square
      (pointwise-square-candidate n original powered s)

    -- Retag only the already inferred value at the exact public square type.
    finite-square : (n : Dim) (original : B.RD.Represented n)
      (powered : B.RP.Represented n) (s : B.State n original powered)
      → PathP
          (λ i →
            (target-drop (finite-state n original powered s)
              ∘ next-naturality n original powered s i)
            ≡ (finite-naturality n original powered s i
              ∘ source-drop (finite-state n original powered s)))
          (left-square (finite-state n original powered s))
          (right-square (finite-state n original powered s))
    finite-square n original powered s = frozen-next-map-value
      (transposed-square-candidate n original powered s)


    abstract
      finite-witness : (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
        (s : B.State n original powered)
        → Witness (finite-state n original powered s) (finite-naturality n original powered s)
      Witness.next (finite-witness n original powered s) = next-naturality n original powered s
      Witness.square (finite-witness n original powered s) = finite-square n original powered s
      Witness.tail (finite-witness n original powered s) = finite-witness (osuc n)
        (B.OriginalStages.Step.next n original) (B.PoweredStages.Step.next n powered)
        (B.advance n original powered s)

    actual-state : ℕ → State
    State.A (actual-state n) = Original.Realization.Stage n
    State.B (actual-state n) = Powered.Realization.Stage n
    State.V (actual-state n) = Action.Source.PartialCone n
    State.W (actual-state n) = Action.Target.PartialCone n
    State.original-presentation (actual-state n) = Original.Realization.state n .snd
    State.powered-presentation (actual-state n) = Powered.Realization.state n .snd
    State.current-map (actual-state n) = Maps.stage-map n
    State.cell-map (actual-state n) = Maps.Realization.state n .snd
    State.original-schedule (actual-state n) = Action.Source.stage-schedule n
    State.powered-schedule (actual-state n) = Action.Target.stage-schedule n
    State.original-representation (actual-state n) = RO.witness-at n
    State.powered-representation (actual-state n) = RP.witness-at n
    State.restriction (actual-state n) = Restriction.partial-map n
    State.restriction-morphism (actual-state n) = Action.morphism-at n

    mutual
      stage-naturality : (n : ℕ) → left (actual-state n) ≡ right (actual-state n)
      stage-naturality zero = finite-naturality ozero B.RD.initial B.RP.initial B.initial
      stage-naturality (suc n) = Witness.next (witness-at n)

      witness-at : (n : ℕ) → Witness (actual-state n) (stage-naturality n)
      witness-at zero = finite-witness ozero B.RD.initial B.RP.initial B.initial
      witness-at (suc n) = Witness.tail (witness-at n)

    module MappingCore = Maps.Core.Mapping Y t Action.Source.PartialCone Action.Target.PartialCone
      Action.Source.drop Action.Target.drop
      (λ n → RO.stage-universal n .fst) (λ n → RP.stage-universal n .fst)
      RP.stage-square Restriction.partial-map
      (λ n h → cong (Restriction.partial-map n) (RO.stage-square n h))

    module HomotopyCore = MappingCore.Homotopy stage-naturality
      (λ n h i j → Witness.square (witness-at n) i j h)

    powered-computation : (h : Powered.Colimit → Y)
      → RP.restrict h ≡ MappingCore.powered-restrict h
    powered-computation h i .fst n = RP.stage-computation h n i
    powered-computation h i .snd n = RP.compatibility-computation h n i

    restricted-computation : (h : Original.Colimit → Y)
      → MappingCore.restricted-original h ≡ Restriction.restrict (RO.restrict h)
    restricted-computation h i .fst n =
      cong (Restriction.partial-map n) (sym (RO.stage-computation h n)) i
    restricted-computation h i .snd n =
      sym (cong (cong (Restriction.partial-map n)) (RO.compatibility-computation h n)
        ∙ cong-∙ (Restriction.partial-map n) (RO.stage-square n (h ∘ SC.incl {n = suc n}))
          (cong (RO.stage-universal n .fst) (MappingCore.source-edge h n))) i

    direct-restrict-natural : (h : Original.Colimit → Y)
      → RP.restrict (h ∘ Maps.direct-evaluation t) ≡ Restriction.restrict (RO.restrict h)
    direct-restrict-natural h = powered-computation (h ∘ Maps.direct-evaluation t)
      ∙ HomotopyCore.direct-restrict-natural h ∙ restricted-computation h

    restrict-natural : (h : Original.Colimit → Y)
      → RP.restrict (λ z → h (Maps.comparison z t)) ≡ Restriction.restrict (RO.restrict h)
    restrict-natural h = powered-computation (λ z → h (Maps.comparison z t))
      ∙ HomotopyCore.restrict-natural h ∙ restricted-computation h

  module Canonical (t : T) = CanonicalMaps.Map C (B.Power.Power D) D (B.Power.evaluation D t) E F
    using (induced; canonical-triangle)

  canonical-triangle : (t : T)
    → Powered.MappingOut.restrict Original.Colimit (λ z → Maps.comparison z t)
      ≡ B.R.restrict t Original.Colimit Original.canonical-cocone
  canonical-triangle t = At.restrict-natural Original.Colimit t (idfun Original.Colimit)

  agrees-with-induced : (t : T) → (λ z → Maps.comparison z t) ≡ Canonical.induced t
  agrees-with-induced t = invEq (congEquiv (Powered.MappingOut.universal Original.Colimit))
    (canonical-triangle t ∙ sym (Canonical.canonical-triangle t))

  comparison-is-canonical : Maps.comparison ≡ (λ z t → Canonical.induced t z)
  comparison-is-canonical i z t = agrees-with-induced t i z
