{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FullInfinitesimalMicrolinearity where

-- The literal definition quantifying over every crisp pointed
-- infinitesimal-variety real-pushout agrees with the spectrum-based
-- definition used by the project. Only the explicit uniform crisp
-- truncation rule at the presentation universe is required by the
-- comparison; no global choice of spectrum representatives is made.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
open import Orbifolds.Lifting using (Local)
import Orbifolds.Microlinearity as ML
import Orbifolds.CrispGeometry as CG
import Orbifolds.InfinitesimalVarietyDiagrams as VD
import Orbifolds.Orbifold as Orb

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ) where
  module Diagrams = VD.Ring R
  module Spectra = CG.Context R
  open Diagrams.InfinitesimalRealPushout

  CrispInfinitesimalRealPushout : Type (ℓ-suc ℓ)
  CrispInfinitesimalRealPushout = Flat Diagrams.InfinitesimalRealPushout

  test : CrispInfinitesimalRealPushout → ML.TestSquare ℓ
  test d = square (counit d)

  module Full = ML.Theory test
  open Full using (Microlinear; isPropMicrolinear) public
  module FullOrbifolds = Orb.Geometry test
  module SpectrumOrbifolds = Orb.Geometry
    (λ d → Spectra.WeilTests.WeilRealPushout.test-square (Spectra.underlying-diagram d))

  LiftsAgainstAllCodiagonals : {ℓx : Level} → Type ℓx → Type (ℓ-max (ℓ-suc ℓ) ℓx)
  LiftsAgainstAllCodiagonals X = (d : CrispInfinitesimalRealPushout)
    → Local (ML.Square.gap (test d)) X

  -- The actual unrestricted pointed-infinitesimal-variety formulation
  -- of Lemma 4.3.10, retaining the actual pushout coherence.
  characterization : {ℓx : Level} (X : Type ℓx)
    → Microlinear X ≃ LiftsAgainstAllCodiagonals X
  characterization X = propBiimpl→Equiv
    isPropMicrolinear (isPropΠ λ d → isPropIsEquiv _)
    (λ micro d → ML.Square.pushout→local (test d) (micro d))
    (λ local d → ML.Square.local→pushout (test d) (local d))

  full→spectra : {ℓx : Level} {X : Type ℓx}
    → Microlinear X → Spectra.Microlinear X
  full→spectra micro (box d) = micro (box (Diagrams.from-spectra d))

  module Presentations
      (distribute : FlatTruncationDistribution {ℓ = ℓ-suc ℓ}) where

    spectra→full : {ℓx : Level} {X : Type ℓx}
      → Spectra.Microlinear X → Microlinear X
    spectra→full {X = X} micro (box d) =
      crisp-truncation-rec distribute
        (Diagrams.Presentation (Diagrams.Frame.NW (frame d)))
        (isPropIsEquiv _)
        (λ pNW → crisp-truncation-rec distribute
          (Diagrams.Presentation (Diagrams.Frame.NE (frame d)))
          (isPropIsEquiv _)
          (λ pNE → crisp-truncation-rec distribute
            (Diagrams.Presentation (Diagrams.Frame.SW (frame d)))
            (isPropIsEquiv _)
            (λ pSW → crisp-truncation-rec distribute
              (Diagrams.Presentation (Diagrams.Frame.SE (frame d)))
              (isPropIsEquiv _)
              (λ pSE → Diagrams.Normalize.transfer d pNW pNE pSW pSE X
                (micro (box (Diagrams.Normalize.real-pushout d pNW pNE pSW pSE))))
              (infinitesimal-SE d))
            (infinitesimal-SW d))
          (infinitesimal-NE d))
        (infinitesimal-NW d)

    spectrum-test-equivalence : {ℓx : Level} (X : Type ℓx)
      → Spectra.Microlinear X ≃ Microlinear X
    spectrum-test-equivalence X = propBiimpl→Equiv
      Spectra.isPropMicrolinear isPropMicrolinear spectra→full full→spectra

    spectrum-orbifold→full : {ℓx : Level} {X : Type ℓx}
      → SpectrumOrbifolds.Orbifold X → FullOrbifolds.Orbifold X
    FullOrbifolds.Orbifold.microlinear (spectrum-orbifold→full orbifold) =
      spectra→full (SpectrumOrbifolds.Orbifold.microlinear orbifold)
    FullOrbifolds.Orbifold.finite-identifications (spectrum-orbifold→full orbifold) =
      SpectrumOrbifolds.Orbifold.finite-identifications orbifold

    full-orbifold→spectrum : {ℓx : Level} {X : Type ℓx}
      → FullOrbifolds.Orbifold X → SpectrumOrbifolds.Orbifold X
    SpectrumOrbifolds.Orbifold.microlinear (full-orbifold→spectrum orbifold) =
      full→spectra (FullOrbifolds.Orbifold.microlinear orbifold)
    SpectrumOrbifolds.Orbifold.finite-identifications (full-orbifold→spectrum orbifold) =
      FullOrbifolds.Orbifold.finite-identifications orbifold

    spectrum-orbifold-equivalence : {ℓx : Level} (X : Type ℓx)
      → SpectrumOrbifolds.Orbifold X ≃ FullOrbifolds.Orbifold X
    spectrum-orbifold-equivalence X = propBiimpl→Equiv
      SpectrumOrbifolds.isPropOrbifold FullOrbifolds.isPropOrbifold
      spectrum-orbifold→full full-orbifold→spectrum
