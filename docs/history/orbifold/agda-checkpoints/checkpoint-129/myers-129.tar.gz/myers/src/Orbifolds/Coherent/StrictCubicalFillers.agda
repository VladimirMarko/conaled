{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalFillers where

-- The literal PathP coordinates of the inner typed filler have exactly
-- the prescribed faces. This finite strict calculation uses only the
-- explicit cubical extensionality structure; no filler is assumed.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using
  (Endpoint; endpoint; Faces; Compatible; shell-face)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Boundary {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  shell-equality : (n : Dim) {X : Type ℓ}
    (lo hi lo' hi' : Cube n X)
    (p : CS.restriction (toNat n) lo ≡ CS.restriction (toNat n) hi)
    (q : CS.restriction (toNat n) lo' ≡ CS.restriction (toNat n) hi')
    → outer lo ≡ˢ outer lo' → outer hi ≡ˢ outer hi'
    → ((i : I) → outer (p i) ≡ˢ outer (q i))
    → outer ((lo , hi) , p) ≡ˢ outer ((lo' , hi') , q)
  shell-equality n lo hi lo' hi' p q reflˢ reflˢ agree =
    strict-cong (λ r → outer ((lo , hi) , inner r)) (path-ext agree)

  forget-canonical-strict : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → outer (CF.forget-filler (toNat n) (CS.restriction (toNat n) c)
        (CF.canonical-filler (toNat n) c)) ≡ˢ outer c
  forget-canonical-strict ozero c = reflˢ
  forget-canonical-strict (osuc n) c = interval-ext λ i →
    forget-canonical-strict n (c i)

  forget-boundary-strict : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    (c : CF.Filler (toNat n) b)
    → outer (CS.restriction (toNat n) (CF.forget-filler (toNat n) b c)) ≡ˢ outer b
  forget-boundary-strict ozero b c = reflˢ
  forget-boundary-strict (osuc n) b c = shell-equality n
    (CF.forget-filler (toNat n) (CS.restriction (toNat n) (b .fst .fst))
      (CF.canonical-filler (toNat n) (b .fst .fst)))
    (CF.forget-filler (toNat n) (CS.restriction (toNat n) (b .fst .snd))
      (CF.canonical-filler (toNat n) (b .fst .snd)))
    (b .fst .fst) (b .fst .snd)
    (λ i → CS.restriction (toNat n)
      (CF.forget-filler (toNat n) (b .snd i) (c i)))
    (b .snd)
    (forget-canonical-strict n (b .fst .fst))
    (forget-canonical-strict n (b .fst .snd))
    (λ i → forget-boundary-strict n (b .snd i) (c i))

  filler-face : (n : Dim) {X : Type ℓ} (p : Position (osuc n)) (e : Endpoint)
    (b : CS.Shell (toNat (osuc n)) X) (c : CF.Filler (toNat (osuc n)) b)
    → outer (coordinate-face n p (endpoint e) (CF.forget-filler (toNat (osuc n)) b c))
      ≡ˢ outer (shell-face n p e b)
  filler-face n p e b c = strict-trans
    (strict-sym (Assembly.Construction.restriction-face E n p e
      (CF.forget-filler (toNat (osuc n)) b c)))
    (strict-cong (λ z → outer (shell-face n p e (inner z)))
      (forget-boundary-strict (osuc n) b c))

  assembled-filler-face : (n : Dim) {X : Type ℓ}
    (F : Faces (osuc n) X) (compatible : Compatible (osuc n) F)
    (c : CF.Filler (toNat (osuc n))
      (Assembly.Construction.assemble E (osuc n) F compatible))
    (p : Position (osuc n)) (e : Endpoint)
    → outer (coordinate-face n p (endpoint e)
        (CF.forget-filler (toNat (osuc n))
          (Assembly.Construction.assemble E (osuc n) F compatible) c))
      ≡ˢ outer (F p e)
  assembled-filler-face n F compatible c p e = strict-trans
    (filler-face n p e (Assembly.Construction.assemble E (osuc n) F compatible) c)
    (Assembly.Construction.assemble-face E n F compatible p e)
