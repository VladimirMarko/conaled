{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictHomotopySquares where

-- Convert a strictly commuting finite square to the full inner
-- homotopy between its two paths. Strict UIP is used only at the
-- finite combinatorial stage, before packaging any infinite witness.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Orbifolds.Coherent.StrictEnriched

strict-square : ∀ {ℓ} {A B A' B' : Type ℓ} (dA : A' → A) (dB : B' → B)
  {f g : A → B} {f' g' : A' → B'}
  (p : outer f ≡ˢ outer g) (p' : outer f' ≡ˢ outer g')
  (left : outer (dB ∘ f') ≡ˢ outer (f ∘ dA))
  (right : outer (dB ∘ g') ≡ˢ outer (g ∘ dA))
  → PathP (λ i → (dB ∘ strict-to-path p' i) ≡ (strict-to-path p i ∘ dA))
      (strict-to-path left) (strict-to-path right)
strict-square dA dB reflˢ reflˢ left right with strict-uip left right
... | reflˢ = refl

adjust-path : ∀ {ℓ} {P : I → Type ℓ} {a₀ b₀ : P i0} {a₁ b₁ : P i1}
  → a₀ ≡ b₀ → PathP P b₀ b₁ → b₁ ≡ a₁ → PathP P a₀ a₁
adjust-path left middle right i = hcomp
  (λ j → λ { (i = i0) → left (~ j) ; (i = i1) → right j }) (middle i)
