{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FlatSharpAdjunction where

-- The ambient flat/sharp adjunction of spatial type theory, stated on
-- actual external mapping types. Native Agda has no sharp primitive, so
-- the reflector and its uniform natural adjunction are explicit inputs.
-- Inversion of flat equivalences by sharp is proved below, not assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
import Cubical.Modalities.Modality as M
open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispPropositions as CP
import Orbifolds.CrispYonedaEndpoints as Y
import Orbifolds.ModalConnected as MC

module External {@♭ ℓ : Level} (@♭ sharp-modality : M.Modality ℓ) where
  private
    module S = M.Modality sharp-modality

  Homs : Type (ℓ-suc ℓ)
  Homs = (@♭ A B : Type ℓ) → Flat (Flat A → B) ≃ Flat (A → S.◯ B)

  NaturalDomain : Homs → Type (ℓ-suc ℓ)
  NaturalDomain hom = (@♭ A A' B : Type ℓ) (@♭ f : A' → A)
    (u : Flat (Flat A → B))
    → hom A' B .fst (flat-map (λ h → h ∘ flat-map f) u)
      ≡ flat-map (λ h → h ∘ f) (hom A B .fst u)

  NaturalTarget : Homs → Type (ℓ-suc ℓ)
  NaturalTarget hom = (@♭ A B B' : Type ℓ) (@♭ g : B → B')
    (u : Flat (Flat A → B))
    → hom A B' .fst (flat-map (λ h → g ∘ h) u)
      ≡ flat-map (λ h → S.◯-map g ∘ h) (hom A B .fst u)

  Adjunction : Type (ℓ-suc ℓ)
  Adjunction = Σ[ hom ∈ Homs ] NaturalDomain hom × NaturalTarget hom

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    (@♭ identity-rules : CrispIdentityInduction {ℓ})
    (@♭ sharp-modality : M.Modality ℓ) where
  module Sharp = MC.Theory sharp-modality
  module Propositions = CP.Context R r₀
  module FlatEquiv = Propositions.WithIdentity identity-rules
  module Identity = CI.Theory identity-rules
  module Assumptions (adjunction : External.Adjunction sharp-modality)
      (real-flat : Propositions.RealFlat) where
    hom = adjunction .fst
    natural-domain = adjunction .snd .fst
    natural-target = adjunction .snd .snd

    module Map {@♭ A B : Type ℓ} (@♭ f : A → B) (flat-equivalence : isEquiv (flat-map f)) where
      module Target (@♭ Z : Type ℓ) where
        middle : Flat (Flat B → Z) ≃ Flat (Flat A → Z)
        middle = flat-map (λ h → h ∘ flat-map f) ,
          FlatEquiv.flat-preserves-isEquiv real-flat (λ h → h ∘ flat-map f)
            (preCompEquiv (flat-map f , flat-equivalence) .snd)

        external-precompose : Flat (B → Sharp.◯ Z) ≃ Flat (A → Sharp.◯ Z)
        external-precompose = invEquiv (hom B Z) ∙ₑ middle ∙ₑ hom A Z

        external-agrees : (u : Flat (B → Sharp.◯ Z))
          → external-precompose .fst u ≡ flat-map (λ h → h ∘ f) u
        external-agrees u = natural-domain B A Z f (invEq (hom B Z) u)
          ∙ cong (flat-map (λ h → h ∘ f)) (secEq (hom B Z) u)

        external-precompose-isEquiv : isEquiv (flat-map (λ (h : B → Sharp.◯ Z) → h ∘ f))
        external-precompose-isEquiv = subst isEquiv (funExt external-agrees) (external-precompose .snd)

        restriction : (@♭ X : Type ℓ) → Flat (Sharp.◯ X → Sharp.◯ Z) ≃ Flat (X → Sharp.◯ Z)
        restriction X = flat-map (λ h → h ∘ Sharp.η) ,
          FlatEquiv.flat-preserves-isEquiv real-flat (λ h → h ∘ Sharp.η)
            (Sharp.unit-local Sharp.◯-isModal)

        reflected-precompose : Flat (Sharp.◯ B → Sharp.◯ Z) → Flat (Sharp.◯ A → Sharp.◯ Z)
        reflected-precompose = flat-map (λ h → h ∘ Sharp.◯-map f)

        square : (u : Flat (Sharp.◯ B → Sharp.◯ Z))
          → restriction A .fst (reflected-precompose u)
            ≡ flat-map (λ h → h ∘ f) (restriction B .fst u)
        square (box h) = Identity.box-path
          (λ a → h (Sharp.◯-map f (Sharp.η a)))
          (λ a → h (Sharp.η (f a)))
          (funExt λ a → cong h (Sharp.◯-map-β f a))

        reflected-precompose-isEquiv : isEquiv reflected-precompose
        reflected-precompose-isEquiv = isEquiv[equivFunA≃B∘f]→isEquiv[f]
          reflected-precompose (restriction A)
          (subst isEquiv (sym (funExt square))
            ((restriction B ∙ₑ (flat-map (λ h → h ∘ f) , external-precompose-isEquiv)) .snd))

      sharp-equivalence : Sharp.ModalEquivalence f
      sharp-equivalence = Y.Map.proves-equivalence (Sharp.◯-map f)
        (Target.reflected-precompose-isEquiv A) (Target.reflected-precompose-isEquiv B)
