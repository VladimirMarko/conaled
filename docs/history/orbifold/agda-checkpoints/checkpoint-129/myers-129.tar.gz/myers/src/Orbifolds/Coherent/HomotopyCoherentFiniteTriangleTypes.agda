{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes where

-- A small, explicitly typed surface for finite canonical triangles.
-- The common cocone type is fixed before checking either endpoint;
-- no full inverse-tower restriction namespace is instantiated here.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction

space : ∀ {ℓ} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
  (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
  (n : Dim) → Represented.Induction.Represented C D E F n → Type ℓ
space C D E F n r = Represented.Induction.Represented.Space r

universal : ∀ {ℓ} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
  (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
  (n : Dim) (r : Represented.Induction.Represented C D E F n)
  → Cocones.Functoriality.Cocone C D E F (space C D E F n r) n
universal C D E F n r = Represented.Induction.Represented.universal-cocone r

Triangle : ∀ {ℓ} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
  (α : Transformations.ForCategory.Transformation C D G)
  (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
  (n : Dim) (source : Represented.Induction.Represented C D E F n)
  (target : Represented.Induction.Represented C G E F n)
  → (space C D E F n source → space C G E F n target) → Type ℓ
Triangle C D G α E F n source target f = PathP
  (λ _ → Cocones.Functoriality.Cocone C D E F (space C G E F n target) n)
  (Cocones.Functoriality.postcompose C D E F n
    {Y = space C D E F n source} {Z = space C G E F n target}
    f (universal C D E F n source))
  (Restriction.Restriction.finite-restriction C D G α E F (space C G E F n target) n
    (universal C G E F n target))
