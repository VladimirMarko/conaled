{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.GeneralLinearMatrices where

-- Literal invertible n by n matrices, their coordinate action, and
-- coefficient change along an actual commutative-ring homomorphism.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Bool using (Bool; true; false; if_then_else_)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.AbGroup.Base using (AbGroup→Group)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
open import Cubical.Algebra.Group.Instances.Pi using (ΠGroup)
open import Cubical.Algebra.Module.Base using (IsLeftModuleHom)
import Cubical.Algebra.Matrix.CommRingCoefficient as MC
import Cubical.Algebra.Ring.BigOps as BO
open import Cubical.Functions.Embedding using (isEmbedding; injEmbedding)
import Orbifolds.FirstOrderLinearMaps as LM

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  module Matrix = MC.Coefficient R
  module Linear = LM.Ring R

  additive-group : Group ℓ
  additive-group = AbGroup→Group (CommRing→AbGroup R)

  module Dimension (n : ℕ) where
    Vector = Linear.Vector n
    GL = Matrix.InvMat n

    vector-group : Group ℓ
    vector-group = ΠGroup (λ (_ : FD.Fin n) → additive-group)

    one : GL
    one = Matrix.𝟙 , Matrix.isInv𝟙

    multiply : GL → GL → GL
    multiply g h = Matrix._⋆_ (g .fst) (h .fst) , Matrix.isInv⋆ (g .snd) (h .snd)

    inverse : GL → GL
    inverse g = g .snd .fst , g .fst , g .snd .snd .snd , g .snd .snd .fst

    setGL : isSet GL
    setGL = isSetΣ Matrix.isSetMat (λ M → isProp→isSet (Matrix.isPropIsInv M))

    GeneralLinear : Group ℓ
    GeneralLinear = makeGroup one multiply inverse setGL
      (λ g h k → Σ≡Prop Matrix.isPropIsInv (Matrix.⋆Assoc (g .fst) (h .fst) (k .fst)))
      (λ g → Σ≡Prop Matrix.isPropIsInv (Matrix.⋆rUnit (g .fst)))
      (λ g → Σ≡Prop Matrix.isPropIsInv (Matrix.⋆lUnit (g .fst)))
      (λ g → Σ≡Prop Matrix.isPropIsInv (g .snd .snd .fst))
      (λ g → Σ≡Prop Matrix.isPropIsInv (g .snd .snd .snd))

    act : GL → Vector → Vector
    act g = Linear.action (g .fst)

    action-unit : (x : Vector) → act one x ≡ x
    action-unit = Linear.action-identity

    action-compose : (g h : GL) (x : Vector)
      → act (multiply g h) x ≡ act g (act h x)
    action-compose g h = Linear.action-compose (h .fst) (g .fst)

    action-additive : (g : GL) → IsGroupHom (vector-group .snd) (act g) (vector-group .snd)
    action-additive g = makeIsGroupHom
      (IsLeftModuleHom.pres+ (Linear.action-linear (g .fst)))

    action-zero : (g : GL) → act g (const 0r) ≡ const 0r
    action-zero g = Linear.action-zero (g .fst)

    action-equivalence : (g : GL) → Vector ≃ Vector
    action-equivalence g = isoToEquiv (iso (act g) (act (inverse g))
      (λ x → sym (action-compose g (inverse g) x)
        ∙ cong (λ M → Linear.action M x) (g .snd .snd .fst) ∙ action-unit x)
      (λ x → sym (action-compose (inverse g) g x)
        ∙ cong (λ M → Linear.action M x) (g .snd .snd .snd) ∙ action-unit x))

    faithful : {g h : GL} → act g ≡ act h → g ≡ h
    faithful p = Σ≡Prop Matrix.isPropIsInv
      (invEq (congEquiv Linear.matrix≃module-hom)
        (Σ≡Prop Linear.module-laws-isProp p))

    action-embedding : isEmbedding act
    action-embedding = injEmbedding
      (isSetΠ λ _ → isSetΠ λ _ → is-set) faithful

module Map {ℓR ℓS : Level} (R : CommRing ℓR) (S : CommRing ℓS)
  (f : CommRingHom R S) where
  module RM = Ring R
  module SM = Ring S
  module RS = CommRingStr (R .snd)
  module SS = CommRingStr (S .snd)
  module H = IsCommRingHom (f .snd)
  module SumMap = BO.SumMap (CommRing→Ring R) (CommRing→Ring S) (CommRingHom→RingHom f)
  module SumS = BO.Sum (CommRing→Ring S)

  matrix : {m n : ℕ} → RM.Matrix.Mat m n → SM.Matrix.Mat m n
  matrix M i j = f .fst (M i j)

  indicator : (b : Bool)
    → f .fst (if b then RS.1r else RS.0r) ≡ (if b then SS.1r else SS.0r)
  indicator false = H.pres0
  indicator true = H.pres1

  identity : {n : ℕ} → matrix (RM.Matrix.𝟙 {n = n}) ≡ SM.Matrix.𝟙
  identity = funExt λ i → funExt λ j → indicator (i FD.== j)

  multiplication : {m n k : ℕ} (M : RM.Matrix.Mat m n) (N : RM.Matrix.Mat n k)
    → matrix (RM.Matrix._⋆_ M N) ≡ SM.Matrix._⋆_ (matrix M) (matrix N)
  multiplication M N = funExt λ i → funExt λ j →
    SumMap.∑Map (λ k → RS._·_ (M i k) (N k j))
    ∙ SumS.∑Ext (λ k → H.pres· (M i k) (N k j))

  invertible : {n : ℕ} (M : RM.Matrix.Mat n n)
    → RM.Matrix.isInv M → SM.Matrix.isInv (matrix M)
  invertible M (N , right , left) = matrix N ,
    (sym (multiplication M N) ∙ cong matrix right ∙ identity) ,
    (sym (multiplication N M) ∙ cong matrix left ∙ identity)

  general-linear : (n : ℕ) → RM.Dimension.GL n → SM.Dimension.GL n
  general-linear n g = matrix (g .fst) , invertible (g .fst) (g .snd)

  group-homomorphism : (n : ℕ)
    → GroupHom (RM.Dimension.GeneralLinear n) (SM.Dimension.GeneralLinear n)
  group-homomorphism n = general-linear n , makeIsGroupHom
    (λ g h → Σ≡Prop SM.Matrix.isPropIsInv (multiplication (g .fst) (h .fst)))

  coordinates : {n : ℕ} → RM.Linear.Vector n → SM.Linear.Vector n
  coordinates x i = f .fst (x i)

  action : {n m : ℕ} (M : RM.Linear.Mat n m) (x : RM.Linear.Vector n)
    → coordinates (RM.Linear.action M x) ≡ SM.Linear.action (matrix M) (coordinates x)
  action M x = funExt λ i →
    SumMap.∑Map (λ j → RS._·_ (M i j) (x j))
    ∙ SumS.∑Ext (λ j → H.pres· (M i j) (x j))

  module Injective (injective : {x y : R .fst} → f .fst x ≡ f .fst y → x ≡ y) where
    matrix-injective : {m n : ℕ} {M N : RM.Matrix.Mat m n}
      → matrix M ≡ matrix N → M ≡ N
    matrix-injective p = funExt λ i → funExt λ j → injective (cong (λ M → M i j) p)

    general-linear-embedding : (n : ℕ) → isEmbedding (general-linear n)
    general-linear-embedding n = injEmbedding (SM.Dimension.setGL n)
      (λ p → Σ≡Prop RM.Matrix.isPropIsInv (matrix-injective (cong fst p)))
