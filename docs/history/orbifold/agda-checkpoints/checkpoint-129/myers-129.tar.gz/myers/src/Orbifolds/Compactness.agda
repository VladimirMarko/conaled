{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.Compactness where

-- David Jaz Myers, arXiv:2205.15887v1, Definition 6.2.1,
-- Lemma 6.2.2, Warning 6.2.3, and Proposition 6.2.5.
--
-- Disjunction is propositional truncation of a sum.  Surjectivity is
-- mere inhabitation of each fiber.  No excluded middle or choice is used.
-- DPCompactAt exposes the universe of the tested propositions explicitly;
-- DPCompact is the same-universe specialization.  No resizing is assumed.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv using (_≃_; propBiimpl→Equiv)
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Functions.Surjection using (isSurjection; _↠_; isEquiv→isSurjection)
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.Sum as Sum
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin.Base using (Fin)
open import Cubical.Data.Unit using (Unit; tt; Unit*; tt*; isPropUnit*)
open import Cubical.Data.Empty using (⊥; ⊥*; isProp⊥*)
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; Dec; yes; no; isPropDec)
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

private
  variable
    ℓ ℓ' ℓ'' p : Level

infixr 3 _∨_

_∨_ : Type ℓ → Type ℓ' → Type (ℓ-max ℓ ℓ')
A ∨ B = ∥ A ⊎ B ∥₁

-- Definition 6.2.1 (compactness part).
DPCompactAt : (p : Level) {ℓ : Level} → Type ℓ → Type (ℓ-max ℓ (ℓ-suc p))
DPCompactAt p K =
  (A : hProp p) (B : K → hProp p) →
  ((x : K) → (A .fst) ∨ (B x .fst)) →
  (A .fst) ∨ ((x : K) → B x .fst)

DPCompact : {ℓ : Level} → Type ℓ → Type (ℓ-suc ℓ)
DPCompact {ℓ} = DPCompactAt ℓ

isPropDPCompactAt : {K : Type ℓ} → isProp (DPCompactAt p K)
isPropDPCompactAt = isPropΠ3 (λ _ _ _ → squash₁)

isPropDPCompact : {K : Type ℓ} → isProp (DPCompact K)
isPropDPCompact = isPropDPCompactAt

emptyDPCompact : DPCompactAt p ⊥
emptyDPCompact A B h = ∣ inr (λ ()) ∣₁

unitDPCompact : DPCompactAt p Unit
unitDPCompact A B h =
  PT.map (Sum.rec inl (λ b → inr (λ { tt → b }))) (h tt)

contractibleDPCompact : {K : Type ℓ} → isContr K → DPCompactAt p K
contractibleDPCompact contraction A B h =
  PT.map (Sum.rec inl
    (λ atCenter → inr (λ x → subst (λ y → B y .fst)
      (contraction .snd x) atCenter)))
    (h (contraction .fst))

-- A finite coproduct of compact types is compact.  This elementary
-- consequence is used to construct the finite ordinal instance below.
sumDPCompact : {K : Type ℓ} {L : Type ℓ'} →
  DPCompactAt p K → DPCompactAt p L → DPCompactAt p (K ⊎ L)
sumDPCompact cK cL A B h =
  PT.rec squash₁
    (Sum.rec (λ a → ∣ inl a ∣₁)
      (λ bK → PT.map
        (Sum.rec inl (λ bL → inr (Sum.elim bK bL)))
        (cL A (B ∘ inr) (h ∘ inr))))
    (cK A (B ∘ inl) (h ∘ inl))

-- Lemma 6.2.2(1), first for the standard finite ordinals.
finiteFinDPCompact : (n : ℕ) → DPCompactAt p (Fin n)
finiteFinDPCompact zero = emptyDPCompact
finiteFinDPCompact (suc n) = sumDPCompact unitDPCompact (finiteFinDPCompact n)

-- Lemma 6.2.2(2).  A witness of a preimage is eliminated only into B x,
-- which is a proposition; no section of the surjection is selected.
surjectiveImageDPCompact : {K : Type ℓ} {X : Type ℓ'} →
  DPCompactAt p K → (f : K → X) → isSurjection f → DPCompactAt p X
surjectiveImageDPCompact cK f surj A B h =
  PT.map
    (Sum.rec inl
      (λ allK → inr (λ x → PT.rec (B x .snd)
        (λ preimage → subst (λ y → B y .fst) (preimage .snd) (allK (preimage .fst)))
        (surj x))))
    (cK A (B ∘ f) (h ∘ f))

equivDPCompact : {K : Type ℓ} {X : Type ℓ'} →
  K ≃ X → DPCompactAt p K → DPCompactAt p X
equivDPCompact e compactK =
  surjectiveImageDPCompact compactK (e .fst) (isEquiv→isSurjection (e .snd))

-- Merely being the image of a finite ordinal, with no chosen enumeration.
FinitelyEnumerable : Type ℓ → Type ℓ
FinitelyEnumerable K = ∥ Σ[ n ∈ ℕ ] (Fin n ↠ K) ∥₁

-- Lemma 6.2.2(1) in its stated, finitely-enumerable generality.
finitelyEnumerableDPCompact : {K : Type ℓ} →
  FinitelyEnumerable K → DPCompactAt p K
finitelyEnumerableDPCompact = PT.rec isPropDPCompactAt
  (λ witness → surjectiveImageDPCompact
    (finiteFinDPCompact (witness .fst))
    (witness .snd .fst) (witness .snd .snd))

-- Lemma 6.2.2(3), separately for the two summands.  The unused summand
-- receives a true predicate, not a chosen point or a decidability axiom.
leftSummandDPCompact : {K : Type ℓ} {L : Type ℓ'} →
  DPCompactAt p (K ⊎ L) → DPCompactAt p K
leftSummandDPCompact {p = p} c A B h =
  PT.map (Sum.rec inl (λ b → inr (b ∘ inl)))
    (c A (Sum.rec B (λ _ → Unit* {ℓ = p} , isPropUnit*))
      (Sum.elim h (λ _ → ∣ inr tt* ∣₁)))

rightSummandDPCompact : {K : Type ℓ} {L : Type ℓ'} →
  DPCompactAt p (K ⊎ L) → DPCompactAt p L
rightSummandDPCompact {p = p} c A B h =
  PT.map (Sum.rec inl (λ b → inr (b ∘ inr)))
    (c A (Sum.rec (λ _ → Unit* {ℓ = p} , isPropUnit*) B)
      (Sum.elim (λ _ → ∣ inr tt* ∣₁) h))

-- Proposition 6.2.5.  All types lie in one universe so quantifying over
-- a fiber still produces a proposition in the tested universe.
sigmaDPCompact : {K : Type ℓ} {F : K → Type ℓ} →
  DPCompact K → ((k : K) → DPCompact (F k)) → DPCompact (Σ K F)
sigmaDPCompact {F = F} cK cF A B h =
  PT.map (Sum.rec inl (λ b → inr (λ pair → b (pair .fst) (pair .snd))))
    (cK A
      (λ k → ((v : F k) → B (k , v) .fst) , isPropΠ (λ v → B (k , v) .snd))
      (λ k → cF k A (λ v → B (k , v)) (λ v → h (k , v))))

productDPCompact : {K L : Type ℓ} →
  DPCompact K → DPCompact L → DPCompact (K × L)
productDPCompact cK cL = sigmaDPCompact cK (λ _ → cL)

-- Warning 6.2.3: a proposition is compact exactly when it is decidable.
-- Dec of a proposition is itself a proposition, so untruncating the
-- disjoint decision type below is valid constructive elimination.
compactProposition→Dec : (P : hProp ℓ) → DPCompact (P .fst) → Dec (P .fst)
compactProposition→Dec {ℓ = ℓ} P c =
  PT.rec (isPropDec (P .snd))
    (Sum.rec yes (λ notP → no (λ x → lower (notP x))))
    (c P (λ _ → ⊥* {ℓ = ℓ} , isProp⊥*) (λ x → ∣ inl x ∣₁))

decidablePropositionDPCompact : (P : hProp ℓ) →
  Dec (P .fst) → DPCompactAt p (P .fst)
decidablePropositionDPCompact P (yes x) A B h =
  PT.map
    (Sum.rec inl (λ bx → inr (λ y → subst (λ z → B z .fst) (P .snd x y) bx)))
    (h x)
decidablePropositionDPCompact P (no notP) A B h =
  ∣ inr (λ x → Empty.rec (notP x)) ∣₁

propositionCompact≃Decidable : (P : hProp ℓ) →
  DPCompact (P .fst) ≃ Dec (P .fst)
propositionCompact≃Decidable P = propBiimpl→Equiv
  isPropDPCompact (isPropDec (P .snd))
  (compactProposition→Dec P) (decidablePropositionDPCompact P)

