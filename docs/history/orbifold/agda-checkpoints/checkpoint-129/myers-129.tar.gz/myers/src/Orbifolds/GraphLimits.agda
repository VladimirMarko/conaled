{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.GraphLimits where

-- Arbitrarily indexed homotopy graph limits and their actual universal
-- property. Higher node and edge identities are retained. This does not
-- identify a bare graph with a general infinity-category diagram.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Graph
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module Diagram {ℓv ℓe ℓx : Level} (I : Graph ℓv ℓe) (X : Diag ℓx I) where
  Vertices : Type (ℓ-max ℓv ℓx)
  Vertices = (i : Node I) → X $g i

  EdgeValues : Type (ℓ-max ℓv (ℓ-max ℓe ℓx))
  EdgeValues = (i j : Node I) → Edge I i j → X $g j

  left right : Vertices → EdgeValues
  left s i j e = (X <$g> e) (s i)
  right s i j e = s j

  Compatibility : Vertices → Type (ℓ-max ℓv (ℓ-max ℓe ℓx))
  Compatibility s = (i j : Node I) (e : Edge I i j) → (X <$g> e) (s i) ≡ s j

  Limit : Type (ℓ-max ℓv (ℓ-max ℓe ℓx))
  Limit = Σ Vertices Compatibility

  projection : (i : Node I) → Limit → X $g i
  projection i z = z .fst i

  projection-square : (i j : Node I) (e : Edge I i j) (z : Limit)
    → (X <$g> e) (projection i z) ≡ projection j z
  projection-square i j e z = z .snd i j e

  equalizer-presentation : ML.Equalizer left right ≃ Limit
  equalizer-presentation = isoToEquiv (iso
    (λ (s , p) → s , (λ i j e k → p k i j e))
    (λ (s , p) → s , (λ k i j e → p i j e k))
    (λ _ → refl) (λ _ → refl))

  Cone : {ℓt : Level} → Type ℓt → Type (ℓ-max ℓt (ℓ-max ℓv (ℓ-max ℓe ℓx)))
  Cone T = Σ[ leg ∈ ((i : Node I) → T → X $g i) ]
    ((i j : Node I) (e : Edge I i j) → (X <$g> e) ∘ leg i ≡ leg j)

  restrict : {ℓt : Level} {T : Type ℓt} → (T → Limit) → Cone T
  restrict h = (λ i t → h t .fst i) , (λ i j e k t → h t .snd i j e k)

  assemble : {ℓt : Level} {T : Type ℓt} → Cone T → T → Limit
  assemble (leg , commutes) t = (λ i → leg i t) , (λ i j e k → commutes i j e k t)

  universal : {ℓt : Level} (T : Type ℓt) → (T → Limit) ≃ Cone T
  universal T = isoToEquiv (iso restrict assemble (λ _ → refl) (λ _ → refl))

  canonical-cone : Cone Limit
  canonical-cone = restrict (idfun Limit)

  precompose-cone : {ℓs ℓt : Level} {S : Type ℓs} {T : Type ℓt}
    → Cone T → (S → T) → Cone S
  precompose-cone (leg , commutes) f = (λ i → leg i ∘ f) ,
    (λ i j e k s → commutes i j e k (f s))

  comparison : {ℓl : Level} {L : Type ℓl} → Cone L → L → Limit
  comparison = assemble

  comparison-natural : {ℓs ℓl : Level} {S : Type ℓs} {L : Type ℓl}
    (cone : Cone L) (f : S → L)
    → restrict (comparison cone ∘ f) ≡ precompose-cone cone f
  comparison-natural cone f = refl

  -- Any other genuinely universal cone has the same underlying type.
  -- Only its ordinary universal property at L and the constructed limit
  -- is needed; these are not additional geometric hypotheses.
  module Candidate {ℓl : Level} (L : Type ℓl) (cone : Cone L)
      (universal-at-L : isEquiv (precompose-cone {S = L} cone))
      (universal-at-limit : isEquiv (precompose-cone {S = Limit} cone)) where
    forward : L → Limit
    forward = comparison cone

    on-maps : {ℓs : Level} (S : Type ℓs)
      → isEquiv (precompose-cone {S = S} cone) → (S → L) ≃ (S → Limit)
    on-maps S p = (precompose-cone cone , p) ∙ₑ invEquiv (universal S)

    inverse : Limit → L
    inverse = invEq (on-maps Limit universal-at-limit) (idfun Limit)

    right-inverse : (z : Limit) → forward (inverse z) ≡ z
    right-inverse = funExt⁻ (secEq (on-maps Limit universal-at-limit) (idfun Limit))

    left-inverse : (x : L) → inverse (forward x) ≡ x
    left-inverse = funExt⁻ (invEq
      (congEquiv (on-maps L universal-at-L)) (funExt λ x → right-inverse (forward x)))

    equivalent : L ≃ Limit
    equivalent = isoToEquiv (iso forward inverse right-inverse left-inverse)

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi} (test : Index → Micro.TestSquare ℓw) where
    module M = Micro.Theory test
    module Limits = ML.Limits test

    limit-microlinear : ((i : Node I) → M.Microlinear (X $g i)) → M.Microlinear Limit
    limit-microlinear micro = Limits.microlinear-equiv equalizer-presentation
      (Limits.microlinear-equalizer left right
        (M.microlinear-Π micro)
        (M.microlinear-Π λ i → M.microlinear-Π λ j → M.microlinear-Π λ e → micro j))

    any-limit-microlinear : {ℓl : Level} (L : Type ℓl) (cone : Cone L)
      (universal-at-L : isEquiv (precompose-cone {S = L} cone))
      (universal-at-limit : isEquiv (precompose-cone {S = Limit} cone))
      → ((i : Node I) → M.Microlinear (X $g i)) → M.Microlinear L
    any-limit-microlinear L cone atL atLimit micro =
      Limits.microlinear-equiv (invEquiv (Candidate.equivalent L cone atL atLimit))
        (limit-microlinear micro)
