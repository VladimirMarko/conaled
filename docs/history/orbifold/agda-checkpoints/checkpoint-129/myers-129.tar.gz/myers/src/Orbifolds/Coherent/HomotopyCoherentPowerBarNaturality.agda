{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarNaturality where

-- The finite power comparison is natural on all mapping spaces. Its
-- successor square is an actual square between the constructed paths,
-- retaining both canonical representability transition homotopies.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (_∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen)
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as FiniteRestriction
import Orbifolds.Coherent.HomotopyCoherentPowerBarStages as StageValues
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictPathEndpointSquares
open import Orbifolds.Coherent.StrictHomotopySquares using (adjust-path)
open import Orbifolds.Coherent.StrictHomotopyNaturality using (cong-strict-path)
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionNaturality as RestrictionNaturality
import Orbifolds.Coherent.HomotopyCoherentPowerBarInterface as PowerStages
import Orbifolds.Coherent.HomotopyCoherentPowerBarCoherence as PowerCoherence

-- The candidate is the already inferred original successor triangle.
-- Its explicit public type is checked with these common producers neutral.
private
  macro
    frozen-next-value : Reflection.Term → Reflection.Term → Reflection.TC ⊤
    frozen-next-value candidate hole = assign-frozen
      ((quote Cocones.Functoriality.postcompose) ∷
       (quote FiniteRestriction.Restriction.finite-restriction) ∷
       (quote StageValues.Construction.Step.q) ∷ []) candidate hole

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (T Y : Type ℓ) (t : T) where
  open StrictCubicalExtensionality E
  module B = PowerStages.Construction C D E F T
    using (State; module State; advance; module RD; module RP; module CPow; module CD;
      module Power; module Step; module R)
  module N = RestrictionNaturality.Naturality C (B.Power.Power D) D (B.Power.evaluation D t) E F
    using (square)
  module R = B.R t Y using (finite-restriction)

  triangle : (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
    (state : B.State n original powered) (h : B.RD.Represented.Space original → Y)
    → B.CPow.postcompose n {Y = B.RP.Represented.Space powered} {Z = Y}
        (λ x → h (B.State.q state x t))
        (B.RP.Represented.universal-cocone powered)
      ≡ R.finite-restriction n
        (B.CD.postcompose n {Y = B.RD.Represented.Space original} {Z = Y}
          h (B.RD.Represented.universal-cocone original))
  triangle n original powered state h = strict-end-path {A = B.CPow.Cocone Y n}
    (λ i → B.CPow.postcompose n {Y = B.RD.Represented.Space original} {Z = Y}
      h (B.State.triangle state t i))
    (B.CPow.postcompose-compose n {Y = B.RP.Represented.Space powered}
      {Z = B.RD.Represented.Space original} {W = Y} (λ x → B.State.q state x t) h
      (B.RP.Represented.universal-cocone powered))
    (N.square n {Y = B.RD.Represented.Space original} {Z = Y}
      h (B.RD.Represented.universal-cocone original))

  triangle-value : (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
    (state : B.State n original powered) (h : B.RD.Represented.Space original → Y) (i : I)
    → outer {A = B.CPow.Cocone Y n} (triangle n original powered state h i)
      ≡ˢ outer {A = B.CPow.Cocone Y n}
        (B.CPow.postcompose n {Y = B.RD.Represented.Space original} {Z = Y}
          h (B.State.triangle state t i))
  triangle-value n original powered state h i = strict-end-path-value
    {A = B.CPow.Cocone Y n}
    (λ i → B.CPow.postcompose n {Y = B.RD.Represented.Space original} {Z = Y}
      h (B.State.triangle state t i))
    (B.CPow.postcompose-compose n {Y = B.RP.Represented.Space powered}
      {Z = B.RD.Represented.Space original} {W = Y} (λ x → B.State.q state x t) h
      (B.RP.Represented.universal-cocone powered))
    (N.square n {Y = B.RD.Represented.Space original} {Z = Y}
      h (B.RD.Represented.universal-cocone original)) i

  module Step (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
      (previous : B.State n original powered) where
    module S = B.Step n original powered previous
    module Coherence = PowerCoherence.Construction.Step C D E F T n original powered previous
      using (prefix; transported-previous; source-transition; canonical-prefix-coherence; module Point)

    PoweredBase OriginalBase : Type ℓ
    PoweredBase = B.RP.Represented.Space powered
    OriginalBase = B.RD.Represented.Space original

    prefix : B.CPow.Cocone Y (osuc n) → B.CPow.Cocone Y n
    prefix = fst
    next-state : B.State (osuc n) S.OD.next S.PP.next
    next-state = B.advance n original powered previous

    previous-path : (h : S.OD.Realize → Y)
      → B.CPow.postcompose n {Y = PoweredBase} {Z = Y}
          (λ x → h (S.OD.Cell.include (B.State.q previous x t)))
          (B.RP.Represented.universal-cocone powered)
        ≡ R.finite-restriction n (B.CD.postcompose n {Y = OriginalBase} {Z = Y}
          (h ∘ S.OD.Cell.include)
          (B.RD.Represented.universal-cocone original))
    previous-path h = triangle n original powered previous (h ∘ S.OD.Cell.include)

    next-path-implementation : (h : S.OD.Realize → Y) → _
    next-path-implementation h = triangle (osuc n) S.OD.next S.PP.next next-state h


    next-path : (h : S.OD.Realize → Y)
      → B.CPow.postcompose (osuc n) {Y = S.PP.Realize} {Z = Y}
          (λ x → h (S.q x t)) S.PP.canonical-cocone
        ≡ R.finite-restriction (osuc n) (B.CD.postcompose (osuc n)
          {Y = S.OD.Realize} {Z = Y} h S.OD.canonical-cocone)
    next-path h = frozen-next-value (next-path-implementation h)

    left-equality : (h : S.OD.Realize → Y)
      → outer (next-path h i0 .fst) ≡ˢ outer (previous-path h i0)
    left-equality h = S.PP.transition-computation Y (λ x → h (S.q x t))

    right-equality : (h : S.OD.Realize → Y)
      → outer (next-path h i1 .fst) ≡ˢ outer (previous-path h i1)
    right-equality h = strict-cong (λ s → outer (R.finite-restriction n (inner s)))
      (S.OD.transition-computation Y h)

    map-start : (h : S.OD.Realize → Y)
      → outer (B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y} h (S.triangle t i0 .fst))
        ≡ˢ outer (next-path h i0 .fst)
    map-start h = strict-cong (λ s → outer (inner s .fst))
      (B.CPow.postcompose-compose (osuc n) {Y = S.PP.Realize} {Z = S.OD.Realize} {W = Y}
        (λ x → S.q x t) h S.PP.canonical-cocone)

    map-end : (h : S.OD.Realize → Y)
      → outer (B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y} h (S.triangle t i1 .fst))
        ≡ˢ outer (next-path h i1 .fst)
    map-end h = strict-cong (λ s → outer (inner s .fst))
      (N.square (osuc n) {Y = S.OD.Realize} {Z = Y} h S.OD.canonical-cocone)

    reframe : (h : S.OD.Realize → Y) → (S.triangle t i0 .fst ≡ S.triangle t i1 .fst)
      → next-path h i0 .fst ≡ next-path h i1 .fst
    reframe h p = strict-end-path {A = B.CPow.Cocone Y n}
      (λ i → B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y} h (p i)) (map-start h) (map-end h)

    prefix-reframe : (h : S.OD.Realize → Y)
      → outer (cong prefix (next-path h))
        ≡ˢ outer (reframe h (cong Coherence.prefix (S.triangle t)))
    prefix-reframe h = path-ext λ i → strict-trans
      (strict-cong (λ s → outer (inner s .fst))
        (triangle-value (osuc n) S.OD.next S.PP.next next-state h i))
      (strict-sym (strict-end-path-value
        {A = B.CPow.Cocone Y n}
        (λ j → B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y} h (S.triangle t j .fst))
        (map-start h) (map-end h) i))

    aligned-prefix : (h : S.OD.Realize → Y) → next-path h i0 .fst ≡ next-path h i1 .fst
    aligned-prefix h = reframe h (Coherence.transported-previous t)

    prefix-computation : (h : S.OD.Realize → Y)
      → cong prefix (next-path h) ≡ aligned-prefix h
    prefix-computation h = strict-to-path (prefix-reframe h)
      ∙ cong (reframe h) (Coherence.canonical-prefix-coherence t)

    aligned-agreement : (h : S.OD.Realize → Y) (i : I)
      → outer {A = B.CPow.Cocone Y n} (aligned-prefix h i)
        ≡ˢ outer {A = B.CPow.Cocone Y n} (previous-path h i)
    aligned-agreement h i = strict-trans
      (strict-end-path-value
        {A = B.CPow.Cocone Y n}
        (λ j → B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y}
          h (Coherence.transported-previous t j))
        (map-start h) (map-end h) i)
      (strict-trans
        (strict-cong {A = Outer (B.CPow.Cocone S.OD.Realize n)}
          {B = Outer (B.CPow.Cocone Y n)}
          (λ s → outer (B.CPow.postcompose n {Y = S.OD.Realize} {Z = Y} h (inner s)))
          (strict-end-path-value
            {A = B.CPow.Cocone S.OD.Realize n}
            (λ j → B.CPow.postcompose n {Y = OriginalBase} {Z = S.OD.Realize}
              S.OD.Cell.include (B.State.triangle previous t j))
            (strict-trans
              (B.CPow.postcompose-compose n {Y = PoweredBase}
                {Z = OriginalBase} {W = S.OD.Realize}
                (λ x → B.State.q previous x t) S.OD.Cell.include
                (B.RP.Represented.universal-cocone powered))
              (strict-sym (Coherence.source-transition t)))
            (strict-trans
              (N.square n {Y = OriginalBase} {Z = S.OD.Realize}
                S.OD.Cell.include (B.RD.Represented.universal-cocone original))
              (Coherence.Point.last-equality t)) i))
        (strict-trans
          (B.CPow.postcompose-compose n {Y = OriginalBase} {Z = S.OD.Realize} {W = Y}
            S.OD.Cell.include h (B.State.triangle previous t i))
          (strict-sym (triangle-value n original powered previous (h ∘ S.OD.Cell.include) i))))

    aligned-square : (h : S.OD.Realize → Y)
      → PathP (λ i → aligned-prefix h i ≡ previous-path h i)
          (strict-to-path (left-equality h))
          (cong (R.finite-restriction n) (strict-to-path (S.OD.transition-computation Y h)))
    aligned-square h = adjust-path refl
      (pointwise-strict-square (λ i → aligned-prefix h i) (λ i → previous-path h i)
        (aligned-agreement h) (left-equality h) (right-equality h))
      (sym (cong-strict-path (R.finite-restriction n) (S.OD.transition-computation Y h)))

    triangle-square : (h : S.OD.Realize → Y)
      → PathP (λ i → next-path h i .fst ≡ previous-path h i)
          (strict-to-path (S.PP.transition-computation Y (λ x → h (S.q x t))))
          (cong (R.finite-restriction n) (strict-to-path (S.OD.transition-computation Y h)))
    triangle-square h = subst
      (λ p → PathP (λ i → p i ≡ previous-path h i)
        (strict-to-path (left-equality h))
        (cong (R.finite-restriction n) (strict-to-path (S.OD.transition-computation Y h))))
      (sym (prefix-computation h)) (aligned-square h)
