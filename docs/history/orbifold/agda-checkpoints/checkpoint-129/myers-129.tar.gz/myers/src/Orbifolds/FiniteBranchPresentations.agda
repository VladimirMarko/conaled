{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.FiniteBranchPresentations where

-- An alternative finiteness route from actual finite partial-map charts.
-- No DP properness, excluded middle, or decidable equality of objects is
-- assumed. A semantic theorem must still construct these charts from the
-- external topology. Openness is not needed for this algebraic consequence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism using (iso; isoToEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Sum using (inl; inr)
open import Cubical.Data.SumFin using (Fin; fzero)
open import Cubical.Data.Unit using (tt; Unit*; tt*; isPropUnit*)
open import Cubical.Data.SubFinSet using (isSubFinSet)
open import Cubical.Functions.Embedding
open import Cubical.Categories.Category using (Category)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.ProperFiniteness
open import Orbifolds.GroupoidCompletion using (AllInvertible; module Completion)
import Orbifolds.GroupoidOrbifold as GO
import Orbifolds.Orbifold as O
import Orbifolds.Microlinearity as ML

private variable ℓ ℓi : Level

BranchArrows : {X Y : Type ℓ} (n : ℕ)
  → (domain : Fin n → X → hProp ℓ)
  → ((i : Fin n) (x : X) → domain i x .fst → Y)
  → X → Y → Type ℓ
BranchArrows n domain target x y =
  Σ[ i ∈ Fin n ] Σ[ in-domain ∈ domain i x .fst ]
    target i x in-domain ≡ y

-- The equivalence describes an entire hom-family over a rectangle.
-- Distinct labels enumerate distinct arrows even when their targets agree.
record FiniteBranchChart {X Y : Type ℓ} (H : X → Y → Type ℓ)
    : Type (ℓ-suc ℓ) where
  field
    number-of-branches : ℕ
    domain : Fin number-of-branches → X → hProp ℓ
    target : (i : Fin number-of-branches) (x : X) → domain i x .fst → Y
    hom-equivalence : (x : X) (y : Y)
      → H x y ≃ BranchArrows number-of-branches domain target x y

open FiniteBranchChart

chart-hom-embedding : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → (chart : FiniteBranchChart H) → (x : X) → (y : Y)
  → H x y ↪ Fin (number-of-branches chart)
chart-hom-embedding setY chart x y =
  compEmbedding
    (EmbeddingΣProp (λ i → isPropΣ (domain chart i x .snd)
      (λ in-domain → setY (target chart i x in-domain) y)))
    (Equiv→Embedding (hom-equivalence chart x y))

chart-hom-subfinite : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → FiniteBranchChart H → (x : X) → (y : Y) → isSubFinSet (H x y)
chart-hom-subfinite setY chart x y = PT.∣
  number-of-branches chart , chart-hom-embedding setY chart x y ∣₁

chart-hom-properly-finite : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → FiniteBranchChart H → (x : X) → (y : Y) → ProperlyFinite (H x y)
chart-hom-properly-finite setY chart x y =
  subfiniteProperlyFinite (chart-hom-subfinite setY chart x y)

-- One identity branch handles the unit-groupoid hom-family on any set.
-- Equality of the objects need not be decidable; its proof is retained
-- as the possibly uninhabited proposition underneath the single label.
identity-branch-chart : {X : Type ℓ} → FiniteBranchChart (λ (x y : X) → x ≡ y)
number-of-branches identity-branch-chart = 1
domain (identity-branch-chart {ℓ = ℓ}) i x = Unit* {ℓ = ℓ} , isPropUnit*
target identity-branch-chart i x in-domain = x
hom-equivalence identity-branch-chart x y = isoToEquiv (iso
  (λ p → fzero , tt* , p)
  (λ witness → witness .snd .snd)
  (λ { (inl tt , tt* , p) → refl ; (inr () , _ , _) })
  (λ p → refl))

identity-paths-via-branches : {X : Type ℓ}
  → isSet X → (x y : X) → ProperlyFinite (x ≡ y)
identity-paths-via-branches setX =
  chart-hom-properly-finite setX identity-branch-chart

-- A local chart covers the requested pair by actual subtype regions.
-- A geometric implementation may prove these regions open; the current
-- theorem only needs membership and the displayed partial-map formula.
record LocalFiniteBranchChart {X Y : Type ℓ} (H : X → Y → Type ℓ)
    (x : X) (y : Y) : Type (ℓ-suc ℓ) where
  field
    source-region : X → hProp ℓ
    target-region : Y → hProp ℓ
    source-membership : source-region x .fst
    target-membership : target-region y .fst
    presentation : FiniteBranchChart
      (λ (u : Σ[ a ∈ X ] source-region a .fst)
         (v : Σ[ b ∈ Y ] target-region b .fst) → H (u .fst) (v .fst))

open LocalFiniteBranchChart

LocalFiniteBranchCharts : {X Y : Type ℓ} → (X → Y → Type ℓ) → Type (ℓ-suc ℓ)
LocalFiniteBranchCharts {X = X} {Y = Y} H =
  (x : X) (y : Y) → PT.∥ LocalFiniteBranchChart H x y ∥₁

local-chart-hom-subfinite : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → {x : X} {y : Y} → LocalFiniteBranchChart H x y
  → isSubFinSet (H x y)
local-chart-hom-subfinite setY {x = x} {y = y} chart =
  chart-hom-subfinite
    (isSetΣ setY (λ b → isProp→isSet (target-region chart b .snd)))
    (presentation chart)
    (x , source-membership chart) (y , target-membership chart)

local-branches→subfinite-homs : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → LocalFiniteBranchCharts H
  → (x : X) → (y : Y) → isSubFinSet (H x y)
local-branches→subfinite-homs setY charts x y =
  PT.rec PT.squash₁ (local-chart-hom-subfinite setY) (charts x y)

local-branches→properly-finite-homs : {X Y : Type ℓ} {H : X → Y → Type ℓ}
  → isSet Y → LocalFiniteBranchCharts H
  → (x : X) → (y : Y) → ProperlyFinite (H x y)
local-branches→properly-finite-homs setY charts x y =
  subfiniteProperlyFinite (local-branches→subfinite-homs setY charts x y)

module Groupoid (C : Category ℓ ℓ) (invertible : AllInvertible C)
    (setObjects : isSet (Category.ob C)) where
  module Completed = Completion C invertible
  module Finite = GO.FiniteCompletion C invertible

  finite-branch-completion : LocalFiniteBranchCharts (Category.Hom[_,_] C)
    → O.LocallyProperlyFinite Completed.Object
  finite-branch-completion charts = Finite.completionLocallyProperlyFinite
    (local-branches→properly-finite-homs setObjects charts)

  module Geometry {Index : Type ℓi} (test : Index → ML.TestSquare ℓ) where
    module Micro = ML.Theory test
    module Orb = O.Geometry test
    module Finish = Finite.Geometry test

    -- The remaining geometric hypotheses refer to the original object
    -- space and actual atlas map, not to the desired completed conclusion.
    finite-branch-completion-orbifold :
      LocalFiniteBranchCharts (Category.Hom[_,_] C)
      → Micro.Microlinear (Category.ob C)
      → Micro.InfinitesimallyEtale Completed.object
      → Orb.Orbifold Completed.Object
    finite-branch-completion-orbifold charts =
      Finish.completionOrbifoldFromLifting
        (local-branches→properly-finite-homs setObjects charts)
