{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrispFiniteModal where

-- Actual finite types are R-null. The only crisp promotion used here is
-- the checked one for elements of crisp finite ordinals; arbitrary
-- finite types and their finiteness witnesses remain ordinary.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Unit using (Unit)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.FinSet using (isFinSet)
open import Cubical.Data.Sigma
import Cubical.Data.SumFin as SF
open import Cubical.Functions.Embedding using (isEmbedding)
open import Cubical.Functions.Surjection
  using (isSurjection; isEmbedding×isSurjection→isEquiv)
open import Cubical.Algebra.CommRing.Base using (CommRing; CommRingStr)
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispPropositions as CP
import Orbifolds.CrispCountable as Countable
import Orbifolds.Crystalline as CR

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  module Propositions = CP.Context R r₀
  module Identity = CI.Theory rules
  module Ordinals = Countable.Context R r₀
  open Propositions using (RealFlat) public

  Generator : Unit → Type ℓ
  Generator _ = R

  counit-set-embedding : RealFlat → {@♭ X : Type ℓ} → isSet X
    → isEmbedding (counit {A = X})
  counit-set-embedding real-flat setX (box x) (box y) =
    isEquiv[f∘equivFunA≃B]→isEquiv[f] (cong counit)
      (Identity.flat-identity-equivalence x y)
      (subst isEquiv (sym (funExt (Identity.counit-decode x y)))
        (Propositions.proposition-discrete real-flat (x ≡ y) (setX x y)))

  module Ordinal (@♭ n : ℕ) where
    module Index = Ordinals.FiniteOrdinal n

    counit-surjective : RealFlat → isSurjection (counit {A = Index.Lifted})
    counit-surjective real-flat = Index.LiftedElimination.crisp-element-elim
      real-flat (λ x → PT.∥ fiber counit x ∥₁) (λ x → PT.∣ box x , refl ∣₁)

    ordinal-discrete : RealFlat → CrisplyDiscrete Index.Lifted
    ordinal-discrete real-flat = isEmbedding×isSurjection→isEquiv
      (counit-set-embedding real-flat (isOfHLevelLift 2 SF.isSetFin)
      , counit-surjective real-flat)

    ordinal-null : RealFlat → NB.isNull Generator Index.Lifted
    ordinal-null real-flat _ = fromIsEquiv const
      (equivFun (real-flat Index.Lifted) (ordinal-discrete real-flat))

  finite-ordinal-null : RealFlat → (n : ℕ)
    → NB.isNull Generator (Lift {j = ℓ} (SF.Fin n))
  finite-ordinal-null real-flat = natural-crisp-elim
    (λ n → NB.isNull Generator (Lift {j = ℓ} (SF.Fin n)))
    (λ n → Ordinal.ordinal-null n real-flat)

  finite-null : RealFlat → {X : Type ℓ} → isFinSet X → NB.isNull Generator X
  finite-null real-flat finite = PT.rec NP.isPropIsNull
    (λ e → NP.equivPreservesIsNull (invEquiv (compEquiv e LiftEquiv))
      (finite-ordinal-null real-flat (finite .fst))) (finite .snd)

module Ring {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CommRingStr (R .snd) using (0r)
  module Generic = Context (R .fst) 0r rules
  module Infinitesimal = CR.Ring R

  finite-shape-modal : Generic.RealFlat → {X : Type ℓ}
    → isFinSet X → Infinitesimal.IsShapeModal X
  finite-shape-modal = Generic.finite-null
