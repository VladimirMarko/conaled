{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CompletionMoritaEquivalence where

-- A functor of actual groupoids induces a map of their actual HIT Rezk
-- completions. Its being an equivalence is characterized by full
-- faithfulness and merely essential surjectivity of the original functor.
-- No representatives, quasi-inverse functor, or choice principle is given.
-- The geometric meaning of these internal hypotheses is a separate issue.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Functions.Embedding
open import Cubical.Functions.Surjection
open import Cubical.Categories.Category using (Category; CatIso; isPropIsIso)
open import Cubical.Categories.Functor using (Functor)
open import Cubical.Categories.Isomorphism using (F-Iso; F-Iso-Pres⋆)
open import Cubical.Categories.Equivalence.WeakEquivalence
  using (isWeakEquivalence; isPropIsWeakEquivalence)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.GroupoidCompletion using (AllInvertible; module Completion)
import Orbifolds.FiniteBranchPresentations as Branches
import Orbifolds.Orbifold as O
import Orbifolds.Microlinearity as ML

private
  variable
    ℓC ℓC' ℓD ℓD' ℓE ℓE' ℓ ℓi : Level

module Map (C : Category ℓC ℓC') (invertibleC : AllInvertible C)
    (D : Category ℓD ℓD') (invertibleD : AllInvertible D)
    (F : Functor C D) where
  module Source = Completion C invertibleC
  module Target = Completion D invertibleD

  -- This is the actual groupoid-quotient recursor. In particular the
  -- object computation is judgmental, and the generating paths carry
  -- the original functor's action on arrows.
  completed-map : Source.Object → Target.Object
  completed-map = Source.R.rec Target.completion-isGroupoid
    (λ x → Target.object (Functor.F-ob F x))
    (λ e → Target.R.inc-ua (F-Iso {F = F} e))
    (λ e f → subst
      (λ g → Square
        (Target.R.inc-ua (F-Iso {F = F} e))
        (Target.R.inc-ua g)
        refl
        (Target.R.inc-ua (F-Iso {F = F} f)))
      (sym (F-Iso-Pres⋆ {F = F} e f))
      (Target.R.inc-sq (F-Iso {F = F} e) (F-Iso {F = F} f)))

  completed-map-object : (x : Category.ob C)
    → completed-map (Source.object x) ≡ Target.object (Functor.F-ob F x)
  completed-map-object x = refl

  completed-map-iso-path : {x y : Category.ob C} (e : CatIso C x y)
    → cong completed-map (Source.R.inc-ua e)
      ≡ Target.R.inc-ua (F-Iso {F = F} e)
  completed-map-iso-path e = refl

  completed-map-morphism-path : {x y : Category.ob C}
    → (f : Category.Hom[_,_] C x y)
    → cong completed-map (Source.morphismPath f)
      ≡ Target.morphismPath (Functor.F-hom F f)
  completed-map-morphism-path f =
    cong Target.R.inc-ua (Σ≡Prop isPropIsIso refl)

  -- The original hom/identity equivalences identify the actual path map,
  -- not merely another function between the same identity types.
  completed-path-map-computes : {x y : Category.ob C}
    → (p : Source.object x ≡ Source.object y)
    → cong completed-map p
      ≡ Target.morphismPath (Functor.F-hom F (Source.pathMorphism p))
  completed-path-map-computes p =
    sym (cong (cong completed-map) (Source.morphismPath-pathMorphism p))
      ∙ completed-map-morphism-path (Source.pathMorphism p)

  original-hom-map-computes : {x y : Category.ob C}
    → (f : Category.Hom[_,_] C x y)
    → Target.pathMorphism (cong completed-map (Source.morphismPath f))
      ≡ Functor.F-hom F f
  original-hom-map-computes f =
    cong Target.pathMorphism (completed-map-morphism-path f)
      ∙ Target.pathMorphism-morphismPath (Functor.F-hom F f)

  fully-faithful→completed-embedding : Functor.isFullyFaithful F
    → isEmbedding completed-map
  fully-faithful→completed-embedding fully-faithful =
    Source.proposition-induction₂
      (λ u v → isEquiv (λ (p : u ≡ v) → cong completed-map p))
      (λ u v → isPropIsEquiv (λ (p : u ≡ v) → cong completed-map p))
      (λ x y → subst isEquiv
        (sym (funExt (completed-path-map-computes {x = x} {y = y})))
        (compEquiv (Source.identification≃hom x y)
          (compEquiv (Functor.F-hom F {x = x} {y = y} , fully-faithful x y)
            (Target.hom≃identification (Functor.F-ob F x)
              (Functor.F-ob F y))) .snd))

  completed-embedding→fully-faithful : isEmbedding completed-map
    → Functor.isFullyFaithful F
  completed-embedding→fully-faithful embedding x y =
    subst isEquiv (funExt (original-hom-map-computes {x = x} {y = y}))
      (compEquiv (Source.hom≃identification x y)
        (compEquiv
          ((λ (p : Source.object x ≡ Source.object y) → cong completed-map p) ,
            embedding (Source.object x) (Source.object y))
          (Target.identification≃hom (Functor.F-ob F x)
            (Functor.F-ob F y))) .snd)

  fully-faithful≃completed-embedding :
    Functor.isFullyFaithful F ≃ isEmbedding completed-map
  fully-faithful≃completed-embedding = propBiimpl→Equiv
    (isPropΠ2 (λ x y → isPropIsEquiv (Functor.F-hom F {x = x} {y = y})))
    isPropIsEmbedding
    fully-faithful→completed-embedding completed-embedding→fully-faithful

  essentially-surjective→completed-surjection : Functor.isEssentiallySurj F
    → isSurjection completed-map
  essentially-surjective→completed-surjection essentially-surjective =
    Target.proposition-induction
      (λ v → PT.∥ fiber completed-map v ∥₁)
      (λ _ → PT.squash₁)
      (λ y → PT.map
        (λ { (x , e) → Source.object x , Target.R.inc-ua e })
        (essentially-surjective y))

  completed-surjection→essentially-surjective : isSurjection completed-map
    → Functor.isEssentiallySurj F
  completed-surjection→essentially-surjective surjective y =
    PT.rec PT.squash₁
      (λ { (u , p) → PT.map
        (λ { (x , q) → x ,
          (Target.pathMorphism (cong completed-map q ∙ p) ,
            invertibleD (Functor.F-ob F x) y
              (Target.pathMorphism (cong completed-map q ∙ p))) })
        (Source.object-surjective u) })
      (surjective (Target.object y))

  essentially-surjective≃completed-surjection :
    Functor.isEssentiallySurj F ≃ isSurjection completed-map
  essentially-surjective≃completed-surjection = propBiimpl→Equiv
    (isPropΠ (λ _ → PT.squash₁)) isPropIsSurjection
    essentially-surjective→completed-surjection
    completed-surjection→essentially-surjective

  weak-equivalence→completed-isEquiv : isWeakEquivalence F
    → isEquiv completed-map
  weak-equivalence→completed-isEquiv weak =
    isEmbedding×isSurjection→isEquiv
      (fully-faithful→completed-embedding (isWeakEquivalence.fullfaith weak) ,
       essentially-surjective→completed-surjection (isWeakEquivalence.esssurj weak))

  completed-isEquiv→weak-equivalence : isEquiv completed-map
    → isWeakEquivalence F
  completed-isEquiv→weak-equivalence equivalent = record
    { fullfaith = completed-embedding→fully-faithful (isEquiv→isEmbedding equivalent)
    ; esssurj = completed-surjection→essentially-surjective (isEquiv→isSurjection equivalent)
    }

  weak-equivalence≃completed-isEquiv :
    isWeakEquivalence F ≃ isEquiv completed-map
  weak-equivalence≃completed-isEquiv = propBiimpl→Equiv
    isPropIsWeakEquivalence (isPropIsEquiv completed-map)
    weak-equivalence→completed-isEquiv completed-isEquiv→weak-equivalence

  completed-equivalence : isWeakEquivalence F → Source.Object ≃ Target.Object
  completed-equivalence weak = completed-map , weak-equivalence→completed-isEquiv weak

-- A common refinement supplies a roof of weak equivalences. Its induced
-- equivalence retains an explicit triangle with both completion maps.
module Span (C : Category ℓC ℓC') (invertibleC : AllInvertible C)
    (D : Category ℓD ℓD') (invertibleD : AllInvertible D)
    (E : Category ℓE ℓE') (invertibleE : AllInvertible E)
    (left : Functor E C) (right : Functor E D)
    (weak-left : isWeakEquivalence left) (weak-right : isWeakEquivalence right) where
  module Left = Map E invertibleE C invertibleC left
  module Right = Map E invertibleE D invertibleD right

  completion-equivalence : Completion.Object C invertibleC ≃ Completion.Object D invertibleD
  completion-equivalence = compEquiv
    (invEquiv (Left.completed-equivalence weak-left))
    (Right.completed-equivalence weak-right)

  comparison-triangle : (u : Completion.Object E invertibleE)
    → equivFun completion-equivalence (Left.completed-map u) ≡ Right.completed-map u
  comparison-triangle u = cong Right.completed-map
    (retEq (Left.completed-equivalence weak-left) u)

-- At a common geometric universe the equivalence transfers the existing
-- predicates. It does not assert that finite branch chart data themselves
-- descend to every presentation, or supply an external atlas comparison.
module Invariance (C : Category ℓ ℓ) (invertibleC : AllInvertible C)
    (D : Category ℓ ℓ) (invertibleD : AllInvertible D)
    (F : Functor C D) (weak : isWeakEquivalence F) where
  module Compared = Map C invertibleC D invertibleD F
  module Source = Completion C invertibleC
  module Target = Completion D invertibleD

  finite-identifications-invariant :
    O.LocallyProperlyFinite Source.Object ≃ O.LocallyProperlyFinite Target.Object
  finite-identifications-invariant = propBiimpl→Equiv
    O.isPropLocallyProperlyFinite O.isPropLocallyProperlyFinite
    (O.equivLocallyProperlyFinite (Compared.completed-equivalence weak))
    (O.equivLocallyProperlyFinite (invEquiv (Compared.completed-equivalence weak)))

  finite-branch-finiteness-transfer : (setObjects : isSet (Category.ob C))
    → Branches.LocalFiniteBranchCharts (Category.Hom[_,_] C)
    → O.LocallyProperlyFinite Target.Object
  finite-branch-finiteness-transfer setObjects charts =
    equivFun finite-identifications-invariant (Charts.finite-branch-completion charts)
    where
    module Charts = Branches.Groupoid C invertibleC setObjects

  module Geometry {Index : Type ℓi} (test : Index → ML.TestSquare ℓ) where
    module Micro = ML.Theory test
    module Orb = O.Geometry test

    orbifold-invariant : Orb.Orbifold Source.Object ≃ Orb.Orbifold Target.Object
    orbifold-invariant = propBiimpl→Equiv Orb.isPropOrbifold Orb.isPropOrbifold
      (Orb.equivOrbifold (Compared.completed-equivalence weak))
      (Orb.equivOrbifold (invEquiv (Compared.completed-equivalence weak)))

    finite-branch-orbifold-transfer : (setObjects : isSet (Category.ob C))
      → Branches.LocalFiniteBranchCharts (Category.Hom[_,_] C)
      → Micro.Microlinear (Category.ob C)
      → Micro.InfinitesimallyEtale Source.object
      → Orb.Orbifold Target.Object
    finite-branch-orbifold-transfer setObjects charts microlinear etale =
      equivFun orbifold-invariant
        (Geometric.finite-branch-completion-orbifold charts microlinear etale)
      where
      module Charts = Branches.Groupoid C invertibleC setObjects
      module Geometric = Charts.Geometry test
