{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispYonedaEndpoints where

-- The endpoint form of external Yoneda.  Useful when the universal
-- property is stated only for a class of targets containing both ends.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Crisp

module Map {@♭ ℓ : Level} {@♭ A B : Type ℓ} (@♭ f : A → B) where
  precompose : (@♭ Y : Type ℓ) → (B → Y) → (A → Y)
  precompose Y h = h ∘ f

  proves-equivalence : isEquiv (flat-map (precompose A))
    → isEquiv (flat-map (precompose B)) → isEquiv f
  proves-equivalence externalA externalB =
    from-inverse (equivCtr mapsA (box (idfun A)))
    where
    mapsA : Flat (B → A) ≃ Flat (A → A)
    mapsA = flat-map (precompose A) , externalA

    mapsB : Flat (B → B) ≃ Flat (A → B)
    mapsB = flat-map (precompose B) , externalB

    injectiveB : (u v : Flat (B → B))
      → equivFun mapsB u ≡ equivFun mapsB v → u ≡ v
    injectiveB u v p = sym (retEq mapsB u)
      ∙ cong (invEq mapsB) p ∙ retEq mapsB v

    from-inverse : fiber (flat-map (precompose A)) (box (idfun A))
      → isEquiv f
    from-inverse (box g , p) = isoToIsEquiv
      (iso f g (funExt⁻ (cong counit right-law-flat))
        (funExt⁻ (cong counit p)))
      where
      right-law-flat : box (f ∘ g) ≡ box (idfun B)
      right-law-flat = injectiveB (box (f ∘ g)) (box (idfun B))
        (cong (flat-map (f ∘_)) p)
