{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CodiscreteCrystalline where

-- Lemma 5.2.8. The ambient sharp reflector and its external flat/sharp
-- adjunction are explicit spatial inputs. The infinitesimal conclusion,
-- unique factor, and its sharp reflection property are all derived.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (yes; no)
open import Cubical.Algebra.CommRing.Base
import Cubical.Modalities.Modality as M
open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispPropositions as CP
import Orbifolds.FlatSharpAdjunction as FS
import Orbifolds.Crystalline as C
import Orbifolds.Penon as PN
import Orbifolds.ModalConnected as MC

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ identity-rules : CrispIdentityInduction {ℓ})
    (@♭ sharp-modality : M.Modality ℓ) where
  open CommRingStr (R .snd) using (0r; is-set)
  open C.Ring R
  module Identity = CI.Theory identity-rules
  module Propositions = CP.Context (R .fst) 0r
  module Sharp = MC.Theory sharp-modality

  collapse : 𝔇 → Unit* {ℓ = ℓ}
  collapse _ = tt*

  module Assumptions (adjunction : FS.External.Adjunction sharp-modality)
      (real-flat : Propositions.RealFlat)
      (excluded-middle : CrispExcludedMiddle {ℓ}) where
    module Adjunction = FS.Context.Assumptions (R .fst) 0r identity-rules sharp-modality adjunction real-flat

    disk-isSet : isSet 𝔇
    disk-isSet = isSetΣSndProp is-set (λ _ → PN.isPropNeighbors)

    crisp-neighbor-zero : (@♭ d : 𝔇) → d ≡ zero𝔇
    crisp-neighbor-zero d with excluded-middle ((d .fst ≡ 0r) , is-set _ _)
    ... | yes p = Σ≡Prop (λ _ → PN.isPropNeighbors) p
    ... | no p = Empty.rec (d .snd p)

    flat-disk-contractible : isContr (Flat 𝔇)
    flat-disk-contractible .fst = box zero𝔇
    flat-disk-contractible .snd (box d) = Identity.flat-identity-equivalence zero𝔇 d .fst
      (Propositions.promote-proof real-flat (zero𝔇 ≡ d) (disk-isSet _ _) (sym (crisp-neighbor-zero d)))

    flat-unit-contractible : isContr (Flat (Unit* {ℓ = ℓ}))
    flat-unit-contractible .fst = box tt*
    flat-unit-contractible .snd (box u) = Identity.box-path tt* u (isContrUnit* .snd u)

    flat-collapse-isEquiv : isEquiv (flat-map collapse)
    flat-collapse-isEquiv = isEquivFromIsContr (flat-map collapse) flat-disk-contractible flat-unit-contractible

    sharp-disk-connected : Sharp.Connected 𝔇
    sharp-disk-connected = isOfHLevelRespectEquiv 0
      (invEquiv (Sharp.◯-map collapse , Adjunction.Map.sharp-equivalence collapse flat-collapse-isEquiv))
      (Sharp.preserves-contractible isContrUnit*)

    codiscrete→crystalline : {X : Type ℓ} → Sharp.isModal X → IsCrystalline X
    codiscrete→crystalline modalX _ = fromIsEquiv const
      (Sharp.connected-constant sharp-disk-connected modalX)

    module Factorization (X : Type ℓ) where
      factor : Im X → Sharp.◯ X
      factor = Crystal.◯-rec (codiscrete→crystalline Sharp.◯-isModal) Sharp.η

      triangle : (x : X) → factor (crystalline-unit x) ≡ Sharp.η x
      triangle = Crystal.◯-rec-β (codiscrete→crystalline Sharp.◯-isModal) Sharp.η

      unique-factor : isContr (fiber
        (λ (h : Im X → Sharp.◯ X) → h ∘ crystalline-unit) Sharp.η)
      unique-factor = equiv-proof (Crystal.unit-local (codiscrete→crystalline Sharp.◯-isModal)) Sharp.η

      -- The actual factor is itself a sharp reflection map: restriction
      -- along it is an equivalence into every codiscrete target.
      sharp-reflection : {Y : Type ℓ} → Sharp.isModal Y
        → isEquiv (λ (h : Sharp.◯ X → Y) → h ∘ factor)
      sharp-reflection {Y} modalY = isEquiv[equivFunA≃B∘f]→isEquiv[f]
        (λ h → h ∘ factor)
        ((λ (h : Im X → Y) → h ∘ crystalline-unit) ,
          Crystal.unit-local (codiscrete→crystalline modalY))
        (subst isEquiv (sym (funExt λ h → funExt λ x → cong h (triangle x)))
          (Sharp.unit-local modalY))
