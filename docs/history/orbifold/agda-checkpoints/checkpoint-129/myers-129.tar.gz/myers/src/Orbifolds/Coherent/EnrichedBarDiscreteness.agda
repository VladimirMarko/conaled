{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarDiscreteness where

-- Externality of every finite bar index is derived from discreteness of
-- objects and homs. Merely declaring the enriched category crisp would
-- not justify holding its chain indices fixed under exponentiation.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Unit using (Unit*; tt*; isPropUnit*)
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals using (flat-natural; natural-crisp-elim)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispLimits as CL
import Orbifolds.CrispNaturalDiscreteness as CN
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyDiscreteIndices as TI
import Orbifolds.GraphColimits as GC
import Orbifolds.Coherent.StrictEnriched as E
import Orbifolds.Coherent.EnrichedBarChains as BC

module Pairs {@♭ ℓ : Level} (@♭ A : Type ℓ) (@♭ B : A → Type ℓ)
    (discrete-base : CrisplyDiscrete A)
    (discrete-fiber : (@♭ a : A) → CrisplyDiscrete (B a)) where
  module Flatten = CL.Sigma B

  fiber-equivalence : (u : Flat A) → Flatten.FlatFamily u ≃ B (counit u)
  fiber-equivalence (box a) = counit , discrete-fiber a

  derived-equivalence : Flat (Σ A B) ≃ Σ A B
  derived-equivalence = Flatten.flat-sigma-equivalence ∙ₑ
    Σ-cong-equiv (counit , discrete-base) fiber-equivalence

  counit-agrees : (z : Flat (Σ A B)) → derived-equivalence .fst z ≡ counit z
  counit-agrees (box z) = refl

  discrete-sigma : CrisplyDiscrete (Σ A B)
  discrete-sigma = subst isEquiv (funExt counit-agrees) (derived-equivalence .snd)

module CrispInduction
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero) where
  module Naturals = CN.Theory identity-zero flat-zero flat-zero-computation

  module Motive {ℓp : Level} (P : (@♭ n : ℕ) → Type ℓp)
      (base : P zero) (step : (@♭ n : ℕ) → P n → P (suc n)) where
    Family : Flat ℕ → Type ℓp
    Family (box n) = P n

    advance : (u : Flat ℕ) → Family u → Family (flat-map suc u)
    advance (box n) = step n

    iterate : (n : ℕ) → Family (flat-natural n)
    iterate zero = base
    iterate (suc n) = advance (flat-natural n) (iterate n)

    induction : (@♭ n : ℕ) → P n
    induction n = subst Family (Naturals.crisp-natural-eta n) (iterate n)

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ C : E.Category ℓ ℓ) where
  open E.Category C
  module Chains = BC.Chains C
  module Identity = CI.Theory identity-rules

  unit-discrete : CrisplyDiscrete (Unit* {ℓ = ℓ})
  unit-discrete = isoToIsEquiv (iso counit (λ _ → box tt*)
    (λ u → isPropUnit* tt* u)
    (λ { (box u) → Identity.box-path tt* u (isPropUnit* tt* u) }))

  chain-discrete : CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (@♭ n : ℕ) (@♭ y : Obj) → CrisplyDiscrete (Chains.Chain n y)
  chain-discrete discrete-objects discrete-homs =
    CrispInduction.Motive.induction identity-zero flat-zero flat-zero-computation
      (λ n → (@♭ y : Obj) → CrisplyDiscrete (Chains.Chain n y))
      (λ y → unit-discrete)
      (λ n previous y → Pairs.discrete-sigma Obj
        (λ x → Hom x y × Chains.Chain n x) discrete-objects
        (λ x → Pairs.discrete-sigma (Hom x y) (λ _ → Chains.Chain n x)
          (discrete-homs x y) (λ _ → previous x)))

  index-discrete : CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (@♭ n : ℕ) → CrisplyDiscrete (Chains.Index n)
  index-discrete discrete-objects discrete-homs n =
    Pairs.discrete-sigma Obj (Chains.Chain n) discrete-objects
      (chain-discrete discrete-objects discrete-homs n)

  module Power
      (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
      (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
      (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ) where
    module Indices = TI.Context identity-rules flat-induction flat-computation R r₀ T
    open Indices using (RealFlat) public

    indices-null : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
      → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
      → (n : ℕ) → isEquiv (const :> (Chains.Index n → (T → Chains.Index n)))
    indices-null real-flat tiny discrete-objects discrete-homs =
      natural-crisp-elim (λ n → isEquiv (const :> (Chains.Index n → (T → Chains.Index n))))
        (λ n → Indices.Index.null-index (Chains.Index n) real-flat
          (index-discrete discrete-objects discrete-homs n) tiny)

    module Coefficients (Coefficient : (n : ℕ) → Chains.Index n → Type ℓ) where
      comparison : (n : ℕ) → (Σ[ c ∈ Chains.Index n ] (T → Coefficient n c))
        → (T → Σ (Chains.Index n) (Coefficient n))
      comparison n (c , v) t = c , v t

      preserves-coefficients : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
        → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
        → (n : ℕ) → isEquiv (comparison n)
      preserves-coefficients real-flat tiny discrete-objects discrete-homs n =
        GC.Coproduct.preserves T (Chains.Index n) (Coefficient n)
          (indices-null real-flat tiny discrete-objects discrete-homs n)
