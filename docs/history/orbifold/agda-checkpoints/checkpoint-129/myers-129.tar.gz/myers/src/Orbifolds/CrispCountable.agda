{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispCountable where

-- An ordinary element of a crisp subcountable type can be represented
-- crisply. The proof uses native Nat induction and R-flatness only on
-- crisp proposition fibers; no unrestricted context reset is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; isSetℕ)
import Cubical.Data.SumFin as SF
open import Cubical.Functions.Embedding
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
import Orbifolds.CrispPropositions as CP

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R) where
  module Propositions = CP.Context R r₀

  module Embedded {@♭ A : Type ℓ} (@♭ e : A ↪ ℕ) where
    crisp-element-elim : {ℓp : Level} → Propositions.RealFlat
      → (P : A → Type ℓp) → ((@♭ a : A) → P a) → (a : A) → P a
    crisp-element-elim real-flat P step a = natural-crisp-elim
      (λ k → e .fst a ≡ k → P a)
      (λ k p → flat-elim (λ _ → P a)
        (λ u → subst P
          (isEmbedding→Inj (e .snd) (u .fst) a (u .snd ∙ sym p))
          (step (u .fst)))
        (Propositions.promote-proof real-flat (fiber (e .fst) k)
          (isEmbedding→hasPropFibers (e .snd) k) (a , p)))
      (e .fst a) refl

  module FiniteOrdinal (@♭ n : ℕ) where
    Lifted : Type ℓ
    Lifted = Lift {ℓ-zero} {ℓ} (SF.Fin n)

    natural-embedding : Lifted ↪ ℕ
    natural-embedding = (SF.toℕ ∘ lower) , injEmbedding isSetℕ
      (λ p → cong lift (SF.toℕ-injective p))

    module LiftedElimination = Embedded natural-embedding

    crisp-fin-elim : {ℓp : Level} → Propositions.RealFlat
      → (P : SF.Fin n → Type ℓp)
      → ((@♭ i : SF.Fin n) → P i) → (i : SF.Fin n) → P i
    crisp-fin-elim real-flat P step i = LiftedElimination.crisp-element-elim
      real-flat (P ∘ lower) (λ u → step (lower u)) (lift i)
