{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedAttachmentInterface where

-- The data and literal restriction of a quoted attachment, without
-- copying the nested quotation/equivalence proof namespaces into clients.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedCellAttachments as Original
import Orbifolds.Coherent.NaturalQuotedCellRestriction as Restriction
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)
import Cubical.HITs.Pushout as PO

module Attachment {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A Index : Type ℓ) (Coefficient : Index → Type ℓ)
    (original-boundary : (c : Index) → CS.Shell (toNat n) (Coefficient c → A)) where
  Cell : Type ℓ
  Cell = Σ Index Coefficient

  Boundary : Type ℓ
  Boundary = Cell × SphereBoundary (toNat n)

  attach : Boundary → A
  attach = Original.Attachment.attach E n A Index Coefficient original-boundary

  boundary : Boundary → Cell
  boundary = fst

  Realize : Type ℓ
  Realize = PO.Pushout attach boundary

  include : A → Realize
  include = PO.inl

  center : Cell → Realize
  center = PO.inr

  mapped-boundary : (Y : Type ℓ) → (A → Y) → (c : Index)
    → CS.Shell (toNat n) (Coefficient c → Y)
  mapped-boundary Y h c = Shells.Action.map-shell E n (λ v → h ∘ v) (original-boundary c)

  Cocone : Type ℓ → Type ℓ
  Cocone Y = Σ[ h ∈ (A → Y) ] ((c : Index) → CF.Filler (toNat n) (mapped-boundary Y h c))

  module Target (Y : Type ℓ) where
    restrict : (Realize → Y) → Cocone Y
    restrict = Restriction.Representation.restrict E n A Index Coefficient original-boundary Y

    universal : (Realize → Y) ≃ Cocone Y
    universal = Restriction.Representation.universal E n A Index Coefficient original-boundary Y

  canonical-cocone : Cocone Realize
  canonical-cocone = Target.restrict Realize (idfun Realize)

  postcompose : {Y Z : Type ℓ} → (Y → Z) → Cocone Y → Cocone Z
  postcompose = Original.Attachment.postcompose E n A Index Coefficient original-boundary
