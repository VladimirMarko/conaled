{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CompactSeparation where

-- Classical point-set geometry, separate from the smooth internal model.
-- CompactData chooses a finite subcover of each supplied indexed cover.
-- Chosen separation and compact-neighborhood data are explicit inputs.
-- The theorems construct closed images from these genuine cover data;
-- classical properness is never identified with the old DPProper predicate.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Empty; empty-elim; Not; PropositionalDNE
  ; Subset; member; member-prop; Included; full; intersection; complement
  ; Image; outsideImage; OpenFragment; IsOpen; open-full; open-intersection
  ; open-local; ClosedMap )

private variable ℓ : Level

infixr 5 _∷_
infixr 4 _⊎_

data _⊎_ (A B : Set ℓ) : Set ℓ where
  inl : A → A ⊎ B
  inr : B → A ⊎ B

PropositionalEM : (ℓ : Level) → Set (Code ℓ)
PropositionalEM ℓ = {P : Set ℓ} → isProp P → P ⊎ Not P

em→dne : PropositionalEM ℓ → PropositionalDNE ℓ
em→dne classical prop double with classical prop
... | inl p = p
... | inr not-p = empty-elim (double not-p)

data List (A : Set ℓ) : Set ℓ where
  [] : List A
  _∷_ : A → List A → List A

data Some {A : Set ℓ} (P : A → Set ℓ) : List A → Set ℓ where
  here : {x : A} {xs : List A} → P x → Some P (x ∷ xs)
  there : {x : A} {xs : List A} → Some P xs → Some P (x ∷ xs)

Covers : {A I : Set ℓ} → Subset A → (I → Subset A) → Set ℓ
Covers {A = A} {I = I} K U =
  (a : A) → member K a → Σ I (λ i → member (U i) a)

CoversListed : {A I : Set ℓ}
  → Subset A → (I → Subset A) → List I → Set ℓ
CoversListed {A = A} K U indices =
  (a : A) → member K a → Some (λ i → member (U i) a) indices

FiniteSubcover : {A I : Set ℓ}
  → Subset A → (I → Subset A) → Set ℓ
FiniteSubcover {I = I} K U = Σ (List I) (CoversListed K U)

-- A data form of the finite-subcover property. It is intentionally not
-- declared proposition-valued. Standard classical compactness supplies
-- this selected operation with external choice at the fixed universe.
CompactData : {A : Set ℓ} → OpenFragment A → Subset A → Set (Code ℓ)
CompactData {ℓ} {A} O K = {I : Set ℓ} (U : I → Subset A)
  → ((i : I) → IsOpen O (U i)) → Covers K U → FiniteSubcover K U

preimage : {A B : Set ℓ} → (A → B) → Subset B → Subset A
member (preimage f U) a = member U (f a)
member-prop (preimage f U) a = member-prop U (f a)

Continuous : {A B : Set ℓ}
  → OpenFragment A → OpenFragment B → (A → B) → Set (Code ℓ)
Continuous OA OB f = (U : Subset _) → IsOpen OB U → IsOpen OA (preimage f U)

record SeparatedNeighborhoods {A : Set ℓ} (O : OpenFragment A)
    (x y : A) : Set (Code ℓ) where
  field
    near-left near-right : Subset A
    left-open : IsOpen O near-left
    right-open : IsOpen O near-right
    left-center : member near-left x
    right-center : member near-right y
    disjoint : (z : A) → member near-left z → member near-right z → Empty {ℓ}

ChosenHausdorff : {A : Set ℓ} → OpenFragment A → Set (Code ℓ)
ChosenHausdorff {A = A} O = (x y : A) → Not (x ≡ y) → SeparatedNeighborhoods O x y

meet : {A I : Set ℓ} → (I → Subset A) → List I → Subset A
meet U [] = full
meet U (i ∷ indices) = intersection (U i) (meet U indices)

meet-open : {A I : Set ℓ} (O : OpenFragment A) (U : I → Subset A)
  → ((i : I) → IsOpen O (U i)) → (indices : List I) → IsOpen O (meet U indices)
meet-open O U opens [] = open-full O
meet-open O U opens (i ∷ indices) =
  open-intersection O (opens i) (meet-open O U opens indices)

meet-center : {A I : Set ℓ} (U : I → Subset A) (a : A)
  → ((i : I) → member (U i) a) → (indices : List I) → member (meet U indices) a
meet-center U a centers [] = tt
meet-center U a centers (i ∷ indices) = centers i , meet-center U a centers indices

meet-excludes-cover : {A I : Set ℓ} (L R : I → Subset A)
  → ((i : I) (a : A) → member (L i) a → member (R i) a → Empty {ℓ})
  → (indices : List I) → (a : A) → member (meet L indices) a
  → Some (λ i → member (R i) a) indices → Empty {ℓ}
meet-excludes-cover L R disjoint [] a all ()
meet-excludes-cover L R disjoint (i ∷ indices) a (li , all) (here ri) =
  disjoint i a li ri
meet-excludes-cover L R disjoint (i ∷ indices) a (li , all) (there rest) =
  meet-excludes-cover L R disjoint indices a all rest

-- The image witness is not resized or assumed a proposition. Its
-- complement is open by separating an outside point from the compact
-- source and using an actual finite subcover of the source.
compact-image-closed : {A B : Set ℓ} (ext : FunExt ℓ ℓ)
  → (OA : OpenFragment A) → (OB : OpenFragment B)
  → ChosenHausdorff OB → (f : A → B) → Continuous OA OB f
  → (C : Subset A) → CompactData OA C → IsOpen OB (outsideImage ext f C)
compact-image-closed {ℓ} {A} {B} ext OA OB separated f continuous C compact =
  open-local OB (outsideImage ext f C) neighborhood
  where
  neighborhood : (y : B) → Not (Image f C y)
    → Σ (Subset B) (λ W → Σ (IsOpen OB W)
      (λ _ → Σ (member W y) (λ _ → Included W (outsideImage ext f C))))
  neighborhood y no-image = W , open-W , center-W , included-W
    where
    Index : Set ℓ
    Index = Σ A (member C)

    separate : (i : Index) → SeparatedNeighborhoods OB y (f (fst i))
    separate (a , ca) = separated y (f a) (λ p → no-image (a , ca , sym p))

    L R : Index → Subset B
    L i = SeparatedNeighborhoods.near-left (separate i)
    R i = SeparatedNeighborhoods.near-right (separate i)

    patches : Index → Subset A
    patches i = preimage f (R i)

    patches-open : (i : Index) → IsOpen OA (patches i)
    patches-open i = continuous (R i) (SeparatedNeighborhoods.right-open (separate i))

    patches-cover : Covers C patches
    patches-cover a ca = (a , ca) , SeparatedNeighborhoods.right-center (separate (a , ca))

    finite : FiniteSubcover C patches
    finite = compact patches patches-open patches-cover

    indices : List Index
    indices = fst finite

    W : Subset B
    W = meet L indices

    open-W : IsOpen OB W
    open-W = meet-open OB L (λ i → SeparatedNeighborhoods.left-open (separate i)) indices

    center-W : member W y
    center-W = meet-center L y (λ i → SeparatedNeighborhoods.left-center (separate i)) indices

    included-W : Included W (outsideImage ext f C)
    included-W z wz (a , ca , at-z) =
      meet-excludes-cover L R (λ i → SeparatedNeighborhoods.disjoint (separate i))
        indices (f a) (subst (member W) (sym at-z) wz) (snd finite a ca)

lefts : {I : Set ℓ} → List (I ⊎ Unit) → List I
lefts [] = []
lefts (inl i ∷ indices) = i ∷ lefts indices
lefts (inr _ ∷ indices) = lefts indices

closed-subset-compact : {A : Set ℓ} (ext : FunExt ℓ ℓ)
  → PropositionalEM ℓ → (O : OpenFragment A) → (K C : Subset A)
  → CompactData O K → IsOpen O (complement ext C)
  → CompactData O (intersection K C)
closed-subset-compact {ℓ} {A} ext classical O K C compact closed {I} U opens covers =
  lefts (fst finite) , λ a kc → restrict (fst finite) a (snd kc) (snd finite a (fst kc))
  where
  extended : I ⊎ Unit → Subset A
  extended (inl i) = U i
  extended (inr _) = complement ext C

  extended-open : (i : I ⊎ Unit) → IsOpen O (extended i)
  extended-open (inl i) = opens i
  extended-open (inr _) = closed

  extended-cover : Covers K extended
  extended-cover a ka with classical (member-prop C a)
  ... | inl ca = inl (fst chosen) , snd chosen
    where
    chosen = covers a (ka , ca)
  ... | inr outside = inr tt , outside

  finite : FiniteSubcover K extended
  finite = compact extended extended-open extended-cover

  restrict : (indices : List (I ⊎ Unit)) → (a : A) → member C a
    → Some (λ i → member (extended i) a) indices
    → Some (λ i → member (U i) a) (lefts indices)
  restrict [] a ca ()
  restrict (inl i ∷ indices) a ca (here member-i) = here member-i
  restrict (inl i ∷ indices) a ca (there rest) = there (restrict indices a ca rest)
  restrict (inr _ ∷ indices) a ca (here outside) = empty-elim (outside ca)
  restrict (inr _ ∷ indices) a ca (there rest) = restrict indices a ca rest

ProperData : {A B : Set ℓ}
  → OpenFragment A → OpenFragment B → (A → B) → Set (Code ℓ)
ProperData OA OB f = (K : Subset _) → CompactData OB K → CompactData OA (preimage f K)

record CompactNeighborhood {A : Set ℓ} (O : OpenFragment A) (a : A) : Set (Code ℓ) where
  field
    compact-set inner : Subset A
    compact : CompactData O compact-set
    inner-open : IsOpen O inner
    center : member inner a
    inside : Included inner compact-set

ChosenLocallyCompact : {A : Set ℓ} → OpenFragment A → Set (Code ℓ)
ChosenLocallyCompact {A = A} O = (a : A) → CompactNeighborhood O a

-- A continuous map with compact preimages into a locally compact
-- Hausdorff space is closed. Every neighborhood and image step below
-- is built from the preceding finite-subcover construction.
proper→closed : {A B : Set ℓ} (ext : FunExt ℓ ℓ)
  → PropositionalEM ℓ → (OA : OpenFragment A) → (OB : OpenFragment B)
  → ChosenHausdorff OB → ChosenLocallyCompact OB
  → (f : A → B) → Continuous OA OB f → ProperData OA OB f
  → ClosedMap ext OA OB f
proper→closed {ℓ} {A} {B} ext classical OA OB separated locally-compact
    f continuous proper C closed =
  open-local OB (outsideImage ext f C) neighborhood
  where
  neighborhood : (y : B) → Not (Image f C y)
    → Σ (Subset B) (λ W → Σ (IsOpen OB W)
      (λ _ → Σ (member W y) (λ _ → Included W (outsideImage ext f C))))
  neighborhood y no-image = W , open-W , center-W , included-W
    where
    N : CompactNeighborhood OB y
    N = locally-compact y

    K V : Subset B
    K = CompactNeighborhood.compact-set N
    V = CompactNeighborhood.inner N

    Q : Subset A
    Q = intersection (preimage f K) C

    compact-Q : CompactData OA Q
    compact-Q = closed-subset-compact ext classical OA (preimage f K) C
      (proper K (CompactNeighborhood.compact N)) closed

    outside-Q : Subset B
    outside-Q = outsideImage ext f Q

    outside-Q-open : IsOpen OB outside-Q
    outside-Q-open = compact-image-closed ext OA OB separated f continuous Q compact-Q

    W : Subset B
    W = intersection V outside-Q

    open-W : IsOpen OB W
    open-W = open-intersection OB (CompactNeighborhood.inner-open N) outside-Q-open

    center-W : member W y
    center-W = CompactNeighborhood.center N , λ { (a , ka-ca , p) → no-image (a , snd ka-ca , p) }

    included-W : Included W (outsideImage ext f C)
    included-W z (vz , excludes) (a , ca , at-z) =
      excludes (a , (subst (member K) (sym at-z) (CompactNeighborhood.inside N z vz) , ca) , at-z)
