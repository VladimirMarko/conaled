{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarConeCompatibility where

-- The actual all-dimensional cubical bar boundary is compatible.
-- Every one of its four endpoint overlaps is derived from earlier cone
-- fillers, strict categorical associativity and the strict diagram law.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; star)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
open import Orbifolds.Coherent.EnrichedBarConeData using (LawPair)
import Orbifolds.Coherent.EnrichedBarConeData as Data

module Compatibility {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Diagram D
  open Chains C
  open Data.Data C D
  open Coherence E
  open StrictCubicalExtensionality E
  open Cubes.Extensional E

  -- A later coordinate is ignored after a cut. Deleting that later
  -- vertex only changes the parenthesization of the suffix action.
  one-later : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P) (s : P)
    (p q : Position (osuc n)) (le : p ≤ᵖ q) (i : I)
    {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (coordinate-face n p i (one-face (osuc n) F s (psuc q) c))
      ≡ˢ outer (one-face n (F .fst) s q (face (osuc n) (weaken p) c))
  one-later n F s pzero q pzero≤ i c = strict-sym
    (one-extend n (F .fst) s q (last-arrow (osuc n) c) (prefix (osuc n) c))
  one-later (osuc n) F s (psuc p) (psuc q) (psuc≤ le) i c = interval-ext λ j →
    strict-trans
      (strict-sym (map-face n p i (action (last-arrow (osuc (osuc n)) c))
        (one-face (osuc n) (F .fst) s (psuc q) (prefix (osuc (osuc n)) c))))
      (strict-cong (λ z → outer (map-cube n (action (last-arrow (osuc (osuc n)) c)) (inner z)))
        (one-later n (F .fst) s p q le i (prefix (osuc (osuc n)) c)))

  -- Restricting an earlier coordinate at zero deletes that vertex
  -- from the retained prefix. The previous cone's zero-face law applies.
  one-zero : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    → Coherent (osuc n) F → (s : P)
    → (p q : Position (osuc n)) → p ≤ᵖ q
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (coordinate-face n q i0 (one-face (osuc n) F s (weaken p) c))
      ≡ˢ outer (one-face n (F .fst) s p (face (osuc n) (psuc q) c))
  one-zero n F coherent s pzero q pzero≤ c = strict-trans
    (strict-sym (map-face n q i0 (action (last-arrow (osuc n) c))
      (top (osuc n) F s (last-source (osuc n) c) (prefix (osuc n) c))))
    (strict-cong (λ z → outer (map-cube n (action (last-arrow (osuc n) c)) (inner z)))
      (LayerLaws.zero-face (LawPair.current coherent) s
        (last-source (osuc n) c) (prefix (osuc n) c) q))
  one-zero (osuc n) F coherent s (psuc p) (psuc q) (psuc≤ le) c = interval-ext λ i →
    strict-trans
      (strict-sym (map-face n q i0 (action (last-arrow (osuc (osuc n)) c))
        (one-face (osuc n) (F .fst) s (weaken p) (prefix (osuc (osuc n)) c))))
      (strict-cong (λ z → outer (map-cube n (action (last-arrow (osuc (osuc n)) c)) (inner z)))
        (one-zero n (F .fst) (LawPair.earlier coherent) s p q le
          (prefix (osuc (osuc n)) c)))

  -- Restricting that earlier coordinate at one cuts the prefix again.
  -- The two actual suffix actions compose by the diagram law.
  one-one : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    → Coherent (osuc n) F → (s : P)
    → (p q : Position (osuc n)) → p ≤ᵖ q
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (coordinate-face n q i1 (one-face (osuc n) F s (weaken p) c))
      ≡ˢ outer (one-face n (F .fst) s q (face (osuc n) (weaken p) c))
  one-one n F coherent s pzero q pzero≤ c = strict-trans
    (strict-sym (map-face n q i1 (action (last-arrow (osuc n) c))
      (top (osuc n) F s (last-source (osuc n) c) (prefix (osuc n) c))))
    (strict-trans
      (strict-cong (λ z → outer (map-cube n (action (last-arrow (osuc n) c)) (inner z)))
        (LayerLaws.one-face-law (LawPair.current coherent) s
          (last-source (osuc n) c) (prefix (osuc n) c) q))
      (strict-sym (one-extend n (F .fst) s q
        (last-arrow (osuc n) c) (prefix (osuc n) c))))
  one-one (osuc n) F coherent s (psuc p) (psuc q) (psuc≤ le) c = interval-ext λ i →
    strict-trans
      (strict-sym (map-face n q i1 (action (last-arrow (osuc (osuc n)) c))
        (one-face (osuc n) (F .fst) s (weaken p) (prefix (osuc (osuc n)) c))))
      (strict-cong (λ z → outer (map-cube n (action (last-arrow (osuc (osuc n)) c)) (inner z)))
        (one-one n (F .fst) (LawPair.earlier coherent) s p q le
          (prefix (osuc (osuc n)) c)))

  bar-compatible : (n : Dim) {P : Type ℓ} (F : Families n P)
    → Coherent n F → (s : P) → {y : Obj} (c : Chain (osuc n) y)
    → Assembly.Compatible (osuc n) (bar-faces n F s c)
  bar-compatible ozero F coherent s c = star
  bar-compatible (osuc n) F coherent s {y} c p q le low low = strict-trans
    (LayerLaws.zero-face (LawPair.current coherent) s y (face (osuc n) (psuc q) c) p)
    (strict-trans
      (strict-cong (λ z → outer (top n (F .fst) s y (inner z))) (face-face n p q le c))
      (strict-sym (LayerLaws.zero-face (LawPair.current coherent) s y
        (face (osuc n) (weaken p) c) q)))
  bar-compatible (osuc n) F coherent s {y} c p q le low high = strict-trans
    (one-later n F s p q le i0 c)
    (strict-sym (LayerLaws.one-face-law (LawPair.current coherent) s y
      (face (osuc n) (weaken p) c) q))
  bar-compatible (osuc n) F coherent s {y} c p q le high low = strict-trans
    (LayerLaws.one-face-law (LawPair.current coherent) s y (face (osuc n) (psuc q) c) p)
    (strict-sym (one-zero n F coherent s p q le c))
  bar-compatible (osuc n) F coherent s {y} c p q le high high = strict-trans
    (one-later n F s p q le i1 c)
    (strict-sym (one-one n F coherent s p q le c))
