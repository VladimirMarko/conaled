{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DeloopedFreeActionQuotients where

-- A universe-polymorphic recognition theorem for free set actions.
-- The family and all its loop transports are supplied explicitly; the
-- resulting orbit-set equivalence and its quotient triangle are proved.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Transport
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
open import Cubical.Functions.Embedding using (injEmbedding)
open import Cubical.Functions.Surjection using
  (isSurjection; isEmbedding×isSurjection→isEquiv)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.SetQuotients as SQ
import Orbifolds.Quotients as Q
import Orbifolds.Torsors as Torsors

module Recognition {ℓd ℓb ℓ : Level}
    (D : Q.Delooping ℓd) (Bundle : Q.BG D → Type ℓb)
    (bundle-set : (b : Q.BG D) → isSet (Bundle b))
    (G : Group ℓ) (A : Torsors.Theory.Action G)
    (coordinates : Bundle (Q.point D) ≃ Torsors.Theory.Carrier G A)
    (loop-coordinates : Q.Loop D ≃ G .fst)
    (loop-unit : loop-coordinates .fst refl ≡ GroupStr.1g (G .snd))
    (all-loop-transport : (p : Q.Loop D) (x : Torsors.Theory.Carrier G A)
      → coordinates .fst (subst Bundle p (invEq coordinates x))
        ≡ Torsors.Theory.act G A
          (GroupStr.inv (G .snd) (loop-coordinates .fst p)) x)
    (free : (g : G .fst) (x : Torsors.Theory.Carrier G A)
      → Torsors.Theory.act G A g x ≡ x → g ≡ GroupStr.1g (G .snd)) where

  module T = Torsors.Theory G
  module Family = Q.FamilyAction D Bundle
  open GroupStr (G .snd)
  open GroupTheory G using (invInv; inv1g)

  X = T.Carrier A
  HomotopyQuotient = Family.Quotient

  orbit : X → HomotopyQuotient
  orbit x = Family.quotient (invEq coordinates x)

  Relation : X → X → Type ℓ
  Relation x y = Σ[ g ∈ G .fst ] T.act A g x ≡ y

  OrbitSet : Type ℓ
  OrbitSet = X SQ./ Relation

  abstract
    stabilizer-loop-trivial : (x : X) (p : Q.Loop D)
      → Family.act p (invEq coordinates x) ≡ invEq coordinates x → p ≡ refl
    stabilizer-loop-trivial x p e = invEq (congEquiv loop-coordinates)
      (coordinate-trivial ∙ sym loop-unit)
      where
      c : G .fst
      c = loop-coordinates .fst p
      fixes : T.act A (inv c) x ≡ x
      fixes = sym (all-loop-transport p x)
        ∙ cong (coordinates .fst) e ∙ secEq coordinates x
      coordinate-trivial : c ≡ 1g
      coordinate-trivial = sym (invInv c)
        ∙ cong inv (free (inv c) x fixes) ∙ inv1g

    stabilizer-contractible : (x : X)
      → isContr (Family.Stabilizer (invEq coordinates x))
    stabilizer-contractible x =
      (refl , Family.action-unit (invEq coordinates x)) , λ (p , e) →
        Σ≡Prop (λ q → bundle-set (Q.point D) _ _)
          (sym (stabilizer-loop-trivial x p e))

    orbit-loops-prop : (x : X) → isProp (orbit x ≡ orbit x)
    orbit-loops-prop x = isOfHLevelRespectEquiv 1
      (invEquiv (Family.isotropy≃stabilizer (invEq coordinates x)))
      (isContr→isProp (stabilizer-contractible x))

    quotient-loops-prop : (z : HomotopyQuotient) → isProp (z ≡ z)
    quotient-loops-prop = Family.quotient-proposition-induction
      (λ z → isProp (z ≡ z)) (λ z → isPropIsProp)
      (λ f → subst (λ z → isProp (z ≡ z))
        (cong Family.quotient (retEq coordinates f))
        (orbit-loops-prop (coordinates .fst f)))

    quotient-set : isSet HomotopyQuotient
    quotient-set x y p = J (λ y p → (q : x ≡ y) → p ≡ q)
      (quotient-loops-prop x refl) p

    action-path : (g : G .fst) (x : X)
      → orbit x ≡ orbit (T.act A g x)
    action-path g x = Family.action-path p (invEq coordinates x)
      ∙ cong Family.quotient (invEq (congEquiv coordinates)
        (all-loop-transport p x
          ∙ cong (λ h → T.act A h x)
            (cong inv (secEq loop-coordinates (inv g)) ∙ invInv g)
          ∙ sym (secEq coordinates (T.act A g x))))
      where
      p : Q.Loop D
      p = invEq loop-coordinates (inv g)

    path-to-relation : (x y : X) → orbit x ≡ orbit y → Relation x y
    path-to-relation x y e = inv (loop-coordinates .fst (witness .fst)) ,
      sym (all-loop-transport (witness .fst) x)
        ∙ cong (coordinates .fst) (witness .snd) ∙ secEq coordinates y
      where
      witness : Σ[ p ∈ Q.Loop D ] Family.act p (invEq coordinates x) ≡ invEq coordinates y
      witness = Family.quotient-identifications (invEq coordinates x)
        (invEq coordinates y) .fst e

  relation-path : (x y : X) → Relation x y → orbit x ≡ orbit y
  relation-path x y (g , e) = action-path g x ∙ cong orbit e

  from-orbit-set : OrbitSet → HomotopyQuotient
  from-orbit-set = SQ.rec quotient-set orbit relation-path

  abstract
    from-injective : (q r : OrbitSet)
      → from-orbit-set q ≡ from-orbit-set r → q ≡ r
    from-injective = SQ.elimProp2 (λ q r → isPropΠ λ _ → SQ.squash/ q r)
      (λ x y p → SQ.eq/ x y (path-to-relation x y p))

    from-surjective : isSurjection from-orbit-set
    from-surjective z = PT.map
      (λ (f , p) → SQ.[ coordinates .fst f ] ,
        cong Family.quotient (retEq coordinates f) ∙ p)
      (Family.quotient-surjective z)

    from-isEquiv : isEquiv from-orbit-set
    from-isEquiv = isEmbedding×isSurjection→isEquiv
      (injEmbedding quotient-set (from-injective _ _) , from-surjective)

  orbit-set≃homotopy-quotient : OrbitSet ≃ HomotopyQuotient
  orbit-set≃homotopy-quotient = from-orbit-set , from-isEquiv

  homotopy-quotient≃orbit-set : HomotopyQuotient ≃ OrbitSet
  homotopy-quotient≃orbit-set = invEquiv orbit-set≃homotopy-quotient

  quotient-triangle : (x : X)
    → homotopy-quotient≃orbit-set .fst (orbit x) ≡ SQ.[ x ]
  quotient-triangle x = retEq orbit-set≃homotopy-quotient SQ.[ x ]
