{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCellStageComparison where

-- Compare the explicit mapped-shell cells with the actual next finite
-- bar stage. The comparison and its strict target naturality are derived
-- from the actual stage action and boundary square. Its equivalence uses
-- only the preceding stage's already constructed representation.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-filler-compose)
open import Orbifolds.Coherent.StrictCubicalFillerCastCoherence
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentFiniteTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.NaturalQuotedCellAttachments as Attachments
import Orbifolds.Coherent.StrictCubicalShellFunctor as ShellFunctor
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.StrictCubicalFillerCastCoherence as Casts
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Comparison {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  open StrictFunctionExtensionality F
  module R = Represented.Induction C D E F
  open R.Represented previous renaming
    (Space to Previous; universal-cocone to u; universal to previous-universal)
  open Cocones.Functoriality C D E F using (Cocone; postcompose)

  Index : Type ℓ
  Index = Chains.Index (Opposite C) (osuc n)

  Coefficient : Index → Type ℓ
  Coefficient c = HC.ForCategory.Diagram.Value D (c .fst)

  actual-boundary : (Y : Type ℓ) → Cocone Y n → (c : Index)
    → CS.Shell (toNat (osuc n)) (Coefficient c → Y)
  actual-boundary Y = Finite.Finite.At.boundary-data
    (Opposite C) (Mapping.Mapping.Into C D E F Y) E n

  original-boundary : (c : Index) → CS.Shell (toNat (osuc n)) (Coefficient c → Previous)
  original-boundary = actual-boundary Previous u

  module Cell = Attachments.Attachment E (osuc n) Previous Index Coefficient original-boundary
  module SF = ShellFunctor.Functoriality E
  module FM = Fillers.Action E
  module Cast = Casts.Coherence E

  boundary-natural : (Y : Type ℓ) (h : Previous → Y) (c : Index)
    → outer (Cell.mapped-boundary Y h c)
      ≡ˢ outer (actual-boundary Y (postcompose n h u) c)
  boundary-natural Y h c = Transformations.Action.stage-boundary-natural
    (Mapping.Mapping.Into C D E F Previous) (Mapping.Mapping.Into C D E F Y)
    (Mapping.Mapping.Postcompose C D E F h) E n u (c .fst) (c .snd)

  compare : (Y : Type ℓ) → Cell.Cocone Y → Cocone Y (osuc n)
  compare Y (h , fs) = postcompose n h u , λ c → cast-filler (osuc n)
    (boundary-natural Y h c) (fs c)

  comparison : (Y : Type ℓ) → Cell.Cocone Y ≃ Cocone Y (osuc n)
  comparison Y = Σ-cong-equiv (previous-universal Y) λ h →
    equivΠCod λ c → cast-filler-equivalence (osuc n) (boundary-natural Y h c)

  comparison-computation : (Y : Type ℓ) (s : Cell.Cocone Y)
    → comparison Y .fst s ≡ compare Y s
  comparison-computation Y s = refl

  actual-map-boundary : {Y Z : Type ℓ} (k : Y → Z) (s : Cocone Y n) (c : Index)
    → outer (Shells.Action.map-shell E (osuc n) (λ v → k ∘ v)
        (actual-boundary Y s c))
      ≡ˢ outer (actual-boundary Z (postcompose n k s) c)
  actual-map-boundary {Y} {Z} k s c = Transformations.Action.stage-boundary-natural
    (Mapping.Mapping.Into C D E F Y) (Mapping.Mapping.Into C D E F Z)
    (Mapping.Mapping.Postcompose C D E F k) E n s (c .fst) (c .snd)

  base-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Previous → Y)
    → outer (postcompose n k (postcompose n h u)) ≡ˢ outer (postcompose n (k ∘ h) u)
  base-natural k h = Cocones.Functoriality.postcompose-compose C D E F n h k u

  filler-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Previous → Y)
    (fs : (c : Index) → CF.Filler (toNat (osuc n)) (Cell.mapped-boundary Y h c))
    (c : Index)
    → outer (strict-subst (λ s → CF.Filler (toNat (osuc n)) (actual-boundary Z s c))
        (base-natural k h) (postcompose (osuc n) k (compare Y (h , fs)) .snd c))
      ≡ˢ outer (compare Z (Cell.postcompose k (h , fs)) .snd c)
  filler-natural {Y} {Z} k h fs c = strict-trans
    (strict-subst-filler (osuc n) (λ s → actual-boundary Z s c) (base-natural k h)
      (postcompose (osuc n) k (compare Y (h , fs)) .snd c))
    (strict-trans
      (Cast.paste-map-cast (osuc n) (λ v → k ∘ v)
        (boundary-natural Y h c)
        (actual-map-boundary k (postcompose n h u) c)
        (strict-cong (λ s → outer (actual-boundary Z (inner s) c)) (base-natural k h))
        (strict-trans
          (SF.map-compose (osuc n) (λ v → k ∘ v) (λ v → h ∘ v) (original-boundary c))
          (boundary-natural Z (k ∘ h) c)) (fs c))
      (strict-sym (cast-filler-compose (osuc n)
        (SF.map-compose (osuc n) (λ v → k ∘ v) (λ v → h ∘ v) (original-boundary c))
        (boundary-natural Z (k ∘ h) c)
        (FM.map-filler (osuc n) (λ v → k ∘ v) (Cell.mapped-boundary Y h c) (fs c)))))

  compare-natural : {Y Z : Type ℓ} (k : Y → Z) (s : Cell.Cocone Y)
    → outer (postcompose (osuc n) k (compare Y s))
      ≡ˢ outer (compare Z (Cell.postcompose k s))
  compare-natural {Y} {Z} k (h , fs) = strict-sigma (base-natural k h)
    (strict-trans
      (strict-subst-Π (λ s c → CF.Filler (toNat (osuc n)) (actual-boundary Z s c))
        (base-natural k h) (postcompose (osuc n) k (compare Y (h , fs)) .snd))
      (function-ext (filler-natural k h fs)))
