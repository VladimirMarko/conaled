{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CategoricalTransfer where

-- A bounded ordinary categorical interface for an obstruction-transfer
-- theorem. All structure below is input data, not a constructed sheaf or
-- higher type-theoretic model. The actual-map inverse operations reuse
-- the accepted intensional development.

open import Agda.Primitive using (Level; Set; lsuc; _⊔_)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (InverseData; asEquiv)

private variable o h ℓ : Level

record Category (o h : Level) : Set (lsuc (o ⊔ h)) where
  field
    Obj : Set o
    Hom : Obj → Obj → Set h
    hom-set : (X Y : Obj) → isSet (Hom X Y)
    identity : {X : Obj} → Hom X X
    compose : {X Y Z : Obj} → Hom Y Z → Hom X Y → Hom X Z
    identity-left : {X Y : Obj} (f : Hom X Y) → compose identity f ≡ f
    identity-right : {X Y : Obj} (f : Hom X Y) → compose f identity ≡ f
    associative : {W X Y Z : Obj}
      (h : Hom Y Z) (g : Hom X Y) (f : Hom W X)
      → compose (compose h g) f ≡ compose h (compose g f)

record Functor (C D : Category o h) : Set (o ⊔ h) where
  private
    module C = Category C
    module D = Category D
  field
    object : C.Obj → D.Obj
    arrow : {X Y : C.Obj} → C.Hom X Y → D.Hom (object X) (object Y)
    arrow-identity : {X : C.Obj} → arrow (C.identity {X}) ≡ D.identity
    arrow-compose : {X Y Z : C.Obj} (g : C.Hom Y Z) (f : C.Hom X Y)
      → arrow (C.compose g f) ≡ D.compose (arrow g) (arrow f)

record IsIso (C : Category o h) {X Y : Category.Obj C}
    (f : Category.Hom C X Y) : Set h where
  private module C = Category C
  field
    inverse-arrow : C.Hom Y X
    right-inverse : C.compose f inverse-arrow ≡ C.identity
    left-inverse : C.compose inverse-arrow f ≡ C.identity

record Iso (C : Category o h) (X Y : Category.Obj C) : Set h where
  constructor arrowIso
  field
    hom : Category.Hom C X Y
    is-iso : IsIso C hom

inverseIso : {C : Category o h} {X Y : Category.Obj C} → Iso C X Y → Iso C Y X
Iso.hom (inverseIso e) = IsIso.inverse-arrow (Iso.is-iso e)
IsIso.inverse-arrow (Iso.is-iso (inverseIso e)) = Iso.hom e
IsIso.right-inverse (Iso.is-iso (inverseIso e)) = IsIso.left-inverse (Iso.is-iso e)
IsIso.left-inverse (Iso.is-iso (inverseIso e)) = IsIso.right-inverse (Iso.is-iso e)

module Categorical {o h : Level} (C : Category o h) where
  open Category C

  precompose : {X Y Z : Obj} → Hom X Y → Hom Y Z → Hom X Z
  precompose f g = compose g f

  postcompose : {X Y Z : Obj} → Hom Y Z → Hom X Y → Hom X Z
  postcompose = compose

  precompose-iso : {X Y : Obj} → Iso C X Y → (Z : Obj)
    → Equiv (Hom Y Z) (Hom X Z)
  precompose-iso e Z = equiv (precompose f) (precompose g)
    (λ h → associative h g f
      ∙ cong (compose h) (IsIso.left-inverse (Iso.is-iso e))
      ∙ identity-right h)
    (λ h → associative h f g
      ∙ cong (compose h) (IsIso.right-inverse (Iso.is-iso e))
      ∙ identity-right h)
    where
    f = Iso.hom e
    g = IsIso.inverse-arrow (Iso.is-iso e)

  postcompose-iso : {Y Z : Obj} → Iso C Y Z → (X : Obj)
    → Equiv (Hom X Y) (Hom X Z)
  postcompose-iso e X = equiv (postcompose f) (postcompose g)
    (λ h → sym (associative f g h)
      ∙ cong (λ k → compose k h) (IsIso.right-inverse (Iso.is-iso e))
      ∙ identity-left h)
    (λ h → sym (associative g f h)
      ∙ cong (λ k → compose k h) (IsIso.left-inverse (Iso.is-iso e))
      ∙ identity-left h)
    where
    f = Iso.hom e
    g = IsIso.inverse-arrow (Iso.is-iso e)

  composeIso : {X Y Z : Obj} → Iso C X Y → Iso C Y Z → Iso C X Z
  Iso.hom (composeIso e d) = compose (Iso.hom d) (Iso.hom e)
  IsIso.inverse-arrow (Iso.is-iso (composeIso e d)) =
    compose (IsIso.inverse-arrow (Iso.is-iso e)) (IsIso.inverse-arrow (Iso.is-iso d))
  IsIso.right-inverse (Iso.is-iso (composeIso e d)) =
    associative g f (compose f' g')
      ∙ cong (compose g) (sym (associative f f' g'))
      ∙ cong (λ k → compose g (compose k g')) (IsIso.right-inverse (Iso.is-iso e))
      ∙ cong (compose g) (identity-left g')
      ∙ IsIso.right-inverse (Iso.is-iso d)
    where
    f = Iso.hom e
    f' = IsIso.inverse-arrow (Iso.is-iso e)
    g = Iso.hom d
    g' = IsIso.inverse-arrow (Iso.is-iso d)
  IsIso.left-inverse (Iso.is-iso (composeIso e d)) =
    associative f' g' (compose g f)
      ∙ cong (compose f') (sym (associative g' g f))
      ∙ cong (λ k → compose f' (compose k f)) (IsIso.left-inverse (Iso.is-iso d))
      ∙ cong (compose f') (identity-left f)
      ∙ IsIso.left-inverse (Iso.is-iso e)
    where
    f = Iso.hom e
    f' = IsIso.inverse-arrow (Iso.is-iso e)
    g = Iso.hom d
    g' = IsIso.inverse-arrow (Iso.is-iso d)

  IsTerminal : Obj → Set (o ⊔ h)
  IsTerminal T = (X : Obj) → isContr (Hom X T)

  terminal-along-iso : {X Y : Obj} → Iso C X Y → IsTerminal X → IsTerminal Y
  terminal-along-iso e terminal W = equivPresIsContr (postcompose-iso e W) (terminal W)

-- This changes the forward map only along the specified homotopy.
-- It does not replace the map by an arbitrary equivalence of its endpoints.
inverse-by-homotopy : {A B : Set ℓ} (e : Equiv A B) (f : A → B)
  → ((x : A) → forward e x ≡ f x) → InverseData f
InverseData.inverse (inverse-by-homotopy e f h) = backward e
InverseData.right-law (inverse-by-homotopy e f h) y = sym (h (backward e y)) ∙ section e y
InverseData.left-law (inverse-by-homotopy e f h) x =
  cong (backward e) (sym (h x)) ∙ retraction e x

inverse-injective : {A B : Set ℓ} {f : A → B} → InverseData f
  → {x y : A} → f x ≡ f y → x ≡ y
inverse-injective d {x} {y} p = sym (InverseData.left-law d x)
  ∙ cong (InverseData.inverse d) p ∙ InverseData.left-law d y

record Products (C : Category o h) : Set (o ⊔ h) where
  private module C = Category C
  field
    product : C.Obj → C.Obj → C.Obj
    first : {X Y : C.Obj} → C.Hom (product X Y) X
    second : {X Y : C.Obj} → C.Hom (product X Y) Y
    pair : {W X Y : C.Obj} → C.Hom W X → C.Hom W Y → C.Hom W (product X Y)
    first-pair : {W X Y : C.Obj} (f : C.Hom W X) (g : C.Hom W Y)
      → C.compose first (pair f g) ≡ f
    second-pair : {W X Y : C.Obj} (f : C.Hom W X) (g : C.Hom W Y)
      → C.compose second (pair f g) ≡ g
    pair-projections : {W X Y : C.Obj} (h : C.Hom W (product X Y))
      → pair (C.compose first h) (C.compose second h) ≡ h

module ProductTheory {o h : Level} {C : Category o h} (P : Products C) where
  open Category C
  open Products P

  product-ext : {W X Y : Obj} {f g : Hom W (product X Y)}
    → compose first f ≡ compose first g
    → compose second f ≡ compose second g → f ≡ g
  product-ext {f = f} {g = g} p q = sym (pair-projections f)
    ∙ cong (λ k → pair k (compose second f)) p
    ∙ cong (pair (compose first g)) q ∙ pair-projections g

  product-map : {X X' Y Y' : Obj} → Hom X X' → Hom Y Y'
    → Hom (product X Y) (product X' Y')
  product-map f g = pair (compose f first) (compose g second)

  first-map : {X X' Y Y' : Obj} (f : Hom X X') (g : Hom Y Y')
    → compose first (product-map f g) ≡ compose f first
  first-map f g = first-pair (compose f first) (compose g second)

  second-map : {X X' Y Y' : Obj} (f : Hom X X') (g : Hom Y Y')
    → compose second (product-map f g) ≡ compose g second
  second-map f g = second-pair (compose f first) (compose g second)

  map-compose : {X X' X'' Y Y' Y'' : Obj}
    (f : Hom X X') (f' : Hom X' X'') (g : Hom Y Y') (g' : Hom Y' Y'')
    → compose (product-map f' g') (product-map f g)
      ≡ product-map (compose f' f) (compose g' g)
  map-compose f f' g g' = product-ext
    (sym (associative first (product-map f' g') (product-map f g))
      ∙ cong (λ k → compose k (product-map f g)) (first-map f' g')
      ∙ associative f' first (product-map f g)
      ∙ cong (compose f') (first-map f g)
      ∙ sym (associative f' f first)
      ∙ sym (first-map (compose f' f) (compose g' g)))
    (sym (associative second (product-map f' g') (product-map f g))
      ∙ cong (λ k → compose k (product-map f g)) (second-map f' g')
      ∙ associative g' second (product-map f g)
      ∙ cong (compose g') (second-map f g)
      ∙ sym (associative g' g second)
      ∙ sym (second-map (compose f' f) (compose g' g)))

  map-identity : {X Y : Obj} → product-map (identity {X}) (identity {Y}) ≡ identity
  map-identity = product-ext
    (first-map identity identity ∙ identity-left first ∙ sym (identity-right first))
    (second-map identity identity ∙ identity-left second ∙ sym (identity-right second))

  product-right-iso : (X : Obj) {Y Z : Obj} → Iso C Y Z → Iso C (product X Y) (product X Z)
  Iso.hom (product-right-iso X e) = product-map identity (Iso.hom e)
  IsIso.inverse-arrow (Iso.is-iso (product-right-iso X e)) =
    product-map identity (IsIso.inverse-arrow (Iso.is-iso e))
  IsIso.right-inverse (Iso.is-iso (product-right-iso X e)) =
    map-compose identity identity (IsIso.inverse-arrow (Iso.is-iso e)) (Iso.hom e)
      ∙ cong (λ f → product-map f (compose (Iso.hom e) (IsIso.inverse-arrow (Iso.is-iso e))))
          (identity-left identity)
      ∙ cong (product-map identity) (IsIso.right-inverse (Iso.is-iso e))
      ∙ map-identity
  IsIso.left-inverse (Iso.is-iso (product-right-iso X e)) =
    map-compose identity identity (Iso.hom e) (IsIso.inverse-arrow (Iso.is-iso e))
      ∙ cong (λ f → product-map f (compose (IsIso.inverse-arrow (Iso.is-iso e)) (Iso.hom e)))
          (identity-left identity)
      ∙ cong (product-map identity) (IsIso.left-inverse (Iso.is-iso e))
      ∙ map-identity

record Adjunction {E C : Category o h} (L : Functor E C) (U : Functor C E) : Set (o ⊔ h) where
  private
    module E = Category E
    module C = Category C
    module L = Functor L
    module U = Functor U
  field
    hom-equivalence : (X : E.Obj) (Y : C.Obj)
      → Equiv (C.Hom (L.object X) Y) (E.Hom X (U.object Y))
    natural-source : {W X : E.Obj} {Y : C.Obj}
      (s : E.Hom W X) (f : C.Hom (L.object X) Y)
      → forward (hom-equivalence W Y) (C.compose f (L.arrow s))
        ≡ E.compose (forward (hom-equivalence X Y) f) s
    natural-target : {X : E.Obj} {Y Z : C.Obj}
      (t : C.Hom Y Z) (f : C.Hom (L.object X) Y)
      → forward (hom-equivalence X Z) (C.compose t f)
        ≡ E.compose (U.arrow t) (forward (hom-equivalence X Y) f)

FullyFaithful : {C E : Category o h} → Functor C E → Set (o ⊔ h)
FullyFaithful {C = C} U = (X Y : Category.Obj C)
  → InverseData (Functor.arrow U {X} {Y})

module Nullity {o h : Level} {C : Category o h} (P : Products C) (R : Category.Obj C) where
  private
    module C = Category C
    module P = Products P
    module H = Categorical C

  Null : C.Obj → Set (o ⊔ h)
  Null F = (X : C.Obj) → InverseData (H.precompose {Z = F} (P.first {X} {R}))

