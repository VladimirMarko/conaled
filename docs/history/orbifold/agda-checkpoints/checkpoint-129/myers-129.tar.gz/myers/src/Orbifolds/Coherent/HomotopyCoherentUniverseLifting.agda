{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentUniverseLifting where

-- A literal, proved embedding of arbitrary-universe coherent diagrams.
-- Object, hom, value, every chain, every cube and both face laws are
-- transported by explicit Lift maps. There is no resizing assumption.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; map-cube; coordinate-face; StrictCubicalExtensionality)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC
import Orbifolds.Coherent.UniverseCoherentArrowChains as UC
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.UniverseHomotopyCoherentDiagrams as UH
import Orbifolds.Coherent.UniverseStrictCubicalExtensionality as UE

module Lifting {ℓo ℓh ℓv : Level} (C : Category ℓo ℓh) (D : UH.ForCategory.Diagram C ℓv) where
  open Category C
  module D = UH.ForCategory.Diagram D
  module Raw = UC.Arrows C

  W : Level
  W = ℓ-max ℓo (ℓ-max ℓh ℓv)

  LiftedCategory : Category W W
  Category.Obj LiftedCategory = Lift {j = W} Obj
  Category.Hom LiftedCategory x y = Lift {j = W} (Hom (lower x) (lower y))
  Category.ident LiftedCategory x = lift (ident (lower x))
  Category.compose LiftedCategory g f = lift (compose (lower g) (lower f))
  Category.assoc LiftedCategory h g f = strict-cong
    (λ z → outer (lift {j = W} (inner z))) (assoc (lower h) (lower g) (lower f))
  Category.left LiftedCategory f = strict-cong
    (λ z → outer (lift {j = W} (inner z))) (left (lower f))
  Category.right LiftedCategory f = strict-cong
    (λ z → outer (lift {j = W} (inner z))) (right (lower f))

  module Lifted = AC.Arrows LiftedCategory

  project-chain : (n : Dim) {x y : Category.Obj LiftedCategory}
    → Lifted.Chain n x y → Raw.Chain n (lower x) (lower y)
  project-chain ozero f = lift (lower f)
  project-chain (osuc n) c = lower (c .fst) , lower (c .snd .fst) , project-chain n (c .snd .snd)

  include-chain : (n : Dim) {x y : Obj} → Raw.Chain n x y → Lifted.Chain n (lift x) (lift y)
  include-chain ozero f = lift (lower f)
  include-chain (osuc n) c = lift (c .fst) , lift (c .snd .fst) , include-chain n (c .snd .snd)

  project-include-chain : (n : Dim) {x y : Obj} (c : Raw.Chain n x y)
    → outer (project-chain n (include-chain n c)) ≡ˢ outer c
  project-include-chain ozero c = reflˢ
  project-include-chain (osuc n) c = strict-cong
    (λ z → outer (Raw.append n (Raw.last-arrow n c) (inner z)))
    (project-include-chain n (Raw.before-last n c))

  include-project-chain : (n : Dim) {x y : Category.Obj LiftedCategory} (c : Lifted.Chain n x y)
    → outer (include-chain n (project-chain n c)) ≡ˢ outer c
  include-project-chain ozero c = reflˢ
  include-project-chain (osuc n) c = strict-cong
    (λ z → outer (Lifted.append n (Lifted.last-arrow n c) (inner z)))
    (include-project-chain n (Lifted.before-last n c))

  chain-equivalence : (n : Dim) (x y : Category.Obj LiftedCategory)
    → Lifted.Chain n x y ≃ Raw.Chain n (lower x) (lower y)
  chain-equivalence n x y = isoToEquiv (iso (project-chain n) (include-chain n)
    (λ c → strict-to-path (project-include-chain n c))
    (λ c → strict-to-path (include-project-chain n c)))

  project-extend : (n : Dim) {x y z : Category.Obj LiftedCategory}
    (f : Category.Hom LiftedCategory y z) (c : Lifted.Chain n x y)
    → outer (project-chain n (Lifted.extend-suffix n f c))
      ≡ˢ outer (Raw.extend-suffix n (lower f) (project-chain n c))
  project-extend ozero f c = reflˢ
  project-extend (osuc n) f c = reflˢ

  project-face : (n : Dim) (p : Position (osuc n)) {x y : Category.Obj LiftedCategory}
    (c : Lifted.Chain (osuc n) x y)
    → outer (project-chain n (Lifted.face n p c))
      ≡ˢ outer (Raw.face n p (project-chain (osuc n) c))
  project-face n pzero c = project-extend n (Lifted.last-arrow n c) (Lifted.before-last n c)
  project-face (osuc n) (psuc p) c = strict-cong
    (λ z → outer (Raw.append n (lower (Lifted.last-arrow (osuc n) c)) (inner z)))
    (project-face n p (Lifted.before-last (osuc n) c))

  project-split : (n : Dim) (p : Position (osuc n)) {x y : Category.Obj LiftedCategory}
    → Lifted.Split n p x y → Raw.Split n p (lower x) (lower y)
  project-split n p z = lower (z .fst) , project-chain (suffix-degree n p) (z .snd .fst) ,
    project-chain (prefix-degree n p) (z .snd .snd)

  project-chain-split : (n : Dim) (p : Position (osuc n)) {x y : Category.Obj LiftedCategory}
    (c : Lifted.Chain (osuc n) x y)
    → outer (Raw.split n p (project-chain (osuc n) c))
      ≡ˢ outer (project-split n p (Lifted.split n p c))
  project-chain-split n pzero c = reflˢ
  project-chain-split (osuc n) (psuc p) c = strict-cong
    (λ z → outer (inner z .fst , Raw.append (suffix-degree n p)
      (lower (Lifted.last-arrow (osuc n) c)) (inner z .snd .fst) , inner z .snd .snd))
    (project-chain-split n p (Lifted.before-last (osuc n) c))

  objects-equivalence : Category.Obj LiftedCategory ≃ Obj
  objects-equivalence = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

  hom-equivalence : (x y : Category.Obj LiftedCategory)
    → Category.Hom LiftedCategory x y ≃ Hom (lower x) (lower y)
  hom-equivalence x y = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

  module Structure (E : StrictCubicalExtensionality W) where
    open StrictCubicalExtensionality E
    open Cubes.Extensional E
    module Small = Cubes.Extensional (UE.restrict {ℓv} {W} E)

    tensor-lift : (n : Dim) (p : Position (osuc n)) {A B Y : Type ℓv}
      (g : B → Cube (suffix-degree n p) Y) (f : A → Cube (prefix-degree n p) B) (a : A)
      → outer (map-cube n (lift {j = W}) (tensor-action n p g f a))
        ≡ˢ outer (tensor-action n p
          (λ (b : Lift {j = W} B) → map-cube (suffix-degree n p) (lift {j = W}) (g (lower b)))
          (λ (a : Lift {j = W} A) → map-cube (prefix-degree n p) (lift {j = W}) (f (lower a))) (lift a))
    tensor-lift n pzero g f a = strict-trans
      (map-compose n (lift {j = W}) g (f a))
      (strict-sym (map-compose n (λ (b : Lift {j = W} _) → lift {j = W} (g (lower b)))
        (lift {j = W}) (f a)))
    tensor-lift (osuc n) (psuc p) g f a = interval-ext λ i → tensor-lift n p (λ b → g b i) f a

    raw-split-action : (n : Dim) (p : Position (osuc n)) {x y : Obj}
      → Raw.Split n p x y → D.Value x → Cube n (D.Value y)
    raw-split-action n p z a = tensor-action n p
      (D.action (suffix-degree n p) (z .snd .fst))
      (D.action (prefix-degree n p) (z .snd .snd)) a

    LiftedDiagram : HC.ForCategory.Diagram LiftedCategory
    HC.ForCategory.Diagram.Value LiftedDiagram x = Lift {j = W} (D.Value (lower x))
    HC.ForCategory.Diagram.action LiftedDiagram n c a = map-cube n (lift {j = W})
      (D.action n (project-chain n c) (lower a))
    HC.ForCategory.Diagram.zero-face LiftedDiagram n p c a = strict-trans
      (strict-sym (map-face n p i0 (lift {j = W})
        (D.action (osuc n) (project-chain (osuc n) c) (lower a))))
      (strict-trans
        (strict-cong (λ z → outer (map-cube n (lift {j = W}) (inner z)))
          (D.zero-face n p (project-chain (osuc n) c) (lower a)))
        (strict-cong (λ z → outer (map-cube n (lift {j = W}) (D.action n (inner z) (lower a))))
          (strict-sym (project-face n p c))))
    HC.ForCategory.Diagram.one-face LiftedDiagram n p c a = strict-trans
      (strict-sym (map-face n p i1 (lift {j = W})
        (D.action (osuc n) (project-chain (osuc n) c) (lower a))))
      (strict-trans
        (strict-cong (λ z → outer (map-cube n (lift {j = W}) (inner z)))
          (D.one-face n p (project-chain (osuc n) c) (lower a)))
        (strict-trans
          (strict-cong (λ z → outer (map-cube n (lift {j = W}) (raw-split-action n p (inner z) (lower a))))
            (project-chain-split n p c))
          (tensor-lift n p
            (D.action (suffix-degree n p) (project-chain (suffix-degree n p) (Lifted.split-suffix n p c)))
            (D.action (prefix-degree n p) (project-chain (prefix-degree n p) (Lifted.split-prefix n p c))) (lower a))))
    HC.ForCategory.Diagram.unit LiftedDiagram x i a = lift (D.unit (lower x) i (lower a))

    value-equivalence : (x : Category.Obj LiftedCategory)
      → HC.ForCategory.Diagram.Value LiftedDiagram x ≃ D.Value (lower x)
    value-equivalence x = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

    project-action : (n : Dim) {x y : Category.Obj LiftedCategory}
      (c : Lifted.Chain n x y) (a : HC.ForCategory.Diagram.Value LiftedDiagram x)
      → outer (map-cube n lower (HC.ForCategory.Diagram.action LiftedDiagram n c a))
        ≡ˢ outer (D.action n (project-chain n c) (lower a))
    project-action n c a = strict-trans
      (Small.map-compose n lower (lift {j = W}) (D.action n (project-chain n c) (lower a)))
      (Small.map-identity n (D.action n (project-chain n c) (lower a)))

    include-action : (n : Dim) {x y : Obj} (c : Raw.Chain n x y) (a : D.Value x)
      → outer (HC.ForCategory.Diagram.action LiftedDiagram n (include-chain n c) (lift a))
        ≡ˢ outer (map-cube n (lift {j = W}) (D.action n c a))
    include-action n c a = strict-cong (λ z → outer (map-cube n (lift {j = W}) (D.action n (inner z) a)))
      (project-include-chain n c)
