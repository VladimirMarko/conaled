{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DeloopedKernels where

-- The actual homotopy fiber of the checked torsor-extension map deloops
-- the algebraic kernel of a surjective group homomorphism. All loop
-- comparisons refer to the actual map, and preserve multiplication.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties
  using (makeIsGroupHom; isPropIsInKer)
open import Cubical.Algebra.Group.Subgroup using (kerGroup)
open import Cubical.Functions.Surjection using (isSurjection)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Quotients as Q
import Orbifolds.Torsors as Torsors
import Orbifolds.TorsorHomomorphisms as TH
import Orbifolds.ConnectedFibers as CF

private
  variable ℓ : Level

conjugation-unit : {A : Type ℓ} {a b : A} (p : a ≡ b)
  → equivFun (conjugatePathEquiv p) refl ≡ refl
conjugation-unit p = cong (sym p ∙_) (sym (lUnit p)) ∙ lCancel p

module Along {ℓ : Level} (G H : Group ℓ) (φ : GroupHom G H)
  (surjective : isSurjection (φ .fst)) where

  module GT = Torsors.Theory G
  module HT = Torsors.Theory H
  module Hom = TH.Along G H φ
  module E = Hom.Extension
  module Fiber = CF.Map E.Extend GT.regular-torsor
  module GS = GroupStr (G .snd)
  module HS = GroupStr (H .snd)

  kernel-type = Fiber.Fiber
  base = Fiber.base

  pointed-loop-surjective : isSurjection Hom.loop-map
  pointed-loop-surjective q = PT.map
    (λ (g , p) → GT.element-loop g ,
      invEq (congEquiv Hom.h-loop-equivalence) (Hom.element-computation g ∙ p))
    (surjective (HT.transport-point HT.regular-torsor q))

  actual-loop-surjective : isSurjection (cong E.Extend :>
    ((GT.regular-torsor ≡ GT.regular-torsor) →
      (E.Extend GT.regular-torsor ≡ E.Extend GT.regular-torsor)))
  actual-loop-surjective q = PT.map
    (λ (p , w) → p , invEq (congEquiv (conjugatePathEquiv E.pointing)) w)
    (pointed-loop-surjective (equivFun (conjugatePathEquiv E.pointing) q))

  kernel-connected : (t : kernel-type) → PT.∥ base ≡ t ∥₁
  kernel-connected = Fiber.connected-fiber GT.torsor-connected actual-loop-surjective

  kernel-isGroupoid : isGroupoid kernel-type
  kernel-isGroupoid = isGroupoidΣ GT.torsor-groupoid
    (λ t → isSet→isGroupoid
      (HT.torsor-groupoid (E.Extend t) (E.Extend GT.regular-torsor)))

  kernel-delooping : Q.Delooping (ℓ-suc ℓ)
  Q.BG kernel-delooping = kernel-type
  Q.point kernel-delooping = base
  Q.connected kernel-delooping = kernel-connected

  kernel-loop-group : Group (ℓ-suc ℓ)
  kernel-loop-group = makeGroup refl _∙_ sym (kernel-isGroupoid base base)
    assoc (λ p → sym (rUnit p)) (λ p → sym (lUnit p)) rCancel lCancel

  h-coordinate-unit : HT.transport-point HT.regular-torsor refl ≡ HS.1g
  h-coordinate-unit = IsGroupHom.pres1 (HT.torsor-loop-group-equivalence .snd)

  loop-null≃kernel : (p : GT.regular-torsor ≡ GT.regular-torsor)
    → (cong E.Extend p ≡ refl)
      ≃ (φ .fst (GT.transport-point GT.regular-torsor p) ≡ HS.1g)
  loop-null≃kernel p = compEquiv
    (congEquiv (conjugatePathEquiv E.pointing))
    (compEquiv (compPathrEquiv (conjugation-unit E.pointing))
      (compEquiv (congEquiv Hom.h-loop-equivalence)
        (compEquiv (compPathrEquiv h-coordinate-unit)
          (compPathlEquiv (sym (Hom.loop-coordinate-square p))))))

  loop≃algebraic-kernel : Q.Loop kernel-delooping ≃ Ker φ
  loop≃algebraic-kernel = compEquiv Fiber.loop-fiber
    (compEquiv (Σ-cong-equiv-snd loop-null≃kernel)
      (Σ-cong-equiv-fst (GT.transport-identifications GT.regular-torsor)))

  loop-coordinate-projection : (p : Q.Loop kernel-delooping)
    → loop≃algebraic-kernel .fst p .fst
      ≡ GT.transport-point GT.regular-torsor (cong fst p)
  loop-coordinate-projection p = refl

  loop-group≃algebraic-kernel : GroupEquiv kernel-loop-group (kerGroup φ)
  loop-group≃algebraic-kernel = loop≃algebraic-kernel , makeIsGroupHom
    (λ p q → Σ≡Prop (isPropIsInKer φ)
      (cong (GT.transport-point GT.regular-torsor) (cong-∙ fst p q)
      ∙ GT.loop-evaluation-multiply (cong fst p) (cong fst q)))
