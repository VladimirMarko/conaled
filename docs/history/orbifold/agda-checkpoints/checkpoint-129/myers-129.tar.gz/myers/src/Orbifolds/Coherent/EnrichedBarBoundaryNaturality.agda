{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarBoundaryNaturality where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Transformation)
import Orbifolds.Coherent.EnrichedBarConeData as Data
import Orbifolds.Coherent.EnrichedBarConeCompatibility as Compatibility
import Orbifolds.Coherent.EnrichedBarConeTransformations as Transformations
import Orbifolds.Coherent.EnrichedBarConeStages as Stages
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells

module Naturality {ℓ : Level} {C : Category ℓ ℓ} (D D' : Diagram C ℓ)
    (η : Transformation D D') (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Chains C
  open Transformation η
  module Source = Data.Data C D
  module Target = Data.Data C D'
  module Map = Transformations.Action D D' η E
  module Shell = Shells.Action E

  module Stage (n : Dim) (P : Type ℓ) (F : Source.Families n P)
      (coherent : Source.Coherent n F) where
    module SourceStep = Stages.Construction.Step C D E n P F coherent
    module TargetStep = Stages.Construction.Step C D' E n P
      (Map.map-families n F) (Map.map-coherent n F coherent)

    boundary-natural : (s : P) (y : Obj) (c : Chain (osuc n) y)
      → outer (Shell.map-shell (osuc n) (component y) (SourceStep.boundary-data s (y , c)))
        ≡ˢ outer (TargetStep.boundary-data s (y , c))
    boundary-natural s y c = Shell.assemble-natural-facewise (osuc n) (component y)
      (Source.bar-faces n F s c)
      (Compatibility.Compatibility.bar-compatible C D E n F coherent s c)
      (Target.bar-faces n (Map.map-families n F) s c)
      (Compatibility.Compatibility.bar-compatible C D' E n
        (Map.map-families n F) (Map.map-coherent n F coherent) s c)
      (Map.bar-faces-map n F s c)
