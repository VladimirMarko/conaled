{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrispConnectedNullity where

-- Universe-explicit form of the connected crisp separated-type argument.
-- In particular, the generator may be small while the connected type
-- is a universe-level classifier. R-flat and the identity rule are
-- required at the target universe and are never inferred from lower data.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv; toIsEquiv)
open import Cubical.Data.Unit using (Unit; tt)
open import Cubical.Data.Sigma
open import Cubical.Functions.Embedding using (isEmbedding)
open import Cubical.Functions.Surjection
  using (isSurjection; isEmbedding×isSurjection→isEquiv)
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI

module Context {@♭ ℓr ℓx : Level} (@♭ R : Type ℓr)
    (@♭ rules : CrispIdentityInduction {ℓx}) where
  module Identity = CI.Theory rules

  Generator : Unit → Type ℓr
  Generator _ = R

  RealFlatAt : Type (ℓ-max ℓr (ℓ-suc ℓx))
  RealFlatAt = (@♭ X : Type ℓx) →
    CrisplyDiscrete X ≃ isEquiv (const :> (X → (R → X)))

  module Pointed (@♭ X : Type ℓx) (@♭ x₀ : X) where
    Connected : Type ℓx
    Connected = (x : X) → PT.∥ x₀ ≡ x ∥₁

    Separated : Type (ℓ-max ℓr ℓx)
    Separated = (x y : X) → NB.isNull Generator (x ≡ y)

    counit-surjective : Connected → isSurjection (counit {A = X})
    counit-surjective connected x = PT.map (λ p → box x₀ , p) (connected x)

    counit-embedding : RealFlatAt → Separated → isEmbedding (counit {A = X})
    counit-embedding real-flat separated (box x) (box y) =
      isEquiv[f∘equivFunA≃B]→isEquiv[f] (cong counit)
        (Identity.flat-identity-equivalence x y)
        (subst isEquiv (sym (funExt (Identity.counit-decode x y)))
          (invEq (real-flat (x ≡ y)) (toIsEquiv const (separated x y tt))))

    separated-connected→discrete : RealFlatAt → Connected → Separated → CrisplyDiscrete X
    separated-connected→discrete real-flat connected separated =
      isEmbedding×isSurjection→isEquiv
        (counit-embedding real-flat separated , counit-surjective connected)

    separated-connected→null : RealFlatAt → Connected → Separated → NB.isNull Generator X
    separated-connected→null real-flat connected separated _ = fromIsEquiv const
      (equivFun (real-flat X) (separated-connected→discrete real-flat connected separated))
