{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrispConnectedModal where

-- A crisp pointed connected type with R-null identity spaces is R-null.
-- Connectedness makes its Flat counit surjective. R-flat on crisp path
-- types and the derived Flat identity comparison make that counit an
-- embedding. No separated-reflection or delooping conclusion is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv; toIsEquiv)
open import Cubical.Data.Unit using (tt)
open import Cubical.Functions.Embedding
  using (isEmbedding)
open import Cubical.Functions.Surjection
  using (isSurjection; isEmbedding×isSurjection→isEquiv)
open import Cubical.Algebra.CommRing.Base using (CommRing; CommRingStr)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispPropositions as CP
import Orbifolds.Crystalline as CR

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  module Propositions = CP.Context R r₀
  module Identity = CI.Theory rules
  open Propositions using (RealFlat) public

  Null : Type ℓ → Type ℓ
  Null X = isEquiv (const :> (X → (R → X)))

  module Pointed {@♭ X : Type ℓ} (@♭ x₀ : X) where
    Connected : Type ℓ
    Connected = (x : X) → PT.∥ x₀ ≡ x ∥₁

    Separated : Type ℓ
    Separated = (x y : X) → Null (x ≡ y)

    counit-surjective : Connected → isSurjection (counit {A = X})
    counit-surjective connected x = PT.map (λ p → box x₀ , p) (connected x)

    counit-embedding : RealFlat → Separated → isEmbedding (counit {A = X})
    counit-embedding real-flat separated (box x) (box y) =
      isEquiv[f∘equivFunA≃B]→isEquiv[f] (cong counit)
        (Identity.flat-identity-equivalence x y)
        (subst isEquiv (sym (funExt (Identity.counit-decode x y)))
          (invEq (real-flat (x ≡ y)) (separated x y)))

    separated-connected→discrete : RealFlat → Connected → Separated → CrisplyDiscrete X
    separated-connected→discrete real-flat connected separated =
      isEmbedding×isSurjection→isEquiv
        (counit-embedding real-flat separated , counit-surjective connected)

    separated-connected→null : RealFlat → Connected → Separated → Null X
    separated-connected→null real-flat connected separated =
      equivFun (real-flat X) (separated-connected→discrete real-flat connected separated)

module Ring {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CommRingStr (R .snd) using (0r)
  module Generic = Context (R .fst) 0r rules
  module Infinitesimal = CR.Ring R

  shape-separated-connected→shape-modal : Generic.RealFlat
    → {@♭ X : Type ℓ} (@♭ x₀ : X)
    → ((x : X) → PT.∥ x₀ ≡ x ∥₁)
    → ((x y : X) → Infinitesimal.IsShapeModal (x ≡ y))
    → Infinitesimal.IsShapeModal X
  shape-separated-connected→shape-modal real-flat x₀ connected separated _ =
    fromIsEquiv const (Generic.Pointed.separated-connected→null x₀ real-flat connected
      (λ x y → toIsEquiv const (separated x y tt)))
