{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPacketFirstProjection where

-- Propagate the actual packet projection before canonical substitution.
-- The continuation keeps the exact original right association of the
-- higher path calculation; it introduces no new preservation premise.
open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Foundations.GroupoidLaws using (rUnit)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as Pasting
open import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle using (typeOf)

map-congruence : ∀ {ℓa ℓb} {A : Type ℓa} {B : Type ℓb}
  (k : A → B) {x y : A} {p q : x ≡ y}
  → p ≡ q → cong k p ≡ cong k q
map-congruence k law = cong (λ p → cong k p) law

-- Check the ordinary right-unit proof before any concrete endpoint is
-- substituted. Strict elimination supplies the endpoint retag exactly.
strict-right-unit : ∀ {ℓ} {B : Type ℓ} {x y z : B}
  (p : x ≡ y) (e : outer y ≡ˢ outer z)
  → p ∙ strict-to-path e ≡ strict-end-path (λ i → p i) reflˢ e
strict-right-unit p reflˢ = sym (rUnit p)

module RightReplacement {ℓ} {B : Type ℓ} {x y z : B}
    {p : x ≡ y} {q q′ : y ≡ z} {r : x ≡ z}
    (law : r ≡ p ∙ q) (change : q ≡ q′) where
  before-path : x ≡ y
  before-path = p

  projected-first : x ≡ z
  projected-first = r

  Tail : (s : x ≡ z) → Type ℓ
  Tail s = p ∙ q′ ≡ s

  after-path : y ≡ z
  after-path = q′

  abstract
    finish : {s : x ≡ z} → p ∙ q′ ≡ s → r ≡ s
    finish tail = law ∙ (cong₂ _∙_ refl change ∙ tail)

    construction : {s : x ≡ z} (tail : p ∙ q′ ≡ s)
      → outer (finish tail)
        ≡ˢ outer (law ∙ (cong₂ _∙_ refl change ∙ tail))
    construction tail = reflˢ

  finish-explicit : (s : x ≡ z) → p ∙ q′ ≡ s → r ≡ s
  finish-explicit s tail = finish {s = s} tail

  abstract
    finish-normalized : (q″ : y ≡ z) (s : x ≡ z)
      → q′ ≡ q″ → p ∙ q″ ≡ s → r ≡ s
    finish-normalized q″ s change′ tail =
      finish {s = s} (cong (p ∙_) change′ ∙ tail)

    normalized-path-construction : (q″ : y ≡ z) (s : x ≡ z)
      (change′ : q′ ≡ q″) (tail : p ∙ q″ ≡ s)
      → outer (finish-normalized q″ s change′ tail)
        ≡ˢ outer (law ∙ (cong₂ _∙_ refl change ∙ (cong (p ∙_) change′ ∙ tail)))
    normalized-path-construction q″ s change′ tail = reflˢ

  Endpoint : SSet ℓ
  Endpoint = outer {A = B} y ≡ˢ outer {A = B} z

  normal-right : (e : Endpoint) → y ≡ z
  normal-right e = strict-to-path e

  returned-path : (e : Endpoint) → x ≡ z
  returned-path e = strict-end-path (λ i → p i) reflˢ e

  UnitChange : Endpoint → Type ℓ
  UnitChange e = q′ ≡ normal-right e

  UnitResult : Endpoint → Type ℓ
  UnitResult e = r ≡ returned-path e

  abstract
    finish-unit : (e : Endpoint) → UnitChange e → UnitResult e
    finish-unit e change′ = finish-normalized (normal-right e) (returned-path e)
      change′ (strict-right-unit p e)

    unit-path-construction : (e : Endpoint) (change′ : UnitChange e)
      → outer {A = UnitResult e} (finish-unit e change′)
        ≡ˢ outer {A = UnitResult e}
          (law ∙ (cong₂ _∙_ refl change ∙
            (cong (p ∙_) change′ ∙ strict-right-unit p e)))
    unit-path-construction e change′ = normalized-path-construction
      (normal-right e) (returned-path e) change′ (strict-right-unit p e)

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module PacketData = Pasting.Construction C D G α E F n source target f triangle
    using (module Packet; module ForInput)
  module CD = Cocones.Functoriality C D E F using (Cocone; postcompose)

  Previous : Type ℓ
  Previous = Triangles.space C D E F n source

  previous : CD.Cocone Previous n
  previous = Triangles.universal C D E F n source

  module ForInput (inputs : PacketData.Packet.Inputs) where
    module Data = PacketData.Packet.Inputs inputs
      using (Y; p; base-path; p-first)
    module Paths = PacketData.ForInput inputs using (first; first-prefix)

    postcompose-base : (Previous → Data.Y) → CD.Cocone Data.Y n
    postcompose-base h = CD.postcompose n {Y = Previous} {Z = Data.Y} h previous

    lifted-prefix : _
    lifted-prefix = map-congruence postcompose-base Data.p-first

    module Normalized = RightReplacement Paths.first-prefix lifted-prefix
      using (before-path; projected-first; Tail; after-path; finish; finish-explicit; construction;
        finish-normalized; normalized-path-construction; Endpoint; normal-right; returned-path;
        UnitChange; UnitResult; finish-unit; unit-path-construction)
    before-path : _
    before-path = Normalized.before-path

    ResultPath : Type ℓ
    ResultPath = typeOf Normalized.projected-first

    projected-first : ResultPath
    projected-first = Normalized.projected-first
    open Normalized public using () renaming (construction to path-construction)

    Tail : _
    Tail = Normalized.Tail

    AfterPath : Type ℓ
    AfterPath = typeOf Normalized.after-path

    after-path : AfterPath
    after-path = Normalized.after-path

    -- Capture the HCD context and neutral packet in an ordinary definition.
    -- Reflection of this sealed function need not expose the generic
    -- continuation's individual cocone points as application arguments.
    finish-implementation : _
    finish-implementation = Normalized.finish-explicit

    abstract
      finish : typeOf finish-implementation
      finish = finish-implementation

      construction : outer finish ≡ˢ outer finish-implementation
      construction = reflˢ

    open Normalized public using (normalized-path-construction)

    -- These type families use this ForInput's own named paths.  Their
    -- generic retag is checked before the canonical packet is substituted.
    Change : (q″ : AfterPath) → Type ℓ
    Change q″ = after-path ≡ q″

    TailAt : (q″ : AfterPath) (s : ResultPath) → Type ℓ
    TailAt q″ s = before-path ∙ q″ ≡ s

    Result : (s : ResultPath) → Type ℓ
    Result s = projected-first ≡ s

    NormalizedFinish : Type ℓ
    NormalizedFinish = (q″ : AfterPath) (s : ResultPath)
      → Change q″ → TailAt q″ s → Result s

    normalized-implementation : NormalizedFinish
    normalized-implementation q″ s change′ tail =
      Normalized.finish-normalized q″ s change′ tail

    abstract
      finish-normalized : NormalizedFinish
      finish-normalized = normalized-implementation

      normalized-construction : outer finish-normalized ≡ˢ outer normalized-implementation
      normalized-construction = reflˢ

    -- The strict equality is constructed at canonical specialization. Keep
    -- the outer proof binder out of Type-valued whole-function aliases.
    Endpoint : SSet ℓ
    Endpoint = Normalized.Endpoint

    normal-right : (e : Endpoint) → AfterPath
    normal-right e = Normalized.normal-right e

    returned-path : (e : Endpoint) → ResultPath
    returned-path e = Normalized.returned-path e

    UnitChange : Endpoint → Type ℓ
    UnitChange e = Change (normal-right e)

    UnitResult : Endpoint → Type ℓ
    UnitResult e = Result (returned-path e)

    UnitFinish : Endpoint → Type ℓ
    UnitFinish e = UnitChange e → UnitResult e

    unit-implementation : (e : Endpoint) → UnitFinish e
    unit-implementation e change′ = Normalized.finish-unit e change′

    abstract
      finish-unit : (e : Endpoint) → UnitFinish e
      finish-unit e = unit-implementation e

      unit-construction : (e : Endpoint)
        → outer {A = UnitFinish e} (finish-unit e)
          ≡ˢ outer {A = UnitFinish e} (unit-implementation e)
      unit-construction e = reflˢ

    open Normalized public using (unit-path-construction)
