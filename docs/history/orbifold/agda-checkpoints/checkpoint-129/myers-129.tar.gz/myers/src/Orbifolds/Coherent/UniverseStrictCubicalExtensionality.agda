{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.UniverseStrictCubicalExtensionality where

-- Extensionality at a working universe implies the same finite structural
-- rule at every smaller universe, by literal Lift and projection.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)

restrict : ∀ {ℓ j} → StrictCubicalExtensionality (ℓ-max ℓ j) → StrictCubicalExtensionality ℓ
StrictCubicalExtensionality.interval-ext (restrict {ℓ} {j} E) {A} {f} {g} p = strict-cong
  (λ h → outer {A = (i : I) → A i} (λ i → lower (inner h i)))
  (StrictCubicalExtensionality.interval-ext E
    {A = λ i → Lift {j = j} (A i)} {f = λ i → lift (f i)} {g = λ i → lift (g i)}
    (λ i → strict-cong (λ x → outer (lift {j = j} (inner x))) (p i)))
StrictCubicalExtensionality.path-ext (restrict {ℓ} {j} E) {A} {a} {b} {p} {q} e = strict-cong
  (λ h → outer {A = PathP A a b} (λ i → lower (inner h i)))
  (StrictCubicalExtensionality.path-ext E
    {A = λ i → Lift {j = j} (A i)} {a = lift a} {b = lift b}
    {p = λ i → lift (p i)} {q = λ i → lift (q i)}
    (λ i → strict-cong (λ x → outer (lift {j = j} (inner x))) (e i)))
