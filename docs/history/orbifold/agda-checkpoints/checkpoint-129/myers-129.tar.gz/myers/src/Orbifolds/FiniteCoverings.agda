{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.FiniteCoverings where

-- A map with fibers merely equivalent to one fixed finite ordinal is
-- an actual shape₁ covering. Its actual finite-type classifier is
-- extended along the actual shape₁ unit; no covering conclusion is
-- included as a hypothesis. Universe-level R-flat is explicit.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv; toIsEquiv)
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (Unit*; tt; tt*)
open import Cubical.Data.Bool using (false; true)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.SumFin using (Fin; isSetFin)
open import Cubical.Data.FinSet using (isFinSet; isFinSet→isSet)
open import Cubical.Algebra.CommRing.Base using (CommRing)
import Cubical.Functions.Fibration as Fib
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
import Orbifolds.CrispFiniteModal as FiniteModal
import Orbifolds.CrispConnectedNullity as Connected
import Orbifolds.ConfigurationBundles as Config
import Orbifolds.SphereNullification as Sphere
import Orbifolds.ShapeOne as S1
import Orbifolds.Crystalline as CR

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ})
    (@♭ upper-rules : CrispIdentityInduction {ℓ-suc ℓ}) where
  open S1.Ring R
  open CR.Ring R using (IsShapeModal)
  module Small = FiniteModal.Ring R rules
  module Large = Connected.Context {ℓr = ℓ} {ℓx = ℓ-suc ℓ} (R .fst) upper-rules
  module LargeSphere = Sphere.At {ℓ = ℓ-suc ℓ} 2

  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = Small.Generic.RealFlat

  UpperRealFlat : Type (ℓ-suc (ℓ-suc ℓ))
  UpperRealFlat = Large.RealFlatAt

  sphere-universe-change : Sphere.Sphere ≃ LargeSphere.Sphere
  sphere-universe-change = compEquiv (invEquiv LiftEquiv) LiftEquiv

  module Ordinal (@♭ n : ℕ) where
    K : Type ℓ
    K = Lift {j = ℓ} (Fin n)

    module Labels = Config.Labels K (Unit* {ℓ = ℓ})
    module CrispExemplar = Large.Pointed Labels.Exemplar Labels.canonical

    exemplar-finite : (e : Labels.Exemplar) → isFinSet (e .fst)
    exemplar-finite (E , p) = n , PT.map
      (λ e → compEquiv e (invEquiv LiftEquiv)) p

    exemplar-isSet : (e : Labels.Exemplar) → isSet (e .fst)
    exemplar-isSet e = isFinSet→isSet (exemplar-finite e)

    exemplar-paths : (e f : Labels.Exemplar) → (e ≡ f) ≃ (e .fst ≃ f .fst)
    exemplar-paths e f = compEquiv
      (invEquiv (Σ≡PropEquiv (λ _ → PT.squash₁))) univalence

    exemplar-isGroupoid : isGroupoid Labels.Exemplar
    exemplar-isGroupoid e f = isOfHLevelRespectEquiv 2 (invEquiv (exemplar-paths e f))
      (isOfHLevel≃ 2 (exemplar-isSet e) (exemplar-isSet f))

    exemplar-separated : RealFlat → CrispExemplar.Separated
    exemplar-separated real-flat e f = NP.equivPreservesIsNull
      (invEquiv (exemplar-paths e f))
      (NP.isNullEquiv
        (Small.finite-shape-modal real-flat (exemplar-finite e))
        (Small.finite-shape-modal real-flat (exemplar-finite f)))

    exemplar-null : RealFlat → UpperRealFlat → NB.isNull Generator Labels.Exemplar
    exemplar-null real-flat upper-real-flat false =
      CrispExemplar.separated-connected→null upper-real-flat
        Labels.exemplar-connected (exemplar-separated real-flat) tt
    exemplar-null real-flat upper-real-flat true = fromIsEquiv const
      (compEquiv
        (const , toIsEquiv const (LargeSphere.truncated-null exemplar-isGroupoid tt*))
        (preCompEquiv sphere-universe-change) .snd)

    module Family {A : Type ℓ} (P : A → Type ℓ)
        (finite : (a : A) → PT.∥ P a ≃ Fin n ∥₁)
        (real-flat : RealFlat) (upper-real-flat : UpperRealFlat) where
      classifier : A → Labels.Exemplar
      classifier a = P a , PT.map (λ e → compEquiv e LiftEquiv) (finite a)

      extended : shape₁ A → Labels.Exemplar
      extended = NP.rec (exemplar-null real-flat upper-real-flat) classifier

      Descended : shape₁ A → Type ℓ
      Descended z = extended z .fst

      descended-modal : (z : shape₁ A) → IsShapeOneModal (Descended z)
      descended-modal z = discrete-set-modal
        (Small.finite-shape-modal real-flat (exemplar-finite (extended z)))
        (exemplar-isSet (extended z))

      family-unit : (a : A) → Descended (η₁ a) ≡ P a
      family-unit _ = refl

      projection-etale : Fundamental.Etale (fst {B = P})
      projection-etale = Fundamental.ReflectedFamily.projection-etale
        A Descended descended-modal

    map-etale : RealFlat → UpperRealFlat → {A Y : Type ℓ}
      (π : Y → A) → ((a : A) → PT.∥ fiber π a ≃ Fin n ∥₁)
      → Fundamental.Etale π
    map-etale real-flat upper-real-flat π finite = Fundamental.etale-precompose-equivalence
      (Fib.totalEquiv π) fst
      (Family.projection-etale (fiber π) finite real-flat upper-real-flat)

  finite-fibers-etale : RealFlat → UpperRealFlat → (n : ℕ)
    → {A Y : Type ℓ} (π : Y → A)
    → ((a : A) → PT.∥ fiber π a ≃ Fin n ∥₁) → Fundamental.Etale π
  finite-fibers-etale real-flat upper-real-flat = natural-crisp-elim
    (λ n → {A Y : Type ℓ} (π : Y → A)
      → ((a : A) → PT.∥ fiber π a ≃ Fin n ∥₁) → Fundamental.Etale π)
    (λ n → Ordinal.map-etale n real-flat upper-real-flat)

  finite-fibers-sets : (n : ℕ) → {A Y : Type ℓ} (π : Y → A)
    → ((a : A) → PT.∥ fiber π a ≃ Fin n ∥₁) → (a : A) → isSet (fiber π a)
  finite-fibers-sets n π finite a = isFinSet→isSet (n , finite a)
