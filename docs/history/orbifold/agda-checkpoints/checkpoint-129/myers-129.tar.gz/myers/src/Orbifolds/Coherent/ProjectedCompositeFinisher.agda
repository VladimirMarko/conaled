{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.ProjectedCompositeFinisher where

-- Compute the projection law for two composed paths. Strict endpoint data
-- are neutral parameters; Finish is an inner function type. The construction
-- certificate records the complete checked path calculation.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.GroupoidLaws
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictPathCoherence

module Finisher {ℓ : Level} (A B : Type ℓ) (project : A → B)
    {x y z : A} (p : x ≡ y) (q : y ≡ z)
    (w v : B) (lower : w ≡ v)
    (a : outer {A = B} (project x) ≡ˢ outer {A = B} (project y))
    (b : outer {A = B} (project y) ≡ˢ outer {A = B} w)
    (d : outer {A = B} v ≡ˢ outer {A = B} (project z))
    (e : outer {A = B} (project x) ≡ˢ outer {A = B} w) where

  AfterPath : Type ℓ
  AfterPath = w ≡ project z

  after : AfterPath
  after = lower ∙ strict-to-path d

  ResultPath : Type ℓ
  ResultPath = project x ≡ project z

  returned : ResultPath
  returned = strict-to-path e ∙ after

  EvaluationLaw : Type ℓ
  EvaluationLaw = cong project p ≡ strict-to-path a

  FiniteLaw : Type ℓ
  FiniteLaw = cong project q ≡ strict-to-path b ∙ after

  Goal : Type ℓ
  Goal = cong project (p ∙ q) ≡ returned

  Finish : Type ℓ
  Finish = EvaluationLaw → FiniteLaw → Goal

  implementation : Finish
  implementation evaluation-law finite-law =
    cong-∙ project p q
    ∙ cong₂ _∙_ evaluation-law finite-law
    ∙ assoc (strict-to-path a) (strict-to-path b) after
    ∙ cong (λ r → r ∙ lower ∙ strict-to-path d)
        (strict-path-composite a b
         ∙ strict-path-proof-independent (strict-trans a b) e)

  abstract
    finish : Finish
    finish = implementation

    finish-construction : outer {A = Finish} finish
      ≡ˢ outer {A = Finish} implementation
    finish-construction = reflˢ
