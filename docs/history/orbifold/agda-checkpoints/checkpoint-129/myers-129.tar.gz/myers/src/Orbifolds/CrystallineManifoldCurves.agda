{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrystallineManifoldCurves where

-- A chart-by-chart repair of the analytic part of Lemma 6.3.4.
-- A crystalline subspace of an ordinary manifold has locally constant
-- real curves. The compact interval argument then gives neighboring
-- values globally. Actual equality follows when the subspace's equality
-- is double-negation stable; that condition is kept explicit here.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Functions.Embedding
open import Cubical.Algebra.CommRing.Base
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Penon using (Neighbors; PenonOpen; inverseImagePenonOpen)
open import Orbifolds.Topology
  using (Topology; Predicate; regularOpen→PenonOpen)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty; BallStructure)
open import Orbifolds.FiniteConnectedGluing using (ConstantOn)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallineEuclidean as CE
import Orbifolds.OrdinaryCharts as OC
import Orbifolds.CountableRealProbe as RP
import Orbifolds.CompactIntervals as IC
import Orbifolds.IntervalParameterization as IP
import Orbifolds.LocallyConstantCurves as LC
import Orbifolds.RealConnectedness as RC

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
    (constancy : CE.Ring.PrincipleOfConstancy R) where
  open CommRingStr (R .snd) using (0r)
  open CR.Ring R
  module Euclidean = CE.Ring R
  module Curves = LC.Curves R kock order compatibility
  module Connected = RC.Connected R kock constancy
  module Probe = RP.RealProbe R kock order compatibility
  module Intervals = IC.Interpolation R kock order compatibility
  module Param = IP.Parameterization R kock order compatibility

  module Manifold (n : ℕ) {M : Type ℓ}
      (euclidean-topology : Topology (FD.Fin n → Carrier))
      (manifold : OC.Geometry.OrdinaryManifold R n M euclidean-topology) where
    module Charts = OC.Geometry R n
    open Charts.OrdinaryManifold manifold
      using (topology; regular-Hausdorff; charts)

    module Subspace {C : Type ℓ} (embedding : C ↪ M) (modalC : IsCrystalline C) where
      setC : isSet C
      setC = Embedding-into-isSet→isSet embedding (Topology.pointsAreSet topology)

      module InChart (m : M) (chart : Charts.Chart topology euclidean-topology m) where
        open Charts.Chart chart

        Piece : Type ℓ
        Piece = Σ[ c ∈ C ] range (embedding .fst c) .fst

        setPiece : isSet Piece
        setPiece = isSetΣ setC (λ c → isProp→isSet (range (embedding .fst c) .snd))

        piece-crystalline : IsCrystalline Piece
        piece-crystalline = Euclidean.crystalline-subtype modalC (range ∘ embedding .fst)

        in-range : Piece → (Σ[ z ∈ M ] range z .fst)
        in-range (c , member) = embedding .fst c , member

        coordinates : Piece → Charts.Euclidean
        coordinates z = invEq chart-equivalence (in-range z) .fst

        coordinates-injective : (z w : Piece) → coordinates z ≡ coordinates w → z ≡ w
        coordinates-injective z w equal = Σ≡Prop
          (λ c → range (embedding .fst c) .snd)
          (isEmbedding→Inj (embedding .snd) (z .fst) (w .fst)
            (cong fst (sym (secEq chart-equivalence (in-range z))
              ∙ cong (equivFun chart-equivalence)
                (Σ≡Prop (λ u → domain u .snd) equal)
              ∙ secEq chart-equivalence (in-range w))))

        -- This is the finite-dimensional instance of 6.3.1, written
        -- coordinatewise so the Fin index remains in its small universe.
        coordinate-constant : (γ : Carrier → Piece) (i : FD.Fin n)
          → (t : Carrier) → coordinates (γ t) i ≡ coordinates (γ 0r) i
        coordinate-constant γ i = constancy (λ t → coordinates (γ t) i)
          (λ t ε → cong (λ z → coordinates z i)
            (Euclidean.crystalline-curve-infinitesimal kock piece-crystalline γ t ε))

        piece-curves-constant : (γ : Carrier → Piece) (s t : Carrier) → γ s ≡ γ t
        piece-curves-constant γ s t = coordinates-injective (γ s) (γ t)
          (funExt λ i → coordinate-constant γ i s ∙ sym (coordinate-constant γ i t))

        locally-constant-at : CoveringProperty Probe.intervalBalls
          → Param.PositiveLineEquivalence → (γ : Carrier → C)
          → (t : Carrier) → range (embedding .fst (γ t)) .fst
          → PT.∥ Σ[ ε ∈ Probe.PositiveRadius ]
            ConstantOn γ
              (BallStructure.ball Probe.intervalBalls t ε) ∥₁
        locally-constant-at covering exponential γ t member =
          Curves.factorThroughConstantTypeLocallyConstantAt covering exponential
            setPiece piece-curves-constant γ
            (λ s → range (embedding .fst (γ s)))
            (inverseImagePenonOpen (embedding .fst ∘ γ) range
              (regularOpen→PenonOpen topology (regular-Hausdorff .fst) range range-open))
            (λ u → γ (u .fst) , u .snd) fst (λ _ → refl) t member

      crystalline-curves-locally-constant : CoveringProperty Probe.intervalBalls
        → Param.PositiveLineEquivalence → (γ : Carrier → C) → Curves.LocallyConstant γ
      crystalline-curves-locally-constant covering exponential γ t = PT.rec PT.squash₁
        (λ chart → InChart.locally-constant-at (embedding .fst (γ t)) chart
          covering exponential γ t (Charts.Chart.center-member chart))
        (charts (embedding .fst (γ t)))

      crystalline-curves-neighbor : CoveringProperty Probe.intervalBalls
        → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
        → (γ : Carrier → C) → (s t : Carrier) → Neighbors (γ s) (γ t)
      crystalline-curves-neighbor covering compact-interval exponential γ =
        Curves.Curve.neighborsEverywhere setC γ
          (crystalline-curves-locally-constant covering exponential γ) covering
          compact-interval exponential Connected.realNoBooleanVariation

      crystalline-separated-curves-constant : CoveringProperty Probe.intervalBalls
        → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
        → ((x y : C) → Neighbors x y → x ≡ y)
        → (γ : Carrier → C) → (s t : Carrier) → γ s ≡ γ t
      crystalline-separated-curves-constant covering compact-interval exponential separated γ s t =
        separated (γ s) (γ t)
          (crystalline-curves-neighbor covering compact-interval exponential γ s t)

      crystalline-separated-shape-modal : CoveringProperty Probe.intervalBalls
        → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
        → ((x y : C) → Neighbors x y → x ≡ y) → IsShapeModal C
      crystalline-separated-shape-modal covering compact-interval exponential separated _ =
        fromIsEquiv const (isoToIsEquiv
          (iso const (λ γ → γ 0r)
            (λ γ → funExt λ t → crystalline-separated-curves-constant
              covering compact-interval exponential separated γ 0r t)
            (λ _ → refl)))
