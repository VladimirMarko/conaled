{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictPathEndpointSquares where

-- Pointwise strict agreement supplies a complete square, with its two
-- endpoint paths fixed to the specified strict equalities by outer UIP.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictCubicalFillerPathTransport using (strict-end-dependent-path)

pointwise-strict-square : ∀ {ℓ} {A : Type ℓ} (p q : I → A)
  (agree : (i : I) → outer (p i) ≡ˢ outer (q i))
  (left : outer (p i0) ≡ˢ outer (q i0))
  (right : outer (p i1) ≡ˢ outer (q i1))
  → PathP (λ i → p i ≡ q i) (strict-to-path left) (strict-to-path right)
pointwise-strict-square p q agree left right = strict-end-dependent-path
  (λ i → strict-to-path (agree i))
  (strict-cong (λ e → outer (strict-to-path e)) (strict-uip (agree i0) left))
  (strict-cong (λ e → outer (strict-to-path e)) (strict-uip (agree i1) right))
