{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowers where

-- Actual pointwise powers of full homotopy-coherent diagrams. Cubical
-- coordinates are transposed with the power parameter; all face laws
-- and literal evaluation transformations are derived.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram; Power)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as HT

transpose : ∀ {ℓ} (n : Dim) {T X : Type ℓ} → (T → Cube n X) → Cube n (T → X)
transpose ozero c = c
transpose (osuc n) c i = transpose n (λ t → c t i)

untranspose : ∀ {ℓ} (n : Dim) {T X : Type ℓ} → Cube n (T → X) → T → Cube n X
untranspose ozero c t = c t
untranspose (osuc n) c t i = untranspose n (c i) t

module Coordinates {ℓ : Level} (E : StrictCubicalExtensionality ℓ)
    (F : StrictFunctionExtensionality ℓ) where
  open StrictCubicalExtensionality E
  open StrictFunctionExtensionality F

  transpose-ext : (n : Dim) {T X : Type ℓ} (c d : T → Cube n X)
    → ((t : T) → outer (c t) ≡ˢ outer (d t))
    → outer (transpose n c) ≡ˢ outer (transpose n d)
  transpose-ext ozero c d equal = function-ext equal
  transpose-ext (osuc n) c d equal = interval-ext λ i →
    transpose-ext n (λ t → c t i) (λ t → d t i)
      (λ t → strict-cong (λ q → outer (inner q i)) (equal t))

  transpose-evaluate : (n : Dim) {T X : Type ℓ} (c : T → Cube n X) (t : T)
    → outer (map-cube n (λ h → h t) (transpose n c)) ≡ˢ outer (c t)
  transpose-evaluate ozero c t = reflˢ
  transpose-evaluate (osuc n) c t = interval-ext λ i →
    transpose-evaluate n (λ t → c t i) t

  transpose-untranspose : (n : Dim) {T X : Type ℓ} (c : Cube n (T → X))
    → outer (transpose n (untranspose n c)) ≡ˢ outer c
  transpose-untranspose ozero c = reflˢ
  transpose-untranspose (osuc n) c = interval-ext λ i → transpose-untranspose n (c i)

  untranspose-transpose : (n : Dim) {T X : Type ℓ} (c : T → Cube n X) (t : T)
    → outer (untranspose n (transpose n c) t) ≡ˢ outer (c t)
  untranspose-transpose ozero c t = reflˢ
  untranspose-transpose (osuc n) c t = interval-ext λ i →
    untranspose-transpose n (λ t → c t i) t

  transpose-natural : (n : Dim) {T X Y : Type ℓ} (f : X → Y) (c : T → Cube n X)
    → outer (map-cube n (λ h t → f (h t)) (transpose n c))
      ≡ˢ outer (transpose n (λ t → map-cube n f (c t)))
  transpose-natural ozero f c = reflˢ
  transpose-natural (osuc n) f c = interval-ext λ i →
    transpose-natural n f (λ t → c t i)

  transpose-face : (n : Dim) (p : Position (osuc n)) (i : I)
    {T X : Type ℓ} (c : T → Cube (osuc n) X)
    → outer (coordinate-face n p i (transpose (osuc n) c))
      ≡ˢ outer (transpose n (λ t → coordinate-face n p i (c t)))
  transpose-face n pzero i c = reflˢ
  transpose-face (osuc n) (psuc p) i c = interval-ext λ j →
    transpose-face n p i (λ t → c t j)

  tensor-transpose : (n : Dim) (p : Position (osuc n)) {T A B Y : Type ℓ}
    (g : B → Cube (suffix-degree n p) Y)
    (f : A → Cube (prefix-degree n p) B) (a : T → A)
    → outer (tensor-action n p
        (λ b → transpose (suffix-degree n p) (λ t → g (b t)))
        (λ a → transpose (prefix-degree n p) (λ t → f (a t))) a)
      ≡ˢ outer (transpose n (λ t → tensor-action n p g f (a t)))
  tensor-transpose n pzero g f a = transpose-natural n g (λ t → f (a t))
  tensor-transpose (osuc n) (psuc p) g f a = interval-ext λ i →
    tensor-transpose n p (λ b → g b i) f a

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (T : Type ℓ) where
  module H = HC.ForCategory C
  module Maps = HT.ForCategory C
  open Coordinates E F
  open Category C

  Power : H.Diagram → H.Diagram
  H.Diagram.Value (Power D) x = T → H.Diagram.Value D x
  H.Diagram.action (Power D) n c a = transpose n (λ t → H.Diagram.action D n c (a t))
  H.Diagram.zero-face (Power D) n p c a = strict-trans
    (transpose-face n p i0 (λ t → H.Diagram.action D (osuc n) c (a t)))
    (transpose-ext n _ _ (λ t → H.Diagram.zero-face D n p c (a t)))
  H.Diagram.one-face (Power D) n p c a = strict-trans
    (transpose-face n p i1 (λ t → H.Diagram.action D (osuc n) c (a t)))
    (strict-trans
      (transpose-ext n _ _ (λ t → H.Diagram.one-face D n p c (a t)))
      (strict-sym (tensor-transpose n p
        (H.Diagram.action D (suffix-degree n p) (Chains.Arrows.split-suffix C n p c))
        (H.Diagram.action D (prefix-degree n p) (Chains.Arrows.split-prefix C n p c)) a)))
  H.Diagram.unit (Power D) x i a t = H.Diagram.unit D x i (a t)

  evaluation : (D : H.Diagram) (t : T) → Maps.Transformation (Power D) D
  Maps.Transformation.component (evaluation D t) x a = a t
  Maps.Transformation.naturality (evaluation D t) n c a =
    transpose-evaluate n (λ t → H.Diagram.action D n c (a t)) t

  map-transformation : {D G : H.Diagram} → Maps.Transformation D G
    → Maps.Transformation (Power D) (Power G)
  Maps.Transformation.component (map-transformation α) x a t = Maps.Transformation.component α x (a t)
  Maps.Transformation.naturality (map-transformation {D} {G} α) n {x} {y} c a = strict-trans
    (transpose-natural n (Maps.Transformation.component α y)
      (λ t → H.Diagram.action D n c (a t)))
    (transpose-ext n _ _ (λ t → Maps.Transformation.naturality α n c (a t)))

  precompose : (D : H.Diagram) (k : T → T) → Maps.Transformation (Power D) (Power D)
  Maps.Transformation.component (precompose D k) x a t = a (k t)
  Maps.Transformation.naturality (precompose D k) n c a = change n
    (λ t → H.Diagram.action D n c (a t))
    where
    change : (n : Dim) {X : Type ℓ} (q : T → Cube n X)
      → outer (map-cube n (λ h t → h (k t)) (transpose n q))
        ≡ˢ outer (transpose n (λ t → q (k t)))
    change ozero q = reflˢ
    change (osuc n) q = StrictCubicalExtensionality.interval-ext E λ i → change n (λ t → q t i)
