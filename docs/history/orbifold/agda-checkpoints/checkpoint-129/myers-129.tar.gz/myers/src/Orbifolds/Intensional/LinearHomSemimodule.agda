{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LinearHomSemimodule where

-- Actual pointwise operations on actual linear maps.
-- No tensor multiplication, algebra structure, or preservation theorem
-- is a parameter of this construction.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteSupportPullbacks using (function-isSet)
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor

private variable ℓ : Level

module Hom {ℓ : Level} (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
    (M N : Semimodule R) where

  private module R = CommutativeSemiring R
  private module M = Semimodule M
  private module N = Semimodule N

  pointwise-path : {h k : LinearMap M N}
    → ((v : M.Carrier) → fst h v ≡ fst k v) → h ≡ k
  pointwise-path {h = h} {k = k} same =
    linear-path ext {M = M} {N = N} {h = h} {k = k} (ext same)

  exchange : (a b c : N.Carrier) → a N.+ (b N.+ c) ≡ b N.+ (a N.+ c)
  exchange a b c = sym (N.+-assoc a b c)
    ∙ cong (λ z → z N.+ c) (N.+-comm a b) ∙ N.+-assoc b a c

  interchange : (a b c d : N.Carrier)
    → (a N.+ b) N.+ (c N.+ d) ≡ (a N.+ c) N.+ (b N.+ d)
  interchange a b c d = N.+-assoc a b (c N.+ d)
    ∙ cong (λ z → a N.+ z) (exchange b c d)
    ∙ sym (N.+-assoc a c (b N.+ d))

  scalar-exchange : (r s : R.Carrier) (v : N.Carrier)
    → r N.• (s N.• v) ≡ s N.• (r N.• v)
  scalar-exchange r s v = sym (N.•-assoc r s v)
    ∙ cong (λ t → t N.• v) (R.*-comm r s) ∙ N.•-assoc s r v

  zero-map : LinearMap M N
  zero-map = (λ _ → N.zero) ,
    ((refl , λ u v → sym (N.+-zero-left N.zero)) ,
      λ r v → sym (N.•-zero r))

  add-map : LinearMap M N → LinearMap M N → LinearMap M N
  add-map h k = (λ v → fst h v N.+ fst k v) ,
    ((cong₂ N._+_ (linear-zero {M = M} {N = N} h)
        (linear-zero {M = M} {N = N} k) ∙ N.+-zero-left N.zero ,
      λ u v → cong₂ N._+_ (linear-add {M = M} {N = N} h u v)
          (linear-add {M = M} {N = N} k u v)
        ∙ interchange (fst h u) (fst h v) (fst k u) (fst k v)) ,
      λ r v → cong₂ N._+_ (linear-scalar {M = M} {N = N} h r v)
          (linear-scalar {M = M} {N = N} k r v)
        ∙ sym (N.•-add r (fst h v) (fst k v)))

  scale-map : R.Carrier → LinearMap M N → LinearMap M N
  scale-map r h = (λ v → r N.• fst h v) ,
    ((cong (N._•_ r) (linear-zero {M = M} {N = N} h) ∙ N.•-zero r ,
      λ u v → cong (N._•_ r) (linear-add {M = M} {N = N} h u v)
        ∙ N.•-add r (fst h u) (fst h v)) ,
      λ s v → cong (N._•_ r) (linear-scalar {M = M} {N = N} h s v)
        ∙ scalar-exchange r s (fst h v))

  hom-additive : AdditiveMonoid ℓ
  AdditiveMonoid.Carrier hom-additive = LinearMap M N
  AdditiveMonoid.carrier-set hom-additive = isSetΣProp
    (function-isSet ext (λ _ → N.carrier-set)) (linear-prop ext M N)
  AdditiveMonoid.zero hom-additive = zero-map
  AdditiveMonoid._+_ hom-additive = add-map
  AdditiveMonoid.+-assoc hom-additive h k l =
    pointwise-path (λ v → N.+-assoc (fst h v) (fst k v) (fst l v))
  AdditiveMonoid.+-comm hom-additive h k =
    pointwise-path (λ v → N.+-comm (fst h v) (fst k v))
  AdditiveMonoid.+-zero-left hom-additive h =
    pointwise-path (λ v → N.+-zero-left (fst h v))
  AdditiveMonoid.+-zero-right hom-additive h =
    pointwise-path (λ v → N.+-zero-right (fst h v))

  hom-module : Semimodule R
  Semimodule.additive hom-module = hom-additive
  Semimodule._•_ hom-module = scale-map
  Semimodule.•-one hom-module h = pointwise-path (λ v → N.•-one (fst h v))
  Semimodule.•-assoc hom-module r s h =
    pointwise-path (λ v → N.•-assoc r s (fst h v))
  Semimodule.•-zero hom-module r = pointwise-path (λ v → N.•-zero r)
  Semimodule.zero-• hom-module h = pointwise-path (λ v → N.zero-• (fst h v))
  Semimodule.•-add hom-module r h k =
    pointwise-path (λ v → N.•-add r (fst h v) (fst k v))
  Semimodule.add-• hom-module r s h =
    pointwise-path (λ v → N.add-• r s (fst h v))

  evaluate : M.Carrier → LinearMap hom-module N
  evaluate v = (λ h → fst h v) , ((refl , λ h k → refl) , λ r h → refl)

module Curry {ℓ : Level} (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
    (L M N : Semimodule R) where

  module H = Hom ext M N

  curry : BilinearMap L M N → LinearMap L H.hom-module
  curry b = (λ u → bilinear-right {L = L} {M = M} {N = N} b u) ,
    ((H.pointwise-path (λ v → linear-zero {M = L} {N = N}
        (bilinear-left {L = L} {M = M} {N = N} b v)) ,
      λ u w → H.pointwise-path (λ v → linear-add {M = L} {N = N}
        (bilinear-left {L = L} {M = M} {N = N} b v) u w)) ,
      λ r u → H.pointwise-path (λ v → linear-scalar {M = L} {N = N}
        (bilinear-left {L = L} {M = M} {N = N} b v) r u))

  uncurry : LinearMap L H.hom-module → BilinearMap L M N
  uncurry h = (λ u v → fst (fst h u) v) ,
    ((λ v → snd (compose-linear {M = L} {N = H.hom-module} {P = N}
      (H.evaluate v) h)) , λ u → snd (fst h u))

  uncurry-curry : (b : BilinearMap L M N) → uncurry (curry b) ≡ b
  uncurry-curry b = bilinear-path ext {L = L} {M = M} {N = N}
    {b = uncurry (curry b)} {c = b} refl

  curry-uncurry : (h : LinearMap L H.hom-module) → curry (uncurry h) ≡ h
  curry-uncurry h = linear-path ext {M = L} {N = H.hom-module}
    {h = curry (uncurry h)} {k = h} (ext (λ u → H.pointwise-path (λ v → refl)))

  curry-equivalence : Equiv (BilinearMap L M N) (LinearMap L H.hom-module)
  curry-equivalence = equiv curry uncurry curry-uncurry uncurry-curry
