{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConnectedPullbacks where

-- Lemma 5.5.1.  The pullback comparison of a connected square is an
-- equivalence if its actual looped comparison is an equivalence and
-- the right vertical loop map is surjective.  All paths of the square
-- are retained, including the basepoint's commuting path.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Foundations.Path
open import Cubical.Foundations.Univalence using (pathToEquiv)
open import Cubical.Foundations.Transport using (transport⁻)
open import Cubical.Data.Sigma
open import Cubical.Functions.Surjection
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.MicrolinearityLimits as ML
import Orbifolds.Quotients as Q

module Span {ℓ : Level} {X Y Z : Type ℓ}
    (f : X → Z) (g : Y → Z) (base : ML.Pullback f g) where
  x₀ : X
  x₀ = base .fst .fst

  y₀ : Y
  y₀ = base .fst .snd

  p₀ : f x₀ ≡ g y₀
  p₀ = base .snd

  LoopCode : Type ℓ
  LoopCode = Σ[ pq ∈ ((x₀ ≡ x₀) × (y₀ ≡ y₀)) ]
    PathP (λ i → f (pq .fst i) ≡ g (pq .snd i)) p₀ p₀

  loops-code : (base ≡ base) ≃ LoopCode
  loops-code = isoToEquiv (iso
    (λ loop → ((λ i → loop i .fst .fst) , (λ i → loop i .fst .snd)) ,
      (λ i j → loop i .snd j))
    (λ { ((p , q) , r) i → (p i , q i) , r i })
    (λ _ → refl) (λ _ → refl))

  loop-left : (x₀ ≡ x₀) → (g y₀ ≡ g y₀)
  loop-left p = sym p₀ ∙∙ cong f p ∙∙ p₀

  loop-right : (y₀ ≡ y₀) → (g y₀ ≡ g y₀)
  loop-right q = cong g q

  module Code (p : x₀ ≡ x₀) (q : y₀ ≡ y₀) where
    rotate : PathP (λ i → f (p i) ≡ g (q i)) p₀ p₀
      ≃ PathP (λ j → p₀ j ≡ p₀ j) (cong f p) (cong g q)
    rotate = isoToEquiv (iso (λ r j i → r i j)
      (λ r i j → r j i) (λ _ → refl) (λ _ → refl))

    equivalence : PathP (λ i → f (p i) ≡ g (q i)) p₀ p₀
      ≃ (loop-left p ≡ loop-right q)
    equivalence = compEquiv rotate
      (pathToEquiv (PathP≡doubleCompPathˡ p₀ (cong f p) (cong g q) p₀))

  loop-pullback-equivalence : (base ≡ base) ≃ ML.Pullback loop-left loop-right
  loop-pullback-equivalence = compEquiv loops-code
    (Σ-cong-equiv-snd (λ { (p , q) → Code.equivalence p q }))

  module Connected
      (connectedX : (x : X) → PT.∥ x₀ ≡ x ∥₁)
      (connectedY : (y : Y) → PT.∥ y₀ ≡ y ∥₁)
      (surjective : isSurjection loop-right) where
    same-vertices : (p : f x₀ ≡ g y₀)
      → PT.∥ base ≡ ((x₀ , y₀) , p) ∥₁
    same-vertices p = PT.map lift-loop (surjective (sym p₀ ∙ p))
      where
      lift-loop : fiber loop-right (sym p₀ ∙ p)
        → base ≡ ((x₀ , y₀) , p)
      lift-loop (q , law) i = (x₀ , q i) , square i
        where
        square : PathP (λ i → f x₀ ≡ g (q i)) p₀ p
        square = transport⁻ (PathP≡compPath p₀ (cong g q) p)
          (cong (p₀ ∙_) law ∙ compPathl-cancel p₀ p)

    vary-y : (y : Y) (q : y₀ ≡ y) (p : f x₀ ≡ g y)
      → PT.∥ base ≡ ((x₀ , y) , p) ∥₁
    vary-y y q = J
      (λ y q → (p : f x₀ ≡ g y) → PT.∥ base ≡ ((x₀ , y) , p) ∥₁)
      same-vertices q

    vary-x : (x : X) (q : x₀ ≡ x) (y : Y) (r : y₀ ≡ y)
      (p : f x ≡ g y) → PT.∥ base ≡ ((x , y) , p) ∥₁
    vary-x x q = J
      (λ x q → (y : Y) (r : y₀ ≡ y) (p : f x ≡ g y)
        → PT.∥ base ≡ ((x , y) , p) ∥₁) vary-y q

    connected-pullback : (z : ML.Pullback f g) → PT.∥ base ≡ z ∥₁
    connected-pullback ((x , y) , p) = PT.rec PT.squash₁
      (λ q → PT.rec PT.squash₁ (λ r → vary-x x q y r p) (connectedY y))
      (connectedX x)

module Square {ℓ : Level} {A B C D : Type ℓ}
    (a₀ : A) (north : A → B) (west : A → C)
    (east : B → D) (south : C → D)
    (commutes : (a : A) → east (north a) ≡ south (west a)) where
  comparison : A → ML.Pullback east south
  comparison a = (north a , west a) , commutes a

  module Target = Span east south (comparison a₀)

  looped-comparison : (a₀ ≡ a₀)
    → ML.Pullback Target.loop-left Target.loop-right
  looped-comparison p = equivFun Target.loop-pullback-equivalence (cong comparison p)

  north-on-loops : (p : a₀ ≡ a₀)
    → looped-comparison p .fst .fst ≡ cong north p
  north-on-loops p = refl

  west-on-loops : (p : a₀ ≡ a₀)
    → looped-comparison p .fst .snd ≡ cong west p
  west-on-loops p = refl

  module Connected
      (connectedA : (a : A) → PT.∥ a₀ ≡ a ∥₁)
      (connectedB : (b : B) → PT.∥ north a₀ ≡ b ∥₁)
      (connectedC : (c : C) → PT.∥ west a₀ ≡ c ∥₁)
      (surjective : isSurjection Target.loop-right) where
    source-group : Q.Delooping ℓ
    Q.BG source-group = A
    Q.point source-group = a₀
    Q.connected source-group = connectedA

    target-group : Q.Delooping ℓ
    Q.BG target-group = ML.Pullback east south
    Q.point target-group = comparison a₀
    Q.connected target-group =
      Target.Connected.connected-pullback connectedB connectedC surjective

    module Maps = Q.ConnectedMaps source-group target-group comparison refl

    from-loop-equivalence : isEquiv (cong comparison :> (a₀ ≡ a₀ → comparison a₀ ≡ comparison a₀))
      → isEquiv comparison
    from-loop-equivalence loops = isEmbedding×isSurjection→isEquiv
      (Maps.loop-equivalence→embedding loops , Maps.pointed-map-surjective)

    pullback-from-loops : isEquiv looped-comparison → isEquiv comparison
    pullback-from-loops preserved = from-loop-equivalence
      (isEquiv[equivFunA≃B∘f]→isEquiv[f]
        (cong comparison) Target.loop-pullback-equivalence preserved)
