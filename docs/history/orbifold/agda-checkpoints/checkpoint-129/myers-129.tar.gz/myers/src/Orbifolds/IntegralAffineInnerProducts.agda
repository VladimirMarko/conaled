{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineInnerProducts where

-- An actual positive inner product invariant under the finite integral
-- linear part. Its squared distance is invariant under the complete
-- integral affine action. This is a derived metric witness, not an
-- assumption about a representation being orthogonal in advance.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.FinSet.Base using (isFinSet)
import Cubical.Data.SumFin as SFN
import Cubical.Data.Fin as F
import Cubical.Data.FinData as FD
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Module.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.EuclideanNorms as EN
import Orbifolds.FiniteRingSums as FS
import Orbifolds.FiniteInvariantInnerProducts as FI
import Orbifolds.ModuleInnerProducts as MI
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.GeneralLinearMatrices as GL
import Orbifolds.IntegralAffineActions as IA

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  module Linear = LM.Ring R
  module Norms = EN.Norms R kock order compatibility
  module Sums = FS.Ring R

  abstract
    sum-squares : (n : ℕ) (x : SFN.Fin n → R .fst)
      → Sums.sum n (λ i → x i · x i) ≡ Norms.squaredNorm n x
    sum-squares zero x = refl
    sum-squares (suc n) x = cong ((x SFN.fzero · x SFN.fzero) +_)
      (sum-squares n (λ i → x (SFN.fsuc i)))

  module Dimension (n : ℕ) where
    module Forms = MI.Theory R order (Linear.Free n)
    module Average = FI.Ordered.OnModule R kock order compatibility (Linear.Free n)

    indices : SFN.Fin n ≃ FD.Fin n
    indices = compEquiv (SFN.SumFin≃Fin n) (invEquiv (F.FinData≃Fin n))

    dot : Linear.Vector n → Linear.Vector n → R .fst
    dot x y = Sums.sum n (λ i → x (indices .fst i) · y (indices .fst i))

    euclidean : Forms.InnerProduct
    Forms.InnerProduct.pairing euclidean = dot
    Forms.InnerProduct.symmetric euclidean x y =
      Sums.sum-ext n (λ i → ·Comm (x (indices .fst i)) (y (indices .fst i)))
    Forms.InnerProduct.additive-left euclidean x y z =
      Sums.sum-ext n (λ i → ·DistL+ (x (indices .fst i)) (y (indices .fst i)) (z (indices .fst i)))
      ∙ Sums.sum-add n (λ i → x (indices .fst i) · z (indices .fst i))
          (λ i → y (indices .fst i) · z (indices .fst i))
    Forms.InnerProduct.homogeneous-left euclidean r x y =
      Sums.sum-ext n (λ i → sym (·Assoc r (x (indices .fst i)) (y (indices .fst i))))
      ∙ Sums.sum-scale n r (λ i → x (indices .fst i) · y (indices .fst i))
    Forms.InnerProduct.positive euclidean x nonzero =
      subst (SF.RingContext.StrictOrder._<_ order 0r)
        (sym (sum-squares n (λ i → x (indices .fst i))))
        (Norms.normPositive n (λ i → x (indices .fst i))
          (λ vanishes → nonzero (funExt λ i →
            sym (cong x (secEq indices i)) ∙ vanishes (invEq indices i))))

    difference : Linear.Vector n → Linear.Vector n → Linear.Vector n
    difference x y i = x i - y i

    squared-distance : Forms.InnerProduct → Linear.Vector n → Linear.Vector n → R .fst
    squared-distance form x y = Forms.norm form (difference x y)

    module Representation (H : Group ℓ)
        (ρ : GroupHom H (GL.Ring.Dimension.GeneralLinear ℤCommRing n)) where
      module Affine = IA.Coordinates.Representation R n H ρ
      module Real = GL.Ring.Dimension R n

      action-equivalences : H .fst → LeftModuleEquiv (Linear.Free n) (Linear.Free n)
      action-equivalences h = Real.action-equivalence (Affine.real-representation .fst h) ,
        Linear.action-linear (Affine.real-representation .fst h .fst)

      module Averaging = Average.FiniteAction H action-equivalences Affine.linear-compose

      Isometric : Forms.InnerProduct → Type ℓ
      Isometric form = (g : Affine.AffineGroup .fst) (x y : Linear.Vector n)
        → squared-distance form (Affine.affine g x) (Affine.affine g y)
          ≡ squared-distance form x y

      abstract
        translation-cancels : (a x y : R .fst) → (a + x) - (a + y) ≡ x - y
        translation-cancels a x y = solve! R

        affine-difference : (g : Affine.AffineGroup .fst) (x y : Linear.Vector n)
          → difference (Affine.affine g x) (Affine.affine g y)
            ≡ Affine.linear (g .snd) (difference x y)
        affine-difference (z , h) x y =
          funExt (λ i → translation-cancels
            (IA.Coordinates.Integer.integer R n (lower z i))
            (Affine.linear h x i) (Affine.linear h y i))
          ∙ sym (IsLeftModuleHom.pres+
              (action-equivalences h .snd) x (λ i → - y i)
            ∙ cong (λ (v : Linear.Vector n) (i : FD.Fin n) → Affine.linear h x i + v i)
              (IsLeftModuleHom.pres- (action-equivalences h .snd) y))

        invariant-to-isometric : (form : Forms.InnerProduct)
          → Averaging.Invariant form → Isometric form
        invariant-to-isometric form invariant g x y =
          cong (Forms.norm form) (affine-difference g x y)
          ∙ invariant (g .snd) (difference x y) (difference x y)

      finite-affine-isometric : isFinSet (H .fst)
        → PT.∥ Σ[ form ∈ Forms.InnerProduct ] Isometric form ∥₁
      finite-affine-isometric finite = PT.map
        (λ (form , invariant) → form , invariant-to-isometric form invariant)
        (Averaging.invariant-inner-product finite euclidean)
