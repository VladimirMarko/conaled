{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalCubicalFillerPowers where

-- Literal evaluation commutes with endpoint-typed cubical filling.
-- The forward map is exactly direct map-filler(eval_t). The inverse
-- transposes the actual forgotten cubes and derives its boundary; no
-- representability inverse or assumed preservation theorem intervenes.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; map-cube; StrictCubicalExtensionality)
open import Orbifolds.Coherent.HomotopyCoherentPowers using (transpose)
import Orbifolds.Coherent.HomotopyCoherentPowers as DiagramPowers
import Orbifolds.Coherent.StrictCubicalShellMaps as SM
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.StrictCubicalFillerMaps as FM
import Orbifolds.Coherent.StrictCubicalFillers as FB
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Powers {ℓ : Level} (E : StrictCubicalExtensionality ℓ)
    (F : StrictFunctionExtensionality ℓ) where
  open StrictCubicalExtensionality E
  open StrictFunctionExtensionality F
  module Coordinate = DiagramPowers.Coordinates E F
  module Shell = SM.Action E
  module Direct = FM.Action E
  module Boundary = FB.Boundary E

  cube-evaluation-extensionality : (n : Dim) {T X : Type ℓ} (c d : Cube n (T → X))
    → ((t : T) → outer (map-cube n (λ h → h t) c) ≡ˢ outer (map-cube n (λ h → h t) d))
    → outer c ≡ˢ outer d
  cube-evaluation-extensionality ozero c d equal = function-ext equal
  cube-evaluation-extensionality (osuc n) c d equal = interval-ext λ i →
    cube-evaluation-extensionality n (c i) (d i)
      (λ t → strict-cong (λ z → outer (inner z i)) (equal t))

  shell-evaluation-extensionality : (n : Dim) {T X : Type ℓ}
    (b b' : CS.Shell (toNat n) (T → X))
    → ((t : T) → outer (Shell.map-shell n (λ h → h t) b)
        ≡ˢ outer (Shell.map-shell n (λ h → h t) b'))
    → outer b ≡ˢ outer b'
  shell-evaluation-extensionality ozero b b' equal = reflˢ
  shell-evaluation-extensionality (osuc n) b b' equal = Boundary.shell-equality n
    (b .fst .fst) (b .fst .snd) (b' .fst .fst) (b' .fst .snd) (b .snd) (b' .snd)
    (cube-evaluation-extensionality n (b .fst .fst) (b' .fst .fst)
      (λ t → strict-cong (λ z → outer (inner z .fst .fst)) (equal t)))
    (cube-evaluation-extensionality n (b .fst .snd) (b' .fst .snd)
      (λ t → strict-cong (λ z → outer (inner z .fst .snd)) (equal t)))
    (λ i → shell-evaluation-extensionality n (b .snd i) (b' .snd i)
      (λ t → strict-trans
        (strict-sym (Shell.side-computation n (λ h → h t) b i))
        (strict-trans
          (strict-cong (λ z → outer (inner z .snd i)) (equal t))
          (Shell.side-computation n (λ h → h t) b' i))))

  module At (n : Dim) {T X : Type ℓ} (b : CS.Shell (toNat n) (T → X)) where
    evaluated-boundary : T → CS.Shell (toNat n) X
    evaluated-boundary t = Shell.map-shell n (λ h → h t) b

    Pointwise : Type ℓ
    Pointwise = (t : T) → CF.Filler (toNat n) (evaluated-boundary t)

    evaluate-filler : CF.Filler (toNat n) b → Pointwise
    evaluate-filler c t = Direct.map-filler n (λ h → h t) b c

    transposed-cube : Pointwise → Cube n (T → X)
    transposed-cube u = transpose n (λ t → CF.forget-filler (toNat n) (evaluated-boundary t) (u t))

    transposed-boundary : (u : Pointwise)
      → outer (CS.restriction (toNat n) (transposed-cube u)) ≡ˢ outer b
    transposed-boundary u = shell-evaluation-extensionality n
      (CS.restriction (toNat n) (transposed-cube u)) b
      (λ t → strict-trans
        (Shell.restriction-natural n (λ h → h t) (transposed-cube u))
        (strict-trans
          (strict-cong (λ c → outer (CS.restriction (toNat n) (inner c)))
            (Coordinate.transpose-evaluate n
              (λ t → CF.forget-filler (toNat n) (evaluated-boundary t) (u t)) t))
          (Boundary.forget-boundary-strict n (evaluated-boundary t) (u t))))

    transpose-filler : Pointwise → CF.Filler (toNat n) b
    transpose-filler u = cast-filler n (transposed-boundary u)
      (CF.canonical-filler (toNat n) (transposed-cube u))

    transpose-filler-forget : (u : Pointwise)
      → outer (CF.forget-filler (toNat n) b (transpose-filler u)) ≡ˢ outer (transposed-cube u)
    transpose-filler-forget u = strict-trans
      (cast-forget n (transposed-boundary u) (CF.canonical-filler (toNat n) (transposed-cube u)))
      (Boundary.forget-canonical-strict n (transposed-cube u))

    evaluate-transpose-point : (u : Pointwise) (t : T)
      → outer (evaluate-filler (transpose-filler u) t) ≡ˢ outer (u t)
    evaluate-transpose-point u t = Direct.filler-extensionality n (evaluated-boundary t)
      (strict-trans
        (Direct.map-filler-forget n (λ h → h t) b (transpose-filler u))
        (strict-trans
          (strict-cong (λ c → outer (map-cube n (λ h → h t) (inner c))) (transpose-filler-forget u))
          (Coordinate.transpose-evaluate n
            (λ t → CF.forget-filler (toNat n) (evaluated-boundary t) (u t)) t)))

    evaluate-transpose : (u : Pointwise)
      → outer (evaluate-filler (transpose-filler u)) ≡ˢ outer u
    evaluate-transpose u = function-ext (evaluate-transpose-point u)

    transpose-evaluate : (c : CF.Filler (toNat n) b)
      → outer (transpose-filler (evaluate-filler c)) ≡ˢ outer c
    transpose-evaluate c = Direct.filler-extensionality n b
      (strict-trans
        (transpose-filler-forget (evaluate-filler c))
        (cube-evaluation-extensionality n (transposed-cube (evaluate-filler c))
          (CF.forget-filler (toNat n) b c)
          (λ t → strict-trans
            (Coordinate.transpose-evaluate n
              (λ t → CF.forget-filler (toNat n) (evaluated-boundary t) (evaluate-filler c t)) t)
            (Direct.map-filler-forget n (λ h → h t) b c))))

    equivalence : CF.Filler (toNat n) b ≃ Pointwise
    equivalence = isoToEquiv (iso evaluate-filler transpose-filler
      (λ u → strict-to-path (evaluate-transpose u))
      (λ c → strict-to-path (transpose-evaluate c)))

    evaluation-is-equivalence : isEquiv evaluate-filler
    evaluation-is-equivalence = equivalence .snd
