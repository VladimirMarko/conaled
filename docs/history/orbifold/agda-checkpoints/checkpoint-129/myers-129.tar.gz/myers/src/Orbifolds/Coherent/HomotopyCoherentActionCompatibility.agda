{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentActionCompatibility where

open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken; _≤ᵖ_; pzero≤; psuc≤)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face; StrictCubicalExtensionality)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC
open import Orbifolds.Coherent.CoherentArrowSplits
import Orbifolds.Coherent.CoherentArrowSplits as AS
open import Orbifolds.Coherent.CoherentCubeTensors using (cast-cube)
import Orbifolds.Coherent.CoherentCubeTensors as CT
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
open import Orbifolds.Coherent.HomotopyCoherentActionData
import Orbifolds.Coherent.HomotopyCoherentActionData as AD
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Compatible; low; high; star)

middle-bound : (n : Dim) (p q : Position (osuc n)) (le : p ≤ᵖ q)
  → middle-degree n p q le ≤ᵈ n
middle-bound n pzero q pzero≤ = suffix-bound n q
middle-bound (osuc n) (psuc p) (psuc q) (psuc≤ le) = lower (middle-bound n p q le)

module Compatibility {ℓ : Level} (C : Category ℓ ℓ) (V : Category.Obj C → Type ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open AC.Arrows C
  open AS.Splits C
  open CT.Tensor E
  open AD.Data C V

  action-cast : {k m n : Dim} (e : k ≡ˢ m) (b : k ≤ᵈ n) (b' : m ≤ᵈ n)
    (F : Actions n) {x y : Obj} (c : Chain k x y) (a : V x)
    → outer (cast-cube e (at b F c a)) ≡ˢ outer (at b' F (cast-chain e c) a)
  action-cast reflˢ b b' F c a = strict-cong (λ f → outer (inner f c a))
    (lookup-irrelevance b b' F)

  action-uncast : {k m n : Dim} (e : k ≡ˢ m) (b : k ≤ᵈ n) (b' : m ≤ᵈ n)
    (F : Actions n) {x y : Obj} (c : Chain k x y) (a : V x)
    → outer (at b F c a) ≡ˢ outer (cast-cube (strict-sym e) (at b' F (cast-chain e c) a))
  action-uncast reflˢ b b' F c a = strict-cong (λ f → outer (inner f c a))
    (lookup-irrelevance b b' F)

  evaluate-split : (n : Dim) (F : Actions n) (p : Position (osuc n)) {x y : Obj}
    → Split n p x y → V x → Cube n (V y)
  evaluate-split n F p z a = tensor-action n p
    (at (suffix-bound n p) F (z .snd .fst))
    (at (prefix-bound n p) F (z .snd .snd)) a

  suffix-zero : (n : Dim) (F : Actions (osuc n)) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y) (a : V x)
    → outer (coordinate-face n p i0 (one (osuc n) F (psuc q) c a))
      ≡ˢ outer (one n (F .fst) q (face (osuc n) (weaken p) c) a)
  suffix-zero n F coherent p q le c a = strict-trans
    (tensor-face-suffix n p q le i0
      (at (suffix-bound (osuc n) (psuc q)) F (split-suffix (osuc n) (psuc q) c))
      (at (prefix-bound (osuc n) (psuc q)) F (split-prefix (osuc n) (psuc q) c)) a)
    (strict-trans
      (tensor-pointwise n q _ _ _ _
        (λ b → strict-trans
          (law-at-zero (suffix-bound (osuc n) (psuc q)) F coherent
            (in-suffix n p q le) (split-suffix (osuc n) (psuc q) c) b)
          (strict-cong (λ f → outer (inner f
            (face (suffix-degree n q) (in-suffix n p q le)
              (split-suffix (osuc n) (psuc q) c)) b))
            (lookup-irrelevance
              (transitive (lower same) (suffix-bound (osuc n) (psuc q)))
              (lower (suffix-bound n q)) F)))
        (λ a → reflˢ) a)
      (strict-sym (strict-cong
        (λ z → outer (evaluate-split n (F .fst) q (inner z) a))
        (cut-face-suffix n p q le c))))

  prefix-zero : (n : Dim) (F : Actions (osuc n)) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y) (a : V x)
    → outer (coordinate-face n q i0 (one (osuc n) F (weaken p) c a))
      ≡ˢ outer (one n (F .fst) p (face (osuc n) (psuc q) c) a)
  prefix-zero n F coherent p q le c a = strict-trans
    (tensor-face-prefix n p q le i0
      (at (suffix-bound (osuc n) (weaken p)) F (split-suffix (osuc n) (weaken p) c))
      (at (prefix-bound (osuc n) (weaken p)) F (split-prefix (osuc n) (weaken p) c)) a)
    (strict-trans
      (tensor-pointwise n p _ _ _ _
        (λ b → action-cast (suffix-weaken n p)
          (suffix-bound (osuc n) (weaken p)) (lower (suffix-bound n p)) F
          (split-suffix (osuc n) (weaken p) c) b)
        (λ a → strict-trans
          (strict-cong (λ z → outer (coordinate-face (prefix-degree n p) (in-prefix n p q le) i0 (inner z)))
            (action-cast (prefix-weaken n p)
              (prefix-bound (osuc n) (weaken p)) (successor-bound (prefix-bound n p)) F
              (split-prefix (osuc n) (weaken p) c) a))
          (strict-trans
            (law-at-zero (successor-bound (prefix-bound n p)) F coherent
              (in-prefix n p q le) (normalized n p c .snd .snd) a)
            (strict-cong (λ f → outer (inner f
              (face (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd)) a))
              (lookup-irrelevance
                (transitive (lower same) (successor-bound (prefix-bound n p)))
                (lower (prefix-bound n p)) F)))) a)
      (strict-sym (strict-cong
        (λ z → outer (evaluate-split n (F .fst) p (inner z) a))
        (cut-face-prefix n p q le c))))

  evaluate-triple-prefix : (n : Dim) (F : Actions (osuc n))
    (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    → Triple n p q le x y → V x → Cube n (V y)
  evaluate-triple-prefix n F p q le z a = tensor-prefix-first n p q le
    (at (lower (suffix-bound n p)) F (z .snd .snd .fst))
    (at (lower (middle-bound n p q le)) F (z .snd .snd .snd .fst))
    (at (lower (prefix-bound n q)) F (z .snd .snd .snd .snd)) a

  evaluate-triple-suffix : (n : Dim) (F : Actions (osuc n))
    (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    → Triple n p q le x y → V x → Cube n (V y)
  evaluate-triple-suffix n F p q le z a = tensor-suffix-first n p q le
    (at (lower (suffix-bound n p)) F (z .snd .snd .fst))
    (at (lower (middle-bound n p q le)) F (z .snd .snd .snd .fst))
    (at (lower (prefix-bound n q)) F (z .snd .snd .snd .snd)) a

  prefix-one : (n : Dim) (F : Actions (osuc n)) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y) (a : V x)
    → outer (coordinate-face n q i1 (one (osuc n) F (weaken p) c a))
      ≡ˢ outer (evaluate-triple-prefix n F p q le (triple n p q le c) a)
  prefix-one n F coherent p q le c a = strict-trans
    (tensor-face-prefix n p q le i1
      (at (suffix-bound (osuc n) (weaken p)) F (split-suffix (osuc n) (weaken p) c))
      (at (prefix-bound (osuc n) (weaken p)) F (split-prefix (osuc n) (weaken p) c)) a)
    (strict-trans
      (tensor-pointwise n p _ _ _ _
        (λ b → action-cast (suffix-weaken n p)
          (suffix-bound (osuc n) (weaken p)) (lower (suffix-bound n p)) F
          (split-suffix (osuc n) (weaken p) c) b)
        (λ a → strict-trans
          (strict-cong (λ z → outer (coordinate-face (prefix-degree n p) (in-prefix n p q le) i1 (inner z)))
            (action-cast (prefix-weaken n p)
              (prefix-bound (osuc n) (weaken p)) (successor-bound (prefix-bound n p)) F
              (split-prefix (osuc n) (weaken p) c) a))
          (strict-trans
            (law-at-one (successor-bound (prefix-bound n p)) F coherent
              (in-prefix n p q le) (normalized n p c .snd .snd) a)
            (tensor-pointwise (prefix-degree n p) (in-prefix n p q le) _ _ _ _
              (λ b → action-uncast (prefix-suffix n p q le)
                (transitive (lower (suffix-bound (prefix-degree n p) (in-prefix n p q le)))
                  (successor-bound (prefix-bound n p)))
                (lower (middle-bound n p q le)) F
                (split-suffix (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd)) b)
              (λ a → action-uncast (prefix-prefix n p q le)
                (transitive (lower (prefix-bound (prefix-degree n p) (in-prefix n p q le)))
                  (successor-bound (prefix-bound n p)))
                (lower (prefix-bound n q)) F
                (split-prefix (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd)) a) a))) a)
      (strict-cong (λ z → outer (evaluate-triple-prefix n F p q le (inner z) a))
        (prefix-triple n p q le c)))

  suffix-one : (n : Dim) (F : Actions (osuc n)) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {x y : Obj}
    (c : Chain (osuc (osuc n)) x y) (a : V x)
    → outer (coordinate-face n p i1 (one (osuc n) F (psuc q) c a))
      ≡ˢ outer (evaluate-triple-suffix n F p q le (triple n p q le c) a)
  suffix-one n F coherent p q le c a = strict-trans
    (tensor-face-suffix n p q le i1
      (at (suffix-bound (osuc n) (psuc q)) F (split-suffix (osuc n) (psuc q) c))
      (at (prefix-bound (osuc n) (psuc q)) F (split-prefix (osuc n) (psuc q) c)) a)
    (strict-trans
      (tensor-pointwise n q _ _ _ _
        (λ b → strict-trans
          (law-at-one (suffix-bound (osuc n) (psuc q)) F coherent
            (in-suffix n p q le) (split-suffix (osuc n) (psuc q) c) b)
          (tensor-pointwise (suffix-degree n q) (in-suffix n p q le) _ _ _ _
            (λ d → action-uncast (suffix-suffix n p q le)
              (transitive (lower (suffix-bound (suffix-degree n q) (in-suffix n p q le)))
                (suffix-bound (osuc n) (psuc q)))
              (lower (suffix-bound n p)) F
              (split-suffix (suffix-degree n q) (in-suffix n p q le)
                (split-suffix (osuc n) (psuc q) c)) d)
            (λ b → action-uncast (suffix-prefix n p q le)
              (transitive (lower (prefix-bound (suffix-degree n q) (in-suffix n p q le)))
                (suffix-bound (osuc n) (psuc q)))
              (lower (middle-bound n p q le)) F
              (split-prefix (suffix-degree n q) (in-suffix n p q le)
                (split-suffix (osuc n) (psuc q) c)) b) b))
        (λ a → reflˢ) a)
      (strict-cong (λ z → outer (evaluate-triple-suffix n F p q le (inner z) a))
        (suffix-triple-correct n p q le c)))

  action-compatible : (n : Dim) (F : Actions n) → Coherent n F
    → {x y : Obj} (c : Chain (osuc n) x y) (a : V x)
    → Compatible (osuc n) (faces n F c a)
  action-compatible ozero F coherent c a = star
  action-compatible (osuc n) F coherent c a p q le low low = strict-trans
    (LayerLaws.zero-face (LawPair.current coherent) p (face (osuc n) (psuc q) c) a)
    (strict-trans
      (strict-cong (λ z → outer (top n (F .fst) (inner z) a)) (face-face n p q le c))
      (strict-sym (LayerLaws.zero-face (LawPair.current coherent) q
        (face (osuc n) (weaken p) c) a)))
  action-compatible (osuc n) F coherent c a p q le low high = strict-trans
    (suffix-zero n F coherent p q le c a)
    (strict-sym (LayerLaws.one-face (LawPair.current coherent) q
      (face (osuc n) (weaken p) c) a))
  action-compatible (osuc n) F coherent c a p q le high low = strict-trans
    (LayerLaws.one-face (LawPair.current coherent) p (face (osuc n) (psuc q) c) a)
    (strict-sym (prefix-zero n F coherent p q le c a))
  action-compatible (osuc n) F coherent c a p q le high high = strict-trans
    (suffix-one n F coherent p q le c a)
    (strict-trans
      (strict-sym (tensor-associativity n p q le
        (at (lower (suffix-bound n p)) F (triple n p q le c .snd .snd .fst))
        (at (lower (middle-bound n p q le)) F (triple n p q le c .snd .snd .snd .fst))
        (at (lower (prefix-bound n q)) F (triple n p q le c .snd .snd .snd .snd)) a))
      (strict-sym (prefix-one n F coherent p q le c a)))
