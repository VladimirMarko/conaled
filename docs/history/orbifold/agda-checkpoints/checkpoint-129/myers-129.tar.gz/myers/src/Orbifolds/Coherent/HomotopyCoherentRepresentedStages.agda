{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentRepresentedStages where

-- Data used by the constructive induction on finite homotopy-coherent bar realizations.
-- Restriction is fixed to the actual cocone action on a universal cocone;
-- its naturality and all strict coherence come from the derived functor
-- laws. A Represented value is an induction witness, not an assumption
-- that every diagram already has a presentation. The base is built here.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentColimitBase as Base

module Induction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  open Cocones.Functoriality C D E F using (Cocone; postcompose)

  record Represented (n : Dim) : Type (ℓ-suc ℓ) where
    field
      Space : Type ℓ
      universal-cocone : Cocone Space n

    restrict : (Y : Type ℓ) → (Space → Y) → Cocone Y n
    restrict Y h = postcompose n h universal-cocone

    field
      restriction-isEquiv : (Y : Type ℓ) → isEquiv (restrict Y)

    universal : (Y : Type ℓ) → (Space → Y) ≃ Cocone Y n
    universal Y = restrict Y , restriction-isEquiv Y

    assemble : (Y : Type ℓ) → Cocone Y n → Space → Y
    assemble Y = invEq (universal Y)

    restrict-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Space → Y)
      → outer (postcompose n k (restrict Y h)) ≡ˢ outer (restrict Z (k ∘ h))
    restrict-natural k h = Cocones.Functoriality.postcompose-compose C D E F n h k universal-cocone

    identity-computation : outer (restrict Space (idfun Space)) ≡ˢ outer universal-cocone
    identity-computation = Cocones.Functoriality.postcompose-identity C D E F n Space universal-cocone

    assemble-restrict : (Y : Type ℓ) (h : Space → Y) → assemble Y (restrict Y h) ≡ h
    assemble-restrict Y = retEq (universal Y)

    restrict-assemble : (Y : Type ℓ) (c : Cocone Y n) → restrict Y (assemble Y c) ≡ c
    restrict-assemble Y = secEq (universal Y)

  initial : Represented ozero
  Represented.Space initial = Base.Base.Initial C D E F
  Represented.universal-cocone initial = Base.Base.canonical-cocone C D E F
  Represented.restriction-isEquiv initial Y = Base.Base.Target.universal C D E F Y .snd
