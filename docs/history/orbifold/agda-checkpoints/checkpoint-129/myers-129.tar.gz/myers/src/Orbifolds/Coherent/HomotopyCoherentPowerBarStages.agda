{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarStages where

-- Actual finite power comparisons, with their universal-cocone triangles.
-- The successor map is definitionally the cellular relative-map successor:
-- the literal map of spans followed by the literal power/pushout comparison.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (_∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen; composition-term)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowers as Powers
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
import Orbifolds.Coherent.HomotopyCoherentColimitStepData as Stages
import Orbifolds.Coherent.HomotopyCoherentColimitCells as Presentations
import Orbifolds.Coherent.HomotopyCoherentFiniteCellSuccessors as Successors
import Orbifolds.Coherent.PowerPushoutEvaluation as Evaluation
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularPresentationComparisons as CC
import Orbifolds.TinyCellularPresentations as Tiny

-- Elaborate the ordinary composition while retaining the same canonical
-- endpoint definitions used by the already checked successor triangle.
private
  macro
    power-triangle-compose : Reflection.Term → Reflection.Term
      → Reflection.Term → Reflection.TC ⊤
    power-triangle-compose first second hole = assign-frozen
      ((quote Cocones.Functoriality.postcompose) ∷
       (quote Restriction.Restriction.finite-restriction) ∷
       (quote Comparison.Comparison.compare) ∷
       (quote Literal.Map.TargetSpace.pullback) ∷
       (quote Cocones.Functoriality.Cocone) ∷
       (quote Literal.Map.induced) ∷ [])
      (composition-term first second) hole

private
  macro
    power-triangle-value : Reflection.Name → Reflection.Term → Reflection.Term → Reflection.TC ⊤
    power-triangle-value map-head candidate hole = assign-frozen
      (map-head ∷ (quote Cocones.Functoriality.postcompose) ∷
       (quote Restriction.Restriction.finite-restriction) ∷
       (quote Comparison.Comparison.compare) ∷
       (quote Literal.Map.TargetSpace.pullback) ∷
       (quote Cocones.Functoriality.Cocone) ∷
       (quote Literal.Map.induced) ∷ []) candidate hole

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module Power = Powers.Construction C E F T using (Power; evaluation)
  module RD = Represented.Induction C D E F using (Represented; module Represented; initial)
  module RP = Represented.Induction C (Power.Power D) E F using (Represented; module Represented; initial)
  module CD = Cocones.Functoriality C D E F using (Cocone; postcompose; postcompose-compose)
  module CPow = Cocones.Functoriality C (Power.Power D) E F using (Cocone; postcompose; postcompose-compose)
  module OriginalStages where
    module Step (n : Dim) (previous : RD.Represented n) = Stages.Step C D E F n previous
  module PoweredStages where
    module Step (n : Dim) (previous : RP.Represented n) = Stages.Step C (Power.Power D) E F n previous
  module Original = Presentations.Construction C D E F using (presentation)
  module Powered = Presentations.Construction C (Power.Power D) E F using (presentation)
  module R (t : T) (Y : Type ℓ) where
    finite-restriction : (n : Dim) → CD.Cocone Y n → CPow.Cocone Y n
    finite-restriction = Restriction.Restriction.finite-restriction C (Power.Power D) D
      (Power.evaluation D t) E F Y

  record State (n : Dim) (original : RD.Represented n) (powered : RP.Represented n) : Type ℓ where
    field
      q : RP.Represented.Space powered → T → RD.Represented.Space original
      triangle : (t : T) → Triangles.Triangle C (Power.Power D) D (Power.evaluation D t)
        E F n powered original (λ x → q x t)

  initial : State ozero RD.initial RP.initial
  State.q initial (x , v) t = x , v t
  State.triangle initial t = refl

  module Step (n : Dim) (original : RD.Represented n) (powered : RP.Represented n)
      (previous : State n original powered) where
    module OD = OriginalStages.Step n original
    module PP = PoweredStages.Step n powered
    module Point (t : T) = Successors.Construction C (Power.Power D) D (Power.evaluation D t)
      E F n powered original (λ x → State.q previous x t) (State.triangle previous t)
      using (module Cell; canonical-triangle)

    on-cell : PP.Cell.Cell → T → OD.Cell.Cell
    on-cell (c , v) t = c , v t

    on-boundary : PP.Cell.Boundary → T → OD.Cell.Boundary
    on-boundary ((c , v) , s) t = (c , v t) , s

    attachment-square : State.q previous ∘ PP.Cell.attach
      ≡ (λ v → OD.Cell.attach ∘ v) ∘ on-boundary
    attachment-square i z t = Point.Cell.attachment-square t i z

    boundary-square : on-cell ∘ PP.Cell.boundary
      ≡ (λ v → OD.Cell.boundary ∘ v) ∘ on-boundary
    boundary-square = refl

    q : PP.Realize → T → OD.Realize
    q = CC.Theory.Step.next-map (Tiny.Power.operations T)
      (Original.presentation n original) (Powered.presentation n powered)
      (State.q previous) on-boundary on-cell attachment-square boundary-square

    module Eval = Evaluation.Comparison T OD.Cell.attach OD.Cell.boundary PP.Cell.attach PP.Cell.boundary
      on-boundary (State.q previous) on-cell attachment-square boundary-square
      using (evaluation-computation)

    evaluation-computation : (t : T) (z : PP.Realize) → q z t ≡ Point.Cell.induced t z
    evaluation-computation = Eval.evaluation-computation

    TriangleGoal : (t : T) → Type ℓ
    TriangleGoal t = Triangles.Triangle C (Power.Power D) D (Power.evaluation D t)
      E F (osuc n) PP.next OD.next (λ z → q z t)

    first-factor : (t : T) → _
    first-factor t = cong
      {A = Triangles.space C (Power.Power D) E F (osuc n) PP.next
        → Triangles.space C D E F (osuc n) OD.next}
      {B = λ _ → CPow.Cocone
        (Triangles.space C D E F (osuc n) OD.next) (osuc n)}
      (λ h → CPow.postcompose (osuc n)
        {Y = Triangles.space C (Power.Power D) E F (osuc n) PP.next}
        {Z = Triangles.space C D E F (osuc n) OD.next}
        h (Triangles.universal C (Power.Power D) E F (osuc n) PP.next))
      (funExt (evaluation-computation t))

    -- Isolate joining the two already typed factors from the explicit
    -- public TriangleGoal conversion. All inferred annotations must close.
    joined : (t : T) → _
    joined t = power-triangle-compose (first-factor t) (Point.canonical-triangle t)

    -- Retag only the already inferred composite at the original public goal.
    triangle : (t : T)
      → Triangles.Triangle C (Power.Power D) D (Power.evaluation D t)
          E F (osuc n) PP.next OD.next (λ z → q z t)
    triangle t = power-triangle-value q (joined t)

  advance : (n : Dim) (original : RD.Represented n) (powered : RP.Represented n)
    → State n original powered
    → State (osuc n) (OriginalStages.Step.next n original) (PoweredStages.Step.next n powered)
  advance n original powered previous = record
    { q = Step.q n original powered previous
    ; triangle = λ t → power-triangle-value Step.q (Step.triangle n original powered previous t)
    }
