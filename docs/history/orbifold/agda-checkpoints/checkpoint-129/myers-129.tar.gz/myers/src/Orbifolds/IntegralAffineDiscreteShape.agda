{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineDiscreteShape where

-- The checked affine shape calculation for an arbitrary crisp,
-- crisply discrete group H. Finiteness is a derived specialization,
-- not a desired quotient-shape premise.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv; toIsEquiv)
open import Cubical.Data.Unit using (tt)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.FinSet using (isFinSet)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.GeneralLinearMatrices as GL
import Orbifolds.IntegralAffineShape as AS
import Orbifolds.NullSigmaReflection as NS

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ upper-identity-rules : CI.CrispIdentityInduction {ℓ-suc ℓ})
    (@♭ n : ℕ) (@♭ H : Group ℓ)
    (@♭ ρ : GroupHom H (GL.Ring.Dimension.GeneralLinear ℤCommRing n)) where
  module Base = AS.Context R identity-rules upper-identity-rules n H ρ
  open Base using (LowerRealFlat; UpperRealFlat;
    coordinate-shape-connected; regular-fiber-connected; all-fibers-connected) public

  group-null : LowerRealFlat → CrisplyDiscrete (H .fst)
    → NB.isNull Base.Real.ShapeGenerator (H .fst)
  group-null lower-flat discrete _ = fromIsEquiv const
    (equivFun (lower-flat (H .fst)) discrete)

  affine-group-null : LowerRealFlat → CrisplyDiscrete (H .fst)
    → NB.isNull Base.Real.ShapeGenerator (Base.Affine.AffineGroup .fst)
  affine-group-null lower-flat discrete = NP.isNullΣ (Base.lattice-null lower-flat)
    (λ _ → group-null lower-flat discrete)

  classifying-type-null : LowerRealFlat → UpperRealFlat → CrisplyDiscrete (H .fst)
    → NB.isNull Base.Real.ShapeGenerator Base.T.Torsor
  classifying-type-null lower-flat upper-flat discrete =
    Base.Classifier.classifier-null upper-flat (affine-group-null lower-flat discrete)

  finite-group-discrete : LowerRealFlat → isFinSet (H .fst) → CrisplyDiscrete (H .fst)
  finite-group-discrete lower-flat finite = invEq (lower-flat (H .fst))
    (toIsEquiv const (Base.Finite.finite-null lower-flat finite tt))

  module Modal (lower-flat : LowerRealFlat) (upper-flat : UpperRealFlat)
      (discrete : CrisplyDiscrete (H .fst)) where
    module Reflection = NS.Theory.Over Base.Real.ShapeGenerator Base.T.Torsor
      (classifying-type-null lower-flat upper-flat discrete) Base.F.Bundle
    module Connected = Reflection.ConnectedFibers all-fibers-connected

    shape-affine-quotient≃classifying-type :
      NB.Null Base.Real.ShapeGenerator Base.F.Family.Quotient ≃ Base.T.Torsor
    shape-affine-quotient≃classifying-type = Connected.reflection≃base

    projection-unit : (z : Base.F.Family.Quotient)
      → shape-affine-quotient≃classifying-type .fst NB.∣ z ∣ ≡ z .fst
    projection-unit = Reflection.projection-unit

    orbit-point-triangle : (x : Base.Coordinates.Vector)
      → shape-affine-quotient≃classifying-type .fst
          NB.∣ Base.F.Family.quotient (Base.F.orbit x) ∣ ≡ Base.T.regular-torsor
    orbit-point-triangle x = refl
