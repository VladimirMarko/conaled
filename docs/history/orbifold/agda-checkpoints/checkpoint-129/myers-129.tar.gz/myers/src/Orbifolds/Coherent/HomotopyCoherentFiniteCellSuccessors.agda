{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellSuccessors where

-- The literal map of cell pushouts advances a finite universal-cocone
-- triangle. Every comparison here refers to the constructed canonical
-- cocones, including their explicit opaque-data computation witnesses.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (_∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.HomotopyCoherentColimitStepCoherenceData as StepData
import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle as SourceTriangles
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as TrianglePasting
import Orbifolds.Coherent.HomotopyCoherentUnifiedLiteralFiniteCellMaps as CellMaps
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments

-- Check the already constructed path at its explicit public goal while
-- retaining its outer and nested endpoint definitions during conversion.
-- Ordinary checked reflexivity assigns exactly that same path.
private
  macro
    inference-frozen-value : Reflection.Name → Reflection.Name
      → Reflection.Term → Reflection.Term → Reflection.TC ⊤
    inference-frozen-value left-head right-head candidate hole =
      assign-frozen (left-head ∷ right-head ∷
        (quote Comparison.Comparison.compare) ∷
        (quote Literal.Map.TargetSpace.pullback) ∷
        (quote Cocones.Functoriality.Cocone) ∷
        (quote Literal.Map.induced) ∷ []) candidate hole

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  -- Retain only the typed declarations needed by the triangle. The full
  -- finite-map and cell-quotation proof namespaces need not be copied.
  module M where
    A B : Type ℓ
    A = Triangles.space C D E F n source
    B = Triangles.space C G E F n target

    module CD = Cocones.Functoriality C D E F using (Cocone; postcompose; postcompose-compose)
    module CG = Cocones.Functoriality C G E F using (Cocone; postcompose; postcompose-compose)
    module SD = Comparison.Comparison C D E F n source
      using (Index; Coefficient; original-boundary; compare)
    module TG = Comparison.Comparison C G E F n target
      using (Index; Coefficient; original-boundary; compare)

    uD : CD.Cocone A n
    uD = Triangles.universal C D E F n source

    module Cell where
      module Data = CellMaps.Construction.Cell C D G α E F n source target f triangle
        using (induced; attachment-square)
      open Data public
      module TargetSpace (Y : Type ℓ) = CellMaps.Construction.Cell.TargetSpace
        C D G α E F n source target f triangle Y using (pullback)
    module At (Y : Type ℓ) = CellMaps.Construction.At C D G α E F n source target f triangle Y
      using (lower-path; lower-path-value; comparison-square)
    module R (Y : Type ℓ) where
      finite-restriction : (m : Dim) → CG.Cocone Y m → CD.Cocone Y m
      finite-restriction = Restriction.Restriction.finite-restriction C D G α E F Y

  module Source where
    open StepData.Step C D E F n source
      using (Realize; canonical-cocone; cell-cocone; cell-original-computation;
        next; transition-computation) public
    module Cell = Attachments.Attachment E (osuc n) M.A
      M.SD.Index M.SD.Coefficient M.SD.original-boundary

  module Target where
    open StepData.Step C G E F n target
      using (Realize; canonical-cocone; cell-cocone; cell-original-computation;
        next; transition-computation) public
    module Cell = Attachments.Attachment E (osuc n) M.B
      M.TG.Index M.TG.Coefficient M.TG.original-boundary

  module Cell = M.Cell
  module At = M.At Target.Realize
  module R = M.R Target.Realize

  target-canonical-computation : outer {A = Target.Cell.Cocone Target.Realize} Target.cell-cocone
    ≡ˢ outer {A = Target.Cell.Cocone Target.Realize} Target.Cell.canonical-cocone
  target-canonical-computation = Canonical.Canonical.constructed E (osuc n)
    M.B M.TG.Index M.TG.Coefficient M.TG.original-boundary

  actual-map : Source.Realize → Target.Realize
  actual-map = Cell.induced

  module SourceTriangle = SourceTriangles.Construction C D E F n source
    using (canonical-restriction-comparison; canonical-transition-coherence)

  -- These aliases infer the exact types of their checked right-hand sides.
  -- The no-unsolved-metas gate closes every annotation; the final public
  -- canonical-triangle statement below is explicit.
  source-square : _
  source-square = SourceTriangle.canonical-restriction-comparison Target.Realize actual-map

  source-prefix : _
  source-prefix = SourceTriangle.canonical-transition-coherence Target.Realize actual-map

  -- Construct the complete dependent input once. Both the triangle and
  -- its lifted projection below use this same canonical packet path.
  module PacketConstruction = TrianglePasting.Construction
    C D G α E F n source target f triangle
    using (module Packet; module ForInput)

  module TriangleData = PacketConstruction.ForInput
    PacketConstruction.Packet.canonical
    using (p; p₀; p-constructed; base-path; p-first;
      first; first-prefix; middle; middle-prefix; last; value; constructed; prefix)

  module CellNaturalityData where
    open TriangleData public using () renaming
      (p to canonical-naturality; p-constructed to construction;
        p-first to original-computation)

  lifted-cell-square : _
  lifted-cell-square = cong {A = Source.Cell.Cocone Target.Realize}
    {B = λ _ → M.CD.Cocone Target.Realize (osuc n)}
    (M.SD.compare Target.Realize) CellNaturalityData.canonical-naturality

  lifted-cell-prefix : _
  lifted-cell-prefix = cong
    {A = (Target.Cell.include ∘ f) ≡ (Target.Cell.include ∘ f)}
    {B = λ _ → M.CD.postcompose n {Y = M.A} {Z = Target.Realize} (Target.Cell.include ∘ f) M.uD
      ≡ M.CD.postcompose n {Y = M.A} {Z = Target.Realize} (Target.Cell.include ∘ f) M.uD}
    (λ p → cong {A = M.A → Target.Realize} {B = λ _ → M.CD.Cocone Target.Realize n}
      (λ h → M.CD.postcompose n {Y = M.A} {Z = Target.Realize} h M.uD) p)
    CellNaturalityData.original-computation

  module LiteralTarget = Attachments.Attachment E (osuc n) M.B M.SD.Index
    M.TG.Coefficient M.TG.original-boundary
    using (Realize; Cocone; canonical-cocone)

  literal-target-canonical-computation :
    outer {A = LiteralTarget.Cocone LiteralTarget.Realize}
      (Canonical.Canonical.cocone E (osuc n) M.B M.SD.Index
        M.TG.Coefficient M.TG.original-boundary)
      ≡ˢ outer {A = LiteralTarget.Cocone LiteralTarget.Realize}
        LiteralTarget.canonical-cocone
  literal-target-canonical-computation = Canonical.Canonical.constructed E (osuc n)
    M.B M.SD.Index M.TG.Coefficient M.TG.original-boundary

  -- Export the actual packet's chosen paths and their complete
  -- projection laws, including the literal middle computation.
  open TriangleData public renaming
    (first to first-square; first-prefix to first-square-prefix;
      middle to middle-square; middle-prefix to middle-square-prefix;
      last to last-square;
      constructed to triangle-construction; prefix to triangle-prefix)

  -- Use the actual represented successor records in the public theorem.
  -- This is the canonical cocone triangle at the two literal next stages.
  canonical-triangle : Triangles.Triangle C D G α E F (osuc n)
    Source.next Target.next actual-map
  canonical-triangle = inference-frozen-value
    Cocones.Functoriality.postcompose Restriction.Restriction.finite-restriction
    TriangleData.value
