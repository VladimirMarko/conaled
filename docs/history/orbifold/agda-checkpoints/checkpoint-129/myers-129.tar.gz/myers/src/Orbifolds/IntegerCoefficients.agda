{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegerCoefficients where

-- The canonical, proved ring homomorphism from the actual integers.
-- This prevents the SL₂(ℤ) action from depending on an arbitrary or
-- assumed interpretation of integer matrix coefficients.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ; pos)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.AbGroup.Base using (AbGroup→Group)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
open import Cubical.Algebra.Group.Instances.Int using (ℤGroup)
open import Cubical.Algebra.Group.ZAction using (_ℤ[_]·_; distrℤ·; homPresℤ·; ℤ·≡·)
import Orbifolds.SpecialLinearTwo as SL

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  module Z = CommRingStr (ℤCommRing .snd)

  additive-group : Group ℓ
  additive-group = AbGroup→Group (CommRing→AbGroup R)

  integer : ℤ → R .fst
  integer n = n ℤ[ additive-group ]· 1r

  additive-homomorphism : GroupHom ℤGroup additive-group
  additive-homomorphism = integer , makeIsGroupHom (distrℤ· additive-group 1r)

  multiply-homomorphism : (r : R .fst) → GroupHom additive-group additive-group
  multiply-homomorphism r = (_· r) , makeIsGroupHom (λ x y → ·DistL+ x y r)

  abstract
    integer-preserves-product : (m n : ℤ) → integer (Z._·_ m n) ≡ integer m · integer n
    integer-preserves-product m n =
      cong integer (ℤ·≡· m n)
      ∙ homPresℤ· additive-homomorphism n m
      ∙ sym (homPresℤ· (multiply-homomorphism (integer n)) 1r m
        ∙ cong (m ℤ[ additive-group ]·_) (·IdL (integer n)))

  ring-homomorphism : CommRingHom ℤCommRing R
  ring-homomorphism .fst = integer
  IsCommRingHom.pres0 (ring-homomorphism .snd) = refl
  IsCommRingHom.pres1 (ring-homomorphism .snd) = +IdR 1r
  IsCommRingHom.pres+ (ring-homomorphism .snd) = IsGroupHom.pres· (additive-homomorphism .snd)
  IsCommRingHom.pres· (ring-homomorphism .snd) = integer-preserves-product
  IsCommRingHom.pres- (ring-homomorphism .snd) = IsGroupHom.presinv (additive-homomorphism .snd)

  module Matrices = SL.Map ℤCommRing R ring-homomorphism

  special-linear-homomorphism : GroupHom SL.SL₂ℤ (SL.Ring.SpecialLinearGroup R)
  special-linear-homomorphism = Matrices.group-homomorphism
