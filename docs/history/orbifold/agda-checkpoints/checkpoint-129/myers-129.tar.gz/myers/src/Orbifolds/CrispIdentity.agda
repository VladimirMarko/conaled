{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispIdentity where

-- Uniform ambient crisp identity induction, following Shulman,
-- arXiv:1509.07584v3, Theorem 5.6.  This rule is an explicit parameter;
-- safe Cubical Agda does not supply crisp path splitting.  The identity
-- equivalence below is proved from the rule, not included as a field.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Orbifolds.Crisp

-- A universe-indexed instance of the structural rule.  The motive,
-- reflexivity branch, endpoints and path are all native-crisp.  Its
-- computation law is propositional; no judgmental computation is
-- asserted for a parameter supplied by the ambient theory.
record CrispIdentityInduction {@♭ ℓ : Level} : Type (ℓ-suc ℓ) where
  field
    crisp-J : (@♭ A : Type ℓ)
      (@♭ P : (@♭ x y : A) → (@♭ p : x ≡ y) → Type ℓ)
      (@♭ d : (@♭ x : A) → P x x refl)
      (@♭ x y : A) (@♭ p : x ≡ y) → P x y p

    crisp-J-refl : (@♭ A : Type ℓ)
      (@♭ P : (@♭ x y : A) → (@♭ p : x ≡ y) → Type ℓ)
      (@♭ d : (@♭ x : A) → P x x refl)
      (@♭ x : A) → crisp-J A P d x x refl ≡ d x

-- The whole rule witness is crisp, so applying it to wholly crisp data
-- produces a term available in further crisp motives and constructions.
module Theory {@♭ ℓ : Level} (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CrispIdentityInduction rules

  box-path : {@♭ A : Type ℓ} (@♭ x y : A) (@♭ p : x ≡ y)
    → box x ≡ box y
  box-path {A} x y p = crisp-J A (λ u v q → box u ≡ box v)
    (λ u → refl) x y p

  box-path-refl : {@♭ A : Type ℓ} (@♭ x : A)
    → box-path x x refl ≡ refl
  box-path-refl {A} x = crisp-J-refl A (λ u v q → box u ≡ box v)
    (λ u → refl) x

  -- Encode/decode is defined for all ordinary elements of Flat A.
  -- Only ordinary Flat eliminations occur in these pattern matches.
  Code : {@♭ A : Type ℓ} → Flat A → Flat A → Type ℓ
  Code (box x) (box y) = Flat (x ≡ y)

  code-refl : {@♭ A : Type ℓ} (u : Flat A) → Code u u
  code-refl (box x) = box refl

  encode : {@♭ A : Type ℓ} {u v : Flat A} → u ≡ v → Code u v
  encode {u = u} p = subst (Code u) p (code-refl u)

  encode-refl : {@♭ A : Type ℓ} (u : Flat A)
    → encode (refl {x = u}) ≡ code-refl u
  encode-refl u = transportRefl (code-refl u)

  decode : {@♭ A : Type ℓ} {u v : Flat A} → Code u v → u ≡ v
  decode {u = box x} {v = box y} (box p) = box-path x y p

  decode-refl : {@♭ A : Type ℓ} (u : Flat A)
    → decode (code-refl u) ≡ refl
  decode-refl (box x) = box-path-refl x

  decode-encode : {@♭ A : Type ℓ} {u v : Flat A} (p : u ≡ v)
    → decode (encode p) ≡ p
  decode-encode {u = u} = J (λ v p → decode (encode p) ≡ p)
    (cong decode (encode-refl u) ∙ decode-refl u)

  encode-box-path : {@♭ A : Type ℓ} (@♭ x y : A) (@♭ p : x ≡ y)
    → encode (box-path x y p) ≡ box p
  encode-box-path {A} = crisp-J A
    (λ x y p → encode (box-path x y p) ≡ box p)
    (λ x → cong encode (box-path-refl x) ∙ encode-refl (box x))

  encode-decode : {@♭ A : Type ℓ} {u v : Flat A} (c : Code u v)
    → encode (decode c) ≡ c
  encode-decode {u = box x} {v = box y} (box p) = encode-box-path x y p

  code≃identity : {@♭ A : Type ℓ} (u v : Flat A) → Code u v ≃ (u ≡ v)
  code≃identity u v = isoToEquiv (iso decode encode decode-encode encode-decode)

  -- Shulman Theorem 6.1. The forward map is the constructed decode map.
  flat-identity-equivalence : {@♭ A : Type ℓ} (@♭ x y : A)
    → Flat (x ≡ y) ≃ (box x ≡ box y)
  flat-identity-equivalence x y = code≃identity (box x) (box y)

  counit-box-path : {@♭ A : Type ℓ} (@♭ x y : A) (@♭ p : x ≡ y)
    → cong counit (box-path x y p) ≡ p
  counit-box-path {A} = crisp-J A
    (λ x y p → cong counit (box-path x y p) ≡ p)
    (λ x → cong (cong counit) (box-path-refl x))

  counit-decode : {@♭ A : Type ℓ} (@♭ x y : A) (p : Flat (x ≡ y))
    → cong counit (decode p) ≡ counit p
  counit-decode x y (box p) = counit-box-path x y p

  box-path-natural : {@♭ A B : Type ℓ} (@♭ f : A → B)
    (@♭ x y : A) (@♭ p : x ≡ y)
    → cong (flat-map f) (box-path x y p)
      ≡ box-path (f x) (f y) (cong f p)
  box-path-natural {A} f = crisp-J A
    (λ x y p → cong (flat-map f) (box-path x y p)
      ≡ box-path (f x) (f y) (cong f p))
    (λ x → cong (cong (flat-map f)) (box-path-refl x)
      ∙ sym (box-path-refl (f x)))

  flat-identity-natural : {@♭ A B : Type ℓ} (@♭ f : A → B)
    (@♭ x y : A) (p : Flat (x ≡ y))
    → cong (flat-map f) (decode p)
      ≡ decode (flat-map (cong f) p)
  flat-identity-natural f x y (box p) = box-path-natural f x y p

  -- Functoriality on crisp homotopies follows from the identity map.
  flat-homotopy : {@♭ A B : Type ℓ} (@♭ f g : A → B)
    (@♭ h : (x : A) → f x ≡ g x) (x : Flat A)
    → flat-map f x ≡ flat-map g x
  flat-homotopy f g h (box x) = box-path (f x) (g x) (h x)

  -- Preservation of a crisp equivalence, including its crisp inverse
  -- laws, is derived. The actual forward map is exactly flat-map.
  flat-equivalence : {@♭ A B : Type ℓ} (@♭ e : A ≃ B) → Flat A ≃ Flat B
  flat-equivalence e = isoToEquiv
    (iso (flat-map (equivFun e)) (flat-map (invEq e)) right left)
    where
    right : (y : Flat _) → flat-map (equivFun e) (flat-map (invEq e) y) ≡ y
    right (box y) = box-path (equivFun e (invEq e y)) y (secEq e y)

    left : (x : Flat _) → flat-map (invEq e) (flat-map (equivFun e) x) ≡ x
    left (box x) = box-path (invEq e (equivFun e x)) x (retEq e x)

  flat-preserves-isEquiv : {@♭ A B : Type ℓ} (@♭ f : A → B)
    → (@♭ equivalence : isEquiv f) → isEquiv (flat-map f)
  flat-preserves-isEquiv f equivalence = flat-equivalence (f , equivalence) .snd
