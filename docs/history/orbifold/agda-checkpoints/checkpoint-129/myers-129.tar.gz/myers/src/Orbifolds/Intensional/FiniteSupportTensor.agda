{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportTensor where

-- The coordinate object is identified with a tensor product by proving
-- its universal property for actual bilinear maps. Its first factor is
-- the constructed free module. A basis of a general scalar parameter
-- and a geometric interpretation are separate, visible requirements.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.CompactSeparation using (inl; inr)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( FiniteSupport; finite-support-path; map-finite-support )
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid)
open import Orbifolds.Intensional.FiniteSupportUniversal using (additive-zero; additive-add)
open import Orbifolds.Intensional.FiniteSupportModules

private variable ℓ : Level

module FreeModule {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) (R : CommutativeSemiring ℓ) where

  private module R = CommutativeSemiring R
  module C = Coordinates ext classical equality (regular-module R)

  Free : Semimodule R
  Free = C.coordinate-module

  generator : I → Semimodule.Carrier Free
  generator i = C.S.single i R.one

  single-from-generator : (i : I) (r : R.Carrier)
    → C.S.single i r ≡ C.scale r (generator i)
  single-from-generator i r = cong (C.S.single i) (sym (R.*-one-right r))
    ∙ linear-scalar {M = regular-module R} {N = Free} (C.single-linear i) r R.one

  module Universal (N : Semimodule R) where

    private module N = Semimodule N
    module LS = LinearDirectSum ext classical equality (regular-module R) N

    scalar-linear : N.Carrier → LinearMap (regular-module R) N
    scalar-linear v = (λ r → r N.• v) ,
      ((N.zero-• v , λ r s → N.add-• r s v) , λ r s → N.•-assoc r s v)

    restriction : LinearMap Free N → I → N.Carrier
    restriction h i = fst h (generator i)

    extension : (I → N.Carrier) → LinearMap Free N
    extension values = LS.extension (λ i → scalar-linear (values i))

    extension-on-single : (values : I → N.Carrier) (i : I) (r : R.Carrier)
      → fst (extension values) (C.S.single i r) ≡ r N.• values i
    extension-on-single values = LS.extension-on-single (λ i → scalar-linear (values i))

    extension-on-generator : (values : I → N.Carrier) (i : I)
      → fst (extension values) (generator i) ≡ values i
    extension-on-generator values i = extension-on-single values i R.one ∙ N.•-one (values i)

    linear-on-single : (h : LinearMap Free N) (i : I) (r : R.Carrier)
      → fst h (C.S.single i r) ≡ r N.• fst h (generator i)
    linear-on-single h i r = cong (fst h) (single-from-generator i r)
      ∙ linear-scalar {M = Free} {N = N} h r (generator i)

    free-module-universal : Equiv (LinearMap Free N) (I → N.Carrier)
    free-module-universal = equiv restriction extension
      (λ values → ext (extension-on-generator values))
      (λ h → LS.linear-determined-on-singles (extension (restriction h)) h
        (λ i r → extension-on-single (restriction h) i r ∙ sym (linear-on-single h i r)))

    linear-determined-on-generators : (h k : LinearMap Free N)
      → ((i : I) → fst h (generator i) ≡ fst k (generator i)) → h ≡ k
    linear-determined-on-generators h k same =
      LS.linear-determined-on-singles h k (λ i r →
        linear-on-single h i r
        ∙ cong (λ v → r N.• v) (same i)
        ∙ sym (linear-on-single k i r))

IsBilinear : {R : CommutativeSemiring ℓ} (L M N : Semimodule R)
  → (Semimodule.Carrier L → Semimodule.Carrier M → Semimodule.Carrier N) → Set ℓ
IsBilinear L M N f =
  Σ ((v : Semimodule.Carrier M) → IsLinear L N (λ u → f u v)) λ _ →
    (u : Semimodule.Carrier L) → IsLinear M N (f u)

BilinearMap : {R : CommutativeSemiring ℓ} (L M N : Semimodule R) → Set ℓ
BilinearMap L M N =
  Σ (Semimodule.Carrier L → Semimodule.Carrier M → Semimodule.Carrier N) (IsBilinear L M N)

bilinear-left : {R : CommutativeSemiring ℓ} {L M N : Semimodule R}
  → BilinearMap L M N → Semimodule.Carrier M → LinearMap L N
bilinear-left b v = (λ u → fst b u v) , fst (snd b) v

bilinear-right : {R : CommutativeSemiring ℓ} {L M N : Semimodule R}
  → BilinearMap L M N → Semimodule.Carrier L → LinearMap M N
bilinear-right b u = fst b u , snd (snd b) u

bilinear-prop : (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
  → (L M N : Semimodule R)
  → (f : Semimodule.Carrier L → Semimodule.Carrier M → Semimodule.Carrier N)
  → isProp (IsBilinear L M N f)
bilinear-prop ext L M N f =
  isPropΣ (isPropΠ ext (λ v → linear-prop ext L N (λ u → f u v)))
    (λ _ → isPropΠ ext (λ u → linear-prop ext M N (f u)))

bilinear-path : (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ} {L M N : Semimodule R}
  → {b c : BilinearMap L M N} → fst b ≡ fst c → b ≡ c
bilinear-path ext {L = L} {M = M} {N = N} = Σ-path-prop (bilinear-prop ext L M N)

module Tensor {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (M : Semimodule R) where

  private module R = CommutativeSemiring R
  private module M = Semimodule M
  module F = FreeModule ext classical equality R
  module C = Coordinates ext classical equality M

  TensorModule : Semimodule R
  TensorModule = C.coordinate-module

  pure : Semimodule.Carrier F.Free → M.Carrier → Semimodule.Carrier TensorModule
  pure a v = map-finite-support (λ r → r M.• v) (M.zero-• v) a

  pure-left : (v : M.Carrier) → LinearMap F.Free TensorModule
  pure-left v = (λ a → pure a v) ,
    ((finite-support-path ext (ext (λ i → M.zero-• v)) ,
      (λ a b → finite-support-path ext (ext (λ i → M.add-• (fst a i) (fst b i) v)))) ,
      (λ r a → finite-support-path ext (ext (λ i → M.•-assoc r (fst a i) v))))

  pure-right : (a : Semimodule.Carrier F.Free) → LinearMap M TensorModule
  pure-right a = pure a ,
    ((finite-support-path ext (ext (λ i → M.•-zero (fst a i))) ,
      (λ v w → finite-support-path ext (ext (λ i → M.•-add (fst a i) v w)))) ,
      (λ r v → finite-support-path ext (ext (λ i →
        sym (M.•-assoc (fst a i) r v)
        ∙ cong (λ s → s M.• v) (R.*-comm (fst a i) r)
        ∙ M.•-assoc r (fst a i) v))))

  pure-bilinear : BilinearMap F.Free M TensorModule
  pure-bilinear = pure , ((λ v → snd (pure-left v)) , λ a → snd (pure-right a))

  pure-single-coordinate : (i : I) (r : R.Carrier) (v : M.Carrier) (j : I)
    → (F.C.S.delta i r j) M.• v ≡ C.S.delta i (r M.• v) j
  pure-single-coordinate i r v j with equality j i
  ... | inl equal = refl
  ... | inr different = M.zero-• v

  pure-single : (i : I) (r : R.Carrier) (v : M.Carrier)
    → pure (F.C.S.single i r) v ≡ C.S.single i (r M.• v)
  pure-single i r v = finite-support-path ext (ext (pure-single-coordinate i r v))

  pure-generator : (i : I) (v : M.Carrier)
    → pure (F.generator i) v ≡ C.S.single i v
  pure-generator i v = pure-single i R.one v ∙ cong (C.S.single i) (M.•-one v)

  module Universal (N : Semimodule R) where

    module LS = LinearDirectSum ext classical equality M N
    module FN = F.Universal N

    restriction : LinearMap TensorModule N → BilinearMap F.Free M N
    restriction h = (λ a v → fst h (pure a v)) ,
      ((λ v → snd (compose-linear {M = F.Free} {N = TensorModule} {P = N} h (pure-left v))) ,
        (λ a → snd (compose-linear {M = M} {N = TensorModule} {P = N} h (pure-right a))))

    extension : BilinearMap F.Free M N → LinearMap TensorModule N
    extension b = LS.extension (λ i → bilinear-right {L = F.Free} {M = M} {N = N} b (F.generator i))

    restriction-extension-generator : (b : BilinearMap F.Free M N) (v : M.Carrier) (i : I)
      → fst (restriction (extension b)) (F.generator i) v ≡ fst b (F.generator i) v
    restriction-extension-generator b v i =
      cong (fst (extension b)) (pure-generator i v)
      ∙ LS.extension-on-single
        (λ j → bilinear-right {L = F.Free} {M = M} {N = N} b (F.generator j)) i v

    restriction-extension : (b : BilinearMap F.Free M N) → restriction (extension b) ≡ b
    restriction-extension b = bilinear-path ext {L = F.Free} {M = M} {N = N}
      {b = restriction (extension b)} {c = b} (ext (λ a → ext (λ v →
      cong (λ h → fst h a)
        (FN.linear-determined-on-generators
          (bilinear-left {L = F.Free} {M = M} {N = N} (restriction (extension b)) v)
          (bilinear-left {L = F.Free} {M = M} {N = N} b v)
          (restriction-extension-generator b v)))))

    extension-restriction : (h : LinearMap TensorModule N) → extension (restriction h) ≡ h
    extension-restriction h = LS.linear-determined-on-singles (extension (restriction h)) h
      (λ i v → LS.extension-on-single
        (λ j → bilinear-right {L = F.Free} {M = M} {N = N} (restriction h) (F.generator j)) i v
        ∙ cong (fst h) (pure-generator i v))

    tensor-universal : Equiv (LinearMap TensorModule N) (BilinearMap F.Free M N)
    tensor-universal = equiv restriction extension restriction-extension extension-restriction

module TensorMap {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (M N : Semimodule R) (f : LinearMap M N) where

  module TM = Tensor ext classical equality M
  module TN = Tensor ext classical equality N

  tensor-map : LinearMap TM.TensorModule TN.TensorModule
  tensor-map = map-finite-support (fst f) (linear-zero {M = M} {N = N} f) ,
    ((finite-support-path ext (ext (λ i → linear-zero {M = M} {N = N} f)) ,
      (λ u v → finite-support-path ext (ext (λ i → linear-add {M = M} {N = N} f (fst u i) (fst v i))))) ,
      (λ r u → finite-support-path ext (ext (λ i → linear-scalar {M = M} {N = N} f r (fst u i)))))

  tensor-map-on-pure : (a : Semimodule.Carrier TM.F.Free) (v : Semimodule.Carrier M)
    → fst tensor-map (TM.pure a v) ≡ TN.pure a (fst f v)
  tensor-map-on-pure a v = finite-support-path ext
    (ext (λ i → linear-scalar {M = M} {N = N} f (fst a i) v))

  induced-bilinear : BilinearMap TM.F.Free M TN.TensorModule
  induced-bilinear = (λ a v → TN.pure a (fst f v)) ,
    ((λ v → snd (TN.pure-left (fst f v))) ,
      (λ a → snd (compose-linear {M = M} {N = N} {P = TN.TensorModule} (TN.pure-right a) f)))

  module U = TM.Universal TN.TensorModule

  tensor-map-is-induced : forward U.tensor-universal tensor-map ≡ induced-bilinear
  tensor-map-is-induced = bilinear-path ext {L = TM.F.Free} {M = M} {N = TN.TensorModule}
    {b = forward U.tensor-universal tensor-map} {c = induced-bilinear}
    (ext (λ a → ext (tensor-map-on-pure a)))
