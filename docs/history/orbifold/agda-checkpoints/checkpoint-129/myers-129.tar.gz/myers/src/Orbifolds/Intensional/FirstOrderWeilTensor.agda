{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FirstOrderWeilTensor where

-- A nontrivial specified algebra square, not an arbitrary square with
-- its extended comparison assumed: D(2) = D x_R D is proved in the
-- first-order algebra module. Here its actual tensor comparison and
-- both augmentation routes are obtained from the constructed tensor.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( Pullback; pullback-path; finite-support-path; finite-support-isSet )
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor
open import Orbifolds.Intensional.FiniteSupportScalarExtension
import Orbifolds.Intensional.FirstOrderWeilSquare as FirstOrder

module Construction {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) (R : CommutativeSemiring ℓ) where

  private module R = CommutativeSemiring R
  module W = FirstOrder.Construction R
  module S = TensorSquare ext classical equality
    W.D2.E-module W.D.E-module W.D.E-module (regular-module R)
    W.first-linear-map W.second-linear-map W.D.augmentation-linear W.D.augmentation-linear
    (λ z → refl)
  Parameter = FreeModule.Free ext classical equality R
  PlaneTensor = Tensor.TensorModule ext classical equality W.D2.E-module
  DualTensor = Tensor.TensorModule ext classical equality W.D.E-module
  ScalarTensor = Tensor.TensorModule ext classical equality (regular-module R)

  plane-pure = Tensor.pure ext classical equality W.D2.E-module
  dual-pure = Tensor.pure ext classical equality W.D.E-module

  extended-first = S.tensor-u
  extended-second = S.tensor-v
  extended-augmentation = S.tensor-f

  extended-plane-augmentation : LinearMap PlaneTensor ScalarTensor
  extended-plane-augmentation = TensorMap.tensor-map ext classical equality
    W.D2.E-module (regular-module R) W.D2.augmentation-linear

  first-on-pure = TensorMap.tensor-map-on-pure ext classical equality
    W.D2.E-module W.D.E-module W.first-linear-map
  second-on-pure = TensorMap.tensor-map-on-pure ext classical equality
    W.D2.E-module W.D.E-module W.second-linear-map
  augmentation-on-pure = TensorMap.tensor-map-on-pure ext classical equality
    W.D.E-module (regular-module R) W.D.augmentation-linear

  first-order-tensor-comparison = S.tensor-comparison

  first-order-tensor-comparison-isEquiv : isEquiv first-order-tensor-comparison
  first-order-tensor-comparison-isEquiv = S.tensor-comparison-isEquiv W.comparison-isEquiv

  pure-boundary : (a : Semimodule.Carrier Parameter) (z : W.D2.E)
    → Pullback (fst extended-augmentation) (fst extended-augmentation)
  pure-boundary a z = dual-pure a (W.first z) ,
    (dual-pure a (W.second z) ,
      augmentation-on-pure a (W.second z) ∙ sym (augmentation-on-pure a (W.first z)))

  comparison-on-pure : (a : Semimodule.Carrier Parameter) (z : W.D2.E)
    → first-order-tensor-comparison (plane-pure a z) ≡ pure-boundary a z
  comparison-on-pure a z = pullback-path (finite-support-isSet ext R.carrier-set)
    (first-on-pure a z) (second-on-pure a z)

  first-augmentation-route : (u : Semimodule.Carrier PlaneTensor)
    → fst extended-augmentation (fst extended-first u) ≡ fst extended-plane-augmentation u
  first-augmentation-route u = finite-support-path ext
    {u = fst extended-augmentation (fst extended-first u)} {v = fst extended-plane-augmentation u} refl

  second-augmentation-route : (u : Semimodule.Carrier PlaneTensor)
    → fst extended-augmentation (fst extended-second u) ≡ fst extended-plane-augmentation u
  second-augmentation-route u = finite-support-path ext
    {u = fst extended-augmentation (fst extended-second u)} {v = fst extended-plane-augmentation u} refl

  module AtParameter (A : Semimodule R) where
    module WithBasis (basis : BasedExtension.Basis ext classical equality A) where

      plane-augmentation : LinearMap PlaneTensor A
      plane-augmentation = BasedExtension.WithBasis.Augmentation.augmented-extension
        ext classical equality A basis W.D2.E-module W.D2.augmentation-linear

      dual-augmentation : LinearMap DualTensor A
      dual-augmentation = BasedExtension.WithBasis.Augmentation.augmented-extension
        ext classical equality A basis W.D.E-module W.D.augmentation-linear

      parameter-first-route : (u : Semimodule.Carrier PlaneTensor)
        → fst dual-augmentation (fst extended-first u) ≡ fst plane-augmentation u
      parameter-first-route = BasedExtension.WithBasis.AugmentedMap.extension-respects-augmentation
        ext classical equality A basis W.D2.E-module W.D.E-module W.first-linear-map
        W.D2.augmentation-linear W.D.augmentation-linear W.first-augmentation

      parameter-second-route : (u : Semimodule.Carrier PlaneTensor)
        → fst dual-augmentation (fst extended-second u) ≡ fst plane-augmentation u
      parameter-second-route = BasedExtension.WithBasis.AugmentedMap.extension-respects-augmentation
        ext classical equality A basis W.D2.E-module W.D.E-module W.second-linear-map
        W.D2.augmentation-linear W.D.augmentation-linear W.second-augmentation
