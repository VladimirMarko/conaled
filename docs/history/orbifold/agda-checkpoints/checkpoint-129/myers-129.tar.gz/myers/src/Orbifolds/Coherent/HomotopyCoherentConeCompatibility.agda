{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentConeCompatibility where

open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face; StrictCubicalExtensionality)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken; in-prefix; in-suffix;
  prefix-prefix; prefix-suffix; suffix-prefix; suffix-suffix)
import Orbifolds.Coherent.CoherentArrowSplits as AS
import Orbifolds.Coherent.CoherentConeChains as CC
open import Orbifolds.Coherent.CoherentCubeTensors using (cast-cube)
import Orbifolds.Coherent.CoherentCubeTensors as CT
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.HomotopyCoherentActionData using (_≤ᵈ_; same; lower; transitive; successor-bound; prefix-bound; LawPair)
import Orbifolds.Coherent.HomotopyCoherentConeData as CD
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Compatible; low; high; star)

module Compatibility {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  module D = HC.ForCategory.Diagram D
  open D using (Value; action)
  open Chains C
  open CC.Splits C
  open CT.Tensor E
  open CD.Data C D

  arrow-cast : {k m : Dim} (e : k ≡ˢ m) {x y : Obj} (c : Arrow.Chain k x y) (a : Value x)
    → outer (cast-cube e (action k c a)) ≡ˢ outer (action m (ArrowCast.cast-chain e c) a)
  arrow-cast reflˢ c a = reflˢ

  arrow-uncast : {k m : Dim} (e : k ≡ˢ m) {x y : Obj} (c : Arrow.Chain k x y) (a : Value x)
    → outer (action k c a) ≡ˢ outer (cast-cube (strict-sym e) (action m (ArrowCast.cast-chain e c) a))
  arrow-uncast reflˢ c a = reflˢ

  cone-cast : {k m n : Dim} {P : Type ℓ} (e : k ≡ˢ m) (b : k ≤ᵈ n) (b' : m ≤ᵈ n)
    (F : Families n P) (s : P) (y : Obj) (c : Chain k y)
    → outer (cast-cube e (at b F s y c)) ≡ˢ outer (at b' F s y (cast-chain e c))
  cone-cast reflˢ b b' F s y c = strict-cong (λ f → outer (inner f s y c))
    (lookup-irrelevance b b' F)

  cone-uncast : {k m n : Dim} {P : Type ℓ} (e : k ≡ˢ m) (b : k ≤ᵈ n) (b' : m ≤ᵈ n)
    (F : Families n P) (s : P) (y : Obj) (c : Chain k y)
    → outer (at b F s y c) ≡ˢ outer (cast-cube (strict-sym e) (at b' F s y (cast-chain e c)))
  cone-uncast reflˢ b b' F s y c = strict-cong (λ f → outer (inner f s y c))
    (lookup-irrelevance b b' F)

  evaluate-split : (n : Dim) {P : Type ℓ} (F : Families n P) (p : Position (osuc n)) {y : Obj}
    → Split n p y → P → Cube n (Value y)
  evaluate-split n F p z s = tensor-action n p
    (action (suffix-degree n p) (z .snd .fst))
    (λ s → at (prefix-bound n p) F s (z .fst) (z .snd .snd)) s

  suffix-zero : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y) (s : P)
    → outer (coordinate-face n p i0 (one-face (osuc n) F s (psuc q) c))
      ≡ˢ outer (one-face n (F .fst) s q (face (osuc n) (weaken p) c))
  suffix-zero n F p q le c s = strict-trans
    (tensor-face-suffix n p q le i0
      (action (suffix-degree (osuc n) (psuc q)) (split-suffix (osuc n) (psuc q) c))
      (λ s → at (prefix-bound (osuc n) (psuc q)) F s
        (split-vertex (osuc n) (psuc q) c) (split-prefix (osuc n) (psuc q) c)) s)
    (strict-trans
      (tensor-pointwise n q _ _ _ _
        (λ b → D.zero-face (suffix-degree n q) (in-suffix n p q le)
          (split-suffix (osuc n) (psuc q) c) b)
        (λ s → reflˢ) s)
      (strict-sym (strict-cong
        (λ z → outer (evaluate-split n (F .fst) q (inner z) s))
        (cut-face-suffix n p q le c))))

  prefix-zero : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y) (s : P)
    → outer (coordinate-face n q i0 (one-face (osuc n) F s (weaken p) c))
      ≡ˢ outer (one-face n (F .fst) s p (face (osuc n) (psuc q) c))
  prefix-zero n F coherent p q le c s = strict-trans
    (tensor-face-prefix n p q le i0
      (action (suffix-degree (osuc n) (weaken p)) (split-suffix (osuc n) (weaken p) c))
      (λ s → at (prefix-bound (osuc n) (weaken p)) F s
        (split-vertex (osuc n) (weaken p) c) (split-prefix (osuc n) (weaken p) c)) s)
    (strict-trans
      (tensor-pointwise n p _ _ _ _
        (λ b → arrow-cast (suffix-weaken n p) (split-suffix (osuc n) (weaken p) c) b)
        (λ s → strict-trans
          (strict-cong (λ z → outer (coordinate-face (prefix-degree n p) (in-prefix n p q le) i0 (inner z)))
            (cone-cast (prefix-weaken n p)
              (prefix-bound (osuc n) (weaken p)) (successor-bound (prefix-bound n p)) F s
              (split-vertex (osuc n) (weaken p) c) (split-prefix (osuc n) (weaken p) c)))
          (strict-trans
            (law-at-zero (successor-bound (prefix-bound n p)) F coherent s
              (normalized n p c .fst) (normalized n p c .snd .snd) (in-prefix n p q le))
            (strict-cong (λ f → outer (inner f s (normalized n p c .fst)
              (face (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd))))
              (lookup-irrelevance
                (transitive (lower same) (successor-bound (prefix-bound n p)))
                (lower (prefix-bound n p)) F)))) s)
      (strict-sym (strict-cong
        (λ z → outer (evaluate-split n (F .fst) p (inner z) s))
        (cut-face-prefix n p q le c))))

  evaluate-triple-prefix : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    → Triple n p q le y → P → Cube n (Value y)
  evaluate-triple-prefix n F p q le z s = tensor-prefix-first n p q le
    (action (suffix-degree n p) (z .snd .snd .fst))
    (action _ (z .snd .snd .snd .fst))
    (λ s → at (lower (prefix-bound n q)) F s (z .snd .fst) (z .snd .snd .snd .snd)) s

  evaluate-triple-suffix : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    → Triple n p q le y → P → Cube n (Value y)
  evaluate-triple-suffix n F p q le z s = tensor-suffix-first n p q le
    (action (suffix-degree n p) (z .snd .snd .fst))
    (action _ (z .snd .snd .snd .fst))
    (λ s → at (lower (prefix-bound n q)) F s (z .snd .fst) (z .snd .snd .snd .snd)) s

  prefix-one : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P) → Coherent (osuc n) F
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y) (s : P)
    → outer (coordinate-face n q i1 (one-face (osuc n) F s (weaken p) c))
      ≡ˢ outer (evaluate-triple-prefix n F p q le (triple n p q le c) s)
  prefix-one n F coherent p q le c s = strict-trans
    (tensor-face-prefix n p q le i1
      (action (suffix-degree (osuc n) (weaken p)) (split-suffix (osuc n) (weaken p) c))
      (λ s → at (prefix-bound (osuc n) (weaken p)) F s
        (split-vertex (osuc n) (weaken p) c) (split-prefix (osuc n) (weaken p) c)) s)
    (strict-trans
      (tensor-pointwise n p _ _ _ _
        (λ b → arrow-cast (suffix-weaken n p) (split-suffix (osuc n) (weaken p) c) b)
        (λ s → strict-trans
          (strict-cong (λ z → outer (coordinate-face (prefix-degree n p) (in-prefix n p q le) i1 (inner z)))
            (cone-cast (prefix-weaken n p)
              (prefix-bound (osuc n) (weaken p)) (successor-bound (prefix-bound n p)) F s
              (split-vertex (osuc n) (weaken p) c) (split-prefix (osuc n) (weaken p) c)))
          (strict-trans
            (law-at-one (successor-bound (prefix-bound n p)) F coherent s
              (normalized n p c .fst) (normalized n p c .snd .snd) (in-prefix n p q le))
            (tensor-pointwise (prefix-degree n p) (in-prefix n p q le) _ _ _ _
              (λ b → arrow-uncast (prefix-suffix n p q le)
                (split-suffix (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd)) b)
              (λ s → cone-uncast (prefix-prefix n p q le)
                (transitive (lower (prefix-bound (prefix-degree n p) (in-prefix n p q le)))
                  (successor-bound (prefix-bound n p)))
                (lower (prefix-bound n q)) F s
                (split-vertex (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd))
                (split-prefix (prefix-degree n p) (in-prefix n p q le) (normalized n p c .snd .snd))) s))) s)
      (strict-cong (λ z → outer (evaluate-triple-prefix n F p q le (inner z) s))
        (prefix-triple n p q le c)))

  suffix-one : (n : Dim) {P : Type ℓ} (F : Families (osuc n) P)
    → (p q : Position (osuc n)) (le : p ≤ᵖ q) {y : Obj}
    (c : Chain (osuc (osuc n)) y) (s : P)
    → outer (coordinate-face n p i1 (one-face (osuc n) F s (psuc q) c))
      ≡ˢ outer (evaluate-triple-suffix n F p q le (triple n p q le c) s)
  suffix-one n F p q le c s = strict-trans
    (tensor-face-suffix n p q le i1
      (action (suffix-degree (osuc n) (psuc q)) (split-suffix (osuc n) (psuc q) c))
      (λ s → at (prefix-bound (osuc n) (psuc q)) F s
        (split-vertex (osuc n) (psuc q) c) (split-prefix (osuc n) (psuc q) c)) s)
    (strict-trans
      (tensor-pointwise n q _ _ _ _
        (λ b → strict-trans
          (D.one-face (suffix-degree n q) (in-suffix n p q le) (split-suffix (osuc n) (psuc q) c) b)
          (tensor-pointwise (suffix-degree n q) (in-suffix n p q le) _ _ _ _
            (λ d → arrow-uncast (suffix-suffix n p q le)
              (Arrow.split-suffix (suffix-degree n q) (in-suffix n p q le)
                (split-suffix (osuc n) (psuc q) c)) d)
            (λ b → arrow-uncast (suffix-prefix n p q le)
              (Arrow.split-prefix (suffix-degree n q) (in-suffix n p q le)
                (split-suffix (osuc n) (psuc q) c)) b) b))
        (λ s → reflˢ) s)
      (strict-cong (λ z → outer (evaluate-triple-suffix n F p q le (inner z) s))
        (suffix-triple-correct n p q le c)))

  bar-compatible : (n : Dim) {P : Type ℓ} (F : Families n P) → Coherent n F
    → (s : P) {y : Obj} (c : Chain (osuc n) y) → Compatible (osuc n) (bar-faces n F s c)
  bar-compatible ozero F coherent s c = star
  bar-compatible (osuc n) F coherent s c p q le low low = strict-trans
    (LayerLaws.zero-face (LawPair.current coherent) s _ (face (osuc n) (psuc q) c) p)
    (strict-trans
      (strict-cong (λ z → outer (top n (F .fst) s _ (inner z))) (face-face n p q le c))
      (strict-sym (LayerLaws.zero-face (LawPair.current coherent) s _
        (face (osuc n) (weaken p) c) q)))
  bar-compatible (osuc n) F coherent s c p q le low high = strict-trans
    (suffix-zero n F p q le c s)
    (strict-sym (LayerLaws.one-face-law (LawPair.current coherent) s _
      (face (osuc n) (weaken p) c) q))
  bar-compatible (osuc n) F coherent s c p q le high low = strict-trans
    (LayerLaws.one-face-law (LawPair.current coherent) s _ (face (osuc n) (psuc q) c) p)
    (strict-sym (prefix-zero n F coherent p q le c s))
  bar-compatible (osuc n) F coherent s c p q le high high = strict-trans
    (suffix-one n F p q le c s)
    (strict-trans
      (strict-sym (tensor-associativity n p q le
        (action (suffix-degree n p) (triple n p q le c .snd .snd .fst))
        (action _ (triple n p q le c .snd .snd .snd .fst))
        (λ s → at (lower (prefix-bound n q)) F s (triple n p q le c .snd .fst)
          (triple n p q le c .snd .snd .snd .snd)) s))
      (strict-sym (prefix-one n F coherent p q le c s)))
