{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictNullCubicalExtensions where

-- Actual all-dimensional nullification extension with constant unit
-- computations. Its boundary is an explicitly given inner shell family;
-- the unit comparison is a finite boundary lemma used to construct the
-- base filler, not a preservation or global coherent-diagram premise.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; endpoint; Faces; Compatible; shell-face)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Cubical.HITs.Nullification.Base as NB
import Orbifolds.NullCubicalExtensions as NC
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
import Orbifolds.CubicalShellCurrying as CC

module Nullification {ℓ : Level} {Ix : Type₀} (S : Ix → Type ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module Null = NC.Nullification S
  module Filler = Fillers.Boundary E

  point-curry : (n : Dim) {X Y : Type ℓ} (f : X → Cube n Y) (x : X)
    → outer (map-cube n (λ h → h x) (CC.Curry.cube-curry X Y (toNat n) f))
      ≡ˢ outer (f x)
  point-curry ozero f x = reflˢ
  point-curry (osuc n) f x = interval-ext λ i → point-curry n (λ x → f x i) x

  module Extension (n : Dim) (X Y : Type ℓ) (nullY : NB.isNull S Y)
      (boundary : NB.Null S X → CS.Shell (toNat n) Y)
      (unit-value : X → Y)
      (boundary-at-unit : (x : X)
        → outer (boundary (NB.∣ x ∣))
          ≡ˢ outer (CS.restriction (toNat n) (CS.constant-cube (toNat n) (unit-value x)))) where

    base : (x : X) → CF.Filler (toNat n) (boundary (NB.∣ x ∣))
    base x = cast-filler n (strict-sym (boundary-at-unit x))
      (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) (unit-value x)))

    module ExtensionSpace = Null.Cubical X Y nullY (toNat n) boundary

    filler : (a : NB.Null S X) → CF.Filler (toNat n) (boundary a)
    filler = ExtensionSpace.extend base

    filler-unit : (x : X) → outer (filler (NB.∣ x ∣)) ≡ˢ outer (base x)
    filler-unit x = reflˢ

    cube : NB.Null S X → Cube n Y
    cube a = CF.forget-filler (toNat n) (boundary a) (filler a)

    cube-boundary : (a : NB.Null S X)
      → outer (CS.restriction (toNat n) (cube a)) ≡ˢ outer (boundary a)
    cube-boundary a = Filler.forget-boundary-strict n (boundary a) (filler a)

    cube-unit : (x : X)
      → outer (cube (NB.∣ x ∣)) ≡ˢ outer (CS.constant-cube (toNat n) (unit-value x))
    cube-unit x = strict-trans
      (cast-forget n (strict-sym (boundary-at-unit x))
        (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) (unit-value x))))
      (Filler.forget-canonical-strict n (CS.constant-cube (toNat n) (unit-value x)))

    curried-cube : Cube n (NB.Null S X → Y)
    curried-cube = CC.Curry.cube-curry (NB.Null S X) Y (toNat n) cube

    curried-unit : (x : X)
      → outer (map-cube n (λ h → h (NB.∣ x ∣)) curried-cube)
        ≡ˢ outer (CS.constant-cube (toNat n) (unit-value x))
    curried-unit x = strict-trans (point-curry n cube (NB.∣ x ∣)) (cube-unit x)

    extensions-contractible : isContr (ExtensionSpace.extension-space base)
    extensions-contractible = ExtensionSpace.extensions-contractible base

  -- The comparison at the unit can itself be derived from actual faces
  -- and their agreements with the constant cube, using the checked
  -- finite shell assembler.
  module Assembled (n : Dim) (X Y : Type ℓ) (nullY : NB.isNull S Y)
      (faces : (a : NB.Null S X) → Faces (osuc n) Y)
      (compatible : (a : NB.Null S X) → Compatible (osuc n) (faces a))
      (unit-value : X → Y)
      (unit-faces : (x : X) (p : Position (osuc n)) (e : Endpoint)
        → outer (faces (NB.∣ x ∣) p e)
          ≡ˢ outer (coordinate-face n p (endpoint e)
            (CS.constant-cube (toNat (osuc n)) (unit-value x)))) where

    boundary : NB.Null S X → CS.Shell (toNat (osuc n)) Y
    boundary a = Assembly.Construction.assemble E (osuc n) (faces a) (compatible a)

    boundary-at-unit : (x : X)
      → outer (boundary (NB.∣ x ∣))
        ≡ˢ outer (CS.restriction (toNat (osuc n))
          (CS.constant-cube (toNat (osuc n)) (unit-value x)))
    boundary-at-unit x = Assembly.Construction.assemble-restriction E (osuc n)
      (faces (NB.∣ x ∣)) (compatible (NB.∣ x ∣))
      (CS.constant-cube (toNat (osuc n)) (unit-value x)) (unit-faces x)

    module Extended = Extension (osuc n) X Y nullY boundary unit-value boundary-at-unit
    open Extended using (base; filler; filler-unit; cube; cube-boundary; cube-unit;
      curried-cube; curried-unit; extensions-contractible) public

    cube-face : (a : NB.Null S X) (p : Position (osuc n)) (e : Endpoint)
      → outer (coordinate-face n p (endpoint e) (cube a)) ≡ˢ outer (faces a p e)
    cube-face a p e = Filler.assembled-filler-face n (faces a) (compatible a) (filler a) p e
