{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteRestrictionFillers where

-- Literal computation of the newest filler under finite restriction.
-- The boundary cast is exactly the previously proved naturality path,
-- so applications need not unfold the recursive stage-map machinery.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
import Orbifolds.Coherent.StrictCubicalFillerMaps as Direct
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.CubicalShellFillers as CF

module Computation {ℓ : Level} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module D = HC.ForCategory.Diagram D using (Value)
  module G = HC.ForCategory.Diagram G using (Value)
  module α = Transformations.ForCategory.Transformation α using (component)
  module R = Restriction.Restriction C D G α E F
    using (Cells; finite-restriction; source-boundary; target-boundary; source-boundary-natural)

  filler : (Y : Type ℓ) (n : Dim)
    (s : Cocones.Functoriality.Cocone C G E F Y (osuc n)) (c : R.Cells n)
    → CF.Filler (toNat (osuc n))
        (R.target-boundary Y n (R.finite-restriction Y n (s .fst)) c)
  filler Y n s c = R.finite-restriction Y (osuc n) s .snd c

  filler-construction : (Y : Type ℓ) (n : Dim)
    (s : Cocones.Functoriality.Cocone C G E F Y (osuc n)) (c : R.Cells n)
    → outer {A = CF.Filler (toNat (osuc n))
        (R.target-boundary Y n (R.finite-restriction Y n (s .fst)) c)}
        (filler Y n s c)
      ≡ˢ outer {A = CF.Filler (toNat (osuc n))
        (R.target-boundary Y n (R.finite-restriction Y n (s .fst)) c)}
        (R.finite-restriction Y (osuc n) s .snd c)
  filler-construction Y n s c = reflˢ

  filler-computation : (Y : Type ℓ) (n : Dim)
    (s : Cocones.Functoriality.Cocone C G E F Y (osuc n)) (c : R.Cells n)
    → outer {A = CF.Filler (toNat (osuc n))
        (R.target-boundary Y n (R.finite-restriction Y n (s .fst)) c)}
        (filler Y n s c)
      ≡ˢ outer {A = CF.Filler (toNat (osuc n))
        (R.target-boundary Y n (R.finite-restriction Y n (s .fst)) c)}
        (cast-filler (osuc n) {X = D.Value (c .fst) → Y}
          (R.source-boundary-natural Y n (s .fst) c)
          (Direct.Action.map-filler E (osuc n)
            {X = G.Value (c .fst) → Y} {Y = D.Value (c .fst) → Y}
            (λ h → h ∘ α.component (c .fst))
            (R.source-boundary Y n (s .fst) c) (s .snd c)))
  filler-computation Y n s (y , c) = reflˢ
