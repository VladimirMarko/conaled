{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyNullHomotopyCoherentColimits where

-- The actual nullification comparison for the fully constructed coherent
-- bar colimit. Nullity comes from its sphere-cell presentation; mapping
-- universality comes from actual restriction along the constructed unit.
-- Neither colimit preservation nor a cocone equivalence is an input.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as PP
import Orbifolds.TinyTypes as TT
import Orbifolds.NullificationComparisonInterface as Universal
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentNullification as Reflection
import Orbifolds.Coherent.HomotopyCoherentColimitCells as BarCells
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as Maps
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitNaturality as Naturality
import Orbifolds.Coherent.NullCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.TinyNullHomotopyCoherentColimitNullity as Nullity

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ Ix : Type₀) (@♭ S : Ix → Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C)
    (@♭ E : StrictCubicalExtensionality ℓ) (@♭ F : StrictFunctionExtensionality ℓ) where
  open Category C
  module Diagram = HC.ForCategory.Diagram D using (Value)
  reflected : HC.ForCategory.Diagram C
  reflected = Reflection.Reflection.reflected C D S E

  unit-transformation : Transformations.ForCategory.Transformation C D reflected
  unit-transformation = Reflection.Reflection.unit-transformation C D S E

  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = PP.Context.RealFlat R r₀

  TinyFamily : Type (ℓ-suc ℓ)
  TinyFamily = (@♭ i : Ix) → TT.External.Tiny (S i)

  Source : Type ℓ
  Source = BarCells.Construction.Colimit C D E F

  Target : Type ℓ
  Target = BarCells.Construction.Colimit C (Reflection.Reflection.reflected C D S E) E F

  unit-colimit-map : Source → Target
  unit-colimit-map = Maps.Map.induced C D
    (Reflection.Reflection.reflected C D S E)
    (Reflection.Reflection.unit-transformation C D S E) E F

  restriction-into-null : (Y : Type ℓ) → NB.isNull S Y
    → isEquiv {A = Target → Y} {B = Source → Y}
      (λ (k : Target → Y) → k ∘ unit-colimit-map)
  restriction-into-null Y null-Y =
    Naturality.Naturality.precomposition-isEquiv C D
      (Reflection.Reflection.reflected C D S E)
      (Reflection.Reflection.unit-transformation C D S E) E F Y
    (Restriction.UnitRestriction.restrict-isEquiv C D S E F Y null-Y)

  module Proof (real-flat : RealFlat) (discrete-generators : CrisplyDiscrete Ix)
      (tiny : TinyFamily) (discrete-objects : CrisplyDiscrete Obj)
      (discrete-homs : (@♭ x y : Obj) → CrisplyDiscrete (Hom x y)) where

    colimit-null : NB.isNull S Target
    colimit-null = Nullity.Context.Proof.colimit-null
      identity-rules flat-induction flat-computation
      identity-zero flat-zero flat-zero-computation R r₀ Ix S C D E F
      real-flat discrete-generators tiny discrete-objects discrete-homs

    module Identification = Universal.Comparison S Source Target unit-colimit-map colimit-null
      (restriction-into-null (NB.Null S Source) (NB.isNull-Null S))
      (restriction-into-null Target colimit-null)
      using (forward; backward; unit-triangle; backward-unit;
        right-inverse; left-inverse; comparison-isEquiv; equivalence)

    comparison : Target → NB.Null S Source
    comparison = Identification.forward

    comparison-isEquiv : isEquiv {A = Target} {B = NB.Null S Source} comparison
    comparison-isEquiv = Identification.comparison-isEquiv

    comparison-equivalence : Target ≃ NB.Null S Source
    comparison-equivalence = Identification.equivalence

    unit-triangle : PathP (λ _ → Source → NB.Null S Source)
      (comparison ∘ unit-colimit-map) NB.∣_∣
    unit-triangle = Identification.unit-triangle

    inverse : NB.Null S Source → Target
    inverse = Identification.backward

    comparison-inverse : (a : NB.Null S Source)
      → PathP (λ _ → NB.Null S Source) (comparison (inverse a)) a
    comparison-inverse = Identification.right-inverse

    inverse-comparison : (b : Target)
      → PathP (λ _ → Target) (inverse (comparison b)) b
    inverse-comparison = Identification.left-inverse

    inverse-unit : (a : Source)
      → PathP (λ _ → Target) (inverse NB.∣ a ∣) (unit-colimit-map a)
    inverse-unit = Identification.backward-unit

    source-generator : (x : Obj) → Diagram.Value x → Source
    source-generator = Maps.Map.source-generator C D reflected unit-transformation E F

    target-generator : (x : Obj) → NB.Null S (Diagram.Value x) → Target
    target-generator = Maps.Map.target-generator C D reflected unit-transformation E F

    generator-unit-computation : (x : Obj) (a : Diagram.Value x)
      → PathP (λ _ → NB.Null S Source)
        (comparison (target-generator x NB.∣ a ∣)) NB.∣ source-generator x a ∣
    generator-unit-computation x a =
      cong comparison (sym (Maps.Map.generator-computation C D reflected unit-transformation E F x a))
      ∙ funExt⁻ unit-triangle (source-generator x a)

    generator-computation : (x : Obj) (a : NB.Null S (Diagram.Value x))
      → PathP (λ _ → NB.Null S Source)
        (comparison (target-generator x a))
        (NP.rec (NB.isNull-Null S) (NB.∣_∣ ∘ source-generator x) a)
    generator-computation x = NP.elim (λ _ → NP.isNull≡ (NB.isNull-Null S))
      (generator-unit-computation x)
