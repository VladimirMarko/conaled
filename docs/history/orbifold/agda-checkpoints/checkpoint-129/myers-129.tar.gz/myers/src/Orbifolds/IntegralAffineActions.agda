{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineActions where

-- Actual integer-coordinate linear and affine actions. The lattice is
-- an explicit universe lift of Z^n, and every coefficient uses the
-- canonical checked integer ring homomorphism.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Int using (ℤ)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom; compGroupHom)
import Orbifolds.GeneralLinearMatrices as GL
import Orbifolds.LiftedGroups as Lifted
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.Torsors as Torsors
import Orbifolds.SemidirectProducts as SD
import Orbifolds.SplitExtensionQuotients as SQ

module Coordinates {ℓ : Level} (R : CommRing ℓ) (n : ℕ) where
  open CommRingStr (R .snd)
  module Z = GL.Ring.Dimension ℤCommRing n
  module Real = GL.Ring.Dimension R n
  module Integer = IC.Ring R
  module IntegerHom = IsCommRingHom (Integer.ring-homomorphism .snd)
  module Change = GL.Map ℤCommRing R Integer.ring-homomorphism
  module Lattice = Lifted.LiftGroup Z.vector-group ℓ

  Vector = Real.Vector
  IntegerVector = Z.Vector
  LatticeGroup = Lattice.Lifted

  integer-vector : IntegerVector → Vector
  integer-vector z i = Integer.integer (z i)

  translate : Lattice.Carrier → Vector → Vector
  translate z x i = Integer.integer (lower z i) + x i

  translation-unit : (x : Vector) → translate Lattice.one x ≡ x
  translation-unit x = funExt λ i → +IdL (x i)

  translation-compose : (z w : Lattice.Carrier) (x : Vector)
    → translate (Lattice.multiply z w) x ≡ translate z (translate w x)
  translation-compose z w x = funExt λ i →
    cong (_+ x i) (IntegerHom.pres+ (lower z i) (lower w i))
    ∙ sym (+Assoc (Integer.integer (lower z i)) (Integer.integer (lower w i)) (x i))

  translation-laws : Torsors.Theory.IsAction LatticeGroup (Vector , translate)
  translation-laws = (isSetΠ λ _ → is-set) , translation-unit , translation-compose

  module Representation (H : Group ℓ)
    (ρ : GroupHom H Z.GeneralLinear) where
    module HS = GroupStr (H .snd)
    module Hom = IsGroupHom (ρ .snd)

    on-lattice : H .fst → Lattice.Carrier → Lattice.Carrier
    on-lattice h z = lift (Z.act (ρ .fst h) (lower z))

    on-lattice-hom : (h : H .fst)
      → IsGroupHom (LatticeGroup .snd) (on-lattice h) (LatticeGroup .snd)
    on-lattice-hom h = makeIsGroupHom λ z w →
      cong lift (IsGroupHom.pres· (Z.action-additive (ρ .fst h)) (lower z) (lower w))

    on-lattice-unit : (z : Lattice.Carrier) → on-lattice HS.1g z ≡ z
    on-lattice-unit z = cong lift
      (cong (λ M → Z.act M (lower z)) Hom.pres1 ∙ Z.action-unit (lower z))

    on-lattice-compose : (h k : H .fst) (z : Lattice.Carrier)
      → on-lattice (h HS.· k) z ≡ on-lattice h (on-lattice k z)
    on-lattice-compose h k z = cong lift
      (cong (λ M → Z.act M (lower z)) (Hom.pres· h k)
        ∙ Z.action-compose (ρ .fst h) (ρ .fst k) (lower z))

    lattice-automorphisms : SD.Construction.AutomorphismAction LatticeGroup H
    SD.Construction.AutomorphismAction.act lattice-automorphisms = on-lattice
    SD.Construction.AutomorphismAction.hom lattice-automorphisms = on-lattice-hom
    SD.Construction.AutomorphismAction.unit lattice-automorphisms = on-lattice-unit
    SD.Construction.AutomorphismAction.compose lattice-automorphisms = on-lattice-compose

    real-representation : GroupHom H Real.GeneralLinear
    real-representation = compGroupHom ρ (Change.group-homomorphism n)

    linear : H .fst → Vector → Vector
    linear h = Real.act (real-representation .fst h)

    linear-unit : (x : Vector) → linear HS.1g x ≡ x
    linear-unit x = cong (λ M → Real.act M x)
      (IsGroupHom.pres1 (real-representation .snd)) ∙ Real.action-unit x

    linear-compose : (h k : H .fst) (x : Vector)
      → linear (h HS.· k) x ≡ linear h (linear k x)
    linear-compose h k x = cong (λ M → Real.act M x)
      (IsGroupHom.pres· (real-representation .snd) h k)
      ∙ Real.action-compose (real-representation .fst h) (real-representation .fst k) x

    linear-laws : Torsors.Theory.IsAction H (Vector , linear)
    linear-laws = (isSetΠ λ _ → is-set) , linear-unit , linear-compose

    preserves-integer-vectors : (h : H .fst) (z : IntegerVector)
      → integer-vector (Z.act (ρ .fst h) z) ≡ linear h (integer-vector z)
    preserves-integer-vectors h z = Change.action (ρ .fst h .fst) z

    compatible : (h : H .fst) (z : Lattice.Carrier) (x : Vector)
      → linear h (translate z x) ≡ translate (on-lattice h z) (linear h x)
    compatible h z x =
      IsGroupHom.pres· (Real.action-additive (real-representation .fst h))
        (integer-vector (lower z)) x
      ∙ cong (λ (v : Vector) (i : FD.Fin n) → v i + linear h x i)
        (sym (preserves-integer-vectors h (lower z)))

    module Semidirect = SD.Construction.Given LatticeGroup H lattice-automorphisms
    module Combined = Semidirect.Compatible translate linear translation-laws linear-laws compatible

    AffineGroup : Group ℓ
    AffineGroup = Semidirect.Semidirect

    affine : AffineGroup .fst → Vector → Vector
    affine = Combined.combined-action

    affine-formula : (z : Lattice.Carrier) (h : H .fst) (x : Vector)
      → affine (z , h) x ≡ translate z (linear h x)
    affine-formula z h x = refl

    affine-multiplication : (z w : Lattice.Carrier) (h k : H .fst)
      → Semidirect.multiply (z , h) (w , k)
        ≡ (Lattice.multiply z (on-lattice h w) , h HS.· k)
    affine-multiplication z w h k = refl

    module Quotients = SQ.Construction.Compatible LatticeGroup H lattice-automorphisms
      translate linear translation-laws linear-laws compatible

    TranslationQuotient = Quotients.Normal.Quotient
    AffineQuotient = Quotients.F.Family.Quotient

    -- This is an actual constructed iterated quotient of R^n. Its
    -- identification with any separately defined smooth torus, and
    -- the crystallographic property, are separate geometric work.
    iterated-affine-quotient = Quotients.iterated-quotient≃semidirect-quotient
