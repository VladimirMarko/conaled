{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CommRingQuotientReflection where

-- Both directions of the actual quotient kernel and products killed in R/I².
-- The quotient is Cubical's set quotient with its constructed ring structure.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Ideal using (IdealsIn; module CommIdeal)
import Cubical.Algebra.CommRing.Ideal.Sum as IS
import Cubical.Algebra.CommRing.Quotient.Base as QB
import Orbifolds.CommRingHomArithmetic as HA

module Quotient {ℓ : Level} (R : CommRing ℓ) (I : IdealsIn R) where
  module A = CommRingStr (R .snd)
  module Ideals = CommIdeal R
  open Ideals using (_∈_)

  quotient : CommRing ℓ
  quotient = QB._/_ R I

  projection : CommRingHom R quotient
  projection = QB.quotientHom R I

  module Q = CommRingStr (quotient .snd)
  module Map = HA.Hom R quotient projection
  open IsCommRingHom (projection .snd)

  in-ideal→zero : (x : R .fst) → x ∈ I → projection .fst x ≡ Q.0r
  in-ideal→zero = QB.zeroOnIdeal I

  zero→in-ideal : (x : R .fst) → projection .fst x ≡ Q.0r → x ∈ I
  zero→in-ideal x equality = subst (λ P → (P .fst x) .fst) (QB.kernel≡I I) equality

  equals-one→difference-in-ideal : (x : R .fst) → projection .fst x ≡ Q.1r → A._-_ x A.1r ∈ I
  equals-one→difference-in-ideal x equality = zero→in-ideal (A._-_ x A.1r)
    (Map.map-difference x A.1r ∙ cong₂ Q._-_ equality pres1 ∙ Q.+InvR Q.1r)

module Square {ℓ : Level} (R : CommRing ℓ) (I : IdealsIn R) where
  module A = CommRingStr (R .snd)
  module Ideals = CommIdeal R
  open Ideals using (_∈_)
  module Product = IS.IdealSum R

  squared : IdealsIn R
  squared = Product._·i_ I I

  module Quot = Quotient R squared
  module Q = CommRingStr (Quot.quotient .snd)

  products-zero : (x y : R .fst) → x ∈ I → y ∈ I
    → Q._·_ (Quot.projection .fst x) (Quot.projection .fst y) ≡ Q.0r
  products-zero x y x-in y-in = sym (IsCommRingHom.pres· (Quot.projection .snd) x y)
    ∙ Quot.in-ideal→zero (A._·_ x y) (Product.prodInProd I I x y x-in y-in)
