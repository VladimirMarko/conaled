{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictHomotopyNaturality where

-- Pointwise forms of strict finite coherence, converted to actual
-- inner squares before any ordinary-natural infinite iteration.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched

cong-strict-path : ∀ {ℓ ℓ'} {A : Type ℓ} {B : Type ℓ'} (f : A → B)
  {x y : A} (p : outer x ≡ˢ outer y)
  → cong f (strict-to-path p)
    ≡ strict-to-path (strict-cong (λ z → outer (f (inner z))) p)
cong-strict-path f reflˢ = refl

strict-square-pointwise : ∀ {ℓ} {A B A' B' : Type ℓ} (dA : A' → A) (dB : B' → B)
  {f g : A → B} {f' g' : A' → B'}
  (p : outer f ≡ˢ outer g) (p' : outer f' ≡ˢ outer g')
  (left : (x : A') → outer (dB (f' x)) ≡ˢ outer (f (dA x)))
  (right : (x : A') → outer (dB (g' x)) ≡ˢ outer (g (dA x)))
  → (x : A')
    → PathP (λ i → dB (strict-to-path p' i x) ≡ strict-to-path p i (dA x))
        (strict-to-path (left x)) (strict-to-path (right x))
strict-square-pointwise dA dB reflˢ reflˢ left right x = strict-to-path
  (strict-cong (λ e → outer (strict-to-path e)) (strict-uip (left x) (right x)))
