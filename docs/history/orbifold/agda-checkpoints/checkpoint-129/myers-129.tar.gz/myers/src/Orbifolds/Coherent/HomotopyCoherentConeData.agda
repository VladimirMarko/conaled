{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentConeData where

-- Actual finite cone histories for a fully coherent diagram. Each high
-- face uses the entire suffix coherence cube, not merely a composite map.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face; StrictCubicalExtensionality)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentConeChains as CC
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.HomotopyCoherentActionData using (_≤ᵈ_; same; lower; transitive; prefix-bound; bound-irrelevance; LawPair)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Faces; low; high; OTop; star)

module Data {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C) where
  open Category C
  open HC.ForCategory.Diagram D using (Value; action)
  open Chains C
  open CC.Splits C

  Top : Dim → Type ℓ → Type ℓ
  Top n P = (s : P) (y : Obj) → Chain n y → Cube n (Value y)

  Families : Dim → Type ℓ → Type ℓ
  Families ozero P = Top ozero P
  Families (osuc n) P = Families n P × Top (osuc n) P

  top : (n : Dim) {P : Type ℓ} → Families n P → Top n P
  top ozero F = F
  top (osuc n) F = F .snd

  at : {m n : Dim} {P : Type ℓ} → m ≤ᵈ n → Families n P → Top m P
  at {m} same F = top m F
  at (lower p) F = at p (F .fst)

  truncate : {m n : Dim} {P : Type ℓ} → m ≤ᵈ n → Families n P → Families m P
  truncate same F = F
  truncate (lower p) F = truncate p (F .fst)

  lookup-irrelevance : {m n : Dim} {P : Type ℓ} (p q : m ≤ᵈ n) (F : Families n P)
    → outer (at p F) ≡ˢ outer (at q F)
  lookup-irrelevance p q F = strict-cong (λ z → outer (at z F)) (bound-irrelevance p q)

  top-truncate : {m n : Dim} {P : Type ℓ} (p : m ≤ᵈ n) (F : Families n P)
    → outer (top m (truncate p F)) ≡ˢ outer (at p F)
  top-truncate same F = reflˢ
  top-truncate (lower p) F = top-truncate p (F .fst)

  at-truncate : {k m n : Dim} {P : Type ℓ} (p : k ≤ᵈ m) (q : m ≤ᵈ n) (F : Families n P)
    → outer (at p (truncate q F)) ≡ˢ outer (at (transitive p q) F)
  at-truncate p same F = reflˢ
  at-truncate p (lower q) F = at-truncate p q (F .fst)

  one-face : (n : Dim) {P : Type ℓ} (F : Families n P) (s : P)
    (p : Position (osuc n)) {y : Obj} → Chain (osuc n) y → Cube n (Value y)
  one-face n F s p c = tensor-action n p
    (action (suffix-degree n p) (split-suffix n p c))
    (λ s → at (prefix-bound n p) F s (split-vertex n p c) (split-prefix n p c)) s

  bar-faces : (n : Dim) {P : Type ℓ} (F : Families n P) (s : P) {y : Obj}
    → Chain (osuc n) y → Faces (osuc n) (Value y)
  bar-faces n F s c p low = top n F s _ (face n p c)
  bar-faces n F s c p high = one-face n F s p c

  record LayerLaws (n : Dim) {P : Type ℓ} (F : Families n P) (next : Top (osuc n) P) : SSet ℓ where
    field
      zero-face : (s : P) (y : Obj) (c : Chain (osuc n) y) (p : Position (osuc n))
        → outer (coordinate-face n p i0 (next s y c)) ≡ˢ outer (top n F s y (face n p c))
      one-face-law : (s : P) (y : Obj) (c : Chain (osuc n) y) (p : Position (osuc n))
        → outer (coordinate-face n p i1 (next s y c)) ≡ˢ outer (one-face n F s p c)

  Coherent : (n : Dim) {P : Type ℓ} → Families n P → SSet ℓ
  Coherent ozero F = OTop ℓ
  Coherent (osuc n) F = LawPair (Coherent n (F .fst)) (LayerLaws n (F .fst) (F .snd))

  coherent-truncate : {m n : Dim} {P : Type ℓ} (p : m ≤ᵈ n) (F : Families n P)
    → Coherent n F → Coherent m (truncate p F)
  coherent-truncate same F coherent = coherent
  coherent-truncate (lower p) F coherent = coherent-truncate p (F .fst) (LawPair.earlier coherent)

  law-at-zero : {m n : Dim} {P : Type ℓ} (bound : osuc m ≤ᵈ n) (F : Families n P)
    → Coherent n F → (s : P) (y : Obj) (c : Chain (osuc m) y) (p : Position (osuc m))
    → outer (coordinate-face m p i0 (at bound F s y c))
      ≡ˢ outer (at (transitive (lower same) bound) F s y (face m p c))
  law-at-zero {m} bound F coherent s y c p = strict-trans
    (strict-cong (λ f → outer (coordinate-face m p i0 (inner f s y c)))
      (strict-sym (top-truncate bound F)))
    (strict-trans
      (LayerLaws.zero-face (LawPair.current (coherent-truncate bound F coherent)) s y c p)
      (strict-cong (λ f → outer (inner f s y (face m p c))) (at-truncate (lower same) bound F)))

  law-at-one : {m n : Dim} {P : Type ℓ} (bound : osuc m ≤ᵈ n) (F : Families n P)
    → Coherent n F → (s : P) (y : Obj) (c : Chain (osuc m) y) (p : Position (osuc m))
    → outer (coordinate-face m p i1 (at bound F s y c))
      ≡ˢ outer (tensor-action m p (action (suffix-degree m p) (split-suffix m p c))
        (λ s → at (transitive (lower (prefix-bound m p)) bound) F s
          (split-vertex m p c) (split-prefix m p c)) s)
  law-at-one {m} bound F coherent s y c p = strict-trans
    (strict-cong (λ f → outer (coordinate-face m p i1 (inner f s y c)))
      (strict-sym (top-truncate bound F)))
    (strict-trans
      (LayerLaws.one-face-law (LawPair.current (coherent-truncate bound F coherent)) s y c p)
      (strict-cong (λ f → outer (tensor-action m p
        (action (suffix-degree m p) (split-suffix m p c))
        (λ s → inner f s (split-vertex m p c) (split-prefix m p c)) s))
        (at-truncate (lower (prefix-bound m p)) bound F)))

  reindex : (n : Dim) {P Q : Type ℓ} → Families n P → (Q → P) → Families n Q
  reindex ozero F h s y c = F (h s) y c
  reindex (osuc n) F h = reindex n (F .fst) h , λ s y c → F .snd (h s) y c

  top-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P) (h : Q → P)
    (s : Q) (y : Obj) (c : Chain n y)
    → outer (top n (reindex n F h) s y c) ≡ˢ outer (top n F (h s) y c)
  top-reindex ozero F h s y c = reflˢ
  top-reindex (osuc n) F h s y c = reflˢ

  at-reindex : {m n : Dim} {P Q : Type ℓ} (b : m ≤ᵈ n) (F : Families n P) (h : Q → P)
    → outer (at b (reindex n F h)) ≡ˢ outer (λ s y c → at b F (h s) y c)
  at-reindex {n = ozero} same F h = reflˢ
  at-reindex {n = osuc n} same F h = reflˢ
  at-reindex (lower b) F h = at-reindex b (F .fst) h

  module Coherence (E : StrictCubicalExtensionality ℓ) where
    open StrictCubicalExtensionality E

    tensor-precompose : (n : Dim) (p : Position (osuc n)) {A B P Q : Type ℓ}
      (g : A → Cube (suffix-degree n p) B) (f : P → Cube (prefix-degree n p) A)
      (h : Q → P) (s : Q)
      → outer (tensor-action n p g (λ s → f (h s)) s)
        ≡ˢ outer (tensor-action n p g f (h s))
    tensor-precompose n pzero g f h s = reflˢ
    tensor-precompose (osuc n) (psuc p) g f h s = interval-ext λ i →
      tensor-precompose n p (λ a → g a i) f h s

    one-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P) (h : Q → P)
      (s : Q) (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
      → outer (one-face n (reindex n F h) s p c) ≡ˢ outer (one-face n F (h s) p c)
    one-reindex n F h s p c = strict-trans
      (strict-cong (λ f → outer (tensor-action n p
        (action (suffix-degree n p) (split-suffix n p c))
        (λ s → inner f s (split-vertex n p c) (split-prefix n p c)) s))
        (at-reindex (prefix-bound n p) F h))
      (tensor-precompose n p (action (suffix-degree n p) (split-suffix n p c))
        (λ s → at (prefix-bound n p) F s (split-vertex n p c) (split-prefix n p c)) h s)

    coherent-reindex : (n : Dim) {P Q : Type ℓ} (F : Families n P)
      → Coherent n F → (h : Q → P) → Coherent n (reindex n F h)
    coherent-reindex ozero F coherent h = star
    LawPair.earlier (coherent-reindex (osuc n) F coherent h) =
      coherent-reindex n (F .fst) (LawPair.earlier coherent) h
    LayerLaws.zero-face (LawPair.current (coherent-reindex (osuc n) F coherent h)) s y c p = strict-trans
      (LayerLaws.zero-face (LawPair.current coherent) (h s) y c p)
      (strict-sym (top-reindex n (F .fst) h s y (face n p c)))
    LayerLaws.one-face-law (LawPair.current (coherent-reindex (osuc n) F coherent h)) s y c p = strict-trans
      (LayerLaws.one-face-law (LawPair.current coherent) (h s) y c p)
      (strict-sym (one-reindex n (F .fst) h s p c))
