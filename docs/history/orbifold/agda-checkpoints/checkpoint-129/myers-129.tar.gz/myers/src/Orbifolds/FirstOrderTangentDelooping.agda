{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderTangentDelooping where

-- The actual square-zero infinitesimals used by SyntheticDifferential
-- are pointed-equivalent to the one-coordinate disk D(1).  This lets
-- the same restricted Postulate W feed the tangent delooping theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Pointed
open import Cubical.Data.Sigma
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyEquivalences as TE
import Orbifolds.TangentDelooping as TD
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as CP
import Orbifolds.Quotients as Q

module Coordinate {ℓ : Level} (R : CommRing ℓ) where
  module Disks = IL.Ring R
  module Differential = SD.FirstOrder R

  to : Disks.D 1 → Differential.D
  to x = x .fst FD.zero , x .snd FD.zero FD.zero

  from : Differential.D → Disks.D 1
  from x = const (x .fst) , λ _ _ → x .snd

  from-to : (x : Disks.D 1) → from (to x) ≡ x
  from-to x = Σ≡Prop Disks.pairwise-zero-isProp
    (funExt λ i → cong (x .fst) (FD.isContrFin1 .snd i))

  equivalence : Disks.D 1 ≃ Differential.D
  equivalence = isoToEquiv (iso to from (λ _ → refl) from-to)

  pointed-equivalence : (Disks.D 1 , Disks.zeroD 1)
    ≃∙ (Differential.D , Differential.zeroD)
  pointed-equivalence = equivalence , refl

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CI.CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero) where
  open CommRingStr (R .snd) using (0r)
  module Linearity = IL.Context R rules identity-zero flat-zero flat-zero-computation
  module Differential = SD.FirstOrder R
  module Propositions = CP.Context (R .fst) 0r
  module Tangents = TD.Context rules identity-zero flat-zero flat-zero-computation
    (R .fst) 0r Differential.D Differential.zeroD
  open Linearity using (TinyDisks)
  open Propositions using (RealFlat)

  square-zero-tiny : TinyDisks → TT.External.Tiny Differential.D
  square-zero-tiny tiny = TE.Context.respects-equivalence rules
    (invEquiv (Coordinate.equivalence R)) (tiny 1)

  module HigherGroup (@♭ G : Q.Delooping ℓ) where
    module Generic = Tangents.HigherGroup G
    open Generic using (LieAlgebra; lie-algebra-point) public

    tangent-delooping : RealFlat → TinyDisks → Q.Delooping ℓ
    tangent-delooping real-flat tiny = Generic.tangent-delooping real-flat (square-zero-tiny tiny)

    lie-algebra-loops : (real-flat : RealFlat) (tiny : TinyDisks)
      → Q.Loop (tangent-delooping real-flat tiny) ≃ LieAlgebra
    lie-algebra-loops real-flat tiny = Generic.lie-algebra-loops real-flat (square-zero-tiny tiny)

    lie-algebra-loops-pointed : (real-flat : RealFlat) (tiny : TinyDisks)
      → (Q.Loop (tangent-delooping real-flat tiny) , refl)
        ≃∙ (LieAlgebra , lie-algebra-point)
    lie-algebra-loops-pointed real-flat tiny =
      Generic.lie-algebra-loops-pointed real-flat (square-zero-tiny tiny)
