{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularCoconeRepresentation where

-- A constructed compatible representation at each finite stage yields
-- the full sequential-colimit mapping universal property. The optional
-- coinductive witness produces exactly these stage data from an actual
-- cellular presentation and an actual inner inverse transition system.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path using (symIso; compPathlEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sequence using (Sequence)
import Cubical.HITs.SequentialColimit as SC
import Cubical.HITs.Pushout as PO
import Orbifolds.MappingColimits as Mapping
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularConeMicrolinearity as Towers

module SequenceRepresentation {ℓa ℓy ℓv : Level} (X : Sequence ℓa) (Y : Type ℓy)
    (V : ℕ → Type ℓv) (drop : (n : ℕ) → V (suc n) → V n)
    (stage : (n : ℕ) → (Sequence.obj X n → Y) ≃ V n)
    (square : (n : ℕ) (h : Sequence.obj X (suc n) → Y)
      → drop n (stage (suc n) .fst h) ≡ stage n .fst (h ∘ Sequence.map X {n})) where
  module Source = Mapping.SequenceCone X Y
  module Target = Towers.InverseTower V drop

  stage-family : ((n : ℕ) → Sequence.obj X n → Y) ≃ ((n : ℕ) → V n)
  stage-family = equivΠCod stage

  compatibility : (h : (n : ℕ) → Sequence.obj X n → Y)
    → ((n : ℕ) → h n ≡ h (suc n) ∘ Sequence.map X {n})
      ≃ Target.Compatibility (λ n → stage n .fst (h n))
  compatibility h = equivΠCod λ n → congEquiv (stage n)
    ∙ₑ isoToEquiv symIso ∙ₑ compPathlEquiv (square n (h (suc n)))

  cocone-equivalence : Source.Cocone ≃ Target.Limit
  cocone-equivalence = Σ-cong-equiv stage-family compatibility

  universal : (SC.SeqColim X → Y) ≃ Target.Limit
  universal = Source.universal ∙ₑ cocone-equivalence

  restrict : (SC.SeqColim X → Y) → Target.Limit
  restrict = universal .fst

  assemble : Target.Limit → SC.SeqColim X → Y
  assemble = invEq universal

  stage-computation : (h : SC.SeqColim X → Y) (n : ℕ)
    → restrict h .fst n ≡ stage n .fst (h ∘ SC.incl {n = n})
  stage-computation h n = refl

  compatibility-computation : (h : SC.SeqColim X → Y) (n : ℕ)
    → restrict h .snd n
      ≡ square n (h ∘ SC.incl {n = suc n})
        ∙ cong (stage n .fst) (sym (λ i x → h (SC.push {n = n} x i)))
  compatibility-computation h n = refl

  assemble-restrict : (h : SC.SeqColim X → Y) → assemble (restrict h) ≡ h
  assemble-restrict = retEq universal

  restrict-assemble : (c : Target.Limit) → restrict (assemble c) ≡ c
  restrict-assemble = secEq universal

module Coinductive {ℓa ℓy ℓv ℓs : Level} (Y : Type ℓy)
    (State : Type ℓs) (Value : State → Type ℓv)
    (advance : State → State) (drop : (q : State) → Value (advance q) → Value q) where

  mutual
    record Witness {A : Type ℓa} (P : CP.Presentation A) (q : State)
        : Type (ℓ-max ℓa (ℓ-max ℓy ℓv)) where
      coinductive
      field
        current : (A → Y) ≃ Value q
        tail : Witness (CP.Presentation.next P) (advance q)
        square : (h : PO.Pushout (CP.Presentation.attach P) (CP.Presentation.boundary P) → Y)
          → drop q (current-of tail .fst h) ≡ current .fst (h ∘ PO.inl)

    current-of : {A : Type ℓa} {P : CP.Presentation A} {q : State}
      → Witness P q → (A → Y) ≃ Value q
    current-of w = Witness.current w

  module Realization (A : Type ℓa) (P : CP.Presentation A) (q : State)
      (witness : Witness P q) where
    module R = CP.Realization A P

    state : ℕ → State
    state zero = q
    state (suc n) = advance (state n)

    witness-at : (n : ℕ) → Witness (R.state n .snd) (state n)
    witness-at zero = witness
    witness-at (suc n) = Witness.tail (witness-at n)

    stage : (n : ℕ) → (R.Stage n → Y) ≃ Value (state n)
    stage n = Witness.current (witness-at n)

    stage-square : (n : ℕ) (h : R.Stage (suc n) → Y)
      → drop (state n) (stage (suc n) .fst h) ≡ stage n .fst (h ∘ R.inclusion n)
    stage-square n = Witness.square (witness-at n)

    module Comparison = SequenceRepresentation R.stages Y
      (λ n → Value (state n)) (λ n → drop (state n)) stage stage-square
    open Comparison using (universal; restrict; assemble; stage-computation;
      compatibility-computation; assemble-restrict; restrict-assemble) public
