{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderRealPushouts where

-- Lemma 4.2.15: the actual first-order axis squares are R-pushouts.
-- Kock--Lawvere supplies unique affine coordinates; splitting their
-- coefficient vector constructs an equivalence for the canonical map.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; _+_)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
import Cubical.Algebra.Ring.BigOps as BO
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.FirstOrderKockLawvere as KL
import Orbifolds.FirstOrderMatrixCoproducts as MC
import Orbifolds.WeilAlgebras as WA
import Orbifolds.MicrolinearityLimits as ML

module Ring {ℓ : Level} (R : CommRing ℓ) (kock-lawvere : WA.Weil.KockLawvere R) where
  open CommRingStr (R .snd) renaming (_+_ to _+R_)
  module Disks = IL.Ring R
  module Coordinates = KL.Ring R kock-lawvere
  module Matrices = MC.Ring R
  module S = BO.Sum (CommRing→Ring R)

  module Binary (n m : ℕ) where
    module Axes = Disks.Axes n m
    module Left = Coordinates.Dimension n
    module Right = Coordinates.Dimension m
    module Union = Coordinates.Dimension (n + m)

    sum-functions : ((FD.Fin n ⊎ FD.Fin m) → R .fst)
      ≃ ((FD.Fin n → R .fst) × (FD.Fin m → R .fst))
    sum-functions = isoToEquiv (iso
      (λ h → h ∘ inl , h ∘ inr)
      (λ { (f , g) (inl i) → f i ; (f , g) (inr j) → g j })
      (λ _ → refl) (λ h → funExt λ { (inl _) → refl ; (inr _) → refl }))

    split-vector : Union.Jet.Vector ≃ (Left.Jet.Vector × Right.Jet.Vector)
    split-vector = compEquiv (preCompEquiv (FD.FinSumChar.Equiv n m)) sum-functions

    CoefficientCone : Type ℓ
    CoefficientCone = Σ[ ab ∈ (Left.Jet.Jet × Right.Jet.Jet) ] ab .fst .fst ≡ ab .snd .fst

    separated-coefficients : CoefficientCone ≃ (R .fst × (Left.Jet.Vector × Right.Jet.Vector))
    separated-coefficients = isoToEquiv (iso
      (λ { (((r , v) , (s , w)) , p) → r , v , w })
      (λ { (r , v , w) → ((r , v) , (r , w)) , refl })
      (λ _ → refl)
      (λ { (((r , v) , (s , w)) , p) →
        Σ≡Prop (λ ab → is-set _ _) (λ i → (r , v) , (p i , w)) }))

    coefficient-comparison : Union.Jet.Jet ≃ CoefficientCone
    coefficient-comparison = compEquiv
      (Σ-cong-equiv-snd (λ _ → split-vector)) (invEquiv separated-coefficients)

    affine-cocones : CoefficientCone
      ≃ ML.Pullback (Axes.Maps.evaluate-left (R .fst)) (Axes.Maps.evaluate-right (R .fst))
    affine-cocones = Σ-cong-equiv
      (Σ-cong-equiv Left.affine-equivalence (λ _ → Right.affine-equivalence))
      (λ { (a , b) → compEquiv
        (compPathrEquiv (sym (Right.affine-origin b)))
        (compPathlEquiv (Left.affine-origin a)) })

    linear-left : (v : Union.Jet.Vector) (d : Disks.D n)
      → Union.linear v (Axes.left d)
        ≡ Left.linear (λ i → v (FD.FinSumChar.fun n m (inl i))) d
    linear-left v d = Matrices.sum-blocks n m (λ i → v i · Axes.left d .fst i)
      ∙ cong₂ _+R_
        (S.∑Ext λ i → cong (v (FD.FinSumChar.fun n m (inl i)) ·_) (Axes.left-at-left d i))
        (S.∑Ext (λ i → cong (v (FD.FinSumChar.fun n m (inr i)) ·_) (Axes.left-at-right d i))
          ∙ S.∑Mulr0 (λ i → v (FD.FinSumChar.fun n m (inr i))))
      ∙ +IdR _

    linear-right : (v : Union.Jet.Vector) (d : Disks.D m)
      → Union.linear v (Axes.right d)
        ≡ Right.linear (λ i → v (FD.FinSumChar.fun n m (inr i))) d
    linear-right v d = Matrices.sum-blocks n m (λ i → v i · Axes.right d .fst i)
      ∙ cong₂ _+R_
        (S.∑Ext (λ i → cong (v (FD.FinSumChar.fun n m (inl i)) ·_) (Axes.right-at-left d i))
          ∙ S.∑Mulr0 (λ i → v (FD.FinSumChar.fun n m (inl i))))
        (S.∑Ext λ i → cong (v (FD.FinSumChar.fun n m (inr i)) ·_) (Axes.right-at-right d i))
      ∙ +IdL _

    comparison-coherence : (rv : Union.Jet.Jet)
      → equivFun affine-cocones (equivFun coefficient-comparison rv)
        ≡ Axes.Maps.comparison (R .fst) (Union.affine rv)
    comparison-coherence (r , v) = Σ≡Prop (λ ab → is-set _ _)
      (λ i → (λ d → cong (r +R_) (sym (linear-left v d)) i) ,
        (λ d → cong (r +R_) (sym (linear-right v d)) i))

    underlying-equivalence : (Disks.D (n + m) → R .fst)
      ≃ ML.Pullback (Axes.Maps.evaluate-left (R .fst)) (Axes.Maps.evaluate-right (R .fst))
    underlying-equivalence = compEquiv (invEquiv Union.affine-equivalence)
      (compEquiv coefficient-comparison affine-cocones)

    canonical-comparison-coherence : equivFun underlying-equivalence
      ≡ Axes.Maps.comparison (R .fst)
    canonical-comparison-coherence = funExt λ h →
      comparison-coherence (invEq Union.affine-equivalence h)
      ∙ cong (Axes.Maps.comparison (R .fst)) (secEq Union.affine-equivalence h)

    real-pullback : Axes.Maps.IsLinear (R .fst)
    real-pullback = subst isEquiv canonical-comparison-coherence (snd underlying-equivalence)

  real-infinitesimally-linear : Disks.InfinitesimallyLinear (R .fst)
  real-infinitesimally-linear = Binary.real-pullback
