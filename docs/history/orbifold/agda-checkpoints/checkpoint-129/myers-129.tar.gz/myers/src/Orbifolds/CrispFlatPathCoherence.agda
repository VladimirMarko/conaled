{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispFlatPathCoherence where

-- The input is a uniform family of actual Flat/path equivalences at one
-- crisp universe level. It is not assumed to preserve reflexivity, the
-- counit or substitution. The construction from148 first reconstructs
-- crisp J, and then the existing identity theorem constructs a coherent
-- comparison. No equality with the initially supplied comparison is claimed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv using (_≃_; equivFun)
open import Orbifolds.Crisp using (Flat; box; counit; flat-map)
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispIdentityFromFlatPaths as FP

-- This is the converse construction to148. These two constructions do
-- not assert an equivalence of the types of complete rule witnesses.
flat-paths-from-rules : {@♭ ℓ : Level}
  → (@♭ rules : CrispIdentityInduction {ℓ}) → FP.FlatPathEquivalences {ℓ}
flat-paths-from-rules rules A x y =
  CI.Theory.flat-identity-equivalence rules {A = A} x y

module Construction {@♭ ℓ : Level} (@♭ E : FP.FlatPathEquivalences {ℓ}) where

  rules : CrispIdentityInduction {ℓ}
  rules = FP.Construction.crisp-identity-induction E

  module Identity = CI.Theory rules

  comparison : {@♭ A : Type ℓ} (@♭ x y : A)
    → Flat (x ≡ y) ≃ (box x ≡ box y)
  comparison x y = Identity.flat-identity-equivalence x y

  comparison-refl : {@♭ A : Type ℓ} (@♭ x : A)
    → equivFun (comparison x x) (box refl) ≡ refl
  comparison-refl x = Identity.box-path-refl x

  comparison-counit : {@♭ A : Type ℓ} (@♭ x y : A)
    → (p : Flat (x ≡ y))
    → cong counit (equivFun (comparison x y) p) ≡ counit p
  comparison-counit x y p = Identity.counit-decode x y p

  comparison-natural : {@♭ A B : Type ℓ} (@♭ f : A → B)
    (@♭ x y : A) (p : Flat (x ≡ y))
    → cong (flat-map f) (equivFun (comparison x y) p)
      ≡ equivFun (comparison (f x) (f y)) (flat-map (cong f) p)
  comparison-natural f x y p = Identity.flat-identity-natural f x y p

  -- Preservation concerns the actual flat-map of the supplied crisp
  -- function, including its specified inverse laws.
  preserves-equivalence : {@♭ A B : Type ℓ} (@♭ e : A ≃ B)
    → Flat A ≃ Flat B
  preserves-equivalence = Identity.flat-equivalence

  preserves-equivalence-map : {@♭ A B : Type ℓ} (@♭ e : A ≃ B)
    → equivFun (preserves-equivalence e) ≡ flat-map (equivFun e)
  preserves-equivalence-map e = refl

-- All equalities are native Cubical paths, and the input E is crisp.
-- This constructs coherence inside that signature. It does not supply E,
-- interpret native crisp contexts, or prove a source substitution theorem.
