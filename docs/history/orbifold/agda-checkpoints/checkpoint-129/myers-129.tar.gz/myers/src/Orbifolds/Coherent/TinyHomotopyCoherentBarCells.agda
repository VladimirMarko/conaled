{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyHomotopyCoherentBarCells where

-- Tinyness supplies the actual initial and local coefficient maps of
-- the fully coherent bar construction. Externality is proved for every
-- finite composable-chain index from discrete objects and hom spaces.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyDiscreteIndices as Discrete
import Orbifolds.TinyCubicalShellCells as Spheres
import Orbifolds.GraphColimits as Coproduct
import Orbifolds.Coherent.EnrichedBarDiscreteness as BarDiscrete
import Orbifolds.Coherent.QuotedCellPowerComparisons as CellPower

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C) where
  open Category C
  open HC.ForCategory.Diagram D using (Value)
  module Objects = Discrete.Context identity-rules flat-induction flat-computation R r₀ T
  module ChainsDiscrete = BarDiscrete.Context identity-rules identity-zero flat-zero flat-zero-computation (Opposite C)
  module Indices = ChainsDiscrete.Power flat-induction flat-computation R r₀ T
  module Boundary = Spheres.BoundaryNullity identity-rules identity-zero flat-zero flat-zero-computation T
  open Objects using (RealFlat) public

  Initial : Type ℓ
  Initial = Σ Obj Value

  PoweredInitial : Type ℓ
  PoweredInitial = Σ[ x ∈ Obj ] (T → Value x)

  initial-comparison : PoweredInitial → T → Initial
  initial-comparison (x , v) t = x , v t

  initial-preserved : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj → isEquiv initial-comparison
  initial-preserved real-flat tiny discrete-objects = Coproduct.Coproduct.preserves T Obj Value
    (Objects.Index.null-index Obj real-flat discrete-objects tiny)

  Index : Dim → Type ℓ
  Index n = Chains.Index (Opposite C) (osuc n)

  Coefficient : (n : Dim) → Index n → Type ℓ
  Coefficient n c = Value (c .fst)

  module Local (n : Dim) = CellPower.Comparison T (Index n) (Coefficient n) (toNat (osuc n))

  indices-null : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (n : Dim) → isEquiv (const :> (Index n → (T → Index n)))
  indices-null real-flat tiny discrete-objects discrete-homs n =
    Indices.indices-null real-flat tiny discrete-objects (λ x y → discrete-homs y x) (toNat (osuc n))

  cells-preserved : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (n : Dim) → isEquiv (Local.cell-comparison n)
  cells-preserved real-flat tiny discrete-objects discrete-homs n =
    Local.NullIndices.cells-preserved n
      (indices-null real-flat tiny discrete-objects discrete-homs n)
      (Boundary.boundaries-null tiny (toNat (osuc n)))

  boundaries-preserved : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (n : Dim) → isEquiv (Local.boundary-comparison n)
  boundaries-preserved real-flat tiny discrete-objects discrete-homs n =
    Local.NullIndices.boundaries-preserved n
      (indices-null real-flat tiny discrete-objects discrete-homs n)
      (Boundary.boundaries-null tiny (toNat (osuc n)))
