{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrystallineEuclidean where

-- Lemma 6.3.1: a crystalline subspace of a real power is shape-modal.
-- The only analytic input is the paper's stated Principle of Constancy;
-- no excluded middle or decidable equality of the smooth reals is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Functions.Embedding
open import Cubical.Algebra.CommRing.Base
import Orbifolds.Crystalline as CR
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.SyntheticField as SF
import Orbifolds.ModalEtaleOperations as EO

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R
  open CommRingStr (R .snd)
  module FirstOrder = SD.FirstOrder R
  module Field = SF.RingContext R
  module Operations = EO.Theory CrystallineModality

  -- Lemma 6.3.2 is a general modal dependent-sum argument. It does not
  -- require that the modality preserve arbitrary pullbacks.
  etale-pullback-crystalline : {X Y C : Type ℓ} (f : X → Y)
    → Crystal.Etale f → IsCrystalline C → (g : C → Y)
    → IsCrystalline (Σ[ c ∈ C ] fiber f (g c))
  etale-pullback-crystalline f etale modalC g =
    Operations.Σ-isModal (λ c → fiber f (g c)) modalC
      (λ c → Operations.etale-modal-fibres f etale (g c))

  crystalline-subtype : {X : Type ℓ} → IsCrystalline X
    → (P : X → hProp ℓ) → IsCrystalline (Σ[ x ∈ X ] P x .fst)
  crystalline-subtype modalX P =
    Operations.Σ-isModal (λ x → P x .fst) modalX
      (λ x → proposition-crystalline (P x .snd))

  PrincipleOfConstancy : Type ℓ
  PrincipleOfConstancy = (f : Carrier → Carrier)
    → ((t : Carrier) (ε : FirstOrder.D) → f (t + ε .fst) ≡ f t)
    → (t : Carrier) → f t ≡ f 0r

  crystalline-map-constant : {X : Type ℓ} → IsCrystalline X
    → (f : 𝔇 → X) (d : 𝔇) → f d ≡ f zero𝔇
  crystalline-map-constant modalX f d =
    sym (cong (λ h → h d) (secEq e f))
      ∙ cong (λ h → h zero𝔇) (secEq e f)
    where e = const , Crystal.connected-constant infinitesimal-connected modalX

  crystalline-curve-infinitesimal : Field.KockField
    → {X : Type ℓ} → IsCrystalline X → (γ : Carrier → X)
    → (t : Carrier) (ε : FirstOrder.D) → γ (t + ε .fst) ≡ γ t
  crystalline-curve-infinitesimal kock modalX γ t ε =
    crystalline-map-constant modalX (λ d → γ (t + d .fst))
      (first-order→infinitesimal kock ε)
    ∙ cong γ (+IdR t)

  real-power-subspace-crystalline→shape-modal : Field.KockField → PrincipleOfConstancy
    → {I X : Type ℓ} → (embedding : X ↪ (I → Carrier))
    → IsCrystalline X → IsShapeModal X
  real-power-subspace-crystalline→shape-modal kock constancy {I = I} {X = X}
      embedding modalX _ = fromIsEquiv const (isoToIsEquiv
        (iso const (λ f → f 0r) (λ f → funExt λ t → sym (constant f t)) (λ _ → refl)))
    where
    coordinate-constant : (γ : Carrier → X) (i : I) (t : Carrier)
      → embedding .fst (γ t) i ≡ embedding .fst (γ 0r) i
    coordinate-constant γ i = constancy (λ t → embedding .fst (γ t) i)
      (λ t ε → cong (λ x → embedding .fst x i)
        (crystalline-curve-infinitesimal kock modalX γ t ε))

    constant : (γ : Carrier → X) (t : Carrier) → γ t ≡ γ 0r
    constant γ t = isEmbedding→Inj (embedding .snd) (γ t) (γ 0r)
      (funExt λ i → coordinate-constant γ i t)
