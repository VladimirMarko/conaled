{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FiniteApproximation where

-- Constructive finite-grid approximation. Overlapping open intervals
-- avoid a floor function or a decision procedure for real order.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.Data.Nat.Order as NO
import Cubical.Data.Fin as F
import Cubical.Data.SumFin as SFin
import Cubical.Data.FinSet.FiniteChoice as FC
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_)
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.SyntheticBounds as SB

module Ordered {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext R using (nat)
  open SF.RingContext.StrictOrder order
  open SO.OrderTheory R order
  open Compatible compatibility
  open SB.Bounds R kock order compatibility using (negateLess)

  finite-choice : {ℓx : Level} {n : ℕ} (A : F.Fin n → Type ℓx)
    → ((i : F.Fin n) → PT.∥ A i ∥₁) → PT.∥ ((i : F.Fin n) → A i) ∥₁
  finite-choice {n = n} A = FC.choice
    (F.Fin n , n , PT.∣ invEquiv (SFin.SumFin≃Fin n) ∣₁) A

  GridWitness : (L : ℕ) → R .fst → Type ℓ
  GridWitness L w = Σ[ k ∈ F.Fin L ]
    ((nat (k .fst) < w) × (w < nat (suc (suc (k .fst)))))

  positive-finite-grid : (L : ℕ) (w : R .fst)
    → 0r < w → w < nat L → PT.∥ GridWitness L w ∥₁
  positive-finite-grid zero w positive below = Empty.rec (lessAsym positive below)
  positive-finite-grid (suc zero) w positive below =
    PT.∣ F.fzero , positive , lessTrans below
      (nat≤→strictNext {n = 1} {i = 1} NO.≤-refl) ∣₁
  positive-finite-grid (suc (suc L)) w positive below = PT.rec PT.squash₁
    (Sum.rec
      (λ above → PT.∣ (L , NO.≤-suc NO.≤-refl) , above , below ∣₁)
      (λ upper → PT.map (λ (k , bounds) → F.finj k , bounds)
        (positive-finite-grid (suc L) w positive upper)))
    (cotransitive (nat≤→strictNext {n = L} {i = L} NO.≤-refl) w)

  interval-difference-upper : (a b x y : R .fst)
    → x < b → a < y → (x - y) < (b - a)
  interval-difference-upper a b x y upper lower =
    lessTrans (translateLess upper (- y))
      (subst2 _<_ (+Comm (- y) b) (+Comm (- a) b) (translateLess (negateLess lower) b))

  minus-difference : (x y : R .fst) → - (y - x) ≡ x - y
  minus-difference x y = solve! R

  grid-width : (a : R .fst) → ((a + 1r) + 1r) - a ≡ 1r + 1r
  grid-width a = solve! R

  same-grid-close : (k : ℕ) (x y : R .fst)
    → ((nat k < x) × (x < nat (suc (suc k))))
    → ((nat k < y) × (y < nat (suc (suc k))))
    → ((- (1r + 1r)) < (x - y)) × ((x - y) < (1r + 1r))
  same-grid-close k x y xb yb =
    subst2 _<_ (cong (-_) (grid-width (nat k))) (minus-difference x y)
      (negateLess (interval-difference-upper (nat k) (nat (suc (suc k))) y x
        (yb .snd) (xb .fst))) ,
    subst ((x - y) <_) (grid-width (nat k))
      (interval-difference-upper (nat k) (nat (suc (suc k))) x y (xb .snd) (yb .fst))

  bounded-pigeonhole : (L : ℕ) (w : F.Fin (suc L) → R .fst)
    → ((i : F.Fin (suc L)) → 0r < w i)
    → ((i : F.Fin (suc L)) → w i < nat L)
    → PT.∥ Σ[ i ∈ F.Fin (suc L) ] Σ[ j ∈ F.Fin (suc L) ]
      (¬ (i ≡ j)) ×
      (((- (1r + 1r)) < (w i - w j)) × ((w i - w j) < (1r + 1r))) ∥₁
  bounded-pigeonhole L w positive bounded = PT.map finish
    (finite-choice (λ i → GridWitness L (w i))
      (λ i → positive-finite-grid L (w i) (positive i) (bounded i)))
    where
    finish : ((i : F.Fin (suc L)) → GridWitness L (w i))
      → Σ[ i ∈ F.Fin (suc L) ] Σ[ j ∈ F.Fin (suc L) ]
        (¬ (i ≡ j)) ×
        (((- (1r + 1r)) < (w i - w j)) × ((w i - w j) < (1r + 1r)))
    finish chosen = i , j , different , same-grid-close (chosen i .fst .fst) (w i) (w j)
      (chosen i .snd)
      (subst (λ k → (nat k < w j) × (w j < nat (suc (suc k))))
        (sym (cong fst same)) (chosen j .snd))
      where
      collision = F.pigeonhole-special (λ i → chosen i .fst)
      i = collision .fst
      j = collision .snd .fst
      different = collision .snd .snd .fst
      same = collision .snd .snd .snd
