{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyHomotopyCoherentBarColimits where

-- The actual full bar-colimit comparison for tiny exponentiation.
-- Both presentations and every attachment square are constructed from
-- the coherent diagram and its evaluation transformations. Local cell
-- equivalences follow from discrete chain indices; all pushout and
-- sequential preservation follows from the external tiny adjunction.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowerBarComparison as PowerComparison
import Orbifolds.Coherent.TinyHomotopyCoherentBarCells as Cells
import Orbifolds.Coherent.RelativePresentationEquivalenceWitness as Witnesses
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyCellularPresentations as Operations
import Orbifolds.TinyCellularComparisons as Tiny
import Orbifolds.CellularPresentationComparisons as Comparisons

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C)
    (@♭ E : StrictCubicalExtensionality ℓ) (@♭ F : StrictFunctionExtensionality ℓ) where
  open Category C
  module Maps = PowerComparison.Construction C D E F T
    using (relative-map; module Bar; module Realization)
  module Bar = Maps.Bar
    using (State; module State; initial; advance; module RD; module RP; module Original; module Powered;
      module OriginalStages; module PoweredStages)
  module Original = Bar.Original using (Initial; presentation; bar-presentation; Colimit)
  module Powered = Bar.Powered using (presentation; bar-presentation; Colimit)
  module RD = Bar.RD
  module RP = Bar.RP
  module Witness = Witnesses.Theory (Operations.Power.operations T)
    using (LocalEquivalences; module LocalEquivalences; module Realization)
  module Coefficients = Cells.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R r₀ T C D
    using (RealFlat; initial-preserved; cells-preserved; boundaries-preserved)
  open Coefficients using (RealFlat) public

  open Maps using (relative-map)

  local-witness : (real-flat : RealFlat) (tiny : TT.External.Tiny T)
    (discrete-objects : CrisplyDiscrete Obj)
    (discrete-homs : (@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    (n : Dim) (original : RD.Represented n) (powered : RP.Represented n)
    (state : Bar.State n original powered)
    → Witness.LocalEquivalences (Original.presentation n original) (Powered.presentation n powered)
        (Bar.State.q state) (relative-map n original powered state)
  Witness.LocalEquivalences.boundary-isEquiv
      (local-witness real-flat tiny discrete-objects discrete-homs n original powered state) =
    Coefficients.boundaries-preserved real-flat tiny discrete-objects discrete-homs n
  Witness.LocalEquivalences.cell-isEquiv
      (local-witness real-flat tiny discrete-objects discrete-homs n original powered state) =
    Coefficients.cells-preserved real-flat tiny discrete-objects discrete-homs n
  Witness.LocalEquivalences.next
      (local-witness real-flat tiny discrete-objects discrete-homs n original powered state) =
    local-witness real-flat tiny discrete-objects discrete-homs (osuc n)
      (Bar.OriginalStages.Step.next n original) (Bar.PoweredStages.Step.next n powered)
      (Bar.advance n original powered state)

  module Construction = Maps.Realization

  comparison : Powered.Colimit → (T → Original.Colimit)
  comparison = Construction.comparison

  open Construction using (stage-map; boundary-map; cell-map; stage-computation; sequence-computation) public

  module Preservation = Tiny.Context.Presentation identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R T
    Original.Initial Original.bar-presentation Powered.bar-presentation
    (Bar.State.q Bar.initial) (relative-map ozero RD.initial RP.initial Bar.initial)
    using (comparison-isEquiv)

  preserves-colimit : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y)) → isEquiv comparison
  preserves-colimit real-flat tiny discrete-objects discrete-homs =
    Preservation.comparison-isEquiv real-flat tiny
      (Coefficients.initial-preserved real-flat tiny discrete-objects)
      (Witness.Realization.local-cells-equivalent Original.bar-presentation Powered.bar-presentation
        (Bar.State.q Bar.initial) (relative-map ozero RD.initial RP.initial Bar.initial)
        (local-witness real-flat tiny discrete-objects discrete-homs ozero RD.initial RP.initial Bar.initial))

  colimit-equivalence : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → Powered.Colimit ≃ (T → Original.Colimit)
  colimit-equivalence real-flat tiny discrete-objects discrete-homs =
    comparison , preserves-colimit real-flat tiny discrete-objects discrete-homs
