{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle where

-- Seal the actual finite canonical restriction triangle with the exact
-- endpoint constants of its original type.  The cell-restrict constant
-- is the constructed literal restriction.  Its strict construction
-- equality and actual first-coordinate transition remain available.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.HomotopyCoherentColimitTransitionCoherence as Transition

typeOf : ∀ {ℓ} {A : Type ℓ} → A → Type ℓ
typeOf {A = A} _ = A

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim) (previous : Represented.Induction.Represented C D E F n) where
  abstract
    canonical-restriction-comparison : typeOf
      (Stages.Construction.Step.canonical-restriction-comparison C D E F n previous)
    canonical-restriction-comparison =
      Stages.Construction.Step.canonical-restriction-comparison C D E F n previous

    construction : (Y : Type ℓ)
      (h : Stages.Construction.Step.Realize C D E F n previous → Y)
      → outer (canonical-restriction-comparison Y h)
        ≡ˢ outer (Stages.Construction.Step.canonical-restriction-comparison
          C D E F n previous Y h)
    construction Y h = reflˢ

    canonical-transition-coherence : (Y : Type ℓ)
      (h : Stages.Construction.Step.Realize C D E F n previous → Y)
      → cong {A = Cocones.Functoriality.Cocone C D E F Y (osuc n)}
          {B = λ _ → Cocones.Functoriality.Cocone C D E F Y n}
          fst (canonical-restriction-comparison Y h)
        ≡ strict-to-path {A = Cocones.Functoriality.Cocone C D E F Y n}
          (Stages.Construction.Step.transition-computation C D E F n previous Y h)
    canonical-transition-coherence Y h =
      Transition.Construction.canonical-transition-coherence C D E F n previous Y h
