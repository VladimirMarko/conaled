{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuoteFiberFunctor where

-- Strict composition for the actual action on quotation fibers. This
-- retains the chosen sphere map as the first component and compares the
-- endpoint certificates pointwise; no inverse-evaluation coherence is
-- postulated or selected independently.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalShellFunctor as ShellFunctor
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as Representation
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.Coherent.NaturalQuotedFillers as Quoted
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Functoriality {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module S = Shells.Action E
  module SF = ShellFunctor.Functoriality E
  module F = Fillers.Action E
  module R = Representation.Representation E
  module N = Natural.Natural E
  module Q = Quoted.Natural E

  cast-fiber : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    → outer b ≡ˢ outer b' → N.QuoteFiber n b → N.QuoteFiber n b'
  cast-fiber n e (h , p) = h , strict-end-path (λ i → p i) reflˢ e

  cast-fiber-value : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    (e : outer b ≡ˢ outer b') (z : N.QuoteFiber n b) (i : I)
    → outer (cast-fiber n e z .snd i) ≡ˢ outer (z .snd i)
  cast-fiber-value n e (h , p) i = strict-end-path-value (λ j → p j) reflˢ e i

  cast-fiber-fill : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    (e : outer b ≡ˢ outer b') (z : N.QuoteFiber n b) (u : Q.SphereNull n (z .fst))
    → cast-filler n e (N.fiber-fill n b z u)
      ≡ N.fiber-fill n b' (cast-fiber n e z) u
  cast-fiber-fill n reflˢ z u = refl

  map-fiber-value : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (b : CS.Shell (toNat n) X) (z : N.QuoteFiber n b) (i : I)
    → outer (N.map-fiber n f b z .snd i) ≡ˢ outer (S.map-shell n f (z .snd i))
  map-fiber-value n f b (h , p) i = strict-end-path-value
    (λ j → S.map-shell n f (p j)) (R.quote-natural n f h) reflˢ i

  map-fiber-compose-path : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y)
    (b : CS.Shell (toNat n) X) (z : N.QuoteFiber n b)
    → outer (cast-fiber n (SF.map-compose n g f b)
        (N.map-fiber n g (S.map-shell n f b) (N.map-fiber n f b z)) .snd)
      ≡ˢ outer (N.map-fiber n (g ∘ f) b z .snd)
  map-fiber-compose-path n g f b z = path-ext λ i → strict-trans
    (cast-fiber-value n (SF.map-compose n g f b)
      (N.map-fiber n g (S.map-shell n f b) (N.map-fiber n f b z)) i)
    (strict-trans
      (map-fiber-value n g (S.map-shell n f b) (N.map-fiber n f b z) i)
      (strict-trans
        (strict-cong (λ a → outer (S.map-shell n g (inner a))) (map-fiber-value n f b z i))
        (strict-trans (SF.map-compose n g f (z .snd i))
          (strict-sym (map-fiber-value n (g ∘ f) b z i)))))

  map-fiber-compose : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y)
    (b : CS.Shell (toNat n) X) (z : N.QuoteFiber n b)
    → outer (cast-fiber n (SF.map-compose n g f b)
        (N.map-fiber n g (S.map-shell n f b) (N.map-fiber n f b z)))
      ≡ˢ outer (N.map-fiber n (g ∘ f) b z)
  map-fiber-compose n g f b z = strict-cong
    (λ p → outer ((g ∘ f ∘ z .fst) , inner p)) (map-fiber-compose-path n g f b z)

  map-fiber-fill-compose : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y)
    (b : CS.Shell (toNat n) X) (z : N.QuoteFiber n b)
    (u : Q.SphereNull n (N.map-fiber n f b z .fst))
    → cast-filler n (SF.map-compose n g f b)
        (F.map-filler n g (S.map-shell n f b)
          (N.fiber-fill n (S.map-shell n f b) (N.map-fiber n f b z) u))
      ≡ N.fiber-fill n (S.map-shell n (g ∘ f) b) (N.map-fiber n (g ∘ f) b z)
          (Q.map-sphere-null n g (N.map-fiber n f b z .fst) u)
  map-fiber-fill-compose n g f b z u =
    cong (cast-filler n (SF.map-compose n g f b))
      (N.fiber-fill-natural n g (S.map-shell n f b) (N.map-fiber n f b z) u)
    ∙ cast-fiber-fill n (SF.map-compose n g f b)
        (N.map-fiber n g (S.map-shell n f b) (N.map-fiber n f b z))
        (Q.map-sphere-null n g (N.map-fiber n f b z .fst) u)
    ∙ cong (λ p → N.fiber-fill n (S.map-shell n (g ∘ f) b)
        ((g ∘ f ∘ z .fst) , p)
        (Q.map-sphere-null n g (N.map-fiber n f b z .fst) u))
        (strict-to-path (map-fiber-compose-path n g f b z))
