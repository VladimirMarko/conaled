{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CompactFiniteness where

-- Constructive bridge from the cover bound of Theorem 6.2.13 to the
-- corrected finite-association argument used in Lemma 6.2.21.
-- The existence of a subcountable Penon-open singleton cover remains an
-- explicit geometric input; this module does not construct manifold atlases.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv using (invEquiv)
open import Cubical.Data.Sigma using (_×_; Σ≡Prop)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Nat.Order using (_<_; isProp≤)
import Cubical.Data.Fin as NatFin
open import Cubical.Data.SumFin using (SumFin≃Fin)
open import Cubical.Data.SubFinSet using (isSubFinSet→isSet)
open import Cubical.Functions.Embedding
  using (compEmbedding; Equiv→Embedding; EmbeddingΣProp)
open import Cubical.Relation.Nullary using (Discrete; Discrete→isSet)
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.Penon using (PenonOpen)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.CountableCovers
  using (CountableProbe; SubcountableIndex; Covers; BoundedSubcover;
         subcountableCoverBound)
open import Orbifolds.Association
  using (SubfiniteSpan; SubfinitelyEnumerable; subfinite-surjection→span;
         subsingleton-cover→enumerability)
open import Orbifolds.ProperFiniteness using (ProperlyFinite; identitySurjection)
open import Orbifolds.Refinements
  using (CountablePenonBasis; SubfiniteRefinement; secondCountableRefinement)
open SubfiniteSpan
open ProperlyFinite
open CountablePenonBasis
open SubfiniteRefinement

private variable ℓ : Level

SingletonMembers : {I K : Type ℓ} → (I → K → hProp ℓ) → Type ℓ
SingletonMembers {I = I} {K = K} U =
  (i : I) {x y : K} → U i x .fst → U i y .fst → x ≡ y

-- Each finite index names at most one point.  It may name no point,
-- and different finite indices may name the same point.  The graph is
-- therefore a genuine subfinite domain surjecting onto K.
boundedSingletonCoverSpan : {K : Type ℓ}
  (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
  SingletonMembers U → (n : ℕ) →
  ((k : K) → ∥ Σ[ i ∈ SubcountableIndex J ] ((i .fst < n) × U i k .fst) ∥₁) →
  SubfiniteSpan K n
Domain (boundedSingletonCoverSpan {K = K} J U singleton n covers) =
  Σ[ a ∈ NatFin.Fin n ] Σ[ j ∈ J (a .fst) .fst ]
    Σ[ k ∈ K ] U (a .fst , j) k .fst
inclusion (boundedSingletonCoverSpan J U singleton n covers) =
  compEmbedding (Equiv→Embedding (invEquiv (SumFin≃Fin n)))
    (EmbeddingΣProp (λ a → isPropΣ (J (a .fst) .snd)
      (λ j → λ { (k , member) (k' , member') →
        Σ≡Prop (λ x → U (a .fst , j) x .snd)
          (singleton (a .fst , j) member member') })))
cover (boundedSingletonCoverSpan J U singleton n covers) =
  (λ { (a , j , k , member) → k }) ,
  (λ k → PT.map
    (λ { ((i , j) , below , member) → ((i , below) , j , k , member) , refl })
    (covers k))

boundedSingletonCover→Enumerable : {K : Type ℓ}
  (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
  SingletonMembers U → BoundedSubcover J U → SubfinitelyEnumerable K
boundedSingletonCover→Enumerable J U singleton =
  PT.map (λ bounded → bounded .fst ,
    boundedSingletonCoverSpan J U singleton (bounded .fst) (bounded .snd))

-- This composes the covering proof with the corrected combinatorial
-- argument.  CountableProbe contains only analytic data about balls and
-- thresholds, independent of K and its cover.
compactSubcountableSingletonCover→Enumerable :
  (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls →
  {K : Type ℓ} → DPCompact K →
  (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
  ((i : SubcountableIndex J) → PenonOpen (U i)) → Covers U →
  SingletonMembers U → SubfinitelyEnumerable K
compactSubcountableSingletonCover→Enumerable balls covering probes compactK
  J U openU covers singleton =
  boundedSingletonCover→Enumerable J U singleton
    (subcountableCoverBound balls covering probes compactK J U openU covers)

compactSubcountableSingletonCover→ProperlyFinite :
  (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls →
  {K : Type ℓ} → DPCompact K → Discrete K →
  (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
  ((i : SubcountableIndex J) → PenonOpen (U i)) → Covers U →
  SingletonMembers U → ProperlyFinite K
enumerable (compactSubcountableSingletonCover→ProperlyFinite
  balls covering probes compactK discreteK J U openU covers singleton) =
  compactSubcountableSingletonCover→Enumerable balls covering probes compactK
    J U openU covers singleton
discrete (compactSubcountableSingletonCover→ProperlyFinite
  balls covering probes compactK discreteK J U openU covers singleton) = discreteK

-- A refinement of a singleton cover still has singleton members.  The
-- witness specifying the original member is eliminated only into a path
-- in the set K.  No selection of an original member is made.
singletonRefinement→Enumerable : {I K : Type ℓ} → isSet K →
  (basis : CountablePenonBasis K) (U : I → K → hProp ℓ) →
  SingletonMembers U → SubfiniteRefinement basis U → SubfinitelyEnumerable K
singletonRefinement→Enumerable {K = K} setK basis U singleton refinement =
  subsingleton-cover→enumerability setK
    (isSubFinSet→isSet (indexSubfinite refinement))
    (λ j k → member refinement j k .fst)
    (λ j k → member refinement j k .snd)
    (covers refinement)
    (λ j {x} {y} hx hy → PT.rec (setK x y)
      (λ { (i , includes) → singleton i (includes x hx) (includes y hy) })
      (refines refinement j))
    (subfinite-surjection→span
      ∣ Index refinement , indexSubfinite refinement , identitySurjection (Index refinement) ∣₁)

-- Relative Lemma 6.2.21: the geometry must supply a second-countable
-- Penon basis and openness of the singleton cover.  The covering and
-- corrected finiteness arguments themselves are fully proved here.
secondCountableCompactSingletonCover→ProperlyFinite :
  (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls →
  {I K : Type ℓ} → DPCompact K → Discrete K →
  (basis : CountablePenonBasis K) (U : I → K → hProp ℓ) →
  ((i : I) → Open basis (U i)) → Covers U →
  SingletonMembers U → ProperlyFinite K
enumerable (secondCountableCompactSingletonCover→ProperlyFinite balls covering
  probes compactK discreteK basis U openU coversU singleton) =
  PT.rec squash₁
    (singletonRefinement→Enumerable (Discrete→isSet discreteK) basis U singleton)
    (secondCountableRefinement balls covering probes compactK basis U openU coversU)
discrete (secondCountableCompactSingletonCover→ProperlyFinite balls covering
  probes compactK discreteK basis U openU coversU singleton) = discreteK

