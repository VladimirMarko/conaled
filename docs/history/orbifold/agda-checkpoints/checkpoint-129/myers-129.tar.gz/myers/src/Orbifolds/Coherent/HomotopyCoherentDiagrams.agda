{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentDiagrams where

-- Quasi-unital, fully homotopy-coherent diagrams in fibrant types.
-- A degree-n cell belongs to a chain of n+1 arrows. Every internal zero
-- face composes arrows; every one face composes FULL prefix/suffix cells
-- on disjoint coordinate blocks. Unit preservation is an actual inner
-- homotopy, never a strict identity imposed on a derived functor.
--
-- The standard quasi-unital interpretation is external model guidance:
-- Tanaka, arXiv:1606.05669, Theorem 1.4; Harpaz, arXiv:1210.0212.
-- Their model-comparison theorems are not silently asserted as Agda terms.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
import Orbifolds.CubicalShells as CS

-- Source-point-first action avoids assuming strict function
-- extensionality over arbitrary source types. Its higher paths are still
-- retained because each action is an actual inner function of that point.
tensor-action : ∀ {ℓ} (n : Dim) (p : Position (osuc n)) {A B C : Type ℓ}
  → (B → Cube (suffix-degree n p) C) → (A → Cube (prefix-degree n p) B) → A → Cube n C
tensor-action n pzero g f a = map-cube n g (f a)
tensor-action (osuc n) (psuc p) g f a i = tensor-action n p (λ b → g b i) f a

module ForCategory {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C
  open Chains.Arrows C

  record Diagram : SSet (ℓ-suc ℓ) where
    field
      Value : Obj → Type ℓ
      action : (n : Dim) {x y : Obj} → Chain n x y → Value x → Cube n (Value y)
      zero-face : (n : Dim) (p : Position (osuc n)) {x y : Obj}
        (c : Chain (osuc n) x y) (a : Value x)
        → outer (coordinate-face n p i0 (action (osuc n) c a))
          ≡ˢ outer (action n (face n p c) a)
      one-face : (n : Dim) (p : Position (osuc n)) {x y : Obj}
        (c : Chain (osuc n) x y) (a : Value x)
        → outer (coordinate-face n p i1 (action (osuc n) c a))
          ≡ˢ outer (tensor-action n p
            (action (suffix-degree n p) (split-suffix n p c))
            (action (prefix-degree n p) (split-prefix n p c)) a)
      unit : (x : Obj) → action ozero (ident x) ≡ (λ a → a)

    unit-is-equivalence : (x : Obj) → isEquiv (action ozero (ident x))
    unit-is-equivalence x = subst isEquiv (sym (unit x)) (idEquiv (Value x) .snd)

    -- Direct verification of the quasi-unit's two mapping-space laws.
    unit-postcompose : ∀ {ℓa} (x : Obj) (A : Type ℓa)
      → (λ (f : A → Value x) a → action ozero (ident x) (f a)) ≡ (λ f → f)
    unit-postcompose x A i f a = unit x i (f a)

    unit-precompose : ∀ {ℓa} (x : Obj) (A : Type ℓa)
      → (λ (f : Value x → A) a → f (action ozero (ident x) a)) ≡ (λ f → f)
    unit-precompose x A i f a = f (unit x i a)

  module StrictEmbedding (E : StrictCubicalExtensionality ℓ) (D : StrictDiagram C ℓ) where
    open StrictCubicalExtensionality E
    module D = StrictDiagram D

    constant : (n : Dim) {X : Type ℓ} → X → Cube n X
    constant n = CS.constant-cube (toNat n)

    constant-face : (n : Dim) (p : Position (osuc n)) (i : I) {X : Type ℓ} (x : X)
      → outer (coordinate-face n p i (constant (osuc n) x)) ≡ˢ outer (constant n x)
    constant-face n pzero i x = reflˢ
    constant-face (osuc n) (psuc p) i x = interval-ext λ j → constant-face n p i x

    map-constant : (n : Dim) {X Y : Type ℓ} (f : X → Y) (x : X)
      → outer (map-cube n f (constant n x)) ≡ˢ outer (constant n (f x))
    map-constant ozero f x = reflˢ
    map-constant (osuc n) f x = interval-ext λ i → map-constant n f x

    tensor-constant : (n : Dim) (p : Position (osuc n)) {A B Y : Type ℓ}
      (g : B → Y) (f : A → B) (a : A)
      → outer (tensor-action n p
          (λ b → constant (suffix-degree n p) (g b))
          (λ a → constant (prefix-degree n p) (f a)) a)
        ≡ˢ outer (constant n (g (f a)))
    tensor-constant n pzero g f a = map-constant n g (f a)
    tensor-constant (osuc n) (psuc p) g f a = interval-ext λ i → tensor-constant n p g f a

    coherent : Diagram
    Diagram.Value coherent = D.Value
    Diagram.action coherent n c a = constant n (D.action (whole n c) a)
    Diagram.zero-face coherent n p c a = strict-trans
      (constant-face n p i0 (D.action (whole (osuc n) c) a))
      (strict-cong (λ f → outer (constant n (D.action (inner f) a)))
        (strict-sym (whole-face n p c)))
    Diagram.one-face coherent n p c a = strict-trans
      (constant-face n p i1 (D.action (whole (osuc n) c) a))
      (strict-trans
        (strict-cong (λ f → outer (constant n (D.action (inner f) a))) (whole-split n p c))
        (strict-trans
          (strict-cong (λ x → outer (constant n (inner x)))
            (D.action-compose-point
              (whole (suffix-degree n p) (split-suffix n p c))
              (whole (prefix-degree n p) (split-prefix n p c)) a))
          (strict-sym (tensor-constant n p
            (D.action (whole (suffix-degree n p) (split-suffix n p c)))
            (D.action (whole (prefix-degree n p) (split-prefix n p c))) a))))
    Diagram.unit coherent x = strict-to-path (D.action-id x)

    action-at-arrow : {x y : Obj} (f : Hom x y) (a : D.Value x)
      → outer (Diagram.action coherent ozero f a) ≡ˢ outer (D.action f a)
    action-at-arrow f a = reflˢ
