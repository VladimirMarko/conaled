{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalShellFunctor where

-- Strict functoriality of the literal finite shell action. The proofs
-- retain the endpoint certificates and use only the existing cubical
-- extensionality structure, not ordinary-index strict funext.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as C
import Orbifolds.Coherent.StrictCubicalShellMaps as S
import Orbifolds.Coherent.StrictCubicalFillers as B
import Orbifolds.CubicalShells as CS

module Functoriality {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module Shell = S.Action E
  module Boundary = B.Boundary E
  module Cube = C.Extensional E

  map-identity : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → outer (Shell.map-shell n (idfun X) b) ≡ˢ outer b
  map-identity ozero (lift tt) = reflˢ
  map-identity (osuc n) {X} b = Boundary.shell-equality n
    (map-cube n (idfun X) (b .fst .fst)) (map-cube n (idfun X) (b .fst .snd))
    (b .fst .fst) (b .fst .snd)
    (Shell.map-shell (osuc n) (idfun X) b .snd) (b .snd)
    (Cube.map-identity n (b .fst .fst)) (Cube.map-identity n (b .fst .snd))
    (λ i → strict-trans (Shell.side-computation n (idfun X) b i)
      (map-identity n (b .snd i)))

  map-compose : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y)
    (b : CS.Shell (toNat n) X)
    → outer (Shell.map-shell n g (Shell.map-shell n f b))
      ≡ˢ outer (Shell.map-shell n (g ∘ f) b)
  map-compose ozero g f b = reflˢ
  map-compose (osuc n) g f b = Boundary.shell-equality n
    (map-cube n g (map-cube n f (b .fst .fst)))
    (map-cube n g (map-cube n f (b .fst .snd)))
    (map-cube n (g ∘ f) (b .fst .fst)) (map-cube n (g ∘ f) (b .fst .snd))
    (Shell.map-shell (osuc n) g (Shell.map-shell (osuc n) f b) .snd)
    (Shell.map-shell (osuc n) (g ∘ f) b .snd)
    (Cube.map-compose n g f (b .fst .fst)) (Cube.map-compose n g f (b .fst .snd))
    (λ i → strict-trans
      (Shell.side-computation n g (Shell.map-shell (osuc n) f b) i)
      (strict-trans
        (strict-cong (λ a → outer (Shell.map-shell n g (inner a)))
          (Shell.side-computation n f b i))
        (strict-trans (map-compose n g f (b .snd i))
          (strict-sym (Shell.side-computation n (g ∘ f) b i)))))
