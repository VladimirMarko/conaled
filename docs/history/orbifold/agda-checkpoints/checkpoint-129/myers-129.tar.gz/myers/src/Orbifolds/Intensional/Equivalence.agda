{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.Equivalence where

-- Equivalences of specified functions, in ordinary intensional MLTT.
-- All geometric types below live at one explicitly fixed level. No
-- function extensionality is used by the fiber and inverse constructions.

open import Agda.Primitive using (Level; Set; lsuc; _⊔_)
open import Orbifolds.Intensional.Identity public
open import Orbifolds.Intensional.BoundedTruncation
open import Orbifolds.Intensional.FiniteBranchAtlas using (InverseData; asEquiv)

private variable ℓ : Level

Fiber : {A B : Set ℓ} → (A → B) → B → Set ℓ
Fiber {A = A} f y = Σ A (λ x → f x ≡ y)

isEquiv : {A B : Set ℓ} → (A → B) → Set ℓ
isEquiv {B = B} f = (y : B) → isContr (Fiber f y)

cong-id : {A : Set ℓ} {x y : A} → (p : x ≡ y) → cong (λ z → z) p ≡ p
cong-id refl = refl

cong-compose : {A B C : Set ℓ} (g : B → C) (f : A → B)
  → {x y : A} → (p : x ≡ y)
  → cong (λ z → g (f z)) p ≡ cong g (cong f p)
cong-compose g f refl = refl

cong₂ : {A B C : Set ℓ} (f : A → B → C)
  → {x x' : A} {y y' : B} → x ≡ x' → y ≡ y'
  → f x y ≡ f x' y'
cong₂ f refl refl = refl

∙-cancel-right : {A : Set ℓ} {x y z : A} {p q : x ≡ y}
  → (r : y ≡ z) → p ∙ r ≡ q ∙ r → p ≡ q
∙-cancel-right {p = p} {q = q} refl e =
  sym (∙-right-unit p) ∙ e ∙ ∙-right-unit q

∙-inverse-cancel-left : {A : Set ℓ} {x y z : A}
  → (p : x ≡ y) → (q : y ≡ z) → sym p ∙ (p ∙ q) ≡ q
∙-inverse-cancel-left p q =
  sym (∙-assoc (sym p) p q) ∙ cong (λ r → r ∙ q) (∙-inverse-left p)

∙-inverse-cancel-right : {A : Set ℓ} {x y z : A}
  → (p : x ≡ y) → (q : y ≡ z) → (p ∙ q) ∙ sym q ≡ p
∙-inverse-cancel-right p q =
  ∙-assoc p q (sym q)
    ∙ cong (λ r → p ∙ r) (∙-inverse-right q)
    ∙ ∙-right-unit p

homotopy-natural : {A B : Set ℓ} {f g : A → B}
  → (h : (x : A) → f x ≡ g x) → {x y : A} → (p : x ≡ y)
  → cong f p ∙ h y ≡ h x ∙ cong g p
homotopy-natural h {x = x} refl = sym (∙-right-unit (h x))

homotopy-id-natural : {A : Set ℓ} (f : A → A)
  → (h : (x : A) → f x ≡ x) → {x y : A} → (p : x ≡ y)
  → cong f p ∙ h y ≡ h x ∙ p
homotopy-id-natural f h {x = x} refl = sym (∙-right-unit (h x))

homotopy-self : {A : Set ℓ} (f : A → A)
  → (h : (x : A) → f x ≡ x) → (x : A)
  → cong f (h x) ≡ h (f x)
homotopy-self f h x = ∙-cancel-right (h x) (homotopy-id-natural f h (h x))

-- A path in an actual fiber, with its path-over equation displayed.
fiber-path : {A B : Set ℓ} (f : A → B) {y : B}
  → {u v : Fiber f y} → (p : fst u ≡ fst v)
  → cong f p ∙ snd v ≡ snd u → u ≡ v
fiber-path f {u = x , p} {v = .x , q} refl square =
  cong (λ r → x , r) (sym square)

ΣPath : {A : Set ℓ} {B : A → Set ℓ} → Σ A B → Σ A B → Set ℓ
ΣPath {B = B} u v = Σ (fst u ≡ fst v) (λ p → subst B p (snd u) ≡ snd v)

Σ-path-code : {A : Set ℓ} {B : A → Set ℓ} {u v : Σ A B}
  → u ≡ v → ΣPath u v
Σ-path-code refl = refl , refl

Σ-path-decode : {A : Set ℓ} {B : A → Set ℓ} {u v : Σ A B}
  → ΣPath u v → u ≡ v
Σ-path-decode (p , q) = Σ-path p q

Σ-path-decode-code : {A : Set ℓ} {B : A → Set ℓ} {u v : Σ A B}
  → (p : u ≡ v) → Σ-path-decode (Σ-path-code p) ≡ p
Σ-path-decode-code refl = refl

Σ-path-code-decode : {A : Set ℓ} {B : A → Set ℓ} {u v : Σ A B}
  → (p : ΣPath u v) → Σ-path-code (Σ-path-decode p) ≡ p
Σ-path-code-decode {u = x , u} {v = .x , .u} (refl , refl) = refl

Σ-path-equivalence : {A : Set ℓ} {B : A → Set ℓ} (u v : Σ A B)
  → Equiv (u ≡ v) (ΣPath u v)
Σ-path-equivalence u v = equiv Σ-path-code Σ-path-decode
  Σ-path-code-decode Σ-path-decode-code

fiber-path-equivalence : {A B : Set ℓ} (f : A → B) {y : B} (u v : Fiber f y)
  → Equiv (u ≡ v)
      (Σ (fst u ≡ fst v) (λ p → subst (λ x → f x ≡ y) p (snd u) ≡ snd v))
fiber-path-equivalence f u v = Σ-path-equivalence u v

-- Adjointify arbitrary inverse data before constructing contractions.
-- The original inverse and left law stay fixed; the right law is adjusted
-- by a specified path, and its triangle identity is proved by naturality.
module Adjoint {A B : Set ℓ} (e : Equiv A B) where
  f : A → B
  f = forward e

  g : B → A
  g = backward e

  η : (x : A) → g (f x) ≡ x
  η = retraction e

  ε : (y : B) → f (g y) ≡ y
  ε = section e

  adjusted-section : (y : B) → f (g y) ≡ y
  adjusted-section y = sym (ε (f (g y))) ∙ cong f (η (g y)) ∙ ε y

  nested-cong : (x : A)
    → cong (λ y → f (g y)) (cong f (η x)) ≡ cong f (η (g (f x)))
  nested-cong x =
    sym (cong-compose (λ y → f (g y)) f (η x))
      ∙ cong-compose f (λ z → g (f z)) (η x)
      ∙ cong (cong f) (homotopy-self (λ z → g (f z)) η x)

  triangle : (x : A) → cong f (η x) ≡ adjusted-section (f x)
  triangle x = sym
    (cong (λ p → sym (ε (f (g (f x)))) ∙ p)
      (sym (cong (λ p → p ∙ ε (f x)) (nested-cong x))
        ∙ homotopy-id-natural (λ y → f (g y)) ε (cong f (η x)))
      ∙ ∙-inverse-cancel-left (ε (f (g (f x)))) (cong f (η x)))

  contraction : {y : B} (x : A) (p : f x ≡ y)
    → (g y , adjusted-section y) ≡ (x , p)
  contraction x refl = fiber-path f (η x)
    (∙-right-unit (cong f (η x)) ∙ triangle x)

equiv→isEquiv : {A B : Set ℓ} (e : Equiv A B) → isEquiv (forward e)
equiv→isEquiv e y =
  (Adjoint.g e y , Adjoint.adjusted-section e y) ,
  (λ { (x , p) → Adjoint.contraction e x p })

isEquiv→Equiv : {A B : Set ℓ} (f : A → B) → isEquiv f → Equiv A B
isEquiv→Equiv f e = equiv f
  (λ y → fst (fst (e y)))
  (λ y → snd (fst (e y)))
  (λ x → cong fst (snd (e (f x)) (x , refl)))

inverseData→isEquiv : {A B : Set ℓ} (f : A → B) → InverseData f → isEquiv f
inverseData→isEquiv f d = equiv→isEquiv (asEquiv f d)

isEquiv→InverseData : {A B : Set ℓ} (f : A → B) → isEquiv f → InverseData f
InverseData.inverse (isEquiv→InverseData f e) = backward (isEquiv→Equiv f e)
InverseData.right-law (isEquiv→InverseData f e) = section (isEquiv→Equiv f e)
InverseData.left-law (isEquiv→InverseData f e) = retraction (isEquiv→Equiv f e)

id-isEquiv : {A : Set ℓ} → isEquiv (λ (x : A) → x)
id-isEquiv = equiv→isEquiv (idEquiv _)

comp-isEquiv : {A B C : Set ℓ} (f : A → B) (g : B → C)
  → isEquiv f → isEquiv g → isEquiv (λ x → g (f x))
comp-isEquiv f g ef eg = equiv→isEquiv
  (compEquiv (isEquiv→Equiv f ef) (isEquiv→Equiv g eg))

left-concat-equivalence : {A : Set ℓ} {x y : A} (p : x ≡ y) (z : A)
  → Equiv (y ≡ z) (x ≡ z)
left-concat-equivalence p z = equiv (λ q → p ∙ q) (λ q → sym p ∙ q)
  (λ q → sym (∙-assoc p (sym p) q) ∙ cong (λ r → r ∙ q) (∙-inverse-right p))
  (∙-inverse-cancel-left p)

-- This equivalence's forward function is precisely cong (forward e).
equiv-path : {A B : Set ℓ} (e : Equiv A B) (x y : A)
  → Equiv (x ≡ y) (forward e x ≡ forward e y)
equiv-path {A = A} e x y = equiv (cong f) inverse-path right-law left-law
  where
  module H = Adjoint e
  f = forward e
  g = backward e
  η = retraction e
  ε = H.adjusted-section

  inverse-path : f x ≡ f y → x ≡ y
  inverse-path p = sym (η x) ∙ cong g p ∙ η y

  right-law : (p : f x ≡ f y) → cong f (inverse-path p) ≡ p
  right-law p =
    cong-∙ f (sym (η x)) (cong g p ∙ η y)
      ∙ cong₂ _∙_ (cong-sym f (η x)) (cong-∙ f (cong g p) (η y))
      ∙ cong₂ _∙_ (cong sym (H.triangle x))
          (cong₂ _∙_ (sym (cong-compose f g p)) (H.triangle y))
      ∙ cong (λ q → sym (ε (f x)) ∙ q)
          (homotopy-id-natural (λ z → f (g z)) ε p)
      ∙ ∙-inverse-cancel-left (ε (f x)) p

  left-law-at : {u v : A} → (p : u ≡ v)
    → sym (η u) ∙ cong g (cong f p) ∙ η v ≡ p
  left-law-at {u = u} refl = ∙-inverse-left (η u)

  left-law : (p : x ≡ y) → inverse-path (cong f p) ≡ p
  left-law = left-law-at

isEquiv-cong : {A B : Set ℓ} (f : A → B) → isEquiv f → (x y : A)
  → isEquiv (λ (p : x ≡ y) → cong f p)
isEquiv-cong f e x y = equiv→isEquiv (equiv-path (isEquiv→Equiv f e) x y)

Σ-fiberwise-equivalence : {A : Set ℓ} {P Q : A → Set ℓ}
  → ((a : A) → Equiv (P a) (Q a)) → Equiv (Σ A P) (Σ A Q)
Σ-fiberwise-equivalence e = equiv
  (λ { (a , p) → a , forward (e a) p })
  (λ { (a , q) → a , backward (e a) q })
  (λ { (a , q) → cong (λ r → a , r) (section (e a) q) })
  (λ { (a , p) → cong (λ r → a , r) (retraction (e a) p) })

fiber-homotopy-equivalence : {A B : Set ℓ} {f g : A → B}
  → ((x : A) → f x ≡ g x) → (y : B) → Equiv (Fiber f y) (Fiber g y)
fiber-homotopy-equivalence h y =
  Σ-fiberwise-equivalence (λ a → left-concat-equivalence (sym (h a)) y)

homotopy-isEquiv : {A B : Set ℓ} (f g : A → B)
  → ((x : A) → f x ≡ g x) → isEquiv f → isEquiv g
homotopy-isEquiv f g h e y = equivPresIsContr (fiber-homotopy-equivalence h y) (e y)

-- Cancel the equivalence on the right (postcomposition), or on the left
-- (precomposition), while retaining the actual remaining function.
cancel-right-isEquiv : {A B C : Set ℓ} (f : A → B) (g : B → C)
  → isEquiv (λ x → g (f x)) → isEquiv g → isEquiv f
cancel-right-isEquiv f g composite eg =
  homotopy-isEquiv (λ x → backward e (g (f x))) f
    (λ x → retraction e (f x))
    (comp-isEquiv (λ x → g (f x)) (backward e)
      composite (equiv→isEquiv (invEquiv e)))
  where
  e = isEquiv→Equiv g eg

cancel-left-isEquiv : {A B C : Set ℓ} (f : A → B) (g : B → C)
  → isEquiv f → isEquiv (λ x → g (f x)) → isEquiv g
cancel-left-isEquiv f g ef composite =
  homotopy-isEquiv (λ y → g (f (backward e y))) g
    (λ y → cong g (section e y))
    (comp-isEquiv (backward e) (λ x → g (f x))
      (equiv→isEquiv (invEquiv e)) composite)
  where
  e = isEquiv→Equiv f ef

-- Fibers of a map over a fixed base are exactly its pointwise fibers.
-- The inverse laws are identity induction on the actual total-space path.
module Fiberwise {A : Set ℓ} {P Q : A → Set ℓ}
    (f : (a : A) → P a → Q a) where
  total : Σ A P → Σ A Q
  total (a , p) = a , f a p

  down : {z : Σ A Q} → Fiber total z → Fiber (f (fst z)) (snd z)
  down ((a , p) , refl) = p , refl

  up : {z : Σ A Q} → Fiber (f (fst z)) (snd z) → Fiber total z
  up {z = a , q} (p , r) = (a , p) , cong (λ s → a , s) r

  down-up : {z : Σ A Q} → (w : Fiber (f (fst z)) (snd z)) → down (up w) ≡ w
  down-up {z = a , .(f a p)} (p , refl) = refl

  up-down : {z : Σ A Q} → (w : Fiber total z) → up (down w) ≡ w
  up-down ((a , p) , refl) = refl

  fiber-equivalence : (z : Σ A Q) → Equiv (Fiber total z) (Fiber (f (fst z)) (snd z))
  fiber-equivalence z = equiv down up down-up up-down

fiberwise→total-isEquiv : {A : Set ℓ} {P Q : A → Set ℓ}
  → (f : (a : A) → P a → Q a)
  → ((a : A) → isEquiv (f a)) → isEquiv (Fiberwise.total f)
fiberwise→total-isEquiv f e z =
  equivPresIsContr (invEquiv (Fiberwise.fiber-equivalence f z)) (e (fst z) (snd z))

total→fiberwise-isEquiv : {A : Set ℓ} {P Q : A → Set ℓ}
  → (f : (a : A) → P a → Q a)
  → isEquiv (Fiberwise.total f) → (a : A) → isEquiv (f a)
total→fiberwise-isEquiv f e a q =
  equivPresIsContr (Fiberwise.fiber-equivalence f (a , q)) (e (a , q))

subst-inverse-return : {A : Set ℓ} (P : A → Set ℓ) {a b : A}
  → (p : a ≡ b) → (q : P b) → subst P p (subst P (sym p) q) ≡ q
subst-inverse-return P refl q = refl

Σ-path-fst : {A : Set ℓ} {P : A → Set ℓ} {u v : Σ A P}
  → (p : fst u ≡ fst v) → (q : subst P p (snd u) ≡ snd v)
  → cong fst (Σ-path p q) ≡ p
Σ-path-fst {u = a , p} {v = .a , .p} refl refl = refl

-- Changing the base of a dependent sum: its fiber over (b,q) is the
-- fiber of the base map over b. The projection on paths is the actual
-- forward map, not an unspecified equivalence of these fiber types.
module BaseChange {A B : Set ℓ} (h : A → B) (P : B → Set ℓ) where
  total : Σ A (λ a → P (h a)) → Σ B P
  total (a , p) = h a , p

  down : {z : Σ B P} → Fiber total z → Fiber h (fst z)
  down ((a , p) , r) = a , cong fst r

  up : {z : Σ B P} → Fiber h (fst z) → Fiber total z
  up {z = b , q} (a , p) =
    (a , subst P (sym p) q) , Σ-path p (subst-inverse-return P p q)

  down-up : {z : Σ B P} → (w : Fiber h (fst z)) → down (up w) ≡ w
  down-up {z = b , q} (a , p) =
    cong (λ r → a , r) (Σ-path-fst p (subst-inverse-return P p q))

  up-down : {z : Σ B P} → (w : Fiber total z) → up (down w) ≡ w
  up-down ((a , p) , refl) = refl

  fiber-equivalence : (z : Σ B P) → Equiv (Fiber total z) (Fiber h (fst z))
  fiber-equivalence z = equiv down up down-up up-down

base-change-isEquiv : {A B : Set ℓ} (h : A → B) (P : B → Set ℓ)
  → isEquiv h → isEquiv (BaseChange.total h P)
base-change-isEquiv h P e z =
  equivPresIsContr (invEquiv (BaseChange.fiber-equivalence h P z)) (e (fst z))

fiber-map : {A B C D : Set ℓ}
  → (u : A → B) (v : C → D) (f : A → C) (g : B → D)
  → ((a : A) → v (f a) ≡ g (u a)) → (b : B) → Fiber u b → Fiber v (g b)
fiber-map u v f g square b (a , p) = f a , square a ∙ cong g p

fiber-map-isEquiv : {A B C D : Set ℓ}
  → (u : A → B) (v : C → D) (f : A → C) (g : B → D)
  → (square : (a : A) → v (f a) ≡ g (u a))
  → isEquiv f → isEquiv g → (b : B) → isEquiv (fiber-map u v f g square b)
fiber-map-isEquiv {A = A} u v f g square ef eg b =
  homotopy-isEquiv (λ z → third (second (first z)))
    (fiber-map u v f g square b) (λ { (a , p) → refl })
    (comp-isEquiv first (λ z → third (second z)) first-equiv
      (comp-isEquiv second third second-equiv third-equiv))
  where
  first : Fiber u b → Σ A (λ a → g (u a) ≡ g b)
  first = Fiberwise.total (λ a → λ p → cong g p)

  second : Σ A (λ a → g (u a) ≡ g b) → Σ A (λ a → v (f a) ≡ g b)
  second = Fiberwise.total (λ a → λ p → square a ∙ p)

  third : Σ A (λ a → v (f a) ≡ g b) → Fiber v (g b)
  third = BaseChange.total f (λ c → v c ≡ g b)

  first-equiv : isEquiv first
  first-equiv = fiberwise→total-isEquiv (λ a → λ p → cong g p)
    (λ a → isEquiv-cong g eg (u a) b)

  second-equiv : isEquiv second
  second-equiv = fiberwise→total-isEquiv (λ a → λ p → square a ∙ p)
    (λ a → equiv→isEquiv (left-concat-equivalence (square a) (g b)))

  third-equiv : isEquiv third
  third-equiv = base-change-isEquiv f (λ c → v c ≡ g b) ef

happly : {A : Set ℓ} {B : A → Set ℓ} {f g : (x : A) → B x}
  → f ≡ g → (x : A) → f x ≡ g x
happly p x = cong (λ h → h x) p

-- This stronger function-extensionality interface is an explicit input.
-- Neither computation law is inferred from an arbitrary weak FunExt.
record CoherentFunExt (ℓ : Level) : Set (lsuc ℓ) where
  field
    ext : FunExt ℓ ℓ
    β : {A : Set ℓ} {B : A → Set ℓ} {f g : (x : A) → B x}
      → (h : (x : A) → f x ≡ g x) → (x : A) → happly (ext h) x ≡ h x
    η : {A : Set ℓ} {B : A → Set ℓ} {f g : (x : A) → B x}
      → (p : f ≡ g) → ext (happly p) ≡ p

happly-equivalence : (E : CoherentFunExt ℓ)
  → {A : Set ℓ} {B : A → Set ℓ} (f g : (x : A) → B x)
  → Equiv (f ≡ g) ((x : A) → f x ≡ g x)
happly-equivalence E f g = equiv happly (CoherentFunExt.ext E)
  (λ h → CoherentFunExt.ext E (CoherentFunExt.β E h))
  (CoherentFunExt.η E)

happly-isEquiv : (E : CoherentFunExt ℓ)
  → {A : Set ℓ} {B : A → Set ℓ} (f g : (x : A) → B x)
  → isEquiv (happly {f = f} {g = g})
happly-isEquiv E f g = equiv→isEquiv (happly-equivalence E f g)

isPropIsEquiv : {A B : Set ℓ} → FunExt ℓ ℓ → (f : A → B) → isProp (isEquiv f)
isPropIsEquiv ext f = isPropΠ ext (λ y → isPropIsContr ext)

isEmbedding : {A B : Set ℓ} → (A → B) → Set ℓ
isEmbedding {B = B} f = (y : B) → isProp (Fiber f y)

isEquiv→isEmbedding : {A B : Set ℓ} (f : A → B) → isEquiv f → isEmbedding f
isEquiv→isEmbedding f e y = isContr→isProp (e y)

path-isEquiv→isEmbedding : {A B : Set ℓ} (f : A → B)
  → ((x y : A) → isEquiv (λ (p : x ≡ y) → cong f p)) → isEmbedding f
path-isEquiv→isEmbedding f paths z (x , p) (y , q) =
  fiber-path f lifted
    (cong (λ r → r ∙ q) comparison
      ∙ ∙-assoc p (sym q) q
      ∙ cong (λ r → p ∙ r) (∙-inverse-left q)
      ∙ ∙-right-unit p)
  where
  e = isEquiv→Equiv (λ (r : x ≡ y) → cong f r) (paths x y)
  lifted = backward e (p ∙ sym q)
  comparison = section e (p ∙ sym q)

module Surjections {ℓ : Level} (T : BoundedTruncation ℓ) where
  module P = Truncation T

  isEquiv→surjective : {A B : Set ℓ} (f : A → B) → isEquiv f → P.Surjective f
  isEquiv→surjective f e y = P.mere (fst (e y))

  embedding-surjection→isEquiv : {A B : Set ℓ} (f : A → B)
    → isEmbedding f → P.Surjective f → isEquiv f
  embedding-surjection→isEquiv f embedding cover y = center , embedding y center
    where
    center : Fiber f y
    center = P.mere-rec-low (embedding y) (λ z → z) (cover y)
