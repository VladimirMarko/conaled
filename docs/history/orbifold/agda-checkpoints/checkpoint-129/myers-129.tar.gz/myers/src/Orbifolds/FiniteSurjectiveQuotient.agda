{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FiniteSurjectiveQuotient where

-- A surjective image of a finite type is finite when the actual kernel
-- relation is decidable. The quotient and its equivalence with the given
-- codomain are constructed; no choice of representatives is required.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Bool using (Dec→Bool; Dec≃DecBool)
open import Cubical.Data.FinSet using (isFinSet; EquivPresIsFinSet)
open import Cubical.Data.FinSet.Quotients using (isFinSetQuot)
open import Cubical.Functions.Embedding
open import Cubical.Functions.Surjection
open import Cubical.Relation.Nullary using (Dec)
open import Cubical.Relation.Binary using (module BinaryRelation)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.SetQuotients as SQ

module Image {ℓ ℓ' : Level} {A : Type ℓ} {X : Type ℓ'}
    (setX : isSet X) (q : A ↠ X) where
  open BinaryRelation

  Kernel : A → A → Type ℓ'
  Kernel a b = q .fst a ≡ q .fst b

  kernel-equivalence : isEquivRel Kernel
  kernel-equivalence = equivRel (λ _ → refl)
    (λ _ _ → sym) (λ _ _ _ → _∙_)

  Quotient : Type (ℓ-max ℓ ℓ')
  Quotient = A SQ./ Kernel

  quotient-map : Quotient → X
  quotient-map = SQ.rec setX (q .fst) (λ _ _ p → p)

  quotient-map-injective : (u v : Quotient)
    → quotient-map u ≡ quotient-map v → u ≡ v
  quotient-map-injective = SQ.elimProp2
    (λ u v → isPropΠ λ _ → SQ.squash/ u v)
    (λ a b → SQ.eq/ a b)

  quotient-map-surjective : isSurjection quotient-map
  quotient-map-surjective x = PT.map
    (λ (a , p) → SQ.[ a ] , p) (q .snd x)

  quotient≃codomain : Quotient ≃ X
  quotient≃codomain = quotient-map , isEmbedding×isSurjection→isEquiv
    (injEmbedding setX (quotient-map-injective _ _) , quotient-map-surjective)

  finite-surjective-image : isFinSet A
    → ((a b : A) → Dec (Kernel a b)) → isFinSet X
  finite-surjective-image finiteA decide = EquivPresIsFinSet quotient≃codomain
    (isFinSetQuot (_ , finiteA) Kernel kernel-equivalence
      (λ a b → Dec→Bool (decide a b) , Dec≃DecBool
        (setX (q .fst a) (q .fst b)) (decide a b)))
