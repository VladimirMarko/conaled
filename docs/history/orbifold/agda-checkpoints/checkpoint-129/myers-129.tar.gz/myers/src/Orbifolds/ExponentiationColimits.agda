{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Actual comparison maps for the pushout/sequence cases of A.0.5.
-- If those maps are equivalences, the corresponding colimits of null
-- vertices are null. No tiny-type or preservation axiom is introduced.
module Orbifolds.ExponentiationColimits where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sequence
open import Cubical.Data.Nat using (ℕ; suc)
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC
import Cubical.HITs.SequentialColimit.Properties as SP

module Pushout {ℓt ℓ : Level} (T : Type ℓt)
  {A B C : Type ℓ} (f : A → B) (g : A → C) where

  Original : Type ℓ
  Original = PO.Pushout f g

  powered-left : (T → A) → (T → B)
  powered-left a = f ∘ a

  powered-right : (T → A) → (T → C)
  powered-right a = g ∘ a

  Powered : Type (ℓ-max ℓt ℓ)
  Powered = PO.Pushout powered-left powered-right

  comparison : Powered → (T → Original)
  comparison (PO.inl b) t = PO.inl (b t)
  comparison (PO.inr c) t = PO.inr (c t)
  comparison (PO.push a i) t = PO.push (a t) i

  Preserved : Type (ℓ-max ℓt ℓ)
  Preserved = isEquiv comparison

  module NullVertices
    (nullA : isEquiv (const :> (A → (T → A))))
    (nullB : isEquiv (const :> (B → (T → B))))
    (nullC : isEquiv (const :> (C → (T → C)))) where

    constant-span : Original ≃ Powered
    constant-span = PO.pushoutEquiv f g powered-left powered-right
      (const , nullA) (const , nullB) (const , nullC) refl refl

    comparison-constant : (x : Original)
      → comparison (equivFun constant-span x) ≡ const x
    comparison-constant (PO.inl b) = refl
    comparison-constant (PO.inr c) = refl
    comparison-constant (PO.push a i) j t = comparison
      (doubleCompPath-filler refl
        (PO.push {f = powered-left} {g = powered-right} (const a)) refl (~ j) i) t

    colimit-null : Preserved → isEquiv (const :> (Original → (T → Original)))
    colimit-null preserved = subst isEquiv (funExt comparison-constant)
      (snd (compEquiv constant-span (comparison , preserved)))

module SequenceColimit {ℓt ℓ : Level} (T : Type ℓt)
  (X : Sequence (ℓ-max ℓt ℓ)) where

  PoweredSequence : Sequence (ℓ-max ℓt ℓ)
  Sequence.obj PoweredSequence n = T → Sequence.obj X n
  Sequence.map PoweredSequence a = Sequence.map X ∘ a

  Original : Type (ℓ-max ℓt ℓ)
  Original = SC.SeqColim X

  Powered : Type (ℓ-max ℓt ℓ)
  Powered = SC.SeqColim PoweredSequence

  comparison : Powered → (T → Original)
  comparison (SC.incl {n} a) t = SC.incl {X = X} {n = n} (a t)
  comparison (SC.push {n} a i) t = SC.push {X = X} {n = n} (a t) i

  Preserved : Type (ℓ-max ℓt ℓ)
  Preserved = isEquiv comparison

  module NullVertices
    (nullX : (n : ℕ) → isEquiv (const :> (Sequence.obj X n → (T → Sequence.obj X n)))) where

    constant-sequence : SequenceEquiv X PoweredSequence
    constant-sequence = sequencemap (λ _ → const) (λ _ _ → refl) , nullX

    constant-colimit : Original ≃ Powered
    constant-colimit = isoToEquiv (SP.sequenceEquiv→ColimIso constant-sequence)

    comparison-constant : (x : Original)
      → comparison (equivFun constant-colimit x) ≡ const x
    comparison-constant (SC.incl x) = refl
    comparison-constant (SC.push {n} x i) j t = comparison
      (compPath-filler (SC.push {X = PoweredSequence} {n = n} (const x)) refl (~ j) i) t

    colimit-null : Preserved → isEquiv (const :> (Original → (T → Original)))
    colimit-null preserved = subst isEquiv (funExt comparison-constant)
      (snd (compEquiv constant-colimit (comparison , preserved)))
