{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispLimits where

-- Native Flat preserves dependent pairs by projections and ordinary
-- Flat elimination.  Pullback preservation then uses the separately
-- named structural crisp-identity rule. External Yoneda below needs
-- only the native Flat core and no additional ambient rule.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI

module Sigma {@♭ ℓ : Level} {@♭ A : Type ℓ} (@♭ B : A → Type ℓ) where
  FlatFamily : Flat A → Type ℓ
  FlatFamily (box a) = Flat (B a)

  Total : Type ℓ
  Total = Σ (Flat A) FlatFamily

  forward : Flat (Σ A B) → Total
  forward (box z) = box (z .fst) , box (z .snd)

  backward : Total → Flat (Σ A B)
  backward (box a , box b) = box (a , b)

  right : (z : Total) → forward (backward z) ≡ z
  right (box a , box b) = refl

  left : (z : Flat (Σ A B)) → backward (forward z) ≡ z
  left (box z) = refl

  flat-sigma-equivalence : Flat (Σ A B) ≃ Total
  flat-sigma-equivalence = isoToEquiv (iso forward backward right left)

module SigmaNaturality {@♭ ℓ : Level} {@♭ A A' : Type ℓ}
  (@♭ B : A → Type ℓ) (@♭ B' : A' → Type ℓ)
  (@♭ f : A → A') (@♭ g : (a : A) → B a → B' (f a)) where
  module Source = Sigma B
  module Target = Sigma B'

  sigma-map : Σ A B → Σ A' B'
  sigma-map (a , b) = f a , g a b

  total-map : Source.Total → Target.Total
  total-map (box a , box b) = box (f a) , box (g a b)

  forward-natural : (z : Flat (Σ A B))
    → Target.forward (flat-map sigma-map z) ≡ total-map (Source.forward z)
  forward-natural (box z) = refl

module Theory {@♭ ℓ : Level} (@♭ rules : CrispIdentityInduction {ℓ}) where
  module Identity = CI.Theory rules

  module PullbackComparison {@♭ A B C : Type ℓ}
    (@♭ f : A → C) (@♭ g : B → C) where
    Pullback : Type ℓ
    Pullback = Σ[ a ∈ A ] Σ[ b ∈ B ] f a ≡ g b

    FlatPullback : Type ℓ
    FlatPullback = Σ[ a ∈ Flat A ] Σ[ b ∈ Flat B ] flat-map f a ≡ flat-map g b

    module Outer = Sigma (λ a → Σ[ b ∈ B ] f a ≡ g b)

    inner-equivalence : (a : Flat A)
      → Outer.FlatFamily a ≃ (Σ[ b ∈ Flat B ] flat-map f a ≡ flat-map g b)
    inner-equivalence (box a) = compEquiv
      (Sigma.flat-sigma-equivalence (λ b → f a ≡ g b))
      (Σ-cong-equiv-snd λ { (box b) → Identity.flat-identity-equivalence (f a) (g b) })

    flat-pullback-equivalence : Flat Pullback ≃ FlatPullback
    flat-pullback-equivalence = compEquiv Outer.flat-sigma-equivalence
      (Σ-cong-equiv-snd inner-equivalence)

    forward : Flat Pullback → FlatPullback
    forward = equivFun flat-pullback-equivalence

    -- The comparison is the actual coordinate map, with the canonical
    -- crisp identity action as its path coordinate.
    forward-box : (@♭ z : Pullback)
      → forward (box z) ≡
        (box (z .fst) , box (z .snd .fst) ,
          Identity.box-path (f (z .fst)) (g (z .snd .fst)) (z .snd .snd))
    forward-box z = refl

    first-projection : (z : Flat Pullback)
      → forward z .fst ≡ flat-map fst z
    first-projection (box z) = refl

    second-projection : (z : Flat Pullback)
      → forward z .snd .fst ≡ flat-map (fst ∘ snd) z
    second-projection (box z) = refl

  -- The exact functional cocone used in the pushout universal property.
  module FunctionalCocone {@♭ A B C : Type ℓ}
    (@♭ f : A → B) (@♭ g : A → C) (@♭ Y : Type ℓ) where
    precompose-left : (B → Y) → (A → Y)
    precompose-left b = b ∘ f

    precompose-right : (C → Y) → (A → Y)
    precompose-right c = c ∘ g

    module Comparison = PullbackComparison precompose-left precompose-right
    open Comparison public renaming
      (Pullback to Cocone; FlatPullback to FlatCocone;
       flat-pullback-equivalence to flat-cocone-equivalence)

  module CoconeNaturality {@♭ A B C Y Z : Type ℓ}
    (@♭ f : A → B) (@♭ g : A → C) (@♭ h : Y → Z) where
    module Source = FunctionalCocone f g Y
    module Target = FunctionalCocone f g Z

    postcompose : Source.Cocone → Target.Cocone
    postcompose (b , c , p) = h ∘ b , h ∘ c , cong (h ∘_) p

    flat-postcompose : Source.FlatCocone → Target.FlatCocone
    flat-postcompose (box b , box c , p) =
      box (h ∘ b) , box (h ∘ c) , cong (flat-map (h ∘_)) p

    forward-natural : (z : Flat Source.Cocone)
      → Target.forward (flat-map postcompose z)
        ≡ flat-postcompose (Source.forward z)
    forward-natural (box z) = cong
      (λ q → box (h ∘ z .fst) , box (h ∘ z .snd .fst) , q)
      (sym (Identity.box-path-natural (h ∘_) (z .fst ∘ f) (z .snd .fst ∘ g)
        (z .snd .snd)))

-- External Yoneda is stronger than mere conservativity of Flat: the
-- premise tests precomposition against every crisp target. The proof
-- only needs the targets A and B and the native Flat functor/counit.
module ExternalYoneda {@♭ ℓ : Level} {@♭ A B : Type ℓ} (@♭ f : A → B) where
  precompose : (@♭ Y : Type ℓ) → (B → Y) → (A → Y)
  precompose Y g = g ∘ f

  DetectsEquivalence : Type (ℓ-suc ℓ)
  DetectsEquivalence = (@♭ Y : Type ℓ) → isEquiv (flat-map (precompose Y))

  proves-equivalence : DetectsEquivalence → isEquiv f
  proves-equivalence external = from-inverse (equivCtr mapsA (box (idfun A)))
    where
    mapsA : Flat (B → A) ≃ Flat (A → A)
    mapsA = flat-map (precompose A) , external A

    mapsB : Flat (B → B) ≃ Flat (A → B)
    mapsB = flat-map (precompose B) , external B

    injectiveB : (u v : Flat (B → B))
      → equivFun mapsB u ≡ equivFun mapsB v → u ≡ v
    injectiveB u v p = sym (retEq mapsB u) ∙ cong (invEq mapsB) p ∙ retEq mapsB v

    from-inverse : fiber (flat-map (precompose A)) (box (idfun A)) → isEquiv f
    from-inverse (box g , p) = isoToIsEquiv (iso f g right-inverse left-inverse)
      where
      left-law : g ∘ f ≡ idfun A
      left-law = cong counit p

      right-law-flat : box (f ∘ g) ≡ box (idfun B)
      right-law-flat = injectiveB (box (f ∘ g)) (box (idfun B))
        (cong (flat-map (f ∘_)) p)

      right-law : f ∘ g ≡ idfun B
      right-law = cong counit right-law-flat

      right-inverse : (y : B) → f (g y) ≡ y
      right-inverse y = funExt⁻ right-law y

      left-inverse : (x : A) → g (f x) ≡ x
      left-inverse x = funExt⁻ left-law x
