{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuoteFiberTransport where

-- Ordinary (inner) paths of shells and quotation fibers retain the
-- dependent filler data. No inner equality is promoted to strict equality.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.GroupoidLaws using (cong-∙)
open import Cubical.Foundations.Transport using (substCommSlice; constSubstCommSlice; substComposite)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as Representation
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.Coherent.NaturalQuotedFillers as Quoted
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

strict-start-composite : ∀ {ℓ} {A : Type ℓ} {a a' b c : A}
  (e : outer a ≡ˢ outer a') (p : a ≡ b) (q : b ≡ c)
  → strict-end-path (λ i → (p ∙ q) i) e reflˢ
    ≡ strict-end-path (λ i → p i) e reflˢ ∙ q
strict-start-composite reflˢ p q = refl

module Transport {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module S = Shells.Action E
  module F = Fillers.Action E
  module R = Representation.Representation E
  module N = Natural.Natural E
  module Q = Quoted.Natural E

  null-along : (n : Dim) {X : Type ℓ} {b : CS.Shell (toNat n) X}
    {z w : N.QuoteFiber n b} (p : z ≡ w)
    → Q.SphereNull n (w .fst) → Q.SphereNull n (z .fst)
  null-along n p (x , q) = x , (cong fst p ∙ q)

  null-transport : (n : Dim) {X : Type ℓ} {b : CS.Shell (toNat n) X}
    {z w : N.QuoteFiber n b} (p : z ≡ w) (u : Q.SphereNull n (w .fst))
    → subst (λ z → Q.SphereNull n (z .fst)) (sym p) u ≡ null-along n p u
  null-transport n p (x , q) = fromPathP (λ i → x , compPath-filler' (cong fst p) q i)

  fiber-fill-path : (n : Dim) {X : Type ℓ} {b : CS.Shell (toNat n) X}
    {z w : N.QuoteFiber n b} (p : z ≡ w) (u : Q.SphereNull n (w .fst))
    → N.fiber-fill n b z (null-along n p u) ≡ N.fiber-fill n b w u
  fiber-fill-path n {b = b} {z = z} p u = sym
    (constSubstCommSlice (λ z → Q.SphereNull n (z .fst)) (CF.Filler (toNat n) b)
      (N.fiber-fill n b) (sym p) u
      ∙ cong (N.fiber-fill n b z) (null-transport n p u))

  move-fiber : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    → b ≡ b' → N.QuoteFiber n b → N.QuoteFiber n b'
  move-fiber n p (h , q) = h , (q ∙ p)

  move-fiber-fill : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    (p : b ≡ b') (z : N.QuoteFiber n b) (u : Q.SphereNull n (z .fst))
    → subst (CF.Filler (toNat n)) p (N.fiber-fill n b z u)
      ≡ N.fiber-fill n b' (move-fiber n p z) u
  move-fiber-fill n p (h , q) u =
    sym (substComposite (CF.Filler (toNat n)) q p (Q.quoted-fill n h u))

  map-filler-subst : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    {b b' : CS.Shell (toNat n) X} (p : b ≡ b') (c : CF.Filler (toNat n) b)
    → F.map-filler n f b' (subst (CF.Filler (toNat n)) p c)
      ≡ subst (CF.Filler (toNat n)) (cong (S.map-shell n f) p) (F.map-filler n f b c)
  map-filler-subst n f p c = sym (substCommSlice (CF.Filler (toNat n))
    (λ b → CF.Filler (toNat n) (S.map-shell n f b)) (F.map-filler n f) p c)

  map-move-fiber : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    {b b' : CS.Shell (toNat n) X} (p : b ≡ b') (z : N.QuoteFiber n b)
    → N.map-fiber n f b' (move-fiber n p z)
      ≡ move-fiber n (cong (S.map-shell n f) p) (N.map-fiber n f b z)
  map-move-fiber n f p (h , q) = ΣPathP (refl ,
    (cong (λ r → strict-end-path (λ i → r i) (R.quote-natural n f h) reflˢ)
      (cong-∙ (S.map-shell n f) q p)
      ∙ strict-start-composite (R.quote-natural n f h)
          (cong (S.map-shell n f) q) (cong (S.map-shell n f) p)))
