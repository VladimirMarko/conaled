{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellRestriction where

-- Literal restriction to the constructed cell cocone. Its isEquiv
-- certificate is sealed separately from the map, so specialization never
-- needs to normalize the whole composite Sigma/Pi equivalence.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedCellAttachments as Attachments
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.CubicalShells as CS
import Cubical.HITs.Pushout as PO

module Representation {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A Index : Type ℓ) (Coefficient : Index → Type ℓ)
    (original-boundary : (c : Index) → CS.Shell (toNat n) (Coefficient c → A)) where
  module Cell = Attachments.Attachment E n A Index Coefficient original-boundary
  module N = Natural.Natural E

  restrict : (Y : Type ℓ) → (Cell.Realize → Y) → Cell.Cocone Y
  restrict Y h = (h ∘ Cell.include) , λ c → N.fiber-fill n
    (Cell.mapped-boundary Y (h ∘ Cell.include) c)
    (N.map-fiber n (λ v → h ∘ Cell.include ∘ v) (original-boundary c)
      (N.canonical-fiber n (original-boundary c)))
    ((λ x → h (Cell.center (c , x))) , (λ i s x → h (PO.push ((c , x) , s) i)))

  computation : (Y : Type ℓ) (h : Cell.Realize → Y)
    → outer (restrict Y h) ≡ˢ outer (Cell.Target.restrict Y h)
  computation Y h = reflˢ

  abstract
    restriction-isEquiv : (Y : Type ℓ) → isEquiv (restrict Y)
    restriction-isEquiv Y = Cell.Target.universal Y .snd

  universal : (Y : Type ℓ) → (Cell.Realize → Y) ≃ Cell.Cocone Y
  universal Y = restrict Y , restriction-isEquiv Y

  canonical-natural : (Y : Type ℓ) (h : Cell.Realize → Y)
    → Cell.postcompose h (Canonical.Canonical.cocone E n A Index Coefficient original-boundary)
      ≡ restrict Y h
  canonical-natural Y h = Canonical.Canonical.natural E n A Index Coefficient original-boundary h

  canonical-original : (Y : Type ℓ) (h : Cell.Realize → Y)
    → cong fst (canonical-natural Y h)
      ≡ strict-to-path (strict-cong (λ k → outer (h ∘ inner k))
          (Canonical.Canonical.original-computation E n A Index Coefficient original-boundary))
  canonical-original Y h = Canonical.Canonical.natural-original E n A Index Coefficient original-boundary h
