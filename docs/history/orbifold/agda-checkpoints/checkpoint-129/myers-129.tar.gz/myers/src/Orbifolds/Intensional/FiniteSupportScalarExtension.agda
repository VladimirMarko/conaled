{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportScalarExtension where

-- Actual scalar extension with a displayed basis of the parameter
-- module. The basis is linear algebra data, not a preservation axiom.
-- The tensor universal property, induced maps, pullback comparison,
-- and augmentation formulas are proved for this constructed object.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( Pullback; FiniteSupport; finite-support-path; map-finite-support; module Square )
open import Orbifolds.Intensional.FiniteSupportUniversal using (additive-zero)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor

private variable ℓ : Level

record LinearEquivalence {R : CommutativeSemiring ℓ} (M N : Semimodule R) : Set ℓ where
  field
    to-linear : LinearMap M N
    from-linear : LinearMap N M
    to-from : (v : Semimodule.Carrier N) → fst to-linear (fst from-linear v) ≡ v
    from-to : (u : Semimodule.Carrier M) → fst from-linear (fst to-linear u) ≡ u

module BasedExtension {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (A : Semimodule R) where

  module F = FreeModule ext classical equality R

  Basis : Set ℓ
  Basis = LinearEquivalence F.Free A

  module WithBasis (basis : Basis) where

    open LinearEquivalence basis renaming
      (to-linear to realize; from-linear to coordinates; to-from to realize-coordinates;
       from-to to coordinates-realize)

    module On (M : Semimodule R) where

      module T = Tensor ext classical equality M

      Extension : Semimodule R
      Extension = T.TensorModule

      pure : Semimodule.Carrier A → Semimodule.Carrier M → Semimodule.Carrier Extension
      pure a v = T.pure (fst coordinates a) v

      pure-left : (v : Semimodule.Carrier M) → LinearMap A Extension
      pure-left v = compose-linear {M = A} {N = F.Free} {P = Extension} (T.pure-left v) coordinates

      pure-right : (a : Semimodule.Carrier A) → LinearMap M Extension
      pure-right a = T.pure-right (fst coordinates a)

      module Universal (N : Semimodule R) where

        module U = T.Universal N

        to-parameter : BilinearMap F.Free M N → BilinearMap A M N
        to-parameter b = (λ a v → fst b (fst coordinates a) v) ,
          ((λ v → snd (compose-linear {M = A} {N = F.Free} {P = N}
            (bilinear-left {L = F.Free} {M = M} {N = N} b v) coordinates)) ,
            (λ a → snd (bilinear-right {L = F.Free} {M = M} {N = N} b (fst coordinates a))))

        to-free : BilinearMap A M N → BilinearMap F.Free M N
        to-free b = (λ a v → fst b (fst realize a) v) ,
          ((λ v → snd (compose-linear {M = F.Free} {N = A} {P = N}
            (bilinear-left {L = A} {M = M} {N = N} b v) realize)) ,
            (λ a → snd (bilinear-right {L = A} {M = M} {N = N} b (fst realize a))))

        basis-bilinear-equivalence : Equiv (BilinearMap F.Free M N) (BilinearMap A M N)
        basis-bilinear-equivalence = equiv to-parameter to-free
          (λ b → bilinear-path ext {L = A} {M = M} {N = N}
            {b = to-parameter (to-free b)} {c = b} (ext (λ a → ext (λ v →
            cong (λ x → fst b x v) (realize-coordinates a)))))
          (λ b → bilinear-path ext {L = F.Free} {M = M} {N = N}
            {b = to-free (to-parameter b)} {c = b} (ext (λ a → ext (λ v →
            cong (λ x → fst b x v) (coordinates-realize a)))))

        scalar-extension-universal : Equiv (LinearMap Extension N) (BilinearMap A M N)
        scalar-extension-universal = compEquiv U.tensor-universal basis-bilinear-equivalence

        universal-forward-is-pure : (h : LinearMap Extension N)
          → (a : Semimodule.Carrier A) (v : Semimodule.Carrier M)
          → fst (forward scalar-extension-universal h) a v ≡ fst h (pure a v)
        universal-forward-is-pure h a v = refl

    module Augmentation (M : Semimodule R) (epsilon : LinearMap M (regular-module R)) where

      module R = CommutativeSemiring R
      module AM = Semimodule A

      tensor-epsilon : LinearMap (On.Extension M) F.Free
      tensor-epsilon = TensorMap.tensor-map ext classical equality M (regular-module R) epsilon

      -- Expose the actual coordinate equation without asking later
      -- unification to unfold all preservation proofs of this map.
      abstract
        augmented-extension : LinearMap (On.Extension M) A
        augmented-extension = compose-linear {M = On.Extension M} {N = F.Free} {P = A} realize tensor-epsilon

        augmentation-evaluation : (w : Semimodule.Carrier (On.Extension M))
          → fst augmented-extension w ≡ fst realize (fst tensor-epsilon w)
        augmentation-evaluation w = refl

      augmentation-on-pure : (a : AM.Carrier) (v : Semimodule.Carrier M)
        → fst augmented-extension (On.pure M a v) ≡ (fst epsilon v) AM.• a
      augmentation-on-pure a v =
        augmentation-evaluation (On.pure M a v)
        ∙ cong (fst realize)
          (TensorMap.tensor-map-on-pure ext classical equality M (regular-module R) epsilon
            (fst coordinates a) v)
        ∙ cong (fst realize) (finite-support-path ext
          {u = Tensor.pure ext classical equality (regular-module R) (fst coordinates a) (fst epsilon v)}
          {v = F.C.scale (fst epsilon v) (fst coordinates a)}
          (ext (λ i → R.*-comm (fst (fst coordinates a) i) (fst epsilon v))))
        ∙ linear-scalar {M = F.Free} {N = A} realize (fst epsilon v) (fst coordinates a)
        ∙ cong (AM._•_ (fst epsilon v)) (realize-coordinates a)

    module AugmentedMap (M N : Semimodule R) (h : LinearMap M N)
        (epsilonM : LinearMap M (regular-module R))
        (epsilonN : LinearMap N (regular-module R))
        (respects : (v : Semimodule.Carrier M) → fst epsilonN (fst h v) ≡ fst epsilonM v) where

      -- Qualified applications select the needed maps/equations. Making
      -- whole aliases of Augmentation here would duplicate every nested
      -- tensor universal-property module twice during elaboration.
      extended-map : FiniteSupport I (Semimodule.zero M) → FiniteSupport I (Semimodule.zero N)
      extended-map = map-finite-support (fst h) (linear-zero {M = M} {N = N} h)

      epsilonM-coordinates : FiniteSupport I (Semimodule.zero M)
        → FiniteSupport I (CommutativeSemiring.zero R)
      epsilonM-coordinates = map-finite-support (fst epsilonM)
        (linear-zero {M = M} {N = regular-module R} epsilonM)

      epsilonN-coordinates : FiniteSupport I (Semimodule.zero N)
        → FiniteSupport I (CommutativeSemiring.zero R)
      epsilonN-coordinates = map-finite-support (fst epsilonN)
        (linear-zero {M = N} {N = regular-module R} epsilonN)

      extension-respects-augmentation : (u : FiniteSupport I (Semimodule.zero M))
        → fst (Augmentation.augmented-extension N epsilonN) (extended-map u)
          ≡ fst (Augmentation.augmented-extension M epsilonM) u
      extension-respects-augmentation u =
        Augmentation.augmentation-evaluation N epsilonN (extended-map u)
        ∙ cong (fst realize)
          {x = epsilonN-coordinates (extended-map u)} {y = epsilonM-coordinates u}
          (finite-support-path ext
            {u = epsilonN-coordinates (extended-map u)} {v = epsilonM-coordinates u}
            (ext (λ i → respects (fst u i))))
        ∙ sym (Augmentation.augmentation-evaluation M epsilonM u)

module TensorSquare {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (D A B C : Semimodule R)
    (u : LinearMap D A) (v : LinearMap D B)
    (f : LinearMap A C) (g : LinearMap B C)
    (commute : (d : Semimodule.Carrier D) → fst g (fst v d) ≡ fst f (fst u d)) where

  module S = Square {I = I} ext
    (Semimodule.zero A) (Semimodule.zero B) (Semimodule.zero C) (Semimodule.zero D)
    (Semimodule.carrier-set C) (fst f) (fst g) (fst u) (fst v)
    (linear-zero {M = A} {N = C} f) (linear-zero {M = B} {N = C} g)
    (linear-zero {M = D} {N = A} u) (linear-zero {M = D} {N = B} v) commute

  tensor-u : LinearMap (Tensor.TensorModule ext classical equality D)
    (Tensor.TensorModule ext classical equality A)
  tensor-u = TensorMap.tensor-map ext classical equality D A u

  tensor-v : LinearMap (Tensor.TensorModule ext classical equality D)
    (Tensor.TensorModule ext classical equality B)
  tensor-v = TensorMap.tensor-map ext classical equality D B v

  tensor-f : LinearMap (Tensor.TensorModule ext classical equality A)
    (Tensor.TensorModule ext classical equality C)
  tensor-f = TensorMap.tensor-map ext classical equality A C f

  tensor-g : LinearMap (Tensor.TensorModule ext classical equality B)
    (Tensor.TensorModule ext classical equality C)
  tensor-g = TensorMap.tensor-map ext classical equality B C g

  original-comparison : Semimodule.Carrier D → Pullback (fst f) (fst g)
  original-comparison d = fst u d , (fst v d , commute d)

  tensor-comparison : FiniteSupport I (Semimodule.zero D)
    → Pullback (fst tensor-f) (fst tensor-g)
  tensor-comparison w = fst tensor-u w , (fst tensor-v w ,
    finite-support-path ext (ext (λ i → commute (fst w i))))

  tensor-comparison-isEquiv : isEquiv original-comparison → isEquiv tensor-comparison
  tensor-comparison-isEquiv = S.extended-comparison-isEquiv

  -- The maps occurring here are the actual induced tensor maps:
  -- TensorMap proves tensor-map-on-pure and tensor-map-is-induced for each.
  -- For any displayed basis of a parameter A0, BasedExtension proves
  -- that these same coordinate objects represent A0 tensor each vertex.

