{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NullCoherentActionUnits where

-- The boundary at a generating point of Null is computed, rather than
-- assumed. Each lower coherent action agrees there with the original
-- strict composite, and every tensor face reduces to that same value.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; endpoint; star)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentActionData using (_≤ᵈ_; same; lower; prefix-bound; suffix-bound)
import Orbifolds.Coherent.HomotopyCoherentActionData as Histories
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Orbifolds.CubicalShells as CS

module Units {ℓ : Level} (C : Category ℓ ℓ) (D : StrictDiagram C ℓ)
    {Ix : Type₀} (S : Ix → Type ℓ) (E : StrictCubicalExtensionality ℓ) where
  open Category C
  module D = StrictDiagram D
  open Chains.Arrows C
  open StrictCubicalExtensionality E
  module Constants = HCD.ForCategory.StrictEmbedding C E D

  M : Modality ℓ
  M = NP.NullModality {ℓ = ℓ} S
  open Modality M using (η; ◯-map)

  Value : Obj → Type ℓ
  Value x = NB.Null S (D.Value x)

  module Data = Histories.Data C Value

  constant : (n : Dim) {X : Type ℓ} → X → Cube n X
  constant n = CS.constant-cube (toNat n)

  AtUnit : (n : Dim) → Data.Actions n → SSet ℓ
  AtUnit n F = (m : Dim) (bound : m ≤ᵈ n) {x y : Obj}
    (c : Chain m x y) (a : D.Value x)
    → outer (Data.at bound F c (η a))
      ≡ˢ outer (constant m (η (D.action (whole m c) a)))

  initial : Data.Actions ozero
  initial f = ◯-map (D.action f)

  initial-coherent : Data.Coherent ozero initial
  initial-coherent = star

  initial-unit : AtUnit ozero initial
  initial-unit .ozero same c a = reflˢ

  -- This uses equality of the particular prefix cube and the suffix
  -- cube at its constant value. It does not require strict function
  -- extensionality over the arbitrary source type.
  tensor-on-constant : (n : Dim) (p : Position (osuc n)) {A B Y : Type ℓ}
    (g : B → Cube (suffix-degree n p) Y)
    (f : A → Cube (prefix-degree n p) B) (a : A) (b : B) (y : Y)
    → outer (f a) ≡ˢ outer (constant (prefix-degree n p) b)
    → outer (g b) ≡ˢ outer (constant (suffix-degree n p) y)
    → outer (tensor-action n p g f a) ≡ˢ outer (constant n y)
  tensor-on-constant n pzero g f a b y prefix suffix = strict-trans
    (strict-cong (λ q → outer (map-cube n g (inner q))) prefix)
    (strict-trans (Constants.map-constant n g b)
      (strict-cong (λ z → outer (constant n (inner z))) suffix))
  tensor-on-constant (osuc n) (psuc p) g f a b y prefix suffix = interval-ext λ i →
    tensor-on-constant n p (λ b → g b i) f a b y prefix
      (strict-cong (λ q → outer (inner q i)) suffix)

  whole-at-split : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (c : Chain (osuc n) x y) (a : D.Value x)
    → outer (η (D.action (whole (osuc n) c) a))
      ≡ˢ outer (η (D.action (whole (suffix-degree n p) (split-suffix n p c))
        (D.action (whole (prefix-degree n p) (split-prefix n p c)) a)))
  whole-at-split n p c a = strict-trans
    (strict-cong (λ f → outer (η (D.action (inner f) a))) (whole-split n p c))
    (strict-cong (λ z → outer (η (inner z)))
      (D.action-compose-point
        (whole (suffix-degree n p) (split-suffix n p c))
        (whole (prefix-degree n p) (split-prefix n p c)) a))

  one-at-unit : (n : Dim) (F : Data.Actions n) → AtUnit n F
    → (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y) (a : D.Value x)
    → outer (Data.one n F p c (η a))
      ≡ˢ outer (constant n (η (D.action (whole (osuc n) c) a)))
  one-at-unit n F at-unit p c a = strict-trans
    (tensor-on-constant n p
      (Data.at (suffix-bound n p) F (split-suffix n p c))
      (Data.at (prefix-bound n p) F (split-prefix n p c)) (η a)
      (η (D.action (whole (prefix-degree n p) (split-prefix n p c)) a))
      (η (D.action (whole (suffix-degree n p) (split-suffix n p c))
        (D.action (whole (prefix-degree n p) (split-prefix n p c)) a)))
      (at-unit (prefix-degree n p) (prefix-bound n p) (split-prefix n p c) a)
      (at-unit (suffix-degree n p) (suffix-bound n p) (split-suffix n p c)
        (D.action (whole (prefix-degree n p) (split-prefix n p c)) a)))
    (strict-cong (λ z → outer (constant n (inner z))) (strict-sym (whole-at-split n p c a)))

  unit-faces : (n : Dim) (F : Data.Actions n) → AtUnit n F
    → {x y : Obj} (c : Chain (osuc n) x y) (a : D.Value x)
    → (p : Position (osuc n)) (e : Endpoint)
    → outer (Data.faces n F c (η a) p e)
      ≡ˢ outer (coordinate-face n p (endpoint e)
        (constant (osuc n) (η (D.action (whole (osuc n) c) a))))
  unit-faces n F at-unit c a p low = strict-trans
    (at-unit n same (face n p c) a)
    (strict-trans
      (strict-cong (λ f → outer (constant n (η (D.action (inner f) a)))) (whole-face n p c))
      (strict-sym (Constants.constant-face n p i0 (η (D.action (whole (osuc n) c) a)))))
  unit-faces n F at-unit c a p high = strict-trans
    (one-at-unit n F at-unit p c a)
    (strict-sym (Constants.constant-face n p i1 (η (D.action (whole (osuc n) c) a))))
