{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentMappingContravariance where

-- An actual coherent transformation induces restriction of cocones.
-- Its action compares all reversed coherence cubes and commutes with
-- actual postcomposition in the target.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces
open import Orbifolds.Coherent.OuterCoordinateReversal using (reverse-coordinates; map-evaluation)
import Orbifolds.Coherent.CoherentArrowReversal as Arrows
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Orbifolds.Coherent.HomotopyCoherentTransformations as Maps
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping

module Contravariance {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HCD.ForCategory.Diagram C)
    (α : Maps.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (FExt : StrictFunctionExtensionality ℓ) where
  open Category C
  module OriginalDiagram = HCD.ForCategory C
  module OriginalMaps = Maps.ForCategory C
  module D = OriginalDiagram.Diagram D
  module G = OriginalDiagram.Diagram G
  module α = OriginalMaps.Transformation α
  module DM = Mapping.Mapping C D E FExt
  module GM = Mapping.Mapping C G E FExt
  module R = Arrows.Reversal C
  module OppMaps = Maps.ForCategory (Opposite C)
  open Extensional E
  open StrictFunctionExtensionality FExt

  Precompose : (Y : Type ℓ) → OppMaps.Transformation (GM.Into Y) (DM.Into Y)
  OppMaps.Transformation.component (Precompose Y) x h = h ∘ α.component x
  OppMaps.Transformation.naturality (Precompose Y) n {x} {y} c h =
    cube-extensionality n λ xs → function-ext λ a → strict-trans
      (strict-cong (λ f → outer (inner f a))
        (map-evaluation n (λ f → f ∘ α.component y) (GM.action n c h) xs))
      (strict-trans
        (GM.action-point n c h xs (α.component y a))
        (strict-trans
          (strict-cong (λ q → outer (h (evaluate n (inner q) (reverse-coordinates n xs))))
            (strict-sym (α.naturality n (R.reverse n c) a)))
          (strict-trans
            (strict-cong (λ b → outer (h (inner b)))
              (map-evaluation n (α.component x) (D.action n (R.reverse n c) a) (reverse-coordinates n xs)))
            (strict-sym (DM.action-point n c (h ∘ α.component x) xs a)))))

  precompose-postcompose : {Y Z : Type ℓ} (k : Y → Z) (x : Obj) (h : G.Value x → Y)
    → outer (OppMaps.Transformation.component (DM.Postcompose k) x
        (OppMaps.Transformation.component (Precompose Y) x h))
      ≡ˢ outer (OppMaps.Transformation.component (Precompose Z) x
        (OppMaps.Transformation.component (GM.Postcompose k) x h))
  precompose-postcompose k x h = reflˢ
