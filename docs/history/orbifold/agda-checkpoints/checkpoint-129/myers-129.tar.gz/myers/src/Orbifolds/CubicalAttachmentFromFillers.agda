{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalAttachmentFromFillers where

-- Given an actually proved finite filler/nullhomotopy representation,
-- construct the next cocone representative as a literal pushout. The
-- particular representation map remains explicit, so its naturality can
-- be used without silently identifying it with a different inverse choice.
-- The boundary computation must be derived from the concrete diagram.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.HITs.Pushout as PO
import Orbifolds.MappingColimits as Mapping
open import Orbifolds.CubicalShells using (Shell)
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)
open import Orbifolds.CubicalShellFillers using (Filler)

module Theory {ℓ : Level} (n : ℕ)
    (evaluate : {X : Type ℓ} → Shell n X → SphereBoundary n → X)
    (filler-nullhomotopy : (X : Type ℓ) (b : Shell n X)
      → Filler n b ≃ (Σ[ center ∈ X ] (evaluate b ≡ (λ _ → center)))) where

  Nullhomotopy : {X : Type ℓ} → Shell n X → Type ℓ
  Nullhomotopy {X} b = Σ[ center ∈ X ] (evaluate b ≡ (λ _ → center))

  module Extension (A Index : Type ℓ) (Coefficient : Index → Type ℓ)
      (boundary-data : (Y : Type ℓ) → (A → Y)
        → (c : Index) → Shell n (Coefficient c → Y))
      (boundary-computation : (Y : Type ℓ) (h : A → Y) (c : Index)
        → evaluate (boundary-data Y h c)
          ≡ (λ s x → h (evaluate (boundary-data A (idfun A) c) s x))) where

    universal-boundary : (c : Index) → Shell n (Coefficient c → A)
    universal-boundary = boundary-data A (idfun A)

    Cell : Type ℓ
    Cell = Σ Index Coefficient

    Boundary : Type ℓ
    Boundary = Cell × SphereBoundary n

    attach : Boundary → A
    attach ((c , x) , s) = evaluate (universal-boundary c) s x

    boundary : Boundary → Cell
    boundary = fst

    Realize : Type ℓ
    Realize = PO.Pushout attach boundary

    include : A → Realize
    include = PO.inl

    center : Cell → Realize
    center = PO.inr

    attaching-computation : (c : Index) (x : Coefficient c) (s : SphereBoundary n)
      → attach ((c , x) , s) ≡ evaluate (universal-boundary c) s x
    attaching-computation c x s = refl

    module Target (Y : Type ℓ) where
      module Ordinary = Mapping.Span attach boundary Y

      Cocone : Type ℓ
      Cocone = Σ[ h ∈ (A → Y) ] ((c : Index) → Filler n (boundary-data Y h c))

      module Fixed (h : A → Y) where
        RawCells : Type ℓ
        RawCells = Σ[ g ∈ (Cell → Y) ] (h ∘ attach ≡ g ∘ boundary)

        composed-boundary : (c : Index) → SphereBoundary n → Coefficient c → Y
        composed-boundary c s x = h (evaluate (universal-boundary c) s x)

        constant-boundary : (c : Index) → (Coefficient c → Y)
          → SphereBoundary n → Coefficient c → Y
        constant-boundary c k s = k

        Coefficientwise : Type ℓ
        Coefficientwise = (c : Index) → Σ[ k ∈ (Coefficient c → Y) ]
          (composed-boundary c ≡ constant-boundary c k)

        split : RawCells → Coefficientwise
        split (g , p) c = (λ x → g (c , x)) , (λ i s x → p i ((c , x) , s))

        join : Coefficientwise → RawCells
        join q = (λ cx → q (cx .fst) .fst (cx .snd)) ,
          (λ i cs → q (cs .fst .fst) .snd i (cs .snd) (cs .fst .snd))

        split-equivalence : RawCells ≃ Coefficientwise
        split-equivalence = isoToEquiv (iso split join (λ _ → refl) (λ _ → refl))

        cell-nullhomotopy : (c : Index)
          → (Σ[ k ∈ (Coefficient c → Y) ]
              (composed-boundary c ≡ constant-boundary c k))
            ≃ Nullhomotopy (boundary-data Y h c)
        cell-nullhomotopy c = Σ-cong-equiv-snd λ k →
          compPathlEquiv (boundary-computation Y h c)

        cell-filler : (c : Index)
          → (Σ[ k ∈ (Coefficient c → Y) ]
              (composed-boundary c ≡ constant-boundary c k))
            ≃ Filler n (boundary-data Y h c)
        cell-filler c = cell-nullhomotopy c ∙ₑ
          invEquiv (filler-nullhomotopy (Coefficient c → Y) (boundary-data Y h c))

        cells-equivalence : RawCells ≃ ((c : Index) → Filler n (boundary-data Y h c))
        cells-equivalence = split-equivalence ∙ₑ equivΠCod cell-filler

      cocone-equivalence : Ordinary.Cocone ≃ Cocone
      cocone-equivalence = Σ-cong-equiv-snd Fixed.cells-equivalence

      universal : (Realize → Y) ≃ Cocone
      universal = Ordinary.universal ∙ₑ cocone-equivalence

      restrict : (Realize → Y) → Cocone
      restrict = universal .fst

      assemble : Cocone → Realize → Y
      assemble = invEq universal

      original-computation : (h : Realize → Y) → restrict h .fst ≡ h ∘ include
      original-computation h = refl

      cell-computation : (h : Realize → Y) (c : Index)
        → restrict h .snd c
          ≡ invEq (filler-nullhomotopy (Coefficient c → Y) (boundary-data Y (h ∘ include) c))
            ((λ x → h (center (c , x))) ,
              (boundary-computation Y (h ∘ include) c
                ∙ (λ i s x → h (PO.push ((c , x) , s) i))))
      cell-computation h c = refl

      assemble-restrict : (h : Realize → Y) → assemble (restrict h) ≡ h
      assemble-restrict = retEq universal

      restrict-assemble : (c : Cocone) → restrict (assemble c) ≡ c
      restrict-assemble = secEq universal

    canonical-cocone : Target.Cocone Realize
    canonical-cocone = Target.restrict Realize (idfun Realize)

    canonical-original : canonical-cocone .fst ≡ include
    canonical-original = refl
