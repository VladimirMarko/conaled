{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentTensorNaturality where

-- Pointwise naturality of the full disjoint-coordinate tensor. The
-- hypotheses concern individual action cubes, never strict equality
-- of arbitrary source-parametrized functions.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)

module Naturality {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  map-square : (n : Dim) {A B C D : Type ℓ}
    (left : A → B) (right : C → D) (bottom : B → D) (top : A → C)
    → ((a : A) → outer (bottom (left a)) ≡ˢ outer (right (top a)))
    → (c : Cube n A)
    → outer (map-cube n bottom (map-cube n left c))
      ≡ˢ outer (map-cube n right (map-cube n top c))
  map-square ozero left right bottom top square c = square c
  map-square (osuc n) left right bottom top square c = interval-ext λ i →
    map-square n left right bottom top square (c i)

  tensor-natural : (n : Dim) (p : Position (osuc n))
    {A B C A' B' C' : Type ℓ}
    (source : A → A') (middle : B → B') (target : C → C')
    (g : B → Cube (suffix-degree n p) C)
    (f : A → Cube (prefix-degree n p) B)
    (g' : B' → Cube (suffix-degree n p) C')
    (f' : A' → Cube (prefix-degree n p) B') (a : A)
    → outer (f' (source a)) ≡ˢ outer (map-cube (prefix-degree n p) middle (f a))
    → ((b : B) → outer (g' (middle b)) ≡ˢ outer (map-cube (suffix-degree n p) target (g b)))
    → outer (tensor-action n p g' f' (source a))
      ≡ˢ outer (map-cube n target (tensor-action n p g f a))
  tensor-natural n pzero source middle target g f g' f' a prefix suffix = strict-trans
    (strict-cong (λ c → outer (map-cube n g' (inner c))) prefix)
    (map-square n middle target g' g suffix (f a))
  tensor-natural (osuc n) (psuc p) source middle target g f g' f' a prefix suffix = interval-ext λ i →
    tensor-natural n p source middle target (λ b → g b i) f (λ b → g' b i) f' a prefix
      (λ b → strict-cong (λ c → outer (inner c i)) (suffix b))
