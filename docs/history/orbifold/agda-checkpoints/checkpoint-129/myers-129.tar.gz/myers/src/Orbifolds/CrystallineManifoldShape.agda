{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CrystallineManifoldShape where

-- The geometric conclusion of Lemma 6.3.4 for an arbitrary crystalline
-- subspace of an ordinary manifold. A constructive finite chain through
-- rational grid intervals removes the earlier separated-equality premise.
-- Shape modality remains distinct from ordinary decidable equality.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Functions.Embedding using (_↪_)
open import Cubical.Algebra.CommRing.Base

open import Orbifolds.Topology using (Topology)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallineEuclidean as CE
import Orbifolds.OrdinaryCharts as OC
import Orbifolds.CountableRealProbe as RP
import Orbifolds.CompactIntervals as IC
import Orbifolds.IntervalParameterization as IP
import Orbifolds.CrystallineManifoldCurves as MC
import Orbifolds.LocallyConstantIntervals as LC

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
    (constancy : CE.Ring.PrincipleOfConstancy R) where
  open CommRingStr (R .snd) using (0r)
  open CR.Ring R
  module Local = MC.Geometry R kock order compatibility constancy
  module Global = LC.Curves R kock order compatibility
  module Probe = RP.RealProbe R kock order compatibility
  module Intervals = IC.Interpolation R kock order compatibility
  module Param = IP.Parameterization R kock order compatibility

  module Manifold (n : ℕ) {M : Type ℓ}
      (euclidean-topology : Topology (FD.Fin n → Carrier))
      (manifold : OC.Geometry.OrdinaryManifold R n M euclidean-topology) where
    module Charts = Local.Manifold n euclidean-topology manifold

    module Subspace {C : Type ℓ} (embedding : C ↪ M) (modalC : IsCrystalline C) where
      module Piece = Charts.Subspace embedding modalC

      crystalline-curves-constant : CoveringProperty Probe.intervalBalls
        → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence
        → (γ : Carrier → C) → (s t : Carrier) → γ s ≡ γ t
      crystalline-curves-constant covering compact-interval exponential γ =
        Global.Curve.globallyConstant Piece.setC γ
          (Piece.crystalline-curves-locally-constant covering exponential γ)
          covering compact-interval

      crystalline-subspace-shape-modal : CoveringProperty Probe.intervalBalls
        → Intervals.UnitIntervalCompact → Param.PositiveLineEquivalence → IsShapeModal C
      crystalline-subspace-shape-modal covering compact-interval exponential _ =
        fromIsEquiv const (isoToIsEquiv (iso const (λ γ → γ 0r)
          (λ γ → funExt λ t → crystalline-curves-constant
            covering compact-interval exponential γ 0r t)
          (λ _ → refl)))
