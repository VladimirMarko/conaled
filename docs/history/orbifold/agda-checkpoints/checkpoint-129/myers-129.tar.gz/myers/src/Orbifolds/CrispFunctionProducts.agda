{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispFunctionProducts where

-- The actual Flat comparison for functions indexed by lifted Nat.
-- The equivalence is derived from CrispProducts; no product-preservation
-- or choice assertion is added. External equivalences consequently lift
-- through this countable function space.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispNaturalDiscreteness as CN
import Orbifolds.CrispProducts as CP

LiftedNat : {@♭ ℓ : Level} → Type ℓ
LiftedNat {ℓ} = Lift {j = ℓ} ℕ

module Family {@♭ ℓ : Level} (@♭ X : Type ℓ) where
  module Constants = CP.Family ℕ (λ _ → X)

  domain-equivalence : (LiftedNat {ℓ} → X) ≃ (ℕ → X)
  domain-equivalence = isoToEquiv
    (iso (λ f n → f (lift n)) (λ f n → f (lower n))
      (λ _ → refl) (λ _ → refl))

  fibre-equivalence : (u : Flat ℕ) → Constants.FlatFamily u ≃ Flat X
  fibre-equivalence (box n) = idEquiv (Flat X)

  flatten-equivalence : Constants.Product ≃ (Flat ℕ → Flat X)
  flatten-equivalence = equivΠCod fibre-equivalence

  comparison : Flat (LiftedNat {ℓ} → X) → (Flat ℕ → Flat X)
  comparison (box f) (box n) = box (f (lift n))

module Context {@♭ ℓ : Level}
  (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
  (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
  (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
  (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
  (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
  (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
  (@♭ R : Type ℓ) where
  module Identity = CI.Theory identity-rules
  module Naturals = CN.Theory identity-zero flat-zero flat-zero-computation

  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = (@♭ X : Type ℓ)
    → CrisplyDiscrete X ≃ isEquiv (const :> (X → (R → X)))

  module At (@♭ X : Type ℓ) where
    module F = Family X

    module Proof (real-flat : RealFlat) where
      module Products = F.Constants.WithCohesion
        identity-rules flat-induction flat-computation R real-flat
      module Discrete = Products.DiscreteIndex Naturals.naturals-discrete

      derived-equivalence : Flat (LiftedNat {ℓ} → X) ≃ (Flat ℕ → Flat X)
      derived-equivalence = Identity.flat-equivalence F.domain-equivalence ∙ₑ
        Discrete.flat-product-equivalence ∙ₑ F.flatten-equivalence

      comparison-agrees : (f : Flat (LiftedNat {ℓ} → X))
        → equivFun derived-equivalence f ≡ F.comparison f
      comparison-agrees (box f) = funExt λ { (box n) → refl }

      flat-function-equivalence : Flat (LiftedNat {ℓ} → X) ≃ (Flat ℕ → Flat X)
      flat-function-equivalence = F.comparison , subst isEquiv
        (funExt comparison-agrees) (derived-equivalence .snd)

  module Map {@♭ X Y : Type ℓ} (@♭ h : X → Y) where
    postcompose : (LiftedNat {ℓ} → X) → (LiftedNat {ℓ} → Y)
    postcompose f = h ∘ f

    pointwise : (Flat ℕ → Flat X) → (Flat ℕ → Flat Y)
    pointwise f u = flat-map h (f u)

    comparison-natural : (f : Flat (LiftedNat {ℓ} → X))
      → Family.comparison Y (flat-map postcompose f)
        ≡ pointwise (Family.comparison X f)
    comparison-natural (box f) = funExt λ { (box n) → refl }

    external-power-preservation : (real-flat : RealFlat)
      → isEquiv (flat-map h) → isEquiv (flat-map postcompose)
    external-power-preservation real-flat external =
      isEquiv[equivFunA≃B∘f]→isEquiv[f] (flat-map postcompose)
        (At.Proof.flat-function-equivalence Y real-flat)
        (subst isEquiv (sym (funExt comparison-natural))
          (compEquiv (At.Proof.flat-function-equivalence X real-flat)
            (equivΠCod (λ _ → flat-map h , external)) .snd))
