{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarInterface where

-- Small, computational access to the constructed power comparison.
-- Every implementation is the original map or witness.  The facades
-- avoid copying the unrelated proof namespaces of the complete bar
-- construction when checking its transition and canonicality proofs.
-- Transparent theorem aliases infer the complete type of their checked
-- right-hand sides; the mandatory no-unsolved-metas gate closes them.
-- Keep the filtered module application separate from its open: Agda's
-- named `open module` shorthand applies its filter only to the open.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowers as Powers
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as FiniteRestriction
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStepCoherenceData as Stages
import Orbifolds.Coherent.HomotopyCoherentColimitPresentation as Presentations
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Mapping
import Orbifolds.Coherent.HomotopyCoherentPowerBarStages as PowerStages
import Orbifolds.Coherent.HomotopyCoherentFiniteCellSuccessors as Successors
import Orbifolds.CellularPresentations as CP
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module Power = Powers.Construction C E F T using (Power; evaluation)
  module RD = Represented.Induction C D E F using (Represented; module Represented; initial)
  module RP = Represented.Induction C (Power.Power D) E F using (Represented; module Represented; initial)
  module CD = Cocones.Functoriality C D E F using (Cocone; postcompose; postcompose-compose)
  module CPow = Cocones.Functoriality C (Power.Power D) E F
    using (Cocone; postcompose; postcompose-compose)

  module OriginalStages where
    module Step (n : Dim) (previous : RD.Represented n) where
      module Data = Stages.Step C D E F n previous
        using (Realize; next; canonical-cocone; cell-cocone;
          cell-original-computation; transition-computation)
      open Data public
      module Cell where
        include : RD.Represented.Space previous → Realize
        include = PO.inl

  module PoweredStages where
    module Step (n : Dim) (previous : RP.Represented n) where
      module Data = Stages.Step C (Power.Power D) E F n previous
        using (Realize; next; canonical-cocone; cell-cocone;
          cell-original-computation; transition-computation)
      open Data public
      module Cell where
        include : RP.Represented.Space previous → Realize
        include = PO.inl

  module Original where
    module PresentationData = Presentations.Construction C D E F
      using (Initial; presentation; bar-presentation; Colimit; canonical-cocone)
    open PresentationData public
    module Realization = CP.Realization Initial bar-presentation
      using (Stage; state; stages; inclusion)
    module MappingOut (Y : Type ℓ) where
      module MappingData = Mapping.Construction.MappingOut C D E F Y
        using (Cocone; PartialCocone; drop; finite-witness; witness-at;
          stage-universal; stage-square; universal; restrict; compatibility-computation)
      open MappingData public
      module Witnesses = Mapping.Construction.MappingOut.Witnesses C D E F Y
        using (Witness; module Witness)

      stage-computation : _
      stage-computation = Presentations.Construction.MappingOut.stage-computation C D E F Y

  module Powered where
    module PresentationData = Presentations.Construction C (Power.Power D) E F
      using (Initial; presentation; bar-presentation; Colimit; canonical-cocone)
    open PresentationData public
    module Realization = CP.Realization Initial bar-presentation
      using (Stage; state; stages; inclusion)
    module MappingOut (Y : Type ℓ) where
      module MappingData = Mapping.Construction.MappingOut C (Power.Power D) E F Y
        using (Cocone; PartialCocone; drop; finite-witness; witness-at;
          stage-universal; stage-square; universal; restrict; compatibility-computation)
      open MappingData public
      module Witnesses = Mapping.Construction.MappingOut.Witnesses C (Power.Power D) E F Y
        using (Witness; module Witness)

      stage-computation : _
      stage-computation = Presentations.Construction.MappingOut.stage-computation C (Power.Power D) E F Y

  module R (t : T) (Y : Type ℓ) where
    finite-restriction : (n : Dim) → CD.Cocone Y n → CPow.Cocone Y n
    finite-restriction = FiniteRestriction.Restriction.finite-restriction C (Power.Power D) D
      (Power.evaluation D t) E F Y

    partial-map : (n : ℕ)
      → Original.MappingOut.PartialCocone Y n → Powered.MappingOut.PartialCocone Y n
    partial-map = Restriction.Restriction.partial-map C (Power.Power D) D (Power.evaluation D t) E F Y

    restrict : Original.MappingOut.Cocone Y → Powered.MappingOut.Cocone Y
    restrict = Restriction.Restriction.restrict C (Power.Power D) D (Power.evaluation D t) E F Y

    module Action where
      module Data = Restriction.Restriction.Action C (Power.Power D) D
        (Power.evaluation D t) E F Y
        using (Morphism; module Morphism; finite-morphism; morphism-at)
      open Data public
      module Source = Restriction.Restriction.Action.Source C (Power.Power D) D
        (Power.evaluation D t) E F Y using (Schedule; module Schedule; PartialCone; stage-schedule; drop)
      module Target = Restriction.Restriction.Action.Target C (Power.Power D) D
        (Power.evaluation D t) E F Y using (Schedule; module Schedule; PartialCone; stage-schedule; drop)
      module SourceFinite = Restriction.Restriction.Action.SourceFinite C (Power.Power D) D
        (Power.evaluation D t) E F Y using (Carrier; finite-state)
      module TargetFinite = Restriction.Restriction.Action.TargetFinite C (Power.Power D) D
        (Power.evaluation D t) E F Y using (Carrier; finite-state)

  module StateData = PowerStages.Construction C D E F T
    using (State; module State; initial; advance)
  open StateData public

  module Step (n : Dim) (original : RD.Represented n) (powered : RP.Represented n)
      (previous : State n original powered) where
    module StepValues = PowerStages.Construction.Step C D E F T n original powered previous
      using (on-boundary; on-cell; attachment-square; boundary-square;
        q; evaluation-computation; triangle)
    open StepValues public
    module OD = OriginalStages.Step n original
    module PP = PoweredStages.Step n powered
    module Point (t : T) where
      module PointValues = Successors.Construction C (Power.Power D) D (Power.evaluation D t)
        E F n powered original (λ x → State.q previous x t) (State.triangle previous t)
        using (canonical-triangle; module Cell)
      open PointValues public using (canonical-triangle)
      module Cell = PointValues.Cell using (induced)
