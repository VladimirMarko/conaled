{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FirstOrderKockLawvere where

-- Postulate J on the constructed square-zero Weil algebra implies the
-- unique affine-coordinate expansion for every map D(n)→R.  This is
-- derived from the actual algebra normal form, not separately assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommAlgebra.Base
import Cubical.Algebra.Ring.BigOps as BO
import Orbifolds.WeilAlgebras as WA
import Orbifolds.WeilPresentation as WP
import Orbifolds.SquareZeroWeil as SW
import Orbifolds.SquareZeroExtensions as SE
import Orbifolds.SquareZeroNormalForm as NF
import Orbifolds.FirstOrderInfinitesimalLinearity as IL

module Ring {ℓ : Level} (R : CommRing ℓ) (KL : WA.Weil.KockLawvere R) where
  open CommRingStr (R .snd)
  module W = WA.Weil R
  module Present = WP.Presentations R
  module Disks = IL.Ring R
  module S = BO.Sum (CommRing→Ring R)

  module Dimension (n : ℕ) where
    module Algebra = SW.Coordinates R n
    module Jet = SE.Extension R n
    module Normal = NF.Coordinates R n
    module P = Algebra.P

    linear : Jet.Vector → Disks.D n → R .fst
    linear v d = S.∑ (λ i → v i · d .fst i)

    affine : Jet.Jet → Disks.D n → R .fst
    affine (r , v) d = r + linear v d

    linear-origin : (v : Jet.Vector) → linear v (Disks.zeroD n) ≡ 0r
    linear-origin v = S.∑Mulr0 v

    affine-origin : (rv : Jet.Jet) → affine rv (Disks.zeroD n) ≡ rv .fst
    affine-origin (r , v) = cong (r +_) (linear-origin v) ∙ +IdR r

    module Evaluation (φ : W.Spec Algebra.weil) where
      module SM = BO.SumMap (CommRing→Ring (P.fpAlg .fst)) (CommRing→Ring R)
        (CommRingHom→RingHom (CommAlgebraHom→CommRingHom φ))

      evaluate-normal-form : (rv : Jet.Jet)
        → φ .fst (Normal.from-jet rv)
          ≡ rv .fst + S.∑ (λ i → rv .snd i · φ .fst (P.generator i))
      evaluate-normal-form (r , v) =
        IsCommAlgebraHom.pres+ (φ .snd) (Normal.scalar r) (Normal.linear v)
        ∙ cong₂ _+_ (Present.scalar-preserved φ r)
          (SM.∑Map (λ i → Normal.QR._·_ (Normal.scalar (v i)) (P.generator i))
            ∙ S.∑Ext (λ i → IsCommAlgebraHom.pres· (φ .snd) (Normal.scalar (v i)) (P.generator i)
              ∙ cong (_· φ .fst (P.generator i)) (Present.scalar-preserved φ (v i))))

    underlying-equivalence : Jet.Jet ≃ (Disks.D n → R .fst)
    underlying-equivalence = invEquiv Normal.equivalence
      ∙ₑ W.evaluation-equivalence P.fpAlg (KL Algebra.weil) .fst
      ∙ₑ preCompEquiv (invEquiv Algebra.spectrum≃disk)

    comparison-agrees : equivFun underlying-equivalence ≡ affine
    comparison-agrees = funExt λ rv → funExt λ d →
      Evaluation.evaluate-normal-form (invEq Algebra.spectrum≃disk d) rv
      ∙ cong (rv .fst +_) (S.∑Ext λ i →
        cong (rv .snd i ·_) (cong (λ z → z .fst i) (secEq Algebra.spectrum≃disk d)))

    affine-isEquiv : isEquiv affine
    affine-isEquiv = subst isEquiv comparison-agrees (underlying-equivalence .snd)

    affine-equivalence : Jet.Jet ≃ (Disks.D n → R .fst)
    affine-equivalence = affine , affine-isEquiv

    PointedFunctions : Type ℓ
    PointedFunctions = Σ[ f ∈ (Disks.D n → R .fst) ] f (Disks.zeroD n) ≡ 0r

    linear-pointed : Jet.Vector → PointedFunctions
    linear-pointed v = linear v , linear-origin v

    coefficients : PointedFunctions → Jet.Vector
    coefficients f = invEq affine-equivalence (f .fst) .snd

    recovered-constant-zero : (f : PointedFunctions)
      → invEq affine-equivalence (f .fst) .fst ≡ 0r
    recovered-constant-zero f =
      sym (affine-origin (invEq affine-equivalence (f .fst)))
      ∙ cong (λ h → h (Disks.zeroD n)) (secEq affine-equivalence (f .fst))
      ∙ f .snd

    linear-reconstruction : (f : PointedFunctions) → linear-pointed (coefficients f) ≡ f
    linear-reconstruction f = Σ≡Prop (λ _ → is-set _ _) (funExt λ d →
      sym (+IdL (linear (coefficients f) d))
      ∙ cong (_+ linear (coefficients f) d) (sym (recovered-constant-zero f))
      ∙ cong (λ h → h d) (secEq affine-equivalence (f .fst)))

    coefficients-linear : (v : Jet.Vector) → coefficients (linear-pointed v) ≡ v
    coefficients-linear v = cong snd
      (cong (invEq affine-equivalence) (sym (funExt λ d → +IdL (linear v d)))
        ∙ retEq affine-equivalence (0r , v))

    linear-equivalence : Jet.Vector ≃ PointedFunctions
    linear-equivalence = isoToEquiv
      (iso linear-pointed coefficients linear-reconstruction coefficients-linear)
