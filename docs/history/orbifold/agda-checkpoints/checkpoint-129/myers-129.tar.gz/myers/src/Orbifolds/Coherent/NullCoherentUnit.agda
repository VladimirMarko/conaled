{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NullCoherentUnit where

-- The native unit is an actual transformation of ALL coherent action
-- cubes. This is the concrete map used to compare bar constructions.

open import Cubical.Foundations.Prelude
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Orbifolds.Coherent.HomotopyCoherentTransformations as Maps
import Orbifolds.Coherent.NullHomotopyCoherentDiagram as Null
import Orbifolds.Coherent.NullCoherentActionUnits as Units
import Orbifolds.Coherent.CoherentArrowChains as Chains

module UnitTransformation {ℓ : Level} (C : Category ℓ ℓ) (D : StrictDiagram C ℓ)
    {Ix : Type₀} (S : Ix → Type ℓ) (E : StrictCubicalExtensionality ℓ) where
  module Original = HCD.ForCategory.StrictEmbedding C E D
  module Reflected = Null.Reflection C D S E
  module U = Units.Units C D S E
  module Arrows = Chains.Arrows C
  open Modality U.M using (η)
  open Maps.ForCategory C

  unit : Transformation Original.coherent Reflected.reflected
  Transformation.component unit x = η
  Transformation.naturality unit n c a = strict-trans
    (Original.map-constant n η (StrictDiagram.action D (Arrows.whole n c) a))
    (strict-sym (Reflected.action-at-unit n c a))
