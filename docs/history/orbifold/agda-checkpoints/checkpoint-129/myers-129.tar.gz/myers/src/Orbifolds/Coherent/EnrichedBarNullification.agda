{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarNullification where

-- The actual coefficientwise nullification map at every finite bar
-- degree, and its naturality for maps of indices and coefficients.
-- Naturality is an inner path derived by nullification induction; it is
-- not advertised as a strict enriched functor law.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.NullSigmaReflection as NSR
import Orbifolds.NullificationSphereCells as NSC
import Orbifolds.Coherent.StrictEnriched as E
import Orbifolds.Coherent.EnrichedBarChains as BC
import Orbifolds.Coherent.EnrichedBarDiscreteness as BD

module Comparison {ℓ : Level} {Ix : Type₀} (S : Ix → Type ℓ)
    (J : Type ℓ) (A : J → Type ℓ) where
  compare : (Σ[ j ∈ J ] NB.Null S (A j)) → NB.Null S (Σ J A)
  compare (j , x) = NP.rec (NB.isNull-Null S) (λ a → NB.∣ j , a ∣) x

  unit-computation : (j : J) (a : A j)
    → compare (j , NB.∣ a ∣) ≡ NB.∣ j , a ∣
  unit-computation j a = refl

  comparison-isEquiv : NB.isNull S J → isEquiv compare
  comparison-isEquiv null-index = isoToIsEquiv (iso compare
    (NSR.Theory.Over.comparison S J null-index A)
    (NSR.Theory.Over.backward-comparison S J null-index A)
    (NSR.Theory.Over.comparison-backward S J null-index A))

module Naturality {ℓ : Level} {Ix : Type₀} (S : Ix → Type ℓ)
    {J K : Type ℓ} (A : J → Type ℓ) (B : K → Type ℓ)
    (index-map : J → K) (coefficient-map : (j : J) → A j → B (index-map j)) where
  total-map : Σ J A → Σ K B
  total-map (j , a) = index-map j , coefficient-map j a

  reflected-total-map : NB.Null S (Σ J A) → NB.Null S (Σ K B)
  reflected-total-map = NP.rec (NB.isNull-Null S) (NB.∣_∣ ∘ total-map)

  coefficientwise-map : (Σ[ j ∈ J ] NB.Null S (A j)) → (Σ[ k ∈ K ] NB.Null S (B k))
  coefficientwise-map (j , x) = index-map j ,
    NP.rec (NB.isNull-Null S) (NB.∣_∣ ∘ coefficient-map j) x

  comparison-natural : (z : Σ[ j ∈ J ] NB.Null S (A j))
    → reflected-total-map (Comparison.compare S J A z)
      ≡ Comparison.compare S K B (coefficientwise-map z)
  comparison-natural (j , x) = NP.elim
    {Y = λ z → reflected-total-map (Comparison.compare S J A (j , z))
      ≡ Comparison.compare S K B (coefficientwise-map (j , z))}
    (λ _ → NP.isNull≡ (NB.isNull-Null S)) (λ _ → refl) x

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ Ix : Type₀) (@♭ S : Ix → Type ℓ)
    (@♭ C : E.Category ℓ ℓ) where
  open E.Category C
  module Chains = BC.Chains C
  module Externality = BD.Context identity-rules identity-zero flat-zero flat-zero-computation C
  module NullIndices = NSC.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R r₀ Ix S
  open NullIndices using (RealFlat; TinyFamily) public

  indices-null : RealFlat → CrisplyDiscrete Ix → TinyFamily → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → (n : ℕ) → NB.isNull S (Chains.Index n)
  indices-null real-flat discrete-generators tiny discrete-objects discrete-homs =
    natural-crisp-elim (λ n → NB.isNull S (Chains.Index n))
      (λ n → NullIndices.null-index real-flat discrete-generators tiny (Chains.Index n)
        (Externality.index-discrete discrete-objects discrete-homs n))

  module Coefficients (Coefficient : (n : ℕ) → Chains.Index n → Type ℓ) where
    comparison : (n : ℕ) → (Σ[ c ∈ Chains.Index n ] NB.Null S (Coefficient n c))
      → NB.Null S (Σ (Chains.Index n) (Coefficient n))
    comparison n = Comparison.compare S (Chains.Index n) (Coefficient n)

    preserves-coefficients : RealFlat → CrisplyDiscrete Ix → TinyFamily
      → CrisplyDiscrete Obj → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
      → (n : ℕ) → isEquiv (comparison n)
    preserves-coefficients real-flat discrete-generators tiny discrete-objects discrete-homs n =
      Comparison.comparison-isEquiv S (Chains.Index n) (Coefficient n)
        (indices-null real-flat discrete-generators tiny discrete-objects discrete-homs n)
