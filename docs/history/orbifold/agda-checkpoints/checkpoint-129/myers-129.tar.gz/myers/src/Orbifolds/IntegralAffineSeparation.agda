{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineSeparation where

-- Actual metric isolation of integral affine transformations.  The
-- ambient neighborhoods test squared coordinate displacement on the
-- finite affine frame {0,e_1,...,e_n}; they are Penon open.  This is
-- stronger information than decidable equality of the abstract group.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Int using (ℤ; pos)
import Cubical.Data.Int as Z
import Cubical.Data.FinData as FD
import Cubical.Data.Fin as F
import Cubical.Data.SumFin as SFin
open import Cubical.Data.Sum using (_⊎_; inl; inr)
open import Cubical.Data.Unit using (Unit; tt)
open import Cubical.Relation.Nullary using (¬_; isProp¬)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
open import Cubical.Algebra.Group.Instances.Int using (ℤGroup)
open import Cubical.Functions.Embedding using (isEmbedding; isEmbedding→Inj)
open import Cubical.Tactics.CommRingSolver
open import Orbifolds.Penon using (PenonOpen; inverseImagePenonOpen)
open import Orbifolds.Compactness using
  (DPCompactAt; finiteFinDPCompact; equivDPCompact; sumDPCompact; unitDPCompact)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.IntegerLatticeSeparation as IS
import Orbifolds.IntegralAffineActions as IA
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.GeneralLinearMatrices as GL

-- These compact finite indices justify the finite conjunction without
-- deciding the open predicates. The index can live in a smaller universe.
finite-data-compact : {p : Level} (n : ℕ) → DPCompactAt p (FD.Fin n)
finite-data-compact n = equivDPCompact
  (compEquiv (SFin.SumFin≃Fin n) (invEquiv (F.FinData≃Fin n)))
  (finiteFinDPCompact n)

compact-conjunction-open : {ℓ ℓi : Level} {X : Type ℓ} {I : Type ℓi}
  → DPCompactAt ℓ I → (U : I → X → hProp ℓ)
  → ((i : I) → PenonOpen (U i))
  → PenonOpen (λ x → ((i : I) → U i x .fst) , isPropΠ (λ i → U i x .snd))
compact-conjunction-open compact U openU x allX y =
  compact ((¬ (x ≡ y)) , isProp¬ _) (λ i → U i y)
    (λ i → openU i x (allX i) y)

module Geometry {ℓ : Level} (R : CommRing ℓ)
  (kock : SF.RingContext.KockField R)
  (order : SF.RingContext.StrictOrder R)
  (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
  (n : ℕ) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  module Order = SO.OrderTheory R order
  module IntegerSeparation = IS.Ordered R order compatibility
  module Squares = IntegerSeparation.Squares kock
  module IntegerLinear = LM.Ring ℤCommRing
  module IntegerMatrices = GL.Ring ℤCommRing
  module IntegerGroup = GroupTheory ℤGroup
  module Affine = IA.Coordinates R n
  module IntegerHom = Affine.IntegerHom
  open Affine using (Vector; integer-vector)
  open Affine.Integer using (integer)

  FrameIndex : Type ℓ-zero
  FrameIndex = Unit ⊎ FD.Fin n

  frame-index-compact : DPCompactAt ℓ FrameIndex
  frame-index-compact = sumDPCompact unitDPCompact (finite-data-compact n)

  frame : FrameIndex → Vector
  frame (inl tt) = const 0r
  frame (inr j) = integer-vector (IntegerLinear.basis j)

  integer-difference : (z w : ℤ) → integer (z Z.- w) ≡ integer z - integer w
  integer-difference z w = IntegerHom.pres+ z (Z.- w)
    ∙ cong (integer z +_) (IntegerHom.pres- w)

  integer-close-equal : (z w : ℤ)
    → ((integer z - integer w) · (integer z - integer w)) < 1r
    → z ≡ w
  integer-close-equal z w below = Z.-≡0 z w
    (Squares.integer-square-zero (z Z.- w)
      (subst (λ a → (a · a) < 1r) (sym (integer-difference z w)) below))

  module Subgroup (H : Group ℓ) (ρ : GroupHom H Affine.Z.GeneralLinear)
    (embedding : isEmbedding (ρ .fst)) where
    module Linear = Affine.Representation H ρ

    integer-frame : Linear.AffineGroup .fst
      → FrameIndex → FD.Fin n → ℤ
    integer-frame g (inl tt) i = lower (g .fst) i
    integer-frame g (inr j) i = lower (g .fst) i Z.+
      Affine.Z.act (ρ .fst (g .snd)) (IntegerLinear.basis j) i

    frame-evaluation : (g : Linear.AffineGroup .fst)
      (j : FrameIndex) (i : FD.Fin n)
      → Linear.affine g (frame j) i ≡ integer (integer-frame g j i)
    frame-evaluation g (inl tt) i =
      cong (integer (lower (g .fst) i) +_)
        (cong (λ v → v i) (Affine.Real.action-zero
          (Linear.real-representation .fst (g .snd))))
      ∙ +IdR (integer (lower (g .fst) i))
    frame-evaluation g (inr j) i =
      cong (integer (lower (g .fst) i) +_)
        (sym (cong (λ v → v i)
          (Linear.preserves-integer-vectors (g .snd) (IntegerLinear.basis j))))
      ∙ sym (IntegerHom.pres+ (lower (g .fst) i)
        (Affine.Z.act (ρ .fst (g .snd)) (IntegerLinear.basis j) i))

    matrix-column : (h : H .fst) (i j : FD.Fin n)
      → Affine.Z.act (ρ .fst h) (IntegerLinear.basis j) i ≡ ρ .fst h .fst i j
    matrix-column h i j = cong (λ M → M i j)
      (retEq IntegerLinear.matrix≃module-hom (ρ .fst h .fst))

    integer-frame-injective : {g h : Linear.AffineGroup .fst}
      → ((j : FrameIndex) (i : FD.Fin n)
        → integer-frame g j i ≡ integer-frame h j i)
      → g ≡ h
    integer-frame-injective {g} {h} equal = ΣPathP
      (cong lift (funExt (equal (inl tt))) ,
        isEmbedding→Inj embedding (g .snd) (h .snd)
          (Σ≡Prop IntegerMatrices.Matrix.isPropIsInv
            (funExt λ i → funExt λ j → sym (matrix-column (g .snd) i j)
              ∙ IntegerGroup.·CancelL (lower (g .fst) i)
                (equal (inr j) i
                  ∙ cong (λ z → z Z.+ Affine.Z.act (ρ .fst (h .snd))
                    (IntegerLinear.basis j) i) (sym (equal (inl tt) i)))
              ∙ matrix-column (h .snd) i j)))

    Endomorphisms : Type ℓ
    Endomorphisms = Vector → Vector

    displacement : (g : Linear.AffineGroup .fst) (f : Endomorphisms)
      → FrameIndex → FD.Fin n → R .fst
    displacement g f j i = f (frame j) i - Linear.affine g (frame j) i

    coordinate-neighborhood : (g : Linear.AffineGroup .fst)
      → FrameIndex → FD.Fin n → Endomorphisms → hProp ℓ
    coordinate-neighborhood g j i f =
      ((displacement g f j i · displacement g f j i) < 1r) , less-isProp _ _

    FrameNeighborhood : Linear.AffineGroup .fst → Endomorphisms → hProp ℓ
    FrameNeighborhood g f =
      ((j : FrameIndex) (i : FD.Fin n) → coordinate-neighborhood g j i f .fst) ,
      isPropΠ2 (λ j i → less-isProp _ _)

    frame-neighborhood-open : (g : Linear.AffineGroup .fst)
      → PenonOpen (FrameNeighborhood g)
    frame-neighborhood-open g = compact-conjunction-open frame-index-compact
      (λ j f → ((i : FD.Fin n) → coordinate-neighborhood g j i f .fst) ,
        isPropΠ (λ i → less-isProp _ _))
      (λ j → compact-conjunction-open (finite-data-compact n) (coordinate-neighborhood g j)
        (λ i → inverseImagePenonOpen
          (λ f → (displacement g f j i · displacement g f j i) , 1r)
          Order.LessPredicate Order.lessRelationPenonOpen))

    abstract
      squared-self-difference : (x : R .fst) → (x - x) · (x - x) ≡ 0r
      squared-self-difference x = solve! R

    frame-neighborhood-contains : (g : Linear.AffineGroup .fst)
      → FrameNeighborhood g (Linear.affine g) .fst
    frame-neighborhood-contains g j i = subst (_< 1r)
      (sym (squared-self-difference (Linear.affine g (frame j) i))) zero<one

    frame-neighborhood-isolates : (g h : Linear.AffineGroup .fst)
      → FrameNeighborhood g (Linear.affine h) .fst → h ≡ g
    frame-neighborhood-isolates g h close = integer-frame-injective
      (λ j i → integer-close-equal (integer-frame h j i) (integer-frame g j i)
        (subst (λ d → (d · d) < 1r)
          (cong₂ _-_ (frame-evaluation h j i) (frame-evaluation g j i))
          (close j i)))
