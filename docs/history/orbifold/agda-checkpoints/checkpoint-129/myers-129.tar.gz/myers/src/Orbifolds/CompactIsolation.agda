{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CompactIsolation where

-- The topological part of Lemma 6.2.21.  A compact subset with decidable
-- equality is locally isolated whenever the ambient regular Hausdorff
-- topology contains all Penon opens.  Local isolation is derived from
-- compact deletion and Proposition 6.2.17, not assumed.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv using (fiber)
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; Dec; yes; no; Discrete; Discrete→isSet; isProp¬)
open import Cubical.Functions.Embedding
  using (isEmbedding; isEmbedding→Inj; isEmbedding→hasPropFibers; EmbeddingΣProp; compEmbedding)
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Compactness using (DPCompact; surjectiveImageDPCompact)
open import Orbifolds.CompactSubspaces using (WithoutPoint; complementSingletonDPCompact)
open import Orbifolds.Penon
  using (PenonOpen; DPSeparated; Complement; compactSubtypePenonClosed)
open import Orbifolds.Topology
  using (Predicate; Topology; IsOpen; RegularHausdorff; SeparatedNeighborhoods;
         regularHausdorff→Hausdorff; regularOpen→PenonOpen)
open import Orbifolds.SubspaceBases using (LocallyIsolatedMap; CountableBasis; module PullbackBasis)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.CountableCovers using (CountableProbe)
open import Orbifolds.ProperFiniteness using (ProperlyFinite)

private variable ℓ : Level

PenonOpensAreOpen : {X : Type ℓ} → Topology X → Type (ℓ-suc ℓ)
PenonOpensAreOpen {X = X} topology = (U : Predicate X) → PenonOpen U → IsOpen topology U

regularHausdorffDPSeparated : {X : Type ℓ} (topology : Topology X) →
  RegularHausdorff topology → DPSeparated X
regularHausdorffDPSeparated topology regularHausdorff x y distinct z = PT.rec squash₁
  (λ separation → PT.rec squash₁
    (Sum.rec (λ neq → ∣ inl neq ∣₁)
      (λ inLeft → PT.map
        (Sum.rec (λ neq → inr (λ path → neq (sym path)))
          (λ inRight → Empty.rec (SeparatedNeighborhoods.disjoint separation z inLeft inRight)))
        (regularOpen→PenonOpen topology (regularHausdorff .fst)
          (SeparatedNeighborhoods.right separation) (SeparatedNeighborhoods.rightOpen separation)
          y (SeparatedNeighborhoods.rightContains separation) z)))
    (regularOpen→PenonOpen topology (regularHausdorff .fst)
      (SeparatedNeighborhoods.left separation) (SeparatedNeighborhoods.leftOpen separation)
      x (SeparatedNeighborhoods.leftContains separation) z))
  (regularHausdorff→Hausdorff topology regularHausdorff x y distinct)

compactEmbeddingIsolated : {X K : Type ℓ} (topology : Topology X) →
  RegularHausdorff topology → PenonOpensAreOpen topology →
  DPCompact K → Discrete K → (f : K → X) → isEmbedding f → LocallyIsolatedMap topology f
compactEmbeddingIsolated {X = X} {K = K} topology regularHausdorff complete
  compactK decide f embedding x = ∣ neighborhood , openNeighborhood , contains ,
    (λ y → unique y (decide x y)) ∣₁
  where
  removed : WithoutPoint x → X
  removed other = f (other .fst)

  removedEmbedding : isEmbedding removed
  removedEmbedding = compEmbedding (f , embedding)
    (EmbeddingΣProp (λ _ → isProp¬ _)) .snd

  removedImage : Predicate X
  removedImage y = fiber removed y , isEmbedding→hasPropFibers removedEmbedding y

  graph : WithoutPoint x → Σ[ y ∈ X ] removedImage y .fst
  graph other = removed other , other , refl

  compactRemovedImage : DPCompact (Σ[ y ∈ X ] removedImage y .fst)
  compactRemovedImage = surjectiveImageDPCompact
    (complementSingletonDPCompact compactK decide x) graph
    (λ { (y , other , path) → ∣ other ,
      (λ i → path i , other , (λ j → path (i ∧ j))) ∣₁ })

  neighborhood : Predicate X
  neighborhood = Complement removedImage

  openNeighborhood : IsOpen topology neighborhood
  openNeighborhood = complete neighborhood
    (compactSubtypePenonClosed (regularHausdorffDPSeparated topology regularHausdorff)
      removedImage compactRemovedImage)

  contains : neighborhood (f x) .fst
  contains (other , path) = other .snd
    (isEmbedding→Inj embedding x (other .fst) (sym path))

  unique : (y : K) → Dec (x ≡ y) → neighborhood (f y) .fst → x ≡ y
  unique y (yes path) member = path
  unique y (no distinct) member = Empty.rec (member ((y , distinct) , refl))

compactEmbeddingProperlyFinite : {X K : Type ℓ} (topology : Topology X) →
  RegularHausdorff topology → CountableBasis topology → PenonOpensAreOpen topology →
  (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls →
  DPCompact K → Discrete K → (f : K → X) → isEmbedding f → ProperlyFinite K
compactEmbeddingProperlyFinite topology regularHausdorff basis complete
  balls covering probes compactK decide f embedding =
  Subspace.compactIsolatedProperlyFinite balls covering probes compactK
    (compactEmbeddingIsolated topology regularHausdorff complete compactK decide f embedding)
  where
  module Subspace = PullbackBasis topology basis (regularHausdorff .fst) f (Discrete→isSet decide)

