{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellCoherence where

-- Projection laws for each factor of the successor's canonical triangle
-- and their complete composite. PowerBarCoherence uses these laws to prove
-- the full transition coherence required by the unbounded inverse tower.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Data.Sigma
import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (List; _∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen; hidden-argument; visible-argument)
open import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle using (typeOf)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictPathCoherence
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionNaturality as Naturality
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as TriangleTypes
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.HomotopyCoherentColimitStepCoherenceData as StepData
import Orbifolds.Coherent.HomotopyCoherentUnifiedLiteralFiniteCellMaps as CellMaps
import Orbifolds.Coherent.HomotopyCoherentFiniteCellSuccessors as Successors
import Orbifolds.Coherent.StrictImagePaths as TrianglePasting
import Orbifolds.Coherent.HomotopyCoherentPacketFirstProjection as FirstProjection
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as PacketPasting
import Orbifolds.Coherent.HomotopyCoherentPacketLastProjection as LastProjection
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical

-- Check exactly the ordinary proof-independence application. The equality
-- values are quoted separately; the application itself is assembled inside
-- the existing restricted ordinary inference scope. Comparison remains
-- reducible so its target pair projection can compute.
private
  macro
    frozen-proof-independence : Reflection.Term → Reflection.Term
      → Reflection.Term → Reflection.TC ⊤
    frozen-proof-independence p q hole = assign-frozen
      ((quote Cocones.Functoriality.Cocone) ∷
       (quote Cocones.Functoriality.postcompose) ∷
       (quote Restriction.Restriction.finite-restriction) ∷ [])
      (Reflection.def (quote strict-path-proof-independent)
        (hidden-argument Reflection.unknown ∷ hidden-argument Reflection.unknown ∷
         hidden-argument Reflection.unknown ∷ hidden-argument Reflection.unknown ∷
         visible-argument p ∷ visible-argument q ∷ [])) hole

-- Project the exact strict-image path before substituting a large cell.
-- Strict proof uniqueness identifies the requested lower endpoint path.
strict-image-prefix : {ℓa ℓb ℓc : Level}
  (A : Type ℓa) (B : Type ℓb) (C₀ : Type ℓc)
  (k : A → B) (u : B → C₀) (x y : A)
  (r : outer x ≡ˢ outer y)
  (q : outer (u (k y)) ≡ˢ outer (u (k x)))
  → cong u (TrianglePasting.strict-image-sym-path A B k x y r) ≡ strict-to-path q
strict-image-prefix A B C₀ k u x .x reflˢ q with strict-uip q reflˢ
... | reflˢ = refl

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Represented.Induction.Represented.Space source
      → Represented.Induction.Represented.Space target)
    (triangle : TriangleTypes.Triangle C D G α E F n source target f) where
  module K = Successors.Construction C D G α E F n source target f triangle
    using (first-square; first-square-prefix; source-square; source-prefix; lifted-cell-square; lifted-cell-prefix;
      middle-square; middle-square-prefix; last-square; canonical-triangle; triangle-prefix; target-canonical-computation;
      literal-target-canonical-computation; module LiteralTarget)

  -- Keep only the declarations used by the path calculation. Copying
  -- the complete nested cell/representation namespaces is unnecessary.
  module M where
    A B : Type ℓ
    A = Represented.Induction.Represented.Space source
    B = Represented.Induction.Represented.Space target
    module CD = Cocones.Functoriality C D E F using (Cocone; postcompose; postcompose-compose)
    module CG = Cocones.Functoriality C G E F using (Cocone; postcompose)
    module SD = Comparison.Comparison C D E F n source using (Index)
    module TG = Comparison.Comparison C G E F n target using (Index; Coefficient; original-boundary; compare)

    uD : CD.Cocone (Represented.Induction.Represented.Space source) n
    uD = Represented.Induction.Represented.universal-cocone source

    uG : CG.Cocone (Represented.Induction.Represented.Space target) n
    uG = Represented.Induction.Represented.universal-cocone target

    module N where
      square : (m : Dim) {Y Z : Type ℓ} (h : Y → Z) (s : CG.Cocone Y m)
        → outer {A = CD.Cocone Z m} (CD.postcompose m {Y = Y} {Z = Z} h
            (Restriction.Restriction.finite-restriction C D G α E F Y m s))
          ≡ˢ outer {A = CD.Cocone Z m} (Restriction.Restriction.finite-restriction C D G α E F Z m
            (CG.postcompose m {Y = Y} {Z = Z} h s))
      square = Naturality.Naturality.square C D G α E F

  module Source = StepData.Step C D E F n source
    using (Realize; canonical-cocone; transition-computation)
  module Target = StepData.Step C G E F n target
    using (Realize; canonical-cocone; cell-original-computation; cell-cocone)
  module TargetCell = Attachments.Attachment E (osuc n)
    (Represented.Induction.Represented.Space target) M.TG.Index M.TG.Coefficient M.TG.original-boundary
    using (Cocone; include; canonical-cocone)
  module Cell = CellMaps.Construction.Cell C D G α E F n source target f triangle
    using (induced)
  module At = CellMaps.Construction.At C D G α E F n source target f triangle Target.Realize
    using (lower-path; comparison-square; comparison-prefix)
  module R where
    finite-restriction : (m : Dim) → M.CG.Cocone Target.Realize m → M.CD.Cocone Target.Realize m
    finite-restriction = Restriction.Restriction.finite-restriction C D G α E F Target.Realize
  prefix : M.CD.Cocone Target.Realize (osuc n) → M.CD.Cocone Target.Realize n
  prefix = fst

  comparison-prefix : (s : TargetCell.Cocone Target.Realize)
    → cong prefix (At.comparison-square s) ≡ At.lower-path (s .fst)
  comparison-prefix s = At.comparison-prefix s


  open K public using () renaming (middle-square-prefix to middle-prefix)

  module PacketConstruction = PacketPasting.Construction
    C D G α E F n source target f triangle using (module Packet)
  module FirstProjectionData = FirstProjection.Construction.ForInput
    C D G α E F n source target f triangle PacketConstruction.Packet.canonical
    using (Endpoint; UnitChange; finish-unit)

  endpoint : FirstProjectionData.Endpoint
  endpoint = reflˢ

  unit-change : FirstProjectionData.UnitChange endpoint
  unit-change = refl

  first-prefix : _
  first-prefix = FirstProjectionData.finish-unit endpoint unit-change

  target-prefix-equality : outer {A = M.CG.Cocone Target.Realize n} (Target.canonical-cocone .fst)
    ≡ˢ outer {A = M.CG.Cocone Target.Realize n}
      (M.CG.postcompose n {Y = M.B} {Z = Target.Realize} TargetCell.include M.uG)
  target-prefix-equality = strict-cong {A = Outer (M.B → Target.Realize)}
    {B = Outer (M.CG.Cocone Target.Realize n)}
    (λ k → outer (M.CG.postcompose n {Y = M.B} {Z = Target.Realize} (inner k) M.uG))
    Target.cell-original-computation

  last-equality : outer {A = M.CD.Cocone Target.Realize n} (R.finite-restriction n
      (M.CG.postcompose n {Y = M.B} {Z = Target.Realize} TargetCell.include M.uG))
    ≡ˢ outer {A = M.CD.Cocone Target.Realize n}
      (R.finite-restriction n (Target.canonical-cocone .fst))
  last-equality = strict-sym (strict-cong
    {A = Outer (M.CG.Cocone Target.Realize n)}
    {B = Outer (M.CD.Cocone Target.Realize n)}
    (λ s → outer (R.finite-restriction n (inner s))) target-prefix-equality)

  module CanonicalLast = LastProjection.Construction.ForInput
    C D G α E F n source target f triangle
    PacketConstruction.Packet.canonical using (last-equality; last-prefix)

  open CanonicalLast public using () renaming
    (last-equality to derived-last-equality; last-prefix to derived-last-prefix)

  last-equality-bridge : _
  last-equality-bridge = frozen-proof-independence derived-last-equality last-equality

  last-prefix : _
  last-prefix = derived-last-prefix ∙ last-equality-bridge

  transported-previous : _
  transported-previous = strict-end-path {A = M.CD.Cocone Target.Realize n}
    (λ i → M.CD.postcompose n {Y = M.B} {Z = Target.Realize} TargetCell.include (triangle i))
    (strict-trans (M.CD.postcompose-compose n {Y = M.A} {Z = M.B} {W = Target.Realize}
        f TargetCell.include M.uD)
      (strict-sym (Source.transition-computation Target.Realize Cell.induced)))
    (strict-trans (M.N.square n {Y = M.B} {Z = Target.Realize} TargetCell.include M.uG) last-equality)


  composite-prefix : _
  composite-prefix = K.triangle-prefix
    ∙ cong₂ _∙_ first-prefix (cong₂ _∙_ middle-prefix last-prefix)
