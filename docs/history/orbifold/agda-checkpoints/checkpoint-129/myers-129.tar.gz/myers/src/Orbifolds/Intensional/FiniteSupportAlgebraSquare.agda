{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportAlgebraSquare where

-- Upgrade the already constructed actual tensor pullback
-- comparison to an algebra isomorphism. Underlying equivalence is
-- proved by TensorSquare, not supplied as a post-extension hypothesis.
-- The inverse algebra-map laws are derived by applying the forward
-- injection to the ordinary inverse equations.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv; homotopy-isEquiv)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using (finite-support-path)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportScalarExtension
open import Orbifolds.Intensional.CommutativeAlgebraCore
open import Orbifolds.Intensional.FiniteSupportTensorAlgebra
open import Orbifolds.Intensional.AlgebraPullback

module WithParameter {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (Parameter : CommutativeAlgebra R) where

  module E = BasedAlgebras ext classical equality Parameter

  module WithBasis (basis : E.B.Basis) where

    module Extended = E.WithBasis basis

    module Square (D A B C : CommutativeAlgebra R)
        (u : AlgebraHom D A) (v : AlgebraHom D B)
        (f : AlgebraHom A C) (g : AlgebraHom B C)
        (commute : (d : CommutativeAlgebra.Carrier D)
          → AlgebraHom.map g (AlgebraHom.map v d) ≡ AlgebraHom.map f (AlgebraHom.map u d)) where

      module XD = Extended.On D
      module XA = Extended.On A
      module XB = Extended.On B
      module XC = Extended.On C
      module TU = Extended.Map D A u
      module TV = Extended.Map D B v
      module TF = Extended.Map A C f
      module TG = Extended.Map B C g

      module Underlying = TensorSquare ext classical equality
        (CommutativeAlgebra.moduleR D) (CommutativeAlgebra.moduleR A)
        (CommutativeAlgebra.moduleR B) (CommutativeAlgebra.moduleR C)
        (AlgebraHom.linear u) (AlgebraHom.linear v)
        (AlgebraHom.linear f) (AlgebraHom.linear g) commute

      module P = PullbackAlgebra ext XA.Algebra.algebra XB.Algebra.algebra XC.Algebra.algebra
        TF.algebra-map TG.algebra-map

      extended-commute : (d : Semimodule.Carrier XD.O.Extension)
        → AlgebraHom.map TG.algebra-map (AlgebraHom.map TV.algebra-map d)
          ≡ AlgebraHom.map TF.algebra-map (AlgebraHom.map TU.algebra-map d)
      extended-commute d = finite-support-path ext (ext (λ i → commute (fst d i)))

      module Comparison = P.Comparison XD.Algebra.algebra TU.algebra-map TV.algebra-map extended-commute

      module ParameterCone = P.Comparison Parameter XA.Algebra.include-left XB.Algebra.include-left
        (λ a → TG.respects-parameter a ∙ sym (TF.respects-parameter a))

      parameter-map : AlgebraHom Parameter P.algebra
      parameter-map = ParameterCone.comparison-hom

      actual-comparison : Semimodule.Carrier XD.O.Extension → P.P
      actual-comparison = Comparison.comparison

      comparison-respects-parameter : (a : CommutativeAlgebra.Carrier Parameter)
        → actual-comparison (AlgebraHom.map XD.Algebra.include-left a) ≡ AlgebraHom.map parameter-map a
      comparison-respects-parameter a = P.path (TU.respects-parameter a) (TV.respects-parameter a)

      comparison-agrees : (d : Semimodule.Carrier XD.O.Extension)
        → Underlying.tensor-comparison d ≡ actual-comparison d
      comparison-agrees d = P.path refl refl

      actual-comparison-isEquiv : isEquiv Underlying.original-comparison → isEquiv actual-comparison
      actual-comparison-isEquiv original = homotopy-isEquiv
        Underlying.tensor-comparison actual-comparison comparison-agrees
        (Underlying.tensor-comparison-isEquiv original)

      module Pullback (original-is-pullback : isEquiv Underlying.original-comparison) where

        module InverseComparison = Inverse XD.Algebra.algebra P.algebra Comparison.comparison-hom
          (actual-comparison-isEquiv original-is-pullback)

        algebra-isomorphism : AlgebraIso XD.Algebra.algebra P.algebra
        algebra-isomorphism = InverseComparison.algebra-isomorphism

        isomorphism-forward-is-actual : (d : Semimodule.Carrier XD.O.Extension)
          → AlgebraHom.map (AlgebraIso.to-hom algebra-isomorphism) d ≡ actual-comparison d
        isomorphism-forward-is-actual d = refl

        first-leg-is-actual : (d : Semimodule.Carrier XD.O.Extension)
          → fst (AlgebraHom.map (AlgebraIso.to-hom algebra-isomorphism) d)
            ≡ fst TU.Map0.tensor-map d
        first-leg-is-actual d = refl

        second-leg-is-actual : (d : Semimodule.Carrier XD.O.Extension)
          → fst (snd (AlgebraHom.map (AlgebraIso.to-hom algebra-isomorphism) d))
            ≡ fst TV.Map0.tensor-map d
        second-leg-is-actual d = refl

        inverse-respects-parameter : (a : CommutativeAlgebra.Carrier Parameter)
          → AlgebraHom.map (AlgebraIso.from-hom algebra-isomorphism) (AlgebraHom.map parameter-map a)
            ≡ AlgebraHom.map XD.Algebra.include-left a
        inverse-respects-parameter a = InverseComparison.injective
          (section InverseComparison.underlying (AlgebraHom.map parameter-map a)
            ∙ sym (comparison-respects-parameter a))
