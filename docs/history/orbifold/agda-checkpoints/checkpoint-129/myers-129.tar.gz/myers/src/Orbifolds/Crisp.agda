{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.Crisp where

-- Native Agda crisp contexts. No ordinary type predicate is used in place
-- of the judgmental crisp restriction. No --flat-split is needed here.
-- Agda 2.8 has this flat modality, but no primitive sharp modality.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Relation.Nullary using (Dec)

data Flat {@♭ ℓ : Level} (@♭ A : Type ℓ) : Type ℓ where
  box : (@♭ x : A) → Flat A

counit : {@♭ ℓ : Level} {@♭ A : Type ℓ} → Flat A → A
counit (box x) = x

flat-elim : {@♭ ℓ : Level} {ℓp : Level} {@♭ A : Type ℓ}
  (P : Flat A → Type ℓp) → ((@♭ x : A) → P (box x))
  → (z : Flat A) → P z
flat-elim P f (box x) = f x

flat-map : {@♭ ℓ ℓ' : Level} {@♭ A : Type ℓ} {@♭ B : Type ℓ'}
  → (@♭ f : A → B) → Flat A → Flat B
flat-map f (box x) = box (f x)

flat-map-id : {@♭ ℓ : Level} {@♭ A : Type ℓ} (x : Flat A)
  → flat-map (idfun A) x ≡ x
flat-map-id (box x) = refl

flat-map-compose : {@♭ ℓ ℓ' ℓ'' : Level}
  {@♭ A : Type ℓ} {@♭ B : Type ℓ'} {@♭ C : Type ℓ''}
  (@♭ f : A → B) (@♭ g : B → C) (x : Flat A)
  → flat-map (g ∘ f) x ≡ flat-map g (flat-map f x)
flat-map-compose f g (box x) = refl

counit-natural : {@♭ ℓ ℓ' : Level} {@♭ A : Type ℓ} {@♭ B : Type ℓ'}
  (@♭ f : A → B) (x : Flat A) → counit (flat-map f x) ≡ f (counit x)
counit-natural f (box x) = refl

duplicate : {@♭ ℓ : Level} {@♭ A : Type ℓ} → Flat A → Flat (Flat A)
duplicate (box x) = box (box x)

counit-duplicate : {@♭ ℓ : Level} {@♭ A : Type ℓ} (x : Flat A)
  → counit (duplicate x) ≡ x
counit-duplicate (box x) = refl

map-counit-duplicate : {@♭ ℓ : Level} {@♭ A : Type ℓ} (x : Flat A)
  → flat-map counit (duplicate x) ≡ x
map-counit-duplicate (box x) = refl

duplicate-associative : {@♭ ℓ : Level} {@♭ A : Type ℓ} (x : Flat A)
  → duplicate (duplicate x) ≡ flat-map duplicate (duplicate x)
duplicate-associative (box x) = refl

CrisplyDiscrete : {@♭ ℓ : Level} (@♭ A : Type ℓ) → Type ℓ
CrisplyDiscrete A = isEquiv (counit {A = A})

-- Axiom 1 is a type of hypotheses, never installed as a postulate.
-- Calling such a hypothesis on a noncrisp proposition is rejected by Agda.
CrispExcludedMiddle : {@♭ ℓ : Level} → Type (ℓ-suc ℓ)
CrispExcludedMiddle {ℓ} = (@♭ P : hProp ℓ) → Dec (P .fst)
