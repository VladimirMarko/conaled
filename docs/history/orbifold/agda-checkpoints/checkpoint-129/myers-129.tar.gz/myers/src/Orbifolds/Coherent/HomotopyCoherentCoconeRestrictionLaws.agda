{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionLaws where

-- Contravariant identity and composition of the actual full cocone
-- restriction maps, including every retained higher coherence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentMappingContravariance as Contravariance
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentConeMapLaws as ConeLaws

module Composition {ℓ : Level} (C : Category ℓ ℓ)
    (D G H : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (β : Transformations.ForCategory.Transformation C G H)
    (γ : Transformations.ForCategory.Transformation C D H)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component β x
          ∘ Transformations.ForCategory.Transformation.component α x)
        ≡ˢ outer (Transformations.ForCategory.Transformation.component γ x))
    (Y : Type ℓ) where
  module DM = Mapping.Mapping C D E F using (Into)
  module GM = Mapping.Mapping C G E F using (Into)
  module HM = Mapping.Mapping C H E F using (Into)
  module A = Contravariance.Contravariance C D G α E F using (Precompose)
  module B = Contravariance.Contravariance C G H β E F using (Precompose)
  module K = Contravariance.Contravariance C D H γ E F using (Precompose)
  module RA = Restriction.Restriction C D G α E F Y using (restrict)
  module RB = Restriction.Restriction C G H β E F Y using (SourceCocone; restrict)
  module RK = Restriction.Restriction C D H γ E F Y using (restrict)

  restriction-composition : (s : RB.SourceCocone)
    → RA.restrict (RB.restrict s) ≡ RK.restrict s
  restriction-composition = ConeLaws.Composition.cone-composition
    (Opposite C) (HM.Into Y) (GM.Into Y) (DM.Into Y)
    (B.Precompose Y) (A.Precompose Y) (K.Precompose Y) E F
    (λ x → strict-cong
      (λ q → outer (λ (h : HC.ForCategory.Diagram.Value H x → Y) → h ∘ inner q))
      (components x))

module Identity {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D D)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component α x) ≡ˢ outer (idfun _))
    (Y : Type ℓ) where
  module DM = Mapping.Mapping C D E F using (Into)
  module A = Contravariance.Contravariance C D D α E F using (Precompose)
  module R = Restriction.Restriction C D D α E F Y using (SourceCocone; restrict)

  restriction-identity : (s : R.SourceCocone) → R.restrict s ≡ s
  restriction-identity = ConeLaws.Identity.cone-identity
    (Opposite C) (DM.Into Y) (A.Precompose Y) E F
    (λ x → strict-cong
      (λ q → outer (λ (h : HC.ForCategory.Diagram.Value D x → Y) → h ∘ inner q))
      (components x))
