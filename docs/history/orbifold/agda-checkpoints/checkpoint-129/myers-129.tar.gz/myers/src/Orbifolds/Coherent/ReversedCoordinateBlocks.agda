{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.ReversedCoordinateBlocks where

-- Reversal interchanges the actual coordinate blocks of a tensor cut.
-- All dimension transports are explicit outer-equality transports.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken)
open import Orbifolds.Coherent.OuterCubicalFaces
open import Orbifolds.Coherent.OuterCoordinateReversal
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken)
open import Orbifolds.Coherent.CoherentCubeTensors using (cast-cube)

cast-coordinates : {m n : Dim} → m ≡ˢ n → Coordinates m → Coordinates n
cast-coordinates reflˢ xs = xs

cast-trans : {k m n : Dim} (p : k ≡ˢ m) (q : m ≡ˢ n) (xs : Coordinates k)
  → cast-coordinates (strict-trans p q) xs ≡ˢ cast-coordinates q (cast-coordinates p xs)
cast-trans reflˢ reflˢ xs = reflˢ

cast-pair : {m n : Dim} (p : m ≡ˢ n) (i : Coordinate) (xs : Coordinates m)
  → cast-coordinates (strict-cong osuc p) (pair i xs) ≡ˢ pair i (cast-coordinates p xs)
cast-pair reflˢ i xs = reflˢ

cast-snoc : {m n : Dim} (p : m ≡ˢ n) (xs : Coordinates m) (i : Coordinate)
  → cast-coordinates (strict-cong osuc p) (snoc m xs i) ≡ˢ snoc n (cast-coordinates p xs) i
cast-snoc reflˢ xs i = reflˢ

prefix-snoc : (n : Dim) (p : Position (osuc n)) (xs : Coordinates n) (i : Coordinate)
  → cast-coordinates (prefix-weaken n p)
      (prefix-coordinates (osuc n) (weaken p) (snoc n xs i))
    ≡ˢ snoc (prefix-degree n p) (prefix-coordinates n p xs) i
prefix-snoc n pzero xs i = reflˢ
prefix-snoc (osuc n) (psuc p) xs i = prefix-snoc n p (second xs) i

suffix-snoc : (n : Dim) (p : Position (osuc n)) (xs : Coordinates n) (i : Coordinate)
  → cast-coordinates (suffix-weaken n p)
      (suffix-coordinates (osuc n) (weaken p) (snoc n xs i))
    ≡ˢ suffix-coordinates n p xs
suffix-snoc n pzero xs i = reflˢ
suffix-snoc (osuc n) (psuc p) xs i = strict-trans
  (cast-pair (suffix-weaken n p) (first xs)
    (suffix-coordinates (osuc n) (weaken p) (snoc n (second xs) i)))
  (strict-cong (pair (first xs)) (suffix-snoc n p (second xs) i))

prefix-last-coordinates : (n : Dim) (xs : Coordinates n)
  → cast-coordinates (prefix-last n) (prefix-coordinates n (last-position n) xs) ≡ˢ ott
prefix-last-coordinates ozero xs = reflˢ
prefix-last-coordinates (osuc n) xs = prefix-last-coordinates n (second xs)

suffix-last-coordinates : (n : Dim) (xs : Coordinates n)
  → cast-coordinates (suffix-last n) (suffix-coordinates n (last-position n) xs) ≡ˢ xs
suffix-last-coordinates ozero xs = reflˢ
suffix-last-coordinates (osuc n) xs = strict-trans
  (cast-pair (suffix-last n) (first xs) (suffix-coordinates n (last-position n) (second xs)))
  (strict-cong (pair (first xs)) (suffix-last-coordinates n (second xs)))

reverse-prefix-coordinates : (n : Dim) (p : Position (osuc n)) (xs : Coordinates n)
  → cast-coordinates (reverse-prefix-degree n p)
      (prefix-coordinates n (reverse-position n p) (reverse-coordinates n xs))
    ≡ˢ reverse-coordinates (suffix-degree n p) (suffix-coordinates n p xs)
reverse-prefix-coordinates n pzero xs = prefix-last-coordinates n (reverse-coordinates n xs)
reverse-prefix-coordinates (osuc n) (psuc p) xs = strict-trans
  (cast-trans (prefix-weaken n (reverse-position n p))
    (strict-cong osuc (reverse-prefix-degree n p))
    (prefix-coordinates (osuc n) (weaken (reverse-position n p))
      (snoc n (reverse-coordinates n (second xs)) (first xs))))
  (strict-trans
    (strict-cong (cast-coordinates (strict-cong osuc (reverse-prefix-degree n p)))
      (prefix-snoc n (reverse-position n p) (reverse-coordinates n (second xs)) (first xs)))
    (strict-trans
      (cast-snoc (reverse-prefix-degree n p)
        (prefix-coordinates n (reverse-position n p) (reverse-coordinates n (second xs))) (first xs))
      (strict-cong (λ ys → snoc (suffix-degree n p) ys (first xs))
        (reverse-prefix-coordinates n p (second xs)))))

reverse-suffix-coordinates : (n : Dim) (p : Position (osuc n)) (xs : Coordinates n)
  → cast-coordinates (reverse-suffix-degree n p)
      (suffix-coordinates n (reverse-position n p) (reverse-coordinates n xs))
    ≡ˢ reverse-coordinates (prefix-degree n p) (prefix-coordinates n p xs)
reverse-suffix-coordinates n pzero xs = suffix-last-coordinates n (reverse-coordinates n xs)
reverse-suffix-coordinates (osuc n) (psuc p) xs = strict-trans
  (cast-trans (suffix-weaken n (reverse-position n p)) (reverse-suffix-degree n p)
    (suffix-coordinates (osuc n) (weaken (reverse-position n p))
      (snoc n (reverse-coordinates n (second xs)) (first xs))))
  (strict-trans
    (strict-cong (cast-coordinates (reverse-suffix-degree n p))
      (suffix-snoc n (reverse-position n p) (reverse-coordinates n (second xs)) (first xs)))
    (reverse-suffix-coordinates n p (second xs)))

cast-evaluation : ∀ {ℓ} {m n : Dim} (p : m ≡ˢ n) {X : Type ℓ}
  (c : Cube m X) (xs : Coordinates m)
  → outer (evaluate n (cast-cube p c) (cast-coordinates p xs)) ≡ˢ outer (evaluate m c xs)
cast-evaluation reflˢ c xs = reflˢ

cast-evaluation-back : ∀ {ℓ} {m n : Dim} (p : m ≡ˢ n) {X : Type ℓ}
  (c : Cube m X) (xs : Coordinates n)
  → outer (evaluate n (cast-cube p c) xs) ≡ˢ outer (evaluate m c (cast-coordinates (strict-sym p) xs))
cast-evaluation-back reflˢ c xs = reflˢ
