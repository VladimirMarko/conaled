{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispPresented where

-- Exact native-crisp consequences for explicitly presented infinitesimal
-- diagrams. This module does not assert that a crisp mere presentation
-- can be unpacked by safe Cubical flat splitting.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
import Orbifolds.CrispGeometry as CG
import Orbifolds.WeilAlgebras as WA
import Orbifolds.WeilZeroLocus as WZ

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ) where
  open CG.Context R
  module W = WA.Weil R
  module P = WZ.Ring R

  crisp-presented-connected : CrispPullbackPreservation
    → (@♭ X : Type ℓ) (@♭ x : X)
    → (@♭ presentation : P.PointedPolynomialPresentation X x)
    → Infinitesimal.Crystal.Connected X
  crisp-presented-connected preserve X x presentation =
    Preserve.connected-equiv
      (invEquiv (P.PointedPolynomialPresentation.presentation-equivalence presentation))
      (crisp-zero-locus-connected preserve
        (P.PointedPolynomialPresentation.n presentation)
        (P.PointedPolynomialPresentation.m presentation)
        (P.PointedPolynomialPresentation.Locus.infinitesimal-map presentation))

  record PresentedDiagram : Type (ℓ-suc ℓ) where
    field
      pushout : WeilTests.WeilRealPushout
    module D = WeilTests.WeilDiagram (WeilTests.WeilRealPushout.diagram pushout)
    field
      presentation-NW : P.PointedPolynomialPresentation (W.Spec D.WNW) (W.origin D.WNW)
      presentation-NE : P.PointedPolynomialPresentation (W.Spec D.WNE) (W.origin D.WNE)
      presentation-SW : P.PointedPolynomialPresentation (W.Spec D.WSW) (W.origin D.WSW)
      presentation-SE : P.PointedPolynomialPresentation (W.Spec D.WSE) (W.origin D.WSE)

  CrispPresentedDiagram : Type (ℓ-suc ℓ)
  CrispPresentedDiagram = Flat PresentedDiagram

  underlying : CrispPresentedDiagram → WeilTests.WeilRealPushout
  underlying (box diagram) = PresentedDiagram.pushout diagram

  module Presented (preserve : CrispPullbackPreservation) where
    open PresentedDiagram
    open WeilTests.WeilRealPushout
    open WeilTests.WeilDiagram

    connected-NW : (d : CrispPresentedDiagram)
      → Infinitesimal.Crystal.Connected (W.Spec (WNW (diagram (underlying d))))
    connected-NW (box d) = crisp-presented-connected preserve
      (W.Spec (D.WNW d)) (W.origin (D.WNW d)) (presentation-NW d)

    connected-NE : (d : CrispPresentedDiagram)
      → Infinitesimal.Crystal.Connected (W.Spec (WNE (diagram (underlying d))))
    connected-NE (box d) = crisp-presented-connected preserve
      (W.Spec (D.WNE d)) (W.origin (D.WNE d)) (presentation-NE d)

    connected-SW : (d : CrispPresentedDiagram)
      → Infinitesimal.Crystal.Connected (W.Spec (WSW (diagram (underlying d))))
    connected-SW (box d) = crisp-presented-connected preserve
      (W.Spec (D.WSW d)) (W.origin (D.WSW d)) (presentation-SW d)

    connected-SE : (d : CrispPresentedDiagram)
      → Infinitesimal.Crystal.Connected (W.Spec (WSE (diagram (underlying d))))
    connected-SE (box d) = crisp-presented-connected preserve
      (W.Spec (D.WSE d)) (W.origin (D.WSE d)) (presentation-SE d)

    module PresentedModal = WeilTests.Indexed.Modal underlying Infinitesimal.CrystallineModality
      connected-NW connected-NE connected-SW connected-SE
