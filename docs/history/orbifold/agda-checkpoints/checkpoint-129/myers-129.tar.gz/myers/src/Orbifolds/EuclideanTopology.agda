{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.EuclideanTopology where

-- The ordinary box topology in every finite real dimension, with a
-- constructed countable rational basis and regular Hausdorff separation.
-- Under the explicit compact-unit-interval axiom, Penon openness agrees
-- with box openness.  Both standard finite-coordinate encodings are kept.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.SumFin using (Fin)
open import Cubical.Data.SumFin.Properties
  using (FinData→SumFin; SumFin→FinData; FinDataSumFinIso)
import Cubical.Data.FinData as FD
open import Cubical.Data.Sum using (inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; isProp¬)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.SyntheticSeparated using (module Separation)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.EuclideanNorms using (module Norms)
open import Orbifolds.IntervalTopology using (module Intervals)
open import Orbifolds.CountableBoxes using (module Boxes)
open import Orbifolds.CompactIntervals using (module Interpolation)
open import Orbifolds.UniformBoxes using (module Uniform)
open import Orbifolds.Compactness using (_∨_; finiteFinDPCompact)
open import Orbifolds.Penon
  using (PenonOpen; RegularSeparation; inverseImagePenonOpen; UnionPredicate; unionPenonOpen)
open import Orbifolds.PenonTopology using (penonTopology)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.Topology
  using (Predicate; Topology; IsOpen; Regular; RegularNeighborhood; T₀; RegularHausdorff)
open import Orbifolds.SubspaceBases using (CountableBasis)
open import Orbifolds.Refinements using (Included)
open import Orbifolds.CompactIsolation using (PenonOpensAreOpen)

module Euclidean {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open Field kock
  open Separation R using (differenceOfEquals; invertibleNonzero)
  open RealProbe R kock order compatibility using (PositiveRadius; intervalBalls)
  open Norms R kock order compatibility using (Vector; vectorIsSet)
  open Intervals R kock order compatibility
    using (ballPenonOpen; Exterior; exteriorPenonOpen; smallerBallIncluded;
      plusLeftLess; subtractFromLess; intervalsT₀)
  open Boxes R kock order compatibility
    using (BoxPredicate; boxContainsCenter; BasicBox; basicBoxPenonOpen; basicBoxAt)
  open Interpolation R kock order compatibility using (UnitIntervalCompact)
  open Uniform R kock order compatibility using (penonOpenHasBox)

  sumTopology : (n : ℕ) → Topology (Vector n)
  sumTopology n = penonTopology (vectorIsSet n)

  boxPenonOpen : (n : ℕ) (x : Vector n) (δ : PositiveRadius) → PenonOpen (BoxPredicate n x δ)
  boxPenonOpen n x δ y member z = finiteFinDPCompact n
    ((¬ (y ≡ z)) , isProp¬ _) (λ i → BallStructure.ball intervalBalls (x i) δ (z i))
    (λ i → PT.map (Sum.map (λ distinct path → distinct (cong (λ v → v i) path)) (λ p → p))
      (ballPenonOpen (x i) δ (y i) (member i) (z i)))

  sumCountableBasis : CoveringProperty intervalBalls → UnitIntervalCompact →
    (n : ℕ) → CountableBasis (sumTopology n)
  CountableBasis.basic (sumCountableBasis covering compactInterval n) = BasicBox n
  CountableBasis.basicOpen (sumCountableBasis covering compactInterval n) = basicBoxPenonOpen n
  CountableBasis.localBasis (sumCountableBasis covering compactInterval n) U openU x ux =
    PT.rec squash₁ (λ { (δ , included) → PT.map
      (λ { (code , contains , inBox) → code , contains ,
        (λ y member → included y (inBox y member)) })
      (basicBoxAt covering n x δ) })
      (penonOpenHasBox covering compactInterval n U openU x ux)

  BoxExterior : (n : ℕ) → Vector n → PositiveRadius → Predicate (Vector n)
  BoxExterior n x δ = UnionPredicate {J = Fin n} (λ i y → Exterior (x i) δ (y i))

  boxExteriorPenonOpen : (n : ℕ) (x : Vector n) (δ : PositiveRadius) → PenonOpen (BoxExterior n x δ)
  boxExteriorPenonOpen n x δ = unionPenonOpen (λ i y → Exterior (x i) δ (y i))
    (λ i → inverseImagePenonOpen (λ y → y i) (Exterior (x i) δ) (exteriorPenonOpen (x i) δ))

  sumRegular : CoveringProperty intervalBalls → UnitIntervalCompact → (n : ℕ) → Regular (sumTopology n)
  sumRegular covering compactInterval n U openU x ux = PT.map finish
    (penonOpenHasBox covering compactInterval n U openU x ux)
    where
    finish : (Σ[ ε ∈ PositiveRadius ] Included (BoxPredicate n x ε) U) →
      RegularNeighborhood (sumTopology n) U x
    finish (ε , included) = record
      { separation = record
        { inner = BoxPredicate n x δ
        ; outside = BoxExterior n x δ
        ; pointInInner = boxContainsCenter n x δ
        ; innerIncluded = λ y member → included y
            (λ i → smallerBallIncluded (x i) δ ε below (y i) (member i))
        ; disjoint = λ y member → PT.rec Empty.isProp⊥
            (λ { (i , exterior) → PT.rec Empty.isProp⊥
              (Sum.rec (λ lower → lessAsym (member i .fst) lower)
                (λ upper → lessAsym (member i .snd) upper)) exterior })
        ; covers = λ y → PT.map
            (Sum.rec inr (λ allCoordinates → inl (included y allCoordinates)))
            (finiteFinDPCompact n (BoxExterior n x δ y)
              (λ i → BallStructure.ball intervalBalls (x i) ε (y i))
              (coordinateCover y))
        }
      ; innerOpen = boxPenonOpen n x δ
      ; outsideOpen = boxExteriorPenonOpen n x δ
      }
      where
      δ : PositiveRadius
      δ = half · ε .fst , halfScalePositive (ε .snd)
      below : δ .fst < ε .fst
      below = halfScaleLess (ε .snd)

      coordinateCover : (y : Vector n) (i : Fin n) →
        (BoxExterior n x δ y .fst) ∨ (BallStructure.ball intervalBalls (x i) ε (y i) .fst)
      coordinateCover y i = PT.rec squash₁
        (Sum.rec
          (λ lower → PT.map
            (Sum.rec (λ upper → inl ∣ i , ∣ inr upper ∣₁ ∣₁)
              (λ upper → inr (lower , upper)))
            (cotransitive (plusLeftLess below (x i)) (y i)))
          (λ exterior → ∣ inl ∣ i , ∣ inl exterior ∣₁ ∣₁ ∣₁))
        (cotransitive (subtractFromLess below (x i)) (y i))

  sumT₀ : (n : ℕ) → T₀ (sumTopology n)
  sumT₀ n x y distinct = PT.rec squash₁
    (λ { (i , unit) → PT.map
      (λ { (U , openU , orientation) → (λ z → U (z i)) ,
        inverseImagePenonOpen (λ z → z i) U openU , orientation })
      (intervalsT₀ (x i) (y i)
        (λ path → invertibleNonzero kock (x i - y i) unit (differenceOfEquals path))) })
    (finite-K kock n (λ i → x i - y i)
      (λ allZero → distinct (funExt (λ i → equalByDifference (x i) (y i) (allZero i)))))

  sumRegularHausdorff : CoveringProperty intervalBalls → UnitIntervalCompact →
    (n : ℕ) → RegularHausdorff (sumTopology n)
  sumRegularHausdorff covering compactInterval n = sumRegular covering compactInterval n , sumT₀ n

  -- Reindex the proved topology to the FinData coordinates used by the
  -- ordinary-manifold and Weil-locus interfaces.  The inverse laws are
  -- checked, so this is the same finite-dimensional topology.
  DataVector : ℕ → Type ℓ
  DataVector n = FD.Fin n → Carrier

  toSum : {n : ℕ} → DataVector n → Vector n
  toSum v i = v (SumFin→FinData i)

  fromSum : {n : ℕ} → Vector n → DataVector n
  fromSum v i = v (FinData→SumFin i)

  fromTo : {n : ℕ} (v : DataVector n) → fromSum (toSum v) ≡ v
  fromTo v = funExt (λ i → cong v (Iso.leftInv FinDataSumFinIso i))

  toFrom : {n : ℕ} (v : Vector n) → toSum (fromSum v) ≡ v
  toFrom v = funExt (λ i → cong v (Iso.rightInv FinDataSumFinIso i))

  vectorEquivalence : (n : ℕ) → DataVector n ≃ Vector n
  vectorEquivalence n = isoToEquiv (iso toSum fromSum toFrom fromTo)

  dataTopology : (n : ℕ) → Topology (DataVector n)
  dataTopology n = penonTopology (isSetΠ (λ _ → is-set))

  dataPenonOpensAreOpen : (n : ℕ) → PenonOpensAreOpen (dataTopology n)
  dataPenonOpensAreOpen n U openU = openU

  dataCountableBasis : CoveringProperty intervalBalls → UnitIntervalCompact →
    (n : ℕ) → CountableBasis (dataTopology n)
  CountableBasis.basic (dataCountableBasis covering compactInterval n) code x = BasicBox n code (toSum x)
  CountableBasis.basicOpen (dataCountableBasis covering compactInterval n) code =
    inverseImagePenonOpen toSum (BasicBox n code) (basicBoxPenonOpen n code)
  CountableBasis.localBasis (dataCountableBasis covering compactInterval n) U openU x ux =
    PT.map (λ { (code , contains , includes) → code , contains ,
      (λ y member → subst (λ z → U z .fst) (fromTo y) (includes (toSum y) member)) })
      (CountableBasis.localBasis (sumCountableBasis covering compactInterval n)
        (λ z → U (fromSum z)) (inverseImagePenonOpen fromSum U openU)
        (toSum x) (subst (λ z → U z .fst) (sym (fromTo x)) ux))

  dataRegular : CoveringProperty intervalBalls → UnitIntervalCompact → (n : ℕ) → Regular (dataTopology n)
  dataRegular covering compactInterval n U openU x ux = PT.map finish
    (sumRegular covering compactInterval n (λ z → U (fromSum z))
      (inverseImagePenonOpen fromSum U openU) (toSum x)
      (subst (λ z → U z .fst) (sym (fromTo x)) ux))
    where
    finish : RegularNeighborhood (sumTopology n) (λ z → U (fromSum z)) (toSum x) →
      RegularNeighborhood (dataTopology n) U x
    finish neighborhood = record
      { separation = record
        { inner = λ z → inner (toSum z)
        ; outside = λ z → outside (toSum z)
        ; pointInInner = pointInInner
        ; innerIncluded = λ z member → subst (λ w → U w .fst) (fromTo z) (innerIncluded (toSum z) member)
        ; disjoint = λ z → disjoint (toSum z)
        ; covers = λ z → PT.map
            (Sum.map (subst (λ w → U w .fst) (fromTo z)) (λ p → p)) (covers (toSum z))
        }
      ; innerOpen = inverseImagePenonOpen toSum inner (RegularNeighborhood.innerOpen neighborhood)
      ; outsideOpen = inverseImagePenonOpen toSum outside (RegularNeighborhood.outsideOpen neighborhood)
      }
      where
      open RegularSeparation (RegularNeighborhood.separation neighborhood)

  dataT₀ : (n : ℕ) → T₀ (dataTopology n)
  dataT₀ n x y distinct = PT.map
    (λ { (U , openU , orientation) → (λ z → U (toSum z)) ,
      inverseImagePenonOpen toSum U openU , orientation })
    (sumT₀ n (toSum x) (toSum y)
      (λ path → distinct (sym (fromTo x) ∙ cong fromSum path ∙ fromTo y)))

  dataRegularHausdorff : CoveringProperty intervalBalls → UnitIntervalCompact →
    (n : ℕ) → RegularHausdorff (dataTopology n)
  dataRegularHausdorff covering compactInterval n = dataRegular covering compactInterval n , dataT₀ n

