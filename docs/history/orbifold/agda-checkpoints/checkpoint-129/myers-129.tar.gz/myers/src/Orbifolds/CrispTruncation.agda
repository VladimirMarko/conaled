{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispTruncation where

-- An explicit ambient spatial-type-theory rule, not a native Agda theorem.
-- Shulman, arXiv:1509.07584v3, Section 5, Theorem 5.8 derives crisp
-- truncation induction from the sharp calculus. Safe Cubical Agda 2.8
-- does not provide that calculus or allow native --flat-split.
-- This uniform interface mentions no Weil algebra or geometric theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Crisp

FlatTruncationDistribution : {@♭ ℓ : Level} → Type (ℓ-suc ℓ)
FlatTruncationDistribution {ℓ} = (@♭ A : Type ℓ)
  → Flat (PT.∥ A ∥₁) → PT.∥ Flat A ∥₁

crisp-truncation-rec : {@♭ ℓ : Level} {ℓp : Level}
  → FlatTruncationDistribution {ℓ = ℓ}
  → (@♭ A : Type ℓ) → {P : Type ℓp} → isProp P
  → ((@♭ a : A) → P) → (@♭ witness : PT.∥ A ∥₁) → P
crisp-truncation-rec distribute A propP step witness =
  PT.rec propP (λ { (box a) → step a }) (distribute A (box witness))
