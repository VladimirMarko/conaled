{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalFillerCastCoherence where

-- Coherence of the actual typed filler action with strict endpoint
-- changes. Strict identity elimination and UIP suffice; no additional
-- comparison or coherence field is introduced.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-filler-compose)
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

strict-subst : ∀ {ℓ ℓ'} {A : Type ℓ} (B : A → Type ℓ') {a b : A}
  → outer a ≡ˢ outer b → B a → B b
strict-subst B reflˢ x = x

strict-sigma : ∀ {ℓ ℓ'} {A : Type ℓ} {B : A → Type ℓ'}
  {a b : A} {x : B a} {y : B b} (p : outer a ≡ˢ outer b)
  → outer (strict-subst B p x) ≡ˢ outer y
  → outer (a , x) ≡ˢ outer (b , y)
strict-sigma reflˢ reflˢ = reflˢ

strict-subst-Π : ∀ {ℓ ℓ' ℓ''} {A : Type ℓ} {Index : Type ℓ'}
  (B : A → Index → Type ℓ'') {a b : A} (p : outer a ≡ˢ outer b)
  (f : (c : Index) → B a c)
  → outer (strict-subst (λ x → (c : Index) → B x c) p f)
    ≡ˢ outer (λ c → strict-subst (λ x → B x c) p (f c))
strict-subst-Π B reflˢ f = reflˢ

cast-filler-isEquiv : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  {b b' : CS.Shell (toNat n) X} (p : outer b ≡ˢ outer b')
  → isEquiv (cast-filler n p)
cast-filler-isEquiv n reflˢ = idEquiv _ .snd

cast-filler-equivalence : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  {b b' : CS.Shell (toNat n) X} (p : outer b ≡ˢ outer b')
  → CF.Filler (toNat n) b ≃ CF.Filler (toNat n) b'
cast-filler-equivalence n p = cast-filler n p , cast-filler-isEquiv n p

cast-filler-computation : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  {b b' : CS.Shell (toNat n) X} (p : outer b ≡ˢ outer b')
  (c : CF.Filler (toNat n) b)
  → outer (cast-filler-equivalence n p .fst c) ≡ˢ outer (cast-filler n p c)
cast-filler-computation n p c = reflˢ

strict-subst-filler : ∀ {ℓ ℓ'} (n : Dim) {A : Type ℓ} {X : Type ℓ'}
  (boundary : A → CS.Shell (toNat n) X) {a b : A} (p : outer a ≡ˢ outer b)
  (c : CF.Filler (toNat n) (boundary a))
  → outer (strict-subst (λ x → CF.Filler (toNat n) (boundary x)) p c)
    ≡ˢ outer (cast-filler n (strict-cong (λ x → outer (boundary (inner x))) p) c)
strict-subst-filler n boundary reflˢ c = reflˢ

module Coherence {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module F = Fillers.Action E
  module S = Shells.Action E

  paste-map-cast : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    {a b : CS.Shell (toNat n) X} {c d : CS.Shell (toNat n) Y}
    (p : outer a ≡ˢ outer b)
    (q : outer (S.map-shell n f b) ≡ˢ outer c) (r : outer c ≡ˢ outer d)
    (s : outer (S.map-shell n f a) ≡ˢ outer d) (u : CF.Filler (toNat n) a)
    → outer (cast-filler n r (cast-filler n q (F.map-filler n f b (cast-filler n p u))))
      ≡ˢ outer (cast-filler n s (F.map-filler n f a u))
  paste-map-cast n f {a = a} reflˢ q r s u = strict-trans
    (cast-filler-compose n q r (F.map-filler n f a u))
    (strict-cong (λ e → outer (cast-filler n e (F.map-filler n f a u)))
      (strict-uip (strict-trans q r) s))
