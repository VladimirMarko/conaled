{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentActionData where

-- Finite, actual histories of coherent action cubes. All action layers
-- are inner types. Outer finite bounds only select already constructed
-- layers; equality of selections is proved from the finite indices.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; coordinate-face)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; Faces; OTop; star)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)

infix 4 _≤ᵈ_
data _≤ᵈ_ (m : Dim) : Dim → SSet where
  same : m ≤ᵈ m
  lower : {n : Dim} → m ≤ᵈ n → m ≤ᵈ osuc n

data Impossible : SSet where

impossible : ∀ {ℓ} {A : SSet ℓ} → Impossible → A
impossible ()

zero-bound : (n : Dim) → ozero ≤ᵈ n
zero-bound ozero = same
zero-bound (osuc n) = lower (zero-bound n)

successor-bound : {m n : Dim} → m ≤ᵈ n → osuc m ≤ᵈ osuc n
successor-bound same = same
successor-bound (lower p) = lower (successor-bound p)

down-left : {m n : Dim} → osuc m ≤ᵈ n → m ≤ᵈ n
down-left same = lower same
down-left (lower p) = lower (down-left p)

predecessor-bound : {m n : Dim} → osuc m ≤ᵈ osuc n → m ≤ᵈ n
predecessor-bound same = same
predecessor-bound (lower p) = down-left p

no-descending : (n : Dim) → osuc n ≤ᵈ n → Impossible
no-descending ozero ()
no-descending (osuc n) p = no-descending n (predecessor-bound p)

bound-irrelevance : {m n : Dim} (p q : m ≤ᵈ n) → p ≡ˢ q
bound-irrelevance same same = reflˢ
bound-irrelevance {n = osuc n} same (lower q) = impossible (no-descending n q)
bound-irrelevance {n = osuc n} (lower p) same = impossible (no-descending n p)
bound-irrelevance (lower p) (lower q) = strict-cong lower (bound-irrelevance p q)

transitive : {k m n : Dim} → k ≤ᵈ m → m ≤ᵈ n → k ≤ᵈ n
transitive p same = p
transitive p (lower q) = lower (transitive p q)

prefix-bound : (n : Dim) (p : Position (osuc n)) → prefix-degree n p ≤ᵈ n
prefix-bound n pzero = same
prefix-bound (osuc n) (psuc p) = lower (prefix-bound n p)

suffix-bound : (n : Dim) (p : Position (osuc n)) → suffix-degree n p ≤ᵈ n
suffix-bound n pzero = zero-bound n
suffix-bound (osuc n) (psuc p) = successor-bound (suffix-bound n p)

record LawPair {ℓ} (A B : SSet ℓ) : SSet ℓ where
  constructor law-pair
  field earlier : A
        current : B

module Data {ℓ : Level} (C : Category ℓ ℓ) (V : Category.Obj C → Type ℓ) where
  open Category C
  open Chains.Arrows C

  Top : Dim → Type ℓ
  Top n = {x y : Obj} → Chain n x y → V x → Cube n (V y)

  Actions : Dim → Type ℓ
  Actions ozero = Top ozero
  Actions (osuc n) = Actions n × Top (osuc n)

  top : (n : Dim) → Actions n → Top n
  top ozero F = F
  top (osuc n) F = F .snd

  at : {m n : Dim} → m ≤ᵈ n → Actions n → Top m
  at {m} same F = top m F
  at (lower p) F = at p (F .fst)

  truncate : {m n : Dim} → m ≤ᵈ n → Actions n → Actions m
  truncate same F = F
  truncate (lower p) F = truncate p (F .fst)

  lookup-irrelevance : {m n : Dim} (p q : m ≤ᵈ n) (F : Actions n)
    → outer {A = Top m} (at p F) ≡ˢ outer {A = Top m} (at q F)
  lookup-irrelevance {m} p q F = strict-cong (λ z → outer {A = Top m} (at z F)) (bound-irrelevance p q)

  top-truncate : {m n : Dim} (p : m ≤ᵈ n) (F : Actions n)
    → outer {A = Top m} (top m (truncate p F)) ≡ˢ outer {A = Top m} (at p F)
  top-truncate same F = reflˢ
  top-truncate (lower p) F = top-truncate p (F .fst)

  at-truncate : {k m n : Dim} (p : k ≤ᵈ m) (q : m ≤ᵈ n) (F : Actions n)
    → outer {A = Top k} (at p (truncate q F)) ≡ˢ outer {A = Top k} (at (transitive p q) F)
  at-truncate p same F = reflˢ
  at-truncate p (lower q) F = at-truncate p q (F .fst)

  one : (n : Dim) (F : Actions n) (p : Position (osuc n))
    {x y : Obj} → Chain (osuc n) x y → V x → Cube n (V y)
  one n F p c a = tensor-action n p
    (at (suffix-bound n p) F (split-suffix n p c))
    (at (prefix-bound n p) F (split-prefix n p c)) a

  faces : (n : Dim) (F : Actions n) {x y : Obj}
    → Chain (osuc n) x y → V x → Faces (osuc n) (V y)
  faces n F c a p low = top n F (face n p c) a
  faces n F c a p high = one n F p c a

  record LayerLaws (n : Dim) (F : Actions n) (next : Top (osuc n)) : SSet ℓ where
    field
      zero-face : (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y) (a : V x)
        → outer (coordinate-face n p i0 (next c a)) ≡ˢ outer (top n F (face n p c) a)
      one-face : (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y) (a : V x)
        → outer (coordinate-face n p i1 (next c a)) ≡ˢ outer (one n F p c a)

  Coherent : (n : Dim) → Actions n → SSet ℓ
  Coherent ozero F = OTop ℓ
  Coherent (osuc n) F = LawPair (Coherent n (F .fst)) (LayerLaws n (F .fst) (F .snd))

  coherent-truncate : {m n : Dim} (p : m ≤ᵈ n) (F : Actions n)
    → Coherent n F → Coherent m (truncate p F)
  coherent-truncate same F coherent = coherent
  coherent-truncate (lower p) F coherent = coherent-truncate p (F .fst) (LawPair.earlier coherent)

  law-at-zero : {m n : Dim} (bound : osuc m ≤ᵈ n) (F : Actions n) → Coherent n F
    → (p : Position (osuc m)) {x y : Obj} (c : Chain (osuc m) x y) (a : V x)
    → outer (coordinate-face m p i0 (at bound F c a))
      ≡ˢ outer (at (transitive (lower same) bound) F (face m p c) a)
  law-at-zero {m} bound F coherent p c a = strict-trans
    (strict-cong (λ f → outer (coordinate-face m p i0 (inner f c a)))
      (strict-sym (top-truncate bound F)))
    (strict-trans
      (LayerLaws.zero-face (LawPair.current (coherent-truncate bound F coherent)) p c a)
      (strict-cong (λ f → outer (inner f (face m p c) a))
        (at-truncate (lower same) bound F)))

  law-at-one : {m n : Dim} (bound : osuc m ≤ᵈ n) (F : Actions n) → Coherent n F
    → (p : Position (osuc m)) {x y : Obj} (c : Chain (osuc m) x y) (a : V x)
    → outer (coordinate-face m p i1 (at bound F c a))
      ≡ˢ outer (tensor-action m p
        (at (transitive (lower (suffix-bound m p)) bound) F (split-suffix m p c))
        (at (transitive (lower (prefix-bound m p)) bound) F (split-prefix m p c)) a)
  law-at-one {m} bound F coherent p c a = strict-trans
    (strict-cong (λ f → outer (coordinate-face m p i1 (inner f c a)))
      (strict-sym (top-truncate bound F)))
    (strict-trans
      (LayerLaws.one-face (LawPair.current (coherent-truncate bound F coherent)) p c a)
      (strict-trans
        (strict-cong (λ g → outer (tensor-action m p (inner g (split-suffix m p c))
          (at (prefix-bound m p) (truncate bound F .fst) (split-prefix m p c)) a))
          (at-truncate (lower (suffix-bound m p)) bound F))
        (strict-cong (λ f → outer (tensor-action m p
          (at (transitive (lower (suffix-bound m p)) bound) F (split-suffix m p c))
          (inner f (split-prefix m p c)) a))
          (at-truncate (lower (prefix-bound m p)) bound F))))
