{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- A geometric reduction of Theorem 6.3.7, not a completed interpretation
-- of ordinary proper étale groupoids in SDG.  Properness is imposed on the
-- actual source-target map.  Compact homs and finite homs are derived.
module Orbifolds.GroupoidGeometry where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Categories.Category using (Category)
open import Cubical.Algebra.CommRing.Base using (CommRing)
open import Cubical.Modalities.Modality using (Modality)
open import Cubical.Relation.Nullary using (Discrete)
open import Cubical.HITs.PropositionalTruncation using (∣_∣₁)

open import Orbifolds.Compactness using (DPCompact; equivDPCompact)
open import Orbifolds.ProperMaps using (DPProper; proper→CompactFibers)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.CountableCovers using (CountableProbe; Covers)
open import Orbifolds.Refinements using (CountablePenonBasis)
open import Orbifolds.CompactFiniteness
  using (SingletonMembers; secondCountableCompactSingletonCover→ProperlyFinite)
open import Orbifolds.ProperFiniteness using (ProperlyFinite)
open import Orbifolds.GroupoidCompletion using (AllInvertible; module Completion)
open import Orbifolds.GroupoidOrbifold using (module FiniteCompletion)
import Orbifolds.Microlinearity as ML
import Orbifolds.MicrolinearModal as MM
import Orbifolds.Orbifold as O
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.CountableRealProbe as RP

private
  variable
    ℓ ℓi : Level

-- The total arrow space is constructed from the hom-family, with its
-- actual source and target projections.  No fiber-identification axiom
-- occurs in this description.
module ArrowSpace (C : Category ℓ ℓ) where
  Objects : Type ℓ
  Objects = Category.ob C

  Hom : Objects → Objects → Type ℓ
  Hom = Category.Hom[_,_] C

  Arrows : Type ℓ
  Arrows = Σ[ xy ∈ Objects × Objects ] Hom (xy .fst) (xy .snd)

  source target : Arrows → Objects
  source a = a .fst .fst
  target a = a .fst .snd

  sourceTarget : Arrows → Objects × Objects
  sourceTarget = fst

  sourceTarget-components : (a : Arrows) → sourceTarget a ≡ (source a , target a)
  sourceTarget-components a = refl

  arrowSpace-isSet : isSet Objects → isSet Arrows
  arrowSpace-isSet setObjects =
    isSetΣ (isSet× setObjects setObjects) (λ _ → Category.isSetHom C)

  hom≃sourceTargetFiber : (x y : Objects)
    → Hom x y ≃ fiber sourceTarget (x , y)
  hom≃sourceTargetFiber x y =
    fiberProjEquiv (Objects × Objects) (λ xy → Hom (xy .fst) (xy .snd)) (x , y)

  sourceTargetFiber≃hom : (x y : Objects)
    → fiber sourceTarget (x , y) ≃ Hom x y
  sourceTargetFiber≃hom x y = invEquiv (hom≃sourceTargetFiber x y)

  -- This is the properness-to-compactness step in Theorem 6.3.7.
  -- Object sethood makes singletons of Objects × Objects genuine subtypes.
  properSourceTarget→CompactHoms : isSet Objects → DPProper sourceTarget
    → (x y : Objects) → DPCompact (Hom x y)
  properSourceTarget→CompactHoms setObjects proper x y =
    equivDPCompact (sourceTargetFiber≃hom x y)
      (proper→CompactFibers (isSet× setObjects setObjects) sourceTarget proper (x , y))

  singletonHom : (x y : Objects) → Hom x y → Hom x y → hProp ℓ
  singletonHom x y h k = (h ≡ k) , Category.isSetHom C h k

  singletonHom-covers : (x y : Objects) → Covers (singletonHom x y)
  singletonHom-covers x y h = ∣ h , refl ∣₁

  singletonHom-members : (x y : Objects) → SingletonMembers (singletonHom x y)
  singletonHom-members x y h hx hy = sym hx ∙ hy

  -- These are independently stated topological and logical inputs.  They
  -- contain neither compactness nor proper finiteness of the hom types.
  HomBases : Type (ℓ-suc ℓ)
  HomBases = (x y : Objects) → CountablePenonBasis (Hom x y)

  HomSingletonsOpen : HomBases → Type ℓ
  HomSingletonsOpen basis = (x y : Objects) (h : Hom x y)
    → CountablePenonBasis.Open (basis x y) (singletonHom x y h)

  DiscreteHoms : Type ℓ
  DiscreteHoms = (x y : Objects) → Discrete (Hom x y)

  -- Proper finite homs now follow from actual properness, the independent
  -- analytic cover machinery, and an open-singleton second-countable basis.
  -- The basis and singleton openness have not been manufactured from a
  -- placeholder manifold structure.
  properSourceTarget→ProperlyFiniteHoms : isSet Objects → DPProper sourceTarget
    → (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls
    → (basis : HomBases) → HomSingletonsOpen basis → DiscreteHoms
    → (x y : Objects) → ProperlyFinite (Hom x y)
  properSourceTarget→ProperlyFiniteHoms setObjects proper balls covering probes
    basis openSingletons discreteHoms x y =
    secondCountableCompactSingletonCover→ProperlyFinite balls covering probes
      (properSourceTarget→CompactHoms setObjects proper x y)
      (discreteHoms x y) (basis x y) (singletonHom x y)
      (openSingletons x y) (singletonHom-covers x y) (singletonHom-members x y)

module CompletionGeometry (C : Category ℓ ℓ) (invertible : AllInvertible C) where
  open ArrowSpace C
  module Completed = Completion C invertible
  module Finite = FiniteCompletion C invertible

  module ModalGeometry (M : Modality ℓ) {Index : Type ℓi}
    (test : Index → ML.TestSquare ℓ)
    (connected-tests : (t : Index) → MM.Theory.ConnectedSquare M (test t)) where
    module Modal = MM.Theory M
    module Family = Modal.Family test connected-tests
    module Orb = O.Geometry test
    module Finish = Finite.ModalGeometry M test connected-tests

    -- Geometric reduction of Theorem 6.3.7.  Every finite-identity and
    -- compactness conclusion is derived in this chain.  Remaining inputs
    -- include a hom-basis, open singletons, decidable equality of homs,
    -- and modal etaleness of the actual canonical completion map.
    -- The paper derives these from ordinary-manifold/crisp/crystalline
    -- geometry; those derivations remain separate obligations.
    properEtaleCompletionOrbifoldReduction :
      isSet Objects → DPProper sourceTarget
      → (balls : BallStructure ℓ) → CoveringProperty balls → CountableProbe balls
      → (basis : HomBases) → HomSingletonsOpen basis → DiscreteHoms
      → Family.Microlinear Objects
      → Modal.Etale Completed.object
      → Orb.Orbifold Completed.Object
    properEtaleCompletionOrbifoldReduction setObjects proper balls covering probes
      basis openSingletons discreteHoms mlObjects canonicalEtale =
      Finish.completionOrbifoldFromModalEtale
        (properSourceTarget→ProperlyFiniteHoms setObjects proper balls covering probes
          basis openSingletons discreteHoms)
        mlObjects canonicalEtale

    module OrderedReals (R : CommRing ℓ)
      (kock : SF.RingContext.KockField R)
      (order : SF.RingContext.StrictOrder R)
      (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
      module Probe = RP.RealProbe R kock order compatibility

      -- Here CountableProbe is discharged by actual ordered-ring and
      -- Archimedean arithmetic.  The interval-ball Covering Property is
      -- the explicit remaining Postulate E input.
      properEtaleCompletionFromOrderedReals :
        isSet Objects → DPProper sourceTarget
        → CoveringProperty Probe.intervalBalls
        → (basis : HomBases) → HomSingletonsOpen basis → DiscreteHoms
        → Family.Microlinear Objects
        → Modal.Etale Completed.object
        → Orb.Orbifold Completed.Object
      properEtaleCompletionFromOrderedReals setObjects proper covering =
        properEtaleCompletionOrbifoldReduction setObjects proper
          Probe.intervalBalls covering Probe.realCountableProbe
