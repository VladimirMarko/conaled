{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FiniteInvariantInnerProducts where

-- A finite group of actual module automorphisms preserves a positive
-- definite bilinear form obtained by summing translates of any given
-- such form. The finite enumeration is eliminated only into a mere
-- existence claim. We neither divide by the group order nor choose an
-- enumeration globally.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc)
open import Cubical.Data.FinSet.Base using (isFinSet)
open import Cubical.Relation.Nullary using (¬_)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Algebra.Module.Base
open import Cubical.Algebra.Module.Properties using (module ModuleTheory)
open import Cubical.Algebra.Group.Base
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.EuclideanNorms as EN
import Orbifolds.ModuleInnerProducts as MI
import Orbifolds.FiniteRingSums as FS

module Ordered {ℓr : Level} (R : CommRing ℓr)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open SF.RingContext.StrictOrder order
  open SO.OrderTheory.Compatible R order compatibility using (lessAsym)
  module Norms = EN.Norms R kock order compatibility
  open FS.Ring R

  abstract
    sum-nonnegative : (n : ℕ) (f : Fin n → R .fst)
      → ((i : Fin n) → Norms.Nonnegative (f i))
      → Norms.Nonnegative (sum n f)
    sum-nonnegative zero f nonnegative = irreflexive 0r
    sum-nonnegative (suc n) f nonnegative = Norms.nonnegativeAdd
      (nonnegative fzero)
      (sum-nonnegative n (λ i → f (fsuc i)) (λ i → nonnegative (fsuc i)))

    sum-positive-at : (n : ℕ) (f : Fin n → R .fst)
      → ((j : Fin n) → Norms.Nonnegative (f j))
      → (i : Fin n) → 0r < f i → 0r < sum n f
    sum-positive-at zero f nonnegative ()
    sum-positive-at (suc n) f nonnegative fzero positive =
      Norms.positiveAddNonnegative positive
        (sum-nonnegative n (λ i → f (fsuc i)) (λ i → nonnegative (fsuc i)))
    sum-positive-at (suc n) f nonnegative (fsuc i) positive =
      Norms.nonnegativeAddPositive (nonnegative fzero)
        (sum-positive-at n (λ j → f (fsuc j)) (λ j → nonnegative (fsuc j)) i positive)

  module OnModule {ℓm : Level} (M : LeftModule (CommRing→Ring R) ℓm) where
    module MS = LeftModuleStr (M .snd)
    module MT = ModuleTheory (CommRing→Ring R) M
    module Forms = MI.Theory R order M
    module Coordinates = MI.ChangeCoordinates {ℓm = ℓm} R order

    abstract
      norm-zero : (form : Forms.InnerProduct) → Forms.norm form MS.0m ≡ 0r
      norm-zero form =
        sym (cong (λ x → Forms.InnerProduct.pairing form x MS.0m) (MT.⋆AnnihilL MS.0m))
        ∙ Forms.InnerProduct.homogeneous-left form 0r MS.0m MS.0m
        ∙ 0LeftAnnihilates (Forms.norm form MS.0m)

      norm-nonnegative : (form : Forms.InnerProduct) (x : M .fst)
        → Norms.Nonnegative (Forms.norm form x)
      norm-nonnegative form x negative = lessAsym
        (Forms.InnerProduct.positive form x
          (λ vanishes → irreflexive 0r
            (subst (_< 0r) (cong (Forms.norm form) vanishes ∙ norm-zero form) negative)))
        negative

    module FiniteAction {ℓh : Level} (H : Group ℓh)
        (action : H .fst → LeftModuleEquiv M M)
        (compose : (g h : H .fst) (x : M .fst)
          → action (GroupStr._·_ (H .snd) g h) .fst .fst x
            ≡ action g .fst .fst (action h .fst .fst x)) where
      module HS = GroupStr (H .snd)

      Invariant : Forms.InnerProduct → Type (ℓ-max ℓh (ℓ-max ℓr ℓm))
      Invariant form = (h : H .fst) (x y : M .fst)
        → Forms.InnerProduct.pairing form
            (action h .fst .fst x) (action h .fst .fst y)
          ≡ Forms.InnerProduct.pairing form x y

      right-translation : (h : H .fst) → H .fst ≃ H .fst
      right-translation h = isoToEquiv (iso
        (λ g → g HS.· h) (λ g → g HS.· HS.inv h)
        (λ g → sym (HS.·Assoc g (HS.inv h) h)
          ∙ cong (g HS.·_) (HS.·InvL h) ∙ HS.·IdR g)
        (λ g → sym (HS.·Assoc g h (HS.inv h))
          ∙ cong (g HS.·_) (HS.·InvR h) ∙ HS.·IdR g))

      module Enumerated (n : ℕ) (e : H .fst ≃ Fin n)
          (original : Forms.InnerProduct) where
        enumeration : Fin n → H .fst
        enumeration = invEq e

        translate : H .fst → Forms.InnerProduct
        translate h = Coordinates.pullback (action h) original

        pairing : M .fst → M .fst → R .fst
        pairing x y = sum n (λ i → Forms.InnerProduct.pairing (translate (enumeration i)) x y)

        averaged : Forms.InnerProduct
        Forms.InnerProduct.pairing averaged = pairing
        Forms.InnerProduct.symmetric averaged x y =
          sum-ext n (λ i → Forms.InnerProduct.symmetric (translate (enumeration i)) x y)
        Forms.InnerProduct.additive-left averaged x y z =
          sum-ext n (λ i → Forms.InnerProduct.additive-left (translate (enumeration i)) x y z)
          ∙ sum-add n
              (λ i → Forms.InnerProduct.pairing (translate (enumeration i)) x z)
              (λ i → Forms.InnerProduct.pairing (translate (enumeration i)) y z)
        Forms.InnerProduct.homogeneous-left averaged r x y =
          sum-ext n (λ i → Forms.InnerProduct.homogeneous-left (translate (enumeration i)) r x y)
          ∙ sum-scale n r
              (λ i → Forms.InnerProduct.pairing (translate (enumeration i)) x y)
        Forms.InnerProduct.positive averaged x nonzero =
          sum-positive-at n
            (λ i → Forms.norm (translate (enumeration i)) x)
            (λ i → norm-nonnegative (translate (enumeration i)) x)
            (e .fst HS.1g)
            (Forms.InnerProduct.positive
              (translate (enumeration (e .fst HS.1g))) x nonzero)

        permutation : H .fst → Fin n ≃ Fin n
        permutation h = compEquiv (invEquiv e) (compEquiv (right-translation h) e)

        abstract
          invariant : Invariant averaged
          invariant h x y =
            sum-ext n (λ i → cong₂ (Forms.InnerProduct.pairing original)
              (sym (compose (enumeration i) h x)) (sym (compose (enumeration i) h y)))
            ∙ sum-ext n (λ i → cong
                (λ g → Forms.InnerProduct.pairing (translate g) x y)
                (sym (retEq e (enumeration i HS.· h))))
            ∙ reindex n (permutation h)
                (λ i → Forms.InnerProduct.pairing (translate (enumeration i)) x y)

      invariant-inner-product : isFinSet (H .fst) → Forms.InnerProduct
        → PT.∥ Σ[ form ∈ Forms.InnerProduct ] Invariant form ∥₁
      invariant-inner-product finite original = PT.map
        (λ e → Enumerated.averaged (finite .fst) e original ,
          Enumerated.invariant (finite .fst) e original)
        (finite .snd)
