{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPacketLastProjection where

-- Project the existing last path while the canonical cell packet is still
-- neutral. Its lower strict equality is derived from the packet's actual
-- construction equality. Its lower endpoint signature is normalized while
-- Inputs is neutral; the final cell-cocone target remains compared once.
-- No first-prefix or preservation law is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle using (typeOf)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as Pasting
import Orbifolds.Coherent.StrictImagePaths as Image

inverse-image-equality : {ℓa ℓb : Level} (A : Type ℓa) (B : Type ℓb)
  (k : A → B) (x y : A) → outer x ≡ˢ outer y → outer (k y) ≡ˢ outer (k x)
inverse-image-equality A B k x y r =
  strict-sym {A = Outer B} {x = outer (k x)} {y = outer (k y)}
    (strict-cong {A = Outer A} {B = Outer B}
      (λ s → outer (k (inner s))) {x = outer x} {y = outer y} r)

project-inverse-image : {ℓa ℓb ℓc : Level}
  (A : Type ℓa) (B : Type ℓb) (C₀ : Type ℓc)
  (k : A → B) (u : B → C₀) (x y : A) (r : outer x ≡ˢ outer y)
  → cong u (Image.strict-image-sym-path A B k x y r)
    ≡ strict-to-path {A = C₀} {x = u (k y)} {y = u (k x)}
        (inverse-image-equality A C₀ (λ a → u (k a)) x y r)
project-inverse-image A B C₀ k u x .x reflˢ = refl

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module Packet = Pasting.Construction.Packet C D G α E F n source target f triangle
    using (Inputs; module Inputs)
  module CD = Cocones.Functoriality C D E F using (Cocone)
  module TG = Comparison.Comparison C G E F n target using (compare)
  module CG = Cocones.Functoriality C G E F using (Cocone; postcompose)

  uG : CG.Cocone (Represented.Induction.Represented.Space target) n
  uG = Represented.Induction.Represented.universal-cocone target

  module ForInput (inputs : Packet.Inputs) where
    module Data = Packet.Inputs inputs using (Y; s; t; r)
    module Paths = Pasting.Construction.ForInput C D G α E F n source target f triangle inputs
      using (last)
    open Paths public using (last)

    map-cell : typeOf Data.s → CD.Cocone Data.Y (osuc n)
    map-cell s = Restriction.Restriction.finite-restriction C D G α E F
      Data.Y (osuc n) (TG.compare Data.Y s)

    prefix : CD.Cocone Data.Y (osuc n) → CD.Cocone Data.Y n
    prefix = fst

    last-equality : outer {A = CD.Cocone Data.Y n}
        (Restriction.Restriction.finite-restriction C D G α E F Data.Y n
          (CG.postcompose n {Y = Represented.Induction.Represented.Space target}
            {Z = Data.Y} (Data.s .fst) uG))
      ≡ˢ outer {A = CD.Cocone Data.Y n}
        (Restriction.Restriction.finite-restriction C D G α E F Data.Y n
          (TG.compare Data.Y Data.t .fst))
    last-equality = inverse-image-equality (typeOf Data.s) (CD.Cocone Data.Y n)
      (λ s → prefix (map-cell s)) Data.t Data.s Data.r

    abstract
      last-prefix : cong prefix last ≡ strict-to-path last-equality
      last-prefix = project-inverse-image (typeOf Data.s)
        (CD.Cocone Data.Y (osuc n)) (CD.Cocone Data.Y n)
        map-cell prefix Data.t Data.s Data.r
