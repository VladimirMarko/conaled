{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalShellSpheres where

-- The recursively specified full cubical shells are represented by
-- actual iterated-suspension spheres. This compares their complete
-- mapping types, including all corner and higher overlap data.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Unit using (Unit; tt)
open import Cubical.Data.Empty using (⊥)
import Cubical.HITs.Susp as S
open import Orbifolds.CubicalShells
import Orbifolds.MicrolinearityLimits as ML

SphereBoundary : ℕ → Type₀
SphereBoundary zero = ⊥
SphereBoundary (suc n) = S.Susp (SphereBoundary n)

module SuspensionMapping {ℓa ℓx : Level} (A : Type ℓa) (X : Type ℓx) where
  Cocone : Type (ℓ-max ℓa ℓx)
  Cocone = Σ[ ends ∈ (X × X) ]
    ((λ (_ : A) → ends .fst) ≡ (λ (_ : A) → ends .snd))

  assemble : Cocone → S.Susp A → X
  assemble c S.north = c .fst .fst
  assemble c S.south = c .fst .snd
  assemble c (S.merid a i) = c .snd i a

  restrict : (S.Susp A → X) → Cocone
  restrict f = (f S.north , f S.south) , (λ i a → f (S.merid a i))

  assemble-restrict : (f : S.Susp A → X) → assemble (restrict f) ≡ f
  assemble-restrict f i S.north = f S.north
  assemble-restrict f i S.south = f S.south
  assemble-restrict f i (S.merid a j) = f (S.merid a j)

  universal : Cocone ≃ (S.Susp A → X)
  universal = isoToEquiv (iso assemble restrict assemble-restrict (λ _ → refl))

-- Transport a literal pullback along equivalences of its three objects,
-- with specified commuting squares. The forward map uses exactly the
-- two endpoint maps and the conjugated boundary path.
span-equivalence : ∀ {ℓa ℓb ℓk ℓx}
  {A : Type ℓa} {B : Type ℓb} {K : Type ℓk} {X : Type ℓx}
  (r : A → B) (e : A ≃ X) (q : B ≃ (K → X))
  (square : (a : A) → q .fst (r a) ≡ (λ _ → e .fst a))
  → ML.Pullback r r ≃ SuspensionMapping.Cocone K X
span-equivalence r e q square = Σ-cong-equiv (≃-× e e) λ ends →
  (congEquiv q ∙ₑ compPathlEquiv (sym (square (ends .fst))))
    ∙ₑ compPathrEquiv (square (ends .snd))

cancel-conjugated-refl : ∀ {ℓ} {A : Type ℓ} {x y : A} (p : x ≡ y)
  → (sym p ∙ refl) ∙ p ≡ refl
cancel-conjugated-refl p = cong (_∙ p) (sym (rUnit (sym p))) ∙ lCancel p

mutual
  shell-equivalence : ∀ {ℓ} (n : ℕ) (X : Type ℓ)
    → Shell n X ≃ (SphereBoundary n → X)
  shell-equivalence zero X = isoToEquiv
    (iso (λ _ ()) (λ _ → lift tt) (λ f → funExt (λ ())) (λ _ → refl))
  shell-equivalence (suc n) X =
    span-equivalence (restriction n) (cube-equivalence n X)
      (shell-equivalence n X) (restriction-computation n X)
      ∙ₑ SuspensionMapping.universal (SphereBoundary n) X

  restriction-computation : ∀ {ℓ} (n : ℕ) (X : Type ℓ) (c : Cube n X)
    → shell-equivalence n X .fst (restriction n c)
      ≡ (λ _ → origin n c)
  restriction-computation n X c =
    cong (shell-equivalence n X .fst) (sym (shell-constant-homotopy n c))
      ∙ constant-computation n X (origin n c)

  constant-computation : ∀ {ℓ} (n : ℕ) (X : Type ℓ) (x : X)
    → shell-equivalence n X .fst (restriction n (constant-cube n x))
      ≡ (λ _ → x)
  constant-computation zero X x = funExt (λ ())
  constant-computation (suc n) X x = null-loop ∙ cong (λ y _ → y) (origin-constant n x)
    where
    c : Cube n X
    c = constant-cube n x

    p : shell-equivalence n X .fst (restriction n c) ≡ (λ _ → origin n c)
    p = restriction-computation n X c

    null-loop : shell-equivalence (suc n) X .fst
      (restriction (suc n) (constant-cube (suc n) x))
      ≡ (λ _ → origin n c)
    null-loop i S.north = origin n c
    null-loop i S.south = origin n c
    null-loop i (S.merid b j) = cancel-conjugated-refl p i j b

-- The actual sphere-valued boundary map is the first projection of the
-- proved equivalence; its contraction is a theorem, not a truncation.
evaluate-shell : ∀ {ℓ} (n : ℕ) {X : Type ℓ}
  → Shell n X → SphereBoundary n → X
evaluate-shell n {X} = shell-equivalence n X .fst

boundary-of-cube-contracts : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (c : Cube n X)
  → evaluate-shell n (restriction n c) ≡ (λ _ → origin n c)
boundary-of-cube-contracts n {X} = restriction-computation n X
