{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalShellMaps where

-- Literal finite coordinate action on shells and on the strict face
-- assembler. The explicit extensionality structure is the one already
-- used by the strict assembler. Comparison with the representable inner
-- shell action is a separate mathematical obligation.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Agda.Primitive using (SSet)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position; pzero; psuc)
open import Orbifolds.Coherent.OuterCubicalFaces using
  (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalShellAssembly using
  (Endpoint; low; high; endpoint; Faces; Compatible; OTop; star; slice-faces; slice-compatible;
   strict-end-path; strict-end-path-value)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
import Orbifolds.CubicalShells as CS

module Action {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module Assemble = Assembly.Construction E
  module CoordinateLaws = Cubes.Extensional E
  module FillerLaws = Fillers.Boundary E

  mutual
    map-shell : (n : Dim) {X Y : Type ℓ} → (X → Y)
      → CS.Shell (toNat n) X → CS.Shell (toNat n) Y
    map-shell ozero f b = lift tt
    map-shell (osuc n) f ((lo , hi) , p) =
      (map-cube n f lo , map-cube n f hi) ,
      strict-end-path (λ i → map-shell n f (p i))
        (restriction-natural n f lo) (restriction-natural n f hi)

    restriction-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X)
      → outer (map-shell n f (CS.restriction (toNat n) c))
        ≡ˢ outer (CS.restriction (toNat n) (map-cube n f c))
    restriction-natural ozero f c = reflˢ
    restriction-natural (osuc n) f c = Assemble.shell-correct n
      (map-cube n f (c i0)) (map-cube n f (c i1))
      (λ i → map-shell n f (CS.restriction (toNat n) (c i)))
      (restriction-natural n f (c i0)) (restriction-natural n f (c i1))
      (map-cube (osuc n) f c) reflˢ reflˢ
      (λ i → restriction-natural n f (c i))

  side-computation : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (b : CS.Shell (toNat (osuc n)) X) (i : I)
    → outer (map-shell (osuc n) f b .snd i) ≡ˢ outer (map-shell n f (b .snd i))
  side-computation n f b i = strict-end-path-value
    (λ j → map-shell n f (b .snd j))
    (restriction-natural n f (b .fst .fst))
    (restriction-natural n f (b .fst .snd)) i

  map-faces : (n : Dim) {X Y : Type ℓ} → (X → Y) → Faces n X → Faces n Y
  map-faces ozero f F = star
  map-faces (osuc n) f F p e = map-cube n f (F p e)

  map-compatible : (n : Dim) {X Y : Type ℓ} (f : X → Y) (F : Faces n X)
    → Compatible n F → Compatible n (map-faces n f F)
  map-compatible ozero f F compatible = star
  map-compatible (osuc ozero) f F compatible = star
  map-compatible (osuc (osuc n)) f F compatible p q le e d = strict-trans
    (strict-sym (CoordinateLaws.map-face n p (endpoint e) f (F _ d)))
    (strict-trans
      (strict-cong (λ c → outer (map-cube n f (inner c))) (compatible p q le e d))
      (CoordinateLaws.map-face n q (endpoint d) f (F _ e)))

  map-slice : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (F : Faces (osuc n) X) (i : I)
    → slice-faces n (map-faces (osuc n) f F) i
      ≡ˢ map-faces n f (slice-faces n F i)
  map-slice ozero f F i = reflˢ
  map-slice (osuc n) f F i = reflˢ

  mutual
    assemble-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
      (F : Faces n X) (source-compatible : Compatible n F)
      (target-compatible : Compatible n (map-faces n f F))
      → outer (map-shell n f (Assemble.assemble n F source-compatible))
        ≡ˢ outer (Assemble.assemble n (map-faces n f F) target-compatible)
    assemble-natural ozero f F source-compatible target-compatible = reflˢ
    assemble-natural (osuc n) {X} {Y} f F source-compatible target-compatible =
      FillerLaws.shell-equality n
        (map-cube n f (F _ low)) (map-cube n f (F _ high))
        (map-cube n f (F _ low)) (map-cube n f (F _ high))
        (map-shell (osuc n) f (Assemble.assemble (osuc n) F source-compatible) .snd)
        (Assemble.assemble (osuc n) (map-faces (osuc n) f F) target-compatible .snd)
        reflˢ reflˢ
        (λ i → strict-trans
          (side-computation n f (Assemble.assemble (osuc n) F source-compatible) i)
          (strict-trans
            (strict-cong (λ b → outer (map-shell n f (inner b)))
              (strict-end-path-value
                (Assemble.Step.side-shell n X (Assemble.assembler n X) F source-compatible)
                (Assemble.Step.side-at-end n X (Assemble.assembler n X) F source-compatible low)
                (Assemble.Step.side-at-end n X (Assemble.assembler n X) F source-compatible high) i))
            (strict-trans
              (assemble-natural-along n f (slice-faces n F i)
                (slice-compatible n F source-compatible i)
                (slice-faces n (map-faces (osuc n) f F) i)
                (slice-compatible n (map-faces (osuc n) f F) target-compatible i)
                (map-slice n f F i))
              (strict-sym (strict-end-path-value
                (Assemble.Step.side-shell n Y (Assemble.assembler n Y)
                  (map-faces (osuc n) f F) target-compatible)
                (Assemble.Step.side-at-end n Y (Assemble.assembler n Y)
                  (map-faces (osuc n) f F) target-compatible low)
                (Assemble.Step.side-at-end n Y (Assemble.assembler n Y)
                  (map-faces (osuc n) f F) target-compatible high) i)))))

    assemble-natural-along : (n : Dim) {X Y : Type ℓ} (f : X → Y)
      (F : Faces n X) (source-compatible : Compatible n F)
      (G : Faces n Y) (target-compatible : Compatible n G)
      → G ≡ˢ map-faces n f F
      → outer (map-shell n f (Assemble.assemble n F source-compatible))
        ≡ˢ outer (Assemble.assemble n G target-compatible)
    assemble-natural-along n f F source-compatible .(map-faces n f F) target-compatible reflˢ =
      assemble-natural n f F source-compatible target-compatible

  Facewise : (n : Dim) {X : Type ℓ} → Faces n X → Faces n X → SSet ℓ
  Facewise ozero F G = OTop ℓ
  Facewise (osuc n) F G = (p : Position (osuc n)) (e : Endpoint)
    → outer (F p e) ≡ˢ outer (G p e)

  slice-facewise : (n : Dim) {X : Type ℓ} (F G : Faces (osuc n) X)
    → Facewise (osuc n) F G → (i : I)
    → Facewise n (slice-faces n F i) (slice-faces n G i)
  slice-facewise ozero F G agree i = star
  slice-facewise (osuc n) F G agree i p e =
    strict-cong (λ c → outer (inner c i)) (agree (psuc p) e)

  -- Pointwise face agreement suffices. In particular no strict function
  -- extensionality for Position/Endpoint-indexed face systems is needed.
  assemble-facewise : (n : Dim) {X : Type ℓ} (F G : Faces n X)
    (compatible-F : Compatible n F) (compatible-G : Compatible n G)
    → Facewise n F G
    → outer (Assemble.assemble n F compatible-F)
      ≡ˢ outer (Assemble.assemble n G compatible-G)
  assemble-facewise ozero F G compatible-F compatible-G agree = reflˢ
  assemble-facewise (osuc n) {X} F G compatible-F compatible-G agree =
    FillerLaws.shell-equality n (F pzero low) (F pzero high) (G pzero low) (G pzero high)
      (Assemble.assemble (osuc n) F compatible-F .snd)
      (Assemble.assemble (osuc n) G compatible-G .snd)
      (agree pzero low) (agree pzero high)
      (λ i → strict-trans
        (strict-end-path-value
          (Assemble.Step.side-shell n X (Assemble.assembler n X) F compatible-F)
          (Assemble.Step.side-at-end n X (Assemble.assembler n X) F compatible-F low)
          (Assemble.Step.side-at-end n X (Assemble.assembler n X) F compatible-F high) i)
        (strict-trans
          (assemble-facewise n (slice-faces n F i) (slice-faces n G i)
            (slice-compatible n F compatible-F i) (slice-compatible n G compatible-G i)
            (slice-facewise n F G agree i))
          (strict-sym (strict-end-path-value
            (Assemble.Step.side-shell n X (Assemble.assembler n X) G compatible-G)
            (Assemble.Step.side-at-end n X (Assemble.assembler n X) G compatible-G low)
            (Assemble.Step.side-at-end n X (Assemble.assembler n X) G compatible-G high) i))))

  assemble-natural-facewise : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (F : Faces n X) (source-compatible : Compatible n F)
    (G : Faces n Y) (target-compatible : Compatible n G)
    → Facewise n (map-faces n f F) G
    → outer (map-shell n f (Assemble.assemble n F source-compatible))
      ≡ˢ outer (Assemble.assemble n G target-compatible)
  assemble-natural-facewise n f F source-compatible G target-compatible agree = strict-trans
    (assemble-natural n f F source-compatible (map-compatible n f F source-compatible))
    (assemble-facewise n (map-faces n f F) G
      (map-compatible n f F source-compatible) target-compatible agree)
