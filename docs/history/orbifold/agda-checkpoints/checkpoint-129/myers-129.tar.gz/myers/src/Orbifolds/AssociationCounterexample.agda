{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- A constructive refutation of Proposition 6.1.7 as printed, including its
-- unbounded existential conclusion.  A two-point example would only refute
-- preservation of the proposed bound; using ℕ refutes the statement itself.
module Orbifolds.AssociationCounterexample where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Empty using (⊥; isProp⊥)
open import Cubical.Data.Unit using (Unit*; tt*; isPropUnit*)
open import Cubical.Data.Nat using (ℕ; suc; isSetℕ; znots)
open import Cubical.Data.Nat.Order using (¬m<m)
open import Cubical.Data.SumFin
  using (Fin; fzero; toℕ; toℕ-injective; isSetFin; isContrSumFin1)
open import Cubical.Data.FinSet.Properties using (isFinSetFin)
open import Cubical.Data.FinSet.FiniteChoice using (choice≃Fin)
open import Cubical.Data.FinSet.Cardinality using (card↪Inequality)
open import Cubical.Functions.Embedding
open import Cubical.HITs.PropositionalTruncation as PT
  using (∥_∥₁; ∣_∣₁; squash₁)
open import Cubical.Relation.Nullary using (¬_)

open import Orbifolds.Association

private
  variable
    ℓ ℓ' ρ : Level

-- This is the paper's printed, opposite uniqueness direction.
record PrintedAssociation (X : Type ℓ) (Y : Type ℓ') (ρ : Level)
    : Type (ℓ-max (ℓ-max ℓ ℓ') (ℓ-suc ρ)) where
  field
    printed-rel : X → Y → Type ρ
    printed-rel-isProp : (x : X) (y : Y) → isProp (printed-rel x y)
    printed-total : (x : X) → ∥ Σ[ y ∈ Y ] printed-rel x y ∥₁
    right-unique : {x : X} {y y' : Y}
      → printed-rel x y → printed-rel x y' → y ≡ y'

open PrintedAssociation public

-- The constant relation to the sole finite label satisfies every printed
-- hypothesis for every type X, with no finiteness assumption on X.
all-types-have-printed-association : (X : Type ℓ)
  → PrintedAssociation X (Fin 1) ℓ
printed-rel (all-types-have-printed-association X) x i = Unit*
printed-rel-isProp (all-types-have-printed-association X) x i = isPropUnit*
printed-total (all-types-have-printed-association X) x = ∣ fzero , tt* ∣₁
right-unique (all-types-have-printed-association X) {y = i} {y' = j} r s =
  isContr→isProp isContrSumFin1 i j

PrintedFiniteAssociation : (X : Type ℓ) → Type (ℓ-suc ℓ)
PrintedFiniteAssociation {ℓ = ℓ} X =
  ∥ Σ[ n ∈ ℕ ] PrintedAssociation X (Fin n) ℓ ∥₁

printed-finite-association-is-vacuous : (X : Type ℓ) → PrintedFiniteAssociation X
printed-finite-association-is-vacuous X = ∣ 1 , all-types-have-printed-association X ∣₁

-- The graph projection in the printed proof really can identify different
-- points.  This fails the corrected property already at the points 0 and 1.
constant-relation-not-left-unique :
  ¬ ((x y : ℕ)
    → printed-rel (all-types-have-printed-association ℕ) x fzero
    → printed-rel (all-types-have-printed-association ℕ) y fzero
    → x ≡ y)
constant-relation-not-left-unique unique = znots (unique 0 1 tt* tt*)

-- Pigeonhole principle in the pinned library rules out an injection of
-- n+1 labels into n labels.  No classical choice is used.
no-successor-injection : {n : ℕ} (f : Fin (suc n) → Fin n)
  → (∀ {i j} → f i ≡ f j → i ≡ j) → ⊥
no-successor-injection {n} f injective =
  ¬m<m (card↪Inequality (Fin (suc n) , isFinSetFin) (Fin n , isFinSetFin)
    ∣ f , injEmbedding isSetFin injective ∣₁)

-- If ℕ had a corrected association with n labels, finitely many choices
-- for 0,...,n would yield an injection Fin(n+1) -> Fin n.  Finite choice is
-- a constructive theorem for propositional truncation, not an axiom.
no-finite-association-for-ℕ : (n : ℕ) → Association ℕ (Fin n) ℓ-zero → ⊥
no-finite-association-for-ℕ n R = PT.rec isProp⊥ impossible
  (choice≃Fin witnesses .fst (λ k → total R (toℕ k)))
  where
  witnesses : Fin (suc n) → Type₀
  witnesses k = Σ[ i ∈ Fin n ] rel R (toℕ k) i

  impossible : ((k : Fin (suc n)) → witnesses k) → ⊥
  impossible choose = no-successor-injection (λ k → choose k .fst)
    (λ {i} {j} p → toℕ-injective
      (left-unique R (choose i .snd)
        (subst (rel R (toℕ j)) (sym p) (choose j .snd))))

ℕ-not-subfinitely-enumerable : ¬ SubfinitelyEnumerable ℕ
ℕ-not-subfinitely-enumerable = PT.rec isProp⊥
  (λ { (n , W) → no-finite-association-for-ℕ n (span→association isSetℕ W) })

-- The implication asserted in the printed proposition, with its actual
-- existential bound, is false.  This is a checked negation, not a postulate
-- containing the error as an assumed fact.
PrintedCriterion : Type₁
PrintedCriterion = (X : Type₀) → isSet X
  → PrintedFiniteAssociation X → SubfinitelyEnumerable X

printed-criterion-is-false : ¬ PrintedCriterion
printed-criterion-is-false criterion = ℕ-not-subfinitely-enumerable
  (criterion ℕ isSetℕ (printed-finite-association-is-vacuous ℕ))
