{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentConeStages where

-- Actual all-dimensional cone stages for an arbitrary quasi-unital
-- homotopy-coherent diagram, including every nonconstant suffix cell. Each new layer is the inner
-- type of endpoint-typed fillers for the computed chain/cut boundaries.
-- Its strict coherence laws are theorems extracted from those fillers.
-- The infinite construction is an ordinary inverse tower obtained from
-- a coinductive schedule; there is no product over an outer natural type.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (low; high; star)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
open import Orbifolds.Coherent.HomotopyCoherentActionData using (LawPair)
import Orbifolds.Coherent.HomotopyCoherentConeData as Data
import Orbifolds.Coherent.HomotopyCoherentConeCompatibility as Compatibility
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
import Orbifolds.CubicalConeAttachments as Attachments
import Orbifolds.CellularConeMicrolinearity as Towers
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open HC.ForCategory.Diagram D using (Value)
  open Chains C
  open Data.Data C D
  open Data.Data.Coherence C D E

  module Step (n : Dim) (Previous : Type ℓ)
      (F : Families n Previous) (coherent : Coherent n F) where
    Cells : Type ℓ
    Cells = Index (osuc n)

    dimension : Cells → ℕ
    dimension c = toNat (osuc n)

    target : Cells → Obj
    target = fst

    Coefficient : Cells → Type ℓ
    Coefficient c = Value (target c)

    boundary-data : Previous → (c : Cells) → CS.Shell (dimension c) (Coefficient c)
    boundary-data s (y , c) = Assembly.Construction.assemble E (osuc n)
      (bar-faces n F s c)
      (Compatibility.Compatibility.bar-compatible C D E n F coherent s c)

    module A = Attachments.Attachment Previous Cells dimension Coefficient boundary-data
    open A using (Next; forget; filler; ExtensionCone; extension-universal;
      assemble-forget; assemble-filler) public

    next-cubes : Top (osuc n) Next
    next-cubes s y c = CF.forget-filler (toNat (osuc n))
      (boundary-data (forget s) (y , c)) (filler s (y , c))

    next-families : Families (osuc n) Next
    next-families = reindex n F forget , next-cubes

    next-coherent : Coherent (osuc n) next-families
    LawPair.earlier next-coherent = coherent-reindex n F coherent forget
    LayerLaws.zero-face (LawPair.current next-coherent) s y c p = strict-trans
      (Fillers.Boundary.assembled-filler-face E n
        (bar-faces n F (forget s) c)
        (Compatibility.Compatibility.bar-compatible C D E n F coherent (forget s) c)
        (filler s (y , c)) p low)
      (strict-sym (top-reindex n F forget s y (face n p c)))
    LayerLaws.one-face-law (LawPair.current next-coherent) s y c p = strict-trans
      (Fillers.Boundary.assembled-filler-face E n
        (bar-faces n F (forget s) c)
        (Compatibility.Compatibility.bar-compatible C D E n F coherent (forget s) c)
        (filler s (y , c)) p high)
      (strict-sym (one-reindex n F forget s p c))

  -- This is a typed cone schedule, not an asserted presentation theorem.
  -- It can store only actual inner stages and their specified fillers.
  -- For bar-schedule below all fields are constructed from C and D.
  record Schedule (Previous : Type ℓ) : Type (ℓ-suc ℓ) where
    coinductive
    field
      Cells : Type ℓ
      dimension : Cells → ℕ
      target : Cells → Obj
      boundary : Previous → (c : Cells) → CS.Shell (dimension c) (Value (target c))

    Next : Type ℓ
    Next = Σ[ previous ∈ Previous ] ((c : Cells) → CF.Filler (dimension c) (boundary previous c))

    field
      tail : Schedule Next

  bar-schedule : (n : Dim) (Previous : Type ℓ)
    (F : Families n Previous) → Coherent n F → Schedule Previous
  Schedule.Cells (bar-schedule n Previous F coherent) = Step.Cells n Previous F coherent
  Schedule.dimension (bar-schedule n Previous F coherent) = Step.dimension n Previous F coherent
  Schedule.target (bar-schedule n Previous F coherent) = Step.target n Previous F coherent
  Schedule.boundary (bar-schedule n Previous F coherent) = Step.boundary-data n Previous F coherent
  Schedule.tail (bar-schedule n Previous F coherent) = bar-schedule (osuc n)
    (Step.Next n Previous F coherent)
    (Step.next-families n Previous F coherent)
    (Step.next-coherent n Previous F coherent)

  Vertices : Type ℓ
  Vertices = (y : Obj) → Value y

  initial-families : Families ozero Vertices
  initial-families s y c = s y

  initial-coherent : Coherent ozero initial-families
  initial-coherent = star

  schedule : Schedule Vertices
  schedule = bar-schedule ozero Vertices initial-families initial-coherent

  State : Type (ℓ-suc ℓ)
  State = Σ[ P ∈ Type ℓ ] Schedule P

  advance : State → State
  advance (P , S) = Schedule.Next S , Schedule.tail S

  state : ℕ → State
  state zero = Vertices , schedule
  state (suc n) = advance (state n)

  PartialCone : ℕ → Type ℓ
  PartialCone n = state n .fst

  stage-schedule : (n : ℕ) → Schedule (PartialCone n)
  stage-schedule n = state n .snd

  drop : (n : ℕ) → PartialCone (suc n) → PartialCone n
  drop n = fst

  stage-is-typed-attachment : (n : ℕ)
    → PartialCone (suc n) ≡ Attachments.Attachment.Next (PartialCone n)
      (Schedule.Cells (stage-schedule n)) (Schedule.dimension (stage-schedule n))
      (λ c → Value (Schedule.target (stage-schedule n) c)) (Schedule.boundary (stage-schedule n))
  stage-is-typed-attachment n = refl

  module Tower = Towers.InverseTower PartialCone drop
  open Tower using (projection; projection-square; restrict; assemble; universal;
    assemble-projection; assemble-square; precompose-cone; universal-natural) public

  Limit : Type ℓ
  Limit = Tower.Limit

  Cone : {ℓt : Level} → Type ℓt → Type (ℓ-max ℓ ℓt)
  Cone = Tower.Cone

  vertex : (y : Obj) → Limit → Value y
  vertex y z = projection zero z y

  canonical-cone : Cone Limit
  canonical-cone = restrict (idfun Limit)

  module Candidate {ℓl : Level} (L : Type ℓl) (cone : Cone L)
      (universal-at-L : isEquiv (precompose-cone {S = L} cone))
      (universal-at-limit : isEquiv (precompose-cone {S = Limit} cone)) where
    forward : L → Limit
    forward = assemble cone

    on-maps : {ℓs : Level} (S : Type ℓs)
      → isEquiv (precompose-cone {S = S} cone) → (S → L) ≃ (S → Limit)
    on-maps S p = (precompose-cone cone , p) ∙ₑ invEquiv (universal S)

    inverse : Limit → L
    inverse = invEq (on-maps Limit universal-at-limit) (idfun Limit)

    right-inverse : (z : Limit) → forward (inverse z) ≡ z
    right-inverse = funExt⁻ (secEq (on-maps Limit universal-at-limit) (idfun Limit))

    left-inverse : (x : L) → inverse (forward x) ≡ x
    left-inverse = funExt⁻ (invEq (congEquiv (on-maps L universal-at-L))
      (funExt λ x → right-inverse (forward x)))

    equivalent : L ≃ Limit
    equivalent = isoToEquiv (iso forward inverse right-inverse left-inverse)

  module Microlinear {ℓi ℓw : Level} {Tests : Type ℓi}
      (test : Tests → Micro.TestSquare ℓw)
      (vertices : (y : Obj) → Micro.Theory.Microlinear test (Value y)) where
    module M = Micro.Theory test
    module Closure = ML.Limits test

    partial-cones-microlinear : (n : ℕ) → M.Microlinear (PartialCone n)
    partial-cones-microlinear zero = M.microlinear-Π vertices
    partial-cones-microlinear (suc n) =
      Attachments.Attachment.Microlinear.next-microlinear (PartialCone n)
        (Schedule.Cells (stage-schedule n)) (Schedule.dimension (stage-schedule n))
        (λ c → Value (Schedule.target (stage-schedule n) c))
        (Schedule.boundary (stage-schedule n)) test
        (partial-cones-microlinear n)
        (λ c → vertices (Schedule.target (stage-schedule n) c))

    limit-microlinear : M.Microlinear Limit
    limit-microlinear = Tower.Microlinear.limit-microlinear test partial-cones-microlinear

    any-limit-microlinear : {ℓl : Level} (L : Type ℓl) (cone : Cone L)
      (universal-at-L : isEquiv (precompose-cone {S = L} cone))
      (universal-at-limit : isEquiv (precompose-cone {S = Limit} cone))
      → M.Microlinear L
    any-limit-microlinear L cone at-L at-limit = Closure.microlinear-equiv
      (invEquiv (Candidate.equivalent L cone at-L at-limit)) limit-microlinear
