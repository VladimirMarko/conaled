{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Theorem 5.4.8 as the actual 𝔇-nullification instance of A.0.9.
-- Its remaining hypotheses are precisely the appropriate canonical
-- exponentiation comparisons from A.0.5, not Im-preservation itself.
module Orbifolds.CrystallineColimits where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sequence using (Sequence)
open import Cubical.Data.Nat using (ℕ; suc)
open import Cubical.Functions.Surjection
open import Cubical.Algebra.CommRing.Base
import Orbifolds.Crystalline as CR
import Orbifolds.ExponentiationColimits as EX
import Orbifolds.NullificationColimits as NC
import Orbifolds.ModalEtaleDescent as ED

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R public
  module Nullification = NC.Nullification CrystallineGenerator
  module DescentTheory = ED.Theory CrystallineModality

  module Pushout {A B C : Type ℓ} (f : A → B) (g : A → C) where
    module NullDiagram = Nullification.Pushout f g

    ExponentiationPreserved : Type ℓ
    ExponentiationPreserved = EX.Pushout.Preserved 𝔇 (Crystal.◯-map f) (Crystal.◯-map g)

    preservation : ExponentiationPreserved → NullDiagram.Diagram.Preserved
    preservation exp-preserves = NullDiagram.preservation (λ _ → exp-preserves)

  module SequenceColimit (X : Sequence ℓ) where
    module NullDiagram = Nullification.SequenceColimit X

    ExponentiationPreserved : Type ℓ
    ExponentiationPreserved = EX.SequenceColimit.Preserved {ℓ = ℓ} 𝔇
      NullDiagram.Diagram.ReflectedSequence

    preservation : ExponentiationPreserved → NullDiagram.Diagram.Preserved
    preservation exp-preserves = NullDiagram.preservation (λ _ → exp-preserves)

  module SelfPullback {A B : Type ℓ} (f : A → B) where
    module D = DescentTheory.Map f
    module Join = D.Join
    module Stage (n : ℕ) = Pushout
      (Join.Successor.left (suc n)) (Join.Successor.right (suc n))
    module Telescope = SequenceColimit D.PositiveStages

    record ExponentiationForJoinDiagrams : Type ℓ where
      field
        join-pushouts : (n : ℕ) → Stage.ExponentiationPreserved n
        positive-colimit : Telescope.ExponentiationPreserved
    open ExponentiationForJoinDiagrams public

    preservation : ExponentiationForJoinDiagrams → D.PreservesJoinDiagrams
    preservation exponentials .D.join-pushouts n = Stage.preservation n
      (join-pushouts exponentials n)
    preservation exponentials .D.positive-colimit = Telescope.preservation
      (positive-colimit exponentials)

    -- The source of units' surjectivity is the pointed 𝔇-nullification
    -- construction in Crystalline; it is not an extra descent axiom.
    self-pullback-descent : ExponentiationForJoinDiagrams
      → Crystal.Etale D.Kernel.left → isSurjection f → Crystal.Etale f
    self-pullback-descent exponentials kernel-etale = D.Descent.self-pullback-descent
      (λ X → crystalline-unit-surjective {X}) (preservation exponentials) kernel-etale
