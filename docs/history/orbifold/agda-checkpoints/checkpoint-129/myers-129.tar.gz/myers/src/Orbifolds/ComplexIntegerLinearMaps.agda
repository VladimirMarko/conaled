{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexIntegerLinearMaps where

-- Actual additive maps Z² -> C preserve integer linear combinations.
-- This is derived from the canonical integer homomorphism and the
-- group integer-action theorem, not assumed as additional linearity.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.AbGroup.Base using (AbGroup→Group)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
open import Cubical.Algebra.Group.ZAction using (_ℤ[_]·_; homPresℤ·)
open import Cubical.Tactics.CommRingSolver
import Orbifolds.ComplexPairs as CP
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.IntegerPairMatrices as IP
import Orbifolds.SpecialLinearTwo as SL

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  module C = CP.Ring R
  module I = IC.Ring R
  open C using (Complex; real; _+c_; _*c_)

  Additive : Group ℓ
  Additive = AbGroup→Group (CommRing→AbGroup C.ComplexRing)

  scalar-homomorphism : (z : Complex) → GroupHom I.additive-group Additive
  scalar-homomorphism z = (λ r → real r *c z) , makeIsGroupHom
    (λ r s → cong₂ _,_ (solve! R) (solve! R))

  abstract
    integer-scaling : (n : ℤ) (z : Complex)
      → n ℤ[ Additive ]· z ≡ real (I.integer n) *c z
    integer-scaling n z = sym (homPresℤ· (scalar-homomorphism z) 1r n
      ∙ cong (n ℤ[ Additive ]·_) (C.multiply-commutative C.one z ∙ C.multiply-right-unit z))

    scalar-coordinates : (r : R .fst) (z : Complex)
      → real r *c z ≡ ((r · z .fst) , (r · z .snd))
    scalar-coordinates r z = cong₂ _,_ (solve! R) (solve! R)

    homomorphism-linear : (f : GroupHom IP.Pairs Additive) (v : ℤ × ℤ)
      → f .fst v ≡ (real (I.integer (v .fst)) *c f .fst SL.Integers.basis₁)
        +c (real (I.integer (v .snd)) *c f .fst SL.Integers.basis₂)
    homomorphism-linear f (m , n) = cong (f .fst) (IP.pair-decomposition (m , n))
      ∙ IsGroupHom.pres· (f .snd) (m ℤ[ IP.Pairs ]· SL.Integers.basis₁)
          (n ℤ[ IP.Pairs ]· SL.Integers.basis₂)
      ∙ cong₂ _+c_ (homPresℤ· f SL.Integers.basis₁ m) (homPresℤ· f SL.Integers.basis₂ n)
      ∙ cong₂ _+c_ (integer-scaling m (f .fst SL.Integers.basis₁))
          (integer-scaling n (f .fst SL.Integers.basis₂))

    homomorphism-coordinate-linear : (f : GroupHom IP.Pairs Additive) (v : ℤ × ℤ)
      → f .fst v ≡
        ((I.integer (v .fst) · f .fst SL.Integers.basis₁ .fst) ,
         (I.integer (v .fst) · f .fst SL.Integers.basis₁ .snd))
        +c
        ((I.integer (v .snd) · f .fst SL.Integers.basis₂ .fst) ,
         (I.integer (v .snd) · f .fst SL.Integers.basis₂ .snd))
    homomorphism-coordinate-linear f v = homomorphism-linear f v
      ∙ cong₂ _+c_ (scalar-coordinates (I.integer (v .fst)) (f .fst SL.Integers.basis₁))
          (scalar-coordinates (I.integer (v .snd)) (f .fst SL.Integers.basis₂))
