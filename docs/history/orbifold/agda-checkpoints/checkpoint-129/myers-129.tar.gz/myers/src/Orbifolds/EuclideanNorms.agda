{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.EuclideanNorms where

-- Finite-dimensional squared norms used in the Euclidean case of 6.2.21.
-- Finite K extracts merely a nonzero coordinate from an unequal vector.
-- Every squared-norm ball contains an explicit positive coordinate box.
-- No square-root operation or equivalence of topologies is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.SyntheticSeparated using (module Separation)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.CompactRealSubspaces using (module RealSubspaces)

module Norms {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order
  open Compatible compatibility
  open Field kock
  open OrderedRingCompatibility compatibility
  open RealProbe R kock order compatibility using (PositiveRadius)
  open RealSubspaces R kock order compatibility using (nonzeroSquarePositive)

  Vector : ℕ → Type ℓ
  Vector n = Fin n → Carrier

  vectorIsSet : (n : ℕ) → isSet (Vector n)
  vectorIsSet n = isSetΠ (λ _ → is-set)

  tail : {n : ℕ} → Vector (suc n) → Vector n
  tail v i = v (fsuc i)

  squaredNorm : (n : ℕ) → Vector n → Carrier
  squaredNorm zero v = 0r
  squaredNorm (suc n) v = (v fzero · v fzero) + squaredNorm n (tail v)

  Nonnegative : Carrier → Type ℓ
  Nonnegative a = ¬ (a < 0r)

  sumCancel : (a b : Carrier) → (a + b) - a ≡ b
  sumCancel a b = solve! R

  nonnegativeAdd : {a b : Carrier} → Nonnegative a → Nonnegative b → Nonnegative (a + b)
  nonnegativeAdd {a} {b} nonnegativeA nonnegativeB negative = PT.rec Empty.isProp⊥
    (Sum.rec
      (λ less → nonnegativeB
        (subst2 _<_ (sumCancel a b) (+InvR a) (translateLess less (- a))))
      nonnegativeA)
    (cotransitive negative a)

  nonnegativeAddPositive : {a b : Carrier} → Nonnegative a → 0r < b → 0r < (a + b)
  nonnegativeAddPositive {a} {b} nonnegativeA positiveB = PT.rec (less-isProp 0r (a + b))
    (Sum.rec
      (λ negativeA → Empty.rec (nonnegativeA (positiveDifference→less
        (subst (0r <_) (sym (+IdL (- a))) negativeA))))
      (λ less → subst2 _<_ (+InvL a) (+Comm b a) (translateLess less a)))
    (cotransitive positiveB (- a))

  positiveAddNonnegative : {a b : Carrier} → 0r < a → Nonnegative b → 0r < (a + b)
  positiveAddNonnegative {a} {b} positiveA nonnegativeB =
    subst (0r <_) (+Comm b a) (nonnegativeAddPositive nonnegativeB positiveA)

  squareNonnegative : (d : Carrier) → Nonnegative (d · d)
  squareNonnegative d negative = lessAsym (nonzeroSquarePositive d nonzero) negative
    where
    nonzero : ¬ (d ≡ 0r)
    nonzero vanishes = irreflexive 0r
      (subst (_< 0r) (cong (λ t → t · t) vanishes ∙ 0LeftAnnihilates 0r) negative)

  normNonnegative : (n : ℕ) (v : Vector n) → Nonnegative (squaredNorm n v)
  normNonnegative zero v = irreflexive 0r
  normNonnegative (suc n) v = nonnegativeAdd (squareNonnegative (v fzero)) (normNonnegative n (tail v))

  normPositiveAt : (n : ℕ) (v : Vector n) (i : Fin n) →
    0r < (v i · v i) → 0r < squaredNorm n v
  normPositiveAt zero v ()
  normPositiveAt (suc n) v fzero positive =
    positiveAddNonnegative positive (normNonnegative n (tail v))
  normPositiveAt (suc n) v (fsuc i) positive =
    nonnegativeAddPositive (squareNonnegative (v fzero)) (normPositiveAt n (tail v) i positive)

  normPositive : (n : ℕ) (v : Vector n) →
    ¬ ((i : Fin n) → v i ≡ 0r) → 0r < squaredNorm n v
  normPositive n v nonzero = PT.rec (less-isProp 0r (squaredNorm n v))
    (λ { (i , invertible) → normPositiveAt n v i
      (nonzeroSquarePositive (v i) (Separation.invertibleNonzero R kock (v i) invertible)) })
    (finite-K kock n v nonzero)

  zeroNorm : (n : ℕ) → squaredNorm n (λ _ → 0r) ≡ 0r
  zeroNorm zero = refl
  zeroNorm (suc n) = cong₂ _+_ (0LeftAnnihilates 0r) (zeroNorm n) ∙ +IdL 0r

  normOfZeros : (n : ℕ) (v : Vector n) → ((i : Fin n) → v i ≡ 0r) → squaredNorm n v ≡ 0r
  normOfZeros n v vanishes = cong (squaredNorm n) (funExt vanishes) ∙ zeroNorm n

  squaredDistance : (n : ℕ) → Vector n → Vector n → Carrier
  squaredDistance n x y = squaredNorm n (λ i → x i - y i)

  distanceSelfZero : (n : ℕ) (x : Vector n) → squaredDistance n x x ≡ 0r
  distanceSelfZero n x = normOfZeros n (λ i → x i - x i) (λ i → +InvR (x i))

  distancePositive : (n : ℕ) {x y : Vector n} → ¬ (x ≡ y) → 0r < squaredDistance n x y
  distancePositive n {x} {y} distinct = normPositive n (λ i → x i - y i)
    (λ vanishes → distinct (funExt (λ i → equalByDifference (x i) (y i) (vanishes i))))

  addLess : {a b c d : Carrier} → a < b → c < d → (a + c) < (b + d)
  addLess {b = b} {c} {d} ab cd = lessTrans (translateLess ab c)
    (subst2 _<_ (+Comm c b) (+Comm d b) (translateLess cd b))

  squareIntervalBound : (δ d : Carrier) → (- δ) < d → d < δ → (d · d) < (δ · δ)
  squareIntervalBound δ d lower upper = positiveDifference→less
    (subst (0r <_) factorization
      (positive-multiply (less→positiveDifference upper) (less→positiveDifference lower)))
    where
    factorization : (δ - d) · (d - (- δ)) ≡ (δ · δ) - (d · d)
    factorization = solve! R

  normIntervalBound : (n : ℕ) (v : Vector n) (δ : Carrier) → 0r < δ →
    ((i : Fin n) → ((- δ) < v i) × (v i < δ)) →
    squaredNorm n v < (nat (suc n) · (δ · δ))
  normIntervalBound zero v δ positive bounds =
    subst (0r <_) (sym (cong (_· (δ · δ)) (+IdL 1r) ∙ ·IdL (δ · δ)))
      (positive-multiply positive positive)
  normIntervalBound (suc n) v δ positive bounds = subst (squaredNorm (suc n) v <_) sumIdentity
    (addLess (squareIntervalBound δ (v fzero) (bounds fzero .fst) (bounds fzero .snd))
      (normIntervalBound n (tail v) δ positive (λ i → bounds (fsuc i))))
    where
    sumPolynomial : (a d : Carrier) → (d · d) + (a · (d · d)) ≡ (a + 1r) · (d · d)
    sumPolynomial a d = solve! R
    sumIdentity : (δ · δ) + (nat (suc n) · (δ · δ)) ≡ nat (suc (suc n)) · (δ · δ)
    sumIdentity = sumPolynomial (nat (suc n)) δ

  coordinateDifferenceBounds : (x y δ : Carrier) →
    ((x - δ) < y) × (y < (x + δ)) → ((- δ) < (x - y)) × ((x - y) < δ)
  coordinateDifferenceBounds x y δ (lower , upper) =
    positiveDifference→less (subst (0r <_) (sym lowerIdentity) (less→positiveDifference upper)) ,
    positiveDifference→less (subst (0r <_) (sym upperIdentity) (less→positiveDifference lower))
    where
    lowerIdentity : (x - y) - (- δ) ≡ (x + δ) - y
    lowerIdentity = solve! R
    upperIdentity : δ - (x - y) ≡ y - (x - δ)
    upperIdentity = solve! R

  distanceBoxBound : (n : ℕ) (x y : Vector n) (δ : PositiveRadius) →
    ((i : Fin n) → ((x i - δ .fst) < y i) × (y i < (x i + δ .fst))) →
    squaredDistance n x y < (nat (suc n) · (δ .fst · δ .fst))
  distanceBoxBound n x y δ bounds = normIntervalBound n (λ i → x i - y i)
    (δ .fst) (δ .snd) (λ i → coordinateDifferenceBounds (x i) (y i) (δ .fst) (bounds i))

  smallerPositive : (a b : PositiveRadius) →
    ∥ Σ[ δ ∈ PositiveRadius ] ((δ .fst < a .fst) × (δ .fst < b .fst)) ∥₁
  smallerPositive a b = PT.map
    (Sum.rec
      (λ belowB → (half · a .fst , halfScalePositive (a .snd)) , halfScaleLess (a .snd) , belowB)
      (λ bBelowA → (half · b .fst , halfScalePositive (b .snd)) ,
        lessTrans (halfScaleLess (b .snd)) bBelowA , halfScaleLess (b .snd)))
    (cotransitive (halfScaleLess (a .snd)) (b .fst))

  cancelScale : (x a u : Carrier) → a · u ≡ 1r → (x · a) · u ≡ x
  cancelScale x a u inverse = sym (·Assoc x a u) ∙ cong (x ·_) inverse ∙ ·IdR x

  normRadius : (n : ℕ) (ε : PositiveRadius) →
    ∥ Σ[ δ ∈ PositiveRadius ] (nat (suc n) · (δ .fst · δ .fst)) < ε .fst ∥₁
  normRadius n ε = PT.map finish
    (smallerPositive (1r , zero<one) (ε .fst · reciprocal .fst ,
      positive-multiply (ε .snd) (reciprocal .snd .fst)))
    where
    N : Carrier
    N = nat (suc n)
    reciprocal : Σ[ u ∈ Carrier ] ((0r < u) × (N · u ≡ 1r))
    reciprocal = positiveInverse N (natPositive n)

    finish : (Σ[ δ ∈ PositiveRadius ]
      ((δ .fst < 1r) × (δ .fst < (ε .fst · reciprocal .fst)))) →
      Σ[ δ ∈ PositiveRadius ] (N · (δ .fst · δ .fst)) < ε .fst
    finish (δ , belowOne , belowLimit) = δ , lessTrans firstBound secondBound
      where
      squareBelow : (δ .fst · δ .fst) < δ .fst
      squareBelow = subst ((δ .fst · δ .fst) <_) (·IdL (δ .fst))
        (multiplyLessRightPositive (δ .snd) belowOne)

      firstBound : (N · (δ .fst · δ .fst)) < (N · δ .fst)
      firstBound = subst2 _<_ (·Comm (δ .fst · δ .fst) N) (·Comm (δ .fst) N)
        (multiplyLessRightPositive (natPositive n) squareBelow)

      secondBound : (N · δ .fst) < ε .fst
      secondBound = subst2 _<_ (·Comm (δ .fst) N)
        (cancelScale (ε .fst) (reciprocal .fst) N
          (·Comm (reciprocal .fst) N ∙ reciprocal .snd .snd))
        (multiplyLessRightPositive (natPositive n) belowLimit)

  normBallContainsBox : (n : ℕ) (x : Vector n) (ε : PositiveRadius) →
    ∥ Σ[ δ ∈ PositiveRadius ] ((y : Vector n) →
      ((i : Fin n) → ((x i - δ .fst) < y i) × (y i < (x i + δ .fst))) →
      squaredDistance n x y < ε .fst) ∥₁
  normBallContainsBox n x ε = PT.map
    (λ { (δ , bound) → δ , (λ y box → lessTrans (distanceBoxBound n x y δ box) bound) })
    (normRadius n ε)

