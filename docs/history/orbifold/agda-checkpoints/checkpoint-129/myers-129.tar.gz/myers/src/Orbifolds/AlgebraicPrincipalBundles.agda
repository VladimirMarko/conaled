{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.AlgebraicPrincipalBundles where

-- Myers 3.3.2 with ordinary algebraic groups, actual algebraic torsor
-- structures on fibers, and the usual pointwise equivariance condition
-- for the map on the actual total space. The base need not be a set.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
import Orbifolds.Torsors as Torsors
import Orbifolds.EquivariantBundles as EB
import Orbifolds.TensorBundles as TB
import Orbifolds.StructuredBundles as SB

module Ordinary {ℓ : Level} (G : Group ℓ) where
  module T = Torsors.Theory G
  open GroupStr (G .snd)

  TorsorStr : Type ℓ → Type ℓ
  TorsorStr E = Σ[ α ∈ (G .fst → E → E) ]
    Σ[ laws ∈ T.IsAction (E , α) ] T.IsTorsor ((E , α) , laws)

  pack-torsor : (Σ[ E ∈ Type ℓ ] TorsorStr E) → T.Torsor
  pack-torsor (E , α , laws , tor) = ((E , α) , laws) , tor

  structured≃torsors : (Σ[ E ∈ Type ℓ ] TorsorStr E) ≃ T.Torsor
  structured≃torsors = isoToEquiv (iso pack-torsor
    (λ (((E , α) , laws) , tor) → E , α , laws , tor)
    (λ _ → refl) (λ _ → refl))

  module Action (X : T.Action) where
    module BundleFamily = EB.Theory.Action G X
    module Tensor = TB.Theory.Action G X
    CarrierX = T.Carrier X

    Associated : (Σ[ E ∈ Type ℓ ] TorsorStr E) → Type ℓ
    Associated t = BundleFamily.Bundle (pack-torsor t)

    associated-quotient≃quotient :
      (Σ (Σ[ E ∈ Type ℓ ] TorsorStr E) Associated)
      ≃ BundleFamily.Family.Quotient
    associated-quotient≃quotient = Σ-cong-equiv-fst structured≃torsors

    module Over (A : Type ℓ) where
      module C = SB.Classification A TorsorStr Associated

      Principal : Type (ℓ-suc ℓ)
      Principal = Σ[ P ∈ Type ℓ ] Σ[ π ∈ (P → A) ]
        ((a : A) → TorsorStr (fiber π a))

      module Bundle (bundle : Principal) where
        P = bundle .fst
        π = bundle .snd .fst
        structure = bundle .snd .snd

        fiber-torsor : A → T.Torsor
        fiber-torsor a = pack-torsor (fiber π a , structure a)

        fiber-action : (a : A) → G .fst → fiber π a → fiber π a
        fiber-action a = T.act (fiber-torsor a .fst)

        action-on-total : G .fst → P → P
        action-on-total g p = fiber-action (π p) g (p , refl) .fst

        action-preserves-base : (g : G .fst) (p : P)
          → π (action-on-total g p) ≡ π p
        action-preserves-base g p = fiber-action (π p) g (p , refl) .snd

        fiber-action-coordinate : (a : A) (g : G .fst) (z : fiber π a)
          → fiber-action a g z .fst ≡ action-on-total g (z .fst)
        fiber-action-coordinate a g (p , q) = J
          (λ a q → fiber-action a g (p , q) .fst ≡ action-on-total g p)
          refl q

        action-unit : (p : P) → action-on-total 1g p ≡ p
        action-unit p = cong fst
          (T.act-unit (fiber-torsor (π p) .fst) (p , refl))

        action-compose : (g h : G .fst) (p : P)
          → action-on-total (g · h) p
            ≡ action-on-total g (action-on-total h p)
        action-compose g h p = cong fst
          (T.act-compose (fiber-torsor (π p) .fst) g h (p , refl))
          ∙ fiber-action-coordinate (π p) g
            (fiber-action (π p) h (p , refl))

        Equivariant : (P → CarrierX) → Type ℓ
        Equivariant f = (g : G .fst) (p : P)
          → f (action-on-total g p) ≡ T.act X g (f p)

        isPropEquivariant : (f : P → CarrierX) → isProp (Equivariant f)
        isPropEquivariant f = isPropΠ2 λ g p → T.carrier-set X _ _

        EquivariantMap : Type ℓ
        EquivariantMap = Σ[ f ∈ (P → CarrierX) ] Equivariant f

        Sections : Type ℓ
        Sections = (a : A) → BundleFamily.Bundle (fiber-torsor a)

        fiberwise-naturality : (f : (a : A) → fiber π a → CarrierX)
          (a : A) (z : fiber π a)
          → f (π (z .fst)) (z .fst , refl) ≡ f a z
        fiberwise-naturality f a (p , q) = J
          (λ a q → f (π p) (p , refl) ≡ f a (p , q)) refl q

        section-to-map : Sections → EquivariantMap
        section-to-map f .fst p = f (π p) .fst (p , refl)
        section-to-map f .snd g p =
          fiberwise-naturality (λ a → f a .fst) (π p)
            (fiber-action (π p) g (p , refl))
          ∙ f (π p) .snd g (p , refl)

        map-to-section : EquivariantMap → Sections
        map-to-section f a .fst z = f .fst (z .fst)
        map-to-section f a .snd g z =
          cong (f .fst) (fiber-action-coordinate a g z)
          ∙ f .snd g (z .fst)

        map-retraction : (f : EquivariantMap)
          → section-to-map (map-to-section f) ≡ f
        map-retraction f = Σ≡Prop isPropEquivariant refl

        section-retraction : (f : Sections)
          → map-to-section (section-to-map f) ≡ f
        section-retraction f = funExt λ a →
          Σ≡Prop (T.isPropEquivariant (fiber-torsor a .fst) X)
            (funExt (fiberwise-naturality (λ a → f a .fst) a))

        sections≃equivariant-maps : Sections ≃ EquivariantMap
        sections≃equivariant-maps = isoToEquiv (iso
          section-to-map map-to-section map-retraction section-retraction)

      PrincipalWithEquivariantMap : Type (ℓ-suc ℓ)
      PrincipalWithEquivariantMap = Σ[ bundle ∈ Principal ]
        Bundle.EquivariantMap bundle

      bundled-sections≃equivariant-maps : C.Bundles ≃ PrincipalWithEquivariantMap
      bundled-sections≃equivariant-maps = compEquiv
        (isoToEquiv (iso
          (λ (P , π , s , x) → (P , π , s) , x)
          (λ ((P , π , s) , x) → P , π , s , x)
          (λ _ → refl) (λ _ → refl)))
        (Σ-cong-equiv-snd (λ bundle → Bundle.sections≃equivariant-maps bundle))

      maps-to-quotient≃principal-bundles :
        (A → BundleFamily.Family.Quotient) ≃ PrincipalWithEquivariantMap
      maps-to-quotient≃principal-bundles = compEquiv
        (equivΠCod (λ _ → invEquiv associated-quotient≃quotient))
        (compEquiv C.maps≃bundles bundled-sections≃equivariant-maps)

      -- The same theorem for the literal balanced tensor action of 2.2.6.
      maps-to-tensor-quotient≃principal-bundles :
        (A → Σ T.Torsor Tensor.Tensor) ≃ PrincipalWithEquivariantMap
      maps-to-tensor-quotient≃principal-bundles = compEquiv
        (equivΠCod (λ _ → Σ-cong-equiv-snd Tensor.tensor≃bundle))
        maps-to-quotient≃principal-bundles
