{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComposedInverseCoordinates where

-- The inverse of a composite, expressed through specified inverse
-- coordinate maps whose comparisons with the actual inverses are
-- already proved. The full path calculation takes place at arbitrary
-- types, before substituting structured path spaces.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
import Orbifolds.InverseEquivalenceComputations as IEC

abstract
  composed-inverse-coordinate : ∀ {ℓa ℓb ℓc ℓd}
    {A : Type ℓa} {B : Type ℓb} {C : Type ℓc} {D : Type ℓd}
    (first : A ≃ B) (middle : B ≃ C) (last : C ≃ D)
    (first-coordinate : B → A)
    (first-inverse : (b : B) → invEq first b ≡ first-coordinate b)
    (last-coordinate : D → C)
    (last-inverse : (d : D) → invEq last d ≡ last-coordinate d)
    (d : D)
    → invEq (compEquiv first (compEquiv middle last)) d
      ≡ first-coordinate (invEq middle (last-coordinate d))
  composed-inverse-coordinate first middle last first-coordinate first-inverse
      last-coordinate last-inverse d =
    IEC.inverse-compose first (compEquiv middle last) d
    ∙ cong (invEq first) (IEC.inverse-compose middle last d)
    ∙ cong (λ c → invEq first (invEq middle c)) (last-inverse d)
    ∙ first-inverse (invEq middle (last-coordinate d))
