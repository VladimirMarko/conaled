{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentConeMapLaws where

-- Identity and composition of the actual unbounded cone maps.  Finite
-- strict function laws are converted to complete inner squares before
-- ordinary-natural iteration; no infinite strict extensionality is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Foundations.GroupoidLaws using (lUnit)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictHomotopySquares
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentFiniteMapLaws as FiniteLaws
import Orbifolds.Coherent.HomotopyCoherentConeMaps as ConeMaps
import Orbifolds.CoinductiveTowerSquares as Generic

module Composition {ℓ : Level} (C : Category ℓ ℓ)
    (D G H : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (β : Transformations.ForCategory.Transformation C G H)
    (γ : Transformations.ForCategory.Transformation C D H)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component β x
          ∘ Transformations.ForCategory.Transformation.component α x)
        ≡ˢ outer (Transformations.ForCategory.Transformation.component γ x)) where
  module A = ConeMaps.Action C D G α E
  module B = ConeMaps.Action C G H β E
  module K = ConeMaps.Action C D H γ E
  module Finite = FiniteLaws.Composition C D G H α β γ E F components

  record State : Type (ℓ-suc ℓ) where
    field
      A₀ A₁ A₂ : Type ℓ
      S₀ : A.Source.Schedule A₀
      S₁ : A.Target.Schedule A₁
      S₂ : B.Target.Schedule A₂
      f : A₀ → A₁
      g : A₁ → A₂
      k : A₀ → A₂
      mf : A.Morphism S₀ S₁ f
      mg : B.Morphism S₁ S₂ g
      mk : K.Morphism S₀ S₂ k

  advance : State → State
  State.A₀ (advance s) = A.Source.Schedule.Next (State.S₀ s)
  State.A₁ (advance s) = A.Target.Schedule.Next (State.S₁ s)
  State.A₂ (advance s) = B.Target.Schedule.Next (State.S₂ s)
  State.S₀ (advance s) = A.Source.Schedule.tail (State.S₀ s)
  State.S₁ (advance s) = A.Target.Schedule.tail (State.S₁ s)
  State.S₂ (advance s) = B.Target.Schedule.tail (State.S₂ s)
  State.f (advance s) x = State.f s (x .fst) , A.Morphism.fiber-map (State.mf s) (x .fst) (x .snd)
  State.g (advance s) x = State.g s (x .fst) , B.Morphism.fiber-map (State.mg s) (x .fst) (x .snd)
  State.k (advance s) x = State.k s (x .fst) , K.Morphism.fiber-map (State.mk s) (x .fst) (x .snd)
  State.mf (advance s) = A.Morphism.tail (State.mf s)
  State.mg (advance s) = B.Morphism.tail (State.mg s)
  State.mk (advance s) = K.Morphism.tail (State.mk s)

  module Squares = Generic.Squares State State.A₀ State.A₂ advance
    (λ s → fst) (λ s → fst) (λ s → State.g s ∘ State.f s) State.k
    (λ s → refl) (λ s → refl)
  open Squares using (Witness)

  finite-state : Dim → State
  State.A₀ (finite-state n) = A.SourceFinite.Carrier n
  State.A₁ (finite-state n) = A.TargetFinite.Carrier n
  State.A₂ (finite-state n) = B.TargetFinite.Carrier n
  State.S₀ (finite-state n) = A.SourceFinite.finite-state n .snd
  State.S₁ (finite-state n) = A.TargetFinite.finite-state n .snd
  State.S₂ (finite-state n) = B.TargetFinite.finite-state n .snd
  State.f (finite-state n) = A.FiniteAction.stage-map n
  State.g (finite-state n) = B.FiniteAction.stage-map n
  State.k (finite-state n) = K.FiniteAction.stage-map n
  State.mf (finite-state n) = A.finite-morphism n
  State.mg (finite-state n) = B.finite-morphism n
  State.mk (finite-state n) = K.finite-morphism n

  actual-state : ℕ → State
  State.A₀ (actual-state n) = A.Source.PartialCone n
  State.A₁ (actual-state n) = A.Target.PartialCone n
  State.A₂ (actual-state n) = B.Target.PartialCone n
  State.S₀ (actual-state n) = A.Source.stage-schedule n
  State.S₁ (actual-state n) = A.Target.stage-schedule n
  State.S₂ (actual-state n) = B.Target.stage-schedule n
  State.f (actual-state n) = A.partial-map n
  State.g (actual-state n) = B.partial-map n
  State.k (actual-state n) = K.partial-map n
  State.mf (actual-state n) = A.morphism-at n
  State.mg (actual-state n) = B.morphism-at n
  State.mk (actual-state n) = K.morphism-at n

  abstract
    finite-witness : (n : Dim) → Witness (finite-state n)
      (strict-to-path (Finite.function-composition n))
    Witness.next (finite-witness n) = strict-to-path (Finite.function-composition (osuc n))
    Witness.square (finite-witness n) = strict-square fst fst
      (Finite.function-composition n) (Finite.function-composition (osuc n)) reflˢ reflˢ
    Witness.tail (finite-witness n) = finite-witness (osuc n)

  mutual
    partial-composition : (n : ℕ) → B.partial-map n ∘ A.partial-map n ≡ K.partial-map n
    partial-composition zero = strict-to-path (Finite.function-composition ozero)
    partial-composition (suc n) = Witness.next (witness-at n)

    witness-at : (n : ℕ) → Witness (actual-state n) (partial-composition n)
    witness-at zero = finite-witness ozero
    witness-at (suc n) = Witness.tail (witness-at n)

  coherence : (s : A.Source.Limit) (n : ℕ)
    → PathP (λ i → B.Target.drop n (partial-composition (suc n) i (s .fst (suc n)))
        ≡ partial-composition n i (s .fst n))
      (cong (B.partial-map n ∘ A.partial-map n) (s .snd n))
      (cong (K.partial-map n) (s .snd n))
  coherence s n = adjust-path
    (lUnit (cong (B.partial-map n ∘ A.partial-map n) (s .snd n)))
    (λ i → (λ j → Witness.square (witness-at n) i j (s .fst (suc n)))
      ∙ cong (partial-composition n i) (s .snd n))
    (sym (lUnit (cong (K.partial-map n) (s .snd n))))

  cone-composition : (s : A.Source.Limit)
    → B.cone-map (A.cone-map s) ≡ K.cone-map s
  cone-composition s i .fst n = partial-composition n i (s .fst n)
  cone-composition s i .snd n = coherence s n i

module Identity {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D D)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component α x) ≡ˢ outer (idfun _)) where
  module A = ConeMaps.Action C D D α E
  module Finite = FiniteLaws.Identity C D α E F components

  record State : Type (ℓ-suc ℓ) where
    field
      Carrier : Type ℓ
      schedule : A.Source.Schedule Carrier
      map : Carrier → Carrier
      morphism : A.Morphism schedule schedule map

  advance : State → State
  State.Carrier (advance s) = A.Source.Schedule.Next (State.schedule s)
  State.schedule (advance s) = A.Source.Schedule.tail (State.schedule s)
  State.map (advance s) x = State.map s (x .fst) ,
    A.Morphism.fiber-map (State.morphism s) (x .fst) (x .snd)
  State.morphism (advance s) = A.Morphism.tail (State.morphism s)

  module Squares = Generic.Squares State State.Carrier State.Carrier advance
    (λ s → fst) (λ s → fst) State.map (λ s → idfun (State.Carrier s))
    (λ s → refl) (λ s → refl)
  open Squares using (Witness)

  finite-state : Dim → State
  State.Carrier (finite-state n) = A.SourceFinite.Carrier n
  State.schedule (finite-state n) = A.SourceFinite.finite-state n .snd
  State.map (finite-state n) = A.FiniteAction.stage-map n
  State.morphism (finite-state n) = A.finite-morphism n

  actual-state : ℕ → State
  State.Carrier (actual-state n) = A.Source.PartialCone n
  State.schedule (actual-state n) = A.Source.stage-schedule n
  State.map (actual-state n) = A.partial-map n
  State.morphism (actual-state n) = A.morphism-at n

  abstract
    finite-witness : (n : Dim) → Witness (finite-state n)
      (strict-to-path (Finite.function-identity n))
    Witness.next (finite-witness n) = strict-to-path (Finite.function-identity (osuc n))
    Witness.square (finite-witness n) = strict-square fst fst
      (Finite.function-identity n) (Finite.function-identity (osuc n)) reflˢ reflˢ
    Witness.tail (finite-witness n) = finite-witness (osuc n)

  mutual
    partial-identity : (n : ℕ) → A.partial-map n ≡ idfun (A.Source.PartialCone n)
    partial-identity zero = strict-to-path (Finite.function-identity ozero)
    partial-identity (suc n) = Witness.next (witness-at n)

    witness-at : (n : ℕ) → Witness (actual-state n) (partial-identity n)
    witness-at zero = finite-witness ozero
    witness-at (suc n) = Witness.tail (witness-at n)

  coherence : (s : A.Source.Limit) (n : ℕ)
    → PathP (λ i → A.Target.drop n (partial-identity (suc n) i (s .fst (suc n)))
        ≡ partial-identity n i (s .fst n))
      (cong (A.partial-map n) (s .snd n)) (s .snd n)
  coherence s n = adjust-path
    (lUnit (cong (A.partial-map n) (s .snd n)))
    (λ i → (λ j → Witness.square (witness-at n) i j (s .fst (suc n)))
      ∙ cong (partial-identity n i) (s .snd n))
    (sym (lUnit (s .snd n)))

  cone-identity : (s : A.Source.Limit) → A.cone-map s ≡ s
  cone-identity s i .fst n = partial-identity n i (s .fst n)
  cone-identity s i .snd n = coherence s n i
