{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCanonicalComparisons where

-- The actual evaluation and native-unit colimit maps. Equivalence is
-- deliberately a separate theorem: these definitions fix which maps
-- the tiny and nullification preservation proofs must identify.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (zero)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram; Power)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentPowers as Powers
import Orbifolds.Coherent.HomotopyCoherentNullification as Null
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as Maps
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Colimits
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.SequentialColimit as SC

module Power {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module P = Powers.Construction C E F T using (Power; evaluation)
  module At (t : T) = Maps.Map C (P.Power D) D (P.evaluation D t) E F
    using (induced; generator-computation)
  module Source = Colimits.Construction C (P.Power D) E F using (Colimit)
  module Target = Colimits.Construction C D E F using (Colimit)

  comparison : Source.Colimit → (T → Target.Colimit)
  comparison z t = At.induced t z

  source-generator : (x : Category.Obj C) → (T → HC.ForCategory.Diagram.Value D x) → Source.Colimit
  source-generator x a = SC.incl {n = zero} (x , a)

  target-generator : (x : Category.Obj C) → HC.ForCategory.Diagram.Value D x → Target.Colimit
  target-generator x a = SC.incl {n = zero} (x , a)

  generator-computation : (x : Category.Obj C) (a : T → HC.ForCategory.Diagram.Value D x) (t : T)
    → comparison (source-generator x a) t ≡ target-generator x (a t)
  generator-computation x a t = At.generator-computation t x a

module Nullification {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    {Ix : Type₀} (S : Ix → Type ℓ) (E : StrictCubicalExtensionality ℓ)
    (F : StrictFunctionExtensionality ℓ) where
  reflected : HC.ForCategory.Diagram C
  reflected = Null.Reflection.reflected C D S E

  unit-transformation : Transformations.ForCategory.Transformation C D reflected
  unit-transformation = Null.Reflection.unit-transformation C D S E

  module Unit = Maps.Map C D reflected unit-transformation E F
    using (induced; source-generator; target-generator; generator-computation; module Source; module Target)

  comparison : Unit.Source.Colimit → Unit.Target.Colimit
  comparison = Unit.induced

  generator-computation : (x : Category.Obj C) (a : HC.ForCategory.Diagram.Value D x)
    → comparison (Unit.source-generator x a) ≡ Unit.target-generator x NB.∣ a ∣
  generator-computation = Unit.generator-computation
