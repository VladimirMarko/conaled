{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrystallinePenonEtale where

-- Theorem 5.2.10 for actual Penon manifolds. The maps on neighborhoods
-- and unit fibers are the canonical ones. The proof preserves their
-- commuting paths and uses the actual crystalline unit's surjectivity.
-- No sharp modality, crispness restriction, or additional axiom occurs.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base using (CommRing)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Penon
open import Orbifolds.StableNeighborhoods using (center)
import Orbifolds.PenonManifolds as PM
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallinePenonDisks as PD
import Orbifolds.PullbackCancellation as PC

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R
  open PM.Geometry R using (PenonManifold)

  module Map {X Y : Type ℓ} {n m : ℕ}
      (source-manifold : PenonManifold X n)
      (target-manifold : PenonManifold Y m) (f : X → Y) where
    module Source = PD.Ring.Manifold R source-manifold
    module Target = PD.Ring.Manifold R target-manifold
    module Square = PC.Cartesian crystalline-unit crystalline-unit f
      (Crystal.◯-map f) (Crystal.◯-map-β f)

    PenonEtale : Type ℓ
    PenonEtale = (x : X) → isEquiv (neighborhoodMap f x)

    isPropPenonEtale : isProp PenonEtale
    isPropPenonEtale = isPropΠ λ x → isPropIsEquiv (neighborhoodMap f x)

    -- The two maps retain the same point of Y. Their second coordinates
    -- agree because reflection of a Penon manifold is a set, a derived
    -- fact in CrystallinePenonDisks rather than a preservation axiom.
    neighborhood-square : (x : X) (d : InfinitesimalNeighborhood x)
      → Square.fibre-map (crystalline-unit x)
          (equivFun (Source.At.neighborhood≃unit-fiber x) d)
        ≡ equivFun (Target.At.neighborhood≃unit-fiber (f x))
          (neighborhoodMap f x d)
    neighborhood-square x d = Σ≡Prop
      (λ y → Target.reflection-isSet (crystalline-unit y) (crystalline-unit (f x))) refl

    neighborhood-equivalence→fiber-equivalence : PenonEtale
      → (x : X) → isEquiv (Square.fibre-map (crystalline-unit x))
    neighborhood-equivalence→fiber-equivalence penon x =
      isEquiv[f∘equivFunA≃B]→isEquiv[f]
        (Square.fibre-map (crystalline-unit x))
        (Source.At.neighborhood≃unit-fiber x)
        (subst isEquiv (sym (funExt (neighborhood-square x)))
          (snd (compEquiv (neighborhoodMap f x , penon x)
            (Target.At.neighborhood≃unit-fiber (f x)))))

    fiber-equivalence→neighborhood-equivalence :
      ((x : X) → isEquiv (Square.fibre-map (crystalline-unit x))) → PenonEtale
    fiber-equivalence→neighborhood-equivalence fibers x =
      isEquiv[equivFunA≃B∘f]→isEquiv[f]
        (neighborhoodMap f x) (Target.At.neighborhood≃unit-fiber (f x))
        (subst isEquiv (funExt (neighborhood-square x))
          (snd (compEquiv (Source.At.neighborhood≃unit-fiber x)
            (Square.fibre-map (crystalline-unit x) , fibers x))))

    crystalline-etale→penon-etale : Crystal.Etale f → PenonEtale
    crystalline-etale→penon-etale crystalline =
      fiber-equivalence→neighborhood-equivalence
        (λ x → Square.comparison→fibres crystalline (crystalline-unit x))

    penon-etale→crystalline-etale : PenonEtale → Crystal.Etale f
    penon-etale→crystalline-etale penon = Square.fibres→comparison λ u →
      PT.rec (isPropIsEquiv (Square.fibre-map u))
        (λ (x , path) → subst (λ v → isEquiv (Square.fibre-map v)) path
          (neighborhood-equivalence→fiber-equivalence penon x))
        (crystalline-unit-surjective u)

    penon≃crystalline-etale : PenonEtale ≃ Crystal.Etale f
    penon≃crystalline-etale = propBiimpl→Equiv isPropPenonEtale
      (isPropIsEquiv (Crystal.unit-gap f))
      penon-etale→crystalline-etale crystalline-etale→penon-etale

    -- In a fiber of a Penon-etale map, two infinitesimally neighboring
    -- points with the same image must coincide. This is double-negation
    -- stability of fiber equality; it is not decidable equality.
    penon-etale-fibers-separated : PenonEtale → (y : Y)
      → (u v : fiber f y) → Neighbors u v → u ≡ v
    penon-etale-fibers-separated penon y u v near = Σ≡Prop
      (λ x → PenonManifold.points-set target-manifold (f x) y)
      (cong fst (invEq (congEquiv {x = source-neighbor} {y = source-center}
        (neighborhoodMap f (v .fst) , penon (v .fst)))
        (Σ≡Prop (λ _ → isPropNeighbors) (u .snd ∙ sym (v .snd)))))
      where
      source-neighbor : InfinitesimalNeighborhood (v .fst)
      source-neighbor = u .fst , preservesNeighbors fst near

      source-center : InfinitesimalNeighborhood (v .fst)
      source-center = center (v .fst)

    crystalline-etale-fibers-separated : Crystal.Etale f → (y : Y)
      → (u v : fiber f y) → Neighbors u v → u ≡ v
    crystalline-etale-fibers-separated crystalline =
      penon-etale-fibers-separated (crystalline-etale→penon-etale crystalline)
