{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CoherentTriangleColimits where

-- The homotopy colimit of one fixed coherent triangle. The literal
-- graph presentation is supplemented by a square for its composition
-- 2-cell. All vertex types, paths, and square data are untruncated.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Orbifolds.Coequalizers as CQ

module Diagram {ℓx ℓy ℓz : Level}
    (X : Type ℓx) (Y : Type ℓy) (Z : Type ℓz)
    (f : X → Y) (g : Y → Z) (h : X → Z)
    (composition : (x : X) → g (f x) ≡ h x) where

  data Colimit : Type (ℓ-max ℓx (ℓ-max ℓy ℓz)) where
    in-X : X → Colimit
    in-Y : Y → Colimit
    in-Z : Z → Colimit
    edge-f : (x : X) → in-X x ≡ in-Y (f x)
    edge-g : (y : Y) → in-Y y ≡ in-Z (g y)
    edge-h : (x : X) → in-X x ≡ in-Z (h x)
    cell : (x : X)
      → Square (edge-f x) (λ j → in-Z (composition x (~ j)))
          (edge-h x) (edge-g (f x))

  -- The actual homotopy coequalizer for the underlying graph. Its
  -- composition relation has not been added at this stage.
  Vertices : Type (ℓ-max ℓx (ℓ-max ℓy ℓz))
  Vertices = X ⊎ (Y ⊎ Z)

  Edges : Type (ℓ-max ℓx ℓy)
  Edges = X ⊎ (Y ⊎ X)

  source target : Edges → Vertices
  source (inl x) = inl x
  source (inr (inl y)) = inr (inl y)
  source (inr (inr x)) = inl x
  target (inl x) = inr (inl (f x))
  target (inr (inl y)) = inr (inr (g y))
  target (inr (inr x)) = inr (inr (h x))

  BareGraph : Type (ℓ-max ℓx (ℓ-max ℓy ℓz))
  BareGraph = CQ.Coeq source target

  graph-X : X → BareGraph
  graph-X x = CQ.point (inl x)

  graph-Y : Y → BareGraph
  graph-Y y = CQ.point (inr (inl y))

  graph-Z : Z → BareGraph
  graph-Z z = CQ.point (inr (inr z))

  graph-f : (x : X) → graph-X x ≡ graph-Y (f x)
  graph-f x = CQ.edge (inl x)

  graph-g : (y : Y) → graph-Y y ≡ graph-Z (g y)
  graph-g y = CQ.edge (inr (inl y))

  graph-h : (x : X) → graph-X x ≡ graph-Z (h x)
  graph-h x = CQ.edge (inr (inr x))

  graph-inclusion : BareGraph → Colimit
  graph-inclusion (CQ.point (inl x)) = in-X x
  graph-inclusion (CQ.point (inr (inl y))) = in-Y y
  graph-inclusion (CQ.point (inr (inr z))) = in-Z z
  graph-inclusion (CQ.edge (inl x) i) = edge-f x i
  graph-inclusion (CQ.edge (inr (inl y)) i) = edge-g y i
  graph-inclusion (CQ.edge (inr (inr x)) i) = edge-h x i

  record Cocone {ℓa : Level} (A : Type ℓa)
      : Type (ℓ-max ℓa (ℓ-max ℓx (ℓ-max ℓy ℓz))) where
    field
      leg-X : X → A
      leg-Y : Y → A
      leg-Z : Z → A
      commutes-f : (x : X) → leg-X x ≡ leg-Y (f x)
      commutes-g : (y : Y) → leg-Y y ≡ leg-Z (g y)
      commutes-h : (x : X) → leg-X x ≡ leg-Z (h x)
      coherence : (x : X)
        → Square (commutes-f x) (λ j → leg-Z (composition x (~ j)))
            (commutes-h x) (commutes-g (f x))
  open Cocone

  restrict : {ℓa : Level} {A : Type ℓa} → (Colimit → A) → Cocone A
  restrict u .leg-X = u ∘ in-X
  restrict u .leg-Y = u ∘ in-Y
  restrict u .leg-Z = u ∘ in-Z
  restrict u .commutes-f x = cong u (edge-f x)
  restrict u .commutes-g y = cong u (edge-g y)
  restrict u .commutes-h x = cong u (edge-h x)
  restrict u .coherence x i j = u (cell x i j)

  rec : {ℓa : Level} {A : Type ℓa} → Cocone A → Colimit → A
  rec c (in-X x) = leg-X c x
  rec c (in-Y y) = leg-Y c y
  rec c (in-Z z) = leg-Z c z
  rec c (edge-f x i) = commutes-f c x i
  rec c (edge-g y i) = commutes-g c y i
  rec c (edge-h x i) = commutes-h c x i
  rec c (cell x i j) = coherence c x i j

  eta : {ℓa : Level} {A : Type ℓa} (u : Colimit → A) → rec (restrict u) ≡ u
  eta u i (in-X x) = u (in-X x)
  eta u i (in-Y y) = u (in-Y y)
  eta u i (in-Z z) = u (in-Z z)
  eta u i (edge-f x j) = u (edge-f x j)
  eta u i (edge-g y j) = u (edge-g y j)
  eta u i (edge-h x j) = u (edge-h x j)
  eta u i (cell x j k) = u (cell x j k)

  universal : {ℓa : Level} (A : Type ℓa) → (Colimit → A) ≃ Cocone A
  universal A = isoToEquiv (iso restrict rec (λ _ → refl) eta)

  postcompose-cocone : {ℓa ℓb : Level} {A : Type ℓa} {B : Type ℓb}
    → Cocone A → (A → B) → Cocone B
  postcompose-cocone c k = restrict (k ∘ rec c)

  universal-natural : {ℓa ℓb : Level} {A : Type ℓa} {B : Type ℓb}
    (u : Colimit → A) (k : A → B)
    → restrict (k ∘ u) ≡ postcompose-cocone (restrict u) k
  universal-natural u k = refl

  -- This second universal property makes the cell attachment explicit:
  -- maps out are maps out of the bare graph together with actual fillers
  -- of the indicated squares. No unspecified attachment law is assumed.
  module Attachment {ℓa : Level} (A : Type ℓa) where
    Filling : (BareGraph → A) → Type (ℓ-max ℓx ℓa)
    Filling u = (x : X)
      → Square (cong u (graph-f x)) (λ j → u (graph-Z (composition x (~ j))))
          (cong u (graph-h x)) (cong u (graph-g (f x)))

    AttachedMap : Type (ℓ-max ℓa (ℓ-max ℓx (ℓ-max ℓy ℓz)))
    AttachedMap = Σ (BareGraph → A) Filling

    graph-map : Cocone A → BareGraph → A
    graph-map c (CQ.point (inl x)) = leg-X c x
    graph-map c (CQ.point (inr (inl y))) = leg-Y c y
    graph-map c (CQ.point (inr (inr z))) = leg-Z c z
    graph-map c (CQ.edge (inl x) i) = commutes-f c x i
    graph-map c (CQ.edge (inr (inl y)) i) = commutes-g c y i
    graph-map c (CQ.edge (inr (inr x)) i) = commutes-h c x i

    from-cocone : Cocone A → AttachedMap
    from-cocone c = graph-map c , coherence c

    to-cocone : AttachedMap → Cocone A
    to-cocone (u , c) .leg-X = u ∘ graph-X
    to-cocone (u , c) .leg-Y = u ∘ graph-Y
    to-cocone (u , c) .leg-Z = u ∘ graph-Z
    to-cocone (u , c) .commutes-f x = cong u (graph-f x)
    to-cocone (u , c) .commutes-g y = cong u (graph-g y)
    to-cocone (u , c) .commutes-h x = cong u (graph-h x)
    to-cocone (u , c) .coherence = c

    attachment-eta : (a : AttachedMap) → from-cocone (to-cocone a) ≡ a
    attachment-eta (u , c) i .fst (CQ.point (inl x)) = u (CQ.point (inl x))
    attachment-eta (u , c) i .fst (CQ.point (inr (inl y))) = u (CQ.point (inr (inl y)))
    attachment-eta (u , c) i .fst (CQ.point (inr (inr z))) = u (CQ.point (inr (inr z)))
    attachment-eta (u , c) i .fst (CQ.edge (inl x) j) = u (CQ.edge (inl x) j)
    attachment-eta (u , c) i .fst (CQ.edge (inr (inl y)) j) = u (CQ.edge (inr (inl y)) j)
    attachment-eta (u , c) i .fst (CQ.edge (inr (inr x)) j) = u (CQ.edge (inr (inr x)) j)
    attachment-eta (u , c) i .snd = c

    cocone≃attachment : Cocone A ≃ AttachedMap
    cocone≃attachment = isoToEquiv (iso from-cocone to-cocone attachment-eta (λ _ → refl))

    attachment-universal : (Colimit → A) ≃ AttachedMap
    attachment-universal = compEquiv (universal A) cocone≃attachment

    graph-computation : (u : Colimit → A) (b : BareGraph)
      → attachment-universal .fst u .fst b ≡ u (graph-inclusion b)
    graph-computation u (CQ.point (inl x)) = refl
    graph-computation u (CQ.point (inr (inl y))) = refl
    graph-computation u (CQ.point (inr (inr z))) = refl
    graph-computation u (CQ.edge (inl x) i) = refl
    graph-computation u (CQ.edge (inr (inl y)) i) = refl
    graph-computation u (CQ.edge (inr (inr x)) i) = refl

  terminal-cocone : Cocone Z
  terminal-cocone .leg-X = h
  terminal-cocone .leg-Y = g
  terminal-cocone .leg-Z = idfun Z
  terminal-cocone .commutes-f x = sym (composition x)
  terminal-cocone .commutes-g y = refl
  terminal-cocone .commutes-h x = refl
  terminal-cocone .coherence x i j = composition x (~ j)

  collapse : Colimit → Z
  collapse = rec terminal-cocone

  -- The contraction on the square is a cube. It is written explicitly
  -- and restricts to the prescribed contractions on all four faces.
  include-collapse : (u : Colimit) → in-Z (collapse u) ≡ u
  include-collapse (in-X x) i = edge-h x (~ i)
  include-collapse (in-Y y) i = edge-g y (~ i)
  include-collapse (in-Z z) i = in-Z z
  include-collapse (edge-f x j) i = cell x (~ i) j
  include-collapse (edge-g y j) i = edge-g y (j ∨ ~ i)
  include-collapse (edge-h x j) i = edge-h x (j ∨ ~ i)
  include-collapse (cell x j k) i = cell x (j ∨ ~ i) k

  colimit≃terminal : Colimit ≃ Z
  colimit≃terminal = isoToEquiv (iso collapse in-Z (λ _ → refl) include-collapse)

  collapse-X : (x : X) → collapse (in-X x) ≡ h x
  collapse-X x = refl

  collapse-Y : (y : Y) → collapse (in-Y y) ≡ g y
  collapse-Y y = refl

  collapse-Z : (z : Z) → collapse (in-Z z) ≡ z
  collapse-Z z = refl

  collapse-f : (x : X) → cong collapse (edge-f x) ≡ sym (composition x)
  collapse-f x = refl

  collapse-g : (y : Y) → cong collapse (edge-g y) ≡ refl
  collapse-g y = refl

  collapse-h : (x : X) → cong collapse (edge-h x) ≡ refl
  collapse-h x = refl

  collapse-cell : (x : X) (i j : I) → collapse (cell x i j) ≡ composition x (~ j)
  collapse-cell x i j = refl
