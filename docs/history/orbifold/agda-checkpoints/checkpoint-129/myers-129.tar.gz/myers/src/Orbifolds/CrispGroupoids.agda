{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispGroupoids where

-- Theorem 5.4.9 for actual crisp pregroupoids and all crisp Weil tests.
-- Canonical Rezk-map etaleness and all join preservation premises are
-- derived. The remaining source-etale and object-microlinear hypotheses
-- are precisely the geometric groupoid data, not conclusions in disguise.

open import Cubical.Foundations.Prelude
open import Cubical.Algebra.CommRing.Base
open import Cubical.Categories.Category using (Category)
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
open import Orbifolds.CrispTruncation using (FlatTruncationDistribution)
open import Orbifolds.GroupoidCompletion using (AllInvertible)
import Orbifolds.CrispGeometry as CG
import Orbifolds.CrispWeil as CW
import Orbifolds.CrispColimits as CC
import Orbifolds.Crystalline as CR
import Orbifolds.GroupoidEtale as GE
import Orbifolds.SyntheticField as SF
import Orbifolds.TinyTypes as TT

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (@♭ rules : CrispIdentityInduction {ℓ})
    (@♭ tiny-witness : TT.External.AdjointData (CR.Ring.𝔇 R)) where
  open CG.Context R
  module Colimits = CC.Context R rules tiny-witness
  module Adjoint = TT.External.Candidate Infinitesimal.𝔇 tiny-witness

  module Presentation (@♭ C : Category ℓ ℓ) (@♭ invertible : AllInvertible C) where
    module Groupoid = GE.Presentation C invertible
    module GroupoidModal = Groupoid.Modal Infinitesimal.CrystallineModality
    module Descent = Colimits.SelfPullback Groupoid.Completed.object

    canonical-object-etale : Adjoint.ExternalAdjunction
      → Infinitesimal.Crystal.Etale Groupoid.source
      → Infinitesimal.Crystal.Etale Groupoid.Completed.object
    canonical-object-etale adjunction source-etale =
      Descent.self-pullback-descent adjunction
        (GroupoidModal.kernel-source-etale source-etale) Groupoid.Completed.object-surjective

    module Geometry (adjunction : Adjoint.ExternalAdjunction)
        (distribute : FlatTruncationDistribution {ℓ = ℓ})
        (preserve : CrispPullbackPreservation) where
      module Connected = CW.Context.Proof R kock distribute preserve
      module Checked = GroupoidModal.Geometry
        (λ d → WeilTests.WeilRealPushout.test-square (underlying-diagram d))
        Connected.WeilModal.connected-tests
      module Finite = Checked.Finite
      module Orb = Checked.Orb

      completion-microlinear : Infinitesimal.Crystal.Etale Groupoid.source
        → Microlinear Groupoid.Objects → Microlinear Groupoid.Completed.Object
      completion-microlinear = Checked.completion-microlinear
        (λ X → Infinitesimal.crystalline-unit-surjective {X})
        (Descent.preserves-join-diagrams adjunction)

      completion-orbifold : Infinitesimal.Crystal.Etale Groupoid.source
        → Microlinear Groupoid.Objects → Finite.ProperlyFiniteHoms
        → Orb.Orbifold Groupoid.Completed.Object
      completion-orbifold = Checked.completion-orbifold
        (λ X → Infinitesimal.crystalline-unit-surjective {X})
        (Descent.preserves-join-diagrams adjunction)

-- The public form uses the mere Tiny predicate from Definition A.0.1;
-- choosing an external right adjoint globally is unnecessary.
module FromTinyness {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CG.Context R
  module Colimits = CC.FromTinyness R rules
  module Adjoints = TT.External Infinitesimal.𝔇

  module Presentation (@♭ C : Category ℓ ℓ) (@♭ invertible : AllInvertible C) where
    module Groupoid = GE.Presentation C invertible
    module GroupoidModal = Groupoid.Modal Infinitesimal.CrystallineModality
    module Descent = Colimits.SelfPullback Groupoid.Completed.object

    canonical-object-etale : Adjoints.Tiny
      → Infinitesimal.Crystal.Etale Groupoid.source
      → Infinitesimal.Crystal.Etale Groupoid.Completed.object
    canonical-object-etale tiny source-etale = Descent.self-pullback-descent tiny
      (GroupoidModal.kernel-source-etale source-etale) Groupoid.Completed.object-surjective

    module Geometry (tiny : Adjoints.Tiny)
        (distribute : FlatTruncationDistribution {ℓ = ℓ})
        (preserve : CrispPullbackPreservation) where
      module Connected = CW.Context.Proof R kock distribute preserve
      module Checked = GroupoidModal.Geometry
        (λ d → WeilTests.WeilRealPushout.test-square (underlying-diagram d))
        Connected.WeilModal.connected-tests
      module Finite = Checked.Finite
      module Orb = Checked.Orb

      completion-microlinear : Infinitesimal.Crystal.Etale Groupoid.source
        → Microlinear Groupoid.Objects → Microlinear Groupoid.Completed.Object
      completion-microlinear = Checked.completion-microlinear
        (λ X → Infinitesimal.crystalline-unit-surjective {X})
        (Descent.preserves-join-diagrams tiny)

      completion-orbifold : Infinitesimal.Crystal.Etale Groupoid.source
        → Microlinear Groupoid.Objects → Finite.ProperlyFiniteHoms
        → Orb.Orbifold Groupoid.Completed.Object
      completion-orbifold = Checked.completion-orbifold
        (λ X → Infinitesimal.crystalline-unit-surjective {X})
        (Descent.preserves-join-diagrams tiny)
