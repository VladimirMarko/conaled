{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NullHomotopyCoherentDiagram where

-- Actual coherent postcomposition by native nullification. No strict
-- composition law is asserted for its derived map. Higher action cubes
-- are constructed by extending dependent null-valued filler families.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (low; high)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentActionData using (_≤ᵈ_; same; lower; prefix-bound; suffix-bound; LawPair; law-pair)
import Orbifolds.Coherent.HomotopyCoherentActionData as Histories
import Orbifolds.Coherent.HomotopyCoherentActionCompatibility as Compatibility
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Orbifolds.Coherent.NullCoherentActionUnits as Units
import Orbifolds.Coherent.StrictNullCubicalExtensions as Extensions
import Cubical.HITs.Nullification.Base as NB
import Orbifolds.NullCubicalExtensions as NC

module Reflection {ℓ : Level} (C : Category ℓ ℓ) (D : StrictDiagram C ℓ)
    {Ix : Type₀} (S : Ix → Type ℓ) (E : StrictCubicalExtensionality ℓ) where
  open Category C
  module D = StrictDiagram D
  open Chains.Arrows C
  module U = Units.Units C D S E
  open U using (Value; AtUnit; constant)
  open Modality U.M using (η; ◯-map)
  module Data = Histories.Data C Value
  module Compatible = Compatibility.Compatibility C Value E
  module Null = Extensions.Nullification S E
  module Native = NC.NativeMaps S
  module HC = HCD.ForCategory C

  record Stage (n : Dim) : SSet ℓ where
    field
      actions : Data.Actions n
      coherent : Data.Coherent n actions
      at-unit : AtUnit n actions

  initial : Stage ozero
  Stage.actions initial = U.initial
  Stage.coherent initial = U.initial-coherent
  Stage.at-unit initial = U.initial-unit

  module Step (n : Dim) (previous : Stage n) where
    F : Data.Actions n
    F = Stage.actions previous

    module Cell {x y : Obj} (c : Chain (osuc n) x y) where
      module Extension = Null.Assembled n (D.Value x) (Value y) (NB.isNull-Null S)
        (Data.faces n F c)
        (Compatible.action-compatible n F (Stage.coherent previous) c)
        (λ a → η (D.action (whole (osuc n) c) a))
        (U.unit-faces n F (Stage.at-unit previous) c)

      action : Value x → Cube (osuc n) (Value y)
      action = Extension.cube

      unit : (a : D.Value x)
        → outer (action (η a))
          ≡ˢ outer (constant (osuc n) (η (D.action (whole (osuc n) c) a)))
      unit = Extension.cube-unit

    next : Data.Top (osuc n)
    next c = Cell.action c

    next-laws : Data.LayerLaws n F next
    Data.LayerLaws.zero-face next-laws p c a = Cell.Extension.cube-face c a p low
    Data.LayerLaws.one-face next-laws p c a = Cell.Extension.cube-face c a p high

    result : Stage (osuc n)
    Stage.actions result = F , next
    Stage.coherent result = law-pair (Stage.coherent previous) next-laws
    Stage.at-unit result .(osuc n) same c a = Cell.unit c a
    Stage.at-unit result m (lower bound) c a = Stage.at-unit previous m bound c a

  stage : (n : Dim) → Stage n
  stage ozero = initial
  stage (osuc n) = Step.result n (stage n)

  stage-lookup : {m n : Dim} (bound : m ≤ᵈ n)
    → outer {A = Data.Top m} (Data.at bound (Stage.actions (stage n)))
      ≡ˢ outer {A = Data.Top m} (Data.top m (Stage.actions (stage m)))
  stage-lookup same = reflˢ
  stage-lookup (lower bound) = stage-lookup bound

  reflected : HC.Diagram
  HC.Diagram.Value reflected = Value
  HC.Diagram.action reflected n = Data.top n (Stage.actions (stage n))
  HC.Diagram.zero-face reflected n p c a =
    Data.LayerLaws.zero-face (LawPair.current (Stage.coherent (stage (osuc n)))) p c a
  HC.Diagram.one-face reflected n p c a = strict-trans
    (Data.LayerLaws.one-face (LawPair.current (Stage.coherent (stage (osuc n)))) p c a)
    (strict-trans
      (strict-cong (λ g → outer (tensor-action n p (inner g (split-suffix n p c))
        (Data.at (prefix-bound n p) (Stage.actions (stage n)) (split-prefix n p c)) a))
        (stage-lookup (suffix-bound n p)))
      (strict-cong (λ f → outer (tensor-action n p
        (Data.top (suffix-degree n p) (Stage.actions (stage (suffix-degree n p))) (split-suffix n p c))
        (inner f (split-prefix n p c)) a))
        (stage-lookup (prefix-bound n p))))
  HC.Diagram.unit reflected x = funExt λ a →
    cong (λ f → ◯-map f a) (strict-to-path (D.action-id x)) ∙ Native.identity-cell a

  -- The pointwise vertices and the degree-zero map are the native ones.
  vertex-computation : (x : Obj) → outer (HC.Diagram.Value reflected x) ≡ˢ outer (NB.Null S (D.Value x))
  vertex-computation x = reflˢ

  arrow-computation : {x y : Obj} (f : Hom x y) (a : Value x)
    → outer (HC.Diagram.action reflected ozero f a) ≡ˢ outer (◯-map (D.action f) a)
  arrow-computation f a = reflˢ

  -- These exact all-dimensional computations are the coherent unit
  -- transformation from the original strict diagram to its reflection.
  action-at-unit : (n : Dim) {x y : Obj} (c : Chain n x y) (a : D.Value x)
    → outer (HC.Diagram.action reflected n c (η a))
      ≡ˢ outer (constant n (η (D.action (whole n c) a)))
  action-at-unit n c a = Stage.at-unit (stage n) n same c a

  unit-is-equivalence : (x : Obj) → isEquiv (HC.Diagram.action reflected ozero (ident x))
  unit-is-equivalence = HC.Diagram.unit-is-equivalence reflected
