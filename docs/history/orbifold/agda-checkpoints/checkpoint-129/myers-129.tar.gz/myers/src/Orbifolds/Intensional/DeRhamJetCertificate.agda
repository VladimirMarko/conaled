{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.DeRhamJetCertificate where

-- A finite computational certificate for the Reiffen/de Jong example.
-- Polynomial multiplication, differentiation, coefficient extraction and
-- the separating functional are executable definitions. Their concrete
-- values below are checked by normalization. The external de Rham and
-- sheaf arguments are documented separately; they are not assumed here.

open import Agda.Primitive using (Set)
open import Agda.Builtin.Nat using (Nat; zero; suc; _+_; _*_)
open import Orbifolds.Intensional.Identity using (_≡_; refl)

data Integer : Set where
  positive : Nat → Integer
  negative : Nat → Integer

-- negative n denotes minus (n + 1), so zero has a unique constructor.
difference : Nat → Nat → Integer
difference zero zero = positive zero
difference zero (suc n) = negative n
difference (suc n) zero = positive (suc n)
difference (suc n) (suc m) = difference n m

negate : Integer → Integer
negate (positive zero) = positive zero
negate (positive (suc n)) = negative n
negate (negative n) = positive (suc n)

infixl 6 _⊕_
_⊕_ : Integer → Integer → Integer
positive n ⊕ positive m = positive (n + m)
positive n ⊕ negative m = difference n (suc m)
negative n ⊕ positive m = difference m (suc n)
negative n ⊕ negative m = negative (suc (n + m))

scale : Nat → Integer → Integer
scale zero a = positive zero
scale (suc n) a = a ⊕ scale n a

data Sequence (A : Set) : Set where
  [] : Sequence A
  _∷_ : A → Sequence A → Sequence A
infixr 5 _∷_

append : {A : Set} → Sequence A → Sequence A → Sequence A
append [] ys = ys
append (x ∷ xs) ys = x ∷ append xs ys

map : {A B : Set} → (A → B) → Sequence A → Sequence B
map f [] = []
map f (a ∷ as) = f a ∷ map f as

record Monomial : Set where
  constructor monomial
  field
    coefficient : Integer
    x-degree : Nat
    y-degree : Nat
open Monomial

Polynomial : Set
Polynomial = Sequence Monomial

shift : Nat → Nat → Polynomial → Polynomial
shift i j = map (λ m → monomial (coefficient m) (i + x-degree m) (j + y-degree m))

negate-polynomial : Polynomial → Polynomial
negate-polynomial = map (λ m → monomial (negate (coefficient m)) (x-degree m) (y-degree m))

dx-term : Monomial → Monomial
dx-term (monomial a zero j) = monomial (positive zero) zero j
dx-term (monomial a (suc i) j) = monomial (scale (suc i) a) i j

dy-term : Monomial → Monomial
dy-term (monomial a i zero) = monomial (positive zero) i zero
dy-term (monomial a i (suc j)) = monomial (scale (suc j) a) i j

dx dy : Polynomial → Polynomial
dx = map dx-term
dy = map dy-term

choose-degree : Nat → Nat → Integer → Integer
choose-degree zero zero a = a
choose-degree zero (suc m) a = positive zero
choose-degree (suc n) zero a = positive zero
choose-degree (suc n) (suc m) a = choose-degree n m a

coefficient-at : Nat → Nat → Polynomial → Integer
coefficient-at i j [] = positive zero
coefficient-at i j (m ∷ ms) =
  choose-degree i (x-degree m) (choose-degree j (y-degree m) (coefficient m))
    ⊕ coefficient-at i j ms

f : Polynomial
f = monomial (positive 1) 4 0 ∷ monomial (positive 1) 0 5
  ∷ monomial (positive 1) 1 4 ∷ []

-- L(a,b) = dx(f b) - dy(f a). Only the twelve monomial inputs
-- of degree at most two can contribute below total degree six.
record Exponent : Set where
  constructor exponent
  field
    x : Nat
    y : Nat
open Exponent

quadratic-basis : Sequence Exponent
quadratic-basis = exponent 0 0 ∷ exponent 0 1 ∷ exponent 0 2
  ∷ exponent 1 0 ∷ exponent 1 1 ∷ exponent 2 0 ∷ []

a-column b-column : Exponent → Polynomial
a-column e = negate-polynomial (dy (shift (x e) (y e) f))
b-column e = dx (shift (x e) (y e) f)

operator-columns : Sequence Polynomial
operator-columns = append (map a-column quadratic-basis) (map b-column quadratic-basis)

functional : Polynomial → Integer
functional p = negate (scale 28 (coefficient-at 4 0 p))
  ⊕ negate (scale 92 (coefficient-at 0 5 p))
  ⊕ scale 116 (coefficient-at 1 4 p)
  ⊕ scale 23 (coefficient-at 3 1 p)
  ⊕ negate (scale 145 (coefficient-at 2 3 p))

zeros : Nat → Sequence Integer
zeros zero = []
zeros (suc n) = positive zero ∷ zeros n

annihilates-all-twelve-columns : map functional operator-columns ≡ zeros 12
annihilates-all-twelve-columns = refl

separates-target : functional f ≡ negative 3
separates-target = refl

data Empty : Set where

target-functional-nonzero : functional f ≡ positive zero → Empty
target-functional-nonzero ()

-- Retain the exact five coefficient rows, independently of the kernel
-- computation. The table follows from the polynomial definitions above.
coefficient-row : Nat → Nat → Sequence Integer
coefficient-row i j = map (coefficient-at i j) operator-columns

x4-row : coefficient-row 4 0 ≡
  (positive 0 ∷ negative 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0
  ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 5 ∷ positive 0 ∷ positive 0 ∷ [])
x4-row = refl

y5-row : coefficient-row 0 5 ≡
  (positive 0 ∷ negative 5 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0
  ∷ positive 0 ∷ positive 1 ∷ positive 0 ∷ positive 1 ∷ positive 0 ∷ positive 0 ∷ [])
y5-row = refl

xy4-row : coefficient-row 1 4 ≡
  (positive 0 ∷ negative 4 ∷ positive 0 ∷ negative 4 ∷ positive 0 ∷ positive 0
  ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 2 ∷ positive 0 ∷ positive 0 ∷ [])
xy4-row = refl

x3y-row : coefficient-row 3 1 ≡
  (positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0
  ∷ positive 0 ∷ positive 4 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ [])
x3y-row = refl

x2y3-row : coefficient-row 2 3 ≡
  (positive 0 ∷ positive 0 ∷ positive 0 ∷ negative 3 ∷ positive 0 ∷ positive 0
  ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ positive 0 ∷ [])
x2y3-row = refl
