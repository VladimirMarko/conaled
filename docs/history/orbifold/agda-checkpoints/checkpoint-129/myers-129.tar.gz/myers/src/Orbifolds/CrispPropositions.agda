{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispPropositions where

-- R-flatness and a crisp point of R make every crisp proposition
-- crisply discrete.  Thus ordinary proofs of crisp propositions may be
-- promoted into Flat; this is derived, not a context-reset principle.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Crisp
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
import Orbifolds.CrispIdentity as CI

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R) where
  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = (@♭ P : Type ℓ) →
    CrisplyDiscrete P ≃ isEquiv (const :> (P → (R → P)))

  proposition-null : (@♭ P : Type ℓ) → isProp P
    → isEquiv (const :> (P → (R → P)))
  proposition-null P propP = isoToIsEquiv
    (iso const (λ f → f r₀)
      (λ f → funExt λ r → propP (f r₀) (f r)) (λ _ → refl))

  proposition-discrete : RealFlat → (@♭ P : Type ℓ)
    → isProp P → CrisplyDiscrete P
  proposition-discrete real-flat P propP =
    invEq (real-flat P) (proposition-null P propP)

  promote-proof : RealFlat → (@♭ P : Type ℓ)
    → isProp P → P → Flat P
  promote-proof real-flat P propP =
    invEq (counit , proposition-discrete real-flat P propP)

  promote-counit : (real-flat : RealFlat) (@♭ P : Type ℓ)
    (propP : isProp P) (p : P)
    → counit (promote-proof real-flat P propP p) ≡ p
  promote-counit real-flat P propP =
    secEq (counit , proposition-discrete real-flat P propP)

  module WithIdentity (@♭ rules : CrispIdentityInduction {ℓ}) where
    module Identity = CI.Theory rules

    flat-preserves-isEquiv : (real-flat : RealFlat)
      {@♭ A B : Type ℓ} (@♭ f : A → B)
      → isEquiv f → isEquiv (flat-map f)
    flat-preserves-isEquiv real-flat f equivalence =
      flat-elim (λ _ → isEquiv (flat-map f))
        (Identity.flat-preserves-isEquiv f)
        (promote-proof real-flat (isEquiv f) (isPropIsEquiv f) equivalence)

    flat-equivalence : (real-flat : RealFlat)
      {@♭ A B : Type ℓ} (@♭ f : A → B)
      → isEquiv f → Flat A ≃ Flat B
    flat-equivalence real-flat f equivalence =
      flat-map f , flat-preserves-isEquiv real-flat f equivalence
