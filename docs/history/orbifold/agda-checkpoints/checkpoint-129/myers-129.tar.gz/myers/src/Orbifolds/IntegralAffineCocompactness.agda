{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineCocompactness where

-- A literal compact subset of R^n whose integral-affine translates
-- cover R^n. Its parameter space is the closed cube [0,1]^n, mapped
-- by multiplication by 2. The overlapping cover requires no floor
-- function, selected representatives, or decidable real order.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism using (Iso)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Functions.Embedding using (_↪_)
open import Cubical.Functions.Image using
  (Image; imageInclusion; restrictToImage; isSurjectionImageRestriction)
open import Cubical.Functions.Surjection using (isSurjection; compSurjection)
open import Cubical.Relation.Binary.Base using (module BinaryRelation)
open BinaryRelation using (isEquivRel)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.SetQuotients as SQ
open import Orbifolds.Compactness using (DPCompact; surjectiveImageDPCompact)
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.IntegralAffineActions as IA
import Orbifolds.TorusTranslations as TT
import Orbifolds.TorusCompactness as TC
import Orbifolds.FreeActionQuotients as FQ

module Geometry {ℓ : Level} (R : CommRing ℓ)
  (kock : SF.RingContext.KockField R)
  (order : SF.RingContext.StrictOrder R)
  (compatibility : SO.OrderTheory.OrderedRingCompatibility R order)
  (n : ℕ) where
  open CommRingStr (R .snd)
  module Affine = IA.Coordinates R n
  module Torus = TT.Coordinates R order n
  module Compact = TC.Geometry R kock order compatibility
  module Cube = Compact.Dimension n
  open Compact.Interval using (UnitIntervalCompact)
  open Affine using (Vector)

  cube-point : Cube.FundamentalCube → Vector
  cube-point t i = Compact.two · t i .fst

  FundamentalRegion : Type ℓ
  FundamentalRegion = Image cube-point

  region-inclusion : FundamentalRegion ↪ Vector
  region-inclusion = imageInclusion cube-point

  fundamental-region-compact : UnitIntervalCompact → DPCompact FundamentalRegion
  fundamental-region-compact compact = surjectiveImageDPCompact
    (Cube.cube-compact compact) (restrictToImage cube-point)
    (isSurjectionImageRestriction cube-point)

  module Representation (H : Group ℓ) (ρ : GroupHom H Affine.Z.GeneralLinear) where
    module Linear = Affine.Representation H ρ
    module Action = FQ.Action Linear.AffineGroup Linear.Combined.combined
    module HS = GroupStr (H .snd)
    module AS = GroupStr (Linear.AffineGroup .snd)

    OrbitSpace : Type ℓ
    OrbitSpace = Action.OrbitSet

    orbit : Vector → OrbitSpace
    orbit = SQ.[_]

    torus-to-orbit-space : Torus.Torus → OrbitSpace
    torus-to-orbit-space = SQ.rec SQ.squash/ orbit
      (λ x y (z , p) → SQ.eq/ x y
        ((lift z , HS.1g) , cong (Affine.translate (lift z)) (Linear.linear-unit x) ∙ p))

    torus-to-orbit-surjective : isSurjection torus-to-orbit-space
    torus-to-orbit-surjective = SQ.elimProp (λ q → PT.squash₁)
      (λ x → PT.∣ Torus.project x , refl ∣₁)

    cube-orbit-cover : Cube.FundamentalCube → OrbitSpace
    cube-orbit-cover t = orbit (cube-point t)

    cube-orbit-cover-surjective : isSurjection cube-orbit-cover
    cube-orbit-cover-surjective = compSurjection
      (Cube.cube-cover , Cube.cube-cover-surjective)
      (torus-to-orbit-space , torus-to-orbit-surjective) .snd

    orbit-space-compact : UnitIntervalCompact → DPCompact OrbitSpace
    orbit-space-compact compact = surjectiveImageDPCompact
      (Cube.cube-compact compact) cube-orbit-cover cube-orbit-cover-surjective

    inverse-action-left : (g : Linear.AffineGroup .fst) (x : Vector)
      → Linear.affine (AS.inv g) (Linear.affine g x) ≡ x
    inverse-action-left g x = sym (Linear.Combined.combined-compose (AS.inv g) g x)
      ∙ cong (λ h → Linear.affine h x) (AS.·InvL g)
      ∙ Linear.Combined.combined-unit x

    orbit-relation-equivalence : isEquivRel Action.Relation
    isEquivRel.reflexive orbit-relation-equivalence x =
      AS.1g , Linear.Combined.combined-unit x
    isEquivRel.symmetric orbit-relation-equivalence x y (g , p) =
      AS.inv g , cong (Linear.affine (AS.inv g)) (sym p) ∙ inverse-action-left g x
    isEquivRel.transitive orbit-relation-equivalence x y z (g , p) (h , q) =
      h AS.· g , Linear.Combined.combined-compose h g x
        ∙ cong (Linear.affine h) p ∙ q

    cube-translates-cover : (x : Vector)
      → PT.∥ Σ[ t ∈ Cube.FundamentalCube ] Σ[ g ∈ Linear.AffineGroup .fst ]
          Linear.affine g (cube-point t) ≡ x ∥₁
    cube-translates-cover x = PT.rec PT.squash₁
      (λ { (t , p) → PT.map (λ r → t , r)
        (Iso.fun (SQ.isEquivRel→TruncIso orbit-relation-equivalence (cube-point t) x) p) })
      (cube-orbit-cover-surjective (orbit x))

    compact-region-translates-cover : (x : Vector)
      → PT.∥ Σ[ u ∈ FundamentalRegion ] Σ[ g ∈ Linear.AffineGroup .fst ]
          Linear.affine g (region-inclusion .fst u) ≡ x ∥₁
    compact-region-translates-cover x = PT.map
      (λ { (t , g , p) → restrictToImage cube-point t , g , p })
      (cube-translates-cover x)
