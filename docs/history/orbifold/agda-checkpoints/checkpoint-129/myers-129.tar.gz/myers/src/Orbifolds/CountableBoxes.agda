{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CountableBoxes where

-- An explicitly countable family of rational boxes in each finite real
-- power.  Every member is Penon open, and every squared-norm ball contains
-- one of these boxes around its center.  We do not assume that every
-- Penon-open predicate on R^n is open in the box topology.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc)
open import Cubical.Data.Unit using (Unit*; tt*; isPropUnit*)
open import Cubical.Data.Sum using (inr)
open import Cubical.Algebra.CommRing.Base
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.IntervalTopology using (module Intervals)
open import Orbifolds.RealCountableBasis using (module RealBasis)
open import Orbifolds.EuclideanNorms using (module Norms)
open import Orbifolds.Penon using (PenonOpen; ProductPredicate; productPenonOpen; inverseImagePenonOpen)
open import Orbifolds.PenonNeighborhoods using (BallStructure; CoveringProperty)
open import Orbifolds.Topology using (Predicate)
open import Orbifolds.Refinements using (Included)
open import Orbifolds.SubspaceBases using (CountableBasis)
open import Orbifolds.NatPairing using (enumeratePair; encodePair; enumerateEncodePair; enumerateTriple)

module Boxes {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open RingContext R
  open StrictOrder order
  open OrderTheory R order using (Carrier)
  open RealProbe R kock order compatibility using (PositiveRadius; intervalBalls)
  open Intervals R kock order compatibility using (ballPenonOpen)
  open Norms R kock order compatibility
    using (Vector; tail; squaredDistance; normBallContainsBox)
  module Real = RealBasis R kock order compatibility

  BasicBox : (n : ℕ) → ℕ → Predicate (Vector n)
  BasicBox zero code v = Unit* {ℓ = ℓ} , isPropUnit*
  BasicBox (suc n) code v =
    ProductPredicate (Real.Basic (enumeratePair code .fst))
      (BasicBox n (enumeratePair code .snd)) (v fzero , tail v)

  basicBoxPenonOpen : (n code : ℕ) → PenonOpen (BasicBox n code)
  basicBoxPenonOpen zero code x _ y = ∣ inr tt* ∣₁
  basicBoxPenonOpen (suc n) code = inverseImagePenonOpen (λ v → v fzero , tail v)
    (ProductPredicate (Real.Basic (enumeratePair code .fst)) (BasicBox n (enumeratePair code .snd)))
    (productPenonOpen (Real.Basic (enumeratePair code .fst)) (BasicBox n (enumeratePair code .snd))
      (Real.gridOpen (enumerateTriple (enumeratePair code .fst)))
      (basicBoxPenonOpen n (enumeratePair code .snd)))

  BoxPredicate : (n : ℕ) → Vector n → PositiveRadius → Predicate (Vector n)
  BoxPredicate n x δ y =
    ((i : Fin n) → BallStructure.ball intervalBalls (x i) δ (y i) .fst) ,
    isPropΠ (λ i → BallStructure.ball intervalBalls (x i) δ (y i) .snd)

  boxContainsCenter : (n : ℕ) (x : Vector n) (δ : PositiveRadius) → BoxPredicate n x δ x .fst
  boxContainsCenter n x δ i = BallStructure.centerInBall intervalBalls (x i) δ

  basicBoxAt : CoveringProperty intervalBalls →
    (n : ℕ) (x : Vector n) (δ : PositiveRadius) →
    ∥ Σ[ code ∈ ℕ ] (BasicBox n code x .fst × Included (BasicBox n code) (BoxPredicate n x δ)) ∥₁
  basicBoxAt covering zero x δ = ∣ zero , tt* , (λ y _ → λ ()) ∣₁
  basicBoxAt covering (suc n) x δ = PT.map2 combine
    (CountableBasis.localBasis (Real.realCountableBasis covering)
      (BallStructure.ball intervalBalls (x fzero) δ) (ballPenonOpen (x fzero) δ)
      (x fzero) (BallStructure.centerInBall intervalBalls (x fzero) δ))
    (basicBoxAt covering n (tail x) δ)
    where
    pairPredicate : ℕ × ℕ → Predicate (Vector (suc n))
    pairPredicate (a , b) v = ProductPredicate (Real.Basic a) (BasicBox n b) (v fzero , tail v)

    combine :
      (Σ[ a ∈ ℕ ] (Real.Basic a (x fzero) .fst ×
        Included (Real.Basic a) (BallStructure.ball intervalBalls (x fzero) δ))) →
      (Σ[ b ∈ ℕ ] (BasicBox n b (tail x) .fst ×
        Included (BasicBox n b) (BoxPredicate n (tail x) δ))) →
      Σ[ code ∈ ℕ ] (BasicBox (suc n) code x .fst ×
        Included (BasicBox (suc n) code) (BoxPredicate (suc n) x δ))
    combine (a , atHead , includeHead) (b , atTail , includeTail) = encodePair (a , b) ,
      subst (λ P → P x .fst × Included P (BoxPredicate (suc n) x δ))
        (sym (cong pairPredicate (enumerateEncodePair (a , b))))
        ((atHead , atTail) , (λ y member → λ
          { fzero → includeHead (y fzero) (member .fst)
          ; (fsuc i) → includeTail (tail y) (member .snd) i
          }))

  normBallBasicBox : CoveringProperty intervalBalls →
    (n : ℕ) (x : Vector n) (ε : PositiveRadius) →
    ∥ Σ[ code ∈ ℕ ] (BasicBox n code x .fst ×
      ((y : Vector n) → BasicBox n code y .fst → squaredDistance n x y < ε .fst)) ∥₁
  normBallBasicBox covering n x ε = PT.rec squash₁
    (λ { (δ , boxIncluded) → PT.map
      (λ { (code , contains , includes) → code , contains ,
        (λ y member → boxIncluded y (includes y member)) })
      (basicBoxAt covering n x δ) })
    (normBallContainsBox n x ε)

