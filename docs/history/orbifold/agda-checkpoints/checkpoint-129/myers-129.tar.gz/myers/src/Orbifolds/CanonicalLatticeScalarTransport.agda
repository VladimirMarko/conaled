{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CanonicalLatticeScalarTransport where

-- The actual inverse scalar coordinate computes carrier transport
-- directly. Its path and computation stay opaque to concrete scalar
-- substitutions, while the exact inverse comparison is retained.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Algebra.CommRing.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexPairs as CP
import Orbifolds.ComplexLines as CL
import Orbifolds.ComplexLatticeStructures as LS
import Orbifolds.CanonicalLatticeIdentities as LI
import Orbifolds.CanonicalLatticePathCoordinates as LPC

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  Complex = CP.Ring.Complex R
  canonical = CL.Complex.canonical-line R
  Unit = CL.Complex.Unit R
  Moduli = LS.Geometry.FiniteFreeModuli R kock order compatibility
  Lattice = LS.Geometry.FiniteFreeLattice R kock order compatibility canonical

  module At (Λ Γ : Lattice) where
    Preserves : Unit → Type ℓ
    Preserves = LI.Geometry.Canonical.ScalarPreserves R kock order compatibility Λ Γ

    abstract
      scalar-path : (u : Unit) → Preserves u → Path Moduli (canonical , Λ) (canonical , Γ)
      scalar-path = LPC.Geometry.At.scalar-path R kock order compatibility Λ Γ

      inverse-computation : (u : Unit) (preserves : Preserves u)
        → invEq (LI.Geometry.Canonical.scalar-identities R kock order compatibility Λ Γ)
            (u , preserves) ≡ scalar-path u preserves
      inverse-computation u preserves = refl

      line-transport : (u : Unit) (preserves : Preserves u) (z : Complex)
        → subst (CL.Complex.Carrier R) (cong fst (scalar-path u preserves)) z
          ≡ CP.Ring._*c_ R (u .fst) z
      line-transport u preserves z = cong (λ p → subst (CL.Complex.Carrier R) p z)
        (LPC.Geometry.At.scalar-path-line R kock order compatibility Λ Γ u preserves)
        ∙ CL.Complex.unit-loop-transport R u z
