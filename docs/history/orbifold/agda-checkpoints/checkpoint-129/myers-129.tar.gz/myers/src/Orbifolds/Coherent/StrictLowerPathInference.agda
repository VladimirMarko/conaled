{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictLowerPathInference where

-- Infer the type of a genuine strict-reflexivity comparison inside the
-- selected scope. The ordinary proof argument reflˢ must pass native checking.
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
import Agda.Builtin.Reflection as R
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (visible-argument; hidden-argument)
open import Orbifolds.Coherent.TriplePathInference using (assign-strict-frozen)
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCellMaps as Core

reflexivity : ∀ {ℓ} {A : Type ℓ} (x y : A)
  → outer x ≡ˢ outer y → outer x ≡ˢ outer y
reflexivity x .x reflˢ = reflˢ

macro
  component-reflexivity : R.Term → R.Term → R.Term → R.TC ⊤
  component-reflexivity x y hole = assign-strict-frozen
    ((quote Core.Construction.At.lower-path) ∷
     (quote Cocones.Functoriality.Cocone) ∷
     (quote Cocones.Functoriality.postcompose) ∷ (quote _∙_) ∷ [])
    (R.def (quote reflexivity)
      (hidden-argument R.unknown ∷ hidden-argument R.unknown ∷
       visible-argument x ∷ visible-argument y ∷
       visible-argument (R.con (quote reflˢ) []) ∷ [])) hole
