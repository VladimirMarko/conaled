{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.OuterCubicalFaces where

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat; Position; pzero; psuc; weaken; _≤ᵖ_; pzero≤; psuc≤)
import Orbifolds.CubicalShells as CS

-- Explicit additional 2LTT structural input. This is not supplied by
-- Cubical Agda, is not postulated here, and contains no preservation theorem.
-- Both interval functions and endpoint-typed paths are explicit: deriving
-- the second rule by equality elimination on forgotten functions failed.
record StrictCubicalExtensionality (ℓ : Level) : SSet (ℓ-suc ℓ) where
  field
    interval-ext : {A : I → Type ℓ} {f g : (i : I) → A i}
      → ((i : I) → outer (f i) ≡ˢ outer (g i))
      → outer f ≡ˢ outer g
    path-ext : {A : I → Type ℓ} {a : A i0} {b : A i1} {p q : PathP A a b}
      → ((i : I) → outer (p i) ≡ˢ outer (q i))
      → outer p ≡ˢ outer q

record Coordinate : SSet where
  constructor coord
  field value : I
open Coordinate public

record OUnit : SSet where
  constructor ott

record OPair (A B : SSet) : SSet where
  constructor pair
  field first : A
        second : B
open OPair public

Coordinates : Dim → SSet
Coordinates ozero = OUnit
Coordinates (osuc n) = OPair Coordinate (Coordinates n)

Cube : ∀ {ℓ} → Dim → Type ℓ → Type ℓ
Cube n X = CS.Cube (toNat n) X

evaluate : ∀ {ℓ} (n : Dim) {X : Type ℓ} → Cube n X → Coordinates n → X
evaluate ozero c xs = c
evaluate (osuc n) c xs = evaluate n (c (value (first xs))) (second xs)

abstract-cube : ∀ {ℓ} (n : Dim) {X : Type ℓ} → (Coordinates n → X) → Cube n X
abstract-cube ozero f = f ott
abstract-cube (osuc n) f i = abstract-cube n (λ xs → f (pair (coord i) xs))

evaluate-abstract : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (f : Coordinates n → X) (xs : Coordinates n)
  → outer (evaluate n (abstract-cube n f) xs) ≡ˢ outer (f xs)
evaluate-abstract ozero f xs = reflˢ
evaluate-abstract (osuc n) f xs = evaluate-abstract n
  (λ ys → f (pair (first xs) ys)) (second xs)

insert : (n : Dim) → Position (osuc n) → I → Coordinates n → Coordinates (osuc n)
insert n pzero i xs = pair (coord i) xs
insert (osuc n) (psuc p) i xs = pair (first xs) (insert n p i (second xs))

coordinate-face : ∀ {ℓ} (n : Dim) → Position (osuc n) → I
  → {X : Type ℓ} → Cube (osuc n) X → Cube n X
coordinate-face n pzero i c = c i
coordinate-face (osuc n) (psuc p) i c j = coordinate-face n p i (c j)

face-evaluation : ∀ {ℓ} (n : Dim) (p : Position (osuc n)) (i : I)
  {X : Type ℓ} (c : Cube (osuc n) X) (xs : Coordinates n)
  → outer (evaluate n (coordinate-face n p i c) xs)
    ≡ˢ outer (evaluate (osuc n) c (insert n p i xs))
face-evaluation n pzero i c xs = reflˢ
face-evaluation (osuc n) (psuc p) i c xs =
  face-evaluation n p i (c (value (first xs))) (second xs)

map-cube : ∀ {ℓ ℓ'} (n : Dim) {X : Type ℓ} {Y : Type ℓ'}
  → (X → Y) → Cube n X → Cube n Y
map-cube ozero f c = f c
map-cube (osuc n) f c i = map-cube n f (c i)

module Extensional {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E

  cube-extensionality : (n : Dim) {X : Type ℓ} {c d : Cube n X}
    → ((xs : Coordinates n) → outer (evaluate n c xs) ≡ˢ outer (evaluate n d xs))
    → outer c ≡ˢ outer d
  cube-extensionality ozero p = p ott
  cube-extensionality (osuc n) p = interval-ext λ i →
    cube-extensionality n (λ xs → p (pair (coord i) xs))

  abstract-evaluate : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → outer (abstract-cube n (evaluate n c)) ≡ˢ outer c
  abstract-evaluate ozero c = reflˢ
  abstract-evaluate (osuc n) c = interval-ext λ i → abstract-evaluate n (c i)

  face-commutes : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
    → (i j : I) {X : Type ℓ} (c : Cube (osuc (osuc n)) X)
    → outer (coordinate-face n p i (coordinate-face (osuc n) (psuc q) j c))
      ≡ˢ outer (coordinate-face n q j (coordinate-face (osuc n) (weaken p) i c))
  face-commutes n pzero q pzero≤ i j c = reflˢ
  face-commutes (osuc n) (psuc p) (psuc q) (psuc≤ le) i j c = interval-ext λ t →
    face-commutes n p q le i j (c t)

  map-identity : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → outer (map-cube n (λ x → x) c) ≡ˢ outer c
  map-identity ozero c = reflˢ
  map-identity (osuc n) c = interval-ext λ i → map-identity n (c i)

  map-compose : ∀ {ℓx ℓy} (n : Dim) {X : Type ℓx} {Y : Type ℓy} {Z : Type ℓ}
    (g : Y → Z) (f : X → Y) (c : Cube n X)
    → outer (map-cube n g (map-cube n f c)) ≡ˢ outer (map-cube n (λ x → g (f x)) c)
  map-compose ozero g f c = reflˢ
  map-compose (osuc n) g f c = interval-ext λ i → map-compose n g f (c i)

  map-face : ∀ {ℓx} (n : Dim) (p : Position (osuc n)) (i : I)
    {X : Type ℓx} {Y : Type ℓ} (f : X → Y) (c : Cube (osuc n) X)
    → outer (map-cube n f (coordinate-face n p i c))
      ≡ˢ outer (coordinate-face n p i (map-cube (osuc n) f c))
  map-face n pzero i f c = reflˢ
  map-face (osuc n) (psuc p) i f c = interval-ext λ j → map-face n p i f (c j)
