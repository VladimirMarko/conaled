{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteActionBranchCharts where

-- An explicit numbering of the actual labels constructs finite branch
-- charts for the hom-family used by ActionGroupoids.Action. No arrow
-- relation or effectivity equivalence is introduced as an extra premise.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.ActionGroupoids using (ActionHom)
import Orbifolds.Intensional.FiniteBranchAtlas as B

module Finite {ℓ : Level} {G X : Set ℓ}
    (setX : isSet X) (act : G → X → X)
    {n : Nat} (numbering : Equiv G (B.Fin {ℓ} n)) where

  Hom : X → X → Set ℓ
  Hom = ActionHom act

  domain : B.Fin {ℓ} n → X → Set ℓ
  domain i x = Unit {ℓ}

  branch-target : (i : B.Fin {ℓ} n) (x : X) → domain i x → X
  branch-target i x d = act (backward numbering i) x

  branch-fiber-prop : (x y : X) (i : B.Fin {ℓ} n)
    → isProp (Σ (domain i x) (λ d → branch-target i x d ≡ y))
  branch-fiber-prop x y i =
    isPropΣ isPropUnit (λ d → setX (branch-target i x d) y)

  branch-forward : {x y : X} → Hom x y
    → B.BranchArrows n domain branch-target x y
  branch-forward {x} (g , p) = forward numbering g , tt ,
    cong (λ h → act h x) (retraction numbering g) ∙ p

  branch-backward : {x y : X}
    → B.BranchArrows n domain branch-target x y → Hom x y
  branch-backward (i , d , p) = backward numbering i , p

  branch-section : {x y : X}
    (b : B.BranchArrows n domain branch-target x y)
    → branch-forward {x} {y} (branch-backward {x} {y} b) ≡ b
  branch-section {x} {y} (i , d , p) =
    Σ-path-prop (branch-fiber-prop x y) (section numbering i)

  branch-retraction : {x y : X} (f : Hom x y)
    → branch-backward {x} {y} (branch-forward {x} {y} f) ≡ f
  branch-retraction {x} {y} (g , p) =
    Σ-path-prop (λ h → setX (act h x) y) (retraction numbering g)

  chart : B.BranchChart Hom
  B.BranchChart.branches chart = n
  B.BranchChart.domain chart = domain
  B.BranchChart.domain-prop chart i x = isPropUnit
  B.BranchChart.target chart = branch-target
  B.BranchChart.hom-equivalence chart x y =
    equiv (branch-forward {x} {y}) (branch-backward {x} {y})
      (branch-section {x} {y}) (branch-retraction {x} {y})

  hom-subfinite : (x y : X) → B.SubfiniteWitness (Hom x y)
  hom-subfinite = B.chart-subfinite-witness setX chart

  stabilizer-subfinite : (x : X) → B.SubfiniteWitness (Hom x x)
  stabilizer-subfinite x = hom-subfinite x x

  -- The same labels give the actual local charts required by the accepted
  -- finite-branch atlas interface. Both regions are the entire object set.
  Region : Set ℓ
  Region = Σ X (λ _ → Unit {ℓ})

  region-set : isSet Region
  region-set = isSetΣProp setX (λ _ → isPropUnit)

  region-domain : B.Fin {ℓ} n → Region → Set ℓ
  region-domain i u = Unit {ℓ}

  region-target : (i : B.Fin {ℓ} n) (u : Region) → region-domain i u → Region
  region-target i u d = act (backward numbering i) (fst u) , tt

  region-fiber-prop : (u v : Region) (i : B.Fin {ℓ} n)
    → isProp (Σ (region-domain i u) (λ d → region-target i u d ≡ v))
  region-fiber-prop u v i =
    isPropΣ isPropUnit (λ d → region-set (region-target i u d) v)

  region-forward : {u v : Region} → Hom (fst u) (fst v)
    → B.BranchArrows n region-domain region-target u v
  region-forward {u} {v} (g , p) = forward numbering g , tt ,
    Σ-path-prop (λ _ → isPropUnit)
      (cong (λ h → act h (fst u)) (retraction numbering g) ∙ p)

  region-backward : {u v : Region}
    → B.BranchArrows n region-domain region-target u v → Hom (fst u) (fst v)
  region-backward (i , d , p) = backward numbering i , cong fst p

  region-section : {u v : Region}
    (b : B.BranchArrows n region-domain region-target u v)
    → region-forward {u} {v} (region-backward {u} {v} b) ≡ b
  region-section {u} {v} (i , d , p) =
    Σ-path-prop (region-fiber-prop u v) (section numbering i)

  region-retraction : {u v : Region} (f : Hom (fst u) (fst v))
    → region-backward {u} {v} (region-forward {u} {v} f) ≡ f
  region-retraction {u} {v} (g , p) =
    Σ-path-prop (λ h → setX (act h (fst u)) (fst v)) (retraction numbering g)

  region-chart : B.BranchChart (λ (u v : Region) → Hom (fst u) (fst v))
  B.BranchChart.branches region-chart = n
  B.BranchChart.domain region-chart = region-domain
  B.BranchChart.domain-prop region-chart i u = isPropUnit
  B.BranchChart.target region-chart = region-target
  B.BranchChart.hom-equivalence region-chart u v =
    equiv (region-forward {u} {v}) (region-backward {u} {v})
      (region-section {u} {v}) (region-retraction {u} {v})

  local-chart : (x y : X) → B.LocalBranchChart Hom x y
  B.LocalBranchChart.source-region (local-chart x y) u = Unit {ℓ}
  B.LocalBranchChart.source-region-prop (local-chart x y) u = isPropUnit
  B.LocalBranchChart.target-region (local-chart x y) v = Unit {ℓ}
  B.LocalBranchChart.target-region-prop (local-chart x y) v = isPropUnit
  B.LocalBranchChart.source-member (local-chart x y) = tt
  B.LocalBranchChart.target-member (local-chart x y) = tt
  B.LocalBranchChart.local-chart (local-chart x y) = region-chart
