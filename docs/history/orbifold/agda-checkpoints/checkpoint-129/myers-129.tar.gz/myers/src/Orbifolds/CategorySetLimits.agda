{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CategorySetLimits where

-- Every small category-shaped limit of microlinear sets is microlinear.
-- The constructed cone is a literal Cubical.Categories.Limits.LimCone;
-- the result also applies to any other cone with the universal property.
-- Graph limits alone would not justify this claim for higher-valued
-- category diagrams, where coherence for composition must be retained.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Graph
open import Cubical.Categories.Category using (Category)
open import Cubical.Categories.Functor using (Functor)
open import Cubical.Categories.Instances.Sets using (SET; completeSET; CatIso→Iso)
import Cubical.Categories.Limits.Limits as CL
import Orbifolds.GraphLimits as GL
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module Diagram {ℓj ℓh : Level} (J : Category ℓj ℓh)
    (D : Functor J (SET (ℓ-max ℓj ℓh))) where
  private
    ℓ = ℓ-max ℓj ℓh
  open Category J using (ob; Hom[_,_])
  open Functor D using (F-ob; F-hom)

  shape : Graph ℓj ℓh
  shape .Node = ob
  shape .Edge = Hom[_,_]

  diagram : Diag ℓ shape
  diagram ._$g_ j = F-ob j .fst
  diagram ._<$g>_ e = F-hom e

  module G = GL.Diagram shape diagram

  compatibility-prop : (s : G.Vertices) → isProp (G.Compatibility s)
  compatibility-prop s = isPropΠ λ i → isPropΠ λ j → isPropΠ λ e → F-ob j .snd _ _

  limit-set : isSet G.Limit
  limit-set = isSetΣSndProp (isSetΠ λ j → F-ob j .snd) compatibility-prop

  limiting-cone : CL.LimCone D
  limiting-cone .CL.LimCone.lim = G.Limit , limit-set
  limiting-cone .CL.LimCone.limCone .CL.Cone.coneOut = G.projection
  limiting-cone .CL.LimCone.limCone .CL.Cone.coneOutCommutes {u} {v} e =
    funExt (G.projection-square u v e)
  limiting-cone .CL.LimCone.univProp c cc = uniqueExists
    (λ t → (λ j → cc .CL.Cone.coneOut j t) ,
      (λ i j e k → cc .CL.Cone.coneOutCommutes e k t))
    (λ _ → refl)
    (CL.isPropIsConeMor cc (limiting-cone .CL.LimCone.limCone))
    (λ f hf → funExt λ t → Σ≡Prop compatibility-prop
      (funExt λ j → sym (funExt⁻ (hf j) t)))

  -- Uniqueness of actual categorical limits, rather than an independently
  -- asserted equivalence to the graph construction.
  any-limit-equivalence : (L : CL.LimCone D)
    → G.Limit ≃ L .CL.LimCone.lim .fst
  any-limit-equivalence L = isoToEquiv
    (CatIso→Iso (CL.LimIso D limiting-cone L .fst .fst))

  library-limit-equivalence : G.Limit ≃ CL.LimCone.lim (completeSET J D) .fst
  library-limit-equivalence = any-limit-equivalence (completeSET J D)

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw) where
    module M = Micro.Theory test
    module Limits = ML.Limits test
    module GraphML = G.Microlinear test

    limit-microlinear : ((j : ob) → M.Microlinear (F-ob j .fst))
      → M.Microlinear G.Limit
    limit-microlinear = GraphML.limit-microlinear

    any-limit-microlinear : (L : CL.LimCone D)
      → ((j : ob) → M.Microlinear (F-ob j .fst))
      → M.Microlinear (L .CL.LimCone.lim .fst)
    any-limit-microlinear L micro = Limits.microlinear-equiv
      (any-limit-equivalence L) (limit-microlinear micro)

    library-limit-microlinear : ((j : ob) → M.Microlinear (F-ob j .fst))
      → M.Microlinear (CL.LimCone.lim (completeSET J D) .fst)
    library-limit-microlinear = any-limit-microlinear (completeSET J D)
