{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.CommutativeAlgebraCore where

-- A commutative algebra is an actual semimodule with an
-- actual bilinear multiplication. Ring structure is derived when the
-- coefficient semiring has additive inverses.

open import Agda.Primitive using (Level; Set; lsuc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv; isEquiv→Equiv)
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor

private variable ℓ : Level

record CommutativeAlgebra (R : CommutativeSemiring ℓ) : Set (lsuc ℓ) where
  field
    moduleR : Semimodule R
  open Semimodule moduleR public
  field
    one : Carrier
    multiplication : BilinearMap moduleR moduleR moduleR

  _*_ : Carrier → Carrier → Carrier
  _*_ = fst multiplication

  field
    *-assoc : (a b c : Carrier) → (a * b) * c ≡ a * (b * c)
    *-comm : (a b : Carrier) → a * b ≡ b * a
    *-one-left : (a : Carrier) → one * a ≡ a

  *-one-right : (a : Carrier) → a * one ≡ a
  *-one-right a = *-comm a one ∙ *-one-left a

  left-multiply : Carrier → LinearMap moduleR moduleR
  left-multiply = bilinear-right {L = moduleR} {M = moduleR} {N = moduleR} multiplication

  right-multiply : Carrier → LinearMap moduleR moduleR
  right-multiply = bilinear-left {L = moduleR} {M = moduleR} {N = moduleR} multiplication

  semiring : CommutativeSemiring ℓ
  CommutativeSemiring.additive semiring = additive
  CommutativeSemiring.one semiring = one
  CommutativeSemiring._*_ semiring = _*_
  CommutativeSemiring.*-assoc semiring = *-assoc
  CommutativeSemiring.*-comm semiring = *-comm
  CommutativeSemiring.*-one-left semiring = *-one-left
  CommutativeSemiring.*-one-right semiring = *-one-right
  CommutativeSemiring.*-zero-left semiring v =
    linear-zero {M = moduleR} {N = moduleR} (right-multiply v)
  CommutativeSemiring.*-zero-right semiring u =
    linear-zero {M = moduleR} {N = moduleR} (left-multiply u)
  CommutativeSemiring.*-add-left semiring u v w =
    linear-add {M = moduleR} {N = moduleR} (right-multiply w) u v
  CommutativeSemiring.*-add-right semiring u v w =
    linear-add {M = moduleR} {N = moduleR} (left-multiply u) v w

record AlgebraHom {R : CommutativeSemiring ℓ}
    (A B : CommutativeAlgebra R) : Set ℓ where
  constructor algebra-hom
  private module A = CommutativeAlgebra A
  private module B = CommutativeAlgebra B
  field
    linear : LinearMap A.moduleR B.moduleR

  map : A.Carrier → B.Carrier
  map = fst linear

  field
    map-one : map A.one ≡ B.one
    map-mul : (u v : A.Carrier) → map (u A.* v) ≡ map u B.* map v

  map-zero : map A.zero ≡ B.zero
  map-zero = linear-zero {M = A.moduleR} {N = B.moduleR} linear

  map-add : (u v : A.Carrier) → map (u A.+ v) ≡ map u B.+ map v
  map-add = linear-add {M = A.moduleR} {N = B.moduleR} linear

  map-scalar : (r : CommutativeSemiring.Carrier R) (v : A.Carrier)
    → map (r A.• v) ≡ r B.• map v
  map-scalar = linear-scalar {M = A.moduleR} {N = B.moduleR} linear

algebra-hom-path : (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
  {A B : CommutativeAlgebra R} {h k : AlgebraHom A B}
  → AlgebraHom.linear h ≡ AlgebraHom.linear k → h ≡ k
algebra-hom-path ext {A = A} {B = B}
    {h = algebra-hom h h1 hm} {k = algebra-hom .h k1 km} refl =
  cong₂ (algebra-hom {A = A} {B = B} h)
    (CommutativeAlgebra.carrier-set B _ _ h1 k1)
    (isPropΠ ext (λ u → isPropΠ ext (λ v → CommutativeAlgebra.carrier-set B _ _)) hm km)

identity-algebra-hom : {R : CommutativeSemiring ℓ} (A : CommutativeAlgebra R) → AlgebraHom A A
AlgebraHom.linear (identity-algebra-hom A) = identity-linear (CommutativeAlgebra.moduleR A)
AlgebraHom.map-one (identity-algebra-hom A) = refl
AlgebraHom.map-mul (identity-algebra-hom A) u v = refl

compose-algebra-hom : {R : CommutativeSemiring ℓ} {A B C : CommutativeAlgebra R}
  → AlgebraHom B C → AlgebraHom A B → AlgebraHom A C
AlgebraHom.linear (compose-algebra-hom {A = A} {B = B} {C = C} g f) =
  compose-linear {M = CommutativeAlgebra.moduleR A} {N = CommutativeAlgebra.moduleR B}
    {P = CommutativeAlgebra.moduleR C} (AlgebraHom.linear g) (AlgebraHom.linear f)
AlgebraHom.map-one (compose-algebra-hom g f) =
  cong (AlgebraHom.map g) (AlgebraHom.map-one f) ∙ AlgebraHom.map-one g
AlgebraHom.map-mul (compose-algebra-hom g f) u v =
  cong (AlgebraHom.map g) (AlgebraHom.map-mul f u v)
    ∙ AlgebraHom.map-mul g (AlgebraHom.map f u) (AlgebraHom.map f v)

record AlgebraIso {R : CommutativeSemiring ℓ}
    (A B : CommutativeAlgebra R) : Set ℓ where
  field
    to-hom : AlgebraHom A B
    from-hom : AlgebraHom B A
    to-from : (v : CommutativeAlgebra.Carrier B)
      → AlgebraHom.map to-hom (AlgebraHom.map from-hom v) ≡ v
    from-to : (u : CommutativeAlgebra.Carrier A)
      → AlgebraHom.map from-hom (AlgebraHom.map to-hom u) ≡ u

module Inverse {ℓ : Level} {R : CommutativeSemiring ℓ}
    (A B : CommutativeAlgebra R) (h : AlgebraHom A B)
    (equivalence : isEquiv (AlgebraHom.map h)) where

  private module A = CommutativeAlgebra A
  private module B = CommutativeAlgebra B
  private module H = AlgebraHom h

  underlying : Equiv A.Carrier B.Carrier
  underlying = isEquiv→Equiv H.map equivalence

  inverse : B.Carrier → A.Carrier
  inverse = backward underlying

  injective : {u v : A.Carrier} → H.map u ≡ H.map v → u ≡ v
  injective {u = u} {v = v} p =
    sym (retraction underlying u) ∙ cong inverse p ∙ retraction underlying v

  inverse-linear : LinearMap B.moduleR A.moduleR
  inverse-linear = inverse ,
    ((injective (section underlying B.zero ∙ sym H.map-zero) ,
      λ u v → injective (section underlying (u B.+ v)
        ∙ sym (H.map-add (inverse u) (inverse v)
          ∙ cong₂ B._+_ (section underlying u) (section underlying v)))) ,
      λ r v → injective (section underlying (r B.• v)
        ∙ sym (H.map-scalar r (inverse v) ∙ cong (B._•_ r) (section underlying v))))

  inverse-hom : AlgebraHom B A
  AlgebraHom.linear inverse-hom = inverse-linear
  AlgebraHom.map-one inverse-hom = injective (section underlying B.one ∙ sym H.map-one)
  AlgebraHom.map-mul inverse-hom u v = injective (section underlying (u B.* v)
    ∙ sym (H.map-mul (inverse u) (inverse v)
      ∙ cong₂ B._*_ (section underlying u) (section underlying v)))

  algebra-isomorphism : AlgebraIso A B
  AlgebraIso.to-hom algebra-isomorphism = h
  AlgebraIso.from-hom algebra-isomorphism = inverse-hom
  AlgebraIso.to-from algebra-isomorphism = section underlying
  AlgebraIso.from-to algebra-isomorphism = retraction underlying

record CommutativeRing (ℓ : Level) : Set (lsuc ℓ) where
  field
    semiring : CommutativeSemiring ℓ
  open CommutativeSemiring semiring public
  field
    negate : Carrier → Carrier
    negate-left : (r : Carrier) → negate r + r ≡ zero

module RingConsequences {ℓ : Level} (R : CommutativeRing ℓ)
    (A : CommutativeAlgebra (CommutativeRing.semiring R)) where

  private module R = CommutativeRing R
  private module A = CommutativeAlgebra A

  negate : A.Carrier → A.Carrier
  negate v = R.negate R.one A.• v

  negate-left : (v : A.Carrier) → negate v A.+ v ≡ A.zero
  negate-left v = cong (λ z → negate v A.+ z) (sym (A.•-one v))
    ∙ sym (A.add-• (R.negate R.one) R.one v)
    ∙ cong (λ r → r A.• v) (R.negate-left R.one) ∙ A.zero-• v

  ring : CommutativeRing ℓ
  CommutativeRing.semiring ring = A.semiring
  CommutativeRing.negate ring = negate
  CommutativeRing.negate-left ring = negate-left

module RingMapConsequences {ℓ : Level} (R : CommutativeRing ℓ)
    (A B : CommutativeAlgebra (CommutativeRing.semiring R)) (h : AlgebraHom A B) where

  private module R = CommutativeRing R
  module Source = RingConsequences R A
  module Target = RingConsequences R B

  map-negate : (v : CommutativeAlgebra.Carrier A)
    → AlgebraHom.map h (Source.negate v) ≡ Target.negate (AlgebraHom.map h v)
  map-negate = AlgebraHom.map-scalar h (R.negate R.one)
