{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalFillerNullhomotopies where

-- A complete endpoint-typed cubical filler is precisely a choice of
-- center together with a nullhomotopy of its actual sphere boundary.
-- This is derived from the shell representation and cube contraction.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.CubicalShells using (Cube; Shell; restriction; origin; cube-equivalence)
open import Orbifolds.CubicalShellFillers using (Filler; filler-fiber-equivalence)
open import Orbifolds.CubicalShellSpheres using
  (SphereBoundary; shell-equivalence; evaluate-shell; restriction-computation)

Nullhomotopy : ∀ {ℓ} (n : ℕ) {X : Type ℓ} → Shell n X → Type ℓ
Nullhomotopy n {X} b = Σ[ center ∈ X ]
  (evaluate-shell n b ≡ (λ _ → center))

fiber-nullhomotopy : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → fiber (restriction n) b ≃ Nullhomotopy n b
fiber-nullhomotopy n {X} b = Σ-cong-equiv (cube-equivalence n X) λ c →
  (congEquiv (shell-equivalence n X)
    ∙ₑ compPathlEquiv (sym (restriction-computation n X c)))
    ∙ₑ isoToEquiv symIso

filler-nullhomotopy : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → Filler n b ≃ Nullhomotopy n b
filler-nullhomotopy n b = filler-fiber-equivalence n b ∙ₑ fiber-nullhomotopy n b

fill-from-nullhomotopy : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  → Nullhomotopy n b → Filler n b
fill-from-nullhomotopy n b = invEq (filler-nullhomotopy n b)

nullhomotopy-computation : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (h : Nullhomotopy n b)
  → filler-nullhomotopy n b .fst (fill-from-nullhomotopy n b h) ≡ h
nullhomotopy-computation n b = secEq (filler-nullhomotopy n b)

filler-computation : ∀ {ℓ} (n : ℕ) {X : Type ℓ} (b : Shell n X)
  (f : Filler n b)
  → fill-from-nullhomotopy n b (filler-nullhomotopy n b .fst f) ≡ f
filler-computation n b = retEq (filler-nullhomotopy n b)
