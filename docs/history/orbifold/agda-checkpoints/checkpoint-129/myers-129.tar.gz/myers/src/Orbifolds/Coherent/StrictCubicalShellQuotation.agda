{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalShellQuotation where

-- Canonical quotation of an actual suspension-sphere map as a full
-- cubical shell. The definition is recursive in the finite outer degree.
-- Constant and mapping laws are proved strictly; no equivalence is assumed.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit using (tt)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
import Orbifolds.Coherent.StrictCubicalShellAssembly as Assembly
import Orbifolds.Coherent.StrictCubicalFillers as Fillers
import Orbifolds.Coherent.StrictCubicalShellMaps as Maps
import Orbifolds.CubicalShells as CS
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)
import Cubical.HITs.Susp as S

module Quotation {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module Assemble = Assembly.Construction E
  module Filler = Fillers.Boundary E
  module Map = Maps.Action E

  mutual
    quote-shell : (n : Dim) {X : Type ℓ}
      → (SphereBoundary (toNat n) → X) → CS.Shell (toNat n) X
    quote-shell ozero h = lift tt
    quote-shell (osuc n) h =
      (CS.constant-cube (toNat n) (h S.north) , CS.constant-cube (toNat n) (h S.south)) ,
      strict-end-path (λ i → quote-shell n (λ s → h (S.merid s i)))
        (quote-constant n (h S.north)) (quote-constant n (h S.south))

    quote-constant : (n : Dim) {X : Type ℓ} (x : X)
      → outer (quote-shell n (λ _ → x))
        ≡ˢ outer (CS.restriction (toNat n) (CS.constant-cube (toNat n) x))
    quote-constant ozero x = reflˢ
    quote-constant (osuc n) x = Assemble.shell-correct n
      (CS.constant-cube (toNat n) x) (CS.constant-cube (toNat n) x)
      (λ i → quote-shell n (λ _ → x))
      (quote-constant n x) (quote-constant n x)
      (CS.constant-cube (toNat (osuc n)) x)
      reflˢ reflˢ (λ i → quote-constant n x)

  quote-side : (n : Dim) {X : Type ℓ}
    (h : SphereBoundary (toNat (osuc n)) → X) (i : I)
    → outer (quote-shell (osuc n) h .snd i)
      ≡ˢ outer (quote-shell n (λ s → h (S.merid s i)))
  quote-side n h i = strict-end-path-value
    (λ j → quote-shell n (λ s → h (S.merid s j)))
    (quote-constant n (h S.north)) (quote-constant n (h S.south)) i

  map-constant-cube : (n : Dim) {X Y : Type ℓ} (f : X → Y) (x : X)
    → outer (map-cube n f (CS.constant-cube (toNat n) x))
      ≡ˢ outer (CS.constant-cube (toNat n) (f x))
  map-constant-cube ozero f x = reflˢ
  map-constant-cube (osuc n) f x = interval-ext λ i → map-constant-cube n f x

  quote-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (h : SphereBoundary (toNat n) → X)
    → outer (Map.map-shell n f (quote-shell n h))
      ≡ˢ outer (quote-shell n (λ s → f (h s)))
  quote-natural ozero f h = reflˢ
  quote-natural (osuc n) f h = Filler.shell-equality n
    (map-cube n f (CS.constant-cube (toNat n) (h S.north)))
    (map-cube n f (CS.constant-cube (toNat n) (h S.south)))
    (CS.constant-cube (toNat n) (f (h S.north)))
    (CS.constant-cube (toNat n) (f (h S.south)))
    (Map.map-shell (osuc n) f (quote-shell (osuc n) h) .snd)
    (quote-shell (osuc n) (λ s → f (h s)) .snd)
    (map-constant-cube n f (h S.north)) (map-constant-cube n f (h S.south))
    (λ i → strict-trans
      (Map.side-computation n f (quote-shell (osuc n) h) i)
      (strict-trans
        (strict-cong (λ b → outer (Map.map-shell n f (inner b))) (quote-side n h i))
        (strict-trans
          (quote-natural n f (λ s → h (S.merid s i)))
          (strict-sym (quote-side n (λ s → f (h s)) i)))))
