{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentTransformations where

-- Strict natural maps between the chosen coherent presentations.
-- Naturality compares the complete action cube at every dimension.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
import Orbifolds.Coherent.CoherentArrowChains as Chains
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD

module ForCategory {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C
  open Chains.Arrows C
  open HCD.ForCategory C using (Diagram)

  record Transformation (D G : Diagram) : SSet ℓ where
    private
      module D = Diagram D
      module G = Diagram G
    field
      component : (x : Obj) → D.Value x → G.Value x
      naturality : (n : Dim) {x y : Obj} (c : Chain n x y) (a : D.Value x)
        → outer (map-cube n (component y) (D.action n c a))
          ≡ˢ outer (G.action n c (component x a))

  module Algebra (E : StrictCubicalExtensionality ℓ) where
    open Cubes.Extensional E

    identity : (D : Diagram) → Transformation D D
    Transformation.component (identity D) x a = a
    Transformation.naturality (identity D) n c a = map-identity n (Diagram.action D n c a)

    compose-map : {D G H : Diagram} → Transformation G H → Transformation D G → Transformation D H
    Transformation.component (compose-map β α) x a = Transformation.component β x (Transformation.component α x a)
    Transformation.naturality (compose-map {D} {G} {H} β α) n {x} {y} c a = strict-trans
      (strict-sym (map-compose n (Transformation.component β y) (Transformation.component α y) (Diagram.action D n c a)))
      (strict-trans
        (strict-cong (λ q → outer (map-cube n (Transformation.component β y) (inner q)))
          (Transformation.naturality α n c a))
        (Transformation.naturality β n c (Transformation.component α x a)))
