{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispFiniteCovers where

-- Proposition 6.2.15 for small indexed open covers of the existing
-- universe-bounded topology. The output is a genuinely finite subobject
-- of the original index set, not merely a finite list with duplicates.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.FinSet using (isFinSet)
import Cubical.Data.FinSet.FiniteChoice as FiniteChoice
open import Cubical.Functions.Embedding
open import Cubical.Functions.Image
  using (Image; imageInclusion; restrictToImage)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
open import Orbifolds.Association using (SubfinitelyEnumerable)
open import Orbifolds.ProperFiniteness using (imageSubfinitelyEnumerable)
open import Orbifolds.CountableCovers using (Covers)
open import Orbifolds.Refinements using (Included)
open import Orbifolds.Topology using (Topology; IsOpen)
import Orbifolds.CrispFiniteness as CF
import Orbifolds.CrispPropositions as CP

record OpenEnumerableRefinement {ℓ : Level} {K I : Type ℓ}
    (topology : Topology K) (U : I → K → hProp ℓ) : Type (ℓ-suc ℓ) where
  field
    Index : Type ℓ
    index-isSet : isSet Index
    index-enumerable : SubfinitelyEnumerable Index
    member : Index → K → hProp ℓ
    member-open : (j : Index) → IsOpen topology (member j)
    covers : Covers member
    refines : (j : Index) → PT.∥ Σ[ i ∈ I ] Included (member j) (U i) ∥₁

record FiniteSubcover {ℓ : Level} {K I : Type ℓ}
    (U : I → K → hProp ℓ) : Type (ℓ-suc ℓ) where
  field
    Chosen : Type ℓ
    finite-chosen : isFinSet Chosen
    include : Chosen ↪ I
    covers-chosen : Covers (U ∘ include .fst)

-- This is the actual refinement-subcompactness property, restricted to
-- index sets in the topology's existing universe bound.
RefinementSubcompact : {ℓ : Level} {K : Type ℓ}
  → Topology K → Type (ℓ-suc ℓ)
RefinementSubcompact {ℓ} {K} topology =
  (I : Type ℓ) → isSet I → (U : I → K → hProp ℓ)
  → ((i : I) → IsOpen topology (U i)) → Covers U
  → PT.∥ OpenEnumerableRefinement topology U ∥₁

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R) where
  module Propositions = CP.Context R r₀
  module Finite = CF.Context R r₀

  module Cover {@♭ K I : Type ℓ} (@♭ topology : Topology K)
      (@♭ setI : isSet I) (@♭ U : I → K → hProp ℓ) where
    module ForRefinement (@♭ refinement : OpenEnumerableRefinement topology U) where
      module V = OpenEnumerableRefinement refinement

      Selectors : Type ℓ
      Selectors = (j : V.Index) → Σ[ i ∈ I ] Included (V.member j) (U i)

      selectors-exist : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
        → FlatTruncationDistribution {ℓ = ℓ-suc ℓ} → PT.∥ Selectors ∥₁
      selectors-exist real-flat excluded-middle distribute = FiniteChoice.choice
        (V.Index , Finite.crisply-subfinite→finite real-flat excluded-middle distribute
          V.Index V.index-isSet V.index-enumerable)
        (λ j → Σ[ i ∈ I ] Included (V.member j) (U i)) V.refines

      module Selection (@♭ choices : Selectors) where
        select : V.Index → I
        select j = choices j .fst

        Selected : Type ℓ
        Selected = Image select

        selected-isSet : isSet Selected
        selected-isSet = isSetΣ setI (λ _ → isProp→isSet PT.squash₁)

        selected-enumerable : SubfinitelyEnumerable Selected
        selected-enumerable = imageSubfinitelyEnumerable select V.index-enumerable

        selected-subcover : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
          → FlatTruncationDistribution {ℓ = ℓ-suc ℓ} → FiniteSubcover U
        selected-subcover real-flat excluded-middle distribute = record
          { Chosen = Selected
          ; finite-chosen = Finite.crisply-subfinite→finite real-flat excluded-middle distribute
              Selected selected-isSet selected-enumerable
          ; include = imageInclusion select
          ; covers-chosen = λ x → PT.map
              (λ (j , belongs) → restrictToImage select j , choices j .snd x belongs)
              (V.covers x)
          }

      finite-subcover : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
        → FlatTruncationDistribution {ℓ = ℓ}
        → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
        → PT.∥ FiniteSubcover U ∥₁
      finite-subcover real-flat excluded-middle distribute distribute-upper =
        PT.rec PT.squash₁
          (λ { (box choices) → PT.∣ Selection.selected-subcover choices
            real-flat excluded-middle distribute-upper ∣₁ })
          (distribute Selectors
            (Propositions.promote-proof real-flat (PT.∥ Selectors ∥₁) PT.squash₁
              (selectors-exist real-flat excluded-middle distribute-upper)))

    crisp-refinement→finite-subcover : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → FlatTruncationDistribution {ℓ = ℓ}
      → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
      → (@♭ witness : PT.∥ OpenEnumerableRefinement topology U ∥₁)
      → PT.∥ FiniteSubcover U ∥₁
    crisp-refinement→finite-subcover real-flat excluded-middle distribute distribute-upper =
      crisp-truncation-rec distribute-upper (OpenEnumerableRefinement topology U)
        PT.squash₁
        (λ refinement → ForRefinement.finite-subcover refinement
          real-flat excluded-middle distribute distribute-upper)

    crisp-subcompact→finite-subcover : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → FlatTruncationDistribution {ℓ = ℓ}
      → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
      → (@♭ compact : RefinementSubcompact topology)
      → (@♭ openU : (i : I) → IsOpen topology (U i))
      → (@♭ coversU : Covers U) → PT.∥ FiniteSubcover U ∥₁
    crisp-subcompact→finite-subcover real-flat excluded-middle distribute distribute-upper
        compact openU coversU = crisp-refinement→finite-subcover
        real-flat excluded-middle distribute distribute-upper
        (compact I setI U openU coversU)
