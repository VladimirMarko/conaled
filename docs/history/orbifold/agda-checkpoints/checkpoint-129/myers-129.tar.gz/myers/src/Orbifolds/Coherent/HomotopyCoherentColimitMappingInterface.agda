{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface where

-- Explicitly typed access to the constructed bar representation.  All
-- implementations are the accepted maps and witnesses, reached through
-- qualified names without instantiating the complete Construction scope.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; suc)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentConeStages as Cones
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitPresentation as Bar
import Orbifolds.CellularPresentations as CP
import Orbifolds.CellularCoconeRepresentation as Representation
import Cubical.HITs.SequentialColimit as SC

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where

  Colimit : Type ℓ
  Colimit = Bar.Construction.Colimit C D E F

  state : ℕ → Σ[ A ∈ Type ℓ ] CP.Presentation A
  state = Bar.Construction.Realization.state C D E F

  Stage : ℕ → Type ℓ
  Stage n = state n .fst

  inclusion : (n : ℕ) → Stage n → Stage (suc n)
  inclusion = Bar.Construction.Realization.inclusion C D E F

  presentation : (n : Dim) (previous : Represented.Induction.Represented C D E F n)
    → CP.Presentation (Represented.Induction.Represented.Space previous)
  presentation = Bar.Construction.presentation C D E F

  module MappingOut (Y : Type ℓ) where
    Into : HC.ForCategory.Diagram (Opposite C)
    Into = Mapping.Mapping.Into C D E F Y

    ConeState : Type (ℓ-suc ℓ)
    ConeState = Cones.Construction.State (Opposite C) Into E

    advance : ConeState → ConeState
    advance = Cones.Construction.advance (Opposite C) Into E

    module Witnesses = Representation.Coinductive {ℓa = ℓ} Y ConeState fst advance (λ q → fst)

    PartialCocone : ℕ → Type ℓ
    PartialCocone = Cones.Construction.PartialCone (Opposite C) Into E

    drop : (n : ℕ) → PartialCocone (suc n) → PartialCocone n
    drop = Cones.Construction.drop (Opposite C) Into E

    Cocone : Type ℓ
    Cocone = Cones.Construction.Limit (Opposite C) Into E

    finite-witness : (n : Dim) (previous : Represented.Induction.Represented C D E F n)
      → Witnesses.Witness (presentation n previous) (Finite.Finite.finite-state (Opposite C) Into E n)
    finite-witness = Bar.Construction.MappingOut.finite-witness C D E F Y

    witness-at : (n : ℕ)
      → Witnesses.Witness (state n .snd) (Cones.Construction.state (Opposite C) Into E n)
    witness-at = Bar.Construction.MappingOut.witness-at C D E F Y

    stage-universal : (n : ℕ) → (Stage n → Y) ≃ PartialCocone n
    stage-universal = Bar.Construction.MappingOut.stage-universal C D E F Y

    stage-square : (n : ℕ) (h : Stage (suc n) → Y)
      → drop n (stage-universal (suc n) .fst h) ≡ stage-universal n .fst (h ∘ inclusion n)
    stage-square = Bar.Construction.MappingOut.stage-square C D E F Y

    universal : (Colimit → Y) ≃ Cocone
    universal = Bar.Construction.MappingOut.universal C D E F Y

    restrict : (Colimit → Y) → Cocone
    restrict = Bar.Construction.MappingOut.restrict C D E F Y

    assemble : Cocone → Colimit → Y
    assemble = Bar.Construction.MappingOut.assemble C D E F Y

    compatibility-computation : (h : Colimit → Y) (n : ℕ)
      → restrict h .snd n
        ≡ stage-square n (h ∘ SC.incl {n = suc n})
          ∙ cong (stage-universal n .fst) (sym (λ i x → h (SC.push {n = n} x i)))
    compatibility-computation = Bar.Construction.MappingOut.compatibility-computation C D E F Y

  canonical-cocone : MappingOut.Cocone Colimit
  canonical-cocone = Bar.Construction.canonical-cocone C D E F
