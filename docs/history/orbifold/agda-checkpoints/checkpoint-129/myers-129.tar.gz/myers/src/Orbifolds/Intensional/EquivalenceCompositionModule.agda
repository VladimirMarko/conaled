{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.EquivalenceCompositionModule where

open import Agda.Primitive using (Level; Set)
import Orbifolds.Intensional.Identity as O

-- Bind the complete carriers and three actual equivalences before exporting
-- their composite maps and inverse laws. No additional inverse law is assumed.
module On {a b c d : Level}
    (W : Set a) (X : Set b) (Y : Set c) (Z : Set d)
    (first : O.Equiv W X) (middle : O.Equiv X Y) (last : O.Equiv Y Z) where

  equivalence : O.Equiv W Z
  equivalence = O.compEquiv first (O.compEquiv middle last)

  lambda : W → Z
  lambda = O.forward equivalence

  apply : Z → W
  apply = O.backward equivalence

  beta : (w : W) → apply (lambda w) O.≡ w
  beta w = O.retraction equivalence w

  eta : (z : Z) → lambda (apply z) O.≡ z
  eta z = O.section equivalence z
