{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictRetaggedPathIndependence where

-- Normalize the exact returned strict path by proved strict equality
-- elimination. The two strict proofs need not compute to the same term.
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
open import Orbifolds.Coherent.StrictPathCoherence
  using (strict-path-proof-independent)

retagged-strict-path-independent : ∀ {ℓ} {B : Type ℓ} {x y z : B}
  (b : outer x ≡ˢ outer y) (e : outer y ≡ˢ outer z)
  (c : outer x ≡ˢ outer z)
  → strict-end-path {A = B} {x = x} {y = z}
      (λ i → strict-to-path b i) reflˢ e
    ≡ strict-to-path c
retagged-strict-path-independent reflˢ reflˢ c =
  strict-path-proof-independent reflˢ c
