{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedCellCanonicalPackage where

-- Construct the entire dependent canonical-cell input before a large
-- coherent diagram is substituted.  Only projections of this actual
-- packet are used later; no canonical triangle or preservation law is
-- assumed.  The outer record can store strict construction equalities,
-- while every carrier and path remains in the original inner universe.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function using (_∘_)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalQuotedAttachmentInterface as Attachments
import Orbifolds.Coherent.NaturalQuotedCellInterface as Original
import Orbifolds.Coherent.NaturalQuotedCellCanonicalNaturality as Sealed
import Orbifolds.Coherent.NaturalQuotedCellCanonical as Canonical
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.CubicalShells as CS

module Construction {ℓ : Level} (E : StrictCubicalExtensionality ℓ) (n : Dim)
    (A B Index : Type ℓ) (SourceCoefficient TargetCoefficient : Index → Type ℓ)
    (source-boundary : (c : Index) → CS.Shell (toNat n) (SourceCoefficient c → A))
    (target-boundary : (c : Index) → CS.Shell (toNat n) (TargetCoefficient c → B))
    (base-map : A → B) (coefficient-map : (c : Index) → SourceCoefficient c → TargetCoefficient c)
    (boundary-path : (c : Index)
      → Shells.Action.map-shell E n (λ v → base-map ∘ v) (source-boundary c)
        ≡ Shells.Action.map-shell E n (λ v → v ∘ coefficient-map c) (target-boundary c)) where
  module Source = Attachments.Attachment E n A Index SourceCoefficient source-boundary
    using (Realize; Cocone; module Target)
  module Target = Attachments.Attachment E n B Index TargetCoefficient target-boundary
    using (Realize; Cocone; canonical-cocone)
  module At (Y : Type ℓ) = Original.Map.TargetSpace E n A B Index
    SourceCoefficient TargetCoefficient source-boundary target-boundary
    base-map coefficient-map boundary-path Y using (pullback)
  module Naturality = Sealed.Naturality E n A B Index
    SourceCoefficient TargetCoefficient source-boundary target-boundary
    base-map coefficient-map boundary-path
    using (canonical-naturality; construction; original-computation)
  module Chosen = Canonical.Canonical E n B Index TargetCoefficient target-boundary
    using (cocone; constructed)

  record Inputs : SSet (ℓ-suc ℓ) where
    field
      Y : Type ℓ
      h : Source.Realize → Y
      s t : Target.Cocone Y
      p p₀ : Source.Target.restrict Y h ≡ At.pullback Y s
      p-constructed : outer p ≡ˢ outer p₀
      base-path : Source.Target.restrict Y h .fst ≡ At.pullback Y s .fst
      p-first : cong fst p ≡ base-path
      r : outer t ≡ˢ outer s

  -- Data projections stay transparent.  The proof values are precisely
  -- the existing sealed naturality and opaque-cocone construction laws.
  canonical : Inputs
  canonical = record
    { Y = Target.Realize
    ; h = Original.Map.induced E n A B Index SourceCoefficient TargetCoefficient
        source-boundary target-boundary base-map coefficient-map boundary-path
    ; s = Target.canonical-cocone
    ; t = Chosen.cocone
    ; p = Naturality.canonical-naturality
    ; p₀ = Original.Map.canonical-naturality E n A B Index
        SourceCoefficient TargetCoefficient source-boundary target-boundary
        base-map coefficient-map boundary-path
    ; p-constructed = Naturality.construction
    ; base-path = refl
    ; p-first = Naturality.original-computation
    ; r = Chosen.constructed
    }
