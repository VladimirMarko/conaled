{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSeparation where

-- Finitely many distinct points admit disjoint open refinements of any
-- supplied neighborhoods in a space with chosen Hausdorff separation.
-- Only finite-index equality is decided; no general excluded-middle
-- parameter is needed for this shrinking construction.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat; zero; suc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code)
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin; fzero; fsuc)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Empty; empty-elim; Not; Subset; member; member-prop; Included
  ; full; intersection; OpenFragment; IsOpen; open-full; open-intersection
  ; PairwiseDisjoint; Hom; FiniteFiberNeighborhoods )
open import Orbifolds.Intensional.CompactSeparation using
  ( _⊎_; inl; inr; SeparatedNeighborhoods; ChosenHausdorff )

private variable ℓ : Level

fsuc-injective : {n : Nat} {i j : Fin {ℓ} n} → fsuc i ≡ fsuc j → i ≡ j
fsuc-injective refl = refl

fin-equality : {n : Nat} (i j : Fin {ℓ} n) → (i ≡ j) ⊎ Not (i ≡ j)
fin-equality fzero fzero = inl refl
fin-equality fzero (fsuc j) = inr (λ ())
fin-equality (fsuc i) fzero = inr (λ ())
fin-equality (fsuc i) (fsuc j) with fin-equality i j
... | inl equal = inl (cong fsuc equal)
... | inr different = inr (λ equal → different (fsuc-injective equal))

fin-meet : {A : Set ℓ} (n : Nat) → (Fin {ℓ} n → Subset A) → Subset A
fin-meet zero U = full
fin-meet (suc n) U = intersection (U fzero) (fin-meet n (λ i → U (fsuc i)))

fin-meet-open : {A : Set ℓ} (O : OpenFragment A)
  → (n : Nat) (U : Fin {ℓ} n → Subset A)
  → ((i : Fin n) → IsOpen O (U i)) → IsOpen O (fin-meet n U)
fin-meet-open O zero U opens = open-full O
fin-meet-open O (suc n) U opens = open-intersection O (opens fzero)
  (fin-meet-open O n (λ i → U (fsuc i)) (λ i → opens (fsuc i)))

fin-meet-center : {A : Set ℓ} (n : Nat) (U : Fin {ℓ} n → Subset A)
  → (a : A) → ((i : Fin n) → member (U i) a) → member (fin-meet n U) a
fin-meet-center zero U a centers = tt
fin-meet-center (suc n) U a centers = centers fzero ,
  fin-meet-center n (λ i → U (fsuc i)) a (λ i → centers (fsuc i))

fin-meet-projection : {A : Set ℓ} (n : Nat) (U : Fin {ℓ} n → Subset A)
  → (a : A) (i : Fin n) → member (fin-meet n U) a → member (U i) a
fin-meet-projection zero U a () all
fin-meet-projection (suc n) U a fzero all = fst all
fin-meet-projection (suc n) U a (fsuc i) all =
  fin-meet-projection n (λ j → U (fsuc j)) a i (snd all)

record SeparatedRefinement {A : Set ℓ} {n : Nat}
    (O : OpenFragment A) (point : Fin {ℓ} n → A)
    (original : Fin {ℓ} n → Subset A) : Set (Code ℓ) where
  field
    refined : Fin {ℓ} n → Subset A
    refined-open : (i : Fin n) → IsOpen O (refined i)
    refined-center : (i : Fin n) → member (refined i) (point i)
    refined-included : (i : Fin n) → Included (refined i) (original i)
    refined-disjoint : PairwiseDisjoint refined

module Shrinking {ℓ : Level} {A : Set ℓ}
    (O : OpenFragment A) (separated : ChosenHausdorff O)
    (n : Nat) (point : Fin {ℓ} n → A)
    (point-injective : (i j : Fin n) → point i ≡ point j → i ≡ j)
    (original : Fin {ℓ} n → Subset A)
    (original-open : (i : Fin n) → IsOpen O (original i))
    (original-center : (i : Fin n) → member (original i) (point i)) where

  -- The diagonal case uses full subsets. In the off-diagonal case both
  -- sides come from the same selected separation, so opposite choices
  -- of a separator cannot invalidate pairwise disjointness.
  record PairPatch (i j : Fin {ℓ} n) : Set (Code ℓ) where
    field
      L R : Subset A
      L-open : IsOpen O L
      R-open : IsOpen O R
      L-center : member L (point i)
      R-center : member R (point j)
      if-apart : Not (i ≡ j) → (a : A)
        → member L a → member R a → Empty {ℓ}

  pair-patch : (i j : Fin {ℓ} n) → PairPatch i j
  pair-patch i j with fin-equality i j
  ... | inl equal = record
    { L = full
    ; R = full
    ; L-open = open-full O
    ; R-open = open-full O
    ; L-center = tt
    ; R-center = tt
    ; if-apart = λ different a l r → different equal
    }
  ... | inr different = record
    { L = SeparatedNeighborhoods.near-left chosen
    ; R = SeparatedNeighborhoods.near-right chosen
    ; L-open = SeparatedNeighborhoods.left-open chosen
    ; R-open = SeparatedNeighborhoods.right-open chosen
    ; L-center = SeparatedNeighborhoods.left-center chosen
    ; R-center = SeparatedNeighborhoods.right-center chosen
    ; if-apart = λ _ → SeparatedNeighborhoods.disjoint chosen
    }
    where
    chosen : SeparatedNeighborhoods O (point i) (point j)
    chosen = separated (point i) (point j)
      (λ equal → different (point-injective i j equal))

  left-family : (i : Fin n) → Fin n → Subset A
  left-family i j = PairPatch.L (pair-patch i j)

  right-family : (i : Fin n) → Fin n → Subset A
  right-family i j = PairPatch.R (pair-patch j i)

  pieces : Fin n → Subset A
  pieces i = intersection (original i)
    (intersection (fin-meet n (left-family i)) (fin-meet n (right-family i)))

  pieces-open : (i : Fin n) → IsOpen O (pieces i)
  pieces-open i = open-intersection O (original-open i)
    (open-intersection O
      (fin-meet-open O n (left-family i) (λ j → PairPatch.L-open (pair-patch i j)))
      (fin-meet-open O n (right-family i) (λ j → PairPatch.R-open (pair-patch j i))))

  pieces-center : (i : Fin n) → member (pieces i) (point i)
  pieces-center i = original-center i ,
    (fin-meet-center n (left-family i) (point i)
       (λ j → PairPatch.L-center (pair-patch i j)) ,
     fin-meet-center n (right-family i) (point i)
       (λ j → PairPatch.R-center (pair-patch j i)))

  pieces-included : (i : Fin n) → Included (pieces i) (original i)
  pieces-included i a in-piece = fst in-piece

  pieces-disjoint : PairwiseDisjoint pieces
  pieces-disjoint a i j in-i in-j with fin-equality i j
  ... | inl equal = equal
  ... | inr different = empty-elim
    (PairPatch.if-apart (pair-patch i j) different a
      (fin-meet-projection n (left-family i) a j (fst (snd in-i)))
      (fin-meet-projection n (right-family j) a i (snd (snd in-j))))

  refinement : SeparatedRefinement O point original
  refinement = record
    { refined = pieces
    ; refined-open = pieces-open
    ; refined-center = pieces-center
    ; refined-included = pieces-included
    ; refined-disjoint = pieces-disjoint
    }

shrink-finite-neighborhoods : {A : Set ℓ} (O : OpenFragment A)
  → ChosenHausdorff O → (n : Nat) (point : Fin {ℓ} n → A)
  → ((i j : Fin n) → point i ≡ point j → i ≡ j)
  → (original : Fin {ℓ} n → Subset A)
  → ((i : Fin n) → IsOpen O (original i))
  → ((i : Fin n) → member (original i) (point i))
  → SeparatedRefinement O point original
shrink-finite-neighborhoods O separated n point injective original opens centers =
  Shrinking.refinement O separated n point injective original opens centers

record SourceNeighborhood {A X : Set ℓ} (O : OpenFragment A)
    (s : A → X) (a : A) : Set (Code ℓ) where
  field
    neighborhood : Subset A
    neighborhood-open : IsOpen O neighborhood
    neighborhood-center : member neighborhood a
    injective-source : (b c : A)
      → member neighborhood b → member neighborhood c → s b ≡ s c → b ≡ c

ChosenSourceNeighborhoods : {A X : Set ℓ}
  → OpenFragment A → (A → X) → Set (Code ℓ)
ChosenSourceNeighborhoods {A = A} O s = (a : A) → SourceNeighborhood O s a

-- The numbering is of the original anchor fiber, not of an assumed
-- neighborhood decomposition. Endpoint sethood lets an equality of
-- underlying arrows lift to equality in that fiber.
numbered-fiber-neighborhoods : {A X Y : Set ℓ}
  → (O : OpenFragment A) → ChosenHausdorff O
  → (s : A → X) (t : A → Y) → isSet X → isSet Y
  → (x : X) (y : Y) → (n : Nat)
  → (numbering : Equiv (Hom s t x y) (Fin {ℓ} n))
  → ((i : Fin n) → SourceNeighborhood O s (fst (backward numbering i)))
  → FiniteFiberNeighborhoods O s t x y
numbered-fiber-neighborhoods {ℓ} {A} {X} {Y} O separated s t setX setY
    x y n numbering local = record
    { piece-count = n
    ; piece = SeparatedRefinement.refined refined
    ; piece-open = SeparatedRefinement.refined-open refined
    ; pieces-disjoint = SeparatedRefinement.refined-disjoint refined
    ; source-injective = λ i a b in-a in-b same-source →
        SourceNeighborhood.injective-source (local i) a b
          (SeparatedRefinement.refined-included refined i a in-a)
          (SeparatedRefinement.refined-included refined i b in-b) same-source
    ; fiber-numbering = numbering
    ; center-in-piece = SeparatedRefinement.refined-center refined
    }
  where
  point : Fin {ℓ} n → A
  point i = fst (backward numbering i)

  endpoint-prop : (a : A) → isProp (Σ (s a ≡ x) (λ _ → t a ≡ y))
  endpoint-prop a = isPropΣ (setX (s a) x) (λ _ → setY (t a) y)

  point-injective : (i j : Fin n) → point i ≡ point j → i ≡ j
  point-injective i j same = sym (section numbering i)
    ∙ cong (forward numbering)
        (Σ-path-prop endpoint-prop
          {u = backward numbering i} {v = backward numbering j} same)
    ∙ section numbering j

  original : Fin {ℓ} n → Subset A
  original i = SourceNeighborhood.neighborhood (local i)

  refined : SeparatedRefinement O point original
  refined = shrink-finite-neighborhoods O separated n point point-injective original
    (λ i → SourceNeighborhood.neighborhood-open (local i))
    (λ i → SourceNeighborhood.neighborhood-center (local i))

chosen-local-fiber-neighborhoods : {A X Y : Set ℓ}
  → (O : OpenFragment A) → ChosenHausdorff O
  → (s : A → X) (t : A → Y) → isSet X → isSet Y
  → ChosenSourceNeighborhoods O s
  → (x : X) (y : Y) → (n : Nat)
  → Equiv (Hom s t x y) (Fin {ℓ} n)
  → FiniteFiberNeighborhoods O s t x y
chosen-local-fiber-neighborhoods O separated s t setX setY local x y n numbering =
  numbered-fiber-neighborhoods O separated s t setX setY x y n numbering
    (λ i → local (fst (backward numbering i)))
