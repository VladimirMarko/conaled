{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TriplePathInference where

-- Excluded elaboration helper. The candidate is an existing generic Triple
-- field applied to the same carriers, projection, and three actual paths.
-- Endpoint metavariables and the complete application are checked inside
-- restricted inference. No composite expression is elaborated as an input.

import Agda.Builtin.Reflection as R
open import Agda.Primitive using (SSet)
open import Agda.Builtin.Bool using (false)
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Sigma using (_,_)
open import Agda.Builtin.Unit using (⊤; tt)
open import Cubical.Foundations.Prelude using (Level)
open import Orbifolds.Coherent.StrictEnriched using (_≡ˢ_; reflˢ)
open import Orbifolds.Coherent.RestrictedPathInference
  using (visible-argument; hidden-argument; assign-frozen)

-- Strict construction equalities inhabit SSet, so their goal assignment
-- uses strict equality directly, rather than the inner-universe Outer box.
demand-strict-equality : ∀ {ℓ : Level} (A : SSet ℓ) (x y : A)
  → x ≡ˢ y → ⊤
demand-strict-equality A x .x reflˢ = tt

strict-demand-term : R.Term → R.Term → R.Term → R.Term
strict-demand-term goal hole candidate = R.def (quote demand-strict-equality)
  (hidden-argument R.unknown ∷ visible-argument goal ∷
   visible-argument hole ∷ visible-argument candidate ∷
   visible-argument (R.con (quote reflˢ) []) ∷ [])

assign-strict-frozen : List R.Name → R.Term → R.Term → R.TC ⊤
assign-strict-frozen names candidate hole =
  R.withNormalisation false
    (R.withReconstructed false
      (R.withReduceDefs (false , names)
        (R.noConstraints
          (R.bindTC (R.inferType hole) (λ goal →
            R.bindTC (R.inferType (strict-demand-term goal hole candidate))
              (λ _ → R.returnTC tt))))))

-- Triple.Pasting fields have two hidden levels, then the visible
-- parameters A, B, projection, x, y, z, w, p, q, r.
-- The four points are inferred from the actual path arguments.
triple-field-term : (entry : R.Name) (A B projection p q r : R.Term) → R.Term
triple-field-term entry A B projection p q r = R.def entry
  (hidden-argument R.unknown ∷ hidden-argument R.unknown ∷
   visible-argument A ∷ visible-argument B ∷ visible-argument projection ∷
   visible-argument R.unknown ∷ visible-argument R.unknown ∷
   visible-argument R.unknown ∷ visible-argument R.unknown ∷
   visible-argument p ∷ visible-argument q ∷ visible-argument r ∷ [])

macro
  inference-frozen-triple : (first-name second-name entry : R.Name)
    (A B projection p q r : R.Term) (hole : R.Term) → R.TC ⊤
  inference-frozen-triple first-name second-name entry A B projection p q r hole =
    assign-frozen (first-name ∷ second-name ∷ [])
      (triple-field-term entry A B projection p q r) hole

  inference-frozen-triple-strict : (first-name second-name entry : R.Name)
    (A B projection p q r : R.Term) (hole : R.Term) → R.TC ⊤
  inference-frozen-triple-strict first-name second-name entry A B projection p q r hole =
    assign-strict-frozen (first-name ∷ second-name ∷ [])
      (triple-field-term entry A B projection p q r) hole
