{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ContractibleSheafConstants where

-- A pointwise constant presheaf is a sheaf when its small carrier is
-- contractible. This constructs only these particular constant objects,
-- not a general constant-sheaf functor or a sheafification operation.
-- Their actual constant/global-section universal property identifies
-- the evaluation counit and compares it with any other representation.

open import Agda.Primitive using (Level; Set; lsuc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (InverseData)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (Empty)
open import Orbifolds.Intensional.CategoricalTransfer
open import Orbifolds.Intensional.SmallPresheaves
open import Orbifolds.Intensional.SmallSites using (GrothendieckTopology)
open import Orbifolds.Intensional.SmallSheaves using (Amalgamation; Sheaf)
open import Orbifolds.Intensional.PresheafConstants using (SmallSet)

module On {ℓ : Level} (ext : FunExt ℓ ℓ) (C : Category ℓ ℓ)
    (J : GrothendieckTopology C) where
  private module C = Category C
  module P = Theory ext C
  module SH = Orbifolds.Intensional.SmallSheaves.On ext C J
  module K = Orbifolds.Intensional.PresheafConstants.On ext C
  module H = Categorical SH.category
  open SmallSet
  open Presheaf
  open Nat
  open Sheaf
  open Amalgamation

  global-object : Sheaf J → SmallSet ℓ
  global-object F = K.gamma-object (underlying F)

  Globals : Sheaf J → Set ℓ
  Globals F = carrier (global-object F)

  globals-map : {F G : Sheaf J}
    → Nat (underlying F) (underlying G) → Globals F → Globals G
  globals-map {F} {G} = K.gamma-arrow {F = underlying F} {G = underlying G}

  constant-sheaf : (A : SmallSet ℓ) → isContr (carrier A) → Sheaf J
  underlying (constant-sheaf A contraction) = K.delta-object A
  glue (is-sheaf (constant-sheaf A contraction) X T cover α) = fst contraction
  restricts (is-sheaf (constant-sheaf A contraction) X T cover α) Y f p =
    snd contraction (component α Y (f , p))
  glue-unique (is-sheaf (constant-sheaf A contraction) X T cover α) a same =
    snd contraction a

  to-constant : (A : SmallSet ℓ) (contraction : isContr (carrier A)) (F : Sheaf J)
    → Nat (underlying F) (underlying (constant-sheaf A contraction))
  component (to-constant A contraction F) X x = fst contraction
  is-natural (to-constant A contraction F) X Y f y = refl

  constant-is-terminal : (A : SmallSet ℓ) (contraction : isContr (carrier A))
    → H.IsTerminal (constant-sheaf A contraction)
  constant-is-terminal A contraction F = to-constant A contraction F ,
    λ α → P.nat-ext (λ X x → snd contraction (component α X x))

  -- The source is now an actual sheaf. The underlying hom equivalence
  -- is exactly the accepted constant-presheaf/global-section equivalence.
  constant-hom-equivalence : (A : SmallSet ℓ) (contraction : isContr (carrier A))
    (F : Sheaf J) → Equiv
      (Nat (underlying (constant-sheaf A contraction)) (underlying F))
      (carrier A → Globals F)
  constant-hom-equivalence A contraction F = K.hom-equivalence A (underlying F)

  constant-hom-natural-target : (A : SmallSet ℓ) (contraction : isContr (carrier A))
    {F G : Sheaf J} (h : Nat (underlying F) (underlying G))
    (g : Nat (underlying (constant-sheaf A contraction)) (underlying F))
    → forward (constant-hom-equivalence A contraction G) (P.compose-nat h g)
      ≡ (λ a → globals-map {F = F} {G = G} h (forward (constant-hom-equivalence A contraction F) g a))
  constant-hom-natural-target A contraction {F} {G} h g =
    Adjunction.natural-target K.adjunction {X = A} {Y = underlying F} {Z = underlying G} h g

  flat-at : (F : Sheaf J) → isContr (Globals F) → Sheaf J
  flat-at F points = constant-sheaf (global-object F) points

  counit : (F : Sheaf J) (points : isContr (Globals F))
    → Nat (underlying (flat-at F points)) (underlying F)
  counit F points = K.counit (underlying F)

  counit-underlying : (F : Sheaf J) (points : isContr (Globals F))
    → counit F points ≡ K.counit (underlying F)
  counit-underlying F points = refl

  counit-component : (F : Sheaf J) (points : isContr (Globals F))
    (X : C.Obj) (s : Globals F)
    → component (counit F points) X s ≡ component s X tt
  counit-component F points X s = refl

  counit-transpose-identity : (F : Sheaf J) (points : isContr (Globals F))
    → forward (constant-hom-equivalence (global-object F) points F) (counit F points)
      ≡ (λ s → s)
  counit-transpose-identity F points =
    K.transpose-untranspose {A = global-object F} {F = underlying F} (λ s → s)

  counit-not-iso : (F : Sheaf J) (points : isContr (Globals F))
    → (H.IsTerminal F → Empty {ℓ})
    → IsIso SH.category {X = flat-at F points} {Y = F} (counit F points) → Empty {ℓ}
  counit-not-iso F points nonterminal invertible = nonterminal
    (H.terminal-along-iso
      (arrowIso {C = SH.category} {X = flat-at F points} {Y = F} (counit F points) invertible)
      (constant-is-terminal (global-object F) points))

  -- A local universal property at one specified small set. This is
  -- comparison data for another interpretation, not an assertion that
  -- constant objects have been constructed at every small set.
  record RepresentsConstants (A : SmallSet ℓ) : Set (lsuc ℓ) where
    field
      object : Sheaf J
      hom-equivalence : (F : Sheaf J)
        → Equiv (Nat (underlying object) (underlying F)) (carrier A → Globals F)
      natural-target : {F G : Sheaf J} (h : Nat (underlying F) (underlying G))
        (g : Nat (underlying object) (underlying F))
        → forward (hom-equivalence G) (P.compose-nat h g)
          ≡ (λ a → globals-map {F = F} {G = G} h (forward (hom-equivalence F) g a))

  constant-representation : (A : SmallSet ℓ) (contraction : isContr (carrier A))
    → RepresentsConstants A
  RepresentsConstants.object (constant-representation A contraction) = constant-sheaf A contraction
  RepresentsConstants.hom-equivalence (constant-representation A contraction) =
    constant-hom-equivalence A contraction
  RepresentsConstants.natural-target (constant-representation A contraction) {F} {G} h g =
    constant-hom-natural-target A contraction {F = F} {G = G} h g

  module Comparison (A : SmallSet ℓ) (contraction : isContr (carrier A))
      (representation : RepresentsConstants A) where
    private
      module Q = RepresentsConstants representation
      Δ : Sheaf J
      Δ = constant-sheaf A contraction

    generator : carrier A → Globals Q.object
    generator = forward (Q.hom-equivalence Q.object) (P.identity-nat (underlying Q.object))

    comparison : Nat (underlying Δ) (underlying Q.object)
    comparison = backward (constant-hom-equivalence A contraction Q.object) generator

    comparison-law : (F : Sheaf J) (h : Nat (underlying Q.object) (underlying F))
      → forward (constant-hom-equivalence A contraction F) (P.compose-nat h comparison)
        ≡ forward (Q.hom-equivalence F) h
    comparison-law F h =
      constant-hom-natural-target A contraction {F = Q.object} {G = F} h comparison
        ∙ cong (λ z a → globals-map {F = Q.object} {G = F} h (z a))
            (section (constant-hom-equivalence A contraction Q.object) generator)
        ∙ sym (Q.natural-target {F = Q.object} {G = F} h (P.identity-nat (underlying Q.object)))
        ∙ cong (forward (Q.hom-equivalence F))
            (Category.identity-right SH.category {X = Q.object} {Y = F} h)

    hom-comparison : (F : Sheaf J)
      → Equiv (Nat (underlying Q.object) (underlying F)) (Nat (underlying Δ) (underlying F))
    hom-comparison F = compEquiv (Q.hom-equivalence F)
      (invEquiv (constant-hom-equivalence A contraction F))

    actual-precomposition : (F : Sheaf J) (h : Nat (underlying Q.object) (underlying F))
      → forward (hom-comparison F) h ≡ P.compose-nat h comparison
    actual-precomposition F h =
      cong (backward (constant-hom-equivalence A contraction F)) (sym (comparison-law F h))
        ∙ retraction (constant-hom-equivalence A contraction F) (P.compose-nat h comparison)

    precomposition-inverse : (F : Sheaf J)
      → InverseData (λ (h : Nat (underlying Q.object) (underlying F)) → P.compose-nat h comparison)
    precomposition-inverse F = inverse-by-homotopy (hom-comparison F)
      (λ h → P.compose-nat h comparison) (actual-precomposition F)

    comparison-inverse : Nat (underlying Q.object) (underlying Δ)
    comparison-inverse = InverseData.inverse (precomposition-inverse Δ) (P.identity-nat (underlying Δ))

    comparison-left : P.compose-nat comparison-inverse comparison ≡ P.identity-nat (underlying Δ)
    comparison-left = InverseData.right-law (precomposition-inverse Δ) (P.identity-nat (underlying Δ))

    comparison-is-iso : IsIso SH.category {X = Δ} {Y = Q.object} comparison
    IsIso.inverse-arrow comparison-is-iso = comparison-inverse
    IsIso.left-inverse comparison-is-iso = comparison-left
    IsIso.right-inverse comparison-is-iso = inverse-injective (precomposition-inverse Q.object)
      (Category.associative SH.category {W = Δ} {X = Q.object} {Y = Δ} {Z = Q.object}
          comparison comparison-inverse comparison
        ∙ cong (P.compose-nat comparison) comparison-left
        ∙ Category.identity-right SH.category {X = Δ} {Y = Q.object} comparison
        ∙ sym (Category.identity-left SH.category {X = Δ} {Y = Q.object} comparison))

    comparison-iso : Iso SH.category Δ Q.object
    comparison-iso = arrowIso {C = SH.category} {X = Δ} {Y = Q.object} comparison comparison-is-iso

    -- This equation compares the maps selected by the two universal
    -- properties, not merely their source objects up to an arbitrary iso.
    comparison-untranspose : (F : Sheaf J) (u : carrier A → Globals F)
      → P.compose-nat (backward (Q.hom-equivalence F) u) comparison
        ≡ backward (constant-hom-equivalence A contraction F) u
    comparison-untranspose F u =
      sym (retraction (constant-hom-equivalence A contraction F)
        (P.compose-nat (backward (Q.hom-equivalence F) u) comparison))
        ∙ cong (backward (constant-hom-equivalence A contraction F))
            (comparison-law F (backward (Q.hom-equivalence F) u)
              ∙ section (Q.hom-equivalence F) u)

  represented-counit : (F : Sheaf J) (representation : RepresentsConstants (global-object F))
    → Nat (underlying (RepresentsConstants.object representation)) (underlying F)
  represented-counit F representation =
    backward (RepresentsConstants.hom-equivalence representation F) (λ s → s)

  represented-counit-comparison : (F : Sheaf J) (points : isContr (Globals F))
    (representation : RepresentsConstants (global-object F))
    → P.compose-nat (represented-counit F representation)
        (Comparison.comparison (global-object F) points representation)
      ≡ counit F points
  represented-counit-comparison F points representation =
    Comparison.comparison-untranspose (global-object F) points representation F (λ s → s)

  represented-counit-not-iso : (F : Sheaf J) (points : isContr (Globals F))
    → (H.IsTerminal F → Empty {ℓ})
    → (representation : RepresentsConstants (global-object F))
    → IsIso SH.category {X = RepresentsConstants.object representation} {Y = F}
        (represented-counit F representation) → Empty {ℓ}
  represented-counit-not-iso F points nonterminal representation invertible = nonterminal
    (H.terminal-along-iso
      (arrowIso {C = SH.category} {X = RepresentsConstants.object representation} {Y = F}
        (represented-counit F representation) invertible)
      (H.terminal-along-iso (Comparison.comparison-iso (global-object F) points representation)
        (constant-is-terminal (global-object F) points)))
