{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.GlobalKockLawvereCalculus where

-- The exact first-order KL equivalence, and hence the full derivative
-- theorem, follow from the global Weil-algebra evaluation axiom.
-- This connects the previously checked calculus to Postulate J.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
import Orbifolds.WeilAlgebras as WA
import Orbifolds.FirstOrderKockLawvere as KL
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.SyntheticDifferential as SD

module Ring {ℓ : Level} (R : CommRing ℓ) (global-KL : WA.Weil.KockLawvere R) where
  open CommRingStr (R .snd)
  module First = SD.FirstOrder R
  module Disks = IL.Ring R
  module Coordinates = KL.Ring.Dimension R global-KL 1

  first-index : (i : FD.Fin 1) → FD.zero ≡ i
  first-index = FD.isContrFin1 .snd

  coefficient-equivalence : (R .fst × R .fst) ≃ Coordinates.Jet.Jet
  coefficient-equivalence = isoToEquiv (iso
    (λ (a , b) → a , λ _ → b)
    (λ (a , v) → a , v FD.zero)
    (λ (a , v) → cong (a ,_) (funExt λ i → cong v (first-index i)))
    (λ _ → refl))

  to-disk : First.D → Disks.D 1
  to-disk (ε , square-zero) = (λ _ → ε) , λ _ _ → square-zero

  from-disk : Disks.D 1 → First.D
  from-disk d = d .fst FD.zero , d .snd FD.zero FD.zero

  disk-equivalence : First.D ≃ Disks.D 1
  disk-equivalence = isoToEquiv (iso to-disk from-disk
    (λ d → Σ≡Prop Disks.pairwise-zero-isProp
      (funExt λ i → cong (d .fst) (first-index i)))
    (λ d → Σ≡Prop (λ ε → is-set (ε · ε) 0r) refl))

  actual-affine-equivalence : (R .fst × R .fst) ≃ (First.D → R .fst)
  actual-affine-equivalence = coefficient-equivalence
    ∙ₑ Coordinates.affine-equivalence
    ∙ₑ preCompEquiv disk-equivalence

  affine-comparison : actual-affine-equivalence .fst ≡ First.affine
  affine-comparison = funExt λ (a , b) → funExt λ ε →
    cong (a +_) (+IdR (b · ε .fst))

  first-order-KL : First.FirstOrderKL
  first-order-KL = subst isEquiv affine-comparison (actual-affine-equivalence .snd)

  open First.Consequences first-order-KL public
