{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispFlat where

-- The uniform ambient crisp Flat-induction rule of Shulman,
-- arXiv:1509.07584v3, Lemma 5.1.  Unlike ordinary native Flat elimination,
-- its motive may depend on a native-crisp Flat value.  This structural
-- rule is an explicit parameter; idempotence is derived below.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Orbifolds.Crisp

CrispFlatInduction : {@♭ ℓ : Level} → Type (ℓ-suc ℓ)
CrispFlatInduction {ℓ} = (@♭ A : Type ℓ)
  (@♭ P : (@♭ u : Flat A) → Type ℓ)
  (@♭ d : (@♭ a : A) → P (box a))
  (@♭ u : Flat A) → P u

CrispFlatComputation : {@♭ ℓ : Level}
  → (@♭ induce : CrispFlatInduction {ℓ}) → Type (ℓ-suc ℓ)
CrispFlatComputation {ℓ} induce = (@♭ A : Type ℓ)
  (@♭ P : (@♭ u : Flat A) → Type ℓ)
  (@♭ d : (@♭ a : A) → P (box a))
  (@♭ a : A) → induce A P d (box a) ≡ d a

-- Both the eliminator and its computation witness are native-crisp.
-- They are separate parameters because Agda cannot construct an ordinary
-- record whose dependent beta field demands a crisp eliminator field.
module Theory {@♭ ℓ : Level}
  (@♭ crisp-flat-ind : CrispFlatInduction {ℓ})
  (@♭ crisp-flat-ind-box : CrispFlatComputation crisp-flat-ind) where

  crisp-duplicate-eta : {@♭ A : Type ℓ} (@♭ u : Flat A)
    → duplicate u ≡ box u
  crisp-duplicate-eta {A} = crisp-flat-ind A
    (λ u → duplicate u ≡ box u) (λ a → refl)

  crisp-duplicate-eta-box : {@♭ A : Type ℓ} (@♭ a : A)
    → crisp-duplicate-eta (box a) ≡ refl
  crisp-duplicate-eta-box {A} = crisp-flat-ind-box A
    (λ u → duplicate u ≡ box u) (λ a → refl)

  -- The outer value is ordinary, so this match is native and safe.
  -- Its constructor witness is crisp; that inner case uses the explicit
  -- structural principle, not hidden native flat splitting.
  duplicate-counit : {@♭ A : Type ℓ} (u : Flat (Flat A))
    → duplicate (counit u) ≡ u
  duplicate-counit (box u) = crisp-duplicate-eta u

  flat-idempotent-equivalence : {@♭ A : Type ℓ}
    → Flat (Flat A) ≃ Flat A
  flat-idempotent-equivalence = isoToEquiv
    (iso counit duplicate counit-duplicate duplicate-counit)

  flat-is-discrete : {@♭ A : Type ℓ} → CrisplyDiscrete (Flat A)
  flat-is-discrete = flat-idempotent-equivalence .snd
