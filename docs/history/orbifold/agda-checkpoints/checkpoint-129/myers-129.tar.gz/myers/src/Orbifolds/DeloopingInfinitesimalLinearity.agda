{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DeloopingInfinitesimalLinearity where

-- The homotopical content of Theorem 5.5.3 for an actual pointed
-- infinitesimal-axis diagram.  Its specialization to D(n) is separate.
-- The canonical comparison and its commuting path are part of the
-- statement; the connectedness of all three mapping spaces is derived
-- from mere tininess and the already checked Appendix A.0.8 theorem.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Functions.FunExtEquiv
open import Cubical.Functions.Surjection
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as CP
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyDeloopings as TD
import Orbifolds.ConnectedPullbacks as PB
import Orbifolds.MicrolinearityLimits as ML
import Orbifolds.Quotients as Q

record PointedAxes (ℓ : Level) : Type (ℓ-suc ℓ) where
  field
    leftTest rightTest unionTest : Type ℓ
    leftOrigin : leftTest
    rightOrigin : rightTest
    leftInclusion : leftTest → unionTest
    rightInclusion : rightTest → unionTest
    originsAgree : leftInclusion leftOrigin ≡ rightInclusion rightOrigin

module Mapping {ℓ : Level} (axes : PointedAxes ℓ) where
  open PointedAxes axes

  evaluate-left : (X : Type ℓ) → (leftTest → X) → X
  evaluate-left X h = h leftOrigin

  evaluate-right : (X : Type ℓ) → (rightTest → X) → X
  evaluate-right X h = h rightOrigin

  compatibility : (X : Type ℓ) (h : unionTest → X)
    → evaluate-left X (h ∘ leftInclusion)
      ≡ evaluate-right X (h ∘ rightInclusion)
  compatibility X h = cong h originsAgree

  comparison : (X : Type ℓ) → (unionTest → X)
    → ML.Pullback (evaluate-left X) (evaluate-right X)
  comparison X h = (h ∘ leftInclusion , h ∘ rightInclusion) , compatibility X h

  IsLinear : Type ℓ → Type ℓ
  IsLinear X = isEquiv (comparison X)

  module Loops (X : Type ℓ) (x : X) where
    base : ML.Pullback (evaluate-left X) (evaluate-right X)
    base = comparison X (const x)

    -- Transposing both path coordinates gives the actual loop-pullback
    -- equivalence at the constant cocone.  No path truncation is used.
    pullback-loops : (base ≡ base)
      ≃ ML.Pullback (evaluate-left (x ≡ x)) (evaluate-right (x ≡ x))
    pullback-loops = isoToEquiv (iso to from (λ _ → refl) (λ _ → refl))
      where
      to : (base ≡ base)
        → ML.Pullback (evaluate-left (x ≡ x)) (evaluate-right (x ≡ x))
      to p = ((λ d i → p i .fst .fst d) , (λ d i → p i .fst .snd d)) ,
        (λ j i → p i .snd j)

      from : ML.Pullback (evaluate-left (x ≡ x)) (evaluate-right (x ≡ x))
        → base ≡ base
      from ((u , v) , p) i = ((λ d → u d i) , (λ d → v d i)) , (λ j → p j i)

    loop-comparison : IsLinear (x ≡ x)
      → ((const x :> (unionTest → X)) ≡ const x) ≃ (base ≡ base)
    loop-comparison linear = compEquiv (invEquiv funExtEquiv)
      (compEquiv (comparison (x ≡ x) , linear) (invEquiv pullback-loops))

    loop-comparison-coherence : (linear : IsLinear (x ≡ x))
      → equivFun (loop-comparison linear) ≡ cong (comparison X)
    loop-comparison-coherence linear = refl

    loop-comparison-isEquiv : IsLinear (x ≡ x)
      → isEquiv (cong (comparison X) :>
        (((const x :> (unionTest → X)) ≡ const x) → base ≡ base))
    loop-comparison-isEquiv linear =
      subst isEquiv (loop-comparison-coherence linear) (snd (loop-comparison linear))

module Context {@♭ ℓ : Level}
    (@♭ rules : CI.CrispIdentityInduction {ℓ})
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) where
  module Propositions = CP.Context R r₀
  open Propositions using (RealFlat)

  module Diagram (@♭ axes : PointedAxes ℓ) (@♭ G : Q.Delooping ℓ) where
    open PointedAxes axes
    module Maps = Mapping axes
    module Left = TD.Context rules identity-zero flat-zero flat-zero-computation
      R r₀ leftTest
    module Right = TD.Context rules identity-zero flat-zero flat-zero-computation
      R r₀ rightTest
    module Union = TD.Context rules identity-zero flat-zero flat-zero-computation
      R r₀ unionTest

    module Square = PB.Square (const (Q.point G))
      (_∘ leftInclusion) (_∘ rightInclusion)
      (Maps.evaluate-left (Q.BG G)) (Maps.evaluate-right (Q.BG G))
      (Maps.compatibility (Q.BG G))

    evaluation-loop-surjective : isSurjection Square.Target.loop-right
    evaluation-loop-surjective p = PT.∣ (λ i _ → p i) , refl ∣₁

    preserves-linearity : RealFlat
      → TT.External.Tiny leftTest → TT.External.Tiny rightTest
      → TT.External.Tiny unionTest
      → Maps.IsLinear (Q.Loop G) → Maps.IsLinear (Q.BG G)
    preserves-linearity real-flat tiny-left tiny-right tiny-union linear =
      Square.Connected.from-loop-equivalence
        (Q.connected (Union.HigherGroup.power-higher-group G real-flat tiny-union))
        (Q.connected (Left.HigherGroup.power-higher-group G real-flat tiny-left))
        (Q.connected (Right.HigherGroup.power-higher-group G real-flat tiny-right))
        evaluation-loop-surjective
        (Maps.Loops.loop-comparison-isEquiv (Q.BG G) (Q.point G) linear)
