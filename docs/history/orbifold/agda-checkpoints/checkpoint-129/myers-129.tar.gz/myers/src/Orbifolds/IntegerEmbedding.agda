{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegerEmbedding where

-- The literal coefficient map Z -> R is injective from Postulate O.
-- No global excluded middle or discreteness of the smooth reals is used.
-- Coordinate translations are consequently free in every dimension.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Int using (ℤ; pos; negsuc)
import Cubical.Data.Empty as Empty
open import Cubical.Functions.Embedding
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Morphisms using (IsGroupHom; isInjective; isMono)
open import Cubical.Algebra.Group.MorphismProperties using (isInjective→isMono)
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO

module Ordered {ℓ : Level} (R : CommRing ℓ)
    (order : SF.RingContext.StrictOrder R) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  open IC.Ring R public using (integer; additive-homomorphism; ring-homomorphism)
  module Additive = GroupTheory (IC.Ring.additive-group R)
  module Order = SO.OrderTheory R order

  positive-integer : (n : ℕ) → 0r < integer (pos (suc n))
  positive-integer zero = subst (0r <_) (sym (+IdR 1r)) zero<one
  positive-integer (suc n) = positive-add zero<one (positive-integer n)

  integer-kernel-trivial : isInjective additive-homomorphism
  integer-kernel-trivial (pos zero) p = refl
  integer-kernel-trivial (pos (suc n)) p =
    Empty.rec (Order.positiveNonzero (positive-integer n) p)
  integer-kernel-trivial (negsuc n) p =
    Empty.rec (Order.positiveNonzero (positive-integer n)
      (IsGroupHom.presinv (additive-homomorphism .snd) (negsuc n)
        ∙ cong (-_) p ∙ Additive.inv1g))

  integer-injective : isMono additive-homomorphism
  integer-injective = isInjective→isMono additive-homomorphism integer-kernel-trivial

  integer-embedding : isEmbedding integer
  integer-embedding = injEmbedding is-set integer-injective

  module Coordinates {ℓi : Level} (I : Type ℓi) where
    integer-vector : (I → ℤ) → I → R .fst
    integer-vector z i = integer (z i)

    integer-vector-injective : {z w : I → ℤ}
      → integer-vector z ≡ integer-vector w → z ≡ w
    integer-vector-injective p = funExt λ i → integer-injective (funExt⁻ p i)

    integer-vector-embedding : isEmbedding integer-vector
    integer-vector-embedding = injEmbedding (isSetΠ λ _ → is-set) integer-vector-injective

    translate : (I → ℤ) → (I → R .fst) → I → R .fst
    translate z x i = integer (z i) + x i

    translate-zero : (x : I → R .fst) → translate (λ _ → pos zero) x ≡ x
    translate-zero x = funExt λ i → +IdL (x i)

    translation-injective : (x : I → R .fst) {z w : I → ℤ}
      → translate z x ≡ translate w x → z ≡ w
    translation-injective x p = funExt λ i → integer-injective
      (Additive.·CancelR (x i) (funExt⁻ p i))

    translation-free : (z : I → ℤ) (x : I → R .fst)
      → translate z x ≡ x → z ≡ (λ _ → pos zero)
    translation-free z x p = translation-injective x (p ∙ sym (translate-zero x))
