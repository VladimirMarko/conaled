{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

module Orbifolds.CubicUnitPerturbation where

-- An actual finite-series inverse over an arbitrary commutative ring.
-- The supplied unit and cubic-zero equation are explicit algebraic data.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma using (Σ; _,_; fst; snd)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SyntheticField as SF

module Construction {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)
  open SF.RingContext R using (Invertible)

  Carrier : Type ℓ
  Carrier = R .fst

  cube : Carrier → Carrier
  cube x = x · (x · x)

  series : Carrier → Carrier
  series n = (1r - n) + n · n

  abstract
    cube-product : (x y : Carrier) → cube (x · y) ≡ cube x · cube y
    cube-product x y = solve! R

    series-identity : (n : Carrier)
      → (1r + n) · series n ≡ 1r + cube n
    series-identity n = solve! R

  module Perturb (u z : Carrier) (unit : Invertible u) (nil : cube z ≡ 0r) where
    inverse-u : Carrier
    inverse-u = unit .fst

    normalized : Carrier
    normalized = inverse-u · z

    normalized-cube-zero : cube normalized ≡ 0r
    normalized-cube-zero = cube-product inverse-u z
      ∙ cong (cube inverse-u ·_) nil
      ∙ 0RightAnnihilates (cube inverse-u)

    inverse : Carrier
    inverse = series normalized · inverse-u

    abstract
      distribute : (u + z) · inverse-u ≡ u · inverse-u + normalized
      distribute = solve! R

      reassociate : (u + z) · inverse
        ≡ ((u + z) · inverse-u) · series normalized
      reassociate = solve! R

    linear-factor : (u + z) · inverse-u ≡ 1r + normalized
    linear-factor = distribute ∙ cong (_+ normalized) (unit .snd)

    inverse-law : (u + z) · inverse ≡ 1r
    inverse-law = reassociate
      ∙ cong (_· series normalized) linear-factor
      ∙ series-identity normalized
      ∙ cong (1r +_) normalized-cube-zero
      ∙ +IdR 1r

    perturbed-unit : Invertible (u + z)
    perturbed-unit = inverse , inverse-law

  unit-plus-cubic-nilpotent : (u z : Carrier)
    → Invertible u → cube z ≡ 0r → Invertible (u + z)
  unit-plus-cubic-nilpotent u z unit nil = Perturb.perturbed-unit u z unit nil
