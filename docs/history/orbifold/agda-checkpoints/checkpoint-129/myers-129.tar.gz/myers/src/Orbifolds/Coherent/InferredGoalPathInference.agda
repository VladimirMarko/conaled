{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.InferredGoalPathInference where

-- Infer the carrier from the existing goal metavariable. Ordinary argument
-- checking uses that metavariable's type without producing and rechecking
-- a quoted copy. The candidate and reflexivity proof are checked normally,
-- with every new constraint required to close.

import Agda.Builtin.Reflection as R
open import Agda.Builtin.Bool using (false)
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Sigma using (_,_)
open import Agda.Builtin.Unit using (⊤; tt)
open import Orbifolds.Coherent.RestrictedPathInference using (demand-term)

assign-frozen-inferred : List R.Name → R.Term → R.Term → R.TC ⊤
assign-frozen-inferred names candidate hole =
  R.withNormalisation false
    (R.withReconstructed false
      (R.withReduceDefs (false , names)
        (R.noConstraints
          (R.bindTC
            (R.inferType (demand-term R.unknown hole candidate))
            (λ _ → R.returnTC tt)))))
