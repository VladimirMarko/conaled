{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitCells where

-- A small typed interface to the actual constructed bar presentation.
-- The cell and boundary spaces are displayed explicitly. Qualified calls
-- retain all definitional computations without copying a large complete
-- construction namespace into each reflected or powered instantiation.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Sequence using (Sequence)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentColimitStages as Stages
import Orbifolds.Coherent.HomotopyCoherentColimitPresentation as Presentation
import Orbifolds.CubicalShellSpheres as Spheres
import Orbifolds.CellularPresentations as CP
import Cubical.HITs.Pushout as PO
import Cubical.HITs.SequentialColimit as SC

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where

  Representation : Dim → Type (ℓ-suc ℓ)
  Representation = Represented.Induction.Represented C D E F

  Space : {n : Dim} → Representation n → Type ℓ
  Space = Represented.Induction.Represented.Space

  initial : Representation ozero
  initial = Represented.Induction.initial C D E F

  Initial : Type ℓ
  Initial = Space initial

  Index : Dim → Type ℓ
  Index n = Orbifolds.Coherent.OuterBarChains.Chains.Index (Opposite C) (osuc n)

  Cells : Dim → Type ℓ
  Cells n = Σ (Index n) (λ c → HC.ForCategory.Diagram.Value D (c .fst))

  Boundary : Dim → Type ℓ
  Boundary n = Cells n × Spheres.SphereBoundary (toNat (osuc n))

  attach : (n : Dim) (previous : Representation n) → Boundary n → Space previous
  attach n previous = Stages.Construction.Step.Cell.attach C D E F n previous

  boundary : (n : Dim) → Boundary n → Cells n
  boundary n = fst

  Next : (n : Dim) → Representation n → Type ℓ
  Next n previous = PO.Pushout (attach n previous) (boundary n)

  next : (n : Dim) → Representation n → Representation (osuc n)
  next n previous = Stages.Construction.Step.next C D E F n previous

  next-space : (n : Dim) (previous : Representation n)
    → outer (Space (next n previous)) ≡ˢ outer (Next n previous)
  next-space n previous = reflˢ

  presentation : (n : Dim) (previous : Representation n) → CP.Presentation (Space previous)
  presentation n previous = Presentation.Construction.presentation C D E F n previous

  bar-presentation : CP.Presentation Initial
  bar-presentation = presentation ozero initial

  state : ℕ → Σ[ A ∈ Type ℓ ] CP.Presentation A
  state = CP.Realization.state Initial bar-presentation

  Stage : ℕ → Type ℓ
  Stage n = state n .fst

  stages : Sequence ℓ
  stages = CP.Realization.stages Initial bar-presentation

  Colimit : Type ℓ
  Colimit = SC.SeqColim stages

  colimit-computation : outer Colimit ≡ˢ outer (Presentation.Construction.Colimit C D E F)
  colimit-computation = reflˢ
