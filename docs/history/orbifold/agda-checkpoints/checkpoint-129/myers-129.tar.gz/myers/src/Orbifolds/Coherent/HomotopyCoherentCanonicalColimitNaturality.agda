{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCanonicalColimitNaturality where

-- All mapping-space squares for the actual canonical bar map follow
-- from its canonical cocone triangle and the independently derived
-- full target/source naturality theorems.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Foundations.Equiv
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentMappingDiagrams as Mapping
import Orbifolds.Coherent.HomotopyCoherentConeMaps as ConeMaps
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as Canonical
import Orbifolds.Coherent.HomotopyCoherentColimitTargetNaturality as TargetNaturality
import Orbifolds.Coherent.HomotopyCoherentFullRestrictionNaturality as RestrictionNaturality
import Orbifolds.MappingSquareEquivalences as Equivalences

module Naturality {ℓ : Level} (C : Category ℓ ℓ) (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module Map = Canonical.Map C D G α E F
    using (induced; canonical-triangle; module Source; module Target)

  post-source : {Y Z : Type ℓ} → (Y → Z)
    → Map.Source.MappingOut.Cocone Y → Map.Source.MappingOut.Cocone Z
  post-source {Y} {Z} k = ConeMaps.Action.cone-map (Opposite C)
    (Mapping.Mapping.Into C D E F Y) (Mapping.Mapping.Into C D E F Z)
    (Mapping.Mapping.Postcompose C D E F k) E

  post-target : {Y Z : Type ℓ} → (Y → Z)
    → Map.Target.MappingOut.Cocone Y → Map.Target.MappingOut.Cocone Z
  post-target {Y} {Z} k = ConeMaps.Action.cone-map (Opposite C)
    (Mapping.Mapping.Into C G E F Y) (Mapping.Mapping.Into C G E F Z)
    (Mapping.Mapping.Postcompose C G E F k) E

  restriction : (Y : Type ℓ)
    → Map.Target.MappingOut.Cocone Y → Map.Source.MappingOut.Cocone Y
  restriction Y = Restriction.Restriction.restrict C D G α E F Y

  post-source-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Map.Source.Colimit → Y)
    → post-source k (Map.Source.MappingOut.restrict Y h)
      ≡ Map.Source.MappingOut.restrict Z (k ∘ h)
  post-source-natural k h = TargetNaturality.Naturality.restrict-natural C D E F k h

  post-target-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Map.Target.Colimit → Y)
    → post-target k (Map.Target.MappingOut.restrict Y h)
      ≡ Map.Target.MappingOut.restrict Z (k ∘ h)
  post-target-natural k h = TargetNaturality.Naturality.restrict-natural C G E F k h

  restriction-natural : {Y Z : Type ℓ} (k : Y → Z) (c : Map.Target.MappingOut.Cocone Y)
    → post-source k (restriction Y c) ≡ restriction Z (post-target k c)
  restriction-natural k c = RestrictionNaturality.Naturality.full-square C D G α E F k c

  precomposition-square : (Y : Type ℓ) (k : Map.Target.Colimit → Y)
    → Map.Source.MappingOut.restrict Y (k ∘ Map.induced)
      ≡ restriction Y (Map.Target.MappingOut.restrict Y k)
  precomposition-square Y k =
    sym (post-source-natural k Map.induced)
    ∙ cong (post-source k) Map.canonical-triangle
    ∙ restriction-natural k Map.Target.canonical-cocone
    ∙ cong (restriction Y) (post-target-natural k (idfun Map.Target.Colimit))

  precomposition-isEquiv : (Y : Type ℓ)
    → isEquiv (restriction Y) → isEquiv (λ (k : Map.Target.Colimit → Y) → k ∘ Map.induced)
  precomposition-isEquiv Y = Equivalences.through-equivalent-square
    (Map.Target.MappingOut.universal Y) (Map.Source.MappingOut.universal Y)
    (λ k → k ∘ Map.induced) (restriction Y) (precomposition-square Y)

  pointwise-map-isEquiv : ((x : Category.Obj C)
    → isEquiv (Transformations.ForCategory.Transformation.component α x))
    → isEquiv Map.induced
  pointwise-map-isEquiv pointwise = Equivalences.TwoTargetYoneda.map-isEquiv Map.induced
    (precomposition-isEquiv Map.Source.Colimit
      (Restriction.Restriction.pointwise-equivalences C D G α E F Map.Source.Colimit pointwise))
    (precomposition-isEquiv Map.Target.Colimit
      (Restriction.Restriction.pointwise-equivalences C D G α E F Map.Target.Colimit pointwise))
