{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FiniteProductQuotients where

-- Actual finite products commute with quotient by a proposition-valued
-- equivalence relation. Surjectivity uses the proved finite-choice
-- theorem, and injectivity uses effectiveness of the literal quotient.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
import Cubical.Data.FinData.FiniteChoice as FC
open import Cubical.Functions.Embedding using (injEmbedding)
open import Cubical.Functions.Surjection using
  (isSurjection; isEmbedding×isSurjection→isEquiv)
open import Cubical.Relation.Binary.Base using (module BinaryRelation)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.SetQuotients as SQ

module Powers {ℓ ℓr : Level} (X : Type ℓ) (R : X → X → Type ℓr)
    (propR : (x y : X) → isProp (R x y))
    (equivalenceR : BinaryRelation.isEquivRel R) (n : ℕ) where

  Vector = FD.Fin n → X

  CoordinateRelation : Vector → Vector → Type ℓr
  CoordinateRelation x y = (i : FD.Fin n) → R (x i) (y i)

  VectorQuotient = Vector SQ./ CoordinateRelation
  QuotientPower = FD.Fin n → X SQ./ R

  power-set : isSet QuotientPower
  power-set = isSetΠ (λ _ → SQ.squash/)

  comparison : VectorQuotient → QuotientPower
  comparison = SQ.rec power-set (λ x i → SQ.[ x i ])
    (λ x y r → funExt λ i → SQ.eq/ (x i) (y i) (r i))

  comparison-on-representatives : (x : Vector)
    → comparison SQ.[ x ] ≡ (λ i → SQ.[ x i ])
  comparison-on-representatives x = refl

  abstract
    comparison-injective : (q r : VectorQuotient)
      → comparison q ≡ comparison r → q ≡ r
    comparison-injective = SQ.elimProp2 (λ q r → isPropΠ λ _ → SQ.squash/ q r)
      (λ x y p → SQ.eq/ x y (λ i → SQ.effective propR equivalenceR
        (x i) (y i) (funExt⁻ p i)))

    comparison-surjective : isSurjection comparison
    comparison-surjective q = PT.map
      (λ representatives → SQ.[ (λ i → representatives i .fst) ] ,
        funExt (λ i → representatives i .snd))
      (FC.choice (λ i → fiber (SQ.[_] {R = R}) (q i))
        (λ i → SQ.[]surjective (q i)))

    comparison-isEquiv : isEquiv comparison
    comparison-isEquiv = isEmbedding×isSurjection→isEquiv
      (injEmbedding power-set (comparison-injective _ _) , comparison-surjective)

  vector-quotient≃quotient-power : VectorQuotient ≃ QuotientPower
  vector-quotient≃quotient-power = comparison , comparison-isEquiv
