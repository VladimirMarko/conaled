{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.QuotedCellPowerComparisons where

-- The actual cell shapes of Orbifolds.Coherent.NaturalQuotedCellAttachments. Comparison
-- maps are literal coefficient evaluation, with every index and sphere
-- coordinate fixed. Their equivalence is derived from the previously
-- proved tiny coproduct/sphere comparisons via explicit reordering.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyCubicalShellCells as TinyCells
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)

module Comparison {ℓ : Level} (T Index : Type ℓ) (Coefficient : Index → Type ℓ) (n : ℕ) where
  Cell : Type ℓ
  Cell = Σ Index Coefficient

  PoweredCell : Type ℓ
  PoweredCell = Σ[ c ∈ Index ] (T → Coefficient c)

  Boundary : Type ℓ
  Boundary = Cell × SphereBoundary n

  PoweredBoundary : Type ℓ
  PoweredBoundary = PoweredCell × SphereBoundary n

  cell-comparison : PoweredCell → T → Cell
  cell-comparison (c , v) t = c , v t

  boundary-comparison : PoweredBoundary → T → Boundary
  boundary-comparison ((c , v) , s) t = (c , v t) , s

  boundary : Boundary → Cell
  boundary = fst

  powered-boundary : PoweredBoundary → PoweredCell
  powered-boundary = fst

  boundary-square : cell-comparison ∘ powered-boundary
    ≡ (λ v → boundary ∘ v) ∘ boundary-comparison
  boundary-square = refl

  module Old = TinyCells.Power T Index (λ _ → n) Coefficient

  old-boundary-equivalence : Old.Original.Boundaries ≃ Boundary
  old-boundary-equivalence = isoToEquiv (iso
    (λ { (c , s , x) → (c , x) , lower s })
    (λ { ((c , x) , s) → c , lift s , x })
    (λ _ → refl) (λ _ → refl))

  powered-boundary-equivalence : PoweredBoundary ≃ Old.Powered.Boundaries
  powered-boundary-equivalence = isoToEquiv (iso
    (λ { ((c , v) , s) → c , lift s , v })
    (λ { (c , s , v) → (c , v) , lower s })
    (λ _ → refl) (λ _ → refl))

  module NullIndices
      (null-index : isEquiv (const :> (Index → (T → Index))))
      (null-sphere : isEquiv (const :> (TinyCells.Boundary {ℓ} n → (T → TinyCells.Boundary {ℓ} n)))) where
    module Preserved = Old.NullIndices null-index (λ _ → null-sphere)

    cells-preserved : isEquiv cell-comparison
    cells-preserved = Preserved.cells-preserved

    boundary-equivalence : PoweredBoundary ≃ (T → Boundary)
    boundary-equivalence = powered-boundary-equivalence
      ∙ₑ (Old.boundary-comparison , Preserved.boundaries-preserved)
      ∙ₑ equivΠCod (λ _ → old-boundary-equivalence)

    boundary-map-computation : (z : PoweredBoundary)
      → boundary-equivalence .fst z ≡ boundary-comparison z
    boundary-map-computation ((c , v) , s) = refl

    boundaries-preserved : isEquiv boundary-comparison
    boundaries-preserved = subst isEquiv (funExt boundary-map-computation) (boundary-equivalence .snd)

module TinyContext {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ) where
  module Tiny = TinyCells.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R r₀ T
  open Tiny using (RealFlat) public

  module Indexed (@♭ Index : Type ℓ) (Coefficient : Index → Type ℓ) (n : ℕ) where
    module Actual = Comparison T Index Coefficient n
    module Original = Tiny.Indexed Index (λ _ → n) Coefficient

    cells-preserved : RealFlat → CrisplyDiscrete Index → TT.External.Tiny T
      → isEquiv Actual.cell-comparison
    cells-preserved real-flat discrete tiny = Actual.NullIndices.cells-preserved
      (Original.index-null real-flat discrete tiny) (Tiny.boundaries-null tiny n)

    boundaries-preserved : RealFlat → CrisplyDiscrete Index → TT.External.Tiny T
      → isEquiv Actual.boundary-comparison
    boundaries-preserved real-flat discrete tiny = Actual.NullIndices.boundaries-preserved
      (Original.index-null real-flat discrete tiny) (Tiny.boundaries-null tiny n)
