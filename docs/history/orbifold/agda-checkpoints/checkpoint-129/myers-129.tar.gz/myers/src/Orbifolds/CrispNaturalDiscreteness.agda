{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}

-- Discreteness of Nat follows from native ordinary Nat induction and
-- the two explicitly named ambient crisp identity/Flat rules.
-- No separate crisp Nat-induction or choice principle is assumed.
module Orbifolds.CrispNaturalDiscreteness where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Crisp
open import Orbifolds.CrispNaturals
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF

module Theory
  (@♭ identity-rules : CI.CrispIdentityInduction {ℓ = ℓ-zero})
  (@♭ flat-induction : CF.CrispFlatInduction {ℓ = ℓ-zero})
  (@♭ flat-computation : CF.CrispFlatComputation flat-induction) where
  module Identity = CI.Theory identity-rules
  module FlatTheory = CF.Theory flat-induction flat-computation

  flat-counit : Flat (Flat ℕ) → Flat ℕ
  flat-counit = flat-map (counit {A = ℕ})

  flat-counit-agrees : (u : Flat (Flat ℕ)) → flat-counit u ≡ counit u
  flat-counit-agrees u = cong flat-counit (sym (FlatTheory.duplicate-counit u))
    ∙ map-counit-duplicate (counit u)

  abstract
    flat-counit-isEquiv : isEquiv flat-counit
    flat-counit-isEquiv = subst isEquiv (sym (funExt flat-counit-agrees))
      (FlatTheory.flat-is-discrete {A = ℕ})

  cancel-flat-counit : {u v : Flat (Flat ℕ)}
    → flat-counit u ≡ flat-counit v → u ≡ v
  cancel-flat-counit {u} {v} p = sym (retEq e u) ∙ cong (invEq e) p ∙ retEq e v
    where
    e = flat-counit , flat-counit-isEquiv

  lifted-section : (u : Flat ℕ) → flat-counit (flat-map flat-natural u) ≡ u
  lifted-section u = sym (flat-map-compose flat-natural (counit {A = ℕ}) u)
    ∙ Identity.flat-homotopy (counit ∘ flat-natural) (idfun ℕ)
        counit-flat-natural u
    ∙ flat-map-id u

  lifted-section-agrees : (u : Flat ℕ) → flat-map flat-natural u ≡ duplicate u
  lifted-section-agrees u = cancel-flat-counit
    (lifted-section u ∙ sym (map-counit-duplicate u))

  crisp-natural-eta : (@♭ n : ℕ) → flat-natural n ≡ box n
  crisp-natural-eta n = cong counit (lifted-section-agrees (box n))

  flat-natural-counit : (u : Flat ℕ) → flat-natural (counit u) ≡ u
  flat-natural-counit (box n) = crisp-natural-eta n

  natural-counit-equivalence : Flat ℕ ≃ ℕ
  natural-counit-equivalence = isoToEquiv
    (iso counit flat-natural counit-flat-natural flat-natural-counit)

  naturals-discrete : CrisplyDiscrete ℕ
  naturals-discrete = snd natural-counit-equivalence
