{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LocalPlots where

-- Actual plots on open probe domains. Reparametrizations are specified
-- independently of all target spaces and branch constructions. Smooth
-- maps preserve plots and the compatible topology. Their locality and
-- open-subspace operations are proved below.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation using (Code; Truth)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Subset; member; member-prop; Included; OpenFragment; IsOpen; open-local )
open import Orbifolds.Intensional.CompactSeparation using (preimage; Continuous)
open import Orbifolds.Intensional.OpenSubspaces using
  ( Carrier; extendSubset; openSubspace; identity-continuous; compose-continuous
  ; inclusion-continuous; corestrict-continuous; Homeomorphism )

private variable ℓ : Level

restriction-map : {P : Set ℓ} {U V : Subset P}
  → Included V U → Carrier V → Carrier U
restriction-map inside z = fst z , inside (fst z) (snd z)

domain-point-path : {P : Set ℓ} (U : Subset P) (a : P)
  → (u v : member U a) → _≡_ {A = Carrier U} (a , u) (a , v)
domain-point-path U a u v = Σ-path-prop (member-prop U) refl

record DomainPatch {P : Set ℓ} (O : OpenFragment P)
    (U : Subset P) (u : Carrier U) : Set (Code ℓ) where
  field
    patch-domain : Subset P
    patch-open : IsOpen O patch-domain
    patch-center : member patch-domain (fst u)
    patch-inclusion : Included patch-domain U

  patch-map : Carrier patch-domain → Carrier U
  patch-map = restriction-map {U = U} {V = patch-domain} patch-inclusion

open DomainPatch public

record Neighborhood {A : Set ℓ} (O : OpenFragment A) (a : A) : Set (Code ℓ) where
  field
    near : Subset A
    near-open : IsOpen O near
    near-center : member near a

open Neighborhood public

-- A small family of probes, with actual maps between their open
-- domains. Ordinary Euclidean spaces and C-infinity maps give the
-- intended classical instance; that analysis is not an input about
-- any subsequent branch diagram.
record PlotProbes (ℓ : Level) : Set (Code ℓ) where
  field
    Probe : Set ℓ
    Points : Probe → Set ℓ
    probe-topology : (i : Probe) → OpenFragment (Points i)
    Reparam : {i j : Probe}
      → (U : Subset (Points i)) (V : Subset (Points j))
      → (Carrier U → Carrier V) → Set ℓ
    reparam-identity : (i : Probe) (U : Subset (Points i))
      → IsOpen (probe-topology i) U → Reparam U U (λ u → u)
    reparam-compose : {i j k : Probe}
      → (U : Subset (Points i)) (V : Subset (Points j)) (W : Subset (Points k))
      → IsOpen (probe-topology i) U → IsOpen (probe-topology j) V
      → IsOpen (probe-topology k) W
      → (f : Carrier U → Carrier V) (g : Carrier V → Carrier W)
      → Reparam U V f → Reparam V W g → Reparam U W (λ u → g (f u))
    reparam-inclusion : {i : Probe} (U V : Subset (Points i))
      → IsOpen (probe-topology i) U → IsOpen (probe-topology i) V
      → (inside : Included V U) → Reparam V U (restriction-map {U = U} {V = V} inside)
    reparam-continuous : {i j : Probe}
      → (U : Subset (Points i)) (V : Subset (Points j))
      → (open-U : IsOpen (probe-topology i) U)
      → (open-V : IsOpen (probe-topology j) V)
      → (f : Carrier U → Carrier V) → Reparam U V f
      → Continuous (openSubspace (probe-topology i) U open-U)
          (openSubspace (probe-topology j) V open-V) f

module Theory {ℓ : Level} (ext : FunExt ℓ ℓ) (probes : PlotProbes ℓ) where

  open PlotProbes probes

  -- Plot certificates live one universe above the points. In particular,
  -- a chosen local presentation may quantify over small open predicates
  -- without pretending that a large existential has been resized.
  record LocalPlotStructure {A : Set ℓ} (OA : OpenFragment A) : Set (Truth ℓ) where
    field
      Plots : (i : Probe) (U : Subset (Points i)) → (Carrier U → A) → Set (Code ℓ)
      plot-constant : (i : Probe) (U : Subset (Points i))
        → IsOpen (probe-topology i) U → (a : A) → Plots i U (λ _ → a)
      plot-reparam : {i j : Probe}
        → (U : Subset (Points i)) (V : Subset (Points j))
        → IsOpen (probe-topology i) U → IsOpen (probe-topology j) V
        → (f : Carrier U → Carrier V) → Reparam U V f
        → (p : Carrier V → A) → Plots j V p → Plots i U (λ u → p (f u))
      plot-local : (i : Probe) (U : Subset (Points i))
        → IsOpen (probe-topology i) U → (p : Carrier U → A)
        → ((u : Carrier U) → Σ (DomainPatch (probe-topology i) U u)
          (λ patch → Plots i (patch-domain patch) (λ v → p (patch-map patch v))))
        → Plots i U p
      plot-continuous : (i : Probe) (U : Subset (Points i))
        → (open-U : IsOpen (probe-topology i) U)
        → (p : Carrier U → A) → Plots i U p
        → Continuous (openSubspace (probe-topology i) U open-U) OA p

  open LocalPlotStructure public

  plot-respects : {A : Set ℓ} {OA : OpenFragment A} (S : LocalPlotStructure OA)
    → (i : Probe) (U : Subset (Points i)) (p q : Carrier U → A)
    → ((u : Carrier U) → p u ≡ q u) → Plots S i U p → Plots S i U q
  plot-respects S i U p q same = subst (Plots S i U) (ext same)

  record Smooth {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
      (SA : LocalPlotStructure OA) (SB : LocalPlotStructure OB)
      (f : A → B) : Set (Code ℓ) where
    field
      smooth-continuous : Continuous OA OB f
      preserves-plots : (i : Probe) (U : Subset (Points i))
        → IsOpen (probe-topology i) U → (p : Carrier U → A)
        → Plots SA i U p → Plots SB i U (λ u → f (p u))

  open Smooth public

  identity-smooth : {A : Set ℓ} {OA : OpenFragment A}
    → (SA : LocalPlotStructure OA) → Smooth SA SA (λ a → a)
  smooth-continuous (identity-smooth {OA = OA} SA) = identity-continuous OA
  preserves-plots (identity-smooth SA) i U open-U p plot = plot

  compose-smooth : {A B C : Set ℓ}
    → {OA : OpenFragment A} {OB : OpenFragment B} {OC : OpenFragment C}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB} {SC : LocalPlotStructure OC}
    → (f : A → B) (g : B → C) → Smooth SA SB f → Smooth SB SC g
    → Smooth SA SC (λ a → g (f a))
  smooth-continuous (compose-smooth {OA = OA} {OB} {OC} f g sf sg) =
    compose-continuous OA OB OC f g (smooth-continuous sf) (smooth-continuous sg)
  preserves-plots (compose-smooth f g sf sg) i U open-U p plot =
    preserves-plots sg i U open-U (λ u → f (p u))
      (preserves-plots sf i U open-U p plot)

  smooth-respects : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB}
    → (f g : A → B) → ((a : A) → f a ≡ g a)
    → Smooth SA SB f → Smooth SA SB g
  smooth-respects {SA = SA} {SB} f g same = subst (Smooth SA SB) (ext same)

  -- The plot structure of an open subtype is the literal induced plot
  -- structure: a plot is a function whose underlying ambient map plots.
  openPlotStructure : {A : Set ℓ} {OA : OpenFragment A}
    → (SA : LocalPlotStructure OA) → (D : Subset A) (open-D : IsOpen OA D)
    → LocalPlotStructure (openSubspace OA D open-D)
  Plots (openPlotStructure SA D open-D) i U p = Plots SA i U (λ u → fst (p u))
  plot-constant (openPlotStructure SA D open-D) i U open-U a =
    plot-constant SA i U open-U (fst a)
  plot-reparam (openPlotStructure SA D open-D) U V open-U open-V f rf p plot =
    plot-reparam SA U V open-U open-V f rf (λ v → fst (p v)) plot
  plot-local (openPlotStructure SA D open-D) i U open-U p local =
    plot-local SA i U open-U (λ u → fst (p u)) local
  plot-continuous (openPlotStructure {OA = OA} SA D open-D) i U open-U p plot =
    corestrict-continuous (openSubspace (probe-topology i) U open-U) OA D open-D
      (λ u → fst (p u)) (plot-continuous SA i U open-U (λ u → fst (p u)) plot)
      (λ u → snd (p u))

  inclusion-smooth : {A : Set ℓ} {OA : OpenFragment A}
    → (SA : LocalPlotStructure OA) → (D : Subset A) (open-D : IsOpen OA D)
    → Smooth (openPlotStructure SA D open-D) SA fst
  smooth-continuous (inclusion-smooth {OA = OA} SA D open-D) =
    inclusion-continuous OA D open-D
  preserves-plots (inclusion-smooth SA D open-D) i U open-U p plot = plot

  corestrict-smooth : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB}
    → (D : Subset B) (open-D : IsOpen OB D)
    → (f : A → B) → Smooth SA SB f → (lands : (a : A) → member D (f a))
    → Smooth SA (openPlotStructure SB D open-D) (λ a → f a , lands a)
  smooth-continuous (corestrict-smooth {OA = OA} {OB} D open-D f sf lands) =
    corestrict-continuous OA OB D open-D f (smooth-continuous sf) lands
  preserves-plots (corestrict-smooth D open-D f sf lands) i U open-U p plot =
    preserves-plots sf i U open-U p plot

  restrict-smooth : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB}
    → (D : Subset A) (open-D : IsOpen OA D) → (f : A → B)
    → Smooth SA SB f → Smooth (openPlotStructure SA D open-D) SB (λ z → f (fst z))
  restrict-smooth {SA = SA} D open-D f sf =
    compose-smooth fst f (inclusion-smooth SA D open-D) sf

  -- Smoothness is local on the source, as a theorem about preservation
  -- of plots. This is not a field of Smooth or LocalPlotStructure.
  local-smooth : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB} → (f : A → B)
    → ((a : A) → Σ (Neighborhood OA a)
      (λ N → Smooth (openPlotStructure SA (near N) (near-open N)) SB (λ z → f (fst z))))
    → Smooth SA SB f
  smooth-continuous (local-smooth {OA = OA} {OB} f local) W open-W =
    open-local OA (preimage f W)
      (λ a in-W →
        let chosen = local a
            N = fst chosen
            D = near N
            open-D = near-open N
            sf = snd chosen
        in extendSubset D (preimage (λ z → f (fst z)) W) ,
          (smooth-continuous sf W open-W ,
            ((near-center N , in-W) , (λ b witness → snd witness))))
  preserves-plots (local-smooth {SA = SA} {SB} f local) i U open-U p plot =
    plot-local SB i U open-U (λ u → f (p u)) neighborhood
    where
    neighborhood : (u : Carrier U) → Σ (DomainPatch (probe-topology i) U u)
      (λ patch → Plots SB i (patch-domain patch) (λ v → f (p (patch-map patch v))))
    neighborhood u = patch , preserves-plots sf i W open-W pW plot-W
      where
      chosen = local (p u)
      N = fst chosen
      D = near N
      open-D = near-open N
      sf = snd chosen

      W : Subset (Points i)
      W = extendSubset U (preimage p D)

      open-W : IsOpen (probe-topology i) W
      open-W = plot-continuous SA i U open-U p plot D open-D

      inside-W : Included W U
      inside-W a witness = fst witness

      patch : DomainPatch (probe-topology i) U u
      patch-domain patch = W
      patch-open patch = open-W
      patch-center patch = snd u , near-center N
      patch-inclusion patch = inside-W

      pW : Carrier W → Carrier D
      pW v = p (patch-map patch v) , snd (snd v)

      plot-W : Plots (openPlotStructure SA D open-D) i W pW
      plot-W = plot-reparam SA W U open-W open-U (patch-map patch)
        (reparam-inclusion U W open-U open-W inside-W) p plot

  -- Continuity can likewise be glued over the open domains of a probe.
  -- This helper is used to verify the generated coproduct plots.
  domain-local-continuous : {B : Set ℓ} (OB : OpenFragment B)
    → (i : Probe) (U : Subset (Points i))
    → (open-U : IsOpen (probe-topology i) U) → (p : Carrier U → B)
    → ((u : Carrier U) → Σ (DomainPatch (probe-topology i) U u)
      (λ patch → Continuous
        (openSubspace (probe-topology i) (patch-domain patch) (patch-open patch))
        OB (λ v → p (patch-map patch v))))
    → Continuous (openSubspace (probe-topology i) U open-U) OB p
  domain-local-continuous OB i U open-U p local W open-W =
    open-local (probe-topology i) (extendSubset U (preimage p W)) neighborhood
    where
    neighborhood : (a : Points i) → member (extendSubset U (preimage p W)) a
      → Σ (Subset (Points i)) (λ V → Σ (IsOpen (probe-topology i) V)
        (λ _ → Σ (member V a) (λ _ → Included V (extendSubset U (preimage p W)))))
    neighborhood a (in-U , in-W) = V , (open-V , (center-V , inside-V))
      where
      chosen = local (a , in-U)
      patch = fst chosen
      cp = snd chosen
      D = patch-domain patch
      inc = patch-inclusion patch

      V : Subset (Points i)
      V = extendSubset D (preimage (λ v → p (patch-map patch v)) W)

      open-V : IsOpen (probe-topology i) V
      open-V = cp W open-W

      center-V : member V a
      center-V = patch-center patch ,
        subst (member W)
          (cong p (domain-point-path U a in-U (inc a (patch-center patch)))) in-W

      inside-V : Included V (extendSubset U (preimage p W))
      inside-V b witness = inc b (fst witness) , snd witness

  record Diffeomorphism {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
      (SA : LocalPlotStructure OA) (SB : LocalPlotStructure OB) : Set (Code ℓ) where
    field
      equivalence : Equiv A B
      smooth-forward : Smooth SA SB (forward equivalence)
      smooth-backward : Smooth SB SA (backward equivalence)

  open Diffeomorphism public

  underlying-homeomorphism : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB}
    → Diffeomorphism SA SB → Homeomorphism OA OB
  Homeomorphism.underlying (underlying-homeomorphism d) = equivalence d
  Homeomorphism.forward-continuous (underlying-homeomorphism d) =
    smooth-continuous (smooth-forward d)
  Homeomorphism.backward-continuous (underlying-homeomorphism d) =
    smooth-continuous (smooth-backward d)

  inverse-diffeomorphism : {A B : Set ℓ} {OA : OpenFragment A} {OB : OpenFragment B}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB}
    → Diffeomorphism SA SB → Diffeomorphism SB SA
  equivalence (inverse-diffeomorphism d) = invEquiv (equivalence d)
  smooth-forward (inverse-diffeomorphism d) = smooth-backward d
  smooth-backward (inverse-diffeomorphism d) = smooth-forward d

  compose-diffeomorphism : {A B C : Set ℓ}
    → {OA : OpenFragment A} {OB : OpenFragment B} {OC : OpenFragment C}
    → {SA : LocalPlotStructure OA} {SB : LocalPlotStructure OB} {SC : LocalPlotStructure OC}
    → Diffeomorphism SA SB → Diffeomorphism SB SC → Diffeomorphism SA SC
  equivalence (compose-diffeomorphism d e) = compEquiv (equivalence d) (equivalence e)
  smooth-forward (compose-diffeomorphism d e) =
    compose-smooth (forward (equivalence d)) (forward (equivalence e))
      (smooth-forward d) (smooth-forward e)
  smooth-backward (compose-diffeomorphism d e) =
    compose-smooth (backward (equivalence e)) (backward (equivalence d))
      (smooth-backward e) (smooth-backward d)
