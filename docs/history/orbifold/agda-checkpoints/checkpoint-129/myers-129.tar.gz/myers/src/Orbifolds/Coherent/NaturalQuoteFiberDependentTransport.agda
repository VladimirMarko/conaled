{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuoteFiberDependentTransport where

-- A path of quotation fibers over a path of shells gives the literal
-- attaching homotopy and its dependent filler comparison at once.
-- In particular, no inner shell path is turned into strict equality.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.NaturalCubicalFillerRepresentation as Natural
import Orbifolds.Coherent.NaturalQuotedFillers as Quoted
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Transport {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module N = Natural.Natural E
  module Q = Quoted.Natural E

  fiber-fill-dependent-path : (n : Dim) {X : Type ℓ}
    {b b' : CS.Shell (toNat n) X} (β : b ≡ b')
    {z : N.QuoteFiber n b} {w : N.QuoteFiber n b'}
    (p : PathP (λ i → N.QuoteFiber n (β i)) z w)
    (u : Q.SphereNull n (w .fst))
    → subst (CF.Filler (toNat n)) β
        (N.fiber-fill n b z (u .fst , ((λ i → p i .fst) ∙ u .snd)))
      ≡ N.fiber-fill n b' w u
  fiber-fill-dependent-path n β p (x , q) = fromPathP
    (λ i → N.fiber-fill n (β i) (p i)
      (x , compPath-filler' (λ j → p j .fst) q (~ i)))
