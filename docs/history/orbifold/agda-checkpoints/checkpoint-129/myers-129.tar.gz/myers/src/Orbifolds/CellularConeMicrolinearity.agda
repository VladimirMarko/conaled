{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CellularConeMicrolinearity where

-- Uniform cellular cone towers. Every stage is the literal pullback of
-- boundary data against products of actual restriction maps. The full
-- cone is the actual inverse tower limit. All higher boundary paths are
-- retained; no assertion that every infinity-diagram has such a
-- presentation is made.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Graph
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML
import Orbifolds.GraphLimits as GL

-- A genuine inverse tower, with its full path-valued compatibility and
-- mapping universal property. Its graph presentation is constructed.
module InverseTower {ℓ : Level} (P : ℕ → Type ℓ)
    (drop : (n : ℕ) → P (suc n) → P n) where
  data EdgeStep : ℕ → ℕ → Type ℓ-zero where
    down : (n : ℕ) → EdgeStep (suc n) n

  graph : Graph ℓ-zero ℓ-zero
  Node graph = ℕ
  Edge graph = EdgeStep

  diagram : Diag ℓ graph
  diagram $g n = P n
  diagram <$g> (down n) = drop n

  module G = GL.Diagram graph diagram

  Compatibility : ((n : ℕ) → P n) → Type ℓ
  Compatibility x = (n : ℕ) → drop n (x (suc n)) ≡ x n

  Limit : Type ℓ
  Limit = Σ ((n : ℕ) → P n) Compatibility

  projection : (n : ℕ) → Limit → P n
  projection n z = z .fst n

  projection-square : (n : ℕ) (z : Limit)
    → drop n (projection (suc n) z) ≡ projection n z
  projection-square n z = z .snd n

  edge-coherence : (x : (n : ℕ) → P n) → Compatibility x → G.Compatibility x
  edge-coherence x p .(suc n) .n (down n) = p n

  from-graph : G.Limit → Limit
  from-graph (x , p) = x , (λ n → p (suc n) n (down n))

  to-graph : Limit → G.Limit
  to-graph (x , p) = x , edge-coherence x p

  edge-roundtrip : (x : (n : ℕ) → P n) (p : G.Compatibility x)
    (i j : ℕ) (e : EdgeStep i j)
    → edge-coherence x (λ n → p (suc n) n (down n)) i j e ≡ p i j e
  edge-roundtrip x p .(suc n) .n (down n) = refl

  graph-roundtrip : (z : G.Limit) → to-graph (from-graph z) ≡ z
  graph-roundtrip (x , p) = ΣPathP (refl ,
    funExt (λ i → funExt (λ j → funExt (edge-roundtrip x p i j))))

  graph-equivalence : G.Limit ≃ Limit
  graph-equivalence = isoToEquiv (iso from-graph to-graph (λ _ → refl) graph-roundtrip)

  Cone : {ℓt : Level} → Type ℓt → Type (ℓ-max ℓ ℓt)
  Cone T = Σ[ leg ∈ ((n : ℕ) → T → P n) ]
    ((n : ℕ) → drop n ∘ leg (suc n) ≡ leg n)

  restrict : {ℓt : Level} {T : Type ℓt} → (T → Limit) → Cone T
  restrict h = (λ n t → h t .fst n) , (λ n i t → h t .snd n i)

  assemble : {ℓt : Level} {T : Type ℓt} → Cone T → T → Limit
  assemble (leg , commutes) t = (λ n → leg n t) , (λ n i → commutes n i t)

  universal : {ℓt : Level} (T : Type ℓt) → (T → Limit) ≃ Cone T
  universal T = isoToEquiv (iso restrict assemble (λ _ → refl) (λ _ → refl))

  assemble-projection : {ℓt : Level} {T : Type ℓt} (c : Cone T) (n : ℕ) (t : T)
    → projection n (assemble c t) ≡ c .fst n t
  assemble-projection c n t = refl

  assemble-square : {ℓt : Level} {T : Type ℓt} (c : Cone T) (n : ℕ) (t : T) (i : I)
    → projection-square n (assemble c t) i ≡ c .snd n i t
  assemble-square c n t i = refl

  precompose-cone : {ℓs ℓt : Level} {S : Type ℓs} {T : Type ℓt}
    → Cone T → (S → T) → Cone S
  precompose-cone (leg , commutes) f = (λ n → leg n ∘ f) ,
    (λ n i s → commutes n i (f s))

  universal-natural : {ℓs ℓt : Level} {S : Type ℓs} {T : Type ℓt}
    (h : T → Limit) (f : S → T)
    → restrict (h ∘ f) ≡ precompose-cone (restrict h) f
  universal-natural h f = refl

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw) where
    limit-microlinear : ((n : ℕ) → Micro.Theory.Microlinear test (P n))
      → Micro.Theory.Microlinear test Limit
    limit-microlinear stages = ML.Limits.microlinear-equiv test graph-equivalence
      (G.Microlinear.limit-microlinear test stages)

-- One cellular cone extension. Cell indices, boundary and filler
-- domains, and coefficients may all be arbitrary higher types.
record Attachment {ℓ : Level} (Previous : Type ℓ) : Type (ℓ-suc ℓ) where
  field
    Cells : Type ℓ
    Boundary Extension Coefficient : Cells → Type ℓ
    boundary : (c : Cells) → Boundary c → Extension c

  BoundaryData : Type ℓ
  BoundaryData = (c : Cells) → Boundary c → Coefficient c

  Fillers : Type ℓ
  Fillers = (c : Cells) → Extension c → Coefficient c

  restriction : Fillers → BoundaryData
  restriction fill c b = fill c (boundary c b)

  field
    boundary-data : Previous → BoundaryData

  Next : Type ℓ
  Next = ML.Pullback boundary-data restriction

  forget : Next → Previous
  forget p = p .fst .fst

  fillers : Next → Fillers
  fillers p = p .fst .snd

  boundary-square : (p : Next) → boundary-data (forget p) ≡ restriction (fillers p)
  boundary-square p = p .snd

  boundary-evaluation : (p : Next) (c : Cells) (b : Boundary c)
    → boundary-data (forget p) c b ≡ fillers p c (boundary c b)
  boundary-evaluation p c b i = p .snd i c b

  ExtensionCone : {ℓt : Level} → Type ℓt → Type (ℓ-max ℓ ℓt)
  ExtensionCone T = ML.Pullback
    (λ (old : T → Previous) → boundary-data ∘ old)
    (λ (fill : T → Fillers) → restriction ∘ fill)

  restrict-extension : {ℓt : Level} {T : Type ℓt} → (T → Next) → ExtensionCone T
  restrict-extension h = ((λ t → forget (h t)) , (λ t → fillers (h t))) ,
    (λ i t → boundary-square (h t) i)

  assemble-extension : {ℓt : Level} {T : Type ℓt} → ExtensionCone T → T → Next
  assemble-extension ((old , fill) , commutes) t = (old t , fill t) , (λ i → commutes i t)

  extension-universal : {ℓt : Level} (T : Type ℓt) → (T → Next) ≃ ExtensionCone T
  extension-universal T = isoToEquiv
    (iso restrict-extension assemble-extension (λ _ → refl) (λ _ → refl))

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw) where
    boundary-data-microlinear : ((c : Cells) → Micro.Theory.Microlinear test (Coefficient c))
      → Micro.Theory.Microlinear test BoundaryData
    boundary-data-microlinear coefficients = Micro.Theory.microlinear-Π test
      (λ c → Micro.Theory.microlinear-Π test (λ _ → coefficients c))

    fillers-microlinear : ((c : Cells) → Micro.Theory.Microlinear test (Coefficient c))
      → Micro.Theory.Microlinear test Fillers
    fillers-microlinear coefficients = Micro.Theory.microlinear-Π test
      (λ c → Micro.Theory.microlinear-Π test (λ _ → coefficients c))

    next-microlinear : Micro.Theory.Microlinear test Previous
      → ((c : Cells) → Micro.Theory.Microlinear test (Coefficient c))
      → Micro.Theory.Microlinear test Next
    next-microlinear previous coefficients = ML.Limits.microlinear-pullback test
      boundary-data restriction previous
      (fillers-microlinear coefficients) (boundary-data-microlinear coefficients)

record Schedule {ℓ : Level} (Previous : Type ℓ) : Type (ℓ-suc ℓ) where
  coinductive
  field
    attachment : Attachment Previous
    next : Schedule (Attachment.Next attachment)

module Tower {ℓ : Level} (Initial : Type ℓ) (schedule : Schedule Initial) where
  State : Type (ℓ-suc ℓ)
  State = Σ[ P ∈ Type ℓ ] Schedule P

  advance : State → State
  advance s .fst = Attachment.Next (Schedule.attachment (s .snd))
  advance s .snd = Schedule.next (s .snd)

  state : ℕ → State
  state zero = Initial , schedule
  state (suc n) = advance (state n)

  PartialCone : ℕ → Type ℓ
  PartialCone n = state n .fst

  attachment : (n : ℕ) → Attachment (PartialCone n)
  attachment n = Schedule.attachment (state n .snd)

  stage-is-pullback : (n : ℕ)
    → PartialCone (suc n) ≡ ML.Pullback
      (Attachment.boundary-data (attachment n)) (Attachment.restriction (attachment n))
  stage-is-pullback n = refl

  drop : (n : ℕ) → PartialCone (suc n) → PartialCone n
  drop n = Attachment.forget (attachment n)

  module Limit = InverseTower PartialCone drop
  open Limit using (projection; projection-square; restrict; assemble; universal;
    assemble-projection; assemble-square; universal-natural) public

  Cone : Type ℓ
  Cone = Limit.Limit

  fillers : (n : ℕ) → Cone → Attachment.Fillers (attachment n)
  fillers n c = Attachment.fillers (attachment n) (projection (suc n) c)

  boundary-square : (n : ℕ) (c : Cone)
    → Attachment.boundary-data (attachment n) (projection n c)
      ≡ Attachment.restriction (attachment n) (fillers n c)
  boundary-square n c = cong (Attachment.boundary-data (attachment n))
    (sym (projection-square n c))
    ∙ Attachment.boundary-square (attachment n) (projection (suc n) c)

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw)
      (initial : Micro.Theory.Microlinear test Initial)
      (coefficients : (n : ℕ) (c : Attachment.Cells (attachment n))
        → Micro.Theory.Microlinear test (Attachment.Coefficient (attachment n) c)) where
    stages-microlinear : (n : ℕ) → Micro.Theory.Microlinear test (PartialCone n)
    stages-microlinear zero = initial
    stages-microlinear (suc n) = Attachment.Microlinear.next-microlinear
      (attachment n) test (stages-microlinear n) (coefficients n)

    cone-microlinear : Micro.Theory.Microlinear test Cone
    cone-microlinear = Limit.Microlinear.limit-microlinear test stages-microlinear

-- The requested initial stage is the literal product of vertex types.
module Vertices {ℓ : Level} (V : Type ℓ) (X : V → Type ℓ)
    (schedule : Schedule ((v : V) → X v)) where
  module T = Tower ((v : V) → X v) schedule
  open T public

  module MicrolinearVertices {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw)
      (vertices : (v : V) → Micro.Theory.Microlinear test (X v))
      (coefficients : (n : ℕ) (c : Attachment.Cells (attachment n))
        → Micro.Theory.Microlinear test (Attachment.Coefficient (attachment n) c)) where
    initial-microlinear : Micro.Theory.Microlinear test ((v : V) → X v)
    initial-microlinear = Micro.Theory.microlinear-Π test vertices

    partial-cones-microlinear : (n : ℕ) → Micro.Theory.Microlinear test (PartialCone n)
    partial-cones-microlinear = T.Microlinear.stages-microlinear test initial-microlinear coefficients

    cone-microlinear : Micro.Theory.Microlinear test Cone
    cone-microlinear = T.Microlinear.cone-microlinear test initial-microlinear coefficients
