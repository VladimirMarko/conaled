{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConditionalRationalSpan where

-- The same conditional subgroup has full rational span: the images of
-- two actual subgroup elements (2,0) and (0,2) are an explicit rational
-- coordinate basis of Q². This is independent of any decision of P.
-- The source states the coordinate/spanning certificate explicitly,
-- without silently identifying an unspecified notion of group rank.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (pos)
open import Cubical.Data.NatPlusOne using (1+_)
import Cubical.Data.Rationals as Q
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties using (module RingTheory)
import Orbifolds.RationalRingHom as RR
import Orbifolds.IntegerCoefficients as IC
import Orbifolds.IntegerPairMatrices as Pair
import Orbifolds.ConditionalIntegerLattices as CL

module Rational = CommRingStr (RR.RationalRing .snd)
module Ring = RingTheory (CommRing→Ring RR.RationalRing)
module Integer = IC.Ring RR.RationalRing
open Rational

half : Q.ℚ
half = Q.[ pos 1 / (1+ 1) ]

two : Q.ℚ
two = Integer.integer (pos 2)

half-two : half · two ≡ 1r
half-two = Q.eq/ _ _ refl

two-half : two · half ≡ 1r
two-half = ·Comm two half ∙ half-two

halve-double : (q : Q.ℚ) → (q · half) · two ≡ q
halve-double q = sym (·Assoc q half two) ∙ cong (q ·_) half-two ∙ ·IdR q

double-halve : (q : Q.ℚ) → (q · two) · half ≡ q
double-halve q = sym (·Assoc q two half) ∙ cong (q ·_) two-half ∙ ·IdR q

module Proposition {ℓ : Level} (P : Type ℓ) (propP : isProp P) where
  module Conditional = CL.Proposition P propP

  RationalPlane = Q.ℚ × Q.ℚ

  rational-image : Conditional.Carrier → RationalPlane
  rational-image (x , n) = Integer.integer (x .fst) , Integer.integer n

  first-element second-element : Conditional.Carrier
  first-element = Conditional.doubling .fst Pair.Mat.basis₁
  second-element = Conditional.doubling .fst Pair.Mat.basis₂

  first-image : rational-image first-element ≡ (two , 0r)
  first-image = refl

  second-image : rational-image second-element ≡ (0r , two)
  second-image = refl

  scale : Q.ℚ → RationalPlane → RationalPlane
  scale a (x , y) = a · x , a · y

  add : RationalPlane → RationalPlane → RationalPlane
  add (x , y) (x' , y') = x + x' , y + y'

  combination : RationalPlane → RationalPlane
  combination (a , b) = add (scale a (rational-image first-element))
    (scale b (rational-image second-element))

  diagonal-computation : (v : RationalPlane)
    → combination v ≡ (v .fst · two , v .snd · two)
  diagonal-computation (a , b) = cong₂ _,_
    (cong (a · two +_) (Ring.0RightAnnihilates b) ∙ +IdR (a · two))
    (cong (_+ b · two) (Ring.0RightAnnihilates a) ∙ +IdL (b · two))

  coefficients : RationalPlane → RationalPlane
  coefficients (x , y) = x · half , y · half

  combination-coefficients : (v : RationalPlane) → combination (coefficients v) ≡ v
  combination-coefficients (x , y) = diagonal-computation (coefficients (x , y))
    ∙ cong₂ _,_ (halve-double x) (halve-double y)

  coefficients-combination : (v : RationalPlane) → coefficients (combination v) ≡ v
  coefficients-combination (a , b) = cong coefficients (diagonal-computation (a , b))
    ∙ cong₂ _,_ (double-halve a) (double-halve b)

  rational-basis-coordinate-equivalence : RationalPlane ≃ RationalPlane
  rational-basis-coordinate-equivalence = isoToEquiv
    (iso combination coefficients combination-coefficients coefficients-combination)

  every-rational-pair-is-spanned : (v : RationalPlane)
    → Σ[ a ∈ Q.ℚ ] Σ[ b ∈ Q.ℚ ]
      add (scale a (rational-image first-element)) (scale b (rational-image second-element)) ≡ v
  every-rational-pair-is-spanned v = coefficients v .fst , coefficients v .snd ,
    combination-coefficients v

  rational-independence : (a b : Q.ℚ)
    → add (scale a (rational-image first-element)) (scale b (rational-image second-element))
        ≡ (0r , 0r)
    → (a ≡ 0r) × (b ≡ 0r)
  rational-independence a b equal = cong fst result , cong snd result
    where
    result : (a , b) ≡ (0r , 0r)
    result = sym (coefficients-combination (a , b)) ∙ cong coefficients equal
      ∙ cong₂ _,_ (Ring.0LeftAnnihilates half) (Ring.0LeftAnnihilates half)
