{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.CrystallineSeparation where

-- A constructive replacement for the sharp comparison needed in the
-- Penon-neighborhood argument. The separating target is the actual set
-- quotient by double-negated equality. No sharp modality, excluded
-- middle, crisp induction or preservation of arbitrary pullbacks is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Univalence using (hPropExt)
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Relation.Binary.Base using (module BinaryRelation)
open import Cubical.Algebra.CommRing.Base using (CommRing)
import Cubical.HITs.SetQuotients as SQ
open import Orbifolds.Penon
open import Orbifolds.MicrolinearNeighborhoods
  using (NeighborStable; neighborhood-predicate; neighborhood-stable)
import Orbifolds.Crystalline as CR

module Separation {ℓ : Level} (X : Type ℓ) where
  open BinaryRelation

  neighbor-equivalence : isEquivRel (Neighbors {X = X})
  neighbor-equivalence = equivRel neighborRefl
    (λ x y → neighborSym) (λ x y z → neighborTrans)

  Quotient : Type ℓ
  Quotient = X SQ./ Neighbors

  quotient : X → Quotient
  quotient = SQ.[_]

  point-equality→neighbor : (x y : X) → quotient x ≡ quotient y → Neighbors x y
  point-equality→neighbor = SQ.effective (λ _ _ → isPropNeighbors) neighbor-equivalence

  separated : (u v : Quotient) → Neighbors u v → u ≡ v
  separated = SQ.elimProp2 (λ u v → isPropΠ λ _ → SQ.squash/ u v)
    (λ x y near → SQ.eq/ x y
      (λ unequal → near (λ path → point-equality→neighbor x y path unequal)))

  -- Neighbor-stable predicates descend to this actual quotient. The
  -- classifier's computation on representatives is judgmental.
  module Predicate (P : X → hProp ℓ) (stable : NeighborStable P) where
    predicate-path : (x y : X) → Neighbors x y → P x ≡ P y
    predicate-path x y near = Σ≡Prop (λ _ → isPropIsProp)
      (hPropExt (P x .snd) (P y .snd)
        (λ px → stable px (neighborSym near)) (λ py → stable py near))

    descended : Quotient → hProp ℓ
    descended = SQ.rec isSetHProp P predicate-path

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CR.Ring R

  infinitesimal-neighbor : (d : 𝔇) → Neighbors d zero𝔇
  infinitesimal-neighbor d unequal = d .snd
    (λ p → unequal (Σ≡Prop (λ _ → isPropNeighbors) p))

  separated→crystalline : {S : Type ℓ}
    → ((x y : S) → Neighbors x y → x ≡ y) → IsCrystalline S
  separated→crystalline separated _ = fromIsEquiv const (isoToIsEquiv
    (iso const (λ f → f zero𝔇)
      (λ f → funExt λ d → sym
        (separated (f d) (f zero𝔇) (preservesNeighbors f (infinitesimal-neighbor d))))
      (λ _ → refl)))

  module For (X : Type ℓ) where
    module Separate = Separation X

    quotient-crystalline : IsCrystalline Separate.Quotient
    quotient-crystalline = separated→crystalline Separate.separated

    factor : Im X → Separate.Quotient
    factor = Crystal.◯-rec quotient-crystalline Separate.quotient

    factor-on-units : (x : X) → factor (crystalline-unit x) ≡ Separate.quotient x
    factor-on-units = Crystal.◯-rec-β quotient-crystalline Separate.quotient

    -- Equality after crystalline reflection cannot identify points that
    -- are provably distinct. This holds even when X and its points vary.
    crystalline-equality→neighbor : (x y : X)
      → crystalline-unit x ≡ crystalline-unit y → Neighbors x y
    crystalline-equality→neighbor x y p = Separate.point-equality→neighbor x y
      (sym (factor-on-units x) ∙ cong factor p ∙ factor-on-units y)

    module StableSubtype (P : X → hProp ℓ) (stable : NeighborStable P) where
      module Classified = Separate.Predicate P stable

      DescendedFamily : Separate.Quotient → Type ℓ
      DescendedFamily q = Classified.descended q .fst

      DescendedTotal : Type ℓ
      DescendedTotal = Σ Separate.Quotient DescendedFamily

      total-crystalline : IsCrystalline DescendedTotal
      total-crystalline = Crystal.Σ-isModal DescendedFamily quotient-crystalline
        (λ q → proposition-crystalline (Classified.descended q .snd))

      subtype-presentation : (Σ[ x ∈ X ] P x .fst)
        ≃ (Σ[ x ∈ X ] fiber (fst {B = DescendedFamily}) (Separate.quotient x))
      subtype-presentation = Σ-cong-equiv-snd
        (λ x → fiberProjEquiv Separate.Quotient DescendedFamily (Separate.quotient x))

      inclusion-etale : Crystal.Etale (fst {B = λ x → P x .fst})
      inclusion-etale = Crystal.etale-precompose-equivalence subtype-presentation fst
        (Crystal.pullback-modal-map-etale total-crystalline quotient-crystalline fst
          Separate.quotient)

    penon-open-inclusion-etale : (P : X → hProp ℓ) → PenonOpen P
      → Crystal.Etale (fst {B = λ x → P x .fst})
    penon-open-inclusion-etale P openP = StableSubtype.inclusion-etale P
      (λ px near → penonOpenNeighborStable P openP px (neighborSym near))

    neighborhood-inclusion-etale : (x : X)
      → Crystal.Etale (fst {B = λ y → Neighbors y x})
    neighborhood-inclusion-etale x = StableSubtype.inclusion-etale
      (neighborhood-predicate x) (neighborhood-stable x)
