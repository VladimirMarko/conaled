{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FixedObjectFunctorExtensionality where

open import Agda.Primitive using (Level; Set)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat

-- One object function is fixed throughout. Equality of arrow maps transports
-- their actual law certificates through a proposition-valued dependent sum.
-- No equality between different object functions is assumed or erased.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ)
    (C D : Cat.Category ℓ ℓ)
    (F₀ : Cat.Category.Obj C → Cat.Category.Obj D) where
  private
    module C = Cat.Category C
    module D = Cat.Category D

  ArrowMap : Set ℓ
  ArrowMap = (X Y : C.Obj) → C.Hom X Y → D.Hom (F₀ X) (F₀ Y)

  IdentityLaw : ArrowMap → Set ℓ
  IdentityLaw m = (X : C.Obj)
    → m X X (C.identity {X = X}) O.≡ D.identity {X = F₀ X}

  CompositionLaw : ArrowMap → Set ℓ
  CompositionLaw m = (X Y Z : C.Obj) (g : C.Hom Y Z) (f : C.Hom X Y)
    → m X Z (C.compose {X = X} {Y = Y} {Z = Z} g f)
      O.≡ D.compose {X = F₀ X} {Y = F₀ Y} {Z = F₀ Z}
        (m Y Z g) (m X Y f)

  identityLaw-prop : (m : ArrowMap) → O.isProp (IdentityLaw m)
  identityLaw-prop m = O.isPropΠ ext
    (λ X → D.hom-set (F₀ X) (F₀ X)
      (m X X (C.identity {X = X})) (D.identity {X = F₀ X}))

  compositionLaw-prop : (m : ArrowMap) → O.isProp (CompositionLaw m)
  compositionLaw-prop m = O.isPropΠ ext (λ X →
    O.isPropΠ ext (λ Y → O.isPropΠ ext (λ Z →
    O.isPropΠ ext (λ g → O.isPropΠ ext (λ f →
      D.hom-set (F₀ X) (F₀ Z)
        (m X Z (C.compose {X = X} {Y = Y} {Z = Z} g f))
        (D.compose {X = F₀ X} {Y = F₀ Y} {Z = F₀ Z}
          (m Y Z g) (m X Y f)))))))

  Laws : ArrowMap → Set ℓ
  Laws m = O.Σ (IdentityLaw m) (λ _ → CompositionLaw m)

  laws-prop : (m : ArrowMap) → O.isProp (Laws m)
  laws-prop m = O.isPropΣ (identityLaw-prop m)
    (λ _ → compositionLaw-prop m)

  Code : Set ℓ
  Code = O.Σ ArrowMap Laws

  arrow-map-path : {m n : ArrowMap}
    → ((X Y : C.Obj) (f : C.Hom X Y) → m X Y f O.≡ n X Y f)
    → m O.≡ n
  arrow-map-path same = ext (λ X → ext (λ Y → ext (same X Y)))

  code-path : {u v : Code} → O.fst u O.≡ O.fst v → u O.≡ v
  code-path {u} {v} = O.Σ-path-prop laws-prop {u = u} {v = v}

  decode : Code → Cat.Functor C D
  Cat.Functor.object (decode q) = F₀
  Cat.Functor.arrow (decode q) {X} {Y} = O.fst q X Y
  Cat.Functor.arrow-identity (decode q) {X} = O.fst (O.snd q) X
  Cat.Functor.arrow-compose (decode q) {X} {Y} {Z} g f =
    O.snd (O.snd q) X Y Z g f

  decode-path : {u v : Code}
    → O.fst u O.≡ O.fst v → decode u O.≡ decode v
  decode-path {u} {v} p = O.cong decode (code-path {u = u} {v = v} p)

  decode-ext : {u v : Code}
    → ((X Y : C.Obj) (f : C.Hom X Y)
      → O.fst u X Y f O.≡ O.fst v X Y f)
    → decode u O.≡ decode v
  decode-ext {u} {v} same = decode-path {u = u} {v = v}
    (arrow-map-path {m = O.fst u} {n = O.fst v} same)

-- These are actual Functor equalities for decoded data over the fixed F₀.
-- Applying the result to pre-existing functors still requires their exact
-- object maps and carrier categories to align; no conversion shortcut follows.
