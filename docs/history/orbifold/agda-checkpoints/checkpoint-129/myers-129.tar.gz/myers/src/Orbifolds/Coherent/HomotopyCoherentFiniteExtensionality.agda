{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteExtensionality where

-- Actual finite stages are determined strictly by their raw cubical
-- coordinates in every degree. The additional function-extensionality
-- rule is visible and separate from interval/path extensionality.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.HomotopyCoherentActionData using (LawPair)
import Orbifolds.Coherent.HomotopyCoherentConeData as Data
import Orbifolds.Coherent.HomotopyCoherentFiniteStages as Finite
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.CubicalShellFillers as CF

module Extensionality {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  open Category C
  open Chains C
  open StrictFunctionExtensionality F

  Carrier : Dim → Type ℓ
  Carrier = Finite.Finite.Carrier C D E

  top : (n : Dim) → Data.Data.Top C D n (Carrier n)
  top n = Data.Data.top C D n (Finite.Finite.families C D E n)

  TopAgreement : (n : Dim) → Carrier n → Carrier n → SSet ℓ
  TopAgreement n s t = (y : Obj) (c : Chain n y)
    → outer (top n s y c) ≡ˢ outer (top n t y c)

  Agreement : (n : Dim) → Carrier n → Carrier n → SSet ℓ
  Agreement ozero s t = TopAgreement ozero s t
  Agreement (osuc n) s t = LawPair (Agreement n (s .fst) (t .fst))
    (TopAgreement (osuc n) s t)

  successor-extensionality : (n : Dim) (s t : Carrier (osuc n))
    → outer (s .fst) ≡ˢ outer (t .fst)
    → TopAgreement (osuc n) s t
    → outer s ≡ˢ outer t
  successor-extensionality n (s , fs) (.s , ft) reflˢ p = strict-cong
    (λ q → outer (s , inner q))
    (function-ext λ { (y , c) → Fillers.Action.filler-extensionality E (osuc n)
      (Finite.Finite.At.boundary-data C D E n s (y , c)) (p y c) })

  stage-extensionality : (n : Dim) (s t : Carrier n)
    → Agreement n s t → outer s ≡ˢ outer t
  stage-extensionality ozero s t p = function-ext λ y → p y (lift tt)
    where open import Cubical.Data.Unit using (tt)
  stage-extensionality (osuc n) s t p = successor-extensionality n s t
    (stage-extensionality n (s .fst) (t .fst) (LawPair.earlier p))
    (LawPair.current p)
