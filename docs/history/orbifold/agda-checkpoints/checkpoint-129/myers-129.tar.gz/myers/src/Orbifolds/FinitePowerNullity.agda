{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}
module Orbifolds.FinitePowerNullity where

-- Locality at R implies locality at every actual finite Cartesian power
-- of R. The equivalence proved is that of the constant map, including
-- the zero-dimensional power; no point of R or choice principle is used.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.Data.FinData.Base as FD

module Powers {ℓr ℓy : Level} (R : Type ℓr) (Y : Type ℓy) where
  Power : ℕ → Type ℓr
  Power n = FD.Fin n → R

  emptyPower : Power zero
  emptyPower ()

  cons : {n : ℕ} → R → Power n → Power (suc n)
  cons r v FD.zero = r
  cons r v (FD.suc i) = v i

  cons-eta : {n : ℕ} (v : Power (suc n))
    → cons (v FD.zero) (v ∘ FD.suc) ≡ v
  cons-eta v = funExt λ { FD.zero → refl ; (FD.suc _) → refl }

  uncurried : (n : ℕ) → (R → Power n → Y) → (Power (suc n) → Y)
  uncurried n f v = f (v FD.zero) (v ∘ FD.suc)

  curried : (n : ℕ) → (Power (suc n) → Y) → (R → Power n → Y)
  curried n f r v = f (cons r v)

  curry-equivalence : (n : ℕ)
    → (R → Power n → Y) ≃ (Power (suc n) → Y)
  curry-equivalence n = isoToEquiv
    (iso (uncurried n) (curried n)
      (λ f → funExt λ v → cong f (cons-eta v))
      (λ _ → refl))

  finite-power-nullity : isEquiv (const :> (Y → (R → Y)))
    → (n : ℕ) → isEquiv (const :> (Y → (Power n → Y)))
  finite-power-nullity nullR zero = isoToIsEquiv
    (iso const (λ f → f emptyPower)
      (λ f → funExt λ v → cong f (funExt λ ()))
      (λ _ → refl))
  finite-power-nullity nullR (suc n) = snd
    (compEquiv (const , nullR)
      (compEquiv
        (equivΠCod (λ (_ : R) → const , finite-power-nullity nullR n))
        (curry-equivalence n)))

  equivalent-power-nullity : {ℓa : Level} {A : Type ℓa}
    → (n : ℕ) → A ≃ Power n
    → isEquiv (const :> (Y → (R → Y)))
    → isEquiv (const :> (Y → (A → Y)))
  equivalent-power-nullity n coordinates nullR = snd
    (compEquiv (const , finite-power-nullity nullR n)
      (preCompEquiv coordinates))
