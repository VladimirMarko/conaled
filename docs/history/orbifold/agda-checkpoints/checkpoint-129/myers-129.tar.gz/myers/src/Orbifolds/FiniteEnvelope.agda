{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Myers, arXiv:2205.15887v1, Lemma 6.1.8:
-- subfinite quotients are exactly subobjects of finite quotients.
-- The forward construction is a genuine pushout in sets; the reverse
-- construction is a genuine pullback.  No decidability or choice is used.
module Orbifolds.FiniteEnvelope where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Function
open import Cubical.Foundations.Isomorphism using (Iso)
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.SumFin using (Fin)
open import Cubical.Functions.Embedding
open import Cubical.Functions.Surjection
open import Cubical.HITs.PropositionalTruncation as PT
  using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.SetTruncation as ST
import Cubical.HITs.Pushout as PO
open import Cubical.HITs.Pushout.KrausVonRaumer using (isEmbeddingInr)

open import Orbifolds.Association
open import Orbifolds.Compactness using (FinitelyEnumerable)

private
  variable
    ℓ ℓ' : Level

-- A set embedded in an arbitrary type stays embedded after set
-- truncation.  Paths in a set truncation are merely paths in the original
-- type; eliminating that mere path is valid because X is a set.
embeddingIntoSetTruncation : {X : Type ℓ} {Y : Type ℓ'}
  → isSet X → X ↪ Y → X ↪ ST.∥ Y ∥₂
embeddingIntoSetTruncation setX e =
  (λ x → ST.∣ e .fst x ∣₂) , injEmbedding ST.squash₂
    (λ { {x} {y} p → PT.rec (setX x y)
      (isEmbedding→Inj (e .snd) x y)
      (Iso.fun ST.PathIdTrunc₀Iso p) })

record FiniteEnvelopeAt (X : Type ℓ) (n : ℕ) : Type (ℓ-suc ℓ) where
  field
    Ambient : Type ℓ
    ambient-isSet : isSet Ambient
    enumeration : Fin n ↠ Ambient
    embedding : X ↪ Ambient

open FiniteEnvelopeAt public

module PushoutEnvelope {X : Type ℓ} {n : ℕ}
  (setX : isSet X) (W : SubfiniteSpan X n) where

  Pushout : Type ℓ
  Pushout = PO.Pushout (inclusion W .fst) (cover W .fst)

  -- The finite ordinal covers the pushout because Domain W covers X.
  finiteMap-surjective : isSurjection (PO.inl {f = inclusion W .fst} {g = cover W .fst})
  finiteMap-surjective = PO.elimProp _ (λ _ → squash₁)
    (λ i → ∣ i , refl ∣₁)
    (λ x → PT.map
      (λ { (a , p) → inclusion W .fst a , PO.push a ∙ cong PO.inr p })
      (cover W .snd x))

  AmbientSet : Type ℓ
  AmbientSet = ST.∥ Pushout ∥₂

  finiteMap : Fin n → AmbientSet
  finiteMap i = ST.∣ PO.inl i ∣₂

  finiteMap-surjective-after-truncation : isSurjection finiteMap
  finiteMap-surjective-after-truncation = ST.elim
    (λ _ → isProp→isSet squash₁)
    (λ z → PT.map (λ { (i , p) → i , cong ST.∣_∣₂ p })
      (finiteMap-surjective z))

  embedX : X ↪ AmbientSet
  embedX = embeddingIntoSetTruncation setX
    (PO.inr , isEmbeddingInr (inclusion W .fst) (cover W .fst) (inclusion W .snd))

  envelope : FiniteEnvelopeAt X n
  Ambient envelope = AmbientSet
  ambient-isSet envelope = ST.squash₂
  enumeration envelope = finiteMap , finiteMap-surjective-after-truncation
  embedding envelope = embedX

span→envelope : {X : Type ℓ} {n : ℕ}
  → isSet X → SubfiniteSpan X n → FiniteEnvelopeAt X n
span→envelope = PushoutEnvelope.envelope

-- Pull back the embedding along the finite enumeration.  Projection to
-- Fin n embeds because the original embedding has proposition fibers.
envelope→span : {X : Type ℓ} {n : ℕ}
  → FiniteEnvelopeAt X n → SubfiniteSpan X n
Domain (envelope→span {n = n} E) =
  Σ[ i ∈ Fin n ] fiber (embedding E .fst) (enumeration E .fst i)
inclusion (envelope→span E) = EmbeddingΣProp
  (λ i → isEmbedding→hasPropFibers (embedding E .snd) (enumeration E .fst i))
cover (envelope→span E) =
  (λ { (i , x , p) → x }) ,
  (λ x → PT.map
    (λ { (i , p) → (i , x , sym p) , refl })
    (enumeration E .snd (embedding E .fst x)))

bounded-envelope-characterization : {X : Type ℓ}
  → isSet X → (n : ℕ)
  → ∥ SubfiniteSpan X n ∥₁ ≃ ∥ FiniteEnvelopeAt X n ∥₁
bounded-envelope-characterization setX n =
  propBiimpl→Equiv squash₁ squash₁ (PT.map (span→envelope setX)) (PT.map envelope→span)

-- This matches the unbounded statement printed in Lemma 6.1.8.  Ambient
-- sethood is retained explicitly, as the lemma is about sets throughout.
EmbeddedInFinitelyEnumerableSet : Type ℓ → Type (ℓ-suc ℓ)
EmbeddedInFinitelyEnumerableSet {ℓ = ℓ} X =
  ∥ Σ[ Y ∈ Type ℓ ] (isSet Y × (FinitelyEnumerable Y × (X ↪ Y))) ∥₁

subfinite→finite-envelope : {X : Type ℓ}
  → isSet X → SubfinitelyEnumerable X → EmbeddedInFinitelyEnumerableSet X
subfinite→finite-envelope setX = PT.map
  (λ { (n , W) → let E = span→envelope setX W in
    Ambient E , ambient-isSet E , ∣ n , enumeration E ∣₁ , embedding E })

finite-envelope→subfinite : {X : Type ℓ}
  → EmbeddedInFinitelyEnumerableSet X → SubfinitelyEnumerable X
finite-envelope→subfinite = PT.rec squash₁
  (λ { (Y , setY , enumY , e) → PT.map
    (λ { (n , q) → n , envelope→span record
      { Ambient = Y ; ambient-isSet = setY ; enumeration = q ; embedding = e } })
    enumY })

-- Lemma 6.1.8, with both implications constructed rather than postulated.
subfinite-enumerable-envelope-characterization : {X : Type ℓ}
  → isSet X → SubfinitelyEnumerable X ≃ EmbeddedInFinitelyEnumerableSet X
subfinite-enumerable-envelope-characterization setX =
  propBiimpl→Equiv squash₁ squash₁
    (subfinite→finite-envelope setX) finite-envelope→subfinite
