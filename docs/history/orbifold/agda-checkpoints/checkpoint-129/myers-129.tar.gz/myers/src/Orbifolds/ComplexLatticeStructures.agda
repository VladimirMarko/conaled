{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ComplexLatticeStructures where

-- Actual complex lines with actual lattice subgroups.  The metric
-- condition quantifies over all real inner products and uses actual
-- positive rational radii.  The rank interpretation is explicit:
-- merely an additive group equivalence with Z² (finite free rank two).
-- No identification with a weaker rational-rank definition is claimed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Powerset
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (zero)
open import Cubical.Data.Int using (pos)
open import Cubical.Data.NatPlusOne using (1+_)
import Cubical.Data.Rationals.Base as Q
import Cubical.Data.Rationals.Order as QO
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Module.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
import Cubical.Algebra.Group.Subgroup as SG
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexPairs as CP
import Orbifolds.ComplexLines as CL
import Orbifolds.ComplexLineInnerProducts as CI
import Orbifolds.RationalCoefficients as RC
import Orbifolds.UpperHalfPlane as UH
import Orbifolds.StandardComplexLattice as ST
import Orbifolds.StandardLatticeMetric as SM

module Geometry {ℓ : Level} (R : CommRing ℓ)
  (kock : SF.RingContext.KockField R)
  (order : SF.RingContext.StrictOrder R)
  (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  module C = CP.Ring R
  module Lines = CL.Complex R
  module Forms = CI.Geometry R order
  module Rationals = RC.Ordered R kock order compatibility
  module H = UH.Geometry R kock order compatibility
  module Standard = ST.Geometry R kock order compatibility
  module Metric = SM.Geometry R kock order compatibility

  RationalPositive : Q.ℚ → Type ℓ-zero
  RationalPositive q = QO._<_ Q.[ pos zero / (1+ zero) ] q

  module At (L : Lines.Line) where
    Additive : Group ℓ
    Additive = LeftModule→Group (L .fst)

    Subgroup : Type (ℓ-suc ℓ)
    Subgroup = SG.Subgroup Additive

    Member : Subgroup → Lines.Carrier L → Type ℓ
    Member Λ x = Λ .fst x .fst

    Zero : Lines.Carrier L
    Zero = LeftModuleStr.0m (L .fst .snd)

    Radius : Subgroup → Forms.InnerProduct L → Type ℓ
    Radius Λ form = Σ[ q ∈ Q.ℚ ] RationalPositive q ×
      ((0r < Rationals.rational q) ×
        ((x : Lines.Carrier L) → Member Λ x
          → Forms.norm {L = L} form x < Rationals.rational q → x ≡ Zero))

    MetricallyDiscrete : Subgroup → Type ℓ
    MetricallyDiscrete Λ = (form : Forms.InnerProduct L) → PT.∥ Radius Λ form ∥₁

    metric-isProp : (Λ : Subgroup) → isProp (MetricallyDiscrete Λ)
    metric-isProp Λ = isPropΠ (λ _ → PT.squash₁)

    HasIntegralBasis : Subgroup → Type ℓ
    HasIntegralBasis Λ = PT.∥ GroupEquiv ST.IntegerPairs (SG.Subgroup→Group Additive Λ) ∥₁

    IsFiniteFreeLattice : Subgroup → Type ℓ
    IsFiniteFreeLattice Λ = MetricallyDiscrete Λ × HasIntegralBasis Λ

    lattice-laws-isProp : (Λ : Subgroup) → isProp (IsFiniteFreeLattice Λ)
    lattice-laws-isProp Λ = isProp× (metric-isProp Λ) PT.squash₁

    FiniteFreeLattice : Type (ℓ-suc ℓ)
    FiniteFreeLattice = Σ Subgroup IsFiniteFreeLattice

    lattice-isSet : isSet FiniteFreeLattice
    lattice-isSet = isSetΣSndProp (SG.isSetSubgroup Additive) lattice-laws-isProp

    predicate : FiniteFreeLattice → ℙ (Lines.Carrier L)
    predicate Λ = Λ .fst .fst

    lattice-path : {Λ Γ : FiniteFreeLattice} → predicate Λ ≡ predicate Γ → Λ ≡ Γ
    lattice-path equal = Σ≡Prop lattice-laws-isProp
      (Σ≡Prop (SG.isPropIsSubgroup Additive) equal)

  FiniteFreeLattice : Lines.Line → Type (ℓ-suc ℓ)
  FiniteFreeLattice = At.FiniteFreeLattice

  FiniteFreeModuli : Type (ℓ-suc ℓ)
  FiniteFreeModuli = Σ Lines.Line FiniteFreeLattice

  moduli-isGroupoid : isGroupoid FiniteFreeModuli
  moduli-isGroupoid = isGroupoidΣ Lines.line-groupoid
    (λ L → isSet→isGroupoid (At.lattice-isSet L))

  module Canonical = At Lines.canonical-line

  -- The canonical-line additive group has the same actual operations
  -- as ComplexPairs. We reproduce only the propositional closure laws;
  -- no equality of unrelated group-structure proof certificates is used.
  standard-subgroup : H.UpperHalfPlane → Canonical.Subgroup
  standard-subgroup τ .fst = Standard.standard-subset τ
  SG.isSubgroup.id-closed (standard-subgroup τ .snd) =
    SG.isSubgroup.id-closed (Standard.subgroup-laws τ)
  SG.isSubgroup.op-closed (standard-subgroup τ .snd) =
    SG.isSubgroup.op-closed (Standard.subgroup-laws τ)
  SG.isSubgroup.inv-closed (standard-subgroup τ .snd) =
    SG.isSubgroup.inv-closed (Standard.subgroup-laws τ)

  abstract
    standard-basis : (τ : H.UpperHalfPlane) → GroupEquiv ST.IntegerPairs
      (SG.Subgroup→Group Canonical.Additive (standard-subgroup τ))
    standard-basis τ = Standard.standard-basis τ .fst , makeIsGroupHom
      (λ v w → Σ≡Prop (Standard.member-isProp τ) (Standard.standard-additive τ v w))

    standard-metric : (τ : H.UpperHalfPlane) → Canonical.MetricallyDiscrete (standard-subgroup τ)
    standard-metric τ form = Metric.standard-metrically-discrete τ (Forms.canonical-to-plane form)

