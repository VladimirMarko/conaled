{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportModules where

-- Scalar structure and the constructed linear direct-sum universal
-- property. A commutative semiring suffices for this free-factor part;
-- no claim that an arbitrary module has a basis is made here.

open import Agda.Primitive using (Level; Set; lsuc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.CompactSeparation using (inl; inr)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using
  ( FiniteSupport; finite-support-path; map-finite-support )
open import Orbifolds.Intensional.FiniteSupportSums using (AdditiveMonoid; module Sums)
open import Orbifolds.Intensional.FiniteSupportUniversal

private variable ℓ : Level

record CommutativeSemiring (ℓ : Level) : Set (lsuc ℓ) where
  field
    additive : AdditiveMonoid ℓ
  open AdditiveMonoid additive public
  field
    one : Carrier
    _*_ : Carrier → Carrier → Carrier
    *-assoc : (a b c : Carrier) → (a * b) * c ≡ a * (b * c)
    *-comm : (a b : Carrier) → a * b ≡ b * a
    *-one-left : (a : Carrier) → one * a ≡ a
    *-one-right : (a : Carrier) → a * one ≡ a
    *-zero-left : (a : Carrier) → zero * a ≡ zero
    *-zero-right : (a : Carrier) → a * zero ≡ zero
    *-add-left : (a b c : Carrier) → (a + b) * c ≡ (a * c) + (b * c)
    *-add-right : (a b c : Carrier) → a * (b + c) ≡ (a * b) + (a * c)

record Semimodule (R : CommutativeSemiring ℓ) : Set (lsuc ℓ) where
  private module R = CommutativeSemiring R
  field
    additive : AdditiveMonoid ℓ
  open AdditiveMonoid additive public
  field
    _•_ : R.Carrier → Carrier → Carrier
    •-one : (v : Carrier) → R.one • v ≡ v
    •-assoc : (r s : R.Carrier) (v : Carrier) → (r R.* s) • v ≡ r • (s • v)
    •-zero : (r : R.Carrier) → r • zero ≡ zero
    zero-• : (v : Carrier) → R.zero • v ≡ zero
    •-add : (r : R.Carrier) (v w : Carrier) → r • (v + w) ≡ (r • v) + (r • w)
    add-• : (r s : R.Carrier) (v : Carrier) → (r R.+ s) • v ≡ (r • v) + (s • v)

regular-module : (R : CommutativeSemiring ℓ) → Semimodule R
Semimodule.additive (regular-module R) = CommutativeSemiring.additive R
Semimodule._•_ (regular-module R) = CommutativeSemiring._*_ R
Semimodule.•-one (regular-module R) = CommutativeSemiring.*-one-left R
Semimodule.•-assoc (regular-module R) = CommutativeSemiring.*-assoc R
Semimodule.•-zero (regular-module R) = CommutativeSemiring.*-zero-right R
Semimodule.zero-• (regular-module R) = CommutativeSemiring.*-zero-left R
Semimodule.•-add (regular-module R) = CommutativeSemiring.*-add-right R
Semimodule.add-• (regular-module R) = CommutativeSemiring.*-add-left R

IsLinear : {R : CommutativeSemiring ℓ} (M N : Semimodule R)
  → (Semimodule.Carrier M → Semimodule.Carrier N) → Set ℓ
IsLinear {R = R} M N f =
  Σ (IsAdditive (Semimodule.additive M) (Semimodule.additive N) f) λ _ →
    (r : CommutativeSemiring.Carrier R) (v : Semimodule.Carrier M) →
      f (Semimodule._•_ M r v) ≡ Semimodule._•_ N r (f v)

LinearMap : {R : CommutativeSemiring ℓ} (M N : Semimodule R) → Set ℓ
LinearMap M N = Σ (Semimodule.Carrier M → Semimodule.Carrier N) (IsLinear M N)

linear-additive : {R : CommutativeSemiring ℓ} {M N : Semimodule R}
  → LinearMap M N → AddHom (Semimodule.additive M) (Semimodule.additive N)
linear-additive h = fst h , fst (snd h)

linear-zero : {R : CommutativeSemiring ℓ} {M N : Semimodule R}
  → (h : LinearMap M N) → fst h (Semimodule.zero M) ≡ Semimodule.zero N
linear-zero {M = M} {N = N} h =
  additive-zero {M = Semimodule.additive M} {N = Semimodule.additive N}
    (linear-additive {M = M} {N = N} h)

linear-add : {R : CommutativeSemiring ℓ} {M N : Semimodule R}
  → (h : LinearMap M N) (v w : Semimodule.Carrier M)
  → fst h (Semimodule._+_ M v w) ≡ Semimodule._+_ N (fst h v) (fst h w)
linear-add {M = M} {N = N} h =
  additive-add {M = Semimodule.additive M} {N = Semimodule.additive N}
    (linear-additive {M = M} {N = N} h)

linear-scalar : {R : CommutativeSemiring ℓ} {M N : Semimodule R}
  → (h : LinearMap M N) (r : CommutativeSemiring.Carrier R) (v : Semimodule.Carrier M)
  → fst h (Semimodule._•_ M r v) ≡ Semimodule._•_ N r (fst h v)
linear-scalar h = snd (snd h)

linear-prop : (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
  → (M N : Semimodule R) (f : Semimodule.Carrier M → Semimodule.Carrier N)
  → isProp (IsLinear M N f)
linear-prop ext M N f = isPropΣ
  (additive-prop ext (Semimodule.additive M) (Semimodule.additive N) f)
  (λ _ → isPropΠ ext (λ r → isPropΠ ext (λ v → Semimodule.carrier-set N _ _)))

linear-path : (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ} {M N : Semimodule R}
  → {h k : LinearMap M N} → fst h ≡ fst k → h ≡ k
linear-path ext {M = M} {N = N} = Σ-path-prop (linear-prop ext M N)

identity-linear : {R : CommutativeSemiring ℓ} (M : Semimodule R) → LinearMap M M
identity-linear M = (λ v → v) , ((refl , λ v w → refl) , λ r v → refl)

compose-linear : {R : CommutativeSemiring ℓ} {M N P : Semimodule R}
  → LinearMap N P → LinearMap M N → LinearMap M P
compose-linear {M = M} {N = N} {P = P} g f = (λ v → fst g (fst f v)) ,
  (snd (compose-add-hom
    {M = Semimodule.additive M} {N = Semimodule.additive N} {P = Semimodule.additive P}
    (linear-additive {M = N} {N = P} g) (linear-additive {M = M} {N = N} f)) ,
    (λ r v → cong (fst g) (linear-scalar {M = M} {N = N} f r v)
      ∙ linear-scalar {M = N} {N = P} g r (fst f v)))

scalar-add-hom : {R : CommutativeSemiring ℓ} (M : Semimodule R)
  → CommutativeSemiring.Carrier R → AddHom (Semimodule.additive M) (Semimodule.additive M)
scalar-add-hom M r = Semimodule._•_ M r , (Semimodule.•-zero M r , Semimodule.•-add M r)

module Coordinates {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (M : Semimodule R) where

  private module R = CommutativeSemiring R
  private module M = Semimodule M
  module S = Sums ext classical equality M.additive

  scale : R.Carrier → FiniteSupport I M.zero → FiniteSupport I M.zero
  scale r = map-finite-support (M._•_ r) (M.•-zero r)

  coordinate-module : Semimodule R
  Semimodule.additive coordinate-module = S.finite-support-monoid
  Semimodule._•_ coordinate-module = scale
  Semimodule.•-one coordinate-module u = finite-support-path ext (ext (λ i → M.•-one (fst u i)))
  Semimodule.•-assoc coordinate-module r s u =
    finite-support-path ext (ext (λ i → M.•-assoc r s (fst u i)))
  Semimodule.•-zero coordinate-module r = finite-support-path ext (ext (λ i → M.•-zero r))
  Semimodule.zero-• coordinate-module u = finite-support-path ext (ext (λ i → M.zero-• (fst u i)))
  Semimodule.•-add coordinate-module r u v =
    finite-support-path ext (ext (λ i → M.•-add r (fst u i) (fst v i)))
  Semimodule.add-• coordinate-module r s u =
    finite-support-path ext (ext (λ i → M.add-• r s (fst u i)))

  delta-scalar : (a : I) (r : R.Carrier) (v : M.Carrier) (i : I)
    → S.delta a (r M.• v) i ≡ r M.• S.delta a v i
  delta-scalar a r v i with equality i a
  ... | inl equal = refl
  ... | inr different = sym (M.•-zero r)

  single-linear : I → LinearMap M coordinate-module
  single-linear a = S.single a ,
    ((S.single-zero a , S.single-add a) ,
      (λ r v → finite-support-path ext (ext (delta-scalar a r v))))

module LinearDirectSum {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (M N : Semimodule R) where

  module CM = Coordinates ext classical equality M
  module CN = Coordinates ext classical equality N
  module DS = DirectSum ext classical equality (Semimodule.additive M) (Semimodule.additive N)
  private module M = Semimodule M
  private module N = Semimodule N

  additive-extension : (I → LinearMap M N) → AddHom (Semimodule.additive CM.coordinate-module) N.additive
  additive-extension h = DS.extension (λ i → linear-additive {M = M} {N = N} (h i))

  extension-scalar : (h : I → LinearMap M N)
    → (r : CommutativeSemiring.Carrier R) (u : Semimodule.Carrier CM.coordinate-module)
    → fst (additive-extension h) (CM.scale r u) ≡ r N.• fst (additive-extension h) u
  extension-scalar h r u = cong (λ k → fst k u)
    (DS.hom-determined-on-singles
      (compose-add-hom
        {M = Semimodule.additive CM.coordinate-module}
        {N = Semimodule.additive CM.coordinate-module} {P = N.additive}
        (additive-extension h) (scalar-add-hom CM.coordinate-module r))
      (compose-add-hom
        {M = Semimodule.additive CM.coordinate-module} {N = N.additive} {P = N.additive}
        (scalar-add-hom N r) (additive-extension h))
      (λ i v →
        cong (fst (additive-extension h))
          (sym (linear-scalar {M = M} {N = CM.coordinate-module} (CM.single-linear i) r v))
        ∙ DS.extension-on-single (λ j → linear-additive {M = M} {N = N} (h j)) i (r M.• v)
        ∙ linear-scalar {M = M} {N = N} (h i) r v
        ∙ cong (N._•_ r) (sym
          (DS.extension-on-single (λ j → linear-additive {M = M} {N = N} (h j)) i v))))

  extension : (I → LinearMap M N) → LinearMap CM.coordinate-module N
  extension h = fst (additive-extension h) , (snd (additive-extension h) , extension-scalar h)

  restriction : LinearMap CM.coordinate-module N → I → LinearMap M N
  restriction k i = compose-linear {M = M} {N = CM.coordinate-module} {P = N} k (CM.single-linear i)

  extension-on-single : (h : I → LinearMap M N) (i : I) (v : M.Carrier)
    → fst (extension h) (CM.S.single i v) ≡ fst (h i) v
  extension-on-single h = DS.extension-on-single (λ i → linear-additive {M = M} {N = N} (h i))

  linear-direct-sum-universal :
    Equiv (LinearMap CM.coordinate-module N) (I → LinearMap M N)
  linear-direct-sum-universal = equiv restriction extension
    (λ h → ext (λ i → linear-path ext {M = M} {N = N} (ext (extension-on-single h i))))
    (λ k → linear-path ext {M = CM.coordinate-module} {N = N}
      (ext (DS.extension-restriction (linear-additive {M = CM.coordinate-module} {N = N} k))))

  linear-determined-on-singles : (k l : LinearMap CM.coordinate-module N)
    → ((i : I) (v : M.Carrier) → fst k (CM.S.single i v) ≡ fst l (CM.S.single i v))
    → k ≡ l
  linear-determined-on-singles k l same = linear-path ext {M = CM.coordinate-module} {N = N}
    (cong fst (DS.hom-determined-on-singles
      (linear-additive {M = CM.coordinate-module} {N = N} k)
      (linear-additive {M = CM.coordinate-module} {N = N} l) same))
