{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalFillerPathTransport where

-- Ordinary transport of fillers can be compared along pointwise strict
-- changes of their shell path. This keeps the whole dependent path;
-- no inner path is replaced by a strict equality.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Transport using (subst⁻-filler)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

path-along-strict-shells : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (b b' : I → CS.Shell (toNat n) X)
  (e : (i : I) → outer (b i) ≡ˢ outer (b' i))
  (v : CF.Filler (toNat n) (b i1))
  → PathP (λ i → CF.Filler (toNat n) (b' i))
      (cast-filler n (e i0) (subst (CF.Filler (toNat n)) (λ i → b (~ i)) v))
      (cast-filler n (e i1) v)
path-along-strict-shells n b b' e v i =
  cast-filler n (e i) (subst⁻-filler (CF.Filler (toNat n)) (λ i → b i) v (~ i))

strict-end-dependent-path : ∀ {ℓ} {A : I → Type ℓ}
  (p : (i : I) → A i) {x : A i0} {y : A i1}
  → outer (p i0) ≡ˢ outer x → outer (p i1) ≡ˢ outer y → PathP A x y
strict-end-dependent-path p reflˢ reflˢ i = p i
