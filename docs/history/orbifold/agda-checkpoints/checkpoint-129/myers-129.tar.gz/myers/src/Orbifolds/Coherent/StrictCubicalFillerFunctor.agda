{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalFillerFunctor where

-- Identity and composition of the literal filler action, with the
-- actual derived shell comparisons as its endpoint casts.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (map-cube; StrictCubicalExtensionality)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalShellFunctor as ShellFunctor
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

module Functoriality {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module Cube = Cubes.Extensional E
  module Filler = Fillers.Action E
  module Shell = Shells.Action E
  module Boundary = ShellFunctor.Functoriality E

  map-identity : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X) (c : CF.Filler (toNat n) b)
    → outer (cast-filler n (Boundary.map-identity n b) (Filler.map-filler n (idfun X) b c))
      ≡ˢ outer c
  map-identity n {X} b c = Filler.filler-extensionality n b
    (strict-trans
      (cast-forget n (Boundary.map-identity n b) (Filler.map-filler n (idfun X) b c))
      (strict-trans
        (Filler.map-filler-forget n (idfun X) b c)
        (Cube.map-identity n (CF.forget-filler (toNat n) b c))))

  map-compose : (n : Dim) {X Y Z : Type ℓ} (g : Y → Z) (f : X → Y)
    (b : CS.Shell (toNat n) X) (c : CF.Filler (toNat n) b)
    → outer (cast-filler n (Boundary.map-compose n g f b)
        (Filler.map-filler n g (Shell.map-shell n f b) (Filler.map-filler n f b c)))
      ≡ˢ outer (Filler.map-filler n (g ∘ f) b c)
  map-compose n g f b c = Filler.filler-extensionality n (Shell.map-shell n (g ∘ f) b)
    (strict-trans
      (cast-forget n (Boundary.map-compose n g f b)
        (Filler.map-filler n g (Shell.map-shell n f b) (Filler.map-filler n f b c)))
      (strict-trans
        (Filler.map-filler-forget n g (Shell.map-shell n f b) (Filler.map-filler n f b c))
        (strict-trans
          (strict-cong (λ z → outer (map-cube n g (inner z))) (Filler.map-filler-forget n f b c))
          (strict-trans
            (Cube.map-compose n g f (CF.forget-filler (toNat n) b c))
            (strict-sym (Filler.map-filler-forget n (g ∘ f) b c))))))
