{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispSetReflection where

-- Lemma 5.2.7: crystalline reflection of a crisp set is a set.
-- The sole geometric assumption is Axiom 4 with its literal crisp
-- diagram binders; sethood itself need not be supplied crisply.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base using (CommRing)
open import Cubical.Modalities.Modality using (Modality)
import Orbifolds.CrispGeometry as CG
import Orbifolds.ModalPullbacks as MP
import Orbifolds.ModalSetReflection as MS

module Generic {@♭ ℓ : Level} (@♭ M : Modality ℓ) where
  open Modality M using (◯)
  module Preserve = MP.Theory M

  CrispPullbackPreservation : Type (ℓ-suc ℓ)
  CrispPullbackPreservation = (@♭ X Y Z : Type ℓ)
    (@♭ f : X → Z) (@♭ g : Y → Z) → Preserve.PullbackDiagram.Preserved f g

  -- These aliases depend only on crisp data. Using the very same named
  -- diagonal on both sides retains the actual comparison. All conversion
  -- checks here take place at an abstract modality, before specialization
  -- to the concrete higher-inductive nullification.
  module At (@♭ X : Type ℓ) where
    module Reflection = MS.Theory.Set M X

    diagonal-preserved : CrispPullbackPreservation
      → Preserve.PullbackDiagram.Preserved
        Reflection.Diagonal.diagonal Reflection.Diagonal.diagonal
    diagonal-preserved preserve = preserve X X (X × X)
      Reflection.Diagonal.diagonal Reflection.Diagonal.diagonal

    reflection-isSet : CrispPullbackPreservation
      → isSet X → isSet (◯ X)
    reflection-isSet preserve setX =
      Reflection.set-reflection setX (diagonal-preserved preserve)

  crisp-set-reflection : CrispPullbackPreservation
    → (@♭ X : Type ℓ) → isSet X → isSet (◯ X)
  crisp-set-reflection preserve X = At.reflection-isSet X preserve

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ) where
  open CG.Context R

  crisp-set-reflection : CrispPullbackPreservation
    → (@♭ X : Type ℓ) → isSet X → isSet (Infinitesimal.Im X)
  crisp-set-reflection = Generic.crisp-set-reflection Infinitesimal.CrystallineModality
