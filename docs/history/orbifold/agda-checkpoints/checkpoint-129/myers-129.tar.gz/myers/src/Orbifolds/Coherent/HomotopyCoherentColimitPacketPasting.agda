{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting where

-- Compose over a neutral, already constructed cell packet.  The first
-- path's endpoint is inferred from the packet's own naturality path;
-- it is never retyped as a reconstructed pullback predicate.  All
-- factors, their right association, and their projected paths are kept.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.HomotopyCoherentColimitRestrictionTriangle using (typeOf)
open import Orbifolds.Coherent.StrictImagePaths using (strict-image-sym-path)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.HomotopyCoherentUnifiedLiteralFiniteCellMaps as CellMaps
import Orbifolds.Coherent.HomotopyCoherentColimitLiteralCellPathPasting as FirstPasting
import Orbifolds.Coherent.NaturalQuotedCellCanonicalPackage as Package
import Orbifolds.Coherent.TriplePathPasting as Triple
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
open import Orbifolds.Coherent.TriplePathInference
  using (inference-frozen-triple; inference-frozen-triple-strict)

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module CD = Cocones.Functoriality C D E F using (Cocone)
  module SD = Comparison.Comparison C D E F n source
    using (Index; Coefficient; original-boundary)
  module TG = Comparison.Comparison C G E F n target
    using (Coefficient; original-boundary; compare)

  module Packet = Package.Construction E (osuc n)
    (Triangles.space C D E F n source) (Triangles.space C G E F n target)
    SD.Index SD.Coefficient TG.Coefficient SD.original-boundary TG.original-boundary
    f (λ c → Transformations.ForCategory.Transformation.component α (c .fst))
    (CellMaps.Construction.boundary-path C D G α E F n source target f triangle)
    using (Inputs; module Inputs; canonical)

  module ForInput (inputs : Packet.Inputs) where
    module Data = Packet.Inputs inputs
      using (Y; h; s; t; p; p₀; p-constructed; base-path; p-first; r)

    -- These are the original packet's proved construction and projection
    -- laws, not new premises on a homotopy-coherent colimit triangle.
    open Data using (p; p₀; p-constructed; base-path; p-first) public

    module First = FirstPasting.Construction.Instance C D E F n source
      Data.Y Data.h _ Data.p
      using (value; prefix; constructed)
    open First public renaming
      (value to first; prefix to first-prefix; constructed to first-construction)

    -- Boundary data, actual map and middle proof share the unified
    -- finite-cell construction. Keep its complete lower-path computation.
    module Middle = CellMaps.Construction.At
      C D G α E F n source target f triangle Data.Y
      using (comparison-square; comparison-prefix; lower-path)

    middle : _
    middle = Middle.comparison-square Data.s

    middle-prefix : _
    middle-prefix = Middle.comparison-prefix Data.s

    lower-path : _
    lower-path = Middle.lower-path (Data.s .fst)

    last : _
    last = strict-image-sym-path (typeOf Data.s) (CD.Cocone Data.Y (osuc n))
      (λ s → Restriction.Restriction.finite-restriction C D G α E F
        Data.Y (osuc n) (TG.compare Data.Y s)) Data.t Data.s Data.r

    -- Each checked field is the original Triple.Pasting field application.
    -- Its four endpoint arguments are inferred inside restricted inference.
    value : _
    value = inference-frozen-triple
      Comparison.Comparison.compare Literal.Map.TargetSpace.pullback
      Triple.Pasting.value
      (CD.Cocone Data.Y (osuc n)) (CD.Cocone Data.Y n)
      (λ (s : CD.Cocone Data.Y (osuc n)) → s .fst)
      first middle last

    constructed : _
    constructed = inference-frozen-triple-strict
      Comparison.Comparison.compare Literal.Map.TargetSpace.pullback
      Triple.Pasting.constructed
      (CD.Cocone Data.Y (osuc n)) (CD.Cocone Data.Y n)
      (λ (s : CD.Cocone Data.Y (osuc n)) → s .fst)
      first middle last

    prefix : _
    prefix = inference-frozen-triple
      Comparison.Comparison.compare Literal.Map.TargetSpace.pullback
      Triple.Pasting.prefix
      (CD.Cocone Data.Y (osuc n)) (CD.Cocone Data.Y n)
      (λ (s : CD.Cocone Data.Y (osuc n)) → s .fst)
      first middle last
