{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConditionalIntegerLattices where

-- The rank-two version of the conditional subgroup diagnostic.
-- H_P x Z embeds into Z² and contains 2Z². An actual finite-free
-- rank-two basis, even merely specified, decides the ordinary P.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ; pos; isSetℤ)
import Cubical.Data.Int.Divisibility as Div
open import Cubical.Relation.Nullary using (Dec; yes; no; ¬_; isPropDec)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.DirProd
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom; compGroupHom)
open import Cubical.Algebra.Group.Instances.Int using (ℤGroup)
open import Cubical.Algebra.Group.ZAction using (_ℤ[_]·_; homPresℤ·; ℤ·≡·)
open import Cubical.Functions.Embedding using (isEmbedding; injEmbedding)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.ConditionalIntegerSubgroups as Conditional
import Orbifolds.IntegerPairMatrices as Pair

open Conditional using (Even; one-not-even)
module Z = Conditional.Z

abstract
  pair-hom-linear-combination : (f : GroupHom Pair.Pairs ℤGroup) (v : ℤ × ℤ)
    → f .fst v ≡ Z._+_
      (Z._·_ (v .fst) (f .fst Pair.Mat.basis₁))
      (Z._·_ (v .snd) (f .fst Pair.Mat.basis₂))
  pair-hom-linear-combination f (m , n) = cong (f .fst) (Pair.pair-decomposition (m , n))
    ∙ IsGroupHom.pres· (f .snd) (m ℤ[ Pair.Pairs ]· Pair.Mat.basis₁)
        (n ℤ[ Pair.Pairs ]· Pair.Mat.basis₂)
    ∙ cong₂ Z._+_
      (homPresℤ· f Pair.Mat.basis₁ m ∙ sym (ℤ·≡· m (f .fst Pair.Mat.basis₁)))
      (homPresℤ· f Pair.Mat.basis₂ n ∙ sym (ℤ·≡· n (f .fst Pair.Mat.basis₂)))

  even-on-basis→even-image : (f : GroupHom Pair.Pairs ℤGroup)
    → Even (f .fst Pair.Mat.basis₁) → Even (f .fst Pair.Mat.basis₂)
    → (v : ℤ × ℤ) → Even (f .fst v)
  even-on-basis→even-image f first second v =
    subst Even (sym (pair-hom-linear-combination f v))
      (Div.∣-+ (Div.∣-right· {n = v .fst} first)
        (Div.∣-right· {n = v .snd} second))

module Proposition {ℓ : Level} (P : Type ℓ) (propP : isProp P) where
  module One = Conditional.Proposition P propP

  GroupH₂ : Group ℓ
  GroupH₂ = DirProd One.GroupH ℤGroup

  Carrier = GroupH₂ .fst

  inclusion : GroupHom GroupH₂ Pair.Pairs
  inclusion .fst (x , n) = x .fst , n
  inclusion .snd = makeIsGroupHom (λ _ _ → refl)

  inclusion-embedding : isEmbedding (inclusion .fst)
  inclusion-embedding = injEmbedding (isSet× isSetℤ isSetℤ)
    (λ p → ΣPathP (Σ≡Prop One.member-prop (cong fst p) , cong snd p))

  doubling : GroupHom Pair.Pairs GroupH₂
  doubling .fst (m , n) = One.doubling .fst m , Z._·_ (pos 2) n
  doubling .snd = makeIsGroupHom λ (m , n) (m' , n') → ΣPathP
    (IsGroupHom.pres· (One.doubling .snd) m m' , Z.·DistR+ (pos 2) n n')

  inclusion-after-doubling : (v : ℤ × ℤ)
    → inclusion .fst (doubling .fst v)
      ≡ (Z._·_ (pos 2) (v .fst) , Z._·_ (pos 2) (v .snd))
  inclusion-after-doubling v = refl

  doubling-after-inclusion : (x : Carrier)
    → doubling .fst (inclusion .fst x) ≡ GroupStr._·_ (GroupH₂ .snd) x x
  doubling-after-inclusion (x , n) = ΣPathP
    (One.doubling-after-inclusion x , cong (Z._+_ n) (Z.+IdR n))

  first-coordinate : GroupHom GroupH₂ ℤGroup
  first-coordinate = (λ x → x .fst .fst) , makeIsGroupHom (λ _ _ → refl)

  module Basis (e : GroupEquiv Pair.Pairs GroupH₂) where
    forward : GroupHom Pair.Pairs GroupH₂
    forward = e .fst .fst , e .snd

    projected : GroupHom Pair.Pairs ℤGroup
    projected = compGroupHom forward first-coordinate

    first-member : One.Member (projected .fst Pair.Mat.basis₁)
    first-member = e .fst .fst Pair.Mat.basis₁ .fst .snd

    second-member : One.Member (projected .fst Pair.Mat.basis₂)
    second-member = e .fst .fst Pair.Mat.basis₂ .fst .snd

    both-even→not-proposition : Even (projected .fst Pair.Mat.basis₁)
      → Even (projected .fst Pair.Mat.basis₂) → ¬ P
    both-even→not-proposition first second p = one-not-even
      (subst Even (cong (first-coordinate .fst) (secEq (e .fst) target))
        (even-on-basis→even-image projected first second (invEq (e .fst) target)))
      where
      target : Carrier
      target = (pos 1 , One.proposition-member p (pos 1)) , pos 0

    decision : Dec P
    decision with Div.dec∣ (pos 2) (projected .fst Pair.Mat.basis₁)
                | Div.dec∣ (pos 2) (projected .fst Pair.Mat.basis₂)
    ... | yes first | yes second = no (both-even→not-proposition first second)
    ... | no first | _ = yes (One.odd-member→proposition first first-member)
    ... | yes _ | no second = yes (One.odd-member→proposition second second-member)

  integral-basis→decidable : GroupEquiv Pair.Pairs GroupH₂ → Dec P
  integral-basis→decidable e = Basis.decision e

  merely-integral-basis→decidable : PT.∥ GroupEquiv Pair.Pairs GroupH₂ ∥₁ → Dec P
  merely-integral-basis→decidable = PT.rec (isPropDec propP) integral-basis→decidable
