{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarComparison where

-- The literal full bar comparison exists before any tinyness or
-- discreteness hypothesis. Every successor is the specified map of
-- actual cell spans followed by the actual power/pushout comparison.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Nat using (ℕ)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowerBarInterface as PowerStages
import Orbifolds.CellularPresentationComparisons as Comparisons
import Orbifolds.TinyCellularPresentations as Operations
import Orbifolds.Coherent.PowerCellularCoconeNaturality as Generic

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module Bar = PowerStages.Construction C D E F T
  module Original = Bar.Original
  module Powered = Bar.Powered
  module RD = Bar.RD
  module RP = Bar.RP
  module Comparison = Comparisons.Theory (Operations.Power.operations T)
    using (RelativeMap; module RelativeMap)

  relative-map : (n : Dim) (original : RD.Represented n) (powered : RP.Represented n)
    (state : Bar.State n original powered)
    → Comparison.RelativeMap (Original.presentation n original) (Powered.presentation n powered)
        (Bar.State.q state)
  Comparison.RelativeMap.on-boundary (relative-map n original powered state) =
    Bar.Step.on-boundary n original powered state
  Comparison.RelativeMap.on-cell (relative-map n original powered state) =
    Bar.Step.on-cell n original powered state
  Comparison.RelativeMap.attachment-square (relative-map n original powered state) =
    Bar.Step.attachment-square n original powered state
  Comparison.RelativeMap.boundary-square (relative-map n original powered state) =
    Bar.Step.boundary-square n original powered state
  Comparison.RelativeMap.next (relative-map n original powered state) =
    relative-map (osuc n) (Bar.OriginalStages.Step.next n original) (Bar.PoweredStages.Step.next n powered)
      (Bar.advance n original powered state)

  module Realization = Comparisons.Theory.Realization (Operations.Power.operations T)
    Original.bar-presentation Powered.bar-presentation
    (Bar.State.q Bar.initial) (relative-map ozero RD.initial RP.initial Bar.initial)
    using (state; comparison; stage-map; boundary-map; cell-map; stage-computation; sequence-computation)

  comparison : Powered.Colimit → T → Original.Colimit
  comparison = Realization.comparison

  open Realization using (stage-map; boundary-map; cell-map; stage-computation; sequence-computation) public

  module Core = Generic.Power T Original.bar-presentation Powered.bar-presentation
    (Bar.State.q Bar.initial) (relative-map ozero RD.initial RP.initial Bar.initial)
    using (direct-evaluation; evaluation-computation; module Mapping)

  open Core using (direct-evaluation; evaluation-computation) public
