{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalQuotedFillers where

-- A nullhomotopy of a sphere map gives a filler of its literal quoted
-- shell. This comparison is an equivalence and commutes with the actual
-- coordinate action, including its specified strict boundary cast.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Path using (symIso)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path; strict-end-path-value)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler)
import Orbifolds.Coherent.StrictCubicalFillerMaps as FM
import Orbifolds.Coherent.StrictCubicalShellMaps as SM
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as SR
import Orbifolds.Coherent.NaturalCubicalFillerBoundary as NB
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)

module Natural {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module F = FM.Action E
  module S = SM.Action E
  module R = SR.Representation E
  module N = NB.Natural E

  SphereNull : (n : Dim) {X : Type ℓ} → (SphereBoundary (toNat n) → X) → Type ℓ
  SphereNull n {X} h = Σ[ x ∈ X ] (h ≡ (λ _ → x))

  map-sphere-null : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (h : SphereBoundary (toNat n) → X) → SphereNull n h → SphereNull n (f ∘ h)
  map-sphere-null n f h (x , p) = f x , (λ i s → f (p i s))

  cast-null : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    → outer b ≡ˢ outer b' → N.ShellNull n b → N.ShellNull n b'
  cast-null n e (x , p) = x , strict-end-path (λ i → p i) reflˢ e

  fill-cast : (n : Dim) {X : Type ℓ} {b b' : CS.Shell (toNat n) X}
    (e : outer b ≡ˢ outer b') (u : N.ShellNull n b)
    → cast-filler n e (N.fill-shell-null n b u)
      ≡ N.fill-shell-null n b' (cast-null n e u)
  fill-cast n reflˢ (x , p) = refl

  quote-null : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    → SphereNull n h → N.ShellNull n (R.quote-shell n h)
  quote-null n h (x , p) = x , strict-end-path
    (λ i → R.quote-shell n (p (~ i))) (R.quote-constant n x) reflˢ

  quote-null-value : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    (x : X) (p : h ≡ (λ _ → x)) (i : I)
    → outer (quote-null n h (x , p) .snd i) ≡ˢ outer (R.quote-shell n (p (~ i)))
  quote-null-value n h x p i = strict-end-path-value
    (λ j → R.quote-shell n (p (~ j))) (R.quote-constant n x) reflˢ i

  quote-null-equivalence : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    → SphereNull n h ≃ N.ShellNull n (R.quote-shell n h)
  quote-null-equivalence n {X} h = Σ-cong-equiv-snd λ x →
    isoToEquiv symIso ∙ₑ congEquiv (R.quote-equivalence n X)
      ∙ₑ SR.cast-path-equivalence (R.quote-constant n x) reflˢ

  quote-null-computation : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    (u : SphereNull n h) → quote-null-equivalence n h .fst u ≡ quote-null n h u
  quote-null-computation n h (x , p) = ΣPathP (refl ,
    SR.cast-path-computation (R.quote-constant n x) reflˢ
      (λ i → R.quote-shell n (p (~ i))))

  quote-null-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (h : SphereBoundary (toNat n) → X) (u : SphereNull n h)
    → outer (cast-null n (R.quote-natural n f h)
        (N.map-null n f (R.quote-shell n h) (quote-null n h u)))
      ≡ˢ outer (quote-null n (f ∘ h) (map-sphere-null n f h u))
  quote-null-natural n f h (x , p) = strict-cong (λ q → outer (f x , inner q))
    (path-ext λ i → strict-trans
      (strict-end-path-value
        (λ j → N.map-null n f (R.quote-shell n h) (quote-null n h (x , p)) .snd j)
        reflˢ (R.quote-natural n f h) i)
      (strict-trans
        (strict-end-path-value
          (λ j → S.map-shell n f (quote-null n h (x , p) .snd j))
          (N.constant-shell-natural n f x) reflˢ i)
        (strict-trans
          (strict-cong (λ b → outer (S.map-shell n f (inner b))) (quote-null-value n h x p i))
          (strict-trans (R.quote-natural n f (p (~ i)))
            (strict-sym (quote-null-value n (f ∘ h) (f x)
              (λ j s → f (p j s)) i))))))

  quoted-fill : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    → SphereNull n h → CF.Filler (toNat n) (R.quote-shell n h)
  quoted-fill n h u = N.fill-shell-null n (R.quote-shell n h) (quote-null n h u)

  quoted-fill-isEquiv : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    → isEquiv (quoted-fill n h)
  quoted-fill-isEquiv n h = subst isEquiv
    (funExt λ u → cong (N.fill-shell-null n (R.quote-shell n h)) (quote-null-computation n h u))
    ((quote-null-equivalence n h ∙ₑ N.fill-shell-null-equivalence n (R.quote-shell n h)) .snd)

  quoted-fill-equivalence : (n : Dim) {X : Type ℓ} (h : SphereBoundary (toNat n) → X)
    → SphereNull n h ≃ CF.Filler (toNat n) (R.quote-shell n h)
  quoted-fill-equivalence n h = quoted-fill n h , quoted-fill-isEquiv n h

  quoted-fill-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    (h : SphereBoundary (toNat n) → X) (u : SphereNull n h)
    → cast-filler n (R.quote-natural n f h)
        (F.map-filler n f (R.quote-shell n h) (quoted-fill n h u))
      ≡ quoted-fill n (f ∘ h) (map-sphere-null n f h u)
  quoted-fill-natural n f h u =
    cong (cast-filler n (R.quote-natural n f h))
      (N.fill-shell-null-natural n f (R.quote-shell n h) (quote-null n h u))
    ∙ fill-cast n (R.quote-natural n f h)
        (N.map-null n f (R.quote-shell n h) (quote-null n h u))
    ∙ cong (N.fill-shell-null n (R.quote-shell n (f ∘ h)))
        (strict-to-path (quote-null-natural n f h u))
