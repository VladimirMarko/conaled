{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.NaturalCubicalFillerBoundary where

-- Actual fillers are represented by paths from constant shells.  The
-- forward comparison is literal dependent substitution, and its
-- naturality is proved for the direct coordinate action on fillers.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Transport using (substCommSlice)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.StrictCubicalFillerMaps as FM
import Orbifolds.Coherent.StrictCubicalShellMaps as SM
import Orbifolds.Coherent.StrictCubicalTotalIsomorphism as TI
import Orbifolds.Coherent.StrictCubicalFillers as FB
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as SR
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

subst-strict-start : ∀ {ℓ ℓ'} {A : Type ℓ} (B : A → Type ℓ')
  {a a' b : A} (e : outer a ≡ˢ outer a') (p : a ≡ b) (u : B a)
  → subst B p u ≡ subst B (strict-end-path (λ i → p i) e reflˢ)
      (subst B (strict-to-path e) u)
subst-strict-start B reflˢ p u = cong (subst B p) (sym (substRefl {B = B} u))

subst-filler-strict-start : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  {a a' b : CS.Shell (toNat n) X} (e : outer a ≡ˢ outer a')
  (p : a ≡ b) (u : CF.Filler (toNat n) a)
  → subst (CF.Filler (toNat n)) p u
    ≡ subst (CF.Filler (toNat n)) (strict-end-path (λ i → p i) e reflˢ)
        (cast-filler n e u)
subst-filler-strict-start n reflˢ p u = refl

module Natural {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  module F = FM.Action E
  module S = SM.Action E
  module T = TI.Natural E
  module B = FB.Boundary E
  module R = SR.Representation E

  constant-shell : (n : Dim) {X : Type ℓ} → X → CS.Shell (toNat n) X
  constant-shell n x = CS.restriction (toNat n) (CS.constant-cube (toNat n) x)

  ShellNull : (n : Dim) {X : Type ℓ} → CS.Shell (toNat n) X → Type ℓ
  ShellNull n {X} b = Σ[ x ∈ X ] (constant-shell n x ≡ b)

  constant-shell-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (x : X)
    → outer (S.map-shell n f (constant-shell n x)) ≡ˢ outer (constant-shell n (f x))
  constant-shell-natural n f x = strict-trans
    (S.restriction-natural n f (CS.constant-cube (toNat n) x))
    (strict-cong (λ c → outer (CS.restriction (toNat n) (inner c)))
      (T.constant-natural n f x))

  map-null : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    → ShellNull n b → ShellNull n (S.map-shell n f b)
  map-null n f b (x , p) = f x , strict-end-path
    (λ i → S.map-shell n f (p i)) (constant-shell-natural n f x) reflˢ

  fill-shell-null : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → ShellNull n b → CF.Filler (toNat n) b
  fill-shell-null n b (x , p) = subst (CF.Filler (toNat n)) p
    (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x))

  fill-shell-null-equivalence : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → ShellNull n b ≃ CF.Filler (toNat n) b
  fill-shell-null-equivalence n {X} b =
    Σ-cong-equiv (R.constant-equivalence n X) (λ _ → idEquiv _)
      ∙ₑ CF.fiber-filler-equivalence (toNat n) b

  fill-shell-null-computation : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X) (h : ShellNull n b)
    → fill-shell-null-equivalence n b .fst h ≡ fill-shell-null n b h
  fill-shell-null-computation n b h = refl

  constant-filler-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (x : X)
    → outer (cast-filler n (constant-shell-natural n f x)
        (F.map-filler n f (constant-shell n x)
          (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x))))
      ≡ˢ outer (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) (f x)))
  constant-filler-natural n f x = F.filler-extensionality n (constant-shell n (f x))
    (strict-trans
      (cast-forget n (constant-shell-natural n f x)
        (F.map-filler n f (constant-shell n x)
          (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x))))
      (strict-trans
        (F.map-filler-forget n f (constant-shell n x)
          (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x)))
        (strict-trans
          (strict-cong (λ c → outer (map-cube n f (inner c)))
            (B.forget-canonical-strict n (CS.constant-cube (toNat n) x)))
          (strict-trans (T.constant-natural n f x)
            (strict-sym (B.forget-canonical-strict n (CS.constant-cube (toNat n) (f x))))))))

  fill-shell-null-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    (h : ShellNull n b)
    → F.map-filler n f b (fill-shell-null n b h)
      ≡ fill-shell-null n (S.map-shell n f b) (map-null n f b h)
  fill-shell-null-natural n f b (x , p) =
    sym (substCommSlice (CF.Filler (toNat n))
      (λ a → CF.Filler (toNat n) (S.map-shell n f a))
      (F.map-filler n f) p
      (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x)))
    ∙ subst-filler-strict-start n (constant-shell-natural n f x)
        (λ i → S.map-shell n f (p i))
        (F.map-filler n f (constant-shell n x)
          (CF.canonical-filler (toNat n) (CS.constant-cube (toNat n) x)))
    ∙ cong (subst (CF.Filler (toNat n))
        (strict-end-path (λ i → S.map-shell n f (p i))
          (constant-shell-natural n f x) reflˢ))
        (strict-to-path (constant-filler-natural n f x))

  unfill : (n : Dim) {X : Type ℓ} (b : CS.Shell (toNat n) X)
    → CF.Filler (toNat n) b → ShellNull n b
  unfill n b = invEq (fill-shell-null-equivalence n b)

  unfill-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (b : CS.Shell (toNat n) X)
    (c : CF.Filler (toNat n) b)
    → unfill n (S.map-shell n f b) (F.map-filler n f b c)
      ≡ map-null n f b (unfill n b c)
  unfill-natural n f b c =
    cong (unfill n (S.map-shell n f b))
      (sym (cong (F.map-filler n f b) (secEq (fill-shell-null-equivalence n b) c))
        ∙ fill-shell-null-natural n f b (unfill n b c))
    ∙ retEq (fill-shell-null-equivalence n (S.map-shell n f b)) (map-null n f b (unfill n b c))
