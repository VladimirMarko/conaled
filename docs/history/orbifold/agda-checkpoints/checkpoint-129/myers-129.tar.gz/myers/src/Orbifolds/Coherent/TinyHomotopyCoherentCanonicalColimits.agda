{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyHomotopyCoherentCanonicalColimits where

-- Final A.0.5 interface for the actual evaluation-induced map.
-- The independent tiny branch proves the literal cellular comparison
-- equivalent. The independent canonical branch identifies that same map
-- with the actual map induced by every evaluation transformation, using
-- the complete cocone compatibility paths. Transport preserves this
-- specified map; no presentation or preservation certificate is an input.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram; Power)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.CrispPropositions as PP
import Orbifolds.TinyTypes as TT
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentPowers as Powers
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Colimits
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as Maps
import Orbifolds.Coherent.HomotopyCoherentCanonicalComparisons as Canonical
import Orbifolds.Coherent.HomotopyCoherentPowerBarComparison as Cellular
import Orbifolds.Coherent.HomotopyCoherentPowerBarCanonical as Identification
import Orbifolds.Coherent.TinyHomotopyCoherentBarColimits as Tiny

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ T : Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C)
    (@♭ E : StrictCubicalExtensionality ℓ) (@♭ F : StrictFunctionExtensionality ℓ) where
  open Category C

  powered : HC.ForCategory.Diagram C
  powered = Powers.Construction.Power C E F T D

  Source : Type ℓ
  Source = Colimits.Construction.Colimit C (Powers.Construction.Power C E F T D) E F

  Target : Type ℓ
  Target = Colimits.Construction.Colimit C D E F

  comparison : Source → T → Target
  comparison = Canonical.Power.comparison C D E F T

  cellular-comparison : Source → T → Target
  cellular-comparison = Cellular.Construction.comparison C D E F T

  comparison-is-canonical : PathP (λ _ → Source → T → Target)
    cellular-comparison comparison
  comparison-is-canonical = Identification.Construction.comparison-is-canonical C D E F T

  evaluation-map : (t : T) → Source → Target
  evaluation-map t = Maps.Map.induced C (Powers.Construction.Power C E F T D) D
    (Powers.Construction.evaluation C E F T D t) E F

  evaluation-computation : (z : Source) (t : T)
    → comparison z t ≡ evaluation-map t z
  evaluation-computation z t = refl

  SourceCocone : Type ℓ
  SourceCocone = Colimits.Construction.MappingOut.Cocone C
    (Powers.Construction.Power C E F T D) E F Target

  evaluation-cocone : (t : T) → SourceCocone
  evaluation-cocone t = Maps.Map.restriction C
    (Powers.Construction.Power C E F T D) D
    (Powers.Construction.evaluation C E F T D t) E F
    (Colimits.Construction.canonical-cocone C D E F)

  canonical-triangle : (t : T) → PathP (λ _ → SourceCocone)
    (Colimits.Construction.MappingOut.restrict C
      (Powers.Construction.Power C E F T D) E F Target (λ z → comparison z t))
    (evaluation-cocone t)
  canonical-triangle t = Maps.Map.canonical-triangle C
    (Powers.Construction.Power C E F T D) D
    (Powers.Construction.evaluation C E F T D t) E F

  source-generator : (x : Obj) → (T → HC.ForCategory.Diagram.Value D x) → Source
  source-generator = Canonical.Power.source-generator C D E F T

  target-generator : (x : Obj) → HC.ForCategory.Diagram.Value D x → Target
  target-generator = Canonical.Power.target-generator C D E F T

  generator-computation : (x : Obj) (a : T → HC.ForCategory.Diagram.Value D x) (t : T)
    → comparison (source-generator x a) t ≡ target-generator x (a t)
  generator-computation = Canonical.Power.generator-computation C D E F T

  RealFlat : Type (ℓ-suc ℓ)
  RealFlat = PP.Context.RealFlat R r₀

  abstract
    preserves-colimit : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
      → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
      → isEquiv {A = Source} {B = T → Target} comparison
    preserves-colimit real-flat tiny discrete-objects discrete-homs =
      subst (λ (f : Source → T → Target) → isEquiv {A = Source} {B = T → Target} f)
        comparison-is-canonical
        (Tiny.Context.preserves-colimit identity-rules flat-induction flat-computation
          identity-zero flat-zero flat-zero-computation R r₀ T C D E F
          real-flat tiny discrete-objects discrete-homs)

  colimit-equivalence : RealFlat → TT.External.Tiny T → CrisplyDiscrete Obj
    → ((@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
    → Source ≃ (T → Target)
  colimit-equivalence real-flat tiny discrete-objects discrete-homs =
    comparison , preserves-colimit real-flat tiny discrete-objects discrete-homs

  module Inverses (real-flat : RealFlat) (tiny : TT.External.Tiny T)
      (discrete-objects : CrisplyDiscrete Obj)
      (discrete-homs : (@♭ x y : Obj) → CrisplyDiscrete (Hom x y)) where
    equivalence : Source ≃ (T → Target)
    equivalence = colimit-equivalence real-flat tiny discrete-objects discrete-homs

    inverse : (T → Target) → Source
    inverse = invEq equivalence

    comparison-inverse : (a : T → Target) → comparison (inverse a) ≡ a
    comparison-inverse = secEq equivalence

    inverse-comparison : (z : Source) → inverse (comparison z) ≡ z
    inverse-comparison = retEq equivalence
