{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.EuclideanCompactness where

-- The one-dimensional Euclidean case of Lemma 6.2.21, with all analytic,
-- countable-basis, and singleton-isolation ingredients constructed.
-- The only synthetic inputs are K, O/Archimedean, the explicitly recorded
-- ordered-ring compatibility property, and interval Covering Property E.
-- Shape-discreteness is not replaced silently: the equality hypothesis is
-- precisely decidable equality, as in Definition 6.1.3.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Algebra.CommRing.Base
open import Cubical.Functions.Embedding using (isEmbedding)
open import Cubical.Relation.Nullary using (Discrete)

open import Orbifolds.SyntheticField using (module RingContext)
open import Orbifolds.SyntheticOrder using (module OrderTheory)
open import Orbifolds.CountableRealProbe using (module RealProbe)
open import Orbifolds.RealCountableBasis using (module RealBasis)
open import Orbifolds.CompactRealSubspaces using (module RealSubspaces)
open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.PenonNeighborhoods using (CoveringProperty)
open import Orbifolds.Topology using (Predicate)
open import Orbifolds.ProperFiniteness using (ProperlyFinite)

module Line {ℓ : Level} (R : CommRing ℓ)
    (kock : RingContext.KockField R) (order : RingContext.StrictOrder R)
    (compatibility : OrderTheory.OrderedRingCompatibility R order) where
  open OrderTheory R order using (Carrier)
  open RealProbe R kock order compatibility using (intervalBalls)
  open RealBasis R kock order compatibility using (realCountableBasis)
  module Subspaces = RealSubspaces R kock order compatibility

  compactDiscreteRealEmbeddingProperlyFinite : CoveringProperty intervalBalls →
    {K : Type ℓ} → DPCompact K → Discrete K → (f : K → Carrier) →
    isEmbedding f → ProperlyFinite K
  compactDiscreteRealEmbeddingProperlyFinite covering =
    Subspaces.compactRealEmbeddingProperlyFinite covering (realCountableBasis covering)

  compactDiscreteRealSubsetProperlyFinite : CoveringProperty intervalBalls →
    (U : Predicate Carrier) → DPCompact (Σ[ x ∈ Carrier ] U x .fst) →
    Discrete (Σ[ x ∈ Carrier ] U x .fst) → ProperlyFinite (Σ[ x ∈ Carrier ] U x .fst)
  compactDiscreteRealSubsetProperlyFinite covering =
    Subspaces.compactDiscreteRealSubtypeProperlyFinite covering (realCountableBasis covering)

