{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegerLatticeSeparation where

-- Explicit separation of the actual integer lattice in the smooth reals.
-- Integer case analysis does not decide equality or order of reals.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Int using (ℤ; pos; negsuc)
open import Cubical.Data.SumFin using (Fin)
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Morphisms using (IsGroupHom)
open import Cubical.Tactics.CommRingSolver
import Orbifolds.IntegerEmbedding as IE
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.MetricTopology as MT
import Orbifolds.EuclideanNorms as EN

module Ordered {ℓ : Level} (R : CommRing ℓ)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open CommRingStr (R .snd)
  open SF.RingContext.StrictOrder order
  open IE.Ordered R order using (integer; additive-homomorphism; positive-integer)
  open SO.OrderTheory R order
  open Compatible compatibility
  open OrderedRingCompatibility compatibility

  one-less-larger-integer : (n : ℕ) → 1r < integer (pos (suc (suc n)))
  one-less-larger-integer n = subst2 _<_ (+IdL 1r)
    (+Comm (integer (pos (suc n))) 1r)
    (translateLess (positive-integer n) 1r)

  positive-integer-not-below-one : (n : ℕ)
    → integer (pos (suc n)) < 1r → Empty.⊥
  positive-integer-not-below-one zero p =
    irreflexive 1r (subst (_< 1r) (+IdR 1r) p)
  positive-integer-not-below-one (suc n) = lessAsym (one-less-larger-integer n)

  negate-less : {x y : R .fst} → x < y → (- y) < (- x)
  negate-less {x} {y} p = positiveDifference→less
    (subst (0r <_) (sym algebra) (less→positiveDifference p))
    where
    algebra : (- x) - (- y) ≡ y - x
    algebra = solve! R

  double-negative : (x : R .fst) → - (- x) ≡ x
  double-negative x = solve! R

  integer-interval-zero : (n : ℤ)
    → (- 1r) < integer n → integer n < 1r → n ≡ pos zero
  integer-interval-zero (pos zero) lower upper = refl
  integer-interval-zero (pos (suc n)) lower upper =
    Empty.rec (positive-integer-not-below-one n upper)
  integer-interval-zero (negsuc n) lower upper =
    Empty.rec (positive-integer-not-below-one n
      (subst2 _<_ (sym (IsGroupHom.presinv (additive-homomorphism .snd) (negsuc n)))
        (double-negative 1r) (negate-less lower)))

  module Squares (kock : SF.RingContext.KockField R) where
    module Metric = MT.Metric R kock order compatibility
    module Norms = EN.Norms R kock order compatibility

    integer-square-zero : (n : ℤ)
      → (integer n · integer n) < 1r → n ≡ pos zero
    integer-square-zero n below = integer-interval-zero n (bounds .fst) (bounds .snd)
      where
      bounds = Metric.smallSquareInterval (1r , zero<one) (integer n)
        (subst ((integer n · integer n) <_) (sym (·IdL 1r)) below)

    integer-vector-small-norm : (n : ℕ) (z : Fin n → ℤ)
      → Norms.squaredNorm n (λ i → integer (z i)) < 1r
      → z ≡ (λ _ → pos zero)
    integer-vector-small-norm n z below = funExt λ i → integer-square-zero (z i)
      (Metric.coordinateSquareBound n (λ j → integer (z j)) i 1r below)
