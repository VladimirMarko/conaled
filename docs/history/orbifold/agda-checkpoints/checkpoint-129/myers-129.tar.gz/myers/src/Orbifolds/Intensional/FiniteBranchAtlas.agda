{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteBranchAtlas where

-- An ordinary intensional theorem about effective atlases and pointed
-- test maps. This is a new, smaller proof, not an interpretation of the
-- old Cubical Rezk implementation. Every semantic input is explicit.

open import Agda.Primitive using (Level; Set; lsuc; _⊔_)
open import Agda.Builtin.Nat using (Nat; zero; suc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.BoundedTruncation

private variable ℓ : Level

-- A universe-lifted finite ordinal. Its ordinary inductive definition
-- needs no higher inductive constructors or proof-irrelevance rule.
data Fin {ℓ : Level} : Nat → Set ℓ where
  fzero : {n : Nat} → Fin {ℓ} (suc n)
  fsuc : {n : Nat} → Fin {ℓ} n → Fin {ℓ} (suc n)

-- A finite label type with proposition fibers, not a finite enumeration
-- of X. Neither membership nor mere inhabitation is assumed decidable.
record SubfiniteWitness (X : Set ℓ) : Set (Code ℓ) where
  field
    size : Nat
    predicate : Fin {ℓ} size → Set ℓ
    predicate-prop : (i : Fin size) → isProp (predicate i)
    presentation : Equiv X (Σ (Fin size) predicate)

open SubfiniteWitness

subfinite-witness-equiv : {X Y : Set ℓ}
  → Equiv X Y → SubfiniteWitness X → SubfiniteWitness Y
size (subfinite-witness-equiv e p) = size p
predicate (subfinite-witness-equiv e p) = predicate p
predicate-prop (subfinite-witness-equiv e p) = predicate-prop p
presentation (subfinite-witness-equiv e p) = compEquiv (invEquiv e) (presentation p)

BranchArrows : {X Y : Set ℓ} (n : Nat)
  → (domain : Fin {ℓ} n → X → Set ℓ)
  → ((i : Fin n) (x : X) → domain i x → Y)
  → X → Y → Set ℓ
BranchArrows n domain target x y =
  Σ (Fin n) (λ i → Σ (domain i x) (λ d → target i x d ≡ y))

record BranchChart {X Y : Set ℓ} (H : X → Y → Set ℓ) : Set (Code ℓ) where
  field
    branches : Nat
    domain : Fin {ℓ} branches → X → Set ℓ
    domain-prop : (i : Fin branches) (x : X) → isProp (domain i x)
    target : (i : Fin branches) (x : X) → domain i x → Y
    hom-equivalence : (x : X) (y : Y)
      → Equiv (H x y) (BranchArrows branches domain target x y)

open BranchChart

chart-subfinite-witness : {X Y : Set ℓ} {H : X → Y → Set ℓ}
  → isSet Y → BranchChart H → (x : X) (y : Y) → SubfiniteWitness (H x y)
size (chart-subfinite-witness setY chart x y) = branches chart
predicate (chart-subfinite-witness setY chart x y) i =
  Σ (domain chart i x) (λ d → target chart i x d ≡ y)
predicate-prop (chart-subfinite-witness setY chart x y) i =
  isPropΣ (domain-prop chart i x) (λ d → setY (target chart i x d) y)
presentation (chart-subfinite-witness setY chart x y) = hom-equivalence chart x y

record LocalBranchChart {X Y : Set ℓ} (H : X → Y → Set ℓ)
    (x : X) (y : Y) : Set (Code ℓ) where
  field
    source-region : X → Set ℓ
    source-region-prop : (u : X) → isProp (source-region u)
    target-region : Y → Set ℓ
    target-region-prop : (v : Y) → isProp (target-region v)
    source-member : source-region x
    target-member : target-region y
    local-chart : BranchChart
      (λ (u : Σ X source-region) (v : Σ Y target-region) → H (fst u) (fst v))

open LocalBranchChart

local-chart-subfinite-witness : {X Y : Set ℓ} {H : X → Y → Set ℓ}
  → isSet Y → {x : X} {y : Y} → LocalBranchChart H x y
  → SubfiniteWitness (H x y)
local-chart-subfinite-witness setY {x = x} {y = y} chart =
  chart-subfinite-witness (isSetΣProp setY (target-region-prop chart))
    (local-chart chart) (x , source-member chart) (y , target-member chart)

module Finiteness {ℓ : Level} (T : BoundedTruncation ℓ) where
  module P = Truncation T

  Subfinite : Set ℓ → Set (Truth ℓ)
  Subfinite X = P.Tr (SubfiniteWitness X)

  subfinite-prop : (X : Set ℓ) → isProp (Subfinite X)
  subfinite-prop X = P.squash (SubfiniteWitness X)

  LocalBranchCharts : {X Y : Set ℓ} → (X → Y → Set ℓ) → Set (Truth ℓ)
  LocalBranchCharts {X = X} {Y = Y} H =
    (x : X) (y : Y) → P.Tr (LocalBranchChart H x y)

  charts-subfinite-homs : {X Y : Set ℓ} {H : X → Y → Set ℓ}
    → isSet Y → LocalBranchCharts H → (x : X) (y : Y) → Subfinite (H x y)
  charts-subfinite-homs setY charts x y =
    P.map (local-chart-subfinite-witness setY) (charts x y)

  LocallySubfinite : Set ℓ → Set (Truth ℓ)
  LocallySubfinite X = (u v : X) → Subfinite (u ≡ v)

  -- These are properties of the actual atlas and its actual hom-family.
  -- No microlinearity or finiteness conclusion is stored in the interface.
  record EffectiveAtlas (A X : Set ℓ) : Set (Truth ℓ) where
    field
      atlas : A → X
      hom : A → A → Set ℓ
      atlas-surjective : P.Surjective atlas
      hom-path : (a b : A) → Equiv (hom a b) (atlas a ≡ atlas b)

  open EffectiveAtlas

  atlas-subfinite-identities : {A X : Set ℓ} (Q : EffectiveAtlas A X)
    → isSet A → LocalBranchCharts (hom Q) → LocallySubfinite X
  atlas-subfinite-identities {A = A} {X = X} Q setA charts u v =
    P.mere-rec (subfinite-prop (u ≡ v))
      (λ { (a , p) → P.mere-rec (subfinite-prop (u ≡ v))
        (λ { (b , r) → subst (λ z → Subfinite (z ≡ v)) p
          (subst (λ z → Subfinite (atlas Q a ≡ z)) r
            (P.map (subfinite-witness-equiv (hom-path Q a b))
              (charts-subfinite-homs setA charts a b))) })
        (atlas-surjective Q v) })
      (atlas-surjective Q u)

-- A genuine inverse structure on a specified map. Its forward function
-- cannot be replaced by an unrelated equivalence of the same two types.
record InverseData {A B : Set ℓ} (f : A → B) : Set ℓ where
  field
    inverse : B → A
    right-law : (y : B) → f (inverse y) ≡ y
    left-law : (x : A) → inverse (f x) ≡ x

asEquiv : {A B : Set ℓ} (f : A → B) → InverseData f → Equiv A B
asEquiv f e = equiv f (InverseData.inverse e)
  (InverseData.right-law e) (InverseData.left-law e)

record PointedGap (ℓ : Level) : Set (Code ℓ) where
  field
    Boundary Codomain : Set ℓ
    gap : Boundary → Codomain
    basepoint : Boundary

module Geometry {ℓ : Level} (T : BoundedTruncation ℓ) (ext : FunExt ℓ ℓ) where
  module P = Truncation T
  module F = Finiteness T

  precompose : {A B X : Set ℓ} → (A → B) → (B → X) → A → X
  precompose e h a = h (e a)

  postcompose : {A X Y : Set ℓ} → (X → Y) → (A → X) → A → Y
  postcompose f h a = f (h a)

  Extension : {A B X : Set ℓ} → (A → B) → (A → X) → Set ℓ
  Extension e k = P.Fiber (precompose e) k

  Local : {A B : Set ℓ} → (A → B) → Set ℓ → Set ℓ
  Local {A = A} e X = (k : A → X) → isContr (Extension e k)

  mapExtension : {A B X Y : Set ℓ} (f : X → Y) (e : A → B) (k : A → X)
    → Extension e k → Extension e (postcompose f k)
  mapExtension f e k (h , w) = postcompose f h , cong (postcompose f) w

  RightOrthogonal : {A B X Y : Set ℓ} → (A → B) → (X → Y) → Set ℓ
  RightOrthogonal {A = A} {X = X} e f =
    (k : A → X) → InverseData (mapExtension f e k)

  lift-map-merely : {A X Y : Set ℓ} (a₀ : A) (f : X → Y)
    → P.Surjective f
    → RightOrthogonal (λ (_ : Unit {ℓ}) → a₀) f
    → (k : A → Y) → P.Mere (P.Fiber (postcompose f) k)
  lift-map-merely {A = A} {X = X} {Y = Y} a₀ f cover orth k =
    P.mere-map liftWitness (cover (k a₀))
    where
    based : Unit {ℓ} → A
    based _ = a₀

    liftWitness : P.Fiber f (k a₀) → P.Fiber (postcompose f) k
    liftWitness (x , p) = fst extension , cong fst comparison
      where
      requested-extension : Extension based (λ _ → f x)
      requested-extension = k , ext (λ _ → sym p)

      lifting = orth (λ _ → x)
      extension = InverseData.inverse lifting requested-extension
      comparison = InverseData.right-law lifting requested-extension

  local-descends : {A B X Y : Set ℓ} (e : A → B) (a₀ : A) (f : X → Y)
    → P.Surjective f
    → RightOrthogonal (λ (_ : Unit {ℓ}) → a₀) f
    → RightOrthogonal e f
    → Local e X → Local e Y
  local-descends {A = A} {B = B} {X = X} {Y = Y} e a₀ f cover based orth localX k =
    P.mere-rec-low (isPropIsContr ext) descend
      (lift-map-merely a₀ f cover based k)
    where
    descend : P.Fiber (postcompose f) k → isContr (Extension e k)
    descend (lifted , comparison) =
      subst (λ h → isContr (Extension e h)) comparison
        (equivPresIsContr (asEquiv (mapExtension f e lifted) (orth lifted))
          (localX lifted))

  module Tests {Index : Set ℓ} (test : Index → PointedGap ℓ) where
    open PointedGap

    Microlinear : Set ℓ → Set ℓ
    Microlinear X = (i : Index) → Local (gap (test i)) X

    record InfinitesimallyEtale {A X : Set ℓ} (q : A → X) : Set ℓ where
      field
        lift-gap : (i : Index) → RightOrthogonal (gap (test i)) q
        lift-base : (i : Index) →
          RightOrthogonal (λ (_ : Unit {ℓ}) → basepoint (test i)) q

    microlinear-descends : {A X : Set ℓ} (q : A → X)
      → P.Surjective q → InfinitesimallyEtale q
      → Microlinear A → Microlinear X
    microlinear-descends q cover etale micro i =
      local-descends (gap (test i)) (basepoint (test i)) q cover
        (InfinitesimallyEtale.lift-base etale i)
        (InfinitesimallyEtale.lift-gap etale i) (micro i)

    record ReducedOrbifold (X : Set ℓ) : Set (Truth ℓ) where
      field
        microlinear : Microlinear X
        subfinite-identities : F.LocallySubfinite X

    -- The final theorem has no assumed completed microlinearity,
    -- completed finiteness, univalence, HIT constructor, DPProper,
    -- excluded middle, crisp rule, or universe-resizing premise.
    finite-branch-atlas-orbifold : {A X : Set ℓ} (Q : F.EffectiveAtlas A X)
      → isSet A → F.LocalBranchCharts (F.EffectiveAtlas.hom Q)
      → Microlinear A → InfinitesimallyEtale (F.EffectiveAtlas.atlas Q)
      → ReducedOrbifold X
    ReducedOrbifold.microlinear
      (finite-branch-atlas-orbifold Q setA charts micro etale) =
      microlinear-descends (F.EffectiveAtlas.atlas Q)
        (F.EffectiveAtlas.atlas-surjective Q) etale micro
    ReducedOrbifold.subfinite-identities
      (finite-branch-atlas-orbifold Q setA charts micro etale) =
      F.atlas-subfinite-identities Q setA charts
