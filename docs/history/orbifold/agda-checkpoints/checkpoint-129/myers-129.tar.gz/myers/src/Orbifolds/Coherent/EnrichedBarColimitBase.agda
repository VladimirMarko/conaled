{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarColimitBase where

-- The actual initial cocone stage of the opposite mapping diagram is
-- represented by the coproduct of the diagram values. This is the base
-- case for cellular bar-colimit representability, not a claim that the
-- higher stages or the full colimit have already been constructed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (ozero)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite; Transformation)
import Orbifolds.Coherent.EnrichedMappingDiagrams as Mapping
import Orbifolds.Coherent.EnrichedBarFiniteStages as Stages

module Base {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Diagram D

  Initial : Type ℓ
  Initial = Σ Obj Value

  include : (y : Obj) → Value y → Initial
  include y x = y , x

  module Target (Y : Type ℓ) where
    module Cones = Stages.Finite (Opposite C) (Mapping.Mapping.Into D Y) E

    Cocone : Type ℓ
    Cocone = Cones.Carrier ozero

    restrict : (Initial → Y) → Cocone
    restrict h y x = h (y , x)

    assemble : Cocone → Initial → Y
    assemble c (y , x) = c y x

    universal : (Initial → Y) ≃ Cocone
    universal = isoToEquiv (iso restrict assemble (λ _ → refl) (λ _ → refl))

    include-computation : (h : Initial → Y) (y : Obj)
      → restrict h y ≡ h ∘ include y
    include-computation h y = refl

    family-computation : (h : Initial → Y) (y : Obj)
      (c : Orbifolds.Coherent.OuterBarChains.Chains.Chain (Opposite C) ozero y)
      → outer (Cones.families ozero (restrict h) y c)
        ≡ˢ outer (h ∘ include y)
    family-computation h y c = reflˢ

  canonical-cocone : Target.Cocone Initial
  canonical-cocone = Target.restrict Initial (idfun Initial)

  canonical-computation : (y : Obj) → canonical-cocone y ≡ include y
  canonical-computation y = refl

  postcompose : {Y Z : Type ℓ} → (Y → Z) → Target.Cocone Y → Target.Cocone Z
  postcompose k c y = k ∘ c y

  restrict-natural : {Y Z : Type ℓ} (k : Y → Z) (h : Initial → Y)
    → outer (postcompose k (Target.restrict Y h))
      ≡ˢ outer (Target.restrict Z (k ∘ h))
  restrict-natural k h = reflˢ

  assemble-natural : {Y Z : Type ℓ} (k : Y → Z) (c : Target.Cocone Y)
    → outer (Target.assemble Z (postcompose k c))
      ≡ˢ outer (k ∘ Target.assemble Y c)
  assemble-natural k c = reflˢ
