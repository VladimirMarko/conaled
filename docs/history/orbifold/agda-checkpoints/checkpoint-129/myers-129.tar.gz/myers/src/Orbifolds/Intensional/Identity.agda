{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.Identity where

-- Ordinary intensional identity types. All proofs below use identity
-- elimination and ordinary inductive types or records. Function
-- extensionality is a displayed parameter at two fixed universe levels.

open import Agda.Primitive using (Level; lzero; lsuc; _⊔_; Set)

infix 4 _≡_
infixr 20 _∙_
infixr 4 _,_
infix 2 _≃_

data _≡_ {a : Level} {A : Set a} (x : A) : A → Set a where
  refl : x ≡ x

J : {a p : Level} {A : Set a} {x : A}
  → (P : (y : A) → x ≡ y → Set p)
  → P x refl → {y : A} → (e : x ≡ y) → P y e
J P base refl = base

sym : {a : Level} {A : Set a} {x y : A} → x ≡ y → y ≡ x
sym refl = refl

_∙_ : {a : Level} {A : Set a} {x y z : A}
  → x ≡ y → y ≡ z → x ≡ z
refl ∙ q = q

cong : {a b : Level} {A : Set a} {B : Set b}
  → (f : A → B) → {x y : A} → x ≡ y → f x ≡ f y
cong f refl = refl

subst : {a b : Level} {A : Set a}
  → (B : A → Set b) → {x y : A} → x ≡ y → B x → B y
subst B refl u = u

∙-left-unit : {a : Level} {A : Set a} {x y : A}
  → (p : x ≡ y) → refl ∙ p ≡ p
∙-left-unit p = refl

∙-right-unit : {a : Level} {A : Set a} {x y : A}
  → (p : x ≡ y) → p ∙ refl ≡ p
∙-right-unit refl = refl

∙-assoc : {a : Level} {A : Set a} {w x y z : A}
  → (p : w ≡ x) → (q : x ≡ y) → (r : y ≡ z)
  → (p ∙ q) ∙ r ≡ p ∙ (q ∙ r)
∙-assoc refl q r = refl

∙-inverse-left : {a : Level} {A : Set a} {x y : A}
  → (p : x ≡ y) → sym p ∙ p ≡ refl
∙-inverse-left refl = refl

∙-inverse-right : {a : Level} {A : Set a} {x y : A}
  → (p : x ≡ y) → p ∙ sym p ≡ refl
∙-inverse-right refl = refl

cong-∙ : {a b : Level} {A : Set a} {B : Set b}
  → (f : A → B) → {x y z : A} → (p : x ≡ y) → (q : y ≡ z)
  → cong f (p ∙ q) ≡ cong f p ∙ cong f q
cong-∙ f refl q = refl

cong-sym : {a b : Level} {A : Set a} {B : Set b}
  → (f : A → B) → {x y : A} → (p : x ≡ y)
  → cong f (sym p) ≡ sym (cong f p)
cong-sym f refl = refl

record Σ {a b : Level} (A : Set a) (B : A → Set b) : Set (a ⊔ b) where
  constructor _,_
  field
    fst : A
    snd : B fst

open Σ public

record Lift {a : Level} (b : Level) (A : Set a) : Set (a ⊔ b) where
  constructor lift
  field
    lower : A

open Lift public

data Unit {ℓ : Level} : Set ℓ where
  tt : Unit

isProp : {a : Level} → Set a → Set a
isProp A = (x y : A) → x ≡ y

isSet : {a : Level} → Set a → Set a
isSet A = (x y : A) → isProp (x ≡ y)

isContr : {a : Level} → Set a → Set a
isContr A = Σ A (λ center → (x : A) → center ≡ x)

isContr→isProp : {a : Level} {A : Set a} → isContr A → isProp A
isContr→isProp (center , contract) x y = sym (contract x) ∙ contract y

-- This is path induction, not uniqueness of arbitrary identity proofs.
-- A specified contraction gives a canonical path and a contraction of
-- the identity type onto that path.
isContr→isContrPaths : {a : Level} {A : Set a}
  → isContr A → (x y : A) → isContr (x ≡ y)
isContr→isContrPaths (center , contract) x y =
  (sym (contract x) ∙ contract y) ,
  (λ p → J
    (λ z q → sym (contract x) ∙ contract z ≡ q)
    (∙-inverse-left (contract x)) p)

isProp→isSet : {a : Level} {A : Set a} → isProp A → isSet A
isProp→isSet prop x y =
  isContr→isProp (isContr→isContrPaths (x , prop x) x y)

isContr→isSet : {a : Level} {A : Set a} → isContr A → isSet A
isContr→isSet contractible = isProp→isSet (isContr→isProp contractible)

isPropUnit : {ℓ : Level} → isProp (Unit {ℓ})
isPropUnit tt tt = refl

isContrUnit : {ℓ : Level} → isContr (Unit {ℓ})
isContrUnit = tt , λ { tt → refl }

Σ-path : {a b : Level} {A : Set a} {B : A → Set b}
  → {u v : Σ A B} → (p : fst u ≡ fst v)
  → subst B p (snd u) ≡ snd v → u ≡ v
Σ-path {u = x , u} {v = .x , v} refl q = cong (λ w → x , w) q

Σ-path-prop : {a b : Level} {A : Set a} {B : A → Set b}
  → ((x : A) → isProp (B x))
  → {u v : Σ A B} → fst u ≡ fst v → u ≡ v
Σ-path-prop {B = B} prop {u = u} {v = v} p =
  Σ-path p (prop (fst v) (subst B p (snd u)) (snd v))

Σ-path-prop-η : {a b : Level} {A : Set a} {B : A → Set b}
  → (prop : (x : A) → isProp (B x))
  → {u v : Σ A B} → (p : u ≡ v)
  → Σ-path-prop prop (cong fst p) ≡ p
Σ-path-prop-η prop {u = x , u} refl =
  cong (cong (λ w → x , w))
    (isProp→isSet (prop x) u u (prop x u u) refl)

isPropΣ : {a b : Level} {A : Set a} {B : A → Set b}
  → isProp A → ((x : A) → isProp (B x)) → isProp (Σ A B)
isPropΣ propA propB u v = Σ-path-prop propB (propA (fst u) (fst v))

isSetΣProp : {a b : Level} {A : Set a} {B : A → Set b}
  → isSet A → ((x : A) → isProp (B x)) → isSet (Σ A B)
isSetΣProp setA propB u v p q =
  sym (Σ-path-prop-η propB p)
    ∙ cong (Σ-path-prop propB {u = u} {v = v})
        (setA (fst u) (fst v) (cong fst p) (cong fst q))
    ∙ Σ-path-prop-η propB q

-- Quasi-inverse data suffice for the transfer results below. We do not
-- claim that this record is itself proposition-valued.
record Equiv {a b : Level} (A : Set a) (B : Set b) : Set (a ⊔ b) where
  constructor equiv
  field
    forward : A → B
    backward : B → A
    section : (y : B) → forward (backward y) ≡ y
    retraction : (x : A) → backward (forward x) ≡ x

open Equiv public

_≃_ : {a b : Level} → Set a → Set b → Set (a ⊔ b)
_≃_ = Equiv

idEquiv : {a : Level} → (A : Set a) → Equiv A A
idEquiv A = equiv (λ x → x) (λ x → x) (λ _ → refl) (λ _ → refl)

invEquiv : {a b : Level} {A : Set a} {B : Set b} → Equiv A B → Equiv B A
invEquiv e = equiv (backward e) (forward e) (retraction e) (section e)

compEquiv : {a b c : Level} {A : Set a} {B : Set b} {C : Set c}
  → Equiv A B → Equiv B C → Equiv A C
compEquiv e f = equiv
  (λ x → forward f (forward e x))
  (λ z → backward e (backward f z))
  (λ z → cong (forward f) (section e (backward f z)) ∙ section f z)
  (λ x → cong (backward e) (retraction f (forward e x)) ∙ retraction e x)

equivPresIsContr : {a b : Level} {A : Set a} {B : Set b}
  → Equiv A B → isContr A → isContr B
equivPresIsContr e (center , contract) = forward e center ,
  (λ y → cong (forward e) (contract (backward e y)) ∙ section e y)

liftEquiv : {a b : Level} {A : Set a} → Equiv A (Lift b A)
liftEquiv = equiv lift lower (λ { (lift x) → refl }) (λ _ → refl)

FunExt : (a b : Level) → Set (lsuc (a ⊔ b))
FunExt a b =
  {A : Set a} {B : A → Set b} {f g : (x : A) → B x}
  → ((x : A) → f x ≡ g x) → f ≡ g

isPropΠ : {a b : Level} {A : Set a} {B : A → Set b}
  → FunExt a b → ((x : A) → isProp (B x))
  → isProp ((x : A) → B x)
isPropΠ ext prop f g = ext (λ x → prop x (f x) (g x))

isPropIsContr : {a : Level} {A : Set a}
  → FunExt a a → isProp (isContr A)
isPropIsContr ext first second =
  Σ-path-prop
    (λ center → isPropΠ ext (λ x → isContr→isSet first center x))
    (snd first (fst second))
