{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CoinductiveTowerSquares where

-- Inner coherent homotopies between two maps of actual transition
-- systems. All generic type checking is independent of any diagram
-- presentation or specialized coherence proof.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_)

module Squares {ℓs ℓp ℓq : Level} (State : Type ℓs)
    (P : State → Type ℓp) (Q : State → Type ℓq) (advance : State → State)
    (drop-P : (s : State) → P (advance s) → P s)
    (drop-Q : (s : State) → Q (advance s) → Q s)
    (left right : (s : State) → P s → Q s)
    (left-square : (s : State) → (drop-Q s ∘ left (advance s)) ≡ (left s ∘ drop-P s))
    (right-square : (s : State) → (drop-Q s ∘ right (advance s)) ≡ (right s ∘ drop-P s)) where

  record Witness (s : State) (current : left s ≡ right s) : Type (ℓ-max ℓp ℓq) where
    coinductive
    field
      next : left (advance s) ≡ right (advance s)
      square : PathP (λ i → (drop-Q s ∘ next i) ≡ (current i ∘ drop-P s))
        (left-square s) (right-square s)
      tail : Witness (advance s) next
