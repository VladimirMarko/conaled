{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FirstOrderWeilTensorAlgebra where

-- The actual square-zero algebras supply the four vertices
-- and maps of the generic algebra comparison. The original pullback
-- equivalence is discharged by FirstOrderWeilSquare.comparison-isEquiv;
-- it is not an application premise.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using (isEquiv; homotopy-isEquiv)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportPullbacks using (pullback-path)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor
open import Orbifolds.Intensional.FiniteSupportScalarExtension using (module BasedExtension)
open import Orbifolds.Intensional.CommutativeAlgebraCore
import Orbifolds.Intensional.SquareZeroAlgebra as SZ
import Orbifolds.Intensional.FirstOrderWeilSquare as FO
import Orbifolds.Intensional.FiniteSupportAlgebraSquare as TAS

module Coefficients {ℓ : Level} (R : CommutativeSemiring ℓ) where

  private module R = CommutativeSemiring R

  multiplication : BilinearMap (regular-module R) (regular-module R) (regular-module R)
  multiplication = R._*_ ,
    ((λ v → ((R.*-zero-left v , λ u w → R.*-add-left u w v) , λ r u → R.*-assoc r u v)) ,
      λ u → ((R.*-zero-right u , R.*-add-right u) ,
        λ r v → sym (R.*-assoc u r v)
          ∙ cong (λ s → s R.* v) (R.*-comm u r) ∙ R.*-assoc r u v))

  algebra : CommutativeAlgebra R
  CommutativeAlgebra.moduleR algebra = regular-module R
  CommutativeAlgebra.one algebra = R.one
  CommutativeAlgebra.multiplication algebra = multiplication
  CommutativeAlgebra.*-assoc algebra = R.*-assoc
  CommutativeAlgebra.*-comm algebra = R.*-comm
  CommutativeAlgebra.*-one-left algebra = R.*-one-left

module SquareZeroAdapter {ℓ : Level} (R : CommutativeSemiring ℓ) (M : Semimodule R) where

  module S = SZ.Extension R M

  multiplication : BilinearMap S.E-module S.E-module S.E-module
  multiplication = S.multiply ,
    ((λ v → ((S.multiply-zero-left v , λ u w → S.multiply-add-left u w v) ,
      λ r u → S.multiply-scale-left r u v)) , λ u → snd (S.multiplication-linear u))

  algebra : CommutativeAlgebra R
  CommutativeAlgebra.moduleR algebra = S.E-module
  CommutativeAlgebra.one algebra = S.oneE
  CommutativeAlgebra.multiplication algebra = multiplication
  CommutativeAlgebra.*-assoc algebra = S.multiply-assoc
  CommutativeAlgebra.*-comm algebra = S.multiply-comm
  CommutativeAlgebra.*-one-left algebra = S.multiply-one-left

  augmentation : AlgebraHom algebra (Coefficients.algebra R)
  AlgebraHom.linear augmentation = S.augmentation-linear
  AlgebraHom.map-one augmentation = SZ.IsSemiringMap.map-one S.augmentation-map
  AlgebraHom.map-mul augmentation = SZ.IsSemiringMap.map-mul S.augmentation-map

module FirstOrder {ℓ : Level} (R : CommutativeSemiring ℓ) where

  module W = FO.Construction R

  coefficient-algebra : CommutativeAlgebra R
  coefficient-algebra = Coefficients.algebra R

  dual-algebra : CommutativeAlgebra R
  dual-algebra = SquareZeroAdapter.algebra R W.coefficients

  two-direction-algebra : CommutativeAlgebra R
  two-direction-algebra = SquareZeroAdapter.algebra R W.two-directions

  augmentation : AlgebraHom dual-algebra coefficient-algebra
  augmentation = SquareZeroAdapter.augmentation R W.coefficients

  first : AlgebraHom two-direction-algebra dual-algebra
  AlgebraHom.linear first = W.first-linear-map
  AlgebraHom.map-one first = SZ.IsSemiringMap.map-one W.first-semiring-map
  AlgebraHom.map-mul first = SZ.IsSemiringMap.map-mul W.first-semiring-map

  second : AlgebraHom two-direction-algebra dual-algebra
  AlgebraHom.linear second = W.second-linear-map
  AlgebraHom.map-one second = SZ.IsSemiringMap.map-one W.second-semiring-map
  AlgebraHom.map-mul second = SZ.IsSemiringMap.map-mul W.second-semiring-map

  commute : (d : W.D2.E)
    → AlgebraHom.map augmentation (AlgebraHom.map second d)
      ≡ AlgebraHom.map augmentation (AlgebraHom.map first d)
  commute d = refl

module Application {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (Parameter : CommutativeAlgebra R)
    (basis : BasedExtension.Basis ext classical equality (CommutativeAlgebra.moduleR Parameter)) where

  module W = FirstOrder R
  module Q = TAS.WithParameter.WithBasis.Square ext classical equality Parameter basis
    W.two-direction-algebra W.dual-algebra W.dual-algebra W.coefficient-algebra
    W.first W.second W.augmentation W.augmentation W.commute

  original-comparison-agrees : (d : W.W.D2.E)
    → W.W.comparison d ≡ Q.Underlying.original-comparison d
  original-comparison-agrees d = pullback-path (CommutativeSemiring.carrier-set R) refl refl

  original-is-pullback : isEquiv Q.Underlying.original-comparison
  original-is-pullback = homotopy-isEquiv W.W.comparison Q.Underlying.original-comparison
    original-comparison-agrees W.W.comparison-isEquiv

  tensor-algebra-isomorphism : AlgebraIso Q.XD.Algebra.algebra Q.P.algebra
  tensor-algebra-isomorphism = Q.Pullback.algebra-isomorphism original-is-pullback

  forward-is-actual : (d : Semimodule.Carrier Q.XD.O.Extension)
    → AlgebraHom.map (AlgebraIso.to-hom tensor-algebra-isomorphism) d ≡ Q.actual-comparison d
  forward-is-actual = Q.Pullback.isomorphism-forward-is-actual original-is-pullback

  forward-respects-parameter : (a : CommutativeAlgebra.Carrier Parameter)
    → AlgebraHom.map (AlgebraIso.to-hom tensor-algebra-isomorphism)
        (AlgebraHom.map Q.XD.Algebra.include-left a) ≡ AlgebraHom.map Q.parameter-map a
  forward-respects-parameter = Q.comparison-respects-parameter

  inverse-respects-parameter : (a : CommutativeAlgebra.Carrier Parameter)
    → AlgebraHom.map (AlgebraIso.from-hom tensor-algebra-isomorphism) (AlgebraHom.map Q.parameter-map a)
      ≡ AlgebraHom.map Q.XD.Algebra.include-left a
  inverse-respects-parameter = Q.Pullback.inverse-respects-parameter original-is-pullback
