{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentUniverseMicrolinearity where

-- Microlinearity of arbitrary-universe, fully homotopy-coherent
-- diagrams' actual cone limit and every cone with its universal property.
-- The finite strict foundation rule is explicit. No coherence assembly,
-- stage microlinearity, cone presentation or limit preservation is input.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Nat using (zero)
open import Orbifolds.Coherent.StrictEnriched renaming (Diagram to StrictDiagram)
import Orbifolds.Coherent.UniverseHomotopyCoherentDiagrams as UH
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentUniverseLifting as Lifted
import Orbifolds.Coherent.HomotopyCoherentConeStages as Stages
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module DiagramTheorem {ℓo ℓh ℓx : Level} (C : Category ℓo ℓh) (D : UH.ForCategory.Diagram C ℓx)
    (E : StrictCubicalExtensionality (Lifted.Lifting.W C D)) where
  module U = Lifted.Lifting C D
  module Raised = U.Structure E
  module Bar = Stages.Construction U.LiftedCategory Raised.LiftedDiagram E
  open Bar using (Limit; Cone; canonical-cone; restrict; assemble; universal;
    precompose-cone; universal-natural) public

  vertex : (y : Category.Obj C) → Limit → UH.ForCategory.Diagram.Value D y
  vertex y z = lower (Bar.vertex (lift y) z)

  vertex-computation : (y : Category.Obj C) (z : Limit)
    → vertex y z ≡ lower (Bar.projection zero z (lift y))
  vertex-computation y z = refl

  module Relative {ℓi ℓw : Level} {Tests : Type ℓi}
      (test : Tests → Micro.TestSquare ℓw)
      (vertices : (y : Category.Obj C) → Micro.Theory.Microlinear test (UH.ForCategory.Diagram.Value D y)) where
    module M = Micro.Theory test
    module Closure = ML.Limits test

    lifted-vertices : (y : Category.Obj U.LiftedCategory)
      → M.Microlinear (HC.ForCategory.Diagram.Value Raised.LiftedDiagram y)
    lifted-vertices y = Closure.microlinear-equiv
      (invEquiv (Raised.value-equivalence y)) (vertices (lower y))

    limit-microlinear : M.Microlinear Limit
    limit-microlinear = Bar.Microlinear.limit-microlinear test lifted-vertices

    any-limit-microlinear : {ℓl : Level} (L : Type ℓl) (cone : Cone L)
      (universal-at-L : isEquiv (precompose-cone {S = L} cone))
      (universal-at-limit : isEquiv (precompose-cone {S = Limit} cone))
      → M.Microlinear L
    any-limit-microlinear L cone at-L at-limit =
      Bar.Microlinear.any-limit-microlinear test lifted-vertices L cone at-L at-limit

    limit-power-microlinear : {ℓa : Level} (A : Type ℓa)
      → M.Microlinear (A → Limit)
    limit-power-microlinear A = M.microlinear-Π λ _ → limit-microlinear

module Powers {ℓi ℓw : Level} {Tests : Type ℓi} (test : Tests → Micro.TestSquare ℓw) where
  module M = Micro.Theory test

  power-microlinear : ∀ {ℓa ℓx} (A : Type ℓa) {X : Type ℓx}
    → M.Microlinear X → M.Microlinear (A → X)
  power-microlinear A micro = M.microlinear-Π λ _ → micro
