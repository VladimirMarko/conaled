{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispGeometry where

-- Judgmentally crisp geometric diagrams. The restrictions below are
-- enforced by Agda's context checker; they are not extra decidability or
-- lexness assertions about arbitrary internally varying types.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Data.Unit
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
import Orbifolds.CrystallineZeroLoci as CZ
import Orbifolds.ModalPullbacks as MP
import Orbifolds.WeilDiagrams as WD

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ) where
  module Infinitesimal = CZ.Ring R
  module Preserve = MP.Theory Infinitesimal.CrystallineModality
  module WeilTests = WD.Geometry R

  -- Axiom 2 (R-flat): the flat counit detects precisely R-null types,
  -- but it is stated only for crisp X. It is not assumed globally here.
  RealFlatAxiom : Type (ℓ-suc ℓ)
  RealFlatAxiom = (@♭ X : Type ℓ) →
    CrisplyDiscrete X ≃ isEquiv (const :> (X → (R .fst → X)))

  -- Axiom 4, with literal crisp binders on the whole pullback diagram.
  CrispPullbackPreservation : Type (ℓ-suc ℓ)
  CrispPullbackPreservation = (@♭ X Y Z : Type ℓ)
    (@♭ f : X → Z) (@♭ g : Y → Z) → Preserve.PullbackDiagram.Preserved f g

  -- This fibre statement is derived from the pullback statement. It is
  -- not silently added as a second axiom.
  crisp-fibre-preservation : CrispPullbackPreservation
    → (@♭ X Y : Type ℓ) (@♭ f : X → Y) (@♭ y : Y)
    → Preserve.FibreDiagram.Preserved f y
  crisp-fibre-preservation preserve X Y f y =
    Preserve.pullback-preservation→fibre-preservation f y
      (preserve X (Unit* {ℓ = ℓ}) Y f (λ _ → y))

  crisp-zero-locus-connected : CrispPullbackPreservation
    → (@♭ n m : ℕ)
    → (@♭ f : Infinitesimal.InfinitesimalPower n → Infinitesimal.InfinitesimalPower m)
    → Infinitesimal.Crystal.Connected (fiber f (Infinitesimal.zero-power m))
  crisp-zero-locus-connected preserve n m f =
    Infinitesimal.ZeroLocus.zero-locus-connected n m f
      (crisp-fibre-preservation preserve
        (Infinitesimal.InfinitesimalPower n) (Infinitesimal.InfinitesimalPower m)
        f (Infinitesimal.zero-power m))

  -- Definition 4.2.12 now ranges over actual crisp Weil-spectrum
  -- R-pushout diagrams. The coefficient-type and zero-locus proofs of
  -- Proposition 5.0.2 are inherited from the already checked construction.
  CrispRealPushout : Type (ℓ-suc ℓ)
  CrispRealPushout = Flat WeilTests.WeilRealPushout

  underlying-diagram : CrispRealPushout → WeilTests.WeilRealPushout
  underlying-diagram = counit

  module CrispTests = WeilTests.Indexed underlying-diagram
  open CrispTests public
