{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.BoundedTruncation where

-- A fixed, universe-raising interface. It does not assert that a universe
-- is closed under arbitrary higher inductive types or assume resizing.
-- Its realization is proved externally in LANGUAGE-BRIDGE-074.md.

open import Agda.Primitive using (Level; Set; lsuc; _⊔_)
open import Orbifolds.Intensional.Identity

Code : Level → Level
Code ℓ = lsuc ℓ

Truth : Level → Level
Truth ℓ = lsuc (lsuc ℓ)

record BoundedTruncation (ℓ : Level) : Set (lsuc (Truth ℓ)) where
  field
    Tr : Set (Code ℓ) → Set (Truth ℓ)
    point : {A : Set (Code ℓ)} → A → Tr A
    squash : (A : Set (Code ℓ)) → isProp (Tr A)
    rec : {A : Set (Code ℓ)} {P : Set (Truth ℓ)}
      → isProp P → (A → P) → Tr A → P

module Truncation {ℓ : Level} (T : BoundedTruncation ℓ) where
  open BoundedTruncation T public

  isPropLift : {a b : Level} {A : Set a} → isProp A → isProp (Lift b A)
  isPropLift prop (lift x) (lift y) = cong lift (prop x y)

  map : {A B : Set (Code ℓ)} → (A → B) → Tr A → Tr B
  map f = rec (squash _) (λ x → point (f x))

  -- Only propositional computation is needed, and follows from the
  -- propositionhood of the target. No judgmental HIT computation is used.
  rec-β : {A : Set (Code ℓ)} {P : Set (Truth ℓ)}
    → (prop : isProp P) → (f : A → P) → (x : A)
    → rec prop f (point x) ≡ f x
  rec-β prop f x = prop _ _

  rec-low : {A : Set (Code ℓ)} {P : Set ℓ}
    → isProp P → (A → P) → Tr A → P
  rec-low prop f z = lower
    (rec (isPropLift {b = Truth ℓ} prop) (λ x → lift (f x)) z)

  Mere : Set ℓ → Set (Truth ℓ)
  Mere A = Tr (Lift (Code ℓ) A)

  mere : {A : Set ℓ} → A → Mere A
  mere x = point (lift x)

  mere-prop : (A : Set ℓ) → isProp (Mere A)
  mere-prop A = squash (Lift (Code ℓ) A)

  mere-map : {A B : Set ℓ} → (A → B) → Mere A → Mere B
  mere-map f = map (λ x → lift (f (lower x)))

  mere-rec : {A : Set ℓ} {P : Set (Truth ℓ)}
    → isProp P → (A → P) → Mere A → P
  mere-rec prop f = rec prop (λ x → f (lower x))

  mere-rec-low : {A P : Set ℓ}
    → isProp P → (A → P) → Mere A → P
  mere-rec-low prop f = rec-low prop (λ x → f (lower x))

  Fiber : {A B : Set ℓ} → (A → B) → B → Set ℓ
  Fiber {A = A} f y = Σ A (λ x → f x ≡ y)

  Surjective : {A B : Set ℓ} → (A → B) → Set (Truth ℓ)
  Surjective {B = B} f = (y : B) → Mere (Fiber f y)
