{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentArrowChains where

-- Nonempty composable chains with BOTH endpoints fixed. Degree n means
-- n+1 arrows, matching the n-cube of a coherent functor. Internal faces
-- preserve source and target definitionally; splits retain both blocks.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; _≤ᵖ_; pzero≤; psuc≤; weaken)
open import Orbifolds.Coherent.OuterCubicalFaces using (Cube; map-cube)

prefix-degree : (n : Dim) → Position (osuc n) → Dim
prefix-degree n pzero = n
prefix-degree (osuc n) (psuc p) = prefix-degree n p

suffix-degree : (n : Dim) → Position (osuc n) → Dim
suffix-degree n pzero = ozero
suffix-degree (osuc n) (psuc p) = osuc (suffix-degree n p)

module Arrows {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C

  Chain : Dim → Obj → Obj → Type ℓ
  Chain ozero x y = Hom x y
  Chain (osuc n) x y = Σ[ z ∈ Obj ] (Hom z y × Chain n x z)

  append : (n : Dim) {x y z : Obj} → Hom y z → Chain n x y → Chain (osuc n) x z
  append n {y = y} g c = y , g , c

  last-source : (n : Dim) {x y : Obj} → Chain (osuc n) x y → Obj
  last-source n c = c .fst

  last-arrow : (n : Dim) {x y : Obj} (c : Chain (osuc n) x y) → Hom (last-source n c) y
  last-arrow n c = c .snd .fst

  before-last : (n : Dim) {x y : Obj} (c : Chain (osuc n) x y) → Chain n x (last-source n c)
  before-last n c = c .snd .snd

  whole : (n : Dim) {x y : Obj} → Chain n x y → Hom x y
  whole ozero f = f
  whole (osuc n) c = compose (last-arrow n c) (whole n (before-last n c))

  extend-suffix : (n : Dim) {x y z : Obj} → Hom y z → Chain n x y → Chain n x z
  extend-suffix ozero g f = compose g f
  extend-suffix (osuc n) g c = append n (compose g (last-arrow n c)) (before-last n c)

  whole-extend : (n : Dim) {x y z : Obj} (g : Hom y z) (c : Chain n x y)
    → outer (whole n (extend-suffix n g c)) ≡ˢ outer (compose g (whole n c))
  whole-extend ozero g c = reflˢ
  whole-extend (osuc n) g c = strict-sym
    (assoc g (last-arrow n c) (whole n (before-last n c)))

  face : (n : Dim) → Position (osuc n) → {x y : Obj} → Chain (osuc n) x y → Chain n x y
  face n pzero c = extend-suffix n (last-arrow n c) (before-last n c)
  face (osuc n) (psuc p) c = append n (last-arrow (osuc n) c)
    (face n p (before-last (osuc n) c))

  whole-face : (n : Dim) (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y)
    → outer (whole n (face n p c)) ≡ˢ outer (whole (osuc n) c)
  whole-face n pzero c = whole-extend n (last-arrow n c) (before-last n c)
  whole-face (osuc n) (psuc p) c = strict-cong
    (λ f → outer (compose (last-arrow (osuc n) c) (inner f)))
    (whole-face n p (before-last (osuc n) c))

  extend-compose : (n : Dim) {w x y z : Obj} (g : Hom y z) (f : Hom x y) (c : Chain n w x)
    → outer (extend-suffix n g (extend-suffix n f c))
      ≡ˢ outer (extend-suffix n (compose g f) c)
  extend-compose ozero g f c = assoc g f c
  extend-compose (osuc n) g f c = strict-cong
    (λ h → outer (append n (inner h) (before-last n c)))
    (assoc g f (last-arrow n c))

  extend-face : (n : Dim) (p : Position (osuc n)) {w x y : Obj}
    (g : Hom x y) (c : Chain (osuc n) w x)
    → outer (face n p (extend-suffix (osuc n) g c))
      ≡ˢ outer (extend-suffix n g (face n p c))
  extend-face n pzero g c = strict-sym
    (extend-compose n g (last-arrow n c) (before-last n c))
  extend-face (osuc n) (psuc p) g c = reflˢ

  face-face : (n : Dim) (p q : Position (osuc n)) → p ≤ᵖ q
    → {x y : Obj} (c : Chain (osuc (osuc n)) x y)
    → outer (face n p (face (osuc n) (psuc q) c))
      ≡ˢ outer (face n q (face (osuc n) (weaken p) c))
  face-face n pzero q pzero≤ c = strict-sym
    (extend-face n q (last-arrow (osuc n) c) (before-last (osuc n) c))
  face-face (osuc n) (psuc p) (psuc q) (psuc≤ le) c = strict-cong
    (λ z → outer (append n (last-arrow (osuc (osuc n)) c) (inner z)))
    (face-face n p q le (before-last (osuc (osuc n)) c))

  Split : (n : Dim) → Position (osuc n) → Obj → Obj → Type ℓ
  Split n p x y = Σ[ z ∈ Obj ]
    (Chain (suffix-degree n p) z y × Chain (prefix-degree n p) x z)

  split : (n : Dim) (p : Position (osuc n)) {x y : Obj} → Chain (osuc n) x y → Split n p x y
  split n pzero c = last-source n c , last-arrow n c , before-last n c
  split (osuc n) (psuc p) c =
    split n p (before-last (osuc n) c) .fst ,
    append (suffix-degree n p) (last-arrow (osuc n) c)
      (split n p (before-last (osuc n) c) .snd .fst) ,
    split n p (before-last (osuc n) c) .snd .snd

  split-vertex : (n : Dim) (p : Position (osuc n)) {x y : Obj} → Chain (osuc n) x y → Obj
  split-vertex n p c = split n p c .fst

  split-prefix : (n : Dim) (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y)
    → Chain (prefix-degree n p) x (split-vertex n p c)
  split-prefix n p c = split n p c .snd .snd

  split-suffix : (n : Dim) (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y)
    → Chain (suffix-degree n p) (split-vertex n p c) y
  split-suffix n p c = split n p c .snd .fst

  whole-split : (n : Dim) (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y)
    → outer (whole (osuc n) c)
      ≡ˢ outer (compose (whole (suffix-degree n p) (split-suffix n p c))
        (whole (prefix-degree n p) (split-prefix n p c)))
  whole-split n pzero c = reflˢ
  whole-split (osuc n) (psuc p) c = strict-trans
    (strict-cong (λ h → outer (compose (last-arrow (osuc n) c) (inner h)))
      (whole-split n p (before-last (osuc n) c)))
    (assoc (last-arrow (osuc n) c)
      (whole (suffix-degree n p) (split-suffix n p (before-last (osuc n) c)))
      (whole (prefix-degree n p) (split-prefix n p (before-last (osuc n) c))))

-- Cubical tensor on disjoint coordinate blocks. It returns the required
-- dimension by recursion on the cut; no arithmetic/dimension transport.
tensor-cut : ∀ {ℓ} (n : Dim) (p : Position (osuc n)) {A B C : Type ℓ}
  → Cube (suffix-degree n p) (B → C) → Cube (prefix-degree n p) (A → B) → Cube n (A → C)
tensor-cut n pzero g f = map-cube n (λ h x → g (h x)) f
tensor-cut (osuc n) (psuc p) g f i = tensor-cut n p (g i) f
