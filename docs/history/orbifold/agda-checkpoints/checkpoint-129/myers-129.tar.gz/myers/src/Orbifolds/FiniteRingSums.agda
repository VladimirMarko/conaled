{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FiniteRingSums where

-- Finite sums and their invariance under an actual permutation.
-- The proof uses a finite Kronecker matrix; no choice of an ordering
-- is required by clients once they pass to a mere finite enumeration.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.SumFin using (Fin; fzero; fsuc; discreteFin)
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (¬_; yes; no)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
open import Cubical.Tactics.CommRingSolver

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)

  sum : (n : ℕ) → (Fin n → R .fst) → R .fst
  sum zero f = 0r
  sum (suc n) f = f fzero + sum n (λ i → f (fsuc i))

  delta : (n : ℕ) → Fin n → Fin n → R .fst
  delta zero ()
  delta (suc n) fzero fzero = 1r
  delta (suc n) fzero (fsuc j) = 0r
  delta (suc n) (fsuc i) fzero = 0r
  delta (suc n) (fsuc i) (fsuc j) = delta n i j

  abstract
    sum-ext : (n : ℕ) {f g : Fin n → R .fst}
      → ((i : Fin n) → f i ≡ g i) → sum n f ≡ sum n g
    sum-ext n p = cong (sum n) (funExt p)

    sum-zero : (n : ℕ) → sum n (λ _ → 0r) ≡ 0r
    sum-zero zero = refl
    sum-zero (suc n) = cong (0r +_) (sum-zero n) ∙ +IdL 0r

    rearrange : (a b c d : R .fst)
      → (a + b) + (c + d) ≡ (a + c) + (b + d)
    rearrange a b c d = solve! R

    sum-add : (n : ℕ) (f g : Fin n → R .fst)
      → sum n (λ i → f i + g i) ≡ sum n f + sum n g
    sum-add zero f g = sym (+IdL 0r)
    sum-add (suc n) f g =
      cong ((f fzero + g fzero) +_)
        (sum-add n (λ i → f (fsuc i)) (λ i → g (fsuc i)))
      ∙ rearrange (f fzero) (g fzero)
          (sum n (λ i → f (fsuc i))) (sum n (λ i → g (fsuc i)))

    sum-scale : (n : ℕ) (a : R .fst) (f : Fin n → R .fst)
      → sum n (λ i → a · f i) ≡ a · sum n f
    sum-scale zero a f = sym (0RightAnnihilates a)
    sum-scale (suc n) a f =
      cong ((a · f fzero) +_) (sum-scale n a (λ i → f (fsuc i)))
      ∙ sym (·DistR+ a (f fzero) (sum n (λ i → f (fsuc i))))

    exchange : (m n : ℕ) (f : Fin m → Fin n → R .fst)
      → sum m (λ i → sum n (f i)) ≡ sum n (λ j → sum m (λ i → f i j))
    exchange zero n f = sym (sum-zero n)
    exchange (suc m) n f =
      cong (sum n (f fzero) +_) (exchange m n (λ i → f (fsuc i)))
      ∙ sym (sum-add n (f fzero) (λ j → sum m (λ i → f (fsuc i) j)))

    delta-refl : (n : ℕ) (i : Fin n) → delta n i i ≡ 1r
    delta-refl zero ()
    delta-refl (suc n) fzero = refl
    delta-refl (suc n) (fsuc i) = delta-refl n i

    delta-equal : (n : ℕ) {i j : Fin n} → i ≡ j → delta n i j ≡ 1r
    delta-equal n {i} p = cong (delta n i) (sym p) ∙ delta-refl n i

    delta-distinct : (n : ℕ) (i j : Fin n)
      → ¬ (i ≡ j) → delta n i j ≡ 0r
    delta-distinct zero ()
    delta-distinct (suc n) fzero fzero distinct = Empty.rec (distinct refl)
    delta-distinct (suc n) fzero (fsuc j) distinct = refl
    delta-distinct (suc n) (fsuc i) fzero distinct = refl
    delta-distinct (suc n) (fsuc i) (fsuc j) distinct =
      delta-distinct n i j (λ p → distinct (cong fsuc p))

    delta-symmetric : (n : ℕ) (i j : Fin n) → delta n i j ≡ delta n j i
    delta-symmetric zero ()
    delta-symmetric (suc n) fzero fzero = refl
    delta-symmetric (suc n) fzero (fsuc j) = refl
    delta-symmetric (suc n) (fsuc i) fzero = refl
    delta-symmetric (suc n) (fsuc i) (fsuc j) = delta-symmetric n i j

    sum-delta : (n : ℕ) (i : Fin n) (f : Fin n → R .fst)
      → sum n (λ j → delta n i j · f j) ≡ f i
    sum-delta zero ()
    sum-delta (suc n) fzero f =
      cong₂ _+_ (·IdL (f fzero))
        (sum-ext n (λ j → 0LeftAnnihilates (f (fsuc j))) ∙ sum-zero n)
      ∙ +IdR (f fzero)
    sum-delta (suc n) (fsuc i) f =
      cong₂ _+_ (0LeftAnnihilates (f fzero))
        (sum-delta n i (λ j → f (fsuc j)))
      ∙ +IdL (f (fsuc i))

    delta-permutation : (n : ℕ) (e : Fin n ≃ Fin n) (i j : Fin n)
      → delta n (e .fst i) j ≡ delta n i (invEq e j)
    delta-permutation n e i j with discreteFin i (invEq e j)
    ... | yes equal = delta-equal n (cong (e .fst) equal ∙ secEq e j)
      ∙ sym (delta-equal n equal)
    ... | no distinct = delta-distinct n (e .fst i) j
        (λ equal → distinct (sym (retEq e i) ∙ cong (invEq e) equal))
      ∙ sym (delta-distinct n i (invEq e j) distinct)

    reindex : (n : ℕ) (e : Fin n ≃ Fin n) (f : Fin n → R .fst)
      → sum n (λ i → f (e .fst i)) ≡ sum n f
    reindex n e f =
      sum-ext n (λ i → sym (sum-delta n (e .fst i) f))
      ∙ exchange n n (λ i j → delta n (e .fst i) j · f j)
      ∙ sum-ext n (λ j →
          sum-ext n (λ i → cong (_· f j)
            (delta-permutation n e i j ∙ delta-symmetric n i (invEq e j)))
          ∙ sum-delta n (invEq e j) (λ _ → f j))
