{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteLabelledGraphProperness where

-- Properness of (g , x) ↦ (x , f g x) for an actually finite label type.
-- This includes every continuous action of an enumerated finite group:
-- multiplication and inverse laws are unnecessary for this topological
-- step. Properness of the anchor and compactness of X are not inputs.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin)
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( OpenFragment; Product; RectangleBasis )
open import Orbifolds.Intensional.CompactSeparation using
  ( List; PropositionalEM; Continuous; ProperData; ChosenHausdorff )
open import Orbifolds.Intensional.FiniteEnumeration using (ListCover)
open import Orbifolds.Intensional.OpenSubspaces using
  ( sumOpenFragment; identity-continuous )
open import Orbifolds.Intensional.ProperOpenBranchCharts using (pair-continuous)
open import Orbifolds.Intensional.FiniteCoproductCompactness using
  ( enumerate; enumerate-covers; finite-coproduct-proper; coproduct-continuous )
open import Orbifolds.Intensional.ClosedGraphProperness using (module Graph)

module Listed {ℓ : Level} {G X Y : Set ℓ}
    (ext : FunExt ℓ ℓ) (classical : PropositionalEM ℓ)
    (labels : List G) (listed : ListCover labels)
    (OX : OpenFragment X) (OY : OpenFragment Y)
    (OXY : OpenFragment (Product X Y))
    (setY : isSet Y) (separated : ChosenHausdorff OY)
    (first-continuous : Continuous OXY OX fst)
    (second-continuous : Continuous OXY OY snd)
    (f : G → X → Y) (continuous : (g : G) → Continuous OX OY (f g)) where

  arrowTopology : OpenFragment (Product G X)
  arrowTopology = sumOpenFragment (λ _ → OX)

  anchor : Product G X → Product X Y
  anchor z = snd z , f (fst z) (snd z)

  module One (g : G) = Graph ext OX OY OXY setY separated
    first-continuous second-continuous (f g) (continuous g)

  anchor-proper : ProperData arrowTopology OXY anchor
  anchor-proper = finite-coproduct-proper labels listed (λ _ → OX) OXY
    (λ g x → x , f g x) (λ g → One.graph-proper g classical)

  anchor-continuous : RectangleBasis OX OY OXY → Continuous arrowTopology OXY anchor
  anchor-continuous rectangles = coproduct-continuous (λ _ → OX) OXY
    (λ g x → x , f g x)
    (λ g → pair-continuous OX OX OY OXY (λ x → x) (f g) rectangles
      (identity-continuous OX) (continuous g))

module Enumerated {ℓ : Level} {G X Y : Set ℓ} {n : Nat}
    (ext : FunExt ℓ ℓ) (classical : PropositionalEM ℓ)
    (numbering : Equiv G (Fin {ℓ} n))
    (OX : OpenFragment X) (OY : OpenFragment Y)
    (OXY : OpenFragment (Product X Y))
    (setY : isSet Y) (separated : ChosenHausdorff OY)
    (first-continuous : Continuous OXY OX fst)
    (second-continuous : Continuous OXY OY snd)
    (f : G → X → Y) (continuous : (g : G) → Continuous OX OY (f g)) where

  module Result = Listed ext classical (enumerate numbering) (enumerate-covers numbering)
    OX OY OXY setY separated first-continuous second-continuous f continuous

  open Result public using (arrowTopology; anchor; anchor-proper; anchor-continuous)
