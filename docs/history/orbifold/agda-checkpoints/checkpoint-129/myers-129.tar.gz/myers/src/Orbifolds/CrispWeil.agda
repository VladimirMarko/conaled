{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispWeil where

-- Lemma 4.3.4 for every crisp Weil spectrum and every crisp infinitesimal
-- variety. The precise ambient crisp-truncation rule is explicit, while
-- the geometric proof uses the proved zero-locus presentation and the
-- literal crisp pullback axiom. No connectedness conclusion is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
import Orbifolds.CrispGeometry as CG
import Orbifolds.CrispPresented as CP
import Orbifolds.WeilAlgebras as WA
import Orbifolds.WeilZeroLocus as WZ
import Orbifolds.SyntheticField as SF

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R) where
  open CG.Context R
  module W = WA.Weil R
  module P = WZ.Ring R

  module Proof (distribute : FlatTruncationDistribution {ℓ = ℓ})
      (preserve : CG.Context.CrispPullbackPreservation R) where
    crisp-weil-connected : (@♭ algebra : W.WeilAlgebra)
      → Infinitesimal.Crystal.Connected (W.Spec algebra)
    crisp-weil-connected algebra = crisp-truncation-rec distribute
      (P.PointedPolynomialPresentation (W.Spec algebra) (W.origin algebra))
      isPropIsContr
      (λ presentation → CP.Context.crisp-presented-connected R preserve
        (W.Spec algebra) (W.origin algebra) presentation)
      (P.weil-zero-locus kock algebra)

    crisp-variety-connected : (@♭ X : Type ℓ) (@♭ x : X)
      → (@♭ variety : W.InfinitesimalVariety X x)
      → Infinitesimal.Crystal.Connected X
    crisp-variety-connected X x variety = crisp-truncation-rec distribute
      (P.PointedPolynomialPresentation X x) isPropIsContr
      (λ presentation → CP.Context.crisp-presented-connected R preserve X x presentation)
      (P.infinitesimal-variety-zero-locus kock variety)

    open WeilTests.WeilRealPushout
    open WeilTests.WeilDiagram

    connected-NW : (d : CrispRealPushout)
      → Infinitesimal.Crystal.Connected (W.Spec (WNW (diagram (underlying-diagram d))))
    connected-NW (box d) = crisp-weil-connected (WNW (diagram d))

    connected-NE : (d : CrispRealPushout)
      → Infinitesimal.Crystal.Connected (W.Spec (WNE (diagram (underlying-diagram d))))
    connected-NE (box d) = crisp-weil-connected (WNE (diagram d))

    connected-SW : (d : CrispRealPushout)
      → Infinitesimal.Crystal.Connected (W.Spec (WSW (diagram (underlying-diagram d))))
    connected-SW (box d) = crisp-weil-connected (WSW (diagram d))

    connected-SE : (d : CrispRealPushout)
      → Infinitesimal.Crystal.Connected (W.Spec (WSE (diagram (underlying-diagram d))))
    connected-SE (box d) = crisp-weil-connected (WSE (diagram d))

    module WeilModal = WeilTests.Indexed.Modal underlying-diagram Infinitesimal.CrystallineModality
      connected-NW connected-NE connected-SW connected-SE
