{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

module Orbifolds.CountableCovers where

-- The covering argument of Theorem 6.2.13 of arXiv:2205.15887v1.
-- This module isolates the real-analysis input as CountableProbe:
-- a sequence of open threshold predicates, all containing an origin,
-- with a point in each origin-neighborhood above only finitely many
-- thresholds.  For the intended reals one uses t < 1/(i+1).
-- The ordered-ring/Archimedean derivation of those probe data is not
-- proved here.  The compactness-to-cover-bound implication is proved.

open import Cubical.Foundations.Prelude hiding (_∨_)
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma using (_×_)
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.Nat.Order using (_<_)
open import Cubical.Data.Unit using (Unit*; tt*; isPropUnit*)
open import Cubical.HITs.PropositionalTruncation using (∥_∥₁; ∣_∣₁; squash₁)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.Compactness using (DPCompact)
open import Orbifolds.Penon
  using (PenonOpen; ProductPredicate; productPenonOpen; UnionPredicate; unionPenonOpen)
open import Orbifolds.PenonNeighborhoods
  using (BallStructure; CoveringProperty; Neighborhood; uniformPenonNeighborhood)
open BallStructure

private variable ℓ : Level

record CountableProbe (balls : BallStructure ℓ) : Type (ℓ-suc ℓ) where
  field
    origin : Carrier balls
    threshold : ℕ → Carrier balls → hProp ℓ
    thresholdOpen : (i : ℕ) → PenonOpen (threshold i)
    thresholdAtOrigin : (i : ℕ) → threshold i origin .fst
    probe : (ε : PositiveRadius balls) →
      ∥ Σ[ x ∈ Carrier balls ]
        (ball balls origin ε x .fst ×
          (Σ[ n ∈ ℕ ] ((i : ℕ) → threshold i x .fst → i < n))) ∥₁

open CountableProbe

-- Indices are a genuine subtype of the natural numbers, not a chosen
-- enumeration with unrecorded repetitions or an arbitrary higher type.
SubcountableIndex : (ℕ → hProp ℓ) → Type ℓ
SubcountableIndex J = Σ[ i ∈ ℕ ] J i .fst

Covers : {I K : Type ℓ} → (I → K → hProp ℓ) → Type ℓ
Covers {I = I} {K = K} U = (k : K) → ∥ Σ[ i ∈ I ] U i k .fst ∥₁

BoundedSubcover : {K : Type ℓ} (J : ℕ → hProp ℓ) →
  (SubcountableIndex J → K → hProp ℓ) → Type ℓ
BoundedSubcover {K = K} J U =
  ∥ Σ[ n ∈ ℕ ] ((k : K) →
      ∥ Σ[ i ∈ SubcountableIndex J ] ((i .fst < n) × U i k .fst) ∥₁) ∥₁

-- One bound works for every point of K; all witnesses remain truncated.
subcountableCoverBound : (balls : BallStructure ℓ) → CoveringProperty balls →
  CountableProbe balls → {K : Type ℓ} → DPCompact K →
  (J : ℕ → hProp ℓ) (U : SubcountableIndex J → K → hProp ℓ) →
  ((i : SubcountableIndex J) → PenonOpen (U i)) → Covers U → BoundedSubcover J U
subcountableCoverBound balls covering probes {K = K} compactK J U openU covers =
  PT.rec squash₁
    (λ neighborhood → PT.rec squash₁
      (λ testPoint → ∣ testPoint .snd .snd .fst ,
        (λ k → PT.map
          (λ member → member .fst ,
            (testPoint .snd .snd .snd (member .fst .fst) (member .snd .snd) ,
              member .snd .fst))
          (neighborhood .snd (testPoint .fst) (testPoint .snd .fst) k)) ∣₁)
      (probe probes (neighborhood .fst)))
    (uniformPenonNeighborhood balls covering compactK relation relationOpen
      (origin probes) relationAtOrigin)
  where
  relation : K × Carrier balls → hProp _
  relation = UnionPredicate (λ i → ProductPredicate (U i) (threshold probes (i .fst)))

  relationOpen : PenonOpen relation
  relationOpen = unionPenonOpen
    (λ i → ProductPredicate (U i) (threshold probes (i .fst))) (λ i →
    productPenonOpen (U i) (threshold probes (i .fst)) (openU i)
      (thresholdOpen probes (i .fst)))

  relationAtOrigin : (k : K) → relation (k , origin probes) .fst
  relationAtOrigin k = PT.map
    (λ member → member .fst , (member .snd , thresholdAtOrigin probes (member .fst .fst)))
    (covers k)

-- The full countable-index specialization of the same argument.
BoundedCountableSubcover : {K : Type ℓ} → (ℕ → K → hProp ℓ) → Type ℓ
BoundedCountableSubcover {K = K} U =
  ∥ Σ[ n ∈ ℕ ] ((k : K) → ∥ Σ[ i ∈ ℕ ] ((i < n) × U i k .fst) ∥₁) ∥₁

countableCoverBound : (balls : BallStructure ℓ) → CoveringProperty balls →
  CountableProbe balls → {K : Type ℓ} → DPCompact K →
  (U : ℕ → K → hProp ℓ) → ((i : ℕ) → PenonOpen (U i)) →
  ((k : K) → ∥ Σ[ i ∈ ℕ ] U i k .fst ∥₁) → BoundedCountableSubcover U
countableCoverBound {ℓ = ℓ} balls covering probes compactK U openU covers =
  PT.map (λ bounded → bounded .fst , (λ k →
    PT.map (λ member → member .fst .fst , member .snd) (bounded .snd k)))
    (subcountableCoverBound balls covering probes compactK
      (λ _ → Unit* {ℓ = ℓ} , isPropUnit*)
      (λ i → U (i .fst)) (λ i → openU (i .fst))
      (λ k → PT.map (λ member → (member .fst , tt*) , member .snd) (covers k)))

