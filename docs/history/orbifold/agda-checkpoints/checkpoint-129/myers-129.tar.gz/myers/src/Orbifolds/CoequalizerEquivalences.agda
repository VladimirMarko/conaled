{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CoequalizerEquivalences where

-- Homotopy coequalizers preserve equivalences of the two-object
-- diagram, with the actual specified square coherences retained.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Univalence using (EquivJ)
import Orbifolds.Coequalizers as CQ

module Map {ℓ : Level} {A B A' B' : Type ℓ}
    (f g : A → B) (f' g' : A' → B')
    (a : A → A') (b : B → B')
    (left : (x : A) → b (f x) ≡ f' (a x))
    (right : (x : A) → b (g x) ≡ g' (a x)) where
  map : CQ.Coeq f g → CQ.Coeq f' g'
  map (CQ.point y) = CQ.point (b y)
  map (CQ.edge x i) =
    (cong CQ.point (left x) ∙∙ CQ.edge (a x) ∙∙ sym (cong CQ.point (right x))) i

module Identity {ℓ : Level} {A B : Type ℓ} (f g : A → B) where
  module Diagram = Map f g f g (idfun A) (idfun B) (λ _ → refl) (λ _ → refl)

  agrees : (x : CQ.Coeq f g) → Diagram.map x ≡ x
  agrees (CQ.point y) = refl
  agrees (CQ.edge x i) j = doubleCompPath-filler refl (CQ.edge x) refl (~ j) i

  equivalent : isEquiv Diagram.map
  equivalent = subst isEquiv (sym (funExt agrees)) (idIsEquiv _)

same-objects : {ℓ : Level} {A B : Type ℓ}
  (f g f' g' : A → B)
  (left : (x : A) → f x ≡ f' x) (right : (x : A) → g x ≡ g' x)
  → isEquiv (Map.map f g f' g' (idfun A) (idfun B) left right)
same-objects {A = A} {B = B} f g f' g' left right =
  J (λ f' p → (g' : A → B) (q : g ≡ g')
      → isEquiv (Map.map f g f' g' (idfun A) (idfun B) (funExt⁻ p) (funExt⁻ q)))
    (λ g' q → J
      (λ g' q → isEquiv (Map.map f g f g' (idfun A) (idfun B) (λ _ → refl) (funExt⁻ q)))
      (Identity.equivalent f g) q)
    (funExt left) g' (funExt right)

same-domain : {ℓ : Level} {A B B' : Type ℓ}
  (e : B ≃ B') (f g : A → B) (f' g' : A → B')
  (left : (x : A) → equivFun e (f x) ≡ f' x)
  (right : (x : A) → equivFun e (g x) ≡ g' x)
  → isEquiv (Map.map f g f' g' (idfun A) (equivFun e) left right)
same-domain {A = A} {B' = B'} = EquivJ
  (λ B e → (f g : A → B) (f' g' : A → B')
    (left : (x : A) → equivFun e (f x) ≡ f' x)
    (right : (x : A) → equivFun e (g x) ≡ g' x)
    → isEquiv (Map.map f g f' g' (idfun A) (equivFun e) left right))
  same-objects

map-equivalent : {ℓ : Level} {A B A' B' : Type ℓ}
  (a : A ≃ A') (b : B ≃ B') (f g : A → B) (f' g' : A' → B')
  (left : (x : A) → equivFun b (f x) ≡ f' (equivFun a x))
  (right : (x : A) → equivFun b (g x) ≡ g' (equivFun a x))
  → isEquiv (Map.map f g f' g' (equivFun a) (equivFun b) left right)
map-equivalent {B = B} {A' = A'} {B' = B'} = EquivJ
  (λ A a → (b : B ≃ B') (f g : A → B) (f' g' : A' → B')
    (left : (x : A) → equivFun b (f x) ≡ f' (equivFun a x))
    (right : (x : A) → equivFun b (g x) ≡ g' (equivFun a x))
    → isEquiv (Map.map f g f' g' (equivFun a) (equivFun b) left right))
  same-domain

comparison-equivalence : {ℓ : Level} {A B A' B' : Type ℓ}
  (a : A ≃ A') (b : B ≃ B') (f g : A → B) (f' g' : A' → B')
  (left : (x : A) → equivFun b (f x) ≡ f' (equivFun a x))
  (right : (x : A) → equivFun b (g x) ≡ g' (equivFun a x))
  → CQ.Coeq f g ≃ CQ.Coeq f' g'
comparison-equivalence a b f g f' g' left right =
  Map.map f g f' g' (equivFun a) (equivFun b) left right ,
  map-equivalent a b f g f' g' left right
