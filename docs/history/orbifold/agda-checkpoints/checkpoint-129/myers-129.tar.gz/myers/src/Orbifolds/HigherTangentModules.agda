{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.HigherTangentModules where

-- Theorem 4.2.19 as an actual representable pointed mapping model.
-- The diagram is the genuine finite-free-module matrix category sent
-- to pointed sets by D.  Its value at n is Map_*(D(n), (X,x)), and
-- every operation is literal pointed precomposition.  Finite-product
-- preservation is proved for this construction.  The WildFunctor
-- below is only a convenient view of the inherited operations/laws;
-- a finite list of wild-category axioms is not used as a substitute
-- definition of an arbitrary coherent higher module.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Pointed
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; _+_)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Categories.Category.Base using (Category)
open import Cubical.Categories.Functor.Base using (Functor)
import Cubical.WildCat.Base as Wild
import Cubical.WildCat.Functor as WF
import Cubical.WildCat.Instances.NonWild as NW
import Cubical.WildCat.Instances.Types as WT
import Orbifolds.FirstOrderLinearMaps as LM
import Orbifolds.FirstOrderMatrixCoproducts as MC
import Orbifolds.FirstOrderInfinitesimalLinearity as IL
import Orbifolds.FirstOrderTangentDelooping as TD
import Orbifolds.TangentProducts as TP
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.Quotients as Q

-- This is a restricted representable construction, with arbitrary
-- higher target.  Its data are the actual pointed-set test functor and
-- the actual representing pointed type, not arbitrary algebraic maps.
module RestrictedRepresentable {ℓc ℓh ℓt ℓx : Level}
    (C : Category ℓc ℓh) (tests : Functor C (LM.PointedSets ℓt))
    (target : Pointed ℓx) where
  module C = Category C
  module F = Functor tests

  test : C.ob → Pointed ℓt
  test c = F.F-ob c .fst .fst , F.F-ob c .snd

  Value : C.ob → Type (ℓ-max ℓt ℓx)
  Value c = test c →∙ target

  operation : {a b : C.ob} → C.Hom[ a , b ] → Value b → Value a
  operation f v = v ∘∙ F.F-hom f

  operation-identity : {a : C.ob} → operation (C.id {a}) ≡ idfun (Value a)
  operation-identity = funExt λ v → cong (v ∘∙_) F.F-id ∙ ∘∙-idˡ v

  operation-composition : {a b c : C.ob} (f : C.Hom[ a , b ]) (g : C.Hom[ b , c ])
    → operation (C._⋆_ f g) ≡ operation f ∘ operation g
  operation-composition f g = funExt λ v →
    cong (v ∘∙_) (F.F-seq f g) ∙ sym (∘∙-assoc v (F.F-hom g) (F.F-hom f))

  -- Operation is a function on the actual hom type.  Its action on
  -- paths, paths between paths, and arbitrarily indexed families is
  -- inherited from that function, rather than separately supplied.
  operation-path : {a b : C.ob} {f g : C.Hom[ a , b ]}
    → f ≡ g → operation f ≡ operation g
  operation-path = cong operation

  operation-family : {ℓi : Level} {I : Type ℓi} {a b : C.ob}
    → (I → C.Hom[ a , b ]) → (I → Value b) → I → Value a
  operation-family f v i = operation (f i) (v i)

  view : WF.WildFunctor (Wild._^op (NW.AsWildCat C)) (WT.TypeCat (ℓ-max ℓt ℓx))
  WF.WildFunctor.F-ob view = Value
  WF.WildFunctor.F-hom view = operation
  WF.WildFunctor.F-id view = operation-identity
  WF.WildFunctor.F-seq view f g = operation-composition g f

module Ring {ℓ : Level} (R : CommRing ℓ) where
  module Linear = LM.Ring R
  module Coproducts = MC.Ring R
  module Disks = IL.Ring R
  module Differential = SD.FirstOrder R
  module Tangent = Q.PointedTest Differential.D Differential.zeroD

  module Model (target : Pointed ℓ) where
    module Representable = RestrictedRepresentable Linear.MatrixCategory Linear.disk-functor target
    open Representable using (Value; operation; view) public
    module Products = TP.Ring R (typ target) (pt target)

    comparison : (n m : ℕ) → Value (n + m) → Value n × Value m
    comparison n m v = operation (Coproducts.Binary.left-injection n m) v ,
      operation (Coproducts.Binary.right-injection n m) v

    comparison-coherence : (n m : ℕ)
      → comparison n m ≡ Products.Binary.comparison n m
    comparison-coherence n m = funExt λ v i →
      cong (v ∘∙_) (Coproducts.Binary.pointed-disk-left n m) i ,
      cong (v ∘∙_) (Coproducts.Binary.pointed-disk-right n m) i

    -- These fields express only preservation of the displayed genuine
    -- initial/coproduct diagrams.  All operations and their inherited
    -- coherence have already been fixed by the representable model.
    record PreservesFiniteProducts : Type ℓ where
      field
        terminal : isContr (Value 0)
        binary : (n m : ℕ) → isEquiv (comparison n m)

    infinitesimal-linearity→products : Disks.InfinitesimallyLinear (typ target)
      → PreservesFiniteProducts
    PreservesFiniteProducts.terminal (infinitesimal-linearity→products linear) =
      Products.preserves-terminal
    PreservesFiniteProducts.binary (infinitesimal-linearity→products linear) n m =
      subst isEquiv (sym (comparison-coherence n m)) (Products.preserves-products linear n m)

    rank-one : Value 1 ≃ Tangent.Tangent (typ target) (pt target)
    rank-one = isoToEquiv (post∘∙equiv (TD.Coordinate.pointed-equivalence R))

    rank-one-pointed : (Value 1 , (const (pt target) , refl))
      ≃∙ (Tangent.Tangent (typ target) (pt target) , (const (pt target) , refl))
    rank-one-pointed = rank-one , ΣPathP (refl , sym compPathRefl)

  -- A concrete presentation of the higher R-module: a product-
  -- preserving restriction of the representable mapping construction
  -- along the actual finite-free module disk functor.  It is not a
  -- claim that every coherent module admits such a presentation.
  RepresentableModule : Type (ℓ-suc ℓ)
  RepresentableModule = Σ[ target ∈ Pointed ℓ ] Model.PreservesFiniteProducts target

  underlying : RepresentableModule → Type ℓ
  underlying (target , _) = Model.Value target 1

  tangent-module : (X : Type ℓ) (x : X) → Disks.InfinitesimallyLinear X → RepresentableModule
  tangent-module X x linear = (X , x) , Model.infinitesimal-linearity→products (X , x) linear

  tangent-module-identification : (X : Type ℓ) (x : X) (linear : Disks.InfinitesimallyLinear X)
    → underlying (tangent-module X x linear) ≃ Tangent.Tangent X x
  tangent-module-identification X x linear = Model.rank-one (X , x)
