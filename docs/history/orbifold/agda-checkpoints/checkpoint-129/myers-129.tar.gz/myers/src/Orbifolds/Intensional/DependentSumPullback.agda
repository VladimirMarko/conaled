{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.DependentSumPullback where

-- The actual pullback of a dependent-sum projection. The carrier comparison
-- requires no setness. Joint injectivity from the two projection equations
-- uses the explicitly stated setness of the old base, not unrestricted K.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity hiding (section; retraction; lift)

sigma-snd-path : {a b : Level} {A : Set a} {B : A → Set b}
  {u v : Σ A B} (p : u ≡ v) → subst B (cong fst p) (snd u) ≡ snd v
sigma-snd-path refl = refl

fiber-injective : {ℓ : Level} {A : Set ℓ} {B : A → Set ℓ}
  → isSet A → (x : A) → {a b : B x} → (x , a) ≡ (x , b) → a ≡ b
fiber-injective {B = B} setA x {a} p =
  sym (cong (λ e → subst B e a) (setA x x (cong fst p) refl)) ∙ sigma-snd-path p

module Pullback {ℓ : Level} (Z W : Set ℓ) (F : Z → Set ℓ) (f : W → Z) where
  Original : Set ℓ
  Original = Σ Z F

  Pulled : Set ℓ
  Pulled = Σ W (λ w → F (f w))

  projection : Pulled → W
  projection = fst

  map : Pulled → Original
  map (w , q) = f w , q

  Actual : Set ℓ
  Actual = Σ W (λ w → Σ Original (λ p → fst p ≡ f w))

  to : Pulled → Actual
  to (w , q) = w , ((f w , q) , refl)

  from : Actual → Pulled
  from (w , ((z , q) , e)) = w , subst F e q

  section : (p : Actual) → to (from p) ≡ p
  section (w , ((.(f w) , q) , refl)) = refl

  retraction : (p : Pulled) → from (to p) ≡ p
  retraction (w , q) = refl

  equivalence : Equiv Pulled Actual
  equivalence = equiv to from section retraction

  joint-injective : isSet Z → {p q : Pulled}
    → projection p ≡ projection q → map p ≡ map q → p ≡ q
  joint-injective setZ {w , a} {.w , b} refl e =
    cong (λ v → w , v) (fiber-injective setZ (f w) e)

  module Cone {A : Set ℓ} (base : A → W) (total : A → Original)
      (square : (a : A) → fst (total a) ≡ f (base a)) where
    lift : A → Pulled
    lift a = base a , subst F (square a) (snd (total a))

    base-triangle : (a : A) → projection (lift a) ≡ base a
    base-triangle a = refl

    total-triangle : (a : A) → map (lift a) ≡ total a
    total-triangle a = sym (Σ-path {u = total a} {v = map (lift a)} (square a) refl)

    unique : isSet Z → (k : A → Pulled)
      → ((a : A) → projection (k a) ≡ base a)
      → ((a : A) → map (k a) ≡ total a)
      → (a : A) → k a ≡ lift a
    unique setZ k kb kt a = joint-injective setZ (kb a) (kt a ∙ sym (total-triangle a))
