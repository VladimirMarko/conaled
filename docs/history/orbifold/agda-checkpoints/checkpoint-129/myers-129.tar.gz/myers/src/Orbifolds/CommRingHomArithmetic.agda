{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CommRingHomArithmetic where

-- Concrete transport of powers, unit witnesses and the displayed 2-by-2
-- coordinate determinant along an actual commutative-ring homomorphism.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Properties
import Orbifolds.SyntheticField as SF
import Orbifolds.WeilLinearCoefficientRigidity as LR

module Hom {ℓ ℓ' : Level} (R : CommRing ℓ) (S : CommRing ℓ')
    (f : CommRingHom R S) where
  module A = CommRingStr (R .snd)
  module B = CommRingStr (S .snd)
  module AR = LR.Calculation R
  module BR = LR.Calculation S
  module AP = Exponentiation R
  module BP = Exponentiation S
  module AU = SF.RingContext R
  module BU = SF.RingContext S
  open IsCommRingHom (f .snd)

  map-power : (x : R .fst) (n : ℕ)
    → f .fst (AP._^_ x n) ≡ BP._^_ (f .fst x) n
  map-power x zero = pres1
  map-power x (suc n) = pres· x (AP._^_ x n)
    ∙ cong (B._·_ (f .fst x)) (map-power x n)

  map-unit : (x : R .fst) → AU.Invertible x → BU.Invertible (f .fst x)
  map-unit x (inverse , inverse-law) = f .fst inverse ,
    sym (pres· x inverse) ∙ cong (f .fst) inverse-law ∙ pres1

  map-three : f .fst AR.three ≡ BR.three
  map-three = pres+ (A._+_ A.1r A.1r) A.1r
    ∙ cong₂ B._+_ (pres+ A.1r A.1r ∙ cong₂ B._+_ pres1 pres1) pres1

  map-four : f .fst AR.four ≡ BR.four
  map-four = pres+ AR.three A.1r ∙ cong₂ B._+_ map-three pres1

  map-difference : (x y : R .fst)
    → f .fst (A._-_ x y) ≡ B._-_ (f .fst x) (f .fst y)
  map-difference x y = pres+ x (A.-_ y) ∙ cong₂ B._+_ refl (pres- y)

  map-one-offset : (x : R .fst)
    → f .fst (A._-_ x A.1r) ≡ B._-_ (f .fst x) B.1r
  map-one-offset x = map-difference x A.1r ∙ cong (B._-_ (f .fst x)) pres1

  map-determinant : (a b c d : R .fst)
    → f .fst (AR.determinant₂ a b c d)
      ≡ BR.determinant₂ (f .fst a) (f .fst b) (f .fst c) (f .fst d)
  map-determinant a b c d = map-difference (A._·_ a d) (A._·_ b c)
    ∙ cong₂ B._-_ (pres· a d) (pres· b c)

  three-unit : AU.Invertible AR.three → BU.Invertible BR.three
  three-unit witness = subst BU.Invertible map-three (map-unit AR.three witness)

  four-unit : AU.Invertible AR.four → BU.Invertible BR.four
  four-unit witness = subst BU.Invertible map-four (map-unit AR.four witness)

  determinant-unit : (a b c d : R .fst) → AU.Invertible (AR.determinant₂ a b c d)
    → BU.Invertible (BR.determinant₂ (f .fst a) (f .fst b) (f .fst c) (f .fst d))
  determinant-unit a b c d witness = subst BU.Invertible (map-determinant a b c d)
    (map-unit (AR.determinant₂ a b c d) witness)
