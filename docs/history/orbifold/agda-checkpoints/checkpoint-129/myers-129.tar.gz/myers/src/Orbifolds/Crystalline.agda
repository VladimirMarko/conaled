{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- The actual higher-inductive nullification of Definition 4.3.1.
-- Its generator is the double-negation neighbourhood of zero, not the
-- collection of Weil spectra and not merely the square-zero elements.
module Orbifolds.Crystalline where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Equiv.PathSplit using (fromIsEquiv)
open import Cubical.Data.Sigma
open import Cubical.Data.Unit
import Cubical.Data.Empty as Empty
open import Cubical.Functions.Surjection
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Modalities.Modality using (Modality)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Ring.Properties
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Orbifolds.Penon as PN
import Orbifolds.SyntheticDifferential as SD
import Orbifolds.SyntheticField as SF
import Orbifolds.ModalEtaleClosure as EC
import Orbifolds.MicrolinearModal as MM
import Orbifolds.TangentEtale as TE

module Ring {ℓ : Level} (R : CommRing ℓ) where
  open CommRingStr (R .snd)
  open RingTheory (CommRing→Ring R)

  Carrier : Type ℓ
  Carrier = R .fst

  𝔇 : Type ℓ
  𝔇 = PN.InfinitesimalNeighborhood 0r

  zero𝔇 : 𝔇
  zero𝔇 = 0r , PN.neighborRefl 0r

  CrystallineGenerator : Unit → Type ℓ
  CrystallineGenerator _ = 𝔇

  CrystallineModality : Modality ℓ
  CrystallineModality = NP.NullModality {ℓ = ℓ} CrystallineGenerator

  module Crystal = EC.Theory CrystallineModality
  module Microlinear = MM.Theory CrystallineModality

  Im : Type ℓ → Type ℓ
  Im = Crystal.◯

  IsCrystalline : Type ℓ → Type ℓ
  IsCrystalline = Crystal.isModal

  crystalline-unit : {X : Type ℓ} → X → Im X
  crystalline-unit = Crystal.η

  -- Pointed nullification fixes all propositions. Consequently its units
  -- are merely surjective; the elimination target remains a proposition.
  proposition-crystalline : {X : Type ℓ} → isProp X → IsCrystalline X
  proposition-crystalline propX _ = fromIsEquiv const (isoToIsEquiv
    (iso const (λ f → f zero𝔇)
      (λ f → funExt λ d → propX (f zero𝔇) (f d)) (λ _ → refl)))

  crystalline-unit-surjective : {X : Type ℓ} → isSurjection (crystalline-unit {X})
  crystalline-unit-surjective = Crystal.◯-elim
    (λ _ → proposition-crystalline PT.squash₁) (λ x → PT.∣ x , refl ∣₁)

  crystalline-preserves-empty : Im (Empty.⊥* {ℓ = ℓ}) ≃ Empty.⊥* {ℓ = ℓ}
  crystalline-preserves-empty = invEquiv
    (crystalline-unit , Crystal.isModalToIsEquiv (proposition-crystalline (λ ())))

  infinitesimal-connected : Crystal.Connected 𝔇
  infinitesimal-connected = NP.generatorsConnected CrystallineGenerator tt

  infinitesimal-base-equivalence : Crystal.ModalEquivalence (λ (_ : Unit* {ℓ = ℓ}) → zero𝔇)
  infinitesimal-base-equivalence = Crystal.connected-map-is-modal-equivalence
    (λ _ → zero𝔇) (Crystal.preserves-contractible isContrUnit*) infinitesimal-connected

  module InfinitesimalTangent = TE.Theory CrystallineModality 𝔇 zero𝔇 infinitesimal-connected

  -- The shape construction at the same universe is also an actual HIT.
  ShapeGenerator : Unit → Type ℓ
  ShapeGenerator _ = Carrier

  ShapeModality : Modality ℓ
  ShapeModality = NP.NullModality {ℓ = ℓ} ShapeGenerator

  module Shape = EC.Theory ShapeModality

  shape : Type ℓ → Type ℓ
  shape = Shape.◯

  IsShapeModal : Type ℓ → Type ℓ
  IsShapeModal = Shape.isModal

  real-shape-connected : Shape.Connected Carrier
  real-shape-connected = NP.generatorsConnected ShapeGenerator tt

  -- The multiplicative action used in Lemma 4.3.7 preserves the actual
  -- double-negation neighbourhood. This needs only the ring operations.
  scale : Carrier → 𝔇 → 𝔇
  scale t (x , neighbor) = t · x ,
    subst (PN.Neighbors (t · x)) (0RightAnnihilates t)
      (PN.preservesNeighbors (t ·_) neighbor)

  scale-zero : (d : 𝔇) → scale 0r d ≡ zero𝔇
  scale-zero d = Σ≡Prop (λ _ → PN.isPropNeighbors) (0LeftAnnihilates (fst d))

  scale-one : (d : 𝔇) → scale 1r d ≡ d
  scale-one d = Σ≡Prop (λ _ → PN.isPropNeighbors) (·IdL (fst d))

  real-contraction-curve : 𝔇 → Carrier → shape 𝔇
  real-contraction-curve d t = Shape.η (scale t d)

  shape-contraction-on-units : (d : 𝔇) → Shape.η zero𝔇 ≡ Shape.η d
  shape-contraction-on-units d = sym (cong Shape.η (scale-zero d))
    ∙ sym (NB.spoke tt (real-contraction-curve d) 0r)
    ∙ NB.spoke tt (real-contraction-curve d) 1r
    ∙ cong Shape.η (scale-one d)

  infinitesimal-shape-connected : Shape.Connected 𝔇
  infinitesimal-shape-connected = Shape.η zero𝔇 ,
    Shape.◯-elim (λ z → Shape.◯-=-isModal (Shape.η zero𝔇) z) shape-contraction-on-units

  -- Lemma 4.3.7's principal inclusion, without assuming global lexness
  -- or an identification of nullification with a different modality.
  shape-modal→crystalline : {X : Type ℓ} → IsShapeModal X → IsCrystalline X
  shape-modal→crystalline modalX _ = fromIsEquiv const
    (Shape.connected-constant infinitesimal-shape-connected modalX)

  shape-modal-fibres→crystalline-fibres : {X Y : Type ℓ} (f : X → Y)
    → ((y : Y) → IsShapeModal (fiber f y))
    → ((y : Y) → IsCrystalline (fiber f y))
  shape-modal-fibres→crystalline-fibres f modalFibres y = shape-modal→crystalline (modalFibres y)

  crystalline-connected→shape-connected : {X : Type ℓ}
    → Crystal.Connected X → Shape.Connected X
  crystalline-connected→shape-connected connectedX = Shape.constant-detects-connected
    (Crystal.connected-constant connectedX (shape-modal→crystalline Shape.◯-isModal))

  crystalline-connected-fibres→shape-connected-fibres : {X Y : Type ℓ} (f : X → Y)
    → ((y : Y) → Crystal.Connected (fiber f y))
    → ((y : Y) → Shape.Connected (fiber f y))
  crystalline-connected-fibres→shape-connected-fibres f connectedFibres y =
    crystalline-connected→shape-connected (connectedFibres y)

  -- A shape-etale map is a pullback of a map between shape-modal types.
  -- Those types are crystalline by the proved inclusion, so its actual
  -- crystalline unit-naturality square is also a pullback.
  shape-etale→crystalline-etale : {X Y : Type ℓ} (f : X → Y)
    → Shape.Etale f → Crystal.Etale f
  shape-etale→crystalline-etale f etale = Crystal.etale-precompose-equivalence
    (Shape.unit-gap f , etale) fst
    (Crystal.pullback-modal-map-etale
      (shape-modal→crystalline Shape.◯-isModal)
      (shape-modal→crystalline Shape.◯-isModal)
      (Shape.◯-map f) Shape.η)

  -- The first-order object maps into the chosen generator under Kock's
  -- field axiom. This is not an assertion that the two objects coincide,
  -- nor does inclusion alone prove first-order crystalline connectedness.
  first-order→infinitesimal : SF.RingContext.KockField R → SD.FirstOrder.D R → 𝔇
  first-order→infinitesimal kock d = fst d , SF.RingContext.nilpotent-neighbor R kock d
