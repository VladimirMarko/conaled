{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.ConditionalIntegerSubgroups where

-- A constructive test for replacing rational rank by finite freeness.
-- For an ordinary proposition P, H_P = {z : Z | 2 divides z or P}
-- is an actual additive group between 2Z and Z. Merely knowing that it
-- has a cyclic generator already decides P. No excluded middle for P
-- is used to define the group or to prove the implication.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ; pos; isSetℤ)
import Cubical.Data.Int as Int
import Cubical.Data.Int.Divisibility as Div
import Cubical.Data.Nat.Divisibility as NatDiv
import Cubical.Data.Nat.Order as NatOrder
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.Sum as Sum
import Cubical.Data.Empty as Empty
open import Cubical.Relation.Nullary using (Dec; yes; no; ¬_; isPropDec)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom; compGroupHom)
open import Cubical.Algebra.Group.Instances.Int using (ℤGroup; ℤHom)
open import Cubical.Algebra.Group.ZAction using
  (_ℤ[_]·_; homPresℤ·; rUnitℤ·ℤ; ℤ·≡·)
open import Cubical.Functions.Embedding using (isEmbedding; injEmbedding)
import Cubical.HITs.PropositionalTruncation as PT

module Z = CommRingStr (ℤCommRing .snd)

Even : ℤ → Type ℓ-zero
Even z = pos 2 Div.∣ z

one-not-even : ¬ Even (pos 1)
one-not-even e = NatOrder.¬-<-zero
  (NatOrder.pred-≤-pred (NatDiv.m∣sn→m≤sn (Div.∣→∣ℕ e)))

integer-hom-is-multiplication : (f : GroupHom ℤGroup ℤGroup) (z : ℤ)
  → f .fst z ≡ Z._·_ z (f .fst (pos 1))
integer-hom-is-multiplication f z = cong (f .fst) (sym (rUnitℤ·ℤ z))
  ∙ homPresℤ· f (pos 1) z ∙ sym (ℤ·≡· z (f .fst (pos 1)))

module Proposition {ℓ : Level} (P : Type ℓ) (propP : isProp P) where
  Member : ℤ → Type ℓ
  Member z = PT.∥ Even z ⊎ P ∥₁

  member-prop : (z : ℤ) → isProp (Member z)
  member-prop z = PT.squash₁

  even-member : {z : ℤ} → Even z → Member z
  even-member e = PT.∣ inl e ∣₁

  proposition-member : P → (z : ℤ) → Member z
  proposition-member p z = PT.∣ inr p ∣₁

  zero-member : Member (pos 0)
  zero-member = even-member Div.∣-zeroʳ

  member-add : {z w : ℤ} → Member z → Member w → Member (Z._+_ z w)
  member-add = PT.rec2 PT.squash₁ λ
    { (inl ez) (inl ew) → even-member (Div.∣-+ ez ew)
    ; (inl _) (inr p) → proposition-member p _
    ; (inr p) _ → proposition-member p _ }

  member-negate : {z : ℤ} → Member z → Member (Z.-_ z)
  member-negate = PT.rec PT.squash₁ λ
    { (inl e) → even-member (Div.∣-right· {n = Int.negsuc 0} e)
    ; (inr p) → proposition-member p _ }

  Carrier : Type ℓ
  Carrier = Σ ℤ Member

  GroupH : Group ℓ
  GroupH = makeGroup
    (pos 0 , zero-member)
    (λ x y → Z._+_ (x .fst) (y .fst) , member-add (x .snd) (y .snd))
    (λ x → Z.-_ (x .fst) , member-negate (x .snd))
    (isSetΣ isSetℤ (λ z → isProp→isSet (member-prop z)))
    (λ x y z → Σ≡Prop member-prop (Z.+Assoc (x .fst) (y .fst) (z .fst)))
    (λ x → Σ≡Prop member-prop (Z.+IdR (x .fst)))
    (λ x → Σ≡Prop member-prop (Z.+IdL (x .fst)))
    (λ x → Σ≡Prop member-prop (Z.+InvR (x .fst)))
    (λ x → Σ≡Prop member-prop (Z.+InvL (x .fst)))

  inclusion : GroupHom GroupH ℤGroup
  inclusion = fst , makeIsGroupHom (λ _ _ → refl)

  inclusion-embedding : isEmbedding (inclusion .fst)
  inclusion-embedding = injEmbedding isSetℤ (Σ≡Prop member-prop)

  doubling : GroupHom ℤGroup GroupH
  doubling .fst z = Z._·_ (pos 2) z , even-member (Div.∣-left {m = pos 2} {k = z})
  doubling .snd = makeIsGroupHom λ z w →
    Σ≡Prop member-prop (Z.·DistR+ (pos 2) z w)

  contains-two : Carrier
  contains-two = pos 2 , even-member (Div.∣-refl refl)

  inclusion-after-doubling : (z : ℤ)
    → inclusion .fst (doubling .fst z) ≡ Z._·_ (pos 2) z
  inclusion-after-doubling z = refl

  doubling-after-inclusion : (x : Carrier)
    → doubling .fst (inclusion .fst x)
      ≡ GroupStr._·_ (GroupH .snd) x x
  doubling-after-inclusion x = Σ≡Prop member-prop
    (cong (Z._+_ (x .fst)) (Z.+IdR (x .fst)))

  odd-member→proposition : {z : ℤ} → ¬ Even z → Member z → P
  odd-member→proposition not-even = PT.rec propP
    (Sum.rec (λ even → Empty.rec (not-even even)) (λ p → p))

  one-member→proposition : Member (pos 1) → P
  one-member→proposition = odd-member→proposition one-not-even

  Generates : Carrier → Type ℓ
  Generates a = (x : Carrier) → a .fst Div.∣ x .fst

  MerelyCyclic : Type ℓ
  MerelyCyclic = PT.∥ Σ Carrier Generates ∥₁

  generator→decidable : (a : Carrier) → Generates a → Dec P
  generator→decidable a generates with Div.dec∣ (pos 2) (a .fst)
  ... | yes even = no λ p → one-not-even
    (Div.∣-trans even (generates (pos 1 , proposition-member p (pos 1))))
  ... | no not-even = yes (odd-member→proposition not-even (a .snd))

  merely-cyclic→decidable : MerelyCyclic → Dec P
  merely-cyclic→decidable = PT.rec (isPropDec propP)
    (λ (a , generates) → generator→decidable a generates)

  basis→cyclic : GroupEquiv ℤGroup GroupH → Σ Carrier Generates
  basis→cyclic e = e .fst .fst (pos 1) , λ x →
    PT.∣ invEq (e .fst) x ,
      sym (integer-hom-is-multiplication projected (invEq (e .fst) x))
      ∙ cong fst (secEq (e .fst) x) ∣₁
    where
    forward : GroupHom ℤGroup GroupH
    forward = e .fst .fst , e .snd
    projected : GroupHom ℤGroup ℤGroup
    projected = compGroupHom forward inclusion

  merely-integral-basis→decidable : PT.∥ GroupEquiv ℤGroup GroupH ∥₁ → Dec P
  merely-integral-basis→decidable = merely-cyclic→decidable ∘ PT.map basis→cyclic
