{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CubicalConeAttachments where

-- Adding endpoint-typed cubical coherence to an existing partial cone.
-- The actual dependent filler type is compared to a literal homotopy
-- pullback; this proves its mapping property and microlinearity without
-- making the filler or boundary comparison an assumption.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Orbifolds.CubicalShells as CS
open CS using (Cube; Shell; restriction)
open import Orbifolds.CubicalShellFillers
import Orbifolds.Microlinearity as Micro
import Orbifolds.MicrolinearityLimits as ML

module Attachment {ℓ : Level} (Previous Cells : Type ℓ)
    (dimension : Cells → ℕ) (Coefficient : Cells → Type ℓ)
    (boundary-data : Previous → (c : Cells) → Shell (dimension c) (Coefficient c)) where

  FreeFillers : Type ℓ
  FreeFillers = (c : Cells) → Cube (dimension c) (Coefficient c)

  Boundaries : Type ℓ
  Boundaries = (c : Cells) → Shell (dimension c) (Coefficient c)

  restrict-fillers : FreeFillers → Boundaries
  restrict-fillers fill c = restriction (dimension c) (fill c)

  Next : Type ℓ
  Next = Σ[ previous ∈ Previous ]
    ((c : Cells) → Filler (dimension c) (boundary-data previous c))

  forget : Next → Previous
  forget = fst

  filler : (p : Next) (c : Cells)
    → Filler (dimension c) (boundary-data (forget p) c)
  filler p c = p .snd c

  Fiberwise : Type ℓ
  Fiberwise = Σ[ previous ∈ Previous ]
    ((c : Cells) → fiber (restriction (dimension c)) (boundary-data previous c))

  pullback-to-fibers : ML.Pullback boundary-data restrict-fillers → Fiberwise
  pullback-to-fibers ((previous , fill) , commutes) =
    previous , (λ c → fill c , (λ i → commutes (~ i) c))

  fibers-to-pullback : Fiberwise → ML.Pullback boundary-data restrict-fillers
  fibers-to-pullback (previous , fill) =
    (previous , (λ c → fill c .fst)) , (λ i c → fill c .snd (~ i))

  pullback-fibers : ML.Pullback boundary-data restrict-fillers ≃ Fiberwise
  pullback-fibers = isoToEquiv (iso pullback-to-fibers fibers-to-pullback
    (λ _ → refl) (λ _ → refl))

  fibers-next : Fiberwise ≃ Next
  fibers-next = Σ-cong-equiv-snd λ previous → equivΠCod λ c →
    fiber-filler-equivalence (dimension c) (boundary-data previous c)

  pullback-next : ML.Pullback boundary-data restrict-fillers ≃ Next
  pullback-next = pullback-fibers ∙ₑ fibers-next

  pullback-forget : (p : ML.Pullback boundary-data restrict-fillers)
    → forget (pullback-next .fst p) ≡ p .fst .fst
  pullback-forget p = refl

  pullback-filler : (previous : Previous) (fill : FreeFillers)
    (commutes : boundary-data previous ≡ restrict-fillers fill) (c : Cells)
    → filler (pullback-next .fst ((previous , fill) , commutes)) c
      ≡ subst (Filler (dimension c)) (λ i → commutes (~ i) c)
          (canonical-filler (dimension c) (fill c))
  pullback-filler previous fill commutes c = refl

  ExtensionCone : {ℓt : Level} → Type ℓt → Type (ℓ-max ℓt ℓ)
  ExtensionCone T = Σ[ old ∈ (T → Previous) ]
    ((t : T) (c : Cells) → Filler (dimension c) (boundary-data (old t) c))

  restrict-extension : {ℓt : Level} {T : Type ℓt} → (T → Next) → ExtensionCone T
  restrict-extension h = (forget ∘ h) , (λ t c → filler (h t) c)

  assemble-extension : {ℓt : Level} {T : Type ℓt} → ExtensionCone T → T → Next
  assemble-extension (old , fill) t = old t , fill t

  extension-universal : {ℓt : Level} (T : Type ℓt) → (T → Next) ≃ ExtensionCone T
  extension-universal T = isoToEquiv (iso restrict-extension assemble-extension
    (λ _ → refl) (λ _ → refl))

  assemble-forget : {ℓt : Level} {T : Type ℓt} (c : ExtensionCone T)
    → forget ∘ assemble-extension c ≡ c .fst
  assemble-forget c = refl

  assemble-filler : {ℓt : Level} {T : Type ℓt} (c : ExtensionCone T)
    (t : T) (j : Cells)
    → filler (assemble-extension c t) j ≡ c .snd t j
  assemble-filler c t j = refl

  module Microlinear {ℓi ℓw : Level} {Index : Type ℓi}
      (test : Index → Micro.TestSquare ℓw) where
    module M = Micro.Theory test
    module Closure = ML.Limits test

    next-microlinear : M.Microlinear Previous
      → ((c : Cells) → M.Microlinear (Coefficient c)) → M.Microlinear Next
    next-microlinear previous coefficients = Closure.microlinear-equiv pullback-next
      (Closure.microlinear-pullback boundary-data restrict-fillers previous
        (M.microlinear-Π (λ c → CS.Microlinear.cube-microlinear test
          (dimension c) (coefficients c)))
        (M.microlinear-Π (λ c → CS.Microlinear.shell-microlinear test
          (dimension c) (coefficients c))))
