{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.CoherentArrowReversal where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken)
open import Orbifolds.Coherent.OuterCoordinateReversal public using (last-position; reverse-position;
  prefix-last; suffix-last; reverse-prefix-degree; reverse-suffix-degree)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as AC
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken)
import Orbifolds.Coherent.CoherentArrowSplits as AS
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)

module Reversal {ℓ : Level} (C : Category ℓ ℓ) where
  open Category C
  module Source = AC.Arrows (Opposite C)
  open AC.Arrows C
  module Cast = AS.Splits C

  prepend : (n : Dim) {x y z : Obj} → Hom x y → Chain n y z → Chain (osuc n) x z
  prepend ozero f g = append ozero g f
  prepend (osuc n) f c = append (osuc n) (last-arrow n c) (prepend n f (before-last n c))

  extend-prefix : (n : Dim) {x y z : Obj} → Hom x y → Chain n y z → Chain n x z
  extend-prefix ozero f g = compose g f
  extend-prefix (osuc n) f c = append n (last-arrow n c) (extend-prefix n f (before-last n c))

  extend-prepend : (n : Dim) {w x y z : Obj} (f : Hom w x) (g : Hom x y) (c : Chain n y z)
    → outer (extend-prefix (osuc n) f (prepend n g c))
      ≡ˢ outer (prepend n (compose g f) c)
  extend-prepend ozero f g c = reflˢ
  extend-prepend (osuc n) f g c = strict-cong
    (λ z → outer (append (osuc n) (last-arrow n c) (inner z)))
    (extend-prepend n f g (before-last n c))

  face-prepend : (n : Dim) (p : Position (osuc n)) {x y z : Obj}
    (f : Hom x y) (c : Chain (osuc n) y z)
    → outer (face (osuc n) (weaken p) (prepend (osuc n) f c))
      ≡ˢ outer (prepend n f (face n p c))
  face-prepend ozero pzero f c = reflˢ
  face-prepend (osuc n) pzero f c = reflˢ
  face-prepend (osuc n) (psuc p) f c = strict-cong
    (λ z → outer (append (osuc n) (last-arrow (osuc n) c) (inner z)))
    (face-prepend n p f (before-last (osuc n) c))

  face-last-prepend : (n : Dim) {x y z : Obj} (f : Hom x y) (c : Chain n y z)
    → outer (face n (last-position n) (prepend n f c)) ≡ˢ outer (extend-prefix n f c)
  face-last-prepend ozero f c = reflˢ
  face-last-prepend (osuc n) f c = strict-cong
    (λ z → outer (append n (last-arrow n c) (inner z)))
    (face-last-prepend n f (before-last n c))

  reverse : (n : Dim) {x y : Obj} → Source.Chain n x y → Chain n y x
  reverse ozero f = f
  reverse (osuc n) c = prepend n (Source.last-arrow n c) (reverse n (Source.before-last n c))

  reverse-extend : (n : Dim) {x y z : Obj} (g : Hom z y) (c : Source.Chain n x y)
    → outer (reverse n (Source.extend-suffix n g c)) ≡ˢ outer (extend-prefix n g (reverse n c))
  reverse-extend ozero g c = reflˢ
  reverse-extend (osuc n) g c = strict-sym
    (extend-prepend n g (Source.last-arrow n c) (reverse n (Source.before-last n c)))

  reverse-face : (n : Dim) (p : Position (osuc n)) {x y : Obj} (c : Source.Chain (osuc n) x y)
    → outer (reverse n (Source.face n p c))
      ≡ˢ outer (face n (reverse-position n p) (reverse (osuc n) c))
  reverse-face n pzero c = strict-trans
    (reverse-extend n (Source.last-arrow n c) (Source.before-last n c))
    (strict-sym (face-last-prepend n (Source.last-arrow n c) (reverse n (Source.before-last n c))))
  reverse-face (osuc n) (psuc p) c = strict-trans
    (strict-cong (λ z → outer (prepend n (Source.last-arrow (osuc n) c) (inner z)))
      (reverse-face n p (Source.before-last (osuc n) c)))
    (strict-sym (face-prepend n (reverse-position n p) (Source.last-arrow (osuc n) c)
      (reverse (osuc n) (Source.before-last (osuc n) c))))

  cast-prepend : {m n : Dim} (e : m ≡ˢ n) {x y z : Obj} (f : Hom x y) (c : Chain m y z)
    → outer (Cast.cast-chain (strict-cong osuc e) (prepend m f c))
      ≡ˢ outer (prepend n f (Cast.cast-chain e c))
  cast-prepend reflˢ f c = reflˢ

  Both : Dim → Dim → Obj → Obj → Type ℓ
  Both s p x y = Σ[ z ∈ Obj ] (Chain s z y × Chain p x z)

  change-split : {s s' p p' : Dim} → s ≡ˢ s' → p ≡ˢ p'
    → {x y : Obj} → Both s p x y → Both s' p' x y
  change-split es ep z = z .fst , Cast.cast-chain es (z .snd .fst) , Cast.cast-chain ep (z .snd .snd)

  change-split-compose : {s s' s'' p p' p'' : Dim}
    (es : s ≡ˢ s') (es' : s' ≡ˢ s'') (ep : p ≡ˢ p') (ep' : p' ≡ˢ p'')
    {x y : Obj} (z : Both s p x y)
    → outer (change-split (strict-trans es es') (strict-trans ep ep') z)
      ≡ˢ outer (change-split es' ep' (change-split es ep z))
  change-split-compose reflˢ reflˢ reflˢ reflˢ z = reflˢ

  split-last-prepend : (n : Dim) {x y z : Obj} (f : Hom x y) (c : Chain n y z)
    → outer (change-split (suffix-last n) (prefix-last n)
        (split n (last-position n) (prepend n f c)))
      ≡ˢ outer (y , c , f)
  split-last-prepend ozero f c = reflˢ
  split-last-prepend (osuc n) f c = strict-trans
    (strict-cong
      (λ s → outer
        ( split-vertex n (last-position n) (prepend n f (before-last n c))
        , inner s
        , Cast.cast-chain (prefix-last n)
            (split-prefix n (last-position n) (prepend n f (before-last n c))) ))
      (Cast.cast-append (suffix-last n) (last-arrow n c)
        (split-suffix n (last-position n) (prepend n f (before-last n c)))))
    (strict-cong
      (λ z → outer (inner z .fst , append n (last-arrow n c) (inner z .snd .fst) , inner z .snd .snd))
      (split-last-prepend n f (before-last n c)))

  split-prepend-weaken : (n : Dim) (p : Position (osuc n)) {x y z : Obj}
    (f : Hom x y) (c : Chain (osuc n) y z)
    → outer (Cast.normalized n p (prepend (osuc n) f c))
      ≡ˢ outer
        ( split-vertex n p c
        , split-suffix n p c
        , prepend (prefix-degree n p) f (split-prefix n p c) )
  split-prepend-weaken n pzero f c = reflˢ
  split-prepend-weaken (osuc n) (psuc p) f c = strict-trans
    (Cast.normalized-snoc n p (prepend (osuc (osuc n)) f c))
    (strict-cong
      (λ z → outer (inner z .fst , append (suffix-degree n p) (last-arrow (osuc n) c)
        (inner z .snd .fst) , inner z .snd .snd))
      (split-prepend-weaken n p f (before-last (osuc n) c)))

  reversed-split : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    → Source.Chain (osuc n) x y → Both (prefix-degree n p) (suffix-degree n p) y x
  reversed-split n p c = change-split (reverse-suffix-degree n p) (reverse-prefix-degree n p)
    (split n (reverse-position n p) (reverse (osuc n) c))

  reverse-split : (n : Dim) (p : Position (osuc n)) {x y : Obj}
    (c : Source.Chain (osuc n) x y)
    → outer (reversed-split n p c)
      ≡ˢ outer
        ( Source.split-vertex n p c
        , reverse (prefix-degree n p) (Source.split-prefix n p c)
        , reverse (suffix-degree n p) (Source.split-suffix n p c) )
  reverse-split n pzero c = split-last-prepend n (Source.last-arrow n c)
    (reverse n (Source.before-last n c))
  reverse-split (osuc n) (psuc p) c = strict-trans
    (change-split-compose
      (suffix-weaken n (reverse-position n p)) (reverse-suffix-degree n p)
      (prefix-weaken n (reverse-position n p)) (strict-cong osuc (reverse-prefix-degree n p))
      (split (osuc n) (weaken (reverse-position n p)) (reverse (osuc (osuc n)) c)))
    (strict-trans
      (strict-cong
        (λ z → outer (change-split (reverse-suffix-degree n p)
          (strict-cong osuc (reverse-prefix-degree n p)) (inner z)))
        (split-prepend-weaken n (reverse-position n p) (Source.last-arrow (osuc n) c)
          (reverse (osuc n) (Source.before-last (osuc n) c))))
      (strict-trans
        (strict-cong
          (λ z → outer
            ( split-vertex n (reverse-position n p) (reverse (osuc n) (Source.before-last (osuc n) c))
            , Cast.cast-chain (reverse-suffix-degree n p)
                (split-suffix n (reverse-position n p) (reverse (osuc n) (Source.before-last (osuc n) c)))
            , inner z ))
          (cast-prepend (reverse-prefix-degree n p) (Source.last-arrow (osuc n) c)
            (split-prefix n (reverse-position n p) (reverse (osuc n) (Source.before-last (osuc n) c)))))
        (strict-cong
          (λ z → outer (inner z .fst , inner z .snd .fst ,
            prepend (suffix-degree n p) (Source.last-arrow (osuc n) c) (inner z .snd .snd)))
          (reverse-split n p (Source.before-last (osuc n) c)))))
