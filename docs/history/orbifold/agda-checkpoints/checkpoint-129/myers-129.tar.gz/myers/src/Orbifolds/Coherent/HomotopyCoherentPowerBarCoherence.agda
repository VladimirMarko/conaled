{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentPowerBarCoherence where

-- The power successor retains its original evaluation and canonical triangle.
-- Proved first/lower normalization supplies the finite projection law, and the
-- generic finisher constructs the original transition coherence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Data.Sigma
import Agda.Builtin.Reflection as Reflection
open import Agda.Builtin.List using (List; _∷_; [])
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using
  (assign-frozen; hidden-argument; visible-argument; composition-term)
open import Orbifolds.Coherent.InferredGoalPathInference using (assign-frozen-inferred)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.StrictPathCoherence
open import Orbifolds.Coherent.StrictConstantPathCoherence
open import Orbifolds.Coherent.OuterBarChains using (Dim; osuc)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (strict-end-path)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentCoconeFunctoriality as Cocones
import Orbifolds.Coherent.HomotopyCoherentFiniteCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCellStageComparison as Comparison
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
import Orbifolds.Coherent.HomotopyCoherentPowerBarInterface as PowerStages
import Orbifolds.Coherent.HomotopyCoherentPowerBarStages as ActualStages
import Orbifolds.Coherent.HomotopyCoherentFiniteCellCoherence as FiniteCoherence

import Orbifolds.Coherent.ProjectedCompositeFinisher as Neutral
import Orbifolds.Coherent.HomotopyCoherentFiniteCellCompositeNormalization as Normalized
import Orbifolds.Coherent.HomotopyCoherentFiniteCellMaps as Core
import Orbifolds.Coherent.HomotopyCoherentColimitStepData as StepData

private
  h : Reflection.Arg Reflection.Term
  h = hidden-argument Reflection.unknown

  names : List Reflection.Name
  names = (quote Literal.Map.induced) ∷
    (quote Cocones.Functoriality.postcompose) ∷
    (quote Core.Construction.At.lower-path) ∷
    (quote strict-to-path) ∷ (quote _∙_) ∷ []

  macro
    neutral-composite-frozen : Reflection.Term → Reflection.Term → Reflection.Term
      → Reflection.Term → Reflection.Term → Reflection.Term → Reflection.Term
      → Reflection.Term → Reflection.Term → Reflection.Term → Reflection.Term
      → Reflection.Term → Reflection.TC ⊤
    neutral-composite-frozen A B project p q eval-law eval-eq lower last-eq source-eq finite-law hole =
      assign-frozen names
        (Reflection.def (quote Neutral.Finisher.finish)
          (h ∷ visible-argument A ∷ visible-argument B ∷ visible-argument project ∷
           h ∷ h ∷ h ∷ visible-argument p ∷ visible-argument q ∷
           visible-argument Reflection.unknown ∷ visible-argument Reflection.unknown ∷
           visible-argument lower ∷ visible-argument eval-eq ∷
           visible-argument Reflection.unknown ∷
           visible-argument last-eq ∷ visible-argument source-eq ∷
           visible-argument eval-law ∷ visible-argument finite-law ∷ [])) hole

    known-frozen : Reflection.Term → Reflection.Term → Reflection.TC ⊤
    known-frozen value hole = assign-frozen-inferred
      ((quote ActualStages.Construction.Step.q) ∷ names) value hole

    compose-frozen : Reflection.Term → Reflection.Term → Reflection.Term → Reflection.TC ⊤
    compose-frozen first second hole = assign-frozen-inferred
      ((quote Literal.Map.induced) ∷
       (quote Cocones.Functoriality.postcompose) ∷
       (quote strict-to-path) ∷ (quote _∙_) ∷ [])
      (composition-term first second) hole

  module ReflectedConstruction {ℓ : Level} (A B : Type ℓ) (project : A → B)
      {x y z : A} (p : x ≡ y) (q : y ≡ z) (w v : B)
      (a : outer (project x) ≡ˢ outer (project y))
      (b : outer (project y) ≡ˢ outer w) (lower : w ≡ v)
      (d : outer v ≡ˢ outer (project z))
      (e : outer (project x) ≡ˢ outer w)
      (eval-law : cong project p ≡ strict-to-path a)
      (finite-law : cong project q ≡ strict-to-path b ∙ lower ∙ strict-to-path d) where
    result : _
    result = neutral-composite-frozen A B project p q eval-law a lower d e finite-law

    exact : outer result ≡ˢ outer
      (Neutral.Finisher.finish A B project p q w v lower a b d e eval-law finite-law)
    exact = reflˢ

    construction : outer result ≡ˢ outer
      (Neutral.Finisher.implementation A B project p q w v lower a b d e eval-law finite-law)
    construction = strict-cong (λ k → outer (inner k eval-law finite-law))
      (Neutral.Finisher.finish-construction A B project p q w v lower a b d e)

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) (T : Type ℓ) where
  module B = PowerStages.Construction C D E F T
    using (State; module State; module RD; module RP; module CPow; module Power; module Step; module R)
  module Constant = Extensional E using (constant-path)

  module Step (n : Dim) (original : B.RD.Represented n) (powered : B.RP.Represented n)
      (previous : B.State n original powered) where
    module S = B.Step n original powered previous
    module Point (t : T) = FiniteCoherence.Construction C (B.Power.Power D) D
      (B.Power.evaluation D t) E F n powered original
      (λ x → B.State.q previous x t) (B.State.triangle previous t)
      using (last-equality; composite-prefix; module At; module M)

    PoweredBase OriginalBase : Type ℓ
    PoweredBase = B.RP.Represented.Space powered
    OriginalBase = B.RD.Represented.Space original

    prefix : B.CPow.Cocone S.OD.Realize (osuc n) → B.CPow.Cocone S.OD.Realize n
    prefix = fst

    uP : B.CPow.Cocone PoweredBase n
    uP = B.RP.Represented.universal-cocone powered

    evaluation-path : (t : T) → _
    evaluation-path t = cong {A = S.PP.Realize → S.OD.Realize}
      {B = λ _ → B.CPow.Cocone S.OD.Realize (osuc n)}
      (λ h → B.CPow.postcompose (osuc n) {Y = S.PP.Realize} {Z = S.OD.Realize}
        h S.PP.canonical-cocone)
      (funExt (S.evaluation-computation t))

    evaluation-prefix-constant : (t : T) (i : I)
      → outer {A = B.CPow.Cocone S.OD.Realize n} (evaluation-path t i .fst)
        ≡ˢ outer {A = B.CPow.Cocone S.OD.Realize n}
          (B.CPow.postcompose n {Y = PoweredBase} {Z = S.OD.Realize}
          (λ x → S.OD.Cell.include (B.State.q previous x t)) uP)
    evaluation-prefix-constant t i = strict-trans {A = Outer (B.CPow.Cocone S.OD.Realize n)}
      (B.CPow.postcompose-compose n {Y = PoweredBase} {Z = S.PP.Realize} {W = S.OD.Realize}
        (S.PP.cell-cocone .fst)
        (λ z → S.evaluation-computation t z i) uP)
      (strict-cong
        {A = Outer (PoweredBase → S.PP.Realize)} {B = Outer (B.CPow.Cocone S.OD.Realize n)}
        (λ k → outer (B.CPow.postcompose n {Y = PoweredBase} {Z = S.OD.Realize}
          (λ x → S.evaluation-computation t (inner k x) i) uP))
        S.PP.cell-original-computation)

    evaluation-prefix-equality : (t : T)
      → outer (evaluation-path t i0 .fst) ≡ˢ outer (evaluation-path t i1 .fst)
    evaluation-prefix-equality t = strict-trans (evaluation-prefix-constant t i0)
      (strict-sym (evaluation-prefix-constant t i1))

    evaluation-prefix : (t : T)
      → cong prefix (evaluation-path t) ≡ strict-to-path (evaluation-prefix-equality t)
    evaluation-prefix t = strict-to-path (Constant.constant-path
      {A = B.CPow.Cocone S.OD.Realize n}
      (cong prefix (evaluation-path t))
      (B.CPow.postcompose n {Y = PoweredBase} {Z = S.OD.Realize}
        (λ x → S.OD.Cell.include (B.State.q previous x t)) uP)
      (evaluation-prefix-constant t))

    source-transition : (t : T)
      → outer {A = B.CPow.Cocone S.OD.Realize n}
          (B.CPow.postcompose (osuc n) {Y = S.PP.Realize} {Z = S.OD.Realize}
            (λ z → S.q z t) S.PP.canonical-cocone .fst)
        ≡ˢ outer {A = B.CPow.Cocone S.OD.Realize n}
          (B.CPow.postcompose n {Y = PoweredBase} {Z = S.OD.Realize}
          (λ x → S.OD.Cell.include (B.State.q previous x t)) uP)
    source-transition t = S.PP.transition-computation S.OD.Realize (λ z → S.q z t)

    direct-include-agrees :
      outer {A = OriginalBase → S.OD.Realize} (StepData.Step.include C D E F n original)
        ≡ˢ outer {A = OriginalBase → S.OD.Realize} S.OD.Cell.include
    direct-include-agrees = reflˢ

    composite-implementation : (t : T) → _
    composite-implementation t = neutral-composite-frozen
      (B.CPow.Cocone S.OD.Realize (osuc n)) (B.CPow.Cocone S.OD.Realize n)
      prefix (evaluation-path t) (S.Point.canonical-triangle t)
      (evaluation-prefix t) (evaluation-prefix-equality t)
      (Point.At.lower-path t (StepData.Step.include C D E F n original))
      (Point.last-equality t) (source-transition t)
      (Normalized.Construction.normalized-composite
        C (B.Power.Power D) D (B.Power.evaluation D t) E F n powered original
        (λ (x : PoweredBase) → B.State.q previous x t) (B.State.triangle previous t))

    composite-prefix : (t : T) → cong prefix (S.triangle t)
      ≡ strict-to-path (source-transition t)
        ∙ Point.At.lower-path t S.OD.Cell.include ∙ strict-to-path (Point.last-equality t)
    composite-prefix t = known-frozen (composite-implementation t)

    transported-previous : (t : T)
      → B.CPow.postcompose (osuc n) {Y = S.PP.Realize} {Z = S.OD.Realize}
          (λ z → S.q z t) S.PP.canonical-cocone .fst
        ≡ B.R.finite-restriction t S.OD.Realize (osuc n) S.OD.canonical-cocone .fst
    transported-previous t = strict-end-path {A = B.CPow.Cocone S.OD.Realize n}
      (λ i → B.CPow.postcompose n {Y = OriginalBase} {Z = S.OD.Realize}
        S.OD.Cell.include (B.State.triangle previous t i))
      (strict-trans
        (B.CPow.postcompose-compose n {Y = PoweredBase} {Z = OriginalBase} {W = S.OD.Realize}
          (λ x → B.State.q previous x t) S.OD.Cell.include uP)
        (strict-sym (source-transition t)))
      (strict-trans
        (Point.M.N.square t n {Y = OriginalBase} {Z = S.OD.Realize} S.OD.Cell.include (Point.M.uG t))
        (Point.last-equality t))

    paste-component : (t : T) → _
    paste-component t =
      strict-path-paste
        (λ i → B.CPow.postcompose n {Y = OriginalBase} {Z = S.OD.Realize}
          S.OD.Cell.include (B.State.triangle previous t i))
        (B.CPow.postcompose-compose n {Y = PoweredBase} {Z = OriginalBase} {W = S.OD.Realize}
          (λ x → B.State.q previous x t) S.OD.Cell.include uP)
        (Point.M.N.square t n {Y = OriginalBase} {Z = S.OD.Realize} S.OD.Cell.include (Point.M.uG t))
        (source-transition t) (Point.last-equality t)

    canonical-prefix-coherence : (t : T) → cong prefix (S.triangle t) ≡ transported-previous t
    canonical-prefix-coherence t = compose-frozen (composite-prefix t) (paste-component t)
