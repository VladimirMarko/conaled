{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMapLaws where

-- Identity and composition for the specified canonical bar maps.
-- Equality is reflected through the actual full mapping equivalence.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function using (_∘_; idfun)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties using (congEquiv)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitMaps as Canonical
import Orbifolds.Coherent.HomotopyCoherentColimitMappingInterface as Bar
import Orbifolds.Coherent.HomotopyCoherentCanonicalColimitNaturality as Naturality
import Orbifolds.Coherent.HomotopyCoherentCoconeRestriction as Restriction
import Orbifolds.Coherent.HomotopyCoherentCoconeRestrictionLaws as RestrictionLaws

module Identity {ℓ : Level} (C : Category ℓ ℓ) (D : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D D)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component α x) ≡ˢ outer (idfun _)) where
  module Map = Canonical.Map C D D α E F using (induced; canonical-triangle; module Source)

  map-identity : Map.induced ≡ idfun Map.Source.Colimit
  map-identity = invEq (congEquiv (Map.Source.MappingOut.universal Map.Source.Colimit))
    (Map.canonical-triangle ∙ RestrictionLaws.Identity.restriction-identity
      C D α E F components Map.Source.Colimit Map.Source.canonical-cocone)

module Composition {ℓ : Level} (C : Category ℓ ℓ)
    (D G H : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (β : Transformations.ForCategory.Transformation C G H)
    (γ : Transformations.ForCategory.Transformation C D H)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (components : (x : Category.Obj C)
      → outer (Transformations.ForCategory.Transformation.component β x
          ∘ Transformations.ForCategory.Transformation.component α x)
        ≡ˢ outer (Transformations.ForCategory.Transformation.component γ x)) where
  module A = Canonical.Map C D G α E F using (induced)
  module B = Canonical.Map C G H β E F using (induced; canonical-triangle; module Source)
  module K = Canonical.Map C D H γ E F using (induced; canonical-triangle; module Source; module Target)

  restriction : B.Source.MappingOut.Cocone K.Target.Colimit
    → K.Source.MappingOut.Cocone K.Target.Colimit
  restriction = Restriction.Restriction.restrict C D G α E F K.Target.Colimit

  map-composition : B.induced ∘ A.induced ≡ K.induced
  map-composition = invEq (congEquiv (K.Source.MappingOut.universal K.Target.Colimit))
    (Naturality.Naturality.precomposition-square C D G α E F K.Target.Colimit B.induced
      ∙ cong restriction B.canonical-triangle
      ∙ RestrictionLaws.Composition.restriction-composition
          C D G H α β γ E F components K.Target.Colimit K.Target.canonical-cocone
      ∙ sym K.canonical-triangle)

module Functoriality {ℓ : Level} (C : Category ℓ ℓ)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ) where
  module Algebra = Transformations.ForCategory.Algebra C E using (identity; compose-map)

  identity-law : (D : HC.ForCategory.Diagram C)
    → Canonical.Map.induced C D D (Algebra.identity D) E F
      ≡ idfun (Bar.Construction.Colimit C D E F)
  identity-law D = Identity.map-identity C D (Algebra.identity D) E F (λ x → reflˢ)

  composition-law : (D G H : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (β : Transformations.ForCategory.Transformation C G H)
    → Canonical.Map.induced C G H β E F ∘ Canonical.Map.induced C D G α E F
      ≡ Canonical.Map.induced C D H (Algebra.compose-map β α) E F
  composition-law D G H α β = Composition.map-composition C D G H
    α β (Algebra.compose-map β α) E F (λ x → reflˢ)
