{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineTransporters where

-- Once the source and target points and the linear part are fixed, an
-- integral translation is unique. Thus transporters embed in the
-- finite linear group. Constructively the conclusion is proper
-- finiteness; no locally constant stabilizer cardinality is asserted.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
open import Cubical.Data.FinSet using (isFinSet)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Functions.Embedding using (isEmbedding; injEmbedding; _↪_)
open import Orbifolds.ProperFiniteness using
  (ProperlyFinite; finiteProperlyFinite; embeddingProperlyFinite)
import Orbifolds.SyntheticField as SF
import Orbifolds.IntegerEmbedding as IE
import Orbifolds.IntegralAffineActions as IA

module Coordinates {ℓ : Level} (R : CommRing ℓ)
  (order : SF.RingContext.StrictOrder R) (n : ℕ) where
  open CommRingStr (R .snd)
  module Affine = IA.Coordinates R n
  module Integer = IE.Ordered.Coordinates R order (FD.Fin n)

  module Representation (H : Group ℓ) (ρ : GroupHom H Affine.Z.GeneralLinear) where
    module Linear = Affine.Representation H ρ
    module HS = GroupStr (H .snd)
    open Affine using (Vector)

    Transporter : Vector → Vector → Type ℓ
    Transporter x y = Σ[ g ∈ Linear.AffineGroup .fst ] Linear.affine g x ≡ y

    linear-part : {x y : Vector} → Transporter x y → H .fst
    linear-part u = u .fst .snd

    transporter-determined-by-linear-part : {x y : Vector} {u v : Transporter x y}
      → linear-part u ≡ linear-part v → u ≡ v
    transporter-determined-by-linear-part {x} {y} {u} {v} same-linear =
      Σ≡Prop (λ g → (isSetΠ λ _ → is-set) (Linear.affine g x) y)
        (ΣPathP (same-translation , same-linear))
      where
      same-translation : u .fst .fst ≡ v .fst .fst
      same-translation = cong lift
        (Integer.translation-injective (Linear.linear (u .fst .snd) x)
          (u .snd ∙ sym (v .snd)
            ∙ cong (λ h → Linear.affine (v .fst .fst , h) x) (sym same-linear)))

    transporter-linear-embedding : (x y : Vector)
      → isEmbedding (linear-part {x} {y})
    transporter-linear-embedding x y = injEmbedding HS.is-set
      transporter-determined-by-linear-part

    transporter↪linear-group : (x y : Vector) → Transporter x y ↪ H .fst
    transporter↪linear-group x y = linear-part , transporter-linear-embedding x y

    transporters-properly-finite : isFinSet (H .fst) → (x y : Vector)
      → ProperlyFinite (Transporter x y)
    transporters-properly-finite finite x y = embeddingProperlyFinite
      (transporter↪linear-group x y) (finiteProperlyFinite finite)

    Stabilizer : Vector → Type ℓ
    Stabilizer x = Transporter x x

    stabilizers-properly-finite : isFinSet (H .fst) → (x : Vector)
      → ProperlyFinite (Stabilizer x)
    stabilizers-properly-finite finite x = transporters-properly-finite finite x x
