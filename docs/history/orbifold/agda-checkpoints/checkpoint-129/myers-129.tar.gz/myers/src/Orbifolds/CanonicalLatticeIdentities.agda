{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CanonicalLatticeIdentities where

-- Scalar coordinates for actual canonical-line lattice identities,
-- and explicit small models of the actual fibers of canonical charts.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Powerset
open import Cubical.Foundations.Transport
open import Cubical.Foundations.Univalence
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Module.Base
import Cubical.Algebra.Group.Subgroup as SG
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.ComplexLatticeStructures as LM
import Orbifolds.PredicateIdentities as PI
import Orbifolds.StructuredPredicateIdentities as SPI

import Orbifolds.LatticeModuliIdentities as Base

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  open Base.Geometry R kock order compatibility public
  open Moduli using (FiniteFreeLattice; FiniteFreeModuli)

  module Canonical (Λ Γ : FiniteFreeLattice Lines.canonical-line) where
    ScalarPreserves : Lines.Unit → Type ℓ
    ScalarPreserves u = (z : C.Complex)
      → Member {Lines.canonical-line} Λ z
        ≃ Member {Lines.canonical-line} Γ (u .fst C.*c z)

    scalar-preserves-isProp : (u : Lines.Unit) → isProp (ScalarPreserves u)
    scalar-preserves-isProp u = isPropΠ λ z → isOfHLevel≃ 1
      (predicate Lines.canonical-line Λ z .snd)
      (predicate Lines.canonical-line Γ (u .fst C.*c z) .snd)

    coordinate-preservation : (e : LeftModuleEquiv Lines.standard Lines.standard)
      → Preserves {Lines.canonical-line} {Lines.canonical-line} e Λ Γ
        ≃ ScalarPreserves (Lines.equivalence-unit e)
    coordinate-preservation e = propBiimpl→Equiv
      (preserves-isProp {Lines.canonical-line} {Lines.canonical-line} e Λ Γ)
      (scalar-preserves-isProp (Lines.equivalence-unit e))
      (λ p z → compEquiv (p z) (pathToEquiv (cong (Member {Lines.canonical-line} Γ)
        (Lines.hom-is-scaling (e .fst .fst , e .snd) z))))
      (λ p z → compEquiv (p z) (pathToEquiv (cong (Member {Lines.canonical-line} Γ)
        (sym (Lines.hom-is-scaling (e .fst .fst , e .snd) z)))))

    morphisms≃scalars : Morphism Lines.canonical-line Lines.canonical-line Λ Γ
      ≃ (Σ[ u ∈ Lines.Unit ] ScalarPreserves u)
    morphisms≃scalars = Σ-cong-equiv Lines.automorphisms≃units coordinate-preservation

    scalar-identities :
      Path FiniteFreeModuli (Lines.canonical-line , Λ) (Lines.canonical-line , Γ)
        ≃ (Σ[ u ∈ Lines.Unit ] ScalarPreserves u)
    scalar-identities = compEquiv (identities {Lines.canonical-line} {Lines.canonical-line} Λ Γ)
      morphisms≃scalars

  -- A small coordinate model for the literal fiber of any canonical-
  -- line parameterization. This is an explicit equivalence across
  -- universes, not an implicit resizing of structural identity types.
  module Chart (S : Type ℓ) (chart : S → FiniteFreeLattice Lines.canonical-line) where
    parameterization : S → FiniteFreeModuli
    parameterization s = Lines.canonical-line , chart s

    SmallFiber : FiniteFreeModuli → Type ℓ
    SmallFiber Y = Σ[ s ∈ S ] Morphism Lines.canonical-line (Y .fst) (chart s) (Y .snd)

    fiber-equivalence : (Y : FiniteFreeModuli) → fiber parameterization Y ≃ SmallFiber Y
    fiber-equivalence Y = Σ-cong-equiv-snd λ s →
      identities {Lines.canonical-line} {Y .fst} (chart s) (Y .snd)

    fiber-coordinate : (Y : FiniteFreeModuli) (z : fiber parameterization Y)
      → fiber-equivalence Y .fst z .fst ≡ z .fst
    fiber-coordinate Y z = refl

    small-fiber-isSet : isSet S → (Y : FiniteFreeModuli) → isSet (SmallFiber Y)
    small-fiber-isSet setS Y = isSetΣ setS λ s →
      morphism-isSet Lines.canonical-line (Y .fst) (chart s) (Y .snd)

    fiber-isSet : isSet S → (Y : FiniteFreeModuli) → isSet (fiber parameterization Y)
    fiber-isSet setS Y = isOfHLevelRespectEquiv 2 (invEquiv (fiber-equivalence Y))
      (small-fiber-isSet setS Y)
