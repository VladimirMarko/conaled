{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegralAffineFaithfulness where

-- An actual subgroup embedding into GL_n(Z) gives a faithful action of
-- the actual affine semidirect product on R^n. Evaluation at zero
-- recovers translation, and the checked matrix action recovers H.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ)
import Cubical.Data.FinData as FD
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Functions.Embedding using
  (isEmbedding; isEmbedding→Inj; injEmbedding)
import Orbifolds.SyntheticField as SF
import Orbifolds.IntegerEmbedding as IE
import Orbifolds.IntegralAffineActions as IA

module Coordinates {ℓ : Level} (R : CommRing ℓ)
    (order : SF.RingContext.StrictOrder R) (n : ℕ) where
  open CommRingStr (R .snd)
  module Affine = IA.Coordinates R n
  module Integer = IE.Ordered R order
  module Vectors = Integer.Coordinates (FD.Fin n)
  module Coefficient = Affine.Change.Injective Integer.integer-injective

  module Subgroup (H : Group ℓ) (ρ : GroupHom H Affine.Z.GeneralLinear)
      (embedding : isEmbedding (ρ .fst)) where
    module Linear = Affine.Representation H ρ
    open Affine using (Vector; translate; integer-vector)

    linear-faithful : {h k : H .fst} → Linear.linear h ≡ Linear.linear k → h ≡ k
    linear-faithful {h} {k} p = isEmbedding→Inj embedding h k
      (isEmbedding→Inj (Coefficient.general-linear-embedding n) (ρ .fst h) (ρ .fst k)
        (Affine.Real.faithful p))

    zero-vector : Vector
    zero-vector = const 0r

    affine-zero : (g : Linear.AffineGroup .fst)
      → Linear.affine g zero-vector ≡ integer-vector (lower (g .fst))
    affine-zero (z , h) = cong (translate z)
      (Affine.Real.action-zero (Linear.real-representation .fst h))
      ∙ funExt (λ i → +IdR (Integer.integer (lower z i)))

    translation-component : {g h : Linear.AffineGroup .fst}
      → Linear.affine g ≡ Linear.affine h → g .fst ≡ h .fst
    translation-component {g} {h} p = cong lift
      (Vectors.integer-vector-injective
        (sym (affine-zero g) ∙ funExt⁻ p zero-vector ∙ affine-zero h))

    linear-component : {g h : Linear.AffineGroup .fst}
      → Linear.affine g ≡ Linear.affine h
      → Linear.linear (g .snd) ≡ Linear.linear (h .snd)
    linear-component {g} {h} p = funExt λ x → funExt λ i →
      Integer.Additive.·CancelL (Integer.integer (lower (g .fst) i))
        (funExt⁻ (funExt⁻ p x
          ∙ sym (cong (λ z → translate z (Linear.linear (h .snd) x))
            (translation-component {g = g} {h = h} p))) i)

    affine-faithful : {g h : Linear.AffineGroup .fst}
      → Linear.affine g ≡ Linear.affine h → g ≡ h
    affine-faithful {g} {h} p = ΣPathP
      (translation-component {g = g} {h = h} p ,
        linear-faithful (linear-component {g = g} {h = h} p))

    affine-action-embedding : isEmbedding Linear.affine
    affine-action-embedding = injEmbedding
      (isSetΠ λ _ → isSetΠ λ _ → is-set) affine-faithful
