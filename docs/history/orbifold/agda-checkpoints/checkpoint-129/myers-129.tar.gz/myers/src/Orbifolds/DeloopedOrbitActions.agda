{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.DeloopedOrbitActions where

-- Action computations on a surjective set of representatives determine
-- the transport formula for every point and every loop. The proof is
-- generic in the actual delooping and family, keeping large torsor
-- equivalence certificates opaque at later applications.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Transport
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
open import Cubical.Functions.Surjection using (isSurjection)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Quotients as Q

module Computation {ℓd ℓf ℓh ℓc ℓx : Level}
    (D : Q.Delooping ℓd) (F : Q.BG D → Type ℓf)
    (H : Group ℓh) (loop-coordinates : Q.Loop D ≃ H .fst)
    (choose : H .fst → Q.Loop D)
    (loop-computation : (h : H .fst)
      → loop-coordinates .fst (choose h) ≡ GroupStr.inv (H .snd) h)
    (C : Type ℓc) (setC : isSet C)
    (coordinates : F (Q.point D) → C) (action : H .fst → C → C)
    (X : Type ℓx) (orbit : X → F (Q.point D)) (surjective : isSurjection orbit)
    (representative-action : H .fst → X → X)
    (chosen-transport : (h : H .fst) (x : X)
      → subst F (choose h) (orbit x) ≡ orbit (representative-action h x))
    (orbit-equivariant : (h : H .fst) (x : X)
      → coordinates (orbit (representative-action h x)) ≡ action h (coordinates (orbit x))) where
  open GroupStr (H .snd)
  open GroupTheory H using (invInv)

  abstract
    recover-loop : (p : Q.Loop D) → choose (inv (loop-coordinates .fst p)) ≡ p
    recover-loop p = invEq (congEquiv loop-coordinates)
      (loop-computation (inv (loop-coordinates .fst p)) ∙ invInv (loop-coordinates .fst p))

    transport-on-orbit : (p : Q.Loop D) (x : X)
      → coordinates (subst F p (orbit x))
        ≡ action (inv (loop-coordinates .fst p)) (coordinates (orbit x))
    transport-on-orbit p x = cong coordinates
      (cong (λ q → subst F q (orbit x)) (sym (recover-loop p))
        ∙ chosen-transport (inv (loop-coordinates .fst p)) x)
      ∙ orbit-equivariant (inv (loop-coordinates .fst p)) x

    all-loop-transport : (p : Q.Loop D) (z : F (Q.point D))
      → coordinates (subst F p z)
        ≡ action (inv (loop-coordinates .fst p)) (coordinates z)
    all-loop-transport p z = PT.rec (setC _ _)
      (λ (x , e) → subst
        (λ z → coordinates (subst F p z)
          ≡ action (inv (loop-coordinates .fst p)) (coordinates z)) e
        (transport-on-orbit p x)) (surjective z)
