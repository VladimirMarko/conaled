{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.FreeActionQuotients where

-- A free algebraic set action has a set-valued homotopy quotient.
-- Its comparison with the literal orbit set is constructed from actual
-- equivariant functions on torsors, with no choice of torsor points.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Transport
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms using (IsGroupHom)
open import Cubical.Algebra.Group.Properties using (module GroupTheory)
import Cubical.HITs.PropositionalTruncation as PT
import Cubical.HITs.SetQuotients as SQ
import Orbifolds.Torsors as Torsors
import Orbifolds.EquivariantBundles as EB

module Action {ℓ : Level} (G : Group ℓ)
    (A : Torsors.Theory.Action G) where
  module T = Torsors.Theory G
  module F = EB.Theory.Action G A
  open GroupStr (G .snd)
  open GroupTheory G using (invInv; inv1g)

  X = T.Carrier A
  HomotopyQuotient = F.Family.Quotient

  orbit : X → HomotopyQuotient
  orbit x = F.Family.quotient (F.orbit x)

  Relation : X → X → Type ℓ
  Relation x y = Σ[ g ∈ G .fst ] T.act A g x ≡ y

  OrbitSet : Type ℓ
  OrbitSet = X SQ./ Relation

  abstract
    loop-transport : (p : T.regular-torsor ≡ T.regular-torsor) (x : X)
      → F.evaluate (F.Family.act p (F.orbit x))
        ≡ T.act A (inv (T.transport-point T.regular-torsor p)) x
    loop-transport p x = F.transport-bundle p (F.orbit x) 1g
      ∙ cong (λ g → T.act A g x)
        (IsGroupHom.presinv (T.torsor-loop-group-equivalence .snd) p)

    action-path : (g : G .fst) (x : X)
      → orbit x ≡ orbit (T.act A g x)
    action-path g x = F.Family.action-path (F.group-loop g) (F.orbit x)
      ∙ cong F.Family.quotient
        (sym (F.orbit-evaluate (F.Family.act (F.group-loop g) (F.orbit x)))
          ∙ cong F.orbit (F.action-transport g x))

  relation-path : (x y : X) → Relation x y → orbit x ≡ orbit y
  relation-path x y (g , p) = action-path g x ∙ cong orbit p

  -- Every value of an equivariant function on a torsor determines the
  -- same ordinary orbit. Weak constancy permits elimination to this set.
  values-related : (t : T.Torsor) (f : F.Bundle t)
    (u v : T.TorsorCarrier t) → Relation (f .fst u) (f .fst v)
  values-related t f u v = g , sym (f .snd g u)
    ∙ cong (f .fst) (secEq orbit-equivalence v)
    where
    orbit-equivalence : G .fst ≃ T.TorsorCarrier t
    orbit-equivalence = (λ h → T.act (t .fst) h u) , t .snd .snd u
    g = invEq orbit-equivalence v

  to-orbit-set : HomotopyQuotient → OrbitSet
  to-orbit-set (t , f) = PT.rec→Set SQ.squash/
    (λ u → SQ.[ f .fst u ])
    (λ u v → SQ.eq/ (f .fst u) (f .fst v) (values-related t f u v))
    (t .snd .fst)

  orbit-computation : (x : X) → to-orbit-set (orbit x) ≡ SQ.[ x ]
  orbit-computation x = cong SQ.[_] (T.act-unit A x)

  module Free (free : (g : G .fst) (x : X)
      → T.act A g x ≡ x → g ≡ 1g) where

    abstract
      stabilizer-loop-trivial : (x : X)
        (p : T.regular-torsor ≡ T.regular-torsor)
        → F.Family.act p (F.orbit x) ≡ F.orbit x → p ≡ refl
      stabilizer-loop-trivial x p e =
        invEq (congEquiv (T.transport-identifications T.regular-torsor))
          (coordinate-trivial
            ∙ sym (IsGroupHom.pres1 (T.torsor-loop-group-equivalence .snd)))
        where
        c : G .fst
        c = T.transport-point T.regular-torsor p
        action-trivial : T.act A (inv c) x ≡ x
        action-trivial = sym (loop-transport p x)
          ∙ cong F.evaluate e ∙ F.evaluate-orbit x
        coordinate-trivial : c ≡ 1g
        coordinate-trivial = sym (invInv c)
          ∙ cong inv (free (inv c) x action-trivial) ∙ inv1g

      stabilizer-contractible : (x : X)
        → isContr (F.Family.Stabilizer (F.orbit x))
      stabilizer-contractible x =
        (refl , F.Family.action-unit (F.orbit x)) , λ (p , e) →
          Σ≡Prop (λ q → F.bundle-set T.regular-torsor _ _)
            (sym (stabilizer-loop-trivial x p e))

      orbit-loops-prop : (x : X) → isProp (orbit x ≡ orbit x)
      orbit-loops-prop x = isOfHLevelRespectEquiv 1
        (invEquiv (F.Family.isotropy≃stabilizer (F.orbit x)))
        (isContr→isProp (stabilizer-contractible x))

      quotient-loops-prop : (z : HomotopyQuotient) → isProp (z ≡ z)
      quotient-loops-prop = F.Family.quotient-proposition-induction
        (λ z → isProp (z ≡ z)) (λ z → isPropIsProp)
        (λ f → subst (λ z → isProp (z ≡ z))
          (cong F.Family.quotient (F.orbit-evaluate f))
          (orbit-loops-prop (F.evaluate f)))

      quotient-set : isSet HomotopyQuotient
      quotient-set x y p = J (λ y p → (q : x ≡ y) → p ≡ q)
        (quotient-loops-prop x refl) p

    from-orbit-set : OrbitSet → HomotopyQuotient
    from-orbit-set = SQ.rec quotient-set orbit relation-path

    abstract
      to-from : (q : OrbitSet) → to-orbit-set (from-orbit-set q) ≡ q
      to-from = SQ.elimProp (λ q → SQ.squash/ _ _) orbit-computation

      from-to : (z : HomotopyQuotient)
        → from-orbit-set (to-orbit-set z) ≡ z
      from-to = F.Family.quotient-proposition-induction
        (λ z → from-orbit-set (to-orbit-set z) ≡ z)
        (λ z → quotient-set _ _)
        (λ f → subst (λ z → from-orbit-set (to-orbit-set z) ≡ z)
          (cong F.Family.quotient (F.orbit-evaluate f))
          (cong from-orbit-set (orbit-computation (F.evaluate f))))

    homotopy-quotient≃orbit-set : HomotopyQuotient ≃ OrbitSet
    homotopy-quotient≃orbit-set = isoToEquiv
      (iso to-orbit-set from-orbit-set to-from from-to)

    quotient-triangle : (x : X)
      → homotopy-quotient≃orbit-set .fst (orbit x) ≡ SQ.[ x ]
    quotient-triangle = orbit-computation
