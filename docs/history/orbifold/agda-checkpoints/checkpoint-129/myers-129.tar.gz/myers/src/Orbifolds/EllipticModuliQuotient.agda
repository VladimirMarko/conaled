{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.EllipticModuliQuotient where

-- Literal finite-free complex lattice moduli is the actual Mobius
-- action quotient. All chart, metric, integral-basis, coverage, coherent
-- action and torsor inputs are instantiated by their checked constructions.
-- This file assumes no desired quotient equivalence or surjectivity.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.UpperHalfPlane as UH
import Orbifolds.ComplexLatticeStructures as LS
import Orbifolds.LatticeModuli as LM
import Orbifolds.LatticeModuliCoverage as Coverage
import Orbifolds.StandardLatticeIdentityCharts as Charts
import Orbifolds.EquivariantBundles as EB

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  UpperHalfPlane : Type ℓ
  UpperHalfPlane = UH.Geometry.UpperHalfPlane R kock order compatibility

  Moduli : Type (ℓ-suc ℓ)
  Moduli = LS.Geometry.FiniteFreeModuli R kock order compatibility

  MobiusQuotient : Type (ℓ-suc ℓ)
  MobiusQuotient = EB.Theory.Action.Family.Quotient
    (UH.Geometry.IntegerGroup R kock order compatibility)
    (UH.Geometry.integer-mobius-action R kock order compatibility)

  q : UpperHalfPlane → Moduli
  q = LM.Geometry.q R kock order compatibility

  orbit : UpperHalfPlane → MobiusQuotient
  orbit τ = EB.Theory.Action.Family.quotient
    (UH.Geometry.IntegerGroup R kock order compatibility)
    (UH.Geometry.integer-mobius-action R kock order compatibility)
    (EB.Theory.Action.orbit
      (UH.Geometry.IntegerGroup R kock order compatibility)
      (UH.Geometry.integer-mobius-action R kock order compatibility) τ)

  abstract
    quotient≃moduli : MobiusQuotient ≃ Moduli
    quotient≃moduli = Charts.Geometry.Chart.Covered.quotient≃Y
      R kock order compatibility
      (LM.Geometry.standard-lattice R kock order compatibility)
      (LM.Geometry.standard-lattice-predicate R kock order compatibility)
      (Coverage.Geometry.q-surjective R kock order compatibility)

    quotient-triangle : (τ : UpperHalfPlane) → quotient≃moduli .fst (orbit τ) ≡ q τ
    quotient-triangle = Charts.Geometry.Chart.Covered.quotient-triangle
      R kock order compatibility
      (LM.Geometry.standard-lattice R kock order compatibility)
      (LM.Geometry.standard-lattice-predicate R kock order compatibility)
      (Coverage.Geometry.q-surjective R kock order compatibility)

  q-is-action-quotient : Σ[ e ∈ (MobiusQuotient ≃ Moduli) ] (e .fst ∘ orbit ≡ q)
  q-is-action-quotient = quotient≃moduli , funExt quotient-triangle
