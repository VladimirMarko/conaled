{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarFiniteTransformations where

-- Actual maps between finite coherent bar stages. Previous stages and
-- actual typed fillers are mapped recursively; the necessary boundary
-- equality and the resulting raw-family naturality are proved together.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Transformation)
open import Orbifolds.Coherent.EnrichedBarConeData using (LawPair)
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.EnrichedBarConeData as Data
import Orbifolds.Coherent.EnrichedBarConeCompatibility as Compatibility
import Orbifolds.Coherent.EnrichedBarConeTransformations as Transformations
import Orbifolds.Coherent.EnrichedBarConeStages as Stages
import Orbifolds.Coherent.EnrichedBarFiniteStages as Finite
import Orbifolds.Coherent.StrictCubicalShellMaps as Shells
import Orbifolds.Coherent.StrictCubicalFillerMaps as Fillers
import Orbifolds.CubicalShellFillers as CF

module Action {ℓ : Level} {C : Category ℓ ℓ} (D D' : Diagram C ℓ)
    (η : Transformation D D') (E : StrictCubicalExtensionality ℓ) where
  open Category C
  open Chains C
  open Transformation η
  open StrictCubicalExtensionality E
  module Source = Data.Data C D
  module Target = Data.Data C D'
  module SourceStages = Stages.Construction C D E
  module TargetStages = Stages.Construction C D' E
  module SourceFinite = Finite.Finite C D E
  module TargetFinite = Finite.Finite C D' E
  module Natural = Transformations.Action D D' η E
  module Shell = Shells.Action E
  module Filler = Fillers.Action E

  Related : (n : Dim) {P Q : Type ℓ}
    → Source.Families n P → Target.Families n Q → P → Q → SSet ℓ
  Related ozero F G s t = (y : Obj) (c : Chain ozero y)
    → outer (component y (F s y c)) ≡ˢ outer (G t y c)
  Related (osuc n) F G s t = LawPair (Related n (F .fst) (G .fst) s t)
    ((y : Obj) (c : Chain (osuc n) y)
      → outer (map-cube (osuc n) (component y) (F .snd s y c)) ≡ˢ outer (G .snd t y c))

  top-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → (y : Obj) (c : Chain n y)
    → outer (map-cube n (component y) (Source.top n F s y c))
      ≡ˢ outer (Target.top n G t y c)
  top-related ozero F G s t r = r
  top-related (osuc n) F G s t r = LawPair.current r

  reindex-related : (n : Dim) {P Q P' Q' : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (f : P' → P) (g : Q' → Q)
    (s : P') (t : Q') → Related n F G (f s) (g t)
    → Related n (Source.reindex n F f) (Target.reindex n G g) s t
  reindex-related ozero F G f g s t r = r
  LawPair.earlier (reindex-related (osuc n) F G f g s t r) =
    reindex-related n (F .fst) (G .fst) f g s t (LawPair.earlier r)
  LawPair.current (reindex-related (osuc n) F G f g s t r) = LawPair.current r

  one-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → (p : Position (osuc n)) {y : Obj} (c : Chain (osuc n) y)
    → outer (map-cube n (component y) (Source.one-face n F s p c))
      ≡ˢ outer (Target.one-face n G t p c)
  one-related n F G s t r pzero c = strict-trans
    (Natural.action-natural-cube n (last-arrow n c)
      (Source.top n F s (last-source n c) (prefix n c)))
    (strict-cong (λ z → outer (map-cube n (Diagram.action D' (last-arrow n c)) (inner z)))
      (top-related n F G s t r (last-source n c) (prefix n c)))
  one-related (osuc n) F G s t r (psuc p) c = interval-ext λ i → strict-trans
    (Natural.action-natural-cube n (last-arrow (osuc n) c)
      (Source.one-face n (F .fst) s p (prefix (osuc n) c)))
    (strict-cong (λ z → outer (map-cube n (Diagram.action D' (last-arrow (osuc n) c)) (inner z)))
      (one-related n (F .fst) (G .fst) s t (LawPair.earlier r) p (prefix (osuc n) c)))

  faces-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q) (s : P) (t : Q)
    → Related n F G s t → {y : Obj} (c : Chain (osuc n) y)
    → (p : Position (osuc n)) (e : Endpoint)
    → outer (map-cube n (component y) (Source.bar-faces n F s c p e))
      ≡ˢ outer (Target.bar-faces n G t c p e)
  faces-related n F G s t r {y} c p low = top-related n F G s t r y (face n p c)
  faces-related n F G s t r c p high = one-related n F G s t r p c

  boundary-related : (n : Dim) {P Q : Type ℓ}
    (F : Source.Families n P) (G : Target.Families n Q)
    (coherent-F : Source.Coherent n F) (coherent-G : Target.Coherent n G)
    (s : P) (t : Q) → Related n F G s t → (y : Obj) (c : Chain (osuc n) y)
    → outer (Shell.map-shell (osuc n) (component y)
        (SourceStages.Step.boundary-data n P F coherent-F s (y , c)))
      ≡ˢ outer (TargetStages.Step.boundary-data n Q G coherent-G t (y , c))
  boundary-related n F G coherent-F coherent-G s t r y c =
    Shell.assemble-natural-facewise (osuc n) (component y)
      (Source.bar-faces n F s c)
      (Compatibility.Compatibility.bar-compatible C D E n F coherent-F s c)
      (Target.bar-faces n G t c)
      (Compatibility.Compatibility.bar-compatible C D' E n G coherent-G t c)
      (faces-related n F G s t r c)

  mutual
    stage-map : (n : Dim) → SourceFinite.Carrier n → TargetFinite.Carrier n
    stage-map ozero s y = component y (s y)
    stage-map (osuc n) s = stage-map n (s .fst) , λ { (y , c) →
      cast-filler (osuc n)
        (boundary-related n (SourceFinite.families n) (TargetFinite.families n)
          (SourceFinite.coherent n) (TargetFinite.coherent n)
          (s .fst) (stage-map n (s .fst)) (stage-related n (s .fst)) y c)
        (Filler.map-filler (osuc n) (component y)
          (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))) }

    stage-related : (n : Dim) (s : SourceFinite.Carrier n)
      → Related n (SourceFinite.families n) (TargetFinite.families n) s (stage-map n s)
    stage-related ozero s y c = reflˢ
    LawPair.earlier (stage-related (osuc n) s) = reindex-related n
      (SourceFinite.families n) (TargetFinite.families n)
      (SourceFinite.transition n) (TargetFinite.transition n) s (stage-map (osuc n) s)
      (stage-related n (s .fst))
    LawPair.current (stage-related (osuc n) s) y c = strict-sym (strict-trans
      (cast-forget (osuc n)
        (boundary-related n (SourceFinite.families n) (TargetFinite.families n)
          (SourceFinite.coherent n) (TargetFinite.coherent n)
          (s .fst) (stage-map n (s .fst)) (stage-related n (s .fst)) y c)
        (Filler.map-filler (osuc n) (component y)
          (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))))
      (Filler.map-filler-forget (osuc n) (component y)
        (SourceFinite.At.boundary-data n (s .fst) (y , c)) (s .snd (y , c))))

  transition-natural : (n : Dim) (s : SourceFinite.Carrier (osuc n))
    → outer (TargetFinite.transition n (stage-map (osuc n) s))
      ≡ˢ outer (stage-map n (SourceFinite.transition n s))
  transition-natural n s = reflˢ

  stage-top-natural : (n : Dim) (s : SourceFinite.Carrier n) (y : Obj) (c : Chain n y)
    → outer (map-cube n (component y) (Source.top n (SourceFinite.families n) s y c))
      ≡ˢ outer (Target.top n (TargetFinite.families n) (stage-map n s) y c)
  stage-top-natural n s = top-related n (SourceFinite.families n) (TargetFinite.families n)
    s (stage-map n s) (stage-related n s)

  stage-boundary-natural : (n : Dim) (s : SourceFinite.Carrier n) (y : Obj)
    (c : Chain (osuc n) y)
    → outer (Shell.map-shell (osuc n) (component y) (SourceFinite.At.boundary-data n s (y , c)))
      ≡ˢ outer (TargetFinite.At.boundary-data n (stage-map n s) (y , c))
  stage-boundary-natural n s y c = boundary-related n
    (SourceFinite.families n) (TargetFinite.families n)
    (SourceFinite.coherent n) (TargetFinite.coherent n)
    s (stage-map n s) (stage-related n s) y c
