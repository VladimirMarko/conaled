{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.OuterCoordinateReversal where

-- Actual reversal of finite coordinate tuples and cubes. All index
-- combinatorics use outer finite recursion; all cubes remain inner.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position; pzero; psuc; weaken)
open import Orbifolds.Coherent.OuterCubicalFaces
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
open import Orbifolds.Coherent.CoherentArrowSplits using (prefix-weaken; suffix-weaken)
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)

last-position : (n : Dim) → Position (osuc n)
last-position ozero = pzero
last-position (osuc n) = psuc (last-position n)

reverse-position : (n : Dim) → Position (osuc n) → Position (osuc n)
reverse-position n pzero = last-position n
reverse-position (osuc n) (psuc p) = weaken (reverse-position n p)

reverse-weaken : (n : Dim) (p : Position (osuc n))
  → reverse-position (osuc n) (weaken p) ≡ˢ psuc (reverse-position n p)
reverse-weaken n pzero = reflˢ
reverse-weaken (osuc n) (psuc p) = strict-cong weaken (reverse-weaken n p)

reverse-last : (n : Dim) → reverse-position n (last-position n) ≡ˢ pzero
reverse-last ozero = reflˢ
reverse-last (osuc n) = strict-cong weaken (reverse-last n)

position-involution : (n : Dim) (p : Position (osuc n))
  → reverse-position n (reverse-position n p) ≡ˢ p
position-involution n pzero = reverse-last n
position-involution (osuc n) (psuc p) = strict-trans
  (reverse-weaken n (reverse-position n p)) (strict-cong psuc (position-involution n p))

prefix-last : (n : Dim) → prefix-degree n (last-position n) ≡ˢ ozero
prefix-last ozero = reflˢ
prefix-last (osuc n) = prefix-last n

suffix-last : (n : Dim) → suffix-degree n (last-position n) ≡ˢ n
suffix-last ozero = reflˢ
suffix-last (osuc n) = strict-cong osuc (suffix-last n)

reverse-prefix-degree : (n : Dim) (p : Position (osuc n))
  → prefix-degree n (reverse-position n p) ≡ˢ suffix-degree n p
reverse-prefix-degree n pzero = prefix-last n
reverse-prefix-degree (osuc n) (psuc p) = strict-trans
  (prefix-weaken n (reverse-position n p)) (strict-cong osuc (reverse-prefix-degree n p))

reverse-suffix-degree : (n : Dim) (p : Position (osuc n))
  → suffix-degree n (reverse-position n p) ≡ˢ prefix-degree n p
reverse-suffix-degree n pzero = suffix-last n
reverse-suffix-degree (osuc n) (psuc p) = strict-trans
  (suffix-weaken n (reverse-position n p)) (reverse-suffix-degree n p)

snoc : (n : Dim) → Coordinates n → Coordinate → Coordinates (osuc n)
snoc ozero xs i = pair i ott
snoc (osuc n) xs i = pair (first xs) (snoc n (second xs) i)

reverse-coordinates : (n : Dim) → Coordinates n → Coordinates n
reverse-coordinates ozero xs = ott
reverse-coordinates (osuc n) xs = snoc n (reverse-coordinates n (second xs)) (first xs)

reverse-snoc : (n : Dim) (xs : Coordinates n) (i : Coordinate)
  → reverse-coordinates (osuc n) (snoc n xs i) ≡ˢ pair i (reverse-coordinates n xs)
reverse-snoc ozero xs i = reflˢ
reverse-snoc (osuc n) xs i = strict-cong (λ ys → snoc (osuc n) ys (first xs))
  (reverse-snoc n (second xs) i)

coordinates-involution : (n : Dim) (xs : Coordinates n)
  → reverse-coordinates n (reverse-coordinates n xs) ≡ˢ xs
coordinates-involution ozero xs = reflˢ
coordinates-involution (osuc n) xs = strict-trans
  (reverse-snoc n (reverse-coordinates n (second xs)) (first xs))
  (strict-cong (pair (first xs)) (coordinates-involution n (second xs)))

insert-last : (n : Dim) (i : I) (xs : Coordinates n)
  → insert n (last-position n) i xs ≡ˢ snoc n xs (coord i)
insert-last ozero i xs = reflˢ
insert-last (osuc n) i xs = strict-cong (pair (first xs)) (insert-last n i (second xs))

insert-snoc : (n : Dim) (p : Position (osuc n)) (i : I) (xs : Coordinates n) (j : Coordinate)
  → insert (osuc n) (weaken p) i (snoc n xs j) ≡ˢ snoc (osuc n) (insert n p i xs) j
insert-snoc n pzero i xs j = reflˢ
insert-snoc (osuc n) (psuc p) i xs j = strict-cong (pair (first xs))
  (insert-snoc n p i (second xs) j)

reverse-insert : (n : Dim) (p : Position (osuc n)) (i : I) (xs : Coordinates n)
  → reverse-coordinates (osuc n) (insert n p i xs)
    ≡ˢ insert n (reverse-position n p) i (reverse-coordinates n xs)
reverse-insert n pzero i xs = strict-sym (insert-last n i (reverse-coordinates n xs))
reverse-insert (osuc n) (psuc p) i xs = strict-trans
  (strict-cong (λ ys → snoc (osuc n) ys (first xs)) (reverse-insert n p i (second xs)))
  (strict-sym (insert-snoc n (reverse-position n p) i (reverse-coordinates n (second xs)) (first xs)))

reverse-cube : ∀ {ℓ} (n : Dim) {X : Type ℓ} → Cube n X → Cube n X
reverse-cube n c = abstract-cube n (λ xs → evaluate n c (reverse-coordinates n xs))

reverse-evaluation : ∀ {ℓ} (n : Dim) {X : Type ℓ} (c : Cube n X) (xs : Coordinates n)
  → outer (evaluate n (reverse-cube n c) xs) ≡ˢ outer (evaluate n c (reverse-coordinates n xs))
reverse-evaluation n c xs = evaluate-abstract n (λ ys → evaluate n c (reverse-coordinates n ys)) xs

map-evaluation : ∀ {ℓ ℓ'} (n : Dim) {X : Type ℓ} {Y : Type ℓ'}
  (f : X → Y) (c : Cube n X) (xs : Coordinates n)
  → outer (evaluate n (map-cube n f c) xs) ≡ˢ outer (f (evaluate n c xs))
map-evaluation ozero f c xs = reflˢ
map-evaluation (osuc n) f c xs = map-evaluation n f (c (value (first xs))) (second xs)

prefix-coordinates : (n : Dim) (p : Position (osuc n)) → Coordinates n → Coordinates (prefix-degree n p)
prefix-coordinates n pzero xs = xs
prefix-coordinates (osuc n) (psuc p) xs = prefix-coordinates n p (second xs)

suffix-coordinates : (n : Dim) (p : Position (osuc n)) → Coordinates n → Coordinates (suffix-degree n p)
suffix-coordinates n pzero xs = ott
suffix-coordinates (osuc n) (psuc p) xs = pair (first xs) (suffix-coordinates n p (second xs))

tensor-evaluation : ∀ {ℓ} (n : Dim) (p : Position (osuc n)) {A B C : Type ℓ}
  (g : B → Cube (suffix-degree n p) C) (f : A → Cube (prefix-degree n p) B)
  (a : A) (xs : Coordinates n)
  → outer (evaluate n (tensor-action n p g f a) xs)
    ≡ˢ outer (evaluate (suffix-degree n p)
      (g (evaluate (prefix-degree n p) (f a) (prefix-coordinates n p xs)))
      (suffix-coordinates n p xs))
tensor-evaluation n pzero g f a xs = map-evaluation n g (f a) xs
tensor-evaluation (osuc n) (psuc p) g f a xs = tensor-evaluation n p
  (λ b → g b (value (first xs))) f a (second xs)

module Reversal {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open Extensional E

  reverse-face : (n : Dim) (p : Position (osuc n)) (i : I) {X : Type ℓ}
    (c : Cube (osuc n) X)
    → outer (coordinate-face n p i (reverse-cube (osuc n) c))
      ≡ˢ outer (reverse-cube n (coordinate-face n (reverse-position n p) i c))
  reverse-face n p i c = cube-extensionality n λ xs → strict-trans
    (face-evaluation n p i (reverse-cube (osuc n) c) xs)
    (strict-trans
      (reverse-evaluation (osuc n) c (insert n p i xs))
      (strict-trans
        (strict-cong (λ ys → outer (evaluate (osuc n) c ys)) (reverse-insert n p i xs))
        (strict-trans
          (strict-sym (face-evaluation n (reverse-position n p) i c (reverse-coordinates n xs)))
          (strict-sym (reverse-evaluation n (coordinate-face n (reverse-position n p) i c) xs)))))

  cube-involution : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → outer (reverse-cube n (reverse-cube n c)) ≡ˢ outer c
  cube-involution n c = cube-extensionality n λ xs → strict-trans
    (reverse-evaluation n (reverse-cube n c) xs)
    (strict-trans
      (reverse-evaluation n c (reverse-coordinates n xs))
      (strict-cong (λ ys → outer (evaluate n c ys)) (coordinates-involution n xs)))

  reverse-map : ∀ {ℓx} (n : Dim) {X : Type ℓx} {Y : Type ℓ} (f : X → Y) (c : Cube n X)
    → outer (reverse-cube n (map-cube n f c)) ≡ˢ outer (map-cube n f (reverse-cube n c))
  reverse-map n f c = cube-extensionality n λ xs → strict-trans
    (reverse-evaluation n (map-cube n f c) xs)
    (strict-trans
      (map-evaluation n f c (reverse-coordinates n xs))
      (strict-trans
        (strict-cong (λ a → outer (f (inner a))) (strict-sym (reverse-evaluation n c xs)))
        (strict-sym (map-evaluation n f (reverse-cube n c) xs))))
