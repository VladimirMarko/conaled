{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictCubicalTotalIsomorphism where

-- Canonical cubes and total endpoint-typed fillers are strict inverses
-- under the named cubical extensionality structure. Their literal maps
-- commute with all direct coordinate actions, avoiding chosen inverses.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; map-cube)
open import Orbifolds.Coherent.StrictCubicalFillerMaps using (cast-filler; cast-forget)
import Orbifolds.Coherent.StrictCubicalFillerMaps as FMaps
import Orbifolds.Coherent.StrictCubicalFillers as FBoundary
import Orbifolds.Coherent.StrictCubicalShellMaps as SMaps
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF

strict-total-pair : ∀ {ℓ} (n : Dim) {X : Type ℓ}
  (b b' : CS.Shell (toNat n) X) (c : CF.Filler (toNat n) b) (c' : CF.Filler (toNat n) b')
  (p : outer b ≡ˢ outer b')
  → outer (cast-filler n p c) ≡ˢ outer c'
  → outer (b , c) ≡ˢ outer (b' , c')
strict-total-pair n b .b c .c reflˢ reflˢ = reflˢ

module Natural {ℓ : Level} (E : StrictCubicalExtensionality ℓ) where
  open StrictCubicalExtensionality E
  module Filler = FMaps.Action E
  module Boundary = FBoundary.Boundary E
  module Shell = SMaps.Action E

  canonical-forget : (n : Dim) {X : Type ℓ} (z : CF.Total (toNat n) X)
    → outer (CF.canonical (toNat n) (CF.forget-total (toNat n) z)) ≡ˢ outer z
  canonical-forget n (b , c) = strict-total-pair n
    (CS.restriction (toNat n) (CF.forget-filler (toNat n) b c)) b
    (CF.canonical-filler (toNat n) (CF.forget-filler (toNat n) b c)) c
    (Boundary.forget-boundary-strict n b c)
    (Filler.filler-extensionality n b (strict-trans
      (cast-forget n (Boundary.forget-boundary-strict n b c)
        (CF.canonical-filler (toNat n) (CF.forget-filler (toNat n) b c)))
      (Boundary.forget-canonical-strict n (CF.forget-filler (toNat n) b c))))

  forget-canonical : (n : Dim) {X : Type ℓ} (c : Cube n X)
    → outer (CF.forget-total (toNat n) (CF.canonical (toNat n) c)) ≡ˢ outer c
  forget-canonical = Boundary.forget-canonical-strict

  total-isomorphism : (n : Dim) (X : Type ℓ) → Iso (Cube n X) (CF.Total (toNat n) X)
  Iso.fun (total-isomorphism n X) = CF.canonical (toNat n)
  Iso.inv (total-isomorphism n X) = CF.forget-total (toNat n)
  Iso.rightInv (total-isomorphism n X) z = strict-to-path (canonical-forget n z)
  Iso.leftInv (total-isomorphism n X) c = strict-to-path (forget-canonical n c)

  total-equivalence : (n : Dim) (X : Type ℓ) → Cube n X ≃ CF.Total (toNat n) X
  total-equivalence n X = isoToEquiv (total-isomorphism n X)

  -- This map has the requested shell action literally as its first
  -- projection, so it induces the ordinary map of projection fibers.
  typed-map : (n : Dim) {X Y : Type ℓ} (f : X → Y)
    → CF.Total (toNat n) X → CF.Total (toNat n) Y
  typed-map n f (b , c) = Shell.map-shell n f b , Filler.map-filler n f b c

  typed-map-is-total : (n : Dim) {X Y : Type ℓ} (f : X → Y) (z : CF.Total (toNat n) X)
    → outer (Filler.map-total n f z) ≡ˢ outer (typed-map n f z)
  typed-map-is-total n f (b , c) = strict-total-pair n
    (Filler.map-total n f (b , c) .fst) (Shell.map-shell n f b)
    (Filler.map-total n f (b , c) .snd) (Filler.map-filler n f b c)
    (Filler.map-total-boundary n f (b , c)) reflˢ

  typed-map-first : (n : Dim) {X Y : Type ℓ} (f : X → Y) (z : CF.Total (toNat n) X)
    → outer (typed-map n f z .fst) ≡ˢ outer (Shell.map-shell n f (z .fst))
  typed-map-first n f z = reflˢ

  canonical-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X)
    → outer (typed-map n f (CF.canonical (toNat n) c))
      ≡ˢ outer (CF.canonical (toNat n) (map-cube n f c))
  canonical-natural n f c = strict-trans
    (strict-sym (typed-map-is-total n f (CF.canonical (toNat n) c)))
    (Filler.map-total-canonical n f c)

  forget-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (z : CF.Total (toNat n) X)
    → outer (CF.forget-total (toNat n) (typed-map n f z))
      ≡ˢ outer (map-cube n f (CF.forget-total (toNat n) z))
  forget-natural n f z = strict-trans
    (strict-cong (λ q → outer (CF.forget-total (toNat n) (inner q)))
      (strict-sym (typed-map-is-total n f z)))
    (Filler.map-total-forget n f z)

  origin-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X)
    → outer (CS.origin (toNat n) (map-cube n f c))
      ≡ˢ outer (f (CS.origin (toNat n) c))
  origin-natural ozero f c = reflˢ
  origin-natural (osuc n) f c = origin-natural n f (c i0)

  constant-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (x : X)
    → outer (map-cube n f (CS.constant-cube (toNat n) x))
      ≡ˢ outer (CS.constant-cube (toNat n) (f x))
  constant-natural ozero f x = reflˢ
  constant-natural (osuc n) f x = interval-ext λ i → constant-natural n f x

  contraction-natural : (n : Dim) {X Y : Type ℓ} (f : X → Y) (c : Cube n X) (i : I)
    → outer (map-cube n f (CS.contract-cube (toNat n) c i))
      ≡ˢ outer (CS.contract-cube (toNat n) (map-cube n f c) i)
  contraction-natural ozero f c i = reflˢ
  contraction-natural (osuc n) f c i = interval-ext λ j →
    contraction-natural n f (c (j ∧ i)) i
