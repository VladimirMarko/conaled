{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispColimits where

-- Theorem 5.4.8 and the preservation premises of 5.4.7, discharged
-- for actual crystalline nullification from a tiny adjoint of 𝔇.
-- Only the uniform ambient crisp identity-induction rule is needed
-- beyond native crisp contexts; no colimit preservation is assumed.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Nat using (ℕ; suc; discreteℕ)
open import Cubical.Data.Sequence using (Sequence)
open import Orbifolds.Crisp using (box)
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Functions.Surjection
open import Cubical.Relation.Nullary using (yes; no)
import Cubical.Data.Empty as Empty
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.CrispIdentity using (CrispIdentityInduction)
open import Orbifolds.CrispNaturals using (natural-crisp-elim)
open import Orbifolds.Penon using (Neighbors; preservesNeighbors)
import Orbifolds.Crystalline as CR
import Orbifolds.CrystallineColimits as CC
import Orbifolds.DecidableDiscrete as DD
import Orbifolds.ModalEtalePushouts as EP
import Orbifolds.ModalEtaleSequences as ES
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyPushouts as TP
import Orbifolds.TinySequences as TS

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ})
    (@♭ witness : TT.External.AdjointData (CR.Ring.𝔇 R)) where
  open CR.Ring R
  module Colimits = CC.Ring R
  module Pushouts = EP.Theory CrystallineModality
  module Sequences = ES.Theory CrystallineModality
  module Adjoint = TT.External.Candidate 𝔇 witness
  module TinyPushout = TP.Context rules 𝔇 witness
  module TinySequence = TS.Context rules 𝔇 witness

  -- This argument is universe-polymorphic in the target of a 𝔇-curve;
  -- Nat stays in its small universe even when the real carrier is large.
  neighboring-naturals : {n m : ℕ} → Neighbors n m → n ≡ m
  neighboring-naturals {n} {m} near with discreteℕ n m
  ... | yes equal = equal
  ... | no different = Empty.rec (near different)

  natural-numbers-null : isEquiv (const :> (ℕ → (𝔇 → ℕ)))
  natural-numbers-null = isoToIsEquiv
    (iso const (λ f → f zero𝔇)
      (λ f → funExt λ d → sym (neighboring-naturals
        (preservesNeighbors f (DD.Ring.generator-neighbor R d))))
      (λ _ → refl))

  module Proof (adjunction : Adjoint.ExternalAdjunction) where
    crisp-pushout-preservation : (@♭ A B C : Type ℓ)
      (@♭ f : A → B) (@♭ g : A → C)
      → Pushouts.PushoutDiagram.Preserved f g
    crisp-pushout-preservation A B C f g = Colimits.Pushout.preservation f g
      (TinyPushout.Diagram.preserves-pushout (Crystal.◯-map f) (Crystal.◯-map g) adjunction)

    crisp-sequence-preservation : (@♭ X : Sequence ℓ)
      → Sequences.SequenceDiagram.Preserved X
    crisp-sequence-preservation X = Colimits.SequenceColimit.preservation X
      (TinySequence.Diagram.Proof.preserves-sequence
        (Sequences.SequenceDiagram.ReflectedSequence X) natural-numbers-null adjunction)

  module SelfPullback {@♭ A B : Type ℓ} (@♭ f : A → B) where
    module Diagram = Colimits.SelfPullback f
    module D = Diagram.D

    preserves-join-diagrams : Adjoint.ExternalAdjunction → D.PreservesJoinDiagrams
    preserves-join-diagrams adjunction .D.join-pushouts = natural-crisp-elim
      (λ n → Pushouts.PushoutDiagram.Preserved
        (D.Join.Successor.left (suc n)) (D.Join.Successor.right (suc n)))
      (λ n → Proof.crisp-pushout-preservation adjunction
        (D.Join.Successor.Pullback (suc n)) (D.Join.Stage (suc n)) A
        (D.Join.Successor.left (suc n)) (D.Join.Successor.right (suc n)))
    preserves-join-diagrams adjunction .D.positive-colimit =
      Proof.crisp-sequence-preservation adjunction D.PositiveStages

    -- Source data is judgmentally crisp, but its etaleness and
    -- surjectivity proofs and the adjunction proof may be ordinary.
    self-pullback-descent : Adjoint.ExternalAdjunction
      → Crystal.Etale D.Kernel.left → isSurjection f → Crystal.Etale f
    self-pullback-descent adjunction = D.Descent.self-pullback-descent
      (λ X → crystalline-unit-surjective {X}) (preserves-join-diagrams adjunction)

-- The paper requires mere tinyness, not a globally selected adjoint.
-- Each preservation assertion is a proposition, so ordinary truncation
-- elimination removes the chosen-adjoint presentation above.
module FromTinyness {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ rules : CrispIdentityInduction {ℓ}) where
  open CR.Ring R
  module Adjoints = TT.External 𝔇
  module Colimits = CC.Ring R
  module Pushouts = EP.Theory CrystallineModality
  module Sequences = ES.Theory CrystallineModality

  crisp-pushout-preservation : Adjoints.Tiny → (@♭ A B C : Type ℓ)
    (@♭ f : A → B) (@♭ g : A → C) → Pushouts.PushoutDiagram.Preserved f g
  crisp-pushout-preservation tiny A B C f g = PT.rec (isPropIsEquiv _)
    (λ { (box witness , adjunction) →
      Context.Proof.crisp-pushout-preservation R rules witness adjunction A B C f g }) tiny

  crisp-sequence-preservation : Adjoints.Tiny → (@♭ X : Sequence ℓ)
    → Sequences.SequenceDiagram.Preserved X
  crisp-sequence-preservation tiny X = PT.rec (isPropIsEquiv _)
    (λ { (box witness , adjunction) →
      Context.Proof.crisp-sequence-preservation R rules witness adjunction X }) tiny

  module SelfPullback {@♭ A B : Type ℓ} (@♭ f : A → B) where
    module D = Colimits.SelfPullback.D f

    preserves-join-diagrams : Adjoints.Tiny → D.PreservesJoinDiagrams
    preserves-join-diagrams tiny .D.join-pushouts = natural-crisp-elim
      (λ n → Pushouts.PushoutDiagram.Preserved
        (D.Join.Successor.left (suc n)) (D.Join.Successor.right (suc n)))
      (λ n → crisp-pushout-preservation tiny
        (D.Join.Successor.Pullback (suc n)) (D.Join.Stage (suc n)) A
        (D.Join.Successor.left (suc n)) (D.Join.Successor.right (suc n)))
    preserves-join-diagrams tiny .D.positive-colimit =
      crisp-sequence-preservation tiny D.PositiveStages

    self-pullback-descent : Adjoints.Tiny
      → Crystal.Etale D.Kernel.left → isSurjection f → Crystal.Etale f
    self-pullback-descent tiny = D.Descent.self-pullback-descent
      (λ X → crystalline-unit-surjective {X}) (preserves-join-diagrams tiny)
