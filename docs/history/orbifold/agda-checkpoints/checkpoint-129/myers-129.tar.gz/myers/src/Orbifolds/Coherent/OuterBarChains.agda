{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.OuterBarChains where

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude
open import Cubical.Data.Nat using (ℕ; zero; suc)
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
import Orbifolds.Coherent.EnrichedBarChains as Inner

-- Only finite combinatorial recursion takes place in these outer types.
-- All chain spaces and all coefficient/cell spaces remain fibrant types.
data Dim : SSet where
  ozero : Dim
  osuc : Dim → Dim

toNat : Dim → ℕ
toNat ozero = zero
toNat (osuc n) = suc (toNat n)

data Position : Dim → SSet where
  pzero : {n : Dim} → Position (osuc n)
  psuc : {n : Dim} → Position n → Position (osuc n)

weaken : {n : Dim} → Position n → Position (osuc n)
weaken pzero = pzero
weaken (psuc i) = psuc (weaken i)

toFin : {n : Dim} → Position n → Inner.Fin.Fin (toNat n)
toFin pzero = Inner.Fin.fzero
toFin (psuc i) = Inner.Fin.fsuc (toFin i)

data _≤ᵖ_ : {n : Dim} → Position n → Position n → SSet where
  pzero≤ : {n : Dim} {j : Position (osuc n)} → pzero ≤ᵖ j
  psuc≤ : {n : Dim} {i j : Position n} → i ≤ᵖ j → psuc i ≤ᵖ psuc j

module Chains {ℓo ℓh : Level} (C : Category ℓo ℓh) where
  open Category C
  module IC = Inner.Chains C

  Chain : Dim → Obj → Type (ℓ-max ℓo ℓh)
  Chain n = IC.Chain (toNat n)

  Index : Dim → Type (ℓ-max ℓo ℓh)
  Index n = IC.Index (toNat n)

  last-source : (n : Dim) {y : Obj} → Chain (osuc n) y → Obj
  last-source n = IC.last-source (toNat n)

  last-arrow : (n : Dim) {y : Obj} (c : Chain (osuc n) y)
    → Hom (last-source n c) y
  last-arrow n = IC.last-arrow (toNat n)

  prefix : (n : Dim) {y : Obj} (c : Chain (osuc n) y) → Chain n (last-source n c)
  prefix n = IC.prefix (toNat n)

  append : (n : Dim) {x y : Obj} → Hom x y → Chain n x → Chain (osuc n) y
  append n = IC.append (toNat n)

  -- These actual face maps are defined by finite OUTER recursion.
  -- Pattern matching on inner chain values is never needed: only projections.
  face : (n : Dim) → Position (osuc n) → {y : Obj}
    → Chain (osuc n) y → Chain n y
  face ozero pzero {y} c = IC.zero-chain y
  face (osuc n) pzero c =
    prefix (osuc n) c .fst ,
    compose (last-arrow (osuc n) c) (last-arrow n (prefix (osuc n) c)) ,
    prefix n (prefix (osuc n) c)
  face (osuc n) (psuc i) c =
    last-source (osuc n) c , last-arrow (osuc n) c , face n i (prefix (osuc n) c)

  face-agrees-inner : (n : Dim) (i : Position (osuc n)) {y : Obj}
    (c : Chain (osuc n) y)
    → outer (face n i c) ≡ˢ outer (IC.face (toNat n) (toFin i) c)
  face-agrees-inner ozero pzero c = reflˢ
  face-agrees-inner (osuc n) pzero c = reflˢ
  face-agrees-inner (osuc n) (psuc i) c = strict-cong
    (λ q → outer (append n (last-arrow (osuc n) c) (inner q)))
    (face-agrees-inner n i (prefix (osuc n) c))

  face-face : (n : Dim) (i j : Position (osuc n)) → i ≤ᵖ j
    → {y : Obj} (c : Chain (osuc (osuc n)) y)
    → outer (face n i (face (osuc n) (psuc j) c))
      ≡ˢ outer (face n j (face (osuc n) (weaken i) c))
  face-face ozero pzero pzero pzero≤ c = reflˢ
  face-face (osuc n) pzero pzero pzero≤ c = strict-cong
    (λ q → outer (append n (inner q)
      (prefix n (prefix (osuc n) (prefix (osuc (osuc n)) c)))))
    (assoc
      (last-arrow (osuc (osuc n)) c)
      (last-arrow (osuc n) (prefix (osuc (osuc n)) c))
      (last-arrow n (prefix (osuc n) (prefix (osuc (osuc n)) c))))
  face-face (osuc n) pzero (psuc j) pzero≤ c = reflˢ
  face-face (osuc n) (psuc i) (psuc j) (psuc≤ le) c = strict-cong
    (λ q → outer (append n (last-arrow (osuc (osuc n)) c) (inner q)))
    (face-face n i j le (prefix (osuc (osuc n)) c))

  -- Any two composable derivations of the same face identification coincide.
  -- Iterating this fact supplies all higher coherence for the strict face laws.
  face-coherence : {n : Dim} {y : Obj} {c d : Chain n y}
    (p q : outer c ≡ˢ outer d) → p ≡ˢ q
  face-coherence = strict-uip

module Cochains {ℓo ℓh ℓ : Level} {C : Category ℓo ℓh}
    (D : Diagram C ℓ) where
  open Category C
  open Diagram D
  open Chains C

  Cochain : Dim → Type (ℓ-max ℓ (ℓ-max ℓo ℓh))
  Cochain n = (y : Obj) → Chain n y → Value y

  action-face : (n : Dim) → Cochain n → Cochain (osuc n)
  action-face n h y c = action (last-arrow n c)
    (h (last-source n c) (prefix n c))

  other-face : (n : Dim) → Position (osuc n) → Cochain n → Cochain (osuc n)
  other-face n i h y c = h y (face n i c)

  action-action : (n : Dim) (h : Cochain n)
    (y : Obj) (c : Chain (osuc (osuc n)) y)
    → outer (other-face (osuc n) pzero (action-face n h) y c)
      ≡ˢ outer (action-face (osuc n) (action-face n h) y c)
  action-action n h y c = action-compose-point
    (last-arrow (osuc n) c)
    (last-arrow n (prefix (osuc n) c))
    (h (last-source n (prefix (osuc n) c)) (prefix n (prefix (osuc n) c)))

  action-other : (n : Dim) (i : Position (osuc n)) (h : Cochain n)
    (y : Obj) (c : Chain (osuc (osuc n)) y)
    → outer (other-face (osuc n) (psuc i) (action-face n h) y c)
      ≡ˢ outer (action-face (osuc n) (other-face n i h) y c)
  action-other n i h y c = reflˢ

  other-other : (n : Dim) (i j : Position (osuc n)) → i ≤ᵖ j
    → (h : Cochain n) (y : Obj) (c : Chain (osuc (osuc n)) y)
    → outer (other-face (osuc n) (psuc j) (other-face n i h) y c)
      ≡ˢ outer (other-face (osuc n) (weaken i) (other-face n j h) y c)
  other-other n i j le h y c = strict-cong
    (λ q → outer (h y (inner q))) (face-face n i j le c)

  action-coherence : {x : Obj} {u v : Value x}
    (p q : outer u ≡ˢ outer v) → p ≡ˢ q
  action-coherence = strict-uip
