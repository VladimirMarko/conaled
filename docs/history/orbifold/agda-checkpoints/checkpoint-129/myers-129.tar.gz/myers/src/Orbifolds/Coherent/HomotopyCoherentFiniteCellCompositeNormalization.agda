{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellCompositeNormalization where

-- Normalize the first and lower factors of the finite projection law.
-- Its two auxiliary bridges come from separate certificate modules.
-- The chosen triangle, last strict proof, and right association are unchanged.
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentColimitSuccessor as OriginalSuccessor
import Orbifolds.Coherent.HomotopyCoherentFiniteCellMaps as Core
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
import Orbifolds.Coherent.HomotopyCoherentFiniteCellCoherence as FiniteCoherence
import Orbifolds.Coherent.HomotopyCoherentFiniteCellFirstNormalization as FirstNormalization
import Orbifolds.Coherent.HomotopyCoherentFiniteCellLowerAgreement as LowerAgreement
import Agda.Builtin.Reflection as R
open import Agda.Builtin.List using ([]; _∷_)
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen; hidden-argument; visible-argument)

replace-factors : ∀ {ℓ} {B : Type ℓ} {x w v z : B}
  {r : x ≡ z} {first normalized-first : x ≡ w}
  {middle public-middle : w ≡ v} {last : v ≡ z}
  (law : r ≡ first ∙ (middle ∙ last))
  (first-bridge : first ≡ normalized-first)
  (lower-agreement : outer public-middle ≡ˢ outer middle)
  → r ≡ normalized-first ∙ (public-middle ∙ last)
replace-factors {last = last} law first-bridge lower-agreement =
  law ∙ cong₂ _∙_ first-bridge
    (cong (λ m → m ∙ last) (sym (strict-to-path lower-agreement)))

private
  h : R.Arg R.Term
  h = hidden-argument R.unknown

  macro
    normalize-factors-frozen : R.Term → R.Term → R.Term → R.Term → R.TC ⊤
    normalize-factors-frozen law first-bridge lower-agreement hole = assign-frozen
      ((quote OriginalSuccessor.Successor.transition-computation) ∷
       (quote Literal.Map.induced) ∷ (quote Core.Construction.At.lower-path) ∷
       (quote strict-to-path) ∷ (quote _∙_) ∷ [])
      (R.def (quote replace-factors)
        (h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷ h ∷
         visible-argument law ∷ visible-argument first-bridge ∷
         visible-argument lower-agreement ∷ [])) hole

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module Finite = FiniteCoherence.Construction C D G α E F n source target f triangle
    using (composite-prefix; last-equality)
  module First = FirstNormalization.Construction C D G α E F n source target f triangle
    using (first-bridge)
  module Lower = LowerAgreement.Construction C D G α E F n source target f triangle
    using (lower-agreement)

  normalized-composite : _
  normalized-composite = normalize-factors-frozen
    Finite.composite-prefix First.first-bridge Lower.lower-agreement
