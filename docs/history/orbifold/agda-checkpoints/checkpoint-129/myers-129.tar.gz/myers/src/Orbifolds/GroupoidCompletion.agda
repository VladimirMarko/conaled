{-# OPTIONS --safe --cubical --guardedness --no-import-sorts #-}

-- Actual Rezk completion of a category whose arrows are all invertible.
-- This uses the pinned Cubical HIT construction, including its proved
-- univalence and universal property.  The path/hom comparison is derived,
-- not supplied as an assumption on a proposed quotient.
module Orbifolds.GroupoidCompletion where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism using (iso; isoToEquiv)
open import Cubical.Data.Sigma
open import Cubical.Functions.Surjection
open import Cubical.Categories.Category
  using (Category; isIso; isPropIsIso; CatIso; pathToIso; isUnivalent)
open import Cubical.Categories.Functor using (Functor)
open import Cubical.Categories.Equivalence.WeakEquivalence
  using (isWeakEquivalence)
open import Cubical.Categories.RezkCompletion.Base using (isRezkCompletion)
open import Cubical.Categories.RezkCompletion.Construction using (module RezkByHIT)

private
  variable
    ℓ ℓ' : Level

-- Standard groupoid hypothesis: every morphism of the category is an
-- isomorphism.  Category already contains the associativity/unit laws and
-- sethood of hom types.  No univalence of the input category is required.
AllInvertible : (C : Category ℓ ℓ') → Type (ℓ-max ℓ ℓ')
AllInvertible C =
  (x y : Category.ob C) (f : Category.Hom[_,_] C x y) → isIso C f

module Completion (C : Category ℓ ℓ') (invertible : AllInvertible C) where
  module R = RezkByHIT C

  Object : Type (ℓ-max ℓ ℓ')
  Object = R.RezkOb

  object : Category.ob C → Object
  object = R.inc

  object-surjective : isSurjection object
  object-surjective = R.inc-surj

  object-surjection : Category.ob C ↠ Object
  object-surjection = object , object-surjective

  completion-isGroupoid : isGroupoid Object
  completion-isGroupoid = R.squash

  completedCategory : Category (ℓ-max ℓ ℓ') ℓ'
  completedCategory = R.Rezk

  inclusionFunctor : Functor C completedCategory
  inclusionFunctor = R.→Rezk

  completion-isUnivalent : isUnivalent completedCategory
  completion-isUnivalent = R.isUnivalentRezk

  inclusion-isWeakEquivalence : isWeakEquivalence inclusionFunctor
  inclusion-isWeakEquivalence = R.isWkEquiv→Rezk

  -- This is the library's proved universal property, not just a name for
  -- the HIT object type.  Its universe-polymorphic statement lives in Typeω.
  completion-universal : isRezkCompletion inclusionFunctor
  completion-universal = R.isRezkCompletion→Rezk

  morphismPath : {x y : Category.ob C}
    → Category.Hom[_,_] C x y → object x ≡ object y
  morphismPath {x} {y} f = R.inc-ua (f , invertible x y f)

  morphismPath-identity : {x : Category.ob C}
    → morphismPath (Category.id C {x}) ≡ refl
  morphismPath-identity =
    cong R.inc-ua (Σ≡Prop isPropIsIso refl) ∙ R.inc-id

  morphismPath-composition : {x y z : Category.ob C}
    → (f : Category.Hom[_,_] C x y) (g : Category.Hom[_,_] C y z)
    → morphismPath (Category._⋆_ C f g) ≡ morphismPath f ∙ morphismPath g
  morphismPath-composition {x} {y} {z} f g =
    cong R.inc-ua (Σ≡Prop isPropIsIso refl)
      ∙ R.inc-⋆ (f , invertible x y f) (g , invertible y z g)

  pathMorphism : {x y : Category.ob C}
    → object x ≡ object y → Category.Hom[_,_] C x y
  pathMorphism p = R.RezkIso→Iso (pathToIso {C = R.Rezk} p) .fst

  -- The hom-to-path constructor computes correctly on all original arrows.
  pathMorphism-morphismPath : {x y : Category.ob C}
    → (f : Category.Hom[_,_] C x y) → pathMorphism (morphismPath f) ≡ f
  pathMorphism-morphismPath {x} {y} f = cong fst
    (R.RezkIsoToPathβ (object x) (object y)
      (R.Iso→RezkIso (f , invertible x y f)))

  -- The other direction uses univalence of the completed category and
  -- propositionhood of the original isomorphism structure.
  morphismPath-pathMorphism : {x y : Category.ob C}
    → (p : object x ≡ object y) → morphismPath (pathMorphism p) ≡ p
  morphismPath-pathMorphism {x} {y} p =
    cong R.inc-ua (Σ≡Prop isPropIsIso refl)
      ∙ R.RezkIsoToPathη (object x) (object y) p

  -- The identity/hom equivalence invoked for Rezk completion in §6.3.
  -- Both maps and both homotopies have been supplied explicitly above.
  identification≃hom : (x y : Category.ob C)
    → (object x ≡ object y) ≃ Category.Hom[_,_] C x y
  identification≃hom x y = isoToEquiv (iso
    pathMorphism morphismPath pathMorphism-morphismPath morphismPath-pathMorphism)

  hom≃identification : (x y : Category.ob C)
    → Category.Hom[_,_] C x y ≃ (object x ≡ object y)
  hom≃identification x y = invEquiv (identification≃hom x y)

  -- Proof-valued properties of any completed object descend from original
  -- objects.  This is the HIT eliminator, so representatives are not chosen.
  proposition-induction : {ρ : Level} (P : Object → Type ρ)
    → ((u : Object) → isProp (P u))
    → ((x : Category.ob C) → P (object x))
    → (u : Object) → P u
  proposition-induction P propP = R.elimProp propP

  proposition-induction₂ : {ρ : Level} (P : Object → Object → Type ρ)
    → ((u v : Object) → isProp (P u v))
    → ((x y : Category.ob C) → P (object x) (object y))
    → (u v : Object) → P u v
  proposition-induction₂ P propP = R.elimProp₂ propP
