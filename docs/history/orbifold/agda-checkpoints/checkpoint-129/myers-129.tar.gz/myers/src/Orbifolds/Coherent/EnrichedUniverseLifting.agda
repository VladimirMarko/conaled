{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedUniverseLifting where

-- A strict enriched diagram with arbitrary object, hom and value
-- universes embeds by literal Lift into one common working universe.
-- All laws and all comparisons are constructed, including strict
-- action/composition computations. No resizing or equality reflection.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Orbifolds.Coherent.StrictEnriched

module Lifting {ℓo ℓh ℓx : Level} (C : Category ℓo ℓh) (D : Diagram C ℓx) where
  open Category C
  open Diagram D

  W : Level
  W = ℓ-max ℓo (ℓ-max ℓh ℓx)

  LiftedCategory : Category W W
  Category.Obj LiftedCategory = Lift {j = W} Obj
  Category.Hom LiftedCategory x y = Lift {j = W} (Hom (lower x) (lower y))
  Category.ident LiftedCategory x = lift (ident (lower x))
  Category.compose LiftedCategory g f = lift (compose (lower g) (lower f))
  Category.assoc LiftedCategory h g f = strict-cong
    (λ q → outer (lift {j = W} (inner q))) (assoc (lower h) (lower g) (lower f))
  Category.left LiftedCategory f = strict-cong
    (λ q → outer (lift {j = W} (inner q))) (left (lower f))
  Category.right LiftedCategory f = strict-cong
    (λ q → outer (lift {j = W} (inner q))) (right (lower f))

  LiftedDiagram : Diagram LiftedCategory W
  Diagram.Value LiftedDiagram x = Lift {j = W} (Value (lower x))
  Diagram.action LiftedDiagram f v = lift (action (lower f) (lower v))
  Diagram.action-compose LiftedDiagram g f = strict-cong
    (λ q → outer (λ v → lift {j = W} (inner q (lower v))))
    (action-compose (lower g) (lower f))
  Diagram.action-id LiftedDiagram x = strict-cong
    (λ q → outer (λ (v : Lift {j = W} (Value (lower x))) → lift {j = W} (inner q (lower v))))
    (action-id (lower x))

  objects-equivalence : Category.Obj LiftedCategory ≃ Obj
  objects-equivalence = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

  hom-equivalence : (x y : Category.Obj LiftedCategory)
    → Category.Hom LiftedCategory x y ≃ Hom (lower x) (lower y)
  hom-equivalence x y = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

  value-equivalence : (x : Category.Obj LiftedCategory)
    → Diagram.Value LiftedDiagram x ≃ Value (lower x)
  value-equivalence x = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

  project-identity : (x : Category.Obj LiftedCategory)
    → outer (lower (Category.ident LiftedCategory x)) ≡ˢ outer (ident (lower x))
  project-identity x = reflˢ

  project-compose : {x y z : Category.Obj LiftedCategory}
    (g : Category.Hom LiftedCategory y z) (f : Category.Hom LiftedCategory x y)
    → outer (lower (Category.compose LiftedCategory g f))
      ≡ˢ outer (compose (lower g) (lower f))
  project-compose g f = reflˢ

  project-action : {x y : Category.Obj LiftedCategory}
    (f : Category.Hom LiftedCategory x y) (v : Diagram.Value LiftedDiagram x)
    → outer (lower (Diagram.action LiftedDiagram f v))
      ≡ˢ outer (action (lower f) (lower v))
  project-action f v = reflˢ

  include-action : {x y : Obj} (f : Hom x y) (v : Value x)
    → outer (Diagram.action LiftedDiagram (lift f) (lift v))
      ≡ˢ outer (lift {j = W} (action f v))
  include-action f v = reflˢ

  include-project-object : (x : Category.Obj LiftedCategory)
    → outer (lift {j = W} (lower x)) ≡ˢ outer x
  include-project-object x = reflˢ

  project-include-object : (x : Obj) → outer (lower (lift {j = W} x)) ≡ˢ outer x
  project-include-object x = reflˢ

  include-project-hom : {x y : Category.Obj LiftedCategory}
    (f : Category.Hom LiftedCategory x y) → outer (lift {j = W} (lower f)) ≡ˢ outer f
  include-project-hom f = reflˢ

  include-project-value : (x : Category.Obj LiftedCategory)
    (v : Diagram.Value LiftedDiagram x) → outer (lift {j = W} (lower v)) ≡ˢ outer v
  include-project-value x v = reflˢ
