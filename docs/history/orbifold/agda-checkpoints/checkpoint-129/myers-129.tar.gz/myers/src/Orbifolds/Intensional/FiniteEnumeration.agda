{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteEnumeration where

-- An actual finite list cover, together with decidable equality, gives
-- an actual equivalence with a finite ordinal. The list is deduplicated
-- constructively. No enumeration or equivalence is an additional input.

open import Agda.Primitive using (Level; Set)
open import Agda.Builtin.Nat using (Nat; zero; suc)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.FiniteBranchAtlas using (Fin; fzero; fsuc)
open import Orbifolds.Intensional.TopologicalFiniteBranches using (Empty; empty-elim; Not)
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; Some; here; there; _⊎_; inl; inr; PropositionalEM )

private variable ℓ : Level

DecidableEquality : Set ℓ → Set ℓ
DecidableEquality A = (x y : A) → (x ≡ y) ⊎ Not (x ≡ y)

set-em→decidable-equality : {A : Set ℓ}
  → isSet A → PropositionalEM ℓ → DecidableEquality A
set-em→decidable-equality setA classical x y = classical (setA x y)

Member : {A : Set ℓ} → A → List A → Set ℓ
Member a xs = Some (λ x → x ≡ a) xs

Some-map : {A : Set ℓ} {P Q : A → Set ℓ} {xs : List A}
  → ((a : A) → P a → Q a) → Some P xs → Some Q xs
Some-map f (here p) = here (f _ p)
Some-map f (there p) = there (Some-map f p)

map-list : {A B : Set ℓ} → (A → B) → List A → List B
map-list f [] = []
map-list f (a ∷ xs) = f a ∷ map-list f xs

Some-map-list : {A B : Set ℓ} (f : A → B) (P : B → Set ℓ) {xs : List A}
  → Some (λ a → P (f a)) xs → Some P (map-list f xs)
Some-map-list f P (here p) = here p
Some-map-list f P (there p) = there (Some-map-list f P p)

length : {A : Set ℓ} → List A → Nat
length [] = zero
length (_ ∷ xs) = suc (length xs)

lookup : {A : Set ℓ} (xs : List A) → Fin {ℓ} (length xs) → A
lookup [] ()
lookup (a ∷ xs) fzero = a
lookup (a ∷ xs) (fsuc i) = lookup xs i

lookup-member : {A : Set ℓ} (xs : List A) (i : Fin {ℓ} (length xs))
  → Member (lookup xs i) xs
lookup-member [] ()
lookup-member (a ∷ xs) fzero = here refl
lookup-member (a ∷ xs) (fsuc i) = there (lookup-member xs i)

some-index : {A : Set ℓ} {P : A → Set ℓ} (xs : List A)
  → Some P xs → Σ (Fin {ℓ} (length xs)) (λ i → P (lookup xs i))
some-index [] ()
some-index (a ∷ xs) (here p) = fzero , p
some-index (a ∷ xs) (there p) = fsuc (fst next) , snd next
  where
  next = some-index xs p

member-index : {A : Set ℓ} (xs : List A) (a : A)
  → Member a xs → Σ (Fin {ℓ} (length xs)) (λ i → lookup xs i ≡ a)
member-index xs a = some-index xs

member? : {A : Set ℓ} → DecidableEquality A → (a : A) → (xs : List A)
  → Member a xs ⊎ Not (Member a xs)
member? equality a [] = inr (λ ())
member? equality a (x ∷ xs) with equality x a
... | inl equal = inl (here equal)
... | inr different with member? equality a xs
...   | inl present = inl (there present)
...   | inr absent = inr λ
  { (here equal) → different equal
  ; (there present) → absent present
  }

data NoDuplicates {A : Set ℓ} : List A → Set ℓ where
  unique-empty : NoDuplicates []
  unique-cons : {a : A} {xs : List A}
    → Not (Member a xs) → NoDuplicates xs → NoDuplicates (a ∷ xs)

record Deduplicated {A : Set ℓ} (xs : List A) : Set ℓ where
  constructor deduplicated
  field
    items : List A
    unique : NoDuplicates items
    retains : (a : A) → Member a xs → Member a items
    contains-only : (a : A) → Member a items → Member a xs

open Deduplicated public

deduplicate : {A : Set ℓ} → DecidableEquality A → (xs : List A) → Deduplicated xs
deduplicate equality [] = deduplicated [] unique-empty (λ a ()) (λ a ())
deduplicate equality (x ∷ xs) with deduplicate equality xs
... | deduplicated ys no-repeats retained original with member? equality x ys
...   | inl present = deduplicated ys no-repeats
  (λ a → λ
    { (here equal) → subst (λ z → Member z ys) equal present
    ; (there witness) → retained a witness
    })
  (λ a witness → there (original a witness))
...   | inr absent = deduplicated (x ∷ ys) (unique-cons absent no-repeats)
  (λ a → λ
    { (here equal) → here equal
    ; (there witness) → there (retained a witness)
    })
  (λ a → λ
    { (here equal) → here equal
    ; (there witness) → there (original a witness)
    })

lookup-injective : {A : Set ℓ} (xs : List A) → NoDuplicates xs
  → (i j : Fin {ℓ} (length xs)) → lookup xs i ≡ lookup xs j → i ≡ j
lookup-injective [] unique-empty () j equal
lookup-injective (a ∷ xs) (unique-cons absent unique) fzero fzero equal = refl
lookup-injective (a ∷ xs) (unique-cons absent unique) fzero (fsuc j) equal =
  empty-elim (absent (subst (λ z → Member z xs) (sym equal) (lookup-member xs j)))
lookup-injective (a ∷ xs) (unique-cons absent unique) (fsuc i) fzero equal =
  empty-elim (absent (subst (λ z → Member z xs) equal (lookup-member xs i)))
lookup-injective (a ∷ xs) (unique-cons absent unique) (fsuc i) (fsuc j) equal =
  cong fsuc (lookup-injective xs unique i j equal)

ListCover : {A : Set ℓ} → List A → Set ℓ
ListCover {A = A} xs = (a : A) → Member a xs

-- The inverse laws are equations of the constructed lookup and search
-- functions. Lookup injectivity proves independence of the selected
-- covering witness without assuming proof irrelevance of Some.
list-cover→finite : {A : Set ℓ} → DecidableEquality A
  → (xs : List A) → ListCover xs → Σ Nat (λ n → Equiv A (Fin {ℓ} n))
list-cover→finite {ℓ = ℓ} {A = A} equality xs cover =
  length ys , equiv encode (lookup ys) encode-lookup lookup-encode
  where
  dedup : Deduplicated xs
  dedup = deduplicate equality xs

  ys : List A
  ys = items dedup

  search : (a : A) → Σ (Fin {ℓ} (length ys)) (λ i → lookup ys i ≡ a)
  search a = member-index ys a (retains dedup a (cover a))

  encode : A → Fin {ℓ} (length ys)
  encode a = fst (search a)

  lookup-encode : (a : A) → lookup ys (encode a) ≡ a
  lookup-encode a = snd (search a)

  encode-lookup : (i : Fin {ℓ} (length ys)) → encode (lookup ys i) ≡ i
  encode-lookup i = lookup-injective ys (unique dedup)
    (encode (lookup ys i)) i (lookup-encode (lookup ys i))

em-set-list-cover→finite : {A : Set ℓ} → isSet A → PropositionalEM ℓ
  → (xs : List A) → ListCover xs → Σ Nat (λ n → Equiv A (Fin {ℓ} n))
em-set-list-cover→finite setA classical =
  list-cover→finite (set-em→decidable-equality setA classical)
