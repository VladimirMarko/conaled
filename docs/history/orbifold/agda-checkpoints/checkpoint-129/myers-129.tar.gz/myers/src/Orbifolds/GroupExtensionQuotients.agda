{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.GroupExtensionQuotients where

-- Quotient iteration along an actual surjective group homomorphism.
-- The kernel delooping is the actual homotopy fiber, and the outer
-- family is the dependent sum along the actual torsor-extension map.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Equiv.Properties
open import Cubical.Foundations.GroupoidLaws
open import Cubical.Foundations.HLevels
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.Transport
open import Cubical.Data.Sigma
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties using (makeIsGroupHom)
open import Cubical.Algebra.Group.Subgroup using (kerGroup)
open import Cubical.Functions.Surjection using (isSurjection)
import Cubical.HITs.PropositionalTruncation as PT
import Orbifolds.Quotients as Q
import Orbifolds.EquivariantBundles as EB
import Orbifolds.DeloopedKernels as DK
open import Orbifolds.SubgroupDeloopingModels using (conjugate-multiplication)

module Along {ℓ : Level} (G H : Group ℓ) (φ : GroupHom G H)
  (surjective : isSurjection (φ .fst)) where
  module K = DK.Along G H φ surjective
  module GT = K.GT
  module HT = K.HT
  module E = K.E
  module GS = GroupStr (G .snd)
  module HS = GroupStr (H .snd)
  module KS = GroupStr (kerGroup φ .snd)

  outer-delooping : Q.Delooping (ℓ-suc ℓ)
  Q.BG outer-delooping = HT.Torsor
  Q.point outer-delooping = E.Extend GT.regular-torsor
  Q.connected outer-delooping t = PT.map (E.pointing ∙_) (HT.torsor-connected t)

  outer-loop-group : Group (ℓ-suc ℓ)
  outer-loop-group = makeGroup refl _∙_ sym
    (HT.torsor-groupoid (Q.point outer-delooping) (Q.point outer-delooping))
    assoc (λ p → sym (rUnit p)) (λ p → sym (lUnit p)) rCancel lCancel

  outer-coordinate : Q.Loop outer-delooping → H .fst
  outer-coordinate p = HT.transport-point HT.regular-torsor
    (equivFun (conjugatePathEquiv E.pointing) p)

  abstract
    outer-coordinate-isEquiv : isEquiv outer-coordinate
    outer-coordinate-isEquiv = compEquiv (conjugatePathEquiv E.pointing)
      (HT.transport-identifications HT.regular-torsor) .snd

    source-coordinate-isEquiv : isEquiv (GT.transport-point GT.regular-torsor)
    source-coordinate-isEquiv = GT.transport-identifications GT.regular-torsor .snd

    kernel-coordinate-isEquiv : isEquiv (K.loop≃algebraic-kernel .fst)
    kernel-coordinate-isEquiv = K.loop≃algebraic-kernel .snd

  outer-loop-equivalence : Q.Loop outer-delooping ≃ H .fst
  outer-loop-equivalence = outer-coordinate , outer-coordinate-isEquiv

  source-loop-equivalence : (GT.regular-torsor ≡ GT.regular-torsor) ≃ G .fst
  source-loop-equivalence = GT.transport-point GT.regular-torsor , source-coordinate-isEquiv

  kernel-loop-equivalence : Q.Loop K.kernel-delooping ≃ Ker φ
  kernel-loop-equivalence = K.loop≃algebraic-kernel .fst , kernel-coordinate-isEquiv

  outer-loop-group-equivalence : GroupEquiv outer-loop-group H
  outer-loop-group-equivalence = outer-loop-equivalence , makeIsGroupHom
    (λ p q → cong (HT.transport-point HT.regular-torsor)
      (conjugate-multiplication E.pointing p q)
      ∙ HT.loop-evaluation-multiply
        (equivFun (conjugatePathEquiv E.pointing) p)
        (equivFun (conjugatePathEquiv E.pointing) q))

  normal-loop : Ker φ → Q.Loop K.kernel-delooping
  normal-loop n = invEq kernel-loop-equivalence (KS.inv n)

  module Action (A : GT.Action) where
    X = GT.Carrier A
    module F = EB.Theory.Action G A

    Inner : HT.Torsor → Type (ℓ-suc ℓ)
    Inner h = Σ[ z ∈ fiber E.Extend h ] F.Bundle (z .fst)

    module Outer = Q.FamilyAction outer-delooping Inner
    module Normal = Q.FamilyAction K.kernel-delooping (λ z → F.Bundle (z .fst))

    iterated-fiber : Outer.Fibre ≡ Normal.Quotient
    iterated-fiber = refl

    iterated-quotient≃original-quotient : Outer.Quotient ≃ F.Family.Quotient
    iterated-quotient≃original-quotient = isoToEquiv (iso
      (λ (h , (t , p) , x) → t , x)
      (λ (t , x) → E.Extend t , (t , refl) , x)
      (λ _ → refl)
      (λ (h , (t , p) , x) i → p i , (t , (λ j → p (i ∧ j))) , x))

    normal-orbit : X → Normal.Quotient
    normal-orbit x = Normal.quotient (F.orbit x)

    iterated-orbit : X → Outer.Quotient
    iterated-orbit x = Outer.quotient (normal-orbit x)

    original-orbit : X → F.Family.Quotient
    original-orbit x = F.Family.quotient (F.orbit x)

    quotient-triangle : (x : X)
      → iterated-quotient≃original-quotient .fst (iterated-orbit x) ≡ original-orbit x
    quotient-triangle x = refl

    abstract
      normal-loop-in-source : (n : Ker φ)
        → cong fst (normal-loop n) ≡ F.group-loop (n .fst)
      normal-loop-in-source n = invEq (congEquiv source-loop-equivalence)
        (sym (K.loop-coordinate-projection (normal-loop n))
        ∙ cong fst (secEq kernel-loop-equivalence (KS.inv n))
        ∙ sym (secEq (GT.transport-identifications GT.regular-torsor) (GS.inv (n .fst))))

      normal-action-transport : (n : Ker φ) (x : X)
        → F.evaluate (Normal.act (normal-loop n) (F.orbit x)) ≡ GT.act A (n .fst) x
      normal-action-transport n x =
        cong (λ p → F.evaluate (subst F.Bundle p (F.orbit x))) (normal-loop-in-source n)
        ∙ F.action-transport (n .fst) x

    module Split (σ : GroupHom H G) (splitting : (h : H .fst) → φ .fst (σ .fst h) ≡ h) where

      outer-loop : H .fst → Q.Loop outer-delooping
      outer-loop h = cong E.Extend (F.group-loop (σ .fst h))

      abstract
        outer-loop-coordinate : (h : H .fst)
          → outer-loop-equivalence .fst (outer-loop h) ≡ HS.inv h
        outer-loop-coordinate h = K.Hom.element-computation (GS.inv (σ .fst h))
          ∙ IsGroupHom.presinv (φ .snd) (σ .fst h)
          ∙ cong HS.inv (splitting h)

        split-action-transport : (h : H .fst) (x : X)
          → subst F.Bundle (F.group-loop (σ .fst h)) (F.orbit x)
            ≡ F.orbit (GT.act A (σ .fst h) x)
        split-action-transport h x =
          sym (F.orbit-evaluate (subst F.Bundle (F.group-loop (σ .fst h)) (F.orbit x)))
          ∙ cong F.orbit (F.action-transport (σ .fst h) x)

        outer-action-on-orbits : (h : H .fst) (x : X)
          → Outer.act (outer-loop h) (normal-orbit x)
            ≡ normal-orbit (GT.act A (σ .fst h) x)
        outer-action-on-orbits h x =
          substCommSlice F.Bundle (Inner ∘ E.Extend)
            (λ t v → (t , refl) , v) (F.group-loop (σ .fst h)) (F.orbit x)
          ∙ cong Normal.quotient (split-action-transport h x)
