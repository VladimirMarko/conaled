{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.StrictImagePaths where

-- The exact generic final-edge construction shared by finite triangles
-- and their prefix computation, independent of any chosen cell map.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched
  using (Outer; outer; inner; _≡ˢ_; strict-to-path; strict-sym; strict-cong)

strict-image-sym-path : {ℓ ℓ′ : Level} (A : Type ℓ) (B : Type ℓ′)
  (k : A → B) (x y : A) → outer x ≡ˢ outer y → k y ≡ k x
strict-image-sym-path A B k x y r =
  strict-to-path {A = B} {x = k y} {y = k x}
    (strict-sym {A = Outer B} {x = outer (k x)} {y = outer (k y)}
      (strict-cong {A = Outer A} {B = Outer B}
        (λ s → outer (k (inner s))) {x = outer x} {y = outer y} r))
