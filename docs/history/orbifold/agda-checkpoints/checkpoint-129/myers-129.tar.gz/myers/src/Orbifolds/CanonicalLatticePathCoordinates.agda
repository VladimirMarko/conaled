{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CanonicalLatticePathCoordinates where

-- The scalar coordinate of an actual canonical-lattice identity
-- computes the transport of every vector. This proves the inverse
-- path's line projection without normalizing a concrete SIP inverse.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.Module.Base
import Orbifolds.SyntheticField as SF
import Orbifolds.SyntheticOrder as SO
import Orbifolds.CanonicalLatticeIdentities as LI
import Orbifolds.LineTransportIdentities as LT

module Geometry {ℓ : Level} (R : CommRing ℓ)
    (kock : SF.RingContext.KockField R)
    (order : SF.RingContext.StrictOrder R)
    (compatibility : SO.OrderTheory.OrderedRingCompatibility R order) where
  module Id = LI.Geometry R kock order compatibility
  module Lines = Id.Lines
  module C = Id.C
  module LinePaths = LT.Ring C.ComplexRing

  module At (Λ Γ : Id.Moduli.FiniteFreeLattice Lines.canonical-line) where
    module Coordinates = Id.Canonical Λ Γ

    scalar-path : (u : Lines.Unit) (preserves : Coordinates.ScalarPreserves u)
      → Path Id.Moduli.FiniteFreeModuli (Lines.canonical-line , Λ) (Lines.canonical-line , Γ)
    scalar-path u preserves = invEq Coordinates.scalar-identities (u , preserves)

    decoded : (u : Lines.Unit) (preserves : Coordinates.ScalarPreserves u)
      → LeftModuleEquiv Lines.standard Lines.standard
    decoded u preserves = Id.identities {Lines.canonical-line} {Lines.canonical-line} Λ Γ
      .fst (scalar-path u preserves) .fst

    coefficient : (u : Lines.Unit) (preserves : Coordinates.ScalarPreserves u)
      → decoded u preserves .fst .fst C.one ≡ u .fst
    coefficient u preserves = cong
      (λ (a : Σ[ v ∈ Lines.Unit ] Coordinates.ScalarPreserves v) → a .fst .fst)
      (secEq Coordinates.scalar-identities (u , preserves))

    scalar-path-line : (u : Lines.Unit) (preserves : Coordinates.ScalarPreserves u)
      → cong fst (scalar-path u preserves) ≡ Lines.unit-loop u
    scalar-path-line u preserves = LinePaths.Between.equal-by-transport
      Lines.canonical-line Lines.canonical-line
      (cong fst (scalar-path u preserves)) (Lines.unit-loop u) λ z →
      cong (λ p → subst Lines.Carrier p z)
        (sym (Id.identity-line-coordinate {Lines.canonical-line} {Lines.canonical-line}
          Λ Γ (scalar-path u preserves)))
      ∙ Lines.line-path-transport Lines.canonical-line Lines.canonical-line (decoded u preserves) z
      ∙ Lines.hom-is-scaling (decoded u preserves .fst .fst , decoded u preserves .snd) z
      ∙ cong (λ (a : C.Complex) → a C.*c z) (coefficient u preserves)
      ∙ sym (Lines.unit-loop-transport u z)
