{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.ActionGroupoids where

-- Actual labelled action arrows. The group and action equations construct
-- composition and inverses; no quotient or effectivity datum is assumed.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
import Orbifolds.Intensional.CategoricalTransfer as Cat
open import Orbifolds.Intensional.TopologicalFiniteBranches using (Product)

ActionHom : {ℓ : Level} {G X : Set ℓ} → (G → X → X) → X → X → Set ℓ
ActionHom {G = G} act x y = Σ G (λ g → act g x ≡ y)

module Action {ℓ : Level} {G X : Set ℓ}
    (setG : isSet G) (setX : isSet X)
    (unit : G) (multiply : G → G → G) (inverse : G → G)
    (unit-left : (g : G) → multiply unit g ≡ g)
    (unit-right : (g : G) → multiply g unit ≡ g)
    (multiply-associative : (g h k : G)
      → multiply (multiply g h) k ≡ multiply g (multiply h k))
    (inverse-left : (g : G) → multiply (inverse g) g ≡ unit)
    (inverse-right : (g : G) → multiply g (inverse g) ≡ unit)
    (act : G → X → X)
    (act-unit : (x : X) → act unit x ≡ x)
    (act-multiply : (g h : G) (x : X)
      → act (multiply g h) x ≡ act g (act h x)) where

  Hom : X → X → Set ℓ
  Hom = ActionHom act

  hom-ext : {x y : X} {f g : Hom x y} → fst f ≡ fst g → f ≡ g
  hom-ext {x} {y} = Σ-path-prop (λ g → setX (act g x) y)

  hom-set : (x y : X) → isSet (Hom x y)
  hom-set x y = isSetΣProp setG (λ g → setX (act g x) y)

  identity : {x : X} → Hom x x
  identity {x} = unit , act-unit x

  compose : {x y z : X} → Hom y z → Hom x y → Hom x z
  compose {x} (h , q) (g , p) = multiply h g ,
    act-multiply h g x ∙ cong (act h) p ∙ q

  identity-left : {x y : X} (f : Hom x y)
    → compose {x} {y} {y} (identity {y}) f ≡ f
  identity-left {x} {y} (g , p) = hom-ext {x} {y} (unit-left g)

  identity-right : {x y : X} (f : Hom x y)
    → compose {x} {x} {y} f (identity {x}) ≡ f
  identity-right {x} {y} (g , p) = hom-ext {x} {y} (unit-right g)

  associative : {w x y z : X}
    (h : Hom y z) (g : Hom x y) (f : Hom w x)
    → compose {w} {x} {z} (compose {x} {y} {z} h g) f
      ≡ compose {w} {y} {z} h (compose {w} {x} {y} g f)
  associative {w} {x} {y} {z} (h , r) (g , q) (f , p) =
    hom-ext {w} {z} (multiply-associative h g f)

  category : Cat.Category ℓ ℓ
  Cat.Category.Obj category = X
  Cat.Category.Hom category = Hom
  Cat.Category.hom-set category = hom-set
  Cat.Category.identity category {X = x} = identity {x}
  Cat.Category.compose category {X = x} {Y = y} {Z = z} = compose {x} {y} {z}
  Cat.Category.identity-left category {X = x} {Y = y} = identity-left {x} {y}
  Cat.Category.identity-right category {X = x} {Y = y} = identity-right {x} {y}
  Cat.Category.associative category {W = w} {X = x} {Y = y} {Z = z} =
    associative {w} {x} {y} {z}

  act-inverse-left : (g : G) (x : X) → act (inverse g) (act g x) ≡ x
  act-inverse-left g x = sym (act-multiply (inverse g) g x)
    ∙ cong (λ h → act h x) (inverse-left g) ∙ act-unit x

  act-inverse-right : (g : G) (x : X) → act g (act (inverse g) x) ≡ x
  act-inverse-right g x = sym (act-multiply g (inverse g) x)
    ∙ cong (λ h → act h x) (inverse-right g) ∙ act-unit x

  inverse-arrow : {x y : X} → Hom x y → Hom y x
  inverse-arrow {x} (g , p) = inverse g ,
    cong (act (inverse g)) (sym p) ∙ act-inverse-left g x

  inverse-right-law : {x y : X} (f : Hom x y)
    → compose {y} {x} {y} f (inverse-arrow {x} {y} f) ≡ identity {y}
  inverse-right-law {x} {y} (g , p) = hom-ext {y} {y} (inverse-right g)

  inverse-left-law : {x y : X} (f : Hom x y)
    → compose {x} {y} {x} (inverse-arrow {x} {y} f) f ≡ identity {x}
  inverse-left-law {x} {y} (g , p) = hom-ext {x} {x} (inverse-left g)

  arrow-is-iso : {x y : X} (f : Hom x y) → Cat.IsIso category {X = x} {Y = y} f
  Cat.IsIso.inverse-arrow (arrow-is-iso {x} {y} f) = inverse-arrow {x} {y} f
  Cat.IsIso.right-inverse (arrow-is-iso {x} {y} f) = inverse-right-law {x} {y} f
  Cat.IsIso.left-inverse (arrow-is-iso {x} {y} f) = inverse-left-law {x} {y} f

  arrow-iso : {x y : X} → Hom x y → Cat.Iso category x y
  arrow-iso {x} {y} f = Cat.arrowIso f (arrow-is-iso {x} {y} f)

  -- This is the total space of the categorical hom-family, not a new
  -- arrow space postulated to have the desired coordinates.
  ArrowSpace : Set ℓ
  ArrowSpace = Σ X (λ x → Σ X (λ y → Hom x y))

  source target : ArrowSpace → X
  source a = fst a
  target a = fst (snd a)

  coordinates : ArrowSpace → Product G X
  coordinates (x , y , g , p) = g , x

  from-coordinates : Product G X → ArrowSpace
  from-coordinates (g , x) = x , act g x , g , refl

  coordinates-section : (z : Product G X)
    → coordinates (from-coordinates z) ≡ z
  coordinates-section (g , x) = refl

  coordinates-retraction : (a : ArrowSpace)
    → from-coordinates (coordinates a) ≡ a
  coordinates-retraction (x , y , g , p) =
    J (λ z q → from-coordinates (g , x) ≡ (x , z , g , q)) refl p

  arrow-space-equivalence : Equiv ArrowSpace (Product G X)
  arrow-space-equivalence = equiv coordinates from-coordinates
    coordinates-section coordinates-retraction

  source-coordinates : (a : ArrowSpace) → source a ≡ snd (coordinates a)
  source-coordinates (x , y , g , p) = refl

  target-coordinates : (a : ArrowSpace)
    → target a ≡ act (fst (coordinates a)) (snd (coordinates a))
  target-coordinates (x , y , g , p) = sym p

  anchor : ArrowSpace → Product X X
  anchor a = source a , target a

  anchor-from-coordinates : (z : Product G X)
    → anchor (from-coordinates z) ≡ (snd z , act (fst z) (snd z))
  anchor-from-coordinates (g , x) = refl

  -- Labels are recovered exactly. Distinct stabilizer labels are not
  -- identified merely because they act identically on the object space.
  label-path : {x y : X} {f g : Hom x y} → f ≡ g → fst f ≡ fst g
  label-path = cong fst

  stabilizer : X → Set ℓ
  stabilizer x = Hom x x
