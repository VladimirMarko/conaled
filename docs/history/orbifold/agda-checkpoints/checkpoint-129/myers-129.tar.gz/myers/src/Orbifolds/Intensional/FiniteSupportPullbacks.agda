{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportPullbacks where

-- Finite-support scalar coordinates preserve actual pullbacks. Support
-- is a small double-negated finite-list witness, hence a proposition.
-- The pullback proof does not choose a support or assume preservation.
-- In classical sets this is the usual finite-support condition.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.Equivalence using
  ( isEquiv; equiv→isEquiv; isEquiv→Equiv; comp-isEquiv; homotopy-isEquiv )
open import Orbifolds.Intensional.TopologicalFiniteBranches using
  ( Empty; Not; not-prop )
open import Orbifolds.Intensional.CompactSeparation using
  ( List; []; _∷_; Some; here; there )
open import Orbifolds.Intensional.FiniteEnumeration using (Member)

private variable ℓ : Level

path-left-cancel : {A : Set ℓ} {x y z : A} (p : x ≡ y)
  → {q r : y ≡ z} → p ∙ q ≡ p ∙ r → q ≡ r
path-left-cancel refl equal = equal

-- Raw ext need not send the reflexive homotopy to refl. Identity
-- elimination still determines its value on every happly p up to that
-- same fixed loop, which is enough to prove sethood of function types.
ext-path-shift : (ext : FunExt ℓ ℓ) {A : Set ℓ} {B : A → Set ℓ}
  → {f g : (x : A) → B x} → (p : f ≡ g)
  → ext (λ x → cong (λ h → h x) p)
      ≡ ext (λ x → refl {x = f x}) ∙ p
ext-path-shift ext refl = sym (∙-right-unit (ext (λ x → refl)))

function-isSet : (ext : FunExt ℓ ℓ) {A : Set ℓ} {B : A → Set ℓ}
  → ((x : A) → isSet (B x)) → isSet ((x : A) → B x)
function-isSet ext sets f g p q = path-left-cancel (ext (λ x → refl))
  (sym (ext-path-shift ext p)
    ∙ cong ext (ext (λ x → sets x (f x) (g x)
        (cong (λ h → h x) p) (cong (λ h → h x) q)))
    ∙ ext-path-shift ext q)

infixr 5 _++_
_++_ : {A : Set ℓ} → List A → List A → List A
[] ++ ys = ys
(x ∷ xs) ++ ys = x ∷ (xs ++ ys)

member-append-left : {A : Set ℓ} {a : A} {xs ys : List A}
  → Member a xs → Member a (xs ++ ys)
member-append-left (here p) = here p
member-append-left (there p) = there (member-append-left p)

member-append-right : {A : Set ℓ} {a : A} (xs : List A) {ys : List A}
  → Member a ys → Member a (xs ++ ys)
member-append-right [] p = p
member-append-right (x ∷ xs) p = there (member-append-right xs p)

NN : Set ℓ → Set ℓ
NN P = Not (Not P)

nn-unit : {A : Set ℓ} → A → NN A
nn-unit a reject = reject a

nn-map : {A B : Set ℓ} → (A → B) → NN A → NN B
nn-map f witness reject = witness (λ a → reject (f a))

nn-map₂ : {A B C : Set ℓ} → (A → B → C) → NN A → NN B → NN C
nn-map₂ f first second reject = first (λ a → second (λ b → reject (f a b)))

SupportBound : {I A : Set ℓ} → A → (I → A) → List I → Set ℓ
SupportBound {I = I} zero f indices =
  (i : I) → Not (Member i indices) → f i ≡ zero

SupportWitness : {I A : Set ℓ} → A → (I → A) → Set ℓ
SupportWitness {I = I} zero f = Σ (List I) (SupportBound zero f)

Supported : {I A : Set ℓ} → A → (I → A) → Set ℓ
Supported zero f = NN (SupportWitness zero f)

FiniteSupport : (I : Set ℓ) {A : Set ℓ} → A → Set ℓ
FiniteSupport I zero = Σ (I → _) (Supported zero)

supported-prop : (ext : FunExt ℓ ℓ) {I A : Set ℓ} (zero : A) (f : I → A)
  → isProp (Supported zero f)
supported-prop ext zero f = not-prop ext (Not (SupportWitness zero f))

finite-support-path : (ext : FunExt ℓ ℓ) {I A : Set ℓ} {zero : A}
  → {u v : FiniteSupport I zero} → fst u ≡ fst v → u ≡ v
finite-support-path ext = Σ-path-prop (supported-prop ext _)

finite-support-isSet : (ext : FunExt ℓ ℓ) {I A : Set ℓ} {zero : A}
  → isSet A → isSet (FiniteSupport I zero)
finite-support-isSet ext setA =
  isSetΣProp (function-isSet ext (λ _ → setA)) (supported-prop ext _)

zero-support : {I A : Set ℓ} → (zero : A) → FiniteSupport I zero
zero-support zero = (λ _ → zero) , nn-unit ([] , λ i absent → refl)

map-support-witness : {I A B : Set ℓ} {zeroA : A} {zeroB : B}
  → (f : A → B) → f zeroA ≡ zeroB → (u : I → A)
  → SupportWitness zeroA u → SupportWitness zeroB (λ i → f (u i))
map-support-witness f at-zero u (indices , bound) = indices ,
  (λ i absent → cong f (bound i absent) ∙ at-zero)

map-finite-support : {I A B : Set ℓ} {zeroA : A} {zeroB : B}
  → (f : A → B) → f zeroA ≡ zeroB
  → FiniteSupport I zeroA → FiniteSupport I zeroB
map-finite-support f at-zero (u , supported) = (λ i → f (u i)) ,
  nn-map (map-support-witness f at-zero u) supported

map-finite-support-equivalence : (ext : FunExt ℓ ℓ)
  → {I A B : Set ℓ} {zeroA : A} {zeroB : B}
  → (e : Equiv A B) → forward e zeroA ≡ zeroB
  → Equiv (FiniteSupport I zeroA) (FiniteSupport I zeroB)
map-finite-support-equivalence ext {zeroA = zeroA} e at-zero = equiv
  (map-finite-support (forward e) at-zero)
  (map-finite-support (backward e)
    (cong (backward e) (sym at-zero) ∙ retraction e zeroA))
  (λ v → finite-support-path ext (ext (λ i → section e (fst v i))))
  (λ u → finite-support-path ext (ext (λ i → retraction e (fst u i))))

Pullback : {A B C : Set ℓ} → (A → C) → (B → C) → Set ℓ
Pullback {A = A} {B = B} f g = Σ A (λ a → Σ B (λ b → g b ≡ f a))

pullback-path : {A B C : Set ℓ} {f : A → C} {g : B → C}
  → isSet C → {u v : Pullback f g}
  → fst u ≡ fst v → fst (snd u) ≡ fst (snd v) → u ≡ v
pullback-path {f = f} {g = g} setC
    {u = a , (b , p)} {v = .a , (.b , q)} refl refl =
  cong (λ r → a , (b , r)) (setC (g b) (f a) p q)

module Preservation {ℓ : Level} {I A B C : Set ℓ}
    (ext : FunExt ℓ ℓ)
    (zeroA : A) (zeroB : B) (zeroC : C) (setC : isSet C)
    (f : A → C) (g : B → C)
    (f-zero : f zeroA ≡ zeroC) (g-zero : g zeroB ≡ zeroC) where

  P : Set ℓ
  P = Pullback f g

  zeroP : P
  zeroP = zeroA , (zeroB , g-zero ∙ sym f-zero)

  FS-A = FiniteSupport I zeroA
  FS-B = FiniteSupport I zeroB
  FS-C = FiniteSupport I zeroC
  FS-P = FiniteSupport I zeroP

  extended-f : FS-A → FS-C
  extended-f = map-finite-support f f-zero

  extended-g : FS-B → FS-C
  extended-g = map-finite-support g g-zero

  ExtendedPullback : Set ℓ
  ExtendedPullback = Pullback extended-f extended-g

  comparison : FS-P → ExtendedPullback
  comparison u =
    map-finite-support fst refl u ,
    (map-finite-support (λ z → fst (snd z)) refl u ,
      finite-support-path ext (ext (λ i → snd (snd (fst u i)))))

  assemble-values : ExtendedPullback → I → P
  assemble-values z i = fst (fst z) i ,
    (fst (fst (snd z)) i , cong (λ w → fst w i) (snd (snd z)))

  assemble-support : (z : ExtendedPullback)
    → SupportWitness zeroA (fst (fst z))
    → SupportWitness zeroB (fst (fst (snd z)))
    → SupportWitness zeroP (assemble-values z)
  assemble-support z (xs , bound-x) (ys , bound-y) = xs ++ ys ,
    (λ i absent → pullback-path setC
      (bound-x i (λ present → absent (member-append-left present)))
      (bound-y i (λ present → absent (member-append-right xs present))))

  assemble : ExtendedPullback → FS-P
  assemble z = assemble-values z , nn-map₂ (assemble-support z)
    (snd (fst z)) (snd (fst (snd z)))

  comparison-assemble : (z : ExtendedPullback) → comparison (assemble z) ≡ z
  comparison-assemble z = pullback-path (finite-support-isSet ext setC)
    (finite-support-path ext refl) (finite-support-path ext refl)

  assemble-comparison : (u : FS-P) → assemble (comparison u) ≡ u
  assemble-comparison u = finite-support-path ext
    (ext (λ i → pullback-path setC refl refl))

  comparison-equivalence : Equiv FS-P ExtendedPullback
  comparison-equivalence = equiv comparison assemble comparison-assemble assemble-comparison

  comparison-isEquiv : isEquiv comparison
  comparison-isEquiv = equiv→isEquiv comparison-equivalence

-- If a specified pointed square is a pullback before extension, its
-- actual coordinatewise extension is a pullback as well. The input
-- equivalence concerns only the original square, not its extension.
module Square {ℓ : Level} {I A B C D : Set ℓ}
    (ext : FunExt ℓ ℓ)
    (zeroA : A) (zeroB : B) (zeroC : C) (zeroD : D) (setC : isSet C)
    (f : A → C) (g : B → C) (u : D → A) (v : D → B)
    (f-zero : f zeroA ≡ zeroC) (g-zero : g zeroB ≡ zeroC)
    (u-zero : u zeroD ≡ zeroA) (v-zero : v zeroD ≡ zeroB)
    (commute : (d : D) → g (v d) ≡ f (u d)) where

  module P = Preservation {I = I} ext zeroA zeroB zeroC setC f g f-zero g-zero

  comparison : D → Pullback f g
  comparison d = u d , (v d , commute d)

  comparison-zero : comparison zeroD ≡ P.zeroP
  comparison-zero = pullback-path setC u-zero v-zero

  extended-u : FiniteSupport I zeroD → P.FS-A
  extended-u = map-finite-support u u-zero

  extended-v : FiniteSupport I zeroD → P.FS-B
  extended-v = map-finite-support v v-zero

  extended-comparison : FiniteSupport I zeroD → P.ExtendedPullback
  extended-comparison w = extended-u w , (extended-v w ,
    finite-support-path ext (ext (λ i → commute (fst w i))))

  factor : FiniteSupport I zeroD → P.ExtendedPullback
  factor w = P.comparison (map-finite-support comparison comparison-zero w)

  factor-computation : (w : FiniteSupport I zeroD) → factor w ≡ extended-comparison w
  factor-computation w = pullback-path (finite-support-isSet ext setC)
    (finite-support-path ext refl) (finite-support-path ext refl)

  extended-comparison-isEquiv : isEquiv comparison → isEquiv extended-comparison
  extended-comparison-isEquiv original =
    homotopy-isEquiv factor extended-comparison factor-computation
      (comp-isEquiv (map-finite-support comparison comparison-zero) P.comparison
        (equiv→isEquiv (map-finite-support-equivalence ext
          (isEquiv→Equiv comparison original) comparison-zero)) P.comparison-isEquiv)
