{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.FiniteSupportTensorAlgebra where

-- Multiplication is constructed by two uses of the actual
-- tensor universal property. The final BasedAlgebras module supplies
-- that property from BasedExtension; no algebra structure on its
-- coordinate carrier and no algebra-preservation conclusion is input.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Identity
open import Orbifolds.Intensional.TopologicalFiniteBranches using (PropositionalDNE)
open import Orbifolds.Intensional.FiniteEnumeration using (DecidableEquality)
open import Orbifolds.Intensional.FiniteSupportSums using (cong₂)
open import Orbifolds.Intensional.FiniteSupportModules
open import Orbifolds.Intensional.FiniteSupportTensor
open import Orbifolds.Intensional.FiniteSupportScalarExtension
open import Orbifolds.Intensional.LinearHomSemimodule
open import Orbifolds.Intensional.CommutativeAlgebraCore

private variable ℓ : Level

postcompose-bilinear : {R : CommutativeSemiring ℓ}
  {L M N P : Semimodule R} → LinearMap N P → BilinearMap L M N → BilinearMap L M P
postcompose-bilinear {L = L} {M = M} {N = N} {P = P} h b =
  (λ u v → fst h (fst b u v)) ,
    ((λ v → snd (compose-linear {M = L} {N = N} {P = P} h
      (bilinear-left {L = L} {M = M} {N = N} b v))) ,
     (λ u → snd (compose-linear {M = M} {N = N} {P = P} h
      (bilinear-right {L = L} {M = M} {N = N} b u))))

precompose-bilinear : {R : CommutativeSemiring ℓ}
  {L M L' M' N : Semimodule R} → LinearMap L' L → LinearMap M' M
  → BilinearMap L M N → BilinearMap L' M' N
precompose-bilinear {L = L} {M = M} {L' = L'} {M' = M'} {N = N} f g b =
  (λ u v → fst b (fst f u) (fst g v)) ,
    ((λ v → snd (compose-linear {M = L'} {N = L} {P = N}
      (bilinear-left {L = L} {M = M} {N = N} b (fst g v)) f)) ,
     (λ u → snd (compose-linear {M = M'} {N = M} {P = N}
      (bilinear-right {L = L} {M = M} {N = N} b (fst f u)) g)))

swap-bilinear : {R : CommutativeSemiring ℓ} {L M N : Semimodule R}
  → BilinearMap L M N → BilinearMap M L N
swap-bilinear b = (λ v u → fst b u v) , (snd (snd b) , fst (snd b))

module Construction {ℓ : Level} (ext : FunExt ℓ ℓ) {R : CommutativeSemiring ℓ}
    (A W : CommutativeAlgebra R) (T : Semimodule R)
    (pure-bilinear : BilinearMap (CommutativeAlgebra.moduleR A) (CommutativeAlgebra.moduleR W) T)
    (universal : (N : Semimodule R) → Equiv (LinearMap T N)
      (BilinearMap (CommutativeAlgebra.moduleR A) (CommutativeAlgebra.moduleR W) N))
    (forward-on-pure : (N : Semimodule R) (h : LinearMap T N)
      (a : CommutativeAlgebra.Carrier A) (w : CommutativeAlgebra.Carrier W)
      → fst (forward (universal N) h) a w ≡ fst h (fst pure-bilinear a w)) where

  private module A = CommutativeAlgebra A
  private module W = CommutativeAlgebra W
  private module AS = CommutativeSemiring A.semiring
  private module WS = CommutativeSemiring W.semiring
  private module T = Semimodule T

  pure : A.Carrier → W.Carrier → T.Carrier
  pure = fst pure-bilinear

  pure-left : W.Carrier → LinearMap A.moduleR T
  pure-left = bilinear-left {L = A.moduleR} {M = W.moduleR} {N = T} pure-bilinear

  pure-right : A.Carrier → LinearMap W.moduleR T
  pure-right = bilinear-right {L = A.moduleR} {M = W.moduleR} {N = T} pure-bilinear

  module Universal (N : Semimodule R) where

    extension : BilinearMap A.moduleR W.moduleR N → LinearMap T N
    extension = backward (universal N)

    abstract
      on-pure : (b : BilinearMap A.moduleR W.moduleR N)
        (a : A.Carrier) (w : W.Carrier) → fst (extension b) (pure a w) ≡ fst b a w
      on-pure b a w = sym (forward-on-pure N (extension b) a w)
        ∙ cong (λ c → fst c a w) (section (universal N) b)

      determined-on-pure : (h k : LinearMap T N)
        → ((a : A.Carrier) (w : W.Carrier) → fst h (pure a w) ≡ fst k (pure a w))
        → h ≡ k
      determined-on-pure h k same = sym (retraction (universal N) h)
        ∙ cong (backward (universal N))
          (bilinear-path ext {L = A.moduleR} {M = W.moduleR} {N = N}
            {b = forward (universal N) h} {c = forward (universal N) k}
            (ext (λ a → ext (λ w → forward-on-pure N h a w
              ∙ same a w ∙ sym (forward-on-pure N k a w)))))
        ∙ retraction (universal N) k

    same-at : (h k : LinearMap T N)
      → ((a : A.Carrier) (w : W.Carrier) → fst h (pure a w) ≡ fst k (pure a w))
      → (t : T.Carrier) → fst h t ≡ fst k t
    same-at h k same t = cong (λ f → fst f t) (determined-on-pure h k same)

    bilinear-same-at : (h k : BilinearMap T T N)
      → ((a b : A.Carrier) (v w : W.Carrier)
          → fst h (pure a v) (pure b w) ≡ fst k (pure a v) (pure b w))
      → (s t : T.Carrier) → fst h s t ≡ fst k s t
    bilinear-same-at h k same s t = same-at
      (bilinear-left {L = T} {M = T} {N = N} h t)
      (bilinear-left {L = T} {M = T} {N = N} k t)
      (λ a v → same-at
        (bilinear-right {L = T} {M = T} {N = N} h (pure a v))
        (bilinear-right {L = T} {M = T} {N = N} k (pure a v))
        (λ b w → same a b v w) t) s

  module U = Universal T
  module End = Hom ext T T

  elementary : A.Carrier → W.Carrier → BilinearMap A.moduleR W.moduleR T
  elementary a w = (λ b z → pure (a A.* b) (w W.* z)) ,
    ((λ z → snd (compose-linear {M = A.moduleR} {N = A.moduleR} {P = T}
      (pure-left (w W.* z)) (A.left-multiply a))) ,
     (λ b → snd (compose-linear {M = W.moduleR} {N = W.moduleR} {P = T}
      (pure-right (a A.* b)) (W.left-multiply w))))

  pure-operator : A.Carrier → W.Carrier → LinearMap T T
  pure-operator a w = U.extension (elementary a w)

  operator-on-pure : (a b : A.Carrier) (w z : W.Carrier)
    → fst (pure-operator a w) (pure b z) ≡ pure (a A.* b) (w W.* z)
  operator-on-pure a b w z = U.on-pure (elementary a w) b z

  operator-left : (w : W.Carrier) → LinearMap A.moduleR End.hom-module
  operator-left w = (λ a → pure-operator a w) ,
    ((U.determined-on-pure (pure-operator A.zero w) End.zero-map
      (λ b z → operator-on-pure A.zero b w z
        ∙ cong (λ a → pure a (w W.* z)) (AS.*-zero-left b)
        ∙ linear-zero {M = A.moduleR} {N = T} (pure-left (w W.* z))) ,
      λ a b → U.determined-on-pure (pure-operator (a A.+ b) w)
        (End.add-map (pure-operator a w) (pure-operator b w))
        (λ c z → operator-on-pure (a A.+ b) c w z
          ∙ cong (λ q → pure q (w W.* z)) (AS.*-add-left a b c)
          ∙ linear-add {M = A.moduleR} {N = T} (pure-left (w W.* z)) (a A.* c) (b A.* c)
          ∙ cong₂ T._+_ (sym (operator-on-pure a c w z)) (sym (operator-on-pure b c w z)))) ,
      λ r a → U.determined-on-pure (pure-operator (r A.• a) w)
        (End.scale-map r (pure-operator a w))
        (λ b z → operator-on-pure (r A.• a) b w z
          ∙ cong (λ q → pure q (w W.* z))
            (linear-scalar {M = A.moduleR} {N = A.moduleR} (A.right-multiply b) r a)
          ∙ linear-scalar {M = A.moduleR} {N = T} (pure-left (w W.* z)) r (a A.* b)
          ∙ cong (T._•_ r) (sym (operator-on-pure a b w z))))

  operator-right : (a : A.Carrier) → LinearMap W.moduleR End.hom-module
  operator-right a = pure-operator a ,
    ((U.determined-on-pure (pure-operator a W.zero) End.zero-map
      (λ b z → operator-on-pure a b W.zero z
        ∙ cong (pure (a A.* b)) (WS.*-zero-left z)
        ∙ linear-zero {M = W.moduleR} {N = T} (pure-right (a A.* b))) ,
      λ v w → U.determined-on-pure (pure-operator a (v W.+ w))
        (End.add-map (pure-operator a v) (pure-operator a w))
        (λ b z → operator-on-pure a b (v W.+ w) z
          ∙ cong (pure (a A.* b)) (WS.*-add-left v w z)
          ∙ linear-add {M = W.moduleR} {N = T} (pure-right (a A.* b)) (v W.* z) (w W.* z)
          ∙ cong₂ T._+_ (sym (operator-on-pure a b v z)) (sym (operator-on-pure a b w z)))) ,
      λ r w → U.determined-on-pure (pure-operator a (r W.• w))
        (End.scale-map r (pure-operator a w))
        (λ b z → operator-on-pure a b (r W.• w) z
          ∙ cong (pure (a A.* b))
            (linear-scalar {M = W.moduleR} {N = W.moduleR} (W.right-multiply z) r w)
          ∙ linear-scalar {M = W.moduleR} {N = T} (pure-right (a A.* b)) r (w W.* z)
          ∙ cong (T._•_ r) (sym (operator-on-pure a b w z))))

  operators : BilinearMap A.moduleR W.moduleR End.hom-module
  operators = pure-operator , ((λ w → snd (operator-left w)) , λ a → snd (operator-right a))

  module UE = Universal End.hom-module
  module C = Curry ext T T T

  curried-product : LinearMap T End.hom-module
  curried-product = UE.extension operators

  -- Keep the constructed operation opaque to later concrete basis
  -- instantiations; its implementation is connected by a checked
  -- computation equality, not an additional assumption.
  abstract
    product-bilinear : BilinearMap T T T
    product-bilinear = C.uncurry curried-product

    product-bilinear-computation : product-bilinear ≡ C.uncurry curried-product
    product-bilinear-computation = refl

  product : T.Carrier → T.Carrier → T.Carrier
  product = fst product-bilinear

  left-multiply : T.Carrier → LinearMap T T
  left-multiply = bilinear-right {L = T} {M = T} {N = T} product-bilinear

  right-multiply : T.Carrier → LinearMap T T
  right-multiply = bilinear-left {L = T} {M = T} {N = T} product-bilinear

  abstract
    product-on-pure : (a b : A.Carrier) (v w : W.Carrier)
      → product (pure a v) (pure b w) ≡ pure (a A.* b) (v W.* w)
    product-on-pure a b v w =
      cong (λ q → fst q (pure a v) (pure b w)) product-bilinear-computation
        ∙ cong (λ h → fst h (pure b w)) (UE.on-pure operators a v)
        ∙ operator-on-pure a b v w

  one : T.Carrier
  one = pure A.one W.one

  abstract
    product-comm : (s t : T.Carrier) → product s t ≡ product t s
    product-comm = U.bilinear-same-at product-bilinear
      (swap-bilinear {L = T} {M = T} {N = T} product-bilinear)
      (λ a b v w → product-on-pure a b v w
        ∙ cong₂ pure (A.*-comm a b) (W.*-comm v w)
        ∙ sym (product-on-pure b a w v))

    product-one-left : (t : T.Carrier) → product one t ≡ t
    product-one-left = U.same-at (left-multiply one) (identity-linear T)
      (λ a w → product-on-pure A.one a W.one w
        ∙ cong₂ pure (A.*-one-left a) (W.*-one-left w))

  assoc-left : T.Carrier → BilinearMap T T T
  assoc-left z = postcompose-bilinear {L = T} {M = T} {N = T} {P = T}
    (right-multiply z) product-bilinear

  assoc-right : T.Carrier → BilinearMap T T T
  assoc-right z = precompose-bilinear {L = T} {M = T} {L' = T} {M' = T} {N = T}
    (identity-linear T) (right-multiply z) product-bilinear

  abstract
    assoc-on-pures : (a b c : A.Carrier) (u v w : W.Carrier)
      → product (product (pure a u) (pure b v)) (pure c w)
        ≡ product (pure a u) (product (pure b v) (pure c w))
    assoc-on-pures a b c u v w =
      cong (λ t → product t (pure c w)) (product-on-pure a b u v)
      ∙ product-on-pure (a A.* b) c (u W.* v) w
      ∙ cong₂ pure (A.*-assoc a b c) (W.*-assoc u v w)
      ∙ sym (product-on-pure a (b A.* c) u (v W.* w))
      ∙ cong (product (pure a u)) (sym (product-on-pure b c v w))

    product-assoc : (x y z : T.Carrier) → product (product x y) z ≡ product x (product y z)
    product-assoc x y = U.same-at (left-multiply (product x y))
      (compose-linear {M = T} {N = T} {P = T} (left-multiply x) (left-multiply y))
      (λ c w → U.bilinear-same-at (assoc-left (pure c w)) (assoc-right (pure c w))
        (λ a b u v → assoc-on-pures a b c u v w) x y)

  algebra : CommutativeAlgebra R
  CommutativeAlgebra.moduleR algebra = T
  CommutativeAlgebra.one algebra = one
  CommutativeAlgebra.multiplication algebra = product-bilinear
  CommutativeAlgebra.*-assoc algebra = product-assoc
  CommutativeAlgebra.*-comm algebra = product-comm
  CommutativeAlgebra.*-one-left algebra = product-one-left

  include-left : AlgebraHom A algebra
  AlgebraHom.linear include-left = pure-left W.one
  AlgebraHom.map-one include-left = refl
  AlgebraHom.map-mul include-left a b =
    sym (product-on-pure a b W.one W.one
      ∙ cong (pure (a A.* b)) (W.*-one-left W.one))

  include-right : AlgebraHom W algebra
  AlgebraHom.linear include-right = pure-right A.one
  AlgebraHom.map-one include-right = refl
  AlgebraHom.map-mul include-right v w =
    sym (product-on-pure A.one A.one v w
      ∙ cong (λ a → pure a (v W.* w)) (A.*-one-left A.one))

  pure-as-product : (a : A.Carrier) (w : W.Carrier)
    → product (AlgebraHom.map include-left a) (AlgebraHom.map include-right w) ≡ pure a w
  pure-as-product a w = product-on-pure a A.one W.one w
    ∙ cong₂ pure (A.*-one-right a) (W.*-one-left w)

  module Coproduct (B : CommutativeAlgebra R) (f : AlgebraHom A B) (g : AlgebraHom W B) where

    private module B = CommutativeAlgebra B
    private module F = AlgebraHom f
    private module G = AlgebraHom g
    module UB = Universal B.moduleR

    pairing : BilinearMap A.moduleR W.moduleR B.moduleR
    pairing = precompose-bilinear
      {L = B.moduleR} {M = B.moduleR} {L' = A.moduleR} {M' = W.moduleR} {N = B.moduleR}
      F.linear G.linear B.multiplication

    abstract
      extension : LinearMap T B.moduleR
      extension = UB.extension pairing

      extension-computation : extension ≡ UB.extension pairing
      extension-computation = refl

      extension-on-pure : (a : A.Carrier) (w : W.Carrier)
        → fst extension (pure a w) ≡ F.map a B.* G.map w
      extension-on-pure a w = cong (λ h → fst h (pure a w)) extension-computation
        ∙ UB.on-pure pairing a w

    exchange : (a b c : B.Carrier) → a B.* (b B.* c) ≡ b B.* (a B.* c)
    exchange a b c = sym (B.*-assoc a b c)
      ∙ cong (λ z → z B.* c) (B.*-comm a b) ∙ B.*-assoc b a c

    interchange : (a b c d : B.Carrier)
      → (a B.* b) B.* (c B.* d) ≡ (a B.* c) B.* (b B.* d)
    interchange a b c d = B.*-assoc a b (c B.* d)
      ∙ cong (λ z → a B.* z) (exchange b c d) ∙ sym (B.*-assoc a c (b B.* d))

    product-image : BilinearMap T T B.moduleR
    product-image = postcompose-bilinear {L = T} {M = T} {N = T} {P = B.moduleR}
      extension product-bilinear

    image-product : BilinearMap T T B.moduleR
    image-product = precompose-bilinear
      {L = B.moduleR} {M = B.moduleR} {L' = T} {M' = T} {N = B.moduleR}
      extension extension B.multiplication

    abstract
      extension-mul : (s t : T.Carrier)
        → fst extension (product s t) ≡ fst extension s B.* fst extension t
      extension-mul = UB.bilinear-same-at product-image image-product
        (λ a b v w → cong (fst extension) (product-on-pure a b v w)
          ∙ extension-on-pure (a A.* b) (v W.* w)
          ∙ cong₂ B._*_ (F.map-mul a b) (G.map-mul v w)
          ∙ interchange (F.map a) (F.map b) (G.map v) (G.map w)
          ∙ cong₂ B._*_ (sym (extension-on-pure a v)) (sym (extension-on-pure b w)))

    induced : AlgebraHom algebra B
    AlgebraHom.linear induced = extension
    AlgebraHom.map-one induced = extension-on-pure A.one W.one
      ∙ cong₂ B._*_ F.map-one G.map-one ∙ B.*-one-left B.one
    AlgebraHom.map-mul induced = extension-mul

    restrict-left : (a : A.Carrier) → AlgebraHom.map induced (AlgebraHom.map include-left a) ≡ F.map a
    restrict-left a = extension-on-pure a W.one
      ∙ cong (B._*_ (F.map a)) G.map-one ∙ B.*-one-right (F.map a)

    restrict-right : (w : W.Carrier) → AlgebraHom.map induced (AlgebraHom.map include-right w) ≡ G.map w
    restrict-right w = extension-on-pure A.one w
      ∙ cong (λ b → b B.* G.map w) F.map-one ∙ B.*-one-left (G.map w)

    abstract
      unique-linear : (k : AlgebraHom algebra B)
        → ((a : A.Carrier) → AlgebraHom.map k (AlgebraHom.map include-left a) ≡ F.map a)
        → ((w : W.Carrier) → AlgebraHom.map k (AlgebraHom.map include-right w) ≡ G.map w)
        → AlgebraHom.linear k ≡ extension
      unique-linear k left right = UB.determined-on-pure (AlgebraHom.linear k) extension
        (λ a w → cong (AlgebraHom.map k) (sym (pure-as-product a w))
          ∙ AlgebraHom.map-mul k (AlgebraHom.map include-left a) (AlgebraHom.map include-right w)
          ∙ cong₂ B._*_ (left a) (right w) ∙ sym (extension-on-pure a w))

      unique : (k : AlgebraHom algebra B)
        → ((a : A.Carrier) → AlgebraHom.map k (AlgebraHom.map include-left a) ≡ F.map a)
        → ((w : W.Carrier) → AlgebraHom.map k (AlgebraHom.map include-right w) ≡ G.map w)
        → k ≡ induced
      unique k left right = algebra-hom-path ext {A = algebra} {B = B}
        {h = k} {k = induced} (unique-linear k left right)

module BasedAlgebras {ℓ : Level} (ext : FunExt ℓ ℓ) (classical : PropositionalDNE ℓ)
    {I : Set ℓ} (equality : DecidableEquality I) {R : CommutativeSemiring ℓ}
    (A : CommutativeAlgebra R) where

  private module A = CommutativeAlgebra A

  -- Typed exports avoid copying the complete nested tensor-UP module
  -- hierarchy when a client instantiates this parameter or an algebra.
  module B where
    Basis : Set ℓ
    Basis = BasedExtension.Basis ext classical equality A.moduleR

  module WithBasis (basis : B.Basis) where

    module On (W : CommutativeAlgebra R) where

      private module W = CommutativeAlgebra W

      module O where
        Extension : Semimodule R
        Extension = BasedExtension.WithBasis.On.Extension ext classical equality A.moduleR basis W.moduleR

        pure : A.Carrier → W.Carrier → Semimodule.Carrier Extension
        pure = BasedExtension.WithBasis.On.pure ext classical equality A.moduleR basis W.moduleR

        pure-left : (w : W.Carrier) → LinearMap A.moduleR Extension
        pure-left = BasedExtension.WithBasis.On.pure-left ext classical equality A.moduleR basis W.moduleR

        pure-right : (a : A.Carrier) → LinearMap W.moduleR Extension
        pure-right = BasedExtension.WithBasis.On.pure-right ext classical equality A.moduleR basis W.moduleR

      pure-bilinear : BilinearMap A.moduleR W.moduleR O.Extension
      pure-bilinear = O.pure , ((λ w → snd (O.pure-left w)) , λ a → snd (O.pure-right a))

      universal : (N : Semimodule R) → Equiv (LinearMap O.Extension N) (BilinearMap A.moduleR W.moduleR N)
      universal N = BasedExtension.WithBasis.On.Universal.scalar-extension-universal
        ext classical equality A.moduleR basis W.moduleR N

      universal-forward : (N : Semimodule R) (h : LinearMap O.Extension N) (a : A.Carrier) (w : W.Carrier)
        → fst (forward (universal N) h) a w ≡ fst h (O.pure a w)
      universal-forward = BasedExtension.WithBasis.On.Universal.universal-forward-is-pure
        ext classical equality A.moduleR basis W.moduleR

      module Algebra where
        algebra : CommutativeAlgebra R
        algebra = Construction.algebra ext A W O.Extension pure-bilinear universal universal-forward

        product-bilinear : BilinearMap O.Extension O.Extension O.Extension
        product-bilinear = Construction.product-bilinear ext A W O.Extension pure-bilinear universal universal-forward

        product : Semimodule.Carrier O.Extension → Semimodule.Carrier O.Extension → Semimodule.Carrier O.Extension
        product = fst product-bilinear

        one : Semimodule.Carrier O.Extension
        one = O.pure A.one W.one

        product-on-pure : (a b : A.Carrier) (v w : W.Carrier)
          → product (O.pure a v) (O.pure b w) ≡ O.pure (a A.* b) (v W.* w)
        product-on-pure = Construction.product-on-pure ext A W O.Extension pure-bilinear universal universal-forward

        product-comm : (s t : Semimodule.Carrier O.Extension) → product s t ≡ product t s
        product-comm = Construction.product-comm ext A W O.Extension pure-bilinear universal universal-forward

        product-one-left : (t : Semimodule.Carrier O.Extension) → product one t ≡ t
        product-one-left = Construction.product-one-left ext A W O.Extension pure-bilinear universal universal-forward

        product-assoc : (s t u : Semimodule.Carrier O.Extension)
          → product (product s t) u ≡ product s (product t u)
        product-assoc = Construction.product-assoc ext A W O.Extension pure-bilinear universal universal-forward

        include-left : AlgebraHom A algebra
        include-left = Construction.include-left ext A W O.Extension pure-bilinear universal universal-forward

        include-right : AlgebraHom W algebra
        include-right = Construction.include-right ext A W O.Extension pure-bilinear universal universal-forward

        pure-as-product : (a : A.Carrier) (w : W.Carrier)
          → product (AlgebraHom.map include-left a) (AlgebraHom.map include-right w) ≡ O.pure a w
        pure-as-product = Construction.pure-as-product ext A W O.Extension pure-bilinear universal universal-forward

        module Universal (N : Semimodule R) where
          extension : BilinearMap A.moduleR W.moduleR N → LinearMap O.Extension N
          extension = Construction.Universal.extension ext A W O.Extension pure-bilinear universal universal-forward N

          on-pure : (b : BilinearMap A.moduleR W.moduleR N) (a : A.Carrier) (w : W.Carrier)
            → fst (extension b) (O.pure a w) ≡ fst b a w
          on-pure = Construction.Universal.on-pure ext A W O.Extension pure-bilinear universal universal-forward N

          determined-on-pure : (h k : LinearMap O.Extension N)
            → ((a : A.Carrier) (w : W.Carrier) → fst h (O.pure a w) ≡ fst k (O.pure a w)) → h ≡ k
          determined-on-pure = Construction.Universal.determined-on-pure
            ext A W O.Extension pure-bilinear universal universal-forward N

          same-at : (h k : LinearMap O.Extension N)
            → ((a : A.Carrier) (w : W.Carrier) → fst h (O.pure a w) ≡ fst k (O.pure a w))
            → (t : Semimodule.Carrier O.Extension) → fst h t ≡ fst k t
          same-at = Construction.Universal.same-at ext A W O.Extension pure-bilinear universal universal-forward N

          bilinear-same-at : (h k : BilinearMap O.Extension O.Extension N)
            → ((a b : A.Carrier) (v w : W.Carrier)
              → fst h (O.pure a v) (O.pure b w) ≡ fst k (O.pure a v) (O.pure b w))
            → (s t : Semimodule.Carrier O.Extension) → fst h s t ≡ fst k s t
          bilinear-same-at = Construction.Universal.bilinear-same-at
            ext A W O.Extension pure-bilinear universal universal-forward N

        module Coproduct (V : CommutativeAlgebra R) (f : AlgebraHom A V) (g : AlgebraHom W V) where
          induced : AlgebraHom algebra V
          induced = Construction.Coproduct.induced ext A W O.Extension pure-bilinear universal universal-forward V f g

          restrict-left : (a : A.Carrier)
            → AlgebraHom.map induced (AlgebraHom.map include-left a) ≡ AlgebraHom.map f a
          restrict-left = Construction.Coproduct.restrict-left
            ext A W O.Extension pure-bilinear universal universal-forward V f g

          restrict-right : (w : W.Carrier)
            → AlgebraHom.map induced (AlgebraHom.map include-right w) ≡ AlgebraHom.map g w
          restrict-right = Construction.Coproduct.restrict-right
            ext A W O.Extension pure-bilinear universal universal-forward V f g

          unique : (k : AlgebraHom algebra V)
            → ((a : A.Carrier) → AlgebraHom.map k (AlgebraHom.map include-left a) ≡ AlgebraHom.map f a)
            → ((w : W.Carrier) → AlgebraHom.map k (AlgebraHom.map include-right w) ≡ AlgebraHom.map g w)
            → k ≡ induced
          unique = Construction.Coproduct.unique ext A W O.Extension pure-bilinear universal universal-forward V f g

    module Map (W V : CommutativeAlgebra R) (h : AlgebraHom W V) where

      private module W = CommutativeAlgebra W
      private module V = CommutativeAlgebra V
      private module H = AlgebraHom h

      source-module : Semimodule R
      source-module = On.O.Extension W

      target-module : Semimodule R
      target-module = On.O.Extension V

      module Map0 where
        tensor-map : LinearMap source-module target-module
        tensor-map = TensorMap.tensor-map ext classical equality W.moduleR V.moduleR H.linear

      on-pure : (a : A.Carrier) (w : W.Carrier)
        → fst Map0.tensor-map (On.O.pure W a w) ≡ On.O.pure V a (H.map w)
      on-pure a w = TensorMap.tensor-map-on-pure ext classical equality W.moduleR V.moduleR H.linear
        (fst (LinearEquivalence.from-linear basis) a) w

      product-image : BilinearMap source-module source-module target-module
      product-image = postcompose-bilinear
        {L = source-module} {M = source-module} {N = source-module} {P = target-module}
        Map0.tensor-map (On.Algebra.product-bilinear W)

      image-product : BilinearMap source-module source-module target-module
      image-product = precompose-bilinear
        {L = target-module} {M = target-module} {L' = source-module} {M' = source-module} {N = target-module}
        Map0.tensor-map Map0.tensor-map (On.Algebra.product-bilinear V)

      abstract
        preserves-product : (s t : Semimodule.Carrier source-module)
          → fst Map0.tensor-map (On.Algebra.product W s t)
            ≡ On.Algebra.product V (fst Map0.tensor-map s) (fst Map0.tensor-map t)
        preserves-product = On.Algebra.Universal.bilinear-same-at W target-module product-image image-product
          (λ a b v w → cong (fst Map0.tensor-map) (On.Algebra.product-on-pure W a b v w)
            ∙ on-pure (a A.* b) (v W.* w)
            ∙ cong (On.O.pure V (a A.* b)) (H.map-mul v w)
            ∙ sym (On.Algebra.product-on-pure V a b (H.map v) (H.map w))
            ∙ cong₂ (On.Algebra.product V) (sym (on-pure a v)) (sym (on-pure b w)))

      algebra-map : AlgebraHom (On.Algebra.algebra W) (On.Algebra.algebra V)
      AlgebraHom.linear algebra-map = Map0.tensor-map
      AlgebraHom.map-one algebra-map = on-pure A.one W.one ∙ cong (On.O.pure V A.one) H.map-one
      AlgebraHom.map-mul algebra-map = preserves-product

      respects-parameter : (a : A.Carrier)
        → AlgebraHom.map algebra-map (AlgebraHom.map (On.Algebra.include-left W) a)
          ≡ AlgebraHom.map (On.Algebra.include-left V) a
      respects-parameter a = on-pure a W.one ∙ cong (On.O.pure V a) H.map-one
