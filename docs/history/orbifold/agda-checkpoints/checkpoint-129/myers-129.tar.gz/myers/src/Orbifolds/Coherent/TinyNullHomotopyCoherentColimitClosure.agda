{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.TinyNullHomotopyCoherentColimitClosure where

-- The actual full coherent bar colimit of null vertices is null for a
-- discrete tiny family. The concrete chain/sphere cell presentation is
-- constructed independently; only pointwise nullity is supplied here.
-- This fixed-diagram proof can be specialized to native nullification
-- without expanding its entire higher-action record during elaboration.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; zero; suc)
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
open import Orbifolds.Crisp
import Orbifolds.CrispIdentity as CI
import Orbifolds.CrispFlat as CF
import Orbifolds.TinyNullificationCubicalShellCells as NullCells
import Orbifolds.TinyNullTypeColimits as NullColimits
import Orbifolds.CellularPresentations as CP
import Orbifolds.CubicalShellSpheres as Spheres
import Orbifolds.TinyCubicalShellCells as Cells
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; toNat)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.EnrichedBarNullification as NullIndices
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentColimitCells as BarCells

module Context {@♭ ℓ : Level}
    (@♭ identity-rules : CI.CrispIdentityInduction {ℓ})
    (@♭ flat-induction : CF.CrispFlatInduction {ℓ})
    (@♭ flat-computation : CF.CrispFlatComputation flat-induction)
    (@♭ identity-zero : CI.CrispIdentityInduction {ℓ = ℓ-zero})
    (@♭ flat-zero : CF.CrispFlatInduction {ℓ = ℓ-zero})
    (@♭ flat-zero-computation : CF.CrispFlatComputation flat-zero)
    (@♭ R : Type ℓ) (@♭ r₀ : R) (@♭ Ix : Type₀) (@♭ S : Ix → Type ℓ)
    (@♭ C : Category ℓ ℓ) (@♭ D : HC.ForCategory.Diagram C)
    (@♭ E : StrictCubicalExtensionality ℓ) (@♭ F : StrictFunctionExtensionality ℓ) where
  open Category C
  module Objects = NullCells.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R r₀ Ix S
  module Indices = NullIndices.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R r₀ Ix S (Opposite C)
  module Closure = NullColimits.Context identity-rules flat-induction flat-computation
    identity-zero flat-zero flat-zero-computation R Ix S
  module Bar = BarCells.Construction C D E F
  open Objects using (RealFlat; TinyFamily) public

  module Proof (real-flat : RealFlat) (discrete-generators : CrisplyDiscrete Ix)
      (tiny : TinyFamily) (discrete-objects : CrisplyDiscrete Obj)
      (discrete-homs : (@♭ x y : Obj) → CrisplyDiscrete (Hom x y))
      (vertices-null : (x : Obj) → NB.isNull S (HC.ForCategory.Diagram.Value D x)) where

    objects-null : NB.isNull S Obj
    objects-null = Objects.null-index real-flat discrete-generators tiny Obj discrete-objects

    unlift-boundary : (n : ℕ) → Cells.Boundary {ℓ} n ≃ Spheres.SphereBoundary n
    unlift-boundary n = isoToEquiv (iso lower lift (λ _ → refl) (λ _ → refl))

    sphere-null : (n : ℕ) → NB.isNull S (Spheres.SphereBoundary n)
    sphere-null n = NP.equivPreservesIsNull (unlift-boundary n)
      (Objects.null-boundary discrete-generators tiny n)

    initial-null : NB.isNull S Bar.Initial
    initial-null = NP.isNullΣ {X = Obj}
      {Y = λ x → HC.ForCategory.Diagram.Value D x}
      objects-null vertices-null

    cells-null : (@♭ n : Dim) → NB.isNull S (Bar.Cells n)
    cells-null n = NP.isNullΣ {X = Bar.Index n}
      {Y = λ c → HC.ForCategory.Diagram.Value D (c .fst)}
      (Indices.indices-null real-flat discrete-generators tiny discrete-objects
        (λ x y → discrete-homs y x) (toNat (osuc n)))
      (λ c → vertices-null (c .fst))

    boundary-null : (@♭ n : Dim) → NB.isNull S (Bar.Boundary n)
    boundary-null n = NP.isNullΣ {X = Bar.Cells n}
      {Y = λ _ → Spheres.SphereBoundary (toNat (osuc n))}
      (cells-null n)
      (λ _ → sphere-null (toNat (osuc n)))

    next-null : (@♭ n : Dim) (@♭ previous : Bar.Representation n)
      → NB.isNull S (Bar.Space previous)
      → NB.isNull S (Bar.Next n previous)
    next-null n previous null-previous = Closure.pushout-null discrete-generators tiny
      {A = Bar.Boundary n} {B = Bar.Space previous} {C = Bar.Cells n}
      (Bar.attach n previous)
      (Bar.boundary n)
      (boundary-null n) null-previous (cells-null n)

    record NullWitness {A : Type ℓ} (P : CP.Presentation A) : Type ℓ where
      coinductive
      field
        current : NB.isNull S A
        tail : NullWitness (CP.Presentation.next P)

    build-witness : (@♭ n : Dim) (@♭ previous : Bar.Representation n)
      → NB.isNull S (Bar.Space previous)
      → NullWitness (Bar.presentation n previous)
    NullWitness.current (build-witness n previous null-previous) = null-previous
    NullWitness.tail (build-witness n previous null-previous) = build-witness (osuc n)
      (Bar.next n previous)
      (next-null n previous null-previous)

    witness-at : (n : ℕ) → NullWitness (Bar.state n .snd)
    witness-at zero = build-witness ozero Bar.initial initial-null
    witness-at (suc n) = NullWitness.tail (witness-at n)

    stages-null : (n : ℕ) → NB.isNull S (Bar.Stage n)
    stages-null n = NullWitness.current (witness-at n)

    abstract
      colimit-null : NB.isNull S Bar.Colimit
      colimit-null = Closure.sequence-null real-flat discrete-generators tiny
        Bar.stages stages-null
