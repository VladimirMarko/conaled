{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.EnrichedBarColimitStep where

-- Concrete successor representability for the actual finite bar cocone
-- stages. The predecessor is the induction hypothesis. All attaching
-- maps and the next-stage mapping equivalence are constructed below.
-- The successor naturality proof needed for unbounded iteration is a
-- separate obligation; it is not asserted as a field of this result.

open import Cubical.Foundations.Prelude hiding (Cube)
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Orbifolds.Coherent.StrictEnriched
open import Orbifolds.Coherent.OuterBarChains
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.EnrichedMappingDiagrams using (Opposite)
import Orbifolds.Coherent.EnrichedMappingDiagrams as Mapping
import Orbifolds.Coherent.EnrichedBarFiniteStages as Finite
import Orbifolds.Coherent.EnrichedBarFiniteTransformations as Transformations
import Orbifolds.Coherent.EnrichedBarColimitBase as Base
import Orbifolds.Coherent.NaturalCubicalShellRepresentation as Representation
import Orbifolds.CubicalShells as CS
import Orbifolds.CubicalShellFillers as CF
import Orbifolds.CubicalAttachmentFromFillers as Attachments
import Cubical.HITs.Pushout as PO
open import Orbifolds.CubicalShellSpheres using (SphereBoundary)

module Construction {ℓ : Level} (C : Category ℓ ℓ) (D : Diagram C ℓ)
    (E : StrictCubicalExtensionality ℓ)
    (filler-representation : (n : Dim) (X : Type ℓ) (b : CS.Shell (toNat n) X)
      → CF.Filler (toNat n) b ≃
        (Σ[ center ∈ X ] (Representation.Representation.evaluate E n b ≡ (λ _ → center)))) where

  Cocone : Type ℓ → Dim → Type ℓ
  Cocone Y n = Finite.Finite.Carrier (Opposite C) (Mapping.Mapping.Into D Y) E n

  postcompose : (n : Dim) {Y Z : Type ℓ} → (Y → Z) → Cocone Y n → Cocone Z n
  postcompose n {Y} {Z} k = Transformations.Action.stage-map
    (Mapping.Mapping.Into D Y) (Mapping.Mapping.Into D Z) (Mapping.Mapping.Postcompose D k) E n

  record Represented (n : Dim) : Type (ℓ-suc ℓ) where
    field
      Space : Type ℓ
      universal : (Y : Type ℓ) → (Space → Y) ≃ Cocone Y n
      natural : (Y Z : Type ℓ) (k : Y → Z) (h : Space → Y)
        → postcompose n k (universal Y .fst h) ≡ universal Z .fst (k ∘ h)

  initial : Represented ozero
  Represented.Space initial = Base.Base.Initial C D E
  Represented.universal initial = Base.Base.Target.universal C D E
  Represented.natural initial Y Z k h = refl

  module Step (n : Dim) (previous : Represented n) where
    open Represented previous renaming (Space to Previous; universal to previous-universal;
      natural to previous-natural)

    Index : Type ℓ
    Index = Chains.Index (Opposite C) (osuc n)

    Coefficient : Index → Type ℓ
    Coefficient c = Diagram.Value D (c .fst)

    boundary-data : (Y : Type ℓ) → (Previous → Y)
      → (c : Index) → CS.Shell (toNat (osuc n)) (Coefficient c → Y)
    boundary-data Y h c = Finite.Finite.At.boundary-data
      (Opposite C) (Mapping.Mapping.Into D Y) E n (previous-universal Y .fst h) c

    universal-cocone : Cocone Previous n
    universal-cocone = previous-universal Previous .fst (idfun Previous)

    boundary-computation : (Y : Type ℓ) (h : Previous → Y) (c : Index)
      → Representation.Representation.evaluate E (osuc n) (boundary-data Y h c)
        ≡ (λ s x → h (Representation.Representation.evaluate E (osuc n)
            (boundary-data Previous (idfun Previous) c) s x))
    boundary-computation Y h c =
      cong (λ p → Representation.Representation.evaluate E (osuc n)
        (Finite.Finite.At.boundary-data (Opposite C) (Mapping.Mapping.Into D Y) E n p c))
        (sym (previous-natural Previous Y h (idfun Previous)))
      ∙ cong (Representation.Representation.evaluate E (osuc n))
          (sym (strict-to-path (Transformations.Action.stage-boundary-natural
            (Mapping.Mapping.Into D Previous) (Mapping.Mapping.Into D Y)
            (Mapping.Mapping.Postcompose D h) E n universal-cocone (c .fst) (c .snd))))
      ∙ Representation.Representation.evaluate-natural E (osuc n) (λ k → h ∘ k)
          (boundary-data Previous (idfun Previous) c)

    Cell : Type ℓ
    Cell = Σ Index Coefficient

    Boundary : Type ℓ
    Boundary = Cell × SphereBoundary (toNat (osuc n))

    attach : Boundary → Previous
    attach ((c , x) , s) = Representation.Representation.evaluate E (osuc n)
      (boundary-data Previous (idfun Previous) c) s x

    boundary : Boundary → Cell
    boundary = fst

    Realize : Type ℓ
    Realize = PO.Pushout attach boundary

    include : Previous → Realize
    include = PO.inl

    center : Cell → Realize
    center = PO.inr

    ConstructedCocone : Type ℓ → Type ℓ
    ConstructedCocone Y = Σ[ h ∈ (Previous → Y) ]
      ((c : Index) → CF.Filler (toNat (osuc n)) (boundary-data Y h c))

    constructed-universal : (Y : Type ℓ) → (Realize → Y) ≃ ConstructedCocone Y
    constructed-universal Y = Attachments.Theory.Extension.Target.universal
      (toNat (osuc n)) (Representation.Representation.evaluate E (osuc n))
      (filler-representation (osuc n)) Previous Index Coefficient boundary-data boundary-computation Y

    dependent-comparison : (Y : Type ℓ)
      → ConstructedCocone Y ≃ Cocone Y (osuc n)
    dependent-comparison Y = Σ-cong-equiv (previous-universal Y) (λ _ → idEquiv _)

    universal : (Y : Type ℓ) → (Realize → Y) ≃ Cocone Y (osuc n)
    universal Y = constructed-universal Y ∙ₑ dependent-comparison Y

    restrict : (Y : Type ℓ) → (Realize → Y) → Cocone Y (osuc n)
    restrict Y = universal Y .fst

    assemble : (Y : Type ℓ) → Cocone Y (osuc n) → Realize → Y
    assemble Y = invEq (universal Y)

    original-computation : (Y : Type ℓ) (h : Realize → Y)
      → Finite.Finite.transition (Opposite C) (Mapping.Mapping.Into D Y) E n (restrict Y h)
        ≡ previous-universal Y .fst (h ∘ include)
    original-computation Y h = refl

    filler-computation : (Y : Type ℓ) (h : Realize → Y)
      → restrict Y h .snd ≡ constructed-universal Y .fst h .snd
    filler-computation Y h = refl

    canonical-cocone : Cocone Realize (osuc n)
    canonical-cocone = restrict Realize (idfun Realize)
