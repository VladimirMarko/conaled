{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.CrispFiniteness where

-- Proposition 6.1.2 for the actual SubfiniteSpan definition. Membership
-- in the finite ordinal and equality in the finite image are decided
-- using crisp excluded middle after lawful crisp element elimination.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Nat using (ℕ; isSetℕ)
import Cubical.Data.SumFin as SF
open import Cubical.Data.FinSet
open import Cubical.Data.FinSet.Constructors using (isFinSetΣ)
open import Cubical.Functions.Embedding
import Cubical.Functions.Fibration as Fibration
open import Cubical.Relation.Nullary using (Dec)
import Cubical.HITs.PropositionalTruncation as PT
open import Orbifolds.Crisp
open import Orbifolds.CrispTruncation
open import Orbifolds.Association
import Orbifolds.CrispPropositions as CP
import Orbifolds.CrispCountable as CC
import Orbifolds.FiniteSurjectiveQuotient as FQ

module Context {@♭ ℓ : Level} (@♭ R : Type ℓ) (@♭ r₀ : R) where
  module Propositions = CP.Context R r₀
  module Countable = CC.Context R r₀
  module UpperPropositions = CP.Context
    (Lift {ℓ} {ℓ-suc ℓ} R) (lift r₀)

  module Span {@♭ X : Type ℓ} (@♭ setX : isSet X)
      (@♭ n : ℕ) (@♭ W : SubfiniteSpan X n) where
    natural-index : SF.Fin n ↪ ℕ
    natural-index = SF.toℕ , injEmbedding isSetℕ SF.toℕ-injective

    natural-domain : Domain W ↪ ℕ
    natural-domain = compEmbedding natural-index (inclusion W)

    module DomainElements = Countable.Embedded natural-domain
    module OrdinalElements = Countable.FiniteOrdinal n
    module Image = FQ.Image setX (cover W)

    membership-decidable : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → (i : SF.Fin n) → Dec (fiber (inclusion W .fst) i)
    membership-decidable real-flat excluded-middle =
      OrdinalElements.crisp-fin-elim real-flat
        (λ i → Dec (fiber (inclusion W .fst) i))
        (λ i → excluded-middle (fiber (inclusion W .fst) i ,
          isEmbedding→hasPropFibers (inclusion W .snd) i))

    domain-finite : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → isFinSet (Domain W)
    domain-finite real-flat excluded-middle = EquivPresIsFinSet
      (invEquiv (Fibration.totalEquiv (inclusion W .fst)))
      (isFinSetΣ (SF.Fin n , isFinSetFin)
        (λ i → fiber (inclusion W .fst) i , isDecProp→isFinSet
          (isEmbedding→hasPropFibers (inclusion W .snd) i)
          (membership-decidable real-flat excluded-middle i)))

    image-equality-decidable : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
      → (a b : Domain W) → Dec (cover W .fst a ≡ cover W .fst b)
    image-equality-decidable real-flat excluded-middle =
      DomainElements.crisp-element-elim real-flat
        (λ a → (b : Domain W) → Dec (cover W .fst a ≡ cover W .fst b))
        (λ a → DomainElements.crisp-element-elim real-flat
          (λ b → Dec (cover W .fst a ≡ cover W .fst b))
          (λ b → excluded-middle ((cover W .fst a ≡ cover W .fst b) ,
            setX (cover W .fst a) (cover W .fst b))))

    span-finite : Propositions.RealFlat → CrispExcludedMiddle {ℓ} → isFinSet X
    span-finite real-flat excluded-middle = Image.finite-surjective-image
      (domain-finite real-flat excluded-middle)
      (image-equality-decidable real-flat excluded-middle)

  -- The precise crisp witness form: Flat-truncation distribution is used
  -- at suc ℓ because the span existential quantifies over a type in ℓ.
  crisply-subfinite→finite : Propositions.RealFlat → CrispExcludedMiddle {ℓ}
    → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
    → (@♭ X : Type ℓ) → (@♭ setX : isSet X)
    → (@♭ witness : SubfinitelyEnumerable X) → isFinSet X
  crisply-subfinite→finite real-flat excluded-middle distribute X setX =
    crisp-truncation-rec distribute (Σ[ n ∈ ℕ ] SubfiniteSpan X n)
      isPropIsFinSet
      (λ witness → Span.span-finite setX (witness .fst) (witness .snd)
        real-flat excluded-middle)

  -- If the subfinite-enumerability proof is ordinary, promotion is a
  -- derived proposition theorem using the displayed upper-universe
  -- R-flat instance. No arbitrary ordinary type or point is promoted.
  crisp-subfinite→finite : Propositions.RealFlat → UpperPropositions.RealFlat
    → CrispExcludedMiddle {ℓ} → FlatTruncationDistribution {ℓ = ℓ-suc ℓ}
    → (@♭ X : Type ℓ) → isSet X → SubfinitelyEnumerable X → isFinSet X
  crisp-subfinite→finite real-flat upper-real-flat excluded-middle distribute
      X setX witness = flat-elim (λ _ → isFinSet X)
      (λ crisp-set → flat-elim (λ _ → isFinSet X)
        (λ crisp-witness → crisply-subfinite→finite
          real-flat excluded-middle distribute X crisp-set crisp-witness)
        (UpperPropositions.promote-proof upper-real-flat
          (SubfinitelyEnumerable X) PT.squash₁ witness))
      (Propositions.promote-proof real-flat (isSet X) isPropIsSet setX)
