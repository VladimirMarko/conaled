{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentNullification where

-- Nullification of an arbitrary existing homotopy-coherent diagram.
-- The original (possibly nonconstant) coherence cube is retained on
-- every generating point of Null. No strict-input hypothesis is used.

open import Agda.Primitive using (SSet)
open import Cubical.Foundations.Prelude hiding (Cube; lower)
open import Cubical.Foundations.Equiv
open import Cubical.Data.Sigma
open import Cubical.Modalities.Modality using (Modality)
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.OuterBarChains using (Dim; ozero; osuc; Position)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality; Cube; coordinate-face; map-cube)
import Orbifolds.Coherent.OuterCubicalFaces as Cubes
open import Orbifolds.Coherent.StrictCubicalShellAssembly using (Endpoint; low; high; endpoint; star)
open import Orbifolds.Coherent.CoherentArrowChains using (prefix-degree; suffix-degree)
import Orbifolds.Coherent.CoherentArrowChains as Chains
open import Orbifolds.Coherent.HomotopyCoherentActionData using (_≤ᵈ_; same; lower; prefix-bound; suffix-bound; LawPair; law-pair)
import Orbifolds.Coherent.HomotopyCoherentActionData as Histories
import Orbifolds.Coherent.HomotopyCoherentActionCompatibility as Compatibility
open import Orbifolds.Coherent.HomotopyCoherentDiagrams using (tensor-action)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HCD
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.CoherentTensorNaturality as Tensors
import Orbifolds.Coherent.StrictNullCubicalLifting as Lifting
import Cubical.HITs.Nullification.Base as NB
import Cubical.HITs.Nullification.Properties as NP
import Orbifolds.NullCubicalExtensions as NC

module Reflection {ℓ : Level} (C : Category ℓ ℓ)
    (D : HCD.ForCategory.Diagram C) {Ix : Type₀} (S : Ix → Type ℓ)
    (E : StrictCubicalExtensionality ℓ) where
  open Category C
  module HC = HCD.ForCategory C
  module D = HC.Diagram D
  open Chains.Arrows C
  open Cubes.Extensional E
  open Tensors.Naturality E
  module Null = Lifting.Lifting S E
  module Native = NC.NativeMaps S
  module Maps = Transformations.ForCategory C

  M : Modality ℓ
  M = NP.NullModality {ℓ = ℓ} S
  open Modality M using (η; ◯-map)

  Value : Obj → Type ℓ
  Value x = NB.Null S (D.Value x)

  module Data = Histories.Data C Value
  module Compatible = Compatibility.Compatibility C Value E

  AtUnit : (n : Dim) → Data.Actions n → SSet ℓ
  AtUnit n F = (m : Dim) (bound : m ≤ᵈ n) {x y : Obj}
    (c : Chain m x y) (a : D.Value x)
    → outer (Data.at bound F c (η a)) ≡ˢ outer (map-cube m η (D.action m c a))

  initial-actions : Data.Actions ozero
  initial-actions f = ◯-map (D.action ozero f)

  initial-unit : AtUnit ozero initial-actions
  initial-unit .ozero same c a = reflˢ

  one-at-unit : (n : Dim) (F : Data.Actions n) → AtUnit n F
    → (p : Position (osuc n)) {x y : Obj} (c : Chain (osuc n) x y) (a : D.Value x)
    → outer (Data.one n F p c (η a))
      ≡ˢ outer (map-cube n η (tensor-action n p
        (D.action (suffix-degree n p) (split-suffix n p c))
        (D.action (prefix-degree n p) (split-prefix n p c)) a))
  one-at-unit n F at-unit p c a = tensor-natural n p η η η
    (D.action (suffix-degree n p) (split-suffix n p c))
    (D.action (prefix-degree n p) (split-prefix n p c))
    (Data.at (suffix-bound n p) F (split-suffix n p c))
    (Data.at (prefix-bound n p) F (split-prefix n p c)) a
    (at-unit (prefix-degree n p) (prefix-bound n p) (split-prefix n p c) a)
    (λ b → at-unit (suffix-degree n p) (suffix-bound n p) (split-suffix n p c) b)

  unit-faces : (n : Dim) (F : Data.Actions n) → AtUnit n F
    → {x y : Obj} (c : Chain (osuc n) x y) (a : D.Value x)
    → (p : Position (osuc n)) (e : Endpoint)
    → outer (Data.faces n F c (η a) p e)
      ≡ˢ outer (coordinate-face n p (endpoint e) (map-cube (osuc n) η (D.action (osuc n) c a)))
  unit-faces n F at-unit c a p low = strict-trans
    (at-unit n same (face n p c) a)
    (strict-trans
      (strict-cong (λ q → outer (map-cube n η (inner q))) (strict-sym (D.zero-face n p c a)))
      (map-face n p i0 η (D.action (osuc n) c a)))
  unit-faces n F at-unit c a p high = strict-trans
    (one-at-unit n F at-unit p c a)
    (strict-trans
      (strict-cong (λ q → outer (map-cube n η (inner q))) (strict-sym (D.one-face n p c a)))
      (map-face n p i1 η (D.action (osuc n) c a)))

  record Stage (n : Dim) : SSet ℓ where
    field
      actions : Data.Actions n
      coherent : Data.Coherent n actions
      at-unit : AtUnit n actions

  initial : Stage ozero
  Stage.actions initial = initial-actions
  Stage.coherent initial = star
  Stage.at-unit initial = initial-unit

  module Step (n : Dim) (previous : Stage n) where
    F : Data.Actions n
    F = Stage.actions previous

    module Cell {x y : Obj} (c : Chain (osuc n) x y) where
      module Extension = Null.Assembled n (D.Value x) (Value y) (NB.isNull-Null S)
        (Data.faces n F c)
        (Compatible.action-compatible n F (Stage.coherent previous) c)
        (λ a → map-cube (osuc n) η (D.action (osuc n) c a))
        (unit-faces n F (Stage.at-unit previous) c)

      action : Value x → Cube (osuc n) (Value y)
      action = Extension.cube

      unit : (a : D.Value x)
        → outer (action (η a)) ≡ˢ outer (map-cube (osuc n) η (D.action (osuc n) c a))
      unit = Extension.cube-unit

    next : Data.Top (osuc n)
    next c = Cell.action c

    next-laws : Data.LayerLaws n F next
    Data.LayerLaws.zero-face next-laws p c a = Cell.Extension.cube-face c a p low
    Data.LayerLaws.one-face next-laws p c a = Cell.Extension.cube-face c a p high

    result : Stage (osuc n)
    Stage.actions result = F , next
    Stage.coherent result = law-pair (Stage.coherent previous) next-laws
    Stage.at-unit result .(osuc n) same c a = Cell.unit c a
    Stage.at-unit result m (lower bound) c a = Stage.at-unit previous m bound c a

  stage : (n : Dim) → Stage n
  stage ozero = initial
  stage (osuc n) = Step.result n (stage n)

  stage-lookup : {m n : Dim} (bound : m ≤ᵈ n)
    → outer {A = Data.Top m} (Data.at bound (Stage.actions (stage n)))
      ≡ˢ outer {A = Data.Top m} (Data.top m (Stage.actions (stage m)))
  stage-lookup same = reflˢ
  stage-lookup (lower bound) = stage-lookup bound

  reflected : HC.Diagram
  HC.Diagram.Value reflected = Value
  HC.Diagram.action reflected n = Data.top n (Stage.actions (stage n))
  HC.Diagram.zero-face reflected n p c a =
    Data.LayerLaws.zero-face (LawPair.current (Stage.coherent (stage (osuc n)))) p c a
  HC.Diagram.one-face reflected n p c a = strict-trans
    (Data.LayerLaws.one-face (LawPair.current (Stage.coherent (stage (osuc n)))) p c a)
    (strict-trans
      (strict-cong (λ g → outer (tensor-action n p (inner g (split-suffix n p c))
        (Data.at (prefix-bound n p) (Stage.actions (stage n)) (split-prefix n p c)) a))
        (stage-lookup (suffix-bound n p)))
      (strict-cong (λ f → outer (tensor-action n p
        (Data.top (suffix-degree n p) (Stage.actions (stage (suffix-degree n p))) (split-suffix n p c))
        (inner f (split-prefix n p c)) a))
        (stage-lookup (prefix-bound n p))))
  HC.Diagram.unit reflected x = funExt λ a →
    cong (λ f → ◯-map f a) (D.unit x) ∙ Native.identity-cell a

  action-at-unit : (n : Dim) {x y : Obj} (c : Chain n x y) (a : D.Value x)
    → outer (HC.Diagram.action reflected n c (η a)) ≡ˢ outer (map-cube n η (D.action n c a))
  action-at-unit n c a = Stage.at-unit (stage n) n same c a

  unit-transformation : Maps.Transformation D reflected
  Maps.Transformation.component unit-transformation x = η
  Maps.Transformation.naturality unit-transformation n c a = strict-sym (action-at-unit n c a)

  vertex-computation : (x : Obj) → outer (HC.Diagram.Value reflected x) ≡ˢ outer (NB.Null S (D.Value x))
  vertex-computation x = reflˢ

  arrow-computation : {x y : Obj} (f : Hom x y) (a : Value x)
    → outer (HC.Diagram.action reflected ozero f a) ≡ˢ outer (◯-map (D.action ozero f) a)
  arrow-computation f a = reflˢ

  vertices-null : (x : Obj) → NB.isNull S (HC.Diagram.Value reflected x)
  vertices-null x = NB.isNull-Null S
