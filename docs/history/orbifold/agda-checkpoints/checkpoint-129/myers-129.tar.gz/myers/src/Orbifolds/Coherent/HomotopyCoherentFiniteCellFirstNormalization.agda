{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellFirstNormalization where

-- Normalize the finite first projection before Power specialization.
-- The auxiliary strict transition uses the actual packet endpoint, so its
-- target is already the first endpoint of the raw lower path.
open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as Triangles
import Orbifolds.Coherent.HomotopyCoherentColimitStages as OriginalStages
import Orbifolds.Coherent.HomotopyCoherentColimitSuccessor as OriginalSuccessor
import Orbifolds.Coherent.NaturalQuotedCellInterface as Literal
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as Pasting
import Orbifolds.Coherent.HomotopyCoherentPacketFirstProjection as FirstProjection
import Orbifolds.Coherent.HomotopyCoherentFiniteCellCoherence as FiniteCoherence
import Orbifolds.Coherent.StrictReturnedCompositeNormalization as Normalize
import Agda.Builtin.Reflection as R
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Unit using (⊤)
open import Orbifolds.Coherent.RestrictedPathInference using (assign-frozen; hidden-argument; visible-argument)

private
  names : List R.Name
  names = (quote OriginalSuccessor.Successor.transition-computation) ∷
    (quote Literal.Map.induced) ∷ (quote strict-to-path) ∷ (quote _∙_) ∷ []

  h : R.Arg R.Term
  h = hidden-argument R.unknown

  macro
    normalize-first-frozen : R.Term → R.Term → R.Term → R.Term → R.TC ⊤
    normalize-first-frozen b e p hole = assign-frozen names
      (R.def (quote Normalize.normalize-returned)
        (h ∷ h ∷ h ∷ h ∷ h ∷ visible-argument b ∷
         visible-argument e ∷ visible-argument p ∷
         visible-argument (R.con (quote reflˢ) []) ∷ [])) hole

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : Triangles.space C D E F n source → Triangles.space C G E F n target)
    (triangle : Triangles.Triangle C D G α E F n source target f) where
  module Packet = Pasting.Construction C D G α E F n source target f triangle
    using (module Packet; module ForInput)
  module Data = Packet.Packet.Inputs Packet.Packet.canonical using (Y; h)
  module First = FirstProjection.Construction.ForInput
    C D G α E F n source target f triangle Packet.Packet.canonical
    using (returned-path)
  module Finite = FiniteCoherence.Construction C D G α E F n source target f triangle
    using (endpoint; first-prefix)

  packet-transition : _
  packet-transition = OriginalStages.Construction.Step.transition-computation
    C D E F n source Data.Y Data.h

  first-bridge : _
  first-bridge = normalize-first-frozen packet-transition Finite.endpoint
    (First.returned-path Finite.endpoint)

