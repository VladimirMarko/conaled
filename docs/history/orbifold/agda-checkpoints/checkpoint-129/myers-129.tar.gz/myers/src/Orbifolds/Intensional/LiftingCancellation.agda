{-# OPTIONS --safe --without-K --no-import-sorts #-}

module Orbifolds.Intensional.LiftingCancellation where

-- Pullback cancellation for the actual mapping-space square. We first
-- transpose equivalence on its vertical fibers to equivalence on its
-- horizontal fibers. Restriction of horizontal lift fibers composes by
-- identity induction, so two-out-of-three gives the desired cancellation.
-- No quotient, completed locality, or boundary lifting is an input here.

open import Agda.Primitive using (Level; Set)
open import Orbifolds.Intensional.Equivalence
open import Orbifolds.Intensional.BoundedTruncation using (BoundedTruncation)
open import Orbifolds.Intensional.FiniteBranchAtlas using (InverseData; module Geometry)

private variable ℓ : Level

sym-involutive : {A : Set ℓ} {x y : A} → (p : x ≡ y) → sym (sym p) ≡ p
sym-involutive refl = refl

total-fiber-projection : {A B : Set ℓ} (f : A → B) → Σ B (Fiber f) → A
total-fiber-projection f (b , (a , p)) = a

total-fiber-η : {A B : Set ℓ} (f : A → B) → (z : Σ B (Fiber f))
  → (f (total-fiber-projection f z) , (total-fiber-projection f z , refl)) ≡ z
total-fiber-η f (.(f a) , (a , refl)) = refl

total-fiber-equivalence : {A B : Set ℓ} (f : A → B) → Equiv (Σ B (Fiber f)) A
total-fiber-equivalence f = equiv (total-fiber-projection f)
  (λ a → f a , (a , refl)) (λ _ → refl) (total-fiber-η f)

module Square {ℓ : Level} {A B C D : Set ℓ}
    (u : A → B) (v : C → D) (f : A → C) (g : B → D)
    (square : (a : A) → v (f a) ≡ g (u a)) where

  Pullback : Set ℓ
  Pullback = Σ B (λ b → Fiber v (g b))

  comparison : A → Pullback
  comparison a = u a , (f a , square a)

  vertical : (b : B) → Fiber u b → Fiber v (g b)
  vertical = fiber-map u v f g square

  comparison-total : (z : Σ B (Fiber u))
    → comparison (total-fiber-projection u z) ≡ Fiberwise.total vertical z
  comparison-total (.(u a) , (a , refl)) =
    cong (λ p → u a , (f a , p)) (sym (∙-right-unit (square a)))

  fiberwise→comparison : ((b : B) → isEquiv (vertical b)) → isEquiv comparison
  fiberwise→comparison e =
    cancel-left-isEquiv (total-fiber-projection u) comparison
      (equiv→isEquiv (total-fiber-equivalence u))
      (homotopy-isEquiv (Fiberwise.total vertical)
        (λ z → comparison (total-fiber-projection u z))
        (λ z → sym (comparison-total z))
        (fiberwise→total-isEquiv vertical e))

  comparison→fiberwise : isEquiv comparison → (b : B) → isEquiv (vertical b)
  comparison→fiberwise e =
    total→fiberwise-isEquiv vertical
      (homotopy-isEquiv (λ z → comparison (total-fiber-projection u z))
        (Fiberwise.total vertical) comparison-total
        (comp-isEquiv (total-fiber-projection u) comparison
          (equiv→isEquiv (total-fiber-equivalence u)) e))

  swap-comparison : Pullback → Σ C (λ c → Fiber g (v c))
  swap-comparison (b , (c , p)) = c , (b , sym p)

  swap-equivalence : Equiv Pullback (Σ C (λ c → Fiber g (v c)))
  swap-equivalence = equiv swap-comparison
    (λ { (c , (b , p)) → b , (c , sym p) })
    (λ { (c , (b , p)) → cong (λ r → c , (b , r)) (sym-involutive p) })
    (λ { (b , (c , p)) → cong (λ r → b , (c , r)) (sym-involutive p) })

-- This is the fiber criterion for the same pullback square read in the
-- other direction. Inverting the displayed commutativity path is part
-- of the actual forward map; no unrelated equivalence is substituted.
square-transpose : {A B C D : Set ℓ}
  → (u : A → B) (v : C → D) (f : A → C) (g : B → D)
  → (square : (a : A) → v (f a) ≡ g (u a))
  → ((b : B) → isEquiv (fiber-map u v f g square b))
  → (c : C) → isEquiv (fiber-map f g u v (λ a → sym (square a)) c)
square-transpose u v f g square vertical =
  Transposed.comparison→fiberwise
    (comp-isEquiv Original.comparison Original.swap-comparison
      (Original.fiberwise→comparison vertical)
      (equiv→isEquiv Original.swap-equivalence))
  where
  module Original = Square u v f g square
  module Transposed = Square f g u v (λ a → sym (square a))

precompose : {A B X : Set ℓ} → (A → B) → (B → X) → A → X
precompose e h a = h (e a)

postcompose : {A X Y : Set ℓ} → (X → Y) → (A → X) → A → Y
postcompose q h a = q (h a)

Lifts : {A X Y : Set ℓ} → (X → Y) → (A → Y) → Set ℓ
Lifts q k = Fiber (postcompose q) k

restrict-lifts : {A B X Y : Set ℓ} (e : A → B) (q : X → Y) (k : B → Y)
  → Lifts q k → Lifts q (precompose e k)
restrict-lifts e q k (h , p) = precompose e h , cong (precompose e) p

HorizontalLifting : {A B X Y : Set ℓ} → (A → B) → (X → Y) → Set ℓ
HorizontalLifting {B = B} {Y = Y} e q =
  (k : B → Y) → isEquiv (restrict-lifts e q k)

restrict-lifts-compose : {A B C X Y : Set ℓ}
  → (e : A → B) (g : B → C) (q : X → Y) (k : C → Y)
  → (z : Lifts q k)
  → restrict-lifts (λ a → g (e a)) q k z
    ≡ restrict-lifts e q (precompose g k) (restrict-lifts g q k z)
restrict-lifts-compose e g q k (h , refl) = refl

horizontal-right-cancel : {A B C X Y : Set ℓ}
  → (e : A → B) (g : B → C) (q : X → Y)
  → HorizontalLifting e q
  → HorizontalLifting (λ a → g (e a)) q
  → HorizontalLifting g q
horizontal-right-cancel e g q along-e along-composite k =
  cancel-right-isEquiv (restrict-lifts g q k)
    (restrict-lifts e q (precompose g k))
    (homotopy-isEquiv (restrict-lifts (λ a → g (e a)) q k)
      (λ z → restrict-lifts e q (precompose g k) (restrict-lifts g q k z))
      (restrict-lifts-compose e g q k) (along-composite k))
    (along-e (precompose g k))

-- Compatibility with the exact interface accepted in checkpoint 074.
-- T and ext enter only because that earlier Geometry module carries
-- them as parameters; this cancellation proof calls neither truncation
-- nor function extensionality.
module Existing {ℓ : Level} (T : BoundedTruncation ℓ) (ext : FunExt ℓ ℓ) where
  module G = Geometry T ext

  right-orthogonal→horizontal : {A B X Y : Set ℓ}
    → (e : A → B) (q : X → Y)
    → G.RightOrthogonal e q → HorizontalLifting e q
  right-orthogonal→horizontal e q orthogonal =
    square-transpose (precompose e) (precompose e) (postcompose q) (postcompose q)
      (λ _ → refl)
      (λ k → inverseData→isEquiv (G.mapExtension q e k) (orthogonal k))

  horizontal→right-orthogonal : {A B X Y : Set ℓ}
    → (e : A → B) (q : X → Y)
    → HorizontalLifting e q → G.RightOrthogonal e q
  horizontal→right-orthogonal e q lifting k =
    isEquiv→InverseData (G.mapExtension q e k)
      (square-transpose (postcompose q) (postcompose q) (precompose e) (precompose e)
        (λ _ → refl) lifting k)

  right-orthogonal-right-cancel : {A B C X Y : Set ℓ}
    → (e : A → B) (g : B → C) (q : X → Y)
    → G.RightOrthogonal e q
    → G.RightOrthogonal (λ a → g (e a)) q
    → G.RightOrthogonal g q
  right-orthogonal-right-cancel e g q along-e along-composite =
    horizontal→right-orthogonal g q
      (horizontal-right-cancel e g q
        (right-orthogonal→horizontal e q along-e)
        (right-orthogonal→horizontal (λ a → g (e a)) q along-composite))

  -- A gap need preserve the chosen base only by a specified path of
  -- functions. The path transports the SE vertex's based lifting to
  -- the actual composite before cancellation is applied.
  based-gap-lifting : {B C X Y : Set ℓ}
    → (base : Unit {ℓ} → B) (target-base : Unit {ℓ} → C)
    → (gap : B → C) (q : X → Y)
    → (λ t → gap (base t)) ≡ target-base
    → G.RightOrthogonal base q → G.RightOrthogonal target-base q
    → G.RightOrthogonal gap q
  based-gap-lifting base target-base gap q triangle at-base at-target =
    right-orthogonal-right-cancel base gap q at-base
      (subst (λ point → G.RightOrthogonal point q) (sym triangle) at-target)
