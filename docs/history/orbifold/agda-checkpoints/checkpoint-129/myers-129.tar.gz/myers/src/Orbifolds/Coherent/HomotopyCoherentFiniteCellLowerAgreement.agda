{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion --two-level #-}
module Orbifolds.Coherent.HomotopyCoherentFiniteCellLowerAgreement where

-- A generic strict certificate for the unchanged lower factor, before
-- specialization. The original packet and public lower paths are used.

open import Cubical.Foundations.Prelude
open import Orbifolds.Coherent.StrictEnriched hiding (Diagram)
open import Orbifolds.Coherent.StrictInnerFunctionExtensionality
open import Orbifolds.Coherent.OuterBarChains using (Dim)
open import Orbifolds.Coherent.OuterCubicalFaces using (StrictCubicalExtensionality)
open import Orbifolds.Coherent.StrictLowerPathInference using (component-reflexivity)
import Orbifolds.Coherent.HomotopyCoherentDiagrams as HC
import Orbifolds.Coherent.HomotopyCoherentTransformations as Transformations
import Orbifolds.Coherent.HomotopyCoherentRepresentedStages as Represented
import Orbifolds.Coherent.HomotopyCoherentFiniteTriangleTypes as TriangleTypes
import Orbifolds.Coherent.HomotopyCoherentColimitPacketPasting as Pasting
import Orbifolds.Coherent.HomotopyCoherentColimitStepData as StepData
import Orbifolds.Coherent.HomotopyCoherentUnifiedLiteralFiniteCellMaps as CellMaps

module Construction {ℓ : Level} (C : Category ℓ ℓ)
    (D G : HC.ForCategory.Diagram C)
    (α : Transformations.ForCategory.Transformation C D G)
    (E : StrictCubicalExtensionality ℓ) (F : StrictFunctionExtensionality ℓ)
    (n : Dim)
    (source : Represented.Induction.Represented C D E F n)
    (target : Represented.Induction.Represented C G E F n)
    (f : TriangleTypes.space C D E F n source → TriangleTypes.space C G E F n target)
    (triangle : TriangleTypes.Triangle C D G α E F n source target f) where
  module P = Pasting.Construction C D G α E F n source target f triangle
    using (module Packet)

  public-lower : _
  public-lower = CellMaps.Construction.At.lower-path
    C D G α E F n source target f triangle
    (StepData.Step.Realize C G E F n target)
    (StepData.Step.include C G E F n target)

  packet-lower : _
  packet-lower = Pasting.Construction.ForInput.lower-path
    C D G α E F n source target f triangle P.Packet.canonical

  -- Orientation: outer public-lower ≡ˢ outer packet-lower, matching the
  -- already checked power-instance comparison's orientation and helper.
  lower-agreement : _
  lower-agreement = component-reflexivity public-lower packet-lower

  -- The reverse certificate rewrites the packet factor to the public one.
  lower-to-public : _
  lower-to-public = strict-sym lower-agreement
