{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.IntegerPairMatrices where

-- Every additive homomorphism Z² -> Z² has its actual integer matrix.
-- An additive equivalence gives inverse matrices, so its determinant
-- is proved to be +1 or -1.  No linearity, matrix representation, or
-- determinant-sign assumption is added to the automorphism.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Function
open import Cubical.Foundations.Equiv
open import Cubical.Foundations.Isomorphism
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.Int using (ℤ; pos; negsuc)
open import Cubical.Data.Sum using (_⊎_; inl; inr)
open import Cubical.Algebra.CommRing.Base
open import Cubical.Algebra.CommRing.Instances.Int using (ℤCommRing)
open import Cubical.Algebra.Ring.Properties using (module RingTheory)
open import Cubical.Algebra.Group.Base
open import Cubical.Algebra.Group.DirProd
open import Cubical.Algebra.Group.Morphisms
open import Cubical.Algebra.Group.MorphismProperties
open import Cubical.Algebra.Group.Instances.Int using (ℤGroup; ℤHom)
open import Cubical.Algebra.Group.ZAction using (_ℤ[_]·_; homPresℤ·; ℤ·≡·; ℤEquiv1)
open import Cubical.Tactics.CommRingSolver
import Orbifolds.SpecialLinearTwo as SL

module Z = CommRingStr (ℤCommRing .snd)
module ZRing = RingTheory (CommRing→Ring ℤCommRing)
module Mat = SL.Integers

Pairs : Group ℓ-zero
Pairs = DirProd ℤGroup ℤGroup

module P = GroupStr (Pairs .snd)

projection₁ projection₂ : GroupHom Pairs ℤGroup
projection₁ = fst , makeIsGroupHom (λ _ _ → refl)
projection₂ = snd , makeIsGroupHom (λ _ _ → refl)

integer-multiplication : (n : ℤ) (v : ℤ × ℤ)
  → n ℤ[ Pairs ]· v ≡ (Z._·_ n (v .fst) , Z._·_ n (v .snd))
integer-multiplication n v = cong₂ _,_
  (homPresℤ· projection₁ v n ∙ sym (ℤ·≡· n (v .fst)))
  (homPresℤ· projection₂ v n ∙ sym (ℤ·≡· n (v .snd)))

abstract
  pair-decomposition : (v : ℤ × ℤ)
    → v ≡ P._·_ (v .fst ℤ[ Pairs ]· Mat.basis₁) (v .snd ℤ[ Pairs ]· Mat.basis₂)
  pair-decomposition (m , n) = sym
    (cong₂ P._·_ (integer-multiplication m Mat.basis₁) (integer-multiplication n Mat.basis₂)
      ∙ cong₂ _,_
        (cong₂ Z._+_ (Z.·IdR m) (ZRing.0RightAnnihilates n) ∙ Z.+IdR m)
        (cong₂ Z._+_ (ZRing.0RightAnnihilates m) (Z.·IdR n) ∙ Z.+IdL n))

coefficients : GroupHom Pairs Pairs → Mat.Matrix
coefficients f = Mat.matrix (f .fst Mat.basis₁ .fst) (f .fst Mat.basis₂ .fst)
  (f .fst Mat.basis₁ .snd) (f .fst Mat.basis₂ .snd)

abstract
  homomorphism-is-matrix : (f : GroupHom Pairs Pairs) (v : ℤ × ℤ)
    → f .fst v ≡ Mat.apply-matrix (coefficients f) v
  homomorphism-is-matrix f (m , n) =
    cong (f .fst) (pair-decomposition (m , n))
    ∙ IsGroupHom.pres· (f .snd) (m ℤ[ Pairs ]· Mat.basis₁) (n ℤ[ Pairs ]· Mat.basis₂)
    ∙ cong₂ P._·_ (homPresℤ· f Mat.basis₁ m) (homPresℤ· f Mat.basis₂ n)
    ∙ cong₂ P._·_ (integer-multiplication m (f .fst Mat.basis₁))
        (integer-multiplication n (f .fst Mat.basis₂))
    ∙ cong₂ _,_ (solve! ℤCommRing) (solve! ℤCommRing)

  matrix-additive : (M : Mat.Matrix) (v w : ℤ × ℤ)
    → Mat.apply-matrix M (P._·_ v w) ≡ P._·_ (Mat.apply-matrix M v) (Mat.apply-matrix M w)
  matrix-additive M v w = cong₂ _,_ (solve! ℤCommRing) (solve! ℤCommRing)

matrix-homomorphism : Mat.Matrix → GroupHom Pairs Pairs
matrix-homomorphism M = Mat.apply-matrix M , makeIsGroupHom (matrix-additive M)

abstract
  coefficients-matrix : (M : Mat.Matrix) → coefficients (matrix-homomorphism M) ≡ M
  coefficients-matrix M = Mat.matrix-path
    (cong fst (Mat.apply-basis₁ M)) (cong fst (Mat.apply-basis₂ M))
    (cong snd (Mat.apply-basis₁ M)) (cong snd (Mat.apply-basis₂ M))

  matrix-coefficients : (f : GroupHom Pairs Pairs) → matrix-homomorphism (coefficients f) ≡ f
  matrix-coefficients f = Σ≡Prop (λ _ → isPropIsGroupHom Pairs Pairs)
    (funExt λ v → sym (homomorphism-is-matrix f v))

matrix≃additive-homomorphism : Mat.Matrix ≃ GroupHom Pairs Pairs
matrix≃additive-homomorphism = isoToEquiv (iso matrix-homomorphism coefficients
  matrix-coefficients coefficients-matrix)

abstract
  matrix-action-faithful : {M N : Mat.Matrix}
    → ((v : ℤ × ℤ) → Mat.apply-matrix M v ≡ Mat.apply-matrix N v) → M ≡ N
  matrix-action-faithful {M} {N} equal = Mat.matrix-path
    (cong fst first) (cong fst second) (cong snd first) (cong snd second)
    where
    first : (Mat.a M , Mat.c M) ≡ (Mat.a N , Mat.c N)
    first = sym (Mat.apply-basis₁ M) ∙ equal Mat.basis₁ ∙ Mat.apply-basis₁ N
    second : (Mat.b M , Mat.d M) ≡ (Mat.b N , Mat.d N)
    second = sym (Mat.apply-basis₂ M) ∙ equal Mat.basis₂ ∙ Mat.apply-basis₂ N

  integer-unit-sign : (d e : ℤ) → Z._·_ d e ≡ pos 1 → (d ≡ pos 1) ⊎ (d ≡ negsuc 0)
  integer-unit-sign d e unit with ℤEquiv1 multiply-equivalence
    where
    right : (x : ℤ) → Z._·_ d (Z._·_ e x) ≡ x
    right x = Z.·Assoc d e x ∙ cong (λ t → Z._·_ t x) unit ∙ Z.·IdL x
    left : (x : ℤ) → Z._·_ e (Z._·_ d x) ≡ x
    left x = Z.·Assoc e d x ∙ cong (λ t → Z._·_ t x) (Z.·Comm e d ∙ unit) ∙ Z.·IdL x
    multiply-equivalence : GroupEquiv ℤGroup ℤGroup
    multiply-equivalence = isoToEquiv (iso (Z._·_ d) (Z._·_ e) right left) , ℤHom d .snd
  ... | inl p = inl (sym (Z.·IdR d) ∙ p)
  ... | inr p = inr (sym (Z.·IdR d) ∙ p)

module Automorphism (e : GroupEquiv Pairs Pairs) where
  forward backward : GroupHom Pairs Pairs
  forward = e .fst .fst , e .snd
  backward = invEq (e .fst) , invGroupEquiv e .snd

  matrix inverse-matrix : Mat.Matrix
  matrix = coefficients forward
  inverse-matrix = coefficients backward

  abstract
    action-right-inverse : (v : ℤ × ℤ)
      → Mat.apply-matrix matrix (Mat.apply-matrix inverse-matrix v) ≡ v
    action-right-inverse v =
      sym (homomorphism-is-matrix forward (Mat.apply-matrix inverse-matrix v))
      ∙ cong (forward .fst) (sym (homomorphism-is-matrix backward v)) ∙ secEq (e .fst) v

    action-left-inverse : (v : ℤ × ℤ)
      → Mat.apply-matrix inverse-matrix (Mat.apply-matrix matrix v) ≡ v
    action-left-inverse v =
      sym (homomorphism-is-matrix backward (Mat.apply-matrix matrix v))
      ∙ cong (backward .fst) (sym (homomorphism-is-matrix forward v)) ∙ retEq (e .fst) v

    matrix-right-inverse : Mat.multiply matrix inverse-matrix ≡ Mat.identity-matrix
    matrix-right-inverse = matrix-action-faithful λ v → Mat.apply-product matrix inverse-matrix v
      ∙ action-right-inverse v ∙ sym (Mat.apply-identity v)

    matrix-left-inverse : Mat.multiply inverse-matrix matrix ≡ Mat.identity-matrix
    matrix-left-inverse = matrix-action-faithful λ v → Mat.apply-product inverse-matrix matrix v
      ∙ action-left-inverse v ∙ sym (Mat.apply-identity v)

    determinant-invertible : Z._·_ (Mat.determinant matrix) (Mat.determinant inverse-matrix) ≡ pos 1
    determinant-invertible = sym (Mat.determinant-product matrix inverse-matrix)
      ∙ cong Mat.determinant matrix-right-inverse ∙ Mat.determinant-identity

    determinant-sign : (Mat.determinant matrix ≡ pos 1) ⊎ (Mat.determinant matrix ≡ negsuc 0)
    determinant-sign = integer-unit-sign (Mat.determinant matrix) (Mat.determinant inverse-matrix)
      determinant-invertible
