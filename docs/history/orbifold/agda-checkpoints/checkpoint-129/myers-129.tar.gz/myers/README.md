# Myers orbifolds formalization

A current, resumable workspace—not an archive of prior workspaces. The full
formalization and cross-setting interpretation are unfinished.

The [purpose and preservation contract](docs/checkpoints.md) governs every
successor. Its purpose takes priority over secondary packaging choices; deliberate
changes must preserve recovery, current useful content and mathematical honesty.

## Where each concern lives

| Concern | Single authoritative location |
| --- | --- |
| Install, restore, check, and diagnose the environment | [docs/environment.md](docs/environment.md) |
| Make a compact checkpoint, only when there is progress | [docs/checkpoints.md](docs/checkpoints.md) |
| Mathematical goals, trust boundaries, and working rules | [docs/project.md](docs/project.md) |
| Current effort, blockers, and next actions | [docs/work.md](docs/work.md) |
| Paper mathematics and correspondence | [math/index.md](math/index.md) |
| Original project Agda | `src/` |
| Exact current source identity and accepted/pending classification | `state.json` |
| Compiler, library, reference, and native-protocol pins | `environment.json` |
| Raw evidence supporting the source ledger | `evidence/` |
| Selected upstream Lean and research material | `references/` |
| Included offline dependencies | `vendor/` |
| Workspace operations | `tools/myers.py` |

`manifest.json` is generated packaging integrity data, not a second proof-status
ledger. `.build/` is disposable runtime state and is never included in a checkpoint.
There is one canonical file per Agda module; pending work is not stored in a
parallel source tree. Read the project rules and current effort before editing.
