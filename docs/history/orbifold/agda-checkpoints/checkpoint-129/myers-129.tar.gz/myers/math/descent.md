# Finite-action torsors and fixed-cover descent

This chapter owns the current mathematics, constructions and interpretation boundary.
Exact native acceptance belongs to `../state.json`, not to this prose. The
construction is set-level and uses discrete group labels. It does not identify a
set quotient with the ambient higher quotient or a quotient in a smooth stack model.

## Literal trivial torsors and arrow families

For `m : Z → M`, the literal trivial torsor is `G × Z`, with right action
`(k,z)·h = (k*h,z)` and anchor `act(inverse k)(m z)`. A label family `c : Z → G`
acts by `(k,z) ↦ (c(z)*k,z)`. Evaluation at the unit recovers the label. A label
`g` followed by `h` composes as `h*g` in the action-groupoid convention; this is
consistent with successive left multiplications on right torsors.

`TrivialActionTorsorMaps` has passed its complete ordinary-mode native gate.
It constructs the actual continuous, equivariant, anchor-preserving maps of
literal trivial torsors, their inverse maps and homeomorphisms, and identity,
composition, inverse and restriction equations. Its general fiberwise maps
have carrier `Z → G → G`; the group-label families are a specified subclass.
There is no sethood hypothesis on Z. Group/action laws, sethood of G and X,
and continuity of the individual action maps remain explicit.
`FiniteActionTrivialTorsorComparison` retains its separate pending gate for
the categorical-arrow/represented-path comparison. Equalities of full bundled
families retain the stated openness-proposition and two function-
extensionality assumptions. An ambient quotient-path family is admitted here
only with the precise local-constancy condition on its recovered labels. Arbitrary
ambient path families are not thereby smooth.

## Independent transition data and the actual fiber quotient

`CechTorsorQuotient.TransitionData` takes a group `G`, a type `C` of local chart
witnesses, transitions `c_ab`, and the equations

```
c_aa = 1,                 c_bc * c_ab = c_ac.
```

For a base point `z` of a covered space, `C` is the actual witness type
`Σ i, U_i(z)`. Membership witnesses are retained. Labels, chart witnesses and
values may live in independent universes in the algebraic construction.
No quotient, chart equivalence, global representative or torsor certificate is an
input. The fiber is the actual Cubical set quotient of `C × G` by

```
(a,g) ~ (b,h)    when    h = c_ab * g.
```

Fixing `a : C` defines `chart_a(g) = [a,g]` and
`recover_a([b,g]) = c_ba*g`. To verify that recovery respects the relation,
substitute `h = c_bc*g` and use `c_ca*c_bc = c_ba`. The diagonal law gives
`recover_a(chart_a(g)) = g`; the quotient's generating path gives
`chart_a(recover_a(q)) = q`. The source proves both laws and packages this exact
chart and recovery as an equivalence.

Right multiplication descends as `[a,g]·h = [a,g*h]`. Its unit, associativity and
recovery-equivariance equations are proved. For every actual fiber element `q`,
the map `h ↦ q·h` is an equivalence. At `[a,k]` its inverse is
`q' ↦ inverse(k)*recover_a(q')`; the two cancellation laws prove the inverse
identities. Quotient induction extends the proof because `isEquiv` of this fixed
map is a proposition. This is not elimination into a chosen global representative.

Mere coverage `∥C∥` yields `∥Fiber∥` and `∥G ≃ Fiber∥`. Neither result removes the
truncation or chooses a local chart at every base point.

## Compatible maps, anchors and gauge arrows

For an actual set `A` and local maps `f_a : G → A` satisfying
`f_b(c_ab*g) = f_a(g)`, `Descent.glue` constructs `Fiber → A`. It proves the chart
computation equation and uniqueness as equality of functions, by quotient
induction and function extensionality. Set-hood of the target is explicit.

For a left action on a set `X`, local objects satisfying `c_ab·m_a = m_b` give

```
anchor([a,g]) = inverse(g)·m_a,
anchor(q·h)   = inverse(h)·anchor(q).
```

The proof uses inverse multiplication order, not commutativity. The action need
not be effective. `CechTorsorOrdinaryBridge` accepts the project's actual ordinary
group/action operations and inductive identity proofs, constructs the Cubical
instance, and returns chart/orbit equivalences, action laws and the anchor in the
ordinary identity interface. Both equality conversions are explicit. This is not
a semantic interpretation of the crisp/cohesive language or a Lean proof import.

`CechTorsorGauge` constructs arrows between independent cocycles `c` and `d`.
Its input is a local coefficient `b_a` with the actual overlap equation

```
d_ab * b_a = b_b * c_ab.
```

The resulting map is `[a,g]_c ↦ [a,b_a*g]_d`. The equation above, with associativity,
proves well-definedness. The inverse coefficient is `inverse(b_a)`; its overlap
law is derived, not assumed. The source constructs both inverse laws, right-action
equivariance, identity and composition compatibility, and naturality under chart
refinement. These equivalences do not need coverage, even when both quotient
fibers are empty. With local anchor equations `b_a·m_a = n_a`, the map preserves
the descended anchors; the proof is again local inverse-order algebra followed
by quotient induction.

## Refinement, without selecting charts

`CechTorsorRefinement` takes `r : D → C` and the actual pulled-back transition
data. It constructs the map `[a,g] ↦ [r(a),g]`, proves its chart and action equations,
and proves that recoveries commute. Any `a : D` gives the inverse
`q ↦ chart_a(recover_{r(a)}(q))`, with both inverse laws.

Since `isEquiv` of the constructed map is a proposition, mere inhabitation `∥D∥`
suffices to prove it an equivalence. The resulting equivalence has exactly that
map. The construction proves identity and composition of refinements as
pointwise equations and whole-function equations; gauge arrows satisfy the
corresponding naturality square. This fiberwise result is distinct from a
comparison of topological or smooth families on all covers.

## Actual total space and topology

`Intensional.FinalTopology` constructs the final `OpenFragment` of an actual
small family of maps `j_i : A_i → Q`. Openness is defined by openness of every
actual preimage. The ordinary open operations, continuity of the chart maps,
and both directions of the continuous-out-of-final-space criterion are proved.
The same criterion is constructed on an open subspace via restricted charts.
No arbitrary continuity certificate or openness predicate is assumed irrelevant.
A family that is not jointly surjective still defines this final topology; no
coverage is inferred from the topology's existence.

`CechTorsorTotalSpace` uses an open family `U_i` of an actual ordinary open-fragment
space `Z`, and independent transition data at each `z`. It constructs the total
space `Σ z, Fiber(z)` and the canonical chart maps

```
U_i → Total,       (z,p) ↦ (z,[(i,p),g])          for each fixed g.
```

The actual inductive-identity fiber of the projection is explicitly equivalent
to the constructed quotient fiber. The actual right-action orbit map on that
fiber is an equivalence, with both inverse laws and the exact map equation;
mere coverage gives merely inhabited actual fibers.

The topology is the final topology of these precise maps, not an unspecified
quotient-topology input. It constructs continuity of the projection, fixed-label
and full discrete-group right action, and the descended anchor when the original
local object maps and action branches are continuous. Compatible continuous local
maps glue to a continuous global map with chart computations and uniqueness.

Over `U_i`, the source constructs an actual equivalence
`G × U_i ≃ projection⁻¹(U_i)` and proves continuity of its forward map. The
backward map uses the previously constructed recovery. In general its continuity
does not follow from algebraic cocycle equations alone.

`CechTorsorLocalCharts` states the needed regularity on the *original* transition
functions over actual overlaps: their label fibers are open, that is, they are
locally constant. On the overlap from chart `j` to `i`, the inverse coordinates
are `(c_ji(z)*g,(z,p_i))`. Existing locally-constant-label lemmas construct their
continuity into the coproduct topology, and the restricted final-topology
criterion then gives continuity of the global backward chart. Both directions
are bundled into the existing ordinary `Homeomorphism` interface, with the
projection triangle. The ordinary topology interface uses a shared small
universe for its carriers; no resizing is introduced.

`CechTorsorTopologicalGauge` joins the algebraic and topological constructions
on the same specified open family. Locally constant local gauge coefficients
give a continuous map of the actual total spaces, commuting with projection and
right action. Inverting the coefficients preserves local constancy. Both inverse
laws and both continuity proofs are packaged in the existing ordinary
`Homeomorphism` interface. Composition agrees with multiplication of the local
coefficients, and the composite remains locally constant. This uses no coverage
choice and no assertion that all underlying ambient quotient paths are continuous.
The algebraic anchor-preservation theorem applies to the same fiber maps when
its stated local anchor equations hold.

## Recovery of torsors and their full gauge morphisms

`CechTorsorRecovery` starts in the opposite direction: from a set-valued
right action whose orbit map at *each supplied point* is an equivalence, and
local sections `s : C → P`. The action division operation uniquely solves
`right(s_b, transition(a,b)) = s_a`, constructing the cocycle laws rather
than importing an assumed transition datum. The comparison from the actual
reconstructed set quotient to `P` is the descended map induced by
`(a,g) ↦ right(s_a,g)`. Its selected inverse and both laws are proved after
supplying any one chart; mere inhabitation `∥C∥` suffices to produce the
comparison equivalence without choosing a chart. An existing anchor that
reverses the right action is recovered from the descended anchor, including
the local object matching equation. This is algebraic effective recovery, not
an all-cover sheaf or higher-stack theorem.

`CechTorsorGaugeRecovery` reverses the gauge-map construction on the *actual*
quotient fibers: a supplied right-equivariant map yields coefficients by
comparing its value on each unit chart with the target's chart recovery.
Equivariance and equality of the images of overlapping charts derive the
coefficient equation `d_ab*b_a = b_b*c_ab`. The canonical map from those
coefficients recovers the original map, with inverse laws, identity and
composition proved on the arrow functions rather than inferred from anchors.
`CechTorsorAnchoredGaugeRecovery` restricts this equivalence to maps
preserving the descended anchor, deriving the local anchor matching law from
that preservation. The existing noncommuting/ineffective controls are extended
by `CechTorsorRecoveryControls`: different gauge labels remain different
underlying arrows even when their anchors coincide; a constant map that fails
equivariance is rejected.

There is also a **regularity converse** on one fixed open family.
`Intensional.ContinuousLabelRecovery` proves that continuity into the
coproduct of label slices makes the extracted label locally constant.
`CechTorsorContinuousGaugeRecovery` applies this to the inverse local charts
of the *target*, under the explicit hypothesis that its transitions are
locally constant. It derives local constancy of recovered gauge coefficients
from continuity of the actual equivariant total-space map; continuity of the
coefficients is not an input. The already constructed forward map takes
locally constant gauges to continuous equivariant maps. When openness proofs
are proposition-valued (`OpenIsProp`), it packages these maps with their
regularity certificates into an equivalence, whose inverse laws retain the
underlying maps and are justified by proof irrelevance only for certificates.
The target-transition regularity and `OpenIsProp` hypotheses cannot be dropped
from the corresponding claims. This does not prove arbitrary change-of-cover,
smooth compatibility or unrestricted internal properness.

## Merely-local openness and topological change of cover

The record `OpenFragment` supplies locality for **chosen** open neighborhoods.
Mere coverage only supplies a truncated chart witness at each point. Eliminating
that truncation into a chosen neighborhood, or choosing neighborhoods uniformly,
is not justified by the existing record. `MerelyLocalOpenFragment.MerelyLocal`
states exactly the additional neighborhood law used here: a subset is open when
each of its points merely admits an open neighborhood contained in it. The
neighborhood type remains in the successor universe; there is no resizing.
The source constructs preservation of this law by open subspaces and final
chart topologies, and derives continuity from a merely covering open family.
It does not identify this law with mere proof irrelevance of openness.

`RationalBallMereLocality` constructs this law for the existing rational-ball
open fragment. Given a merely supplied neighborhood, its openness at the point
merely supplies a positive rational radius. Compose the neighborhood inclusion
with the radius inclusion and eliminate into the truncated radius-witness type.
Thus the construction returns neither a chart selector nor a radius selector.
It applies uniformly to the existing Dedekind-line and finite Cartesian metric
instances, through their actual `RationalBallOpenness.Construction` definitions.

Let the fine cover `(V_j)` refine `(U_i)` through `r : J → I` and inclusions
`V_j ⊆ U_(r j)`. Pull back the transition cocycle along the actual membership map
`(j,v) ↦ (r j, include v)`. `CechTorsorTopologicalRefinement` constructs

    (z, [j,g]) ↦ (z, [r j,g])

between the existing total spaces and proves continuity by their chart-final
topologies. No cover hypothesis is needed for that forward map. Mere fine
coverage makes its already constructed fiber map an equivalence. On `V_j`, the
inverse recovers the coarse label in chart `r j` and uses the fine chart `j`.
Locally constant **coarse** transition functions prove continuity of these local
inverses: on overlap with coarse chart `i`, the new label is `c_(i,r j)(z) * g`.
The merely-local law then glues continuity of the inverse over the mere fine
cover. The outcome is a homeomorphism whose forward map is exactly refinement,
with the projection triangle and equivariance law, not an unrelated equivalence.

`CechTorsorTopologicalRefinementLaws` proves identity and composition of these
actual maps. Its inverse-composition law follows from the two inverse laws and
the forward-composition equation. It does not identify coverage witnesses or
select chart representatives. Equality is asserted for the underlying maps, not
for arbitrary continuity certificates.

## Parameter change and its refinement square

For a continuous `f : W → Z`, `CechTorsorBaseChange` uses the literal preimage
cover `f⁻¹(U_i)` and the cocycle at `f(w)`. Its total carrier is the actual
dependent sum `Σ w. Fiber(f(w))`, and the map to the old total space is
`(w,q) ↦ (f(w),q)`. The chart square, projection square and equivariance compute
on these maps. Continuity follows by composing the original chart with the
restricted parameter map. Transition local constancy is pulled back along the
actual overlap map. Coverage is preserved simply by evaluating the old mere
coverage at `f(w)`. Identity and iterated parameter-change equations retain the
same quotient fibers and are proved for the underlying total-space functions.

`CechTorsorRefinementBaseChange` compares refining before parameter change with
refining the literal pulled-back covers. Its forward square computes on the
actual quotient maps. With mere fine coverage, its inverse square is derived:
apply the original inverse to the forward square at the pulled-back inverse,
then use both section/retraction laws. No extra compatibility equation or
inverse square is supplied as an input.

`CechTorsorGaugeBaseChange` extends parameter restriction to the actual
continuous gauge arrows. Restrict a coefficient by evaluating it at `f(w)`;
local constancy pulls back along the actual map of covering domains. The square
between the old and pulled gauge maps commutes on total-space elements, and so
does the inverse square. Identity and multiplication order are retained in the
coefficient laws and the map-composition theorem. No faithfulness of restriction
along an arbitrary parameter map is asserted. Continuity certificates are not
silently identified.

## The actual continuous pullback lift

`Orbifolds.Intensional.DependentSumPullback` compares the split total
`Sigma w. Fiber(f(w))` with the actual dependent identity-fiber pullback

    Sigma w. Sigma p : OriginalTotal. projection(p) = f(w).

The forward map inserts reflexivity. The reverse map transports the fiber
component along the supplied base equality. Both inverse laws are proved by
identity elimination. This carrier equivalence needs no setness assumption.
For uniqueness from the two separate projection equations, the old base must
be a set: that hypothesis identifies the residual loop in the base. It is
explicit in `joint-injective`, not unrestricted K for arbitrary types.

`CechTorsorBaseChangePullback` proves the topological part rather than inferring
it from the carrier formula. Let `a : A -> W` and `b : A -> OriginalTotal` be
continuous with `projection(b(t)) = f(a(t))`. Construct

    lift(t) = (a(t), transport Fiber square(t) (second(b(t)))).

On the part where `a(t)` belongs to the pulled chart `i`, the old chart inverse
recovers the label of `b(t)`. Its continuity makes that label locally constant.
The pulled chart applied to this label and `a(t)` is continuous, and identity
elimination proves that it agrees with the displayed transported lift. Mere
coverage and the **domain's** `MerelyLocal` law then give global continuity.
The two triangles hold for these actual maps. Setness of the old base gives
pointwise and whole-function uniqueness, not an assumed universal property.
The pulled total's merely-local law is separately constructed from that of W.

The precise domain of this topological universal property is the class of
merely-local open fragments, with the stated locally constant transitions and
mere cover. It is not a claim about arbitrary `OpenFragment` records or an
unrestricted higher categorical pullback. The quotient fibers are sets; the
whole dependent total need not be declared a set unless its base is one.
`DedekindMereLocality` supplies actual real-line, finite Cartesian (including
zero-dimensional), and open-subspace instances of the required domain law.

`CechTorsorEquivariantPullback` adds the group action without a new choice. If
`a` is invariant under an action on A and `b` is equivariant, then the two
projections of `lift(t*g)` and `lift(t)*g` agree. The proved joint injectivity
therefore makes the constructed continuous lift equivariant. The action on A
and its compatibility with the input cone are input data; equivariance of the
lift is a conclusion.

These are universal-property, parameter-map and change-of-cover theorems for
the constructed topological torsors. They are not yet an interpretation of all
generated source substitutions, a smooth/formal upgrade, or higher stack
descent. Exact native-check status for each current module is in the source
ledger, not inferred from this mathematical account.

## Recovery of existing bundles and naturality on actual maps

`CechTorsorRecoveryNaturality` connects the object recovery construction to
arrows between independently supplied principal right actions. For actions on
P and Q, local sections s_i and t_i, and an actual equivariant function f:P→Q,
its coefficient is

    c_i = divide_Q(t_i, f(s_i)).

Thus t_i·c_i = f(s_i), and equivariance gives
`t_i·(c_i g) = f(s_i·g)`. Applying freeness at t_j to this equation and the two
section-transition equations proves `e_ij c_i = c_j d_ij`. The coefficient is
therefore an actual gauge. Quotient elimination proves the entire comparison
square `comparison_Q ∘ gaugeMap = f ∘ comparison_P`. Mere inhabitation of the
index type supplies isEquiv of the object comparisons; the inverse square
then follows without selecting any global index. The same argument constructs
isEquiv of f under mere coverage. Identity and composition of the extracted
gauges are proved as equalities of the complete gauges, preserving the order
`c_g · c_f`, not just the endpoints or anchor values.

`CechTorsorTopologicalRecovery` applies this object construction fiberwise to
an existing total space `Sigma z. P(z)` with its supplied topology. Input consists
of actual principal fiber actions, sections over an open family U_i, continuous
projection, continuous sections and action maps, and local constancy of the
*existing* division coordinate relative to each section. The last condition
expresses local regularity of this discrete principal bundle; it is not
continuity of the desired comparison, or an assumed gluing equivalence.

The recovered cocycle is `d_ij(z)=divide(s_j(z),s_i(z))`. Its locally constant
transition law is derived, by restricting s_i to an overlap and applying the
j-division coordinate. No transition-regularity conclusion is an input.
The quotient uses the existing actual final topology. Its forward comparison
is continuous because its restriction on sheet (i,g) is `s_i(z)·g`, a composite
of the supplied continuous section and action maps.

Under mere coverage, fiberwise algebraic recovery gives an inverse, with no
chosen representative. On the inverse image of U_i in the existing total,
that inverse agrees with `[i, divide(s_i(z),p)]`. This local expression is
continuous: division is locally constant, the base coordinate is continuous,
and the quotient chart is continuous by its construction. The existing total
space's explicitly supplied `MerelyLocal` law glues these local continuity
proofs across the mere cover. Both inverse laws, both projection triangles,
and equivariance in both directions hold for the actual maps.

This recovers any bundle satisfying the displayed hypotheses, not only a
bundle already defined as the constructed quotient. It works without finite
labels, an effective action, classical choice, a global section, or DPProper.
It is a topological fixed-cover construction. It does not yet supply a smooth
site, higher stack, mechanized source admission, or full categorical equivalence
of all bundles. Matching the entire continuous-arrow comparison and its
parameter substitution to the source model remains a separate proof task.

## Full comparison on actual bundle maps

`CechTorsorBundleArrowComparison` upgrades object-recovery naturality to an
actual equivalence of hom types. On a fixed merely inhabited index type C,
take two independent principal right actions on P and Q with local sections
s_i and t_i. An arrow is a function f:P→Q together with its equivariance proof,
not an assumed gauge or quotient map. Recovery extracts

    c_i = divide_Q(t_i, f(s_i)).

Conversely, a gauge u defines the actual function

    P --inverse(comparison_P)--> Quotient_P
      --gaugeMap(u)--> Quotient_Q --comparison_Q--> Q.

The inverse of the object comparison is equivariant by its two inverse laws
and the forward comparison's equivariance. Therefore the displayed composite
is an equivariant function. Its value on a local representative is
`t_i·(u_i g)`, and its value at s_i is `t_i·u_i`. The already proved naturality
square and uniqueness of division give both full round trips: gluing the
recovered gauge returns the original function, and recovering from the glued
function returns the supplied entire gauge. Proof certificates are propositions
because the principal carriers are sets. Identity and composition are preserved;
composition has coefficient `c_g · c_f` for f followed by g. Mere coverage is
used to invert the object comparisons, never to choose a global index.

The fiberwise version `CechTorsorContinuousBundleMaps` retains these functions
between existing total spaces `Sigma z. P(z)` and `Sigma z. Q(z)`. Given a
continuous equivariant family f, restrict the source section to chart i, apply
f, and corestrict to the target chart. The target's locally constant division
coordinate then proves local constancy of the extracted gauge coefficient.
This direction needs target coordinate regularity, not a global representative.
In the reverse direction, source merely-locality and source coordinate
regularity make the source recovery inverse continuous; a locally constant
gauge has a constructed continuous quotient map, and the target comparison is
continuous. Their composite is exactly the function constructed by algebraic
gluing. A pointwise comparison transfers continuity to any original function
with those recovered coefficients.

`CechTorsorContinuousBundleEquivalence` assembles both directions into an
equivalence of **bundled** continuous equivariant map families and locally
constant gauge families. Equalities of bundled objects retain explicit
`OpenIsProp` hypotheses for the base and source-total open fragments. The
underlying value maps and equivariance already have their set-valued
extensionality proofs; arbitrary openness certificates are not silently
identified. The map remains over the fixed base, and its actual right action
is preserved. This is stronger than an equivalence of pointwise functions
without their continuity data, but it is still a fixed-cover construction.

### Parameter restriction and refinement of the bundle-arrow comparison

`CechTorsorBundleBaseChange` connects this full arrow comparison to the actual
parameter and quotient-refinement maps. Its parameter part starts with a
continuous map `f:W→Z`, independent principal families `P(z),Q(z)`, sections on
the specified open family `U_i`, and mere coverage. The pulled families are
literally `P(f(w)),Q(f(w))`; their local sections are the original sections
applied to the actual chart map `(w,u)↦(f(w),u)`. Coverage is reindexed, not
replaced by a chosen chart.

Restriction of a map family or gauge family is evaluation at `f(w)`. With
these exact data, both routes through the full arrow comparison agree as
whole families:

    restrict(glue(u)) = glue(restrict(u)),
    restrict(recover(h)) = recover(restrict(h)).

The total maps are `(w,p)↦(f(w),p)`. Their base-projection and equivariance
triangles and the square for the original, independently supplied bundle map
are retained. Object recovery also commutes with these exact total maps and
the existing cocycle base-change maps. Local constancy of the restricted gauge
is derived from continuity of the actual chart map by
`CechTorsorGaugeBaseChange`; this supplies continuity and the selected square
for the constructed quotient gauge map. No conclusion about continuity for
arbitrarily chosen topologies on the independent pulled total spaces follows
merely from the dependent-pair formula.

The refinement part is not just a definitional parameter equation. Fix a map
`r:D→C` between local-section indices and mere inhabitation of `D`. It induces
mere inhabitation of `C` by mapping the truncation. Both comparisons use the
same original principal actions, with fine sections `s∘r,t∘r`. Restricting a
gauge uses the already constructed `Gauge.Refinement.restricted`, including
its compatibility equation. Recovery commutes with restriction by the actual
division formula. Applying injectivity of fine recovery and both full
arrow/gauge round trips then proves

    glue_fine(restrict(u)) = glue_coarse(u)

as equality of entire equivariant maps, including their proof certificates.
The constructed inverse to gauge restriction is

    v ↦ recover_coarse(glue_fine(v)).

Both inverse laws follow from the same squares and round trips. Surjectivity
of `r` is unnecessary: mere fine coverage already recovers the entire original
principal-action map, without choosing an index. The quotient comparison
square uses the existing refinement map on representatives; its source
inverse square follows from the actual object-comparison inverse laws. The
gauge-map square is the one already proved for this same refinement, retaining
the order of every group coefficient.

These statements concern the displayed set-valued principal actions and
topological parameter restrictions. They neither interpret native source
declarations nor supply smooth/formal pullbacks, semantic universes, higher
quotient descent, or an identification of properness predicates. Acceptance
of the source is determined only by `state.json` and its exact receipts.

### Independent pulled-total topology and continuous cones

`CechTorsorBundlePullback` now contains the source construction of the literal
independent pulled total, its output topology, actual comparison maps and
inverse laws, continuous projection/original-total map, locality transport,
and literal continuous cone lift with both triangles and uniqueness. The ledger
and applicable receipts alone determine its exact native acceptance. It uses the actual recovery
equivalences and the proved quotient pullback, rather than adding the desired
pulled topology or continuity as an input.

Keep the independent principal family `P(z)`, its sections on `U_i`, mere
coverage, and the continuous parameter map `f:W->Z` above. Supply the old
independent total's topology with continuous projection, right actions and
these local sections. Let `F(z)` be the
actual quotient of its recovered cocycle. Write `c_z:F(z)->P(z)` for the
constructed comparison and `d_z` for its inverse from
`CechTorsorRecovery.Action.Local.recovery-equivalence`. The two maps

    E : (Sigma w:W. P(f(w))) -> (Sigma w:W. F(f(w)))
    E(w,p) = (w,d_{f(w)}(p)),
    E^{-1}(w,q) = (w,c_{f(w)}(q))

are inverse by the fiber comparisons' actual round trips. Their source is
the literal independent pulled total; their target is the existing pulled
cocycle total of `CechTorsorBaseChangePullback`. Apply
`Intensional.EquivalenceTopologyTransport.Transport` to this equivalence
and the target's constructed topology. Thus a subset `V` of the independent
total is open precisely when its preimage under `E^{-1}` is open in the quotient
total. The topology and both continuous comparison maps are outputs. Obtain
the equivalence directly from the fiber comparisons, not from a new
`CechTorsorTopologicalRecovery.Construction.Topology.Covered` instance whose continuity
arguments would make this construction circular.

The selected maps remain `pi(w,p)=w` and `m(w,p)=(f(w),p)`, with old
projection `pi_Z(z,p)=z`. The
first is continuous by composition with `E` and the quotient projection.
For the second, the exact square
`m(E^{-1}(q)) = oldComparison(quotientBaseMap(q))` and the round trip for
`E` identify `m` with a composite of already continuous maps. Apply
`MerelyLocalOpenFragment.continuous-pointwise` to that equality. This step
uses the old sections/actions' continuity, but needs neither continuity of
the old recovery inverse nor a chosen chart.

For the continuous cone property, additionally assume the old independent
total is merely local and its division coordinates are locally constant.
`CechTorsorTopologicalRecovery.Construction.Topology.Covered.inverse-continuous` then
makes its actual recovery inverse continuous. Given a merely-local domain
`A`, continuous maps `a:A->W`, `b:A->Sigma z.P(z)` and the specified square
`p_x:pi_Z(b(x))=f(a(x))`, compose `b` with that old inverse. The old inverse's
base triangle gives the exact quotient cone. Apply
`CechTorsorBaseChangePullback.Construction.Regular.Cone.lift-continuous`, using the old
coordinate regularity's proved transition regularity, then compose its
lift with `E^{-1}`. The resulting continuous map equals the literal lift

    x |-> (a(x), transport_P(p_x, snd(b(x))))

from `Intensional.DependentSumPullback.Pullback.Cone`. The comparison uses
only the ordinary identity-elimination equation

    c_{z'}(transport_F(p,q)) = transport_P(p,c_z(q))

(proved at reflexivity) and `c_z(d_z(v))=v`. Consequently continuity of the
literal lift requires no setness of `Z`. Its two triangles are the existing
dependent-sum triangles. Uniqueness from just the two projection equations
retains the explicit `isSet Z` hypothesis. The source also retains
the lift's literal computation equation. Equivariance under a supplied
base-invariant, equivariant cone is constructed in the separate
structure source below, using the same joint-injectivity argument. Equality
of continuity certificates is a separate question.

`CechTorsorBundlePullbackStructure` now contains the full source assembly of
a pulled `LocallyTrivialPrincipalBundles.On.Bundle` and the equivariant
cone lift. This additive source and its pullback core have separate complete
native gates; authored source alone grants no acceptance. Its input is the independently supplied OLD bundle, with
its own projection/action/section continuity and division-coordinate
regularity, together with explicit `OpenIsProp OW` and `MerelyLocal OW`.
The new carrier and principal action are literal reindexings `P(f(w))` and
`action(f(w))`; its total and topology are precisely the core outputs above.

Mere locality is constructed in the core: mere locality of
`OW` gives mere locality of the quotient total and then of the transported
topology by mapping each mere neighborhood along `E^{-1}`. The neighborhood
truncation stays at its existing successor universe. For openness
propositionhood, openness of a subset of the quotient total is a product,
over the small chart parameters `(i,g)`, of openness in the pulled base
charts. `OpenIsProp OW` makes each factor a proposition, and the ordinary
product-proposition lemma uses the existing bridge function-extensionality
instance. For a subset `V` of the independent total, apply this result to
its preimage under `E^{-1}`. This proves the new `open-prop` field, rather
than identifying arbitrary openness or continuity certificates.

Write `rho_f((w,p),g)=(w,rho_{f(w)}(p,g))` for the literal pulled right
action and `rho_Q` for the actual quotient action. Fiber comparison
equivariance and the round trip give the selected pointwise equation

    E^{-1}(rho_Q(E(p),g)) = rho_f(E^{-1}(E(p)),g) = rho_f(p,g).

For each fixed `g`, the expression on the left is continuous by the two
constructed comparison maps and `CechTorsorTotalSpace`'s right-action
continuity. `continuous-pointwise` therefore proves continuity of the
literal `rho_f`, with the original right-action convention unchanged.
The new local section is `s_i` applied to the actual pulled chart map.
Composing the quotient chart `(i,1g)` with `E^{-1}` gives that section
followed by right multiplication by the unit; the principal-action unit
law supplies its pointwise equality with the literal total section. The
same continuity-transfer lemma proves the new section-continuity field.

For coordinate regularity, let `Over_f(i)` and `Over_old(i)` be the
preimages of the pulled and original `U_i` under the selected total
projections. The actual map between them is

    alpha_i : Over_f(i) -> Over_old(i),    alpha_i(p,u) = (m(p),u).

It is continuous by restricting the already proved continuous `m` and
corestricting into the old open subspace. The literal new division
coordinate is the old bundle's division coordinate composed with
`alpha_i`; `ContinuousActionArrowFamilies.locally-constant-restrict` then
proves its local constancy. Use the exact core projection-continuity term
in both the new bundle field and the definition of `Over_f(i)`, so their
open-subspace constructions agree. These constructions supply every
remaining new bundle field. No new action, section or coordinate
continuity conclusion is supplied as an input, and no setness of `Z` is
needed for this object assembly.

The structure source includes the equivariant cone lift by the following
argument. For the literal lift `L` above, a supplied domain action `act`,
base invariance `a(act(x,g))=a(x)` and equivariance
`b(act(x,g))=rho_old(b(x),g)` give both projection equalities between
`L(act(x,g))` and `rho_f(L(x),g)`. The total equality is the chain

    m(L(act(x,g))) = b(act(x,g)) = rho_old(b(x),g)
      = rho_old(m(L(x)),g) = m(rho_f(L(x),g)).

`DependentSumPullback.Pullback.joint-injective` with explicit `isSet Z`
therefore proves equality of those actual lifted points. Apart from the
core's already stated uniqueness theorem, this is the only step of the
assembly argument using `isSet Z`; the topology, bundle fields and lift
continuity do not acquire that assumption.

`CechTorsorBundlePullbackArrows` now owns the complete restriction-on-arrows
construction below. `CechTorsorBundlePullbackFunctor` reexports its operations
and retains the full fixed-`f` functor laws and record. The arrow-construction
owner has passed its complete native gate; the full functor remains pending.
All actual map, cone, continuity and law bodies are preserved. The bundle category,
pullback core and structure retain
their separate native acceptance; their checks do not accept these targets. The source keeps
the same specified cover and all the displayed inputs to
`CechTorsorBundlePullbackStructure.Construction`.

For old bundles `P,Q` and an actual arrow `h:Hom(P,Q)`, restrict its entire
equivariant family at `f(w)`: the actual Agda family is
`family w = fst h (f w)`. It retains the supplied fiber equivariance proof.
Its total map is the literal function

    h_f : (Sigma w:W. P(f(w))) -> (Sigma w:W. Q(f(w))),
    h_f(w,p) = (w,h_{f(w)}(p)).

To obtain its continuity, apply the TARGET's actual continuous cone lift
to the SOURCE's constructed pulled total. Use its output topology and the
derived locality `Source.C.merely-local localW`, its continuous projection
as base map, and `h_total o m_P` as old-total component. The latter is
continuous by the constructed continuity of `m_P` and the old arrow's
continuity certificate. The cone square is

    pi_Q(h_total(m_P(w,p))) = f(w),

proved by a transparent reflexivity clause on `(w,p)`. Keep that clause
outside an abstract block. The target's `lift-computation` then identifies
the constructed lift with `h_f`: its transport is exactly transport along
reflexivity. `MerelyLocalOpenFragment.continuous-pointwise` transfers the
lift's continuity to the literal restricted map. This requires no assumed
continuity of `h_f` and no uniqueness argument. In particular, no `isSet Z`
hypothesis is needed for this fixed-map arrow construction: equivariance
already belongs to the restricted family, so the general cone-equivariance
theorem is not invoked.

Pair the restricted family with that derived continuity certificate.
The new category's `HomData.hom-ext` gives identity and composition laws
for the WHOLE bundled arrows from the checked pointwise value equations.
For `h:P->Q` followed by `g:Q->R`, both composite values are exactly
`g_{f(w)}(h_{f(w)}(p))`, preserving the old map/action order. This
extensionality accounts for the equivariance and continuity certificates;
it does not require their judgmental equality. Convert its Cubical path
with `pathToId` for the ordinary equalities in `Cat.Functor`. Both old and
new categories are `Cat.Category (ℓ-suc ℓ) (ℓ-suc ℓ)`, so the current same-level functor
interface needs no resizing or extra setness. Its object map is the
structure's constructed `pull`, and its arrow map is this literal
restriction.

The current pending public source keeps the same object and arrow aliases and
assembles the functor from the separately stated concrete whole-arrow laws. Its category
interfaces name the original `Bundles.On` owner directly, using the exact
pulled-cover and opening formulas. The full public law statements are unchanged.

`CechTorsorBundlePullbackValues` has passed its independent complete native gate.
Its arbitrary-arrow equation is exactly
`(pull h)_w(p) = h_(f(w))(p)` for the existing whole continuous arrow. Identity
values specialize that equation. For composition, first evaluate `pull (g h)`,
then apply the original g to the inverse of h's evaluation equation, then use
the inverse of g's evaluation equation at the actual restricted h value.
Every step stays in the displayed fiber at f(w); no projection of a dependent
total-space equality or setness of the base is needed. The evaluation proof is
abstract in a named child module, so its derived laws use the equation without
unfolding its body. The actual object/arrow/topology owners are unchanged. The
independent `CechTorsorBundlePullbackIdentityLaw` and
`CechTorsorBundlePullbackCompositionLaw` now supply the corresponding checked
value equation to `ordinary-hom-ext` from the checked
`LocallyTrivialPrincipalBundleHomExtensionality` owner. The imported abstract
theorem owns `HomData.hom-ext` and `pathToId` at variable bundles/arrows; the
concrete laws supply the actual objects and two whole-arrow endpoints.
The whole Hom retains level `ell-suc ell`. Each uses the original typed
object/arrow aliases and exact pulled-
cover formulas; neither constructs a category/functor record or assumes a
whole-arrow law. Their complete native gates remain pending. The existing
`CechTorsorBundlePullbackLaws` keeps its literal public statements as typed
delegates, with its own pending gate. The unchanged full public functor uses
those opaque exports in four transparent copattern fields, preserving the
same object/arrow projections used by its comparison modules. Its independent
gate is also pending. The separation changes checking ownership, without
claiming that a particular declaration caused the earlier resource failure.

`LocallyTrivialPrincipalBundleHomExtensionality` now supplies a checked
ordinary equality interface on arbitrary actual bundles P,Q and whole arrows
u,v. Its abstract `ordinary-hom-ext` takes only equality of their fiber values
and proves ordinary equality of those same whole arrows, by composing the
accepted Cubical `HomData.hom-ext` with `pathToId` at variable endpoints.
Equivariance and continuity witnesses remain in u,v, and the whole Hom
remains at `ell-suc ell`. This gives one opaque proof boundary before concrete
pullback specialization, with no category/functor or desired whole-arrow
equality input. The concrete law modules now use this interface, with their
own revised gates still pending; no resource benefit or declaration hotspot
has been established.

`LocallyTrivialPrincipalBundleFunctor` supplies the generic constructor into
this same bundle category and has passed its own complete native gate.
For any source category at the existing successor object and arrow
levels, take an actual object map and actual whole continuous-arrow map. Prove
their identity and composition equations on every fiber value. `hom-ext` and
`pathToId` then produce the whole-arrow equations, and those equations fill
the complete `Cat.Functor` record. Check this argument at symbolic maps before
specializing it to restriction, where the separate accepted Values owner
supplies both value equations.
The object and arrow fields must remain transparent; only the derived law
proofs need opacity. This supplies a useful independent proof boundary without
assuming a functor, continuity, a source interpretation or a smaller universe.
The source exports literal object/arrow computation equations. It remains a
checked symbolic constructor. The current concrete route separates its two
particular whole-arrow theorems from the final record assembly instead of
instantiating this full generic builder. Neither this generic success nor the
pointwise equations accept the concrete law, facade or public functor gates.

This is a functor for one fixed continuous `f` and its specified pulled
cover. Identity and iterated parameter restrictions may produce different
topology records: construct canonical continuous comparison isomorphisms
and their coherence before claiming source-substitution compatibility.
Neither strict equality of those bundle/topology records nor admission of
the finite-branch source derivation follows here. These are fixed-level
set-valued topological constructions, with no crisp change, properness
identification, smooth/higher model or new source-admission hypothesis.

### Identity and iterated bundle restrictions

`CechTorsorBundlePullbackIdentity` contains the identity comparison as source
written and pending a full native check; its prerequisite
`CechTorsorBundlePullbackFunctor` also remains pending. It constructs both
continuous component arrows, their whole-arrow inverse laws, and natural
transformations in both directions.
`CechTorsorBundlePullbackComposition` contains the composite comparison
isomorphism and both natural transformations as source written and pending
a full native check, with the same pending Functor prerequisite.
`CechTorsorBundlePullbackCoherence` now contains the whole-arrow right-unit,
left-unit and triple-composition laws as source written and pending a full
native check. It uses the actual forward comparison components with fixed
capabilities and canonical identity/composite continuity witnesses; its
Identity and Composition prerequisites remain pending.

Fix `f:W->Z`, `g:V->W`, certificates `cf:Continuous OW OZ f` and
`cg:Continuous OV OW g`, and one merely covered open family `(U,open-U,covered)`
on `Z`. Keep the same group, level and index type, with explicit witnesses
`openW:OpenIsProp OW`, `localW:MerelyLocal OW`, `openV:OpenIsProp OV` and
`localV:MerelyLocal OV`. Choose these exact derived inputs and functor tuples:

```agda
Uf i = Compact.preimage f (U i)
open-Uf i = cf (U i) (open-U i)
covered-f w = covered (f w)
fg v = f (g v)
cfg = OS.compose-continuous OV OW OZ g f cg cf

module RF = CechTorsorBundlePullbackFunctor.Construction
  G Z W I OZ OW U open-U covered f cf openW localW
module RG = CechTorsorBundlePullbackFunctor.Construction
  G W V I OW OV Uf open-Uf covered-f g cg openV localV
module RD = CechTorsorBundlePullbackFunctor.Construction
  G Z V I OZ OV U open-U covered fg cfg openV localV
```

`RG` starts at `RF`'s actual target bundle category. Its target cover is
`preimage g (preimage f (U i))`, which converts fieldwise to `RD`'s direct
cover; both opening proofs reduce to `cg (Uf i) (cf (U i) (open-U i))`.
Thus `Coherence.composeFunctor RG.pullFunctor RF.pullFunctor` and
`RD.pullFunctor` have the same source and target categories at `suc ell`.
For `P`, write `FP=RF.object P`, `IP=RG.object FP`, `DP=RD.object P`.
Their actual Structure owners are `Structure.Construction.Pull` with the
respective full tuples above and old bundles `P`, `FP`, `P`; call them
`SF`, `SI`, `SD`. The carriers of `IP` and `DP` are both
`Sigma v:V. P.Carrier(f(g(v)))`; their total topologies are not identified.

For `IP -> DP`, apply `SD.Cone` to `SI.C.Pulled`, `SI.C.topology` and
`SI.C.merely-local localV`. Use base `SI.C.projection` with its existing
continuity, and old-total map `SF.C.map o SI.C.map`, whose continuity is the
composition of `SI.T.map-continuous` and `SF.T.map-continuous`. Define the
square transparently by reflexivity at `(v,p)`. Its `lift-computation` gives
the literal identity; `continuous-pointwise` transfers the proved continuity
to the identity-family total map.

For `DP -> IP`, first apply `SF.Cone` to `SD.C.Pulled`, `SD.C.topology` and
`SD.C.merely-local localV`. Its base is `g o SD.C.projection`, continuous by
composing the projection's certificate with `cg`; its old-total map is
`SD.C.map` with `SD.T.map-continuous`. A transparent reflexive square makes
the lift compute to `j(v,p)=(g(v),p)`. Transfer continuity to this literal `j`.
Then apply `SI.Cone` to the same direct total, topology and locality, using
base `SD.C.projection`, total `j`, and those actual continuity certificates.
The second square is reflexivity and its lift computes to the literal identity
into `IP`. Transfer continuity again before forming the reverse bundle arrow.

The two identity fiber families are equivariant by reflexivity. Pair them with
these constructed certificates to obtain `c_P:Hom IP DP` and `d_P:Hom DP IP`.
The existing whole-`Hom` extensionality proves `c_P o d_P=id_DP` and
`d_P o c_P=id_IP`. For an actual arrow `a:P->Q`, it also proves

    c_Q o RG.arrow(RF.arrow(a)) = RD.arrow(a) o c_P
    d_Q o RD.arrow(a) = RG.arrow(RF.arrow(a)) o d_P.

Every side has fiber function `a_(f(g(v)))`; these are equations of full
continuous arrows and provide actual natural transformations in both directions.
No cone uniqueness, cone-equivariance theorem or base setness is used.

The existing identity design uses the literal identity map and
`OS.identity-continuous`. Its cover and opening proof convert to the original
ones. The forward arrow is the existing continuous `map`; the reverse is its
cone on the old bundle total, using that bundle's locality, projection and
identity total map. Constructing identity restriction on `Z` additionally
requires explicit `openZ:OpenIsProp OZ` and `localZ:MerelyLocal OZ`.

Orient `c(f,g):g^*f^* -> (f o g)^*` and denote the identity comparison by
`iota`. The whole-arrow unit and triple equations are

    c(f,id_W)_P = iota_W(f^*P)
    c(id_Z,f)_P = f^*(iota_Z(P))
    c(f o g,h)_P o h^*(c(f,g)_P)
      = c(f,g o h)_P o c(g,h)_(f^*P).

The first unit uses the existing capabilities on `W`; the second also needs
those on `Z`. For `h:T->V`, retain fixed capabilities on `T` and certificate
`ch`, with pulled coverage always `covered(image(x))`. Use only the displayed
identity/composite continuity operations. For every subset `S` of `Z` and
opening witness `o`, both associated full composite certificates reduce to

    ch (preimage g (preimage f S)) (cg (preimage f S) (cf S o)).

Identity composition similarly reduces to `cf S o`. Record/function eta
therefore aligns the canonical direct endpoint constructions, not merely their
selected cover openings. Both coherence routes are fiber identities, so whole
`Hom` extensionality proves the equations. No judgmental equality of composite
Functor proof records or independent intermediate topology records is asserted.
An independently supplied composite continuity certificate needs its own
comparison. This fixed-cover design neither chooses global charts nor supplies
smoothness, properness, crisp interpretation, resizing, an action-quotient
comparison, or admission of the finite-branch source judgment.

### Completion maps and pending coherence

The following bundle quotient specializations are precise mathematical
designs, not source-written or natively accepted. Their actual bundle
Identity, Composition and Coherence prerequisites remain pending. The
generic completion maps and naturality interfaces already provide the
operations used here.

Write `BundleCompletion` for
`LocallyTrivialPrincipalBundleCompletion`. Retain the preceding fixed cover,
maps, continuity certificates and capabilities. The exact completion tuples
are

    BZ = BundleCompletion.On G Z I OZ U open-U covered
    BW = BundleCompletion.On G W I OW Uf open-Uf covered-f
    BV = BundleCompletion.On G V I OV Ugf open-Ugf covered-fg

where `Ugf i = Compact.preimage g (Uf i)`,
`open-Ugf i = cg (Uf i) (open-Uf i)` and
`covered-fg v = covered (f (g v))`. Each tuple supplies its own actual
`category` and coverage-derived `all-invertible`. All generic completion
applications use working level `suc ell`: both category levels, the completed
objects and these homotopies retain that level. No inverse or quotient model
is supplied as a new premise.

Let `QF` denote `OrdinaryGroupoidCompletionMaps.Map.completed-map` for the
specified source/target categories, their exact inversion witnesses and F.
Let `H(eta)` denote
`OrdinaryGroupoidCompletionNaturality.Naturality.completed-homotopy` for an
actual natural transformation eta. Its existing
`completed-homotopy-object` identifies its value at `quotient P` with
`Target.morphismPath (component eta P)`, retaining the whole continuous
component arrow.

Keep the EXISTING corrections from `OrdinaryGroupoidCompletionCoherence`:
`Identity.completed-identity-pointwise` gives
`iota(q) : Q(id)(q) = q`; `Composition.completed-composition-pointwise`,
with first functor F and second G, gives
`kappa(G,F)(q) : Q(G o F)(q) = QG(QF(q))`.
For the actual identity restriction I and the actual first, second and direct
restrictions RF, RG, RD above, the forward and backward homotopies are exactly

    H(to-identity)(q) . iota(q)              : QI(q) = q
    sym(iota(q)) . H(from-identity)(q)       : q = QI(q)

    sym(kappa(RG,RF)(q)) . H(to-composite)(q)
      : QRG(QRF(q)) = QRD(q)
    H(from-composite)(q) . kappa(RG,RF)(q)
      : QRD(q) = QRG(QRF(q)).

Here "." denotes Cubical path concatenation. Instantiate `Naturality` for
the identity comparison with BZ twice; for the composite comparison use BZ
and BV. Instantiate the generic composition correction with BZ, BW, BV and
the actual `First.pullFunctor`, `Second.pullFunctor`. Identity restriction
also retains `openZ,localZ`. Function equality follows by `funExt`, and
ordinary equality by `pathToId`. These basic homotopies do not require the
additional coherence proofs below.

The unchanged `OrdinaryGroupoidCompletionTransformationComparison` has
passed a fresh native gate against the Coherence computation exports below.
For fixed actual F,G, its construction lifts ordinary equalities of
two transformations' components to equality of their induced homotopies.
The proof uses the two existing object-computation equations, congruence of
`morphismPath`, and `Source.R.elimProp`. The motive is equality BETWEEN
paths, which is propositional because the target completion is a groupoid;
the paths themselves need not be propositions. Combining this comparison
with the existing `OrdinaryGroupoidCompletionNaturalityLaws.Context.Vertical`
and `.Identity` gives the constructed generic inverse chain

    sym(Vertical.completed-vertical-pointwise q)
      . Compare.completed-comparison-pointwise q
      . Identity.completed-identity-pointwise q.

With actual component equations `theta_P o eta_P = id`, this proves
`H(eta)(q) . H(theta)(q) = refl`; swapping the transformations gives the
other inverse law. The supplied equations are the bundle comparisons'
actual `At.left-inverse` and `At.right-inverse`, not assumed inverse
homotopies.

This generic inverse chain is now constructed and natively accepted in
`OrdinaryGroupoidCompletionNaturalityInverses`, with its own completed
source-bound evidence. It takes actual opposite natural transformations and their ordinary
component inverse equations, and constructs both pointwise and whole-function
inverse laws for the existing completed homotopies. Its two comparison
instances retain the same literal endpoint pairs F,F and G,G. It has no
pending bundle import and assumes no completed inverse equation; the actual
bundle specialization and its correction-path normalization remain separate.

For eta:F=>G, postcomposition by K and precomposition by L require the
following exact additional whiskering squares:

    H(K eta)(q) . kappa(K,G)(q)
      = kappa(K,F)(q) . cong(QK)(H(eta)(q))
    H(eta L)(q) . kappa(G,L)(q)
      = kappa(F,L)(q) . H(eta)(QL(q)).

Their ordinary whiskered transformations follow from the supplied functor
arrow laws and eta's actual naturality. These transformations and the two
quotient compatibility squares are now constructed and natively accepted in
`OrdinaryGroupoidCompletionWhiskering`. The module exports both representative
equations, both pointwise comparison laws and the corresponding function
equalities. Representative calculations use the existing
`Maps.Map.completed-map-morphism-path` and naturality object computations,
but also need object computations for the EXISTING corrections:

    completed-identity-pointwise (quotient x) = refl
    completed-composition-pointwise (quotient x) = refl.

The pending `OrdinaryGroupoidCompletionHorizontalComposition` now constructs
both horizontal presentations for eta:F⇒G and theta:H⇒K. Their actual components
are theta(Gx)∘H(eta(x)) and K(eta(x))∘theta(Fx), equal by theta's naturality.
Accepted transformation comparison and vertical composition identify their
completed homotopies and their concatenated whiskering presentations. The two
whiskering squares also give the literal normalized formulas

```text
H(horizontal)(q) . kappa(K,G)(q)
  = kappa(H,F)(q) . (cong(QH)(H(eta)(q)) . H(theta)(QG(q)))
H(alternate)(q) . kappa(K,G)(q)
  = kappa(H,F)(q) . (H(theta)(QF(q)) . cong(QK)(H(eta)(q))).
```

Both sides have the actual composite HF and KG endpoints before correction.
The middle corrections are the identical kappa(H,G) or kappa(K,F) instances
from the two relevant squares. Path associativity supplies the reassociations;
the completed component comparison then compares the normalized expressions.
The current source packages the repeated five-step pasting calculation in a
private abstract PathPasting theorem for arbitrary paths a,b,c,k,s,u,v with
b.c=k.v and a.k=s.u. Its output (a.b).c=s.(u.v) is proved by the same three
associativity and two congruence steps. The two concrete proofs supply their
original whiskering squares and retain every normalized path and endpoint.
No functor or natural-transformation proof records are identified. Every
existing prerequisite is accepted, but this new target retains its own gate.

The natively accepted `OrdinaryGroupoidCompletionHomotopyExtensionality` packages
the existing quotient argument for arbitrary actual maps f,g and homotopies
p,q. Given p(quotient x)=q(quotient x), proposition elimination gives p(z)=q(z)
for all z because the target is a groupoid, and funExt gives p=q. This only
uses propositionhood of equality BETWEEN paths; the supplied paths themselves
need not be propositions. It constructs no alternative map correction.
Its acceptance does not itself accept the pending coherence owner.

Those corrections remain abstract. Their quotient-object equations are now
source-written in the original Coherence owner as
`completed-identity-object` and `completed-composition-object`, with proofs
inside the original abstract blocks. The complete owner gate has passed with
exact current source-bound evidence. The unchanged NaturalityLaws target and
its Naturality dependency have passed their fresh gate; the unchanged
TransformationComparison target has also passed its own fresh gate.
Callers use these propositional
equations rather than reducing an opaque correction externally. No duplicate
correction recursor is introduced.

Normalized bundle unit/triple coherence additionally needs the chosen
corrections' own unit/associativity laws and explicit common endpoint
functors or actual comparison transformations. The generic laws are now
source-written in `OrdinaryGroupoidCompletionCoherenceLaws`, with their own
pending native gate. Representative normalization now belongs to named
`Representatives` children. Each outer proof now applies the accepted
HomotopyExtensionality.compare to the same explicit start/end maps, two paths
and abstract object equation. The helper owns the quotient eliminator at
that exact motive; the
literal public laws remain typed delegates. It constructs actual identity-component left/right
unit and associator transformations. The pointwise unit equations compare
their completed homotopies with the corresponding composite correction
paths; the associativity equation retains the actual associator homotopy
between the differently parenthesized endpoint functors. All three proofs
normalize to reflexivity at objects through the existing correction exports
and the actual identity-arrow path equation, then use `elimProp` for equality
between paths in the target groupoid. Component equations do not
identify functor proof records. Once endpoints and representative equations
are supplied, the resulting equalities between paths descend by
`elimProp`. These additional bundle specializations and normalized coherence
proofs remain unwritten/pending; no representative choice, loss of isotropy, resizing,
action-quotient comparison, properness, crisp interpretation or source
admission follows from the proposed adapter.

### Independent anchors

`CechTorsorAnchoredBundleMaps` supplies a set-valued left action on X and
independent equivariant value maps vP:P→X and vQ:Q→X, with convention
`v(p·g)=act(inv g)(v(p))`. A recovered gauge satisfies

    act(c_i)(vP(s_i)) = vQ(t_i)

exactly when the reconstructed equivariant map preserves the anchors. The
forward proof first establishes preservation at a local section, then at every
p using `p=s_i·divide(s_i,p)`. This argument is available for any supplied i;
it is eliminated from mere coverage only into the proposition expressing
anchor preservation. Conversely, applying vQ to `t_i·c_i=f(s_i)` and cancelling
the action of the inverse label derives the matching equation. Neither an
anchor-preserving comparison nor the desired matching equation is built into
an unstructured input map.

`CechTorsorContinuousAnchoredBundleMaps` combines this equivalence with the
continuous one, with both inverse laws for the entire bundled structures. It
retains exactly the same underlying reconstructed function. It does not need
an effective action on X, a finite group, a global chart, or any properness
predicate.

### Controls for original bundles, not just their quotient presentations

`CechTorsorBundleMapControls` independently constructs the regular right action
of G on G, and actual equivariant left-multiplication functions. It computes
recovery and gluing for constant gauges, and checks the composite function.
Two concrete noncommuting permutations of a three-element type reject reversal
of multiplication order. A constant one-point anchor is preserved by distinct
maps, so anchor values cannot erase ineffective arrows. With an empty local
index type the recovered gauges agree while the original functions can be
distinct. Thus canonical recovery is not faithful without the coverage
hypothesis. This last statement is about the actual recovery construction,
not an unsupported assertion that no unrelated equivalence could ever exist.

## Controls and precise remaining scope

`CechTorsorControls` uses two explicitly defined noncommuting permutations of a
three-element type. Opposite multiplication orders remain distinguishable after
the actual quotient. A trivial action on the one-point space gives equal anchors
without collapsing those labels. A nonidentity self-transition contradicts the
required diagonal equation. Refining an inhabited one-chart fiber by the empty
chart type cannot give an equivalence; this witnesses the need for the refinement
coverage hypothesis. A genuinely covered two-chart refinement supplies a positive
control. These checks supplement, not replace, the general constructions.

The remaining work includes connecting the proved merely-local pullback universal
property to the chosen semantic category, full source-substitution coherence,
smooth/formal instances and smooth local maps, stack-level gluing and higher
quotient comparison, and admission into
the actual source interpretation with its universe/crisp/modal requirements.
A topological local trivialization is not by itself a smooth stack or a proof of
properness. The same-cover gauge comparison and the specified topological refinement maps
are distinct from compatibility with all semantic substitutions. The latter
still needs explicit smooth/source-interpretation theorems, not a renamed record
field.
The distinctions among `DPProper`, `Compact.ProperData` and external `IsProperMap`
remain unchanged.


## Independently supplied locally trivial bundle category

`Orbifolds.SemanticBridge.LocallyTrivialPrincipalBundles` was recovered from
the exact attached 035 archive. It defines bundles independently of the Čech
quotient: each base point carries a principal right action, and the actual
dependent total space has a topology, continuous projection/right actions and
specified continuous local sections. Coordinate recovery uses the existing
principal-action division operation; local constancy of those coordinates is
an explicit input. Mere locality and openness propositionhood remain explicit.

Morphisms are actual fiberwise equivariant maps whose total maps are continuous.
Pointwise hom extensionality, with propositionhood of continuity certificates,
supplies the categorical identity/composition laws. No coverage or global section
is required merely to define this category. Coverage must be supplied for a
later comparison with cocycles; neither full faithfulness nor essential
surjectivity is an input or a proved consequence of this category module.

Its hom-extensionality proof supplies the actual equivariant-arrow endpoints
explicitly, including their proof components. Exact native acceptance is
determined by `state.json` and its applicable raw receipt. The next mathematical
step is the comparison functor using the existing quotient/recovery/gauge maps,
retaining local sections and independent anchors, followed by both object and
arrow recovery and parameter/refinement compatibility. It is not a replacement
for the required smooth/higher interpretation.

### Coverage-dependent inverses of actual bundle arrows

The existing continuous comparison gives a constructive route to making this
actual bundle category a groupoid once the specified cover is merely covering.
The assembly in `LocallyTrivialPrincipalBundleGroupoid` has passed its own
complete native gate. Its only extra input beyond the category's data is
`covered(z) : || Sigma i:I. member(U_i,z) ||`. Coverage matters: the principal
action record's orbit equivalence is conditional on a point of its carrier, so
that record alone allows an empty carrier.

For independent bundles P,Q and an actual continuous equivariant arrow h, apply
`CechTorsorContinuousBundleMaps.Comparison` to their own carriers, principal
actions, sections, and the displayed coverage. Its `Topologies` instance uses
their actual total topologies and projection/action/section continuity fields.
`Topologies.FromContinuous.recover-regular` uses Q's coordinate regularity and
h's continuity to construct regularity of the recovered gauge u.

`CechTorsorTopologicalGauge.Homeomorphism.inverse-gauge` constructs the
coefficientwise inverse gauge v; `inverse-regular` proves its regularity.
Now swap P and Q in the continuous comparison. Its `Topologies.glue-continuous`,
using Q's stored mere locality and coordinate regularity, supplies continuity of
the actual reverse family `glue(v)`. Together with its proved equivariance this
is a reverse arrow k in the original bundle category. No section index is chosen.
The direct construction needs no new `OpenIsProp OZ` or `MerelyLocal OZ` premise:
the required total-space capabilities are the bundles' existing fields.

For both inverse laws, fix z and its local-witness type
`C_z = Sigma i:I. member(U_i,z)`. Use the actual pointwise sections of P and Q.
The accepted algebraic comparison provides `recover-composition`,
`recover-glue`, `recover-identity`, and `recover-injective`. Thus the two
composites' recovered gauges are respectively `compose v u` and `compose u v`.
`CechTorsorGaugeRecovery.Recovery.gauge-ext` reduces their identity equations
to the group laws `inv(u_i) * u_i = 1` and `u_i * inv(u_i) = 1`.
This retains the noncommutative convention that the later arrow's coefficient
multiplies on the left. Recovery injectivity yields the fiber-Hom equations.
Evaluate them on points and apply the bundle `HomData.hom-ext`, with explicit
whole-arrow endpoints, then `pathToId`. The resulting ordinary equations are
exactly the right and left inverse fields of `Cat.IsIso B.category h`.

Consequently the remaining assembly target is
`all-invertible : (P Q : B.Bundle) (h : B.Hom P Q) -> Cat.IsIso B.category h`
under that coverage input. It constructs the inverse and continuity rather than
assuming either. The category has both object and hom level `suc ell`, so this
result is used by the new
[LocallyTrivialPrincipalBundleCompletion](../src/Orbifolds/SemanticBridge/LocallyTrivialPrincipalBundleCompletion.agda)
to instantiate `OrdinaryGroupoidCompletion.Completion` at `suc ell`. Both the
groupoid prerequisite and this specialization have passed their own full native
gates. Its actual completion lives in `Type (suc ell)`, with the existing
hom/path constructions and mere-representative package at that level. The
bounded truncation's `Code` and `Truth` levels are retained: the effective-atlas
record itself lives at `Truth (suc ell)`, three successors above ell. No finite
branch charts or setness of the atlas object type are supplied merely by this
record. The bundle objects are unanchored: no action target X or comparison
with X//G has been constructed. This does not resize the quotient
to `ell`, establish smoothness or properness, interpret crisp structure, or
complete the source/model/classical bridge.

### An actual nontrivial loop in the bundle completion

[LocallyTrivialPrincipalBundleIsotropyControl](../src/Orbifolds/SemanticBridge/LocallyTrivialPrincipalBundleIsotropyControl.agda)
has passed its own complete native gate. For an actual
`G : Group ell`, it constructs `regularBundle` over `Z = I = O.Unit {ell}`
with the full open chart. Both base and total space use the discrete open
fragment `IsOpen(P) = O.Unit`; this needs no decision procedure for membership.
The carrier is G, the principal action is the existing regular right action,
and the specified local section is the group unit. Openness propositionhood,
mere locality, projection/right-action/section continuity and coordinate
regularity are all supplied for these actual topologies. The open-subspace
openness goals reduce to the same unit type. Coverage is the explicit
truncated pair of unit witnesses, so no arbitrary bundle chart is selected.

For each g, `left-arrow g` is the whole continuous equivariant bundle arrow
whose underlying function is left multiplication by g. Evaluating an equality
with the actual identity arrow at the base point and the group unit would
give `g * 1 = 1`, hence `g = 1`. Thus a nonidentity g gives two distinct whole
arrows, including their continuity certificates. Applying the actual
completion's `homToPath` gives a loop at `quotient regularBundle`. If that loop
were reflexivity, `homToPath-identity` and both occurrences of the
`pathToHom-homToPath` inverse law would recover equality of those whole arrows,
contradicting the unit evaluation. The module also converts this to a Cubical
nonidentity path and derives that this completion is not a set.

The concrete control uses the existing `CechTorsorControls.G`, `alpha` and
`alpha-not-unit`; it introduces no new group or nonidentity assumption for that
instance. Fibers and the total space remain at ell, while bundles, whole homs
and the completion remain at `suc ell`. An explicit constant one-point anchor
is preserved by the actual total left maps. This last equation constructs
neither an anchored category nor a comparison with an action quotient. It does
not establish properness, smoothness, finite branch charts, crisp structure or
source admission.
