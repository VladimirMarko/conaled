# Complex lattices

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="complex-lines"></a>

## Actual complex-line exemplars and their identities

`ComplexLines.Ring C` constructs the type of rank-one modules over an
ordinary commutative ring C. A point contains an actual library
`LeftModule` and only a truncated existence proof of a module
equivalence with C. It carries no chosen basis. `ComplexLines.Complex R`
specializes this construction to the already constructed complex-pair
ring C = R × R.

The type is proved a pointed connected groupoid. Its identities are
equivalent to actual structured module equivalences, using the
library's module univalence. The projection to underlying carriers
computes to ordinary univalence, and actual transport along a line
identity computes to the underlying linear equivalence. Both
statements are explicit checked lemmas.

Every linear endomorphism of the standard line is multiplication by
its value at one. An automorphism has an actual invertible scalar,
and the module proves an equivalence between standard-line
automorphisms and the subtype of units of C. Consequently the loop
type of the canonical line is equivalent to these units. For the
loop constructed from a unit λ, carrier transport is literally
multiplication by λ, with its equality proved in Agda.

This provides the complex-line component needed by the paper's moduli
definition. It does not replace a lattice by a chosen basis or assume
an equivalence of the moduli type with an action quotient. The only
mathematical input to this module is the ordinary commutative ring;
no field, order, crispness or differential axiom is required.

<a id="complex-line-inner-products"></a>

## Actual inner products on complex lines

These modules extend the metric setting of Definition 2.4.6 in
[Myers, Higher Orbifolds](https://arxiv.org/abs/2205.15887) from the
literal plane to the actual complex-line objects already constructed
in `ComplexLines.agda`. A complex line is an actual module over the
constructed complex ring with merely an equivalence to its regular
rank-one module. It does not store a chosen basis.

### Restriction of scalars

`ScalarRestriction.Along R S f` works for arbitrary rings and an
actual ring homomorphism f. Its `restrict` constructs the real module
structure, including scalar associativity, both distributive laws,
and the scalar unit law. The carrier and additive structure are
judgmentally unchanged. The module also restricts actual module
homomorphisms and equivalences without changing their underlying
functions or equivalences.

`ComplexLineInnerProducts.Geometry R order.RealModule L` applies
this construction to the proved real embedding R → C and the actual
complex module underlying L. Thus `RealModule L .fst` is judgmentally
`ComplexLines.Complex.Carrier R L`; there is no replacement by a
coordinate-frame type.

### Arbitrary module inner products and coordinate changes

`ModuleInnerProducts.Theory R order M.InnerProduct` contains an
actual R-valued pairing on the carrier of the real module M, with
symmetry, additivity, real homogeneity, and positivity on nonzero
vectors. Equality of pairings implies equality of these structures,
because every law is a proposition.

For an actual module equivalence e : M ≃ N, `ChangeCoordinates.pullback`
has the exact pairing

pullback(e, form)(x,y) = form(e(x), e(y)).

The inverse of e is proved to be a module equivalence by the actual
inverse laws and the four preservation laws. Pullback along this
inverse is then proved inverse to pullback along e. Consequently
`forms-equivalence e` is an equivalence of complete inner-product
types, not merely a function between pairings. The forward pairing
formula computes judgmentally.

The complex-line wrapper restricts actual complex module equivalences
and supplies the corresponding pullback and form-type equivalence.
These results permit the metric-separation condition to be transported
under complex-linear changes of coordinates without assuming that all
norms are equivalent.

### Exact agreement with the literal-plane definition

On the canonical complex line, the restricted scalar action is
complex multiplication by the embedded real scalar. The accepted
coordinate identity identifies this action with componentwise real
scaling on R × R.

`canonical-forms` is an equivalence between the complete generic
inner-product type on this real module and the complete
`RealInnerProducts.Plane.InnerProduct` type. Both conversion functions
leave the pairing and positivity field unchanged. The coordinate
identity is used only to convert the homogeneity law. The two inverse
laws are proved using the propositional character of the laws.
The exported `canonical-pairing` and `canonical-inverse-pairing`
computations are reflexivity proofs.

This is a genuine equivalence of inner-product definitions, so the
already checked standard-lattice separation theorem applies to all
inner products of the canonical complex line. No restriction to a
selected frame or selected family of norms occurs.

The construction requires the ring and strict order but does not
require Kock's field axiom, ordered-ring compatibility, a crispness
rule, or a chosen complex basis. It does not itself classify lattices
or prove that the paper's abstract rank condition supplies an integer
basis; those remain separate statements.

<a id="standard-complex-lattices"></a>

## Standard complex lattice subgroups and their Möbius comparison

The following modules have passed the canonical safe native-kit check
with cohesion enabled, exit status zero, and no warnings:

- `StandardComplexLattice.agda`
- `MobiusStandardLattices.agda`
- `StandardLatticeSeparation.agda`
- `IntegerPairMatrices.agda`

They construct concrete parts of the lattice argument in
[Definitions 2.4.6–2.4.7 and Proposition 2.4.8](https://arxiv.org/html/2205.15887v1#S2.SS4).
They retain the explicit ordinary commutative ring, Kock-field,
strict-order, and ordered-ring-compatibility context. No lattice
classification, chosen arbitrary-lattice basis, or torsor conclusion is
an input.

### The literal subgroup

For an actual upper-half-plane point `τ`, `StandardComplexLattice`
defines the function

`standard τ (m,n) = real (integer m) * τ + real (integer n)`.

The integer coefficients use the proved canonical map from the actual
integers. Positivity of `Im τ` makes it invertible; comparing imaginary
coordinates and then real coordinates, together with the proved integer
embedding, proves this standard map injective. Its homotopy fibers are
therefore propositions. The function `Member τ z = fiber (standard τ) z`
is consequently an actual proposition-valued subset of the complex
plane, without needing to choose representations from a truncation.

The module proves closure under addition and negation, packages the
actual additive subgroup, and proves an actual group equivalence from
`ℤ × ℤ` to its carrier. The inclusion of this equivalence is judgmentally
the original standard map. Its two standard generators are proved to
be `τ` and `1`.

This establishes the free rank-two property of this particular
subgroup. It does not infer the existence of a basis of an arbitrary
lattice from an unspecified interpretation of the word “rank.”

### Actual Möbius scaling equality

`MobiusStandardLattices.Geometry.Transform M τ` uses the actual integer
matrix `M`, its actual Möbius transform `σ`, and actual denominator
`D = c*τ+d`. It proves

`D * standard σ v = standard τ (transpose M · v)`.

The transpose matrix has determinant one, and its action on actual
integer pairs is a proved equivalence. This yields, for every complex
number `z`, the equivalence

`Member σ z ≃ Member τ (D*z)`.

Propositional extensionality then gives the equality of actual subset
predicates `Z*σ+Z = D⁻¹(Z*τ+Z)`. The inverse direction explicitly uses
the matrix inverse and cancellation by the already proved denominator
unit. Thus this is the subset comparison required by the printed fiber
action, with no assumed “change of lattice” law.

### Euclidean quantitative separation

`StandardLatticeSeparation` proves that any real radius `ε` satisfying
`ε < 1` and `ε < (Im τ)²` isolates zero in the standard subgroup for the
actual Euclidean squared norm. A norm bound bounds the imaginary
coordinate square; division by the positive `(Im τ)²` and the proved
integer-square separation force the first coefficient to be zero. The
remaining real coefficient is then zero by the same integer theorem.

The radius's positivity is unnecessary for that implication and is
therefore not an extra premise. Constructing a positive rational radius
and treating every inner product are separate work. In particular,
this accepted module does not assert the full arbitrary-norm clause
of Definition 2.4.6.

### Algebraic and geometric classification interfaces

`IntegerPairMatrices` identifies additive homomorphisms ℤ² → ℤ² with integer
matrices and derives determinant ±1 for an additive group equivalence. This
pure algebraic result has no real-ring, order or field hypothesis. The separate
oriented basis-change theorem supplies the determinant +1 condition for complex
lattice comparisons.

The later literal lattice structures retain the all-inner-product metric
condition and a merely supplied integral group equivalence ℤ² ≃ Λ. Real spanning,
coverage and the actual quotient comparison are described in this chapter and
[Elliptic moduli](elliptic-moduli.md). No weaker rational-rank condition is silently
identified with that finite-free integral condition.

<a id="standard-lattice-metric"></a>

## The standard complex lattice is metrically discrete for every inner product

Both `RealInnerProducts.agda` and `StandardLatticeMetric.agda` were
accepted by the pinned Agda kit with exit code 0 and no warnings.

This proves the metric clause of Definition 2.4.6 for the actual
standard lattice used in Proposition 2.4.8 of
[Myers, Higher Orbifolds](https://arxiv.org/abs/2205.15887).
The subgroup is exactly `StandardComplexLattice.Member τ z`, the
fiber of `(m,n) |-> m*τ+n` for actual integers m and n. Its additive
subgroup structure and actual group equivalence from Z² were already
proved in `StandardComplexLattice.agda`.

### Mathematical setting

The complex plane is literally R × R. The new `InnerProduct` record
contains a real-valued pairing, symmetry, additivity and homogeneity
in the first variable, and strict positivity on nonzero vectors.
Linearity in the second variable is derived from symmetry. It has no
norm-comparison, lattice-separation, compactness, or basis field.
The ordinary dot product is constructed as an inhabitant of this
record, using the previously proved finite-dimensional positivity
theorem.

The ambient parameters are the existing commutative real ring,
Kock field axiom, literal strict-order axiom, and separately named
ordered-ring compatibility. The last parameter remains explicit,
as throughout the project's synthetic order development. No new
axiom is introduced, and no crispness or choice premise is used.

### Derived bound

Fix any such inner product and any τ with positive imaginary part.
Put e = (1,0), A = ⟨e,e⟩, and B = ⟨e,τ⟩. Positivity makes A
strictly positive. The existing ordered Kock-field theorem constructs
its positive reciprocal u. Set s = B*u and w = τ-s*e.

The file proves ⟨e,w⟩ = 0 from bilinearity and A*u = 1. The imaginary
coordinate of w is the imaginary coordinate of τ, so w is nonzero.
Consequently S = ⟨w,w⟩ is strictly positive as well.

The actual vector identity and orthogonal norm identity give

⟨m*τ+n*e, m*τ+n*e⟩
      = m²*S + ⟨(n+m*s)*e, (n+m*s)*e⟩.

Every squared norm is nonnegative; this is derived from positivity
and the proved zero-vector calculation. Removing the nonnegative
second summand preserves a strict upper bound. Therefore a norm
smaller than any ε < S forces m² < 1. The actual integer-square
separation theorem then forces m = 0. The remaining norm is n²*A,
so ε < A likewise forces n = 0.

The existing `smallerPositive` theorem supplies merely a positive
real δ below A and S. `RationalCoefficients.small-positive-rational`
then supplies merely an actual q : ℚ with q > 0, positive real
interpretation, and value(q) < δ. Propositional truncations are
eliminated only into the final mere-existence statement.

### Exact public conclusion

`StandardLatticeMetric.Geometry.standard-metrically-discrete τ`
has, for every ordinary inner product, the conclusion

merely Σ q : ℚ,
      q > 0 × value(q) > 0 ×
      ((z : C) -> Member τ z -> ⟨z,z⟩ < value(q) -> z = 0).

The proof uses the actual subgroup membership fiber to obtain its
integer coordinates and transports the resulting zero equality back
to z. It does not replace the subgroup with an abstract free group,
assume equivalence of arbitrary norms, or select untruncated rational
bounds uniformly over inner products.

This result establishes the standard-lattice metric clause. It does
not prove that every abstract rank-two metric lattice has a basis,
nor the complete elliptic-moduli quotient classification. Those
remaining statements require their own constructions.

<a id="integral-complex-bases"></a>

## Integral complex bases: checked normalization and coverage foundation

`ComplexIntegerLinearMaps`, `ComplexBasisNormalization`, and `IntegralComplexBases` introduce no new axioms.

### Actual maps and normalization

`ComplexIntegerLinearMaps.Ring R` proves that every actual additive map
from the actual integer pair group to the constructed complex additive
group preserves the canonical integer linear combinations. The proof uses
the actual integer action on groups and the canonical coefficient ring
homomorphism. Its coordinate form matches `RealLatticeSpanning.combination`.
Only an ordinary commutative ring is needed for this algebraic layer.

`ComplexBasisNormalization.Geometry R kock order compatibility.normalize`
takes two actual complex vectors with invertible real determinant. It
constructs, merely, a point of the actual upper half-plane and an actual
complex unit scalar such that the basis is `(scalar*tau,scalar)`, possibly
with its generators interchanged. The sign split is the existing mere
nonzero-sign principle, not decidable real order. Positive imaginary part,
reciprocal existence, and the scalar multiplication equation are proved.

### Exact generic coverage statement

`IntegralComplexBases.Geometry.EmbeddedMap` is parameterized by an actual
additive homomorphism `f : Z² → C` and proof that its underlying function
is injective. Its `presentation epsilon positive isolated` theorem uses
an actual positive real isolation radius: `norm(f z)<epsilon` implies
`f z=0`. It concludes merely a parameter `tau` in the actual upper
half-plane, an actual complex unit `scalar`, and, for every actual complex
`z`, an equivalence

```
StandardComplexLattice.Member tau z ≃ fiber f (scalar*z).
```

The real determinant is proved invertible by the imported constructive
Dirichlet/spanning theorem. Normalization handles both orientations;
the coefficient bijection is explicitly either the identity or the
coordinate interchange. The forward and reverse membership maps are
proved, with cancellation supplied by the actual complex unit. These
are literal function fibers, not an abstract desired image-classification
predicate.

The ordered geometric layers retain the existing explicit Kock-field,
strict-order, and ordered-ring-compatibility inputs. Neither real
independence, a lattice classification theorem, a chosen real sign, nor
a quotient/torsor conclusion is assumed.

This is the generic coverage foundation for the finite-free interpretation
of the elliptic lattice moduli. Instantiation with an arbitrary lattice's
mere integral group basis and actual metric clause, the actual moduli map,
and its identity/fiber/quotient classification are separate assembly
steps. No weaker rational-rank definition is identified with finite-free
rank here.

<a id="standard-lattice-basis-change"></a>

## Unique oriented integral basis change

`StandardLatticeCoordinates.agda` and `StandardLatticeBasisChange.agda`
have passed the canonical safe native-kit check with cohesion enabled,
exit status zero, and no warnings. They prove the actual oriented
basis-change calculation needed in
[Proposition 2.4.8](https://arxiv.org/html/2205.15887v1#S2.SS4).

### Exact theorem

The ordinary ambient inputs are the existing commutative ring,
Kock-field, strict-order, and explicit ordered-ring-compatibility
structures. The concrete comparison data are upper-half-plane points
`σ,τ`, a complex number `scalar` with its actual multiplicative inverse,
and pointwise equivalences of the literal subgroup predicates

`Member σ z ≃ Member τ (scalar*z)`.

`StandardLatticeBasisChange.Geometry.Comparison.unique-realization`
proves contractibility of the type

`Σ[ M ∈ SL₂(ℤ) ] (integer-mobius M τ = σ) × (denominator M τ = scalar)`.

Thus the comparison determines exactly one actual determinant-one
integer matrix. The input is an ordinary scalar isomorphism preserving
two already constructed standard subgroups. It is not an assumed
matrix representation, torsor condition, or quotient classification.

### Construction and orientation

Multiplication by the supplied scalar induces an actual equivalence of
the two additive subgroup carriers. Composing with their proved
integer bases gives an actual additive automorphism of `ℤ²`.
`IntegerPairMatrices` derives its matrix and inverse and proves its
determinant is `+1` or `−1`.

The matrix is transposed to match the paper's fractional-linear
convention. Its rows satisfy the actual complex equations

`scalar*σ = a*τ+b` and `scalar = c*τ+d`.

The proved complex cross-imaginary identity gives

`norm(scalar)*Im(σ) = integer(det M)*Im(τ)`.

Both imaginary parts are positive, and the scalar's unit witness makes
its squared norm positive. Cancellation by the positive `Im(τ)` proves
the interpreted determinant positive, excluding `−1`. This supplies
the orientation argument omitted from the printed basis step. The
displayed numerator and denominator equations also fix the ratio
consistently.

The source comparison has been checked against the actual v1 text.
Its two displayed equations instead assign `z = a*τ+b` and
`z*σ = c*τ+d`, then print the opposite ratio for `σ`. Interchanging
which row describes `z*σ` and which describes `z` restores the intended
fractional-linear convention used above. Also, an arbitrary change of
ordered integral basis has determinant `+1` or `-1`; being ordered
alone does not select `+1`. The proved imaginary-part argument is the
additional orientation step. These are independently verified repairs
to that calculation, not an author-published erratum, and they do not
by themselves complete the remaining moduli-map theorem.

The already proved denominator-unit uniqueness theorem gives the
Möbius equation itself. Finally, injectivity of the standard lattice
map identifies both rows of any other realizing matrix, proving
uniqueness. The final realization type's proof fields are propositions,
so the result is contractibility of the full structured type.

The coordinate certificate is in a separate checked module to keep
Agda from expanding its structured equivalence while checking the
orientation argument. This changes proof normalization only. The
matrix entries are still extracted from the actual derived coordinate
automorphism.

### Scope and downstream assembly

This result classifies scalar comparisons between standard subgroups. The
complex-line identity, coverage, fiber action and final quotient are additional
constructions in [Elliptic moduli](elliptic-moduli.md); they are not input
assumptions of the basis-change theorem.

<a id="real-lattice-spanning"></a>

## Discrete integer bases span the real plane

The three checked modules `FiniteApproximation`, `DirichletApproximation`
and `RealLatticeSpanning` supply the analytic converse needed for the
elliptic lattice classification. Their arguments are constructive in the
synthetic real setting.

### Exact hypotheses and conclusion

Fix an ordinary commutative ring R, KockField, StrictOrder (including its
Archimedean clause), and the separately recorded ordered-ring compatibility.
For two ordinary vectors u,v in the literal plane R × R, define

combination u v (m,n) = integer(m) u + integer(n) v.

If this actual map from the actual integers Z × Z is injective, and some
positive epsilon isolates zero by the usual squared Euclidean norm, then

lattice-determinant-invertible : Invertible (u.re*v.im - u.im*v.re).

The isolation input says every integer combination of squared norm less
than epsilon equals zero. There is no real-linear independence, chosen
real basis, lattice normal form, rational approximation, or real-order
decidability hypothesis. No crispness, KL, countable choice, global excluded
middle, or added postulate is used.

This is a theorem about an actual embedded integer basis. It does not prove
that every group of abstract rational rank two is free abelian of rank two.
The interpretation of the paper's rank clause remains explicit in the
lattice/moduli definitions.

### Constructed approximation

`FiniteApproximation` proves finite choice for propositional truncation
from the pinned library's theorem, covers (0,L) by L overlapping intervals
(k,k+2), and applies the actual finite pigeonhole theorem to L+1 points.
The overlap permits cotransitivity rather than a floor function.

`DirichletApproximation.Ordered.dirichlet` proves that, for every alpha and
positive epsilon, there merely exist actual integers m,n with m nonzero and

-epsilon < integer(m)*alpha + integer(n) < epsilon.

It constructs integer translates with residues in (0,2), chooses a fine
positive reciprocal using the Archimedean axiom, and applies finite
pigeonhole to the scaled residues. The nonzero coefficient comes from two
distinct finite indices. Only finite truncated choices are eliminated.

`RealLatticeSpanning` proves that a vanishing determinant would make u a
real scalar multiple of nonzero v. Finite K supplies an invertible
coordinate of v. Dirichlet then gives a nonzero integer combination inside
the isolating norm ball, contradicting injectivity. Finally K turns the
nonzero determinant into an actual inverse.

<a id="lattice-rank-diagnostic"></a>

### What the source says

Myers' Definition 2.4.6 requires an additive subgroup, metric
discreteness for every inner product with a positive rational
radius, and “rank n as an abelian group.” It does not define that
last phrase. Example 2.4.12 subsequently chooses generators that
give an abstract group isomorphism with the integer lattice.
Proposition 2.4.8 describes free transitive action on existing
fiber points; its displayed proof does not separately establish
that every fiber is inhabited.

Primary source:
<https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm6>.
Related proof and construction:
<https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm8> and
<https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm12>.

The formalization's `ComplexLatticeStructures` makes its
interpretation explicit. `HasIntegralBasis` is mere existence
of an additive group equivalence with `ℤ²`. Its finite-free
lattice type includes that property alongside the exact metric
condition. The following checked diagnostic shows why a weaker
rational-spanning interpretation cannot silently provide that
integral-basis property in an ordinary varying context.

### The conditional subgroup

Let `P` be an arbitrary ordinary proposition. Define

`H_P = { z : ℤ | ∥ (2 divides z) ⊎ P ∥ }`.

`ConditionalIntegerSubgroups.agda` constructs this as an actual
additive group. It constructs its embedding in `ℤ`, the
homomorphism `z ↦ 2z` into it, and the relevant composite
computations. Thus it lies between `2ℤ` and `ℤ` without any
decision about `P`. Membership of `1` implies `P`, and `P`
implies membership of every integer.

The module proves more than a basis obstruction: merely knowing
that `H_P` has a cyclic generator implies `Dec P`. For a proposed
generator `a`, integer divisibility decides whether `2` divides
its integer coordinate. If it does not, membership of `a`
implies `P`. If it does, then every integer multiple of `a` is
even. Under `P`, the group contains `1`, which contradicts the
generator property. These branches construct a decision for
`P`. Elimination from mere generator existence is permitted
because `Dec P` is a proposition when `P` is a proposition.

An actual group equivalence `ℤ ≃ H_P` supplies such a generator,
so the module also proves

`∥ GroupEquiv ℤGroup GroupH ∥ → Dec P`.

The only case split is on ordinary integer divisibility, whose
decision procedure is proved in the Cubical library. No excluded
middle for `P` is used.

### The rank-two version

`ConditionalIntegerLattices.agda` constructs `K_P = H_P × ℤ`.
It embeds this group into `ℤ²` and constructs a doubling map in
the opposite direction. One composite is coordinatewise
doubling on `ℤ²`; the other is doubling on `K_P`. In particular,
the group contains the entire doubled integer lattice.

The source proves

`∥ GroupEquiv (ℤ × ℤ) K_P ∥ → Dec P`.

The proof takes the first integer coordinates of the two images
of a proposed basis. If either coordinate is odd, that basis
element's membership gives `P`. If both are even, the first
coordinate of every integral linear combination is even. Under
`P`, the element `(1,0)` belongs to `K_P`, contradicting
surjectivity of the proposed group equivalence. The argument
uses the checked calculation of an additive homomorphism on
integer coordinates, rather than an assumed determinant or
Smith-normal-form theorem.

### Actual rational spanning evidence

`ConditionalRationalSpan.agda` interprets integer coordinates in
the project's preferred rational ring. The actual subgroup
elements `(2,0)` and `(0,2)` have their literal rational images.
The map taking two rational coefficients to the corresponding
linear combination is proved to be an equivalence of rational
planes. Its inverse halves both coordinates. The source also
exports the spanning statement and the independence statement
explicitly.

Consequently this example has an actual rational coordinate
basis in its image, independent of `P`, and sits inside the
rational plane through its integer-coordinate presentation.
The checked doubled-lattice comparison maps give an additional
explicit commensurability certificate. The source does not
silently rename any of these statements as an unspecified
library notion of group rank. A general comparison with a
tensor-product definition of rational rank is not included in
this construction.

### The exact metric clause

`ConditionalMetricLattices.agda` embeds `K_P` into the canonical
complex line using the accepted standard-lattice embedding for
any point of the upper half-plane. Its image is an actual
`Canonical.Subgroup` in `ComplexLatticeStructures`. The group
of that subgroup is proved equivalent to `K_P`.

The conditional subgroup is contained in the full standard
lattice. Therefore the already proved standard-lattice radius
works for it as well. The resulting theorem has exactly the
type `Canonical.MetricallyDiscrete subgroup`: it quantifies
over every actual real inner product and supplies a merely
existing positive rational radius. Neither the radius nor
the embedding requires deciding `P`.

The same module proves that
`Canonical.HasIntegralBasis subgroup` implies `Dec P`. It also
proves `no-uniform-basis-completion`: under the Kock field and
first-order Kock–Lawvere hypotheses, integral bases cannot be
supplied uniformly for all these ordinary proposition-indexed
metric subgroups. Such a supply would decide every ordinary
proposition, hence every equality of smooth reals, contradicting
the already checked `SyntheticField` theorem excluding decidable
equality of the smooth reals under those hypotheses.

### Consequence for the formalization

The finite-free condition in `ComplexLatticeStructures` is
substantive. It cannot be derived uniformly from the displayed
metric condition plus the rational-spanning evidence exhibited
here. If the paper intends rank to include a locally existing
integral basis, the current finite-free interpretation expresses
that requirement. If it intends ordinary rational rank alone,
the missing basis step needs an additional hypothesis or a
different statement.

This diagnostic does not settle the author's intended rank
convention, so it is recorded as an interpretation and bridge
limitation rather than an unconditional refutation of the
paper. It concerns ordinary `P`, which may vary over the smooth
context. Restricting a proposition to the crisp context changes
the situation because the source separately assumes excluded
middle for crisp propositions. This observation does not itself
prove a general crisp-lattice basis theorem.

<a id="complex-lattice-moduli"></a>

## Literal finite-free complex lattice moduli

`ComplexLatticeStructures.agda` introduces no new axioms. Its `Geometry R kock order compatibility` retains the ordinary ordered Kock-field context, including the separately explicit ordered-ring compatibility input.

### Literal definition

For each actual complex line from `ComplexLines`, `At.Subgroup` is the
library's actual proposition-valued additive subgroup. Scalar restriction
from the complex module to the real module is the proved construction in
`ComplexLineInnerProducts`.

`At.MetricallyDiscrete` quantifies over every actual symmetric positive-
definite real bilinear form on that real module. Its radius is merely an
actual library rational, positive in rational order and with positive
canonical value in the real ring, such that every subgroup point below
that squared-form bound equals the line's zero. No norm comparison,
choice of coordinates, or chosen radius is stored as an extra axiom.

`At.HasIntegralBasis` is explicitly the propositional truncation of an
actual additive `GroupEquiv Z² (Subgroup→Group ...)`. `FiniteFreeLattice`
combines this with the metric clause. This interprets the source's use
of rank and later integral bases as finite-free rank two. No identification
with a weaker rational-rank condition is claimed. The source's angle-
bracket norm is represented by an actual positive-definite bilinear form;
a theorem identifying this with every separate normed-space norm is not
asserted.

The lattice structure on each actual line is proved to be a set, with
identity determined by its actual membership predicate. The total
`FiniteFreeModuli = Σ Lines.Line FiniteFreeLattice` is proved to be a
groupoid. The standard subgroup, its actual group basis, and its full
metric clause are checked on the actual canonical line. The group
operations agree with the concrete complex ring operations; only
propositional closure certificates are rebuilt when passing between
the library's module-derived and ring-derived group structures.

### Checked canonical-line coverage data

`CanonicalLatticePresentations.agda` is also accepted, exit zero and no
warnings. For every literal canonical-line `FiniteFreeLattice`, it derives
merely a parameter in the actual upper half-plane, an actual complex
unit scalar, and pointwise equivalences between standard membership at
`z` and the original subgroup membership at `scalar*z`. It eliminates
exactly the lattice's existing mere integral group basis and actual metric
radius. The basis composed with subgroup inclusion supplies the embedded
additive map, and the actual Euclidean form supplies the isolation radius
for `IntegralComplexBases`. No additional spanning, orientation, chosen
basis, or coverage premise is used.

### Checked component assembly

`StandardLatticeIntegralBasis` constructs the actual truncated integral
group-equivalence certificate directly at the canonical subgroup type.
`StandardLatticeMetricData` pairs the actual standard subgroup with its
metric certificate and proves its exact subgroup coordinate. Both are
accepted. `DependentDecorations` supplies generic dependent-pair
constructors and combines two decorations with equal base coordinates;
these are ordinary proved constructors, not additional mathematical
assumptions.

`StandardLatticeSubgroups` supplies an abstract representative of the
same actual standard subgroup, together with a proved equality to it
and exact predicate computation. This accepted equality is a compiler
abstraction boundary, not an added lattice condition or assumption.

`StandardLatticeBasisData` now also checks. It constructs the actual mere
integral group basis directly at the expected type, transports it along
the proved subgroup equality, and pairs the result with the abstract
representative. Its first coordinate is proved equal to the original
standard subgroup. No chosen basis becomes a field of the moduli type.

The final complete lattice packaging in `LatticeModuli` now also passes
the canonical default safe check, with no warnings. Compiler diagnostics
are kept separate from the accepted roots and do not contribute additional
theorem acceptance claims.

### Assembly boundary

`LatticeModuli.agda` constructs the actual map `tau ↦ (C,Z*tau+Z)` into
the literal finite-free lattice moduli. Its abstract standard lattice
contains the checked all-form metric and mere integral-basis certificates;
its predicate is proved equal to the actual standard subgroup predicate.
The map's complex-line coordinate is exactly the canonical line. The
predicate comparison is explicit, so downstream identity and quotient
proofs do not depend on unfolding the mathematical certificates.

`LatticeModuliCoverage` now proves surjectivity of this exact map. For
the canonical line it uses the derived normalized presentation and the
actual structured identity induced by the resulting complex scalar
unit. It then transports coverage along the arbitrary line's existing
mere complex frame. It assumes no additional real spanning, chosen
integral basis, coverage, or classification principle.

### Checked scalar-invariance boundary

`StandardLatticeScalarInvariance` checks the actual scalar arrow of a
Möbius matrix for any canonical-line lattice chart with the proved
standard predicate. It retains the exact inverse-coordinate equality
and identifies its scalar unit with the actual Möbius denominator unit.
It also proves that the inverse of the constructed scalar-arrow/matrix
equivalence is precisely the constructed matrix-to-scalar function.
The new declarations are abstract to prevent repeated expansion of
their dependent proof certificates; every comparison is proved, not
assumed. The checked standard lattice and predicate computation supply
the chart inputs directly.

The identities, coherent fiber action, and actual small torsors are now
checked in `StandardLatticeIdentityCharts`. `EllipticModuliQuotient`
instantiates this construction with the actual standard lattice and
proved coverage, giving the literal finite-free moduli quotient
classification and original-map triangle. `EllipticModuliShape` now
proves its actual shape and specified universal-cover statements. No
conclusion of these classifications occurs as a field of the lattice
structure or as an additional premise of the final wrappers.

<a id="elliptic-lattice-identities"></a>

## Actual identities of complex lines with lattice subgroups

For any two actual complex lines L and M with actual finite-free
lattice subgroups Λ and Γ, the theorem identifies the actual path type

(L,Λ) = (M,Γ)

in `ComplexLatticeStructures.FiniteFreeModuli` with the small type

Σ e : LeftModuleEquiv L M,
      ∀ x, Member Λ x ≃ Member Γ (e x).

The subgroup is a literal proposition-valued predicate in the line's
carrier. Its closure laws, metric discreteness condition, and mere
integral-basis condition are propositions. Predicate equality therefore
determines equality of the lattice structures. The accepted theorem
combines that fact with the already proved univalent identity
characterization of actual complex lines.

The equivalence retains the actual first-coordinate path. Its inverse
`morphism-path` produces a literal moduli identity from a module
equivalence and membership preservation, and `morphism-path-line`
computes its projection to the line identity supplied by univalence.
`paths-equal-by-line` proves that two paths between fixed moduli points
are equal when their line projections are equal; the lattice fibers
are sets, so no higher lattice-path data is omitted.

### Exact mathematical scope

The real ring, Kock field axiom, project strict-order record, and
ordered-ring compatibility are ordinary explicit parameters inherited
from the actual lattice structures. The identity argument itself uses
only their constructed line/subgroup types and proposition-valued
laws. It introduces no additional synthetic axiom, choice principle,
resizing principle, or premise asserting the desired moduli quotient.

The metric condition in the lattice structure quantifies over all
actual real inner products on the arbitrary complex line and asks
merely for an actual positive rational isolation radius. Rank two is
explicitly the mere existence of an actual additive group equivalence
Z²≃Λ. No comparison with a weaker rational-rank definition is claimed.

### Downstream boundary

The arbitrary-line/lattice identity theorem does not by itself supply the
scalar-coordinate specialization, small chart-fiber models, q constructor,
Möbius denominator coherence, fiber action, or quotient equivalence. These
are the separate constructions in [Elliptic moduli](elliptic-moduli.md).

The earlier generic fiber-action and orbit-equivalence constructions
are already accepted, as documented in `elliptic-moduli.md#coherent-fiber-actions`.
The generic structural theorem used here is independently accepted in
`StructuredPredicateIdentities.agda`. Concrete scalar and chart work
is isolated in other modules so this accepted result remains stable.

<a id="canonical-lattice-identities"></a>

## Canonical-line scalar identities and small actual fibers

For any actual finite-free lattices Λ and Γ in the canonical complex
line, it proves the exact equivalence

((C,Λ) = (C,Γ))
      ≃ Σ u : ComplexUnit, ∀ z, Member Λ z ≃ Member Γ (u*z).

This specializes the checked arbitrary-line identity theorem through
the checked equivalence between actual complex-linear automorphisms
of the canonical line and actual complex scalar units. Evaluation at
1 supplies the scalar coordinate, and the checked linearity theorem
identifies every value of the map with multiplication by that scalar.
The membership equivalences are actual equivalences between the
literal subgroup predicates; no basis is chosen in a lattice.

### Small models of literal chart fibers

For any small parameter type S and actual canonical-line chart
`chart : S → FiniteFreeLattice C`, the file defines the actual map

parameterization s = (C,chart s).

Its codomain is the full type of complex lines with lattice subgroups,
which lies in the successor universe. For every actual moduli point Y,
the file constructs a small type

SmallFiber Y = Σ s:S, Morphism (C,chart s) Y

and an explicit equivalence from the literal homotopy fiber of
`parameterization` over Y to `SmallFiber Y`. The first parameter
coordinate is preserved by reflexivity. If S is a set, both the small
model and the literal larger-universe fiber are proved sets.

This is an explicit cross-universe equivalence derived from structural
univalence. No universe-resizing axiom, choice of line basis, truncation
of the fiber's paths, or assumption that the fiber is a torsor is used.
The ordinary real-ring, Kock-field, strict-order and ordered-ring
compatibility parameters are the same as in the underlying actual
lattice structures.

### Downstream use and rank boundary

The identity equivalence is used by `StandardLatticeIdentityCharts` and the
`EllipticModuliQuotient` wrapper, whose concrete orbit-map comparison is described
in [Elliptic moduli](elliptic-moduli.md). The generic identity result alone is not
the quotient theorem. Rank two here means mere existence of an additive group
equivalence ℤ² ≃ Λ; comparison with a weaker rank convention remains separate.

