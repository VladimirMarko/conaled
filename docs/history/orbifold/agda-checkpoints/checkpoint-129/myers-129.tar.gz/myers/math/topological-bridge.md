# Topological bridge

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="topological-branches"></a>

## The closed-anchor step and finite partial branches

New source:
`src/Orbifolds/Intensional/TopologicalFiniteBranches.agda`.

The subsequent finite shrinking provider is
`src/Orbifolds/Intensional/FiniteSeparation.agda`.

### 1. The mathematical step now expressed as a proof

The new source implements the middle and algebraic final steps of the
finite-bisection argument in Sections 3--4 of
[external-models.md#finite-bisection-interpretation](external-models.md#finite-bisection-interpretation).
For an anchor

\[
 p=(s,t):A\longrightarrow X\times Y
\]

and a fixed pair `(x0,y0)`, the input is a closed-map property, a finite
numbering of the single fiber over that pair, and pairwise disjoint open
neighborhoods of the numbered points on which `s` is injective. A product
open-basis operation and explicitly stated classical logic are also used.
The proof constructs open neighborhoods `U` and `V` of the pair and an
actual equivalence of the varying hom families

\[
 \operatorname{Hom}(x,y)
 \simeq \sum_{i:\operatorname{Fin}(n)}
          \sum_{d:D_i(x)}(\phi_i(x,d)=y),
 \qquad x\in U,\ y\in V.
\]

The partial domains are constructed from the original source fibers and
proved proposition-valued. The input contains no finite branch
decomposition over a rectangle, no hom/branch equivalence, and no already
completed local branch chart. The proof explicitly removes all other
arrows before constructing that equivalence.

The main exports are:

- `BranchConstruction.At.no-extra-arrows`: every arrow whose source is
  in the constructed `U` and target in the constructed `V` belongs to
  the selected finite union;
- `BranchConstruction.At.U-open` and `At.V-open`: the selected regions
  are open in the supplied topological structures;
- `BranchConstruction.At.hom-branches`: the actual fiberwise equivalence;
- `BranchConstruction.At.local-branch-chart` and
  `BranchConstruction.finite-bisections-local-chart`: the existing
  `FiniteBranchAtlas.LocalBranchChart` record, now constructed from these
  more elementary inputs;
- `BranchConstruction.Bounded.merely-finite-bisections-local-charts`:
  mapping bounded propositional truncation turns merely supplied local
  finite-fiber/neighborhood packages into the family of merely supplied
  charts required by the earlier ordinary theorem.

This is a point-set step in the external classical geometric argument. It
does not install classical logic in the internal smooth model.

### 2. Primitive topology and the exact closed-map interface

`Subset A` consists of a predicate `member : A -> Set ell` with a proof
that every membership type is a proposition. The underlying carriers and
membership types are at the same fixed universe. `Included P Q` is
pointwise implication. Intersection and complement are defined by pairs
and negation of membership, respectively. Function extensionality at
`ell,ell` proves that negated membership is a proposition.

`OpenFragment A` supplies four familiar open-set operations:

1. The whole subset is open.
2. Two predicates with pointwise implications both ways have the same
   openness status.
3. The intersection of two open subsets is open.
4. A subset is open if every member has an open neighborhood containing
   that member and included in the subset.

The fourth field is the ordinary neighborhood criterion for openness.
It derives the finite-union instance used here; the proof does not ask
for a special topology operation whose conclusion is the desired branch
decomposition. These fields specify the portion of point-set topology
used by this module, not a formalization of the whole category of
topological spaces or manifolds.

For a function `f : A -> B` and a subset `C`, the code defines the actual
image witness type

\[
 \operatorname{Image}(f,C,b)
   =\sum_{a:A}\bigl(C(a)\times(f(a)=b)\bigr).
\]

It need not be a proposition. Its negation is a proposition and defines
the subset `outsideImage ext f C`. Negating this witness type is
equivalent to negating mere image membership, without resizing a
truncation back into the carrier universe. This is why no small image
or propositional-resizing operation is hidden in the topology interface.

The exact definition is:

```text
ClosedMap ext OA OB f =
  (C : Subset A) ->
  IsOpen OA (complement ext C) ->
  IsOpen OB (outsideImage ext f C)
```

Thus every subset whose complement is open has an image with open
complement. In classical point-set topology this is the usual assertion
that `f` sends closed subsets to closed subsets. The definition concerns
every closed subset, independently of any selected fiber or branch data.
`CompactSeparation.proper→closed` now produces exactly this function from
continuity, compact preimages, chosen locally compact neighborhoods and
chosen Hausdorff separation, with explicit propositional excluded middle.
Its compactness input is an actual finite-subcover operation on indexed
open covers. It first proves compact images closed and closed subsets
compact, then performs the locally compact neighborhood argument. Thus
closedness is not a renamed properness assumption. Instantiating its
selected compactness and separation data from conventional classical
topology remains explicit; external classical choice at the fixed
universe can supply those selections. See
[properness.md#compact-separation-scope](properness.md#compact-separation-scope).

`RectangleBasis OX OY OXY` is the ordinary product-basis operation. From an
open subset of `X x Y` containing a pair, it supplies open source and
target neighborhoods containing that pair, together with their inclusion
in the given open subset. It does not refer to the anchor, arrows,
finite fibers, or branches.

### 3. What the finite-neighborhood package assumes

`FiniteFiberNeighborhoods OA s t x0 y0` has these fields:

| Field | Mathematical input |
| --- | --- |
| `piece-count` | A natural number `n` |
| `piece` and `piece-open` | A family of `n` open subsets `B_i` of the arrow carrier |
| `pieces-disjoint` | Simultaneous membership in `B_i` and `B_j` implies `i = j` |
| `source-injective` | On each `B_i`, equal sources imply equal arrows |
| `fiber-numbering` | An equivalence between the original fiber over `(x0,y0)` and `Fin n` |
| `center-in-piece` | The arrow numbered `i` belongs to `B_i` |

The original fiber is defined directly as

\[
 \operatorname{Hom}(x,y)
   =\sum_{a:A}\bigl((s(a)=x)\times(t(a)=y)\bigr).
\]

Nothing is assumed about the other fibers near the fixed pair. In
particular, the package does not say that these neighborhoods exhaust
all arrows over any open rectangle. Proving that assertion is the role
of the closed-map construction.

Full local bisections supply more information than this package uses.
The new point-set finite-predicate argument only needs source
injectivity on the chosen pieces. It does not use target injectivity or
a chosen smooth source inverse. Those stronger geometric facts remain
relevant to proving that the constructed domains are open submanifolds
and that their partial target maps are smooth.

The package asks for an actual finite numbering when constructing one
chart. Its bounded wrapper accepts the whole package merely, separately
at each pair, and maps that truncation into mere existence of a local
chart. Thus the application need not choose one global numbering or one
global family of chart witnesses.

### 4. Construction of the rectangle

Let `S(a)` be the indexed-sum membership

\[
                         S(a)=\sum_i B_i(a).
\]

Pairwise disjointness and propositionhood of each `B_i(a)` prove that
`S(a)` is a proposition. This avoids a truncated union and keeps its
membership small. Its openness follows from the neighborhood criterion:
at a member `(i,b)`, use the original open piece `B_i`, whose inclusion
in `S` sends `b'` to `(i,b')`.

The fiber numbering and its inverse law prove that every arrow in the
fiber over `(x0,y0)` belongs to `S`. The proof transports the membership
of its numbered representative along the actual equality supplied by
the numbering's retraction law.

Now form `C(a) = not S(a)`. To see that this is closed, its complement
has membership `not not S(a)`. The explicit classical parameter gives
the implication back to `S(a)`; the reverse implication is constructive.
Openness transfers from `S` to this double complement.

The closed-map hypothesis consequently proves that

\[
                         W=(X\times Y)\setminus p(C)
\]

is open. The center belongs to `W`: any witness of its membership in
`p(C)` would be an arrow in the original fiber together with a proof
that it belongs to no selected piece, contradicting fiber coverage.
The product basis now supplies the open rectangle `U x V` inside `W`.

For any arrow over that rectangle, assuming it lies outside `S` gives
an actual image witness in `p(C)` at its anchor, contradicting the
rectangle inclusion. Classical stability of `S(a)` turns this
double-negated membership into membership. This proves
`no-extra-arrows` for all arrows over the constructed rectangle.

`PropositionalDNE ell` is an explicit function parameter. It is used
only for the small proposition `S(a)`: once to identify its double
complement for openness and once to extract membership after the
image-complement argument. It is not a global postulate, an undecided
import, or a field of the existing smooth internal orbifold theorem.
The empty-fiber case is included by `n = 0`; the same construction gives
a rectangle containing no arrows.

### 5. Construction of the partial branches and inverse laws

Write `LocalSource = Sigma X U` and `LocalTarget = Sigma Y V`. For a
source point `x` in this restricted source, the code defines

\[
 D_i(x)=\sum_{a:A}
         \bigl(B_i(a)\times(s(a)=x)\times V(t(a))\bigr).
\]

This is the actual source fiber of the `i`th piece restricted by the
target region. Source injectivity shows that any two such witnesses
have equal arrows. All remaining fields are propositions, using the
given sethood of `X` and propositionhood of the regions. Hence `D_i(x)`
is a proposition. The target map takes its witness to `(t(a), V(t(a)))`.
No element is chosen from an arbitrary merely inhabited image.

An arrow from `x` to `y` in the rectangle receives its unique label by
`no-extra-arrows`, and its arrow and endpoint equalities give the
corresponding domain witness and target equality. Conversely, a label,
domain witness and target equality yield the original arrow with its
source and target equalities.

Both inverse laws are proved. The branch-side law first identifies the
two labels by disjointness and then uses propositionhood of the
remaining domain/target-equality fiber. The arrow-side law keeps the
same underlying arrow and uses propositionhood of its endpoint
equalities. Thus `hom-branches` is an actual `Equiv` with specified
forward and inverse functions, not an assumed equivalence between
unrelated carriers. Its assembly gives the existing local branch chart
record with the newly constructed open source and target regions.

### 6. The finite shrinking provider

`FiniteSeparation.shrink-finite-neighborhoods` constructs the disjoint
neighborhoods required above. Its input consists of an injective family
`point : Fin n -> A`, a chosen Hausdorff separation operation, and one
open neighborhood `V_i` containing each `point i`. Its output is a
`SeparatedRefinement`: open subsets `B_i` still containing those points,
included in the original neighborhoods, and pairwise disjoint. There is
no input field asserting that the original neighborhoods are disjoint.

The proof decides equality of finite labels by recursion on the ordinary
`Fin` constructors. It does not ask for decidable equality of the arrow
carrier or for a general excluded-middle principle. When `i` and `j`
differ, injectivity proves that their points differ, and chosen Hausdorff
separation gives `L_ij` around `point i` and `R_ij` around `point j`
with empty intersection. For equal labels, both subsets are the whole
space. The construction takes

\[
 B_i=V_i\cap\bigcap_j L_{ij}\cap\bigcap_j R_{ji}.
\]

Finite-index recursion constructs each intersection, its openness, its
center membership, and its projections. If a point belonged to both
`B_i` and `B_j` with different labels, it would belong to `L_ij` and
`R_ij` from the same selected separator, a contradiction. Using both
indexed families ensures that independent choices for the two ordered
pairs cannot break this argument. No general theorem asserting that
`Fin n` is a set is required by the implementation.

`SourceNeighborhood O s a` records an open subset containing `a` on
which `s` is injective. The export `numbered-fiber-neighborhoods` takes
the actual equivalence of the anchor fiber with `Fin n` and one such
neighborhood for each numbered arrow. It first proves that the numbered
underlying arrows are distinct: an equality of arrows lifts to equality
in the fiber because its endpoint-equality fields are propositions,
and the numbering's section law then identifies the labels. The finite
shrinking theorem applies. Source injectivity passes to each smaller
subset through its proved inclusion. The result is exactly
`TopologicalFiniteBranches.FiniteFiberNeighborhoods`.

The convenience export `chosen-local-fiber-neighborhoods` obtains the
initial finite family from a displayed operation supplying a source
neighborhood at every arrow. Thus chosen local source neighborhoods,
chosen Hausdorff separation, endpoint sethood and a finite numbering
now suffice; pairwise disjointness is derived. The source introduces
no new general EM/DNE parameter. External classical choice may supply
the chosen geometric neighborhood operations, as already distinguished
from their mere existence in the surrounding classical argument.

### 7. Native and semantic scope

Both new sources declare `--safe --without-K --no-import-sorts` and import
only the earlier ordinary identity, bounded-truncation and finite-branch
modules and the new ordinary topological/compact-separation modules,
plus ordinary universe and natural-number primitives. They use
no Cubical interval, `Glue`, univalence, native quotient HIT, crisp rule,
or global postulate. Function extensionality, source/target sethood,
the topological operations, the closed-map property, the product basis
and classical DNE are displayed parameters.

The bounded wrapper applies the existing `Tr` to
`FiniteFiberNeighborhoods`, which lives at `Code ell`, and maps it to
`LocalBranchChart`, also at `Code ell`. The output lives at `Truth ell`.
It neither truncates a `Truth ell` object nor resizes any result.

Classical DNE makes this a theorem intended for the external classical
point-set setting. It must not be instantiated as unrestricted excluded
middle inside the nonclassical smooth sheaf model. Likewise the fully
faithful comparison functor of
[source-interpretation.md#morita-comparison-074](source-interpretation.md#morita-comparison) cannot automatically
transport every construction here: that functor is not left exact.
Geometric representability and the preservation of the specific
pullbacks still matter.

In particular, this module proves a set-level family decomposition and
openness of the rectangle. It has not proved openness of every partial
domain, continuity or smoothness of its target map, a diffeomorphism of
manifolds, or the descent statement at all formal stages. The stronger
local-bisection geometry supplies those facts in the existing external
report; mechanizing them remains separate.

### 8. The providers and remaining geometric inputs in this local construction

`FiniteEnumeration` and `CompactDiscreteFibers` supply finite fiber
equivalences and the proper-anchor local chart assembly. `OpenBranchDomains`
supplies openness and partial continuity using chosen continuous local
source sections; its original branch target is preserved by reflexive
computation. These are the selected-data providers, not newly assumed
branch-specific conclusions.

Open-subspace and coproduct topologies, the actual finite-branch
homeomorphism and its forward/inverse diagrams are supplied by the
homeomorphism and proper-open-branch constructions below. They retain the
actual `At.Domain` and `At.Target` data. Smooth/formal interpretation remains
a separate obligation.

The milestone moves the former branch-chart assumption back to the
following independently meaningful ingredients:

The providers have separate scopes:

- `CompactSeparation.proper→closed` derives closedness from its finite-subcover
  compactness, compact-preimage, separation and local-compactness data. It
  does not assert anything about unrestricted internal `DPProper`.
- `FiniteEnumeration` and `CompactDiscreteFibers` construct the finite fiber
  numbering under their explicit classical hypotheses.
- `FiniteSeparation.chosen-local-fiber-neighborhoods` constructs disjoint
  neighborhoods from finite numbering and chosen Hausdorff/source operations.
  `LocalHomeomorphisms` supplies the local source inputs.
- The rectangle basis and actual branch homeomorphisms give the point-set
  diagrams. Connecting smooth branch geometry to formal-point descent and
  the internal local-chart fields requires the separate interpretation.

The elementary topological argument formalized here is the explicit one
in the earlier finite-bisection report. That report records the primary
geometric references and its separate external-model boundary. This
note makes no claim that those remaining prerequisites, the whole
classical groupoid construction, or the exact source-to-model transfer
have already been mechanized by adding this module.

<a id="lifting-semantics"></a>

## From vertex lifting to the actual boundary and gap

Status: `src/Orbifolds/Intensional/PushoutLifting.agda` has an independent
read-only mathematical review and an accepted native ordinary-mode check.
It closes the boundary-lifting step left open by
`topological-bridge.md#lifting-semantics`, retaining the pushout's actual universal
property as an independently interpreted input.

### 1. The categorical step

The accepted ordinary proof supplies both atlas-lifting fields in
Section 6 of `external-models.md#finite-bisection-interpretation` from the four vertex
lifting properties and the actual boundary's pushout universal property.
It is parameterized by an arbitrary map `q : A -> X`. No assertion that
the quotient is microlinear, has subfinite identities, or already has
boundary or gap lifting is stored in its input.

Let `C -> L` and `C -> R` be the NW-to-NE and NW-to-SW maps. Fix a common
base map `b : S -> C`. The proof first derives lifting at

\[
        b:S\to C,\qquad fb:S\to L,\qquad gb:S\to R
\]

to lifting at the actual boundary base `S -> B`. The result holds for an
arbitrary common source `S`. Taking `S = Unit` gives the required based
lifting. The proof then constructs the actual map `B -> D` from the
target cocone at the SE vertex and derives its basepoint equation from
the universal property. The accepted cancellation theorem turns boundary
and SE based lifting into lifting along that actual gap.

The main exports are `Existing.pushout-base-lifting` and
`Existing.pushout-gap-lifting`. Their conclusions use the exact
`Geometry.RightOrthogonal` definition, with
inverse data attached to the actual extension map.

### 2. The exact pushout interface

The code uses homotopy pullbacks represented by identity fibers:

\[
 \operatorname{Pullback}(u,v)
   =\sum_a\sum_b(vb=ua).
\]

For the fixed span, a target cocone is

\[
 \operatorname{Cocone}(Z)
   =\sum_{l:L\to Z}\sum_{r:R\to Z}(rg=lf).
\]

`PushoutBoundary` stores the carrier `B`, the two actual legs `iL`, `iR`,
and one equality of functions

\[
                        iR\,g=iL\,f.
\]

The orientation matches the displayed pullback convention. The
restriction function is fixed by these data:

\[
 \operatorname{restriction}_Z(h)
   =(h\,iL,h\,iR,\operatorname{ap}_{h\circ-}(glue)).
\]

`IsPushout B` states that this very function is an equivalence for every
`Z : Set ell`. It is independent of the atlas map `q`. In particular,
the interface supplies neither equivalence of an unspecified map between
the same types nor a boundary-lifting conclusion.

This is a bounded, nondependent universal-property interface. It is not
a native HIT definition. The actual pushout in the external higher
Cahiers category supplies it. The proof uses only its instances at
`A`, `X`, and the SE target `D`. No elimination into a larger universe
is required.

The universal property's inverse includes a path in the entire cocone
type. It therefore retains the coherence of the gluing path, not merely
equations on the two legs. Its computation is propositional; no
judgmental HIT computation law is requested. The standard mapping-out
universal property is also described in the HoTT Book, Lemma 6.8.2.
[H13]

### 3. Three squares give the boundary square

For a based object `bV : S -> V`, the actual comparison map is

\[
 (V\to A)\longrightarrow
 \sum_{a:S\to A}\operatorname{fib}_{-\circ bV}(qa),
 \qquad h\longmapsto(hbV,qh,refl).
\]

It is the comparison for the naturality square of restriction along
`bV` and postcomposition by `q`. The previously proved square/fiber
criterion converts between equivalence of this map and the existing
right-orthogonality condition.

The new `PullbackMap` calculation proves equivalence invariance of
homotopy pullbacks. Its forward map is explicitly defined using the
three component maps, the two specified square homotopies, and ordinary
transport. Equivalence of the three component maps gives equivalence
of the induced pullback map through the accepted fiberwise and
base-change lemmas. This preservation property is proved, not supplied
as a categorical axiom.

`BaseChangePullback` then proves that base change preserves a pullback.
It reorders the relevant dependent pairs, applies the actual fiber
equivalence of `BaseChange.total`, and reorders the remaining pairs.
Its forward map keeps the left endpoint's base witness. The gluing
path becomes the projection of the supplied total-space path.

Applying these constructions to the three vertex comparison maps gives
a comparison for cocones. A nested-congruence equation identifies the
resulting arrow with the actual postcomposition action on the cocone's
gluing path. The proof explicitly supplies this equation using
`cong-compose`; it does not replace the forward map by an unrelated
equivalence with the same domain and codomain.

Finally, restriction from the actual boundary is an equivalence at
`A` and `X`. The based restriction map is an equivalence on the relevant
identity fibers. Naturality of restriction and postcomposition is
proved as an equality in the based cocone type. Two-out-of-three then
shows that the actual boundary comparison is an equivalence. Converting
back gives `Geometry.RightOrthogonal` for the boundary base map.

### 4. The selected gap and its base equation

Let `target : Cocone D` be the actual SE cocone. The module `Gap` defines

\[
 gap=\operatorname{restriction}_D^{-1}(target).
\]

The inverse is obtained from the proved equivalence of the actual
restriction function. Its section law is a path

\[
                \operatorname{restriction}_D(gap)=target.
\]

Projecting that path to the left leg and restricting along `f b` gives
the exact equality of functions

\[
             gap\circ(iL\,f\,b)=target_L\,f\,b.
\]

Thus the selected gap and its base equation are constructed from the
cocone universal property. They are not two unrelated interface fields.
`Existing.pushout-gap-lifting` applies the accepted
`Existing.based-gap-lifting` cancellation theorem to this equation, the
newly derived boundary lifting, and the SE vertex lifting.

### 5. Coherence, universes, and model support

The proof deliberately represents the cocone's glue as an equality of
functions. Consequently postcomposition naturality follows from
identity induction's composition law for `cong`. It does not convert
pointwise paths using an arbitrary raw `FunExt`, and it requires neither
beta nor eta laws for that raw parameter. The compatibility wrapper
mentions `T` and `ext` only to instantiate the old `Geometry T ext`
definitions; the new proof invokes neither truncation nor function
extensionality.

All carriers, mapping types, pullbacks, identity fibers and equivalence
predicates lie at the fixed level `ell`. `PushoutBoundary` and the
target-uniform `IsPushout` property live at `Code ell`. The latter
quantifies over `Z : Set ell`; there is no `Setomega` field or assertion
of same-universe closure under arbitrary pushouts.

| Source data | Level and primitive requirements |
| --- | --- |
| Carriers, maps, cocones, pullbacks and equivalence fibers | `ell`; ordinary products, sums and identity types |
| `PushoutBoundary` | `Code ell`, because it contains the code of its carrier |
| `IsPushout B` | `Code ell`, because it quantifies over target codes in `Set ell` |
| Gap and its base equation | `ell`; inverse data from the actual restriction equivalence and `cong` |
| Compatibility with `Geometry T ext` | Existing parameters only; no new truncation or extensionality call |

The selected proof uses no native HIT eliminator, univalence, Cubical
operation, excluded-middle parameter, choice operation, or propositional
resizing. The import closure contains the earlier bounded-truncation
interface and a declaration of `CoherentFunExt`, but neither is invoked
by these new constructions.

For the external instance, first construct the selected small family
of Weil boundaries and choose the starting universe large enough to
contain those actual objects and maps, as in
`source-interpretation.md#language-bridge`. Shulman's ordinary strict model interprets
the source's sums, products, identities and derived equivalence
calculations. [S19] The actual pushout supplies the bounded universal
property. Uniformity over the target universe is interpreted at the
generic target context: colimits in an infinity-topos are stable under
base change. It is not an internal choice of unrelated inverse maps
for individual target types.

Externally, ordinary function extensionality in this model identifies
the code's function-equality cocones with the usual mapping-object
pullback description. The semantic interpretation uses this theorem
of the model; the new proof itself does not demand an extra opaque
function-extensionality computation rule.

### 6. What remains outside this proof

The source derives the two atlas lifting fields from actual pushout
data and lifting at the four finite Weil vertices. It does not prove
the geometric vertex lifting. That remains the independent formal
etaleness argument: nilpotent thickenings do not change the open-cover
space, and local diffeomorphisms lift uniquely after the reduced value
is specified.

It also does not construct the higher Cahiers site, its strict MLTT
model, or the actual external pushout inside Agda. The language-to-model
interpretation, the external colimit construction and its geometric
instance retain the explicitly stated trust boundary. This development
does not supply a semantic interpretation of the older native Cubical
implementation or the full Myers-oriented joint foundation.

### 7. The derived final theorem

`src/Orbifolds/Intensional/DerivedAtlasOrbifold.agda` now connects these
constructions to the ordinary finite-branch theorem. It also derives
the object's gap locality directly from the actual four-vertex mapping
comparison. Its final signature therefore takes neither the assembled
source-locality predicate nor either assembled atlas-lifting field as
an input.

#### Test data and the literal object comparison

`PointedPushoutTest` contains four carriers `NW`, `NE`, `SW`, `SE`, the
span `f : NW -> NE`, `g : NW -> SW`, the actual boundary and its
`IsPushout` proof, an origin in `NW`, and the actual target cocone
`c : Cocone SE`. It lives at `Code ell`. It imposes no undeclared Weil
algebra condition: the intended finite Weil family is an external
instance of these explicit data.

For each target `Z`, the map whose equivalence is required is literally

\[
 \mu_Z:(SE\to Z)\longrightarrow\operatorname{Cocone}(Z),
 \qquad h\longmapsto h_*c.
\]

Here `h_*c` postcomposes both legs and applies `cong` to the specified
gluing path. `Test.mapping-comparison` defines this map, and
`Theory.Family.ObjectSquares A` asserts its equivalence for `Z = A` at
every test in the selected family. It cannot be inhabited by merely
supplying an unrelated equivalence between the displayed types.

Let `rho_Z` be the actual boundary restriction and let
`gap = rho_SE^{-1}(c)`, exactly as in the accepted pushout construction.
`Test.gap-section` is the actual inverse law

\[
                         \rho_{SE}(gap)=c.
\]

`Test.restriction-naturality` proves equality in the whole cocone type,
including its gluing path:

\[
             \rho_Z(h\,gap)=h_*\rho_{SE}(gap).
\]

The gluing component is `cong-compose`; no function-extensionality
computation rule is assumed. Applying `h_*` to the section law then
gives `Test.comparison-computation`, the actual comparison homotopy

\[
                   \rho_Z\circ gap^*\simeq\mu_Z.
\]

Since `rho_Z` is an equivalence by the literal pushout universal
property, and `mu_Z` is an equivalence by `ObjectSquares`, the accepted
two-out-of-three lemma proves that `gap^*` is an equivalence. Its fibers
are definitionally the old `Geometry.Extension` types. Thus
`Test.mapping-square-local` supplies `Geometry.Local gap Z`, and
`Theory.Family.source-locality` supplies the old `Microlinear A`
predicate for the derived family. It does not assume that predicate in
disguise as a record field: it proves the comparison with the different,
four-vertex mapping-square condition, retaining the actual forward maps.

#### Both atlas fields from the four vertex lifts

`VertexLifting d q` has exactly four fields. They assert right
orthogonality of `q` to the based maps at

\[
 origin,\qquad f(origin),\qquad g(origin),\qquad c_L(f(origin))
\]

in the four respective vertex carriers. The SE basepoint is prescribed
by the actual target cocone, not chosen independently. The boundary
basepoint is `iL(f(origin))`, and the gap between these points is the
one constructed by the universal property.

`Theory.Family.vertex-lifting→etale` applies the accepted
`pushout-base-lifting` and `pushout-gap-lifting` theorems. It constructs
both old `InfinitesimallyEtale` fields for this very gap family. In
particular, the final wrapper does not take boundary lifting, gap
lifting, or an unspecified equivalent substitute as a premise.

The final export is
`Theory.Family.finite-branch-pushout-atlas-orbifold`. Its premises and
constructions are:

| Independently supplied premise | Native construction or use |
| --- | --- |
| The selected `PointedPushoutTest` family, including literal pushout universal properties | Actual gap maps, basepoints, and their base equations |
| Equivalence of every actual object comparison `mu_A` | Source gap locality for the derived family |
| Four based vertex lifting properties of the specified atlas map | Both completed atlas lifting fields |
| Actual `EffectiveAtlas`, including mere representatives and hom/path equivalences | Descent along that specified atlas and identification of its identity fibers |
| Sethood of the atlas carrier and mere local branch charts of its actual hom-family | Subfinite identities of the quotient |
| Existing bounded truncation and ordinary function extensionality | The earlier constructive descent proof |

The conclusion is exactly the old ordinary `ReducedOrbifold X` for
the derived test family: locality for those gap maps and subfinite
identity families. Subfinite still means a mere presentation as a
finite family of propositions; it does not mean decidable or ordinarily
enumerated cardinal finiteness. These are more primitive geometric
premises, not a claim that four vertex lifts are logically weaker than
every earlier assembled lifting interface.

#### Remaining interpretation boundary and continuation

The new comparison calculation uses only the already interpreted
ordinary identity, sum, product, and equivalence machinery. The
test-data record is at `Code ell`; `ObjectSquares`, vertex lifting,
and locality are at `ell`; the final orbifold record remains at
`Truth ell`. There is no new universe, resizing principle, native HIT,
or coherent-function-extensionality premise. Unlike the standalone
pushout proof, the final theorem invokes the existing bounded
truncation and raw function-extensionality parameters through the
earlier descent theorem.

For the finite Weil instance, the real-line tensor calculation and its
extension through open manifold charts must supply the actual
`ObjectSquares` premise. The formal etaleness argument must supply the
four vertex lifts. Groupoid effectivity must supply the actual atlas
and its hom/path comparison. The source now connects those inputs to
the conclusion, but does not construct those geometric inputs inside
Agda. The external explanation remains Sections 2, 4-6 of
`external-models.md#finite-bisection-interpretation`, read with the ordinary-language
boundary in `source-interpretation.md#language-bridge`.

The separately checked classical properness and finite-branch
construction supply a point-set chart. To supply this theorem's chart
input in higher Cahiers, the remaining geometric step is to upgrade
the branch pieces using local smooth source inverses, exhibit the
resulting diffeomorphism over an open rectangle, and preserve it at
formal stages using open restriction and sheaf descent. A classical
set-family bijection alone is insufficient for that transfer. This
wrapper imports none of the classical excluded-middle or compactness
interfaces and does not silently use them inside the smooth model.

The ordinary syntax interpretation, actual external pushouts, smooth
formal-point preservation, and classical restriction of the quotient
remain unmechanized. No claim about a model of the old native Cubical
development or the full Myers-oriented foundation has been added.

### Primary references

- **H13:** The Univalent Foundations Program, *Homotopy Type Theory:
  Univalent Foundations of Mathematics*, 2013, Lemma 6.8.2 and
  Theorems 4.7.1, 4.7.6-4.7.7. Official project publication:
  <https://homotopytypetheory.org/book/>.
- **S19:** Michael Shulman, *All (infinity,1)-toposes have strict univalent
  universes*, arXiv:1904.07004v2, 2019. Corollary 4.9; Theorem 11.2;
  Appendix A, especially Theorem A.26 and Remarks A.27-A.28.
  <https://arxiv.org/pdf/1904.07004>.

<a id="derived-atlas-interpretation"></a>

## Semantic audit of the derived finite-Weil atlas instance

**Finding:** the strengthened theorem introduces no new semantic
obstruction under the external universe assumptions and geometric
constructions already stated in `source-interpretation.md#language-bridge` and
`external-models.md#finite-bisection-interpretation`. Its new categorical combination is
native checked. The construction of its semantic instance and the
soundness/interpretation argument remain external mathematics. This
audit does not convert an axiomatic interface into a constructed native
model or claim an end-to-end machine-checked external theorem.

### 1. Exact source and evidence

The audited final theorem receives the actual effective atlas, its
set-valued object carrier, mere local finite-branch charts, a family of
actual pointed pushout tests, the actual object mapping-square
comparisons, and four based atlas lifting properties per test. It
constructs the gaps, source locality, boundary lifting, gap lifting,
and the reduced orbifold conclusion. The calculations are documented
in Section 7 of `topological-bridge.md#lifting-semantics`; an independent source review
also checked the actual comparison maps and path orientations.

### 2. Fixed universes contain the actual family

Use the already specified small skeleton of augmented finite real Weil
algebras and its selected pullback squares. This is a set of tests, not
an object-language quantification over all universes or all small
diagrams. Its constant sheaf is the test index. As usual, sections of
a constant sheaf over a disconnected stage may vary locally.

Before selecting the starting syntactic universe, form the entire
indexed span and its actual pushout family in the higher Cahiers
category. Regard the family as one morphism over the test index, and
do the same for all four vertex families, including SE. Also retain
the actual quotient, atlas, hom-family, and the selected family of
open-region predicates. Apply the fixed-morphism size bounds to these
data, and choose the starting universe at `ell` large enough to
classify them. Only then select `Code ell`, `Truth ell`, and the
universe containing the bounded-truncation interface.

This is the construction already specified in Section 3 of
`source-interpretation.md#language-bridge`. Shulman's Corollary 4.9 supplies the
fixed-morphism bounds; the selected universe hierarchy and strict
ordinary interpretation are supplied by its universe/coherence
theorems. [S19] Bounding a whole fixed small family is sufficient. It
does not assert that every `ell`-small span has an `ell`-small pushout,
or use the unproved same-universe parameterized-HIT closure claim.

`PointedPushoutTest` lives at `Code ell`. Its carriers are at `ell`, and
its `IsPushout` field quantifies over targets `Z : Set ell`, so that
field is also at `Code ell`. The code requires no new universe above
the already audited hierarchy and no resizing operation.

### 3. The universal property must be contextual

The required map is the literal restriction

\[
 \rho_Z:(B\to Z)\longrightarrow
 \sum_{l:NE\to Z}\sum_{r:SW\to Z}(r\,g=l\,f).
\]

It postcomposes the actual boundary legs and its actual gluing path.
Its equivalence for all `Z : Set ell` is an internal statement,
including parameter-dependent target types. An equivalence only of
global mapping spaces would not supply this field.

An actual pushout in an infinity-topos does supply it. Pull the
pushout family back to the generic target context. Colimits in an
infinity-topos are stable under base change, and the mapping-out
property in that slice gives the equivalence of the internal mapping
objects. The interpreted field is therefore one contextual proof,
stable under substitution. It is not a choice of unrelated inverse
maps for each externally named target. Restricting the genuine
universal property to targets in the selected universe causes no
additional size problem. The source uses no larger-target eliminator
or native HIT computation law. The ordinary pushout mapping-out
description is also stated in the HoTT Book, Lemma 6.8.2. [H13]

#### Function paths and raw function extensionality

The semantic ordinary model has the canonical comparison between an
identity of functions and a pointwise homotopy. Use that comparison
when representing the actual boundary's glue and its mapping-out
property. This identifies the displayed function-path cocone with
the usual homotopy-coherent cocone of the actual pushout.

The separate source parameter `ext : FunExt ell ell` asks only for a
map from pointwise paths to function paths. It has no beta or eta
field. The new computations do not require such a field: their
naturality equations are proved by `cong-compose` on an already
supplied function path. The model can supply its standard function
extensionality term for the old descent proof. [S19]

There is a precise limitation here: one may not apply an arbitrary
opaque raw `ext` to a pointwise HIT constructor and then infer that
the result has the canonical mapping-out property without a
comparison proof. The present instantiation uses the actual semantic
pushout and supplies its literal universal property directly. It
does not make that unsupported inference.

### 4. The selected gap matches the SE cocone

Let `c : Cocone SE` be the actual cocone obtained by dualizing the
chosen algebra pullback square. The source defines

\[
                          gap=\rho_{SE}^{-1}(c).
\]

Its `gap-section` is an equality in the whole cocone type
`rho_SE(gap) = c`, including the gluing path. The source does not
merely assert agreement of the two legs. Its base equation is a
projection of the same section.

Consequently the gap is a filler of the intended SE cocone. If the
external construction has independently selected another canonical
filler, the actual pushout property makes the filler space
contractible and identifies the two fillers with their cocone
coherence. This is equality up to the resulting path, not necessarily
judgmental equality between two independent presentation choices.
No additional arbitrary-gap compatibility assumption is needed.

### 5. The four exact atlas lifts

For a finite Weil vertex `V`, let `0 : 1 -> V` be its augmentation
point. The external argument must prove the actual evaluation square

\[
\begin{matrix}
 A^V&\longrightarrow&X^V\\
 \downarrow&&\downarrow\\
 A&\xrightarrow{q}&X
\end{matrix}
\]

is a pullback, uniformly over formal parameter stages. The code uses
`A^Unit` and `X^Unit` in the bottom row of its literal based
comparison. The natural equivalences `A^Unit ~= A` and `X^Unit ~= X`
identify these squares. The accepted based-comparison/fiber theorem
then supplies inverse data for the exact extension maps defining
`Geometry.RightOrthogonal`.

The external geometric proof applies to the actual atlas of the
quotient stack. Pulling it back gives a principal groupoid bundle,
locally an etale space. A local inverse of source extends a specified
lift uniquely across the relative nilpotent inclusion

\[
                  T\longrightarrow T\times V.
\]

Here `T` may already contain its own Weil directions; the given lift
is a `T`-valued lift, not only an ordinary point. The two stages have
the same underlying open-cover space. Local unique lifts therefore
glue, and the resulting comparison is an equivalence of sheaves,
not just a bijection of ordinary global points. This is the
parameter-uniform argument of Section 6 of
`external-models.md#finite-bisection-interpretation`.

All four points used by `VertexLifting` are prescribed:
`origin`, `f(origin)`, `g(origin)`, and `c_L(f(origin))`. Augmentation
preservation identifies them with the canonical points of their
respective finite Weil vertices. If a chosen model presentation makes
these identifications propositional rather than definitional, the
lifting proof is transported along those paths. There is no missing
independent choice of an SE point.

This supplies the primitive four fields. The boundary and gap lifting
properties are now derived natively from them; they should no longer
be counted as unproved categorical consequences in the ordinary
branch. The nilpotent etale lifting construction itself remains
external mathematics.

### 6. The manifold comparison is the required actual map

The object premise is equivalence of

\[
 \mu_M:(SE\to jM)\longrightarrow\operatorname{Cocone}(jM),
 \qquad h\longmapsto h_*c.
\]

It must be this map, not an unspecified equivalence between the same
objects. For a formal stage `T = U x ell W0`, put
`R_T = C-infinity(U) tensor_R W0`. For `M = R`, the four mapping sets
are the underlying sets of `R_T tensor_R W_v`, and the maps induced
by `c` are the tensor extensions of the actual algebra maps. Tensor
over the real field preserves finite limits of vector spaces. Since
the Weil pullback and its tensor extension have the corresponding
algebra operations, this proves equivalence of precisely `mu_R`,
uniformly at every formal stage. The finite Taylor description of
formal maps is the well-adapted finite-Weil calculation. [D79, K06]

Finite powers give Euclidean targets. For an open subset, a formal
map factors through it exactly when its reduced underlying map does.
The two supplied legs of a cocone have the same reduced map because
the Weil vertices share their augmentation point and agree on NW.
Thus their Euclidean extension remains in the open subset. For a
manifold, cover the parameter stage by opens on which that common
reduced map lies in one chart, construct the unique chart extension,
and glue. These are the external arguments of Sections 2 and 5 of
`external-models.md#finite-bisection-interpretation`.

Manifold objects are 0-truncated, so the relevant function-path
equalities are propositions. The set-level comparison just described
therefore matches the full cocone type, including its unique
compatibility proof. It gives the exact `ObjectSquares` premise.
The native source now proves that this premise implies locality for
its selected gap, using the literal restriction universal property
and cancellation.

### 7. External charts supply internal mere chart families by descent

Choosing a classical finite chart around each ordinary pair does not
by itself define an internally varying chart-selection function.
The selected charts may vary discontinuously with the pair. The
valid bridge uses each chart on its entire open rectangle.

For each selected open branch piece `B_i`, use a local smooth source
inverse `sigma_i : S_i -> B_i`, with `S_i` open. Its domain over a
rectangle is explicitly

\[
          D_i=U\cap S_i\cap(t\sigma_i)^{-1}(V),
 \qquad \phi_i=t\sigma_i|_{D_i}.
\]

The existing unique source-fiber domain is equivalent to this open
domain by the inverse laws. Disjoint open exhaustion yields a genuine
diffeomorphism over the rectangle

\[
                p^{-1}(U\times V)\cong\coprod_i D_i.
\]

The functor of formal points preserves the products and open
restriction pullbacks involved here, and sends the disjoint open
cover to a coproduct after sheaf descent. Well-adaptedness supplies
the requisite transverse-pullback and open-cover preservation.
[D79, K06] No assertion that it preserves arbitrary manifold anchor
fibers or arbitrary set bijections is needed. Formal homs are fibers
of the interpreted anchor; those fibers need not themselves be
represented manifolds.

The rectangles form an effective epimorphic cover of `jG0 x jG0`.
On each rectangle the fixed smooth chart gives the complete
`LocalBranchChart` data for every generalized pair in that rectangle.
Apply the genuine bounded truncation and descend these sections into
the resulting proposition-valued family. This produces
`Finiteness.LocalBranchCharts`, uniformly at all generalized points.
There is no internal choice of chart or global finite enumeration.
Finite labels vary locally on parameter stages; an internal `Fin n`
section records precisely that locally constant label.

The set of all available charts, or an externally selected covering
set of charts, can be bounded before the initial universe is chosen.
The universe bound must include their region families, not merely
each chart separately. The existing bounded truncation has enough
size for the resulting `Code ell` chart records and their
`Truth ell` truncations.

The new point-set modules now derive the finite decomposition and
open/continuous branch data under their displayed classical
interfaces. Their excluded-middle and selected compactness data
belong to the external classical interpretation. Smooth local
inverses, the smooth comparison, and formal-stage preservation/descent
remain a separate bridge. None of these classical principles is
silently assumed in the internal higher Cahiers theorem.

### Exact interpretation boundary

| Part | Status of this audit |
| --- | --- |
| Actual pushout restriction plus object-square comparison implies source locality | Native checked in `DerivedAtlasOrbifold` |
| Three based vertex lifts imply boundary lifting; SE lift and the derived triangle imply gap lifting | Native checked in `PushoutLifting` and `LiftingCancellation` |
| Effective atlas, source locality, those lifts and local finite charts imply the reduced orbifold conclusion | Native checked ordinary theorem |
| Classical properness, finite fiber numbering, disjoint pieces, and point-set branch data | Native checked separately in the external classical branch; their exact source interfaces remain explicit |
| Fixed model, its ordinary syntax/universes, and the bounded genuine truncation operation | External model theorem plus the project-specific bounded construction; not mechanized |
| Actual test-family pushouts and their contextual literal universal properties | External construction in the chosen higher Cahiers category; not mechanized |
| Finite Weil algebra comparison, manifold chart extension, and four atlas vertex lifts | External geometric proofs; not mechanized |
| Smooth branch comparison, formal-point preservation, and descent to internal mere charts | External geometric/sheaf bridge; not mechanized |
| Actual quotient effectivity and recovery on ordinary manifolds | External quotient/stackification argument; not mechanized |

Two wording qualifications should be preserved when using the older
external report. Its references to `ProperlyFinite` and the older
Cubical conclusion are not the native ordinary conclusion proved
here. The current conclusion is relative finite-Weil gap locality
and **Subfinite** identities: a mere finite family of propositions,
without decidable membership or ordinary cardinal enumeration.
Also, the selected `PointedPushoutTest` record does not express a
Weil algebra condition. The external algebra construction, not the
record's name or existence, establishes that intended instance.

No fatal mismatch was found. The three conditions requiring particular
care are: bound the actual whole small geometric family before choosing
the initial universe; supply the contextual literal pushout universal
property using the model's path/function interpretation; and compare
any independently selected external gap through the entire contractible
filler space. Subject to these already available external constructions,
the lifting and source-locality constructions supply the abstract categorical combination. It does not
remove the semantic construction and transfer from the trusted boundary.

### Primary sources reused

- **S19:** Michael Shulman, *All (infinity,1)-toposes have strict univalent
  universes*, 2019, Corollary 4.9; Theorems 11.1-11.2; Appendix A,
  especially Definition A.14, Example A.15, Theorems A.25-A.26, and
  Remarks A.27-A.28. <https://arxiv.org/pdf/1904.07004>.
- **H13:** The Univalent Foundations Program, *Homotopy Type Theory*,
  2013, Lemma 6.8.2. <https://homotopytypetheory.org/book/>.
- **D79:** Eduardo J. Dubuc, *Sur les modeles de la geometrie
  differentielle synthetique*, 1979, Definition I(2)(i)-(iii) and
  Theorem 4.10. <https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf>.
- **K06:** Anders Kock, *Synthetic Differential Geometry*, second
  edition, 2006, III Section 3 (Axiom A), III Section 4 (Axiom C),
  and III Section 9, example (2) and Theorem 9.4 (the Cahiers
  construction and well-adaptedness).
  <https://users-math.au.dk/kock/sdg99.pdf>.

These primary sources support the stated model components. The exact
finite-branch/Weil/atlas instance and its combination are the project's
derived arguments, not a claim that a cited source already formalizes
this complete theorem. Existing inspected sources and reports were
reused; this audit did not perform a new broad source search.

<a id="open-branch-domains"></a>

## Open domains and continuity of the actual partial branches

`OpenSubspaces` and `OpenBranchHomeomorphism` equip the actual domains with
subspace/coproduct topologies and construct both directions of the
homeomorphism and source/target diagrams. `LocalHomeomorphisms` supplies
the uniform source inputs; `ProperOpenBranchCharts` assembles the topological
result. These are separate from smooth and formal-stage descent.

Source: [OpenBranchDomains.agda](../src/Orbifolds/Intensional/OpenBranchDomains.agda).

This addition closes the topological openness and partial-target
continuity obligations for the actual domains constructed by
`TopologicalFiniteBranches`. The domain is the existing unique source
fiber, with its original witnesses, rather than a replacement family
whose relationship to the earlier chart is assumed. The new proofs use a
uniform source-openness property and target continuity. The same module
derives that uniform openness property from chosen continuous local
source sections through every point.

### 2. A small image predicate with actual witnesses

All carriers and membership types in the construction are at one fixed
universe level `ell`. The existing `Subset A` packages a predicate
`A -> Set ell` together with proposition-valued membership. The openness
interface is the existing `OpenFragment`, described in
[topological-bridge.md#topological-branches-075](topological-bridge.md#topological-branches).

For `s : A -> X` and a subset `C` of `A`, the actual source-image witness
at `x` is

\[
 \operatorname{Image}(s,C,x)
   = \sum_{a:A}\bigl(C(a)\times(s(a)=x)\bigr).
\]

When `X` is a set and `s` is injective on `C`, this witness type is a
proposition. Indeed, two witnesses have equal underlying points by
injectivity; their membership and endpoint-equality fields are
propositions. `injective-image-prop` proves precisely this fact, and
`injectiveImage` packages the same witness type as a small subset of
`X`. The construction does not truncate or resize an arbitrary image.
It also does not require a sethood assumption for all of `A`.

The uniform topology input is:

```text
OpenInjectiveImages OA OX s setX =
  (C : Subset A) ->
  IsOpen OA C ->
  (injective : InjectiveOn s C) ->
  IsOpen OX (injectiveImage setX s C injective)
```

This concerns every open subset on which the source map is injective.
It does not mention finite branches, a target map, a selected rectangle,
or the desired branch domains. In ordinary topology an open map has
this property. It is therefore an independently meaningful geometric
input, rather than the conclusion of the branch construction restated
as an assumption.

### 3. Deriving the uniform input from continuous local sections

`LocalContinuousSection OA OX s a` consists of an open neighborhood `S`
of `s(a)`, an actual function

\[
 \sigma : \{x\in X\mid S(x)\}\longrightarrow A,
\]

the right-section equation `s(sigma(x)) = x`, the equation that the
section takes its selected center witness to `a`, and continuity of
`sigma`. The continuity is expressed using the bounded partial-map
interface described in Section 5 below. The neighborhood and its
openness are part of this local-section data.

`ChosenLocalContinuousSections` supplies such a section through each
point of `A`. From this family,
`local-sections-open-injective-images` constructs
`OpenInjectiveImages`.

The proof is the usual local argument, with its witnesses exposed. For
an image point represented by `a in C`, choose the section through `a`.
The preimage of the open set `C` under that section is an open
neighborhood of `s(a)`. The center equation proves that it contains the
specified image point, and the right-section equation proves that the
whole neighborhood lies in the actual source image of `C`. The
`open-local` field of `OpenFragment` then proves that image open.
Injectivity is used to package its membership as a proposition, not to
assume a local inverse in this argument.

A local diffeomorphism supplies this local-section interface through
its local inverse. Instantiating that assertion from a formalized
category of manifolds and its charts has not been done here. The module
expects selected section data, rather than merely existential chart
claims. Conventional classical mathematics can supply those selections
using the appropriate choice principle; no global choice postulate is
added to this Agda source. Source continuity itself is not needed for
the openness argument, although it will be needed for the forward map
in a topological homeomorphism comparison.

### 4. The actual domain is open

Fix an open source-injective piece `C` of `A` and an open target region
`V` in `Y`. Assume that `t : A -> Y` is continuous and that `s` has the
uniform property from Section 2. The `BranchDomain` module defines

\[
 D(x)=\sum_{a:A}
       \sum_{c:C(a)}
       \sum_{p:s(a)=x}V(t(a)).
\]

The field order is deliberately the same as the existing
`BranchConstruction.At.Domain`. `domain-prop` proves that `D(x)` is a
proposition. The open subset of arrows

\[
 C\cap t^{-1}(V)
\]

is still source-injective. Its actual source image is open by
`OpenInjectiveImages`. `domain-image-equivalence` identifies that image
with `D(x)` by explicit reassociation of witness fields, with both
inverse laws proved by reflexivity. Openness transfers along the two
membership implications, giving `domain-open`.

For an additional open source region `U`, the nested `Restricted`
module defines the ambient source domain

\[
 D_U(x)=U(x)\times D(x)
\]

and proves `restricted-domain-open` by open intersection. Thus the
constructed branch has an open underlying domain in `X`, not only a
proposition-valued abstract domain over the local source type.

### 5. Continuity of the actual partial target map

For a proposition-valued domain `D` and an actual partial map
`f : (x : X) -> D(x) -> Y`, the module defines

\[
 \operatorname{PartialPreimage}(D,f,W)(x)
    =\sum_{d:D(x)}W(f(x,d)).
\]

This is a small proposition because both domain membership and `W`
membership are propositions. `PartialContinuous OX OY D f` says that
this subset is open in `X` for every open subset `W` of `Y`. When `D`
is open, this is the ordinary continuity condition for the map on its
open subtype, stated directly in ambient-subset language.

The actual target map is

\[
 \phi(x,d)=t(\operatorname{fst}(d)).
\]

For an arbitrary open test `W` in `Y`, its partial preimage is the
actual source image of

\[
 C\cap t^{-1}(V)\cap t^{-1}(W).
\]

That arrow subset is open by target continuity and remains
source-injective. The proof again uses the uniform source-openness
operation and an explicit reassociation of actual witnesses. This
establishes `partial-target-continuous`, with no new assumption about
the partial target map itself. `target-in-region` returns the retained
proof that its value lies in `V`.

`restrict-partial-continuity` proves that restricting such a map to an
additional open source subset preserves this condition. Consequently
`BranchDomain.Restricted` provides both
`restricted-target-continuous` and `restricted-target-in-region`.

The open-subspace adapter defines openness on the subtype `sum X D` by the small ambient predicate

\[
 x\longmapsto\sum_{d:D(x)}P(x,d).
\]

For that adapter, continuity of the uncurried map on the subtype will
match `PartialContinuous` directly. The construction of this topology,
and a packaged continuity theorem into the open subtype `V`, remain
separate work. This qualification concerns the representation of
topological spaces, not an assumption missing from the proved
ambient-preimage statements.

### 6. Compatibility with the existing selected finite branches

`SelectedBranches` instantiates the preceding result for each of the
pieces and the actual rectangle constructed by
`TopologicalFiniteBranches.BranchConstruction.At`. It exports:

| Export in `SelectedBranches.Piece i` | Accepted conclusion |
| --- | --- |
| `actual-domain-equivalence` | The original `At.Domain i x` equals the new raw domain at the underlying source point definitionally; the exported equivalence is the identity. |
| `actual-total-domain-equivalence` | The total original domain `sum At.LocalSource (At.Domain i)` is equivalent to the open ambient subtype, retaining the `U` witness. |
| `actual-domain-open` | That underlying subset of `X` is open. |
| `actual-target-continuous` | The actual partial target is continuous in the ambient-preimage sense of Section 5. |
| `actual-target-computation` | The map just proved continuous is the underlying map of the existing `At.Target`, by reflexivity. |
| `actual-target-in-region` | Its values lie in the actual selected target region `At.V`. |

There is no unproved identification between a convenient replacement
domain and the domain used by the earlier hom/branch equivalence. The
total-domain equivalence simply reassociates `((x,u),d)` and
`(x,(u,d))`, with reflexive inverse laws. The target computation law also
concerns the same actual map.

The compatibility module carries the existing function-extensionality
and propositional-double-negation-elimination parameters because the
earlier rectangle construction uses them. The new injective-image,
local-section, domain-openness, and partial-continuity proofs themselves
use neither parameter. They introduce no new truncation, excluded
middle, or global postulate.

### 7. Next geometric comparison and the remaining boundary

The homeomorphism adapter uses the branch theorem without assuming an
additional branch-specific inverse: instantiate `BranchDomain` with target
map `id_A`, topology `OA`, and target region `preimage t V`. Its raw domain
is definitionally the same `D(x)`, and its partial target is the actual
selector `sigma(x,d) = fst d`. Restriction to `U`, source continuity and the
open-subspace adapter yield the homeomorphism described below.

The corresponding finite-disjoint-union comparison must then retain
the actual arrow map, inverse laws, and source/target diagram. The
existing no-extra-arrows theorem and disjointness of pieces provide
the set-level coverage and uniqueness needed for that step. A
topology on the finite disjoint union and continuity of the resulting
maps remain to be supplied.

These are still point-set statements about the external geometric
argument. This module does not prove smoothness, a diffeomorphism, a
manifold structure on the selected domains, or descent at formal
stages. Smooth local inverses and a faithful interpretation of the
required open restrictions, products, diffeomorphisms, and covering
descent must be supplied for the geometric-to-formal passage described
in [external-models.md#finite-bisection-interpretation](external-models.md#finite-bisection-interpretation).
In particular, the non-left-exact formal-point extension established in
[source-interpretation.md#morita-comparison-074](source-interpretation.md#morita-comparison) cannot simply be
applied to arbitrary point-set equalizers or fibers.

The addition neither interprets the original Cubical development in a
full semantic model nor repairs literal `DPProper`. Its accepted scope
is the bounded ordinary theorem that the previously constructed
branches have open actual domains and continuous actual target maps
under the stated uniform topological inputs.

<a id="open-subspaces"></a>

## Open subspaces and coproduct topology in the ordinary branch

Assessment date: 2026-11-08. This note records an independent read-only
review of the accepted `OpenSubspaces.agda` source. The review found no
mathematical, transport-orientation, or universe defect in the displayed
constructions. No source was edited and no compiler was run by the
reviewer.

### The actual small extension of a subset

For a proposition-valued subset `D` of `A`, its carrier is the actual
dependent sum `Carrier D = Sigma A (member D)`. Given a subset `P` of
that carrier, `extendSubset D P` has membership

\[
             a\longmapsto\sum_{d:D(a)}P(a,d).
\]

This is the fiberwise projection image. Identity elimination identifies
it with the explicit witness/path fiber of the projection from
`Sigma (Carrier D) (member P)` to `A`. The displayed smaller form
simply fixes the base coordinate before storing its two witnesses.
Both witnesses are propositions, so the dependent sum is already a
proposition. This works without assuming that all of `A` is a set.

All membership types remain at `ell`. The subset records themselves
are at `Code ell`, as before. No large existential, image truncation,
propositional resizing, or choice operation occurs.

### The topology on an open subtype

For an explicitly open `D`, `openSubspace O D open-D` defines a subset
`P` of `Carrier D` to be open exactly when its projection extension is
open in `A`. This is the usual topology on an **open** subspace: an
open subset of that subspace is itself ambient-open. Openness of `D`
is essential to this formulation and is an explicit argument. The
module does not claim the same characterization for an arbitrary
nonopen subset.

The `OpenFragment` fields are derived from those of `O`. The full
subspace extends to `D`. For intersections, two membership witnesses
`d,e : D(a)` are identified using propositionhood; the `Q(a,e)`
witness is correctly transported along `e = d` before pairing it
with `P(a,d)`. The locality proof extends the chosen neighborhood
and retains its actual dependent membership witness. It assumes no
new local selection operation beyond the neighborhood data explicitly
received by `open-local`.

These are constructions of the existing openness interface. In the
external classical set interpretation, where that interface is supplied
by the ordinary topology, they give precisely the ordinary open-subspace
topology. No extra property asserting that arbitrary `IsOpen` witness
types are propositions is used or silently derived.

### Actual continuity helpers

The module proves continuity for identity and composition, restriction
of a continuous map to an open source subtype, inclusion of that
subtype, and corestriction to an open target subtype when an actual
landing proof is supplied. Every result refers to the specified
underlying function.

For corestriction, the ambient preimage has membership

\[
                  \sum_{d:D(fa)}P(fa,d).
\]

The actual corestricted function is `a |-> (f a, lands a)`. The forward
membership conversion therefore transports `P(fa,d)` along
`d = lands a`; the reverse conversion pairs `lands a` with the given
witness. This is the direction implemented by
`corestrict-continuous`. Restriction and composition use the literal
preimage predicates and their definitional identifications.

`Homeomorphism` records the actual `Equiv` and continuity of its
specified forward and backward functions. The identity, inverse, and
composition helpers retain those functions. In particular, composition
uses the reverse order for the backward continuous map. No theorem
about a selected branch decomposition is assumed by these helpers.

### Coproduct topology

`sumOpenFragment` defines a subset of `Sigma I A` to be open exactly
when its restriction along every component injection is open. Its
full-set, transfer, intersection, and locality fields are proved
componentwise. `injection-continuous` and `sum-map-continuous` apply to
the actual injections and actual componentwise maps.

For an external set-indexed family, including the finite ordinal
families used by the branch construction, this is exactly the
ordinary coproduct topology. No topology on the label set is an
input. The source is polymorphic in `I : Set ell`; that generality
does not assert that a higher index type or higher carrier is an
ordinary point-set space. The present external application uses sets.

### Interpretation boundary

The new constructions use ordinary dependent sums, identity transport,
proposition witnesses, and the existing openness interface. They invoke
no excluded-middle parameter, function-extensionality operation,
truncation eliminator, or higher inductive constructor. Classical
definitions imported with the earlier modules are not additional
premises of these proofs.

This module supplies derived topology and continuity infrastructure.
It does not construct smooth charts, prove that a particular
homeomorphism is a diffeomorphism, or interpret any set-level map in
the higher Cahiers category. The later branch-homeomorphism proof and
the smooth/formal-point preservation bridge remain separate tasks.
The semantic boundaries recorded in
`topological-bridge.md#derived-atlas-interpretation` are unchanged.

<a id="open-branch-homeomorphism"></a>

## The actual finite branch diagram as a homeomorphism

Source: [OpenBranchHomeomorphism.agda](../src/Orbifolds/Intensional/OpenBranchHomeomorphism.agda).

The ordinary development now constructs a homeomorphism from the actual
restricted arrow space to the finite disjoint union of the actual open
branch domains. It proves that this homeomorphism commutes with both
source and target, in both directions, and identifies its target maps
with those in the earlier finite branch chart. This closes the
topological diagram step beyond the open-domain and partial-continuity
theorem.

The construction is a theorem about the supplied `OpenFragment`
topologies. Smoothness and transfer of the resulting diagram to formal
stages are still separate obligations.

### 2. The exact mathematical conclusion

Write `s : A -> X` and `t : A -> Y` for the source and target functions.
The earlier closed-anchor construction supplies open neighborhoods `U`
and `V` and finitely many pairwise disjoint open pieces `C_i` of `A`,
such that `s` is injective on each piece and every arrow over `U x V`
lies in one of them. Its actual partial-domain witness is

\[
 D_i(x)=\sum_{a:A}
          \sum_{c:C_i(a)}
          \sum_{p:s(a)=x}V(t(a)),
 \qquad x\in U.
\]

The preceding
[open-domain theorem](topological-bridge.md#open-branch-domains) proved that

\[
 \widehat D_i(x)=U(x)\times D_i(x)
\]

is an open subset of `X`. The present theorem uses the open-subspace
topology on its carrier, and the componentwise coproduct topology on
the finite disjoint union. Let

\[
 R(a)=U(s(a))\times V(t(a)).
\]

`SelectedFiniteBranches.finite-branch-homeomorphism` constructs

\[
 H:\{a\in A\mid R(a)\}
     \;\cong\;
     \coprod_{i:\operatorname{Fin}(n)}
          \{x\in X\mid\widehat D_i(x)\}.
\]

Here a `Homeomorphism` contains an actual equivalence of the carrier
types, continuity of its actual forward function, and continuity of
its actual inverse function. This is stronger than an equivalence
of separate endpoint fibers or an existence claim about some
unspecified comparison map.

On the right, the source function sends `(i,(x,(u,d)))` to `(x,u)` in
`U`. The target function sends it to `t(fst d)`, with its stored
membership proof in `V`. Both functions are proved continuous into
those open subspaces. The forward diagrams say

\[
 s_{\rm branches}\circ H=s|_R,
 \qquad
 t_{\rm branches}\circ H=t|_R.
\]

The source also proves the corresponding two diagrams for `H`'s
inverse. These are pointwise equalities of the actual maps; no function
extensionality is needed to convert them into data used by the theorem.

### 3. Inputs and the absence of a circular decomposition assumption

The selected-branch module takes the earlier closed-map and product
rectangle-basis inputs, endpoint sethood, and the existing
`FiniteFiberNeighborhoods` package at the selected center. That package
contains a finite numbering of one anchor fiber and open disjoint
source-injective neighborhoods of its members. The earlier theorem
constructs the rectangle and proves coverage over that rectangle. The
new source does not assume a homeomorphism over the rectangle or a
continuous assignment of branch labels.

The new topological requirements are:

- continuity of `s : A -> X`;
- continuity of `t : A -> Y`;
- `OpenInjectiveImages OA OX s setX`, which states uniformly that the
  source image of every open source-injective subset is open.

The last property was already derived in
`OpenBranchDomains.local-sections-open-injective-images` from chosen
continuous local source sections through every point. It does not
mention finite branches, the selected rectangle, or the desired
homeomorphism. Thus one can use that accepted provider to instantiate
it. Source continuity is the additional ordinary requirement needed
for the forward source map in a homeomorphism; the earlier domain
openness argument did not need it.

The finite shrinking and compact-fiber providers remain the source of
the finite neighborhood package. The current result uses their common
interface, so it neither changes the meaning of properness nor
replaces finite enumeration by a decomposition assumption. Selection
of conventional classical compactness, separation, and chart data
remains an explicit external instantiation issue.

### 4. A homeomorphism for each actual piece

For one selected open piece `C`, the `OpenSourcePiece` module defines
the open arrow subset

\[
 B=\{a\in A\mid U(s(a))\times V(t(a))\times C(a)\}.
\]

The forward map sends an arrow `a` to its source `s(a)`, retaining the
arrow itself as the actual witness in the partial domain. The inverse
map retrieves the arrow from that witness. Its stored equality
`s(a)=x` transports the `U` membership back to `s(a)`. Proposition-valued
membership gives the two inverse laws by ordinary identity elimination
and dependent-pair paths.

Continuity of the forward map follows from source continuity,
restriction to the open arrow subset, and corestriction to the open
domain. The inverse has no newly assumed continuity field. Instead,
the proof reuses the accepted `BranchDomain` theorem with:

```text
new target map     = id_A
new target space   = A
new target region  = preimage t V
```

Its actual domain is definitionally the previous `D(x)`, including the
membership proposition proof. Its partial target is exactly the arrow
selector `sigma(x,d) = fst d`. The accepted partial-continuity theorem
therefore proves that this actual selector is continuous into `A`.
The open-subspace adapter turns that statement into ordinary
continuity on the constructed open domain; corestriction then gives
continuity into `B`.

The result is `OpenSourcePiece.piece-domain-homeomorphism`. No extra
branch-specific chart, inverse operation, or inverse-continuity
assumption appears. The same module constructs continuous domain
source and target maps into `U` and `V`, and proves its two forward
triangles by reflexivity.

### 5. The genuine finite disjoint union topology

[OpenSubspaces.agda](../src/Orbifolds/Intensional/OpenSubspaces.agda)
defines `sumOpenFragment`: a subset of a dependent sum is open exactly
when its restriction to each component is open. The index may be any
type in the fixed universe; the branch theorem specializes it to
`Fin n`. `sum-homeomorphism` assembles actual componentwise
homeomorphisms into a homeomorphism for this topology.

The generic `FiniteOpenPartition` module handles the remaining gluing
step. Its inputs are an open region `R`, pairwise disjoint open pieces
`C_i`, and a membership function proving that the pieces cover `R`.
It constructs an equivalence

\[
 \coprod_i (R\cap C_i)\longrightarrow R
\]

whose forward map forgets the label and whose inverse uses the supplied
coverage witness. Disjointness proves that changing from a given
component to the coverage witness and back preserves that component.

The forward map is continuous by open-subspace inclusion on each
component. For inverse continuity, consider an arbitrary open test
`P` on the coproduct. Its component restrictions give ambient open
subsets

\[
 W_i(a)=\sum_{b:(R\cap C_i)(a)}P(i,(a,b)).
\]

These are genuine small subsets: all displayed membership fields are
propositions. They are pairwise disjoint because the original `C_i`
are. Their actual finite union, with membership
`sum i (W_i(a))`, is therefore itself proposition-valued and open by
the earlier `finite-union-open` theorem. That union is exactly the
ambient extension of the inverse preimage of `P`. The proof gives
both membership implications explicitly; one implication transports
`P` along the proved inverse law for the component label.

This establishes `FiniteOpenPartition.partition-homeomorphism`.
Continuity of the label choice is a conclusion of this open-partition
argument, not an input. No arbitrary image truncation or resizing is
used.

### 6. Assembly and compatibility with the earlier chart

For the selected branches, the coverage function supplied to
`FiniteOpenPartition` is precisely the existing
`At.no-extra-arrows`. The finite-branch homeomorphism first uses the
inverse partition homeomorphism to attach the unique piece label to
each restricted arrow. It then applies the componentwise source-piece
homeomorphisms.

The key exports of `SelectedFiniteBranches` are:

| Export | Checked content |
| --- | --- |
| `finite-branch-homeomorphism` | The actual restricted arrow space is homeomorphic to the finite coproduct of actual open domains. |
| `decompose`, `assemble` | The forward and inverse maps of that homeomorphism. |
| `branch-source-continuous`, `branch-target-continuous` | Continuity into the actual selected open source and target regions. |
| `source-diagram`, `target-diagram` | Forward source and target triangles, proved by reflexivity. |
| `inverse-source-diagram`, `inverse-target-diagram` | The corresponding inverse triangles; the source proof uses the stored source equality, and the target proof is reflexive. |
| `actual-domain-equivalence` | The new raw domain is the original `At.Domain`, with an identity equivalence. |
| `actual-target-computation` | The target in the homeomorphism diagram is the original `At.Target`, by reflexivity. |

The maps are therefore compatible with the actual branch data used in
the existing hom-family equivalence. There is no unresolved replacement
of either its domains or its target functions.

The general open-partition and piece-homeomorphism proofs introduce no
classical logic, truncation, function extensionality, or global
postulate. `SelectedFiniteBranches` carries the existing extensionality
and propositional-double-negation-elimination parameters solely to use
the earlier closed-anchor rectangle construction.

### 7. What remains for a smooth and formal diagram

This theorem proves a topological homeomorphism. Its hypotheses require
only continuity of `t`; they do not imply that the partial branch
targets are smooth or local diffeomorphisms. A construction in the
smooth category needs smooth `s` and `t`, their relevant local inverse
data, and the corresponding smooth restriction and gluing arguments.
In particular, the actual selector above must be proved smooth. For a
source local diffeomorphism, the expected proof identifies it locally
with the source's smooth inverse by injectivity on the selected piece.
The finite disjoint open assembly then needs the smooth analogue of
the gluing argument. These smoothness assertions are not exports of
the accepted source.

Once a smooth diagram is available, its geometric shape is suitable
for the intended formal-stage argument: it uses a finite coproduct of
open manifold domains, the open restriction of the arrow manifold,
and an actual diffeomorphism preserving source and target. One can
then interpret the whole smooth diagram using preservation of products,
open restrictions, diffeomorphisms, and the relevant covering descent,
and take its endpoint fibers inside the formal model. This route does
not require applying a classical-to-formal extension directly to
arbitrary classical anchor fibers. Its preservation and descent facts
still need to be supplied at the claimed trust level; see
[external-models.md#finite-bisection-interpretation](external-models.md#finite-bisection-interpretation)
and [source-interpretation.md#morita-comparison-074](source-interpretation.md#morita-comparison).

No full interpretation of the original Cubical development, no repair
of literal `DPProper`, and no machine-checked smooth or formal-stack
comparison follows merely from the present topological theorem. The
accepted advance is the complete actual topological finite-branch
diagram, including the homeomorphism, both directions of continuity,
and source/target compatibility.

<a id="proper-open-branch-charts"></a>

## Proper local source charts give the complete open branch diagram

Main source:
[ProperOpenBranchCharts.agda](../src/Orbifolds/Intensional/ProperOpenBranchCharts.agda).

Local chart provider:
[LocalHomeomorphisms.agda](../src/Orbifolds/Intensional/LocalHomeomorphisms.agda).

The point-set assembly now starts from genuine compact-preimage
properness, standard chosen local homeomorphism charts for the source,
target continuity, and the stated separation and compact-neighborhood
data. It derives the finite fibers, disjoint local pieces, closedness,
open branch domains, and the actual finite branch homeomorphism. None
of those conclusions is an input to the final assembly.

This is the complete topological branch-diagram theorem under those
primitive data. Smoothness, formal-stage descent, and a semantic
interpretation of the original Cubical development remain separate.

### 2. Final hypotheses

The theorem concerns maps

\[
 A\mathrel{\mathop{\longrightarrow}^{s}}X,
 \qquad A\mathrel{\mathop{\longrightarrow}^{t}}Y,
 \qquad p=(s,t):A\longrightarrow X\times Y.
\]

`Construction` has the following complete input list, grouped by role.

| Input | Precise content |
| --- | --- |
| Bounded carriers and topology | `A`, `X`, and `Y` at one fixed universe; sethood of each; `OpenFragment` structures `OA`, `OX`, `OY`, and `OXY` on their product. |
| Explicit logic | `FunExt ell ell` and `PropositionalEM ell`. Excluded middle is supplied for proposition-valued types at that level. |
| Arrow separation | `ChosenHausdorff OA`, giving selected disjoint open neighborhoods of unequal points of `A`. |
| Product separation | `ChosenHausdorff OXY`, on `X x Y`. |
| Product compact neighborhoods | `ChosenLocallyCompact OXY`: an open neighborhood of each point contained in a supplied compact subset. |
| Source geometry | `ChosenLocalHomeomorphisms OA OX s`, for the actual source function. |
| Target geometry | `Continuous OA OY t`. |
| Properness | `ProperData OA OXY p`: compact subsets of the target have compact preimages. |
| Product basis | `RectangleBasis OX OY OXY`: each open neighborhood of a pair contains a product of selected open neighborhoods of its coordinates. |

The input does not contain source continuity, a separate source
injectivity package, source-image openness, anchor continuity, a
closed-anchor property, finite fiber enumerations, disjoint branch
pieces, branch-domain openness, a branch equivalence, or a final
homeomorphism. These are all constructed.

The theorem needs no groupoid operations and requires only continuity
of the target. A proper etale Lie groupoid is a motivating eventual
instance; a formalization of that manifold instance and its smooth
structure is not part of the present module.

#### What the compactness and properness data mean

The existing `CompactData O K` is an actual finite-subcover operation.
For every small index type, family of open subsets, and coverage
witness assigning a containing member to every point of `K`, it
returns a finite list of indices and a proof that the listed opens
still cover `K`. The interface contains no finite enumeration of the
points of `K`.

`ProperData` is exactly

```text
(K : Subset target) ->
CompactData target-topology K ->
CompactData source-topology (preimage p K)
```

It contains neither closedness nor a finite-branch conclusion.
Continuity of `p` is derived separately and then used with properness
to prove closedness. The theorem therefore does not rename a closed-map
assumption as properness.

These selected operations are data forms of familiar classical
topological hypotheses. Interpreting conventional compactness,
properness, separation, and local chart existence as the displayed
selected data uses external classical choice at the relevant fixed
universe levels. That instantiation has not been mechanically derived
from a library of classical topological spaces. The Agda theorem keeps
the selected inputs explicit and adds no global choice postulate.

### 3. Standard local homeomorphism charts supply the source data

For each `a : A`, `LocalHomeomorphismChart OA OX s a` supplies:

- an open source patch containing `a` and an open target patch;
- proof that the actual restriction of `s` lands in the target patch;
- an inverse between these open subtypes, with left and right inverse
  laws for that actual restriction;
- continuity of the actual restriction and its inverse.

These are ordinary local homeomorphism data. The fields mention no
anchor properness, finite fiber, branch domain, or finite decomposition.

`LocalHomeomorphisms` derives three useful interfaces from those data.
The inverse laws make the actual source restriction injective, giving
`ChosenSourceNeighborhoods`. The inverse followed by the source-patch
inclusion gives chosen continuous local sections through the selected
point. Finally, the continuity of the restricted source maps and the
open-neighborhood criterion for openness prove global continuity of
`s`.

The final assembly exposes these as `source-neighborhoods`,
`source-sections`, and `source-continuous`. It then applies
`local-sections-open-injective-images` to derive `source-open`.
The precise conclusion is openness of the actual image of every open
source-injective subset. Injectivity and sethood of `X` make each such
actual image witness a small proposition. The proof does not require
an arbitrary-image resizing operation.

### 4. From properness to finite disjoint pieces and a closed anchor

First, `pair-continuous` proves continuity of the actual anchor from
source and target continuity. Given an open target test and a point
mapping into it, the supplied rectangle basis gives open coordinate
neighborhoods inside that test. Their two continuous preimages have
open intersection, providing a neighborhood in the anchor preimage.
The `open-local` operation proves the whole preimage open.

Next, the compact-fiber theorem uses compactness of a singleton in
`X x Y`, so properness supplies compactness of the actual anchor
fiber. The source chart neighborhoods are locally injective for the
anchor as well: equality of anchor values implies equality of source
values. Covering the compact fiber by these selected neighborhoods
gives a finite list of actual fiber points, and each neighborhood
contains at most one point of that fiber. The existing finite
enumeration theorem removes duplicates using the explicitly supplied
propositional excluded middle and constructs an actual equivalence
with `Fin n`.

The equivalence between the anchor fiber and

\[
 \operatorname{Hom}(x,y)
   =\sum_{a:A}(s(a)=x)\times(t(a)=y)
\]

gives `finite-hom-numbering` for every pair `(x,y)`. It is actual finite
numbering data, not merely a proof that a finite number could exist.
The existing finite separation theorem shrinks the selected source
neighborhoods around those finitely many distinct arrows to pairwise
disjoint open source-injective pieces. This constructs
`finite-local-pieces`; no disjointness or finite numbering is left as
a separate input.

Independently, `proper→closed` uses the derived anchor continuity,
compact preimages, product Hausdorff separation, and product compact
neighborhoods to construct `closed-anchor`. Its earlier checked proof
establishes compact-image closedness and closed-subset compactness
before the locally compact neighborhood argument. Thus this invocation
uses the actual properness theorem rather than a disguised closedness
field.

The final assembly uses the same derived finite package and its own
checked `closed-anchor` to instantiate `SelectedFiniteBranches`. The
result is not identified with a separately recomputed chart through
an assumed equality: all final outputs are taken from this one
instantiation `At.H`.

### 5. Every local conclusion now obtained from the final inputs

For every pair `(x,y)`, `Construction.At x y` selects open neighborhoods
`U` and `V`, containing `x` and `y`, together with finitely many actual
open branch domains. The full chain of formerly supplied conclusions
is now:

| Derived conclusion | Construction used |
| --- | --- |
| Continuity of the source | Local homeomorphism restriction continuity and open locality. |
| Open source-injective neighborhoods | The local inverse laws. |
| Chosen continuous local sections | The local inverse and inclusion of its open source patch. |
| Openness of injective source images | The local-section image argument. |
| Continuity of the anchor | `pair-continuous`, using the rectangle basis. |
| Compact anchor fibers | Properness applied to compact singletons. |
| Actual finite hom numbering | Compactness plus locally injective neighborhoods, finite-list coverage, and duplicate removal. |
| Disjoint open finite pieces | Finite shrinking using arrow Hausdorff separation. |
| Closedness of the anchor | The compact-preimage properness-to-closedness theorem. |
| Open `U` and `V`, with their center witnesses | Closedness excludes the image of the closed remainder; the rectangle basis supplies `U x V`. |
| No remaining arrows over the rectangle | The closed-remainder argument. |
| Proposition-valued actual domains and a hom/branch equivalence | The existing unique-source-witness construction. |
| Open underlying domains | Uniform injective-image openness applied to each piece restricted by the target region. |
| Continuous actual partial targets | The same image argument applied to arbitrary open target tests. |
| Continuous inverse arrow selectors | Reuse of that theorem with target `id_A`. |
| An actual finite coproduct homeomorphism | The source-piece homeomorphisms and the finite disjoint open partition theorem. |
| Source/target compatibility in both directions | The checked actual-map diagrams of that assembled homeomorphism. |

The main direct exports in `Construction.At` are:

```text
proper-local-branch-chart
proper-open-branch-homeomorphism
source-center
target-center
source-diagram
target-diagram
inverse-source-diagram
inverse-target-diagram
```

The nested `H` module retains the detailed open-domain, continuity,
actual-domain identity, and actual-target computation exports. Both
the local predicate chart and the topological homeomorphism use that
same `H` instance and its original maps.

Concretely, the homeomorphism is

\[
 \{a\in A\mid U(s(a))\times V(t(a))\}
 \;\cong\;
 \coprod_{i:\operatorname{Fin}(n)}
   \left\{x\in X\;\middle|\;
      U(x)\times
      \sum_{a:A}\bigl(C_i(a)\times(s(a)=x)\times V(t(a))\bigr)
   \right\}.
\]

All spaces carry the constructed open-subspace or coproduct topology.
The forward function and its inverse are continuous, and the displayed
homeomorphism commutes with the actual source and target into `U` and
`V`. The inverse does not assume a continuous branch-label choice: its
continuity was derived from the disjoint open partition. See
[topological-bridge.md#open-branch-homeomorphism-077](topological-bridge.md#open-branch-homeomorphism)
for that component of the proof.

### 6. Independent review and remaining scope

A read-only review of the final assembly and local-chart provider found
no circular hypothesis or mathematical mismatch. In particular, the
chart forward map is the specified restriction of `s`; the pair map
is the actual anchor; compactness is supplied by properness of that
anchor; and the final chart and homeomorphism are extracted from one
common selected construction. The checked abstractions preserve these
types and implementations while limiting normalization.

The logical parameters belong to this external classical point-set
theorem. They are not installed as axioms of the intended internal
smooth theory. The proof does not claim to deduce the displayed
selected topology and chart data inside that internal theory.

What remains at the geometric boundary is now smoothness and
interpretation, rather than the finite-fiber, shrinking, closedness,
openness, or topological diagram steps. One must instantiate the
standard data for the intended manifolds, prove that the actual inverse
selectors and assembled maps are smooth, and obtain the corresponding
diffeomorphism. Its whole source/target diagram can then be interpreted
using the required preservation of products, open restrictions,
diffeomorphisms, and covering descent, with endpoint fibers taken
inside the formal model. Those facts have not been mechanically
supplied by this source.

The result does not resolve the original literal `DPProper`
comparison, provide a full semantic model of the old Cubical
development, or assert that a non-left-exact classical-to-formal
extension preserves arbitrary point-set fibers. The accepted theorem
is the complete bounded ordinary topological branch construction from
the final hypotheses in Section 2.

<a id="smooth-branches"></a>

### The new result

The smooth development upgrades the actual functions from the 077 topological
branch construction. Its smoothness predicate is independently defined by
preservation of plots and continuity. Neither branch smoothness nor the final
diffeomorphism is an input field.

`SmoothBranchCharts.Theory.SelectedFiniteBranches.finite-branch-diffeomorphism`
has the actual open arrow region as source and the finite disjoint union of the
actual open branch domains as target. Its forward and inverse functions are
definitionally the accepted `decompose` and `assemble` functions:
`decompose-computation` and `assemble-computation` are both proved by `refl`.
Both directions commute with both source and target. The branch source and
target functions themselves are smooth.

`ProperSmoothBranchCharts.Theory.Construction.At.proper-smooth-branch-diffeomorphism`
assembles this from compact-preimage properness, chosen smooth local charts for
the actual source map, and smoothness of the target map. The existing chosen
separation, compact-neighborhood, rectangle-basis, sethood, function-extensionality
and classical-logic data stay explicit. It derives finite fibers, disjoint
source-injective pieces, the excluding rectangle, open domains and the final
diffeomorphism. A desired finite chart or smooth branch decomposition is never
supplied to this final theorem.

There is one properness construction instance and one selected smooth branch
instance at each object pair. All its statements refer to that selection;
source and target neighborhoods are not recomputed independently for different
parts of the diagram.

### Independent definition of smoothness

`LocalPlots.PlotProbes` fixes a small family of probe spaces and actual functions
between their open subsets. Its primitive reparametrization predicate is
independent of the spaces being studied. The assumptions are identity,
composition, inclusions of open domains, and continuity of those
reparametrizations.

For a separately supplied topology `OA`, `LocalPlotStructure OA` specifies
plots on every open probe domain. Its fields are constant plots,
reparametrization, gluing over open neighborhoods in a probe, and continuity
of plots. `Smooth SA SB f` means that the actual function `f` is continuous
and sends every plot of `SA` to a plot of `SB`. These are ordinary
compatible-topology plot structures. No claim is made that the generic
`OA` has already been constructed as the full D-topology.

The code proves identity, composition, equality invariance, smooth inclusion
and corestriction of open subspaces, and locality on the source. In particular,
locality of a smooth map is a theorem about plot preservation, not an extra
field that could assume the later branch result. The plot structure of an
open subtype is literally the ambient plot condition after forgetting its
membership proof.

The carrier types, probe points, reparametrization witnesses and subset
membership types are at level `ell`. Plot certificates are at `Code ell`,
one universe higher. The entire plot structure is at `Truth ell`. Local
presentations can therefore quantify over small open predicates without
resizing the resulting existential data. Plot certificates are not required
to be propositions. This distinction matters for the generated coproduct.

`CoproductPlots.SumPlots` is an ordinary inductive datatype whose constructors
are component plots, reparametrization and local gluing. Continuity and the
smooth coproduct mapping operations are proved by induction on certificates.
They are not postulated as properties of a branch-dependent structure. This
construction also includes the empty plot in an empty coproduct: the local
gluing constructor has a vacuous pointwise argument on the empty domain.

### Why the actual inverse is smooth

`LocalDiffeomorphismChart` supplies two open neighborhoods, the actual
restricted source map, a local inverse, the two inverse laws, and smoothness
of those two maps. This is ordinary chosen local-diffeomorphism data. It
contains no finite branch, properness, or atlas-transfer conclusion.

The key general lemma is `continuous-lift-smooth`. Suppose `s : A -> X` has
these chosen local charts, `g : B -> A` is continuous, `f : B -> X` is smooth,
and `s (g b) = f b` at every `b`. Then `g` is smooth. At `b`, use the chosen
source chart through `g b` and pull its open source neighborhood back along
`g`. On that neighborhood, `g` equals the local inverse composed with `f`.
The equality follows from the displayed commuting equation and the local
inverse law. The code derives smoothness of this local composite and applies
the independently proved source-locality theorem.

For a branch, `g` is the actual arrow selector already proved continuous in
077. The map `f` is inclusion of the actual branch domain into the source
manifold. Its commuting equation is the source equality stored in each
branch witness. Applying the lifting lemma proves smoothness of the selector,
and corestricting it gives the actual inverse of the source restriction.
Composing the selector with the original target map gives the original branch
target function. Thus smoothness is proved for the selected functions, with
their witnesses, rather than for an unrelated equivalent chart.

For the finite-label selection, restrict the arrow region to one of the
disjoint open pieces. On that neighborhood the actual label selector is equal
to the smooth injection of that component. The existing partition inverse
law proves this equality. Source locality then proves global smoothness of
the finite-label selector. Combining it with the componentwise
diffeomorphisms produces the required finite-branch diffeomorphism.

### A concrete external classical instance

This section supplies an external mathematical instance of the new primitive
records. It is our verification against their displayed fields. It is not a
native Agda construction of the real numbers, differentiation or manifolds.

Use ordinary finite-dimensional Hausdorff second-countable smooth manifolds
without boundary, with their usual topology. Lee's author-hosted first
chapter fixes these manifold conventions, treats open submanifolds in
Example 1.26 and products in Example 1.8, and establishes local compactness
in Proposition 1.12. [Lee, Chapter 1](https://sites.math.washington.edu/~lee/Books/ISM/c01.pdf).

The standard plot interpretation uses open Euclidean domains, constant plots,
smooth reparametrization and open-local gluing. For manifolds its plots are
ordinary smooth parametrizations, and plot-preserving maps recover ordinary
smooth maps. These definitions and the manifold comparison are stated in
Iglesias-Zemmour, Sections 1, 2, 5 and 6; Sections 7 and 22 give the induced
subset structure and open local maps. [An Introduction to Diffeology](https://math.huji.ac.il/~piz/documents/AITD.pdf).

Here is the exact instance, including the points where our code carries
additional explicit data.

1. Set `Probe = N` and `Points n = R^n`, including `R^0`. Give each probe its
   usual topology. Encode a subset by its ordinary membership proposition.
   Let `Reparam U V r` assert that `U` and `V` are open and that the underlying
   map `r : U -> V` is classically infinitely differentiable. The extra
   openness clauses make the predicate defined on all subsets, including
   nonopen ones. Every interface use already supplies openness. The chain
   rule, identity maps, restrictions of identity maps and continuity of
   differentiable maps give the four required reparametrization operations.

2. For a manifold `M`, let `Plots n U p` assert that `U` is open and that
   `p : U -> M` is a classically smooth map, with this proposition lifted to
   the certificate universe. Constants are smooth. Composing with the
   preceding reparametrizations gives the required new plots. For the local
   gluing field, each input neighborhood proves chart smoothness near its
   center. At every point this is exactly the local chart criterion for
   smoothness of the given global function `p`; no extension or choice of
   a new function is needed. Smooth maps are continuous, which gives
   `plot-continuous` for the usual topology.

3. In this instance the code's `Smooth M N f` is equivalent, as an existence
   property, to classical smoothness of the same function `f`. A classical
   smooth `f` is continuous and preserves plots by composition. Conversely,
   take an inverse coordinate chart `q : W -> M`, where `W` is an open
   subset of a Euclidean space. It is a plot. Plot preservation says that
   `f q` is classically smooth. Around each point, compose with a coordinate
   chart of `N`, restricting the domain as needed using the supplied
   continuity of `f`. This is precisely the coordinate criterion for `f`
   to be smooth. No assertion about an internal de Rham modality is used.

4. If `D` is open in `M`, the code's induced plots on `Carrier D` are exactly
   the classical plots of the open submanifold. One direction follows by
   composing with the smooth inclusion. For the converse, use an ambient
   chart restricted to `D`; its coordinate expression is unchanged by
   corestriction. This identifies the actual branch-domain structures with
   their ordinary open-manifold smooth structures.

5. The generated coproduct certificates have the same existence condition
   as the standard smooth plots on a finite disjoint union of these open
   submanifolds. Every constructor preserves classical smoothness:
   component inclusion, composition and locality establish this by induction.
   Conversely, for a classical smooth `p : U -> coproduct_i M_i` and any
   `u` in `U`, take the inverse image of the open component containing
   `p(u)`. On that open neighborhood the map factors through that component
   with a classically smooth component map. A `component-plot` certificate
   for each such restriction followed by `local-plot` gives a certificate
   for `p`. For an empty `U` the same construction is vacuous. No global
   constant-label assumption is imposed.

6. A classical local diffeomorphism `s : A -> X` gives the required chosen
   source charts by selecting, through every `a`, open sets on which the
   actual restriction of `s` is a diffeomorphism. Its genuine inverse and
   inverse equations give the record fields. The preceding comparisons
   provide the two required smoothness witnesses. Choice of this family is
   explicit selected data; it is not a conclusion about branches.

The finite sums in the branch theorem consist of open submanifolds of the
same `X`, so they have a common dimension and are again ordinary manifolds.
The code also permits arbitrary indexed families of compatible plot spaces;
this larger scope is unnecessary for this manifold instance. Generated
certificates can be proof-relevant. The correspondence here concerns the
underlying functions and existence of smoothness witnesses, not equality of
all certificate objects or a full-faithful functor on a category whose
morphisms retain those witnesses as extra data.

### The resulting classical theorem

Let `A`, `X`, `Y` be such manifolds, `s : A -> X` a local diffeomorphism,
`t : A -> Y` a smooth map, and `(s,t) : A -> X x Y` proper in the ordinary
compact-preimage sense. At every `(x,y)` there are open neighborhoods `U`
and `V`, finitely many disjoint open source-injective arrow pieces, and
open domains `D_i` in `U`, for which the actual restricted arrow space is
diffeomorphic to the finite disjoint union of the `D_i`.

The forward function sends an arrow to its unique piece label and its
source, with the actual branch witness. The inverse returns that witness's
arrow. The source diagram is projection to `U`; the target diagram uses
the original `t` applied to the inverse selector. Both diagrams commute in
both directions, and every map displayed in them is classically smooth.
The finite indexing set may be empty.

To apply the final assembly externally, usual manifold topologies satisfy
`OpenFragment`. The usual product topology gives the rectangle basis.
Hausdorffness and local compactness provide the required separation and
compact neighborhoods. Properness provides compactness of every compact
preimage. Standard classical set-theoretic choice supplies the particular
finite-subcover and neighborhood selections requested by the records.
Set-theoretic identity and function extensionality give the corresponding
ordinary intensional inputs; classical propositional EM is interpreted only
in this external point-set argument.

This yields an explicit external classical instance of the checked
implication. It does not make the Agda project self-contained in real
analysis. Replacing all of the external choices and manifold facts with
native definitions and checked witnesses remains a separate mechanization
task.

### Semantic and validation boundary

The smooth calculation requires neither the old `DPProper` predicate nor
any modal axiom. It does not identify classical properness with that
predicate. It also does not construct Myers's full setting, the coherent
appendix, or a smooth infinitesimal model by itself. It supplies the actual
smooth maps that the external semantic transfer uses. The following
section verifies that transfer for the already specified finite-Weil site.
Its proof remains external; a bijection on ordinary real points alone
would not supply it.

The set interpretation can be bounded by a fixed hierarchy of universes
containing the chosen reals, manifolds and families. The certificate universe
is kept one level larger as in the source. No propositional resizing or
unbounded universe of all plots is inferred from this construction.

### Audit of the full parameter-varying transfer

The construction below specializes the external argument in
[external-models.md#finite-bisection-interpretation](external-models.md#finite-bisection-interpretation),
Section 4, to the exact smooth maps now constructed. Its site and formal
point functor are those of
[source-interpretation.md#semantic-completion-078](source-interpretation.md#semantic-completion), Sections 2 and 4.
The whole argument is at arbitrary stages `T = Z x ell W0`, including
already present nilpotent directions. It adds no geometric hypothesis to
the stated Hausdorff-manifold/local-diffeomorphism/proper-anchor setting.

#### Transfer the maps before taking hom fibers

Let `jM` be the sheaf of formal points of a manifold `M`. Every classical
smooth function `f : M -> N` induces the actual natural transformation
`jf : jM -> jN`, by composition of formal smooth maps. This is defined
for all formal morphisms, including those mixing ordinary and nilpotent
coordinates. The equalities and inverse laws of the smooth functions are
preserved under composition. Hence the actual branch diffeomorphism
produces an equivalence of formal sheaves with the same source and target
diagrams.

For an open `O` in `M`, a formal map into `M` factors through `O` exactly
when its reduced map lands in `O`. The factorization is unique. Locally
this is localization of a smooth-function algebra to an open set: a
function with nowhere-zero reduced value stays invertible after a finite
nilpotent extension, using a finite geometric series. Smooth maps into
the open set are then obtained in local coordinates and glue uniquely.
Thus `jO -> jM` is a monomorphism and represents precisely this open
membership condition. This uses the actual formal map, not an identification
of that map with its reduction.

Products of manifolds are preserved by `j`, as is checked on coordinate
products and their open charts. Consequently the actual arrow region
`R = (s,t)^-1(U x V)` satisfies

\[
 jR \simeq jA\mathop{\times}_{jX\times jY}(jU\times jV).
\]

Only products and open restrictions occur in this comparison. The anchor
need not be a submersion. In particular, the argument never assumes that
`j` preserves an arbitrary point fiber of the anchor. An ordinary fiber
can be finite while its formal family still varies with nilpotent
parameters; the entire smooth diagram must be transferred first.

#### The coproduct is a sheaf coproduct

The classical summands `D_i` form a disjoint open cover of their finite
disjoint-union manifold. Every formal map into that manifold factors
locally through its open summands, and the intersection of two different
summands is empty. Sheaf descent therefore gives

\[
 j\left(\coprod_{i=1}^{n}D_i\right)
 \simeq \coprod_{i:\Delta\operatorname{Fin}(n)}jD_i.
\]

This is proved from the displayed open cover. It is not a general claim
that a Yoneda functor preserves coproducts. A section of the right-hand
side over `T` can use different labels on different open parts of `Z`.
The finite discrete label object has locally constant sections, as
required. When `n = 0`, the empty open cover yields the initial sheaf
and the same comparison.

After these identifications, take the fiber over the variable pair
`(x,y) : jU x jV` in the sheaf category. Fibers of the smooth diagram
give the natural family equivalence

\[
 \operatorname{Hom}(x,y)
 \simeq
 \sum_{i:\Delta\operatorname{Fin}(n)}
 \sum_{d:D_i(x)}\bigl(j\varphi_i(x,d)=y\bigr).
\]

The first fiber `D_i(x)` is a proposition because `jD_i -> jU` is
an open monomorphism. The target equality is a proposition because
`jV` is a sheaf of sets. The equality constraint is retained; it is
not replaced with a classical decision. This is precisely the
set-valued, parameter-varying branch-family input of the ordinary
finite-branch theorem.

#### Local witnesses for an arbitrary generalized pair

The selected rectangles cover the ordinary `X x Y`. Given an arbitrary
formal pair over `T`, pull this cover back along its reduced pair
`Z -> X x Y`. Each resulting open `Z_k` gives the formal restriction
`Z_k x ell W0`, and on that restriction the actual pair factors through
the corresponding `jU x jV`. The complete chart constructed above is
therefore available on a cover of `T`.

The source asks only for a merely existing chart. Interpret its bounded
truncation as the appropriate image, as constructed in
`source-interpretation.md#semantic-completion`, Section 3. A proposition with local witnesses
over an effective epimorphic cover has a global witness. This descends
the charts as mere existence. It does not choose a global rectangle,
global enumeration or global label for a generalized arrow.

Choose the geometric universe large enough to contain the one external
set of selected charts, their open regions and maps, together with the
fixed Weil test family. The existing finite hierarchy then contains the
chart records and their bounded truncations. No new resizing rule or
same-universe closure under all arbitrary colimits is needed.

#### What this resolves and what remains to mechanize

For the specified finite-Weil higher Cahiers setting, the smooth diagram
and this argument close the mathematical branch-transfer obligation at
all formal stages. The geometric properties just used are verified from
the independently specified site; branch-transfer equivalence has not
been added as a new assumed record field. The final Lie-groupoid
application separately retains its original groupoid operations and
source/target local-diffeomorphism hypotheses for the quotient atlas
and its four based lifts, as audited in
[topological-bridge.md#derived-atlas-interpretation-076](topological-bridge.md#derived-atlas-interpretation).

The new native theorem requires only a local-diffeomorphism source and a
smooth target. Its chosen arrow pieces are source-injective. It does
not claim that each selected piece is also target-injective, so its
output is a finite smooth branch decomposition. Target injectivity of
each piece is unnecessary for the transfer above. The stronger existing
external bisection construction can still be used for an etale groupoid.

The remaining end-to-end mechanization has these finite interfaces:

| Task | Current status |
| --- | --- |
| Build real calculus and ordinary manifold witnesses for `PlotProbes`, `LocalPlotStructure`, the chosen local charts and the point-set properness inputs. | Explicit external instance above; not constructed in native Agda. |
| Construct the chosen formal site, its sheaf category and the actual functor `j` on smooth maps; prove its products and open-restriction comparisons. | External construction and proof; no native category/model implementation. |
| Implement disjoint-open-cover descent, the actual hom-fiber comparison and descent of the bounded merely existing chart family. | External proof above at every formal stage; no native implementation. |
| Connect those data, the quotient atlas and its geometric lifts to the checked ordinary theorem in a strict semantic presentation. | External source-to-model audit in the cited reports; no machine-checked interpretation/soundness bridge. |

The missing native interfaces are substantive construction tasks. They
are not additional unproved geometric assumptions in the external
theorem, and their external proofs must not be reported as native
compiler checks. The classical point-set calculation uses EM and chosen
compactness data in its external set interpretation; the resulting smooth
maps are then transferred to the smooth sheaf setting. EM is not thereby
installed in that setting or in the independent reduced internal theorem.

<a id="dependency-boundaries"></a>

### 1. Assumption separation

The smooth and finite-support branches do not add assumptions to this theorem.
The latter sums use explicit classical DNE in the external set model;
the internal theorem continues to assume neither EM/DNE nor choice.

### 2. Actual signature and universe footprint

The final export is instantiated at one geometric level `ell`. Its
parameters and inputs are:

| Input | What is supplied |
| --- | --- |
| `T : BoundedTruncation ell` | A bounded universe-raising propositional truncation interface |
| `ext : FunExt ell ell` | Weak function extensionality at the displayed fixed levels |
| `Index : Set ell` and `tests : Index -> PointedPushoutTest ell` | A small family of actual spans, boundary cocones and SE cocones, with a chosen origin and the actual restriction universal property |
| `Q : EffectiveAtlas A X` | An actual map `A -> X`, mere surjectivity, an actual hom-family and hom/path equivalences |
| `isSet A` | Sethood of the atlas object carrier |
| `LocalBranchCharts (hom Q)` | Mere local finite-predicate branch charts of the actual hom-family |
| `ObjectSquares A` | Equivalence of each specified four-vertex mapping-comparison function |
| The four `VertexLifting` fields for each test | Inverse data for the actual extension maps at the NW, NE, SW and SE basepoints |

The conclusion is `ReducedOrbifold X` for the gaps derived from that
same test family: test-relative locality and subfinite identity types.
The completed source-locality predicate, boundary lifting and gap
lifting are proved within the construction, not additional input
fields. The theorem does not assume decidable membership in its finite
predicate presentations or a global numbering of quotient identities.

The universe levels remain the bounded ones already audited in
[source-interpretation.md#language-bridge-074](source-interpretation.md#language-bridge):

- `Code ell = lsuc ell` and `Truth ell = lsuc (lsuc ell)`.
- `T.Tr` takes `Set (Code ell)` to `Set (Truth ell)`. Its recursor
  eliminates into propositions at `Truth ell`; the low-level recursor
  is derived using `Lift`.
- `T` itself lives one universe above `Truth ell`.
- `PointedPushoutTest` and its target-uniform `IsPushout` field live at
  `Code ell`; the latter quantifies over `Z : Set ell`.
- Effective-atlas surjectivity, mere local branch charts and the
  subfinite conclusion live at `Truth ell`.

There is no `Setomega` interface field, same-universe truncation or
unrestricted pushout-closure assumption. `PointedPushoutTest` contains
no algebraic Weil condition: the intended finite-Weil family is a
separate geometric instance of its explicit data.

### 3. Where the supplied principles are used

The retained `FiniteBranchAtlas` descent proof uses weak function
extensionality in two places relevant here. `lift-map-merely` builds a
path between constant functions from the selected pointwise path.
`local-descends` uses `isPropIsContr ext` so that truncation can eliminate
into the proposition asserting contractibility of an extension fiber.

Mere atlas surjectivity is not converted into a globally chosen
section. `lift-map-merely` maps the mere point-fiber witness into a
mere lift witness. The locality proof eliminates that witness only
into a proposition. The subfinite-identity proof likewise descends
through mere atlas witnesses and maps mere local charts to the
propositional subfinite conclusion. It does not choose a family of
chart representatives or finite enumerations.

The new actual-map fiber calculus, transposition, pushout comparison
and gap cancellation use ordinary identity elimination, sums,
products and inverse data. The `LiftingCancellation.Existing` and
`PushoutLifting.Existing` compatibility modules carry `T` and `ext` to
instantiate the earlier `Geometry T ext` interface, but those new
categorical calculations invoke neither truncation nor function
extensionality. The object mapping-square comparison in
`DerivedAtlasOrbifold.Test` uses the actual cocone section and
`cong-compose`; it does not require a computation law for raw
function extensionality.

`Equivalence.agda` separately declares `CoherentFunExt`, together with
conditional `happly` equivalence results. That record is not a
parameter of the derived atlas theorem and no inhabitant of it is
supplied or used by this construction. The source does not infer its
beta or eta fields from arbitrary weak `FunExt`.

### 4. An imported definition is not an assumed axiom

The point-set modules define the types

```text
PropositionalEM ell  = {P : Set ell} -> isProp P -> P + Not P
PropositionalDNE ell = {P : Set ell} -> isProp P -> Not (Not P) -> P
```

These declarations define what an excluded-middle or double-negation
operation would be. They do not construct such an operation, introduce
a postulate or add an implicit parameter to every importing theorem.
Actual uses receive an explicit value named `classical`, with the
corresponding type in the enclosing module or function signature.

This distinction matters even within the point-set branch. For example,
`OpenSubspaces` imports the topology definitions and `Continuous`, whose
source module also contains the definition of `PropositionalEM`.
`OpenSubspaces` itself takes no EM/DNE parameter and its proofs do not
invoke such an operation. The same is true of the generic
`FiniteOpenPartition` and `OpenSourcePiece` constructions in
`OpenBranchHomeomorphism`.

The same rule applies to the bounded truncation and function
extensionality interfaces. Declaring their records or types is not
assuming an inhabitant. The derived theorem does require its displayed
`T` and `ext`, and their interpretation must be justified; optional
interfaces declared elsewhere are not silently added to its signature.

### 5. The separate point-set parameter boundary

The completed point-set stages use the following distinctions:

| Stage | Classical or selected-data dependence |
| --- | --- |
| `FiniteEnumeration.list-cover→finite` | Explicit decidable equality and an actual covering list; its EM wrapper obtains the equality decision from sethood and a supplied EM operation |
| `CompactDiscreteFibers.compact-locally-injective-fiber` | Explicit propositional EM, chosen local injectivity neighborhoods and an actual finite-subcover operation |
| `CompactSeparation.proper→closed` | Explicit weak function extensionality and propositional EM, continuity/properness data, chosen Hausdorff separation and chosen compact neighborhoods |
| `FiniteSeparation` shrinking | Chosen separating and source-neighborhood data; finite-label equality is decided by recursion, without a new general EM parameter |
| `TopologicalFiniteBranches.BranchConstruction` | Explicit DNE in the complement/removal argument, plus its displayed closed-map, rectangle and finite-neighborhood data |
| `OpenBranchDomains` core | Uniform open injective images and target continuity; the open-image condition is derived from chosen continuous local source sections without new EM or choice |
| `OpenSubspaces` and the generic homeomorphism constructions | Explicit topology and continuity data; no EM/DNE or choice principle |
| `OpenBranchHomeomorphism.SelectedFiniteBranches` | Carries the earlier explicit DNE parameter to obtain the actual rectangle and its coverage theorem; the new homeomorphism and continuity proofs add no classical principle |

The actual declarations and their accepted scope are documented in
[properness.md#finite-fiber-numbering-scope](properness.md#finite-fiber-numbering-scope),
[properness.md#compact-separation-scope](properness.md#compact-separation-scope),
[topological-bridge.md#topological-branches-075](topological-bridge.md#topological-branches), and
[topological-bridge.md#open-branch-domains-076](topological-bridge.md#open-branch-domains). The new
homeomorphism maps, topology and accepted individual evidence are in
[topological-bridge.md#open-branch-homeomorphism-077](topological-bridge.md#open-branch-homeomorphism).

`CompactData` returns an actual finite list and covering witnesses from
an actual cover. `ChosenHausdorff`, `ChosenLocallyCompact`,
`ChosenSourceNeighborhoods`, chosen local source sections and the
rectangle-basis operation likewise carry actual selected witnesses.
The source does not assert that these data types are propositions and
does not install a global choice axiom. If the external application
starts with conventional mere-existence versions of compactness,
separation and local charts, its metatheory must justify the selections
needed to populate these interfaces at the specified size.

The core finite-cover conversion produces a finite list of actual
fiber points. The finite enumeration then deduplicates it and proves
the lookup/search inverse laws. In the proper-anchor assembly,
finite fibers, closedness, disjoint neighborhoods and the final chart
are conclusions of the composition of these stages. This does not
make the classical and selected-data inputs disappear; it states
precisely which geometric conclusions have been derived from them.

### 6. Interpretation boundary

The internal theorem remains suitable for the ordinary bounded model
audited in [source-interpretation.md#language-bridge-074](source-interpretation.md#language-bridge) and
[topological-bridge.md#derived-atlas-interpretation-076](topological-bridge.md#derived-atlas-interpretation).
The latter treats the contextual all-target pushout universal
property, the size bound for the whole selected test family, the
actual gap coherence and the four vertex lifts. These are external
mathematical interpretation arguments, not a mechanized model construction.

The EM-dependent point-set assembly is interpreted in classical sets
with its displayed selected data. It is not obtained by importing
classical EM into the non-Boolean higher Cahiers model. Connecting its
actual smooth branch geometry to the internal local-chart fields
still requires preservation of the relevant geometric constructions
and descent at formal parameters. Native acceptance of both branches
in one source tree does not itself construct that transfer.

The positive categorical comparison functor is not left exact, as
proved in [source-interpretation.md#morita-comparison-074](source-interpretation.md#morita-comparison). Its full
faithfulness alone therefore cannot justify transferring arbitrary
dependent constructions from the classical point-set branch. The
specific geometric preservation arguments retain their separate role.

Finally, none of this audit interprets the older Cubical HIT proof or
constructs a model of the entire retained Myers-oriented foundation.
Those obligations remain distinct from the exact seven-file ordinary
theorem reviewed here.


<a id="local-homeomorphisms"></a>

## Local homeomorphism data and derived global continuity

### The exact local-map interface

`LocalHomeomorphismChart OA OX s a` contains an open source patch
`U` through `a`, an open target patch `V`, and a landing proof for
the actual restriction of the specified map `s`:

\[
 s_U:\operatorname{Carrier}(U)\longrightarrow\operatorname{Carrier}(V),
 \qquad u\longmapsto(s(\pi_1u),\operatorname{lands}(u)).
\]

Its remaining fields are an inverse of this exact function, both
inverse laws, continuity of this exact restriction, and continuity
of its displayed inverse. Thus the record cannot be supplied by an
unrelated homeomorphism between the same two open carriers.
`Chart.restriction-homeomorphism` packages the same maps into the
accepted `Homeomorphism` record.

`ChosenLocalHomeomorphisms OA OX s` supplies one such chart for every
source point. The fields contain no global continuity, finite fiber,
finite neighborhood system, branch decomposition, properness, or
quotient conclusion. They are ordinary uniform local-map data.

### Derived local injectivity and continuous sections

The export `local-homeomorphism-source-neighborhoods` supplies the
existing `ChosenSourceNeighborhoods OA s` interface. Its neighborhood
is the chart's actual source patch. Given `s b = s c` for two points
of that patch, propositionhood of target-patch membership lifts the
equality to an equality of their images under `s_U`. Applying the
specified inverse and its left laws gives equality in the source
carrier; projecting gives `b = c`. No ambient sethood, excluded
middle, or function extensionality is required for this argument.

The export `local-homeomorphism-sections` supplies
`ChosenLocalContinuousSections OA OX s`. Its target neighborhood is
`V`, and its section is the inverse followed by the source inclusion.
The right inverse law gives `s(section(x)) = x`; the left inverse
law at the source center gives that the section passes through the
specified arrow. The target center is obtained from the restriction's
landing proof, not separately chosen.

Continuity of the section is proved by composition with the source
inclusion. Since `V` is open, its subspace preimage predicate is
definitionally the existing `PartialContinuous` predicate. There is
no substitute selector, assumed branch-specific inverse, or added
continuity axiom.

### Global continuity is derived locally

The export `local-homeomorphism-continuous` proves `Continuous OA OX s`.
For an open target predicate `P`, a point of `s^{-1}(P)` lies in its
chosen chart's source patch `U`. The restriction's forward continuity,
composed with the target inclusion, proves ambient openness of the
literal predicate

\[
                         U\cap s^{-1}(P).
\]

That open neighborhood contains the point and is included in
`s^{-1}(P)`. Applying the existing `open-local` criterion proves
openness of the full preimage. The local chart assignment itself
need not be a continuous choice: only its actual open patches and
their local continuity statements enter this argument.

These three exports can be used with the earlier finite separation,
open injective-image, and branch-homeomorphism theorems. Their outputs
are derived from standard local homeomorphism data before any finite
fiber or branch is chosen.

### Universe and semantic scope

Carrier, membership, map, and equality types remain at `ell`.
Subset, chart, chosen-chart, and continuity interfaces live at
`Code ell`. No new universe, propositional resizing, truncation
operation, or higher inductive construction is introduced. All new
proofs use ordinary dependent sums, identity paths, and the existing
openness/continuity operations.

The input is deliberately **chosen** chart data. Translating a merely
existential classical local-homeomorphism definition into this uniform
assignment may use external choice. The source does not silently
perform that selection or assume a corresponding internal choice
principle. In its intended point-set interpretation the carriers are
external sets and `OpenFragment` is supplied by their ordinary topology.

A smooth local diffeomorphism supplies such topological charts by its
local smooth inverses, after forgetting smoothness. The adapter itself
proves no inverse function theorem and no smoothness result. Recovering
a smooth branch comparison and transferring it to formal stages remains
separate from these checked topological conversions. The previously
recorded higher Cahiers interpretation boundary is unchanged.
