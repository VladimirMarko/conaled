# Corrections

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="errata"></a>

## Known corrections and interpretation boundaries

Review date: 2026-11-08. Reference: David Jaz Myers,
*Orbifolds as microlinear types in synthetic differential cohesive homotopy
type theory*, [arXiv:2205.15887v1](https://arxiv.org/pdf/2205.15887).

This register distinguishes checked corrections, choices made in the
formalization, and semantic obligations. It is the consolidated list of
issues currently identified by the project; it is not a claim that a complete
independent review has found every issue in the paper. The three
`corrected-and-refuted` result-ledger rows count corrections to named results.
They do not count every definition-level correction or interpretation issue.

### Checked corrections

| ID | Location | Exact issue and retained result | Evidence |
| --- | --- | --- | --- |
| E01 | Lemma 2.2.12 | The printed forward-precomposition calculation does not give covariant transport of predicates under the fixed carrier-transport convention. Transport to the target precomposes with inverse carrier transport. The corrected subgroup-delooping result remains valid. | `SubgroupTorsors.Subgroup.transport-membership`; the closed `PredicateTransportCounterexample.RegularC3Action.subtorsors-differ`; [detailed correction](corrections.md#predicate-transport-correction) |
| E02 | Proposition 6.1.7 | The printed association condition makes the label unique for a fixed element. A constant relation to one label then satisfies it for every type, including the natural numbers. The valid finite-enumerability criterion makes the element unique for a fixed label. | `Association.association-characterization`; `AssociationCounterexample.printed-criterion-is-false`; [detailed correction](corrections.md#issue32-correction) |
| E03 | Proposition 6.2.4 | Subtype-based properness implies compact homotopy fibers when the codomain is a set. Without the set-codomain hypothesis, the direction `DPProper -> compact homotopy fibers` and the pullback-stability claim fail under the displayed synthetic assumptions; `compact homotopy fibers -> DPProper` remains valid. The set-codomain theorem used by the main presentation result is retained. | `ProperMaps.proper≃CompactFibers`; `HigherPropernessCounterexample.Ring.unrestricted-fiber-converse-is-false` and `self-pullback-not-proper`; [detailed correction](properness.md#higher-properness-correction) |
| E04 | The fundamental-groupoid construction preceding Definition 3.2.1 | The printed real-plus-circle nullification does not have the stated discrete-groupoid modal class with the usual sphere indexing. The project uses the real line plus the lifted 2-sphere and proves that its modal types are exactly shape-modal groupoids. | `ShapeOne.Ring.modal-characterization`; `SphereNullification.At.null-truncated`; [scope](differential-geometry.md#universal-cover-microlinear) and [covering classification](coverings.md#shape-coverings) |

E01 has a finite, closed counterexample and introduces no synthetic or
classical assumptions. It refutes the specific transport calculation, with
the action convention fixed; it does not refute every claim about subgroups.
The concrete three-cycle instance is an application of the generic
`Counterexample` module, so its closed exported name and the generic proof
declaration are both relevant source anchors.

E02 also has a closed constructive refutation. It changes the uniqueness
direction in the association criterion and preserves the later compactness
application, whose finite cover members are subsingletons.

E03 is an internal conditional refutation. The counterexample is the point
map into the actual torsor delooping of the additive real group. The required
noncompactness of the real line is derived under K, O, explicit ordered-ring
compatibility, and E. This is not an independently constructed semantic
countermodel of the entire foundation. It must not be combined with the
separate diagonal obstruction below as though the two were the same issue.

E04 is a definition-level correction and therefore does not add a fourth
`corrected-and-refuted` row to the 100-result ledger. The covering theorem,
elliptic universal-cover result, and universal-cover microlinearity theorem
use the corrected, characterized reflector. Their source correspondence
must continue to mention it.

### Additional source-level editorial issues

Issues E05--E07 were found by reading the previously unanchored
nonresult environments; E08 was found in the proof-body review of the
retained tangent-module theorem. All were verified against pages of the actual
[version 1 PDF](https://arxiv.org/pdf/2205.15887v1). They are mathematical
editorial findings, **not newly native-checked corrections**. None changes
the three `corrected-and-refuted` result-ledger rows. The PDF provenance and
the precise review limits are recorded in
[paper correspondence map](paper-map.json).

| ID | Exact source location | Printed issue | Justified repair and its limit |
| --- | --- | --- | --- |
| E05 | Example 2.1.7, PDF page 13, one-dimensional Hermitian-line paragraph | The claimed unitary map sends `1` to `ℓ / ⟨ℓ,ℓ⟩`. Its image has squared norm `1 / ⟨ℓ,ℓ⟩`, so it is not generally a unit vector. | Divide by the positive square root of `⟨ℓ,ℓ⟩`, when that square root is supplied. For example, in the standard complex line, `ℓ = 2` makes the printed image `1/2`, while the repaired image is `1`. This repairs the normalization step; it does not construct the missing Hermitian classifier in Agda. |
| E06 | Remark 4.2.5, PDF page 33 | The claimed reciprocal-bound characterization uses only `x < 1/n` for `n : ℕ`. Negative ordinary constants satisfy every such positive-denominator upper bound without being infinitesimal, and the displayed quantifier leaves the denominator at zero unspecified. | An intended smallness characterization needs positive integers and bounds on both sides, for example `-1/n < x < 1/n`, or an appropriate absolute-value formulation. The equivalence with the project's full double-negation neighborhood still needs a proof from explicit hypotheses; the editorial correction does not supply that proof. |
| E07 | Definition 2.2.10, PDF page 16, and its following connectedness argument on page 17 | The displayed pairwise root-of-unity and invariance conditions allow the empty subset. The following argument selects an element on the ground that `n ≥ 1`, although nonemptiness or cardinality is not included in the displayed conditions. | Add inhabitance explicitly for positive `n`, or explicitly retain the intended `n`-element condition from the preceding motivation. Inhabitance supplies the missing step in the stated orbit argument. If cardinality is part of the intended definition, it must also be stated and justified. The concrete Hermitian-cycle implementation remains missing. |
| E08 | Theorem 4.2.19, PDF page 36, final sentence of its proof | The conclusion calls the represented tangent construction a model of the Lawvere theory of `R-algebras`, although the diagram is built from finite free `R`-modules and matrices. | Replace `R-algebras` with `R-modules`, matching both the theorem statement and `HigherTangentModules`. The opening phrase assumes microlinearity, but the argument needs only the displayed infinitesimal-linearity squares, as the checked construction does. This is a prose correction; it does not add multiplication or a Lie bracket to the tangent type. |

Warnings 6.1.6 and 6.3.5 also require a scope qualification in summaries:
the parameter-dependent two-point quotient obstructs a **uniform**
discreteness or union-closure rule. It is not valid to say that every
specialization is nondiscrete; the zero-parameter specialization is a
singleton. This review records the qualification without adding another
literal-source erratum or claiming to have implemented those counterexamples.

### Explicit interpretations and additional premises

| ID | Location | What the development actually uses | What remains to be compared |
| --- | --- | --- | --- |
| I01 | Definition 2.4.6 and its elliptic-moduli applications | A metrically discrete additive subgroup with merely an actual integral group equivalence from `Z²`; metric discreteness quantifies over the implemented positive-definite real bilinear forms. | The paper does not define its abelian-group rank convention. Identification with weaker rational-rank data or a broader norm convention is not established. |
| I02 | Axiom 3, Postulate O | The literal `SyntheticField.StrictOrder` bullets, plus a separate `SyntheticOrder.OrderTheory.OrderedRingCompatibility` input relating comparison to positivity of a difference. | The compatibility input is not claimed to follow from the literal bullet-list record. A model or a fuller ordered-ring interface must supply it. |
| I03 | Corollary 5.2.12 | The separately stated infinitesimal inverse function theorem remains an explicit premise. | This is a premise in the source itself, not an omitted proof that the formalization has silently supplied. Any external application of this corollary must justify the premise. |

For I01, the actual finite-free elliptic classification and its original-map
universal cover have been proved at their recorded scope. The
proposition-indexed conditional-lattice diagnostic shows why exhibited
rational-spanning and commensurability data cannot uniformly supply an
integral basis in an ordinary varying context under K and first-order KL.
That diagnostic does not identify every possible definition of rational rank
or settle the author's intended convention. See
[complex-lattices.md#lattice-rank-diagnostic](complex-lattices.md#lattice-rank-diagnostic),
[elliptic-moduli.md#elliptic-moduli-quotient](elliptic-moduli.md#elliptic-moduli-quotient), and
[elliptic-moduli.md#elliptic-moduli-shape](elliptic-moduli.md#elliptic-moduli-shape).

I02 is an interface and source-completeness issue. The project does not claim
to have refuted the usual mathematical notion of an ordered ring. I03 is
listed to prevent an explicitly assumed analytic theorem from being hidden
by the short ledger status `checked-relative`.

#### S01 — Classical properness versus literal internal properness

The checked development proves, for an internal set `X`,

```agda
DPProper diagonal ≃ Discrete X
```

Here `Discrete` is ordinary decidable equality. Under the project's Kock
field and first-order Kock–Lawvere assumptions, it also proves that the
smooth-real diagonal is not `DPProper`. The declarations are
`ProperCompactDecisions.Diagonal.proper-diagonal≃discrete` and
`ProperCompactDecisions.SmoothReals.smooth-real-diagonal-not-DP-proper`.

Consequently a sound interpretation cannot simultaneously identify the
external real line with that smooth-real object, preserve its product and
diagonal, validate those assumptions, and send every classically proper map
to the literal internal `DPProper` predicate. The external unit Lie groupoid
on the real line provides the relevant test case: its source-target map is
the classically proper diagonal. This argument concerns the proposed
comparison package. It is not a theorem that no model of the synthetic
foundation exists or that no alternative external orbifold interpretation
can be useful.

`DPProper` quantifies over ordinary internal compact subtypes. Crispness of
the presentation does not change those binders. A comparison restricted to
fixed external compact subsets would therefore not establish its premise.
The complete scope discussion is in [properness.md#properness-scope](properness.md#properness-scope).
The internal main theorem is stated separately in
[properness.md#proper-etale-orbifold-scope](properness.md#proper-etale-orbifold-scope).

#### S02 — The actual foundations need a joint semantic realization

Native crisp annotations, uniform crisp identity and Flat rules, the
synthetic-real assumptions, and the required type-theoretic constructions
must be interpreted together for an external application. Native acceptance
of parameterized proofs does not construct their joint realization. The
additional rules must not be promoted from visible assumptions to native
Agda theorems in summaries.

An existing model and soundness theorem could supply this work if its
hypotheses cover the precise fragment used. A new construction is not always
necessary. Having a sound interpretation is necessary for transferring the
checked proofs to the intended external geometry. See
[foundations.md#foundations-review](foundations.md#foundations-review),
[foundations.md#crisp-foundation](foundations.md#crisp-foundation), and
[foundations.md#crisp-identity](foundations.md#crisp-identity).

The current [model audit](external-models.md#model-audit) resolves two
candidate questions negatively, with external proofs: the full
germ-determined Dubuc site with standard `Flat = Delta Gamma` fails the exact
RealFlat comparison, and the finite-Weil Cahiers site fails external tinyness
of the whole double-negation neighborhood. The latter also fails RealFlat
by the [de Rham sheaf construction](external-models.md#real-flat-de-rham),
whose finite coefficient certificate is separately native checked. These are failures of specified
models and modal choices, not a universal inconsistency result. The same
Cahiers site supports the [reduced finite-branch geometric theorem](external-models.md#finite-bisection-interpretation),
whose exact native language-transfer obligations remain explicit.

#### S03 — Coherent diagrams, strict rules, and universes

The general limit and colimit results use the specified quasi-unital
homotopy-coherent diagram presentation. The independent object/hom/value
universe theorem 5.0.1 and the common-universe A.0.5/A.0.9 interfaces have
different scope. The latter also retain their stated discrete-object,
discrete-hom, tiny-generator, crisp, and universe conditions. No resizing or
equivalence with every alternative infinity-category presentation is claimed.

`StrictCubicalExtensionality` and `StrictFunctionExtensionality` are visible
additional structural inputs where used. Ordinary Cubical function
extensionality is not asserted to supply them. Their realization belongs to
the semantic investigation of these coherent constructions, not automatically
to every earlier geometric theorem. See
[coherent-diagrams.md#coherent-diagram-boundary](coherent-diagrams.md#coherent-diagram-boundary),
[coherent-diagrams.md#enriched-bar-limits](coherent-diagrams.md#enriched-bar-limits),
[tiny-colimits.md#tiny-power-coherent-colimits](tiny-colimits.md#tiny-power-coherent-colimits), and
[tiny-colimits.md#tiny-null-coherent-colimits](tiny-colimits.md#tiny-null-coherent-colimits).

### Use in the revised development

`paper-map.json` attaches these issue IDs to the directly relevant
numbered environments when regenerated by the correspondence auditor. The
bounded classification of all 49 previously unanchored nonresult environments
is in [paper correspondence map](paper-map.json).
The complete review limits and the distinction
between reference coverage, declaration binding, proof acceptance, and
semantic realization are in [paper-map.json](paper-map.json).

<a id="issue32-correction"></a>

## Proposition 6.1.7: corrected finite association

Paper: David Jaz Myers, *Orbifolds as Microlinear Types in Synthetic
Differential Cohesive Homotopy Type Theory*, arXiv:2205.15887v1. Numbering here
refers to that version. Review date: 2026-11-04.

### Finding

**Proposition 6.1.7 has its uniqueness condition in the wrong coordinate.**
Its printed hypotheses make a relation the graph of a function from the
possibly infinite set to a finite set. That does not impose finiteness on the
domain. The corrected condition says that each finite label represents at most
one point, while a point may have more than one label.

This is a proposed correction independently verified against the paper's TeX
source. It is not being represented as an author-published erratum. The
[arXiv record](https://arxiv.org/abs/2205.15887) lists v1; the
[primary statement](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm7) is the
source of the comparison.

### How issue #32 leads to the finding

The association correction was identified in conaled’s paper/foundations assessment. That prior Lean discussion is attribution and mathematical comparison, not an imported proof dependency of this Agda development.


### Printed and corrected statements

Let `X` be a set, let `Fin n` be the finite ordinal, and let `R x i` be a
proposition. Both versions require totality:

\[
  \forall x:X,\quad \left\|\sum_{i:\mathrm{Fin}(n)}R(x,i)\right\|.
\]

The distinction is:

| Version | Uniqueness requirement | Meaning |
| --- | --- | --- |
| Printed | `R x i → R x j → i = j` | Each point receives at most one label. |
| Corrected | `R x i → R y i → x = y` | Each label denotes at most one point. |

The truncation bars express mere existence. They do not supply a global
choice of representatives. The Agda definitions retain these truncations.

For the printed version, take `n = 1` and make `R x i` always true. There is
one label, so totality and uniqueness of that label hold for every `X`. In
particular they hold for the natural numbers. Hence the claimed conclusion
would make the natural numbers subfinitely enumerable.

The proof in the paper tries to use the graph of `R` as an object embedded in
`Fin n`. Its projection to the label is injective only under the corrected
condition. Under the printed condition, `(0,*)` and `(1,*)` are distinct graph
points with the same image in `Fin 1`.

### Proof of the corrected characterization

Definition 6.1.1(4) describes subfinite enumerability by a span

\[
  X \xleftarrow{\;q\;} A \xhookrightarrow{\;e\;} \mathrm{Fin}(n),
\]

where `q` is surjective. Both directions can be proved constructively.

#### From an association to a span

Set

\[
 A = \sum_{i:\mathrm{Fin}(n)}\sum_{x:X}R(x,i),
 \qquad e(i,x,r)=i,\qquad q(i,x,r)=x.
\]

For a fixed `i`, any two elements `(x,r)` and `(y,s)` of the second fiber
have equal first components by corrected uniqueness. Their proof components
also agree because `R` is proposition-valued. Thus each fiber over `i` is a
proposition, which makes `e` an embedding. Totality makes `q` surjective.

This constructs the span rather than assuming the conclusion as a field of
some higher-level structure.

#### From a span to an association

Define the image relation

\[
 R(x,i)=\left\|\sum_{a:A}(e(a)=i)\times(q(a)=x)\right\|.
\]

Surjectivity of `q` gives totality. If `R(x,i)` and `R(y,i)`, choose their
witnesses only inside the proof of the proposition `x=y`. The embedding
property of `e` identifies the two witnesses in `A`, and applying `q`
identifies `x` and `y`. Elimination from the truncations is valid because `X`
is explicitly assumed to be a set.

The code proves the equivalence both with a fixed bound `n` and after merely
quantifying over `n`. It also proves equivalence with a surjection from an
object satisfying the existing Cubical library predicate `isSubFinSet`; this
connects the definition to the pinned external library.

#### Composition

For corrected associations `R : X × Y` and `S : Y × Z`, define

\[
 (S\circ R)(x,z)=\left\|\sum_{y:Y}R(x,y)\times S(y,z)\right\|.
\]

Totality composes. For two witnesses relating `x` and `x'` to the same `z`,
the uniqueness law for `S` first identifies their intermediate points in `Y`.
The uniqueness law for `R` then identifies `x` and `x'`. This proves the
second assertion of corrected Proposition 6.1.7: association to a subfinitely
enumerable set transfers subfinite enumerability to the source.

### Why the counterexample refutes the whole printed statement

Showing two points cannot be covered by a subset of `Fin 1` would only refute
the proposed bound. The paper's conclusion permits some finite bound, so the
Agda counterexample proves the stronger fact that the natural numbers have no
subfinite enumerating span at any bound.

Suppose a corrected association relates the natural numbers to `Fin n`.
Use totality for the finite list `0,...,n`. Constructive finite choice produces
merely a selection of one label for each member of `Fin(n+1)`. Corrected
uniqueness makes that selection injective: equal labels imply equal natural
numbers, and the finite-ordinal inclusion into the natural numbers is
injective. The pigeonhole principle rules out an injection of `Fin(n+1)` into
`Fin n`.

The contradiction is a proposition, so the final truncated finite selection
can be eliminated into it. No infinite choice, excluded middle, postulated
finiteness, or unsafe Agda feature is used. Combining this result with the
always-true relation to `Fin 1` gives a negation of the printed implication
for all sets, including its unbounded existential conclusion.

### Downstream consequences

The finiteness closure arguments in Proposition 6.1.9 must consistently use
the corrected direction. Restriction, products, and finite disjoint unions
preserve that condition; the arguments compare points with a shared label.
They must not copy the printed uniqueness calculation unchanged.

The final combinatorial step of Lemma 6.2.21 remains repairable. For a cover
by subsingleton subsets `U_y`, use `R(x,y) := x ∈ U_y`. Coverage gives
totality, and the subsingleton property of a single `U_y` gives the corrected
uniqueness condition. A subfinitely enumerable index type therefore makes
the covered set subfinitely enumerable. The combinatorial theorem takes the cover and its small index as explicit
hypotheses. Later accepted modules, culminating in `ManifoldCompactness`,
construct the geometric compact-finite argument from actual ordinary
manifold and Dubuc–Penon compactness hypotheses; see STATUS.md.

This correction does not by itself refute the main orbifold theorem. It
repairs a combinatorial dependency. Cohesion, synthetic infinitesimals,
microlinearity, descent, and the geometric compactness argument are
separate mathematical obligations, addressed by the later geometric
modules under the explicit ambient hypotheses.

### Agda declarations

`src/Orbifolds/Association.agda` contains the corrected definitions, span
constructions, fixed-bound and unbounded characterization, library bridge,
composition, downward transfer, and supplied subsingleton-cover theorem.

`src/Orbifolds/AssociationCounterexample.agda` contains the printed definition,
the constant-label construction for all types, the natural-number
non-enumerability theorem, and `printed-criterion-is-false`.

Both modules require Cubical Agda and are marked `--safe`. The checker uses
the project's explicit `libraries` registry, so each source obtains its flags
from its own `.agda-lib`; global Cubical flags are not imposed on primitive
modules. The proof terms for the corrected characterization and for the
negation of the printed statement were checked; these results establish this
combinatorial correction without claiming the paper's geometric theorems.

<a id="predicate-transport-correction"></a>

## A finite counterexample to the printed predicate-transport formula

`PredicateTransportCounterexample.agda` proves that the forward-
precomposition rule used in
[Myers, Lemma 2.2.12](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm12)
does not describe covariant transport of predicates.

This is a counterexample to that specific displayed transport claim.
It does not refute the paper's main conditional theorem. The separately
checked subgroup-delooping construction uses the correct transport rule
and remains valid; see `torsors.md#subgroup-delooping-scope`.

### The direction of transport

Let `p : A ≡ B`, and let `e : A → B` be its carrier transport. The
covariantly transported predicate `P : A → Prop` is the predicate on `B`
whose value at `b` is `P(e⁻¹ b)`. Thus, if carrier transport is the action
of `g`, transporting the subset gives its forward image under `g`.

The printed forward-precomposition expression instead evaluates
`P(g b)`. That is the inverse image under `g`, or the inverse translate
of the original subset. These operations differ for a three-cycle.

The module's `Counterexample.transport-membership` proves the correct
inverse-carrier formula by path induction. The source's proposed
expression is represented explicitly as `printed-predicate`, without
changing which carrier transport is called the action of `g`.

### A genuine three-element group and a genuine trivial subgroup

The finite carrier is Cubical `SumFin 3`, with points named zero, one,
and two. Using the sum representation avoids unsupported indexed
matching on transported `FinData` values. The cycle is

```text
0 ↦ 1,  1 ↦ 2,  2 ↦ 0.
```

The module constructs `C3 : Group ℓ-zero` by addition modulo three.
Associativity, unit, and inverse laws are all checked by the finite
calculations; the cycle is left action by the element one.

`trivial-inclusion` is an actual homomorphism from the one-element group
to `C3`, and `trivial-inclusion-isEmbedding` proves that it is an
embedding. Thus the counterexample uses the trivial subgroup, which
avoids any question about a non-normal subgroup failing to be preserved.

`TrivialSubtorsor X` is a predicate on `X` with contractible subtype.
The `Trivial` module equips that subtype with an actual algebraic torsor
structure for the one-element group, proves its inclusion is an
embedding, and proves equivariance for the ambient trivial action.
The relevant ambient sethood and all three equivariant subactions are
supplied in each counterexample instance. Consequently these are actual
trivial-subgroup torsors, not arbitrary predicates substituted for them.

### Actual transport and the printed expression disagree

The generic calculation starts with a pointed family and a checked
coordinate equivalence of its base fiber with the three-element set.
Its sole action-computation input says that carrier transport acts as
the cycle in these coordinates. The initial predicate is the fiber of
the coordinate equivalence above zero, hence a contractible singleton.

The module forms both subobjects:

- `actual`, by actual transport in the family of trivial subtorsors.
- `printed`, by the printed forward-precomposition expression. This
  subtype is also contractible: it is a fiber of a composite equivalence.

It proves `actual-one-member`, `printed-one-absent`, and
`printed-two-member`. The decisive result is

```agda
subtorsors-differ : actual ≡ printed → ⊥
```

There are two closed instantiations, with no remaining assumptions:

1. `UnivalentThreeCycle` uses univalence of the explicit cycle
   equivalence on the finite set.
2. `RegularC3Action` uses the actual accepted `TensorBundles` family for
   the regular algebraic `C3` action. Its loop is the checked group loop
   corresponding to one, and the required carrier computation is
   `tensor-action-transport`. This confirms the discrepancy in the
   project's actual action-delooping construction, not only along an
   unrelated type identity.

In either instance, the actual transported singleton has coordinate
one, whereas the printed expression has coordinate two. Equality would
force the printed predicate to hold at one, contradicted by the
distinctness of zero and two in the finite set.

### What remains valid

The correct inverse-carrier predicate-transport law is already used by
the accepted subgroup modules. In a regular left torsor, actual torsor
monodromy is right multiplication, an equivariant map; the subgroup
stabilizer argument then proves Proposition 2.2.13 without using the
incorrect arbitrary-action formula.

The counterexample introduces no synthetic-real assumptions, modal
axioms, excluded middle, resizing, or choice principles. All algebraic
and finite data are constructed, and the decisive conclusions inhabit
ordinary Cubical identity and empty types. No accepted source was
modified.

