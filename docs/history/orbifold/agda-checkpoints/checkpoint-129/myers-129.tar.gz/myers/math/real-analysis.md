# Real analysis

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="constructive-real-base"></a>

## Constructive real base and ordinary interface realization

The constructions below realize selected ordinary interfaces in Cubical
Agda using an actual located Dedekind-cut carrier. They supply concrete
mathematical objects, not by themselves a smooth model or a full source
interpretation theorem.

### Equality and structures are translated through actual maps

`IdentityPath` imports the existing ordinary inductive identity datatype
unchanged. `idToPath` maps its reflexivity constructor to a constant Cubical
path. `pathToId` transports ordinary reflexivity along a Cubical path. Both
composites are proved equal to the respective identity functions, pointwise,
using the actual maps. These are propositional inverse laws, not a judgmental
identification of the two equality types. Congruence and dependent substitution
also have explicit comparison proofs.

The module constructs ordinary function extensionality at every displayed pair
of levels using Cubical function extensionality and those equality conversions.
Its beta and eta equations are proved for this particular witness. It does not
upgrade an arbitrary parameter having the weaker ordinary FunExt signature.
`CoherentFunExt` packages the constructed witness and equations in the existing
ordinary coherent interface.

`Structures` converts the ordinary and Cubical dependent pairs with both
inverse laws. It converts Cubical isomorphisms/equivalences to the ordinary
quasi-inverse record and conversely, preserving the actual forward function by
reflexivity. These conversions do not identify all quasi-inverse proof data
with proposition-valued Cubical `isEquiv` data. The same distinction applies
when the resulting ordinary equivalence is used by another theorem.

Propositionhood, sethood and contractibility have conversions in both
directions. The `hSetSmallSetEquiv` construction preserves the carrier and
proves both round trips, including the needed propositionhood of the sethood
certificate. It therefore supplies an actual ordinary SmallSet from a Cubical
set; a mere assertion that a carrier has two equivalent descriptions is not
used in place of these maps.

### Bounded truncation is constructed at its existing levels

`Truncation` defines the existing ordinary truncation interface by the Cubical
propositional-truncation HIT and the ordinary Lift constructor. In the old
interface, `Code ℓ` is `lsuc ℓ` and `Truth ℓ` is `lsuc (lsuc ℓ)`. The
construction retains those increases exactly. It supplies the point map,
propositionhood and eliminator, and its eliminator computes on points by
ordinary reflexivity.

No resizing or downward universe identification is introduced. This is a
realization in the current Cubical metatheory. It does not construct a universe
classifier in a sheaf model, supply crisp source judgments, or prove source
interpretation and substitution.

### A real carrier built from rational predicates

`RationalDensity` uses the pinned ordered rational carrier
`Cubical.Data.Rationals.Base.ℚ` throughout. It constructs an actual rational
midpoint with both strict inequalities and explicit predecessor/successor
bounds. It does not mix that representation with `MoreRationals` merely
because the latter has a convenient field interface.

`DedekindCuts` defines a rational predicate as `ℚ → hProp ℓ-zero`. A
DedekindReal consists of lower and upper predicates, with six proved-law fields:
inhabitedness of both cuts, roundedness of each cut, strict separation, and
locatedness. The carrier is a concrete sigma type in universe 1; membership
and the law types live in universe 0. Existential witnesses and located
disjunctions use actual propositional truncation.

The law record is proved proposition-valued. The space of rational predicates
is a set using Cubical hProp extensionality; from this the full cut carrier is
proved a set. `cutExt` proves equality of cuts from the four pointwise
membership implications. This is actual extensional equality inside Cubical
Agda, not a quotient or setoid whose relation has been silently used as the
ordinary identity type.

`rationalCut` constructs all six cut laws for every rational. The map is
injective, and its actual action on equality proofs is an equivalence. The
constructed zero and one cuts are proved unequal. Positive strict order is
defined by a merely existing rational strictly between the two cuts; it is
proposition-valued, irreflexive, transitive, asymmetric and cotransitive.
Rational strict order is preserved and reflected by the designated embedding.

Apartness is the disjoint sum of the two strict-order directions. The module
proves its propositionhood, irreflexivity, symmetry, cotransitivity and
tightness. Tightness has the constructive direction

```text
not (x # y)  ->  x = y.
```

It does not decide equality, and it does not infer positive apartness from
mere inequality. Cotransitivity returns a truncated disjunction. The tightness
proof uses roundedness and locatedness to compare membership predicates;
there is no excluded-middle or choice parameter.

`DedekindInstance` connects this exact carrier to the existing ordinary
interfaces. It constructs `realSmallSet` at level 1 and proves its carrier
equal to DedekindReal by reflexivity. It supplies ordinary function
extensionality, rational injectivity, positive order and apartness
propositionhood, tightness, and noncontractibility from zero differing from
one. The rational-order equivalence has the designated forward map by
reflexivity.

This carrier is intended as a constructive external coefficient line for
ordinary analysis and the later smooth-site construction. It is not being
identified with the internal synthetic line at infinitesimal stages. That
line, its formal-stage values and its nilpotent behavior still need their own
actual construction and interpretation.

### What remains

Real arithmetic, metric completeness, topology and calculus are the separate constructions below. Their hypotheses distinguish constructive locatedness/convergence data from arbitrary classically bounded sets.

The later obligations remain actual smooth categories and covers, sheaves and
selected gluing/cover comparisons, finite-Weil and formal-stage operations,
dependent and higher semantics and universe classification, quotient/descent,
and exact source interpretation/substitution. General classical properness
comparison needs its own geometric proof. No result here settles the full
original Myers model/no-model question or the complete external theorem.

<a id="constructive-real-arithmetic"></a>

## Constructed real addition, order and bounded completeness

The arithmetic construction supplies an abelian group, order-preserving translations, finite rational approximations, located suprema, binary maxima and limits of explicitly supplied rational intervals. Its exact constructive hypotheses are described below.

### Actual additive operations and rational compatibility

`RationalNegation` and `DedekindNegation` construct negation on the existing
carrier by reflecting and exchanging its two rational predicates. All six
cut laws are proved. Negation is involutive, preserves the designated
rational embedding and zero, reverses strict order, and preserves apartness.
Its equivalence uses these actual functions and their proved inverse laws.

`RationalArchimedean` constructs positive rational reciprocals and finite
natural-number bounds using the pinned rational quotient representation.
Quotient representatives are eliminated only into proposition-valued goals.
`DedekindApproximation` then proves that, for every cut x and positive rational
epsilon, there merely exist rational lower and upper members a and b with
b < a + epsilon. The proof is a finite overlapping rational-grid search whose
natural fuel decreases. It does not choose an approximation sequence for
every real or invoke countable choice.

`DedekindAddition` defines its lower and upper predicates by truncated
rational-sum witnesses. Locatedness uses the proved finite approximation of
one input and then locatedness of the other. Each of the other cut laws is
proved for these predicates. `RationalAdditionBounds`,
`RationalSumDecomposition` and `DedekindAdditiveLaws` prove the required
rational decompositions, addition associativity and commutativity, both zero
laws and both inverse laws for the actual constructed negation.

`DedekindAbGroup` packages exactly this carrier, addition, zero, negation and
their proofs into the pinned Cubical `AbGroup` interface. The rational
homomorphism's underlying function is definitionally `rationalCut`, and its
injectivity is proved. Filling this interface is the last packaging step
after constructing the operations and proving the laws; it introduces no
new algebraic assumptions.

### Order and actual translations

`DedekindOrder` defines non-strict order by lower-cut inclusion and proves its
partial-order laws. It is constructively equivalent to the absence of the
reverse positive strict inequality. Upper predicates are contravariant, and
the designated rational embedding preserves and reflects the rational order.
The mixed strict/non-strict transitivity laws are proved.

`DedekindAdditiveOrder` proves monotonicity of addition and constructs the
translation equivalence with forward function x mapped to x + z and inverse
x mapped to x + (-z). Strict and non-strict order are both preserved and
reflected by those actual maps. Negation reverses non-strict order as well.
This is an abelian group with these proved order laws; a total disjunction
deciding the non-strict order of two arbitrary reals is not asserted.

### Located suprema: exact hypotheses

`DedekindSupremum` treats a family f indexed by a type I in universe 0. It
requires mere inhabitation of I, a merely existing real upper bound, and the
following explicitly supplied whole-family locatedness condition:

```text
for every pair of rationals p < q,
  merely ((there exists i with p in the lower cut of f(i))
          or (for every i, q is in the upper cut of f(i))).
```

Individual locatedness of every f(i) does not replace this family condition.
The bound is truncated in its actual universe 1; there is no resizing. The
supremum's lower predicate is the truncated union of the lower predicates.
Its upper predicate is the strict interior of the uniform upper bounds.
All six cut laws, the upper-bound property, leastness and uniqueness are
proved for this constructed cut.

`DedekindMaximum` supplies all the needed family data for a two-element
family, so binary maximum is unconditional. Its upper-bound and leastness
laws, commutativity, idempotence and monotonicity do not decide which input
real is larger. Only rational comparisons are decided in the construction.

### Rational interval limits: exact supplied data

`RationalIntervalCompletion` takes actual sequences l,u from natural numbers
to the pinned rationals, with cross-compatibility

```text
for every m,n, l(m) <= u(n),
```

and an actual index selected at each positive rational precision epsilon
such that u(n) - l(n) < epsilon. This is a function returning an index and
its proof, not a merely existing sequence or an untruncated choice obtained
from the earlier approximation lemma.

The constructed `intervalLimit` lies above every rational lower endpoint
and below every rational upper endpoint. Any other real satisfying these
bounds equals it as an actual Dedekind cut. Constant rational intervals
normalize to the designated rational embedding. Endpoint monotonicity is
unnecessary for this theorem. Its supplied modulus does not assert that
every later interval is narrow.

These results therefore do not claim a supremum for every bounded subset,
or an automatically chosen interval presentation for every real, or arbitrary
Cauchy completeness. Those stronger statements have distinct constructive
input requirements.

### Place in the stronger programme

These are actual constructive operations on the external coefficient line.
The internal synthetic line on infinitesimal formal stages remains a
separate object to construct. Next are actual multiplication and its laws,
reciprocals on positive apartness, metric and appropriate convergence
constructions, then analysis and smooth geometry. The chosen cut universes
and truncation levels must be retained when connecting them to the existing
ordinary categorical and sheaf interfaces.

Actual smooth sites and covers, represented sheaves and gluing, finite-Weil
and formal-stage geometry, dependent and higher model operations and universe
classification, quotient/descent and properness comparisons, and exact
source interpretation/substitution remain open. Neither existence nor
nonexistence of a model of the entire original Myers foundation is settled.
The complete external theorem is not yet machine checked from these
foundations upward.

<a id="dedekind-product-metric"></a>

## Constructed real product and metric

The product/metric construction supplies actual multiplication with all six cut laws, commutativity, rational compatibility, zero/unit equations, and a distance with the metric laws. The ring, reciprocals and topology require the additional constructions below.

### Multiplication from enclosing rational rectangles

An Enclosure x consists of rational endpoints a,b with a in the lower cut
of x and b in its upper cut. Their mere existence follows from the cut laws.
Intersecting enclosures uses the maximum lower endpoint and minimum upper
endpoint, preserving both memberships and narrowing the interval. All these
operations use the already fixed ordered rational representation.

For a rectangle [a,b] times [c,d], the construction takes the minimum and
maximum of its four rational corner products. It proves actual corner
attainment and that every rational point product in the rectangle lies
between these extrema. Rational absolute-value and bilinear-error lemmas
prove the diameter estimate

```text
high - low <= M * ((b-a) + (d-c))
```

when both coordinate intervals lie inside [-M,M]. An explicit positive
rational bound M is constructed for any four supplied endpoints. A positive
reciprocal of M and the proved quarter-gap estimates give a positive input
tolerance whose resulting product width is smaller than the requested gap.

Using the actual 085 closeBounds, then intersecting with a coarse enclosure,
gives merely existing product boxes of arbitrarily small positive rational
width. Every elimination of an existence truncation targets a proposition.
No global sequence of approximations or sign decision for reals is extracted.

The product's lower cut at p is the mere existence of an enclosing rectangle
whose minimum exceeds p. Its upper cut at q is the mere existence of an
enclosing rectangle whose maximum is below q. The operation is therefore
defined before any real multiplication law is assumed.

All six cut laws are proved directly. For separation, two enclosures of one
input contain a common rational point: the maximum of their lower endpoints
lies below both upper endpoints. Rational products of common points in the
two coordinates lie above the first box's minimum and below the second
box's maximum. This compares arbitrary lower and upper witnesses without
presupposing a real product.

For locatedness at p<q, choose only under truncation a box with product width
less than q-p. The rational comparison of p with its minimum either supplies
lower membership or puts the maximum below q, supplying upper membership.
No witness is selected outside proposition-valued goals.

Rectangle symmetry proves commutativity of the actual product. Rational
compatibility, zero and unit equations use a proved cut equality principle:
if lower and upper membership of one cut both imply the corresponding
membership of another, neither strict inequality can hold; tight apartness
then gives actual cut equality. This does not infer positive apartness from
mere negated equality.

Five rational helper modules and three product-cut modules carry these
proofs. For fixed universe-1 cuts, enclosure data and product predicates
remain in universe 0. The real carrier is unchanged; no resizing is used.

### An actual real-valued distance

Three modules construct and prove laws for these exact functions:

```agda
subtractReal x y = addReal x (negateReal y)
absReal x       = maximum x (negateReal x)
distanceReal x y = absReal (subtractReal x y)
```

Subtraction has cancellation, zero reflection, reversal under negation and
the chained-difference identity. The negation-of-addition identity applies
pinned Cubical group theory to the actual constructed abelian group. It is
not supplied as an additional assumption.

Absolute value is nonnegative, bounds x and -x, is unchanged by negation,
vanishes exactly at zero and satisfies the additive triangle inequality.
That inequality follows from the binary maximum's universal property and
proved addition order laws. Nonnegativity does not decide a real's sign.

Distance is nonnegative, symmetric and zero on the diagonal. Zero distance
is equivalent to equality, and the triangle inequality holds for this actual
distance. Positive distance is equivalent to the earlier constructive
apartness relation. These are separate equivalences: negated equality is
not substituted for apartness. Positive-distance reflection uses the actual
maximum's truncated lower-cut witness, eliminating into the proved proposition
expressing apartness.

A distance and its metric laws alone are not a topology/completeness/field or manifold construction. The separate topology and completeness modules below supply their respective additional results.

### Continuing semantic obligations

Next prove associativity/distributivity for this exact product by realizing
operation enclosures at common rational points, then construct reciprocals
on the constructive apartness domain and the remaining order laws. Cauchy
convergence requires explicit constructive input data; the earlier truncated
approximation lemma does not select a countable approximation sequence.

This is the external coefficient line. The internal synthetic line on formal
stages, actual smooth sites and sheaves, dependent/higher semantics, universe
classification, quotient/descent and properness comparisons, and exact source
interpretation/substitution remain to be constructed. The full original
Myers model question and complete external theorem remain open. The conaled
assessment remains source inspection at c19a9ab, without a fresh Lean build
and with one bounded explicit principal-fiber gluing proposal. It introduces
no Lean component into the Agda proof chain.

<a id="dedekind-ring-completeness"></a>

## Actual constructive real ring and modulated Cauchy completeness

The ring/completeness construction supplies a nontrivial commutative ring on the actual Dedekind carrier, its injective rational ring homomorphism, and metric limits for real Cauchy sequences with explicit rational moduli.

### The concrete commutative ring

`DedekindEnclosureRefinement` constructs common rational points for two and
three actual cut enclosures, and proves equality when all pairs of output
enclosures merely overlap strictly. `DedekindOperationEnclosures` proves
actual sum and product realization: a specified output enclosure merely
admits input enclosures whose every closed rational point combination lands
strictly inside that output enclosure.

Associativity uses four such realization witnesses. Distributivity uses five;
the repeated variable has a common point in three enclosures. Exact rational
identities give a strict common output point. Apartness tightness then gives
equality of the real cuts. All finite witnesses stay under propositional
truncation. There is no selected infinite approximation sequence or assumed
continuity theorem.

The generic finite-polynomial helper takes operation functions and realization
certificates. `DedekindRingLaws` supplies the actual constructed operations and
proved certificates, so it adds no ring-law hypothesis. It proves the two
required identities; it is not a general polynomial-language interpretation.
`DedekindCommRing` fills the pinned commutative-ring structure, keeps the actual
carrier and operations by reflexivity, and constructs the injective rational
homomorphism whose function is definitionally `rationalCut`.

### Actual Cauchy limits and their precise hypotheses

Let u be a sequence of the constructed reals. `ModulatedCauchy u` supplies,
for every positive rational e, an actual index mu(e), and the proof that
m,n at least mu(e) imply d(u(m),u(n)) at most e. The index function need not
be monotone. This explicit input is retained throughout the existence theorem.

The limit's lower cut at q merely has a positive margin e with
q+e in the lower cut of u(mu(e)); its upper cut uses q-e in the upper cut.
Finite maxima of indices and the Cauchy bounds establish the six cut laws.
Metric/cut transfer lemmas then prove distance at most e on the tail starting
at mu(e), and strict distance below e on the tail starting at mu(e/2).

`Converges` retains merely eventual indices. Uniqueness eliminates only
finitely many such witnesses into propositions and uses the triangle
inequality and apartness tightness. This establishes independence from the
input modulus, contractibility of the type of limit points with merely
eventual convergence proofs, and the constant-sequence equation. It does not
establish uniqueness of numerical modulus data, choose indices from arbitrary
merely eventual Cauchy data, or prove unmodulated completeness.

### Exact native and constructive scope


The actual real carrier remains at Type1. These are external coefficient
reals; they are not a synthetic real-line object with infinitesimals. Existing
UnsupportedIndexedMatch warnings in three ordinary imports limit transport
computation claims, without being presented as new operational adequacy.

### Remaining obligations

Multiplicative order, reciprocals and the tight apartness-field package are
additional constructions below. Actual smooth/formal manifold instances,
semantic universes, higher operations, descent/properness transport and
source interpretation remain separate from this arithmetic. No joint model
of the entire original foundation or universal impossibility theorem is
claimed.
<a id="dedekind-inverses-weil"></a>

## Actual real inverses, order and concrete Weil algebras

The inverse/Weil construction supplies real reciprocals on the apart-from-zero domain, multiplication-order laws, ordinary algebra on the same carrier, and one- and two-direction square-zero algebras with an explicit pullback comparison.

### Actual reciprocal and multiplication order

The development constructs a reciprocal of the actual Dedekind real whenever the input is constructively apart from zero:

```text
inverseApartReal : (x : DedekindReal) → x #ℝ zeroReal → DedekindReal.
```

The domain is the existing alternative `(x <ℝ 0) ⊎ (0 <ℝ x)`. A positive input receives a newly constructed reciprocal cut; a negative input receives the negative of the positive reciprocal of its negation. Both multiplication inverse equations, uniqueness, involution, independence of the supplied certificate, preservation of apartness from zero, and cancellation by an apart-from-zero factor are proved for these actual operations. The positive real reciprocal agrees with the embedded positive rational reciprocal, and the inverse of one is one.

The positive reciprocal is built from small rational predicates. A rational `p` belongs to its lower cut when there merely exists a positive rational upper point `b` of the input with `p < inverseQ b`. Its upper cut is defined dually using a positive rational lower point `a` with `inverseQ a < q`. All six Dedekind cut laws are proved. Finite enclosure realization and the actual product construction establish the inverse equations; real reciprocal or reciprocal continuity is not an input. The rational inverse itself is obtained from a proved unique positive reciprocal witness, so eliminating its mere existence uses propositionhood rather than a choice axiom.

For the actual real multiplication, the development proves positivity and nonnegativity of products. Multiplication by a nonnegative factor preserves non-strict order. Multiplication by a strictly positive factor preserves and reflects both strict and non-strict order, yielding equivalences of the corresponding order propositions. Reflection uses the constructed positive reciprocal. No ordered-field record or missing order law is assumed.

This does not instantiate the pinned Cubical `Field` interface: that interface requests an inverse from `¬(x = 0)`, whereas the constructed inverse accepts `x #ℝ 0`. These domains have not been identified. In particular, tight apartness alone does not supply the positive/negative alternative from negated equality. This is an exact interface boundary, not an impossibility theorem about field structures or external classical interpretations. Additional apartness-field packaging and strong-extensionality results belong to later work.

### Ordinary coefficient algebra and finite square-zero extensions

The same Dedekind carrier and operations now fill the existing ordinary `AdditiveMonoid`, `CommutativeSemiring`, and `CommutativeRing` interfaces. Actual Cubical law proofs are converted through the constructed identity adapter, and carrier sethood is transferred through that adapter. Explicit computation equations identify the carrier, zero, one, addition, multiplication, and negation with the original operations and the Cubical ring package. No ring law, real field structure, or new extensionality parameter is supplied as an assumption.

Instantiating the existing finite Weil construction with this coefficient semiring gives concrete extension rings with coordinate equivalences

\[
D\simeq R\times R,\qquad D(2)\simeq R\times(R\times R).
\]

Their multiplication computes to

\[
(r,u)(s,v)=(rs,rv+su),
\qquad
(r,u,v)(s,u',v')=(rs,ru'+su,rv'+sv).
\]

Scalar inclusions, augmentations, and direction projections are actual maps with the relevant semiring preservation proofs. Coordinatewise negation supplies the additive inverses. The directions `(0,1)`, `(0,1,0)`, and `(0,0,1)` are proved nonzero and square-zero; both mixed products of the last two directions vanish, and those directions are distinct. These nilpotents are elements of the extension rings.

The actual comparison identifies `D(2)` with the pullback of two copies of `D` over their augmentation to `R`. It sends `(r,u,v)` to `((r,u),(r,v),refl)` and has an explicit inverse with both inverse laws. The ordinary pullback comparison and inverse preserve the exposed semiring and module structures. A second comparison converts its equality witness to a Cubical path and gives an equivalence with the literal Cubical-pair/path pullback, with the same forward coordinate map. A separate transported semiring package on that latter presentation is not claimed.

### Foundation and semantic boundary

The real, extension, and pullback carriers remain in universe 1; their algebra packages are in universe 2. Rational cut predicates and their cut laws remain small. The constructions introduce no resizing, classical-choice parameter, real sign decision, or assumed real inverse. Ordinary identity and Cubical paths are related by explicit maps with proved propositional round trips.

These results supply concrete constructive coefficient algebras, an actual apartness-domain reciprocal, multiplication-order laws, and a finite algebraic diagram suitable for subsequent semantic work. They do not identify the extension directions with infinitesimals in the Dedekind carrier or in the paper's internal language. A polynomial quotient presentation or spectrum interpretation, Kock–Lawvere instance, smooth site and sheaves, model universes and type operations, exact source-language interpretation and substitution theorem, descent/properness comparison, and the external orbifold theorem remain separate obligations. No complete model of the original foundation or universal obstruction to such a model is asserted.

<a id="dedekind-topology-completeness"></a>

## Topological apartness field and Cauchy completeness

The topology/completeness construction supplies the tight apartness-field package, real and product metric topology, continuous arithmetic including reciprocal on its actual domain, and Cauchy completeness from merely eventual tail data.

### Constructed topology interfaces

| Construction | Modules | Mathematical result |
| --- | ---: | --- |
| topology | 4 | Rational-ball and coordinate-ball open fragments; additive continuity |
| apartness | 7 | Actual nontrivial tight apartness field and strong extensionality |
| Continuity/completeness | 2 | Joint multiplication continuity and reusable enclosure-neighborhood lemmas |
| Continuity/completeness | 3 | Open apartness domain and actual reciprocal continuity |
| Continuity/completeness | 4 | Cauchy completeness from merely eventual estimates, without a selected modulus |


### A constructive field package on the existing carrier

The concrete package `dedekindApartnessField` uses the already constructed Dedekind cuts, commutative ring, cut apartness, and apartness-domain reciprocal. Its ring, carrier, relation, and reciprocal computation equations are reflexive. No alternative real operation or assumed field law is substituted into the package.

The new seven-module branch proves product-apartness reflection directly from the actual product cut: if `x*y` is apart from zero, both factors are apart from zero. A product membership witness supplies a rational enclosure rectangle whose entire range is strictly on one side of zero. If zero lay in either factor interval, the rectangle range bounds would include the product zero, contradicting that separation. Only rational endpoint comparisons are decided. All merely existing witnesses are eliminated into the already proved proposition of real apartness.

Using the already constructed factor inverses, associativity and unit laws prove `(x*y)*(inverse y*inverse x)=1`. This gives product-apartness preservation without first assuming that the product has an inverse. Combining preservation and reflection constructs the actual equivalence

\[
(xy\mathrel{\#}0)\simeq(x\mathrel{\#}0)\times(y\mathrel{\#}0).
\]

The branch also proves strong extensionality of addition and multiplication, with the resulting alternative kept propositionally truncated. Apart output products imply that at least one input pair is apart. Multiplication by an apart factor preserves and reflects arbitrary apartness. The actual reciprocal preserves and reflects apartness on its explicit domain, and the inverse-of-product equation follows from actual inverse uniqueness.

`TightApartnessFieldStructure` has nineteen fields, all filled in `DedekindApartnessField.agda`: proposition-valued tight apartness with truncated cotransitivity, nontriviality, arithmetic strong extensionality, product apartness, and the actual reciprocal with its left/right inverse equations, apartness, certificate independence, involution, and strong extensionality. The earlier multiplication-order theorems remain available; the generic new interface itself packages apartness laws rather than assuming an order.

The inverse domain is constructive `x # 0`. Tightness does not turn merely `¬(x = 0)` into that evidence. This package therefore does not claim to instantiate the pinned Cubical `Field` interface whose inverse input is negated equality. The carrier remains in universe 1 and apartness in universe 0, explicitly recorded by the interface.

### Constructed open fragments and additive continuity

The actual metric ball is

\[
B(x,r)=\{y\mid d(x,y)<\operatorname{rat}(r)\}.
\]

For a fixed ordinary subset, openness means that every member has a merely existing positive rational ball contained in that subset. A radius witness includes its positivity proof and the actual neighborhood-containment function. Its existence remains propositionally truncated. The implementation fills all five fields of the existing ordinary `OpenFragment`, including the locality proof; `IsOpen` is defined and its laws proved.

Actual rational balls are open. The proof uses an intermediate rational distance bound, the positive gap to the requested radius, and the existing metric triangle inequality. Ordinary subset membership explicitly lifts the small ball predicate into the universe required by the interface, with actual lower/lift inverse maps and proposition proofs.

Negation and translations are proved isometries for the existing distance, hence continuous. The product carrier is the ordinary pair of actual reals, with simultaneous coordinate balls defining its open fragment. Its projections are continuous, products of open subsets are open, and the actual addition map is jointly continuous using a half-radius estimate. Its computation on an ordinary pair is an ordinary reflexivity equation.

The code supplies a rectangle from explicit radius data and proves both directions of a truncated local-rectangle characterization. It does not extract selected radii or a selected `RectangleBasis` from mere openness.

### Actual multiplication and reciprocal continuity

Joint multiplication continuity is proved for the existing enclosing-box product and the constructed real/product open fragments. The proof needs neither an assumed norm inequality nor another multiplication-continuity field.

First, rounded cut membership yields truncated local radii preserving a specified rational lower or upper bound. Combining them preserves an entire specified enclosure with the same rational endpoints. The product cut's own rectangle estimates bound the products of any two points retaining those factor enclosures. Two reals in one closed rational interval have distance at most its rational width. A sufficiently narrow actual product box and stable input enclosures therefore give a truncated positive input radius for each positive requested output radius. Composing these neighborhood maps proves the existing ordinary `C.Continuous` signature for the actual pair-to-product map.

For reciprocals, `ApartReal` is the actual dependent pair of a real and a proof of apartness from zero. Its rational balls are the ambient balls pulled back along the first projection. The source constructs its open fragment, sethood, continuous injective inclusion into the reals, and openness of the ambient lifted apartness subset. A negative rational upper witness or positive rational lower witness persists in a sufficiently small ball, proving that openness without deciding arbitrary real signs.

The reciprocal-neighborhood theorem uses the actual reciprocal cut. An output enclosure of a positive reciprocal contains rational witnesses that directly determine an input enclosure preserving the output bounds. The negative branch follows by reflecting the actual cut enclosures through negation. Explicit certificate-independence transports ensure that the resulting neighborhood proof controls the same `inverseApartReal` map for arbitrary supplied apartness certificates.

Narrow output bounds and the stable-input-enclosure radius yield reciprocal continuity from `ApartReal` to the reals. The same map lands in `ApartReal`; the previous inverse-involution theorem and propositionhood of the certificate fiber prove its involution there. The code constructs an actual equivalence with that same map as both directions and proves it continuous as a self-map. This provides explicit self-inverse continuous-equivalence data. It does not additionally package a separate ordinary open-embedding/homeomorphism record or a comparison with a different subspace implementation.

All local radii remain truncated. The results do not select a global neighborhood-radius function or assert uniform reciprocal continuity near zero.

### Cauchy completeness without a supplied modulus

The new theorem strengthens the earlier modulated existence theorem while preserving its historical source and scope. Its input is an actual sequence `u : ℕ → DedekindReal` with

\[
\operatorname{Cauchy}(u)=
\prod_{e:\mathbb Q}\bigl(0<e\to
\bigl\|\sum_{N:\mathbb N}\prod_{m,n:\mathbb N}
(N\le m)\to(N\le n)\to
 d(u_m,u_n)\le\operatorname{rat}(e)\bigr\|\bigr).
\]

Each positive rational tolerance has a merely existing certified tail. The input does not contain a function selecting an index from each truncation.

The limit's lower predicate at `q` is the truncation of a positive rational margin `e`, an index `i`, a certified `e`-tail, and `Lower (u i) (q+e)`. Its upper predicate uses `Upper (u i) (q-e)`. These actual small predicates range over all certified tails; they do not select a center as a function of the tolerance.

All six cut laws are proved. Inhabitedness uses one merely existing tail at tolerance one. Roundedness retains the same certified data and rounds the center's rational membership. Separation takes the finite maximum of two supplied indices and transfers both witnesses to that single sequence term. Locatedness uses an explicit quarter-gap tolerance and the locatedness of one term supplied inside the relevant truncation. No countable sequence of choices is extracted.

An arbitrary certified tail bounds the distance between the constructed limit and its sufficiently late terms. Finite maxima again combine unrelated witness indices. Requesting a half-tolerance converts this non-strict error bound to the existing strict, merely eventual `Converges` predicate. Consequently the code constructs the actual function

```agda
completeCauchy : (u : ℕ → DedekindReal) → Cauchy u
  → Σ[ l ∈ DedekindReal ] Converges u l
```

The actual Sigma output is obtained by constructing the limit predicates and their cut laws. It is not obtained by eliminating a truncated choice of limit values into the real carrier.

The existing uniqueness theorem for merely eventual limits proves uniqueness, independence from the Cauchy proof, and contractibility of `Σ l, Converges u l`. The new limit agrees with the prior `cauchyLimit` when an explicit modulus is supplied, and constant sequences have their expected limit. Conversely, merely eventual convergence implies the new Cauchy predicate using one half-tolerance tail and the triangle inequality.

For a fixed sequence, certified tails, the Cauchy/convergence predicates, and the limit-membership witnesses remain in universe 0. The real carrier and the Sigma of a limit with convergence remain in universe 1. The construction supplies no numerical convergence modulus, no general choice principle, and no selected rational approximation sequence for every real. It does not establish completeness for arbitrary metric spaces or suprema without their required locatedness hypotheses.

### Remaining semantic boundary

These results give actual constructive algebra, metric neighborhoods, arithmetic continuity, and sequential completeness on the same external Dedekind carrier. They materially strengthen the real-analysis base needed for a later semantic construction. All operations and comparisons above reuse implemented data and laws.

The differentiability and calculus modules are further constructions;
finite-dimensional smooth manifolds and formal smooth semantics, semantic
universes, higher interpretations, and source substitution do not follow
from arithmetic continuity. In particular, the square-zero algebras are not
nonzero nilpotents inside the Dedekind real carrier, and no Kock–Lawvere
instance follows.

A model of the entire original Myers foundation remains unestablished. No universal impossibility theorem is claimed. General classical-orbifold applicability, including the appropriate external properness comparison, remains open work rather than a consequence of these analysis results.


