# Coherent diagrams

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="coherent-foundations"></a>

## Coherent diagram foundation — active construction

The enriched bar foundations are in `src/Orbifolds/Coherent`. They are part of the original cohesive branch, not an ordinary set-valued replacement.

### Chosen model

Use strict categories enriched in fibrant types and quasi-unital homotopy-coherent
type-valued diagrams. The diagram has an actual composition cube in every
finite degree, both full splitting/deletion face laws, and an actual identity
homotopy. Strict enriched diagrams embed by a checked construction. Bar cones
are indexed by all finite composable chains.
Finite combinatorics use Agda's outer (`SSet`) natural numbers and finite positions.
Each actual chain space, coefficient space, cube, shell and filler remains in the
inner fibrant universe. Infinite stages are exposed through the constructed inner coinductive
schedule and its ordinary-Nat inverse tower.
There is no global product over outer Nat and no assumption that outer Nat is
cofibrant.

The standard enriched/computadic model is an explicit model choice. The all-dimensional action interface is now constructed and instantiated by
native nullification of an arbitrary existing coherent diagram. The external
comparison with other infinity-category presentations remains model guidance,
not an additional unchecked Agda theorem. See coherent-diagrams.md#null-coherent-reflection.

### Modules

- `StrictEnriched`: strict category/diagram structure, strict equality primitives,
  actual category of types and identity diagram, powered diagrams. Composition
  preservation is equality of entire action functions so powers derive by strict
  congruence without strict function extensionality.
- `EnrichedBarChains`: ordinary-Nat finite chains, actual face maps, complete
  ordered face-face identity, coface maps and their three overlap identities.
  Recursive finite sums avoid unsupported indexed-pattern-match warnings.
- `OuterBarChains`: finite outer combinatorics with the same inner chain spaces.
  The face, coface and action overlap laws are strict equalities; all higher
  identifications of these strict proofs follow from proved strict UIP.
- `OuterCubicalFaces`: actual finite cube coordinates, evaluation/abstraction,
  coordinate insertion/restriction, cube face commutation, and cube map laws.
- `OuterBarCuts`: actual retained prefixes and composed suffix maps; literal
  one-face formula; zero/one cut overlap identities; recursive one-face formula
  proved equal to the composite-suffix formula.
- `EnrichedBarConeCompatibility`: all four low/high overlaps of the actual
  finite bar boundary, derived from preceding typed fillers and diagram laws.
- `EnrichedBarConeTransformations` and `EnrichedBarBoundaryNaturality`: strict
  enriched transformations act on actual finite bar families and preserve their
  coherence; assembled Step boundaries are natural for the actual direct shell map.
- `EnrichedUniverseLifting`: arbitrary object/hom/value universes lift literally
  into their maximum, with strict action/composition and actual equivalences.
- `StrictCubicalShellQuotation`: canonical recursive quotation of sphere maps,
  with strict constant and target-naturality laws. No equivalence is assumed.
- `CrispOuterBarProbe`: native crisp SSet Category/Diagram/Extensionality inputs
  successfully compute boxed actual inner bar limit types and schedules. A
  concrete cellular presentation over that actual limit also boxes; it is only
  a modality check, not the desired bar colimit presentation.
- `EnrichedBarDiscreteness` derives finite-chain
  discreteness and power comparisons from crisp discrete objects and hom spaces.

### Explicit new structural dependency

`OuterCubicalFaces.StrictCubicalExtensionality ℓ` has exactly two fields:

1. Strict extensionality of dependent interval functions `(i : I) → A i`.
2. Strict extensionality of endpoint-typed `PathP A a b`, again from pointwise
   strict equality.

Neither is postulated globally, inferred from ordinary Cubical funext, or supplied
as a preservation result. This is an explicit choice of two-level structural foundations for these
new theorems; earlier geometric results retain their original hypotheses. A direct attempt to derive the second field from the
first by `reflˢ` matching on forgotten paths failed with Agda's higher-order
unification; the second rule is therefore listed explicitly.

`StrictEnriched`, `EnrichedBarChains`, and `OuterBarChains` do not require this
extensionality interface. Their imports contain no postulates or unsafe options.
All modules use `--safe --cubical --cohesion --two-level` and the pinned compiler.

### Separate strict extensionality for inner functions

`StrictInnerFunctionExtensionality.StrictFunctionExtensionality ell` supplies
strict dependent function extensionality over `A : Type ell`, with families
`B : A -> Type ell`. It is a separate named parameter. Finite cocone stages
need it to derive equality of object-indexed vertex functions and
chain-indexed filler families. The actual stage action's identity and
composition laws follow from this rule and proved raw-cube computations.
The rule is not ordinary Cubical funext, a global postulate, or an assumed
presentation/preservation theorem. The nullification diagram construction
itself still needs only the earlier cubical extensionality interface.

### Scope requirements for colimits

The paper uses the external infinity-category with crisp mapping types. Its bar
indices must therefore be externally discrete. Merely having a crisp type of
objects or homs is insufficient. Colimit wrappers require the derived discreteness
of the actual finite-chain indices; limits may allow arbitrary internal index and
hom types.

### Bar-stage assembly

`EnrichedBarConeStages` now checks: actual finite
bar boundary data is assembled from `bar-compatible`; each next stage is the
literal inner type of specified fillers; its coherence laws are extracted from
those fillers. The corecursive schedule and ordinary-Nat inverse tower are
constructed. Their mapping universal property and microlinearity from all vertex
values are proved. No presentation or desired-limit-preservation premise is used.

The arbitrary coherent functor interface, actual all-dimensional nullification
and its exact unit transformation are now checked. Generic coherent cone
boundaries also have all overlap laws. Their full inner cone stages, mapping universal property and microlinearity
are now checked in a common universe. Remaining work is the universe
wrapper, the actual bar colimit presentation with canonical restriction,
and the powered/nullified comparisons.
NaturalCubicalShellRepresentation now proves the canonical quotation
equivalence by finite induction and derives natural inverse sphere evaluation.
It connects direct strict shell maps to actual sphere attachment maps without
assuming the desired equivalence.
The model-scope obligation concerning resolution/computadic sources for arbitrary
coherent functors must also remain explicit in the final theorem interpretation.

The exact natural filler comparisons and their useful quote-fiber interface
are described in coherent-diagrams.md#natural-cubical-fillers.

<a id="coherent-diagram-infrastructure"></a>

## Current coherent-diagram infrastructure

This records the checked components used by the explicit coherent-diagram
model. The complete constructions close 5.0.1, A.0.9 and A.0.5 relative to
their stated model and foundation hypotheses. The final A.0.5 entrypoint is
Orbifolds.Coherent.TinyHomotopyCoherentCanonicalColimits.Context.colimit-equivalence.
The component lemmas described here are distinct from those final theorem
statements and retain their own displayed signatures.

### Actual cellular comparisons and adjunction mates

`CellularPresentationComparisons` defines a relative map between two
coinductive cellular presentations under a type operation. Its data consist
of actual maps on the initial objects, boundaries and cells, together with
both attachment squares. Every successor comparison is constructed by the
pushout recursor; the final comparison is the actual induced sequence map
followed by the operation's sequence comparison. The proof of equivalence
uses local equivalences and primitive pushout/sequence preservation. Neither
a desired realization equivalence nor a coherent-cocone equivalence is a
field of the data.

`TinyCellularComparisons` and `TinyNullificationCellularComparisons` supply
the primitive preservation proofs from the previously checked tiny and
nullification results. Their crisp and universe hypotheses remain explicit.

`TinyCellularCocones` defines the full recursive cocone mate by assembling
the source cocone, applying tiny evaluation, precomposing with the actual
realization comparison, and decoding the target cocone. Its assembly square
is an equality of complete functions, preserving every higher cell. The
external equivalence is proved after Flat from the chosen tiny adjunction,
the derived realization comparison, and the existing R-flat proposition
promotion rule. No Flat/infinite-product distribution rule is added.

### Cubical boundaries in every dimension

`CubicalShells` defines free n-cubes and complete shells recursively over
ordinary natural numbers. A successor shell is two opposite n-cubes and a
path between their complete lower-dimensional boundaries. This retains all
overlap data. Free cubes are proved equivalent to their value at the origin;
microlinearity of both cubes and shells follows from microlinearity of the
coefficient type.

`CubicalShellSpheres` constructs actual representing boundary spaces:
the zero-dimensional boundary is Empty and each successor is its suspension.
It proves an equivalence between the full shell type and maps from that
boundary space. The actual restriction of a cube is compared with the
constant boundary at its origin by an explicit homotopy. No truncation or
unproved sphere identification is used.

`CubicalShellFillers` defines endpoint-typed fillers by dependent cubical
paths. The total canonical map from free cubes to a shell with a filler is
proved an equivalence in every dimension. Consequently a filler over a
specified shell is equivalent to the actual homotopy fiber of restriction.
The strictification operation, its transport formula, and both inverse
laws are proved. Direct recursive coordinate forgetting is also provided.

`CubicalConeAttachments` adds these endpoint-typed fillers to a previous
partial cone. It proves equivalence with a literal pullback, the mapping
universal property, and microlinearity using only the preceding cone and
coefficient types. The index types, dimensions and complete boundary maps
are supplied at this generic interface; the accepted coherent-diagram
construction separately derives them from its actual chains and actions.

The eight constructions above add no new ambient axiom or compiler option.

### Accepted finite indexing and complete coherent diagrams

The accepted modules under src/Orbifolds/Coherent construct strict
Type-enriched indexing categories, finite chains and all deletion/split
identities, complete finite shell assembly and its coordinate computations.
The quasi-unital HCD interface records actual action cubes in every degree;
all cone boundary overlaps are derived from those data. Inner cone/cocone
towers and literal sphere-cell bar realizations have their full mapping
universal properties. Canonical bar maps retain their complete cocone
triangles, target naturality, identity/composition and pointwise-equivalence
behavior.

Outer finite dimensions are used for strict combinatorics. Infinite stages
are exposed through coinductive inner presentations and ordinary-natural
towers. Ordinary Nat is not identified with outer Nat, and no outer-Nat
cofibrancy or outer infinite product is assumed. StrictCubicalExtensionality
for interval functions and endpoint-typed paths, and the separate
StrictFunctionExtensionality for ordinary inner functions, are explicit
two-level structural parameters. They are separate from the eight ordinary
Cubical modules above and are not inferred from Cubical funext.

Nullification of any existing HCD is constructed by actual dependent
extensions, with all higher action cubes and the complete native unit
transformation. This avoids assuming strict modality laws. The final A.0.9
bar comparison is now proved from full unit restriction and actual
tiny-generated null-vertex colimit closure. Its common-universe, small
generator-index and crisp/discrete hypotheses remain explicit; see
tiny-colimits.md#tiny-null-coherent-colimits.

The complete A.0.5 assembly constructs the literal powered bar comparison
and proves its full canonical identification with the actual evaluation map.
Finite successor triangles and transition squares assemble into a complete
inner tower witness. The independent tiny branch proves the cellular map
an equivalence; the final wrapper transports that proof along the whole-function
canonical identification, retaining full cocone compatibility and inverse laws.
The common universe, RealFlat, native-crisp context, working/zero-level crisp
identity/Flat rules and separate E/F inputs remain explicit. Native crispness
does not imply external index discreteness; the Flat-discrete Obj/Hom
conditions are retained and are not sethood assumptions. See
tiny-colimits.md#tiny-power-coherent-colimits.

<a id="coherent-diagram-boundary"></a>

## Coherent diagrams: checked model and exact scope

The development has actual all-dimensional limit and colimit constructions
for quasi-unital homotopy-coherent diagrams, and actual nullification of every
diagram in that interface. The complete colimit presentation, its canonical
maps and full target naturality are included in the accepted aggregate.
The final tiny-family nullification comparison A.0.9 and canonical tiny-power
comparison A.0.5 are also included.

These constructions derive all finite boundary compatibility and higher
action cubes. They do not assume a diagram presentation or a desired
preservation theorem.

### Exact source scope

The source is [Myers, arXiv:2205.15887v1](https://arxiv.org/html/2205.15887v1).
The theorem ledger records the completed limit, nullification and tiny-power
theorems in this chosen model. Their exact hypotheses remain part of each
correspondence; no external model equivalence is inferred.

| Source statement | Checked construction | Exact scope |
| --- | --- | --- |
| 5.0.1: limits and arbitrary powers preserve microlinearity | Fully coherent bar limits with independent object, hom and value universes; actual mapping universal property, any-limit transport, and microlinearity from vertices; arbitrary powers | Checked relative to the stated two-level foundation and chosen HCD model |
| A.0.5: tiny exponentiation preserves crisp colimits | Actual evaluation-induced equivalence Bar(Power T D) ≃ (T → Bar D), complete coherent cocone triangle, vertex computation and both inverse laws | Checked relative to one common universe, native-crisp context, RealFlat, external tinyness, Flat-discrete Obj/Hom and the working/zero-level crisp identity/Flat and named E/F structural inputs in tiny-colimits.md#tiny-power-coherent-colimits |
| A.0.9: tiny-generator nullification preserves crisp colimits | Actual equivalence Bar(reflected D) ≃ Null S(Bar D), constructed native reflection and unit, exact canonical unit triangle, both inverse laws, inverse-unit formula and computation on every nullified vertex element | Checked relative to the displayed common-universe, tiny/discrete/crisp and two-level hypotheses in tiny-colimits.md#tiny-null-coherent-colimits |

### Foundation and chosen model

The source is a category enriched in fibrant types with strict outer
composition and unit laws. A homotopy-coherent diagram assigns a genuine
n-cube to each chain of n+1 arrows. Zero faces compose adjacent arrows;
one faces compose the full prefix and suffix cubes on disjoint coordinate
blocks. Unit preservation is an actual inner homotopy. The strict diagram
embedding and the quasi-unit's mapping-space identity laws are proved.

The all-dimensional cone construction uses the entire suffix action cube
in every cut face. All four pairs of boundary faces commute by checked
finite combinatorics. Each next stage is the inner type of actual typed
fillers. The full limit is an inner inverse tower constructed from a
coinductive schedule. No outer infinite product or outer-Nat cofibrancy is
assumed. The arbitrary-universe limit interface separates object, hom and
value universes. Actual lifting of chains, actions, faces and cuts reduces
to their maximum without resizing. The working-level strict cubical
extensionality rule also derives its smaller-level instance.

StrictCubicalExtensionality explicitly supplies strict extensionality for
interval functions and endpoint-typed paths. The separate
StrictFunctionExtensionality supplies strict dependent extensionality for
ordinary inner types where whole vertex/filler functions must be compared.
Neither is derived from ordinary Cubical funext or postulated globally.
Neither assumes a colimit presentation or preservation result. Earlier
geometric theorems keep their original hypotheses.

[Riehl, Homotopy coherent structures](https://math.jhu.edu/~eriehl/coherent-structures.pdf),
[Harpaz, Quasi-unital infinity-categories](https://arxiv.org/abs/1210.0212), and
[Tanaka, Functors that aren't strictly unital](https://arxiv.org/abs/1606.05669)
provide external guidance for the presentation model. Their rectification
or unitalization theorems have not been imported as unchecked Agda terms.
The code does not replace arbitrary inner associativity paths by strict
equality proofs or prove equivalence with every other infinity-category
implementation.

### Actual colimits and canonical maps

The canonical finite represented-stage record fixes restriction to the
actual action on its universal cocone. Its identity and composition laws
are derived. A successor is represented by a literal sphere-cell pushout,
with exact original-space and filler computations. The complete HCD
successor and its unbounded iteration are in the accepted aggregate. The
constructed sequential colimit has the full mapping equivalence to coherent
cocones, including every transition path.

An exact HCD transformation induces an actual map of these bar colimits.
Its full canonical cocone triangle, all-stage and vertex computations,
target naturality, identity/composition laws and componentwise-equivalence
theorem are proved. The proof of target naturality retains the sequential
compatibility paths; a family of unrelated finite equalities is not used
as a substitute for a full tower equality.

The natural sphere/filler equivalence is fully proved, including naturality
for the actual coordinate action. The literal quoted-cell map carries the
specific quote fiber of the universal boundary by postcomposition. Its
ordinary shell path retains both the attaching homotopy and the dependent
filler comparison; no ordinary equality is strengthened to strict equality.
HomotopyCoherentFiniteCellMaps proves the resulting full typed-cocone square.
See coherent-diagrams.md#natural-cubical-fillers.

### Nullification and canonical power comparisons

Native nullification of an arbitrary existing HCD is constructed in every
degree. Its vertices are the actual HIT nullifications, and its unit is an
exact all-degree transformation. The reflected bar is null because its
actual discrete-chain sphere-cell presentation preserves nullity under the
stated tiny-generator assumptions. Full unit-cocone restriction is an
equivalence into every null target; canonical map naturality transfers this
to precomposition by the actual induced bar map. The native reflection
universal property then constructs the final comparison and both inverse
laws. No strict functor laws for nullification or preservation premise are
assumed. See tiny-colimits.md#tiny-null-coherent-colimits for the complete signature.

The tiny adjunction is external, with mapping types Flat(X -> Y).
Accordingly external index discreteness remains a genuine hypothesis;
crispness alone does not imply it. Finite-chain discreteness is derived
from the actual object/hom hypotheses. The final A.0.9 theorem retains
these conditions, the native crisp structural rules and Ix:Type0. No
universe resizing is proved.

For A.0.5, the literal cellular powered comparison is constructed through all
stages. Its transition squares form a full inner tower witness; canonical
identification retains both stage values and path-valued compatibility.
The final production entrypoint is
Orbifolds.Coherent.TinyHomotopyCoherentCanonicalColimits.Context.colimit-equivalence.
Its comparison is literally the evaluation-induced map. The final wrapper
transports isEquiv from the independent tiny branch along a whole-function
path, retaining the full cocone triangle, vertex formula and inverse laws.
See tiny-colimits.md#tiny-power-coherent-colimits for its exact common-universe signature.
The bounded research notes are recovery/construction references, not an
alternative acceptance certificate.

<a id="coherent-triangles"></a>

### Exact input and retained coherence

Both modules take arbitrary higher types `X`, `Y`, and `Z`, in independent
universes, maps `f : X -> Y`, `g : Y -> Z`, `h : X -> Z`, and a specified
composition homotopy

composition : (x : X) -> g (f x) = h x.

There is no sethood assumption. Paths and paths between paths are not
truncated. The composition homotopy is part of the actual diagram, not an
unnamed proof that some equivalence or comparison exists.

This develops one finite coherent shape relevant to the implementation
boundary in [Myers, Proposition 5.0.1 and Appendix A](https://arxiv.org/html/2205.15887v1).
It does not supply a uniform model of infinity-category diagrams, all
finite inverse categories, or a skeletal presentation theorem for such
diagrams. See `coherent-diagrams.md#coherent-diagram-boundary` for that distinct task.

### Actual coherent limit

A point of the constructed limit is data

x : X, y : Y, z : Z,
    p : f x = y, q : g y = z, r : h x = z,
    Square (cong g p) r (composition x) q.

The square relates the two routes through the triangle. Its full identity
type is retained. `Cone A` has the same vertex, edge, and square data
varying over an arbitrary apex `A`. The module proves the actual mapping
equivalence

(A -> Limit) ≃ Cone A,

with both inverse laws and naturality under precomposition. These proofs
compute on the square field as well as the vertex and edge fields.

The literal first-vertex projection gives `limit≃initial : Limit ≃ X`.
Its inverse has the exact legs `x`, `f x`, and `g (f x)`, identity paths
for `f` and `g`, and the reversed supplied composition path for `h`. The
remaining square is explicitly filled. For a fixed `x`, the full
completion is contractible: the first two stages are ordinary based path
spaces, and the final edge together with its square is a dependent based
path space. Thus the proof does not assume a cone comparison law.

The initial cone itself is proved universal, with its actual computation
under precomposition. For every ordinary family of infinitesimal test
squares, microlinearity of `X` implies microlinearity of this limit by the
checked equivalence-invariance theorem. This includes the full
pointed-infinitesimal-variety formulation and requires no extra geometric
assumption.

### Literal graph and attached 2-cell

`CoherentTriangleColimits` first gives a higher inductive type with the
three vertex injections, paths for `f`, `g`, and `h`, and an actual square
constructor `cell`. Its four faces are the three edge paths and the image
of the supplied composition homotopy. There is no truncation constructor.

The underlying graph is separately constructed as the actual homotopy
coequalizer of its two incidence maps, with vertices `X + (Y + Z)` and
edges `X + (Y + X)`. A literal `graph-inclusion` sends its point and edge
constructors to the corresponding constructors of `Colimit`.

The checked `attachment-universal` theorem proves that maps from `Colimit`
to any higher type `A` are equivalent to a map from that bare graph to `A`
together with actual fillers of the specified squares. Its forward map
agrees with precomposition by `graph-inclusion`, including on graph edge
constructors. This is a derived cell-attachment universal property.

The equivalent coherent-cocone presentation has three legs, three path
families, and the square family. Its mapping universal property and
naturality under postcomposition are also checked.

### Canonical terminal equivalence and computations

The actual collapse map gives

colimit≃terminal : Colimit ≃ Z.

On the vertex injections it is `h`, `g`, and the identity of `Z`.
It sends the `f` edge to the reversed composition homotopy and the `g`
and `h` edges to constant paths. Its computation on the square is stated
explicitly in `collapse-cell`.

The inverse is the literal injection `in-Z`. The homotopy from
`in-Z (collapse u)` to `u` is defined on every constructor. On the square
it is the explicit cube

include-collapse (cell x j k) i = cell x (j ∨ ~ i) k.

Its four faces restrict to the prescribed edge homotopies. This is the
coherence that would be unavailable after retaining only the bare graph.

### Assumptions and boundary

The construction adds no postulates, choice, resizing, set truncation,
termination overrides, or semantic compiler flags. No tiny adjunction,
R-flatness, order, or Kock--Lawvere principle is needed. Microlinearity is
the only premise of the corresponding limit-closure corollary.

These modules construct the requested finite triangle and its universal
properties. They do not assert that graph and sequential preservation
alone establishes the unrestricted claims of A.0.5 or A.0.9. No general
coherent-diagram comparison has been inserted as a hypothesis.

<a id="graph-limits"></a>

## Arbitrary graph limits and categorical limits of sets

Source: Proposition 5.0.1 of
[arXiv:2205.15887v1](https://arxiv.org/html/2205.15887v1#S5.SS0.Thmthm1).

### Checked statements

`GraphLimits.Diagram` takes the library's actual `Graph` and `Diag`
structures. Vertices, edges and their values may be higher types in
different universes. Its limit is the dependent family of vertex values
together with an identity for every edge. The identities are not
truncated. The module proves the actual equivalence between maps into
this limit and cones, including both inverses and naturality under
precomposition. A second cone with a genuine universal property is
proved equivalent to this construction.

For any ordinary family of infinitesimal test squares, pointwise
microlinearity of the diagram implies microlinearity of the constructed
limit and of any such universal cone. The proof derives the statement
from dependent products and homotopy equalizers. It adds no geometric
assumptions.

`CategorySetLimits.Diagram` takes an actual small library `Category` and
an actual functor into `SET`. It constructs a literal `LimCone`, proves
its categorical universal property, and proves that its carrier agrees
with the graph construction. Uniqueness of categorical limits gives an
equivalence with any other `LimCone`, including the library's
`completeSET`. Every such limit of microlinear sets is microlinear.
The object and hom universes of the indexing category can differ; the
set-valued diagram lives in their maximum, as in `completeSET`.

### Exact boundary

This supplements the previously checked dependent products, arbitrary
powers, finite homotopy limits, paths and inertia. It does not identify
a graph diagram with a general infinity-category diagram. Higher-valued
category diagrams need coherent composition data beyond the edges of
their underlying graph. The `CategorySetLimits` result avoids this gap
because its naturality identities are propositions in sets.

The complete general infinity-category reading of Proposition 5.0.1 is
still recorded as open in the theorem ledger. The graph theorem is
fully higher-homotopical within its stated graph shape; the category
theorem is fully general within its stated set-valued scope.

<a id="enriched-bar-limits"></a>

## Coherent enriched bar limits: checked construction

This note describes the actual limit construction in the current proof tree. It is a current-state scope note, not an incremental history.

### Model and explicit structural input

`StrictEnriched.Category` is a category enriched in arbitrary fibrant types.
Its object and hom types may have higher identities. Composition and units
have explicit strict outer equality laws. `StrictEnriched.Diagram` assigns
actual types and functions and preserves composition and identities strictly.
The action is defined on the entire hom type, so every higher identity in a
hom space acts as its corresponding higher identity of functions.

The limit is the coherent bar limit of such a diagram: it contains a cube for
every finite composable chain, with all deletion and suffix-action faces.
It does not replace a category by its bare underlying graph. In particular,
the two-arrow layer includes the actual comparison between the composite
arrow cone and the two individual arrow cones, and all further coherence
layers are included uniformly.

This is an explicit enriched presentation model. A general claim about another
infinity-category model requires its standard enriched/cofibrant presentation
interpretation. No converter from an ordinary Cubical `Category` whose laws
are inner paths to outer strict category laws has been asserted or provided.
The foundational reference for enriched coherent presentations and their
resolutions is Emily Riehl's
[Homotopy coherent structures](https://math.jhu.edu/~eriehl/coherent-structures.pdf).
The present code constructs the bar cones; it does not formalize a theorem
equating every other infinity-category formalization to this model.

The construction takes the explicitly named
`OuterCubicalFaces.StrictCubicalExtensionality` at its working universe. Its
two fields are strict extensionality for dependent interval functions and
strict extensionality for endpoint-typed `PathP`. These are structural
two-level rules. They are not native Cubical path extensionality, a global
postulate, an assumed cone presentation, or a preservation assertion.

Finite combinatorics use outer natural numbers `Dim` and finite positions.
Every chain type, cube, shell, filler, stage, and final limit is an **inner
fibrant type**. The infinite construction is produced by a coinductive inner
schedule and an ordinary-natural inverse tower. It assumes neither a product
over outer naturals nor cofibrancy of outer naturals.

### Actual cell data

For a chain

```
x₀ → x₁ → ... → xₙ
```

an `n`-cone cell is an `n`-cube in `D(xₙ)`. Coordinates are ordered from the
penultimate vertex backwards. A zero face deletes its indexed vertex, using
composition for an internal vertex and deletion for the initial vertex.
A one face applies the composite remaining suffix to the already specified
prefix cone and ignores coordinates after the cut.

For two arrows `f : x → y` and `g : y → z`, the four one-dimensional faces
are the cone on `g ∘ f`, the image under `D(g)` of the cone on `f`, the cone
on `g`, and the constant cube at `D(g ∘ f)(vₓ)`. Their corner compatibility
is proved from the actual earlier cone laws and the strict action law.

`EnrichedBarConeCompatibility` proves all four zero/one overlap cases at
every dimension. It does not take the compatibility of the new layer as an
input. Its recursive proofs use the actual source-category face identities,
the actual action on composite suffixes, and the earlier cone layers.

`StrictCubicalShellAssembly` constructs the complete inner cubical shell from
these faces and overlap laws. It proves both reconstruction from the faces
of a given cube and preservation of every individual face. `StrictCubicalFillers`
then proves that the raw coordinates of an actual inner endpoint-typed filler
have exactly the prescribed faces. Thus the next cone layer satisfies its
coherence laws by construction.

### Finite and infinite cones

For an actual previous stage `P`, the next stage is literally

```
Σ (s : P), Π (chain : Chains(n + 1)), Filler(assembledBoundary(s, chain)).
```

The coefficient of each filler is precisely the diagram value at the
chain's final vertex. The previous stage projection is the first Sigma
projection. The new cube family is obtained by reading the filler's literal
`PathP` coordinates. The new strict layer laws are proved by
`assembled-filler-face`, together with the checked parameter-reindexing laws.

`EnrichedBarConeStages.Construction.bar-schedule` corecursively performs these
actual attachments at every finite outer dimension. Its ordinary-natural
stages are `PartialCone`. The complete limit is the actual compatible tower

```
Σ (s : Π n, PartialCone(n)), Π n, drop(n)(s(n + 1)) = s(n).
```

All compatibility paths are retained. They are not truncated to propositions
or sets. The full mapping-space universal property is proved by the actual
inverse-tower construction. Its source type may be in an independent
universe, and its component projections, compatibility squares, and
precomposition naturality have their literal computations.

The `Cone T` interface exposes compatible maps `T → PartialCone(n)`. Each
such map unpacks into the actual finite chain cubes and all their typed
coherences. A separate identification with the bar construction of the
powered diagram can use the checked shell/filler currying comparisons; it
is not being assumed by the limit closure proof.

`Candidate` proves equivalence with any other type carrying a universal
cone for this same cone interface. Its two equivalence hypotheses are the
ordinary universal property at the candidate and at the constructed limit,
not additional geometric assumptions or a presumed preservation theorem.

### Microlinearity

`EnrichedBarConeStages.Construction.Microlinear` assumes only microlinearity
of the diagram's vertex values, for an arbitrary independent-universe family
of infinitesimal test squares.

The proof uses the checked facts that a free cube is equivalent to its
coefficient type, a complete shell is built by homotopy pullbacks, and the
endpoint-typed filler is equivalent to the actual fiber of restriction.
Consequently each new stage is equivalent to a literal homotopy pullback of
the previous stage and products of cubes/shells. It is therefore microlinear.
The complete inverse tower is microlinear by the actual graph-limit theorem.
The universal-cone comparison transports this result to every other limit
of the same coherent cone data.

No microlinearity of chain indices, finite shells' underlying indexing
spaces, intermediate stages, or the final limit is supplied as a premise.
No choice, crispness, set truncation, or universe resizing is used.

`EnrichedUniverseLifting` embeds arbitrary object, hom, and coefficient
universes into their maximum using literal `Lift`, with actual object, hom,
and value equivalences and strict action/composition computations.
`EnrichedBarMicrolinearity` uses that construction to state the limit theorem
without a common-universe restriction on the input diagram. Arbitrary power
closure is also exposed at independent source and coefficient universes.

### Checked modules

The substantive limit construction consists of:

- `StrictEnriched`, `EnrichedBarChains`, `OuterBarChains`, `OuterBarCuts`, and
  `OuterCubicalFaces`: actual enriched and finite combinatorial foundations.
- `StrictCubicalShellAssembly` and `StrictCubicalFillers`: derived finite
  boundary assembly and exact filler-face computations.
- `EnrichedBarConeData` and `EnrichedBarConeCompatibility`: actual finite
  chain cubes, deletion/cut faces, and all new-layer overlap laws.
- `EnrichedBarConeStages`: actual finite attachments, the infinite schedule,
  inverse tower, mapping universal property, and vertex-only microlinearity.
- `EnrichedUniverseLifting` and `EnrichedBarMicrolinearity`: arbitrary input
  universe wrapper and transfer to every universal cone in this model.

All checks use the pinned unchanged native Agda compiler through the kit,
with `--safe`, no unresolved metas, no incomplete matches, and the shared
compiler lock. The explicit two-level structural input remains visible in
the final theorem's module parameters.

<a id="discrete-graph-colimits"></a>

## Appendix colimits: discrete indices and actual graph diagrams

`NullificationGraphColimits.agda` and `TinyNullificationGraphColimits.agda` construct the actual comparison and both inverse laws, including the dependent edge square. See [graph colimits](coherent-diagrams.md#nullification-graph-colimits) for the precise scope.

This extends the concrete cases of [Appendix A.0.5 and A.0.9 of Myers](https://arxiv.org/abs/2205.15887).
The source explicitly places the tiny adjunction in the external
category whose mapping types are `Flat (X -> Y)`. Its colimit claims
concern crisp colimits in that sense. An arbitrary internally varying
index type is not an external discrete indexing collection.

### Arbitrary crisply discrete indices

`CrispIndexedProducts.agda` extends the previously checked countable
Flat-product argument to arbitrary index types in the working
universe. For crisp I and A : I -> Type, its actual comparison is

Flat ((i : I) -> A i)
      -> ((u : Flat I) -> FlatFamily A u),

where `FlatFamily A (box i) = Flat (A i)`. Under crisply discrete I,
this map is an equivalence. The proof derives the restricted product
comparison from the existing explicit identity and Flat
induction/computation rules and R-flatness. It does not add product
preservation or a choice principle.

The proof that I is crisply discrete may itself be ordinary. A fixed
crisp point of R makes the relevant equivalence proposition
R-null; derived proposition promotion then supplies the Flat
certificate needed for the fixed crisp restriction map. This is
promotion of a proposition, not promotion of an arbitrary type or
context. All these constructions stay in the working universe.

`TinyDiscreteIndices.agda` uses the actual external tiny adjunction
to prove that every crisp, crisply discrete I is T-null:

const : I -> (T -> I)

is an equivalence. Its proof generalizes the former Nat argument.
The adjunction at the unit type shows that the evaluation map from
the tiny right adjoint is an external equivalence. The derived
Flat-product comparison lifts that equivalence through I-indexed
functions. Naturality then identifies precomposition by the actual
constant map as an external equivalence, and the checked external
Yoneda argument proves that constant map equivalent.

Tinyness remains a mere proposition. Its chosen-adjoint witness is
eliminated only to prove the equivalence proposition. There is no
choice of right adjoints indexed by ordinary variables.

As a consequence, for any family A : I -> Type, the literal map

(i, v) |-> (t |-> (i, v t))

from `Σ i, (T -> A i)` to `(T -> Σ i, A i)` is an equivalence.
Here the family A may be ordinary and internally varying. The
condition is on the index I. It is not silently dropped. In
particular, this does not assert preservation of the coproduct
indexed internally by the synthetic real line.

“Crisply discrete” means equivalence of the actual Flat counit. It
is not a claim of decidable equality or set truncation. The index
spaces can have higher identity structure.

### Graph colimits with their actual comparisons

`GraphColimits.agda` defines a small graph diagram by vertex and
edge types V and E, source and target maps E -> V, a family of
objects, and a map on each edge. It introduces no category
composition law or additional higher coherences.

Its colimit is the genuine homotopy coequalizer of the two incidence
maps

Σ e : E, Object(source e)  -->  Σ v : V, Object(v).

The two maps send `(e,x)` to `(source e,x)` and
`(target e, arrow e x)`. The module proves the complete mapping
universal property for graph cocones, including the edge paths;
there is no set-truncation constructor.

The library's `Cubical.HITs.Colimit.Base.colim` is also a graph
colimit. The new module gives an explicit equivalence with its
small presentation. The inverse maps are defined on both
`colim-leg` and `colim-com`; both inverse laws compute on those
constructors. The library places this HIT two universes higher
than necessary. The small equivalence avoids requiring tiny
adjunctions or R-flatness at those larger universes.

`CoequalizerEquivalences.agda` supplies the general equivalence of
coequalizers induced by equivalences of their domain and codomain
objects and the two specified commuting homotopies. Its actual
forward map retains those homotopies on the edge constructor.
Equivalence induction proves this map equivalent.

`TinyGraphColimits.agda` now proves A.0.5 for every crisp graph
diagram whose V and total E are crisply discrete. It distributes
exponentiation through both incidence sums by the preceding
index theorem, transports the diagram to the powered coequalizer,
and applies the previously proved tiny coequalizer preservation.
A constructor-by-constructor equality identifies the resulting
map with the literal comparison

point(v,f) |-> (t |-> point(v,f t))
    edge(e,f,i) |-> (t |-> edge(e,f t,i)).

A separate wrapper proves equivalence of the library's literal
`colim-leg`/`colim-com` comparison as well. For a library graph with
an edge family `Edge v w`, the explicit edge-index hypothesis is
crisply discrete `Σ v, Σ w, Edge v w`, together with crisply
discrete vertices. No unnoticed sethood or truncation premise is
introduced.

### Nullification by a crisp family of tiny types

`NullificationCoproducts.agda` proves a general theorem first:
nullification commutes with dependent sums over a null base.
Its actual comparison is

(j, u : L(A j)) |-> L(inclusion j)(u).

The sum of reflected fibers is null by the existing null-dependent-
sum theorem. The actual nullification eliminator supplies an
inverse, and its two inverse laws follow by nullification
induction. For a crisp, crisply discrete base J and a crisp family
of tiny generators, `TinyDiscreteIndices` proves that J is null.
Thus this coproduct theorem also allows an ordinary family A.

The accepted `NullificationGraphColimits.agda`, together with
`TinyNullificationGraphColimits.agda`, proves A.0.9 for the same
crisp graph diagrams. The reflected diagram has literal objects
`Null S (Object v)` and literal nullification maps on its arrows.
Its canonical colimit comparison is defined on points by the
reflected injections and on edges by nullification induction on
the original edge path.

For each generator S i, tiny graph preservation and the nullness
of the reflected vertices show that the entire reflected colimit
is S i-null. The generator family is indexed by a crisp, crisply
discrete type; the derived discrete-index eliminator extends the
crisp fiberwise tiny argument to all ordinary i. Each tiny witness
is used only to prove a proposition.

Once the reflected colimit is null, nullification induction
constructs the inverse to the specified canonical comparison.
The source includes the vertex inverse equations and the actual
edge square needed for the homotopy-coequalizer inverse law.
Modal preservation is therefore a conclusion, not a supplied
field or assumed equivalence.

### Exact boundary of the generality claim

The checked concrete scope now includes:

* Dependent sums over arbitrary same-universe crisp, crisply
  discrete index spaces.
* Homotopy coequalizers and pushouts of crisp diagrams.
* Arbitrary crisp graph homotopy colimits with crisply discrete
  vertex and total edge index spaces, including the library HIT.
* Crisp sequential colimits, from the previously checked actual
  sequence comparisons.

These results apply at successive stages of an explicitly supplied
cellular construction: graph or pushout attachments followed by the
checked sequential comparison. The separate accepted quasi-unital HCD
construction derives its actual sphere-cell presentation and full mapping
universal property. Its chosen-model scope is recorded in
coherent-diagrams.md#coherent-diagram-boundary.

In particular, the graph construction does not represent an
arbitrary infinity-category diagram. Even an ordinary category
regarded as a graph loses the data enforcing composition in its
homotopy colimit. Those data must not be inferred from the graph
HIT's name.

The separate complete quasi-unital HCD comparisons prove the required
canonical maps and full coherent cocone compatibility from the actual
diagram data. They do not accept a desired cone equivalence or preservation
certificate as a premise. See tiny-colimits.md#tiny-power-coherent-colimits and
tiny-colimits.md#tiny-null-coherent-colimits for their precise common-universe,
external-tiny/discrete and named structural hypotheses. Equivalence with
every other infinity-category implementation remains unclaimed.

<a id="cellular-presentations"></a>

### Checked result

The result is a uniform theorem for an unbounded, explicitly supplied cellular presentation. Its stages are literal higher inductive pushouts, its realization is the actual sequential colimit, and its coherent cocones are recursively defined data with a proved mapping universal property. Tiny exponentiation and nullification by the stated tiny family preserve the actual canonical transformed realization. No global preservation theorem, inverse, realization equivalence, or cocone comparison is an input.

This gives generic supplied-presentation instances of Myers [A.0.5 and A.0.9](https://arxiv.org/html/2205.15887v1). The separate quasi-unital HCD construction derives its actual all-dimensional presentation and full mapping universal property; its final comparisons are described in `coherent-diagrams.md#coherent-diagram-boundary`, `tiny-colimits.md#tiny-power-coherent-colimits` and `tiny-colimits.md#tiny-null-coherent-colimits`. The generic cellular inverse-cone construction also supports the chosen-model limit theorem 5.0.1. Equivalence with every other infinity-category implementation remains unclaimed.

### Literal stages and coherent cocones

`CellularPresentations.agda` defines a coinductive `Presentation A`. At each stage it gives arbitrary higher types `Boundary` and `Cells`, maps from the boundary to the current stage and to the cells, and a presentation of their literal pushout. In mathematical notation,

\[
A_0=A,\qquad A_{n+1}=A_n\sqcup_{B_n} C_n,
\qquad |P|=\operatorname{colim}_{n\in\mathbb N}A_n.
\]

The maps, boundary types, and cell types may contain unrestricted higher path structure. There is no sethood assumption, finite-dimensional bound, finite number of stages, or finite number of cells. Every source type lies in the declared working universe; the presentation data therefore lies one universe above it. Mapping targets can lie in an independent universe.

For a target `W`, the module independently defines partial cocones. The zero-stage data is a map `A → W`. Successor data consists of the preceding partial cocone, a map from the newly attached cells, and a path equating the two boundary composites. The full cocone consists of all partial cocones with paths expressing compatibility under restriction. Thus the coherent boundary fillers and the higher structure of their path spaces are retained.

`Realization.MappingOut.mapping-universal` proves

\[
(|P|\to W)\simeq\operatorname{Cocone}(P,W).
\]

The proof derives the finite-stage assembly equivalence by recursion from the actual pushout mapping property and then uses the actual sequential mapping property. `stage-computation`, `cell-computation`, `attachment-computation`, and `sequence-computation` expose the corresponding literal constructor computations. The definition of a cocone is not a map out of the desired realization in disguise.

### Canonical transformation without selecting inverses

`CellularTransformations.agda` first accepts ordinary operations `F`, its map operation, and the canonical pushout and sequential comparison maps with their point computations. These fields do not assert that any comparison is an equivalence. The two final wrappers instantiate them by the already defined evaluation/nullification maps.

The transformed presentation is defined before using any tinyness or preservation proof. Given its current comparison `cₙ : Qₙ → F Aₙ`, its next boundary is

\[
\widetilde B_n
=\sum_{v:F B_n}\operatorname{fib}_{c_n}(F a_n(v)).
\]

The two actual boundary maps send a lift to its `Qₙ` coordinate and its image in `F Cₙ`. The successor `Qₙ₊₁` is their literal pushout. The next comparison maps that pushout to the pushout of the three reflected vertices and then applies the actual primitive comparison. This construction uses neither an inverse of `cₙ` nor a proof that `cₙ` is equivalent. Consequently a crisp input presentation gives crisp transformed data even when the tinyness witness is ordinary and merely specified.

The module subsequently proves that, whenever the preceding comparison is an equivalence, each auxiliary lift fiber is contractible and `B̃ₙ ≃ F Bₙ`. Induction derives all stage equivalences from the local primitive pushout theorems. The final map is the actual realization of the resulting sequence map followed by the primitive sequential comparison. Its equivalence is then derived from stagewise equivalence and the primitive sequential preservation theorem. Stepwise cell and attachment computations and the full stage and sequence computations are exported.

`CellularTransformationPresentations.agda` proves that the transformed sequence is the sequence of its recorded coinductive presentation. It then supplies the full recursive cocone mapping universal property for the transformed realization as well. This equality of presentations is proved; it is not a supplied realization certificate.

### Tiny exponentiation and tiny-family nullification

`TinyCellularPresentations.agda` instantiates the operations with `F X = T → X`. Its `preserves-cellular` and `cellular-equivalence` use the accepted external-adjunction pushout theorem and accepted tiny sequential theorem. Their assumptions are:

- A native-crisp working universe, crisp `R` and `T`, crisp initial type and complete cellular presentation.
- The explicit crisp identity-induction, Flat-induction, and Flat-computation rules at the working and zero universes.
- The stated `RealFlat` equivalence at the working universe and ordinary mere `Tiny T`.

There is no additional per-stage or global preservation hypothesis. `natural-crisp-elim` legally applies the crisp local theorem at every ordinary natural-number stage; no ordinary stage parameter is silently promoted to crisp.

`TinyNullificationCellularPresentations.agda` instantiates the operations with actual nullification. It uses the strict constructor-level comparison maps and proves their equivalence from the accepted canonical comparisons using their checked agreement paths. Its additional family inputs are a crisp `Ix : Type₀`, a crisp family `S : Ix → Type ℓ`, `CrisplyDiscrete Ix`, and mere tinyness of each crisp generator. The small generator-index restriction is exactly the scope of the consumed sequential preservation primitive. The theorem does not quantify over unspecified larger generator-index universes.

The raw global theorems transform the whole boundary and cell types. They do not silently claim that an arbitrary index type is fixed by exponentiation or nullification.

### Indexed sphere cells and the exact fixed-index restriction

`CellularSphereCells.agda` gives a literal specialization with an arbitrary cell index `J`, a dimension function `d : J → ℕ`, and arbitrary higher coefficient types `K j`. The boundary sphere is empty for dimension zero and the actual library sphere `S^(d−1)` for positive dimension, lifted into the working universe. The span uses

\[
B=\sum_{j:J}(\partial D^{d(j)}\times K_j),
\qquad C=\sum_{j:J}K_j,
\]

with the literal projection as boundary map. A coinductive `SpherePresentation` translates to the general presentation by direct copattern definitions. Dimensions and cell indices may change at each stage; no upper-dimensional bound is introduced.

For a crisp, crisply discrete `J`, the module derives equivalence of the actual fixed-index comparisons

\[
\sum_j(T\to K_j)\longrightarrow
  \left(T\to\sum_jK_j\right),
\]

and

\[
\sum_j\left(\partial D^{d(j)}\times(T\to K_j)\right)
\longrightarrow
\left(T\to\sum_j(\partial D^{d(j)}\times K_j)\right).
\]

The forward maps are literal evaluation, and their boundary square is reflexivity. Nullity of the index follows from the checked tiny discrete-index theorem; nullity of every finite sphere and the empty boundary follows from `TinySpheres`. This fixed-index interpretation additionally uses the explicit point `r₀ : R` required by that index theorem. The coefficient family and dimension function may vary in the ordinary context.

`NullificationSphereCells.agda` derives the corresponding two coefficientwise nullification comparisons. The forward map on a reflected coefficient is the actual nullification recursor sending a coefficient unit to the corresponding indexed cell or boundary point. Its boundary square and unit computations are proved by nullification induction. The proof uses the checked universe-polymorphic dependent-sum reflection theorem over null bases. Both the generator index and the cell index have their explicit crisp discreteness hypotheses; no resizing or arbitrary-family crispness is assumed.

### Exact component and model boundary

These generic modules prove preservation for every explicitly supplied presentation of this form, uniformly through all natural-number stages and with full higher boundary data. The separate accepted quasi-unital HCD modules construct the diagram interface, its all-dimensional cellular realization and the complete cone/cocone mapping equivalences, then instantiate the generic preservation machinery. The final 5.0.1, A.0.5 and A.0.9 correspondences retain that chosen model and their respective universe and structural hypotheses. No converter from every other infinity-category representation is claimed.

All seven sources use `--safe --cubical --guardedness --no-import-sorts --cohesion`. They add no postulates, unsafe termination/productivity directives, resizing, global excluded middle, or desired global equivalence as an axiom. Their sole modal and analytic premises are the explicit pre-existing rules listed above; there is no order or Kock–Lawvere assumption in this cellular development.

<a id="cellular-cone-microlinearity"></a>

### Supplied cellular data

Fix a working universe and actual vertex types `X(v)` indexed by an
actual type `V`. The initial partial cone is literally `Π v, X(v)`.
Each successive attachment specifies an actual cell-index type `C`,
actual boundary and extension types `B(c)` and `E(c)`, coefficient types
`Y(c)`, and actual maps `j(c) : B(c) → E(c)`. All of these may be higher
types. The instantiated restriction map is exactly

```
r : (Π c, E(c) → Y(c)) → (Π c, B(c) → Y(c))
r(fill)(c)(b) = fill(c)(j(c)(b)).
```

The attachment also supplies the prescribed boundary map
`delta : Previous → Π c, B(c) → Y(c)`. Its next partial-cone type is the
literal homotopy pullback

```
Σ (old : Previous, fill : Π c, E(c) → Y(c)), delta(old) = r(fill).
```

The equality is a complete function-space path. Evaluating it at a cell
and boundary point gives the actual boundary comparison. No set or
propositional truncation is inserted into the attachment data.

A coinductive `Schedule` supplies the successive attachments, with its
tail indexed by the literal newly constructed pullback. A state/advance
recursion constructs all finite stages. The theorem `stage-is-pullback`
is reflexivity: the next stage is that pullback by definition, not by
an assumed identification or an assumed microlinearity witness.

### Actual inverse tower and universal property

The transition `drop(n)` is the actual first projection of the stage
pullback. The full cone is defined as

```
Σ (p : Π n, PartialCone(n)),
  Π n, drop(n)(p(n+1)) = p(n).
```

The tower compatibility consists of full path types. A constructed graph
with nodes `n : Nat` and one edge `n+1 → n` identifies this exact type
with the already proved graph-limit presentation. Its component
projections and edge squares retain the supplied compatibility paths.

For every source type `T`, in an independent universe, the module
constructs the exact mapping equivalence between `T → Cone` and
compatible families of maps `T → PartialCone(n)`, with path-valued
commuting edge squares. Both directions are explicit. Projection and
edge-square computations are reflexivity, and precomposition
naturality is proved. Each individual attachment also has its literal
mapping-space pullback universal property.

### Microlinearity conclusion

Microlinearity is relative to any supplied family of actual infinitesimal
test squares, with independent test-index and test-space universes.
The only microlinearity inputs are the vertex types and all coefficient
types `Y(n,c)`. Products and powers derive microlinearity of every filler
and boundary-data type. Pullback closure then derives each successive
partial-cone type by induction. Graph-limit closure derives the full
inverse-tower cone.

There is no microlinearity premise for a partial-cone stage, cell index,
boundary type, or extension type. The data types and stages share the
declared working universe; no resizing is used. Higher boundary and
tower paths remain intact.

This is a uniform theorem for supplied cellular cone presentations in
all finite dimensions and their full inverse tower. It does not assert
that every infinity-category diagram admits such a presentation. The
dual cellular colimit work has the same stated representation boundary.

<a id="natural-cubical-fillers"></a>

## Natural cubical fillers and their sphere boundaries

The accepted modules under `src/Orbifolds/Coherent` construct an actual
equivalence between complete endpoint-typed cubical fillers and
nullhomotopies of their sphere boundaries. They also prove naturality for
the literal coordinate action on fillers. Naturality is not assumed merely
because the two types are equivalent.

### Constructed comparisons

For each finite outer degree `n`, write `kappa x` for the shell of the
constant cube at `x`. `NaturalCubicalFillerBoundary` proves

(Sigma x : X, kappa x = b)  ≃  Filler n b.

Its forward function is literal substitution of the canonical constant
filler along the supplied boundary path. The equivalence follows from the
constant-cube equivalence and the proved restriction-fiber description of
fillers. Its naturality follows from dependent substitution naturality,
strict constant-shell naturality and the actual filler action.

`NaturalQuotedFillers` next constructs

(Sigma x : X, h = constant x)  ≃  Filler n (quote h).

Quotation is the already proved natural equivalence from maps out of the
actual iterated-suspension boundary sphere to cubical shells. The path in
the left side is quoted with its orientation reversed, and the strict
constant computation identifies its endpoint with `kappa x`. The resulting
filler comparison is proved natural with exactly the strict boundary cast
from `quote-natural`.

`NaturalCubicalFillerRepresentation` extends this to every shell `b`.
It uses the canonical point `(evaluate b, quote-evaluate b)` in the actual
contractible fiber of quotation. Substitution along this fiber's boundary
path gives the general equivalence. Naturality of inverse evaluation is
chosen from the contraction of that entire fiber, so the necessary boundary
coherence is retained. The standard nullhomotopy action is proved to be

(x, p) |-> (f x, evaluate-natural f b followed by postcomposition of p).

Both directions of the filler/nullhomotopy equivalence commute with the
actual maps. This particular `evaluate-natural` has the same endpoints as
the earlier comparison in `NaturalCubicalShellRepresentation`; the code
does not silently identify the two chosen paths.

### Useful stronger interface for the colimit construction

The general representation also exposes `fiber-fill-equivalence` for
**any actual point** `(h, q) : fiber quote b`, together with
`fiber-fill-natural`. The bar colimit can therefore fix the quoted sphere
boundary at a universal cocone and map that exact point along each target
map. This keeps its boundary map literally postcomposition and avoids a
second, unnecessary comparison between chosen inverse-evaluation paths.

`StrictCubicalShellFunctor` proves strict identity and composition for the
direct shell action. `StrictCubicalTotalIsomorphism` proves that the actual
canonical-cube and forgotten-filler maps are strict inverses, with actual
mapping, constant and contraction computations. These results use only the
explicit `StrictCubicalExtensionality` rules for interval functions and
paths; they do not need strict extensionality over arbitrary inner types.

### Use in the coherent colimit construction

These are finite representation and naturality results. The unbounded
quasi-unital HCD colimit and powered/nullified comparisons use the additional
constructions in this chapter and [Tiny colimits](tiny-colimits.md); those
conclusions are not assumptions of the finite filler modules.

<a id="null-coherent-reflection"></a>

## Native nullification of an arbitrary coherent diagram

Orbifolds.Coherent.HomotopyCoherentNullification.Reflection.reflected
constructs nullification of any existing diagram in the chosen quasi-unital
homotopy-coherent interface. It preserves actual higher action cubes on
generating points of nullification; the input need not be strict or have
constant coherence cubes.

### Exact result

For a strict type-enriched source category C, an actual HCD D, a small
family of nullification generators S, and the explicit parameter
E : StrictCubicalExtensionality, the construction gives:

- Values literally equal to native Null S (D.Value x).
- Degree-zero action literally equal to the native modality map of the
  original arrow action.
- An actual action cube in every finite degree, both complete sets of
  composition face laws, and an actual identity homotopy.
- The native unit as a transformation of the complete coherent
  presentations, with its naturality equation checked in every degree.
- Nullity of every reflected value.

The construction does not pretend that the native modality map obeys
strict composition and unit laws. Its higher cells supply the required
coherence. It does not by itself prove preservation of the bar colimit.

### Construction

Orbifolds.NullCubicalExtensions proves nullity of actual finite typed
fillers in a null target. It also proves that restriction of dependent
null-valued sections along the native unit is an equivalence. Requested
extensions form contractible fibers and compute on the unit.

HomotopyCoherentActionData stores finite action histories in nested inner
types. Outer finite bounds select lower degrees; bound irrelevance,
truncation and selected-layer laws are derived. CoherentArrowSplits,
CoherentCubeTensors and HomotopyCoherentActionCompatibility prove every
pair of finite boundary-face equations from that lower history.

At a generating point eta a, the next requested cube is the original
action cube mapped pointwise by eta. CoherentTensorNaturality and the
original diagram's full face laws show that its boundary is exactly the
assembled boundary of the reflected lower history.
StrictNullCubicalLifting forms its canonical typed filler and extends the
dependent filler family through the native nullification eliminator.
This supplies the next cube, all its exact faces and its unit computation.

HomotopyCoherentNullification iterates the construction through every
outer finite degree. Lookup stabilization identifies each selected finite
action with the final one. Its identity homotopy follows from the original
identity homotopy and the actual native nullification identity cell. The
unit transformation follows from the all-dimensional unit computation.

The separately checked NullHomotopyCoherentDiagram and NullCoherentUnit
give the earlier strict-input specialization, where the generating cubes
are constant cubes at original composites. The general construction
above retains nonconstant source coherence.

### Foundation and interpretation

These reflection results need the stated cubical strict extensionality
interface. They do not need the separate strict function-extensionality
parameter over arbitrary inner types. There is no outer-Nat cofibrancy,
global outer product, resizing, added global postulate, unsafe option,
unsolved meta, desired filler or colimit-preservation premise.

The quasi-unital interpretation is external model guidance from
[Harpaz](https://arxiv.org/abs/1210.0212) and
[Tanaka](https://arxiv.org/abs/1606.05669). The code checks the actual unit
homotopy and its mapping-space identity laws; it does not assert a
machine-checked conversion between every infinity-category presentation.

The HCD cone boundaries and inner limit construction are used with the coherent cocone/bar realization and cellular comparison described in [Tiny colimits](tiny-colimits.md). A unit transformation alone is not that complete comparison.
<a id="null-unit-fibers"></a>

## Fibers of the actual nullification unit

`Orbifolds.NullUnitFibers` is accepted by the canonical Agda 2.8.0.2
kit with `--safe --cubical --cohesion`, without warnings. All generator,
total-space, base, and family universe levels are independent.

### Generic map comparison

For an arbitrary family of nullification generators `S`, a null type
`B`, and a specified map `q : X → B`, the module
`Theory S.Map X B null-base q` uses the actual comparison
`NP.rec null-base q : Null S X → B`. Its unit computation is reflexivity.

If this actual comparison is an equivalence, its nested `Equivalent`
module proves

`fiber unit (unit x₀) ≃ fiber q (q x₀)`.

Both directions preserve the `X` coordinate. This follows by applying
the equivalence's identity-space comparison separately at each `x`,
then taking the dependent sum over `X`. No arbitrary replacement of the
comparison map is made.

### Connected families over a null base

`Theory S.Over B null-base F connected` takes an actual family
`F : B → Type ℓf` and contractions of `Null S (F b)` for every `b`.
The accepted `NullSigmaReflection` theorem proves that the recursor
extending the first projection is an equivalence. The new module then
proves, for every `x₀ : Σ B F`,

`unit-fiber≃family x₀ : fiber unit (unit x₀) ≃ F (fst x₀)`.

The inverse satisfies

`fst (invEq (unit-fiber≃family x₀) a) = (fst x₀, a)`.

This is exported as `inverse-inclusion`, and as equality of functions
in `cover-map-triangle`. Thus the theorem preserves the literal
inclusion of the family fiber into its total space, as needed for a
later covering construction.

The module adds no axioms and assumes no resizing, crispness, or
classical choice. It does not itself assert etaleness or a universal
covering theorem: identifying the desired modality, proving the
specific base null and its fibers connected, and verifying the covering
structure are separate applications.

<a id="nullification-graph-colimits"></a>

## Nullification preserves actual crisp discrete graph colimits

The accepted modules `NullificationGraphColimits` and
`TinyNullificationGraphColimits` extend the checked portion of Theorem A.0.9
to arbitrary small crisp graph diagrams with crisply discrete vertex and
total-edge index types.

### Actual comparison and proof

For a family S of nullifying generators and an actual graph diagram D,
the reflected diagram keeps the same vertices and edges, replaces each
object X by the actual HIT `Null S X`, and replaces each arrow by its
nullification map. Its colimit is the literal homotopy coequalizer of the
incidence maps from the dependent sum of edge source objects to the
dependent sum of vertex objects. `GraphColimits` already identifies this
presentation with the pinned library's graph-colimit HIT, including both
its point and path constructors.

`Nullification.Diagram.comparison` maps this reflected colimit to the
nullification of the original colimit. It is defined on actual point and
edge constructors. The inverse is the actual nullification eliminator of
the unit cocone. Both inverse laws are proved, including the dependent
square over every edge; the higher path coherence is retained.

First, preservation by each generator's exponential implies that the
reflected colimit is null, using the proved graph exponentiation comparison.
Then the inverse and its laws prove that the specified comparison is an
equivalence. The generic intermediate lemma names exponential preservation
as its input; the final crisp wrapper **derives** this input from the
actual external tiny adjunction for each generator. It does not assume
the desired nullification-colimit equivalence.

### Exact scope

The final `Context.Diagram.preserves-graph` requires a crisp same-universe
family of generators, crisply discrete generator index, tiny data for each
crisp generator, the recorded R-flat/crisp identity/Flat rules, and a crisp
graph diagram whose vertex and total-edge indices are crisply discrete.
All the graph's object types may have higher paths. No sethood condition
is imposed on the diagram objects.

The graph modules have the scope above; a graph does not encode all
composition coherences of an infinity-category diagram. Uniform supplied
cellular presentations are handled in coherent-diagrams.md#cellular-presentations. The separate
accepted quasi-unital HCD construction supplies its actual all-dimensional
presentation and the final A.0.5/A.0.9 comparisons, under the exact hypotheses
in tiny-colimits.md#tiny-power-coherent-colimits and tiny-colimits.md#tiny-null-coherent-colimits.
Equivalence with every other infinity-category implementation is unclaimed.

<a id="join-resolution"></a>

## Iterated fibered joins and the image theorem

`Orbifolds.JoinResolution` proves the join-resolution ingredient used in
the proof of Theorem 5.4.7 of
[arXiv:2205.15887](https://arxiv.org/abs/2205.15887).

For an arbitrary map `f : A → B` between types in the same universe,
`Resolution f` constructs the following actual higher-inductive objects:

- `Stage 0` is empty.
- `Stage (suc n)` is the pushout of the two projections of
  `Σ[x : Stage n] Σ[a : A] stage-map n x = f a`.
- `step n` is the left pushout inclusion and `added n : A → Stage (suc n)`
  is the right inclusion.
- `stages` is a Cubical `Sequence`, and `Colimit` is its actual sequential
  colimit, with canonical `to-base : Colimit → B`.

The first positive stage is equivalent to `A`. Each positive step, each
`added` map, and `to-colimit : A → Colimit` is proved surjective. These
statements do not require `A` to be inhabited or `f` to be surjective.
The source factorization through `to-base` computes to `f`.

### The image equivalence is proved

The module proves that `to-base` has propositional fibers, then uses the
library's uniqueness of image factorizations to obtain
`colimit≃image : Colimit ≃ Image f`. If `f` is surjective,
`colimit≃base` equips the actual canonical `to-base` map with an
equivalence proof. Neither result is an assumption or a truncated stand-in
for the infinite join theorem.

The proof proceeds fiber by fiber. `SequentialFlattening` identifies each
fiber with the sequential colimit of the stage fibers. The difference
between transport along `ua (idEquiv _)` and the constant base path is
explicitly resolved by `uaIdEquiv`.

Given `(a,p) : fiber f b`, each positive transition of that fiber sequence
is nullhomotopic, through the actual pushout path to the newly added copy
of `(a,p)`. The required dependent equality is proved by path composition
and cancellation. A general `NullSequence` lemma shows that a pointed
sequence of nullhomotopic maps has contractible colimit: its homotopies
give a path of `Sequence` records to the sequence with constant maps, and
the latter has an explicit contraction respecting the colimit path
constructors. Shifting the sequence removes the empty initial stage.

Every point of the final fiber merely comes from a source point.
Eliminating that mere witness into the proposition that the fiber is
contractible proves the embedding assertion without selecting preimages
or invoking choice.

This module is a homotopy-type-theoretic result for arbitrary higher types.
It contains no modal-preservation, étaleness, or crispness assumptions.
Those are separate inputs to the application in Theorem 5.4.7.

