# Real sheaves

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="dedekind-real-sheafs"></a>

## A constructive real-open site, actual sheaves and the plain-real boundary

The fixed real-open-site construction supplies a nontrivial covering topology, the continuous-real sheaf, subcanonicity and fixed-site cartesian closed operations. It also proves contractibility of the plain real carrier’s square-zero subtype and noninjectivity of its specified affine coefficient map.

### What this integration constructs

The development now supplies concrete constructions for a topological site built from the actual constructive Dedekind real carrier, its sheaf of continuous real-valued functions, proofs that its actual representables are sheaves, and terminal, product and exponential operations in the category of set-valued sheaves on that site. These definitions instantiate the existing ordinary interfaces with constructed data. They do not ask a caller to provide the real topology, its covers, the continuous-real sheaf condition, or the exponential closure theorem as additional assumptions.

| Batch | Concrete construction | Principal exported result |
| --- | --- | --- |
| Continuity/completeness | Actual real-open inclusion category, finite intersections, covering sieves and a proper cover | `realOpenGrothendieckTopology` and `overlappingRaySieve-covers` |
| Continuity/completeness | Actual continuous sections, restriction, compatible gluing, continuity and uniqueness | `realContinuousSheaf` |
| Continuity/completeness | Actual representable presheaves and their sheaf conditions | `realOpenSite-subcanonical` |
| Continuity/completeness | Actual fixed-site sheaf category, terminal object, products, exponentials and local component formulas | `sheafExponentialStructure` and `continuousRealFunctionObject` |
| Continuity/completeness | Square-zero subtype of the plain constructed real carrier and its exact affine coefficient map | `isContrDReal`, `affineRestriction-not-injective` and `affineRestriction-not-isEquiv` |

### The real-open site and a nontrivial cover

A real-open object is an actual proposition-valued subset of the constructed Dedekind real carrier together with its proved rational-ball openness. An arrow is an inclusion of those subsets, explicitly lifted to the chosen site hom universe. The category has actual identity and composite inclusions. The whole and empty opens have their terminal and initial laws; an inclusion from the whole real line into the empty open is impossible.

Finite intersections are actual intersections of these subsets, with their proved openness, projections, pairing and product laws. No equality of open-set codes or propositional extensionality for open objects is assumed.

A sieve covers an open precisely when every point of that open merely belongs to some source open of an arrow in the sieve. The witness records the open object, its inclusion, sieve membership and point membership. The topology fields are proved: cover propositionhood, the top sieve, upward closure, pullback stability through actual intersections, and locality through composition. Covering members remain under propositional truncation.

The example uses the actual rational rays \(x<1\) and \(0<x\). Locatedness of each real proves that their sieve covers the whole line. Its identity arrow is absent: either proposed whole-line inclusion into one of those rays contradicts the rational endpoint. Thus the constructed topology has a proper covering sieve. This is a concrete witness, not an assumed nontriviality property or a completed rational-basis comparison theorem.

### Continuous sections and actual unique gluing

A section over an open \(U\) is an actual function from the ordinary subtype of points in \(U\) to the constructed real carrier, paired with continuity for the proved open-subspace topology. Continuity is proposition-valued; section sethood and extensionality are proved. Restriction is actual precomposition with an inclusion, with identity and composition laws.

For a matching family on a covering sieve, two local values at the same point agree by restricting both sections to the actual intersection of their source opens and applying matching-family naturality. The two composite inclusion arrows and their sieve-presheaf entries are identified using the already proved propositionhood of inclusion homs and sieve membership.

The gluing proof then constructs a real together with a certificate that every local witness gives that value. Under mere inhabitation of the covering-witness type, this value-with-certificate type is itself a proposition. Eliminating the truncated cover into that proposition gives the actual real value without selecting a covering object.

The function obtained pointwise restricts to each given local continuous section. Local continuity is proved using truncated open neighborhoods and truncated rational-radius witnesses; no family of chosen radii is extracted. This gives continuity of the global function. A competing amalgamation agrees pointwise because equality of actual reals is a proposition. Membership-certificate comparisons handle the two representations of the same subtype point. The construction fills every field of the existing ordinary `Amalgamation`, `IsSheaf`, and `Sheaf` interfaces.

### Subcanonicity

For every real-open object \(V\), the original representable presheaf has value \(\operatorname{Hom}(U,V)\) over \(U\), and restriction is composition of actual inclusions. A cover and local inclusion data give membership in \(V\) pointwise by proposition-valued truncation elimination. The resulting actual inclusion supplies an amalgamation; its restriction and uniqueness laws follow from inclusion-hom propositionhood.

This proves subcanonicity for the fixed constructed topology. The representable of the whole open has inclusion-hom values. It is not identified with the continuous-real sheaf, whose values are continuous real-valued functions.

### Terminal objects, products and exponentials

Batch 096 instantiates the existing proved ordinary sheaf constructions with the actual site and the constructed ordinary function-extensionality instance. The closed instance is defined from the existing equality/path bridge and then made proof-opaque; its body is checked, and no new extensionality assumption is supplied. All three categorical instances use the same term. This is the existing weak ordinary function-extensionality operation, not a newly constructed coherent semantic-universe structure. Morphisms are all natural transformations between the underlying presheaves. The terminal and product sheaves use their actual presheaves and the already constructed gluing proofs. The projections, pairing and all three product equations are exposed.

The exponential uses the existing theorem that constructs sheaf amalgamations for the actual presheaf exponential by gluing over pullback covering sieves. Its sheaf condition is proved, not supplied as an additional field assumption. The fixed-site wrappers expose the actual currying and uncurrying maps, both inverse laws, their ordinary equivalence, source naturality, evaluation, and the constant arrow obtained by currying the first projection. The fully faithful forgetful functor preserves the underlying constructions and maps through explicit computation statements.

For sheaves \(R,F\), a section of the constructed exponential over \(U\) has the exact form

\[
\operatorname{Nat}\bigl(yU\times\underline R,\underline F\bigr).
\]

Evaluation applies that natural family at the identity inclusion and the supplied \(R\)-section. Currying, uncurrying, restriction and naturality retain their concrete component formulas. Fixing \(R=F\) to the actual continuous-real sheaf gives its internal function object and the corresponding pointwise evaluation formulas.

The constant arrow is constant in its exponent argument: it returns the restriction of the supplied output section. That output section may still vary with the base point. No identification with an externally chosen topological mapping space, smooth function space, or unrestricted function set is asserted.

These are operations and laws of an ordinary cartesian closed category on the fixed site. They are not by themselves a syntax interpretation or substitution theorem.

### A precise negative control for the plain real carrier

Batch 098 constructs the actual square-zero subtype of the accepted Dedekind carrier,

\[
D_{\mathbb R}=\sum_{d:\operatorname{DedekindReal}}(d\cdot d=0).
\]

Both multiplication and equality are the actual cut operation and Cubical path type. The proof uses the already constructed tight apartness and preservation of apartness by products. If \(d\) were apart from zero, then \(d\cdot d\) would be apart from zero; transporting along its square-zero equation contradicts irreflexivity. Tightness gives \(d=0\) constructively. The chosen zero element and propositionhood of the square-zero certificate give a contraction of the whole dependent pair type, including its witness component.

The module then defines the exact forward map

\[
\Phi:\operatorname{DedekindReal}\times\operatorname{DedekindReal}
\longrightarrow(D_{\mathbb R}\to\operatorname{DedekindReal}),
\qquad \Phi(a,b)(d,p)=a+b\cdot d.
\]

For every coefficient pair, \(\Phi(a,b)\) is proved equal to the constant function with value \(a\). The explicit coefficient pairs \((0,0)\) and \((0,1)\) are distinct by the proved inequality \(0\ne1\), but their image functions are equal. This refutes path injectivity and Cubical `isEquiv` for this exact affine-restriction map. The latter conclusion uses the genuine inverse and retraction supplied by an assumed `isEquiv` to derive the already-refuted injectivity statement. It does not assert that the two types have no unrelated equivalence.

This result delineates the plain external carrier: its own square-zero subtype and ordinary ambient function type cannot support unique coefficients for the displayed affine map. It is not a statement about the internal square-zero object or internal function object of a sheaf, generalized points of a formal-stage line, or every model of the Myers setting. The nonzero nilpotents already constructed in coefficient-algebra extensions live in different carriers and remain compatible with this result. No inference from this plain-carrier calculation to a universal impossibility of synthetic or classical-orbifold extensions is made.

### Universe and logical scope

| Data or structure | Universe level |
| --- | ---: |
| Dedekind real carrier, points of an open subtype, subset membership | 1 |
| Plain-real square-zero subtype, affine coefficient pairs and its ambient function type | 1 |
| Real-open object codes, lifted site homs, cover witnesses, continuous sections | 2 |
| Sheaf section values and sheaf morphisms | 2 |
| Base category, sieve and Grothendieck-topology records | 3 |
| Type of sheaf objects and sheaf conditions | 3 |
| Category record with sheaf object level 3 and hom level 2 | 4 |

The higher levels are retained explicitly. The type of all these sheaf objects is not asserted to be a set or a universe of semantic types. The gluing construction's coherent-value certificate quantifies over universe-2 covering witnesses; projecting its real component into universe 1 is ordinary dependent-pair projection, not resizing.

The new constructions require no excluded middle, choice of covering members, countable selection, propositional resizing or assumed gluing operation. The independent reviews track all truncation eliminations into proved propositions. Existing ordinary modules retain their original source mode and interface; the separate Cubical bridge supplies the actual equality and function-extensionality instances. Native warning records remain part of the evidence and do not establish an operational interpretation of the source language.

### Remaining semantic obligations

This is substantive progress toward an actual constructive semantic setting: concrete opens, a nontrivial topology, actual sheaves and ordinary cartesian closed operations. It does not settle the existence of the entire original Myers foundation or the external orbifold comparison.

The outstanding work includes the appropriate smooth and infinitesimal site, calculus and manifold data, quotient/descent and properness constructions, the required dependent and higher type operations, semantic universes, and an exact interpretation and substitution theorem for the intended source language. A terminal/product/exponential package alone does not give dependent products or a locally cartesian closed structure, and a set-valued topological sheaf category alone does not supply the required univalent or higher model. No statement is made that every model or classical-orbifold extension is impossible.

<a id="dedekind-real-sheaf-ring"></a>

## Arithmetic on the actual continuous-real sheaf

The real-sheaf ring construction supplies commutative rings of continuous real sections, restriction homomorphisms, arithmetic sheaf morphisms, and rings of generalized sections with precomposition homomorphisms.

### Constructed section operations

A section on an actual real-open domain is a function from that open subtype
to the constructed Dedekind real carrier, together with its continuity proof.
Pairing two sections produces the actual pair of their values. Continuity of
the pairing is proved using the constructed coordinate-ball product topology
and the intersection of the two open preimages.

The two local witnesses can carry different proofs of membership in the same
open domain. Propositionhood of membership identifies those subtype points,
so the two ball conditions can be applied at a common point. Local radii
remain under propositional truncation. The construction selects no global
radius, cover index or approximation sequence.

Constants are continuous by using the whole source neighborhood. Unary and
binary operations are formed by composing actual continuous maps; the binary
case uses the proved continuity of pairing. Thus zero, one, addition,
negation and multiplication give actual continuous real-valued sections.

### Section rings and restriction maps

On every actual open domain, the constructed carrier of continuous sections
has constant zero and one and pointwise addition, negation and multiplication.
Each ring law follows by section extensionality from the corresponding law
of the actual Dedekind arithmetic. The construction fills the pinned Cubical
`CommRing` interface; carrier, addition and multiplication have explicit
computation laws identifying them with these actual operations.

Restriction is precomposition with the actual inclusion of open subtypes.
It preserves zero, one, addition, negation and multiplication. These equations
fill the genuine `CommRingHom` preservation record, and its function
projection computes to the intended restriction map. Identity and composition
are equalities of the actual ring homomorphisms, using the established
restriction equations and homomorphism extensionality. Composition is
contravariant: restricting from a larger open to an intermediate open and
then to a smaller one equals the direct restriction.

The fixed-site specialization exposes a section ring over every constructed
real-open object and the corresponding restriction homomorphism on each
inclusion. It retains exact compatibility with the existing `SectionAt` and
`restrictAt` values and maps. No abstract ring-valued restriction operation is
supplied as a new assumption.

### Arithmetic sheaf morphisms

The ring object uses the actual continuous-real sheaf constructed on the real-open site. Its five arithmetic arrows are constructed explicitly:
zero and one from the terminal sheaf, addition and multiplication from the
actual product of the continuous-real sheaf with itself, and negation from
the sheaf to itself. Their components are the continuous-section operations.
Their naturality is proved by the actual restriction-preservation laws, with
section and pointwise component equations retained.

For every sheaf \(H\) on this fixed site, the actual morphism type

\[
\operatorname{Hom}(H,\mathcal R)
\]

is equipped with a commutative-ring structure. Its operations are categorical
composition with these arithmetic arrows and the actual product pairing.
The ring laws are equalities of natural transformations, proved using
natural-transformation extensionality and the section equations at every
open object. The resulting `generalizedSectionCommRing` has explicit carrier
and operation computation laws.

Every actual arrow \(K\to H\) induces a genuine ring homomorphism
\(\operatorname{Hom}(H,\mathcal R)\to\operatorname{Hom}(K,\mathcal R)\)
whose underlying map is categorical precomposition. All five preservation
fields are proved from the component computations. This supplies arithmetic
compatible with changes of generalized domain, beyond a list of unrelated
ring structures on individual carriers.

### Universes and nontriviality

| Carrier or structure | Universe level |
| --- | ---: |
| Dedekind real carrier and points of an open subtype | 1 |
| Actual real-open objects and lifted inclusion homs | 2 |
| Continuous-section carriers and ring homomorphisms | 2 |
| Commutative-ring structure type on a section carrier | 3 |
| Sheaf objects on the fixed site | 3 |
| Sheaf morphisms and generalized-section carriers | 2 |
| Commutative-ring structure type for generalized sections | 3 |

No universe is resized. Where a proof is made opaque to control elaboration,
its full constructed body still has to be checked; the actual carrier and
operation maps remain the displayed ones. Proof opacity does not change the displayed operation maps or hypotheses.

An actual point of a domain proves its section ring nontrivial by evaluation.
For the whole real line, the actual zero point distinguishes the zero and
one sections. This also proves that the corresponding zero and one sheaf
morphisms are distinct. Nontriviality is not asserted for every open domain:
an empty domain has only one function into the real carrier.

### Remaining semantic boundary

The bounded result is commutative-ring arithmetic on the actual continuous-real
sheaf over the fixed topological site. It constructs no inverse for an arbitrary
section, proves no field-of-sections assertion, and extracts no pointwise
apartness certificate from a section. It makes no blanket nontriviality claim
for sections over empty domains.

The existing plain-real square-zero negative control and formal-stage
nilpotent examples retain their separate carriers and meanings. This extension
does not identify the continuous-real sheaf with a smooth infinitesimal line,
settle the entire original Myers-model question, or give a universal no-model
theorem. Calculus and manifolds, the intended smooth and formal sites,
dependent and higher type operations and universes, quotient/descent/properness,
and an exact source interpretation and substitution theorem remain outstanding.

<a id="dedekind-polynomial-pullbacks"></a>

## Actual polynomial calculus and fixed-site sheaf pullbacks

The polynomial/pullback construction supplies polynomial analytic derivatives and their continuous iterated derivative tower over the actual Dedekind reals, and actual universal pullbacks in the fixed real-open sheaf category.

### Constructed polynomial calculus

The real carrier, arithmetic, metric, constructive apartness, and reciprocal on supplied apartness certificates are the existing constructed Dedekind-real operations. `RealPolynomial` is the pinned Cubical polynomial higher inductive type over the actual real commutative ring. Horner evaluation and the polynomial divided difference are defined on that type with explicit coherence for its trailing-zero path:

\[
\operatorname{eval}(a::p,x)=a+x\operatorname{eval}(p,x),\qquad
\operatorname{DD}(a::p,x,y)=\operatorname{eval}(p,y)+x\operatorname{DD}(p,x,y).
\]

The constructed factorization holds for every pair of actual real inputs, including equal inputs:

\[
\operatorname{eval}(p,y)-\operatorname{eval}(p,x)
=(y-x)\operatorname{DD}(p,x,y).
\]

The formal derivative is a polynomial-valued map. Its evaluation at `x` equals the diagonal divided difference, with the formal polynomial addition and trailing-zero coherence proved. These algebraic facts supply the particular functions and equations used by the subsequent analytic proof.

`MetricContinuousAt f x` quantifies over positive rational tolerances and merely existing positive rational radii. The candidate proves its constant, identity, addition, multiplication, and composition closures from actual existing metric/ring operations. Polynomial evaluation and each fixed-base divided difference are continuous by induction. The diagonal slope is continuous through the evaluation of the actual formal derivative. An explicit comparison in both directions relates this metric predicate to the existing actual open-fragment continuity predicate; it retains their original universes.

### Actual derivative predicate and uniqueness

The difference quotient is the actual real expression

\[
\bigl(f(y)-f(x)\bigr)\operatorname{inverseApartReal}(y-x).
\]

The required inverse certificate is constructed from supplied `y # x`; it is never inferred from mere negated equality. The quotient is proved independent of the apartness witness. `HasDerivativeAt f x d` states that for every positive rational tolerance there merely exists a positive rational radius such that every actual real `y` apart from `x` within that radius has its difference quotient within the tolerance of `d`. The quantified points are all actual Dedekind reals. The predicate is proposition-valued in `Type₁`.

A constructed general criterion turns an exact factorization through a function locally continuous at the base point into an analytic derivative. In the polynomial case the supplied factor is the explicit divided difference and both required hypotheses have been proved. Thus the analytic derivative of polynomial evaluation is the evaluation of its actual formal derivative.

Derivative uniqueness applies to any actual function satisfying this derivative predicate. At a half-tolerance it combines two merely existing radii inside a proposition, constructs a common positive rational radius, and uses the explicit point `x + rationalCut(r/2)` with proved positive apartness from `x`. Both bounds concern this same point and difference quotient. The metric triangle inequality and the existing arbitrarily-small-distance theorem give equality of the derivative values. No chosen sequence of radii, countable choice, or selection of cut approximations is used.

The derivative-value-and-proof type for every polynomial at every real point is consequently contractible. The constant, identity, and square examples are stated for the actual real functions, with derivatives `0`, `1`, and `x + x`; the square derivative is unique and the actual square function is continuous. Their complete native entry is required separately from acceptance of the generic criterion or polynomial theorem.

### The explicit continuous polynomial derivative tower

Natural-number recursion constructs the actual iterated formal derivative polynomial `Dⁿ(p)`. Evaluation gives an explicit sequence of functions beginning at the evaluation of `p`. Every level is continuous in the metric and actual open-fragment senses, and the next level is its analytic derivative at every actual real input. Induction and derivative uniqueness show that any other analytic derivative tower with the same starting polynomial function agrees with this tower at every level.

This is an actual polynomial smoothness result with a supplied tower. It does not construct differentiation or smoothness for arbitrary functions, a general analytic chain rule, multivariable or manifold calculus, or a smooth site.

### Constructed pullbacks in the actual sheaf category

For actual sheaves `F`, `G`, and `H` on the fixed real-open site and actual morphisms `α : F → H`, `β : G → H`, the new pullback has value at `U`

\[
\sum_{(a,b):F(U)\times G(U)}\alpha_U(a)=\beta_U(b).
\]

Restriction acts on the two coordinates using the given restrictions. Its equality certificate is constructed using the naturality of `α` and `β`. Coordinate sethood and proposition-valued equality certificates prove sethood of this value type. Actual projections, the commuting square, and the factor map are provided, together with exact component computations and the two projection laws.

The sheaf proof glues the two coordinate matching families with the actual `F` and `G` amalgamations. Naturality and the matching values' stored equations prove equality of the restricted images. Separatedness of the actual target sheaf `H` then proves equality of the glued images. Those sections and their equation form the actual glued pullback section. Its restriction and uniqueness laws fill every amalgamation field. No limit-preservation or extra gluing operation is assumed.

For every actual domain sheaf `K`, the comparison from maps into the pullback to commuting pairs of maps has a displayed inverse. Both comparison composites are proved to equal the identity, and equal projected maps imply equal maps into the pullback. The `O.Equiv` interface here records these explicit quasi-inverse maps and laws. The identity-leg specialization also constructs the embedding `a ↦ (a, α(a))`, its inverse projection, and their actual categorical isomorphism laws.

All generic site/extensionality arguments are supplied by `realOpenCategory`, `realOpenGrothendieckTopology`, and the existing constructed `realSheafFunExt`. The real-open site and sheaf category are actual constructions already accepted in the earlier milestones. Ordinary fixed-category pullbacks are a prerequisite for later base change of display maps; strict substitution, a split comprehension structure, dependent products, and their coherence are separate work.

### Constructivity, universes, and remaining model obligations

The actual real carrier and polynomial type are in `Type₁`. The analytic predicates use proposition-valued finite radius existence in the same level; the topology-continuity predicate remains in its existing `Type₂` interface. The explicit comparison of those particular predicates is not a resizing principle. At the fixed sheaf site, pullback values, each hom type, and each commuting-cone type are in `Type₂`, while `RealSheaf` objects remain in `Type₃`. No additional universe-level function extensionality is postulated.

The constructions add no classical choice, excluded middle, resizing, global radius selector, arbitrary approximation sequence, assumed calculus record, or assumed categorical limit field. They do not construct internal universes or a source-language interpretation/substitution theorem. The full joint Myers-model existence question, smooth and formal stages, higher dependent operations, general quotient/descent/properness comparison, and the complete external orbifold theorem remain unresolved.

The earlier reducedness and affine-map collision for the plain Dedekind-real carrier retain their exact scope. These polynomial and ordinary sheaf constructions neither prove a universal model obstruction nor identify that plain real carrier with a synthetic infinitesimal line.

<a id="dedekind-remainders-families"></a>

## Actual derivative remainders and dependent sheaf families

The remainder/family construction supplies an all-real-input first-order remainder equivalent to the derivative predicate, differentiability-implies-local-metric-continuity, and dependent sheaf-family reindexing with actual pullback comparison maps on the fixed real-open site.

### Constructed derivative remainder

The existing `HasDerivativeAt f x d` predicate and actual Dedekind-real arithmetic, metric, constructive apartness and reciprocal are retained. The new remainder is the concrete expression

\[
R(f,x,d,y)=f(y)-f(x)-d(y-x).
\]

`HasFirstOrderRemainderAt f x d` states that for every positive rational accuracy \(\varepsilon\), there merely exists a positive rational radius \(\delta\) such that every actual real \(y\) within that radius satisfies

\[
|R(f,x,d,y)|\leq \varepsilon\,\operatorname{distance}(x,y).
\]

This is a closed estimate, including the diagonal and inputs without a supplied apartness witness. The bound itself is a `Type₀` proposition; the radius witness and the proposition quantifying over all positive rational accuracies live in `Type₁`, because their controls range over the actual real carrier. No radius selector or resizing principle is extracted.

The constructed closed order is double-negation stable because it is equivalent to the negation of reverse strict order. More specifically, an estimate valid at a base point and at a supplied apart point extends to an arbitrary given point. A hypothetical strict violation contradicts all supplied apartness witnesses; tight apartness then yields equality with the base, where the diagonal estimate gives the contradiction. This is a theorem about actual closed real bounds, not double-negation elimination for arbitrary propositions or a decision procedure for real equality.

The same extension proves absolute multiplication for every pair of actual reals. First, absolute value fixes nonnegative reals. Negative and positive product calculations split the sign only after apartness from zero has been supplied. The constructed path extension handles the zero or undecided case, yielding the actual path \(|uv|=|u||v|\).

### Equivalence with the unchanged derivative predicate

At a supplied apart input \(y\mathrel{\#}x\), the actual inverse law reconstructs the function increment from the existing difference quotient \(Q(f,x,y)\). Actual distributivity and absolute multiplication then prove

\[
|R(f,x,d,y)|
 = \operatorname{distance}(d,Q(f,x,y))\,
   \operatorname{distance}(x,y).
\]

The forward implication from `HasDerivativeAt` weakens its strict quotient estimate to a closed one and multiplies by nonnegative input distance. The diagonal remainder is proved zero. The closed-order extension supplies the bound at every input in the same ball, using the same radius; the caller's neighborhood proof remains in context.

The reverse implication asks for the remainder estimate at half the requested accuracy. Supplied \(y\mathrel{\#}x\) gives strictly positive input distance, so the already constructed positive-factor order reflection cancels that distance. The closed half-accuracy bound is strictly smaller than the requested accuracy. The two actual maps yield an equivalence of the two proposition-valued derivative predicates. The existing quotient is still formed only on its positive-apartness domain; no inverse is inferred from mere negated equality.

### Differentiability implies actual local continuity

At unit remainder accuracy, the additive restore identity, triangle inequality and absolute multiplication give the concrete growth estimate

\[
\operatorname{distance}(f(x),f(y))
 \leq (1+|d|)\operatorname{distance}(x,y).
\]

It is an estimate relative to the specified base point in its supplied remainder neighborhood, not a neighborhood-wide two-point Lipschitz theorem. The coefficient \(1+|d|\) is proved positive. Its actual upper cut supplies a merely existing positive rational upper bound \(b\).

For an output accuracy \(\varepsilon\), the explicit rational scale is \(b^{-1}\varepsilon\), using the constructed rational reciprocal. Its positivity and the identity \(b(b^{-1}\varepsilon)=\varepsilon\) are proved. A common positive rational radius fits both this scale and the remainder radius. The growth estimate followed by strict multiplication by \(b>0\) controls every real input in that ball.

Only two finite truncations are eliminated, and the result is a truncated continuity-radius witness. This constructs `HasFirstOrderRemainderAt f x d → MetricContinuousAt f x`, and hence `HasDerivativeAt f x d → MetricContinuousAt f x`. It does not construct a global modulus, countable choices, or continuity of the derivative function. General analytic sum, product and chain rules, uniform interval calculus and manifold calculus remain subsequent work.

### Actual dependent presheaf families and total objects

For a set-valued presheaf \(\Gamma\) on a category \(C\), the constructed category of elements has objects \((U,x)\) with \(x\in\Gamma(U)\). An arrow \((U,x)\to(V,y)\) consists of \(f:U\to V\) and an actual equation \(\Gamma(f)(y)=x\). The equation is a proposition by the given value sethood; base-arrow equality therefore proves equality of such arrows. Identity, composition, their laws and the element functor induced by a natural transformation are explicitly constructed.

A dependent presheaf family over \(\Gamma\) is an actual set-valued presheaf on this element category. Its total value at \(U\) is

\[
\sum_{x:\Gamma(U)} A(U,x).
\]

The ordinary dependent-sum sethood proof is supplied by the previously constructed ordinary/Cubical identity and pair bridge. Total restriction applies \(\Gamma(f)\) to the base value and the actual family restriction to the corresponding element arrow.

For an ordinary equality \(p:x=y\), a vertical element arrow goes from \((U,y)\) to \((U,x)\). Contravariance of the family gives transport from \(A(U,x)\) to \(A(U,y)\), and ordinary equality induction proves that this operation equals actual `subst`. Total identity and composition laws explicitly compare the relevant composite element arrows, then use the family's restriction laws. No dependent transport-coherence field is assumed. The total projection and its component/restriction computations are the actual first projection.

### Constructed reindexing and pullback comparison

For \(\sigma:\Delta\to\Gamma\), the induced element functor and the existing actual presheaf restriction construction define \(A[\sigma]\). Its fiber at \((U,y)\) computes to \(A(U,\sigma_U(y))\). The total lift is the concrete map \((y,a)\mapsto(\sigma_U(y),a)\); its naturality uses ordinary transport along \(\sigma\)'s naturality equation and the proved element-arrow comparison.

The total of \(A[\sigma]\) is explicitly isomorphic to the previously constructed pullback of the original total display along \(\sigma\). The forward component is

\[
(y,a)\longmapsto (((\sigma_U(y),a),y),\mathrm{refl}),
\]

and the inverse sends \((((x,a),y),e:x=\sigma_U(y))\) to \((y,\operatorname{subst}(A,e,a))\). The two inverse laws use actual dependent-pair paths and proposition-valued pullback certificates. Inverse naturality is derived through the injective actual forward comparison and its inverse equations. Both natural-transformation inverse laws, the display square, the categorical isomorphism and both projection equations are supplied. No selected family equivalence or preservation-of-pullbacks field replaces those maps.

### Sheaf admissibility, reindexing closure and the actual site

A dependent sheaf family over an input sheaf \(\Gamma\) is defined to be an actual dependent presheaf family together with sheafhood of that family's own total. This is an explicit admissibility condition on the input object. It does not assert that every dependent presheaf is a sheaf, and it does not assume the desired preservation theorem for the reindexed family.

The reindexed total is compared with the actual sheaf pullback of the input total display along \(\sigma\). The pullback's sheafhood is already constructed from the supplied input sheaves. A new generic transport theorem pushes a matching family through an actual presheaf isomorphism, glues in the target sheaf, applies the actual inverse, and fills both the restriction and uniqueness fields. Applying it to the explicit total/pullback comparison proves sheafhood of the reindexed total. Thus reindexing closure is constructed rather than made a field of the family record.

The constant unit family on the element category supplies an actual example over every context sheaf. Its total projection has the section \(x\mapsto(x,\mathtt{tt})\) and both inverse equations. The same explicit sheaf transport proves its total admissible. This inhabits the family type over every context; it does not assert that every context has a global section.

The fixed-site adapter supplies `realOpenCategory`, `realOpenGrothendieckTopology` and the existing closed `realSheafFunExt`. `RealFamily Γ` lies in `Type₃`; its fibers and total section carriers lie in `Type₂`, with actual ordinary sethood proofs. Reindexing, total/display maps, the fixed-site pullback isomorphism and all forward/inverse component formulas are retained. The generic function-extensionality input is fully supplied here, with no new extensionality postulate.

### Scope beyond these constructions

These are actual constructive analysis and set-valued dependent-family constructions over the fixed topological site. They do not provide strict substitution identity/composition coherence, a split category-with-families structure, dependent products, an internal universe classifier, or an interpretation and substitution theorem for the source language. No element-site sheaf equivalence is asserted. The general smooth/formal site, higher dependent operations, quotient/descent/properness comparison and complete external orbifold theorem remain separate obligations.

The full joint Myers-model existence question remains open. The earlier reducedness and affine-map collision for the plain Dedekind-real carrier keep their exact bounded scope; these results imply neither a universal no-model theorem nor an identification of that plain carrier with a synthetic infinitesimal line.

The implementation is Agda only. Three conaled source files at revision `c19a9ab31d0764d68752f4825554fac8e44a5e24` are retained as documentary source-inspection inputs for the dependent-family design. They supply no Lean proof dependency or build result. The separate calculus-direction note is retained as research evidence and does not enlarge the accepted theorem scope.

<a id="constructive-calculus-families"></a>

### 1. Arbitrary-function scalar calculus

`DedekindDerivativeChainRule.hasDerivativeAt-chain-rule` accepts arbitrary
`f,g : DedekindReal -> DedekindReal`, a derivative `a` of `f` at `x`, and a
derivative `b` of `g` at `f(x)`. It constructs the derivative `b * a` for
`g composed with f` at `x`. `chain-rule-derivative-unique` identifies any other
certified derivative of that composite with the same value.

`DedekindRemainderComposition` and `DedekindRemainderChainRule` supply the actual
remainder identity and estimates. Continuity of the inner function is derived
from differentiability. Positive bounds and radii remain propositionally
truncated; no choice of a modulus for every tolerance is silently extracted.
The proof does not divide by the potentially zero inner increment or decide
whether it vanishes.

`DedekindDerivativeAlgebra` supplies constant, sum and product rules for arbitrary
functions. At `x`, derivatives `a,b` of `f,g` give product derivative
`g(x) * a + f(x) * b`. `DedekindRemainderAlgebra` supplies the exact algebraic
identity, and `DedekindRemainderProductRule` estimates its cross term using a
positive rational majorant and four truncated radius witnesses. These are
constructive scalar real-line results; no multivariable or manifold theorem is
included in their signatures.

### 2. Supplied C1 maps and algebra operations

`DedekindC1Maps.C1Data f` contains an actual derivative function, derivative
certificates at every point and metric continuity of that derivative.
`isPropC1Data` proves uniqueness of the entire supplied certificate. `C1Map`
is a set, and `c1Map-ext` identifies full certified maps from pointwise equality
of their underlying functions.

`identityC1` and `composeC1` are actual constructed maps, with derivative 1 and
`(g' composed with f) * f'`. Derivative continuity, derived continuity of the
original map, and full-map left/right identity and associativity paths are
proved. The input includes the derivative function; no operation selects one
from a bare proposition asserting differentiability.

`DedekindC1Algebra` constructs `constantC1`, `addC1`, `productC1` with exact
function and derivative equations. It proves full-certified-map paths for
addition commutativity, associativity and right zero; multiplication
commutativity, associativity, right unit, right zero and left distributivity.
These paths are not a separately packaged ring or semiring record. No new
negation or division rule is supplied by these four algebra modules.
The later individually accepted `DedekindC1Category` is intentionally outside
the fixed 22-source 095 release; its acceptance requires a distinct supplement.

### 3. Actual terms, display families and dependent sums

`DependentPresheafSections` defines a term as an actual natural section of the
constructed total presheaf. It proves the section equation, extensionality,
comprehension pairing and recovery against the actual pullback comparison.
`DependentPresheafTermSections` constructs an equivalence with natural maps
from the terminal presheaf on the context's category of elements to the family.
Both directions and inverse laws are supplied.

Fiber transport is substantive here: the proof uses ordinary identity
elimination with a free endpoint, reconstruction of the actual total pair,
and sethood of the context. It does not replace the equality produced by
natural-transformation extensionality with a reflexive proof.

`PresheafDisplayFamilies` constructs the family over a presheaf from an actual
display map and compares the total with its source. `SheafDisplayFamilies`
constructs the corresponding family over a sheaf, including the actual sheaf
certificate. `DependentSheafSums.On.Sum.totalIso` identifies the resulting
sum total sheaf with the iterated total by explicit maps and inverse laws.
Its display equation is proved, and `fiber-equivalence` compares each actual
fiber with the ordinary dependent sum of the two given fibers.

These results do not establish every full sheaf-term wrapper, sum reindexing
coherence law or strict category-with-families interpretation. Each pending
packet retains its own source and native status.

### 4. Dependent presheaf products and the element site

`DependentPresheafProducts` constructs a dependent product as a local-section
presheaf. At a context element, its values are actual natural transformations
from the projection's Hom kernel into the family. Restriction is given by
composition, using the existing right Kan extension on actual presheaves.
The module constructs transpose and untranspose, their component formulas,
beta and eta, the two functors and `dependentAdjunction`. The accepted repair
specializes the adjunction proof without changing its public data or laws.

`PresheafElementSite` constructs the topology on the category of elements by
actual sieve projection/lifting and their covering laws. `ElementFamilyTransport`
and `ElementSheafMatching` construct the fiber transports and matching families
needed by `ElementSheafComparison`.

For a sheaf context and a family over its underlying presheaf,
`total-to-element-is-sheaf` and `element-to-total-is-sheaf` construct both
directions of the sheafhood comparison. The context's actual amalgamation
supplies the base of the glue, and transport aligns the fiber. The output is a
pair of implications between the two certificate types; equality or inverse
laws between large sheafhood certificates are not claimed.

This release does not accept the full sheaf-dependent-product and base-change
packets 126, 127, 129, 132, 134. Their explicit source constructions and favorable
source reviews remain useful, but a full native attempt which exhausts its
budget supplies no acceptance of the uncompleted modules. No assumed
Beck-Chevalley or sheaf-preservation field is used to fill that gap.

### 5. The exact selected-target incompatibility

`CrispCovariantYonedaEndpoints.Map.proves-equivalence` derives equivalence of
an actual crisp map from external postcomposition tests at its two endpoints.
`TinySelectedTargetLocality.Context.At.root-is-null` uses four evaluation
comparisons for one root, at domains `K`, `K x A`, `(A -> K)` and
`(A -> K) x A`, together with the displayed locality and `RealFlat` assumptions.

The nullification theorem needs two additional domains, `X` and `Null_R X`.
Consequently `TinySelectedTargetNullification` and the final incompatibility
wrapper use **six comparisons per root**, **twelve fields across two
independently supplied same-level crisp roots**. The targets are the actual
`Null_R(T -> X)` and `(T -> Null_R X)`. With finite coordinates for `(T -> R)`,
`Selected.preserves-nullification` proves equivalence of the already constructed
canonical comparison. It does not assume an unrelated comparison or a global
assignment of tiny roots.

`WeilSelectedTinyIncompatibility.Context.Selected` applies this result to the
constructed rank-15 Weil algebra and spectrum. Its context contains a crisp
commutative ring, Kock-field witness and `CrispIdentityInduction`. The displayed
reflexivity instance gives the coordinates, shape-power equivalence and its unit
computation. `CrispPullbackPreservation` supplies the endomorphism
shape-connectedness. The constructed separator contradicts this connectedness
when 3 and 4 are units; the ordered corollary derives these units from
`StrictOrder`. The full Kock-Lawvere corollary supplies the required reflexivity.

The result is a conditional theorem in its literal native `--cohesion`, crisp,
modal and same-universe signature. Exact source interpretation, modal
computation, universe correspondence and possible large-root/resizing variants
remain separate. It is not an unconditional proof that every foundation
intended by the paper, every synthetic differential geometry model or every
classical orbifold extension is impossible.

#### Five comparisons for a left inverse

For the explicit collision, injectivity of the canonical comparison already
suffices. A smaller selected-root argument constructs a left inverse. Keep
the crisp level, rules, R, its point, T and X of the existing nullification
context. Write S=Null_R(T->X), B=(T->Null_R X), and c:S->B for its actual
comparison. Choose just one same-level crisp K and a crisp evaluation
e:(T->K)->S. For each crisp Z, the comparison is the actual map
`a_Z(w)(v)=e(w o v)` under Flat.

Require its equivalence at exactly K, K x R, R->K, (R->K) x R, and X.
With RealFlat and the existing finite-coordinate equivalence
(T->R)~=(Fin n->R), S's nullity gives the powered locality used by
`TinySelectedTargetLocality`. The first four comparisons then make K
R-null. Thus restriction along X->Null_R X is an equivalence on maps to K,
also under Flat by the existing RealFlat theorem.

The fifth comparison lifts the boxed unit (T->X)->S to a member of
Flat(X->K). Inverting root restriction extends this member to
Flat(Null_R X->K). Apply the actual evaluation comparison at Null_R X to
obtain a member of Flat(B->S). Naturality proves that its restriction along
the powered unit is the original boxed unit. No invertibility at Null_R X
is used in this step.

Restriction along (T->X)->S is an equivalence on maps to S, since S is
R-null. Its injectivity, together with the computation of c on the unit,
therefore identifies the resulting composite with the boxed identity of S.
Eliminating the Flat witness constructs g:B->S with g c=id_S. Hence c is
injective. This gives a left inverse of this specified map, not a right
inverse or an equivalence, and uses no second selected root.

The generic construction is implemented in
[TinySelectedSourceRetraction](../src/Orbifolds/TinySelectedSourceRetraction.agda)
with its exact native acceptance recorded by the source ledger and raw receipt.
All selected roots and comparison domains remain
at the stated level; no larger-root replacement or resizing is inferred. Its application to
the constructed Weil collision belongs to [Joint obstruction](joint-obstruction.md#weil-tiny-incompatibility).

<a id="constant-sheaves-family-maps"></a>

### 1. The concrete locally constant sheaf

`SetValuedCoherentDescent` eliminates a truncated inhabited collection of
mutually agreeing values into the proposition consisting of a value together
with all agreement certificates. It does not choose a representative from an
arbitrary truncated inhabited set.

For a supplied `SmallSet` at the actual real site's `realSiteLevel` (`Type₂`),
`DedekindLocallyConstantSections` uses functions on the actual open's points,
with propositionally truncated local witnesses of constancy. Restriction uses
actual intersections and inclusion arrows; membership proofs are handled by
point extensionality. Empty-open sections are contractible without a label.

`DedekindLocallyConstantPresheaf`, `DedekindLocallyConstantGluing` and
`DedekindLocallyConstantSheaf` construct the actual restriction laws,
compatible matching values, amalgamation and uniqueness. Their overlap
argument uses actual meet squares and sieve down-closure. The constant-map
comparison is a natural transformation from the pointwise constant presheaf;
that presheaf is not assumed already to satisfy sheafhood.

### 2. Universal property for the actual constant presheaf

`DedekindConstantLabelSeparation` proves that equal constant sections have
equal images under a constant-presheaf map into a sheaf. Its equality sieve
covers the empty open vacuously; target separatedness collapses image values
without constructing an equality of arbitrary labels on an empty domain.

`DedekindLocallyConstantRepresentatives` supplies the actual sieve of local
constant representatives and its cover. `DedekindLocallyConstantExtension`
constructs coherent matching values on that sieve, glues them in the supplied
target sheaf, and proves representative computation and naturality.

`DedekindLocallyConstantUniversal` supplies precomposition by the constructed
constant comparison, its actual inverse extension, both inverse laws, and
the resulting hom equivalence. It composes this with the existing
`PresheafConstants` equivalence to give maps from labels into actual global
sections, with target naturality and component/local-inverse equations.

This is a proved universal property for this particular presheaf/sheaf pair.
It does not provide general sheafification of every presheaf. The label-map functor, two-variable bundled adjunction and explicit unit/counit triangles require their separate constructions and source-specific checks. No interpretation
of native `Flat`, crisp typing or source substitution follows merely from the
ordinary external constructions.

### 3. Actual family maps and total sheaves

`DependentFamilyTotalMaps` constructs the correspondence between family
natural transformations and maps of actual total presheaves commuting with
their displays. Its fixed-base construction transports output fibers along
the actual display equality and proves both inverse laws and reconstruction.
Identity and composition of total maps and the across-base comparison are
constructed from the actual pullback/reindexing data.

The fiber argument uses ordinary identity elimination and set-valued bases.
It does not claim the equality generated by natural-transformation
extensionality is reflexive. The general along-isomorphism transfer handles
the resulting transports explicitly.

`DependentSheafFamilyIsomorphisms` lifts an actual family isomorphism to an
isomorphism of the existing total sheaves. Both display equations and component
formulas are supplied. Sheaf morphisms are the actual underlying natural
transformations, so no equality of large sheafhood certificates is needed.

Only these 293- and 133-line general modules are selected. The distinct
`DependentProductBaseChange` and `DependentSheafProductBaseChange` modules
are excluded. General transfer tools do not by themselves prove the full
dependent-product comparison or its substitution coherence.

### 4. C1 endomorphisms

`DedekindC1Category` packages the already constructed set of supplied C1 maps
of the actual Dedekind real line into a single-object category. Its identity,
composition and four law aliases use the previously accepted full-map paths.
The selected small generic constructor changes how the record is assembled,
without replacing its mathematical data or laws.

This is an endomorphism category of the real line. No category of manifolds,
multivariable calculus or C1 ring/semiring structure is packaged by this file.

### Interpretation and release boundaries

The precise joint original-branch signature and its conditional incompatibility
are detailed in [Joint obstruction](joint-obstruction.md). A complete original-foundation model, exact crisp/cubical
source interpretation, universe correspondence and substitution theorem are
still separate obligations. No universal no-model theorem is asserted.

These constant-sheaf and family-map results alone do not establish the full
dependent sheaf product/base-change interpretation, strict coherence,
semantic universes, smooth/formal and manifold semantics, higher descent,
or external properness. The current source-by-source acceptance boundary
is maintained in `../state.json`, not inferred from this mathematics note.

