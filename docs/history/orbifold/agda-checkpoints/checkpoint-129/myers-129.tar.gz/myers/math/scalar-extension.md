# Scalar extension

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="tensor-algebra"></a>

### 1. Precise claim and assumptions

Let `R` be a commutative semiring with a set-valued carrier. A commutative
`R`-algebra is represented by an actual `R`-semimodule, an actual bilinear
multiplication, a specified unit, and the associativity, commutativity,
and unit laws. Additive distributivity, absorption of zero, and scalar
compatibility are then consequences of the bilinearity fields. No field
asserts any property of a subsequently constructed tensor object.

For the intended ring case, supply additive inverses on `R`. Every
semimodule over it has constructed inverses `v ↦ (-1) • v`. Thus all
algebras and algebra maps in the construction become commutative rings
and ring maps; negative preservation is a consequence of linearity.
The semiring formulation does not silently call an arbitrary semiring
a ring.

Fix a parameter algebra `A`, an index set `I` with displayed decidable
equality, weak function extensionality at the displayed universe level,
and the displayed propositional double-negation-elimination parameter
needed by the earlier finite-support summation construction. Supply an
actual linear basis equivalence

\[
  b:F_R(I)\simeq_R A.
\]

For every commutative `R`-algebra `W`, the earlier `BasedExtension` gives
the literal carrier and module

\[
  T_A(W)=\operatorname{FS}_I(W),
  \qquad a\otimes w=\operatorname{pure}(b^{-1}(a),w),
\]

and the actual module tensor universal property. The new construction
puts a commutative algebra structure on this same carrier, with

\[
  (a\otimes w)(a'\otimes w')=aa'\otimes ww',
  \qquad 1=1_A\otimes1_W.
\]

It constructs the factor algebra maps, proves the algebra coproduct
property, and upgrades the existing actual coordinate maps `1⊗h` to
algebra maps. For a displayed original pullback square of algebra maps,
the existing underlying-set equivalence is used to obtain an algebra
isomorphism of the actual extended comparison. Both it and its inverse
respect the specified parameter map from `A`.

No post-extension pullback property, tensor multiplication, tensor ring
law, algebra-coproduct property, or inverse algebra-map property is a
parameter. The only basis assumption concerns the original parameter
module. General existence of bases, the real field, formal-locus
interpretations, smooth operations, and semantic soundness remain outside
this algebra construction.

### 2. The actual module of linear maps

`LinearHomSemimodule.Hom` takes ordinary semimodules `M,N` and constructs
`Hom_R(M,N)` using the existing type of a function together with its
linearity equations. Its zero, addition, and scalar multiplication are
the literal pointwise operations:

\[
  0(m)=0,\qquad(f+g)(m)=f(m)+g(m),\qquad(rf)(m)=r f(m).
\]

Closure under addition uses the additive interchange law. Closure under
scalar multiplication uses commutativity of `R` to exchange two scalar
actions. The linearity properties are propositions because the target
is a set. The earlier proof that weak function extensionality preserves
function-space sethood therefore proves sethood of the actual linear-map
carrier. The semimodule axioms hold pointwise.

Evaluation at a specified element is a constructed linear map. Currying
and uncurrying are actual functions between bilinear maps and linear maps
into this constructed Hom module; their inverse equations are provided.
They do not assume a closed monoidal category. The usual external
counterpart is [Stacks, Section 10.12, Lemma 10.12.8](https://stacks.math.columbia.edu/tag/00CV).
Here the operations and equations needed for currying are supplied in the
ordinary source itself.

### 3. Constructing multiplication by the tensor universal property

The generic `Construction` module is parameterized by the independently
available **module** tensor universal property and its actual pure-map
computation. This generic parameter is discharged by the final
`BasedAlgebras.WithBasis.On` instantiation using the previously constructed
`BasedExtension` universal property. It is not the algebra property being
proved.

Write `T=T_A(W)`. For fixed `a∈A,w∈W`, form the bilinear map

\[
  (b,z)\longmapsto ab\otimes wz.
\]

The module tensor universal property extends it to an actual linear map

\[
  L_{a,w}:T\to T,
  \qquad L_{a,w}(b\otimes z)=ab\otimes wz.
\]

Next, prove that `(a,w)↦L_{a,w}` is bilinear with values in the constructed
module `Hom_R(T,T)`. For example,

\[
  L_{a+a',w}=L_{a,w}+L_{a',w}
\]

is an equality of actual linear maps. It follows by evaluating both
sides on `b⊗z`, distributing multiplication in `A`, using bilinearity
of `pure`, and invoking uniqueness in the module tensor universal
property. Zero and scalar laws, and the laws in the `W` variable, are
proved by the same explicitly supplied operations and paths.

A second application of that universal property now produces

\[
  L:T\longrightarrow\operatorname{Hom}_R(T,T).
\]

Define multiplication by evaluation: `s*t=L(s)(t)`. Currying supplies
linearity in the first argument, and each value of `L` is itself a
linear map, supplying linearity in the second argument. The pure-product
formula follows from the two proved extension computation equations.

This construction extends bilinear maps twice. It does not assert that
every tensor is itself pure, choose a sum presentation of every tensor,
or introduce an operation merely by stating the desired formula.

#### Laws on the whole carrier

Two linear maps out of `T` are equal when they agree on every `a⊗w`.
Applying this fact twice proves the corresponding uniqueness statement
for bilinear maps on `T×T`. The checked module uses that statement to prove
commutativity from the pure-product formula and commutativity in `A,W`.

For associativity, each side is linear in each of its three arguments.
One use of linear uniqueness and two uses within the bilinear uniqueness
lemma reduce the equation to

\[
  ((ab)c)\otimes((uv)w)=a(bc)\otimes u(vw),
\]

which follows from the actual associativity laws in `A,W`. The complete
path also includes the pure-product computation on both nested products.
The unit equation is proved by linear uniqueness using the pure unit
calculation. Distributivity and zero absorption are extracted from the
already constructed bilinearity proofs when forming the semiring.

The generic universal-property equality proofs are `abstract` in the
checked source. This is an elaboration boundary, not a mathematical assumption:
their proof terms are provided, while later clients need not normalize the
large previously constructed tensor equivalence proof.

### 4. The algebra coproduct, not just a multiplication

The factor maps are the literal functions

\[
  i_A(a)=a\otimes1_W,
  \qquad i_W(w)=1_A\otimes w.
\]

Their linearity, unit preservation, and multiplication preservation are
proved. The same pure computation gives

\[
  i_A(a)i_W(w)=a\otimes w.
\]

For actual algebra maps `f:A→B` and `g:W→B` into a commutative algebra,
the map `(a,w)↦f(a)g(w)` is bilinear. Its unique module-linear extension
`h:T→B` is proved multiplicative by comparing two bilinear maps on pure
pairs. The key step is the ordinary multiplicative interchange law

\[
  (f(a)f(b))(g(v)g(w))=(f(a)g(v))(f(b)g(w)),
\]

derived from associativity and commutativity in `B`. Unit preservation
and both restriction equations are also proved.

If another algebra map has the same restrictions, multiplication
preservation and `i_A(a)i_W(w)=a⊗w` force agreement on every pure tensor.
The module universal property gives equality of its linear maps. The
candidate `algebra-hom-path` upgrades this to equality of actual algebra
maps, using propositionhood of the unit and multiplication equation
fields. Thus `Coproduct.unique` is an equality of algebra homomorphisms,
not merely a carrier-level observation.

This is the coproduct in commutative `R`-algebras. It is not by itself
an identification with a `C∞`-algebra coproduct. That latter comparison
requires the separate smooth/Taylor argument at formal stages.

### 5. Actual tensor maps and the parameter algebra

For an actual algebra map `h:W→V`, the new `BasedAlgebras.Map` keeps the
existing coordinate function

\[
  T_A(h)(u)_i=h(u_i).
\]

Its existing linearity and pure-map equation are reused. Multiplication
preservation is proved by comparing two bilinear maps on pure pairs:
the image of a product and the product of the images. On pure tensors,
the calculation uses exactly `h(ww')=h(w)h(w')`. Unit preservation follows
from the pure-map equation and `h(1)=1`.

The theorem `respects-parameter` additionally proves

\[
  T_A(h)(a\otimes1_W)=a\otimes1_V.
\]

Consequently this is the actual map of algebras equipped with their
specified maps from the parameter algebra `A`, not an unnamed algebra
map on isomorphic carriers.

### 6. The literal algebra pullback

For algebra maps `f:B→E` and `g:C→E`, `AlgebraPullback` uses exactly the
carrier already used by `FiniteSupportPullbacks` and `TensorSquare`:

\[
  P=\sum_{b:B}\sum_{c:C}\bigl(g(c)=f(b)\bigr).
\]

Zero, sum, scalar action, unit, and product have their actual coordinate
definitions. For instance, multiplication sends `(b,c,p),(b',c',q)` to
`(bb',cc',r)` where the supplied compatibility proof is the path

\[
  g(cc')=g(c)g(c')=f(b)f(b')=f(bb').
\]

Sethood of `E` makes the compatibility equation proposition-valued.
This gives equality of pullback elements from equality of both
coordinates, and proves sethood of the pullback carrier. All module and
algebra laws follow using those actual coordinate equalities.

The two projections are constructed algebra maps. A commuting cone
`D→B,D→C` gives the literal comparison

\[
  d\longmapsto(u(d),v(d),\operatorname{commute}(d)).
\]

It is proved to be an algebra map, and equality on the two projections
proves its uniqueness as an algebra map. This is the explicit algebra
pullback construction. The standard external set-underlying description
is also recorded in [Stacks, Section 4.7](https://stacks.math.columbia.edu/tag/0020).

### 7. The actual extended comparison and its inverse

`FiniteSupportAlgebraSquare.WithParameter.WithBasis.Square` takes a
commuting square of actual algebra maps. Its only pullback premise is

\[
  \operatorname{isEquiv}\bigl(d\mapsto(u(d),v(d),\operatorname{commute}(d))\bigr)
\]

for the **original** square. `TensorSquare` supplies equivalence of the
extended underlying comparison from this premise. The new algebra
construction supplies the same four extended maps as algebra maps and
forms their actual algebra pullback.

The proof `comparison-agrees` identifies the two comparison functions
using equality of the two coordinate legs. This deliberately does not
require their compatibility-proof witnesses to be definitionally equal.
`homotopy-isEquiv` transfers the proved equivalence to the literal
algebra comparison map, preserving its actual legs.

The generic `CommutativeAlgebraCore.Inverse` then constructs the inverse
algebra map from this actual forward algebra map and its underlying
equivalence. Let `k:X→Y` be that forward map and `q:Y→X` its constructed
inverse. Injectivity of `k` proves, for example,

\[
  q(y+y')=q(y)+q(y')
\]

because applying `k` gives equality by the inverse section and the
already proved additivity of `k`. The checked module supplies the corresponding
paths for zero, scalar action, unit, and multiplication. It does not
accept these inverse preservation laws as fields. Both inverse equations
are retained from the actual underlying equivalence.

Thus the resulting `AlgebraIso` has the actual comparison as its forward
map. Separate computation theorems expose its actual first and second
tensor legs.

The final file also constructs the parameter map into the pullback from
the two factor parameter maps. Both the comparison and its inverse
respect that specified cone. The inverse compatibility follows by
applying the actual forward injection to its section equation followed
by the inverse of the forward parameter-compatibility equation.

### 8. Ring specialization and the remaining boundary

`CommutativeAlgebraCore.RingConsequences` constructs additive inverses
on each algebra when `R` is a commutative ring. The actual proof is

\[
  (-1)\cdot v+v
   =(-1)\cdot v+1\cdot v
   =((-1)+1)\cdot v
   =0\cdot v=0.
\]

`RingMapConsequences` proves preservation of this negation by every
constructed algebra map using its scalar-preservation equation. In
particular, both sides of the tensor comparison are actual commutative
rings and both inverse directions are ring homomorphisms. The general
semiring theorem therefore yields the requested ring isomorphism when
the intended coefficient ring is supplied.

The algebra construction supplies multiplication/coproduct structure and the passage from the underlying comparison to an algebra isomorphism. The following requirements remain outside this construction:

1. Instantiation of the intended real field and actual parameter
   algebras, including their basis data or a separately proved basis
   existence theorem with its choice assumptions.
2. A complete finite-Weil category with its finite-dimensionality,
   augmentation, locality, nilpotence, and morphism data. The generic
   algebra construction neither assumes nor proves these extra properties.
3. Identification of the actual ordinary algebra tensors with smooth
   formal-stage function algebras, including naturality and Taylor
   operations. An algebra coproduct alone does not prove this.
4. The site, sheaves, universes, dependent type operations, quotient
   interpretation, and the source-to-model soundness/transfer theorem.
   The present construction is an ingredient of that larger task.

An independent read-only review by the smooth branch examined all six
constructions, including the two-UP construction, the literal pullback,
the parameter-cone assembly, and the concrete first-order adapter. It found no mathematical circularity. This
review is useful evidence about the construction's design and supplied
proof paths; it does not replace the native gates.

### 9. Concrete first-order application without a pullback premise

The final small `FirstOrderWeilTensorAlgebra` adapter uses the accepted
square-zero constructions

\[
  D=R\oplus R\epsilon,\qquad
  D(2)=R\oplus R\epsilon_1\oplus R\epsilon_2,
\]

where every product of infinitesimal directions is zero. It wraps the
already supplied multiplication, scalar-compatibility, and ring-map
equations as the `CommutativeAlgebra` and `AlgebraHom` data required above.
It does not assert new ring laws merely to fit an interface.

The coefficient algebra is the actual regular module of `R`, with its
ordinary multiplication; its bilinearity is proved from the supplied
semiring laws. The two arrows `D(2)→D` use the actual first and second
coordinate projections and their already proved linear and multiplicative
laws. The two arrows `D→R` use the actual augmentation and its already
proved equations.

`FirstOrderWeilSquare.comparison-isEquiv` supplies the original equivalence
by its explicit coordinate inverse. A homotopy identifies that literal
comparison with the adapter's algebra-square comparison. Thus the final
`Application` has **no original pullback premise**: the only remaining
inputs are the coefficient semiring, parameter algebra, basis, and the
displayed finite-support logic parameters.

The output is the actual algebra isomorphism

\[
 T_A(D(2))\ \simeq\
 T_A(D)\times_{T_A(R)}T_A(D),
\]

with the actual tensor projection legs, and forward and inverse
compatibility with the specified parameter algebra. It specializes to a
ring isomorphism when `R` is a ring.

The base of this displayed pullback is literally `T_A(R)=A⊗_R R`.
This adapter does not silently replace it by `A`. The separate
`FirstOrderWeilBasedTensor` work identifies the actual extended
augmentations to `A` and supplies the corresponding underlying-set
comparison using base transport. Upgrading that separately specified
base change to an algebra-level comparison is a distinct statement,
unless its actual base map is also supplied or proved to be an algebra
isomorphism. No such additional identification is claimed by this
adapter's type.

### 10. Native integration: checked opacity without new assumptions

The original candidate source retained too much transparent computation
when the generic proof was instantiated at a concrete basis. The generic
construction itself checked; some concrete exported equations caused
expansion of the complete finite-support tensor evaluator. The integration
made three local changes while preserving the mathematical construction.

First, `BasedAlgebras` now uses explicitly typed, qualified exports in
place of whole nested module copies. The basis type, actual extension,
pure maps, algebra operations, coproduct results, and map compatibility
remain available. The small `Map0` namespace contains the actual typed
tensor map rather than copying the whole tensor-map implementation.

Second, `Construction.product-bilinear` is abstract after being defined
as the constructed `C.uncurry curried-product`. In the same abstraction
block, the source proves

```text
product-bilinear-computation :
  product-bilinear ≡ C.uncurry curried-product
product-bilinear-computation = refl
```

The pure-product theorem evaluates that checked equality and then uses
the two tensor extension computation laws. The operation therefore remains
the one actually constructed; the checker is prevented from repeatedly
expanding it while checking unrelated concrete exports. This is not an
extra multiplication field or an assumed pure-product law.

Third, `Construction.Coproduct.extension` is abstract after being defined
as `UB.extension pairing`. The source proves its computation equality by
`refl` in that same block, then derives `extension-on-pure` by evaluating
the equality and applying the existing tensor UP computation theorem.
Multiplication preservation, unit preservation, both restrictions, and
full algebra-map uniqueness all use that proved equation. None is dropped
or replaced by an input.

These abstraction boundaries alter elaboration visibility, not the input
hypotheses or the existence of the actual definitions. All definitions
and computation equalities were checked under the unchanged safe flags.

<a id="scalar-extension"></a>

### 1. Finite support without choosing support lists

For an index type `I`, a pointed type `(V,0)`, and a function `w : I → V`, define

\[
\operatorname{Bound}(w,L)
  :=\prod_{i:I}(i\notin L\to w_i=0),
\qquad
\operatorname{Supported}(w)
  :=\neg\neg\sum_{L:\operatorname{List}(I)}\operatorname{Bound}(w,L).
\]

The carrier `FiniteSupport I 0` consists of a function and this double-negated witness. The support predicate is a proposition, using the displayed function-extensionality parameter. Equality of underlying functions therefore gives equality of finite-support elements. This is a small, explicit representation; it is not silently treated as a quotient or as a propositional truncation with an unstated elimination rule.

In a classical set interpretation it is the usual finite-support condition. In the Agda development, its use remains governed by the actual definitions. In particular, a double-negated support list cannot be extracted to evaluate an arbitrary finite sum.

#### Actual pullbacks

`FiniteSupportPullbacks.Preservation` takes pointed maps `f : V → Z` and `g : W → Z`, their zero-preservation proofs, function extensionality, and sethood of `Z`. Its pullback is the actual type

\[
P=\sum_{v:V}\sum_{w:W}(g(w)=f(v)).
\]

It constructs the literal comparison

\[
\mathrm{FS}_I(P)\longrightarrow
\mathrm{FS}_I(V)\times_{\mathrm{FS}_I(Z)}\mathrm{FS}_I(W)
\]

by applying the two projections coordinatewise. Its inverse pairs the already specified coordinate functions, obtaining each compatibility equation by evaluating the given equality of functions at that coordinate. The concatenation of two support lists bounds the paired function. Applying double-negation functoriality twice proves support of that function without selecting either support list.

Both inverse equations are proved. This module does not require excluded middle, double-negation elimination, decidable equality on `I`, a field, or an additive structure. The subsequent `Square` module proves the actual extended comparison for any original pointed square whose actual original comparison is an equivalence. Preservation after extension is a theorem, not an input field.

### 2. Actual sums and the scope of classical logic

`FiniteSupportSums` adds an additive commutative monoid with a set-valued carrier, decidable equality on `I`, and the explicit parameter `PropositionalDNE ℓ`.

The list evaluator visits a coordinate once and erases it before visiting the remaining list:

\[
\operatorname{listSum}([],w)=0,
\qquad
\operatorname{listSum}(i::L,w)
 =w_i+\operatorname{listSum}(L,\operatorname{erase}_i w).
\]

Consequently duplicate indices do not contribute twice. A proved extraction identity and induction show that any two support lists give the same value.

The actual sum is constructed through the type

\[
\operatorname{SumValue}(w)
 =\sum_{n:V}\prod_L
    \bigl(\operatorname{Bound}(w,L)\to\operatorname{listSum}(L,w)=n\bigr).
\]

Given the double-negated support witness, any two proposed sum values are equal: a support witness would identify both with its list sum, and DNE eliminates the resulting double negation into the proposition expressing equality in the set `V`. The equation data are also propositional. Thus `SumValue(w)` is a proposition. A given support witness constructs an inhabitant, so double-negation functoriality gives `¬¬ SumValue(w)`; propositional DNE then gives its unique inhabitant.

This is the precise classical step. No support list is selected from its double negation. Later proofs eliminate double-negated support only into equality propositions. The `Sum` implementation and its unique-value proof are abstract behind the proved computation interfaces `sum-on-bound`, `sum-zero`, `sum-add`, and `sum-single`.

The original ordinary orbifold core is not changed to assume DNE. These classical parameters belong to this separate external algebra construction. Decidable equality on the index is also displayed; an external classical interpretation with a set-valued basis index can supply it. Neither parameter asserts that all internal geometric objects have decidable equality.

### 3. Direct sums, free modules, and the tensor universal property

`FiniteSupportUniversal` defines actual additive homomorphisms as functions with their preservation equations. It proves

\[
\operatorname{AddHom}(\mathrm{FS}_I(M),N)
 \simeq\prod_{i:I}\operatorname{AddHom}(M,N).
\]

Restriction evaluates a homomorphism on a single-coordinate injection. Extension takes the constructed sum of the coordinate images. The inverse equations follow from evaluation on single-coordinate elements and an induction using the proved coordinate-splitting equation. This is a universal property of the constructed carrier, not a desired equivalence supplied as data.

`FiniteSupportModules` defines commutative semirings, semimodules, and actual linear maps. A commutative semiring suffices for this part; additive inverses and a field structure are unnecessary for a free first factor. Coordinatewise operations make finite-support functions a semimodule. The additive extension is proved linear by uniqueness on its single-coordinate generators. This gives

\[
\operatorname{Lin}_R(\mathrm{FS}_I(M),N)
 \simeq\prod_{i:I}\operatorname{Lin}_R(M,N).
\]

`FiniteSupportTensor.FreeModule` constructs

\[
F_R(I)=\mathrm{FS}_I(R)
\]

and proves its free-module universal property by evaluating a linear map on the coordinate generators with coefficient `1`:

\[
\operatorname{Lin}_R(F_R(I),N)\simeq(I\to N).
\]

`FiniteSupportTensor.Tensor` then constructs the tensor candidate

\[
T_I(M)=\mathrm{FS}_I(M),
\qquad
\operatorname{pure}(a,m)_i=a_i\cdot m.
\]

Both variables of `pure` are proved linear. For every target semimodule `N`, the module proves

\[
\operatorname{Lin}_R(T_I(M),N)
 \simeq\operatorname{Bilin}_R(F_R(I),M;N).
\]

The forward map is the literal operation `h ↦ ((a,m) ↦ h(pure(a,m)))`. The backward map extends the family `m ↦ b(e_i,m)` using the already proved linear direct-sum property. Both inverse equations are proved, first on the free generators and then by their universal property. This identifies the carrier with `F_R(I) ⊗_R M` by the defining tensor universal property.

The conventional bilinear definition and tensor universal property are recorded in the primary reference [Stacks, Section 10.12, Definition 10.12.1 and Lemma 10.12.2](https://stacks.math.columbia.edu/tag/00CV). The Agda construction proves the corresponding property for this free-factor representation; it does not import that result as an axiom.

### 4. The actual tensor maps

For an actual linear map `h : M → N`, `FiniteSupportTensor.TensorMap` defines

\[
T_I(h)(w)_i=h(w_i).
\]

It proves linearity and the equation

\[
T_I(h)(\operatorname{pure}(a,m))
 =\operatorname{pure}(a,h(m)).
\]

It also proves that the tensor universal property's forward map sends this coordinate map to that exact induced bilinear map. Thus the comparison below uses the actual maps `1 ⊗ h`. It is not merely an equivalence between unrelated sets having the right names.

### 5. A displayed basis for the scalar parameter

`FiniteSupportScalarExtension.BasedExtension` takes an actual parameter semimodule `A` and a displayed linear equivalence

\[
b:F_R(I)\simeq_R A.
\]

The data contain linear maps `realize` and `coordinates`, together with both pointwise inverse equations. This is the only basis input. It is not a field asserting that scalar extension preserves the square being considered.

The same carrier `T_I(M)` represents `A ⊗_R M`, with

\[
\operatorname{pure}_A(a,m)
 =\operatorname{pure}(b^{-1}(a),m).
\]

Precomposition with `b` and `b^{-1}` gives a proved equivalence between the two bilinear-map types. Composing it with the tensor universal property proves

\[
\operatorname{Lin}_R(T_I(M),N)
 \simeq\operatorname{Bilin}_R(A,M;N),
\]

and the forward map is verified to be evaluation on this literal `pure_A`.

For an arbitrary real vector space, existence of a basis is classical external mathematics here. [Stacks, Lemma 9.4.1](https://stacks.math.columbia.edu/tag/09FN) states the standard field-module freeness result. The current Agda modules neither prove general basis existence nor conceal a choice principle in `PropositionalDNE`. Supplying a basis of the intended parameter vector space remains an explicit requirement. A constructive use can instead supply an independently constructed basis.

### 6. Augmentations and base compatibility

For an actual linear augmentation `ε : M → R`, the extended augmentation is the actual linear map

\[
\varepsilon_A:T_I(M)\longrightarrow A,
\qquad
\varepsilon_A(w)=b\bigl(i\mapsto\varepsilon(w_i)\bigr).
\]

The module proves

\[
\varepsilon_A(\operatorname{pure}_A(a,m))
 =\varepsilon(m)\cdot a.
\]

Commutativity of scalar multiplication is used explicitly when converting the coordinate product to this scalar action on `A`. For `h : M → N` with a specified equation `ε_N ∘ h = ε_M`, the code proves

\[
\varepsilon_{N,A}\circ T_I(h)=\varepsilon_{M,A}.
\]

Hence the chosen zero/base maps and the two augmentation routes are visible. The preservation theorem does not discard the base conditions needed for later based lifting statements.

### 7. The four-vertex theorem and its geometric use

Let linear maps form a specified commutative square

\[
D\xrightarrow{u} B,\quad D\xrightarrow{v} C,
\quad B\xrightarrow{f} E,\quad C\xrightarrow{g} E,
\qquad g\,v=f\,u.
\]

The original comparison is the literal map

\[
\kappa(d)=(u(d),v(d),g(v(d))=f(u(d))).
\]

Assuming `isEquiv κ` states that this original square is a pullback. `FiniteSupportScalarExtension.TensorSquare` then proves equivalence of the actual map

\[
\kappa_A:A\otimes_R D\longrightarrow
 (A\otimes_R B)\times_{A\otimes_R E}(A\otimes_R C),
\qquad
w\longmapsto((1\otimes u)w,(1\otimes v)w,\ldots).
\]

The proof reuses the previously constructed coordinate pullback inverse. The tensor universal properties and induced-map equations identify every object and arrow with the tensors displayed in this formula. No post-extension comparison is an input.

For a finite-Weil algebra pullback `D = B ×_E C`, the intended contravariant formal-locus square has vertices `ℓE`, `ℓB`, `ℓC`, and `ℓD`. At a context `T = U × ℓW₀`, put `A = C∞(U) ⊗_R W₀`. If the model supplies the actual natural identifications

\[
\operatorname{Maps}(T\times\ell W,j\mathbb R)
 \simeq \operatorname{underlying}(A\otimes_R W),
\]

compatible with all four algebra maps and their augmentations, the proved `κ_A` is exactly the real-line four-vertex comparison. These identifications are the remaining semantic bridge; they are not consequences of naming the module tensors after formal function algebras.

### 8. Precise remaining boundary

The tensor-algebra construction supplies the additional algebra structures and comparisons described above. None of those ordinary algebra constructions alone supplies a smooth semantic model.

1. **The intended field and parameter spaces.** Instantiate a nontrivial real field and the actual real vector spaces used for `C∞(U)` and finite Weil algebras. Supply the basis of the actual parameter module, or formalize the relevant basis-existence theorem with its choice assumptions.

2. **Algebra structure and finite-Weil data.** The separate tensor-algebra branch supplies the commutative algebra multiplication and its compatibility with actual tensor maps; its native integration is tracked independently. A chosen model must still identify its algebra tensor/coproduct with the represented module tensor and formalize the category of finite-dimensional augmented local algebras with nilpotent augmentation ideal. The constructed symbolic square-zero examples do not constitute that complete category.

3. **Identifying the model's algebra pullbacks.** The first-order example already supplies its actual coordinate inverse, and the separate algebra branch constructs actual algebra pullbacks. For a model's complete test family, identify each claimed algebra pullback with the actual underlying comparison used by the theorem, retaining its maps. The original-pullback premise is not a substitute for constructing the model's claimed test diagrams.

4. **Formal points and smooth operations.** Construct or formalize the formal-locus interpretation, including the smooth/Taylor operations that identify functions on `U × ℓW` with the appropriate Weil extension of `C∞(U)`. The module tensor universal property proved here, and any ordinary algebra tensor construction in the separate branch, do not themselves establish a `C∞`-algebra coproduct identification.

5. **Naturality and the internal mapping comparison.** Prove the displayed real-line identification naturally in contexts and Weil maps. Then identify its four legs with the literal mapping comparison expected by `DerivedAtlasOrbifold`. Pointwise agreement of object names is insufficient.

6. **Manifolds and the rest of the ambient semantics.** Extend the real-line calculation to Euclidean spaces, opens, and manifolds with the required descent. Supply the model's limits, dependent constructions, effective atlases, locality, and formal-étale interpretation actually used by the retained theorem. This is the semantic construction and transfer requested by the user, not an optional editorial assertion.

The scalar-extension theorem therefore closes a substantive algebraic gap while leaving a sharply stated model-construction boundary. It supplies no evidence for the blanket assertion that no semantic model could connect an orbifold-like internal theory to external geometry; that question must be assessed against the exact interpretation and hypotheses being claimed.

### 9. Comparison with another tensor implementation

The module `TensorRepresentations` states the tensor universal property with its actual bilinear pure map, an extension operation, its pure-tensor equation, and uniqueness of linear maps agreeing on pure tensors. It derives the usual hom-set equivalence from those data and constructs the record for the finite-support tensor using the already proved native tensor theorem. The record contains no preservation assertion.

For any two proved tensor representations of the same pair of modules, it constructs a canonical linear equivalence. Its forward map sends each specified pure tensor to the corresponding pure tensor in the second representation; the inverse has the converse property. Both inverse laws follow by direct uniqueness on pure tensors. It also proves naturality: for an actual linear map of the second factors, the canonical equivalences commute with the actual induced tensor maps.

This closes a potential interpretation ambiguity. A future algebraic or smooth construction that proves the ordinary tensor universal property does not need to assume an arbitrary equivalence with our coordinates or an arbitrary comparison of maps. Those equivalences and map compatibilities can be derived. Proving that the future construction has that universal property remains necessary.

### 10. The explicit first-order square

The separate first-order branch constructs the dual numbers and the first-order plane by coordinates. Writing `D = R ⊕ Rε` and `D(2) = R ⊕ Rε₁ ⊕ Rε₂`, every product of infinitesimal directions vanishes. The maps from `D(2)` to the two copies of `D` retain the scalar coordinate and one chosen infinitesimal coordinate. The two augmentations from `D` both retain the scalar coordinate. The original comparison and its coordinate inverse are constructed, with the algebra and module maps checked separately by that branch.

The native-accepted module `FirstOrderWeilTensor` instantiates the generic tensor theorem with precisely those modules and maps. Its input pullback proof is the explicitly constructed first-order comparison, not a new preservation or equivalence field. Initially its target is the pullback over the constructed tensor `A ⊗_R R`. It retains both tensor projection maps, proves their pure-tensor formula, and proves that both projection-augmentation routes equal the direct augmented map from the plane.

Two further native-accepted modules make the base identification explicit. `PullbackBaseChange` constructs an equivalence of actual pullbacks along an equivalence of their common bases, allowing the target maps to agree with the composites by specified equations. `FirstOrderWeilBasedTensor` applies it to the displayed basis and the proved augmentation evaluation equations. It then proves equivalence of the literal pair of tensor projection maps into the pullback of the actual augmentations to `A`. The conclusion is

\[
A\otimes_R D(2)\simeq
(A\otimes_R D)\times_A(A\otimes_R D)
\]

for any parameter `A` with a displayed linear basis. The actual comparison's compatibility path is the proved second augmentation route followed by the inverse of the first route. Equality with the comparison obtained by base change uses sethood of the target base; neither route nor base identification is omitted.

This is a specified nontrivial infinitesimal test when the coefficient unit differs from zero. The over-`A` theorem here is an equivalence of the actual underlying pullback types with the actual augmentation maps. It should not be relabelled as an algebra isomorphism over `A` without the corresponding algebra structures and laws. Instantiating the coefficient semiring with the actual real field, constructing the smooth model, and identifying its formal real-line values remain distinct tasks.

<a id="first-order-weil-square"></a>

### Result boundary

The four modules below construct the dual-number algebra and the first-order
two-direction algebra, their actual coordinate pullback comparison, finite
bases, and the unit/local-ring criterion over field coefficients. The desired
pullback property, square-zero law, finite basis and locality conclusion are
proved rather than installed as input fields.

### The independently constructed algebra

Let `R` satisfy the ordinary `CommutativeSemiring` laws and let `M` be an
`R`-semimodule. `SquareZeroAlgebra.Extension` defines the carrier `R x M`,
componentwise addition and scalar multiplication, and

\[
 (r,m)(s,n)=(rs,rn+sm),\qquad 1=(1,0).
\]

The module constructs the full commutative-semiring record for these
operations. Associativity expands the second coordinate using the module
laws and commutativity of the coefficient multiplication. Distributivity
is likewise derived from scalar distributivity and additive interchange.
Multiplication by each fixed element is proved linear over `R`.

The augmentation `(r,m) -> r` and scalar inclusion `r -> (r,0)` are actual
semiring homomorphisms; the augmentation is also linear. Multiplication by
the scalar inclusion agrees with the displayed scalar action. For every
`m,n`, the product `(0,m)(0,n)` is proved zero. The stronger theorem
`kernel-product-zero` proves the same for arbitrary elements whose actual
augmentations are zero.

For a supplied ordinary linear map `h : M -> N`, the map
`(r,m) -> (r,h(m))` is constructed and proved to be both linear and a
semiring homomorphism. Its compatibility with augmentation is reflexive.
This is the source of the two coordinate projections in the concrete
square.

The construction and its product-sethood proof use ordinary identity
elimination. They need no function extensionality, excluded middle,
choice of basis, field axiom, or abstract limit-preservation premise.

### The concrete square and its actual maps

`FirstOrderWeilSquare.Construction R` sets

\[
 D=R\oplus R\epsilon,\qquad
 D(2)=R\oplus R\epsilon_1\oplus R\epsilon_2.
\]

Their elements are the literal pairs `(r,u)` and nested pairs `(r,(u,v))`.
Their operations come from the preceding construction. In particular,
all products of two infinitesimal directions vanish, including the mixed
products. This `D(2)` is a first-order plane; it is not the truncated
polynomial algebra with a nonzero mixed product, nor an algebra of
second-order powers of one direction.

The two maps from `D(2)` to `D` are

\[
 \pi_1(r,u,v)=(r,u),\qquad \pi_2(r,u,v)=(r,v).
\]

Both are linear and unital semiring homomorphisms. They preserve the
scalar inclusions and commute with the augmentations. The comparison to
the **literal underlying pullback** is

\[
 c(r,u,v)=((r,u),((r,v),\mathrm{refl})).
\]

The pullback contains pairs `((r,u),((s,v),p))` with `p : s = r`.
Its inverse is explicitly

\[
 a((r,u),((s,v),p))=(r,u,v).
\]

The equation `a(c(z))=z` is reflexive. The other inverse law uses the
displayed equality `p` to identify the scalar coefficients and sethood of
`R` to identify the equality witnesses. The theorem
`comparison-isEquiv` is obtained from these constructed inverse data;
no equivalence of the original square is supplied by a caller.

The pullback is also equipped with its literal coordinatewise zero, one,
addition, multiplication and scalar action. Their laws are proved on
both projections, using a proved pullback path principle and pullback
sethood. Both `c` and `a` are proved linear and semiring homomorphisms for
those actual operations. In the multiplicative law for `a`, the stored
matching equations explicitly replace the second scalar coefficients by
the first; this compatibility is not assumed by transporting an
unspecified algebra structure.

For any actual cone of functions with matching augmentations, the module
also constructs its lift through `D(2)`, proves the two projection
equations, and proves pointwise uniqueness. Thus the comparison is the
one determined by the displayed square.

The elements

\[
 \epsilon=(0,1),\quad \epsilon_1=(0,1,0),\quad
 \epsilon_2=(0,0,1)
\]

have square zero, and both mixed products in `D(2)` are zero. If
`1 != 0` in `R`, the three displayed elements are nonzero in their
respective algebras, and the two plane directions are distinct. This
is an actual nontrivial infinitesimal algebra example over any
nontrivial field, including the real field.

### Finite bases are constructed

`FirstOrderWeilCoordinates.FiniteCoordinates` constructs the pointwise
coordinate semimodule on `Fin n -> R`. It constructs the coordinate and
realization functions for `n = 2` and `n = 3`, proves both functions
linear, and proves their actual inverse laws:

\[
 D\simeq R^{\operatorname{Fin}(2)},\qquad
 D(2)\simeq R^{\operatorname{Fin}(3)}.
\]

These are the specified coefficient maps, rather than unnamed vector
space isomorphisms. The module proves the expansions

\[
 (r,u)=r\,1+u\,\epsilon,
 \qquad
 (r,u,v)=r\,1+(u\,\epsilon_1+v\,\epsilon_2),
\]

and proves that a zero linear combination has all coefficients zero.
Thus `(1,epsilon)` and `(1,epsilon1,epsilon2)` are actual bases after
field specialization. Weak function extensionality is used for equality
of the finite coordinate functions. Neither classical logic nor any
basis-selection principle is used.

### Field specialization and the local-ring criterion

`SquareZeroUnits.FieldData R` supplies ordinary coefficient-field
structure: additive inverses, `1 != 0`, and an inverse of each nonzero
coefficient. These are input laws of the coefficient field, not input
laws of either constructed infinitesimal algebra.

For any module with ordinary additive inverses, the square-zero
extension obtains componentwise additive inverses. Given a nonzero
residue `r` and an inverse `s` of `r`, the explicit algebra inverse is

\[
 (r,m)^{-1}=(s,-s(sm)).
\]

Its product with `(r,m)` is proved to be the unit. Conversely, a unit
in the extension must have nonzero residue, by applying the actual
augmentation to its inverse equation. The module proves uniqueness
of inverse elements and propositionhood of the resulting unit
predicate without assuming uniqueness of arbitrary equality proofs.

The augmentation kernel contains zero, excludes one, and is closed
under addition, additive negation, and multiplication by an arbitrary
element. It squares to zero by the earlier theorem. The augmentation
is split surjective through the actual scalar inclusion.

Under the separately displayed propositional DNE parameter, a nonunit
has zero residue. More strongly, `proper-ideal-in-kernel` proves that
every multiplicatively absorbing predicate excluding one is contained
in this kernel. Indeed an element outside the kernel has the explicit
inverse above; absorption would then put one in the predicate. This
applies to every proper ideal. Since the kernel itself is a proper
ideal, it is the unique maximal ideal. Its local-ring property has
therefore been derived from the actual algebra operations and the
ordinary field data.

`FirstOrderFields` instantiates the generic argument for both `D` and
`D(2)`. It also specializes the nonzero and distinct direction proofs.
The native statements include the explicit ideal-containment and
split-residue maps; the project does not yet package these in a
general quotient-ring or maximal-ideal library.

### Exact external real and smooth-algebra interpretation

Take `R` to be the ordinary real field with its usual addition,
multiplication, negation and reciprocal of a nonzero element. The
displayed finite bases, commutative-algebra laws, nilpotent augmentation
kernels and local-ring criterion identify the constructed objects as
finite-dimensional local real Weil algebras with residue field `R`.
Equivalently they have the familiar presentations

\[
 \mathbb R[\epsilon]/(\epsilon^2),\qquad
 \mathbb R[\epsilon_1,\epsilon_2]
   /(\epsilon_1^2,\epsilon_1\epsilon_2,\epsilon_2^2).
\]

These polynomial presentations explain the notation; no quotient-ring
construction is required for the coordinate definition or for its
pullback proof.

The associated first-order smooth operations are completely explicit.
For an ordinary smooth function `f : R^k -> R`, define its operation on
the dual algebra by

\[
 f_D((r_i,u_i)_i)
  =\left(f(r),\sum_i(\partial_i f)(r)u_i\right).
\]

For the first-order plane, use the same formula independently in its
two infinitesimal coordinates:

\[
 f_{D(2)}((r_i,u_i,v_i)_i)
  =\left(f(r),\sum_i(\partial_i f)(r)u_i,
                   \sum_i(\partial_i f)(r)v_i\right).
\]

The ordinary chain rule verifies composition of these smooth
operations. Their constants, addition and multiplication are exactly
the coordinate algebra operations already constructed. Projection onto
either infinitesimal coordinate and augmentation commute with every
such operation by direct inspection of the formulas. Hence the actual
square is a square of finite-Weil smooth algebras as well as a square
of ordinary real algebras. This is an external calculus verification;
the derivatives, real field and smooth-operation theory are not
implemented by the four modules.

### Scalar extension and formal parameters

For any real algebra `A`, the finite bases give the canonical
identifications

\[
 A\otimes_{\mathbb R}D\cong A\oplus A,\qquad
 A\otimes_{\mathbb R}D(2)\cong A\oplus A\oplus A.
\]

The maps on pure tensors take `(a,(r,u))` to `(ar,au)` and the analogous
three-coordinate expression. Their inverses use the displayed bases,
for example `(a,b)` goes to `a tensor 1 + b tensor epsilon`.
Multiplication becomes the same square-zero coordinate formula over
`A`. The extended augmentation and projections are the actual
coordinate maps.

The concrete pullback theorem is valid for every commutative semiring,
so applying `FirstOrderWeilSquare.Construction` directly to `A`
proves this coordinate pullback without any basis of `A`. In
particular, the external specialization
`A = C-infinity(Z) tensor_R W0` works at every formal parameter stage,
including its existing nilpotent directions. A potentially infinite
basis of the coefficient-function space is unnecessary for this
specific first-order square.

The separate `FiniteSupportScalarExtension.TensorSquare` construction
provides a general tensor route from actual module maps. The planned
`FirstOrderWeilTensor` integration supplies its original comparison
proof from the theorem above, rather than assuming it. That integration
has its own source and native evidence status and is not silently
counted among these four modules.

### The full first-order smooth comparison at every formal stage

Here is the external theorem for this particular test, including its
smooth-algebra and parameter compatibility. The finite-Weil site and
the functor `j` of formal points are the independently specified ones
in [source-interpretation.md#semantic-completion-078](source-interpretation.md#semantic-completion), Section 2.

For every formal stage `T = Z x ell W0` and every ordinary smooth
manifold `M`, the actual restriction map is a bijection

\[
 \operatorname{Map}(T\times\ell D(2),jM)
 \longrightarrow
 \operatorname{Map}(T\times\ell D,jM)
 \mathop{\times}_{\operatorname{Map}(T,jM)}
 \operatorname{Map}(T\times\ell D,jM).
\]

It is natural under all formal morphisms of `T`, including maps that
mix ordinary and nilpotent coordinates. Thus it is an equivalence of
the corresponding internal mapping objects. It is not only a
statement at the ordinary point stage or a statement about reduced
points.

#### Smooth operations over a general coefficient algebra

Let `A` be any commutative C-infinity algebra. On `A x A`, give a
smooth operation `F : R^k -> R` the formula

\[
 F_{A\oplus A}((a_i,b_i)_i)
 =\left(F_A(a),\sum_i(\partial_iF)_A(a)b_i\right).
\]

On `A x A x A`, apply that derivative expression separately to the
second and third coordinates. The coefficient values `a_i` can
already have nilpotent parts. The partial derivative is evaluated
using the given operation of `A` on those actual values, not just
their real residues.

The smooth chain rule is an identity between ordinary smooth
functions. Interpreting that identity in `A` proves that these
operations respect composition; projections and constants satisfy
their required identities directly. They therefore define genuine
C-infinity algebra structures with the constructed square-zero ring
operations. The augmentation and the two coordinate projections
preserve every smooth operation by these formulas.

These are the actual smooth coproducts `A tensor_infinity D` and
`A tensor_infinity D(2)`. To verify this, suppose given C-infinity
homomorphisms `alpha : A -> B` and `beta : D -> B`. Put
`delta = beta(epsilon)`. Their only possible ordinary algebra
extension is

\[
 h(a,b)=\alpha(a)+\alpha(b)\delta.
\]

Here `delta^2 = 0`. The first-order Taylor identity with smooth
remainder implies, in every C-infinity algebra,

\[
 F(x+n)=F(x)+\sum_i(\partial_iF)(x)n_i
 \quad\text{when all }n_i n_j=0.
\]

Indeed the ordinary identity has a remainder that is a finite sum
of `n_i n_j` times smooth functions of `(x,n)`. Those terms vanish
after interpreting the identity in the algebra. Applying this with
`n_i = alpha(b_i) delta` proves that `h` preserves every smooth
operation. The analogous formula

\[
 h(a,b,c)=\alpha(a)+\alpha(b)\delta_1+\alpha(c)\delta_2
\]

works for `D(2)` because all `delta_i delta_j` vanish. Every element
has the displayed decomposition, so the extension is unique. This
proves the smooth coproduct claim with its actual inclusions; it is
not inferred from an unspecified isomorphism of ordinary rings.

#### The comparison is smooth and natural in all parameters

Equip the literal pullback of the two augmented `A x A` algebras
with componentwise smooth operations. The matching condition is
preserved because augmentation is a C-infinity homomorphism. The
coordinate comparison from `A x A x A` preserves every operation
directly. Its actual inverse uses the common first coordinate and
the two infinitesimal coordinates. In its smooth-operation law,
the matching equalities replace every second first-coordinate
value by the corresponding first one, exactly as in the native
multiplication proof. It too is a C-infinity homomorphism.

For a C-infinity homomorphism `alpha : A -> B`, applying `alpha`
to each coordinate commutes with these operations. This includes
the partial derivative operations because they are also ordinary
smooth functions. It commutes with the augmentation, projections,
comparison and inverse. Thus the whole isomorphism is natural in
the actual coefficient algebra; no decomposition of its morphisms
into separate body and Weil-factor maps is assumed.

At a formal stage use
`A = C-infinity(Z) tensor_R W0`, with its established finite-Taylor
C-infinity structure. The products with `ell D` and `ell D(2)`
have the smooth coproduct algebras just proved above. These are
again formal Cartesian stages: the corresponding finite tensor
products of Weil factors have nilpotent augmentation ideals and
residue field `R`. A formal map `T' -> T` induces an actual
C-infinity homomorphism between these coefficient algebras, so
the preceding naturality applies to arbitrary such maps.

The parameter algebra `A` is not assumed to be a field or to be
finite-dimensional over `R`. The local-ring theorem applies to the
original finite-dimensional Weil factors over the external real
field. Its displayed classical DNE is an external algebraic input;
it is not installed in the smooth sheaf topos or used to decide
equalities between its varying real points.

#### Real, Euclidean, open and manifold targets

The C-infinity algebra of the real line is free on one generator.
Consequently maps from a formal stage into `jR` are its actual
algebra elements. Restriction along the four actual maps of the
first-order square is therefore precisely the coordinate
comparison already proved, with the same augmentation and
projections. This establishes the displayed theorem for `M = R`
uniformly over `T`. Finite products establish it for Euclidean
targets.

All three nontrivial infinitesimal stages have the same reduced
body as `T`. A formal map into a manifold factors through an open
submanifold exactly when its reduced map lands there. For a
compatible pair of maps their restrictions to `T` agree, hence
they have one common reduced map `Z -> M`. Pull back a manifold
chart cover along that map. On each resulting open of `Z`, both
maps factor through the same chart. The Euclidean comparison
gives a unique extension there, and its reduced value is unchanged,
so it stays in the chart's open image. The local extensions agree
on overlaps by uniqueness and glue by the sheaf condition.

These are the actual restriction maps throughout. Their inverse
constructions are compatible with substitution by their uniqueness
and the previously checked coefficient naturality. Since formal
stages generate the sheaf category, the stagewise natural
bijections establish the internal mapping-object equivalence.

This closes the external smooth and all-parameter comparison for
the specified first-order Weil square. Its ordinary coordinate
algebra calculation is native checked. The real calculus,
C-infinity operations, site, sheaf interpretation, and this
source-to-model argument remain external mathematics. The result
does not establish the corresponding comparison for every
internally defined infinitesimal object of the old Myers language.

### Scope of what remains

This work constructs a concrete, nonzero algebra square with the exact
coordinate comparison used by the first-order Weil test. It does not
construct every finite real Weil algebra, the full real field inside
Agda, the smooth-function algebra of an arbitrary manifold, the Cahiers
site, its sheaves, or the type-theoretic semantic transfer. The canonical
real/C-infinity/tensor identifications above are explicit external
mathematics. Their status should remain separate from both the native
algebra theorems and the broader external model audit.

