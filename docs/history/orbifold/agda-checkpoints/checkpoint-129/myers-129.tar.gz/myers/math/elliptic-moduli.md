# Elliptic moduli

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="elliptic-identity-prerequisites"></a>

## Checked prerequisites for elliptic moduli identities

The four modules below are bounded intermediate constructions for the actual moduli-map fibers in [Myers §2.4](https://arxiv.org/abs/2205.15887).

### Exact checked statements

`PredicateIdentities.agda` identifies equality of proposition-valued
predicates with pointwise equivalence. For a family of carriers, it also
identifies equality after transport of a predicate with preservation of
membership along the actual carrier transport. Its orientation is
source membership at x to target membership at transported x. This is
a universe-polymorphic pure type-theoretic result.

`StandardLatticeArrows.agda` proves an equivalence between actual scalar
unit maps carrying the standard lattice Zσ+Z to Zτ+Z and actual matrices
M in SL₂(Z) equipped with the equation Mτ=σ. The scalar is exactly the
Möbius denominator cτ+d. The inverse uses the proved denominator unit
and the actual standard-lattice membership equivalence. Both inverse
laws are proved; matrix uniqueness comes from the checked basis-change
theorem, rather than being assumed. The direction σ→τ corresponds to
Mτ=σ, which matters for the later fiber action.

`StructureTransportIdentities.agda` proves a general faithful-transport
criterion for structures whose identities are represented by carrier
equivalences with proposition-valued laws. The representation
equivalence and its transport computation are explicit parameters.
Equal transport on every element then implies equality of the actual
structure paths. The proof is abstract over that representation, so it
does not normalize a particular large structure-identity proof.

`LineTransportIdentities.agda` instantiates that criterion with the
already proved univalent identity characterization of rank-one
modules. It proves that the actual path for scalar 1 is reflexivity,
and that the actual paths for scalar units u and v compose to the path
for their product. These are equations of actual paths in the type of
lines, proved through their action on every vector.

### Hypotheses and boundaries

The scalar lattice correspondence uses an ordinary commutative real
ring, Kock's field axiom, the project strict-order record and its
ordered-ring compatibility. It uses the constructed complex ring,
actual integer coefficient map, actual SL₂(Z), actual upper half-plane,
and actual embedded standard lattices. No desired quotient theorem or
torsor-fiber premise is added.

The complex-line transport theorem needs only a commutative ring; the
predicate and faithful-transport theorems are pure type theory. All four
modules use the project's safe Cubical Agda settings.

The complete moduli identities, coherent invariance paths, free/transitive
fiber actions and quotient classification are constructed separately in
`LatticeModuliIdentities`, `MobiusLatticeCocycle`,
`StandardLatticeIdentityCharts` and `EllipticModuliQuotient`. Their hypotheses
are described below; these prerequisites alone are not the final theorem.

The lattice-moduli structures currently used by the project encode
rank two as mere existence of an actual additive group equivalence
Z²≃Λ. No equivalence with a different or weaker meaning of rank has
been silently introduced. The final moduli statement must retain this
finite-free interpretation unless a separate comparison theorem is
proved.

Compiler invocations are serialized to protect the shared interface state.
The successful generic faithful-transport boundary is part of the checked
source. Recovery and source-acceptance rules are in ACTIVE-WORK.md.

<a id="elliptic-chart-fibers"></a>

## Actual standard-lattice chart coordinates and fibers

The chart interfaces are `StandardLatticeChartScalars`, `StandardLatticeMatrixEquivalence`, `StandardLatticeMatrixCoordinates`, `StandardLatticeChartIdentities`, and `StandardLatticeIdentityCharts`.

### Exact scalar coordinates

The module takes an actual chart in the canonical complex line's
finite-free lattice type, together with a proved equality between its
subgroup predicate and the constructed standard lattice predicate.
It proves that scalar-unit arrows preserving the chart's membership
are equivalent to scalar-unit arrows preserving that actual standard
lattice. The inverse comparison preserves the exact scalar unit;
only its propositional membership-preservation witness changes.

The real commutative ring, Kock field axiom, strict order, and
ordered-ring compatibility are ordinary explicit inputs. The lattice
type retains actual metric discreteness for every real inner product
and mere existence of an integral two-element group basis. This does
not interpret an unspecified rational-rank condition as an integral
basis.

### Exact matrix coordinates

`StandardLatticeMatrixEquivalence` proves that an actual identity
between the chart values at σ and τ is equivalent to an actual
determinant-one integer matrix M together with Mτ = σ for the proved
Möbius action. It composes the actual scalar-coordinate equivalence
of canonical-line lattice identities, the proved chart-predicate
comparison, and the accepted standard-lattice scalar/matrix theorem.
An explicit equality to this exact composition is retained, even
though the resulting equivalence value is opaque to later elaboration.

`StandardLatticeMatrixCoordinates` proves the inverse formula for that
exact equivalence. A matrix arrow is sent to its actual standard-lattice
scalar arrow, then through the inverse chart-predicate comparison, and
finally to the actual canonical-line lattice identity. The equality is
proved from the exact composition above using a universe-polymorphic
inverse calculation and transport along the proved equality of
equivalences. No alternative identity or unproved inverse formula is
introduced.

`StandardLatticeChartIdentities` defines the actual chart-invariance
path and proves that the inverse classifier at `(M, refl)` is exactly
this path. It further computes its actual projection to the complex
line as the scalar-unit loop determined by the Möbius denominator.
The calculation uses faithful transport on vectors of the canonical
complex line and the checked scalar-coordinate computation.

### Actual chart fibers and quotient comparison

`StandardLatticeIdentityCharts` proves the unit and multiplication
coherence of these actual invariance paths. Identities in the lattice
moduli are determined by their complex-line projections, so the checked
denominator cocycle supplies the required equality of paths.

For each moduli point Y, it defines the literal action on the actual
fiber of q by `(τ, p) ↦ (Mτ, invariance(M, τ) ∙ p)`. The group laws
are checked for this exact action. The proved matrix classifier and
its exact inverse computation show that each orbit map into that
fiber is an equivalence. Freeness and transitivity are conclusions.

The actual fiber lives in the higher universe of the moduli type.
The explicit small model from `CanonicalLatticeIdentities` retains
the same parameter τ and an actual complex-line isomorphism preserving
the lattice. Its proved equivalence to the literal fiber transfers
the action. Assuming actual surjectivity of q, these small models are
proved to be algebraic torsors; no resizing or choice is introduced.

The `Chart.Covered` module then proves an equivalence from the actual
ordinary Möbius action quotient to the actual finite-free lattice
moduli. `quotient-triangle` identifies this equivalence on the actual
orbit map with q pointwise. The exact group, action, fiber coordinates,
and equivariance are supplied to the checked small-fiber quotient
recognition theorem, rather than assumed as a desired torsor or
quotient property.

### Current boundary

`EllipticModuliQuotient` uses the actual `LatticeModuli.standard-lattice`,
its predicate computation, and the independently proved
`LatticeModuliCoverage` surjectivity. `EllipticModuliShape` adds the shape
and universal-cover transfer. They are additional wrappers, not assumptions
of the generic chart result.

All current entrypoints use ordinary geometric parameters. The
classification does not require a crispness premise. The source's
rank terminology is interpreted here as mere existence of an actual
integral two-element group basis, as stated above; the constructive
weak-rank distinction remains documented separately.

<a id="coherent-fiber-actions"></a>

## Actual coherent fiber actions and orbit equivalences

`CoherentFiberActions.agda` and its related fiber constructions retain the explicit coherence hypotheses below.

These are pure type-theoretic constructions with independent universes
for the group, the parameter space, and the target of the map. They
support the concrete elliptic moduli proof; this generic receipt does
not claim that its remaining geometric specialization is already
accepted.

### Coherence gives the literal fiber action

For an ordinary group G acting on X, a map q:X→Y, and actual paths
h(g,x):q(g·x)=q(x), `CoherentFiberActions` takes the unit and composition
equations of those paths. It constructs the action on the literal
homotopy fibers by

g · (x,p) = (g·x, h(g,x) ∙ p).

The unit and composition proofs use the actual transport in the
dependent sum defining the fiber. No equality proof is discarded by
set truncation, and no action or torsor structure on the fibers is an
input.

If an explicit small type is equivalent to each literal fiber, the
module transfers that action through the equivalence. It proves the
full coordinate comparison and, in particular, equivariance of the
first coordinate with the original action on X. With mere
surjectivity of q and equivalence of every actual orbit map, the
resulting small actions are actual algebraic torsors. The small
equivalences are explicit data, so this transfer uses no resizing
principle or choice of fiber points.

### Identity classification gives the actual orbit equivalences

`IdentityFiberOrbits` starts from an actual equivalence

(q(s)=q(t)) ≃ Σ g:G, g·t=s

and the computation identifying its inverse at (g,refl) with h(g,t).
It proves that the literal map

g ↦ (g·x, h(g,x) ∙ p)

is an equivalence onto the fiber over y, for every (x,p) in that fiber.
The proof first computes the fiber over q(x) by summing the given
identity equivalence, then composes with p. Its comparison with the
displayed orbit map is checked explicitly. Consequently an unrelated
equivalence between the group and some replacement fiber cannot
stand in for freeness and transitivity.

### Geometric specialization

The elliptic application is supplied by the concrete chart and quotient modules
described in [Elliptic moduli](elliptic-moduli.md). The generic result here does
not itself construct scalar-lattice classification, the Möbius denominator
cocycle, or geometric coverage.

<a id="elliptic-coherence"></a>

## Actual scalar-path and Möbius denominator computations

The concrete coherence interfaces are the modules named in this section.
Their maps and equations, not compiler summaries, specify the comparison.

### Projection of the actual inverse scalar identity

The checked canonical-lattice identity equivalence identifies an
actual moduli path with a complex scalar unit that preserves the
literal lattice membership predicate. `CanonicalLatticePathCoordinates`
computes the line projection of its actual inverse: it is precisely
the univalent complex-line loop induced by multiplication by that
scalar unit.

The proof evaluates the decoded linear map at 1, using the section
law of the checked scalar identity equivalence. Linearity computes
the decoded map on every vector. The actual carrier-transport
computation of the line identity then identifies its effect with
scalar multiplication. Finally, the checked faithful-transport
theorem gives equality of the actual line paths. This avoids treating
an unspecified equivalence of path types as the required comparison.

`CanonicalLatticeScalarTransport` retains this actual inverse path
behind an abstraction boundary. Its checked inverse-computation
equation identifies it with the original inverse scalar-coordinate
map, and its carrier-transport formula directly computes scalar
multiplication on every vector. Concrete substitutions can therefore
use the formula without expanding the structured univalence path.
`CanonicalLatticeArrowTransport` gives the same exact interface for
an entire dependent scalar-arrow pair. This lets later computations
pass the pair without first exposing its concrete dependent fields.

`InverseEquivalenceComputations` proves the inverse equations of the
library's actual composition and isomorphism constructors with generic
arguments. These equations support explicit inverse comparisons at
concrete types without requiring their full inverse terms to normalize.
`ComposedInverseCoordinates` combines these equations into the full
three-equivalence inverse-coordinate calculation, using proved inverse
formulas for its first and last equivalences. The concrete matrix stage
uses this accepted calculation directly.

### Actual denominator units and their cocycle

`MobiusDenominatorCocycle` uses the literal determinant-one integer
matrices, their actual coefficient map to the real ring, and the
already constructed Möbius action on the actual upper half-plane.
Its denominator is exactly cτ+d. The supplied inverse is the already
proved inverse of that actual complex number.

The module proves the unit equation and the exact product formula

D(MN,τ) = D(M,Nτ) * D(N,τ).

The unit calculation uses the integer ring homomorphism on the four
literal identity-matrix entries. The product calculation uses the
checked coefficient map on raw matrix multiplication, followed by
the proved denominator-clearing equation for the actual Möbius map.
Thus neither matrix multiplication nor the denominator cocycle is
an additional premise.

### Actual complex-line loops

`MobiusScalarLoops` constructs the literal univalent complex-line
loop of multiplication by each actual denominator unit. Its accepted
transport theorem computes the effect of that actual path on every
vector as multiplication by cτ+d. This theorem is kept abstract across
the file boundary so the later unit and composition proofs can use
the computation without expanding the concrete univalence proof.

`MobiusLoopTransport` also gives an opaque representative of that
same actual loop, with a proved equality to the original canonical
univalent scalar-unit loop. It preserves the carrier-transport formula
and the faithful-transport theorem for actual complex-line paths.
The opacity is only an elaboration boundary: the exact canonical
identification is part of the checked API.

`MobiusLatticeCocycle` proves the unit and composition laws of these
actual loops. The composite loop first transports by D(M,Nτ) and
then by D(N,τ). Commutativity of complex multiplication and the
proved denominator cocycle identify this transport with D(MN,τ).
Faithful carrier transport then gives equality of the actual line
paths. The identity denominator similarly gives the reflexivity path.

### Parameters and current boundary

Both concrete modules retain the ordinary real commutative ring,
Kock field axiom, project strict order, and ordered-ring compatibility
parameters of the actual complex/lattice construction. They introduce
no choice, resizing, or desired quotient conclusion.

The concrete chart, orbit map q, coverage, and shape comparison are
additional constructions with the scope described below. Their conditional
formal results do not identify the native foundation with an external
smooth model.
<a id="elliptic-moduli-quotient"></a>

### Exact statement

The theorem concerns `ComplexLatticeStructures.Geometry.FiniteFreeModuli`.
An object consists of an actual complex line, an actual additive subgroup,
metric discreteness for every actual real inner product on the line, and
mere existence of an actual additive group equivalence from the integer
pair group to that subgroup. The metric condition gives a merely specified
positive rational radius for each inner product. The radius condition
forces a lattice point of sufficiently small squared norm to be zero.
Neither a basis nor an inner product is chosen as part of the moduli point.

The upper half-plane, integer determinant-one matrix group, fractional
linear action, standard subgroup, and map

\[
q(\tau)=(\mathbb C,\mathbb Z\tau+\mathbb Z)
\]

are the previously constructed objects, including all lattice proofs.
The quotient is the actual torsor-family action quotient. It retains the
groupoid identities and stabilizers; it is not a set-truncated orbit set.

The final declarations prove

\[
e:\mathbb H//\mathrm{SL}_2(\mathbb Z)\simeq
  \operatorname{FiniteFreeModuli},
\qquad e\circ\operatorname{orbit}=q.
\]

`Geometry.quotient≃moduli` is the equivalence,
`Geometry.quotient-triangle` is its pointwise map computation, and
`Geometry.q-is-action-quotient` packages both. The final wrapper assumes
no quotient equivalence, surjectivity, chosen frame, or fiber-torsor
certificate.

### Mathematical inputs

The geometric parameters are an ordinary commutative ring R, its stated
Kock-field condition, the strict order of Postulate O including the
Archimedean law, and the explicitly separated ordered-ring compatibility
laws. No crispness, R-flat, tiny-object, or Kock–Lawvere premise is needed
for this classification theorem itself. The subsequent shape and cover
theorems add their recorded cohesive and analytic inputs; see
`elliptic-moduli.md#elliptic-moduli-shape`.

The upper half-plane and the matrix group carrier lie in the working
universe. The line/lattice moduli and the torsor-family quotient lie one
universe above it. Actual small fiber models bridge these universes by
proved equivalences. No general resizing rule is used.

### Construction of the equivalence

1. `LatticeModuli` constructs q from the standard subgroup, its actual
   integral basis, and its every-inner-product metric discreteness.
   `LatticeModuliCoverage` proves actual mere surjectivity using the
   derived lattice normalization and each line's existing mere frame.
   The real-spanning theorem is proved through constructive Dirichlet
   approximation and metric separation.
2. Actual lattice identities are classified by complex-linear
   equivalences preserving subgroup membership. On the canonical line,
   these are scalar units preserving the standard lattices. The
   scalar/matrix theorem gives the unique determinant-one matrix; its
   positive determinant is derived from the upper-half-plane condition.
3. `StandardLatticeMatrixCoordinates` and `StandardLatticeChartIdentities`
   prove the exact inverse classifier and its complex-line projection.
   The invariant path induced by a matrix has the actual denominator
   scalar-unit loop as its line coordinate.
4. `StandardLatticeIdentityCharts` derives unit and multiplication
   coherence, the actual action on every literal q fiber, and the
   equivalence of each orbit map. Together with independently proved
   q-surjectivity, the explicit small fiber models are actual torsors.
5. The checked small-fiber torsor recognition theorem identifies the
   ordinary Möbius action quotient and preserves the original orbit/q
   triangle. The final wrapper instantiates every chart, predicate,
   coverage, action, and fiber input by these constructions.

The opaque helper boundaries used to keep Agda conversion manageable all
export proved comparisons to the original concrete maps. They introduce
no new mathematical assumptions.

### Relation to the paper

This completes the quotient theorem for the explicit finite-free
interpretation of the rank-two lattice setting in
[Proposition 2.4.8](https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm8).
The source's abelian-rank phrase is not defined there. Identification with
a weaker rational-rank interpretation is neither proved nor claimed.
`complex-lattices.md#lattice-rank-diagnostic` records the checked constructive obstruction
to uniformly extracting integral bases from the weaker exhibited data.
The every-inner-product interpretation of the norm notation also remains
explicit in `complex-lattices.md#complex-lattice-moduli`.

`complex-lattices.md#standard-lattice-basis-change` records the corrected coordinates in
the displayed scalar/matrix calculation. The actual quotient and its
map are proved for those checked coordinates. These documented repairs
are independent formal findings, not author-published errata.

<a id="elliptic-shape-foundations"></a>

## Actual upper half-plane and integer-torsor shape

These are concrete foundations for the elliptic examples in Myers,
Proposition 2.4.8 and Corollary 3.2.6. They do not themselves assert
classification of metric lattices or the complete elliptic-moduli
quotient identification.

### Upper half-plane

`UpperHalfPlaneShape.agda` uses the actual type from
`UpperHalfPlane.Geometry`:

H = Σ z : (R × R), 0 < snd z.

Reassociation gives an explicit equivalence H ~= R × R-positive.
The actual positive-line equivalence supplied by the existing
`IntervalParameterization.PositiveLineEquivalence` therefore gives
an explicit R² ~= H. This is the precise fragment of the paper's
Exp assumption used here.

The actual shape modality is nullification at R. R is connected for
that modality by the existing generator theorem, and the checked
product theorem makes R² connected. Transport along the displayed
equivalence proves `Shape.Connected H`, i.e. contractibility of the
actual shape reflection of H. No convexity or shape-contractibility
assumption is added.

### Native integers and determinant-one matrices

`CrispIntegerNullity.agda` derives an integer crisp eliminator from
native integer constructors and the already checked natural-number
crisp eliminator. The motive may depend on ordinary context. It
therefore gives a merely inhabited actual fiber of the Flat counit
at each lifted integer.

The counit is an embedding for a crisp set under the existing
R-flatness and crisp identity rule. Combining that embedding with
the derived surjectivity proves lifted integers crisply discrete,
and R-flatness then proves actual R-nullity. Equivalence with the
unlifted integer type gives the cross-universe statement for ℤ.

Closure of null types under dependent sums and identity types proves
R-nullity of the literal four-integer matrix type and then of the
actual determinant-one subtype `SpecialLinearTwo.Integers.SL₂`.
The explicit universe lift used by the upper-half-plane action is
also R-null. No assumption that SL₂(ℤ) is discrete, no matrix
countability axiom, and no lattice classification are introduced.

### Actual algebraic torsor classifier

`TorsorShape.agda` is generic. For a crisp group G in universe ℓg,
its classifier is exactly `Torsors.Theory G.Torsor`, pointed by the
actual regular torsor. This classifier lives in universe suc ℓg.
The existing torsor theorem identifies its actual loop type with
the actual carrier of G and proves it merely connected.

R-nullity of the group carrier implies R-nullity of that loop type.
Mere connectedness then transports this property to every identity
type of the actual classifier. Both truncations are eliminated only
into nullity propositions. The already checked connected crisp
separated-type theorem proves the whole classifier R-null and
crisply discrete.

The theorem explicitly requires the crisp identity rule and R-flat
condition at the classifier's larger target universe. The generator
R may remain in a smaller universe. Those upper-universe hypotheses
are not inferred from lower ones. The classifier's groupoid property
comes from the checked algebraic torsor construction.

### Exact specialization used by the Möbius action

`SpecialLinearTorsorShape.agda` specializes to the precise group
`UpperHalfPlane.Geometry.IntegerGroup`. Its public `BSL₂ℤ` is
definitionally that module's `IntegerActions.Torsor`; it is not a
selected abstract delooping.

Given ordinary lower and upper R-flat proofs, and the explicit crisp
identity rules at both levels, the wrapper proves:

* R-nullity of this actual classifier.
* Equivalence of its actual Flat counit.
* Its actual groupoid truncation level.
* Equivalence of its actual shape unit into nullification at the
  same real generator R.

The geometry parameters are crisp in this wrapper because the
connected crisp separated-type theorem applies to a crisp classifier.
The lower and upper R-flat proofs themselves remain ordinary. The
larger classifier universe and the smaller real generator remain
visible in the types.

<a id="elliptic-moduli-shape"></a>

## Actual elliptic lattice moduli: shape and universal-cover transfer

The rank condition is the mere existence of an additive group equivalence
ℤ² ≃ Λ. The actual chart/coverage/quotient/shape chain uses that condition;
a weaker rational-rank convention has not been silently substituted.

This is the transfer step for the setting used to interpret
[Proposition 2.4.8 and Theorem 3.2.6](https://arxiv.org/html/2205.15887v1).
Its inputs and remaining interpretation boundaries are explicit below.

### Literal objects and maps

The moduli type is the actual dependent pair of a complex line and a
lattice subgroup in that line. The lattice condition quantifies over
every actual symmetric positive-definite real bilinear form, uses a
positive actual rational isolation radius, and requires merely an
integral additive group equivalence with `Z²`.

The map `q` is exactly the checked map taking a point `tau` of the actual
upper half-plane to the canonical complex line with subgroup `Z*tau+Z`.
The checked quotient comparison comes from `EllipticModuliQuotient`;
it is an actual construction with all chart, coverage, action, and
torsor inputs instantiated. The shape module introduces no quotient
equivalence or surjectivity premise.

### Checked shape statement

`Geometry.Exponential.shape-moduli≃BSL₂ℤ` identifies the actual
R-nullification of this moduli type with the actual algebraic torsor
classifier of the lifted integer matrix group used by the Möbius action.
The equivalence is obtained by the actual nullification functor applied
to the constructed quotient equivalence, followed by the checked shape
comparison of the Möbius action quotient.

The `shape-point` theorem retains the original `q(tau)` point and sends
its shape unit to the regular torsor. `pointed-shape-equivalence`
packages this comparison, and `shape-loops≃SL₂ℤ` gives its induced
equivalence of loop carriers with the actual integer matrix group
carrier. `shape-one-moduli≃BSL₂ℤ` separately uses the exact existing
shape-one generator family.

### Checked specified universal-cover statement

For any chosen upper-half-plane point `tau0`, `Based.UniversalCover` is
literally

```
fiber (unit : Moduli → Null ShapeOne.Generator Moduli)
      (unit (q tau0)).
```

The `upper-half-plane≃universal-cover` equivalence first uses
the checked universal cover of the actual Möbius quotient. It then uses
the checked `NullUnitEquivalences.unit-fiber-at` along the actual
quotient comparison and its original-map triangle. The first-coordinate
computation gives the `cover-triangle` theorem, whose conclusion
is exactly `cover(e(tau)) = q(tau)`. The `q-is-universal-cover` statement
packages that equivalence and equality of the displayed maps.

### Exact assumptions and interpretation boundaries

The geometry has native-crisp commutative-ring, Kock-field, strict-order,
and ordered-ring-compatibility data. Shape uses native-crisp identity
rules at the carrier and torsor-classifier universes, explicit lower and
upper R-flat hypotheses, and the actual positive-line equivalence from
the exponential context. The upper-half-plane shape and classifier
nullity are derived by the already checked modules; they are not new
fields of the final theorem.

The carrier of the upper half-plane lies in the small universe, while
the actual moduli, torsor classifier, and unit fiber lie in the next
universe. Their stated equivalences are constructed across those levels;
no universe resizing is assumed.

The finite-free integral interpretation of abelian rank remains visible.
It is not silently replaced by a weaker rational-rank condition; the
checked conditional-subgroup diagnostic documents that distinction.
Likewise the source's angle-bracket norm is represented by actual
positive-definite bilinear forms, without asserting a comparison with
every separately axiomatized normed-space norm. The established
shape-one indexing convention remains unchanged: the actual S²-nullity
presentation gives the stated discrete-groupoid class, without silently
identifying it with an S¹-indexed set reflection.

<a id="mobius-quotient-shape"></a>

## Shape of the actual Möbius action quotient

`MobiusQuotientShape`, `SphereNullityUniverses`, `ShapeOneUniverses`,
and `MobiusUniversalCover`
are accepted with the pinned safe native kit and cohesion, exit zero and
no warnings. Compiler calls are serialized with `flock`; the proof flags
and evaluator are unchanged. No new axiom is introduced.

### Actual action and actual quotient

`MobiusQuotientShape.Geometry` uses the actual constructed upper half-plane,
the canonical lifted integer matrix group, its proved Möbius action, and
the actual `EquivariantBundles` family over the exact algebraic torsor
classifier of that group. Its `MobiusQuotient` is that family's literal
dependent sum. Its `orbit` is the original associated-bundle orbit map.
No abstract quotient or desired lattice-classification field is supplied.

The inputs are native-crisp ordered Kock-field data, crisp identity rules
at both the carrier and torsor-classifier universes, ordinary lower and
upper R-flat hypotheses, and the actual positive-line equivalence from
the exponential context. The upper-half-plane shape is proved contractible
by `UpperHalfPlaneShape`. Evaluation at the regular torsor identifies the
actual regular associated fiber with that upper half-plane, and the
torsor's mere connectedness transports this result to all fibers.

`SpecialLinearTorsorShape` supplies nullity of the actual classifier in
its own larger universe. `NullSigmaReflection` then proves

```
Null Real.ShapeGenerator MobiusQuotient ≃ BSL₂ℤ.
```

This equivalence is the actual recursor extending the quotient projection.
Its unit computation preserves that projection, and its orbit triangle
sends every original upper-half-plane point to the regular torsor. The
module also records the pointed equivalence and the resulting actual
loop-type equivalence with the lifted integer matrix group carrier.
The base, fibers, and generator universes remain distinct; no resizing
or lifted replacement ring is used.

### Exact shape-one universe bridge

`SphereNullityUniverses` proves the same sphere-nullity/truncation
characterization as `SphereNullification`, for an independent target
universe. `ShapeOneUniverses` uses the exact existing `ShapeOne.Generator`
family, including its actual sphere index, rather than introducing a new
reflection. A type is null for this family exactly when it is R-null and
a groupoid, across these universes.

If a type's actual R-shape is already a groupoid, the actual shape-one
reflection is proved equivalent to that actual shape by the two HIT
recursors and their elimination principles. Both maps preserve the
original unit judgmentally. The existing explicit sphere-indexing scope
of `ShapeOne` is retained: the S²-nullity presentation realizes the stated
class of discrete groupoids; no silent identification with an S¹-indexed
set reflection is claimed.

### Actual universal cover

`MobiusUniversalCover` combines the actual shape comparison with the
same shape-one HIT generators and `NullUnitFibers`. For each chosen
upper-half-plane point `tau0`, its universal cover is literally

```
fiber (unit : MobiusQuotient → Null ShapeOne.Generator MobiusQuotient)
      (unit (orbit tau0)).
```

It constructs an equivalence from the actual upper half-plane to this
actual fiber. Composing that equivalence with the fiber's first projection
is proved equal to the original orbit map. Thus both the covering space
and the displayed map are identified; no replacement map or assumed
covering classifier is substituted. The shape-one projection comparison
is the actual HIT recursor, proved an equivalence by the checked
unit-preserving shape comparison. The universe of the actual cover may
be larger than that of the upper half-plane; their cross-universe
equivalence is constructed without resizing.

### Transport of the actual unit fiber

`NullUnitEquivalences` is also checked. For an actual equivalence
`e : X ≃ Y`, it constructs an equivalence between the actual nullification
unit fibers over `x0` and `e(x0)`. A supplied equality `e(x0)=y0` gives the
version over the specified point `y0`. The first coordinate of either
fiber equivalence is exactly `e` applied to the original first coordinate.
It uses the library's actual nullification map and the induced path
equivalence, with independent universes for all generators and spaces.
This result supplies the map-preserving transfer used by the separately
checked lattice-moduli identification and its universal-cover theorem.

### Checked identification with finite-free lattice moduli

The results above are independently proved for the literal Möbius action
quotient. The separate `EllipticModuliQuotient` construction now identifies
that quotient with the literal finite-free lattice moduli while preserving
`q(tau)=(C,Z*tau+Z)`. `EllipticModuliShape` transfers the actual shape and
specified ShapeOne-unit fiber along that constructed equivalence and
proves that the resulting covering map is exactly `q`. Both modules have
completed canonical safe checks. The explicit finite-free rank and
inner-product norm interpretations remain visible in their scopes.

<a id="upper-half-plane"></a>

## The actual Möbius action on the upper half-plane

The upper-half-plane module constructs the literal Möbius action. That action alone is not the lattice torsor classification; the additional comparison is in [Elliptic moduli](elliptic-moduli.md).

### Exact context and carrier

`Geometry R kock order compatibility` takes an ordinary commutative
ring, the existing `SyntheticField.KockField` and `StrictOrder`
structures, and the existing explicit `OrderedRingCompatibility`
relating the order to positive differences. No crispness, choice,
excluded middle, exponential map, or desired action theorem is a
premise. The order compatibility is kept visible; it is not silently
inserted into the literal fields of Postulate O.

The carrier is literally

`UpperHalfPlane = Σ[ z ∈ R × R ] 0 < snd z`.

Its basepoint is `(0,1)`, with positivity supplied by the order axiom.
The complex arithmetic comes from the checked `ComplexPairs` ring.
The matrices come from the checked actual determinant-one subtype in
`SpecialLinearTwo`.

### Denominators and positivity

For a determinant-one matrix and an upper-half-plane point, the module
proves `c*z+d` is nonzero. If this denominator vanished, its imaginary
part would give `c*im z = 0`. Positivity and the Kock-field axiom make
`im z` invertible, forcing `c=0`; the real part then forces `d=0`,
contradicting the determinant equation.

The checked finite-coordinate norm theorem proves its squared norm
positive. `SyntheticOrder.positiveInverse` therefore supplies an actual
positive reciprocal of that norm. The constructed Möbius value is
the literal numerator multiplied by the conjugate denominator and this
reciprocal. The checked imaginary-part identity proves its imaginary
part positive, so the function actually lands in the upper half-plane.
The reciprocal certificate is abstract only to control Agda
normalization; it is constructed from the explicit axioms and proofs.

### Actual action laws and integer coefficients

The module proves the denominator-cleared numerator and denominator
composition formulas. Cancellation by the proved denominator unit then
proves the identity and composition laws for the actual fractional
linear function. `real-mobius-action` is an actual algebraic action for
the actual group `SL₂(R)`.

`integer-mobius` uses the canonical, proved coefficient homomorphism
`SL₂(ℤ) → SL₂(R)` from `IntegerCoefficients`. Its unit and composition
laws are proved explicitly. The existing algebraic torsor library uses
one common universe for a group and its action carrier. Accordingly,
`IntegerGroup` explicitly lifts the integer matrix group to `Type ℓ`,
with operations and laws inherited through `lift` and `lower`.
`integer-mobius-action` packages the action of this lifted group. No
resizing axiom is used, and the underlying function on ordinary integer
matrices remains separately exported.

The scalar-coordinate and final classification constructions are separate from this action module; see [Complex lattices](complex-lattices.md) and the quotient and shape constructions in this chapter.

