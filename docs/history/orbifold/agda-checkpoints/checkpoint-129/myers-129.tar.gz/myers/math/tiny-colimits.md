# Tiny colimits

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="tiny-colimits"></a>

## Tiny types, canonical colimits, and crystalline descent

Reference: Myers, [arXiv:2205.15887v1](https://arxiv.org/abs/2205.15887),
Appendix A and Theorems 5.4.7–5.4.9.

### The external adjunction is the actual one

`TinyTypes.External T` records a crisp family `root` and its evaluation
map. For crisp X and Y the adjunction comparison is

```agda
comparison X Y omega v = evaluate Y (omega ∘ v)
```

Its image under `flat-map` must be an equivalence. Naturality in X is
proved before applying Flat. The witness is crisp, but the proof that
these comparisons are equivalences can be ordinary. `Tiny` is the mere
existence of a boxed adjoint witness and its adjunction proof, not a
choice of such data in every context.

### Pushouts and coequalizers

`MappingColimits.Span` and `Coequalizers.Mapping` prove the universal
properties using actual restriction functions. Coherences are function
identities, retaining all homotopy information. `Coequalizers.Coeq` is a
genuine HIT with points and gluing paths and no set-truncation constructor.

`CrispIdentity` explicitly names the ambient structural crisp identity
induction rule and derives the canonical Flat identity comparison and
its naturality. `CrispLimits` derives Flat preservation of dependent
pairs and pullbacks. This is foundation infrastructure, not a geometric
preservation assumption. See foundations.md#crisp-identity and foundations.md#crisp-limits.

`TinyPushouts` and `TinyCoequalizers` then transport the mapping-space
universal property across the external adjunction. The path coordinate
of each cone is checked using naturality of the Flat identity comparison.
The resulting square identifies the transported map with precomposition
by the literal exponential comparison. An external Yoneda argument,
proved in `CrispLimits` using only native Flat, proves that comparison
is an equivalence.

For example the pushout comparison has precisely these clauses:

```agda
comparison (inl b) t = inl (b t)
comparison (inr c) t = inr (c t)
comparison (push a i) t = push (a t) i
```

No preservation assertion is included among the tiny-adjoint fields.

### Sequential colimits

`SequentialCoequalizer` proves the canonical equivalence

```text
SeqColim X ≃ Coeq id advance
advance (n , x) = (suc n , map X x)
```

on the dependent sum of the stages. If the natural numbers are T-null,
Lemma A.0.6 makes the actual constant-index map

```text
Σ n (T → X n) → (T → Σ n X n)
```

an equivalence. Its compatibility with `advance` is definitional.
Coequalizer congruence and `TinyCoequalizers` now give the sequence
comparison. `TinySequences` proves that this composite agrees with the
literal pointwise `incl`/`push` comparison, including its gluing paths.

For the actual crystalline generator 𝔇, T-nullness of the natural numbers
is proved directly: every infinitesimal double-negation-neighbors zero,
and decidable equality on the natural numbers turns that neighbor
relation into equality. Thus the crystalline case uses no extra nullness
assumption, countable choice, or Flat-product axiom.

The separate `CrispProducts` and `CrispFunctionProducts` developments prove
the actual Flat product comparisons under R-flatness and uniform crisp
structural rules. `TinyNaturals` now derives Nat-nullness for arbitrary
tiny T from its external adjunction and those comparisons.
`TinySequentialPreservation` therefore proves the general canonical
sequence comparison from mere tinyness, without selecting an adjoint
globally or leaving Nat-nullness as an assumption. These extra structural
inputs are not needed by the direct crystalline argument above. See
tiny-colimits.md#general-tiny-sequences for their exact scope.

### Nullification preservation

`NullificationColimits` proves the pushout and sequence cases of A.0.9
for actual HIT nullification. Exponentiation preservation by every
nullifying generator makes the colimit of the reflected vertices null.
An explicit inverse to the comparison follows by nullification
elimination. The proof identifies its strict HIT map with the general
canonical modal comparison used by the earlier descent modules.

`CrystallineColimits` specializes this result to the actual infinitesimal
generator. `CrispColimits` supplies its exponential comparisons from the
proved tiny-type results, giving Theorem 5.4.8. Its `FromTinyness` module
eliminates the mere Tiny witness into the proposition that each canonical
comparison is an equivalence. A globally chosen adjoint is unnecessary.

`TinyNullificationColimits` also derives both canonical comparisons for
an arbitrary native-crisp family of merely tiny types indexed by a small
crisply discrete type. The index type need not be finite or countable.
The proof derives its discrete-index eliminator from the Flat counit
equivalence. This result uses the explicit uniform crisp structural
rules and R-flatness for sequences; it does not assume generator-wise
exponential preservation. General higher indexing diagrams and a
separately larger index universe are outside this theorem's current scope.
See tiny-colimits.md#tiny-nullification-families.

### Consequence for groupoids

`CrispColimits.FromTinyness.SelfPullback` supplies every positive join
pushout and the positive-stage sequential colimit needed by the checked
join descent theorem. `CrispNaturals` lets the ordinary stage index use
the crisp preservation theorem. Crystalline-unit surjectivity is already
a consequence of the actual pointed nullification.

`CrispGroupoids.FromTinyness` combines this with the actual Rezk
completion. Source etaleness derives canonical-object-map etaleness.
Connectedness of all crisp Weil tests, proved separately from K, crisp
pullback preservation and the uniform ambient truncation rule, yields
the full microlinearity conclusion of Theorem 5.4.9.

ProperEtaleManifoldOrbifolds now derives properly finite homs and the literal
internal Theorem 6.3.7. The additional tiny powered-surjection theorem gives
crystalline total arrows from literal DP properness; the full manifold shape
theorem and crisp logic then give total-arrow decidable equality, which
restricts to ordinary hom families. No local-injectivity premise remains.
The separate external properness comparison is not proved; its exact
diagonal obstruction is documented in properness.md#properness-scope.

<a id="tiny-coequalizers"></a>

### The coequalizer and its actual universal map

`Orbifolds.Coequalizers` defines a higher inductive type `Coeq f g` with
constructors `point b` and `edge a : point (f a) = point (g a)`.
There is no set-truncation constructor.

`Mapping f g Y.universal` proves

```text
(Coeq f g → Y) ≃ Σ (b : B → Y), b ∘ f = b ∘ g.
```

The forward map restricts a function to the actual point and edge
constructors. The inverse is the HIT recursor. All gluing paths are
retained, so this theorem applies to higher targets.

`endomorphism-equivalence e s t commute` proves invariance of
`Coeq id s` under an equivalence `e` satisfying `e ∘ s ~ t ∘ e`.
Its actual forward map sends `point a` to `point (e a)`, and sends an
edge to the target edge followed by the inverse of the conjugacy path.
Equivalence induction and ordinary identity induction prove this map
is an equivalence. For reflexive conjugacy its edge action differs
from the bare target edge only by the right unit law, which is used
explicitly in `EndomorphismIdentity.map-identity`.

This is the form needed to express sequential colimits as coequalizers
of identity and successor on the sum of their stages.

### Theorem A.0.5, coequalizer case

`TinyCoequalizers.Exponentiation T f g` defines the canonical comparison
from the coequalizer of the powered maps to `T → Coeq f g`. It maps
`point b` pointwise and maps each `edge a` to the corresponding
pointwise edge. `Preserved` means exactly that this map is an
equivalence.

`Context rules T witness.Diagram f g.preserves-coequalizer` proves
`Preserved` from the actual external tiny adjunction in `TinyTypes`.
The crisp identity-induction rule, chosen adjunction data, types, and
diagram are explicit. No colimit-preservation conclusion occurs among
the premises.

The proof uses the coequalizer mapping universal property, native Flat
preservation of dependent pairs, and the derived Flat identity
equivalence. The external adjunction then transfers the complete
functional cocone. A checked comparison square includes naturality of
the path coordinate; cancellation yields external precomposition
equivalences. The native external Yoneda theorem finally establishes
equivalence of the actual powered comparison.

Source correspondence: Myers, *Orbifolds as microlinear types*,
[arXiv:2205.15887](https://arxiv.org/abs/2205.15887), Appendix A,
Theorem A.0.5. The theorem is formalized over its external adjunction
premise and the named uniform crisp structural rule, rather than over
an assumed preservation property.

<a id="general-tiny-sequences"></a>

## General tiny types preserve sequential colimits

Reference: Myers, [arXiv:2205.15887v1](https://arxiv.org/abs/2205.15887),
Proposition A.0.5, specifically its sequential-colimit clause.

### Remaining assumptions are foundation assumptions

The proof takes R-flat, the already named uniform crisp identity rule,
and the uniform crisp Flat-induction rule with its beta law. Rule
instances are supplied at the target universe and the small universe
containing Nat. These are explicit ambient spatial-type-theory inputs;
they are not claimed to be native safe Cubical Agda rules.

The result takes the actual external tiny adjunction defined in
`TinyTypes`. Its public form uses the mere `Tiny T` predicate, so a
right-adjoint witness is not chosen globally. No Nat-nullness, countable
choice, Flat-product preservation, or colimit-preservation axiom is
added.

### Actual Flat function comparison

`CrispProducts` already proves Flat preservation of dependent products
indexed by a small crisply discrete type. `CrispFunctionProducts`
specializes that result to a constant family, uses the proved discreteness
of Nat, and raises Nat to the target universe. The forward map is exactly

```agda
comparison (box f) (box n) = box (f (lift n))
```

The canonical comparison therefore gives

```text
Flat (Lift Nat → X) ≃ (Flat Nat → Flat X).
```

Its naturality is checked pointwise. Consequently, if the actual
`flat-map h` is an equivalence, then so is the actual
`flat-map (h ∘_)` on functions indexed by lifted Nat. This is a theorem,
not a field in the ambient structure.

### Tinyness implies Nat-nullness

Fix a crisp tiny-adjoint witness and a crisp target Y. Its evaluation
map defines

```text
epsilon : root Y → Y
epsilon y = evaluate Y (constant y).
```

The external adjunction at Unit, together with the ordinary mapping
spaces out of Unit and the contractible type `(T → Unit)`, proves that
`Flat epsilon` is an equivalence. The Flat function comparison then
proves the same for its pointwise action on Nat-indexed functions.

Naturality of the actual tiny comparison identifies that action with
precomposition by

```text
constant : Lift Nat → (T → Lift Nat).
```

The external Yoneda criterion from `CrispLimits` now proves that this
literal constant map is an equivalence. Ordinary universe-lifting
comparisons give the required equivalence

```text
Nat ≃ (T → Nat),
```

whose forward map is again exactly constant.

### The canonical sequential comparison

`TinySequences` already identifies the actual sequential exponential
comparison with a composite of genuine homotopy-coequalizer
comparisons, provided Nat is T-null. `TinySequentialPreservation`
supplies the newly proved Nat-nullness and obtains, for each native-crisp
sequence X, an equivalence whose forward map is

```agda
comparison (incl a) t = incl (a t)
comparison (push a i) t = push (a t) i
```

All gluing-path coherence remains the previously checked coherence of
`TinySequences`; no set truncation replaces the colimit. Finally,
ordinary propositional-truncation elimination removes the chosen-adjoint
presentation, since being an equivalence is a proposition.

The public API is

```text
TinySequentialPreservation.Context ... R T.preserves-sequence
```

with explicit R-flat and `Tiny T` inputs. The earlier crystalline
specialization remains valid with fewer structural hypotheses: it
proved Nat-nullness of the actual infinitesimal generator directly,
without the general Flat function-product argument.

<a id="tiny-nullification-commutation"></a>

### Checked result and scope

`TinyNullificationCommute.agda` is accepted by the pinned Agda 2.8.0.2 kit
with the project safe, Cubical, guardedness, no-import-sorts, and cohesion
configuration. Its imports include three other accepted new modules:
`CrispPropositions`, `TinyLocalTypes`, and `CrispYonedaEndpoints`.

This is the nullification specialization of Myers, arXiv:2205.15887v1,
Theorem A.0.7 (printed page 67). The printed theorem concerns localization
at a crisp family of maps with T-null sequentially compact endpoints,
indexed by a crisply discrete T-null type. The checked result below
concerns the library's actual nullification HIT. Arbitrary-map
localization, the truncation corollary, and A.0.8 are established in the
separate modules documented in `tiny-colimits.md#tiny-localization-truncation`; this
module retains the direct nullification specialization.

For native-crisp types R, T, and I in Type l, a native-crisp point r0:R,
and a native-crisp family S:I->Type l, the module proves equivalence of

Null S (T -> X) -> (T -> Null S X)

for every native-crisp X:Type l. The map is the actual nullification
recursor induced by pointwise application of the nullification unit.
It is not an unspecified equivalence between the two endpoint types.

The hypotheses are the existing uniform crisp identity induction rule,
R-flatness, equivalence of the actual Flat counit for I, T-nullness of
S(i) at each crisp index, and mere Tiny T. The generator index occupies
the same universe as T and the other types. No finite or countable
restriction is imposed. A scalar ring supplies r0 by its zero element.

This proof does not need sequential compactness of the generators or
T-nullness of the index. These are not omitted assumptions of the
sequential presentation: the argument uses a different, universal-property
proof which establishes the stronger nullification statement directly.

### Proof

First, every crisp proposition P is R-null: evaluation at r0 is inverse
to the constant-function map because P is a proposition. R-flatness then
proves that its actual Flat counit is an equivalence. This yields
`CrispPropositions.Context.promote-proof`, which moves an ordinary proof
of P into Flat P. Together with the already named crisp identity rule,
it lifts an ordinary isEquiv proof of a crisp map under Flat. No context
reset or new proof-promotion axiom is introduced.

Next, `TinyLocalTypes` proves that the actual external tiny right adjoint
sends a target local at P->Q to another local target when P and Q are
T-null. The proof curries product mapping types, applies the given
external adjunction, and transports precomposition across the canonical
product comparisons. An external covariant Yoneda argument turns the
result into the internal equivalence of precomposition. All transformation
maps and their naturality squares are explicit.

Applied to S(i)->1, this makes the right adjoint of an S-null target
S-null. The derived discrete-index eliminator supplies the statement at
ordinary indices. The proved nullification mapping universal property
then gives the external universal property of exponentiating the unit.
Both endpoints of the canonical comparison are S-null, so testing mapping
types at those two endpoints proves that comparison an equivalence.

Finally, the chosen adjoint is eliminated out of the propositional
truncation defining Tiny into the proposition isEquiv of the fixed
comparison. No global choice of adjoints is required.

### Public API

- `CrispPropositions.Context.proposition-discrete` and `promote-proof`.
- `TinyLocalTypes.Context.Map.root-is-local`.
- `TinyNullificationCommute.Context.preserves-nullification`.
- `TinyNullificationCommute.Context.nullification-equivalence`.

<a id="tiny-nullification-families"></a>

## Tiny generator families and nullification colimits

The correspondence is with Myers,
[arXiv:2205.15887v1](https://arxiv.org/abs/2205.15887), Theorem A.0.9:
the pushout and sequential-colimit comparisons for nullification at a
crisp family of tiny types indexed by a crisply discrete type.

### Exact index and tinyness hypotheses

The module takes a native-crisp small index `Ix : Type₀` and a native-crisp
family `S : Ix → Type ℓ`. It takes the actual equivalence of the flat
counit on Ix, written `CrisplyDiscrete Ix`. The proof of that equivalence
may be ordinary.

Tinyness is given fiberwise at crisp indices:

```agda
TinyFamily = (@♭ i : Ix) → Tiny (S i)
```

This restriction respects the definition of the external tiny adjunction:
forming `Tiny (S i)` requires the type `S i` itself to be crisp. Each
`Tiny` is a mere existence assertion. No right adjoint is chosen for all
indices, either by ordinary choice or by countable choice.

The index restriction is a universe restriction, not a finiteness or
countability condition. Any small crisply discrete type is permitted.
The current implementation does not separately generalize the index to
a larger universe than `Type₀`.

### Ordinary indices are handled by a proved eliminator

The earlier actual nullification theorem needs exponential preservation
for every ordinary `i : Ix`. The new module derives an appropriate
eliminator from the counit equivalence:

```text
CrisplyDiscrete Ix →
(P : Ix → Type) →
((@♭ i : Ix) → P i) →
(i : Ix) → P i.
```

An ordinary index is mapped by the inverse counit to an actual value of
`Flat Ix`. Ordinary Flat elimination exposes its crisp representative;
transport along the counit's section equation returns the result at the
original index. This is a proved map. It adds no judgmental context-reset
or crisp-index assumption.

### Pushouts

For each crisp index, `TinyPushouts` derives the actual exponential
pushout comparison from a tiny-adjoint witness and the uniform ambient
crisp identity rule. Being an equivalence is a proposition, so ordinary
truncation elimination discharges the mere Tiny witness. The derived
index eliminator supplies preservation at every ordinary index.

`NullificationColimits.Pushout.preservation` then proves equivalence of
the actual canonical modal pushout comparison. No exponential comparison
or modal preservation remains among the inputs of the public theorem.

### Sequential colimits

The same construction uses `TinySequentialPreservation` for each crisp
index. That result derives Nat-nullness from the actual external
adjunction, R-flatness, and the previously named uniform crisp identity
and Flat-induction rules. It then proves the literal sequential
exponential comparison, including its HIT paths.

The index eliminator supplies the corresponding statement at every
ordinary generator. The already checked nullification theorem yields
equivalence of the canonical modal sequential comparison.

The public APIs are

```text
Context ... R Ix S.Pushout f g.preserves-pushout
Context ... R Ix S.SequenceColimit X.preserves-sequence.
```

The first needs the index counit equivalence and fiberwise Tiny. The
second additionally uses R-flat. Uniform structural rule parameters
remain visible in the surrounding module. The conclusions use exactly
the comparison maps from `ModalEtalePushouts` and `ModalEtaleSequences`;
they are not unspecified equivalences of endpoint types.

The proof concerns these two explicitly needed colimit cases. It does
not claim a formalization of arbitrary higher indexing diagrams. The
earlier crystalline specialization remains useful because it proves
Nat-nullness directly and therefore uses fewer structural assumptions.

<a id="tiny-localization-truncation"></a>

### Checked coverage

The following six modules are accepted by the pinned Agda 2.8.0.2 kit,
with the safe, Cubical, guardedness, no-import-sorts, and cohesion flags:

- `LocalizationUniversal.agda`
- `TinyLocalizationCommute.agda`
- `TinySpheres.agda`
- `SphereNullification.agda`
- `TinyTruncation.agda`
- `TinyDeloopings.agda`

They formalize Theorem A.0.7 and Corollary A.0.8 of
[Myers, arXiv:2205.15887v1](https://arxiv.org/pdf/2205.15887), printed page
67, in the explicitly specified ambient setting below. The conclusions
are proved from actual external Tiny data and actual library HITs.

### General localization: A.0.7

For a native-crisp family of maps F(i):P(i)->Q(i), the theorem proves
that the canonical map

Localize F (T -> X) -> (T -> Localize F X)

is an equivalence for every native-crisp X. Its definition is the
localization recursor applied to the pointwise unit. The inverse
equivalence gives the orientation printed in the paper.

The index I, P(i), Q(i), T, X, and the cohesive generator R inhabit a
common universe Type l. The family, maps, index, T, R, and a point r0:R
are native-crisp. The remaining hypotheses are:

- the existing uniform crisp identity induction rule at l;
- R-flatness, as equivalence of the actual Flat-counit and constant-map
  equivalence predicates on crisp types;
- the actual Flat counit equivalence for I;
- T-nullness of P(i) and Q(i) at every crisp index;
- mere Tiny T, using the project's externally quantified adjunction.

The proof establishes a stronger result than the printed sufficient
conditions: sequential compactness of the endpoints and T-nullness of I
are not needed. It uses the localization universal property directly,
rather than constructing a sequential presentation. No resizing or
cross-universe Tiny-adjoint principle is assumed.

`TinyLocalTypes` first proves that the external right adjoint of a local
target is local. It applies external covariant Yoneda to the actual
precomposition map, with explicit currying/product comparisons and
naturality. `CrispPropositions` supplies the needed promotion of ordinary
proofs of crisp propositions, derived from R-flatness and r0. A ring's
zero element supplies this point in the geometric application.

`LocalizationUniversal` fills a missing library foundation: it proves
that restriction along the actual localization unit is an equivalence
for local targets. Its dependent eliminator assumes equivalence of
restriction on sections along every generating Q-diagram. It does not
incorrectly substitute ordinary fiberwise locality, which would amount
to treating every localization as a modality. This relative condition is
proved for the path family between two maps into a local target. The
higher `equiv-ext` constructor and its square coherence are handled with
the actual dependent-path equivalence and its section law.

These two ingredients give the external universal property of the
powered unit. Both ends of the canonical comparison are local, so the
two endpoint tests of external Yoneda prove it an equivalence. Mere
Tiny is eliminated into the proposition isEquiv of that fixed map.

### Truncation consequence and connectedness

`TinySpheres` derives T-nullness of every lifted finite sphere. Evaluation
at the empty target already rules out a T-indexed empty function.
Suspensions are presented as actual crisp pushouts, so Bool and then all
finite spheres follow from tiny pushout preservation. The existing
small-universe crisp identity/Flat-induction/computation rules prove
Nat discreteness, allowing the crisp successor statements to be assembled
by ordinary induction. Neither R-flatness nor Nat-nullness is assumed
in this sphere lemma.

`SphereNullification` proves that the actual nullification HIT at the
lifted n-sphere is equivalent to the library's h-level (n+1) truncation.
Both maps preserve the unit; both inverse laws use the respective
eliminators. This presentation and the nullification commutation theorem
show that the ordinary canonical map

trunc_n(T -> X) -> (T -> trunc_n(X))

is an equivalence. Its agreement with the transported presentation is
proved by truncation elimination. The theorem holds for every ordinary
natural n, while X remains native-crisp. The zero case is treated
directly.

Cubical uses h-level indexing: 0 is contractible truncation, 1 is
propositional truncation, and 2 is set truncation. Conventional
k-truncation and k-connectedness therefore correspond to index k+2.
Contractibility of the powered truncation now proves preservation of
connectedness, exactly as required by A.0.8.

### Deloopings

`TinyDeloopings` proves pointed equivalences commuting every iterated
loop space with an unpointed function type. Given a crisp pointed
k-connected (k+1)-fold delooping of a crisp pointed group G, it constructs
such a delooping of T->G, with space T->B^(k+1)G. Its required
connectedness is derived from `TinyTruncation`; it is not an additional
premise. The iterated loop identification is a pointed equivalence.

The single-delooping case is also instantiated for the project's
existing `Quotients.Delooping` representation. Its connectedness is mere
path existence, recovered from the checked connectedness theorem, and
its loop type is explicitly equivalent to T->Loop G.

### Public entry points

- `TinyLocalizationCommute.Context.preserves-localization`
- `TinyLocalizationCommute.Context.localization-equivalence`
- `TinyTruncation.Context.preserves-truncation`
- `TinyTruncation.Context.preserves-connectedness`
- `TinyDeloopings.Context.power-delooping`
- `TinyDeloopings.Context.HigherGroup.power-higher-group`

<a id="tiny-set-surjections"></a>

### Checked theorem

`TinySetSurjections.agda` and `SetCoequalizerPresentation.agda` are
accepted by the pinned Agda kit, exit code 0 without warnings.

For native-crisp A, B, T, and f:A->B, the public theorem proves

isSet B -> isSurjection f
      -> isSurjection (fun h -> f o h : (T -> A) -> (T -> B)).

The sethood and original surjectivity proofs are ordinary. Source
sethood is not required. Tiny T is mere Tiny, not a globally chosen
adjoint. The surrounding context contains the same structural inputs
as `TinyTruncation`: crisp identity induction at the working universe,
small-universe identity/Flat induction/computation for Nat discreteness,
and a pointed crisp cohesive generator R with R-flatness.

The actual API is

TinySetSurjections.Context
      rules identity-zero flat-zero flat-zero-computation R r0 T
      .preserves-surjection real-flat tiny f setB surjective.

All types occupy the common working universe. The result applies in
particular to the crisp arrow-to-image map in the proper groupoid work.
It does not assert that arbitrary ordinary fibers of a crisp map are
crisp, or apply the crisp-type connectedness theorem to such fibers.

### Proof

For f:A->B, form the actual kernel pair

Kernel = sum (a:A) (a':A). f a = f a'

and its two projections to A. `SetCoequalizerPresentation` proves that
the set truncation of their homotopy coequalizer is equivalent to B
whenever f is surjective and B is a set. The forward map sends each
quotient generator a to f(a). Injectivity follows by propositional
elimination from the kernel-pair edge; surjectivity follows directly
from the original surjectivity witness. This proof needs no choice.

Next, exponentiate the kernel-pair coequalizer diagram. The already
checked canonical tiny coequalizer comparison and canonical set-
truncation comparison, followed by postcomposition with the quotient
presentation, give an equivalence

setTrunc(Coeq(powered projections)) ~= (T -> B).

The point map from T->A into this set-truncated coequalizer is
surjective. The composite with the displayed equivalence agrees
*definitionally* with the literal postcomposition map h |-> f o h on
generators. Transporting surjectivity along this equality proves the
claimed powered surjection.

There is no need to identify the powered kernel pair separately with
the kernel pair of the powered map. The explicit quotient presentation
and agreement of the canonical point maps already give the result.

<a id="tiny-null-coherent-colimits"></a>

### Checked result and entrypoint

The final A.0.9 construction is in the accepted aggregate:

`Orbifolds.Coherent.TinyNullHomotopyCoherentColimits.Context.Proof.comparison-equivalence`

Write N for the native HIT nullification at S, and Bar for the actual
constructed coherent bar colimit. For a diagram D in the explicit
quasi-unital HCD model, the theorem constructs

comparison : Bar(reflected D) -> N(Bar D)
    comparison-equivalence : Bar(reflected D) ≃ N(Bar D).

The reflected diagram is constructed in every degree; its vertex at x is
literally N(D x). Its action cubes and native unit transformation are derived
using actual dependent nullification extensions. The result is not a theorem
about a record that assumes colimit preservation or its desired presentation.

The canonical tiny-power comparison A.0.5 for these complete colimits is documented with its exact hypotheses in [Tiny power colimits](tiny-colimits.md#tiny-power-coherent-colimits).

### Exact hypotheses

The final wrapper uses one common working universe ℓ. No resizing is used
or proved. Its signature has these native-crisp parameters:

| Input | Exact role |
| --- | --- |
| `C : Category ℓ ℓ` | The defined strictly Type-enriched indexing category |
| `D : HomotopyCoherentDiagrams.ForCategory.Diagram C` | All actual action cubes, face equations and an inner unit homotopy |
| `Ix : Type₀`, `S : Ix -> Type ℓ` | The small family of nullifying types |
| `R : Type ℓ`, `r₀ : R` | The pointed type used by the stated R-flat proposition rule |
| `CrispIdentityInduction` at ℓ and zero | The explicit crisp identity rules used by the primitive preservation results |
| `CrispFlatInduction` and its `CrispFlatComputation` at ℓ and zero | The explicit lawful crisp Flat elimination rules |
| `E : StrictCubicalExtensionality ℓ` | Strict extensionality for interval functions and endpoint-typed paths |
| `F : StrictFunctionExtensionality ℓ` | Strict dependent extensionality for ordinary inner functions |

Inside this context, the proof takes the following displayed properties:

- `PP.Context.RealFlat R r₀` at the working universe.
- `CrisplyDiscrete Ix`.
- `(@♭ i : Ix) -> TT.External.Tiny (S i)`.
- `CrisplyDiscrete (Category.Obj C)`.
- `(@♭ x y : Category.Obj C) -> CrisplyDiscrete (Category.Hom C x y)`.

Tinyness is the existing external adjunction notion; no chosen adjoint is
an additional theorem parameter. Crisp discreteness is a genuine external
index condition. It is not inferred from native crispness. In particular,
CrisplyDiscrete Ix supplies the ordinary-index elimination used with the
crisp-generator tiny hypothesis.

The E and F records are explicitly named two-level structural rules. They
are not global postulates and are not derived from ordinary Cubical funext.
The theorem neither constructs a cohesive model satisfying all these rules
nor proves equivalence with every other infinity-category representation.
The external model-comparison references in coherent-diagrams.md#coherent-diagram-boundary
are guidance, not imported unchecked Agda terms.

### Actual maps and computations

Let A = Bar(D), B = Bar(reflected D), and let
u : A -> B be `unit-colimit-map`, the actual induced map of the constructed
all-degree unit transformation. The comparison comes with paths

comparison o u = η_A
    comparison (inverse a) = a
    inverse (comparison b) = b
    inverse (η_A a) = u a.

The first is a path of complete functions. It is the unit triangle for the
actual induced colimit map, not only a calculation on vertex generators.

For every vertex x, write ι_x : D x -> A and
ι'_x : N(D x) -> B for the actual source and target generators. The final
`generator-computation` proves, for every a : N(D x),

comparison (ι'_x a) = Null.rec isNull-Null (η_A o ι_x) a.

This includes all nullified vertex elements, not only points of the form
η(a). The separate `generator-unit-computation` records that special case.

### Proof structure

1. The exact unit transformation induces full restriction of coherent
   cocones into each null target Y. Its coefficient maps are precomposition
   by the native vertex units. Native nullification section universality
   makes these maps equivalences. The actual full cone-map theorem therefore
   makes the complete cocone restriction an equivalence, including all
   higher cells and every inverse-tower compatibility path. Tinyness is not
   needed for this part.
2. The canonical bar mapping universal property and its full target
   naturality transfer that equivalence to the actual function
   `(B -> Y) -> (A -> Y)`, k mapped to k o u. The proof uses the actual
   precomposition square, rather than assuming that the bar assignment is
   a functor with the desired mapping behavior.
3. The actual bar of a null-valued diagram is null under the tiny/discrete
   hypotheses. Its literal presentation consists of discrete-chain
   coefficient sums and quoted sphere-cell pushouts followed by the actual
   sequential colimit. Derived nullity of the chain indices and sphere
   coefficients, together with checked tiny-generator pushout and sequence
   closure, proves each stage and the final B null. Specializing the
   generic theorem to the constructed reflection supplies `colimit-null`.
4. The native reflection universal property and the preceding mapping
   equivalences construct comparison, inverse and both inverse laws. The
   unit triangle and vertex computations are retained throughout. This is
   the checked ordinary `NullificationComparisonInterface`, instantiated
   with derived facts about these actual bar colimits.

The final theorem assumes no arbitrary-diagram presentation, per-stage
preservation, desired cocone comparison, strict nullification functor laws,
outer-Nat cofibrancy or Flat distribution over an infinite product. All
compiler checks retain the unchanged pinned safe flags.

<a id="tiny-power-coherent-colimits"></a>

### Checked result and entrypoint

The canonical preservation wrapper is:

`Orbifolds.Coherent.TinyHomotopyCoherentCanonicalColimits.Context.colimit-equivalence`.

A.0.5 is relative to the exact hypotheses below.

The wrapper combines two independent branches:

- `TinyHomotopyCoherentBarColimits.Context.preserves-colimit` proves the
  actual literal cellular comparison equivalent from the tiny hypotheses.
- `HomotopyCoherentPowerBarCanonical.Construction.comparison-is-canonical`
  identifies that same comparison with the actual evaluation-induced map,
  retaining the complete coherent cocone paths.

Neither branch imports the other. The final wrapper transports isEquiv along
the whole-function identification while keeping the actual canonical map as
the first component of the equivalence.

### Specified map and conclusion

For a quasi-unital homotopy-coherent diagram D, write D^T for the actual
pointwise power diagram and Bar for the constructed coherent bar colimit.
The final map is fixed before its preservation proof:

κ : Bar(D^T) -> (T -> Bar(D))
    κ z t = Bar(evaluation at t) z.

Here Bar(evaluation at t) is the actual map defined by the complete bar
mapping universal property. The accepted
`HomotopyCoherentCanonicalComparisons.Power.comparison` is exactly κ.
The new wrapper uses that definition for its own `comparison`; it does not
replace κ by an unspecified equivalent map.

The theorem proves `isEquiv κ`, hence

Bar(D^T) ≃ (T -> Bar(D)).

The wrapper also exposes the evaluation equation, the full canonical
cocone triangle, vertex-generator computation, and both inverse laws of
the resulting equivalence. For the actual generators ι and ι^T, the vertex
formula is

κ (ι^T_x a) t = ι_x (a t).

The full triangle is a path in the complete coherent cocone type, which
includes every inverse-tower compatibility path. The theorem's canonical
claim is stronger than the generator formula alone.

### Exact hypotheses

The final wrapper uses one common working universe ℓ. It has these
native-crisp parameters:

| Input | Exact role |
| --- | --- |
| `C : Category ℓ ℓ` | The defined strict Type-enriched indexing category |
| `D : HomotopyCoherentDiagrams.ForCategory.Diagram C` | Actual action cubes in every degree, face equations and an inner unit homotopy |
| `T : Type ℓ` | The exponentiating type |
| `R : Type ℓ`, `r₀ : R` | The pointed type used in the recorded R-flat proposition rule |
| `CrispIdentityInduction` at ℓ and zero | Explicit crisp identity rules |
| `CrispFlatInduction` and `CrispFlatComputation` at ℓ and zero | Explicit lawful crisp Flat elimination rules |
| `E : StrictCubicalExtensionality ℓ` | Strict extensionality for interval functions and endpoint-typed paths |
| `F : StrictFunctionExtensionality ℓ` | Strict dependent extensionality for ordinary inner functions |

The final theorem arguments are exactly:

- `PP.Context.RealFlat R r₀` at the working universe.
- `TT.External.Tiny T`.
- `CrisplyDiscrete (Category.Obj C)`.
- `(@♭ x y : Category.Obj C) -> CrisplyDiscrete (Category.Hom C x y)`.

Tinyness uses the existing external adjunction notion, with Flat mapping
types. A chosen adjoint is not an additional theorem argument. Crispness
alone does not imply external index discreteness; the displayed object and
hom conditions are used to derive discreteness of the actual finite-chain
indices. These discreteness conditions are cohesive/Flat discreteness, not
0-truncation or `isSet` assumptions. Object and hom types can retain higher
homotopy, and the bar model retains every finite coherence degree. Vertex
values may be arbitrary higher types in the working universe. The point r₀ and both universe levels of structural rules remain
part of the signature.

No universe-resizing theorem or independent-universe preservation wrapper
is claimed here. The E and F records are explicit two-level structural
inputs, not global postulates or consequences of ordinary Cubical funext.
The chosen quasi-unital HCD model is over the stated strict enriched
category. No equivalence with every other infinity-category implementation
is formalized by this entrypoint; the external model guidance is recorded
in coherent-diagrams.md#coherent-diagram-boundary.

### Assembly and full coherence

The actual power HCD and its evaluation transformations are constructed by
transposing ordinary power arguments with the cube coordinates. Their
face laws are already checked. The original and powered bar presentations
are the actual sphere-cell presentations obtained from those diagrams.

At every finite stage, the checked power assembly constructs the map on
cell indices and coefficients by evaluation. Its successor is literally
the map of the cell spans followed by the primitive power/pushout
comparison. The initial map is `(x, a) -> (t -> (x, a t))`. Both attachment
squares and the next canonical cocone triangle are constructed from the
diagram data and the preceding triangle. The initial triangle is
reflexivity, and the entire state is advanced recursively.

`HomotopyCoherentPowerBarComparison` corecursively constructs the relative
presentation map from these actual states. `TinyHomotopyCoherentBarColimits`
derives local coefficient/boundary equivalences from the discrete chain
indices and tinyness, then applies the checked primitive pushout and
sequence preservation theorems. The final tiny theorem accepts no
presentation, stage comparison, triangle or preservation certificate as an
argument; those generic objects are instantiated by its own construction.

The canonical branch constructs a compatible family of paths through the
entire tower, including its transition squares.
`HomotopyCoherentPowerBarNaturality` constructs an actual square between
the successor and previous finite triangles, with the precise
representability transition paths as its endpoints.
`HomotopyCoherentPowerBarCanonical` stores those squares in a guarded
`CoinductiveTowerSquares` witness, then iterates it over ordinary naturals.
Its `powered-computation` and `restricted-computation` explicitly handle
both the stage values and the path-valued compatibility component. The
complete mapping universal property then identifies the literal map with
every actual evaluation-induced map and gives a path of whole functions.

The separate final wrapper transports `isEquiv` along that
whole-function path. This is the only bridge between the independent tiny
and canonical branches. It adds no mathematical hypothesis.

The selected finite interface stops at its proved `composite-prefix`.
`PowerBarCoherence` uses that composite and proves its own full
`canonical-prefix-coherence`, which Naturality consumes. This full power
coherence is mandatory; it is not supplied by assuming an unused generic
finite conclusion.
<a id="tiny-exhaustion-obstruction"></a>

## An unbounded exhaustion obstructs preservation by exponentiation

`src/Orbifolds/TinyExhaustionObstruction.agda` formalizes the algebraic
argument used to test tinyness of the full infinitesimal neighborhood.
It constructs the relevant cover and proves the obstruction without
assuming a semantic model or installing any tinyness or nilpotence axiom.

### The abstract data

Take a pointed type `K` with point `k₀`, and a family

\[
P:\mathbb N\to K\to\mathrm{Type}.
\]

The object and predicate-family universes are independent and explicit.
No monotonicity or propositionhood of `P` is required by the abstract
proof. For the intended infinitesimal example, `P(n,d)` is a
proposition asserting a nilpotence equation.

Define the actual covering type and projection by

\[
C=\sum_{n:\mathbb N}\sum_{k:K}P(n,k),
\qquad
q(n,k,p)=k.
\]

The module uses these three properties:

- **Exhaustion:** every `k` merely belongs to some stage:
  `∀ k, ∥ Σ n, P(n,k) ∥`.
- **Constant natural labels:** every function `label : K → ℕ` satisfies
  `label(k) = label(k₀)` for every `k`.
- **No uniform bound:** for every `n`, the function type
  `∀ k, P(n,k)` is uninhabited.

`projection-surjective` constructs a surjectivity witness for `q` from
the exhaustion. The converse is also proved, giving
`exhaustive≃surjective-projection`. In particular, the epimorphism at
issue is not supplied under an arbitrary name while its source and
surjectivity remain unspecified.

### A lift forces a uniform bound

Suppose there is an actual function `l : K → C` with
`q(l(k)) = k` for all `k`. Write its label as

\[
N(k)=\operatorname{fst}(l(k)).
\]

The constant-label property gives `N(k) = N(k₀)`. The remaining
components of `l(k)` give a point `k'`, evidence of `P(N(k),k')`, and
the triangle `k' = k`. Transport first along the triangle and then along
the label equality gives

\[
\prod_{k:K}P(N(k_0),k).
\]

This is the explicit `lift→uniform-bound` proof. It does not choose
stage labels from merely given pointwise exhaustion witnesses.

Now consider the actual exponentiated projection

\[
q^K:(K\to C)\to(K\to K),\qquad l\mapsto q\circ l.
\]

If `q^K` is surjective, its fiber above `id_K` is merely inhabited.
Mapping the preceding construction over this propositional truncation
produces a **merely** existing uniform bound. Conversely, a uniform
bound `(n,b)` lifts every self-map `f` by
`k ↦ (n,f(k),b(f(k)))`; this implication also descends from a merely
existing bound because surjectivity is a proposition.

The module therefore proves the precise equivalence

\[
\boxed{
\operatorname{isSurjection}(q^K)
\simeq
\left\|\sum_{n:\mathbb N}\prod_{k:K}P(n,k)\right\|
}
\]

under the constant-label hypothesis. Its declaration is
`Exhaustion.power-surjective≃mere-uniform-bound`.

Combining exhaustion with unboundedness gives an explicit surjective
`q` whose exponentiation is not surjective. The exported
`exhaustion-epi-not-preserved` returns both proofs.
`no-preservation-of-exhaustion` refutes the proposed preservation
implication for this particular map.

### Deriving constant labels from double-negation nearness

The condition

\[
\prod_{k:K}\neg\neg(k=k_0)
\]

is sufficient. For a function from `K` to any type with decidable
equality, decide whether the value at `k` equals the value at `k₀`.
The negative case would turn any equality `k=k₀` into a contradiction,
contradicting double-negation nearness. Hence the values are equal.

`near→constant-discrete` proves this for every decidable target.
`near→constant-naturals` specializes it to the standard decidable
equality of the natural numbers. The corollaries
`near-exhaustion-epi-not-preserved` and
`near-no-preservation-of-exhaustion` then expose the version needed for
an infinitesimal neighborhood of zero.

This reasoning does not assert that every `k` equals `k₀`. It only
forces functions into a decidable target to be constant.

### Application to a candidate infinitesimal model

For the proposed Cahiers application, take `K` to be the full
double-negation neighborhood of zero and let

\[
P(n,d)\equiv d^{n+1}=0.
\]

The following are **additional semantic obligations**, not assumptions
silently proved by the new Agda file:

1. Identify that full neighborhood in the chosen model.
2. Establish the exhaustion by the finite nilpotence stages as an
   internal surjection, including arbitrary generalized contexts.
3. Establish that no one exponent bounds the entire neighborhood,
   again with the contextual meaning of negation.
4. Connect the proposed tinyness/right-adjoint structure to preservation
   of this surjection by exponentiation.

The last implication has an existing internal counterpart:
`TinySetSurjections.Context.preserves-surjection` derives preservation
for a crisp map with set codomain from its explicitly displayed tiny,
R-flat and crisp structural assumptions. Applying that theorem requires
checking its hypotheses and universe instances; the abstract exhaustion
module does not add those assumptions to its own statement.

In a categorical model, an exponential functor with a right adjoint is
a left adjoint and preserves the relevant colimits. Preservation of
effective epimorphisms then supplies the comparison being refuted.
The candidate-model argument and its precise site assumptions are
developed separately in
`external-models.md#cahiers-full-neighborhood-nontiny`.

### Why unboundedness is stated as a negated universal

`NoUniformBound` is

\[
\prod_{n:\mathbb N}\neg\left(\prod_{k:K}P(n,k)\right).
\]

It is not the stronger assertion
`∀ n, ∃ k, ¬ P(n,k)`. These differ constructively, and the stronger
assertion can be inappropriate for synthetic infinitesimals.

For example, a new Weil disk with a free formal coordinate can refute a
purported universal equation `d^(n+1)=0` after base change. That need
not supply a globally selected infinitesimal, or an internally nonzero
infinitesimal. An external calculation at a larger test stage must be
used with the correct contextual interpretation of the negated
universal statement.

The formal proof eliminates a merely existing uniform bound only into
the empty proposition. It introduces no countable or global choice
principle.

### Scope of the obstruction

Once the semantic obligations hold, the theorem rules out tinyness of
that full unbounded object in that model. It does not rule out tinyness
of each individual finite Weil disk, does not show that every
differential-cohesive setting is inconsistent, and does not transfer an
exhaustion claim from one candidate site to a different site.

In particular, existence of separately tiny bounded infinitesimals
would not by itself establish tinyness of their full unbounded
neighborhood. This is a distinct obstruction from the classical
properness comparison addressed in
`properness.md#external-properness-obstruction`.

