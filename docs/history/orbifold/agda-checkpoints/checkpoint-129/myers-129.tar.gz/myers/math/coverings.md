# Coverings

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="finite-coverings"></a>

## Finite fibers give actual covering maps

`CrispFiniteModal.agda`, `CrispConnectedNullity.agda`, and
`FiniteCoverings.agda` have passed canonical safe native-kit checks with
cohesion enabled, exit status zero and no warnings. The result supplies
the covering assertion needed in the finite-configuration classification
of [Section 3.3](https://arxiv.org/html/2205.15887v1#S3.SS3).

`FiniteCoverings.Context.finite-fibers-etale` takes an ordinary natural
number `n`, an ordinary map `π : Y → A`, and ordinary witnesses

`(a : A) → ∥ fiber π a ≃ Fin n ∥₁`.

It proves that the original map `π` is etale for the actual
`ShapeOne.Ring.ShapeOneModality`. The companion `finite-fibers-sets`
proves that its actual fibers are sets. Together these are the paper's
covering-map criterion. Finiteness is not redefined to contain an
etaleness conclusion.

### Exact universe assumptions

The ring, base, total space, and fibers lie in `Type ℓ`. The context takes
a native-crisp commutative ring, native-crisp `CrispIdentityInduction` at
both `ℓ` and `ℓ + 1`, and ordinary R-flat inputs at those two target
universes. The upper input is stated explicitly as

`(@♭ X : Type (ℓ + 1)) → CrisplyDiscrete X ≃ isEquiv (const : X → (R → X))`.

Here `R` is the same lower-universe real carrier; it is not silently
replaced by an unrelated higher-universe ring. The lower R-flat input
has the same form for crisp `X : Type ℓ`. No upper instance is inferred
from the lower one, and no universe resizing is used. The precise two
instances remain visible in the theorem signature.

The finite number, map, base, total space, and finite-fiber witnesses
need not be crisp. There is no crisp excluded middle, tiny generator,
crisp pullback preservation, Kock-field, or desired finite-cover premise.

### Construction

`CrispFiniteModal` first proves that every ordinary finite small type is
R-null. For a crisp finite ordinal, the checked `CrispCountable` rule
provides a mere preimage under its actual flat counit for every element.
R-flatness on crisp proposition-valued identity types, together with the
crisp identity equivalence, makes the same counit an embedding. Its
surjectivity and embedding property therefore make it an equivalence.
R-flat converts this to R-nullity. Native natural-number induction
removes the crispness restriction on the ordinal size, and mere finite
equivalences transport the result to an arbitrary finite type.

`CrispConnectedNullity` makes the earlier connected crisp separated-type
argument explicit across different generator and target universes.
It proves nullity of a crisp pointed connected type from nullity of all
its identity types, using the target-universe R-flat input and identity
rule. It does not supply an unrestricted context reset.

For a fixed crisp numeral, `FiniteCoverings` uses the actual
`ConfigurationBundles.Labels` exemplar type

`Σ[ E ∈ Type ℓ ] ∥ E ≃ Lift (Fin n) ∥₁`.

This type is pointed and merely connected. Its identity types are
equivalent, by univalence and the propositional subtype witness, to
equivalences between its actual finite carriers. The finite-nullity
result and nullification's closure properties make those identity types
R-null. The cross-universe connectedness argument therefore proves the
exemplar itself R-null. Its carriers are sets, so univalence also proves
that the exemplar is a groupoid.

The module derives nullity of this actual exemplar for both generators
of `ShapeOne`, including an explicit equivalence between the lifted
spheres at the two universe levels. Cross-universe nullification
recursion extends the original finite-family classifier to the actual
fundamental-groupoid reflection. Its underlying family has modal finite
fibers, and its restriction along the actual unit is judgmentally the
original fiber family.

The checked reflected-family theorem now proves the restricted first
projection etale. The actual fiber-total-space equivalence identifies
the original map `π` with that projection, so equivalence invariance
gives etaleness of `π` itself. Finally, native natural-number induction
allows ordinary `n` in the exported theorem.

The configuration-map classification is assembled separately. These modules establish the geometric covering conclusion for its actual finite-fiber maps.
<a id="shape-coverings"></a>

## Classification of actual covering maps

`ModalEtaleClassification.agda`, `ModalCoveringClassification.agda`, and
`ShapeCoverings.agda` have passed canonical safe native-kit checks with
cohesion enabled, exit status zero and no warnings.

`ShapeCoverings.Ring.Base.covering-classification` proves
[Theorem 3.2.4](https://arxiv.org/html/2205.15887v1#S3.SS2) for the actual
fundamental-groupoid modality constructed in `ShapeOne`:

`Coverings X ≃ (shape₁ X → DiscreteSets)`.

`Coverings X` is the literal type of a small total type `Y`, an ordinary
map `π : Y → X`, a proof that its actual shape₁ naturality square is a
pullback, and proofs that its actual homotopy fibers are sets. It is
not defined to mean the existence of a classifier or an action.
`DiscreteSets` is the type of small types with both shape modality and
sethood. No crispness is imposed on `X`, its covering map, or its
classifier family.

### The associated covering is the stated projection

Given `P : shape₁ X → DiscreteSets`, `AssociatedTotal P` is exactly

`Σ[ x ∈ X ] P (η₁ x) .fst`.

`associated-projection P` is exactly `fst`. The domain and projection
formulas for `associated-cover P` are judgmental equalities, exported
with proofs by reflexivity. Its shape₁-etaleness and set fibers are
proved, and both inverse laws for `classify` and `associated-cover` are
provided. `fiber-at-unit` identifies each original homotopy fiber with
the classifier's value at the image of its original base point.

The type `shape₁ X` and the map `η₁` are the actual simultaneous
nullification construction. The modal objects are proved to be exactly
shape-modal groupoids in `ShapeOne`, as documented in
`differential-geometry.md#universal-cover-microlinear`, including its explicit sphere-indexing
note. No independent desired fundamental-groupoid or covering-classifier
axiom is used here.

### Generic proof and its set-fiber restriction

`ModalEtaleClassification` works for any supplied modality `M` in a fixed
universe. It classifies the literal type of `M`-etale maps over `X` by
modal-valued families over `M X`. For an etale map `π`, the classifier
is the actual fiber family of `M π`. For a modal family on `M X`, the
associated map is the first projection after restriction along the
actual unit of `X`.

The already checked reflected-family theorem computes the reflection of
this total space. Its comparison preserves the first projection
judgmentally, so the equivalence of its fibers with the original family
is explicit. This proves one inverse law. For the other, the actual
unit-square gap map of `π` is an equivalence by its etaleness witness.
Univalence gives a path of total types over `X`, retaining the projection;
the etaleness proof is propositional, so this gives equality of the
literal structured maps. No equality of unstructured total-space types
is substituted for equality of maps over the base.

`ModalCoveringClassification` restricts this equivalence to maps with
set fibers. It assumes only surjectivity of the actual unit of the
specific base `X`. The fiber equivalence gives sethood of the classifier
at every unit point. Mere unit surjectivity extends this property to all
reflected points by elimination into the proposition expressing sethood.
The reverse direction uses the actual fibers of a dependent-sum first
projection. Both inverse laws remain equalities of the fully structured
covering data.

`ShapeCoverings` instantiates this theorem at `ShapeOne`, whose actual
unit surjectivity is already proved from its generators. For sets,
shape₁ modality is equivalent to ordinary shape modality because their
groupoid truncation is automatic. This identifies the generic modal-set
classifiers with the paper's discrete sets.

### Assumptions

All ring, base, total-space, and fiber types lie in one fixed `Type ℓ`.
The classifier universe lies in `Type (ℓ + 1)`, but no modality or R-flat
assumption is applied at that larger universe. The construction needs
only the ordinary commutative ring supplied to `ShapeOne`; its chosen
zero makes the real generator inhabited. It needs no crisp identity
rule, crisp excluded middle, R-flat, tiny generator, pullback-preservation
postulate, resizing, or chosen section of a surjection.

The generic realization-etaleness and other proposition-valued proof
certificates are checked abstract declarations. Their abstraction
prevents unnecessary normalization when the generic theorem is applied
to a concrete higher inductive modality; the actual total types,
classifier maps, and associated projections remain transparent.

<a id="configuration-bundles-scope"></a>

## Maps into finite configuration spaces

Primary statement: Myers, Proposition 3.3.1,
<https://arxiv.org/html/2205.15887v1#S3.SS3.Thmthm1>.
The underlying configuration is the actual construction in Example 2.4.4,
<https://arxiv.org/html/2205.15887v1#S2.SS4.Thmthm4>.

`ConfigurationBundles.agda` proves the complete univalent fibration
calculation: a map `A → Configuration n X` is equivalent to an actual
total type `P`, an actual map `π : P → A`, mere equivalences of every
literal fiber with `Fin n`, and an actual map `P → X`.

The configuration space is a genuine homotopy quotient. Its symmetry
delooping is the type of types merely equivalent to the lifted finite
ordinal; the action family sends such a type `E` to `E → X`.
Connectedness of this delooping is proved, and its loop type is proved
equivalent to the actual permutation type of the ordinal. No finite
set quotient replaces the homotopy quotient. The code also proves
the covariant function-family transport formula with inverse carrier
transport, so it does not use the incorrect formula in Lemma 2.2.12.

The main pure theorem is
`Finite.Over.maps-to-configuration≃finite-bundles`. The base `A` need
not be a set. `X` can lie in an independent universe. The finite
ordinal is lifted only to give an explicit point of the universe of
small carriers; the output's finite-fiber condition is stated with
the actual SumFin ordinal `Fin n`.

The finite-fiber calculation does not itself include “covering” in the
input data. Definition 3.2.2 requires actual shape-one etaleness as well as
set fibers. The modal finite-family-to-covering bridge is a separate
construction in this chapter; the pure calculation alone is not the whole
cohesive covering statement.

<a id="configuration-coverings-scope"></a>

## Full finite configuration covering theorem

`ConfigurationCoverings.agda` completes Myers, Proposition 3.3.1:
<https://arxiv.org/html/2205.15887v1#S3.SS3.Thmthm1>.

Its final theorem is
`Context.Number.maps-to-configuration≃nfold-coverings`. It proves an
equivalence between maps `A → Configuration n X` and the actual type
of `n`-fold coverings of `A` equipped with a map from their total
space to `X`.

### Literal covering structure

The covering type is `ShapeCoverings.Ring.Base.Coverings`, whose data
are an actual small total type `P`, a map `π : P → A`, a proof that
`π` is etale for the actual shape-one nullification modality, and
sethood of every literal homotopy fiber. This is Definition 3.2.2,
not a renamed type of finite-fiber maps.

`ConfigurationBundles.agda` already proves the complete pure
classification with finite fibers. The accepted
`FiniteCoverings.Context.finite-fibers-etale` theorem derives the
covering property for those maps. Its proof extends their actual
finite-type classifier along the actual shape-one unit, using the
proved modality of the finite-type exemplar. The present source
instantiates that theorem, adds the resulting covering structure,
and proves that forgetting it is inverse. Its uniqueness follows
from propositionhood of the etaleness and sethood proofs, not from
truncating the bundle or map data.

The finite-fiber witness is precisely
`(a : A) → ∥ fiber π a ≃ SumFin.Fin n ∥`. The cardinal `n`, base `A`,
and target `X` may be ordinary, noncrisp parameters. No sethood of
the base or target is required. The target has an independent
universe parameter.

### Exact foundational inputs

The context exposes a native-crisp commutative ring `R`, crisp identity
induction at the carrier universe and its successor, and R-flat
comparisons at both of those universes. The upper comparison uses
the same real carrier as generator. These are the exact cohesion
inputs needed to prove the modality of the actual universe-level
finite-type classifier. There is no global excluded middle, no
choice of finite enumerations, no resizing axiom, and no assumed
covering conclusion. No Kock-Lawvere or analytic premise is used.

This completes the modal step left separate in
`coverings.md#configuration-bundles-scope`; the pure source alone still has
exactly the scope stated there.

<a id="shape-quotients"></a>

## Shapes of actual action quotients

`ModalSigmaReflection.agda` and `ShapeQuotients.agda` have passed the
canonical safe native-kit check with cohesion enabled, exit status zero.

`ShapeQuotients.Ring.Action.ConnectedFibre` proves
[Theorem 3.2.7](https://arxiv.org/html/2205.15887v1#S3.SS2): the actual first
projection from the family-action quotient to its shape-modal delooping
is a shape unit when the actual fiber at the chosen base point is
shape-connected. The group is supplied by the existing pointed,
merely connected `Quotients.Delooping`; the action is its actual type
family, and its quotient is the existing dependent-sum construction.

The exported `comparison` is the actual modal recursor extending the first
projection. `projection-is-shape-unit` proves it an equivalence.
`comparison-unit` gives its triangle on every total-space point.
`orbit-point-triangle` identifies the image of every orbit representative
with the chosen delooping point. If an actual fiber point is supplied,
`pointed-shape-quotient-equivalence` returns an actual pointed equivalence.
No representative is selected from connectedness, and no inhabitedness of
the original fiber is added.

The proof is generic in a modality and then instantiated at the actual
`Crystalline.Ring.ShapeModality`. It needs no crisp hypothesis: the exact
assumptions are a modal delooping and connected reflection of the fiber at
its base point. Mere path connectedness of the delooping transports that
proof to all twisted fibers by elimination into a proposition.

The supporting `ModalSigmaReflection` computes reflection of a dependent
sum over a modal base by reflecting its fibers. It constructs both
directions and inverse laws and verifies the comparison over the original
base. Consequently, `reflected-quotient-equivalence` also computes the
reflected action quotient over an **already modal** delooping, with its
canonical fiberwise-unit triangle.

That latter computation is only the discrete-delooping special case of
Theorem 3.2.8. Full 3.2.8 allows an arbitrary crisp higher group and requires
descent of the reflected action to the reflected delooping, together with
identification of its loops with the reflected group. Those obligations
are not assumed or claimed by these two modules.

All types lie in a fixed `Type ℓ`.
<a id="crisp-shape-quotients"></a>

## Shapes of quotients by arbitrary crisp higher groups

The new modules `CrispConnectedModal.agda`, `CrispShapeDeloopings.agda`, and
`CrispShapeQuotients.agda` have each passed the canonical safe native-kit
check with cohesion enabled, exit status zero and no warnings. They use
the separately checked `SuspensionNullity.agda`.

`CrispShapeQuotients.Context.Action` supplies the full crisp-group case of
[Theorem 3.2.8](https://arxiv.org/html/2205.15887v1#S3.SS2), complementing the
already checked Theorem 3.2.7 in `ShapeQuotients.agda`. The latter file is
unchanged. No hypothesis that the original delooping is shape-modal is
required by the new theorem.

### Exact inputs and outputs

The context takes a native-crisp commutative ring `R : CommRing ℓ`, the
native-crisp structural rule `CrispIdentityInduction` at that same level,
and the ordinary `RealFlat` equivalence between discreteness of a crisp
type and nullity for the constant-map comparison out of the carrier of
`R`. The chosen zero of the ring supplies a crisp point. No additional
ordered-ring, field, infinitesimal, or compactness assumptions are used.

The higher group is an actual native-crisp `Quotients.Delooping ℓ`: its
base is pointed and merely connected. The action is an ordinary family
`A : BG → Type ℓ`; the action itself need not be crisp. The original
quotient is the existing family-action dependent sum `Σ BG A`, and the
original group is the loop type of the chosen base point.

The construction returns the actual reflected delooping with underlying
base `shape BG`, base point `η point`, and a proved mere connectedness
witness. It proves a canonical equivalence

`shape (Loop G) ≃ Loop ReflectedGroup`

with its triangle on every original loop and its pointed equivalence.
Thus the new action really is an action of the reflected higher group;
an arbitrary equivalent type has not been substituted for the group.

Its action family `Descended : shape BG → Type ℓ` consists of shape-modal
types and satisfies `Descended (η b) = shape (A b)` judgmentally. Its
fiber at the reflected base point is judgmentally `shape (A point)`.
The exported `unique-reflected-action` proves contractibility of the
fiber of the actual restriction map on modal-valued families at the
actual family `b ↦ (shape (A b), modal witness)`. This is coherent
uniqueness of the reflected action together with its unit identification.
It does not assert that arbitrary unstructured actions are determined
by an equivalence between their quotient types.

The main result is the canonical equivalence

`shape (Σ BG A) ≃ Σ (shape BG) Descended`.

Its forward map is the actual shape recursor extending
`(b , a) ↦ (η b , η a)`. The module supplies both inverse laws, the
triangle on every original total-space point, compatibility with the
reflected first projection, the triangle on orbit representatives, and
the induced pointed quotient equivalence when an actual original fiber
point is supplied. It also proves that the original fiberwise unit
intertwines the old action with the new action, both along `cong η g`
and along the canonically identified reflected group element `η g`.

### How the descent is proved

`CrispConnectedModal` proves that a crisp pointed connected type whose
identity types are shape-modal is itself shape-modal. Connectedness
makes its actual `Flat` counit surjective. The derived flat identity
equivalence and `RealFlat` on crisp path types make that counit an
embedding. The equivalence criterion for an embedding and a surjection
then makes the counit an equivalence; `RealFlat` converts this result to
shape modality. Connectedness is eliminated only into a proposition, so
no global choice of paths or unjustified promotion of an ordinary type
to a crisp type occurs.

`SuspensionNullity` identifies nullity for `Susp R` with nullity of all
identity types for `R`, using the actual constant-map comparisons. Its
actual higher inductive `Null (Susp R) X` has null identity types and
preserves pointed mere connectedness.

For a crisp pointed connected `X`, `CrispShapeDeloopings` therefore proves
that this actual separated reflection is shape-modal and constructs
`Null (Susp R) X ≃ shape X`, with the canonical unit triangle and both
inverse laws. The universe of small shape-modal types has shape-modal
identity types by the library's checked nullification theorem. It is
therefore `Susp R`-null, and cross-universe nullification recursion
extends every small modal-valued family from `X` to its separated
reflection. The equivalence just constructed transfers that universal
property to the actual `shape X`.

This use of a universe in `Type (ℓ + 1)` requires no resizing and no
upper-universe instance of `RealFlat`: the universe's suspension-nullity
is proved directly, and the nullification recursor allows its target at
that level. The only use of the crisp connectedness argument is on the
small separated reflection in `Type ℓ`.

The same construction descends the actual reflected based-path family.
Two stages of shape induction prove its total space contractible. The
checked identity-recognition theorem then identifies the descended path
codes with the actual paths of `shape X`, yielding the canonical loop
equivalence and its computation law. Finally, two stages of shape
induction construct the quotient comparison inverse and both inverse
laws.

All object, group, and action-fiber types lie in one fixed `Type ℓ`.
There is no additional desired family-descent, separated-reflection,
loop-preservation, sharp-adjunction, tinyness, or lexness premise.

