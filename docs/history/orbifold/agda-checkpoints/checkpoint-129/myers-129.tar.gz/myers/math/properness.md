# Properness

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="properness-scope"></a>

## Literal Dubuc–Penon properness and the main theorem

The checked properness hypothesis has a strong internal consequence: it
decides whether each fiber is inhabited. For a diagonal of a set, literal
Dubuc–Penon properness is equivalent to decidable equality. These facts
provide a new proof route for the internal main theorem, and also expose a
separate limitation in its comparison with external, classically proper
Lie groupoids.

`ProperCompactDecisions.agda` and `ProperEtaleDiscreteness.agda` do not postulate decidable hom equality or add a foundation field for it.

### Exact source definition and quantification

The source is Myers, [arXiv:2205.15887v1, Definition 6.2.1](https://arxiv.org/html/2205.15887v1).
Its compactness condition quantifies over propositions `A` and families
`B : K → Prop`. Its properness condition tests every compact subtype of
the codomain. Neither clause restricts those inputs to crisp ones.
Definition 6.3.6 applies that properness condition to the source–target
map, and Theorem 6.3.7 concerns the Rezk completion of a crisp presentation.
Crispness of the presentation does not change the internal quantifiers in
its properness predicate.

The existing `ProperMaps.agda` retains that subtype-based definition:

```agda
DPProper f =
  (U : Y → hProp ℓ) → DPCompact (Subtype U) → DPCompact (Preimage f U)
```

All types in this display are in the explicit universe of the formalization.
`Compactness.agda` also exposes the tested proposition universe through
`DPCompactAt`; these new results use the same-universe specialization
`DPCompact`. No proposition-resizing principle is introduced.

For a set codomain, singletons are genuine proposition-valued subtypes.
The existing proof `proper→CompactFibers` therefore gives compactness of
every ordinary fiber, including fibers at ordinary, varying points. Its
converse `compactFibers→Proper` needs no sethood assumption. The set-codomain
hypothesis is explicit throughout the new diagonal and source–target
arguments.

### Compactness decides mere inhabitation

`ProperCompactDecisions.compact-inhabitation-decidable` proves

```agda
DPCompact K → Dec ∥ K ∥₁
```

The proof sends `K` onto its propositional truncation. Compactness is
preserved by this actual surjection, and the already checked equivalence
between compactness and decidability for propositions then applies.
This decides mere inhabitation; it does not select an element of `K`.

Consequently, for `f : X → Y` with `Y` a set, the checked theorem
`proper-image-decidable` has type

```agda
isSet Y → DPProper f → (y : Y) → Dec ∥ fiber f y ∥₁
```

In the category presentation, properness of `(source,target)` therefore
decides `∥ Hom x y ∥₁` for every ordinary `x` and `y`.
`Groupoid.proper-orbit-decision` gives this exact result without using
groupoid inverses. The later lifting proof uses identity arrows. The additional
`proper-orbits-penon-open` theorem turns the resulting decidable orbit
predicate into a Penon-open predicate by explicit case analysis.

### The diagonal diagnostic is an equivalence

For any set `X`, `ProperCompactDecisions.Diagonal` proves

```agda
DPProper (λ (x : X) → (x , x)) ≃ Discrete X
```

Here `Discrete X` is Cubical Agda's ordinary decidable-equality predicate,
`(x y : X) → Dec (x ≡ y)`. It is not a notation for shape modality.

The fiber of the diagonal above `(x,y)` is explicitly equivalent to
`x ≡ y`. Properness makes that proposition compact, hence decidable.
Conversely, decidable equality makes each diagonal fiber a decidable
proposition, hence compact; the existing compact-fibers-to-properness
theorem supplies properness. Both directions are actual terms, and their
proposition-valued types yield the displayed equivalence.

`ProperCompactDecisions.SmoothReals` specializes the obstruction to a
commutative ring `R` with the existing Kock field axiom `KockField R` and
the first-order Kock–Lawvere axiom `FirstOrderKL R`:

```agda
DPProper (λ (x : R .fst) → (x , x)) → ⊥
```

It composes the diagonal equivalence with the previously checked theorem
`SyntheticField.RingContext.Differential.no-decidable-equality`. There is
no appeal here to an informal model or to a claim about the topology of
the real line. The contradiction is internal and conditional on the two
displayed synthetic axioms. The implementation does not assume that all
diagonals are proper.

This is a diagnostic about a proposed comparison of properness notions.
An external theorem that identified ordinary proper maps with the
literal internal predicate would need to explain this diagonal
obstruction. Such a comparison has not been proved in this project.

### The lifting argument for a proper étale presentation

`ProperEtaleDiscreteness.Ring.Presentation` works with an arbitrary category
`C`, a proof that its object type is a set, and the actual crystalline
modality built from the infinitesimal neighborhood `𝔇` of zero. This
generic step requires no manifold structure, ordered-ring axioms,
Principle of Constancy, or groupoid inverses.

Let `q : Arrows → Image sourceTarget` be the actual restriction of the
source–target map to its image. The generic module displays the one
temporary input

```agda
PowerSurjection = isSurjection (λ (h : 𝔇 → Arrows) → q ∘ h)
```

It is a concrete preservation property of this map. It is not a general
choice principle, a decidability premise, or an installed ambient axiom.
The checked `TinySetSurjections.preserves-surjection` supplies it for
the crisp map `q`, using the existing tiny-type and crisp modal rules.
The target image is a set; no source-set hypothesis is needed by that
preservation theorem. The proof uses an actual set-truncated kernel-pair
coequalizer presentation, rather than claiming that ordinary fibers of
a crisp map are themselves crisp.

The rest of the argument is implemented in these stages:

1. For an arbitrary `v : 𝔇 → Objects`, every `d : 𝔇` is a
   double-negation neighbor of zero. At zero, an identity arrow witnesses
   membership of `(v zero𝔇, v zero𝔇)` in the source–target image.
   Decidable image membership therefore gives actual mere membership of
   `(v zero𝔇, v d)` for every `d`.
2. These memberships form a map `𝔇 → Image sourceTarget` with fixed
   source coordinate. `PowerSurjection` supplies a merely chosen lift to
   `𝔇 → Arrows`, together with its commuting path. No pointwise choice
   operation is used.
3. The source coordinate of the commuting path turns the lift into a
   curve in the ordinary source fiber over `v zero𝔇`. Étaleness makes
   that fiber crystalline, so this curve is constant.
4. The target coordinate then gives `v d ≡ v zero𝔇`. The truncation of
   the lifted curve is eliminated only into this propositional equality
   type, justified by object sethood. Constant maps and evaluation at
   zero are explicit inverses, proving `IsCrystalline Objects`.
5. Crystalline source fibers over crystalline objects give a crystalline
   total space. An explicit equivalence between this total space and
   `Arrows` proves `IsCrystalline Arrows`.

The exported conclusions `objects-crystalline` and `arrows-crystalline`
take the concrete `PowerSurjection`, literal `DPProper sourceTarget`, and
actual `Crystal.Etale source`. In the final crisp presentation assembly,
tiny exponentiation discharges the concrete preservation input.

The manifold argument can then be applied to the **total arrow space**.
The checked full geometric Lemma 6.3.4 supplies its shape modality. This
type is crisp when the presentation is crisp, so the checked crisp
discreteness theorem gives ordinary decidable arrow equality. Each
ordinary `Hom x y` embeds into that total space and inherits decidable
equality. No promotion of `x`, `y`, or `Hom x y` to crisp data occurs.

### What this establishes, and the external bridge still missing

The diagonal result does not refute the literal conditional main theorem.
Its internal properness hypothesis derives the hom-equality decisions used
by the compactness and finiteness argument. The final assembly
`ProperEtaleManifoldOrbifolds.Context.Presentation.Ordinary.proper-etale-completion-orbifold`
supplies the actual Rezk-completion orbifold conclusion. The analytic and
modal assumptions remain explicit; no additional `PowerSurjection` or
hom-decidability premise is used.

This result does not establish that every externally or classically
proper Lie groupoid satisfies `DPProper sourceTarget`. That implication
would be an additional semantic comparison theorem. The diagnostic
shows why it must not be silently inferred from terminology or from a
comparison of compactness for crisp ordinary manifolds alone. The
internal properness predicate tests ordinary varying compact subtypes,
not merely fixed external compact subsets.

The related [Warning 6.2.20](https://arxiv.org/html/2205.15887v1) already
exhibits a closed bounded subtype equivalent to an equality proposition
whose compactness would decide that proposition. Thus one cannot repair
the external comparison by declaring arbitrary closed subtypes of
compact types to be DP compact. The checked argument above makes no such
closure claim and assumes no infinitesimal inverse function theorem.

For source verification, the exact paper URL is
<https://arxiv.org/html/2205.15887v1>; the relevant numbered passages are
Definition 6.2.1, Proposition 6.2.4, Warning 6.2.20, Definition 6.3.6,
and Theorem 6.3.7. The corresponding abstract page is
<https://arxiv.org/abs/2205.15887>.

<a id="external-properness-obstruction"></a>

### Exact conclusion

`src/Orbifolds/ExternalPropernessObstruction.agda` makes the necessary
condition for a proposed external comparison explicit. Under the existing
Kock field and first-order Kock–Lawvere assumptions, no map represented as
the smooth-real diagonal, even only up to equivalences and a commuting
homotopy, can satisfy the literal internal `DPProper` predicate.

Consequently, a sound interpretation cannot simultaneously:

1. validate those two synthetic assumptions for its smooth-real object;
2. represent the external real diagonal by that diagonal up to the stated
   equivalences;
3. send classical properness of that external map to internal `DPProper`.

This refutes that package of comparison requirements. It does **not**
prove that the synthetic theory has no model, that every relationship
with classical orbifolds is impossible, or that an external orbifold-like
interpretation cannot be developed with different hypotheses. It does
not refute the already formalized conditional internal main theorem.

The module adds no geometric axiom or postulate. Its negative theorems take a proposed properness comparison as the assumption refuted. They do not construct the separate semantic soundness theorem.

### Formal statements and their dependencies

| Declaration | Content |
| --- | --- |
| `equivalence-DP-proper` | Every actual equivalence is DP proper. |
| `proper-along-equivalences` | DP properness transfers along a homotopy-commuting square whose vertical maps are equivalences. |
| `properness-commuting-equivalences` | The preceding transfer is an equivalence of the properness propositions. |
| `DiagonalRepresentation` | Records a domain equivalence, a codomain equivalence and the actual diagonal square for a proposed representative map. |
| `represented-diagonal-proper≃discrete` | For a set `X`, properness of any represented diagonal is equivalent to ordinary decidable equality on `X`. |
| `compact-equality-at-decided-pair` | A decision of equality at a particular pair does make its equality proposition compact. |
| `IdentityPresentation.source-target-proper≃discrete` | The actual source-target map of the constructed unit groupoid is proper exactly when its object set has ordinary decidable equality. |
| `SmoothReals.equality-fibers-not-uniformly-compact` | Under K and first-order KL, the equality propositions of the smooth reals cannot all be DP compact uniformly in ordinary pairs. |
| `SmoothReals.represented-diagonal-not-DP-proper` | Under the same assumptions, any represented smooth-real diagonal is not DP proper. |
| `SmoothReals.unit-groupoid-source-target-not-DP-proper` | Specializes that obstruction to the actual unit-groupoid source-target map. |
| `MapClass.SmoothLine.no-comparison-at-represented-line-diagonal` | Refutes even a comparison restricted to one externally proper distinguished arrow with the required representation. |
| `MapClass.SmoothLine.no-properness-preserving-interpretation` | Refutes a proposed comparison for all maps in an independently supplied map class when it includes that distinguished arrow. |

The generic properness and representation results need ordinary Cubical
type theory and the existing definition of DP compactness/properness.
The smooth-real specializations additionally need `KockField R` and
`FirstOrderKL R`. They need neither the ordered-real assumptions, the
Covering Property, the Principle of Constancy, interval compactness,
tinyness, nor the additional coherent-diagram extensionality rules.
This minimal dependency statement concerns the mathematical parameters of
these declarations; the imported project/library source closure is
recorded separately by the checker.

All type and proposition tests in the new module use its explicit common
working universe. No proposition resizing or universe-polymorphic
semantic model is asserted.

### External nonvacuity: the two axioms in the Cahiers model

The two algebraic hypotheses of the obstruction have a concrete joint
realization independently of the unresolved full foundational package.
This section gives an external sheaf-theoretic verification of the
**exact signatures** in `SyntheticField.RingContext.KockField` and
`SyntheticDifferential.FirstOrder.FirstOrderKL`. It is not an Agda
construction of a model or a formal soundness proof for native Cubical
Agda.

Use the Cahiers site of formal manifolds `T = U × ℓW`, with `U` a
Euclidean open set, `W` a finite-dimensional local real Weil algebra
with residue field the reals, and covers induced by ordinary open
covers of `U`. Representables are sheaves. The sheaf `R` represented
by the ordinary real line is a commutative ring object with

\[
R(T)=A_T=C^\infty(U)\otimes_{\mathbb R}W.
\]

The algebra identification, representation of the square-zero disk,
and the well-adapted sheaf model are the standard construction in
Dubuc's 1979 paper, specifically Proposition 1.6, Observation 1.9,
Section 4 and Theorem 4.10. The following finite-tuple argument spells
out the particular logical axiom needed here rather than inferring all
of Myers' assumptions from that reference. [D79]

#### Nontriviality and the finite Kock field clause

Write `m_W` for the nilpotent maximal ideal of `W`. Reduction gives a
smooth body `bar(a) ∈ C∞(U)` for every `a ∈ A_T`, with nilpotent kernel
`C∞(U) ⊗ m_W`. At any nonempty stage, evaluation of the body at a point
of `U` distinguishes zero from one. The equality subobject `0 = 1` is
therefore empty, giving the exact field

\[
\mathsf{nontrivial}:(0=1)\longrightarrow\bot.
\]

At the empty stage the assertion holds uniquely. In particular, zero
and one are distinct at the terminal probe, so this is a nondegenerate
model.

The other field is

\[
\prod_{n:\mathbb N}\prod_{x:\mathrm{Fin}(n)\to R}
\left(\neg\prod_{i:\mathrm{Fin}(n)}x_i=0\right)
\longrightarrow
\left\|\sum_{i:\mathrm{Fin}(n)}
             \sum_{y:R}x_i y=1\right\|.
\]

Fix a stage `T` and first take an externally fixed finite `n`. Suppose
the tuple `x_i ∈ A_T` satisfies the displayed **internal** negation.
This means that every pullback context in which all the `x_i` vanish
is empty; it is stronger than the external assertion that these
sections are not all identically zero. If the bodies `bar(x_i)` had a
common zero `u ∈ U`, pulling back along the ordinary point
`u : 1 → T` would make the whole tuple zero in a nonempty context,
contradicting the premise. Consequently the finitely many open sets

\[
U_i=\{u\in U:\bar x_i(u)\ne0\}
\]

cover `U`.

On `U_i`, decompose `x_i = f_i + η_i`, where `f_i = bar(x_i)` is a
nowhere-zero smooth function and `η_i` lies in the nilpotent kernel.
Choose an external `N` with `m_W^N = 0`. An inverse is explicitly

\[
x_i^{-1}
=f_i^{-1}\sum_{k=0}^{N-1}(-f_i^{-1}\eta_i)^k.
\]

Thus on each covering stage `U_i × ℓW` there is an index and an actual
inverse. Propositional truncation expresses precisely this local
existence. Different indices on overlaps cause no compatibility
problem for the proposition-valued conclusion. This supplies
`finite-K` without an internal choice principle or a globally selected
invertible entry.

The empty tuple is included: when `n = 0`, the all-zero proposition is
inhabited, so its negation can hold only in the empty context. For an
ordinary internally varying `n`, sections of the natural-number object
are locally constant. Refine the open cover to regions where `n` is
constant and apply the argument there. This verifies the ordinary
dependent quantifiers and their stability under substitution, rather
than a version restricted to crisp tuples.

#### The exact first-order Kock--Lawvere equivalence

In the code, the test object for this axiom is

\[
D=\sum_{d:R}(d^2=0).
\]

It is the square-zero disk represented by
`ℓ(ℝ[ε]/(ε²))`. It must not be confused with the full
double-negation infinitesimal neighborhood considered in
`tiny-colimits.md#tiny-exhaustion-obstruction`. Since `R` is a sheaf of sets, the
equation `d² = 0` is proposition valued, so this represented subobject
matches the displayed dependent-sum definition.

Let `W₁ = ℝ[ε]/(ε²)`. The product of `T` with `D` is represented by
`U × ℓ(W ⊗ W₁)`. Hence the exponential sheaf satisfies

\[
\begin{aligned}
(R^D)(T)
&=\operatorname{Hom}_{\mathrm{Sh}}(T\times D,R)\\
&\cong A_T\otimes_{\mathbb R}W_1\\
&=\{a+b\varepsilon:a,b\in A_T\}
\cong A_T\times A_T.
\end{aligned}
\]

Uniqueness of the two coefficients follows from the basis `1, ε` of
the dual-number algebra. Under this identification, the map from
`R × R` is exactly the code's

\[
\mathsf{affine}(a,b)(d)=a+b\,d.
\]

The coefficient correspondence is natural under every morphism of
formal stages: the induced algebra homomorphism sends
`a + bε` to the corresponding expression with the two coefficients
pulled back. It is therefore an isomorphism of sheaves, supplying
`isEquiv affine`, including the contractibility of its fibers. This
is a statement about the full internal mapping object, not the set of
arbitrary functions `D(T) → R(T)` at an individual stage. For example,
the terminal stage has only zero as a square-zero real number, but
the internal mapping object there still has the two affine
coefficients, as required.

#### What this realization establishes

These arguments jointly validate the two displayed axioms in the
ordinary Cahiers sheaf model. They also concern only set- and
proposition-valued constructions, which give the same interpretation
inside the corresponding higher sheaf topos. They require no crisp
elimination, order axiom, flat modality, `RFlat`, or tinyness of the
full infinitesimal neighborhood. Thus the algebraic hypothesis package
behind the diagonal obstruction is not merely an uninstantiated list
of assumptions.

The result establishes external nonvacuity at this stated logical
scope. It does not construct the complete Myers setting, supply the
failed properness comparison, or discharge the remaining interpretation
of the native proof language and its universe rules. Those claims must
remain separate.

**[D79]** Eduardo J. Dubuc, *Sur les modèles de la géométrie
différentielle synthétique*, 1979, Proposition 1.6, Observation 1.9 and
Theorem 4.10.
[Primary paper](https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf).

### Equivalent presentations do not evade the obstruction

Let `f : A → B`. A `DiagonalRepresentation X f` consists of actual
equivalences

\[
a:A\simeq X,\qquad b:B\simeq X\times X
\]

and a homotopy

\[
b(f(z))=(a(z),a(z)).
\]

The proof that equivalences are proper uses their contractible fibers.
Composition of proper maps, together with the inverse of `a`, makes
`b ∘ f ∘ a⁻¹` proper whenever `f` is proper. The displayed homotopy and
the inverse law for `a` identify this composite with the diagonal.
Repeating the construction with inverse equivalences proves the converse.
Thus the result concerns equivalently represented arrows, rather than
only one syntactic expression for the diagonal.

The existing module `ProperCompactDecisions.agda` proves

\[
\operatorname{DPProper}(\Delta_X)
\simeq
\prod_{x,y:X}\operatorname{Dec}(x=y)
\]

for a set `X`. Composing these equivalences proves
`represented-diagonal-proper≃discrete`. `Discrete` here is Cubical
Agda's ordinary decidable-equality predicate. It does not denote a shape
modality or a requirement restricted to crisp points.

For the unit groupoid, the object set is `X` and the hom from `x` to `y`
is `x ≡ y`. The category is the library's actual `DiscreteCategory`, and
all its arrows are proved invertible. The project construction
`GroupoidGeometry.ArrowSpace` then gives

\[
\operatorname{Arrows}
=\sum_{(x,y):X\times X}(x=y),
\qquad
(s,t)((x,y),p)=(x,y).
\]

Projection to `x` is proved equivalent to the object type, with inverse
`x ↦ ((x,x),refl)`. The path `p` provides the commuting diagonal square.
This connects the obstruction to the actual groupoid machinery used by
the formalization.

### The empty-or-point distinction

At a pair where equality has been decided, the equality fiber is
compact: if equal it is contractible, and if unequal it is empty. The
module exports `compact-equality-at-decided-pair` for exactly this fact.

The problematic assertion is the ordinary dependent function

\[
\prod_{x,y:R}\operatorname{DPCompact}(x=y).
\]

DP compactness of a proposition gives a decision of that proposition.
The displayed function would therefore give ordinary decidable equality
on `R`, contrary to the consequence of K and first-order KL already
proved in `SyntheticField.agda`.

In particular, external classical case distinctions at each fixed pair
of global real points do not provide this function for all generalized,
varying points of the smooth-real object. A proposed semantics must
respect the contexts and substitution occurring in the internal
quantifier. Crispness of the presentation does not turn those ordinary
quantifiers into crisp ones. See `properness.md#properness-scope` for the original
properness definition and its quantification.

### External mathematical input: a Hausdorff diagonal is proper

The following is an external classical topological proof. It is included
to specify the external premise used by the comparison obstruction; it
is **not** a claim that classical topology or its real line has now been
fully encoded in this Agda development.

Let `M` be a Hausdorff space and let
`Δ : M → M × M` be its diagonal. If `(x,y)` is outside the diagonal,
Hausdorff separation gives disjoint open neighborhoods of `x` and `y`.
Their product misses the diagonal. Consequently the diagonal is closed.
Its first-coordinate projection is inverse to `Δ` onto its image, so
`Δ` is a closed embedding.

For a compact subset `K ⊆ M × M`, the intersection `K ∩ Δ(M)` is a
closed subset of a compact space and is therefore compact. The
homeomorphism between `M` and `Δ(M)` identifies this intersection with
`Δ⁻¹(K)`. Thus inverse images of compact subsets along `Δ` are compact:
the diagonal is proper in this standard classical sense.

Apply this to the ordinary real line. The unit Lie groupoid has both
its object and arrow manifolds equal to the real line, and source and
target equal to the identity. The source is a local diffeomorphism and
the source-target map is the proper diagonal. It is therefore a
classical proper étale Lie groupoid.

No global excluded-middle axiom is imported into the synthetic context
to make this argument. The external classical proof and the internal
synthetic obstruction have separate foundations; a sound interpretation
is exactly what would have to connect the proposed comparison.

### What the abstract interpretation interface proves

`MapClass` takes independently specified object and arrow types, a
predicate `Proper` on those arrows, and proposed assignments of internal
objects and maps. `PreservesProperness` states the desired implication
for each arrow. The negative theorem also takes a distinguished arrow
`delta`, its `Proper delta` witness, and the representation of its image
as the smooth-real diagonal. It derives the contradiction by applying
the proposed comparison to that one witness.

The interface imposes no unnecessary functor, product, or category laws:
the displayed diagonal representation records the exact consequences
of those laws needed for this obstruction. The even smaller theorem
`no-comparison-at-represented-line-diagonal` only assumes a comparison
for the distinguished arrow. Thus external size or universe issues
about a category of all manifolds are not the cause of the obstruction.
Restricting a proposed comparison to crisp maps does not by itself remove
this test: the external real diagonal is already a fixed external map.
The problematic varying parameters occur inside its internal
`DPProper` predicate. A different restriction on that predicate would be
a changed mathematical definition requiring new proofs.

This is a formal certificate about the necessary data of a proposed
comparison. It does not quantify over a constructed syntax of all Agda
models and does not formalize a general soundness theorem. To conclude
externally that no sound interpretation can supply these data, one uses
soundness externally: the interpretation of the internal contradiction
would be a contradiction in the proposed nondegenerate model.

The paper's explicit identification of crisp ordinary proper étale
pregroupoids with external proper étale groupoids appears in its
introduction and conclusion. Its internal properness definition is
Definition 6.2.1. Source: David Jaz Myers, *Orbifolds as Microlinear Types
in Synthetic Differential Cohesive Homotopy Type Theory*,
[arXiv:2205.15887v1](https://arxiv.org/pdf/2205.15887).
The certificate targets that specific properness-preserving comparison.

### Consequences for the revised development

Any proposed external application must state which comparison it uses.
For the represented real diagonal, retaining K, first-order KL and
literal internal `DPProper` leaves no room for the desired blanket
properness implication. Choosing a different model without changing
these requirements cannot remove this contradiction.

This leaves meaningful alternatives to investigate: an interpretation
of the synthetic conclusions using a different external hypothesis; a
different internal properness notion followed by new proofs; or a
specified external class of groupoids/stacks on which the required
comparison actually holds. The present theorem neither constructs nor
rules out those alternatives. Their semantics and geometric comparison
remain separate work.

There is already a concrete positive distinction in the existing code:
`Orbifold.setLocallyProperlyFinite` proves that every set has properly
finite identity types, and `Orbifold.Geometry.microlinearSetOrbifold`
makes every microlinear set an internal orbifold. Consequently, once
microlinearity of the smooth-real type is supplied, that type is an
internal orbifold despite the failure of literal DP properness for its
unit-groupoid presentation. The obstruction concerns a proposed route
through that properness hypothesis; it does not negate this independent
construction of the conclusion.

<a id="higher-properness-correction"></a>

## Proposition 6.2.4 needs a set-codomain restriction

`HigherPropernessCounterexample.agda` gives a checked counterexample to
the unrestricted higher-type formulation of Proposition 6.2.4 in
[arXiv:2205.15887v1](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm4).

The paper defines properness by inverse images of compact subtypes,
then claims that it is equivalent to compactness of homotopy fibers,
and hence stable under pullback. There is no set-codomain condition in
that printed statement. `ProperMaps.agda` already proves the equivalence
and pullback theorem with that condition. The new module proves why
the restriction is necessary, within the explicit synthetic setting.

### An actual proper map with a noncompact fiber

Let B be the already constructed type of algebraic torsors for the
additive group of R, and let b be its regular torsor. B is a genuine
pointed connected groupoid, with its actual loop type equivalent to R.
Consider the actual map

point-map : Unit -> B,   point-map(*) = b.

This map is subtype-proper. More generally, the point map into any
pointed connected type is subtype-proper: for a compact subtype U of B,
connectedness supplies a surjection from U onto the proposition U(b).
Compactness descends along that surjection, and the inverse image of U
is the product of U(b) with the unit type. This is exactly the existing
`ProperMaps.pointMapProper` proof; no compactness of loop types is used.

Its homotopy fiber at b, however, is equivalent to the actual loop type
of B and hence to R. The already checked bounded-real-function theorem
proves that R is not DP compact: applying it to the identity function
would give a strict upper bound B for every real, including B itself,
contradicting irreflexivity of the strict order.

The geometric inputs for this noncompactness proof are the same
explicit Kock-field, strict order, ordered-ring compatibility, and
interval covering-property assumptions used by `SyntheticBounds`.
There is no new noncompactness axiom or semantic countermodel assumption.
No Kock--Lawvere, excluded middle, sharp, or crisp structure is needed.

The decisive checked entrypoints are

- `Ring.point-map-proper`;
- `Ring.point-fiber-not-compact`;
- `Ring.unrestricted-fiber-converse-is-false`.

### Pullback stability also fails without the restriction

Pull back the same point map along itself. Its total space is
`Unit x fiber(point-map,b)`, and its base is Unit. If this projection
were subtype-proper, testing its entire compact codomain would make
its total space compact. Its actual projection onto the original fiber
is surjective, which would make that fiber compact. This contradicts
the noncompactness proof above.

`Ring.self-pullback-not-proper` proves this claim for the actual
`ProperMaps.pullbackProjection`, with the original point map supplied
on both sides. Thus the failure includes the printed unrestricted
pullback-stability corollary.

### Universe and main-theorem scope

R lies in `Type ℓ`; its torsor delooping lies in `Type (ℓ+1)`. The
properness counterexample is stated at that larger universe. The
function `lower-compact-tests` explicitly lifts small test propositions
to the larger universe and lowers the resulting disjunction. It uses
no proposition resizing or hidden equality of universes.

For maps into sets, singletons are proposition-valued subtypes, and the
checked compact-fiber equivalence remains valid. The source-target map
in the main ordinary-manifold theorem has a set codomain, so that
theorem uses the valid restricted result. Its completed proof is
unchanged. This correction is also separate from the real-diagonal
properness diagnostic in `properness.md#properness-scope`.

<a id="compact-separation-scope"></a>

### The point-set theorem now checked

The final theorem `proper→closed` proves that a continuous map with compact
preimages into a locally compact Hausdorff target is closed. Its inputs use
the explicit selected-data forms below. The conclusion is exactly
`TopologicalFiniteBranches.ClosedMap`, so it supplies the closed-anchor
hypothesis of the checked finite-branch construction.

The intermediate theorems are proved from finite covers:

- `compact-image-closed`: the image of a compact subset under a continuous
  map into a Hausdorff space has open complement.
- `closed-subset-compact`: intersecting a compact subset with a closed
  subset preserves the finite-subcover property.
- Finite intersections of opens retain openness, their common center,
  and the disjointness needed to exclude a finite covering family.

The proof does not take closedness of proper maps or closedness of compact
images as extra fields.

### Exact data forms and classical interpretation

`Subset A` consists of a predicate `member : A -> Set ell` and proofs that
each membership type is a proposition. `OpenFragment A` supplies the whole
open set, intersections, invariance under pointwise equivalence of
membership, and the neighborhood criterion for openness. These are
ordinary topological operations, instantiated by an actual classical
topology in the external application.

`CompactData O K` is a selected finite-subcover operation. Given a small
index type `I`, an open family `U : I -> Subset A`, and actual covering
witnesses for points of `K`, it returns a list of indices and a proof that
those listed opens still cover `K`. It is data and is not asserted to be
a proposition. `ChosenHausdorff` chooses separating neighborhoods for
distinct points. `ChosenLocallyCompact` chooses, at each point, an open
neighborhood contained in a specified compact subset.

Standard classical compactness, Hausdorff separation and local compactness
supply these data using choice over the coded collections at the fixed
external universe. This is an explicit external set-theoretic assumption.
The development has not proved equivalence between the selected-data
interfaces and a separately mechanized library of classical topological
definitions. In the usual classical set model with that choice principle,
the displayed data are supplied by their ordinary mathematical definitions.

`PropositionalEM ell` is an explicit proof argument. It is used to extend
a cover of `K intersect C` to a cover of `K` by adding the open complement
of `C`. The finite list is then filtered to remove this extra open; points
of `C` cannot use it. No general excluded-middle axiom is installed in the
ordinary theory or the smooth internal theorem.

The interpretation of these point-set arguments is in classical sets.
The higher Cahiers application continues to use its constructive internal
logic. Transferring the resulting classical branch construction to formal
points requires its own preservation and descent argument.

### Proof of closed compact images

For a point outside the image of the compact source subset, choose a pair
of disjoint target neighborhoods separating it from each source point's
image. The inverse images of the second neighborhoods cover the compact
subset. Its finite-subcover operation returns a finite list. Intersect the
first neighborhoods along that list. The resulting open neighborhood
contains the outside point and misses every source image, because any
source point lies in one of the selected inverse images. The neighborhood
criterion gives openness of the image complement.

An image is represented by its actual witness type
`Sigma a. C(a) times (f(a) = b)`. It is not assumed to be a proposition.
Its negation is a proposition by function extensionality. This formulation
avoids resizing or a same-universe image truncation.

### Proof that proper maps are closed

For a closed source subset `C` and a target point outside its image, choose
a compact target neighborhood `K` containing an open neighborhood `V`.
Properness supplies compactness of the actual preimage of `K`. The proved
closed-subset theorem makes its intersection with `C` compact. The proved
compact-image theorem makes the image of this intersection closed. The
open set `V` intersected with its image complement contains the chosen
point and misses the entire image of `C`: any image point in `V` already
comes from the compact preimage of `K`.

Thus `proper→closed` supplies the exact closed-map operation used by
`TopologicalFiniteBranches`, with no comparison to literal synthetic
`DPProper`.

### Scope of this local separation step

This module alone does not construct manifold charts, Euclidean compact
neighborhoods, or a smooth sheaf model. Finite numbering and the complete
open-branch diagram are supplied by the separate finite-fiber-numbering and
[topological bridge](topological-bridge.md) constructions. Smooth/formal
interpretation remains a separate obligation; the compactness and separation
hypotheses of the local theorem must be retained.
### Open-domain comparison

The finite-numbering task just recorded is now supplied by the accepted
`FiniteEnumeration` and `CompactDiscreteFibers` modules. Actual compact
finite-cover data and local source injectivity give a covering list of
the fiber, and deduplication constructs an actual equivalence with
`Fin n`. The full `ProperBranchConstruction.proper-local-branch-chart`
assembly composes this with the closed-map theorem in this module and
the finite-separation theorem; it takes neither finite fibers nor
closedness nor disjoint pieces nor the final chart as an extra input.
See [properness.md#finite-fiber-numbering-scope](properness.md#finite-fiber-numbering-scope).

`OpenBranchDomains` proves openness and partial continuity for the actual
branch domains and target maps, deriving uniform open-image data from chosen
continuous local source sections. The subtype topologies and homeomorphism
assembly are additional constructions in [Topological bridge](topological-bridge.md).
Formal-point extension remains distinct.

### Topological assembly

`LocalHomeomorphisms` now derives the required local injectivity,
continuous sections and global source continuity from chosen charts
for the actual source restriction. `ProperOpenBranchCharts` combines
this module's proper-to-closed theorem with finite numbering,
separation and the actual branch homeomorphism. The final statement
derives finite fibers, closedness, disjoint pieces and the open-domain
homeomorphism from its displayed properness and local-homeomorphism
inputs. See
[topological-bridge.md#proper-open-branch-charts-077](topological-bridge.md#proper-open-branch-charts).
This completes the topological diagram stage; smoothness and transfer
to formal parameters retain the boundary stated above.

<a id="finite-fiber-numbering-scope"></a>

### Finite enumeration from an actual list cover

The accepted module
`src/Orbifolds/Intensional/FiniteEnumeration.agda` constructs an actual
equivalence with a finite ordinal from an actual finite list cover and
decidable equality. The list may contain repetitions. An enumeration,
an injective lookup function, and an equivalence with `Fin n` are not
additional assumptions.

The primary export is

list-cover→finite :
      DecidableEquality A ->
      (xs : List A) ->
      ((a : A) -> Some (lambda x -> x == a) xs) ->
      Sigma (n : Nat). Equiv A (Fin n).

All carrier and finite-ordinal types are at the same fixed level `ell`;
the source writes the ordinal as `Fin {ell} n`.

#### Exact assumptions

`DecidableEquality A` is the explicit operation

(x y : A) -> (x == y) + Not (x == y).

`ListCover xs` means that every `a : A` comes with a `Some` witness
locating an equal element in `xs`. This is actual data, not a
propositional truncation of the existence of a list or covering witness.
The core construction needs neither function extensionality nor a
separate sethood assumption.

For the classical application, the module also exports

set-em→decidable-equality :
      isSet A -> PropositionalEM ell -> DecidableEquality A

and the composed result `em-set-list-cover→finite`. Sethood makes each
identity type a proposition, so the already displayed propositional
excluded-middle parameter decides that identity. This is the only use
of excluded middle in the enumeration module; the list algorithm itself
is constructive relative to its supplied decisions.

#### Deduplication and the actual inverse functions

`member?` decides membership in a finite list by structural recursion.
`NoDuplicates` records that the head is absent from the tail and the
tail itself has no duplicates. `deduplicate` processes the tail first:
if the head is already represented, it keeps that tail; otherwise it
adjoins the head.

Its result, `Deduplicated xs`, contains four proved components:

- `items`, the resulting list;
- `unique`, a `NoDuplicates items` proof;
- `retains`, which sends every original membership witness to a
  membership witness in `items`;
- `contains-only`, which sends every membership witness in `items`
  back to one in the original list.

Thus the construction preserves coverage and introduces no new points.
It does not assume that the `Some` witness type is a proposition.

The module defines `length` and the ordinary recursive

lookup xs : Fin (length xs) -> A.

`lookup-member` locates each lookup value in the list. `some-index`
turns a `Some P xs` witness into an index together with a proof of
`P (lookup xs i)`; `member-index` specializes this to an equality with
a requested element. These are computations on the inductive witness,
without any elimination from truncation.

`lookup-injective` proves injectivity when the list has no duplicates.
The two head/tail cases contradict the head's recorded absence from
the tail; the tail/tail case recurses and applies `cong fsuc`.

Let `ys` be the deduplicated list. For each `a`, the supplied cover,
followed by `retains` and `member-index`, constructs

search a : Sigma (i : Fin (length ys)). lookup ys i == a.

The returned equivalence has these actual functions:

forward  a = fst (search a)
    backward i = lookup ys i.

The backward-after-forward law is `snd (search a)`. For the other law,
`lookup-injective` is applied to that equation at `a = lookup ys i`.
Both inverse laws are therefore proved for the displayed functions,
including whatever membership witnesses the input cover selected.

The generic helper exports `Some-map`, `map-list`, and `Some-map-list`
also allow a finite subcover's witness and index families to be mapped
to a required list-cover presentation.

### Compact locally injective fibers

That separate construction is now supplied by
`src/Orbifolds/Intensional/CompactDiscreteFibers.agda`.

`singleton-compact` proves compactness of a singleton directly from the
indexed-cover definition of `CompactData`. A cover contains an index
covering the center; that single index covers the singleton by transport.
No finite-cover or compactness conclusion is supplied as a field of the
singleton.

The next theorem, `compact-locally-injective-fiber`, takes:

- an open-set structure on `A` and sethood of `A` and `B`;
- propositional excluded middle at the fixed level;
- a function `f : A -> B`;
- a chosen open neighborhood of every point on which `f` is injective;
- compact-cover data for the actual subset `f a == b`.

It returns `Sigma n. Equiv (Fiber f b) (Fin n)` as follows.
The cover is indexed by the **actual fiber points** `(a,p)` with
`p : f a == b`. The open assigned to such an index is the chosen
injectivity neighborhood of `a`. Every point of the fiber lies in its
own indexed neighborhood, so compactness returns a finite list of these
fiber points and covering witnesses for that list.

If `(a,p)` lies in the neighborhood indexed by `(c,q)`, local
injectivity applied to `q · sym p` proves `c == a`. Sethood of `B`
makes the endpoint-identity fibers propositions, allowing that equality
to lift to equality of the complete fiber points. `Some-map` therefore
turns the finite subcover into

(point : Fiber f b) ->
      Some (lambda chosen -> chosen == point) indices.

This is exactly the actual list cover required by `FiniteEnumeration`.
`isSetΣProp` proves the fiber is a set, so the EM wrapper constructs its
finite numbering. Compactness supplies the list; the preceding list
algorithm supplies deduplication and the two inverse functions.

`proper-locally-injective-fibers` removes the compact-fiber premise.
It applies `ProperData` to the compact singleton just constructed and
then invokes `compact-locally-injective-fiber`. Here `ProperData` means
that inverse images of compact subsets carry the stated finite-subcover
operation. It contains no fiber enumeration or branch-chart field.

### From anchor fibers to hom families

For maps `s : A -> X` and `t : A -> Y`, the existing hom family is

Hom s t x y = Sigma a : A. (s a == x) × (t a == y).

`hom-anchor-equivalence` identifies this with the actual fiber of

anchor a = (s a , t a)

over `(x,y)`. The forward map pairs the two endpoint paths; the backward
map applies `cong fst` and `cong snd` to the product path. Both maps
preserve the underlying arrow `a`. Their inverse laws use sethood of
the endpoint spaces and the proved sethood of their product, rather
than assuming an identification of homs with a separately numbered set.

`anchor-neighborhoods` constructs local injectivity neighborhoods for
the anchor from those for `s`: equality of anchor values gives equality
of their first coordinates, to which source injectivity applies.
No local-diffeomorphism or injectivity property of the anchor itself is
an extra premise.

### Assembly of local finite branch charts

`ProperBranchConstruction.proper-local-branch-chart` derives the full
`LocalBranchChart (Hom s t) x y` for every base pair. Its input data are
explicit:

- fixed-level set carriers `A`, `X`, and `Y`, with their open-set
  structures and an open-set structure on `X × Y`;
- weak function extensionality and propositional excluded middle;
- chosen Hausdorff separation on the arrow space and the product;
- chosen compact neighborhoods on the product;
- continuity and compact-preimage properness of the actual anchor;
- chosen open neighborhoods on which the actual source map is injective;
- the rectangle-basis property for the displayed product topology.

The assembly constructs the intermediate properties in this order:

| Export or construction | What is proved from the inputs |
|---|---|
| `fiber-numbering` | Every original hom family is equivalent to an actual `Fin n`, using singleton compactness, properness, local injectivity, and `hom-anchor-equivalence` |
| `fiber-neighborhoods` | The numbered arrows admit disjoint open source-injectivity pieces, by the finite Hausdorff shrinking theorem |
| `proper→closed` from `CompactSeparation` | The anchor is closed, using its continuity and properness and the product's Hausdorff and compact-neighborhood data |
| `Branches.finite-bisections-local-chart` | A rectangle avoids the image of all remaining arrows, and explicit maps identify the local hom family with the finite branch presentation |

In the shrinking step, the numbering proves that distinct finite
indices represent distinct underlying arrows. Finite intersections of
the chosen pairwise separators refine their original source
neighborhoods. This constructs disjointness and preserves source
injectivity; a disjoint branch family is not an assembly input.

In the removal step, the complement of the selected finite union is
closed. The proved closed-map property makes the complement of its image
open around the base pair. The rectangle basis supplies the source and
target regions. Propositional double-negation elimination, derived from
the displayed EM parameter, then proves that every arrow over this
rectangle lies in a selected piece.

The branch domain is the actual source fiber of a selected piece,
restricted by the target region. Its propositionhood follows from
source injectivity. The branch target sends its actual arrow to its
target endpoint. The forward and backward hom/branch maps and their
inverse laws are those constructed in `TopologicalFiniteBranches`.
Thus closedness, finite fibers, disjoint pieces, and the final chart
are all derived in the full assembly.

### Open domains

`OpenBranchDomains.agda` identifies branch-domain witnesses with injective
source images, proves these domains open, and proves partial continuity of
the actual target maps. Chosen continuous local source sections supply its
uniform open-image input. The compatibility theorem preserves the branch
target by reflexive computation. See [Topological bridge](topological-bridge.md)
for the selected-data assumptions and further assembly.

### Classical set-model boundary

The topological assembly is an ordinary **external classical set-theoretic
theorem**. Its interpretation uses sets as carriers, ordinary subsets
and open sets, the usual compact-subcover and Hausdorff properties, and
the displayed selected data. `CompactData`, chosen separators, and
chosen compact or injectivity neighborhoods are operations carrying
actual witnesses. When these are obtained from their conventional
existence-only formulations, the classical external metatheory must
justify the corresponding selections at the chosen size. The source
does not assert these data to be propositions or make that selection
principle an unmentioned internal axiom.

For a proper etale Lie groupoid in the selected Hausdorff manifold
conventions, its ordinary point-set geometry supplies the stated kind
of inputs: the anchor is continuous and proper, source is locally a
diffeomorphism and hence locally injective, and the product has the
required Hausdorff, local-compactness, and rectangle structure. The
native result makes the finite-fiber and finite-predicate-chart part
of that external argument explicit.

The returned `LocalBranchChart` records proposition-valued partial
domains and their target functions. Its fields do not assert that
those domains are open or that the partial functions and their inverses
are smooth. Uniform interpretation over formal parameters requires
the genuine smooth local-source charts and the formal-point comparison
arguments described in
`external-models.md#finite-bisection-interpretation` and
`source-interpretation.md#morita-comparison`.

In particular the EM-dependent point-set assembly is not asserted to
hold by direct interpretation in the non-Boolean higher Cahiers topos.
The classical topological construction and the bounded ordinary
internal orbifold theorem have distinct model boundaries. Connecting
their geometric data remains the specifically stated external
comparison, rather than an automatic consequence of native acceptance
or of a full-faithful functor between sheaf categories.

### this construction topological assembly

The accepted `ProperOpenBranchCharts` module now combines this finite
fiber construction with actual open-subspace and coproduct topologies
and the branch homeomorphism. Its
`Construction.At.proper-open-branch-homeomorphism` starts from chosen
local-homeomorphism charts for the source, target continuity,
compact-preimage anchor properness and the displayed sethood,
separation, compact-neighborhood, rectangle, weak-extensionality and
EM data. It derives the source-neighborhood and continuous-section
inputs, finite fibers, closedness, disjoint pieces, open domains and
both continuity directions of the final homeomorphism. The original
source and target diagrams are retained. See
[topological-bridge.md#proper-open-branch-charts-077](topological-bridge.md#proper-open-branch-charts).

The topological steps previously listed as separate are therefore now
checked. Smoothness under genuine local-diffeomorphism inputs and
formal-stage transfer remain separate from this classical point-set
assembly and from the independent internal atlas theorem.

<a id="proper-etale-orbifold-scope"></a>

## Proper etale manifold groupoids: the checked completion theorem

`ProperEtaleManifoldOrbifolds.agda` and the full-definition corollary
`FullProperEtaleOrbifolds.agda` have passed canonical native-kit checks
with exit status zero and no warnings. Each exports
`Context.Presentation.Ordinary.proper-etale-completion-orbifold`.
The latter is the entrypoint for the literal all-infinitesimal-varieties
conclusion.

This theorem concludes that the **actual Rezk completion** of the supplied
crisp pregroupoid is an orbifold: it has the mapping-space microlinearity
property for all crisp real-pushout squares of actual pointed infinitesimal
varieties, and its identity types are properly finite. The original proof
uses Weil-spectrum tests. The checked `FullInfinitesimalMicrolinearity`
equivalence transports that conclusion to the literal full definition;
see differential-geometry.md#full-infinitesimal-microlinearity. It composes the existing library Rezk construction,
`CrispGroupoids`, and `ManifoldCompactness`. Neither completed microlinearity
nor completed finite identities occur among its assumptions.

The target is the literal formulation of
[Definition 6.3.6 and Theorem 6.3.7](https://arxiv.org/html/2205.15887v1#S6.SS3.Thmthm7).
The theorem is relative to the explicit synthetic, analytic, and structural
assumptions below. This is not a construction of a model satisfying those
assumptions, and it does not identify literal Dubuc-Penon properness with
ordinary external topological properness.

### Exact presentation data and assumptions

All object, arrow, hom, and ring-carrier types are in a fixed universe
`Type ℓ`. The inputs are:

* A native-crisp commutative ring `R` and a native-crisp proof of the stated
  Kock-field conditions; an ordinary strict order including the
  Archimedean law of Postulate O, and the separately specified ordered-
  ring compatibility laws.
* The Principle of Constancy, the actual interval-ball Covering Property
  (Postulate E), Dubuc-Penon compactness of the closed unit interval (Axiom 5), and the
  existing `PositiveLineEquivalence` analytic input. The latter is an actual
  equivalence from the ring carrier to its strictly positive elements. It
  supports the checked interval parameterizations; it has not been derived
  from the weaker ordered-ring fields. It is directly supplied by the
  underlying equivalence of Axiom 3's Postulate Exp, which asserts the
  stronger ordered-group isomorphism.
* The stated same-universe R-flat axiom, crisp excluded middle, tinyness of
  the actual infinitesimal generator `𝔇`, flat/propositional-truncation
  distribution, and preservation of actual **crisp** pullback diagrams by
  crystalline reflection. The full-definition corollary also explicitly
  requires uniform flat/truncation distribution at `suc ell`, where the
  mere spectrum presentations live. This is the same structural rule at
  the presentation universe, with no resizing or global choice.
* The existing explicit native-flat structural rules: crisp identity
  induction at `ℓ` and at level zero, plus level-zero flat induction and its
  computation law. These are the structural inputs used by the checked tiny
  coequalizer/truncation arguments, not any desired geometric conclusion.
* A native-crisp `Category ℓ ℓ` and native-crisp proof that all its morphisms
  are invertible. Its total arrow type is the genuine dependent sum of its
  hom-family over pairs of objects.
* Actual `OrdinaryManifold` structures on the object and total arrow types,
  in respective fixed finite dimensions, for the constructed Euclidean
  topologies. These structures include regular Hausdorff topologies,
  countable bases, and pointed local homeomorphism charts. Their proofs and
  the dimensions need not be crisp.
* `DPProper sourceTarget`, where `sourceTarget` is the actual projection
  from total arrows to pairs of objects, and crystalline `Etale source` for
  the actual source projection.

The generator and tinyness premise have been cross-checked against the
original official PDF as well as its HTML rendering. Axiom 3, Postulate W
(printed page 30) explicitly asserts tinyness both of crisp infinitesimal
varieties **and of the full type `𝔇`**. Definition 4.2.3 (printed page 33)
defines that latter type as `Σ r : R, ¬¬(r = 0)`, exactly the unfolding of
`Crystalline.Ring.𝔇`. Theorem 5.4.8 (printed page 49) explicitly uses this
tinyness to derive crystalline preservation of crisp pushouts and sequences.
Thus `Tiny 𝔇` is a stated paper premise, not an additional assumption made
for this formalization. Postulate Exp appears on the same printed page as
Postulate W. See [the original PDF](https://arxiv.org/pdf/2205.15887).

Remark 4.3.2 distinguishes nullification at this `𝔇` from nullification at
all crisp infinitesimal varieties and leaves their agreement in the Dubuc
setting unclear. The formalization consequently retains the paper's actual
generator; it does not silently replace it by finite Weil spectra.

There are no extra assumptions of local source injectivity, an inverse
function theorem, hom decidable equality, hom compactness, hom finiteness,
or preservation of the particular powered image surjection. Those are
either unnecessary or are derived in the construction.

### How the ordinary hom-decidability obligation is discharged

The proof uses a consequence of **literal** Dubuc-Penon properness that is
stronger than needed merely to prove compactness of each hom. Its scope is
also documented in `properness.md#properness-scope`.

1. `ProperCompactDecisions` proves that a Dubuc-Penon compact type has
   decidable mere inhabitation. Applied to the actual fibers of the proper
   source-target map, it decides membership in that map's actual image.
2. The canonical map from arrows onto their image is genuinely crisp. The
   image type and map are named before any ordinary proof parameters.
   `TinySetSurjections.preserves-surjection` proves that exponentiation by
   `𝔇` preserves this map's surjectivity. Its target-set and original
   surjectivity proofs may be ordinary.
3. `ProperEtaleDiscreteness` lifts infinitesimal families of related pairs
   along this powered image map. A lift with fixed source lies in an actual
   crystalline source fiber, so it is constant. Thus the entire object
   space is crystalline. Etaleness of the source then makes the entire
   arrow space crystalline as well.
4. `CrystallineManifoldShape` applies to the identity embedding of the arrow
   manifold into itself. It proves that this total arrow space is
   shape-modal, using the completed finite-chain argument for locally
   constant curves.
5. The total arrow **type** is crisp because the category is crisp. Its
   ordinary sethood proof is a proof of a crisp proposition, so
   `CrispPropositions.promote-proof` legitimately promotes that proof using
   R-flat. `CrispDiscrete` now gives decidable equality on the total arrow
   type. No crisp promotion is performed on a varying type `Hom x y` or on
   its ordinary parameters `x,y`.
6. Each ordinary `Hom x y` embeds into total arrows through the actual
   source-target fiber identification. Decidable equality therefore
   restricts to every hom type. Properness gives compactness of that same
   hom type, and `ManifoldCompactness` proves it properly finite from its
   compact discrete embedding in the actual arrow manifold.
7. Ordinary object charts give a Penon-manifold structure and hence actual
   microlinearity. `CrispGroupoids` derives the canonical completion map's
   etaleness and descends microlinearity. The proved hom/identity equivalence
   and completion induction transfer properly finite homs to all identity
   types in the Rezk completion.

Consequently, the staging `PowerSurjection` premise in
`ProperEtaleDiscreteness` is **fully instantiated** in this final theorem.
The earlier general question about decidable equality of an arbitrary
noncrisp shape-modal set is not used in the proof.

### Exported intermediate results

Inside `Context.Presentation`, `Sets` exports `powered-image-surjective`,
`objects-crystalline`, `arrows-crystalline`, and the actual `hom-embedding`.
These results do not require manifold charts.

The `Ordinary` module additionally exports `objects-microlinear`,
`arrows-shape-modal`, `arrows-decidable-equality`,
`homs-decidable-equality`, and `homs-properly-finite`, before the final
`proper-etale-completion-orbifold` theorem.

The conclusion that the *whole* object and arrow spaces become crystalline
is a meaningful scope diagnostic. Together with the other stated inputs
and their ordinary manifold structures, it makes them discrete in the
relevant sense. It must not be silently described as a theorem about every
ordinary topologically proper etale Lie groupoid. The relation between the
literal internal properness predicate and that external notion requires
its own model-level argument. These checked consequences alone are not a
claim that the paper or its intended models are inconsistent.

