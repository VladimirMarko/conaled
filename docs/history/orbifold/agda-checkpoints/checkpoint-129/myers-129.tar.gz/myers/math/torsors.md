# Torsors

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="torsors"></a>

## Algebraic torsors and their genuine identities

`Orbifolds.Torsors` uses only Cubical HoTT and the actual algebraic `Group`
record. It constructs set actions with explicit unit and composition laws,
and defines torsors by mere inhabitedness and equivalence of each orbit map.
The latter is exactly the existence of a unique translating group element.
No basepoint is selected for every torsor.

### Checked correspondence

For Proposition 2.1.3, the type of torsors is a genuine pointed connected
groupoid. The point is the regular left action. An orbit map at a torsor
point is an equivariant equivalence; its structural identity comes from a
proved structure identity principle. Mere inhabitedness therefore gives
mere identifiability with the regular torsor.

The loop comparison is actual transport of the unit in the carrier family.
Its equivalence is proved using the computation rule for univalence and the
fact that an equivariant map out of the regular action is determined by its
value at the unit. The checked `torsor-loop-group-equivalence` is a
`GroupEquiv`, including multiplication, unit and inverse compatibility.
Here the loop-group multiplication is ordinary path concatenation. The
reversed convention used for family actions in `Quotients` is kept explicit.

For Lemma 2.1.13, the associated carrier is the literal identity type
`regular-torsor = T`. Its action is precomposition by the regular
automorphism corresponding to the acting element. Unit, composition,
free-transitivity, sethood and mere inhabitedness are all proved. Actual
transport evaluation is an equivariant equivalence to the original torsor.
The identity carrier lies in a larger universe; the theorem relates these
carriers by an equivalence without a resizing assumption.

### Separate extensions

The balanced quotient, extension of torsors and all-loop transport calculations
are separate constructions detailed below. A generic torsor identity theorem
is not by itself a complete smooth/model interpretation.

<a id="tensor-bundles-scope"></a>

## The literal balanced quotient for a set action

`Orbifolds.TensorBundles` completes the balanced-quotient construction
in [Myers, Proposition 2.2.6](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm6).

### Actual quotient and its relation

For an algebraic group `G`, a set action `A`, and an algebraic left torsor
`t`, the module defines `At.Tensor t` as the Cubical set quotient of
`TorsorCarrier t × Carrier A`. Its relation is

```agda
Balanced a b = Σ[ g ∈ G .fst ]
  (b .fst ≡ act (t .fst) (inv g) (a .fst))
  × (a .snd ≡ act A g (b .snd))
```

Thus `At.balancing` gives precisely

```text
u ⊗ (g · x) = (g⁻¹ · u) ⊗ x.
```

The definition is the actual balanced set quotient, not an opaque object
required to satisfy its universal property. The theorem `tensor-isSet`
supplies its sethood.

### Equivalence with equivariant functions

The accepted `EquivariantBundles` module constructs the type of equivariant
functions from each torsor to `A` and proves that evaluation at any torsor
point is an equivalence. `At.pair-to-bundle (u,x)` is its inverse at `x`.
`At.pair-evaluation` proves that this function takes `u` to `x`.

Equivariance and the inverse action law show that this map respects the
displayed balancing relation. Set-quotient recursion therefore defines
the actual comparison `At.comparison`.

Given a torsor point `u₀`, an inverse sends an equivariant function `f` to
`u₀ ⊗ f(u₀)`. Evaluation gives one inverse law. For the other, the torsor's
orbit equivalence supplies the unique element carrying a representative's
torsor coordinate to `u₀`; the balancing constructor and equivariance then
give the required equality in the quotient. Quotient induction extends it
to all quotient elements.

The torsor point is eliminated from its mere existence only into the
proposition that the comparison is an equivalence. No global torsor
basepoint, choice principle, classical axiom, or cohesive axiom is used.
The resulting equivalence is exported as `tensor≃bundle`.

### Pointed family and action computation

`Tensor : T.Torsor → Type ℓ` is the actual quotient family. At the regular
torsor, its coordinate equivalence is `regular-coordinates`, whose behavior
on every representative is proved by `regular-point-computation`:

```text
regular-coordinates (g ⊗ x) = g⁻¹ · x.
```

`classify-action` sends a torsor to this actual quotient fiber in the
automorphism delooping of the action's carrier. `classify-action-point`
supplies its pointing via univalence applied to `regular-coordinates`.

The naturality theorem `comparison-transport` compares transport in the
literal quotient family with transport in the equivariant-function family
for every actual torsor identity. Finally, `tensor-action-transport`
computes transport around the loop corresponding to `g`, in the regular
coordinates, as the original action `x ↦ g · x`.

The loop convention is inherited explicitly from `EquivariantBundles`:
`group-loop g = T.element-loop (inv g)`. This matches the reversed loop
product used for left family actions in `Quotients`; it is not silently
identified with the ordinary-concatenation convention of the separate
torsor loop-group equivalence. This construction and its basepoint formula
use the left-torsor and left-action convention displayed in Proposition
2.2.6 and Remark 2.2.7.

### Checking and implementation scope

The earlier draft stalled during reduction of the evaluation-equivalence
certificate inherited from the torsor univalence proof. The completed
module uses local `abstract` blocks for that already proved certificate
and for the proof that the quotient comparison is an equivalence. Agda
still checks both proof terms; their opacity prevents unnecessary later
normalization. The evaluation map, quotient, quotient comparison, pointed
family, and action computations remain explicit.

No accepted dependency was modified. The only mathematical inputs are
the actual Cubical algebraic group and its set action. This result does
not claim the separate extension-of-torsors construction for a group
homomorphism in Proposition 2.2.2 or a general classification theorem for
arbitrary deloopings.

<a id="torsor-extension-scope"></a>

## Extension of torsors along a group homomorphism

`TorsorExtension.agda` and `TorsorHomomorphisms.agda` prove the literal
balanced-quotient construction and the delooping assertion of
[Myers, Proposition 2.2.2](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm2).

### Exact inputs and mathematical scope

The modules are universe polymorphic in a common level `ℓ`. Their inputs
are actual Cubical algebraic groups `G H : Group ℓ` and an actual
`hom : GroupHom G H`. Write `φ = hom .fst`. The homomorphism has its
multiplication, unit, and inverse preservation fields. No injectivity or
surjectivity of `φ` is assumed.

The construction uses the accepted algebraic torsors from `Torsors.agda`:
a set with a left group action, mere inhabitedness, and an equivalence
for every orbit map. It uses Cubical univalence, set quotients, and
propositional truncation. It assumes no classical choice, crisp excluded
middle, real or differential axioms, cohesive rules, or resizing.

### Literal quotient and its actual left action

For a `G`-torsor `t`, the carrier `At.Extended t` is the set quotient of
`H × TorsorCarrier t` by the relation

```agda
Balanced a b = Σ[ g ∈ G .fst ]
  (a .fst ≡ b .fst · φ g)
  × (b .snd ≡ GT.act (t .fst) g (a .snd))
```

In particular, its quotient constructor `At.balancing` identifies

```text
(h φ(g)) ⊗ u = h ⊗ (g · u).
```

The `H` action is defined directly by set-quotient recursion:

```text
k · (h ⊗ u) = (k h) ⊗ u.
```

Preservation of the balancing relation follows from associativity. Unit
and composition laws follow by quotient induction from the corresponding
group laws. Thus the literal quotient has an actual `H`-action before
its torsor property is established.

### Proving the torsor property without a global choice of points

Restrict left multiplication on `H` along `φ` to obtain a set action of
`G`. The accepted equivariant-function bundle for this action consists of
functions `f : TorsorCarrier t → H` with `f(g · u) = φ(g) f(u)`.

The quotient comparison sends `(h,u)` to the unique equivariant function
whose value at `u` is `h⁻¹`. The checked comparison from `TensorBundles`
supplies this function and its evaluation law. Its balancing proof
converts the group coefficient by the inverse-product law and by
preservation of inverse under `φ`.

Given one point `u₀` of the input torsor, an inverse comparison sends `f`
to `f(u₀)⁻¹ ⊗ u₀`. The inverse laws use evaluation and the unique group
element translating a representative's point to `u₀`. Quotient induction
extends the representative calculation to all elements. Mere existence
of `u₀` is eliminated only into the proposition that the comparison is an
equivalence; no point is selected for every torsor.

Under this comparison the actual left action on the quotient becomes
`(k · f)(u) = f(u) k⁻¹`. Inverting evaluation at an input-torsor point
therefore gives an `H`-equivariant equivalence from the quotient to the
regular `H` action. This proves that each quotient orbit map is an
equivalence. Again, the input point is eliminated only into that
proposition-valued conclusion.

Mere inhabitedness is obtained by mapping an input point `u` to
`1 ⊗ u`. Together these results give the actual map

```agda
Extend : GT.Torsor → HT.Torsor
```

Its carrier is judgmentally the literal balanced quotient defined above.

### Pointing and its computation

At the regular `G`-torsor, `regular-coordinates` is an equivariant
equivalence to the regular `H`-torsor. Its representative computation is

```agda
regular-point-computation : (h : H .fst) (g : G .fst)
  → regular-coordinates .fst (At.tensor GT.regular-torsor h g)
    ≡ h · φ g
```

The structure identity principle converts this actual equivariant
equivalence into

```agda
pointing : Extend GT.regular-torsor ≡ HT.regular-torsor
```

`pointing-transport` checks its transport computation using univalence.
In particular, the distinguished representative `1 ⊗ 1` transports to
the unit of `H`.

### The statement for every actual loop

`TorsorHomomorphisms` uses the actual pointed loop map of `Extend`:
conjugation of `cong Extend p` by the displayed pointing. It proves

```agda
loop-coordinate-square : (p : Q.Loop GT.torsor-delooping)
  → HT.transport-point HT.regular-torsor (loop-map p)
    ≡ φ (GT.transport-point GT.regular-torsor p)
```

This quantifies over every actual torsor identity loop. It is not
restricted to a chosen set of representatives. The proof uses the
natural family map `u ↦ 1 ⊗ u`, its transport law, the computation of the
pointing on `1 ⊗ 1`, and the regular-coordinate formula.

The loop groups here use ordinary path concatenation, matching the
accepted `torsor-loop-group-equivalence`. Applying the injective loop
coordinate map of `H` to the two sides of a proposed multiplication law
reduces that law to the all-loop square, multiplication compatibility of
both loop-coordinate equivalences, and the multiplication field of
`hom`. This produces

```agda
loop-homomorphism : GroupHom GT.torsor-loop-group HT.torsor-loop-group
```

Unit and inverse compatibility follow from the checked Cubical
`makeIsGroupHom` construction. The module then composes this actual
homomorphism with the two checked loop-group equivalences, obtaining
`delooped-homomorphism : GroupHom G H`. The final theorem is the equality
of complete homomorphism records:

```agda
delooped-homomorphism≡original : delooped-homomorphism ≡ hom
```

Thus the constructed pointed map of torsor deloopings recovers the
original group homomorphism, including its group structure. The literal
quotient, its torsor action, its pointing, and this loop compatibility
are all checked; none is supplied as an additional axiom or certificate
input.

<a id="subgroup-delooping-scope"></a>

## Subgroup exemplars and their actual transport

Three modules construct subgroup deloopings using literal predicate subobjects, first in the algebraic torsor model and then in any pointed connected groupoid.

These results address
[Myers, Proposition 2.2.13](https://arxiv.org/html/2205.15887v1#S2.SS2.Thmthm13).
The broader arbitrary-action formula printed in Lemma 2.2.12 is a
separate question and is not assumed by any of these proofs.

### Actual subgroup subobjects

`SubgroupTorsors.Subgroup` takes an algebraic `Group ℓ` and a Cubical
`Subgroup G`. The subgroup is a proposition-valued subset closed under
unit, multiplication, and inverse; no normality or decidable membership
is assumed.

For an actual left `G`-torsor `T`, a `Subtorsor T` contains a literal
predicate `P : Carrier T → hProp ℓ`, stability under the subgroup action,
and torsor laws for the induced action on `Σ x , P x`. The additional
structure is proposition-valued, so `Subtorsor T` is a set.

The total type `Σ T , Subtorsor T` has the regular `G`-torsor with its
subgroup predicate as its point. It is a groupoid and is connected.
For connectedness, a point in a subtorsor gives an equivariant orbit
equivalence from the regular torsor to the ambient torsor. Its structural
identity carries the subgroup predicate to the given subobject. The
subtorsor's mere inhabitedness is eliminated only into mere path
existence; no global selection of subtorsor points is used.

### Transport and the loop calculation

`transport-membership` proves the ordinary covariant transport formula:

```text
transported P at x = P (inverse carrier transport of x).
```

The inverse is explicit in the checked statement. For the regular left
`G`-torsor, `SubgroupDelooping.carrier-transport-right` separately proves
that carrier transport around a loop `p` is right multiplication by the
loop's coordinate:

```text
transport p x = x · coordinate(p).
```

This transport is `G`-equivariant. Consequently the transported subgroup
subobject equals the original exactly when `coordinate(p)` belongs to
the subgroup. The two implications are proved using actual predicate
transport and subgroup closure laws.

The dependent-sum identity calculation now gives an equivalence between
loops in the total type and subgroup elements. Multiplication is proved
compatible with ordinary loop concatenation, yielding the complete
`subgroup-loop-group-equivalence : GroupEquiv ... Γ`.

The first projection is treated as an actual pointed map. Its induced
loop map is a checked group homomorphism, and
`projection-deloops-inclusion` proves equality of the recovered
`GroupHom Γ G` with the subgroup inclusion.

### Arbitrary delooping models

`SubgroupDeloopingModels.Model` takes any `D : Delooping ℓ`, a proof that
its carrier is a groupoid, and a subgroup of its actual loop group.
The accepted `TorsorClassification` theorem provides a pointed
equivalence from `BG D` to the torsors of that loop group.

Reindexing the predicate-subtorsor family along this actual classifier
gives the exemplars

```text
(b : BG D) × Subtorsor (associated torsor of b).
```

The module proves connectedness, groupoid level, the loop-group
equivalence with the subgroup, and the same equality asserting that the
first projection deloops the inclusion. The pointing coherence of the
classifier is included in the loop calculation. Its group parameter is
`G = Ω(BG D)`, the higher-group convention, so an arbitrary delooping
model is allowed rather than only the canonical torsor model.

The associated-torsor orientation follows the accepted classifier:
paths `point = b` with ordinary concatenation. This convention is
explicit; it does not silently replace the inverse/right-translation
calculation by an arbitrary left action. Equivalences relate displayed
universe levels without resizing.

All modules use only Cubical HoTT, actual algebraic groups, and the
proved torsor classification. No cohesive, synthetic-real, classical,
normality, or choice premise was added. No accepted dependency was edited.

<a id="principal-bundles-scope"></a>

### Checked statement

Myers, Proposition 3.3.2, says that maps from a type `A` into an action
quotient correspond to principal bundles over `A` equipped with an
equivariant map from their total space into the acted-on type.

Primary source:
<https://arxiv.org/html/2205.15887v1#S3.SS3.Thmthm2>.

The checked sources are `StructuredBundles.agda`, `PrincipalBundles.agda`,
and `AlgebraicPrincipalBundles.agda`. They use ordinary Cubical Agda
univalence, dependent sums, and identity elimination. No differential or
cohesive axiom, choice principle, resizing axiom, or additional postulate
is used. In particular, this result is independent of the correction to
the predicate-transport formula printed in Lemma 2.2.12.

### Actual bundles and the higher-group theorem

`StructuredBundles.Classification.maps≃bundles` proves the general
univalent fibration calculation. Its output includes an actual total
type `P`, an actual map `π : P → A`, structure on each literal homotopy
fiber `fiber π a`, and a section of the associated family. The inverse
laws are full paths of these data. The source and target are not merely
shown equiinhibited.

`PrincipalBundles.Higher` accepts an arbitrary pointed connected type
`G` and an arbitrary action family `X : BG G → Type`. Its torsor
structure on a carrier `E` is the standard representable presentation:
an exemplar `b : BG G` and an equivalence `E ≃ (b = point)`. This
presentation defines the coherent action family `t ↦ (b = t)`, with
contractible quotient. It is not an assumption that all torsors have
this form: `CoherentTorsor.coherent-torsor-representability` proves, by
the fundamental theorem of identity types, that every action family
whose quotient is contractible is equivalent to this representable
family. `family-identification` gives the resulting equality of whole
families, retaining their higher coherence.

The final theorem is
`Higher.Over.maps-to-quotient≃principal-bundles`. A bundle has torsor
structures on its actual fibers. Its action family is
`Twist t = Σ a , (classify a = t)`, exactly the orientation used in the
paper's 3.3.2 calculation. `Bundle.total-coordinates` identifies the
fiber at the basepoint with the actual `P`. Equivariant maps are maps
between whole dependent action families, which is the higher-group
definition used in the paper. The source constructs the map on `P`,
proves its loopwise equivariance, identifies the action quotient with
`A`, and proves that the quotient map agrees with `π` under the total
coordinates.

All types can be placed in a common universe; the action target has an
independent universe parameter. The universe of small carriers appears
at its actual successor level. No smallness identification is assumed.

### Ordinary algebraic groups

`AlgebraicPrincipalBundles.Ordinary.Action.Over` accepts an ordinary
algebraic group, a set action, and any base type `A` in the common
carrier universe. It requires no sethood hypothesis on `A`.

Here a fiber torsor structure consists of an actual operation, the
checked action laws and sethood, mere inhabitedness, and equivalence
of each orbit map. The proof constructs the induced operation on
`P`, verifies that it preserves the projection, and proves its unit
and composition laws. `Bundle.EquivariantMap` uses precisely the
ordinary condition `f (g · p) = g · f p`; equivalence with sections
of the associated family is proved, rather than defined.

Two final equivalences are supplied:

- `maps-to-quotient≃principal-bundles`, for the accepted
  equivariant-function presentation of the action family;
- `maps-to-tensor-quotient≃principal-bundles`, for the literal balanced
  tensor quotient constructed and compared in `TensorBundles.agda`.

<a id="split-extension-scope"></a>

## Constructed split extensions and quotient calculations

This work supports the torus example in Myers, Corollary 3.2.9:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.
The statements below are bounded algebraic and homotopy-theoretic
intermediates. They do not assume or assert a classification of a smooth
torus, a lattice, or a crystallographic group.

### Accepted algebraic construction

`SemidirectProducts.agda` constructs the group `N ⋊ H` on `N × H`
from an actual action of `H` by group automorphisms of `N`. Its
multiplication is `(n,h)(m,k) = (n · h(m), h · k)` and its inverse
is `(h⁻¹(n⁻¹), h⁻¹)`. All group laws are checked.

The code constructs group homomorphisms for the normal inclusion,
projection, and splitting. It proves that the inclusion embeds, that
the projection is surjective, and that its actual algebraic kernel is
group-equivalent to `N`. It also proves the semidirect factorization
and conjugation relation. Compatible actions of `N` and `H` on a set
produce an actual action of `N ⋊ H`; its restrictions are proved to
recover the supplied operations.

### Accepted delooped-kernel theorem

`DeloopedKernels.agda` takes an arbitrary surjective group homomorphism.
It uses the actual balanced-torsor extension map already constructed
in `TorsorExtension.agda` and its checked all-loop computation in
`TorsorHomomorphisms.agda`. The actual homotopy fiber over the image of
the regular torsor is proved connected and a groupoid. Its full loop
group is proved group-equivalent to the literal algebraic kernel.
The first-coordinate computation identifies the induced inclusion on
all loops. Surjectivity, the homotopy fiber, and the loop equivalence
are proved rather than inserted as classifier hypotheses.

### Accepted iterated quotient theorem

`GroupExtensionQuotients.agda` constructs the quotient iteration for
every surjective homomorphism `φ : G → H` and every set action of
`G`. It uses the actual torsor-extension map `E : BG → BH`. Its
outer action family over `BH` is the actual dependent sum
`Inner h = Σ t : BG , (E t = h) × Xᵗ`. The fiber at the image of the
regular torsor is the genuine homotopy quotient of the restricted
action over the actual kernel delooping. The underlying loop group
of this delooping is identified with `ker φ` by the preceding
accepted theorem; its action transport is computed as the actual
restriction of the supplied `G` action.

Reassociating these dependent sums constructs an equivalence from
the iterated quotient to the original `G` quotient, with inverse
laws. The quotient-map triangle is also proved, and its stated
forward computation is definitionally reflexive. If the extension
has a group-homomorphic splitting, the code constructs the outer
loops from that actual splitting, computes their coordinates in
`H`, and computes their action on every image of a point of `X`.

`SplitExtensionQuotients.agda` instantiates all of this using the
actual semidirect group and splitting from `SemidirectProducts`.
Its main theorem is
`Construction.Compatible.iterated-quotient≃semidirect-quotient`.
The actual normal-fiber and outer loop groups are group-equivalent
to `N` and `H`. `normal-action-transport` computes the supplied
normal action. `outer-action-on-orbits` computes the supplied
compatible `H` operation on every orbit point. The full dependent
families retain all higher coherences and isotropy; the proof does
not infer a complete higher action merely from its value on points.

The normal and outer deloopings here are explicitly constructed
models, identified by full loop group equivalences. No desired
delooping, kernel classifier, or quotient equivalence is a premise.
The only input algebra is the two groups, an automorphism action,
and the ordinary compatibility of their actions on the set `X`.

### Torus specialization

The translation quotient, integral-affine action, shape calculation and
crystallographic certificate are treated in [Tori](torus.md) and
[Integral affine geometry](integral-affine.md). They are additional geometric
constructions, not consequences assumed by the generic split-extension theorem.

<a id="torsor-quotient-scope"></a>

## Recognition of a quotient from torsor fibers

`TorsorQuotientRecognition.agda` proves
[Myers, Theorem 2.3.5](https://arxiv.org/html/2205.15887v1#S2.SS3.Thmthm5)
from explicit algebraic torsor structures on the actual fibers of a map.

### Inputs are structures on the supplied map's fibers

The input data are `G : Group ℓ`, types `X Y : Type ℓ`, a map `q : X → Y`,
and a `FiberTorsorStructure` containing:

- An action `G → fiber q y → fiber q y` for each ordinary `y : Y`.
- The sethood, unit, and composition laws for those actions.
- Mere inhabitedness and free transitivity, expressed by equivalence of
  each orbit map, for every fiber.

Neither `X` nor `Y` is assumed to be a set. The data do not include a
classifying map, an action on `X`, or a quotient equivalence. Those are
constructed. No choice of a point in every fiber is made. The construction
uses Cubical HoTT and the accepted algebraic torsors, with no real,
differential, cohesive, classical, or resizing assumptions.

### Small action family and actual pointing

The data give an actual `classify-fibers : Y → T.Torsor`. The family

```agda
Twist t = Σ[ y ∈ Y ] T.ActionEquiv (t .fst) (classify-fibers y .fst)
```

lies in `Type ℓ`. The theorem `twist≃classified` identifies it, for each
torsor `t`, with the paper's family of pairs `(y, t ≡ classify-fibers y)`.
This is a checked equivalence across the displayed universe levels;
it does not resize the larger identity type of torsor structures.

At the regular torsor, the checked evaluation equivalence identifies
`Twist regular-torsor` with the sum of the fibers of `q`, hence with `X`.
Its inverse is the explicit map

```agda
to-pointed-fiber x =
  q x , T.orbit-equivalence (classify-fibers (q x)) (x , refl)
```

The equivariant equivalence in this pair sends the group unit to
`(x,refl)`. Its equivalence property is checked, not assumed.

The resulting `pointed-classifier` maps the torsor delooping into
`BAut(X)`, with a proved `classifier-point`. Thus the action is an actual
pointed family in the same universe as `X`, matching the definition of
a group action used in the paper.

### The quotient map, not merely the quotient type

The action quotient is the dependent sum `Σ t , Twist t`. The existing
`Quotients.ClassifiedBundle` theorem applies after the pointwise
`twist≃classified` comparison, giving

```agda
quotient≃Y : action-quotient ≃ Y
```

Its forward map sends `(t,y,e)` to `y`. The quotient map on the original
`X` is `Action.quotient ∘ to-pointed-fiber`, so the exact map comparison
computes without an additional path argument:

```agda
quotient-triangle : (x : X)
  → quotient≃Y .fst (quotient-map x) ≡ q x
quotient-triangle x = refl
```

The final theorem packages the equivalence and the commuting triangle as
an equality of functions:

```agda
q-is-homotopy-quotient :
  Σ[ e ∈ (action-quotient ≃ Y) ] (e .fst ∘ quotient-map ≡ q)
```

All higher identifications are retained. No set quotient is substituted
for the dependent-sum homotopy quotient.
<a id="small-fiber-torsor-quotients"></a>

## Quotient recognition from actual small fiber torsors

`Orbifolds.SmallFiberTorsorQuotients` is accepted by the canonical Agda
2.8.0.2 kit with `--safe --cubical --cohesion`, without warnings. It is a
cross-universe extension of the checked algebraic quotient recognition
used for Theorem 2.3.5 of [the paper](https://arxiv.org/html/2205.15887v1).

### Exact input

`Recognition G A {Y} q.Given fibers coordinates coordinate-equivariance`
takes an actual group `G : Group ℓ`, an ordinary algebraic action `A` on
its set carrier `X : Type ℓ`, an independently sized `Y : Type ℓy`, and
the specified map `q : X → Y`. The remaining inputs are:

- actual small algebraic torsors `fibers : Y → T.Torsor`;
- actual equivalences `coordinates y : Carrier (fibers y) ≃ fiber q y`;
- equivariance of the first coordinate with respect to the specified
  action on `X`.

The last field is only the equation
`fst (coordinates y (g · z)) = g · fst (coordinates y z)`.
It does not demand an additional equality between the displayed paths
in the literal fibers. Neither `Y` nor its identities are assumed small.

### Checked output

`quotient≃Y` identifies `Y` with the literal homotopy quotient of the
supplied action, namely the dependent sum of
`EquivariantBundles.Theory.Action.Bundle G A` over the actual algebraic
torsor delooping. `quotient-triangle` proves that this equivalence sends
`(regular-torsor, orbit x)` to `q x`. The theorem
`q-is-action-quotient` packages the equivalence and the equality of these
maps together. Surjectivity of `q` is also derived.

For a torsor `t`, the proof forms
`Twist t = Σ y, ActionEquiv t (fibers y)` and maps it to the associated
bundle by applying the supplied coordinate maps. Evaluation at the unit
proves this map is an equivalence for the regular torsor. Mere
connectedness extends the proposition that it is an equivalence to all
torsors. Structural univalence and the already checked classified-bundle
calculation identify the total space with `Y`.

No chosen global torsor points, resizing principle, classical choice,
crispness, real-field axiom, or new postulate is used. `Twist t` can live
in a larger universe; its equivalence to the small associated bundle is
a derived theorem. In particular, the result applies to an elliptic
parameter space in `Type ℓ` mapping to lattice moduli in `Type (suc ℓ)`.
The concrete construction of those lattice fiber torsors and their
equivariance remains a separate obligation; this generic result does
not by itself certify that instantiation.

