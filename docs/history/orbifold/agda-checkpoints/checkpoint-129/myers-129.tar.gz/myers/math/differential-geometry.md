# Differential geometry

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="weil-presentations"></a>

## Actual Weil presentations and infinitesimal zero loci

The modules `Orbifolds.WeilPresentation` and `Orbifolds.WeilZeroLocus`
prove Lemmas 4.1.3, 4.2.7, and 4.2.9 and the universal-property content of
Remark 4.1.6 of [arXiv:2205.15887](https://arxiv.org/abs/2205.15887).
They use the pinned Cubical library's actual polynomial rings, generated
ideals, quotient algebras, and finite-presentation universal property.

### Augmentation-zero finite presentations

`WeilPresentation.Presentations R.Universal p A.hom≃solutions` identifies
algebra homomorphisms from the actual finitely presented algebra with tuples
of elements of `A` satisfying the actual polynomial relations. The proof
includes both inverse laws and a derived computation theorem for induced
homomorphisms on the quotient generators.

`Translation n c` constructs the polynomial homomorphisms sending each
variable to the variable minus or plus its specified scalar. Their composites
are proved equal to the identity as algebra homomorphisms.

`Center p a` replaces each defining relation by its translated polynomial.
It constructs maps between the two quotient algebras, proves both inverse
laws using the finite-presentation universal property, and proves that every
new generator has zero augmentation. Consequently
`augmentation-zero-presentation` produces a merely existing
`StandardPresentation` from an arbitrary augmented finitely presented
algebra. The record is a proved conclusion, not an additional hypothesis.
`StandardFacts.augmentation-square` proves that the induced evaluation at
zero equals the original augmentation composed with the constructed
algebra equivalence. This is the full augmented-algebra conclusion of
Lemma 4.1.3.

### Neighborhoods, nilpotence, and polynomial fibers

`WeilZeroLocus.finite-neighbors` proves that a finite tuple of pairwise
double-negation neighbors is itself a double-negation neighbor. It uses
finite induction; no choice, excluded middle, or field hypothesis is needed.
`coordinate-neighborhood-equivalence` therefore gives the equivalence in
Lemma 4.2.7 for the actual finite powers of
`𝔇 = Σ[x : R] ¬¬(x = 0)`.

`NilpotentCoordinates.kernel-coordinate-neighbor` proves that the value of
an augmentation-kernel element at any spectrum point is a neighbor of zero.
The proof sends the actual nilpotent-ideal product equation through an
algebra homomorphism. If its value were nonzero, Postulate K would make it
invertible, hence every positive power invertible; its vanishing power
would contradict the field's nontriviality. The merely existing ideal
nilpotency exponent is eliminated only into a proposition.

`PolynomialMap` restricts an actual finite tuple of polynomial evaluations
to powers of `𝔇`, proves that it sends zero to zero when the equations do,
and identifies its solution subtype with its fiber over zero. `FromStandard`
then supplies both directions of the pointed spectrum equivalence.

The final theorem
`infinitesimal-variety-zero-locus` proves the exact merely pointed-equivalent
formulation of Lemma 4.2.9. Its conclusion retains the natural numbers,
polynomials, zero equations, actual fiber equivalence, and basepoint
equation. Its mathematical hypotheses are a commutative scalar ring,
Postulate K as the explicit `KockField` argument, and the existing definition
of an infinitesimal variety through an actual Weil algebra. It does not
require Kock–Lawvere reflexivity or assume a zero-locus description.

### Interface to crystalline connectedness

The zero-locus construction uses exactly
`CrystallineZeroLoci.Ring R.InfinitesimalPower` and `zero-power`. For a
presentation `p`, `PointedPolynomialPresentation.Locus p.infinitesimal-map`
is the polynomial map needed by `CrystallineZeroLoci.ZeroLocus`. Its
`presentation-equivalence` and `presentation-pointed` can be supplied to
the existing connectedness theorem once the independently scoped modal
fiber-preservation hypothesis is available. These two algebraic modules
do not assert that crystalline nullification preserves arbitrary fibers.

<a id="weil-category-duality"></a>

## The actual Weil-spectrum equivalence of categories

`WeilCategories.agda` completes the categorical packaging of Lemma 4.2.2.
It passed the canonical native Agda 2.8.0.2 safe check, exit status zero
and no warnings. The exact input is an ordinary commutative ring and the
existing algebraic Kock--Lawvere evaluation axiom on actual Weil algebras.

`Ring.WeilCategory` has the already constructed finitely presented
augmented Weil algebras as objects and augmentation-preserving algebra
homomorphisms as arrows. Identity, composition, their laws, and hom
sethood are checked. The target is the full category of pointed sets
merely equivalent to actual Weil spectra, previously used for 4.2.14.

`spectrum-functor` is contravariant, with the actual precomposition map
on spectra. Its full faithfulness is the earlier augmented spectrum
duality theorem. The new work supplies an actual inverse on objects:
to a pointed infinitesimal variety `(X,x)` it assigns the function
algebra `X -> R`, augmented by evaluation at x.

The function algebra's Weil properties are proved. Algebra univalence
first gives a path of augmented algebras from a Weil algebra to its
function algebra on the spectrum. Its finite presentation, finitely
generated augmentation kernel, and nilpotent kernel transport along
that path. A mere spectrum presentation of X is eliminated only into
the proposition asserting these three Weil properties. No basis,
presentation, or spectrum representative is selected by choice.

The point-evaluation map `X -> Spec(Functions X)` is proved an
equivalence for every actual infinitesimal variety. Together with the
augmented evaluation path, this proves both inverse laws on objects.
Full faithfulness and this object equivalence then yield the library's
actual categorical equivalence, with an inverse functor and natural
isomorphisms represented by `isEquivalence`:

```agda
spectrum-duality : (WeilCategory ^op) ≃ᶜ InfinitesimalVarieties
```

This is more than a pair of hom-set equivalences or a bare assertion
of essential surjectivity. It introduces no additional algebraic,
classical, cohesive, or resizing assumption.

### Completed map-class inclusion

`ShapeCrystallineClasses.agda`, also proved,
completes the remaining equivalence clause of Lemma 4.3.7. Every map
inverted by the actual crystalline nullification is inverted by the
actual shape nullification. The proof uses the already proved coherent
orthogonality characterization and the inclusion from shape-etale maps
to crystalline-etale maps. The type, modal-fiber, connected-fiber, and
etale inclusions remain in `Crystalline.agda`. This part needs only a
commutative ring and the actual two nullification constructions.

<a id="square-zero-weil"></a>

## Actual Weil algebras for first-order coordinate disks

The modules `PresentedAugmentationIdeals`, `SquareZeroWeil`, and
`TinyFirstOrderDisks` are accepted by the pinned native Agda kit with
`--safe`, no unsolved metas, and no warnings.

For every commutative ring R and every natural n, `SquareZeroWeil.Coordinates`
constructs the literal finitely presented algebra

R[X₁,…,Xₙ] / (XᵢXⱼ : 1 ≤ i,j ≤ n).

The finite relation family is indexed by the actual equivalence
`Fin n × Fin n ≃ Fin (n*n)`. Evaluation at zero is an actual augmentation.
Its kernel is generated by the coordinate generators, and the product of
any two kernel elements is zero. Thus this is a `WeilAlgebra` according to
the existing definition, including finite presentation, finite generation
of the augmentation ideal, and a single uniform nilpotence exponent.

The proof of finite generation is independently useful:
`PresentedAugmentationIdeals.Presentation` handles any finite presentation
whose chosen generators augment to zero. Polynomial induction proves that
an element minus its scalar augmentation is a linear combination of the
generators. The actual quotient map is surjective, so the result descends
to all presented elements and hence the whole augmentation kernel. This
does not assume a normal-form theorem or an unproved presentation axiom.

The universal property of the finite presentation then gives an actual
pointed equivalence between its spectrum and

D(n) = Σ (x : Fin n → R), ∀ i j, x i * x j = 0.

The forward map reads off the coordinate generators, and its value at the
augmentation is proved to be the zero vector. These algebraic and spectrum
results need neither Postulate J, Postulate K, nor excluded middle.

### Consequences for Postulate W and higher groups

`TinyFirstOrderDisks.Context.WeilTinyness` is precisely the restriction of
Postulate W to all actual crisp Weil spectra. The `disks-tiny` theorem
derives tinyness of every crisp D(n), using the constructed pointed
equivalence and the checked equivalence invariance of external tinyness.
No choice of a global family of tiny right adjoints is made.

The final `Consequences.preserves-infinitesimal-linearity` proves the
coordinate-disk version of Theorem 5.5.3 directly from that global Weil
tinyness hypothesis. The previously staged `TinyDisks` input is thereby
discharged. The final `tangent-delooping` and `lie-algebra-loops` wrappers
likewise use the literal square-zero test already used by
`SyntheticDifferential`, with its actual pointing.

The wrappers retain the explicit R-flat and crisp structural inputs of the
underlying tiny-type theorems. They do not prove the coherent R-module part
of Theorem 4.2.19 or Corollary 5.5.5. Those require the additional algebraic
theory of finite free modules. The fully faithful first-order patch functor
and its real-pushout property (4.2.14–15) also remain separate obligations.

Source: [Definitions 4.2.13–16 and Theorem 5.5.3 in the paper](https://arxiv.org/html/2205.15887v1).
<a id="first-order-real-pushouts"></a>

### Lemma 4.2.15: the canonical comparison for R

`FirstOrderRealPushouts` proves that the actual restriction map

(D(n+m) -> R)
      -> Pullback(evaluate-zero : (D(n) -> R) -> R,
                  evaluate-zero : (D(m) -> R) -> R)

is an equivalence, for every ordinary n and m. The two restrictions
are precomposition by the exact zero-padding axes defined earlier;
their commuting path is action on the specified equality of origins.

The proof uses the already derived Kock--Lawvere affine equivalence

R x (Fin n -> R) ~= (D(n) -> R).

Compatible pairs of affine maps have the same constant coefficient.
Their coefficient vectors therefore combine by the actual finite
block decomposition. This gives an equivalence on compatible affine
data. Finite-sum identities prove that restriction along each axis
has exactly the corresponding coefficient block. The resulting map
is then proved equal to the literal canonical comparison, and its
equivalence certificate is transferred along that equality.

The ring's sethood is used for uniqueness of the equality coordinate
in this R-valued comparison. No sethood of a general later target X
is inferred from it. The theorem assumes the project's global
Kock--Lawvere condition on actual Weil algebras; the affine theorem
was itself derived from their constructed square-zero normal forms.
No separate affine-coordinate or real-pushout axiom is added.

### Actual Weil-spectrum test squares

`FirstOrderWeilPushouts` packages the disk square as a square of
pointed types. Its northwest corner is D(0), proved contractible;
the other corners are D(n), D(m), and D(n+m). Its north and west maps
are constant at zero, and the east and south maps are the literal
axis inclusions, with their actual pointing paths.

Pointed univalence transports the entire square, including its maps,
pointing paths, and commuting homotopy, to the spectra of the actual
square-zero Weil algebras. The source retains a path of complete
`Microlinearity.TestSquare` records between the disk and spectrum
squares. Thus an `IsPushoutFor` certificate transports for its actual
canonical mapping comparison, for arbitrary higher X. The proof does
not replace a specified comparison by the existence of some
equivalence between endpoint types.

This yields an actual `WeilDiagrams.Geometry.WeilRealPushout` for
each pair n,m, with the R-pushout property proved by the preceding
affine-coordinate argument. The mapping cocone over D(0) is
equivalent to the usual evaluation pullback by its actual
contractibility, and the comparison maps agree definitionally under
that equivalence.

### Exact native-crisp microlinearity implication

The public API

FirstOrderWeilPushouts.CrispContext
      R identity-zero flat-zero flat-zero-computation
      .microlinear->infinitesimally-linear real-flat KL micro

proves infinitesimal linearity from the exact project
`CrispGeometry.Context.Microlinear` definition, whose test family
consists of `Flat WeilRealPushout`.

For crisp n,m, the underlying square-zero Weil diagram is crisp and
independent of the Kock--Lawvere proof. The ordinary KL proof proves
the small proposition that this fixed diagram is an R-pushout.
`CrispPropositions.promote-proof` derives a Flat representative of
that proof from R-flatness; eliminating it gives the actual boxed
test diagram required by microlinearity. This promotes only a small
proposition. It does not promote an arbitrary type, assume upper-
universe R-flatness, or require the global KL witness to be crisp.

Derived discreteness of Nat then extends the crisp n,m cases to all
ordinary dimensions. The small-universe identity and Flat
induction/computation rules are the already explicit ambient inputs
used for that discreteness theorem. X remains arbitrary in the
working universe; none of its identity types are truncated.

The pure `Ring` module additionally supplies the implication for
microlinearity quantified over all ordinary actual Weil R-pushout
diagrams. The native-crisp wrapper is the one matching the existing
geometric development. Combining it with `HigherTangentModules`
gives the concrete represented higher R-module presentation on the
tangent fibers of every existing microlinear example.

<a id="first-order-patches"></a>

## Finite free modules and first-order infinitesimal patches

The following five modules have passed the canonical Agda 2.8.0.2 safe
native-kit check with cohesion enabled, exit status zero and no warnings:

- `FirstOrderLinearMaps.agda`
- `SquareZeroExtensions.agda`
- `SquareZeroNormalForm.agda`
- `FirstOrderKockLawvere.agda`
- `FirstOrderFullFaithfulness.agda`

They complete Lemma 4.2.14 in the finite-coordinate presentation of finite
free modules. The categorical finite coproducts and higher tangent module
model are documented separately in `differential-geometry.md#higher-tangent-modules`.

### Actual categories and maps

`FirstOrderLinearMaps.Ring.MatrixCategory` has natural-number objects and
actual matrices as arrows. Matrix evaluation is proved equivalent to
`LeftModuleHom` between the corresponding coordinate modules, using their
actual basis expansion. Thus the finite-coordinate presentation uses the
usual linear maps rather than functions supplied with an unrelated name.

Matrix evaluation preserves zero and all pairwise-zero coordinate products.
It therefore defines an actual functor to pointed sets whose object at n
is the literal disk `D(n) = {d : R^n | d_i * d_j = 0}`. Identity and
composition laws, including the pointing paths, are checked.

### Constructed square-zero normal form

`SquareZeroExtensions.Extension` constructs the commutative R-algebra
`R + R^n` with multiplication `(r,v)(s,w) = (rs,rw+sv)`. All algebra laws
and the scalar structure are proved from the commutative-ring laws.

`SquareZeroNormalForm.Coordinates.algebra-equivalence` identifies this
algebra with the actual finitely presented algebra
`R[X_1,...,X_n]/(X_i*X_j)` constructed in `SquareZeroWeil`. One direction
uses the finite-presentation universal property; the other is the actual
scalar-plus-linear-polynomial expression. The generator relations, both
inverse laws, and the algebra homomorphism laws are all checked. This
normal-form result needs neither Kock--Lawvere nor classical logic.

### Unique affine coordinates from the paper's algebraic axiom

Given the existing full Kock--Lawvere evaluation axiom on actual Weil
algebras, `FirstOrderKockLawvere.Dimension.affine-equivalence` proves that
every map from D(n) to R has unique expression

d |-> r + sum_i (v_i * d_i).

The forward map is exactly this expression. The equivalence is derived
from the constructed algebra normal form, the proved spectrum calculation,
and the algebraic evaluation axiom. No separate affine-coordinate axiom
is introduced. Its origin computation identifies pointed maps with the
linear expressions, with a proved coefficient reconstruction law.

### Full faithfulness

`FirstOrderFullFaithfulness.Ring.pointed-map-equivalence` applies unique
linear coordinates componentwise. It proves that the actual disk-functor
map from matrices n -> m to pointed maps D(n) -> D(m) is an equivalence.

`InfinitesimalVarieties` is the full subcategory of pointed sets with an
actual mere pointed equivalence to a Weil spectrum. The required witnesses
for each disk are supplied by the actual finite square-zero Weil algebra.
The entrypoints `infinitesimal-functor` and
`infinitesimal-fully-faithful` therefore provide the fully faithful functor
claimed in Lemma 4.2.14, without assuming that these disks are infinitesimal
varieties or assuming full faithfulness as an input.

The result works in one arbitrary universe over an ordinary commutative
ring with the explicit algebraic Kock--Lawvere input. It does not require
set-level replacement of a higher target: this lemma's target category is
the actual pointed-set category because the infinitesimal varieties are
sets. Higher tangent targets are handled by the separate pointed mapping
construction. The finite-free source is its coordinate skeleton; no claim
that all modules have a chosen basis is made.

<a id="crisp-weil-tangents"></a>

## Generalized tangents for actual crystalline-etale maps

`CrispWeilTangents` specializes the checked modal lifting theorem to
the actual crystalline modality and every actual native-crisp pointed
infinitesimal variety. It also exposes the actual Weil-spectrum case.

For every ordinary crystalline-etale map `f : X → Y` and every ordinary
point `x : X`, the literal based precomposition map

```
derivative f x : Tangent X x → Tangent Y (f x)
```

is an equivalence. The tangent consists of actual maps from the chosen
pointed variety together with their actual base-point equality. Neither
the map nor the point is required to be crisp.

This closes the previously separate crystalline specialization of
Proposition 4.3.5. The test variety's crystalline connectedness is
derived in `CrispWeil`, using its polynomial zero-locus presentation.
The explicit ambient inputs are a native-crisp coefficient ring and
Kock-field axiom, the existing uniform flat/truncation distribution
rule, and literal crisp pullback preservation for crystalline
reflection. No connectedness conclusion or tangent equivalence is
supplied as an additional premise.

<a id="tangent-delooping"></a>

### Actual tangent fibers and loop maps

For a pointed test type (T,t0), the tangent type is the existing
`Quotients.PointedTest.Tangent` definition:

Tangent X x = sum (v : T -> X). v(t0) = x.

Its zero point is (constant x, refl). `TangentDelooping.PointedTest.At`
constructs an explicit pointed equivalence

Loops(Tangent X x, zero) ~= Tangent (x = x) refl.

The forward map evaluates a path of tangent vectors pointwise and
transposes the equality-coordinate square. The inverse transposes
these same coordinates back. Both inverse laws and preservation of
the specified zero point are definitional equalities. The square
comparing looped evaluation with evaluation on pointwise loops also
commutes definitionally. All higher paths are retained.

`ConnectedFibers` proves that the actual fiber of f:A->B over f(a0)
is connected if A is connected from a0 and the based loop map of f
is surjective. It uses the connected pullback theorem and an explicit
pullback/fiber equivalence; connectedness of the fiber is derived.

For a crisp higher group G and a crisp pointed tiny T,
`TangentDelooping.Context.HigherGroup.tangent-delooping` makes the
actual tangent fiber of BG at its point into a `Quotients.Delooping`.
Its connectedness comes from the already checked tiny-power
connectedness theorem and the constant-function section of looped
evaluation. Its loops are pointed-equivalent to the actual tangent
fiber of Loop G at refl. This proves the higher-group/delooping
assertion of Corollary 5.5.5. Infinitesimal linearity is not needed for
this homotopical part; it is needed for the separate R-module claim.

### First-order specialization and tininess

`TinyEquivalences` proves invariance of mere Tiny under a native-crisp
equivalence S ~= T. It transforms the actual external adjoint: the
root is unchanged, and evaluation precomposes by the inverse test
equivalence. The actual adjunction comparison is the composite of
the original comparison and a proved precomposition equivalence.
Only crisp identity induction at the working universe is required.

Its public API is:

TinyEquivalences.Context.respects-equivalence rules e
      : Tiny T -> Tiny S

where e:S~=T is native crisp. No globally chosen adjoint, R-flatness,
or additional choice principle is needed for this invariance lemma.

`FirstOrderTangentDelooping.Coordinate` proves the actual pointed
equivalence between the one-coordinate disk D(1) of
`FirstOrderInfinitesimalLinearity` and the literal square-zero type
`SyntheticDifferential.FirstOrder.D`. Evaluation at the only finite
coordinate is the forward map; a constant one-coordinate vector is
the inverse. Both specified origins are preserved.

Consequently the explicit `TinyDisks` hypothesis used for Theorem
5.5.3 supplies tininess of the exact test type already used by the
project's first-order tangent API. The final specialization constructs
the delooping of the actual higher Lie algebra T_refl(Loop G), with
delooping exactly T_point(BG), and exposes both an equivalence and a
pointed equivalence of the canonical loop types.

The ambient structural and R-flat assumptions are those of
`TinyDeloopings`. The accepted `SquareZeroWeil` and
`TinyFirstOrderDisks` modules now discharge `TinyDisks` from global W
on the project's actual crisp Weil spectra. The latter exports
`Consequences.tangent-delooping` and `Consequences.lie-algebra-loops`
directly from `WeilTinyness`, with no separate disk-tininess or tangent
delooping premise. Details of the actual square-zero algebra
presentation are tracked in `differential-geometry.md#delooping-linearity`.

### Higher module structure supplied by later modules

The four modules covered by this note prove the higher-group and
delooping portion of Corollary 5.5.5. The accepted later modules
`TangentProducts`, `FirstOrderMatrixCoproducts`, and
`HigherTangentModules` now supply Theorem 4.2.19 in the concrete
product-preserving pointed-representable model formulation, without
truncating X or its tangent fibers. `HigherLieAlgebra` assembles that
module presentation on the actual tangent delooping from global W
and Theorem 5.5.3. `differential-geometry.md#higher-tangent-modules` specifies this model,
the canonical carrier equivalence, and its precise coherence scope.

<a id="delooping-linearity"></a>

### Accepted scope

Four new modules are accepted by the pinned Agda 2.8.0.2 kit with the
project's canonical flags, exit code 0 and no warnings:

- `ConnectedPullbacks.agda`
- `RightVerticalConnectedPullbacks.agda`
- `DeloopingInfinitesimalLinearity.agda`
- `FirstOrderInfinitesimalLinearity.agda`

### Lemma 5.5.1

For a commuting square A -> B, A -> C, B -> D, C -> D, the canonical
comparison sends a to ((north a, west a), commutes a). It is a map to
the actual homotopy pullback, including its equality coordinate.

`ConnectedPullbacks` first proves that this target pullback is connected
when B and C are connected from the displayed basepoints and the loop
map of the south leg is surjective. The proof eliminates only into
propositional truncations: it moves the two vertices to their
basepoints, then lifts the remaining loop to connect the equality
coordinate. Connectedness is not supplied as a hypothesis on the
pullback. The fundamental theorem of higher groups from `Quotients`
then shows that an equivalence on the actual based loop map makes the
original comparison an equivalence.

The loops of the pullback are explicitly equivalent to the pullback
of the normalized based loop maps. The normalization retains the
square's commuting path at the basepoint, through conjugation. The
two projections of the looped comparison are the actual actions of
north and west on paths, by definitional equality.

`RightVerticalConnectedPullbacks` transposes this construction to give
the literal orientation in Lemma 5.5.1: surjectivity is required for
the right vertical/east loop map. The pullback transposition reverses
the equality coordinate; transposing the original comparison back
agrees definitionally with the original comparison. The final result
therefore concerns that comparison, rather than an unspecified
equivalence between the corner and some pullback type.

All four corner types use one arbitrary universe. The source and the
two off-diagonal corners are connected; connectedness of D is not
needed by this proof. Basepoints are normalized to images of the
source basepoint, and the given commuting path provides their
comparison in D. No strict commutation or truncation of paths is
assumed. This part is pure HoTT and uses no cohesive or differential
axiom.

### Theorem 5.5.3: the homotopical argument

`DeloopingInfinitesimalLinearity.PointedAxes` records pointed test types
U and V, a third test W, inclusions U -> W and V -> W, and the actual
path identifying the two included origins. For any X, its canonical
comparison is

(W -> X) -> Pullback(evaluate-origin : (U -> X) -> X,
                        evaluate-origin : (V -> X) -> X).

The equality coordinate is action of the given W-valued origin path
under the function W -> X. `Mapping.IsLinear X` states that this exact
comparison is an equivalence.

For a native-crisp higher group G and native-crisp U, V, W, the theorem
derives `IsLinear (BG G)` from `IsLinear (Loop G)` when all three test
types are merely tiny. `TinyDeloopings` supplies connectedness of all
three mapping spaces. Evaluation on based loops is surjective because
each loop has its constant-function lift. The canonical looped
comparison is identified with the comparison for `Loop G` by
transposing path/function coordinates. Its map coherence is
definitionally reflexive, including the equality coordinate of the
pullback. The connected-pullback theorem then gives the result.

The ambient assumptions are exactly those used by `TinyTruncation`:
crisp identity induction at the working universe, small-universe
identity and Flat induction/computation, a pointed crisp generator R,
and R-flatness. Tiny witnesses are propositional truncations of the
external adjunction data; no adjoint is selected globally.

### Definitions 4.2.13 and 4.2.16: actual first-order disks

`FirstOrderInfinitesimalLinearity.Ring` defines, for an actual
commutative ring R,

D(n) = sum (x : Fin n -> R). forall i j, x(i) * x(j) = 0.

It constructs D(n) -> D(n+m) by putting the vector in the left block
and zero in the right block, and constructs D(m) -> D(n+m) in the
opposite way. The four coordinate formulas are proved. Pairwise
square-zero equations are preserved, and both origins map to the
zero vector. This supplies the actual `PointedAxes` diagram.

`InfinitesimallyLinear X` quantifies the resulting canonical
pullback-comparison equivalences over all ordinary natural n and m,
as in Definition 4.2.16. The final theorem proves this property for
BG from the property for Loop G. It extends crisp n,m instances to
ordinary n,m using the previously derived discreteness of Nat, not
a new crisp natural-number elimination rule.

The explicit hypothesis

TinyDisks = (@crisp n : Nat) -> Tiny D(n)

is the restriction of Postulate W needed by the local theorem. The
separate, now accepted `SquareZeroWeil` module constructs the actual
finitely presented augmented quotient R[X1,...,Xn]/(Xi*Xj), proves
finite generation and square nilpotence of its augmentation kernel,
and identifies its pointed spectrum with D(n). `TinyEquivalences`
transfers mere tininess along this actual crisp equivalence.

The accepted `TinyFirstOrderDisks` module consequently derives
`TinyDisks` from the single hypothesis

WeilTinyness = (@crisp V : WeilAlgebra) -> Tiny (Spec V).

Its `Consequences.preserves-infinitesimal-linearity` exports Theorem
5.5.3 directly from global W on actual crisp Weil spectra. No
separate disk tininess, connectedness, pullback preservation, or
delooping-preservation premise remains in this wrapper. The local
restricted API and its earlier source comment are retained unchanged;
the source comment's proposed presentation bridge is now supplied by
these later modules.

This result is infinitesimal linearity, not the full microlinearity
statement that the paper itself does not infer in Remark 5.5.4.

<a id="higher-tangent-modules"></a>

### Accepted mathematical presentation

`HigherTangentModules` proves the product-preserving pointed
representable model required by Theorem 4.2.19, for arbitrary higher
targets. The result uses the actual category of finite free coordinate
R-modules, the actual disk functor into pointed sets, and literal
pointed precomposition. Its value in dimension one is pointed-
equivalent to the literal square-zero tangent type already used in
`SyntheticDifferential` and `Quotients`.

This is a concrete presentation of a coherent higher R-module by a
restricted representable mapping construction. It does not define an
arbitrary infinity-category or assert that a finite wild-category
record alone encodes all infinity coherence. The test functor and
representing pointed type are the actual data; operations and their
action on paths and indexed families are inherited from pointed
precomposition. The code exposes a `WildFunctor` only as a convenient
view of the already specified construction.

The following modules are proved:

- `TangentProducts.agda`
- `FirstOrderMatrixCoproducts.agda`
- `HigherTangentModules.agda`
- `HigherLieAlgebra.agda`

### Genuine finite free module diagrams

`FirstOrderLinearMaps` constructs the matrix category with objects
natural numbers and arrows n -> m given by m-by-n matrices over R.
It proves that these arrows are equivalent to actual `LeftModuleHom`
maps between the corresponding free coordinate modules. Matrix
evaluation preserves zero and pairwise-square-zero equations, so it
defines an actual functor from this category to pointed sets whose
value at n is (D(n),0).

`FirstOrderMatrixCoproducts` supplies the genuine categorical finite
coproduct diagrams. The binary coproduct of n and m is n+m, with
Kronecker-delta block inclusion matrices. Composition with these
matrices is proved equal to restriction to the two column blocks.
The block-entry equivalence proves the actual Cubical
`BinCoproduct.univProp`, including unique matrix fillers. Zero is an
initial object. These are universal properties of actual module
maps, not named diagrams assumed to have the required property.

The images of both inclusion matrices under the disk functor agree
with the exact zero-padding axis maps of Definition 4.2.16. Equality
of their pointing paths is included. Thus the categorical product
comparison of the representable model is identified with the
geometric comparison supplied by infinitesimal linearity.

### Based product comparisons retain higher paths

For arbitrary X and x:X, define

Based(n) = sum (v : D(n) -> X). v(0) = x.

`TangentProducts` proves that Based(0) is contractible, with the actual
constant tangent as center, and that the canonical map

Based(n+m) -> Based(n) x Based(m)

is an equivalence when X is infinitesimally linear. Each restriction
has the actual pointing path

action(v, axis-origin) followed by the original tangent path.

The proof first lifts the actual unbased pullback comparison through
its pointing family. It then identifies the resulting based cocone
with the product of the two tangent fibers. A checked path-algebra
identity shows that the second pointing path is exactly the literal
restriction path. No sethood, proposition truncation, or discarded
equality coordinate is used for X or these tangent fibers.

### The represented model and its carrier

For the actual disk functor D and pointed target (X,x), the model is

n |-> Map_*(D(n), (X,x)),

contravariant on finite free module maps. `RestrictedRepresentable`
defines its operations by actual pointed composition. The identity
and composition laws are inherited from the genuine disk functor and
the ordinary pointed mapping construction. Operations are functions
on actual hom types, so their action on paths and indexed families
is part of that construction rather than independently chosen data.

`Model.PreservesFiniteProducts` records only terminal and binary
product preservation for this fixed represented model. It does not
purport to encode the model's coherence by a finite list of algebraic
axioms. `tangent-module X x linear` supplies these preservation
certificates from the actual infinitesimal-linearity hypothesis.

The pointed D(1)-to-square-zero equivalence identifies the model's
dimension-one carrier with the actual tangent fiber. The exported
`rank-one-pointed` also preserves its specified zero vector. The
construction works in one arbitrary universe and imposes no
truncation condition on X. For this implication, neither Kock--Lawvere
nor tininess is an additional hypothesis once infinitesimal linearity
of X is supplied.

The later accepted `FirstOrderRealPushouts` and
`FirstOrderWeilPushouts` modules derive the actual axis R-pushout
property from global Kock--Lawvere and prove the implication from
the project's native-crisp Weil-diagram microlinearity to this exact
infinitesimal-linearity property. Thus the construction applies
directly to all existing microlinear examples, without a separate
axis-preservation hypothesis. See `differential-geometry.md#first-order-real-pushouts`.

### Corollary 5.5.5 assembly

`HigherLieAlgebra` combines these results with the global-W versions
of Theorem 5.5.3 and the tangent delooping theorem. For a crisp higher
group G with infinitesimally linear Loop G, it supplies:

- the actual tangent fiber T_point(BG) as a pointed connected delooping;
- a pointed equivalence from its loops to the actual higher Lie algebra
  T_refl(Loop G);
- the product-preserving represented R-module presentation on its
  carrier, with a pointed identification of that carrier with the
  actual tangent delooping.

The assumptions are the already explicit cohesive structural rules,
R-flatness, and Postulate W quantified over the project's actual
crisp Weil spectra. The disk tininess needed by the proof is derived
through actual square-zero Weil presentations. No tangent-module,
connectedness, or delooping-preservation conclusion is assumed.

This completes the module claim of Corollary 5.5.5 in the concrete
represented-model formulation just described. It does not supply a
general theory or classification of all infinity-categorical
R-modules, and the paper's informal phrase “higher Lie algebra” does
not add a Lie-bracket construction to the proved claim.

<a id="global-kock-lawvere-calculus"></a>

## First-order calculus from the global Weil axiom

`GlobalKockLawvereCalculus.Ring` takes the actual global Weil-algebra
Kock-Lawvere evaluation axiom over an ordinary commutative ring. It
derives the exact first-order equivalence used by `SyntheticDifferential`:

\[
 R\times R\simeq (D\to R),\qquad
 (a,b)\longmapsto(\varepsilon\longmapsto a+b\varepsilon),
 \quad D=\{\varepsilon\mid\varepsilon^2=0\}.
\]

The proof uses the constructed square-zero Weil algebra in dimension
one and the proved affine-coordinate theorem in `FirstOrderKockLawvere`.
It constructs the actual coefficient equivalence and the actual
equivalence between the one-coordinate disk and the literal nilsquare
subtype. The resulting equivalence is proved to have exactly the affine
map displayed above as its forward function.

It then exports the existing checked calculus at this derived
first-order axiom: every function `R → R` has a unique derivative
function satisfying its infinitesimal expansion, and the constant,
identity, sum, product and chain rules hold. Thus the earlier remaining
bridge from global Postulate J to the exact first-order hypothesis of
Lemma 4.1.7 is now checked. No field, order, excluded middle, crispness,
or additional first-order evaluation hypothesis is required by this
bridge.

This is a theorem relative to the global synthetic evaluation axiom;
it does not construct a classical real field satisfying that axiom.
<a id="infinitesimal-inverse-function"></a>

## Infinitesimal inverse function theorem and Theorem 5.2.12

The source is [Myers, *Orbifolds as microlinear types*, Theorem 5.2.12](https://arxiv.org/abs/2205.15887).
All seven new modules were accepted by the pinned Agda 2.8.0.2 kit
with exit code 0 and no warnings.

This development keeps the paper’s additional infinitesimal inverse-function assumption as an explicit input and derives its geometric consequence in `PenonInverseFunctionTheorem.agda`.

### Exact assumption and conclusion

Fix a commutative ring R in the working universe, the project's
`SyntheticField.KockField` axiom, and the global Kock--Lawvere condition
on actual Weil algebras. The two disk types remain distinct:

* The full Penon line is the actual double-negation neighborhood
  `𝔇 = Σ r : R, ¬¬(r = 0)`, and `𝔇ⁿ = Fin n -> 𝔇`.
* The first-order disk is
  `D(n) = Σ d : (Fin n -> R), ∀ i j, d i * d j = 0`.
  Its origin is the actual zero vector.

`InfinitesimalInverseFunction.Ring.InfinitesimalInverseFunctionTheorem`
is exactly the following type of hypotheses:

(n : Nat) (f : (𝔇ⁿ,0) ->* (𝔇ⁿ,0))
      -> isEquiv (restriction f)
      -> isEquiv (underlying f).

The restriction in this signature is a constructed, unique map
`D(n) -> D(n)`. Its commuting square with the actual inclusion into
`𝔇ⁿ` is proved. The assumption contains no etaleness predicate or
manifold-level conclusion. No inhabitant of this assumption is
installed in the context.

For ordinary Penon manifolds X and Y of dimensions n and m, and an
ordinary map f : X -> Y, the final theorem proves

crystalline-etale f  <->  isEquiv (tangent-bundle comparison f).

The right-hand comparison is the literal homotopy-pullback comparison
for the naturality square of the tangent bundle projection. Tangents
use the actual square-zero test type from `SyntheticDifferential`.
The result permits different n and m. Neither the manifolds nor their
local-model witnesses nor f need to be crisp in this construction.
The paper's crisp case is therefore an immediate specialization.

### First-order restriction and canonical coordinates

`PenonFirstOrder.agda` constructs the inclusion D(n) -> 𝔇ⁿ from
Kock's field axiom: every square-zero element double-negation
neighbors zero. For any rectangular matrix, the actual finite linear
combination extends to a pointed map on full Penon disks. Neighbor
preservation and finite double-negation conjunction prove that these
linear combinations still belong to the full disk.

For every pointed map D(n) -> 𝔇ᵐ, global Kock--Lawvere gives unique
linear coordinate formulas. Their coefficient matrix defines a map
D(n) -> D(m), since linear combinations of a pairwise-square-zero
vector remain pairwise square-zero. The reconstructed map agrees with
the original coordinate functions. This yields a literal equivalence
between matrices and pointed maps from D(n) into 𝔇ᵐ.

Applying this to a pointed map 𝔇ⁿ -> 𝔇ᵐ after the inclusion gives
its first-order restriction. The module proves the inclusion square,
uniqueness of this restriction, and preservation of identity and
composition. These are equalities of the actual pointed maps,
including their pointing paths.

`PenonTangentCoordinates.agda` specializes the small domain to D(1)
and transports along the already checked pointed equivalence with
the literal square-zero type D. It gives an actual equivalence

Rⁿ  ~=  ((D,0) ->* (𝔇ⁿ,0)).

Under these coordinates, postcomposition by a pointed full-disk map
is exactly the action of its first-order restriction matrix. Thus an
equivalence of the actual tangent maps makes that matrix action an
equivalence of the underlying coordinate types.

### Different dimensions without a rank axiom

`FirstOrderMatrixInverses.agda` proves constructively that the inverse
function of an invertible linear coordinate map is itself linear.
Each module law follows by applying the original injective linear
map and its inverse equations. Expanding the inverse on the standard
basis gives a rectangular inverse matrix. Its two inverse equations
also hold on the actual first-order disks.

Suppose F : 𝔇ⁿ -> 𝔇ᵐ has invertible tangent map at the origin. Let B
be the inverse matrix just constructed and let G : 𝔇ᵐ -> 𝔇ⁿ be its
full linear extension. The actual restrictions of G composed with F
and F composed with G are equivalences, by the checked restriction
composition law and the two matrix inverse equations. The additional
axiom applies to these two genuine self-maps, one in dimension n and
one in dimension m. Both composites are consequently equivalences.
An explicit inverse construction then proves F itself is an
equivalence.

This argument never asserts n = m and never assumes an invariant
basis number theorem. It uses precisely the self-map hypothesis that
the paper states.

### Penon neighborhoods and merely given charts

`PenonTangentNeighborhoods.agda` proves a natural equivalence between
the tangent fiber at x and pointed D-curves in its actual Penon
neighborhood. Every such curve lies there because D double-negation
neighbors its origin and every function preserves neighboring. The
forward map retains the original curve and supplies the derived
neighbor proof; the inverse forgets that proof.

For f : X -> Y, this equivalence intertwines its literal derivative
with postcomposition by the literal neighborhood map. For the sets
underlying Penon manifolds, the required proof coordinates are
propositions, and the actual commuting paths are retained.

The final wrapper uses the merely given pointed local models of
these neighborhoods. After conjugating the neighborhood map by a
pair of local models, the preceding full-disk theorem applies.
Equivalence of the neighborhood map is a proposition, so both
propositional truncations are eliminated only into that proposition.
There is no choice of an atlas or of charts varying with x.

The already checked `CrystallinePenonEtale` theorem identifies
pointwise equivalence of these actual neighborhood maps with
crystalline etaleness. The forward implication also follows from
this identification and the tangent-neighborhood equivalence; it
does not require the inverse function assumption.

### Literal tangent-bundle pullback square

`TangentBundlePullback.agda` is a general homotopy-theoretic helper
for any pointed test type, with no sethood requirement on X or Y.
It defines

tangent-map (x,v) = (f x, derivative f x v)

and the actual comparison

(x,v) |-> ((tangent-map (x,v), x), refl)

into the homotopy pullback of the projection TY -> Y along f.
That pullback is equivalent to `Σ x : X, Tangent Y (f x)` by the
standard fiber equivalence for a dependent-sum projection. Under
this equivalence, the comparison is definitionally the total map of
the family of derivatives. The fiberwise-equivalence theorem then
proves both implications between the pullback condition and
pointwise equivalence of the actual derivatives.

### Scope

The conclusion is conditional on the literal additional infinitesimal
inverse function assumption, as in Theorem 5.2.12. The development
does not prove that assumption from Kock--Lawvere, assert a classical
analytic model of the synthetic axioms, or replace it by the desired
etaleness conclusion. It uses no W/tinyness hypothesis, R-flatness,
upper-universe cohesion rule, equal-dimension premise, or chart
choice. Every new source module uses the canonical safe cubical
compiler flags.

<a id="full-infinitesimal-microlinearity"></a>

## All pointed infinitesimal-variety tests

`InfinitesimalVarietyDiagrams` and `FullInfinitesimalMicrolinearity`
close the distinction between the project's spectrum tests and the
paper's literal quantification over all crisp pointed infinitesimal
varieties in Definitions 4.2.11–4.2.12 and Lemma 4.3.10.

### Exact diagram type

A frame consists of four actual pointed types. A square consists of
four actual pointed maps and its actual commutativity path. Each
vertex has a mere pointed equivalence to the spectrum of an actual
Weil algebra, exactly as in the existing `InfinitesimalVariety`
definition. An infinitesimal real-pushout additionally carries the
actual real-valued pushout comparison equivalence. The crisp test
family is `Flat` of this entire type of squares.

The definition does not require selected spectrum presentations,
replace commutativity by a mere proposition, or discard higher
coherence from the mapping-type pushout condition.

### Normalization and the comparison theorem

For four given pointed spectrum presentations, the normalizer uses
pointed univalence to obtain a path between frames. It transports the
whole pointed diagram along that path. The resulting square is
literally a spectrum square. A proved path between the original and
normalized test squares transports the real-pushout witness and every
target-valued pushout witness. Thus the required invariance is proved
from actual transport, rather than assumed as a diagram-conversion law.

For a crisp original square, four applications of the uniform crisp
truncation rule produce the needed crisp presentations only inside the
proof of the proposition that its target-valued comparison is an
equivalence. This yields

```
spectrum-test-equivalence X : SpectrumMicrolinear X ≃ FullMicrolinear X
```

for an arbitrary ordinary target type, including higher types and an
independent target universe. The reverse direction simply regards each
actual spectrum as an infinitesimal variety.

The additional ambient input is explicitly
`FlatTruncationDistribution` at `suc ell`, the universe containing the
mere Weil-spectrum presentations. No global choice, universe resizing,
ordinary excluded middle, or new postulated inhabitant is introduced.
The comparison does not require Kock-Lawvere, field or order axioms,
R-flat, or an additional crisp identity induction rule.

### Codiagonals and orbifolds

The `characterization` theorem proves the literal all-varieties version
of Lemma 4.3.10: full microlinearity is equivalent to locality for every
actual codiagonal of the crisp infinitesimal real-pushout squares. This
characterization itself does not need the presentation-comparison
axiom; it follows from the actual homotopy-pushout universal property.

The comparison also gives an equivalence between the spectrum-based
and full orbifold structures. Their properly finite identity-type
fields are retained unchanged; only the microlinearity field is
transported through the proved equivalence.

The `FullProperEtaleOrbifolds.agda` wrapper applies the checked geometric main
theorem to its actual hypotheses and then the proved definition
equivalence. Its conclusion is an orbifold structure on the actual
Rezk completion using every crisp pointed infinitesimal-variety test.
It adds only the displayed upper-universe crisp truncation rule to the
existing main-theorem signature; it does not take an orbifold conclusion
as an extra hypothesis.

The wrapper invokes qualified declarations directly. An earlier version
that copied the full nested proof namespaces was stopped without
acceptance after 176 seconds. The qualified version checked successfully
under a 150-second bound with the same mathematical signature.

<a id="universal-cover-microlinear"></a>

## Microlinearity from the actual universal cover

`ShapeOne.agda` and `UniversalCoverMicrolinear.agda` have passed the
canonical safe native-kit check with cohesion enabled, exit status zero
and no warnings.

The construction follows the definition used in
[Corollary 5.4.2](https://arxiv.org/html/2205.15887v1#S5.SS4): the universal
cover of a pointed type is the fiber of its fundamental-groupoid unit
`X → shape₁ X` over the image of the chosen point. The connectedness
premise is mere connectedness of `shape₁ X`, as in the paper. Connectedness
of `X` itself or of the full, untruncated shape is not substituted for it.

### The fundamental-groupoid modality

`ShapeOne.Ring` constructs an actual nullification modality with two
generators: the carrier of the ring and a lifted homotopy 2-sphere.
The existing checked `SphereNullification.At 2` identifies nullity for
that sphere with `isGroupoid`. The module proves that its modal objects
are exactly the shape-modal groupoids, matching the specified class of
discrete groupoids in the paper's modal covering theory.

The paper's introductory prose in Section 3.2 mentions localization at
`R` and `S¹` while specifying discrete groupoids as the modal objects.
This development follows that specified class: for the nullification
convention used here, `S²`-nullity is groupoid truncation, whereas
`S¹`-nullity is set truncation. The sphere indexing is therefore explicit;
the two nullifications are not silently identified.

Both the reflector and its unit are the actual higher inductive
nullification construction. `modal-characterization` is an equivalence
between its modality predicate and the pair of shape modality and
groupoid truncation. `discrete-groupoid-universal` is the actual
restriction equivalence on mapping spaces, with a pointwise unit law.
The module also proves that the unit is merely surjective and that
discrete sets and propositions are modal. These facts are derived from
the generators; they are not extra fields of an assumed reflector.

All ring and target types lie in one fixed `Type ℓ`. The sphere is lifted
into that universe. No resizing, upper-universe assumption, preservation
of truncation by shape, or desired fundamental-groupoid conclusion is
assumed.

### The actual cover and monodromy action

For an ordinary `X : Type ℓ` and `x₀ : X`, the module defines

`UniversalCover = fiber η₁ (η₁ x₀)`

and `cover = fst`. Its chosen point is `(x₀ , refl)`. Given ordinary
mere connectedness of `shape₁ X` based at `η₁ x₀`, it defines an actual
`Quotients.Delooping` with that base, and the monodromy family is the
literal family `fiber η₁`.

The homotopy quotient is therefore the existing dependent-sum quotient
`Σ (shape₁ X) (fiber η₁)`. The checked fiber-total-space equivalence gives
`quotient≃base` from this actual quotient to `X`. The exported triangle
says its composite with the actual action quotient map is the actual
cover projection. Another triangle identifies its composite with the
fundamental-groupoid unit with the quotient's first projection.

The delooping has set-valued loop spaces by the proved groupoid property.
`fundamental-group≃loops` identifies the paper's set truncation of the
loop type with those actual loops. The module also proves that the cover
is shape₁-etale and has set fibers, retaining the paper's covering-map
criterion.

### Microlinear descent

`Geometry.Based.universal-cover-microlinear→base-microlinear` proves the
conclusion of 5.4.2 for the actual cover. Its exact geometric inputs are:

- A native-crisp commutative ring and native-crisp Kock-field witness.
- `FlatTruncationDistribution` at the working universe.
- The literal `CrispPullbackPreservation` axiom for the crystalline
  modality.
- Ordinary pointed `X`, ordinary connectedness of `shape₁ X`, and
  microlinearity of the literal universal-cover fiber.

The actual fundamental-groupoid base is shape-modal, hence crystalline.
The previously checked generic quotient-microlinearity theorem therefore
applies to its monodromy action and descends microlinearity from the
cover to the quotient. Equivalence invariance then transfers the result
to `X`. The infinitesimal test family is the existing family of crisp
Weil-spectrum real-pushout squares; its connectedness is supplied by the
checked `CrispWeil` proof.

This argument proves the result also for an ordinary `X` and ordinary
point. It needs no additional `RealFlat`, crisp excluded middle,
tinyness, crispness of the connectedness witness, or context-reset rule:
the reflected base is already modal by its construction, so the generic
quotient theorem is sufficient.

