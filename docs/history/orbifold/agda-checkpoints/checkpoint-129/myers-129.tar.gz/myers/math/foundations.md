# Foundations

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="foundations-review"></a>

## Foundation and dependency assessment

Date: 2026-11-04. This is an implementation assessment, not a claim that the
paper's differential-cohesive foundation has already been constructed.

### Recommended library

Sources:

- https://github.com/agda/cubical/tree/v0.9
- https://github.com/agda/cubical/blob/v0.9/README.md
- https://api.github.com/repos/agda/cubical/tags?per_page=8
- https://github.com/agda/agda/releases/tag/v2.8.0.2

The library manifest supplies these flags:

```text
--safe --cubical --no-import-sorts -WnoUnsupportedIndexedMatch --guardedness
```

The original kit's `--no-libraries` mode does not consult this manifest.
Testing revealed that passing all of these flags globally also misconfigures
Agda's builtins, which have their own cubical-mode and sort requirements.
The kit now supports an explicit `--library-file` registry, together with
`--no-default-libraries`. The project's registry names only the pinned
Cubical source, and project/library manifests apply flags at the correct
source boundary. Do not pass global `--cubical` or `--no-import-sorts` when
using this route. If warning suppression is used, record it instead of
treating it as evidence that every definition computes as expected.

Validated invocation:

This checked both quotient modules successfully on 2026-11-04 with Agda
2.8.0.2 and the pinned Cubical v0.9 sources.

### Existing mathematical components

The pinned tree was inspected (1,386 entries; GitHub reported no truncation).
Relevant components are:

| Requirement | Existing module or family |
| --- | --- |
| Paths, dependent functions, equivalences and univalence | `Cubical.Foundations.Prelude`, `Equiv`, `Univalence`, `Path`, `Function` |
| Propositional truncation | `Cubical.HITs.PropositionalTruncation` |
| Dependent-pair identity equivalence | `Cubical.Data.Sigma.Properties` (`ΣPathTransport≃PathΣ`) |
| Mere surjectivity and embeddings | `Cubical.Functions.Surjection`, `Embedding` |
| Finite and subfinite sets | `Cubical.Data.FinSet`, `Cubical.Data.SubFinSet` |
| General monadic modality | `Cubical.Modalities.Modality` |
| Lex-modality consequences | `Cubical.Modalities.Lex` |
| Genuine higher inductive localization and nullification | `Cubical.HITs.Localization`, `Cubical.HITs.Nullification` |
| Rings, ideals, quotients and polynomial algebras | `Cubical.Algebra.CommRing` and its submodules |
| Categorical pullbacks | `Cubical.Categories.Limits.Pullback` |

`Cubical.HITs.Nullification.Properties` actually constructs a `NullModality`
and proves its eliminator/universal property. It is a useful alternative to
postulating an unspecified nullification. The library does not identify an
arbitrary nullification with Myers' shape or crystalline modality.

`Cubical.Modalities.Lex` takes a universe-polymorphic modality, induction laws,
and modal universes as parameters. It develops consequences of those
hypotheses; importing it does not establish lexness of a newly named
modality. It must not be used to obscure an unproved geometric assumption.

Exact inspected sources:

- https://github.com/agda/cubical/blob/v0.9/Cubical/Modalities/Modality.agda
- https://github.com/agda/cubical/blob/v0.9/Cubical/Modalities/Lex.agda
- https://github.com/agda/cubical/blob/v0.9/Cubical/HITs/Nullification/Properties.agda
- https://github.com/agda/cubical/blob/v0.9/Cubical/Data/Sigma/Properties.agda
- https://github.com/agda/cubical/blob/v0.9/Cubical/Data/SubFinSet.agda

### Crisp contexts are not the whole cohesive theory

Native `@♭`/`@flat` binders are not a shape or sharp modality. The supplied
foundation review records rejection of `--safe --cubical --flat-split`:
safe mode cannot combine `--without-K` with `--flat-split`. The development
uses native crisp binders, not flat splitting. Crisp axioms, shape/crystalline
laws, tiny-type adjunctions, smooth-real structure and Kock–Lawvere principles
remain explicit premises; a joint model is a separate construction.

Source: https://agda.readthedocs.io/en/v2.8.0/language/flat.html

### Finiteness distinction

The library's `isSubFinSet A` is mere embeddability of `A` in some `Fin n`.
It proves that such a type is a set and has decidable equality. Myers'
**proper finiteness** is instead subfinite enumerability together with
decidable equality: a quotient of a subfinite set with that extra equality
condition. The paper explicitly says it has not proved that every properly
finite set is subfinite. Do not replace proper finiteness by
`isSubFinSet` without stating a stronger hypothesis.

Sources: paper §6.1, especially Definition 6.1.3 and the following remark;
`Cubical.Data.SubFinSet` at the pinned commit.

### Earlier differential-cohesion formalization

Felix Cherubini's `DCHoTT-Agda` is useful proof literature. Its README targets
Agda 2.6.2.2 and explicitly describes an axiomatized coreduction modality.
The inspected `Im.agda` and `Shape.agda` contain postulates; it is not a
drop-in `--safe` Cubical dependency or a construction of the paper's full
model. Its `FormallyEtaleMaps` and `PropertiesOfEtaleMaps` exhibit useful
proofs via pullback pasting, including composition of étale maps and formal
disk-bundle preservation. These arguments can guide independently checked
Cubical proofs, with their foundational assumptions stated explicitly.

Sources:

- https://github.com/felixwellen/DCHoTT-Agda
- https://github.com/felixwellen/DCHoTT-Agda/blob/master/Im.agda
- https://github.com/felixwellen/DCHoTT-Agda/blob/master/FormallyEtaleMaps.agda
- https://github.com/felixwellen/DCHoTT-Agda/blob/master/PropertiesOfEtaleMaps.agda

### Implementation boundary

Pure HoTT facts about family actions, dependent-sum homotopy quotients,
identity types and stabilizers can be proved now without a synthetic-real
axiom. Geometric theorems should sit over explicit structures containing
only the foundation assumptions actually used. A record field equal to a
desired geometric conclusion is an assumption, not its proof. A generic
conditional theorem must be reported as such until the hypotheses have
been instantiated or established in the intended setting.

### Checked foundations now present in this project

The following modules were accepted by the unmodified Agda 2.8.0.2 checker
with the pinned Cubical library and `--safe`. These are derived theorems,
not additional axioms.

- `Orbifolds.Quotients` proves the loop-map form of the fundamental theorem
  for pointed connected types, the homotopy quotient as a dependent sum,
  its identity/stabilizer equivalence and mere surjectivity, and the
  dependent-sum calculation for a classified bundle. Its pointed-test
  tangent construction proves only functoriality and transport action;
  no Kock–Lawvere or tangent-module result is asserted.
- `Orbifolds.QuotientExamples` constructs the trivial action of the
  automorphism group of `Bool` on `Unit`. Its quotient retains a nonidentity
  loop and has isotropy equivalent to `Bool`, demonstrating why a set
  quotient would lose essential information.
- `Orbifolds.ModalConnected` derives the universal property of a general
  modality, proves that a map inverted by reflection induces an equivalence
  of mapping spaces into every modal target, and proves Lemma 4.3.12:
  the pushout of a span of three modal-connected types is modal-connected.
- `Orbifolds.ModalEtale` defines étaleness by the actual homotopy pullback
  of the unit-naturality square. It then proves coherent right
  orthogonality against every map inverted by the modality, matching
  `Orbifolds.Lifting.RightOrthogonal` exactly. The proof proceeds through
  equivalences of function-space fibres and pullback sections, preserving
  all boundary equalities.
- `Orbifolds.MicrolinearModal` derives both lifting conditions used by
  `Orbifolds.Microlinearity` from this genuine étaleness hypothesis whenever
  the four vertices of each specified test square are modal-connected.
  It consequently proves microlinearity ascends along étale maps and
  descends along merely surjective étale maps, with those geometric test
  hypotheses explicit.
- `Orbifolds.TangentEtale` identifies the based mapping-space tangent
  definition with an extension space. For a pointed modal-connected test
  object it proves that the actual tangent pushforward of an étale map is
  an equivalence, the modal argument underlying Proposition 4.3.5.

Neither modality module assumes left exactness. In particular, the
crystalline modality must not be asserted globally lex: the paper's
warning preceding Lemma 4.3.12 rules out that shortcut. The crystalline and shape modalities are now constructed as actual
nullifications at the double-negation zero-neighborhood and at the real
line, respectively. Connected finite infinitesimal powers and polynomial
zero loci are proved under the exact per-diagram preservation comparison.
The crisp-presentation bridge is now proved in CrispWeil using the uniform
FlatTruncationDistribution ambient rule and literal native-crisp pullback
preservation. That structural rule is justified by spatial type theory,
not supplied by native safe Cubical Agda; see foundations.md#crisp-foundation. No
ordinary, internally varying pullback preservation is assumed.

#### Modal geometry and closure proofs

The following constructions retain their displayed hypotheses.

| Module | Checked mathematical content | Explicit boundary |
| --- | --- | --- |
| `ModalEtaleClosure` | A modal family over the reflected base has an étale projection when restricted along the unit; pullbacks of maps between modal types are étale. | Modal fibres over an arbitrary base alone are insufficient. |
| `ModalEtaleOperations` | Étale maps have modal fibres; they are closed under arbitrary pullback and composition. | No global left exactness. |
| `ModalEtaleSums` | Dependent sums of étale component maps over maps of modal index types are étale (Lemma 5.3.3). | Both index types must be modal. |
| `MicrolinearSums` | A dependent sum over a modal index of microlinear types is microlinear (Lemma 5.3.4). | The infinitesimal test vertices are modal-connected. |
| `EtaleAtlas` | Microlinearity descends from the chart models of an étale atlas (Theorem 5.3.5). | Chart hypotheses and connected test squares are explicit; total-map étaleness is derived. |
| `QuotientMicrolinear` | The family-action quotient map is étale when the delooping is modal; quotient microlinearity follows by descent. | The generic theorem takes a modal delooping. ModalDelooping and CrispQuotients now derive it from the appropriate crisp loop-group hypotheses and crisp pullback preservation. |
| `Crystalline` | Actual nullification at the double-negation zero-neighborhood, its connected generator, surjective units, empty preservation, actual shape nullification at the real carrier, and several shape-to-crystalline comparisons. | A commutative ring is supplied. No model of synthetic smooth reals or global crystalline left exactness is claimed. |
| `ModalPullbacks` | Connected products and finite powers; preservation of the explicit reflection comparison for a pullback implies connectedness of that pullback. Its fibre comparison is derived from the pullback-with-a-point comparison. | Preservation is stated for the individual diagram, never for all internally varying diagrams. |
| `CrystallineZeroLoci` | Infinitesimal neighborhood powers are connected; a polynomial zero locus between those powers is connected when its own comparison is preserved. | The geometric/crisp source of that preservation remains separate. |
| `PullbackCancellation` and `ModalEtaleCancellation` | Cartesian-square cancellation and étale right cancellation when the reflected first map is merely surjective (Lemma 5.4.12). | No untruncated preimage choice. |
| `SequentialFlattening` | The total space of an equivalence-glued family over a sequential colimit is equivalent to the colimit of the total spaces. | Constructed by higher-inductive elimination and path coherence. |
| `ModalEtaleSequences` | Every cocone inclusion of a sequence of étale maps is étale (Lemma 5.4.11). | The canonical comparison from the colimit of reflected stages to the reflection of the colimit is required to be an equivalence for this sequence. |
| `ModalEtalePushouts` | Both inclusions of the pushout of an étale span are étale (Lemma 5.4.10), by actual pushout flattening. | The canonical comparison from the pushout of the reflected span to the reflection of its pushout is required to be an equivalence for this span. |
| `ModalEtaleDescent` | A surjective map with étale self-pullback projection is étale (Theorem 5.4.7), using the constructed infinite join resolution. | Surjective modality units and preservation of precisely the positive join pushouts and positive-stage sequential colimit. Shifting the sequence removes the paper's empty-preservation and inhabited-source assumptions. |
| `ExponentiationColimits` | Constructs the literal comparison for exponentiation of pushouts and sequential colimits; if it is an equivalence and all vertices are null, the colimit is null. | This is the comparison infrastructure for A.0.5; it does not assume the resulting modality-preservation statement. |
| `NullificationColimits` | For actual higher-inductive nullification, proves A.0.9 for pushouts and sequential colimits. A strict comparison has an explicit inverse, and its homotopy to the earlier canonical comparison transfers equivalence. | Requires only that exponentiation by each generator preserve the indicated reflected diagram. |
| `CrystallineColimits` | Instantiates A.0.9 at the actual infinitesimal neighborhood 𝔇, yielding the preservation comparisons used by Theorem 5.4.8 and self-pullback descent. | The remaining input is A.0.5's canonical exponentiation comparison, not crystalline preservation itself. |

These last colimit-preservation hypotheses have a different source from
the paper's crisp pullback axiom: they belong to the tiny-type argument in
Appendix A and Theorem 5.4.8. They are not instances of an unrestricted lex
assumption. A proof using such a hypothesis must retain it in its theorem
statement until the relevant crisp tiny-type construction discharges it. That
construction is now checked for the actual crystalline generator:
CrispColimits derives both canonical comparisons from mere Tiny(𝔇),
using TinyPushouts, TinyCoequalizers, TinySequences and
NullificationColimits. CrispGroupoids instantiates the entire Rezk
microlinearity chain. The generic modality theorems retain their explicit
premises; the crystalline specialization no longer assumes them.

<a id="crisp-foundation"></a>

## Crisp foundations and the remaining family boundary

This note separates formal statements, explicit ambient rules, and remaining interpretation obligations. It does not assert a further error in either cited paper.

### Primary references

Michael Shulman, *Brouwer's fixed-point theorem in real-cohesive homotopy
type theory*, [arXiv:1509.07584v3](https://arxiv.org/abs/1509.07584v3),
25 April 2017; published in *Mathematical Structures in Computer Science*
28(6), 856–941, [doi:10.1017/S0960129517000147](https://doi.org/10.1017/S0960129517000147).
The theorem numbers below refer to v3.

The relevant source facts are these:

- Section 3 gives sharp formation/introduction rules that reset ordinary
  context variables to crisp. Theorem 3.3 permits that reset when the
  goal is codiscrete.
- Theorem 5.8 derives crisp truncation induction from sharp. The following
  discussion warns against indiscriminate crisp induction for all higher
  inductive types.
- Definition 8.2 defines discreteness by nullity, including for noncrisp
  types. Lemma 8.10 crisps a discreteness proof when its type is crisp.
- Lemma 8.15 states the equivalence of discreteness and decidable equality
  for sets under crisp excluded middle and C1. Its forward proof makes
  the two points crisp before applying excluded middle.

The Agda [Flat Modality manual](https://agda.readthedocs.io/en/v2.8.0/language/flat.html)
documents `@♭`, restricts the context available when supplying a crisp
argument, and explicitly says `--cohesion` supplies neither sharp nor
shape. Its pattern-matching extension is separate from basic crisp
quantification.

### Accepted native core

`Orbifolds.Crisp` uses actual Agda `@♭` binders. Its `Flat A` constructor
requires a crisp witness of a crisp type. An ordinary inhabitant of
`Flat A` can be pattern-matched to obtain that crisp witness; this is
the accepted elimination rule used throughout the project.

The supplied foundation review records the following compiler-scope probes. This table is not a fresh run or proof-status ledger:

| Attempt | Result |
| --- | --- |
| Apply crisp excluded middle to an ordinary proposition variable | Rejected: `VariableIsOfUnusableCohesion` |
| Directly split a crisp propositional truncation | Rejected: `SplitOnUnusableCohesion` |
| Enable `--flat-split` together with safe Cubical checking | Rejected: `SafeFlagPragma` |

No accepted source enables flat splitting or changes a rejected binder
to an ordinary one to evade these checks.

### A uniform ambient rule closes the presentation-witness step

`Orbifolds.CrispTruncation.FlatTruncationDistribution` is the explicit
parameter

```agda
(@♭ A : Type ℓ) → Flat (∥ A ∥₁) → ∥ Flat A ∥₁
```

Its type mentions no algebra, polynomial, spectrum, or geometric
connectedness conclusion. It expresses a uniform structural interaction
of the crisp context with propositional truncation. The project treats
it as an ambient rule, motivated by the cited crisp truncation theorem;
it does not claim Agda's native primitives construct it.

The checked `crisp-truncation-rec` derives the needed elimination from
this rule using ordinary propositional truncation elimination and the
accepted `Flat` eliminator. Its target proposition may depend on an
ordinary context; only the truncated source witness and constructor
witnesses are required to be crisp.

`Orbifolds.CrispWeil` then combines this structural rule with the literal
crisp pullback-preservation axiom and the proved augmentation-zero,
pointed polynomial presentation. Thus it derives connectedness for every
crisp Weil spectrum and every crisp infinitesimal variety, including
when the finite presentation is merely given. This closes the earlier
gap between a chosen presentation and mere finite presentability.

This is a conditional formalization over a named ambient rule. It is
neither a native implementation of the complete spatial calculus nor a
semantic model of that calculus.

### What `CrispDiscrete` proves

`Orbifolds.CrispDiscrete.Context.Set` requires a native-crisp type `X`
and a native-crisp proof that `X` is a set. Over the explicit R-flat
axiom and crisp excluded middle, it proves

```agda
IsShapeModal X → Discrete X
```

Here `Discrete` is Cubical's decidable equality. The argument first
uses R-flat to invert `Flat X → X`. For arbitrary points of `X`, the
inverse supplies flat witnesses; ordinary elimination of those flat
witnesses gives crisp points. Excluded middle therefore receives a
well-scoped crisp equality proposition. The resulting decision is
transported along the counit's inverse laws.

The point variables of the final result are ordinary. The type variable
`X` is still crisp. These two statements must not be confused.

### Varying hom types are a different obligation

Even for a crisp category `C`, the type `Hom x y` depends on ordinary
object variables `x` and `y` in the main orbifold conclusion. Passing
that type to the crisp binder of `CrispDiscrete` is not well-typed. Nor
does `FlatTruncationDistribution` change this: its source type is crisp
before the rule can be applied.

The accepted `GroupoidEtale.Presentation.Modal.hom-modal` already proves
that these actual hom types are crystalline, using source étaleness,
set objects, and the proved crystalline modality of propositions.
`CrystallineEuclidean` proves shape nullity for arbitrary crystalline
subspaces of real powers, over Kock's field property and the stated
Principle of Constancy. Neither theorem by itself changes the status of
the ordinary variables occurring in `Hom x y`.

Consequently the following uniform statement has **not** been proved
from this project's native crisp core:

```agda
(X : Type ℓ) → isSet X → IsShapeModal X → Discrete X
```

It is the additional family theorem one would need to reproduce that
part of the paper's argument without further geometric data. Adding
precisely this statement as a field named “cohesion” would only rename
the missing theorem. The forward proof in the cited lemma cannot simply
be pasted into native Agda with its crisp-type side condition removed.

### Why a sharp record alone is not a resolution

An ordinary `Modality` record for sharp can express reflection,
elimination and modal closure properties. It does not encode a
judgmental operation which makes the ambient ordinary context crisp
inside a term. A faithful implementation of the full spatial calculus
must retain that context discipline, including its substitution and
computation rules.

Even after such an implementation, using context reset demands a proof
that the actual goal is codiscrete. The goal `Dec (u ≡ v)` in an
ordinary family is not automatically codiscrete merely because it is a
proposition. Declaring all ordinary propositions codiscrete would erase
the distinction responsible for the rejected excluded-middle probe.
Thus “add sharp” is a foundation-development direction, not a completed
derivation of this family theorem.

A semantic warning is useful here: externally discrete fibers do not
automatically furnish a continuously varying equality decision. The
line with doubled origin illustrates this distinction for a family of
topological fibers, but this observation is **not** a verified model
of all the project's axioms or a counterexample to Lemma 6.3.4. That
lemma concerns crystalline subspaces of a fixed crisp ordinary
manifold; its Hausdorff, embedding and differential hypotheses must all
be retained in any countermodel analysis.

### The separated subspace route currently available

There is a checked geometric route with ordinary parameters.
`SubspaceBases.PullbackBasis.discreteFromIsolation` proves decidable
equality from the following independently geometric data:

- a regular ambient topology with a countable basis;
- a set `Y` and a map `f : Y → X`;
- for every `y`, a merely given ambient open neighborhood of `f y`
  whose inverse image contains only `y`.

The proof turns these actual open isolating neighborhoods into
Penon-open singletons and then decides equality. No crisp excluded
middle is used. In particular, source charts on which the groupoid
source map is injective yield isolating neighborhoods of its hom
inclusions; the general compactness proofs can then derive proper
finiteness.

This provides an honest stronger-hypothesis completion route. It does
not establish that modal source étaleness alone supplies such ordinary
locally injective charts. The converse route currently present in
`CompactIsolation` starts with decidable equality, so using it to
discharge the missing equality decision would be circular.

`LocalInjectivity` and `LocallyInjectiveGroupoids` now check this stronger
route explicitly, including actual local homeomorphism charts, ordinary
family-wise equality decisions and the Rezk orbifold conclusion. Their
topological source hypothesis remains separate from modal étaleness.

`CrispNaturals` also gives a small native bridge needed for crisp join
diagrams: ordinary induction constructs `flat-natural : ℕ → Flat ℕ`
with a counit section law. Consequently a theorem at a native-crisp
numeral can be transported to an ordinary natural-number stage index.
This uses no general crisp induction axiom and does not change the
type-family boundary above.

Native crispness and separation alone do not supply the desired family theorem.
The literal conditional main theorem instead derives the required hom-equality
decisions from its stated internal properness hypothesis; see
[Properness](properness.md). Faithful interpretation of all these assumptions
and context side conditions remains a separate obligation.

### Relation to the completed literal main theorem

ProperEtaleManifoldOrbifolds now proves the literal internal Theorem 6.3.7
by applying crisp logic to the crystalline, shape-modal total arrow type,
then restricting its decidable equality through ordinary hom embeddings.
This does not extend the generic shape-modal-to-DecEq rule to ordinary
families. The strong properness input and separate external-comparison
limitation are documented in properness.md#properness-scope.

<a id="crisp-identity"></a>

## Crisp identity induction and Flat paths

`Orbifolds.CrispIdentity` uses the explicit ambient premise described below; its derived results do not erase that premise.

### The ambient structural premise

The source reference is Michael Shulman, *Brouwer's fixed-point theorem
in real-cohesive homotopy type theory*,
[arXiv:1509.07584v3](https://arxiv.org/abs/1509.07584v3), Theorem 5.6.
That theorem supplies crisp identity induction and reflexivity
computation. The project represents the computation law propositionally
and requires a native-crisp witness of the entire rule.

`CrispIdentityInduction` is uniform in all types of its chosen universe.
Its only fields are the eliminator and its reflexivity computation law.
The type, identity-dependent motive, reflexivity branch, endpoints and
input identity are all explicitly native-crisp. It contains no geometric
condition and no claim about Flat preserving identities or equivalences.

The `Theory` module takes `(@♭ rules : CrispIdentityInduction)` as a
parameter. This is essential: terms obtained from the rule can then
occur in subsequent crisp motives. An ordinary witness would not have
the same judgmental availability.

This parameter remains an ambient foundation assumption. Safe Cubical
Agda does not natively split crisp identity arguments, and the accepted
module does not enable `--flat-split` or add a postulate. A full sharp
calculus could derive the structural rule; that calculus has not been
implemented here.

### Derived identity equivalence

The proof follows encode/decode, and works first for arbitrary ordinary
elements `u v : Flat A`:

```agda
Code (box x) (box y) = Flat (x ≡ y)
code≃identity : (u v : Flat A) → Code u v ≃ (u ≡ v)
```

Ordinary path induction defines encoding. Decoding eliminates ordinary
Flat values and applies crisp identity induction to their crisp
witnesses. One inverse law uses ordinary path induction; the other
uses the ambient crisp induction rule. Both account for its
propositional computation law.

The specialization is the proved equivalence

```agda
flat-identity-equivalence :
  (@♭ x y : A) → Flat (x ≡ y) ≃ (box x ≡ box y)
```

Its forward function is the constructed `decode`, not an unspecified
equivalence. `counit-decode` proves compatibility with the ordinary
counit, and `flat-identity-natural` proves its naturality under every
crisp function. These identify the map needed when transporting actual
commutative squares and equalizer conditions.

### Derived functorial consequences

`flat-homotopy` transports a crisp homotopy between crisp functions to a
homotopy between their actual `flat-map` functions. `flat-equivalence`
then transports a crisp equivalence, including its inverse laws:

```agda
flat-equivalence : (@♭ e : A ≃ B) → Flat A ≃ Flat B
flat-preserves-isEquiv : (@♭ f : A → B) →
  (@♭ equivalence : isEquiv f) → isEquiv (flat-map f)
```

The forward map of `flat-equivalence e` is definitionally
`flat-map (equivFun e)`. Preservation is therefore proved for the
canonical comparison used elsewhere in the development.

The present instance handles one universe at a time; it can be supplied
at each required level. It does not assert an unrestricted operation
that takes an ordinary, internally varying type or equivalence and
makes it crisp. In particular, the ordinary hom-family decision issue
documented in `foundations.md#crisp-foundation` is unaffected.

<a id="crisp-limits"></a>

## Crisp limits and external Yoneda

`CrispLimits` separates results available from the native Flat core from those requiring the explicit crisp identity rule.

### Dependent pairs and pullbacks

`Sigma B.flat-sigma-equivalence` identifies `Flat (Σ A B)` with the
dependent sum over `u : Flat A` of the flat family obtained by ordinary
elimination of `u`. The forward map sends `box (a , b)` to
`box a , box b`; the inverse combines the crisp witnesses. The inverse
laws are reflexivity. No additional ambient rule is needed. The module
also proves its naturality under a crisp map of dependent families.

Over a native-crisp `CrispIdentityInduction` witness,
`Theory.PullbackComparison f g` proves the actual comparison

```text
Flat (Σ a : A, Σ b : B, f a = g b)
  ≃ Σ a : Flat A, Σ b : Flat B, flat-map f a = flat-map g b.
```

The path coordinate uses the proved canonical Flat identity map.
The coordinate formula and both projection compatibilities are exposed.
`FunctionalCocone f g Y` specializes this construction to the exact
functional cocone of a homotopy pushout. `CoconeNaturality` proves its
postcomposition naturality, including the path coordinate.

### External Yoneda

`ExternalYoneda f.proves-equivalence` proves that a crisp map `f : A → B`
is an equivalence if precomposition by `f` induces equivalences

```text
Flat (B → Y) → Flat (A → Y)
```

for every crisp target `Y`. This theorem uses only native Flat operations.
At `Y = A`, invert the boxed identity to obtain a boxed candidate inverse
and its left inverse law. At `Y = B`, injectivity of the comparison,
applied to the flat postcomposition of that law, supplies the right
inverse law. Applying the ordinary counit extracts both laws.

The external hypothesis itself may be ordinary. This is not a claim
that Flat reflects arbitrary equivalences: the testing premise ranges
over all crisp targets, and the proof uses two particular targets.

### Idempotence has its own structural boundary

`CrispFlat` separately represents crisp Flat constructor induction,
the uniform rule in Shulman,
[arXiv:1509.07584v3](https://arxiv.org/abs/1509.07584v3), Lemma 5.1.
The eliminator and propositional computation law are two native-crisp
parameters. Agda rejected a combined ordinary record constructor because
the dependent computation field needs the eliminator crisply; no field
annotation was silently weakened to overcome that rejection.

From this rule the module proves `duplicate u = box u` for a crisp
`u : Flat A`, then by ordinary outer Flat elimination proves
`duplicate (counit z) = z`. Together with the already-native opposite
inverse law, this yields the actual counit equivalence
`Flat (Flat A) ≃ Flat A` and `flat-is-discrete`.

The native core's comultiplication counit laws do not themselves prove this
idempotence law. Crisp identity induction acts on identities; it does not
supply constructor induction on a crisp Flat value. The structural premise
is therefore explicit.
<a id="crisp-finiteness-scope"></a>

### Actual finite-span theorem

`CrispFiniteness.agda` proves [Proposition 6.1.2 of the paper](https://arxiv.org/html/2205.15887v1#S6.SS1.Thmthm2)
using the existing `SubfiniteSpan` and `SubfinitelyEnumerable` definitions from
`Association.agda`. A span consists of an actual type embedded in a finite
ordinal and an actual merely surjective map from that type onto the target.
Finiteness is the pinned Cubical library's `isFinSet`, namely an exact natural
cardinality and a merely given equivalence with that finite ordinal.

The proof follows the two finite constructions in the paper. Crisp excluded
middle decides the proposition fibers of the embedding into the finite
ordinal. The library's finite dependent-sum theorem therefore proves that the
span domain is finite. Crisp excluded middle also decides the actual kernel
relation of the surjection. The library's finite set-quotient theorem then
produces a finite quotient, and the proved equivalence between this quotient
and the supplied codomain transfers finiteness to the original type.

### Context discipline and exact assumptions

`Context.crisply-subfinite→finite` takes:

* A crisp probe type `R : Type ℓ` and a crisp point of `R`.
* The R-flat equivalence for crisp types in `Type ℓ`.
* Crisp excluded middle for propositions in `Type ℓ`.
* `FlatTruncationDistribution` at universe `ℓ-suc ℓ`.
* A crisp target `X : Type ℓ`, a crisp sethood proof, and a crisp proof of
  `SubfinitelyEnumerable X`.

The upper-universe truncation rule is needed because the span existential
quantifies over a type in `Type ℓ`. It provides merely given crisp span
witnesses; no untruncated global selection occurs.

`Context.crisp-subfinite→finite` accepts ordinary sethood and ordinary
subfinite-enumerability proofs for the same crisp target. This wrapper also
displays an R-flat instance in `Type (ℓ-suc ℓ)`, with the probe lifted into that
universe. The checked `CrispPropositions.promote-proof` derives flat witnesses
for those crisp propositions. This does not promote an arbitrary ordinary
type or an ordinary element of an arbitrary family into the crisp context.

### Reusable supporting theorems

`CrispCountable.agda` derives a crisp elimination principle for any crisp type
with a crisp embedding into the natural numbers. Native ordinary Nat induction
first gives a crisp natural-number representative. The embedding's fiber over
that representative is a crisp proposition, so R-flatness promotes its
ordinary witness. Flat elimination and the embedding's injectivity then
transport a result back to the original element. The motive may depend on
ordinary context. This is a derived, restricted elimination theorem, not a
general context-reset rule. The finite-ordinal instance uses universe lifting
to avoid requiring a separate R-flat axiom at the smallest universe.

`FiniteSurjectiveQuotient.agda` is independent of crispness and the real probe.
For a surjection onto a set it constructs the kernel-pair set quotient and
proves its canonical map to the codomain is an equivalence. If the domain is
finite and this actual kernel relation is decidable, it derives finiteness of
the codomain. Its use of surjectivity stays propositionally truncated.

These results do not assert finiteness for ordinary varying subfinitely
enumerable types. The target type in Proposition 6.1.2 remains judgmentally
crisp. No field asserting a desired finiteness result has been introduced.

### Finite subcovers from crisp refinement-subcompactness

`CrispFiniteCovers.agda` proves the indexed form of
[Proposition 6.2.15](https://arxiv.org/html/2205.15887v1#S6.SS2.Thmthm15).
It defines the actual `OpenEnumerableRefinement` record: a set of indices,
its subfinite enumerability, an open family, coverage, and mere inclusion of
each refinement member in some original cover member. `RefinementSubcompact`
quantifies over open covers and asserts the mere existence of such refinements.
Neither definition includes a finite-subcover consequence.

For a crisp refinement witness, Proposition 6.1.2 makes its index set finite.
The pinned library's proved finite-choice theorem supplies a merely given
selector of original cover members. The proposition that such a selector
exists is crisp, so R-flatness and flat/truncation distribution supply a merely
given crisp selector. Its actual image in the original index set is crisply
subfinitely enumerable. A second application of Proposition 6.1.2 makes that
image finite. The returned `FiniteSubcover` contains this finite type, its
embedding into the original index set, and a proof of coverage.

The theorem requires R-flatness in `Type ℓ`, crisp excluded middle in that
universe, and flat/truncation distribution at both `ℓ` and `ℓ-suc ℓ`.
The topology, original index set and its sethood proof, cover family,
openness/coverage proofs, and refinement-subcompactness witness are
judgmentally crisp. This crisp-witness theorem does not need the additional
upper-universe R-flat instance used by the ordinary-proof wrapper of 6.1.2.

The current topology interface is explicitly universe bounded. Accordingly,
this result covers index sets `I : Type ℓ` and predicates valued in
`hProp ℓ` on a space `K : Type ℓ`. It does not quantify over larger index
universes or use proposition resizing. Openness of the selected original
members is inherited from the supplied open cover.

### Connection to actual Dubuc–Penon compactness

`CrispCompactCovers.agda` connects the two existing constructions. Starting
from an actual `SubspaceBases.CountableBasis` for the topology and a proof that
its opens are Penon open, it constructs a `CountablePenonBasis` whose `Open`
field is judgmentally the topology's `IsOpen`. It converts the existing
`SubfiniteRefinement` into an `OpenEnumerableRefinement`, using the proved
subfinite-set instances rather than assuming finiteness.

The actual `secondCountableRefinement` theorem then derives
`RefinementSubcompact` from Dubuc–Penon compactness, the displayed covering
property, and the existing countable probe. On crisp input data the finite
subcover theorem applies. Its `RegularContext` specialization derives Penon
openness from the topology's regularity. Ordinary manifolds already supply
both regularity and the actual countable basis, so this gives the bounded
topological consequence described in Remark 6.2.16. No additional
basis/topology agreement field is required by the public theorem.

The resulting subcover retains the same small-index restriction and crisp
context restrictions as the preceding theorem. It does not decide equality
in ordinary groupoid hom families or assume an inverse function theorem.

<a id="shape-flat-adjunction"></a>

## External Shape–Flat adjunction: Theorem 3.1.2

`ShapeFlatAdjunction.agda` has passed the canonical safe native-kit check
with native cohesion, exit status zero and no warnings.

For native-crisp types `X` and `Y` in a fixed universe, the checked theorem
has precisely the orientation in
[Theorem 3.1.2](https://arxiv.org/html/2205.15887v1#S3.SS1):

```agda
shape-flat-adjunction : RealFlat → (@♭ X Y : Type ℓ)
  → Flat (X → Flat Y) ≃ Flat (shape X → Y)
```

The generic `Context` works for a native-crisp pointed type `R`. Its shape
is the pinned library's actual higher-inductive nullification at the
constant singleton-indexed family with value `R`. The `Ring` specialization
is judgmentally the already used `Crystalline.Ring.shape`; no equivalence
between separately assumed modalities is required.

### Assumptions and context boundary

The inputs are native-crisp `R`, a native-crisp point of `R`, the existing
crisp identity induction rule, crisp Flat induction and its computation
law, and the R-flat equivalence relating the actual flat counit to
`R`-nullness. The R-flat proof itself may be ordinary. Neither a sharp
modality nor a Shape–Flat adjunction is supplied as a field. No crisp
excluded middle, tinyness, crystalline pullback preservation, or synthetic
ordered-ring axiom is used.

The two endpoint **types** must be native-crisp. Their elements and the
elements of the external mapping types remain ordinary. Where a crisp
equivalence certificate is needed, `CrispPropositions` promotes only an
ordinary proof of the crisp proposition `isEquiv f`, using the stated
R-flat axiom. There is no general context-reset or promotion of arbitrary
ordinary data.

### Canonical construction and coherence

The proof uses a middle mapping type:

```agda
Flat (shape X → Flat Y)
```

Restriction along the actual shape unit gives a map from the middle type
to `Flat (X → Flat Y)`. Flat idempotence and R-flat make `Flat Y`
shape-modal. The actual nullification universal property therefore makes
restriction an equivalence; its image under Flat is proved to remain an
equivalence.

Postcomposition with the actual flat counit gives a map from the middle
type to `Flat (shape X → Y)`. R-flat makes `shape X` crisply discrete.
The separate `Counit.Domain` construction proves the external counit
universal property for every crisp discrete domain. Its inverse sends a
crisp function `f` to `flat-map f` after the inverse of the domain's
counit. The two inverse laws follow from counit naturality, crisp identity
induction, and crisp Flat induction.

The final equivalence composes the inverse restriction equivalence with
this counit equivalence. It has additional checked coherence:

* `Pair.transpose-triangle` states that the transposed function, restricted
  along the actual shape unit, agrees with the original function followed
  by the actual flat counit.
* `Naturality.natural` proves bivariate naturality for crisp maps
  `a : X′ → X` and `b : Y → Y′`. The left mapping space acts through
  `flat-map b` and precomposition by `a`; the right mapping space acts
  through `b` and precomposition by the actual reflected map `shape-map a`.
  The proof uses the shape map's beta law and the counit's naturality.

Thus the file constructs a natural external hom equivalence with its
specified unit/counit behavior, not an unspecified equivalence between
the endpoint types.

<a id="sharp-crystalline"></a>

## Codiscrete types and crystalline reflection

`FlatSharpAdjunction.agda` and `CodiscreteCrystalline.agda` prove Lemma
5.2.8, including the unique factor and its reflection property. Both
passed the canonical safe native Agda 2.8.0.2 check with cohesion
enabled, exit status zero and no warnings.

### Exact ambient structure

Native Agda supplies crisp binders and the project's native `Flat`
construction, but no primitive sharp modality. This result therefore
takes an explicit native-crisp sharp `Modality` and the uniform external
flat/sharp adjunction of spatial type theory. The latter is an
equivalence of the actual external mapping types

Flat(Flat A -> B)  ≃  Flat(A -> sharp B)

for every crisp A and B, with naturality in both arguments along crisp
maps. This is general ambient spatial structure. It does not contain
crystalline modality, an infinitesimal disk, sharp connectedness, or the
desired codiscrete-to-crystalline conclusion as a field.

The other inputs are a native-crisp commutative ring R, the recorded
crisp identity-induction rule, same-universe R-flatness, and crisp
excluded middle. The adjunction, R-flatness, and excluded-middle
witnesses can remain ordinary. No Kock-field, order, analytic covering,
tinyness, resizing, or upper-universe assumption is required here.

An ordinary `Modality` record is not presented as an implementation of
the whole spatial calculus. No context-reset operation is introduced,
and no generic ordinary-family excluded-middle theorem follows from
this development.

### Derived flat/sharp comparison

`FlatSharpAdjunction.Context.Assumptions.Map.sharp-equivalence` proves
that sharp inverts every crisp map whose actual Flat image is an
equivalence. The proof uses the uniform external adjunction and its
domain naturality, the actual sharp unit restriction equivalence, and
the already checked endpoint form of external Yoneda. All comparison
maps are actual precomposition maps; their commuting square is proved
from the sharp functor's unit computation law.

R-flatness promotes only proposition-valued equivalence certificates
for fixed crisp maps. It is not used to declare an arbitrary ordinary
type crisp. Thus the flat-to-sharp inversion theorem is proved from the
ambient adjunction rather than installed as an additional theorem axiom.

### The infinitesimal generator and ordinary targets

The infinitesimal generator is the project's literal
`D = {r : R | not not (r = 0)}`. For a crisp member, crisp excluded
middle makes its coordinate equal to zero. R-flatness promotes that
proposition-valued path, and the proved flat-identity equivalence
produces the actual path in Flat D. Ordinary Flat elimination therefore
proves `Flat D` contractible.

The derived flat/sharp inversion theorem makes the sharp image of
`D -> Unit` an equivalence. Sharp preserves contractible types, so
sharp D is contractible. Its ordinary connectedness universal property
then proves nullity of every codiscrete target for D. Consequently

codiscrete->crystalline : sharp-modal X -> crystalline X

holds for ordinary varying X and ordinary modality witnesses. The
conclusion is nullity, not a decision procedure on ordinary equality.

For every ordinary X, `Factorization.factor` is the actual crystalline
recursor extending the sharp unit. `triangle` proves its unit law, and
`unique-factor` proves contractibility of the full space of such
extensions with their triangle. Finally, `sharp-reflection` proves that
precomposition with this factor is an equivalence into every codiscrete
target. Thus the factor itself has the universal property of sharp
reflection, covering the last assertion of 5.2.8.

<a id="suspension-nullity"></a>

## Suspension nullity and separated reflection

`SuspensionNullity.agda` is proved. For generator R
in universe r and target X in an independently chosen universe l, it
proves that the actual constant map X -> (Susp R -> X) is an
equivalence exactly when each actual path-constant map

(x = y) -> (R -> x = y)

is an equivalence. The proof uses the genuine suspension mapping
universal property and total/fiberwise equivalence; all comparison
maps are the literal constant maps. It supplies both the equivalence
predicates and the library `isNull` predicates, with arbitrary target
universe throughout.

Consequently the actual HIT `Null (const (Susp R)) X` has R-null path
types. It is pointed connected whenever X is pointed connected. The
latter proof uses its dependent eliminator into mere paths; no
connectedness or separatedness of the result is postulated.

This module is pure HoTT. It requires no R-flatness at any universe,
no resizing, and no additional cohesive rule. It supports the later
crisp shape-family descent by allowing a small separated reflection
and a larger modal-type universe to use the same generator.

<a id="modal-factorization-scope"></a>

## Modal-equivalence / etale factorization classes

`ModalFactorizationClasses.agda` has passed the canonical native-kit check in
safe Cubical mode with cohesion enabled. It completes the two maximality
characterizations of the factorization system recalled in
[Section 3.2.3](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm3).

The theorem is generic in an actual pinned-library `Modality ℓ`. It concerns
maps between types in `Type ℓ`. `ModalEquivalence f` is the existing predicate
that the reflected map is an equivalence. `Etale f` is the existing predicate
that the actual comparison to the unit-naturality pullback is an equivalence.

The new module proves equivalences of propositions:

* `ModalEquivalence f` is equivalent to left orthogonality of `f` to every
  `Etale` map between types in the chosen universe.
* `Etale f` is equivalent to right orthogonality of `f` to every
  `ModalEquivalence` between types in that universe.

The orthogonality predicate is exactly `Lifting.RightOrthogonal`: the induced
map of coherent extension spaces is an equivalence for every boundary map.
The proof does not truncate or discard the equality witnessing a square.

For the right-class converse, the assumed lifting property supplies one
inverse of the canonical factorization's left factor. Uniqueness against its
known etale right factor supplies the other inverse law. This proves the
canonical comparison itself is an equivalence, which is the definition of
etaleness.

For the left-class converse, the assumed lifting property similarly constructs
an inverse of the canonical right factor. A reindexing map on whole extension
spaces carries the higher coherence needed to apply the known orthogonality
of the canonical factors. Reflection then inverts both factors and hence the
original map, using the already checked coherence of reflection with
composition.

The preceding files `ModalFactorization.agda` and `ModalEtale.agda` already
construct the factorization of every map and prove orthogonality in the
forward directions. The new class equivalences, together with those results,
give the usual complete factorization-system characterization. No separate
retract-closure statement is assumed, and no left-exactness or crisp
pullback-preservation axiom is needed.

Verification used:

