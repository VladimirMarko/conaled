# Manifolds

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="crystalline-separation"></a>

## A constructive separation argument for crystalline étaleness

This module supplies the open-inclusion and ordinary-point neighborhood
étaleness needed in the paper's §5.2 and §6.3 arguments. The proof uses
an explicit quotient construction, so it needs neither a sharp modality
nor crispness of the subset or its points.

### The separating quotient

For any type `X`, define the relation

```text
x ~ y  :=  ¬¬ (x = y).
```

This is a proposition-valued equivalence relation. The module constructs
the actual Cubical set quotient `Q = X / ~`. Effectiveness identifies
equality of representatives in `Q` with the relation. Quotient induction
then proves that equality in `Q` is stable under double negation.

Every point of the actual crystalline generator
`𝔇 = Σ r : R, ¬¬ (r = 0)` double-negation-neighbors its basepoint.
Any function from `𝔇` to a type with double-negation-stable equality
therefore has equal values everywhere. Evaluation at the basepoint
proves that the constant-function map is an equivalence. Thus such
types, and in particular `Q`, are crystalline.

The quotient map `X → Q` consequently factors through the actual
crystalline reflector. Effectiveness then gives the checked theorem

```text
(η x = η y) → ¬¬ (x = y).
```

This applies to ordinary, varying types and points; no promotion of a
variable to a crisp context occurs.

### Stable predicates yield actual étale inclusions

Suppose `P : X → hProp` is stable under neighboring. The two directions
of that stability make `P` invariant under `~`, so proposition
extensionality and the quotient recursor produce an actual predicate
`P̄ : Q → hProp` with `P̄ [x]` computing to `P x`.

Both `Q` and `Σ q : Q, P̄ q` are crystalline: propositions are crystalline,
and the modality is closed under dependent sums of modal types.
The inclusion `Σ x : X, P x → X` is an actual pullback of their
projection along `X → Q`. The existing proved pullback theorem for maps
between modal types therefore makes this inclusion crystalline étale.
The module constructs the pullback equivalence; it does not assume
étaleness or infer it merely from modal fibers.

Two direct corollaries are exposed:

- `For X.penon-open-inclusion-etale P openP`, since Penon-open predicates
  are neighbor-stable;
- `For X.neighborhood-inclusion-etale x`, since neighboring is transitive.

In particular, ordinary open chart ranges can be used directly once
their Penon openness is proved. Selecting a crisp chart atlas is not
required for this argument. The neighborhood corollary also applies at
ordinary points, as needed when intersecting a crystalline subspace
with the neighborhood of a point on an ordinary curve.

### Scope

The only geometric input is the ring used to define `𝔇` and its actual
higher-inductive nullification. No Kock–Lawvere axiom, excluded middle,
crisp induction, sharp calculus, or pullback-preservation axiom is used.

The theorem does not identify every Penon neighborhood with a reflected
unit fiber: that further identification requires connectedness of the
neighborhood. It also does not assert that arbitrary crystalline
subspaces have decidable equality. Those are separate statements.

Paper correspondence: Myers,
[*Orbifolds as microlinear types*](https://arxiv.org/abs/2205.15887),
§5.2 and the open-chart/disk steps in Lemma 6.3.4. The quotient proof is
an independently checked replacement for the relevant use of sharp,
not a formal construction of the entire sharp modality.

<a id="penon-crystalline-scope"></a>

## Penon disks and crystalline reflection

This note records the exact scope of the recovered and extended Section 5.2
proofs. The files use the actual crystalline modality, defined as nullification
at the infinitesimal neighborhood of zero in a commutative ring. All Agda checks
use the pinned native kit, safe mode, Cubical Agda, and literal cohesion checking.

### Accepted ordinary-context results

For an actual Penon manifold, `CrystallinePenonDisks.agda` proves:

* The infinitesimal neighborhood at a point is equivalent to the actual fiber
  of the crystalline unit over that point's image. The equivalence retains the
  underlying point judgmentally.
* The double-negated equality relation between two points is equivalent to
  equality of their crystalline images.
* The crystalline reflection of the manifold is a set.

The proof uses the constructive separated quotient in
`CrystallineSeparation.agda`, the crystalline connectedness of infinitesimal
powers, stable-subtype inclusion etaleness, and the actual unit's mere
surjectivity. It assumes neither crispness nor sharp reflection nor a global
pullback-preservation axiom. These are ordinary-context versions of the
comparison in Lemma 5.2.9 and the manifold case of Lemma 5.2.7.

`CrystallinePenonEtale.agda` proves Theorem 5.2.10 for ordinary Penon manifolds.
For a function `f`, its `PenonEtale` predicate is literally the assertion that
every canonical `neighborhoodMap f x` is an equivalence. This predicate is
equivalent to the existing crystalline `Etale f`, defined by the actual unit
naturality pullback comparison. The proof compares the canonical neighborhood
maps with the maps on unit fibers, applies the fiber criterion from
`PullbackCancellation.agda`, and extends the condition from unit images to all
reflected points using mere surjectivity.

The same file derives `crystalline-etale-fibers-separated`: equality in each
fiber of such an etale map is stable under double negation. This is separation,
not decidable equality. In particular it does not supply the missing ordinary
family decidable-equality step in the full orbifold argument.

### Accepted generic and crisp set reflection

`ModalProducts.agda` proves that every modality preserves binary products, with
the actual universal-property comparison and its diagonal coherence. It uses
modal induction only.

`ModalSetReflection.agda` proves that reflection preserves the sethood of a type
if it preserves the single self-pullback of that type's diagonal. The proof
characterizes embeddings by either projection from their self-pullback,
transports this condition across the canonical pullback comparison, and uses
binary-product preservation to recover the actual reflected diagonal. It does
not assume unrestricted left exactness.

`CrispSetReflection.agda` specializes this generic theorem to Lemma 5.2.7 using
the literal `CrispPullbackPreservation` axiom from `CrispGeometry.agda`. Its type
has a judgmentally crisp type parameter `(@♭ X : Type ℓ)`; the proof of `isSet X`
may be ordinary. The only instance of the axiom is the crisp diagonal's
self-pullback. Its crisp
theorem is first checked for an abstract modality and then specialized to the
actual crystalline modality; this keeps elaboration from expanding the entire
nullification comparison while matching the diagonal diagram.
<a id="geometry-audit"></a>

## Geometry and logical scope audit

The literal internal main Theorem 6.3.7 is now checked. This audit records
which tempting shortcuts remain unjustified and how the accepted proof avoids
them. The exact main signature and assumptions are in
properness.md#proper-etale-orbifold-scope; its external-properness limitation is in
properness.md#properness-scope.

### Chart preimages and actual constancy

Shape modality gives constancy of maps defined on all of R, not on an
arbitrary disconnected open subset. The chart-preimage sentence in the
printed proof of 6.3.4 therefore needs additional work.

CrystallineManifoldCurves restricts chart preimages to actual interval
neighborhoods. IntervalParameterization supplies a surjection R onto a
bounded open interval using the underlying equivalence of Postulate Exp.
FiniteIntervalChains, RationalGridOrder and LocallyConstantIntervals then
prove actual global constancy by a structurally terminating chain through
finite selected rational-grid intervals. Only coded endpoints have decidable
comparisons; smooth-real order and selection membership remain undecided.
CrystallineManifoldShape consequently proves the full geometric conclusion
of 6.3.4 without a double-negation-separation premise.

FiniteConnectedGluing remains a useful independent proof of the weaker
negative-equality consequence. It uses constructive double-negated finite
decisions, with no global excluded middle. The final interval-chain proof
no longer needs that weakening.

### The crisp/family distinction remains valid

CrispDiscrete proves decidable equality for a native-crisp set that is
shape-modal, relative to R-flat and crisp excluded middle. An ordinary
varying Hom x y is not automatically crisp. Three properties remain distinct:
shape modality, double-negation-stable equality, and decidable equality.
The new main theorem does not install a generic implication between these
properties for an arbitrary ordinary family.

Instead, literal DPProper(source,target) yields decidable image membership.
Tiny-powered surjectivity lifts infinitesimal families of related object
pairs to arrows; source etaleness forces those lifts constant. The total
arrow space is therefore crystalline. It is also an actual ordinary
manifold, so the full 6.3.4 theorem makes it shape-modal. Crucially, the
presentation makes this total arrow type crisp. Crisp logic applies there,
and each ordinary Hom x y inherits decidable equality through its actual
embedding. No object variable or hom family is promoted to crisp data.

### Properness and the external interpretation

ProperCompactDecisions proves DPProper diagonal equivalent to decidable
equality for every set. Under K and first-order Kock-Lawvere, the smooth-real
diagonal cannot satisfy that internal predicate. Thus the literal internal
main theorem must be distinguished from an external comparison asserting
that every classically proper Lie groupoid supplies its hypotheses.
Such a semantic comparison is not proved here. The diagnostic does not
refute the checked conditional theorem. Definition 6.2.1 tests ordinary
varying compact subtypes, not only crisp ones; Warning 6.2.20 already shows
why arbitrary closed subtypes of compact types cannot be declared DP compact.

### Infinitesimal inverse versus an ordinary local inverse

LocalInjectivity proves that actual open local homeomorphism data imply
ordinary fiberwise isolation and decidable equality. The separate
LocallyInjectiveGroupoids theorem uses that explicit additional hypothesis.
The accepted main theorem no longer needs it.

Myers adds an infinitesimal inverse-function hypothesis before Corollary
5.2.12. Its tangent-square criterion does not, by its name alone, construct
ordinary open inverse neighborhoods. No such model-specific comparison has
been installed as a general rule. That conditional theorem and any associated
external comparison remain separate correspondence entries.

### Sources

- Myers, [arXiv:2205.15887v1](https://arxiv.org/html/2205.15887v1), especially
  5.2.8–5.2.12, 6.2.1, 6.2.20 and 6.3.1–6.3.7.
- Penon, [Infinitésimaux et intuitionnisme (1981)](https://www.numdam.org/item/CTGDC_1981__22_1_67_0.pdf),
  printed pp. 70–71 for the ordinary-model discussion and inverse-function
  hypothesis.
- foundations.md#crisp-foundation for native Agda scope, and properness.md#properness-scope for the
  checked diagonal diagnostic and its exact logical limits.

<a id="ordered-uniform-neighborhoods"></a>

## A uniform real neighborhood over a compact type

`OrderedUniformNeighborhoods` supplies the explicit ordered-real
specialization of Theorem 6.2.8. If a proposition-valued relation on
`K × R` is Penon open, `K` is Dubuc-Penon compact, and the relation holds
for every element of `K` at a real point `x`, there merely exists one
positive real radius `epsilon` such that it holds for every `k : K`
and every `y` in the actual interval `(x-epsilon, x+epsilon)`.

The ball structure is the already constructed open-interval structure
from `CountableRealProbe`; no abstract ball structure remains as an
input. The explicit hypotheses are the existing Kock field, strict
order, ordered-ring compatibility, and Postulate E instantiated for
these literal intervals. No radius is chosen independently at each
point of `K`, and no countable or dependent choice is assumed.

<a id="rational-intervals-scope"></a>

### Decidable comparison of the constructed endpoints

`RationalGridOrder.agda` uses the actual endpoint construction from
`RealCountableBasis.agda`: a triple `(n,m,k)` represents
`(nat k - nat m) * step n`, where the existing `step n` satisfies
`nat (n+1) * step n = 1` and is positive.

To compare two such points, the proof multiplies by both positive denominators
and adds a common offset. The comparison becomes a comparison between

* `k * (n'+1) + m' * (n+1)`, and
* `k' * (n+1) + m * (n'+1)`.

These are natural numbers. Their trichotomy supplies the decision, and the
ordered-ring calculations prove both directions of the translation. This
does not give or assume decidable order on arbitrary smooth reals. It uses
the precise reciprocals already chosen in the basis, so no equality between
independently selected reciprocals is needed.

The same module constructs the `DenseOrder` interface required by
`FiniteIntervalChains.agda`: weak order is the negation of reverse strict
order, mixed transitivity follows from cotransitivity, and half-interval
arithmetic supplies overlap points. It also proves that the coded center
`(n,m,k+1)` belongs to the actual grid interval indexed by `(n,m,k)`.

### Locally constant curves are constant

`LocallyConstantIntervals.agda` proves
`Curve.globallyConstant`: every locally constant map from the smooth real
line into a set is constant. Its assumptions are the existing Kock field,
strict order, separately displayed ordered-ring compatibility, covering
property E, and compactness of the explicit closed unit interval.

The proof uses the existing, constructed countable rational-grid basis and
the existing selected cover. A code is selected precisely when the curve
is constant on that code's grid interval. Selection is proposition-valued
and is never assumed decidable. Compactness gives a bound on the selected
codes needed to cover the segment under consideration. The proof converts
that bound to a finite indexed family, retaining the selection proofs in
the merely supplied membership witnesses.

The checked finite-chain algorithm traverses this actual finite cover. When
the target lies beyond the current interval, coverage at its upper endpoint
supplies an overlapping interval. Density gives a point in both intervals;
the two local constancy proofs identify the function values. The exhausted
interval is then deleted and induction continues on the smaller family.
All choices are eliminated only into the propositional equality type of
the set-valued target.

For arbitrary curve endpoints, selected grid intervals supply their coded
centers. Local constancy identifies each endpoint value with its center's
value, and the rational-endpoint theorem connects the centers.

This theorem yields actual equality. It needs no separation premise on the
target, no decidable target equality, no Principle of Constancy, no exponential
equivalence, and no Boolean-connectedness premise. The latter three inputs
were needed by other earlier routes, not by this constructive gluing theorem.

### General crystalline subspaces of ordinary manifolds

`CrystallineManifoldShape.agda` combines the previously checked local chart
argument with this stronger gluing theorem. Its public theorem
`Geometry.Manifold.Subspace.crystalline-subspace-shape-modal` proves that an
arbitrary crystalline type embedded into an actual `OrdinaryManifold` is
actually shape-modal.

The inputs are K, O, ordered-ring compatibility, the exact real-valued
Principle of Constancy, covering property E, closed-unit-interval compactness,
and an equivalence of the real line with the positive reals. The chart
argument uses the positive-line equivalence to parameterize actual interval
neighborhoods within chart preimages. It makes no connectedness claim about
the whole chart preimage. The final theorem has no additional double-negation
stability or decidable-equality premise on the subspace.

This completes the geometric shape-modality conclusion of Lemma 6.3.4 in
the formalization's explicit analytic setting. It supersedes the extra
separation requirement of the earlier general-subspace route described in
`manifolds.md#manifold-curves-scope`; the previously checked fiber and hom results remain
valid independently.

### Remaining logical boundary

Shape modality is still not identified with ordinary family-wise decidable
equality. In particular, this upgrade does not derive
`(x y : Objects) → Discrete (Hom x y)` from shape modality alone, and does not
by itself discharge the proper-finiteness step in the literal main theorem.
No global excluded middle, decision procedure for smooth reals, unrestricted
crispness promotion, or additional decidability foundation field was added.

<a id="manifold-curves-scope"></a>

### Real connectedness

`RealConnectedness.agda` derives that every function from the smooth reals to
`Bool` is constant. The assumptions are exactly the existing Kock field
condition and the real-valued Principle of Constancy. The proof encodes the
two Boolean values by zero and one, proves that the encoding is injective,
and uses the double-negation stability of Boolean equality to show invariance
under first-order infinitesimal translations. It then applies Principle of
Constancy to the encoded real-valued curve. It assumes no excluded middle,
decidable equality of smooth reals, or additional connectedness field.

### The repaired chart argument

`CrystallineManifoldCurves.agda` works with an actual embedding of a
crystalline type into an actual `OrdinaryManifold`, using the existing pointed
open chart equivalences. The intersection with each chart range is a
propositional subtype of the crystalline type, hence is crystalline. Its
inverse chart coordinates separate points. Principle of Constancy applied
coordinate by coordinate therefore makes all real curves into this chart
piece constant.

The preimage of a chart range can be disconnected. The proof does not apply
connectedness to that entire preimage. It uses the actual Penon openness of
the preimage to find an interval neighborhood, and the proved interval
parameterization to obtain constancy on that interval.

The original countable grid-cover argument in `LocallyConstantCurves.agda`
gives globally neighboring values. Its upgrade using separately supplied
double-negation stability remains a valid theorem, but the full general
subspace result no longer needs that extra hypothesis.

### Full geometric conclusion of Lemma 6.3.4

`RationalGridOrder.agda` constructs decidable order for the actual rational
grid endpoints. Positive denominator cross multiplication reduces each
comparison to natural-number trichotomy. It also instantiates the dense-order
interface of `FiniteIntervalChains.agda`, using cotransitivity for the weak
order laws and half-interval arithmetic for overlap witnesses. It does not
assume decidable order or equality for arbitrary smooth reals.

`LocallyConstantIntervals.agda` applies the finite-chain theorem to the
exact selected countable grid cover. Compactness bounds the necessary codes;
selection itself remains undecidable. The algorithm crosses overlapping
intervals and deletes exhausted members, terminating structurally on the
finite family size. It proves actual global equality for every locally
constant set-valued real curve. This intermediate theorem uses only K, O,
ordered-ring compatibility, E, and closed-unit-interval compactness. It needs
no target separation, decidable target equality, Principle of Constancy,
exponential equivalence, or Boolean-connectedness premise.

`CrystallineManifoldShape.agda` combines this actual-equality theorem with
the local chart proof. Its
`Geometry.Manifold.Subspace.crystalline-subspace-shape-modal` proves actual
shape modality for any crystalline type embedded in an actual ordinary
manifold. The exact analytic premises are K, O, separately displayed
ordered-ring compatibility, Principle of Constancy, covering property E,
compactness of the explicit closed unit interval, and an equivalence of the
real line with the positive reals. There is no separated-equality or
decidable-equality premise on the subspace. The complete rational arithmetic
and gluing construction is described in `manifolds.md#rational-intervals-scope`.

### Actual etale fibers and groupoid homs

`CrystallineManifoldFibers.agda` discharges the separation hypothesis for
fibers of an actual crystalline-etale map from an ordinary manifold into a
Penon manifold. It uses the ordinary-to-Penon theorem for the source, the
actual crystalline modality's modal-fiber theorem, and
`CrystallinePenonEtale.crystalline-etale-fibers-separated`. The latter follows
from injectivity of the canonical map on Penon disks, not from a decidable
equality assumption.

Consequently these actual fibers are shape-modal. A groupoid hom type is
identified with the target-equality subtype of a source fiber; since the
object type is a set, that subtype is propositional. Closure of shape-modal
types under these subtypes then yields
`(x y : Objects) → IsShapeModal (Hom x y)` for ordinary, unrestricted object
variables. No crispness promotion occurs.

This is a geometric shape-modality result. It does not establish ordinary
family-wise `Discrete (Hom x y)`, and does not by itself complete the proper
finiteness or full Theorem 6.3.7 argument.

### Finite-interval combinatorics

`FiniteIntervalChains.agda` is a generic constructive gluing theorem. In a
dense ordered ambient type, a finite cover by open intervals with decidably
comparable endpoints forces a set-valued function constant whenever it is
constant on each selected member. The selection predicates can be arbitrary
types, and their membership need not be decidable. The algorithm crosses
overlapping intervals and deletes each exhausted interval, so its termination
is structural on the finite family size. Only endpoints are compared; it
does not assume decidable ambient order or equality.

Its rational-grid instantiation is now checked and is used by the full
general manifold-subspace theorem above. This geometric upgrade still does
not justify a shape-modal-to-decidable-equality inference for ordinary varying
families, which remains a separate boundary in the main theorem.

### Relation to the completed literal main theorem

ProperEtaleManifoldOrbifolds now proves the literal internal Theorem 6.3.7
by applying crisp logic to the crystalline, shape-modal total arrow type,
then restricting its decidable equality through ordinary hom embeddings.
This does not extend the generic shape-modal-to-DecEq rule to ordinary
families. The strong properness input and separate external-comparison
limitation are documented in properness.md#properness-scope.

