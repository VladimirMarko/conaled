# Torus

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="torus-translations-scope"></a>

## Actual torus quotient and free-action comparison

This is a constructed intermediate for Myers, Corollary 3.2.9:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.

`FreeActionQuotients.agda` takes an ordinary algebraic group, an
actual action on a set, and a proof that the action is free. It
proves that the actual homotopy quotient defined by equivariant
functions on algebraic torsors is a set. It constructs its
equivalence with the literal set quotient by
`Relation x y = Σ g, g · x = y`, together with the quotient-map
triangle. The forward map uses weakly constant truncation
elimination into a set, rather than a chosen torsor point. The
module also computes transport along every loop of the torsor
delooping, including the inverse dictated by the left-action
convention.

`DeloopedFreeActionQuotients.agda` proves the corresponding
universe-polymorphic recognition theorem for an actual family
over any pointed connected delooping. Its explicit inputs are
set fibers, an algebraic action, an equivalence at the base
fiber, a loop-coordinate equivalence preserving the unit,
the transport computation for every loop, and freeness.
It derives sethood, the literal orbit-set comparison, and the
quotient-map triangle. These inputs are a reusable theorem
interface; no torus or semidirect instantiation is assumed.

`TorusTranslations.Coordinates` takes a commutative ring `R`,
the paper's `StrictOrder`, and a natural number `n`. It defines
the torus as the actual set quotient of `FinData.Fin n → R`
by the relation

`Σ z : (FinData.Fin n → ℤ), integer(z) + x = y`.

The integer interpretation is the canonical checked coefficient
map. The accepted `IntegerEmbedding.translation-free` proves
freeness. An explicit lift/lower comparison removes the
universe lift from the representatives of the final relation.
The resulting `translation-homotopy-quotient≃torus` and
`quotient-triangle` identify the actual algebraic translation
homotopy quotient with this literal torus and preserve its
projection from real coordinates.

For any ordinary group `H` and actual integer matrix
representation `ρ : H → GLₙ(ℤ)`, `TorusTranslations` also
constructs an action on the literal torus by quotient recursion.
The unit and composition laws are proved, and its action on
representatives is definitionally `[x] ↦ [ρ(h)x]`.

The generic torus comparisons use no EM, choice, or decidable equality of
reals, and their representation need not be finite, crisp, or faithful.
The normal-fiber and associated-family comparisons and finite crisp subgroup
specialization are supplied by the separate split-extension and shape
modules below, not by these generic comparisons alone.
<a id="torus-finite-products-scope"></a>

## Finite products of the literal circle quotient

`FiniteProductQuotients.agda` proves that a finite product commutes
with quotient by a proposition-valued equivalence relation. The
comparison sends a vector class to the vector of its coordinate
classes. Quotient effectiveness proves injectivity. The proved
finite-choice theorem in Cubical v0.9 proves surjectivity. No
additional choice axiom is introduced.

`TorusFiniteProducts.agda` defines the literal circle quotient
`R/ℤ` by the proposition-valued relation

`Σ z : ℤ, integer(z) + x = y`.

The canonical integer embedding proves that this relation is
proposition-valued. Its reflexivity, symmetry, and transitivity
are checked directly. Coordinatewise translation witnesses
assemble into an actual integer vector, and this yields the
equivalence

`circle-power≃torus : (FinData.Fin n → R/ℤ) ≃ Rⁿ/ℤⁿ`.

Both representative triangles are proved. The forward map from
`Rⁿ/ℤⁿ` to the product computes definitionally by sending `[x]`
to the coordinate classes `[xᵢ]`. The inverse triangle identifies
the image of those coordinate classes with `[x]`.

For every actual representation `ρ : H → GLₙ(ℤ)`, the source
also transports the previously constructed matrix action to the
finite product, proves its action laws, and proves equivariance
of the torus comparison. `matrix-action-on-representatives`
computes this action as `[x] ↦ [ρ(h)x]` coordinatewise. The
accepted homotopy quotient and associated-family constructions
remain unchanged.

The inputs are a commutative ring with `StrictOrder` and an
ordinary natural dimension. Matrix-action compatibility adds
only the actual group representation. There is no crispness,
real decidable-equality, Kock-Lawvere, or shape premise in these
two modules. This is an auxiliary concrete identification for
Myers' torus construction:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.

<a id="torus-compactness"></a>

## A compact fundamental cover of the literal torus

`TorusCompactness.agda` is checked with the pinned safe Agda compiler,
exit code zero and no warnings. It proves actual compactness of the
literal quotient R^n/Z^n, using the paper's explicit unit-interval
compactness hypothesis.

The map on the actual closed cube is

t |-> [i |-> 2*t(i)].

Its surjectivity is proved. The constructed integer-residue theorem gives
each real number merely an integer translate in (0,2). Multiplication by
the proved positive inverse of 2 gives an actual point of the closed unit
interval mapping to its quotient class. The proved finite-choice theorem
assembles the coordinate witnesses. The exact finite-product torus
comparison and its representative triangle identify this map with the
literal vector quotient projection; no arbitrary replacement torus is
used.

Compactness of finite powers is derived from binary-product compactness.
The recursion uses sum-based finite ordinals and their proved equivalence
with the literal coordinate index, avoiding unsupported indexed matches.
Surjective-image compactness then proves the torus compact. The module
also proves compactness of the one-dimensional quotient R/Z directly.

Exact inputs are an ordinary commutative ring, KockField, StrictOrder,
ordered-ring compatibility, and `CompactIntervals.UnitIntervalCompact`.
No floor function, decision of real order, countable choice, or additional
compactness axiom is assumed. The theorem uses same-universe compactness;
it does not silently promote tests to a larger proposition universe.

This supplies a compact fundamental cover for the integer-translation
quotient. It does not by itself package a full geometric definition of a
crystallographic action, an invariant Euclidean metric for a finite linear
group, or a proper-discontinuity theorem. Those remain separate from the
already checked torus shape calculation.

<a id="torus-split-scope"></a>

## Torus family, affine quotient, and shape computation

These are actual constructions for the torus statement in Myers,
Corollary 3.2.9:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.

### Actual quotient and action

`DeloopedOrbitActions.agda` proves a generic descent theorem:
transport computations on a surjective set of representatives,
together with the actual loop-coordinate equivalence, determine
transport at every point and every loop. All proof elimination
is into set-valued identity types. The generic certificate also
avoids repeatedly normalizing the concrete torsor constructions.

`SplitFreeActionQuotients.agda` instantiates the checked free-action
recognition theorem for the actual normal homotopy fiber of the
semidirect-product projection. The input consists of actual groups
`N,H`, an automorphism action of `H` on `N`, compatible set actions,
and freeness of the `N` action. It proves that the normal-fiber
quotient is the literal `N` orbit set. The actual outer family is
set-valued, and its transport along every loop is the induced
`H` action on the orbit set. Neither its loop-transport premise nor
its orbit-set comparison remains assumed in this instantiation.

`TorusSplitQuotients.Coordinates.Representation` takes an ordered
commutative ring `R`, dimension `n`, a group `H`, and an actual
integer matrix representation `ρ : H → GLₙ(ℤ)`. The integer lattice
translation action is free by the checked integer embedding theorem.
Its `AssociatedTorus` is an actual family over the actual `H` torsor
delooping, with the point shifted along the constructed extension
pointing. `base-fiber≃torus` identifies the fiber with the literal
set quotient `Rⁿ/ℤⁿ` from `TorusTranslations.agda`.

`all-loop-matrix-action` computes transport for every loop and every
fiber point. `matrix-action` states the usual action of each `h`
after the inverse convention for left actions is accounted for.
This identifies the associated action with the previously constructed
matrix action on all torus classes. `torus-quotient≃affine-quotient`
then identifies the actual dependent-sum quotient of that family
with the actual affine semidirect homotopy quotient. Both the
base-fiber triangle and the total quotient triangle are checked.

### Shape and universe accounting

`NullSigmaReflection.agda` proves nullification of an actual dependent
sum over a null base using the universe-polymorphic nullification
recursor. The base and the fibers may live in different universes.
Contractible reflected fibers make the canonical first projection
a reflection map, with its unit triangle. No resizing or change
of the real generator is used.

`IntegralAffineShape.agda` takes crisp `R,n,H,ρ`, explicit lower and
upper crisp identity rules, lower and upper real-flatness, and an
ordinary finiteness witness for `H`. It derives nullity of the actual
integer lattice and of the actual affine semidirect group. It then
uses `TorsorShape` to derive nullity of the actual algebraic torsor
classifier in its successor universe. Real-coordinate shape
connectedness follows from the real generator and the checked finite
product theorem. The result is the canonical equivalence

`Null_R (Rⁿ // (ℤⁿ ⋊ H)) ≃ Torsors (ℤⁿ ⋊ H)`.

`projection-unit` and `orbit-point-triangle` identify the actual map
and its point. The upper real-flatness hypothesis is explicit and
is not inferred from the lower one. The input does not assume
nullity of the desired classifier or shape connectedness of real
coordinate space.

The final composition with the torus quotient equivalence belongs to
the separate `TorusShape.agda` wrapper and is a separate wrapper.
The algebraic construction accepts
any integer matrix representation; the paper's finite-subgroup
specialization also requires its representation to be an embedding.
The Euclidean isometry, proper-discontinuity and cocompactness certificate is a further construction in [Integral affine geometry](integral-affine.md), not an assumption of this generic split extension. They construct the actual split extension and
the actual action and shape equivalences described above.

<a id="torus-shape"></a>

## Shape of the actual torus matrix quotient

`TorusShape.agda` and `IntegralAffineDiscreteShape.agda` use the constructed torus/action/semidirect comparison described in [Split extension](torus.md#torus-split-scope).

These results formalize the shape calculation underlying
[Myers, Corollary 3.2.9](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9).
The precise conclusion is an equivalence from the actual R-nullification
of the torus matrix-action quotient to the actual algebraic torsor
classifier of the integer affine semidirect group.

### Actual objects and maps

The torus is the literal set quotient of `FinData.Fin n → R` by
integer translations. Its matrix action is constructed from an actual
group homomorphism `ρ : H → GLₙ(ℤ)`, using the proved integer ring
homomorphism. The associated family over the actual H torsor
delooping has this torus as its identified base fiber. Transport is
computed for every loop and every fiber point, so the action is
specified beyond a formula on selected representatives.

The checked `TorusSplitQuotients.torus-quotient≃affine-quotient`
identifies that dependent-sum action quotient with the actual
homotopy quotient of Rⁿ by Zⁿ ⋊ρ H. The semidirect multiplication and
the affine action are constructed in `IntegralAffineActions.agda`.
The classifier in the final theorem is precisely
`Torsors.Theory.Torsor` of that constructed group.

### Derived modality hypotheses

For a crisp real ring, crisp n, crisp H, and crisp ρ, the reusable
theorem takes an ordinary proof that the actual Flat counit of H's
carrier is an equivalence. Lower-universe R-flatness then proves H
R-null. Native integer crisp induction proves actual integer nullity;
function-type closure proves nullity of integer coordinate vectors;
the explicit universe lift and product closure give nullity of the
actual semidirect carrier.

The actual torsor classifier is connected and has its loop type
identified with the semidirect group. The checked crisp connected
separated-type theorem therefore proves the classifier R-null at its
own successor universe. The required upper-universe R-flatness and
crisp identity rule remain explicit. Neither is inferred from the
lower-universe hypotheses.

The actual shape of R is contractible by the nullification generator
theorem. Finite-product preservation of connectedness proves the
same for `FinData.Fin n → R`. The actual affine action's regular
fiber is equivalent to this coordinate type. Mere connectedness of
the torsor classifier transports connectedness to every associated
fiber, eliminating paths only into the proposition of contractibility.
Universe-polymorphic sigma reflection then identifies the affine
quotient's shape with the classifier.

For the paper's finite-group case, the explicit `Finite` module takes
ordinary actual finiteness `isFinSet (H .fst)` and derives the required
discreteness using the already checked finite-nullity theorem and
R-flatness. No assumption of the desired classifier nullity, quotient
shape equivalence, or coordinate shape contractibility remains.

### Canonical comparison and pointing

The final map is the actual nullification recursor extending

torus quotient --constructed equivalence--> affine quotient
                   --first projection--> torsor classifier.

The composite proof of equivalence through the affine quotient is
identified with this exact recursor by nullification induction.
`comparison-unit` computes on every original quotient point.
`representative-triangle` sends every real-coordinate orbit point to
the regular torsor, using the checked total-quotient triangle.

The file consequently exports the equivalence, a pointed equivalence
at every chosen real-coordinate representative, and an equivalence
from its actual shape loop type to the carrier of the constructed
integer affine group. These are not equivalences between unspecified
replacement types.

### Scope

The reusable theorem applies to arbitrary crisp crisply discrete H
and an actual integral representation. The finite specialization
therefore applies in particular to a finite crisp subgroup of
GLₙ(ℤ); faithfulness is not needed for the displayed shape equivalence.
The strict order is an ordinary parameter, used in the earlier proof
that integer translations are free. Kock's field axiom, a compactness
axiom, and a norm-equivalence premise are not needed here.

The theorem identifies the explicit group Zⁿ ⋊ρ H and its classifier.
It does not package a separate definition or theorem of Euclidean
isometric, properly discontinuous, or cocompact action under the
word “crystallographic.” Such additional geometric properties must
retain their own precise hypotheses and proofs.

