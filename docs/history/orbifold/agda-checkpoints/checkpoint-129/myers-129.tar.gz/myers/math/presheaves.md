# Presheaves

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="presheaf-semantics"></a>

### Implementation boundary

The intended end-to-end semantic formalization remains entirely in Agda.
Conaled is a source of mathematical constructions and proof strategies,
not a Lean component of this proof. The current native result constructs
ordinary presheaf operations and assembles a conditional obstruction. It
does not yet interpret the smooth sheaf theory or the admitted source
language.

### 1. The accepted constructions

All module paths below are under `src/Orbifolds/Intensional/`.

| Module | Constructed result |
| --- | --- |
| `CategoricalTransfer` | Two-universe ordinary categories, actual-arrow isomorphisms, product-map laws, hom-map inverses, adjunction interface and projection-based nullity. |
| `ObstructionTransfer` | Transfers nullity, contractible global sections and nonterminality; derives invertibility of the actual constant map and noninvertibility of the Flat counit under the displayed structural inputs. |
| `SmallPresheaves` | Actual set-valued presheaves, natural transformations and their equality/sethood, the presheaf category, terminal object, pointwise products, constants, representables and Yoneda. |
| `PresheafRestriction` | Actual restriction, with inverses of its canonical terminal and product comparison maps. |
| `PresheafRightKan` | Pointwise right extension, the restriction/right-extension adjunction, its natural counit, and full faithfulness derived from a fully faithful base functor. |
| `PresheafConstants` | Small-set category, constant-presheaf and global-section functors, their adjunction, and the actual natural evaluation counit. |
| `PresheafRepresentedLine` | The canonical isomorphism between the restriction of the target representable and the source representable. |
| `PresheafExponentials` | Actual fixed exponential objects, evaluation, curry/uncurry, inverse laws, source naturality and the component formula for the canonical constant map. |
| `PresheafObstructionInstance` | Instantiates the conditional theorem with all those constructed presheaf operations and the actual counit. |

The categorical interfaces remain useful for other instances. The concrete
presheaf adapter does not ask for its adjunction, preservation comparisons,
exponential or constant-object conclusions as fields: it constructs them
from the supplied bases and functor.

### 2. Universes and logical inputs

The general category interface separates object and hom universes:
objects lie in `Set o` and each hom lies in `Set h`, with an explicit
hom-set proof. In the presheaf construction, the base objects and homs
lie in `Set ℓ`, and every value is an `ℓ`-small set. Presheaf objects then
lie in `Set (lsuc ℓ)`, while each natural-transformation type lies in
`Set ℓ`. There is no resizing step.

The concrete presheaf constructions take explicit weak function
extensionality `FunExt ℓ ℓ`. It proves component extensionality,
irrelevance of naturality certificates, and sethood of the transformation
types. Larger-universe function extensionality and object univalence are
not inputs. Function extensionality is a stated metatheoretic parameter;
these modules do not construct its inhabitant in ordinary intensional
Agda.

No excluded-middle, double-negation-elimination, arbitrary-choice,
crisp-excluded-middle, RealFlat or infinitesimal-tinyness inhabitant is
used by this branch. Some helper modules also contain definitions and
theorems about other assumptions; importing those definitions does not
supply their inhabitants. The final signatures and proof dependencies
retain the explicit function-extensionality boundary.

`ConstantObjects` ranges over small types supplied with set proofs, not
all types in the larger presheaf-object universe. This distinction is
needed for the actual small-set constant functor. A set-valued presheaf
category is not thereby a model with an internal universe of all admitted
dependent families.

### 3. Actual restriction and right Kan extension

Let `i : C → D` be the supplied functor between small ordinary categories.
Restriction is precomposition with `i`. For a presheaf `F` on `C`, define

\[
  (UF)(d)=\operatorname{Nat}(D(i(-),d),F).
\]

An arrow `d' → d` acts by precomposition with the corresponding map of
represented kernels. The implementation proves the presheaf laws and
constructs the action on natural transformations.

For `P` on `D`, the two directions of the adjunction are explicit:

\[
 \Phi(a)_d(p)_c(f)=a_c(P(f)(p)),\qquad
 \Psi(t)_c(p)=t_{i(c)}(p)_c(\mathrm{id}).
\]

The two inverse laws and both hom-naturality laws are proved before
assembling `Adjunction restriction extension`. In particular, no
right-Kan-extension existence theorem is an input.

When `i` is fully faithful, let `recover` be the supplied inverse of its
actual hom-map. The inverse of the counit at `F,c` sends `x` to the
natural family

\[
  (c',f:i(c')\to i(c))\longmapsto F(\operatorname{recover}(f))(x).
\]

Naturality and both inverse laws follow from the hom inverse and the
functor laws. The proof of `extension-fully-faithful` then identifies the
forward function of its composed hom-equivalence with the actual
`extend-nat` operation. An unrelated equivalence of endpoint hom-sets
would not establish that result.

`PresheafRestriction` proves invertibility of the canonical comparison
formed by pairing the two restricted projections. It does not replace
that map by an unspecified product isomorphism. The represented-line
comparison takes explicit choices `R_C = y_C(R)` and `R_E = y_D(iR)`;
its forward components are `recover`, and its inverse components are
the actual hom-map of `i`.

### 4. Exponentials, constants and global sections

For presheaves `R,F` on the same base, the exponential is constructed by

\[
  F^R(c)=\operatorname{Nat}(y_c\times R,F).
\]

Its restriction maps use postcomposition of representable arrows, paired
with the identity of `R`. Evaluation and curry/uncurry are actual maps:

\[
 \operatorname{curry}(a)_c(x)_d(k,r)=a_d(H(k)(x),r),\qquad
 \operatorname{uncurry}(t)_c(x,r)=t_c(x)_c(\mathrm{id},r).
\]

Both levels of naturality and the inverse laws are derived. These fixed
exponential objects satisfy the precise currying interface required by
the obstruction theorem. A separately packaged exponential functor in
its arguments is not claimed.

The canonical constant map is defined by currying the first projection.
Its component formula is proved by reflexivity:

\[
  \operatorname{const}_c(x)_d(k,r)=F(k)(x).
\]

The constant-presheaf functor `Δ` acts pointwise on small sets. The
global-section functor is

\[
  \Gamma F=\operatorname{Nat}(1,F).
\]

This is the set of all compatible global sections, not evaluation at an
assumed terminal base object. The construction also works for an empty
base. The adjunction `Δ ⊣ Γ` is proved, and its actual counit evaluates a
global section: `ε_F(c,s) = s_c(tt)`. Naturality of this arrow is proved.
Its domain is definitionally the `Flat` object used by the adapter,
including the relevant point-set proof.

These are presheaf constants. A pointwise constant presheaf is generally
not a sheaf. The later sheaf construction must supply sheafification or
another proved constant-sheaf construction and its comparison laws.

### 5. Exact conditional obstruction

For a category with chosen products and line `R`, nullity of `F` means
invertibility, for every `X`, of the actual projection-precomposition map

\[
 \operatorname{Hom}(X,F)\longrightarrow
 \operatorname{Hom}(X\times R,F),\qquad f\longmapsto f\circ\pi_1.
\]

The abstract transfer theorem composes the adjunction, this inverse,
the canonical product comparison, and the line comparison. It proves
that the resulting forward map is precisely precomposition by the
source projection. Terminal comparison transfers contractible global
sections. Full faithfulness reflects terminality, hence transfers
nonterminality.

The concrete presheaf theorem has the following remaining inputs:

1. Actual small categories `C,D`, their functor `i`, its full-faithfulness
   inverse data, and `FunExt ℓ ℓ`.
2. A base object `R`.
3. An actual presheaf `F` that is `y_C(R)`-null, whose global-section set is
   contractible, and that is not terminal.

It constructs `UF` and proves transferred nullity, contractible global
sections and nonterminality. Nullity and the constructed exponential
make the actual constant map `UF → (UF)^R_E` invertible. Since
`Γ(UF)` is contractible, `ΔΓ(UF)` is terminal. Therefore its actual
counit to the nonterminal `UF` cannot be an isomorphism.

The main exports are in
`PresheafObstructionInstance.ForEmbedding.ForCounterexample`:
`lifted-nullity`, `lifted-points`, `lifted-nonterminal`,
`constant-is-iso`, `flat-counit-not-iso`, and
`real-flat-contradiction`. The final result refutes the implication from
invertibility of that particular constant map to invertibility of that
particular counit, at the supplied witness. The witness is not assumed
to exist merely because this conditional theorem has been checked.

### 6. Relation to the smooth-site argument and original source

[external-models.md#site-transfer-080](external-models.md#site-transfer) independently proves the
external ordinary-sheaf comparison for the specified finite smooth
presentation and germ-determined sites. It transfers the previously
constructed external de Rham witness from finite-Weil probes by an
actual right Kan extension. The native modules here supply generic
categorical and presheaf components of that proof. They do not supply
the actual sites, cover lifting, sheaf conditions, or de Rham witness.

The exact source correspondence was checked against Myers's
[paper, v1, section 3.1](https://arxiv.org/pdf/2205.15887): Definition
3.1.1 uses the canonical flat counit, and Axiom 2 concerns the actual
constant-map arrow for every crisp type in its universe. The source
`CrispPropositions.RealFlat` has that same quantification; its variable
name `P` does not restrict it to propositions. The paper describes flat
as the stack constant at global sections.

A native application to that source still needs an interpretation of
the smooth line, exponentials and lambda terms, identity and equivalence,
the crisp Flat former and counit, and a code for the witness in the
relevant universe admitted by the crisp binder. A cardinal size estimate
alone is not a universe-classification or crisp-substitution theorem.
The ordinary-sheaf obstruction under those identifications does not
prove that every possible interpretation of the original foundation is
inconsistent.

The original source also separately assumes crisp excluded middle.
That obligation must be addressed for an interpretation of the unchanged
full foundation. It is not an assumption of the new presheaf construction
or of the reduced seven-file ordinary atlas theorem.

### 7. Remaining constructions

The next native model layer must construct sites and the relevant sheaf
operations: the sheaf condition, restriction and right-extension sheaf
closure, constant sheaves, representable sheaves and exponential sheaf
closure. It must then construct dependent families, reindexing,
comprehension and type operations with their exact substitution laws.

The geometric instance additionally requires constructive real/calculus
and manifold foundations, the formal smooth site and its localization
proofs, actual quotient/descent constructions, and the appropriate
counterexample or geometric test objects. The higher interpretation,
universes and their classification, crisp rules, and source-language
interpretation remain separate substantial obligations. None is
discharged by these nine ordinary presheaf modules.

The proposed proof strategies and their constructive/classical
boundaries are compared in
[Constructive transfer](constructive-transfer.md).

<a id="sheaf-semantics"></a>

## Actual small sites, sheaves, and right Kan gluing

The ordinary sheaf operations below concern supplied small sites. They do not by themselves construct the smooth site or interpret the source type theory.

### 1. Sizes and actual site data

`SmallSites.agda` takes a category whose objects and hom sets lie in
`Set ℓ`. A sieve on `X` gives an actual proposition-valued membership
predicate on arrows into `X`, and a proof of closure under precomposition.
The sieve type lives in `Set (lsuc ℓ)`. Pullback sieves are constructed by
composition; their downward closure uses the actual associativity law.

A Grothendieck topology gives a small proposition of covering for each
sieve, with maximality, pullback stability and local character. Upward
closure under pointwise inclusion is explicit. This prevents an implicit
use of propositional extensionality to identify different records for
logically equivalent sieves. No propositional extensionality or resizing
is used by these modules.

For a functor `i : C → D`, the inverse-image sieve along `f : i(c) → d`
is the actual predicate

\[
T_f(h) = S(f \circ i(h)).
\]

The `CoverLifting` premise says that `T_f` covers `c` for every covering
sieve `S` on `d` and every such `f`. This premise concerns categories,
arrows, sieve membership and covering alone. It contains no sheaf,
right-Kan extension, or preservation-of-sheaves conclusion. The concrete
smooth-site application must prove this premise separately.

### 2. A sheaf has actual unique gluing

`SmallSheaves.agda` constructs the presheaf associated with a sieve:
its sections at `Y` are pairs `(f : Y → X, p : S(f))`. Restriction
precomposes `f` and applies the sieve's downward-closure proof. The
proposition-valued membership makes this a set-valued presheaf without
identifying membership proof records externally.

A matching family is an actual natural transformation from that sieve
presheaf into `F`. An `Amalgamation` consists of a section of `F(X)`, its
restriction equations, and uniqueness against every competing section
with those equations. `IsSheaf` supplies such an amalgamation for every
covering matching family. The sheaf record retains both its underlying
presheaf and that gluing structure.

This is constructive data: the closure proofs invoke the given gluing
operation and prove its required laws. They do not choose arbitrary
witnesses from truncated existence statements. These files do not claim
an equivalence with every alternative, propositionally truncated
formulation of the sheaf condition; such a conversion would need its own
argument.

The category of sheaves has all underlying natural transformations as
morphisms. It does not require equality between two sheaf certificates.
Consequently its construction avoids function extensionality over the
large type of all sieves and avoids assuming certificate irrelevance.
The only extensionality parameter is the existing `FunExt ℓ ℓ`, used for
small functions and natural transformations. Sheaf objects lie in
`Set (lsuc ℓ)` and hom sets in `Set ℓ`.

The forgetful functor to presheaves is constructed and fully faithful
for its actual arrow map. Separatedness is derived from unique gluing.
The terminal sheaf is constructed with its unique section. Binary
products are the actual pointwise presheaf products; the proof projects
a matching family, glues each projection, and pairs the results. The
restriction and uniqueness laws are proved componentwise. No terminal
or product sheafhood is supplied as an unproved model field.

### 3. Right Kan extension preserves sheaves

`RightKanSheaves.agda` uses the actual extension already constructed above:

\[
UF(d) = \operatorname{Nat}(D(i(-),d),F).
\]

Given a sheaf `F` on `C`, a covering sieve `S` on `d`, and a matching
family `α : S → UF`, the proof constructs its unique amalgamation:

1. The previously proved adjunction's actual `untranspose` turns `α`
   into a transformation from the restricted sieve to `F`.
2. For each `f : i(c) → d`, this transformation gives a matching family
   over `T_f`, evaluated on the composites `f ∘ i(h)`.
3. `CoverLifting` makes `T_f` covering. The given sheaf structure of `F`
   therefore produces a glued value in `F(c)`.
4. Separatedness on the relevant inverse-image cover proves that these
   values are natural in `c`. They form an actual element of `UF(d)`.
5. The actual transpose/untranspose inverse law identifies the canonical
   restrictions of this element with the original `α`.
6. Applying the competing section's restriction equations at identity
   arrows, followed by uniqueness of the local gluings, proves uniqueness
   of the resulting element of `UF(d)`.

Thus `extension-is-sheaf` is a theorem, not a field in the assumptions.
Its proof does not require full faithfulness of `i`. The induced functor
between the two actual sheaf categories is constructed. When the base
functor is fully faithful, the earlier presheaf full-faithfulness theorem
applies to this same map of underlying natural transformations, giving
`extension-fully-faithful` for the sheaf functor.

### 4. What this milestone does not establish

Restriction of presheaves has already been constructed, but these three
files do not prove that restriction preserves sheaves. In particular,
full faithfulness and preservation of covers alone do not control overlaps
that exist in the larger category but are invisible in the smaller one.
An adequate continuity theorem must include the necessary overlap or
pullback condition. The selected-overlap restriction theorem and sheaf adjunction are separate constructions below; neither follows just from the three modules in this subsection.

The [overlap counterexample](#overlap-counterexample) below explains the missing hypothesis. The concrete site transfer uses image coverage and preservation of actual open intersections, not full faithfulness alone.

The ordinary exponential, constant-sheaf and dependent-family constructions
are separate sections/modules, not premises of this right-Kan theorem.
The full smooth site, higher quotient/descent, universe classification, crisp
semantics and source interpretation/substitution remain distinct. The actual
de Rham witness is not constructed here as a native inhabitant of these
sheaf definitions.

The input topology and input sheaf are genuine mathematical parameters.
This milestone proves closure theorems for those parameters; it does not
establish all the analytical or model-theoretic instances required for
the complete external orbifold theorem. Nor does it settle the full
original Myers foundation's model-existence question.

## Changing one leg of an actual sheaf pullback

`SheafPullbackLegIsomorphism` has passed its complete native gate. Fix actual
sheaves F,G,G',H, arrows alpha:F→H,
beta:G→H and beta':G'→H, an isomorphism e:G→G', and the one equation
beta'∘e=beta. Both pullback objects are constructed by the existing
`SheafPullbackConstruction`, not supplied as a desired comparison.

Write f for the forward leg map and g for its inverse. The additional square
beta∘g=beta' follows at x from the inverse of the supplied square at g(x),
then congruence of beta' on f(g(x))=x. This is an equality of whole natural
maps by the existing small natural-map extensionality.

For Source=F×_H G and Target=F×_H G', their actual lifts construct

```text
forward = lift_Target(first_Source, f ∘ second_Source)
inverse = lift_Source(first_Target, g ∘ second_Target).
```

The existing lift-first and lift-second theorems give all four projection
triangles. For forward∘inverse, the first projection reduces to the original
first projection by two triangles; the second uses two triangles followed by
f∘g=id. Target.morphism-ext then proves the whole right inverse. The reverse
argument uses g∘f=id and Source.morphism-ext. These maps and laws construct the
isomorphism of the actual pullback sheaves. Values and morphisms stay at level
ell, sheaf objects at its successor, using only the existing FunExt ell ell.

For the constant-count construction, specialize F to the finite-label sheaf,
G to delta(Unit), G' to the terminal sheaf, and H to the natural-label sheaf.
Use the actual count projection, constantArrow, count, terminalComparisonIso
and count-on-unit equation. The constructed endpoints agree with the existing
DeltaPullback and TerminalPullback by their definitions, with their actual
sheafhood certificates retained.

This specialization selects the helper's derived commuting proof in its
inverse lift. That proof need not be judgmentally equal to the old concrete
reflexive square. If comparison with that implementation is required, both
whole natural maps agree by their projection triangles and morphism-ext;
equality of internal witnesses is unnecessary. The downstream context, family
and certified-term construction uses the triangles and inverse laws. Acceptance
of the generic owner alone does not accept that concrete specialization or
establish which declaration caused its earlier resource failure.

<a id="sheaf-exponentials"></a>

## Constructed sheaf exponentials

`Orbifolds.Intensional.SheafExponentials` constructs function objects in the supplied ordinary category of sheaves.

### The theorem and its inputs

Let `C` be a small category with objects and hom sets in `Set ℓ`, let `J`
be a Grothendieck topology in the exact `SmallSites` sense, and supply the
existing `FunExt ℓ ℓ` parameter. If `F` is a `J`-sheaf and `R` is any
small set-valued presheaf on `C`, the already constructed presheaf
exponential `F^R` is a `J`-sheaf. In particular, the result applies when
both `R` and `F` are sheaves.

The proof does not assume that representables are sheaves, that the site
is subcanonical, that `R` is a sheaf, or that any sheafification functor
exists. Sheafhood of `F^R` is the conclusion of an explicit gluing proof.
The result remains about ordinary set-valued sheaves. It is not by itself a
dependent-product or higher-type-theory model construction.

### Actual gluing of functions

The underlying exponential has components

\[
(F^R)(X)=\operatorname{Nat}(yX\times R,F).
\]

Suppose `α` is a matching family of such elements on a covering sieve
`T` of `X`. The construction uses the actual presheaf uncurrying map to
obtain a transformation `T × R → F`. For each arrow `f : Y → X` and
each `r : R(Y)`, it forms the matching family on the actual pullback
sieve `f* T` whose value at `h : Z → Y` is

\[
\operatorname{uncurry}(\alpha)_Z((f\circ h,p),R(h)(r)).
\]

Pullback stability makes this sieve covering. `F`'s sheaf structure
glues these values to an element of `F(Y)`. The proof then establishes:

- Naturality of these glued values in `Y`, using separatedness over
  another actual pullback covering sieve and the presheaf composition
  laws for both `F` and `R`.
- Recovery of the original local value whenever `f` belongs to `T`,
  using restriction along the identity and the gluing equations.
- Equality of the resulting canonical matching family with `α`, using
  the actual curry/uncurry inverse law proved for presheaves.
- Uniqueness of the glued natural transformation, by applying any
  competing section's restriction equations at identities and then
  the unique-gluing property of `F`.

This construction supplies `exponential-is-sheaf`. All local argument
data from `R` are explicitly restricted; they are never selected or
glued using an assumed sheaf structure on `R`.

### The category operations and exact maps

For sheaves `R` and `F`, the module forms an actual exponential object
in the full category of sheaves. Because that category uses all
underlying natural transformations as morphisms and has the constructed
pointwise products, the existing presheaf currying equivalence gives

\[
\operatorname{Hom}(H\times R,F)
\simeq \operatorname{Hom}(H,F^R)
\]

with both inverse laws and naturality in `H`. The module instantiates
the existing `Exponential` interface with these actual operations.
Together with the ordinary sheaf terminal and binary products, this
constructs the cartesian closed structure on the supplied ordinary
sheaf category.

Evaluation is the inherited transformation whose component sends
`(s,r)` to `s(id,r)`. The theorem `evaluation-is-uncurry` identifies it
with uncurrying the identity. The categorical constant arrow is the
transpose of the actual first projection. `constant-underlying`
identifies it with the existing presheaf constant arrow by reflexivity;
its value at `(f,r)` is `F(f)(x)`, independent of `r`. These are
identifications of the exact intended maps, not merely assertions that
some isomorphism or evaluation operation exists.

### Logic, sizes and remaining obligations

Only the existing `FunExt ℓ ℓ` is used. No larger-universe extensionality,
certificate irrelevance, propositional extensionality, resizing,
excluded middle or arbitrary-choice operation is introduced. Sheaf
objects remain in `Set (lsuc ℓ)` and their natural-transformation hom
sets in `Set ℓ`. The sheaf certificates are retained as data and are
not identified as equal records.

This result does not construct restriction continuity, the sheaf
adjunction between the specified sites, the constant-sheaf/global-section
adjunction, sheafification, or the de Rham counterexample as an actual
native sheaf. A pointwise constant presheaf must not be silently treated
as a sheaf. The actual smooth site and analytic instance, dependent
families and universe classifiers, higher quotient/descent, crisp rules,
and exact interpretation/substitution for the source language remain
separate work. The complete external orbifold theorem and full original
foundation's model-existence question remain unresolved.

The user-requested implementation remains entirely Agda. The inspected
Lean and Agda libraries are mathematical and architectural references;
none is imported as an unverified component of this native proof.

<a id="sheaf-adjunction"></a>

## Constructed restriction of sheaves and its right adjunction

Three ordinary modules construct restriction-preserves-sheaves and the actual sheaf adjunction, with the hypotheses below.


### 1. The precise additional site data

The overlap obstruction explains why full
faithfulness, covering images and `CoverLifting` do not by themselves
ensure that restriction preserves sheaves: a smaller category may fail
to detect overlaps that exist in the larger category. The new proof
states the missing structure explicitly.

For `i : C → D`, source topology `J` and target topology `K`,
`SelectedCoverRefinements` supplies the following for every `J`-covering
sieve `S` on `c`:

- A small indexed family `u_j : c_j → c`, each lying in `S`.
- Universal image coverage: every target sieve on `i(c)` containing
  all `i(u_j)` is `K`-covering.
- For every `u_j` and every source arrow `h : y → c`, a chosen commuting
  square in `C` whose image is an actual pullback in `D`. Its lift,
  projection equations and uniqueness quantify over every object of `D`.

`CoverRefinement.agda` defines these structures. The image-coverage
condition avoids needing a propositionally truncated generated-image
sieve. The overlap condition contains an actual universal property,
not merely a square commuting on source probes. A commuting `C`-square
with a `D`-universal image is the exact data supplied: without full
faithfulness, the record does not separately assert a universal property
inside `C`.

This is **selected cover and pullback data**, stronger than an unstructured
statement that an appropriate family merely exists. The theorem does not
derive that selection from excluded middle or a choice operator. A concrete
site must construct the data, possibly using a canonical family of all
suitable cover members, or state the additional mathematical assumptions
needed. Renaming an arbitrary selection as site data would not establish
a constructive instance.

The premise mentions no sheaf, gluing operation or preservation-of-sheaves
conclusion. It therefore isolates a genuine site-level input to the
constructed theorem. It is distinct from `CoverLifting`, which was the
input for the right-Kan direction in this local construction.

### 2. Unique compatible values replace arbitrary factorizations

`SheafRestriction.agda` takes a target sheaf `G` and a matching family
`α` on a source cover `S`. For the selected cover members write
`a_j = α(u_j)`. Given a target arrow `f : d → i(c)`, a value `x : G(d)`
is compatible when every commuting square

\[
f\circ k=i(u_j)\circ t
\]

satisfies `G(k)(x) = G(t)(a_j)`. This is a small proposition: its
quantifiers range over the small index set, objects, arrows and equality
proofs; its final equalities lie in the set `G(e)`.

Compatibility has at most one solution. For two compatible values `x,y`,
the proof forms an **agreement sieve** on `i(c)`. An arrow `g : e → i(c)`
belongs when every square `f k = g l` forces `G(k)(x)=G(k)(y)`.
Compatibility puts every image cover arrow `i(u_j)` in this sieve, so
universal image coverage makes it covering. Pulling it back along `f`
and evaluating the square condition at the identity gives equality of
all local restrictions of `x,y`. The target sheaf's separatedness proves
`x=y`.

Consequently the dependent sum

\[
\mathrm{Good}(f)=\sum_{x:G(d)}\mathrm{Compatible}(f,x)
\]

is a proposition. It retains an actual unique local value rather than
an arbitrarily chosen factorization. Precomposition restricts that value,
so `Good` is an actual sieve. Its first projections form a natural
transformation from the sieve presheaf into `G`.

### 3. Gluing and recovery are proved

The preserved overlap square for `u_j` against a source arrow `h` lets
the proof turn source matching-family naturality into compatibility
against **all target-domain squares**. The target pullback lift is what
makes the arbitrary target domains visible.

Applying this argument to the source cover members proves that `Good`
contains every `i(u_j)`, hence is covering. The actual target sheaf
structure glues the natural family of its first projections to a section
of `G(i(c))`.

For every original sieve member `h`, the value `α(h)` is itself compatible,
using its selected overlap squares. The gluing restriction equation on
`Good(i(h))` therefore recovers `α(h)`. This proves all of the original
matching equations, not just those on the selected refinement.

Finally, a competing global section that matches `α` restricts to each
selected `a_j`. Its restriction along any target arrow is consequently
compatible. Uniqueness of compatible values gives the required matching
equations on `Good`; the target sheaf's unique gluing proves global
uniqueness. This supplies `restriction-is-sheaf` and the actual restriction
functor between the two sheaf categories.

The proof introduces no truncated image, representative-selection
operation, full-faithfulness assumption, or sheafhood conclusion as a
field. It uses only the existing small `FunExt ℓ ℓ`, actual input
sheaf gluing, and the explicitly selected site data.

### 4. The actual sheaf adjunction and comparison maps

`SheafAdjunction.agda` additionally takes `CoverLifting` for the same
sites and functor. Restriction and right extension then both land in
sheaves by their respective constructed gluing proofs. Because the
sheaf categories have the full underlying natural-transformation hom
sets, the existing actual presheaf hom equivalence gives

\[
L:\mathrm{Sh}(D,K)\rightleftarrows\mathrm{Sh}(C,J):U,
\qquad L\dashv U.
\]

The module proves both hom-naturality laws using those same maps. Its
counit is the existing presheaf counit on the actual restricted extension.
The terminal comparison is definitionally the canonical terminal map.
The binary-product comparison is definitionally the pairing of the
restricted actual projections. Their inverse maps and both inverse
equations are supplied, so terminal and binary-product preservation are
proved rather than replaced by unrelated isomorphisms.

When the base functor is fully faithful, the actual counit is an
isomorphism and the right extension is fully faithful. Invertibility of the unit
and an equivalence of the whole sheaf categories are not asserted.

### 5. Remaining geometric and semantic obligations

Concrete smooth sites must still be constructed, along with their
`SelectedCoverRefinements` and `CoverLifting` instances. The external
SITE-TRANSFER-080 proof provides a mathematical guide: its localization
calculation proves the required open intersections are actual pullbacks
against all larger-site objects. That calculation is not mechanized by
the generic theorem.

For a sheaf-level represented-line comparison, the particular target
representable must actually be a sheaf, and the source representable's
certificate must be supplied or transported along the actual presheaf
isomorphism. Full faithfulness alone does not establish representable
sheafhood. General constant sheaves/sheafification, the actual de Rham
witness, real/calculus/manifold instances, dependent and higher operations,
universe classification and exact source interpretation remain separate.

<a id="sheaf-obstruction"></a>

## Actual contractible constants and the conditional sheaf obstruction

`ContractibleSheafConstants.agda` and `SheafObstructionInstance.agda` construct the following bounded obstruction adapter.


### 1. The particular constant object is constructed

A pointwise constant presheaf need not be a sheaf. These modules use a
specific case where it is a sheaf: the small value set `A` is supplied
with a contraction. On any covering matching family, the contraction's
center is an actual glue. Its paths to all other elements give both the
restriction and uniqueness equations. This constructs the sheaf and
proves that it is terminal.

The existing presheaf constant/global-section equivalence becomes an
actual sheaf hom equivalence

\[
\operatorname{Hom}(\Delta A,F)\simeq (A\to\Gamma F),
\]

natural in the target sheaf `F`. Here `ΓF` is the actual small set of
natural transformations from the terminal presheaf to the underlying
presheaf of `F`. It is not merely a specified set of closed points or
an evaluation at an assumed terminal base object.

When `ΓF` is contractible, this constructs the particular object
`Delta Gamma F` and its actual evaluation counit. Its component at a
base object `X` sends a global section `s` to `s_X(tt)`. The proof
identifies this map with the inverse transpose of the identity on `ΓF`.
If `F` is nonterminal, the counit is not an isomorphism: its source is
terminal, and an isomorphism would transfer terminality to `F`.

This does not construct a constant-sheaf functor at every small set.
The witness-specific construction is enough for this obstruction, while
the general constant-sheaf and sheafification tasks remain separate.

### 2. Comparison with a genuine constant/global-section interpretation

The record `RepresentsConstants A` states a local universal property at
one specified small set: an object `Q` represents `A → Γ(-)`, with an
actual hom equivalence natural in the target. A genuine constant/global-
section adjunction supplies this data at each individual `A`.

The proof constructs the canonical comparison `ΔA → Q` from the image
of `id_Q` under the other universal property. Target naturality proves
that precomposition by this actual comparison realizes the composite
hom equivalence. Its inverse is extracted from that equivalence;
injectivity after precomposition proves the other inverse law. The
comparison is therefore an actual isomorphism.

The module also proves compatibility with the maps selected by both
universal properties. At `A = ΓF`, applied to the identity of `ΓF`, this
is the exact commuting counit square. Consequently the alternate
representation's own counit is also noninvertible when `F` is nonterminal
and `ΓF` is contractible. This comparison concerns the intended maps,
not only an unspecified isomorphism between their source objects.

The local representation record is used to compare other interpretations.
It is not being used to assert that the missing general constant-sheaf
functor has been constructed: the contractible constant object and its
counit were constructed independently above.

### 3. Genuine sheaf nullity supplies the presheaf premise

The source witness is assumed null in its actual **sheaf category**:
precomposition with the first projection gives the specified hom
equivalence for every sheaf parameter. The adapter does not demand a
stronger presheaf-nullity input.

First, the actual sheaf exponential turns this sheaf nullity into
invertibility of the canonical map `F → F^R`. Its underlying natural
transformation is exactly the previously constructed presheaf constant
map. The inverse and its equations remain valid in presheaves. For any
presheaf parameter `X`, postcomposition with that isomorphism, followed
by the actual uncurrying equivalence, gives an equivalence

\[
\operatorname{Hom}(X,F)\simeq\operatorname{Hom}(X\times R,F).
\]

The constant-map naturality equation and the curry/uncurry inverse law
identify its forward map with precomposition by the actual first
projection. This derives the full presheaf-nullity premise used by the
presheaf transfer theorem. No sheafification of `X` is assumed.

### 4. The assembled sheaf statement

The adapter takes the following mathematical inputs:

| Input | Exact role |
| --- | --- |
| Small categories `C,D`, functor `i`, and topologies `J,K` | The actual source and target sites |
| `CoverLifting` | The site-only condition used to prove right-Kan sheafhood |
| Full faithfulness of `i` | The constructed extension's full faithfulness and underlying represented-line comparison |
| A source object `R` and sheaf certificates for `y_C(R)` and `y_D(iR)` | Actual line objects in both sheaf categories |
| A source sheaf `F` | The supplied counterexample object |
| Sheaf nullity of `F` for `y_C(R)` | Converted to the exact underlying presheaf premise |
| Contractible actual global sections of `F` and nonterminality of `F` | The two other counterexample properties |
| `FunExt ℓ ℓ` | Small function and natural-transformation equalities |

From these inputs, the theorem constructs the actual sheaf
`UF(d) = Nat(D(i(-),d),F)` and proves:

1. `UF` is null for the target represented line, in the target sheaf
   category.
2. Its actual global-section set is contractible.
3. It is nonterminal; full faithfulness of the actual sheaf extension
   reflects the hypothetical terminality back to `F`.
4. Its actual exponential constant map is an isomorphism.
5. The actual evaluation counit from its constructed contractible
   constant object is not an isomorphism.
6. The corresponding nullity-to-counit-invertibility direction is
   contradictory, both for the constructed constant object and for
   any other representation with the stated local universal property.

This bounded adapter does not use the restriction-continuity theorem or
`SelectedCoverRefinements` from the restriction branch. Its
presheaf transfer and right-Kan sheafhood suffice. Importing both branches
in the aggregate does not add one branch's parameters to the other.

### 5. Constructivity and the remaining interpretation boundary

No general choice operation, truncated-image representative, excluded
middle, propositional extensionality, resizing, certificate irrelevance
or larger-universe function extensionality is introduced. Small set
carriers and homs lie in `Set ℓ`; the sheaf objects and local universal-
property record lie in `Set (lsuc ℓ)`. The latter quantifies over objects,
but its use does not require equality between all such object-indexed
functions or between sheaf certificates.

The actual smooth categories, topologies, cover lifting and represented-
line sheaf certificates are still inputs. The de Rham counterexample
has not yet been constructed as a native inhabitant of `Sheaf J` with
the required properties. The theorem does not thereby establish a new
concrete countermodel or a universal no-model theorem.

To apply the result to Myers's exact source axiom still requires the
correct universe code for the witness, its admissibility at the crisp
binder, the specified line and function-type interpretation, and the
identification of the source Flat counit with the compared constant/
global-section counit. These are substantive model and source-translation
obligations. A generic categorical obstruction alone does not settle the
full original foundation's consistency or model existence.


<a id="overlap-counterexample"></a>

## Restriction of sheaves: the missing overlap condition

This finite counterexample and sufficient-route argument are paper mathematics, not an additional native Agda theorem.

### The two directions require different site hypotheses

For i:C->D, SmallSites.Along.CoverLifting J K says that every K-covering
sieve S on d, pulled back along f:i(c)->d, gives the J-covering sieve
{h:c'->c | f i(h) belongs to S}. RightKanSheaves constructs sheafness of
UF(d)=Nat(D(i(-),d),F) from precisely this condition. This is correct and
requires no full faithfulness. It does not establish that restriction r
sends every K-sheaf to a J-sheaf.

Even full faithfulness, CoverLifting, and coverage of the D-sieve generated
by every J-cover are insufficient for that latter assertion.

### Explicit finite counterexample

Let D be the diamond poset, regarded as a category, with objects e,a,b,c
and nonidentity arrows e->a->c and e->b->c; both composites are the same
arrow e->c. Let C be its full subcategory on a,b,c. Give each category the
topology generated by the family {a->c,b->c}, with maximal covers elsewhere.
The image-generated sieve in D includes e->c; the source sieve in C does not
have an e-object.

The inclusion is fully faithful. It satisfies CoverLifting: restricting the
nontrivial covering sieve at c gives the source cover, and pulling it back
to a or b gives the maximal sieve. Covers at e have no maps to e from C.
Images of source covering families generate target covering sieves.

The constant presheaf with value the two-element set is a D-sheaf. A
matching family on the cover of c must agree on e, so its two labels are
equal and glue uniquely. Its restriction to C is not a sheaf: the source
cover has a matching family labelled 0 on a and 1 on b, with no common
object imposing agreement, and it has no amalgamation in the constant
presheaf. The missing hypothesis is control of overlaps.

Global density of C in D would fix this, but is unnecessarily strong and
not the intended finite-Weil/finite-smooth-presentation comparison. Nor
should the generic theorem demand preservation of arbitrary finite limits:
formal Cartesian probes are not closed under arbitrary smooth pullbacks.

### A sufficient condition adapted to SmallSites

Use a specified basis of covering families in C. For each family
(u_j:c_j->c), require:

(a) Its image is K-covering. This can be expressed without constructing a
truncated generated-image sieve: for every T:Sieve D (i c), if T contains
every i(u_j), then K.Cover T. This is a topology condition, not a
sheaf-preservation field.

(b) Each pair c_j,c_k has a chosen overlap c_jk in C with projections and
the commuting square, and its image square is an actual pullback in D.
The universal property must quantify over every D-object. A pullback
property only tested on objects of C would miss exactly the diamond defect.
An alternative is a K-covering family of C-overlap probes satisfying the
same compatibility-detection property; this is useful for a ball basis.

(c) The specified families really generate J, with their stability and
composition/refinement proofs. Formalization must supply a cover-induction
or cover-refinement theorem, rather than silently assume that testing these
families is equivalent to the given arbitrary-sieve sheaf condition.

For a K-sheaf G, source matching sections on a basis cover agree on c_jk by
C-naturality. Condition (b) makes these the actual D-overlap equations.
Condition (a) then gives their unique D-gluing at i(c). The basis criterion
(c) yields IsSheaf J (rG). Every compatibility map is induced by the given
functor and restrictions; no conclusion about sheafhood is an input.

There is an implementation subtlety: the raw Sigma type of factorizations
of an arbitrary D-arrow through an image covering arrow is not usually a
proposition. It cannot simply be installed as Sieve.contains and supplied
with an unjustified contains-prop. Defining its propositional image requires
an appropriate truncation construction, or a formulation avoiding that image.
Adding a chosen factorization for every image-member is a stronger selected-
data assumption; it must not be advertised as avoiding arbitrary choice by
renaming it a topology field.

The universal containment formulation in (a) avoids assuming an image sieve.
A constructive family-descent lemma can use the sieve of arrows carrying a
unique compatible local value: uniqueness makes its membership a proposition,
and the sheaf supplies the gluing. Its proof still needs the overlap and
pullback-cover arguments; (a) alone is insufficient. Another sound route is
to construct the needed small truncations and generated sieves explicitly.
The restriction and adjunction modules described above implement a selected-overlap route; this argument alone is not their native verification.



## Certified comprehension values

`DependentPresheafComprehensionComputation` has passed its complete native gate.
For the existing comprehension of a family A over Γ along σ:Δ→Γ, take one
actual map k:Δ→Γ.A and its actual over-base equation h:display∘k=σ.
The existing read operation constructs a certified term in A[σ]. At X,x put

```text
a = subst (λ y → value A (X,y))
      (cong (λ s → component s X x) h)
      (snd (component k X x)).
```

The existing read-component equation is reflexivity and exhibits its section
component as `(x,a)`. The term-value operation additionally transports a along
the actual section certificate. This is a loop at x; the existing value-set
of Δ identifies that loop with reflexivity. Congruence of substitution therefore
proves the certified value exactly a, retaining the original transport along h.
The proof is abstract at symbolic presheaves and family, so concrete callers
need only its equation. There is no computation assumption about nat-ext,
propositionhood assumption on A's fibers, arbitrary proof-irrelevance premise,
or desired term input. Pair recovery and certified uniqueness remain the
existing pair-read and unique operations in DependentPresheafSections.

## Pairing across repeated reindexing

`DependentTermPairComposition` has passed its complete native gate. For an
actual family A over Gamma and maps sigma:Delta→Gamma and tau:Theta→Delta,
the single family A[sigma∘tau] and repeated family A[sigma][tau] remain distinct
presheaf presentations. The accepted family-reindexing comparison provides
actual forward and inverse natural maps between them; the accepted term
transport maps certified terms through those maps.

Let Direct pair terms from the single family, Iterated pair terms from the
repeated family, and First.lift be the actual total-space lift for sigma.
The two checked equations are

```text
First.lift ∘ Iterated.pair (Forward.map t) = Direct.pair t
Direct.pair (Inverse.map u) = First.lift ∘ Iterated.pair u.
```

Here t inhabits the single family and u the repeated one. Write the actual
section output at an input as (y,a). Both sides of each equation have component
(sigma_X(tau_X(y)),a): the family comparison preserves the displayed value,
and the two lifts compute that actual base. Small natural-map extensionality
then proves equality of the whole pairing maps. This argument does not replace
y by the original input or assume its section certificate computes.

The inverse equation supports comparing the explicitly mapped repeated term
with a direct read term by the existing comprehension uniqueness theorem.
It does not identify the two family records. The natively accepted
`DependentTermSubstitutionLaws` now uses these actual pairing maps. Identity
compares the section of the identity-family image with the identity
comprehension pair, then applies substitution-pair and categorical right
identity before whole-term extensionality. Both component maps preserve the
section's actual output base; no certificate computation is assumed.

For composition let d be direct substitution and r iterated substitution.
The inverse pairing equation, the two substitution-pair equations and
associativity prove

```text
pairDirect(Inverse.map r)
  = First.lift ∘ pairSecond r
  = First.lift ∘ (section(firstTerm) ∘ tau)
  = (First.lift ∘ section(firstTerm)) ∘ tau
  = (section(t) ∘ sigma) ∘ tau
  = section(t) ∘ (sigma ∘ tau)
  = pairDirect d.
```

Comprehension pair-injectivity gives Inverse.map r = d in the actual single
family. Reversing its image under Forward.map and using the accepted term-map
forward-inverse law for the same family isomorphism proves Forward.map d = r.
The certified terms and public law endpoints are unchanged. This revised
proof has passed its complete native gate. The earlier source's timeout does
not apply to these bytes, and no declaration hotspot is claimed.

`DependentTermSubstitutionEquality` is a separate source-written, pending
compatibility theorem. For freely quantified actual context maps sigma,tau
and p:sigma=tau, the existing contextMap(p) takes substitute sigma t to
substitute tau t as equality of complete certified terms in A[tau]. Ordinary
identity elimination on p reduces contextMap to the actual identity natural
map of A[sigma]; the accepted term-map identity law supplies that case.
The target endpoint tau remains free in the motive, so this is ordinary J
and not K. No substitution construction, family record or section certificate
is replaced, and no larger universe or extra coherence premise is assumed.

## Explicit sections of proposition-valued families

`DependentPropositionFamilySections` has passed its complete native gate.
For an actual presheaf context Gamma and family A with
proposition-valued fibers, actual elements point(X,x) at every stage and
context point define a natural global section: both A.restrict(f)(point(v))
and point(u) lie in the same proposition fiber at the domain u of an
element-category arrow f:u→v. The accepted term/global-section comparison
then constructs the certified term, with component (x,point(X,x)) and an
actual term-value equation accounting for its certificate transport.
Existing value extensionality proves uniqueness and thus contractibility.
The explicit point data are stronger than mere local inhabitance; this
construction neither chooses from truncations nor assumes a certified term.
It supplies no universe or higher identity interpretation.

## Componentwise repeated contexts and identity endpoints

`DependentReindexedTotalExtensionality` has passed its complete native gate.
For the actual reindexing of A over Gamma along sigma:Delta→Gamma, the
constructed total carries its display to Delta and lift to the original
total Gamma.A. Equality of these two images determines equality of total
elements: the existing pullback value-path compares their images under the
actual pullback comparison, and that comparison's constructed injectivity
returns equality in the reindexed total. Applying this value argument to
each component of two natural maps and then natural-map extensionality proves
their whole-map equality. Both projection equations are explicit inputs;
joint monicity is the output. The proof retains the original reindexing and
pullback presentations and the specified function-extensionality hypothesis.

For a set-valued presheaf context Gamma and an actual presheaf family A, write
B for its dependent total and D for the total after reindexing A along B's
display. The elements of D are `((x,a),b)`. The repeated-context implementation
uses the component maps

    first((x,a),b) = (x,a)
    second((x,a),b) = (x,b)
    diagonal(x,a) = ((x,a),a).

The restriction computations make the last two maps natural pointwise. Both
projection/diagonal laws are proved as equalities of natural transformations,
using the existing transformation extensionality. This does not replace
arbitrary equality proofs by reflexivity: the computations concern these
particular components in the constructed reindexed family.

For the common family over D, the two candidate sections insert respectively
`a` and `b` as the last component. The common value map forgets the two endpoint
slots and keeps that last component. Their display triangles, value triangles
and equality after diagonal substitution are the exact obligations in
`DependentPresheafIdentityEndpoints`. The source contains their componentwise
proofs; its complete native gate remains pending. A completed check of
`DependentPresheafRepeatedContext` is a smaller theorem, not acceptance of
those endpoints or arbitrary-motive identity elimination. The current ledger,
not a report of a lost check, determines which exact sources have evidence.

The comparison with the prior comprehension/read and variable operations is
preserved in `DependentPresheafEndpointCompatibility`. It states the actual
term equalities, including the display equations and the original variable
term, rather than assuming a new operation-preservation field. It is separate
pending source, not silently discarded correspondence. The sheaf specialization
must use the same maps and independently constructed sheaf certificates; that
specialization, identity-context isomorphism, J and substitution/reflexivity
compatibility still require complete native checks. All this concerns the
set-valued model: neither a higher identity eliminator nor full source-language
admission follows from it alone.


## Constructed display identity elimination and its map laws

There is now a separate complete categorical construction that does not unfold
the expensive nested family presentation. It is extensional, set-valued
identity semantics; it neither replaces arbitrary higher identities nor claims
that the old identity-family representation is definitionally the same object.

`Intensional.PullbackIdentityElimination` starts with a category, a display
p:B→Gamma, its actual self-pullback D with projections a,b, and an equalizer
E→D of those projections. Its input interfaces are the usual limit universal
properties: lifts and triangles with joint monicity, and factorization with
monic inclusion. They contain no identity-context isomorphism or eliminator.
The self-pullback constructs a diagonal delta:B→D. Equalizer factorization
constructs s:B→E, and r:E→B is the first projection after inclusion. The two
inverse laws are proved by joint monicity and equalizer monicity. For any
motive display q:M→E and branch d:B→M with q d=s, define

    J(d) = d r.

Then q J(d)=id, J(d) s=d, and every arrow with this beta equation is J(d).
The motive may be an entire finite dependent tail; no global section is an
input. Equalities are of the whole categorical morphisms. The generic module
uses ordinary identity, without K, and separate object/hom universe levels.

`SemanticBridge.SheafDisplayIdentityElimination` constructs the needed inputs
from the existing sheaf self-pullback and sheaf equalizer for an arbitrary
small site and actual sheaf display. Sheafhood, the limit maps and their
universal properties come from those previously constructed operations. The
result is an actual identity object, reflexivity, retraction and arbitrary-
motive eliminator in that category, not a record assuming J or gluing.
Set-valued sheaves and the displayed small function-extensionality parameter
are the precise scope.

`Intensional.PullbackIdentityMaps` takes a commuting map of two displays. The
map between their self-pullbacks is its constructed pullback lift. Equalizer
factorization then constructs the map between their identity contexts. Both
projection squares and the reflexivity square are proved from the limit
triangles and monicity. Consequently the inverse square is derived, not a
stability premise. For an arbitrary, possibly noninvertible motive map m with
the actual branch square, the construction proves

    m J(d') = J(d) identityMap.

`Intensional.PullbackIdentityCoherence` proves that the constructed identity
map is the identity for an identity display map, and that it respects composition
of display maps. The proof uses uniqueness from agreement after reflexivity,
not equality of arbitrary choices of limit fillers. The sheaf adapter
`SheafDisplayIdentityMaps` instantiates these constructions and laws with the
same actual sheaf limit objects. No supplied identity-comparison or
J-preservation field is accepted as a substitute.

The remaining comparison is to the original category-of-elements families,
their comprehension and simultaneous substitution, and their specific identity
constructor. The older `DependentSheafIdentityElimination` and endpoint queue
retain their own pending status. The new display construction alone does not
admit the native Agda source language, supply semantic universes, or validate
higher groupoid-valued identity types.


## Recovering an actual family from its display fibers

`DependentFamilyDisplayRecovery` constructs the missing converse at the level
of families on the category of elements. For an actual presheaf family A over
Gamma, let p:T(A)->Gamma be its constructed total-space projection and let
F(p) be the already constructed presheaf of fibers of p. There is a natural
isomorphism A -> F(p), with inverse, in the existing category of families.

The construction does not assume a family equivalence or choose representatives.
The existing display-fiber construction gives an isomorphism T(F(p)) <-> T(A)
whose maps are include and erase, with both display triangles. The existing
`DependentFamilyTotalMaps` hom comparison converts these display-commuting maps
into actual family natural transformations `encode` and `decode`. Its inverse
laws show that their total maps are precisely include and erase. Faithfulness
of the same comparison, together with preservation of identity and composition
by totalization, proves both whole-transformation inverse laws. The explicit
component equation is

    encode_(X,x)(a) = ((x,a), refl).

The component proof must not apply ordinary `cong snd` to equality in a
dependent total space. Erase to equality of the original total values, then
use the fiber's proposition-valued condition and fiber extensionality. This
neither assumes the dependent second projection is an ordinary function nor
invokes K. The maps are opaque outside their explicit computation lemmas;
this proof-engineering choice adds no axiom or computation principle.

`PresheafDisplayMaps` constructs the fiber map of every actual commuting
triangle f:E->E' over Gamma, from the triangle equation p' f=p. On a fiber
it sends (e,q) to (f(e), triangle(e) followed by q). Naturality is proved using
f's naturality and the propositionhood of the fiber condition. Both total
squares, with erase and include, are proved; identity and composition are
also preserved. No invertibility of f is required.

`DependentFamilyDisplayNaturality` proves the recovery comparisons commute
with arbitrary family maps u:A->B, as equations of whole natural
transformations:

    F(T(u)) encode_A = encode_B u,
    decode_B F(T(u)) = u decode_A.

Together with the existing hom comparison, the actual slice construction in
`Intensional.SliceCategory` and `PresheafFamilyDisplayFunctors` now give
functors T:Families(Gamma)->Presheaves/Gamma and F in the reverse direction.
T is fully faithful with an explicit inverse on each hom type. Slice arrows
retain the commuting triangle; its proof is irrelevant only because the
underlying category has set-valued homs. The recovery is the unit of these two actual functors.
`PresheafFamilyDisplayUnit` proves its naturality as equality of entire
family transformations. The separately defined counit is the actual
erase/include comparison in the slice; its proof uses the previously proved
total-space inverse laws and proof irrelevance only for commuting triangles.
`PresheafFamilyDisplayCounit` constructs that natural counit, with both
inverse laws. `PresheafFamilyDisplayEquivalence` proves the two adjoint
triangle identities for those exact maps. The total triangle follows by
erasing the displayed component of `encode-point`; the fiber triangle uses
the same component equation and the propositionhood of its endpoint condition.
These are equations of complete slice arrows and family transformations.
Together the actual functors, natural unit/counit and these triangles give
the full categorical equivalence for this small set-valued presheaf model.
No equality of large family objects, univalence or strictification is assumed.

### Actual substitution, not an unrelated fiberwise equivalence

`PresheafDisplayBaseChange` uses the existing pullback implementation. Given
p:E->Gamma and sigma:Delta->Gamma, write Q=E x_Gamma Delta and q:Q->Delta.
The comparison between sigma*F(p) and F(q) is computed on elements by

    (e, p(e)=sigma(d)) |-> (((e,d), p(e)=sigma(d)), refl).

The inverse keeps the E component and transports the endpoint equation using
the stored equation that the Delta component is d. Both family inverse laws
are proved as natural-transformation equalities. The total comparison is

    (d, (e, p(e)=sigma(d))) |-> ((e,d), p(e)=sigma(d)),

with its explicit reconstruction. It is an isomorphism onto the actual
chosen pullback and commutes with both projections, not merely an isomorphism
onto some object of the same cardinality.

`PresheafDisplayBaseChangeNaturality` constructs the pullback map of a
commuting display map f by the existing pullback universal property. It
proves forward, inverse and total-space naturality squares with the two
change-of-base comparisons. The map sigma, the displayed map f, and the
families are arbitrary; no global representatives, inhabited fibers, or
invertibility hypotheses are introduced.

### The recovery and term substitution squares

`DependentFamilyDisplaySubstitution` connects recovery of a family to the
chosen comprehension/reindexing comparison, rather than merely proving a
separate base-change isomorphism for display fibers. Let A be a family on
Gamma, sigma:Delta->Gamma, and c:T(sigma*A)->T(A) x_Gamma Delta the existing
`DependentPresheafReindex` comparison. With eta denoting the constructed
recovery unit and b the constructed display-fiber base change, it proves

    b (sigma*eta_A) = F(c) eta_(sigma*A).

This is equality of whole family natural transformations. Componentwise the
left route is `(((sigma(d),a),d),refl),refl`; the right route has the same
underlying pullback point. Its two equality certificates agree by the actual
set-valued fiber condition, not by assuming that different pullback objects
are definitionally identical. The inverse equation is proved using the
already established inverse laws:

    (sigma*eta_A^-1) b^-1 F(c) = eta_(sigma*A)^-1.

The source `DependentFamilyDisplayTermSubstitution` then lifts this square to
the existing certified `DependentPresheafSections.Term` and its existing
`substitute` operation. It does not introduce a different representation of
terms to make the equation easy. The existing family-map action on terms has
proved identity/composition laws, and commutes with actual substitution.
Applying these laws and the preceding family square gives

    map(b) (substitute(sigma, map(eta_A, t)))
      = map(F(c)) (map(eta_(sigma*A), substitute(sigma,t))).

Each side is a complete term, including its section equation, in the fiber
family of the same actual pullback. A whole-transformation equality induces
a whole-term equality; no choice of equality witnesses or global
representatives is used. The same existing term-map construction carries
eta and its inverse to both inverses of a term equivalence. The construction
is written against the real term implementation. Its complete gate exhausted
the configured heap and remains pending; the applicable diagnostic is in
the current work note and raw evidence. The accepted family square and generic
term-map laws do not accept this target. It remains a comparison in a set-valued model, not a soundness
theorem for a source calculus or an identification of its identity eliminator.

`SheafFamilyDisplayRecovery` inverts the existing comparison isomorphism at
explicit original and encoded sheaf endpoints. The resulting four projections
are the actual inclusion, erasure and their two existing inverse equations.
Its transparent FamilyMap.lift states total-map conversion for arbitrary
sheaf-family variables before specializing to Original.encode and
Original.decode. It therefore retains the actual totalized maps.

For each of the two comparison equations, project the accepted whole-map
encode-total or decode-total equality to components in its original presheaf
carrier, then apply nat-ext at the stated sheaf carriers. The output remains
equality of complete natural transformations with the original endpoints;
only the abstract equality proof term changes. The two sheafhood certificates
are retained separately, with no equality of certificates or large family
records, extra model premise or universe enlargement. The Along module and
its arbitrary-map naturality exports are unchanged. This received revision
has passed its own complete native gate in the current continuation; the old
source's heap-exhaustion receipt does not apply to it.

The sheaf specialization `SheafFamilyDisplayComparison` uses the independently
constructed total sheafhood, sheaf pullbacks, and display-family certificates.
Its source avoids asserting equality of large sheafhood certificates and
compares the actual arrows. Its complete native target has passed after the
intended Context child-module export was made explicit with the module selector.
The actual base-change family/total isomorphisms and all three arbitrary-map
naturality squares are retained. This
and the presheaf results concern the set-valued model with the displayed small
function-extensionality parameter. Identifying the two actual identity
contexts, higher identity semantics, and native source admission are further
obligations; the older nested-family identity queue is not accepted by these
results alone.


## Comparing the two identity equalizers

The family/display equivalence does not automatically identify the identity
constructor already used by the nested-family implementation.
`Intensional.SectionEqualizerComparison` constructs the following intermediate
comparison from ordinary categorical limits and joint monicity. In a category let
p:K->D and v:K->B be jointly monic, and let s,t:D->K be sections of p.
For every k:W->D, the two conditions

    s k = t k                 and                 (v s) k = (v t) k

are equivalent. The forward implication is postcomposition by v. For the
reverse implication, p(s k)=k=p(t k) follows from the two section equations;
joint monicity then gives equality of the whole K-valued arrows. Importantly,
v is not assumed monic by itself, and the common projection is not forgotten.

Let E be an actual equalizer of s,t and F an actual equalizer of v s,v t.
Factor E's inclusion through F using the forward implication, and factor
F's inclusion through E using the reverse implication. Both factors commute
with the original D-projections. Monicity of the equalizer inclusions and
these triangles prove both inverse laws, giving an actual isomorphism E<->F.
For any k and supplied section-equality equation, the forward map sends its
chosen E-factor to its chosen F-factor: compose with F's inclusion and use
uniqueness. The reverse factor comparison is proved too. The module's `Rename`
construction retargets an existing equalizer along proved equalities of its
parallel arrows, keeping its object and inclusion rather than silently
choosing an unrelated limit. Thus reflexivity, when supplied by the actual diagonal factor,
is preserved rather than postulated as an extra comparison field.

For the present source representations the intended specialization is
p=commonDisplay, v=valueMap, s=leftSection and t=rightSection. Their value
composites are the existing first and second endpoints. Joint monicity comes
from the existing reindexed-total pullback comparison, not a new axiom.
Separately, the repeated context is compared with the actual self-pullback of
the original display. Its existing reindexing comparison orders the endpoints
as (second,first), so any subsequent identity comparison must retain the swap
and its equality symmetry explicitly rather than guess the label orientation.
The diagonal itself is unaffected. Combining the projection-preserving
comparisons with the already proved categorical eliminator naturality is the
route to the J comparison. That concrete specialization and source admission
remain distinct proof obligations; the generic equalizer argument alone is
not their acceptance.


Two finite controls separate the hypotheses. In ordinary sets take D=B={0,1},
K=D x B, p=first and v=second. The maps are jointly monic even though v is
not monic: (0,0) and (1,0) have the same v-image. The sections s(x)=(x,x) and
t(x)=(x,0) have equalizer {0}, as do their v-components. Thus replacing the
joint condition by monicity of v would unnecessarily exclude the actual
comprehension pattern. Conversely, the constant maps s(x)=(0,0) and
t(x)=(1,0) have equal v-components everywhere but never agree as K-valued
maps. They are not both sections of p. This rejects dropping the common
section/projection premise merely because the values agree. These are finite
paper controls for the categorical argument, not a new native-check receipt
or a claim about higher identity types.


### Actual identity-family fibers and reflexivity

`DependentSheafIdentityFiberComparison` owns the actual equalizer `E` of the two
certified section maps and the actual family supplied by
`SheafDisplayFamilies.Display` for `E.inclusion`, through certified-term
reflection. That checked owner remains unchanged.
`DependentSheafIdentityReflexivity` now owns the actual reflexivity section,
its certificate and its decoded computation. `DependentSheafIdentityFamilies`
reexports that construction and retains
the original ordinary identity-elimination and whole-term-equivalence bodies.
The literal section is unchanged. Its current certificate is constructed by
comparison with an explicitly generated proposition-family term; no family,
section or equivalence is supplied as a new premise.
The fiber owner has passed its complete native gate. The new reflexivity
constructor and the full public term/equality theorem each have a pending gate.

For `p : Fiber X x`, the outer fiber equation `snd p` says that the base
of the equalizer point `fst p` is `x`. The revised `encode-decode` first uses
`E.value-path` with `sym (snd p)` to compare the equalizer points underlying
`encode (decode p)` and `p`; `D.Built.fiber-path` then gives equality in the
actual displayed fiber. The revised `fiber-prop` uses the same two existing
lemmas with `snd p` followed by `sym (snd q)`. This proves propositionhood
directly from the equalizer's proposition-valued condition and the two
actual fiber equations.

For reflexivity, `Factor` remains the actual equalizer factor of the identity
map, and `section` remains `D.inverse` composed with `Factor.factor`. Write
`d` for the family display, `j` for `D.inverse`, `e` for `E.inclusion`, and
`k` for `Factor.factor`. The current proof constructs an auxiliary certified
term using the actual values `Pair.encode t t X x refl` and the new generic
proposition-family section constructor. The original section's first projection
computes to x: the actual Factor.factor has component (x,refl), the equalizer
inclusion projects x, and D.inverse is the display includeValue. The explicit
section-base theorem proves this before either section certificate is used.

The auxiliary term's component equation gives its first projection as x too.
Sigma-path-prop, with the checked identity fiber-proposition theorem, compares
the two whole total-space components along the path first(original)=x=first(auxiliary).
Natural-map extensionality then yields p:section=fst(auxiliary). The certificate
is `cong (d ∘ -) p` followed by the actual certificate of the auxiliary term.
Its endpoints are d∘section=d∘fst(auxiliary)=id, so it certifies the same
original map. The new proof term is not asserted judgmentally equal to its
predecessor. The private SectionComparison child exposes the comparison
abstractly, retaining the stated computation equations.

The earlier categorical argument remains valid mathematics:
`d (j k) = (d j) k = e k = id`, using reversed associativity,
D.inverse-display-comparison and Factor.triangle. The equivalent slice-category
composition has objects (Γ₀,id), (E.presheaf,E.inclusion), and
(T.extension Γ₀ I.presheafFamily,T.display Γ₀ I.presheafFamily), with arrows
(D.inverse,D.inverse-display-comparison) and (Factor.factor,Factor.triangle).
Slice objects stay at suc ℓ and their arrows at ℓ. The current source no longer
implements its certificate through the former private SectionComposite helper.
No family, monicity or equivalence premise is added, and no arbitrary categorical
monomorphism is identified with a pointwise proposition-valued display.

The literal certified pair now lives in a named child `Certified` as an
abstract `term`. Its `term-construction` theorem proves equality of the whole
term with the exact pair `(section, section-law)`. This is an intentional change
from external judgmental pair reduction to explicit certified computation;
the pair body and section remain, while the certificate proof changes as above. The
existing `value` statement and proof remain outside the child, so they use a
correctly typed term without unfolding its full certificate. The particular
identity equality type is proposition-valued, which proves the decoded
reflexivity equation for that term. The current Public, BaseChange and
ReflexivityCompatibility callers use the term type or the particular
identity-term proposition theorem, not judgmental pair projections; they need
no adapters. Future map projection follows by congruence of `fst` on
`term-construction`; the dependent certificate projection needs transport/J.
This abstraction still requires checking the actual construction and does not
establish any reduction in checking cost.

The generic `DependentPropositionFamilySections` constructor is natively accepted;
this concrete certificate revision remains source-written and pending.
They realize the preceding alternative
plan using the existing DependentPresheafTermSections comparison, actual reflexive
values and derived naturality. Their complete native gates remain separate:
the generic acceptance does not accept the revised concrete specialization.
Term extensionality also compares the original certified pair with the auxiliary
term once the section comparison is available. Neither a desired global section
nor an arbitrary-monomorphism converse is an input. No reduction in checking
cost follows from source review, and the former-source diagnostic does not
apply to the changed certificate proof.

The current owners retain the literal section, the complete reflexivity and
term/equality statements, and the selected facades used by their consumers.
Acceptance and applicable evidence belong to `state.json`; the current gate
is recorded in `docs/work.md`. These constructions still concern small,
set-valued identity families; no higher identity semantics, semantic universe,
or source-language identity eliminator is supplied by this proof revision.


### Moving the endpoint equalizer through the actual pullback comparison

An isomorphism of the ambient contexts need not make their equalizers
identical. For e:D->P with inverse r, and parallel maps f,g:D->B and
f',g':P->B satisfying f'e=f and g'e=g, factor e composed with the
first equalizer's inclusion through the second equalizer. Conversely factor
r composed with the second inclusion through the first. The required
inverse commutation equations follow from e r=identity, not from extra
input fields. Monicity of both inclusions, together with e r=identity and
r e=identity, proves that the two factors are inverse. The comparison is
over the given e, and sends every chosen factor along k to the chosen
factor along e k. In particular it preserves the actual reflexivity factor
when e carries the diagonal to the selected pullback diagonal.

For the repeated-context comparison, the existing reindexing map orders the
self-pullback pair as (second,first). Swapping the parallel arrows of an
equalizer changes the supplied equality to its inverse and uses the same
object and inclusion, so it does not identify equality witnesses by an
unmentioned choice. This is the next concrete adapter after the section/value
equalizer comparison. The argument concerns actual categorical morphisms
and chosen limits; it does not turn a higher identity context into a set.


## Constructed local propositional truncation

`SheafPropositionalTruncation` uses the actual small site's topology J.
For a presheaf F define a sieve S_F(X) by

    S_F(X)(f:Y->X) = mere(F(Y)).

Restriction of F makes this a sieve. Define T_F(X)=Cover_J(S_F(X)).
The topology's explicitly proposition-valued covering predicate makes each
T_F(X) a proposition in the displayed small level. Pullback of a covering
sieve and the pointwise inclusion of that pullback into S_F(Y) define its
restriction maps. Propositionhood proves their identity/composition laws.
The unit sends x:F(X) to the cover obtained from the maximal sieve by
restricting x along every arrow. No decision of inhabitation is involved.

A matching family of T_F-values on a covering sieve R gives, for every
f:Y->X in R, a cover of S_F(Y), hence a cover of the pullback of S_F(X)
along f. The actual local character axiom for J then proves Cover(S_F(X)).
This constructs the sheaf amalgamation. The restriction and uniqueness
laws hold because these values are propositions. It is not the false
assertion that pointwise mere inhabitation is automatically a sheaf.

For a proposition-valued sheaf Q and an actual natural map F->Q, a member
of S_F(X) at f:Y->X supplies mere F(Y). Its image can be eliminated into
Q(Y), producing an actual matching family of Q on the entire support sieve.
Gluing Q along the supplied covering proof constructs T_F(X)->Q(X).
Naturality, beta and uniqueness are equations in the target propositions.
The two operations on complete natural transformations are inverse, so
restriction along the unit gives a Hom equivalence, not merely an existence
assertion. No global or local representatives have been selected.

`SheafTruncationMaps` maps support sieves along arbitrary natural
transformations. The resulting T is an actual functor from small presheaves
to sheaves, its unit is natural, and the unit of a proposition-valued sheaf
is an isomorphism. In particular it is idempotent by constructed inverse maps.
These statements use the same local-inhabitation object, not a replacement
chosen after the desired functor laws are specified.

`DependentSheafTruncation` applies that construction on the existing
category-of-elements site for each sheaf context Gamma. The existing
`ElementSheafComparison` constructs total sheafhood of the resulting family;
its opposite implication makes a supplied proposition-valued family into
the required target element sheaf. Thus the recursor and its Hom equivalence
concern the existing family representation in each context.

`PresheafTruncationBaseChange` constructs the context substitution isomorphism.
For sigma:Delta->Gamma and x in Delta(X), the projected support sieves have
members mere(A(Y,Gamma(f)(sigma x))) and mere(A(Y,sigma(Delta(f)x))).
The naturality equation for sigma transports these ordinary equality-indexed
fibers in both directions inside mere inhabitation. Upward stability of J
therefore transports their covering witnesses. This defines both actual maps
between the reindexed truncation and the truncation of the reindexed family.
Their naturality, inverse laws and unit squares hold in the explicitly
proposition-valued fibers. `PresheafTruncationCoherence` retains those maps
and proves their naturality in arbitrary family maps, identity and composite
parameter changes. The identity and composition equations include the chosen
family-reindexing forward and inverse maps rather than identify presentations
by fiat. No parameter map is required to be an equivalence.

Dependent elimination, higher context semantics and semantic universe closure
remain separate obligations. The Cubical
metatheory supplies mere inhabitation used to build support; this operation
alone does not constitute an interpretation of the ordinary native
BoundedTruncation signature or its larger universe parameters. Native checking
status is the exact source ledger, not these mathematical arguments.


### Relative image and dependent truncation elimination

For a sheaf family A over Gamma, let I=Gamma.T(A) and let
eta:Gamma.A->I be totalization of the constructed truncation point.
The projection I->Gamma is pointwise monic: two of its elements with
equal Gamma coordinates have equal remaining coordinates because the
local-inhabitation fiber is a proposition. This does not assert that
Gamma is a proposition.

For any actual sheaf morphism q:Q->Gamma with proposition-valued fibers,
the actual display/family construction makes its fibers a sheaf family
B over Gamma. A map b:Gamma.A->Q over Gamma determines a family map
A->B directly: at (X,x), send a to (b_X(x,a), over_X(x,a)). Its
naturality equation lies in the explicitly proposition-valued fiber of B,
so that equation follows from the supplied fiber propositionhood. No
global converse from categorical monicity to component fibers is used.
This direct map removes the otherwise unnecessary display-map/recovery
normalization from the relative-image proof. The existing
truncation recursor gives T(A)->B; totalize and erase the fiber encoding
to obtain I->Q. Its projection is I->Gamma and its composite with eta
is b. Any two maps over Gamma into this Q agree pointwise in those
fibers, proving uniqueness and both inverse laws of the complete
Hom-over-Gamma comparison. A factorization is the output, not an input
field. This is the relative image universal property among displays with
explicitly proposition-valued component fibers; the generic categorical
Image record below has a stronger quantifier and is not silently instantiated.

For dependent elimination let M be an actual family over I, with every
fiber a proposition, and let r:I.M->I be its display. The composite
I.M->Gamma again has proposition-valued fibers: equality of the Gamma
coordinate first identifies the two I coordinates by monicity above,
then identifies the two motive values using M's fiber propositionhood.
An actual branch b:Gamma.A->I.M with r b=eta is therefore extended by
the image construction. Monicity of I->Gamma proves r elim=identity_I.
The earlier computation gives elim eta=b. Monicity of r gives uniqueness
of the whole section, not merely its object values. The resulting pair
(elim,section equation) has the existing certified-term representation.

The concrete elimination-map body is kept with its proved section and beta
equations behind an abstraction boundary. Its definition is still constructed
and checked; callers use these equations instead of unfolding the image
recursor. The certified term remains the transparent pair of that map and its
section certificate. Computation below is an equality of full certified terms,
not a promise of public judgmental unfolding of this helper.

The certified source branch is a term of the actual reindexed motive
eta*M on Gamma.A. Its existing comprehension pair gives the map b and its
triangle; apply the constructed extension to obtain eliminateTerm(d).
Restriction is the existing Terms.substitute along eta. Applying the
comprehension pair to that restriction gives elim eta by substitution-pair,
then b by the map beta theorem. Injectivity of the actual comprehension pair
therefore proves certified-beta as equality of full certified terms. Any
term of M is equal to the constructed one by display monicity and term-ext;
this gives certified-unique, certified-eta, and both inverse laws of
termEquivalence. The equation witnesses agree by hom-setness, not by
postulating computation for function extensionality.

For an actual map k:Delta->I, retain the existing sheaf reindexing k*M,
its total-space lift m, and its proved square r m=k r'. The small categorical
section-square lemma proves m s'=s k for any sections s of r and s' of r'.
The existing comprehension pair and substitution-pair then identify the
entire certified s' with Terms.substitute(s,k). Thus the comparison uses
the existing term-substitution operation and actual reindexed family;
neither k nor m is assumed invertible.

For source-family substitution sigma:Delta->Gamma, take A_sigma to be the
existing reindexed sheaf family and r:Delta.A_sigma->Gamma.A its actual
total-space lift. Totalizing the inverse direction of the already constructed
truncation base-change isomorphism gives k:I_sigma->I over sigma. Its
inverse-point-square proves k eta_sigma=eta r as a whole natural-transformation
equation. Pull b r into the actual pullback of the motive display along k;
the existing pullback lift and inverse total/family comparison construct this
pulled branch and both its display and motive-lift triangles. In particular,
the branch is constructed without using either eliminated section.

The whole-map unit square has a small totalization proof. For actual families
A and B over a presheaf Gamma, a map sigma:Delta->Gamma and a family map
alpha:A->B, the actual reindexing lifts satisfy
`lift_B totalMap(alpha[sigma]) = totalMap(alpha) lift_A`.
At (x,a), both components are `(sigma(x), alpha_(sigma(x))(a))`; nat-ext
proves equality of the complete natural transformations. The separate helper
[DependentFamilyTotalNaturality.agda](../src/Orbifolds/SemanticBridge/DependentFamilyTotalNaturality.agda)
states this over symbolic presheaves, without a sheaf, image or section premise.
Its complete native gate and its concrete use in the public eliminator have passed.
For the concrete truncation inverse i and changed point eta', the unit-square
derivation is

```text
(lift_T totalMap(i)) totalMap(eta')
  = lift_T (totalMap(i) totalMap(eta'))
  = lift_T totalMap(i eta')
  = lift_T totalMap(point[sigma])
  = totalMap(point) lift_A.
```

The middle equality uses the actual inverse-point-square, and the final
equality is this naturality theorem. AcrossBase.toOver unfolds to the displayed
whole composite, so the proof preserves the existing imageMap, changedUnit,
unit and sourceMap rather than replacing them by new operations.

There is also a paper cancellation consequence of the existing over-base
triangles. Write q=imageDisplay, p=originalDisplay and use primes for the
changed context. The actual equations q eta=p, q' eta'=p', p r=sigma p'
and q k=sigma q' give
`q (k eta') = (q k) eta' = (sigma q') eta' = sigma (q' eta')
= sigma p' = p r = (q eta) r = q (eta r)`.
The already constructed categorical monicity of q cancels this equality.
This needs neither monicity of q' nor a converse from categorical monicity
to fiber propositionhood. The accepted public source keeps its existing
total-map proof; this independently reviewed consequence is not a new native gate.

The two projection triangles also have a small categorical derivation. For
an actual isomorphism e:E≅Q, maps p:E->B and q:Q->B with q e=p, and a
chosen cone c:K->Q satisfying q c=u, the existing slice inverse-square gives
p e^-1=q. Associativity and composition of that equality with c give
`p (e^-1 c) = (p e^-1) c = q c = u`.
For the actual motive reindexing comparison, use its comparison-display
triangle and the pullback lift-second equation for one projection; use
comparison-value and lift-first for the other. This retains the actual cone,
comparison inverse and independently pulled branch. It adds no extension,
section or model premise. This is a mathematical factoring of the two
triangles, not evidence of a compiler hotspot or a measured speed improvement.

The entire source-change argument also has a symbolic statement: take two
instances of the exact RelativeSheafImageTerms.On.Over data, including their
actual original/image sheaves, displays, units, component injection, categorical
monicity and restricted explicit-Σ recursors. Given source maps r and k with
`k eta' = eta r`, the preceding motive pullback, independent branch, read/pair
law and certified substitution construction go through over these symbolic
data. No map between the two ambient bases or separate over-base equation for
k is needed by this argument. Those belong to constructing r, k and their
unit square in the concrete truncation instance.

This complete proof boundary is now source-written in
[RelativeSheafImageTermSubstitution.agda](../src/Orbifolds/SemanticBridge/RelativeSheafImageTermSubstitution.agda),
which owns the whole Motive subtree and the inverse-cone lemma. The concrete
public module retains its actual data, maps and unit-square, then specializes
and reexports that subtree. Both recursors are the existing Image.Into.extend
at the actual contexts, with the identical image-law arguments used by Core.
Core already specializes the same general term theorem, so these references
retain the same underlying term, pair, read and elimination operations without
a new concrete premise or comparison of different extension witnesses. The
written factoring has received independent source review, and the complete
general theorem passed its native gate with stable sources, matching copies
and its target Finished marker. The complete concrete public gate has also
passed with those checks, including its actual unit-square and specialization.
The two applicable receipts remain separate; no timing improvement is claimed.

Apply the new eliminator to that branch. The preceding section-square and
pair-injectivity prove that its certified term is the existing
Terms.substitute of the original eliminated term. The source certified-branch
operation is constructed by the same pullback followed by comprehension read;
its pair-read equation retains the actual pulled map. The full operation law
is eliminateTerm-substitution, not just an objectwise existence or a square
whose comparison maps are assumed. The construction does not assert
judgmental strictness for repeated comprehension or interpret the native
source universe signature.
The concrete sources' native checking status is owned by the exact ledger;
the independently checked categorical consequence below does not promote them.

#### Repeated source substitution: comparison boundary

The following is a paper consequence of the existing operations, not a newly
checked coherence module. For two successive actual source substitutions,
write k:I1->I0 and l:I2->I1 for their image maps, and e0,e1,e2 for the actual
eliminated certified terms. The single-step laws give
`p_sigma : e1 = sub_k(e0)` and `p_tau : e2 = sub_l(e1)`. Let KL be
`DependentTermSubstitutionLaws.Composite I0 I1 I2 M k l`. Its Compare.map
uses the explicit family comparison from `(k l)*M` to `l*(k*M)`, and its
law has orientation

    KL.Compare.map (sub_(k l)(e0)) = sub_l(sub_k(e0)).

Consequently the full certified-term image-chain law has proof
`p_tau . cong(sub_l)(p_sigma) . sym(KL.law e0)`. Both endpoints are in the
actual twice-reindexed motive over I2; neither reindexed-family equality nor
judgmental equality of distinct presentations is asserted.

The direct source family A_(sigma tau) has its own actual image Id.
The adapter comparing it with the twice-reindexed image I2 remains unbuilt.
Let AComp be the existing source-family composite comparison. Its inverse
maps the twice-reindexed family to the directly reindexed one. Apply the
actual truncation map from `PresheafTruncationCoherence.Context.map`, then
the existing fixed-base totalMap, to construct h:I2->Id in that direction.
The display triangle comes from `FixedBase.toOver`. Together with the three
actual imageMap-over equations, it gives
`e : kd h = k l` by the original image display's constructed categorical
monicity. This uses monicity to compare maps; no converse to fiber
propositionhood or model premise is needed.

For the direct eliminated term eDirect, set DH to the term-substitution
Composite module for kd and h. Its existing Compare uses the forward family
arrow. The required reverse map must instead be the actual
`DependentTermTransport.AlongFamily I2 DH.I.twice DH.I.once DH.I.inverse`,
called ReverseDH. Put

    comparedDirect = KL.Compare.map
      (subst (q -> Term I2 (reindex M q)) e
        (ReverseDH.map (sub_h(eDirect)))).

The substitution along h, reverse family map, forward transport along e,
and KL's forward family map place this whole term in the same actual motive
as e2. `certified-unique d2 comparedDirect` then gives `comparedDirect=e2`;
take its symmetry for the desired `e2=comparedDirect`. Source identity
likewise needs the actual image map obtained by totalizing the truncation
of the forward source-family identity comparison. Its display triangle identifies
it with the Public identity image map by image monicity. Identity and
composite term laws apply with these explicit comparisons; they do not
identify A[id] with A or their image sheaves judgmentally. The concrete
identity/composite adapter and its native gate remain separate work.

#### Section construction and certified-term laws

`SheafTruncationSections` and `MonicPresheafSectionTerms` separate the following
two proof layers. The Sections module reexports the actual bundled extension
from its single canonical body in `SheafTruncationExtension`; its arbitrary-target
section construction remains a separate layer. Native acceptance is owned only by the ledger.
The section module keeps the actual image I and unit eta of Gamma.A, but takes
an arbitrary sheaf Q, a map p:Q->I, and explicit
component injection: p_X(a)=p_X(b) implies a=b. For a branch b:Gamma.A->Q with
p b=eta, the composite q=(I->Gamma) p has proposition-valued component fibers
by that injection, image-monic, and setness of Gamma's values. The existing
concrete image extension then supplies elim:I->Q and its over-Gamma and beta
equations. The symbolic-q layer packages them as one dependent pair: its first
field is `Image.Into.extend (b,over)`, an actual member of Over(I,i); its second
field is the existing `Branch.beta b over`, since the first projection of
`extend (b,over)` reduces to the identical `Branch.eliminate b over`. The map,
over-base equation and beta equation are projections of this single abstract
constructed result. `section-from-over` applies to this particular extension;
component injection gives the categorical cancellation needed for section
uniqueness. No full Image record, arbitrary-mono classification, or section
existence premise is added.

There is a smaller interface sufficient for the concrete motive construction.
Once its actual extension s has been proved to be a section of the monic
motive display p, beta follows by cancellation alone. For the existing branch
b with p b=u, the categorical chain is
`p (s u) = (p s) u = id u = u = p b`, hence `s u=b` by monicity of p.
Thus this particular dependent eliminator can consume only the constructed
over-base extension and its over equation, derive its section law by
`section-from-over`, and derive computation from that section law. This is a
propositional beta equation, with the same branch and unit; it does not assert
judgmental computation or supply a section as an input. The current
`RelativeSheafImageSections` owns the complete generic section theorem.
Its named child packages one actual extension with its section and over-base
equations in an abstract result; the public maps and certificates are
projections of that same result. The categorical proof is organized over
symbolic sheaves and maps. Its recursor is restricted to sheaf displays with
explicit proposition-valued component fibers; it supplies only an over-base
map and triangle. The recursor's domain and codomain are explicit presheaf
pairs `Σ (Nat Y Q₀) (λ h → compose-nat q h ≡ d)`, matching `Image.Into.Over`.
The local `chosen` retains its categorical `Monic.Branch` type, so that
conversion is checked over the symbolic data. The concrete Context fills
that parameter with the existing
`Image.Into.extend`, using the actual image, original display, unit triangle,
component injection and categorical monicity. No new parameter appears in the
concrete Context/Motive/Branch interface. In particular, the sole chosen
extension still specializes to the original `Image.Into.extend` application,
and `section-from-over` uses only that extension's map and triangle. Section,
beta and uniqueness are outputs, not recursor fields.
`DependentSheafTruncationConstruction` is the actual Image specialization of
this theorem, retaining its existing Context/Motive/Branch interface and the
generic Over export. The generic proof and concrete specialization have
separate full native gates; accepting the conditional generic theorem does
not accept the concrete specialization. All generic proof bodies, including
the direct categorical beta proof, remain unchanged and have one source owner.

`MonicPresheafDisplays` now states the display arguments over symbolic
presheaves I and Gamma and an actual family M over I. Propositionhood of M's
fibers gives component injection of its total-space display p; presheaf
extensionality then gives categorical monicity of p. For an explicitly
component-injective q:I->Gamma, a pair of points of a fiber of q p first gives
equality of their images under p, then equality of their total-space points.
The existing display `fiber-path` supplies equality of the whole fiber points.
The same helper proves the section-beta cancellation above for a supplied
section and compatible branch. `SheafTruncationMotive` proves the first three
facts for symbolic sheaves I and Gamma, a component-injective map i, and an
actual sheaf motive M over I, independently of any branch. Its bodies apply
`Σ-path-prop`, display `fiber-path` and `nat-ext` directly, with explicit
total-space points and natural-transformation endpoints. Its concrete Context
supplies the actual sheaf image, image display and checked component injection,
and reexports the resulting Motive module without a second concrete proof
telescope. The original Context/Motive interface is retained. It owns
the actual total, display and composite and the explicit proposition
hypothesis required by the image recursor. Construction reexports that data
and uses its existing categorical motive monicity directly for the section's
branch computation: cancel p from `p(s u) = (p s)u = id u = u = p b`.
Thus it does not re-instantiate the separate total-display presentation to
reconstruct monicity. The base-map
input is component injection, not a converse from arbitrary categorical
monicity. No operation producing sections
is an input. This factoring is not a measured elaboration-cost diagnosis;
native acceptance belongs to the ledger.

The optional arbitrary-target Sections layer exposes eliminate, section, beta
and unique abstractly from one helper instance.
A concrete family specialization takes Q=I.M and p as the existing display,
deriving component injection from M's explicit proposition-valued fibers.
All four wrappers must use the same Q, p and injection witness. In particular,
do not combine a helper beta with a separately reconstructed image extension
using another abstract fiber-proposition witness; no equality between those
proof witnesses is required. This boundary separates the extension proof from
the concrete total-family representation without changing its equations.

The separate certified-term proof layer uses arbitrary presheaves I,S, an actual family
M over I and u:S->I. It retains the existing Terms.Term, reindexing, pair, read
and substitute operations. Given one actual term s of M and a term d of u*M,
the equation fst(s) u=pair(d) implies substitute(s,u)=d by substitution-pair
and pair-injective. Monicity of M's actual display gives equality of any two
certified sections by term-ext. For arbitrary k:D->I, use the existing lift
and display square in section-square, then pair-injective and substitution-pair
to identify each section of k*M with substitute(s,k). These are lemmas about
supplied sections, not an assumed operation producing extensions. The concrete
caller still constructs eliminateTerm; its certified beta, uniqueness, eta and
both inverse laws follow from these lemmas. The source-family substitution
construction retains its independently pulled branch and actual read/pair law.
Selected declarations and one canonical generic proof body per lemma keep the
two interfaces small. `DependentSheafTruncationConstruction` contains the actual
particular-image extension, section, beta and uniqueness, with the identical
local fiber-proposition/branch-over witnesses. `RelativeSheafImageTerms` owns
the complete certified-term theorem over symbolic original and image sheaves.
It instantiates the accepted generic section construction with the same
restricted recursor. Monicity and term-ext identify complete sections;
substitution-pair and sourcePair-injective give certified computation for the
constructed section. The original context remains an actual sheaf so that branchMotive is
the existing sheaf-family reindexing, not a replacement presheaf operation.
Core specializes this entire theorem to the actual Image data and
`Image.Into.extend`, retaining the Context/Motive/Branch hierarchy and its
unchanged concrete parameters. Its motive-restriction square applies
MonicImageElimination.section-square directly to the actual total objects,
displays, lift and lift-square. The existing pair injection and substitution-pair
equation then compare the complete certified terms. This keeps those actual
sheaf endpoints in the categorical application; it requires no separately
assumed comparison of the two lift presentations. The term equivalence retains
both inverse laws and all operations retain their original definitions.
The optional arbitrary-target section helper is not a dependency.
The construction, generic term theorem, Core and full public substitution
target each need their own complete gate. This organization alone establishes
neither faster elaboration nor native acceptance of any target.


### Categorical elimination and actual pullback stability

`Intensional.MonicImageElimination` is an ordinary without-K theorem in the
existing category interface. An image factorization A --u--> I --i--> Gamma
is supplied with monic i, its triangle, and the universal factor map into
subobjects of Gamma, including its two equations. No dependent section or
eliminator is an input. This is a theorem ABOUT such a factorization, not a
construction of a new sheaf model or a claim that every arrow has an image.

Let p:M->I be monic and let b:A->M satisfy p b=u. The composite i p is
monic. Apply the image property to obtain s:I->M with (i p)s=i and s u=b.
Cancellation of i yields p s=id. Cancellation of p proves uniqueness among
all sections of p. Restriction s |-> s u and the constructed extension are
inverse on the full sigma types of arrows with their projection equations.
Hom-setness justifies equality of those equation witnesses; no univalence,
choice, or function extensionality beyond the category interface is added.
The exported `section-branch-equivalence` includes both inverse laws.

For p':M'->I', k:I'->I and m:M'->M with p m=k p', any sections s and s'
satisfy m s'=s k, by cancellation of p. This is the whole-arrow equation
`section-square`, not objectwise agreement or a requirement that m or k
be invertible. It needs no branch matching premise: once both sections
exist, the target's proposition-valued fibers force this equation. That
observation must NOT be generalized to motives with nontrivial fibers.

For a specified actual pullback of k and p, its first projection is proved
monic using the pullback's two projections, square, and joint uniqueness.
The cone (id,s k) constructs the reindexed section. `substitution-square`
is the second pullback triangle, and `unique` compares any other section
with this constructed one. The pullback and its universal property are
explicit input geometry, not assumed substitution preservation. The result
can therefore compare independently constructed eliminators after their
actual concrete pullback data and section laws have been supplied.

At the adapter boundary, the generic Image property quantifies over
categorically monic arrows, while the direct sheaf extension takes explicit
proposition-valued component fibers. These are distinct hypotheses until a
conversion is proved. For the intended motive composite its pointwise
fiber propositionhood is already available. The smaller exported lemma
`section-from-over` takes just the particular extension and its over-Gamma
equation, so the concrete adapter can use it without proving a global
classification of categorical monomorphisms. Pointwise monicity gives
categorical monicity by natural-transformation extensionality. The separate
concrete self-pullback argument below supplies the converse for this actual
sheaf category, without making the dependent eliminator rely on it.
Native source admission, bounded universe
interpretation, and arbitrary higher motives remain separate obligations.

### The categorical image is constructed using the actual self-pullback

`SheafTruncationCategoricalImage` uses the independently constructed sheaf
pullback of q:Q->Gamma with itself. Its projections p1,p2 are actual natural
transformations, and its sheafhood and equation q p1=q p2 are proved by
`SheafPullbackConstruction`. If q is categorically monic, cancellation gives
p1=p2 as whole natural transformations. At X, the pullback has the explicit
value ((a,b),e) for every e:q_X(a)=q_X(b). Evaluating p1=p2 at this value
proves a=b. For elements (a,p),(b,r) in the fiber over x, apply this result
to p followed by the inverse of r; setness of Gamma(X) then identifies the
remaining equality certificates. This proves the required fiber propositionhood.

The test object in cancellation is the constructed self-pullback sheaf itself.
No representable is presumed to be a sheaf, and no sheafification,
subcanonicality or additional test-object hypothesis is used. Pullback values
and all component fibers remain at level ell; objects of the sheaf category
are at suc ell and its hom types at ell. The argument only converts monicity
into the needed small fiber witnesses. It does not assert an equivalence of
monicity proof-witness types or assume function extensionality at the larger
object level.

For Gamma.A->Gamma, the adapter now assembles the categorical Image record:
the object, unit and inclusion are the existing local-inhabitation total,
point and display; the triangle and monicity are the concrete proved laws.
For an arbitrary categorical monic q, the self-pullback conversion supplies
the explicit fiber propositionhood to the already constructed extension.
Its over-Gamma and beta equations fill the remaining fields. Thus the full
categorical Image is an output of actual sheaf operations, never an extra
model assumption or a field asserting the desired conclusion. Its native
acceptance is a separate gate because the particular-extension eliminator
deliberately does not import this adapter.

### A native local-versus-pointwise control

`SheafTruncationControl` constructs a two-object category patch->base,
with only identities and that arrow. A sieve on X covers exactly when
it contains the unique map patch->X. The supplied category and topology
laws are proved, not fields assumed by the example. The presheaf F is
Unit on patch and empty on base. It is a presheaf, not a sheaf.
Its support covers base because F(patch) is inhabited, so the constructed
T_F(base) is inhabited. Pointwise mere F(base) is nevertheless empty.
The matching family on that support has a value at every permitted
local arrow; an assumed sheaf amalgamation for the pointwise-truncated
presheaf would produce mere F(base), a contradiction. A fresh completed native check now supports this concrete control; its
source is unchanged from 041. It rejects treating pointwise truncation of
an arbitrary presheaf as a sheaf. It does not pretend to be a smooth
manifold example or a nontrivial torsor, nor assert that F itself is a sheaf.
