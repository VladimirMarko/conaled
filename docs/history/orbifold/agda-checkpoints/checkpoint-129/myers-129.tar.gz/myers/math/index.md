# Mathematics and paper correspondence

This directory owns the mathematical arguments and designs. It consolidates the
supplied notes by subject; old runtime reports and serial continuation notes are
not mathematical sources of truth. Individual statements retain their explicit
hypotheses and bounded scope. Some are paper proofs or pending designs, not Agda
acceptance or a mechanized model.

The single [paper map](paper-map.json) combines all 199 numbered environments,
selected declaration anchors, result scopes, compactness interfaces, 17 detailed
scope cases and 49 bounded nonresult reviews. It includes corrections and missing
concrete definitions. A scoped correspondence classification is not proof status;
canonical signatures are in `../src/`, and `../state.json` is the only current
accepted/pending ledger. Negative search findings remain bounded-review findings.

| Subject | Content |
| --- | --- |
| [Foundations](foundations.md) | Crisp/modal rules, explicit ambient premises and their boundaries |
| [Coherent diagrams](coherent-diagrams.md) | Bar constructions, graph and coherent limits/colimits |
| [Tiny colimits](tiny-colimits.md) | Tiny preservation and its actual comparison/coherence maps |
| [Differential geometry](differential-geometry.md) | Weil algebra, tangent constructions and synthetic calculus |
| [Properness](properness.md) | Internal and external properness, diagonal obstruction and finite fibers |
| [Manifolds](manifolds.md) | Penon/crystalline disks, geometric assumptions and local consequences |
| [Finite presentations](finite-presentations.md) | Finite branch atlases, completion and Morita comparisons |
| [Torsors](torsors.md) | Torsor identities, extension, tensor bundles and quotients |
| [Coverings](coverings.md) | Finite/configuration coverings and shape comparisons |
| [Integral affine](integral-affine.md) | Integral lattices, affine actions and crystallographic geometry |
| [Complex lattices](complex-lattices.md) | Complex-line lattices, bases, finite-free rank and identities |
| [Elliptic moduli](elliptic-moduli.md) | Actual chart/fiber/quotient/shape constructions and rank boundary |
| [Torus](torus.md) | Torus translations, products, compactness and split extension |
| [Corrections](corrections.md) | Printed statements, corrected formulations and counterexamples |
| [External models](external-models.md) | Candidate-site interpretations and specific model obstructions |
| [Source interpretation](source-interpretation.md) | Bounded ordinary language, universes and interpretation scope |
| [Topological bridge](topological-bridge.md) | Open-domain, local-homeomorphism and smooth-branch interfaces |
| [Scalar extension](scalar-extension.md) | Tensor algebra and actual first-order Weil diagrams |
| [Presheaves](presheaves.md) | Ordinary presheaves/sheaves, adjunctions and overlap counterexample |
| [Real analysis](real-analysis.md) | Constructed Dedekind arithmetic, metric, topology and completeness |
| [Real sheaves](real-sheaves.md) | Real-open site, calculus, dependent families and constants |
| [Joint obstruction](joint-obstruction.md) | Conditional incompatibility of the exact native joint signature |
| [Constructive transfer](constructive-transfer.md) | Constructive reuse strategies and selector/coherence boundaries |
| [Descent](descent.md) | Constructed cocycle torsors, topological charts and gauge descent; remaining higher/smooth scope |
| [Conaled](conaled.md) | Single outward-facing handoff and external interface boundary |

The conaled/Mathlib files in `../references/` are selected upstream sources, not a
second project implementation or a complete Lean build. Exact pins live only in
`../environment.json`. Current priorities and unresolved checking attempts are in
`../docs/work.md`; setup and packaging instructions do not belong in these notes.
