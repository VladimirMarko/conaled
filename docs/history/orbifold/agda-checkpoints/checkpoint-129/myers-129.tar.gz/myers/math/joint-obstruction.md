# Joint obstruction

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="weil-tiny-incompatibility"></a>

## A checked incompatibility for the displayed joint foundation

Interpretation of the literal native crisp/Cubical signature in the paper’s intended foundation is an independent obligation.

### Precise conclusion

`WeilFullPostulateIncompatibility.Context.incompatible` inhabits the empty
type from five ordinary inputs: the existing strict-order laws, crystalline
preservation of crisp pullbacks, `RealFlat`, Kock–Lawvere reflexivity, and the
existing tininess signature for all crisp Weil spectra. Its surrounding
context contains a crisp universe level, a crisp commutative ring, a crisp
Kock-field witness, and the explicit crisp identity-induction rule with its
propositional computation law.

The proof in `WeilTinyShapeIncompatibility` and `WeilFullPostulateIncompatibility` constructs the algebra and the invariant used by
the contradiction. Those data are not extra hypotheses of the final theorem.

This is an incompatibility theorem for this literal formal signature. It is
not an unconditional inconsistency of Agda, nor a theorem excluding every
model of synthetic differential geometry or every classical orbifold
interpretation. A sound, nondegenerate model interpreting this exact signature
and its operations cannot realize all of these inputs simultaneously. Applying
that observation to another source language still requires its interpretation.

### The algebra is constructed

Over the arbitrary commutative ring in the crisp context, the development
constructs

\[
W_R=R[x,y]/\bigl((x,y)^7,\ x^3+y^4,\ x^4+y^5\bigr).
\]

It proves a normal-form equivalence with the free rank-15 module having basis

\[
1,y,y^2,y^3,y^4,y^5,y^6,
x,xy,xy^2,xy^3,
x^2,x^2y,x^2y^2,x^2y^3.
\]

The proof includes the coordinate multiplication, commutative-algebra laws,
the actual polynomial quotient and its generator relations, realization and
normalization with both inverse laws, and the augmentation. The augmentation
kernel has explicit finite generators, and every product of seven kernel
elements vanishes. These supply the actual Weil-algebra fields used later.
The code does not obtain its result by assuming a record containing the
desired normal form or algebra equivalence.

For an arbitrary algebra endomorphism, write the images of the generators
with constants \(\alpha,\beta\) and linear coefficients \(a,b,c,d\). Under
units of 3, 4, and \(D=ad-bc\), the development proves

\[
\alpha=\beta=0,\qquad a=d=1,\qquad b=c=0.
\]

The vanishing of the generator constants is proved here; it is not assumed.
Two actual quotient rings, by
\(I=(\alpha,\beta)\) and by \(I^2\), control the constants. The first
quotient supplies the linear congruences; coefficient calculations in the
second give \(\alpha,\beta\in I^2\). An explicit finite geometric-inverse
argument and the two-generator nilpotence calculation then collapse \(I\).
The result constrains constants and the linear coefficient matrix. It does
not assert that all higher coefficients vanish or that the entire
endomorphism is the identity.

### From algebra to a separator of all spectrum endomorphisms

Let \(T=\operatorname{Spec}(W_R)\). Kock–Lawvere reflexivity reconstructs an
ordinary algebra homomorphism from every internal function \(T\to T\).
Applying the proved coefficient invariant produces

\[
D:(T\to T)\longrightarrow R.
\]

The reconstruction laws prove that \(D\) is zero on the constant-origin
function and one on the identity. The rigidity theorem proves, for every
endomorphism \(f\), that invertibility of \(D(f)\) implies \(D(f)=1\).
Neither invertibility of every endomorphism nor preservation of augmentation
is assumed.

The constructive Boolean separator uses the Kock-field cover by invertibility
of \(z\) or of \(1-z\). For a unit-rigid \(z\), these alternatives are
disjoint: if \(z\) is a unit, it equals one, so \(1-z\) cannot be a unit.
Each alternative is proposition-valued, making their disjoint sum a
proposition. Propositional truncation therefore eliminates into that sum
without a choice axiom. Its tag defines the actual Boolean map. At the
constant-origin and identity functions, the tags are respectively false and
true.

This argument does not assert the stronger pointwise dichotomy
\(D(f)=0\) or \(D(f)=1\). A nonunit may retain infinitesimal information.
The proved unit-cover separator is sufficient.

### Why the modal hypotheses force the opposite conclusion

The actual finite polynomial presentation yields a crisp pointed presentation
of \(T\). Crystalline preservation of crisp pullbacks then gives its
crystalline connectedness, and hence its shape connectedness.

The rank-15 coordinate equivalence, reflexivity, tininess of \(T\), real
cohesion, and the proved target-relative nullification comparison imply shape
connectedness of \(T\to T\). The actual comparison maps are part of the
preceding proofs; the final theorem does not assume a desired exponential or
shape-commutation equation.

Under the same real-cohesion and crisp structural inputs, Boolean is an
appropriate shape-local discrete target. Every Boolean-valued map on this
shape-connected endomorphism type must be constant. Its distinct proved
endpoint values yield the contradiction.

The final corollary supplies tininess of this particular spectrum by applying
the existing all-crisp-Weil signature directly to the constructed `Normal.weil`.
There is no inference from tininess of the dual numbers to tininess of arbitrary
zero loci. Tininess of the full double-negation infinitesimal neighborhood and
`FlatTruncationDistribution` are not inputs of this theorem.

### The actual comparison already has an explicit collision

`WeilShapePowerComparisonObstruction` locates the failure at a specified map,
without taking tininess as an input. For the same constructed spectrum
\(T=\operatorname{Spec}(W_R)\), its `comparison` is literally
`TinyFinitePowerNullification.Context.At.comparison`, the nullification
recursor

\[
c:\operatorname{Shape}(T\to T)\longrightarrow
  (T\to\operatorname{Shape}(T)),\qquad
c(\eta f)(t)=\eta(f(t)).
\]

Let \(z=\eta(\operatorname{const}_{0_T})\) and
\(u=\eta(\operatorname{id}_T)\). The source separation and image equality
have different, explicitly recorded premises:

| Construction | Required inputs beyond the crisp ring context |
| --- | --- |
| The determinant label on \(T\to T\) | Kock field, reflexivity of this actual rank-15 algebra, invertibility of 3 and 4 |
| Extension of the label to \(\operatorname{Shape}(T\to T)\), proving \(z\ne u\) | The same local algebraic inputs, `RealFlat`, and the native crisp identity rule at level \(\ell\) |
| Contractibility of \(T\to\operatorname{Shape}(T)\), hence \(c(z)=c(u)\) | Kock field and the existing crisp-pullback-preservation signature, through the constructed pointed polynomial presentation |

For separation, lift the actual Boolean label to
`Lift {j = ℓ} Bool`. The previously constructed shape modality of this target
extends the label by the actual shape recursor. Its computation law identifies
the two unit values with the determinant label's proved false and true values.
A path \(z=u\) would therefore yield false = true. This establishes more than
the failure of a chosen proof of connectedness: the two displayed points of
the reflected endomorphism type are distinct, so that type is not a
proposition.

For image equality, the explicit presentation and crisp pullback preservation
make \(\operatorname{Shape}(T)\) contractible. Its \(T\)-indexed function
type is then contractible, identifying the two actual comparison values.
Consequently the canonical \(c\) is not injective and cannot be an equivalence.
The code constructs this collision and the non-equivalence proof; it does not
postulate a failed comparison or a Boolean invariant. Current native acceptance
of this additive module is determined only by `state.json` and its applicable
raw receipts.

The connection to the fixed-universe tininess signature uses this same map
directly. Apply
`TinyFiniteFreeWeilShape.Context.Algebra.functions-coordinates` to the actual
`Connected.Normal.weil`, its constructed 15-coordinate equivalence, and the
local reflexivity witness. This gives
\((T\to R)\simeq(\mathrm{Fin}(15)\to R)\). With `RealFlat`,
`TinyFinitePowerNullification.Context.At.preserves-nullification` then sends
an `External.Tiny T` witness to `isEquiv c`, where \(c\) is exactly the
displayed recursor, including its unit computation. No unspecified equivalence
between the source and target is substituted for it. This implication needs
neither the units of 3 and 4 nor crisp pullback preservation; those hypotheses
enter the separate collision argument. Composing the implication with the
proved non-equivalence therefore excludes this very tininess signature under
the combined local assumptions. The same obstruction source now expresses these
two steps as `tiny-forces-comparison-equivalence` and `not-tiny`; their native
acceptance follows only from the current source ledger and applicable receipt.
No additional model structure or all-Weil premise is needed.

This localizes the incompatible consequence of the tininess argument.
The separation theorem does not need crisp pullback preservation, and the
collision theorem does not need reflexivity or tininess. Combining them needs
neither all-Weil Kock–Lawvere nor all-Weil tininess: reflexivity of the one
constructed algebra suffices. Strict order is unnecessary once the two scalar
units are given; the existing ordered corollary constructs those units. No
`DPProper`, `Compact.ProperData`, external properness, excluded middle, or
flat/truncation-distribution rule occurs in this argument.

Every displayed source, target and lifted Boolean object remains in
`Type ℓ`; the crisp ring, Kock witness and `CrispIdentityInduction {ℓ}` retain
their native binders. A revised foundation must explain which premise or
which derivation of this precise same-level comparison changes. Merely naming
a larger external adjoint does not provide the original `External.Tiny`
record or establish that its required evaluation-induced comparison is
preserved. This is a diagnostic for a revised interpretation, not a
construction or consistency claim for one.

The new [selected-root left-inverse argument](real-sheaves.md#five-comparisons-for-a-left-inverse)
sharpens the finite-premise audit. Take its X=T and S=Shape(T->T), with one
same-level crisp root K and actual evaluation (T->K)->S. Under RealFlat and
the local reflexivity supplying the constructed 15-coordinate equivalence,
its five evaluation comparisons would make this exact c injective. The
existing separated-points/collision argument therefore rules out that package
under the same scalar-unit and crisp-pullback assumptions. The comparison at
Shape(T) is used as a map, without an invertibility premise; a root for the
target of c is not needed. The generic source is now written in
[TinySelectedSourceRetraction](../src/Orbifolds/TinySelectedSourceRetraction.agda)
with its exact native acceptance owned by the source ledger and raw receipt.
The collision specialization is implemented in
[WeilSelectedSourceIncompatibility](../src/Orbifolds/WeilSelectedSourceIncompatibility.agda).
It derives the source's powered locality from the actual 15-coordinate
equivalence, applies the constructed injection at X=T, and contradicts the
existing separated comparison's collision. Its separate native acceptance is
recorded in the source ledger and applicable raw receipt. This accepts this
smaller conditional incompatibility package; it does not alter the original
obstruction module or supply a source-interpretation theorem.

### Source correspondence and remaining interpretation work

The source audit maps `RealFlat` to Myers's Axiom 2; the Kock, order,
Kock–Lawvere, and Weil-tininess inputs to Axiom 3; and crystalline crisp-pullback
preservation to Axiom 4. The external tininess comparison follows the
evaluation-based form discussed in Appendix A. Crisp identity induction is
motivated by Shulman's Theorem 5.6, derived in his spatial theory using sharp.
These are source-correspondence findings, not a completed translation theorem.

Primary sources:

- Myers, *Orbifolds as microlinear types in synthetic differential cohesive
  homotopy type theory*, <https://arxiv.org/html/2205.15887v1>.
- Shulman, *Brouwer's fixed-point theorem in real-cohesive homotopy type
  theory*, <https://arxiv.org/html/1509.07584v3>.

An exact transfer must interpret native crisp dependence and substitution,
the crisp identity rule and its computation law, cubical identity and the
higher inductive constructions actually used, and the chosen universe levels.
In particular, `External.Tiny` contains a same-level object assignment and
the actual evaluation-induced comparison under Flat. An external right
adjoint in a larger category does not by itself fill that fixed-universe
signature. An arbitrary equivalence with similar-looking hom-space types
does not identify the required comparison map either.

Consequently the status has advanced from a source-only proposed obstruction
to a checked contradiction for the displayed package. The unrestricted
claim about every interpretation of the original paper has not been silently
added to the theorem. The constructive external real, calculus, and sheaf
development remains useful for a revised geometric theory whose assumptions
can be realized together.

