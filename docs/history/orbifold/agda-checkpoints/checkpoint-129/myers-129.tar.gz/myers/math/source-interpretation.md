# Source interpretation

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="language-bridge"></a>

## A bounded ordinary type-theoretic bridge

This note supplies an external mathematical realization of the bounded
ordinary type-theoretic interface used by the finite-branch atlas theorem.
Its source audit does not interpret the Cubical implementation or formalize
a proof assistant’s soundness theorem.

### 1. The smaller implementation target

The new theorem uses a deliberately restricted, ordinary intensional
Martin-Lof type theory, checked with `--safe --without-K`: dependent
products and sums, inductive identity with its J eliminator, natural and
finite types, explicit universe lifts, function extensionality, and the
bounded propositional truncations described below. Its proof uses no
Cubical module, interval operation, `Glue`, `SSet`, rewriting, reflection,
crisp syntax, or primitive groupoid-quotient HIT.

The theorem's input includes an actual map `q : A -> X`, an arrow family
`H : A -> A -> Type`, and these independently meaningful data:

- mere representatives for every point of `X`, i.e. surjectivity of `q`;
- equivalences `H(a,b) ~= (q(a) = q(b))` for the original arrow family;
- finite local partial-map charts for `H`;
- the actual pointed test maps `b_i : 1 -> B_i` and `g_i : B_i -> T_i`;
- locality of `A` for every `g_i` and right orthogonality of `q` to every
  `b_i` and `g_i`.

The proof derives subfinite identities and locality descent from these
data. Here subfinite means a mere presentation by a finite family of
propositions, as specified exactly in Section 5. It does not include
locality or subfinite identities of `X` as fields of the input interface.
A category structure is unnecessary for this particular internal
implication: it is used externally to construct the effective atlas and
identify its kernel pair.

For the application, take `X = |N(jG)|`, the actual quotient of the
represented Lie groupoid, and `q : jG0 -> X` its atlas. Groupoid effectivity
identifies `jG1` with `jG0 x_X jG0`; its fibers provide precisely the required
hom/path equivalences. Effective epimorphy supplies the representative
condition. These are structural facts about the quotient, independently
of any finite-branch or microlinearity conclusion. Section 6 of
`external-models.md#finite-bisection-interpretation` constructs them and the atlas lifting
properties in the chosen higher Cahiers setting.

Similarly, externally form `B_i` as the homotopy pushout of the three
appropriate finite Weil vertices and `g_i` as its actual gap map. The
mapping-space universal property identifies locality for this map with
the intended microlinearity comparison. The new executable theorem can
take those maps as data; it need not implement their pushout construction.

This is a new theorem at a smaller semantic boundary. It is not a literal
port of `RezkByHIT`, nor an interpretation of the old Cubical term merely
because the conclusions have related mathematical meanings.

#### Ordinary MLTT

Shulman's Theorems 11.1-11.2 and A.26 give every Grothendieck infinity-topos
a strict model with dependent sums/products, function extensionality,
identity types, elementary inductive types, and suitable noncumulative
univalent universes. Remark A.28 discusses explicit lifts. Theorem A.26
also supplies stable HIT operations, but the discussion on pp. 29 and
56-57 does not establish closure of these universes under parameterized
HITs. Corollary 4.9 bounds any fixed morphism by relative presentability.
These are the ingredients used below; no univalence principle is needed
by the proposed smaller proof. [S19]

Lumsdaine-Shulman Theorems 10.6 and 13.2 supply stable propositional
truncations and pushouts in the relevant excellent model categories;
Sections 5-6 address elimination and computation. Their construction has
restrictions on constructor boundaries involving fibrant structure.
In particular, a groupoid-quotient interface with path-composition laws
cannot simply be declared an instance without giving the translation.
Their truncation result provides the full proposition-valued elimination
used below. [LS19]

#### Exact Cubical Agda

The Cubical Agda paper describes an implementation based on De Morgan
cubical type theory, including transport/composition optimizations and
native higher inductive pattern matching. Its Section 6 discusses the
relationship to the semantic and canonicity results for that theory.
This is useful foundation evidence, but does not give an interpretation
of the present source in the specified higher Cahiers category. [VMA19]

Coquand-Ruch-Sattler construct cubical sheaf models via descent operations
and explain how the modal interpretation changes inductive/HIT
constructions to retain computation laws. Thus naive levelwise use of
the old cubical operations is not itself the sheaf interpretation. [CRS21]

The 2026 higher-sheaf paper gives further constructive machinery, but its
introduction explicitly leaves identification with the intended higher
categories of sheaves conjectural. Its Theorem 29 and Remark 30 do not
therefore discharge our particular classical-category identification.
[CHS26]

The 2026 equivariant cartesian cubical model does present classical
spaces. However, it is a cartesian construction, and Remark A.6.3 does
not undertake the proposed HIT interpretation. It supplies neither a
direct semantics for the present De Morgan source nor the required
smooth sheaf comparison. [ACCRS26]

No claim is made that no newer theorem could improve these routes. The
bounded ordinary route below already avoids relying on such a theorem.

### 3. A bounded truncation interface with an external model

The following is a derived construction for this project, not a claim
that a cited theorem already states this exact interface.

#### Bounded-interface lemma

Fix a universe `U_a` in a type-theoretic model topos presenting the chosen
Grothendieck infinity-topos. Under the external universe assumptions
needed to choose a sufficiently large later inaccessible cardinal, there
is a later universe `U_b` and an operation

\[
  \operatorname{Tr}_{a,b}:U_a\longrightarrow U_b
\]

with a unit `A -> Tr(A)`, propositionhood of `Tr(A)`, and dependent
elimination into proposition-valued families coded in `U_b`. In decoded
notation the eliminator has the shape

\[
 \prod_{A:U_a}\prod_{P:\operatorname{Tr}(A)\to U_b}
 \left(\prod_z\operatorname{isProp}(Pz)\right)
 \to\left(\prod_{x:A}P(|x|)\right)
 \to\prod_{z:\operatorname{Tr}(A)}Pz.
\]

Only propositional computation at `|x|` is required. It follows at once
from propositionhood of the target fiber, independently of how the
eliminator is represented. This lemma does not put `Tr(A)` back in `U_a`.

#### Construction

Work in the strict ordinary model. Over the single context `A : U_a`,
form a genuine stable propositional truncation of the universal decoded
family. Its comprehension is one fibration

\[
  t:T\longrightarrow U_a.
\]

The unbounded type-former exists before any assertion that `T` is coded
in a particular universe. Since the underlying category is locally
presentable and locally cartesian closed, this one map has a relative
presentability bound. Choose a later inaccessible cardinal above that
bound and the ordinary universe requirements. The associated universe
classifies `t` by a map `tau : U_a -> U_b` and a chosen isomorphism of
`t` with the pullback of its universal fibration.

These size choices can be made before the final ordinary coherence step:
the universal fibration at `U_a` and its generic stable truncation are
already fixed morphisms in the underlying model category before `U_b`
is chosen. The selected universe family and these generic data can then
be used in the strict model. Thus placing the output at the next selected
syntactic level does not require first assuming a same-universe HIT
closure result.

Define `Tr(A)` to be the decoded type of `tau(A)`. Transfer the original
unit and proposition structure along the chosen isomorphism. To obtain
recursion, use the original truncation's eliminator in the *single
generic context* consisting of `A : U_a`, a proposition target family
coded in `U_b`, its proposition witness, and the input section. Transfer
the resulting section along the same isomorphism.

The result is ordinary model data, hence a term of the displayed
interface. Substitution is application/pullback of these chosen generic
data; it is not a collection of unrelated choices at individual stages.
No internal axiom of choice is used. The construction is uniform over
all inputs coded in the fixed `U_a`, with one larger output universe.

The ordinary universe assumptions are substantive external assumptions,
as in the model theorem. This argument does not calculate small cardinal
bounds or claim a predicative constructive metatheory. It establishes the
bounded interface in the same classical external setting as the selected
higher Cahiers construction.

#### The implemented Agda interface

For carriers at a fixed native level `ell`, branch-chart records contain
small proposition-valued regions and therefore live at `suc ell`. One
implemented design is

```text
Code ell  = lsuc ell
Truth ell = lsuc (lsuc ell)

Tr     : Set (Code ell) -> Set (Truth ell)
point  : A -> Tr A
squash : (A : Set (Code ell)) -> isProp (Tr A)
rec    : isProp P -> (A -> P) -> Tr A -> P
         -- A : Set (Code ell), P : Set (Truth ell)
```

The syntactic successor `Truth ell = lsuc (Code ell)` places no restriction
that the associated inaccessible cardinals be adjacent. For a fixed level
instance, choose the universe at `Truth ell` sufficiently large for the
bounded-interface construction. The hierarchy can omit intermediate
cardinals: choose the level structure and universe family using [S19,
Definition A.14, Example A.15, and Theorem A.25], then apply its strict
coherence construction with these choices. Lower-level inputs and
elimination targets are explicitly
lifted. Subfiniteness predicates live at `Truth ell`; they are not resized
back to `ell`. The interface record itself is in
`Set (lsuc (Truth ell))`, so the interpretation also includes a further
universe for this record.

The interface requests only nondependent elimination into propositions
at `Truth ell`. Its lower-level recursor lifts the target there and then
projects the result. It has no `Setomega` field quantifying over all target
levels. Propositionhood proves the displayed `rec-β` theorem; no
judgmental truncation computation is requested. A nondependent recursor
into propositions, together with `isProp (Tr A)`, also gives dependent
proposition elimination by transporting from `|a|` to the requested
argument before recursion. That stronger derived eliminator is not used
by the present proof.

If a later extension genuinely truncates a type already living at
`Truth ell`, add a later bounded operation and repeat the construction.
Merely eliminating into a `Truth ell` proposition does not require
truncating that proposition again. Keep a finite acyclic list of these
universe increases; do not smuggle a same-universe closure claim into
the notation. A level-polymorphic theorem can be applied at chosen
fixed levels for the external application; no object-language type of
all universes is needed.

There is also an initial size choice for the geometric inputs. First form
the actual quotient, atlas, and fixed small family of external Weil gaps.
Regard an indexed family as one morphism over its index object. Choose the
starting universe at `ell` large enough to classify these objects and
families, including the hom-family and open chart predicates. Corollary
4.9 supplies bounds for the fixed representing morphisms. Then choose
the `Code`, `Truth`, and interface universes in that order. This applies
to the whole chosen small test family, not just to finitely many test
maps; only the number of successive universe choices is finite. No
closure of the starting universe under arbitrary pushouts or quotients
is being asserted.

### 4. Why supplying an effective atlas is legitimate here

An input interface by itself is not a model. To instantiate it, retain
the actual external quotient, map and arrow family, and supply each field
by a separate geometric fact:

| Ordinary theorem input | External construction supplying it |
| --- | --- |
| `A`, `X`, `q` | `jG0`, the actual quotient `|N(jG)|`, and its object atlas |
| `H(a,b)` | The fiber of the original source-target map |
| `H(a,b) ~= (q(a) = q(b))` | The effective groupoid's actual kernel-pair equivalence |
| Mere representatives | Effective epimorphy of that atlas, evaluated by genuine propositional truncation |
| Local branch data | The finite open bisection construction, including its generalized-point descent |
| Pointed maps `b_i`, `g_i` | The chosen finite Weil squares and their external homotopy-pushout boundaries |
| Locality of `A` | The finite Weil calculation in manifold charts |
| Both lifting properties of `q` | Formal etaleness and the pullback-cancellation argument for that actual atlas |

All these constructions are supplied in the existing external report.
The new theorem still has to perform the mathematical work from these
inputs to finite identities and locality of `X`. In particular, its input
must not contain a field named differently but logically equal to either
of those conclusions.

The semantic transfer is performed in a fixed model presentation of the
higher Cahiers infinity-topos. Its identity types represent homotopy
fibers/path objects and its equivalences represent equivalences in the
infinity-category. Consequently the kernel-pair equivalence above
provides the interpreted hom/path input. The interpretation of `Tr` is
the genuine truncation transferred along its chosen coding isomorphism,
so effective epimorphy supplies the interpreted surjectivity input.

This does not require an internal choice of atlas representatives,
global branch labels, or a global enumeration of arrows. All local
existence enters proposition-valued statements and is eliminated only
where the destination has been proved a proposition.

#### 4.1 Set-valued interpretation and nontrivial isotropy

The current dependent sheaf constructor branch has a precise scope:
`Intensional.SmallPresheaves.Presheaf` requires `value-set`,
`SemanticBridge.DependentPresheafTotal.Family` is a set-valued presheaf
on a category of elements, and `DependentSheafFamilies` adds the sheaf
certificate. The constructed identity family in
`DependentSheafIdentityFamilies` has `equality-prop` and `fiber-prop`.
These signatures do not make every construction in `SemanticBridge`
set-valued.

The following control against the actual ordinary source is implemented in
`src/Orbifolds/Intensional/EffectiveAtlasSetTarget.agda`. For
`F = FiniteBranchAtlas.Finiteness T`, its `At.set-target-homs-prop`
signature is

```text
set-target-homs-prop : (Q : F.EffectiveAtlas A X) -> isSet X
                    -> (a b : A) -> isProp (F.EffectiveAtlas.hom Q a b)
```

Put `e = F.EffectiveAtlas.hom-path Q a b`. For arrows `h` and `k`,
the proof is the ordinary identity composite

```text
sym (retraction e h)
  . cong (backward e)
      (setX (atlas Q a) (atlas Q b) (forward e h) (forward e k))
  . retraction e k
```

where `.` denotes identity concatenation. Only `hom-path` and the
additional `isSet X` premise are used; no function extensionality,
truncation elimination, crisp rule, properness, or resizing is needed.
Consequently an interpretation with proposition-valued identity fibers cannot
realize an effective atlas whose hom type contains two distinct arrows.
This does **not** obstruct admission of the uniform source theorem into
a suitably constructed restricted set model. The source's `Set ell`
is a universe, not a sethood premise, and its final theorem assumes
`isSet A`, not `isSet X`. Such a restricted model would realize only
the atlas instances compatible with its identity interpretation;
source admission and realization of the intended nontrivial-isotropy
instances are distinct obligations. The typed-source and universe
classification obligations remain even for that restricted admission.

An accepted concrete nontrivial finite-isotropy control already exists
in `src/Orbifolds/QuotientExamples.agda`: the trivial action on a point
has `orbit-loop-is-not-identity`, `quotient-is-not-a-set`, and
`isotropy≃two : (orbit ≡ orbit) ≃ Bool`. Its intermediate
`isotropy≃automorphisms-of-two` identifies the entire automorphism type
of `Bool`. This existing control should be reused; the argument above
does not create new native evidence. Its `FamilyAction` quotient is
also distinct from the newer ordinary groupoid-completion adapter.

The accepted `SemanticBridge.OrdinaryGroupoidCompletion` constructs
an actual ambient Cubical groupoid quotient, both hom/path maps and
their inverse laws, and an `effective-atlas` of the exact ordinary
source signature. `FiniteActionQuotientPresentation.stabilizer-loops`
identifies the original stabilizer with the quotient's loops, while
`arrow-label-recovered` retains the original labels. These are a
positive higher route already present in the project. They do not
supply a sitewise higher-family model, semantic universes, or a
derivation of the selected source proof. Acceptance of those existing
files and of this control is determined by `state.json` and
applicable raw receipts, separately from this manual argument.

#### 4.2 Bounded ordinary-functor atlas adapter

The construction is implemented in
`src/Orbifolds/SemanticBridge/OrdinaryGroupoidCompletionMaps.agda`;
its exact native acceptance is determined by `state.json` and its applicable
raw receipt.
Its inputs are actual ordinary categories `C D : Cat.Category ell ell`,
proofs `invertibleC` and `invertibleD` that every respective arrow is
`Cat.IsIso`, and an actual `ordinaryFunctor : Cat.Functor C D`. Set
`F = Cat.Functor ordinaryFunctor`, and instantiate `Source` and `Target`
as `OrdinaryGroupoidCompletion.Completion` with those categories and
invertibility proofs. No completed map, hom/path equation, inverse
functor, full faithfulness or desired atlas morphism is an input.

Convert the functor between the existing `CategoryBridge` categories:
its object and arrow maps are `F.object` and `F.arrow`; its identity
law is `idToPath F.arrow-identity`; its Cubical composition law at
`f g` is `idToPath (F.arrow-compose g f)`. The reversed arguments
are required because Cubical `f ⋆ g` is ordinary `compose g f`.
The pinned `RezkByHIT.recCat` in
`vendor/cubical/Cubical/Categories/RezkCompletion/Construction.agda`
supplies the authored map directly:

```agda
completed-map : Source.Object → Target.Object
completed-map = Source.Q.R.recCat
  Target.Q.completedCategory
  Target.Q.completion-isUnivalent
  (CF.funcComp Target.Q.inclusionFunctor convertedFunctor)

completed-map-object : (x : Cat.Category.Obj C)
  → completed-map (Source.quotient x)
    O.≡ Target.quotient (F.object x)
completed-map-object x = O.refl
```

Here `CF` is `Cubical.Categories.Functor` and `O` is the ordinary
identity module. Keep the map transparent until its object computation
has been established. The known generic completed-map formula already
appears in `CompletionMoritaEquivalence.Map`; this adapter specializes
the exposed plain library recursor and does not claim a new generic
completion theorem. It requires no extraction or change to either
accepted `CompletionMoritaEquivalence` or shared `GroupoidCompletion`.

The remaining generating-arrow equation is
`cong completed-map (Source.Q.morphismPath h) ≡
Target.Q.morphismPath (F.arrow h)`, with Cubical equality. Its authored
proof is `cong Target.Q.R.inc-ua (Σ≡Prop isPropIsIso refl)`: the
`recCat` path branch reduces through the target's constructed
`CatIsoToPath` to `RezkIsoToPath`, and at included objects to
`inc-ua ∘ RezkIso→Iso`. The transported and chosen invertibility
witnesses have the same underlying arrow. The complete authored module is
the native checking target; no generating-arrow lemma
with this exact interface was found among the inspected Rezk exports.

The source names that Cubical equation `completed-map-morphism-path h`.
The ordinary
hom/path equation is reconstructed using the existing `IdentityPath`
round trips, without UIP or judgmentally identifying the equalities:

```agda
completed-map-homToPath h = idToPath-reflect
  ( idToPath-cong completed-map (Source.homToPath h)
  ∙ cong (cong completed-map)
      (idToPath-pathToId (Source.Q.morphismPath h))
  ∙ completed-map-morphism-path h
  ∙ sym (idToPath-pathToId
      (Target.Q.morphismPath (F.arrow h))) )
```

Instantiate `AM = AtlasMorphisms.Comparison
(boundedTruncationInstance ell) (funExtInstance ell ell)` with the
same truncation instance as both completions. Package an
`AM.AtlasMorphism Source.effective-atlas Target.effective-atlas` with
object map `F.object`, map `completed-map`, object square `O.refl`,
and hom map `F.arrow`. Its `hom-path-computation` is
`completed-map-homToPath h O.∙ O.sym (O.∙-right-unit
(Target.homToPath (F.arrow h)))`. The symmetric right-unit correction
is necessary after the left reflexivity whisker reduces.

This is an additive plain-Cubical bridge interface at one common
object/hom level. Its project dependencies are the ordinary
`AtlasMorphisms`, `Equivalence`, `CategoricalTransfer`, `Identity`,
`BoundedTruncation`, `FiniteBranchAtlas`, the bridge's `IdentityPath`,
`Truncation`, `OrdinaryGroupoidCompletion`, and the already approved
shared `GroupoidCompletion`. A bounded local import review found no
additional project exception, cohesion or crisp dependency. Do not
import the cohesive `CompletionMoritaEquivalence` even with a narrow
`using` list, widen the shared-source exception, or alter pins.
The authored result concerns the actual functor's atlas morphism;
it supplies neither source admission nor semantic universes,
sitewise higher-family semantics, or probe-restriction coherence.

#### 4.3 Identity and composition of the actual completed maps

The next bounded coherence construction retains those very functions. Write
qF for the completed map of an ordinary functor F. The intended equations are
`qId = id` and `q(G F) = qG qF`, as equalities of functions on all completed
objects. Ordinary identity and composite functors use the literal identity
and composite object/arrow functions, with laws derived from the supplied
functor laws. No completed-function law is an input.

The pinned `RezkByHIT.elimSet` applies to the path family between the two
functions: its fibers are sets because the target completion is a groupoid.
Proposition induction or mere object-surjectivity would not supply the needed
homotopy for these path fibers. On included objects both sides compute to the
same included target object, so the branch is reflexivity.

For an arbitrary generating isomorphism e, first identify `inc-ua e` with
`morphismPath (fst e)` using `cong inc-ua (Σ≡Prop isPropIsIso refl)`. Only the
isomorphism certificates are proposition-valued; the original arrows are
retained. The existing map computation then sends that generator to the path
of F's actual arrow action. In the identity case this is the original generator.
For composition both sides give the path of `G.arrow (F.arrow (fst e))`.

If the resulting equality between paths is `generator e`, the dependent
generator square required by `elimSet` is its transpose
`lambda e i j -> generator e j i`. The source endpoints give the two reflexivity
branches; the other endpoints are the left and right functions along the
source generator. Fiber setness supplies the higher constructor cases in the
pinned eliminator. Function extensionality yields the completed-function
equations, and `pathToId` yields their ordinary identity presentation.

This is implemented in the additive `OrdinaryGroupoidCompletionCoherence`
target; its native acceptance is owned by the source ledger and applicable
raw receipt. It requires no new shared-source
exception, cohesive import, resizing, inverse functor or desired model premise.
Coherence between these function equalities, sitewise higher-family semantics,
smooth/formal instances and source admission remain separate obligations.

#### 4.4 Natural transformations give completed-map homotopies

Actual pullback identity and composition comparisons need not be equalities
of ordinary functors. To transport their natural comparison arrows, take
ordinary functors F,G:C->D between the same groupoids as above, components
eta_x:F(x)->G(x), and the actual ordinary naturality equations
`eta_y o F(h) = G(h) o eta_x`. No completed-map homotopy is an input.

The object branch is the target completion's path of eta_x. For an arbitrary
isomorphism generator e with underlying arrow h, the two existing map laws and
the target's composition law give

```
ap(qF,[h]) . [eta_y]
  = [eta_y o F(h)]
  = [G(h) o eta_x]
  = [eta_x] . ap(qG,[h]).
```

The middle equality is the supplied ordinary naturality equation converted
with `idToPath`. As in Section 4.3, propositionhood is used only to replace
the generating isomorphism's certificate while retaining its underlying arrow.
The pinned `compPath→Square` converts this equation `p . s = r . q` into
`Square r s p q`, exactly the dependent generator branch between the paths of
eta_x and eta_y. The target completion is a groupoid, so the displayed path
fibers are sets and `RezkByHIT.elimSet` constructs the homotopy on every
completed object. Its value on an included object is the original component
path. Function extensionality then gives equality of the actual completed maps.

This supplies the mathematical next step from a constructed ordinary natural
comparison to quotient restriction coherence. It is now written in
`OrdinaryGroupoidCompletionNaturality`, reusing the checked coherence target's
generator comparison rather than introducing a second copy. Its own native
acceptance remains subject to the ledger and applicable receipt.
Higher compatibility between several such
homotopies, actual pullback comparison arrows, cover descent and source
admission retain their separate obligations.

#### 4.5 Identity and vertical composition of those homotopies

There is a smaller next coherence argument for the very homotopy constructed
above. The identity natural transformation of F has component `id_(F x)`.
For eta:F=>G and theta:G=>H, their vertical composite has the actual component
`theta_x o eta_x`; its naturality follows by associativity, eta's naturality,
reverse associativity, theta's naturality, and associativity again. These
are ordinary arrow equations, with no completed homotopy supplied as data.

Write h_eta for the constructed completed homotopy. The desired pointwise laws
are `h_id(z)=refl` and `h_(theta o eta)(z)=h_eta(z) . h_theta(z)`. The two sides
in each equation are paths with the same endpoints in the target completion.
Because that completion is a groupoid, equality between those path values is
a proposition. Thus the pinned Rezk eliminator's `elimProp`, unlike the
`elimSet` used to construct the homotopies, suffices to prove these laws.
No representative is selected from mere surjectivity.

On an included object x, the existing object computation gives the original
component arrow's path. The identity equation is then `morphismPath-identity`.
For vertical composition, `morphismPath-composition` identifies the path of
`theta_x o eta_x` with the concatenation of the two component paths. The
object computation laws identify these with the two original constructed
homotopies. Function extensionality gives equality of the homotopies as
functions. This proof does not unfold their generator squares or replace
the component arrows by proof-irrelevant data.

This argument is implemented in
[OrdinaryGroupoidCompletionNaturalityLaws](../src/Orbifolds/SemanticBridge/OrdinaryGroupoidCompletionNaturalityLaws.agda),
whose full native gate has passed with applicable completed evidence. It addresses identity and vertical
composition only. Horizontal
composition, actual continuous pullback comparison arrows, their sitewise
coherence, and source admission retain their stated obligations.

### 5. Audit of the concrete ordinary source

The audited project files are:

- `src/Orbifolds/Intensional/Identity.agda`;
- `src/Orbifolds/Intensional/BoundedTruncation.agda`;
- `src/Orbifolds/Intensional/FiniteBranchAtlas.agda`.

#### Syntax and computation actually used

`Identity.agda` defines an ordinary inductive identity type and `J`.
Its path calculations reduce by identity elimination. In particular,
`isContr→isContrPaths` uses the supplied contraction and `J`; it does
not assume uniqueness of arbitrary identity proofs. The proposition and
set lemmas derived from it are the usual intensional arguments.
Nonrecursive records and their copattern definitions have ordinary
dependent-tuple interpretations. `Lift` is interpreted by the explicit
universe lifts, with inverse `lift` and `lower`, supplied by [S19,
Definition A.14 and Remark A.28].

The only proof parameter for function extensionality is `FunExt ell ell`.
It supplies a path from pointwise paths, and no special computation rule
for this parameter is used. `Equiv` stores a map, an inverse, and two
homotopies. It is quasi-inverse data; the source correctly makes no claim
that this record is a proposition.

The indexed `Fin` datatype requires no new higher inductive semantics.
At fixed `ell` it can be interpreted by natural-number recursion into
the universe, with `Fin 0` empty and `Fin (suc n)` the binary sum of the
unit type and `Fin n`. Its constructors and eliminator are derived by
ordinary natural-number, sum, and empty elimination. This uses the
standard large eliminators, including recursion into a universe, already
available in the strict MLTT model. It makes no parameterized-HIT
universe-closure assumption.

The project imports only its two earlier ordinary modules,
`Agda.Primitive`, and `Agda.Builtin.Nat`. The last imports the shipped
ordinary `Bool` datatype. The relevant pinned primitive files were read:
the natural-number definitions are ordinary terminating recursion, and
no Cubical interval or HIT module is in this import closure. The native
primitive module also declares other builtin sorts, but this source uses
only `Set` and universe-index operations. The semantic claim is for a
fixed-level specialization of these declarations; it treats level indices
as metatheoretic indices, not as a new internal `LevelUniv` object. It
does not claim a model of every feature advertised by `Agda.Primitive`.

#### Universe and truncation audit

| Declaration or family | Declared level | Semantic interpretation |
| --- | --- | --- |
| Carriers, homs, region fibers, test index, boundaries and codomains | `ell` | The fixed geometric inputs, bounded before choosing the initial universe |
| `BranchChart`, `LocalBranchChart`, `SubfiniteWitness`, `PointedGap` | `Code ell` | Ordinary dependent tuples whose fields may contain codes of `ell`-small types |
| `Tr A`, `Mere A`, `Subfinite A`, `LocalBranchCharts`, `EffectiveAtlas` | `Truth ell` | The single bounded truncation and ordinary sums/products |
| `Extension`, `Local`, `RightOrthogonal`, `Microlinear`, `InfinitesimallyEtale` | `ell` | Ordinary function types, identity fibers, and inverse data |
| `ReducedOrbifold X` | `Truth ell` | A pair of relative test-locality and subfinite-identity proofs |
| `BoundedTruncation ell` | `lsuc (Truth ell)` | The record containing the bounded operation and its eliminator |

Every call to `Tr` consumes a `Code ell` type. `Mere` explicitly lifts an
`ell`-small type to that level. Every direct `rec` target is a proposition
at `Truth ell`; `rec-low` explicitly lifts an `ell`-small proposition to
`Truth ell` and lowers the output. `rec-β` is proved by target
propositionhood. Nothing truncates a `Truth ell` type, resizes the result,
or requires a judgmental beta rule for the opaque truncation parameter.
The bounded construction of Section 3 supplies exactly these fields.

#### The exact conclusion and its geometric inputs

`SubfiniteWitness X` consists of a natural number `n`, a family
`P : Fin n -> Set ell`, proofs that its fibers are propositions, and
`Equiv X (Sigma (Fin n) P)`. `Subfinite X` is the bounded propositional
truncation of this record. Thus the checked target is a mere finite
predicate presentation. It does not enumerate `X`, decide membership in
`P`, or assert ordinary cardinal finiteness. This new file does not define
or assert the old library's `ProperlyFinite` predicate.

`chart-subfinite-witness` obtains the proposition fiber at label `i` as
the pair of branch-domain membership and equality of the branch target
with the requested endpoint. The first component is a proposition by
the chart input; the second is a proposition because the target is a
set. Local charts first restrict to the proposition-valued regions and
then use this calculation. Truncation maps the local chart witness to a
subfinite hom witness.

`EffectiveAtlas` stores the actual map `atlas`, its specified `hom`
family, genuine mere representatives, and hom/path equivalences. The
proof transfers the hom witness along that equivalence and along paths
from chosen representatives. It eliminates the representatives only into
the proposition `Subfinite (u = v)`. No quotient identification is
concluded merely from the name of the record: Section 4 supplies these
fields for the actual effective quotient.

For geometry, `Extension e k` is the identity fiber of precomposition
with `e` at `k`. `mapExtension f e k` is the actual postcomposition map
on these extension fibers. `RightOrthogonal e f` asks for
`InverseData (mapExtension f e k)` for every `k`; its forward function is
fixed. It cannot be satisfied merely by an unrelated equivalence between
the two extension types. An external equivalence of this very map gives
the inverse data, including its two homotopies.

`lift-map-merely` lifts a boundary map after lifting its basepoint.
`local-descends` then transports the contraction of the extension space
upstairs across the specified extension-map equivalence. The remaining
mere lift is eliminated into `isContr (Extension e k)`, proved a
proposition using the displayed function-extensionality parameter.
Consequently the two atlas lifting properties do real work in deriving
locality of the quotient.

Finally, `Tests.Microlinear X` means locality for the supplied `test`
family. For arbitrary input tests it makes only that relative claim.
When the family is the actual finite Weil gap family of the external
report, the internal mapping-object universal property identifies this
with the selected finite Weil microlinearity condition. The final
`finite-branch-atlas-orbifold` theorem proves precisely this locality and
`(u v : X) -> Subfinite (u = v)`. Neither completed conclusion occurs as
an input field. It does not construct the quotient, establish external
properness, or classify every inhabitant of `ReducedOrbifold` as a
classical orbifold.

The source audit therefore finds no additional semantic assumption
beyond standard ordinary MLTT, the displayed function extensionality,
the bounded truncation constructed in Section 3, and the independently
instantiated geometric inputs. The unchanged source has the separate
native acceptance recorded above. This remains a mathematical audit of
the source-level fragment, not a mechanized elaboration or syntax-to-model
proof.

#### First coded judgment still missing

The four copattern clauses of `chart-subfinite-witness` identify a specific
first admission obligation. Its size reuses `branches chart`; its presentation
reuses `hom-equivalence chart x y`; and its proposition proof is the existing
`isPropΣ` applied to domain propositionhood and `setY`. Repeating that calculation
in a new native record would not interpret the source proof. The substantive
boundary is its field `predicate : Fin (branches chart) -> Set ell`, which
returns small-type codes.

For a constructed universe `U_ell` with decoding `El_ell`, the actual source
body would have the following code, retaining the chart's own inputs:

```text
predicate-code i =
  sigma-code (domain-code i x)
    (lambda d -> id-code Y-code (target i x d) y)
```

The required rules, written here as a schema rather than assumed model fields,
are:

```text
sigma-code : (a : U_ell) -> (El_ell a -> U_ell) -> U_ell
El_ell (sigma-code a b) ~= Sigma (El_ell a) (lambda d -> El_ell (b d))
id-code : (a : U_ell) -> El_ell a -> El_ell a -> U_ell
El_ell (id-code a u v) ~= (u = v)
```

The decoding comparisons must identify the constructed sum and identity
families and commute with actual context substitution. Pointwise signatures
alone do not supply these contextual laws. The universe and its code-valued
terms retain the successor level of the source's `Set ell`; this is not a
resizing of the existing family interface.

`DependentSheafSums.Sum.fiber-equivalence` and
`DependentSheafIdentityFamilies.Context.Pair.fiber-equivalence` supply external
fiber comparisons, and `Pair.fiber-prop` supplies propositionhood for the current
set-valued identity family. These familywise constructions do not themselves
produce the displayed code-valued term, a universe classifying the families,
or a typed derivation of the source clauses. Adding those missing operations
as premises of an assumed model, or replacing the code field by an external
family, leaves this admission obligation unresolved. It is separate from
realizing the intended higher atlases with nontrivial isotropy.

#### External proposition-code predecessor

**External code construction; this is not source admission.**
[SieveCodeExtensionality](../src/Orbifolds/SemanticBridge/SieveCodeExtensionality.agda)
contains the sieve extensionality and sethood proofs;
[ExternalPropositionCodes](../src/Orbifolds/SemanticBridge/ExternalPropositionCodes.agda)
contains the closed characteristic sieve, decoder with inverse laws,
code restriction and contextual-substitution equalities, and decoder squares
transporting along those actual code equalities. Native acceptance is recorded
only in the ledger and its applicable receipts.
The construction concerns external proposition codes at `suc ℓ` with
membership at ℓ, before the required internal universe. For an existing sheaf
context Γ, family A and proof that each fiber is a proposition, assign to
`x : Γ(U)` the characteristic sieve

```text
χ_A(U,x)(f : V -> U) = A(V, Γ(f)(x)).
```

Its downward map is the actual family restriction, transported along Γ's
composition equation. Its J-closedness is proved by gluing the supplied
local witnesses in the existing total sheaf of A, identifying the glued base
with Γ(f)(x), and transporting the fiber element. No classifier or choice of
merely existing local witnesses is an input. Let `ClosedSieveCode(U)` retain
this actual sieve and its closedness certificate, and decode by identity-arrow
membership:

```text
El_U(S) = S.contains(id_U)
El_U(χ_A(U,x)) ~= A(U,x)
f*(χ_A(U,x)) = χ_A(V, Γ(f)(x))
χ_(A[σ])(U,δ) = χ_A(U, σ_U(δ)).
```

The decoding equivalence uses Γ's identity equation. The restriction and
contextual-substitution comparisons use Γ's composition equation and the
actual naturality equation of σ. Their decoding squares compare the
constructed maps with A's actual restriction/transport maps, retaining
transport along the stated code equalities.

`Intensional.SmallSites` deliberately does not identify sieves from mutual
inclusion. The separate SemanticBridge lemma derives sieve
extensionality and sethood using the pinned Cubical `hPropExt`, `isSetHProp`,
function extensionality, and the existing `IdentityPath` conversions. Membership
families take values in hProp; downward-closure and closedness certificates are
proposition-valued. This proves equality of the actual code records from the
constructed membership maps. The Cubical
dependency, including any derived larger-level function extensionality, stays
explicit in this semantic construction; it adds no axiom to the ordinary source.

`ExternalPropositionCodes.code-identity-equiv` identifies actual
ordinary code equality with the pair of full-sieve inclusions:

```text
(s = t) ~= Included(fst s, fst t) × Included(fst t, fst s).
```

Its forward map transports membership along the equality in both directions;
its inverse is the constructed code-ext. The inverse laws use code-isSet and
propositionhood of the included-function types. Every object, arrow and
membership binder in those inclusion types is at ℓ, so the supplied
`ext : FunExt ℓ ℓ` suffices. This gives an ℓ-small representative of these
particular code identity types at `suc ℓ`, using all probe arrows. It makes
no general resizing, source-universe or categorical-monomorphism
classification claim.

These codes live at `suc ℓ`, whereas their decoded membership propositions live
at ℓ. The existing `SmallPresheaves` stage values and family fibers still share
the site's level ℓ. The checked mixed-level construction below now supplies
the code sheaf Ω_ℓ and its specified decoded display on the unchanged site,
with explicit heterogeneous pullbacks and restricted recovery for small
proposition-valued families over a fixed small Γ. No site lifting, cumulative
coercion or resizing is used. This Ω_ℓ does not provide all of `U_ℓ`, its
general sum and ordinary identity/J codes, or a typed derivation of
`chart-subfinite-witness`.

`code-isSet` concerns proposition codes. A decoding universe satisfying
univalence cannot be a set if it contains a code whose decoded type has two
distinct self-equivalences: univalence identifies that code's loop type with
its decoded self-equivalences, so the loop type is not a proposition. The
ambient two-element type provides identity and swap;
[QuotientExamples](../src/Orbifolds/QuotientExamples.agda) records the
corresponding nonidentity loop and automorphism comparison. This makes no
claim that every site has a nondegenerate two-element sheaf. The restricted,
nonunivalent set interpretation of the ordinary source fragment remains a
separate possibility. Proposition-code sethood therefore does not place a
full univalent universe among the current value-set objects.

The precise local obstruction needs only `Code : Type u`,
`El : Code -> Type v`, a specified c, and an explicit Cubical equivalence
`Φ : (c = c) ≃ (El(c) ≃ El(c))`. If the selected loop type is a proposition,
then for complete automorphism witnesses e and f the section law of Φ gives

```text
e = Φ(Φ^-1(e)) = Φ(Φ^-1(f)) = f.
```

The middle equality is congruence of Φ applied to propositionhood of the
loop type. Sethood of Code supplies exactly that propositionhood. Two
specified distinct automorphisms therefore contradict sethood. The code
and decoding levels u and v remain independent; the supplied comparison
lives at their maximum and performs no resizing. This compares whole
equivalence witnesses and needs only the self-instance of univalence at c.
It constructs neither that comparison nor a source universe. The independently
reviewed Cubical candidate is now written in
[UnivalentUniverseSetBoundary.agda](../src/Orbifolds/SemanticBridge/UnivalentUniverseSetBoundary.agda)
and has passed its full native gate. The checked scope is this conditional
Cubical statement. An application from ordinary sethood would retain the explicit
IdentityPath adapter rather than silently identify the two identity presentations.

`DedekindBooleanSheafAutomorphisms` has passed its complete native gate.
It constructs the locally constant sheaf on the explicit label type
`O.Lift realSiteLevel Bool`, using the existing Dedekind constant-sheaf
functor. Its negation map is the actual `delta-arrow`; functoriality and the
label involution give both inverse laws. Identity and negation are distinct
whole sheaf self-isomorphisms: evaluate the lifted-false constant section on
`wholeOpen` at the actual point `(zeroReal, tt)`, obtaining false and true
respectively. This also constructs distinct whole self-equivalences of the
complete certified whole-open section type. Labels and section values remain
at level 2, with small-set and sheaf records at level 3.

This is a witness on the constructed Dedekind site, not an assumption that
every site has a nondegenerate Boolean sheaf. The construction supplies the
sheaf and separated automorphisms, but no universe code, decoder identification,
or self-path/equivalence comparison. The external section type is not identified
with an internal decoded family. These sheaf automorphisms are separate from
the completed-bundle isotropy control and do not change the crisp, tininess or
properness boundaries of the joint-foundation audit.

`DedekindBooleanUniverseSetBoundary` has passed its complete native gate.
This conditional specialization retains explicit
`Code : Type u`, `El : Code → Type v`, a code c, a decoding equivalence
`e : El c ≃ Whole`, and the self-path comparison
`(c ≡ c) ≃ (El c ≃ El c)`. The pinned `equivComp e e` constructs an
equivalence between the two whole automorphism types, with forward map
`a ↦ e ∘ a ∘ e⁻¹`. Take its inverse images of the actual flip and identity.
If those images were equal, congruence of the forward map and its two section
equations would equate the already separated actual automorphisms. The checked
conditional boundary therefore forbids propositionhood of c's loop type and
sethood of Code. No decoder is silently replaced by a constant family.
Decoded values stay at v, actual whole-open sections at level 2, and their
comparison at the join of those levels; no equation between levels or resizing
is required. This supplies no code existence, native univalence computation,
internal decoded-family identification or source-substitution admission.

The retained conaled `SmallFamilyClassification`, `SmallFamilyDecoding` and
`SmallFamilySubstitution` sources motivate keeping the code context, decoder,
and substitution laws separate. Their raised cubical presheaf construction is
not assumed to classify these Agda sheaf families. The checked proposition-sum
comparison below identifies the constructed bounded sum code with χ of the
actual sum family. It does not supply the source universe or Y-code required
by the source constructor expression above.

#### Dependent proposition-sum constructor

[ExternalPropositionCodeSums](../src/Orbifolds/SemanticBridge/ExternalPropositionCodeSums.agda)
contains the small sum sieve, closedness, decoding equivalence,
dependent-code reindexing, code restriction equality and explicit decoder
square. The actual sum-family comparison below has passed its complete native
gate. The actual sum base-change and sum-code substitution below are also
checked. The identity specialization and its base-change/caller gates remain
independently pending.
The exact chart predicate is
`Σ (domain chart i x) (λ d → target chart i x d ≡ y)`.
Its domain is a proposition, and its equality fibers are propositions by setY.
This bounded constructor
therefore works with the existing proposition codes, without assuming a
general universe or a classifier.

For p : Code(U), a function `El_U(p) -> Code(U)` is insufficient: a local
witness over V -> U need not descend to U. Require actual dependent code data
at every probe, with its restriction equation:

```text
q(V,f,a) : Code(V)                 (f : V -> U, a : p.contains(f))
ν_(g;f,a) : g*q(V,f,a) = q(W,f∘g,p.downward f g a).
```

Here p.contains and p.downward denote its underlying sieve. The q data have
level suc ℓ, while their membership arguments have level ℓ. Define the
sum sieve by

```text
ΣΩ(p,q).contains(f) = Σ(a : p.contains(f)) El_V(q(V,f,a)).
```

This is an ordinary ℓ-small Σ of propositions. Its downward map takes
(a,b) to (p.downward f g a, subst El_W ν_(g;f,a)
(El-restrict g (q(V,f,a)) b)). There is no truncated-witness extraction.
With this membership definition, decoding at identity has the direct carrier

```text
El_U(ΣΩ(p,q)) = Σ(a : El_U(p)) El_U(q(U,id,a)).
```

Closedness has two stages. Given a cover R over V and local pairs (a_h,b_h)
along f∘h, Closed p at f constructs a : p.contains(f). Propositionhood of
p.contains(f∘h) identifies p.downward f h a with a_h. Appending congruence of
q in that witness to ν gives the actual code equality

```text
ρ_h : h*q(V,f,a) = q(W,f∘h,a_h).
```

Transport b_h along sym ρ_h, then identity-right h, then inverse
identity-left h. These terms supply the inclusion into the identity pullback
of q(V,f,a). Its Closed certificate over R constructs b : El_V(q(V,f,a)).
The pair (a,b) proves closedness of the sum sieve.

For f : V -> U, define `(f*q)(W,g,a) = q(W,f∘g,a)`. Its naturality follows
from ν, followed by the source Σ pair path for forward associativity
`((f∘g)∘h) = f∘(g∘h)`. This matches the actual forward-associativity
transport in Sv.pullback.downward; propositionhood handles its membership
certificate. The two sides of

```text
f*ΣΩ(p,q) = ΣΩ(f*p,f*q)
```

then have the same membership types. code-ext with identity membership maps
gives equality of the actual closed-code records. The decoder square
retains transport along that equality and compares it with the actual dependent
pair map from El-restrict and ν; propositionhood applies after these endpoints
are typed.

For the chart pattern, take an actual domain family A over Γ and the existing
identity family I over Γ.A for the actual target and endpoint terms. At x,
put p = χ_A(U,x) and q(V,f,a) = χ_I(V,(Γ(f)x,a)). Characteristic restriction
and the actual total-family pair transport construct ν. At each probe,
decoding χ_I followed by DependentSheafSums.Sum.pack gives the forward
membership map to χ_(Σ_A I); Sum.unpack followed by χ_I encoding gives the
reverse. code-ext therefore compares the constructed ΣΩ code with the
characteristic code of the actual sum family.

The checked comparison in
[ExternalPropositionCodeSumComparison.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionCodeSumComparison.agda)
implements this argument for actual proposition-valued families A and B and
has passed its complete native gate. Its decoder comparison at identity
retains a further total-family transport. A decoded pair initially has first component
`a : A(U, Γ(id)x)` and second component in the decoding of
`χ_B(U,(Γ(id)x,a))`. Put `a' = decode_A(a) : A(U,x)`. The identity law of Γ
and propositionhood of A give the actual pair path
`e : (Γ(id)x,a) = (x,a')`. Decode the second component at its original
point, transport that B-element along e, and then apply the existing
`Sum.pack U x` to this pair. The other side decodes the characteristic sum
after transport along the constructed code-comparison equality. Both sides
are now terms of the same actual sum fiber; its propositionhood is derived
from A, B and the existing pack/unpack inverse laws. That is the specified
decoder square, including its dependent transport.

##### Sum-code contextual substitution

**Checked construction.**
[ExternalPropositionCodeSumSubstitution.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionCodeSumSubstitution.agda)
has passed its complete native gate, retaining the following actual code equality
and decoder square. Its actual sum-base-change dependency is also checked. Fix the same C, J and small ext, actual small sheaves
Γ and Δ, proposition-valued A over Γ and B over total A, and an actual natural
map σ : Δ -> Γ. Instantiate
[DependentSheafSumBaseChange.On.Along](../src/Orbifolds/SemanticBridge/DependentSheafSumBaseChange.agda)
as BC. Its selected substitutions are

```text
Aσ = BC.First.reindexedFamily
σA = BC.First.lift
Bσ = BC.Second.reindexedFamily = B[σA].
```

Use this actual σA, including its naturality and display triangle.
Propositionhood is derived by the actual reindexing carriers:
`propAσ(U,δ) = propA(U,σ_U(δ))` and
`propBσ(U,z) = propB(U,σA_U(z))`. Instantiate the existing sum-code comparison
for (Γ,A,B) as Original and for (Δ,Aσ,Bσ) as Changed. Write their constructed
codes as KΓ(U,x) and KΔ(U,δ). Also instantiate
`Codes.Substitution Γ Δ BC.Original.family Original.sum-prop σ` as Sub.

The first new comparison is between the characteristic codes of
`BC.targetFamily` and `BC.sourceFamily`, both over Δ. At a probe f : V -> U,
their memberships are the respective actual family fibers at Δ(f)(δ).
The two inclusion maps for code-ext are exactly

```text
z ↦ BC.inverseValue (V,Δ(f)(δ)) z
z ↦ BC.forwardValue (V,Δ(f)(δ)) z.
```

Call the resulting equality eBC(U,δ), oriented from the changed sum's
characteristic code to the reindexed original sum's characteristic code.
The constructor equality is the explicit composite

```text
eΣ(U,δ) : KΔ(U,δ) = KΓ(U,σ_U(δ))
eΣ = Changed.code-comparison
     · eBC
     · Sub.substitution
     · sym Original.code-comparison.
```

Thus the second and third links do different work: actual base-change maps
compare the two families over Δ, and actual σ naturality gives characteristic
substitution. Neither equality of family records nor the desired code law is
an input.

Retain the selected decoder into the actual displayed sum:

```text
DΓ(U,x,z) = Original.Built.pack U x
              (Original.decode-pair (Original.Constructed.decode z)),
```

with the existing At(U,x) parameters understood, and similarly DΔ. The
required decoder square is

```text
DΓ(U,σ_U(δ), subst El_U eΣ(U,δ) z)
  = BC.inverseValue (U,δ) (DΔ(U,δ,z)).
```

Both endpoints inhabit the actual original sum fiber at σ_U(δ); its derived
`Original.sum-prop` proves the equation after these endpoints are typed.
The right side names the actual inverse map. `BC.inverse-pack` additionally
identifies its action on the actual packed pair; an unrelated equivalence
of fibers is insufficient. The existing `decode-pair` retains the total-family
identity transport described above.

If the result is exported as a whole mixed natural-map equation, give K its
restriction law by congruence of restriction applied to code-comparison,
then characteristic restriction, then inverse code-comparison. Mixed nat-ext
applied to eΣ gives `KΔ = KΓ ∘ from-small-nat σ`. Original contexts remain at
value level ℓ, while these code maps land at suc ℓ. This uses no cumulative
coercion and does not assert a source universe.

##### Identity code and endpoint substitution

For an actual small family Y over Γ and actual certified terms s and t,
instantiate
[DependentSheafIdentityFiberComparison.Context.Pair](../src/Orbifolds/SemanticBridge/DependentSheafIdentityFiberComparison.agda)
as I. This complete fiber theorem has passed its native gate. Its fiber-prop,
derived from the set-valued family, permits
`χI = Codes.Characteristic Γ I.family I.fiber-prop`. Define

```text
idCode(U,x) = χI.code U x
idDecode(z) = I.decode U x (χI.decode U x z)
idEncode(p) = χI.encode U x (I.encode U x p).
```

The two existing decoding equivalences compose to give both inverse laws.
Y need not be proposition-valued; its stagewise sethood supplies the required
proposition-valued identity fibers. This external identity-code wrapper is
source-written in
[ExternalPropositionIdentityCodes.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionIdentityCodes.agda)
and has passed its complete native gate after redirecting only its import to
the checked fiber theorem. It takes actual Y and terms; it supplies no Y-code.

Under σ, use the actual forwardValue and inverseValue from
[DependentSheafIdentityBaseChange.Along.Pair](../src/Orbifolds/SemanticBridge/DependentSheafIdentityBaseChange.agda).
Characteristic code-ext followed by Codes.Substitution gives

```text
eI(U,δ) : idCode_(s[σ],t[σ])(U,δ) = idCode_(s,t)(U,σ_U(δ)).
```

Let `εs = Values.substitute-value s U δ`, whose direction is
`s[σ](U,δ) = s(U,σ_U(δ))`, and define εt likewise. The decoder equation must
retain these actual endpoint paths:

```text
idDecode_Γ(subst El_U eI(U,δ) z)
  = sym εs · idDecode_Δ(z) · εt.
```

This is the direction of the existing inverseValue. Equality of the two
paths follows from the established equality-prop after the endpoints are
aligned; the substitution paths are not silently treated as reflexivity.
The actual code and decoder substitution statements are source-written in
[ExternalPropositionIdentityCodeSubstitution.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionIdentityCodeSubstitution.agda).
Their gate, the public reflexivity/equivalence gate and identity base change
remain pending; the independently checked fiber theorem does not accept them.

For the chart expression, take the identity family over the actual Γ.A and
substitute along σA. Identity base change compares `I[σA]` with the identity
family of the actually substituted target and endpoint terms. To pass this
comparison through the same first proposition code p, the small
sum-code congruence in
[ExternalPropositionCodeSumCongruence.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionCodeSumCongruence.agda)
has now passed its full native gate. Given actual code equalities
`ρ(V,f,a) : q(V,f,a) = r(V,f,a)` at every probe, code-ext proves
`ΣΩ(p,q) = ΣΩ(p,r)` using `(a,b) ↦ (a,subst El_V ρ(V,f,a) b)` and inverse
transports. Its decoder square retains that selected code equality and pair
map. This lemma does not choose local witnesses or assume a universe
constructor law. Its application is source-written in the chart-substitution
adapter below and keeps the pending family and code-constructor gates above.

This remains a proposition-code constructor. The ambient Y may be a
non-propositional set, so these codes do not supply Y-code. A constructed U_ℓ,
its uniform identity-code and ordinary J interpretation with substitution,
and the typed interpretation of the chart's code-valued context remain absent.
Neither χ of the fibers nor this constructor is a typed admission
of the source predicate judgment.

##### Composite chart-predicate adapters

**Source-written; native gates pending.**
[ExternalPropositionChartPredicateCodes.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionChartPredicateCodes.agda)
and
[ExternalPropositionChartPredicateSubstitution.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionChartPredicateSubstitution.agda)
contain the two independently reviewed constructions below. Neither adapter
has native acceptance. The complete identity-fiber theorem and identity-code
wrapper are checked. Substitution additionally
awaits the public reflexivity/equivalence theorem, identity base change and
identity-code substitution. The precise current queue is in `docs/work.md`.

For the first adapter, fix the existing ℓ, ext, C and J, an actual small Γ,
`A : Family Γ` with explicit propA, an arbitrary actual family Y over Γ.A,
and certified terms s,t of Y. No propositionhood of Y is assumed. Put

```text
Id   = IdentityCodes.Context(Γ.A,Y).Pair(s,t)
B    = Id.I.family
Comp = SumComparison.Context(Γ,A,B,propA,Id.I.fiber-prop)
Predicate(U,x) = Σ(a : A(U,x)) Id.I.Equality U (x,a).
```

Predicate is a proposition by isPropΣ, propA and Id.I.equality-prop. In
Comp.At(U,x), the actual second code is definitionally
`q(V,f,a) = Id.code V (Γ(f)x,a)`, with the existing total-family restriction
path supplying its naturality. Set `K(U,x) = Comp.At(U,x).Constructed.code`
and retain `eK = Comp.At(U,x).code-comparison`, oriented from K to the
characteristic code of Comp.Built.family.

The selected decoder first applies Constructed.decode and then
Comp.At.decode-pair, obtaining `(a,b)` in the actual ordinary sum over x;
it returns `(a,Id.I.decode U (x,a) b)`. The decode-pair step retains the
actual transport from Γ(id)x to x and must not be omitted. The encoder is

```text
encode(a,p) = subst (El_U) (sym eK)
  (Comp.Target.encode U x
    (Comp.Built.pack U x (a,Id.I.encode U (x,a) p))).
```

Predicate propositionhood and El-isProp give both inverse laws after these
actual endpoints are typed. Thus El_U(K(U,x)) is explicitly equivalent to
the branch-domain witness paired with equality of the two certified endpoints.
The code restriction equation is the chain

```text
cong (restrict-code f) eK(U,x)
  · Comp.Target.restriction f x
  · sym eK(V,Γ(f)x).
```

It constructs a mixed natural map `from-small Γ₀ -> codePresheaf`.
Mixed nat-ext applied to eK identifies that map with the canonical
characteristic map of the actual sum family. The existing restricted
classification then applies to that family and its derived Comp.sum-prop;
family recovery is an isomorphism over Γ, without equality of certificates.

For contextual substitution σ : Δ -> Γ, use exactly
`First = Families.Substitution Γ Δ A σ`, `Aσ = First.reindexedFamily` and
`σA = First.lift`. The changed predicate uses Y[σA] and the actually substituted
s,t. Instantiate IdentityCodeSubstitution along σA. At every probe and first
witness, use its **characteristic-base-change** at `(V,(Δ(f)δ,a))`. This ends
at the characteristic code of the reindexed original identity family,
which is exactly SumSubstitution.Changed.BCharacteristic at that point.
The full identity code-substitution theorem skips this needed intermediate
endpoint. Instantiate both sum comparisons with SumSubstitution's same Aσ
and propAσ, so that SumCongruence acts over one literal first code
`p = χ_Aσ(U,δ)`. The complete code equality is

```text
eChart : K_changed(U,δ) = K_original(U,σ_Uδ)
eChart = SumCongruence.code-congruence
         · SumSubstitution.At(U,δ).code-substitution.
```

For a decoded pair `(a,p)`, the actual substitution map preserves a and sends
p to `sym εs · p · εt`, where εs and εt are
IdentityBaseChange.Values.substitute-value at U,(δ,a). First.lift has actual
component `(δ,a) -> (σ_Uδ,a)`, so no further total-base path is needed at this
final pair. The decoder square compares this map with decoding after
`subst El_U eChart`; the original Predicate propositionhood proves equality
once both pairs have these exact endpoints.

These adapters take already-realized families and certified terms. For the
source chart, Y here must be the ambient target family reindexed to Γ.A,
and t must be the actual weakening of the endpoint y. The still-missing
admission concerns the original context with X,Y : Set ℓ, H, setY,
chart : BranchChart H, x : X, y : Y and
`i : Fin (branches chart)`, and its predicate body as a term of Set ℓ.
A fixed external i does not interpret that dependent finite-label context.
The constructed Γ-to-Ω_ℓ map classifies this particular small proposition;
it supplies neither arbitrary Y-code nor the full source universe and its
uniform identity/J interpretation. Ω_ℓ cannot replace Set ℓ when Y may be
non-propositional. No properness, crisp interpretation or realization of
higher isotropy follows from these code adapters.

##### Varying finite labels and the actual endpoint variable

The dependent finite-label display in
[DedekindFiniteLabelFamilies.agda](../src/Orbifolds/SemanticBridge/DedekindFiniteLabelFamilies.agda)
has passed its complete native gate. The constant-count construction below is
now source-written in `DedekindConstantCountLabels`,
`DedekindConstantCountContexts` and `DedekindConstantCountFamilies`. The Labels
owner has passed its complete native gate; the context comparison and complete
family comparison retain their distinct pending gates. The varying-label
context, endpoint-predicate and substitution adapters are now source-written
in `DedekindFiniteLabelContextBaseChange`,
`DedekindFiniteLabelChartPredicate` and
`DedekindFiniteLabelChartPredicateSubstitution`, all pending their complete
native gates; none admits the generic `BranchChart`
context. On the actual Dedekind site put
`λ = DedekindRealOpens.realSiteLevel = suc (suc zero)`. Use the source's
own universe-polymorphic `FiniteBranchAtlas.Fin` and define

```text
N₀ = O.Lift λ Nat
E₀ = O.Σ N₀ (λ n → Fin {λ} (O.lower n))
π₀ = O.fst : E₀ → N₀.
```

Both carriers are at exactly λ. Lifted Nat is a set by its explicit
lower/lift retract. The actual source Fin has decidable equality in
`FiniteSeparation.fin-equality`; `IdentityPath` converts its ordinary
equality and empty-type negation to the Cubical discreteness/sethood proof.
The total E₀ requires **general Sigma sethood**, obtained through the
explicit ordinary-Sigma/Cubical-Sigma retract. `O.isSetΣProp` is not
applicable: the Fin fibers are not propositions in general.

The existing `DedekindConstantSheafFunctors.delta-object` and `delta-arrow`
then construct actual sheaves N and E and an arrow π:E→N. Apply
`SheafDisplayFamilies.On.Display` to that arrow to obtain FinBase.family.
For a small sheaf context B and an actual varying count map n:B→N, use
`DependentSheafFamilies.Substitution` to construct Fin(n)=FinBase.family[n],
its total Γᵢ=B.Fin(n), and its display πᵢ:Γᵢ→B. The existing
`DependentPresheafSections.Variable` constructs the finite-label variable
over this total context, including its actual pair-variable equation.
No count, label, display family or section is supplied as the desired output.

The exact stage fiber at an open U and context section γ is

```text
Σ e : LC(E₀)(U). delta-arrow π₀ U e = n_U γ.
```

Thus labels vary locally over the given locally constant count section.
Even over constant k the appropriate comparison is with δ(Fin k), not
with a bare fixed finite set at every open. Disconnected opens allow
varying labels. At the empty open, the displayed section fiber is
contractible even for count zero, whereas external Fin 0 is empty.
The constant-count comparison needs its own actual sheaf maps and inverse
laws; the checked display alone does not prove it. Nor does this display
construct an NNO eliminator or a universe code for the finite family.

A concrete constant-count comparison has been reviewed and written as pending
source. For k:Nat, the checked
`DedekindLocallyConstantPullbacks.Cospan` on the label maps
`E₀ → N₀ ← Unit λ`, namely fst and the constant lift k, supplies an
actual isomorphism between δ of the label pullback L and the sheaf
pullback of those actual delta arrows. Its label carrier is

```text
L = Σ (e,u) : E₀ × Unit λ. fst e = lift k.
toFin(e,u,q) = subst (λ n → Fin (lower n)) q (snd e)
fromFin(i) = (((lift k,i),tt),refl).
```

The Fin roundtrip is reflexivity. For the L roundtrip, the existing
PullbackSections label-path uses `sym (O.Σ-path q O.refl)` on e and
`O.isPropUnit tt u` on u. Its equation proofs are compared using sethood
of N₀; no Fin fiber is assumed propositional. Applying the existing
isSetRetract to the actual Fin k retract of the label SmallSet constructs
the needed Fin-k SmallSet certificate; no private export from the
finite-family constructor is required. Applying the existing
delta-arrow to both maps supplies actual natural transformations.
Their whole-map inverse laws are the chain sym(delta-compose), congruence
of delta-arrow on the ordinary function equality, and delta-identity.
Compose this isomorphism with the actual locally constant pullback
comparison, retaining its projection equations. The label maps, both label
inverse laws, Fin-k SmallSet and both whole delta-map inverse laws are now
accepted in `DedekindConstantCountLabels`. This does not by itself accept the
subsequent context, displayed-family or certified-term comparison.

The chosen terminal sheaf is a different record from δ(Unit λ).
`DedekindLocallyConstantFiniteProducts` supplies the actual maps
t:δUnit→terminal and s:terminal→δUnit and both inverse laws. If c is the
constant label delta arrow, choose n_k=c∘s. The equation n_k∘t=c follows
from the actual inverse law. Two `SheafPullbackConstruction.lift` maps
then transport the pullback along this terminal isomorphism; lift-first,
lift-second and morphism-ext give the triangles and whole inverse laws.
The current implementation uses the independent
[actual pullback-leg constructor](presheaves.md#changing-one-leg-of-an-actual-sheaf-pullback),
specialized at this terminal isomorphism and count-on-unit equation. Its
generic proof has passed its complete native gate and was durably published
before the concrete specialization changed. TerminalChange now opens that
actual constructor with the terminalComparisonIso and count-on-unit arguments.
The inverse lift uses the helper's derived commuting witness; no judgmental
equality with the previous witness is asserted. All subsequent context, family
and certified-term proof bodies are retained.

For the actual `Along.context terminal n_k`, the checked
`PresheafDisplayBaseChange.On.Change` already constructs the direct comparison
to the literal pullback of countProjection and n_k. Instantiate it at the
underlying natural, terminal and finite-label presheaves with those two maps.
Its reindexed family is the actual Along family's underlying presheaf family.
The comparison sends `(u,(e,q))` to `((e,u),q)` and reconstruction reverses
that rearrangement. Both whole-natural-map inverse laws and both projection
equations are already checked. Since each endpoint has its actual sheaf
certificate, package these same maps and laws as a sheaf isomorphism without
equating those certificates. This removes the need for the previously planned
extra first-leg pullback change through total(finiteFamily).

Compose this direct comparison with the terminal-leg change, the actual
locally constant pullback comparison and the label δ-isomorphism. The result
is the proposed actual context comparison with δ(Fin k). Its display equations
come from the terminal maps; its original-label equation retains the embedding
`i ↦ (lift k,i)`, using comparison-first and the actual delta-compose law.
The current source carries out the inverse-map algebra componentwise in
the underlying presheaf category. The selected maps remain exactly
`(Labels.inverse ∘ LocalPullback.inverse) ∘ TerminalChange.inverse` and
`TerminalChange.forward ∘ (LocalPullback.comparison ∘ Labels.forward)`.
For the forward/inverse composite, apply the accepted TerminalChange
inverse-forward equation under the actual LocalPullback.inverse and
Labels.inverse components, then cancel LocalPullback by inverse-comparison,
then Labels by inverse-forward. For the reverse composite, use Labels
forward-inverse, LocalPullback comparison-inverse and TerminalChange
forward-inverse in that order. The existing PS.nat-ext turns these pointwise
equations into equalities of the whole natural transformations. Compose the
actual context comparison first: its comparison-reconstruction equation
and the first pullback law prove one inverse, while the reverse pullback law
and reconstruction-comparison prove the other. The existing
SheafIsomorphismConstruction.fromNatInverse packages those exact maps and
laws as the final sheaf isomorphism. This revision removes only private
intermediate isomorphism records; it preserves public maps and statements
while deliberately replacing their inverse-law witnesses. Sheaf identities, composition and homs
are these underlying presheaf operations, so no certificate equality or extra
faithfulness premise is needed. This interface retains the literal maps and
their parentheses while keeping sheafhood out of the intermediate algebra.
For the displayed-family comparison use Change.familyIso followed by the
actual PresheafDisplayMaps induced by these maps over the terminal sheaf.
Their inverse laws follow from natural-map extensionality, the existing
fiber-path lemma and the whole context inverse laws. The resulting stage
comparison is with locally constant Fin-k sections, including disconnected
and empty opens. The exact owners can be reopened without changing the checked
finite-family module's exports. Values remain at level 2 and records at level 3.
No finite-limit-preservation premise, global label choice or identification
of independent total-space records is inserted in this argument.

The certified comparison term uses the actual inverse map into the Along
context and its display triangle. Read this map with the existing
`DependentPresheafSections.Comprehension` over the terminal map from δ(Fin k).
The existing pair-read equation gives its pairing exactly as that inverse;
postcomposition by the forward comparison gives the whole identity map.
The existing unique theorem gives equality of whole certified terms with that
same pairing. The old Along.Variable.term remains related by its pair-variable
equation composed with the actual inverse. This statement concerns the
once-reindexed family; it does not silently identify it with an iterated
variable substitution. The literal read-component equation exposes the
transport along the supplied display triangle. The extra certificate loop in
term-value is removed by the domain presheaf's existing value-set, with no
assumed nat-ext computation or propositionhood of Fin fibers. Applying the
stage comparison to this value recovers the input finite-label section by
section-reconstruction and the whole coordinate equation. The generic loop
calculation has its own accepted `DependentPresheafComprehensionComputation`
owner; its argument is in
[Presheaves](presheaves.md#certified-comprehension-values).
The constant-count sources retain all these actual maps and equations. The
context owner now contains the construction through label-computation, and the
full Families owner reexports it and retains the displayed-family/term proofs.
The preceding complete source and its unsuccessful diagnostic were preserved
before this ownership split. The revised componentwise context proof's complete
6G/900-second gate ended with native -9/wrapper 247 after 580.951 seconds,
maximum RSS 6427628 KiB, stable matching source/copies, no guard refusal and
no target Finished marker. Its real/sheaf prerequisites finished their cold
rebuild. There was no heap-exhaustion message, identified kill cause or
declaration timing. Both revised gates remain pending; older receipts do not
apply to them and the full
family gate was not run behind the pending context gate. The accepted
label comparison and generic computation lemma do not accept this combined
family and term construction.

There is a subsequent substitution argument in one precisely fixed family.
Write B for the terminal presheaf, D for the underlying delta(Fin k), A for
the actual Along family, b:D→B for the terminal map, t for the comparison
term, and R for Comprehension B D A b. For an actual tau:Theta→D, put
F=R.reindexed and S=Comprehension D Theta F tau. The existing substitute
constructs u:Term Theta S.reindexed, in the literal twice-reindexed family
(A[b])[tau]. The accepted substitution-pair equation and associativity give

```text
R.Built.lift ∘ S.pair u = R.pair t ∘ tau = inverse ∘ tau.
forward ∘ (R.Built.lift ∘ S.pair u) = tau.
```

The accepted substitute-value equation followed by decoded-computation gives
the stage value tau_U(theta). S.unique gives whole certified-term uniqueness
from the exact hypothesis S.pair v = (fst t) ∘ tau, using the actual
over-base certificate from substitute. Uniqueness from only the further
composite with R.Built.lift would require an extra projection argument.
These are available proof plans after the concrete comparison passes. Comparing
instead with the direct read in A[b∘tau] requires the explicit once/twice family
comparison and its pairing law. DependentFamilyReindexingLaws and
DependentTermPairComposition are now accepted; the inverse pairing equation
followed by Direct.unique supplies the stated comparison once the concrete
term is available. The separate certified-term substitution laws have now
passed their complete native gate. No equality of reindexed presheaf records is silently inserted.

A reviewed ownership boundary separates the actual context comparison through
label-computation into DedekindConstantCountContexts, while
the full Families owner retains the displayed-family and certified-term bodies.
The context owner exposes the actual terminal pullback, the two intermediate
maps and both inverse laws as its support interface. Its Change facade needs
only the total comparisons; the family owner selects forward/inverse/familyIso
from the identical accepted module tuple. The specialized Along.Variable
facade belongs only to the family/term owner, where both original variable APIs
are retained. All context data stay transparent, and no desired comparison
becomes an input. This is a source-written checking boundary, not a claim about the
declaration responsible for the current resource failure.

To specialize the predicate, take A:Family Γᵢ with explicit propA, an
actual arbitrary set-valued family Y_B over B and its certified endpoint
y. The endpoint can itself be the canonical variable in a preceding
total-context extension. Form the actual weakenings Yᵢ=Y_B[πᵢ] and
YᵢA=Yᵢ[π_A]. A natural target section over Γᵢ.A gives the certified term
s by `DependentPresheafTermSections.Comparison.fromSection`. The second
certified term is t=(y[πᵢ])[π_A]. Retain the actual value equations

```text
εs : value(s) = target-value
εt : value(t) = value(y),
```

using fromSection-value and the two successive substitute-value paths.
ChartCodes on Γᵢ,A,propA,YᵢA,s,t decodes to `(d,p)` with
`p:value(s)=value(t)`. The comparison to the literal chart predicate sends
it to `(d,sym εs · p · εt)`; the inverse sends `(d,r)` to
`(d,εs · r · sym εt)`. Derived propositionhood proves both inverse laws
after these endpoints are aligned. The existing decode-pair transport is
still part of the first decoding step.

For τ:B′→B, substitute along the actual lifted context map
τᵢ:B′.(Fin(n)[τ])→B.Fin(n); do not hold an external label fixed.
If the new finite family is constructed directly as Fin(n∘τ), compare it
with Fin(n)[τ] using `DependentFamilyReindexingLaws.Composite.comparison`
and lift that isomorphism to the totals and display equations using
`DependentSheafFamilyIsomorphisms`. Endpoint weakening additionally needs
`DependentTermSubstitutionLaws.Composite.law`, whose native gate has now
passed. The chart-code substitution adapter then applies along the
actual τᵢ, retaining its own pending gate and endpoint-conjugation paths.

These constructions now have the three pending source owners named above.
`DedekindFiniteLabelContextBaseChange.Along` supplies the actual τᵢ,
direct/iterated family isomorphism, total-context isomorphism, both whole
inverse laws, display equations and component equations. Its existing
prerequisites are all accepted. `DedekindFiniteLabelChartPredicate.Context`
constructs both weakenings and uses an actual natural target section to
construct its certified term; its At module gives the code, decoder, encoder
and both inverse laws. `VariableEndpoint` constructs the canonical variable
instance on the preceding comprehension total. The substitution owner retains
the exact code paths and decoder transports, along with the lifted domain
map and endpoint once/twice comparisons. Its DirectCodes comparison is generic
chart substitution along the constructed direct label lift. It does not yet
identify that code with an independently rebuilt Context over B′ with
Y[τ] and endpoint[τ]. That reconstruction comparison, full identity/composition
coherence and the existing pending chart-code and certified-term gates remain
separate obligations. No constant-count comparison is a prerequisite here.
The decoded predicates remain at the small value level; their proposition
codes retain the existing successor level without resizing.

**Reconstruction comparison: current proof plan, not implemented or accepted.**
There is a concrete route from the direct-lift code to the independently
rebuilt Context. Write Gamma for the old label context, Gamma′ for
Labels.Direct.context, pi and pi′ for their actual projections, lambda for
Labels.direct-lift and q:pi∘lambda=tau∘pi′ for the constructed display square.
Put Y′=Y[tau] and e′=e[tau] using the actual family and certified-term
substitutions. The independent Context B′ direct-count Y′ e′ has the same
Labels.Direct.context and projection by these definitions.

Construct the endpoint-family isomorphism beta by the chain

```text
Y[pi][lambda]
  -- inverse Composite(pi,lambda) --> Y[pi∘lambda]
  -- contextIso(q)                --> Y[tau∘pi′]
  -- Composite(tau,pi′)           --> Y[tau][pi′].
```

Here contextIso and contextMap are the accepted
DependentFamilyReindexingCoherence operations. They retain the actual equality
q of context maps, rather than identifying different family records. The
corresponding whole-term comparison beta_*(e[pi][lambda])=e[tau][pi′] uses
the accepted substitution-law owner's inverse-term-law, then the small lemma
contextMap(p)_*(substitute sigma t)=substitute tau t for p:sigma=tau, then
its forward composite law. The small lemma is proved by ordinary identity
elimination on p; at refl the accepted term-map identity law applies.
Accepted term-map composition expands the composite family map.
The small lemma is now source-written as
DependentTermSubstitutionEquality.On.substitute-context-equality and remains
pending its own native gate; it imports only accepted prerequisites.

Retain the actual domain A′=A[lambda] with propositionhood inherited at
lambda(delta). Let rho and rho′ be the displays of Gamma.A and Gamma′.A′,
and lambda_A their constructed substitution lift, with actual square
rho∘lambda_A=lambda∘rho′. Applying the same family-comparison recipe to
Y[pi] and that square gives

```text
chi : (Y[pi][rho])[lambda_A] ≅ (Y[pi][lambda])[rho′]
Psi = beta[rho′] ∘ chi
    : (Y[pi][rho])[lambda_A] ≅ (Y[tau][pi′])[rho′].
```

Reindex both maps and their inverse equations with the accepted Along.map.
Each endpoint retains its actual sheafhood certificate. The endpoint term
comparison follows from the square theorem for chi, accepted naturality of
term maps under substitution, and the beta endpoint comparison. For the
original certified target s, form u=Psi_*(s[lambda_A]) and supply
rebuiltDomain.Sections.toSection u to the independently rebuilt Target.
The accepted from-toSection equation identifies its resulting target term
with u. Thus its target section and both term comparisons are constructed.

At each actual domain point, let phi be the forward component of Psi. The
term comparisons and map-value give paths c_s:phi(s_old)=s_new and
c_t:phi(t_old)=t_new. The identity-predicate map sends
p to sym(c_s) . cong(phi)(p) . c_t, retaining the domain witness a.
The inverse component and its inverse law give injectivity of phi and hence
the reverse predicate map; propositionhood supplies both inverse laws.

Compare code membership at every f:V→U, not only decoded truth at (U,delta).
The accepted CodeAmalgamation.member-to-El converts membership to decoding
of the restricted old code. Transport along its actual restriction equation,
decode, apply the predicate map at delta restricted along f, encode with the
rebuilt code, transport back along its restriction equation, then apply
El-to-member. The reverse predicate map gives the reverse inclusion.
Codes.code-ext produces equality of the actual closed-sieve code records,
and mixed natural-map extensionality gives the code-valued map comparison.
This uses only the public code restriction/decoder APIs and keeps the sum
decoder transport. A final decoder square retains Existing.DirectAt.decode
and the selected code equality: convert its literal predicate using the two
substitute-value equations, apply the Psi identity comparison and rebuilt
from-coded, then use propositionhood at the common rebuilt predicate.

The necessary varying-label and chart-code/substitution gates remain pending,
including their identity-code/base-change chain. The generic certified-term
identity/composition laws are now accepted. The small context-equality term
lemma is source-written and pending native evidence; this complete
reconstruction adapter still needs source implementation and its own gate.
No identity-endpoint gate or
constant-count construction is a premise of this route. Context/family values
and terms remain at level 2, sheaf/family records at 3, proposition codes at 3
and their decodings at 2, using the existing mixed-level code-map interface.
This plan adds no arbitrary-Y code, source universe or BranchChart admission.

The original generic context has a further size obligation:
`H:X→Y→Set ℓ` and `BranchChart H` live at `Code ℓ = suc ℓ`, and
X,Y:Set ℓ range over successor-level data. They are not already objects
of the current same-level small-context interface. Mixed presheaves alone
do not supply mixed dependent families or the missing universe decoder.
Although the predicate body does not inspect H or hom-equivalence, those
fields still belong to the original context; factoring the expression
through its used data is a weakening theorem, not record admission.

The remaining interpretation must construct an actual Uℓ with decoding
for non-propositional Y, the code-valued H and BranchChart record, the
finite-family code where the source requires it, sum/identity code
operations with decoding and substitution, and the dependent function
into the larger universe in `Fin (branches chart) → Set ℓ`. Its context
extensions must respect the displayed levels. Ordinary J for the broader
source fragment remains separate. The restricted varying-label and
endpoint construction supplies useful missing semantic data without
identifying Ωℓ with Set ℓ or assuming a desired model.

#### Mixed-level small-proposition code object

**Checked constructions.** The matching-component
amalgamation is in
[ExternalPropositionCodeAmalgamation.agda](../src/Orbifolds/SemanticBridge/ExternalPropositionCodeAmalgamation.agda);
the mixed-value interface and exact-carrier adapters are in
[MixedLevelSheaves.agda](../src/Orbifolds/SemanticBridge/MixedLevelSheaves.agda).
[PropositionCodeSheaves.agda](../src/Orbifolds/SemanticBridge/PropositionCodeSheaves.agda)
constructs the code sheaf, decoded total, display and its specified small fibers.
[PropositionCodeFamilyPullback.agda](../src/Orbifolds/SemanticBridge/PropositionCodeFamilyPullback.agda)
constructs the heterogeneous pullback below. All four targets have passed
their complete native gates; the ledger and applicable receipts determine
the accepted source identities and import closures.

Separate the presheaf value level v from the unchanged original
`C : Category ℓ ℓ` and topology J.
A parallel interface suffices; existing small presheaves and sieve-presheaves
retain their exact carriers at v = ℓ. No site lifting is needed. The levels are

```text
MixedPresheaf C v : Type (ℓ ⊔ suc v)
Nat(F_v,G_w) : Type (ℓ ⊔ v ⊔ w)
Amalgamation_v(F,U,R,α) : Type (ℓ ⊔ v)
IsSheaf_v(J,F) : Type (suc ℓ ⊔ v).
```

Coverage still ranges over the original ℓ-valued sieves. Larger-level function
extensionality, if needed, must be derived through IdentityPath/Cubical, not
obtained by applying the supplied small `ext : FunExt ℓ ℓ` outside its scope.

At v = suc ℓ, the actual Code, restrict-code, code-isSet and restriction
laws from ExternalPropositionCodes form the Ω_ℓ presheaf. Its sheafhood
is supplied by the following construction. Let α match codes on a covering sieve
R of U, write c_(f,r) = α_V(f,r), and retain its actual naturality equation

```text
ν_(h;f,r) : h* c_(f,r) = c_(f∘h, R.downward f h r).
```

For a code c, `El(h*c) = c.contains(h∘id)`; transport by identity-right h
converts this into c.contains(h), and its symmetry gives the reverse map.
Changing (f,r) along an arrow equality uses ordinary Σ-path-prop for R's
membership proofs, then congruence of α and transport of El.

For g : V -> U define the witness sieve and glued membership by

```text
E_g(h : W -> V) = Σ(r : R(g∘h)) El_W(c_(g∘h,r))
S.contains(g) = J.Cover(E_g).
```

Both displayed memberships are ℓ-propositions: E_g(h) is an ordinary Σ of
propositions, and J supplies cover-prop for S.contains(g). Although α takes
values at suc ℓ, its displayed El fibers remain
at ℓ. E_g downward closure uses actual El-restrict, then ν, then the
associativity transport from (g∘h)∘k to g∘(h∘k). No witnesses are selected
from coverage or from a propositional truncation.

Associativity gives `E_(g∘k) ⊆ k*E_g`; its symmetry gives
`k*E_g ⊆ E_(g∘k)`. These inclusions transport both the R witness and the
El witness through the source Σ pair path. S downward closure applies
covers-pullback to Cover(E_g), then covers-upward with the second inclusion.
For closedness, a cover Q on V and Q(h) -> Cover(E_(g∘h)) give
Cover(h*E_g) using the first inclusion. covers-local then gives Cover(E_g).
Thus S has an actual Closed certificate.

For f : V -> U with r : R(f), recover `f*S = c_(f,r)` by code-ext.
At g : W -> V, Cover(E_(f∘g)) implies c_(f,r).contains(g): each E witness
at h yields c_(f,r).contains(g∘h), by associativity, inverse ν_(g∘h;f,r),
and identity-right. Apply the code's closedness at g. Conversely, membership
at g supplies all E_(f∘g) witnesses: use downward closure, inverse
identity-right, ν, and inverse associativity; R.downward f (g∘h) r supplies
the R component. Hence top is included in E_(f∘g), so covers-top and
covers-upward give its coverage.

For uniqueness, let d restrict to the same matching codes. S(g) implies
d.contains(g) by closedness of d over E_g, transporting each local witness
along the inverse restriction comparison and identity-right. Conversely,
d.contains(g) gives an inclusion g*R ⊆ E_g using downward closure and the
forward restriction comparison. Since g*R covers, E_g covers. code-ext gives
the required equality of whole codes. These constructions supply chosen glue,
restriction equations and glue-unique in the existing Amalgamation style.

The specified decoded total is

```text
D(U) = Σ(c : Code(U)) El_U(c)
D(f)(c,a) = (restrict-code f c, El-restrict f c a).
```

D(U) has level suc ℓ, while its specified dependent fibers have level ℓ.
Sethood uses isSetΣProp with code-isSet and El-isProp; identity/composition
laws use Σ-path-prop and the actual code laws. Projection to Code is natural
by definition; no general family universe is needed for this particular display.

Original value-ℓ sheaves remain at v = ℓ. Their comparison with D -> Ω_ℓ
at v = suc ℓ uses the explicit heterogeneous pullback argument below:
there is no cumulative coercion between these fixed-value categories.

To glue a matching D-family, first project it to matching codes and obtain
c with comparisons `ρ_f : f*c = c_(f,r)`. Transport each supplied local
witness along `sym ρ_f`, then identity-right f, obtaining c.contains(f).
Transport by `sym(identity-left f)` to obtain c.contains(id∘f).
Closed c at id, over the original covering R, now supplies a : El_U(c).
The pair (c,a) restricts correctly by Σ-path-prop with base path ρ_f;
uniqueness follows from code uniqueness and El-isProp. The witnesses and
transports here are the actual ones, not unrelated endpoint equivalences.

For the specified display, its ordinary fiber over c is
`Σ(z : D(U)) (fst z = c)`, at level suc ℓ. Decode `(z,e)` by transporting
`snd z` along e in El; encode a as `((c,a),refl)`. Code sethood and
El-isProp prove this actual fiber proposition-valued, so the two inverse
laws follow from reflexive decoding and fiber propositionhood. This is a
chosen equivalence with the particular small El_U(c), not a general
resizing principle.

The heterogeneous pullback argument can retain the original small total
family. For an actual small sheaf Γ and family A with explicitly
proposition-valued component fibers, let `χ : Γ -> Ω_ℓ` be its constructed
characteristic map. Define `Φ : total A -> D` by
`Φ_U(x,a) = (χ_U(x),encode_A(U,x,a))`. Its naturality is Σ-path-prop over
the actual characteristic restriction equation. The full natural-map
square `display ∘ Φ = χ ∘ projection_A` is pointwise reflexive.

For an arbitrary value-level test presheaf K and an actual cone
`g : K -> Γ`, `h : K -> D`, take the component of its square as
`e_k : fst(h_U(k)) = χ_U(g_U(k))`. The unique lift is

```text
lift_U(k) = (g_U(k),
  decode_A(U,g_U(k), transport El e_k (snd(h_U(k))))).
```

Naturality uses Σ-path-prop with g's naturality and the supplied
propositionhood of A. The first triangle is pointwise reflexive; the
second uses Σ-path-prop with `sym e_k` and El-isProp. Any competing lift
with the same first triangle is equal by Σ-path-prop in the actual
small total and natural-map extensionality. Thus no higher-level test
presheaf is silently coerced into the small category, and uniqueness
uses this family's explicit fiber hypothesis, not a converse from
arbitrary categorical monicity. These are the actual maps and universal
property in the checked heterogeneous pullback construction.

This constructs Ω_ℓ at value level suc ℓ with a specified ℓ-small
proposition display. It does not classify arbitrary suc ℓ propositions or
categorical monomorphisms without an additional smallness/classification
theorem. The checked recovery result below concerns the specified small
proposition families over a fixed small Γ; no resizing, full U_ℓ, or typed
source admission is claimed.

#### Reverse classification for small proposition families

**Checked constructions; restricted recovery.**
[PropositionCodeDecodingFamily.agda](../src/Orbifolds/SemanticBridge/PropositionCodeDecodingFamily.agda)
constructs the actual small family and its own total sheaf by the direct Closed
argument below.
[PropositionCodeClassification.agda](../src/Orbifolds/SemanticBridge/PropositionCodeClassification.agda)
constructs the two recovery comparisons, reusing the existing
PropositionCodeFamilyPullback characteristic map. Fix the same original C, J and
small ext, a small sheaf Γ with underlying presheaf G, and an actual mixed map
`χ : Nat (from-small G) codePresheaf`. Write `k_U(x) = χ_U(x)` and retain its
actual naturality path

```text
ν_f(y) : restrict-code f (k_U(y)) = k_V(G(f)(y)).
```

Construct a small presheaf Aχ₀ on the existing category of elements of G by
`Aχ₀(U,x) = El_U(k_U(x))`. The actual element-category arrow
`(f,q) : (V,x) -> (U,y)` has `q : G(f)(y) = x`, as defined in
[PresheafElements](../src/Orbifolds/SemanticBridge/PresheafElements.agda).
Its restriction map sends a to

```text
subst El_V (ν_f(y) · cong k_V q)
  (El-restrict f (k_U(y)) a).
```

The target El fiber is a proposition. This gives sethood and the presheaf
identity/composition equations after the actual endpoints are typed; Γ is
not assumed proposition-valued. Let Tχ be the actual
`DependentPresheafTotal.Total G Aχ₀` presheaf. Its stage carrier is exactly
`Σ(x : G(U)) El_U(k_U(x))`. There is an actual mixed map
`Φ : from-small Tχ -> decodedPresheaf` with
`Φ_U(x,a) = (k_U(x),a)`. Its naturality is Σ-path-prop for El applied to ν;
no judgmental simplification of the second restriction witness is needed.
The square with the two actual projections is pointwise reflexive.

To supply Aχ₀'s required total-sheaf certificate, take an ordinary matching
map `α : Nat (sieve-presheaf R) Tχ` on a covering R of U. Project it through
Tχ's actual display and use Γ's chosen amalgamation, obtaining b with

```text
bρ(V,f,r) : G(f)(b) = fst(α_V(f,r)).
```

Set `c = k_U(b)` and let S be its underlying closed sieve. Actual naturality
of χ followed by the base restriction equation gives

```text
ρ(V,f,r) = ν_f(b) · cong k_V (bρ(V,f,r))
          : restrict-code f c = k_V(fst(α_V(f,r))).
```

The actual local second witness is `a_f = snd(α_V(f,r))`. Transport it by
sym ρ to `El_V(restrict-code f c) = S.contains(f∘id_V)`, then by
identity-right f and inverse identity-left f. This supplies the exact
inclusion required by closedness at the identity:

```text
local : Included R (pullback id_U S)
local(V,f,r) =
  subst (S.contains) (identity-right f · sym(identity-left f))
    (subst El_V (sym ρ(V,f,r)) a_f).

a = (snd c) U id_U R cover local : El_U(c)
smallGlue = (b,a).
```

Both identity laws are needed here: the endpoint for Closed is
`S.contains(id_U∘f)`, on the original covering R. The small total proof uses
Γ's chosen amalgamation and the existing closedness certificate of c;
it requires no code or decoded mixed amalgamation.
Σ-path-prop applied to bρ proves every restriction equation for smallGlue.
For a competing total section z with the same restrictions, congruence of
fst gives its base restriction equations. Γ's glue-unique gives
`b = fst z`, and Σ-path-prop gives `smallGlue = z`. This constructs the exact
ordinary `Sh.IsSheaf J Tχ.presheaf`, hence an actual
`Families.Family Γ` with presheafFamily Aχ₀ and its own total-is-sheaf
certificate. The witness a is constructed from the supplied local sections,
with the displayed transports; no merely existing witness is selected.

Now form `Char = Codes.Characteristic Γ Aχ propAχ`, with propositionhood
given by El-isProp. At U,x put c = k_U(x). The characteristic sieve's
membership at f : V -> U is `El_V(k_V(G(f)(x)))`. To recover c, code-ext
uses these two actual maps:

```text
forward z = subst (c.contains) (identity-right f)
              (subst El_V (sym ν_f(x)) z)

backward z = subst El_V ν_f(x)
               (subst (c.contains) (sym (identity-right f)) z).
```

The intermediate carrier is
`El_V(restrict-code f c) = c.contains(f∘id)`. Thus identity-right has the
displayed direction; no identity-left adjustment occurs in this recovery.
The result is equality of actual code records `Char.code U x = χ_U(x)`.
Mixed nat-ext lifts these pointwise equalities to equality of the actual
characteristic natural map and χ.

For the other recovery direction, start with an actual small family A over Γ
and explicit propA, and use its existing characteristic natural map. The
reconstructed family has fibers `El_U(CharA.code U x)`. Its map to A is
`CharA.decode U x`; its inverse is `CharA.encode U x`. Both are natural on
the actual element-category arrows because the respective target fibers are
propositions. The existing decode-encode and encode-decode equations, with
small natural-map extensionality on the element category, give an actual
family-presheaf isomorphism. Applying
[DependentSheafFamilyIsomorphisms.Context.Comparison](../src/Orbifolds/SemanticBridge/DependentSheafFamilyIsomorphisms.agda)
to that isomorphism supplies the actual total sheafIso and both display
equations. The family result is an explicit isomorphism over Γ; chosen
sheafhood certificates are retained, without asserting equality of family
records.

The reconstructed family and total have stage values at ℓ, while their
presheaf/family/sheaf records live at suc ℓ. Code and Decoded stage values
are at suc ℓ and their mixed presheaf/sheaf records at suc(suc ℓ). The mixed
map χ and its natural-map equality are at suc ℓ. This is restricted to
maps into this particular code object and the specified ℓ-small proposition
families over the fixed small Γ. It gives neither a converse for arbitrary
categorical monomorphisms nor resizing, a full source universe, J, or extra
contextual coherence. Both reconstruction and classification have passed
their complete native gates for these stated constructions. Code recovery is
equality of the actual mixed natural maps; family recovery is the explicit
family-presheaf and total-sheaf isomorphism over Γ, with both display equations,
not equality of the chosen family certificates. Sum-code substitution is now
checked, as are the complete identity-fiber comparison and identity-code
constructor. Public reflexivity, identity-family base change and identity-code
substitution remain pending. The full source-universe, Y-code, ordinary J and typed
source-admission gaps remain.

#### Attachment of the constructed bundle comparison

`CechTorsorBundleBaseChange` connects the full comparison between gauges and
maps of independent principal actions to the actual parameter and refinement
maps. Under a continuous parameter map, restriction commutes with both gluing
and recovery, and the total-space square retains the base projection. Under a
local-section refinement `r:D->C`, mere coverage of D suffices to construct an
equivalence on gauge types whose forward function is the existing restriction.
Its inverse is coarse recovery after fine gluing; equality of the resulting
whole equivariant maps follows from recovery injectivity. The proof and exact
topological scope are in [Descent](descent.md). Source acceptance is determined
by the ledger, not by this attachment to the semantic argument.

These maps provide concrete arrow components for a probe-indexed groupoid
comparison. Assembling that comparison still requires the object pullback with
its actual topology and regularity, whole restriction functors with identity
and composition laws, and compatibility of the dependent-total projection with
the original-cover matching construction. The parameter squares do not imply
continuity for arbitrary topologies on pulled bundle totals. Nor does a natural
equivalence of these hom types supply a typed derivation of
`Geometry.Tests.finite-branch-atlas-orbifold`: the retained conaled
`sectionCoherence` consumes explicit context, type and term derivations, and its
`universalTransfer_square` uses the different, specified `UniversalTransfer`
proof. The actual finite-branch declarations and their constructors must enter
that admission boundary explicitly.

### 6. What this can close, and what remains separate

The audited source is confined to the ordinary fragment above and its
parameters match the constructed bounded interface. Its independent
ordinary-mode native check is accepted. The model theorem,
bounded-interface construction, and geometric instantiation give an
external mathematical interpretation of a fixed-level instance of
**that new theorem**. Its proof has been checked in ordinary Agda without
first interpreting native Cubical operations in higher Cahiers. This is
a substantive reduction of the semantic
obligation, not a claim that `--without-K` alone proves soundness of every
Agda feature.

A semantic audit must match the source’s universe bounds, parameters, computation rules and import closure. Additional source features require additional interpretation; compiler acceptance is not that interpretation.

The published model results and this note remain trusted external
mathematics. No syntax-to-model translation has been mechanized here,
and no formal compiler-correctness claim is made. Mechanizing the site,
model construction, geometric input and semantic transfer is still
required for an entirely checked external theorem.

The existing `FiniteBranchPresentations` Cubical implementation retains
its separate interpretation obligation. A wholesale ordinary port would
also have to reconstruct or justify the chosen groupoid quotient,
including its composition coherences, univalence-based hom construction,
large eliminators and universe bounds. It may instead construct a
quotient from independently supported colimit/truncation operations, but
the equivalence with the original completion must then be proved. Merely
copying its desired hom/path equivalence into a primitive HIT record
does not prove that comparison.

None of this supplies the full Myers-oriented joint foundation. The
reduced ordinary theorem's model is chosen specifically to avoid the
unneeded modal, crisp, whole-neighborhood tinyness and strict outer
assumptions.

### Primary references and exact roles

- **S19:** Michael Shulman, *All (infinity,1)-toposes have strict univalent
  universes*, arXiv:1904.07004v2, 2019. Corollary 4.9; Theorem 11.2;
  Appendix A, especially Theorem A.26 and Remarks A.27-A.28. The
  parameterized-HIT universe qualification is on printed pp. 29 and
  56-57. <https://arxiv.org/pdf/1904.07004>
- **LS19:** Peter LeFanu Lumsdaine and Michael Shulman, *Semantics of higher
  inductive types*, arXiv:1705.07088v2, 2019. Sections 5-6; Definition
  10.1 and Theorem 10.6; Theorems 13.1-13.2; constructor-boundary
  restriction in Section 12. <https://arxiv.org/pdf/1705.07088>
- **VMA19:** Andrea Vezzosi, Anders Mortberg and Andreas Abel, *Cubical
  Agda: A Dependently Typed Programming Language with Univalence and
  Higher Inductive Types*, 2019, Sections 5-6.
  <https://staff.math.su.se/anders.mortberg/papers/cubicalagda.pdf>
- **CRS21:** Thierry Coquand, Fabian Ruch and Christian Sattler,
  *Constructive sheaf models of type theory*, published 2021; primary
  preprint arXiv:1912.10407v4, 2020. Sections 1.5 and 3.4.
  <https://arxiv.org/pdf/1912.10407>
- **CHS26:** Thierry Coquand, Jonas Hofer and Christian Sattler,
  *Constructive higher sheaf models with applications to synthetic
  mathematics*, arXiv:2605.15126v2, 2026. Introduction; Theorem 29 and
  Remark 30. <https://arxiv.org/pdf/2605.15126>
- **ACCRS26:** Steve Awodey, Evan Cavallo, Thierry Coquand, Emily Riehl and
  Christian Sattler, *The equivariant model structure on cartesian cubical
  sets*, arXiv:2406.18497v3, 2026. Theorem 6.3.6 and Remark A.6.3.
  <https://arxiv.org/pdf/2406.18497>

<a id="morita-comparison"></a>

## Morita comparison and the classical orbifold subcategory

Assessment date: 2026-11-08. Status: an external mathematical construction
and proof. This note does not certify a native build, interpret the exact
Cubical Agda implementation, or assert a machine-checked construction of
the sites and stacks used below.

### 1. Result and scope

The formal-point quotient construction of
`external-models.md#finite-bisection-interpretation` has a presentation-independent
comparison with classical smooth stacks. In fact, there is a fully
faithful functor

\[
 E:\mathscr H_S\longrightarrow\mathscr H_C,
 \qquad rE\simeq\operatorname{Id}_{\mathscr H_S},                 \tag{1}
\]

where `H_S` is the infinity-category of ordinary smooth infinity-sheaves,
`H_C` is the chosen higher Cahiers infinity-topos, and `r` restricts to
ordinary smooth tests. For a Hausdorff, second-countable Lie groupoid
`G1 => G0`, there is a natural equivalence

\[
 E[G]\simeq |N(jG)|=:X_G.                                    \tag{2}
\]

Consequently all classical equivalences between the quotient stacks of
the allowed groupoids are preserved and reflected. This includes every
Morita equivalence between Hausdorff, second-countable etale Lie
groupoids. The comparison respects all stack morphisms and their
2-isomorphisms, including morphisms represented by refinements or
principal bibundles.

For a smooth weak-equivalence functor between etale presentations, the
proof below also supplies the precise internal, parameter-varying full
faithfulness and merely essential surjectivity required by
`CompletionMoritaEquivalence.agda`. This is more specific than showing
that two externally defined quotient objects happen to be equivalent.

Finally, an explicit atlas criterion characterizes the image of classical
proper etale orbifold stacks inside `H_C`. The resulting comparison is
an equivalence of the specified full orbifold subcategories. It does not
classify every object satisfying the reduced internal orbifold predicate.

The functor `E` is not left exact: a square-zero equalizer gives a concrete
counterexample in Section 9. Thus (1) is a categorical comparison, not an
interpretation of arbitrary dependent types or an identification of
literal `DPProper` with classical properness.

### 2. Sites, sizes, and geometric conventions

Work in an external classical metatheory. Choose universes so that the
following sites are small and their presheaf and sheaf categories are
formed in a larger universe. All colimits mentioned below are small at
the selected size. These conventions do not establish the universe or
resizing requirements of an Agda interpretation.

Let `Cart` have all open subsets `U` of finite-dimensional real Euclidean
spaces as objects, all smooth maps as morphisms, and ordinary open
covers. One may include the empty object and its empty cover. Choose a
small skeleton of finite-dimensional local real Weil algebras with
residue field `R`. Let `FormalCart` have objects

\[
 T=U\times\ell W,
 \qquad A_T=C^\infty(U)\otimes_{\mathbb R}W,
\]

and all opposite `C-infinity`-algebra homomorphisms between their
algebras. The tensor product here has its usual Weil-extension smooth
functional calculus. Covering families are

\[
 \{U_a\times\ell W\longrightarrow U\times\ell W\}_a
\]

for ordinary open covers of `U`, with `W` fixed. The topology is
subcanonical. An open restriction is determined by the ordinary body:
the inverse image of `V x ell W` under a formal map with body `f` is
the open restriction to `f^{-1}(V)`. This follows equally from smooth
open localization or from local coordinates and finite Taylor
expansion. It supplies the needed stability of the coverage under
arbitrary formal maps. [D79, Sc16]

Set

\[
 \mathscr H_S=\operatorname{Sh}_{\infty}(\mathrm{Cart},J_{\rm open}),
 \qquad
 \mathscr H_C=\operatorname{Sh}_{\infty}
                    (\mathrm{FormalCart},J_{\rm open}).          \tag{3}
\]

Here `Sh_infinity` means infinity-sheaves with ordinary cover descent;
we do not impose hypercompletion. The primary formal-smooth discussion
in [Sc16, Proposition 6.5.10] uses a hypercomplete presentation. The
0- and 1-truncated objects at issue in the orbifold comparison agree
with that presentation, but no identification of the entire
hypercomplete and nonhypercomplete categories is assumed. The adjunction
argument below is given directly for (3).

All manifolds in this note are finite-dimensional, Hausdorff and second
countable, without boundary. Write `hM` for the ordinary sheaf of smooth
maps into `M`, and `jM` for its formal-point sheaf in `H_C`. For a chart
`U`, these are the respective representables. The usual open-chart
comparison identifies ordinary sheaves on `Cart` with ordinary smooth
sheaves on this manifold site: chart restrictions determine an extension
by descent, and descent determines its restriction back. In particular,
1-truncated objects are ordinary stacks in groupoids for this topology.

The convention for a classical orbifold stack will be a stack admitting
a proper etale Lie groupoid presentation of the stated manifold kind.
Here proper means that inverse images of compact sets are compact.
Ineffective isotropy is allowed. An effective-orbifold convention adds
its usual classical effectiveness requirement to the presentations.

#### 3.1 The direction of the site adjunction

The inclusion and reduction functors are

\[
 i:\mathrm{Cart}\longrightarrow\mathrm{FormalCart},\quad
 iU=U\times\ell\mathbb R,
 \qquad
 \mathrm{red}(U\times\ell W)=U.
\]

Reduction is functorial for all formal morphisms. Indeed, the nilradical
of `A_T` is `C-infinity(U) tensor m_W`: this ideal is nilpotent and its
quotient `C-infinity(U)` is reduced. Algebra homomorphisms preserve
nilpotents and hence induce the required maps of reduced algebras.

If `V` is ordinary, a morphism `iV -> T` corresponds to a smooth-algebra
map `A_T -> C-infinity(V)`. It kills the nilradical, uniquely. Thus

\[
 \operatorname{Hom}_{\rm FormalCart}(iV,T)
 \cong \operatorname{Hom}_{\rm Cart}(V,\mathrm{red}\,T)          \tag{4}
\]

naturally in both variables. Consequently

\[
                         i\dashv\mathrm{red},
 \qquad\mathrm{red}\,i=\operatorname{Id}.
\]

The counit is the body inclusion `i red(T) -> T`. The argument does
not assume a natural projection in the reverse direction for arbitrary
formal morphisms.

#### 3.2 Restriction and its right adjoint

Restriction along `i` sends sheaves to sheaves, since ordinary open
covers are among the formal covers. Denote it by

\[
 r:\mathscr H_C\longrightarrow\mathscr H_S.
\]

At the presheaf level the right adjoint to restriction has value at `T`
given by

\[
 \begin{aligned}
 R_pF(T)
 &\simeq\operatorname{Map}_{\operatorname{PSh}(\mathrm{Cart})}
              (r_p y_{\rm FormalCart}T,F)\\
 &\simeq\operatorname{Map}_{\operatorname{PSh}(\mathrm{Cart})}
              (y_{\rm Cart}(\mathrm{red}\,T),F)\\
 &\simeq F(\mathrm{red}\,T).
 \end{aligned}                                                \tag{5}
\]

The middle step is (4). Equivalently this is right Kan extension
along `i^op`.

If `F` is an infinity-sheaf, the presheaf (5) is also an infinity-sheaf.
For a covering family of `U x ell W`, every term of its Cech diagram
has the form

\[
 (U_{a_0}\cap\cdots\cap U_{a_n})\times\ell W.
\]

Reduction sends this to the ordinary open-cover Cech diagram. Descent
for (5) is therefore precisely descent for `F` on that ordinary cover.
Thus the presheaf adjunction restricts to an adjunction

\[
 r\dashv R,\qquad RF(T)=F(\mathrm{red}\,T).                    \tag{6}
\]

In particular `r` preserves all small colimits. It also preserves
limits, which are computed objectwise in these sheaf categories. The
counit `rR -> Id` is an equivalence by `red i = Id`.

The functor `R` is not the formal-point extension of a manifold: it
evaluates `hM` on the body only. The extension used in (1) is the
different left adjoint constructed next.

#### 3.3 The left adjoint and its full faithfulness

Let `a_C` denote sheafification on `FormalCart`, and regard a sheaf on
`Cart` as a presheaf by the fully faithful inclusion. Define

\[
 EF=a_C\operatorname{Lan}_{i^{\rm op}}F.                       \tag{7}
\]

The Kan-extension adjunction followed by the sheafification adjunction
gives `E dashv r`. These adjunctions are between infinity-categories,
so include natural mapping-space equivalences. Altogether,

\[
                         E\dashv r\dashv R.                   \tag{8}
\]

For an ordinary chart `U`, left Kan extension sends its representable
to the formal representable at `iU`. Subcanonicity then gives

\[
 E(y_{\rm Cart}U)\simeq y_{\rm FormalCart}(iU).
\]

Restricting the right side gives `y_Cart U`, since `i` is fully
faithful. The adjunction unit `eta : Id -> rE` is this equivalence on
representables.

Representables generate `H_S` under small colimits: first use Yoneda
density in presheaves and then apply sheafification. Both `Id` and
`rE` preserve these colimits, since `E` is a left adjoint and (6) makes
`r` a left adjoint as well. The full subcategory where `eta` is an
equivalence is therefore colimit-closed and contains all the
generators. This proves (1) for every infinity-sheaf. In particular,

\[
 \operatorname{Map}_{\mathscr H_C}(EF,EG)
 \simeq\operatorname{Map}_{\mathscr H_S}(F,G).                 \tag{9}
\]

The generator and sheafification facts are [L09, Corollary 5.1.5.8
and Proposition 6.2.2.7]. The related formal-smooth adjoint structure
and full faithfulness are explicitly recorded in [Sc16, Proposition
6.5.11]. The proof here specifies the reduction, the sheaf condition,
and the colimit argument for our chosen sites; it does not infer full
faithfulness solely from checking ordinary points.

#### 4.1 Agreement with the formal-point embedding

There is a canonical natural map `E(hM) -> jM`, adjoint to the
identification `hM = r(jM)`. It is an equivalence. Choose an open
Euclidean-chart cover of `M`. Its Cech diagram presents `hM` as a
colimit in `H_S`. Every intersection is an open subset of a chart and
can be treated as a representable. Applying `E` gives the corresponding
diagram of formal chart sheaves.

The same diagram presents `jM`. Indeed, a formal map into `M` locally
lies in a chart when its body does; open membership is unchanged by
nilpotent thickening. The formal chart family is an effective
epimorphic cover and its intersections are the indicated open
restrictions. Its Cech colimit is `jM`. Hence

\[
                             E(hM)\simeq jM                   \tag{10}
\]

canonically and naturally in every smooth map, independently of the
chosen cover. Combining (9) and ordinary Yoneda also shows that `j`
is fully faithful on manifolds.

#### 4.2 The pullbacks that the proof actually needs

For a submersion `p : M -> N` and any smooth `f : K -> N`, the
manifold pullback `P = K x_N M` exists, and

\[
                          jP\simeq jK\times_{jN}jM.           \tag{11}
\]

Here is the local reason. Around any compatible pair of body points,
submersion coordinates make `p` a coordinate projection. A formal
point of its pullback is then exactly a pair of formal points with
matching projected coordinates. This identifies both sides of (11)
on an open cover of every formal parameter. These local identifications
are the canonical comparison map and so glue. This is also a special
case of the transversal-pullback property in the well-adapted model.
[D79, Definition I(2) and Theorem 4.10]

If `p` is surjective as well, `jp` is an effective epimorphism. For
each ordinary target point, the submersion theorem supplies a smooth
section `sigma_a : V_a -> M` on some open neighborhood. These
neighborhoods cover `N`. Given a formal parameter `T = U x ell W`
and a map `T -> jN`, pull back that cover along its body `U -> N`.
On each resulting open formal restriction, the map factors through
`jV_a` and then lifts using `j sigma_a`. Thus it lifts locally for
every formal parameter. This is exactly effective epimorphy between
the 0-truncated sheaves concerned. It supplies local existence, with
no selection of a global section.

### 5. Quotients and natural recovery on ordinary tests

Let `G` be a Lie groupoid with the stated manifold conventions; this
section does not require properness or etaleness. All manifolds in
its nerve `G_n` exist as iterated pullbacks along source or target
submersions. By (11), applying `j` gives an internal groupoid and

\[
                      j(G_n)\simeq N(jG)_n.
\]

The classical quotient stack is the realization `[G] = |N(hG)|`
in `H_S`. By (10), degree by degree, and the colimit preservation
of `E`,

\[
 E[G]\simeq E|N(hG)|\simeq|E N(hG)|
       \simeq|N(jG)|=X_G.                                    \tag{12}
\]

The object map `jG0 -> X_G` is an effective epimorphism and
`jG1` is its kernel pair, by effectiveness of groupoid objects in
an infinity-topos. Its hom fibers are 0-truncated, so the quotient
is 1-truncated. These are general topos facts, rather than an
additional orbifold or properness hypothesis. [L09, Theorem 6.1.0.6
and Proposition 6.1.3.19]

The construction of (12) is natural in smooth functors. A smooth
natural transformation becomes an internal natural transformation
after `j`, and the usual nerve homotopy supplies the corresponding
homotopy of quotient maps. The identification with `E` preserves
these operations and their compositions coherently.

Using (1), the unit gives a natural equivalence

\[
                              rX_G\simeq[G].                  \tag{13}
\]

For every ordinary manifold `T`, including manifolds outside the
chosen chart site, its precise evaluation consequence is

\[
 \operatorname{Map}_{\mathscr H_C}(jT,X_G)
 \simeq\operatorname{Map}_{\mathscr H_S}(hT,[G])
 \simeq [G](T).                                              \tag{14}
\]

The right side is the groupoid of principal `G`-bundles on `T`
and their isomorphisms. Equivalence (14) is natural in the test
manifold, in the groupoid presentation, and in 2-isomorphisms. It
recovers the groupoid of families and their symmetries, not only
the set of isomorphism classes or the coarse orbit space.

In addition to functoriality, (9) proves the stronger statement

\[
 \operatorname{Map}_{\mathscr H_C}(X_G,X_H)
 \simeq\operatorname{Map}_{\mathscr H_S}([G],[H]).              \tag{15}
\]

For these 1-truncated targets the displayed mapping spaces are
groupoids. Arbitrary stack morphisms need not arise from a smooth
functor between the two chosen presentations. For example, a
nontrivial principal finite-group bundle on a manifold gives a
map to its classifying stack, while a functor from that manifold's
unit groupoid to the one-object groupoid gives the trivial bundle.
Refinements or principal bibundles represent the additional maps.
Equation (15) covers the full mapping groupoid, including those
maps; mere functoriality of `G |-> X_G` would not prove this.
The presentation of stack maps by fractions and cover refinements
is described in [C12, Section 2.1, Definition 2.10 and equation (3)].

### 6. Direct internalization of etale weak equivalences

Let `F : G -> H` be a smooth functor between Hausdorff,
second-countable etale Lie groupoids. Use the standard
weak-equivalence conditions:

1. The comparison

\[
   G_1\longrightarrow
   (G_0\times G_0)\times_{H_0\times H_0}H_1,
   \quad g\longmapsto(sg,tg,F_1g)                            \tag{16}
   \]

is a diffeomorphism, with the base map `F0 x F0`.

2. With

\[
   B=H_1\times_{s,H_0,F_0}G_0,
   \qquad q:B\longrightarrow H_0,\quad q(h,x)=t(h),          \tag{17}
   \]

the map `q` is a surjective submersion.

This is [L09b, Definition 3.5], with inversion exchanging its arrow
orientation and ours. The local-section formulation appears in
[C12, Definition 2.8]. No extra surjectivity, injectivity, or
properness of `F0` is assumed.

#### 6.1 The object map is automatically etale

The projection `B -> G0` is a local diffeomorphism, being a base
change of `s_H`. Around `(1_{F0(x)},x)`, restrict to a unit
bisection of `H`. Under this local identification of `B` with
an open part of `G0`, `q` is `F0`. Condition (17) therefore
implies that `F0` is a submersion at every `x`.

Fix `x`. By (16), each `x'` with `F0(x') = F0(x)` determines
the unique arrow `g : x -> x'` such that `F1(g)` is the identity
at `F0(x)`. This gives a continuous injective map from the
manifold fiber `F0^{-1}(F0(x))` into the source fiber of `G` at
`x`. The latter is discrete because `G` is etale. The former
fiber is consequently discrete as well. A submersion with
zero-dimensional fibers is a local diffeomorphism. Thus `F0`,
and hence `F0 x F0`, is etale.

This argument is the needed justification for preserving (16).
An unsupported assertion that formal-point extension preserves
every manifold pullback would be false.

#### 6.2 Full faithfulness over all parameters

The square (16) is a pullback along the submersion `F0 x F0`.
Applying (11) yields a pullback of formal-point sheaves. Its
fibers give the internal equivalences

\[
 (x,x'):jG_0\times jG_0\quad\vdash\quad
 \operatorname{Hom}_{jG}(x,x')
 \simeq\operatorname{Hom}_{jH}(jF(x),jF(x')).                 \tag{18}
\]

These are equivalences of the varying hom families, not a
collection of statements restricted to ordinary global objects.

#### 6.3 Mere essential surjectivity over all parameters

The defining pullback for `B` is preserved because `s_H` is a
submersion. By Section 4.2, the local smooth sections of (17)
make `jq` an effective epimorphism. In the internal language,
this says

\[
 (y:jH_0)\quad\vdash\quad
 \left\|\sum_{x:jG_0}
          \operatorname{Hom}_{jH}(jF(x),y)\right\|.           \tag{19}
\]

Concretely, for `y` over any formal stage `U x ell W`, the
inverse images under its body of the local-section domains
cover `U`; the sections supply `(x,h)` on that cover. They
give the truncation in (19), with no global representative
choice. Since all arrows of `jH` are invertible, its hom type
is equivalent to `CatIso`, so (19) is exactly the essential
surjectivity formulation of the native comparison module.

Together (18) and (19) are the mathematical input represented
by `isWeakEquivalence F` there. The relevant native export is

`CompletionMoritaEquivalence.Map.weak-equivalence≃completed-isEquiv`.

The exports `Map.completed-map-object` and
`Map.completed-map-morphism-path` specify the action of the
actual completion map on objects and generating arrow paths.
An identification of that native HIT interpretation with
the mathematical quotient (12) still belongs to the separate
language-to-model obligation.

### 7. Precisely what presentation independence covers

Conditions (18)--(19) make the quotient map induced by `jF`
an equivalence. One can see this using groupoid effectiveness:
full faithfulness makes the quotient map a monomorphism, and
local essential surjectivity makes it an effective epimorphism.
Equivalently, the ordinary weak equivalence induces a classical
stack equivalence, and (12) applies `E` to that same map.

If both arrows in a span

\[
                           G\longleftarrow K\longrightarrow H
\]

are such weak equivalences, their formal quotient maps give
`X_G <- X_K -> X_H` with both arrows equivalences. Inverting
the left arrow produces the comparison and a homotopy
commuting triangle. The native span interface records these
as `Span.completion-equivalence` and
`Span.comparison-triangle`. Under (13), the external triangle
restricts to the original classical fraction.

The preservation statement is not restricted to a particular
choice of common refinement. By (15), every equivalence of
classical quotient stacks has an equivalent image, with all
its 2-isomorphisms. Conversely, if the image of a classical
map is an equivalence, applying `r` and (1) shows that the
original map was an equivalence. Thus the precise class is
**all classical Morita equivalences between the allowed
presentations**, with the entire classical stack mapping
groupoid retained. No additional requirement that a
presentation functor be proper or surjective on objects is
introduced. The standard relation between Morita spans and
equivalent stacks is [C12, Section 2.1].

There is also a direct bibundle version whenever its total
space is a manifold satisfying our conventions. Its action
domains and principality diagrams are pullbacks along
submersions, so (11) preserves them. Its surjective submersion
anchors become effective epimorphisms by Section 4.2.
Therefore a two-sided principal Morita bibundle becomes
a two-sided principal internal bibundle. This agrees with
the map already supplied by `E` and descent. The classical
bibundle construction is developed in [L09b, Sections 3.2--3.3].

The direct manifold argument does not make an unstated
extension to non-Hausdorff arrow manifolds or bibundle total
spaces. Those are outside the selected input conventions.
The all-morphisms assertion concerns the full subcategory
of classical stacks with the allowed presentations.

### 8. An atlas criterion for the classical orbifold image

Let `Orb_cl` be the full `(2,1)`-subcategory of `H_S` on
the classical proper etale orbifold stacks specified in
Section 2. Let `Orb_atlas` be the full subcategory of `H_C`
on objects `X` admitting these data:

1. A manifold `M` of the stated kind and an effective
   epimorphism `a : jM -> X`.
2. A manifold `R` of the stated kind and an equivalence

\[
                       jR\simeq jM\times_X jM               \tag{20}
   \]

over `jM x jM`.
3. The smooth maps `s,t : R -> M` corresponding to the
   projections in (20) are local diffeomorphisms.
4. The classical map `(s,t) : R -> M x M` is proper.

Existence of these data is the condition; the atlas is
not part of a morphism in the full subcategory. Its reference
to classical properness is explicit. It does not substitute
literal `DPProper` or finite hom fibers for that hypothesis.

**Theorem.** The functors `E` and `r` restrict to an equivalence
of `(2,1)`-categories

\[
                   \mathrm{Orb}_{\rm cl}
                   \simeq\mathrm{Orb}_{\rm atlas}.           \tag{21}
\]

**Forward direction.** For `X = E[G]`, use `M = G0` and
`R = G1`. Effectiveness of the groupoid quotient gives the
atlas and (20). Etaleness and properness are exactly the
assumed classical geometric properties of `G`.

**Converse direction.** The Cech groupoid of `a` has object
sheaf `jM` and arrow sheaf `jR`. Full faithfulness of `j`
on manifolds gives unique smooth identity and inverse maps.
The domain of composition is represented by `R x_M R`,
since `s` and `t` are submersions and (11) applies. Full
faithfulness therefore gives a unique smooth composition.
The groupoid identities reflect to identities of smooth
maps: mapping spaces into the 0-truncated manifold sheaves
are discrete, so their coherent equalities express the
ordinary groupoid equations. We have constructed an actual
Lie groupoid `G = (R => M)`. It is etale by condition 3
and proper by condition 4.

Its formal nerve is the Cech nerve of `a`, by repeated
applications of (11). Effective epimorphy now gives

\[
                       X\simeq|N(jG)|\simeq E[G].             \tag{22}
\]

In particular `X` is 1-truncated; this need not be assumed
separately in the criterion. Full faithfulness (9) gives
the equivalences of all morphism groupoids needed for
(21), and the unit and counit restrict to the claimed
inverse equivalences. Different eligible atlases recover
equivalent classical stacks because both restrict to `rX`.

The criterion constructs the classical presentation from
an effective atlas and its representable relation. It
does not assume the desired internal orbifold conclusion
as an input. By the finite-bisection and atlas-lifting
argument of `external-models.md#finite-bisection-interpretation`, every
object in this subcategory satisfies the reduced finite
Weil orbifold predicate. That predicate can hold for
objects outside this subcategory; the earlier doubled-origin
example already shows why properness must remain explicit.

### 9. Full faithfulness does not give a dependent-type interpretation

In `H_S`, consider the equalizer of the two smooth maps

\[
 h\mathbb R\mathrel{\substack{\xrightarrow{\ x\mapsto x^2\ }\\[-2pt]
                              \xrightarrow[\ x\mapsto0\ ]{}}}
 h\mathbb R.
\]

At every ordinary test, a real-valued smooth function whose
square is zero is zero. Thus this equalizer is the point.
Its image under `E` is still the point by (10).

The equalizer of the two image maps in `H_C` is instead
the square-zero infinitesimal

\[
                  D=\{d:j\mathbb R\mid d^2=0\}.
\]

At the formal test `ell(R[epsilon]/epsilon^2)`, the algebra
element `epsilon` defines a section of `D` distinct from
the zero section. Hence `D` is not the terminal sheaf and
the equalizer comparison is not an equivalence. This is
an external inequality of two elements of the test algebra;
it does not assert the internally negated proposition
`epsilon != 0` at every restriction.

Therefore `E` does not preserve arbitrary equalizers or
pullbacks. There is no conflict with (11): that statement
concerns manifold pullbacks along submersions. Nor is
there a conflict with full faithfulness, which preserves
mapping spaces between image objects but need not preserve
their limits as computed in the larger category.

A general interpretation of dependent type theory must
handle context extension and substitution by the relevant
pullbacks, as well as its specified type formers and
universes. The functor `E` alone does not supply that
structure. In particular it does not transport all
internally stated properties between the two settings.
The argument proves neither a literal `DPProper`
comparison nor the full original crisp/modal foundation.
Classical properness enters the reduced realization
through finite bisections and the explicit atlas criterion.

### 10. Evidence boundary and remaining work

The external mathematical comparison established here is
specific: the two sheaf categories (3), the adjunctions
(8), the full faithfulness (9), the quotient identification
(12), the varying weak-equivalence data (18)--(19), and
the proper etale subcategory equivalence (21).

The native completion comparison concerns the actual HIT completion map.
This external construction explains the mathematical hypotheses; it does
not identify exact native syntax with its interpretation by assertion.
See [Completion comparison](finite-presentations.md#morita-completion-scope).

The reduced finite-branch realization remains the one
proved externally in `external-models.md#finite-bisection-interpretation`.
The bounded ordinary-language route investigated in
`source-interpretation.md#language-bridge` is another, explicitly scoped
semantic bridge; it is not justified merely by (9).
An end-to-end mechanization would still have to formalize
the sites, their sheaf/stack machinery and the geometric
arguments, or designate those external mathematical
results as its trusted semantic boundary. An exact
Cubical-language interpretation requires its own proof.

### Primary sources and their precise use

These source entries are local to this new note. They do
not modify the shared semantic source ledger. The
comparison proofs above spell out the specialized
arguments instead of attributing this whole development
to a single source.

- **[D79] Eduardo J. Dubuc, _Sur les modeles de la geometrie
  differentielle synthetique_ (1979).**
  [Primary PDF](https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf).
  Definition I(2), printed pp. 232--233, and Theorem 4.10
  with proof, printed pp. 276--278: the manifold embedding,
  open-cover behavior, and transversal-pullback property
  of the well-adapted sheaf model. No claim about the
  exact native Cubical/crisp language is inferred.

- **[Sc16] Urs Schreiber, _Differential cohomology in a
  cohesive infinity-topos_, version dated by the
  `161227` PDF.**
  [Primary PDF](https://ncatlab.org/schreiber/files/dcct161227.pdf).
  Section 6.5.1, especially Definitions 6.5.5 and 6.5.7,
  gives the formal smooth site. Proposition 6.5.10
  explicitly uses a hypercomplete presentation;
  Proposition 6.5.11, printed p. 726 / PDF p. 752,
  states the adjoint structure and full faithfulness
  of its leftmost functor. Our proof treats the
  particular nonhypercomplete categories (3) directly.

- **[L09] Jacob Lurie, _Higher Topos Theory_ (2009).**
  [Author's primary PDF](https://www.math.ias.edu/~lurie/papers/HTT.pdf).
  Theorem 5.1.5.6 and Corollary 5.1.5.8: the
  presheaf cocompletion and its representable generators.
  Proposition 6.2.2.7: sheafification as a left exact
  localization. Theorem 6.1.0.6 and Proposition 6.1.3.19:
  the infinity-topos axioms, including effectiveness
  of groupoid objects. Left exactness here belongs
  to sheafification, not to `E`.

- **[L09b] Eugene Lerman, _Orbifolds as stacks?_,
  arXiv:0806.4160v2 (2009).**
  [Primary PDF](https://arxiv.org/pdf/0806.4160).
  Definition 3.5: smooth full-faithfulness and
  surjective-submersion essential surjectivity for
  equivalence functors. Sections 3.2--3.3 and 4:
  principal bibundles and quotient-stack descriptions.
  Its source/target convention in Definition 3.5
  is exchanged with (17) by inversion.

- **[C12] David Carchedi, _Sheaf theory for etale
  geometric stacks_, arXiv:1011.6070v2 (2012).**
  [Primary PDF](https://arxiv.org/pdf/1011.6070).
  Section 2.1, especially Definition 2.8 and the
  following discussion: local-section Morita
  equivalences, spans, and equivalent quotient
  stacks. Definition 2.10 and equation (3): cover
  refinements describing the full groupoid of
  stack maps. These classical comparison facts
  do not by themselves prove the smooth-to-formal
  full faithfulness (9); that uses Sections 3--4.

<a id="semantic-completion"></a>

## What the reduced theory models, and what semantic completion means

This report audits the external realization of the seven-module ordinary
theorem identified in [topological-bridge.md#dependency-boundaries-078](topological-bridge.md#dependency-boundaries).
It changes no accepted proof source and records no compiler run. Its
mathematical constructions and source-to-model audit are **external
mathematics**, with the model theorems cited below in the trusted boundary.

The audit supports the positive result already developed in
[source-interpretation.md#language-bridge-074](source-interpretation.md#language-bridge),
[source-interpretation.md#morita-comparison-074](source-interpretation.md#morita-comparison), and
[topological-bridge.md#derived-atlas-interpretation-076](topological-bridge.md#derived-atlas-interpretation):
the reduced ordinary theorem has a nondegenerate higher Cahiers
interpretation, and the objects obtained from classical proper etale
Lie groupoids recover their full classical quotient stacks.

This report adds three clarifications with proofs:

1. The implemented bounded truncation can be constructed from the image
   of one universal family. Primitive higher inductive truncation and
   same-universe HIT closure are unnecessary for this interface.
2. The source-to-model dictionary and the remaining mechanization
   obligations are separated from the external mathematical theorem.
3. The bare `ReducedOrbifold` predicate is strictly broader than the
   finite-dimensional classical target. An infinite product of real
   lines is a counterexample to an unrestricted converse. A separate
   geometric atlas criterion gives the valid classical recognition
   theorem.

None of these statements supplies a model of the complete old Myers
foundation. In particular, `Flat`, `RealFlat`, crisp rules, the full
double-negation infinitesimal generator, its tinyness, and literal
`DPProper` are absent from the ordinary theorem being interpreted.

### 1. An exact external theorem

Work in classical external mathematics with the universe assumptions
needed for the selected strict ordinary type-theoretic model. Fix a
small skeleton of finite-dimensional augmented local real Weil
algebras and a small family of their pullback squares. The family may
contain all pullback squares in that skeleton; it need not be a finite
list. Only the number of successive universe choices below is finite.

Let `G = (G1 => G0)` be a Lie groupoid whose object and arrow manifolds
are finite-dimensional, Hausdorff, and second countable. Suppose its
source and target are local diffeomorphisms and its actual anchor

\[
                         (s,t):G_1\longrightarrow G_0\times G_0
\]

is proper in the ordinary compact-preimage sense. Write `H_C` for the
infinity-topos of sheaves on the finite-Weil formal Cartesian site
specified in Section 2, and `j` for the functor of formal points of a
manifold. Form the actual quotient

\[
                 X_G=|N(jG)|,\qquad q_G:jG_0\longrightarrow X_G.
\]

Then the following external conclusions hold.

**Interpretation.** There is a selected finite-level ordinary MLTT
model presenting `H_C`, with weak function extensionality and the exact
universe-raising `BoundedTruncation` interface used by the source. The
quotient, its atlas, its actual hom-family, and the whole selected Weil
test family can be coded at its starting geometric level.

**Reduced theorem.** The actual atlas supplies all premises of
`DerivedAtlasOrbifold.Theory.Family.finite-branch-pushout-atlas-orbifold`.
Consequently `X_G` is local for the gaps of those actual Weil squares,
and its identity types are subfinite in the source's precise sense:
merely equivalent to a finite family of proposition fibers. This does
not assert decidable identity, a global finite enumeration, or the old
`ProperlyFinite` predicate.

**Classical recovery.** There is a fully faithful functor

\[
 E:\operatorname{Sh}_\infty(\mathrm{Cart})\longrightarrow H_C
\]

and a restriction functor `r` with `r E` equivalent to the identity.
For this groupoid,

\[
                    E([G])\simeq X_G,\qquad r(X_G)\simeq [G].
\]

The equivalence retains all arrows, isotropy, principal bundles, and
stack morphisms. It is not a comparison of coarse orbit sets. In
particular, equivalent classical quotient stacks have equivalent
images, and equivalences between their images are reflected.

**Recognition.** An object of `H_C` with an effective manifold atlas,
a manifold-representable kernel pair, local-diffeomorphism source and
target, and a classically proper anchor is of this form. These are
additional geometric hypotheses; the bare reduced predicate does not
imply them. Section 7 gives an explicit reason the qualification is
necessary.

The theorem is an external mathematical theorem using a checked
ordinary implication. It is not an end-to-end machine-checked
construction of `H_C` or a machine-checked interpretation of Agda.

#### 2.1 The site is specified independently of the desired theorem

Objects of `Cart` are open subsets `U` of finite-dimensional Euclidean
spaces; morphisms are smooth maps and covers are ordinary open covers.
Empty opens are included. One may use a small coded version of this
site in a fixed external universe.

Objects of `FormalCart` are

\[
       T=U\times\ell W,\qquad
       \mathcal O(T)=C^\infty(U)\otimes_{\mathbb R}W,
\]

where `W` is a finite-dimensional local real algebra with residue field
`R` and nilpotent augmentation ideal. Give this tensor product its
finite-Taylor `C-infinity` operations. Morphisms are opposite
`C-infinity` algebra homomorphisms. Covers have the form
`{U_i x ell W -> U x ell W}`, where `{U_i}` covers `U`. The tensor with
a Weil algebra is also the appropriate smooth-algebra coproduct; it
is not an assertion about arbitrary algebraic tensor products of
smooth function rings.

To see smallness explicitly, choose the vector space of each Weil
algebra from `R^n`, and code multiplication, unit, and augmentation
by finitely many real structure constants. The conditions defining a
Weil algebra select a set of such codes. Algebra homomorphisms are
also a set. Opens, smooth maps, covers, and the selected square family
then belong to a sufficiently large external set universe. Passing
to this skeleton does not identify distinct morphisms.

The category used here is

\[
                    H_C=\operatorname{Sh}_\infty(\mathrm{FormalCart}),
\]

with ordinary open-cover descent. No identification of this entire
category with its hypercompletion is required. Its 0-truncated and
1-truncated objects agree with their hypercomplete counterparts,
which is sufficient for the classical manifold and orbifold objects.

For a manifold `M`, the sheaf `jM` is its functor of formal points.
Locally, a map `U x ell W -> j R^n` is an `n`-tuple in
`C-infinity(U) tensor W`; it factors through an open subset exactly
when its reduction does. These coordinate descriptions glue across
smooth charts. They give the actual functor used below, including
its action on smooth maps.

The finite-Weil site and its well-adapted manifold embedding have
primary precedents in Kock, Theorem III.9.4 and its preceding example,
and Schreiber, Definitions 6.5.5-6.5.7. Kock explicitly proves the
transverse-pullback property; it is not arbitrary finite-limit
preservation. [K06, Sch16]

#### 2.2 The model theorem used is ordinary, not Cubical Agda semantics

The primary model input is Shulman's construction of strict ordinary
type-theoretic models presenting Grothendieck infinity-toposes. The
required ordinary type formers, function extensionality, sufficiently
large universes, and coherence are provided by Theorems 11.1-11.2 and
A.26. Corollary 4.9 gives a relative-presentability bound for each
fixed morphism. The noncumulative universe/lift discussion is Remark
A.28. No univalence term is used by the present source. [S19]

The fragment actually needing interpretation consists of ordinary
identity, dependent products and sums, natural and finite types,
explicit lifts, nonrecursive records, and a fixed truncation record.
The source has no native cubical operation, quotient HIT, reflection,
rewrite rule, or `Setomega` field. Its exact dependency closure and
hashes are in [topological-bridge.md#dependency-boundaries-078](topological-bridge.md#dependency-boundaries).

The translation at one chosen native level `ell` has the following
ordinary mathematical dictionary.

| Source construction | Interpretation |
| --- | --- |
| `A : Set ell` | A code `A` in the selected universe, with occurrences of `A` as a type read through its decoding family |
| `(x : A) -> B x`, lambda, application | Dependent product, abstraction, evaluation in the strict model |
| `Σ A B`, constructor and projections | Dependent sum, pairing, projections |
| The inductive `_≡_`, `refl`, `J` | The model's intensional identity type, reflexivity, identity eliminator |
| Record constructors, fields, and copattern definitions | Finite dependent tuples and their ordinary projection equations |
| `Nat`, its pattern recursion | The natural-number type and its eliminator |
| `Fin n` | The finite family defined by `Fin 0 = Empty` and `Fin (suc n) = Unit + Fin n`, with its corresponding eliminator |
| `Lift b A`, `lift`, `lower` | The explicit lifted copy of the decoded type with its constructor/projection computation |
| `Equiv A B` | The displayed map, inverse, and two homotopies; no claim that this quasi-inverse record is proposition-valued |
| `FunExt ell ell` | The model's function-extensionality term, restricted to the requested levels |
| `BoundedTruncation ell` | The generic image construction of Section 3 |
| Module and implicit parameters | Ordinary context parameters and substitution; fixed level specialization removes metatheoretic level polymorphism from the application |

Pattern proofs in the closure use ordinary inductive elimination.
The finite-family interpretation uses the usual large eliminator
into the chosen universe; it is not a replacement of `Fin` by a
set-theoretic list while ignoring its eliminator. Nonrecursive
records require no recursive-record semantic principle.

This dictionary supplies the manual source-to-model audit. It does
not prove that Agda's elaborator emits exactly a formally defined
MLTT syntax, nor does it implement the fundamental interpretation
theorem in Agda. Those distinct mechanization obligations remain
listed in Section 8.

#### 2.3 Whole-family universe bounds are chosen in order

Construct the actual quotient, atlas, hom-family, and indexed Weil
vertices and pushouts first. Construct the family of ordinary open
rectangles and branch regions used for the chosen groupoid. Regard
each indexed family as one morphism over its index object. Choose
the geometric universe large enough for this entire fixed collection.

Next choose `Code ell`, then the image family of its universal
decoded type, then `Truth ell` large enough to classify that image
family, and finally a universe for the truncation interface itself.
The literal source has

```text
Code ell  = lsuc ell
Truth ell = lsuc (lsuc ell)
BoundedTruncation ell : Set (lsuc (Truth ell))
```

Successor *syntactic* levels may be represented by widely separated
inaccessible cardinals. The procedure does not require adjacent
cardinals, same-universe truncation, or closure of the geometric
universe under every small pushout. It bounds the whole selected
small test family, rather than separately bounding each test and
silently assuming a uniform bound.

The generic contexts used for the operations are formed once in
this selected hierarchy. No internal type of all levels and no
internal choice of a universe for each parameter are involved.

### 3. Bounded truncation from an image of one universal family

This construction sharpens the earlier language bridge. It applies
to the exact nondependent recursor in `BoundedTruncation.agda` and
does not need a primitive truncation HIT.

Let

\[
                         p_a:E_a\longrightarrow U_a
\]

be the universal decoded family for the selected input universe.
In the underlying infinity-topos take its image factorization

\[
                    E_a\xrightarrow{e_a}T_a\xrightarrow{m_a}U_a,
\]

where `e_a` is an effective epimorphism and `m_a` is a monomorphism.
Effective-epimorphism/monomorphism factorization and its orthogonality
are instances of the connective/truncated factorization systems in
an infinity-topos. [HTT]

Choose a fibrant representative of `m_a` over the universe in the
strict-model presentation. This is one fixed morphism, so it has a
relative-presentability bound. Choose a later universe `U_b` above
that bound and classify it by

\[
                              \tau_a:U_a\longrightarrow U_b.
\]

The decoded fiber of `tau_a(A)` is `Tr(A)`. The fiber of `e_a` gives
`point : A -> Tr(A)`. The fact that `m_a` is a monomorphism gives
`squash : isProp (Tr(A))` uniformly in `A`.

For the recursor, use the **single generic context** of data

\[
              A:U_a,\quad P:U_b,\quad p:\operatorname{isProp}(P),
              \quad f:A\longrightarrow P.
\]

After pullback to this context, the unit `A -> Tr(A)` is an
effective epimorphism and `P -> 1` is a monomorphism. Their
orthogonality supplies a contractible space of maps

\[
                              \overline f:\operatorname{Tr}(A)\to P
\]

extending `f`. Represent this one generic map as ordinary strict
model data. Application and substitution then give every requested
instance of `rec`; there is no family of unrelated stagewise choices.
The source requires only propositional computation, which follows
directly from propositionhood of `P`:

\[
                    \overline f(\operatorname{point}(x))=f(x).
\]

The image construction is stable under base change. This explains
why its fibers interpret genuine propositional truncation and why
mere atlas surjectivity has the expected effective-epimorphism
meaning. It also prevents a vacuous substitute, such as returning a
fixed inhabited proposition for every input, from being mistaken for
the semantic instance.

Only the fixed map `m_a` is classified in `U_b`. Nothing in this
argument resizes every proposition into `U_a` or claims that `U_a`
is closed under a parameterized HIT. A generic target in `U_b` is
allowed because the record and its operations live at the next
selected universe level. The ordinary strict-model representation
of this generic construction remains trusted external mathematics;
an Agda record with these fields would not itself formalize the
construction.

The concrete set-valued `SheafTruncationImage` and
`DependentSheafTruncationElimination` concern supplied contexts and families.
Even with their computation and substitution laws, applying this argument to
the native `Code`/`Truth` signature still requires the universal decoded input
family, classification of its image by the selected larger universe, and the
single generic operation context above. Their familywise laws do not construct
those classifiers or remove the explicit `Lift` in `rec-low`.

### 4. Classical extension and recovery

This section records the actual adjoint argument, because a model
with a real-line object alone would not establish classical
applicability.

Let `i : Cart -> FormalCart` include the reduced objects. For
`T=U x ell W`, set `red(T)=U`. The nilradical of
`C-infinity(U) tensor W` is precisely `C-infinity(U) tensor m_W`:
that ideal is nilpotent and its quotient is the reduced ring
`C-infinity(U)`. Every formal map therefore has a natural reduced
map. Moreover,

\[
 \operatorname{Hom}_{\mathrm{FormalCart}}(iV,T)
       \cong\operatorname{Hom}_{\mathrm{Cart}}(V,\operatorname{red}T),
\]

because a map into a reduced smooth-function algebra kills the
nilpotent ideal. Thus `i` is left adjoint to `red`, and `red i = id`.
This is the orientation needed below. An objectwise projection
`T -> i red(T)` is not natural for all formal maps and must not be
used as a replacement for this adjunction.

Restriction `r` along `i` sends formal sheaves to ordinary smooth
sheaves. The presheaf right adjoint to restriction is

\[
                         R(F)(T)=F(\operatorname{red}T).
\]

It sends sheaves to sheaves: reduction takes each displayed formal
open cover and its entire Cech diagram to the corresponding ordinary
open-cover diagram. Consequently `r` is also a left adjoint, with
right adjoint `R`, and preserves colimits as well as limits.

Let `a_C` denote formal sheafification. The left adjoint to `r` is

\[
                         E=a_C\operatorname{Lan}_{i^{op}}.
\]

On a representable `hU`, its value is `jU`, by Yoneda and
subcanonicity. The unit `hU -> rE(hU)` is therefore an equivalence.
Representables generate the ordinary sheaf infinity-topos under
colimits, and both `id` and `rE` preserve colimits. Hence the unit is
an equivalence on every smooth sheaf. This proves full faithfulness
of `E` on mapping spaces, not just on isomorphism classes. The
representable-generation theorem and the usual sheaf localization
are the general categorical inputs. [HTT]

A manifold is assembled from its open-chart Cech diagram. The same
chart diagram presents `jM`, so `E(hM) = jM`. A manifold pullback
along a submersion is preserved by `j`: use local projection
coordinates and the formal-coordinate calculation, then glue. A
surjective submersion has smooth local sections, so its image is an
effective epimorphism. These are exactly the geometric diagrams
needed for a Lie groupoid nerve.

It follows that `E` takes the classical groupoid nerve to the nerve
of `jG`. Since `E` preserves colimits,

\[
                         E([G])\simeq |N(jG)|.
\]

Applying `r` recovers `[G]`. For every test manifold `M`, the
mapping groupoid into this restriction is the groupoid of principal
`G`-bundles on `M`, including its morphisms. Full faithfulness also
includes stack morphisms represented by bibundles or refinements;
it is not restricted to strict functors between fixed presentations.

#### Why this is not a general transfer of dependent type theory

The functor `E` is not left exact. The ordinary smooth equalizer of
`x -> x^2` and `x -> 0` on `R` is the point. Its formal equalizer is
the square-zero object, which has a nonzero section `epsilon` at the
dual-number stage. Thus `E` does not preserve that equalizer.

This does not affect the proof above: the specific open restrictions,
products, and submersion pullbacks were verified separately. It does
rule out translating an arbitrary internal type-theoretic statement
by simply applying `E`. The ordinary proof is interpreted directly
inside the strict model of `H_C`, and its particular geometric
objects are then compared by `r`.

#### 5.1 The quotient atlas and path family

The manifold groupoid nerve remains a groupoid object after applying
`j`, because its defining submersion pullbacks are preserved. Form
its geometric realization `X_G`. Effectivity gives

\[
                       jG_1\simeq jG_0\times_{X_G}jG_0
\]

and makes `q_G` an effective epimorphism. The source's hom-family
is the fiber of the actual represented anchor; the displayed
equivalence supplies exactly its hom/path field. The image-based
truncation supplies mere representatives. The 0-truncation of the
manifold objects and effectivity also show that `X_G` is 1-truncated.
Universal colimits and groupoid effectivity are structural
infinity-topos properties, not assumptions of the desired orbifold
conclusion. [HTT]

#### 5.2 The pushout universal property is internal in every context

For each chosen algebra square, dualize the three boundary vertices
and form their actual pushout `B`. Retain its actual legs and glue.
For every target `Z`, the source's map is the literal restriction

\[
 (B\to Z)\longrightarrow
 \sum_{l:NE\to Z}\sum_{r:SW\to Z}(r\circ g=l\circ f).
\]

To provide the internal `IsPushout` field, pull the entire pushout
family to the generic context of `Z` in the selected universe.
Colimits in an infinity-topos are stable under base change, so the
mapping-out property holds in that slice. It is therefore an
equivalence of the internal mapping objects, uniformly in `Z` and
under subsequent substitutions. A proof only for global mapping
spaces would not suffice.

Use the semantic model's canonical function-path/homotopy
comparison to represent the glue. The separate weak `FunExt`
parameter does not contain beta or eta laws, so an arbitrary opaque
choice of weak extensionality must not be used to infer a pushout
universal property. The source instead receives the actual
restriction equivalence and proves its needed naturality by identity
elimination.

The source selects the gap by taking the inverse restriction image
of the actual SE cocone. Its `gap-section` is equality of the whole
cocone, including the glue. Any independently selected semantic
filler is identified with it by contractibility of the filler
space. Agreement of the two boundary legs alone would be an
insufficient comparison.

#### 5.3 The manifold comparison uses the specified algebra maps

Write the algebra pullback as

\[
                  W_{SE}=W_{NE}\times_{W_{NW}}W_{SW}.
\]

At a formal parameter `T=U x ell W0`, maps from a vertex into `jR`
are elements of

\[
                  C^\infty(U)\otimes W_0\otimes W_v.
\]

Tensoring real vector spaces is exact. Applied to the equalizer
description of this pullback, it proves that the map obtained from
the actual square is a bijection onto its actual matching pairs.
The algebra operations are the componentwise ones. This is the
specified `mapping-comparison`, rather than an unrelated
equivalence between the same carriers.

Finite powers give Euclidean targets. For an open target, both
boundary maps have a common reduced map because the Weil vertices
have the same augmentation point and agree on NW. The glued map
therefore stays in the open target. Chartwise construction and
unique gluing prove the statement for manifolds. All of this is
uniform in `U` and in the already present Weil directions `W0`.

This argument concerns the chosen pullback-square tests. It must
not be paraphrased as preservation of every finite limit in an
augmented Weil category, including an empty diagram with different
terminal-object conventions.

#### 5.4 The four atlas lifts are relative nilpotent lifts

For a Weil vertex `V` with augmentation point, the required
evaluation square is

\[
\begin{matrix}
 (jG_0)^V&\longrightarrow&X_G^V\\
 \downarrow&&\downarrow\\
 jG_0&\longrightarrow&X_G.
\end{matrix}
\]

Over a formal stage `T`, an object in the lower-right lifting
problem is a principal bundle over `T x V` with a specified atlas
lift over `T`. Open-locally the principal bundle is a pullback of
the source map of `jG1`. Choose a local inverse of the ordinary
etale source map through the reduced arrow. Since `T -> T x V`
is a relative nilpotent thickening with the same open-cover space,
that inverse extends the specified lift uniquely. The local unique
lifts agree on intersections and glue.

The specified lift is `T`-valued, including every pre-existing
nilpotent direction, not merely an ordinary point. Thus the result
is a pullback of mapping objects over all formal stages. Natural
identifications `A^Unit = A` give the exact bottom row used by the
source. The four prescribed points are the augmentation points
because the algebra maps preserve augmentations; transport along
their identifications is allowed if a model presentation does not
make them judgmentally equal.

#### 5.5 Whole open charts descend to mere internal charts

Ordinary properness and the etale source map give a finite
disjoint system of source branch neighborhoods around each anchor
fiber. Compactness of that fiber gives finiteness; closedness of a
proper map excludes remaining arrows after shrinking an endpoint
rectangle. For a chosen source inverse `sigma_i`, the actual domain
over a rectangle `U x V` is

\[
            D_i=U\cap S_i\cap(t\sigma_i)^{-1}(V),\qquad
            \phi_i=t\sigma_i|_{D_i}.
\]

These are open domains and smooth partial maps. They give a
diffeomorphism over the rectangle

\[
                   (s,t)^{-1}(U\times V)\cong\coprod_i D_i.
\]

Apply `j` to this entire geometric diagram. Products, open
restriction pullbacks, diffeomorphisms, and disjoint open-cover
descent are preserved. The endpoint fibers are then taken inside
`H_C`. No preservation of arbitrary classical anchor fibers is
needed, and no arbitrary set bijection is treated as a smooth map.

Each rectangle supplies an internal chart on its whole represented
open. These opens cover `jG0 x jG0`. Applying genuine bounded
truncation makes the chart family proposition-valued, so the local
existences descend to the source's `LocalBranchCharts`. This avoids
inventing a continuous global choice of charts from an arbitrary
pointwise external choice. Finite labels over disconnected formal
stages may vary locally, as sections of the internal finite type.

The point-set and smooth native constructions developed in the
project check parts of this route under their explicit hypotheses.
They are separate from interpreting the sheaf of formal points and
performing the model-level descent just described.

### 6. Nondegeneracy and the geometric recognition theorem

The reduced model contains genuine infinitesimals: at the
dual-number stage, the square-zero object has the section
`epsilon` distinct from zero. It contains the real line with its
ordinary manifold interpretation. It also contains genuine
1-types: for a nontrivial finite group `K`, the groupoid
`K => *` is proper etale, and the identity type at the canonical
point of its quotient is `K`. Thus the construction is not a model
in which all orbifold isotropy has been collapsed to a set.

For classical recognition, suppose `X` has an effective atlas
`jM -> X` and an identified kernel pair `jR`, with `M,R` ordinary
manifolds. Suppose its source and target are represented by local
diffeomorphisms, and its represented anchor is classically proper.

The Cech groupoid of the atlas supplies identity, inverse, and
composition in `H_C`. Its composition domain is represented by
`R x_M R`, because the required pullback is along a submersion.
Full faithfulness of `j` uniquely reflects these maps to smooth
maps of manifolds. The groupoid laws reflect as actual equalities:
mapping spaces between these 0-truncated manifold objects are
discrete. Therefore `R => M` is an ordinary proper etale Lie
groupoid. Effective descent identifies `X` with its represented
quotient, and Section 4 recovers its classical quotient stack.

This is a recognition theorem using ordinary geometric data, not
an interface that stores the desired conclusion `X = E([G])` as
a field. The groupoid structure and quotient identification are
derived from the actual atlas and kernel pair.

### 7. The bare reduced predicate is broader than classical orbifolds

There is a concrete counterexample to claiming that every reduced
orbifold is a finite-dimensional classical orbifold. Assume the
selected tests are the finite-Weil pullback-square family above,
and form in `H_C`

\[
                              A=\prod_{n\in\mathbb N}j\mathbb R.
\]

Each factor is local for every selected gap. Gap-local objects
are closed under limits: the two mapping-object functors in the
locality comparison preserve limits, and limits of equivalences
are equivalences. Hence `A` is local for all these gaps. It is
0-truncated, since it is a product of 0-truncated objects.

Take `q = id_A` and `hom(x,y) = (x=y)`. This is an effective atlas.
It has a one-branch chart on the whole product: use the full source
domain and the identity target map. The branch-arrow type is
equivalent to `(x=y)`. Its identity types are propositions, so they
are subfinite with one finite label and predicate `(x=y)`. The
four identity-atlas lifting maps are equivalences directly.
Consequently `A` satisfies the exact reduced theorem's conclusion.

It is not equivalent to `E([G])` for a finite-dimensional proper
etale Lie groupoid. Here is a formal-point argument that does not
depend on a choice of topology on the underlying set `R^N`.

Let `D` be the dual-number object and let `0:1->A` be the zero
point, given by the zero in every coordinate. At the terminal
ordinary stage, the fiber at zero of evaluation `A^D -> A` is
naturally

\[
                                 T_0A\cong\mathbb R^{\mathbb N}.
\]

Indeed `A(D) = (R[e]/(e^2))^N`, evaluation is coordinatewise
augmentation, and its zero fiber is `(R e)^N`. The displayed
identification concerns the resulting ordinary real vector spaces.
Addition is obtained from the two-direction
first-order Weil object
`D(2) = ell(R[e1,e2]/(e1^2,e1 e2,e2^2))`, its two axes, and its
diagonal. Scalar multiplication is induced by `e -> lambda e`.
Every map of formal smooth objects respects these operations when
its source and target satisfy the corresponding Weil comparison.

Suppose an equivalence `E([G]) -> A` existed. The zero point lifts
to an ordinary point `m` of `G0`: a principal groupoid bundle over
the terminal ordinary point is locally trivial, and that point
has no nontrivial open cover. Equivalently, its surjective bundle
projection has a point, whose moment map selects `m` and the
required isomorphism to the quotient object. The based etale
lifting square of
Section 5.4 then gives a bijection

\[
                                  T_mG_0\cong T_0A.
\]

Naturality for the preceding Weil operations makes this a linear
isomorphism. An ordinary chart at `m`, including the case of a
zero-dimensional chart, identifies the left side with `R^d` for
the finite dimension of `G0` near `m`. The right side contains
the infinite linearly independent family of coordinate vectors.
This is impossible. The tangent argument uses actual dual-number
and two-direction Weil objects in the model; it does not infer
linear structure from a mere bijection of sets of equal cardinality.

Thus the bare reduced predicate has a useful infinitesimal meaning
but does not encode finite-dimensional manifold representability.
Restriction `r` is always available on the semantic object. To
promise a classical orbifold as its value, retain the additional
geometric atlas certificate of Section 6. Without that certificate,
the honest target is a smooth higher sheaf with the specified
internal locality and finiteness properties.

This example is an external mathematical counterexample. No new
native formalization of its tangent-space argument is claimed.

### 8. A completion ledger with distinct acceptance criteria

The following obligations have different meanings and cannot be
collapsed into one percentage of completion.

| Obligation | Present status | What would justify the stronger machine-checked claim |
| --- | --- | --- |
| Ordinary internal implication from actual atlas data | Accepted native theorem; bounded ordinary closure | Maintain the source-to-interpretation boundary; proof status is in `../state.json` |
| Existence of the finite-Weil sheaf category and ordinary model | Explicit external site construction plus primary strict-model theorem | Formal construction of the category, descent, model presentation, and ordinary type formers in an appropriate metatheory |
| Bounded truncation | Constructed externally from the image of one universal family in Section 3 | Formal image factorization, classification, generic recursor, and substitution proof in the constructed model |
| Meaning of the checked source in that model | Manual ordinary-fragment dictionary and dependency audit | Formal syntax or certified elaborated-term export, plus a fundamental interpretation/substitution theorem matching all used reductions |
| Whole-family universe coding | Fixed objects/families and finite ordered cardinal choices stated explicitly | Formal universe construction and classification of those actual families, including the generic operation contexts |
| Actual quotient and atlas | External groupoid realization and effectivity construction | Formal groupoid-object nerve, realization, kernel-pair equivalence, and effective-epimorphism interpretation |
| Actual Weil tests and manifold comparison | External algebra/coordinate proof, with separate native algebra work where accepted | Formal smooth-algebra/site instance connecting the native tensor calculation to the actual formal mapping objects |
| Etale lifting over already formal stages | External unique-extension and gluing proof | Formal local inverse construction, relative nilpotent restriction, bundle descent, and the exact internal comparison map |
| Finite branch chart construction | Point-set theorem native under explicit hypotheses; smooth upgrades tracked separately | Accepted smooth construction plus a formal manifold instance and formal-point/open-cover preservation |
| Chart and representative descent | External image/epimorphism arguments | Formal sheaf-level descent terms that instantiate the actual bounded interfaces |
| Classical recovery and recognition | External adjoint/generator proof and geometric atlas reconstruction | Formal restriction/Kan-extension/sheafification functors, their adjunctions and unit, nerve preservation, and recognition theorem |
| Model of the old full foundation | Not established by this route | A separately specified model satisfying its exact stronger rules, if such a model is possible |

The first column is finite as a work-package list. Several entries
require substantial libraries, not a finite number of missing
fields in the existing Agda interfaces. A record that assumes a
soundness map, a quotient's effectivity, or the classical comparison
does not close those entries. It merely names an external boundary.

There is no remaining *logical need* for a full semantic model of
the abandoned old foundation in order to obtain the positive
reduced theorem. There is a remaining need for model and transfer
mechanization if the deliverable is required to be machine checked
all the way to the external theorem. The work completed in this
report closes mathematical ambiguity and supplies an independent
bounded-truncation construction; it does not claim those larger
mechanization tasks have been performed.

### 9. Sources and precise use

The long project-specific arguments above are supplied here; the
following primary sources supply the named general inputs. No
source is cited as a complete interpretation of this project's
Agda development.

- **[S19]** Michael Shulman, *All infinity-toposes have strict
  univalent universes*, <https://arxiv.org/pdf/1904.07004>.
  Corollary 4.9; Theorems 11.1-11.2 and A.26; Remark A.28.
  These give the ordinary strict-model and fixed-map size inputs.
- **[HTT]** Jacob Lurie, *Higher Topos Theory*,
  <https://www.math.ias.edu/~lurie/papers/HTT.pdf>.
  Theorem 5.1.5.6 and Corollary 5.1.5.8 for representable
  generation; Section 5.2.8 and Section 6.5.1 for orthogonal
  connective/truncated factorization; Theorem 6.1.0.6 for
  universal colimits and effective groupoids; Section 6.2.2 for
  sheaf localization. The application of these results to the
  selected site and source interface is the argument above.
- **[K06]** Anders Kock, *Synthetic Differential Geometry*,
  second edition, <https://users-math.au.dk/kock/sdg99.pdf>.
  The example preceding Theorem III.9.4 explicitly includes
  smooth-manifold function rings tensored with Weil algebras;
  that theorem supplies the indicated well-adapted properties.
- **[Sch16]** Urs Schreiber, *Differential cohomology in a cohesive
  infinity-topos*, <https://ncatlab.org/schreiber/files/dcct161227.pdf>.
  Section 6.5.1 specifies the finite-Weil formal smooth site;
  Proposition 6.5.11 records the differential adjoint structure
  for its higher sheaf presentation. Section 4 above gives the
  needed adjoint argument directly for the chosen nonhypercomplete
  sheaf category, rather than identifying two presentations by name.

