# Finite presentations

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="finite-branch-presentations"></a>

### Statement and scope

`src/Orbifolds/FiniteBranchPresentations.agda` gives an algebraic route from
actual finite partial-map presentations to properly finite hom types and
the actual Rezk completion. Acceptance is determined by the native receipts,
not by this description.

For a family `H : X → Y → Type`, a `FiniteBranchChart H` supplies a finite
number of labels, proposition-valued domains `D_i(x)`, target functions
`phi_i : (x : X) → D_i(x) → Y`, and equivalences of the whole family:

H(x,y) ≃ Σ i : Fin n. Σ d : D_i(x). (phi_i(x,d) = y).

When `Y` is a set, each fiber over a label is a proposition. The proof
therefore constructs an actual embedding of `H(x,y)` into `Fin n`.
Subfiniteness and proper finiteness follow, with no decision of whether
`phi_i(x,d)=y`, and no decision of whether `H(x,y)` is inhabited.

`LocalFiniteBranchChart H x y` supplies subtype regions containing the
chosen pair and a finite branch chart for the restricted hom-family.
`LocalFiniteBranchCharts H` asks for these charts merely, at every ordinary
pair. The finite-hom conclusion is propositional, so the truncations are
eliminated without selecting a global chart or choosing representatives.
Openness of the regions is unnecessary for this algebraic step; a geometric
construction can and should supply it separately.

For an actual category with invertible arrows and set-valued objects, the
module derives locally properly finite identity types of its genuine Rezk
completion. With microlinearity of the original objects and the exact
infinitesimal lifting property of the actual completion map, it constructs
the existing internal orbifold structure on the completion.

### Why this avoids the obstruction

No literal `DPProper` premise occurs. No compactness of varying diagonal
fibers, ordinary excluded middle, decidable equality of the base space,
crisp induction, smooth field axiom, or completed-orbifold conclusion is
an input to the finite-branch theorem. Distinct branch labels can represent
distinct arrows with identical endpoints, so isotropy is retained.

The explicit `identity-branch-chart` is a useful boundary case: the
identity hom-family on every set has a one-branch presentation, whose
single partial map is the identity. It therefore gives properly finite
identity types without deciding equality of the underlying objects.
In particular the finite-branch criterion does not exclude the smooth
real unit-groupoid presentation as the literal DP-proper criterion does.

The distinction is substantial: a proposition-valued subset of a finite
set is subfinite and properly finite constructively, even when its
inhabitation is undecidable. Requiring DP compactness of that proposition
would force the missing decision.

### External interpretation and remaining native transfer

Classical proper étale Hausdorff Lie groupoids admit these presentations:
the fiber over a fixed endpoint pair is compact and discrete, hence finite;
disjoint bisections around those finitely many arrows give the labels;
properness permits shrinking a rectangle around the endpoints so that no
other arrows occur. The resulting local hom formula is a finite disjoint
union of partial graphs.

The complete external argument is in
`external-models.md#finite-bisection-interpretation`. It constructs the
higher Cahiers setting with an explicit nontrivial family of finite Weil
tests, proves these charts uniformly over generalized points, and proves
manifold microlinearity and both exact atlas lifting fields. The mathematical
quotient restricts to the original classical quotient stack.

This external mathematics is not imported as an Agda axiom. Interpreting the
exact native Cubical term, including its genuine univalence, HIT and large
elimination requirements, remains separate. The source-level dependency
audit in `finite-presentations.md#finite-branch-semantic-obligations` specifies that smaller task;
it does not construct a syntax-to-model interpretation.

The finite branch route shows why the proven obstruction must not be
reported as a theorem that no extension of classical orbifolds is possible.
It rejects a proposed properness comparison while admitting the direct
geometric transfer just described. There is no claimed converse classifying
all internal orbifolds as classical ones. The countable-product example in
the external report shows that the internal predicate is broader; selecting
the classical subcategory requires geometric atlas and properness conditions.

<a id="finite-branch-semantic-obligations"></a>

## Finite-branch comparison: independent scope audit

This note checks the proposed alternative to the failed DP-properness
comparison. It separates a classical local geometric argument, the
algebraic Agda consequence, and the additional obligations of a semantic
interpretation. It does not certify that the complete external theorem or
the complete differential-cohesive foundation has been formalized.

This audit continues to describe the original
Cubical completion proof. A separate three-module ordinary theorem is now
accepted and has an external mathematical interpretation of its bounded
interface: see `finite-presentations.md#intensional-finite-branch-scope` and
`source-interpretation.md#language-bridge`. It takes the actual effective
quotient and gap maps as externally constructed inputs, then proves the
finite-identity and locality conclusion. It neither interprets this old
Cubical term nor supplies a mechanized site/model construction. The new
external full-faithfulness and classical atlas criterion are in
`source-interpretation.md#morita-comparison`.

### Classical local theorem

Let `G₁ ⇉ G₀` be an étale Lie groupoid with Hausdorff object and arrow
manifolds, and suppose that its anchor

\[
p=(s,t):G_1\longrightarrow G_0\times G_0
\]

is proper. Here the usual compact-preimage definition of properness is
enough, because the target is locally compact and Hausdorff. For each
ordinary external pair `(x,y)`, there are open neighborhoods `U` of `x`
and `V` of `y`, a finite ordinal `n`, open subspaces `Dᵢ ⊆ U`, and smooth
partial maps `φᵢ : Dᵢ → V` such that, over `U × V`,

\[
p^{-1}(U\times V)\cong\coprod_{i<n}D_i,
\qquad
p|_{D_i}(u)=(u,\varphi_i(u)).
\]

Each branch in this construction is a bisection, so `φᵢ` is also a
diffeomorphism onto an open subspace of `V`. The algebraic
`FiniteBranchPresentations.agda` consequence uses only the displayed
partial-map description, not openness or the local-diffeomorphism law.

#### Proof with the edge cases exposed

1. The fiber `F = p⁻¹(x,y)` is compact because a point is compact. It is
   discrete: an étale source chart around any arrow meets this fiber in
   at most one point. A compact discrete space is finite, so enumerate
   the arrows in `F` by a finite ordinal.
2. Choose a bisection neighborhood around each arrow of `F`. Since `G₁`
   is Hausdorff and `F` is finite, shrink these to pairwise disjoint open
   bisections `Bᵢ`. The source and target restrictions remain local
   diffeomorphisms after shrinking.
3. The map `p` is closed. To justify this from compact-preimage
   properness, take a closed `C ⊆ G₁` and a point `z` outside `p(C)`.
   Choose a compact neighborhood `K` of `z` in `G₀ × G₀`. Then
   `C ∩ p⁻¹(K)` is compact and its image is compact, hence closed in the
   Hausdorff target. Subtract that image from the interior of `K` to
   obtain a neighborhood of `z` missing `p(C)`.
4. Apply closedness to `C = G₁ \ ⋃ Bᵢ`. The open set
   `W = (G₀ × G₀) \ p(C)` contains `(x,y)`, because the entire fiber
   `F` lies in the union of the chosen bisections. Choose an open
   rectangle `U × V` around `(x,y)` contained in `W`.
5. The restricted bisections `Bᵢ' = Bᵢ ∩ p⁻¹(U × V)` form a disjoint
   open decomposition of `p⁻¹(U × V)`. Set `Dᵢ = s(Bᵢ')`. The source
   restriction is a diffeomorphism `Bᵢ' → Dᵢ`, and
   `φᵢ = t ∘ (s|Bᵢ')⁻¹` has values in `V`. This gives the claimed
   decomposition over the rectangle.

If `F` is empty, choose zero branches. Step 4 uses the closed image
`p(G₁)` and produces a rectangle disjoint from that image. The arrow
space over this rectangle is empty. No assumption that the two objects
lie in the same orbit is needed.

This proof uses properness of the anchor. It does not assume properness
of the source map. In particular, the anchor itself is not being
identified with a local diffeomorphism or a finite covering of
`G₀ × G₀`; its branches are graphs over subspaces of the source factor.

The Hausdorff assumption on `G₁` is material to this proof: it supplies
pairwise disjoint branch neighborhoods. Allowing non-Hausdorff arrow
manifolds requires an additional argument or a different conclusion;
it must not be silently included in the present theorem. Local
compactness and Hausdorffness of `G₀ × G₀` justify the closed-map step.
Second countability, effectiveness, and connectedness are not used in
this local construction. Any global atlas theorem can retain its own
additional hypotheses.

No effectiveness assumption is hidden in the labels. Different arrows
may induce the same local target function. They still occupy distinct
bisections and must retain their separate labels, so ineffective
isotropy is preserved.

For a related standard local construction, Moerdijk–Pronk give the
finite-bisection argument at an isotropy fiber in *Orbifolds, Sheaves and
Groupoids* (1997), pp. 15–16. Moerdijk's *Orbifolds as Groupoids: an
Introduction* (2002), §1.2, explicitly assumes Hausdorff object and arrow
manifolds, and §3.4 states the finite-group local-chart theorem. The
rectangle argument above spells out the version for arbitrary pairs,
including empty fibers.

Sources:

- [Moerdijk–Pronk, 1997, primary paper](https://ncatlab.org/nlab/files/MoerdijkPronk-OrbifoldsAndGroupoids.pdf)
- [Moerdijk, 2002, primary paper](https://arxiv.org/pdf/math/0203100)

### What must hold in a semantic interpretation

Let `J` denote the proposed embedding of classical manifolds into a
category of smooth sheaves or higher smooth sheaves. The preceding
classical theorem does not by itself establish an ordinary internal
statement about all generalized points. The following structures and
compatibilities must be supplied and verified.

#### Products, open subobjects and finite coproducts

The interpretation must identify `J(U × V)` with `J(U) × J(V)`, represent
the chosen open embeddings as the appropriate internal subobjects, and
preserve their restrictions. It must also turn the actual disjoint
finite branch decomposition into an internal coproduct decomposition,
including the zero-branch case.

Raw Yoneda preserves limits, but it does not preserve arbitrary
coproducts. Preservation of this finite disjoint decomposition is
justified by the sheaf condition for the disjoint open cover by the
branches, or by a suitable proved property of `J`; it cannot be inferred
from the word "Yoneda" alone.

After these comparisons, for ordinary internal points `u : J(U)` and
`v : J(V)`, the internal hom-family has the form

\[
\operatorname{Hom}(u,v)
\simeq
\sum_{i:\mathrm{Fin}(n)}
\sum_{d:D_i(u)}\bigl(\varphi_i(u,d)=v\bigr).
\]

The membership predicate `Dᵢ(u)` must be proposition valued, and `J(V)`
must be a set so that the equality constraint is proposition valued.
These are exactly the ingredients of the embedding into `Fin(n)` in
`FiniteBranchPresentations.agda`.

The equality constraint must be retained. Replacing it with an external
case distinction would reintroduce the ordinary-decidability problem.
The branch representation allows a hom type to be a varying subtype of
a finite label type; it does not assert that it is a constant finite
set or that its mere inhabitation is decidable.

#### Generalized points and descent

The rectangles supplied by the classical proof cover `G₀ × G₀`. Their
images under `J` must form an effective epimorphic cover, stable under
pullback by arbitrary generalized points. On such a pullback cover, the
fixed external branch data provide the required local internal witness.

The desired conclusion is the proposition that such a chart merely
exists, or the proposition that a hom is subfinite/properly finite.
These local proofs can descend because the target is proposition
valued. A globally chosen chart, a globally fixed branch labeling, or a
global choice of representatives is unnecessary. This use of descent
must be established in the chosen semantic framework; checking only
ordinary global points of a represented manifold does not prove it.

An arrow family over a disconnected or covered test object can change
branch locally. The internal finite coproduct, rather than a constant
external label chosen once for every family, accounts for that
behavior. In an infinitesimal site, the covering and restriction
properties must also apply to the formal test objects, not just to
ordinary manifolds.

#### Quotients and the remaining geometric conclusion

The preceding argument concerns hom finiteness in a presentation. For
the orbifold conclusion, the interpretation must additionally justify:

1. The actual internal Rezk/HIT completion represents the intended
   quotient stack, with the required identification between its
   equality types and the presented hom types.
2. The interpreted object manifold is microlinear for the precisely
   specified infinitesimal test family.
3. The interpreted atlas has the precise infinitesimal lifting
   properties consumed by `Microlinearity.agda` and the completion
   theorem; a reference to external étaleness alone must be connected
   to those properties.
4. The type-theoretic rules and constructions used by these formal
   proofs are sound in the chosen model, including the relevant
   universe bounds, truncation and HIT rules.

If a candidate model establishes these for a fixed family of externally
presented finite Weil tests, that gives a meaningful restricted theorem.
It does not automatically establish microlinearity for every member of
the original internally defined `InfinitesimalVariety` record, nor the
complete model of all Myers/Agda foundational assumptions. In
particular, tinyness of each representable finite Weil object would not
by itself prove tinyness of the larger double-negation infinitesimal
generator used elsewhere in the original development.

### Relation to the formal results

`FiniteBranchPresentations.agda` proves the algebraic implications from
the exact branch data to subfinite homs, properly finite homs, and the
finite-identification part of the actual completion. Its geometric
wrapper keeps microlinearity and infinitesimal étaleness as explicit
remaining hypotheses. This is a useful change of theorem premise, not
a silent proof of the rejected classical-properness-to-`DPProper`
comparison.

The one-branch identity chart works on any type, and the finiteness
consequence works on any set. It retains `x = y` as the proposition
under the single branch label. Thus, for the smooth-real unit
presentation, this alternative can supply the required identity
finiteness without deciding equality of its objects or making its
source-target map DP proper. It is compatible with the negative theorem
in `ExternalPropernessObstruction.agda`.

No full external orbifold-transfer theorem should be reported as proved
until the semantic and geometric obligations above have been discharged
at the stated scope. A rigorous external proof and a machine-checked
formal proof are separately reportable evidence, and neither should be
represented as the other.

### Focused dependency audit of the completed-orbifold theorem

The entry point audited here is
`FiniteBranchPresentations.Groupoid.Geometry.finite-branch-completion-orbifold`.
This is a source-level trace of the definitions and proof constructors
actually selected by that entry point. It is not an automatically
extracted closed subdevelopment, a proof that Cubical Agda conservatively
translates to another language, or a semantic soundness theorem. The
larger imported modules contain many additional results which this
particular proof does not use.

#### Actual parameters and proof chain

The theorem takes a category `C : Category ℓ ℓ`, proof that every arrow
is invertible, sethood of its object type, an ordinary type `Index`, and
an ordinary family `test : Index → TestSquare ℓ`. Its remaining inputs
are local finite branch charts for the hom-family, microlinearity of
the object type, and the two lifting properties constituting
`InfinitesimallyEtale` for the actual completion map. The tests, charts,
objects, and lifting arguments are not crisp-bound variables in this
signature. The word "crisp" in a comment in `Microlinearity.agda` does
not add a crisp binder or an elimination rule.

The selected chain is as follows.

| Component | Selected definitions | Mathematical work |
| --- | --- | --- |
| Local branch calculation | `chart-hom-embedding`, `local-chart-hom-subfinite`, `local-branches→subfinite-homs` | Proposition-valued branch fibers embed into `Fin n`; local witnesses are eliminated only into propositional truncation. |
| Proper finiteness | `subfiniteProperlyFinite`, `identitySurjection`, `isSubFinSet→Discrete` | The type itself is the finite-span domain. Decidable equality is inherited from its finite label type; no decision of object equality or of branch inhabitation is assumed. |
| Transport of finiteness | `equivProperlyFinite`, `equivSubfinitelyEnumerable`, `surjectionSubfinitelyEnumerable` | Compose the finite span's cover with an equivalence, and transport decidable equality. |
| Completion identities | `Completion.hom≃identification`, `RezkByHIT.RezkHomSet`, `RezkIsoToPathβ`, `RezkIsoToPathη` | Construct the completed hom-family and prove the identity/hom equivalence for the actual quotient. |
| Completion induction | `completionLocallyProperlyFinite`, `proposition-induction₂`, `RezkByHIT.elimProp₂` | Extend the finite-identity proposition from presented objects to every pair of completed objects. |
| Surjectivity of the atlas | `Completion.object-surjective`, `RezkByHIT.inc-surj`, `GroupoidQuotients.isSurjective[]` | Quotient induction proves mere existence of representatives; no representative is chosen globally. |
| Geometric descent | `microlinear-descends`, `Square.pushout→local`, `Square.local→pushout`, `Lifting.local-descends`, `lift-map-merely` | Pushout mapping spaces give the locality formulation. Based lifting gives a merely existing lifted diagram; elimination into `isContr` proves descent. |
| Final record | `completionOrbifoldFromLifting`, `Orbifold.Geometry.Orbifold` | Combine microlinearity and locally properly finite identity types. |

These are all ordinary, untruncated parameters except where a
propositional truncation is explicitly displayed. In particular,
`lift-map-merely` keeps its lift under truncation, and `local-descends`
eliminates that truncation into the proposition that an extension space
is contractible. There is no use of choice at this step.

#### The ordinary HoTT formulation suggested by this trace

At the mathematical level, the selected construction is expressed by
dependent products and sums, identity types and their coherence,
function extensionality, univalent universes, natural numbers and
finite inductive types, and the following three kinds of HIT:

1. **Propositional truncation**, including its dependent elimination
   into propositions at the relevant universe levels.
2. **Homotopy pushouts**, including the dependent eliminator and the
   computation laws which establish the usual mapping-space universal
   property.
3. **The 1-truncated groupoid quotient.** The actual pinned definition is
   `Cubical.HITs.GroupoidQuotients.Base._//_`: it has object points,
   paths for arrows, a two-dimensional constructor for composition,
   and a constructor making the result a groupoid. Here its relation
   is `CatIso C`, with isomorphism composition. The proof uses its
   groupoid-, set-, and proposition-valued eliminators. It is not a
   set quotient.

Univalence is a genuine selected dependency. In the pinned
`Cubical.Categories.RezkCompletion.Construction.RezkByHIT`,
`RezkHomSet` recurses into `hSet ℓ`. Its transport along isomorphisms is
defined using `isoToPath`, its coherence uses `uaβ`, and its target's
groupoid structure uses `isGroupoidHSet`. The latter depends on the
univalence-based h-level theorem for identity types of types. Thus
univalence cannot be removed from this audit simply because the final
entry point does not name `ua`.

The chosen HIT construction keeps the completed object in `Type ℓ`
when both the objects and homs of `C` lie in `Type ℓ`. The
universe-increasing Yoneda-image construction is present in the same
library file but is not the completion used here. Likewise,
`Completion.completion-universal` exports the library's
universe-polymorphic `Typeω` universal property, but the completed
orbifold proof does not call it. The proof calls the concrete quotient,
its eliminators, and its identity/hom equivalence. A separate external
identification of the interpreted quotient with the classical quotient
stack still has to be established; the fact that this universal
property is unused internally does not remove that obligation.

#### Universe accounting

There is no propositional resizing step in the selected chain.
`SubfiniteSpan X n` quantifies over an actual domain in `Type ℓ`, so
`SubfinitelyEnumerable X` and `ProperlyFinite X` deliberately live in
`Type (ℓ-suc ℓ)`. Local chart records also live at that larger level,
because they contain small proposition-valued regions. The theorem
does not lower these records or their truncations back into `Type ℓ`.

There is nevertheless genuine large elimination to interpret:

- `RezkHomSet` eliminates the small quotient into `hSet ℓ`, whose type
  lies in the next universe.
- `completionLocallyProperlyFinite` eliminates it into the
  proposition-valued family `ProperlyFinite (u ≡ v)`, again in the next
  universe.
- Propositional truncation operations are used across these displayed
  universe levels, including the map from subfinite embeddings to
  finite spans.

An interpretation must therefore supply suitable univalent universes
and stable eliminators with these universe bounds. Saying only that an
infinity-topos has finite limits and colimits does not discharge this
typed obligation. The polymorphic theorem can be instantiated at
fixed chosen levels; it does not require interpreting the unused
`Typeω` statement as a type of the object language. Universe lifts of
the unit or other elementary types are ordinary lifts, not resizing
axioms.

#### Foundation assumptions not selected

This particular proof does not use a smooth real ring, the Kock field
axiom, Kock--Lawvere, `DPProper`, decidable compactness, excluded middle,
flat or shape modalities, `RFlat`, tinyness, a right adjoint to powers,
the full double-negation infinitesimal neighborhood, or any
`InfinitesimalVariety` record. It uses neither the modality-based
alternative in `GroupoidOrbifold.ModalGeometry` nor the modal-to-lifting
bridge in `MicrolinearModal`.

Other imported declarations are also not selected: the circle and
inertia results in `Orbifold`, the suspension constructions elsewhere
in the pushout module, and the imported set-truncation constructions
in the groupoid-quotient module. Their presence in an import closure
should not be confused with their use as proof primitives here.

No crisp variable or crisp eliminator appears in the selected project
definitions. The `--cohesion` option on the entry-point module enables
language syntax but does not itself supply an axiom to this theorem.
Similarly, `--guardedness` is not an occurrence of guarded recursion in
the selected construction. No independent strict equality, outer
two-level type theory, or two-level elimination principle is used as a
mathematical premise.

#### The native Cubical implementation remains a separate obligation

The preceding paragraph does **not** mean that the actual native term
is already a term in an ordinary intensional-HoTT syntax. It is a
Cubical Agda term. Its implementation uses interval abstraction and
application, `PathP`, connections and path fillers, transport and
homogeneous composition, and the computation rules for cubical HIT
constructors. For example, `Square.gap` and `Square.glue` pattern match
directly on `push a i`, their equivalence proof uses these computation
rules, and the groupoid quotient eliminators pattern match on its
two- and three-dimensional constructors. `RezkHomSet` also contains
calculations relying on the cubical computation of universe transport.

At the core of the pinned library, `isoToPath` and `ua` are implemented
with `Glue`, while composition and partial elements use Cubical Agda's
non-fibrant `SSet` machinery. These are native cubical primitives; an
absence of a separate two-level axiom in the project does not make
their semantic interpretation automatic. Reflection helpers named
`StrictEquiv` generate ordinary equivalence proof terms checked by
Agda; their name is not evidence of an assumed strict-equality axiom.

There are therefore two distinct ways to close the remaining language
gap. One can interpret the exact selected cubical syntax, universes,
and HIT computation rules in the proposed model. Alternatively, one
can port the displayed proof chain to an ordinary univalent-HoTT
language, replacing the cubical calculations by identity-type
coherence proofs and the appropriate propositional HIT computation
laws, then apply a soundness theorem for that language. The dependency
audit identifies a substantially smaller porting target than the full
differential-cohesive development. It does not perform that port or
certify an interpretation of the existing executable proof.

For the higher Cahiers application, the external mathematical construction
is now supplied in
`external-models.md#finite-bisection-interpretation`: it fixes all
augmentation-preserving pullback squares in a small skeleton of finite
real Weil algebras, constructs the finite charts, proves microlinearity
and both lifting inputs, and identifies the quotient's ordinary restriction
with the classical quotient stack.

The remaining language task is to interpret this exact native fragment,
including its universes and quotient constructors, or to port the selected
proof to a language with the required established semantics. That work
must connect its interpreted quotient and input data to the externally
constructed objects. If the deliverable must be machine checked all the
way to classical geometry, the external site, geometric proofs, and
semantic transfer must also be mechanized. Until then they remain stated
external mathematical input. Neither route requires first constructing a
model of all the original foundational assumptions.

<a id="intensional-finite-branch-scope"></a>

## An ordinary finite-branch atlas theorem

The bounded ordinary model argument below is external mathematics. A native
proof of an implication with supplied atlas data is not a mechanized
syntax-to-model interpretation of the full cohesive development.

This is a smaller theorem with its own proof. It is not an interpretation
of the old Cubical Rezk implementation and does not establish the full
Myers-oriented joint foundation.

The complete project import closure is:

- `src/Orbifolds/Intensional/Identity.agda`;
- `src/Orbifolds/Intensional/BoundedTruncation.agda`;
- `src/Orbifolds/Intensional/FiniteBranchAtlas.agda`.

All three declare `--safe --without-K --no-import-sorts`. The independent
runner additionally passes `--no-libraries`, so the project library's
`--cubical` setting is excluded. These sources are deliberately not imports
of `Everything.agda`.


### The theorem and its actual hypotheses

The final declaration is
`Geometry.Tests.finite-branch-atlas-orbifold` in `FiniteBranchAtlas.agda`.
Fix a working level, the bounded truncation interface, function
extensionality at that level, and a small indexed family of pointed maps

\[
  b_i:1\longrightarrow B_i,\qquad g_i:B_i\longrightarrow T_i.
\]

Let `A` be a set, `X` a type, and `q : A -> X` an actual map. The inputs are:

1. An actual hom family `H(a,b)` and equivalences
   `H(a,b) ~= (q(a) = q(b))`.
2. Mere representatives for `q`: each fiber is merely inhabited.
3. Merely existing local finite partial-map charts for that hom family.
4. Locality of `A` for each `g_i`.
5. Right orthogonality of `q` to both `b_i` and `g_i`.

The conclusion is locality of `X` for every `g_i` together with subfiniteness
of every identity type `u = v` in `X`. For the designated finite Weil gaps,
the locality condition is the selected finite Weil microlinearity condition.
For another family of gaps it means locality for that other family only.

The record called `EffectiveAtlas` contains the actual map, hom family,
surjectivity and hom/path equivalences. It contains no assumption of
microlinearity, subfiniteness, or an orbifold structure on `X`. Externally,
groupoid effectivity supplies these input fields for the actual quotient;
the name of the record alone does not establish that identification.

### What subfiniteness means

A `SubfiniteWitness Y` consists of a natural number `n`, proposition-valued
membership conditions `P : Fin n -> Set ell`, and an equivalence

\[
                    Y\simeq\sum_{j:\mathrm{Fin}(n)}P(j).
\]

`Subfinite Y` is the bounded propositional truncation of this witness.
Membership in `P(j)` is not assumed decidable. A finite label family with
possibly undecidable membership does not give an enumeration of `Y`.
In particular, the result does not decide equality of smooth points.
The new source does not define the old library's `ProperlyFinite`
predicate or assert that the two predicates are definitionally identical.

A branch chart expresses the hom family as a finite sum of branch-domain
membership and equality of the branch target with the requested endpoint.
Domain membership is a proposition, and target equality is a proposition
because the target region is a set. This gives an actual subfinite witness
on each chart. Local chart witnesses are then eliminated into the
proposition `Subfinite (H(a,b))`.

`Finiteness.atlas-subfinite-identities` transfers this through the specified
hom/path equivalences and through paths from mere atlas representatives.
The two representative eliminations target a proposition. No global
choice of representatives or globally fixed branch labeling occurs.

### How the geometric descent is proved

`Extension e k` is the identity fiber of the actual precomposition map
at `k`. `mapExtension f e k` is the actual postcomposition map between
extension fibers. `RightOrthogonal e f` supplies inverse data for that
specific forward function. An unrelated equivalence of the two extension
types would not satisfy this definition.

The proof first lifts the image of the basepoint merely along the atlas.
Orthogonality at the basepoint inclusion then extends that to a mere lift
of the whole boundary map. Orthogonality at the gap transfers the upstairs
contractible extension space to the downstairs one. Function extensionality
proves that contractibility is a proposition, allowing elimination of the
remaining mere lift. Thus `Geometry.local-descends` derives locality of the
quotient from the stated inputs.

The final theorem combines this descent with the independent subfinite
identity calculation. Neither output is copied from an input field.

### Ordinary language and the universe boundary

`Identity.agda` uses ordinary inductive identity and its J eliminator,
dependent sums/products, elementary h-level arguments and explicit lifts.
Natural numbers and the indexed finite ordinal are ordinary inductive
types. There are no global project postulates, Cubical imports, interval
operations, primitive HIT constructors, univalence parameters, crisp or
modal operations, strict outer equality, or resizing rules.

The truncation interface deliberately increases universe level:

```text
Code ell  = lsuc ell
Truth ell = lsuc (lsuc ell)

Tr     : Set (Code ell) -> Set (Truth ell)
point  : A -> Tr A
squash : isProp (Tr A)
rec    : isProp P -> (A -> P) -> Tr A -> P
```

Here the recursor target `P` is at `Truth ell`. Lower inputs and targets
are explicitly lifted. Its propositional computation law follows from
target propositionhood. Nothing truncates a type already at `Truth ell`,
and no same-universe closure under parameterized higher inductive types
is required. The record itself needs one further universe.

The external construction in
`source-interpretation.md#language-bridge` first forms the genuine generic
propositional truncation family over the universe at `Code ell`. That one
fibration has a relative-presentability bound. A later universe above the
bound codes it; its unit, propositionhood and eliminator transfer along
the chosen coding isomorphism. Generic construction makes substitution
stable. The external hierarchy may skip inaccessible cardinals: syntactic
successor does not mean the immediately next inaccessible cardinal.

This is a derived bounded-interface argument using the published ordinary
MLTT model and truncation theorems. It retains their external universe
assumptions. The interpretation specializes the source at a fixed level;
it treats level indices metatheoretically and does not interpret every
feature of `Agda.Primitive` or an internal type of all levels.

### The external instance and its remaining trust boundary

For a classical Hausdorff, second-countable proper etale Lie groupoid `G`,
take `A = jG0`, `X = |N(jG)|`, and the actual atlas `q`. Effectivity
identifies the original hom family with the atlas identity fibers and
supplies mere representatives. The finite-bisection construction gives
the local charts at all formal parameters. Manifold calculations give
finite Weil microlinearity, and formal etaleness with pullback cancellation
gives both actual atlas lifting properties.

These constructions are proved externally in
`external-models.md#finite-bisection-interpretation`. The actual quotient
and the whole fixed small family of gap maps are formed externally first,
then placed in a sufficiently large starting universe. The proof does not
assume that this starting universe is closed under all quotients or
pushouts. The later bounded truncation universe is chosen afterward.

`source-interpretation.md#morita-comparison` additionally proves that the
quotient lies in the fully faithful classical image, identifies all
morphism groupoids, and gives a proper etale atlas criterion for that
image. The larger reduced predicate also has nonclassical objects; the
new internal theorem is not a classification of all its inhabitants.

The native proof, the bounded model argument, and the external geometric
instance now fit at this precise smaller boundary. The last two and the
source-level interpretation remain trusted external mathematics. An
entirely machine-checked external theorem would still require their
mechanization. The old Cubical theorem's language interpretation and the
full joint foundational problem remain separate research tasks.

<a id="intensional-atlas-morphisms-scope"></a>

## Ordinary equivalences and changes of effective atlas

Assessment date: 2026-11-08. This note describes
`src/Orbifolds/Intensional/Equivalence.agda` and
`src/Orbifolds/Intensional/AtlasMorphisms.agda`.

The new theorem proves that the **actual map** between two types with
effective atlases is an equivalence when the corresponding hom map is
fully faithful and merely essentially surjective. Its computation law
ties that hom map to the actual map's action on identity paths. It does
not assume an equivalence between the two presented types.

### Equivalence of a specified function

At a fixed level `ell`, the new definitions are

Fiber f y = Sigma x : A. f x == y
    isEquiv f = (y : B) -> isContr (Fiber f y).

The earlier `Identity.Equiv A B` record contains a forward function,
an inverse, and the two inverse laws. It is quasi-inverse data and is
not asserted to be a proposition. The new module proves its relation
to contractible fibers:

| Export | Conclusion and computation |
|---|---|
| `equiv→isEquiv e` | Contractible fibers of `forward e` |
| `isEquiv→Equiv f E` | An `Equiv` whose forward function is definitionally `f` |
| `inverseData→isEquiv f d` | Contractible fibers from the existing `InverseData f` |
| `isEquiv→InverseData f E` | Inverse data for the same function `f` |
| `equiv-path e x y` | An equivalence of identity types whose forward function is `cong (forward e)` |
| `isEquiv-cong f E x y` | Contractible fibers of the actual path map `cong f` |

Converting arbitrary quasi-inverse data to contractible fibers requires
coherence. The proof supplies it: `Adjoint.adjusted-section` changes the
right inverse law by a specified composite of paths, and
`Adjoint.triangle` proves its triangle identity by homotopy naturality.
`Adjoint.contraction` then contracts each fiber by identity induction.
No triangle identity is assumed, and no uniqueness-of-identity-proofs
rule is used.

The composition, homotopy-invariance, and two-of-three exports preserve
the actual remaining functions:

- `comp-isEquiv f g` proves equivalence of `g` composed with `f`;
- `homotopy-isEquiv f g` transfers equivalence along a displayed
  pointwise equality from `f` to `g`;
- `cancel-right-isEquiv f g` cancels an equivalent postcomposition;
- `cancel-left-isEquiv f g` cancels an equivalent precomposition.

### Fiber algebra

`Σ-path-equivalence` and `fiber-path-equivalence` give the ordinary
transport description of paths in dependent pairs and fibers.
`fiber-path` constructs a fiber identity from its base path and an
explicit commuting path equation.

For `h : (a : A) -> P a -> Q a`, `Fiberwise.total h` is the actual map

(a , p) |-> (a , h a p).

`Fiberwise.fiber-equivalence` identifies its fiber over `(a,q)` with
`Fiber (h a) q`. The two exports `fiberwise→total-isEquiv` and
`total→fiberwise-isEquiv` prove the corresponding criterion in both
directions. Their inverse laws are identity induction on the total-space
path; they do not require function extensionality.

For `h : A -> B` and `P : B -> Set ell`, `BaseChange.total h P` is

(a , p) |-> (h a , p).

Its fiber over `(b,q)` is equivalent to `Fiber h b` by
`BaseChange.fiber-equivalence`. The forward map projects the actual
pair path with `cong fst`. `base-change-isEquiv` therefore transfers
equivalence of `h` to this dependent-sum map.

The general square comparison uses maps `u : A -> B`, `v : C -> D`,
`f : A -> C`, `g : B -> D`, and an explicitly oriented square

square a : v (f a) == g (u a).

The export `fiber-map` sends

(a , p) |-> (f a , square a · cong g p).

`fiber-map-isEquiv` proves this precise function is an equivalence when
`f` and `g` are equivalences. Its proof factors the function into the
path map of `g`, concatenation with the square, and dependent-sum base
change along `f`.

Finally, `isEmbedding f` means that every actual fiber is a proposition.
`path-isEquiv→isEmbedding` derives it from equivalence of all path maps.
For the existing bounded truncation `T`,
`Surjections.embedding-surjection→isEquiv` combines this property with
`Truncation T.Surjective f`. A truncated inhabitant of a proposition
fiber can be eliminated into that same fiber, producing its contraction.
This uses no choice principle.

### The atlas comparison and its exact premises

The module `AtlasMorphisms.Comparison T ext` uses the existing
`Finiteness T.EffectiveAtlas`. Write the two atlas maps as
`q : A -> X` and `r : B -> Y`. Each effective atlas already supplies
its bounded mere surjectivity and an equivalence between its hom family
and the corresponding identity type of the presented object.

An `AtlasMorphism Q R` supplies:

1. An object map `F : A -> B` and an actual map `f : X -> Y`.
2. A commuting square `s a : f (q a) == r (F a)`.
3. A map `H a b : hom_Q a b -> hom_R (F a) (F b)`.
4. The path computation, for every `h : hom_Q a b`,

`cong f (hom-path_Q h) == s a · hom-path_R (H a b h) · sym (s b)`.

The computation uses the forward functions of the supplied hom/path
equivalences. It prevents an unrelated hom equivalence from being used
to certify a different map `f`.

`FullyFaithful m` means `isEquiv (hom-map m a b)` for all original
objects. `EssentiallySurjective m` is the parameter-varying condition

(b : B) -> Mere (Sigma a : A. hom_R (F a) b).

`included-path-isEquiv` conjugates the hom map through the hom/path
equivalences and the two square paths, then uses the displayed
computation to recover the actual `cong f`. Bounded proposition
elimination along the source atlas extends this to all points of `X`.
`essentially-surjective→surjection` uses the target atlas's mere
surjectivity and composes the actual square and hom paths.

The central result is

atlas-morphism-isEquiv m :
      FullyFaithful m -> EssentiallySurjective m -> isEquiv (map m).

`atlas-morphism-equivalence` packages the resulting inverse, and
`atlas-morphism-equivalence-map` is `refl`: its forward function is
the supplied `map m`. `atlas-morphism-inverse-data` exposes the result
in the existing `InverseData` interface.

The converse exports `isEquiv→fully-faithful` and
`isEquiv→essentially-surjective` recover both hypotheses from
equivalence of that same map. They are implications; the source does
not silently assume higher-universe function extensionality to package
their higher-level predicates as an equivalence of proposition types.

### Universe and extensionality footprint

There is one fixed geometric level `ell`. The new proofs do not quantify
over every universe inside an interface field.

| Data or property | Level or explicit parameter |
|---|---|
| Carriers, homs, fibers, `isEquiv`, `isEmbedding`, path computations, `FullyFaithful` | `Set ell` |
| `FunExt ell ell`, `CoherentFunExt ell` | `Set (lsuc ell)` |
| Existing `Code ell` | `lsuc ell` |
| Existing `Truth ell` | `lsuc (lsuc ell)` |
| `Mere`, atlas surjectivity, `EffectiveAtlas`, `EssentiallySurjective` | `Set (Truth ell)` |
| Existing bounded-truncation interface `T` | `Set (lsuc (Truth ell))` |

The atlas comparison takes `T : BoundedTruncation ell` and
`ext : FunExt ell ell`. Weak function extensionality is used to prove
that `isEquiv f` is a proposition, enabling its descent along the
source atlas. The fiber algebra and inverse-data conversions do not
require it.

The separate `CoherentFunExt ell` record explicitly contains function
extensionality together with pointwise beta and path eta laws for
`happly`. `happly-equivalence` and `happly-isEquiv` depend on this stronger
record. The atlas theorem does not use it. Its fields are not inferred
from an arbitrary implementation of the earlier weak `FunExt` record.

All truncation uses are applications of the existing `T`: low-level
witnesses are lifted to `Code ell`, and their truncations live at
`Truth ell`. There is no new truncation operation at the output level,
resizing assumption, same-universe HIT closure, or `Setω` field.

### Semantic scope

The proof terms use ordinary identity elimination, dependent sums and
products, the existing records, and the explicitly supplied bounded
interface. Their fixed-level instances therefore fit the ordinary
MLTT model and bounded-truncation construction documented in
`source-interpretation.md#language-bridge`. The additional coherent
function-space exports are conditional on the displayed `CoherentFunExt`
data; in the intended ordinary model these are the inverse and
computation laws of the canonical identity-to-pointwise-identity
equivalence. No new geometric type former is requested.

This is an external mathematical model argument, not a mechanized
soundness theorem for Agda. Native acceptance by itself does not
construct the model. Instantiating the atlas comparison geometrically
still requires actual effective atlases, the actual induced map, and
its square and hom-path computation. In the classical weak-equivalence
application, the varying full-faithfulness and mere-essential-surjectivity
inputs are the ones constructed externally in
`source-interpretation.md#morita-comparison`.

The ordinary theorem starts with a supplied map between presented types.
It does not construct such a map from bare object/hom data using an
unmentioned quotient eliminator. It imports no Cubical module and does
not automatically interpret or translate the old actual-HIT
`CompletionMoritaEquivalence.agda` proof. The older completion theorem
and its exact language-to-model obligation retain their separate scope.

### Derived atlas consumers

The accepted `PushoutLifting` module uses this actual-map fiber and
equivalence calculus to prove pullback invariance, base-change
comparisons and boundary/gap lifting. `DerivedAtlasOrbifold` uses the
same cancellation results to derive source locality from the actual
four-vertex mapping comparison and assemble the ordinary orbifold
theorem. See
[topological-bridge.md#lifting-semantics-076](topological-bridge.md#lifting-semantics).
These consumers require no value of `CoherentFunExt`. Their new
pushout universal-property input is attached to the actual restriction
map and is independent of the atlas being tested. They do not construct
a quotient map from bare groupoid data or remove the geometric
instantiation and semantic boundaries recorded above. The original
individual evidence in this scope remains the unchanged 075 evidence;
the complete 076 ordinary aggregate had fifteen modules.

The internal derived-atlas theorem and the external point-set topology
construction retain separate assumptions. Importing their modules together
does not add classical hypotheses to the internal theorem or prove a
semantic transfer between the two branches.
<a id="classical-core-scope"></a>

### Purpose and boundary

`src/Orbifolds/ClassicalFiniteGroupoids.agda` isolates a positive comparison
that does not require the differential-cohesive axioms. It concerns the
algebraic finiteness of identity types, not microlinearity or a smooth atlas.
Its ordinary excluded-middle argument is an explicit local parameter. It
does not replace crisp excluded middle in the existing geometric theory,
and it is not combined with the smooth-real Kock and Kock–Lawvere axioms.

### Positive comparison

For the explicit ordinary excluded-middle principle at the working
proposition universe, the module proves:

1. A subfinitely enumerable set is finite in the standard `isFinSet` sense.
2. `ProperlyFinite X` is equivalent to `isFinSet X`.
3. `LocallyProperlyFinite X` is equivalent to finite identity sets:
   `(x y : X) → isFinSet (x ≡ y)`.
4. These are equivalent to finite isotropy:
   `(x : X) → isFinSet (x ≡ x)`.
5. Such a type is a groupoid (a homotopy 1-type).
6. The actual homotopy quotient of a set-valued family action by a finite
   group has finite identity sets. The quotient is not replaced by its set
   of orbits.

The finite-span proof decides membership in a finite ordinal, reconstructs
the domain through the fibers of its embedding, and applies the existing
finite-surjective-image theorem. Truncated span witnesses are eliminated
only into the proposition `isFinSet`. No axiom of choice is introduced.

For the finite-isotropy comparison, the proof decides mere inhabitation
of `x ≡ y`. When it is empty, the identity type is equivalent to the empty
finite ordinal. When inhabited, a merely supplied identification
transports finiteness of `x ≡ x` to finiteness of `x ≡ y`. The elimination
again targets `isFinSet`, so no global selection of connecting arrows is
needed. The reverse implication specializes the finite-hom condition to
`x = y`. These implications yield the exported equivalences
`locallyFinite≃finiteIsotropy` and
`locallyProperlyFinite≃finiteIsotropy`.

This supplies the algebraic comparison expected in a classical
interpretation: finite identity sets are finite hom sets in a groupoid,
equivalently under the stated classical assumption finite automorphism
groups. It does not bound the number of
objects or components, construct a Lie-groupoid atlas, impose second
countability, or imply properness of an atlas. Those remain distinct
geometric questions.

### A second semantic diagnostic

For ordinary excluded middle at proposition universe `p`, the same module
proves `DPCompactAt p K` for every type `K`, at any object universe. Given
the defining premise, decide the proposition `A`: if it holds, choose the
left disjunct; otherwise each premise `A ∨ B(x)` yields `B(x)`.
Consequently every map is literally `DPProper` in the corresponding
Boolean interpretation.

Thus merely evaluating the logical compactness formula in classical logic
does not recover topological compactness. Its geometric content relies on
the non-Boolean internal logic and varying parameters of a spatial model.
This is compatible with the properness obstruction: a model of the smooth
axioms cannot supply the unrestricted ordinary excluded-middle parameter.

### What this contributes to the revised project

The finiteness portion already has a precise classical algebraic meaning.
A proposed geometric semantics must add a justified interpretation of
microlinearity and a suitable atlas/representability condition if the goal
is differentiable stacks or classical orbifolds. This module is a reusable
comparison for that program; it is not a construction or consistency proof
of the complete current differential-cohesive foundation, nor a formalized
soundness theorem for the Agda language.

<a id="morita-completion-scope"></a>

## Completion equivalences and independence of a groupoid presentation

Source: `src/Orbifolds/CompletionMoritaEquivalence.agda`.

### The missing step filled by this module

The completion/path theorem and an abstract orbifold equivalence alone do
not construct the presentation-induced comparison. This module constructs
that actual map and its compatibility, under the hypotheses below.

The library's `isEquivF-ob` theorem for weak equivalences assumes that both
input categories are univalent. The groupoid presentations here need not
be univalent. Their actual completions are used instead; the new module
does not assume a completed equivalence as an extra field.

### The actual induced map

Let `F : Functor C D`, and suppose every arrow of each category is
invertible. No sethood or decidable equality of the object types is needed
for the comparison theorem. The `Map` module constructs

completed-map : Completion.Object C invertibleC
                  -> Completion.Object D invertibleD

by the library's groupoid-quotient recursor. On an original object it is
definitionally the inclusion of `F-ob x`. On a generating isomorphism path
it is definitionally the path induced by the functor's image isomorphism.
The original functor's composition law supplies the quotient's composition
square. Groupoid truncation supplies the required higher coherence.

The exported object and arrow computation results are:

- `Map.completed-map-object`;
- `Map.completed-map-iso-path`;
- `Map.completed-map-morphism-path`;
- `Map.completed-path-map-computes`;
- `Map.original-hom-map-computes`.

These identify the map on identity types with the original functor's map
on hom types through the proved `identification≃hom` equivalences. The
proof does not select an unrelated equivalence between the two completed
types.

### Exact characterizations

The module supplies all three equivalences of propositions:

Functor.isFullyFaithful F ≃ isEmbedding completed-map

Functor.isEssentiallySurj F ≃ isSurjection completed-map

isWeakEquivalence F ≃ isEquiv completed-map.

Here full faithfulness means that every original hom map is an equivalence.
Essential surjectivity is the internal, parameter-varying condition

(y : ob D) -> || Sigma (x : ob C). CatIso D (F-ob x) y ||.

It is propositional truncation, not a supplied choice of an object and
isomorphism for each `y`.

Full faithfulness first makes the actual path map between included objects
an equivalence. Proposition induction in each completed variable then
proves that the whole completed map is an embedding. Conversely, an
embedding restricted to included objects gives the original hom
equivalences by the same explicit computation.

Essential surjectivity supplies merely a preimage for each included target
object, and proposition induction reaches all target objects. Conversely,
a mere preimage of an included target object can itself be represented
merely by an original source object. The resulting path is decoded into
an original target arrow and its invertibility data. All eliminations from
mere existence target propositions. No global representative function or
quasi-inverse functor is chosen.

The standard embedding-plus-surjection theorem then constructs an actual
equivalence whose forward function is `completed-map`. The exported names
are `Map.completed-equivalence` and
`Map.weak-equivalence≃completed-isEquiv`.

### Common refinements

The `Span` module treats a roof

C <- E -> D

whose two functors are weak equivalences in the preceding internal sense.
It constructs `Span.completion-equivalence` between the actual completions
of `C` and `D`. The theorem `Span.comparison-triangle` retains the homotopy
commuting triangle with both completion maps out of `E`.

This is the precise span-based presentation change covered here. It is not
a definition or formalization of arbitrary smooth principal bibundles,
nor a theorem that every externally described Morita equivalence already
supplies this internal data.

### Consequences for the finite branch theory

At a common geometric universe, `Invariance` proves equivalence of the
locally properly finite identity predicates on the two completion types.
For an explicitly fixed family of test squares, its `Geometry` module
also proves equivalence of the existing orbifold predicates.

The theorem `Invariance.Geometry.finite-branch-orbifold-transfer` starts
with finite branch charts, object microlinearity and the exact canonical
atlas lifting property for the source presentation. It applies the checked
finite branch completion theorem there, then transfers the resulting
orbifold structure to the target completion using the equivalence induced
by the original weak-equivalence functor.

No finite branch charts, microlinearity or atlas lifting property for the
target presentation are requested as extra assumptions. This concerns the
completed object's orbifold property; the theorem does not claim that the
particular branch chart data themselves descend to every presentation.

### Assumptions and remaining semantic boundary

The basic completion comparison allows independent object and hom
universes for `C`, `D` and a common refinement `E`; their completions have
the same maximum-universe bounds as `GroupoidCompletion`. The geometric
transfer uses the same universe for the two presentations and the chosen
tests. There is no resizing principle.

The proof uses the actual groupoid-quotient recursor, its propositional
induction, and the existing hom/identity equivalences. It does not invoke
the `Typeω` completion-universal wrapper. The underlying library proof of
the hom/identity comparison genuinely uses univalence and large
elimination, as already documented in
`finite-presentations.md#finite-branch-semantic-obligations`.

There is no additional excluded-middle, choice, smooth-real, modal,
crisp-induction, tinyness, literal DP properness or external-orbifold
assumption. The `--cohesion` option keeps the native build configuration
consistent; the new comparison uses no crisp variables or crisp
elimination rule.

The external construction in `source-interpretation.md#morita-comparison`
now supplies the displayed full faithfulness and parameter-varying mere
essential surjectivity for the chosen classical etale weak equivalences.
It also identifies quotient stacks and characterizes the classical proper
etale image. Those are external mathematical proofs. Interpreting the exact
native proof in the geometric model remains a separate language-to-model
obligation. The module supplies the constructive internal comparison, not
an Agda semantics or a formalized site/stack construction.

<a id="groupoid-etale"></a>

### The actual square

For an actual Cubical category `C` in which every morphism is invertible,
the module constructs

```text
Arrows = Σ (x , y : Objects), Hom x y
source ((x , y) , h) = x
target ((x , y) , h) = y
```

The existing `GroupoidCompletion` proves the identity/hom equivalence for
the library's actual Rezk completion. Applying it in each fiber proves
`arrows≃kernel-pair`, whose forward map sends an arrow to its source,
target and actual completed identity path. Both projections commute
definitionally. Thus `quotient-square-cartesian` certifies the canonical
comparison map itself as an equivalence.

### Theorem 5.4.9

`Presentation.Modal.canonical-object-etale` combines this square with the
proved Theorem 5.4.7 in `ModalEtaleDescent`. Its assumptions are:

- surjectivity of the modality's units;
- étaleness of the actual groupoid source map;
- equivalence of the canonical reflection comparison for each positive
  join pushout and for their positive sequential colimit.

The preservation assumptions describe independent, explicit diagrams.
They do not contain the completed object map's étaleness. Native Agda's
crisp binder alone does not discharge them. The positive shift used in
the proof removes the paper's inhabitedness and empty-preservation
requirements.

`Presentation.Modal.Geometry.completion-microlinear` then proves
microlinearity of the actual Rezk completion when the object type is
microlinear and the chosen infinitesimal test vertices are connected for
the modality. The canonical object map's surjectivity and étaleness are
both derived. `completion-orbifold` additionally uses properly finite
hom types to derive properly finite completed identities.

These results implement the homotopy-theoretic content of Theorem 5.4.9.
Instantiating the diagram preservation and connectedness hypotheses in
the paper's differential cohesive theory is a separate foundation task.

### Modal hom types

`Presentation.Modal.hom-modal` proves that genuine hom types are modal
when objects form a set, the source map is étale, and all propositions
are modal. The proof first derives modal source fibers from the étale
unit square, then imposes the propositional target equality and uses an
explicit equivalence with `Hom x y`.

For crystalline nullification, `Crystalline.Ring.proposition-crystalline`
discharges the proposition premise. This step does not claim decidable
equality of arbitrary varying hom types: that further logical property
requires its own proof.

Source correspondence: Myers, *Orbifolds as microlinear types*,
[arXiv:2205.15887](https://arxiv.org/abs/2205.15887), Theorems 5.4.7 and
5.4.9, and the source-fiber argument used in §6.3.

