# Integral affine

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="integer-embedding"></a>

## The actual integer embedding and free translations

`IntegerEmbedding.Ordered R order` proves injectivity of the canonical
ring map constructed in `IntegerCoefficients`. Its mathematical inputs
are only the commutative ring and the paper's literal order postulate O.
In particular, no Kock-field, ordered-ring compatibility, Kock-Lawvere,
crispness or excluded-middle hypothesis is used.

Repeated addition of one is strictly positive for every positive
integer. The negative-integer case follows by preservation of additive
inverses. These facts make the additive kernel trivial, which proves
injectivity and the actual homotopical embedding property.

For any index type `I`, the coordinate map `(I → ℤ) → (I → R)` is an
embedding. The literal translation
`translate z x i = integer (z i) + x i` is injective in `z`, and
`translate z x ≡ x` implies that `z` is the zero vector. Thus integer
translations are free in every finite dimension, as well as in the
stated arbitrary-coordinate generality. This is a concrete prerequisite
for the torus construction; it does not by itself assert the entire
crystallographic example or the elliptic-moduli classification.

<a id="integer-rational-lattices"></a>

## Integer separation and actual rational coefficients

The accepted modules `IntegerLatticeSeparation`, `RationalCoefficients`
and `RationalRingHom` support the literal metric-lattice definitions in
Section 2.4. They use an ordinary commutative ring, Kock field, order O,
and the explicitly recorded ordered-ring compatibility. They add no
approximation, norm-comparison, choice or excluded-middle axiom.

### Separation

For the actual canonical integer map, an integer strictly between -1
and 1 is zero. The proof uses integer constructor case analysis and
order compatibility; it does not decide the order of arbitrary reals.
Using the already proved square/interval comparison, an integer whose
square is less than 1 is zero. In every finite dimension, an integer
vector of squared Euclidean norm less than 1 is the zero vector.

### Rational witnesses

The scalar domain is the library's actual preferred rational type:
the set quotient of integer/positive-natural pairs by cross
multiplication. The interpretation into the smooth real ring is
constructed by integer coefficients and positive denominator inverses.
It is proved well-defined on that quotient and is an embedding.

Every positive real bound has a merely existing strictly smaller
positive rational, with positivity proved both in the library's
rational order and after interpretation into the real ring. The
witnesses are actual fractions 1/(n+1). The proof uses the earlier
Archimedean rational-grid construction and uniqueness of reciprocals;
rational density is not an added assumption.

`RationalRingHom` packages the same preferred rational presentation as
an actual `CommRing` using its existing proved operations, and proves
that the constructed interpretation is an actual `CommRingHom`.
The library's other rational-ring package uses a different quotient;
the module does not silently interchange those presentations.

These arithmetic results alone do not prove that every abstract rank-two lattice has a real basis or establish the elliptic-moduli quotient theorem. Those require the additional constructions and finite-free rank condition in [Complex lattices](complex-lattices.md) and [Elliptic moduli](elliptic-moduli.md).
<a id="affine-faithfulness-scope"></a>

## Faithfulness of the actual integral affine action

`IntegralAffineFaithfulness.agda` supplies the subgroup-embedding
condition for the concrete construction supporting Myers,
Corollary 3.2.9:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.

The inputs are a commutative ring `R`, the checked `StrictOrder`,
a natural dimension `n`, a group `H`, an actual homomorphism
`ρ : H → GLₙ(ℤ)`, and `isEmbedding (ρ .fst)`. The source proves
faithfulness of the induced linear action and of the actual
affine semidirect action on `Rⁿ`. In particular,
`affine-action-embedding` is an embedding of the constructed
group carrier into the set of functions `Rⁿ → Rⁿ`.

The proof evaluates affine transformations at zero to recover
their integer translation components. It then cancels that
translation, uses the checked faithfulness of the matrix action,
uses injectivity of integer coefficient change, and finally
uses the actual subgroup embedding. No equality decision for
the smooth reals or choice of representatives is used.

Finiteness and crispness of `H` are unnecessary for this
faithfulness result. The finite crisp subgroup assumptions are
supplied in the paper's final specialization. This source does
not claim an independent Euclidean isometry or cocompactness
theorem.

<a id="finite-invariant-inner-products"></a>

## Finite invariant inner products

`FiniteRingSums` proves permutation invariance of actual finite sums in
an arbitrary commutative ring. Its proof constructs the finite Kronecker
matrix, proves its evaluation formula and exchanges the two finite sums.
It works with `SumFin`, avoiding unsupported fixed-length indexed
constructor matches in cubical mode.

`FiniteInvariantInnerProducts` starts with an actual real module, an
actual symmetric positive-definite bilinear form, and a finite group
acting by actual module automorphisms. For a finite enumeration it
constructs the form

\[
  B_H(x,y)=\sum_{h\in H}B(hx,hy).
\]

Symmetry and bilinearity follow term by term. Each diagonal summand is
nonnegative, and at the index of the identity it is positive whenever
the vector is nonzero. Right multiplication by a group element is an
actual equivalence of the index type, so the finite reindexing theorem
proves invariance of the form under the action.

The enumeration is eliminated only into the propositional truncation
of the resulting form together with its invariance proof. There is no
global choice of enumeration, division by the order of the group,
classical excluded middle, or prior invariant-form hypothesis.

The ordered scalar hypotheses are the existing Kock field, strict order
and ordered-ring compatibility. The module and the finite group need
not be crisp. Their universes are independent.

All three modules described here passed canonical safe Agda 2.8.0.2 checks with
cohesion enabled, exit zero and no warnings. `IntegralAffineInnerProducts` constructs the canonical positive dot
product on actual finite coordinate modules, using finite K for its
positivity, and applies the averaging theorem to the actual integer
matrix representation. Translation cancellation proves invariance of
the resulting squared distance under every actual element of the full
semidirect affine group. The result is mere existence of this actual
form together with the complete affine isometry law.
This result alone asserts neither DP properness nor a complete
crystallographic-action theorem.

<a id="integral-affine-scope"></a>

## Literal integral affine actions

These constructions support Myers, Corollary 3.2.9:
<https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9>.

`GeneralLinearMatrices.agda` constructs `GLₙ(R)` from actual finite
square matrices and actual two-sided inverse matrices. It proves
all group laws, the coordinate action, its additivity and
invertibility, and its faithfulness. A ring homomorphism induces an
actual group homomorphism between the general-linear groups.
Coefficient change commutes with the matrix action. An injective
coefficient map induces an embedding on general-linear groups.
The matrices use the existing finite free module and matrix
operations, not an assumed group of matrix symmetries.

`LiftedGroups.agda` gives an explicit universe lift of an algebraic
group, with its actual raising and lowering group equivalences.
It makes the universe change of the integer lattice visible and
does not invoke resizing.

`IntegralAffineActions.Coordinates.Representation` takes a
commutative ring `R`, a natural dimension `n`, an algebraic group
`H`, and an actual homomorphism `ρ : H → GLₙ(ℤ)`. It interprets
coefficients with the canonical checked map in
`IntegerCoefficients.agda`. It constructs the action of `H` on the
integer lattice, the action on `Rⁿ`, and their compatibility with
integer translation. The resulting affine group is the actual
semidirect product of the lifted integer lattice with `H`.
Its operation and action satisfy the displayed formulas

`(z,h)(w,k) = (z + ρ(h)w, hk)` and
`(z,h) · x = integer(z) + ρ(h)x`.

Both formulas are statements about the constructed operations.
The action laws are checked. The source also instantiates the
accepted iterated-quotient theorem for this actual affine action.
Thus the input is an integer matrix representation, not a desired
torus classifier or quotient equivalence.

No order, Kock-Lawvere, compactness, finiteness, faithfulness of `ρ`,
or cohesion assumption is needed for this algebraic construction.
The finite crisp subgroup assumptions in the paper remain explicit
requirements for its final specialization. The current
`TranslationQuotient` is the constructed translation homotopy
quotient in the iterated-quotient model. Its comparison with the
literal set quotient `Rⁿ/ℤⁿ` and the shape computation are separate
remaining proofs. The source does not assume either comparison.

<a id="integral-affine-geometry"></a>

## Geometric integral affine action

The source [Corollary 3.2.9](https://arxiv.org/html/2205.15887v1#S3.SS2.Thmthm9)
calls the extension of a finite subgroup of `GL_n(Z)` crystallographic.
Its displayed proof constructs the extension and delooping. The geometric
properties below make the separate crystallographic interpretation
explicit for the actual semidirect action already constructed in this
formalization.

### Accepted: metric isolation in the ambient function space

`IntegralAffineSeparation.agda` is proved. It assumes
the actual commutative ring `R`, Kock field axiom, strict order and
ordered-ring compatibility, an ordinary dimension `n`, and an actual
group homomorphism `rho : H -> GL_n(Z)` which is an embedding. Finiteness
and crispness of `H` are not needed for this separation result.

For each element `g` of the actual integral affine semidirect group,
`FrameNeighborhood g` is a predicate on **all** functions `R^n -> R^n`.
It requires squared coordinate differences from `g` to be less than one
at the affine frame consisting of zero and the coordinate basis vectors.
The module proves that this ambient neighborhood is Penon open, contains
the actual transformation `g`, and contains no other transformation from
the faithful integral affine group.

The proof computes integer coordinates of every frame value. The checked
integer lattice separation theorem turns the strict squared bounds into
integer equalities; evaluation at zero recovers translation, and the
basis columns recover the actual matrix. The subgroup embedding recovers
the element of `H`. Finite conjunctions are justified by proved compactness
of the finite index sets, with no decision procedure for real predicates.

This is an explicit geometric isolation result, in addition to the
already checked abstract faithfulness. No global excluded middle,
decidable equality of smooth reals, or new axiom is introduced.

### Accepted: transporters and stabilizers

`IntegralAffineTransporters.agda` is proved. With the
source and target points fixed, two affine transformations with the same
linear part have equal translations by injectivity of the actual integer
coefficient map. Thus every transporter embeds into `H`. If `H` is finite,
the actual transporter and stabilizer types are `ProperlyFinite`. This
uses only strict order for the integer embedding; the representation need
not be faithful for this particular result.

### Accepted: a compact fundamental cover

`IntegralAffineCocompactness.agda` is proved. Its actual
`FundamentalRegion` is the image in `R^n` of the coordinate map from the
closed cube `[0,1]^n` which multiplies every coordinate by two. Assuming
the explicit `UnitIntervalCompact` premise, this image is DP compact by
the proved finite-product and surjective-image compactness theorems.

`compact-region-translates-cover` proves that every vector merely has a
representation as an affine translate of a member of this region. The
proof uses the already checked torus cube cover and effectiveness of the
actual orbit relation. The literal ordinary affine orbit set is also
proved DP compact. No unique representatives or nonoverlapping domain
are asserted. Finiteness and faithfulness of the linear group are not
needed for this compact cover; the translation subgroup already suffices.

### Accepted: the actual isometry group

`SquaredIsometryGroups.agda` is proved. For a specified
two-point quantity on a set, it constructs the actual group of
equivalences preserving that quantity. A group action preserving it gives
an actual group homomorphism into this group, and an embedding of the
action as functions induces an embedding of that homomorphism. The
application uses the chosen inner product's squared distance; no
square-root operation is required.

### Accepted: the complete geometric realization

`CrystallographicActions.agda` is also proved. It
packages a faithful action, its actual ambient open isolation
neighborhoods, and a compact fundamental cover into an embedded subgroup
of the actual isometry group when the specified distance is preserved.
Its `IsCrystallographic` record retains the isometry homomorphism's
embedding, the isolating opens on the isometry group, and the compact
fundamental cover.

`IntegralAffineCrystallographic.agda` is proved. Its
theorem

`Geometry.Subgroup.finite-integral-affine-crystallographic`

takes actual finiteness of `H` and `UnitIntervalCompact` and proves the
mere existence of a positive inner product on the actual coordinate
space together with the full crystallographic certificate for the actual
integral affine semidirect action. The inner product is supplied by the
separately accepted finite-group averaging theorem, not by an invariant
metric premise. The certificate consists of an actual injective group
homomorphism into the group of squared-distance isometries, Penon-open
neighborhoods isolating its individual image elements, and an actual
compact subset whose translates cover the whole coordinate space.

The actual homomorphism is exported through
`Geometry.Subgroup.WithMetric.Realization.homomorphism`; its underlying
function is the previously constructed affine action. Properly finite
transporters are also exported independently by the final module.

### Match to Corollary 3.2.9

Together with the accepted `TorusShape`, `TorusSplitQuotients`, and
semidirect-extension results, these theorems support classifying
Corollary 3.2.9 as **checked relative to the stated foundations**, rather
than leaving its geometric adjective as an unproved fragment:

- The torus and its matrix action are actual constructions. The shape
  equivalence targets the actual algebraic torsor classifier of
  `Z^n ⋊_rho H`, with the canonical comparison and representative triangle.
- The extension is the actual semidirect extension, with its projection,
  splitting, and kernel group equivalence. Its explicit universe lift of
  the integer vectors is group-equivalent to `Z^n`.
- For an actual finite subgroup of `GL_n(Z)`, the same semidirect group
  now has the geometric realization just described: an embedded isometry
  group, explicit metric-frame isolation, and a compact fundamental cover.

The shape layer retains native crisp real-ring, dimension, group, and
representation parameters, lower- and upper-universe R-flatness, and the
corresponding crisp identity rules. Upper-universe hypotheses are not
silently inferred from lower ones. Its order parameter is ordinary. The
additional geometric layer uses the Kock field axiom, ordered-ring
compatibility, the subgroup embedding, actual finiteness, and explicit
compactness of the unit interval. These are named foundational inputs;
no desired shape equivalence, classifier nullity, invariant metric, or
crystallographic realization is assumed.

The geometric word is formalized by the precise certificate above:
isolation uses actual finite evaluation inequalities and Penon openness,
and cocompactness uses an actual DP-compact fundamental subset. A separate
comparison with an externally presented compact-open topology, or a
different definition of proper discontinuity, is not asserted. The
inner product is constructed on `R^n`; an orthonormal change of coordinates
to the canonical dot product is not required or assumed.

No statement here identifies these geometric properties with the stronger
internal `DPProper` predicate. Ordinary finite stabilizer cardinality is
also not asserted; the constructive finiteness target is `ProperlyFinite`.

