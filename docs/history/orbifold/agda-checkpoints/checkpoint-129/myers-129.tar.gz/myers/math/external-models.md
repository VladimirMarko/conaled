# External models

Mathematical statements and constructions. Source signatures are in `../src/`;
checking status is recorded only in `../state.json`. These notes do not assert
a model or a completed cross-setting interpretation beyond their stated scope.

<a id="model-audit"></a>

## Model audit: retained theory and reduced geometric core

This chapter combines external mathematical assessments with explicitly
identified native obstruction theorems. It does not supply a machine-checked
semantic interpretation.

### 1. Finding

The classical foundations of synthetic differential geometry are supported
by actual well-adapted models. The remaining positive goal in this project
is a realization of an explicitly revised foundation and an interpretation
of the checked source fragment it supports, including its geometric objects,
substitution and universe bounds.

For the unchanged displayed native package there is already a checked
conditional incompatibility, beyond the candidate-site obstructions below:
`WeilFullPostulateIncompatibility.Context.incompatible` derives the empty
type from its exact crisp context and five stated inputs. The
[joint-obstruction chapter](joint-obstruction.md#weil-tiny-incompatibility)
owns the theorem, its precise premises and the smaller actual-comparison
obstructions. Any proposed revised foundation must identify which premise
or derivation changes. Applying that theorem to another source language
requires its interpretation; neither a general model theorem nor an Agda
check supplies that interpretation by itself.

The two immediate standard site choices fail different precise stronger
requirements. The full germ-determined Dubuc site with standard
`Flat = Delta Gamma` contains a real-line-null Cantor-valued sheaf that is
not flat discrete. The finite-Weil Cahiers site makes the full
double-negation infinitesimal neighborhood a union of finite disks that
is not externally tiny. The de Rham argument additionally proves that finite-Weil
Cahiers with the standard Flat also fails RealFlat, using a de Rham
sheaf and a native-checked finite coefficient certificate; see
`external-models.md#real-flat-de-rham`. The other complete external proofs are in
`external-models.md#cantor-realflat-obstruction` and
`external-models.md#cahiers-full-neighborhood-nontiny`. These are candidate-specific
obstructions; the separate conditional theorem for the literal native
package is identified above.

The higher Cahiers topos remains a concrete model for the reduced
finite-branch geometric theorem. That theorem uses finite Weil probes and
ordinary smooth geometry without full-neighborhood tinyness or `RealFlat`.

There is also a direct joint realization of the two algebraic assumptions
used by the properness obstruction. The stagewise Cahiers verification of
the exact finite-tuple `KockField` and `FirstOrderKL` signatures is in
[properness.md#external-properness-obstruction](properness.md#external-properness-obstruction).
This establishes nonvacuity of that smaller hypothesis package, including
ordinary varying parameters. It does not discharge the full setting or the
native syntax-to-model interpretation.

### 2. What established model constructions supply

Dubuc's 1979 **Theorem 4.10** constructs a well-adapted sheaf model with
fully faithful manifold and infinitesimal embeddings. Its proof also checks
the relevant smallness/tinyness property for the finite Weil objects using
compatibility of products with the site's covers. This supplies an actual
classical SDG model; it does not supply the later higher, crisp, or Agda
specific foundations. [D79]

Bunge, Gago, and San Luis' 2018 monograph develops a well-adapted model of
synthetic differential topology in Parts V and VI, using the germ-determined
Dubuc topos. The accessible introduction explicitly identifies that model
and the role of germ-determined ideals. The detailed chapter proofs were
not available in the retrieved preview, so this audit does not promote an
uninspected theorem about each precise Agda axiom from the book's overall
description. [BGS18]

For higher type theory, Shulman's 2019 **Theorem 11.2** provides a model
of ordinary HoTT in every Grothendieck infinity-topos: dependent sums and
products, identity types, univalent universes at suitable inaccessible
cardinals, and many higher inductive constructions, including pushouts,
truncations, and localizations. The paper states a remaining universe-closure
qualification for parametrized higher inductive types. Its theorem does
not identify the native Cubical Agda/crisp/two-level combination used here
with that syntax. [S19]

Coquand, Ruch, and Sattler construct sheaf models of univalent type theory
from a base category and Grothendieck topology, using suitable left exact
modalities on a cubical presheaf model. This is a more directly cubical
foundation route. The modal structure needed for native crisp binders and
the additional project rules still needs a compatible construction. [CRS21]

Aagaard, Kristensen, Gratzer, and Birkedal's 2024 **Theorem 4.10** gives
combined cubical/modal semantics from a cubical MTT cosmos. The hypotheses
include LOPS-topos structures and compatible modal functors, intervals, and
face lattices. **Theorem 4.15** supplies a presheaf construction. This is
substantive evidence that cubical and modal foundations can be combined,
but those hypotheses still have to be instantiated for the selected smooth
site and the project's precise rules. [AKGB24]

The July 2026 work of Coquand, Hofer, and Sattler supplies additional
constructive higher-sheaf model machinery, including hypotheses under which
higher inductive types are supported. Its introduction explicitly leaves
the identification of its constructed models with classical higher sheaf
categories conjectural. Consequently, it should not be cited as having
automatically completed the intended classical comparison. [CHS26]

### 3. Full germ-site candidate and the exact remaining ledger

Let `GermLoci` be a suitably small skeleton of the opposite category of
finitely generated germ-determined real C-infinity rings, with its open
covering topology. The concrete candidate is

\[
  \mathscr H_D=\operatorname{Sh}_{\infty}(\mathrm{GermLoci}).
\]

Its 0-truncated objects recover the corresponding ordinary sheaf topos;
the smooth line is represented by the free C-infinity ring on one generator.
The model construction is external, in classical set theory with universes
large enough for the chosen site and type universes. With the standard
constant/global-section interpretation of `Flat`, this candidate fails
`RealFlat`: see the explicit Cantor-sheaf counterexample. It should therefore
not be presented as an unverified but otherwise accepted complete model.
The following ledger records both available components and the obligations
that a revised candidate would need to meet.

#### Exact obligation matrix

Here **component available** means there is an identified external model
construction or theorem addressing a component. **Open in project** means
the exact joint realization is not established by the available files.

| Required structure | Evidence or candidate | Exact remaining obligation |
| --- | --- | --- |
| Ordinary dependent type theory, homotopy identities, univalence | S19; cubical alternatives CRS21 and CHS26 | Choose one semantic presentation and match the actual used syntax, computation principles, HITs, and universe levels. |
| Native crisp context and `Flat` | Constant/global-section adjunction is the intended semantic structure; AKGB24 gives a combined cubical/modal method | Construct the relevant two-context interpretation, including substitution and the actual Agda elimination discipline. A comonad on objects alone is insufficient. |
| `CrispIdentityInduction`, `CrispFlatInduction`, `CrispFlatComputation` | Explicit project parameters | Derive their exact signatures and computation laws in the selected interpretation; do not infer them merely from the names of modal functors. |
| `FlatTruncationDistribution` | A local-site/global-sections argument is a plausible route: the terminal test object has no nontrivial open cover | Prove the statement at both required universes, for all types and in the permitted crisp contexts, in the selected higher model. |
| Crisp excluded middle | Classical reasoning in the external discrete mode is the intended source | Verify the mode interpretation and restricted binder; it does not authorize ordinary internal excluded middle. |
| Kock's finite field condition `K` | Classical well-adapted SDG/SDT models provide the relevant field-like smooth ring; D79, BD86, BGS18 | Match the exact finite tuple/truncated-existence formulation and nontriviality in this chosen model. |
| Strict order `O`, Archimedean law, ordered-ring compatibility | Smooth order interpreted by open inequalities; BD86 addresses Archimedean local C-infinity rings | Verify each displayed field, including the separately encoded compatibility laws. An unlabelled claim that the ring is ordered is not a signature comparison. |
| `PositiveLineEquivalence` / `Exp` | The classical smooth exponential and logarithm furnish the geometric maps | Verify their interpreted equivalence and the exact order/group properties used. |
| Covering Property `E` | A smooth-site local factorization argument is the candidate; BGS18 is the fuller SDT reference | Prove the internal statement for arbitrary proposition-valued covers, uniformly over generalized parameters. Checking fixed subsets of the ordinary line is insufficient. |
| Principle of Constancy | Ordinary smooth differentiation and the zero-derivative theorem motivate the interpretation | Verify the parameterized internal formulation for all maps of the smooth-real object, not only global smooth functions. |
| First-order and Weil Kock-Lawvere `J` | Finite Weil duality is part of the well-adapted model construction | Match the project's definition of augmented finitely presented nilpotent algebras and its internal quantifiers; verify the required relative version. |
| `W` for finite Weil spectra/infinitesimal varieties | D79's finite Weil tinyness argument supplies an established component | Carry the argument through the chosen higher sheaf model and its external adjunction. |
| `W` for the whole `D = {r | not not (r = 0)}` | Germ representability motivates a larger site, but finite-Weil Cahiers fails this exact clause | The Cahiers obstruction proves that finite Weil tinyness is insufficient. Any alternative must identify the exact object and prove its higher external adjunction. |
| `RealFlat` | The intended comparison is constant/global-section discreteness versus smooth-real nullity | Both the full germ-determined Dubuc candidate and the finite-Weil Cahiers candidate with standard `Flat` fail this comparison already for a 0-sheaf (by the Cantor and de Rham constructions respectively). A revised candidate needs a new proof; generic SDG model theorems cannot discharge it. |
| Crystalline reflection as native `D`-nullification | The project actually constructs that localization | Identify the localization's external functor before borrowing properties of any de Rham/reduction functor. |
| Preservation of crisp pullbacks by this reflection | Explicit Axiom 4 / project parameter | Prove the property for the exact localization just identified; finite-Weil reduction is not a substitute. |
| Unit interval DP compactness | DP86 supplies a genuine compactness comparison for its specified geometric models | Check the interval object, boundary convention, and uniform formula at the chosen universes. This supplies no classical-to-internal properness theorem. |
| Strict outer rules `E`/`F` for the coherent appendix | Explicit `StrictCubicalExtensionality` and `StrictFunctionExtensionality` inputs | Realize the combined outer/inner theory and these strict laws. Ordinary cubical function extensionality does not discharge them. |

The main geometric theorem and the coherent appendix have different
dependency sets. An interpretation for one must not silently be advertised
as an interpretation of the other.

#### The full-generator boundary is especially important

Myers' Axiom 3 explicitly includes tinyness of the whole double-negation
neighborhood. Remark 4.3.2 distinguishes its nullification from nullification
at finite infinitesimal varieties and says their agreement in the Dubuc
setting is unclear. The subsequent crisp-pullback assertion is an additional
axiom. Consequently the project must prove the required model comparison,
or replace this foundation in the revised development. [M22]

This audit has not proved an inconsistency in the full axiom package.
It has ruled out the two particular standard candidate/extra-axiom
combinations just described. A change of site or modal structure is an
additional construction, not something supplied by relabelling either model.
The checked diagonal result rules out a particular extra properness
comparison; it does not refute the existence of models of the retained
axioms themselves.

### 4. A concrete smaller setting supporting the new geometry

Use the Cahiers site `FormalCart`, with objects

\[
  U\times\ell W,
\]

where `U` is an open Cartesian smooth manifold and `W` is a finite-dimensional
local real Weil algebra with residue field the ordinary reals. Morphisms
are the opposite C-infinity algebra homomorphisms. Covers are generated by
open covers of `U`, with the same Weil factor. Set

\[
  \mathscr H_C=\operatorname{Sh}_{\infty}(\mathrm{FormalCart}).
\]

This is an external, nondegenerate infinity-topos. Ordinary smooth manifolds
embed as 0-truncated sheaves via their functors of formal points. The
ordinary sheaf part is Dubuc's well-adapted model. Applying S19 gives a
model of ordinary HoTT in this infinity-topos at the specified universe
strength. This combination supplies an actual mathematical setting for
the reduced geometric argument below; it is not a proof that all the
retained Myers axioms or every native Agda primitive hold there.

For the reduced theorem, choose the test index to be the constant object
on a small external family of pointed finite Weil squares that are real-line
pushouts. This matches `Microlinearity.Theory test` as a parameterized
interface: it does not require an identification with every type described
by the old full internal infinitesimal-variety record. All further geometric
properties are checked directly for those tests.

In this setting a Hausdorff proper etale Lie groupoid has:

- actual finite local branch charts of its hom-family;
- a microlinear object manifold for those finite Weil tests;
- a formally etale atlas, which supplies both orthogonality fields required
  by `Microlinearity.InfinitesimallyEtale`;
- an actual quotient stack whose atlas and identity families realize the
  groupoid-completion universal property.

The proof is given in `external-models.md#finite-bisection-interpretation`. It is a useful
external theorem about a concrete model, with no reliance on internal
`DPProper`, the whole double-negation generator, `RealFlat`, or the coherent
appendix's strict rules. It provides a candidate semantic home for the new
finite-branch development while the full-setting question stays open.

### 5. Completion obligations after this audit

1. Choose the exact semantic presentation or porting language for the
   reduced native fragment identified in
   `../../finite-presentations.md#finite-branch-semantic-obligations`. The test family is already
   fixed in `external-models.md#finite-bisection-interpretation`: all augmentation-preserving
   pullback squares in a small skeleton of finite real Weil algebras.
2. Interpret the selected native proof, or port it to that language, with
   its exact quotient/completion and universe requirements. Connect those
   interpreted objects to the completed external finite-chart,
   microlinearity, atlas-lifting, and classical restriction constructions.
3. Mechanize the external site, topology, finite-bisection, and formal-etale
   arguments if an end-to-end machine-checked external theorem is required.
4. Keep a separate full-setting ledger. Its entries become complete only
   after the actual joint model obligations are proved, not after finding
   references that cover neighboring theories.

An external mathematical realization can justify a mathematical application
without itself being mechanized. Such an application must label its trust
boundary. It is different from having checked the entire semantic transfer
inside Agda.

### Primary references

- **D79:** Eduardo J. Dubuc, *Sur les modeles de la geometrie differentielle
  synthetique*, 1979, Theorem 4.10 and its proof.
  <https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf>
- **BD86:** Marta Bunge and Eduardo J. Dubuc, *Archimedian local C-infinity
  rings and models of synthetic differential geometry*, 1986.
  <https://www.numdam.org/article/CTGDC_1986__27_3_3_0.pdf>
- **DP86:** Eduardo J. Dubuc and Jacques Penon, *Objets compacts dans les
  topos*, 1986. <https://doi.org/10.1017/S144678870002718X>
- **BGS18:** Marta Bunge, Felipe Gago, and Ana Maria San Luis, *Synthetic
  Differential Topology*, 2018, Parts V-VI; accessible introduction/preview.
  <https://www.cambridge.org/core/books/synthetic-differential-topology/446AD9AE704BD756D03769528DF668A0>
- **S19:** Michael Shulman, *All (infinity,1)-toposes have strict univalent
  universes*, 2019, Theorems 11.1-11.2 and the qualification following them.
  <https://arxiv.org/pdf/1904.07004>
- **CRS21:** Thierry Coquand, Fabian Ruch, and Christian Sattler,
  *Constructive sheaf models of type theory*, 2021.
  <https://doi.org/10.1017/S0960129521000359>
- **AKGB24:** Frederik Lerbjerg Aagaard, Magnus Baunsgaard Kristensen,
  Daniel Gratzer, and Lars Birkedal, *Unifying cubical and multimodal type
  theory*, 2024, Theorems 4.10 and 4.15.
  <https://arxiv.org/pdf/2203.13000>
- **CHS26:** Thierry Coquand, Jonas Hofer, and Christian Sattler,
  *Constructive higher sheaf models with applications to synthetic
  mathematics*, 2026, introduction, Theorem 29 and Remark 30.
  <https://arxiv.org/pdf/2605.15126>
- **M22:** David Jaz Myers, *Orbifolds as microlinear types in synthetic
  differential cohesive homotopy type theory*, 2022, Axioms 3-5 and
  Remark 4.3.2. <https://arxiv.org/pdf/2205.15887>

<a id="finite-bisection-interpretation"></a>

### 1. The result

Let `G1 => G0` be a Lie groupoid whose object and arrow manifolds are Hausdorff and second countable. Assume that source and target are local diffeomorphisms and that `p = (s,t) : G1 -> G0 x G0` is classically proper, meaning inverse images of compact sets are compact. Its quotient in the higher Cahiers topos has these properties:

1. It is a 1-truncated smooth stack, with the original groupoid as the kernel pair of its object atlas.
2. Its identity families are locally subtypes of finite constant sets. The hom-family on the atlas admits the actual partial-map presentations of `FiniteBranchPresentations.agda`.
3. Its atlas is formally etale for finite Weil probes, supplying both lifting fields in `Microlinearity.InfinitesimallyEtale`.
4. It is microlinear for the explicit finite Weil test family below.
5. Its restriction to ordinary manifolds is the classical quotient stack of the original proper etale Lie groupoid.

Thus the reduced finite-branch argument has an actual external geometric realization including classical orbifold stacks. Effectiveness of isotropy is not required. If the convention for orbifolds requires effective local actions, add that condition to the input groupoid.

The statement uses finite Weil tests. It does not identify them with every object satisfying the old, internally quantified `InfinitesimalVariety` record, or realize the whole double-negation generator, `RealFlat`, all crisp rules, or the coherent appendix's outer strict rules.

### 2. Model and explicit test family

Work externally in classical mathematics, with universes large enough for a small site and the type universes. Let `FormalCart` have objects `T = U x ell W`, where `U` is an open subset of a finite-dimensional Euclidean space and `W` is a finite-dimensional local real Weil algebra with residue field the ordinary reals. Morphisms are opposite C-infinity algebra homomorphisms. Covers are generated by ordinary open covers of `U`, with `W` unchanged. Set

\[
  \mathscr H_C=\operatorname{Sh}_{\infty}
       (\mathrm{FormalCart},J_{\mathrm{open}}).
\]

Manifolds give 0-truncated objects by their functors of formal points, denoted `jM`. The ordinary sheaf model is Dubuc's well-adapted Cahiers model. Space-valued sheaves supply its higher extension; Schreiber Section 6.5.1 also describes the formal-smooth site. His cited discussion uses a hypercomplete higher presentation. We do not identify that entire presentation with our chosen `Sh_infinity` construction here: the site description and the 0- and 1-truncated geometric objects used in this argument agree. [D79, Sc16]

Fix a small skeleton, at the selected universe, of the category of finite-dimensional local real Weil algebras augmented to the ordinary reals. Take all augmentation-preserving pullback squares in this skeleton as the external test index. All four algebras, including the pullback, are required to be in this category. Dualization gives squares of pointed infinitesimal objects

\[
\begin{matrix}
 V_{NW}&\longrightarrow&V_{NE}\\
 \downarrow&&\downarrow\\
 V_{SW}&\longrightarrow&V_{SE}.
\end{matrix}
\]

Each vertex has its unique ordinary point dual to its augmentation, and all maps preserve those points. These conditions supply the connected pointed probes needed in the chart and atlas arguments below; there is no assertion for disconnected products of Weil algebras or arbitrary unpointed squares. Interpret the test index as the constant object on this external set. This gives an explicit, nontrivial family for the parameterized microlinearity interface.

For example, the family contains the algebra pullback

\[
 \mathbb R[\varepsilon,\eta]/(\varepsilon^2,\varepsilon\eta,\eta^2)
 \cong
 \mathbb R[\varepsilon]/(\varepsilon^2)
       \mathop{\times}_{\mathbb R}
 \mathbb R[\eta]/(\eta^2).
\]

Its dual test has the two square-zero lines as `NE` and `SW`, the point
as `NW`, and the first-order two-dimensional infinitesimal as `SE`.
The gap is commonly written `D(1) coproduct_* D(1) -> D(2)`; it is the
real-line pushout comparison, not an assertion that this gap is an
equivalence of all sheaves.

Here is the real-line comparison uniformly over parameters. At `T = U x ell W0`, put `A = C-infinity(U) tensor_R W0`. Maps `T x ell W -> jR` are elements of `A tensor_R W`; smooth functional calculus for the Weil extension is given by finite Taylor expansion. Tensoring real vector spaces preserves finite limits, so an algebra pullback gives the required pullback of real-valued mapping sets at every `T`. This is an equivalence of internal mapping objects. Finite powers of the line inherit it.

Shulman's Theorem 11.2 provides an ordinary HoTT model in this infinity-topos, subject to its universe and higher-inductive-type qualifications. Matching the exact native Cubical Agda proof to that semantic presentation remains separate. [S19]

### 3. Finite bisections over an arbitrary pair

Fix `q = (x0,y0)` and let `F = p^{-1}(q)`. Properness makes `F` compact. Every arrow has an open bisection neighborhood: intersect neighborhoods on which source and target are diffeomorphisms and restrict. A bisection meets `F` in at most one point. Thus `F` is discrete and compact, hence finite; enumerate it as `g1,...,gn`.

Because `G1` is Hausdorff and this set is finite, choose pairwise disjoint open bisections `Bi` about its arrows. This is the use of separation of the arrow space. Distinct arrows retain distinct labels even when their induced local maps coincide; effectiveness is unnecessary.

#### Properness removes the remaining arrows

Under the compact-inverse-image definition, a continuous proper map to a locally compact Hausdorff target is closed. Indeed, for a closed set `C` and a point `z` outside `p(C)`, choose a compact neighborhood `K` of `z`. Then `C intersect p^{-1}(K)` is compact and its image is closed in the Hausdorff target. The open neighborhood

\[
 \operatorname{int}(K)\setminus p(C\cap p^{-1}(K))
\]

avoids `p(C)`. This applies since `G0 x G0` is locally compact Hausdorff.

Apply it to `C = G1 \setminus union_i Bi`. The open set

\[
 W=(G_0\times G_0)\setminus p(C)
\]

contains `q`. Choose an open rectangle `U x V` containing `q` inside `W`. Every arrow over this rectangle now belongs to exactly one `Bi`.

If `F` is empty, take no bisections. Closedness of `p(G1)` gives the same construction with `n = 0` and no arrows over the rectangle.

#### Exact partial-domain decomposition

Define

\[
 B'_i=B_i\cap p^{-1}(U\times V),\quad
 D_i=s(B'_i)\subseteq U,\quad
 \phi_i=t\circ(s|_{B'_i})^{-1}:D_i\longrightarrow V.
\]

The `Di` are open, and each restricted source map is a diffeomorphism. There is a diffeomorphism over `U x V`

\[
 p^{-1}(U\times V)\cong\coprod_{i=1}^{n}D_i,
\]

where the map of the `i`th summand to the base is `a |-> (a,phi_i(a))`. The graphs may overlap in the base: disjointness is in the arrow space.

Taking fibers gives the natural family isomorphism

\[
 \operatorname{Hom}_G(x,y)\cong
 \sum_{i:\operatorname{Fin}(n)}
 \sum_{d:D_i(x)}(\phi_i(x,d)=y),
 \qquad x\in U,\ y\in V. \tag{1}
\]

Projection to the label is injective. Domain membership and equality in the target manifold are propositions; their truth need not be internally decidable. This is a family presentation on an open rectangle, not merely external point-fiber finiteness.

Moerdijk and Pronk's proof of Theorem 4.1 uses finite bisections and properness around an isotropy fiber. The argument above supplies the arbitrary-pair form needed here and explicitly includes partial domains and empty fibers. [MP97]

### 4. Descent to arbitrary generalized points

The functor of formal points preserves the pullbacks used above: source and target are submersions, and the restrictions to regions are open-subobject pullbacks. It sends open covers to effective epimorphic families. The finite disjoint union becomes a coproduct of sheaves because its summands form a disjoint open cover.

This does not rely on a false claim that raw Yoneda preserves arbitrary coproducts. Preservation here follows from this particular open cover and sheaf descent; the empty cover handles `n = 0`. A generalized arrow may change its label on different open parts of the parameter space. An internal section of `Fin n` records precisely this locally constant choice.

The rectangles cover `G0 x G0`. A map from a formal test object into `j(G0 x G0)` factors locally through them, because open membership is determined by the map on its underlying ordinary points. On each part, (1) gives an isomorphism of sheaf families. In the internal logic this proves

\[
 (x,y):jG_0\times jG_0\quad\vdash\quad
 \bigl\|\operatorname{LocalFiniteBranchChart}
                 (\operatorname{Hom}_G,x,y)\bigr\|.
\]

Thus the quantifier is the ordinary, parameter-varying quantifier required by the Agda interface. There is no internal choice operation or global enumeration. One may take the set of all available finite charts as the external cover.

The geometric construction supplies open source and target regions.
The Agda record `LocalFiniteBranchChart` itself asks only for
proposition-valued regions containing the selected pair; it does not
require openness. Thus these open-rectangle bisection charts are a
stronger geometric source of the abstract record, not a characterization
of all data that can inhabit it.

The constructive algebraic lemma then gives properly finite homs from the embeddings into finite sets. No internal `DPProper` assumption is involved.

### 5. Manifold microlinearity

The real-line comparison is valid at every formal stage by Section 2, and taking finite products proves it for Euclidean spaces.

An open subset `O` of a Euclidean space inherits the comparison. A finite Weil thickening has the same underlying topological space as its reduced base. A formal map into Euclidean space therefore factors through `O` exactly when its reduction does. The Euclidean extension of a compatible test cocone into `O` has the same reduced value, so remains in `O`; uniqueness is inherited.

For a manifold `M`, compatible maps from `V_NE` and `V_SW` have a common value at their canonical point, since they agree on `V_NW`. At an arbitrary formal parameter stage, cover the underlying parameter space so this common reduced value lies in one manifold chart. All the Weil maps then factor through that chart. The preceding argument gives their unique extension there, and descent glues it. This proves the internal mapping-object equivalence defining microlinearity of `jM` for the chosen tests, uniformly over parameters.

### 6. Quotient and the exact atlas lifting fields

Let `X = |N(jG)|` be the geometric realization of the groupoid nerve. Effectiveness of groupoid objects in an infinity-topos gives an effective epimorphism `q : jG0 -> X` with kernel pair `jG1`. The arrow fibers are sets, so `X` is 1-truncated. Its identity fibers on the atlas are the original hom-families. This is the groupoid-completion universal property and identifies the mathematical completion with the quotient stack.

For every finite Weil object `V` with canonical point `0`, the atlas gives an internal pullback square

\[
\begin{matrix}
 (jG_0)^V&\longrightarrow&X^V\\
 \downarrow\mathrm{ev}_0&&\downarrow\mathrm{ev}_0\\
 jG_0&\xrightarrow{q}&X.
\end{matrix} \tag{2}
\]

To prove this, pull the atlas back along a map into the quotient. This is the principal groupoid bundle classified by the map. Locally it is an etale space over its base, because source and target are local diffeomorphisms. Etale maps uniquely lift across nilpotent Weil thickenings once the value on the reduction is given. In local coordinates the lift is the inverse of the relevant local diffeomorphism. The thickening does not change open covers, so these unique lifts glue. This proves (2) at every formal parameter stage, with a contractible space of lifts, not just pointwise existence.

The actual interface has two fields. For a test square put

\[
 B=V_{NE}\mathop{\sqcup}\limits^h_{V_{NW}}V_{SW},
 \qquad g:B\longrightarrow V_{SE}.
\]

These are `Boundary` and `gap`. Mapping out of a homotopy pushout is a pullback. The three versions of (2) for `NW`, `NE`, and `SW`, with compatible basepoints, therefore prove its version for `B`. Hence `q` is right orthogonal to `* -> B`, the field `lift-base`.

The versions of (2) for `B` and `SE` identify the corresponding mapping objects into `jG0` with pullbacks along `q`. The gap preserves basepoints. Cancellation of these pullback squares says that

\[
 (jG_0)^{V_{SE}}\longrightarrow
 (jG_0)^B\mathop{\times}_{X^B}X^{V_{SE}}
\]

is an equivalence. This is right orthogonality to the gap, the field `lift-gap`. Both required fields are thus supplied.

Microlinearity descends along this effective epimorphism using those two fields. A boundary map into `X` locally lifts after lifting its basepoint; microlinearity upstairs extends it; gap orthogonality controls uniqueness and gluing. Any pair of generalized points of `X` also locally lifts to the atlas. Their identity type becomes a hom-family of Section 4. Proper finiteness is a proposition, so these local witnesses descend. This proves the reduced orbifold conclusion.

### 7. Classical restriction and examples

On an ordinary manifold `T`, the open covers computing the quotient are ordinary manifold covers. Restricting the construction to ordinary tests therefore gives exactly the stackification of smooth maps into `G0` and `G1`, equivalently the classical stack of principal `G`-bundles. Thus its classical restriction is `[G]` itself.

Joyce's Definition 4.13 and Theorem 4.14 compare proper etale groupoid formulations of orbifolds in smooth-algebraic and ordinary smooth sites. This report needs only the direct quotient identification above, not a new equivalence theorem for every category of orbifolds. [J12]

Two concrete cases are useful:

- **A manifold as its unit groupoid.** One everywhere-defined identity branch gives `Hom(x,y) = (x = y)`, a subtype of `Fin 1`. Mere inhabitation need not be internally decidable. This is compatible with the checked failure of the smooth-real diagonal to be `DPProper`.
- **A smooth finite group action on a Hausdorff manifold.** Global branches are indexed by group elements, with target `h.x`. Thus `Hom(x,y)` consists of `h` such that `h.x = y`, even for an ineffective action. The action groupoid is classically proper: over a compact subset of `M x M`, each branch has a closed subset of the compact first projection as its inverse image, and there are finitely many branches.

The same reduced theorem applies to etale groupoids supplied directly with local finite-branch charts. Properness is a sufficient geometric source of open-rectangle bisection charts. It stays a separate condition when the target is to be a classical orbifold under the proper-diagonal convention. Finite isotropy alone supplies neither properness nor the open-rectangle geometric condition proved here; this does not assert that it fails to supply the weaker Agda record in an appropriately specified setting.

#### Finite open branches need not give a proper quotient

There is an elementary example with a Hausdorff manifold atlas and even
global finite open-branch data. Let

\[
 G_0=\mathbb R\times\{0,1\}.
\]

Include all identity arrows, and include a unique arrow between `(x,0)`
and `(x,1)` in each direction exactly when `x` is nonzero. Thus `G1` is
the disjoint union of two copies of `R` for identities and two copies of
`R minus {0}` for the cross-copy arrows. Both manifolds are Hausdorff and
second countable. Source and target are local diffeomorphisms; inversion
and composition are smooth, as is seen on these components. All isotropy
groups are trivial.

There are two global partial branches on `G0`: the identity with domain
all of `G0`, and copy-swap `(x,i) |-> (x,1-i)` with open domain `x != 0`.
They give exactly the finite-branch hom-family presentation, with no need
to shrink source or target regions. The resulting quotient satisfies the
reduced finite-Weil orbifold predicate by the same manifold-microlinearity,
etale-atlas, and finite-branch arguments used above.

Nevertheless `p = (s,t)` is not classically proper. In the `(0,1)`
component of `G0 x G0`, consider the compact convergent sequence with its
limit

\[
 K=\{((1/n,0),(1/n,1)):n\geq1\}
       \cup\{((0,0),(0,1))\}.
\]

Its inverse image is the sequence `{1/n : n >= 1}` in the cross-arrow
component `R minus {0}`. It is not compact: the continuous function
`x |-> 1/x` has the unbounded image `{1,2,3,...}` on it. The limiting
cross-arrow at zero is absent.

The quotient is the line with doubled origin. Nonzero points in the two
copies are identified, while the two origins remain distinct. Every
neighborhood of either origin contains a punctured interval around zero,
so neighborhoods of the two origins always intersect. The quotient is
therefore non-Hausdorff, despite the Hausdorff object and arrow manifolds.
In sheaf terms this is the quotient obtained by gluing two represented
lines along their punctured open subobjects.

Under the classical convention used here, orbifolds have Hausdorff
orbit spaces and proper etale presentations. This example is outside that
class, but supplies an explicit nonproper smooth object with the reduced
orbifold properties. It proves that external properness cannot be dropped
even when the presentation has a Hausdorff manifold atlas and finite
open branches. All assertions in this subsection are the elementary
external argument just given; no native checked status is claimed.

### 8. Direction of comparison and the larger class

The theorem constructs `G |-> X_G` from a classical proper etale Lie
groupoid and proves that restriction of `X_G` to ordinary manifolds is
the original quotient stack `[G]`. It does not prove that every object
satisfying the reduced internal `Orbifold` predicate has a classical
finite-dimensional orbifold presentation.

There is a concrete reason for that distinction. In this model consider

\[
 X=(j\mathbb R)^{\mathbb N}.
\]

This is a set. Products preserve the mapping-object pullback comparison
defining finite-Weil microlinearity, so `X` is microlinear. Each of its
identity types is a proposition, hence a subtype of `Fin 1` and properly
finite. Thus it satisfies the reduced orbifold predicate. The corresponding
abstract closure results already occur as `Microlinearity.Theory.microlinear-Π`
and `Orbifold.Geometry.microlinearSetOrbifold` in the development.

Its ordinary restriction is the sheaf

\[
 T\longmapsto C^\infty(T,\mathbb R)^{\mathbb N}.
\]

Suppose this were represented by a finite-dimensional manifold `M`, and
let `m0` correspond to the zero sequence. The coordinate projections of
the sheaf would be smooth maps `pi_n : M -> R`. For every real sequence
`v`, the family `t |-> (t v_n)_n` would correspond to a smooth curve
`c_v : R -> M` through `m0`, satisfying

\[
 d\pi_n\bigl(c_v'(0)\bigr)=v_n.
\]

Taking the coordinate unit sequences gives arbitrarily many linearly
independent tangent vectors at `m0`: applying `d pi_n` to any finite
linear relation extracts its `n`th coefficient. This contradicts finite
dimension. The argument uses smooth curves on ordinary test manifolds,
so it does not assume that restriction preserves any formal-infinitesimal
tangent construction.

The restriction is set-valued. If it had a classical proper etale
orbifold presentation, its isotropy would therefore be trivial. Such an
orbifold stack is represented by a manifold: the local finite-group
charts have trivial stabilizers and give ordinary manifold charts on the
quotient. That would contradict the preceding argument. Hence this
particular reduced internal orbifold is not a classical finite-dimensional
orbifold even after ordinary restriction.

The classical subcategory must consequently retain explicit
finite-dimensional manifold-atlas and external properness conditions.
The larger class of finite-Weil-microlinear stacks with properly finite
identities remains a meaningful external target; it includes examples
without classical finite-dimensional orbifold atlases.

### 9. Evidence boundary

| Item | Status |
| --- | --- |
| Finite bisections from classical proper etale hypotheses | External proof, including empty fibers, partial domains, and ineffective labels. |
| Generalized-point hom-family chart | External sheaf proof, with preservation and descent spelled out. |
| Concrete site and finite Weil tests | External construction and uniform mapping calculation. |
| Manifold microlinearity and both atlas lifting fields | External proofs above. |
| Quotient and recovery on ordinary manifolds | External universal-property and stackification arguments. |
| Finite charts imply properly finite homs and the conditional completion theorem | Native module `src/Orbifolds/FiniteBranchPresentations.agda`; consult `../state.json` for source checking status. |
| Interpretation of every primitive of that exact native implementation | Not implemented or machine checked here. Ordinary HoTT semantic theorems provide a route, not a native compiler receipt. |
| Entire old Myers/crisp/cohesive/strict setting | Not claimed; see the model audit and Cantor obstruction. |
| External site and classical Lie-groupoid proof fully formalized in Agda | Not completed. |

This is an actual external mathematical model and theorem for a smaller, explicitly selected geometric language. An entirely machine-checked external theorem still requires formalizing this semantic transfer, or stating it as trusted external mathematics.

### Primary sources

- **D79:** Eduardo J. Dubuc, *Sur les modeles de la geometrie differentielle synthetique*, 1979, Theorem 4.10. <https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf>
- **Sc16:** Urs Schreiber, *Differential cohomology in a cohesive infinity-topos*, version 2016-12-27, Section 6.5.1, Definitions 6.5.5-6.5.7 and Proposition 6.5.8. <https://ncatlab.org/schreiber/files/dcct161227.pdf>
- **S19:** Michael Shulman, *All (infinity,1)-toposes have strict univalent universes*, 2019, Theorem 11.2 and its qualifications. <https://arxiv.org/pdf/1904.07004>
- **MP97:** Ieke Moerdijk and Dorette A. Pronk, *Orbifolds, Sheaves and Groupoids*, 1997, Theorem 4.1 and proof. <https://doi.org/10.1023/A:1007767628271>; author-hosted copy <https://www.math.colostate.edu/~renzo/teaching/Orbifolds/pronk.pdf>.
- **J12:** Dominic Joyce, *An introduction to C-infinity schemes and C-infinity algebraic geometry*, 2012 version, Definition 4.13 and Theorem 4.14. <https://arxiv.org/pdf/1104.4951>

<a id="cahiers-full-neighborhood-nontiny"></a>

### 1. Statement and semantic meaning of tinyness

Use the ordinary or higher Cahiers sheaf model on formal Cartesian probes `T = U x ell W`, with `W` a finite-dimensional local real Weil algebra and covers generated by open covers of `U`. Let `R` be the represented smooth line and put

\[
 \mathcal D=\{d:\mathbf R\mid\neg\neg(d=0)\},
 \qquad D_n=\{d:\mathbf R\mid d^{n+1}=0\},\quad n\geq 0.
\]

Then each `D_n` is a finite Weil object, but `D` is not externally tiny: the functor `(-)^D` on this sheaf category has no right adjoint. Thus this model cannot satisfy the full-neighborhood clause of Axiom W with its usual external-adjunction meaning, even though finite Weil tinyness is a standard property of the model.

This targets an external right adjoint to exponentiation, not an ordinary internal dependent right adjoint. In `TinyTypes.agda`, the corresponding external comparison is deliberately under `Flat`, with crisp object parameters. With `Flat = Delta Gamma`, it is the external mapping-space adjunction. Natural representability in its domain variable yields the usual external right adjoint. The counterargument only uses a countable diagram of fixed objects, all within a sufficiently large universe.

### 2. Identify the exact double-negation object

At a formal probe `T = U x ell W`, a section `r` of the line is an element of

\[
 A=C^\infty(U)\otimes_{\mathbb R}W.
\]

Let `r_red : U -> R` be its reduction along the augmentation of `W`.

The proposition `not (r = 0)` holds at `T` exactly when `r_red` is nowhere zero. If its reduction vanishes at `u`, the ordinary point `u : * -> T` pulls `r` back to zero, contradicting the negation. Conversely, a nowhere-zero body has a smooth reciprocal; the nilpotent correction has a finite geometric-series inverse. Thus `r` is invertible and cannot become zero at any nonempty probe over `T`.

It follows that `not not (r = 0)` holds exactly when `r_red` vanishes identically. If `r_red(u)` is nonzero, the ordinary point at `u` refutes double negation. If the reduction is identically zero, every pullback also has zero reduction, so no nonempty probe can force `not (r = 0)`. Consequently

\[
 \mathcal D(T)=C^\infty(U)\otimes_{\mathbb R}\mathfrak m_W,
\]

where `m_W` is the nilpotent augmentation ideal. This calculation uses generalized-point semantics for negation, not merely testing whether the section vanishes on an open subset of `U`.

Since `m_W` has a finite nilpotence exponent, every section of `D` at this probe belongs to some `D_n`, with a bound depending only on `W`. Therefore

\[
 \mathcal D=\mathop{\operatorname{colim}}_{n\geq0}D_n
\]

as an increasing union of subobjects, and the canonical morphism

\[
 p:\coprod_{n\geq0}D_n\longrightarrow\mathcal D \tag{1}
\]

is an effective epimorphism. In fact each section at each formal probe has a lift to one summand; no new cover is needed for that particular section.

### 3. Tinyness would produce a section of (1)

Suppose exponentiation by `D` had an external right adjoint. It would then preserve colimits because it would be a left adjoint. Exponentiation also preserves limits. It consequently preserves effective epimorphisms: apply it to the Cech nerve of (1), using limit preservation for the nerve and colimit preservation for its realization. In the ordinary topos this is the corresponding kernel-pair/coequalizer argument.

Hence

\[
 p^{\mathcal D}:
 \left(\coprod_nD_n\right)^{\mathcal D}
       \longrightarrow\mathcal D^{\mathcal D}
\]

would be an effective epimorphism. Pull it back along the global element `id_D` of `D^D`.

The terminal probe has a one-point body and only trivial nonempty open-cover refinements. A covering sheaf map therefore lifts a section at the terminal probe to an actual section. Here the fiber is 0-truncated, since the source and target of (1) are sheaves of sets. There is thus a global map

\[
 \ell:\mathcal D\longrightarrow\coprod_nD_n,
 \qquad p\ell=\operatorname{id}_{\mathcal D}. \tag{2}
\]

The passage from an epimorphism to a global lift is special to this terminal-probe property. No general internal axiom of choice is being assumed.

### 4. The section must choose one fixed order

Each `D_n` is represented by the Weil algebra `R[e]/(e^(n+1))`. Its body is one point and it has no nontrivial open covers. A map from `D_n` to the constant natural-number sheaf is therefore a single constant natural number, by Yoneda.

A map `D -> N` is a compatible family of maps `D_n -> N`, by the colimit description. All the `D_n` share their zero point, so those constant values must agree. Every map `D -> N` is constant.

Compose (2) with the summand-index map `coproduct_n D_n -> N`. The result is therefore a fixed natural number `N`. By disjointness of coproducts, (2) factors through that summand:

\[
 \mathcal D\xrightarrow{\ell_N}D_N
          \xrightarrow{j_N}\mathcal D,
 \qquad j_N\ell_N=\operatorname{id}_{\mathcal D}.
\]

Since `j_N` is monic, this would make it an isomorphism. Equivalently, every element of `D` would satisfy the same bound `d^(N+1) = 0`.

At the allowed probe `D_(N+1)`, the universal element `e` has zero reduction and hence belongs to `D`. But `e^(N+1)` is nonzero in `R[e]/(e^(N+2))`. This contradicts that uniform bound. Therefore exponentiation by `D` has no external right adjoint.

This refutes a universal equation by evaluating it at a generalized stage;
it does not assert an internally inhabited type of nonzero nilpotents.
The contextual form is equally explicit. Over any nonempty probe
`T = U x ell W`, pass to `T x D_(N+1)`. The new free coordinate has
nonzero `(N+1)`st power in
`C-infinity(U) tensor W tensor R[e]/(e^(N+2))`. Thus the universal
equation cannot hold in any nonempty context. If the order is a locally
varying natural-number section, restrict to an open part on which that
section is constant before applying this argument.

### 5. Scope and consequences

The result distinguishes the whole double-negation neighborhood from every finite Weil disk. It is entirely consistent for each `D_n` to be tiny while their filtered union is not tiny. A proof of W for finite Weil spectra does not extend automatically to `D`.

This is a failure of the finite-Weil Cahiers candidate when the full W clause is required. The separate Cantor-sheaf proof identifies a failure of the full germ-determined Dubuc candidate with the standard `Flat = Delta Gamma` and exact `RealFlat`. Together these show that the two immediate standard site choices do not discharge the complete stronger package as stated.

They do not prove inconsistency of that package in all models. Enlarging or changing a site, changing a modal interpretation, or weakening the package would require new checks, including compatibility of tinyness, real-line nullity, and the rest of the syntax.

The positive finite-bisection theorem only needs finite Weil tests and ordinary quotient-stack geometry. It does not invoke tinyness of `D` and is unaffected by this obstruction.

### 6. Sources and provenance

The argument above is an explicit external proof constructed for this audit. The source below supplies the underlying model and finite-Weil component; it is not being cited as already stating this whole-neighborhood counterexample.

- Eduardo J. Dubuc, *Sur les modeles de la geometrie differentielle synthetique*, 1979, Theorem 4.10 and proof, including the formal-manifold site and finite Weil exponential argument. <https://www.numdam.org/article/CTGDC_1979__20_3_231_0.pdf>
- David Jaz Myers, *Orbifolds as microlinear types in synthetic differential cohesive homotopy type theory*, 2022, Axiom 3 and Remark 4.3.2, for the distinction between finite infinitesimal varieties and the whole double-negation generator in the intended setting. <https://arxiv.org/pdf/2205.15887>

The native project signature being assessed is `src/Orbifolds/TinyTypes.agda`, particularly `External.Candidate.ExternalAdjunction` and `External.Tiny`.

The new native module
[`TinyExhaustionObstruction.agda`](../src/Orbifolds/TinyExhaustionObstruction.agda)
formalizes the abstract algebraic heart of the obstruction; its precise
scope is recorded in
[`tiny-colimits.md#tiny-exhaustion-obstruction`](tiny-colimits.md#tiny-exhaustion-obstruction).
The Cahiers site, the identification of the double-negation neighborhood,
and the semantic preservation/lifting arguments remain the external
mathematics of this report.
<a id="cantor-realflat-obstruction"></a>

### 1. Precise statement

Take the full open-cover site opposite to finitely generated, germ-determined real C-infinity rings, and its ordinary or higher sheaf topos. Interpret the smooth real line by its representable object and `Flat` by the standard constant/global-sections composite `Delta Gamma`.

Then the project's `RealFlat` assertion fails already for a 0-truncated object. There is a sheaf `F` for which

\[
 F\longrightarrow F^{\mathbf R}
\]

(the constant-map morphism) is an isomorphism, but the counit

\[
 \Delta\Gamma F\longrightarrow F
\]

is not an epimorphism, hence is not an equivalence.

In `CrispPropositions.agda`, `RealFlat` quantifies over crisp types and asserts the equivalence between these two properties. The externally constructed sheaf `F` is such a fixed type. The obstruction therefore concerns the exact direction from real-line nullity to flat discreteness, not a stronger unasked-for claim about arbitrary internally varying types.

### 2. The site hypotheses, checked explicitly

Write a site object as `L = ell A`, where

\[
 A=C^\infty(\mathbb R^n)/I
\]

and `I` is germ-determined. The rings are finitely generated as C-infinity algebras; the ideals are not required to be finitely generated. This is the distinction between fair and finitely presented rings in Joyce Definition 2.9. [J12]

Let `|L|` be the set of real points, with the topology generated by evaluation of elements of `A`. Its presentation identifies it with the closed zero set `Z(I)` in `R^n`, with the subspace topology. The topology is generated by open-localization covers, whose real-point maps are ordinary open covers. Dubuc's open-cover construction and discussion of germ-determined reflection give these site facts; Joyce also states the open-cover topology for the corresponding schemes. [D81, J12]

Two particular checks matter:

- **Products with the line.** Before germ-determined reflection, adjoining a free coordinate gives `C-infinity(R^(n+1))` modulo the ideal generated by the pullback of `I`. Its real zero set is `Z(I) x R`. Reflection to a germ-determined ideal does not change its zero set. The coordinate/evaluation topology is the product topology, so `|L x R| = |L| x R` naturally.
- **A Cantor body is present.** Let `C` be the middle-thirds Cantor subset of the ordinary real line and `I(C)` the ideal of smooth functions vanishing on `C`. This ideal is point-determined, hence germ-determined: if a function has, at every point, a germ belonging to the localized ideal, it vanishes on `C`, so belongs to `I(C)`. Conversely membership implies germwise membership. Smooth bump functions separate a point outside the closed set `C` from `C`, so `Z(I(C)) = C`. Therefore `L_C = ell(C-infinity(R)/I(C))` is an allowed site object with body `C`.

The first check remains valid when the categorical coproduct of germ-determined rings differs from its raw C-infinity-algebra coproduct: the reflection preserves real points and their evaluation topology. No assumption that these two algebraic coproducts are identical is needed.

### 3. Construct a reduced continuous Cantor-valued sheaf

Define, for every test locus `L`,

\[
 F(L)=\operatorname{Cont}(|L|,C),
\]

where `C` carries its ordinary Cantor topology. Pullback is composition with the continuous map on real-point spaces induced by a locus morphism. Continuous maps glue uniquely on open covers; thus this is a sheaf for the specified site topology. Regard it also as a 0-truncated object of the higher sheaf topos.

This is intentionally not the representable Cantor locus. A representable singular locus may contain additional infinitesimal mapping data. The functor `F` forgets that data by its definition, so none of the subsequent reasoning assumes that such infinitesimal directions vanish in a representable.

### 4. Real-line nullity is a natural isomorphism

Since the smooth line is representable and products of loci exist, the sheaf exponential is evaluated by

\[
 (F^{\mathbf R})(L)=F(L\times\mathbf R)
  =\operatorname{Cont}(|L|\times\mathbb R,C).
\]

For any continuous map `h : |L| x R -> C` and any `a` in `|L|`, the function `r |-> h(a,r)` is constant: the real line is connected, whereas every connected subset of the Cantor set is a point. Put `g(a) = h(a,0)`. This `g` is continuous by composition with the zero section, and `h = g composed with projection`.

The constant-map transformation and evaluation at zero are therefore inverse bijections at every test locus. They are natural under all locus morphisms. Thus `F -> F^R` is an isomorphism of sheaves, not merely a statement about global paths or ordinary points.

### 5. The flat counit fails

The terminal locus has one real point, so `Gamma F = C` as an external set. The constant sheaf `Delta C` is the sheafification of the constant presheaf on this set. Because covers are open-localization covers, its sections over `L` are precisely locally constant functions from `|L|` to the set `C` with the discrete topology. Equivalently, a section is locally one fixed label in `C`; these local labels glue. The counit is the inclusion of these locally constant functions into continuous Cantor-valued functions.

At `L_C`, the identity map

\[
 \operatorname{id}_C\in\operatorname{Cont}(C,C)=F(L_C)
\]

is not locally constant. The Cantor space has no isolated points, so it cannot even become locally constant on an open cover of itself. Consequently this section does not locally lift through `Delta C -> F`. The counit is not an epimorphism.

All objects involved can be placed in a sufficiently large fixed universe. No unbounded quantification or size escape is used.

### 6. Consequences and limits

This proves a failure of the standard full Dubuc-site candidate with `Flat = Delta Gamma`. Merely citing that site as a well-adapted SDG/SDT model cannot discharge the exact `RealFlat` axiom.

It does not show that the whole axiomatic setting is inconsistent. A different site, different justified modal structure, or a revised axiom package requires its own assessment. Nor does it prove that the finite-branch geometric core has no model.

In the finite-Weil Cahiers site, the bodies of basic probes are open subsets of Euclidean spaces, hence locally connected. Every continuous map from such a body into the totally disconnected Cantor set is locally constant. The same sheaf construction therefore becomes `Delta C` there; it gives no corresponding counterexample in that site. The separate full-neighborhood tinyness obstruction explains another boundary of that smaller model.

The proof also says nothing by itself about whether Covering Property E or Principle of Constancy holds in the full Dubuc site. It identifies one exact failed comparison, which already prevents the claimed complete model with these modal choices.

### 7. Primary references and proof provenance

The Cantor-sheaf counterexample is the explicit argument given here; it is not attributed to an unverified theorem in a source. The references establish the site definitions it uses.

- **D81:** Eduardo J. Dubuc, *Open covers and infinitary operations in C-infinity-rings*, 1981, Definition 3, Proposition 4, Definition 6 and the germ-determined reflection discussion following it. In particular, reflection is stated to leave the real zero set unchanged. <https://www.numdam.org/article/CTGDC_1981__22_3_287_0.pdf>
- **J12:** Dominic Joyce, *An introduction to C-infinity schemes and C-infinity algebraic geometry*, 2012 version, Definition 2.9, Proposition 2.10, Theorem 3.4, and Definition 4.1. <https://arxiv.org/pdf/1104.4951>

<a id="germ-site-followup"></a>

### 1. Candidate being tested

One possible next construction would use probes `U x L`, where `U` is an open Cartesian manifold and `L` belongs to a selected small class of smooth loci with a one-point body. That class would contain finite Weil loci and the full smooth germ of the real line at zero. The proposed covers are ordinary open covers in `U`.

This avoids the specific Cantor-body counterexample: a continuous map from the locally connected body `U` to the Cantor set is locally constant. It does not establish `RealFlat`, whose quantifier ranges over every small sheaf or higher type, not just reduced sheaves obtained from ordinary continuous maps.

No primary theorem realizing the exact joint package in this proposed site was found in the bounded follow-up. Neither a complete model nor a new impossibility theorem is claimed here.

### 2. An established germ-representability ingredient

Kock, *Synthetic Differential Geometry*, second edition, Section III.10, Proposition 10.4 gives a useful precise ingredient. For the stated full subcategory of smooth algebras and subcanonical topology, the following are equivalent for a line element: noninvertibility in the internal sense, vanishing at every ordinary real point, and factorization of its algebra map through the smooth germ algebra at zero. The nearby Theorem 10.3 identifies the double-negation neighborhood in the particular models treated there. [K06]

Thus adjoining a represented point-germ is mathematically motivated. It can provide an object containing zero-body elements that are not nilpotent to any finite order, so the finite-Weil exhaustion used in the Cahiers nontinyness proof is no longer available. This explains how that particular obstruction might be avoided. It is not by itself a proof that the new site realizes full-neighborhood W.

### 3. Actual remaining obligations

1. **Specify the site.** Choose a small class of one-point loci closed under the products actually needed. Construct its products with Cartesian opens, and verify that the resulting objects and morphisms are the intended smooth-algebraic ones. Restricting a category by a name or by its point spaces does not establish these facts.
2. **Verify the topology.** Pullbacks of the proposed open covers along arbitrary morphisms of probes must again be covers of the required form. Verify subcanonicity, open-subobject descriptions, and the relation between a probe's real-point body and its localization maps.
3. **Identify the exact double-negation object.** Apply the germ factorization result with the hypotheses actually checked for this site, and verify the field/noninvertibility comparison needed to identify `not not (r = 0)`. A represented germ object is not automatically the internal formula merely because both are called infinitesimal.
4. **Prove tinyness, not just representability.** Exponentiation by the represented germ evaluates a sheaf at the product of a probe with that germ. To deduce an external right adjoint, prove the relevant preservation of sheaf colimits, for example by showing that this product functor has the required continuous/cocontinuous relation to the coverage so sheafification commutes with precomposition. The intuition that the extra factor has one body point is a possible proof ingredient, not an adjoint theorem on its own.
5. **Establish `RealFlat` for all types.** One sufficient route would show that every basic probe with a contractible Cartesian body becomes contractible under the localization generated by real-line projections, and that constant higher objects are real-line null. In particular the one-point factors must disappear under that localization. The full line germ has a scalar real-line contraction, but a nonhomogeneous singular or Weil factor does not inherit the same formula automatically. Ordinary connectedness of its body is weaker than this localization statement. Conversely, failure to exhibit a direct contraction is not proof that the localization is nontrivial.
6. **Finish the joint interpretation.** Even if both geometric conditions were proved, the retained covering, constancy, crystalline localization, crisp-context, universe, native Cubical, and any strict outer rules would still need the exact compatibility checks in `external-models.md#model-audit`.

A workable next bounded milestone is therefore an explicit site plus its product/coverage lemma and germ-object identification, followed by an independent computation of real-line localization on its one-point generators. It would be premature to advertise the full model before the latter calculation.

### 4. De Rham follow-up: resolved for finite Weil factors

For the finite-Weil site, [the de Rham construction](external-models.md#real-flat-de-rham)
supplies the real differential class, smooth comparison, sheafification,
real-line invariance and failed flat counit. The extension to a site with
arbitrary germ factors remains unproved; the investigation below concerns
that distinct germ-ideal obligation.

A potentially sharper test arose during the earlier search. De Jong gives an explicit finite-dimensional Artinian complex algebra

\[
 B=\mathbb C[x,y]/(x^4+y^5+xy^4,x^{100},y^{100})
\]

with nonzero degree-one cohomology of its ordinary, non-derived algebraic de Rham complex. The example uses Reiffen's calculation, treated in Appendix B of Taroyan's paper. [DJ25, T26]

One could investigate whether a sheaf of local, non-derived smooth de Rham cohomology on the proposed site is real-line null but not flat discrete. For finite Weil coefficients, the smooth-parameter Poincare argument is a promising route. This would require proving all of the following before claiming a counterexample:

- the real form of the Artinian example gives the required nonzero smooth-algebra differential cohomology, with the precise comparison of algebraic and smooth differentials;
- the chosen construction is a sheaf, or its sheafification has the asserted values;
- real-line invariance holds naturally at every parameter stage and survives that sheafification;
- for the germ-enlarged site, integration/homotopy operators respect the actual germ ideals and the chosen coverage;
- the resulting object is in the universe to which `RealFlat` applies and its flat counit demonstrably fails.

For the finite-Weil site, the combined conclusions are now established by
the linked078 proof. Nontrivial cohomology of an algebra alone would not
have sufficed. For the germ-enlarged site, the additional integration and
ideal-compatibility obligation above remains open; the078 proof does not
claim that extension.

### References

- **K06:** Anders Kock, *Synthetic Differential Geometry*, second edition, 2006, Section III.10, especially Proposition 10.4 and Theorem 10.3. Author's text: <https://users-math.au.dk/kock/sdg99.pdf>.
- **DJ25:** A. Johan de Jong, *de Rham cohomology of an Artinian ring*, September 28, 2025. Author's primary note: <https://www.math.columbia.edu/~dejong/wordpress/?p=4986>.
- **T26:** Gregory Taroyan, *De Rham Theory in Derived Differential Geometry*, arXiv version 3, February 9, 2026, Appendix B. <https://arxiv.org/pdf/2505.03978>.

<a id="real-flat-de-rham"></a>

## A de Rham obstruction to RealFlat in finite-Weil Cahiers

Assessment date: 2026-11-08 (Atlantic/Reykjavik). Status: a proved external
mathematical obstruction for the specified model, with a native-checked
finite coefficient certificate. The construction of the sheaf model and
the interpretation of its type theory are not mechanized by the certificate.

### 1. Exact assertion

Let `FormalCart` be the finite-Weil Cahiers site used throughout this
project: its objects are `U × ℓW`, for a Cartesian open `U` and a finite
real Weil algebra `W`, with opposite smooth-algebra maps and covers
generated by open covers of `U`. Work in its ordinary sheaf topos or in
the 0-truncated objects of its higher sheaf topos. Interpret the smooth
line by its representable and `Flat` by `Delta Gamma`.

There is a fixed, 0-truncated sheaf `F` for which the constant-map morphism

\[
 F\longrightarrow F^{\mathbb R}
\]

is an isomorphism, whereas `Delta Gamma F -> F` is not an epimorphism.
Consequently the direction from real-line nullity to flat discreteness in
`CrispPropositions.RealFlat` fails for this interpretation. A sufficiently
large chosen type universe contains this one sheaf, so the counterexample
is to the axiom for a crisp fixed type, not merely to a stronger assertion
about a varying family of types.

This is a second obstruction in the finite-Weil candidate, independent of
its failure of full-neighborhood tinyness. It does not establish that the
abstract joint Myers-oriented assumptions have no model, nor does it
establish the same de Rham construction on a germ-enlarged site. The
reduced finite-Weil orbifold theorem does not use `RealFlat` and is
unaffected.

### 2. A real Weil algebra with a nonzero differential class

Put

\[
 f=x^4+y^5+xy^4,\qquad
 W=\mathbb R[x,y]/(f,x^{100},y^{100}).
\]

The ideal `(x,y)` of `W` is nilpotent: every monomial of total degree
199 contains either `x^100` or `y^100`. Its quotient is `R`. Thus `W`
is a finite-dimensional local real algebra with residue field `R`, and
is a real Weil algebra. Evaluation at the origin shows that its unit is
nonzero. The finite Taylor prescription equips it with its usual unique
smooth-algebra structure.

The Artinian construction is due to de Jong, using Reiffen's example;
Taroyan treats the corresponding smooth calculation in Appendix B. [DJ25,
T26] The following explicit separating functional supplies the finite
calculation needed over the reals, without relying on descent from a
complex example.

Consider

\[
 \omega=\left(\frac{x^5}{5}+xy^5+\frac{x^2y^4}{2}\right)dy.
\]

Its derivative is `f dx ∧ dy`, so its image in the algebraic de Rham
complex of `W/R` is closed. If that image were exact, lift the asserted
primitive and the relations in the module of differentials to `R[x,y]`.
For the three generators `g_i` of the ideal, one obtains

\[
 \omega=dh+\sum_i g_i\alpha_i+\sum_i\beta_i\,dg_i,
\]

where the `alpha_i` are polynomial one-forms and the `beta_i` are
polynomials. Applying `d` gives

\[
 f\,dx\wedge dy=\sum_i d\bigl(g_i(\alpha_i-d\beta_i)\bigr).
\]

The terms from `x^100,y^100` have coefficients of degree at least 99.
Modulo `(x,y)^6`, the equation therefore requires polynomials `a,b` with

\[
 f=\partial_x(fb)-\partial_y(fa)\pmod{(x,y)^6}.                 \tag{1}
\]

Only terms of total degree at most two in `a,b` can contribute below
degree six. Write `a_ij,b_ij` for their coefficients. The five selected
coefficients of the right side of (1) are:

| Monomial | Coefficient |
| --- | --- |
| `x^4` | `5 b_10 - a_01` |
| `y^5` | `b_10 + b_01 - 6 a_01` |
| `xy^4` | `2 b_10 - 5 a_10 - 5 a_01` |
| `x^3y` | `4 b_01` |
| `x^2y^3` | `-4 a_10` |

Let `lambda` be the coefficient functional with weights

\[
 (-28,-92,116,23,-145)
\]

in this order. It annihilates the right side: the coefficients of
`b_10,a_01,b_01,a_10` respectively are

\[
 -140-92+232=0,\quad 28+552-580=0,\quad -92+92=0,\quad -580+580=0.
\]

The other constant, linear and quadratic input coefficients contribute
zero to these five positions. In contrast,

\[
 \lambda(f)=-28-92+116=-4\ne0.
\]

This contradicts (1), proving that `[omega]` is nonzero in
`H^1(Omega^*_{W/R})`.

#### The exact mechanized part

`src/Orbifolds/Intensional/DeRhamJetCertificate.agda` defines signed
integers, finite monomial lists, monomial multiplication by a basis
monomial, differentiation, coefficient extraction and the functional.
It proves by native normalization:

- all five displayed rows, for the twelve actual differentiated basis
  inputs `a,b` in `1,y,y^2,x,xy,x^2`;
- `annihilates-all-twelve-columns`;
- `separates-target`, whose value is the canonical integer `-4`;
- `target-functional-nonzero` by disjointness of integer constructors.

The native coefficient calculation uses ordinary intensional algebra and
no extra axiom. It computes actual polynomial operations rather than
assuming a matrix. Extension from the basis calculation to arbitrary real
polynomials, the degree cutoff and differential quotient argument are
external mathematics. It does not formalize a general integer-ring
normalization theorem, the de Rham complex, or a sheaf model.

### 3. Comparing smooth and algebraic Weil differentials

For a real Weil algebra `W`, every ordinary `R`-linear derivation
`delta:W -> M`, with `M` an arbitrary `W`-module, satisfies the smooth
chain rule. Here is the needed reason, including the nilpotent remainder.

Write the inputs of a smooth operation as their real residues plus
nilpotents. Choose a Taylor order strictly above the nilpotence bound.
The value of the operation in `W` is its finite Taylor polynomial.
Differentiate that polynomial using the algebraic derivation law.
Its partial derivatives agree with the values in `W` of the smooth
partial derivatives. Terms beyond the nilpotence bound vanish; the
total derivatives of such zero polynomial elements also vanish under
`delta`. Choosing the extra Taylor order ensures that discarding a
remainder before differentiation does not discard a surviving
lower-degree term. This proves the smooth chain rule.

Conversely a smooth derivation is an ordinary real derivation. The two
modules of differentials therefore represent the same derivation
functor on every `W`-module, giving their canonical isomorphism. Exterior
powers and the universal differential identify the full ordinary
smooth and algebraic de Rham complexes of `W`.

For a Cartesian open `U`, the smooth coproduct `C^infty(U) tensor_infty W`
is the ordinary finite-Weil scalar extension, whose underlying vector
space is `C^infty(U) tensor_R W`. This follows directly by the same
finite Taylor formula. The universal property for smooth derivations
on a coproduct gives

\[
 \Omega^1_{C^\infty}(C^\infty(U)\otimes_\infty W)
 \cong (\Omega^1_{\mathrm{sm}}(U)\otimes W)
       \oplus(C^\infty(U)\otimes\Omega^1_{W/\mathbb R}).
\]

The ordinary smooth differential module on a Cartesian open is the
module of smooth one-forms. Taking exterior algebras gives the natural
isomorphism of differential graded algebras

\[
 \Omega^*_{C^\infty}(C^\infty(U)\otimes_\infty W)
 \cong \Omega^*_{\mathrm{sm}}(U)\otimes_\mathbb R\Omega^*_{W/\mathbb R}, \tag{2}
\]

with total differential
`d(alpha tensor beta) = d alpha tensor beta + (-1)^deg(alpha) alpha tensor d beta`.
This differential, rather than a degreewise vector-space identification
alone, is what is needed below.

### 4. Constructing the sheaf and computing its values

Define a presheaf of abelian groups on `FormalCart` by

\[
 P(T)=H^1\bigl(\Omega^*_{C^\infty}(\mathcal O(T))\bigr),
\]

using pullback of differentials for every actual formal smooth map, and
let `F = aP` be its associated sheaf. In particular, functoriality for
maps that mix the ordinary and nilpotent coordinates is built into this
construction. It is not inferred from a formula that only covers maps
preserving the chosen factors.

Fix `W` and let `K(W)=H^1(Omega^*_{W/R})`. On a small convex open ball
`V`, the usual smooth radial Poincare chain homotopy, tensored with the
identity on `Omega^*_{W/R}`, contracts (2) onto `Omega^*_{W/R}`. The
cross terms cancel with the signs in the total differential. All
coefficient spaces of the latter complex are finite-dimensional, so
integration of coefficient functions is ordinary componentwise smooth
integration. Thus constant Weil forms give a quasi-isomorphism on
such `V`, and

\[
 K(W)\xrightarrow{\ \cong\ }P(V\times\ell W).
\]

These constant-form maps are compatible with restriction to smaller
balls. The covers of `U × ell W` are generated by ordinary open covers
of `U` with the fixed factor `W`. Consequently restricting the
associated-sheaf calculation to that fixed-factor slice is exactly
ordinary sheafification on `U`. The balls form a basis, hence

\[
 F(U\times\ell W)\cong \operatorname{LC}(U,K(W)),                \tag{3}
\]

where `LC` means locally constant functions to the underlying discrete
abelian group. Formula (3) is an isomorphism on this open-cover slice;
no assertion that arbitrary formal maps act merely by a fixed map of
Weil factors is needed or made.

At the point-body object `ell W` the topology has only trivial
nonempty basic covers. In particular (3) gives `F(ell W)=K(W)`. The
nonzero class constructed above survives sheafification.

### 5. Real-line nullity and failure of the flat counit

For each test object `T=U × ell W`, pullback along its actual projection
`T × R -> T` induces, under (3),

\[
 \operatorname{LC}(U,K(W))\longrightarrow
 \operatorname{LC}(U\times\mathbb R,K(W)).
\]

This is an isomorphism: every locally constant function on the product
is constant on each connected real-line fiber; evaluation at zero is
its inverse and yields a locally constant function on `U`. These maps
are the components of the single canonical presheaf/sheaf morphism
induced by the projections. Therefore their naturality for all formal
morphisms is automatic from that construction. Since the test objects
generate the sheaf topos, they establish `F -> F^R` as an isomorphism.

This argument computes the associated sheaf before testing real-line
invariance. It does not appeal to a general claim that sheafification
preserves real-line invariance.

For the terminal test object, `W=R` and `U` is a point. Its degree-one
de Rham cohomology is zero, so `Gamma F` is the singleton zero group.
Thus `Delta Gamma F` is the terminal zero sheaf, and its counit into
`F` is the zero section. At the specific `ell W` above the class
`[omega]` has no local lift along this map. A point-body probe has no
proper nonempty open restriction on which a nonzero class could become
zero. The counit is therefore not epimorphic, and in particular is
not an equivalence.

The object is 0-truncated, so this calculation applies unchanged in
the higher sheaf topos. Choose an inaccessible universe above the
fixed site's size and the section sizes of `F`; the bounded type
universe then contains this counterexample. No internal excluded
middle is introduced into the smooth model by this external classical
construction.

### 6. Consequences and limits

The de Rham calculation in `external-models.md#germ-site-followup` is now
resolved for the finite-Weil site by the explicit real class,
differential comparison, slice sheafification calculation, natural
real-line invariance, size bound and failed counit above. The analogous
calculation on a site with arbitrary germ factors still requires
control of integration and the actual germ ideals. It is not implied
by the finite-dimensional calculation.

The positive external interpretation of the reduced atlas theorem
continues to use the same nondegenerate higher Cahiers topos. There
is no contradiction: that theorem deliberately omits `RealFlat`, the
full double-negation tinyness axiom, and the literal classical-to-DP
properness identification.

### References and provenance

- **DJ25:** A. Johan de Jong, *de Rham cohomology of an Artinian ring*,
  September 28, 2025, author's primary note:
  <https://www.math.columbia.edu/~dejong/wordpress/?p=4986>.
- **T26:** Gregory Taroyan, *De Rham Theory in Derived Differential
  Geometry*, arXiv:2505.03978v3, February 9, 2026, Appendix B,
  especially Proposition B.8: <https://arxiv.org/pdf/2505.03978>.
- The displayed five-row separating certificate and its native
  implementation were derived in this project. Its exact arithmetic
  was independently checked both by the native module and by a direct
  finite monomial calculation. The external comparison/sheaf argument
  was independently reviewed in the supplied mathematical review.

<a id="site-transfer"></a>

## Extending the finite-Weil RealFlat obstruction along actual smooth sites

Status: external mathematical argument, independently reviewed on
2026-11-08. This is not a native Agda or Lean construction of either site, their
sheaf categories, or their adjunction. It supplies concrete site hypotheses for
the proposed conditional transfer theorem. Its counterexample input is the
external construction in external-models.md#real-flat-de-rham-078, not just that report's
machine-checked finite coefficient calculation.

### 1. Result and scope

Let C_open be the finite-Weil formal smooth site whose objects have coordinate
algebras

\[
 B(V,W)=C^\infty(V)\otimes_\infty W,
\]

where V is any open subset of a finite-dimensional real affine space and W is a
finite-dimensional local real Weil algebra with residue field R. Morphisms are
all opposite smooth-algebra homomorphisms. Covers are ordinary open covers of V
with W fixed. The symbol tensor-infinity denotes coproduct of smooth algebras;
in this particular Weil case its underlying real algebra is the ordinary
tensor product.

The same conclusions hold for a Cartesian or ball basis C_cart, with the
qualification in Section 5. It is not necessary to assume that such a literal
Cartesian basis is closed under every principal open.

There are actual fully faithful site functors

\[
 i:C_{\mathrm{open}}\longrightarrow D
\]

for each of the following precise choices of D:

1. D_fp: the opposite category of finite presentations of smooth algebras,
   with all smooth-algebra homomorphisms, and the topology generated by
   arbitrary small principal-localization families covering every real point.
   This is the mathematical category and coverage encoded in conaled's
   SmoothPresentationCategory, SmoothOpenCover and SmoothOpenTopology at commit
   5867d02ecfc290b7a3b7505cc94acbb98f4f49ff.
2. D_germ: the opposite category of finitely generated germ-determined smooth
   algebras, with the open-cover topology of Kock III.7. Localizations here use
   germ-determined reflection when necessary. This qualification matters.

For either choice, restriction of presheaves restricts to an adjunction

\[
 r:\operatorname{Sh}(D)\rightleftarrows\operatorname{Sh}(C_{\mathrm{open}}):U,
 \qquad r\dashv U,
\]

whose right adjoint is fully faithful. An explicit formula is

\[
 (UF)(d)=
 \operatorname{Nat}(i^*y_d,F)
 \cong
 \operatorname{Hom}_{\operatorname{Sh}(C_{\mathrm{open}})}
       (a_C i^*y_d,F).                                      \tag{1}
\]

Here i-star in the formula is presheaf restriction and a_C is sheafification.
The assertions that UF is a D-sheaf and that the counit rUF to F is an
isomorphism are proved below.

Restriction preserves terminal objects and products, and

\[
 r(R_D)\cong R_C,                                            \tag{2}
\]

where the smooth lines are represented by the same ordinary real-line probe.
Equation (2) is the required line comparison. No assertion
U(R_C) = R_D is made or needed.

Consequently the existing finite-Weil de Rham witness F gives a witness UF
against the RealFlat implication for the interpretation Flat = Delta Gamma in
each of these larger ordinary sheaf topoi. This extends the scope of that
specific obstruction; it does not establish inconsistency of every proposed
Myers model.

### 2. The probes really are finitely presented

This is needed before treating C_open as a subcategory of D_fp.

#### 2.1 Arbitrary ordinary opens

For V open in R^n, choose a smooth function chi on R^n whose nonzero locus is V.
For example, suitably weighted countably many bump functions supported inside
V give such a function, with convergence of all derivatives. The graph
x maps to (x,1/chi(x)) identifies V with the regular
closed hypersurface chi(x)t = 1. Restriction gives

\[
 C^\infty(V)\cong
 C^\infty(\mathbb R^{n+1})/(\chi(x)t-1).                       \tag{3}
\]

The graph is closed in R^(n+1), the derivative in t is nonzero along it, and
smooth extension together with the regular-level-set ideal calculation gives
the quotient assertion. In particular this is a one-relation finite
presentation, even if V is disconnected or not diffeomorphic to R^n.
It also proves the localization identity

\[
 C^\infty(V)\{h^{-1}\}\cong
 C^\infty(\{v\in V:h(v)\ne0\})                               \tag{4}
\]

for h in C-infinity(V). Bunge--Dubuc [BD86, Corollary 1.2(a), printed pp. 8--9]
give the graph presentation and its localization universal property.

This step is also represented concretely in the inspected conaled sources:
EuclideanOpen.openDefining and openDefining_locus use Mathlib's existence of a
smooth function with the prescribed open nonzero locus. EuclideanOpen.code
uses one extra generator and one inverse relation. These sources do not by
themselves instantiate every Weil factor considered here.

#### 2.2 Weil factors

Choose nilpotent algebra generators z_1,...,z_m for W. There is a finite
polynomial presentation

\[
 W=\mathbb R[z_1,\ldots,z_m]/(p_1,\ldots,p_k)
\]

and an integer N for which all monomials of total degree N lie in the relation
ideal. Polynomial ideal finite generation follows here already from the
Noetherian polynomial ring. The corresponding smooth quotient is the same
Weil algebra [Kock, III.5, Proposition 5.11].

For completeness, the parameter-dependent calculation used here is as follows.
Taylor expansion in z, with smooth remainder and coefficients depending
smoothly on v in V, reduces every smooth function on V times R^m modulo the
degree-N monomials to a polynomial in z with coefficients in C-infinity(V).
The additional polynomial relations p_j then give exactly
C-infinity(V) tensor_R W. The remainder vanishes in the quotient, and applying
the same Taylor map to a relation and its smooth multiplier shows that no
additional relation has been introduced. This also constructs its smooth
operations by finite Taylor expansion. Thus

\[
 B(V,W)\cong
 C^\infty(\mathbb R^{n+1+m})/
       (\chi(x)t-1,p_1(z),\ldots,p_k(z)).                     \tag{5}
\]

Equation (5) supplies an actual object of the finite-presentation category.
Choose such a presentation and the displayed isomorphism for each probe.
Conjugating all smooth-algebra maps by these isomorphisms defines a fully
faithful functor into conaled's category of codes. Duplicate presentation codes
cause no problem: fully faithful does not mean injective on objects.

For D_germ, finite presentation also implies germ determination. One can see
this from a finite generating family for the ideal: local expressions in those
generators patch, by a partition of unity, into global expressions with the
same finite family. Hence these probes are objects of D_germ as well.

The two inclusions are full because the source site uses all smooth-algebra
homomorphisms between its coordinate algebras. A source category allowing only
maps that separately preserve the displayed factors would not give this
fullness argument.

### 3. Pulling a principal cover back to a probe

Let d have coordinate algebra A, and let a map i(V,W) to d correspond to
phi:A to B, where B = B(V,W). Suppose the chosen generating D-cover of d is
given algebraically by

\[
 A\longrightarrow A\{s_\alpha^{-1}\},
 \qquad
 \forall p:A\to\mathbb R\quad
 \exists\alpha\quad p(s_\alpha)\ne0.                         \tag{6}
\]

For D_germ, insert germ-determined reflection after the displayed
localizations. We justify below why it disappears after pullback to B.

The pullback coordinate algebra in the finite-presentation case is

\[
 B\otimes_{\infty,A} A\{s_\alpha^{-1}\}
 \cong B\{\phi(s_\alpha)^{-1}\}.                              \tag{7}
\]

This follows from the universal property of making one element invertible;
no classification of smooth maps is required.

Write b = phi(s_alpha) as b_0 + n, where b_0 is its body in C-infinity(V),
embedded back in B, and n lies in C-infinity(V) tensor the maximal ideal of W.
This ideal has a uniform finite nilpotence exponent. In any target smooth
algebra, the images of b and b_0 differ by a nilpotent element. Either is
invertible if and only if the other is: the inverse correction is the finite
geometric series in that nilpotent element. Therefore their smooth
localization functors have identical universal properties. Using (4) and
associativity of smooth coproducts gives

\[
\begin{aligned}
 B\{b^{-1}\}
 &\cong B\{b_0^{-1}\}\\
 &\cong
       \bigl(C^\infty(V)\{b_0^{-1}\}\bigr)\otimes_\infty W\\
 &\cong C^\infty(V_\alpha)\otimes_\infty W,
 \qquad V_\alpha=\{v:b_0(v)\ne0\}.                           \tag{8}
\end{aligned}
\]

This is the essential calculation. The isomorphisms are compatible with the
base map from B, so (8) identifies the pullback arrow with the ordinary open
restriction (V_alpha,W) to (V,W).

All real points of B kill its nilpotent ideal, and the real points of
C-infinity(V) are evaluations at the points of V, also directly from (3).
Composing any such point
with phi and using (6) shows that the opens V_alpha cover V. Thus the pullback
of every generating D-cover along every map from a formal probe is a
C_open-cover.

For D_germ, germ-reflected localization solves the same invertibility
universal problem among germ-determined target algebras. The localization of B
in (8) is finitely presented and hence already germ-determined. It therefore
computes this pullback in D_germ without any extra quotient. One must not
assume that unreflected localization or coproduct stays germ-determined for
an arbitrary starting algebra. Kock III.7, Definitions 7.1--7.2 and Proposition
7.3 specify precisely this reflected open-cover construction.

Conversely, an ordinary open cover V_alpha of V is a D-cover of i(V,W).
Each V_alpha has a smooth defining function on V, and (8) identifies its
restriction with the corresponding principal localization. Coverage of V is
exactly coverage of all real points. The same calculation identifies pairwise
open intersections with their D-pullbacks.

### 4. Lifting every generated covering sieve

It is not enough to check a generating family and then omit the topology
closure argument.

For a sieve S on d in D and a map f:i(c) to d, define the sieve on c

\[
 R_{f,S}=\{u:c'\to c\mid f\circ i(u)\text{ belongs to }S\}.
\]

Let K(d) consist of the sieves S for which R_(f,S) is C-covering for every c
and f. The collection K is a Grothendieck topology on D:

* The maximal sieve satisfies the condition.
* Pullback stability follows from
  R_(g,pullback_f S) = R_(f composed with g,S).
* For transitivity, suppose S is in K(d), and T is a sieve on d such that
  s-star T belongs to K(e) for every s:e to d in S. For a fixed f:i(c) to d,
  R_(f,S) covers c. Each u:c' to c in this sieve gives
  s = f composed with i(u) in S. Applying the hypothesis to s at the identity
  of i(c') shows that R_(s,T) covers c'. This is u-star R_(f,T).
  Transitivity in C proves that R_(f,T) covers c.

Section 3 shows that K contains all the principal generators defining D_fp.
Therefore the generated topology J_D is contained in K. The same proof
applies to the specified D_germ open-cover topology. We have proved:

> Every D-covering sieve, pulled back along any formal probe and then
> restricted to formal probes, is a C-covering sieve.

This is the required cocontinuity/cover-lifting assertion. Full inclusion
alone would not establish it.

### 5. A literal Cartesian or ball basis

If the chosen notion of "Cartesian open" means a body diffeomorphic to some
R^n, replace C_open by the full subcategory C_cart of the allowed bodies.
Assume this basis contains ordinary balls up to diffeomorphism, as the usual
Cartesian basis does, and use its ordinary open-cover topology.

The set V_alpha in (8) need not be an object of C_cart. Cover it instead by
ordinary open balls contained in V_alpha. These ball probes, with the same W,
map into the corresponding localization. Over all alpha they cover the
original Cartesian body. This gives the needed C_cart refinement of (6)
and hence the same covering-sieve argument from Section 4.

There is also an explicit basis comparison. Every object of C_open is covered
by ball probes with the same W; every intersection needed for ordinary
gluing has such a cover. A sheaf on the ball/Cartesian basis extends to an
arbitrary open body by compatible local sections on these probes. Refinement
and the basis sheaf condition make the extension independent of the chosen
cover. Pullback of an open restriction under any formal map is given by (8),
and can again be covered by balls, so the extension is functorial for all
formal maps, including maps mixing body and nilpotent coordinates. This gives

\[
 \operatorname{Sh}(C_{\mathrm{open}})
 \simeq \operatorname{Sh}(C_{\mathrm{cart}}).
\]

Under this equivalence, restriction from D is actual restriction to the
Cartesian probes. Thus the adjunction and obstruction below hold for that
basis as well. No arbitrary fiber products in C_cart are assumed: open
intersections and their ball refinements supply the descent that is used.

#### 6.1 Restriction preserves sheaves

First work with C_open. Its generating open covers become D-covers, and their
open intersections are the same pullbacks by Section 3. A D-sheaf therefore
satisfies the matching-family and unique-gluing condition on each generating
C-cover. Thus rG = i-star G is a C-sheaf. The basis comparison gives the same
conclusion for C_cart.

Limits of sheaves are computed objectwise. Consequently this restriction r
preserves all small limits that exist at the chosen size, in particular
terminal objects and binary products.

#### 6.2 Formula (1) is a D-sheaf

For a C-sheaf F, define UF first as the presheaf right Kan extension (1).
For a map d' to d the restriction map is precomposition by
i-star y_(d') to i-star y_d.

Let S be a D-covering sieve on d. The monomorphism of C-presheaves

\[
 i^*S\longrightarrow i^*y_d
\]

is locally surjective. Indeed, a section of its target over c is precisely a
map f:i(c) to d, and Section 4 says that f locally belongs to S on a C-cover.
Its sheafification is consequently an isomorphism:

\[
 a_C i^*S\ \cong\ a_C i^*y_d.                                \tag{9}
\]

Presheaf right Kan adjunction and sheafification adjunction identify the
D-sheaf test for UF with

\[
\begin{aligned}
 UF(d)
  &= \operatorname{Nat}(i^*y_d,F)\\
  &\longrightarrow \operatorname{Nat}(i^*S,F)
   = \operatorname{Nat}(S,UF).
\end{aligned}
\]

This map is a bijection by (9). Therefore UF is a D-sheaf. The ordinary
presheaf adjunction now restricts to

\[
 \operatorname{Hom}_D(G,UF)
 \cong \operatorname{Hom}_C(rG,F),
\]

so r is left adjoint to U. This proves sheafness rather than including it
as an assumed record field.

#### 6.3 Counit and full faithfulness

For c in C, full faithfulness of i gives i-star y_(i(c)) = y_c up to the
canonical isomorphism. Hence Yoneda gives

\[
 (rUF)(c)=\operatorname{Nat}(y_c,F)\cong F(c).                 \tag{10}
\]

The map takes a natural transformation to its value on id_c. Its inverse
sends x in F(c) to the family u maps to F(u)(x). This identifies (10) with
the counit epsilon_F:rUF to F of r adjoint U, naturally in c and F.
Thus the counit is an isomorphism and U is fully faithful.

For clarity about terminology, the other adjunction map is the unit
eta_G:G to UrG. Formula (1) sends g in G(d) to the natural family
f:i(c) to d maps to G(f)(g). The proof does not assert that this unit is
an isomorphism for every D-sheaf. There is no density or equivalence claim
for C inside D.

The general categorical result is also recorded in Stacks [ST20],
Lemma 7.20.2, and [ST21], Lemma 7.21.7. The work above verifies its
site hypotheses for these specific sites.

### 7. Smooth line, global sections, and transfer of the witness

Both sites have the same terminal probe, the point with W = R. The ordinary
line probe also belongs to C. The open-cover topologies used here are
subcanonical; conaled proves representable sheafness for D_fp in
SmoothOpenSheaf, and Kock III.7, Theorem 7.4 proves it for D_germ.
Full faithfulness therefore identifies restriction of the
represented line with the represented line, as in (2).

Right adjoints preserve limits, so U also preserves terminal objects and
products. But preserving limits does not identify U(R_C) with R_D. The
transfer only uses r(R_D) = R_C and r's product preservation.

Let F be the sheaf in external-models.md#real-flat-de-rham. The external input from that
report is:

\[
 F\longrightarrow F^{R_C}\text{ is an isomorphism},\qquad
 \Gamma_C F\cong 1,\qquad F\not\cong 1.
\]

More precisely, the unique global section 1 to F is not epimorphic. F is the
associated sheaf of degree-one smooth de Rham cohomology, and its value at
the specific point-body Weil probe in that report contains a nonzero class.
The finite coefficient certificate alone does not establish all these
sheaf-theoretic assertions; the cited external argument is part of the input.

Set X = UF. For any D-sheaf A the following identifications are natural:

\[
\begin{aligned}
 \operatorname{Hom}_D(A,X)
 &\cong \operatorname{Hom}_C(rA,F)\\
 &\cong \operatorname{Hom}_C(rA\times R_C,F)\\
 &\cong \operatorname{Hom}_C(r(A\times R_D),F)\\
 &\cong \operatorname{Hom}_D(A\times R_D,X).
\end{aligned}
\]

These bijections identify precomposition with the projection on both sides.
Yoneda therefore proves that the canonical X to X^(R_D) is an isomorphism.
There is no assumption that r preserves arbitrary exponentials.

Moreover

\[
 \Gamma_D X
 =\operatorname{Hom}_D(1,UF)
 \cong\operatorname{Hom}_C(r1,F)
 \cong\Gamma_C F
 \cong1.
\]

Since rX is isomorphic to F, X cannot be terminal. The unique global section
1 to X is a monomorphism in this ordinary sheaf topos; if it were epimorphic
it would be an isomorphism. It is therefore not epimorphic. Equivalently,
r is a left adjoint and preserves epimorphisms between sheaves, so an
epimorphic section would contradict the original section after restriction.

For the stipulated interpretation Flat_D = Delta_D Gamma_D,
Flat_D(X) is the terminal sheaf. Its counit into X is exactly this failed
section. Thus X is R_D-null but not flat for that interpretation. This
is an actual extension of the external finite-Weil obstruction to D_fp
and the specified D_germ.

In D_germ this does not compute the de Rham cohomology sheaf directly on
arbitrary germ algebras, and does not assert that that direct sheaf equals
UF. The right Kan extension is the constructed larger-site witness.

### 8. Size, verification boundary, and failure conditions

Choose small representatives of the finite presentations, finite Weil
algebras, ordinary opens, and finitely generated germ-determined quotients
in a fixed sufficiently large set-theoretic universe. Every value in (1)
is a subset of a product indexed by that small site. A sufficiently large
universe also contains the fixed witness F and its extension UF. This is
ordinary external size bookkeeping, not a construction of an internal
univalent universe or a crisp type-theoretic interpretation.

All constructions in this report concern ordinary sheaves of sets. Their
0-truncated realization inside a chosen higher sheaf model is a separate
semantic instantiation; any use of the source language, its crisp contexts,
its modalities, and its universes must still be justified. This report
does not instantiate that language.

The argument would fail for a different proposed larger topology if a
cover of a Weil probe could not be refined by ordinary open-body covers.
Declaring a new infinitesimal reduction map to cover, for example, requires
checking that condition anew. Full categorical inclusion never supplies it
automatically. A different line, a different meaning of Flat, a different
restriction on the quantified universe, or a site with different
morphisms likewise requires a fresh comparison.

Native status: conaled's listed definitions and existing native statements
were inspected read-only. No conaled edit or build was performed for this
report. No new native finite-Weil inclusion, right Kan extension, sheafness
proof, counit proof, or transfer instance is claimed. A native proof of an
abstract conditional transfer lemma would not change this status.

The next bounded formalization task is to mechanize (8), then the sieve
argument and (9)--(10), using actual site objects and homomorphisms. Supplying
these facts as interface fields would leave the same mathematical work as
assumptions.

### 9. Exact sources and inspected code

Primary mathematical sources:

* [BD86] Marta Bunge and Eduardo J. Dubuc, "Archimedian local C-infinity-rings
  and models of synthetic differential geometry", Cahiers de topologie et
  géométrie différentielle catégoriques 27 (1986), no. 3, pp. 3--22.
  Corollary 1.2(a), printed pp. 8--9, is the ordinary-open graph presentation
  and localization fact.
  <https://www.numdam.org/article/CTGDC_1986__27_3_3_0.pdf>
* [Kock] Anders Kock, Synthetic Differential Geometry, second edition,
  author PDF. III.5 Proposition 5.11 gives finite smooth presentations of
  Weil algebras; III.6 Theorem 6.3 gives germ determination of finitely
  presented smooth algebras; III.7 Definitions 7.1--7.2 and Proposition 7.3
  specify reflected open localizations and their cover stability; Theorem 7.4
  gives subcanonicity.
  <https://users-math.au.dk/kock/sdg99.pdf>
* [ST20] Stacks Project, Section 7.20, especially Lemma 7.20.2, proves
  right-Kan sheafness from cocontinuity and gives formula (1).
  <https://stacks.math.columbia.edu/tag/00XI>
* [ST21] Stacks Project, Lemma 7.21.7, proves that continuous,
  cocontinuous, fully faithful site functors give the isomorphic counit.
  <https://stacks.math.columbia.edu/tag/00XT>

Inspected conaled sources, all at commit
5867d02ecfc290b7a3b7505cc94acbb98f4f49ff:

* SquareKit/SmoothPresentationCategory.lean: Code, Carrier, the category
  instance with all SmoothAlgebra.Hom maps, localization, localizationBase.
* SquareKit/SmoothOpenCover.lean: OpenCover.Covers is pointwise nonvanishing
  coverage over all smooth homomorphisms to R.
* SquareKit/SmoothOpenTopology.lean: coverage, topology,
  isSheaf_iff_principal, covering_pullback.
* SquareKit/SmoothOrdinaryPullbackCover.lean: EuclideanOpen.openDefining,
  openDefining_locus.
* SquareKit/SmoothOpenEmbedding.lean: EuclideanOpen.Domain and code.
* SquareKit/SmoothOpenSheaf.lean: scalar and all-representable sheafness.

Counterexample input: [Real-flat de Rham obstruction](external-models.md#real-flat-de-rham).

This report is included as independently reviewed external mathematical
evidence. It does not claim native acceptance of its site constructions.

