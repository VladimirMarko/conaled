# Constructive transfer design

These proof strategies and logical boundaries consolidate the supplied source
review. They are mathematical plans, not a fresh upstream axiom audit, current
Lean-build report, or a completed Agda model.

## What counts as a logical dependency

A `noncomputable` declaration or a `classical` command alone is not a per-theorem
axiom certificate; imported definitions and instance synthesis matter. Explicit
selection of arbitrary representatives and case splits on arbitrary real predicates
are substantive operations. A merely existing **unique** solution is different: in
a set-valued constructive development, the type consisting of the solution and its
unique-output certificate can be a proposition, permitting truncation elimination.
That argument is not arbitrary choice.

## Dependent sheaf families

Use restriction-compatible families with an actual sheaf certificate for their
total presheaf. Prove substitution by comparing the substituted total with a
constructed sheaf pullback, rather than placing substitution closure in an input
record. Represent dependent functions by natural sections subject to the equation
that their first projection equals the argument. Target separatedness proves the
locality of this equalizer condition; compatible functions over restrictions then
give the dependent-product comparison. Prove beta, eta and substitution equations
for these actual maps.

Lean proof irrelevance and heterogeneous equality are not automatically Cubical
Agda coherence proofs. Establish propositionhood of the relevant law/certificate
types and handle transports. Ordinary set-valued sheaf constructions do not provide
higher universes, Glue, univalence, HITs, or native crisp-source interpretation.

## Smooth algebras and quotient operations

The constructive route uses actual smooth functions on finite powers of the chosen
coefficient line and their free universal property. A Hadamard difference-factorization
argument can establish ideal stability under smooth operations. Define the resulting
finite-arity quotient operations by set-quotient elimination, not a global choice
of representative for every quotient element. Independence of representatives
is a proof obligation. The derivative/integral and joint-smoothness theorems used
by a Hadamard argument remain actual analytic work, not algebraic record fields.

For covers, distinguish negative inequality from positive apartness/invertibility.
An apartness-based cozero basis is a possible explicit constructive convention,
but its localization, pullback, cover and classical-comparison theorems must be
proved. Replacing arbitrary local representatives by all available local witnesses,
or eliminating into a unique-output proposition, can remove particular selectors;
it does not prove gluing by itself. Arbitrary-open defining functions, locally
finite smooth partitions, and support manipulations need their own analytic
existence theorems or explicitly restricted input data.

## Universal infinitesimals and geometry

Once the actual smooth site and scalar sheaf are constructed, a first-order
Kock–Lawvere proof can evaluate a natural operation at the universal dual element
on an extended parameter stage. Extract the two genuine dual-number coefficients;
use naturality to prove reconstruction and both inverse laws for the **original**
affine comparison. This constructs first-order KL, not all Weil axioms, RealFlat,
universe closure or source-language soundness.

A chosen chart family separates explicit atlas data from a selector choosing
preferred charts. Full faithfulness and manifold comparison must follow from
actual coordinate, localization and cover arguments, not be assumed as fields.
Finite action labels and local maps can be explicit even when a more general
existence proof uses classical choices; the word “classical” does not itself
specify the logical assumptions of every theorem.

## Descent without losing isotropy

Build the descended family from compatible local sections over all restrictions,
and derive locality from separatedness. Cocycles supply inverse transition maps;
descent effectiveness should be a conclusion. Quotient objects retain torsors and
equivariant maps, and arrows retain equivariant isomorphisms. A supplied local
trivialization does not globally trivialize every torsor. Do not collapse the
groupoid to a coarse orbit set or replace varying group-sheaf labels by constants.

The current fixed-cover quotient design and its unresolved obligations are in
[Descent](descent.md). Its proof has to retain actual restrictions, refinement
coherence, the multiplication convention and ineffective actions. Avoiding
selectors alone does not resolve the RealFlat or properness obstructions or
produce a model of the unchanged full native foundation.
