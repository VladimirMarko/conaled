{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianOpenContinuity where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ; isPropΠ2)
open import Cubical.Foundations.Equiv using (_≃_; propBiimpl→Equiv)
open import Cubical.Data.Nat.Base using (ℕ; zero; suc)
open import Cubical.Data.Sigma
import Cubical.Data.FinData.Base as F
import Cubical.HITs.PropositionalTruncation as PT
open PT using (isPropPropTrunc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.TopologicalFiniteBranches as T
import Orbifolds.Intensional.CompactSeparation as C

open import Orbifolds.SemanticBridge.DedekindCartesianMetric
open import Orbifolds.SemanticBridge.DedekindCartesianOpenCategory
import Orbifolds.SemanticBridge.DedekindMetricTopology as Real
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as Topology
import Orbifolds.SemanticBridge.DedekindCartesianMetricBalls as Balls

-- Intersections retain the existing open-subspace topology. Its empty
-- intersection is full, whose openness supplies the source neighborhood
-- when the target has zero coordinates.
module FiniteIntersections (X : CartesianOpen) where

  meet : {n : ℕ} → (F.Fin n → T.Subset (OpenCarrier X)) → T.Subset (OpenCarrier X)
  meet {zero} P = T.full
  meet {suc n} P = T.intersection (P F.zero) (meet {n} (λ i → P (F.suc i)))

  meet-open : {n : ℕ} (P : F.Fin n → T.Subset (OpenCarrier X))
    → ((i : F.Fin n) → T.IsOpen (openTopology X) (P i))
    → T.IsOpen (openTopology X) (meet P)
  meet-open {zero} P opens = T.open-full (openTopology X)
  meet-open {suc n} P opens = T.open-intersection (openTopology X)
    (opens F.zero) (meet-open {n} (λ i → P (F.suc i)) (λ i → opens (F.suc i)))

  meet-member : {n : ℕ} (P : F.Fin n → T.Subset (OpenCarrier X)) (x : OpenCarrier X)
    → ((i : F.Fin n) → T.member (P i) x) → T.member (meet P) x
  meet-member {zero} P x inside = O.tt
  meet-member {suc n} P x inside = O._,_ (inside F.zero)
    (meet-member {n} (λ i → P (F.suc i)) x (λ i → inside (F.suc i)))

  meet-elim : {n : ℕ} (P : F.Fin n → T.Subset (OpenCarrier X)) (x : OpenCarrier X)
    → T.member (meet P) x → (i : F.Fin n) → T.member (P i) x
  meet-elim P x inside (F.zero {n}) = O.fst inside
  meet-elim P x inside (F.suc {n} i) =
    meet-elim {n} (λ j → P (F.suc j)) x (O.snd inside) i

module FromOpen (X : CartesianOpen) (n : ℕ) where

  module Target = Topology.OnDimension n
  module TargetBalls = Balls.OnDimension n
  module Meets = FiniteIntersections X

  ContinuousToCartesian : (OpenCarrier X → Cartesian n) → Type₂
  ContinuousToCartesian = C.Continuous (openTopology X) Target.cartesianOpenFragment

  CoordinatewiseContinuous : (OpenCarrier X → Cartesian n) → Type₂
  CoordinatewiseContinuous f = (i : F.Fin n) →
    C.Continuous (openTopology X) Real.realOpenFragment (λ x → f x i)

  continuous-coordinates : (f : OpenCarrier X → Cartesian n)
    → ContinuousToCartesian f → CoordinatewiseContinuous f
  continuous-coordinates f continuous i P openP =
    continuous (C.preimage (λ y → y i) P)
      (Target.coordinate-projection-continuous i P openP)

  -- Source maps are defined only on X. No extension outside that open
  -- set is chosen. A finite intersection supplies one actual source
  -- membership proof, shared by all coordinate estimates at that point.
  coordinates-continuous : (f : OpenCarrier X → Cartesian n)
    → CoordinatewiseContinuous f → ContinuousToCartesian f
  coordinates-continuous f continuous P openP a inside = PT.rec isPropPropTrunc
    (λ { (r , rp , contains) →
      let x = O._,_ a (O.fst inside)
          neighborhoods = λ i → C.preimage (λ z → f z i) (Real.rationalBall (f x i) r)
          open-neighborhoods = λ i →
            continuous i (Real.rationalBall (f x i) r) (Real.rationalBall-open (f x i) r)
          at-center = Meets.meet-member neighborhoods x
            (λ i → Real.rationalBall-center (f x i) r rp)
      in PT.map
        (λ { (d , dp , stays) → d , dp , (λ b near →
          let witness = stays b near
              y = O._,_ b (O.fst witness)
              coordinates = λ i → O.lower (Meets.meet-elim neighborhoods y (O.snd witness) i)
          in O._,_ (O.fst witness)
            (contains (f y) (TargetBalls.coordinates-to-metric-ball (f x) r (f y) rp coordinates))) })
        (Meets.meet-open neighborhoods open-neighborhoods a (O._,_ (O.fst inside) at-center)) })
    (openP (f (O._,_ a (O.fst inside))) (O.snd inside))

  continuity-coordinate-equiv : (f : OpenCarrier X → Cartesian n)
    → ContinuousToCartesian f ≃ CoordinatewiseContinuous f
  continuity-coordinate-equiv f = propBiimpl→Equiv
    (isPropΠ2 (λ P _ → isPropOpenPredicate X (C.preimage f P)))
    (isPropΠ (λ i → isPropΠ2
      (λ P _ → isPropOpenPredicate X (C.preimage (λ x → f x i) P))))
    (continuous-coordinates f) (coordinates-continuous f)
