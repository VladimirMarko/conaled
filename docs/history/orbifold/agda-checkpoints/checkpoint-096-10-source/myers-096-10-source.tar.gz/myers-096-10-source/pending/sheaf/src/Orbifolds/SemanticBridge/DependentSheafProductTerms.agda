{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentSheafProductTerms where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.Intensional.SmallSites as Site
import Orbifolds.Intensional.SmallSheaves as Sh
import Orbifolds.SemanticBridge.DependentPresheafTotal as TotalBase
import Orbifolds.SemanticBridge.DependentPresheafSections as SectionsBase
import Orbifolds.SemanticBridge.DependentSheafFamilies as FamiliesBase
import Orbifolds.SemanticBridge.DependentPresheafProductTerms as TermsBase
import Orbifolds.SemanticBridge.DependentSheafProducts as ProductsBase

-- Terms retain the existing natural-section representation. The product
-- family has its constructed total-sheaf certificate; lambda/application
-- and the ordinary beta/eta equations are the actual presheaf term maps.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ)
    (J : Site.GrothendieckTopology C) where
  Family : Sh.Sheaf J → Type (ℓ-suc ℓ)
  Family = FamiliesBase.On.Family ext C J

  Term : (Γ : Sh.Sheaf J) → Family Γ → Type ℓ
  Term Γ A = SectionsBase.On.Term ext C (Sh.Sheaf.underlying Γ)
    (FamiliesBase.On.Family.presheafFamily
      {ext = ext} {C = C} {J = J} {Γ = Γ} A)

  module Product (Γ : Sh.Sheaf J) (A : Family Γ)
      (B : Family (FamiliesBase.On.total ext C J {Γ = Γ} A)) where
    extension : Sh.Sheaf J
    extension = FamiliesBase.On.total ext C J {Γ = Γ} A

    family : Family Γ
    family = ProductsBase.On.piFamily ext C J Γ A B

    private
      basePresheaf : P.Presheaf C
      basePresheaf = Sh.Sheaf.underlying Γ
      argumentFamily : TotalBase.On.Family C basePresheaf
      argumentFamily = FamiliesBase.On.Family.presheafFamily
        {ext = ext} {C = C} {J = J} {Γ = Γ} A
      resultFamily : TotalBase.On.Family C (Sh.Sheaf.underlying extension)
      resultFamily = FamiliesBase.On.Family.presheafFamily
        {ext = ext} {C = C} {J = J} {Γ = extension} B

    lambda : Term extension B → Term Γ family
    lambda = TermsBase.On.Product.lambda ext C
      basePresheaf argumentFamily resultFamily

    -- Application is at the canonical variable over the actual display Γ.A.
    apply-at-display : Term Γ family → Term extension B
    apply-at-display = TermsBase.On.Product.apply ext C
      basePresheaf argumentFamily resultFamily

    beta : (t : Term extension B) → apply-at-display (lambda t) O.≡ t
    beta = TermsBase.On.Product.beta ext C
      basePresheaf argumentFamily resultFamily

    eta : (t : Term Γ family) → lambda (apply-at-display t) O.≡ t
    eta = TermsBase.On.Product.eta ext C
      basePresheaf argumentFamily resultFamily

    term-equivalence : O.Equiv (Term extension B) (Term Γ family)
    term-equivalence = O.equiv lambda apply-at-display eta beta

-- No general context-substitution equation or strict Beck--Chevalley
-- identification is introduced by these fixed-display operations.
