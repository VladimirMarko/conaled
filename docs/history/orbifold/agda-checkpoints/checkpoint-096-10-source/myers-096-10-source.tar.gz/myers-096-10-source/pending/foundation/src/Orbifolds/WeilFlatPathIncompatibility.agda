{-# OPTIONS --safe --cubical --guardedness --no-import-sorts --cohesion #-}
module Orbifolds.WeilFlatPathIncompatibility where

-- Combine148 with the accepted selected-target obstruction131. Crisp
-- identity induction is constructed from independent Flat/path equivalences;
-- it is not a separate input. All algebra, spectrum, comparison and endpoint
-- terms are the actual existing constructions at the same universe level.

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv using (_≃_; equivFun)
open import Cubical.Data.Sigma
import Cubical.Data.Empty as Empty
import Cubical.HITs.PropositionalTruncation as PT
open import Cubical.Algebra.CommRing.Base
open import Orbifolds.Crisp using (box)
import Orbifolds.CrispIdentityFromFlatPaths as FP
import Orbifolds.CrispFlatPathCoherence as Coherent
import Orbifolds.CrispGeometry as CG
import Orbifolds.SyntheticField as SF
import Orbifolds.TinyTypes as TT
import Orbifolds.TinyFirstOrderDisks as TFD
import Orbifolds.WeilSelectedTinyIncompatibility as Original

module Context {@♭ ℓ : Level} (@♭ R : CommRing ℓ)
    (@♭ kock : SF.RingContext.KockField R)
    (@♭ E : FP.FlatPathEquivalences {ℓ}) where

  module Structure = Coherent.Construction E
  module Base = Original.Context R kock Structure.rules
  module Weil = Base.Weil
  module Coordinate = Base.Coordinate
  module Normal = Base.Normal
  module Connected = Base.Connected
  module Geometry = Base.Geometry
  module Scalar = Base.Scalar
  module Comparison = Base.Comparison
  open Base.Propositions using (RealFlat)
  open SF.RingContext R using (Invertible; StrictOrder)

  module Selected (@♭ K₀ K₁ : Type ℓ)
      (@♭ evaluate₀ : (Connected.T → K₀) → Comparison.D.Original)
      (@♭ evaluate₁ : (Connected.T → K₁) → Comparison.D.Reflected) where

    module Data = Comparison.Selected K₀ K₁ evaluate₀ evaluate₁
    module Proof = Base.Selected K₀ K₁ evaluate₀ evaluate₁

    -- The two independent roots are tested at exactly six source
    -- objects each. No global assignment of roots or source model occurs.
    shape-power-equivalence : RealFlat → Weil.Reflexive Coordinate.algebra
      → Data.Left.ComparisonData → Data.Right.ComparisonData
      → Geometry.shape (Connected.T → Connected.T)
        ≃ (Connected.T → Geometry.shape Connected.T)
    shape-power-equivalence = Proof.shape-power-equivalence

    shape-power-unit : (real-flat : RealFlat)
      (reflexive : Weil.Reflexive Coordinate.algebra)
      (left : Data.Left.ComparisonData) (right : Data.Right.ComparisonData)
      (h : Connected.T → Connected.T)
      → equivFun (shape-power-equivalence real-flat reflexive left right)
          (Geometry.Shape.η h) ≡ (λ t → Geometry.Shape.η (h t))
    shape-power-unit real-flat reflexive left right h = refl

    incompatible : CG.Context.CrispPullbackPreservation R
      → RealFlat → Weil.Reflexive Coordinate.algebra
      → Data.Left.ComparisonData → Data.Right.ComparisonData
      → Invertible Scalar.three → Invertible Scalar.four → Empty.⊥
    incompatible = Proof.incompatible

    -- Order supplies only the units needed by the algebraic invariant.
    ordered-incompatible : StrictOrder
      → CG.Context.CrispPullbackPreservation R
      → RealFlat → Weil.Reflexive Coordinate.algebra
      → Data.Left.ComparisonData → Data.Right.ComparisonData → Empty.⊥
    ordered-incompatible order preserve real-flat reflexive left right =
      incompatible preserve real-flat reflexive left right
        Numerals.three-unit Numerals.four-unit
      where
      module Numerals = Scalar.PositiveNumerals kock order

    -- Full KL is used only at the explicitly constructed rank15 algebra.
    full-kock-lawvere-incompatible : StrictOrder
      → CG.Context.CrispPullbackPreservation R → RealFlat → Weil.KockLawvere
      → Data.Left.ComparisonData → Data.Right.ComparisonData → Empty.⊥
    full-kock-lawvere-incompatible order preserve real-flat KL left right =
      ordered-incompatible order preserve real-flat (KL Normal.weil) left right

  from-chosen : (@♭ witness : TT.External.AdjointData Connected.T)
    → TT.External.Candidate.ExternalAdjunction Connected.T witness
    → StrictOrder → CG.Context.CrispPullbackPreservation R
    → RealFlat → Weil.KockLawvere → Empty.⊥
  from-chosen witness adjunction order preserve real-flat KL =
    Selected.full-kock-lawvere-incompatible
      (TT.External.AdjointData.root witness Comparison.D.Original)
      (TT.External.AdjointData.root witness Comparison.D.Reflected)
      (TT.External.AdjointData.evaluate witness Comparison.D.Original)
      (TT.External.AdjointData.evaluate witness Comparison.D.Reflected)
      order preserve real-flat KL
      (Comparison.Chosen.left-comparisons witness adjunction)
      (Comparison.Chosen.right-comparisons witness adjunction)

  -- Only propositional truncation into the empty proposition is eliminated;
  -- no selected crisp root is extracted from the truncated tiny witness.
  from-tiny : StrictOrder → CG.Context.CrispPullbackPreservation R
    → RealFlat → Weil.KockLawvere → TT.External.Tiny Connected.T → Empty.⊥
  from-tiny order preserve real-flat KL = PT.rec Empty.isProp⊥
    (λ { (box witness , adjunction) →
      from-chosen witness adjunction order preserve real-flat KL })

  from-all-weil : StrictOrder → CG.Context.CrispPullbackPreservation R
    → RealFlat → Weil.KockLawvere
    → TFD.Context.WeilTinyness R Structure.rules → Empty.⊥
  from-all-weil order preserve real-flat KL tiny =
    from-tiny order preserve real-flat KL (tiny Normal.weil)

-- These terms exclude the displayed package in a sound nondegenerate
-- interpretation of this native signature. Constructing such an interpretation,
-- its crisp substitution laws, universe closure and preservation of the actual
-- paths/HITs remains separate. No unrestricted no-model theorem for Myers's
-- intended source calculus or revised orbifold geometries is claimed.
