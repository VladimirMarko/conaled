{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentProductArgumentNaturality where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.Intensional.PresheafRestriction as Restriction
import Orbifolds.SemanticBridge.PresheafElements as ElementsBase
import Orbifolds.SemanticBridge.DependentPresheafTotal as TotalBase
import Orbifolds.SemanticBridge.DependentProductArgumentIsomorphism as Argument

-- Naturality in an arbitrary map of output families of the constructed
-- argument-isomorphism comparison and its inverse. The comparison square
-- follows from the proved component formula; it is not an extra premise.
-- Coherence for changing the argument isomorphism is a separate theorem.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  Family : P.Presheaf C → Type (ℓ-suc ℓ)
  Family = TotalBase.On.Family C

  module Context (Γ : P.Presheaf C) where
    private
      module Base = ElementsBase.On.Context C Γ
      module FP = P.Theory ext Base.category

    module AlongIso (A A′ : Family Γ) (i : Cat.Iso FP.category A A′)
        (B B′ : Family (TotalBase.On.Total.presheaf C Γ A′))
        (α : P.Nat B B′) where
      module From = Argument.On.Context.AlongIso ext C Γ A A′ i B
      module To = Argument.On.Context.AlongIso ext C Γ A A′ i B′
      private
        module OutputRestriction = Restriction.Along ext
          From.SourceExtended.category From.TargetProduct.Extended.category
          From.LiftMap.functor

      sourceMap : P.Nat From.sourceFamily To.sourceFamily
      sourceMap = Cat.Functor.arrow From.TargetProduct.piFunctor
        {X = B} {Y = B′} α

      reindexedOutputMap : P.Nat From.reindexedOutput To.reindexedOutput
      reindexedOutputMap = OutputRestriction.restrict-nat {F = B} {G = B′} α

      targetMap : P.Nat From.targetFamily To.targetFamily
      targetMap = Cat.Functor.arrow From.SourceProduct.piFunctor
        {X = From.reindexedOutput} {Y = To.reindexedOutput} reindexedOutputMap

      comparison-natural-at : (u : Base.Element)
        (s : P.Presheaf.value From.sourceFamily u)
        → To.At.forwardSection u (P.Nat.component sourceMap u s)
          O.≡ P.Nat.component targetMap u (From.At.forwardSection u s)
      comparison-natural-at u s = P.Theory.nat-ext ext From.SourceExtended.category
        {F = From.SourceProduct.kernel u} {G = To.reindexedOutput}
        (λ e k → To.At.forward-component u (P.Nat.component sourceMap u s) e k
          O.∙ O.cong (P.Nat.component α (From.LiftMap.onObject e))
            (O.sym (From.At.forward-component u s e k)))

      comparison-natural : FP.compose-nat
          {F = From.sourceFamily} {G = To.sourceFamily} {H = To.targetFamily}
          To.comparison sourceMap
        O.≡ FP.compose-nat
          {F = From.sourceFamily} {G = From.targetFamily} {H = To.targetFamily}
          targetMap From.comparison
      comparison-natural = FP.nat-ext
        {F = From.sourceFamily} {G = To.targetFamily} comparison-natural-at

      inverse-natural-at : (u : Base.Element)
        (t : P.Presheaf.value From.targetFamily u)
        → To.At.inverseSection u (P.Nat.component targetMap u t)
          O.≡ P.Nat.component sourceMap u (From.At.inverseSection u t)
      inverse-natural-at u t = To.At.forward-injective u
        (To.At.forward-inverse u (P.Nat.component targetMap u t)
          O.∙ O.cong (P.Nat.component targetMap u)
            (O.sym (From.At.forward-inverse u t))
          O.∙ O.sym (comparison-natural-at u (From.At.inverseSection u t)))

      inverse-natural : FP.compose-nat
          {F = From.targetFamily} {G = To.targetFamily} {H = To.sourceFamily}
          To.inverse targetMap
        O.≡ FP.compose-nat
          {F = From.targetFamily} {G = From.sourceFamily} {H = To.sourceFamily}
          sourceMap From.inverse
      inverse-natural = FP.nat-ext
        {F = From.targetFamily} {G = To.sourceFamily} inverse-natural-at
