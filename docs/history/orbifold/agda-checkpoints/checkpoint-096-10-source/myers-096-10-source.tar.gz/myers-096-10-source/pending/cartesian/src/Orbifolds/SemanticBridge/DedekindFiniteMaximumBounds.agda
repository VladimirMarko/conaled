{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindFiniteMaximumBounds where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ; isProp×)
open import Cubical.Foundations.Equiv using (_≃_; propBiimpl→Equiv)
open import Cubical.Data.Nat.Base using (ℕ; zero; suc)
open import Cubical.Data.Sigma
open import Cubical.Data.Rationals.Base
import Cubical.Data.FinData.Base as F
import Cubical.Data.Rationals.Order as QO
open import Cubical.Relation.Nullary using (yes; no)
import Cubical.HITs.PropositionalTruncation as PT

open import Orbifolds.SemanticBridge.DedekindCuts
open import Orbifolds.SemanticBridge.DedekindOrder
open import Orbifolds.SemanticBridge.DedekindMaximum
open import Orbifolds.SemanticBridge.DedekindFiniteMaximum

-- Two merely supplied rational upper witnesses can be compared inside
-- propositional elimination. This uses decidable rational order only;
-- it does not compare arbitrary real numbers or select a real witness.
private
  maximum-from-upper-witnesses : (x y : DedekindReal) (r p q : ℚ)
    → Upper x p → p QO.< r → Upper y q → q QO.< r
    → maximum x y <ℝ rationalCut r
  maximum-from-upper-witnesses x y r p q up pr uq qr with QO.<Dec p q
  ... | yes pq = ≤ℝ-<ℝ-trans (maximum x y) (rationalCut q) (rationalCut r)
    (maximum-least x y (rationalCut q)
      (≤ℝ-trans x (rationalCut p) (rationalCut q)
        (upper→rational-bound x p up)
        (rational-≤ℝ-preserves p q (QO.<Weaken≤ p q pq)))
      (upper→rational-bound y q uq))
    (rational-<ℝ-preserves q r qr)
  ... | no npq = ≤ℝ-<ℝ-trans (maximum x y) (rationalCut p) (rationalCut r)
    (maximum-least x y (rationalCut p)
      (upper→rational-bound x p up)
      (≤ℝ-trans y (rationalCut q) (rationalCut p)
        (upper→rational-bound y q uq)
        (rational-≤ℝ-preserves q p (QO.≮→≥ p q npq))))
    (rational-<ℝ-preserves p r pr)

maximum-strict-rational-bound : (x y : DedekindReal) (r : ℚ)
  → x <ℝ rationalCut r → y <ℝ rationalCut r
  → maximum x y <ℝ rationalCut r
maximum-strict-rational-bound x y r =
  PT.rec2 (isProp<ℝ (maximum x y) (rationalCut r))
    (λ { (p , up , pr) (q , uq , qr) →
      maximum-from-upper-witnesses x y r p q up pr uq qr })

-- The zero seed is a genuine part of finiteMaximum. Its strict bound is
-- required even for the empty vector; no positive-dimensional shortcut
-- is used in either direction of the characterization.
finiteMaximum-strict-rational-bound : {n : ℕ}
  → (v : F.FinVec DedekindReal n) (r : ℚ)
  → 0 QO.< r → ((i : F.Fin n) → v i <ℝ rationalCut r)
  → finiteMaximum v <ℝ rationalCut r
finiteMaximum-strict-rational-bound {zero} v r positive bounds =
  rational-<ℝ-preserves 0 r positive
finiteMaximum-strict-rational-bound {suc n} v r positive bounds =
  maximum-strict-rational-bound (v F.zero)
    (finiteMaximum (λ i → v (F.suc i))) r (bounds F.zero)
    (finiteMaximum-strict-rational-bound {n = n}
      (λ i → v (F.suc i)) r positive (λ i → bounds (F.suc i)))

finiteMaximum-strict-coordinate : {n : ℕ}
  → (v : F.FinVec DedekindReal n) (r : ℚ)
  → finiteMaximum v <ℝ rationalCut r
  → (i : F.Fin n) → v i <ℝ rationalCut r
finiteMaximum-strict-coordinate v r bound i =
  ≤ℝ-<ℝ-trans (v i) (finiteMaximum v) (rationalCut r)
    (finiteMaximum-above v i) bound

finiteMaximum-strict-positive : {n : ℕ}
  → (v : F.FinVec DedekindReal n) (r : ℚ)
  → finiteMaximum v <ℝ rationalCut r → 0 QO.< r
finiteMaximum-strict-positive v r bound = rational-<ℝ-reflects 0 r
  (≤ℝ-<ℝ-trans zeroReal (finiteMaximum v) (rationalCut r)
    (finiteMaximum-nonnegative v) bound)

finiteMaximum-strict-rational-equiv : {n : ℕ}
  → (v : F.FinVec DedekindReal n) (r : ℚ)
  → (finiteMaximum v <ℝ rationalCut r)
    ≃ ((0 QO.< r) × ((i : F.Fin n) → v i <ℝ rationalCut r))
finiteMaximum-strict-rational-equiv v r = propBiimpl→Equiv
  (isProp<ℝ (finiteMaximum v) (rationalCut r))
  (isProp× (QO.isProp< 0 r) (isPropΠ (λ i → isProp<ℝ (v i) (rationalCut r))))
  (λ bound → finiteMaximum-strict-positive v r bound ,
    finiteMaximum-strict-coordinate v r bound)
  (λ bounds → finiteMaximum-strict-rational-bound v r (fst bounds) (snd bounds))
