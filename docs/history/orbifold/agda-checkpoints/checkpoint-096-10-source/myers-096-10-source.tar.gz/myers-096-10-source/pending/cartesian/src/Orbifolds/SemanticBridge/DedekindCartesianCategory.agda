{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianCategory where

open import Agda.Primitive using (lzero; lsuc)
open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ2; isSetΠ; isSetΣSndProp)
open import Cubical.Data.Nat.Base using (ℕ; zero)
open import Cubical.Data.Sigma
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.CompactSeparation as C

open import Orbifolds.SemanticBridge.IdentityPath using (pathToId; pathIsSetToId)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as Topology
import Orbifolds.SemanticBridge.DedekindCartesianContinuity as Continuity

CartesianContinuous : {m n : ℕ} → (Cartesian m → Cartesian n) → Type₂
CartesianContinuous {m} {n} = C.Continuous
  (Topology.OnDimension.cartesianOpenFragment m)
  (Topology.OnDimension.cartesianOpenFragment n)

isPropCartesianContinuous : {m n : ℕ} (f : Cartesian m → Cartesian n)
  → isProp (CartesianContinuous f)
isPropCartesianContinuous {m} f = isPropΠ2
  (λ P _ → Topology.OnDimension.isPropMetricOpen m (C.preimage f P))

-- Arrows contain the actual map and its open-preimage continuity proof.
-- The certificate is a proposition; hom equality is therefore determined
-- by the underlying map. Hom types stay in Type2, without resizing them.
CartesianMap : ℕ → ℕ → Type₂
CartesianMap m n = Σ (Cartesian m → Cartesian n) CartesianContinuous

cartesian-map : {m n : ℕ} → CartesianMap m n → Cartesian m → Cartesian n
cartesian-map = fst

cartesian-map-continuous : {m n : ℕ} (f : CartesianMap m n)
  → CartesianContinuous (cartesian-map f)
cartesian-map-continuous = snd

cartesianMap-ext : {m n : ℕ} {f g : CartesianMap m n}
  → ((x : Cartesian m) → cartesian-map f x ≡ cartesian-map g x) → f ≡ g
cartesianMap-ext equal = Σ≡Prop isPropCartesianContinuous (funExt equal)

isSetCartesianMap : (m n : ℕ) → isSet (CartesianMap m n)
isSetCartesianMap m n = isSetΣSndProp
  (isSetΠ (λ _ → isSetCartesian n)) isPropCartesianContinuous

cartesianIdentity : (n : ℕ) → CartesianMap n n
cartesianIdentity n = (λ x → x) , (λ P openP → openP)

cartesianCompose : {k m n : ℕ}
  → CartesianMap m n → CartesianMap k m → CartesianMap k n
cartesianCompose g f = (λ x → cartesian-map g (cartesian-map f x)) ,
  (λ P openP → cartesian-map-continuous f (C.preimage (cartesian-map g) P)
    (cartesian-map-continuous g P openP))

cartesian-identity-left : {m n : ℕ} (f : CartesianMap m n)
  → cartesianCompose (cartesianIdentity n) f ≡ f
cartesian-identity-left f = cartesianMap-ext (λ _ → refl)

cartesian-identity-right : {m n : ℕ} (f : CartesianMap m n)
  → cartesianCompose f (cartesianIdentity m) ≡ f
cartesian-identity-right f = cartesianMap-ext (λ _ → refl)

cartesian-associative : {j k m n : ℕ}
  → (h : CartesianMap m n) (g : CartesianMap k m) (f : CartesianMap j k)
  → cartesianCompose (cartesianCompose h g) f
    ≡ cartesianCompose h (cartesianCompose g f)
cartesian-associative h g f = cartesianMap-ext (λ _ → refl)

cartesianCategory : Cat.Category lzero (lsuc (lsuc lzero))
Cat.Category.Obj cartesianCategory = ℕ
Cat.Category.Hom cartesianCategory = CartesianMap
Cat.Category.hom-set cartesianCategory m n = pathIsSetToId (isSetCartesianMap m n)
Cat.Category.identity cartesianCategory {n} = cartesianIdentity n
Cat.Category.compose cartesianCategory = cartesianCompose
Cat.Category.identity-left cartesianCategory f = pathToId (cartesian-identity-left f)
Cat.Category.identity-right cartesianCategory f = pathToId (cartesian-identity-right f)
Cat.Category.associative cartesianCategory h g f = pathToId (cartesian-associative h g f)

cartesianToZero : (m : ℕ) → CartesianMap m zero
cartesianToZero m = (λ _ → emptyCartesian) ,
  Continuity.FromDimension.empty-target-continuous m (λ _ → emptyCartesian)

-- Zero dimensions is an actual terminal object: every outgoing hom to it
-- contracts to the displayed empty-coordinate map, with its continuity
-- proof. This states uniqueness of certified arrows as well as functions.
cartesian-zero-terminal : (m : ℕ) → isContr (CartesianMap m zero)
cartesian-zero-terminal m = cartesianToZero m ,
  (λ f → cartesianMap-ext (λ x → dimension-zero-unique
    (cartesian-map (cartesianToZero m) x) (cartesian-map f x)))

ordinary-cartesian-zero-unique : (m : ℕ) (f : CartesianMap m zero)
  → cartesianToZero m O.≡ f
ordinary-cartesian-zero-unique m f = pathToId (snd (cartesian-zero-terminal m) f)
