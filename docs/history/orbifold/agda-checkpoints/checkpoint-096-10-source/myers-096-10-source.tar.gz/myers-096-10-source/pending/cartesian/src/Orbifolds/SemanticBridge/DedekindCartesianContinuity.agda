{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianContinuity where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ2; isPropΠ)
open import Cubical.Foundations.Equiv using (_≃_; propBiimpl→Equiv)
open import Cubical.Data.Nat.Base using (ℕ; zero; suc)
open import Cubical.Data.Sigma
open import Cubical.Data.Rationals.Base
import Cubical.Data.FinData.Base as F
import Cubical.Data.Rationals.Order as QO
import Cubical.HITs.PropositionalTruncation as PT
open PT using (∥_∥₁; ∣_∣₁; isPropPropTrunc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.TopologicalFiniteBranches as T
import Orbifolds.Intensional.CompactSeparation as C

open import Orbifolds.SemanticBridge.RationalDensity using (zero<one)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
import Orbifolds.SemanticBridge.RationalBallOpenness as Radii
import Orbifolds.SemanticBridge.DedekindMetricTopology as Real
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as CartesianTopology
import Orbifolds.SemanticBridge.DedekindCartesianMetricBalls as CartesianBalls

module FromDimension (m : ℕ) where

  module Domain = CartesianTopology.OnDimension m

  -- Finitely many merely existing neighborhoods give a merely existing
  -- common neighborhood. Elimination stays inside truncation, including
  -- the successor step. The empty family uses the explicit positive
  -- radius 1 and imposes no coordinate condition.
  CommonRadius : {n : ℕ} → (F.Fin n → Cartesian m → Type₀)
    → Cartesian m → Type₁
  CommonRadius {n} P x = Σ[ r ∈ ℚ ] ((0 QO.< r) ×
    ((y : Cartesian m) → Domain.RationalBall x r y → (i : F.Fin n) → P i y))

  individual-radii-to-common : {n : ℕ}
    → (P : F.Fin n → Cartesian m → Type₀) (x : Cartesian m)
    → ((i : F.Fin n) → ∥ Σ[ r ∈ ℚ ] ((0 QO.< r) ×
        ((y : Cartesian m) → Domain.RationalBall x r y → P i y)) ∥₁)
    → ∥ CommonRadius P x ∥₁
  individual-radii-to-common {zero} P x local =
    ∣ 1 , zero<one , (λ y near ()) ∣₁
  individual-radii-to-common {suc n} P x local = PT.rec2 isPropPropTrunc
    (λ { (p , pp , head) (q , qp , tail) →
      let common = Radii.commonPositiveRadius p q pp qp
          r = fst common
          rp = fst (snd common)
          r≤p = fst (snd (snd common))
          r≤q = snd (snd (snd common))
      in ∣ r , rp , (λ y near → λ
        { F.zero → head y (Domain.rationalBall-enlarge x y r p r≤p near)
        ; (F.suc i) → tail y (Domain.rationalBall-enlarge x y r q r≤q near) i }) ∣₁ })
    (local F.zero)
    (individual-radii-to-common {n = n} (λ i → P (F.suc i)) x
      (λ i → local (F.suc i)))

  module ToDimension (n : ℕ) where

    module Target = CartesianTopology.OnDimension n
    module Balls = CartesianBalls.OnDimension n

    CoordinatewiseContinuous : (Cartesian m → Cartesian n) → Type₂
    CoordinatewiseContinuous f = (i : F.Fin n) →
      C.Continuous Domain.cartesianOpenFragment Real.realOpenFragment (λ x → f x i)

    continuous-coordinates : (f : Cartesian m → Cartesian n)
      → C.Continuous Domain.cartesianOpenFragment Target.cartesianOpenFragment f
      → CoordinatewiseContinuous f
    continuous-coordinates f continuous i P openP =
      continuous (C.preimage (λ y → y i) P)
        (Target.coordinate-projection-continuous i P openP)

    coordinate-ball-neighborhood : (f : Cartesian m → Cartesian n)
      → CoordinatewiseContinuous f → (x : Cartesian m) (r : ℚ)
      → 0 QO.< r
      → ∥ CommonRadius (λ i y → Real.RationalBall (f x i) r (f y i)) x ∥₁
    coordinate-ball-neighborhood f continuous x r positive =
      individual-radii-to-common (λ i y → Real.RationalBall (f x i) r (f y i)) x
        (λ i → PT.map
          (λ { (d , dp , contains) → d , dp ,
            (λ y near → O.lower (contains y near)) })
          (continuous i (Real.rationalBall (f x i) r)
            (Real.rationalBall-open (f x i) r) x
            (Real.rationalBall-center (f x i) r positive)))

    coordinates-continuous : (f : Cartesian m → Cartesian n)
      → CoordinatewiseContinuous f
      → C.Continuous Domain.cartesianOpenFragment Target.cartesianOpenFragment f
    coordinates-continuous f continuous P openP x inside = PT.rec isPropPropTrunc
      (λ { (r , rp , contains) → PT.map
        (λ { (d , dp , coordinates) → d , dp , (λ y near → contains (f y)
          (Balls.coordinates-to-metric-ball (f x) r (f y) rp (coordinates y near))) })
        (coordinate-ball-neighborhood f continuous x r rp) })
      (openP (f x) inside)

    continuity-coordinate-equiv : (f : Cartesian m → Cartesian n)
      → C.Continuous Domain.cartesianOpenFragment Target.cartesianOpenFragment f
        ≃ CoordinatewiseContinuous f
    continuity-coordinate-equiv f = propBiimpl→Equiv
      (isPropΠ2 (λ P _ → Domain.isPropMetricOpen (C.preimage f P)))
      (isPropΠ (λ i → isPropΠ2
        (λ P _ → Domain.isPropMetricOpen (C.preimage (λ x → f x i) P))))
      (continuous-coordinates f) (coordinates-continuous f)

  -- The reverse direction above is total at n = 0. This explicit export
  -- records that every map to the actual empty Cartesian product is
  -- continuous without introducing any coordinate or choice premise.
  empty-target-continuous : (f : Cartesian m → Cartesian zero)
    → C.Continuous Domain.cartesianOpenFragment
      (CartesianTopology.OnDimension.cartesianOpenFragment zero) f
  empty-target-continuous f = ToDimension.coordinates-continuous zero f (λ ())
