{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianMetricBalls where

open import Agda.Primitive using (lzero; lsuc)
open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ)
open import Cubical.Foundations.Equiv using (_≃_; propBiimpl→Equiv)
open import Cubical.Data.Nat.Base using (ℕ)
open import Cubical.Data.Sigma
open import Cubical.Data.Rationals.Base
import Cubical.Data.FinData.Base as F
import Cubical.Data.Rationals.Order as QO
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.TopologicalFiniteBranches as T

open import Orbifolds.SemanticBridge.IdentityPath using (pathToId)
open import Orbifolds.SemanticBridge.DedekindCuts
open import Orbifolds.SemanticBridge.DedekindMetric
open import Orbifolds.SemanticBridge.DedekindFiniteMaximumBounds
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
import Orbifolds.SemanticBridge.DedekindMetricTopology as Real
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as CartesianTopology

module OnDimension (n : ℕ) where

  module Metric = CartesianTopology.OnDimension n

  CoordinateBall : Cartesian n → ℚ → Cartesian n → Type₀
  CoordinateBall c r x = (i : F.Fin n) → Real.RationalBall (c i) r (x i)

  isPropCoordinateBall : (c : Cartesian n) (r : ℚ) (x : Cartesian n)
    → isProp (CoordinateBall c r x)
  isPropCoordinateBall c r x =
    isPropΠ (λ i → isProp<ℝ (distanceReal (c i) (x i)) (rationalCut r))

  metric-ball-to-coordinates : (c : Cartesian n) (r : ℚ) (x : Cartesian n)
    → Metric.RationalBall c r x → CoordinateBall c r x
  metric-ball-to-coordinates c r x =
    finiteMaximum-strict-coordinate (λ i → distanceReal (c i) (x i)) r

  coordinates-to-metric-ball : (c : Cartesian n) (r : ℚ) (x : Cartesian n)
    → 0 QO.< r → CoordinateBall c r x → Metric.RationalBall c r x
  coordinates-to-metric-ball c r x =
    finiteMaximum-strict-rational-bound (λ i → distanceReal (c i) (x i)) r

  metric-coordinate-ball-equiv : (c : Cartesian n) (r : ℚ) (x : Cartesian n)
    → 0 QO.< r → Metric.RationalBall c r x ≃ CoordinateBall c r x
  metric-coordinate-ball-equiv c r x positive = propBiimpl→Equiv
    (isProp<ℝ (distanceCartesian c x) (rationalCut r))
    (isPropCoordinateBall c r x)
    (metric-ball-to-coordinates c r x)
    (coordinates-to-metric-ball c r x positive)

  -- Pointwise finite intersection of the coordinate balls, lifted into
  -- the ordinary Subset interface's actual universe. Both inclusions
  -- compare certified subsets without assuming their record equality.
  coordinateBallSubset : Cartesian n → ℚ → T.Subset (Cartesian n)
  T.member (coordinateBallSubset c r) x = O.Lift (lsuc lzero) (CoordinateBall c r x)
  T.member-prop (coordinateBallSubset c r) x a b = O.cong O.lift
    (pathToId (isPropCoordinateBall c r x (O.lower a) (O.lower b)))

  metric-ball-in-coordinate-ball : (c : Cartesian n) (r : ℚ)
    → T.Included (Metric.rationalBall c r) (coordinateBallSubset c r)
  metric-ball-in-coordinate-ball c r x inside =
    O.lift (metric-ball-to-coordinates c r x (O.lower inside))

  coordinate-ball-in-metric-ball : (c : Cartesian n) (r : ℚ)
    → 0 QO.< r
    → T.Included (coordinateBallSubset c r) (Metric.rationalBall c r)
  coordinate-ball-in-metric-ball c r positive x inside =
    O.lift (coordinates-to-metric-ball c r x positive (O.lower inside))

  positive-coordinate-ball-open : (c : Cartesian n) (r : ℚ)
    → 0 QO.< r → Metric.MetricOpen (coordinateBallSubset c r)
  positive-coordinate-ball-open c r positive = T.open-transfer
    Metric.cartesianOpenFragment
    (metric-ball-in-coordinate-ball c r)
    (coordinate-ball-in-metric-ball c r positive)
    (Metric.rationalBall-open c r)
