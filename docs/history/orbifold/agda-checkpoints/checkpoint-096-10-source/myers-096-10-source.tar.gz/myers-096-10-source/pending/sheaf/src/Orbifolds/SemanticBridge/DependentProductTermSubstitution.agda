{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentProductTermSubstitution where

open import Cubical.Foundations.Prelude using (Level)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.SemanticBridge.DependentPresheafSections as Terms
import Orbifolds.SemanticBridge.DependentPresheafProductTerms as ProductTerms
import Orbifolds.SemanticBridge.DependentPresheafReindex as Reindex
import Orbifolds.SemanticBridge.DependentProductBaseChange as BaseChange
import Orbifolds.SemanticBridge.DependentTermTransport as Transport

-- Substitution commutes with lambda and canonical-display application,
-- after the constructed base-change map identifies the actual Pi families.
-- The proofs use its forward component equation and actual term values.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  module T = Terms.On ext C
  module R = Reindex.On ext C
  module V = Transport.On ext C

  module Along (Γ Δ : P.Presheaf C) (A : T.Family Γ)
      (B : T.Family (T.extension Γ A)) (σ : P.Nat Δ Γ) where
    module BC = BaseChange.On.Along ext C Γ Δ A B σ
    module Original = ProductTerms.On.Product ext C Γ A
    module Reindexed = ProductTerms.On.Product ext C Δ
      (R.reindex {Γ = Γ} {Δ = Δ} A σ)
    module PiSub = V.AlongContext Γ Δ (Original.piFamily B) σ
    module OutputSub = V.AlongContext Original.extension Reindexed.extension
      B BC.Change.lift
    module Comparison = V.AlongFamily Δ BC.sourceFamily BC.targetFamily BC.comparison

    substituteOutput : T.Term Original.extension B
      → T.Term Reindexed.extension BC.reindexedOutput
    substituteOutput = T.substitute Original.extension Reindexed.extension B BC.Change.lift

    substituteProduct : T.Term Γ (Original.piFamily B) → T.Term Δ BC.targetFamily
    substituteProduct p = Comparison.map (T.substitute Γ Δ (Original.piFamily B) σ p)

    lambda-natural : (t : T.Term Original.extension B)
      → substituteProduct (Original.lambda B t)
        O.≡ Reindexed.lambda BC.reindexedOutput (substituteOutput t)
    lambda-natural t = V.value-ext Δ BC.targetFamily _ _
      (λ X x → P.Theory.nat-ext ext BC.ReindexedExtended.category
        {F = BC.ReindexedProduct.kernel (O._,_ X x)} {G = BC.reindexedOutput}
        (λ e k →
          O.cong (λ s → P.Nat.component s e k)
            (Comparison.map-value
              (T.substitute Γ Δ (Original.piFamily B) σ (Original.lambda B t)) X x)
          O.∙ BC.At.forward-component (O._,_ X x)
            (T.term-value Δ BC.sourceFamily
              (T.substitute Γ Δ (Original.piFamily B) σ (Original.lambda B t)) X x) e k
          O.∙ O.cong
            (λ s → P.Nat.component s (BC.LiftMap.onObject e) (BC.BaseMap.onArrow k))
            (PiSub.substitute-value (Original.lambda B t) X x)
          O.∙ Original.lambda-value B t X (P.Nat.component σ X x)
            (BC.LiftMap.onObject e) (BC.BaseMap.onArrow k)
          O.∙ O.sym (OutputSub.substitute-value t (O.fst e) (O.snd e))
          O.∙ O.sym (Reindexed.lambda-value BC.reindexedOutput
            (substituteOutput t) X x e k)))

    -- Beta and eta let the lambda equation determine the application
    -- equation without treating either inverse law as judgmental reduction.
    apply-natural : (p : T.Term Γ (Original.piFamily B))
      → Reindexed.apply BC.reindexedOutput (substituteProduct p)
        O.≡ substituteOutput (Original.apply B p)
    apply-natural p = O.cong (Reindexed.apply BC.reindexedOutput)
      (O.sym (O.cong substituteProduct (Original.eta B p))
        O.∙ lambda-natural (Original.apply B p))
      O.∙ Reindexed.beta BC.reindexedOutput (substituteOutput (Original.apply B p))

-- This concerns the actual presheaf-family Pi and the existing term
-- substitution. It is not an interpretation of the original modal syntax,
-- a sheaf-universe construction, or strict equality of Pi presentations.
