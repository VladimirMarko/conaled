{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianProducts where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv using (_≃_)
open import Cubical.Foundations.Isomorphism using (iso; isoToEquiv)
open import Cubical.Data.Nat.Base using (ℕ; _+_)
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.FinData.Base as F
import Cubical.Data.FinData.Properties as FP
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.CompactSeparation as C

open import Orbifolds.SemanticBridge.IdentityPath using (pathToId)
open import Orbifolds.SemanticBridge.DedekindCuts using (DedekindReal)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
open import Orbifolds.SemanticBridge.DedekindCartesianCategory
import Orbifolds.SemanticBridge.DedekindMetricTopology as Real
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as Topology
import Orbifolds.SemanticBridge.DedekindCartesianContinuity as Continuity

-- Split finite indices with the library's actual constructive equivalence.
-- The product carrier is exactly Cartesian (m+n); it is not supplied as
-- an unrelated object with an assumed product comparison.
module CoordinateProduct (m n : ℕ) where

  choose : Cartesian m → Cartesian n → F.Fin m ⊎ F.Fin n → DedekindReal
  choose x y (inl i) = x i
  choose x y (inr i) = y i

  join : Cartesian m → Cartesian n → Cartesian (m + n)
  join x y i = choose x y (FP.FinSumChar.inv m n i)

  left : Cartesian (m + n) → Cartesian m
  left z i = z (FP.FinSumChar.fun m n (inl i))

  right : Cartesian (m + n) → Cartesian n
  right z i = z (FP.FinSumChar.fun m n (inr i))

  left-join : (x : Cartesian m) (y : Cartesian n) → left (join x y) ≡ x
  left-join x y = funExt
    (λ i → cong (choose x y) (FP.FinSumChar.ret m n (inl i)))

  right-join : (x : Cartesian m) (y : Cartesian n) → right (join x y) ≡ y
  right-join x y = funExt
    (λ i → cong (choose x y) (FP.FinSumChar.ret m n (inr i)))

  private
    choose-split : (z : Cartesian (m + n)) (s : F.Fin m ⊎ F.Fin n)
      → choose (left z) (right z) s ≡ z (FP.FinSumChar.fun m n s)
    choose-split z (inl i) = refl
    choose-split z (inr i) = refl

  join-split : (z : Cartesian (m + n)) → join (left z) (right z) ≡ z
  join-split z = funExt (λ i →
    choose-split z (FP.FinSumChar.inv m n i) ∙ cong z (FP.FinSumChar.sec m n i))

  left-continuous : CartesianContinuous left
  left-continuous = Continuity.FromDimension.ToDimension.coordinates-continuous
    (m + n) m left (λ i → Topology.OnDimension.coordinate-projection-continuous
      (m + n) (FP.FinSumChar.fun m n (inl i)))

  right-continuous : CartesianContinuous right
  right-continuous = Continuity.FromDimension.ToDimension.coordinates-continuous
    (m + n) n right (λ i → Topology.OnDimension.coordinate-projection-continuous
      (m + n) (FP.FinSumChar.fun m n (inr i)))

  private
    choose-continuous : {k : ℕ} (f : CartesianMap k m) (g : CartesianMap k n)
      → (s : F.Fin m ⊎ F.Fin n)
      → C.Continuous (Topology.OnDimension.cartesianOpenFragment k)
          Real.realOpenFragment
          (λ x → choose (cartesian-map f x) (cartesian-map g x) s)
    choose-continuous {k} f g (inl i) =
      Continuity.FromDimension.ToDimension.continuous-coordinates k m
        (cartesian-map f) (cartesian-map-continuous f) i
    choose-continuous {k} f g (inr i) =
      Continuity.FromDimension.ToDimension.continuous-coordinates k n
        (cartesian-map g) (cartesian-map-continuous g) i

  join-continuous : {k : ℕ} (f : CartesianMap k m) (g : CartesianMap k n)
    → CartesianContinuous (λ x → join (cartesian-map f x) (cartesian-map g x))
  join-continuous {k} f g =
    Continuity.FromDimension.ToDimension.coordinates-continuous k (m + n)
      (λ x → join (cartesian-map f x) (cartesian-map g x))
      (λ i → choose-continuous f g (FP.FinSumChar.inv m n i))

cartesianFirst : (m n : ℕ) → CartesianMap (m + n) m
cartesianFirst m n = CoordinateProduct.left m n , CoordinateProduct.left-continuous m n

cartesianSecond : (m n : ℕ) → CartesianMap (m + n) n
cartesianSecond m n = CoordinateProduct.right m n , CoordinateProduct.right-continuous m n

cartesianPair : {k m n : ℕ}
  → CartesianMap k m → CartesianMap k n → CartesianMap k (m + n)
cartesianPair {m = m} {n = n} f g =
  (λ x → CoordinateProduct.join m n (cartesian-map f x) (cartesian-map g x)) ,
  CoordinateProduct.join-continuous m n f g

cartesian-first-pair : {k m n : ℕ} (f : CartesianMap k m) (g : CartesianMap k n)
  → cartesianCompose (cartesianFirst m n) (cartesianPair f g) ≡ f
cartesian-first-pair {m = m} {n = n} f g = cartesianMap-ext
  (λ x → CoordinateProduct.left-join m n (cartesian-map f x) (cartesian-map g x))

cartesian-second-pair : {k m n : ℕ} (f : CartesianMap k m) (g : CartesianMap k n)
  → cartesianCompose (cartesianSecond m n) (cartesianPair f g) ≡ g
cartesian-second-pair {m = m} {n = n} f g = cartesianMap-ext
  (λ x → CoordinateProduct.right-join m n (cartesian-map f x) (cartesian-map g x))

cartesian-pair-projections : {k m n : ℕ} (h : CartesianMap k (m + n))
  → cartesianPair (cartesianCompose (cartesianFirst m n) h)
      (cartesianCompose (cartesianSecond m n) h) ≡ h
cartesian-pair-projections {m = m} {n = n} h = cartesianMap-ext
  (λ x → CoordinateProduct.join-split m n (cartesian-map h x))

cartesianProducts : Cat.Products cartesianCategory
Cat.Products.product cartesianProducts = _+_
Cat.Products.first cartesianProducts {m} {n} = cartesianFirst m n
Cat.Products.second cartesianProducts {m} {n} = cartesianSecond m n
Cat.Products.pair cartesianProducts = cartesianPair
Cat.Products.first-pair cartesianProducts f g = pathToId (cartesian-first-pair f g)
Cat.Products.second-pair cartesianProducts f g = pathToId (cartesian-second-pair f g)
Cat.Products.pair-projections cartesianProducts {k} {m} {n} h =
  pathToId (cartesian-pair-projections {k = k} {m = m} {n = n} h)

-- This universal property includes both inverse laws on certified maps.
-- It covers zero-dimensional factors using the same index equivalence.
cartesian-product-hom-equiv : (k m n : ℕ)
  → CartesianMap k (m + n) ≃ (CartesianMap k m × CartesianMap k n)
cartesian-product-hom-equiv k m n = isoToEquiv (iso
  (λ h → cartesianCompose (cartesianFirst m n) h ,
    cartesianCompose (cartesianSecond m n) h)
  (λ pair → cartesianPair (fst pair) (snd pair))
  (λ pair → cong₂ _,_ (cartesian-first-pair (fst pair) (snd pair))
    (cartesian-second-pair (fst pair) (snd pair)))
  (λ h → cartesian-pair-projections {k = k} {m = m} {n = n} h))
