{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentPresheafProductTerms where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.EquivalenceCompositionModule as Composition
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.SemanticBridge.PresheafElements as ElementsBase
import Orbifolds.SemanticBridge.DependentPresheafTotal as TotalBase
import Orbifolds.SemanticBridge.DependentPresheafSections as TermsBase
import Orbifolds.SemanticBridge.DependentPresheafProducts as ProductsBase
import Orbifolds.Intensional.RightKanGlobalSections as GlobalSections
import Orbifolds.SemanticBridge.DependentPresheafTermSections as TermSectionsBase

-- Currying and application at the display, now on the actual total-presheaf
-- Term representation. The ordinary beta/eta equations are transferred
-- through constructed inverse maps, with no strict-substitution assertion.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  private module C = Cat.Category C

  Family : P.Presheaf C → Type (ℓ-suc ℓ)
  Family = TotalBase.On.Family C

  Term : (Γ : P.Presheaf C) → Family Γ → Type ℓ
  Term = TermsBase.On.Term ext C

  module Product (Γ : P.Presheaf C) (A : Family Γ) where
    module Core = ProductsBase.On.Product ext C Γ A
    open Core public using (extension; elementProjection; piFamily)

    module Base = Core.Base
    module Extended = Core.Extended

    module Operations (B : Family extension) =
      Composition.On
        (Term extension B)
        (TermSectionsBase.On.Comparison.GlobalSection ext C extension B)
        (TermSectionsBase.On.Comparison.GlobalSection ext C Γ (piFamily B))
        (Term Γ (piFamily B))
        (TermSectionsBase.On.Comparison.equivalence ext C extension B)
        (GlobalSections.Along.section-equivalence ext
          Core.Extended.category Core.Base.category Core.elementProjection B)
        (O.invEquiv
          (TermSectionsBase.On.Comparison.equivalence ext C Γ (piFamily B)))

    -- This applies a product term to the canonical variable over Γ.A.
    open Operations public using (lambda; apply; beta; eta; equivalence)

    lambda-value : (B : Family extension) (t : Term extension B)
      (X : C.Obj) (x : P.Presheaf.value Γ X) (e : Extended.Element)
      (k : Base.Arrow (Cat.Functor.object elementProjection e) (O._,_ X x))
      → P.Nat.component (TermsBase.On.term-value ext C Γ (piFamily B) (lambda B t) X x) e k
        O.≡ TermsBase.On.term-value ext C extension B t (O.fst e) (O.snd e)
    lambda-value B t X x e k = O.cong (λ s → P.Nat.component s e k)
      (TermSectionsBase.On.Comparison.fromSection-value ext C Γ (piFamily B)
        (GlobalSections.Along.lambda-section ext
          Core.Extended.category Core.Base.category Core.elementProjection B (TermSectionsBase.On.Comparison.toSection ext C extension B t)) X x)
      O.∙ GlobalSections.Along.lambda-section-component ext
        Core.Extended.category Core.Base.category Core.elementProjection B
        (TermSectionsBase.On.Comparison.toSection ext C extension B t) (O._,_ X x) e k

    apply-value : (B : Family extension) (t : Term Γ (piFamily B)) (e : Extended.Element)
      → TermsBase.On.term-value ext C extension B (apply B t) (O.fst e) (O.snd e)
        O.≡ P.Nat.component
          (TermsBase.On.term-value ext C Γ (piFamily B) t
            (O.fst (Cat.Functor.object elementProjection e))
            (O.snd (Cat.Functor.object elementProjection e)))
          e (Base.identity (Cat.Functor.object elementProjection e))
    apply-value B t e = TermSectionsBase.On.Comparison.fromSection-value ext C extension B
      (GlobalSections.Along.apply-section ext
        Core.Extended.category Core.Base.category Core.elementProjection B (TermSectionsBase.On.Comparison.toSection ext C Γ (piFamily B) t))
      (O.fst e) (O.snd e)
      O.∙ GlobalSections.Along.apply-section-component ext
        Core.Extended.category Core.Base.category Core.elementProjection B (TermSectionsBase.On.Comparison.toSection ext C Γ (piFamily B) t) e

