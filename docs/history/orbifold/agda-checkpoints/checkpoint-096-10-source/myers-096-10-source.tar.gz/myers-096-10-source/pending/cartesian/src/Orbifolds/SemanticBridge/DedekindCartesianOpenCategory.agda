{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianOpenCategory where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ2; isSetΠ; isSetΣSndProp)
open import Cubical.Data.Nat.Base using (ℕ)
open import Cubical.Data.Sigma
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.TopologicalFiniteBranches as T
import Orbifolds.Intensional.CompactSeparation as C
import Orbifolds.Intensional.OpenSubspaces as OS

open import Orbifolds.SemanticBridge.IdentityPath using
  (idToPath; pathToId; idIsSetToPath; pathIsSetToId)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as Topology

cartesianSiteLevel : Level
cartesianSiteLevel = ℓ-suc (ℓ-suc ℓ-zero)

-- Objects are actual open subspaces of the constructed finite powers.
-- Their certified open subsets naturally live in Type2; arrows below
-- have that same level. No resizing or lifted surrogate hom is used.
record CartesianOpen : Type₂ where
  constructor cartesianOpen
  field
    dimension : ℕ
    domainSubset : T.Subset (Cartesian dimension)
    domainOpen : Topology.OnDimension.MetricOpen dimension domainSubset

open CartesianOpen public

OpenCarrier : CartesianOpen → Type₁
OpenCarrier X = OS.Carrier (domainSubset X)

ambientTopology : (X : CartesianOpen) → T.OpenFragment (Cartesian (dimension X))
ambientTopology X = Topology.OnDimension.cartesianOpenFragment (dimension X)

openTopology : (X : CartesianOpen) → T.OpenFragment (OpenCarrier X)
openTopology X = OS.openSubspace (ambientTopology X) (domainSubset X) (domainOpen X)

openCarrier-path : (X : CartesianOpen) {x y : OpenCarrier X}
  → O.fst x ≡ O.fst y → x ≡ y
openCarrier-path X p = idToPath
  (O.Σ-path-prop (T.member-prop (domainSubset X)) (pathToId p))

isSetOpenCarrier : (X : CartesianOpen) → isSet (OpenCarrier X)
isSetOpenCarrier X = idIsSetToPath (O.isSetΣProp
  (pathIsSetToId (isSetCartesian (dimension X))) (T.member-prop (domainSubset X)))

isPropOpenPredicate : (X : CartesianOpen) (P : T.Subset (OpenCarrier X))
  → isProp (T.IsOpen (openTopology X) P)
isPropOpenPredicate X P = Topology.OnDimension.isPropMetricOpen (dimension X)
  (OS.extendSubset (domainSubset X) P)

OpenContinuous : {X Y : CartesianOpen} → (OpenCarrier X → OpenCarrier Y) → Type₂
OpenContinuous {X} {Y} = C.Continuous (openTopology X) (openTopology Y)

isPropOpenContinuous : {X Y : CartesianOpen} (f : OpenCarrier X → OpenCarrier Y)
  → isProp (OpenContinuous {X} {Y} f)
isPropOpenContinuous {X} f = isPropΠ2
  (λ P _ → isPropOpenPredicate X (C.preimage f P))

OpenMap : CartesianOpen → CartesianOpen → Type₂
OpenMap X Y = Σ (OpenCarrier X → OpenCarrier Y) (OpenContinuous {X} {Y})

open-map : {X Y : CartesianOpen} → OpenMap X Y → OpenCarrier X → OpenCarrier Y
open-map = fst

open-map-continuous : {X Y : CartesianOpen} (f : OpenMap X Y)
  → OpenContinuous {X} {Y} (open-map f)
open-map-continuous = snd

openMap-ext : {X Y : CartesianOpen} {f g : OpenMap X Y}
  → ((x : OpenCarrier X) → open-map f x ≡ open-map g x) → f ≡ g
openMap-ext {X} {Y} equal = Σ≡Prop (isPropOpenContinuous {X} {Y}) (funExt equal)

openMap-coordinate-ext : {X Y : CartesianOpen} {f g : OpenMap X Y}
  → ((x : OpenCarrier X) → O.fst (open-map f x) ≡ O.fst (open-map g x)) → f ≡ g
openMap-coordinate-ext {Y = Y} equal = openMap-ext (λ x → openCarrier-path Y (equal x))

isSetOpenMap : (X Y : CartesianOpen) → isSet (OpenMap X Y)
isSetOpenMap X Y = isSetΣSndProp (isSetΠ (λ _ → isSetOpenCarrier Y))
  (isPropOpenContinuous {X} {Y})

openIdentity : (X : CartesianOpen) → OpenMap X X
openIdentity X = (λ x → x) , OS.identity-continuous (openTopology X)

openCompose : {X Y Z : CartesianOpen} → OpenMap Y Z → OpenMap X Y → OpenMap X Z
openCompose {X} {Y} {Z} g f = (λ x → open-map g (open-map f x)) ,
  OS.compose-continuous (openTopology X) (openTopology Y) (openTopology Z)
    (open-map f) (open-map g) (open-map-continuous f) (open-map-continuous g)

open-identity-left : {X Y : CartesianOpen} (f : OpenMap X Y)
  → openCompose (openIdentity Y) f ≡ f
open-identity-left f = openMap-ext (λ _ → refl)

open-identity-right : {X Y : CartesianOpen} (f : OpenMap X Y)
  → openCompose f (openIdentity X) ≡ f
open-identity-right f = openMap-ext (λ _ → refl)

open-associative : {W X Y Z : CartesianOpen}
  → (h : OpenMap Y Z) (g : OpenMap X Y) (f : OpenMap W X)
  → openCompose (openCompose h g) f ≡ openCompose h (openCompose g f)
open-associative h g f = openMap-ext (λ _ → refl)

cartesianOpenCategory : Cat.Category cartesianSiteLevel cartesianSiteLevel
Cat.Category.Obj cartesianOpenCategory = CartesianOpen
Cat.Category.Hom cartesianOpenCategory = OpenMap
Cat.Category.hom-set cartesianOpenCategory X Y = pathIsSetToId (isSetOpenMap X Y)
Cat.Category.identity cartesianOpenCategory {X} = openIdentity X
Cat.Category.compose cartesianOpenCategory = openCompose
Cat.Category.identity-left cartesianOpenCategory f = pathToId (open-identity-left f)
Cat.Category.identity-right cartesianOpenCategory f = pathToId (open-identity-right f)
Cat.Category.associative cartesianOpenCategory h g f = pathToId (open-associative h g f)

wholeCartesianOpen : (n : ℕ) → CartesianOpen
wholeCartesianOpen n = cartesianOpen n T.full
  (T.open-full (Topology.OnDimension.cartesianOpenFragment n))

open-map-to-ambient-continuous : {X Y : CartesianOpen} (f : OpenMap X Y)
  → C.Continuous (openTopology X) (ambientTopology Y) (λ x → O.fst (open-map f x))
open-map-to-ambient-continuous {X} {Y} f =
  OS.compose-continuous (openTopology X) (openTopology Y) (ambientTopology Y)
    (open-map f) O.fst (open-map-continuous f)
    (OS.inclusion-continuous (ambientTopology Y) (domainSubset Y) (domainOpen Y))
