{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentSheafProducts where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.Intensional.SmallSites as Site
import Orbifolds.Intensional.SmallSheaves as Sh
import Orbifolds.SemanticBridge.DependentPresheafTotal as TotalBase
import Orbifolds.SemanticBridge.DependentSheafFamilies as FamiliesBase
import Orbifolds.SemanticBridge.DependentPresheafProducts as ProductsBase
import Orbifolds.SemanticBridge.PresheafElementSite as ElementSite
import Orbifolds.SemanticBridge.DependentPresheafProductSheaves as PreservationBase
import Orbifolds.SemanticBridge.DependentSheafElementFamilies as Conversion

-- Construct the product by passing through actual sheaves on categories of
-- elements. The conversions retain their underlying presheaves; their
-- independently proved amalgamation certificates do not need unfolding.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ)
    (J : Site.GrothendieckTopology C) where
  module Families = FamiliesBase.On ext C J

  Family : Sh.Sheaf J → Type (ℓ-suc ℓ)
  Family = Families.Family

  module Product (Γ : Sh.Sheaf J) (A : Family Γ)
      (B : Family (Families.total {Γ = Γ} A)) where
    extension : Sh.Sheaf J
    extension = Families.total {Γ = Γ} A

    basePresheaf : P.Presheaf C
    basePresheaf = Sh.Sheaf.underlying Γ

    argumentFamily : TotalBase.On.Family C basePresheaf
    argumentFamily = Families.Family.presheafFamily A

    resultFamily : TotalBase.On.Family C (Sh.Sheaf.underlying extension)
    resultFamily = Families.Family.presheafFamily B

    module Input = Conversion.On ext C J extension
    module Output = Conversion.On ext C J Γ
    module Preservation = PreservationBase.On.Product ext C J basePresheaf argumentFamily

    input-element-is-sheaf : Sh.IsSheaf
      (ElementSite.On.topology C (Sh.Sheaf.underlying extension) J) resultFamily
    input-element-is-sheaf = Input.element-is-sheaf B

    piElementSheaf : Sh.Sheaf (ElementSite.On.topology C basePresheaf J)
    piElementSheaf = Preservation.piSheaf (Input.elementSheaf B)

    piPresheaf : TotalBase.On.Family C basePresheaf
    piPresheaf = Sh.Sheaf.underlying piElementSheaf

    pi-element-is-sheaf : Sh.IsSheaf
      (ElementSite.On.topology C basePresheaf J) piPresheaf
    pi-element-is-sheaf = Sh.Sheaf.is-sheaf piElementSheaf

    pi-total-is-sheaf : Sh.IsSheaf J
      (TotalBase.On.Total.presheaf C basePresheaf piPresheaf)
    pi-total-is-sheaf = Output.total-is-sheaf piElementSheaf

    family : Family Γ
    family = Output.totalFamily piElementSheaf

    family-underlying : O._≡_ {A = TotalBase.On.Family C basePresheaf}
      (Families.Family.presheafFamily family)
      (ProductsBase.On.Product.piFamily ext C basePresheaf argumentFamily resultFamily)
    family-underlying = O.refl

    object : Sh.Sheaf J
    object = Families.total {Γ = Γ} family

    display : P.Nat (Sh.Sheaf.underlying object) basePresheaf
    display = Families.display {Γ = Γ} family

    object-underlying : Sh.Sheaf.underlying object
      O.≡ TotalBase.On.Total.presheaf C basePresheaf piPresheaf
    object-underlying = O.refl

  piFamily : (Γ : Sh.Sheaf J) (A : Family Γ)
    → Family (Families.total {Γ = Γ} A) → Family Γ
  piFamily = Product.family

-- Context-substitution coherence and internal universe closure are separate
-- claims; this construction supplies the actual dependent product family.
