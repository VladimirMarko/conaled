{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianOpenProducts where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Equiv using (_≃_)
open import Cubical.Foundations.Isomorphism using (iso; isoToEquiv)
open import Cubical.Data.Nat.Base using (ℕ; zero; _+_)
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_; inl; inr)
import Cubical.Data.FinData.Base as F
import Cubical.Data.FinData.Properties as FP
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.TopologicalFiniteBranches as T
import Orbifolds.Intensional.CompactSeparation as C
import Orbifolds.Intensional.OpenSubspaces as OS

open import Orbifolds.SemanticBridge.IdentityPath using (pathToId; pathIsContrToId)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
open import Orbifolds.SemanticBridge.DedekindCartesianOpenCategory
import Orbifolds.SemanticBridge.DedekindMetricTopology as Real
import Orbifolds.SemanticBridge.DedekindCartesianMetricTopology as Topology
import Orbifolds.SemanticBridge.DedekindCartesianProducts as Products
import Orbifolds.SemanticBridge.DedekindCartesianOpenContinuity as Continuity

module ProductOpen (X Y : CartesianOpen) where

  private
    m n : ℕ
    m = dimension X
    n = dimension Y
    module Coordinates = Products.CoordinateProduct m n
    module Ambient = Topology.OnDimension (m + n)

  subset : T.Subset (Cartesian (m + n))
  subset = T.intersection (C.preimage Coordinates.left (domainSubset X))
    (C.preimage Coordinates.right (domainSubset Y))

  subset-open : Ambient.MetricOpen subset
  subset-open = T.open-intersection Ambient.cartesianOpenFragment
    (Coordinates.left-continuous (domainSubset X) (domainOpen X))
    (Coordinates.right-continuous (domainSubset Y) (domainOpen Y))

  object : CartesianOpen
  object = cartesianOpen (m + n) subset subset-open

  first : OpenMap object X
  first = (λ z → O._,_ (Coordinates.left (O.fst z)) (O.fst (O.snd z))) ,
    OS.corestrict-continuous (openTopology object) (ambientTopology X)
      (domainSubset X) (domainOpen X) (λ z → Coordinates.left (O.fst z))
      (OS.restrict-continuous Ambient.cartesianOpenFragment (ambientTopology X)
        subset subset-open Coordinates.left Coordinates.left-continuous)
      (λ z → O.fst (O.snd z))

  second : OpenMap object Y
  second = (λ z → O._,_ (Coordinates.right (O.fst z)) (O.snd (O.snd z))) ,
    OS.corestrict-continuous (openTopology object) (ambientTopology Y)
      (domainSubset Y) (domainOpen Y) (λ z → Coordinates.right (O.fst z))
      (OS.restrict-continuous Ambient.cartesianOpenFragment (ambientTopology Y)
        subset subset-open Coordinates.right Coordinates.right-continuous)
      (λ z → O.snd (O.snd z))

  private
    choose-continuous : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
      → (s : F.Fin m ⊎ F.Fin n)
      → C.Continuous (openTopology Z) Real.realOpenFragment
          (λ z → Coordinates.choose (O.fst (open-map f z)) (O.fst (open-map g z)) s)
    choose-continuous {Z} f g (inl i) =
      Continuity.FromOpen.continuous-coordinates Z m (λ z → O.fst (open-map f z))
        (open-map-to-ambient-continuous f) i
    choose-continuous {Z} f g (inr i) =
      Continuity.FromOpen.continuous-coordinates Z n (λ z → O.fst (open-map g z))
        (open-map-to-ambient-continuous g) i

  pair-function : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
    → OpenCarrier Z → Cartesian (m + n)
  pair-function f g z = Coordinates.join (O.fst (open-map f z)) (O.fst (open-map g z))

  pair-continuous : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
    → C.Continuous (openTopology Z) Ambient.cartesianOpenFragment (pair-function f g)
  pair-continuous {Z} f g =
    Continuity.FromOpen.coordinates-continuous Z (m + n) (pair-function f g)
      (λ i → choose-continuous f g (FP.FinSumChar.inv m n i))

  pair-lands : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
    → (z : OpenCarrier Z) → T.member subset (pair-function f g z)
  pair-lands f g z = O._,_
    (subst (T.member (domainSubset X))
      (sym (Coordinates.left-join (O.fst (open-map f z)) (O.fst (open-map g z))))
      (O.snd (open-map f z)))
    (subst (T.member (domainSubset Y))
      (sym (Coordinates.right-join (O.fst (open-map f z)) (O.fst (open-map g z))))
      (O.snd (open-map g z)))

  pair : {Z : CartesianOpen} → OpenMap Z X → OpenMap Z Y → OpenMap Z object
  pair {Z} f g = (λ z → O._,_ (pair-function f g z) (pair-lands f g z)) ,
    OS.corestrict-continuous (openTopology Z) Ambient.cartesianOpenFragment
      subset subset-open (pair-function f g) (pair-continuous f g) (pair-lands f g)

  first-pair : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
    → openCompose first (pair f g) ≡ f
  first-pair f g = openMap-coordinate-ext
    (λ z → Coordinates.left-join (O.fst (open-map f z)) (O.fst (open-map g z)))

  second-pair : {Z : CartesianOpen} (f : OpenMap Z X) (g : OpenMap Z Y)
    → openCompose second (pair f g) ≡ g
  second-pair f g = openMap-coordinate-ext
    (λ z → Coordinates.right-join (O.fst (open-map f z)) (O.fst (open-map g z)))

  pair-projections : {Z : CartesianOpen} (h : OpenMap Z object)
    → pair (openCompose first h) (openCompose second h) ≡ h
  pair-projections h = openMap-coordinate-ext (λ z → Coordinates.join-split (O.fst (open-map h z)))

  hom-equiv : (Z : CartesianOpen) → OpenMap Z object ≃ (OpenMap Z X × OpenMap Z Y)
  hom-equiv Z = isoToEquiv (iso
    (λ h → openCompose first h , openCompose second h)
    (λ fg → pair (fst fg) (snd fg))
    (λ fg → cong₂ _,_ (first-pair (fst fg) (snd fg)) (second-pair (fst fg) (snd fg)))
    pair-projections)

cartesianOpenProducts : Cat.Products cartesianOpenCategory
Cat.Products.product cartesianOpenProducts = ProductOpen.object
Cat.Products.first cartesianOpenProducts {X} {Y} = ProductOpen.first X Y
Cat.Products.second cartesianOpenProducts {X} {Y} = ProductOpen.second X Y
Cat.Products.pair cartesianOpenProducts {Z} {X} {Y} = ProductOpen.pair X Y {Z}
Cat.Products.first-pair cartesianOpenProducts {Z} {X} {Y} f g =
  pathToId (ProductOpen.first-pair X Y {Z} f g)
Cat.Products.second-pair cartesianOpenProducts {Z} {X} {Y} f g =
  pathToId (ProductOpen.second-pair X Y {Z} f g)
Cat.Products.pair-projections cartesianOpenProducts {Z} {X} {Y} h =
  pathToId (ProductOpen.pair-projections X Y {Z} h)

terminalOpen : CartesianOpen
terminalOpen = wholeCartesianOpen zero

terminalArrow : (X : CartesianOpen) → OpenMap X terminalOpen
terminalArrow X = (λ _ → O._,_ emptyCartesian O.tt) ,
  OS.corestrict-continuous (openTopology X) (ambientTopology terminalOpen)
    T.full (domainOpen terminalOpen) (λ _ → emptyCartesian)
    (Continuity.FromOpen.coordinates-continuous X zero (λ _ → emptyCartesian) (λ ()))
    (λ _ → O.tt)

terminalOpen-isTerminal : Cat.Categorical.IsTerminal cartesianOpenCategory terminalOpen
terminalOpen-isTerminal X = pathIsContrToId
  (terminalArrow X , (λ f → openMap-coordinate-ext
    (λ x → dimension-zero-unique emptyCartesian (O.fst (open-map f x)))))
