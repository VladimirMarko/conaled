{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentProductArgumentIsomorphism where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.SemanticBridge.PresheafElements as ElementsBase
import Orbifolds.SemanticBridge.DependentPresheafTotal as TotalBase
import Orbifolds.SemanticBridge.DependentPresheafReindex as ReindexBase
import Orbifolds.SemanticBridge.DependentPresheafProducts as ProductsBase
import Orbifolds.SemanticBridge.DependentProductArgumentInputs as InputsBase
import Orbifolds.SemanticBridge.ElementFamilyTransport as TransportBase
import Orbifolds.SemanticBridge.DependentFamilyTotalMaps as MapsBase

-- An actual isomorphism A -> A' of argument families induces
-- Pi_A' B -> Pi_A (totalForward* B). The local maps use the constructed147
-- input Iso and its display triangles; outer naturality uses its parameter
-- square. The product comparison and naturality are conclusions, not inputs.
-- No base-change wrapper or identity/composition coherence is used or claimed.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  private module C = Cat.Category C

  Family : P.Presheaf C → Type (ℓ-suc ℓ)
  Family = TotalBase.On.Family C

  module Context (Γ : P.Presheaf C) where
    module Base = ElementsBase.On.Context C Γ
    private module FP = P.Theory ext Base.category

    module AlongIso (A A′ : Family Γ) (i : Cat.Iso FP.category A A′)
        (B : Family (TotalBase.On.Total.presheaf C Γ A′)) where
      module SourceProduct = ProductsBase.On.Product ext C Γ A
      module TargetProduct = ProductsBase.On.Product ext C Γ A′
      module Inputs = InputsBase.On.Context.AlongIso ext C Γ A A′ i
      module SourceExtended = ElementsBase.On.Context C SourceProduct.extension
      module LiftMap = ElementsBase.On.Reindex C
        TargetProduct.extension SourceProduct.extension Inputs.totalForward
      module OutputTransport = TransportBase.On C TargetProduct.extension B

      reindexedOutput : Family SourceProduct.extension
      reindexedOutput = ReindexBase.On.reindex ext C
        {Γ = TargetProduct.extension} {Δ = SourceProduct.extension} B Inputs.totalForward

      sourceFamily : Family Γ
      sourceFamily = TargetProduct.piFamily B

      targetFamily : Family Γ
      targetFamily = SourceProduct.piFamily reindexedOutput

      module At (u : Base.Element) where
        module Input = Inputs.At u
        module Old = MapsBase.On.FixedBase ext C TargetProduct.extension
          (TargetProduct.kernel u) B
        module New = MapsBase.On.AcrossBase ext C
          TargetProduct.extension SourceProduct.extension
          (SourceProduct.kernel u) B Inputs.totalForward
        module Transfer = MapsBase.On.Target.AlongIso ext C TargetProduct.extension B
          Input.targetInputs Input.sourceInputs Input.TargetInput.display New.baseMap
          Input.inputIso Input.forward-over-display Input.inverse-over-display

        equivalence : O.Equiv (P.Presheaf.value sourceFamily u) (P.Presheaf.value targetFamily u)
        equivalence = O.compEquiv Old.equivalence
          (O.compEquiv Transfer.equivalence (O.invEquiv New.equivalence))

        forwardSection : P.Presheaf.value sourceFamily u → P.Presheaf.value targetFamily u
        forwardSection s = New.fromOver (Transfer.forward (Old.toOver s))

        inverseSection : P.Presheaf.value targetFamily u → P.Presheaf.value sourceFamily u
        inverseSection s = Old.fromOver (Transfer.inverse (New.toOver s))

        forward-inverse : (s : P.Presheaf.value targetFamily u)
          → forwardSection (inverseSection s) O.≡ s
        forward-inverse = O.section equivalence

        inverse-forward : (s : P.Presheaf.value sourceFamily u)
          → inverseSection (forwardSection s) O.≡ s
        inverse-forward = O.retraction equivalence

        forward-injective : {s t : P.Presheaf.value sourceFamily u}
          → forwardSection s O.≡ forwardSection t → s O.≡ t
        forward-injective {s} {t} p = O.sym (inverse-forward s)
          O.∙ O.cong inverseSection p O.∙ inverse-forward t

        -- Reconstruction handles the actual display-equation certificates;
        -- no nat-ext proof is identified with reflexivity.
        forward-component : (s : P.Presheaf.value sourceFamily u)
          (e : SourceExtended.Element)
          (k : Base.Arrow (Cat.Functor.object SourceProduct.elementProjection e) u)
          → P.Nat.component (forwardSection s) e k
            O.≡ P.Nat.component s (LiftMap.onObject e) k
        forward-component s (Y O., e) k =
          O.sym (OutputTransport.transport-refl {X = Y}
            (P.Nat.component (forwardSection s) (O._,_ Y e) k))
          O.∙ OutputTransport.total-path-fiber {X = Y} O.refl
            (O.sym (New.reconstruction (Transfer.forward (Old.toOver s)) Y (O._,_ e k)))

      module AlongArrow {u v : Base.Element} (h : Base.Arrow u v) where
        private
          module U = At u
          module V = At v
          module Parameter = Inputs.AlongArrow h

        -- Apply the actual147 parameter square to the total map of s, then
        -- recover its B-fiber. This avoids dependent congruence on a varying
        -- input base and does not assume the comparison's naturality.
        parameter-component : (s : P.Presheaf.value sourceFamily v)
          (e : SourceExtended.Element)
          (k : Base.Arrow (Cat.Functor.object SourceProduct.elementProjection e) u)
          → P.Nat.component s (LiftMap.onObject e) (Base.compose h k)
            O.≡ P.Nat.component
              (P.Presheaf.restrict sourceFamily {X = u} {Y = v} h s)
              (LiftMap.onObject e) k
        parameter-component s (Y O., (x O., a)) k =
          O.sym (OutputTransport.transport-refl {X = Y}
            (P.Nat.component s (LiftMap.onObject (O._,_ Y (O._,_ x a)))
              (Base.compose h k)))
          O.∙ OutputTransport.total-path-fiber {X = Y} O.refl
            (O.cong (P.Nat.component (O.fst (V.Old.toOver s)) Y)
              (O.sym (Parameter.forward-parameterValue Y (O._,_ (O._,_ x a) k))))

      comparison : P.Nat sourceFamily targetFamily
      P.Nat.component comparison = At.forwardSection
      P.Nat.is-natural comparison u v h s =
        P.Theory.nat-ext ext SourceExtended.category
          {F = SourceProduct.kernel u} {G = reindexedOutput}
          (λ e k → At.forward-component v s e (Base.compose h k)
            O.∙ AlongArrow.parameter-component h s e k
            O.∙ O.sym (At.forward-component u
              (P.Presheaf.restrict sourceFamily {X = u} {Y = v} h s) e k))

      inverse : P.Nat targetFamily sourceFamily
      P.Nat.component inverse = At.inverseSection
      P.Nat.is-natural inverse u v h s = At.forward-injective u
        (O.sym (P.Nat.is-natural comparison u v h (At.inverseSection v s))
          O.∙ O.cong (P.Presheaf.restrict targetFamily {X = u} {Y = v} h)
            (At.forward-inverse v s)
          O.∙ O.sym (At.forward-inverse u
            (P.Presheaf.restrict targetFamily {X = u} {Y = v} h s)))

      comparison-inverse : FP.compose-nat {F = targetFamily} {G = sourceFamily}
          {H = targetFamily} comparison inverse O.≡ FP.identity-nat targetFamily
      comparison-inverse = FP.nat-ext {F = targetFamily} {G = targetFamily} At.forward-inverse

      inverse-comparison : FP.compose-nat {F = sourceFamily} {G = targetFamily}
          {H = sourceFamily} inverse comparison O.≡ FP.identity-nat sourceFamily
      inverse-comparison = FP.nat-ext {F = sourceFamily} {G = sourceFamily} At.inverse-forward

      argumentIso : Cat.Iso FP.category sourceFamily targetFamily
      Cat.Iso.hom argumentIso = comparison
      Cat.IsIso.inverse-arrow (Cat.Iso.is-iso argumentIso) = inverse
      Cat.IsIso.right-inverse (Cat.Iso.is-iso argumentIso) = comparison-inverse
      Cat.IsIso.left-inverse (Cat.Iso.is-iso argumentIso) = inverse-comparison
