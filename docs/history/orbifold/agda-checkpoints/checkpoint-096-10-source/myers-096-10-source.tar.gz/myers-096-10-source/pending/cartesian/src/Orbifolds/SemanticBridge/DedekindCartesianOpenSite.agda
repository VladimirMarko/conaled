{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianOpenSite where

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels using (isPropΠ)
open import Cubical.Data.Sigma
import Cubical.HITs.PropositionalTruncation as PT
open PT using (∥_∥₁; ∣_∣₁; isPropPropTrunc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.SmallSites as Site

open import Orbifolds.SemanticBridge.IdentityPath using (pathToId; pathIsPropToId)
open import Orbifolds.SemanticBridge.DedekindCartesianOpenCategory
open import Orbifolds.SemanticBridge.DedekindCartesianOpenParts

module OpenSieves = Site.Sieves cartesianOpenCategory

-- Covering sieves contain actual open inclusions around every point.
-- General continuous arrows are present in the category, but pointwise
-- surjectivity alone is not used as a definition of an open cover.
CoverWitness : {X : CartesianOpen} → Site.Sieve cartesianOpenCategory X
  → OpenCarrier X → Type₂
CoverWitness {X} R x = Σ[ P ∈ OpenPart X ]
  (Site.Sieve.contains R (partInclusion P) × PartMember P x)

CartesianCover : {X : CartesianOpen} → Site.Sieve cartesianOpenCategory X → Type₂
CartesianCover {X} R = (x : OpenCarrier X) → ∥ CoverWitness R x ∥₁

cartesianCover-prop : {X : CartesianOpen} (R : Site.Sieve cartesianOpenCategory X)
  → O.isProp (CartesianCover R)
cartesianCover-prop R = pathIsPropToId (isPropΠ (λ _ → isPropPropTrunc))

cartesianCovers-top : (X : CartesianOpen) → CartesianCover (OpenSieves.top X)
cartesianCovers-top X x = ∣ wholePart X , O.tt , O.snd x ∣₁

cartesianCovers-upward : {X : CartesianOpen} {R S : Site.Sieve cartesianOpenCategory X}
  → OpenSieves.Included R S → CartesianCover R → CartesianCover S
cartesianCovers-upward includes cover x = PT.map
  (λ { (P , included , inside) → P , includes (partDomain P) (partInclusion P) included , inside })
  (cover x)

pullbackCoverWitness : {X Y : CartesianOpen} (f : OpenMap Y X)
  {R : Site.Sieve cartesianOpenCategory X} (y : OpenCarrier Y)
  → CoverWitness R (open-map f y) → CoverWitness (OpenSieves.pullback f R) y
pullbackCoverWitness f {R} y (P , included , inside) =
  preimagePart f P ,
  O.subst (λ h → Site.Sieve.contains R h) (pathToId (preimage-square f P))
    (Site.Sieve.downward R (partInclusion P) (preimageComparison f P) included) ,
  preimagePart-member f P y inside

cartesianCovers-pullback : {X Y : CartesianOpen} (f : OpenMap Y X)
  {R : Site.Sieve cartesianOpenCategory X}
  → CartesianCover R → CartesianCover (OpenSieves.pullback f R)
cartesianCovers-pullback f {R} cover y =
  PT.map (pullbackCoverWitness f {R} y) (cover (open-map f y))

composeCoverWitness : {X : CartesianOpen} (P : OpenPart X)
  {S : Site.Sieve cartesianOpenCategory X} (x : OpenCarrier X) (inside : PartMember P x)
  → CoverWitness (OpenSieves.pullback (partInclusion P) S) (partPoint P x inside)
  → CoverWitness S x
composeCoverWitness P {S} x inside (Q , included , local) =
  composePart P Q ,
  O.subst (λ h → Site.Sieve.contains S h) (pathToId (sym (composePart-square P Q))) included ,
  local

cartesianCovers-local : {X : CartesianOpen} {R S : Site.Sieve cartesianOpenCategory X}
  → CartesianCover R
  → ((Y : CartesianOpen) (f : OpenMap Y X) → Site.Sieve.contains R f
    → CartesianCover (OpenSieves.pullback f S))
  → CartesianCover S
cartesianCovers-local {X} {R} {S} cover localCover x = PT.rec isPropPropTrunc
  (λ { (P , included , inside) →
    PT.map (composeCoverWitness P {S} x inside)
      (localCover (partDomain P) (partInclusion P) included (partPoint P x inside)) })
  (cover x)

cartesianOpenGrothendieckTopology : Site.GrothendieckTopology cartesianOpenCategory
cartesianOpenGrothendieckTopology = record
  { Cover = λ {X} R → CartesianCover {X} R
  ; cover-prop = λ {X} R → cartesianCover-prop {X} R
  ; covers-top = cartesianCovers-top
  ; covers-upward = λ {X} {R} {S} includes cover →
      cartesianCovers-upward {X} {R} {S} includes cover
  ; covers-pullback = λ {X} {Y} f {R} cover →
      cartesianCovers-pullback {X} {Y} f {R} cover
  ; covers-local = λ {X} {R} {S} cover localCover →
      cartesianCovers-local {X} {R} {S} cover localCover
  }
