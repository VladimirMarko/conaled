{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentTermTransport where

open import Cubical.Foundations.Prelude using (Level; Type; ℓ-suc)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.SemanticBridge.DependentPresheafTotal as Total
import Orbifolds.SemanticBridge.DependentPresheafReindex as Reindex
import Orbifolds.SemanticBridge.DependentPresheafSections as Terms
import Orbifolds.SemanticBridge.DependentFamilyTotalMaps as Maps

private
  sigma-fiber-path : {a b : Level} {A : Type a} {B : A → Type b}
    {u v : O.Σ A B} (p : u O.≡ v)
    → O.subst B (O.cong O.fst p) (O.snd u) O.≡ O.snd v
  sigma-fiber-path O.refl = O.refl

  fiber-injective : {a b : Level} {A : Type a} {B : A → Type b}
    → O.isSet A → {x : A} {u v : B x}
    → O._,_ {A = A} {B = B} x u O.≡ O._,_ x v → u O.≡ v
  fiber-injective {B = B} setA {x} {u} {v} p =
    O.sym (O.cong (λ q → O.subst B q u)
      (setA x x (O.cong O.fst p) O.refl)) O.∙ sigma-fiber-path p

-- Terms are the existing certified total-presheaf sections. The following
-- maps and equations retain their actual section-equation certificates.
module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  module T = Terms.On ext C
  module R = Reindex.On ext C
  module PT = P.Theory ext C
  private module C = Cat.Category C

  value-ext : (Γ : P.Presheaf C) (A : T.Family Γ) (s t : T.Term Γ A)
    → ((X : C.Obj) (x : P.Presheaf.value Γ X)
      → T.term-value Γ A s X x O.≡ T.term-value Γ A t X x)
    → s O.≡ t
  value-ext Γ A s t same = T.term-ext Γ A
    (PT.nat-ext {F = Γ} {G = T.extension Γ A}
      (λ X x → T.section-reconstruction Γ A s X x
        O.∙ O.cong (λ a → O._,_ x a) (same X x)
        O.∙ O.sym (T.section-reconstruction Γ A t X x)))

  module AlongFamily (Γ : P.Presheaf C) (A B : T.Family Γ)
      (α : P.Nat A B) where
    module M = Maps.On.FixedBase ext C Γ A B

    totalMap : P.Nat (T.extension Γ A) (T.extension Γ B)
    totalMap = M.totalMap α

    map : T.Term Γ A → T.Term Γ B
    O.fst (map t) = PT.compose-nat
      {F = Γ} {G = T.extension Γ A} {H = T.extension Γ B} totalMap (O.fst t)
    O.snd (map t) = PT.nat-ext {F = Γ} {G = Γ}
      (λ X x → T.term-base Γ A t X x)

    map-value : (t : T.Term Γ A) (X : C.Obj) (x : P.Presheaf.value Γ X)
      → T.term-value Γ B (map t) X x
        O.≡ P.Nat.component α (O._,_ X x) (T.term-value Γ A t X x)
    map-value t X x = fiber-injective (P.Presheaf.value-set Γ X)
      (O.sym (T.section-reconstruction Γ B (map t) X x)
        O.∙ O.cong (P.Nat.component totalMap X)
          (T.section-reconstruction Γ A t X x))

  module AlongContext (Γ Δ : P.Presheaf C) (A : T.Family Γ)
      (σ : P.Nat Δ Γ) where
    module Built = R.Along Γ Δ A σ
    reindexed : T.Family Δ
    reindexed = R.reindex {Γ = Γ} {Δ = Δ} A σ

    -- The actual existing substitution, defined by the pullback inverse,
    -- has the expected value in the actual reindexed dependent fiber.
    substitute-value : (t : T.Term Γ A) (X : C.Obj) (x : P.Presheaf.value Δ X)
      → T.term-value Δ reindexed (T.substitute Γ Δ A σ t) X x
        O.≡ T.term-value Γ A t X (P.Nat.component σ X x)
    substitute-value t X x = fiber-injective (P.Presheaf.value-set Γ X)
      (O.sym (O.cong (P.Nat.component Built.lift X)
          (T.section-reconstruction Δ reindexed (T.substitute Γ Δ A σ t) X x))
        O.∙ O.cong (λ n → P.Nat.component n X x)
          (T.substitution-pair Γ Δ A σ t)
        O.∙ T.section-reconstruction Γ A t X (P.Nat.component σ X x))

-- The only path uniqueness used above is the supplied context's sethood.
-- Neither equality of arbitrary types nor a selected global fiber is used.
