{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DedekindCartesianOpenParts where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.TopologicalFiniteBranches as T
import Orbifolds.Intensional.CompactSeparation as C
import Orbifolds.Intensional.OpenSubspaces as OS

open import Orbifolds.SemanticBridge.IdentityPath using (idToPath; pathToId)
open import Orbifolds.SemanticBridge.DedekindCartesianMetric
open import Orbifolds.SemanticBridge.DedekindCartesianOpenCategory

-- An open part gives an actual ambient open subset and its inclusion.
-- Pullbacks below construct these data using the actual map preimage.
record OpenPart (X : CartesianOpen) : Type₂ where
  constructor openPart
  field
    partSubset : T.Subset (Cartesian (dimension X))
    partOpen : T.IsOpen (ambientTopology X) partSubset
    partIncluded : T.Included partSubset (domainSubset X)

open OpenPart public

partDomain : {X : CartesianOpen} → OpenPart X → CartesianOpen
partDomain {X} P = cartesianOpen (dimension X) (partSubset P) (partOpen P)

PartMember : {X : CartesianOpen} → OpenPart X → OpenCarrier X → Type₁
PartMember P x = T.member (partSubset P) (O.fst x)

partInclusion : {X : CartesianOpen} (P : OpenPart X) → OpenMap (partDomain P) X
partInclusion {X} P =
  (λ x → O._,_ (O.fst x) (partIncluded P (O.fst x) (O.snd x))) ,
  OS.corestrict-continuous (openTopology (partDomain P)) (ambientTopology X)
    (domainSubset X) (domainOpen X) O.fst
    (OS.inclusion-continuous (ambientTopology X) (partSubset P) (partOpen P))
    (λ x → partIncluded P (O.fst x) (O.snd x))

partPoint : {X : CartesianOpen} (P : OpenPart X) (x : OpenCarrier X)
  → PartMember P x → OpenCarrier (partDomain P)
partPoint P x inside = O._,_ (O.fst x) inside

partPoint-inclusion : {X : CartesianOpen} (P : OpenPart X) (x : OpenCarrier X)
  → (inside : PartMember P x) → open-map (partInclusion P) (partPoint P x inside) ≡ x
partPoint-inclusion {X} P x inside = openCarrier-path X refl

partFactor : {X Y : CartesianOpen} (P : OpenPart X) (f : OpenMap Y X)
  → ((y : OpenCarrier Y) → PartMember P (open-map f y)) → OpenMap Y (partDomain P)
partFactor {X} {Y} P f lands =
  (λ y → O._,_ (O.fst (open-map f y)) (lands y)) ,
  OS.corestrict-continuous (openTopology Y) (ambientTopology X)
    (partSubset P) (partOpen P) (λ y → O.fst (open-map f y))
    (open-map-to-ambient-continuous f) lands

partFactor-square : {X Y : CartesianOpen} (P : OpenPart X) (f : OpenMap Y X)
  → (lands : (y : OpenCarrier Y) → PartMember P (open-map f y))
  → openCompose (partInclusion P) (partFactor P f lands) ≡ f
partFactor-square P f lands = openMap-coordinate-ext (λ _ → refl)

partInclusion-monic : {X Z : CartesianOpen} (P : OpenPart X)
  → {f g : OpenMap Z (partDomain P)}
  → openCompose (partInclusion P) f ≡ openCompose (partInclusion P) g → f ≡ g
partInclusion-monic P equal = openMap-coordinate-ext
  (λ z → cong (λ h → O.fst (open-map h z)) equal)

wholePart : (X : CartesianOpen) → OpenPart X
wholePart X = openPart (domainSubset X) (domainOpen X) (λ x inside → inside)

composePart : {X : CartesianOpen} (P : OpenPart X)
  → OpenPart (partDomain P) → OpenPart X
composePart P Q = openPart (partSubset Q) (partOpen Q)
  (λ x inside → partIncluded P x (partIncluded Q x inside))

composePart-square : {X : CartesianOpen} (P : OpenPart X) (Q : OpenPart (partDomain P))
  → partInclusion (composePart P Q) ≡ openCompose (partInclusion P) (partInclusion Q)
composePart-square P Q = openMap-coordinate-ext (λ _ → refl)

preimagePart : {X Y : CartesianOpen} (f : OpenMap Y X) → OpenPart X → OpenPart Y
preimagePart {X} {Y} f P = openPart
  (OS.extendSubset (domainSubset Y)
    (C.preimage (λ y → O.fst (open-map f y)) (partSubset P)))
  (open-map-to-ambient-continuous f (partSubset P) (partOpen P))
  (λ y inside → O.fst inside)

preimagePart-member : {X Y : CartesianOpen} (f : OpenMap Y X) (P : OpenPart X)
  → (y : OpenCarrier Y) → PartMember P (open-map f y) → PartMember (preimagePart f P) y
preimagePart-member f P y inside = O._,_ (O.snd y) inside

preimagePart-member-reflect : {X Y : CartesianOpen} (f : OpenMap Y X) (P : OpenPart X)
  → (y : OpenCarrier Y) → PartMember (preimagePart f P) y → PartMember P (open-map f y)
preimagePart-member-reflect {Y = Y} f P y inside =
  subst (λ z → PartMember P (open-map f z))
    (openCarrier-path Y {x = O._,_ (O.fst y) (O.fst inside)} {y = y} refl)
    (O.snd inside)

preimageComparison : {X Y : CartesianOpen} (f : OpenMap Y X) (P : OpenPart X)
  → OpenMap (partDomain (preimagePart f P)) (partDomain P)
preimageComparison f P =
  partFactor P (openCompose f (partInclusion (preimagePart f P)))
    (λ z → O.snd (O.snd z))

preimage-square : {X Y : CartesianOpen} (f : OpenMap Y X) (P : OpenPart X)
  → openCompose (partInclusion P) (preimageComparison f P)
    ≡ openCompose f (partInclusion (preimagePart f P))
preimage-square f P =
  partFactor-square P (openCompose f (partInclusion (preimagePart f P)))
    (λ z → O.snd (O.snd z))

module Pullback {X Y : CartesianOpen} (f : OpenMap Y X) (P : OpenPart X) where

  private
    inverse : OpenPart Y
    inverse = preimagePart f P

  lift-membership : {Z : CartesianOpen} (g : OpenMap Z Y) (h : OpenMap Z (partDomain P))
    → openCompose f g ≡ openCompose (partInclusion P) h
    → (z : OpenCarrier Z) → PartMember inverse (open-map g z)
  lift-membership g h square z = preimagePart-member f P (open-map g z)
    (subst (T.member (partSubset P))
      (sym (cong (λ k → O.fst (open-map k z)) square)) (O.snd (open-map h z)))

  lift : {Z : CartesianOpen} (g : OpenMap Z Y) (h : OpenMap Z (partDomain P))
    → openCompose f g ≡ openCompose (partInclusion P) h
    → OpenMap Z (partDomain inverse)
  lift g h square = partFactor inverse g (lift-membership g h square)

  lift-left : {Z : CartesianOpen} (g : OpenMap Z Y) (h : OpenMap Z (partDomain P))
    → (square : openCompose f g ≡ openCompose (partInclusion P) h)
    → openCompose (partInclusion inverse) (lift g h square) ≡ g
  lift-left g h square = partFactor-square inverse g (lift-membership g h square)

  lift-right : {Z : CartesianOpen} (g : OpenMap Z Y) (h : OpenMap Z (partDomain P))
    → (square : openCompose f g ≡ openCompose (partInclusion P) h)
    → openCompose (preimageComparison f P) (lift g h square) ≡ h
  lift-right g h square = openMap-coordinate-ext
    (λ z → cong (λ k → O.fst (open-map k z)) square)

  lift-unique : {Z : CartesianOpen} (g : OpenMap Z Y) (h : OpenMap Z (partDomain P))
    → (square : openCompose f g ≡ openCompose (partInclusion P) h)
    → (k : OpenMap Z (partDomain inverse))
    → openCompose (partInclusion inverse) k ≡ g → k ≡ lift g h square
  lift-unique g h square k left-law = partInclusion-monic inverse
    (left-law ∙ sym (lift-left g h square))
