{-# OPTIONS --safe --cubical --no-import-sorts #-}

module Orbifolds.SemanticBridge.DependentTermSubstitutionLaws where

open import Cubical.Foundations.Prelude using (Level)
import Orbifolds.Intensional.Identity as O
import Orbifolds.Intensional.CategoricalTransfer as Cat
import Orbifolds.Intensional.SmallPresheaves as P
import Orbifolds.SemanticBridge.DependentPresheafSections as Terms
import Orbifolds.SemanticBridge.DependentPresheafReindex as Reindex
import Orbifolds.SemanticBridge.DependentFamilyReindexingLaws as Families
import Orbifolds.SemanticBridge.DependentTermTransport as Transport

-- Identity and composition for the actual total-section substitution.
-- Both sides inhabit the same dependent result after applying the
-- explicitly constructed family comparison; no strict equality of
-- presheaf presentations or judgmental conversion is asserted.

module On {ℓ : Level} (ext : O.FunExt ℓ ℓ) (C : Cat.Category ℓ ℓ) where
  module T = Terms.On ext C
  module R = Reindex.On ext C
  module F = Families.On ext C
  module V = Transport.On ext C
  module PT = P.Theory ext C

  module Identity (Γ : P.Presheaf C) (A : T.Family Γ) where
    module I = F.Identity Γ A
    module Compare = V.AlongFamily Γ I.reindexed A I.forward
    module Substitute = V.AlongContext Γ Γ A (PT.identity-nat Γ)

    law : (t : T.Term Γ A)
      → Compare.map (T.substitute Γ Γ A (PT.identity-nat Γ) t) O.≡ t
    law t = V.value-ext Γ A _ t
      (λ X x → Compare.map-value (T.substitute Γ Γ A (PT.identity-nat Γ) t) X x
        O.∙ Substitute.substitute-value t X x)

  module Composite (Γ Δ Θ : P.Presheaf C) (A : T.Family Γ)
      (σ : P.Nat Δ Γ) (τ : P.Nat Θ Δ) where
    module I = F.Composite Γ Δ Θ A σ τ
    module Compare = V.AlongFamily Θ I.once I.twice I.forward

    firstFamily : T.Family Δ
    firstFamily = R.reindex {Γ = Γ} {Δ = Δ} A σ

    module First = V.AlongContext Γ Δ A σ
    module Second = V.AlongContext Δ Θ firstFamily τ
    module Direct = V.AlongContext Γ Θ A I.composite

    law : (t : T.Term Γ A)
      → Compare.map (T.substitute Γ Θ A I.composite t)
        O.≡ T.substitute Δ Θ firstFamily τ (T.substitute Γ Δ A σ t)
    law t = V.value-ext Θ I.twice _ _
      (λ X x → Compare.map-value (T.substitute Γ Θ A I.composite t) X x
        O.∙ Direct.substitute-value t X x
        O.∙ O.sym (First.substitute-value t X (P.Nat.component τ X x))
        O.∙ O.sym (Second.substitute-value (T.substitute Γ Δ A σ t) X x))

-- This proves semantic term substitution at the existing presheaf-family
-- interface. A syntax interpretation and substitution laws for every
-- dependent type constructor and original modal operation remain separate.
