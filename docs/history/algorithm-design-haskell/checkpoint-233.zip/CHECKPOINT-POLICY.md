# Durability checkpoint policy

A checkpoint is a self-contained recovery point for the current work. It is
not a version-control archive or a copy of every earlier experiment.

All published checkpoints use this same source/evidence recovery format.
Labels such as "mathematical result" or "review" describe the new content;
they do not identify different backup classes. The latest standalone archive
is the preferred safekeeping and new-chat handoff. Preserve accepted mathematical
achievements through their retained sources/evidence or exact documented source
recovery, and disclose any material recovery limitation. Do not equate this
compact archive with a complete machine image, offline compiler distribution,
all chat history or all historical scratch bytes.

## Keep

- The current integrated Lean sources, source-correspondence records, chapter
  scope, dependency pins, and the current verification evidence.
- The official Haskell source bundle and errata, and the licensed proof
  references already required for this project.
- The final sources of useful experimental proof methods, their generators,
  required inputs, and selected successful gate or diagnostic reports.
- One canonical copy of each large input that is still needed to resume the
  active experiment. Retain a certificate when it is an irreplaceable proof
  input; a redundant external serialization is unnecessary when the complete
  checked data is already present in the Lean source.
- A concise statement of what is proved, what remains open, the current
  experiment, its exact constraints, and the next action.

## Leave out

- Repeated input and source snapshots, abandoned partial outputs, compiled
  objects, caches, downloaded build packages, and toolchain binaries.
- Superseded generated variants and full failed-attempt trees. Retain a short
  explanation of useful negative results and any unique source still useful.
- Prior checkpoint ZIPs, recursive preservation manifests, and copies of old
  continuation documents. Recovery must not depend on earlier checkpoints.

Existing historical archives remain untouched. Exclusion from a new recovery
snapshot is not deletion from those archives or from the working filesystem.

## Checkpoint cadence

Create a new checkpoint after a substantive result or a meaningful amount of
hard-to-reconstruct work, not for each edit or metadata review. The latest
standalone checkpoint is sufficient for recovery. Older checkpoints are optional
historical records and are never dependencies of later snapshots.

## Packaging

`durability-selection.json` is an explicit current file list. The packager does
not recursively scoop up the workspace. Update the selection when current work
changes; remove superseded material instead of appending history indefinitely.

Run `python3 durability_checkpoint.py --id ID --title TITLE --output PATH.zip`.
The compatibility command at `project/adwh-lean/scripts/checkpoint.py` delegates
to this packager. The default publication limit is **32 MiB**. If a candidate
exceeds it, packaging retains the partial locally and reports the largest
members; inspect the selection before considering a justified policy change.
This is a storage guard, unrelated to the mathematical computation limits.

Every archive has an exact payload manifest with byte sizes and SHA256 hashes.
Before publication, the packager checks every ZIP member and its CRC/hash,
checks the current integrated source/control bindings, checks the accepted n6
proof-source bindings, and confirms that selected inputs did not change during
packaging. A clean extraction is checked when changing the packaging format.

The archive's historical gate reports are evidence of the recorded runs.
Packaging and byte verification do not constitute a new mathematical gate.
Compiler binaries and compiled imports are rebuilt from the pinned sources.

## An unfinished authorized migration

Durability must not depend on finishing a long migration. The v2 archive format
can preserve modified current sources with an explicit `migration_in_progress`
state. It retains the previous accepted gate and exactly those old source/control
files needed to recover its bindings; unchanged files are shared. The verifier
reports these as historical baseline bindings and explicitly reports the current
sources as unverified. It does not convert a failed or pending build into a pass.

After the new complete gate passes, return to current-gate bindings and remove
the temporary old-source copies from the selection. This temporary recovery
mechanism is not an accumulating version history. The 32 MiB guard still applies.
