## Latest continuation — checkpoint 208

Checkpoint 208, `adwh-lean-208-selector-prefix-and-lookup-transport.zip`, is a
standalone source/evidence snapshot. It preserves every checkpoint 207 payload
path and earlier mathematical achievement. The integrated project and accepted
ledger are unchanged. The stock `cqueens 16 = 14772512` theorem remains open;
checkpoint 200's actual source-connected native acceptance and checkpoint 205's
62-root Natrec closure remain valid at their recorded boundaries.

### Actual sliced-selector result

The new three-module, 29-origin, 86-report selector experiment failed at the
cumulative wall deadline in 30.216433003006387 seconds, peak 831,156 KiB.
Core passed in 14.896235230989987 seconds with its six outputs. Foundation
passed in 1.6523940240003867 seconds with both outputs and all 56 exact reports.
RecursorSelectors was killed at exit -9 after 13.462481689988635 seconds and
produced neither reports nor outputs. Both its raw logs are empty. This does
not identify a theorem position, diagnose an individual proof or show a
speedup. The complete candidate is unaccepted; its 56-report prefix is accepted.

The exact raw report is 131,915 bytes, SHA256
`a32db0151f86bf0a0d4e5ac3609e3f7abbc760831d16603e2e106906b116e8be`.
All source, snapshot, control and runtime postchecks passed. The source-policy
key `d4ec79bc098030e20ba7221eccdddcda50e6c5a6e96921029a0e2cd394067af0`
is permanently consumed. No unchanged mathematical retry is permitted.

`kernel-sliced-selector/` retains its source assembly, all 29 origin inverses,
five source overlays, independent component/layout/control reviews, actual
preflight, raw report and six logs, permanent marker and exact recovery map.
Root read the saved-evidence auditor in full and ran live and source-only
modes successfully: 103 bindings, 30 snapshot mappings, six logs and eight
actual artifact identities. Compiled artifacts and duplicate snapshots are
omitted from the archive; their exact canonical source/evidence recovery is
retained. These audits preserve the failure and accepted prefix, not a whole
selector or numeral success.

### Reviewed source preparation

The finite-lookup implementation and its lookup-query bridge have independent
source reviews. The collector checks internal names, preserves full records
and derives agreement on exactly twenty requested keys. Guard evidence is
transported to a caller's actual prefix through explicit agreement. The bridge
copies all six fields between the distinct pin structures, recognizes the
entire query, computes its answer and supplies the actual pure-reducer run and
uniform-depth cache premise. It has no expected-answer or fixture argument.
The prefix is used only in the proof field of the lookup optimizer; no runtime
full-prefix construction is required by that interface. Successful installed
agreement, higher normalization and cache/checker integration remain unproved.

The branch-loop sharing variant is independently reviewed. One induction on
strictly smaller branch fuel supplies local bound three; the former full-WHNF
theorem is a short corollary. Exact public headers and the complete named-call
bridge are unchanged. The two contract definitions and six private helpers
move with explicitly recorded ownership; reporting locations stay unchanged.
With the separately reviewed shared-operation base it would have 43 logical
origins and 148 reports. No physical higher closure or compiled acceptance is
claimed. All source variants and full inverse records remain distinct.

The retained masked UInt64 implementation now has a completed independent
source review. It replaces two dynamic modulus operations by proved power-two
mask operations and preserves terminal priority, arbitrary Nat depth/budget,
saturating addition and the total exact Nat fallback. Its refinement is generic
on the stated width/range domain. The old emitted C already shared the low bit
with the tail, so no additional CSE gain is attributed to the new explicit let.
No new generated code, runtime gain or numerical acceptance is claimed yet.

The new masked original-counter endpoint/driver has root's independent source
review and exact inverses to the old endpoint/driver. The prospective complete
native closure has 22 fresh modules, 141 reports, 24 subprocesses and 88 final
artifacts, including the explicit ten-report source-audit module. All selected
experimental proof and code generation, native compile/link, actual n16 call
and final checks must fit one unchanged budget. Only the exact seven-original
native pool is eligible for reuse; its separate historical cost and 21 copied
files are disclosed. Frozen native controls and their completed independent control review are
retained; no native attempt or marker exists at this checkpoint. Root must
complete its own inspection and preflight before dispatch.

### Next work and unchanged boundary

Continue the justified selector/whole-evaluator route and the changed masked
evaluator experiment. A new isolated legacy-format Core source-cost variant
is being investigated after the measured Core cost. It must preserve all
declaration bodies and disclose every module/import/exposure change; changing
the imported visibility regime is not an identical exported-API claim. The
pinned parser rejects `import all` without a module header, so any legacy
variant must explicitly address that import. No such candidate's acceptance
or performance is inherited from this checkpoint's failed run.

Root alone executes compilers, gates, generators, native programs and saved
auditors. Every complete selected new mathematical/native closure remains
fresh within one cumulative 30-second, one-CPU/thread, 1-GiB gate, with default
heartbeat/recursion behavior, strict options and only the three permitted
axioms. Keep every used source marker and meaningful failure. No upstream
metatheory exemption, unchanged retry or budget splitting is authorized.

The user explicitly requested autonomous continuation until the n16 target
and continued uploads. Do not stop merely because this checkpoint is published.
Actual source/prefix recognition, whole operational refinement, a justified
validating checker and its concrete accepted artifact remain necessary for an
optimized-kernel result. External native ACCEPT is not a stock Lean proof of
the concrete acceptance equation. Preserve these evidence boundaries.

Checkpoint 207's actual saved-copy and clean-restoration receipt is included.
The archive needs no earlier ZIP. Compiler/runtime restoration and, for a new
live native gate, validated original-only dependency materialization remain
external build requirements. Source-only recovery audits do not require them.

