# Generic first-row reflection and an exact Word16 source wrapper

## Status and ownership

This is a new two-module source candidate, authored by `counting_route` after
root's source-only authorization. No existing source, result, control, marker
or checkpoint is changed. No Lean/compiler/native count, retained generator,
gate, preflight or saved auditor was run or imported. Independent review and
any future complete gate remain separate.

`ASSESSMENT.md` and `SOURCE-ASSESSMENT.json` are the earlier frozen assessment.
The actual implementation below uses the same semantic boundary. Its empty
state decomposition is proved directly from `solutionsQ_equation`, then joined
to the existing `cqueens_eq_queens3_count`; it does not need an additional
depth-conversion theorem or a new bit-reflection worker.

## Source modules and contracts

| New module | Actual imports | Printed roots |
| --- | --- | ---: |
| `FirstRowReflection` | Original `QueensSearch`; pinned Init list range/sum lemmas | 10 |
| `FirstRowReflectionSource` | `FirstRowReflection`, unchanged `UInt64MaskedSource` | 3 |

The generic namespace is
`ADWH.Experiments.Chapter15.FirstRowReflection`; the original-source adapter
uses its nested `SourceBridge` namespace. Neither shadows a Std namespace or
changes the original counter's declarations.

The combinatorial module defines column reflection `n + 1 - q`, its pointwise
board map, the simple column-bounds predicate `Within`, semantic first-child
cardinality and a paired weighted sum. Its statements quantify over every
natural board size. Bounds are retained exactly where truncated natural
subtraction makes reflection an involution and preserves distance. Legal
moves remain a permutation, since their ascending enumeration order reverses.
Induction on the existing finite `expandRows` proves exact cardinality
preservation without assuming nonempty or nonattacking input boards beyond
the actual column bounds needed for the symmetry.

The final generic sum theorem holds for any `Nat → Nat` function invariant
under reflection on the legal columns. It partitions the columns into the
lower half, a length-zero-or-one center interval and the reflected upper
half. The proof uses lists and multiplicity-preserving permutations, not an
unproved set cardinality shortcut. The zero-size sum is zero; the semantic
queen count's zero-board terminal is handled separately by the adapter.

The adapter's `child n q` is exactly:

```
let s := BitRepresentation.encode [q]
UInt64MaskedEvaluator.countExact 16 (mask n).toNat 16 16
  s.1.toNat s.2.1.toNat s.2.2.toNat
```

The actual Word16 encoder is used at this top-level boundary, including its
original truncation and column-to-bit convention. There is no new bit-order
lemma or hand-copied state formula. The recursive worker itself is untouched.
For `n ≤ 16` and `q ∈ columns n`, the accepted all-state masked-source bridge,
`NatCounting.count_refines`, `countFast_eq` and `stateCount_encode` give exactly
the cardinality of `solutionsQ n [q]`. This is the full source child, using the
already proved sufficient depth **16**, not a guessed search cutoff.

The new total `SourceBridge.cqueens` returns the exact source terminal at zero,
uses the paired sum for positive `n ≤ 16`, and calls the unchanged masked source
wrapper otherwise. Its final theorem states equality to the actual
`ADWH.Chapter15.Queens.BitRepresentation.cqueens` for **every** `n`.
This does not reinterpret inputs beyond the original intended board range.

## Exact arithmetic and fallback

Every selected child is computed by the existing exact UInt64/Nat wrapper.
Unsupported states and widths or the saturation sentinel still take its
proved natural fallback. The top-level sum, doubling and center addition are
ordinary unbounded Nat operations. No theorem assumes that a child or final
answer fits a machine word, and no expected queen count determines any width
or accepted branch.

Even positive boards evaluate `n/2` child calls. Odd boards evaluate those
calls plus the center once. The generic function and proof are reusable for
every supported original board size; there is no numerical answer fixture,
search trace or enumeration invoked by source preparation. The repeated
calls do not mutate or memoize state, so summing separately has no omitted
state effect. Their actual compiled performance remains unmeasured.

## Pinned dependencies and prospective fresh scope

`SOURCE-INVENTORY.json` records the two new sources, all 13 exact statement
headers and roots, the direct existing sources used in the proof, retained
primary API excerpts, and the accepted masked-lintfix provenance.

The literal import closure of `UInt64MaskedSource` in the accepted inventory
contains 18 existing mathematical modules with 118 printed roots. Adding the
two new modules yields a **prospective 20-module / 131-root** complete source
proof closure, with 40 normal `.olean`/`.ilean` outputs. This is an inventory,
not a selected or executed gate. All 20 would have to be freshly checked under
the unchanged cumulative 30-second, one-CPU/thread, 1-GiB/default-option policy.
Only the separately disclosed original seven-module pool could be reused;
no new experimental object is an input.

The retained original `QueensBitCounting` convenience suffix is not imported
through an alternative route. The proposed dependency selection uses the
same accepted scoped Counting source and symbolic primitive replacement as
the masked-lintfix closure. All original executable definitions and the
generic source-count theorem remain present. The separate original Fast/Nat
audit-print module and native certificate parser/driver are unnecessary for
this universal proof closure; a future executable checker selection would
explicitly add its required fresh endpoint and driver.

The original source and accepted-helper bytes are unchanged. These two new
files are additions, so no existing-source inverse is needed; removing the
new candidate leaves every previous source intact. Every reused source row is
hash-bound to its actual accepted selection rather than copied into this
directory. The original source theorem is an input theorem with its existing
proof dependencies, not a numerical acceptance oracle.

## Separate integration work

The existing six-operand `Query.answer_eq` contract remains unchanged. A future
integration may propose an empty-board size and check the exact original
width, depth, mask and zero-state conditions before using this wrapper; all
other queries must retain the current exact evaluator. The theorem proving
that conditional dispatcher equal at every query, the selected source-pin
closure, any cache hook and any installed checking success remain outside
this candidate. No new endpoint or native run is selected by these files.

There is no claim of arbitrary-modulus or arbitrary-width bitboard symmetry.
Such a theorem would require additional mask/shift/cursor-order reasoning.
The current theorem is generic in board size and then uses the book's honest
`n ≤ 16` implementation bridge. This smaller boundary is sufficient for a
future source-correct optimization of the actual target and avoids treating
a universal machine-width framework as a prerequisite.

No measured speedup, complete budget fit, new numeric acceptance, whole-kernel
installation or stock `cqueens 16` numeral proof is asserted. Root alone may
select and execute a reviewed complete experiment.
