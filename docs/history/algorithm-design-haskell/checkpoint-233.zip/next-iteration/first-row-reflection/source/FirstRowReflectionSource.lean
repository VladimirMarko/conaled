import FirstRowReflection
import UInt64MaskedSource

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Exact reflected first-row wrapper for the original Word16 source

The generic reflection theorem is instantiated only at the original source's
proved board range. Each child uses the existing total exact masked evaluator,
including its saturation fallback. Aggregation and doubling are Nat operations.
The empty board and inputs outside the optimized range keep exact semantics.
-/

namespace ADWH.Experiments.Chapter15.FirstRowReflection.SourceBridge

open ADWH.Chapter15.Queens
open ADWH.Chapter15.Queens.BitRepresentation

/-- The source's actual encoded singleton, original mask and complete child
depth. No reflected bit-state representation or answer bound is assumed. -/
def child (n q : Nat) : Nat :=
  let s := encode [q]
  UInt64MaskedEvaluator.countExact 16 (mask n).toNat 16 16
    s.1.toNat s.2.1.toNat s.2.2.toNat

theorem child_eq_firstChild (n q : Nat) (hn : n ≤ 16) (hq : q ∈ columns n) :
    child n q = firstChild n q := by
  have hb : PartialBoard n 1 [q] := by
    apply (partialBoard_cons_iff n 0 q []).mpr
    refine ⟨hq, ?_, by simp, ?_⟩
    · simp [PartialBoard, NonAttacking]
    · intro j hj
      simp at hj
  calc
    child n q = NatCounting.count (mask n).toNat 16 (NatCounting.repr (encode [q])) := by
      unfold child NatCounting.repr
      exact UInt64MaskedEvaluator.SourceBridge.countExact_eq_source
        (mask n).toNat 16 (encode [q]).1.toNat
          (encode [q]).2.1.toNat (encode [q]).2.2.toNat
    _ = countFast (mask n) 16 (encode [q]) :=
      NatCounting.count_refines (mask n) 16 (encode [q])
    _ = literalCountRows n 16 (encode [q]) := countFast_eq n 16 (encode [q])
    _ = stateCount n (encode [q]) := rfl
    _ = (solutionsQ n [q]).length := stateCount_encode hn hb
    _ = firstChild n q := rfl

theorem source_firstRow_sum (n : Nat) (hpos : 0 < n) (hn : n ≤ 16) :
    ADWH.Chapter15.Queens.BitRepresentation.cqueens n =
      ((columns n).map (child n)).sum := by
  rw [cqueens_eq_queens3_count n hn]
  have he : queens3 n = solutionsQ n [] := by simp [queens3, searchQ]
  rw [he, solutionsQ_empty_sum n hpos]
  apply congrArg List.sum
  apply List.map_congr_left
  intro q hq
  exact (child_eq_firstChild n q hn hq).symm

/-- All-input wrapper: optimize every intended Word16 board size, and retain
the existing exact original-source evaluator beyond that intended range. -/
def cqueens (n : Nat) : Nat :=
  if n = 0 then 1
  else if n ≤ 16 then pairedSum n (child n)
  else UInt64MaskedEvaluator.SourceBridge.cqueens n

theorem cqueens_eq (n : Nat) :
    cqueens n = ADWH.Chapter15.Queens.BitRepresentation.cqueens n := by
  unfold cqueens
  by_cases hz : n = 0
  · subst n
    have he := cqueens_eq_queens3_count 0 (by decide)
    have hs : ADWH.Chapter15.Queens.BitRepresentation.cqueens 0 = 1 := by
      simpa [queens3, searchQ, solutionsQ, expandRows] using he
    change 1 = ADWH.Chapter15.Queens.BitRepresentation.cqueens 0
    exact hs.symm
  · rw [ite_eq_right hz]
    by_cases hn : n ≤ 16
    · rw [ite_eq_left hn]
      have hs : ∀ q ∈ columns n, child n (reflectColumn n q) = child n q := by
        intro q hq
        calc
          child n (reflectColumn n q) = firstChild n (reflectColumn n q) :=
            child_eq_firstChild n (reflectColumn n q) hn (reflectColumn_mem n q hq)
          _ = firstChild n q := firstChild_reflect n q hq
          _ = child n q := (child_eq_firstChild n q hn hq).symm
      exact (paired_sum n (child n) hs).symm.trans
        (source_firstRow_sum n (by omega) hn).symm
    · rw [ite_eq_right hn]
      exact UInt64MaskedEvaluator.SourceBridge.cqueens_eq n

#print axioms child_eq_firstChild
#print axioms source_firstRow_sum
#print axioms cqueens_eq

end ADWH.Experiments.Chapter15.FirstRowReflection.SourceBridge
