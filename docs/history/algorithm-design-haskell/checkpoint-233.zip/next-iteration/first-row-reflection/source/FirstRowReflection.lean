import ADWH.Chapter15.QueensSearch
import Init.Data.List.Nat.Range
import Init.Data.List.Nat.Sum

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Column reflection and exact first-row pairing

All combinatorial statements are parameterized by the board size. Reflection
changes legal-move order, so only permutations and cardinalities are used.
This module performs no finite queen computation and supplies no answer.
-/

namespace ADWH.Experiments.Chapter15.FirstRowReflection

open ADWH.Chapter15.Queens

def reflectColumn (n q : Nat) : Nat := n + 1 - q

def reflectBoard (n : Nat) (qs : List Nat) : List Nat :=
  qs.map (reflectColumn n)

def Within (n : Nat) (qs : List Nat) : Prop :=
  ∀ q ∈ qs, q ∈ columns n

theorem reflectColumn_mem (n q : Nat) (hq : q ∈ columns n) :
    reflectColumn n q ∈ columns n := by
  have hb := (mem_columns_iff n q).mp hq
  apply (mem_columns_iff n (reflectColumn n q)).mpr
  unfold reflectColumn
  omega

theorem reflectColumn_involutive (n q : Nat) (hq : q ∈ columns n) :
    reflectColumn n (reflectColumn n q) = q := by
  have hb := (mem_columns_iff n q).mp hq
  unfold reflectColumn
  omega

theorem distance_reflect (n a b : Nat)
    (ha : a ∈ columns n) (hb : b ∈ columns n) :
    distance (reflectColumn n a) (reflectColumn n b) = distance a b := by
  have hab := (mem_columns_iff n a).mp ha
  have hbb := (mem_columns_iff n b).mp hb
  unfold distance reflectColumn
  omega

theorem columns_reflect (n : Nat) :
    (columns n).map (reflectColumn n) = (columns n).reverse := by
  apply List.ext_getElem
  · simp
  · intro i hi hj
    have hin : i < n := by simpa only [List.length_map, columns_length] using hi
    simp only [List.getElem_map, List.getElem_reverse, columns,
      List.getElem_range', List.length_range', Nat.one_mul, reflectColumn]
    omega

private theorem reflected_mem_iff (n q : Nat) (qs : List Nat)
    (hq : q ∈ columns n) (hqs : Within n qs) :
    reflectColumn n q ∈ reflectBoard n qs ↔ q ∈ qs := by
  change reflectColumn n q ∈ qs.map (reflectColumn n) ↔ q ∈ qs
  rw [List.mem_map]
  constructor
  · rintro ⟨a, ha, he⟩
    have he' := congrArg (reflectColumn n) he
    rw [reflectColumn_involutive n a (hqs a ha),
      reflectColumn_involutive n q hq] at he'
    simpa only [he'] using ha
  · intro h
    exact ⟨q, h, rfl⟩

private theorem newSafe_reflect (n q : Nat) (qs : List Nat)
    (hq : q ∈ columns n) (hqs : Within n qs) :
    NewSafe (reflectColumn n q) (reflectBoard n qs) ↔ NewSafe q qs := by
  have hl : (reflectBoard n qs).length = qs.length := List.length_map _
  constructor
  · intro h
    unfold NewSafe at h ⊢
    intro j hj
    have hj' : j < (reflectBoard n qs).length := by simpa only [hl] using hj
    have hh := h j hj'
    have hb := hqs qs[j] (List.getElem_mem hj)
    simpa only [reflectBoard, List.getElem_map, distance_reflect n q qs[j] hq hb]
      using hh
  · intro h
    unfold NewSafe at h ⊢
    intro j hj
    have hj' : j < qs.length := by simpa only [hl] using hj
    have hb := hqs qs[j] (List.getElem_mem hj')
    simpa only [reflectBoard, List.getElem_map, distance_reflect n q qs[j] hq hb]
      using h j hj'

theorem moves_reflect_perm (n : Nat) (qs : List Nat) (hqs : Within n qs) :
    ((moves n qs).map (reflectColumn n)).Perm (moves n (reflectBoard n qs)) := by
  have hc : ((columns n).map (reflectColumn n)).Perm (columns n) := by
    rw [columns_reflect]
    exact List.reverse_perm _
  let p := fun q => decide (q ∉ reflectBoard n qs) && newDiag q (reflectBoard n qs)
  have he : ((columns n).map (reflectColumn n)).filter p =
      ((columns n).filter (fun q => decide (q ∉ qs) && newDiag q qs)).map
        (reflectColumn n) := by
    rw [List.filter_map]
    apply congrArg (List.map (reflectColumn n))
    apply List.filter_congr
    intro q hq
    apply Bool.eq_iff_iff.mpr
    dsimp only [Function.comp_def, p]
    simp only [Bool.and_eq_true, decide_eq_true_eq, newDiag_eq_true_iff,
      reflected_mem_iff n q qs hq hqs, newSafe_reflect n q qs hq hqs]
  have hp := hc.filter p
  rw [he] at hp
  exact hp

private theorem sum_eq_of_perm {xs ys : List Nat} (h : xs.Perm ys) :
    xs.sum = ys.sum := by
  induction h with
  | nil => rfl
  | cons _ _ ih => simp only [List.sum_cons, ih]
  | swap => simp only [List.sum_cons]; omega
  | trans _ _ ih ih' => exact ih.trans ih'

theorem expandRows_length_reflect (n r : Nat) (qs : List Nat)
    (hqs : Within n qs) :
    (expandRows n r (reflectBoard n qs)).length = (expandRows n r qs).length := by
  induction r generalizing qs with
  | zero => rfl
  | succ r ih =>
    simp only [expandRows, List.length_flatMap, successors, List.map_map,
      Function.comp_def]
    calc
      ((moves n (reflectBoard n qs)).map
          (fun q => (expandRows n r (q :: reflectBoard n qs)).length)).sum =
          (((moves n qs).map (reflectColumn n)).map
            (fun q => (expandRows n r (q :: reflectBoard n qs)).length)).sum :=
        (sum_eq_of_perm ((moves_reflect_perm n qs hqs).map _)).symm
      _ = ((moves n qs).map (fun q => (expandRows n r (q :: qs)).length)).sum := by
        rw [List.map_map]
        apply congrArg List.sum
        apply List.map_congr_left
        intro q hq
        have hb : Within n (q :: qs) := by
          intro a ha
          rcases List.mem_cons.mp ha with rfl | ha
          · exact ((mem_moves_iff n q qs).mp hq).1
          · exact hqs a ha
        simpa only [Function.comp_def, reflectBoard, List.map_cons] using ih (q :: qs) hb

theorem solutionsQ_length_reflect (n : Nat) (qs : List Nat) (hqs : Within n qs) :
    (solutionsQ n (reflectBoard n qs)).length = (solutionsQ n qs).length := by
  have hl : (reflectBoard n qs).length = qs.length := List.length_map _
  by_cases h : qs.length ≤ n
  · simp only [solutionsQ, hl, ite_eq_left h]
    exact expandRows_length_reflect n (n - qs.length) qs hqs
  · simp only [solutionsQ, hl, ite_eq_right h]

def firstChild (n q : Nat) : Nat := (solutionsQ n [q]).length

theorem firstChild_reflect (n q : Nat) (hq : q ∈ columns n) :
    firstChild n (reflectColumn n q) = firstChild n q := by
  have hb : Within n [q] := by
    intro a ha
    have he : a = q := by simpa only [List.mem_singleton] using ha
    simpa only [he] using hq
  simpa only [firstChild, reflectBoard, List.map_cons, List.map_nil] using
    solutionsQ_length_reflect n [q] hb

private theorem moves_nil (n : Nat) : moves n [] = columns n := by
  unfold moves
  apply List.filter_eq_self.mpr
  intro q _
  apply Bool.and_eq_true_iff.mpr
  constructor
  · exact decide_eq_true (by simp)
  · apply (newDiag_eq_true_iff q []).mpr
    intro j hj
    simp at hj

theorem solutionsQ_empty_sum (n : Nat) (hn : 0 < n) :
    (solutionsQ n []).length = ((columns n).map (firstChild n)).sum := by
  have hb : PartialBoard n 0 [] := by simp [PartialBoard, NonAttacking]
  have he := solutionsQ_equation hb
  have hs : solved n [] = false := by
    unfold solved
    exact decide_eq_false (by simp only [List.length_nil]; omega)
  rw [hs] at he
  change solutionsQ n [] = searchQ n (successors n []) at he
  rw [he]
  simp only [searchQ, List.length_flatMap, successors, moves_nil, List.map_map,
    Function.comp_def, firstChild]

private theorem reflected_upper_half (h middle : Nat) :
    ((columns h).reverse.map (reflectColumn ((h + middle) + h))) =
      List.range' (1 + h + middle) h := by
  apply List.ext_getElem
  · simp [columns]
  · intro i hi hj
    have hin : i < h := by
      simpa only [List.length_map, List.length_reverse, columns_length] using hi
    simp only [List.getElem_map, List.getElem_reverse, columns,
      List.getElem_range', List.length_range', Nat.one_mul, reflectColumn]
    omega

private theorem sum_three_parts (h middle : Nat) (f : Nat → Nat)
    (hs : ∀ q ∈ columns ((h + middle) + h),
      f (reflectColumn ((h + middle) + h) q) = f q) :
    ((columns ((h + middle) + h)).map f).sum =
      2 * ((columns h).map f).sum + ((List.range' (1 + h) middle).map f).sum := by
  have hc : columns ((h + middle) + h) =
      columns h ++ List.range' (1 + h) middle ++ List.range' (1 + h + middle) h := by
    unfold columns
    rw [← List.range'_append_1 (s := 1) (m := h + middle) (n := h),
      ← List.range'_append_1 (s := 1) (m := h) (n := middle)]
    simp only [List.append_assoc, Nat.add_assoc]
  have hu : ((List.range' (1 + h + middle) h).map f).sum =
      ((columns h).map f).sum := by
    rw [← reflected_upper_half h middle, List.map_map]
    have hm : (columns h).reverse.map (f ∘ reflectColumn ((h + middle) + h)) =
        (columns h).reverse.map f := by
      apply List.map_congr_left
      intro q hq
      have hq' : q ∈ columns h := List.mem_reverse.mp hq
      have hb := (mem_columns_iff h q).mp hq'
      have hn : q ∈ columns ((h + middle) + h) :=
        (mem_columns_iff _ q).mpr ⟨hb.1, by omega⟩
      exact hs q hn
    rw [hm, List.map_reverse, List.sum_reverse]
  rw [hc]
  simp only [List.map_append, List.sum_append]
  rw [hu]
  omega

/-- Exact pairing for an arbitrary natural-valued symmetric column weight. -/
def pairedSum (n : Nat) (f : Nat → Nat) : Nat :=
  2 * ((columns (n / 2)).map f).sum +
    if n % 2 = 0 then 0 else f (n / 2 + 1)

theorem paired_sum (n : Nat) (f : Nat → Nat)
    (hs : ∀ q ∈ columns n, f (reflectColumn n q) = f q) :
    ((columns n).map f).sum = pairedSum n f := by
  have hn : n = ((n / 2) + (n % 2)) + (n / 2) := by omega
  have hs' : ∀ q ∈ columns (((n / 2) + (n % 2)) + (n / 2)),
      f (reflectColumn (((n / 2) + (n % 2)) + (n / 2)) q) = f q := by
    simpa only [← hn] using hs
  have hp := sum_three_parts (n / 2) (n % 2) f hs'
  rw [← hn] at hp
  have hm : ((List.range' (1 + n / 2) (n % 2)).map f).sum =
      if n % 2 = 0 then 0 else f (n / 2 + 1) := by
    have hc : n % 2 = 0 ∨ n % 2 = 1 := by omega
    rcases hc with hc | hc
    · simp [hc]
    · simp [hc, List.range', Nat.add_comm]
  simpa only [pairedSum, hm] using hp

#print axioms reflectColumn_mem
#print axioms reflectColumn_involutive
#print axioms distance_reflect
#print axioms columns_reflect
#print axioms moves_reflect_perm
#print axioms expandRows_length_reflect
#print axioms solutionsQ_length_reflect
#print axioms firstChild_reflect
#print axioms solutionsQ_empty_sum
#print axioms paired_sum

end ADWH.Experiments.Chapter15.FirstRowReflection
