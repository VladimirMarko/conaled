# Independent source review: first-row reflection

**Status: passed source-only review; not compiled.** I found no mathematical or pinned-API blocker in the frozen two-module candidate. This review does not accept a proof, select a gate, run a count, or establish a performance result. Its exact 39 input bindings and statement/API checks are in `SOURCE-AUDIT.json`.

`counting_route` authored both new modules. `validity_contracts` performed this review and did not change those modules or their author controls. The reviewer previously authored some reused FiniteFold and masked-evaluator work; this is an independent review of the new reflection/adapter construction, not a new independent audit of every historical backend proof. The accepted dependency report is used for exact source-selection provenance only.

## Frozen scope

| Module | Source bytes | SHA-256 | New public roots |
| --- | ---: | --- | ---: |
| `FirstRowReflection` | 10,397 | `089d487a9a01c51ab2bcdc7375d103e9d55fc85daf8cc7aaef5bed813d22cb06` | 10 |
| `FirstRowReflectionSource` | 3,898 | `8a1e24ec4e3dde9b41a8f8e45af3cb2d5ee0807c1254ce56063d8c599c66ce2e` | 3 |

The inventory is `16c42eee03cc6c6fcccdcb60eff8a07e32a307c389a0ddee8bafdea5c00d76c8`. All 13 public headers, six private supporting headers, seven definitions and 13 ordered axiom-print commands agree with the actual source. The files use ordinary legacy imports and only the stated strict options. No admission, new axiom, unsafe/native proof escape, noncomputable evaluator, resource override or expected-count premise was found.

## Column symmetry and complete enumeration

The board uses one-based columns, `columns n = List.range' 1 n`. Reflection is `n + 1 - q`; the involution and distance lemmas correctly retain legal-column hypotheses. Those bounds are essential because subtraction is truncated in `Nat`. The proof does not claim a global involution on arbitrary naturals.

`columns_reflect` identifies the reflected enumeration with its reverse by indexed list equality. The legal-move proof then preserves multiplicity through `List.Perm.filter` and `List.Perm.map`. The membership and diagonal tests are transported separately: bounded reflection is injective on the board's entries, and absolute column distance is unchanged while row indices stay fixed. This establishes a permutation of legal moves without assuming that their ascending order is preserved.

`expandRows_length_reflect` uses induction on the actual remaining expansion depth. Each selected child has a legal new column, so `Within` is preserved for the induction hypothesis. The proof sums the same child cardinalities through the move permutation; it does not replace lists by sets or discard duplicate branches. Its initial board need only satisfy the stated column bounds. `solutionsQ_length_reflect` also covers an overlong board: both source expressions take the existing empty-result branch.

The singleton specialization supplies `firstChild_reflect`. The empty-board decomposition uses the original `solutionsQ_equation` and `moves n [] = columns n`, and correctly requires `0 < n`. At zero the source has one terminal empty board, whereas the sum over first moves is empty, so omitting this premise would have been wrong.

## Exact weighted pairing

`paired_sum` applies to an arbitrary natural-valued function symmetric on the legal columns. Its helper partitions the full source range into a lower interval, a middle interval, and a reflected upper interval. The upper interval is obtained from the **reversed** lower interval, and sum invariance is justified by the actual list laws.

The arithmetic identity `n = (n / 2 + n % 2) + n / 2` and the two possible remainders account for the center exactly. Even sizes have two equal half sums. Odd sizes add the unique center once. The zero-size weighted sum is zero. No equality of individual child weights is assumed except the explicit reflection hypothesis, and no known numerical queen count enters the construction.

## Original-source adapter

The executable `child n q` uses the actual `BitRepresentation.encode [q]`, original `mask n`, and the existing total masked evaluator at width 16, branch budget 16 and depth 16. It does not substitute a hand-written reflected bit state.

For `n ≤ 16` and a legal column, the proof first constructs `PartialBoard n 1 [q]`, then composes the exact existing interfaces:

1. `UInt64MaskedEvaluator.SourceBridge.countExact_eq_source` gives the Nat evaluator on that encoded state.
2. `NatCounting.count_refines` gives `countFast` on the original Word16 state.
3. `countFast_eq` and the definition of `stateCount` give the original literal counter.
4. `stateCount_encode` gives the complete `solutionsQ n [q]` cardinality.

Depth 16 is therefore the previously proved sufficient source depth, not an assumed remaining-row cutoff. Every child retains the exact evaluator's input checks, saturation detection and Nat fallback. The outer sum, multiplication by two and optional center addition use unbounded `Nat`, so the adapter does not require the total or any child count to fit in UInt64.

`source_firstRow_sum` connects the full first-child sum to the actual source `cqueens` through `cqueens_eq_queens3_count`. The final theorem handles zero separately using the original empty-board terminal, applies symmetry for positive `n ≤ 16`, and uses the unchanged all-input masked-source equality for `n > 16`. Its statement is equality to `ADWH.Chapter15.Queens.BitRepresentation.cqueens n` for every natural `n`. It makes no claim that the wrapped Word16 behavior beyond 16 counts unrestricted mathematical boards.

## API, provenance and future execution

I checked the five complete pinned SDK identities and all 23 retained API excerpts. The proof uses the actual `Bool.and_eq_true_iff` with `.mpr`, while using proposition equality `Bool.and_eq_true` only as a simplification rule. The list filter, permutation, range-concatenation, reverse-index and sum signatures match their uses. The Range excerpt at lines 84–89 in the author's API file precedes `getElem_range'`; I also read its actual declaration at lines 90–92 and retain that supplemental excerpt in the audit. This is a documentation supplement, not a source correction. The `List.Perm` constructor and Nat sum equation source snippets used by the local sum induction are retained there as reference-only SDK evidence.

All 18 reused mathematical source rows match the accepted masked-lintfix report's exact paths, bytes, hashes, imports and root lists. The proposed order is topologically valid against the seven disclosed original-source pool modules and pinned standard library. The resulting **20 fresh modules / 131 reports / 40 default outputs** is a prospective universal-proof scope. Its count is 118 retained dependency reports plus 13 new reports. The historical accepted native result neither checks these new files nor authorizes reuse of experimental objects.

Any selected complete gate still needs all new mathematical modules fresh under the unchanged cumulative 30-second, one-CPU, 1-GiB/default-option policy. An endpoint/driver, conditional integration with the six-operand query evaluator, cache use, installation soundness, a new numerical run and a stock Lean numeral proof are outside this candidate. No source or proof-control bytes were changed during review; fresh elaboration and strict-warning acceptance remain pending.
