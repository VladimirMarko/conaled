# First-row column reflection: a source-correct optimization boundary

## Decision

Prepare a small, separate column-reflection proof and an exact first-row
wrapper around the existing masked evaluator. The combinatorial theorem is
parameterized by every natural board size. Its adapter to this book's actual
Word16 counter keeps the explicit `n ≤ 16` condition and uses the existing
exact implementation outside that range. No expected count, proposed answer,
fixture or arithmetic-fit assumption is needed.

This is a genuine search reduction: for an even positive board size it
evaluates one child from each reflected first-row pair and doubles their sum.
For odd size it also evaluates the center child once. It leaves every selected
child's search and exact saturation fallback intact. The pairing is still an
uncompiled proof proposal; no speedup or full-budget fit has been measured.

## Existing theorems and the missing symmetry

`QueensConstraintReflection.reverseDomains`, `fits_reverse` and
`solutions_length_reverse`, and `QueensConstraintCertificates.count_reverse`,
reverse **row order**. `QueensSearch.board_reverse` likewise maps a board to
its reversed list. Those results do not exchange column `q` with `n + 1 - q`
and cannot justify the proposed first-row pruning.

The existing geometry is well suited to a new column theorem. `Queens.distance`
is saturated natural subtraction in both directions; for `1 ≤ a,b ≤ n`,
reflecting both columns preserves that distance by elementary arithmetic.
`NewSafe`, `moves`, `successors`, `expandRows` and `solutionsQ` expose all
subsequent search conditions. The columns are exactly `List.range' 1 n`.
Reflection permutes that list in reverse order and preserves each legal move.

The intended missing proof chain is:

1. Define `mirrorColumn n q = n + 1 - q` and map it over board lists. Prove
   bounded involution, column bounds, distance and legal-move preservation.
2. Prove the reflected legal-move lists are permutations. Their enumeration
   orders generally differ; do not claim literal list equality.
3. Induct on `expandRows` depth to prove equal completion cardinalities from
   a board and its column reflection. This yields
   `|solutionsQ n [q]| = |solutionsQ n [n+1-q]|` for every legal first column.
4. Prove a separate arithmetic pairing lemma for any natural-valued function
   on columns satisfying that involution. Split into the lower half, an optional
   center and the reflected upper half, retaining all multiplicities.

All four steps concern arbitrary `n`, not a table of small answers. A list-sum
permutation lemma is sufficient; no external finite-set library or general
dihedral-group framework is needed.

## The accepted child bridge is already present

For `n ≤ 16` and `q ∈ columns n`, let `s = BitRepresentation.encode [q]`.
The proposed executable child uses the existing
`UInt64MaskedEvaluator.countExact` at width, branch budget and depth 16 with
the three natural components of `s` and the original `(mask n).toNat`.

The existing source theorems compose as follows:

| Existing declaration | What it supplies |
| --- | --- |
| `UInt64MaskedEvaluator.SourceBridge.countExact_eq_source` | Exact equality of this child computation to `NatCounting.count`. |
| `NatCounting.count_refines` | Natural masks agree with the exact Word16 `countFast`, at every depth and state. |
| `BitRepresentation.countFast_eq` | The fast counter equals `literalCountRows` with the original mask. |
| `BitRepresentation.stateCount_encode` | At depth 16 a reachable encoded singleton counts exactly `solutionsQ n [q]`. |
| `BitRepresentation.searchCount_cons` | The empty-board source counter equals the sum of its complete first-row child counts. |

`searchCount_cons` already justifies using depth **16** for each child. Its
proof uses sufficient remaining depth and early terminal tests; no unproved
replacement of the original child depth 15 is needed. The singleton state is
the literal `move (0,0,0) (singleton q)`. Calling the existing encoder at the
top-level boundary needs no new arithmetic or bit-order correspondence.

The sum and final doubling are ordinary `Nat` arithmetic. Each child retains
the accepted UInt64 saturation sentinel and exact Nat fallback. Consequently
there is no new premise that a child, doubled sum or final answer fits UInt64.
The zero-board case remains the source value one; the odd center is added
once, including the one-board case. Inputs above 16 use the unchanged total
source wrapper, preserving even its out-of-intended-domain Word16 behavior.

## Why this avoids a larger bit-reflection development

The pinned SDK provides `BitVec.reverse`, `getLsbD_reverse`,
`getMsbD_reverse` and `reverse_reverse_eq`. It does not already supply the
whole state-count symmetry needed here. A direct arbitrary-width proof would
also need reflection of both shifts/diagonal roles, bounded-mask invariants,
availability, and reordering of the least-bit cursor sum. Reflection sends
the least selected bit to the opposite end of the order, so a pointwise
step-by-step correspondence of the current cursor loop is insufficient.

The board-level proof and existing all-state count bridge discharge exactly
the required original-source boundary with less new machinery. They do not
establish symmetry of `FirstOrderNat.count` at arbitrary modulus, budget,
depth, masks or state. A general machine-width extension beyond the original
Word16 range would need its own proven state/board bridge or bitwise symmetry
theorem and is not a prerequisite for this optimization.

## Fresh proof and integration boundaries

The proposed mathematical source consists of two modules: one importing the
existing `QueensSearch` semantics and proving column/count/pairing laws, and
one importing that module and the existing masked source adapter to prove the
new total source wrapper. No queen enumeration, count or answer is executed
while preparing either file. The existing original import pool is provenance,
not permission to reuse any new mathematical object in a future complete gate.

An endpoint can use the new wrapper only after its universal original-source
equality is freshly checked. The existing `CountQueryGuard.Query.answer_eq`
has a broader six-operand contract, so replacing its backend requires a
separate conditional wrapper theorem: recognize a supported empty-board
query, prove its equality using the new source result, and retain the current
exact evaluator for every other query. A guess at board size may propose a
candidate, but the exact mask/width/depth/zero-state conditions must be checked.
No such query or cache integration is included here.

For the actual even-size target, the new wrapper would evaluate eight first-row
children instead of sixteen. That is a source-level branch count, not a measured
time ratio; proof compilation, query recognition, allocation and later checker
work remain. The current ordinary-field Core candidate stays separate. Root
alone can select a complete fresh proof/native gate with unchanged limits.

## Evidence and status

`SOURCE-ASSESSMENT.json` binds the exact retained source files and declaration
locations used in this assessment. SDK snippets, if needed by the eventual
proof, will be bound separately to their pinned primary source. The source
search found no existing column-reflection theorem in the retained Chapter15
Lean files; this is an explicit text census, not a theorem about all libraries.

This assessment introduces no theorem acceptance, new numeric result,
kernel-installation claim or stock numeral proof. All prior source, reports,
controls, markers and checkpoints remain unchanged.
