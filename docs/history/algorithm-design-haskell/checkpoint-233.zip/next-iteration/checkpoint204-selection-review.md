# Checkpoint 204 selection review

This selection retains every checkpoint203 payload path and all earlier
accepted mathematical achievements. It adds three actual recursor attempts,
exact five-attempt recovery, reviewed but uncompiled Bool/delta/spine/source
body work, the optional Expr/Canon source cut, the actual cache-seam assessment,
and explicitly unfinished masked-evaluator source preparation. The current
Natrec source is the actual failed05 variant. There is no new concrete count,
Natrec acceptance, optimized checking path or stock numeral theorem.

Duplicate attempt snapshots resolve through the canonical recovery map.
Unique source/control versions, all278 raw logs, five reports and permanent
markers remain physical. The 185 snapshot mappings and688 compiled identities
were checked by root in both live and source-only saved-evidence audits.
Both passed; the compiled objects themselves are omitted from this archive.
The script was reviewed against the previously published203 version, including
the exact historical-section digest checks and explicit empty04/05 logs.

Root also checked all106 direct input occurrences of the five new isolated
source reviews against actual bytes and the selection. The Bool/Delta chain
resolves historical04 Natrec through retained canonical paths, so its review
does not claim that05 was checked as a dependency. The source-body comparison
is static syntax correspondence; annotation and normalization remain open.

The marked masked independent-review draft is retained as unfinished work,
not adopted as a frozen review. Unfinished compact gate controls and the
in-progress structural-head proof are outside this publication; their next
completed states belong in a later checkpoint. No compiled object, runtime
binary, cache, old checkpoint ZIP or full upstream source checkout is added.
The two old source ZIPs are the already-required book/proof source bundles.
Checkpoint203's actual clean-recovery/saving receipt is included.

The first packaging attempt used the existing explicit 33 MiB storage
allowance and correctly stopped at 34,903,650 bytes, exceeding that allowance
by 300,642 bytes. Its partial archive remains local. Root inspected the exact
candidate and largest members: no earlier payload path is missing, and the
235 new members total 364,262 compressed bytes. Their largest entries are
the three real new gate reports, cache-seam source inventory, reversible
source cuts and exact historical review inputs. The overall increase over
203 is 448,212 bytes, including changed living evidence and ZIP metadata.

An explicit 34 MiB allowance is justified for this checkpoint to retain those
sources and exact outcomes. No redundant compiler/build tree or old checkpoint
ZIP has been included. The default policy remains 32 MiB. This storage change
is independent of the unchanged 30-second, one-CPU/thread, 1-GiB mathematical
limit. The packager must verify exact members, CRCs, every payload hash and
the integrated/n6 source bindings before the archive is published.
