## Checkpoint 208: accepted prefix and new source interfaces

The latest snapshot is `adwh-lean-208-selector-prefix-and-lookup-transport.zip`.
It includes every checkpoint 207 payload path, earlier accepted mathematical
results and the exact later sliced-selector failure. No earlier archive is a
recovery dependency. The integrated project and accepted ledger are unchanged.

The complete sliced-selector attempt failed at 30.216433003006387 seconds.
Its Core/Foundation prefix passed with 56 exact reports; the final selector
module timed out silently and produced no outputs. The 86-report closure and
stock n16 theorem remain open. All 30 attempt snapshots have exact canonical
recovery mappings. Keep the six logs, report, marker and map; compiled outputs
and duplicate snapshots are intentionally omitted.

After extraction, from the archive root:

```text
python3 -I next-iteration/kernel-sliced-selector/audit_saved_result.py --source-only
```

Root's live and source-only audits passed before packaging. A clean-extraction
audit and saved-copy receipt created after publication belong to the next
checkpoint, not retroactively to this ZIP. Source-only auditing reads evidence;
it does not rerun Lean or turn the complete failure into success.

The finite-lookup transport, lookup-query bridge, branch-loop proof sharing,
masked UInt64 evaluator and masked endpoint/driver have independent source
reviews, all retained with their exact inputs and inverses. They remain
uncompiled beyond the explicitly accepted selector prefix. The independently reviewed masked native
controls are a frozen upcoming experiment; consult their review and do not
invent an execution result or reuse prior experimental objects.

For continued live compilation, restore the pinned external Lean distribution
using the existing toolchain instructions. The upcoming masked native gate
also needs the exact seven-original native dependency pool. Checkpoints omit
its generated objects; its retained report/marker is historical evidence.
Missing objects require an explicitly recorded bounded materialization, with
new evidence and preserved old markers, before the new gate may consume them.
All selected experimental sources must still compile freshly in that gate.

Read the latest section of `CONTINUATION.md` for the next source-cost revision
and the actual optimized-kernel integration obligations. The mathematical
30-second/one-CPU/1-GiB policy and no-unchanged-retry rule remain in force.

