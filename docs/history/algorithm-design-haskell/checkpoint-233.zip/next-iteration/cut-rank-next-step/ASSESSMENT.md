# After the fixed cut-rank probe

## Decision

The probe validates the exact **61-product to35-group** identity, but does not establish a basis of19 functions or a rank below35. Do not feed the sampled rank19 into a counting certificate, repeat the sampling policy, or build a dense polynomial normalizer on that premise.

A narrow next mathematical milestone is plausible: propose **one fixed exact additive relation among the35 B views from the already recorded Nat matrix**, then certify or refute that complete function identity using the original ordered ADD/guard Shannon rules. Every candidate-derivation and identity-checking operation must be charged, and the result must be a complete identity witness or an honestly retained failure. This is a new exact algebraic question, not another attempt to make the sample rank look smaller. No such relation is presently known, and this assessment performs no candidate search, expansion, elimination or evaluation.

I do not recommend immediately adding a grouping normalization pass to the latest lazy counter. There is a concrete way to integrate grouping before product construction, described below, but the current evidence does not show a net saving large enough to advance the stalled contraction or the n16 goal.

## What the recorded run establishes

The producer and independent replay both complete. The trace has23,591 charged starts and23,591 completions, with no pending requests. Both reports retain the outcome `inconclusive_sampled_rank`. These are Python diagnostic results, not new Lean rank or source-count theorems. [RUN, REPLAY]

| Recorded side | Source-view attempts | Distinct sample rows | Sample rank | Outcome |
| --- | ---: | ---: | ---: | --- |
| A: the35 grouped Nat functions | 60 | 56 | 35 | Stopped at full column rank |
| B: the35 distinct guarded views | 35 | 19 | 19 | Fixed witness pool exhausted |

For B, every available row belongs to the selected independent set. **Rank19 is the maximum possible for these19 rows.** This is a small greedy pool, not a demonstrated global deficiency. The sample matrix necessarily admits column relations, but those relations may disappear at an unobserved assignment. No rational or global GF(2) function relation has been established. [REPLAY]

The exact cut reconstruction covers all128 assignments to the seven eliminated variables, with67 zero cases and61 retained occurrences. Original-root lineage validates the common disjoint12-variable X and16-variable Y partition. The61 A views pair with35 B views, so

`F(x,y) = Σ(j<35) A'_j(x) B_j(y)`

with every A occurrence retained in its group's natural sum. This grouping is useful independently of the rank test; it follows from exact equality of B views and distributivity. [DESIGN, REPLAY]

If both matrices had reached35, invertible parity minors would have established exact rational separation rank35 at this partition. That would exclude fewer separated rational terms here, but would not exclude a cheaper basis with35 terms, another partition, or a different counting method. It would not make the current cofactor algorithm optimal.

The actual A minor already establishes rational independence of the35 grouped A functions, subject to formalizing the diagnostic witness. Thus, at this fixed partition, the rank of F is the dimension of the B span. The present matrices support only the range **19 through35**, not equality to19. Any further rank reduction here must come from a genuine relation among B functions; an A-only relation is excluded by the full A minor. This is a mathematical inference from the diagnostic matrices, not an accepted Lean theorem.

One sampled grouped Nat value exceeded1. It is a completed scalar observation only. No outside-factor compatibility or extendible board family was checked. [REPLAY]

## Carrying the35-term grouping into contraction

There is a sound integration point: **collect terminal operand pairs before calling multiplication and before assembling the Boolean-branch sum tree**. Keep their exact cofactor proofs and occurrence coverage. Within that one designated block, group by an already checked identical right view/ID, construct each left Nat sum, then construct one product per group and the final group sum. The parent has already proved generic occurrence-preserving `regroup_products` and `sumVars_regroup_products`; their permutation premise still needs concrete coverage evidence. [GROUP-LAW]

This must be part of contraction construction. Flattening and regrouping a completed sum after its products and recursive cofactors have already been computed cannot erase that work from the budget. The collector must also retain existing zero/forced/absent/projection logic and multiplicities; naively replacing it with all128 explicit branches could do more work. Every new collection, coverage, grouping and arithmetic obligation remains charged.

For a simple arithmetic illustration,61 nonzero uncached terms need61 product requests and60 addition requests. Group sizes totaling61 over35 nonempty groups need26 within-group additions,35 products and34 outer additions:95 requests rather than121. **The direct difference is26 product requests; it does not remove addition requests.** This illustration excludes all cofactors, collection/coverage claims, cache behavior and the recursive work triggered by the existing factoring rule. It is not a measured certificate saving.

That distinction matters for the current algorithm. The latest lazy counter makes an ordinary multiplication into a nonrecursive product descriptor; it no longer performs the large recursive ADD product expansion seen in the older guarded implementation. At its50,000-claim stop,31,856 claims are cofactors, while only61 terminal products are involved in the particular cut under discussion. Grouping may improve subsequent expression structure, but the retained data do not measure that saving. [FACTORED, LAZY-SOURCE, GUARDED-SOURCE]

There is also a representation boundary. The validated35 classes are flat guarded views of old source roots25319/42351. The latest lazy circuit contains sums/products and is not canonically equivalent to those views by node identity. Exact duplicate B views in the old ADD do not automatically mean identical lazy cofactor IDs. To import the classes into the lazy counter, either they must arise from its own checked exact IDs, or a complete cross-representation equivalence must justify them. A post hoc normalizer or an external assertion that the old replay agreed would not suffice.

Therefore a global pair collector is a coherent construction, but **the current probe does not justify another counter run solely for that26-product arithmetic reduction**. A useful application would need to eliminate repeated conditioning or preserve a compact factor representation through the difficult block, with its full cost counted. That evidence is not present yet.

## What existing metadata says about exact polynomials

The35 recorded B views use **20 distinct bare core IDs, all of kind `ite`**. None has a constant1 bare core. Several reuse cores40874,40971,42331,38888 and10966 under different guards. Outer negative-literal counts range from0 to6. These facts were extracted only from the saved views and their existing source declarations; no descendant traversal or function evaluation was performed. [B-METADATA]

An exact multilinear interpretation is straightforward in principle:

- a constant maps to its integer value;
- a branch maps to `P_low + x_v * (P_high − P_low)`;
- a guard multiplies the core by its positive literals and factors `(1−x_v)` for its negative literals.

The already checked support conditions keep the relevant variables disjoint, so these constructions remain multilinear. But the outer guards are only part of each B function. Their small literal counts do not bound the term counts inside the20 nontrivial cores. Sixteen Boolean variables permit65,536 monomial positions per function, or2,293,760 across35 separate dense coefficient vectors. Those are representation capacities, not measured expansion sizes. The metadata neither proves an explosion nor supports a sparse expansion fitting the remaining budget.

Building complete expanded polynomials before finding out whether any relation exists is therefore an unsupported detour. The original Shannon structure already provides a more direct exact identity-checking language.

## One narrow exact-identity milestone

Use the existing19×35 **Nat** matrix only to propose a coefficient vector. Fix the candidate-selection rule before execution; do not use later counterexamples to expand the sample pool or run an adaptive search campaign. A nonzero integer relation can be encoded as an equality of two positive Nat combinations by moving negative coefficients to the other side. This keeps the identity-checking statement within natural-valued arithmetic even when the candidate was discovered overQ.

The untrusted certificate must then prove that equality for **every Y assignment** using local guarded-view restriction, alignment at the next variable, both Shannon branches, and exact terminal Nat arithmetic. Repeated identical views may have their coefficients combined with explicitly checked operations. A failing terminal equality yields a retained counterexample; a cap stop yields an incomplete certificate. The candidate matrix itself supplies no global premise. No dense2^16 or2^28 truth table is required by the interface, although the symbolic check can still grow too large.

A relation isolating one B function with coefficient1 against a positive combination is immediately useful for the existing Nat algebra. A general signed/rational basis reduction is a larger step: exploiting it may require signed intermediate factors, denominator treatment and a proved transfer back to the natural source total. The existing Nat counter cannot silently inherit those operations.

Success should mean an actual, complete exact identity certificate with all processing accounted for—not another deficient sampled matrix. It would demonstrate a new compression mechanism beyond literal duplicate grouping. Even success on one relation would not establish n16 feasibility: its substitution, factor complexity and aggregate cost must be measured before selecting a new complete counting route. Failure must remain evidence against that fixed candidate, without an automatic order, sample or board-size sweep.

## Scope and bindings

Only this new assessment directory is written. There is no new counter, replay, rank calculation, symbolic expansion/elimination, polynomial construction or Lean run. Metadata extraction reads existing completed reports and selected source declarations only. `recorded-metadata.json` preserves the small copied data; `evidence.json` binds the exact inputs.

References (workspace-relative):

- **RUN:** `next-iteration/cut-rank-review/attempts/cut-rank-01/run-report.json` and `work.jsonl`.
- **REPLAY:** `next-iteration/cut-rank-review/attempts/cut-rank-replay-01/{run-report.json,replay-report.json}`.
- **DESIGN:** `next-iteration/cut-rank-review/{DESIGN.md,schema.json,PROTOCOL.md}`.
- **GROUP-LAW:** `next-iteration/block-grouping-laws/{BlockGrouping.lean,README.md}`.
- **FACTORED:** `next-iteration/lazy-factored-circuit/{README.md,RESULTS.json}`.
- **LAZY-SOURCE:** `next-iteration/lazy-factored-circuit/diagnostics/produce_lazy_trace.py`.
- **GUARDED-SOURCE:** `next-iteration/bulk-guarded-fused/diagnostics/add_line_counter.py`.
- **B-METADATA:** this directory's `recorded-metadata.json`, sourced from REPLAY and its already bound original guarded input.
