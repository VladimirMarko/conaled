# Empty-basis producer and independent replay: completed

The standalone source is `diagnostics/produce_basis.py`. Its CLI is `--trace --sample --output`. It uses the root-owned bounded runner's snapshot layout: policy files at the source root, and exact inherited files under `inherited/`. Those inherited files are read for byte bindings and are never imported or executed by this producer.

No producer, evaluator, algebraic fixture, semantic helper, independent replay or Lean process was run during implementation. Preparation consists of source editing, AST parsing, JSON syntax checks, static source comparison and byte hashes. This document makes no empirical completion, basis-dimension or counting claim.

## Fixed mathematical path

The basis and witness lists begin empty. The saved grouping file supplies only its35 original views. The code contains no read of its old matrix, ranks or assignments, and has no input for the later six counterexamples.

For each original column, the producer eliminates against immutable basis vectors in insertion order. It evaluates the current residual at each retained witness through individual original B evaluations and rational dot products. Sparse merges construct the exact new coefficient vector. A positive denominator product produces the integer oracle input. A complete zero gives an identity; a complete refutation with signed value z produces the new canonical rational vector c/z. Older basis entries remain immutable. Final coverage is checked column by column.

The interpreter, guarded cofactor rules, complete zero/refutation search and exact-state cache are retained from the frozen relation producer. Eighteen inherited methods are byte-identical. The only changed body among those integer-oracle methods is `term_add`: its old derived20-term bound becomes the35 original-column bound. This does not change the50,000-request limit.

New arithmetic is an explicitly recorded rational-add wrapper, source evaluation, sparse vector merging, denominator clearing and basis bookkeeping. All rational multiplication/subtraction/division, sign normalization, gcd steps and underlying integer arithmetic retain their exact old rules.

## Source and completion bindings

Each source evaluation records a full view/full assignment lookup. Hashes only index completion-ordered buckets; every inspected candidate has a charged exact-key comparison. On a miss, the evaluator checks the guard and validated constant or selected original ite child. Recursive flat views come from that selected child's validation record. The unselected child is not evaluated. Only completed values enter the cache; hits are charged and name the earlier result.

Dot-product and oracle-origin requests select the original-column view validation after their charged start. The selected WorkID appears in the output and explicit dependencies. This serialization clarification was approved by the parent and coordinated with the independent replayer. It changes no mathematical rule or request schedule. Exact earlier draft bytes and the two clarification patches are under `producer-origin/`.

The unchanged meter rejects request50,001 before semantic work, preserves pending stacks and publishes results only after matching completion records. Every candidate, source evaluation, cache hit, scalar child and oracle descendant shares that counter. Time/CPU/memory controls belong to the root-owned runner and remain unchanged. A complete producer result would still require independent replay; it would not itself be a Lean theorem.

## Preparation evidence

`producer-origin/static-source-comparison.json` lists unchanged/new methods and imports. `producer-origin/producer.patch` records the exact adaptation from the frozen relation producer. `producer-origin/preparation.json` binds the current source, policy files, inherited sources, earlier plan bytes and these static records. No historical attempt tree, trace copy or generated certificate is duplicated here.

After source/control review, the single fixed producer and independent replay completed successfully. All 35 columns are covered, the exact rational dimension is 31, and four scale-one identities were found in 29,360 charged requests. See `RESULTS.md` and `RESULTS.json`. Mathematical program, protocol and schema bytes remain unchanged after execution. Historical authoring snapshots and patches are optional workspace history, not durability dependencies; final canonical source/control and result reviews bind the retained current sources.
