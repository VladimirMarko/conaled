# Exact basis completed: four identities and dimension 31

The one fixed empty-basis algorithm completed all 35 original columns within
the unchanged budget, and the independent replayer accepted the entire
transcript. The rational span of these exact guarded B functions has dimension
**31**. This is external diagnostic evidence, not a Lean theorem or a new
queens count.

## The actual identities

With the original column numbering, all four recorded clearing scales are one:

```text
B0  - B1  - B2  + B3  = 0
B6  - B7  - B8  + B9  = 0
B11 - B12 - B13 + B14 = 0
B17 - B18 - B19 + B20 = 0
```

These are complete pointwise identities of the original guarded functions,
independently checked through the signed zero-proof DAG. The discarded columns
are 3, 9, 14 and 20. Their root proof IDs are 134, 216, 289 and 343. The other
31 columns have source-bound triangular independence witnesses, and the final
coverage record includes every column. Thus the dimension claim supplies both
spanning and independence, not merely a sampled rank or several failed guesses.

The earlier batch's sixteen separate refutations remains correct. A linear
combination of refuted proposals can be a valid identity; that batch did not
exclude this possibility. The new algorithm started with no basis or witnesses
and used only the saved original views, not the old 19 sampled rows or the six
previous counterexamples.

## Recorded cost and controls

| Measurement | Producer | Independent replay |
| --- | ---: | ---: |
| Child elapsed seconds | 0.867624397 | 2.310043218 |
| Peak child RSS, KiB | 108,660 | 114,024 |
| Outcome | Complete exact basis | Entire transcript accepted |

There were **29,360 starts and 29,360 completions**, no pending requests, and
58,722 physical transcript records. The budget included source validation,
constituent source values, cache comparisons, rational vector arithmetic,
denominator clearing, all global oracle calls and final coverage.

| Phase | Charged requests |
| --- | ---: |
| Original view loading | 35 |
| Selected source validation | 1,956 |
| Column elimination, evaluation and oracle work | 27,333 |
| Final coverage | 36 |

The independent replay checked 1,253 distinct original descriptors and 1,101
completed source-value cache entries. There are 344 published zero-proof nodes
in the complete run. This includes proper substates used during independent
column refutations; it is not a count of root identities. The maximum vector
and signed-state length was four. Recorded numerator, denominator, cleared
coefficient, state coefficient, source-value and terminal-value widths were
all at most two bits.

Both processes used one CPU, a 30-second wall/CPU limit and 1 GiB address space.
The producer's cap remained 50,000 requests. There was one producer attempt
and one independent replay, with unchanged source and input hashes. No second
ordering, sample policy, oracle, normalization, larger board or relaxed limit
was tried. No Lean process ran for this diagnostic.

## What this permits and what remains

The four identities permit an exact signed regrouping of the 35-term expression.
For example, eliminating B3 uses B3 = B1 + B2 - B0. Its new B0 coefficient is
A0 - A3, which need not be a natural-valued function. The normalized rational
basis vectors are not needed to use these four integer identities, but the
existing natural-number contraction cannot silently treat subtraction as
natural truncated subtraction.

The dimension is only four below the current 35-term grouping. Conditional on
the already checked full-column-rank A witness and the designated cut bridge,
31 is also the exact rational separation rank at this fixed X/Y partition.
Further unconditional rational basis searches here cannot reduce it below 31.
This does not constrain a different partition or separately proved relations
valid under outside-factor conditions.

The current lazy counter uses different descriptor roots at the same frontier.
An identity for the guarded source functions must be transferred through an
actual lineage/equality bridge before rewriting that counter. Term-count
reduction alone is not a measured reduction of its complete counting work.

The next decision is a concrete proof/integration assessment: certify these
four fixed identities from internally interpreted guarded descriptors, assess
the cost of a signed block replacement, and bind the replacement to the actual
factor occurrence. Neither the basis-discovery arithmetic nor the Python
replayer should become a trusted premise of Lean. A new route still needs a
complete bounded source-linked small counting proof before larger-board work.
The target `BitRepresentation.cqueens 16 = 14772512` remains open.

## Canonical recovery evidence

- `RESULTS.json` contains the exact extracted coefficients, committed basis
  vectors, outcomes, counts, timings and byte bindings. Its extraction performs
  no new source evaluation, elimination, rank computation or semantic replay.
- `attempts/basis-01/work.jsonl` is the single canonical complete transcript:
  11,510,282 bytes, SHA256
  `52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6`.
- `attempts/basis-01/run-report.json` records the bounded producer process.
- `attempts/basis-replay-01/run-report.json` records the bounded replay process.
- `attempts/basis-replay-01/replay-report.json` records the accepted replay,
  SHA256 `48cf7f62c41be1c64ff34e01e7235e08c29553fda08576a9ba7e18ba16e11d9b`.
- `../exact-basis-review/` contains the canonical source/control and result
  reviews. The mathematical programs, protocol and schema remain unchanged
  after execution.

The next compact checkpoint retains these current sources and results once.
It retires the older fixed-relation work transcript from its selection while
keeping that negative result's documentation, reports and regenerable code.
Historical authoring copies, patches, attempt source/input snapshots and the
replay's duplicate certificate are not recovery prerequisites. Existing files
and older archives remain untouched.
