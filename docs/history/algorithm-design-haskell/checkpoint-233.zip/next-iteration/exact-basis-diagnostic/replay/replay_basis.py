#!/usr/bin/env python3
"""Independent replay of the fixed exact-basis diagnostic.

The fixed basis controller checks scheduled requests, local results, exact origins
and completion order. No producer, evaluator, algebra package, or previous
semantic checker is imported. This file is an unexecuted implementation until
its independent source review and one authorized bounded replay are recorded.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import sys
import time


SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
SAMPLE_SHA = "ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2"
DESIGN_SHA = "f4348e182b4a9e73fa603524a7ba46169edb1ebce8fb30c4507858f3bf727d24"
SCHEMA_SHA = "7963068009a08ad638f0697283740ea3edf7db892a15897df8c9b384bc7c6dea"
PROTOCOL_SHA = "d98237b37a29edb45bd9a15cbf3a35e67b15dfda368496666ef86f0dd69ad08b"
PROGRAM_SHA = "5315caa207d966b1bf4291a734af6f9253495d1dfeb1412e92346cd65de794df"
BASE_PROTOCOL_SHA = "28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147"
BASE_PRODUCER_SHA = "5c5ba4f6d8a87f9931f6da9fe2d64ff3598aaf1c0c9d7dc3637678efbe817029"
BASE_REPLAYER_SHA = "029ad7a95d6d37c66b53b9d78fb1e3d6a341852eb7596491dda314700c617cbc"
COLUMNS, CAP, VARIABLES = 35, 50000, 210
ZERO_VIEW = (0, 0, 0)
MASK_LIMIT = 1 << VARIABLES
Y_VARIABLES = (171, 174, 175, 177, 186, 187, 189, 191,
               192, 193, 195, 200, 202, 203, 206, 208)
Y_MASK = sum(1 << index for index in Y_VARIABLES)


class Rejected(Exception):
    """The supplied transcript or fixture is inconsistent."""


class EndOfPrefix(Exception):
    """A retained footer occurred before the next semantic request."""

    def __init__(self, footer, location):
        self.footer = footer
        self.location = location


def need(condition, message):
    if not condition:
        raise Rejected(message)


def integer(value, label):
    need(type(value) is int, label + ": integer required")
    return value


def natural(value, label, bound=None):
    integer(value, label)
    need(value >= 0, label + ": nonnegative integer required")
    if bound is not None:
        need(value < bound, label + ": upper bound exceeded")
    return value


def unique_fields(items):
    result = {}
    for key, value in items:
        need(key not in result, "duplicate JSON field: " + str(key))
        result[key] = value
    return result


def parse_json(raw):
    return json.loads(raw, object_pairs_hook=unique_fields)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def same(actual, expected, label):
    # Exact JSON comparison preserves the distinction between bool and int.
    left, right = encoded(actual), encoded(expected)
    need(left == right, f"{label}: observed {left[:500]}, expected {right[:500]}")


def binding(path):
    path = Path(path)
    h, length = hashlib.sha256(), 0
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
            length += len(block)
    return {"path": str(path), "bytes": length, "sha256": h.hexdigest()}


def checked_view(raw):
    need(type(raw) in (list, tuple) and len(raw) == 3, "view shape")
    positive, negative, core = raw
    natural(positive, "positive mask", MASK_LIMIT)
    natural(negative, "negative mask", MASK_LIMIT)
    natural(core, "bare core ID")
    need(positive & negative == 0, "contradictory full view")
    return positive, negative, core


class RawInputs:
    """Byte binding and raw indexing only; no graph validation or evaluation."""

    def __init__(self, trace, sample):
        self.trace_binding = binding(trace)
        self.sample_binding = binding(sample)
        same(self.trace_binding["sha256"], SOURCE_SHA, "fixed original trace")
        same(self.sample_binding["sha256"], SAMPLE_SHA, "fixed saved sample")
        self.index, self.parsed_records = {}, 0
        with Path(trace).open(encoding="utf-8") as stream:
            for text in stream:
                row = parse_json(text)
                self.parsed_records += 1
                if row.get("type") == "node":
                    # Preserve duplicates and distinguish malformed bool IDs
                    # from integer IDs. Only a charged validate request may
                    # inspect the actual descriptor and reject its semantics.
                    self.index.setdefault(encoded(row.get("id")), []).append(row)
        self.sample = parse_json(Path(sample).read_text())

    def descriptor(self, index):
        natural(index, "source descriptor ID")
        rows = self.index.get(encoded(index), [])
        need(len(rows) == 1, f"missing or duplicated selected descriptor {index}")
        same(rows[0]["id"], index, "selected descriptor ID")
        return rows[0]


@dataclass(frozen=True)
class Completed:
    work_id: int
    output: dict
    operation: str = ""
    inputs: dict | None = None

    def reference(self, name, *indices):
        return [self.work_id, name, *indices]


@dataclass
class Frame:
    work_id: int
    explicit: list = field(default_factory=list)
    children: list = field(default_factory=list)


OPERATIONS = (
    "view_load", "validate", "view_validate", "int_scalar", "rat_mul", "rat_sub",
    "rat_div", "rat_normalize", "gcd_step",
    "normalize", "term_add", "term_compare", "state", "state_lookup",
    "cache_candidate", "cache_term", "view_support", "support_join",
    "select_variable", "branch", "cofactor", "terminal_decide",
    "refute_lift", "column_start", "eliminate", "rat_add", "dot", "dot_term",
    "evaluate", "evaluation_lookup", "evaluation_candidate", "vector_sub",
    "vector_merge", "clear_vector", "clear_entry", "oracle_bridge",
    "origin_term", "column_complete", "basis_commit", "basis_entry",
    "basis_finish", "coverage_entry",
)


class Journal:
    """Consume one scheduled request before performing its local checks."""

    def __init__(self, path):
        self.path = Path(path)
        self.stream = self.path.open(encoding="utf-8")
        self.lines = 0
        self.started = 0
        self.completed = {}
        self.stack = []
        self.counts = {name: 0 for name in OPERATIONS}
        self.cache_counts = {name: {"hits": 0, "misses": 0}
                             for name in ("validate", "zero_state", "source_evaluation")}
        self.context = {"phase": "load", "column": None, "basis_index": None}
        self.maxima = {name: 0 for name in (
            "numerator_bits", "denominator_bits", "vector_terms", "cleared_coefficient_bits",
            "state_coefficient_bits", "state_terms", "source_value_bits", "terminal_integer_bits",
            "pending_depth", "zero_cache_entries", "source_evaluation_cache_entries")}
        self.header = self.read()
        need(self.header.get("kind") == "header", "missing initial header")

    def read(self):
        line = self.stream.readline()
        need(bool(line), "transcript ended without its complete footer")
        self.lines += 1
        result = parse_json(line)
        need(type(result) is dict, "record must be an object")
        return result

    def event(self, location):
        row = self.read()
        if row.get("kind") == "footer":
            raise EndOfPrefix(row, location)
        return row

    def record(self, index):
        natural(index, "completed work reference")
        need(index in self.completed, f"reference to unfinished work {index}")
        return self.completed[index]

    def value(self, reference):
        need(type(reference) is list and len(reference) >= 2, "Ref shape")
        item = self.record(reference[0]).output
        name = reference[1]
        need(type(name) is str and name in item, "Ref output field")
        item = item[name]
        for index in reference[2:]:
            natural(index, "Ref list selector")
            need(type(item) in (list, tuple) and index < len(item), "Ref list selection")
            item = item[index]
        return item

    def use(self, frame, reference):
        value = self.value(reference)
        frame.explicit.append(reference[0])
        return value

    def use_record(self, frame, index):
        result = self.record(index)
        frame.explicit.append(index)
        return result

    def argument(self, frame, argument):
        need(type(argument) is dict and len(argument) == 1, "integer argument shape")
        if "literal" in argument:
            return integer(argument["literal"], "integer literal")
        need("ref" in argument, "unknown integer argument tag")
        return integer(self.use(frame, argument["ref"]), "integer argument reference")

    def inspect_argument(self, argument):
        # Used only inside an already charged wrapper after the operand's
        # origin has already been recorded, or for reporting metadata.
        if "literal" in argument:
            return integer(argument["literal"], "integer literal")
        return integer(self.value(argument["ref"]), "integer argument reference")

    def set_context(self, phase, column=None, basis_index=None):
        self.context = {"phase": phase, "column": column, "basis_index": basis_index}

    def rational_observation(self, value):
        numerator, denominator = value
        self.maxima["numerator_bits"] = max(self.maxima["numerator_bits"], numerator.bit_length())
        self.maxima["denominator_bits"] = max(self.maxima["denominator_bits"], denominator.bit_length())

    def observe(self, operation, output):
        if operation in {"rat_add", "rat_mul", "rat_sub", "rat_div", "rat_normalize", "dot", "dot_term"}:
            self.rational_observation(output["value"])
        if operation in {"column_start", "eliminate", "vector_sub", "basis_commit"}:
            vector = output["vector"]
            self.maxima["vector_terms"] = max(self.maxima["vector_terms"], len(vector))
            for _, coefficient in vector:
                self.rational_observation(coefficient)
        if operation == "column_start":
            self.rational_observation(output["rational_zero"])
        if operation == "eliminate":
            self.rational_observation(output["factor"])
        if operation == "basis_entry":
            self.rational_observation(output["entry"][1])
        if operation == "clear_entry":
            self.maxima["cleared_coefficient_bits"] = max(
                self.maxima["cleared_coefficient_bits"], output["coefficient"].bit_length())
        if operation == "evaluate":
            self.rational_observation(output["rational"])
            self.maxima["source_value_bits"] = max(self.maxima["source_value_bits"], output["value"].bit_length())
        if operation == "term_add":
            state = output["state"]
            self.maxima["state_terms"] = max(self.maxima["state_terms"], len(state))
            for _, coefficient in state:
                self.maxima["state_coefficient_bits"] = max(
                    self.maxima["state_coefficient_bits"], coefficient.bit_length())

    def terminal_observation(self, value):
        self.maxima["terminal_integer_bits"] = max(
            self.maxima["terminal_integer_bits"], value.bit_length())

    def call(self, operation, inputs, body):
        row = self.event("start")
        need(self.started < CAP and operation in self.counts, "request cap or vocabulary")
        index = self.started
        self.started += 1
        self.counts[operation] += 1
        frame = Frame(index)
        self.stack.append(frame)
        self.maxima["pending_depth"] = max(self.maxima["pending_depth"], len(self.stack))
        same(row, {"kind": "work", "id": index, "operation": operation,
                   "inputs": inputs, "context": self.context}, "scheduled request")
        output = body(frame)
        dependencies = frame.explicit + frame.children
        need(all(type(index) is int and index in self.completed for index in dependencies),
             "dependency is not already complete")
        done = self.event("done")
        same(done, {"kind": "done", "id": index, "finish": len(self.completed),
                    "dependencies": dependencies, "output": output}, "local completion")
        need(self.stack[-1] is frame, "completion does not close the top frame")
        self.stack.pop()
        result = Completed(index, output, operation, inputs)
        self.completed[index] = result
        self.observe(operation, output)
        if self.stack:
            self.stack[-1].children.append(index)
        return result


def literal(value):
    return {"literal": value}


def referenced(reference):
    return {"ref": reference}


def rat_fields(raw):
    need(type(raw) in (list, tuple) and len(raw) == 2, "rational pair shape")
    numerator, denominator = raw
    integer(numerator, "rational numerator")
    integer(denominator, "rational denominator")
    need(denominator > 0, "rational denominator must be positive")
    # Coprimality follows from the checked construction history. No hidden gcd
    # is performed here or used as an extra semantic request.
    need(numerator != 0 or denominator == 1, "noncanonical rational zero")
    return numerator, denominator


class ExactArithmetic:
    def __init__(self, journal):
        self.j = journal

    def scalar(self, op, a, b=None):
        def body(frame):
            x = self.j.argument(frame, a)
            y = self.j.argument(frame, b) if b is not None else None
            if op in {"neg", "abs"}:
                need(y is None, "unary scalar has a second operand")
                value = -x if op == "neg" else abs(x)
            else:
                need(y is not None, "binary scalar lacks its second operand")
                if op == "add":
                    value = x + y
                elif op == "sub":
                    value = x - y
                elif op == "mul":
                    value = x * y
                else:
                    need(op == "divmod" and y > 0, "divmod requires a positive divisor")
                    quotient, remainder = divmod(x, y)
                    value = [quotient, remainder]
            return {"value": value}
        return self.j.call("int_scalar", {"op": op, "a": a, "b": b}, body)

    def gcd_step(self, x_arg, y_arg):
        def body(frame):
            x = self.j.argument(frame, x_arg)
            y = self.j.argument(frame, y_arg)
            natural(x, "gcd x")
            natural(y, "gcd y")
            if y == 0:
                return {"terminal": True, "quotient": None, "remainder": None}
            quotient, remainder = divmod(x, y)
            return {"terminal": False, "quotient": quotient, "remainder": remainder}
        return self.j.call("gcd_step", {"x": x_arg, "y": y_arg}, body)

    def normalize(self, numerator, denominator):
        def body(frame):
            n_arg, d_arg = numerator, denominator
            n = self.j.argument(frame, n_arg)
            d = self.j.argument(frame, d_arg)
            need(d != 0, "zero normalization denominator")
            if d < 0:
                new_n = self.scalar("neg", n_arg)
                new_d = self.scalar("neg", d_arg)
                n_arg, d_arg = referenced(new_n.reference("value")), referenced(new_d.reference("value"))
                n, d = new_n.output["value"], new_d.output["value"]
            if n == 0:
                return {"value": [0, 1], "rule": "zero"}
            if d == 1:
                return {"value": [n, 1], "rule": "denominator_one"}
            magnitude = self.scalar("abs", n_arg)
            x_arg, y_arg = referenced(magnitude.reference("value")), d_arg
            while True:
                step = self.gcd_step(x_arg, y_arg)
                if step.output["terminal"]:
                    gcd_arg = x_arg
                    break
                x_arg, y_arg = y_arg, referenced(step.reference("remainder"))
            need(self.j.inspect_argument(gcd_arg) > 0, "normalization gcd is not positive")
            n_div = self.scalar("divmod", n_arg, gcd_arg)
            d_div = self.scalar("divmod", d_arg, gcd_arg)
            need(n_div.output["value"][1] == d_div.output["value"][1] == 0,
                 "normalization division is not exact")
            return {"value": [n_div.output["value"][0], d_div.output["value"][0]], "rule": "gcd"}
        return self.j.call("rat_normalize", {"numerator": numerator, "denominator": denominator}, body)

    def rational(self, op, left, right):
        def body(frame):
            a = rat_fields(self.j.use(frame, left))
            b = rat_fields(self.j.use(frame, right))
            an, ad = referenced(left + [0]), referenced(left + [1])
            bn, bd = referenced(right + [0]), referenced(right + [1])
            if op == "rat_mul":
                if a[0] == 0 or b[0] == 0:
                    return {"value": [0, 1], "rule": "zero"}
                if a == (1, 1):
                    return {"value": list(b), "rule": "left_unit"}
                if b == (1, 1):
                    return {"value": list(a), "rule": "right_unit"}
                n = self.scalar("mul", an, bn)
                d = self.scalar("mul", ad, bd)
            elif op == "rat_sub":
                if b[0] == 0:
                    return {"value": list(a), "rule": "right_zero"}
                if a == b:
                    return {"value": [0, 1], "rule": "equal"}
                if a[0] == 0:
                    negative = self.scalar("neg", bn)
                    return {"value": [negative.output["value"], b[1]], "rule": "left_zero"}
                if a[1] == b[1]:
                    n = self.scalar("sub", an, bn)
                    result = self.normalize(referenced(n.reference("value")), ad)
                    return {"value": result.output["value"], "rule": "equal_denominator"}
                first = self.scalar("mul", an, bd)
                second = self.scalar("mul", bn, ad)
                n = self.scalar("sub", referenced(first.reference("value")), referenced(second.reference("value")))
                d = self.scalar("mul", ad, bd)
            elif op == "rat_add":
                if b[0] == 0:
                    return {"value": list(a), "rule": "right_zero"}
                if a[0] == 0:
                    return {"value": list(b), "rule": "left_zero"}
                if a[1] == b[1]:
                    n = self.scalar("add", an, bn)
                    result = self.normalize(referenced(n.reference("value")), ad)
                    return {"value": result.output["value"], "rule": "equal_denominator"}
                first = self.scalar("mul", an, bd)
                second = self.scalar("mul", bn, ad)
                n = self.scalar("add", referenced(first.reference("value")), referenced(second.reference("value")))
                d = self.scalar("mul", ad, bd)
            else:
                need(op == "rat_div", "unknown rational operation")
                need(b[0] != 0, "zero rational divisor")
                if a[0] == 0:
                    return {"value": [0, 1], "rule": "zero"}
                if b == (1, 1):
                    return {"value": list(a), "rule": "unit_divisor"}
                if a == b:
                    return {"value": [1, 1], "rule": "equal"}
                n = self.scalar("mul", an, bd)
                d = self.scalar("mul", ad, bn)
            result = self.normalize(referenced(n.reference("value")), referenced(d.reference("value")))
            return {"value": result.output["value"], "rule": "general"}
        return self.j.call(op, {"a": left, "b": right}, body)



class GuardedController:
    """Unchanged internally checked source and signed-oracle local rules."""

    def __init__(self, source, journal):
        self.src, self.j = source, journal
        self.a = ExactArithmetic(journal)
        self.views = []
        self.validation = {}
        self.zero_validation = None
        self.validated_views = []
        self.zero_buckets = {}
        self.proofs = []

    def validate(self, node_id):
        def body(frame):
            natural(node_id, "selected source ID")
            if node_id in self.validation:
                self.j.cache_counts["validate"]["hits"] += 1
                prior = self.j.use_record(frame, self.validation[node_id].work_id)
                return dict(prior.output, cache_hit=True, prior=prior.work_id)
            self.j.cache_counts["validate"]["misses"] += 1
            raw = self.src.descriptor(node_id)
            kind, value = raw.get("kind"), None
            if kind == "constant":
                value = natural(raw.get("value"), "original constant")
                support, flat = 0, [0, 0, node_id]
            elif kind == "ite":
                variable = natural(raw.get("variable"), "original branch variable", VARIABLES)
                low = natural(raw.get("low"), "original low child", node_id)
                high = natural(raw.get("high"), "original high child", node_id)
                lo = self.validate(low)
                hi = self.validate(high)
                child_support = lo.output["support"] | hi.output["support"]
                need(child_support & ((1 << (variable + 1)) - 1) == 0,
                     "original branch violates strict variable order")
                support, flat = (1 << variable) | child_support, [0, 0, node_id]
            elif kind == "guard":
                positive = natural(raw.get("positive"), "original positive guard", MASK_LIMIT)
                negative = natural(raw.get("negative"), "original negative guard", MASK_LIMIT)
                need(positive | negative != 0 and positive & negative == 0,
                     "original guard is empty or contradictory")
                core = natural(raw.get("core"), "original guard core", node_id)
                child = self.validate(core)
                need(child.output["node_kind"] != "guard", "original guard has nested guard core")
                need((positive | negative) & child.output["support"] == 0,
                     "original guard overlaps core support")
                support = positive | negative | child.output["support"]
                flat = [positive, negative, core]
            else:
                raise Rejected("unknown selected source node kind")
            natural(support, "derived original support", MASK_LIMIT)
            if node_id == 0:
                need(kind == "constant" and value == 0, "designated zero is not constant zero")
            return {"node_kind": kind, "support": support, "flat": flat,
                    "value": value, "cache_hit": False, "prior": None}

        checked = self.j.call("validate", {"source_node_id": node_id}, body)
        if not checked.output["cache_hit"]:
            need(node_id not in self.validation, "source validation cache overwrite")
            self.validation[node_id] = checked
        return checked

    def cached_core(self, frame, core):
        natural(core, "cached bare core")
        need(core in self.validation, "use of unvalidated original core")
        return self.j.use_record(frame, self.validation[core].work_id)

    @staticmethod
    def support_from(view, validated):
        positive, negative, core = checked_view(view)
        info = validated.output
        need(validated.inputs["source_node_id"] == core, "view/core validation binding")
        need(info["node_kind"] != "guard", "view core is not bare")
        need((positive | negative) & info["support"] == 0, "view guard/core support overlap")
        return positive | negative | info["support"]

    def validate_views(self):
        self.j.set_context("validate")
        self.zero_validation = self.validate(0)
        for column, loaded in enumerate(self.views):
            value, ref = loaded.output["view"], loaded.reference("view")

            def body(frame, value=value, ref=ref):
                same(self.j.use(frame, ref), value, "original selected view binding")
                zero = self.j.use_record(frame, self.zero_validation.work_id)
                need(zero.output["node_kind"] == "constant" and zero.output["value"] == 0,
                     "initial zero validation")
                view = checked_view(value)
                core = self.validate(view[2])
                support = self.support_from(view, core)
                need(support & ~Y_MASK == 0, "selected view has support outside fixed Y")
                return {"view": list(view), "support": support, "inside_y": True}

            checked = self.j.call("view_validate", {
                "column": column, "view": value, "load": ref}, body)
            self.validated_views.append(checked)

    def term_compare(self, incoming, existing):
        def body(frame):
            left = checked_view(self.j.use(frame, incoming))
            right = checked_view(self.j.use(frame, existing))
            order = -1 if left < right else (1 if left > right else 0)
            return {"order": order}
        return self.j.call("term_compare", {"incoming": incoming, "existing": existing}, body)

    def term_add(self, accumulator, view, coefficient):
        def body(frame):
            old = [] if accumulator is None else self.j.use(frame, accumulator)
            incoming = list(checked_view(self.j.use(frame, view)))
            amount = integer(self.j.use(frame, coefficient), "incoming signed coefficient")
            if amount == 0:
                return {"state": list(old), "rule": "zero_coefficient"}
            if tuple(incoming) == ZERO_VIEW:
                return {"state": list(old), "rule": "zero_view"}
            for position in range(len(old)):
                comparison = self.term_compare(view, accumulator + [position, 0])
                order = comparison.output["order"]
                if order < 0:
                    return {"state": old[:position] + [[incoming, amount]] + old[position:],
                            "rule": "insert"}
                if order == 0:
                    added = self.a.scalar("add", referenced(accumulator + [position, 1]),
                                          referenced(coefficient))
                    total = added.output["value"]
                    middle = [] if total == 0 else [[incoming, total]]
                    return {"state": old[:position] + middle + old[position + 1:],
                            "rule": "cancel" if total == 0 else "combine"}
            return {"state": list(old) + [[incoming, amount]], "rule": "append"}

        return self.j.call("term_add", {
            "accumulator": accumulator, "view": view, "coefficient": coefficient}, body)

    def normalize(self, terms):
        def body(frame):
            for term in terms:
                self.j.use(frame, term["view"])
                self.j.use(frame, term["coefficient"])
            current, last = None, None
            for term in terms:
                last = self.term_add(current, term["view"], term["coefficient"])
                current = last.reference("state")
            return {"state": [] if last is None else last.output["state"]}
        return self.j.call("normalize", {"terms": terms}, body)

    def cache_term(self, current, cached):
        def body(frame):
            left, right = self.j.use(frame, current), self.j.use(frame, cached)
            # This charged request is the only full-term cache comparison.
            need(type(left) is list and len(left) == 2 and type(right) is list and len(right) == 2,
                 "cache term shape")
            left_view, right_view = checked_view(left[0]), checked_view(right[0])
            a = integer(left[1], "current cached coefficient")
            b = integer(right[1], "prior cached coefficient")
            return {"equal": left_view == right_view and a == b}
        return self.j.call("cache_term", {"current": current, "cached": cached}, body)

    def cache_candidate(self, state_ref, prior_state, prior_zero, prior_proof):
        def body(frame):
            current = self.j.use(frame, state_ref)
            cached = self.j.use(frame, prior_state)
            proof = self.j.use_record(frame, prior_zero)
            natural(prior_proof, "prior zero proof", len(self.proofs))
            need(self.proofs[prior_proof].work_id == prior_zero
                 and proof.output["outcome"] == "zero"
                 and proof.output["proof_id"] == prior_proof,
                 "cache entry is not a completed zero proof")
            if len(current) != len(cached):
                return {"equal": False}
            for position in range(len(current)):
                result = self.cache_term(state_ref + [position], prior_state + [position])
                if not result.output["equal"]:
                    return {"equal": False}
            return {"equal": True}
        return self.j.call("cache_candidate", {
            "state": state_ref, "prior_state": prior_state,
            "prior_zero": prior_zero, "prior_proof": prior_proof}, body)

    def state_lookup(self, state_ref):
        def body(frame):
            state = self.j.use(frame, state_ref)
            digest = hashlib.sha256(json.dumps(
                state, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
            for prior_state, prior_zero, prior_proof in self.zero_buckets.get(digest, []):
                result = self.cache_candidate(state_ref, prior_state, prior_zero, prior_proof)
                if result.output["equal"]:
                    self.j.cache_counts["zero_state"]["hits"] += 1
                    return {"hit": True, "prior": prior_zero,
                            "proof_id": prior_proof, "digest": digest}
            self.j.cache_counts["zero_state"]["misses"] += 1
            return {"hit": False, "prior": None, "proof_id": None, "digest": digest}
        return self.j.call("state_lookup", {"state": state_ref}, body)

    def view_support(self, view_ref):
        def body(frame):
            value = checked_view(self.j.use(frame, view_ref))
            core = self.cached_core(frame, value[2])
            return {"support": self.support_from(value, core)}
        return self.j.call("view_support", {"view": view_ref}, body)

    def support_join(self, before, term_support):
        def body(frame):
            a = natural(self.j.argument(frame, before), "accumulated support", MASK_LIMIT)
            b = natural(self.j.use(frame, term_support), "term support", MASK_LIMIT)
            return {"after": a | b}
        return self.j.call("support_join", {"before": before, "term_support": term_support}, body)

    def select_variable(self, support):
        def body(frame):
            value = natural(self.j.argument(frame, support), "selected support", MASK_LIMIT)
            variable = (value & -value).bit_length() - 1 if value else None
            return {"variable": variable}
        return self.j.call("select_variable", {"support": support}, body)

    def cofactor(self, view_ref, variable_ref, bit):
        def body(frame):
            value = checked_view(self.j.use(frame, view_ref))
            variable = natural(self.j.use(frame, variable_ref), "cofactor variable", VARIABLES)
            need(type(bit) is int and bit in (0, 1), "cofactor Boolean choice")
            positive, negative, core = value
            validated = self.cached_core(frame, core)
            self.j.use_record(frame, self.zero_validation.work_id)
            support = self.support_from(value, validated)
            need(support & ((1 << variable) - 1) == 0,
                 "cofactor is below a still-supported variable")
            selected_bit = 1 << variable
            if value == ZERO_VIEW:
                result, result_support, rule = ZERO_VIEW, 0, "zero"
            elif (positive | negative) & selected_bit:
                if bool(positive & selected_bit) == bool(bit):
                    result = positive & ~selected_bit, negative & ~selected_bit, core
                    result_support, rule = support & ~selected_bit, "guard_satisfied"
                else:
                    result, result_support, rule = ZERO_VIEW, 0, "guard_contradiction"
            elif support & selected_bit == 0:
                result, result_support, rule = value, support, "absent"
            else:
                descriptor = self.src.descriptor(core)
                need(descriptor["kind"] == "ite" and descriptor["variable"] == variable,
                     "cofactor does not select the original branch head")
                child_id = descriptor["high"] if bit else descriptor["low"]
                child = self.cached_core(frame, child_id)
                cp, cn, cc = checked_view(child.output["flat"])
                rp, rn = positive | cp, negative | cn
                result = ZERO_VIEW if (cp, cn, cc) == ZERO_VIEW or rp & rn else (rp, rn, cc)
                # The selected child's validated flat form already proves its
                # bare support. No implicit new-core cache read is needed.
                bare_support = child.output["support"] & ~(cp | cn)
                need((rp | rn) & bare_support == 0, "merged guard overlaps selected core")
                result_support = 0 if result == ZERO_VIEW else rp | rn | bare_support
                rule = "branch"
            need(result_support & ((1 << (variable + 1)) - 1) == 0,
                 "cofactor did not remove the selected variable")
            return {"view": list(result), "support": result_support, "rule": rule}

        return self.j.call("cofactor", {"view": view_ref, "variable": variable_ref, "bit": bit}, body)

    def branch(self, state_ref, variable_ref, bit):
        def body(frame):
            state = self.j.use(frame, state_ref)
            natural(self.j.use(frame, variable_ref), "branch variable", VARIABLES)
            cofactored = []
            # Every occurrence is restricted before any collection, including
            # occurrences that later cancel or share an identical flat view.
            for position in range(len(state)):
                cofactored.append(self.cofactor(state_ref + [position, 0], variable_ref, bit))
            terms = [{"view": value.reference("view"),
                      "coefficient": state_ref + [position, 1]}
                     for position, value in enumerate(cofactored)]
            normalized = self.normalize(terms)
            child = self.state(normalized.reference("state"))
            return {"child_state": normalized.output["state"], "child_ref": child.work_id,
                    "outcome": child.output["outcome"], "proof_id": child.output["proof_id"],
                    "assignment": child.output["assignment"],
                    "nonzero_value": child.output["nonzero_value"]}

        return self.j.call("branch", {"state": state_ref, "variable": variable_ref, "bit": bit}, body)

    def refute_lift(self, variable_ref, bit, branch_id):
        def body(frame):
            variable = natural(self.j.use(frame, variable_ref), "lift variable", VARIABLES)
            child = self.j.use_record(frame, branch_id)
            need(child.operation == "branch" and child.inputs["variable"] == variable_ref
                 and child.inputs["bit"] == bit and child.output["outcome"] == "refuted",
                 "refutation does not match the chosen branch")
            assignment = natural(child.output["assignment"], "child assignment", MASK_LIMIT)
            nonzero = integer(child.output["nonzero_value"], "child nonzero value")
            need(nonzero != 0 and type(bit) is int and bit in (0, 1), "invalid refutation lift")
            selected_bit = 1 << variable
            assignment = assignment | selected_bit if bit else assignment & ~selected_bit
            return {"assignment": assignment, "nonzero_value": nonzero}

        return self.j.call("refute_lift", {
            "variable": variable_ref, "bit": bit, "branch": branch_id}, body)

    def terminal_decide(self, state_ref, selection_ref, total):
        def body(frame):
            self.j.use(frame, state_ref)
            selection = self.j.use(frame, selection_ref)
            value = self.j.argument(frame, total)
            need(selection is None, "terminal decision has nonempty support")
            return {"zero": value == 0, "value": value}
        return self.j.call("terminal_decide", {
            "state": state_ref, "selection": selection_ref, "sum": total}, body)

    def state(self, normalization):
        publication = {}

        def zero_result(rule, children=(), cached_id=None):
            proof_id = len(self.proofs) if cached_id is None else cached_id
            for child in children:
                natural(child, "split child proof ID", proof_id)
            return {"outcome": "zero", "rule": rule, "proof_id": proof_id,
                    "proof_new": cached_id is None, "proof_children": list(children),
                    "assignment": None, "nonzero_value": None}

        def refuted_result(rule, assignment, value):
            natural(assignment, "state refutation assignment", MASK_LIMIT)
            need(integer(value, "state refutation value") != 0, "zero value is not a refutation")
            return {"outcome": "refuted", "rule": rule, "proof_id": None,
                    "proof_new": False, "proof_children": [],
                    "assignment": assignment, "nonzero_value": value}

        def body(frame):
            current = self.j.use(frame, normalization)
            need(len(current) <= 35, "normalized state exceeds the fixed original-column bound")
            lookup = self.state_lookup(normalization)
            if lookup.output["hit"]:
                return zero_result("cache", cached_id=lookup.output["proof_id"])
            publication["digest"] = lookup.output["digest"]
            support_arg = literal(0)
            for position in range(len(current)):
                support = self.view_support(normalization + [position, 0])
                joined = self.support_join(support_arg, support.reference("support"))
                support_arg = referenced(joined.reference("after"))
            selected = self.select_variable(support_arg)
            variable_ref = selected.reference("variable")
            if selected.output["variable"] is None:
                total = literal(0)
                for position in range(len(current)):
                    # Source-value origins remain explicit scalar arguments.
                    # Zero derived support ensures these bare cores are the
                    # validated constant descriptors, without new evaluation.
                    core_id = current[position][0][2]
                    need(core_id in self.validation, "terminal core lacks validation")
                    source_value = self.validation[core_id].reference("value")
                    product = self.a.scalar("mul", referenced(normalization + [position, 1]),
                                            referenced(source_value))
                    self.j.terminal_observation(product.output["value"])
                    added = self.a.scalar("add", total, referenced(product.reference("value")))
                    self.j.terminal_observation(added.output["value"])
                    total = referenced(added.reference("value"))
                decided = self.terminal_decide(normalization, variable_ref, total)
                if decided.output["zero"]:
                    return zero_result("terminal")
                return refuted_result("terminal", 0, decided.output["value"])
            false_branch = self.branch(normalization, variable_ref, 0)
            if false_branch.output["outcome"] == "refuted":
                lifted = self.refute_lift(variable_ref, 0, false_branch.work_id)
                return refuted_result("refuted_low", lifted.output["assignment"],
                                      lifted.output["nonzero_value"])
            true_branch = self.branch(normalization, variable_ref, 1)
            if true_branch.output["outcome"] == "refuted":
                lifted = self.refute_lift(variable_ref, 1, true_branch.work_id)
                return refuted_result("refuted_high", lifted.output["assignment"],
                                      lifted.output["nonzero_value"])
            need(false_branch.output["outcome"] == true_branch.output["outcome"] == "zero",
                 "split lacks two complete zero children")
            return zero_result("split", (false_branch.output["proof_id"], true_branch.output["proof_id"]))

        result = self.j.call("state", {"normalization": normalization}, body)
        if result.output["proof_new"]:
            same(result.output["proof_id"], len(self.proofs), "new proof completion order")
            self.proofs.append(result)
            self.zero_buckets.setdefault(publication["digest"], []).append(
                (normalization, result.work_id, result.output["proof_id"]))
            self.j.maxima["zero_cache_entries"] = len(self.proofs)
        return result



def vector_entry(value):
    need(type(value) is list and len(value) == 2, "sparse vector entry shape")
    column = natural(value[0], "original column", COLUMNS)
    coefficient = rat_fields(value[1])
    need(coefficient[0] != 0, "zero coefficient in sparse vector")
    return column, coefficient


class BasisController(GuardedController):
    """Exact sparse triangular basis schedule; no external matrix premises."""

    def __init__(self, source, journal):
        super().__init__(source, journal)
        self.basis_entries = []
        self.column_outcomes = []
        self.final_basis = None
        self.column_seed = None
        self.evaluation_buckets = {}
        self.source_evaluations = []

    def load(self):
        self.j.set_context("load")
        raw_views = self.src.sample["grouping"]["b_views"]
        for column in range(COLUMNS):
            raw = raw_views[column]

            def body(frame, column=column, raw=raw):
                need(type(raw_views) is list and len(raw_views) == COLUMNS, "fixed original view count")
                same(raw, raw_views[column], "original view position")
                return {"view": list(checked_view(raw))}

            self.views.append(self.j.call("view_load", {"column": column, "saved_view": raw}, body))

    def evaluation_candidate(self, view_ref, assignment_ref, prior_id):
        def body(frame):
            view = checked_view(self.j.use(frame, view_ref))
            assignment = natural(self.j.use(frame, assignment_ref), "evaluation assignment", MASK_LIMIT)
            prior = self.j.use_record(frame, prior_id)
            need(prior.operation == "evaluate" and not prior.output["cache_hit"],
                 "source cache refers to a missing evaluation or an alias")
            old_view = checked_view(self.j.value(prior.inputs["view"]))
            old_assignment = natural(self.j.value(prior.inputs["assignment"]), "cached assignment", MASK_LIMIT)
            return {"equal": view == old_view and assignment == old_assignment}
        return self.j.call("evaluation_candidate", {
            "view": view_ref, "assignment": assignment_ref, "prior": prior_id}, body)

    def evaluation_lookup(self, view_ref, assignment_ref):
        def body(frame):
            view = list(checked_view(self.j.use(frame, view_ref)))
            assignment = natural(self.j.use(frame, assignment_ref), "lookup assignment", MASK_LIMIT)
            digest = hashlib.sha256(json.dumps(
                [view, assignment], separators=(",", ":"), ensure_ascii=True).encode("ascii")).hexdigest()
            for prior in self.evaluation_buckets.get(digest, []):
                match = self.evaluation_candidate(view_ref, assignment_ref, prior.work_id)
                if match.output["equal"]:
                    return {"hit": True, "prior": prior.work_id, "digest": digest}
            return {"hit": False, "prior": None, "digest": digest}

        result = self.j.call("evaluation_lookup", {"view": view_ref, "assignment": assignment_ref}, body)
        # The decision is counted after lookup completion, even if its enclosing
        # miss evaluation subsequently reaches the cap before producing a value.
        self.j.cache_counts["source_evaluation"]["hits" if result.output["hit"] else "misses"] += 1
        return result

    def evaluate(self, view_ref, assignment_ref):
        publication = {}

        def body(frame):
            view = checked_view(self.j.use(frame, view_ref))
            assignment = natural(self.j.use(frame, assignment_ref), "source assignment", MASK_LIMIT)
            lookup = self.evaluation_lookup(view_ref, assignment_ref)
            if lookup.output["hit"]:
                prior = self.j.use_record(frame, lookup.output["prior"])
                value = natural(prior.output["value"], "previous exact source value")
                return {"value": value, "rational": [value, 1], "cache_hit": True,
                        "prior": prior.work_id, "rule": "cache", "child": None}
            publication["digest"] = lookup.output["digest"]
            positive, negative, core = view
            checked = self.cached_core(frame, core)
            self.support_from(view, checked)
            if assignment & positive != positive or assignment & negative != 0:
                value, rule, child_id = 0, "guard_zero", None
            elif checked.output["node_kind"] == "constant":
                value = natural(checked.output["value"], "validated constant value")
                rule, child_id = "constant", None
            else:
                descriptor = self.src.descriptor(core)
                need(checked.output["node_kind"] == descriptor["kind"] == "ite", "nonbare evaluation core")
                variable = natural(descriptor["variable"], "evaluated variable", VARIABLES)
                selected = descriptor["high"] if assignment & (1 << variable) else descriptor["low"]
                validated_child = self.cached_core(frame, selected)
                child = self.evaluate(validated_child.reference("flat"), assignment_ref)
                value, rule, child_id = child.output["value"], "branch", child.work_id
            return {"value": value, "rational": [value, 1], "cache_hit": False,
                    "prior": None, "rule": rule, "child": child_id}

        result = self.j.call("evaluate", {"view": view_ref, "assignment": assignment_ref}, body)
        if not result.output["cache_hit"]:
            self.source_evaluations.append(result)
            self.evaluation_buckets.setdefault(publication["digest"], []).append(result)
            self.j.maxima["source_evaluation_cache_entries"] = len(self.source_evaluations)
        return result

    def dot_term(self, entry_ref, assignment_ref, before_ref):
        def body(frame):
            column, _ = vector_entry(self.j.use(frame, entry_ref))
            natural(self.j.use(frame, assignment_ref), "dot assignment", MASK_LIMIT)
            rat_fields(self.j.use(frame, before_ref))
            # The original-column lookup occurs only after this request starts.
            validated = self.j.use_record(frame, self.validated_views[column].work_id)
            need(validated.inputs["column"] == column, "dot original-column origin")
            evaluated = self.evaluate(validated.reference("view"), assignment_ref)
            product = self.a.rational("rat_mul", entry_ref + [1], evaluated.reference("rational"))
            added = self.a.rational("rat_add", before_ref, product.reference("value"))
            return {"value": added.output["value"], "view_validation": validated.work_id,
                    "evaluation": evaluated.work_id, "product": product.reference("value"),
                    "sum": added.reference("value")}
        return self.j.call("dot_term", {
            "entry": entry_ref, "assignment": assignment_ref, "before": before_ref}, body)

    def dot(self, vector_ref, assignment_ref, zero_ref):
        def body(frame):
            vector = self.j.use(frame, vector_ref)
            natural(self.j.use(frame, assignment_ref), "dot-product assignment", MASK_LIMIT)
            same(list(rat_fields(self.j.use(frame, zero_ref))), [0, 1], "dot initial canonical zero")
            current = zero_ref
            for position in range(len(vector)):
                term = self.dot_term(vector_ref + [position], assignment_ref, current)
                current = term.reference("value")
            return {"value": list(rat_fields(self.j.value(current))), "last": current}
        return self.j.call("dot", {"vector": vector_ref, "assignment": assignment_ref, "zero": zero_ref}, body)

    def vector_merge(self, left_ref, right_ref, factor_ref, zero_ref, left_cursor, right_cursor):
        def body(frame):
            left = self.j.use(frame, left_ref)
            right = self.j.use(frame, right_ref)
            factor = rat_fields(self.j.use(frame, factor_ref))
            same(list(rat_fields(self.j.use(frame, zero_ref))), [0, 1], "merge zero origin")
            natural(left_cursor, "left merge cursor")
            natural(right_cursor, "right merge cursor")
            need(left_cursor <= len(left) and right_cursor <= len(right) and factor[0] != 0,
                 "merge cursors or nonzero factor")
            if left_cursor == len(left) and right_cursor == len(right):
                return {"terminal": True, "kind": "terminal", "entry": None,
                        "next_left": left_cursor, "next_right": right_cursor}
            l_entry = vector_entry(left[left_cursor]) if left_cursor < len(left) else None
            r_entry = vector_entry(right[right_cursor]) if right_cursor < len(right) else None
            if l_entry is not None and (r_entry is None or l_entry[0] < r_entry[0]):
                return {"terminal": False, "kind": "left_only",
                        "entry": [l_entry[0], list(l_entry[1])],
                        "next_left": left_cursor + 1, "next_right": right_cursor}
            product = self.a.rational("rat_mul", factor_ref, right_ref + [right_cursor, 1])
            if l_entry is not None and l_entry[0] == r_entry[0]:
                value = self.a.rational("rat_sub", left_ref + [left_cursor, 1], product.reference("value"))
                kind, next_left = "both", left_cursor + 1
            else:
                value = self.a.rational("rat_sub", zero_ref, product.reference("value"))
                kind, next_left = "right_only", left_cursor
            entry = None if value.output["value"][0] == 0 else [r_entry[0], value.output["value"]]
            return {"terminal": False, "kind": kind, "entry": entry,
                    "next_left": next_left, "next_right": right_cursor + 1}
        return self.j.call("vector_merge", {
            "left": left_ref, "right": right_ref, "factor": factor_ref, "zero": zero_ref,
            "left_cursor": left_cursor, "right_cursor": right_cursor}, body)

    def vector_sub(self, left_ref, factor_ref, right_ref, zero_ref):
        def body(frame):
            left = self.j.use(frame, left_ref)
            factor = rat_fields(self.j.use(frame, factor_ref))
            self.j.use(frame, right_ref)
            same(list(rat_fields(self.j.use(frame, zero_ref))), [0, 1], "vector-subtraction zero")
            if factor[0] == 0:
                return {"vector": list(left), "rule": "zero_factor"}
            result, left_cursor, right_cursor = [], 0, 0
            while True:
                step = self.vector_merge(left_ref, right_ref, factor_ref, zero_ref, left_cursor, right_cursor)
                if step.output["terminal"]:
                    break
                if step.output["entry"] is not None:
                    result.append(step.output["entry"])
                left_cursor, right_cursor = step.output["next_left"], step.output["next_right"]
            need(len(result) <= COLUMNS, "sparse vector exceeds original column universe")
            return {"vector": result, "rule": "merge"}
        return self.j.call("vector_sub", {
            "left": left_ref, "factor": factor_ref, "right": right_ref, "zero": zero_ref}, body)

    def column_start(self, column, previous):
        def body(frame):
            natural(column, "next original column", COLUMNS)
            need(column == len(self.column_outcomes), "column schedule skipped or repeated an outcome")
            if previous is None:
                need(column == 0, "only column zero lacks a predecessor")
            else:
                prior = self.j.use_record(frame, previous)
                need(prior.operation == "column_complete" and prior.output["column"] == column - 1,
                     "original column predecessor")
            return {"vector": [[column, [1, 1]]], "rational_zero": [0, 1], "integer_one": 1}
        return self.j.call("column_start", {"column": column, "previous_column": previous}, body)

    def eliminate(self, column, basis_index, residual_ref, basis_id):
        def body(frame):
            self.j.use(frame, residual_ref)
            basis = self.j.use_record(frame, basis_id)
            natural(basis_index, "next retained basis index", len(self.basis_entries))
            need(self.basis_entries[basis_index].work_id == basis_id
                 and basis.output["basis_index"] == basis_index
                 and basis.output["pivot_column"] < column,
                 "elimination did not use the next immutable earlier basis")
            zero = self.column_seed.reference("rational_zero")
            dot = self.dot(residual_ref, basis.reference("witness"), zero)
            update = self.vector_sub(residual_ref, dot.reference("value"), basis.reference("vector"), zero)
            return {"vector": update.output["vector"], "factor": dot.output["value"],
                    "dot": dot.work_id, "update": update.work_id, "triangular_prefix": basis_index + 1}
        return self.j.call("eliminate", {"column": column, "basis_index": basis_index,
                                          "residual": residual_ref, "basis_commit": basis_id}, body)

    def clear_entry(self, entry_ref, scale_ref):
        def body(frame):
            column, _ = vector_entry(self.j.use(frame, entry_ref))
            scale = integer(self.j.use(frame, scale_ref), "positive common denominator product")
            need(scale > 0, "clearing scale is not positive")
            division = self.a.scalar("divmod", referenced(scale_ref), referenced(entry_ref + [1, 1]))
            need(division.output["value"][1] == 0, "clearing denominator does not divide product")
            product = self.a.scalar("mul", referenced(entry_ref + [1, 0]),
                                    referenced(division.reference("value", 0)))
            coefficient = integer(product.output["value"], "cleared coefficient")
            need(coefficient != 0, "clearing lost a nonzero coefficient")
            return {"column": column, "coefficient": coefficient}
        return self.j.call("clear_entry", {"entry": entry_ref, "scale": scale_ref}, body)

    def clear_vector(self, column, vector_ref, one_ref):
        def body(frame):
            vector = self.j.use(frame, vector_ref)
            same(self.j.use(frame, one_ref), 1, "clearing integer-one origin")
            need(bool(vector), "residual lost its own original column")
            last_column, last_coefficient = vector_entry(vector[-1])
            need(last_column == column and last_coefficient == (1, 1),
                 "residual does not retain its unit original-column coefficient")
            scale_ref = one_ref
            for position in range(len(vector)):
                product = self.a.scalar("mul", referenced(scale_ref),
                                        referenced(vector_ref + [position, 1, 1]))
                scale_ref = product.reference("value")
            # scale_ref names a completed scalar, never this pending wrapper.
            scale = integer(self.j.value(scale_ref), "completed denominator product")
            need(scale > 0, "nonpositive clearing denominator product")
            cleared = [self.clear_entry(vector_ref + [position], scale_ref)
                       for position in range(len(vector))]
            entries = [[item.output["column"], item.output["coefficient"]] for item in cleared]
            target = cleared[-1].output["coefficient"]
            need(cleared[-1].output["column"] == column and target == scale,
                 "integer residual target is not its positive scale")
            return {"scale": scale, "entries": entries,
                    "entry_ids": [item.work_id for item in cleared], "target_coefficient": target}
        return self.j.call("clear_vector", {"column": column, "vector": vector_ref, "one": one_ref}, body)

    def origin_term(self, clear_entry_id):
        def body(frame):
            entry = self.j.use_record(frame, clear_entry_id)
            need(entry.operation == "clear_entry", "oracle term is not a completed clearing entry")
            column = natural(entry.output["column"], "oracle original column", COLUMNS)
            coefficient = integer(entry.output["coefficient"], "oracle signed coefficient")
            need(coefficient != 0, "zero oracle origin coefficient")
            # Selecting this original column is part of the charged origin step.
            validated = self.j.use_record(frame, self.validated_views[column].work_id)
            need(validated.inputs["column"] == column, "oracle original-view origin")
            return {"view_validation": validated.work_id, "view": validated.output["view"],
                    "coefficient": coefficient}
        return self.j.call("origin_term", {"clear_entry": clear_entry_id}, body)

    def oracle_bridge(self, column, cleared_id):
        def body(frame):
            cleared = self.j.use_record(frame, cleared_id)
            need(cleared.operation == "clear_vector" and cleared.inputs["column"] == column,
                 "oracle bridge references the wrong residual clearing")
            terms = []
            for entry_id in cleared.output["entry_ids"]:
                origin = self.origin_term(entry_id)
                terms.append({"view": origin.reference("view"), "coefficient": origin.reference("coefficient")})
            normalized = self.normalize(terms)
            root = self.state(normalized.reference("state"))
            return {"root_state": root.work_id, "normalization": normalized.reference("state"),
                    "outcome": root.output["outcome"], "proof_id": root.output["proof_id"],
                    "assignment": root.output["assignment"], "nonzero_value": root.output["nonzero_value"]}
        return self.j.call("oracle_bridge", {"column": column, "cleared": cleared_id}, body)

    def basis_entry(self, clear_entry_id, nonzero_ref):
        def body(frame):
            entry = self.j.use_record(frame, clear_entry_id)
            nonzero = integer(self.j.use(frame, nonzero_ref), "signed oracle residual value")
            need(entry.operation == "clear_entry" and nonzero != 0,
                 "basis normalization lacks a clearing entry or a nonzero witness")
            column = natural(entry.output["column"], "basis original column", COLUMNS)
            normalized = self.a.normalize(referenced(entry.reference("coefficient")), referenced(nonzero_ref))
            need(normalized.output["value"][0] != 0, "basis normalization discarded a nonzero entry")
            return {"entry": [column, normalized.output["value"]]}
        return self.j.call("basis_entry", {"clear_entry": clear_entry_id, "nonzero_value": nonzero_ref}, body)

    def basis_commit(self, basis_index, column, cleared_id, oracle_id):
        def body(frame):
            cleared = self.j.use_record(frame, cleared_id)
            oracle = self.j.use_record(frame, oracle_id)
            need(basis_index == len(self.basis_entries)
                 and cleared.operation == "clear_vector" and cleared.inputs["column"] == column
                 and oracle.operation == "oracle_bridge" and oracle.inputs == {"column": column, "cleared": cleared_id}
                 and oracle.output["outcome"] == "refuted", "basis commitment origins or order")
            scale = integer(cleared.output["scale"], "basis clearing scale")
            nonzero = integer(oracle.output["nonzero_value"], "basis oracle nonzero value")
            witness = natural(oracle.output["assignment"], "basis witness", MASK_LIMIT)
            need(scale > 0 and nonzero != 0 and witness & ~Y_MASK == 0,
                 "basis scale/sign/witness domain")
            entries = [self.basis_entry(entry_id, oracle.reference("nonzero_value"))
                       for entry_id in cleared.output["entry_ids"]]
            vector = [entry.output["entry"] for entry in entries]
            need(bool(vector) and vector_entry(vector[-1])[0] == column,
                 "new basis lost its original pivot column")
            return {"basis_index": basis_index, "pivot_column": column, "vector": vector,
                    "witness": witness, "nonzero_value": nonzero, "cleared": cleared_id, "oracle": oracle_id}
        result = self.j.call("basis_commit", {"basis_index": basis_index, "column": column,
                                               "cleared": cleared_id, "oracle": oracle_id}, body)
        self.basis_entries.append(result)
        return result

    def column_complete(self, column, cleared_id, oracle_id):
        def body(frame):
            cleared = self.j.use_record(frame, cleared_id)
            oracle = self.j.use_record(frame, oracle_id)
            need(column == len(self.column_outcomes)
                 and cleared.operation == "clear_vector" and cleared.inputs["column"] == column
                 and oracle.operation == "oracle_bridge" and oracle.inputs == {"column": column, "cleared": cleared_id},
                 "column completion is not its exact current residual oracle")
            if oracle.output["outcome"] == "zero":
                natural(oracle.output["proof_id"], "dependent-column zero proof", len(self.proofs))
                outcome, basis_id, proof_id = "dependent", None, oracle.output["proof_id"]
            else:
                need(oracle.output["outcome"] == "refuted", "incomplete oracle outcome")
                basis_index = len(self.basis_entries)
                self.j.set_context("columns", column, basis_index)
                committed = self.basis_commit(basis_index, column, cleared_id, oracle_id)
                self.j.set_context("columns", column)
                outcome, basis_id, proof_id = "independent", committed.work_id, None
            return {"column": column, "outcome": outcome, "cleared": cleared_id,
                    "oracle": oracle_id, "proof_id": proof_id, "basis_commit": basis_id}
        result = self.j.call("column_complete", {"column": column, "cleared": cleared_id, "oracle": oracle_id}, body)
        self.column_outcomes.append(result)
        return result

    def coverage_entry(self, column, outcome_id):
        def body(frame):
            outcome = self.j.use_record(frame, outcome_id)
            need(outcome.operation == "column_complete" and outcome.output["column"] == column
                 and self.column_outcomes[column].work_id == outcome_id,
                 "final coverage repeats, omits or changes an original column")
            return {"outcome": outcome.output["outcome"], "basis_commit": outcome.output["basis_commit"],
                    "proof_id": outcome.output["proof_id"]}
        return self.j.call("coverage_entry", {"column": column, "column_outcome": outcome_id}, body)

    def basis_finish(self):
        outcome_ids = [item.work_id for item in self.column_outcomes]
        basis_ids = [item.work_id for item in self.basis_entries]

        def body(frame):
            for index in outcome_ids:
                self.j.use_record(frame, index)
            for index in basis_ids:
                self.j.use_record(frame, index)
            need(len(outcome_ids) == COLUMNS, "final basis lacks all original column outcomes")
            independent, dependent = [], []
            for column in range(COLUMNS):
                checked = self.coverage_entry(column, outcome_ids[column])
                if checked.output["outcome"] == "independent":
                    independent.append(checked.output["basis_commit"])
                else:
                    need(checked.output["outcome"] == "dependent", "unknown completed column outcome")
                    dependent.append(column)
            same(independent, basis_ids, "final committed basis is exactly the independent outcomes")
            return {"dimension": len(self.basis_entries),
                    "pivot_columns": [item.output["pivot_column"] for item in self.basis_entries],
                    "dependent_columns": dependent, "columns_complete": COLUMNS}

        result = self.j.call("basis_finish", {"column_outcomes": outcome_ids, "basis_commits": basis_ids}, body)
        self.final_basis = result.output
        return result

    def run(self):
        self.load()
        self.validate_views()
        for column in range(COLUMNS):
            self.j.set_context("columns", column)
            previous = self.column_outcomes[-1].work_id if self.column_outcomes else None
            self.column_seed = self.column_start(column, previous)
            residual = self.column_seed.reference("vector")
            # The retained list is immutable during this column's eliminations.
            for basis_index, basis in enumerate(self.basis_entries):
                self.j.set_context("columns", column, basis_index)
                result = self.eliminate(column, basis_index, residual, basis.work_id)
                residual = result.reference("vector")
            self.j.set_context("columns", column)
            cleared = self.clear_vector(column, residual, self.column_seed.reference("integer_one"))
            oracle = self.oracle_bridge(column, cleared.work_id)
            self.column_complete(column, cleared.work_id, oracle.work_id)
        self.j.set_context("finish")
        self.basis_finish()


def verify_header(journal, source):
    """Compare source identities as bytes; never import their implementations."""
    base = Path(__file__).resolve().parent.parent
    policy_paths = {
        "program": base / "diagnostics" / "produce_basis.py",
        "protocol": base / "PROTOCOL.md",
        "design": base / "DESIGN.md",
        "schema": base / "schema.json",
        "inherited_protocol": base / "inherited" / "PROTOCOL.md",
        "inherited_producer": base / "inherited" / "produce_relations.py",
        "inherited_replayer": base / "inherited" / "replay_relations.py",
    }
    fixed_hashes = {
        "program": PROGRAM_SHA, "protocol": PROTOCOL_SHA,
        "design": DESIGN_SHA, "schema": SCHEMA_SHA,
        "inherited_protocol": BASE_PROTOCOL_SHA,
        "inherited_producer": BASE_PRODUCER_SHA,
        "inherited_replayer": BASE_REPLAYER_SHA,
    }
    policies = {name: binding(path) for name, path in policy_paths.items()}
    for name, expected in fixed_hashes.items():
        same(policies[name]["sha256"], expected, "fixed " + name + " snapshot")
    header = journal.header
    need(set(header) == {"kind", "version", "input_bindings", "policy_bindings", "limits"},
         "header field set")
    same(header["kind"], "header", "header kind")
    same(header["version"], "exact-guarded-basis-v1", "header version")
    for group, expected in (("input_bindings", {"trace": source.trace_binding, "sample": source.sample_binding}),
                            ("policy_bindings", policies)):
        observed = header[group]
        need(type(observed) is dict and set(observed) == set(expected), group + " fields")
        for name, actual in expected.items():
            item = observed[name]
            need(type(item) is dict and set(item) == {"path", "bytes", "sha256"}, "byte-binding shape")
            need(type(item["path"]) is str and Path(item["path"]).is_absolute(), "snapshot path metadata")
            natural(item["bytes"], "snapshot byte length")
            same(item["bytes"], actual["bytes"], group + "." + name + " bytes")
            same(item["sha256"], actual["sha256"], group + "." + name + " SHA256")
    same(header["limits"], {"charged_request_cap": CAP, "wall_seconds": 30,
                            "cpu_seconds": 30, "cpu_count": 1,
                            "address_space_bytes": 1073741824}, "fixed diagnostic limits")
    return policies


def verify_footer(journal, controller, footer, completed, location):
    if completed:
        need(not journal.stack and len(journal.completed) == journal.started
             and len(controller.column_outcomes) == COLUMNS and controller.final_basis is not None,
             "completed footer lacks the whole fixed basis schedule and final coverage")
        status, error = "completed_exact_basis", None
    else:
        need(location == "start" and journal.started == CAP,
             "request-cap footer does not precede exactly request 50001")
        status = "request_cap"
        error = {"type": "LimitReached", "message": "charged request cap 50000 reached before next request"}
    expected = {
        "kind": "footer", "status": status, "charged_starts": journal.started,
        "completed_requests": len(journal.completed),
        "pending_stack": [frame.work_id for frame in journal.stack],
        "physical_records": journal.lines,
        "operation_counts": journal.counts, "cache_counts": journal.cache_counts,
        "phase": journal.context,
        "completed_columns": [item.output for item in controller.column_outcomes],
        "basis_commits": [item.output for item in controller.basis_entries],
        "final_basis": controller.final_basis,
        "maxima": journal.maxima, "error": error,
    }
    same(footer, expected, "complete accounting footer")
    need(journal.stream.read() == "", "trailing records after footer")
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--sample", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    began = time.monotonic()
    journal = controller = source = None
    report = {"status": "rejected", "qualification": "No identity, basis dimension or count claim is accepted."}
    exit_code = 1
    try:
        source = RawInputs(args.trace, args.sample)
        journal = Journal(args.certificate)
        policies = verify_header(journal, source)
        controller = BasisController(source, journal)
        try:
            controller.run()
        except EndOfPrefix as prefix:
            producer_status = verify_footer(journal, controller, prefix.footer, False, prefix.location)
        else:
            producer_status = verify_footer(journal, controller, journal.read(), True, None)
        report = {
            "status": "passed",
            "qualification": (
                "The fixed exact transcript is independently checked. Completed dependent columns carry "
                "global signed identities over the original guarded descriptors; completed basis commits "
                "carry source-bound triangular independence witnesses. Only a completed basis_finish "
                "with all 35 column outcomes establishes spanning and the final rational function-space "
                "dimension. A cap prefix makes no spanning claim for unfinished columns. This is "
                "diagnostic evidence, not a Lean rank theorem, queens count, or n16 result."),
            "producer_status": producer_status,
            "charged_starts": journal.started,
            "completed_requests": len(journal.completed),
            "pending_requests": [frame.work_id for frame in journal.stack],
            "physical_records": journal.lines,
            "operation_counts": journal.counts,
            "cache_counts": journal.cache_counts,
            "phase": journal.context,
            "completed_columns": [item.output for item in controller.column_outcomes],
            "basis_commits": [item.output for item in controller.basis_entries],
            "final_basis": controller.final_basis,
            "new_zero_proofs": len(controller.proofs),
            "completed_source_evaluations": len(controller.source_evaluations),
            "validated_original_nodes": len(controller.validation),
            "maxima": journal.maxima,
            "input_bindings": {"trace": source.trace_binding, "sample": source.sample_binding,
                               "certificate": binding(args.certificate)},
            "policy_bindings": policies,
            "replayer": binding(Path(__file__).resolve()),
            "source_preparation": {"parsed_records": source.parsed_records,
                                   "semantic_processing_before_tickets": False},
            "checks": {
                "empty_initial_basis_and_fixed_original_column_order": True,
                "exact_current_residual_chain": True,
                "constituent_source_evaluations_and_cache_comparisons_charged": True,
                "exact_scalar_and_rational_arithmetic": True,
                "positive_denominator_clearing_and_signed_c_over_z": True,
                "immutable_triangular_basis_and_completion_only_publication": True,
                "final_coverage_only_after_all_original_columns": True,
                "selected_original_descriptors_validated": len(controller.validated_views) == COLUMNS,
                "no_producer_or_evaluator_import": True,
                "exact_occurrence_collection_and_full_view_cache": True,
                "completed_dependencies_and_proof_children": True,
                "pending_results_never_published": True,
                "every_started_record_accounted": True,
                "sample_values_ranks_and_old_counterexamples_unused": True,
                "no_new_sample_pool_or_board_count": True,
            },
        }
        exit_code = 0
    except Exception as error:
        report.update({"error": {"type": type(error).__name__, "message": str(error)},
                       "qualification": (
                           "Replay did not accept the whole transcript or a completely framed cap prefix. "
                           "The retained bytes are failure evidence, not an accepted identity, basis "
                           "dimension or count claim.")})
        if journal is not None:
            report.update({"charged_starts": journal.started,
                           "completed_requests": len(journal.completed),
                           "pending_requests": [frame.work_id for frame in journal.stack],
                           "physical_records": journal.lines})
    finally:
        if journal is not None:
            journal.stream.close()
    report["seconds"] = time.monotonic() - began
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

