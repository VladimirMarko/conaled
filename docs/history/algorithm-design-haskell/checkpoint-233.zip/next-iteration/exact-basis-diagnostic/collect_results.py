#!/usr/bin/env python3
"""Extract existing exact-basis run metadata; performs no function or algebra evaluation."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def binding(path: Path) -> dict:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": digest}


def require_same_bytes(recorded: dict, actual: dict, label: str) -> None:
    if any(recorded.get(key) != actual[key] for key in ("bytes", "sha256")):
        raise ValueError("Recorded byte binding differs: " + label)


def unique_suffix(entries: list, field: str, suffix: str) -> dict:
    selected = [entry for entry in entries if entry.get(field, "").endswith(suffix)]
    if len(selected) != 1:
        raise ValueError("Expected one binding for " + suffix)
    return selected[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--producer-report", type=Path, required=True)
    parser.add_argument("--replay-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    producer_path = args.producer_report.resolve(strict=True)
    replay_path = args.replay_report.resolve(strict=True)
    producer = json.loads(producer_path.read_text())
    replay = json.loads(replay_path.read_text())
    if producer["status"] not in ("passed", "capped_prefix"):
        raise ValueError("Producer did not report a completed run or preserved cap prefix")
    if replay["status"] != "passed":
        raise ValueError("Independent replay was not accepted")
    for report in (producer, replay):
        for field in ("source_hashes_unchanged", "input_hashes_unchanged",
                      "source_bindings_complete", "input_bindings_complete"):
            if report.get(field) is not True:
                raise ValueError("Incomplete or changed run binding: " + field)

    transcript = producer_path.parent / "work.jsonl"
    checked_path = replay_path.parent / "replay-report.json"
    checked = json.loads(checked_path.read_text())
    if checked.get("status") != "passed":
        raise ValueError("Replay result does not report acceptance")
    transcript_binding, checked_binding = binding(transcript), binding(checked_path)
    require_same_bytes(unique_suffix(producer["artifacts"], "path", "/work.jsonl"),
                       transcript_binding, "producer output")
    certificate_input = unique_suffix(replay["inputs"], "snapshot", "/input/certificate.jsonl")
    require_same_bytes(certificate_input, transcript_binding, "replay certificate input")
    if certificate_input.get("snapshot_sha256") != transcript_binding["sha256"]:
        raise ValueError("Replay certificate snapshot differs")
    require_same_bytes(unique_suffix(replay["artifacts"], "path", "/replay-report.json"),
                       checked_binding, "bounded replay result")
    require_same_bytes(checked["input_bindings"]["certificate"], transcript_binding,
                       "replayer's checked certificate")
    completed = {}
    phase_counts = {}
    operation_counts = {}
    header = footer = None
    physical_records = 0
    with transcript.open() as stream:
        for line in stream:
            record = json.loads(line)
            physical_records += 1
            if record["kind"] == "header":
                if header is not None:
                    raise ValueError("Duplicate transcript header")
                header = record
            elif record["kind"] == "work":
                phase = record["context"]["phase"]
                phase_counts[phase] = phase_counts.get(phase, 0) + 1
                operation = record["operation"]
                operation_counts[operation] = operation_counts.get(operation, 0) + 1
            elif record["kind"] == "done":
                completed[record["id"]] = record["output"]
            elif record["kind"] == "footer":
                if footer is not None:
                    raise ValueError("Duplicate transcript footer")
                footer = record
            else:
                raise ValueError("Unknown physical record kind")
    if header is None or footer is None:
        raise ValueError("Complete envelope required for this metadata extractor")
    if checked["producer_status"] != footer["status"]:
        raise ValueError("Replay producer status differs from the summarized footer")
    if physical_records != footer["physical_records"]:
        raise ValueError("Physical record count differs")
    if len(completed) != footer["completed_requests"]:
        raise ValueError("Completed record count differs")
    if sum(phase_counts.values()) != footer["charged_starts"]:
        raise ValueError("Charged record count differs")
    if any(footer["operation_counts"].get(key) != value
           for key, value in operation_counts.items()):
        raise ValueError("Operation record counts differ")

    outcomes = []
    for item in footer["completed_columns"]:
        cleared = completed[item["cleared"]]
        oracle = completed[item["oracle"]]
        outcomes.append({"column": item["column"], "outcome": item["outcome"],
                         "positive_scale": cleared["scale"],
                         "integer_original_column_coefficients": cleared["entries"],
                         "root_state": oracle["root_state"],
                         "proof_id": item["proof_id"],
                         "basis_commit": item["basis_commit"]})
    final_basis = footer["final_basis"]
    if (footer["status"] == "completed_exact_basis") != (final_basis is not None):
        raise ValueError("Completion status and final basis metadata disagree")
    if final_basis is not None and final_basis["columns_complete"] != 35:
        raise ValueError("Final basis lacks complete column coverage")

    result = {
        "kind": "exact-basis-metadata-extraction-v1",
        "scope": "Extraction of already produced and independently replayed records only; no new source evaluation, algebra, rank computation, semantic replay or Lean execution.",
        "producer_status": footer["status"],
        "replay_status": checked["status"],
        "replay_qualification": checked.get("qualification"),
        "charged_starts": footer["charged_starts"],
        "completed_requests": footer["completed_requests"],
        "pending_stack": footer["pending_stack"],
        "physical_records": physical_records,
        "phase_counts": phase_counts,
        "operation_counts": footer["operation_counts"],
        "cache_counts": footer["cache_counts"],
        "maxima": footer["maxima"],
        "completed_columns": outcomes,
        "basis_commits": footer["basis_commits"],
        "final_basis": final_basis,
        "error": footer["error"],
        "timings": {"producer_seconds": producer.get("seconds"),
                    "producer_peak_rss_kib": producer.get("peak_rss_kib"),
                    "replay_seconds": replay.get("seconds"),
                    "replay_peak_rss_kib": replay.get("peak_rss_kib")},
        "bindings": [binding(path) for path in
                     (Path(__file__).resolve(), producer_path, replay_path,
                      transcript, checked_path)],
        "formal_evidence": False,
        "source_count_computed": False,
    }
    with args.output.open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": binding(args.output.resolve()),
                      "producer_status": result["producer_status"],
                      "completed_columns": len(outcomes),
                      "committed_basis_entries": len(result["basis_commits"]),
                      "final_basis": final_basis}, sort_keys=True))


if __name__ == "__main__":
    main()
