# Concrete certification of the four global identities

## Recommendation

Proceed with a narrowly scoped ordinary-Lean certificate for the four original-function identities, together with a generic weighted-rewrite law. The completed trace has a small reusable zero-proof closure. It does not require formalizing the rational basis search, its source evaluations, or the diagnostic dimension-31 independence argument. A cumulative 30-second, one-CPU, 1-GiB fresh gate is a credible target for this component, but no Lean timing has been measured and success within that bound is not established.

The four natural-valued theorem statements should be:

```
B0 + B3   = B1 + B2
B6 + B9   = B7 + B8
B11 + B14 = B12 + B13
B17 + B20 = B18 + B19
```

These are function equalities over all Boolean assignments, with each B defined by the exact original guarded descriptors and selected view. They certify four concrete rewrites. They do not certify a queens count, the completed counting factor plan, or an exact Lean rank of 31.

## Measured certificate size, from recorded metadata only

The following counts follow completed `proof_children`, completed dependency IDs, and previously recorded state/descriptor fields. No source evaluation, cofactor computation, PIT, rational elimination or new identity test was performed for this assessment.

| Dependent column | Root WorkID / ProofID | Zero-proof ancestors | Original source descriptors |
|---|---|---:|---:|
| 3 | 3326 / 134 | 131 | 286 |
| 9 | 10353 / 216 | 94 | 380 |
| 14 | 15429 / 289 | 127 | 252 |
| 20 | 20722 / 343 | 78 | 302 |

The union has **332 published zero-proof nodes: 331 splits and one shared empty terminal**. Every recorded goal has at most four terms; all coefficients in this closure are exactly +1 or -1. There are 909 distinct full views in those goals. The sixteen selected original columns require **866 source descriptors: three constants, 449 ite nodes and 414 guards**, with original IDs between 0 and 42331.

The split closure contains 662 branch edges and 2,382 recorded cofactor calls: 1,436 head branches, 443 satisfied guards, 443 contradicted guards and 60 absent-variable cases. Recorded collection uses only zero-view deletion, insertion/permutation and cancellation. No nonunit merge or nonempty terminal arithmetic is needed in this closure.

Blindly retaining all WorkID ancestors would pull in 23,053 requests, because discovery history includes previous columns, rational coefficients and evaluations. The four root statements already fix their integer coefficients and positive scale 1. A new Lean certificate can check those four literal statements directly against the smaller semantic DAG; the discovery transcript is provenance, not a theorem premise.

## Minimal proof architecture

1. **Direct guarded-source semantics.** Add a small internally interpreted const/ite/guard descriptor type. Reuse the strong-induction pattern of `LazyNodeSemantics`, leaving that accepted file unchanged: it currently supports const/branch/sum/product and has no guard constructor. Interpret a view as its cube indicator times the meaning of its bare core. Prove source unfolding, finite support, and view cofactor laws from checked descriptor validity. Guard bits need not precede the core's top variable, so converting a guard to an ordered branch prefix without a proof is unsafe.

2. **The four-root local certificate.** Interpret each recorded signed state with `SignedRelations.combine`. The existing `combine_restrict`, `combine_perm`, `combine_cancel`, `combine_zero_coefficient`, `combine_transport`, `zero_split` and `earlier_dag_sound` provide the required algebra. Add only the checked source-cofactor/collection bridge. Each branch checks every input occurrence, deletes a proved zero view, preserves multiplicities, and compares the collected state with the exact earlier child goal. The shared terminal is literally the empty state. Source constants still need exact interpretation, but a general constant-terminal arithmetic certificate is unnecessary here.

3. **Concrete data and roots.** Extract the 866-descriptor closure, sixteen original view bindings and 332 proof nodes from the frozen inputs. Use prior proof IDs in completion order, with checked root mapping; WorkIDs are not proof indices. Emit named local proof applications or small separately checked records, so earlier proofs are referenced directly. Avoid repeated linear lookups through a 42,332-slot sparse source table or a monolithic replay of all discovery requests. If descriptors are densely indexed, preserve original IDs and check every old-child/new-position correspondence and each selected B mapping.

The source-data boundary must remain explicit. A file hash is provenance, not a Lean premise. The emitted literals must contain the exact original fields, and the theorem must use their internal interpretation. A selected closed subtable is sufficient for these roots; a generic closure-agreement lemma can later transfer it to any larger table agreeing at those original IDs. Connecting that larger table and the 35 cut groups back to the counting computation remains a separate checked bridge. Do not present a function with an arbitrary supplied Weight meaning as the original source.

Required local obligations include strict earlier source references; exact zeroNode=constant0; disjoint positive/negative masks; guard/core support disjointness; exact child support/order; contradiction versus satisfied-guard behavior; absent-variable independence; and all reordering/cancellation occurrences. Boolean splitting proves a pointwise equality and introduces no factor 2. Summing an absent variable later still requires its usual multiplicity.

The final fresh gate should include all new generic bodies and concrete data, print the axioms of the four root theorems, and retain the unchanged deadline on failure. An independent dependency audit should follow the roots through the internal source interpretation, original-view binding, cofactor/collection laws and Boolean split proof. If staging is useful, column 20 has the smallest proof closure (78 nodes); the acceptance milestone should still be all four roots in the single fixed fresh gate.

## How signed rewrites enter counting

For one block write the identity as `Bp + Bd = Bq + Br`, with original natural-valued left weights Gp,Gq,Gr,Gd. Over Int-valued functions it gives

```
Gp*Bp + Gq*Bq + Gr*Br + Gd*Bd
  = (Gp-Gd)*Bp + (Gq+Gd)*Bq + (Gr+Gd)*Br.
```

This removes Bd without denominators. The four blocks have disjoint column sets, so the formal separated expression can use the remaining 31 original B functions. The coefficient Gp-Gd can be negative; replacing it with truncated Nat subtraction is unsound without an additional pointwise dominance proof. No such dominance was tested or established here.

The practical route is an Int-valued contraction layer with a proved natural-to-integer lift for products, signed linearity of finite projection, and equality to the original natural-valued factor sum. Existing `SignedRelations.lift_sumVars` and `nat_projection_eq` supply part of the final transfer; lift/product and signed multiplication/linearity laws remain small missing lemmas. Nonnegativity of the complete result follows from equality to the original natural function, not from nonnegative intermediate terms.

A subtraction-free alternative is the balanced Nat identity

```
original_four_term_sum + Gd*Bp
  = Gp*Bp + (Gq+Gd)*Bq + (Gr+Gd)*Br.
```

Multiplication by outside factors and finite summation preserve this equality. It is useful for checking a compensated computation, but introduces an extra product and does not itself demonstrate a faster counter.

The four identities justify a reduction from 35 separated terms to 31 at this cut. They do not establish a wall-time or descriptor reduction: signed left coefficients can become more complicated. A later bounded counting integration must measure the complete rewrite and contraction cost while preserving outside-factor occurrences and variable coverage. No new counter or integration experiment is proposed as already authorized by this assessment.

## Exact assessment inputs

- `RESULTS.json`: SHA256 `59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb`.
- `attempts/basis-01/work.jsonl`: SHA256 `52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6`.
- `attempts/basis-replay-01/replay-report.json`: SHA256 `48cf7f62c41be1c64ff34e01e7235e08c29553fda08576a9ba7e18ba16e11d9b`.
- `../signed-relation-laws/SignedRelations.lean`: SHA256 `2fb5d47a1b5a12fbebf55cea3485c7b44183026aecfa33a76b143bf70f8736ec`.
- `../lazy-node-semantics/LazyNodeSemantics.lean`: SHA256 `f910ab1b20c8777d6ba7b6e2312c28140a1c41af0f1d09b0b634c5b36a8632ce`.

This is one current assessment. No new Lean component, semantic computation or historical-copy chain was created.
