#!/usr/bin/env python3
"""Untrusted, explicitly metered empty-basis construction over original guarded functions.

This program has not been executed during implementation.  It proves no Lean
theorem and uses no expected queens count.  A separate implementation replays
its local arithmetic, source and relation records.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import time


VERSION = "exact-guarded-basis-v1"
CAP, VARIABLES, COLS = 50_000, 210, 35
ZERO = [0, 0, 0]
Y = [171, 174, 175, 177, 186, 187, 189, 191, 192, 193, 195, 200, 202, 203, 206, 208]
Y_MASK = sum(1 << v for v in Y)
SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
SAMPLE_SHA = "ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2"
KINDS = ['view_load', 'validate', 'view_validate', 'int_scalar', 'rat_mul', 'rat_sub', 'rat_div', 'rat_normalize', 'gcd_step', 'normalize', 'term_add', 'term_compare', 'state', 'state_lookup', 'cache_candidate', 'cache_term', 'view_support', 'support_join', 'select_variable', 'branch', 'cofactor', 'terminal_decide', 'refute_lift', 'column_start', 'eliminate', 'rat_add', 'dot', 'dot_term', 'evaluate', 'evaluation_lookup', 'evaluation_candidate', 'vector_sub', 'vector_merge', 'clear_vector', 'clear_entry', 'oracle_bridge', 'origin_term', 'column_complete', 'basis_commit', 'basis_entry', 'basis_finish', 'coverage_entry']
MAXIMA = ['numerator_bits', 'denominator_bits', 'vector_terms', 'cleared_coefficient_bits', 'state_coefficient_bits', 'state_terms', 'source_value_bits', 'terminal_integer_bits', 'pending_depth', 'zero_cache_entries', 'source_evaluation_cache_entries']


class LimitReached(RuntimeError):
    pass


class FixtureRejected(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise FixtureRejected(message)


def integer(value):
    require(type(value) is int, "expected an integer")
    return value


def natural(value):
    require(integer(value) >= 0, "expected a natural number")
    return value


def binding(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def ref(ticket, field, *indices):
    return [ticket, field, *indices]


def ra(reference):
    return {"ref": reference}


def lit(value):
    return {"literal": value}


def arg_ids(*args):
    return [a["ref"][0] for a in args if a is not None and "ref" in a]


class Meter:
    def __init__(self, stream):
        self.stream = stream
        self.charged = self.completed = self.physical = 0
        self.stack = []
        self.outputs = {}
        self.counts = dict.fromkeys(KINDS, 0)
        self.cache_counts = {k: {"hits": 0, "misses": 0} for k in ("validate", "zero_state", "source_evaluation")}
        self.context = {"phase": "load", "column": None, "basis_index": None}
        self.maxima = dict.fromkeys(MAXIMA, 0)

    def write(self, record):
        self.stream.write(json.dumps(record, separators=(",", ":"), ensure_ascii=True) + "\n")
        self.stream.flush()
        self.physical += 1

    def begin(self, operation, inputs):
        if self.charged == CAP:
            raise LimitReached("charged request cap 50000 reached before next request")
        require(operation in self.counts, "unknown request kind")
        ticket = self.charged
        self.charged += 1
        self.counts[operation] += 1
        self.stack.append({"id": ticket, "children": []})
        self.maxima["pending_depth"] = max(self.maxima["pending_depth"], len(self.stack))
        self.write({"kind": "work", "id": ticket, "operation": operation,
                    "inputs": inputs, "context": dict(self.context)})
        return ticket

    def finish(self, ticket, output, explicit=()):
        require(self.stack and self.stack[-1]["id"] == ticket, "non-nested completion")
        dependencies = list(explicit) + self.stack[-1]["children"]
        require(all(i in self.outputs for i in dependencies), "unfinished dependency")
        self.write({"kind": "done", "id": ticket, "finish": self.completed,
                    "dependencies": dependencies, "output": output})
        self.stack.pop()
        self.outputs[ticket] = output
        self.completed += 1
        if self.stack:
            self.stack[-1]["children"].append(ticket)
        return ticket

    def get(self, reference):
        require(type(reference) is list and len(reference) >= 2, "malformed reference")
        ticket, field, *indices = reference
        require(type(ticket) is int and ticket in self.outputs and type(field) is str,
                "reference is not to completed output")
        value = self.outputs[ticket][field]
        for index in indices:
            natural(index)
            require(type(value) is list and index < len(value), "reference selector out of bounds")
            value = value[index]
        return value

    def arg(self, argument):
        require(type(argument) is dict, "malformed integer argument")
        if set(argument) == {"literal"}:
            return integer(argument["literal"])
        require(set(argument) == {"ref"}, "malformed integer argument fields")
        return integer(self.get(argument["ref"]))

    def rational(self, reference):
        value = self.get(reference)
        require(type(value) is list and len(value) == 2, "malformed rational")
        integer(value[0])
        require(natural(value[1]) > 0, "nonpositive rational denominator")
        return value

    def rational_max(self, value):
        self.maxima["numerator_bits"] = max(self.maxima["numerator_bits"], value[0].bit_length())
        self.maxima["denominator_bits"] = max(self.maxima["denominator_bits"], value[1].bit_length())

    def count_cache(self, name, hit):
        self.cache_counts[name]["hits" if hit else "misses"] += 1


def prepare(trace_path, sample_path):
    """Bytes and raw index only.  No support, rational, cofactor or identity work."""
    started = time.monotonic()
    tb, sb = binding(trace_path), binding(sample_path)
    require(tb["sha256"] == SOURCE_SHA and sb["sha256"] == SAMPLE_SHA, "fixed input hash differs")
    raw = defaultdict(list)
    records = 0
    with trace_path.open() as stream:
        for line in stream:
            record = json.loads(line)
            records += 1
            if record.get("type") == "node":
                raw[record.get("id")].append(record)
    sample = json.loads(sample_path.read_text())
    return raw, sample, {"trace": tb, "sample": sb}, {
        "seconds": time.monotonic() - started, "raw_records": records,
        "semantic_processing": False,
    }


class Basis:
    def __init__(self, meter, raw, sample):
        self.m, self.raw, self.sample = meter, raw, sample
        self.views = []
        self.valid = {}
        self.zero_id = None
        self.view_validations = []
        self.buckets = defaultdict(list)
        self.proof_count = 0
        self.evaluation_buckets = defaultdict(list)
        self.evaluation_count = 0
        self.basis = []
        self.outcomes = []
        self.column_ids = []
        self.final_basis = None
        self.column_seed = None

    def phase(self, phase, column=None, basis_index=None):
        self.m.context = {"phase": phase, "column": column, "basis_index": basis_index}

    def scalar(self, op, a, b=None):
        t = self.m.begin("int_scalar", {"op": op, "a": a, "b": b})
        av = self.m.arg(a)
        if op in ("neg", "abs"):
            require(b is None, "unary scalar argument")
            value = -av if op == "neg" else abs(av)
        else:
            require(b is not None, "missing binary scalar argument")
            bv = self.m.arg(b)
            if op == "add":
                value = av + bv
            elif op == "sub":
                value = av - bv
            elif op == "mul":
                value = av * bv
            elif op == "divmod":
                require(bv > 0, "divmod divisor must be positive")
                value = list(divmod(av, bv))
            else:
                raise FixtureRejected("unknown scalar operation")
        self.m.finish(t, {"value": value}, arg_ids(a, b))
        return ref(t, "value")

    def gcd_step(self, x, y):
        t = self.m.begin("gcd_step", {"x": x, "y": y})
        xv, yv = self.m.arg(x), self.m.arg(y)
        require(xv >= 0 and yv >= 0, "negative gcd argument")
        if yv == 0:
            out = {"terminal": True, "quotient": None, "remainder": None}
        else:
            q, r = divmod(xv, yv)
            out = {"terminal": False, "quotient": q, "remainder": r}
        self.m.finish(t, out, arg_ids(x, y))
        return t

    def rat_normalize(self, numerator, denominator):
        t = self.m.begin("rat_normalize", {"numerator": numerator, "denominator": denominator})
        original = arg_ids(numerator, denominator)
        n, d = self.m.arg(numerator), self.m.arg(denominator)
        require(d != 0, "zero rational denominator")
        if d < 0:
            numerator = ra(self.scalar("neg", numerator))
            denominator = ra(self.scalar("neg", denominator))
            n, d = self.m.arg(numerator), self.m.arg(denominator)
        if n == 0:
            value, rule = [0, 1], "zero"
        elif d == 1:
            value, rule = [n, 1], "denominator_one"
        else:
            x, y = ra(self.scalar("abs", numerator)), denominator
            while True:
                step = self.gcd_step(x, y)
                if self.m.outputs[step]["terminal"]:
                    break
                x, y = y, ra(ref(step, "remainder"))
            nr = self.scalar("divmod", numerator, x)
            dr = self.scalar("divmod", denominator, x)
            nq, remn = self.m.get(nr)
            dq, remd = self.m.get(dr)
            require(remn == 0 and remd == 0 and dq > 0, "nonexact rational normalization")
            value, rule = [nq, dq], "gcd"
        self.m.finish(t, {"value": value, "rule": rule}, original)
        self.m.rational_max(value)
        return ref(t, "value")

    def rat(self, operation, a, b):
        t = self.m.begin(operation, {"a": a, "b": b})
        av, bv = self.m.rational(a), self.m.rational(b)
        if operation == "rat_mul":
            if av[0] == 0 or bv[0] == 0:
                value, rule = [0, 1], "zero"
            elif av == [1, 1]:
                value, rule = bv[:], "left_unit"
            elif bv == [1, 1]:
                value, rule = av[:], "right_unit"
            else:
                n = self.scalar("mul", ra(a + [0]), ra(b + [0]))
                d = self.scalar("mul", ra(a + [1]), ra(b + [1]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        elif operation == "rat_sub":
            if bv[0] == 0:
                value, rule = av[:], "right_zero"
            elif av == bv:
                value, rule = [0, 1], "equal"
            elif av[0] == 0:
                n = self.scalar("neg", ra(b + [0]))
                value, rule = [self.m.get(n), bv[1]], "left_zero"
            elif av[1] == bv[1]:
                n = self.scalar("sub", ra(a + [0]), ra(b + [0]))
                value = self.m.get(self.rat_normalize(ra(n), ra(a + [1])))
                rule = "equal_denominator"
            else:
                left = self.scalar("mul", ra(a + [0]), ra(b + [1]))
                right = self.scalar("mul", ra(b + [0]), ra(a + [1]))
                n = self.scalar("sub", ra(left), ra(right))
                d = self.scalar("mul", ra(a + [1]), ra(b + [1]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        else:
            require(operation == "rat_div" and bv[0] != 0, "unknown operation or zero rational divisor")
            if av[0] == 0:
                value, rule = [0, 1], "zero"
            elif bv == [1, 1]:
                value, rule = av[:], "unit_divisor"
            elif av == bv:
                value, rule = [1, 1], "equal"
            else:
                n = self.scalar("mul", ra(a + [0]), ra(b + [1]))
                d = self.scalar("mul", ra(a + [1]), ra(b + [0]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        self.m.finish(t, {"value": value, "rule": rule}, [a[0], b[0]])
        self.m.rational_max(value)
        return ref(t, "value")

    def record(self, node):
        records = self.raw.get(node, [])
        require(len(records) == 1, "missing or duplicate selected source definition")
        return records[0]

    def info(self, node):
        require(node in self.valid, "unvalidated source read")
        return self.valid[node]

    def validate(self, node):
        t = self.m.begin("validate", {"source_node_id": node})
        natural(node)
        if node in self.valid:
            info, prior = self.valid[node]
            self.m.count_cache("validate", True)
            self.m.finish(t, {**info, "cache_hit": True, "prior": prior}, [prior])
            return t
        self.m.count_cache("validate", False)
        r = self.record(node)
        require(r.get("type") == "node" and natural(r["id"]) == node, "source node binding")
        kind, value = r["kind"], None
        if kind == "constant":
            value = natural(r["value"])
            support, flat = 0, [0, 0, node]
        elif kind == "ite":
            v, low, high = natural(r["variable"]), natural(r["low"]), natural(r["high"])
            require(v < VARIABLES and low < node and high < node, "source branch bounds/order")
            low_id, high_id = self.validate(low), self.validate(high)
            child_support = self.m.outputs[low_id]["support"] | self.m.outputs[high_id]["support"]
            require(child_support & ((1 << (v + 1)) - 1) == 0, "source variable order")
            support, flat = (1 << v) | child_support, [0, 0, node]
        elif kind == "guard":
            p, n, core = natural(r["positive"]), natural(r["negative"]), natural(r["core"])
            require(p < 1 << VARIABLES and n < 1 << VARIABLES and core < node, "source guard bounds")
            require(p | n and p & n == 0, "source guard conflict or empty guard")
            child_id = self.validate(core)
            child = self.m.outputs[child_id]
            require(child["node_kind"] != "guard" and (p | n) & child["support"] == 0,
                    "source guard/core overlap or nested guard")
            support, flat = p | n | child["support"], [p, n, core]
        else:
            raise FixtureRejected("unsupported original node kind")
        require(node != 0 or (kind == "constant" and value == 0), "source node0 is not zero")
        info = {"node_kind": kind, "support": support, "flat": flat, "value": value}
        self.m.finish(t, {**info, "cache_hit": False, "prior": None})
        self.valid[node] = (info, t)
        return t

    def check_view(self, view, info):
        require(type(view) is list and len(view) == 3, "malformed view")
        p, n, core = (natural(x) for x in view)
        require(p < 1 << VARIABLES and n < 1 << VARIABLES and info["node_kind"] != "guard",
                "view bounds or nonbare core")
        require(p & n == 0 and (p | n) & info["support"] == 0, "view support conflict")
        support = p | n | info["support"]
        require(support & ~Y_MASK == 0, "view support outside fixed side")
        return support

    def validate_selected(self):
        self.phase("validate")
        self.zero_id = self.validate(0)
        for column, load in enumerate(self.views):
            view = self.m.get(load)
            t = self.m.begin("view_validate", {"column": column, "view": view, "load": load})
            child = self.validate(view[2])
            support = self.check_view(view, self.m.outputs[child])
            self.m.finish(t, {"view": view[:], "support": support, "inside_y": True},
                          [load[0], self.zero_id])
            self.view_validations.append(t)

    def term_add(self, accumulator, view, coefficient):
        t = self.m.begin("term_add", {"accumulator": accumulator, "view": view, "coefficient": coefficient})
        before = [] if accumulator is None else self.m.get(accumulator)
        incoming, c = self.m.get(view), integer(self.m.get(coefficient))
        out = before[:]
        if c == 0:
            rule = "zero_coefficient"
        elif incoming == ZERO:
            rule = "zero_view"
        else:
            rule = "append"
            for position in range(len(before)):
                existing = accumulator + [position, 0]
                compare = self.m.begin("term_compare", {"incoming": view, "existing": existing})
                ev = self.m.get(existing)
                order = -1 if incoming < ev else 1 if incoming > ev else 0
                self.m.finish(compare, {"order": order}, [view[0], existing[0]])
                if order < 0:
                    out.insert(position, [incoming[:], c])
                    rule = "insert"
                    break
                if order == 0:
                    summed = self.scalar("add", ra(accumulator + [position, 1]), ra(coefficient))
                    combined = self.m.get(summed)
                    if combined == 0:
                        out.pop(position)
                        rule = "cancel"
                    else:
                        out[position] = [incoming[:], combined]
                        rule = "combine"
                    break
            if rule == "append":
                out.append([incoming[:], c])
        require(len(out) <= COLS, "relation state exceeds original-column bound")
        self.m.finish(t, {"state": out, "rule": rule},
                      ([] if accumulator is None else [accumulator[0]]) + [view[0], coefficient[0]])
        self.m.maxima["state_terms"] = max(self.m.maxima["state_terms"], len(out))
        if rule in ("insert", "append"):
            self.m.maxima["state_coefficient_bits"] = max(self.m.maxima["state_coefficient_bits"], c.bit_length())
        elif rule == "combine":
            self.m.maxima["state_coefficient_bits"] = max(
                self.m.maxima["state_coefficient_bits"], combined.bit_length())
        return ref(t, "state")

    def normalize(self, terms):
        t = self.m.begin("normalize", {"terms": terms})
        acc = None
        explicit = []
        for term in terms:
            explicit.extend([term["view"][0], term["coefficient"][0]])
            acc = self.term_add(acc, term["view"], term["coefficient"])
        state = [] if acc is None else self.m.get(acc)
        self.m.finish(t, {"state": state}, explicit)
        return ref(t, "state")

    def state_lookup(self, state_ref):
        t = self.m.begin("state_lookup", {"state": state_ref})
        state = self.m.get(state_ref)
        encoded = json.dumps(state, separators=(",", ":"), ensure_ascii=True).encode("ascii")
        digest = hashlib.sha256(encoded).hexdigest()
        found = None
        for entry in self.buckets.get(digest, []):
            previous = entry["state_ref"]
            c = self.m.begin("cache_candidate", {"state": state_ref, "prior_state": previous,
                                                  "prior_zero": entry["work"], "prior_proof": entry["proof"]})
            other = self.m.get(previous)
            equal = len(state) == len(other)
            if equal:
                for position in range(len(state)):
                    current_term, cached_term = state_ref + [position], previous + [position]
                    e = self.m.begin("cache_term", {"current": current_term, "cached": cached_term})
                    equal = self.m.get(current_term) == self.m.get(cached_term)
                    self.m.finish(e, {"equal": equal}, [current_term[0], cached_term[0]])
                    if not equal:
                        break
            self.m.finish(c, {"equal": equal}, [state_ref[0], previous[0], entry["work"]])
            if equal:
                found = entry
                break
        hit = found is not None
        self.m.count_cache("zero_state", hit)
        output = {"hit": hit, "prior": found["work"] if hit else None,
                  "proof_id": found["proof"] if hit else None, "digest": digest}
        self.m.finish(t, output, [state_ref[0]])
        return t

    def view_support(self, view_ref):
        t = self.m.begin("view_support", {"view": view_ref})
        view = self.m.get(view_ref)
        info, validation = self.info(view[2])
        support = self.check_view(view, info)
        self.m.finish(t, {"support": support}, [view_ref[0], validation])
        return ref(t, "support")

    def join_support(self, before, support):
        t = self.m.begin("support_join", {"before": before, "term_support": support})
        a, b = natural(self.m.arg(before)), natural(self.m.get(support))
        require(a < 1 << VARIABLES and b < 1 << VARIABLES, "support mask bound")
        self.m.finish(t, {"after": a | b}, arg_ids(before) + [support[0]])
        return ref(t, "after")

    def select_variable(self, support):
        t = self.m.begin("select_variable", {"support": support})
        value = natural(self.m.arg(support))
        require(value < 1 << VARIABLES, "support selection mask bound")
        variable = None if value == 0 else (value & -value).bit_length() - 1
        self.m.finish(t, {"variable": variable}, arg_ids(support))
        return ref(t, "variable")

    def cofactor(self, view_ref, variable_ref, bit):
        t = self.m.begin("cofactor", {"view": view_ref, "variable": variable_ref, "bit": bit})
        view, v = self.m.get(view_ref), natural(self.m.get(variable_ref))
        require(v < VARIABLES and type(bit) is int and bit in (0, 1), "cofactor variable/bit")
        p, n, core = view
        info, validation = self.info(core)
        support = self.check_view(view, info)
        deps = [view_ref[0], variable_ref[0], validation, self.zero_id]
        require(support & ((1 << v) - 1) == 0, "cofactor below least variable")
        mark = 1 << v
        if view == ZERO:
            rule, result, remaining = "zero", ZERO[:], 0
        elif p & mark:
            if bit:
                rule, result, remaining = "guard_satisfied", [p ^ mark, n, core], support ^ mark
            else:
                rule, result, remaining = "guard_contradiction", ZERO[:], 0
        elif n & mark:
            if bit:
                rule, result, remaining = "guard_contradiction", ZERO[:], 0
            else:
                rule, result, remaining = "guard_satisfied", [p, n ^ mark, core], support ^ mark
        elif not support & mark:
            rule, result, remaining = "absent", view[:], support
        else:
            source = self.record(core)
            require(source["kind"] == "ite" and source["variable"] == v, "cofactor branch mismatch")
            child = source["high"] if bit else source["low"]
            child_info, child_validation = self.info(child)
            deps.append(child_validation)
            cp, cn, cc = child_info["flat"]
            pp, nn = p | cp, n | cn
            if child_info["flat"] == ZERO or pp & nn:
                result, remaining = ZERO[:], 0
            else:
                bare_support = child_info["support"] & ~(cp | cn)
                require((pp | nn) & bare_support == 0, "merged cofactor guard/core overlap")
                result, remaining = [pp, nn, cc], pp | nn | bare_support
            rule = "branch"
        require(remaining & ((1 << (v + 1)) - 1) == 0 and remaining & ~Y_MASK == 0,
                "cofactor did not reduce supported variables")
        self.m.finish(t, {"view": result, "support": remaining, "rule": rule}, deps)
        return ref(t, "view")

    def branch(self, state_ref, variable, bit):
        t = self.m.begin("branch", {"state": state_ref, "variable": variable, "bit": bit})
        state = self.m.get(state_ref)
        cofactors = []
        for position in range(len(state)):
            cofactors.append(self.cofactor(state_ref + [position, 0], variable, bit))
        terms = [{"view": c, "coefficient": state_ref + [i, 1]} for i, c in enumerate(cofactors)]
        normalized = self.normalize(terms)
        child = self.prove_state(normalized)
        result = self.m.outputs[child]
        self.m.finish(t, {"child_state": self.m.get(normalized), "child_ref": child,
                          "outcome": result["outcome"], "proof_id": result["proof_id"],
                          "assignment": result["assignment"], "nonzero_value": result["nonzero_value"]},
                      [state_ref[0], variable[0]])
        return t

    def refute_lift(self, variable, bit, branch):
        t = self.m.begin("refute_lift", {"variable": variable, "bit": bit, "branch": branch})
        v = natural(self.m.get(variable))
        child = self.m.outputs[branch]
        require(child["outcome"] == "refuted" and child["nonzero_value"] != 0,
                "refutation lift needs completed nonzero child")
        assignment = natural(child["assignment"])
        require(v < VARIABLES and assignment < 1 << VARIABLES and bit in (0, 1), "refutation bound")
        assignment = (assignment | (1 << v)) if bit else (assignment & ~(1 << v))
        self.m.finish(t, {"assignment": assignment, "nonzero_value": child["nonzero_value"]},
                      [variable[0], branch])
        return t

    def prove_state(self, state_ref):
        t = self.m.begin("state", {"normalization": state_ref})
        state = self.m.get(state_ref)
        lookup_id = self.state_lookup(state_ref)
        lookup = self.m.outputs[lookup_id]
        if lookup["hit"]:
            output = {"outcome": "zero", "rule": "cache", "proof_id": lookup["proof_id"],
                      "proof_new": False, "proof_children": [], "assignment": None, "nonzero_value": None}
        else:
            support = lit(0)
            for position in range(len(state)):
                term_support = self.view_support(state_ref + [position, 0])
                support = ra(self.join_support(support, term_support))
            variable = self.select_variable(support)
            if self.m.get(variable) is None:
                summed = lit(0)
                for position, term in enumerate(state):
                    validation = self.info(term[0][2])[1]
                    product = self.scalar("mul", ra(state_ref + [position, 1]), ra(ref(validation, "value")))
                    self.m.maxima["terminal_integer_bits"] = max(
                        self.m.maxima["terminal_integer_bits"], self.m.get(product).bit_length())
                    total = self.scalar("add", summed, ra(product))
                    self.m.maxima["terminal_integer_bits"] = max(
                        self.m.maxima["terminal_integer_bits"], self.m.get(total).bit_length())
                    summed = ra(total)
                terminal = self.m.begin("terminal_decide", {"state": state_ref, "selection": variable, "sum": summed})
                value = self.m.arg(summed)
                zero = value == 0
                self.m.finish(terminal, {"zero": zero, "value": value},
                              [state_ref[0], variable[0]] + arg_ids(summed))
                output = {"outcome": "zero" if zero else "refuted", "rule": "terminal",
                          "proof_id": self.proof_count if zero else None, "proof_new": zero,
                          "proof_children": [], "assignment": None if zero else 0,
                          "nonzero_value": None if zero else value}
            else:
                low = self.branch(state_ref, variable, 0)
                if self.m.outputs[low]["outcome"] == "refuted":
                    failure = self.refute_lift(variable, 0, low)
                    output = {"outcome": "refuted", "rule": "refuted_low", "proof_id": None,
                              "proof_new": False, "proof_children": [], **self.m.outputs[failure]}
                else:
                    high = self.branch(state_ref, variable, 1)
                    if self.m.outputs[high]["outcome"] == "refuted":
                        failure = self.refute_lift(variable, 1, high)
                        output = {"outcome": "refuted", "rule": "refuted_high", "proof_id": None,
                                  "proof_new": False, "proof_children": [], **self.m.outputs[failure]}
                    else:
                        output = {"outcome": "zero", "rule": "split", "proof_id": self.proof_count,
                                  "proof_new": True, "proof_children": [self.m.outputs[low]["proof_id"],
                                                                          self.m.outputs[high]["proof_id"]],
                                  "assignment": None, "nonzero_value": None}
        self.m.finish(t, output, [state_ref[0]])
        if output["proof_new"]:
            self.proof_count += 1
            self.buckets[lookup["digest"]].append({"state_ref": state_ref, "work": t, "proof": output["proof_id"]})
            self.m.maxima["zero_cache_entries"] = max(self.m.maxima["zero_cache_entries"], self.proof_count)
        return t

    def vector(self, reference):
        value = self.m.get(reference)
        require(type(value) is list and len(value) <= COLS, "malformed bounded vector")
        return value

    def vector_entry(self, reference):
        value = self.m.get(reference)
        require(type(value) is list and len(value) == 2, "malformed vector entry")
        column = natural(value[0])
        coefficient = self.m.rational(reference + [1])
        require(column < COLS and coefficient[0] != 0, "vector entry bounds or zero")
        return column, coefficient

    def vector_max(self, vector):
        self.m.maxima["vector_terms"] = max(self.m.maxima["vector_terms"], len(vector))

    def load(self):
        self.phase("load")
        for column in range(COLS):
            saved = self.sample["grouping"]["b_views"][column]
            t = self.m.begin("view_load", {"column": column, "saved_view": saved})
            require(len(self.sample["grouping"]["b_views"]) == COLS, "view dimension mismatch")
            require(type(saved) is list and len(saved) == 3, "malformed saved view")
            for item in saved:
                natural(item)
            self.m.finish(t, {"view": saved[:]})
            self.views.append(ref(t, "view"))

    def rat_add(self, a, b):
        t = self.m.begin("rat_add", {"a": a, "b": b})
        av, bv = self.m.rational(a), self.m.rational(b)
        if bv[0] == 0:
            value, rule = av[:], "right_zero"
        elif av[0] == 0:
            value, rule = bv[:], "left_zero"
        elif av[1] == bv[1]:
            n = self.scalar("add", ra(a + [0]), ra(b + [0]))
            value = self.m.get(self.rat_normalize(ra(n), ra(a + [1])))
            rule = "equal_denominator"
        else:
            left = self.scalar("mul", ra(a + [0]), ra(b + [1]))
            right = self.scalar("mul", ra(b + [0]), ra(a + [1]))
            n = self.scalar("add", ra(left), ra(right))
            d = self.scalar("mul", ra(a + [1]), ra(b + [1]))
            value = self.m.get(self.rat_normalize(ra(n), ra(d)))
            rule = "general"
        self.m.finish(t, {"value": value, "rule": rule}, [a[0], b[0]])
        self.m.rational_max(value)
        return ref(t, "value")

    def evaluation_lookup(self, view_ref, assignment_ref):
        t = self.m.begin("evaluation_lookup", {"view": view_ref, "assignment": assignment_ref})
        view, assignment = self.m.get(view_ref), natural(self.m.get(assignment_ref))
        require(type(view) is list and len(view) == 3 and assignment < 1 << VARIABLES,
                "evaluation cache key bounds")
        encoded = json.dumps([view, assignment], separators=(",", ":"), ensure_ascii=True).encode("ascii")
        digest = hashlib.sha256(encoded).hexdigest()
        found = None
        for prior in self.evaluation_buckets.get(digest, []):
            c = self.m.begin("evaluation_candidate", {"view": view_ref, "assignment": assignment_ref,
                                                      "prior": prior["work"]})
            equal = (view == self.m.get(prior["view"]) and
                     assignment == self.m.get(prior["assignment"]))
            self.m.finish(c, {"equal": equal}, [view_ref[0], assignment_ref[0], prior["work"]])
            if equal:
                found = prior
                break
        hit = found is not None
        self.m.finish(t, {"hit": hit, "prior": found["work"] if hit else None, "digest": digest},
                      [view_ref[0], assignment_ref[0]])
        self.m.count_cache("source_evaluation", hit)
        return t

    def evaluate(self, view_ref, assignment_ref):
        t = self.m.begin("evaluate", {"view": view_ref, "assignment": assignment_ref})
        lookup_id = self.evaluation_lookup(view_ref, assignment_ref)
        lookup = self.m.outputs[lookup_id]
        dependencies = [view_ref[0], assignment_ref[0]]
        child = None
        if lookup["hit"]:
            prior = lookup["prior"]
            value = natural(self.m.outputs[prior]["value"])
            rule = "cache"
            dependencies.append(prior)
        else:
            prior = None
            view, assignment = self.m.get(view_ref), natural(self.m.get(assignment_ref))
            info, validation = self.info(view[2])
            self.check_view(view, info)
            require(assignment < 1 << VARIABLES and assignment & ~Y_MASK == 0,
                    "evaluation assignment outside fixed side")
            dependencies.append(validation)
            p, n, core = view
            if (p & assignment) != p or (n & assignment) != 0:
                value, rule = 0, "guard_zero"
            elif info["node_kind"] == "constant":
                value, rule = natural(info["value"]), "constant"
            else:
                source = self.record(core)
                require(source["kind"] == "ite", "evaluation expected bare ite")
                variable = natural(source["variable"])
                selected = source["high"] if assignment & (1 << variable) else source["low"]
                _, selected_validation = self.info(selected)
                dependencies.append(selected_validation)
                child = self.evaluate(ref(selected_validation, "flat"), assignment_ref)
                value, rule = natural(self.m.outputs[child]["value"]), "branch"
        output = {"value": value, "rational": [value, 1], "cache_hit": lookup["hit"],
                  "prior": prior, "rule": rule, "child": child}
        self.m.finish(t, output, dependencies)
        self.m.rational_max(output["rational"])
        self.m.maxima["source_value_bits"] = max(self.m.maxima["source_value_bits"], value.bit_length())
        if not lookup["hit"]:
            self.evaluation_buckets[lookup["digest"]].append(
                {"view": view_ref[:], "assignment": assignment_ref[:], "work": t})
            self.evaluation_count += 1
            self.m.maxima["source_evaluation_cache_entries"] = max(
                self.m.maxima["source_evaluation_cache_entries"], self.evaluation_count)
        return t

    def dot_term(self, entry_ref, assignment_ref, before):
        t = self.m.begin("dot_term", {"entry": entry_ref, "assignment": assignment_ref, "before": before})
        column, _ = self.vector_entry(entry_ref)
        validation = self.view_validations[column]
        evaluation = self.evaluate(ref(validation, "view"), assignment_ref)
        product = self.rat("rat_mul", entry_ref + [1], ref(evaluation, "rational"))
        summed = self.rat_add(before, product)
        value = self.m.get(summed)
        self.m.finish(t, {"value": value, "evaluation": evaluation, "product": product,
                          "sum": summed, "view_validation": validation},
                      [entry_ref[0], assignment_ref[0], before[0], validation])
        self.m.rational_max(value)
        return t

    def dot(self, vector_ref, assignment_ref, zero):
        t = self.m.begin("dot", {"vector": vector_ref, "assignment": assignment_ref, "zero": zero})
        vector = self.vector(vector_ref)
        require(self.m.rational(zero) == [0, 1], "dot zero seed differs")
        before = zero
        for position in range(len(vector)):
            term = self.dot_term(vector_ref + [position], assignment_ref, before)
            before = ref(term, "value")
        value = self.m.get(before)
        self.m.finish(t, {"value": value, "last": before}, [vector_ref[0], assignment_ref[0], zero[0]])
        self.m.rational_max(value)
        return t

    def vector_merge(self, left_ref, right_ref, factor_ref, zero, left_cursor, right_cursor):
        t = self.m.begin("vector_merge", {"left": left_ref, "right": right_ref, "factor": factor_ref,
                                           "zero": zero, "left_cursor": left_cursor, "right_cursor": right_cursor})
        left, right = self.vector(left_ref), self.vector(right_ref)
        require(natural(left_cursor) <= len(left) and natural(right_cursor) <= len(right), "merge cursor bound")
        require(self.m.rational(factor_ref)[0] != 0 and self.m.rational(zero) == [0, 1], "merge factor or seed")
        next_left, next_right = left_cursor, right_cursor
        entry = None
        terminal = left_cursor == len(left) and right_cursor == len(right)
        if terminal:
            kind = "terminal"
        else:
            lref = None if left_cursor == len(left) else left_ref + [left_cursor]
            rref = None if right_cursor == len(right) else right_ref + [right_cursor]
            lv = None if lref is None else self.vector_entry(lref)
            rv = None if rref is None else self.vector_entry(rref)
            if rv is None or (lv is not None and lv[0] < rv[0]):
                kind, entry = "left_only", [lv[0], lv[1][:]]
                next_left += 1
            elif lv is None or rv[0] < lv[0]:
                kind = "right_only"
                product = self.rat("rat_mul", factor_ref, rref + [1])
                coefficient = self.m.get(self.rat("rat_sub", zero, product))
                if coefficient[0] != 0:
                    entry = [rv[0], coefficient]
                next_right += 1
            else:
                kind = "both"
                product = self.rat("rat_mul", factor_ref, rref + [1])
                coefficient = self.m.get(self.rat("rat_sub", lref + [1], product))
                if coefficient[0] != 0:
                    entry = [lv[0], coefficient]
                next_left += 1
                next_right += 1
        self.m.finish(t, {"terminal": terminal, "kind": kind, "entry": entry,
                          "next_left": next_left, "next_right": next_right},
                      [left_ref[0], right_ref[0], factor_ref[0], zero[0]])
        return t

    def vector_sub(self, left_ref, factor_ref, right_ref, zero):
        t = self.m.begin("vector_sub", {"left": left_ref, "factor": factor_ref, "right": right_ref, "zero": zero})
        if self.m.rational(factor_ref)[0] == 0:
            out, rule = self.vector(left_ref), "zero_factor"
        else:
            out, rule = [], "merge"
            left_cursor = right_cursor = 0
            while True:
                step = self.vector_merge(left_ref, right_ref, factor_ref, zero, left_cursor, right_cursor)
                result = self.m.outputs[step]
                if result["terminal"]:
                    break
                if result["entry"] is not None:
                    out.append(result["entry"])
                left_cursor, right_cursor = result["next_left"], result["next_right"]
        require(len(out) <= COLS, "subtraction exceeds original-column bound")
        self.m.finish(t, {"vector": out, "rule": rule}, [left_ref[0], factor_ref[0], right_ref[0], zero[0]])
        self.vector_max(out)
        return t

    def column_start(self, column, previous):
        t = self.m.begin("column_start", {"column": column, "previous_column": previous})
        require(natural(column) == len(self.column_ids) and column < COLS, "column order differs")
        require(previous == (self.column_ids[-1] if self.column_ids else None), "previous column differs")
        vector = [[column, [1, 1]]]
        self.m.finish(t, {"vector": vector, "rational_zero": [0, 1], "integer_one": 1},
                      [] if previous is None else [previous])
        self.m.rational_max([0, 1])
        self.m.rational_max([1, 1])
        self.vector_max(vector)
        self.column_seed = t
        return t

    def eliminate(self, column, index, residual, basis):
        t = self.m.begin("eliminate", {"column": column, "basis_index": index,
                                        "residual": residual, "basis_commit": basis})
        require(natural(column) == len(self.column_ids) and natural(index) < len(self.basis), "elimination index")
        require(self.basis[index] == basis, "elimination basis order")
        zero = ref(self.column_seed, "rational_zero")
        dotted = self.dot(residual, ref(basis, "witness"), zero)
        update = self.vector_sub(residual, ref(dotted, "value"), ref(basis, "vector"), zero)
        vector = self.m.outputs[update]["vector"]
        self.m.finish(t, {"vector": vector, "factor": self.m.outputs[dotted]["value"],
                          "dot": dotted, "update": update, "triangular_prefix": index + 1},
                      [residual[0], basis])
        self.vector_max(vector)
        return t

    def clear_entry(self, entry_ref, scale_ref):
        t = self.m.begin("clear_entry", {"entry": entry_ref, "scale": scale_ref})
        column, _ = self.vector_entry(entry_ref)
        require(integer(self.m.get(scale_ref)) > 0, "nonpositive clearing scale")
        quotient = self.scalar("divmod", ra(scale_ref), ra(entry_ref + [1, 1]))
        require(self.m.get(quotient)[1] == 0, "clearing quotient not exact")
        product = self.scalar("mul", ra(entry_ref + [1, 0]), ra(quotient + [0]))
        coefficient = integer(self.m.get(product))
        require(coefficient != 0, "clearing lost a nonzero coefficient")
        self.m.finish(t, {"column": column, "coefficient": coefficient}, [entry_ref[0], scale_ref[0]])
        self.m.maxima["cleared_coefficient_bits"] = max(
            self.m.maxima["cleared_coefficient_bits"], coefficient.bit_length())
        return t

    def clear_vector(self, column, vector_ref, one):
        t = self.m.begin("clear_vector", {"column": column, "vector": vector_ref, "one": one})
        vector = self.vector(vector_ref)
        require(vector and vector[-1] == [column, [1, 1]], "residual target coefficient is not one")
        require(integer(self.m.get(one)) == 1, "clearing one seed differs")
        scale = one
        for position in range(len(vector)):
            scale = self.scalar("mul", ra(scale), ra(vector_ref + [position, 1, 1]))
        entries, entry_ids = [], []
        for position in range(len(vector)):
            entry = self.clear_entry(vector_ref + [position], scale)
            result = self.m.outputs[entry]
            entries.append([result["column"], result["coefficient"]])
            entry_ids.append(entry)
        value = integer(self.m.get(scale))
        require(value > 0 and entries[-1] == [column, value], "cleared target differs from positive scale")
        self.m.finish(t, {"scale": value, "entries": entries, "entry_ids": entry_ids,
                          "target_coefficient": value}, [vector_ref[0], one[0]])
        return t

    def origin_term(self, clear_entry):
        t = self.m.begin("origin_term", {"clear_entry": clear_entry})
        source = self.m.outputs[clear_entry]
        column, coefficient = natural(source["column"]), integer(source["coefficient"])
        require(column < COLS and coefficient != 0, "origin term coefficient or column")
        validation = self.view_validations[column]
        self.m.finish(t, {"view": self.m.outputs[validation]["view"], "coefficient": coefficient,
                          "view_validation": validation}, [clear_entry, validation])
        return t

    def oracle_bridge(self, column, cleared):
        t = self.m.begin("oracle_bridge", {"column": column, "cleared": cleared})
        vector = self.m.outputs[cleared]
        require(vector["scale"] > 0 and vector["entries"][-1] == [column, vector["scale"]], "oracle target origin")
        terms = []
        for entry in vector["entry_ids"]:
            term = self.origin_term(entry)
            terms.append({"view": ref(term, "view"), "coefficient": ref(term, "coefficient")})
        normalization = self.normalize(terms)
        root = self.prove_state(normalization)
        result = self.m.outputs[root]
        self.m.finish(t, {"root_state": root, "normalization": normalization,
                          "outcome": result["outcome"], "proof_id": result["proof_id"],
                          "assignment": result["assignment"], "nonzero_value": result["nonzero_value"]},
                      [cleared])
        return t

    def basis_entry(self, clear_entry, nonzero):
        t = self.m.begin("basis_entry", {"clear_entry": clear_entry, "nonzero_value": nonzero})
        original = self.m.outputs[clear_entry]
        require(integer(self.m.get(nonzero)) != 0, "basis normalization divisor zero")
        normalized = self.rat_normalize(ra(ref(clear_entry, "coefficient")), ra(nonzero))
        coefficient = self.m.get(normalized)
        require(coefficient[0] != 0, "basis normalization lost nonzero coefficient")
        entry = [natural(original["column"]), coefficient]
        self.m.finish(t, {"entry": entry}, [clear_entry, nonzero[0]])
        return t

    def basis_commit(self, index, column, cleared, oracle):
        t = self.m.begin("basis_commit", {"basis_index": index, "column": column,
                                           "cleared": cleared, "oracle": oracle})
        require(natural(index) == len(self.basis), "basis insertion order differs")
        result, original = self.m.outputs[oracle], self.m.outputs[cleared]
        require(result["outcome"] == "refuted" and integer(result["nonzero_value"]) != 0,
                "basis needs completed refutation")
        witness = natural(result["assignment"])
        require(witness < 1 << VARIABLES and witness & ~Y_MASK == 0, "basis witness outside fixed side")
        vector = []
        for clear_entry in original["entry_ids"]:
            entry = self.basis_entry(clear_entry, ref(oracle, "nonzero_value"))
            vector.append(self.m.outputs[entry]["entry"])
        require(vector and len(vector) <= COLS and vector[-1][0] == column and vector[-1][1][0] != 0,
                "basis original pivot lost")
        output = {"basis_index": index, "pivot_column": column, "vector": vector,
                  "witness": witness, "nonzero_value": result["nonzero_value"],
                  "cleared": cleared, "oracle": oracle}
        self.m.finish(t, output, [cleared, oracle])
        self.basis.append(t)
        self.vector_max(vector)
        return t

    def column_complete(self, column, cleared, oracle):
        t = self.m.begin("column_complete", {"column": column, "cleared": cleared, "oracle": oracle})
        require(natural(column) == len(self.column_ids), "column completion order differs")
        result = self.m.outputs[oracle]
        if result["outcome"] == "zero":
            require(result["proof_id"] is not None, "dependent column lacks zero proof")
            outcome, commit, proof = "dependent", None, result["proof_id"]
        else:
            require(result["outcome"] == "refuted", "incomplete oracle cannot complete column")
            index = len(self.basis)
            self.phase("columns", column, index)
            commit = self.basis_commit(index, column, cleared, oracle)
            self.phase("columns", column)
            outcome, proof = "independent", None
        output = {"column": column, "outcome": outcome, "cleared": cleared,
                  "oracle": oracle, "proof_id": proof, "basis_commit": commit}
        self.m.finish(t, output, [cleared, oracle])
        self.column_ids.append(t)
        self.outcomes.append(output)
        return t

    def basis_finish(self):
        t = self.m.begin("basis_finish", {"column_outcomes": self.column_ids[:], "basis_commits": self.basis[:]})
        require(len(self.column_ids) == COLS, "basis coverage incomplete")
        pivots, dependent = [], []
        for column in range(COLS):
            source = self.column_ids[column]
            c = self.m.begin("coverage_entry", {"column": column, "column_outcome": source})
            result = self.m.outputs[source]
            require(result["column"] == column, "column coverage origin differs")
            if result["outcome"] == "independent":
                require(len(pivots) < len(self.basis) and result["basis_commit"] == self.basis[len(pivots)] and
                        result["proof_id"] is None, "basis coverage order differs")
                pivots.append(column)
            else:
                require(result["outcome"] == "dependent" and result["basis_commit"] is None and
                        result["proof_id"] is not None, "dependency coverage differs")
                dependent.append(column)
            self.m.finish(c, {"outcome": result["outcome"], "basis_commit": result["basis_commit"],
                              "proof_id": result["proof_id"]}, [source])
        require(len(pivots) == len(self.basis), "uncovered basis entry")
        output = {"dimension": len(pivots), "pivot_columns": pivots,
                  "dependent_columns": dependent, "columns_complete": COLS}
        self.m.finish(t, output, self.column_ids + self.basis)
        self.final_basis = output
        return t

    def run(self):
        self.load()
        self.validate_selected()
        for column in range(COLS):
            self.phase("columns", column)
            start = self.column_start(column, self.column_ids[-1] if self.column_ids else None)
            residual = ref(start, "vector")
            for index, basis in enumerate(self.basis):
                self.phase("columns", column, index)
                result = self.eliminate(column, index, residual, basis)
                residual = ref(result, "vector")
                self.phase("columns", column)
            cleared = self.clear_vector(column, residual, ref(start, "integer_one"))
            oracle = self.oracle_bridge(column, cleared)
            self.column_complete(column, cleared, oracle)
        self.phase("finish")
        self.basis_finish()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", required=True, type=Path)
    parser.add_argument("--sample", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    engine = None
    status, error, exit_code = "unexpected_error", None, 2
    preparation = None
    with args.output.open("x") as stream:
        meter = Meter(stream)
        try:
            raw, sample, inputs, preparation = prepare(args.trace, args.sample)
            source_dir = Path(__file__).resolve().parents[1]
            policies = {"program": binding(Path(__file__).resolve()),
                        "protocol": binding(source_dir / "PROTOCOL.md"),
                        "design": binding(source_dir / "DESIGN.md"),
                        "schema": binding(source_dir / "schema.json"),
                        "inherited_protocol": binding(source_dir / "inherited" / "PROTOCOL.md"),
                        "inherited_producer": binding(source_dir / "inherited" / "produce_relations.py"),
                        "inherited_replayer": binding(source_dir / "inherited" / "replay_relations.py")}
            expected_base = {"inherited_protocol": "28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147",
                             "inherited_producer": "5c5ba4f6d8a87f9931f6da9fe2d64ff3598aaf1c0c9d7dc3637678efbe817029",
                             "inherited_replayer": "029ad7a95d6d37c66b53b9d78fb1e3d6a341852eb7596491dda314700c617cbc"}
            require(all(policies[k]["sha256"] == v for k, v in expected_base.items()), "inherited source binding differs")
            meter.write({"kind": "header", "version": VERSION, "input_bindings": inputs,
                         "policy_bindings": policies,
                         "limits": {"charged_request_cap": CAP, "wall_seconds": 30, "cpu_seconds": 30,
                                    "cpu_count": 1, "address_space_bytes": 1 << 30}})
            engine = Basis(meter, raw, sample)
            engine.run()
            require(not meter.stack and engine.final_basis is not None, "completed basis lacks full coverage")
            status, exit_code = "completed_exact_basis", 0
        except LimitReached as exc:
            status, exit_code = "request_cap", 4
            error = {"type": type(exc).__name__, "message": str(exc)}
        except FixtureRejected as exc:
            status = "source_invalid" if meter.context["phase"] in ("validate", "columns") else "fixture_mismatch"
            error = {"type": type(exc).__name__, "message": str(exc)}
        except Exception as exc:
            status = "unexpected_error"
            error = {"type": type(exc).__name__, "message": str(exc)}
        footer = {"kind": "footer", "status": status, "charged_starts": meter.charged,
                  "completed_requests": meter.completed,
                  "pending_stack": [f["id"] for f in meter.stack],
                  "physical_records": meter.physical + 1,
                  "operation_counts": meter.counts, "cache_counts": meter.cache_counts,
                  "phase": dict(meter.context),
                  "completed_columns": [] if engine is None else engine.outcomes,
                  "basis_commits": [] if engine is None else [meter.outputs[i] for i in engine.basis],
                  "final_basis": None if engine is None else engine.final_basis,
                  "maxima": meter.maxima, "error": error}
        meter.write(footer)
    print(json.dumps({"status": status, "charged_starts": meter.charged,
                      "completed_requests": meter.completed, "pending_requests": footer["pending_stack"],
                      "seconds": time.monotonic() - started, "preparation": preparation,
                      "source_count_computed": False, "output": binding(args.output)}, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
