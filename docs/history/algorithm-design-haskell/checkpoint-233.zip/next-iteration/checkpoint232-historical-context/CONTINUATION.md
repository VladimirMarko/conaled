# Continue this project

The authoritative living intent and mathematical scope are in
[`project/CONTINUATION.md`](project/CONTINUATION.md). That file was included in
checkpoint 180 and remains part of every recovery selection. This root entry
point makes it visible immediately after extraction.

On 24 October 2026 the user approved upgrading the whole project to Lean 4.35.0,
trying its bundled kernels, and investigating a proved custom optimization or
replacement if their improvement is insufficient. Research what their proofs
actually establish. The user offered a private library for inspection if a
concrete infrastructure gap makes it relevant.

The Chapter 15 target `cqueens 16 = 14772512` remains open. Preserve the existing
certificate work and compact standalone checkpoints. The latest supplied checkpoint is213,
`adwh-lean-213-reflection-verified-nat-only-proof-repairs.zip`, restored and
byte-verified in this session on25October2026. The active workspace descends
from that standalone source/evidence snapshot. The projected-context experiment
is paused while the approved kernel direction is evaluated.

Read `RESTORE.md` for restoration, `CHECKPOINT-POLICY.md` for retention, and
`next-iteration/lean435-migration/` for current migration evidence. A version-pin
change is not a successful build or proof result.

## User clarification — 25 October 2026

The user values transferable computational-proof infrastructure more than a
one-off proof of the book's n16 numeral. Keep that Chapter 15 goal, but prioritize
methods that work algorithmically for other inputs, a clear reusable checker
interface, and the approved investigation of a proved optimized evaluator or
kernel. A successful n6 refinement alone is not evidence of that practical
generality. The current producer computes its answer; its known small answers
are diagnostic metadata/comparisons, never count premises. Its small-board CLI
and instance-specific source emitters remain engineering specializations.

The user explicitly authorized fixing the identified padding defects. Current
work is `next-iteration/common-payload-padding/`: separate producer/replayer
repairs, meaningful finite boundary tests, and a small universal Lean padding
and codec contract independent of board size or expected count. Earlier frozen
artifacts stay unchanged. This generic proof is now a useful requested result;
it need not be inserted into another n6 count rerun. The fixed resource and
axiom policy remains in force.

The proposed custom kernel has not been built. Existing kernel comparisons and
formal-contract reviews remain evidence, not a refutation of that direction.
The next kernel change needs a measured operation, an explicit refinement
contract, source binding and an execution/integration account. The prior demand
for a new compression witness concerns another capped ADD-producer variant;
it does not make new certificate compression a prerequisite for researching a
general optimized evaluator or kernel.

All published checkpoints use the same standalone source/evidence format.
"Mathematical-result checkpoint" described the change that prompted 195, not a
different backup type. 196 preserves every mathematical source/result from 195
and adds its later review. Keep the latest standalone checkpoint; older ones
are optional history. Neither ZIP is a machine image or includes its compiler,
compiled objects, full textbook or complete upstream kernel metatheory builds.
Read the new DURABILITY-REVIEW for the exact recovery and new-chat boundaries.

## Active completion work — checkpoint 231

Continue the user's instruction to complete `cqueens 16 = 14772512`, publish
standalone durability checkpoints, expose/upload them promptly, and keep working.
**The stock numeral and original installed-kernel endpoints remain open.** Read
`next-iteration/checkpoint231-current-state.md` for the precise current handoff.

### Actual fresh proof attempts and permanent no-retry boundary

The previously accepted Foundation134 run remains intact: all134 reports in
25.97892414099988seconds, peak877200KiB. The larger Interpreter185 attempt now
exists and **failed** after27.61938600800204seconds, peak876532KiB. Core2/Cached6
passed; all177 reports from the combined proof owner are rejected. Its single
failing proof scope is `iota_plain_of_prepared`: the final reduction is not
closed, with twelve unused-simp-argument errors. All1374 read-only snapshots,
six raw logs and the consumed marker have exact canonical recovery mappings.
See `kernel-cached-eventual-interpreter-assembly/gate/RESULT-AND-NEXT.md`.

The first complete word-foundation59 attempt failed in two Routing proofs:
21accepted/37observed,2.2848216820057132seconds. A separately reviewed two-proof
repair was then freshly checked. All five Routing owners passed37 reports, but
Addition's `quotient_add_of_masked` failed at one residue-normalization step.
That complete59 attempt is **failed**,37accepted/59observed,
3.49208853100572seconds, peak509216KiB. Its163 snapshots/twelve logs and the
first attempt's125 snapshots/ten logs are retained. No59-pass claim is made.
See `kernel-word-major-routing-proof-repairs/gate/RESULT-AND-NEXT.md`.

All three source keys are permanently consumed. No unchanged retries, renamed
attempts or prepared dependency artifacts may reset them. The next candidates
must be separate diagnosed proof repairs with full independent source/control
review and a complete fresh closure under the unchanged cumulative30-second,
one-CPU/thread,1-GiB/default-resource/strict-warning/three-axiom policy.

### New reviewed interfaces and explicit source-only work

The installed-guard22 import adaptation now has independent1347/1350 review.
RecordComposition4 now has final1380/1381 review. It constructs the actual
six-literal QueryWithRest callback at arbitrary depth and, for the concrete
record, at fuel99998/depth0 with bound1516. Its final theorem invokes the
original checkPending run from{} at the parametric FirstOrderNat result,
retaining complete restricted record/program/arithmetic metadata and shape
premises. It does not introduce or prove14772512. Its individual-file closure
is35 owners/449 reports/996754bytes; it is not a selected or accepted full gate.

The Eventual PendingCertifier is frozen with1545 author inputs and two sources,
but its independent review is pending. NumericBackend/directBackend keep their
canonical owner; compute-before-compare and the actual restricted lookup remain
explicit. Its prospective closure is40 owners/500 reports/1052028bytes, without
an installed environment or a selected numerical backend. Restoring the masked
backend additionally requires two omitted numerical origins; an import rename
alone is insufficient. The newly failed interpreter is explicit context.

WordMajorAddition22 retains its reviewed68/69 scope but failed its first actual
owner check. WordMajorRouting16's repaired source has76/77 review and now actual
acceptance in the five-owner prefix. Integration26 is frozen with139 author
inputs, pending independent review and compilation; it preserves complete
69-bit packets and all51 n6 payload bits. Whole-word Adjacency19 is now frozen
with184 author inputs, independent review pending; it derives request markers
and compares entire packet fields. Its parent Addition failure remains explicit.
The exact complete n6 substitution census and new diagnosed repairs in progress
are outside this checkpoint's fixed cut unless listed in its selection review.

### Durability and next priorities

The230 publication/clean-restoration receipt is included. All previously selected
payload paths remain. This is source/evidence recovery, not a compiler image:
SDK binaries, prepared objects, duplicate attempt source/input/build trees, full
textbook and full upstream metatheory are omitted. Use the unchanged runtime
pins in session215-runtime-restoration.json. The measured storage-only guard
in checkpoint231-selection-review.json does not change mathematical limits.

First finish the diagnosed iota and Addition proof corrections, review their
actual interfaces, and test each complete selected closure once. Review the
new pending certifier and integration leaves; finish concrete whole-word
adjacency and the exact all-fresh small-certificate closure. Older successful
n6 timings used prepared original imports and do not establish current all-fresh
fit. Preserve the distinct ground stock-theorem and original installed-kernel
routes; a compiled external numeric acceptance does not discharge either.

## Prior status review — checkpoint 214

Checkpoint 214, `adwh-lean-214-status-and-integration-roadmap.zip`, preserves the
checkpoint 213 source/evidence payload and adds the requested report at
`next-iteration/status-review-214/REPORT.md`. This review introduces no new Lean
acceptance and changes no mathematical source, frozen attempt or integrated
ledger. The original n16 numeral theorem and installed validating-kernel result
remain open. The accepted 24-module/154-report reflection workload is retained.

The supplied checkpoint 213 was freshly verified and cleanly extracted: all
7,953 payload files, 1,245 integrated source/control bindings, three historical
n6 bundles and ten original source imports passed. A new independently reviewed
narrow reader passed all 50 recorded source-review scopes (2,246 input
occurrences over 562 canonical paths), the reflection result's 92 canonical
snapshot mappings/52 logs and original Nat-only failure's 15 mappings/eight
logs. These are saved-byte checks, not a new mathematical gate or completion
of the two pending dedicated full saved-result readers.

The user reports post-cut success of the corrected Nat-only proof plus actual
dependency export: 36 reports in 3.37 seconds. That later successful report,
export, controls and marker are absent from the supplied ZIP. Preserve this
as reported later progress, distinct from retained verified evidence. The quote
says actual exported-body inspection was beginning, not completed. Read
`POST-CHECKPOINT-213-HANDOFF.md` beside the report. An earlier archive's absent
marker is not a new execution slot for a run known to have occurred.

Recommended continuation: establish exact new exported-body and certified
annotation correspondence; explicitly adapt the old program/query guards from
StructuralPrimitiveReference to StructuralNatOnlyReference; finish independent
review and the complete fresh Nat-only controls/higher gate; then prove
query-specific cached forward success from the actual invariant-satisfying
state and the complete original fixed-fuel GroupChecked contract. Existing
cached simulation assumes success and cannot be inverted. The higher draft's
pure bound is 45 + depth*(41 + 17*width), or 5053 at 16/16; it is uncompiled and
is neither a total-work bound nor a cached-checker bound. Preserve the real
prefix EnvWF, lookup, annotation, fuel and installation obligations.

Chapters 1–14 and 16 retain their recorded completion scopes; Chapter 6 keeps
its separate user-accepted research limitation. Chapter 16 does not need to be
started anew after n16. The proposed next book phase is final integration and
source/coverage reconciliation, including stale Chapter 15/16 research prose.
Do not edit hash-bound integrated ledgers without refreshing affected evidence.
The full textbook PDF/private extraction remain absent; official code and
errata are present. No further source attachment is needed for current reducer
work. See the report for the complete assessment and primary-source register.

All prior root-only execution, 30-second/one-CPU/thread/1-GiB/default-limit,
three-axiom, no-unchanged-retry and fresh-complete-closure rules remain in force.
Continue authorized development after this requested status report; checkpoint
publication is durability work, not Chapter 15 completion.

## Latest continuation — checkpoint 213

Checkpoint213, `adwh-lean-213-reflection-verified-nat-only-proof-repairs.zip`, is a standalone recovery snapshot containing all checkpoint212 payload paths and the new accepted reflection result. No prior ZIP or chat memory is required for the selected sources and evidence. Restore the pinned SDK and reproducible binary dependencies separately. **The stock Lean numeral theorem remains open. Continue the user's authorized work after publishing checkpoints.**

### New accepted mathematical and numerical result

The three diagnosed reflection proof corrections passed the complete fresh source/native gate: 24 fresh modules,154 accepted roots,26 subprocesses and94 artifacts in23.36454244100605 seconds, peak796004KiB. The canonical actual checker returned `ACCEPT ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512`; its numerical child took7.666948686004616 seconds and17236KiB. The generic reflection laws, original Word16 source adapter and certified endpoint were all freshly checked. There are no fixture totals or answer assumptions in their executable definitions. This is external compiled numerical acceptance together with universal Lean proofs, not yet the stock numeral theorem or an installed validating-kernel theorem.

The corrected source preserves all16 theorem headers,5 executable definitions and10 reflection roots. The other23 selected sources are exact. The new gate retains all12 execution/enforcement functions unchanged (run and main also text-identical); only preflight and a new proof-overlay validator select the correction. Root independently reviewed92 bindings and234 source-review occurrences. The old39/52 scopes remain separate from the new17-input correction review. The original failed attempt remains intact. New consumed fingerprint: `ef97064dc4fb980f6c1e9ed49d30d4279f205bf58dfe3edfe693877110e45e51`; report SHA `bfb829741652a52e126bf0288cb292e991157c958f8027f43eb96454c06a3ed0`. All92 snapshots have exact canonical mappings;52 raw logs and94 live artifacts were rehashed. Its dedicated saved reader is pending at this snapshot cut; never replay the accepted workload merely for auditing.

The original reflection failure now has a separately reviewed saved-evidence reader. Root passed both live and source-only modes. Its historical recovery record's reader-pending field is preserved as an old-cut statement; the new review/receipt records the completed audit.

### Nat-only route and actual diagnosed correction

The first Nat-only reference proof/export gate failed in its new fourth module after1.583017391996691 seconds,503436KiB. The first3 modules/26 roots passed; all10 reports of the failed module are unaccepted. The exporter was not reached. Actual errors were the private zero binder lint, an unsuccessful arithmetic proof and dependent-ite rewriting. The source contains no admission. Report SHA `97ef6ab808cb39915e2c3b7d3ae71542722cb87cf5891238fcfab63010e3d761`, consumed key `fd05279880917e977af10199b0848e2ed632b03c5d73f262c46e771f5a688513`. Fifteen exact snapshot mappings,42 bindings,eight logs,six prefix output identities and the actual root receipt remain recoverable. Dedicated saved reader pending.

Root authored four proof-only repairs under `structural-nat-only-proof-corrections/`; counting_route independently reviewed24 inputs. The three executable bodies and10 public theorem headers are unchanged. The private zero parameter is alpha-renamed, the arithmetic proof composes exact Nat iff lemmas, and the two dependent rewrites use simp only. A truncated private-header inventory value was repaired before compilation; its original inventory and exact metadata explanation are preserved. The earlier empty prepared_objects array was always correct; a withdrawn inspection concern caused no edit or gate failure. The corrected four-module/36-root actual export gate is being prepared and is not selected in this snapshot cut. Do not retry the unchanged failed source.

The expression-major Nat/zero-selector component now has its independent18-input source review. The local-WHNF component retains its16-input review. `kernel-nat-only-controls/` is a frozen physical assembly of30 logical origins in3fresh modules/90roots/6default outputs. It explicitly selects the shared Scalar/Low variants and retains all original standalone component scopes. Its126-input independent assembly review and exact3-import inverse are included; the complete fresh gate remains pending.

`kernel-nat-only-whole-count/` is a complete frozen source draft of11new modules,65public roots,48private headers and44direct author inputs. It contains lifted open templates, capture-safe substitution, actual Nat difference/zero tests, selected-head transfer, branch/count/evaluate normalization and explicit pure fuel thresholds. It prospectively uses the corrected logical reference and shared Scalar/Low; no new physical whole-count gate is selected. The final literal evaluate threshold is45 + depth*(41 +17*width), with local-loop threshold7. This is a pure reducer bound, not total computation cost or cached-checker success. Independent full source review, actual exported-body/annotation match and fresh complete compilation remain pending.

### What to do next

Root alone executes compilers, native mathematical programs, generators/exporters, metadata preflights and saved-evidence readers. Agents only read/edit/hash source and controls. Continue the corrected Nat-only reference export gate, review/run the complete Nat-only controls, independently review the higher chain, establish actual stored-body correspondence and prove cached forward success into the original Installed/GroupChecked contract. Existing cached simulation is one-way and does not supply that missing forward theorem. The new general reflection result is useful but does not close this integration gap.

Every newly selected mathematical closure must freshly include all selected upstream/experimental dependencies in one cumulative30-second,one-CPU/thread,1-GiB/default-limit interval. No prepared experimental object, split budget, metatheory exemption, source admission or unchanged retry is authorized. Keep old failures and markers. The integrated project remains unchanged and its accepted verification evidence is preserved. Checkpoint212's actual upload and clean-restore receipt is now included. Make and promptly expose further standalone checkpoints without stopping the authorized mathematical work.

## Latest continuation — checkpoint 212

Checkpoint 212, `adwh-lean-212-reflection-diagnostics-and-nat-only-route.zip`, is a standalone recovery snapshot. It retains every checkpoint 211 payload path, all prior accepted achievements, the next two actual failed experiments and the frozen Nat-only source route. No earlier ZIP or chat memory is required for these selected sources and evidence. The pinned toolchain and reproducible binary dependencies remain separately restorable. **The stock `cqueens 16 = 14772512` theorem is still open. Continue the user's authorized work after publishing checkpoints.**

### Actual new experiments

The ordinary-field complete selector gate failed at 30.22823879700445 seconds and 907,192 KiB. Core itself completed; Foundation completed with 56 accepted roots. The final selector was deadline-killed with no diagnostic, report or output. Its 90-root closure remains unaccepted. Source fingerprint `c7debf15856e214669589796f1f1913bea165d79a33d4013b8e13a185b03594b` is consumed. Its full report, six logs, marker and 16 canonical snapshot mappings are retained. Root independently reviewed its saved reader and passed both live and source-only modes. Four initial unexecuted controls remain physical, and the three descriptive provenance corrections remain explicitly separate from preflight or mathematical failure.

The first-row reflection proof/native gate then failed on concrete proof diagnostics after 10.829759938002098 seconds and 789,892 KiB. Nineteen dependencies passed, with 128 accepted roots. FirstRowReflection exited 1: an unavailable q after a substitution pattern, an unresolved firstChild/solutionsQ mapped-sum goal and two unused simp arguments. All ten reports from that failed module are unaccepted, including compiler-generated error placeholders. No source admission was inserted. The native linker and actual n16 computation were not reached. All input/output integrity postchecks passed.

That reflection attempt selected 24 fresh Lean/C modules, 154 roots, 26 total commands and 94 expected artifacts under one budget. Its fingerprint `9347a908caea495bf245c1780ab23ba687a04ead28ee6c5da6ded87bd6cb2221` is consumed. The raw report, 40 logs, permanent marker, root preflight/run receipts and 76 exact canonical snapshot mappings are retained. The 78 produced original/prefix artifacts have recorded identities; binaries are omitted from the ZIP. A dedicated new saved-reader is still pending, explicitly recorded in its recovery map. The generic checkpoint verifier validates all retained bytes. A separate frozen reflection-proof-corrections component makes three diagnosed proof edits and preserves all executable definitions and theorem headers. Its author inventory is included, but independent review and a new complete gate are pending. Do not retry the unchanged source or relax lint settings.

### Reusable source work, with precise acceptance status

`first-row-reflection/` contains the general first-row pairing theorem and exact original Word16 adapter; `first-row-reflection-nat-checker/` contains the independently reviewed endpoint/driver and complete gate. The endpoint still names the actual original source and uses the same canonical parser. Its run/correct fields select the universal reflection wrapper together. The failed candidate remains immutable. The correction must preserve executable definitions and theorem statements.

`structural-nat-only-reference/` contains a new source program with two bounded Nat folds and three additional Nat zero-test recursors. Ten public proof bodies establish universal equality to StructuralNatReference and FirstOrderNat, including modulus zero and arbitrary natural states. Root independently reviewed all source, exact correspondence, 26 bindings and body recipe. This is source review, not compilation. Root selected a separate complete four-module/36-root proof and actual raw-export gate. Its frozen author controls are included, awaiting root control review and first execution. The actual new exported bodies must be inspected before claiming their stored-body recognition.

The open positive selector branch must use `Expr.liftLooseBVars 2 0`; closedness and exact substitution must justify the later unlifted operational shape. Nat.recCompiled may compute the ignored recursive argument, so the new reference is a logical program, not an asserted fast native implementation. The accepted masked exact evaluator remains the native backend through universal equality.

`kernel-nat-expression-major/` contains frozen author source and controls for arbitrary-expression Nat major preparation/iota/head proofs, preserving the accepted literal interfaces, plus a closed zero/positive selector that discards its recursive argument through actual certified beta steps. Its 18-input component inventory is rehashed, but independent proof review and compilation are pending. Its standalone accepted-base dependency plan remains a separate scope.

`kernel-local-whnf/` relocates twelve exact generic local-loop/delta/weakening blocks under a new namespace, with ten public roots. Counting_route independently reviewed root's mathematical source; root checked its metadata and whole-file reconstruction. It is a component-only review. The eventual joint selection must explicitly choose the shared-operations Scalar and Low variants because the old accepted Scalar source lacks the public shared alias used here. The expression-major component's earlier standalone plan must not be silently relabeled.

The Nat-only higher proof adaptation is now in progress: exact new templates/guards, lifting and substitution, selected-head transfer, branch/count/evaluate normalization and explicit fuel bounds. It must replace every former Bool selector obligation with actual Nat-major runs; dropping Bool imports alone is not a proof. New actual export correspondence, complete operational compilation, cached forward success and original record integration remain open.

`kernel-explicit-fuel-bounds/` preserves the independently reviewed additive old-program proof candidate with pure threshold `29 + (41 + 17 * width) * depth`, 5037 at width/depth 16. It is uncompiled and does not bound total work or cached-checker fuel. The new cached fixed-fuel assessment records the missing forward-run theorem: existing simulation is one-way success-to-pure and does not turn a pure fuel bound into success of the flushed cached checker. The original GroupChecked-compatible macro/fallback contract remains a target, not an implemented installation.

### Recovery and next work

The latest accepted numerical workload remains checkpoint 209's external compiled ACCEPT, 25.57449162499688 seconds complete /13.22057051298907 seconds numerical execution. It is preserved and does not establish the stock numeral theorem. The integrated project remains unchanged. Checkpoint 211's actual publication/clean-restore receipt is now included.

The aggregate source audit preserves 46 independent review scopes, 2061 input occurrences and 520 canonical paths, plus separately identified pending/source-assessment inventories. It is a durability hash check, not fresh mathematical acceptance. All selected new proofs remain subject to the unchanged root-only execution policy: one complete fresh closure in 30 seconds, one CPU/thread, 1 GiB, default resource settings and only propext/Quot.sound/Classical.choice. No reused experimental objects, upstream exemption, split budget or unchanged retry is authorized.

Next: complete the three diagnosed reflection proof corrections and a fresh full native test; review the expression-major Nat component; run the new reference proof/export stage; and continue the actual-reducer/cached-checker integration. Keep making source/evidence checkpoints without treating them as completion of the mathematical goal.

## Latest continuation — checkpoint 211

Checkpoint 211, `adwh-lean-211-beta-failure-and-ordinary-fields-reviewed.zip`, preserves the complete checkpoint 210 payload and the next substantive source/evidence work. It is a standalone recovery snapshot; no earlier ZIP is needed. The integrated library and accepted achievements are unchanged. The stock `cqueens 16 = 14772512` theorem remains open. Continue the authorized work after publishing a checkpoint.

### Actual beta experiment and recovery

The complete shared-beta selector attempt failed at 30.22363517100166 seconds and 908,292 KiB. Fresh Core and Foundation completed, with 56 accepted Foundation reports. The final selector was killed at the wall limit with empty stdout/stderr and no output files. The 90-root complete closure, including three new generic beta helpers, is unaccepted. This supplies no individual theorem timing or measured beta speedup.

The raw report, six logs, permanent marker, exact sources, reviews, controls and 19 canonical snapshot mappings are retained under `kernel-shared-beta-selector/`. Root reviewed the standalone saved-evidence reader and successfully ran live and source-only modes. Its actual receipt and independent review are included. Source key `6532e9d4739bdf260f6dfe719f51829e00d9625cd54487dfb0e5a03d5a8d7fc4` is permanently consumed.

The first metadata preflight had failed before any Lean process or marker reservation: short theorem names were compared with qualified names. Exactly three schema comparisons were corrected without changing any mathematical source, policy, source fingerprint or execution lifecycle. Eight old controls have explicit recovery mappings; six unique old metadata files are retained physically. The successful second metadata preflight and actual mathematical attempt are separate evidence. Restoration does not authorize an unchanged retry.

### Next source-cost candidate

`kernel-ordinary-fields-core/` replaces three computed-field blocks (Name.hashData, Level.hashData, Expr.data) with ordinary safe computable definitions and the same deriving handlers. All eighteen constructor equations and all other Core proof/executable bytes remain exact. Four full inverse edits are independently reviewed, including the explanatory notice. Root's review binds 71 direct inputs. No candidate compilation has occurred in this checkpoint.

The pinned Lean compiler source assessment explains the additional computed-field implementation types, constructors and overrides, while recording that ordinary recursive functions have their own compilation costs. There is no measured speed claim and no claim of identical native representation or generated private names. Ordinary recursive Expr.data could be slower during native checking. The prospective next full selector still requires all 29 origins, 90 roots and six outputs freshly in one gate. Its physical layout/gate is being prepared separately; consult current files before execution.

A proposed noncomputable pure-reference shortcut was rejected for the unchanged full checker: BasisGen actually executes pure annotateCore during #annotate_basis/#annotate_pins elaboration. The exact source obstruction is retained in `kernel-pure-reference-codegen-assessment/`. No source or gate implements that shortcut.

### Concrete checker contract and further work

`kernel-original-record-contract/` records a smaller relative integration target: produce the original typed GroupChecked result, then use an exact macro/fallback worker equality to preserve the existing installation theorem. This is a contract, not an implemented macro or completed soundness proof. Fixed-fuel success remains a real obligation.

A source trace identifies an important query shape: an auxiliary equality with `Nat.add (StructuralPrimitiveReference.evaluate ...) 0` forces the cached full-WHNF call used by the proposed seed. A direct equality on the evaluator follows a different reduction path and does not establish that outer cache lookup. The answer is computed data, never a proof premise. Actual Eq/Eq.refl typing, restricted-prefix pins, annotation and complete fixed-fuel pending checking remain to be proved.

An isolated additive higher-proof draft is being developed toward explicit pure fuel bound `29 + (41 + 17 * width) * depth` (5037 at width/depth 16). It is not frozen or included in this checkpoint, and is not a compiled theorem or cached-checker bound. A separate general first-row column-reflection assessment is in progress; its list theorem can be general in n while this book's fixed-width bridge must retain n≤16. Neither work item is accepted or measured yet.

### Exact boundary and execution policy

The latest accepted numerical workload remains checkpoint 209: 22 fresh Lean/C modules, 141 roots, 25.57449162499688 seconds total, 13.22057051298907 seconds for the n16 native call. Its canonical external ACCEPT is preserved. It is not the stock numeral theorem or an installed validating-kernel result.

Root alone runs gates, compilers, generators, native mathematics and saved-evidence auditors. Each selected complete new closure remains fresh within a cumulative 30-second, one-CPU/thread, 1-GiB gate with default resource settings and only propext, Quot.sound and Classical.choice. No upstream exemption, object reuse, budget split, unchanged retry or resource override is authorized.

Checkpoint 210's actual upload and clean restoration receipt is included. Compiler binaries, compiled objects and the full external upstream proof checkout remain reproducible separately pinned dependencies. The new retained primary-source excerpts make their particular assessments readable without that checkout. Publication is a durability action, not completion of the user's mathematical goal.

## Historical continuation — checkpoint 210

Checkpoint 210, `adwh-lean-210-seeded-model-bridge-reviewed.zip`, is a standalone
source/evidence snapshot. It retains every checkpoint 209 payload path and the
earlier accepted mathematical results. The integrated project and accepted
ledger are unchanged. The stock `cqueens 16 = 14772512` theorem remains open.
Continue the authorized work; publication of a checkpoint is not completion.

### Exact numerical result remains preserved

The accepted masked native workload remains the checkpoint 209 result:
22 fresh Lean/C modules, 141 accepted roots, 25.57449162499688 seconds for the
complete proof/C/link/native workload and 13.22057051298907 seconds for the
actual n16 call. It prints the canonical original-source ACCEPT with result
14772512. This is external numerical acceptance, not a stock numeral theorem
or an installed validating-kernel result.

The dedicated success auditor and independent recovery review are now complete.
Root read the auditor and ran both live and source-only modes successfully;
the actual tool results are in `uint64-masked-count-lintfix/ROOT-AUDIT-RECEIPT.json`.
It verifies 59 current snapshot mappings, 48 logs, 88 recorded artifacts and
the 141 ordered reports, together with the original-only pool and historical
source-review scopes. The two actual generated C files remain retained. Keep
the earlier failed worker snapshot at its actual attempt path. Historical
RESULTS/map descriptions retain their preparation-time status; the later receipt
records completion rather than retroactively rewriting them.

### Shared-iota attempt failed; no new selector acceptance

The newly reviewed shared-iota candidate adds one actual reducer theorem and
specializes it in four existing cases, preserving every old public statement
and runtime definition. Its three-module, 29-origin, 87-root complete-01 gate
failed at 30.21896726200066 seconds and 908,764 KiB. Core passed in
14.962436557005276 seconds; Foundation passed in 1.5698740380030358 seconds
with 56 reports; the selector was killed after 13.476049285003683 seconds,
with empty logs and no output files. No theorem position or individual proof
cost follows from that silence.

Raw report: 166,852 bytes, SHA-256
`51f3a94fc15a53636ce47ae1509f2d33847a1c4502b882a8c7b5e4088cff78fe`.
The source key `6b316fd4a57c35d7f79ab23e7bc10e34eb786d671a6b72735df52d3a613d8dab`
is permanently consumed. All identity postchecks passed; the complete output
inventory and mathematical gate failed. Root's live and source-only evidence
audits passed 18 canonical snapshot mappings, 154 direct bindings, 136
historical references, six logs and four artifact identities. Their actual
receipt is in `kernel-shared-iota-selector/ROOT-AUDIT-RECEIPT.json`.

The component's five proof edits, current two import edits, predecessor
29-origin assembly and 24-edit legacy Core overlay retain distinct inverses.
The six reviewed scopes are 57/17/48/25/25/52, totaling 224 input occurrences
over 116 canonical paths. No failed prefix objects may be reused as acceptance.

### Concrete checker integration is reviewed, not compiled

`kernel-seeded-pending-check/` contains the actual post-flush, prefix-restricted
cache update and pending checker. It preserves the original inference,
annotation and equality checks. Its distinct `SeededGroupChecked` proposition
records success of the new driver and implies the actual pure pending check
at some fuel; it does not manufacture old fixed-fuel `GroupChecked` success.
Root's independent source review binds 26 inputs and nine prospective roots.

`kernel-seeded-install-run/` adds deterministic exact-query discovery in the
actual pending type/value and an ordered all-record checking function that
constructs its own typed `SeededFullyChecked` evidence. The actual upstream
installation-model argument is adapted at its one phase-B simulation call.
The model and real push chain derive prefix validity and full lookup agreement;
an arbitrary valid prefix is not assumed instead. Root reviewed both sources,
all six proof-slice inverses, 27 inputs and the thirteen new report commands.
The upstream SetTheory hypothesis remains explicit. Frontend/CLI wiring,
actual exported-declaration checks and all fresh proof acceptance remain open.

The exact dependency inventory is now independently recomputed. A proposed
phase-B extraction reaches 101 upstream modules and 16 existing resource-option
occurrences. The new model's direct upstream union reaches 509 modules,
9,945,616 source bytes and 114 resource-option occurrences; original InstallRun
reaches 510/115. These are source counts, not measured build costs. Project
query/evaluator dependencies are additional. Raw upstream overrides and other
source compatibility have no exception under current policy. The local
insertion-law/phase-B extraction opportunities do not remove the full model
obligation. No smaller complete installation-soundness theorem was established.

`kernel-masked-count-query-guard/` is a separately reviewed three-substitution
overlay selecting the accepted masked evaluator in the existing query interface.
All other source bytes and contracts remain exact. Its seven roots and seventeen
review inputs are uncompiled at this combined boundary. A future closure must
select exactly one query module version; old review scopes remain unchanged.

### Next substantive proof-cost experiment and fixed policy

`kernel-core-proof-census/` found only a small closed unused seven-law subset
of 1,381 declaration bytes. The large remaining substitution proofs are used by
the whole-count chain. It does not justify another tiny-cut gate or a timing
claim. The current next source hypothesis shares five beta-reduction chains
through generic three/four-argument spine lemmas and a known-lambda head lemma.
This work is in progress and not an accepted result in this checkpoint.

Root alone runs compilers, gates, mathematical generators, native programs and
saved-evidence auditors. Every selected complete new closure remains fresh
within one cumulative 30-second, one-CPU/thread, 1-GiB gate, with default resource
settings and only propext, Quot.sound and Classical.choice. Preserve all permanent
markers and meaningful failures. No unchanged retry, upstream-metatheory
exemption, budget split or resource override has been authorized.

Checkpoint 209's actual saved-copy and clean-restoration receipt is included.
Source/evidence recovery needs no previous ZIP. The pinned compiler, omitted
objects and full external upstream proof checkout remain reproducible build
dependencies, separately identified in RESTORE and the new source inventories.

## Previous continuation — checkpoint 209

Checkpoint 209, `adwh-lean-209-masked-evaluator-native-accepted.zip`, is a standalone source/evidence snapshot. It retains every checkpoint 208 payload path and all earlier mathematical achievements. The integrated project and accepted ledger remain unchanged. The stock Lean numeral theorem `cqueens 16 = 14772512` remains open; do not stop at this checkpoint.

### Actual reusable masked-evaluator success

The corrected masked evaluator complete01 passed all 22 fresh experimental Lean/C modules and 141 ordered axiom reports, native compile/link and the canonical original-source n16 certificate. The exact output is `ACCEPT ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512`. The complete workload took 25.57449162499688seconds at 793,388KiB; the native call took 13.22057051298907seconds at 13,888KiB. There were24 commands,88 artifacts and59 read-only source/control snapshots. All final identity/output checks passed. Raw report 319,825 bytes SHA256 `229b123eeda36f20cd1e2edb7f70fde30e22a2c4800c96e5174f3435d1c44828`.

The source key `ff976527a651e033c99d83ef3641e63e37f205a0bad77587bf2adfcf82dc45a8` is permanently consumed. Only the existing seven-original ADWH pool supplied 21 copied objects; its separately recorded preparation cost is unchanged. No experimental object was reused. Checkpoint200's older recorded whole/native times were 29.918614695998258/18.04023222399701seconds. These are individual observations, not repeated statistical timing or larger-board evidence.

The universal operation/worker/source refinements are ordinary freshly checked Lean proofs. They preserve arbitrary Nat depth/budget/fuel, the stated width/range domain, saturation and the total exact Nat fallback. The original adapter remains Word16/depth16; a broader classical-board interface requires a separate width-parametric bridge. The compiler's actual generated worker/helper C is retained in `uint64-masked-count-lintfix/emitted-c-evidence/`: the targeted dynamic moduli are replaced by bit operations. No expected-answer premise or hand-tuned count fixture was added to these proofs.

The earlier masked complete01 failed on the strict unused `hl` binder diagnostic after 108 accepted / 120 observed reports, 10.681264573009685seconds, without native execution. It is retained unchanged. The separate one-character `hl` to `_hl` correction keeps the hypothesis and all proof/executable bytes, except that binder spelling. All other 21 source rows are exact; named-argument ABI identity is not claimed. The old 33/53/22-input review scopes remain at their old worker, supplemented by an 18-input focused correction review. Root reviewed the new controls and ran the successful preflight/complete attempt. External native ACCEPT is not a stock proof of its concrete acceptance equation and not a validating-kernel installation.

`uint64-masked-count-lintfix/` retains the exact sources, correction, reviews, controls, actual preflight/execution receipt, report, 48 raw logs, marker, generated C and canonical 59-snapshot map. The old failed worker snapshot must remain physically at its actual attempt path because the new gate binds it. All binary/object omissions are explicit. A dedicated new-success saved-result auditor is being prepared separately; do not invent a completed audit from this preparation status. Root's live/source-only auditors for the original masked failure both passed and their actual receipts are included.

### Actual legacy selector failure and next proof-cost change

The legacy-format three-module selector attempt failed at 30.219782653002767seconds, 908,596 KiB. Core passed 12.665476419002516seconds with 2 outputs; Foundation passed 1.4809488659957424seconds with 56 reports and 2 outputs. RecursorSelectors was killed after 15.868104270004551seconds, with empty logs and no outputs. No theorem position or individual proof cost follows from those empty buffers. The complete 86-root closure remains unaccepted. Raw report 148,244 bytes SHA256 `4fdfe328365c7c9ebbed0afe0d6bc1af8615cdb904e38862e392bb152f55d676`; key `106e1062f715d56c049ca4c199a34de072ed2e9e88614f582af4844a7d0b2f68` consumed.

The 24 command-only Core overlay, old 29-origin assembly/five overlays, reviews and all 126 bindings remain distinct. Legacy visibility/private imports differ; module-format consumers cannot directly import this legacy Core. Root's live/source-only recovery audits passed 15 snapshot mappings,111 historical references,6 logs,4 actual output identities and147 review-input occurrences over 98 canonical paths. The exact receipts are included.

The whole-count source bundle is independently reviewed but uncompiled: 43 logical origins,148 roots,4 physical modules and8 prospective outputs. It introduces one higher assembly 182,909 bytes SHA256 `f359b7aa954c12045321e5f0d69b228d66285c4a5ec26f3c8b181dc99efc4b08`, with 24 exact import substitutions,216 declarations / 95 private declarations and no new foreign private references in the lexical census. No whole gate has been selected. Its historical reviews retain their exact scopes; a failed base cannot be reused as acceptance.

The next concrete source-cost hypothesis shares four repeated full `iotaRec` proof walks through one ordinary lemma with the same actual stored-record, constructor-spine, preparation and certificate premises. No current timing benefit or new acceptance is assumed. Separately, concrete post-flush query-cache seeding and a separately named pending-check contract are being developed against the real checker. Preserve the actual prefix lookup boundary and distinguish the changed driver from old fixed-fuel GroupChecked. Neither work in progress closes installed source recognition, whole operational normalization or the installation/model bridge.

### Unchanged execution and recovery policy

Root alone executes compilers, native programs, generators, gates and saved-result auditors. All selected new mathematical dependencies remain fresh within one cumulative 30-second / one-CPU / 1-GiB gate, with default resource settings, strict options and only propext, Quot.sound and Classical.choice. Keep all permanent markers and meaningful failures. No unchanged retry, upstream metatheory exemption or budget splitting is authorized.

Checkpoint 208's actual upload and clean-extraction receipt is retained. Recovery needs no previous ZIP; compiler/runtime and any live original-only object materialization remain separate. Continue the promised mathematical/kernel work after publishing 209. The user's goal is a reusable trustworthy computational-proof route and the actual n16 theorem, not merely another external count.

## Previous continuation — checkpoint 208

Checkpoint 208, `adwh-lean-208-selector-prefix-and-lookup-transport.zip`, is a
standalone source/evidence snapshot. It preserves every checkpoint 207 payload
path and earlier mathematical achievement. The integrated project and accepted
ledger are unchanged. The stock `cqueens 16 = 14772512` theorem remains open;
checkpoint 200's actual source-connected native acceptance and checkpoint 205's
62-root Natrec closure remain valid at their recorded boundaries.

### Actual sliced-selector result

The new three-module, 29-origin, 86-report selector experiment failed at the
cumulative wall deadline in 30.216433003006387 seconds, peak 831,156 KiB.
Core passed in 14.896235230989987 seconds with its six outputs. Foundation
passed in 1.6523940240003867 seconds with both outputs and all 56 exact reports.
RecursorSelectors was killed at exit -9 after 13.462481689988635 seconds and
produced neither reports nor outputs. Both its raw logs are empty. This does
not identify a theorem position, diagnose an individual proof or show a
speedup. The complete candidate is unaccepted; its 56-report prefix is accepted.

The exact raw report is 131,915 bytes, SHA256
`a32db0151f86bf0a0d4e5ac3609e3f7abbc760831d16603e2e106906b116e8be`.
All source, snapshot, control and runtime postchecks passed. The source-policy
key `d4ec79bc098030e20ba7221eccdddcda50e6c5a6e96921029a0e2cd394067af0`
is permanently consumed. No unchanged mathematical retry is permitted.

`kernel-sliced-selector/` retains its source assembly, all 29 origin inverses,
five source overlays, independent component/layout/control reviews, actual
preflight, raw report and six logs, permanent marker and exact recovery map.
Root read the saved-evidence auditor in full and ran live and source-only
modes successfully: 103 bindings, 30 snapshot mappings, six logs and eight
actual artifact identities. Compiled artifacts and duplicate snapshots are
omitted from the archive; their exact canonical source/evidence recovery is
retained. These audits preserve the failure and accepted prefix, not a whole
selector or numeral success.

### Reviewed source preparation

The finite-lookup implementation and its lookup-query bridge have independent
source reviews. The collector checks internal names, preserves full records
and derives agreement on exactly twenty requested keys. Guard evidence is
transported to a caller's actual prefix through explicit agreement. The bridge
copies all six fields between the distinct pin structures, recognizes the
entire query, computes its answer and supplies the actual pure-reducer run and
uniform-depth cache premise. It has no expected-answer or fixture argument.
The prefix is used only in the proof field of the lookup optimizer; no runtime
full-prefix construction is required by that interface. Successful installed
agreement, higher normalization and cache/checker integration remain unproved.

The branch-loop sharing variant is independently reviewed. One induction on
strictly smaller branch fuel supplies local bound three; the former full-WHNF
theorem is a short corollary. Exact public headers and the complete named-call
bridge are unchanged. The two contract definitions and six private helpers
move with explicitly recorded ownership; reporting locations stay unchanged.
With the separately reviewed shared-operation base it would have 43 logical
origins and 148 reports. No physical higher closure or compiled acceptance is
claimed. All source variants and full inverse records remain distinct.

The retained masked UInt64 implementation now has a completed independent
source review. It replaces two dynamic modulus operations by proved power-two
mask operations and preserves terminal priority, arbitrary Nat depth/budget,
saturating addition and the total exact Nat fallback. Its refinement is generic
on the stated width/range domain. The old emitted C already shared the low bit
with the tail, so no additional CSE gain is attributed to the new explicit let.
No new generated code, runtime gain or numerical acceptance is claimed yet.

The new masked original-counter endpoint/driver has root's independent source
review and exact inverses to the old endpoint/driver. The prospective complete
native closure has 22 fresh modules, 141 reports, 24 subprocesses and 88 final
artifacts, including the explicit ten-report source-audit module. All selected
experimental proof and code generation, native compile/link, actual n16 call
and final checks must fit one unchanged budget. Only the exact seven-original
native pool is eligible for reuse; its separate historical cost and 21 copied
files are disclosed. Frozen native controls and their completed independent control review are
retained; no native attempt or marker exists at this checkpoint. Root must
complete its own inspection and preflight before dispatch.

### Next work and unchanged boundary

Continue the justified selector/whole-evaluator route and the changed masked
evaluator experiment. A new isolated legacy-format Core source-cost variant
is being investigated after the measured Core cost. It must preserve all
declaration bodies and disclose every module/import/exposure change; changing
the imported visibility regime is not an identical exported-API claim. The
pinned parser rejects `import all` without a module header, so any legacy
variant must explicitly address that import. No such candidate's acceptance
or performance is inherited from this checkpoint's failed run.

Root alone executes compilers, gates, generators, native programs and saved
auditors. Every complete selected new mathematical/native closure remains
fresh within one cumulative 30-second, one-CPU/thread, 1-GiB gate, with default
heartbeat/recursion behavior, strict options and only the three permitted
axioms. Keep every used source marker and meaningful failure. No upstream
metatheory exemption, unchanged retry or budget splitting is authorized.

The user explicitly requested autonomous continuation until the n16 target
and continued uploads. Do not stop merely because this checkpoint is published.
Actual source/prefix recognition, whole operational refinement, a justified
validating checker and its concrete accepted artifact remain necessary for an
optimized-kernel result. External native ACCEPT is not a stock Lean proof of
the concrete acceptance equation. Preserve these evidence boundaries.

Checkpoint 207's actual saved-copy and clean-restoration receipt is included.
The archive needs no earlier ZIP. Compiler/runtime restoration and, for a new
live native gate, validated original-only dependency materialization remain
external build requirements. Source-only recovery audits do not require them.


## Previous continuation — checkpoint 207

Checkpoint 207, `adwh-lean-207-selector-recovery-and-query-interface.zip`,
preserves every checkpoint 206 payload path and mathematical achievement.
The stock `cqueens 16 = 14772512` theorem remains open. Checkpoint 200's native
source-connected acceptance and checkpoint 205's accepted 62-root Natrec
closure remain the latest respective execution and operational-proof successes.
The integrated project sources and its accepted ledger are unchanged.

### Actual shared-selector result

The shared-selector complete-01 attempt failed at the cumulative deadline in
30.211182990009547 seconds, peak 861,100 KiB. Core finished in
13.547379287003423 seconds; the combined proof module was killed after
16.46732915400935 seconds and produced neither required output. It accepted
zero of 78 required roots. Its 4096-byte buffered stdout contains 38 complete
permitted reports and an incomplete fragment; this cannot identify a slow
proof, prove later diagnostic absence or establish the refactor's speed.
The exact raw report is 103,975 bytes, SHA256
`0c1c6bfaea726b1705ce44b4c308e5a0058e3942b6924c73968a632b9f304908`.

`kernel-shared-selector-bundle/RESULTS.md`, the raw logs/report, permanent
marker, exact source maps, reviews and two control-correction inverse chains
are retained. The first no-run preflight found a schema-field mismatch before
any attempt reservation; its focused correction and second passing preflight
are saved separately. Root inspected the saved-evidence auditor and ran both
live and source-only modes successfully: 103 bindings, 18 snapshot mappings,
four raw logs and six actual Core artifact identities. These audits preserve
the failure, not mathematical acceptance. The source-policy key is consumed.

### Prepared reusable interfaces

The four-file higher shared-substitution variant has independent source
review. Twelve repeated proof bodies now apply the shared Nat lemmas; all
68 original statement headers and 20 reports remain unchanged. The coherent
thirteen-module higher order selects KernelCountLoop and excludes the original
KernelCountInduction module. With the shared selector base it would contain
42 origins and 140 reports. This is a logical plan, not an accepted physical
build or a resource-feasibility result.

CountQueryGuard has independent source review. It recognizes the entire
six-literal structural evaluator expression, checks actual typed Nat/Bool/
program/arithmetic guards, computes its answer using the proved total UInt64/
Nat evaluator and derives the actual pure-reducer run. There is no expected
answer or count fixture parameter. Its cacheClause supplies the uniform-fuel
premise of the retained cache insertion law; no cache insertion or checker
patch has been performed. The guard and higher operational chain remain
uncompiled, and successful recognition of actual installed exports is unproved.

The restricted-lookup assessment identifies exactly 20 queried names. A future
checked finite extraction must verify returned records' internal names and
prove requested-key agreement. The guard evidence must then be transported
to the true declaration prefix using actual restricted-lookup agreement.
The full underlying Env of a restricted FEnv is not that prefix; the reducer
must not be run in the finite inspection environment. Source implementation
still being prepared outside this publication is not a recovery prerequisite.

### Next source-cost revision

The isolated kernel-shared-operations candidate adds eight public aliases to
unchanged existing operational proofs and replaces eight duplicate later
bodies with qualified applications. Original headers, visibility, definitions,
pins, arguments, fuel bounds, imports and options remain unchanged. It has
independent source review and exact full inverses. Selecting it with the
previous eight-origin layout would require 86 reports. No measured speedup or
compiled acceptance is claimed. Preserve the frozen predecessor attempts.

The separate optional PropWhen-law slice is retained as an author-prepared,
uncompiled candidate. It omits 36 proofs and fifteen simp registrations while
retaining every computational declaration, constructor invariant and required
isNever fact. Its exact inverse and explicit-reference census are retained;
implicit simplifier use still needs actual elaboration. The broader checker
assessment distinguishes a small insertion lemma from complete acceptance.

Continue the actual selector/whole-count path with substantive, reviewed
source or dependency improvements. Every selected new mathematical dependency
must compile freshly in the same 30-second, one-CPU/thread, 1-GiB gate, with
default heartbeat/recursion/output behavior and the three permitted axioms.
No unchanged retry, upstream metatheory exemption or splitting a selected
closure across budgets is authorized. Actual prefix recognition, the revised
validating checker and its complete success/soundness connection remain open.
Existential pure-run/cache premises alone do not prove the existing driver's
fixed-fuel success. Read the cache-seam assessment before integration.

This snapshot includes checkpoint 206's actual saved-copy and clean-restoration
receipts. It remains standalone source/evidence recovery, with no earlier ZIP
dependency and with external compiler/runtime restoration required. The older
accepted Natrec section below remains valid historical evidence.


## Previous accepted recursor checkpoint — 205

Checkpoint 205, `adwh-lean-205-nat-recursor-verified.zip`, is a standalone
source/evidence recovery snapshot. It retains every checkpoint 204 achievement
and adds the first accepted actual Nat-recursor contracts, the exact preceding
compact/bundled failures, and reviewed source proofs for the inner counting
fold. The integrated chapter sources and successful project ledger are
unchanged. The stock Lean theorem `cqueens 16 = 14772512` remains open; the
actual native result from checkpoint 200 is preserved and has not been rerun.

### Actual Nat-recursor closure accepted

`next-iteration/kernel-bundled-reference/gate/attempts/complete-02/report.json`
records a passing fresh build of eight physical modules covering all 28
mathematical source origins. All 62 required reports and all 20 default outputs
were accepted in **27.806141771987313 seconds**, peak **834,908 KiB**. Raw report:
105,714 bytes, SHA256
`f44b12bcdb20a4ec5171556d55eda94aa9d766ea34666b0257ae8bcd3e8f26e4`.
The unchanged resource policy is one cumulative 30-second budget, one CPU and
compiler thread, 1 GiB, default heartbeats/recursion/compiler options, strict
warnings, and only `propext`, `Quot.sound`, `Classical.choice`.

All eleven Natrec roots now pass, alongside the 51-root foundation. The local
accepted `source/KernelNatRecursor.lean` is 31,624 bytes, SHA256
`126beff77f617603e5da5bc0662d3c64ee8962645e9ca6262cbf7dda79e358df`.
These are conditional theorems about the actual ConLeche verified reducer:
zero/successor iota, head reduction, application, and fuel-uniform full runs.
They do not discharge the stored environment pins or establish the whole
counter. No count, optimized kernel installation or stock numeral theorem was
part of this run.

The source bundle consolidates 21 upstream units into `KernelCompactCore`.
Exact source maps retain the original declaration/proof text except the
previously disclosed optional cuts, module/import headers and explicit EOF
scope closures. The Low import adapter and the separate three-proof Natrec
correction have exact inverses. Changed module ownership/visibility and
persistent registrations are disclosed; literal source correspondence is not
claimed to establish identical elaborated private names or full cached-engine
compatibility. Every selected module compiled freshly; no old object was an
input.

### Exact failed attempts remain failures

The compact 28-module attempt failed at 30.23736371799896 seconds with 51
accepted prefix roots and 138 partial outputs. Natrec stdout/stderr were empty.
Its failure supplies no theorem-level timing or diagnostic attribution.

The first bundled attempt finished within limits in 28.879820896007004 seconds.
It accepted the same 51-root prefix and exposed three actual free-variable
errors in `decide` calls for application-spine lengths. All eleven Natrec
reports were printed but unaccepted because that module failed; six included
error-recovery `sorryAx`. The local correction changes exactly those three
proof subterms to first expose the literal lengths 1, 2 and 3. All 25 theorem
headers, eleven roots, definitions, pins, fuel conditions and strict options
are unchanged. Independent source and gate reviews bind the actual failure
and verify both directions of the exact correction. Its passing complete-02
result does not relabel complete-01.

The earlier five recursor attempts and all exact unique source/control texts,
raw reports/logs and permanent markers remain retained. Their canonical
recovery maps preserve failed outcomes and omitted compiled-artifact identities.
Read the compact, bundled and recursion RESULTS and saved-evidence auditors.
Do not rerun accepted or failed unchanged source/policy keys, including after
restoration.

### Reviewed whole-fold source work remains uncompiled

The retained `kernel-structural-head` module exposes the actual inner
function-valued recursor at zero and successor fuel. `kernel-branch-composition`
composes the actual selector, arithmetic, child and predecessor expressions.
`kernel-arithmetic-runs` gives pointwise existential fuel thresholds for actual
operand expressions and all state updates. Its power lemma explicitly retains
the actual reducer's exponent support bound, `n ≤ 16777216`.

`kernel-count-head` exposes the outer recursor's three state lambdas and the
exact terminal selectors after their three actual argument substitutions. Its
eight proposed roots and independent review are retained, still uncompiled.

`kernel-branch-induction` proves the proposed inner-fuel induction against
those operational interfaces. Its child contract is pointwise over actual
closed argument expressions and their actual runs; the outer-depth induction
must discharge it at a strictly smaller depth. The recursive predecessor uses
the exact remaining-cursor expression and smaller fuel. No current whole-call
normalization is assumed. These source reviews found no mathematical blocker,
but none of these candidate modules has been compiled. Their historical
Natrec/Bool dependency bindings remain explicit, and a selected fresh gate
must rebind the actual accepted variant rather than silently changing review
scope.

The earlier Bool, delta, ordinary-definition spine and exact source-body work
is also retained as reviewed, uncompiled source. The three actual export-tree
comparisons establish syntax correspondence only. They do not establish
annotation, installation, environment validity or whole execution. In-progress
Bool staging, explicit Natrec proof preparation and outer-depth work outside
this checkpoint's explicit
selection are not prerequisites for recovery; continue them from the saved
interfaces and handoff if they are absent.

### Next action and kernel-integration boundary

Continue the actual Bool/selector path and whole outer-depth proof, selecting
reviewed source/build optimizations where the complete fresh closure needs
more headroom. The accepted recursor closure leaves only about two seconds
under the fixed budget; this is a measured closure cost, not a license to
exempt dependencies, enlarge limits, split unchanged work or assume uncompiled
proofs. The three Bool arity decisions have the same open-expression pattern
as the actual Natrec diagnostics. Preserve frozen source/review history when
preparing a corrected variant.

The cache-seam assessment remains a separate open obligation. Successful
`CSOK.insertWhnfC` use needs an actual pure full-WHNF run under the appropriate
environment/scoping premises. `FEnv.restrictTo` changes visibility without
removing the full underlying environment. Installation queues checks; it does
not establish their validity. Source annotations, environment pins, the
outer-fold result and actual cached-checker/driver integration must all be
connected before claiming an optimized validating kernel. The full metatheory
closure has not been shown to fit this policy.

Both accepted primitive-reference exports, the accepted structural Nat and
logical reducer foundations, the exact native sixteen-queen check, all earlier
stock numerical proofs and the current integrated project evidence remain
recoverable without an earlier ZIP. Checkpoint 204's actual clean extraction,
saved-copy receipt and source/review-input audit are retained. Compiler/runtime
binaries and compiled outputs are deliberately excluded and restored from pins.

## Exact numerical checker result — checkpoint 200

Checkpoint 200, `adwh-lean-200-cqueens16-external-check-verified.zip`, established
the following result, fully retained in checkpoint 203. The exact target
has been **accepted by a compiled, source-connected verified checker**:

```text
ACCEPT ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

**The stock Lean numeral theorem is still open.** This external acceptance is
not an ordinary proof term of the concrete equality or of the checker's
concrete acceptance premise. The integrated project and its accepted Lean 4.35
whole-project gate remain unchanged; the chapter ledger is not silently closed.
The user requested continued pursuit until the target is reached and continued
checkpoint publication/upload. Do not ask for renewed permission. Preserve the
exact external result and continue the justified proof/kernel integration work.

### Complete actual16 external check

`next-iteration/uint64-restricted-nat-checker/native-gate/attempts/complete-01/`
contains the first and only actual16 execution. Its complete gate rebuilt all
18 selected mathematical/driver modules, checked all 119 exact theorem reports,
generated fresh C, compiled/linked it, ran the exact four-token certificate,
and performed final integrity checks. The whole gate passed in
**29.918614695998258 seconds**, peak **790,848 KiB**. The concrete certificate
process took **18.04023222399701 seconds**, peak **11,952 KiB**, exited zero,
printed precisely the line above and had empty stderr. The raw report is
260,223 bytes, SHA256
ed6b8c8f8162ee0027900ca8df267cbc3227c4101ec1b362fbb3f200355fef88.

The 20 commands and all 76 final artifacts were checked. There were 37 immutable
input snapshots and 44 pinned compiler/runtime/header bindings. All 119 roots
use only propext, Quot.sound and Classical.choice as allowed. The actual
original-source UInt64 adapter and its checker instantiation passed in this
fresh closure. No prior experimental object, generated C or executable was
used. The final elapsed observation leaves only about 0.0814 seconds under the
fixed 30-second cap; it is not a robust performance margin or a larger-n scaling
result. Do not rerun the unchanged source/claim to obtain another timing.

Only 21 prepared objects for seven unchanged original ADWH modules were copied:
seven each of .olean, .ilean and native .o. Their explicit separate preparation
completed in 10.480943722002849 seconds, peak 799,192 KiB, with fourteen compiler
commands and 28 outputs. It ran no program or count. Its raw report SHA256 is
fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5.
Read `next-iteration/first-order-nat-evaluator/original-native-preparation/`.
That preparation budget is disclosed separately, not hidden in the count time.
It exempts no new mathematical module from the fresh complete execution.

### Reusable mathematics now established

`next-iteration/uint64-saturating-evaluator/` now has accepted ordinary Lean
proofs for its scalar implementation and exact fallback wrapper. Its generic-03
gate freshly rebuilt six modules and accepted all 53 roots in
2.8234893230037414 seconds, peak 503,512 KiB. Raw report SHA256:
da4760d6399ef531a109371a1c6cdb49185fec2249d3b252f80c6d29bf6a372f.
Nine roots use no axioms; the remaining profiles use only the allowed names.
The separate four-root actual-source adapter also passed in the complete native
gate, together with the canonical parser and concrete checker soundness laws.

The recursive invariant is
`UInt64Result.toNat = min ExactNatResult (2^64 - 1)`.
The total Nat-valued wrapper falls back to exact Nat computation on the sentinel
(including equality to it), unsupported widths or out-of-range masks. It
therefore assumes neither the desired answer nor an upper bound on the count.
The fast-path representation laws cover widths zero through 63, with arbitrary
budget/depth/fuel. The wrapper theorem is unconditional for all natural inputs.
The actual source adapter retains Word16 masks and depth/budget 16. Its equality
covers every input to the original source definition; board semantics beyond
that implementation's established n<=16 domain are not thereby proved.

Generic-01 and generic-02 were genuine failed proof attempts, not timings to
ignore. The first accepted 26 / observed 42 roots before two UInt64 literal-one
normalizations failed in mask proofs. The second accepted 42 / observed 51 before
two analogous terminal-case proof steps failed. Explicit rfl/local literal
facts repaired exactly those four proof steps; executable definitions and all
39 candidate theorem statements stayed unchanged. Preserve both failed reports,
logs, source/control snapshots and permanent markers. The recovery map retains
12 unique superseded inputs, mapping all 42 snapshots across the three attempts.
No recovery sorryAx diagnostic from either rejected module is an accepted root.

The earlier accepted reusable foundations remain:

- FiniteFold: nine axiom-free finite-fold equations and uniqueness laws.
- FirstOrderNat generic: two fresh modules, 18 roots, 1.1119027979948441 seconds.
- FirstOrderNat actual-source adapter: ten fresh modules, 67 roots,
  5.742802972003119 seconds; equality to the original cqueens for every input.
- RestrictedNatChecker: thirteen fresh modules, 80 roots,
  6.574911215000611 seconds; typed endpoint, canonical parser and source soundness.
- First-order native n8/n10/n12 diagnostic: outputs 92, 724 and 14,200 in the fixed
  complete 2.5806708649979555-second run. Its n12 internal interval was 21,655,703 ns,
  versus 105,247,886 ns in the retained original-shape baseline, about 4.860 times
  faster in those single observations. Those runs remain diagnostics.

The successful actual16 run uses the UInt64 evaluator, not that earlier Nat-only
native executable. Its emitted C has unboxed scalar count/branch workers and
ordinary direct recursion. Retained C permits review without rerunning the
count. Native compiler and standard primitive/runtime correctness remain the
explicit execution boundary; the Lean source proofs do not verify machine code.

### What the successful certificate does and does not establish

The endpoint type contains the actual original cqueens function. Its executable
field is the refined evaluator, and its correctness field is the proved universal
source equality. The canonical four-token parser fixes the declaration name,
input, equality sign and decimal value before evaluation. The claimed value is
only compared with the computed result; it does not control sizing, branching,
refinement hypotheses or the count. No hand-designed instance fixture or
expected-answer premise is used in this algorithmic route.

The freshly checked `UInt64QueensNatChecker.accepts_original` theorem connects
successful safe checker acceptance to the exact original equation. The pinned
native run supplies external computational validation under its recorded
compiler/runtime/I/O boundary. The report deliberately keeps universal proof
success, native invocation, canonical output, complete-gate success and stock
numeral theorem fields separate; the stock-theorem fields remain false.

Applying that theorem inside stock Lean still requires an ordinary proof of the
concrete acceptance equation. The native exit code cannot be inserted as such
a proof. `native_decide`, a new axiom, unsafe override, unchecked kernel insertion
or a name-only evaluator hook is not permitted. Adding another certificate/AST
wrapper around the same external call does not by itself close this gap.
A justified optimized kernel must validate actual source recognition/installation
and successful reduction, and connect that path to its concrete checked proof
artifact. A custom accepted export must also be distinguished from a stock
.olean recheck. The source-based concrete completion assessment is the next
research direction, not another unmodified numerical run.

`next-iteration/reusable-evaluator-direction/` retains the pinned integration
and kernel contracts. The full upstream project has not been built or
executed. The selected 21-module logical kernel reference is now freshly
checked with the disclosed compatibility/optional-optimization changes. The
large full checkout/archive remains an omitted reproducible external dependency. There is no established generic program-hook theorem and no proven
default-limit compatibility for its full proof closure. Do not silently exempt
upstream metatheory or split a selected new proof closure across fresh budgets.


The low-operation bridge proposed after the external result is now accepted in
checkpoint 202's logical-reference complete-02 gate, as detailed above. Its
original deadline failure and later proof-script failure remain preserved.
The next construction is the whole structural-reference connection through
actual annotated recursor/beta steps and exact source recognition. A separate
power-of-two operation candidate remains independently reviewed but uncompiled;
it has no selected numerical rerun or measured speedup. Preserve these scopes
and every genuine attempt when continuing after restoration.

### Fixed execution and recovery rules

Only root executes Lean, native programs, counters and computation generators;
review agents inspect source and saved evidence. Each selected complete fresh
mathematical/native closure shares one 30-second, one-CPU, 1-GiB budget, default
heartbeats/recursion, strict warnings, Lean `-j1 -M1024` and the permitted axioms.
The source-keyed markers and all failed attempts remain permanent. The actual16
identity includes its exact canonical argv. Reacquiring external dependencies
is not authorization to erase markers or rerun accepted instances unchanged.

All earlier accepted work, source-bound evidence and standalone recovery maps
remain selected, including checkpoint 195's stock cqueens6 source proof and the
common-payload codec repair. Source-only saved-evidence auditors do not execute
Lean, native checkers or counters. The checkpoint 199 clean extraction and all
six then-current auditors passed; its separate recovery-validation JSON is
retained. The documented 198 ZIP-mode auditor correction and original scripts
remain available. Read RESTORE and the current RESULTS/recovery maps for the
new generic, original-native and actual16 evidence. Compiler/runtime objects
and executables are deliberately omitted; all needed source and exact evidence
identities are retained without any earlier ZIP dependency.

## Prior checkpoint 197

The previous standalone recovery snapshot was checkpoint 197,
`adwh-lean-197-common-payload-padding-verified.zip`.
Recovery requires no earlier archive. The complete supplied kernel-validity report and invalid-export
attachment are now preserved unchanged under
`next-iteration/kernel-validity-reconciliation/attachments/`. Read that parent's
README, formal review and regression results. The report is no longer missing.

Checkpoint 197 completes `next-iteration/common-payload-padding/`. Separate
producer/replayer variants use the maximum of node and claim payload widths,
append only the necessary zero padding, validate malformed natural inputs
before widths/shifts, and reject nonzero unused fields. Actual constant values
determine widths; expected-answer metadata is ignored. The exact inverse check
preserves both original main() bodies and their old trace/CLI/cap guards.
All twelve finite synthetic scalar-codec tests passed in the fixed Python gate:
0.19858322300569853 seconds, peak 38,616 KiB. Its report SHA256 is
dc6254ec03d56f16550507d2aa4c83ec48b3b11bd237a35ca29d6c256ccc0838.

The universal CommonPayloadPadding helper is accepted by the ordinary Lean
4.35 kernel. Its first complete gate freshly rebuilt all three modules and
accepted all 239 required roots in 7.89377424599661 seconds, peak 700,396 KiB.
Each of the nine new roots uses exactly propext and Quot.sound. They quantify
over arbitrary layouts, payload lists and rows, with no board size or expected
count. The report SHA256 is
292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8.
Read README, both RESULTS reports, the independent source/gate/result reviews,
and SNAPSHOT-RECOVERY. Preserve both execution markers; do not rerun unchanged.

This repairs the reusable representation boundary. It proves neither Python
implementation correspondence nor a new source count, larger producer,
compression bound or optimized kernel. The latest complete numerical source-count
fixture remains checkpoint 195's packed-row cqueens6 result. The integrated
project and n16 target are unchanged. Follow RESEARCH-DIRECTION for the user's
priority: reusable input support or a measured, proved evaluator/kernel
optimization, rather than another local n6 refinement.

Checkpoint 196's `next-iteration/instance-schema-contract/` remains the source-only
adaptation contract and independent review. Most semantics are already generic.
The smallest supported-language adaptation can preserve ConsolidatedGeneric
byte for byte and put fixture-local codecs and four specialized field-transport
proofs in the new Arithmetic source. The new universal padding helper supplies
an independently accepted option for those field transports.

The contract identified a concrete n16 encoding restriction: the frozen packer
and independent replay required node payload width to be no larger
than claim payload width, equivalent to valueWidth <= nodeIdWidth + 2. A stored
final value 14772512 would need at least 24 bits, so a trace with nodeIdWidth < 22
would fail that old representation restriction. The separate common-payload
variants and general Lean contracts above repair this boundary without changing
the frozen originals. Widths still derive from actual trace values, never an
expected-answer premise. No complete new instance or count is claimed.

Read the contract's complete field, witness, routing, arithmetic, factor,
site/line/wire and source-clause obligations. A new larger producer still needs
the distinct compression mechanism and fixed actual-boundary evidence required
by `next-direction-review/README.md`; then a source proof needs a complete trace.
Neither enabling n7, repeating a prefix, nor rechecking n6 codec compatibility
supplies that evidence. No larger producer execution is selected. This condition
does not block a different general evaluator/kernel route. Existing user authority
continues; the obstacle is missing mathematical/experimental evidence.

The user's updated kernel report is now preserved and reviewed in
`next-iteration/kernel-validity-reconciliation/upstream-update/`. Its exact
SHA-256 is d05d355ea13915cef372cfec2e5b951ed6152c2c1425c76d83a0257300f39a16.
Pinned sources corroborate the field-count repair at nanoda 0.4.27 and both
nested-recursor repairs at the 0.4.28 mainline merge; the assessed 0.4.29
revision retains them. The shipped Lean 4.35 nanoda remains 0.4.19. The newer
regression matrix is supplied report evidence, not a new execution here.
The added paranoid-mode wording must be qualified: the recorded six individual
checks imply failure of the all-checker conjunction; they are not a separate
observed Lake paranoid-workflow run. Flattened axiom-name identity and trusted
native primitive definitions remain documented boundaries. No checker was
adopted or changed, and existing user authorization to investigate remains in
force; future experiments need their own reviewed protocol, not fresh permission.

The completed new source experiment is `next-iteration/packed-equality-refinement/`.
Pinned kernel source shows that identical expensive split-formula atoms are
already shared, so isolated split factoring was rejected before execution.
The new equality comparator unions XOR differences and masks once, with an
unconditional equality theorem for arbitrary selectors and list widths. Its
generator preserves the original nine-source count closure except one helper
import and the two node/claim-check proof bodies. The new full boundary is ten
fresh modules and 381 required roots. Generic-01 passed all 233 roots in
8.643420584 seconds. Full-01 passed all 381 roots in 28.854135757 seconds,
peak 972,692 KiB, and rechecked the original cqueens6 source theorem. Its report
SHA-256 is edc7a0d339267ee92324855ddd9d73b26adbd827fb78968b2429e424739a4882.
The actual generic-01 report, fdce4dee22beb2167a5b03ff9653c8f3d346d09c3821e69402fdd91ece47c6cb,
is correctly bound and frozen in a read-only full control snapshot. All ten
mathematical modules were rebuilt; only the fourteen permitted original
objects were copied. This result supplies no useful new resource headroom
against the earlier 27.281-second observation; it is not a controlled causal
comparison. Retain the universal equality proof, but do not rerun the experiment.

The latest `next-iteration/packed-row-descriptor-cache/` route is accepted.
Its four-width layout uses a guarded total lookup, an immediate left-hand row
mask after one table shift, and fixed field extraction. The concrete 7,010-digit
hexadecimal word has 28,037 significant bits and represents all 738 preserved
descriptors. Ninety-three ordinary page checks and one balanced semantic proof
with 92 range joins establish exact reference equality. All 36 original
expansion propositions and the entire final source module are preserved.

Generic-01 passed all 234 roots in 7.765072037 seconds, peak 700,716 KiB.
Its actual report SHA-256 is
20ea0102c00d569747f473fde269b9e019e8a0c9ce423502d0ada13c76156c5a.
Full-01 freshly checked all ten mathematical modules and all 479 roots in
25.786490249 seconds, peak 981,228 KiB, rechecking the exact source theorem
cqueens 6 = 4. The full report SHA-256 is
2c471bf8d936228009ca6233948b5a4fc38b0d1175131d167cc3132f5f602fd3.
Both independent audits verify all raw roots and the permitted axioms, actual
generic report/snapshot/marker linkage, ten source/nine control snapshots,
23 historical references and 34 objects (14 original copies plus 20 fresh).
No tree/equality helper object or prior experimental object was reused.

The observation leaves 4.213509751 seconds and 67,348 KiB below the full
limits. Relative to baseline191 it used 1.494699295 fewer seconds and
73,208 KiB more peak RSS. This is an observed time/memory tradeoff, not a
matched causal benchmark or evidence that n16 fits. Read RESULTS and the
independent generic/full reviews. Preserve both execution markers; close this
exact candidate without a rerun, page-size sweep or budget increase.

The new NEXT-SCALING-ASSESSMENT identifies the separate larger-instance
obligations. No complete n7 ADD fixture was found in the inspected retained
inventory; the retained n8 ADD traces are incomplete at the fixed 50,000
operation cap. The existing packed node/claim codecs, witnesses, routing
capacity and source generators still contain n6-specific widths and geometry.
In particular, the retained n8 trace has 210 wire variables, beyond the
seven-bit rank representation. Generalizing this cache's Layout did not
generalize that whole pipeline. The instance-schema contract reported above
now covers those fields and source obligations, distinguishing the necessary
per-instance changes from optional abstraction. It supplies neither a new
compression mechanism nor a complete trace. Do not relabel n8 prefixes as complete.

The historical compact n8 certificate really reaches cqueens 8 = 92 on Lean
4.33, but its generator replays a pinned 409-node tree at six fixed reuse sites
and retains 80 singleton leaves. It is not a general larger-board producer or
ADD input. Its old cost is not a new Lean 4.35 result. Keep projected-context
paused and do not infer a larger-board execution mandate from the cache pass.
The integrated project and the still-open n16 target remain unchanged.

The retained `next-iteration/page-composed-descriptor-cache/` route is accepted.
It retains the same 738 descriptors and total lookup, but replaces one
monolithic descriptor check with 93 checked leaves and one balanced proof
using 92 applications of a universal fork lemma. Both concrete aliases are
explicitly unfolded. The original 36 expansion propositions and the entire
final source module are unchanged. The new module has a distinct identity
while deliberately preserving the old internal namespace and helper bodies.

Generic-01 failed on the invalid Bool.and_eq_true.mpr reference; generic-02
rewrote the checks but left (true && true) = true open. Their failed fork
reports contain error-recovery sorryAx and are unaccepted. Exact corrections
and all unique source/control versions remain recoverable. The final explicit
Bool.and_true true step passed in generic-03: 8.526747557 seconds,
698,176 KiB, all 234 roots. Its report SHA-256 is
099b833d49cd66f7d4aba28d87959d856abbb993801c418b5286a825d588206a.
The fork lemma itself has no axioms.

Full-01 freshly checked all ten mathematical modules in 27.527305750 seconds,
peak 945,328 KiB, with all 479 required reports accepted and only the three
allowed axioms. It rechecked the exact source theorem cqueens 6 = 4. The
report SHA-256 is
4a3e052ebf38ee498ed0061b1e6a3265b864407d2960a91e95612e3d0c5272b7.
The actual generic-03 report is bound and snapshotted correctly. All ten
source/nine control snapshots, 28 historical references and 34 objects
(14 permitted original copies plus 20 freshly compiled objects) verify.
Read RESULTS and the independent generic/full reviews. Do not rerun this
completed experiment or reset its marker. It establishes a complete source
proof organization, but supplies no useful new headroom against baseline191;
the timings are not a controlled causal comparison or an n16 scaling result.

Checkpoint194's source-only packed-row plan is retained byte for byte as
`packed-row-descriptor-cache/SOURCE-ASSESSMENT.md`; the later implementation
and complete result are reported above. Pinned primitive-source evidence
supports native literal shifts/masks, scalar normalization of the concrete
masked row and the small-left-mask copy rationale. The large suffix still
has allocation costs; raw suffix-value bounds are not RSS bounds.
`explicit-proof-source-feasibility/` separately rejects wholesale printed
proof/replay substitution as the next step; it neither identifies tactic
elaboration as the measured bottleneck nor bypasses fresh source checking.
Projected-context remains paused and n16 is open.

The retained structural cache experiment in `next-iteration/paged-descriptor-cache/`
has finished with an accepted generic helper and a failed complete gate.
The exact 738 descriptors form 92 eight-record pages and one two-record tail,
with a balanced size-indexed tree, contiguous coverage and total lookup.
Generic-01 was rejected for nine deprecated proof aliases; the precisely
recorded replacement with current names passed in generic-02: 8.282702034
seconds, 697,924 KiB, all 233 required roots. Its report SHA-256 is
d96b8474ccc1ddb77aab5a43e87cc69e4d76d227bfe85b76b07520f76c992d60.

Full-01 failed at the concrete lookup bridge: `simpa only [Nat.zero_add]`
left the explicit lookup term on one side and the `pagedNodes` alias on the
other. It completed in 27.067857685 seconds, peak 1,041,852 KiB, without a
watchdog event. Eight earlier modules passed (270 accepted reports); the
failed Arithmetic module emitted 91 reports, 43 tainted by error-recovery
`sorryAx`, and none of its reports are accepted. Source was not attempted.
The totals are 361 observed / 270 accepted / 385 required. The raw concrete
cache-check report lists only propext, but its failed enclosing module prevents
treating it as an accepted milestone. Full report SHA-256:
689655eae2a6f4a61c628733534d9375dbae1ad2047655cb3dcaae24055eba34.

Read RESULTS, DEVELOPMENT, FAILURE-DIAGNOSIS and both independent result
reviews. The correct generic-02 report was bound and frozen; all ten source
and nine control snapshots, 23 historical references and original-object
copies verify. Preserve the full marker and frozen source/control versions.
Do not rerun the full experiment with a simple alias fix or claim resource
failure, speedup or count acceptance from it. Checkpoint 193 contains the
unique helper, deterministic generator, results and exact snapshot recovery
map. The separately checked page proposal was implemented and accepted under
the distinct complete boundary reported above; this old full failure and its
marker remain unchanged. The pinned lifecycle source audit in this directory
supports separate checker-state ownership per theorem, not a measured RSS
drop or a causal explanation of the old peak.

One fixed six-checker negative control reproduced bundled nanoda's successful
exit on `bad : False` with no axioms; the other five checkers diagnosed an
application type mismatch. This invalid export is negative test evidence, never
an ADWH premise. No kernel was patched or adopted. Existing ordinary-kernel
ADWH derivations and the accepted all-six certificate result remain intact.

The complete `next-iteration/hoisted-view-checks/` route is now accepted.
Its single `full-01` gate freshly rebuilt all nine modules in 23.727831765 seconds,
peak 763,460 KiB, with all 121 actual required axiom reports. Eight new generic
results justify using the already checked view table to eliminate repeated
cofactor view-validation checks. The original `proofs_checked` proposition and
all sixteen final relation endpoints are recovered. Seven original modules and
all 2,439 data/metadata records remain unchanged. Independent post-run review
verified all 69 distinct recorded bindings and raw reports; no log recovery.
Read RESULTS.md and FULL-RESULT-REVIEW.md. Do not rerun this fixed gate or reset
its full execution marker. Historical timings are not a matched benchmark.

The follow-up `next-iteration/hoisted-expansion-count/` proposal encountered two
preserved failures. Original-import preparation exhausted the fixed policy at
QueensBitsPrimitives (30.042108718 seconds cumulatively; recorded peak 1,168,564
KiB). Its five earlier compiled modules are not an accepted complete import
pool. Separately, generic-01 failed in the old list-based CNF interface, which
changed in Lean 4.35: 8.093997821 seconds, 649,316 KiB, zero accepted reports.
The expansion helper itself never compiled and no full count gate ran. The
existing source proof really depends on the universal primitive certificate;
dropping that import would not preserve the target. Read the failure reviews
and PRIMITIVE-DEPENDENCIES before choosing the next action. Do not repeat these
unchanged attempts or raise their limits.

The new `next-iteration/symbolic-word16-primitives/` route is accepted in its
isolated namespace. The exact original Word, bit, low, bits2 and
PrimitiveCertificate declaration bodies are copied unchanged. Ordinary
symbolic proofs establish least-set-bit identification, strict subtraction
decrease, and the exact ordered bits2 recurrence for every Word16 value, with
no value enumeration. Complete-02 rebuilt both modules freshly together in
0.776588671 seconds, peak 491,036 KiB, with all seventeen required axiom reports
accepted. Only propext, Quot.sound and Classical.choice occur. Earlier failed
proof-script attempts and their actual corrections are retained. Read RESULTS,
SOURCE-REVIEW and the result review; do not rerun the accepted gate unchanged.

The original-namespace refinement is now accepted under that directory's
source-refinement/. Refinement-01 rebuilt the entire eight-module closure
freshly in 7.285628826 seconds, peak 794,400 KiB, with all 24 required reports.
The reversible generator changes exactly 64 private chunk proof bodies, keeps
all 79 original declaration headers and the complete dispatch/public suffix,
and checks the unchanged recursive bits program. The refined copy removes
the old resource overrides and passes under defaults. Each actual proof
application checks the definitional equality of the copied and original
primitive predicates. Integrated project sources remain unchanged. Read
RESULTS and RESULT-REVIEW; do not rerun refinement-01.

The separate next-iteration/legacy-list-clause-compatibility/ helper is also
accepted: generic-01, 0.310033594 seconds, 492,660 KiB, six required and accepted
reports. Explicit LegacyListCNF names retain the old list semantics and prove
exact clause representation round trips and clause/formula evaluation
preservation for every assignment. No Std name is shadowed. Exact historical
and current source/license evidence and independent result review are retained.

The combined route is now accepted in
next-iteration/legacy-list-clause-compatibility/count-migration/. Its sole
full-01 gate rebuilt all nine new mathematical modules freshly in
27.281189544 seconds, peak 908,020 KiB, with all 378 actual required axiom
reports accepted. The final theorem is the original source_cqueens_six:
BitRepresentation.cqueens 6 = 4. Its full statement/proof suffix and all six
literal executor definitions remain unchanged. The exact scoped BitCounting
prefix through cqueens_eq_queens_count is retained; only the Examples import
and three unrelated convenience suffix theorems are explicitly omitted.
The CNF identifier mapping and every source refinement have exact inverses.

The full gate used exactly fourteen objects from a separate successful
seven-module original-only preparation (7.278098570 seconds, 797,832 KiB).
Those seven source dependencies are unchanged and independent of every new
primitive/helper/counting module. All eighteen new mathematical objects were
produced inside the full gate. No earlier experimental object was reused.
The generic-01 strict-warning failure and the one-argument proof correction
remain recorded; generic-02 accepted all 233 roots before full-01. Read RESULTS,
FULL-RESULT-REVIEW and NEXT-STEPS. Do not repeat these completed experiments,
reset their markers, or raise limits. The final report is SHA-256
bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa.

Independent audit found a recording defect in that full report: a shadowed
Python path variable made accepted_generic_gate.report identify an older
kernel-comparison report, and the actual generic-02 report was not frozen in
the full run's control snapshots. The correct generic-02 checks had executed,
and all nine mathematical modules were rebuilt independently in full-01.
GENERIC-PROVENANCE-ADDENDUM.md and GENERIC-PROVENANCE-AUDIT.json separately bind
and re-audit the actual generic-02 evidence, without claiming it was originally
captured. The mathematical pass is verified with this explicit provenance
qualification. Raw runner, report and markers are unchanged; a separate
future-use patch fixes the variable shadowing. Do not present the original
report as having flawless generic-provenance metadata.

This is a current Lean 4.35 complete source proof for the existing n6 result.
The canonical historical three-bundle proof remains unchanged and accurately
labelled Lean 4.33 evidence. The integrated project is still unchanged; this
isolated source refinement is not a newly merged whole-project gate. No matched
speedup comparison or n16 scaling result follows. The next work must address
the remaining actual counting/certificate scale with a new reviewed design,
using the accepted generic refinements and preserving the fixed resource policy.
The projected-context experiment remains paused. The n16 theorem remains open.

Checkpoint 186's accepted total-lookup refinement remains preserved, together
with its completed probe and rejected congruence experiment. Do not rerun those
unchanged. The current integrated sources and complete project gate remain
unchanged. The report supplies no ordinary acceptance equation or missing count
bridge; con-leche's already proved instantiation-cache cap is not a new feature
to add. The projected-context semantic experiment remains paused. No board
above eight has been attempted. Continue toward the still-open original target
`cqueens 16 = 14772512`, preserving useful accepted certificates and publishing
standalone checkpoints after substantive results.
