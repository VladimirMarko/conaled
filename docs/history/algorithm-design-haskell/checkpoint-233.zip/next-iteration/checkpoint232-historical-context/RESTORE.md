# Restore the ADWH Chapter 15 work

This checkpoint is a standalone recovery snapshot. Unpack it into a fresh
directory. It contains `project/` and the selected active `next-iteration/`
directories at their working relative paths. No earlier checkpoint is needed.

Every published checkpoint has this same recovery role. A label describing a
mathematical result or a source review says what changed, not what kind of
backup it is. Attach the latest ZIP when starting a new chat and ask the new
agent to read CONTINUATION and RESTORE first. The saved handoffs, sources and
evidence carry the selected work; chat memory is not a recovery dependency.

This is not a full machine image or a fully offline build environment. Restore
the pinned compiler and required compiled dependencies separately. The full
textbook PDF/private extraction and complete upstream kernel proof projects
are not bundled. The exact 195/196 comparison and limitations are documented
in `next-iteration/common-payload-padding/DURABILITY-REVIEW.md` in this snapshot.

The remaining goal is:

```lean
ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

**The stock Lean theorem is still open.** The exact sixteen-queen statement
has been accepted by the freshly compiled source-linked external numerical checker. This
snapshot preserves that concrete result and its proved source connection;
it does not mislabel it as a stock-kernel numeral proof.

## Checkpoint 231: accepted routing and preserved interpreter diagnostics

Read both active continuation sections and
`next-iteration/checkpoint231-current-state.md`. Continue the authorized work
on the still-open stock numeral and original installed-kernel endpoints.

Foundation134 remains accepted. The larger Interpreter185 run failed in one
iota proof scope after27.61938600800204seconds:8accepted/185observed,
peak876532KiB. All1374 snapshots, six logs, the report and consumed marker are
retained with exact canonical recovery mappings. Its177-report proof owner is
not accepted. A distinct diagnosed correction is the next task, not a retry.

The original word-foundation59 run failed in two Routing proofs. A separately
reviewed repair then passed all five Routing owners and37 reports. Addition
failed at one `omega` residue-normalization step, leaving that complete59 run
failed at37accepted/59observed in3.49208853100572seconds, peak509216KiB. Both
consumed attempts and their125/163 snapshot mappings and10/12 logs remain.
The three new actual results have root receipts and RESULT-AND-NEXT notes.

InstalledGuard22 and RecordComposition4 now have full independent source
reviews. The frozen PendingCertifier1545 and Integration26 author packages
remain explicitly pending independent review/compilation. The newly frozen
Adjacency19/184 author package is also included with independent review pending.
New in-progress proof repairs and complete n6 substitution work are outside
this fixed cut unless named in its selection review. No ordinary
numeral, complete query, original installation or GroupChecked claim is added.

The previous230 publication/clean-restoration receipt is included. All previous
payload paths remain; original review arrays, control corrections and failed
source keys remain distinct. New mathematical work freshly rebuilds its entire
selected closure within one unchanged30-second, one-CPU/thread,1-GiB budget,
with default limits, strict warnings and the same three permitted axioms.

The explicit storage-only guard is justified by measured selected bytes in
checkpoint231-selection-review.json. Restore the exact runtime separately via
session215-runtime-restoration.json. Clean ZIP verification requires neither
a prior ZIP nor the omitted SDK binaries, objects, duplicate attempt trees,
full textbook or upstream metatheory. Byte restoration is not a saved-result
proof reader or another Lean run.

## Checkpoint 214: status assessment and verified source recovery

The current snapshot is `adwh-lean-214-status-and-integration-roadmap.zip`.
It preserves every checkpoint213 payload path and adds the requested report,
the exact user-supplied post-cut handoff, and new clean-restoration/narrow-audit
evidence under `next-iteration/status-review-214/`. No mathematical source or
accepted/failing experiment was changed, and no new mathematical gate ran.

The complete supplied213 archive and current integrated/n6 source bindings
passed a fresh clean extraction. The new narrow identity reader can be run
without a compiler, exporter, counter, runtime binary or previous ZIP:

```text
python3 -I next-iteration/status-review-214/audit_recovery.py
```

It checks50 recorded source-review scopes,2246 input occurrences/562 canonical
review paths,92 reflection and15 Nat-only-failure snapshot mappings,60 logs,
and limited saved reflection-result fields. It is not a complete dedicated
result reader and supplies no new theorem acceptance. Its source was
independently reviewed before root's successful execution.

The corrected Nat-only36-report/export success in3.37seconds is reported by
the user's later quotation but its exact run artifacts are not in the supplied
213 archive. Read the saved handoff before scheduling execution: the old cut's
absent marker does not authorize an unchanged retry. The exported-body
comparison was reported as starting, not completed. All pending source,
annotation, cached-forward and original-record obligations are in REPORT.md.

Use this standalone archive for selected source/evidence recovery; restore
the pinned SDK and external dependencies separately when live development
requires them. The stock numeral theorem remains open. This checkpoint's own
publication/verification receipt is produced after packaging and is not claimed
as part of its earlier payload.

## Checkpoint 213: verified reflection and Nat-only proof repairs

The latest snapshot is `adwh-lean-213-reflection-verified-nat-only-proof-repairs.zip`. It retains all7825 checkpoint212 payload paths, all accepted achievements and actual failures. No earlier archive is needed. Pinned SDK and reproducible binary dependencies are separately restorable; compiled experimental objects are omitted and cannot be reused in a new complete gate.

The corrected reflection gate is accepted:24fresh modules/154roots and actual canonical n16 numerical acceptance,23.36454244100605 seconds complete. Its92source/control snapshots map to exact canonical files in `reflection-proof-corrections/SNAPSHOT-RECOVERY.json`;52logs and the consumed marker/report are stored. The new dedicated saved reader is pending at this cut. Canonical source and byte evidence is complete. The stock numeral theorem remains open.

The original reflection failure's independently reviewed reader now supports source-only recovery:

```text
python3 -I next-iteration/first-row-reflection-nat-checker/audit_saved_result.py --source-only
```

Root passed live and source-only modes. The earlier ordinary-field saved reader remains available and passed on clean checkpoint212 restoration. The original Nat-only reference failure records15canonical snapshot mappings and8logs; its dedicated reader remains pending. The corrected source is separately reviewed and uncompiled at this cut. Nat-only control and higher-source assemblies are explicitly frozen pending work, not mathematical acceptance.

Read the newest continuation section before choosing a gate. Do not rerun consumed attempts. Checkpoint212's actual publication and clean-restore receipt is included; checkpoint213's own receipt belongs in the following snapshot. Resume the authorized work after restoring and auditing selected bytes.

## Checkpoint 212: reflection diagnostics and Nat-only route

The latest standalone snapshot is `adwh-lean-212-reflection-diagnostics-and-nat-only-route.zip`. It retains every checkpoint 211 payload path and all earlier accepted achievements. Restore the ZIP itself; an older ZIP is unnecessary. Restore the pinned compiler and any required original-only prepared binaries separately as documented. Do not import old experimental objects into a new complete mathematical gate.

The ordinary-field selector failure has a complete standalone saved-evidence reader:

```text
python3 -I next-iteration/kernel-ordinary-fields-selector/audit_saved_result.py --source-only
```

It checks 225 bindings, 16 canonical snapshot mappings, six raw logs, the exact failed full attempt and 56-root accepted prefix. Root passed both live and source-only modes before packaging. Keep all four unexecuted initial metadata controls and the consumed source marker. The descriptive correction did not consume a separate mathematical attempt.

The reflection failure retains the raw report, 40 logs, consumed marker and actual root execution receipt. Its 76 duplicate snapshots map to exact canonical files through SNAPSHOT-RECOVERY.json. A dedicated reader for this latest failure is still pending; the map was checked against actual snapshot bytes, and every canonical file is retained and archive-hashed. Nineteen prefix modules/128 roots passed, but the failed reflection module contributes no accepted report and no native call occurred.

The new reflection and Nat-only sources have explicit individual review statuses. The expression-major Nat candidate is frozen author source awaiting independent review. The generic local-WHNF component has an independent source review but its joint dependency selection is pending. The old explicit pure-fuel candidate is reviewed and uncompiled; cached forward success remains unproved. Read the latest continuation before selecting any new gate.

Checkpoint 211's actual saved-copy and clean restoration receipt is included. Checkpoint 212's own postpublication receipt belongs in a later snapshot. Continue the authorized work toward the stock numeral theorem after recovery; checkpoint publication is a durability action.

## Checkpoint 211: beta failure and reviewed ordinary-field candidate

The latest standalone snapshot is `adwh-lean-211-beta-failure-and-ordinary-fields-reviewed.zip`. It retains every checkpoint 210 payload path, the accepted masked native result and earlier mathematical achievements. The stock numeral theorem and installed validating-kernel acceptance remain open.

The shared-beta complete-01 deadline failure, 56-root accepted prefix, six raw logs, consumed marker and 19 canonical snapshot mappings are retained. Its source-only saved-evidence audit needs no compiler or earlier archive:

```text
python3 -I next-iteration/kernel-shared-beta-selector/audit_saved_result.py --source-only
```

Keep the six unique failed-preflight controls under `gate/preflight-01-controls/`. The two duplicate controls have explicit canonical mappings. This metadata failure preceded the sole mathematical attempt; the three-line metadata repair did not change its mathematical source fingerprint. Root's actual live and source-only saved-reader receipts are included.

The independently reviewed ordinary-field Core source is uncompiled. Its complete four-edit inverse, all 18 preserved field equations, pinned compiler-source assessment and 71-input root review are retained. The next full selector gate is under separate preparation and is not claimed executed here. The original-record contract and rejected noncomputable-reference shortcut are source assessments, not accepted checker changes. Read the latest continuation for exact remaining obligations and the unchanged fresh complete-gate policy.

Checkpoint 210's postpublication saved-copy and clean restoration receipt is now included. A receipt generated after publishing 211 belongs in the following checkpoint.

## Historical checkpoint 210: reviewed seeded checker/model and preserved proof failure

The latest standalone snapshot is `adwh-lean-210-seeded-model-bridge-reviewed.zip`.
It retains all checkpoint 209 payload paths, the accepted masked native result
and earlier mathematical achievements. No previous ZIP is required. The stock
numeral theorem and installed validating-kernel acceptance remain open.

The new shared-iota complete-01 is a deadline failure, with 56 accepted
Foundation reports, empty selector logs and no selector outputs. Its exact
source/control reviews, report, six logs, marker and eighteen canonical snapshot
mappings are retained. The consumed source key is not a new execution slot
after restoration. Root's actual live/source-only audit receipts are included.

The dedicated successful masked-native auditor is also now retained, together
with its independent recovery review and root's actual two successful runs.
After extraction, these commands require no compiler, old archive or executable
proof objects:

```text
python3 -I next-iteration/uint64-masked-count-lintfix/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-shared-iota-selector/audit_saved_result.py --source-only
```

Keep the earlier failed masked worker physically at its recorded
`uint64-masked-nat-checker/native-gate/attempts/complete-01/source/UInt64MaskedCount.lean`
path. It is an explicit input of the corrected native gate and saved auditors.

The actual seeded pending checker, automatic query discovery, all-record typed
checking result and adapted installation-model proof are preserved with their
independent source reviews. They are **uncompiled**. Their dependency graph is
recorded exactly, including 509 upstream modules and 114 raw resource-option
occurrences for the model union. That full upstream checkout is an external
source dependency, pinned by repository revision, archive digest and every
relevant module hash. The archive retains the small directly reviewed primary
copies; it does not bundle the full checkout or its compiled metatheory.
This recovery qualification does not exempt any selected future mathematical
dependency from the current complete fresh resource gate.

The separately reviewed masked query overlay must replace, rather than coexist
with, the older source of the same module in any future selection. Read the
latest continuation for the beta-chain sharing hypothesis and the unchanged
policy. The integrated project and accepted ledger remain unchanged.

The exact upload/clean-extraction receipt for checkpoint 209 is included.
A receipt created after publishing 210 belongs to a later checkpoint and is
not retroactively claimed as payload of this archive.

## Historical checkpoint 209: accepted masked native evaluator

The checkpoint 209 snapshot was `adwh-lean-209-masked-evaluator-native-accepted.zip`. It retains all checkpoint 208 payload paths and the newly accepted masked evaluator result. The complete 22-module, 141-report proof/C/link/native workload passed in 25.57449162499688seconds. The actual original-source n16 call took 13.22057051298907seconds and printed the canonical ACCEPT. The stock Lean numeral theorem and optimized validating-kernel installation remain open.

The successful attempt's report, 48 logs, exact control/source reviews, permanent marker, 59 canonical snapshot mappings and two actual generated C files are retained under `next-iteration/uint64-masked-count-lintfix/`. The earlier failed masked worker, its raw warning and marker are retained under `uint64-masked-nat-checker/`. Keep the old failed-worker snapshot at its actual `native-gate/attempts/complete-01/source/UInt64MaskedCount.lean` path; the new gate explicitly binds that file.

The new complete legacy-selector attempt also remains a failure with 56 accepted prefix reports and empty final-module logs. Its exact 15 snapshot mappings, 126 bindings, 6 logs and 4 output identities are retained. Root's live and source-only saved-evidence audits passed for this failure and the original masked warning failure. After extraction, these read-only commands require no compiler or earlier ZIP:

```text
python3 -I next-iteration/uint64-masked-nat-checker/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-legacy-core-selector/audit_saved_result.py --source-only
```

A separate new-success auditor is being prepared; consult its exact saved status before claiming it ran. Root's actual native-gate preflight, run and final postchecks are already preserved. Canonical source/evidence recovery is distinct from rebuilding executable proof objects. All complete native artifacts have exact hashes; binaries are omitted. New live compilation requires the pinned runtime and validated original-only dependency materialization, while all selected experimental proof/code dependencies remain fresh in the same unchanged resource budget.

The reviewed whole-count source assembly is uncompiled and does not inherit acceptance from any base prefix. Read the latest continuation for the shared-iota proof-cost revision and actual pending-check cache integration obligations. The actual upload and clean-restoration receipt for 208 is included; a postpublication receipt for 209 belongs to a later checkpoint.

## Historical checkpoint 208: accepted prefix and new source interfaces

The checkpoint 208 snapshot was `adwh-lean-208-selector-prefix-and-lookup-transport.zip`.
It includes every checkpoint 207 payload path, earlier accepted mathematical
results and the exact later sliced-selector failure. No earlier archive is a
recovery dependency. The integrated project and accepted ledger are unchanged.

The complete sliced-selector attempt failed at 30.216433003006387 seconds.
Its Core/Foundation prefix passed with 56 exact reports; the final selector
module timed out silently and produced no outputs. The 86-report closure and
stock n16 theorem remain open. All 30 attempt snapshots have exact canonical
recovery mappings. Keep the six logs, report, marker and map; compiled outputs
and duplicate snapshots are intentionally omitted.

After extraction, from the archive root:

```text
python3 -I next-iteration/kernel-sliced-selector/audit_saved_result.py --source-only
```

Root's live and source-only audits passed before packaging. A clean-extraction
audit and saved-copy receipt created after publication belong to the next
checkpoint, not retroactively to this ZIP. Source-only auditing reads evidence;
it does not rerun Lean or turn the complete failure into success.

The finite-lookup transport, lookup-query bridge, branch-loop proof sharing,
masked UInt64 evaluator and masked endpoint/driver have independent source
reviews, all retained with their exact inputs and inverses. They remain
uncompiled beyond the explicitly accepted selector prefix. The independently reviewed masked native
controls are a frozen upcoming experiment; consult their review and do not
invent an execution result or reuse prior experimental objects.

For continued live compilation, restore the pinned external Lean distribution
using the existing toolchain instructions. The upcoming masked native gate
also needs the exact seven-original native dependency pool. Checkpoints omit
its generated objects; its retained report/marker is historical evidence.
Missing objects require an explicitly recorded bounded materialization, with
new evidence and preserved old markers, before the new gate may consume them.
All selected experimental sources must still compile freshly in that gate.

Read the latest section of `CONTINUATION.md` for the next source-cost revision
and the actual optimized-kernel integration obligations. The mathematical
30-second/one-CPU/1-GiB policy and no-unchanged-retry rule remain in force.


## Approved Lean 4.35 migration

Start with the root `CONTINUATION.md`, then `project/CONTINUATION.md`.
The user approved updating the whole project to Lean 4.35.0 on 24 October 2026,
trying its bundled kernels, and investigating a proved custom optimization or
replacement if their improvement is insufficient. The projected-context
experiment is paused. The offered private library has not yet been supplied.

Read `next-iteration/lean435-migration/STATUS.md` and the current
`project/adwh-lean/reports/verification.json` before interpreting any evidence.
The full 4.35 gate has passed as run `6e376337ca5b4b34a679cd9588e3bfc1`, covering
1,240 source modules, 83,281 owned declarations and all 17,846 selected theorem
references. Current chapter and status records bind that run. The final snapshot
therefore binds the accepted current sources directly and omits the temporary
historical source overrides used during migration. The earlier interim archives
remain intact. Historical experimental evidence keeps its original compiler
version; migration does not imply every earlier experiment was rerun.

## Verify the restored bytes

From outside the new destination, use the included verifier:

```bash
python3 verify_durability.py /absolute/path/to/checkpoint.zip --extract /absolute/path/to/new-workspace
```

The destination must not already exist. This checks every payload, exact ZIP
membership, the accepted current integrated source/control bindings, and the complete
accepted size-six source bindings. It does not execute Lean or the counters.
Ordinary ZIP extraction also works. Unique proof sources and canonical inputs
are retained directly; the documented source-only generators recover selected
derived copies without any earlier archive.

Start with `project/CONTINUATION.md`, `project/BOOK-COVERAGE.md`, and
`project/adwh-lean/README.md`. The approved compiler pin is Lean `4.35.0`,
commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. The official archive SHA256 is
`7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d`;
exact executable hashes and bundled revisions are in
`next-iteration/lean435-migration/toolchain.json`.
Compiler binaries, build packages and compiled objects are deliberately absent.
Follow the project's pinned environment instructions to restore them.

## Current source and saved evidence — checkpoint 207

This snapshot preserves every checkpoint 206 payload path and accepted
achievement. It adds the exact shared-selector timeout and its recoverable
source/control history, reviewed higher shared proofs, a reviewed computed
query interface, the finite restricted-lookup assessment, and prepared
source-cost revisions. Higher counting/guard proofs remain uncompiled and
the stock numeral theorem remains open.

The shared-selector complete-01 gate failed at 30.211182990009547 seconds with
zero of 78 roots accepted. Its used source-policy key is permanent. The
38-report buffered prefix cannot identify a slow theorem or prove that later
diagnostics were absent. Both pre-execution control corrections, the failed
first preflight, successful corrected preflight and the actual one-time build
are retained with distinct evidence. An unchanged source-key retry is not
permitted after restoration.

The new count-query recognizer computes its answer without an expected-answer
parameter and checks the full input expression. Its conditional reducer-run
proof and cache premise remain source-only; no actual checker hook or installed
recognition has been accepted. The finite lookup proposal uses exactly twenty
names, checks internal record names, and transports guard evidence to the true
prefix. Never use the restricted FEnv's underlying full Env as that prefix,
and never substitute the finite inspection environment in the reducer theorem.

After extraction, audit the new saved failure without rerunning mathematics:

```sh
python3 -I next-iteration/kernel-shared-selector-bundle/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-selector-bundle/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-bundled-reference/audit_saved_result.py --source-only
```

The first checks 103 source/control bindings, 18 canonical snapshot mappings,
all four logs, six actual artifact identities and both control-correction
inverse chains. Source-only mode explicitly permits omitted objects/runtime;
all retained-file identities remain mandatory. Root already inspected and ran
the first auditor in live and source-only modes before publication.

Use KernelCountLoop instead of the original KernelCountInduction in a future
higher closure; their internal namespaces overlap. The higher shared variant
has exact predecessor maps and independent review. The separate shared
operational-lemma candidate preserves every original statement/visibility and
adds eight audited public aliases; it would raise the preceding selector
layout to 86 reports. The optional PropWhen proof slice is retained as an
uncompiled source candidate, with all computational declarations unchanged
and a separate warning about its fifteen omitted simp registrations. A new
physical source assembly and complete fresh gate are required.

Checkpoint 206's actual saved-copy and clean-restoration receipts are included.
No earlier ZIP is needed. The wrapper's three historical toolchain API-source
references have canonical recovery mappings in its SOURCE-INPUT-RECOVERY.json.
Compiler/runtime binaries, compiled proofs and complete upstream metatheory
builds remain omitted and must be restored from the pinned sources. Broader
checker proof closures need their real dependencies; the finite guard and
existential cache premise do not by themselves establish complete checker
acceptance or the old driver's fixed-fuel success.


## Accepted kernel operation and structural reference — checkpoint 202

The current results are in `next-iteration/kernel-logical-reference/` and
`next-iteration/structural-nat-reference/`. The former freshly accepted 47 roots
in 26 modules and proves the actual verified reducer's low-bit operation; the
latter freshly accepted 26 roots in three modules and proves the explicit
Nat-recursion reference equal to FirstOrderNat. Read their RESULTS and the
living CONTINUATION for the exact logical and execution scope.

After extraction, validate the saved accepted and failed evidence with:

```sh
python3 -I next-iteration/kernel-logical-reference/audit_saved_result.py --source-only
python3 -I next-iteration/structural-nat-reference/audit_saved_results.py --source-only
```

These commands read retained bytes; they do not launch Lean, an exporter or a
counter. Current mathematical sources are retained directly. Snapshot recovery
maps resolve duplicate snapshots to canonical sources and retain unique old
controls/source files explicitly. Source-only mode requires neither compiled
objects, toolchain binaries nor preserved readonly permission bits. Its scope
is recovery consistency, not another mathematical check.

The original unsliced timeout, first logical-reference proof failure and first
structural-reference compiler/proof failure remain visible. Their failed module
reports are never counted as accepted. The exact proof corrections and source
inverses are retained. All older accepted numerical and generic evidence is
still present; no earlier archive is a recovery dependency.

The direct-primitive preparation described in checkpoint 202 has since passed
the two proof/export gates recorded above. Whole-kernel integration remains
open; the structural export census is not a mathematical kernel check.
The checkpoint 201 clean-restore record is retained at
`next-iteration/checkpoint201-recovery-validation.json`.

## Actual-kernel proof boundary — checkpoint 201

Checkpoint 201 preserves all checkpoint 200 achievements and the first failed
fresh build for the actual ConLeche low-operation proof. Read
`next-iteration/kernel-low-operation-refinement/RESULTS.md` and the living
CONTINUATION before choosing another execution.

The selected 26-module closure exceeded its single 30-second budget while
building the 21 upstream dependencies. Twenty upstream modules compiled;
TypeChecker was killed at the deadline. The new five-theorem helper was never
reached. There were zero observed/accepted printed roots, 120 partial compiled
outputs, 30.22964570100885 seconds of elapsed accounting and 516548 KiB peak
RSS. This is a recorded fresh-build limitation, not a proof failure in the
uncompiled helper or an accepted kernel shortcut.

The archive retains all selected sources, reviews, exact pre-run controls,
raw logs/report, marker and the recovery map for all 36 source/control
snapshots. Its 21 upstream source copies and exact inverse recipes reconstruct
the original pinned bytes without requiring the omitted full upstream checkout.
The 120 partial compiled artifacts remain omitted from source recovery.

Validate the saved failed-attempt evidence after extraction with:

```sh
python3 -B next-iteration/kernel-low-operation-refinement/audit_saved_result.py --source-only
```

This audit does not execute Lean or retry the failed closure. A successful
audit means that the preserved failure evidence is internally consistent;
it does not change the attempt's failed status. Any new proof-slice or structural
reference candidate needs its own reviewed sources and complete fresh gate.

The checkpoint 200 clean-restore record is retained in
`next-iteration/checkpoint200-recovery-validation.json`. All nine actual
auditors passed. The published 200 RESTORE file misspelled the UInt64 generic
auditor as singular; the correct included file is `audit_saved_results.py`,
and the command below now uses that exact name.

## Actual sixteen-queen external check — checkpoint 200

The complete native checker accepted the exact original-source claim
`cqueens 16 = 14772512`. Its eighteen fresh proof/C modules, 119 theorem reports,
native compile/link, concrete check and final integrity checks completed in
29.918614695998258 seconds, peak 790,848 KiB. The certificate process itself took
18.04023222399701 seconds. Read CONTINUATION and the actual native RESULTS
for exact input/output, source, runtime and trust boundaries. This is a verified
external checker result, not a stock Lean numeral theorem or new kernel rule.

The separate generic UInt64 refinement/fallback proof passed 53 roots in
2.8234893230037414 seconds. Two preceding literal-normalization proof failures
and all unique historical inputs are preserved. The original seven-module
native dependency preparation is explicitly separate; it reused no old objects
and ran no counter. The full native checker rebuilt every new mathematical
module and reused only 21 disclosed original dependency objects.

After extraction, the following read-only auditors validate saved evidence
without a compiler, native executable, generator or counter:

```sh
python3 -B next-iteration/native-nat-evaluator-probe/audit_saved_result.py --source-only
python3 -B next-iteration/finite-fold-evaluator/audit_saved_result.py --source-only
python3 -B next-iteration/first-order-nat-evaluator/audit_generic_result.py --source-only
python3 -B next-iteration/first-order-nat-evaluator/audit_source_result.py --source-only
python3 -B next-iteration/first-order-nat-evaluator/native-probe/audit_saved_result.py --source-only
python3 -B next-iteration/restricted-nat-checker/audit_saved_result.py --source-only
python3 -B next-iteration/uint64-saturating-evaluator/audit_saved_results.py --source-only
python3 -B next-iteration/first-order-nat-evaluator/original-native-preparation/audit_saved_result.py --source-only
python3 -B next-iteration/uint64-restricted-nat-checker/audit_saved_result.py --source-only
```

The new recovery maps retain canonical mathematical/control sources, raw logs,
reports, permanent markers and emitted C while omitting duplicate snapshots,
compiled objects and executables. Twelve unique superseded generic inputs are
retained explicitly. Runtime and external source identities are recorded;
reacquire the pinned release before any later explicit fresh build. All earlier
selected source/evidence remains; no earlier ZIP is required.

Source-only mode validates content and roles without requiring ZIP extraction
to preserve readonly filesystem mode bits. Full/live audit keeps those mode
checks. The 198 auditor repair and its preserved original scripts are documented
in `next-iteration/source-only-recovery-permissions/`. A separate record confirms
clean 199 extraction and six successful saved-evidence audits without Lean/native
execution. The published older ZIPs and their raw reports remain immutable.

Restoration does not reset an execution marker or authorize an unchanged count
rerun. Successful external acceptance is not inserted as a Lean proof premise.
The remaining work is a justified concrete proof/kernel integration; neither
ordinary stock .olean acceptance nor chapter completion has been recorded.

## Common-payload repair and universal proof — checkpoint 197

The latest recovery point includes `next-iteration/common-payload-padding/`.
Its ordinary Lean gate passed all 239 required roots in three fresh modules:
7.89377424599661 seconds, peak 700,396 KiB. Nine new universal padding/codec
theorems depend exactly on propext and Quot.sound. Its separate Python gate
passed all twelve boundary tests and the exact source-preservation inverse:
0.19858322300569853 seconds, peak 38,616 KiB. Read README, MATH-RESULTS,
PYTHON-RESULTS, and the independent reviews for the exact scopes. This establishes
no new count or Python-to-Lean correspondence. The latest complete numerical
source-count fixture remains the packed-row n6 result below; n16 is open.

The unique helper, repaired Python sources/tests, controls, reviews, raw logs,
reports and permanent execution markers are retained directly. No generator is
needed for this new candidate. SNAPSHOT-RECOVERY maps all nine mathematical and
twenty-two Python input snapshots to unchanged canonical files in this archive;
duplicate snapshots and compiled objects are omitted. The saved raw reports keep
their original execution paths. Do not rewrite historical evidence to make
those paths local, reset a marker, or claim that restoring bytes reran a gate.

The mathematical saved-evidence auditor supports a source-only recovery check:

```sh
python3 next-iteration/common-payload-padding/audit_math_result.py --source-only
```

This mode explicitly skips absent runtime/object bindings and resolves omitted
snapshot copies through their canonical source bytes. It audits saved evidence;
it does not invoke Lean. Read the recovery map for the Python input identities
and the exact retained logs. The README and RESEARCH-DIRECTION also record the
user's priority for reusable computation and the still-open optimized-kernel
direction; preserve that intent in a new chat.

## Instance boundary review retained from checkpoint 196

Checkpoint 196 adds `next-iteration/instance-schema-contract/`. Read its
CONTRACT, SOURCE-INVENTORY and independent review before proposing a larger
fixture. These are source-only findings, with no new compiler or producer run.
All accepted packed-row mathematics and its recovery recipe below are unchanged.

Most checker and source semantics already support arbitrary instance sizes.
The minimal adaptation may keep ConsolidatedGeneric unchanged and place exact
fixture codecs and four transport proofs in the new Arithmetic source. The
frozen packer and replay needed consistent common-payload padding when node values
are wider than claim fields; checkpoint197's separate variants and universal
helper now address that boundary. This removes a representation restriction; it
does not construct a counting certificate. A different compression mechanism
with a fixed actual-boundary witness remains required before a larger producer
trial in the existing capped ADD route, and a complete trace remains required
before its source proof. This condition does not gate a different general kernel
or evaluator approach. No n7 CLI change or unchanged n8 retry is selected.

The inventory binds retained frozen inputs by relative path and hash. It does
not bind the living handoffs or require an earlier checkpoint. The source-only
recovery recipe was clean-extraction verified for checkpoint 195; its generator,
manifest, helper and required baseline inputs remain byte-identical here.
Five of the inventory's 21 source paths refer to those omitted derived copies.
Run the packed-row recovery recipe below before checking their source hashes
and line anchors; the other sixteen source files are retained directly.

## Latest accepted packed-row cache — checkpoint 195

Checkpoint 195 adds the complete accepted `next-iteration/packed-row-descriptor-cache/`
implementation. Generic-01 passed all 234 roots; full-01 freshly checked all
ten mathematical modules and all 479 required roots in 25.786490249 seconds,
peak 981,228 KiB, preserving the original `BitRepresentation.cqueens 6 = 4`.
The full report SHA-256 is
`2c471bf8d936228009ca6233948b5a4fc38b0d1175131d167cc3132f5f602fd3`.
The actual generic-01 report, its readonly snapshot and the permanent full
marker are correctly bound. Read RESULTS and both independent result reviews.
The observation has more time margin and less RSS margin than baseline191;
it is not a matched benchmark or a claim that the n16 target fits.

Restore the nine omitted derived count-source copies directly from the
retained baseline and unique current helper, with no Lean, counter, earlier
archive, old cache generator or compiled-object dependency:

```sh
python3 next-iteration/packed-row-descriptor-cache/generate_packed.py
python3 next-iteration/packed-row-descriptor-cache/generate_packed.py --verify
```

`packed-row-descriptor-cache/SNAPSHOT-RECOVERY.json` maps all 30 recorded source
and current-control snapshots to exact retained or regenerated bytes. This
proposal has no failed generic variant. Its initial source-only assessment,
pinned primitive evidence, exact hexadecimal literal generation and complete
inverse are retained. Preserve the accepted execution markers.

Read NEXT-SCALING-ASSESSMENT before choosing any larger-board work: the
surrounding n6 codecs/source geometry and the capped incomplete n8 ADD inputs
are separate obligations. The completed source-only contract above records the
exact adaptation boundary and the missing compression/trace evidence. Any new
larger-instance proposal must specify its complete input and proof obligations.
Projected-context remains paused and n16 is open.

## Accepted page-composed cache retained from checkpoint 194

Checkpoint 194 adds `next-iteration/page-composed-descriptor-cache/`.
Generic-03 accepted all 234 roots after two preserved proof-script failures.
Its single full-01 freshly checked all ten mathematical modules and all 479
required roots in 27.527305750 seconds, peak 945,328 KiB, rechecking the original
`BitRepresentation.cqueens 6 = 4`. Full report SHA-256:
`4a3e052ebf38ee498ed0061b1e6a3265b864407d2960a91e95612e3d0c5272b7`.
The actual generic-03 report and its read-only snapshot are correctly bound.
Read RESULTS, both development notes and the independent result reviews.
No n16 proof or useful new scaling headroom is asserted; do not rerun the
completed gate or reset its marker.

The unique helper, generator, current controls, raw evidence and unique failed
input versions are retained. The nine derived count-source copies are omitted.
Restore them directly from the retained baseline and helper:

```sh
python3 next-iteration/page-composed-descriptor-cache/generate_composed.py
python3 next-iteration/page-composed-descriptor-cache/generate_composed.py --verify
```

This source-only generator reconstructs the prior paged Arithmetic bytes in
memory, checks their two historical identities and then applies the current
composition edits. It does not require that omitted old derived file on disk,
an earlier archive, a compiler, a counter or compiled proof objects.
`page-composed-descriptor-cache/SNAPSHOT-RECOVERY.json` maps all 52 recorded
source and current-control snapshots to exact retained or regenerated bytes,
including fourteen distinct earlier inputs from the two failed generics.
The old reports keep their real execution paths and statuses.

Pinned theorem-checker lifecycle evidence, the explicit-proof-source assessment,
and the initial packed-row lookup design are retained too. The later packed-row
implementation is accepted as reported above; the initial design remains
separately preserved as SOURCE-ASSESSMENT.md.

## Structural cache failure retained from checkpoint 193

Checkpoint 193 preserves `next-iteration/paged-descriptor-cache/` and the
earlier accepted results. The new generic helper is accepted (generic-02,
233 roots, 8.282702034 seconds); generic-01's nine strict deprecation errors
and exact proof-name correction remain recoverable. The complete full-01
attempt failed at an alias-unfolding step in `pagedNodes_eq_cachePlanes`.
It recorded 27.067857685 seconds and 1,041,852 KiB, with no resource-watchdog
event. Eight earlier modules supplied 270 accepted reports. Arithmetic's 91
reports, including 43 with error-recovery `sorryAx`, are all unaccepted;
the final Source module was not attempted. Read RESULTS, FAILURE-DIAGNOSIS
and the independent generic/full result reviews. No new count is accepted.

The unique current helper and the six unique superseded generic-01 input
versions are retained directly. Derived copies of the nine count sources are
reconstructed from the retained checkpoint191 baseline, with no Lean process,
queen search, earlier archive or compiled-object dependency:

```sh
python3 next-iteration/paged-descriptor-cache/generate_cache.py
python3 next-iteration/paged-descriptor-cache/generate_cache.py --verify
```

`paged-descriptor-cache/SNAPSHOT-RECOVERY.json` maps all 41 recorded source
and current-control snapshots to exact retained or regenerated bytes. Old
reports retain their actual historical paths and failed status; source-only
recovery does not rewrite them or accept the failed gate. Preserve the full
execution marker. A simple bridge correction is not a new full experiment.
The distinct page-composition experiment above is accepted; it does not change
this earlier failed run or supply acceptance for that old module.

## Equality refinement and upstream report update retained from checkpoint 192

Checkpoint 192 adds `next-iteration/packed-equality-refinement/`. Its generic
gate checked three fresh modules and all 233 required roots in 8.643420584
seconds. Its full-01 gate checked all ten new mathematical modules and all
381 required roots in 28.854135757 seconds, peak 972,692 KiB. The original
`BitRepresentation.cqueens 6 = 4` endpoint is preserved. The full report SHA-256
is edc7a0d339267ee92324855ddd9d73b26adbd827fb78968b2429e424739a4882.
The correct generic report is explicitly bound and snapshotted before the full
marker; this new gate does not repeat checkpoint191's metadata defect.

The universal equality proof and complete result are retained, but this one
observation did not supply useful resource headroom. It is not a controlled
speedup comparison. Do not repeat either gate unchanged or reset its markers.
The original integrated project remains unchanged, and n16 remains open.

The unique helper is retained directly. The nine derived count-source copies
are recoverable from the retained checkpoint191 baseline with exactly one
import and two proof-body edits. Reconstruct and verify them from the restored
root, without Lean or a counting algorithm:

```sh
python3 next-iteration/packed-equality-refinement/generate_equality.py
python3 next-iteration/packed-equality-refinement/generate_equality.py --verify
```

`packed-equality-refinement/SNAPSHOT-RECOVERY.json` maps the recorded source
and current-control snapshots to identical retained or regenerated bytes.
The old gate reports still contain historical execution paths. Missing omitted
objects are not an invitation to rerun a completed experiment.

The updated kernel report is preserved exactly under
`kernel-validity-reconciliation/upstream-update/attachments/`, with its delta,
39 pinned source/API records, license and independent source audit. Later
nanoda source revisions repair the two nested-recursor defects; they do not
change the already shipped binary. Newer reported regression outcomes were
not executed here. Read the review's distinction between individual checker
outcomes and an actually observed paranoid workflow, and its remaining axiom
identity/native-primitive qualifications.

`packed-claim-factoring/` records why isolated factoring was rejected before
execution, the kernel sharing evidence, and the qualified source-operation
census. `paged-descriptor-cache/PLAN.md` is the frozen pre-execution plan for
the experiment reported above, based on checkpoint191. Its tense does not
override the later RESULTS and raw failed report. No new larger-board
experiment is claimed.

## Complete Lean 4.35 n6 source refinement retained from checkpoint191

Checkpoint 191 adds the accepted combined route in
`next-iteration/legacy-list-clause-compatibility/count-migration/` and the
accepted seven-module original-only preparation in
`next-iteration/scoped-counting-bridge/import-preparation/`.
The complete full-01 gate rebuilt all nine new mathematical sources freshly
in 27.281189544 seconds, peak 908,020 KiB, with all 378 required axiom reports.
Its final source theorem is the original `BitRepresentation.cqueens 6 = 4`.
The final statement/proof suffix and all literal executor definitions are
preserved, and explicit inverse transformations recover the original sources.
Read RESULTS, FULL-RESULT-REVIEW and NEXT-STEPS. The n16 theorem is still open.

Read GENERIC-PROVENANCE-ADDENDUM.md as well. The full run's raw report contains
a wrong generic-report reference caused by variable shadowing; the correct
generic-02 report was not included in its original control snapshots. The
independent mathematical audit verifies all nine fresh compilations and 378
roots, and a separate post-execution audit binds the actual matching generic
evidence. The raw recording defect is not silently rewritten. A separate
future-use runner patch is retained; no compiler rerun was performed to hide
or repair the historical metadata.

The separate original-only preparation took 7.278098570 seconds, peak
797,832 KiB. Its fourteen old objects have no new mathematical dependencies;
all eighteen new objects were built in the full gate. This distinction and
the exact 32-artifact inventory are recorded. No compiler or compiled object
is retained in this source-only archive. Successful reports remain evidence
of their actual recorded runs, not claims that omitted live object pools are
already materialized in a new workspace.

To check source reconstruction after extraction, run these source-only steps
from the restored root:

```sh
python3 next-iteration/hoisted-expansion-count/generate_expansion.py
python3 next-iteration/symbolic-word16-primitives/source-refinement/generate_refinement.py --verify
python3 next-iteration/legacy-list-clause-compatibility/count-migration/generate_migration.py --verify
```

The first command regenerates the omitted repeated precursor bundles from
retained canonical historical sources and the unique helper. The later
commands check exact inverse chains and all current final source bytes.
They run neither Lean nor a counting algorithm. Earlier ZIPs are unnecessary.

`count-migration/SNAPSHOT-RECOVERY.json` maps each of that route's recorded
source/control snapshots to byte-identical retained canonical files or to the
precursor files regenerated by the first command above. Five unique earlier
control versions are retained at their original snapshot paths. This avoids
repeating whole attempt trees while preserving the exact historical inputs.
The map supplies byte recovery only; it adds no evidence to the original gate
and does not supply the missing generic-02 snapshot in full-01.

The completed gate runners and saved-result audit scripts contain original
execution-workspace paths and references to omitted build/snapshot files.
Do not reset their markers or mistake a missing historical artifact for a
failed mathematical result. A future new experiment must explicitly
materialize its original dependencies from these pinned sources under a
bounded preparation record, and freshly check its entire new mathematical
closure. It must not silently reuse an old new-proof object or relabel a
historical gate. The integrated project and its accepted complete audit
remain unchanged.

## Original-namespace primitive refinement and CNF bridge

Checkpoint 190 adds the accepted original-namespace primitive refinement under
`next-iteration/symbolic-word16-primitives/source-refinement/`. The fixed
refinement-01 gate freshly compiled all eight selected modules in 7.285628826
seconds, peak 794,400 KiB, with all 24 axiom reports. Read RESULTS and
RESULT-REVIEW. The generator's exact inverse restores the original primitive
source; all executable definitions and original declaration statements are
preserved. The accepted integrated project is unchanged. Do not rerun this
fixed gate or reset its execution marker.

The new `next-iteration/legacy-list-clause-compatibility/` directory retains
the accepted six-root ordinary proof connecting the historical clause-list
semantics to the current packed representation. Its sole generic-01 gate
passed in 0.310033594 seconds, peak 492,660 KiB. Exact source, license,
representation/evaluation theorems, controls and independent reviews are
included. No current Std name is shadowed, and no count is proved by this
helper alone. A future complete gate must rebuild all new dependencies.

The subsequent combined count migration and seven-module original-only import
preparation are now accepted as described above. These component results
remain useful independent milestones. The canonical historical n6 proof is
not relabelled, and the n16 target remains open. Compiler binaries and all
compiled objects remain omitted.

## Symbolic primitive certificate

Checkpoint 189 adds `next-iteration/symbolic-word16-primitives/`. Its accepted
complete-02 gate freshly compiled both current sources in 0.776588671 seconds,
with peak 491,036 KiB and all seventeen required axiom reports. The theorem is
the exact original primitive-certificate proposition, proved symbolically for
every Word16 value in an isolated namespace. It does not enumerate word values
or use native/external acceptance. Read RESULTS, SOURCE-REVIEW and the result
review. Accepted canonical sources, unique failed proof bodies, logs, immutable
manifests and execution markers are retained; compiled objects are omitted.
Do not rerun accepted or failed attempts unchanged.

The subsequent original-module proof refinement is accepted as described
above, but not merged into the integrated project. All new sources must remain
inside any complete count gate; the old project verification does not cover
new proof bodies. The original integrated sources and gate remain unchanged.

The preceding `next-iteration/hoisted-expansion-count/` failures are also retained:
original-import preparation exceeded its resource policy at the universal
primitive certificate, and generic-01 failed on the changed CNF interface.
Neither is an accepted full count gate. Its canonical historical inputs and
source-only generator reconstruct the three omitted repeated candidate bundles;
the unique HoistedExpansion helper and complete failure logs are retained.
`generate_expansion.py` materializes those candidate sources without running
Lean or counting, and `--verify` checks the exact transformation. The historical
bundles are already included at their original project paths. No earlier ZIP is
needed for this reconstruction.

## Supplied report and complete hoisting refinement

Checkpoint 188 preserves both supplied attachments under
`next-iteration/kernel-validity-reconciliation/attachments/`, the complete formal
review and pinned primary sources, and one reproduced invalid-export negative
control. The invalid export is not an accepted theorem or an ADWH premise.

`next-iteration/hoisted-view-checks/` now contains a complete accepted source
refinement and guarded certificate. `full-01` rebuilt all nine modules freshly
in 23.727831765 seconds with 121 accepted reports, peak 763,460 KiB. Read RESULTS,
FULL-RESULT-REVIEW and the retained execution marker. This full gate is complete;
do not rerun it unchanged. The earlier generic development records are retained
as provenance, not as substitutes for this complete result.

The source-only generator `generate_hoisted.py --verify` checks exact reproduction
without executing Lean or any counting algorithm. Canonical sources and unique
failed helper proof text are retained directly; historical absolute build and
snapshot paths are not prerequisites for recovery. Compiler binaries and build
artifacts remain omitted.

The original hoisted-expansion counting attempt and its two failures remain
historical evidence. The later composed route now has the explicit CNF
compatibility proof, original-namespace primitive refinement and complete
Lean 4.35 n6 source gate described above, with its disclosed generic-report
provenance defect. The canonical older n6 result retains its actual 4.33
compiler label. The integrated project is unchanged and the n16 target is open.

## Latest lookup refinement and completed diagnostics

`next-iteration/lookup-refinement/` contains an accepted ordinary Lean lookup
refinement and complete guarded-identity gate. Read `RESULTS.md` and
`PROBE-RESULTS.md` first. The `full-02` run rebuilt all nine selected sources
in 26.577593627 seconds; all 123 required axiom reports passed. Original arrays,
defaults, source IDs and final relation statements are preserved. This is not
a replacement kernel or a new count.

The fixed lookup probe is now complete: corrected `probe-02` rebuilt all six
modules in 3.651275067 seconds, with 22 accepted axiom reports. The small
reference/direct comparison does not establish an end-to-end improvement.
The isolated `congruence/` variant failed the full 30-second gate and is not
adopted. Its sources are regenerable from the retained generator and accepted
parent; compiled outputs and repeated failed-source copies are omitted.
The failed probe preparation and its proof-only correction are explicitly
recorded; no timed candidate ran twice. Do not repeat completed experiments.

The accepted source gate can be inspected from its retained canonical source
files and report without recovering historical absolute output paths. Runtime
binaries and compiled objects remain omitted. The pinned compiler must be
restored before any future new source gate, and its ordinary `--lean` path
argument identifies the local executable.

## Important retained work

| Work | Location and scope |
| --- | --- |
| Integrated book formalization | `project/adwh-lean/`; exact current mathematical sources and correspondence, with the existing full-project verification record |
| Earlier certificate methods | `project/experiments/chapter15-queens-*`; source, generator and selected evidence, including the MICE clause-ID repair and pinned licensed generator source |
| Historical complete packed arithmetic proof | `project/experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated/`; three complete Lean 4.33 bundles, 58 modular source inputs, consolidation recipe, accepted gate and dependency audit |
| Current complete n6 source refinement | `next-iteration/legacy-list-clause-compatibility/count-migration/`; nine fresh Lean 4.35 sources, exact transformation/inverse records, accepted 378-root complete gate and independent review |
| Symbolic Word16 primitive proof | `next-iteration/symbolic-word16-primitives/`; accepted universal symbolic certificate and exact original-namespace proof replacement, with separate fresh gates |
| Explicit CNF compatibility | `next-iteration/legacy-list-clause-compatibility/`; accepted historical-list/current-packed representation and evaluation theorems, with licensed pinned primary sources |
| Current factor diagnostic | `next-iteration/lazy-factored-circuit/`; producer, independent replayer, the small n4 transcript and selected n8 outcome reports |
| Fixed cut audit | `next-iteration/cut-rank-review/`; source, fixed input once, and completed independent replay data; the old work transcript is regenerable |
| New generic laws | `next-iteration/lazy-factor-law/`, `block-grouping-laws/`, and `signed-relation-laws/`; source and accepted gate evidence |
| Earlier fixed relation experiment | `next-iteration/exact-relation-plan/` and `exact-relation-diagnostic/`; all sixteen candidates refuted, with final reports and regenerable code |
| Completed exact basis | `next-iteration/exact-basis-plan/` and `exact-basis-diagnostic/`; dimension 31 and four exact identities, one complete transcript and independent replay |
| Accepted guarded identities | `next-iteration/guarded-relation-proof/`; eight fresh sources, the four concrete pointwise identities and signed rewrites, and the successful complete gate |
| Lean 4.35 migration | `next-iteration/lean435-migration/`; official toolchain bindings, accepted whole-project gate, source compatibility reviews and completed metadata refresh evidence |
| Bundled kernel comparison | `next-iteration/lean435-kernel-comparison/`; all six accepted one fixed export, the fresh 4.35 guarded-source gate, reproduction protocol and compact measured evidence |
| Primitive-proof comparison | `next-iteration/lean435-primitive-kernel-comparison/`; one existing 1,024-case theorem, six successful process exits, five runs within the fixed resource policy, exact binding and compact results |
| Supplied kernel report and regression | `next-iteration/kernel-validity-reconciliation/`; exact attachments, primary-source reconciliation and one completed invalid-export negative control |
| Hoisted view-check refinement | `next-iteration/hoisted-view-checks/`; accepted complete nine-module guarded-certificate refinement and source-preserving generator |
| Released kernel proof contracts | `next-iteration/lean435-kernel-research/`; exact-release con-leche and con-ron source reviews, refinement guarantees and remaining assumptions |
| Prepared next discriminator | `next-iteration/projected-context-plan/`; one fixed context-support experiment with a predetermined dimension-at-most-15 screen; no experiment executed |

The complete n6 proof establishes the original `cqueens 6 = 4`. Its recorded
fresh gate was 27.329427591 seconds. All concrete certificate data required by
that proof is already encoded in the retained Lean sources; the 173 MB external
JSON and its copies are unnecessary for recovering or checking those sources.
`generate_bundles.py --verify` checks the retained modular-to-bundled source
transformation without any counting computation.

Historical experimental runners and reports contain the original workspace's
absolute paths and some historical provenance references. They are retained as
evidence, not represented as turnkey portable wrappers. The historical Lean
4.33 n6 route used ten original ADWH imports and three retained bundles; this
is provenance, not an instruction to repeat that completed route. The current
Lean 4.35 boundary is the seven-original/nine-new composition described above.
Any future experiment needs its own reviewed gate and explicit dependency
preparation. Do not reconstruct an entire history merely to satisfy an old
runner's provenance plumbing. The older mathematical import closure and source
hashes remain in `bundle-manifest.json` and its accepted gate report.

The exact-basis runner uses workspace-relative canonical inputs. Its one fixed
run and independent replay are complete: 29,360 requests, all 35 columns
covered, dimension 31 and four scale-one identities. The original 50,000-request,
one-CPU, 30-second and 1-GiB limits were unchanged. It does not rely on the old
sampled values or six counterexamples. The four guarded identities and their
signed block rewrites now have a complete accepted Lean gate: `complete-07`
rebuilt all eight selected sources in 28.019105930 seconds, with 779,936 KiB peak
child RSS and all 113 required axiom reports accepted. Its 133 local checks
shared one cumulative 30-second allowance. The only axioms are `propext`,
`Classical.choice`, and `Quot.sound`; no compiled experimental imports were
reused. These theorems concern the internally interpreted selected descriptor
table. They do not establish the rank-31 theorem, a complete factor/count bridge,
or the n16 target.

The current eight Lean sources compile directly from the retained files; no
extraction JSON or earlier representation is an input to that check. The two
source-only generators can recover the omitted extraction JSON from the three
canonical inputs. See `next-iteration/guarded-relation-proof/GENERATION.md` and
the compact180 retention recommendation for the clean generation-tree procedure.
The accepted layout uses 8-entry literal pages and unchanged 16-entry checking
ranges. The fixed projected-context support discriminator is paused; it has
not run. Complete counting integration and the bridge
to the actual lazy factor occurrence remain separate obligations. Do not repeat
an unchanged gate or increase limits.

## What was deliberately omitted

This snapshot contains selected current evidence, not every historical evidence
manifest's transitive payloads. Old logs may name omitted snapshots. Repeated
copies, obsolete generated variants, partial writes and build downloads remain
in the earlier archives/workspace but are not dependencies of this recovery
snapshot. `CHECKPOINT-POLICY.md` governs future checkpoints.

The one-time migration metadata helpers compare against checkpoint 180 and
deliberately require that separately identified historical input. Their completed
output reports and execution record are retained here. Repeating that historical
comparison is not a prerequisite for restoring these current sources or running
the ordinary full-project proof gate; this archive needs no earlier checkpoint
for those recovery tasks.
