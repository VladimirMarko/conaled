## Checkpoint 213: verified reflection and Nat-only proof repairs

The latest snapshot is `adwh-lean-213-reflection-verified-nat-only-proof-repairs.zip`. It retains all7825 checkpoint212 payload paths, all accepted achievements and actual failures. No earlier archive is needed. Pinned SDK and reproducible binary dependencies are separately restorable; compiled experimental objects are omitted and cannot be reused in a new complete gate.

The corrected reflection gate is accepted:24fresh modules/154roots and actual canonical n16 numerical acceptance,23.36454244100605 seconds complete. Its92source/control snapshots map to exact canonical files in `reflection-proof-corrections/SNAPSHOT-RECOVERY.json`;52logs and the consumed marker/report are stored. The new dedicated saved reader is pending at this cut. Canonical source and byte evidence is complete. The stock numeral theorem remains open.

The original reflection failure's independently reviewed reader now supports source-only recovery:

```text
python3 -I next-iteration/first-row-reflection-nat-checker/audit_saved_result.py --source-only
```

Root passed live and source-only modes. The earlier ordinary-field saved reader remains available and passed on clean checkpoint212 restoration. The original Nat-only reference failure records15canonical snapshot mappings and8logs; its dedicated reader remains pending. The corrected source is separately reviewed and uncompiled at this cut. Nat-only control and higher-source assemblies are explicitly frozen pending work, not mathematical acceptance.

Read the newest continuation section before choosing a gate. Do not rerun consumed attempts. Checkpoint212's actual publication and clean-restore receipt is included; checkpoint213's own receipt belongs in the following snapshot. Resume the authorized work after restoring and auditing selected bytes.
