# Checkpoint 208 selection review

This is source/evidence packaging, not mathematical acceptance. Root retains
all checkpoint 207 payload paths and the integrated accepted source/control
bindings. The new selection contains the actual sliced-selector failure with
its accepted 56-report prefix, exact canonical recovery map, reviewed auditor
and real root audit receipts. Its eight compiled outputs and thirty duplicate
snapshots are excluded; the map recovers every omitted source/control snapshot.

The newly selected source work comprises the completed PropWhen slice review,
the current selector assembly/control reviews, finite-lookup transport,
lookup-query composition, one branch-loop induction, the completed masked
evaluator review and its new source-connected endpoint/driver and frozen
native controls. None of the source-only higher, lookup or masked candidates
is promoted to a compiled theorem by packaging. The native gate has not run.

The aggregate review record verifies 25 separate review scopes, 980 direct
input occurrences and 309 distinct canonical review inputs, plus the two
separately retained older author-inventory scopes. Original scope and explicit
same-byte path resolutions remain recorded. The new reviewed inputs all
resolve inside the archive selection; no omitted SDK file or upstream checkout
is silently required for these source-only evidence checks. The old control
correction chains remain enforced by their existing saved-result auditor.

All new raw logs, the one-use marker, actual preflight receipt and precise
source/overlay inverses remain selected. Generated objects, toolchain binaries,
prior ZIPs and new duplicate attempt snapshots are excluded. Native dependency
objects remain an explicitly external live-build requirement, with their exact
historical preparation retained. The current legacy-Core investigation is
outside this snapshot and supplies no premise for any recorded result.

Both living continuations and RESTORE receive the exact retained checkpoint208
sections. Root's static source binding checks and both actual sliced-selector
saved-evidence audit modes passed before packaging. Archive construction will
perform its usual member CRC/hash, integrated-binding, n6-source and input
stability checks. A later clean extraction will check the new audit from the
archive alone. These are recovery checks and do not execute a counter or Lean.

The initial pack exceeded the prior 35-MiB storage allowance by 304,724 bytes.
Its exact partial was retained and inspected: 72 new members contributed
518,626 compressed bytes, chiefly the new Core source, binding inventory,
source/control reviews and actual failed-run evidence; no old member was lost.
The largest archive members remain inherited integrated evidence and accepted
proof sources. The reviewed new control files add a small further increment.
Use a 36-MiB allowance for this standalone snapshot, preserving the actual
source/evidence rather than dropping a recovery dependency. The 32-MiB
packager default is unchanged, as are every mathematical resource limit.
