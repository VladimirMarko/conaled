#!/usr/bin/env python3
"""Build delivered formalizations and check their transitive axiom dependencies.

Run from any directory: python3 scripts/check.py [--with-mathlib] [--lake PATH].
The original checker is preserved at recovery-notes/check.pre-fix.py. This active
version adds failure-safe reporting, kernel-check-option rejection and validation
of coverage references against the current successful compiler audit.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_AXIOMS = ['propext', 'Quot.sound', 'Classical.choice']
FORBIDDEN_TOKENS = ['sorry', 'admit', 'axiom', 'partial', 'unsafe',
                    'native_decide', 'implemented_by']
FORBIDDEN = re.compile(r'\b(' + '|'.join(FORBIDDEN_TOKENS) + r')\b')
KERNEL_BYPASS = re.compile(r'\bskipKernelTC\b')


def lean_code(text: str, *, mask_strings: bool = True) -> str:
    """Mask nested comments and, by default, strings; retain positions/newlines."""
    out = list(text)
    i, depth, string = 0, 0, False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                out[i:i+2] = '  '
                depth += 1
                i += 2
            elif text.startswith('-/', i):
                out[i:i+2] = '  '
                depth -= 1
                i += 2
            else:
                if text[i] != '\n':
                    out[i] = ' '
                i += 1
        elif string:
            if text[i] == '\\' and i + 1 < len(text):
                if mask_strings:
                    out[i:i+2] = '  '
                i += 2
            else:
                if text[i] == '"':
                    string = False
                if mask_strings and text[i] != '\n':
                    out[i] = ' '
                i += 1
        elif text.startswith('/-', i):
            out[i:i+2] = '  '
            depth = 1
            i += 2
        elif text.startswith('--', i):
            end = text.find('\n', i)
            if end < 0:
                end = len(text)
            out[i:end] = ' ' * (end - i)
            i = end
        elif text[i] == '"':
            if mask_strings:
                out[i] = ' '
            string = True
            i += 1
        else:
            i += 1
    if depth or string:
        raise ValueError('Unclosed comment or string in Lean source')
    return ''.join(out)


def write_json(path: Path, value: dict) -> None:
    """Atomically replace a report so interrupted writes cannot retain success."""
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def reject_kernel_bypass(path: Path, raw: str) -> None:
    # Keep strings: Lake can express options as quoted names.
    visible = lean_code(raw, mask_strings=False) if path.suffix == '.lean' else raw
    bad = KERNEL_BYPASS.search(visible)
    if bad:
        line = visible.count('\n', 0, bad.start()) + 1
        raise ValueError(f'Forbidden kernel-check option skipKernelTC at {path}:{line}')


def check_lean_source(path: Path, raw: str) -> str:
    code = lean_code(raw)
    bad = FORBIDDEN.search(code)
    if bad:
        line = code.count('\n', 0, bad.start()) + 1
        raise ValueError(f'Forbidden source token {bad.group()} at {path}:{line}')
    reject_kernel_bypass(path, raw)
    return code


def module_closure(base: Path, start: str) -> set[str]:
    visited: set[str] = set()
    pending = [start]
    while pending:
        name = pending.pop()
        if name in visited:
            continue
        path = base / (name.replace('.', '/') + '.lean')
        if not path.exists():
            raise ValueError(f'Missing local module {name}: {path}')
        visited.add(name)
        code = lean_code(path.read_text())
        for import_line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M):
            for imported in import_line.split():
                if imported == start or imported.startswith(start + '.'):
                    pending.append(imported)
    return visited


def source_gate(base: Path, root_module: str) -> list[dict]:
    reachable = module_closure(base, root_module)
    # Include the aggregate root: options there affect authored elaboration too.
    files = [base / (root_module + '.lean')]
    files += sorted((base / root_module).rglob('*.lean'))
    report = []
    for path in files:
        module = path.relative_to(base).with_suffix('').as_posix().replace('/', '.')
        if module not in reachable:
            raise ValueError(f'Lean module is absent from the build root: {module}')
        raw = path.read_text()
        code = check_lean_source(path, raw)
        report.append({
            'path': path.relative_to(ROOT).as_posix(),
            'module': module,
            'sha256': hashlib.sha256(raw.encode()).hexdigest(),
            'lines': len(raw.splitlines()),
            'named_theorems_and_lemmas': len(re.findall(
                r'^\s*(?:(?:private|protected)\s+)*(?:theorem|lemma)\s+', code, re.M)),
            'examples': len(re.findall(r'^\s*example\b', code, re.M)),
            'definitions': len(re.findall(
                r'^\s*(?:(?:private|protected|noncomputable)\s+)*def\s+', code, re.M)),
        })
    return report


def control_gate() -> list[dict]:
    """Check authored audit scripts/options and fingerprint verification controls."""
    paths = [ROOT / 'scripts/Audit.lean', ROOT / 'scripts/AuditMathlib.lean',
             ROOT / 'scripts/check.py', ROOT / 'lean-toolchain',
             ROOT / 'lakefile.lean', ROOT / 'lakefile.toml',
             ROOT / 'mathlib/lean-toolchain', ROOT / 'mathlib/lakefile.lean',
             ROOT / 'mathlib/lakefile.toml']
    result = []
    for path in paths:
        if not path.exists():
            continue
        raw = path.read_text()
        if path.suffix == '.lean':
            check_lean_source(path, raw)
        elif path.name in {'lakefile.toml', 'lean-toolchain'}:
            reject_kernel_bypass(path, raw)
        result.append({'path': path.relative_to(ROOT).as_posix(),
                       'sha256': hashlib.sha256(raw.encode()).hexdigest()})
    return result


def run(command: list[str], cwd: Path, output: Path) -> str:
    proc = subprocess.run(command, cwd=cwd, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, check=False)
    output.write_text(proc.stdout)
    if proc.returncode:
        sys.stderr.write(proc.stdout)
        raise RuntimeError(f'Command failed with exit {proc.returncode}: {command!r}')
    return proc.stdout


def audit(lake: str, cwd: Path, script: str, output: Path) -> tuple[dict, list[dict]]:
    data = run([lake, 'env', 'lean', '-DautoImplicit=false', '-DwarningAsError=true', script],
               cwd, output)
    records = [json.loads(line) for line in data.splitlines() if line.strip()]
    if not records or records[-1].get('status') != 'passed':
        raise RuntimeError('Axiom audit did not return its passing summary')
    summary, declarations = records[-1], records[:-1]
    if summary.get('declarations') != len(declarations):
        raise RuntimeError('Axiom audit declaration count is inconsistent')
    names = set()
    for record in declarations:
        name = record.get('declaration')
        if not isinstance(name, str) or name in names:
            raise RuntimeError('Axiom audit has a missing or duplicate declaration name')
        names.add(name)
        if not isinstance(record.get('module'), str) or not isinstance(record.get('kind'), str):
            raise RuntimeError(f'Axiom audit has invalid ownership/kind metadata for {name}')
        axioms = record.get('axioms')
        if not isinstance(axioms, list) or any(a not in ALLOWED_AXIOMS for a in axioms):
            raise RuntimeError(f'Axiom audit has unapproved dependencies for {name}')
    return summary, declarations


def validate_coverage(path: Path, core_records: list[dict],
                      optional_records: list[dict], with_mathlib: bool) -> dict:
    """Use only records produced by successful audits in this invocation."""
    if not path.exists():
        return {'status': 'skipped', 'reason': 'reports/coverage.json is unavailable',
                'checked_references': [], 'skipped_optional_references': []}
    raw = path.read_text()
    digest = hashlib.sha256(raw.encode()).hexdigest()
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError('coverage.json must contain an object')
        refs = data.get('distinct_public_theorem_references')
        if not isinstance(refs, list) or any(not isinstance(ref, str) for ref in refs):
            raise ValueError('distinct_public_theorem_references must be a list of strings')
        if len(refs) != len(set(refs)):
            raise ValueError('distinct_public_theorem_references contains duplicates')
    except (ValueError, TypeError) as exc:
        return {'status': 'failed', 'coverage_sha256': digest, 'error': str(exc)}
    # Never consult a stale optional log when that package was not requested.
    records = core_records + (optional_records if with_mathlib else [])
    by_name = {record['declaration']: record for record in records}
    checked, skipped, missing, wrong_kind = [], [], [], []
    for ref in refs:
        record = by_name.get(ref)
        if record is not None:
            if record['kind'] == 'theorem':
                checked.append(ref)
            else:
                wrong_kind.append({'reference': ref, 'actual_kind': record['kind']})
        elif not with_mathlib and ref.startswith('ADWHMathlib.'):
            skipped.append(ref)
        else:
            missing.append(ref)
    return {
        'status': 'failed' if missing or wrong_kind else 'passed',
        'coverage_sha256': digest,
        'requested_reference_count': len(refs),
        'checked_reference_count': len(checked),
        'checked_references': checked,
        'skipped_optional_references': skipped,
        'missing_references': missing,
        'wrong_kind_references': wrong_kind,
        'with_mathlib': with_mathlib,
        'scope': 'Checks theorem references against current audited declarations; '
                 'does not establish that the source-to-Lean coverage claims are complete.',
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lake', default=shutil.which('lake') or 'lake')
    parser.add_argument('--with-mathlib', action='store_true')
    args = parser.parse_args()
    lake = str(Path(args.lake).resolve()) if '/' in args.lake else args.lake
    reports = ROOT / 'reports'
    attempt = {'status': 'running', 'run_id': uuid.uuid4().hex,
               'started_at_utc': datetime.now(timezone.utc).isoformat(),
               'with_mathlib': args.with_mathlib, 'stage': 'initializing'}
    coverage = {'status': 'not_run', 'run_id': attempt['run_id']}
    try:
        reports.mkdir(parents=True, exist_ok=True)
        write_json(reports / 'verification.json', attempt)
        write_json(reports / 'coverage-validation.json', coverage)
        # Remove previous outputs before any operation that can fail.
        for name in ['core-build.log', 'proof-audit.jsonl', 'mathlib-build.log',
                     'mathlib-proof-audit.jsonl', 'lean-version.txt']:
            (reports / name).unlink(missing_ok=True)

        def stage(name: str) -> None:
            attempt['stage'] = name
            write_json(reports / 'verification.json', attempt)

        stage('source_and_control_checks')
        controls = control_gate()
        files = source_gate(ROOT, 'ADWH')
        optional_files = []
        if args.with_mathlib:
            optional_files = source_gate(ROOT / 'mathlib', 'ADWHMathlib')
        stage('core_build')
        run([lake, 'build'], ROOT, reports / 'core-build.log')
        stage('core_axiom_audit')
        core, core_records = audit(lake, ROOT, 'scripts/Audit.lean', reports / 'proof-audit.jsonl')
        optional, optional_records = None, []
        if args.with_mathlib:
            optional_root = ROOT / 'mathlib'
            stage('optional_mathlib_build')
            run([lake, 'build'], optional_root, reports / 'mathlib-build.log')
            stage('optional_mathlib_axiom_audit')
            optional, optional_records = audit(
                lake, optional_root, '../scripts/AuditMathlib.lean',
                reports / 'mathlib-proof-audit.jsonl')
        stage('version_and_source_consistency')
        version = run([lake, 'env', 'lean', '--version'], ROOT,
                      reports / 'lean-version.txt').strip()
        if source_gate(ROOT, 'ADWH') != files or control_gate() != controls:
            raise RuntimeError('Authored source or verification controls changed during checking')
        if args.with_mathlib and source_gate(ROOT / 'mathlib', 'ADWHMathlib') != optional_files:
            raise RuntimeError('Optional authored source changed during checking')
        files += optional_files
        stage('coverage_reference_validation')
        coverage = validate_coverage(reports / 'coverage.json', core_records,
                                     optional_records, args.with_mathlib)
        coverage['run_id'] = attempt['run_id']
        write_json(reports / 'coverage-validation.json', coverage)
        if coverage['status'] == 'failed':
            raise ValueError('Coverage reference validation failed; see coverage-validation.json')
        result = {
            **attempt,
            'status': 'passed',
            'stage': 'completed',
            'checked_at_utc': datetime.now(timezone.utc).isoformat(),
            'lean_version': version,
            'core_kernel_axiom_audit': core,
            'optional_mathlib_kernel_axiom_audit': optional,
            'allowed_axioms': ALLOWED_AXIOMS,
            'forbidden_source_tokens': FORBIDDEN_TOKENS,
            'forbidden_kernel_options': ['skipKernelTC', 'debug.skipKernelTC'],
            'source_module_count': len(files),
            'source_module_count_includes_aggregate_roots': True,
            'named_theorems_and_lemmas': sum(f['named_theorems_and_lemmas'] for f in files),
            'example_proofs': sum(f['examples'] for f in files),
            'definitions': sum(f['definitions'] for f in files),
            'files': files,
            'verification_controls': controls,
            'coverage_validation': coverage,
            'scope': 'Checks the delivered Lean modules and their axiom dependencies; '
                     'does not certify book-wide coverage or Haskell operational equivalence.',
        }
        write_json(reports / 'verification.json', result)
        print(json.dumps({k: result[k] for k in [
            'status', 'lean_version', 'source_module_count', 'named_theorems_and_lemmas',
            'example_proofs', 'definitions']}, indent=2))
        return 0
    except (Exception, KeyboardInterrupt) as exc:
        failed = {**attempt, 'status': 'failed',
                  'failed_at_utc': datetime.now(timezone.utc).isoformat(),
                  'error_type': type(exc).__name__, 'error': str(exc),
                  'coverage_validation': coverage}
        try:
            write_json(reports / 'verification.json', failed)
            if coverage['status'] == 'not_run':
                coverage = {**coverage, 'status': 'not_run',
                            'reason': 'Verification failed before coverage validation'}
                write_json(reports / 'coverage-validation.json', coverage)
        except OSError as report_error:
            sys.stderr.write(f'Could not write failure report: {report_error}\n')
        sys.stderr.write(f'Verification failed at {attempt["stage"]}: {exc}\n')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
