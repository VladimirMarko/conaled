import ArithmeticLocal

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Occurrence-preserving grouping of finite sums of natural-valued products.
An externally proposed grouping must retain the complete term list up to a
permutation. Equal terms are not deduplicated, and empty groups contribute zero.
These are generic algebraic laws, with no concrete restriction, rank, source
factor, or queens-count certificate assumed or checked.
-/
namespace ADWH.Experiments.Chapter15.BlockGrouping

open ADWH.Experiments.Chapter15.ArithmeticCounting

def total : List Weight → Weight
  | [] => constant 0
  | f :: fs => add f (total fs)

theorem total_single (f : Weight) : total [f] = f := add_zero_right f

theorem total_pair (f g : Weight) : total [f, g] = add f g := by
  simp only [total, add_zero_right]

theorem total_append (fs gs : List Weight) :
    total (fs ++ gs) = add (total fs) (total gs) := by
  induction fs with
  | nil => simp only [List.nil_append, total, add_zero_left]
  | cons f fs ih =>
    simp only [List.cons_append, total, ih]
    funext σ
    exact (Nat.add_assoc _ _ _).symm

theorem total_perm {fs gs : List Weight} (h : fs.Perm gs) :
    total fs = total gs := by
  induction h with
  | nil => rfl
  | cons f h ih => simp only [total, ih]
  | swap f g fs =>
    funext σ
    simp only [total, add]
    exact Nat.add_left_comm _ _ _
  | trans h₁ h₂ ih₁ ih₂ => exact ih₁.trans ih₂

theorem total_map_perm {α : Type} (meaning : α → Weight)
    {xs ys : List α} (h : xs.Perm ys) :
    total (xs.map meaning) = total (ys.map meaning) :=
  total_perm (h.map meaning)

theorem total_map_mul_right (fs : List Weight) (g : Weight) :
    total (fs.map (fun f => mul f g)) = mul (total fs) g := by
  induction fs with
  | nil => simp only [List.map_nil, total, mul_zero_left]
  | cons f fs ih =>
    simp only [List.map_cons, total, ih]
    funext σ
    exact (Nat.add_mul _ _ _).symm

theorem total_map_mul_left (f : Weight) (gs : List Weight) :
    total (gs.map (fun g => mul f g)) = mul f (total gs) := by
  induction gs with
  | nil => simp only [List.map_nil, total, mul_zero_right]
  | cons g gs ih =>
    simp only [List.map_cons, total, ih]
    funext σ
    exact (Nat.mul_add _ _ _).symm

theorem total_flatMap {α : Type} (groups : List α) (members : α → List Weight) :
    total (groups.flatMap members) = total (groups.map (fun g => total (members g))) := by
  induction groups with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.flatMap_cons, List.map_cons, total_append, total, ih]

def productMeaning {α β : Type} (left : α → Weight) (right : β → Weight)
    (p : α × β) : Weight := mul (left p.1) (right p.2)

/-- Each left occurrence is paired with its group's exact right label. -/
def groupedTerms {α β : Type} (groups : List (List α × β)) : List (α × β) :=
  groups.flatMap (fun g => g.1.map (fun a => (a, g.2)))

def groupMeaning {α β : Type} (left : α → Weight) (right : β → Weight)
    (g : List α × β) : Weight := mul (total (g.1.map left)) (right g.2)

theorem one_group {α β : Type} (left : α → Weight) (right : β → Weight)
    (xs : List α) (b : β) :
    total ((xs.map (fun a => (a, b))).map (productMeaning left right)) =
      groupMeaning left right (xs, b) := by
  simpa only [List.map_map, Function.comp_def, productMeaning, groupMeaning] using
    total_map_mul_right (xs.map left) (right b)

theorem groupedTerms_total {α β : Type} (left : α → Weight) (right : β → Weight)
    (groups : List (List α × β)) :
    total ((groupedTerms groups).map (productMeaning left right)) =
      total (groups.map (groupMeaning left right)) := by
  induction groups with
  | nil => rfl
  | cons g gs ih =>
    change total (((g.1.map (fun a => (a, g.2))) ++ groupedTerms gs).map
      (productMeaning left right)) = _
    rw [List.map_append, total_append, one_group, ih]
    rfl

/-- The list-permutation premise is essential: set equality would erase
repeated contributions. No independence or distinct-label premise is needed. -/
theorem regroup_products {α β : Type} (left : α → Weight) (right : β → Weight)
    {terms : List (α × β)} {groups : List (List α × β)}
    (coverage : terms.Perm (groupedTerms groups)) :
    total (terms.map (productMeaning left right)) =
      total (groups.map (groupMeaning left right)) := by
  exact (total_map_perm (productMeaning left right) coverage).trans
    (groupedTerms_total left right groups)

/-- Grouping may be used under any exact finite sum, retaining even repeated
quantified variables. This does not supply the grouping's coverage premise. -/
theorem sumVars_regroup_products {α β : Type} (left : α → Weight) (right : β → Weight)
    (vs : List Nat) {terms : List (α × β)} {groups : List (List α × β)}
    (coverage : terms.Perm (groupedTerms groups)) :
    sumVars vs (total (terms.map (productMeaning left right))) =
      sumVars vs (total (groups.map (groupMeaning left right))) := by
  rw [regroup_products left right coverage]

end ADWH.Experiments.Chapter15.BlockGrouping

#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_single
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_pair
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_append
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_perm
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_map_perm
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_map_mul_right
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_map_mul_left
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.total_flatMap
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.one_group
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.groupedTerms_total
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.regroup_products
#print axioms ADWH.Experiments.Chapter15.BlockGrouping.sumVars_regroup_products
