import Init.Data.List.Perm
import Init.Data.List.Nat.Prod

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Natural-number functions on Boolean assignments. Projection sums both values
of a variable, even when the function does not depend on that variable.
Finite support means agreement on a finite list determines the value; it is
stronger than invariance under individual changes outside that list.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting

abbrev Assignment := Nat → Bool
abbrev Weight := Assignment → Nat

def setVar (σ : Assignment) (v : Nat) (b : Bool) : Assignment :=
  fun w => if w = v then b else σ w

@[simp] theorem setVar_same (σ : Assignment) (v : Nat) (b : Bool) :
    setVar σ v b v = b := by simp [setVar]

@[simp] theorem setVar_other (σ : Assignment) (v w : Nat) (b : Bool)
    (h : w ≠ v) : setVar σ v b w = σ w := by simp [setVar, h]

theorem setVar_restore (σ : Assignment) (v : Nat) :
    setVar σ v (σ v) = σ := by
  funext w
  by_cases h : w = v <;> simp [setVar, h]

@[simp] theorem setVar_overwrite (σ : Assignment) (v : Nat) (a b : Bool) :
    setVar (setVar σ v a) v b = setVar σ v b := by
  funext w
  by_cases h : w = v <;> simp [setVar, h]

theorem setVar_comm (σ : Assignment) (v w : Nat) (a b : Bool) (h : v ≠ w) :
    setVar (setVar σ v a) w b = setVar (setVar σ w b) v a := by
  funext x
  by_cases hx : x = v
  · subst x
    simp [setVar, h]
  · by_cases hy : x = w
    · subst x
      simp [setVar, Ne.symm h]
    · simp [setVar, hx, hy]

def constant (n : Nat) : Weight := fun _ => n
def add (f g : Weight) : Weight := fun σ => f σ + g σ
def mul (f g : Weight) : Weight := fun σ => f σ * g σ
def branch (v : Nat) (low high : Weight) : Weight :=
  fun σ => if σ v then high σ else low σ
def cofactor (v : Nat) (b : Bool) (f : Weight) : Weight :=
  fun σ => f (setVar σ v b)
def sumOut (v : Nat) (f : Weight) : Weight :=
  add (cofactor v false f) (cofactor v true f)

def Independent (v : Nat) (f : Weight) : Prop :=
  ∀ σ b, f (setVar σ v b) = f σ

def SupportedBy (vars : List Nat) (f : Weight) : Prop :=
  ∀ σ τ, (∀ v ∈ vars, σ v = τ v) → f σ = f τ

theorem supported_const (vars : List Nat) (n : Nat) :
    SupportedBy vars (constant n) := by
  intro σ τ h
  rfl

theorem independent_of_supported {vars : List Nat} {f : Weight}
    (h : SupportedBy vars f) {v : Nat} (hv : v ∉ vars) : Independent v f := by
  intro σ b
  apply h
  intro w hw
  have hne : w ≠ v := by
    intro he
    exact hv (he ▸ hw)
  simp [hne]

theorem supported_empty_constant {f : Weight} (h : SupportedBy [] f)
    (σ : Assignment) : f = constant (f σ) := by
  funext τ
  exact h τ σ (by simp)

theorem supported_add {xs ys : List Nat} {f g : Weight}
    (hf : SupportedBy xs f) (hg : SupportedBy ys g) :
    SupportedBy (xs ++ ys) (add f g) := by
  intro σ τ h
  simp only [add, hf σ τ (fun v hv => h v (List.mem_append_left _ hv)),
    hg σ τ (fun v hv => h v (List.mem_append_right _ hv))]

theorem supported_mul {xs ys : List Nat} {f g : Weight}
    (hf : SupportedBy xs f) (hg : SupportedBy ys g) :
    SupportedBy (xs ++ ys) (mul f g) := by
  intro σ τ h
  simp only [mul, hf σ τ (fun v hv => h v (List.mem_append_left _ hv)),
    hg σ τ (fun v hv => h v (List.mem_append_right _ hv))]

theorem cofactor_independent (v : Nat) (b : Bool) (f : Weight) :
    Independent v (cofactor v b f) := by
  intro σ c
  simp [cofactor]

theorem sumOut_independent (v : Nat) (f : Weight) :
    Independent v (sumOut v f) := by
  intro σ b
  simp [sumOut, add, cofactor]

theorem supported_sumOut {vars : List Nat} {f : Weight}
    (h : SupportedBy vars f) (v : Nat) :
    SupportedBy (vars.filter (fun w => w != v)) (sumOut v f) := by
  intro σ τ he
  have hc (b : Bool) : f (setVar σ v b) = f (setVar τ v b) := by
    apply h
    intro w hw
    by_cases hv : w = v
    · subst w
      simp
    · simp only [setVar_other σ v w b hv, setVar_other τ v w b hv]
      exact he w (by simp [hw, hv])
  simp only [sumOut, add, cofactor, hc]

theorem sumOut_absent {v : Nat} {f : Weight} (h : Independent v f) :
    sumOut v f = mul (constant 2) f := by
  funext σ
  simp only [sumOut, add, cofactor, h σ false, h σ true, mul, constant, Nat.two_mul]

theorem sumOut_constant (v n : Nat) :
    sumOut v (constant n) = constant (2 * n) := by
  funext σ
  simp [sumOut, add, cofactor, constant, Nat.two_mul]

theorem sumOut_add (v : Nat) (f g : Weight) :
    sumOut v (add f g) = add (sumOut v f) (sumOut v g) := by
  funext σ
  simp [sumOut, add, cofactor, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm]

theorem sumOut_mul_right (v : Nat) (f g : Weight) (hg : Independent v g) :
    sumOut v (mul f g) = mul (sumOut v f) g := by
  funext σ
  simp only [sumOut, add, cofactor, mul, hg σ false, hg σ true, Nat.add_mul]

theorem sumOut_mul_left (v : Nat) (f g : Weight) (hf : Independent v f) :
    sumOut v (mul f g) = mul f (sumOut v g) := by
  funext σ
  simp only [sumOut, add, cofactor, mul, hf σ false, hf σ true, Nat.mul_add]

theorem sumOut_comm (v w : Nat) (f : Weight) :
    sumOut v (sumOut w f) = sumOut w (sumOut v f) := by
  by_cases h : v = w
  · simp [h]
  · funext σ
    simp only [sumOut, add, cofactor,
      setVar_comm σ v w false false h, setVar_comm σ v w false true h,
      setVar_comm σ v w true false h, setVar_comm σ v w true true h]
    simp [Nat.add_assoc, Nat.add_left_comm]

def sumVars : List Nat → Weight → Weight
  | [], f => f
  | v :: vs, f => sumVars vs (sumOut v f)

theorem sumVars_sumOut (vs : List Nat) (v : Nat) (f : Weight) :
    sumVars vs (sumOut v f) = sumOut v (sumVars vs f) := by
  induction vs generalizing f with
  | nil => rfl
  | cons w ws ih =>
    simp only [sumVars, sumOut_comm w v f, ih]

theorem sumVars_append (xs ys : List Nat) (f : Weight) :
    sumVars (xs ++ ys) f = sumVars ys (sumVars xs f) := by
  induction xs generalizing f with
  | nil => rfl
  | cons v vs ih => simp only [List.cons_append, sumVars, ih]

theorem sumVars_perm {xs ys : List Nat} (h : xs.Perm ys) (f : Weight) :
    sumVars xs f = sumVars ys f := by
  induction h generalizing f with
  | nil => rfl
  | cons v h ih => exact ih (sumOut v f)
  | swap v w vs => simp only [sumVars, sumOut_comm v w f]
  | trans h₁ h₂ ih₁ ih₂ => exact (ih₁ f).trans (ih₂ f)

end ADWH.Experiments.Chapter15.ArithmeticCounting

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.supported_empty_constant
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.supported_sumOut
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.sumOut_absent
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.sumOut_mul_right
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.sumOut_comm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.sumVars_perm
