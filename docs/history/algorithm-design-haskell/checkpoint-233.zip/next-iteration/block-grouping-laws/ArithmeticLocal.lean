import ArithmeticSemantics

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Local proof-producing ADD rules. A concrete trace can name each node as a
Weight and prove one equation per operation using earlier named equations.
No canonical diagram, hash table, lookup cache, or external arithmetic result
is a mathematical premise. Below records the independence needed when a
projection skips variables preceding a diagram's root.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting

theorem add_comm (f g : Weight) : add f g = add g f := by
  funext σ
  exact Nat.add_comm _ _

theorem mul_comm (f g : Weight) : mul f g = mul g f := by
  funext σ
  exact Nat.mul_comm _ _

theorem add_constant (a b : Nat) :
    add (constant a) (constant b) = constant (a + b) := rfl

theorem mul_constant (a b : Nat) :
    mul (constant a) (constant b) = constant (a * b) := rfl

theorem add_zero_left (f : Weight) : add (constant 0) f = f := by
  funext σ
  exact Nat.zero_add _

theorem add_zero_right (f : Weight) : add f (constant 0) = f := by
  funext σ
  exact Nat.add_zero _

theorem mul_zero_left (f : Weight) : mul (constant 0) f = constant 0 := by
  funext σ
  exact Nat.zero_mul _

theorem mul_zero_right (f : Weight) : mul f (constant 0) = constant 0 := by
  funext σ
  exact Nat.mul_zero _

theorem mul_one_left (f : Weight) : mul (constant 1) f = f := by
  funext σ
  exact Nat.one_mul _

theorem mul_one_right (f : Weight) : mul f (constant 1) = f := by
  funext σ
  exact Nat.mul_one _

theorem branch_same (v : Nat) (f : Weight) : branch v f f = f := by
  funext σ
  simp [branch]

theorem add_branch (v : Nat) (al ah bl bh : Weight) :
    add (branch v al ah) (branch v bl bh) =
      branch v (add al bl) (add ah bh) := by
  funext σ
  cases h : σ v <;> simp [branch, add, h]

theorem mul_branch (v : Nat) (al ah bl bh : Weight) :
    mul (branch v al ah) (branch v bl bh) =
      branch v (mul al bl) (mul ah bh) := by
  funext σ
  cases h : σ v <;> simp [branch, mul, h]

theorem add_split {v : Nat} {a b al ah bl bh rl rh result : Weight}
    (ha : a = branch v al ah) (hb : b = branch v bl bh)
    (hl : add al bl = rl) (hh : add ah bh = rh)
    (hr : branch v rl rh = result) : add a b = result := by
  rw [ha, hb, add_branch, hl, hh, hr]

theorem mul_split {v : Nat} {a b al ah bl bh rl rh result : Weight}
    (ha : a = branch v al ah) (hb : b = branch v bl bh)
    (hl : mul al bl = rl) (hh : mul ah bh = rh)
    (hr : branch v rl rh = result) : mul a b = result := by
  rw [ha, hb, mul_branch, hl, hh, hr]

theorem independent_constant (v n : Nat) : Independent v (constant n) := by
  intro σ b
  rfl

theorem independent_branch {v w : Nat} {low high : Weight}
    (hvw : v ≠ w) (hl : Independent v low) (hh : Independent v high) :
    Independent v (branch w low high) := by
  intro σ b
  simp only [branch, setVar_other σ v w b (Ne.symm hvw), hl σ b, hh σ b]

/-- Every variable strictly below this bound is absent from the function. -/
def Below (bound : Nat) (f : Weight) : Prop :=
  ∀ v, v < bound → Independent v f

theorem below_constant (bound n : Nat) : Below bound (constant n) := by
  intro v hv
  exact independent_constant v n

theorem below_mono {a b : Nat} {f : Weight} (h : a ≤ b) (hf : Below b f) :
    Below a f := by
  intro v hv
  exact hf v (Nat.lt_of_lt_of_le hv h)

theorem below_branch (v : Nat) (low high : Weight)
    (hl : Below v low) (hh : Below v high) : Below v (branch v low high) := by
  intro w hw
  exact independent_branch (Nat.ne_of_lt hw) (hl w hw) (hh w hw)

theorem sumOut_branch_head (v : Nat) (low high : Weight)
    (hl : Independent v low) (hh : Independent v high) :
    sumOut v (branch v low high) = add low high := by
  funext σ
  simp [sumOut, add, cofactor, branch, hl σ false, hh σ true]

theorem sumOut_branch_other (v w : Nat) (low high : Weight) (h : v ≠ w) :
    sumOut v (branch w low high) =
      branch w (sumOut v low) (sumOut v high) := by
  funext σ
  cases hs : σ w <;>
    simp [sumOut, add, cofactor, branch, setVar_other σ v w false (Ne.symm h),
      setVar_other σ v w true (Ne.symm h), hs]

theorem project_head {v : Nat} {input low high result : Weight}
    (hi : input = branch v low high)
    (hl : Independent v low) (hh : Independent v high)
    (ha : add low high = result) : sumOut v input = result := by
  rw [hi, sumOut_branch_head v low high hl hh, ha]

theorem project_absent {v : Nat} {input result : Weight}
    (hi : Independent v input)
    (hm : mul (constant 2) input = result) : sumOut v input = result :=
  (sumOut_absent hi).trans hm

theorem project_other {v w : Nat} {input low high rl rh result : Weight}
    (hi : input = branch w low high) (hne : v ≠ w)
    (hl : sumOut v low = rl) (hh : sumOut v high = rh)
    (hr : branch w rl rh = result) : sumOut v input = result := by
  rw [hi, sumOut_branch_other v w low high hne, hl, hh, hr]

end ADWH.Experiments.Chapter15.ArithmeticCounting

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.add_split
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.mul_split
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.below_branch
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.project_head
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.project_absent
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.project_other
