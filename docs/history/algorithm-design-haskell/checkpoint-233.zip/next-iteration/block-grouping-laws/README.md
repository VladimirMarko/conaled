# Occurrence-preserving product grouping

The first fresh three-source gate passes. `BlockGrouping.lean` adds twelve
generic Lean lemmas for finite natural-valued sums, permutation of summands,
distributivity, and grouping products that share the same right factor. Its
coverage condition is a permutation of the complete original term list, so
equal terms retain their multiplicity. Empty groups contribute zero. No
independence, disjoint-support, or distinct-label assumption is needed for
these pointwise equalities.

This is the algebra needed to justify a proposed grouping of the retained
binary cut's product terms. It does **not** check that concrete grouping,
the 128 cofactor cases, the discarded zero cases, guarded descriptors, a rank
witness, or a queens count. The future concrete application must prove the
exact list-permutation premise and its connection to the original contraction.
No proposed rank or expected count is an assumption of these theorems.

## Accepted fresh gate

`attempts/fresh-grouping-01/report.json` has SHA-256
`81bf05c19dd486b73aa219a7142b18b9070f860bc60b23cb1751349ed07f80a6`.

- Three fresh sources: exact copies of `ArithmeticSemantics` and
  `ArithmeticLocal`, followed by the new `BlockGrouping`.
- One cumulative mathematical gate: **1.734835079 seconds**.
- Peak measured child RSS: **502,212 KiB**.
- Twenty-four required axiom-print occurrences were checked exactly; only
  `propext` and `Quot.sound` occur.
- One CPU, one Lean thread, `-M1024`, and the unchanged thirty-second deadline.
- Pinned Lean 4.33.0-rc1, unchanged project source guard, no experimental
  compiled imports reused, all input/control bindings unchanged.

The source stages took 1.052457592, 0.345399259, and 0.335252345 seconds. These
are single observations, not a new performance comparison or scaling claim.
There was one attempt and no timing repeat. The internal Lean memory cap is
distinct from the reported process RSS.

## Source and control identities

`BlockGrouping.lean` has SHA-256
`3f8cc78c799d204c02674c834e74458427fb4f6a181fd3e15980d30acf4cc25f`.
The runner has SHA-256
`be6ac057d45083f0284093fd2e04c4e0be8b21559facb1e128ea8cd099df6216`.
The exact preparation manifest has SHA-256
`49099f81440f7fc0ea844b110b0a2380091bc596588241de6e6e53d42289a7a6`.

The runner is copied from the already reviewed factor-law gate, with only its
description, selected source list, and report-kind label changed. Its exact
parent and patch are retained under `origin/`. The existing dependency sources
are unchanged copies from the frozen factor-law bundle. Source snapshots,
compiler outputs, logs, and the producing report remain available. The
inventory separates archivable files from reproducible runtime objects.

No previously frozen experiment, integrated source, chapter ledger, or
acceptance limit was modified. The sixteen-queen theorem remains open.
