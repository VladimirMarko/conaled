# Exact-relation bounded-runner pre-review

The draft runner `next-iteration/exact-relation-diagnostic/run_probe.py` has no control blocker. This review covers the complete source and its exact difference from the accepted cut-probe parent. It does not execute or import either runner, acquire the shared lock, or execute any candidate calculation or replay.

The resource and preservation controls are unchanged: one child process starts in a new process group, is pinned to one available CPU, has a 1-GiB address-space limit and a 30-second CPU limit, and is monitored against a 30-second wall deadline. A result returned after the deadline is rejected even if the process was not killed. The existing exclusive nonblocking `residual-dag/compile.lock` remains in use. There is no larger allowance or fallback retry.

The runner creates a new attempt directory with exclusive file creation, snapshots both independent programs, the runner, local protocol, and the frozen plan's DESIGN/schema, and executes the selected program snapshot with isolated Python. The original guarded trace and saved sample/replay report have exact fixed SHA256 pins. Replay also snapshots its explicit certificate argument. Original files and snapshots are checked again after execution; accepted or cap-prefix results are rejected on a binding change. Interpreter identity, command, CPU affinity, process usage, all retained artifacts and preparation failures are recorded.

The parent-to-draft changes are limited to the new program filenames, the external plan-file mapping, the exact saved sample input, diagnostic scope text, matrix metadata, and producer footer/status fields. The full preserved patch reproduces those source changes exactly. The limits and process-management block are unchanged.

Producer exit zero plus `completed_fixed_batch` is a completed diagnostic process; exit four plus `request_cap` is a retained capped prefix. Neither is a Lean theorem or a checked counting result. Replay must independently validate the mathematical and work-accounting transcript. The runner only reads the producer's last record or the replay's result JSON to classify process status; it deliberately does not duplicate that mathematical checker.

## Remaining combined-source checks

The final producer and replayer must accept the snapshotted CLI (`--trace`, `--sample`, `--output`, and replay-only `--certificate`) and use the snapshotted policy/protocol layout. The producer footer must expose `charged_starts`, `completed_requests`, `pending_stack`, `physical_records`, and the exact status labels. Replay must expose its exact `status`, `qualification`, `producer_status`, corresponding work totals and `pending_requests`. The mathematical replayer, rather than this metadata reader, must enforce valid qualification, exact fields, exact numbers and complete or partial outcomes.

The source implementations must actually enforce the one shared 50,000-request cap across candidate arithmetic, source validation and all candidate identity checks. The runner reports this bound but cannot enforce individual mathematical requests itself. Deterministic ordering must come from the fixed program policy, not an assumption about Python hash iteration or environment variables.

This pre-review clears the unchanged execution controls. It is not execution authorization and does not stand in for the final program/protocol/dataflow review.
