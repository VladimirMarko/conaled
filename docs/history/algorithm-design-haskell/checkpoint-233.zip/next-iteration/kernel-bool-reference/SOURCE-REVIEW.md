# Independent source review: actual Bool selector steps

**Disposition: passed source-only review; uncompiled.** No missing mathematical
premise or additional source blocker was identified in the frozen candidate.
This is not a claim that its scripts elaborate, its full closure fits the
budget, or its installed source guards have been discharged. The reviewer
`validity_contracts` did not author this module, run or import a gate, or
execute Lean, an exporter, a counter or a native evaluator. The reviewer
previously authored FiniteFold and the logical source slice; those older
inputs have separate reviews and saved results. `regression_audit` authored
this new module, and root alone executes future gates.

## Exact scope

| Input | Bytes | SHA-256 |
|---|---:|---|
| `source/KernelBoolSelector.lean` | 38,785 | `9db147490032834c2ebd34c88bcae551742558939fc19784ad0877f8b50ea116` |
| `PLAN.md` | 7,568 | `232b568b1076ee30fa7d4fbb4b4ba47963c15c1f89f110050deaa1bf9444acd5` |
| `SOURCE-INVENTORY.json` | 63,651 | `c6b50fa7147c8b35e48fa102860be3699ac61b2d2977ace860865dd962ec93b3` |
| `BOOL-EXPORT-PINS.json` | 19,599 | `e59aa82f395f5b4ac9dbff239d273e6475a903f5f7fa81acb19d68618a7dcbea` |

The accompanying audit binds exactly **37 distinct direct inputs**:
29 mathematical sources, seven author/provenance controls and the inventory.
Every length/hash was checked. The first 28 sources match the reviewed
Natrec04 inventory exactly. The Natrec source and inventory now resolve to
the immutable `kernel-recursion-reference/failed-complete-04/source/` and
`failed-complete-04/controls/` canonical copies, retaining hashes
`e6bcf1351f8ae3f51f48be6950630f8969682f6cba1605787840f77738c9cb4f` and
`8582439601f0f00a50178daf5db58c8b0355e4730fb29e4d437b3e4d2518dea8`.
The relocation changes metadata paths only, keeping all mathematical bytes
and the Bool PLAN unchanged. Complete-04 reached the cumulative deadline
with no Natrec reports or objects; its source identity is not acceptance.
The active Natrec05 proof changes and print movement have **not** been
propagated into this reviewed Bool preparation. Any future propagation
requires explicit rebinding and review before a complete fresh gate. No
prior result replaces a fresh check of any selected module. The prospective Bool closure is **29 fresh modules,75 roots and142
default artifacts**, with thirteen new public statements and seventeen
private supports. The one new import is KernelNatRecursor.

All public/private headers and ordered printed names match the actual source.
Six private proof segments match that exact historical04 Natrec source byte-for-byte;
the recorded segment convention includes the leading space before `:=` and
one terminal newline. The complete BoolPins block, including its separating
blank line, matches its recorded hash. Fourteen proof-local default-transparency
configurations were propagated from the actual Natrec diagnostics; removing
only those configurations recovers the earlier uncompiled Bool source hash
`dc15e9a92e8cf76424899026c3ea75bbd35277963486dda85e9bcee01fb07225`.
These are preventive Bool repairs, not observations from a Bool compiler run.

## Actual export and installation boundary

I independently compared the two saved export declarations and all their
reachable records with the actual export-02 NDJSON: **39 expression nodes,
11 name nodes and3 universe nodes**, including their complete reference
closure and resolved names. This is a data inspection of an existing export,
not a new exporter or checker execution.

Bool.casesOn takes motive,major,false branch,true branch; its four-lambda
body applies Bool.rec to motive,false branch,true branch,major. The
recursor's major position and prefix are3, and both constructors have zero
parameters/fields. The wrapper's abbreviation hint and single universe
parameter are recorded. The source templates use the corresponding de
Bruijn indices and concrete universe1. The false rule selects bound variable1
under three lambdas; the true rule selects variable0. The wrapper body uses
motive3,false1,true0,major2.

Raw binder information is not the installed ConLeche annotation. BoolPins
has seven record/body data fields and nineteen exact guards covering names,
stored kinds, constructor/rule data, level arities, complete instantiated
types and right-hand sides. The all-never annotated templates are a
conditional operational interface. This review does not establish that the
real installation produces them or that an arbitrary environment is valid.
The actual annotated-source recognition and environment invariants remain
necessary before using these steps inside a validating checker.

## Operational proof and fuel accounting

The proofs use actual ConLeche expressions and existing prepareMajor,
iotaCerts,iotaRec,whnfCore,whnfStep,whnfLoop and whnf. There is no substitute
syntax, evaluator or reduction rule. The condition is normalized by the
actual full-WHNF child call. The two active nullary rules and the existing
licensed telescope walk supply the iota step; the following beta peels
select the stated branch. Closedness is explicit where later substitution
traverses an already inserted motive,condition or earlier false branch.
The final true branch is inserted last, so that local equation needs no
extra closedness hypothesis for it.

| Composition | Checked source contract |
|---|---|
| Bool recursor | Input knot fuel f+6; condition at f+5; selected branch head at f+4. |
| casesOn lambda body | Four beta peels; uniform head threshold max(condition,branch)+7. |
| Ordinary wrapper unfolding | Exactly one local loop iteration, with the same knot fuel. |
| Same-head transfer | Two actual head runs give the same subsequent native/delta tail and continuation. |
| Scalar/binary operation | Explicit local thresholds1/2; binary children use their own actual full-WHNF calls. |
| Full-WHNF conclusion | Explicit bound by unchanged whnfLoopFuel plus one entry knot level. |

LoopRunsAbove quantifies over every sufficiently large knot fuel, every
sufficiently large local-loop budget and every scoped depth. The selected
branch transfer requires a positive branch-loop threshold. It does not
reuse a fixed-budget full run at one fewer local iteration. Head runs, full
runs and loop runs remain separate predicates. The binary table equation
retains all existing operation/storage guards, including the exponent
cutoff. Constructor normal forms require the actual stored-constructor
condition. All these are local compositional obligations; later whole-fold
induction must supply them for the exact recognized program.

## Policy and remaining obligations

A nested-comment/string-masked scan found no admission,new axiom,unsafe or
partial declaration,native decision,external implementation or resource
override. The only source options are the three strict options. The proposed
closure must retain the single cumulative30-second,one-CPU/thread,1-GiB,
-j1/-M1024 gate with default heartbeat/recursion limits and no compiled
experimental or upstream reuse. No headroom or timing claim follows from
source review.

A whole structural-fold simulation, installed Bool/Nat pins, exact exported
program recognition, and actual cache/checker integration remain open.
No new native count or stock cqueens16 numeral theorem follows from these
lemmas. Root's separate Delta module is not part of this inventory, and a
future source-recognition guard is not an artificial dependency of this
local proof closure.
