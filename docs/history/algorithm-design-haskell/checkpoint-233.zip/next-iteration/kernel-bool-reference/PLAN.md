# Actual Bool selector reduction

**Status: complete source-only candidate, uncompiled. No gate has been selected or run for this directory.**

`KernelBoolSelector.lean` follows the actual `Bool.casesOn` body retained in the raw-literal structural-reference export-02. Its purpose is to complete the Boolean selection path needed by the two explicit `Nat.rec` folds. It introduces operational lemmas about ConLeche's existing `Expr`, `prepareMajor`, `iotaRec`, `whnfCore`, `whnfStep`, `whnfLoop` and `whnf`; it introduces no replacement evaluator or proof-language syntax.

## Exact source shape and conditional pins

The exported wrapper takes `motive, major, falseBranch, trueBranch`, has one level parameter and an abbreviation hint, and contains four lambdas applying `Bool.rec` in the order `motive, falseBranch, trueBranch, major`. The recursor has major position and rule prefix 3, two nullary constructors and two rules. All calls in this candidate instantiate the recursor and wrapper at universe 1. `BOOL-EXPORT-PINS.json` retains the exact two export declarations, their reachable expression/name/level records and the source stream's identity.

The local `BoolPins` structure records the complete source identities required by this route: stored recursor/constructor/definition kinds and names, both constructor arities, level arities, annotated instantiated types, active plain rules and all three instantiated right-hand sides. In particular, the operational proof never assumes a successful run of the whole selector or a native value. The two consumed binder telescopes and wrapper lambda metadata carry `.never` in the intended universe-1 installation.

The raw export has binder information, not ConLeche's installed annotations. The copied raw records do **not** prove `BoolPins`, annotation success, environment validity or installation correctness. A later source-recognition/annotation bridge must connect the exact raw declarations and annotated stored values. Unused type/name fields are retained to specify complete declaration identity rather than claim an arbitrary stored body represents the original source.

## The two fuel parameters

`HeadRunsAbove` and `RunsAbove` are imported from the Natrec candidate. The new predicate

`LoopRunsAbove env expression result knotThreshold loopThreshold`

means that the **existing** `whnfLoop` succeeds for every knot fuel at or above the first threshold, every local loop budget at or above the second threshold, and every scoped depth. It is a property of the actual reducer, not a second implementation.

| Local result | Explicit cost and obligation |
|---|---|
| Bool recursor zero/one choice | The actual condition full-WHNF child runs at `fuel + 5`; the recursor at `fuel + 6` has the selected branch's head result at `fuel + 4`. |
| Four-lambda casesOn body | Four certified beta peels transfer `fuel + 5` to the recursor at `fuel + 4`; its uniform head threshold is `max(condition, branch) + 7`. |
| Ordinary wrapper delta | One real local-loop iteration, from budget `b + 1` to budget `b`, with the same knot fuel. |
| Selected-branch loop transfer | Once wrapper-body and branch heads agree, the same literal/delta tail and continuation run. The wrapper costs one more local iteration than the selected branch. |
| Scalar result | One local iteration, under its actual head-normalization and stored-constructor/literal guard. |
| Existing binary Nat table | Two local iterations, under the actual two child full-WHNF runs and existing operation/definition guards; those child calls start their own unchanged local loops. |
| Full-WHNF conclusion | Requires the explicit local threshold to fit the unchanged `whnfLoopFuel`, plus the extra entry knot level. |

The selected-branch theorem requires a positive branch-loop threshold. It never reuses a full-WHNF run at a decremented local budget. The condition and selected branch are genuine smaller operational premises for a later fold induction; there is no premise asserting the desired complete selector run.

## Thirteen public roots

The printed roots are `iota_bool`, `whnfCore_bool`, `headRunsAbove_bool`, `whnfCore_cases_body`, `headRunsAbove_cases_body`, `whnfLoop_cases_delta`, `whnfStep_eq_of_same_head`, `whnfLoop_cases_select`, `loopRunsAbove_cases`, `runsAbove_of_loop`, `loopRunsAbove_scalar`, `loopRunsAbove_binary` and `runsAbove_cases`, all in `ADWH.Experiments.Chapter15.KernelBoolSelector`.

The source also contains seventeen private supporting proofs. Closed substitution is needed for the motive, condition and earlier false branch in the wrapper, because later beta steps traverse those inserted expressions. The final true branch is not traversed by a later substitution, so the local equation does not add an unnecessary closedness premise for it.

## Prospective fresh closure and provenance

The source imports `KernelNatRecursor`, which imports `KernelScalarSteps` and the accepted logical reducer foundation. The proposed standalone Bool selection is therefore **29 fresh modules, 75 exact printed roots and 142 default Lean artifacts**: the previous 28-source inventory plus this one module. All selected upstream and experimental modules must be compiled afresh in any future complete gate, under one cumulative 30-second, one-CPU/thread, 1-GiB-RSS limit, with `-j1 -M1024`, strict `autoImplicit=false`, `warningAsError=true`, `Elab.async=false`, and default heartbeat/recursion options. There is no compiled dependency reuse or preparation exemption.

At this preparation point the prior 28-module inventory binds the reviewed Natrec correction after complete-03; that corrected Natrec source has not yet been accepted. The failed variants' parser/proof diagnostics and real deadlines are retained separately. The new Bool draft incorporates their explicit match/Except reductions, syntax repairs and narrowly configured default-transparency rewrites before its first compilation. The last change addresses semireducible definitions retained inside dependent conditional instances; it changes proof elaboration only. No Bool failure or success is claimed by propagating a correction from that distinct source.

The bound prior source inventory supplies the exact dependency identities. `PROOF-PROVENANCE.json` retains the original substitution/closedness proof-pattern provenance. Several private helpers are textually shared with the current Natrec candidate, and the scalar-loop proof follows the already accepted scalar helper; all are checked again in the proposed fresh closure.

Root's separate `KernelDeltaSteps` candidate may later compose ordinary definition wrappers using the explicit loop interface. It is deliberately outside this author inventory and no combined gate is selected here. A source-recognition guard belongs in a later actual-source closure rather than being silently added to this mathematical dependency chain.

## Remaining scope

This candidate does not prove the entire structural evaluator's normalization, discharge installed Bool or Nat pins, install a cached reducer rule, validate a Lean export using a new fast path, or produce a stock numerical theorem for `cqueens 16`. Those require the whole-fold induction, source/annotation recognition and the existing reducer's installation/simulation contract. The externally accepted native count remains a separate result with its previously stated trust boundary.

Authorship: regression_audit authored this source; validity_contracts performs the independent source review; root alone selects and executes any later gate.
