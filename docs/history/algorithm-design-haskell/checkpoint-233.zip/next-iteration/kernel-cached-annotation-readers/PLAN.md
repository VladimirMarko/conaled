# Actual annotation reader and telescope-exit equations

Status: frozen source candidate awaiting independent review. No Lean, metadata
preflight, gate, exporter, generator, profiler, native mathematical program or
dedicated saved-result reader was executed by the author. All consumed source
selections, review scopes and control packages remain unchanged.

## Selected mathematical content

KernelCachedAnnotationReaders imports only KernelCachedForward. It adds seventeen
public theorem reports and one explicitly named output-description definition,
rebuildNever. No actual checker definition is replaced or redefined.

The first eight roots expose the original headTypePW/headProofPW/typeSortPW/
proofPW behavior. Constant lemmas require the actual FEnv lookup, a non-tower
record, exact universe arity, and the relevant full stored-type/residual datum.
They retain actual Level.substPW. The never specialization is a reader equation
under a stated datum premise; it does not validate that annotation semantically.

The next five roots cover the actual placeholder write and successful annotPwPiI,
annotPwLamI, annotatePisPwI and annotateLamsPwI branches when the real reader is
known. These operations return exactly the supplied state. They require no
assumed success of an annotation action or inference fallback.

The outward-fold theorem proves actual annotateBindersOutI success for a stack
of .never input entries and an actual leaf datum .never. rebuildNever describes
its exact output using actual Expr.abstractRangeC calls. Every cache field is
unchanged. The two telescope-exit theorems keep actual Expr.instantiateRev and
Expr.abstractRangeC, consume the actual supplied callback run on the opened leaf,
and return exactly that callback's state. Thus any state predicate known there
is preserved by the remaining reader/rebuild work. These equations deliberately
do not replace those actual traversals by pure syntax operations.

The final root exposes the real let branch with all seven successful actions:
annotate the type, infer its type, ensure a sort, annotate the value, infer its
type, check value-type equality, then annotate the substituted body. Each premise
starts at the preceding action's returned state. The substitution uses the
original value, exactly as annotateBodyI does. Neither a missing let check nor
an assumed successful enclosing let call is used.

The callbacks are explicit CoreFnsI values. A later complete annotation proof
must instantiate them at the genuine preceding knot fuel and supply the required
recursive runs. This leaf proves body equations; it does not bound that recursive
annotation proof or its total fuel. It adds no cache-invariant assumptions to the
state-neutral steps and no complete-state validity conclusion to a supplied
callback that did not already provide it.

## Source and installation connection

The source-only assessment in kernel-cached-annotation-source-assessment identifies
the real exported StructuralNatOnlyReference names, actual regular hints 12/13/14,
exact raw body comparison and the single branches let node 11320. The present
leaf begins the missing actual-annotation bridge. It does not yet construct
literal raw records or prove annotation of all three complete bodies.

The raw .never placeholder is recomputed by the actual annotator. Typed lookup
premises must eventually come from actual stored prefix records; the eight
ArithmeticPins definition-kind bits do not supply them. Full telescope entry,
opened-domain annotation, concrete abstraction/reversed-instantiation equations,
let type/value checks, valid .never licences, original driver guards and an actual
successful installation chain remain outstanding. No hand-built environment is
called installed, and no recognizer completeness theorem is treated as evidence
that recognition succeeded on the actual exported program.

Book's separate wrapper leaf owns Eq-specific notProofFast and finite const,
literal and application annotation branches. This leaf does not import or
redefine them. Its generic reader and binder/let equations can be shared by the
program proof and that wrapper once independently reviewed and freshly compiled.

## Complete prospective ownership and fixed budget

The minimal current-owner closure is three physical modules in order:
KernelCompactCore, KernelCachedForward, KernelCachedAnnotationReaders. It has
seventeen upstream and three project origins, twenty distinct origins and
twenty-two source segments, forty-three ordered reports (1 + 25 + 17), and six
ordinary outputs. Current Core/Cached sources are the exact reviewed evaluator
comment-repair variants. All partial/whole evaluator omissions and their earlier
review contexts remain separate; this is not the original full driver closure.

The author inventory binds the complete prior control/source context as historical
evidence without selecting its other mathematical leaves. Its arrays and actual
failed source key remain unchanged. The preceding Syntax repair120 run accepted
112 reports through Bulk, then timed out at Literal; its accepted prefix is useful
evidence, but not a complete120 acceptance or a prepared-object exemption.

No gate is selected here and no resource fit is claimed. Any future gate must
compile its entire actual selected dependency/annotation/report closure fresh
under the same cumulative thirty seconds, one CPU/thread, one GiB, default
heartbeat/recursion and three-axiom policy. Any later original installer work must
restore the explicitly omitted driver declarations and validate that new closure.
