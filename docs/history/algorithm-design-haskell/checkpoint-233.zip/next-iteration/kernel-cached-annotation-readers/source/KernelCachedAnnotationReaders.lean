import KernelCachedForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual annotation readers, telescope exit and let validation

Source candidate only. These equations use the original cached annotation
functions. The lookup premises describe actual stored records, including the
non-tower and universe-arity checks. They do not assert that a chosen annotation
is valid or that an environment was installed successfully.

The telescope exit retains the actual reversed instantiation and abstraction
functions. It returns exactly the state produced by its supplied annotation
callback. The let equation keeps all real annotation, inference, sort and defeq
checks in order, and substitutes the original value as the implementation does.
No equation assumes success of the annotation call it concludes.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedAnnotationReaders

open ConLeche
open ConLeche.Cached

theorem head_type_of_lookup (fe : FEnv) (name : Name) (levels : List Level)
    (info : ConstantInfo) (arguments : Nat) (sortLevel : Level)
    (stored : fe.find? name = some info)
    (ordinary : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (residual : info.toConstantVal.type.peelNeverPis arguments = some (.sort sortLevel)) :
    headTypePW fe.find? (.const name levels) arguments =
      some (Level.substPW info.toConstantVal.levelParams levels (Level.zeronessOf sortLevel)) := by
  unfold headTypePW
  rw [stored, ordinary]
  dsimp only []
  rw [ite_eq_left arity, residual]
  all_goals rfl

theorem head_proof_of_lookup (fe : FEnv) (name : Name) (levels : List Level)
    (info : ConstantInfo) (datum : PropWhen)
    (stored : fe.find? name = some info)
    (ordinary : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (typeRead : typeSortPW fe.find? info.toConstantVal.type = some datum) :
    headProofPW fe.find? (.const name levels) =
      some (Level.substPW info.toConstantVal.levelParams levels datum) := by
  unfold headProofPW
  rw [stored, ordinary]
  dsimp only []
  rw [ite_eq_left arity, typeRead]
  all_goals rfl

theorem type_sort_const_of_lookup (fe : FEnv) (name : Name) (levels : List Level)
    (info : ConstantInfo) (sortLevel : Level)
    (stored : fe.find? name = some info)
    (ordinary : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (typePin : info.toConstantVal.type = .sort sortLevel) :
    typeSortPW fe.find? (.const name levels) =
      some (Level.substPW info.toConstantVal.levelParams levels (Level.zeronessOf sortLevel)) := by
  change headTypePW fe.find? (.const name levels) 0 = _
  apply head_type_of_lookup fe name levels info 0 sortLevel stored ordinary arity
  rw [typePin]
  all_goals rfl

theorem proof_const_of_lookup (fe : FEnv) (name : Name) (levels : List Level)
    (info : ConstantInfo) (datum : PropWhen)
    (stored : fe.find? name = some info)
    (ordinary : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (typeRead : typeSortPW fe.find? info.toConstantVal.type = some datum) :
    proofPW fe.find? (.const name levels) =
      some (Level.substPW info.toConstantVal.levelParams levels datum) := by
  change headProofPW fe.find? (.const name levels) = _
  exact head_proof_of_lookup fe name levels info datum stored ordinary arity typeRead

theorem proof_app_of_head (fe : FEnv) (function argument : Expr) (datum : PropWhen)
    (headRead : headProofPW fe.find? function.getAppFn = some datum) :
    proofPW fe.find? (.app function argument) = some datum := by
  change headProofPW fe.find? function.getAppFn = some datum
  exact headRead

theorem type_sort_forall (fe : FEnv) (domain body : Expr) (metadata : BinderMeta) :
    typeSortPW fe.find? (.forallE domain body metadata) = some metadata.pw := rfl

theorem proof_lambda (fe : FEnv) (domain body : Expr) (metadata : BinderMeta) :
    proofPW fe.find? (.lam domain body metadata) = some metadata.pw := rfl

/-- This is the actual reader's result under an explicit stored-type datum.
It is not a proof of semantic validity of that datum. -/
theorem head_proof_never_of_lookup (fe : FEnv) (name : Name) (levels : List Level)
    (info : ConstantInfo)
    (stored : fe.find? name = some info)
    (ordinary : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (typeRead : typeSortPW fe.find? info.toConstantVal.type = some .never) :
    headProofPW fe.find? (.const name levels) = some .never := by
  have result := head_proof_of_lookup fe name levels info .never stored ordinary arity typeRead
  exact result

theorem annot_meta_never :
    annotBinderMetaI (some .never) ⟨.never⟩ = ⟨.never⟩ := rfl

theorem annot_pi_of_read (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (body : Expr) (datum : PropWhen) (state : CState)
    (reader : typeSortPW fe.find? body = some datum) :
    annotPwPiI callbacks fe depth body state = .ok (datum, state) := by
  simp only [annotPwPiI, reader]
  all_goals rfl

theorem annot_lam_of_read (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (body : Expr) (datum : PropWhen) (state : CState)
    (reader : proofPW fe.find? body = some datum) :
    annotPwLamI callbacks fe depth body state = .ok (datum, state) := by
  simp only [annotPwLamI, reader]
  all_goals rfl

theorem annot_pi_write_of_read (callbacks : CoreFnsI) (fe : FEnv) (depth count : Nat)
    (body : Expr) (datum : PropWhen) (state : CState)
    (reader : typeSortPW fe.find? body = some datum) :
    annotatePisPwI callbacks fe depth count body state = .ok (some datum, state) := by
  have readRun := annot_pi_of_read callbacks fe (depth + count) body datum state reader
  simp only [annotatePisPwI, Bind.bind, StateT.bind, readRun, pure, StateT.pure,
    Except.bind]
  all_goals rfl

theorem annot_lam_write_of_read (callbacks : CoreFnsI) (fe : FEnv) (depth count : Nat)
    (body : Expr) (datum : PropWhen) (state : CState)
    (reader : proofPW fe.find? body = some datum) :
    annotateLamsPwI callbacks fe depth count body state = .ok (some datum, state) := by
  have readRun := annot_lam_of_read callbacks fe (depth + count) body datum state reader
  simp only [annotateLamsPwI, Bind.bind, StateT.bind, readRun, pure, StateT.pure,
    Except.bind]
  all_goals rfl

/-- Exact output description of the actual outward binder fold when each raw
stack entry has the .never placeholder and the actual leaf reader returned it.
The abstraction remains the real cached traversal, with its default cursor. -/
def rebuildNever (mk : Expr → Expr → BinderMeta → Expr) (depth : Nat) :
    List Expr → Nat → Expr → Expr
  | [], _, current => current
  | type :: rest, index, current =>
    rebuildNever mk depth rest (index - 1)
      (mk (Expr.abstractRangeC type depth index) current ⟨.never⟩)

theorem annotate_binders_out_never (mk : Expr → Expr → BinderMeta → Expr)
    (depth : Nat) (types : List Expr) (index : Nat) (current : Expr) (state : CState) :
    annotateBindersOutI mk depth (some .never)
        (types.map fun type => (type, (⟨.never⟩ : BinderMeta))) index current state =
      .ok (rebuildNever mk depth types index current, state) := by
  induction types generalizing index current with
  | nil => rfl
  | cons type rest ih =>
    change annotateBindersOutI mk depth (some .never)
        (rest.map fun type => (type, (⟨.never⟩ : BinderMeta))) (index - 1)
        (mk (Expr.abstractRangeC type depth index) current ⟨.never⟩) state =
      .ok (rebuildNever mk depth rest (index - 1)
        (mk (Expr.abstractRangeC type depth index) current ⟨.never⟩), state)
    exact ih (index - 1) (mk (Expr.abstractRangeC type depth index) current ⟨.never⟩)

theorem annotate_pi_leaf_never (callbacks : CoreFnsI) (fe : FEnv) (depth count : Nat)
    (body annotatedBody : Expr) (fvars : Array Expr) (types : List Expr)
    (state final : CState)
    (bodyRun : callbacks.annotate (depth + count) (Expr.instantiateRev body fvars) state =
      .ok (annotatedBody, final))
    (reader : typeSortPW fe.find? annotatedBody = some .never) :
    annotatePisLeafI callbacks fe depth body count fvars
        (types.map fun type => (type, (⟨.never⟩ : BinderMeta))) state =
      .ok (rebuildNever (fun type body metadata => .forallE type body metadata) depth
        types (count - 1) (Expr.abstractRangeC annotatedBody depth count), final) := by
  have readRun := annot_pi_write_of_read callbacks fe depth count annotatedBody .never final reader
  simp only [annotatePisLeafI, instListRevM, abstractRangeM, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.bind, bodyRun, readRun, annotate_binders_out_never]
  all_goals rfl

theorem annotate_lam_leaf_never (callbacks : CoreFnsI) (fe : FEnv) (depth count : Nat)
    (body annotatedBody : Expr) (fvars : Array Expr) (types : List Expr)
    (state final : CState)
    (bodyRun : callbacks.annotate (depth + count) (Expr.instantiateRev body fvars) state =
      .ok (annotatedBody, final))
    (reader : proofPW fe.find? annotatedBody = some .never) :
    annotateLamsLeafI callbacks fe depth body count fvars
        (types.map fun type => (type, (⟨.never⟩ : BinderMeta))) state =
      .ok (rebuildNever (fun type body metadata => .lam type body metadata) depth
        types (count - 1) (Expr.abstractRangeC annotatedBody depth count), final) := by
  have readRun := annot_lam_write_of_read callbacks fe depth count annotatedBody .never final reader
  simp only [annotateLamsLeafI, instListRevM, abstractRangeM, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.bind, bodyRun, readRun, annotate_binders_out_never]
  all_goals rfl

/-- The real let type/value checks precede zeta. The final supplied callback
receives the original value substituted into the body, not annotatedValue. -/
theorem annotate_let_of_calls (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (type value body annotatedType typeType annotatedValue valueType result : Expr)
    (sortLevel : Level) (state afterType afterTypeInfer afterSort afterValue
      afterValueInfer afterEquality final : CState)
    (typeRun : callbacks.annotate depth type state = .ok (annotatedType, afterType))
    (typeInfer : callbacks.infer depth annotatedType afterType = .ok (typeType, afterTypeInfer))
    (sortRun : ensureSortI callbacks depth typeType afterTypeInfer = .ok (sortLevel, afterSort))
    (valueRun : callbacks.annotate depth value afterSort = .ok (annotatedValue, afterValue))
    (valueInfer : callbacks.infer depth annotatedValue afterValue = .ok (valueType, afterValueInfer))
    (equalityRun : callbacks.defeq depth valueType annotatedType afterValueInfer =
      .ok (true, afterEquality))
    (bodyRun : callbacks.annotate depth (Expr.instantiate1C body value) afterEquality =
      .ok (result, final)) :
    annotateBodyI callbacks fe depth (.letE type value body) state = .ok (result, final) := by
  simp only [annotateBodyI, inst1M, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.bind, typeRun, typeInfer, sortRun, valueRun, valueInfer, equalityRun, bodyRun]
  all_goals rfl

#print axioms head_type_of_lookup
#print axioms head_proof_of_lookup
#print axioms type_sort_const_of_lookup
#print axioms proof_const_of_lookup
#print axioms proof_app_of_head
#print axioms type_sort_forall
#print axioms proof_lambda
#print axioms head_proof_never_of_lookup
#print axioms annot_meta_never
#print axioms annot_pi_of_read
#print axioms annot_lam_of_read
#print axioms annot_pi_write_of_read
#print axioms annot_lam_write_of_read
#print axioms annotate_binders_out_never
#print axioms annotate_pi_leaf_never
#print axioms annotate_lam_leaf_never
#print axioms annotate_let_of_calls

end ADWH.Experiments.Chapter15.KernelCachedAnnotationReaders
