# Independent review: actual annotation readers and exits

Reviewer: `book_scope_review`. Author: `reflection_evidence_review`.

**Verdict: no blocking source-level issue found.** This review covers the frozen
11,883-byte KernelCachedAnnotationReaders source, SHA256
`e728b6c494f2996909486dd68ceb8d61337c6c6fbafec3c9be396d50f24c8d84`.
It is source-only: the seventeen roots are uncompiled, and no complete gate or
successful annotation/installation claim is supplied by this review. No author
or predecessor source, metadata or evidence was edited.

## Read and identity scope

I read all 231 source lines and all seventeen proof bodies against the actual
PropRead, Cached/CoreC and Cached/StateC definitions, together with PLAN.md and
AUTHOR-REVIEW.md. All 347 identities in the author inventory match the retained
files. All thirteen literal primary intervals match their complete file, exact
inclusive line range, byte count and hash. The new declaration/report order is
seventeen distinct public theorem names; its only new definition is
rebuildNever. Its one active import and three strict options match the stated
selection.

The prospective physical closure is the reviewed evaluator Core/Cached owners
and this leaf: three modules, 43 reports, six ordinary artifacts and 517,167
source bytes. The source has twenty logical origins and twenty-two segments,
including the already disclosed partial and whole evaluator omissions. Those
counts do not imply elaborated dependency completeness, original driver API
restoration or fit under the common deadline. The older source-review scopes
are retained at their own identities.

The source-assessment metadata describes the retained exact raw type/body
comparison for the three StructuralNatOnlyReference definitions and explicitly
denies actual annotation/installed-pin success. I read those retained fields
as context; I did not execute a new exporter, body comparator, evaluator or
dedicated saved-result reader. None of those facts is a hidden hypothesis of
the new mathematical leaf. The historical original-record namespace mismatch
and the annotation/install bridge remain separate work.

## Typed lookup and metadata readers

The first eight roots follow the actual pure readers. The constant cases keep
the real indexed FEnv lookup, non-tower condition and universe-arity test before
reading the full stored type or the exact peeled residual. head_type_of_lookup
requires the actual peelNeverPis residual to be a sort; it does not infer that
fact from the number of arguments or the name of an operator. The result uses
the actual Level.substPW applied to the actual stored level-parameter list.

The head-proof lemma reads typeSortPW of the full stored type. Its specialization
to `.never` uses the real definitional substitution of that datum. It supplies
no semantic validation of the datum. The const/app, forall and lambda reader
equations preserve exactly the constructor distinctions in proofPW/typeSortPW.
No declaration-kind Boolean or raw arithmetic name is substituted for a stored
type or a reader result.

These statements are operational even for a hypothetical lookup that would
not arise from a valid installation. That is appropriate for branch equations,
provided the later program proof derives the premises from the actual prefix.
The source and documentation state that remaining obligation explicitly.

## Reader/write and outward reconstruction equations

The five reader/write roots cover annotBinderMetaI and the direct successful
reader arms of annotPwPiI, annotPwLamI, annotatePisPwI and annotateLamsPwI.
They retain the actual depth-plus-count argument and return the original
supplied state. A known reader result selects the actual fast arm; no success
of an inference fallback is assumed or manufactured.

rebuildNever is an output description using the original abstractRangeC
traversal. It does not replace annotateBindersOutI. The outward-fold induction
follows the actual innermost-first stack, uses the actual index minus one at
each step, and propagates the datum just written by annotBinderMetaI. Each
stack entry has the stated `.never` input metadata, so the propagated Option
remains `some .never`. Both abstraction and the remaining fold are state
neutral. The proof does not require an unjustified equality between cached
abstraction and a separate pure operation.

The two telescope-leaf equations first perform actual instantiateRev on the
given body/array. They then consume the supplied annotation callback at
depth + count, read the datum at that callback's actual output expression and
state, abstract with the original depth/count, and reconstruct the whole
stated stack from that same state. The returned expression contains those
actual operations, and the final state is exactly the callback's state.
No relationship between count, array length, stack length or well-formed
binders is silently inferred; the equations describe the actual functions on
their stated arguments. Such relationships remain necessary when proving a
particular well-formed program's annotation.

## The real let branch

annotate_let_of_calls includes the complete actual call order:

1. Annotate the declared type.
2. Infer the annotated type's type.
3. Run the real ensureSortI action.
4. Annotate the original value.
5. Infer the annotated value's type.
6. Run actual defeq against the annotated declared type, requiring true.
7. Annotate the body after actual instantiate1C with the original value.

Every premise starts at its predecessor's returned state. The final
substitution uses `value`, not `annotatedValue`, exactly as the retained
annotateBodyI implementation does. The real sort and equality checks are
present before zeta. No whole-let annotation success premise is substituted
for those checks, and no early body comparison claims that they succeeded.

The seventh action and the telescope callbacks are lower-level premises of
body equations. They still need actual recursive proofs at the genuine
preceding knot fuel. The leaf does not close an annotation memo, prove its
hits valid, establish callback fuel bounds or assert that these callbacks
preserve additional state predicates. Returning a callback's exact state
allows an independently supplied state fact to be reused, but does not create
that fact.

## Remaining boundaries

This leaf does not prove annotation of the three complete exported program
bodies, full telescope entry/domain handling, open/close syntax identities,
the concrete let's inference/equality premises or an actual guard success.
It does not validate `.never` metadata, establish ProgramPins from installation,
construct an installed environment, prove true-prefix EnvWF, prove the original
GroupChecked target or identify a stock queens numeral. The earlier ordinary
representation and omitted driver-API integration boundaries remain unchanged.

The source is complementary to Wrapper41's specific Eq no-proof and finite
constant/literal/application equations. It does not import Wrapper41 or depend
on its current source-review correction. Its prior context includes a failed
complete120 run with 112 accepted prefix reports; that remains a failed
complete selection and is not an exemption for any future prepared object.

The reviewer performed only source reads, identity comparisons and review-file
authoring. No Lean, compiler, gate, metadata preflight, mathematical program,
exporter, profiler, retained generator or saved-evidence reader was executed.
A fresh complete closure, under the unchanged common 30-second, one-CPU/thread,
1-GiB, default-limit and three-axiom policy, remains necessary.
