# One fixed batch of exact guarded-function relations

## Status and decision

**Reviewed design v2. No candidate algebra, symbolic traversal, counter, replay or Lean run has been performed for this plan.** The parent approved the fixed policy and authorized producer implementation after these three clarifications on 2026-10-24. Execution still requires the complete source/control review. The exact v1 files are preserved in `origin/v1/`. All earlier bundles remain unchanged; this directory is outside checkpoint 175.

The proposed milestone is one complete, independently replayable **pointwise integer identity among the 35 original B views**. The fixed experiment also retains complete refutations and honest cap prefixes. It does not seek another sample-rank result, change the contraction order, compute a new queens count, or claim that a useful identity exists.

The two stages share one 50,000-request allowance: first propose the 16 canonical sample-null directions by exact rational row reduction, then check those fixed directions against the complete guarded functions. Candidate arithmetic is not free preparation. In particular, rational normalization and each Euclidean remainder are charged. A cap reached while forming candidates is a legitimate incomplete result.

## Exact inputs and what they mean

Read the frozen replay result

`next-iteration/cut-rank-review/attempts/cut-rank-replay-01/replay-report.json`.

Its `grouping.b_views` gives the 35 complete views in their recorded first-appearance order. Its `sides.B.sample_rows` gives 19 rows in their existing order; `nat_values` is the exact 35-entry row. No new row, column permutation, candidate pool, prime, or adaptive sample is allowed. The corresponding original descriptor bytes are

`next-iteration/cut-rank-review/attempts/cut-rank-01/input/trace.jsonl`,

SHA256 `6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea`.

The accepted cut replay is bound to work-trace SHA256 `048355ac631a1cf5fb9793102511e093c6015d011d08236e16f2a309dc1c6066`. The new evidence manifest binds both reports and the original bytes. It does not promote either Python report to a Lean axiom.

The old probe observed sample rank 19 on B and rank 35 on the grouped A functions. The B pool contained only 19 distinct assignments, so its rank does not establish a global relation. Full row rank modulo two implies full rational row rank for this integer sample matrix. The planned RREF still computes and checks its actual pivots; it does not install the old rank as an executable premise. An unexpected pivot count is a fixture mismatch, not permission to change the policy.

The 35 columns are functions of the common 16-variable set

`[171,174,175,177,186,187,189,191,192,193,195,200,202,203,206,208]`.

The new source validator derives support from the selected original descriptors and checks this inclusion. It neither reads a source `maximum` annotation as an oracle nor computes all historical node supports. The global identity conclusion depends only on those original descriptors, their exact interpretations, the explicit integer coefficients and completed relation proofs. Even an arbitrary or incorrect proposal matrix could not justify an incorrect identity.

## Stage 1: a fixed rational candidate batch

### Rational representation and elementary arithmetic

A rational is the canonical pair `(numerator : Int, denominator : Nat)`, with positive denominator, coprime components, and zero represented as `(0,1)`. Input matrix cells load as `(savedNat,1)`. Do not call `Fraction`, a hidden `gcd`, a symbolic algebra package, or a library matrix routine.

Every rational request is charged **before** testing its fixed local shortcut cases or requesting child arithmetic. Its nontrivial integer operations are separately charged scalar requests. `int_scalar` permits only exact addition, subtraction, multiplication, negation, absolute value and `divmod`. `divmod` requires a strictly positive divisor and permits a signed numerator, so its remainder is a Nat strictly smaller than the divisor. Denominator signs are normalized before this operation. No scalar request acts on a vector, polynomial, whole matrix, list of terms, or truth table. Integer bit lengths are reported; the existing time and address-space bounds remain in force.

The fixed shortcut priorities are:

| Request | First applicable rule |
| --- | --- |
| `rat_mul(a,b)` | either zero; left unit; right unit; otherwise two integer products and normalization |
| `rat_sub(a,b)` | right zero; exact equal pairs; left zero by one integer negation; equal denominators by one numerator subtraction and normalization; otherwise two cross products, numerator subtraction, denominator product and normalization |
| `rat_div(a,b)` | first reject zero divisor; zero numerator; unit divisor; exact equal pairs; otherwise numerator/denominator cross products and normalization |

These are exact arithmetic shortcuts, not changes to the row-reduction policy. A shortcut request still counts. Rational equality compares the two canonical integer fields; it does not launch an unrecorded arithmetic calculation.

`rat_normalize(n,d)` is a separately charged request. It rejects `d=0`; a negative denominator requests explicit negations; zero or denominator-one cases return directly. Otherwise it requests `abs(n)` and runs the Euclidean algorithm. **Each gcd step is charged before its zero test or remainder.** A nonterminal `gcd_step(x,y)` records the exact quotient and remainder of `divmod(x,y)`; the next pair is `(y,remainder)`. The final step records `y=0`. Two separately charged exact `divmod` operations divide numerator and positive denominator by the resulting gcd; both remainders must be zero. There is no unrecorded coefficient-reduction pass.

Fixed-size control tests inside a charged request are included in that request. Scanning a row, a state, a source closure, or a list of coefficients requires the item requests specified here. Container indexing and byte serialization are not mathematical oracles.

### RREF order

1. Charge one `view_load` per recorded B column and one `matrix_load` per one of the 665 saved Nat cells. These bind exact source positions; loading does not reevaluate the functions.
2. Maintain a current immutable-result reference for each matrix cell. Scan columns from 0 through 34. For each column, scan unused rows from the current pivot row upward. Every inspected candidate is a `pivot_probe`. Choose the first nonzero entry. No pivot heuristic is allowed.
3. If a row swap is needed, one charged `row_swap` request contains 35 charged `cell_swap` children in column order. The operation moves exact cell references and values; it performs no arithmetic.
4. Capture the original pivot value. Normalize the entire pivot row, columns 0 through 34, using one `rat_div` request per cell. Even a zero cell generates its shortcut request.
5. Visit every other row in row-index order. An `eliminate_probe` reads its coefficient in the pivot column. Zero skips that row. Otherwise capture the coefficient and visit all 35 columns: request `rat_mul(coefficient,pivotCell)`, then `rat_sub(oldCell,product)`. The latter result becomes that cell's current reference. No later update may read a superseded cell accidentally.
6. Commit the pivot and continue. After the fixed scan, charge a `rref_entry` check for each cell to verify the completed pivot-column identity pattern. `rref_complete` binds the 19 pivot columns and 16 free columns, the final cell references and the operation history. Different dimensions or pivot count stop as `fixture_mismatch`.

This is ordinary exact Gauss–Jordan reduction with a fixed order. The independent replay checks the whole schedule and each scalar result. It cannot accept correct isolated arithmetic with a different row origin or stale cell reference.

### The 16 candidates

For each free column `j`, in increasing column order, form the unique sample relation with free coordinate `j` equal to 1 and every other free coordinate zero:

`c_j = e_j − Σ(i<19) R[i,j] e_(pivot[i])`.

Freeze **all 16 explicit coefficient vectors before checking any global identity**. No result, failure path, timing observation or intermediate relation may modify this batch.

To clear denominators, use the product of the 19 canonical denominators `R[i,j].denominator` in pivot-row order, starting at 1. Each multiplication is an `int_scalar` request. Call the positive result `D_j`. This intentionally uses a fixed product, not a hidden least-common-multiple or primitive-vector optimization. For each of the 35 column positions, a charged `candidate_entry` returns:

- `D_j` at the designated free column;
- `−R[i,j].numerator * (D_j / R[i,j].denominator)` at pivot column `i`, with exact division, multiplication and negation charged separately; an exact zero numerator may use the explicit zero shortcut;
- zero at the other free columns.

`candidate_complete` binds the 35 entries, positive target coefficient, denominator-product references, free-column label and relevant final RREF cells. No sign rescaling or coefficient normalization follows. The canonical rational direction and this fixed positive scaling determine the integer vector completely.

Candidate generation can exhaust the cap before any global check. Completed candidates remain proposals, not partially proved identities. If the whole proposal stage finishes, their vectors remain unchanged throughout stage 2.

## Stage 2: complete identities over the original guarded functions

### Source interpretation and validation

A complete view is `(positiveMask, negativeMask, bareCoreID)`. Its value is the original core's natural value when all positive and negative literals are satisfied, and zero otherwise. Embed that value into `Int` for signed relations. Equality of bare core IDs alone never identifies two complete views.

The raw parser indexes source records by ID and preserves duplicate definitions. Validation happens only after a charged request begins. Validate node 0 and the 35 selected view cores, in column order, recursively visiting a branch's low child before its high child and a guard's core once. A cached validation is still a charged request. Reject missing or duplicate selected definitions, non-prior child IDs, out-of-range variables or masks, conflicting guards, nested unflattened guard cores, wrong branch order, and guard/core support overlap. Constants use their actual Nat values. Child support and flat views are derived from already completed validation results. No historical `maximum` is used.

Masks and support unions contain at most 210 bits. The canonical zero view is `(0,0,0)`, justified by the checked zero descriptor. Every selected B view must have derived support included in the stated 16-variable Y set. No assumption about the values at the 19 samples is needed for any source or identity rule.

### State representation and exact collection

A state is a lexicographically sorted sparse list of `(view, coefficient : Int)`, with no duplicate view and no zero coefficient. It denotes

`L_state(σ) = Σ_(view,c in state) c * Int.ofNat(viewMeaning view σ)`.

Start each candidate from its 35 fixed column occurrences. A charged `normalize` wrapper inserts them in column order. Each `term_add` is charged, including zero coefficients and canonical-zero views. To find a position in the sorted accumulator, charge each `term_compare`; a matching view requests one exact integer addition of coefficients. Remove the entry only if the resulting integer is zero. Inserting a distinct view preserves that full occurrence; no set-style deduplication is permitted. The same collector is used after restriction, in the parent state's existing term order.

Only the designated free column and 19 pivot columns can be nonzero initially. Therefore a normalized state contains at most 20 terms. Cofactoring changes views but never creates extra terms; exact collection can only merge or remove them. This bounds each key's shape, **not** the number of states or coefficient bit lengths.

### Fixed recursive policy

Check candidates in increasing free-column order. A charged `state` request begins before cache access or a support scan. It uses a charged `state_lookup` on the exact coefficient/view list. A deterministic SHA256 digest of the canonical JSON state is solely a bucket index. Buckets retain zero-state entries in completion order. Every inspected bucket entry, on a hit or a miss, starts a charged `cache_candidate`; length comparison is inside that request, followed by a charged `cache_term` for each corresponding complete entry until the first mismatch. Thus Python tuple/dictionary equality may not compare whole states behind the meter. An empty bucket gives a charged lookup miss; a digest collision cannot establish equality. A hit returns the existing earlier completed `ProofID` without allocating an alias proof node. The lookup and state requests still complete and remain charged. Only completed zero states are cached; failed or pending states are not reused.

On a miss, request `view_support` for each current term and `support_join` for each union step. These are bounded local mask operations using explicit completed source-validation references; they do not recursively traverse a source graph. `select_variable` returns the least set bit of the resulting at-most-210-bit mask, or the terminal indication. This one bounded bit operation is not a packed truth-table calculation.

If the union is empty, every view is a checked constant. Request each integer coefficient-times-constant product and each running sum addition explicitly. `terminal_decide` accepts exactly total zero. A nonzero total returns a concrete refutation with all remaining variables false and the exact nonzero integer value. An empty state is the terminal zero case.

Otherwise let `v` be the least supported variable. Process the false branch completely before starting the true branch. A charged `branch` request performs, in order:

1. One charged `cofactor(view,v,bit)` for **every** parent-state term, including terms later cancelled. All cofactors complete before collection starts.
2. Exact normalization of the resulting coefficient/view occurrences, retaining the original coefficient on each occurrence.
3. A recursive state request on that exact normalized child.

Every term has no supported variable below `v`. Consequently cofactor checking is local: satisfy or contradict a guard literal; select an actual branch child when its variable is `v`; or keep an absent-variable view unchanged using checked support. The selected child's flat guard merges with the remaining guard, with explicit contradiction and support checks. The result may be a symbolic view; it is never mislabeled as an existing source node ID. Every original descriptor or validation-cache entry read by this rule is an explicit completed dependency.

If the false child is refuted, propagate its assignment by setting `v=false` and finish this candidate without searching the true child. If false is proved zero, check true by the same policy. A true refutation propagates with `v=true`. **A zero parent requires both branches to be proved zero.** Every propagation is a charged `refute_lift` using the already checked cofactor equations. It does not call a fresh hidden evaluator.

This is a pointwise Boolean case split, not a projection or summation. An absent variable does not double a relation. The original Nat projection rules still retain their factor of two when counting; this proposal does not modify them.

### Termination and certificate dependencies

Each recursive split removes the selected least variable from all child supports. Remaining support is contained in the original 16-variable set, so recursion depth is at most 16. That is only a termination bound; a relation can still require a large simultaneous Shannon tree or many distinct coefficient states.

Work ticket IDs are assigned before work, so child ticket numbers can exceed a parent's. A result is usable only after its completion record. Zero-proof IDs are instead assigned at completed zero-state creation; their child proof references are strictly earlier. Cache publication occurs only after completion. A newly proved zero state allocates one new proof ID; a hit reuses the earlier proof ID and does not republish an alias entry. Both occurrences of a shared child reference are preserved in a binary split.

A replay checks the exact coefficient collection, local source restrictions, full candidate-root state, terminal arithmetic and both proof branches. It also checks failure assignments by composing the recorded restrictions with the nonzero terminal result. A failure establishes only that candidate's nonidentity. It cannot be used to discard another candidate or to add a new sample.

## Shared accounting and retained prefixes

The same counter charges stage 1, source validation and stage 2. There is no reset after proposing candidates, between the 16 candidates, or after a failed candidate. Reserve a ticket and write its start **before** its local inspection, cache lookup, arithmetic or recursive children. Request 50,001 is rejected before allocating a ticket or doing work.

The transcript retains starts and completions separately. Completion dependencies consist of explicit earlier input/cache references followed by direct completed child requests in call order; duplicate references remain. A completion may use only results already completed, irrespective of numeric start-ID order. The footer records the exact pending stack, current phase/candidate/cell and all operation/cache counts. A half-normalized rational, unfinished row, unfinished candidate or unfinished state is not a completed fact.

Parsing JSON bytes, retaining raw records, hashing files and recording wall/resource data are preparation. They may not validate source support, reduce fractions, scan symbolic states, evaluate samples, form candidates or perform nullspace algebra. The whole process remains under the unchanged 30-second, one-CPU, 1-GiB limits. The physical record count is reported separately from charged requests.

Useful conditional size bounds make the risk visible. Dense elimination can request up to 665 pivot-row rational divisions and 11,970 matrix-entry updates; each update requests a multiplication and subtraction before their scalar/normalization children. There can be at most 665 pivot probes and 342 elimination probes. **Those wrappers alone are not the full cost.** Nontrivial integer arithmetic and Euclidean steps can make candidate generation exceed 50,000. Sparse zero/unit shortcuts may reduce executed work, but no success or timing prediction is justified without the one reviewed bounded attempt.

Exact coefficients may grow. The report retains the largest observed numerator, denominator, integer coefficient and terminal-value bit lengths, and the largest state/stack/cache sizes. No metadata upper bound is used as a mathematical shortcut. No new bit-width, operation, board-size or time cap is silently introduced.

## What outcomes would justify

- A complete zero proof certifies its explicit global integer identity, independently of sample correctness.
- A complete nonzero terminal plus restriction path refutes only that explicit identity. The path is evidence, not a new proposal input.
- A cap, timeout, memory failure or malformed fixture leaves all prior completed results and the exact unfinished prefix. It gives no conclusion about the unfinished candidates.
- If `k` canonical candidates are proved, their distinct nonzero free coordinates make those `k` relations rationally independent. Subject to a formal bridge, this gives a B-span upper bound of `35−k`, alongside the existing sampled lower bound 19. It does not claim minimal rank.
- Even if every one of the 16 canonical candidates is refuted, another linear combination of those sample-null directions may still be a global identity. Therefore all failures do **not** establish global rank 35.

The first useful milestone is one complete relation with a manageable certificate. A coefficient-one identity with a nonnegative right side can fit the current Nat algebra directly. General signed/scaled relations may require signed intermediate factor functions, explicit denominator propagation and exact cancellation back to the original Nat total. Their usefulness is not implied by finding a relation. This experiment would not integrate a new contraction scheme, finish n8, authorize larger boards or complete n16.

## Later Lean obligations

The frozen `signed-relation-laws/SignedRelations.lean` supplies generic signed collection, cofactor, Boolean-split and earlier-DAG soundness lemmas. Its accepted fresh gate is evidence for those lemmas only. A concrete milestone still needs a checked guarded-source interpreter, local flat-view restriction and support laws, a finite signed-state/claim checker, exact candidate-view binding and the completed proof DAG. The original cut grouping and source count would need their own checked transfers before using a relation in a counting proof.

RREF need not enter that Lean trust path: the final theorem can quantify over any explicit coefficients and prove the complete identity directly. Its diagnostic calculation nevertheless remains fully charged and independently replayed. No external expected count is among the premises.

`schema.json` fixes the planned request vocabulary, inputs, outputs and control policy for review. It is not an implemented checker or an execution authorization. `evidence.json` binds this design to the frozen inputs and generic-law sources.
