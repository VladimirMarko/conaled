# Independent source review: one branch-loop induction

**Result: no mathematical or source-organization blocker found.** The three sources are prepared for a separately selected complete fresh gate. No Lean, preflight, runner, source generator, native evaluator or counter was imported or executed during this review.

| Source | Bytes | SHA-256 |
| --- | ---: | --- |
| `KernelBranchContracts.lean` | 1,726 | `d01e0a9e09d304f19efd995c19438fbd81e6e7f0dcd2bc4f1c7fadd8da261fb3` |
| `KernelBranchInduction.lean` | 11,711 | `e71c339ee15c2c6189b8912d666cb8a3c6244b99cfbf21227fd41a2ea48f8372` |
| `KernelBranchCall.lean` | 17,988 | `92a60d9fc68ed6d04fbcb1ecdd6d12138f321547a256ac35d96c1cdd4ea9f812` |

The author inventory is `ec194f52d5ae661ac29a43859cb07abaa2cbcde5e754b7c779913988610c1f06`; the exact correspondence map is `c5df2015cfe06c39244ce188be053727e2804a4d02d3225fcda8c46eb7f766d1`. I checked all **28 direct input bindings**, the complete source bodies and the relevant actual composition/loop contracts. The accompanying audit records exact headers, reports, owners and source bindings.

## Mathematical argument

The new primary proof establishes the existing `KernelBranchCall.loopNatRuns_branches` contract by induction on the natural branch fuel, generalizing both the actual closed cursor expression and its mathematical value. Its result has local-loop bound three. All original hypotheses remain: Nat and Bool recursor pins, seven arithmetic stored-operation guards, separate Boolean-equality/addition guards, closed captured parameters and cursor, actual operand runs, and pointwise `ChildRuns` evidence.

The zero-fuel case uses the existing local bound one and weakens it to three. The successor with zero cursor uses the existing selector bound two and weakens it to three. These branches do not invoke the induction hypothesis.

In the nonzero successor case, the proof obtains low-bit, updated-state and rest-cursor results from the actual arithmetic run lemmas. It proves closedness of those same expressions and applies `ChildRuns` to the exact updated arguments. The recursive predecessor is the source expression applied to `binary natSubName cursor (low modulus cursor)`, not a replacement literal. This is definitionally the `rest` expression supplied to the strictly smaller-fuel induction hypothesis.

The induction hypothesis gives its own existential knot threshold and local-loop bound three. Only that predecessor is converted to a full run, by the actual `KernelBoolSelector.runsAbove_of_loop` theorem with the explicit obligation `3 ≤ whnfLoopFuel`. The conversion adds one to its knot threshold. The subsequent addition/selector composition combines independent witnesses through the existing maxima. It does not demand a uniform threshold over all callback arguments or infer a full run from a decremented local budget.

The old `KernelBranchInduction.natRuns_branches` is then a short corollary: obtain the local result and apply the same fixed-loop conversion once. Its theorem is absent from the local induction body. Thus the dependency is noncircular: smaller local IH → predecessor full run → current local result → current full corollary.

The callback contract remains a substantive premise, to be discharged by the outer induction at smaller depth. The actual source run, current branch result or whole counter result is never assumed. Modulus and fuel remain arbitrary naturals, including zero modulus; operand values and expression witnesses remain general. No board-size or expected-count premise was added.

## Exact preservation and ownership

I independently replayed all **20 disjoint byte-offset edit spans** in both directions. They reproduce the two new variants and recover both old source files exactly. The created contracts file matches its recorded full text. The two relocated definition texts and fully qualified names are exact. All six moved private theorem declarations are exact, as are the retained representatives of the five removed duplicates.

All three public theorem headers are byte-identical to their predecessors. The entire `loopNatRuns_branchesCall` declaration and the call-file tail beginning at `bounded_mono` are unchanged. The latter includes the three previously reviewed public-substitution applications and the exact named-definition bridge. The bridge still performs seven beta steps and one ordinary delta step, yielding local bound four with complete stored declaration pins.

| Public theorem | Definition owner | Axiom-report owner |
| --- | --- | --- |
| `KernelBranchCall.loopNatRuns_branches` | `KernelBranchInduction` | `KernelBranchCall` |
| `KernelBranchInduction.natRuns_branches` | `KernelBranchInduction` | `KernelBranchInduction` |
| `KernelBranchCall.loopNatRuns_branchesCall` | `KernelBranchCall` | `KernelBranchCall` |

The report commands retain their original modules, order and names. The new contracts module prints none. Printing the imported local theorem does not establish fresh acceptance by itself: its defining induction module and the entire selected mathematical closure must also pass in the same gate.

The contract definitions retain their full namespaces while moving to `KernelBranchContracts`. That module imports arithmetic; the induction module imports the contracts; the call module imports the induction. The theorem's user namespace introduces no reverse import edge. Six private declarations change generated module ownership; this is disclosed, and no unchanged private ABI is claimed. Private theorem count falls from 21 to 16.

## Dependency scope and remaining evidence

I checked the fourteen prospective higher-module bindings and their import order. The selection includes `KernelCountLoop` and excludes the old physical `KernelCountInduction` module with the same internal namespace. All imports are available before their consumers in the stated logical order; no cycle or extra mathematical root is introduced.

The primary correspondence uses the frozen 78-report shared-substitution foundation: **43 logical origins and 140 reports**. The separately prepared shared-operations foundation instead yields **43 origins and 148 reports**. These remain distinct source selections. This review does not assemble either physical closure, choose its outputs or claim that it fits the unchanged cumulative 30-second, one-CPU/thread, 1-GiB limit.

The author is `regression_audit`; this review is by `validity_contracts`. I authored an earlier inherited staged Bool variant, independently reviewed by root. This review independently assesses the new branch-loop refactor and its exact dependency contracts; it does not re-prove every inherited operational theorem.

All selected mathematics still requires fresh ordinary Lean acceptance with the existing strict options and allowed axioms. Actual installed guard success, whole validating-checker/cache integration, native speedup and the stock sixteen-queen numeral theorem remain unestablished by this source preparation.
