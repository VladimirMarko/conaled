# One local-loop induction for the actual branch fold

Status: source-only preparation, with no selected physical layout or gate.
No Lean, compiler, exporter, checker, native evaluator, counter, source
generator, gate or preflight was executed. Every prior source and result is
unchanged. This variant was prepared after checkpoint207's selection window
and must receive its own source review before any future gate.

## The proof change

The earlier `KernelBranchInduction.natRuns_branches` proves the full-WHNF
result by induction on branch fuel. The later
`KernelBranchCall.loopNatRuns_branches` repeats the zero, empty-cursor and
nonempty-cursor case construction in order to expose local bound three; its
predecessor run invokes the earlier full theorem. Both complete case proofs
must then elaborate.

This variant proves the existing local theorem directly by one induction on
fuel, generalizing the exact closed cursor expression and its mathematical
value. The original full theorem becomes a short corollary. The named-call
bridge consumes the same local theorem through the same public name and
unchanged statement. Its entire declaration and proof remain byte-identical.

No result, source constant, arithmetic rule, environment guard, operand
bound, depth/fuel meaning or whole-run premise changes. The logical branches
still have local bounds one, two and three, promoted to three uniformly.
The ordinary named-definition delta still consumes a fourth iteration.

## Breaking the module cycle explicitly

| Declaration | Original owner module | New owner module | Full name |
|---|---|---|---|
| `ChildRuns` | `KernelBranchInduction` | `KernelBranchContracts` | `ADWH.Experiments.Chapter15.KernelBranchInduction.ChildRuns` |
| `LoopNatRuns` | `KernelBranchCall` | `KernelBranchContracts` | `ADWH.Experiments.Chapter15.KernelBranchCall.LoopNatRuns` |
| `loopNatRuns_branches` | `KernelBranchCall` | `KernelBranchInduction` | `ADWH.Experiments.Chapter15.KernelBranchCall.loopNatRuns_branches` |
| `natRuns_branches` | `KernelBranchInduction` | unchanged | `ADWH.Experiments.Chapter15.KernelBranchInduction.natRuns_branches` |
| `loopNatRuns_branchesCall` | `KernelBranchCall` | unchanged | `ADWH.Experiments.Chapter15.KernelBranchCall.loopNatRuns_branchesCall` |

`KernelBranchContracts` imports only `KernelArithmeticRuns`. It contains
exactly the two original contract definitions, with their complete
declaration text and namespaces preserved. It supplies no proof or execution
result. `KernelBranchInduction` imports the contracts, composition,
arithmetic and structural-reference modules; it never imports
`KernelBranchCall`. The latter imports the induction module as before.
Declaring a theorem in the existing `KernelBranchCall` namespace within the
induction module does not introduce an import edge.

The six local/closedness helpers used by the main loop proof move from the
old call module to the induction module, retaining their exact declaration
text and `KernelBranchCall` user namespace. Their generated private owner
changes. The old induction module's five duplicate closedness proofs are
removed. No imported client is promised access to those private names.
The call module retains its other ten private helpers unchanged,
including the three already-reviewed shared-substitution aliases.

## Noncircular induction and fuel accounting

For fuel zero, the existing actual branch-head/composition theorem supplies
local bound one, which is weakened to three. For successor fuel and cursor
value zero, the selector theorem supplies local bound two, likewise weakened
to three. Neither case calls the induction hypothesis.

For a nonzero cursor, all arithmetic children are obtained through the
actual `NatRuns` lemmas on their original expressions: low bit, the three
updated state arguments and the rest cursor. Closedness is proved for those
same expressions. The pointwise `ChildRuns` contract supplies the child
count application; it remains an explicit premise to be discharged by the
outer induction at smaller depth.

The branch predecessor is the exact expression

```text
previousApplication modulus
  (branchesRec modulus child left columns right (natExpr fuel)) cursor
```

Its rest cursor is definitionally the `binary natSubName cursor bit`
expression passed to the strictly smaller-fuel induction hypothesis. That
hypothesis yields `LoopNatRuns ... 3` with its own existential knot threshold.
Only then does `KernelBoolSelector.runsAbove_of_loop` convert it to a full
run, using the explicit proof `3 ≤ whnfLoopFuel`. The existing fixed loop
constant remains unchanged; this is not a proof from a full run at a
decremented local budget. The conversion adds one knot level, which is kept
in the predecessor's independent witness before the existing max-based
nonempty composition combines all witnesses.

The full theorem obtains the current local result from the proved induction
and performs the same fixed-loop conversion once. It is not used in the
local induction's body. Thus the dependency is local induction → full
corollary, never a mutual logical assumption.

All quantities remain general: arbitrary natural modulus, including zero;
arbitrary branch fuel represented by its actual Nat-literal major; arbitrary
closed operand/cursor expressions with independently witnessed runs; and
arbitrary callback satisfying the actual pointwise child contract. No
board-size, expected-count or runtime-fit premise is introduced.

## Exact correspondence and reporting

`PROOF-REFACTOR.json` records a complete byte-offset edit map between each of
the two old source files and its new variant. Applying the edits recovers
the new files exactly; reversing them recovers both original files exactly.
It also records creation of the contract module, the two exact definition
relocations, the six private declaration relocations, the eliminated five
duplicates, and preservation of all three public statement headers.

The `#print axioms` commands deliberately stay in their original reporting
modules and order:

- `KernelBranchInduction` prints only its original `natRuns_branches`.
- `KernelBranchCall` prints the now-imported public
  `loopNatRuns_branches`, then the unchanged `loopNatRuns_branchesCall`.
- `KernelBranchContracts` prints nothing.

The local theorem is therefore defined and checked in the induction module
but reported at its original location. A future gate must distinguish
declaration ownership from report ownership explicitly. No result is
accepted from printing an imported name alone: the induction module and
all other selected mathematical modules must have passed freshly in the
same complete gate.

## Prospective scope, not a selected layout

Relative to the frozen shared-substitution foundation of 29 origins and
78 reports, replacing the two higher files and adding the contract module
gives **43 mathematical origins and the same 140 reports**. The fourteen
higher modules still contribute 62 reports. This plan selects the coherent
`KernelCountLoop` alternative and excludes the original `KernelCountInduction`
module; its retained internal theorem namespace is not an extra import.

Root's separately reviewed shared-operations source candidate adds eight
foundation reports without changing that origin count. Combining that
candidate with this higher plan would instead give **43 origins and
148 reports**. These are distinct source selections; this candidate's
primary correspondence remains bound to the frozen 78-report foundation.
No assembled physical source bundle, artifact count, execution or acceptance
is claimed for either combination.

All selected mathematics would remain subject to one fresh cumulative
30-second, one-CPU/thread, 1-GiB gate with default heartbeat, recursion and
compiler settings. No earlier experimental objects become preparatory
dependencies. The source justification is removal of duplicated case-proof
construction and five duplicate closedness proofs, not a timing attribution
from prior buffered logs or a promise of a complete gate fitting the limit.

Exact installed-source and operational guards remain conditional. This
variant establishes no installation, actual validating-checker integration,
native speedup, larger-board result or stock Lean numeral theorem.
