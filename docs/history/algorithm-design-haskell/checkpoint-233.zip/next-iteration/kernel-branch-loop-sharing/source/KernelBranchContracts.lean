import KernelArithmeticRuns

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Shared contracts for the actual inner branch fold

These two definitions retain their original complete declaration text and
fully qualified names. Their separate module breaks the former dependency
between the full-WHNF induction and the local-loop reconstruction. Neither
definition supplies any run, fuel bound, installed pin or numerical result.
-/

namespace ADWH.Experiments.Chapter15.KernelBranchInduction

open ConLeche
open KernelNatRecursor (app3)
open KernelArithmeticRuns (NatRuns)

/-- A contract for actual applications of the child expression. The
existential knot threshold remains inside each NatRuns conclusion. -/
def ChildRuns (env : Env) (child : Expr)
    (callback : Nat → Nat → Nat → Nat) : Prop :=
  ∀ (left columns right : Expr) (l c r : Nat),
    left.looseBVarsBounded 0 = true →
    columns.looseBVarsBounded 0 = true →
    right.looseBVarsBounded 0 = true →
    NatRuns env left l → NatRuns env columns c → NatRuns env right r →
    NatRuns env (app3 child left columns right) (callback l c r)

end ADWH.Experiments.Chapter15.KernelBranchInduction

namespace ADWH.Experiments.Chapter15.KernelBranchCall

open ConLeche
open KernelLowOperation (natExpr)
open KernelBoolSelector (LoopRunsAbove)

/-- A separate witness for each actual expression, with an explicit fixed
local-loop threshold. This is only an existential wrapper on the real loop. -/
def LoopNatRuns (env : Env) (e : Expr) (value localThreshold : Nat) : Prop :=
  ∃ threshold, LoopRunsAbove env e (natExpr value) threshold localThreshold

end ADWH.Experiments.Chapter15.KernelBranchCall
