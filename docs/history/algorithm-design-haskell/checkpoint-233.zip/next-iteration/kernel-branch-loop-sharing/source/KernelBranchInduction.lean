import KernelBranchContracts
import KernelBranchComposition
import KernelArithmeticRuns
import StructuralNatReference

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# One actual inner-fuel induction with local and full consequences

The existing public local-bound theorem is proved here by induction on fuel.
Only its strictly smaller-fuel hypothesis is converted to full WHNF, using
the unchanged fixed local-loop bound. The original full-WHNF theorem is a
short consequence below. Both existing fully qualified public names and
statements are preserved. The local theorem's original axiom-report command
remains in KernelBranchCall, preserving the earlier ordered root inventory.

The exact closed cursor expression, all independent operand-run witnesses,
the pointwise child contract and the literal-major boundary are unchanged.
This source-only variant has not been compiled or used to execute a counter.
-/

namespace ADWH.Experiments.Chapter15.KernelBranchCall

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (NatRecPins)
open KernelBoolSelector (BoolPins LoopRunsAbove)
open KernelStructuralBodies
open KernelStructuralHead (BranchParametersClosed)
open KernelArithmeticRuns (NatRuns ArithmeticPins)
open KernelBranchInduction (ChildRuns)
open KernelBranchComposition (childApplication previousApplication branchThreshold
  emptySelectorThreshold nonemptySelectorThreshold)

private theorem loop_raise_local (env : Env) (e result : Expr)
    (knot smaller larger : Nat) (le : smaller ≤ larger)
    (run : LoopRunsAbove env e result knot smaller) :
    LoopRunsAbove env e result knot larger := by
  intro fuel depth budget enoughFuel enoughBudget
  exact run fuel depth budget enoughFuel (Nat.le_trans le enoughBudget)

private theorem binary_closed (name : ConLeche.Name) (left right : Expr)
    (hl : left.looseBVarsBounded 0 = true)
    (hr : right.looseBVarsBounded 0 = true) :
    (binary name left right).looseBVarsBounded 0 = true := by
  change ((true && left.looseBVarsBounded 0) && right.looseBVarsBounded 0) = true
  rw [hl, hr]
  all_goals rfl

private theorem low_closed (modulus cursor : Expr)
    (hm : modulus.looseBVarsBounded 0 = true)
    (hq : cursor.looseBVarsBounded 0 = true) :
    (low modulus cursor).looseBVarsBounded 0 = true :=
  binary_closed natLandName cursor _ hq
    (binary_closed natModName _ modulus
      (binary_closed natSubName modulus cursor hm hq) hm)

private theorem nextLeft_closed (modulus left bit : Expr)
    (hm : modulus.looseBVarsBounded 0 = true)
    (hl : left.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextLeft modulus left bit).looseBVarsBounded 0 = true :=
  binary_closed natModName _ modulus
    (binary_closed natMulName _ (natExpr 2)
      (binary_closed natLorName left bit hl hb) rfl) hm

private theorem nextColumns_closed (columns bit : Expr)
    (hc : columns.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextColumns columns bit).looseBVarsBounded 0 = true :=
  binary_closed natLorName columns bit hc hb

private theorem nextRight_closed (right bit : Expr)
    (hr : right.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextRight right bit).looseBVarsBounded 0 = true :=
  binary_closed natShiftRightName _ (natExpr 1)
    (binary_closed natLorName right bit hr hb) rfl

/-- One induction provides the actual local bound three. The recursive
predecessor is strictly smaller fuel, with its exact unevaluated rest cursor;
only that predecessor is converted to full WHNF for the addition child. -/
theorem loopNatRuns_branches (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (arithmeticPins : ArithmeticPins env)
    (modulus child left columns right : Expr) (m l c r : Nat)
    (callback : Nat → Nat → Nat → Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (modulusRun : NatRuns env modulus m)
    (leftRun : NatRuns env left l) (columnsRun : NatRuns env columns c)
    (rightRun : NatRuns env right r)
    (childCorrect : ChildRuns env child callback)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (fuel : Nat) (cursor : Expr) (q : Nat)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (cursorRun : NatRuns env cursor q) :
    LoopNatRuns env
      (.app (branchesRec modulus child left columns right (natExpr fuel)) cursor)
      (StructuralNatReference.branches m callback l c r fuel q) 3 := by
  induction fuel generalizing cursor q with
  | zero =>
      rw [StructuralNatReference.branches_zero]
      exact ⟨8, loop_raise_local env _ _ 8 1 3 (by omega)
        (KernelBranchComposition.loopRunsAbove_branchesApply_zero env natPins
          modulus child left columns right cursor)⟩
  | succ fuel ih =>
      rw [StructuralNatReference.branches_succ]
      by_cases empty : q = 0
      · rw [ite_eq_left empty]
        have cursorZero : NatRuns env cursor 0 := by
          simpa only [empty] using cursorRun
        obtain ⟨cursorThreshold, cursorAbove⟩ := cursorZero
        exact ⟨branchThreshold (emptySelectorThreshold cursorThreshold),
          loop_raise_local env _ _ _ 2 3 (by omega)
            (KernelBranchComposition.loopRunsAbove_branchesApply_succ_zero env
              natPins boolPins modulus child left columns right cursor fuel cursorThreshold
              closed cursorClosed beqStored cursorAbove)⟩
      · rw [ite_eq_right empty]
        let bit := low modulus cursor
        have bitRun : NatRuns env bit (FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_low env arithmeticPins modulus cursor m q
            modulusRun cursorRun
        have bitClosed : bit.looseBVarsBounded 0 = true :=
          low_closed modulus cursor closed.modulus_closed cursorClosed
        have updatedLeft : NatRuns env (nextLeft modulus left bit)
            (((l ||| FirstOrderNat.low m q) * 2) % m) :=
          KernelArithmeticRuns.natRuns_nextLeft env arithmeticPins modulus left bit
            m l (FirstOrderNat.low m q) modulusRun leftRun bitRun
        have updatedColumns : NatRuns env (nextColumns columns bit)
            (c ||| FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_nextColumns env arithmeticPins columns bit
            c (FirstOrderNat.low m q) columnsRun bitRun
        have updatedRight : NatRuns env (nextRight right bit)
            ((r ||| FirstOrderNat.low m q) >>> 1) :=
          KernelArithmeticRuns.natRuns_nextRight env arithmeticPins right bit
            r (FirstOrderNat.low m q) rightRun bitRun
        have childRun : NatRuns env (childApplication modulus child left columns right cursor)
            (callback (((l ||| FirstOrderNat.low m q) * 2) % m)
              (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1)) :=
          childCorrect (nextLeft modulus left bit) (nextColumns columns bit)
            (nextRight right bit) (((l ||| FirstOrderNat.low m q) * 2) % m)
            (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1)
            (nextLeft_closed modulus left bit closed.modulus_closed closed.left_closed bitClosed)
            (nextColumns_closed columns bit closed.columns_closed bitClosed)
            (nextRight_closed right bit closed.right_closed bitClosed)
            updatedLeft updatedColumns updatedRight
        let rest := binary natSubName cursor bit
        have restRun : NatRuns env rest (q - FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_binary env natSubName cursor bit q
            (FirstOrderNat.low m q) (q - FirstOrderNat.low m q)
            (Or.inr (Or.inl rfl)) arithmeticPins.sub cursorRun bitRun rfl
        have restClosed : rest.looseBVarsBounded 0 = true :=
          binary_closed natSubName cursor bit cursorClosed bitClosed
        have predecessorRun : NatRuns env
            (previousApplication modulus
              (branchesRec modulus child left columns right (natExpr fuel)) cursor)
            (StructuralNatReference.branches m callback l c r fuel
              (q - FirstOrderNat.low m q)) := by
          obtain ⟨predecessorThreshold, predecessorLoop⟩ :=
            ih rest (q - FirstOrderNat.low m q) restClosed restRun
          exact ⟨predecessorThreshold + 1, KernelBoolSelector.runsAbove_of_loop env
            (previousApplication modulus
              (branchesRec modulus child left columns right (natExpr fuel)) cursor)
            (natExpr (StructuralNatReference.branches m callback l c r fuel
              (q - FirstOrderNat.low m q)))
            predecessorThreshold 3 predecessorLoop (by unfold whnfLoopFuel; omega)⟩
        obtain ⟨cursorThreshold, cursorAbove⟩ := cursorRun
        obtain ⟨childThreshold, childAbove⟩ := childRun
        obtain ⟨previousThreshold, previousAbove⟩ := predecessorRun
        exact ⟨branchThreshold
            (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold),
          KernelBranchComposition.loopRunsAbove_branchesApply_succ_nonzero env natPins boolPins
            modulus child left columns right cursor fuel q
            (callback (((l ||| FirstOrderNat.low m q) * 2) % m)
              (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1))
            (StructuralNatReference.branches m callback l c r fuel
              (q - FirstOrderNat.low m q))
            cursorThreshold childThreshold previousThreshold closed cursorClosed empty
            beqStored addStored cursorAbove childAbove previousAbove⟩

end ADWH.Experiments.Chapter15.KernelBranchCall

namespace ADWH.Experiments.Chapter15.KernelBranchInduction

open ConLeche
open KernelLowOperation (natExpr)
open KernelNatRecursor (NatRecPins)
open KernelBoolSelector (BoolPins)
open KernelStructuralBodies
open KernelStructuralHead (BranchParametersClosed)
open KernelArithmeticRuns (NatRuns ArithmeticPins)

/-- The original full-WHNF theorem is the local-bound-three consequence.
The unchanged fixed local loop suffices; no current-call run is assumed. -/
theorem natRuns_branches (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (arithmeticPins : ArithmeticPins env)
    (modulus child left columns right : Expr) (m l c r : Nat)
    (callback : Nat → Nat → Nat → Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (modulusRun : NatRuns env modulus m)
    (leftRun : NatRuns env left l) (columnsRun : NatRuns env columns c)
    (rightRun : NatRuns env right r)
    (childCorrect : ChildRuns env child callback)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (fuel : Nat) (cursor : Expr) (q : Nat)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (cursorRun : NatRuns env cursor q) :
    NatRuns env
      (.app (branchesRec modulus child left columns right (natExpr fuel)) cursor)
      (StructuralNatReference.branches m callback l c r fuel q) := by
  obtain ⟨threshold, loop⟩ := KernelBranchCall.loopNatRuns_branches env natPins boolPins
    arithmeticPins modulus child left columns right m l c r callback closed
    modulusRun leftRun columnsRun rightRun childCorrect beqStored addStored
    fuel cursor q cursorClosed cursorRun
  exact ⟨threshold + 1, KernelBoolSelector.runsAbove_of_loop env
    (.app (branchesRec modulus child left columns right (natExpr fuel)) cursor)
    (natExpr (StructuralNatReference.branches m callback l c r fuel q))
    threshold 3 loop (by unfold whnfLoopFuel; omega)⟩

#print axioms natRuns_branches

end ADWH.Experiments.Chapter15.KernelBranchInduction
