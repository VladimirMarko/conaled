import KernelBranchInduction
import KernelDefinitionSpines
import KernelDeltaSteps

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# The actual branch-definition call with a bounded local loop

The imported inner-fold theorem directly supplies local bound three from one
fuel induction. Seven actual beta steps connect the pinned branchesValue to
that expression, and one ordinary definition delta consumes a fourth local
iteration. The original theorem names, statements and report order remain.

This is source-only preparation. Exact stored source pins are assumptions;
their successful installation or semantic validity is not asserted here.
-/

namespace ADWH.Experiments.Chapter15.KernelBranchCall

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (HeadRunsAbove NatRecPins app2 app3 app4 natType)
open KernelBoolSelector (BoolPins LoopRunsAbove)
open KernelStructuralBodies
open KernelStructuralHead (BranchParametersClosed)
open KernelArithmeticRuns (NatRuns ArithmeticPins)
open KernelBranchInduction (ChildRuns)
open KernelBranchComposition (childApplication previousApplication branchThreshold
  emptySelectorThreshold nonemptySelectorThreshold)

/- LoopNatRuns is relocated unchanged, with this same fully qualified name,
to KernelBranchContracts. -/

/-- Complete monomorphic stored-declaration pins for the actual source
branches definition. These pins do not establish environment validity. -/
structure BranchDefinitionPins (env : Env) where
  valueType : ConstantVal
  hint : ReducibilityHint
  namePin : valueType.name = branchesName
  levelsPin : valueType.levelParams = []
  typePin : valueType.type = branchesType
  stored : env.find? branchesName = some (.defnInfo valueType branchesValue hint)

/- The six local/closedness helper proof bodies have moved into
KernelBranchInduction, which provides the public loopNatRuns_branches
declaration in this same namespace and with its exact statement. Its proof
is the single inner fuel induction. The moved helpers remain private; this
report remains at its original location and order. -/

#print axioms loopNatRuns_branches

private theorem bounded_mono {bound larger : Nat} (le : bound ≤ larger) :
    ∀ {e : Expr}, e.looseBVarsBounded bound = true →
      e.looseBVarsBounded larger = true := by
  exact KernelNatRecursor.bounded_mono le

private theorem instantiate_bounded {value : Expr} :
    ∀ {e : Expr} {cutoff : Nat}, e.looseBVarsBounded cutoff = true →
      e.instantiate1 value cutoff = e := by
  exact KernelNatRecursor.instantiate_bounded

private theorem instantiate_closed (e : Expr) (closed : e.looseBVarsBounded 0 = true)
    (value : Expr) (cutoff : Nat) : e.instantiate1 value cutoff = e :=
  KernelNatRecursor.instantiate_closed e closed value cutoff

private theorem head_lambda (env : Env) (domain body : Expr) :
    HeadRunsAbove env (.lam domain body ⟨.never⟩)
      (.lam domain body ⟨.never⟩) 1 := by
  intro fuel depth enough
  have shape : fuel = (fuel - 1) + 1 := by omega
  rw [shape]
  all_goals rfl

private theorem head_raise (env : Env) (e value : Expr) (smaller larger : Nat)
    (le : smaller ≤ larger) (run : HeadRunsAbove env e value smaller) :
    HeadRunsAbove env e value larger := by
  intro fuel depth enough
  exact run fuel depth (Nat.le_trans le enough)

private def branchBody (modulus child left columns right fuel cursor : Expr) : Expr :=
  .app (branchesRec modulus child left columns right fuel) cursor

private theorem branchSelection_instantiate
    (modulus child left columns right previous cursor value : Expr) (cutoff : Nat) :
    (branchSelection modulus child left columns right previous cursor).instantiate1
        value cutoff =
      branchSelection (modulus.instantiate1 value cutoff)
        (child.instantiate1 value cutoff) (left.instantiate1 value cutoff)
        (columns.instantiate1 value cutoff) (right.instantiate1 value cutoff)
        (previous.instantiate1 value cutoff) (cursor.instantiate1 value cutoff) := rfl

private theorem branchesStep_instantiate
    (modulus child left columns right value : Expr) (cutoff : Nat) :
    (branchesStep modulus child left columns right).instantiate1 value cutoff =
      branchesStep (modulus.instantiate1 value (cutoff + 3))
        (child.instantiate1 value (cutoff + 3))
        (left.instantiate1 value (cutoff + 3))
        (columns.instantiate1 value (cutoff + 3))
        (right.instantiate1 value (cutoff + 3)) := by
  have previous : (Expr.bvar 1).instantiate1 value (cutoff + 3) = .bvar 1 := by
    apply instantiate_bounded
    simp only [Expr.looseBVarsBounded, decide_eq_true_eq]
    omega
  have current : (Expr.bvar 0).instantiate1 value (cutoff + 3) = .bvar 0 := by
    apply instantiate_bounded
    simp only [Expr.looseBVarsBounded, decide_eq_true_eq]
    omega
  change (.lam natType (.lam (natFunctionType 1) (.lam natType
    ((branchSelection modulus child left columns right (.bvar 1) (.bvar 0)).instantiate1
      value (cutoff + 3)) ⟨.never⟩) ⟨.never⟩) ⟨.never⟩) = _
  rw [branchSelection_instantiate, previous, current]
  all_goals rfl

private theorem branchBody_instantiate
    (modulus child left columns right fuel cursor value : Expr) (cutoff : Nat) :
    (branchBody modulus child left columns right fuel cursor).instantiate1 value cutoff =
      branchBody (modulus.instantiate1 value (cutoff + 3))
        (child.instantiate1 value (cutoff + 3))
        (left.instantiate1 value (cutoff + 3))
        (columns.instantiate1 value (cutoff + 3))
        (right.instantiate1 value (cutoff + 3))
        (fuel.instantiate1 value cutoff) (cursor.instantiate1 value cutoff) := by
  change (.app
    (app4 (.const KernelNatRecursor.recName [KernelNatRecursor.one]) (natMotive 1)
      branchesZero ((branchesStep modulus child left columns right).instantiate1 value cutoff)
      (fuel.instantiate1 value cutoff)) (cursor.instantiate1 value cutoff)) = _
  rw [branchesStep_instantiate]
  all_goals rfl

/-- The seven source arguments are consumed in their actual order. The five
captured step parameters are instantiated three binders deeper than fuel and
cursor. The final body head is supplied by the already proved recursor head. -/
private theorem head_branchesValue_apply (env : Env)
    (modulus child left columns right cursor head : Expr) (fuel : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (bodyHead : HeadRunsAbove env
      (branchBody modulus child left columns right (natExpr fuel) cursor) head 10) :
    HeadRunsAbove env
      (Expr.mkAppN branchesValue [modulus, child, left, columns, right, natExpr fuel, cursor])
      head 11 := by
  let b0 := branchBody (.bvar 9) (.bvar 8) (.bvar 7) (.bvar 6) (.bvar 5)
    (.bvar 1) (.bvar 0)
  let b1 := branchBody modulus (.bvar 8) (.bvar 7) (.bvar 6) (.bvar 5)
    (.bvar 1) (.bvar 0)
  let b2 := branchBody modulus child (.bvar 7) (.bvar 6) (.bvar 5)
    (.bvar 1) (.bvar 0)
  let b3 := branchBody modulus child left (.bvar 6) (.bvar 5) (.bvar 1) (.bvar 0)
  let b4 := branchBody modulus child left columns (.bvar 5) (.bvar 1) (.bvar 0)
  let b5 := branchBody modulus child left columns right (.bvar 1) (.bvar 0)
  let b6 := branchBody modulus child left columns right (natExpr fuel) (.bvar 0)
  let b7 := branchBody modulus child left columns right (natExpr fuel) cursor
  have s1 : b0.instantiate1 modulus 6 = b1 := by
    change (branchBody (.bvar 9) (.bvar 8) (.bvar 7) (.bvar 6) (.bvar 5)
      (.bvar 1) (.bvar 0)).instantiate1 modulus 6 = _
    rw [branchBody_instantiate]
    all_goals rfl
  have s2 : b1.instantiate1 child 5 = b2 := by
    change (branchBody modulus (.bvar 8) (.bvar 7) (.bvar 6) (.bvar 5)
      (.bvar 1) (.bvar 0)).instantiate1 child 5 = _
    rw [branchBody_instantiate, instantiate_closed modulus closed.modulus_closed child 8]
    all_goals rfl
  have s3 : b2.instantiate1 left 4 = b3 := by
    change (branchBody modulus child (.bvar 7) (.bvar 6) (.bvar 5)
      (.bvar 1) (.bvar 0)).instantiate1 left 4 = _
    rw [branchBody_instantiate,
      instantiate_closed modulus closed.modulus_closed left 7,
      instantiate_closed child closed.child_closed left 7]
    all_goals rfl
  have s4 : b3.instantiate1 columns 3 = b4 := by
    change (branchBody modulus child left (.bvar 6) (.bvar 5)
      (.bvar 1) (.bvar 0)).instantiate1 columns 3 = _
    rw [branchBody_instantiate,
      instantiate_closed modulus closed.modulus_closed columns 6,
      instantiate_closed child closed.child_closed columns 6,
      instantiate_closed left closed.left_closed columns 6]
    all_goals rfl
  have s5 : b4.instantiate1 right 2 = b5 := by
    change (branchBody modulus child left columns (.bvar 5)
      (.bvar 1) (.bvar 0)).instantiate1 right 2 = _
    rw [branchBody_instantiate,
      instantiate_closed modulus closed.modulus_closed right 5,
      instantiate_closed child closed.child_closed right 5,
      instantiate_closed left closed.left_closed right 5,
      instantiate_closed columns closed.columns_closed right 5]
    all_goals rfl
  have s6 : b5.instantiate1 (natExpr fuel) 1 = b6 := by
    change (branchBody modulus child left columns right (.bvar 1) (.bvar 0)).instantiate1
      (natExpr fuel) 1 = _
    rw [branchBody_instantiate,
      instantiate_closed modulus closed.modulus_closed (natExpr fuel) 4,
      instantiate_closed child closed.child_closed (natExpr fuel) 4,
      instantiate_closed left closed.left_closed (natExpr fuel) 4,
      instantiate_closed columns closed.columns_closed (natExpr fuel) 4,
      instantiate_closed right closed.right_closed (natExpr fuel) 4]
    all_goals rfl
  have s7 : b6.instantiate1 cursor 0 = b7 := by
    change (branchBody modulus child left columns right (natExpr fuel) (.bvar 0)).instantiate1
      cursor 0 = _
    rw [branchBody_instantiate,
      instantiate_closed modulus closed.modulus_closed cursor 3,
      instantiate_closed child closed.child_closed cursor 3,
      instantiate_closed left closed.left_closed cursor 3,
      instantiate_closed columns closed.columns_closed cursor 3,
      instantiate_closed right closed.right_closed cursor 3]
    all_goals rfl
  have h1 : HeadRunsAbove env (Expr.mkAppN branchesValue [modulus])
      (.lam (natFunctionType 3) (natLambdas 5 b1) ⟨.never⟩) 2 := by
    apply KernelNatRecursor.headRunsAbove_apply env branchesValue modulus natType
      (.lam (natFunctionType 3) (natLambdas 5 b0) ⟨.never⟩)
      (.lam (natFunctionType 3) (natLambdas 5 b1) ⟨.never⟩) 1 1
    · exact head_lambda env natType (.lam (natFunctionType 3) (natLambdas 5 b0) ⟨.never⟩)
    · change HeadRunsAbove env
        (.lam (natFunctionType 3) (natLambdas 5 (b0.instantiate1 modulus 6)) ⟨.never⟩)
        (.lam (natFunctionType 3) (natLambdas 5 b1) ⟨.never⟩) 1
      rw [s1]
      exact head_lambda env (natFunctionType 3) (natLambdas 5 b1)
  have h2 : HeadRunsAbove env (Expr.mkAppN branchesValue [modulus, child])
      (natLambdas 5 b2) 3 := by
    apply KernelNatRecursor.headRunsAbove_apply env (Expr.mkAppN branchesValue [modulus])
      child (natFunctionType 3) (natLambdas 5 b1) (natLambdas 5 b2) 2 1 h1
    change HeadRunsAbove env (natLambdas 5 (b1.instantiate1 child 5)) (natLambdas 5 b2) 1
    rw [s2]
    exact head_lambda env natType (natLambdas 4 b2)
  have h3 : HeadRunsAbove env (Expr.mkAppN branchesValue [modulus, child, left])
      (natLambdas 4 b3) 4 := by
    apply KernelNatRecursor.headRunsAbove_apply env (Expr.mkAppN branchesValue [modulus, child])
      left natType (natLambdas 4 b2) (natLambdas 4 b3) 3 1 h2
    change HeadRunsAbove env (natLambdas 4 (b2.instantiate1 left 4)) (natLambdas 4 b3) 1
    rw [s3]
    exact head_lambda env natType (natLambdas 3 b3)
  have h4 : HeadRunsAbove env (Expr.mkAppN branchesValue [modulus, child, left, columns])
      (natLambdas 3 b4) 5 := by
    apply KernelNatRecursor.headRunsAbove_apply env
      (Expr.mkAppN branchesValue [modulus, child, left]) columns natType
      (natLambdas 3 b3) (natLambdas 3 b4) 4 1 h3
    change HeadRunsAbove env (natLambdas 3 (b3.instantiate1 columns 3)) (natLambdas 3 b4) 1
    rw [s4]
    exact head_lambda env natType (natLambdas 2 b4)
  have h5 : HeadRunsAbove env
      (Expr.mkAppN branchesValue [modulus, child, left, columns, right]) (natLambdas 2 b5) 6 := by
    apply KernelNatRecursor.headRunsAbove_apply env
      (Expr.mkAppN branchesValue [modulus, child, left, columns]) right natType
      (natLambdas 2 b4) (natLambdas 2 b5) 5 1 h4
    change HeadRunsAbove env (natLambdas 2 (b4.instantiate1 right 2)) (natLambdas 2 b5) 1
    rw [s5]
    exact head_lambda env natType (natLambdas 1 b5)
  have h6 : HeadRunsAbove env
      (Expr.mkAppN branchesValue [modulus, child, left, columns, right, natExpr fuel])
      (natLambdas 1 b6) 7 := by
    apply KernelNatRecursor.headRunsAbove_apply env
      (Expr.mkAppN branchesValue [modulus, child, left, columns, right]) (natExpr fuel) natType
      (natLambdas 1 b5) (natLambdas 1 b6) 6 1 h5
    change HeadRunsAbove env (natLambdas 1 (b5.instantiate1 (natExpr fuel) 1))
      (natLambdas 1 b6) 1
    rw [s6]
    exact head_lambda env natType b6
  apply KernelNatRecursor.headRunsAbove_apply env
    (Expr.mkAppN branchesValue [modulus, child, left, columns, right, natExpr fuel])
    cursor natType b6 head 7 10 h6
  rw [s7]
  exact bodyHead

private theorem head_branch_body (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (modulus child left columns right cursor : Expr) (fuel : Nat)
    (closed : BranchParametersClosed modulus child left columns right) :
    ∃ head, HeadRunsAbove env
      (branchBody modulus child left columns right (natExpr fuel) cursor) head 10 := by
  cases fuel with
  | zero =>
      exact ⟨natExpr 0, head_raise env _ _ 8 10 (by omega)
        (KernelStructuralHead.headRunsAbove_branchesApply_zero env natPins
          modulus child left columns right cursor)⟩
  | succ fuel =>
      exact ⟨branchSelection modulus child left columns right
          (branchesRec modulus child left columns right (natExpr fuel)) cursor,
        KernelStructuralHead.headRunsAbove_branchesApply_succ env natPins boolPins
          modulus child left columns right cursor fuel closed⟩

/-- The actual ordinary source call spends one delta iteration after its
seven beta steps. Its result is derived from the inner induction, not supplied
as a whole-call premise. All installed body/arity pins remain explicit. -/
theorem loopNatRuns_branchesCall (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (arithmeticPins : ArithmeticPins env)
    (definitionPins : BranchDefinitionPins env)
    (modulus child left columns right : Expr) (m l c r : Nat)
    (callback : Nat → Nat → Nat → Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (modulusRun : NatRuns env modulus m)
    (leftRun : NatRuns env left l) (columnsRun : NatRuns env columns c)
    (rightRun : NatRuns env right r)
    (childCorrect : ChildRuns env child callback)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (fuel : Nat) (cursor : Expr) (q : Nat)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (cursorRun : NatRuns env cursor q) :
    LoopNatRuns env (branchesCall modulus child left columns right (natExpr fuel) cursor)
      (StructuralNatReference.branches m callback l c r fuel q) 4 := by
  let arguments := [modulus, child, left, columns, right, natExpr fuel, cursor]
  let body := Expr.mkAppN branchesValue arguments
  let applied := branchBody modulus child left columns right (natExpr fuel) cursor
  obtain ⟨innerThreshold, innerLoop⟩ := loopNatRuns_branches env natPins boolPins arithmeticPins
    modulus child left columns right m l c r callback closed
    modulusRun leftRun columnsRun rightRun childCorrect beqStored addStored
    fuel cursor q cursorClosed cursorRun
  obtain ⟨head, appliedHead⟩ := head_branch_body env natPins boolPins
    modulus child left columns right cursor fuel closed
  have bodyHead : HeadRunsAbove env body head 11 :=
    head_branchesValue_apply env modulus child left columns right cursor head fuel closed
      appliedHead
  have bodyLoop : LoopRunsAbove env body
      (natExpr (StructuralNatReference.branches m callback l c r fuel q))
      (Nat.max 11 (Nat.max 10 innerThreshold)) 3 :=
    KernelDeltaSteps.loopRunsAbove_of_same_head env body applied head _
      11 10 innerThreshold 3 bodyHead appliedHead innerLoop
  have callHead : HeadRunsAbove env
      (branchesCall modulus child left columns right (natExpr fuel) cursor)
      (branchesCall modulus child left columns right (natExpr fuel) cursor) 8 :=
    KernelDefinitionSpines.headRunsAbove_definition_spine env branchesName [] arguments
      definitionPins.valueType branchesValue definitionPins.hint definitionPins.stored
  have unfolds : unfoldDefinition env
      (branchesCall modulus child left columns right (natExpr fuel) cursor) = some body := by
    apply KernelDefinitionSpines.unfoldDefinition_spine env branchesName [] arguments
      definitionPins.valueType branchesValue branchesValue definitionPins.hint
      definitionPins.stored
    · rw [definitionPins.levelsPin]
      all_goals rfl
    · rw [definitionPins.levelsPin]
      all_goals rfl
  have noNative : ∀ knot depth, reduceNat (pureFns .verified env knot) env depth
      (branchesCall modulus child left columns right (natExpr fuel) cursor) = .ok none := by
    intro knot depth
    rfl
  exact ⟨Nat.max 8 (Nat.max 11 (Nat.max 10 innerThreshold)),
    KernelDeltaSteps.loopRunsAbove_delta env
      (branchesCall modulus child left columns right (natExpr fuel) cursor)
      (branchesCall modulus child left columns right (natExpr fuel) cursor) body _
      8 (Nat.max 11 (Nat.max 10 innerThreshold)) 3 callHead noNative unfolds bodyLoop⟩

#print axioms loopNatRuns_branchesCall

end ADWH.Experiments.Chapter15.KernelBranchCall
