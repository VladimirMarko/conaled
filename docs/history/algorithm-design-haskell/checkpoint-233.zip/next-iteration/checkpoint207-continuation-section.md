## Latest continuation — checkpoint 207

Checkpoint 207, `adwh-lean-207-selector-recovery-and-query-interface.zip`,
preserves every checkpoint 206 payload path and mathematical achievement.
The stock `cqueens 16 = 14772512` theorem remains open. Checkpoint 200's native
source-connected acceptance and checkpoint 205's accepted 62-root Natrec
closure remain the latest respective execution and operational-proof successes.
The integrated project sources and its accepted ledger are unchanged.

### Actual shared-selector result

The shared-selector complete-01 attempt failed at the cumulative deadline in
30.211182990009547 seconds, peak 861,100 KiB. Core finished in
13.547379287003423 seconds; the combined proof module was killed after
16.46732915400935 seconds and produced neither required output. It accepted
zero of 78 required roots. Its 4096-byte buffered stdout contains 38 complete
permitted reports and an incomplete fragment; this cannot identify a slow
proof, prove later diagnostic absence or establish the refactor's speed.
The exact raw report is 103,975 bytes, SHA256
`0c1c6bfaea726b1705ce44b4c308e5a0058e3942b6924c73968a632b9f304908`.

`kernel-shared-selector-bundle/RESULTS.md`, the raw logs/report, permanent
marker, exact source maps, reviews and two control-correction inverse chains
are retained. The first no-run preflight found a schema-field mismatch before
any attempt reservation; its focused correction and second passing preflight
are saved separately. Root inspected the saved-evidence auditor and ran both
live and source-only modes successfully: 103 bindings, 18 snapshot mappings,
four raw logs and six actual Core artifact identities. These audits preserve
the failure, not mathematical acceptance. The source-policy key is consumed.

### Prepared reusable interfaces

The four-file higher shared-substitution variant has independent source
review. Twelve repeated proof bodies now apply the shared Nat lemmas; all
68 original statement headers and 20 reports remain unchanged. The coherent
thirteen-module higher order selects KernelCountLoop and excludes the original
KernelCountInduction module. With the shared selector base it would contain
42 origins and 140 reports. This is a logical plan, not an accepted physical
build or a resource-feasibility result.

CountQueryGuard has independent source review. It recognizes the entire
six-literal structural evaluator expression, checks actual typed Nat/Bool/
program/arithmetic guards, computes its answer using the proved total UInt64/
Nat evaluator and derives the actual pure-reducer run. There is no expected
answer or count fixture parameter. Its cacheClause supplies the uniform-fuel
premise of the retained cache insertion law; no cache insertion or checker
patch has been performed. The guard and higher operational chain remain
uncompiled, and successful recognition of actual installed exports is unproved.

The restricted-lookup assessment identifies exactly 20 queried names. A future
checked finite extraction must verify returned records' internal names and
prove requested-key agreement. The guard evidence must then be transported
to the true declaration prefix using actual restricted-lookup agreement.
The full underlying Env of a restricted FEnv is not that prefix; the reducer
must not be run in the finite inspection environment. Source implementation
still being prepared outside this publication is not a recovery prerequisite.

### Next source-cost revision

The isolated kernel-shared-operations candidate adds eight public aliases to
unchanged existing operational proofs and replaces eight duplicate later
bodies with qualified applications. Original headers, visibility, definitions,
pins, arguments, fuel bounds, imports and options remain unchanged. It has
independent source review and exact full inverses. Selecting it with the
previous eight-origin layout would require 86 reports. No measured speedup or
compiled acceptance is claimed. Preserve the frozen predecessor attempts.

The separate optional PropWhen-law slice is retained as an author-prepared,
uncompiled candidate. It omits 36 proofs and fifteen simp registrations while
retaining every computational declaration, constructor invariant and required
isNever fact. Its exact inverse and explicit-reference census are retained;
implicit simplifier use still needs actual elaboration. The broader checker
assessment distinguishes a small insertion lemma from complete acceptance.

Continue the actual selector/whole-count path with substantive, reviewed
source or dependency improvements. Every selected new mathematical dependency
must compile freshly in the same 30-second, one-CPU/thread, 1-GiB gate, with
default heartbeat/recursion/output behavior and the three permitted axioms.
No unchanged retry, upstream metatheory exemption or splitting a selected
closure across budgets is authorized. Actual prefix recognition, the revised
validating checker and its complete success/soundness connection remain open.
Existential pure-run/cache premises alone do not prove the existing driver's
fixed-fuel success. Read the cache-seam assessment before integration.

This snapshot includes checkpoint 206's actual saved-copy and clean-restoration
receipts. It remains standalone source/evidence recovery, with no earlier ZIP
dependency and with external compiler/runtime restoration required. The older
accepted Natrec section below remains valid historical evidence.
