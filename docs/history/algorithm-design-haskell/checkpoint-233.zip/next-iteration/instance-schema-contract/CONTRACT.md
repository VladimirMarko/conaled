# Instance contract for the retained packed ADD source-count proof

## Decision and scope

This is a source-only contract, not an implementation, new fixture or execution
proposal. Its reference is the accepted packed-row n6 closure: ten fresh Lean
4.35 modules, the original `cqueens 6 = 4` endpoint, full-report SHA256
`2c471bf8d936228009ca6233948b5a4fc38b0d1175131d167cc3132f5f602fd3`.
[SOURCE-INVENTORY.json](SOURCE-INVENTORY.json) records exact file identities,
declaration anchors, field layouts, dimensions and obligations. Paths in that
inventory are relative to `work/`.

**A universal schema framework is not a prerequisite for a new instance.**
Most Lean semantics already quantify over variable, node and claim counts.
An exact per-instance adaptation of the few fixed codecs and concrete source
obligations is sufficient if the producer stays within the existing rule
language. Width abstraction would avoid duplicated field proofs, but would
not solve the counting problem.

There are two separate missing inputs. A larger producer trial first needs
evidence of a **different compression mechanism on a fixed actual boundary**,
including the construction and checking work; merely enabling `--n 7` does
not meet the retained [direction-review decision](../next-direction-review/README.md).
A complete source proof then needs a complete, independently replayed trace
in the supported language. No complete n7 fixture was found in the inspected
inventory; the retained ADD n8 traces are capped prefixes. Existing complete
residual n8 certificates use a different language. Neither missing input is
supplied by this contract.

## 1. Instance quantities and exact field layouts

Use `b` for board size, `V` for auxiliary wire variables, `N` for node count,
`C` for claim count, and `B` for the prefix needed by the initial site roots.
These are different quantities: `V` is not `b` or `b*b`.
Wire and cell IDs need not be disjoint: the source bridge uses separate wire
and occupation assignments.

The current producer `produce_packed_add.configure` derives
`r = bit_length(V)`, `d = bit_length(N)`, `a = bit_length(C)` and
`v = max(1, bit_length(maximum actual constant-node value))`. It uses inclusive
`V` and `N`, which also occur as comparison constants/sentinels. These are
encoding conventions, not new Lean axioms. The exact n6 values are
`(b,V,N,C,B) = (6,110,9454,11956,738)` and `(r,d,a,v) = (7,14,14,3)`.
If a candidate stores the target numeral 14772512 as its final constant, that
field alone needs at least 24 bits; intermediate constants may require more.
This is an encoding bound, not evidence for the target count.

| Field | n6 bit interval, low end inclusive | Instance encoding and invariant |
| --- | --- | --- |
| Node `rank` | `[0,7)` | Width `r`; constants have rank `V`, branches rank `< V` |
| Node `low` | `[7,21)` | Width `d`; constant field zero, branch child ID `<` its parent ID |
| Node `high` | `[21,35)` | Width `d`; same child-order requirement |
| Node `value` | `[35,38)` | Width `v`; branch field zero, exact natural constant otherwise |
| Node payload padding | `[38,51)` | Zero producer padding to common payload width `P`; not an additional semantic field |
| Claim `kind` | `[0,2)` | Fixed language codes: add 0, multiply 1, project 2 |
| Claim `left` | `[2,16)` | Width `d`; node ID `< N` |
| Claim `right` | `[16,30)` | Width `d`; node ID `< N`, zero for project |
| Claim `result` | `[30,44)` | Width `d`; node ID `< N` |
| Claim `var` | `[44,51)` | Width `r`; `< V` for project, zero otherwise |
| Witness `rule` | Four separate planes | Codes 0–8 remain the existing language, not a board parameter |
| Witness `splitRank` | Seven separate planes | Width `r`; split rank `< V`, zero in unused cases |
| Witness `lowOp`, `highOp` | Fourteen planes each | Width `a`; every used child claim strictly earlier than the current claim; unused fields zero |

Node width is `r + 2*d + v`; claim width is `2 + 3*d + r`.
The producer currently sets `P = max(nodeWidth, claimWidth)` **and rejects
unless `P = claimWidth`**. This is a real producer restriction. A fixture whose
node width is larger requires explicit claim padding and corresponding
serialization changes, or must be rejected; truncation is not permitted.
Equivalently, the current restriction requires `v ≤ d+2`. Conditional on
storing final value 14772512, `v ≥ 24`, so a compact complete trace with
`d < 22` would be rejected by this packer despite valid semantics. The small
repair is to zero-pad claim records to `max(nodeWidth, claimWidth)` when
needed, preserving both actual field layouts and their transport proofs.
Inflating node IDs is unnecessary; the expected numeral remains no premise.
The independent `replay_packed_add.infer_shape` repeats the restriction, and
`claim_decode` currently has no padding field. Its schema and explicit
zero-padding validation must change together with the producer; simply
deleting a guard is not the complete repair.

`ConsolidatedGeneric` fixes these offsets in `decodeNode`, `decodeClaim`,
`nodePlanes`, `claimPlanes` and four transport theorems. The general
`BulkFields.wordAt_field` already proves slice decoding for arbitrary offsets
and widths. By contrast, `NodeValid`, `LocalValid`, `ClaimMeaning`,
`ConstantLocalValid`, `packedNode_sound`, `packedClaimRules_sound` and
`claimsWithConstants_sound` already take arbitrary `V/N/C`. The formula helpers
zero-extend operands and retain the final addition carry; no fixed-width
modular interpretation of the count is allowed.

The distinguished node ID **2** in `AbsentRule` is a semantic convention, not
an n6 accident: `2 < N` and `ConstantAt V nodes 2 2` must be proved. The
minimal adaptation retains the producer's zero/one/two node convention and
the existing rule codes. Changing those conventions requires additional
source changes and proofs, not just different widths.

## 2. Dense definitions, requests and routing

The table has `D = N+C` definitions: node key `i`, claim key `N+j`.
Reference blocks are exact occurrence lists, including inactive slots:

| Block | Start formula | n6 start | Rows | Active target |
| --- | --- | ---: | --- | --- |
| Node low | `D` | 21410 | `N` | Branch child node |
| Node high | `D+N` | 30864 | `N` | Branch child node |
| Operation left | `D+2*N` | 40318 | `C` | Left/input node |
| Operation right | `D+2*N+C` | 52274 | `C` | Right node for non-project claims |
| Operation result | `D+2*N+2*C` | 64230 | `C` | Result node |
| Child low | `D+2*N+3*C` | 76186 | `C` | Claim key `N+lowOp` for rules 3–6 |
| Child high | `D+2*N+4*C` | 88142 | `C` | Claim key `N+highOp` for rules 3–4 |

Inactive and padding requests use node-zero key/payload. They must not be
interpreted as claim descriptors. `claim_reference` and `childLow_of_key` /
`childHigh_of_key` retain the explicit equation `key = N+j` before claiming a
decoded claim identity.

Occupied rows are `O = 3*N+6*C` (100098). The present routing producer chooses
`k = bit_length(O-1)` and `L = 2^k` (17 and 131072). It emits one definition
plane, `k` key planes and `P` payload planes (69 semantic planes), plus the
separate witness planes (39). The n6 route has 33 switches, 30974 padding
requests and 109662 total request occurrences. Switch count is producer
output, not a constant assumed by the Lean routing theorem.

For a new fixture, all four actual checks remain mandatory:
`prefix_checked`, `switches_checked`, `routed_matches`, `adjacency_checked`.
Their generic consequence is exact whole-packet permutation, strict table-key
bounds and payload equality for every original request. Each block also needs
`D ≤ offset` and `offset+rows ≤ L`. `indexPlanes k`, selector coverage and
constant bit-vectors must match the new dimensions. Source serialization's
2048-hex-digit chunks are a representation choice, not a counting rule or
permission to shard proof work.

## 3. Completeness obligations beyond a correctly decoded table

The following obligations are separate and all must close. Names refer to
the current `BulkADD.RealSix` sections of `ConsolidatedArithmetic` and
`ConsolidatedSource`; the inventory gives their exact anchors.

1. **Every node and claim.** `nodes_valid` covers all `i < N`, including
   canonical unused fields, descending child IDs and increasing child ranks.
   `claims_valid` covers all `i < C`. The n6 `claimSelector` excludes exactly
   5012 and 11953, discharged by `constant_add_valid` and
   `constant_mul_valid`. A new fixture must derive its entire exceptional
   index set and check every constant-arithmetic row with exact Nat addition
   or multiplication; it cannot preserve the two-index exception by default.
   All remaining rows must be covered by the actual packed selector.

2. **All factors and eliminated variables.** `PlanFactors.initialRoots`,
   `initialVariables`, `steps`, `variables_checked` and `plan_checked` must
   connect the complete initial occurrence list to a final singleton root.
   The n6 producer requires 36 initial factors, 146 factor occurrences, 110
   elimination steps, 35 selected multiplication claims and 110 projection
   claims. Its supported bucket sizes are one or two. `IDFactorPlan.StepValid`
   checks the occurrence permutation, actual operation descriptors, strict
   bounds and independence of every remaining factor via rank. A larger
   bucket needs a changed plan representation or explicit intermediate
   products; it is outside the smallest adaptation. `final_node_descriptor`
   reads the actual final root (n6: 9453) and value (4). An expected answer or
   the trace's diagnostic count field is not a premise.

3. **Every local site function.** The 36 n6 scopes, expansion trees, channels
   and initial roots change together. Each site retains expansion, tree-scope,
   channel-scope and `checkPackedSite` checks before `site*_identity`.
   The packed site checker also checks Boolean tree leaves and a zero carry
   when summing the two occupation indicators. The generator currently caps
   local scopes at eight wires; that is an engineering restriction, while the
   generic theorem quantifies over arbitrary scope lists. Local validation
   work remains part of the complete gate.

4. **Exact prefix cache, if used.** The current `B` is one plus the maximum
   initial root ID. It must satisfy `B ≤ N`; descending node IDs justify
   prefix closure. `cache_planes_checked`, bounded row equality, the explicit
   out-of-range default and `nodesValid_prefix` are retained. The row lookup
   helper already accepts arbitrary four-width layouts and counts. The
   concrete 738 records, 93 checks of size 8/2 and 92 joins are fixture data,
   not universal constants. New data require complete contiguous coverage
   within the same single gate, not a page-size sweep or extra budgets.

5. **Whole geometry and multiplicity.** n6 has 36 cells/sites, 34 lines, 110
   auxiliary wires and 144 channel occurrences. Rows and columns end at
   `some true` for exactly one occupied cell; both diagonal families end at
   `none` for at most one. `lines_wellFormed` checks
   `wires.length+1=cells.length`; `wire_coverage` is a permutation of all
   eliminated variables; `entry_coverage` is a permutation of every channel
   occurrence; `site_cells` is exactly `List.range (b*b)`. These facts and
   nodup support unique auxiliary-wire extensions and
   `site_tensor_network_sum`. Matching only sets, dimensions or a few sites
   does not establish the required multiplicities.

6. **Exact source clauses.** The n6 decoder uses cell count 36, pair-code
   threshold 1296 and column-code threshold 1302. The corresponding formulas
   are `b*b`, `(b*b)^2` and `(b*b)^2+b`. It decodes two negative literals or a
   full positive row/column clause. Its total default branch remains explicit;
   validity of the concrete lists comes from both decoded-list equalities.
   All 302 n6 clause occurrences (12 positive, 290 negative) participate in
   `network_codes_decode`, `source_codes_decode` and `codes_perm`.
   `source_clause_coverage` transports their occurrence permutation; it does
   not assume injectivity of codes or discard repeated clauses.

7. **Original source endpoint.** `OneHot.constraints`, `queensCNF`,
   `encoded_boards_perm_models` and `queens_count_eq_CNF_sum` are already
   generic in `b`. The instance must prove `network_eq_queensCNF`,
   `source_cnf_total` and then the source count. The unchanged
   `BitRepresentation.cqueens_eq_queens_count b` requires `b ≤ 16`; this is
   a theorem hypothesis, not permission for a new board run. This task remains
   source-only; the retained continuation records no board above eight having
   been attempted in this experiment lineage. The accepted symbolic Word16
   primitive proofs and scoped
   executor bridge need no larger-board-specific numerical theorem.

## 4. Smallest coherent adaptation and its proof boundary

Once an eligible complete trace exists, the smallest candidate is a **new,
exact per-instance copy of the current ten-module closure**, not a universal
framework:

- Leave `ConsolidatedGeneric` byte-identical. In a distinct fixture-local
  `Codec` namespace in the new `ConsolidatedArithmetic`, define the exact
  `decodeNode`, `decodeClaim`, `nodePlanes`, `claimPlanes`, `nodesFrom` and
  `claimsFrom` for the new widths. Supply the four specialized transports
  `nodePlanes_at`, `claimPlanes_at`, `node_reference`, `claim_reference` using
  the existing general `wordAt_field`. Qualify codec references explicitly.
  All consumers after these bridges accept arbitrary descriptor functions and
  planes, so the old fixed codecs need not be modified or used. Changing a
  copied `FrozenPackedData` section instead is a possible implementation
  choice, not a logical prerequisite.
- Generate the complete new `ConsolidatedArithmetic` literals, reference
  bindings, selectors/exceptions, factor plan, site proofs, cache proofs and
  geometry from the pinned proposed instance. Rebuild the concrete portions
  of `ConsolidatedSource`, preserving the generic one-hot correspondence and
  the original `cqueens` definition.
- Freshly check, in dependency order, `SymbolicWord16Core`,
  `SymbolicWord16Recurrence`, refined `QueensBitsPrimitives`, scoped
  `QueensBitCounting`, `LegacyListClause`, `ConsolidatedGeneric`,
  `HoistedExpansion`, `PackedRowDescriptorCache`, `ConsolidatedArithmetic`,
  `ConsolidatedSource`. Only the same seven unchanged original ADWH imports
  may use the disclosed prepared pool. No experimental object is reused.

Every new selected source and any additional required lemma belongs inside
one cumulative 30-second, one-CPU/thread, 1-GiB gate with the existing allowed
axioms. Root inventories must be derived and frozen after the concrete
exception/page/site inventories are known; the n6 count of 479 is not a
universal expected count. Old attempts, execution markers and sources stay
untouched.

An optional four-lemma parameterized codec module could replace those local
specializations, with generic `nodePlanes_at`, `claimPlanes_at`, `node_reference`
and `claim_reference` transport over a width record. It would add fresh
proof/source work and is not selected merely to obtain abstraction. Retained
n6 data can exercise either adaptation's compatibility, but would only
recheck n6; it would not test the unresolved larger-count compression problem.

## 5. Producer input and next-execution decision

The required proposed trace has a unique header and complete variable order;
dense node/claim IDs; complete row-major initial site occurrences; all
elimination/bucket records; and a unique finish with an actual constant root.
It must independently replay under the unchanged cap and carry the full
structural site/line/wire correspondence. Exact source/certificate hashes,
routing witnesses, all field-fit conditions and all proof inventories must
then be frozen. Existing generators contain historical path assumptions,
fixed hashes and n6 assertions: they are source evidence, not ready commands
to run against a new filename.

This contract supplies the adaptation map, not the missing trace or mechanism.
The next substantive research choice must supply the fixed-boundary
compression evidence required by the retained direction review before a new
larger producer is justified. No width change, current n6-only gate, n7 CLI
addition, old residual-DAG repack or unchanged n8 prefix retry is selected here.
Projected-context remains paused. No compiler, counter, source generator,
exporter or larger-board experiment was run for this contract.
