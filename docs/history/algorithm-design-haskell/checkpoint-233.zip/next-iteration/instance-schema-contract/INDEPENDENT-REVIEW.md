# Independent review of the instance contract

## Finding and scope

**The proposed boundary is sufficient at source level, and a universal instance-schema theorem is not a prerequisite.** The existing proof already separates arbitrary natural-number arithmetic and board semantics from the concrete six-board certificate. A future fixture can retain the accepted generic modules, add a few explicitly qualified, fixture-local codec definitions and transports, and replace the concrete arithmetic and source-coverage data. This conclusion assumes the new trace stays within the existing operation and factor-plan language. It is not a claim that such a complete larger trace exists or fits the resource gate.

I independently read the actual codec, formula, node/claim, factor-plan, site, geometry and source-count interfaces, plus the producer and independent replayer's width handling. I also checked every inventory binding and exact declaration anchor: **34 binding occurrences, 28 distinct files, and 150 anchors**. These are source and metadata checks. No Lean, counter, retained generator, replay, exporter or new mathematical checker was executed. No frozen artifact or living handoff was modified.

Reviewed final documents:

| Document | Bytes | SHA-256 |
| --- | ---: | --- |
| `CONTRACT.md` | 16,599 | `e2689566357e5ef18d506ea1a3515ada086aabce3f4577a2860632344197332b` |
| `SOURCE-INVENTORY.json` | 69,394 | `aa04d02575dcfb05469f685b79d555a9f8a3aac2774b13078a37a19f40fbb842` |

The source IDs below refer to the exact files and hashes in [SOURCE-INVENTORY.json](SOURCE-INVENTORY.json). `G`, `A`, `S` are the accepted packed-row `ConsolidatedGeneric`, `ConsolidatedArithmetic` and `ConsolidatedSource`; `BC` is the scoped original counting bridge; `H` and `R` are the hoisted-expansion and packed-row helpers; `P` and `E` are the retained producer and independent replayer. The inventory also pins all ten accepted mathematical sources. The reference full report remains the six-board result, SHA-256 `2c471bf8d936228009ca6233948b5a4fc38b0d1175131d167cc3132f5f602fd3`.

## 1. Which constants matter

| Current quantity | Meaning and required treatment in a new fixture |
| --- | --- |
| Board size `6`, occupancy range `36`, source decoder thresholds `1296`/`1302` | These select the actual queens problem and its clause encoding. Replace the concrete geometry and both clause-decode equalities together. The reusable source theorem already uses arbitrary `n` and `n*n`. [S: `decodeClause` 216; `source_clause_coverage` 235; `queens_count_eq_CNF_sum` 745] |
| Auxiliary limit `110` | This is the rank sentinel for constant ADD nodes and the limit for branch variables. It is not the board size or number of occupancy cells. The source theorem uses separate wire and occupancy assignments, so shared numeric IDs do not require a new global disjointness premise. [G: `NodeValid` 541; `site_tensor_network_sum` 5478; A: `occupation_total` 3032] |
| `9454` nodes, `11956` claims, definition count, block offsets and lane log `17` | These specialize the exact checked domains, dense node/claim key map and complete request layout. They are not restrictions of the generic arithmetic theorem, but using stale values would change what is checked. Replace all bounds, selectors, index planes and reference premises coherently. [A: 39–52, 329–489, 530–665] |
| Node widths `7/14/14/3`, claim widths `2/14/14/14/7` | These are encoding choices with semantic consequences: `decodeField` takes a remainder modulo a power of two. New widths and slices need exact transports to the supplied descriptor functions; truncating a larger value is not an adaptation. [G: `decodeField` 2411; `decodeNode` through `claim_reference`, 2475–2535] |
| Kind codes `0/1/2`, rule codes `0`–`8`, distinguished node ID `2` | These belong to the supported proof language. In particular, the existing absent-variable rule requires the actual node at ID `2` to be constant two. Preserve or explicitly re-prove a changed convention. [G: `AbsentRule` 837; `LocalRule` 845; `packedClaimRules_sound` 3448; `ConstantLocalValid` 3514] |
| Prefix `738`, page sizes `8/2`, 93 range proofs and 92 joins | These describe the current cache and proof partition. The helper supports arbitrary layouts, counts and ranges. A new cache needs complete bounded equality and prefix validity; its out-of-range default does not prove equality to the original table outside that prefix. [G: 3741–3786; H: `nodesValid_prefix` 15; R: `lookup`, `checkRange_sound`, `rangeAgree_append`, `lookup_default`] |
| Terminal root `9453` and value `4` | The root and value must come from the checked complete elimination plan and decoded constant descriptor. An expected numeral is never evidence for this step. [A: `plan_checked` 827; `final_node_descriptor` 831; `component_total` 838] |

The `n ≤ 16` premise in `cqueens_eq_queens_count` is already sufficient for the intended board size sixteen. It constrains the original Word16 implementation's correspondence, not the auxiliary ADD variable count or its natural-number field widths. No new numerical Word16 theorem is needed merely because the certificate uses more wires. [BC: 37–67, 113–124]

## 2. The smallest codec adaptation

The final contract correctly chooses a fixture-local `Codec` namespace as the first option. `ConsolidatedGeneric` can remain byte-identical. Its existing fixed codecs may remain unused while the new arithmetic source supplies exact `decodeNode`, `decodeClaim`, plane slices and table interpretation functions for that fixture.

The four local transports are the existing boundary: plane slices equal decoded record fields, and genuine routed payloads equal the corresponding node or claim descriptors. Each fixed-width proof can use the already general `wordAt_field`. The claim transport must retain `key = N+j`; a bound on the pooled definition table alone does not distinguish a claim from an inactive node-zero request. All downstream semantic consumers accept arbitrary descriptor functions and `NodePlanes`/`ClaimPlanes`, so there is no hidden dependence on the old decoder beyond these transports. [G: 2416–2424, 2446–2535, 2811–2845, 3448–3481]

The existing formula interface also avoids a new arithmetic theory. `eqWords` and `ltWords` zero-extend both inputs without truncation; `addWords` preserves the final carry. The underlying raw comparator rejects unequal list lengths, so a replacement should retain those wrappers rather than silently compare differently sized lists. Dense claim keys must still represent the full natural sum `N+j`. [G: 2611–2647, 2700–2736, 2890–2936, 2984–3013]

There is one concrete serialization issue to address when its condition occurs. The producer currently requires

`r + 2*d + v ≤ 2 + 3*d + r`, equivalently `v ≤ d+2`.

The independent replayer repeats this condition. Conditional on storing `14772512` as a final constant, that field requires at least 24 bits; a trace with `d < 22` would therefore be rejected by this layout restriction. This does **not** establish the target count or the necessary width of all intermediates. Widths must still derive from the actual complete trace. The small repair is common-width claim padding, with matching independent schema derivation and an explicit zero-padding check. Removing only a guard would leave encoding and replay inconsistent. [P: `configure` 24–68, `encode` 97–105; E: `infer_shape` 22–71, `node_decode`/`claim_decode` 134–141]

## 3. Completeness still has to close

The contract's obligations match the actual proof chain. The decisive boundaries are:

1. **Whole-table arithmetic:** cover every node and every claim, including every constant-arithmetic exception. The current excluded indices `5012` and `11953` are fixture data. Earlier-claim induction and node well-formedness must hold for the complete new tables. [G: `claimsWithConstants_sound` 3595; A: 594–665]
2. **Exact elimination:** preserve each factor occurrence, justify every multiplication/projection, eliminate the complete variable list, and close at the actual constant root. The current `Step` language supports a bucket of one or two factors; a larger bucket or another operation needs a precisely identified extension, not an assumption that the existing checker accepts arbitrary plans. [G: 1192–1242, 1294–1320; A: 825–846]
3. **All initial site functions:** retain the checked expansion, tree and channel support, Boolean local truth table and zero-carry condition for every initial site. A representative row, a sampled assignment or only the cache prefix is insufficient. [G: 3673–3716, 4513–4557; A: `site0_identity` 1978 and corresponding site declarations]
4. **Whole geometry:** account for every channel occurrence, all eliminated wires and all occupancy cells. The checked permutations, nodup facts and line well-formedness are what establish unique auxiliary-wire extension and the exact count transfer. The row/column endpoints encode exactly one; both diagonal families encode at most one. Set equality or a matching dimension does not replace the occurrence premises in this proof. [G: 4843–4864, 5219–5280, 5478–5504; A: 2925–2997]
5. **Original queens completeness:** establish both concrete decoded clause lists and their permutation, then derive the new network's equality with `queensCNF n`. No universal clause-code injectivity theorem is required: the current argument maps an already checked permutation. The generic board/model bijection and `queens_count_eq_CNF_sum` then connect the full count to the unchanged counter. [S: 225–260, 698–749; BC: 119–124]

These are the present route's obligations. A different compressed representation could replace an interface with a proved equivalent one, but neither a smaller stored graph nor a valid layout proves that replacement. Retained n8 residual certificates use another language; successful decoding does not transfer their semantic rules into this ADD checker.

## 4. Disposition and useful next boundary

The reviewed final contract has no source-level blocker. It incorporates the local-codec option, the complete padding/replayer repair, the conditional 24-bit observation and the distinction between theorem hypotheses and recorded experimental history. The earlier unsupported description of a global “at most eight” board policy is absent. The review adds no new permission requirement; the user's continuing authorization is unchanged.

A universal codec module or another n6 compatibility gate would not supply the two missing substantive inputs: evidence that a proposed mechanism compresses work at an actual difficult boundary, and a complete supported-language trace with all source correspondence. The retained direction review asks that construction and checking work be included in that evidence; it is not an impossibility theorem for larger instances. [DR: decision and §7]

Once a qualifying trace exists, the concrete next implementation can stay small: its local codecs and any required claim padding, complete new arithmetic/geometry literals, and the fixed-instance source bridge. Derive the actual root inventory from that instance. All selected new mathematics still belongs in one fresh cumulative 30-second, one-CPU/thread, `-j1 -M1024` gate with the existing RSS ceiling and three allowed axioms. The present 479-root inventory and page partition are not a template for extra budgets. No new count, scaling guarantee or useful n16 resource margin is established here.
