# Exact evaluator-scope Core/Cached extraction

Author: `nat_only_gap_review`. Status: source-only candidate, frozen for independent
root source review. No compiler, exporter, generator, gate, metadata preflight,
mathematical evaluator or saved-evidence reader has run for this variant.

## Purpose and exact changes

The consumed cost120 selection still exceeded the common deadline. Its retained
result records 71 accepted reports; the Syntax process was killed without any
report or diagnostic. The new candidate removes actual unreferenced declaration
families from the evaluator's physical source owners. It is an evaluator-scope
experiment, not a claim that the unchanged complete checker will fit the budget.

SOURCE-OMISSIONS.json gives every UTF-8 before/after span, both byte offsets,
lengths and hashes. Five Core edits and three Cached edits include two explanatory
prefixes. Literal forward/inverse reconstruction restores both complete consumed
sources. All retained definitions, data fields, theorem bodies, instances,
attributes, imports and source options remain byte-for-byte unchanged.

| Owner | Removed family | Original lines | Explicit declarations |
| --- | --- | --- | ---: |
| Core | BasisKind and its deriving requests | 2883–2887 | 1 |
| Core | QuotKind, Declaration and install-shape predicates | 3046–3173 | 5 |
| Core | Declaration.names | 3205–3221 | 1 |
| Core | Nine whole Basis/Canon construction origins | 3537–4382 | 72 |
| Cached | allLevelParamsDefinedP/XP/C guard family | 1755–1874 | 5 |
| Cached | constsResolveFP/FXP/FC, enterCRF, recordCConst | 2247–2372 | 5 |

Core shrinks from 335,500 to 297,743 bytes. Cached shrinks from 219,068 to
207,543 bytes. The new complete seven-owner evaluator selection totals 588,573
source bytes, a net reduction of 49,282 bytes. The two omitted certified Cached
guard walks contain 29 explicit Squash.mk result-certificate branches. Three
removed datatypes each requested DecidableEq and Inhabited derivation; no generated
declaration census is claimed. The only explicit theorem removed is the unused
allLevelParamsDefinedP_cut, which had no simp registration or selected report.
These are source/certificate counts, not measured compilation-time savings.

## Retained operational closure

The actual CState type, its fields and caches, flushing operation, all memo
operations, conversions, constant/type/rule helpers and every six-slot cached
body and coreKnotI remain exact. The pure six-slot bodies/coreKnot and public
reference wrappers also remain exact and computable. Actual bound accessors,
saturated fallback, all instantiation and scoping functions, Expr/Level/Name
representations, ConstantInfo/RecRule/constructor metadata and their instances
are retained. No infer/defeq/annotation slot is stubbed or specialized away.
instantiateList_cons and all selected 120 report roots remain present.

Only Core and Cached change in the prospective complete gate; Stable, Helper,
Syntax, Bulk and Literal retain their frozen cost120 bytes. The seven modules,
120 distinct roots and fourteen ordinary outputs remain the same. No arithmetic,
Nat iota, beta/delta, scope, prefix or installed-guard leaf is added to that gate.
No noncomputable modifier, compiler option, native API replacement, object reuse,
prepared experiment object or resource change is introduced.

## Source and dependency census

SOURCE-CENSUS.json records all 89 removed explicit qualified declarations and
checks that the retained explicit declaration start headers remain in the same
order. The exact complement map establishes preservation of their whole bodies.
It scans 25 exact sources: retained current120 leaves, all four non-Core physical
owners from accepted pure177, all frozen forthcoming operational source leaves
(including their logical/bundled prefix and installed-guard contexts), and both
new candidate owners. There are no remaining qualified deleted-name references
or unambiguous deleted short-name references in that scan.

The census is source text evidence, not an elaborated dependency export. Common
short names are recorded separately. The remaining ap2 is a local Nat-operation
builder; canon is retained PropWhen.canon; pi is a locally bound nested-rule
expression; rule and names are local parameters, and u/v/u1 are level/universe or
pattern variables. No retained source opens BasisDSL or the removed declaration
namespaces. Implicit elaboration, derived declarations and generated match names
are still subject to the complete fresh Lean gate and cannot be concluded from
token absence alone.

## Current versus historical ownership

The historical evaluator selection had 26 upstream and seven project origins:
33 logical origins and 35 source segments. Exactly nine complete upstream origins
are now absent from current mathematical ownership: Basis.Builder, Basis.Eq,
Basis.Nat, Basis.Empty, Basis.False, Basis.Quot, Basis.And, Canon and Basis.
Current ownership is therefore 17 upstream plus seven project origins: 24 logical
origins and 26 segments. Env, Cached.ExprOpsC and Cached.StateC remain owners with
explicit partial omissions. Basis.Names remains a current owner.

Historical correspondence maps, source arrays and every prior review retain their
original origins, counts and source identities. The new omission map applies
after those historical transformations. Its complete inverse preserves their
source evidence; it does not relabel their review scope or erase removed origins
from the historical record. Old source marker comments inside the candidate are
retained as historical assembly notices; the first new notice and current map
state the current partial ownership explicitly.

## Required later record-driver restoration

The removed families are real APIs used by the original parser/installer/front
door. Before proving original record processing, a coherent extension must restore
exact declaration kinds, Basis/Canon constructors and recognition, both guard
walks and recordCConst with their required proof dependencies. In particular,
removing recordCConst does not establish preservation of IEnvTags after record
insertion; removing syntactic prechecks does not establish EnvWF or annotations.
No current theorem has been rewritten to omit those later-driver obligations.

The retained source originals can supply an exact restoration overlay or appendix;
that future closure must itself be independently reviewed and freshly checked
under the unchanged policy. It cannot inherit budget acceptance from a smaller
evaluator pass. A pass here would prove only the selected evaluator/helper/syntax
roots, and would still leave whole-query cached success, actual record-state
invariants, installed guards, original GroupChecked and the stock numeral theorem
open. No budget-fit or speedup claim precedes that run.
