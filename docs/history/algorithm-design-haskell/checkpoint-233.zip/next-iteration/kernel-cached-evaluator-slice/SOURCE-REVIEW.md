# Independent root review: evaluator source extraction

Verdict: passed source-only review, uncompiled and unmeasured. The source author
is nat_only_gap_review; root independently read every removed mathematical
family and the retained declaration/scope boundaries, the complete plan and
author assessment, static census and alternative-cost analysis. The separate
audit binds61inputs, including all60author identities and the inventory itself.

## Exact edits and retained computation

Root independently reconstructed both complete source variants forward and
inverse through all eight recorded edits. Every offset, before/after byte count
and SHA256 matches. All bytes outside these removals and two documentation
prefixes are literal. Core removes37757net bytes; Cached removes11525net bytes.
The seven-owner prospective selection totals588573bytes. Existing sources,
consumed reports, markers and all earlier review scopes remain unchanged.

The Core removals are complete BasisKind and QuotKind/Declaration interfaces,
installation shape checks and Declaration.names, followed by nine whole
Basis/Canon construction origins. They do not remove ConstantVal, ConstantInfo,
RecRule, constructor metadata, Env/FEnv, expression or level representations.
Each removed whole origin has a balanced independent section/namespace wrapper.
The retained Basis.Names origin still provides reducer names. Every retained
pure body, coreKnot, public wrapper and all cached six-slot bodies/coreKnotI
remain literal; none is stubbed or made noncomputable.

The Cached removals are two complete parsed-driver guard walk families and
recordCConst. Root read their plain descent, pointer memo, intrinsic equality
certificates, cutoff, wrappers and insertion operation. Their removal reduces
actual source declarations and29intrinsic result-certificate branches; it is
not merely deletion of comments or an unused attribute. Both surrounding
namespace closures, actual CState fields, flushC, all main memo operations and
all helper bodies remain. The sole explicit theorem removed is
allLevelParamsDefinedP_cut, with no selected print or simp registration.

The actual CState helper fields, substitution cap/reset, constant/value/rule
lookup branches and NF map writes required by the prospective framed query
are unchanged. The new HelperFrame16 source is included in the static consumer
scope. Nothing in this extraction supplies that still-uncompiled leaf's proof.

## Dependency and ownership review

Root verified all89removed declaration-header identities against the old
physical sources and their exact omitted byte spans. It independently repeated
the comment/string-aware reference scan across25listed sources for all deleted
fully qualified and unambiguous short names and checked absence of a retained
open BasisDSL. The scan includes all current120leaves, accepted pure177non-Core
owners and frozen forthcoming operational sources. Ambiguous names are local
binders or retained unrelated functions (including PropWhen.canon and the local
Nat-operation ap2); a text census does not prove elaborated implicit/name or
derived-declaration resolution. Fresh Lean checking remains essential.

The current origin list is exactly the old33logical origins minus nine complete
upstream origins, giving17upstream plus7project origins,24logical origins and
26source segments. The14-entry additional segment-ownership list accounts for
non-Core segments; the12remaining Core origins supply the balance. Partial
omissions in Env, ExprOpsC and StateC are explicit. Historical maps still record
the old26/33/35counts and full origins; they must be reconstructed before this
new overlay in the complete gate, never silently reinterpreted as current scope.

Only Core and Cached change. The five other source identities, seven module
order,120distinct ordered report roots and fourteen required ordinary outputs
remain exact. All source-level resource options and selected proofs are retained.
No timing gain is inferred from byte counts, proof-branch counts or token scans.

## Later original-driver boundary

This evaluator source selection does not implement the complete original driver.
Basis/Canon construction, declaration datatypes and shape checks, both parsed
source guards and recordCConst must be restored with their exact dependencies
before an unchanged Parsed/Installed path is claimed. In particular, deleting
recordCConst proves no IEnvTags preservation after insertion; deleting guards
proves no annotation, prefix validity or input recognition. A future restored
closure must satisfy the same fresh total budget itself.

The retained noncomputable-reference assessment remains applicable: real
BasisGen elaboration executes pure annotateCore. No such variant is selected.
The explicit-proof-term idea is an unmeasured alternative requiring ordinary
checked source and complete private dependency provenance; no exporter ran.

The proposed complete120run still requires independent root control review and
metadata preflight. A successful evaluator gate would not establish whole-query
cached success, installed pins, GroupChecked, a model theorem or the stock
numeral. The fixed30-second,oneCPU/thread,1GiB,default-resource,three-axiom policy
and all permanently consumed keys are unchanged.
