#!/usr/bin/env python3
"""Fresh 120-report cached evaluator-scope selection. Root alone executes; no Lean without --run."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CORRECTION = ROOT / 'next-iteration/kernel-cached-forward-proof-corrections'
STABLE = ROOT / 'next-iteration/kernel-cached-stable-forward'
STABLE_CORRECTION = ROOT / 'next-iteration/kernel-cached-stable-proof-corrections'
DIRECT = ROOT / 'next-iteration/kernel-cached-helper-direct'
DIAGNOSED = ROOT / 'next-iteration/kernel-cached-helper-proof-repairs'
ACCEPTED_PREDECESSOR = DIAGNOSED / 'gate'
SYNTAX = ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections'
SHARING = ROOT / 'next-iteration/kernel-cached-forward-proof-sharing'
BULK = ROOT / 'next-iteration/kernel-cached-bulk-bound'
LITERAL = ROOT / 'next-iteration/kernel-cached-literal-forward'
COST_PREDECESSOR = ROOT / 'next-iteration/kernel-cached-complete-120/gate'
PRESENTATION = ROOT / 'next-iteration/kernel-cached-presentation-slice'
COUNT_SHARING = ROOT / 'next-iteration/kernel-cached-syntax-count-sharing'
OMISSION = ROOT / 'next-iteration/kernel-cached-evaluator-slice'
OMISSION_PREDECESSOR = ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate'
PREDECESSOR = DIRECT / 'gate'
STABLE_PREDECESSOR = CORRECTION / 'gate'
ORIGINAL_GATE = ROOT / 'next-iteration/kernel-cached-forward-work/gate'
BUNDLED = ORIGINAL_GATE.parent / 'bundled'
MANIFEST = HERE / 'source-manifest.json'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
FORMAT = 'adwh-kernel-cached-evaluator-slice-120-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-evaluator-slice-120-manifest-v1'
MODULES = ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedStableForward', 'KernelCachedHelperDirect', 'KernelCachedSyntaxCorrespondence', 'KernelCachedBulkBound', 'KernelCachedLiteralForward']
NAMESPACE = 'ADWH.Experiments.Chapter15.KernelCachedForward.'
ROOT_NAMES = [
    'succeeds_pure', 'succeeds_modifyGet', 'succeeds_modify', 'succeeds_bind',
    'memoEI_hit', 'memoEI_miss', 'whnf_hit', 'whnf_miss', 'whnf_zero',
    'whnfCore_hit', 'whnfCore_miss', 'instListM_succeeds',
    'instLevelParamsM_succeeds', 'storedTyIdxM_succeeds', 'storedValIdxM_succeeds',
    'constTyAtM_succeeds', 'constValAtM_succeeds', 'ruleRhsAtM_succeeds',
    'iotaCertsIAux_never', 'iotaCertsI_never', 'defEqListI_empty',
    'iotaIndexOkI_noIndices', 'whnfAppI_never', 'betaPeelI_never', 'betaPeelI_done',
]
STABLE_ROOT_NAMES = [
    'stable_run_of_unscoped', 'stable_whnf_of_runs_above', 'stable_head_of_runs_above',
    'stable_run_has_one_fuel', 'stable_run_unique', 'stable_map_empty', 'stable_map_insert',
    'stable_nf_empty', 'stable_nf_frame', 'stable_nf_insert_whnf', 'stable_nf_insert_head',
    'whnf_cache_value', 'head_cache_value', 'stable_nf_flushed', 'flushed_whnf_miss',
    'flushed_head_miss', 'flush_starts_unseeded', 'true_memo_frame',
    'whnf_forward_of_body', 'head_forward_of_body',
]
HELPER_ROOT_NAMES = [
    'map_backed_empty', 'map_backed_insert', 'ienv_tags_empty', 'helper_cache_empty',
    'helper_cache_frame', 'helper_cache_memo_frame', 'helper_cache_flushed',
    'helper_result_of_unchanged', 'helper_result_stable_nf', 'instantiateListC_cut',
    'instantiateListC_eq_plain', 'instLevelParams_eq_plain', 'instLevelParamsM_correct',
    'storedTyIdxM_correct', 'storedValIdxM_correct', 'instLevelParamsM_helper_result',
    'storedTyIdxM_helper_result', 'storedValIdxM_helper_result', 'instListM_correct',
    'constTyAtM_correct', 'constValAtM_correct', 'ruleRhsAtM_correct',
    'constTyAtM_from_prefix', 'constValAtM_from_prefix', 'ruleRhsAtM_from_prefix',
]
SYNTAX_ROOT_NAMES = ['level_params_cutoff',
 'plain_level_params_eq_pure',
 'level_params_eq_pure',
 'pure_bulk_fixed',
 'plain_bulk_eq_pure',
 'bulk_eq_pure',
 'instListM_pure_result',
 'instLevelParamsM_pure_result',
 'constTyAtM_pure_result',
 'constValAtM_pure_result',
 'ruleRhsAtM_pure_result']
BULK_ROOTS = ['ConLeche.bvarOfData_lt',
 'ConLeche.fvarOfData_lt',
 'ConLeche.satSucc_lt',
 'ConLeche.toNat_max',
 'ConLeche.toNat_sub_one',
 'ConLeche.satPred_lt',
 'ConLeche.max_lt_32768',
 'ConLeche.bvarOfData_pack',
 'ConLeche.Expr.bvarBRaw_lt',
 'ConLeche.Expr.bvarBRaw_bvar',
 'ConLeche.Expr.bvarBRaw_fvar',
 'ConLeche.Expr.bvarBRaw_sort',
 'ConLeche.Expr.bvarBRaw_const',
 'ConLeche.Expr.bvarBRaw_lit',
 'ConLeche.Expr.bvarBRaw_app',
 'ConLeche.Expr.bvarBRaw_lam',
 'ConLeche.Expr.bvarBRaw_forallE',
 'ConLeche.Expr.bvarBRaw_letE',
 'ConLeche.Expr.bvarBRaw_proj',
 'ConLeche.Expr.looseBVarsBounded_iff',
 'ConLeche.Expr.bvarBRaw_exact',
 'ConLeche.Expr.MemoBInv.empty',
 'ConLeche.Expr.MemoBInv.insert',
 'ConLeche.Expr.bvarBoundGo_spec',
 'ConLeche.Expr.bvarBoundMemo_eq',
 'ConLeche.Expr.bvarB_eq',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_cutoff_sound',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.plain_bulk_eq_pure',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_eq_pure',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.instListM_pure_result']
LITERAL_ROOT_NAMES = ['pure_head_nat',
 'pure_full_nat',
 'stable_head_nat',
 'stable_full_nat',
 'head_body_nat',
 'full_loop_nat_of_head',
 'cached_head_nat',
 'cached_full_nat']
REQUIRED = {
    'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero'],
    'KernelCachedForward': [NAMESPACE + n for n in ROOT_NAMES],
    'KernelCachedStableForward': ['ADWH.Experiments.Chapter15.KernelCachedStableForward.' + n
                                  for n in STABLE_ROOT_NAMES],
    'KernelCachedHelperDirect': ['ADWH.Experiments.Chapter15.KernelCachedHelperDirect.' + n
                                 for n in HELPER_ROOT_NAMES],
    'KernelCachedSyntaxCorrespondence': ['ADWH.Experiments.Chapter15.KernelCachedSyntaxCorrespondence.' + n
                                         for n in SYNTAX_ROOT_NAMES],
    'KernelCachedBulkBound': BULK_ROOTS,
    'KernelCachedLiteralForward': ['ADWH.Experiments.Chapter15.KernelCachedLiteralForward.' + n
                                   for n in LITERAL_ROOT_NAMES],
}
RAW_REQUIRED = {
    'KernelCompactCore': REQUIRED['KernelCompactCore'],
    'KernelCachedForward': ROOT_NAMES,
    'KernelCachedStableForward': STABLE_ROOT_NAMES,
    'KernelCachedHelperDirect': HELPER_ROOT_NAMES,
    'KernelCachedSyntaxCorrespondence': SYNTAX_ROOT_NAMES,
    'KernelCachedBulkBound': BULK_ROOTS,
    'KernelCachedLiteralForward': LITERAL_ROOT_NAMES,
}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
POLICY = {'Elab.async': False, 'autoImplicit': False, 'compiler_threads': 1,
          'cumulative_wall_seconds': 30,
          'default_heartbeats_recursion_and_compiler_options': True,
          'lean_memory_mib': 1024, 'resident_memory_kib': 1048576,
          'warningAsError': True}
HISTORICAL_120_SOURCE_PINS = [('next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCompactCore.lean',
  336027,
  'b91de3074ab7d61d07d8655cb0340ea855794c1af309a892c73f0343c85d4b17'),
 ('next-iteration/kernel-cached-forward-proof-sharing/source/KernelCachedForward.lean',
  219068,
  'f55d286c9df4cb31f12e9148bcc7b82bf0737c180709eaa585f2ea6062585041'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCachedSyntaxCorrespondence.lean',
  22155,
  '0429b107d8ad196772ed6af52d3fb5024226addd176ef18ef08a3e7a57e8eed8'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
HISTORICAL_COST_SOURCE_PINS = [('next-iteration/kernel-cached-presentation-slice/source/KernelCompactCore.lean',
  335500,
  'aaaccdd190332c305e355392cb6ef8045f5a74ce4e0081d0cc92481c72002044'),
 ('next-iteration/kernel-cached-forward-proof-sharing/source/KernelCachedForward.lean',
  219068,
  'f55d286c9df4cb31f12e9148bcc7b82bf0737c180709eaa585f2ea6062585041'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean',
  21993,
  '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-slice/source/KernelCompactCore.lean',
  297743,
  '573ab19b394b85f494711e994970e858e0c1bf5171f69c62b49921cf7e3b22ee'),
 ('next-iteration/kernel-cached-evaluator-slice/source/KernelCachedForward.lean',
  207543,
  '66cb3f9a5b4d50bcc1859414db516288e84f530874babf08f63759630aa182e4'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean',
  21993,
  '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
OMITTED_WHOLE_ORIGINS = ['ConLeche.Kernel.Basis.Builder',
 'ConLeche.Kernel.Basis.Eq',
 'ConLeche.Kernel.Basis.Nat',
 'ConLeche.Kernel.Basis.Empty',
 'ConLeche.Kernel.Basis.False',
 'ConLeche.Kernel.Basis.Quot',
 'ConLeche.Kernel.Basis.And',
 'ConLeche.Kernel.Canon',
 'ConLeche.Kernel.Basis']

FIXED = {
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
    BUNDLED / 'SOURCE-CORRESPONDENCE.json': '264fd7e7cef66082b8f116c6b3e8eb511363bc68f22384c6c715b89fdd4b328f',
    BUNDLED / 'SOURCE-INVENTORY.json': 'c001e9b25724b572a6c8ae48c605276fc791c33665a97afb148b39b533c92f5e',
    BUNDLED / 'SOURCE-AUDIT.json': 'a837f17f55ea29041e6012092c06ede8c9928b1cff4638f9eb92519a8add2139',
    BUNDLED / 'SOURCE-REVIEW.md': 'd61dd5c508517aedf291a06ac0d85b68e46369474ddac0b863640286c2c17b7e',
    CORRECTION / 'PROOF-CORRECTION.json': '921c4a15b9e77b5d00df0a0d27a63496f511873ddafa4073191a9f93f2359c4b',
    CORRECTION / 'SOURCE-AUDIT.json': '5d664f252cb76f0634a5091bbda4f494b2787f725de1df119684beed55354223',
    CORRECTION / 'SOURCE-REVIEW.md': 'd26809c70fc75505585cf5b934ebbd7939b4b7f045a6178b34165916c0909ed8',
    STABLE / 'SOURCE-INVENTORY.json': '12b93b51c94f77758b79f36ecd412ed57193a1957c85fe0eb670992fb3c7c3fb',
    STABLE / 'SOURCE-AUDIT.json': 'f4bcac938b6f00f46e9e7b4f53924cd1286bfa7c86436f1b88d7bd5cc4d38e14',
    STABLE / 'SOURCE-REVIEW.md': 'e309c82f1b9263a02911195fde542660c204961804ff1eaf0ead97be3f149be8',
    STABLE_CORRECTION / 'PROOF-CORRECTION.json': '4e559e46e14450d25ce621212d045635056bc9af25f45436b8b40428815a3b0d',
    STABLE_CORRECTION / 'SOURCE-AUDIT.json': 'ed234c0ec2e4d528b191783baade14bb7e66c569b1a355d02f6d1842540c3e25',
    STABLE_CORRECTION / 'SOURCE-REVIEW.md': '5aec4f93f875601b980debefa608506ae13b12b8cad24e0fffaf1ceace985a9d',
    DIRECT / 'PROOF-CORRECTION.json': '452dea5fa7d99bea9a02a771c1f9a8c01fabcc9f6808d908a6dfe76425fbfc41',
    DIRECT / 'SOURCE-INVENTORY.json': '4a2d1c43edda021d5f9495d8b538e041e4c41f9303aa2dbaafde5a3e3d612039',
    DIRECT / 'SOURCE-AUDIT.json': 'e37b164c2fe9b5862da224231879dc4045bc42bfc6c04f6e6bd7d145c22bae48',
    DIRECT / 'SOURCE-REVIEW.md': 'ca06e8cd3b5d91067e9aeffaf92aa8c4054210f701b752d2c863abf3a9e3ead3',
    DIAGNOSED / 'PROOF-CORRECTION.json': 'b2e80318564bb23ecdf7b377c5f490574049a9ff1e9537baf063f887e14c1794',
    DIAGNOSED / 'SOURCE-INVENTORY.json': 'ab226bf4cb7ce175d1b403104e602bb05b1c195e9d146d6763ac5d2a8dbc7742',
    DIAGNOSED / 'SOURCE-AUDIT.json': '0a9ed6e2cc91c9698c31bfa4e731b13b8729d13ca557a15b83f857e4ee4d1e52',
    DIAGNOSED / 'SOURCE-REVIEW.md': 'fe5d0304726eba2fd26645cc3aa5e94c814ced133fbbfb10dd9dad7eb6347bd7',
    PREDECESSOR / 'attempts/complete-01/report.json': '9eb9fef9f6d5d1ded434675495e9e2ab6ed77f3d1cdd0d898c3fbfc80c4d5635',
    PREDECESSOR / 'attempts/complete-01/KernelCachedHelperDirect.stdout.log': '76ce4f727a29c7648689b39cd3014986503a9c1616c32e17bbf8ac9c861fd82e',
    PREDECESSOR / 'execution-markers/complete-c7be13545fb772ae734d0aa6c3568a22709662870f3b7058ab0f66a8561ab321.json':
        '5437ec3caadf299854848cf47494f000d0fc6d09c1149cdd1cd6e803fe4ffc76',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/PROOF-CORRECTION.json': 'd47cb05c4b9c3b1b1a7af9832e2bfbe865593f6928e5e796f7ae09e540d784df',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-INVENTORY.json': 'b2fd5f6372a8f50dc10360bd3fbcca2a5eb35353f04fdf7401f3f2f6645776de',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-AUDIT.json': '9ce96ceffce8d01396e7c126e70257db6a77d88eb66d1f854be16576d6ac9110',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-REVIEW.md': 'a5aacb07793e5b82df9280070fba62801197cc98a4e17ad7aab5b98efd04a378',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/PROOF-OVERLAY.json': 'afb29fcbc1e31ae87c8d4e203c6930f49786754c5d7b0128fe4d269df681f589',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-CORRESPONDENCE.json': 'e9888035205452549c7080acef2b75a9fed00aed7d822eb1941549347fffec9b',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-INVENTORY.json': '7e03b38816335ecbc8685e84ddcd58b6e908ba267fbedcf660b03a4cf174262a',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-AUDIT.json': 'a473f95514dac7fcc6fbfa3fb18702d22c7d3073527024a6079b523e0c635cd7',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-REVIEW.md': 'c70c25643de2f329e95248b425e57a2db89eca30c033fef2e363cfb2bbdf5a54',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-CORRESPONDENCE.json': 'a6a245aa258ec3fb75879be5ef4a59d47f1ca94d8f73a97d088071a49c70d750',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SLICE-BOUNDARY-CORRECTION.json': '9d5636dabea34d84b99e0c035ff2cd6cf53c33d7bac91236709b0222835dac6a',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-INVENTORY.json': '3ec1eb8f5fdcdf5ba2533ce332b8b7bdd740059bd24ca73e30e30b38ea454847',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-AUDIT.json': '584941f93555a1165a30079084e39b41b0e3562639bb5623a0cc409ecc82e438',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-REVIEW.md': '56d4daad9e53a46759def8b53299f371b61c0daee7b4295bf386e1f3de8a47c8',
    ROOT / 'next-iteration/kernel-cached-literal-forward/REVIEW-WORDING-CORRECTION.json': '0fa2132d2467be55126c14f8cf2c3245f0074a43295e381c40cc462e429e7b53',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-INVENTORY.json': '2f2f5588a3c048b62adba38783f469f95486536c4225cc507b3b60cbef84df96',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-AUDIT.json': '271bd3647fbffba3e3d1ba04ccda5922f758a947fa1ebb4b766b6bfbeb0ca4a2',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-REVIEW.md': '0f2ec16817a349b2f9ac63a110f39204bb80f96c3f65450c0ea0604d86ae8984',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/run_gate.py': '663ae3b965c439ddf48205c28213fcce76f5b690e110a4449f097cd71cc0e138',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/source-manifest.json': 'feb9df79f0ff7c610494ffa017e3d6eb8dfcb5fc8ba6b3d4a1953b5e33b3f684',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/PROTOCOL.md': '9ed08c7ab1fbf0e1c2c173671d4894237443ec1b78104500e00dcf2dc12ee9c3',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/INDEPENDENT-CONTROL-REVIEW.md': 'd0fe46684410ca6639ebd12a698e831e6d56fcc86a2b8e04dcde4bbca17fc8ce',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/report.json': 'e5df6430b847459c7572db232b4f1699b21cb1253d76b2e8b5434324e7ef625c',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/execution-markers/complete-efb1eed69cd6102398244e005a8cba75455a39e4c687b2fad539ba5aa1f8c444.json': '62add59871126874e8adb4920598f6cfbf3cc0980351daafbf0f925655590543',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/PRESENTATION-OMISSIONS.json': 'ae680f4611cfcf92167f63abaad1edbb509d896a5358563695ca194cb4159be4',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/STATIC-CENSUS.json': '42c52902151cf2382657090112ecef5b56adcbb8da7dc32ada29d8a205cbae66',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-INVENTORY.json': '073c5dceee9d5c348ec78e8cff4bc0561ca16e0dae2dbd2f48979356dcca8c12',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-AUDIT.json': '44cd82ab8006080a7cb686400da941980db575a370152b6d9e5866ab40bfe4c4',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-REVIEW.md': 'a5bcff768a0c6fe5d7d1bc6e76201993aa47b268097c9c8494caf8c1e0ad9970',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/PLAN.md': 'c61100b3c50d918a339ff56fd4ed5abdf764981ca7b4a110a066ea5e90809142',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/PROOF-OVERLAY.json': 'bd7b10024da7925f9b568c4c1adf83e3bb94e77dd4aeec35f58e645e22b9bf92',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-INVENTORY.json': '4a26aa56b016f7f22ef8b96d6dabd24768a46f087a08eb6e027716b9441c0d5d',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-AUDIT.json': 'ece74d9a5fda51ee34b5114e1cdc9ea1b296323e113d27f5ca1a870ecf28a7ed',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-REVIEW.md': '70d6f0cb92e886093945041df302d559c254be43977a0a64facc8d279c86aefa',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/PLAN.md': '534d7c40b714995377d4a96c0d8a5e488ee34010808dfb05139e79ad8ac3bdcd',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/run_gate.py': 'dca4f133beec0cd8488f063973ea68a316caa17e74e80ea4f0462e582dc29f2f',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/source-manifest.json': '21e7a9cdb086c9440869c9e9fb0355b2edfd0047e9b4c59312d179c265b91e20',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/PROTOCOL.md': '001fc582953bd92aed68e531ca87bc7f76cf7fc95b3258cf808800fe5e175b7e',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/AUTHORING.md': '68e4b7e3acfb07d12cf04793114c3c1278d95906643c1b3c49cba1682df915a1',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/INDEPENDENT-CONTROL-REVIEW.md': '202aa19627bcea128634fc8a546f283f4f7e865c96827fcb660e2d02079589d4',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/report.json': '78f26ceecef3ee2345fcae825faf9c3c2c9adc2a102629e475a788443160cc11',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/execution-markers/complete-785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e.json': 'f4df56cb45dfdf40fa8a85a5125b0aaab772ebfc97728bd021e30f41986efd4c',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-OMISSIONS.json': '3107123cf85d5952e3007f662f71bdd1b6bc93d2f6f5d87a61d195237f162b09',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-CENSUS.json': '60cc15b6a20bb35fa22a29c085ce2767c572e31fb218566e7563bb80ab28ba01',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-INVENTORY.json': 'a1331f78878ff382eefd967faeeb90491725ddc15dcac2ca9daa73685f1cb273',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-AUDIT.json': '8e491b44a84f3b2a84af35a8e07e3297ffb407b8ac573e91269aebad31685383',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-REVIEW.md': '4c51622961d69aab5ce1372df96742e4bc3e0464994a43d17e94953b6e4e7522',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/PLAN.md': 'e4fb5feb67b637a3a529a92e18b1f123f2d4a2f754e4902ba5da2040521972d2',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/AUTHOR-REVIEW.md': 'f89a6bff3b4c2d79021d81858b1faff66a3a922f19f1412c45f3ed094243788a',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/ALTERNATIVE-COST-ROUTES.md': '4f88ee6ccbc6dde4381959eee8986bdc61803d5dff69c6c2d4ec784eab559ba9',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/run_gate.py': '706acbb38dc5129f2e63f637e6828afc8fa994183a6f6024ad977408346647a2',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/source-manifest.json': 'd3db0d88fdb63e6cf70c27b81e5d7251223f3f2ecb136d3630ba7cf10c5a5e19',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/PROTOCOL.md': '014cb95b03bd3b60b1c87c24237dd4c4f82e4e7d00a9e40a5fdadb0970e75111',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/AUTHORING.md': '9de6176fe79b3cc85e06b1cd9bebc8bf77741c5e0ae8cfc793a78733d3cdfa66',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/CONTROL-CORRESPONDENCE.json': 'efbcea4dc10788530ee6ec2df7284de85672322ae6c3e872087264e1b8e90d33',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/INDEPENDENT-CONTROL-REVIEW.md': '568460741d60b04c67e6875c56c1278244ca15848dedec9a01a1262d418ce29a',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/report.json': '90af5dd72031f041a5c7a8674ad7f039cc5d59e1f7f3120e3b0172ab9bb3d828',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/execution-markers/complete-3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5.json': 'e0ec22c88b955a3cfc432078e43dc60fc434a242c8b65f9f8d23929ec01b7650',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def local_path(name):
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name,
            'Nonlocal input path: ' + name)
    path = ROOT.joinpath(*rel.parts)
    require(path.resolve().is_relative_to(ROOT), 'Escaping input path: ' + name)
    require(path.is_file() and not path.is_symlink(), 'Missing ordinary input: ' + name)
    return path


def identity(row, h):
    path = local_path(row['path'])
    actual = h.binding(path)
    require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
            'Input identity differs: ' + row['path'])
    return actual


def verify(rows, readonly=False):
    for row in rows:
        path = Path(row['path'])
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
                and sha(path) == row['sha256'], 'Input/output identity differs: ' + str(path))
        if readonly:
            require(path.stat().st_mode & 0o222 == 0, 'Writable frozen evidence: ' + str(path))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fingerprint(sources):
    # A control/metadata edit or attempt rename does not reset a consumed source key.
    body = {'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
            'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def imports(code):
    return [name for group in re.findall(
        r'^\s*(?:(?:public|private|meta)\s+)*import[ \t]+(?:all[ \t]+)?([^\n]+)', code, re.M)
        for name in group.split()]


def check_source(row, guard):
    module = row['module']
    path = local_path(row['path'])
    code = guard.check_lean_source(path, path.read_text())
    require(imports(code) == row['imports'], 'Physical import census: ' + module)
    require(not re.search(r'^\s*module\s*$', code, re.M), 'Unexpected module format: ' + module)
    options = ([('linter.unusedSimpArgs', 'false')] * 2 if module == MODULES[0] else
               [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]
               * (3 if module == MODULES[1] else 1))
    require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)', code) == options,
            'Source option or resource override: ' + module)
    require(not re.search(r'^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b', code, re.M),
            'Executable elaborator command: ' + module)
    require(re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
            == row['raw_source_print_identifiers'], 'Ordered source reports: ' + module)
    require(not re.search(r'^\s*(?:public\b|meta\s+import|import\s+all)|@\[(?:expose|no_expose)\]', code, re.M),
            'Unsupported legacy visibility command: ' + module)


def apply_edits(original, edits, offset_key, before_key, after_key):
    output, cursor = bytearray(), 0
    for edit in edits:
        start = edit[offset_key]
        before, after = edit[before_key].encode(), edit[after_key].encode()
        require(type(start) is int and cursor <= start <= len(original), 'Overlapping or invalid edit')
        require(original[start:start + len(before)] == before, 'Recorded edit does not match source')
        output.extend(original[cursor:start])
        output.extend(after)
        cursor = start + len(before)
    output.extend(original[cursor:])
    return bytes(output)


def verify_correspondence(mapping, h):
    historical = read(ROOT / 'next-iteration/kernel-sliced-selector/SOURCE-BUNDLE.json')
    unit = historical['physical_units'][0]
    require(unit['module'] == MODULES[0] and len(unit['origin_units']) == 21,
            'Inherited Core origin census')
    identity(unit['source'], h)
    assembled = bytearray(unit['bundle_header'].encode())
    for origin in unit['origin_units']:
        identity(origin['original'], h)
        raw = local_path(origin['original']['path']).read_bytes()
        body = apply_edits(raw, origin['edits'], 'original_offset', 'original_text', 'replacement_text')
        assembled.extend(origin['prefix_text'].encode())
        require(len(assembled) == origin['bundle_body_start_byte']
                and len(body) == origin['bundle_body_bytes']
                and hashlib.sha256(body).hexdigest() == origin['bundle_body_sha256'], 'Inherited origin span')
        assembled.extend(body)
        assembled.extend(origin['suffix_text'].encode())
    require(bytes(assembled) == local_path(unit['source']['path']).read_bytes(), 'Inherited Core assembly')
    overlays = []
    for component, count in [('kernel-legacy-core-selector', 24), ('kernel-ordinary-fields-core', 4)]:
        overlay = read(ROOT / f'next-iteration/{component}/SOURCE-CORRESPONDENCE.json')
        identity(overlay['original_source'], h)
        identity(overlay['candidate_source'], h)
        original = local_path(overlay['original_source']['path']).read_bytes()
        candidate = local_path(overlay['candidate_source']['path']).read_bytes()
        require(overlay['edit_count'] == len(overlay['edits']) == count, 'Inherited overlay edit count')
        require(apply_edits(original, overlay['edits'], 'original_start_byte', 'before', 'after') == candidate
                and apply_edits(candidate, overlay['edits'], 'candidate_start_byte', 'after', 'before') == original,
                'Inherited overlay forward/inverse: ' + component)
        overlays.append({'component': component, 'edits': count, 'exact_forward_and_inverse': True})
    current = mapping['physical_units'][1]
    identity(current['selected_source'], h)
    complete = local_path(current['selected_source']['path']).read_bytes()
    assembled = bytearray(current['bundle_header'].encode())
    segments = []
    for origin in current['source_segments']:
        if origin['kind'] == 'exact_supplemental_slice':
            identity(origin['full_origin_input'], h)
            original = local_path(origin['full_origin_input']['path']).read_bytes()
            first, stop = origin['upstream_original_start_byte'], origin['upstream_original_end_byte_exclusive']
            require(type(first) is int and type(stop) is int and 0 <= first <= stop <= len(original),
                    'Supplement source interval')
            body = original[first:stop]
            require(not origin['edits'] and body == origin['source_text'].encode()
                    and len(body) == origin['source_slice_bytes']
                    and hashlib.sha256(body).hexdigest() == origin['source_slice_sha256'],
                    'Supplement is not the exact original source interval')
        else:
            require(origin['kind'] in ('full_upstream_unit', 'full_project_unit'), 'Unknown source segment')
            identity(origin['original'], h)
            original = local_path(origin['original']['path']).read_bytes()
            body = apply_edits(original, origin['edits'], 'original_offset', 'original_text', 'replacement_text')
            require(apply_edits(body, origin['edits'], 'transformed_offset', 'replacement_text', 'original_text')
                    == original, 'Full new origin inverse')
        require(len(assembled) == origin['bundle_prefix_start_byte'], 'New origin prefix offset')
        assembled.extend(origin['prefix_text'].encode())
        require(len(assembled) == origin['bundle_body_start_byte']
                and len(body) == origin['bundle_body_bytes']
                and hashlib.sha256(body).hexdigest() == origin['bundle_body_sha256'], 'New origin body span')
        assembled.extend(body)
        assembled.extend(origin['suffix_text'].encode())
        segments.append({'owner': origin['module'], 'kind': origin['kind'], 'exact_source_correspondence': True})
    require(bytes(assembled) == complete, 'Complete cached assembly reconstruction')
    require(len(segments) == 9 and sum(x['kind'] == 'exact_supplemental_slice' for x in segments) == 2
            and sum(x['kind'] == 'full_upstream_unit' for x in segments) == 5
            and sum(x['kind'] == 'full_project_unit' for x in segments) == 2,
            'New segment census')
    return {'inherited_Core_origins': 21, 'inherited_Core_literal_reconstruction': True,
            'separate_Core_overlays': overlays, 'new_source_segments': segments,
            'new_physical_source_literal_reconstruction': True,
            'historical_reviews_rebased': False, 'elaborated_API_equivalence_asserted': False}


def verify_proof_correction(correction, h):
    require(correction['author'] == 'root' and len(correction['corrections']) == 3,
            'Correction authorship/source scope')
    outcomes = []
    for row, expected in zip(correction['corrections'], [2, 4, 6]):
        identity(row['original'], h)
        identity(row['candidate'], h)
        original = local_path(row['original']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        edits = row['exact_source_edits']
        require(row['edit_count'] == len(edits) == expected, 'Proof-correction edit count')
        require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
                == candidate, 'Complete proof-correction forward reconstruction')
        reverse, delta = [], 0
        for edit in edits:
            before, after = edit['original_text'], edit['replacement_text']
            reverse.append({'offset': edit['original_start_byte'] + delta,
                            'before': after, 'after': before})
            delta += len(after.encode()) - len(before.encode())
        require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
                'Complete proof-correction inverse')
        outcomes.append({'original': row['original'], 'candidate': row['candidate'],
                         'edit_count': expected, 'exact_forward_and_inverse': True})
    return {'logical_and_physical_source_overlays': outcomes,
            'historical_source_review_rebased': False,
            'theorem_header_changes': correction['theorem_header_changes']}


def verify_leaf_corrections(stable_correction, helper_correction, h):
    outcomes = []
    for label, correction, author, field, expected in [
            ('stable', stable_correction, 'root', 'edits', 13),
            ('helper', helper_correction, 'reflection_evidence_review', 'exact_source_edits', 2)]:
        require(correction['author'] == author, 'Leaf correction author: ' + label)
        identity(correction['original'], h)
        identity(correction['candidate'], h)
        original = local_path(correction['original']['path']).read_bytes()
        candidate = local_path(correction['candidate']['path']).read_bytes()
        edits = correction[field]
        require(correction['edit_count'] == len(edits) == expected, 'Leaf correction count: ' + label)
        require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
                == candidate, 'Leaf correction forward: ' + label)
        reverse, delta = [], 0
        for edit in edits:
            before, after = edit['original_text'], edit['replacement_text']
            reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
            delta += len(after.encode()) - len(before.encode())
        require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
                'Leaf correction inverse: ' + label)
        outcomes.append({'component': label, 'original': correction['original'],
                         'candidate': correction['candidate'], 'edit_count': expected,
                         'exact_forward_and_inverse': True})
    copies = []
    for row in helper_correction['preserved_unselected_draft']:
        copy = identity(row['preserved_copy'], h)
        require(all(copy[key] == row['original'][key] for key in ('bytes', 'sha256')),
                'Unselected draft copy differs from its historical source identity')
        copies.append(row['preserved_copy'])
    return {'separate_leaf_overlays': outcomes, 'preserved_unselected_helper_draft': copies,
            'historical_reviews_rebased': False}


def verify_diagnosed_helper_repair(repair, h):
    require(repair['author'] == 'reflection_evidence_review'
            and repair['edit_count'] == len(repair['exact_source_edits']) == 16,
            'Diagnosed Helper repair authorship/edit scope')
    identity(repair['original'], h)
    identity(repair['candidate'], h)
    original = local_path(repair['original']['path']).read_bytes()
    candidate = local_path(repair['candidate']['path']).read_bytes()
    edits = repair['exact_source_edits']
    require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
            == candidate, 'Diagnosed Helper forward reconstruction')
    reverse, delta = [], 0
    for edit in edits:
        before, after = edit['original_text'], edit['replacement_text']
        reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
        delta += len(after.encode()) - len(before.encode())
    require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
            'Diagnosed Helper inverse reconstruction')
    headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
    roots = lambda data: re.findall(r'^#print axioms (\S+)$', data.decode(), re.M)
    require(len(headers(original)) == len(headers(candidate)) == 26
            and headers(original) == headers(candidate)
            and roots(original) == roots(candidate) == HELPER_ROOT_NAMES,
            'Diagnosed Helper theorem headers or reports differ')
    require(not re.search(r'\b(?:if_pos|if_neg|dif_pos|dif_neg)\b', candidate.decode()),
            'Diagnosed Helper still uses a deprecated conditional alias')
    return {'original': repair['original'], 'candidate': repair['candidate'],
            'edit_count': 16, 'exact_forward_and_inverse': True,
            'unchanged_public_and_private_theorem_header_count': 26,
            'ordered_report_count': 25,
            'IEnvTags_explicit_types_are_only_definition_text_change': True,
            'equality_to_an_accepted_predecessor_IEnvTags_claimed': False,
            'historical_reviews_rebased': False}



def verify_recorded_overlay(row, expected, h, field='exact_source_edits'):
    identity(row['original'], h)
    identity(row['candidate'], h)
    original = local_path(row['original']['path']).read_bytes()
    candidate = local_path(row['candidate']['path']).read_bytes()
    edits = row[field]
    require(len(edits) == expected, 'Separate overlay edit census')
    require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
            == candidate, 'Separate overlay forward reconstruction')
    reverse, delta = [], 0
    for edit in edits:
        before, after = edit['original_text'], edit['replacement_text']
        reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
        delta += len(after.encode()) - len(before.encode())
    require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
            'Separate overlay inverse reconstruction')
    return {'original': row['original'], 'candidate': row['candidate'],
            'edit_count': expected, 'exact_forward_and_inverse': True}


def verify_observer_syntax_overlay(overlay, h):
    require(overlay['author'] == 'reflection_evidence_review'
            and [r['label'] for r in overlay['source_variants']]
            == ['ordinary_core_observer_laws', 'syntax_metadata_cutoff'],
            'Observer/Syntax overlay identity')
    outcomes = [verify_recorded_overlay(row, count, h)
                for row, count in zip(overlay['source_variants'], [3, 2])]
    originals = [r['original'] for r in overlay['source_variants']]
    candidates = [r['candidate'] for r in overlay['source_variants']]
    require(candidates == [dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_120_SOURCE_PINS[n])) for n in (0, 4)],
            'Observer/Syntax historical owners differ')
    require(len(overlay['restored_exact_upstream_declarations']) == 2,
            'Observer restoration scope')
    for index, law in enumerate(overlay['restored_exact_upstream_declarations']):
        identity(law['source'], h)
        lines = local_path(law['source']['path']).read_text().splitlines(keepends=True)
        text = ''.join(lines[law['start_line'] - 1:law['end_line_inclusive']]).encode()
        require(text == law['text'].encode() and len(text) == law['bytes']
                and hashlib.sha256(text).hexdigest() == law['sha256']
                and text == overlay['source_variants'][0]['exact_source_edits'][index]['replacement_text'].encode(),
                'Restored observer is not the exact upstream law')
    headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
    syntax_old, syntax_new = [local_path(row['path']).read_bytes() for row in (originals[1], candidates[1])]
    require(headers(syntax_old) == headers(syntax_new) and len(headers(syntax_new)) == 31,
            'Syntax theorem interface census')
    require(overlay['new_core_public_axiom_report'] == REQUIRED[MODULES[0]][0]
            and overlay['core_executable_definitions_changed'] is False
            and overlay['external_private_representation_workaround_used'] is False
            and overlay['hasParams_never_restored'] is False, 'Observer scope boundary')
    return {'separate_source_overlays': outcomes, 'restored_exact_upstream_law_count': 2,
            'added_Core_public_simp_registration_count': 1,
            'added_Core_report_count': 1, 'Syntax_unchanged_theorem_header_count': 31,
            'effective_remaining_optional_PropWhen_proof_omissions': 34,
            'effective_remaining_optional_PropWhen_simp_omissions': 14,
            'historical_omission_maps_rebased': False,
            'historical_reviews_rebased': False}


def verify_cached_proof_sharing(overlay, correspondence, mapping, h):
    require(overlay['author'] == 'reflection_evidence_review'
            and [v['label'] for v in overlay['variants']]
            == ['physical_corrected_owner', 'full_logical_ExprOpsC'],
            'Cached proof-sharing variant identities')
    outcomes = [verify_recorded_overlay(row, count, h)
                for row, count in zip(overlay['variants'], [41, 40])]
    physical, logical = overlay['variants']
    require(physical['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[1]))
            and physical['original'] == correspondence['accepted_physical_baseline']
            and logical['original'] == correspondence['original_raw_upstream_source']
            and logical['candidate'] == correspondence['selected_full_logical_source'],
            'Cached proof-sharing source ownership')
    for row in overlay['variants']:
        kinds = Counter(e['kind'] for e in row['exact_source_edits'])
        require(kinds['constructor_subtype_proof_only'] == 36
                and kinds['termination_proof_search_order_only'] == 4
                and kinds['documentation_only'] == (1 if row is physical else 0)
                and sum(kinds.values()) == (41 if row is physical else 40),
                'Cached proof-only edit census')
        original, candidate = [local_path(row[k]['path']).read_text() for k in ('original', 'candidate')]
        headers = lambda text: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', text)
        require(headers(original) == headers(candidate)
                and re.findall(r'^\s*#print axioms \S+$', original, re.M)
                == re.findall(r'^\s*#print axioms \S+$', candidate, re.M),
                'Cached proof-sharing statement/report interfaces')
    inherited = next(s for s in mapping['physical_units'][1]['source_segments']
                     if s['module'] == 'ConLeche.Cached.ExprOpsC')
    edits = correspondence['unchanged_legacy_header_and_explicit_universe_edits']
    require(edits == inherited['edits'] and len(edits) == 5,
            'Cached full-origin header/visibility/universe edits changed')
    body = apply_edits(local_path(logical['candidate']['path']).read_bytes(), edits,
                       'original_offset', 'original_text', 'replacement_text')
    new = local_path(physical['candidate']['path']).read_bytes()
    prior = local_path(physical['original']['path']).read_bytes()
    first, stop = (correspondence['selected_full_origin_body_start_byte'],
                   correspondence['selected_full_origin_body_end_byte_exclusive'])
    prefix, suffix = correspondence['full_origin_prefix'].encode(), correspondence['full_origin_suffix'].encode()
    doc = correspondence['physical_variant_scope_prefix'].encode()
    prior_first = prior.index(prefix) + len(prefix)
    prior_stop = prior.index(suffix, prior_first)
    require(new[first:stop] == body and len(body) == correspondence['selected_full_origin_body_bytes']
            and hashlib.sha256(body).hexdigest() == correspondence['selected_full_origin_body_sha256']
            and new[first - len(prefix):first] == prefix and new[stop:stop + len(suffix)] == suffix
            and new.startswith(doc) and new[len(doc):first] == prior[:prior_first]
            and new[stop:] == prior[prior_stop:], 'Cached full-origin or complement correspondence')
    return {'separate_source_overlays': outcomes, 'complete_full_origin': 'ConLeche.Cached.ExprOpsC',
            'constructor_equality_certificate_edits': 36, 'termination_search_order_edits': 4,
            'new_declarations_or_reports': [], 'new_omissions': [],
            'complete_logical_to_physical_body_byte_exact': True,
            'physical_complement_unchanged_after_documentation_prefix': True,
            'no_compiler_equivalence_or_native_performance_claim': True,
            'historical_reviews_rebased': False}


def verify_bulk_and_literal_maps(bulk_map, boundary, literal_wording, h):
    identity(bulk_map['selected_source'], h)
    identity(boundary['original'], h)
    identity(boundary['candidate'], h)
    require(boundary['candidate'] == bulk_map['selected_source']
            == dict(zip(('path', 'bytes', 'sha256'), SOURCE_PINS[5])),
            'Bulk selected source or comment boundary identity')
    selected = local_path(boundary['candidate']['path']).read_bytes()
    removed = selected
    for line in boundary['added_exact_comment_lines']:
        text = line.encode()
        require(removed.count(text) == 1, 'Bulk boundary line is not unique')
        removed = removed.replace(text, b'', 1)
    require(removed == local_path(boundary['original']['path']).read_bytes()
            and len(boundary['added_exact_comment_lines']) == 2,
            'Bulk comment-only boundary correction differs')
    segments = bulk_map['segments']
    require(len(segments) == 6, 'Bulk supplement slice census')
    for segment in segments:
        identity(segment['origin'], h)
        lines = local_path(segment['origin']['path']).read_text().splitlines(keepends=True)
        original = ''.join(lines[segment['start_line'] - 1:segment['end_line_inclusive']]).encode()
        body = segment['selected_text'].encode()
        require(original == segment['original_text'].encode() and len(original) == segment['original_bytes']
                and hashlib.sha256(original).hexdigest() == segment['original_sha256'],
                'Bulk exact original interval differs')
        first = segment['selected_start_byte']
        require(selected[first:first + len(body)] == body and len(body) == segment['selected_bytes']
                and hashlib.sha256(body).hexdigest() == segment['selected_sha256']
                and segment['byte_identical'] == (original == body),
                'Bulk selected interval/adaptation differs')
    require(bulk_map['required_axiom_reports'] == REQUIRED[MODULES[5]]
            and bulk_map['required_axiom_report_count'] == 30
            and bulk_map['no_existing_actual_definition_replaced'] is True,
            'Bulk roots or actual definition ownership')
    wording = dict(literal_wording)
    require(wording['author'] == 'root' and wording['edit_count'] == 1
            and wording['mathematical_source_tokens_changed'] is False
            and wording['candidate'] == dict(zip(('path', 'bytes', 'sha256'), SOURCE_PINS[6])),
            'Literal comment-only review correction scope')
    wording['exact_source_edits'] = [{k: wording[k] for k in
                                    ('original_start_byte', 'original_text', 'replacement_text')}]
    literal_result = verify_recorded_overlay(wording, 1, h)
    return {'bulk_selected_source': bulk_map['selected_source'],
            'bulk_exact_upstream_intervals_checked': 6,
            'bulk_comment_opening_lines_restored': 2,
            'bulk_owning_Expr_and_ExprOps_supplements_not_duplicate_imports': True,
            'literal_comment_only_overlay': literal_result,
            'historical_reviews_rebased': False}



def verify_cost_overlays(presentation, census, count_overlay, historical, h, guard):
    require(presentation['author'] == count_overlay['author'] == 'reflection_evidence_review',
            'Cost overlay authorship')
    presentation_result = verify_recorded_overlay(presentation, 21, h)
    count_result = verify_recorded_overlay(count_overlay, 2, h)
    for overlay, index in ((presentation, 0), (count_overlay, 4)):
        require(overlay['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_120_SOURCE_PINS[index]))
                and overlay['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[index])),
                'Cost overlay original/current source identity')
        old = local_path(overlay['original']['path']).read_bytes()
        new = local_path(overlay['candidate']['path']).read_bytes()
        delta = 0
        for edit in overlay['exact_source_edits']:
            before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
            require(edit['candidate_start_byte'] == edit['original_start_byte'] + delta
                    and edit['original_text_bytes'] == len(before)
                    and edit['replacement_text_bytes'] == len(after)
                    and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest(),
                    'Cost overlay exact byte-offset/text metadata')
            delta += len(after) - len(before)
        headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
        reports = lambda data: re.findall(r'^\s*#print axioms (\S+)$', data.decode(), re.M)
        require(headers(old) == headers(new) and reports(old) == reports(new) == RAW_REQUIRED[MODULES[index]],
                'Cost overlay theorem header/report preservation')
        if index == 4:
            require(len(headers(new)) == 31, 'Syntax count-sharing theorem-header census')
    kinds = Counter(edit['kind'] for edit in presentation['exact_source_edits'])
    require(kinds == Counter({'documentation_only': 1, 'omit_unused_repr_deriving_request': 19,
                            'omit_unused_display_definition_and_instance': 1})
            and presentation['omitted_repr_deriving_request_count'] == 19
            and presentation['omitted_explicit_display_definitions'] == ["ConLeche.PropWhen.reprPrec'"]
            and presentation['omitted_explicit_display_instances'] == ['Repr ConLeche.PropWhen']
            and presentation['generated_declaration_count_claim'] is None
            and presentation['cached_owner_edits'] == []
            and presentation['selected_cached_owner'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[1])),
            'Presentation-only omission or retained Cached owner census')
    deriving_edits = [edit for edit in presentation['exact_source_edits']
                      if edit['kind'] == 'omit_unused_repr_deriving_request']
    require(len({edit['type'] for edit in deriving_edits}) == 19, 'Repeated Repr deriving type')
    for edit in deriving_edits:
        before, after = edit['original_text'], edit['replacement_text']
        expected = (before.replace('Repr, ', '', 1) if 'Repr, ' in before else
                    '  -- Presentation-only slice: unused Repr deriving request omitted.\n')
        require(re.fullmatch(r'[ \t]*deriving[^\n]*\bRepr\b[^\n]*\n', before)
                and before.count('Repr') == 1 and after == expected
                and ('Repr, ' in before or before == '  deriving Repr\n'),
                'Non-display content removed by deriving edit')
    historical_rows = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                       for row in historical['sources']]
    require(census['scope'] == historical_rows and census['status'] == 'source_text_census_not_elaborated_dependency_export'
            and census['cached_repr_deriving_requests'] == census['cached_repr_instances']
            == census['cached_display_formatter_definitions'] == []
            and census['measured_benefit'] is None,
            'Static presentation census scope')
    old_core_path = local_path(presentation['original']['path'])
    old_core = old_core_path.read_text()
    old_code = guard.lean_code(old_core)
    old_lines = old_core.splitlines(keepends=True)
    actual_sites = []
    for match in re.finditer(r'(?m)^[ \t]*deriving[^\n]*\bRepr\b[^\n]*$', old_code):
        line = old_code.count('\n', 0, match.start()) + 1
        actual_sites.append({'line': line, 'text': old_lines[line - 1]})
    require(actual_sites == [{'line': row['line'], 'text': row['text']}
                             for row in census['core_repr_deriving_sites']]
            and len(actual_sites) == 19
            and [(row['type'], row['line'], row['text']) for row in census['core_repr_deriving_sites']]
                == [(edit['type'], edit['original_line_start'], edit['original_text']) for edit in deriving_edits],
            'Actual source Repr deriving request census')
    for row in (presentation['candidate'], presentation['selected_cached_owner']):
        visible = guard.lean_code(local_path(row['path']).read_text())
        require(not re.search(r'\bRepr\b|\breprPrec\b|\breprArg\b|\breprStr\b', visible),
                'Unexpected retained display dependency in Core/Cached owner')
    require(len(census['primary_intervals']) == 5, 'Presentation primary-interval census')
    for interval in census['primary_intervals']:
        identity(interval['source'], h)
        lines = local_path(interval['source']['path']).read_text().splitlines(keepends=True)
        text = ''.join(lines[interval['start_line'] - 1:interval['end_line_inclusive']]).encode()
        require(text == interval['text'].encode() and len(text) == interval['bytes']
                and hashlib.sha256(text).hexdigest() == interval['sha256'],
                'Presentation primary interval differs')
    require(Counter(edit['kind'] for edit in count_overlay['exact_source_edits']) ==
            Counter({'documentation_only': 1, 'proof_only_common_case_before_structural_induction': 1})
            and count_overlay['exact_source_edits'][1]['declaration'] ==
                'ADWH.Experiments.Chapter15.KernelCachedSyntaxCorrespondence.plain_bulk_eq_pure'
            and count_overlay['changed_existing_theorem_headers'] == []
            and count_overlay['new_or_removed_declarations'] == []
            and count_overlay['new_or_removed_axiom_reports'] == []
            and count_overlay['proof_reorganization']['shared_count_zero_case'] == 1
            and count_overlay['proof_reorganization']['former_per_constructor_zero_count_cases'] == 10
            and count_overlay['proof_reorganization']['remaining_per_constructor_zero_count_cases'] == 0,
            'Syntax common-count proof-only scope')
    require(presentation['claimed_compilation_or_speedup'] is False
            and count_overlay['claimed_compilation_or_speedup'] is False,
            'Source-cost overlays must not claim measured acceptance')
    return {'presentation_overlay': presentation_result, 'syntax_count_overlay': count_result,
            'Core_omitted_Repr_deriving_requests': 19,
            'Core_omitted_display_definitions': ["ConLeche.PropWhen.reprPrec'"],
            'Core_omitted_display_instances': ['Repr ConLeche.PropWhen'],
            'generated_declaration_count_claimed': False, 'static_primary_intervals_checked': 5,
            'Cached_owner_unchanged': True, 'all_existing_theorem_headers_and_reports_preserved': True,
            'Syntax_common_zero_count_case_shared_once': True,
            'new_computational_definition_or_resource_change': False,
            'historical_review_scopes_rebased': False, 'budget_fit_assumed': False}



def explicit_named_declarations(text, guard):
    """Literal named-source census only; generated and implicit declarations are excluded."""
    code_lines, raw_lines = guard.lean_code(text).splitlines(), text.splitlines()
    frames, rows, byte_offset = [], [], 0
    pattern = re.compile(r'^(?:@\[[^\n]*\]\s*)?(?:(?:private|protected|noncomputable|unsafe)\s+)*'
                         r'(def|abbrev|theorem|lemma|inductive|structure|opaque)\s+([^\s:({]+)')
    for line_no, (visible, raw) in enumerate(zip(code_lines, raw_lines), 1):
        namespace = re.match(r'^namespace\s+(\S+)', visible)
        if namespace:
            frames.append(('namespace', namespace.group(1)))
        elif re.match(r'^section(?:\s|$)', visible):
            frames.append(('section', ''))
        elif re.match(r'^mutual(?:\s|$)', visible):
            frames.append(('mutual', ''))
        elif re.match(r'^end(?:\s|$)', visible):
            require(bool(frames), 'Unbalanced source scope in declaration census')
            frames.pop()
        match = pattern.match(visible)
        if match:
            kind, source_name = match.groups()
            prefix = '.'.join(name for tag, name in frames if tag == 'namespace')
            name = (source_name[len('_root_.'):] if source_name.startswith('_root_.')
                    else '.'.join(part for part in (prefix, source_name) if part))
            rows.append({'name': name, 'source_name': source_name, 'kind': kind,
                         'line': line_no, 'start_byte': byte_offset,
                         'declaration_start_line_text': raw})
        byte_offset += len(raw.encode()) + 1
    require(not frames and len(code_lines) == len(raw_lines), 'Incomplete source scope census')
    return rows


def verify_evaluator_omissions(overlay, census, inventory, source_audit, historical, h, guard):
    require(overlay['format'] == 'adwh-cached-evaluator-scope-exact-omission-overlay-v1'
            and overlay['author'] == 'nat_only_gap_review'
            and overlay['exact_source_edit_count'] == 8
            and [row['module'] for row in overlay['variants']] == MODULES[:2]
            and overlay['removed_whole_upstream_origins'] == OMITTED_WHOLE_ORIGINS
            and len(OMITTED_WHOLE_ORIGINS) == 9,
            'Evaluator extraction overlay identity and exact omission census')
    outcomes, removed_names, removed_theorems = [], [], []
    for index, (variant, declared, edit_count, old_count, new_count) in enumerate(zip(
            overlay['variants'], census['source_variants'], [5, 3], [466, 277], [387, 267])):
        require(variant['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[index]))
                and variant['candidate'] == dict(zip(('path', 'bytes', 'sha256'), SOURCE_PINS[index])),
                'Evaluator extraction selected historical/current owner')
        outcomes.append(verify_recorded_overlay(variant, edit_count, h))
        original = local_path(variant['original']['path']).read_text()
        candidate = local_path(variant['candidate']['path']).read_text()
        delta = 0
        cut_intervals = []
        for edit in variant['exact_source_edits']:
            before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
            require(edit['candidate_start_byte'] == edit['original_start_byte'] + delta
                    and edit['original_text_bytes'] == len(before)
                    and edit['replacement_text_bytes'] == len(after)
                    and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest(),
                    'Evaluator omission exact offset, length or text hash')
            delta += len(after) - len(before)
            if before:
                cut_intervals.append((edit['original_start_byte'], edit['original_start_byte'] + len(before)))
        old_rows = explicit_named_declarations(original, guard)
        new_rows = explicit_named_declarations(candidate, guard)
        is_removed = lambda row: any(lo <= row['start_byte'] < hi for lo, hi in cut_intervals)
        removed = [row for row in old_rows if is_removed(row)]
        retained = [row for row in old_rows if not is_removed(row)]
        headers = lambda rows: [(row['name'], row['kind'], row['declaration_start_line_text']) for row in rows]
        reports = lambda raw: re.findall(r'^\s*#print\s+axioms\s+(\S+)', guard.lean_code(raw), re.M)
        require(declared['module'] == MODULES[index]
                and declared['original_explicit_named_declaration_count'] == len(old_rows) == old_count
                and declared['candidate_explicit_named_declaration_count'] == len(new_rows) == new_count
                and declared['omitted_explicit_named_declaration_count'] == len(removed) == old_count - new_count
                and removed == declared['omitted_explicit_named_declarations']
                and headers(retained) == headers(new_rows)
                and declared['retained_explicit_declaration_start_headers_literal'] is True
                and declared['all_retained_declaration_bodies_literal_by_complement_map'] is True
                and reports(original) == reports(candidate) == declared['ordered_axiom_prints'] == RAW_REQUIRED[MODULES[index]]
                and declared['ordered_axiom_prints_unchanged'] is True
                and declared['generated_declaration_count_claimed'] is False,
                'Evaluator explicit source declaration/header/report census')
        removed_names += [row['name'] for row in removed]
        removed_theorems += [row['name'] for row in removed if row['kind'] in ('theorem', 'lemma')]
        require(variant['exact_forward_inverse_and_complement_verified'] is True
                and variant['removed_source_bytes'] == sum(len(edit['original_text'].encode()) for edit in variant['exact_source_edits'])
                and variant['replacement_source_bytes'] == sum(len(edit['replacement_text'].encode()) for edit in variant['exact_source_edits'])
                and variant['net_source_bytes_removed'] == len(original.encode()) - len(candidate.encode()),
                'Evaluator omission byte accounting')
    require(census['status'] == 'literal_source_census_not_elaborated_dependency_export'
            and census['removed_qualified_names'] == removed_names
            and len(set(removed_names)) == 89
            and removed_theorems == ['ConLeche.Expr.allLevelParamsDefinedP_cut']
            and census['only_explicit_theorem_removed'] == removed_theorems[0]
            and census['removed_theorem_was_registered_simp'] is False
            and census['scanned_source_count'] == len(census['scanned_sources']) == 25
            and census['remaining_qualified_removed_name_hits'] == []
            and census['remaining_unambiguous_removed_short_name_hits'] == []
            and census['generated_declaration_count_claimed'] is False
            and census['removed_cached_intrinsic_result_certificate_branch_count'] == 29
            and census['complete_elaborated_dependency_or_implicit_resolution_claimed'] is False,
            'Bounded source dependency census and limitation')
    qualified_pattern = lambda name: r"(?<![A-Za-z0-9_'.])" + re.escape(name) + r"(?![A-Za-z0-9_'])"
    short_pattern = lambda name: r"(?<![A-Za-z0-9_'])" + re.escape(name) + r"(?![A-Za-z0-9_'])"
    short_names = sorted({name.rsplit('.', 1)[-1] for name in removed_names})
    ambiguous = sorted(set(short_names) - set(census['unambiguous_removed_short_names']))
    require(ambiguous == sorted(['bn', 'u', 'v', 'uN', 'vN', 'u1N', 'u1', 'bv', 'srt', 'prop',
            'type1', 'cnst', 'pi', 'piI', 'piA', 'lm', 'lmI', 'ap2', 'ap3', 'ap4', 'rule',
            'canon', 'canonEq', 'slot', 'decls', 'names']), 'Ambiguous source-token census')
    actual_ambiguous = []
    for row in census['scanned_sources']:
        identity(row, h)
        visible = guard.lean_code(local_path(row['path']).read_text())
        require(not any(re.search(qualified_pattern(name), visible) for name in removed_names)
                and not any(re.search(short_pattern(name), visible) for name in census['unambiguous_removed_short_names']),
                'Deleted declaration has a retained explicit source reference: ' + row['path'])
        counts = {name: len(re.findall(short_pattern(name), visible)) for name in ambiguous}
        actual_ambiguous.append({'path': row['path'], 'counts': {name: count for name, count in counts.items() if count}})
    require(actual_ambiguous == census['ambiguous_short_name_census'],
            'Ambiguous source-token counts differ from independently reviewed census')
    current_origins = [name for name in historical['logical_origins'] if name not in OMITTED_WHOLE_ORIGINS]
    require(overlay['historical_logical_origin_order'] == historical['logical_origins']
            and overlay['current_logical_origin_order'] == current_origins
            and inventory['current_logical_origin_order'] == current_origins
            and (overlay['historical_upstream_origin_count'], overlay['current_upstream_origin_count'],
                 overlay['current_project_origin_count'], overlay['current_logical_origin_count'],
                 overlay['historical_source_segment_count'], overlay['current_source_segment_count'])
                == (26, 17, 7, 24, 35, 26)
            and overlay['retained_declaration_bodies_proofs_imports_options_literal'] is True
            and overlay['all_six_pure_and_cached_callback_bodies_and_knots_retained'] is True
            and overlay['actual_CState_layout_flushed_and_helper_operations_retained'] is True
            and overlay['new_computational_definitions_or_proof_bodies'] == []
            and overlay['noncomputable_modifiers_introduced'] is False
            and overlay['resource_or_compiler_option_changes'] is False
            and overlay['native_full_original_driver_API_preserved'] is False
            and overlay['later_driver_restoration_required'] is True
            and overlay['historical_reviews_rebased'] is False
            and overlay['compilation_or_budget_fit_claimed'] is False,
            'Current evaluator ownership, retained algorithms or driver boundary')
    require(source_audit['exact_overlay_forward_inverse_and_complement_verified'] is True
            and source_audit['retained_declaration_bodies_and_proofs_literal_unchanged'] is True
            and source_audit['all_six_actual_pure_and_cached_slots_and_knots_retained'] is True
            and source_audit['full_original_driver_API_preserved'] is False
            and source_audit['later_original_driver_restoration_required'] is True,
            'Independent evaluator omission source-review conclusions')
    return {'variants': outcomes, 'exact_edit_count': 8, 'removed_named_declarations': 89,
            'removed_intrinsic_certificate_branches': 29, 'static_consumer_sources_checked': 25,
            'net_selected_source_bytes_removed': 49282, 'current_logical_origins': current_origins,
            'removed_whole_upstream_origins': OMITTED_WHOLE_ORIGINS,
            'all_retained_source_text_literal': True, 'historical_review_scopes_rebased': False,
            'static_census_is_complete_elaborated_dependency_proof': False,
            'full_original_driver_native_API_preserved': False, 'later_driver_restoration_required': True,
            'budget_fit_assumed': False}


def preflight(args, h, guard):
    manifest = read(MANIFEST)
    mapping = read(BUNDLED / 'SOURCE-CORRESPONDENCE.json')
    inventory = read(BUNDLED / 'SOURCE-INVENTORY.json')
    audit = read(BUNDLED / 'SOURCE-AUDIT.json')
    correction = read(CORRECTION / 'PROOF-CORRECTION.json')
    correction_audit = read(CORRECTION / 'SOURCE-AUDIT.json')
    stable_inventory = read(STABLE / 'SOURCE-INVENTORY.json')
    stable_audit = read(STABLE / 'SOURCE-AUDIT.json')
    stable_correction = read(STABLE_CORRECTION / 'PROOF-CORRECTION.json')
    stable_correction_audit = read(STABLE_CORRECTION / 'SOURCE-AUDIT.json')
    helper_correction = read(DIRECT / 'PROOF-CORRECTION.json')
    helper_inventory = read(DIRECT / 'SOURCE-INVENTORY.json')
    helper_audit = read(DIRECT / 'SOURCE-AUDIT.json')
    diagnosed_repair = read(DIAGNOSED / 'PROOF-CORRECTION.json')
    diagnosed_inventory = read(DIAGNOSED / 'SOURCE-INVENTORY.json')
    diagnosed_audit = read(DIAGNOSED / 'SOURCE-AUDIT.json')
    syntax_overlay = read(SYNTAX / 'PROOF-CORRECTION.json')
    syntax_inventory = read(SYNTAX / 'SOURCE-INVENTORY.json')
    syntax_audit = read(SYNTAX / 'SOURCE-AUDIT.json')
    sharing_overlay = read(SHARING / 'PROOF-OVERLAY.json')
    sharing_correspondence = read(SHARING / 'SOURCE-CORRESPONDENCE.json')
    sharing_inventory = read(SHARING / 'SOURCE-INVENTORY.json')
    sharing_audit = read(SHARING / 'SOURCE-AUDIT.json')
    bulk_map = read(BULK / 'SOURCE-CORRESPONDENCE.json')
    bulk_boundary = read(BULK / 'SLICE-BOUNDARY-CORRECTION.json')
    bulk_inventory = read(BULK / 'SOURCE-INVENTORY.json')
    bulk_audit = read(BULK / 'SOURCE-AUDIT.json')
    literal_wording = read(LITERAL / 'REVIEW-WORDING-CORRECTION.json')
    literal_inventory = read(LITERAL / 'SOURCE-INVENTORY.json')
    literal_audit = read(LITERAL / 'SOURCE-AUDIT.json')
    historical_120 = read(COST_PREDECESSOR / 'source-manifest.json')
    presentation_overlay = read(PRESENTATION / 'PRESENTATION-OMISSIONS.json')
    presentation_census = read(PRESENTATION / 'STATIC-CENSUS.json')
    presentation_inventory = read(PRESENTATION / 'SOURCE-INVENTORY.json')
    presentation_audit = read(PRESENTATION / 'SOURCE-AUDIT.json')
    count_overlay = read(COUNT_SHARING / 'PROOF-OVERLAY.json')
    count_inventory = read(COUNT_SHARING / 'SOURCE-INVENTORY.json')
    count_audit = read(COUNT_SHARING / 'SOURCE-AUDIT.json')
    historical_cost = read(OMISSION_PREDECESSOR / 'source-manifest.json')
    omission_overlay = read(OMISSION / 'SOURCE-OMISSIONS.json')
    omission_census = read(OMISSION / 'SOURCE-CENSUS.json')
    omission_inventory = read(OMISSION / 'SOURCE-INVENTORY.json')
    omission_audit = read(OMISSION / 'SOURCE-AUDIT.json')
    require(manifest['format'] == MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY and manifest['module_order'] == MODULES
            and manifest['prepared_objects'] == [] and manifest['export_targets'] == []
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 120
            and manifest['expected_artifact_count'] == 14, 'Manifest selection or policy differs')
    require(audit['status'] == 'passed_source_only_review_not_compiled'
            and audit['reviewer'] == 'reflection_evidence_review'
            and audit['source_author'] == 'book_scope_review'
            and audit['independent_of_source_author'] is True
            and audit['audited_input_count'] == len(audit['audited_inputs']) == 27
            and manifest['reviewed_direct_inputs'] == audit['audited_inputs'], 'Independent review scope')
    require(correction_audit['status'] == 'passed_source_only_review_not_compiled'
            and correction_audit['reviewer'] == 'book_scope_review'
            and correction_audit['correction_author'] == 'root'
            and correction_audit['independent_of_correction_author'] is True
            and correction_audit['direct_input_count'] == len(correction_audit['inputs']) == 18
            and manifest['reviewed_correction_inputs'] == correction_audit['inputs']
            and correction_audit['fully_qualified_roots'] == REQUIRED[MODULES[1]],
            'Independent correction review scope')
    require(audit['physical_module_order'] == MODULES[:2]
            and audit['required_axiom_report_roots'] == REQUIRED[MODULES[1]]
            and audit['required_axiom_report_count'] == 25, 'Reviewed source/root selection')
    require(mapping['physical_module_order'] == MODULES[:2]
            and mapping['distinct_upstream_origin_count'] == 26
            and mapping['distinct_project_origin_count'] == 2
            and mapping['distinct_mathematical_origin_count'] == 28
            and mapping['selected_source_segment_count'] == 30,
            'Origin and supplemental ownership census')
    require(stable_audit['status'] == 'passed_source_only_review_not_compiled'
            and stable_audit['reviewer'] == 'book_scope_review'
            and stable_audit['source_author'] == 'nat_only_gap_review'
            and stable_audit['independent_of_source_author'] is True
            and stable_audit['direct_input_count'] == len(stable_audit['inputs']) == 17
            and manifest['reviewed_stable_inputs'] == stable_audit['inputs']
            and stable_audit['fully_qualified_roots'] == REQUIRED[MODULES[2]]
            and stable_inventory['physical_module_order'] == MODULES[:3]
            and stable_inventory['new_required_axiom_reports'] == REQUIRED[MODULES[2]]
            and stable_inventory['required_total_axiom_reports'] == 45
            and stable_inventory['expected_default_artifact_count'] == 6
            and stable_inventory['input_count'] == len(stable_inventory['inputs']) == 44
            and helper_inventory['logical_origins'][:29] == stable_inventory['logical_origins'],
            'Original stable source/review scope must remain unchanged')
    require(stable_correction_audit['status'] == 'passed_source_only_review_not_compiled'
            and stable_correction_audit['reviewer'] == 'book_scope_review'
            and stable_correction_audit['correction_author'] == 'root'
            and stable_correction_audit['independent_of_correction_author'] is True
            and stable_correction_audit['direct_input_count'] == len(stable_correction_audit['inputs']) == 12
            and manifest['reviewed_stable_correction_inputs'] == stable_correction_audit['inputs']
            and stable_correction_audit['fully_qualified_roots'] == REQUIRED[MODULES[2]]
            and stable_correction_audit['original'] == stable_correction['original'] == stable_audit['source']
            and stable_correction_audit['candidate'] == stable_correction['candidate'],
            'Independent stable correction scope')
    require(helper_audit['status'] == 'passed_source_only_review_not_compiled'
            and helper_audit['reviewer'] == 'book_scope_review'
            and helper_audit['source_author'] == 'reflection_evidence_review'
            and helper_audit['independent_of_source_author'] is True
            and helper_audit['direct_input_count'] == len(helper_audit['inputs']) == 25
            and manifest['reviewed_helper_inputs'] == helper_audit['inputs']
            and helper_audit['fully_qualified_roots'] == REQUIRED[MODULES[3]]
            and helper_audit['source'] == helper_correction['candidate'] == helper_inventory['new_source']
            and helper_audit['original_source'] == helper_correction['original']
            and helper_inventory['input_count'] == len(helper_inventory['inputs']) == 75
            and helper_inventory['physical_module_order'] == MODULES[:4]
            and helper_inventory['new_required_axiom_reports'] == REQUIRED[MODULES[3]]
            and helper_inventory['required_total_axiom_reports'] == 70
            and helper_inventory['expected_default_artifact_count'] == 8
            and historical_cost['logical_origins'][:30] == helper_inventory['logical_origins']
            and len(set(historical_cost['logical_origins'])) == 33
            and historical_cost['source_segment_count'] == 35,
            'Independent helper source and complete closure scope')
    require(diagnosed_audit['status'] == 'passed_source_only_review_not_compiled'
            and diagnosed_audit['reviewer'] == 'book_scope_review'
            and diagnosed_audit['correction_author'] == 'reflection_evidence_review'
            and diagnosed_audit['independent_of_correction_author'] is True
            and diagnosed_audit['direct_input_count'] == len(diagnosed_audit['inputs']) == 18
            and manifest['reviewed_diagnosed_helper_inputs'] == diagnosed_audit['inputs']
            and diagnosed_audit['new_source_roots'] == REQUIRED[MODULES[3]]
            and diagnosed_audit['original'] == diagnosed_repair['original'] == helper_audit['source']
            and diagnosed_audit['candidate'] == diagnosed_repair['candidate'] == diagnosed_inventory['new_source']
            and diagnosed_inventory['input_count'] == len(diagnosed_inventory['inputs']) == 84
            and diagnosed_inventory['new_required_axiom_reports'] == REQUIRED[MODULES[3]]
            and diagnosed_inventory['physical_module_order'] == MODULES[:4]
            and diagnosed_inventory['logical_origins'] == historical_cost['logical_origins'][:30]
            and diagnosed_inventory['required_total_axiom_reports'] == 70
            and diagnosed_inventory['expected_default_artifact_count'] == 8
            and diagnosed_inventory['selected_physical_source_bytes'] == 592064
            and diagnosed_inventory['syntax_candidate_selected'] is False,
            'Independent diagnosed Helper repair/current complete closure scope')
    failed = read(PREDECESSOR / 'attempts/complete-01/report.json')
    require(failed['status'] == 'failed' and failed['source_fingerprint'] ==
            'c7be13545fb772ae734d0aa6c3568a22709662870f3b7058ab0f66a8561ab321'
            and failed['module_order'] == MODULES[:4]
            and [m['status'] for m in failed['modules']] == ['passed', 'passed', 'passed', 'failed']
            and failed['accepted_axiom_report_count'] == 45
            and failed['observed_axiom_report_count'] == 70
            and failed['all_selected_mathematical_sources_freshly_checked'] is False
            and failed['direct_helper_25_roots_checked'] is False,
            'Consumed Helper attempt or accepted-prefix boundary differs')
    failed_marker = local_path(manifest['preserved_failed_predecessors'][-1]['consumed_marker']['path'])
    verify([h.binding(failed_marker)], True)
    require(read(failed_marker)['source_fingerprint'] == failed['source_fingerprint'],
            'Consumed Helper marker differs')
    require(historical_cost['origin_ownership'] == mapping['distinct_upstream_origin_order']
            and len(set(historical_cost['origin_ownership'])) == 26
            and manifest['source_segment_ownership'] == [x['module'] for x in mapping['physical_units'][1]['source_segments']] + MODULES[2:]
            and manifest['inherited_omissions'] == mapping['inherited_omissions'] == audit['inherited_omissions']
            and manifest['core_correspondence_layers'] == mapping['core_layers_unchanged'],
            'Origin ownership, omission or historical-layer disclosure changed')
    sources, done = [], set()
    require(len(manifest['sources']) == len(SOURCE_PINS), 'Source count')
    for row, module, pin in zip(manifest['sources'], MODULES, SOURCE_PINS):
        require(row['module'] == module and (row['path'], row['bytes'], row['sha256']) == pin,
                'Frozen physical source pin: ' + module)
        require(row['module_format'] is False and row['expected_default_output_suffixes'] == ['.olean', '.ilean']
                and row['fully_qualified_roots'] == REQUIRED[module]
                and row['raw_source_print_identifiers'] == RAW_REQUIRED[module],
                'Physical output/report contract: ' + module)
        require(all(n in done or n == 'Init' or n.startswith(('Init.', 'Std.')) for n in row['imports']),
                'External experimental or forward physical import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']})
        done.add(module)
    require(audit['selected_physical_sources'] == [u['selected_source'] for u in mapping['physical_units']],
            'Original review scope must remain at original physical source identities')
    original_stable_selection = [mapping['physical_units'][0]['selected_source'],
                                 correction['corrections'][2]['candidate'], stable_audit['source']]
    require(original_stable_selection == [u['selected_source'] for u in stable_inventory['physical_units']],
            'Original stable inventory keeps its exact historical three owners')
    corrected_selection = original_stable_selection[:2] + [stable_correction['candidate'], helper_audit['source']]
    require(corrected_selection == [u['selected_source'] for u in helper_inventory['physical_units']],
            'Helper inventory must select the exact four corrected source owners')
    diagnosed_selection = corrected_selection[:3] + [diagnosed_repair['candidate']]
    require(diagnosed_selection == [u['selected_source'] for u in diagnosed_inventory['physical_units']]
            == diagnosed_audit['physical_sources'], 'Diagnosed Helper complete selection')
    require(manifest['accepted_70_historical_physical_selection'] == diagnosed_selection,
            'Accepted 70 closure must retain its historical physical source identities')
    require(correction['corrections'][2]['original'] == mapping['physical_units'][1]['selected_source']
            and manifest['corrected_project_origins'] == [x['candidate'] for x in correction['corrections'][:2]]
            and manifest['historical_corrected_leaf_origins'] == [stable_correction['candidate'], helper_correction['candidate']]
            and manifest['corrected_leaf_origins'] == [stable_correction['candidate'], diagnosed_repair['candidate']]
            and manifest['source_origin_rows_precede_separate_proof_overlay'] is True,
            'Physical correction must start from the exact original assembly')

    for label, source_audit, expected_count, count_key, reviewer, author, author_key, status in [
            ('observer_syntax', syntax_audit, 33, 'direct_input_count', 'book_scope_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled'),
            ('cached_proof_sharing', sharing_audit, 26, 'direct_input_count', 'book_scope_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled_or_measured'),
            ('bulk_bound', bulk_audit, 119, 'direct_input_count', 'nat_only_gap_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled'),
            ('literal_forward', literal_audit, 16, 'input_count', 'nat_only_gap_review',
             'root', 'source_author', 'passed_source_only_review_not_compiled')]:
        require(source_audit['status'] == status and source_audit['reviewer'] == reviewer
                and source_audit[author_key] == author and source_audit['independent_of_source_author'] is True
                and source_audit[count_key] == len(source_audit['inputs']) == expected_count
                and manifest['new_separate_review_scopes'][label]['inputs'] == source_audit['inputs']
                and manifest['new_separate_review_scopes'][label]['input_count'] == expected_count,
                'Independent new review scope: ' + label)
    for label, inv, count in [('observer_syntax', syntax_inventory, 104),
                              ('cached_proof_sharing', sharing_inventory, 129),
                              ('bulk_bound', bulk_inventory, 116),
                              ('literal_forward', literal_inventory, 15)]:
        require(inv['input_count'] == len(inv['inputs']) == count
                and manifest['new_separate_author_inventory_scopes'][label]['inputs'] == inv['inputs']
                and manifest['new_separate_author_inventory_scopes'][label]['input_count'] == count,
                'Frozen new author inventory scope: ' + label)
    require(syntax_audit['fully_qualified_roots'] == REQUIRED[MODULES[4]]
            and syntax_audit['Core_candidate'] == syntax_overlay['source_variants'][0]['candidate']
            and syntax_audit['source'] == syntax_overlay['source_variants'][1]['candidate']
            and syntax_inventory['physical_module_order'] == MODULES[:5]
            and syntax_inventory['required_total_axiom_reports'] == 82
            and syntax_inventory['expected_default_artifact_count'] == 10,
            'Observer/Syntax original reviewed selection')
    require(sharing_audit['fully_qualified_owner_report_roots'] == REQUIRED[MODULES[1]]
            and sharing_audit['selected_physical_source'] == sharing_overlay['variants'][0]['candidate']
            and sharing_inventory['physical_module_order'] == MODULES[:6]
            and sharing_inventory['required_total_axiom_reports'] == 112
            and sharing_inventory['expected_default_artifact_count'] == 12
            and sharing_inventory['logical_origin_order'] == historical_cost['logical_origins'][:32],
            'Proof-sharing reviewed and author selection')
    require(bulk_audit['new_report_roots'] == bulk_inventory['new_required_axiom_reports']
            == REQUIRED[MODULES[5]] and bulk_audit['new_source'] == bulk_map['selected_source']
            and bulk_inventory['physical_module_order'] == MODULES[:6]
            and bulk_inventory['required_total_axiom_reports'] == 112
            and bulk_inventory['expected_default_artifact_count'] == 12
            and bulk_inventory['logical_origin_order'] == historical_cost['logical_origins'][:32]
            and bulk_audit['new_proof_sharing_owner_automatically_covered'] is False,
            'Bulk independent scope or unchanged owner-context boundary')
    require(literal_audit['ordered_axiom_reports'] == literal_inventory['new_required_axiom_reports']
            == REQUIRED[MODULES[6]] and literal_audit['selected_new_source'] == literal_wording['candidate']
            and literal_inventory['physical_module_order'] == MODULES[:3] + [MODULES[6]]
            and literal_inventory['required_total_axiom_reports'] == 53
            and literal_inventory['expected_default_artifact_count'] == 8
            and literal_inventory['logical_origins'][:29] == historical_cost['logical_origins'][:29]
            and literal_inventory['logical_origins'][-1] == historical_cost['logical_origins'][-1],
            'Literal independent scope or historical four-owner selection')
    actual_selection = [{k: row[k] for k in ('path', 'bytes', 'sha256')} for row in manifest['sources']]
    require(actual_selection == [omission_overlay['variants'][0]['candidate'],
            omission_overlay['variants'][1]['candidate'], stable_correction['candidate'],
            diagnosed_repair['candidate'], count_overlay['candidate'],
            bulk_map['selected_source'], literal_wording['candidate']]
            and sum(len(roots) for roots in REQUIRED.values()) == 120
            and len({root for roots in REQUIRED.values() for root in roots}) == 120,
            'Complete current owner/report selection')
    accepted = read(ACCEPTED_PREDECESSOR / 'attempts/complete-01/report.json')
    require(accepted['status'] == 'passed' and accepted['module_order'] == MODULES[:4]
            and accepted['source_fingerprint'] == 'efb1eed69cd6102398244e005a8cba75455a39e4c687b2fad539ba5aa1f8c444'
            and accepted['accepted_axiom_report_count'] == accepted['observed_axiom_report_count'] == 70
            and accepted['all_selected_mathematical_sources_freshly_checked'] is True,
            'Accepted 70 predecessor identity or acceptance boundary')
    accepted_marker = local_path(manifest['preserved_accepted_predecessor']['consumed_marker']['path'])
    verify([h.binding(accepted_marker)], True)
    require(read(accepted_marker)['source_fingerprint'] == accepted['source_fingerprint']
            and manifest['preserved_accepted_predecessor']['source_fingerprint'] == accepted['source_fingerprint'],
            'Accepted predecessor marker identity')
    require(manifest['new_independent_review_scopes_rebased'] is False
            and manifest['effective_Core_optional_PropWhen_omissions'] == {'proofs': 34, 'simp_registrations': 14}
            and manifest['new_existing_origin_supplements']['bulk_slices'] == 6
            and manifest['new_existing_origin_supplements']['PropWhen_exact_observer_laws'] == 2,
            'Current supplement and inherited-omission disclosure')


    historical_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                            for row in historical_120['sources']]
    require(historical_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                     for pin in HISTORICAL_120_SOURCE_PINS]
            == manifest['consumed_120_historical_physical_selection']
            and historical_120['policy'] == POLICY and historical_120['module_order'] == MODULES
            and historical_120['source_fingerprint'] ==
                '785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e',
            'Consumed 120 selection/source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor'):
        require(manifest[key] == historical_120[key], 'Historical 120 scope rebased: ' + key)
    historical_cost_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                                 for row in historical_cost['sources']]
    require([index for index, (old, new) in enumerate(zip(historical_selection, historical_cost_selection))
             if old != new] == [0, 4]
            and presentation_overlay['original'] == historical_selection[0]
            and count_overlay['original'] == historical_selection[4]
            and sum(row['bytes'] for row in historical_cost['sources']) ==
                historical_cost['selected_physical_source_bytes'] == 637855,
            'Historical cost selection changes only Core and Syntax')
    for label, source_audit, inv, overlay, index, review_count, inventory_count in (
            ('presentation', presentation_audit, presentation_inventory, presentation_overlay, 0, 210, 209),
            ('syntax_count_sharing', count_audit, count_inventory, count_overlay, 4, 214, 213)):
        require(source_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
                and source_audit['reviewer'] == 'root'
                and source_audit['source_author'] == 'reflection_evidence_review'
                and source_audit['independent_of_source_author'] is True
                and source_audit['direct_input_count'] == len(source_audit['inputs']) == review_count
                and manifest['cost_separate_review_scopes'][label]['input_count'] == review_count
                and manifest['cost_separate_review_scopes'][label]['inputs'] == source_audit['inputs']
                and source_audit['original'] == overlay['original']
                and source_audit['candidate'] == overlay['candidate']
                and source_audit['required_axiom_reports'] == REQUIRED[MODULES[index]]
                and source_audit['public_and_private_theorem_headers_literal_unchanged'] is True
                and source_audit['algorithmic_computational_definitions_changed'] is False
                and source_audit['historical_reviews_rebased'] is False
                and inv['review_input_count'] == len(inv['review_inputs']) == inventory_count
                and manifest['cost_separate_author_inventory_scopes'][label]['input_count'] == inventory_count
                and manifest['cost_separate_author_inventory_scopes'][label]['inputs'] == inv['review_inputs']
                and inv['selected_physical_variant'] == overlay['candidate']
                and inv['predecessor_source'] == overlay['original'],
                'Independent cost source review/inventory scope: ' + label)
    consumed_120 = read(COST_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_120['status'] == 'failed'
            and consumed_120['source_fingerprint'] == historical_120['source_fingerprint']
            and consumed_120['module_order'] == MODULES
            and [row['module'] for row in consumed_120['modules']] == MODULES[:5]
            and [row['status'] for row in consumed_120['modules']] == ['passed'] * 4 + ['failed']
            and consumed_120['accepted_axiom_report_count'] == consumed_120['observed_axiom_report_count'] == 71
            and consumed_120['modules'][-1]['limit_exceeded'] == 'wall_time'
            and consumed_120['modules'][-1]['exit_code'] == -9
            and consumed_120['modules'][-1]['axiom_audit']['observed_count'] == 0
            and consumed_120['all_selected_mathematical_sources_freshly_checked'] is False,
            'Consumed 120 timeout or accepted-prefix boundary differs')
    consumed_marker = local_path(manifest['preserved_consumed_120_predecessor']['consumed_marker']['path'])
    verify([h.binding(consumed_marker)], True)
    require(read(consumed_marker)['source_fingerprint'] == consumed_120['source_fingerprint']
            and manifest['preserved_consumed_120_predecessor']['source_fingerprint'] ==
                consumed_120['source_fingerprint'], 'Consumed 120 permanent marker differs')
    require(manifest['cost_historical_review_scopes_rebased'] is False
            and manifest['cost_new_leaves_selected'] == []
            and manifest['cost_presentation_omissions'] == {
                'Repr_deriving_requests': 19, 'display_definitions': ["ConLeche.PropWhen.reprPrec'"],
                'display_instances': ['Repr ConLeche.PropWhen'], 'generated_declaration_count_claimed': False},
            'Cost selection disclosures differ')

    require(historical_cost_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                          for pin in HISTORICAL_COST_SOURCE_PINS]
            == manifest['consumed_cost120_historical_physical_selection']
            and historical_cost['policy'] == POLICY and historical_cost['module_order'] == MODULES
            and historical_cost['source_fingerprint'] ==
                '3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5',
            'Consumed cost120 complete historical source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'cost_separate_review_scopes',
                'cost_separate_author_inventory_scopes', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor', 'preserved_consumed_120_predecessor',
                'consumed_120_historical_physical_selection', 'accepted_70_historical_physical_selection'):
        require(manifest[key] == historical_cost[key], 'Historical cost120 scope rebased: ' + key)
    require([index for index, (old, new) in enumerate(zip(historical_cost_selection, actual_selection))
             if old != new] == [0, 1]
            and sum(row['bytes'] for row in manifest['sources']) ==
                manifest['selected_physical_source_bytes'] == 588573
            and manifest['ordered_report_counts'] == [1, 25, 20, 25, 11, 30, 8]
            and manifest['omission_historical_review_scopes_rebased'] is False
            and manifest['omission_new_leaves_selected'] == []
            and manifest['full_original_driver_native_API_preserved'] is False
            and manifest['later_original_driver_restoration_required'] is True,
            'Only evaluator Core/Cached extraction may change the consumed cost selection')
    require(omission_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
            and omission_audit['reviewer'] == 'root'
            and omission_audit['source_author'] == 'nat_only_gap_review'
            and omission_audit['independent_of_source_author'] is True
            and omission_audit['direct_input_count'] == len(omission_audit['inputs']) == 61
            and manifest['omission_separate_review_scope']['input_count'] == 61
            and manifest['omission_separate_review_scope']['inputs'] == omission_audit['inputs']
            and omission_inventory['input_count'] == len(omission_inventory['inputs']) == 60
            and manifest['omission_separate_author_inventory_scope']['input_count'] == 60
            and manifest['omission_separate_author_inventory_scope']['inputs'] == omission_inventory['inputs']
            and omission_inventory['prospective_physical_sources'] == manifest['sources']
            and omission_audit['source_variants'] == omission_inventory['source_variants']
            == [{key: row[key] for key in ('module', 'original', 'candidate')} for row in omission_overlay['variants']]
            and omission_audit['required_axiom_report_count'] == 120
            and omission_audit['static_consumer_sources_checked'] == 25
            and omission_audit['predecessor_key'] == historical_cost['source_fingerprint'],
            'Separate evaluator extraction independent review and author inventory')
    require(manifest['logical_origins'] == omission_inventory['current_logical_origin_order']
            == [name for name in historical_cost['logical_origins'] if name not in OMITTED_WHOLE_ORIGINS]
            and manifest['origin_ownership'] == [name for name in historical_cost['origin_ownership']
                                                if name not in OMITTED_WHOLE_ORIGINS]
            and (manifest['distinct_upstream_origin_count'], manifest['distinct_project_origin_count'],
                 manifest['distinct_logical_origin_count'], manifest['source_segment_count']) == (17, 7, 24, 26)
            and len(set(manifest['logical_origins'])) == 24
            and manifest['removed_whole_upstream_origins'] == OMITTED_WHOLE_ORIGINS
            and manifest['partially_omitted_current_origins'] == omission_overlay['partially_omitted_retained_origins']
            and manifest['historical_cost_origin_context'] == {
                key: historical_cost[key] for key in ('origin_ownership', 'logical_origins',
                'complete_origin_source_rows', 'distinct_upstream_origin_count', 'distinct_project_origin_count',
                'distinct_logical_origin_count', 'source_segment_count')},
            'Current evaluator ownership must remain distinct from historical full-origin scope')
    consumed_cost = read(OMISSION_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_cost['status'] == 'failed'
            and consumed_cost['source_fingerprint'] == historical_cost['source_fingerprint']
            and consumed_cost['module_order'] == MODULES
            and [row['module'] for row in consumed_cost['modules']] == MODULES[:5]
            and [row['status'] for row in consumed_cost['modules']] == ['passed'] * 4 + ['failed']
            and consumed_cost['accepted_axiom_report_count'] == consumed_cost['observed_axiom_report_count'] == 71
            and consumed_cost['modules'][-1]['limit_exceeded'] == 'wall_time'
            and consumed_cost['modules'][-1]['exit_code'] == -9
            and consumed_cost['modules'][-1]['axiom_audit']['observed_count'] == 0
            and consumed_cost['all_selected_mathematical_sources_freshly_checked'] is False,
            'Consumed cost120 timeout and exact accepted-prefix boundary')
    cost_marker = local_path(manifest['preserved_consumed_cost120_predecessor']['consumed_marker']['path'])
    verify([h.binding(cost_marker)], True)
    require(read(cost_marker)['source_fingerprint'] == consumed_cost['source_fingerprint']
            and manifest['preserved_consumed_cost120_predecessor']['source_fingerprint'] == consumed_cost['source_fingerprint'],
            'Consumed cost120 permanent marker differs')

    require(manifest['source_fingerprint_scope'] == {
                'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]},
            'Current source-fingerprint scope differs')

    require(manifest['source_fingerprint'] == fingerprint(sources), 'Source/policy fingerprint')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({r['path'] for r in controls}) == len(controls)
            and len({r['role'] for r in controls}) == len(controls), 'Repeated control identity/role')
    controls.append({**h.binding(MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'Source/control overlap')
    historical = read(ROOT / 'next-iteration/kernel-sliced-selector/SOURCE-BUNDLE.json')['physical_units'][0]
    origin_rows = [o['original'] for o in historical['origin_units']]
    origin_rows += [o['original'] for o in mapping['physical_units'][1]['source_segments'] if 'original' in o]
    origin_rows += [stable_audit['source'], helper_correction['original']]
    origin_rows += [syntax_overlay['source_variants'][1]['original'],
                    bulk_boundary['original'], literal_wording['original']]
    require(historical_cost['complete_origin_source_rows'] == origin_rows and len(origin_rows) == 33,
            'Historical full-origin source rows before evaluator extraction')
    current_origin_rows = [row for name, row in zip(historical_cost['logical_origins'], origin_rows)
                           if name not in OMITTED_WHOLE_ORIGINS]
    require(manifest['complete_origin_source_rows'] == current_origin_rows
            == omission_inventory['current_origin_source_rows'] and len(current_origin_rows) == 24,
            'Current evaluator projected origin source rows')
    required_inputs = (audit['audited_inputs'] + correction_audit['inputs'] + stable_audit['inputs']
                       + stable_correction_audit['inputs'] + helper_audit['inputs'] + diagnosed_audit['inputs']
                       + inventory['inputs'] + stable_inventory['inputs'] + helper_inventory['inputs']
                       + diagnosed_inventory['inputs']
                       + syntax_audit['inputs'] + sharing_audit['inputs'] + bulk_audit['inputs'] + literal_audit['inputs']
                       + syntax_inventory['inputs'] + sharing_inventory['inputs'] + bulk_inventory['inputs']
                       + literal_inventory['inputs']
                       + presentation_audit['inputs'] + count_audit['inputs']
                       + presentation_inventory['review_inputs'] + count_inventory['review_inputs']
                       + historical_selection + historical_cost_selection
                       + omission_audit['inputs'] + omission_inventory['inputs']
                       + origin_rows + mapping['core_layers_unchanged'])
    for component in ('kernel-legacy-core-selector', 'kernel-ordinary-fields-core'):
        overlay = read(ROOT / f'next-iteration/{component}/SOURCE-CORRESPONDENCE.json')
        required_inputs += [overlay['original_source'], overlay['candidate_source']]
    for row in required_inputs:
        actual = identity(row, h)
        require(actual['path'] in bound and all(bound[actual['path']][key] == actual[key]
                for key in ('bytes', 'sha256')), 'Reviewed input, origin or overlay not bound')
    for path in list(FIXED) + [Path(__file__).resolve(), HERE / 'PROTOCOL.md',
                              HERE / 'AUTHORING.md', HERE / 'CONTROL-CORRESPONDENCE.json']:
        require(str(path) in bound, 'Execution/selection control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls), 'Snapshot census')
    correspondence = verify_correspondence(mapping, h)
    proof_overlay = verify_proof_correction(correction, h)
    leaf_overlays = verify_leaf_corrections(stable_correction, helper_correction, h)
    diagnosed_overlay = verify_diagnosed_helper_repair(diagnosed_repair, h)
    observer_syntax_result = verify_observer_syntax_overlay(syntax_overlay, h)
    proof_sharing_result = verify_cached_proof_sharing(sharing_overlay, sharing_correspondence, mapping, h)
    bulk_literal_result = verify_bulk_and_literal_maps(bulk_map, bulk_boundary, literal_wording, h)
    cost_result = verify_cost_overlays(presentation_overlay, presentation_census, count_overlay,
                                       historical_120, h, guard)
    omission_result = verify_evaluator_omissions(omission_overlay, omission_census, omission_inventory,
                                                  omission_audit, historical_cost, h, guard)
    compiler_path = args.lean.resolve()
    h.TOOLCHAIN = compiler_path.parent.parent
    pin, compiler = read(PIN), h.binding(compiler_path)
    require(compiler_path.name == 'lean' and pin['version'] == '4.35.0'
            and pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and all(compiler[key] == pin['binaries']['lean'][key] for key in ('bytes', 'sha256')),
            'Pinned Lean compiler differs')
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in read(RUNTIME_REFERENCE)['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((h.TOOLCHAIN / 'lib/lean').glob('*.so'))]
    require(len(runtime) == 5 and {Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime}
            == expected_runtime, 'Pinned runtime differs')
    verify(sources + controls + [compiler] + runtime)
    return {'sources': sources, 'controls': controls, 'roots': REQUIRED,
            'source_fingerprint': fingerprint(sources), 'compiler': compiler, 'runtime': runtime,
            'correspondence': correspondence, 'proof_overlay': proof_overlay, 'leaf_overlays': leaf_overlays,
            'review': h.binding(BUNDLED / 'SOURCE-AUDIT.json'),
            'correction_review': h.binding(CORRECTION / 'SOURCE-AUDIT.json'),
            'stable_review': h.binding(STABLE / 'SOURCE-AUDIT.json'),
            'stable_correction_review': h.binding(STABLE_CORRECTION / 'SOURCE-AUDIT.json'),
            'helper_review': h.binding(DIRECT / 'SOURCE-AUDIT.json'),
            'diagnosed_helper_review': h.binding(DIAGNOSED / 'SOURCE-AUDIT.json'),
            'diagnosed_helper_overlay': diagnosed_overlay,
            'failed_helper_predecessor': manifest['preserved_failed_predecessors'][-1],
            'accepted_70_predecessor': manifest['preserved_accepted_predecessor'],
            'observer_syntax_overlay': observer_syntax_result,
            'cached_proof_sharing_overlay': proof_sharing_result,
            'bulk_literal_correspondence': bulk_literal_result,
            'cost_overlays': cost_result,
            'consumed_120_predecessor': manifest['preserved_consumed_120_predecessor'],
            'cost_separate_reviews': {name: {'audit': h.binding(path / 'SOURCE-AUDIT.json'), 'input_count': count}
                                      for name, path, count in [('presentation', PRESENTATION, 210),
                                        ('syntax_count_sharing', COUNT_SHARING, 214)]},
            'new_separate_reviews': {name: {'audit': h.binding(path / 'SOURCE-AUDIT.json'), 'input_count': count}
                                     for name, path, count in [('observer_syntax', SYNTAX, 33),
                                       ('cached_proof_sharing', SHARING, 26), ('bulk_bound', BULK, 119),
                                       ('literal_forward', LITERAL, 16)]},
            'omission_overlay': omission_result,
            'omission_review': h.binding(OMISSION / 'SOURCE-AUDIT.json'),
            'consumed_cost120_predecessor': manifest['preserved_consumed_cost120_predecessor'],
            'historical_cost_origin_context': manifest['historical_cost_origin_context'],
            'origin_ownership': manifest['origin_ownership'], 'origin_sources': current_origin_rows,
            'supplemental_ownership': manifest['source_segment_ownership'][:2],
            'inherited_omissions': manifest['inherited_omissions']}


def audit_logs(required, stdout_path, stderr_path):
    out = stdout_path.read_text() if stdout_path.is_file() else ''
    err = stderr_path.read_text() if stderr_path.is_file() else ''
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [row['root'] for row in raw]
    allowed = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'passed': stdout_path.is_file() and stderr_path.is_file() and names == required
                and allowed and not err and not pattern.sub('', out).strip(),
            'required_count': len(required), 'observed_count': len(raw),
            'observed_unique_count': len(set(names)), 'raw_reports': raw,
            'duplicate_names': [name for name, count in Counter(names).items() if count > 1],
            'exact_ordered_names': names == required, 'all_raw_axiom_names_permitted': allowed,
            'stderr_empty': not err, 'unparsed_stdout': pattern.sub('', out).strip()}


def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    predecessor_markers = [path / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
                           for path in (OMISSION_PREDECESSOR, COST_PREDECESSOR, ACCEPTED_PREDECESSOR, PREDECESSOR, STABLE_PREDECESSOR, ORIGINAL_GATE)]
    require(not attempt.exists() and not marker.exists() and not any(path.exists() for path in predecessor_markers),
            'Attempt or unchanged source closure already consumed')
    require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt,
              'executor': 'root', 'gate_author': 'nat_only_gap_review',
              'module_order': MODULES, 'physical_module_count': 7,
              'distinct_upstream_origin_count': 17, 'distinct_project_origin_count': 7,
              'distinct_logical_origin_count': 24, 'source_segment_count': 26, 'origin_ownership': plan['origin_ownership'],
              'complete_origin_source_rows': plan['origin_sources'],
              'supplemental_ownership': plan['supplemental_ownership'],
              'inherited_omissions': plan['inherited_omissions'],
              'source_bindings': plan['sources'], 'controls': plan['controls'],
              'source_fingerprint': plan['source_fingerprint'], 'source_correspondence': plan['correspondence'],
              'separate_proof_correction_overlay': plan['proof_overlay'],
              'separate_stable_and_helper_proof_overlays': plan['leaf_overlays'],
              'independent_source_review': plan['review'], 'reviewed_direct_input_count': 27,
              'independent_proof_correction_review': plan['correction_review'],
              'proof_correction_review_input_count': 18,
              'independent_stable_leaf_review': plan['stable_review'],
              'stable_leaf_review_input_count': 17,
              'independent_stable_correction_review': plan['stable_correction_review'],
              'stable_correction_review_input_count': 12,
              'independent_helper_review': plan['helper_review'], 'helper_review_input_count': 25,
              'independent_diagnosed_helper_review': plan['diagnosed_helper_review'],
              'diagnosed_helper_review_input_count': 18,
              'separate_diagnosed_helper_proof_overlay': plan['diagnosed_helper_overlay'],
              'preserved_failed_helper_predecessor': plan['failed_helper_predecessor'],
              'preserved_accepted_70_predecessor': plan['accepted_70_predecessor'],
              'separate_observer_syntax_overlay': plan['observer_syntax_overlay'],
              'separate_cached_proof_sharing_overlay': plan['cached_proof_sharing_overlay'],
              'bulk_and_literal_correspondence': plan['bulk_literal_correspondence'],
              'new_separate_independent_reviews': plan['new_separate_reviews'],
              'evaluator_omission_overlay': plan['omission_overlay'],
              'evaluator_omission_independent_review': plan['omission_review'],
              'evaluator_omission_review_input_count': 61,
              'preserved_consumed_cost120_predecessor': plan['consumed_cost120_predecessor'],
              'historical_cost_origin_context': plan['historical_cost_origin_context'],
              'source_correspondence_scope': 'historical_pre_omission_owners_then_separate_exact_omission',
              'full_original_driver_native_API_preserved': False,
              'later_original_driver_restoration_required': True,
              'separate_cost_source_overlays': plan['cost_overlays'],
              'separate_cost_independent_reviews': plan['cost_separate_reviews'],
              'preserved_consumed_120_predecessor': plan['consumed_120_predecessor'],
              'cost_historical_review_scopes_rebased': False, 'cost_new_leaves_selected': [],
              'effective_Core_optional_PropWhen_omissions': {'proofs': 34, 'simp_registrations': 14},
              'Syntax11_selected': True, 'Bulk30_selected': True, 'Literal8_selected': True,
              'source_origin_rows_precede_separate_proof_overlay': True,
              'historical_reviews_rebased': False, 'compiler': plan['compiler'],
              'compiler_release': '4.35.0', 'compiler_commit': 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'runtime_libraries': plan['runtime'], 'constraints': {**POLICY, 'cpu_affinity': []},
              'execution_marker': None, 'required_prints': REQUIRED,
              'required_axiom_report_count': 120, 'required_unique_axiom_name_count': 120,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'each_physical_module_acceptance_is_all_or_nothing': True,
              'modules': [], 'seconds': None, 'peak_child_rss_kib': 0, 'artifacts': [],
              'expected_artifact_count': 14, 'prepared_objects': [], 'object_search_path': str(build),
              'all_selected_mathematical_sources_freshly_checked': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'exact_build_artifact_inventory': False,
              'cached_operational_and_licensed_25_roots_checked': False,
              'stable_memo_20_roots_checked': False,
              'direct_helper_25_roots_checked': False,
              'actual_cached_syntactic_functions_equal_separate_pure_tree_functions': False,
              'all_cached_syntactic_operations_correspondence_claimed': False,
              'actual_instantiateListC_equals_pure_instantiateList_for_all_exprs': False,
              'actual_instLevelParams_equals_pure_substitution_for_all_exprs': False,
              'bulk_cutoff_soundness_assumption_discharged': False,
              'cached_literal_forward_success_from_StableNF_and_MemoFrame': False,
              'cached_literal_forward_preserves_StableNF_and_auxiliary_not_map_equality': False,
              'literal_forward_applies_to_arbitrary_invalid_initial_cache': False,
              'actual_driver_prefix_lookup_agreement_proved': False,
              'whole_query_cached_forward_success_proved': False,
              'CSOK_or_EnvWF_discharged': False, 'actual_installed_annotation_pins_discharged': False,
              'whole_structural_evaluator_normalization_proved': False,
              'original_GroupChecked_proved': False, 'optimized_kernel_installed': False,
              'compiled_experimental_or_upstream_imports_reused': False,
              'exporter_or_native_program_or_counter_executed': False,
              'stock_numeral_theorem_proved': False, 'integrated_project_modified': False}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings'] + report['controls']:
            destination = (frozen / (row['module'] + '.lean') if 'module' in row else
                           inputs / Path(row['path']).relative_to(ROOT))
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            destination.chmod(0o444)
            row['snapshot'] = h.binding(destination)
            require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')), 'Snapshot differs')
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
        verify([row['snapshot'] for row in report['source_bindings'] + report['controls']], True)
        marker.parent.mkdir(exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': args.attempt,
                'source_fingerprint': plan['source_fingerprint'], 'source_bindings': report['source_bindings'],
                'controls': report['controls'], 'compiler': report['compiler'],
                'runtime_libraries': report['runtime_libraries'], 'policy': POLICY,
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for name in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(name, None)
        env['LEAN_IMPORT_WORKERS'] = '1'
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                       '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / (module + '.olean')),
                       '-i', str(build / (module + '.ilean')), module + '.lean']
            stdout_path, stderr_path = attempt / (module + '.stdout.log'), attempt / (module + '.stderr.log')
            record = {'module': module, 'command': command, 'status': 'running'}
            report['modules'].append(record)
            h.save(report_path, report)
            try:
                record.update(h.child(command, frozen, env, stdout_path, stderr_path, cpu, deadline))
            finally:
                for key, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                    if path.is_file():
                        record[key] = h.binding(path)
                audit = audit_logs(REQUIRED[module], stdout_path, stderr_path)
                record['axiom_audit'] = audit
                objects = all((build / (module + suffix)).is_file() for suffix in ('.olean', '.ilean'))
                record['required_outputs_present'] = objects
                good = (record.get('exit_code') == 0 and record.get('within_limits') is True
                        and audit['passed'] and objects)
                record['status'] = 'passed' if good else 'failed'
                report['observed_axiom_report_count'] = sum(m['axiom_audit']['observed_count'] for m in report['modules'])
                report['observed_unique_axiom_root_count'] = len({r['root'] for m in report['modules']
                                                                for r in m['axiom_audit']['raw_reports']})
                report['accepted_axiom_report_count'] = sum(m['axiom_audit']['observed_count']
                                                           for m in report['modules'] if m['status'] == 'passed')
                h.save(report_path, report)
            require(record['status'] == 'passed', 'Fresh module/axiom/output/resource failure: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            require(len(snapshots) == len(report['source_bindings']) + len(report['controls']), 'Incomplete snapshots')
            verify(snapshots, True)
            verify([m[key] for m in report['modules'] for key in ('stdout', 'stderr') if key in m])
            require(report['execution_marker'] is not None, 'No execution marker reserved')
            verify([report['execution_marker']], True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected = {str(build / (module + suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = ({row['path'] for row in report['artifacts']} == expected
                                                       and len(report['artifacts']) == 14)
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((m.get('sampled_tree_and_wait4_peak_rss_kib', 0)
                                          for m in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [m['module'] for m in report['modules']] == MODULES
                  and all(m['status'] == 'passed' for m in report['modules'])
                  and report['accepted_axiom_report_count'] == 120
                  and report['observed_unique_axiom_root_count'] == 120
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['cached_operational_and_licensed_25_roots_checked'] = passed
        report['stable_memo_20_roots_checked'] = passed
        report['direct_helper_25_roots_checked'] = passed
        report['observer_Core_1_root_checked'] = passed
        report['syntax_11_roots_checked'] = passed
        report['bulk_bound_30_roots_checked'] = passed
        report['literal_forward_8_roots_checked'] = passed
        report['actual_instantiateListC_equals_pure_instantiateList_for_all_exprs'] = passed
        report['actual_instLevelParams_equals_pure_substitution_for_all_exprs'] = passed
        report['bulk_cutoff_soundness_assumption_discharged'] = passed
        report['cached_literal_forward_success_from_StableNF_and_MemoFrame'] = passed
        report['cached_literal_forward_preserves_StableNF_and_auxiliary_not_map_equality'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path), 'seconds': report['seconds'],
                      'peak_rss_kib': report['peak_child_rss_kib'], 'accepted_roots': report['accepted_axiom_report_count'],
                      'observed_roots': report['observed_axiom_report_count']}, sort_keys=True))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True, help='Pinned Lean 4.35.0 bin/lean; relocation is permitted')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt), 'Invalid attempt name')
    for path, expected in FIXED.items():
        require(path.is_file() and not path.is_symlink() and sha(path) == expected,
                'Pinned control differs before loading: ' + str(path))
    h = load(HELPER, 'cached_forward_resource_helper')
    guard = load(GUARD, 'cached_forward_source_guard')
    require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Resource/axiom helper contract')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
                          'physical_module_count': 7, 'distinct_upstream_origin_count': 17,
                          'distinct_project_origin_count': 7, 'distinct_logical_origin_count': 24,
                          'source_segment_count': 26,
                          'full_original_driver_native_API_preserved': False,
                          'required_axiom_report_count': 120, 'required_unique_axiom_name_count': 120,
                          'expected_artifact_count': 14, 'prepared_objects': 0,
                          'source_fingerprint': plan['source_fingerprint'],
                          'snapshot_count': len(plan['sources']) + len(plan['controls']),
                          'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
