# Independent complete evaluator-scope 120 control review

Reviewer: root. Control author: nat_only_gap_review. Outcome: passed independent source/control review before metadata preflight and the single mathematical execution. This record does not claim compilation, measured fit, or target completion.

## Concrete review

I read the complete new protocol and authoring note, every one of the thirty literal control edits, both new verification functions, and the complete selected execution and main sections. I compared every function against the independently reviewed consumed cost120 runner. Twenty functions are unchanged; five existing functions have the disclosed historical-pin, ownership, snapshot-union, result-disclosure or consumed-marker additions. The two new functions check the source omission and literal declaration census. No mathematical process invocation or acceptance rule is added or weakened.

Independently recomputed forward and inverse transformations reproduce both complete runners. Every span's byte offset, source line, length and SHA-256 matches. The full 8,058-byte execution block has SHA-256 d026f37710ceaf9c89a049a70a9b1fc232b7a4e3f04db112188183d4cc30153c, identical to the consumed runner. This boundary includes the initial report save through the return before main; the adjacent separator newline is outside the recorded block. The permanent stage, policy literal and fingerprint construction are unchanged.

All 271 source/control identities were independently checked against the actual files; the manifest is the 272nd snapshot. The seven-owner source total is 588,573 bytes, and only Core and Cached differ from consumed cost120. All 120 ordered roots and fourteen ordinary outputs remain required. All twelve historical independent review arrays and their earlier physical selections are unchanged, with the new 61-input independent omission review and separate 60-input author inventory bound separately. The authoring and correspondence documents are themselves controls. No prior accepted object is an import.

The new omission verifier reconstructs eight edits in both directions and checks offset/text metadata, retained named declaration starts and all root prints. It checks the frozen twenty-five-source comment/string-aware consumer census and discloses the limits of that source scan. Historical full-origin correspondence runs before the omission layer. Current ownership is seventeen upstream, twenty-four logical origins and twenty-six segments; the original twenty-six/thirty-three/thirty-five scope remains historical evidence. Removed original installer/driver declarations must be restored for a later full driver closure.

## Execution and acceptance boundary

The common thirty-second interval starts before the first fresh compiler and includes final artifact and input/runtime verification and affinity restoration. Each child receives only remaining time, one compiler thread, one CPU, 1,024 MiB Lean memory and the 1,048,576 KiB process-tree resident limit. Default heartbeat/recursion/compiler options remain; no profiler or diagnostic allowance appears. All selected dependencies are freshly compiled into a new empty build; only ordinary SDK imports are prebuilt. The pinned resource helper, source guard, toolchain and runtime libraries remain checked before use.

The exclusive marker is created before the first compiler call. Current and six historical marker directories prohibit an unchanged-source retry. The new source key is 1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06. Changing filenames, control prose, attempt name or compiler relocation cannot create a new mathematical key.

Each module remains all-or-nothing: zero exit, limits honored, exact ordered reports, empty stderr, no other stdout, both ordinary outputs and only propext, Quot.sound and Classical.choice. A failed module receives no accepted credit. Complete acceptance requires all seven modules, 120 reports, fourteen artifacts, unchanged source/control/snapshot/runtime hashes and total time within thirty seconds. The pinned consumed timeout and its empty Syntax logs remain exact. Nothing in the current runner executes the count, installs a kernel or asserts cached whole-query, original GroupChecked or stock-Lean numeral completion.

This review authorizes the metadata-only preflight and one execution of this exact new selected closure under the existing user policy. A mathematical failure permanently consumes it. No source/control repair was made during review.
