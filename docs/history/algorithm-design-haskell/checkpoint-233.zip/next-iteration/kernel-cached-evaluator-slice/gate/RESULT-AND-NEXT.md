# Consumed evaluator-slice120 result and next step

The root-executed complete gate failed before accepting any theorem report.
The common measured interval was 0.5471648200000345 seconds, with peak child/tree
RSS 474,440 KiB. Core exited 1 after 0.3067126070000086 seconds. The first source
diagnostic is `KernelCompactCore.lean:35:0: error: invalid 'import' command, it
must be used in the beginning of the file`. Its stdout is exactly 107 bytes;
stderr is empty. No later module was started and no ordinary output was produced.
All snapshot, canonical source, control, runtime and marker integrity checks
passed. This is a source parser failure, not a budget-fit result.

The new omission header begins with `/-!` before the import commands. This is a
Lean module-documentation command, so imports are no longer at the beginning of
the module. The same new header form is present in both changed source owners.
A separate diagnosed source repair should change just those two leading openers
to ordinary `/-` comments, preserving all declarations and actual imports. The
failed source closure, controls, logs, report and marker remain immutable. Root
must independently review the new exact source repair and complete successor
controls before a single fresh run. No unchanged retry or resource change is
permitted.

The complete source key is
`1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06`.
The report is 253,946 bytes with SHA-256
`db069a45089d773595ad4b8d43d21143f1f521df64d3d4dc8c1213d80c5b8da1`.
The recovery record maps all 272 checked read-only snapshots to their retained
canonical identical bytes and retains both raw logs. It is not a complete
saved-result reader or a fresh mathematical verification. No Syntax/Bulk/Literal
acceptance, whole cached query, installed-record acceptance, or stock numeral
theorem follows from this run. The earlier pure177 acceptance remains separate.
