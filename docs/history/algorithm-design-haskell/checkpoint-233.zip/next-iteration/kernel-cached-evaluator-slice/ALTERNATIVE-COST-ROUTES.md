# Source-only assessment of alternative cost routes

No alternative route in this note is selected or implemented. The actual candidate
is the exact dead-family extraction in SOURCE-OMISSIONS.json.

## Explicit checked proof terms

Replacing an existing tactic proof with an ordinary explicit Lean term can avoid
re-running tactic search while retaining kernel checking. The credible targets
are intrinsic result-equality certificates in retained ExprOpsC walks and selected
termination proofs, plus standalone source proof bodies such as PropWhen.mem_merge,
sorted_merge, sorted_ext, and Expr.instantiateList_cons. These are named source
locations, not profiled dominance claims. The nine retained *XP walks contain
110 explicit Squash.mk result-certificate branches; the two removed driver walks
contain another 29. The recent constructor-proof sharing already failed to show
a measured benefit, so proof-term expansion is a separate unmeasured idea.

A valid transformation must emit ordinary Lean source. It must preserve the
original declaration types, executable branches, binder/argument order and
termination relation. Generated terms need every referenced private theorem,
match equation and tactic-generated auxiliary declaration available under the
new source identities. A complete dependency inventory must either retain those
names or materialize their ordinary checked declarations with an explicit name
map. Local proof contexts and de Bruijn binders must be reconstructed correctly.
Large unshared terms can cost more parsing and elaboration than the tactics they
replace; neither small source nor a speedup follows automatically.

An exporter would be an untrusted source producer. Its output must pass the same
source guard, independent exact-overlay review and complete fresh Lean gate with
ordinary kernel checking and the same axiom profile. Neither an old .olean as a
verification import, unchecked addDecl, skipKernelTC, an unsafe evaluator nor a
trusted proof-term blob is admissible. No exporter was executed or selected here.
The best first source experiment would target a bounded family with known private
dependencies, rather than promise a wholesale proof-term conversion.

## Noncomputable pure reference

The retained kernel-pure-reference-codegen-assessment/ASSESSMENT.md already rejects
this as a closed optimization for the unchanged complete checker. BasisGen executes
pure annotateCore in #annotate_basis/#annotate_pins, including actual basis and
axiom-pin generation. Several higher Type-valued records also hold those functions.
The ordinary source guard does not forbid noncomputable, and a precisely bounded
proof-only prefix could retain the same checked kernel equations while lacking
native implementations. That narrower possibility does not solve the real
build consumer or authorize removal of its executable API from the full checker.
No broad section or per-definition noncomputable variant is selected here.

## Dropping inference/defeq/annotation bodies

Although the current Nat query follows licensed branches, actual coreKnotI builds
all six callback slots. Removing a family or replacing a slot by a stub changes
the actual knot and needs a separate projection/call-independence theorem. The
current slice retains all six actual cached and pure bodies unchanged. No such
projection shortcut is used, and no general simulation or annotation soundness
is inferred from successful operational branches.
