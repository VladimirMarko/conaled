# Author source review: evaluator extraction

This is the source author's bounded review, pending independent root review and
fresh Lean checking. The author has read all removed declarations, their complete
source boundaries and the retained callers. No original consumed file was edited.

## Literal source checks

Each removal begins at a complete documentation/declaration or whole-origin
boundary and ends before the next retained declaration's documentation. In Core,
ConstantInfo and its derived instances precede the declaration-interface cut;
projFnName/projTableName and all ConstantInfo accessors follow it unchanged.
Env's complete type/find? interface follows the independent Declaration.names
cut. The nine whole origins are each historically wrapped in their own section
and namespace closures; removing their complete interval leaves those scopes
balanced. Basis.Names and all subsequent CoreDefs/Core/TypeChecker text remain.

The Cached all-level guard cut ends before ConLeche.Expr's namespace closure.
The second Cached cut begins after flushC and ends before ConLeche.Cached's
closure. CState, instListM, level and stored-expression helpers, every real
constTyAtM/constValAtM/ruleRhsAtM branch and the flushed-state definition are
literal. The complete CoreC source and both operational/license proof origins
are outside the cuts. There is no change to intrinsic proofs in retained walks.

The exact eight edits reconstruct forward and inverse, including every
unmodified byte between them. Core retains 387 of its 466 explicit named
declarations; Cached retains 267 of 277. The removed 79 Core entries are types
or executable installer definitions. Cached loses nine executable driver
functions plus the single unused allLevelParamsDefinedP_cut theorem. All 120
selected print names and every retained explicit source header remain unchanged.
The overlay removes the computational definitions themselves, not merely their
comments, and removes 29 intrinsic guard-walk result certificates.

## Dependency review

The selected cached knot calls its own six I-body families. It never calls the
removed Basis/Canon constructors or the two parsed-driver guards. The pure knot
also remains complete: no reference-only API has been made noncomputable.
Neither lookup/cache storage nor the current helper invariants requires a
Declaration value; actual ConstantInfo values and full metadata stay unchanged.
NatRecPins and the installed guard candidates compare retained ConstantInfo
records and therefore retain their required DecidableEq instances.

The 25-file source census covers all currently selected evaluator roots, the
accepted pure177 non-Core owners and the separately frozen forthcoming operations.
It records zero remaining full deleted-name references and zero unambiguous
short-name references. The deliberately ambiguous names were inspected: Core's
ap2 is a local helper under natOpRuleEqs, canon belongs to PropWhen, Cached's pi
is a local pinArgsI result, and names/rule/u/v are local variables or universes.
No retained open declaration imports BasisDSL. The census is not represented as
a complete elaborated dependency proof or an implicit-resolution result.

## Historical and integration limits

All previous source reviews stay at their exact selected bytes. The new map acts
after presentation and proof-sharing overlays, preserving their full originals.
The complete old cost120 result and consumed permanent key remain failed evidence;
new names or metadata alone could not reset that key. This candidate performs
substantive source/certificate extraction under the same resource policy.

Current ownership excludes nine complete upstream origins. The three partially
cut owners stay current. Historical full-origin maps and counts remain bound as
context, not mislabeled current ownership. The projected gate still checks all
120 evaluator roots; it does not claim the removed driver can execute or its
input guards/state insertion are established. Future Parsed/Installed work must
restore those exact declarations and prove its real initialization/preservation
and installation obligations. A measured improvement is unknown until a complete
fresh run; byte and certificate counts do not establish one.
