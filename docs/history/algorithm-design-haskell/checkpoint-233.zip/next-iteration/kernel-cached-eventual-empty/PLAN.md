# Eventual actual-cached empty-state semantics: finite pilot

Author: `nat_only_gap_review`. The two Lean sources are frozen source candidates
for independent review. They have not been compiled, executed or selected in a
complete gate. The separately authored reduced runtime owner is not silently
assumed by this author inventory.

## Sources and reports

| Source | New public report roots | Purpose |
| --- | ---: | --- |
| KernelCachedEventualEmpty.lean |8| Actual empty-state relations, scoped functionality, empty validity, run-only miss equations and witness construction |
| KernelCachedEventualAtoms.lean |9| Four finite trace constructors, interpretation, eventual witnesses, literal/sort forwarding |

The two sources total19,280 bytes. There is one private mathematical helper,
`full_terminal_head_atom`, in addition to the17 public roots. No existing source,
theorem statement, runtime algorithm, resource option or frozen review changes.

The logical import chain is:
`KernelCachedForward → KernelCachedMemoRelation → KernelCachedEventualEmpty →
KernelCachedEventualAtoms`.
The runtime's own Core import must be selected coherently. This package binds the
current frozen full-runtime source context and the earlier generic16 review; a
future smaller Core/Cached physical selection must be supplied and reviewed
separately. No old object, compatibility bridge or pure-reference theorem is
used as a verification input.

## Relations and the depthless cache key

`Eventual run query value` has one threshold for every sufficiently large actual
knot fuel and every depth at which `Expr.wscopedB depth query = true`. Its
reference state is the genuine empty `CState`. A successful run may return a
different final state at each fuel/depth; the relation records the exact Expr.
`Full` and `Head` instantiate the relation with original `coreKnotI` full and
noncheap head calls. The relation never substitutes a pure evaluator or assumes
that a desired numeral is correct.

`eventual_functional` compares two witnesses at the maximum of their thresholds,
the same scoped depth, and the identical empty-state action. Equality of the
actual `Except.ok` results identifies the Expr components. This proves exactly
GenericMemo's scoped functionality contract. There is no unconditional result
claim for keys that cannot be scoped, and no global cached-fuel monotonicity
theorem or independent operational determinism development is imported.

`NF` is precisely GenericMemo's all-entry invariant on the actual `whnfC` and
noncheap `whnfCoreC`. Its empty validity is vacuous. The other state fields,
including cheap normalization and helper caches, are unconstrained by this
property. The pilot's terminal operations never consult those fields.

## The noncircular memo step

The order in each memo case of `trace_runs` is explicit:

1. The strictly smaller body trace provides an induction hypothesis for every
   auxiliary invariant and its insertion frame.
2. Instantiate that IH with the trivial auxiliary invariant, the actual empty
   state and the proved empty NF invariant, at the real fixed local-loop budget.
3. Retain only the actual body run equation. The original memo miss equation
   executes the final insertion without requiring a root relation witness or a
   proof that the post-insertion state is valid.
4. Package those run-only equations for every sufficiently large predecessor
   fuel and every scoped depth into the root's eventual witness. The threshold
   increases by one for the original positive-fuel knot entry.
5. Apply the unchanged generic memo forwarding theorem to the caller's supplied
   valid state and auxiliary invariant. On a hit, exact functionality identifies
   the actual cached value. On a miss, reuse the smaller body IH at that supplied
   state, then prove insertion validity with the newly established root witness.

There is no circular definition of the relation: it refers only to the already
defined actual cached program, its fixed empty initial state and ordinary
existential run equations. There is no circular induction premise: every body
or head call used by the interpreter is represented by a strict child of a
finite `Trace` value. The full-terminal constructor's same-query head call is
also a strict child with a different command index.

## Deliberately small operational fragment

`HeadAtom` lists exactly the terminal head constructors: sort, fvar, forall,
lambda, constant and literal. It excludes raw bvars, applications, lets and
projections, matching the actual head step's error and recursive branches.

`FullTerminal` additionally excludes constants, which may unfold. The actual
native-Nat and delta helpers both return `none` on its remaining constructors,
so the full loop preserves exactly the state returned by its head callback.
The four trace constructors are head-atom, head-memo, full-terminal and full-memo.

Head atoms have knot threshold1 and full terminal calls threshold2. The final
`cached_nat` and `cached_sort` theorems provide real full-WHNF equations from any
state satisfying the two new map relations and an arbitrary `MemoFrame`
auxiliary invariant. Their scope proofs explicitly use the `Expr.wscopedB`
equations. Sort normalization is included because the original record path
performs it before the large numeric query.

The finite constructor datatype contains no cached-success premise and no
eventual/pure backing field. The only run-equation premises in the two public
run-only miss helpers are genuine smaller body equations, discharged in the
finite interpreter itself. The terminal equation helper takes the actual head
callback equation, likewise discharged by a child trace.

## Required next extensions and boundaries

This pilot proves no beta, delta, native arithmetic, Nat recursion or whole-query
trace. Those operators must be added using actual helper outputs, indexed
lookups, stored licenses, local budgets and returned-state threading. The
current generic helper-result facts already expose equality of both NF maps;
they can be reused with GenericMemo's `nf_frame` after an exact import split.
For these later extensions the forwarding property must also require the real
`HelperCache fe` conditions, prove them for the genuine empty state, and preserve
them through all actual helper writes. No arbitrary flush establishes the
surviving converted-entry tags. The present atom interpreter does not pretend
to provide those missing facts.

The reduced runtime selection must retain all actual cached operations and
their native Lift/record APIs, the16 shared Core runtime declarations and their
error instance. It may omit independently inventoried pure-only checker
declarations because the new sources do not refer to them. The original pure
StableNF, Compatibility12 and pure-support body/head proofs must not re-enter
that selected proof closure merely to translate back to the old invariant.

The final original record proof needs a new internal invariant path or an
appropriately generalized wrapper while preserving the unchanged actual
`checkPending` equation. Actual stored-record recognizers, pure-template/source
correspondence, the numerical backend equality/comparison, installed-record
membership and original native `GroupChecked` remain independent obligations.
The native installer's separate BasisGen/pure-client/default-data dependencies
are not solved by this pilot. Fresh closure cost and final producer eligibility
remain unestablished.

## Validation status

The author read the complete two sources, actual cached miss/loop/terminal
definitions, the generic memo interfaces and their current review. Exact source
identities, report names, direct imports and primary-source intervals are
recorded in the accompanying inventory and context maps. Book's preliminary
architectural source read found no blocker; the final independent audit is a
separate artifact and is not claimed in this author freeze. No mathematical
execution, preflight or budget-fit measurement has occurred for this package.
