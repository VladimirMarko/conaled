import KernelCachedEventualEmpty

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# A finite constructor pilot for actual empty-state memo semantics

The trace has separate full/head commands and full/head local loops. Every
memo constructor contains only a strictly smaller body trace and its real
local-budget bound. No constructor carries a root result-relation witness or
a cached-success equation. The full-loop constructor delegates to a strictly
smaller head trace for the same query.

The interpreter first obtains the root's empty-state run from the body IH with
the trivial auxiliary invariant. Its final insertion is an operational step
and needs no proof that the inserted value is already related. Only after
constructing the eventual witness does the interpreter invoke generic memo
forwarding for arbitrary valid initial maps and auxiliary frames.

This pilot covers terminal head constructors and full terminal results,
including natural literals and sorts. It does not cover beta, delta, native
arithmetic, Nat recursion, helper writes or the whole queens query. Those
extensions must supply their actual body equations and state preservation.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualAtoms

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation
open KernelCachedEventualEmpty

/-- Exactly the terminal constructor cases of the actual head step. Raw
bound variables, applications, lets and projections are excluded. -/
def HeadAtom : Expr → Prop
  | .sort _ | .fvar .. | .forallE .. | .lam .. | .const .. | .lit _ => True
  | _ => False

/-- These heads cannot enter either native arithmetic or definition unfolding.
A constant head is deliberately absent because it may unfold. -/
def FullTerminal : Expr → Prop
  | .sort _ | .fvar .. | .forallE .. | .lam .. | .lit _ => True
  | _ => False

private theorem full_terminal_head_atom (expression : Expr)
    (terminal : FullTerminal expression) : HeadAtom expression := by
  cases expression <;> try cases terminal
  all_goals trivial

def Forward (mode : CheckMode) (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) : Prop :=
  ∀ state, NF mode fe state → auxiliary state →
    ∃ final, action state = .ok (value, final) ∧
      NF mode fe final ∧ auxiliary final

inductive Command where
  | full (query : Expr)
  | head (query : Expr)
  | fullLoop (query : Expr)
  | headLoop (query : Expr)

def Runs (mode : CheckMode) (fe : FEnv) (auxiliary : CState → Prop)
    (command : Command) (value : Expr) (knot localBound : Nat) : Prop :=
  match command with
  | .full query =>
    ∀ fuel depth, knot ≤ fuel → Expr.wscopedB depth query = true →
      Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnf depth query) value
  | .head query =>
    ∀ fuel depth, knot ≤ fuel → Expr.wscopedB depth query = true →
      Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnfCore false depth query) value
  | .fullLoop query =>
    ∀ fuel depth budget, knot ≤ fuel → localBound ≤ budget →
      Expr.wscopedB depth query = true →
      Forward mode fe auxiliary
        (whnfLoopI (coreKnotI mode fe fuel) fe depth budget query) value
  | .headLoop query =>
    ∀ fuel depth budget, knot ≤ fuel → localBound ≤ budget →
      Expr.wscopedB depth query = true →
      Forward mode fe auxiliary
        (whnfCoreLoopI mode (coreKnotI mode fe fuel) fe false depth budget query) value

/-- Finite evidence of body structure, not evidence assuming the root run. -/
inductive Trace : Command → Expr → Nat → Nat → Prop where
  | headAtom (expression : Expr) (atom : HeadAtom expression) :
      Trace (.headLoop expression) expression 0 1
  | headMemo (query value : Expr) (knot localBound : Nat)
      (fits : localBound ≤ whnfCoreLoopFuel)
      (body : Trace (.headLoop query) value knot localBound) :
      Trace (.head query) value (knot + 1) 0
  | fullTerminal (query value : Expr) (knot : Nat)
      (terminal : FullTerminal value)
      (head : Trace (.head query) value knot 0) :
      Trace (.fullLoop query) value knot 1
  | fullMemo (query value : Expr) (knot localBound : Nat)
      (fits : localBound ≤ whnfLoopFuel)
      (body : Trace (.fullLoop query) value knot localBound) :
      Trace (.full query) value (knot + 1) 0

theorem head_loop_atom (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth budget : Nat) (expression : Expr)
    (atom : HeadAtom expression) (state : CState) :
    whnfCoreLoopI mode callbacks fe false depth (budget + 1) expression state =
      .ok (expression, state) := by
  change whnfCoreStepI mode callbacks fe false depth
    (whnfCoreLoopI mode callbacks fe false depth budget) expression state = _
  cases expression <;> try cases atom
  all_goals rfl

/-- The exact state returned by the head callback threads through the two
actual terminal branches. No relation or cache premise is used here. -/
theorem full_loop_terminal_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (query value : Expr) (terminal : FullTerminal value)
    (state afterHead : CState)
    (headRun : callbacks.whnfCore false depth query state = .ok (value, afterHead)) :
    whnfLoopI callbacks fe depth (budget + 1) query state =
      .ok (value, afterHead) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind]
  cases value <;> try cases terminal
  all_goals rfl

/-- The body IH is available for every auxiliary invariant. In the two memo
cases it is first used with True at the genuine empty state; afterward it is
used with the caller's auxiliary invariant at the caller's actual state. -/
theorem trace_runs (mode : CheckMode) (fe : FEnv)
    (command : Command) (value : Expr) (knot localBound : Nat)
    (trace : Trace command value knot localBound) :
    ∀ auxiliary : CState → Prop, MemoFrame auxiliary →
      Runs mode fe auxiliary command value knot localBound := by
  induction trace with
  | headAtom expression atom =>
    intro auxiliary _frame fuel depth budget _enoughKnot enoughLocal _queryScoped
      state valid auxiliaryValid
    cases budget with
    | zero => omega
    | succ previous =>
      exact ⟨state, head_loop_atom mode (coreKnotI mode fe fuel) fe depth previous
        expression atom state, valid, auxiliaryValid⟩
  | headMemo query value knot localBound fits _body ih =>
    have backing : Head mode fe query value :=
      head_eventual_of_body_runs mode fe query value knot (by
        intro fuel depth enough queryScoped
        obtain ⟨afterBody, bodyRun, _finalValid, _finalAuxiliary⟩ :=
          ih (fun _ => True) true_memo_frame fuel depth whnfCoreLoopFuel
            enough fits queryScoped {} (empty_valid mode fe) trivial
        exact ⟨afterBody, bodyRun⟩)
    intro auxiliary frame fuel depth enough queryScoped state valid auxiliaryValid
    cases fuel with
    | zero => omega
    | succ predecessor =>
      have bodyEnough : knot ≤ predecessor := Nat.le_of_succ_le_succ enough
      exact KernelCachedMemoRelation.head_forward_of_body
        (Full mode fe) (Head mode fe) (head_functional mode fe)
        mode fe predecessor depth query value auxiliary frame backing queryScoped
        state valid auxiliaryValid (fun _miss =>
          ih auxiliary frame predecessor depth whnfCoreLoopFuel bodyEnough fits
            queryScoped state valid auxiliaryValid)
  | fullTerminal query value knot terminal _head ih =>
    intro auxiliary frame fuel depth budget enoughKnot enoughLocal queryScoped
      state valid auxiliaryValid
    cases budget with
    | zero => omega
    | succ previous =>
      obtain ⟨afterHead, headRun, headValid, headAuxiliary⟩ :=
        ih auxiliary frame fuel depth enoughKnot queryScoped state valid auxiliaryValid
      exact ⟨afterHead, full_loop_terminal_of_head (coreKnotI mode fe fuel) fe
        depth previous query value terminal state afterHead headRun,
        headValid, headAuxiliary⟩
  | fullMemo query value knot localBound fits _body ih =>
    have backing : Full mode fe query value :=
      full_eventual_of_body_runs mode fe query value knot (by
        intro fuel depth enough queryScoped
        obtain ⟨afterBody, bodyRun, _finalValid, _finalAuxiliary⟩ :=
          ih (fun _ => True) true_memo_frame fuel depth whnfLoopFuel
            enough fits queryScoped {} (empty_valid mode fe) trivial
        exact ⟨afterBody, bodyRun⟩)
    intro auxiliary frame fuel depth enough queryScoped state valid auxiliaryValid
    cases fuel with
    | zero => omega
    | succ predecessor =>
      have bodyEnough : knot ≤ predecessor := Nat.le_of_succ_le_succ enough
      exact KernelCachedMemoRelation.full_forward_of_body
        (Full mode fe) (Head mode fe) (full_functional mode fe)
        mode fe predecessor depth query value auxiliary frame backing queryScoped
        state valid auxiliaryValid (fun _miss =>
          ih auxiliary frame predecessor depth whnfLoopFuel bodyEnough fits
            queryScoped state valid auxiliaryValid)

theorem full_trace_eventual (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (knot : Nat) (trace : Trace (.full query) value knot 0) :
    Full mode fe query value := by
  refine ⟨knot, ?_⟩
  intro fuel depth enough queryScoped
  obtain ⟨final, run, _valid, _auxiliary⟩ :=
    trace_runs mode fe (.full query) value knot 0 trace
      (fun _ => True) true_memo_frame fuel depth enough queryScoped
      {} (empty_valid mode fe) trivial
  exact ⟨final, run⟩

theorem head_trace_eventual (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (knot : Nat) (trace : Trace (.head query) value knot 0) :
    Head mode fe query value := by
  refine ⟨knot, ?_⟩
  intro fuel depth enough queryScoped
  obtain ⟨final, run, _valid, _auxiliary⟩ :=
    trace_runs mode fe (.head query) value knot 0 trace
      (fun _ => True) true_memo_frame fuel depth enough queryScoped
      {} (empty_valid mode fe) trivial
  exact ⟨final, run⟩

theorem head_atom_trace (expression : Expr) (atom : HeadAtom expression) :
    Trace (.head expression) expression 1 0 := by
  exact Trace.headMemo expression expression 0 1
    (by unfold whnfCoreLoopFuel; decide) (Trace.headAtom expression atom)

theorem full_terminal_trace (expression : Expr) (terminal : FullTerminal expression) :
    Trace (.full expression) expression 2 0 := by
  exact Trace.fullMemo expression expression 1 1 (by unfold whnfLoopFuel; decide)
    (Trace.fullTerminal expression expression 1 terminal
      (head_atom_trace expression (full_terminal_head_atom expression terminal)))

/-- An actual natural literal call with no preexisting answer or success
assumption, from any state whose two memos satisfy the new relations. -/
theorem cached_nat (mode : CheckMode) (fe : FEnv) (fuel depth number : Nat)
    (enough : 2 ≤ fuel) (auxiliary : CState → Prop) (frame : MemoFrame auxiliary) :
    Forward mode fe auxiliary
      ((coreKnotI mode fe fuel).whnf depth (.lit (.natVal number)))
      (.lit (.natVal number)) := by
  exact trace_runs mode fe (.full (.lit (.natVal number))) (.lit (.natVal number))
    2 0 (full_terminal_trace _ trivial) auxiliary frame fuel depth enough
    (by simp only [Expr.wscopedB])

/-- Sort normalization is also needed by the later original record wrapper;
its full and head memo writes satisfy the same exact-expression relations. -/
theorem cached_sort (mode : CheckMode) (fe : FEnv) (fuel depth : Nat) (level : Level)
    (enough : 2 ≤ fuel) (auxiliary : CState → Prop) (frame : MemoFrame auxiliary) :
    Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnf depth (.sort level))
      (.sort level) := by
  exact trace_runs mode fe (.full (.sort level)) (.sort level)
    2 0 (full_terminal_trace _ trivial) auxiliary frame fuel depth enough
    (by simp only [Expr.wscopedB])

#print axioms head_loop_atom
#print axioms full_loop_terminal_of_head
#print axioms trace_runs
#print axioms full_trace_eventual
#print axioms head_trace_eventual
#print axioms head_atom_trace
#print axioms full_terminal_trace
#print axioms cached_nat
#print axioms cached_sort

end ADWH.Experiments.Chapter15.KernelCachedEventualAtoms
