import KernelCachedMemoRelation

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Exact memo values from eventual runs of the actual cached evaluator

The reference state is the genuine empty CState. Both relations quantify over
every sufficiently large actual knot fuel and every depth at which the key is
well scoped. The final state may depend on that fuel and depth. Only the exact
returned Expr is part of the relation.

A run-only memo miss equation does not require validity of the inserted value.
It can therefore turn a strictly smaller finite body derivation into the root's
eventual witness. That witness is used afterward by relation-parametric memo
forwarding for arbitrary valid initial maps. No whole-query success, pure
normalization, monotonicity, installation fact or seeded state is assumed.

This is a source-only pilot. Its imports still need a separately reviewed
physical runtime selection before any claim of removing the pure owner or of
fresh default-resource acceptance.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualEmpty

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation

/-- The same expression-key relation is used at every later scoped depth.
No uniqueness is demanded when the key cannot be scoped at any depth. -/
def Eventual (run : Nat → Nat → Expr → CheckCM Expr)
    (query value : Expr) : Prop :=
  ∃ threshold, ∀ fuel depth, threshold ≤ fuel →
    Expr.wscopedB depth query = true →
    ∃ final : CState, run fuel depth query {} = .ok (value, final)

def Full (mode : CheckMode) (fe : FEnv) : Expr → Expr → Prop :=
  Eventual (fun fuel depth query => (coreKnotI mode fe fuel).whnf depth query)

def Head (mode : CheckMode) (fe : FEnv) : Expr → Expr → Prop :=
  Eventual (fun fuel depth query =>
    (coreKnotI mode fe fuel).whnfCore false depth query)

abbrev NF (mode : CheckMode) (fe : FEnv) (state : CState) : Prop :=
  NFValid (Full mode fe) (Head mode fe) state

/-- Both witnesses run the identical actual action from the identical empty
state at one common future fuel. Equality of the returned pair identifies its
first component even though the witness states were independently chosen. -/
theorem eventual_functional (run : Nat → Nat → Expr → CheckCM Expr) :
    ScopedFunctional (Eventual run) := by
  intro query left right depth queryScoped leftValid rightValid
  obtain ⟨leftThreshold, leftRun⟩ := leftValid
  obtain ⟨rightThreshold, rightRun⟩ := rightValid
  obtain ⟨leftState, leftResult⟩ := leftRun (max leftThreshold rightThreshold)
    depth (Nat.le_max_left leftThreshold rightThreshold) queryScoped
  obtain ⟨rightState, rightResult⟩ := rightRun (max leftThreshold rightThreshold)
    depth (Nat.le_max_right leftThreshold rightThreshold) queryScoped
  have pairSame : (left, leftState) = (right, rightState) :=
    Except.ok.inj (leftResult.symm.trans rightResult)
  exact congrArg Prod.fst pairSame

theorem full_functional (mode : CheckMode) (fe : FEnv) :
    ScopedFunctional (Full mode fe) :=
  eventual_functional _

theorem head_functional (mode : CheckMode) (fe : FEnv) :
    ScopedFunctional (Head mode fe) :=
  eventual_functional _

theorem empty_valid (mode : CheckMode) (fe : FEnv) : NF mode fe {} :=
  nf_empty (Full mode fe) (Head mode fe)

/-- This operational equation has no root relation or final invariant premise.
The original memo writes its result after the supplied actual body run. -/
theorem full_miss_from_empty (mode : CheckMode) (fe : FEnv)
    (fuel depth : Nat) (query value : Expr) (afterBody : CState)
    (bodyRun : whnfBodyI (coreKnotI mode fe fuel) fe depth query {} =
      .ok (value, afterBody)) :
    (coreKnotI mode fe (fuel + 1)).whnf depth query {} =
      .ok (value, { afterBody with whnfC := afterBody.whnfC.insert query value }) := by
  apply KernelCachedForward.whnf_miss mode fe fuel depth query value {} afterBody
  · change (∅ : Std.HashMap Expr Expr)[query]? = none
    simp only [Std.HashMap.getElem?_empty]
  · exact bodyRun

theorem head_miss_from_empty (mode : CheckMode) (fe : FEnv)
    (fuel depth : Nat) (query value : Expr) (afterBody : CState)
    (bodyRun : whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query {} =
      .ok (value, afterBody)) :
    (coreKnotI mode fe (fuel + 1)).whnfCore false depth query {} =
      .ok (value, { afterBody with whnfCoreC := afterBody.whnfCoreC.insert query value }) := by
  apply KernelCachedForward.whnfCore_miss mode fe fuel depth query value {} afterBody
  · change (∅ : Std.HashMap Expr Expr)[query]? = none
    simp only [Std.HashMap.getElem?_empty]
  · exact bodyRun

/-- A body equation at each sufficiently large predecessor fuel produces the
root witness. The finite-trace leaf supplies these equations by strict body
induction; this lemma does not obtain them from the current full call. -/
theorem full_eventual_of_body_runs (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (threshold : Nat)
    (bodyRuns : ∀ fuel depth, threshold ≤ fuel →
      Expr.wscopedB depth query = true →
      ∃ afterBody : CState,
        whnfBodyI (coreKnotI mode fe fuel) fe depth query {} =
          .ok (value, afterBody)) :
    Full mode fe query value := by
  refine ⟨threshold + 1, ?_⟩
  intro fuel depth enough queryScoped
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have bodyEnough : threshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    obtain ⟨afterBody, bodyRun⟩ := bodyRuns predecessor depth bodyEnough queryScoped
    exact ⟨{ afterBody with whnfC := afterBody.whnfC.insert query value },
      full_miss_from_empty mode fe predecessor depth query value afterBody bodyRun⟩

theorem head_eventual_of_body_runs (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (threshold : Nat)
    (bodyRuns : ∀ fuel depth, threshold ≤ fuel →
      Expr.wscopedB depth query = true →
      ∃ afterBody : CState,
        whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query {} =
          .ok (value, afterBody)) :
    Head mode fe query value := by
  refine ⟨threshold + 1, ?_⟩
  intro fuel depth enough queryScoped
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have bodyEnough : threshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    obtain ⟨afterBody, bodyRun⟩ := bodyRuns predecessor depth bodyEnough queryScoped
    exact ⟨{ afterBody with whnfCoreC := afterBody.whnfCoreC.insert query value },
      head_miss_from_empty mode fe predecessor depth query value afterBody bodyRun⟩

#print axioms eventual_functional
#print axioms full_functional
#print axioms head_functional
#print axioms empty_valid
#print axioms full_miss_from_empty
#print axioms head_miss_from_empty
#print axioms full_eventual_of_body_runs
#print axioms head_eventual_of_body_runs

end ADWH.Experiments.Chapter15.KernelCachedEventualEmpty
