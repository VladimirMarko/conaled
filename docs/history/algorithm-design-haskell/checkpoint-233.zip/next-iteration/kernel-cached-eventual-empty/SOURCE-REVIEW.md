# Independent source review: eventual actual-cached empty-state pilot

Reviewer: `book_scope_review`.

**Verdict: passed for the two new logical source files and their recorded
interfaces.** This is source inspection, not Lean elaboration or fresh closure
acceptance. The separate reduced Core/Cached owner selection is outside this
review. Its author inventory and independent review must remain distinct.

## Exact reviewed scope

The held sources are `KernelCachedEventualEmpty.lean` (6,934 bytes, eight public
report roots) and `KernelCachedEventualAtoms.lean` (12,346 bytes, nine public
report roots). Their combined 19,280 bytes contain 17 public theorems and one
private helper theorem, `full_terminal_head_atom`. Both sources were read in
full, as was the unchanged generic memo relation source. The actual cached
state, memo implementation, knot, positive-fuel hit/miss equations, terminal
head step, full step, local loops and callback interfaces were checked against
the retained current implementation.

All 420 author input identities match their recorded byte counts and SHA-256
digests. The complete 409-input prior GenericMemo review context is included
verbatim, without rebasing its source ownership, status or identities. This
review's direct input list adds the current author inventory, for 421 inputs.
The inherited list contains six context paths outside `adwh-work` (three pinned
SDK paths and three pinned upstream paths); this review adds no new such path.
A portable gate must retain those original identities and use an explicit
byte-identical recovery mapping where needed, rather than rewriting this scope.

All 16 primary excerpts were independently reconstructed in two ways: from their
half-open byte intervals and from their inclusive line intervals. Each literal
text, excerpt length and digest matches. The two sources' imports, options,
namespaces, ordered report identifiers, qualified roots, private theorem count
and total byte count match all three source/inventory/dependency descriptions.
The sources are new mathematical leaves; there is no claimed old-to-new runtime
transformation or omitted theorem body to reconstruct in this package.

## Relation and scoped functionality

`Eventual run query value` is a proposition about the genuine supplied action,
run from the actual empty `CState`. Its witness gives one threshold that works
for every later fuel and every depth at which the key is scoped. The returned
expression is exact syntax; the existential final state may vary with fuel and
depth. The fixed reference state is not seeded with a result. `Full` and `Head`
use the actual `coreKnotI` full and noncheap head operations.

The functionality proof is sound without a global fuel monotonicity theorem.
It runs the two eventual witnesses at the maximum of their thresholds, the same
scoped depth, the same query and the same empty state. Both equations therefore
describe the same `Except` result. Injectivity of `Except.ok` and projection of
the returned pair identify the expressions, independently of how the two final
states were chosen.

This gives precisely GenericMemo's `ScopedFunctional` contract. Cache keys
remain expressions alone. Every map entry is quantified by the invariant,
without a reachability or literal-only restriction; the relation itself supplies
uniform evidence for every scoped depth at which such an entry can be used.
The relation can be vacuous for a key with no scoped depth, but the hit theorem
always requires a current scoping witness. No unscoped uniqueness claim is
needed or made.

`NF` is exactly `NFValid (Full mode fe) (Head mode fe)`. It covers the actual
`whnfC` and noncheap `whnfCoreC` maps. Its empty-state theorem follows from the
absence of entries. It asserts nothing about helper, cheap-head, inference,
annotation, conversion or level-cache fields.

## The memo induction is noncircular

The two empty-state miss theorems use the original positive-fuel memo equations.
They prove the actual empty-map miss, run the supplied predecessor-fuel body,
and retain the exact final insertion. Their premises contain neither a root
relation witness nor validity of the post-insertion map. They are operational
run equations, not an inversion of a simulation or a semantic-success theorem.

The eventual-witness helpers take smaller body equations uniformly over future
predecessor fuel and scoped depth. They increase the threshold by one, split the
actual root fuel into zero/successor, and use the run-only miss theorem in the
successor case. The zero case is excluded by the threshold. In particular, the
root witness is established before it is used to justify insertion validity.

The finite trace interpreter follows this order in each memo case:

1. Instantiate the strict body induction hypothesis with the trivial auxiliary
   predicate and its proved `MemoFrame`, the genuine empty state, and the real
   fixed local-loop budget.
2. Extract the body run equation. The returned-state validity and auxiliary
   facts are discarded for the purpose of constructing the root witness.
3. Apply the corresponding eventual-witness helper, which executes the original
   miss and insertion without assuming the root witness.
4. Apply unchanged GenericMemo forwarding to the caller's arbitrary valid
   state and auxiliary invariant, reusing the body induction hypothesis at
   that state when there is a miss.

The interpreter quantifies the auxiliary predicate and its frame outside the
case-local proof. Its induction hypotheses can therefore be used first with
`True`, and later with the caller's predicate. This is essential to the argument
and is present in the actual statement. The `fullTerminal` constructor's head
call for the same query is also a strict trace child. Switching from the full
command to the head command does not introduce a same-size induction call.

Neither the four trace constructors nor their interpretation carries a root
cached-success premise, a pure evaluator witness, a desired numeral, or a
presumed final-state invariant. The abstract run-only helper premises are
discharged from the strict trace children within the interpreter.

## Actual terminal operations and bounds

`HeadAtom` matches the actual head-step terminal cases: sort, free variable,
forall, lambda, constant and literal. Bound variables, applications, lets and
projections are excluded. In particular, this source does not invent a raw-let
normalization branch; the original cached head step rejects raw lets.

`FullTerminal` excludes constants as well, because they may enter definition
unfolding. For its remaining constructors, actual `reduceNatI` and
`unfoldDefinitionI` both return `none`. The full-loop equation consequently
returns the exact expression and state provided by the actual head callback.
The local proof preserves that state explicitly. The allowed terminal branches
consult no helper cache and perform no helper writes, so the pilot does not need
to infer helper validity from `NF` or from `MemoFrame`.

The head loop consumes one positive local step. The full loop consumes one
positive local step and calls the head callback. The memo entries each consume
one knot successor. The resulting head-atom threshold is one, and the full
terminal threshold is two. The fit proofs use the original `whnfCoreLoopFuel`
and `whnfLoopFuel` constants; their large values are runtime local budgets,
not new Lean resource settings. The final literal and sort proofs explicitly
use the `Expr.wscopedB` equations rather than assuming definitional reduction of
that well-founded predicate.

`cached_nat` and `cached_sort` therefore state actual full-normalization runs
from any state satisfying the new two-map invariant, while preserving an
arbitrary independently framed auxiliary predicate. They have no preloaded
answer or whole-call success premise. The original record sort-normalization
excerpt supplies a future application context, not a newly proved record step.

## Ownership, proof dependency and remaining limits

The new import chain is exactly GenericMemo → EventualEmpty → EventualAtoms.
The six transitive project memo proof roots are the original generic memo
hit/miss equations and actual full/head positive-fuel hit/miss equations. The
new leaves do not import StableNF, the compatibility bridge, HelperDirect, a
pure-WHNF result theorem, or the previous full-query trace interpretation.

The author inventory deliberately pins a historical full Core/Cached context
and sets `prospective_physical_selection` to null. Those historical source files
still contain their original wider declaration families. Thus this logical
review does not itself establish removal of the pure owner. The separately
authored reduced runtime, exact omissions, native correspondence, retained
runtime APIs, source guard eligibility and complete fresh selection require
their own review. No old review is relabeled to apply to that later owner.

This pilot proves only the finite terminal fragment. Beta, delta, arithmetic,
Nat recursion, projections, helper writes and a whole-query trace remain
outside it. A helper extension must establish the real helper-cache conditions
for the actual empty state and preserve them through each original helper
effect. A generic flush theorem for the two NF maps cannot supply the surviving
converted-entry tags. `MemoFrame` alone does not preserve arbitrary auxiliary
predicates through helper writes or record processing.

The original record, annotation, stored-program recognition, true-prefix
lookup, numerical equality/comparison, installed-record membership, native
declaration ownership and `GroupChecked` obligations remain separate. The
native installer's BasisGen and default-data dependencies are not repaired by
this pilot. It provides no concrete numeral, installed guard pass, certificate
production, whole-checker success or performance result.

The only options in each new file are `autoImplicit false`, `warningAsError
true`, and `Elab.async false`. Inspection found no admitted proof, new axiom,
unsafe declaration, resource override, unchecked evaluator or native-decision
mechanism. Ordinary elaboration, strict-warning acceptance and compilation of
the complete selected closure are still required. No Lean command, compiler,
gate, metadata preflight, evaluator, exporter, profiler, retained generator or
dedicated saved-result reader was executed by this reviewer.
