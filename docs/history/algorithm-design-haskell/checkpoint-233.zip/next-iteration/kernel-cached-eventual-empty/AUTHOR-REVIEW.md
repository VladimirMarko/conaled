# Author source review of the eventual-empty pilot

The relation is over exact Expr values, not natural-number denotations or
extensionally equal functions. One threshold is uniform across every scoped
depth; the actual cache remains keyed by Expr alone. Uniqueness compares the
same actual action at the same common future fuel and genuine empty state.

The miss helpers retain the original positive-fuel boundary and exact inserted
state. Their bodies use `KernelCachedForward.whnf_miss/whnfCore_miss`; they have
no final-NF or root-backing premise. Consequently the finite interpreter can
obtain the root witness before proving the root insertion preserves the map
invariant. Its sole recursive argument in each memo case is the body trace.

The finite interpreter quantifies auxiliary invariants outside the case-local
proof. Each body IH can therefore be instantiated with True for constructing
the semantic witness and with the actual caller invariant afterward. The
empty validity proof requires no existing entry and no preloaded answer.
The full-terminal constructor stores a strict head child for the same query,
so that command switch does not create a recursive proof cycle.

The terminal constructor predicates match the actual runtime branches. Bvars,
lets, projections and applications are absent from HeadAtom. Constants are
further absent from FullTerminal. Full-loop terminal success threads precisely
the returned head state through actual reduceNatI/unfoldDefinitionI `none`
branches. No helper map is read or updated by these terminal branches. The
arbitrary auxiliary frame therefore needs only the two real NF insertions.

All knot/local fuel inequalities retain the original ordinary constants.
Memo entries cost one knot successor; the terminal head/full traces have
thresholds1/2. The final Nat and sort scope premises use explicit wscopedB
equations, avoiding the previously diagnosed reliance on plain rfl for that
well-founded definition.

The17 public reports plus one private theorem have no admitted goals, unsafe
declarations, new axioms, unchecked kernel operations, native_decide or
resource overrides. No source computes queens or assumes its expected total.
The two Lean files import only the generic memo chain and contain no direct
pure evaluator, StableNF, compatibility or whole-query success premise.

This is source inspection, not an elaboration result. The earlier GenericMemo
review supplies its own bounded source scope but not fresh module acceptance
in this new closure. The historical full runtime context is distinguished from
the reduced runtime assembly being authored separately. All broader operational,
helper, record, annotation, installation, native-ownership and timing boundaries
in PLAN.md remain open.
