# Checkpoint 203 selection review

The recovery selection preserves all checkpoint 202 payload paths and adds the
two accepted primitive-reference proof/export results, both actual scalar/
recursor failures, exact historical source/control recovery, and the reviewed
but uncompiled NatRecGuard preparation. No accepted result has been dropped.
The current Natrec source is the actual failed complete-02 version; its next
correction is not yet selected or accepted. Unfrozen Bool and masked-evaluator
preparations are outside this publication.

Both actual primitive export streams are retained. Duplicate attempt input
snapshots resolve through checked canonical maps; unique older texts, every
raw log/report and permanent marker remain physical. No compiled artifact,
compiler binary, native executable, cache, previous ZIP, or full upstream
checkout is included. The imported logical kernel sources remain physical.
The clean checkpoint202 extraction record is included.

The existing 33 MiB publication allowance is selected explicitly for this
checkpoint after reviewing the added source/evidence and canonical recovery
selection. The default CHECKPOINT-POLICY guard remains 32 MiB. This storage
allowance is unrelated to, and does not change, any mathematical 30-second,
one-CPU/thread, 1-GiB limit. The packager must still verify exact members, CRCs,
all payload hashes and the integrated/n6 source bindings before publication.

Root ran both new saved-evidence auditors in live and source-only modes. They
passed without launching a compiler, exporter, counter or new gate. The
recursor audit preserves both whole-closure failures, including the actual
second attempt's deadline violation and zero Natrec root acceptance.
