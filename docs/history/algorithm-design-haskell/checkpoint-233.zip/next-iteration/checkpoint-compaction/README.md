# Checkpoint compaction

The user clarified that checkpoints are durability, not version control. The
previous packager recursively archived the cumulative experiment tree, retaining
full repeated source/input snapshots and failed writes at every checkpoint.

Checkpoint 175 is 400,288,864 bytes (381.745 MiB), with 12,404 ZIP members and
2,116,115,802 uncompressed bytes including its manifest. Its five largest members
are three copies of one 173,786,113-byte n6 diagnostic certificate and two
abandoned partial outputs. Together those members consume 188,242,986 compressed
bytes, 47.0% of the ZIP. The independent full hash audit found 6,068 redundant
payload occurrences across 657 duplicate groups, accounting for 194,961,733
compressed bytes beyond one copy of each payload. These two figures overlap.

The accepted n6 proof does not read that external JSON. Its three complete Lean
bundles occupy 4,042,014 bytes, or 1,003,455 compressed bytes in checkpoint 175.
The 58 modular editing inputs add 1,026,262 compressed bytes. Both are retained,
with their exact consolidation recipe and successful gate/audit evidence.

The replacement selects a current standalone recovery tree. It retains the
integrated project and original source evidence, useful certificate method
sources and generators, the final n6 closure, selected current diagnostic data,
and the active post-175 signed-relation work. It omits cumulative history and
does not depend on prior archives. Existing archives and working files are not
deleted.

`prepare_selection.py` documents this one-time migration from checkpoint 175;
it performs file selection only. Future packaging reads the explicit root
`durability-selection.json`, which should track the current work rather than
grow by appending every historical file. The new packager has a 32 MiB default
publication guard and checks exact payload hashes before publication.

This is a packaging change. Existing mathematical statements, source hashes,
resource limits, trust constraints and recorded outcomes are unchanged. The
main n16 theorem remains open.
