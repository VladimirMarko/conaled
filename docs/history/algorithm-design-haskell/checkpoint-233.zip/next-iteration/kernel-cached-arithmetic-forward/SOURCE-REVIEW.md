# Independent source review: actual cached binary arithmetic forwarding

Status: **passed source-only mathematical review; the new leaf is uncompiled.**

Reviewer: book_scope_review. Source author: reflection_evidence_review.
All seventeen public theorems, three private operational helpers and four
definitions were read against the selected actual cached implementation and
the existing Stable/Literal interfaces. SOURCE-AUDIT.json binds 26 direct
inputs. All 205 author-inventory byte counts and hashes and all fifteen
retained primary-source intervals were checked.

## Exact source and dependency boundary

The new source is 20,026 bytes, SHA-256
9488897da7437e42f71e9bdc31f60dba491bf5c347571bff50a41d1dd41b53ca.
It imports only KernelCachedLiteralForward and retains the usual strict
autoImplicit, warning and asynchronous-elaboration settings. All seventeen
public declarations have exact ordered report commands.

The literal dependency retains its separate sixteen-input independent
review. The cached proof-sharing owner and observer-restored Core retain
their separate reviews and exact overlay maps. This review does not rebase
those scopes or independently re-review every unrelated declaration in
their complete files.

The author's frozen inventory described the 120-report context before its
execution. Since that inventory froze, root executed that complete gate:
the Core, Cached, Stable and Helper prefix accepted 71 reports, then Syntax
hit the common wall-time deadline. The complete attempt failed at
30.255617265000183 seconds; it accepted neither BulkBound nor LiteralForward.
Its report and permanent marker are new direct context inputs to this
review. The old inventory's historical pending status is left unchanged.
Arithmetic was not part of that attempt and receives no compiled
acceptance from it.

The prospective addition has eight physical modules, 34 logical origins,
137 reports, sixteen ordinary outputs and 658,570 source bytes. These are
source-selection counts. They establish no fresh acceptance or resource
fit, and this review authorizes no unchanged retry of the failed closure.

## Recognition and the actual primitive guard

NatBinaryName copies the fourteen-name disjunction in the original binary
reduceNatI branch. Its order and names match addition, subtraction,
multiplication, power, equality and inequality comparisons, division,
modulus, gcd, land, lor, xor and the two shifts. The unary successor and
predecessor cases are not silently added to this binary theorem.

The actual operator has an empty universe-argument list. Its storage guard
is exactly natOpStoredF fe operator = true. The source derives an actual
indexed lookup witness for a .defnInfo entry from that guard. It does not
replace the guard with the stronger semantic natOpGuardF predicate or add
natLitSupportedF, which this particular executable branch does not test.

The same definition lookup excludes the actual recursor-info case in
iotaArityOk. Both application-spine prefixes therefore reject iota. This
justification uses the actual indexed environment; it does not identify
fe.env with the driver's visible prefix or claim an environment is valid.

The result equation is the actual natOpResult equation. Its exponent cutoff
and all other operation definitions remain unchanged. In particular, when
natOpResult returns none the theorem cannot supply a primitive result;
the later definition-unfolding behavior is not bypassed. No concrete queen
count or expected-count equality appears as a premise.

## Actual left-to-right state sequence

reduce_nat_binary expands the real binary clause, not a model of it.
The first callback returns a literal and afterLeft; rawNatLitC? is then
checked on that actual returned expression. Only behind that successful
literal check does the second callback run, using afterLeft. Its literal
check and the actual natOpResult equation lead to the stated result with
the second callback's final state.

The proof's explicit equations preserve the original order. No independent
initial state is supplied to the right operand, no callback result is
discarded, and no arbitrary state equality replaces a returned state.
The SDK StateT.bind and StateT.pure definitions were checked as part of this
review: bind passes the returned state onward, while pure retains the
supplied state.

## Constant head and application spine

The pure constant-head equation holds at positive knot fuel for arbitrary
mode, environment, depth, name and universe arguments. Its head branch
performs no definition lookup. That supplies the stable pure backing for
a constant without an environment-validity premise.

The actual cached constant body also returns the constant without a
callback or body-state change. cached_head_const uses the existing
head-forward lifting theorem: a memo hit is identified by stable uniqueness;
a miss uses the concrete body equation, then performs the actual head-map
insertion. StableNF and the explicit auxiliary MemoFrame are retained.

The two private application helpers expand the real whnfAppI iterations
for a constant and then an application. The stored-definition witness
rejects iota in both. Neither argument is normalized at this head stage,
and the continuation is not called. whnf_app_binary consequently leaves
the original two-argument application intact.

head_body_binary_of_const follows the actual head body's spine extraction,
one constant-head callback and those two spine iterations. It uses exactly
the state returned by the constant-head callback. cached_head_binary then
handles the outer application's real hit or miss at knot fuel fuel + 2.
Its supplied StableHead witness and query-scoping premise remain explicit;
this source does not derive that witness for an arbitrary environment.

## Finishing the primitive result

PrimitiveResult permits a natural literal or a constant with an explicit
NoDefinition premise about the actual indexed lookup. Natural literals need
no constant lookup. For constant results, NoDefinition excludes every
.defnInfo witness, so actual unfoldDefinitionI returns none and invokes
neither the cached value helper nor a continuation.

The actual natOpResult uses Boolean constants for its two Boolean-valued
operations. The stated NoDefinition condition is sufficient for their
terminal full-loop behavior. It is an operational condition, not a theorem
that a Boolean constructor has been installed or that the environment is
valid. Missing or other non-definition entries can also satisfy it.

cached_head_result uses the concrete literal or constant head theorem.
full_loop_result_of_head expands the real terminal iteration using the
head callback's returned state. The result-map invariant is preserved;
the theorem does not assert that a miss leaves the normal-form maps
unchanged.

## The final actual cached theorem

full_loop_binary_of_runs composes two actual local full-loop iterations:
one performs the application head call and binary primitive; the next
normalizes and finishes the primitive result. The states are state,
afterHead, afterLeft, afterRight and the result-head callback's final state,
in that order. Its body proof uses the actual callbacks' supplied equations.

cached_full_binary discharges the final miss-body obligation. It invokes
cached_head_binary, then the left operand's actual success/preservation
premise on afterHead, then the right premise on the returned afterLeft.
It finally invokes the concrete result-head theorem on afterRight and
uses the proved two-iteration loop equation. The outer full memo lifting
theorem supplies either validated hit success or the original insertion
on a miss.

The final theorem does not assume success of its own miss body. Its remaining
recursive success premises are exactly the operand calls, quantified over
each supplied StableNF and auxiliary-valid state. Pure stable head and
full backing, the actual query scope, the initial StableNF assertion,
the auxiliary predicate and its MemoFrame remain visible premises.
These must be supplied by the eventual query and driver argument; no
one-way simulation is inverted.

The knot fuel offsets are consistent: application head at fuel + 2,
full normalization at fuel + 3, and both operand callbacks and the result
head at fuel + 2. The constant-head callback inside the application head
uses fuel + 1. These are separate from the unchanged local head-loop
constant 1000000 and full-loop constant 100000. The displayed successor
decompositions expose one and two positive iterations respectively;
no fuel definition, resource option or recursion limit changes.

## Limits and next acceptance work

This leaf provides a compositional actual arithmetic step and additional
constant base cases. It establishes no global cache invariant from an
arbitrary initial record state, no helper-cache initialization, no
intervening-record preservation, and no relation between the selected
indexed environment and the actual visible prefix. Its independently
supplied pure environment is not silently equated with either.

The final query induction, actual installed annotations and ProgramPins,
true-prefix EnvWF, original GroupChecked and stock numeral theorem remain
open. The accepted 71-report prefix of the failed larger attempt is useful
evidence for those exact modules, but it does not validate this new leaf
or its uncompiled Literal dependency. A later complete selection needs
substantive source-cost work and fresh acceptance under the unchanged
30-second policy; no fit is inferred from these source proofs.

No compiler, preflight, gate, exporter, evaluator, native mathematical
program, profiler, retained generator or saved-evidence-reader script was
executed by this reviewer. The review used source reads, exact text and
identity comparisons, JSON reads and cryptographic hashing.
