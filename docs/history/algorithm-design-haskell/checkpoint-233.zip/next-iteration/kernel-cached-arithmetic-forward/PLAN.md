# Actual cached forward arithmetic after the 120-report selection

Status: a new source candidate after the frozen 120-report selection. No Lean
compilation, theorem acceptance, gate execution or timing result is claimed.
All previously selected sources, source reviews, inventories and gates remain
unchanged. This module imports only the reviewed, still-uncompiled
`KernelCachedLiteralForward` leaf.

## Result and remaining premises

`cached_full_binary` proves the original memoizing full reducer succeeds from
every supplied `StableNF` state on a recognized binary Nat application. It
preserves `StableNF` and any supplied auxiliary state predicate whose
`MemoFrame` proves preservation under the two actual NF-map writes.

The recursive premises are actual success and preservation for the left and
right operand calls, at the stated predecessor knot fuel, from every supplied
valid state. The theorem invokes the right premise on the state actually
returned by the left call. It also needs the existing pure stable backing for
the complete application's head result and full result, and the actual scope
fact required to validate memo hits. Those premises remain visible and must
be discharged by the later query induction.

No final primitive theorem assumes success of its miss body. The source
proves the constant-head call, both non-recursor spine iterations, the actual
binary primitive, and the final result loop step. It does not infer cached
success from pure success or from simulation.

## Exact operation set and guard

`NatBinaryName` copies the actual fourteen-name disjunction from `reduceNatI`:

| Family | Exact names |
| --- | --- |
| Ordinary Nat arithmetic | `natAddName`, `natSubName`, `natMulName`, `natPowName`, `natDivName`, `natModName`, `natGcdName` |
| Boolean comparisons | `natBeqName`, `natBleName` |
| Bit operations | `natLandName`, `natLorName`, `natXorName`, `natShiftLeftName`, `natShiftRightName` |

The operator has no universe arguments, exactly as in the selected binary
branch. The real guard is `natOpStoredF fe operator = true`: the actual indexed
lookup must hold a definition. `stored_definition` recovers that precise
lookup witness. It also proves both application-spine prefixes fail the real
`iotaArityOk` recursor test. No additional `natOpGuardF` or
`natLitSupportedF` premise is silently imposed on this branch.

The result premise is the actual equation

`natOpResult operator leftNumber rightNumber = some value`.

It is not an arbitrary expected-number premise. The original computation
still determines the value, including natural subtraction/division/modulus,
bit operations, and the exponent cutoff of `Nat.pow`. A caller cannot use
this primitive-result theorem when the actual `natOpResult` returns `none`;
that case belongs to the definition-unfolding path. No numerical claim about
`cqueens 16` is supplied or assumed by this leaf.

Nat-valued results are terminal literals without any constant lookup.
Boolean-valued results are constant expressions. For those, the explicit
`NoDefinition fe resultName` premise ensures that the final full-loop step
does not unfold the selected Boolean constant. The predicate quantifies over
actual `.defnInfo` lookup witnesses; a stored Boolean constructor can supply
it directly. Missing or other non-definition entries also satisfy this
operational condition, so this predicate is not an environment-validity or
installation theorem. It does not claim those broader properties.

## Actual state and fuel order

The complete miss path performs these calls in order:

| Step | Actual call | State passed onward |
| --- | --- | --- |
| Head application | Head-normalize the original binary application; its constant head is normalized once, then two non-recursor spine steps leave both arguments unchanged. | `afterHead` |
| Left operand | The real full-WHNF callback on `left`, returning a Nat literal. | `afterLeft` |
| Right operand | The same callback on `right`, starting at `afterLeft`, returning a Nat literal. | `afterRight` |
| Primitive result | Apply the original `natOpResult`; this part performs no state update. | `afterRight` |
| Result head and terminal step | The real head callback on the resulting literal or non-definition constant, then the actual full-loop terminal branch. | The result-head call's final state |
| Outer full memo | Insert the complete query/result pair under the actual expression key if the outer full cache missed. | The final returned state |

The head theorem uses `coreKnotI mode fe (fuel + 2)`. Its constant-head call
uses the predecessor knot at `fuel + 1`. The full theorem uses
`coreKnotI mode fe (fuel + 3)`; its actual head, left, right and result-head
callbacks all use `fuel + 2`.

These knot levels are distinct from the original local iteration budgets.
Head processing uses one positive head-loop iteration from the unchanged
`whnfCoreLoopFuel = 1000000`. Full arithmetic needs two iterations from the
unchanged `whnfLoopFuel = 100000`: one computes the primitive and the next
finishes its result. The source explicitly uses `999999 + 1` and
`99998 + 2` only to expose those existing positive budgets. It changes no
fuel constant, recursion limit, heartbeat limit or resource control.

The outer and head memo-hit paths use the already reviewed stable-cache
uniqueness lemmas. Their conclusions need the supplied pure stable witnesses
and real scope fact; the invariant is not silently extended to other cached
fields. Taking the auxiliary predicate to be `HelperCache fe` is possible
using its independently proved memo-frame theorem, but this arithmetic leaf
does not import or invoke a helper-cache tower.

## Source scope

The module contains four proposition/expression definitions, seventeen public
theorems and three private operational proof helpers. Every public theorem has
an explicit axiom-report command. Its direct dependencies are the actual
cached `natOpStoredF`, `iotaArityOk`, `reduceNatI`, `whnfAppI`,
`whnfCoreStepI`/`whnfCoreLoopI`, `whnfStepI`/`whnfLoopI` and `coreKnotI`
definitions, together with the stable-cache and literal-forward interfaces.

The future complete selection must bind this source and its independent
review as an addition to the current 120-report selection. The prospective
total is eight physical modules, 34 ownership origins, 137 public reports
and sixteen default `.olean`/`.ilean` artifacts. This is a source census,
not an assertion that the larger closure fits the fixed budget.

Independent review and a complete fresh gate remain necessary. The same
cumulative 30-second, one-CPU, one-thread, 1-GiB, strict-default and three-axiom
controls apply, with root as the only executor and no prepared experimental
objects. The later query induction, visible-prefix agreement, record-state
initialization and intervening actions, annotation and installation validity,
prefix `EnvWF`, record acceptance, `GroupChecked` and the stock numeral theorem
remain unfinished by this leaf.
