import KernelCachedLiteralForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual cached forward steps for the fourteen binary Nat primitives

Source candidate only. The final theorem proves the original full knot's
miss body by following the actual constant head, two non-recursor spine
prefixes, left-then-right recursive calls, natOpResult and the result loop.
Its premises are actual recursive operand success/preservation and pure
stable backing; no miss-body-success premise or simulated-success inversion
is used. Every state is the state returned by the preceding actual call.

The actual binary guard only asks that the operator is stored as a definition.
No stronger natOpGuardF or natLitSupportedF premise is inserted. Bool results
add an explicit non-definition lookup premise on their result constant so the
last full-loop step is terminal. Nat literal results need no such lookup.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedArithmeticForward

open ConLeche
open ConLeche.Cached
open KernelCachedStableForward
open KernelCachedLiteralForward

/-- Exactly the disjunction tested by the original binary reduceNatI arm. -/
def NatBinaryName (operator : Name) : Prop :=
  operator = natAddName ∨ operator = natSubName ∨ operator = natMulName ∨
  operator = natPowName ∨ operator = natBeqName ∨ operator = natBleName ∨
  operator = natDivName ∨ operator = natModName ∨ operator = natGcdName ∨
  operator = natLandName ∨ operator = natLorName ∨ operator = natXorName ∨
  operator = natShiftLeftName ∨ operator = natShiftRightName

def binaryApplication (operator : Name) (left right : Expr) : Expr :=
  .app (.app (.const operator []) left) right

/-- A full-loop constant result may not unfold as a definition. This is a
predicate of the actual indexed lookup, not of an assumed environment prefix. -/
def NoDefinition (fe : FEnv) (name : Name) : Prop :=
  ∀ (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint),
    fe.find? name ≠ some (.defnInfo constant body hint)

/-- The actual primitive results are Nat literals or Bool constants. The
constant form states the lookup condition needed to finish the full loop. -/
def PrimitiveResult (fe : FEnv) (value : Expr) : Prop :=
  (∃ number, value = natLiteral number) ∨
  ∃ name levels, value = .const name levels ∧ NoDefinition fe name

theorem primitive_result_nat (fe : FEnv) (number : Nat) :
    PrimitiveResult fe (natLiteral number) := Or.inl ⟨number, rfl⟩

theorem primitive_result_const (fe : FEnv) (name : Name) (levels : List Level)
    (notDefinition : NoDefinition fe name) :
    PrimitiveResult fe (.const name levels) :=
  Or.inr ⟨name, levels, rfl, notDefinition⟩

/-- The executable guard implies an actual definition lookup witness. -/
theorem stored_definition (fe : FEnv) (operator : Name)
    (stored : natOpStoredF fe operator = true) :
    ∃ constant body hint, fe.find? operator = some (.defnInfo constant body hint) := by
  cases found : fe.find? operator with
  | none => simp [natOpStoredF, found] at stored
  | some info =>
    cases info <;> simp_all [natOpStoredF]

/-- A stored primitive definition cannot pass the actual recursor pre-check,
at either of its two application-spine prefixes. -/
theorem stored_head_no_iota (fe : FEnv) (operator : Name) (expression : Expr)
    (head : Expr.getAppFn expression = .const operator [])
    (stored : natOpStoredF fe operator = true) :
    iotaArityOk fe expression = false := by
  obtain ⟨constant, body, hint, found⟩ := stored_definition fe operator stored
  unfold iotaArityOk
  rw [head, found]

/-- The actual binary primitive calls its first operand, checks the literal,
and calls its second operand from the first call's returned state. -/
theorem reduce_nat_binary (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (operator : Name) (left right : Expr) (leftNumber rightNumber : Nat)
    (value : Expr) (state afterLeft final : CState)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (leftRun : callbacks.whnf depth left state =
      .ok (.lit (.natVal leftNumber), afterLeft))
    (rightRun : callbacks.whnf depth right afterLeft =
      .ok (.lit (.natVal rightNumber), final))
    (computed : natOpResult operator leftNumber rightNumber = some value) :
    reduceNatI callbacks fe depth (binaryApplication operator left right) state =
      .ok (some value, final) := by
  have enabled : NatBinaryName operator ∧ natOpStoredF fe operator = true :=
    ⟨recognized, stored⟩
  change reduceNatI callbacks fe depth
    (.app (.app (.const operator []) left) right) state = _
  simp only [reduceNatI, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.bind, ite_eq_left enabled, leftRun,
    rawNatLitC?, rightRun, computed]
  all_goals rfl

theorem pure_head_const (mode : CheckMode) (environment : Env)
    (fuel depth : Nat) (name : Name) (levels : List Level) :
    whnfCore mode environment (fuel + 1) depth (.const name levels) =
      .ok (.const name levels) := by
  rfl

theorem stable_head_const (mode : CheckMode) (environment : Env)
    (name : Name) (levels : List Level) :
    StableHead mode environment (.const name levels) (.const name levels) := by
  refine ⟨1, ?_⟩
  intro fuel depth large _
  cases fuel with
  | zero => omega
  | succ rest => exact pure_head_const mode environment rest depth name levels

theorem head_body_const (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (cheap : Bool) (depth : Nat) (name : Name)
    (levels : List Level) (state : CState) :
    whnfCoreBodyI mode callbacks fe cheap depth (.const name levels) state =
      .ok (.const name levels, state) := by
  unfold whnfCoreBodyI whnfCoreLoopFuel
  rfl

theorem cached_head_const (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (name : Name) (levels : List Level)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (state : CState) (valid : StableNF mode environment state)
    (auxValid : auxiliary state) :
    ∃ final, (coreKnotI mode fe (fuel + 1)).whnfCore false depth
        (.const name levels) state = .ok (.const name levels, final) ∧
      StableNF mode environment final ∧ auxiliary final := by
  apply head_forward_of_body mode environment fe fuel depth
    (.const name levels) (.const name levels) auxiliary frame
    (stable_head_const mode environment name levels) rfl state valid auxValid
  intro _
  exact ⟨state, head_body_const mode (coreKnotI mode fe fuel) fe false depth
    name levels state, valid, auxValid⟩

private theorem app_const_step (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (operator : Name) (argument : Expr) (rest : List Expr)
    (noIota : iotaArityOk fe (.app (.const operator []) argument) = false) :
    whnfAppI mode callbacks fe depth next (.const operator []) (argument :: rest) =
      whnfAppI mode callbacks fe depth next (.app (.const operator []) argument) rest := by
  rw [whnfAppI.eq_def]
  simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.bind, noIota]
  all_goals rfl

private theorem app_app_step (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (function left right : Expr) (rest : List Expr)
    (noIota : iotaArityOk fe (.app (.app function left) right) = false) :
    whnfAppI mode callbacks fe depth next (.app function left) (right :: rest) =
      whnfAppI mode callbacks fe depth next (.app (.app function left) right) rest := by
  rw [whnfAppI.eq_def]
  simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.bind, noIota]
  all_goals rfl

/-- Both original spine iterations reject iota and leave the arguments intact.
The supplied continuation is never called on this path. -/
theorem whnf_app_binary (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (operator : Name) (left right : Expr)
    (stored : natOpStoredF fe operator = true) :
    whnfAppI mode callbacks fe depth next (.const operator []) [left, right] =
      pure (binaryApplication operator left right) := by
  have first := stored_head_no_iota fe operator
    (.app (.const operator []) left) rfl stored
  have second := stored_head_no_iota fe operator
    (binaryApplication operator left right) rfl stored
  rw [app_const_step mode callbacks fe depth next operator left [right] first]
  rw [app_app_step mode callbacks fe depth next (.const operator []) left right [] second]
  rw [whnfAppI.eq_def]

/-- The actual head body normalizes the constant head once, then runs those
two spine iterations using the head call's returned state. -/
theorem head_body_binary_of_const (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (operator : Name) (left right : Expr)
    (state final : CState) (stored : natOpStoredF fe operator = true)
    (headRun : callbacks.whnfCore false depth (.const operator []) state =
      .ok (.const operator [], final)) :
    whnfCoreBodyI mode callbacks fe false depth
      (binaryApplication operator left right) state =
      .ok (binaryApplication operator left right, final) := by
  change whnfCoreLoopI mode callbacks fe false depth whnfCoreLoopFuel
    (binaryApplication operator left right) state = _
  have budgetEq : whnfCoreLoopFuel = 999999 + 1 := by
    unfold whnfCoreLoopFuel
    rfl
  rw [budgetEq]
  change whnfCoreStepI mode callbacks fe false depth
    (whnfCoreLoopI mode callbacks fe false depth 999999)
    (.app (.app (.const operator []) left) right) state = _
  simp only [whnfCoreStepI, Expr.getAppFn,
    Expr.getAppArgsC, Expr.getAppArgsAccC, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.bind, headRun,
    whnf_app_binary mode callbacks fe depth
      (whnfCoreLoopI mode callbacks fe false depth 999999) operator left right stored]
  all_goals rfl

/-- Head normalization of the binary application itself: two knot levels,
including either actual head-cache branch at both calls. -/
theorem cached_head_binary (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (operator : Name) (left right : Expr)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (stored : natOpStoredF fe operator = true)
    (backing : StableHead mode environment (binaryApplication operator left right)
      (binaryApplication operator left right))
    (queryScoped : Expr.wscopedB depth (binaryApplication operator left right) = true)
    (state : CState) (valid : StableNF mode environment state)
    (auxValid : auxiliary state) :
    ∃ final, (coreKnotI mode fe (fuel + 2)).whnfCore false depth
        (binaryApplication operator left right) state =
        .ok (binaryApplication operator left right, final) ∧
      StableNF mode environment final ∧ auxiliary final := by
  apply head_forward_of_body mode environment fe (fuel + 1) depth
    (binaryApplication operator left right) (binaryApplication operator left right)
    auxiliary frame backing queryScoped state valid auxValid
  intro _
  obtain ⟨final, run, finalValid, finalAux⟩ :=
    cached_head_const mode environment fe fuel depth operator []
      auxiliary frame state valid auxValid
  exact ⟨final, head_body_binary_of_const mode (coreKnotI mode fe (fuel + 1))
    fe depth operator left right state final stored run, finalValid, finalAux⟩

private theorem unfold_const_none (fe : FEnv) (name : Name)
    (levels : List Level) (notDefinition : NoDefinition fe name) (state : CState) :
    unfoldDefinitionI fe (.const name levels) state = .ok (none, state) := by
  cases found : fe.find? name with
  | none =>
    simp only [unfoldDefinitionI, Expr.getAppFn, Bind.bind, StateT.bind,
      pure, StateT.pure, Except.bind, found]
    all_goals rfl
  | some info =>
    cases info with
    | defnInfo constant body hint =>
      exact False.elim (notDefinition constant body hint found)
    | _ =>
      simp only [unfoldDefinitionI, Expr.getAppFn, Bind.bind, StateT.bind,
        pure, StateT.pure, Except.bind, found]
      all_goals rfl

/-- A non-definition constant is terminal for the actual full loop after its
real head call. No constant-value helper is invoked. -/
theorem full_loop_const_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (name : Name) (levels : List Level)
    (state final : CState) (notDefinition : NoDefinition fe name)
    (headRun : callbacks.whnfCore false depth (.const name levels) state =
      .ok (.const name levels, final)) :
    whnfLoopI callbacks fe depth (budget + 1) (.const name levels) state =
      .ok (.const name levels, final) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget)
    (.const name levels) state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind, reduceNatI,
    pure, StateT.pure, unfold_const_none fe name levels notDefinition final]
  all_goals rfl

theorem cached_head_result (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (value : Expr)
    (resultForm : PrimitiveResult fe value)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (state : CState) (valid : StableNF mode environment state)
    (auxValid : auxiliary state) :
    ∃ final, (coreKnotI mode fe (fuel + 1)).whnfCore false depth value state =
        .ok (value, final) ∧ StableNF mode environment final ∧ auxiliary final := by
  rcases resultForm with ⟨number, rfl⟩ | ⟨name, levels, rfl, _notDefinition⟩
  · exact cached_head_nat mode environment fe fuel depth number
      auxiliary frame state valid auxValid
  · exact cached_head_const mode environment fe fuel depth name levels
      auxiliary frame state valid auxValid

theorem full_loop_result_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (value : Expr) (state final : CState)
    (resultForm : PrimitiveResult fe value)
    (headRun : callbacks.whnfCore false depth value state = .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 1) value state = .ok (value, final) := by
  rcases resultForm with ⟨number, rfl⟩ | ⟨name, levels, rfl, notDefinition⟩
  · exact full_loop_nat_of_head callbacks fe depth budget number state final headRun
  · exact full_loop_const_of_head callbacks fe depth budget name levels state final
      notDefinition headRun

/-- Two actual local-loop iterations, with every intermediate state visible. -/
theorem full_loop_binary_of_runs (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (operator : Name) (left right : Expr)
    (leftNumber rightNumber : Nat) (value : Expr)
    (state afterHead afterLeft afterRight final : CState)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (computed : natOpResult operator leftNumber rightNumber = some value)
    (resultForm : PrimitiveResult fe value)
    (headRun : callbacks.whnfCore false depth
      (binaryApplication operator left right) state =
      .ok (binaryApplication operator left right, afterHead))
    (leftRun : callbacks.whnf depth left afterHead =
      .ok (.lit (.natVal leftNumber), afterLeft))
    (rightRun : callbacks.whnf depth right afterLeft =
      .ok (.lit (.natVal rightNumber), afterRight))
    (resultHeadRun : callbacks.whnfCore false depth value afterRight =
      .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 2)
      (binaryApplication operator left right) state = .ok (value, final) := by
  have primitiveRun := reduce_nat_binary callbacks fe depth operator left right
    leftNumber rightNumber value afterHead afterLeft afterRight recognized stored
    leftRun rightRun computed
  have finishRun := full_loop_result_of_head callbacks fe depth budget value
    afterRight final resultForm resultHeadRun
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth (budget + 1))
    (binaryApplication operator left right) state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind, primitiveRun]
  all_goals exact finishRun

/-- Concrete original full-knot primitive execution from every supplied valid
state. The only recursive-success premises are the actual left and right
operand calls at the stated predecessor knot fuel. Both miss bodies, the
constant head, iota rejection and final result step are proved above. -/
theorem cached_full_binary (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (operator : Name) (left right : Expr)
    (leftNumber rightNumber : Nat) (value : Expr)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (computed : natOpResult operator leftNumber rightNumber = some value)
    (resultForm : PrimitiveResult fe value)
    (headBacking : StableHead mode environment (binaryApplication operator left right)
      (binaryApplication operator left right))
    (fullBacking : StableWhnf mode environment (binaryApplication operator left right) value)
    (queryScoped : Expr.wscopedB depth (binaryApplication operator left right) = true)
    (leftSuccess : ∀ before, StableNF mode environment before → auxiliary before →
      ∃ after, (coreKnotI mode fe (fuel + 2)).whnf depth left before =
          .ok (.lit (.natVal leftNumber), after) ∧
        StableNF mode environment after ∧ auxiliary after)
    (rightSuccess : ∀ before, StableNF mode environment before → auxiliary before →
      ∃ after, (coreKnotI mode fe (fuel + 2)).whnf depth right before =
          .ok (.lit (.natVal rightNumber), after) ∧
        StableNF mode environment after ∧ auxiliary after)
    (state : CState) (valid : StableNF mode environment state)
    (auxValid : auxiliary state) :
    ∃ final, (coreKnotI mode fe (fuel + 3)).whnf depth
        (binaryApplication operator left right) state = .ok (value, final) ∧
      StableNF mode environment final ∧ auxiliary final := by
  apply whnf_forward_of_body mode environment fe (fuel + 2) depth
    (binaryApplication operator left right) value auxiliary frame fullBacking
    queryScoped state valid auxValid
  intro _
  obtain ⟨afterHead, headRun, headValid, headAux⟩ :=
    cached_head_binary mode environment fe fuel depth operator left right
      auxiliary frame stored headBacking queryScoped state valid auxValid
  obtain ⟨afterLeft, leftRun, leftValid, leftAux⟩ :=
    leftSuccess afterHead headValid headAux
  obtain ⟨afterRight, rightRun, rightValid, rightAux⟩ :=
    rightSuccess afterLeft leftValid leftAux
  obtain ⟨final, resultHeadRun, finalValid, finalAux⟩ :=
    cached_head_result mode environment fe (fuel + 1) depth value resultForm
      auxiliary frame afterRight rightValid rightAux
  refine ⟨final, ?_, finalValid, finalAux⟩
  change whnfLoopI (coreKnotI mode fe (fuel + 2)) fe depth whnfLoopFuel
    (binaryApplication operator left right) state = _
  have budgetEq : whnfLoopFuel = 99998 + 2 := by
    unfold whnfLoopFuel
    rfl
  rw [budgetEq]
  all_goals exact full_loop_binary_of_runs (coreKnotI mode fe (fuel + 2)) fe
    depth 99998 operator left right leftNumber rightNumber value state afterHead
    afterLeft afterRight final recognized stored computed resultForm
    headRun leftRun rightRun resultHeadRun

#print axioms primitive_result_nat
#print axioms primitive_result_const
#print axioms stored_definition
#print axioms stored_head_no_iota
#print axioms reduce_nat_binary
#print axioms pure_head_const
#print axioms stable_head_const
#print axioms head_body_const
#print axioms cached_head_const
#print axioms whnf_app_binary
#print axioms head_body_binary_of_const
#print axioms cached_head_binary
#print axioms full_loop_const_of_head
#print axioms cached_head_result
#print axioms full_loop_result_of_head
#print axioms full_loop_binary_of_runs
#print axioms cached_full_binary

end ADWH.Experiments.Chapter15.KernelCachedArithmeticForward
