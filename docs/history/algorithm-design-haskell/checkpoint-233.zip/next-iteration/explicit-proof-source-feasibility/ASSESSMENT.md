# Explicit proof source for ConsolidatedGeneric: source-only assessment

24 October 2026. No Lean process, exporter, checker, counter or proof-generation
program was run for this assessment. Existing sources, controls and attempts
remain unchanged. The page-composed cache gate remains the active experiment.

## Decision

**Freshly checking generated proof text is legitimate in principle, but a
wholesale replay of `ConsolidatedGeneric` is not a justified next experiment.**
The pinned toolchain has the ingredients for retrieving complete kernel
expressions, but no reviewed turnkey conversion from those expressions to a
source-preserving replacement module. The narrower possible route is to retain
the original declarations and replace selected tactic proof bodies with explicit
terms. That route still needs an actual reason to expect useful savings.

The accepted baseline measured 7.280312506 seconds for the entire Generic
compilation. This includes more than tactic elaboration; the report does not
separate parsing, elaboration, kernel checking, printing or other costs. Copying
the same proof term leaves its kernel checking and reduction obligations in
place. Larger explicit terms can also add parsing, elaboration and memory cost.
There is no current evidence that this change would save the required time or
improve n16 scaling. [B1]

## What the pinned facilities actually provide

`LeanExport.Basic` serializes names, universe levels, expression nodes, theorem
types and theorem values, and recursively visits their used constants. Shared
expression nodes have indices. The reader returns an ordinary constant map and
explicitly does not add anything to a trusted environment. This is a suitable
*untrusted certificate representation*, not a proof acceptance result. By
default the writer removes expression metadata and normalizes the let-expression
`nonDep` optimization flag; a byte-identity claim about raw expressions would
need to account for that normalization. [S1, S2]

Exporting only the 224 printed Generic roots would not, by itself, promise to
reconstruct every declaration of the module. Export follows dependencies of the
requested roots; its default root list excludes internal names unless reached as
dependencies. A module-preserving transformation needs the exact local declaration
inventory, including otherwise-unused declarations which the current source
still checks. The theorem print inventory and the full declaration inventory
serve different purposes. [S1, B2]

The built-in `Lean.Kernel.Environment.replay` reconstructs declarations from
`ConstantInfo`, orders dependencies, sends them to the kernel, and validates
constructors and recursors against the reconstructed inductives. These are useful
primary examples of how to handle the dependency boundary. They do not make the
stock replay command a replacement for our source gate. Its checked-add call is
`addDeclCore 0 0`, instead of the ordinary option-derived limits; zero denotes no
internal heartbeat or recursion-depth limit. It can also skip an already-present
theorem when its declaration metadata matches. Such behavior must not be confused
with freshly checking every local theorem body in the proposed closure. [S3, S4]

`leanchecker --from-export` starts with an empty kernel environment and replays
the supplied constant map. Its purpose is rechecking, and it does not produce a
normal replacement `.olean` with the original elaborator extensions for the
later Arithmetic and Source compilations. A successful external recheck cannot
be used as a premise for those modules. Importing the old experimental object
and then printing or replaying some of it would also violate the requested fresh
source boundary. [S5]

## Why a printed module is not an adequate recovery artifact

The delaborator's own documentation says that `pp.all` *should* make term
delaboration injective and permit round-tripping. That supports trying complete
term output; it is not a claim that concatenated `#print` messages reproduce a
module. The default pretty printer hides proofs and deep terms, while the
independent `pp.maxSteps` default is 5000 even with `pp.all`. The delaborator emits
an omission when that limit is reached. `#print` has declaration-specific display
forms, can show a body as unavailable, and does not serialize every source
attribute or environment extension. Its inductive display is explanatory output,
not the original inductive command. [S6, S7]

The actual Generic source contains private decidability instances, private
theorems, derived `DecidableEq` instances, a well-founded recursive `nodeMeaning`,
inductives, structures and simp attributes. Lean's private names include the
module name, and match elaboration can create auxiliary declarations. A proof
body may mention such auxiliaries even when they were not written explicitly in
the original body. Replacing a body removes the elaboration that previously
created its auxiliaries. Renaming the module changes private names as well.
Consequently, an exporter would have to classify dependencies as one of: retained
source declarations; regenerated auxiliaries of those declarations; explicit new
proof auxiliaries; or allowed original/runtime imports. That classification has
not been carried out, and no auxiliary count is inferred from the 224 prints.
[B2, S8]

Whole-module constant replay also loses the source commands which populate simp,
instance, equation, structure and name-resolution metadata. Even if the kernel
constants are sound, later source elaboration is a separate requirement. Retaining
the original executable declarations and their attributes is the simpler way to
preserve this behavior; recreating all extensions would be a new infrastructure
project. [B2, S3, S7]

## The only defensible later form

If a future source-level reason identifies a small expensive tactic body, a
certificate-to-source change could satisfy the current trust boundary as follows:

1. Preserve the original module name, imports, executable declarations, theorem
   headers, attributes and final source endpoint. Record exact proof-body edits
   and an inverse that restores the accepted source bytes.
2. Treat any accepted object used to obtain a proof as generation-time input
   only. Pin its source provenance and retain the resulting complete certificate
   text; recovery and the fresh mathematical gate must not depend on that old
   object's presence or prior acceptance.
3. Include every needed local proof auxiliary, with explicit names, types,
   universe parameters and bodies. Keep a complete dependency inventory and
   forbid new axioms, undeclared external constants or hidden experimental
   imports. Shared certificate nodes need a deliberate representation, rather
   than silently duplicating a potentially large proof graph as text.
4. Elaborate each supplied term against the **unchanged source proposition** and
   add the resulting theorem through the ordinary checked declaration path under
   the default options. A proof of an exported type chosen by the exporter is not
   sufficient evidence that the original source statement was preserved.
5. Freshly compile the complete new mathematical closure in the single existing
   budget. Preserve the exact source and axiom inventories and subsequent
   Arithmetic/Source endpoint checks. No old experimental object, success flag,
   unchecked insertion or replay-specific limit override belongs in that gate.

This would be ordinary proof-source reuse, like writing down a proof found by a
tactic, not reuse of its earlier checking result. The normal `Lean.addDecl` path
provides the kernel check, but its existence does not certify a custom generator
or environment loader: those must remain untrusted and unable to replace the
source proposition or insert unchecked constants. [S9]

**Recommendation:** retain this possibility as deferred, reject wholesale
`#print`/replay substitution now, and do not start an export or a benchmark on its
basis. The present evidence supports neither an implementation shortcut nor a
performance claim. The current page-composed cache experiment changes actual
proof organization and should be resolved first.

## Sources and recovery

All Lean source references below were read from the installed pinned Lean 4.35
distribution, commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. Exact local paths,
SHA256 hashes and corresponding primary URLs are recorded in
`SOURCE-INVENTORY.json`. This is a source-only evidence inventory, not a proof
manifest. No new proof artifact was created.

- **B1:** [Accepted baseline full report](../legacy-list-clause-compatibility/count-migration/attempts/full-01/report.json),
  SHA256 `bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa`.
  Its separately disclosed generic-pointer defect is described in the
  [provenance addendum](../legacy-list-clause-compatibility/count-migration/GENERIC-PROVENANCE-ADDENDUM.md);
  this note uses the actual full report's fresh module measurement.
- **B2:** [Baseline Generic source](../legacy-list-clause-compatibility/count-migration/source/ConsolidatedGeneric.lean),
  SHA256 `74169d839843ddf553610be8a458e67dc337d8eaec8dc7afda3ab5319cff3e68`.
  Relevant source anchors: `nodeMeaning` and its termination proof; private
  decidability instances; `deriving DecidableEq`; simp theorem declarations.
- **S1:** [LeanExport.Basic](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/LeanExport/Basic.lean),
  `State`, `getIdx`, `removeMData`, `dumpExprAux`, `dumpConstant`, `dumpEnv`.
- **S2:** [LeanExport.Parse](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/LeanExport/Parse.lean),
  file documentation, `ExportedEnv`, `parseStream`.
- **S3:** [Lean.Replay](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/Replay.lean),
  `Replay.addDecl`, `replayConstant`, constructor/recursor post-checks, `replay`.
- **S4:** [CoreM](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/CoreM.lean),
  `maxHeartbeats` and `getMaxHeartbeats`;
  [RecDepth](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/Util/RecDepth.lean),
  `maxRecDepth`.
- **S5:** [LeanChecker](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/LeanChecker.lean),
  `checkExport`, `replayFromImports`, `replayFromFresh`, `main`.
- **S6:** [Delaborator.Basic](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/PrettyPrinter/Delaborator/Basic.lean),
  introductory round-trip comment, `OmissionReason`, `delab`;
  [Delaborator.Options](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/PrettyPrinter/Delaborator/Options.lean),
  `pp.maxSteps`, `getPPMaxSteps`, `getPPProofs`, `getPPPrivateNames`.
- **S7:** [Elab.Print](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/Elab/Print.lean),
  `mkHeader`, `mkOmittedMsg`, `printDefLike`, `printInduct`, `printIdCore`.
- **S8:** [PrivateName](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/PrivateName.lean),
  `mkPrivateNameCore`;
  [Elab.Match](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/Elab/Match.lean),
  `mkAuxName` / `mkMatcher` at the matcher construction.
- **S9:** [AddDecl](https://github.com/leanprover/lean4/blob/eb6cafb7290e8bd5f2937522d8d804f58f02bafc/src/Lean/AddDecl.lean),
  `Environment.addDeclAux`, checked `doAdd`, `addDecl`;
  [existing checked-declaration lifecycle review](../paged-descriptor-cache/lifecycle-evidence/README.md).
