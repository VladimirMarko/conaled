# Next bounded step: hoist expansion guards in the complete n6 proof

24 October 2026. This is a source-only proposal after the successful guarded
`full-01` gate. No new compiler/counter run, larger board, or resumed
projected-context experiment is claimed here.

## Concrete opportunity in the complete counting route

The complete packed ADD proof lives in
`../../project/experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated/`.
Its `ConsolidatedGeneric.lean` defines `checkExpansion`, which checks
`i < nodeCount` at every tree node and both child IDs `< i` at every branch.
The complete `ConsolidatedArithmetic.lean` already proves
`RealSix.nodes_valid : NodesValid 110 9454 nodes` from its packed descriptor
check. That invariant includes strict child bounds for every nonconstant node.

All 36 concrete site proofs expand roots below 738 using the existing
`fastNodes` cache. `cache_planes_checked` and `fastNodes_eq` prove that those
descriptors agree with the genuine table. The existing cache reduces the size
of descriptor-access inputs; it does not remove the redundant expansion
guards. The proposed refinement is therefore distinct from that cache.

A syntax-only inventory of the fixed 36 literal trees gives 1,394 branch
occurrences and 1,430 constants: 2,824 tree-node occurrences. A new expansion
checker can retain one root bound per tree, then use the already proved
descriptor invariant for recursive bounds. This removes 2,788 repeated
node-bound tests and 2,788 child-order tests in the syntax. These are not
instrumented runtime counts or an estimated speedup; the kernel may already
share some reductions.

## Required theorem and concrete use

First prove `NodesValid` transport to a smaller exact descriptor prefix.
Child IDs remain within that prefix because they are strictly smaller than
their parent. Then define an expansion body omitting only recursive node and
child-order guards. **Retain rank equality, the branch variable bound,
constant-value comparison, and both recursive subtrees.** A branch with the
constant rank must not become accepted by dropping the variable bound.

Prove equality with the original expansion at every bounded root under
`NodesValid`. Wrap the body in one root bound and derive equality for *all*
natural root IDs: an invalid root is rejected by both checkers. Apply the
result to the actual `nodes_valid`, `fastNodes_eq`, and prefix bound. The
36 original expansion propositions can then be recovered by equality from
the optimized checks. No external Boolean or semantic node value is assumed.

The original source-count endpoint remains exactly
`ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six`,
proving `BitRepresentation.cqueens 6 = 4`. This step would exercise the full
counting/source connection, rather than another guarded-identity benchmark.

## Migration and fresh acceptance boundary

The existing complete n6 result is historical **Lean 4.33.0-rc1** evidence:
58 source bodies, consolidated into three bundles, passed in 27.329427591
seconds with 988,024 KiB peak RSS. It is not already a Lean-4.35 gate.
The three original bundles must remain untouched.

Prepare an isolated candidate under `../hoisted-expansion-count/`. The known
4.35 migration maps can replace deprecated proof-lemma aliases outside
comments and strings, with exact occurrence records and inverse reconstruction.
This source scan cannot prove that those are the only compatibility repairs
needed; fresh checking must resolve any actual remaining elaboration error.
Do not disable strict warnings or alter mathematical statements for migration.

The source bridge imports the exact ten-module integrated ADWH closure used
by the historical route. Its current accepted 4.35 sources must be bound and
any object preparation separately disclosed. No compiled experimental bundle
may be reused to claim freshness. The complete acceptance gate must check
all three mathematical bundles plus the new helper together under the
unchanged cumulative 30-second, one-CPU/thread, `-j1 -M1024` and separate
1-GiB RSS limits, including all original 334 axiom-print occurrences and the
new proof roots. A small helper-only check is development evidence only.

## Why not continue trimming the guarded checker here

After the accepted hoist, `checkGoal` occurs once per proof node; it is not
recomputed inside both branch cofactors. Its bounds are the evidence that
makes the successful hoist valid. Support-bit tests distinguish absent
variables from source-head cases and cannot simply be dropped from a valid
view. The remaining per-cofactor variable-bound repetition is a possible
local refinement, but empty parent goals need special treatment and it would
still concern only the identity certificate. The complete n6 expansion
boundary is the more useful next experiment.

## Decision and limits

Prepare and review this exact complete-count proposal. The potential savings
are unmeasured, and helper/proof overhead may consume them. A successful n6
gate would be a real complete counting-workflow milestone, but still would
not justify larger-board scaling or close `cqueens 16 = 14772512`.
No n6 rerun is warranted until the new source/proof transformation is fixed
and independently reviewed. Do not enlarge limits or repeat a failed
unchanged candidate.
