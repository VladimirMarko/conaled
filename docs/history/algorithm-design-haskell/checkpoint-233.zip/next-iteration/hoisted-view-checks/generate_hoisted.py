#!/usr/bin/env python3
"""Generate one source-bound hoisting variant without semantic evaluation.

All existing source bytes are copied unchanged except three fixed textual
transformations in the final proof module. The new generic helper is an input,
not a generated or assumed truth. No Lean process or source-function evaluator
is called. Acceptance requires the separately controlled complete fresh gate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CANONICAL = ROOT / "next-iteration/lean435-kernel-comparison/source"
PIN_PATH = ROOT / "next-iteration/lean435-kernel-comparison/protocol.json"
OUT = HERE / "source"
HELPER = OUT / "HoistedViewChecks.lean"
MANIFEST = HERE / "generation.json"
MODULES = ["ArithmeticSemantics", "SignedRelations", "GuardedSource",
           "GuardedRelationChecker", "TableCheck", "SignedBlockRewrite",
           "HoistedViewChecks", "GeneratedGuardedData", "GeneratedGuardedRelations"]
OLD_PREDICATE = "checkProofAt 210 866 nodes 909 views proofs"
NEW_PREDICATE = "HoistedViewChecks.checkProofAtBody 210 866 nodes 909 views proofs"
OLD_WRAPPER = (
    "  checkProofs_of_range (V := 210) (nodeCount := 866) (viewCount := 909) (proofCount := 332)\n"
    "    (nodes := nodes) (views := views) (proofs := proofs) proofs_range_0_332\n"
)
NEW_WRAPPER = (
    "  HoistedViewChecks.checkProofs_of_range (V := 210) (nodeCount := 866) (viewCount := 909) (proofCount := 332)\n"
    "    (nodes := nodes) (views := views) (proofs := proofs) views_checked proofs_range_0_332\n"
)
IMPORT_ANCHOR = "import SignedBlockRewrite\n"
NEW_IMPORTS = IMPORT_ANCHOR + "import HoistedViewChecks\n"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def bind_bytes(path: Path, raw: bytes) -> dict:
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": digest(raw)}


def binding(path: Path) -> dict:
    return bind_bytes(path, path.read_bytes())


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def transform(original: bytes) -> tuple[bytes, int]:
    text = original.decode()
    require(text.count(IMPORT_ANCHOR) == 1, "canonical import boundary changed")
    require(text.count(OLD_WRAPPER) == 1, "canonical whole-check wrapper changed")
    count = text.count(OLD_PREDICATE)
    require(count > 0 and "HoistedViewChecks" not in text, "unexpected canonical predicate")
    changed = text.replace(IMPORT_ANCHOR, NEW_IMPORTS)
    changed = changed.replace(OLD_PREDICATE, NEW_PREDICATE)
    changed = changed.replace(OLD_WRAPPER, NEW_WRAPPER)
    restored = changed.replace(NEW_WRAPPER, OLD_WRAPPER)
    restored = restored.replace(NEW_PREDICATE, OLD_PREDICATE)
    restored = restored.replace(NEW_IMPORTS, IMPORT_ANCHOR)
    require(restored.encode() == original, "inverse does not recover canonical bytes")
    require(changed.split("theorem all_proofs_correct", 1)[1] ==
            text.split("theorem all_proofs_correct", 1)[1], "final semantic endpoints changed")
    require("theorem proofs_checked : checkProofs 210 866 nodes 909 views 332 proofs = true :=\n"
            in changed, "original public checker conclusion changed")
    return changed.encode(), count


def build() -> tuple[dict[str, bytes], dict]:
    pins = json.loads(PIN_PATH.read_text())
    originals = {module: (CANONICAL / f"{module}.lean").read_bytes()
                 for module in MODULES if module != "HoistedViewChecks"}
    for module, raw in originals.items():
        require(digest(raw) == pins["source_sha256"][module],
                f"canonical source hash mismatch: {module}")
    outputs = dict(originals)
    outputs["GeneratedGuardedRelations"], count = transform(originals["GeneratedGuardedRelations"])
    outputs["HoistedViewChecks"] = HELPER.read_bytes()
    roots = {module: re.findall(r"^#print axioms ([\w.']+)\s*$", outputs[module].decode(), re.M)
             for module in MODULES}
    flattened = [root for module in MODULES for root in roots[module]]
    require(len(flattened) == len(set(flattened)) == 121,
            "required axiom root inventory changed")
    require(len(roots["HoistedViewChecks"]) == 8, "helper must expose eight reviewed roots")
    # This is a syntax-only occurrence count. It evaluates no checker or cofactor.
    data = originals["GeneratedGuardedData"].decode()
    proof_records = re.findall(r"^  ⟨(\[.*\]), (\.empty|\.split \d+ \d+ \d+)⟩,?\s*$", data, re.M)
    require(len(proof_records) == 332, "proof-record syntax or count changed")
    goal_occurrences = 0
    split_count = 0
    seen_ids = set()
    for goal, step in proof_records:
        entries = re.findall(r"\((-?\d+), (\d+)\)", goal)
        if step.startswith(".split"):
            split_count += 1
            goal_occurrences += len(entries)
            seen_ids.update(int(index) for _, index in entries)
        else:
            require(goal == "[]", "empty terminal is not literally empty")
    require(split_count == 331, "split count changed")
    manifest = {
        "format": "hoisted-view-check-source-refinement-v1",
        "semantic_evaluation": False,
        "lean_executed": False,
        "scope": "Fixed textual predicate/import/transport change; original complete checker conclusion retained.",
        "canonical_protocol": binding(PIN_PATH),
        "generator": binding(Path(__file__).resolve()),
        "canonical_sources": [bind_bytes(CANONICAL / f"{m}.lean", originals[m])
                              for m in MODULES if m in originals],
        "sources": [bind_bytes(OUT / f"{m}.lean", outputs[m]) for m in MODULES],
        "modules": MODULES,
        "axiom_roots": roots,
        "required_axiom_report_count": len(flattened),
        "changed_original_modules": ["GeneratedGuardedRelations"],
        "unchanged_original_modules": [m for m in MODULES if m in originals and m != "GeneratedGuardedRelations"],
        "proof_predicate_occurrences_changed": count,
        "inverse_recovers_canonical_final_source": True,
        "all_original_data_bytes_unchanged": True,
        "original_public_proofs_checked_statement_unchanged": True,
        "final_semantic_endpoint_suffix_unchanged": True,
        "static_occurrence_count": {
            "kind": "Source syntax only; no dynamic call count or timing claim",
            "proof_nodes": len(proof_records),
            "split_nodes": split_count,
            "parent_goal_term_occurrences_at_split_nodes": goal_occurrences,
            "cofactor_occurrences_if_each_branch_reaches_each_term": goal_occurrences * 2,
            "distinct_parent_view_ids": len(seen_ids),
            "complete_original_view_table_entries": 909,
        },
    }
    return outputs, manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    outputs, manifest = build()
    manifest_bytes = encode_json(manifest)
    if args.verify:
        for module in MODULES:
            require((OUT / f"{module}.lean").read_bytes() == outputs[module],
                    f"generated source differs: {module}")
        require(MANIFEST.read_bytes() == manifest_bytes, "generation manifest differs")
    else:
        OUT.mkdir(parents=True, exist_ok=True)
        for module in MODULES:
            if module != "HoistedViewChecks":
                (OUT / f"{module}.lean").write_bytes(outputs[module])
        MANIFEST.write_bytes(manifest_bytes)
    print(json.dumps({"status": "verified" if args.verify else "generated",
                      "modules": len(MODULES),
                      "axiom_reports_required": manifest["required_axiom_report_count"],
                      "proof_predicate_occurrences_changed": manifest["proof_predicate_occurrences_changed"],
                      "inverse_recovers_canonical_final_source": True,
                      "lean_executed": False,
                      "static_occurrence_count": manifest["static_occurrence_count"]}, sort_keys=True))


if __name__ == "__main__":
    main()
