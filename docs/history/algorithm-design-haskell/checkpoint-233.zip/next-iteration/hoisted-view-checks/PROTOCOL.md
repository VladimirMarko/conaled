# Hoist repeated view validation using a checked table

Prepared 24 October 2026 after reconciling the supplied kernel-validity report.
This is a source-level proof-producing optimization, with the ordinary Lean
kernel as the acceptance boundary. It neither modifies a kernel nor proves a
new queens count. The original target `BitRepresentation.cqueens 16 = 14772512`
remains open.

## Concrete source opportunity

The canonical `GuardedSource.cofactorView` starts by evaluating `checkView`.
The concrete certificate also proves the complete `checkViews` table, and
`GuardedRelationChecker.checkProofs_sound` already requires that proof. Each
`checkProofAt` first checks that every parent-goal view index is in range.
Consequently a proved refinement can use those two existing facts to remove
the repeated local view validation from cofactor execution. This is distinct
from the completed literal-page lookup experiment and the existing n6 cache.

Use the exact eight source modules pinned by
`../lean435-kernel-comparison/protocol.json`, including the canonical eight-entry
array pages. Keep the seven modules other than `GeneratedGuardedRelations`
byte-identical. In particular, no original record, mask, source ID, default,
link, lookup, reference checker, or reference soundness theorem changes.

## Required proof contract

Add `HoistedViewChecks.lean`. The body of a cofactor with a previously checked
view must agree with the original cofactor under `checkView = true`.
Lift this through cofactor terms and branches using a checked parent goal.
Prove equality of the optimized and original complete proof-check booleans
under the existing `checkViews = true` premise, including the case of a failed
goal-index check. All other checks, rejected operations, and earlier-proof
index requirements remain in the computation.

The generated concrete module may replace the internal proof-range predicate
with the optimized one, but must transport its result back to the unchanged
original `proofs_checked` proposition using the actual `views_checked` theorem.
The final four identities and signed block rewrites retain their statements.
No externally observed Boolean, unvalidated table, or unsupported assertion
becomes a premise. A deterministic generator must reproduce every source and
reverse its textual changes to recover the canonical final module exactly.

## Development and complete gate

A generic development check may compile the complete local dependency closure
of the new helper. This is not acceptance of the concrete certificate. Each
development attempt has its own immutable source snapshots and logs; a proof
correction requires a source change and a new name. There is no unchanged
timing retry and no resource increase.

The complete acceptance gate freshly compiles all nine selected sources under
one cumulative **30-second** wall limit. It uses the existing shared compile
lock, one CPU, one Lean thread, `-j1 -M1024`, the existing **1 GiB RSS** watchdog,
and default heartbeat/recursion options. No compiled experimental helper is
reused. The exact local import closure is checked; other imports must belong
to the pinned toolchain's Init or Std. The unchanged project source guard
checks all selected sources. Axiom reports for every required root must occur
exactly once and contain only `propext`, `Quot.sound`, and `Classical.choice`.

One complete candidate run is planned after independent source/protocol review.
An immutable execution marker is created immediately before compilation. A
failed full gate remains failed; substantive new source proposals require a
separate documented protocol rather than resetting that marker. No semantic
counter, larger board, paused projected-context experiment, or checker patch
is part of this gate.

Bind the compiler, shared runtime, canonical sources, new sources, generator,
manifest, protocol, resource helper, source guard and raw logs. Verify those
bindings after execution. Keep accepted and observed axiom counts separate
from counts merely required by attempted modules.

## Interpretation and retention

The mathematical result requires both the generic refinement and the complete
concrete gate. A successful result establishes the same guarded certificate
under a different proof-checking computation, not the missing factor/count
bridge or n16 scaling. Historical timings are context, not a matched benchmark.
Record actual complete-process observations without attributing differences
to one isolated operation. Preserve the previous accepted route regardless
of this outcome. Retain unique sources, generator and concise results; omit
reproducible build products and repeated snapshots from durability archives.
