import GuardedRelationChecker
import TableCheck

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
The complete view-table check already validates every bounded view ID.
Consume that proof once, rather than recomputing its five local conditions
for every cofactor occurrence. The original whole proof checker is recovered
by equality, including failed goal bounds and unsuccessful cofactor cases.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks

def cofactorViewBody (V _nodeCount : Nat) (nodes : Nat → NodeDesc)
    (varIdx : Nat) (bit : Bool) (view : View) : Option View :=
  if varIdx < V then
    if view.positive.testBit varIdx then
      if bit then some ⟨eraseBit view.positive varIdx, view.negative, view.core⟩
      else some zeroView
    else if view.negative.testBit varIdx then
      if bit then some zeroView
      else some ⟨view.positive, eraseBit view.negative varIdx, view.core⟩
    else if (nodes view.core).support.testBit varIdx then
      match (nodes view.core).raw with
      | .ite head _ _ =>
          if varIdx = head then
            some (mergeView view.positive view.negative
              (flatView nodes (if bit then (nodes view.core).high else (nodes view.core).low)))
          else none
      | _ => none
    else some view
  else none

theorem cofactorViewBody_eq {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    {varIdx : Nat} {bit : Bool} {view : View}
    (hview : checkView V nodeCount nodes view = true) :
    cofactorViewBody V nodeCount nodes varIdx bit view =
      cofactorView V nodeCount nodes varIdx bit view := by
  simp only [cofactorView, hview, ite_true, cofactorViewBody]
  cases (nodes view.core).raw <;> rfl

def cofactorTermsBody (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (v : Nat) (b : Bool) : ViewTerms → Option ViewTerms
  | [] => some []
  | (c, view) :: tail =>
      match cofactorViewBody V nodeCount nodes v b view with
      | none => none
      | some result =>
          match cofactorTermsBody V nodeCount nodes v b tail with
          | none => none
          | some rest => some ((c, result) :: rest)

theorem cofactorTermsBody_eq {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    {v : Nat} {b : Bool} {terms : ViewTerms}
    (hvalid : ∀ term ∈ terms, checkView V nodeCount nodes term.2 = true) :
    cofactorTermsBody V nodeCount nodes v b terms =
      cofactorTerms V nodeCount nodes v b terms := by
  revert hvalid
  induction terms with
  | nil => intro _; rfl
  | cons term tail ih =>
    intro hvalid
    rcases term with ⟨c, view⟩
    have hhead : checkView V nodeCount nodes view = true :=
      hvalid (c, view) (List.mem_cons_self)
    have htail : ∀ term ∈ tail, checkView V nodeCount nodes term.2 = true := by
      intro term hterm
      exact hvalid term (List.mem_cons_of_mem _ hterm)
    rw [cofactorTermsBody, cofactorTerms, cofactorViewBody_eq hhead, ih htail]
    cases cofactorView V nodeCount nodes v b view <;>
      cases cofactorTerms V nodeCount nodes v b tail <;> rfl

theorem expandGoal_checked {V nodeCount viewCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {goal : Goal}
    (hviews : checkViews V nodeCount nodes viewCount views = true)
    (hgoal : checkGoal viewCount goal = true) :
    ∀ term ∈ expandGoal views goal, checkView V nodeCount nodes term.2 = true := by
  intro term hterm
  change term ∈ goal.map (fun item => (item.1, views item.2)) at hterm
  obtain ⟨item, hitem, heq⟩ := List.mem_map.mp hterm
  subst term
  have hbound : item.2 < viewCount :=
    of_decide_eq_true (List.all_eq_true.mp hgoal item hitem)
  exact List.all_eq_true.mp hviews item.2 (List.mem_range.mpr hbound)

def checkBranchBody (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (parent child : Goal) (v : Nat) (b : Bool) : Bool :=
  match cofactorTermsBody V nodeCount nodes v b (expandGoal views parent) with
  | none => false
  | some restricted =>
      decide ((collectTerms restricted).Perm (collectTerms (expandGoal views child)))

theorem checkBranchBody_eq {V nodeCount viewCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View}
    {parent child : Goal} {v : Nat} {b : Bool}
    (hviews : checkViews V nodeCount nodes viewCount views = true)
    (hgoal : checkGoal viewCount parent = true) :
    checkBranchBody V nodeCount nodes views parent child v b =
      checkBranch V nodeCount nodes views parent child v b := by
  unfold checkBranchBody checkBranch
  rw [cofactorTermsBody_eq (expandGoal_checked hviews hgoal)]
  cases cofactorTerms V nodeCount nodes v b (expandGoal views parent) <;> rfl

def checkStepBody (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (proofs : Nat → ProofNode) (index : Nat) : Step → Bool
  | .empty => decide ((proofs index).goal = [])
  | .split v low high =>
      decide (low < index ∧ high < index) &&
        (checkBranchBody V nodeCount nodes views (proofs index).goal (proofs low).goal v false &&
         checkBranchBody V nodeCount nodes views (proofs index).goal (proofs high).goal v true)

theorem checkStepBody_eq {V nodeCount viewCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    {index : Nat} (step : Step)
    (hviews : checkViews V nodeCount nodes viewCount views = true)
    (hgoal : checkGoal viewCount (proofs index).goal = true) :
    checkStepBody V nodeCount nodes views proofs index step =
      checkStep V nodeCount nodes views proofs index step := by
  cases step with
  | empty => rfl
  | split v low high =>
    simp only [checkStepBody, checkStep, checkBranchBody_eq hviews hgoal]

def checkProofAtBody (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (viewCount : Nat) (views : Nat → View) (proofs : Nat → ProofNode) (index : Nat) : Bool :=
  checkGoal viewCount (proofs index).goal &&
    checkStepBody V nodeCount nodes views proofs index (proofs index).step

theorem checkProofAtBody_eq {V nodeCount viewCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    (hviews : checkViews V nodeCount nodes viewCount views = true) (index : Nat) :
    checkProofAtBody V nodeCount nodes viewCount views proofs index =
      checkProofAt V nodeCount nodes viewCount views proofs index := by
  by_cases hgoal : checkGoal viewCount (proofs index).goal = true
  · simp only [checkProofAtBody, checkProofAt, checkStepBody_eq _ hviews hgoal]
  · have hfalse : checkGoal viewCount (proofs index).goal = false :=
      Bool.eq_false_iff.mpr hgoal
    simp only [checkProofAtBody, checkProofAt, hfalse, Bool.false_and]

def checkProofsBody (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (viewCount : Nat) (views : Nat → View)
    (proofCount : Nat) (proofs : Nat → ProofNode) : Bool :=
  (List.range proofCount).all
    (fun index => checkProofAtBody V nodeCount nodes viewCount views proofs index)

theorem checkProofsBody_eq {V nodeCount viewCount proofCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    (hviews : checkViews V nodeCount nodes viewCount views = true) :
    checkProofsBody V nodeCount nodes viewCount views proofCount proofs =
      checkProofs V nodeCount nodes viewCount views proofCount proofs := by
  unfold checkProofsBody checkProofs
  apply congrArg (fun test : Nat → Bool => (List.range proofCount).all test)
  funext index
  exact checkProofAtBody_eq hviews index

theorem checkProofs_of_range {V nodeCount viewCount proofCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    (hviews : checkViews V nodeCount nodes viewCount views = true)
    (h : TableCheck.checkRange
      (checkProofAtBody V nodeCount nodes viewCount views proofs) 0 proofCount = true) :
    checkProofs V nodeCount nodes viewCount views proofCount proofs = true := by
  have hbody : checkProofsBody V nodeCount nodes viewCount views proofCount proofs = true :=
    TableCheck.range_all_of_checkRange h
  rw [checkProofsBody_eq hviews] at hbody
  exact hbody

end ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.cofactorViewBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.cofactorTermsBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.expandGoal_checked
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.checkBranchBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.checkStepBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.checkProofAtBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.checkProofsBody_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks.checkProofs_of_range
