# Independent pre-execution review

24 October 2026. Reviewer: the `validity_contracts` agent, which did not author
the helper, generator or runner. This review ran source-only byte comparisons
and `generate_hoisted.py --verify`. It ran no Lean compiler or checker and
establishes no timing or mathematical acceptance result.

**Decision:** the proposed contract, source transformation and bounded runner
are suitable for the planned fresh generic development gate, followed by the
separately fixed complete gate if the generic source checks. Compilation is
still required; source review is not a substitute for kernel acceptance.

## Mathematical boundary

The helper removes precisely the leading `checkView` condition from the
cofactor operation. An independent text comparison removed that one outer
condition and its final `else none` from the original source, adjusted its
indentation, and obtained the new body exactly. The variable bound, positive
and negative masks, support test, matching head variable, node constructors,
child choice, `flatView`, `mergeView`, failure cases and returned values are
unchanged.

The eight-theorem chain has the right premises:

1. `cofactorViewBody_eq` requires the actual original `checkView = true`.
2. `cofactorTermsBody_eq` requires that fact for every input occurrence and
   preserves both head failure and tail failure of the original recursion.
3. `expandGoal_checked` derives the facts from the actual complete
   `checkViews` result and `checkGoal`, using range membership for each ID.
4. `checkBranchBody_eq` requires only checked parent indices. The child goal
   is expanded and collected identically in both definitions; imposing a
   spurious child-validity premise is unnecessary.
5. `checkStepBody_eq` preserves both the terminal case and the original
   earlier-proof-index checks. The low and high branches use the same parent.
6. `checkProofAtBody_eq` splits on the original goal-bound check. When it is
   false, both complete checks are false. Thus no valid-index assumption is
   silently imposed on arbitrary inputs or on a total function's defaults.
7. `checkProofsBody_eq` extends pointwise equality to the exact finite range.
8. The range transport obtains the **original** `checkProofs = true`
   proposition from the new computation and the checked view table.

The equality is deliberately conditional on the checked view table. The
helper is not claimed equivalent to the reference cofactor on an arbitrary
invalid view. The concrete wrapper supplies `views_checked`, which was already
required by the unchanged global certificate theorem. `nodes_checked` remains
required by the original semantic soundness theorem. No node-validity premise
is discarded or replaced by a view-validity premise.

An empty parent goal, invalid split variable, invalid earlier-proof index,
out-of-range parent view ID, and failed cofactor therefore retain the original
behavior at the appropriate interface. The functions remain total over their
declared Lean types; their invalid-input cases do not rely on a generator
assertion. The final conversion to semantics still uses the original source
checker and its existing soundness proof.

The apparent elaboration concern about bare `List.mem_cons_self` is resolved
by the pinned toolchain's declaration: both `a` and `l` are implicit in
`Init/Data/List/Lemmas.lean`. This is source inspection, not a prediction that
the complete helper has no other elaboration errors.

## Independent preservation checks

- Seven original modules, including the entire concrete data module, are
  byte-identical to the canonical eight-module 4.35 source.
- The 61 concrete proof-range predicate occurrences change to the new body.
  One import and the final range-to-original-checker wrapper also change.
- Independently reversing those substitutions recovers the canonical final
  source exactly, without using the generator's inverse function.
- The source suffix beginning at `all_proofs_correct` is byte-identical.
  The original public `proofs_checked` statement is retained.
- The generator's independent `--verify` invocation passed. Its canonical
  inputs are bound to the pre-existing protocol hashes, and the manifest
  contains 121 distinct required axiom-report roots, including eight new
  helper roots.

Reviewed helper SHA-256:
`e7b0f6bb7a6fc5aa67cff793bd62541d534e35b4c694aa72dc3530ed4412bb28`.

Reviewed final source SHA-256:
`38cf3cad3c5701aee75fd9c10d1bd27261a33192c87e9f71fedf4051b4d9d914`.

The syntax-only count of 2,382 potential cofactor occurrences is not a measured
number of reductions or function invocations. Short-circuit evaluation and
kernel sharing can affect runtime. It should remain labeled as the generator
labels it.

## Protocol and runner

`PROTOCOL.md` fixes the unchanged one-CPU/thread, 30-second cumulative,
`-j1 -M1024`, 1 GiB RSS conditions, prohibits unchanged retries, distinguishes
generic development from complete acceptance, and retains the old route.

`run_gate.py` selects the exact local import closure: six modules and 63
required reports for the generic stage; nine modules and 121 reports for the
complete stage. Every selected module is copied into a fresh source directory
and compiled into a fresh build directory. Local import order and closure are
checked, with only pinned Init/Std imports allowed outside that selection.
The unchanged source guard and strict options are applied before execution.

The runner binds the compiler and all shared runtime libraries, checks the
canonical source pins, and uses the existing resource watchdog and shared
compile lock. The complete stage verifies the generator and creates its
exclusive execution marker before any compilation. It does not reuse the
generic stage's compiled helper.

After execution it checks source, snapshot and control bindings, records raw
per-module logs through the unchanged process helper, and distinguishes
required, observed and accepted axiom-report counts. A deadline, memory stop,
compiler failure, failed axiom audit, missing module or changed binding cannot
produce complete acceptance.

No result should be described as an n16 count or a proved performance benefit
merely because this pre-execution review passed. The complete source gate and
the remaining counting argument are separate obligations.

## Reviewed development correction after `generic-01`

The first generic gate failed in the new helper after five successful fresh
modules. The three failing proof bodies left equal-looking expressions with
separately generated match helpers; the compiler did not close those goals.
Its error-state axiom output contained `sorryAx`, which the gate rejected.
The recorded result is failed: 63 reports observed, but only the 55 from the
five passing modules accepted. No full-gate execution marker had been created.

The author repaired exactly `cofactorViewBody_eq`, `cofactorTermsBody_eq` and
`checkBranchBody_eq` by explicitly splitting the relevant node/Option
constructors and closing the resulting cases with reflexivity. An independent
comparison replaced only those three proof bodies in both versions and
obtained byte-identical remaining files. Thus every executable definition,
theorem statement, other proof and axiom-print command is unchanged. The
original failed source is retained in its immutable attempt snapshot.

The corrected helper SHA-256 is
`f9f5e339234a5819f4c2b5c98c372f234b8de36a276b3eed7ca6a62ef8c0b716`.
The concrete final source remains
`38cf3cad3c5701aee75fd9c10d1bd27261a33192c87e9f71fedf4051b4d9d914`.
The generator's verification passed again after the source/manifest update.
No compiler was run by this reviewer. The correction is suitable for a fresh
named generic development attempt with the same protocol and limits.
