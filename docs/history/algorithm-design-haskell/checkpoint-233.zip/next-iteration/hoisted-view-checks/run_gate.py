#!/usr/bin/env python3
"""Fresh, bounded proof checks for the actual hoisted-view refinement."""
from __future__ import annotations
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = HERE / 'source'
BASELINE = ROOT / 'next-iteration/lean435-kernel-comparison/source'
HELPER = BASELINE.parent / 'run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FULL = ['ArithmeticSemantics', 'SignedRelations', 'GuardedSource',
        'GuardedRelationChecker', 'TableCheck', 'SignedBlockRewrite',
        'HoistedViewChecks', 'GeneratedGuardedData', 'GeneratedGuardedRelations']
GENERIC = [x for x in FULL if x not in
           {'SignedBlockRewrite', 'GeneratedGuardedData', 'GeneratedGuardedRelations'}]
UNCHANGED = [x for x in FULL if x not in {'HoistedViewChecks', 'GeneratedGuardedRelations'}]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True)
    parser.add_argument('--stage', choices=['generic', 'full'], required=True)
    parser.add_argument('--attempt', required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]*', args.attempt):
        parser.error('invalid attempt name')
    modules = FULL if args.stage == 'full' else GENERIC
    root_module = 'GeneratedGuardedRelations' if args.stage == 'full' else 'HoistedViewChecks'
    expected_count = 121 if args.stage == 'full' else 63
    lean = args.lean.resolve()
    h = load(HELPER, 'hoisted_unchanged_resource_helper')
    h.TOOLCHAIN = lean.parent.parent
    guard = load(GUARD, 'hoisted_unchanged_source_guard')
    target = HERE / 'attempts' / args.attempt
    target.mkdir(parents=True, exist_ok=False)
    report = {
        'format': 'adwh-hoisted-view-checks-fresh-gate-v1', 'status': 'preparing',
        'stage': args.stage, 'root_module': root_module,
        'scope': 'Actual checker refinement under the existing checked-view premise',
        'n16_target_proved': False, 'source_count_proved': False,
        'kernel_modified': False, 'compiled_experimental_imports_reused': False,
        'constraints': {'cumulative_wall_seconds': 30, 'threads': 1,
                        'lean_memory_mib': 1024, 'resident_memory_kib': 1048576,
                        'default_heartbeats_and_recursion': True},
        'modules': [], 'source_bindings': [], 'controls': [],
    }
    save = lambda: h.save(target / 'report.json', report)
    save()
    try:
        with LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            h.require(Path('/proc/self/status').is_file(), 'RSS watchdog needs /proc')
            pin_path = ROOT / 'next-iteration/lean435-migration/toolchain.json'
            pins = json.loads(pin_path.read_text())
            h.require(h.sha(lean) == pins['binaries']['lean']['sha256'], 'Compiler differs')
            report['compiler'] = h.binding(lean)
            version = subprocess.run([str(lean), '--version'], capture_output=True,
                                     text=True, timeout=10, check=True).stdout.strip()
            h.require(pins['commit'] in version and '4.35.0' in version, 'Compiler version differs')
            report['compiler_version'] = version
            report['compiler_commit'] = pins['commit']
            baseline_protocol_path = BASELINE.parent / 'protocol.json'
            baseline_protocol = json.loads(baseline_protocol_path.read_text())
            for module, digest in baseline_protocol['source_sha256'].items():
                h.require(h.sha(BASELINE / (module + '.lean')) == digest,
                          'Canonical source differs: ' + module)
            for module in UNCHANGED:
                if module in modules:
                    h.require((SOURCE / (module + '.lean')).read_bytes() ==
                              (BASELINE / (module + '.lean')).read_bytes(),
                              'Reference module changed: ' + module)
            controls = [Path(__file__), HELPER, GUARD, HERE / 'PROTOCOL.md',
                        baseline_protocol_path, pin_path,
                        *[BASELINE / (name + '.lean') for name in baseline_protocol['source_sha256']]]
            if args.stage == 'full':
                generated = subprocess.run([sys.executable, str(HERE / 'generate_hoisted.py'), '--verify'],
                    cwd=HERE, capture_output=True, text=True, timeout=10)
                h.require(generated.returncode == 0,
                          'Source generation verification failed: ' + generated.stdout + generated.stderr)
                report['generation_verification'] = generated.stdout
                controls.extend([HERE / 'generate_hoisted.py', HERE / 'generation.json'])
            report['controls'] = [h.binding(p) for p in controls]
            reference_path = BASELINE.parent / 'attempts/comparison-01/report.json'
            reference = json.loads(reference_path.read_text())
            runtime_reference = {Path(x['path']).name: x['sha256']
                                 for x in reference['controls'] if x['path'].endswith('.so')}
            runtime_paths = sorted((lean.parent.parent / 'lib/lean').glob('*.so'))
            h.require(runtime_paths, 'Shared runtime missing')
            report['runtime_libraries'] = [h.binding(p) for p in runtime_paths]
            h.require({Path(x['path']).name: x['sha256'] for x in report['runtime_libraries']}
                      == runtime_reference, 'Shared runtime differs from accepted release')
            report['controls'].append(h.binding(reference_path))
            frozen, build = target / 'source', target / 'build'
            frozen.mkdir()
            build.mkdir()
            seen, imports_by_module, required = set(), {}, {}
            for module in modules:
                path = SOURCE / (module + '.lean')
                code = guard.check_lean_source(path, path.read_text())
                for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'),
                                      ('Elab.async', 'false')]:
                    options = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
                    h.require(options and set(options) == {value}, 'Strict option differs: ' + module)
                h.require(not re.search(r'\bset_option\s+(maxRecDepth|maxHeartbeats|maxMemory)\b', code),
                          'Resource option override: ' + module)
                imports = [name for line in re.findall(r'^\s*import\s+([^\n]+)$', code, re.M)
                           for name in line.split()]
                h.require(all(name in seen or name.split('.')[0] in {'Init', 'Std'} for name in imports),
                          'Unlisted or out-of-order local import: ' + module)
                imports_by_module[module] = imports
                seen.add(module)
                required[module] = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
                h.require(required[module], 'No axiom roots: ' + module)
                snapshot = frozen / path.name
                shutil.copyfile(path, snapshot)
                snapshot.chmod(0o444)
                report['source_bindings'].append({**h.binding(path), 'module': module,
                    'imports': imports, 'snapshot': str(snapshot), 'snapshot_sha256': h.sha(snapshot)})
            reached = set()
            def reach(module):
                if module in reached:
                    return
                reached.add(module)
                for name in imports_by_module[module]:
                    if name in imports_by_module:
                        reach(name)
            reach(root_module)
            h.require(reached == set(modules), 'Selected source closure is not exact')
            total_required = sum(map(len, required.values()))
            h.require(total_required == expected_count, 'Required root count differs from fixed design')
            report['required_prints'] = required
            report['required_axiom_report_count'] = total_required
            cpu = min(os.sched_getaffinity(0))
            os.sched_setaffinity(0, {cpu})
            report['constraints']['cpu_affinity'] = [cpu]
            env = h.clean_environment(build)
            for key in ['LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH']:
                env.pop(key, None)
            if args.stage == 'full':
                marker = HERE / 'FULL-EXECUTION-STARTED.json'
                with marker.open('x') as stream:
                    stream.write(json.dumps({'attempt': args.attempt,
                        'protocol': h.binding(HERE / 'PROTOCOL.md'),
                        'runner': h.binding(Path(__file__)),
                        'sources': report['source_bindings'],
                        'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())},
                        indent=2, sort_keys=True) + '\n')
                report['controls'].append(h.binding(marker))
            report['status'] = 'running'
            save()
            began = time.monotonic()
            deadline = began + 30.0
            good = True
            for module in modules:
                if time.monotonic() >= deadline:
                    good = False
                    break
                command = [str(lean), '-j1', '-M1024', '-o', str(build / (module + '.olean')),
                           '-i', str(build / (module + '.ilean')), module + '.lean']
                item = h.child(command, frozen, env, target / (module + '.stdout.log'),
                               target / (module + '.stderr.log'), cpu, deadline)
                output = (target / (module + '.stdout.log')).read_text() + '\n' + \
                         (target / (module + '.stderr.log')).read_text()
                audit = h.axiom_reports(output, required[module])
                item.update(module=module, axiom_audit=audit)
                item['status'] = ('passed' if item['exit_code'] == 0 and item['within_limits']
                                  and audit['passed'] else 'failed')
                report['modules'].append(item)
                save()
                if item['status'] != 'passed':
                    good = False
                    break
            report['seconds'] = time.monotonic() - began
            report['peak_child_rss_kib'] = max(
                (m['sampled_tree_and_wait4_peak_rss_kib'] for m in report['modules']), default=0)
            h.verify_bindings(report['source_bindings'] + report['controls'] +
                              report['runtime_libraries'] + [report['compiler']])
            for item in report['source_bindings']:
                h.require(h.sha(Path(item['snapshot'])) == item['sha256'], 'Snapshot changed')
            report['all_input_and_control_bindings_unchanged'] = True
            report['observed_axiom_report_count'] = sum(
                len(m['axiom_audit']['reports']) for m in report['modules'])
            report['accepted_axiom_report_count'] = sum(
                len(m['axiom_audit']['reports']) for m in report['modules'] if m['status'] == 'passed')
            report['all_selected_mathematical_sources_freshly_checked'] = (
                good and len(report['modules']) == len(modules) and report['seconds'] <= 30)
            report['status'] = ('passed' if report['all_selected_mathematical_sources_freshly_checked']
                                else 'failed')
            report['artifacts'] = [h.binding(p) for p in sorted(build.iterdir()) if p.is_file()]
            save()
    except BaseException as error:
        report['status'] = 'failed'
        report['exception'] = {'type': type(error).__name__, 'message': str(error)}
        save()
        raise
    print(json.dumps({k: report.get(k) for k in
        ['status', 'stage', 'seconds', 'peak_child_rss_kib', 'accepted_axiom_report_count',
         'all_selected_mathematical_sources_freshly_checked']}, indent=2))
    print('report:', target / 'report.json')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
