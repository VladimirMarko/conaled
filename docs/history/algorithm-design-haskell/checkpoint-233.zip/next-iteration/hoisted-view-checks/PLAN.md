# Exact hoisted-check proposal

The fixed protocol is `PROTOCOL.md`. The motivating counting-route and report
review is `../kernel-validity-reconciliation/PLAN-REVIEW.md`.

`generate_hoisted.py` copies the canonical accepted Lean-4.35 source closure,
adds `source/HoistedViewChecks.lean`, and changes only 61 occurrences of the
proof-range predicate, one import, and the final checker-transport wrapper.
The complete data source and the other six original helper modules remain
byte-identical. Its inverse reconstructs the original final module exactly.
The public `proofs_checked` proposition and all subsequent semantic proof
bodies remain unchanged. Generation and `--verify` perform no Lean execution
or semantic evaluation.

The generic helper proves equality of the new and original operation under a
checked input view, lifts that equality through terms and branches, and obtains
the input-view condition from the already checked complete table plus parent
goal bounds. It explicitly treats failed parent bounds: both complete-node
checks then equal false. Every remaining cofactor failure and source case is
unchanged. The final range wrapper consumes the concrete `views_checked`
theorem and returns the original complete checker proposition.

The helper exposes exactly eight axiom-audit roots: `cofactorViewBody_eq`,
`cofactorTermsBody_eq`, `expandGoal_checked`, `checkBranchBody_eq`,
`checkStepBody_eq`, `checkProofAtBody_eq`, `checkProofsBody_eq`, and
`checkProofs_of_range`, all under
`ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.HoistedViewChecks`.
Together with the retained 113 original roots, the full nine-module closure
requires 121 actual accepted reports. It must pass one fresh cumulative gate;
a helper-only check does not accept the concrete certificate.

A source-syntax inventory records 332 proof nodes, of which 331 split; 1,191
parent-goal term occurrences; and 909 distinct referenced view IDs, equal to
the complete table size. Evaluating both branches through every term would
make 2,382 cofactor occurrences whose initial view check this route removes.
That is a syntactic opportunity count, not an instrumented dynamic-call count,
a running-time prediction, or evidence of counting-scale improvement.

All nine generated sources, the generator, the new helper and original pins
are recorded in `generation.json`. A proposed source is not an accepted
theorem until the corresponding controlled Lean gate succeeds. No new count,
source/factor bridge, or kernel modification is part of this experiment.
