# Independent review of the complete hoisted-view certificate

24 October 2026. The single fixed `full-01` attempt **passed all nine selected
modules freshly** in **23.727831765 seconds**, with **763,460 KiB** peak child
RSS and **121 actual accepted axiom reports**. This includes both the generic
refinement and the complete concrete certificate in the same cumulative gate.
The original one-CPU/thread, 30-second, `-j1 -M1024`, 1 GiB RSS limits remain.

The authoritative report is `attempts/full-01/report.json`, SHA-256
`9a2640ba21e4ed050d6630ae8a3041299732d124d1961114e80bf39f3e786db1`.

## Independent audit

The reviewer did not author the helper, generator or gate runner and ran no
Lean process. A separate read-only audit verified:

- All **69 distinct recorded file bindings**, including the compiler, shared
  runtime, canonical and new sources, controls, raw logs and build artifacts.
- All **nine immutable source snapshots**, and their agreement with the
  nine source bindings recorded in the exclusive full-execution marker.
- All **18 compiled-artifact bindings**. These artifacts are audit evidence
  in the workspace; they are not needed in the durability selection.
- Exactly **121 distinct axiom reports**, each occurring once, parsed from
  raw stdout/stderr independently of the runner and checked against both
  source `#print axioms` commands and the recorded audit.
- Only the permitted `propext`, `Quot.sound` and `Classical.choice` dependencies
  in those reports. All nine compiler processes exited successfully within
  their recorded limits; no error-state admission was accepted.

All bindings matched. No log-byte recovery was needed. The detailed audit is
`FULL-RESULT-AUDIT.json`. The generator's `--verify` also passed after the gate.

## Preserved mathematical result

The full gate used the previously reviewed corrected helper, SHA-256
`f9f5e339234a5819f4c2b5c98c372f234b8de36a276b3eed7ca6a62ef8c0b716`.
Seven original source modules, including all canonical concrete records,
remain byte-identical. Independently reversing the final module's fixed
import, predicate and wrapper substitutions recovers its original bytes.

The final public proposition remains:

```lean
checkProofs 210 866 nodes 909 views 332 proofs = true
```

The optimized range result is transported to that original proposition using
the actual `views_checked` theorem. The complete source suffix beginning at
`all_proofs_correct` is byte-identical, and all **16 original final relation
endpoints** (`relation0` through `relation3`, each with `_zero`, `_bound`,
`_nat` and `_block`) appear in the accepted raw axiom reports.

Thus the full result establishes the same existing guarded identities and
signed block rewrites through the new, proved computation. The helper's
conditional equality covers failed goal bounds and cofactor failures; an
unvalidated view table is not substituted for the checked premise.

## Observation and limits

The data module took 9.277005506 seconds and the final relation module took
10.812827285 seconds in this run. The total includes the new refinement module
and runner bookkeeping. The historical accepted original gate took
25.223733357 seconds, but it was a different run in a different session with
one fewer proof module. These observations are **not a matched benchmark** and
do not establish a causal speedup or a statistical performance ranking.

The accepted result is a source-level checker refinement under the ordinary
Lean kernel. It modifies no kernel and adds no native-computation assumption.
It does not complete the factor/count bridge, count a larger board, or prove
`cqueens 16 = 14772512`. No unchanged full-gate retry or increased allowance was
used. Keep the previous accepted route and the concise development record;
omit compiled outputs and reproducible duplicate snapshots from checkpoints.
