# Complete hoisted-view checker refinement accepted

24 October 2026. The single fixed `full-01` gate passed all nine selected source
modules freshly together in **23.727831765 seconds**, with **763,460 KiB** peak
child RSS and **121 actual accepted axiom reports**. All required roots use
only `propext`, `Quot.sound`, and `Classical.choice`. No compiled experimental
helper from development or a previous run was reused.

The limits stayed cumulative 30 seconds, one CPU/thread, `-j1 -M1024`, and the
separate 1 GiB RSS watchdog, with default heartbeat/recursion settings. The
full execution marker remains intact. No kernel was changed or replaced.

## Mathematical result

Eight new generic results prove equality between the optimized and original
proof-check booleans under the already required complete checked-view premise.
The original cofactor's repeated local validity guard can therefore be removed
at precisely the call sites where the original parent-goal bound check and
complete view-table proof establish it.

The refinement covers failed goal bounds explicitly and preserves variable
bounds, earlier-proof bounds, source cases, masks, defaults, normalization,
child expansion and unsuccessful cofactor behavior. It asserts equality of
the complete actual Boolean checker under its stated premise, not merely
agreement on the generator's successful inputs.

The concrete module checks the optimized predicate by ordinary `decide +kernel`
and consumes the existing actual `views_checked` theorem to recover the
unchanged original `proofs_checked` proposition. The original global soundness
theorem then reestablishes all four guarded identities and signed block rewrites.
All sixteen final relation endpoints are present and audited.

## Source preservation

Seven original modules remain byte-identical, including all canonical data:
866 source nodes, 909 views, 332 proof nodes and 332 original-ID metadata entries.
The generator changes one import, 61 internal proof-predicate occurrences and
the proof wrapper that supplies `views_checked`. Its independent inverse
recovers the original final source exactly. The public `proofs_checked`
statement and all subsequent semantic proof source remain unchanged.

The new route uses the original accepted eight-entry array pages. The separately
accepted direct-lookup refinement from checkpoint 186 remains available but is
not an import or input to this gate. Combining the two would be a different
proposal requiring its own complete gate, not an inferred result.

## Verification evidence

The authoritative report is `attempts/full-01/report.json`. Independent
post-run inspection checked 69 distinct recorded file bindings, all nine
frozen source snapshots and their execution-marker bindings, eighteen build
artifacts, and all 121 distinct raw axiom reports. Every recorded binding
matched; no log recovery was required. Compiled artifacts and redundant source
snapshots are workspace audit material and need not be in the recovery ZIP.
See `FULL-RESULT-REVIEW.md` and `FULL-RESULT-AUDIT.json`.

| Stage | Seconds | Accepted reports |
| --- | ---: | ---: |
| Seven generic modules, including the new refinement | 3.622 | 68 |
| Original concrete descriptor data | 9.277 | 23 |
| Concrete checks and final relation proofs | 10.813 | 30 |
| Complete gate, including interleaved bookkeeping | 23.728 | 121 |

The earlier eight-module 4.35 certificate gate took 25.223733357 seconds, and
checkpoint 186's different lookup-refinement closure took 26.577593627 seconds.
Neither is a matched benchmark for this new run. The result establishes
acceptance within the fixed budget, not a causal end-to-end speedup, isolated
kernel-operation timing, or improvement for a complete queens count.

## Development provenance

The first generic gate failed on three proof-script goals involving separate
generated match helpers. Its error-state placeholders were rejected. Explicit
constructor cases corrected only those three proof bodies; every executable
definition, theorem statement, other proof, full concrete source and resource
limit stayed unchanged. The corrected `generic-02` gate passed six freshly
rebuilt sources in 3.215847374 seconds with 63 accepted reports. The later full
gate rebuilt those six again as part of its exact nine-module closure.
`DEVELOPMENT.md` and `INDEPENDENT-REVIEW.md` record the correction.

## Remaining counting boundary

This accepted certificate concerns selected internally interpreted functions
at a fixed n8-derived cut. It does not bind the current lazy counter's actual
factor occurrence, complete the factor/count bridge, establish a new queens
count, or prove `cqueens 16 = 14772512`. No board above eight was attempted.
The projected-context experiment remains paused.

Do not repeat this unchanged gate or reset its execution marker. Preserve
this proved refinement and the prior accepted certificate. The next source
investigation asks whether the same use of already established validity facts
can simplify the *complete* packed n6 counting route's tree-expansion check.
That is a separate proposal, not a consequence or accepted result of this gate.
