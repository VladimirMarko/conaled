# Generic refinement development

24 October 2026. The new helper's complete six-module dependency closure has
passed a fresh development gate. This establishes the generic conditional
checker equality. It does not yet accept the generated concrete certificate;
the full nine-module gate must rebuild these six modules as part of its own
single cumulative allowance.

| Attempt | Outcome | Cumulative seconds | Peak RSS, KiB | Actual accepted axiom reports |
| --- | --- | ---: | ---: | ---: |
| `generic-01` | Helper proof elaboration failed | 3.404674348 | 523,568 | 55 from five passing dependencies |
| `generic-02` | All six modules passed | 3.215847374 | 523,440 | 63 |

Both runs kept one CPU/thread, `-j1 -M1024`, the 30-second cumulative deadline,
and separate 1-GiB resident limit. Neither reused compiled experimental imports.
The successful run's 63 required reports contain only the three permitted
axioms. `source/HoistedViewChecks.lean` has SHA256
`f9f5e339234a5819f4c2b5c98c372f234b8de36a276b3eed7ca6a62ef8c0b716`.

## Exact correction

The first attempt left three reflexivity-shaped goals open after rewriting.
The displayed expressions agreed, but they used separately generated match
helpers. The correction explicitly cases on the common raw constructor or
`Option` discriminator and closes each case with `rfl`.

Only the proof bodies of `cofactorViewBody_eq`, `cofactorTermsBody_eq`, and
`checkBranchBody_eq` changed. Comparison with the retained `generic-01` source
snapshot confirms that all six executable definitions and all eight theorem
statements are byte-identical. No data, premise, resource option, generator,
or concrete proof module changed. The generation manifest was regenerated
to bind the corrected helper and passed source-only `--verify`.

The first failed helper emitted error-state `sorryAx` dependencies. Those
reports were rejected, not accepted mathematical evidence. Its report records
63 observed lines but only 55 valid reports from the earlier dependencies.
No admission was added to the source. The distinct second attempt used the
corrected source and fresh dependency objects; the failed attempt remains
retained with its original report and logs.

## Report bindings

- `attempts/generic-01/report.json`:
  `fe8ee78719a4a0b87f1d1065630b7ffe06770e093e252061c3af9a602457c125`.
- `attempts/generic-02/report.json`:
  `b2e925328e5efc4889b962246ebce86c3a581af355feb8b52822e91db3fb09e2`.

Independent review and its correction addendum are in `INDEPENDENT-REVIEW.md`.
The full candidate is unchanged by this development correction apart from
the new helper's three proof bodies and their recorded hash. This is not a
timing retry of an unchanged accepted candidate.
