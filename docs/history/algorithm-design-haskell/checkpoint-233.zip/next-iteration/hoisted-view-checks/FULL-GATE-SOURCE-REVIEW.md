# Source-only readiness for the complete gate

24 October 2026. This note is by the implementation author; independent review
is recorded separately in `INDEPENDENT-REVIEW.md`. No compilation was run for
this note.

The fixed full candidate consists of the canonical eight source modules plus
the new `HoistedViewChecks` helper. The helper's exact six-module local closure
has passed `generic-02`; its objects must not be reused in the full gate.
The remaining three modules are `SignedBlockRewrite`, `GeneratedGuardedData`,
and `GeneratedGuardedRelations`. The runner orders all dependencies before
their consumers and recompiles all nine modules together.

The generator's source-only verification checks every canonical source hash,
all nine output bytes, the complete 121-root print inventory, and the manifest.
Its inverse reconstructs the canonical final relation module exactly. Seven
original modules, including the data module, remain byte-identical. The final
module retains every original node/view check and range. Its proof ranges
use the new predicate, cover the same 332 proof IDs, and are joined by the
unchanged range-composition theorem.

The only changed final whole-table application supplies the actual
`views_checked` theorem to the new range wrapper. The wrapper concludes the
original `checkProofs` proposition. Thus the original `proofs_checked`
statement, `all_proofs_correct` proof, and every subsequent identity and
signed rewrite remain fixed. The complete original `nodes_checked` proof
still enters the original semantic soundness theorem.

The planned complete gate is the acceptance decision. Passing a generic
refinement in isolation does not demonstrate an improvement or discharge any
concrete condition. Report actual whole-gate time and memory with the full
121 accepted axiom reports, or retain the rejected outcome. Do not promote
historical per-module timings into an isolated cost attribution or n16 claim.
