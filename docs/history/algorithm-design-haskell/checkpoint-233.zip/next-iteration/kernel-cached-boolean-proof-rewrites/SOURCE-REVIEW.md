# Independent source review of the thirty-two Boolean certificates

Reviewer: `book_scope_review`. Source author: `reflection_evidence_review`.

**Result: no source-level semantic blocker found.** This review covers the
final parenthesized physical and native candidates, their exact overlays and
their explicit recovery history. It is source-only acceptance for a separately
reviewed complete gate. It is not compilation, a measured improvement, a native
API acceptance, a complete resource-fit result or an original record theorem.

The selected physical candidate is 210,150 bytes, SHA-256
`285b257310da159cd60570a33eac6b5a5396a234b3a7c166762062c381e45565`.
The full native companion is 77,612 bytes, SHA-256
`10cc8c786c7550a087ec9fc11b17f87b7353d7942c6e720716e3ac0884a85cfb`.
The companion is provenance for later integration; it is not a second compiled
owner in the prospective ordinary evaluator selection.

## Reviewed mathematical change

Each of the two actual Boolean walks returns a Boolean paired with a proof
that it equals its plain descent's result, together with the actual returned
memo. The edits replace sixteen such proof fields in `wscopedBXP` and sixteen
in `leavesSubXP`. The result values, recursive calls, conditionals, memo
operations and surrounding dependent pairs remain unchanged.

I read both complete new walk blocks, their actual plain descents, the cutoff
theorems, child-entry wrappers and the `ResB`/`ResB0` result contracts. The new
proofs use one actual descent equation, the existing false-cutoff fact and
only the branch or child certificates available on the executed path.

| Branch family, in each walk | Certificates | Source-level proof check |
| --- | ---: | --- |
| Bound variable, sort, constant, literal | 4 | The false cutoff and one descent equation leave the stated true result. |
| Free variable accepted/rejected | 2 | The actual Nat comparison or leaf-membership fact determines the first Boolean. The accepted branch uses its actual child certificate; the rejected branch needs no child run. |
| Application | 2 | A true first child permits the second certificate; a false first child reduces the conjunction without inspecting the skipped argument. |
| Lambda and forall | 4 | The type/body conjunction is retained, including the actual free-variable cursor at both children. |
| Let | 3 | The existing left-associated conjunction and type/value/body order are retained; each early false branch uses only certificates already obtained. |
| Projection | 1 | The sole child certificate identifies the returned Boolean. |

For scope queries the free-variable annotation is checked at the variable's
own index, as in `wscopedBP ty idx`. Binder bodies retain the ambient
free-variable cursor `d`; the candidate does not substitute a bound-variable
depth convention. The leaf-subset walk retains the actual `leafMem` predicate
and exact base list. Neither walk's cutoff is changed or justified by a new
unstated invariant.

The child proof orientation is also correct. For example, a branch contains
`hf : true = wscopedBP f d`; rewriting by its reverse makes the corresponding
Boolean operand true. The false branch similarly rewrites the first operand
to false. The final Boolean reductions are the pinned `Bool.and` reductions,
which inspect the first operand and do not require the skipped second child.
This preserves the actual short-circuit structure.

The two free-variable comparison branches use the pinned nondeprecated
`decide_eq_true` and `decide_eq_false` statements. The rejected leaf-membership
branch has exactly the negated `leafMem ... = true` premise required by
`Bool.eq_false_of_ne_true`. The retained SDK Prelude and Notation files are
byte-identical to the restored pinned SDK copies. Their relevant four
intervals were read, including equality precedence 50 and Boolean-conjunction
precedence 35. The final twenty-two compound `change` goals in each source
parenthesize the complete Boolean right-hand side.

The edits do not add a proposition, assumption, theorem, axiom, executable
function or import. Each new proof inhabits the same existing equality field.
Once checked, proof irrelevance identifies the proof components while the
existing data result remains the same. This review does not infer a generated
machine-code identity or a runtime measurement from that logical fact.

## Exact source correspondence

I independently checked all 234 direct author input identities. The main overlay
reconstructs both complete candidates from their frozen predecessors, and the
inverse substitutions reconstruct both predecessors exactly. The physical
overlay has thirty-two proof edits and one 534-byte ordinary comment insertion;
the native overlay has exactly the same thirty-two proof edits and no prefix.
The physical source grows by 2,608 bytes, and the native source by 2,074 bytes.

All 34 physical and 33 native unchanged complement segments match byte-for-byte
at their recorded offsets, sizes and hashes. The source-map text, lengths,
hashes and original/candidate line positions were checked at every edit. All
sixty-four proof replacements lie in the equality-certificate fields of the
two specified definitions; the additional physical insertion is a comment.

The two complete original walk blocks and the two complete candidate walk
blocks match byte-for-byte across the physical and native representations.
Their mapped sizes and hashes were checked separately. The actual source
headers, imports, options and report-command texts are unchanged. The existing
twenty-five physical owner report roots remain exactly the same; this is not
a count of all inherited public theorem declarations in that owner.

All twelve primary intervals match the complete bound source files exactly.
The earlier forty-edit proof layer, native-to-ordinary origin correspondence,
explicit evaluator omissions and two leading-comment repairs remain separate
historical scopes. This new review does not replace or rebase those reviews.

The physical owner still omits the documented driver families, including the
resolution APIs and `recordCConst`. The native companion preserves its own
full predecessor module/import/visibility/API text. These are two distinct
claims: the companion does not restore the omitted APIs to the current physical
owner, and this review does not claim the whole original kernel/model closure
has been compiled.

## Preserved pre-review history

The initial metadata wording correction changes the ambiguous report-count
label; its common overlay fields are otherwise unchanged. The original
metadata bytes remain under `pre-review-metadata-01`. The intermediate
canonical identities named by that correction are recovered explicitly by
`SOURCE-GRAMMAR-CORRECTION.json` under `unselected-draft-v1`; they are not
treated as hashes of the final files now occupying those canonical paths.

The parenthesization correction has exactly twenty-two line edits in each
representation. I reconstructed each final source from its preserved draft
and each draft from its final source. All four draft source/map recovery
identities match their preserved bytes. The final baseline-to-candidate map
still confines every mathematical edit to the same thirty-two proof fields.
No compiler failure is invented for these source-inspection corrections, and
no mathematical attempt was consumed by the unselected drafts.

## Execution and selection boundary

The consumed earlier complete gates remain evidence about their exact old
sources. The SyntaxHasLP120 attempt accepted 112 reports and exhausted the
common deadline at Literal. The later Wrapper136 attempt accepted 71 reports
and failed at two Literal scope-proof elaboration errors, before Frame or
Wrapper was accepted. Neither attempt used this Boolean proof variant.

Removing broad simplification at these thirty-two sites is a concrete source
change and a plausible cost experiment. It is not measured performance
evidence. The earlier direct proof layer did not create sufficient headroom
for all planned selections; this additional layer may also be insufficient.
The failed runs do not profile individual declarations or establish that
these particular certificates account for the observed module cost.

The next complete gate must separately bind the diagnosed Literal repair and
its independent review, this review, and every retained dependency scope.
All selected mathematical owners still require fresh compilation together
under one cumulative 30-second, one-CPU/thread, 1-GiB, default-limit,
strict-warning and three-axiom policy. No prepared objects, split compilation,
unchanged-source retry or independent base timing run is licensed here.

No compiler, gate, metadata preflight, mathematical program, exporter,
profiler, retained generator or saved-evidence reader was executed during
this review. The checks used source reads, byte identities, literal
reconstruction and inspection of the retained raw source/result metadata.
Actual whole-query success, installed annotations/pins, the true-prefix
environment, EnvWF, original GroupChecked, native/source reconciliation and
the final validating-kernel numeral result remain outside this scope.
