# Author source review of Boolean32

Author: `reflection_evidence_review`. This is not an independent review and does
not claim compilation, measured cost reduction or gate acceptance.

All sixteen branches in each actual walk were read against its retained plain
descent and `ResB`/`ResB0` equality field. The new goal shapes retain each actual
cursor, child and conjunction association. True and false branches use only
proofs supplied by the calls the program actually made. The rejected fvar and
false-first-child branches do not assume success or a certificate for a skipped
child. The returned memo and all memo operations remain outside the edited proof
spans.

Both native and physical source variants were reconstructed from the frozen
predecessors by the exact ordered edits. Every unchanged complement segment is
recorded with offsets, size and hash. The two original walk blocks and the two
candidate walk blocks match byte-for-byte between source representations. The
physical prefix is an ordinary `/-` comment, retaining the diagnosed Lean import
grammar requirement. Full native module/import/visibility commands remain
unchanged. No declaration, report, source option or resource setting is added.

The pinned Prelude gives the exact positive/negative comparison and negative
Boolean-guard lemmas used by the new proofs, and its `Bool.and` definition gives
the claimed left Boolean reductions. The pinned Notation source confirms the
equality/conjunction precedence that prompted the recorded source-only draft
correction. All compound equality goals now parenthesize the complete Boolean
right-hand side. Both preserved draft variants remain explicitly unselected.

The current physical owner still has its documented driver omissions, while the
native companion preserves its own complete predecessor API. Neither source is
treated as a compiled artifact or as proof that the final original record has
been accepted. Only root may execute a reviewed fresh complete gate; the cost
hypothesis remains unmeasured.
