/- Thirty-two additional Boolean subtype-certificate proofs use explicit
one-step descent, cutoff/branch facts and child equalities. The historical
notices below describe predecessor layers, not the new proof scripts. All
computational data, calls, guards, keys, memo writes, interfaces and source
options are unchanged. The complete native ExprOpsC companion preserves its
full source API; this ordinary evaluator owner retains its existing explicit
driver omissions. This separate proof-only candidate is not compiled or timed. -/

/- Evaluator-scope extraction. The historical notices below describe retained
predecessor transformations. This variant omits the two certified parsed-driver
guard walks and recordCConst, which have no caller in the selected evaluator.
All retained actual cached definitions, intrinsic proofs, CState fields, helper
operations, six knot slots, imports and options are exact. The original record
driver still requires the removed guards and insertion API. This source-only
extraction claims no complete-driver acceptance or measured timing improvement. -/

/- Distinct proof-only compilation-cost candidate over the accepted corrected
cached owner. Forty proof edits are explicit in PROOF-OVERLAY.json: thirty-six
subtype certificates use direct equality rewriting, and four termination
proofs try the structural-right case first. All computational branches,
arguments, borrowing annotations, guards, memo keys and writes are retained.
The inherited assembly header below describes the predecessor's source-copy
layer; it does not assert that this variant's forty proof scripts are unchanged.
This variant is not compiled or timed. It adds no declaration or report. -/

import KernelCompactCore

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual cached operational and licensed paths over the current logical Core

Source candidate only; no compile, gate, or performance result is claimed.
KernelCompactCore is selected at its exact current ordinary-field identity.
Its inherited representation, compiler-substitution, proof and registration
cuts remain in force.  Upstream comments below describe the unsliced computed
representation; they do not establish constant-time observers or preserved
native implementation here.  The two explicit supplemental slices restore
only the actual eight helpers required by these cached definitions.

All five newly selected full upstream units retain every declaration and proof
body.  Their module/import/visibility commands and the explicit universe in
ExprOpsC are recorded in SOURCE-CORRESPONDENCE.json.  Former EOF public sections
are closed at their original boundaries.  No CSOK, CEff, model, simulation,
installation or source-guard theorem is imported.  The two project proof units
are literal apart from their import comments.  Fresh strict compilation remains
necessary; this assembly establishes no whole-count or GroupChecked result.
-/

/- BEGIN exact supplemental slice pointer_helpers from ConLeche.Kernel.Expr -/
section

-- Explicit universes required by the strict autoImplicit=false policy.
universe u v

namespace ConLeche.Expr

/-- `withPtrAddr` into a subsingleton: its side condition — the
continuation's result does not depend on the address — is then
`Subsingleton.elim`. -/
@[inline] def withAddr {α : Type u} {β : Type v} [Subsingleton β] (a : α)
    (k : USize → β) : β :=
  withPtrAddr a k (fun _ _ => Subsingleton.elim _ _)

/-- Identity, decided: the pointer test at runtime, the derived
structural decision in the pure model. -/
@[inline] def ptrDec (a b : Expr) : Decidable (a = b) :=
  withPtrEqDecEq a b (fun _ => instDecidableEqExpr a b)


end ConLeche.Expr
end -- supplemental source scope
/- END exact supplemental slice pointer_helpers -/

/- BEGIN exact supplemental slice saturated_ranges from ConLeche.Kernel.ExprOps -/
section

namespace ConLeche.Expr

/-- Memoized `bvarBound` (the saturated branch's exact recomputation). -/
def bvarBoundGo (memo : Std.HashMap Expr Nat) (e : Expr) :
    Nat × Std.HashMap Expr Nat :=
  match memo[e]? with
  | some r => (r, memo)
  | none =>
    let (r, memo) : Nat × Std.HashMap Expr Nat :=
      match e with
      | .bvar i => (i + 1, memo)
      | .fvar _ _ | .sort _ | .const _ _ | .lit _ => (0, memo)
      | .app f a =>
        let (rf, memo) := bvarBoundGo memo f
        let (ra, memo) := bvarBoundGo memo a
        (max rf ra, memo)
      | .lam ty body _ | .forallE ty body _ =>
        let (rt, memo) := bvarBoundGo memo ty
        let (rb, memo) := bvarBoundGo memo body
        (max rt (rb - 1), memo)
      | .letE ty val body =>
        let (rt, memo) := bvarBoundGo memo ty
        let (rv, memo) := bvarBoundGo memo val
        let (rb, memo) := bvarBoundGo memo body
        (max (max rt rv) (rb - 1), memo)
      | .proj _ _ sub => bvarBoundGo memo sub
    (r, memo.insert e r)

@[inherit_doc bvarBoundGo]
def bvarBoundMemo (e : Expr) : Nat := (bvarBoundGo {} e).1

/-- Memoized `fvarRange` (the saturated branch's exact
recomputation). -/
def fvarRangeGo (memo : Std.HashMap Expr Nat) (e : Expr) :
    Nat × Std.HashMap Expr Nat :=
  match memo[e]? with
  | some r => (r, memo)
  | none =>
    let (r, memo) : Nat × Std.HashMap Expr Nat :=
      match e with
      | .fvar idx _ => (idx + 1, memo)
      | .bvar _ | .sort _ | .const _ _ | .lit _ => (0, memo)
      | .app f a =>
        let (rf, memo) := fvarRangeGo memo f
        let (ra, memo) := fvarRangeGo memo a
        (max rf ra, memo)
      | .lam ty body _ | .forallE ty body _ =>
        let (rt, memo) := fvarRangeGo memo ty
        let (rb, memo) := fvarRangeGo memo body
        (max rt rb, memo)
      | .letE ty val body =>
        let (rt, memo) := fvarRangeGo memo ty
        let (rv, memo) := fvarRangeGo memo val
        let (rb, memo) := fvarRangeGo memo body
        (max (max rt rv) rb, memo)
      | .proj _ _ sub => fvarRangeGo memo sub
    (r, memo.insert e r)

@[inherit_doc fvarRangeGo]
def fvarRangeMemo (e : Expr) : Nat := (fvarRangeGo {} e).1

/-- **The loose-bvar bound the checker reads**: the packed field, or —
on the saturated branch alone — the exact memoized recomputation.
Equal to `Expr.bvarBound` unconditionally (`bvarB_eq`). -/
@[inline] def bvarB (e : Expr) : Nat :=
  let r := e.bvarBRaw
  if r == satRange then bvarBoundMemo e else r

/-- **The fvar range the checker reads**: the packed field, or — on the
saturated branch alone — the exact memoized recomputation.  Equal to
`Expr.fvarRange` unconditionally (`fvarB_eq`). -/
@[inline] def fvarB (e : Expr) : Nat :=
  let r := e.fvarBRaw
  if r == satRange then fvarRangeMemo e else r



end ConLeche.Expr
end -- supplemental source scope
/- END exact supplemental slice saturated_ranges -/

/- BEGIN full source origin ConLeche.Kernel.FEnv -/
-- Cached bundle origin 00, original line 1: module

-- Cached bundle origin 00, original line 3: public import ConLeche.Kernel.Core

section

/-!
# `FEnv`: the environment with a name index

The spec environment together with a name index whose lookup function
agrees with `Env.find?`, built once per top-level entry call, plus the
`Env`-guard twins that read through it (`natLitSupportedF`,
`strLitSupportedF`, `natOpGuardF`, `natOpStoredF`).

**Representation-free.**  Nothing here mentions an expression
representation: `FEnv` indexes `ConstantInfo`s by `Name`, and the four
guards ask only about the constants an environment holds.  Both
executable cores read the environment through it, and the F-mirror
agreement (`ConLeche/Verify/EnvBound.lean`) is stated about it.  The
`F` suffix on the guards reads "through the index".
-/

namespace ConLeche
/-! ## The indexed environment -/

/-- The spec environment together with a name index whose lookup function
agrees with `Env.find?` (built once per top-level entry call).

Every index entry carries its **installation counter** — the number of
constants installed before it, i.e. its position counted from the bottom
of `env.consts` — and the environment carries a **visibility bound**,
`visibleBelow`: `find?` returns `none` for an entry whose counter is at
or above the bound, so a single `FEnv` value answers lookups against any
*prefix* of itself at `O(1)` (task #108; a field comparison on the entry
— never a filtered copy or a second environment value).  `visibleBelow`
doubles as the next counter to hand out, so on the ordinary
install-and-check path it is exactly `env.consts.length` and nothing is
ever hidden (`mkFEnv_find?`); lowering it to `k` is the prefix view of
the first `k` installed constants (`mkFEnv_find?_visibleBelow`,
`ConLeche/Verify/EnvBound.lean`). -/
structure FEnv where
  env : Env
  idx : Std.HashMap Name (Nat × ConstantInfo)
  /-- Entries with counter `< visibleBelow` are visible; also the next
  counter `push` hands out. -/
  visibleBelow : Nat

/-- The index build, from the back: the newest (front) constant is
inserted last and wins, exactly as `List.find?` takes the first match —
so the agreement with `Env.find?` is unconditional (no freshness
assumption).  The `Nat` component is the running counter, so the build
stays linear (the tail's length is returned, not recomputed). -/
def mkFEnvGo : List ConstantInfo → Nat × Std.HashMap Name (Nat × ConstantInfo)
  | [] => (0, ∅)
  | ci :: cs =>
    let p := mkFEnvGo cs
    (p.1 + 1, p.2.insert ci.name (p.1, ci))

/-- Build the index of `env`, with nothing hidden (`visibleBelow` is the
constant count). -/
def mkFEnv (env : Env) : FEnv :=
  let p := mkFEnvGo env.consts
  ⟨env, p.2, p.1⟩

namespace FEnv

/-- Indexed lookup, bounded by the visibility counter (`= Env.find?` for
`mkFEnv`, which hides nothing). -/
def find? (fe : FEnv) (n : Name) : Option ConstantInfo :=
  match fe.idx[n]? with
  | some (c, ci) => if c < fe.visibleBelow then some ci else none
  | none => none

/-- Restrict the view to the first `k` installed constants (task #108).
`O(1)`: a field update on the single linearly-threaded index. -/
def restrictTo (fe : FEnv) (k : Nat) : FEnv :=
  { fe with visibleBelow := k }

/-- The index of the cons-extended environment (`push_mkFEnv`:
`FEnv.push (mkFEnv env) ci = mkFEnv ⟨ci :: env.consts⟩`, definitionally).
The new entry gets the next installation counter, and the visibility
bound advances with it — so a push is visible to everything checked
after it and to nothing checked before (task #108). -/
def push (fe : FEnv) (ci : ConstantInfo) : FEnv :=
  ⟨⟨ci :: fe.env.consts⟩, fe.idx.insert ci.name (fe.visibleBelow, ci),
   fe.visibleBelow + 1⟩

/-- Indexed projection-table lookup (`= Env.findProj?` for `mkFEnv`). -/
def findProj? (fe : FEnv) (T : Name) (i : Nat) : Option ProjEntry :=
  match fe.find? (projTableName T) with
  | some (.projInfo tbl) => if i < tbl.numFields then some (tbl.entry i) else none
  | _ => none

/-- `towerSlotsAll` through the index. -/
def towerSlotsAllF (fe : FEnv) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j => (fe.findProj? T j).isSome

/-- `andRescueSlots` through the index. -/
def andRescueSlotsF (fe : FEnv) (ctor : Name) (nP : Nat) (ust : List Level) : Bool :=
  andRescueSlotsOf fe.findProj? ctor nP ust

/-- `recSlotsAll` through the index. -/
def recSlotsAllF (fe : FEnv) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j =>
    match fe.find? (projFnName T j) with
    | some (.recInfo _ _ _ _) => true
    | _ => false

end FEnv

/-! ### Indexed guard twins (same result as the `Env` versions) -/

/-- `natLitSupported` through the index. -/
def natLitSupportedF (fe : FEnv) : Bool :=
  natIndOk (fe.find? natName) && natZeroOk (fe.find? natZeroName) &&
    natSuccOk (fe.find? natSuccName)

/-- `strLitSupported` through the index. -/
def strLitSupportedF (fe : FEnv) : Bool :=
  natLitSupportedF fe &&
    stringTyOk (fe.find? stringName) &&
    stringOfListTyOk (fe.find? stringOfListName) &&
    listTyOk (fe.find? listName) &&
    listNilTyOk (fe.find? listNilName) &&
    listConsTyOk (fe.find? listConsName) &&
    charTyOk (fe.find? charName) &&
    charOfNatTyOk (fe.find? charOfNatName)

/-- `natOpGuard` through the index. -/
def natOpGuardF (fe : FEnv) (c : Name) : Bool :=
  natLitSupportedF fe &&
  (natOpDeps c).all (fun n => match fe.find? n with
    | some (.defnInfo cv _ _) => cv.levelParams.isEmpty
    | _ => false) &&
  (if c = natBeqName || c = natBleName || natDivModNames.contains c then
    (match fe.find? boolTrueName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false) &&
    (match fe.find? boolFalseName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false)
   else true)

/-- `natOpStored` through the index (task #161 item B3). -/
def natOpStoredF (fe : FEnv) (c : Name) : Bool :=
  match fe.find? c with
  | some (.defnInfo _ _ _) => true
  | _ => false
end ConLeche

end -- original EOF public section of ConLeche.Kernel.FEnv
/- END full source origin ConLeche.Kernel.FEnv -/

/- BEGIN full source origin ConLeche.Cached.ExprNodes -/
-- Cached bundle origin 01, original line 1: module

-- Cached bundle origin 01, original line 3: public import Std.Data.HashMap
-- Cached bundle origin 01, original line 4: public import ConLeche.Kernel.Expr

section

/-!
# The node constructors, and the trust census of the one expression type

There is **one** expression type, `ConLeche.Expr`, carrying its
derived fields as Lean `@[computed_field]`s (`ConLeche/Kernel/Expr.lean`;
tasks #172 B3a, #285).  The executed, memoized operations live in its
namespace beside the pure specs they are proved equal to, under a `C`
suffix wherever the spec already owns the name (`instantiate1C`,
`wscopedBC`, …); this module holds the node constructors they build
with.  The fields being the compiler's, there is no smart-constructor
discipline to maintain, and with the hash a *function* of the node the
executed equality's specification is plain decidable equality.

Equality (`Expr.beq`) is the official kernel's: pointer equality
first, then the computed hashes, then structural descent.  Together
with the `O(1)` `Hashable` instance this is what makes
`Std.HashMap Expr α` a viable memo key without a hash-consing table.
Terms are shared *naturally*, by Lean's own structure sharing: the
operations return their children by reference, so the result of an
instantiation shares every unchanged subterm with its input, and the
pointer test then decides equality of those subterms in O(1) exactly
as an arena index comparison does.

## THE TRUST CENSUS (task #172 B3a) — the escapes, all of them

`#print axioms` measures the *proof* term; an
`implemented_by` escape is invisible to both, so the escapes are
enumerated here by hand and this list is the pin.  It has ONE row.

1. **The `@[computed_field]` machinery**.  The per-node derived
   data (`hash`, `bvarB`, `fvarB`, `hasLP` — since task #167 one
   packed `UInt64`, `Expr.data`; since task #176 P3 also
   `Name.hashData` and `Level.hashData`, the cached hashes
   `Lean.Name`/`Lean.Level` and the C++ kernel keep too) is declared
   in the inductive's `with`
   block; logically it is an ordinary recursive function, and the
   *agreement between the stored word and that function is the code
   generator's*, not a theorem of this repository.  `Lean/Elab/ComputedFields.lean:33`, verbatim: *"This
   file implements the computed fields feature by simulating it via
   `implemented_by`."*  Hence it is an escape, and it is likewise
   invisible to `#print axioms`.

   **USER RULING, 2026-09-04, verbatim:** *"Adopt computed_fields.
   It's a compiler feature, we trust the compiler."*

   What the row buys: the field functions reduce definitionally on
   constructors, so no hand-rolled field invariant is needed.  The
   escape replaces a hand-maintained discipline (every construction
   site must use a smart constructor) with the compiler's own, on the
   feature `Lean.Expr` itself is built from.

**Why the equalities are not rows.**  The pointer-first
`Name.beqPtr`/`Level.beqPtr` and the pointer-first, memoised
`Expr.beqMemo` (`ConLeche/Kernel/Name.lean`, `ConLeche/Kernel/Expr.lean`)
replace `Name.beq`/`Level.beq`/`Expr.beq` in compiled code through
**`@[csimp]`**, i.e. on the strength of a *kernel-checked equality*
(`Name.beq_eq_beqPtr`, `Level.beq_eq_beqPtr`, `Expr.beq_eq_beqMemo`) —
**USER RULING, 2026-09-05, verbatim:** *"do *not* use
`implemented_by`.  If you can prove them equal, use `csimp`."*  A
`csimp` substitution is not an escape at all: the compiler is licensed
by a theorem this repository proves, not by an unchecked attribute.
The address reads behind them go through `Init.Util`'s `withPtrEq` and
`withPtrAddr`, whose side conditions those files discharge, and the
equality memo carries its invariant in its value type (`Expr.EqPair`)
and verifies every hit by identity.  The tree's compiler-escape scan
(`tests/trust-surface.sh`) is the gate that keeps the census at this
one row.
-/

namespace ConLeche.Expr

/-! ## The constructors

Under `@[computed_field]` the compiler computes the derived fields, so
each of these is the plain constructor.  The names survive because they are the term the whole
cached tier and its verification are written in; each is `@[inline]`,
so nothing is added at runtime. -/

@[inline] def mkFVar (idx : Nat) (ty : Expr) : Expr :=
  .fvar idx ty

@[inline] def mkSort (u : Level) : Expr := .sort u

@[inline] def mkConst (n : Name) (us : List Level) : Expr := .const n us

@[inline] def mkApp (f a : Expr) : Expr := .app f a

@[inline] def mkLam (ty body : Expr) (m : BinderMeta) : Expr :=
  .lam ty body m

@[inline] def mkForallE (ty body : Expr) (m : BinderMeta) :
    Expr := .forallE ty body m

@[inline] def mkLetE (ty val body : Expr) : Expr :=
  .letE ty val body

@[inline] def mkLit (l : Literal) : Expr := .lit l

@[inline] def mkProj (s : Name) (i : Nat) (e : Expr) : Expr := .proj s i e

/-! ## Equality, hashing and the trust census

Both live in `ConLeche/Kernel/Expr.lean`, with the type
itself: `BEq Expr` must be **one** instance tree-wide (the pure tier
compares `Expr`s too, and two defeq-but-distinct instances make `rw`
and `simp` fail across the seam — measured, on `DiscC5`'s `defeqStep`
simulation).  `Expr.beq` is `Expr.beq`, verified there (`Expr.beqMemo_eq`); the
trust census is this module's header. -/

/-! ### The constructor equations

`mkApp f a = .app f a` and its nine siblings, all `rfl`; the cached
tier rewrites with them.  That every node's derived data satisfies its
recurrence is the compiler's (the census row above). -/

@[simp] theorem mkFVar_eq (idx : Nat) (ty : Expr) :
    mkFVar idx ty = .fvar idx ty := rfl

@[simp] theorem mkSort_eq (u : Level) : mkSort u = .sort u := rfl

@[simp] theorem mkConst_eq (n : Name) (us : List Level) :
    mkConst n us = .const n us := rfl

@[simp] theorem mkApp_eq (f a : Expr) : mkApp f a = .app f a := rfl

@[simp] theorem mkLam_eq (ty b : Expr) (m : BinderMeta) :
    mkLam ty b m = .lam ty b m := rfl

@[simp] theorem mkForallE_eq (ty b : Expr) (m : BinderMeta) :
    mkForallE ty b m = .forallE ty b m := rfl

@[simp] theorem mkLetE_eq (ty v b : Expr) :
    mkLetE ty v b = .letE ty v b := rfl

@[simp] theorem mkLit_eq (l : Literal) : mkLit l = .lit l := rfl

@[simp] theorem mkProj_eq (s : Name) (i : Nat) (e : Expr) :
    mkProj s i e = .proj s i e := rfl

end ConLeche.Expr

end -- original EOF public section of ConLeche.Cached.ExprNodes
/- END full source origin ConLeche.Cached.ExprNodes -/

/- BEGIN full source origin ConLeche.Cached.ExprOpsC -/
-- Cached bundle origin 02, original line 1: module

-- Cached bundle origin 02, original line 3: public import ConLeche.Cached.ExprNodes
-- Cached bundle origin 02, original line 4: public import ConLeche.Kernel.Core

section

-- Explicit universe for the original PEnt.hit and BEnt.hit signatures.
universe u

/-!
# The cached syntactic operations on `Expr`

The **executed**, memoized syntactic operations; the derived data they
cut off on is a field of the node.  Two structural facts, both
load-bearing for performance:

* the scope and definedness walks' memos are keyed on `Expr` itself
  (`O(1)` hashing off the cached field, pointer-first equality), so
  shared sub-DAGs are still visited once (`Std.HashMap Expr α`).  The
  SUBSTITUTION walks key theirs by address instead; see "The
  substitution walks" below;
* a cutoff (`bvarB ≤ d`, `fvarB ≤ d`, `!hasLP`) returns the node
  **itself**, so the result shares memory with the input and later
  pointer comparisons on it are `O(1)`.
-/

namespace ConLeche.Expr

/-! ## Spines -/

/-- Prepend the spine arguments of `e` to `acc` (outermost last). -/
def getAppArgsAccC : Expr → List Expr → List Expr
  | .app f a .., acc => getAppArgsAccC f (a :: acc)
  | _, acc => acc

/-- The arguments of an application spine, outermost last. -/
@[inline] def getAppArgsC (e : Expr) : List Expr := getAppArgsAccC e []

/-! ## The substitution walks (tasks #314, #316, #317)

ONE walk per operation — `instantiate1XP`, `instantiate1LiftXP`,
`instantiateListXP`, `instantiateRevXP`, `abstract1XP`,
`abstractRangeXP`, `instLevelParamsXP` — and ONE memo discipline.  The
design, as landed:

* **Memoise only what is shared.**  At every compound node past the
  cutoff the walk asks `withExclusive`
  (`ConLeche/Kernel/Exclusive.lean`) whether the node is an EXCLUSIVE
  object — single-threaded, reference count 1.  An exclusive node
  cannot be reached twice, so it is rebuilt with the memo untouched:
  no key, no probe, no insert.  A shared node (count `> 1`,
  multi-threaded, or persistent — the installed environment) is
  probed and, on a miss, recorded after the rebuild.  The table is
  created at the first shared compound node (`none` until then); the
  root is never probed (it cannot be reached again within its own
  walk).  The official kernel's `replace_fn` caches exactly the
  `!is_likely_unshared(e)` nodes.
* **Key the memo by address and cursor.**  The key is the node's
  address, read by `withPtrAddr` (`Expr.withAddr`) at the top of the
  shared step, packed with the cursor into one `Nat` (`pkey`) — a
  scalar, no allocation, no structural hash.  The table is a
  `Std.HashMap` on that key.
* **Validate a hit by pointer identity.**  A probe that returns an
  entry is believed only after `Expr.ptrDec` (`withPtrEq`, the
  pointer comparison at runtime and the derived structural decision
  in the model) says the stored node IS the current one, and the
  cursors compare equal.  The address is therefore never trusted: a
  wrong key can only cost a rebuild, never a value.
* **Every entry is self-proving.**  A `PEnt` stores its node, its
  rebuild, its cursor and the proof `val = s node depth`.  So there is
  **no table invariant** — the table may be anything, may grow and may
  overwrite — and a validated hit yields the proof the walk's result
  type demands by rewriting along the two equalities.  This is the
  `BeqMap`/`EqPair`/`probeHit` shape of `Expr.beqGoX`, applied to the
  walks.
* **No cutoff.**  The walk is exact: it memoises every shared compound
  node it meets, for as long as the walk lasts, and nothing bounds the
  table.  The node budget of task #313 — a heuristic that stopped
  memoising after 256 nodes and restarted — is gone (task #317).

**The borrowed-parameter convention is a REQUIREMENT, not an
optimisation.**  The node is borrowed (`@&`) all the way down, and so
is the replacement.  An owned parameter is a reference of its own, and
the count `withExclusive` reads would then be "in-tree references
+ 1" — every child of a held root would answer shared, and the memo
would degenerate to the always-memoised walk.  Borrowed, the count is
the number of references INSIDE the term (plus the caller's at the
root, which is never asked), which is the question the memo exists to
answer.  **How this is checked**: by reading the generated C of every
walk (`.lake/build/ir/ConLeche/Cached/ExprOpsC.c`) for a surviving
`lean_inc_ref` of the node before `lean_is_exclusive_obj` — the IR
audits of the task #314 and #316 records (DESIGN.md).  A change to
these walks that drops a `@&` or lets a `let`, a closure or a `Prod`
hold the node across the check is silently correct and measurably
slower; the audit is what catches it.

**Verification is intrinsic** (the `Expr.beqGoX` shape): a walk returns
a `Squash` of the rebuilt term with its proof of equality to the PLAIN
descent (`*P`, the reference — `Verify/Cached/OpsC.lean` proves each
`*P` equal to the specification) beside the memo, which is
unobservable.  The result is a `Subsingleton`, which is the obligation
`withExclusive` and `withPtrAddr` each ask of their continuation — so
the wrapper's theorem holds whatever the reference count and the
address are, by the primitives' contracts, never by a case analysis on
either.  Each walk's `enter*P` is the child step: the cutoff, the
compound test, then the exclusivity read; its `rec` argument is the
descent itself, inlined, so the recursive call is applied to the
subterm and termination is the walk's own.

Nothing here adds to the trust surface beyond the one allowlisted
escape: `withPtrAddr` and `withPtrEq` are `Init.Util`'s (and the tree
already relies on both, in `Expr.beqGoX` and `Name.beq`), and
`withExclusive` is `ConLeche/Kernel/Exclusive.lean`'s — the walks' one
`unsafe`-implemented primitive, whose module docstring is the
justification `tests/trust-surface.sh` points at. -/

/-- The nodes a memo entry can save a descent of. -/
@[inline] def isCompound : Expr → Bool
  | .app .. | .lam .. | .forallE .. | .letE .. | .proj .. => true
  | _ => false

/-- The term of a walk's result (the quotient lifts: the term is fixed
by its subtype). -/
@[inline] def resTerm {c : Expr} {M : Type} (s : Squash ({ r : Expr // r = c } × M)) : Expr :=
  Quotient.lift (fun p => p.1.1) (fun p q _ => by rw [p.1.2, q.1.2]) s

/-- What the term of a walk's result is: the value its subtype names.
Whatever the exclusivity reads and the addresses were along the
way. -/
theorem resTerm_eq {c : Expr} {M : Type} (s : Squash ({ r : Expr // r = c } × M)) :
    resTerm s = c := by
  induction s using Quotient.ind with
  | _ p => exact p.1.2

/-! ### The memo

The key is the node's ADDRESS packed with the cursor into one `Nat`
(`pkey`: addresses are 8-byte aligned, so `addr / 8`, then the cursor
modulo `2^16` in the low bits — pure register arithmetic, a tagged
scalar, no allocation and no structural hash), and the table is a
`Std.HashMap` on it under a MIXING hash (the address bits are dense;
`hash64` is what `Lean.Ptr` uses, and the identity hash of `Nat` would
cluster them after Std's fold — the intern table's lesson of task
#89).

A structural key `(e, c)` was what the walks used before task #316: a
`Prod` allocation per entry, the node's cached hash mixed with the
cursor, and a `beq` on every probe.  The C++ kernel's `replace_fn`
pays none of that — its cache is an `unordered_map` on the raw `expr`
pointer and the offset — and neither does this.

The price of the cheap key is that the key alone proves nothing, so
the entry does: `PEnt` stores its node, its rebuild, its cursor and
the proof, and `PEnt.hit` believes a probe only after the cursors
compare equal and `Expr.ptrDec` says the stored node IS the current
one.  A key collision (an address reused within one walk cannot happen
— every recorded node is held by its entry and the root by the caller
— but nothing here depends on that) fails validation and is a miss.
Hence **no table invariant at all**: the table may grow, rehash and
overwrite freely, and no lemma about it is needed.

`withPtrAddr`'s own obligation is discharged the same way the rest of
the section's are: the continuation of the address read is the whole
shared-node step and returns a `Squash`, so it is `Subsingleton.elim`
(`Expr.withAddr`).  The address may choose HOW the walk computes —
which slot, which entry is consulted — never WHAT. -/

/-- The packed key: the node's address over its 8-byte alignment,
then the cursor modulo `2^16` in the low bits.  Pure `UInt64` register
arithmetic; a tagged scalar as a `Nat` (addresses are below `2^47`).
In the model the address is `0` and the key is the cursor — the
tables never rely on the key: an entry validates itself. -/
@[inline] def pkey (addr : USize) (c : Nat) : Nat :=
  (addr.toUInt64 / 8 * 65536 + (UInt64.ofNat c &&& 65535)).toNat

/-- A memo entry: the node it was made for, its rebuild, the cursor,
and the proof — the entry is its own invariant. -/
structure PEnt (s : Expr → Nat → Expr) where
  node : Expr
  val : Expr
  depth : Nat
  eq : val = s node depth

/-- A validated hit: the cursor compares equal and the stored node IS
the current one (by pointer at runtime — `Expr.ptrDec` — structurally
in the model); then the entry's proof is the walk's. -/
@[inline] def PEnt.hit {s : Expr → Nat → Expr} {β : Sort u} (p : PEnt s) (e : Expr) (c : Nat)
    (k : { r : Expr // r = s e c } → β) (miss : Unit → β) : β :=
  if hd : p.depth = c then
    match Expr.ptrDec p.node e with
    | isTrue hn => k ⟨p.val, by rw [p.eq, hn, hd]⟩
    | isFalse _ => miss ()
  else miss ()

/-- The hash-map variant's key: the packed `Nat` under a MIXING hash —
the identity hash of `Nat` clusters dense address bits after Std's
fold (the intern table's lesson, task #89). -/
structure PKey where
  val : Nat

instance : BEq PKey := ⟨fun a b => a.val == b.val⟩
instance : Hashable PKey := ⟨fun k => hash64 (UInt64.ofNat k.val)⟩

/-- The hash-map table: the incumbent's `Std.HashMap`, keyed by the
packed address instead of the structural pair. -/
abbrev HTab (s : Expr → Nat → Expr) := Std.HashMap PKey (PEnt s)

/-- The pointer-keyed memo: absent until the first shared compound
node. -/
abbrev MemoXP (s : Expr → Nat → Expr) := Option (HTab s)

/-- A pointer-keyed walk's result: the term, fixed by its proof,
beside the memo. -/
abbrev ResXP (s : Expr → Nat → Expr) (e : Expr) (c : Nat) :=
  { r : Expr // r = s e c } × MemoXP s

/-- The record: the entry under its packed key, in the table or in a
fresh one. -/
@[inline] def MemoXP.insert {s : Expr → Nat → Expr} (memo : MemoXP s) (key : Nat)
    (p : PEnt s) : MemoXP s :=
  match memo with
  | none => some (({} : HTab s).insert ⟨key⟩ p)
  | some m => some (m.insert ⟨key⟩ p)

/-- The shared-node step over the pointer-keyed memo: the address
read, the probe, the validated hit — else the descent and the record
under the key read BEFORE the descent (the result is a `Squash`, so
the address is unobservable: `withAddr`). -/
@[inline] def MemoXP.shared {s : Expr → Nat → Expr} (memo : MemoXP s) (e : Expr) (c : Nat)
    (rec : Unit → Squash (ResXP s e c)) : Squash (ResXP s e c) :=
  withAddr e fun addr =>
  let key := pkey addr c
  match memo with
  | none => Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
      Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, r, c, hr⟩)
  | some m =>
    match m[(⟨key⟩ : PKey)]? with
    | some p => p.hit e c (fun r => Squash.mk (r, memo)) fun _ =>
        Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
          Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, r, c, hr⟩)
    | none => Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
        Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, r, c, hr⟩)

/-- The cursor-free instance (`instLevelParams`): the cursored memo at
cursor `0`. -/
abbrev MemoXP0 (s : Expr → Expr) := MemoXP (fun e _ => s e)

abbrev ResXP0 (s : Expr → Expr) (e : Expr) := { r : Expr // r = s e } × MemoXP0 s

@[inline] def MemoXP0.shared {s : Expr → Expr} (memo : MemoXP0 s) (e : Expr)
    (rec : Unit → Squash (ResXP0 s e)) : Squash (ResXP0 s e) :=
  MemoXP.shared (s := fun e _ => s e) memo e 0 rec

/-! ### `instantiate1LiftC` (task #214, P4)

The capture-avoiding substitution `Expr.instantiate1Lift` — the one
substitution on the direct install's executed path that once had no
memoised twin at all: `structProjBodies` runs it once per field over
the constructor telescope, turning a DAG-shared field type into an
unshared tree each time.  The twin is the section's walk, with the
`bvarB` cutoff (a node bounded at or below the cursor is returned
unchanged).  `instantiate1LiftC_spec`
(`ConLeche/Verify/Cached/OpsC.lean`) reads it as
`Expr.instantiate1Lift`. -/

/-- The plain descent of `instantiate1LiftC`: the reference
`instantiate1LiftXP` carries its own proof against. -/
def instantiate1LiftP (v : Expr) (e : Expr) (d : Nat) : Expr :=
  if e.bvarB ≤ d then e else
  match e with
  | .bvar i .. =>
    if i = d then Expr.liftLooseBVars d 0 v else if i > d then Expr.mkBvar (i - 1) else e
  | .fvar .. | .sort .. | .const .. | .lit .. => e
  | .app f a .. => mkApp (instantiate1LiftP v f d) (instantiate1LiftP v a d)
  | .lam ty body m .. =>
    mkLam (instantiate1LiftP v ty d) (instantiate1LiftP v body (d + 1)) m
  | .forallE ty body m .. =>
    mkForallE (instantiate1LiftP v ty d) (instantiate1LiftP v body (d + 1)) m
  | .letE ty val body .. =>
    mkLetE (instantiate1LiftP v ty d) (instantiate1LiftP v val d)
      (instantiate1LiftP v body (d + 1))
  | .proj sn i sub .. => mkProj sn i (instantiate1LiftP v sub d)

theorem instantiate1LiftP_cut {v e : Expr} {d : Nat} (h : e.bvarB ≤ d) :
    instantiate1LiftP v e d = e := by
  rw [instantiate1LiftP.eq_def]; simp [h]

/-- The child step of `instantiate1LiftXP`: the cutoff, the compound
test, the exclusivity read. -/
@[inline] def enterLiftP (v : @& Expr) (e : @& Expr) (d : Nat)
    (memo : MemoXP (instantiate1LiftP v))
    (rec : (hcut : ¬ e.bvarB ≤ d) → Squash (ResXP (instantiate1LiftP v) e d)) :
    Squash (ResXP (instantiate1LiftP v) e d) :=
  if hcut : e.bvarB ≤ d then Squash.mk (⟨e, (instantiate1LiftP_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e d fun _ => rec hcut

/-- The walk of `instantiate1LiftC`. -/
def instantiate1LiftXP (v : @& Expr) (memo : MemoXP (instantiate1LiftP v)) (e : @& Expr)
    (d : Nat) (hcut : ¬ e.bvarB ≤ d) : Squash (ResXP (instantiate1LiftP v) e d) :=
  match e with
  | .bvar i .. =>
    Squash.mk (⟨if i = d then Expr.liftLooseBVars d 0 v
        else if i > d then Expr.mkBvar (i - 1) else .bvar i,
      by rw [instantiate1LiftP]; simp [hcut]⟩, memo)
  | .fvar idx ty .. => Squash.mk (⟨.fvar idx ty, by rw [instantiate1LiftP]; simp [hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by rw [instantiate1LiftP]; simp [hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by rw [instantiate1LiftP]; simp [hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by rw [instantiate1LiftP]; simp [hcut]⟩, memo)
  | .app f a .. =>
    enterLiftP v f d memo (fun h => instantiate1LiftXP v memo f d h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterLiftP v a d memo (fun h => instantiate1LiftXP v memo a d h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by rw [instantiate1LiftP.eq_def, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterLiftP v ty d memo (fun h => instantiate1LiftXP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLiftP v body (d + 1) memo (fun h => instantiate1LiftXP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by rw [instantiate1LiftP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterLiftP v ty d memo (fun h => instantiate1LiftXP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLiftP v body (d + 1) memo (fun h => instantiate1LiftXP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by rw [instantiate1LiftP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterLiftP v ty d memo (fun h => instantiate1LiftXP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLiftP v val d memo (fun h => instantiate1LiftXP v memo val d h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterLiftP v body (d + 1) memo (fun h => instantiate1LiftXP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by rw [instantiate1LiftP.eq_def, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterLiftP v sub d memo (fun h => instantiate1LiftXP v memo sub d h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by rw [instantiate1LiftP.eq_def, ite_eq_right hcut, hs]⟩, memo)

/-- The cached `Expr.instantiate1Lift`: the cutoff, then the walk. -/
def instantiate1LiftC (e : @& Expr) (v : Expr) (d : Nat := 0) : Expr :=
  if hcut : e.bvarB ≤ d then e else
  resTerm (instantiate1LiftXP v none e d hcut)

/-- The plain descent of `instantiate1C`: the reference the walk is
verified against (`instantiate1P_spec`, `Verify/Cached/OpsC.lean`, is
the equation to `Expr.instantiate1`). -/
def instantiate1P (v : Expr) (e : Expr) (d : Nat) : Expr :=
  if e.bvarB ≤ d then e else
  match e with
  | .bvar i .. => if i = d then v else if i > d then Expr.mkBvar (i - 1) else e
  | .fvar .. | .sort .. | .const .. | .lit .. => e
  | .app f a .. => mkApp (instantiate1P v f d) (instantiate1P v a d)
  | .lam ty body m .. => mkLam (instantiate1P v ty d) (instantiate1P v body (d + 1)) m
  | .forallE ty body m .. =>
    mkForallE (instantiate1P v ty d) (instantiate1P v body (d + 1)) m
  | .letE ty val body .. =>
    mkLetE (instantiate1P v ty d) (instantiate1P v val d) (instantiate1P v body (d + 1))
  | .proj sn i sub .. => mkProj sn i (instantiate1P v sub d)

theorem instantiate1P_cut {v e : Expr} {d : Nat} (h : e.bvarB ≤ d) :
    instantiate1P v e d = e := by
  rw [instantiate1P.eq_def]; simp [h]

/-- The child step of `instantiate1XP`: the cutoff, the compound test,
the exclusivity read. -/
@[inline] def enter1P (v : @& Expr) (e : @& Expr) (d : Nat) (memo : MemoXP (instantiate1P v))
    (rec : (hcut : ¬ e.bvarB ≤ d) → Squash (ResXP (instantiate1P v) e d)) :
    Squash (ResXP (instantiate1P v) e d) :=
  if hcut : e.bvarB ≤ d then Squash.mk (⟨e, (instantiate1P_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e d fun _ => rec hcut

/-- The walk of `instantiate1C` (the node is past the cutoff: the
wrapper and `enter1P` test it). -/
def instantiate1XP (v : @& Expr) (memo : MemoXP (instantiate1P v)) (e : @& Expr) (d : Nat)
    (hcut : ¬ e.bvarB ≤ d) : Squash (ResXP (instantiate1P v) e d) :=
  match e with
  | .bvar i .. =>
    Squash.mk (⟨if i = d then v else if i > d then Expr.mkBvar (i - 1) else .bvar i,
      by rw [instantiate1P]; simp [hcut]⟩, memo)
  | .fvar idx ty .. => Squash.mk (⟨.fvar idx ty, by rw [instantiate1P]; simp [hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by rw [instantiate1P]; simp [hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by rw [instantiate1P]; simp [hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by rw [instantiate1P]; simp [hcut]⟩, memo)
  | .app f a .. =>
    enter1P v f d memo (fun h => instantiate1XP v memo f d h) |>.lift fun (⟨f', hf⟩, memo) =>
    enter1P v a d memo (fun h => instantiate1XP v memo a d h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by rw [instantiate1P.eq_def, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enter1P v ty d memo (fun h => instantiate1XP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enter1P v body (d + 1) memo (fun h => instantiate1XP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by rw [instantiate1P.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enter1P v ty d memo (fun h => instantiate1XP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enter1P v body (d + 1) memo (fun h => instantiate1XP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by rw [instantiate1P.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enter1P v ty d memo (fun h => instantiate1XP v memo ty d h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enter1P v val d memo (fun h => instantiate1XP v memo val d h) |>.lift fun (⟨v', hv⟩, memo) =>
    enter1P v body (d + 1) memo (fun h => instantiate1XP v memo body (d + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by rw [instantiate1P.eq_def, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enter1P v sub d memo (fun h => instantiate1XP v memo sub d h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by rw [instantiate1P.eq_def, ite_eq_right hcut, hs]⟩, memo)

/-- The cached `Expr.instantiate1`: the cutoff, then the walk. -/
def instantiate1C (e : @& Expr) (v : Expr) (d : Nat := 0) : Expr :=
  if hcut : e.bvarB ≤ d then e else
  resTerm (instantiate1XP v none e d hcut)

/-- The plain descent of `instantiateListC`: the reference
`instantiateListXP` carries its own proof against. -/
def instantiateListP (vs : Array Expr) (e : Expr) (k : Nat) (d : Nat) : Expr :=
  if k = 0 then e
  else if e.bvarB ≤ d then e
  else
    match e with
    | .bvar i .. =>
      if i < d then e
      else if _h : i - d < k then
        if h : i - d < vs.size then
          let w := vs[i - d]
          if i - d = 0 || w.bvarB ≤ d then w
          else instantiateListP vs w (i - d) d
        else e
      else Expr.mkBvar (i - k)
    | .fvar .. | .sort .. | .const .. | .lit .. => e
    | .app f a .. => mkApp (instantiateListP vs f k d) (instantiateListP vs a k d)
    | .lam ty body m .. => mkLam (instantiateListP vs ty k d) (instantiateListP vs body k (d + 1)) m
    | .forallE ty body m .. =>
      mkForallE (instantiateListP vs ty k d) (instantiateListP vs body k (d + 1)) m
    | .letE ty val body .. =>
      mkLetE (instantiateListP vs ty k d) (instantiateListP vs val k d) (instantiateListP vs body k (d + 1))
    | .proj sn i sub .. => mkProj sn i (instantiateListP vs sub k d)
termination_by (k, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.right; simp +arith +decide)
    | (apply Prod.Lex.left; omega)

theorem instantiateListP_cut {vs : Array Expr} {e : Expr} {k d : Nat} (h : e.bvarB ≤ d) :
    instantiateListP vs e k d = e := by
  rw [instantiateListP.eq_def]; simp [h]

/-- (Task #316, the pointer-keyed twin.) The child step of `instantiateListXP` (`k` is the parent's live prefix). -/
@[inline] def enterListP (vs : @& Array Expr) (e : @& Expr) (k d : Nat)
    (memo : MemoXP (fun e d => instantiateListP vs e k d))
    (rec : (hcut : ¬ e.bvarB ≤ d) → Squash (ResXP (fun e d => instantiateListP vs e k d) e d)) :
    Squash (ResXP (fun e d => instantiateListP vs e k d) e d) :=
  if hcut : e.bvarB ≤ d then Squash.mk (⟨e, (instantiateListP_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e d fun _ => rec hcut

/-- The walk of the bulk instantiation.  The `bvar` arm's re-entry at
a replacement runs under a FRESH memo: it is the one place the live
prefix `k` shrinks, and `k` is not part of the key. -/
def instantiateListXP (vs : @& Array Expr) (k : Nat) (memo : MemoXP (fun e d => instantiateListP vs e k d))
    (e : @& Expr) (d : Nat) (hk : ¬ k = 0) (hcut : ¬ e.bvarB ≤ d) :
    Squash (ResXP (fun e d => instantiateListP vs e k d) e d) :=
  match e with
  | .bvar i .. =>
    if hi : i < d then Squash.mk (⟨.bvar i, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut, hi]⟩, memo)
    else if _h : i - d < k then
      if h : i - d < vs.size then
        let w := vs[i - d]
        if h0 : i - d = 0 || w.bvarB ≤ d then
          Squash.mk (⟨w, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut, hi, _h, h, w, h0]⟩, memo)
        else
          have h0' : ¬ i - d = 0 ∧ ¬ w.bvarB ≤ d := by
            simpa only [Bool.or_eq_true, decide_eq_true_eq, not_or] using h0
          instantiateListXP vs (i - d) none w d h0'.1 h0'.2 |>.lift fun (⟨r, hr⟩, _) =>
          Squash.mk (⟨r, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut, hi, _h, h, w, h0, hr]⟩, memo)
      else Squash.mk (⟨.bvar i, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut, hi, _h, h]⟩, memo)
    else Squash.mk (⟨Expr.mkBvar (i - k), by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut, hi, _h]⟩, memo)
  | .fvar idx ty .. => Squash.mk (⟨.fvar idx ty, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by dsimp only; rw [instantiateListP.eq_def]; simp [hk, hcut]⟩, memo)
  | .app f a .. =>
    enterListP vs f k d memo (fun h => instantiateListXP vs k memo f d hk h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterListP vs a k d memo (fun h => instantiateListXP vs k memo a d hk h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by dsimp only; rw [instantiateListP.eq_def, ite_eq_right hk, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterListP vs ty k d memo (fun h => instantiateListXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterListP vs body k (d + 1) memo (fun h => instantiateListXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by dsimp only; rw [instantiateListP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterListP vs ty k d memo (fun h => instantiateListXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterListP vs body k (d + 1) memo (fun h => instantiateListXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by dsimp only; rw [instantiateListP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterListP vs ty k d memo (fun h => instantiateListXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterListP vs val k d memo (fun h => instantiateListXP vs k memo val d hk h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterListP vs body k (d + 1) memo (fun h => instantiateListXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by dsimp only; rw [instantiateListP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterListP vs sub k d memo (fun h => instantiateListXP vs k memo sub d hk h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by dsimp only; rw [instantiateListP.eq_def, ite_eq_right hk, ite_eq_right hcut, hs]⟩, memo)
termination_by (k, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.right; simp +arith +decide)
    | (apply Prod.Lex.left; omega)

/-- The cached `Expr.instantiateList` (bulk): the cutoff, then the walk. -/
def instantiateListC (e : @& Expr) (vs : List Expr) (d : Nat := 0) : Expr :=
  match vs with
  | [] => e
  | v :: vs' =>
    let a := (v :: vs').toArray
    if hcut : e.bvarB ≤ d then e
    else resTerm (instantiateListXP a a.size none e d (by simp [a]) hcut)

/-- The plain descent of `instantiateRev` (as `instantiateListP` on
the reversed array): the reference of `instantiateRevXP`. -/
def instantiateRevP (vs : Array Expr) (e : Expr) (k : Nat) (d : Nat) : Expr :=
  if k = 0 then e
  else if e.bvarB ≤ d then e
  else
    match e with
    | .bvar i .. =>
      if i < d then e
      else if _h : i - d < k then
        if h : i - d < vs.size then
          let w := vs[vs.size - 1 - (i - d)]'(by omega)
          if i - d = 0 || w.bvarB ≤ d then w
          else instantiateRevP vs w (i - d) d
        else e
      else Expr.mkBvar (i - k)
    | .fvar .. | .sort .. | .const .. | .lit .. => e
    | .app f a .. => mkApp (instantiateRevP vs f k d) (instantiateRevP vs a k d)
    | .lam ty body m .. => mkLam (instantiateRevP vs ty k d) (instantiateRevP vs body k (d + 1)) m
    | .forallE ty body m .. =>
      mkForallE (instantiateRevP vs ty k d) (instantiateRevP vs body k (d + 1)) m
    | .letE ty val body .. =>
      mkLetE (instantiateRevP vs ty k d) (instantiateRevP vs val k d) (instantiateRevP vs body k (d + 1))
    | .proj sn i sub .. => mkProj sn i (instantiateRevP vs sub k d)
termination_by (k, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.right; simp +arith +decide)
    | (apply Prod.Lex.left; omega)

theorem instantiateRevP_cut {vs : Array Expr} {e : Expr} {k d : Nat} (h : e.bvarB ≤ d) :
    instantiateRevP vs e k d = e := by
  rw [instantiateRevP.eq_def]; simp [h]

/-- (Task #316, the pointer-keyed twin.) The child step of `instantiateRevXP` (`k` is the parent's live prefix). -/
@[inline] def enterRevP (vs : @& Array Expr) (e : @& Expr) (k d : Nat)
    (memo : MemoXP (fun e d => instantiateRevP vs e k d))
    (rec : (hcut : ¬ e.bvarB ≤ d) → Squash (ResXP (fun e d => instantiateRevP vs e k d) e d)) :
    Squash (ResXP (fun e d => instantiateRevP vs e k d) e d) :=
  if hcut : e.bvarB ≤ d then Squash.mk (⟨e, (instantiateRevP_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e d fun _ => rec hcut

/-- The walk of the bulk instantiation on a reversed accumulator.  The
`bvar` arm's re-entry at a replacement runs under a FRESH memo: it is
the one place the live prefix `k` shrinks, and `k` is not part of the
key. -/
def instantiateRevXP (vs : @& Array Expr) (k : Nat) (memo : MemoXP (fun e d => instantiateRevP vs e k d))
    (e : @& Expr) (d : Nat) (hk : ¬ k = 0) (hcut : ¬ e.bvarB ≤ d) :
    Squash (ResXP (fun e d => instantiateRevP vs e k d) e d) :=
  match e with
  | .bvar i .. =>
    if hi : i < d then Squash.mk (⟨.bvar i, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut, hi]⟩, memo)
    else if _h : i - d < k then
      if h : i - d < vs.size then
        let w := vs[vs.size - 1 - (i - d)]'(by omega)
        if h0 : i - d = 0 || w.bvarB ≤ d then
          Squash.mk (⟨w, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut, hi, _h, h, w, h0]⟩, memo)
        else
          have h0' : ¬ i - d = 0 ∧ ¬ w.bvarB ≤ d := by
            simpa only [Bool.or_eq_true, decide_eq_true_eq, not_or] using h0
          instantiateRevXP vs (i - d) none w d h0'.1 h0'.2 |>.lift fun (⟨r, hr⟩, _) =>
          Squash.mk (⟨r, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut, hi, _h, h, w, h0, hr]⟩, memo)
      else Squash.mk (⟨.bvar i, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut, hi, _h, h]⟩, memo)
    else Squash.mk (⟨Expr.mkBvar (i - k), by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut, hi, _h]⟩, memo)
  | .fvar idx ty .. => Squash.mk (⟨.fvar idx ty, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by dsimp only; rw [instantiateRevP.eq_def]; simp [hk, hcut]⟩, memo)
  | .app f a .. =>
    enterRevP vs f k d memo (fun h => instantiateRevXP vs k memo f d hk h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterRevP vs a k d memo (fun h => instantiateRevXP vs k memo a d hk h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by dsimp only; rw [instantiateRevP.eq_def, ite_eq_right hk, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterRevP vs ty k d memo (fun h => instantiateRevXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterRevP vs body k (d + 1) memo (fun h => instantiateRevXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by dsimp only; rw [instantiateRevP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterRevP vs ty k d memo (fun h => instantiateRevXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterRevP vs body k (d + 1) memo (fun h => instantiateRevXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by dsimp only; rw [instantiateRevP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterRevP vs ty k d memo (fun h => instantiateRevXP vs k memo ty d hk h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterRevP vs val k d memo (fun h => instantiateRevXP vs k memo val d hk h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterRevP vs body k (d + 1) memo (fun h => instantiateRevXP vs k memo body (d + 1) hk h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by dsimp only; rw [instantiateRevP.eq_def, ite_eq_right hk, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterRevP vs sub k d memo (fun h => instantiateRevXP vs k memo sub d hk h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by dsimp only; rw [instantiateRevP.eq_def, ite_eq_right hk, ite_eq_right hcut, hs]⟩, memo)
termination_by (k, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.right; simp +arith +decide)
    | (apply Prod.Lex.left; omega)

/-- Bulk instantiation on a reversed accumulator array: the cutoffs,
then the walk. -/
def instantiateRev (e : @& Expr) (vs : Array Expr) (d : Nat := 0) : Expr :=
  if hk : vs.size = 0 then e
  else if hcut : e.bvarB ≤ d then e
  else resTerm (instantiateRevXP vs vs.size none e d hk hcut)

/-! ## Abstraction -/

/-- The plain descent of `abstract1C`: the reference of
`abstract1XP`. -/
def abstract1P (d : Nat) (e : Expr) (k : Nat) : Expr :=
  if e.fvarB ≤ d then e else
  match e with
  | .fvar idx .. => if idx = d then Expr.mkBvar k else e
  | .bvar .. | .sort .. | .const .. | .lit .. => e
  | .app f a .. => mkApp (abstract1P d f k) (abstract1P d a k)
  | .lam ty body m .. => mkLam (abstract1P d ty k) (abstract1P d body (k + 1)) m
  | .forallE ty body m .. => mkForallE (abstract1P d ty k) (abstract1P d body (k + 1)) m
  | .letE ty val body .. =>
    mkLetE (abstract1P d ty k) (abstract1P d val k) (abstract1P d body (k + 1))
  | .proj sn i sub .. => mkProj sn i (abstract1P d sub k)

theorem abstract1P_cut {d : Nat} {e : Expr} {k : Nat} (h : e.fvarB ≤ d) :
    abstract1P d e k = e := by
  rw [abstract1P.eq_def]; simp [h]

/-- (Task #316.) The child step of `abstract1XP`, pointer-keyed. -/
@[inline] def enterAbs1P (d : Nat) (e : @& Expr) (k : Nat) (memo : MemoXP (abstract1P d))
    (rec : (hcut : ¬ e.fvarB ≤ d) → Squash (ResXP (abstract1P d) e k)) :
    Squash (ResXP (abstract1P d) e k) :=
  if hcut : e.fvarB ≤ d then Squash.mk (⟨e, (abstract1P_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e k fun _ => rec hcut

/-- The walk of `abstract1C`. -/
def abstract1XP (d : Nat) (memo : MemoXP (abstract1P d)) (e : @& Expr) (k : Nat)
    (hcut : ¬ e.fvarB ≤ d) : Squash (ResXP (abstract1P d) e k) :=
  match e with
  | .fvar idx ty .. =>
    Squash.mk (⟨if idx = d then Expr.mkBvar k else .fvar idx ty,
      by rw [abstract1P]; simp [hcut]⟩, memo)
  | .bvar i .. => Squash.mk (⟨.bvar i, by rw [abstract1P]; simp [hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by rw [abstract1P]; simp [hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by rw [abstract1P]; simp [hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by rw [abstract1P]; simp [hcut]⟩, memo)
  | .app f a .. =>
    enterAbs1P d f k memo (fun h => abstract1XP d memo f k h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterAbs1P d a k memo (fun h => abstract1XP d memo a k h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by rw [abstract1P.eq_def, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterAbs1P d ty k memo (fun h => abstract1XP d memo ty k h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbs1P d body (k + 1) memo (fun h => abstract1XP d memo body (k + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by rw [abstract1P.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterAbs1P d ty k memo (fun h => abstract1XP d memo ty k h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbs1P d body (k + 1) memo (fun h => abstract1XP d memo body (k + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by rw [abstract1P.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterAbs1P d ty k memo (fun h => abstract1XP d memo ty k h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbs1P d val k memo (fun h => abstract1XP d memo val k h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterAbs1P d body (k + 1) memo (fun h => abstract1XP d memo body (k + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by rw [abstract1P.eq_def, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterAbs1P d sub k memo (fun h => abstract1XP d memo sub k h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by rw [abstract1P.eq_def, ite_eq_right hcut, hs]⟩, memo)

/-- The cached `Expr.abstract1`: the cutoff, then the walk. -/
def abstract1C (e : @& Expr) (d : Nat) (k : Nat := 0) : Expr :=
  if hcut : e.fvarB ≤ d then e else
  resTerm (abstract1XP d none e k hcut)

/-- The plain descent of `abstractRangeC`: the reference of
`abstractRangeXP`. -/
def abstractRangeP (d k : Nat) (e : Expr) (c : Nat) : Expr :=
  if e.fvarB ≤ d then e else
  match e with
  | .fvar idx .. =>
    if d ≤ idx ∧ idx < d + k then Expr.mkBvar (c + (d + k - 1 - idx)) else e
  | .bvar .. | .sort .. | .const .. | .lit .. => e
  | .app f a .. => mkApp (abstractRangeP d k f c) (abstractRangeP d k a c)
  | .lam ty body m .. =>
    mkLam (abstractRangeP d k ty c) (abstractRangeP d k body (c + 1)) m
  | .forallE ty body m .. =>
    mkForallE (abstractRangeP d k ty c) (abstractRangeP d k body (c + 1)) m
  | .letE ty val body .. =>
    mkLetE (abstractRangeP d k ty c) (abstractRangeP d k val c)
      (abstractRangeP d k body (c + 1))
  | .proj sn i sub .. => mkProj sn i (abstractRangeP d k sub c)

theorem abstractRangeP_cut {d k : Nat} {e : Expr} {c : Nat} (h : e.fvarB ≤ d) :
    abstractRangeP d k e c = e := by
  rw [abstractRangeP.eq_def]; simp [h]

/-- (Task #316.) The child step of `abstractRangeXP`, pointer-keyed. -/
@[inline] def enterAbsRP (d k : Nat) (e : @& Expr) (c : Nat) (memo : MemoXP (abstractRangeP d k))
    (rec : (hcut : ¬ e.fvarB ≤ d) → Squash (ResXP (abstractRangeP d k) e c)) :
    Squash (ResXP (abstractRangeP d k) e c) :=
  if hcut : e.fvarB ≤ d then Squash.mk (⟨e, (abstractRangeP_cut hcut).symm⟩, memo)
  else if !isCompound e then rec hcut
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e c fun _ => rec hcut

/-- The walk of `abstractRangeC`. -/
def abstractRangeXP (d k : Nat) (memo : MemoXP (abstractRangeP d k)) (e : @& Expr) (c : Nat)
    (hcut : ¬ e.fvarB ≤ d) : Squash (ResXP (abstractRangeP d k) e c) :=
  match e with
  | .fvar idx ty .. =>
    Squash.mk (⟨if d ≤ idx ∧ idx < d + k then Expr.mkBvar (c + (d + k - 1 - idx))
        else .fvar idx ty,
      by rw [abstractRangeP]; simp [hcut]⟩, memo)
  | .bvar i .. => Squash.mk (⟨.bvar i, by rw [abstractRangeP]; simp [hcut]⟩, memo)
  | .sort u .. => Squash.mk (⟨.sort u, by rw [abstractRangeP]; simp [hcut]⟩, memo)
  | .const n us .. => Squash.mk (⟨.const n us, by rw [abstractRangeP]; simp [hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by rw [abstractRangeP]; simp [hcut]⟩, memo)
  | .app f a .. =>
    enterAbsRP d k f c memo (fun h => abstractRangeXP d k memo f c h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterAbsRP d k a c memo (fun h => abstractRangeXP d k memo a c h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by rw [abstractRangeP.eq_def, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterAbsRP d k ty c memo (fun h => abstractRangeXP d k memo ty c h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbsRP d k body (c + 1) memo (fun h => abstractRangeXP d k memo body (c + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' m, by rw [abstractRangeP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterAbsRP d k ty c memo (fun h => abstractRangeXP d k memo ty c h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbsRP d k body (c + 1) memo (fun h => abstractRangeXP d k memo body (c + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' m, by rw [abstractRangeP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterAbsRP d k ty c memo (fun h => abstractRangeXP d k memo ty c h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterAbsRP d k val c memo (fun h => abstractRangeXP d k memo val c h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterAbsRP d k body (c + 1) memo (fun h => abstractRangeXP d k memo body (c + 1) h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by rw [abstractRangeP.eq_def, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterAbsRP d k sub c memo (fun h => abstractRangeXP d k memo sub c h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by rw [abstractRangeP.eq_def, ite_eq_right hcut, hs]⟩, memo)

/-- The cached `Expr.abstractRange` (`k = 0` is the identity and skips
the traversal, as in the arena): the cutoff, then the walk. -/
def abstractRangeC (e : @& Expr) (d k : Nat) (c : Nat := 0) : Expr :=
  match k with
  | 0 => e
  | _ + 1 =>
    if hcut : e.fvarB ≤ d then e else
    resTerm (abstractRangeXP d k none e c hcut)

/-! ## Level instantiation -/

/-- The plain descent of `instLevelParams`: the reference of
`instLevelParamsXP`. -/
def instLevelParamsP (ks : List Name) (us : List Level) (e : Expr) : Expr :=
  if !e.hasLP then e else
  match e with
  | .bvar .. | .lit .. => e
  | .sort u .. => mkSort (Level.subst ks us u)
  | .const n vs .. => mkConst n (vs.map (Level.subst ks us))
  | .fvar idx ty .. => mkFVar idx (instLevelParamsP ks us ty)
  | .app f a .. => mkApp (instLevelParamsP ks us f) (instLevelParamsP ks us a)
  | .lam ty body m .. =>
    mkLam (instLevelParamsP ks us ty) (instLevelParamsP ks us body) ⟨Level.substPW ks us m.pw⟩
  | .forallE ty body m .. =>
    mkForallE (instLevelParamsP ks us ty) (instLevelParamsP ks us body)
      ⟨Level.substPW ks us m.pw⟩
  | .letE ty val body .. =>
    mkLetE (instLevelParamsP ks us ty) (instLevelParamsP ks us val)
      (instLevelParamsP ks us body)
  | .proj s i sub .. => mkProj s i (instLevelParamsP ks us sub)

theorem instLevelParamsP_cut {ks : List Name} {us : List Level} {e : Expr}
    (h : (!e.hasLP) = true) : instLevelParamsP ks us e = e := by
  rw [instLevelParamsP.eq_def]; simp [h]

/-- The child step of `instLevelParamsXP`: the cutoff, then the
exclusivity read on EVERY node past it — there is no compound test
here, since a `const` with level parameters is a `Level.subst` per
occurrence and worth recording. -/
@[inline] def enterLPP (ks : @& List Name) (us : @& List Level) (e : @& Expr)
    (memo : MemoXP0 (instLevelParamsP ks us))
    (rec : (hcut : ¬ (!e.hasLP) = true) → Squash (ResXP0 (instLevelParamsP ks us) e)) :
    Squash (ResXP0 (instLevelParamsP ks us) e) :=
  if hcut : (!e.hasLP) = true then Squash.mk (⟨e, (instLevelParamsP_cut hcut).symm⟩, memo)
  else withExcl e fun excl =>
    if excl then rec hcut else memo.shared e fun _ => rec hcut

/-- The walk of `instLevelParams`. -/
def instLevelParamsXP (ks : @& List Name) (us : @& List Level)
    (memo : MemoXP0 (instLevelParamsP ks us)) (e : @& Expr) (hcut : ¬ (!e.hasLP) = true) :
    Squash (ResXP0 (instLevelParamsP ks us) e) :=
  match e with
  | .bvar i .. => Squash.mk (⟨.bvar i, by rw [instLevelParamsP.eq_def, ite_eq_right hcut]⟩, memo)
  | .lit l .. => Squash.mk (⟨.lit l, by rw [instLevelParamsP.eq_def, ite_eq_right hcut]⟩, memo)
  | .sort u .. =>
    Squash.mk (⟨mkSort (Level.subst ks us u), by rw [instLevelParamsP.eq_def, ite_eq_right hcut]⟩, memo)
  | .const n vs .. =>
    Squash.mk (⟨mkConst n (vs.map (Level.subst ks us)),
      by rw [instLevelParamsP.eq_def, ite_eq_right hcut]⟩, memo)
  | .fvar idx ty .. =>
    enterLPP ks us ty memo (fun h => instLevelParamsXP ks us memo ty h) |>.lift fun (⟨t, ht⟩, memo) =>
    Squash.mk (⟨mkFVar idx t, by rw [instLevelParamsP.eq_def, ite_eq_right hcut, ht]⟩, memo)
  | .app f a .. =>
    enterLPP ks us f memo (fun h => instLevelParamsXP ks us memo f h) |>.lift fun (⟨f', hf⟩, memo) =>
    enterLPP ks us a memo (fun h => instLevelParamsXP ks us memo a h) |>.lift fun (⟨a', ha⟩, memo) =>
    Squash.mk (⟨mkApp f' a', by rw [instLevelParamsP.eq_def, ite_eq_right hcut, hf, ha]⟩, memo)
  | .lam ty body m .. =>
    enterLPP ks us ty memo (fun h => instLevelParamsXP ks us memo ty h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLPP ks us body memo (fun h => instLevelParamsXP ks us memo body h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLam ty' b' ⟨Level.substPW ks us m.pw⟩,
      by rw [instLevelParamsP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .forallE ty body m .. =>
    enterLPP ks us ty memo (fun h => instLevelParamsXP ks us memo ty h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLPP ks us body memo (fun h => instLevelParamsXP ks us memo body h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkForallE ty' b' ⟨Level.substPW ks us m.pw⟩,
      by rw [instLevelParamsP.eq_def, ite_eq_right hcut, ht, hb]⟩, memo)
  | .letE ty val body .. =>
    enterLPP ks us ty memo (fun h => instLevelParamsXP ks us memo ty h) |>.lift fun (⟨ty', ht⟩, memo) =>
    enterLPP ks us val memo (fun h => instLevelParamsXP ks us memo val h) |>.lift fun (⟨v', hv⟩, memo) =>
    enterLPP ks us body memo (fun h => instLevelParamsXP ks us memo body h) |>.lift fun (⟨b', hb⟩, memo) =>
    Squash.mk (⟨mkLetE ty' v' b', by rw [instLevelParamsP.eq_def, ite_eq_right hcut, ht, hv, hb]⟩, memo)
  | .proj sn i sub .. =>
    enterLPP ks us sub memo (fun h => instLevelParamsXP ks us memo sub h) |>.lift fun (⟨s', hs⟩, memo) =>
    Squash.mk (⟨mkProj sn i s', by rw [instLevelParamsP.eq_def, ite_eq_right hcut, hs]⟩, memo)

/-- The cached `Expr.instantiateLevelParams`: the cutoff, then the
walk. -/
def instLevelParams (ks : List Name) (us : List Level) (e : @& Expr) : Expr :=
  if hcut : (!e.hasLP) = true then e else
  resTerm (instLevelParamsXP ks us none e hcut)

/-- The cached `ProjEntry.typeAt`: the same two instantiations through
the memoized, **sharing-preserving** `instLevelParams` and
`instantiateListC` (`ProjEntry.typeAtI_eq`, `ConLeche/Verify/Cached/
OpsC.lean`, is the equation).

The executable `.proj` inference clause used to call the spec's
`ProjEntry.typeAt` directly — legitimate as a *value* (`Expr = Expr`)
but not as a *computation*: `Expr.instantiateList` is the unmemoized
tree walk, and its `bvar` arm re-traverses the replacement (`vs[j - d]`
under `vs.take (j - d)`), so every occurrence of the subject and of
every parameter in the field type came back as a fresh **tree copy**
of a term that was a DAG.  On a projection chain over a Mathlib
carrier (`(Classical.choice …).ColimitCocone.0.Cocone.0.CommRingCat.0`)
the copies nest, and at `AlgebraicGeometry.isAffine_of_isAffineOpen_basicOpen`
(subject tree 3.9 · 10⁸ nodes on a 3 106-node DAG) the copy alone is
the out-of-memory — DESIGN.md "The affine frontier". -/
def _root_.ConLeche.ProjEntry.typeAtI (entry : ProjEntry) (us : List Level)
    (targs : List Expr) (pe : Expr) : Expr :=
  instantiateListC (instLevelParams entry.levelParams us entry.body)
    (pe :: targs.reverse)

/-! ## The `Bool`-valued walks

The scope, definedness and resolution guards are the substitution
walks' design over a `Bool`, and the tree has ONE memo discipline for
every traversal memo in it (task #319; `Expr.beqGoX` is the third
instance).  Each guard used to create a `Std.HashMap` per call, keyed
STRUCTURALLY on the node (and, for the scope walk, the cursor), and
record EVERY node it decided — a probe that compared the stored node
with the query by `Expr.beq`, and an entry for every leaf.  Instead:

* **memoise only what is shared** — at every compound child past the
  cutoff, `withExclusive` (`ConLeche/Kernel/Exclusive.lean`) on the
  node (borrowed); an exclusive node is descended with the memo
  untouched (no key, no probe, no insert), a shared one is probed and
  recorded on a miss.  A node with one reference cannot be reached
  again, so recording it is pure loss;
* **key by address and cursor** — `withPtrAddr` (`Expr.withAddr`) at
  the top of the shared step, packed with the cursor into one `Nat`
  (`pkey`), under the mixing hash of `PKey`.  No structural hash and
  no `Expr.beq` on any probe;
* **validate a hit by pointer identity** — `Expr.ptrDec` on the
  stored node against the current one, plus a cursor compare.  The
  address is never trusted: a wrong key can only cost a descent,
  never a value;
* **every entry is self-proving** — a `BEnt` carries its node, its
  cursor, its decision and the proof `val = s node depth`, so there
  is **no table invariant** and no lemma about the table at all;
* **no cutoff beyond the walk's own** (`fvarB`, `hasLP`, and none at
  all for `constsResolveFC`): every shared compound node the walk
  meets is memoised, for as long as the call lasts.

A walk's result is a `Squash` of `{ r : Bool // r = <the plain
descent> }` beside the memo — a `Subsingleton`, which is the
obligation `withExclusive` and `withPtrAddr` each ask of their
continuation — and the wrapper reads the decision off it with
`resBool`.  The plain descents (`*P`) carry the cutoff and are proved
equal to their `ConLeche.Expr` specifications in
`ConLeche/Verify/Cached/{OpsC,GuardsC}.lean`.  **The borrowed
parameter is a requirement, not an optimisation**, for the reason the
substitution walks' section states.

The one walk of this file that is NOT of this shape is
`fvarLeavesGoC`, whose memo is a visited SET; its docstring says
why. -/

/-- The nodes a `Bool` memo entry can save a descent of: the compound
nodes, and `fvar` — every walk of this section descends into the
ANNOTATION, so the cached fvar range does not decide an `fvar` node. -/
@[inline] def isCompoundF : Expr → Bool
  | .app .. | .lam .. | .forallE .. | .letE .. | .proj .. | .fvar .. => true
  | _ => false

/-- A `Bool` memo entry: the node it was decided for, the cursor, the
decision, and the proof — the entry is its own invariant (`PEnt` with
`Bool` in place of the rebuilt term). -/
structure BEnt (s : Expr → Nat → Bool) where
  node : Expr
  depth : Nat
  val : Bool
  eq : val = s node depth

/-- A validated hit: the cursor compares equal and the stored node IS
the current one (by pointer at runtime — `Expr.ptrDec` — structurally
in the model); then the entry's proof is the walk's. -/
@[inline] def BEnt.hit {s : Expr → Nat → Bool} {β : Sort u} (p : BEnt s) (e : Expr) (c : Nat)
    (k : { r : Bool // r = s e c } → β) (miss : Unit → β) : β :=
  if hd : p.depth = c then
    match Expr.ptrDec p.node e with
    | isTrue hn => k ⟨p.val, by rw [p.eq, hn, hd]⟩
    | isFalse _ => miss ()
  else miss ()

/-- The `Bool` table: the packed address-and-cursor key under the
mixing hash of `PKey`. -/
abbrev BTab (s : Expr → Nat → Bool) := Std.HashMap PKey (BEnt s)

/-- The pointer-keyed `Bool` memo: absent until the first shared
compound node. -/
abbrev MemoB (s : Expr → Nat → Bool) := Option (BTab s)

/-- A `Bool` walk's result: the decision, fixed by its proof, beside
the memo. -/
abbrev ResB (s : Expr → Nat → Bool) (e : Expr) (c : Nat) :=
  { r : Bool // r = s e c } × MemoB s

/-- The record: the entry under its packed key, in the table or in a
fresh one. -/
@[inline] def MemoB.insert {s : Expr → Nat → Bool} (memo : MemoB s) (key : Nat)
    (p : BEnt s) : MemoB s :=
  match memo with
  | none => some (({} : BTab s).insert ⟨key⟩ p)
  | some m => some (m.insert ⟨key⟩ p)

/-- The shared-node step over the pointer-keyed `Bool` memo: the
address read, the probe, the validated hit — else the descent and the
record under the key read BEFORE the descent (`MemoXP.shared`
verbatim, with `BEnt` for `PEnt`). -/
@[inline] def MemoB.shared {s : Expr → Nat → Bool} (memo : MemoB s) (e : Expr) (c : Nat)
    (rec : Unit → Squash (ResB s e c)) : Squash (ResB s e c) :=
  withAddr e fun addr =>
  let key := pkey addr c
  match memo with
  | none => Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
      Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, c, r, hr⟩)
  | some m =>
    match m[(⟨key⟩ : PKey)]? with
    | some p => p.hit e c (fun r => Squash.mk (r, memo)) fun _ =>
        Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
          Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, c, r, hr⟩)
    | none => Squash.lift (rec ()) fun (⟨r, hr⟩, memo) =>
        Squash.mk (⟨r, hr⟩, memo.insert key ⟨e, c, r, hr⟩)

/-- The cursor-free instance: the cursored `Bool` memo at cursor
`0`. -/
abbrev MemoB0 (s : Expr → Bool) := MemoB (fun e _ => s e)

abbrev ResB0 (s : Expr → Bool) (e : Expr) := { r : Bool // r = s e } × MemoB0 s

@[inline] def MemoB0.shared {s : Expr → Bool} (memo : MemoB0 s) (e : Expr)
    (rec : Unit → Squash (ResB0 s e)) : Squash (ResB0 s e) :=
  MemoB.shared (s := fun e _ => s e) memo e 0 rec

/-- The decision of a `Bool` walk's result (the quotient lifts: the
decision is fixed by its subtype). -/
@[inline] def resBool {c : Bool} {M : Type} (s : Squash ({ r : Bool // r = c } × M)) : Bool :=
  Quotient.lift (fun p => p.1.1) (fun p q _ => by rw [p.1.2, q.1.2]) s

/-- What the decision of a `Bool` walk's result is: the value its
subtype names.  Whatever the exclusivity reads and the addresses were
along the way. -/
theorem resBool_eq {c : Bool} {M : Type} (s : Squash ({ r : Bool // r = c } × M)) :
    resBool s = c := by
  induction s using Quotient.ind with
  | _ p => exact p.1.2

/-! ## Scope queries -/

/-- The plain descent of `wscopedBC`: the reference the walk is
verified against (`wscopedBP_spec`, `ConLeche/Verify/Cached/OpsC.lean`,
is the equation to `Expr.wscopedB`).  The cursor is the node's second
argument, as it is for the substitution walks — it CHANGES at `fvar`,
where the annotation is entered at the variable's own index, so the
memo key must carry it. -/
def wscopedBP (e : Expr) (d : Nat) : Bool :=
  if e.fvarB == 0 then true else
  match e with
  | .bvar .. | .sort .. | .const .. | .lit .. => true
  | .fvar idx ty .. => idx < d && wscopedBP ty idx
  | .app f a .. => wscopedBP f d && wscopedBP a d
  | .lam ty body _ .. | .forallE ty body _ .. => wscopedBP ty d && wscopedBP body d
  | .letE ty val body .. => wscopedBP ty d && wscopedBP val d && wscopedBP body d
  | .proj _ _ sub .. => wscopedBP sub d

theorem wscopedBP_cut {e : Expr} {d : Nat} (h : (e.fvarB == 0) = true) :
    wscopedBP e d = true := by
  rw [wscopedBP.eq_def]; simp [h]

/-- The child step of `wscopedBXP`: the cutoff, the compound test, the
exclusivity read. -/
@[inline] def enterWSP (e : @& Expr) (d : Nat) (memo : MemoB wscopedBP)
    (rec : (hcut : (e.fvarB == 0) = false) → Squash (ResB wscopedBP e d)) :
    Squash (ResB wscopedBP e d) :=
  match hcut : e.fvarB == 0 with
  | true => Squash.mk (⟨true, (wscopedBP_cut hcut).symm⟩, memo)
  | false =>
    if !isCompoundF e then rec hcut
    else withExcl e fun excl =>
      if excl then rec hcut else memo.shared e d fun _ => rec hcut

/-- The walk of `wscopedBC` (the node is past the cutoff: the wrapper
and `enterWSP` test it). -/
def wscopedBXP (memo : MemoB wscopedBP) (e : @& Expr) (d : Nat)
    (hcut : (e.fvarB == 0) = false) : Squash (ResB wscopedBP e d) :=
  match e with
  | .bvar .. => Squash.mk (⟨true, by rw [wscopedBP.eq_def, hcut]⟩, memo)
  | .sort .. => Squash.mk (⟨true, by rw [wscopedBP.eq_def, hcut]⟩, memo)
  | .const .. => Squash.mk (⟨true, by rw [wscopedBP.eq_def, hcut]⟩, memo)
  | .lit .. => Squash.mk (⟨true, by rw [wscopedBP.eq_def, hcut]⟩, memo)
  | .fvar idx ty .. =>
    if hidx : idx < d then
      enterWSP ty idx memo (fun h => wscopedBXP memo ty idx h)
        |>.lift fun (⟨rt, ht⟩, memo) =>
      Squash.mk (⟨rt, by
        rw [wscopedBP.eq_def, hcut]
        change rt = decide (idx < d) && wscopedBP ty idx
        rw [decide_eq_true hidx, ← ht]⟩, memo)
    else
      Squash.mk (⟨false, by
        rw [wscopedBP.eq_def, hcut]
        change false = decide (idx < d) && wscopedBP ty idx
        rw [decide_eq_false hidx]⟩, memo)
  | .app f a .. =>
    enterWSP f d memo (fun h => wscopedBXP memo f d h) |>.lift fun (⟨rf, hf⟩, memo) =>
    match rf, hf with
    | true, hf =>
      enterWSP a d memo (fun h => wscopedBXP memo a d h) |>.lift fun (⟨ra, ha⟩, memo) =>
      Squash.mk (⟨ra, by
        rw [wscopedBP.eq_def, hcut]
        change ra = wscopedBP f d && wscopedBP a d
        rw [← hf, ← ha]⟩, memo)
    | false, hf =>
      Squash.mk (⟨false, by
        rw [wscopedBP.eq_def, hcut]
        change false = wscopedBP f d && wscopedBP a d
        rw [← hf]⟩, memo)
  | .lam ty body _ .. =>
    enterWSP ty d memo (fun h => wscopedBXP memo ty d h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterWSP body d memo (fun h => wscopedBXP memo body d h)
        |>.lift fun (⟨rb, hb⟩, memo) =>
      Squash.mk (⟨rb, by
        rw [wscopedBP.eq_def, hcut]
        change rb = wscopedBP ty d && wscopedBP body d
        rw [← ht, ← hb]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [wscopedBP.eq_def, hcut]
        change false = wscopedBP ty d && wscopedBP body d
        rw [← ht]⟩, memo)
  | .forallE ty body _ .. =>
    enterWSP ty d memo (fun h => wscopedBXP memo ty d h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterWSP body d memo (fun h => wscopedBXP memo body d h)
        |>.lift fun (⟨rb, hb⟩, memo) =>
      Squash.mk (⟨rb, by
        rw [wscopedBP.eq_def, hcut]
        change rb = wscopedBP ty d && wscopedBP body d
        rw [← ht, ← hb]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [wscopedBP.eq_def, hcut]
        change false = wscopedBP ty d && wscopedBP body d
        rw [← ht]⟩, memo)
  | .letE ty val body .. =>
    enterWSP ty d memo (fun h => wscopedBXP memo ty d h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterWSP val d memo (fun h => wscopedBXP memo val d h)
        |>.lift fun (⟨rv, hv⟩, memo) =>
      match rv, hv with
      | true, hv =>
        enterWSP body d memo (fun h => wscopedBXP memo body d h)
          |>.lift fun (⟨rb, hb⟩, memo) =>
        Squash.mk (⟨rb, by
          rw [wscopedBP.eq_def, hcut]
          change rb = (wscopedBP ty d && wscopedBP val d) && wscopedBP body d
          rw [← ht, ← hv, ← hb]⟩, memo)
      | false, hv =>
        Squash.mk (⟨false, by
          rw [wscopedBP.eq_def, hcut]
          change false = (wscopedBP ty d && wscopedBP val d) && wscopedBP body d
          rw [← ht, ← hv]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [wscopedBP.eq_def, hcut]
        change false = (wscopedBP ty d && wscopedBP val d) && wscopedBP body d
        rw [← ht]⟩, memo)
  | .proj _ _ sub .. =>
    enterWSP sub d memo (fun h => wscopedBXP memo sub d h) |>.lift fun (⟨rs, hs⟩, memo) =>
    Squash.mk (⟨rs, by
      rw [wscopedBP.eq_def, hcut]
      change rs = wscopedBP sub d
      rw [← hs]⟩, memo)

/-- The cached `Expr.wscopedB d` (one memoized DAG walk): the cutoff,
then the walk. -/
def wscopedBC (d : Nat) (e : Expr) : Bool :=
  match hcut : e.fvarB == 0 with
  | true => true
  | false => resBool (wscopedBXP none e d hcut)

/-- Core of `fvarLeavesC` (memoized set accumulation).

**The one walk of the tree whose memo is not the `withExclusive`
idiom, and why** (task #319, which put that idiom in front of every
other traversal memo — the substitution walks, `Expr.beqGoX`, and the
`Bool`-valued walks above).  This memo is a visited SET, and its
entries are `Unit`: what an entry means is *"this node's leaves are
already in `acc`"* — a statement about the ACCUMULATOR, which changes
at every step, and about the walk's own descent path, not about the
node.  It is the verification's `SeenInv`
(`ConLeche/Verify/Cached/GuardsC.lean`): every key of `seen` either
has all its leaves in `acc` already or is *gray* (being processed).
An entry carrying no value cannot prove itself, so this memo needs a
table invariant — which is exactly what the idiom removes.

The self-proving alternative is an entry carrying the node's own leaf
list, `{ r : List (Nat × Expr) // r = Expr.fvarLeaves e }`, appended
at the parent.  That closes as a proof — it is the `Bool` walks'
shape with a list in place of the decision — but it is the wrong
ALGORITHM: `Expr.fvarLeaves` concatenates at every compound node
(`ConLeche/Kernel/ExprOps.lean`), so a node's own list is the leaf
list of its TREE unfolding, and materialising one per entry is
precisely the blow-up the `seen` set exists to avoid (an `app e e`
ladder gives the root a list of `2^k` elements on `k` nodes; the
affine frontier's 3.9 · 10⁸-node unfolding of a 3 106-node DAG is the
real instance).  Weakening the subtype to a membership
characterization — all the one consumer, `leafMem`, needs — closes
just as easily and does not shrink the lists: siblings still
concatenate, and deduplicating at each node reintroduces a per-node
set, i.e. the table the entry was meant to replace.  So the
accumulator is the algorithm here, and the accumulator is what cannot
be carried in a type.  DESIGN.md, task #319, records this as the one
permitted exception and the open question behind it. -/
def fvarLeavesGoC (acc : List (Nat × Expr))
    (seen : Std.HashMap Expr Unit) (e : Expr) :
    List (Nat × Expr) × Std.HashMap Expr Unit :=
  if e.fvarB == 0 then (acc, seen) else
  match seen[e]? with
  | some _ => (acc, seen)
  | none =>
    let seen := seen.insert e ()
    match e with
    | .bvar .. | .sort .. | .const .. | .lit .. => (acc, seen)
    | .fvar idx ty .. => fvarLeavesGoC ((idx, ty) :: acc) seen ty
    | .app f a .. =>
      let (acc, seen) := fvarLeavesGoC acc seen f
      fvarLeavesGoC acc seen a
    | .lam ty body _ .. | .forallE ty body _ .. =>
      let (acc, seen) := fvarLeavesGoC acc seen ty
      fvarLeavesGoC acc seen body
    | .letE ty val body .. =>
      let (acc, seen) := fvarLeavesGoC acc seen ty
      let (acc, seen) := fvarLeavesGoC acc seen val
      fvarLeavesGoC acc seen body
    | .proj _ _ sub .. => fvarLeavesGoC acc seen sub

/-- The reachable `fvar` leaves (hereditarily through annotations). -/
def fvarLeavesC (e : Expr) : List (Nat × Expr) :=
  (fvarLeavesGoC [] {} e).1

/-- Is `(idx, ty)` in the base leaf list?  Compares the annotation
with `Expr.beq` (pointer-first). -/
def leafMem : List (Nat × Expr) → Nat → Expr → Bool
  | [], _, _ => false
  | (i, t) :: rest, idx, ty =>
    (i == idx && t == ty) || leafMem rest idx ty

/-- The plain descent of the leaf-subset walk: the reference the walk
is verified against (`leavesSubP_spec`,
`ConLeche/Verify/Cached/GuardsC.lean`, is the equation to the
`Expr`-level leaf-subset boolean).  `leafMem` is the membership
test (task #86). -/
def leavesSubP (bl : List (Nat × Expr)) (e : Expr) : Bool :=
  if e.fvarB == 0 then true else
  match e with
  | .bvar .. | .sort .. | .const .. | .lit .. => true
  | .fvar idx ty .. => leafMem bl idx ty && leavesSubP bl ty
  | .app f a .. => leavesSubP bl f && leavesSubP bl a
  | .lam ty body _ .. | .forallE ty body _ .. => leavesSubP bl ty && leavesSubP bl body
  | .letE ty val body .. =>
    leavesSubP bl ty && leavesSubP bl val && leavesSubP bl body
  | .proj _ _ sub .. => leavesSubP bl sub

theorem leavesSubP_cut {bl : List (Nat × Expr)} {e : Expr} (h : (e.fvarB == 0) = true) :
    leavesSubP bl e = true := by
  rw [leavesSubP.eq_def]; simp [h]

/-- The child step of `leavesSubXP`: the cutoff, the compound test,
the exclusivity read. -/
@[inline] def enterLSub (bl : @& List (Nat × Expr)) (e : @& Expr)
    (memo : MemoB0 (leavesSubP bl))
    (rec : (hcut : (e.fvarB == 0) = false) → Squash (ResB0 (leavesSubP bl) e)) :
    Squash (ResB0 (leavesSubP bl) e) :=
  match hcut : e.fvarB == 0 with
  | true => Squash.mk (⟨true, (leavesSubP_cut hcut).symm⟩, memo)
  | false =>
    if !isCompoundF e then rec hcut
    else withExcl e fun excl =>
      if excl then rec hcut else memo.shared e fun _ => rec hcut

/-- The leaf-subset walk (the node is past the cutoff: `leavesSubC`
and `enterLSub` test it). -/
def leavesSubXP (bl : @& List (Nat × Expr)) (memo : MemoB0 (leavesSubP bl))
    (e : @& Expr) (hcut : (e.fvarB == 0) = false) : Squash (ResB0 (leavesSubP bl) e) :=
  match e with
  | .bvar .. => Squash.mk (⟨true, by rw [leavesSubP.eq_def, hcut]⟩, memo)
  | .sort .. => Squash.mk (⟨true, by rw [leavesSubP.eq_def, hcut]⟩, memo)
  | .const .. => Squash.mk (⟨true, by rw [leavesSubP.eq_def, hcut]⟩, memo)
  | .lit .. => Squash.mk (⟨true, by rw [leavesSubP.eq_def, hcut]⟩, memo)
  | .fvar idx ty .. =>
    if hlm : leafMem bl idx ty = true then
      enterLSub bl ty memo (fun h => leavesSubXP bl memo ty h)
        |>.lift fun (⟨rt, ht⟩, memo) =>
      Squash.mk (⟨rt, by
        rw [leavesSubP.eq_def, hcut]
        change rt = leafMem bl idx ty && leavesSubP bl ty
        rw [hlm, ← ht]⟩, memo)
    else
      Squash.mk (⟨false, by
        rw [leavesSubP.eq_def, hcut]
        change false = leafMem bl idx ty && leavesSubP bl ty
        rw [Bool.eq_false_of_ne_true hlm]⟩, memo)
  | .app f a .. =>
    enterLSub bl f memo (fun h => leavesSubXP bl memo f h) |>.lift fun (⟨rf, hf⟩, memo) =>
    match rf, hf with
    | true, hf =>
      enterLSub bl a memo (fun h => leavesSubXP bl memo a h) |>.lift fun (⟨ra, ha⟩, memo) =>
      Squash.mk (⟨ra, by
        rw [leavesSubP.eq_def, hcut]
        change ra = leavesSubP bl f && leavesSubP bl a
        rw [← hf, ← ha]⟩, memo)
    | false, hf =>
      Squash.mk (⟨false, by
        rw [leavesSubP.eq_def, hcut]
        change false = leavesSubP bl f && leavesSubP bl a
        rw [← hf]⟩, memo)
  | .lam ty body _ .. =>
    enterLSub bl ty memo (fun h => leavesSubXP bl memo ty h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterLSub bl body memo (fun h => leavesSubXP bl memo body h)
        |>.lift fun (⟨rb, hb⟩, memo) =>
      Squash.mk (⟨rb, by
        rw [leavesSubP.eq_def, hcut]
        change rb = leavesSubP bl ty && leavesSubP bl body
        rw [← ht, ← hb]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [leavesSubP.eq_def, hcut]
        change false = leavesSubP bl ty && leavesSubP bl body
        rw [← ht]⟩, memo)
  | .forallE ty body _ .. =>
    enterLSub bl ty memo (fun h => leavesSubXP bl memo ty h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterLSub bl body memo (fun h => leavesSubXP bl memo body h)
        |>.lift fun (⟨rb, hb⟩, memo) =>
      Squash.mk (⟨rb, by
        rw [leavesSubP.eq_def, hcut]
        change rb = leavesSubP bl ty && leavesSubP bl body
        rw [← ht, ← hb]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [leavesSubP.eq_def, hcut]
        change false = leavesSubP bl ty && leavesSubP bl body
        rw [← ht]⟩, memo)
  | .letE ty val body .. =>
    enterLSub bl ty memo (fun h => leavesSubXP bl memo ty h) |>.lift fun (⟨rt, ht⟩, memo) =>
    match rt, ht with
    | true, ht =>
      enterLSub bl val memo (fun h => leavesSubXP bl memo val h)
        |>.lift fun (⟨rv, hv⟩, memo) =>
      match rv, hv with
      | true, hv =>
        enterLSub bl body memo (fun h => leavesSubXP bl memo body h)
          |>.lift fun (⟨rb, hb⟩, memo) =>
        Squash.mk (⟨rb, by
          rw [leavesSubP.eq_def, hcut]
          change rb = (leavesSubP bl ty && leavesSubP bl val) && leavesSubP bl body
          rw [← ht, ← hv, ← hb]⟩, memo)
      | false, hv =>
        Squash.mk (⟨false, by
          rw [leavesSubP.eq_def, hcut]
          change false = (leavesSubP bl ty && leavesSubP bl val) && leavesSubP bl body
          rw [← ht, ← hv]⟩, memo)
    | false, ht =>
      Squash.mk (⟨false, by
        rw [leavesSubP.eq_def, hcut]
        change false = (leavesSubP bl ty && leavesSubP bl val) && leavesSubP bl body
        rw [← ht]⟩, memo)
  | .proj _ _ sub .. =>
    enterLSub bl sub memo (fun h => leavesSubXP bl memo sub h) |>.lift fun (⟨rs, hs⟩, memo) =>
    Squash.mk (⟨rs, by
      rw [leavesSubP.eq_def, hcut]
      change rs = leavesSubP bl sub
      rw [← hs]⟩, memo)

/-- The cached leaf-subset test: the cutoff, then the walk. -/
def leavesSubC (bl : List (Nat × Expr)) (e : Expr) : Bool :=
  match hcut : e.fvarB == 0 with
  | true => true
  | false => resBool (leavesSubXP bl none e hcut)

/-- The fabrication leaf guard: every `fvar` leaf of `fab` is one of
`base` (short-circuits on `fvar`-free fabrications, `O(1)` off the
cached range). -/
def leafGuard (fab base : Expr) : Bool :=
  !fab.hasFvar || leavesSubC (fvarLeavesC base) fab

/-! ## Telescope operations -/

/-- The `instantiate1C` chain of `Expr.instSpine`. -/
def instSpineChainC : List Expr → Nat → Expr → Expr
  | [], _, e => e
  | a :: as, t, e => instSpineChainC as (t - 1) (instantiate1C e a t)

/-- The cached `Expr.instSpine` (bulk when the spine spans the
telescope context, the chain otherwise). -/
def instSpineC (args : List Expr) (t : Nat) (e : Expr) : Expr :=
  if args.length = t + 1 then instantiateListC e args.reverse 0
  else instSpineChainC args t e

/-- Core of `piResidual` (bulk form, task #50).

Not structural: the `bvar` arm re-enters on the same argument list with
the accumulator flushed.  Measure `(as.length, acc.length)` — the
`forallE` arm consumes an argument, the `bvar` arm keeps the arguments
and empties a nonempty accumulator. -/
def piResidualAcc : List Expr → Expr → List Expr → Option Expr
  | acc, e, [] => some (instantiateListC e acc 0)
  | acc, e, a :: as =>
    match e with
    | .forallE _ b _ .. => piResidualAcc (a :: acc) b as
    | .bvar .. =>
      match acc with
      | [] => none
      | _ :: _ => piResidualAcc [] (instantiateListC e acc 0) (a :: as)
    | _ => none
termination_by acc _ as => (as.length, acc.length)
decreasing_by
  all_goals first
    | (apply Prod.Lex.right; simp +arith +decide)
    | (apply Prod.Lex.left; simp +arith +decide)

@[inherit_doc piResidualAcc]
def piResidual (e : Expr) (args : List Expr) : Option Expr :=
  piResidualAcc [] e args

/- Evaluator extraction: the original allLevelParamsDefinedP/XP/C guard family
   is retained separately for the parsed-record driver. -/

end ConLeche.Expr

end -- original EOF public section of ConLeche.Cached.ExprOpsC
/- END full source origin ConLeche.Cached.ExprOpsC -/

/- BEGIN full source origin ConLeche.Cached.StateC -/
-- Cached bundle origin 03, original line 1: module

-- Cached bundle origin 03, original line 3: public import ConLeche.Kernel.FEnv
-- Cached bundle origin 03, original line 4: public import ConLeche.Cached.ExprOpsC

section

/-!
# The cached checker state and its operation wrappers

The per-declaration state: the converted-constant cache, the memo
caches for the five entry points, the level-operation memos and the
persistent bulk-instantiation memo, with the linear-update discipline
(detach a component from the state record before mutating it) each of
them is written in.

The environment-index guards
below (`isCtorAppC`, `headHintC`, `unfoldableHeadC`,
`sameConstHeadsC`, `rawNatLitC?`, `etaCtorShapeC`) are what the core
calls directly.

## Memo key discipline

Pointer identity is not available as a *key*, so the memo maps are
keyed on `Expr` values with:

* `Hashable Expr` = the cached hash field (`O(1)`, no traversal);
* `BEq Expr` = pointer identity, then the cached hashes, then
  structural descent.  Bucket comparisons therefore cost `O(1)` on
  the overwhelmingly common shared-subterm case (instantiation and
  abstraction return unchanged subterms *by reference*), and a hash
  mismatch rejects the rest without descending.

A hash-cons table is deliberately **not** used: it would reintroduce
the deleted arena's central data structure.  The `Level`-keyed and
`Name`-keyed caches (`lsimpC`, `eqvC`, `constTyAt`, …) are the one
place where structural hashing survives.
-/

namespace ConLeche.Cached

open ConLeche

/-! ## The environment-index guards -/

/-- `isCtorApp` through the index. -/
def isCtorAppC (fe : FEnv) (e : Expr) : Bool :=
  match Expr.getAppFn e with
  | .const cn _ .. =>
    match fe.find? cn with
    | some (.ctorInfo _ _ _) => true
    | _ => false
  | _ => false

/-- `headHint` through the index. -/
def headHintC (fe : FEnv) (e : Expr) : ReducibilityHint :=
  match Expr.getAppFn e with
  | .const nm _ .. =>
    match fe.find? nm with
    | some (.defnInfo _ _ hint) => hint
    | _ => .opaque
  | _ => .opaque

/-- `unfoldableHead` through the index (the lazy-delta decision). -/
def unfoldableHeadC (fe : FEnv) (e : Expr) : Bool :=
  match Expr.getAppFn e with
  | .const nm us .. =>
    match fe.find? nm with
    | some (.defnInfo cv _ _) => us.length == cv.levelParams.length
    | _ => false
  | _ => false

/-- The cached `sameConstHeads`. -/
def sameConstHeadsC (a b : Expr) : Bool :=
  match a, b with
  | .app f₁ _ .., .app f₂ _ .. =>
    match Expr.getAppFn f₁, Expr.getAppFn f₂ with
    | .const n₁ _ .., .const n₂ _ .. => n₁ == n₂
    | _, _ => false
  | _, _ => false

/-- `rawNatLit?` on an `Expr`. -/
def rawNatLitC? (e : Expr) : Option Nat :=
  match e with
  | .lit (.natVal n) .. => some n
  | .const c [] .. => if c == natZeroName then some 0 else none
  | _ => none

/-- Twin of `etaCtorShape` (the audit's D13 gate; `Expr = Expr`). -/
def etaCtorShapeC (fe : FEnv) (e : Expr) : Bool :=
  match Expr.getAppFn e with
  | .const c _ =>
    match fe.find? c with
    | some (.ctorInfo _ cnP cnF) => (Expr.getAppArgs e).length == cnP + cnF
    | _ => false
  | _ => false

/-! ## The state -/

/-- One cached-environment entry: a stored constant's annotated type
and (for definitions/theorems/opaques) value converted to `Expr`,
each tagged with the very `Expr` object it came from.  A use validates
the tag by pointer equality (`Expr.exprPtrBEq`, reused), so the
conversion of a stored constant is paid once per declaration instead
of once per delta step. -/
structure CConstE where
  tyE : Expr
  ty : Expr
  val : Option (Expr × Expr) := none

/-- Per-declaration state: the converted-constant cache, the memo
caches for the five entry points, the lazy caches for
level-instantiated stored constants, the level-operation memos, and
the persistent bulk-instantiation memo (task #145). -/
structure CState where
  ienv : Std.HashMap Name CConstE := {}
  constTyAt : Std.HashMap (Name × List Level) Expr := {}
  constValAt : Std.HashMap (Name × List Level) Expr := {}
  ruleRhsAt : Std.HashMap (Name × Name × List Level) Expr := {}
  whnfCoreC : Std.HashMap Expr Expr := {}
  /-- The cheap-projection head normalization's memo (`whnfCore` at
  `cheap_proj`, `whnfCoreBody`): a separate map, since the two modes'
  results differ on a stuck projection. -/
  whnfCoreCheapC : Std.HashMap Expr Expr := {}
  whnfC : Std.HashMap Expr Expr := {}
  inferC : Std.HashMap Expr Expr := {}
  /-- **The io-grade inference memo** (task #170 / #172 B4): results of
  the knot's `inferIO` slot at `mode.ioGate` (both modes), kept apart
  from `inferC` per the task-#170 memo
  ruling — *"since caching has no access to semantic reasoning (yet)
  we need two memos, one with and one without the flag"* — because an
  io entry witnesses fewer checks than the full-infer claims consume.
  Its invariant is the io claims' weaker (premise-form) one
  (`CSOK.inferIOC`, `Verify/Cached/DiscC1.lean`).  Official's own
  layout: the C++ kernel keys its infer cache by `infer_only`.  At
  `ioGate = false` (no mode any more) the slot shares `inferC` and
  this map stays empty. -/
  inferIOC : Std.HashMap Expr Expr := {}
  defeqC : Std.HashMap (Expr × Expr) Bool := {}
  annotC : Std.HashMap Expr Expr := {}
  lsimpC : Std.HashMap Level Level := {}
  lnzC : Std.HashMap Level Bool := {}
  eqvC : Std.HashMap (Level × Level) Bool := {}
  instC : Std.HashMap (Expr × List Expr × Nat) Expr := {}

instance : Inhabited CState := ⟨{}⟩

/-- Entry bound for the persistent bulk-instantiation memo. -/
def instCCapC : Nat := 32000000

/-- The cached checker's monad: the per-declaration memo state over
`CheckM`. -/
abbrev CheckCM := StateT CState CheckM

/-- Peel fuel of the binder-telescope loops.  A constant beyond any
real binder chain; the fuel is *semantically transparent*: on
exhaustion the leaf phase hands the residual chain back to the knot,
which is exactly the chained specification's next step. -/
def peelFuel : Nat := 16777216

@[inline] def peelFuelM : CheckCM Nat := pure peelFuel

/-- The per-node loose-bvar bound — an `O(1)` field read. -/
@[inline] def bvarBoundM (e : Expr) : CheckCM Nat := pure e.bvarB

/-! ## Syntactic operations (the `*M` wrappers) -/

/-- `Expr.instantiate1`; the identity — the same node, by reference —
when the target has no loose bvar at or above the cursor. -/
@[inline] def inst1M (e v : Expr) (d : Nat := 0) : CheckCM Expr :=
  pure (Expr.instantiate1C e v d)

/-- Bulk instantiation with the persistent result memo (task #145),
keyed by the whole argument tuple. -/
def instListM (e : Expr) (vs : List Expr) (d : Nat := 0) : CheckCM Expr :=
  modifyGet fun s =>
    if e.bvarB ≤ d then (e, s)
    else
      match s.instC[(e, vs, d)]? with
      | some r => (r, s)
      | none =>
        let mp := s.instC
        let s := { s with instC := {} }
        let mp := if mp.size < instCCapC then mp else {}
        let r := Expr.instantiateListC e vs d
        (r, { s with instC := mp.insert (e, vs, d) r })

/-- Bulk instantiation on a reversed accumulator array (deliberately
not memoized). -/
@[inline] def instListRevM (e : Expr) (vs : Array Expr) (d : Nat := 0) :
    CheckCM Expr :=
  pure (Expr.instantiateRev e vs d)

@[inline] def abstract1M (e : Expr) (d : Nat) : CheckCM Expr :=
  pure (Expr.abstract1C e d)

@[inline] def abstractRangeM (e : Expr) (d k : Nat) : CheckCM Expr :=
  pure (Expr.abstractRangeC e d k)

@[inline] def mkAppNM (f : Expr) (args : List Expr) : CheckCM Expr :=
  pure (Expr.mkAppN f args)

@[inline] def instSpineM (args : List Expr) (t : Nat) (e : Expr) :
    CheckCM Expr :=
  pure (Expr.instSpineC args t e)

@[inline] def piResidualM (e : Expr) (args : List Expr) :
    CheckCM (Option Expr) :=
  pure (Expr.piResidual e args)

@[inline] def instLevelParamsM (ks : List Name) (us : List Level)
    (e : Expr) : CheckCM Expr :=
  pure (Expr.instLevelParams ks us e)

/-! ## Level operations

Levels are plain trees here (there is no level arena), so the level
memos are keyed structurally — the one place a non-`O(1)` hash is
paid.  The *results* are cached (`lsimpC`, `lnzC`, `eqvC`), so a
decided comparison is never recomputed. -/

@[inline] def substLevelTreesM (ks : List Name) (us : List Level)
    (ls : List Level) : CheckCM (List Level) :=
  pure (ls.map (Level.subst ks us))

/-- Level equivalence with a persistent result cache: simplify both
sides, compare, then the `leqCore` cascade both ways.

The `l == r` head test is official's `is_equivalent` disjunct
(`level.cpp:518`, task #176 P2) and is what makes the *shared* case —
the overwhelming majority: the parser hands one object per stream
level index — cost one pointer compare instead of a
`(Level × Level)`-keyed memo probe.  It writes no cache entry, so the
`CSOK.eqv` invariant is untouched. -/
def isEquivLM (l r : Level) : CheckCM (Option Bool) :=
  if l == r then pure (some true) else
  modifyGet fun s =>
    match s.eqvC[(l, r)]? with
    | some b => (some b, s)
    | none =>
      let mp := s.lsimpC
      let ec := s.eqvC
      let s := { s with lsimpC := {}, eqvC := {} }
      let (ls, mp) :=
        match mp[l]? with
        | some x => (x, mp)
        | none => let x := Level.simplify l; (x, mp.insert l x)
      let (rs, mp) :=
        match mp[r]? with
        | some x => (x, mp)
        | none => let x := Level.simplify r; (x, mp.insert r x)
      if ls == rs then
        (some true, { s with lsimpC := mp, eqvC := ec.insert (l, r) true })
      else
        match Level.leqCore Level.defaultFuel ls rs 0 with
        | some false =>
          (some false, { s with lsimpC := mp, eqvC := ec.insert (l, r) false })
        | some true =>
          match Level.leqCore Level.defaultFuel rs ls 0 with
          | some b =>
            (some b, { s with lsimpC := mp, eqvC := ec.insert (l, r) b })
          | none => (none, { s with lsimpC := mp, eqvC := ec })
        | none => (none, { s with lsimpC := mp, eqvC := ec })

/-- Pointwise `isEquivLM`. -/
def isEquivListLM : List Level → List Level → CheckCM (Option Bool)
  | [], [] => pure (some true)
  | l :: ls, r :: rs => do
    match ← isEquivLM l r with
    | none => pure none
    | some false => pure (some false)
    | some true => isEquivListLM ls rs
  | _, _ => pure (some false)

/-! ## Lazy stored-constant conversions -/

/-- The `Expr` of a stored constant's type: the cached entry when its
`Expr` tag validates by pointer equality, else a fresh conversion. -/
def storedTyIdxM (n : Name) (ty : Expr) : CheckCM Expr := do
  let ent? : Option CConstE ← modifyGet fun s => (s.ienv[n]?, s)
  match ent? with
  | some ent =>
    if Expr.exprPtrBEq ent.tyE ty then pure ent.ty
    else pure ty
  | none => pure ty

/-- The `Expr` of a stored definition/theorem value (see
`storedTyIdxM`). -/
def storedValIdxM (n : Name) (v : Expr) : CheckCM Expr := do
  let ent? : Option CConstE ← modifyGet fun s => (s.ienv[n]?, s)
  match ent? with
  | some ⟨_, _, some (vE, vi)⟩ =>
    if Expr.exprPtrBEq vE v then pure vi
    else pure v
  | _ => pure v

/-- The level-instantiated *type* of the stored constant `n`. -/
def constTyAtM (fe : FEnv) (_nI : Name) (n : Name) (us : List Level) :
    CheckCM Expr := do
  let hit? ← modifyGet fun s => (s.constTyAt[(n, us)]?, s)
  match hit? with
  | some i => pure i
  | none =>
    match fe.find? n with
    | some ci =>
      let cv := ci.toConstantVal
      let raw ← storedTyIdxM n cv.type
      let i ← instLevelParamsM cv.levelParams us raw
      modify fun s =>
        let mp := s.constTyAt
        let s := { s with constTyAt := ∅ }
        { s with constTyAt := mp.insert (n, us) i }
      pure i
    | none => throw (.internal "constTyAtM: unknown constant")

/-- The level-instantiated *value* of the stored definition `n`. -/
def constValAtM (fe : FEnv) (_nI : Name) (n : Name) (us : List Level) :
    CheckCM Expr := do
  let hit? ← modifyGet fun s => (s.constValAt[(n, us)]?, s)
  match hit? with
  | some i => pure i
  | none =>
    match fe.find? n with
    | some (.defnInfo cv v _) =>
      let raw ← storedValIdxM n v
      let i ← instLevelParamsM cv.levelParams us raw
      modify fun s =>
        let mp := s.constValAt
        let s := { s with constValAt := ∅ }
        { s with constValAt := mp.insert (n, us) i }
      pure i
    | _ => throw (.internal "constValAtM: not a stored definition")

/-- The level-instantiated right-hand side of the rule for constructor
`j` of the stored recursor `c`. -/
def ruleRhsAtM (fe : FEnv) (_cI _jI : Name) (c j : Name) (us : List Level) :
    CheckCM Expr := do
  let hit? ← modifyGet fun s => (s.ruleRhsAt[(c, j, us)]?, s)
  match hit? with
  | some i => pure i
  | none =>
    match fe.find? c with
    | some (.recInfo cv _ _ rules) =>
      match rules.find? (fun r' => r'.ctor == j) with
      | some rl =>
        let i ← instLevelParamsM cv.levelParams us rl.rhs
        modify fun s =>
          let mp := s.ruleRhsAt
          let s := { s with ruleRhsAt := ∅ }
          { s with ruleRhsAt := mp.insert (c, j, us) i }
        pure i
      | none => throw (.internal "ruleRhsAtM: no rule for constructor")
    | _ => throw (.internal "ruleRhsAtM: not a stored recursor")

/-- Drop the environment-dependent caches (an environment transition).
The environment-independent components — the converted-constant cache
`ienv` (self-certified by its `Expr` tags) and the level-operation
memos — survive. -/
def CState.flushed (s : CState) : CState :=
  { s with
      constTyAt := {}, constValAt := {}, ruleRhsAt := {},
      whnfCoreC := {}, whnfCoreCheapC := {}, whnfC := {}, inferC := {}, inferIOC := {},
      defeqC := {}, annotC := {}, instC := {} }

def flushC : CheckCM Unit := modify (·.flushed)

/- Evaluator extraction: constsResolveFP/FXP/FC, enterCRF and recordCConst are
   retained separately for actual record-driver guards and state insertion. -/

end ConLeche.Cached

end -- original EOF public section of ConLeche.Cached.StateC
/- END full source origin ConLeche.Cached.StateC -/

/- BEGIN full source origin ConLeche.Cached.CoreC -/
-- Cached bundle origin 04, original line 1: module

-- Cached bundle origin 04, original line 3: public import ConLeche.Cached.StateC

section

/-!
# The cached checker core

The core over the computed-field representation: `whnfCore`, `whnf`,
`infer`, `defeq` and `annotate`, each memoized in `CState`; a
syntactic read is the operation itself (task #198).

See DESIGN.md, "The cached checker".

**One body, two modes.**  Every body below is a template
over `mode : CheckMode`, and the knot at the end (`coreKnotI mode`)
ties them at a mode.  The verified core is this knot at `.verified`;
the trusted core is this same knot at `.trusted` — there is no second
implementation: what
the trusted mode omits is exactly what `mode.verifiedChecks` gates
here (group A: the annotation validations, the λ-codomain sort check,
the projection certificate) plus what `mode.certs` gates (the
certificate families: every `certAtI` / `certUnlessI` site and the
`betaSkip` / `ioSkip` reads), and nothing else (DESIGN.md, "CORET
RETIRED").  Every read is a `match` on the two-constructor enum
(`ConLeche/Kernel/Env.lean`), so at either literal mode it reduces by
`rfl` and the branch is gone, not collapsed.
-/

namespace ConLeche.Cached

open ConLeche

variable {m : Type → Type}

/-! ## The core record and its helper twins -/

/-- The record of mutually recursive cached entry points. -/
structure CoreFnsI where
  whnfCore : Bool → Nat → Expr → CheckCM Expr
  whnf : Nat → Expr → CheckCM Expr
  infer : Nat → Expr → CheckCM Expr
  defeq : Nat → Expr → Expr → CheckCM Bool
  annotate : Nat → Expr → CheckCM Expr
  /-- Type inference at the **infer-only grade** (task #170 / #172 B4)
  — the twin of `CoreFns.inferIO` (`ConLeche/Kernel/Core.lean`): what
  every internal inference call site runs.  The knot selects the
  grade's meaning per mode (`mode.ioGate`): the io body (own memo,
  `CState.inferIOC`) at **both modes** since the licence ruling of
  2026-09-06 — the io skip is a licence, not certification-only work
  — and the full `infer` only at `ioGate = false`, which no mode
  spells any more (the retired R core). -/
  inferIO : Nat → Expr → CheckCM Expr

/-- The io-grade view (twin of `CoreFns.ioView`): the record whose
full-grade `infer` slot is the io slot, so a body written against
`r.infer` recurses at the io grade when handed `r.ioView`. -/
def CoreFnsI.ioView (r : CoreFnsI) : CoreFnsI :=
  { r with infer := r.inferIO }

/-- Twin of `unfoldDefinition` (monadic: the unfolded value is read
through the `(name, levels)` cache).  Like the spec, a theorem never
unfolds. -/
def unfoldDefinitionI (fe : FEnv) (e : Expr) : CheckCM (Option Expr) := do
  match Expr.getAppFn e with
  | .const n us => do
    let nm ← pure n
    match fe.find? nm with
    | some (.defnInfo cv _ _) =>
      if us.length = cv.levelParams.length then do
        let v ← constValAtM fe n nm us
        let args ← pure (Expr.getAppArgsC e)
        let r ← mkAppNM v args
        pure (some r)
      else pure none
    | _ => pure none
  | _ => pure none

/-- Twin of `litToCtorIfNat`. -/
def litToCtorIfNatI (fe : FEnv) (e : Expr) : CheckCM Expr := do
  match e with
  | .lit (.natVal n) =>
    if natLitSupportedF fe then pure (natLitToConstructor n)
    else pure e
  | _ => pure e

/-- Twin of `reduceNat`. -/
def reduceNatI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (e : Expr) :
    CheckCM (Option Expr) := do
  match e with
  | .app f₁ b =>
    match f₁ with
    | .const c us =>
      match us with
      | _ :: _ => pure none
      | [] => do
        let cn ← pure c
        if cn = natSuccName ∧ natLitSupportedF fe then do
          let w ← r.whnf depth b
          match ← pure (rawNatLitC? w) with
          | some n => do
            let r ← pure (Expr.lit (.natVal (n + 1)))
            pure (some r)
          | none => pure none
        else pure none
    | .app f₂ a =>
      match f₂ with
      | .const c us =>
        match us with
        | _ :: _ => pure none
        | [] => do
          let cn ← pure c
          if (cn = natAddName ∨ cn = natSubName ∨ cn = natMulName ∨
              cn = natPowName ∨ cn = natBeqName ∨ cn = natBleName ∨
              cn = natDivName ∨ cn = natModName ∨ cn = natGcdName ∨
              cn = natLandName ∨ cn = natLorName ∨ cn = natXorName ∨
              cn = natShiftLeftName ∨ cn = natShiftRightName) ∧
              natOpStoredF fe cn = true then do
            -- first argument first; the second only behind a literal
            -- (official `reduce_bin_nat_op`; the spec's D15 note)
            let w₁ ← r.whnf depth a
            match ← pure (rawNatLitC? w₁) with
            | some n₁ => do
              let w₂ ← r.whnf depth b
              match ← pure (rawNatLitC? w₂) with
              | some n₂ =>
                match natOpResult cn n₁ n₂ with
                | some x => do
                  let r ← pure x
                  pure (some r)
                | none => pure none
              | none => pure none
            | none => pure none
          else if natOpWfNames.contains cn ∧ natLitSupportedF fe then do
            let w₁ ← r.whnf depth a
            match ← pure (rawNatLitC? w₁) with
            | some _ => do
              let w₂ ← r.whnf depth b
              match ← pure (rawNatLitC? w₂) with
              | some _ => throw (.notImplemented
                  s!"native Nat computation on literals ({cn})")
              | none => pure none
            | none => pure none
          else pure none
      | _ => pure none
    | _ => pure none
  | _ => pure none

/-- Twin of `iotaCerts`, bulk form (task #50): peel the raw telescope
while accumulating the certified arguments, substituting only each
binder's *domain* (small) instead of copying the whole residual
telescope per argument.  A raw `bvar` body (whose substitution could
expose further `∀`-binders — the fold semantics) substitutes the
accumulator and re-enters.

`lic` is the ι-slot licence (the spec's docstring): at a licensed walk
a `.never` binder's slot is skipped outright — no domain instantiation,
no inference, no defeq — and the binder's argument joins the
accumulator as if certified.  The datum read is the level-instantiated
one (the telescope was instantiated at the recursor's levels by
`constTyAtM`), which is where `Nat.rec.{u}`'s `.ifAllZero [u]` major
binder becomes `.never` at `u := succ _`. -/
def iotaCertsIAux (r : CoreFnsI) (fe : FEnv) (depth : Nat) (lic : Bool) :
    Expr → List Expr → List Expr → CheckCM Bool
  | _, _, [] => pure true
  | ty, acc, arg :: rest => do
    match ty with
    | .forallE dom body mb =>
      if lic && mb.pw.isNever then
        iotaCertsIAux r fe depth lic body (arg :: acc) rest
      else do
        let dom' ← instListM dom acc
        let ta ← r.inferIO depth arg
        if ← r.defeq depth ta dom' then
          iotaCertsIAux r fe depth lic body (arg :: acc) rest
        else pure false
    | .bvar _ =>
      match acc with
      | [] => pure false
      | _ :: _ => do
        let ty' ← instListM ty acc
        iotaCertsIAux r fe depth lic ty' [] (arg :: rest)
    | _ => pure false
termination_by _ acc args => (args.length, acc.length)
decreasing_by
  · apply Prod.Lex.left; simp
  · apply Prod.Lex.left; simp
  · apply Prod.Lex.right' <;> simp

/-- Twin of `iotaCerts` (certify a spine against a recursor telescope);
the bulk-instantiating accumulator loop at the empty accumulator. -/
def iotaCertsI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (lic : Bool)
    (ty : Expr) (args : List Expr) : CheckCM Bool :=
  iotaCertsIAux r fe depth lic ty [] args

/-- Twin of `defEqList`. -/
def defEqListI (r : CoreFnsI) (fe : FEnv) (depth : Nat) :
    List Expr → List Expr → CheckCM Bool
  | [], [] => pure true
  | a :: as, b :: bs => do
    if ← r.defeq depth a b then
      defEqListI r fe depth as bs
    else pure false
  | _, _ => pure false

/-- Twin of `iotaIndexOk` (the canonical-index comparison, only where
the recursor has indices). -/
def iotaIndexOkI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (mI rP cnP : Nat)
    (tyCtor : Expr) (margs idx : List Expr) : CheckCM Bool :=
  if mI = rP then pure true
  else do
    match ← piResidualM tyCtor margs with
    | some residual => do
      let resArgs ← pure (Expr.getAppArgsC residual)
      defEqListI r fe depth (resArgs.drop cnP) idx
    | none => pure false

/-- Twin of `defeqSpine`. -/
def defeqSpineI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  match Expr.getAppFn a with
  | .const n us =>
    match Expr.getAppFn b with
    | .const n' us' => do
      let aargs ← pure (Expr.getAppArgsC a)
      let bargs ← pure (Expr.getAppArgsC b)
      if n = n' ∧ aargs.length = bargs.length then
        match ← isEquivListLM us us' with
        | some true => defEqListI r fe depth aargs bargs
        | _ => pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- Twin of `proofIrrel`. -/
def proofIrrelI (r : CoreFnsI) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  let ta ← r.inferIO depth a
  let tta ← r.inferIO depth ta
  let wtta ← r.whnf depth tta
  match wtta with
  | .sort uT => do
    let z ← pure .zero
    let okA ← liftFueled "level comparison" (← isEquivLM uT z)
    let tb ← r.inferIO depth b
    let ttb ← r.inferIO depth tb
    let wttb ← r.whnf depth ttb
    match wttb with
    | .sort vT => do
      let z ← pure .zero
      let okB ← liftFueled "level comparison" (← isEquivLM vT z)
      pure (okA && okB)
    | _ => pure false
  | _ => pure false

/- Task #172 batch B2 — **THE BODY TEMPLATE'S PARAMETER** (the mode
itself since task #185).  Every configured body below takes
`mode : CheckMode` and is instantiated at the two named concrete cores
at the end of this module (`…PC` at `.verified`, `…TC` at `.trusted`;
the `…RC` half retired with the R core, 2026-09-05).  Every read below
is one of the `CheckMode` functions of `ConLeche/Kernel/Env.lean`, each
a `match` on the enum.  The ι cone (`structEtaCertWithI` →
`majorToCtorI` → `prepareMajorI` → `iotaRecI`) reads its ι-slot
licence off `mode.betaGate` — the same function the β site reads —
and keeps only the TT-lane residue on `mode.ttChecks`, a literal
`false` at each mode. -/
variable (mode : CheckMode)

/-! ### The certificate-family switch (the twin's retirement, 2026-09-06)

`CheckMode.certs` (`ConLeche/Kernel/Env.lean`) is the task-#76 skip
list as a mode function: the certificate families the reference
kernel does not run and only the soundness proof consumes.  Every such
certificate below is spelled through one of the two wrappers here, so
the list of `certAtI`/`certUnlessI` sites — plus the `betaSkip` and
`ioSkip` reads — **is** the list of what the trusted core omits beyond
group A.  At `.verified` the function is `true`, so `certAtI .verified
c` is `c` by `rfl` (`certAtI_verified`); the simulation tower
(`ConLeche/Verify/Cached/*`), stated under `hμ : mode.verifiedChecks =
true`, sees through the wrapper by `certAtI_of_verifiedChecks` — the
spec bodies carry no such wrapper. -/

/-- Run the certificate `c` when the mode runs the certificate
families; otherwise it is `true` without running. -/
@[inline] def certAtI (mode : CheckMode) (c : CheckCM Bool) : CheckCM Bool :=
  if mode.certs then c else pure true

/-- `certAtI` with a *verdict-relevant* exception: `keep = true` runs
the check at every mode (the twin's judgement at ι's parameter
comparison — nested-rule comparands and projection-function rules
compare in both modes, ordinary plain rules only when certifying). -/
@[inline] def certUnlessI (mode : CheckMode) (keep : Bool) (c : CheckCM Bool) :
    CheckCM Bool :=
  if mode.certs || keep then c else pure true

/-- At a mode running the certificate families the wrapper is the
certificate — the simulation tower's blindness to the switch, under
its `hμ`. -/
@[simp] theorem certAtI_of_verifiedChecks {mode : CheckMode}
    (hμ : mode.verifiedChecks = true) (c : CheckCM Bool) :
    certAtI mode c = c := by
  cases mode <;> simp_all [certAtI, CheckMode.certs, CheckMode.verifiedChecks]
@[simp] theorem certUnlessI_of_verifiedChecks {mode : CheckMode}
    (hμ : mode.verifiedChecks = true) (keep : Bool) (c : CheckCM Bool) :
    certUnlessI mode keep c = c := by
  cases mode <;> simp_all [certUnlessI, CheckMode.certs, CheckMode.verifiedChecks]
/-- … and at the two modes the wrapper is the certificate or the
constant `true`, by `rfl`. -/
@[simp] theorem certAtI_verified (c : CheckCM Bool) :
    certAtI .verified c = c := rfl
@[simp] theorem certAtI_trusted (c : CheckCM Bool) :
    certAtI .trusted c = pure true := rfl

/-- Twin of `propIrrel` (task #168): the hoisted `Prop`-branch test
with both head-symbol arms.  Ungated since 2026-09-06 — the readers
run in both modes, so this body takes no `CheckMode` at all. -/
def propIrrelI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  if notProofFast fe.find? a || notProofFast fe.find? b then
    pure false
  else if isProofFast fe.find? a && isProofFast fe.find? b then
    pure true
  else
  let ta ← r.inferIO depth a
  let tta ← r.inferIO depth ta
  let wtta ← r.whnf depth tta
  match wtta with
  | .sort uT => do
    let z ← pure .zero
    let okA ← liftFueled "level comparison" (← isEquivLM uT z)
    let tb ← r.inferIO depth b
    let ttb ← r.inferIO depth tb
    let wttb ← r.whnf depth ttb
    match wttb with
    | .sort vT => do
      let z ← pure .zero
      let okB ← liftFueled "level comparison" (← isEquivLM vT z)
      pure (okA && okB)
    | _ => pure false
  | _ => pure false

/-- The projection-application spine
`[proj_0 targs b, …]` (structural recursion; the spec side is a pure
`List.map`). -/
def projAppsFnI (T : Name) (us' : List Level) (targs : List Expr)
    (b : Expr) : List Nat → CheckCM (List Expr)
  | [] => pure []
  | i :: rest => do
    let pf ← pure (projFnName T i)
    let h ← pure (Expr.const pf us')
    let r ← mkAppNM h (targs ++ [b])
    let rs ← projAppsFnI T us' targs b rest
    pure (r :: rs)

/-- The `.proj T i b` spine (the tower spelling, task #175
W4c). -/
def projNodesI (T : Name) (b : Expr) : List Nat → CheckCM (List Expr)
  | [] => pure []
  | i :: rest => do
    let r ← pure (Expr.proj T i b)
    let rs ← projNodesI T b rest
    pure (r :: rs)

/-- Twin of `etaProjs`: the tower spelling at an all-tower slot family
(`towerSlotsAll` through the index), the projection-function spelling
otherwise. -/
def projAppsI (fe : FEnv) (Tn T : Name) (us' : List Level)
    (targs : List Expr) (b : Expr) (nF : Nat) :
    CheckCM (List Expr) :=
  if fe.towerSlotsAllF Tn nF then
    projNodesI T b (List.range nF)
  else projAppsFnI T us' targs b (List.range nF)

/-- Twin of `structEtaProjCerts`. -/
def structEtaProjCertsI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (TI : Name) (T : Name) (us' : List Level) (targs : List Expr)
    (b : Expr)
    (lpsT : List Name) : List Nat → CheckCM Bool
  | [] => pure true
  | i :: rest => do
    match fe.find? (projFnName T i) with
    | some (.recInfo cvp _ _ _) =>
      if cvp.levelParams = lpsT ∧
          (cvp.type.stripPis (targs.length + 1)).isSome = true then do
        let pf ← pure (projFnName TI i)
        let pty ← constTyAtM fe pf (projFnName T i) us'
        if ← iotaCertsI r fe depth false pty (targs ++ [b]) then
          structEtaProjCertsI r fe depth TI T us' targs b lpsT rest
        else pure false
      else pure false
    | _ => pure false

/-- Twin of `structEtaCertWith`. -/
def structEtaCertWithI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (a b wtb : Expr) : CheckCM Bool := do
  match Expr.getAppFn a with
  | .const c us => do
    let cn ← pure c
    match fe.find? cn with
    | some (.ctorInfo cvc cnP cnF) => do
      let aargs ← pure (Expr.getAppArgsC a)
      if aargs.length = cnP + cnF then
        match Expr.getAppFn wtb with
        | .const T us' => do
          let Tn ← pure T
          match fe.find? Tn with
          | some (.indInfo cvT caps) => do
            let targs ← pure (Expr.getAppArgsC wtb)
            if caps.eta = true ∧ caps.etaCtor = cn ∧
                reservedBasisNames.contains Tn = false ∧
                reservedBasisNames.contains cn = false ∧
                targs.length = caps.etaParams ∧
                us'.length = cvT.levelParams.length ∧
                cvc.levelParams = cvT.levelParams ∧
                (fe.towerSlotsAllF Tn caps.etaFields ||
                  fe.recSlotsAllF Tn caps.etaFields) = true then do
              if ← liftFueled "level comparison"
                  (← isEquivListLM us us') then do
                let tyT ← constTyAtM fe T Tn us'
                -- the type-former telescope certificate and the
                -- per-slot ones are certificate families (official's
                -- `try_eta_struct_core` runs neither); off at `.trusted`
                if ← certAtI mode (iotaCertsI r fe depth false tyT targs) then do
                  -- the per-slot certificates are the projection-function
                  -- kind's; a tabled family has none (task #175 S1)
                  if ← certAtI mode
                      (if fe.towerSlotsAllF Tn caps.etaFields then pure true
                      else structEtaProjCertsI r fe depth T Tn us'
                        targs b cvT.levelParams
                        (List.range caps.etaFields)) then do
                    if ← defEqListI r fe depth
                        (aargs.take caps.etaParams) targs then do
                      let projs ← projAppsI fe Tn T us' targs b caps.etaFields
                      -- synthetic-spine certification (task #137): the
                      -- fabricated constructor application
                      -- `c targs (proj_i … b)` is certified against the
                      -- constructor's own telescope, here rather than at
                      -- the callers, so that BOTH consumers get it —
                      -- `majorToCtorI`'s eta rescue ran it already
                      -- (task #71), `defeq`'s `structEtaCertI` did not.
                      -- TT-lane check (task #147): skipped unless
                      -- `mode.ttChecks`, a literal `false` at
                      -- both shipped cores.
                      if ← (if mode.ttChecks then do
                          let tyCtor ← constTyAtM fe c cn us
                          iotaCertsI r fe depth false tyCtor (targs ++ projs)
                        else pure true) then
                        defEqListI r fe depth (aargs.drop caps.etaParams) projs
                      else pure false
                    else pure false
                  else pure false
                else pure false
              else pure false
            else pure false
          | _ => pure false
        | _ => pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- Twin of `structEtaCert`. -/
def structEtaCertI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  -- the constructor-shape gate first (D13), as in the spec
  let sh ← pure (etaCtorShapeC fe a)
  if sh then
    let tb ← r.inferIO depth b
    let wtb ← r.whnf depth tb
    structEtaCertWithI mode r fe depth a b wtb
  else pure false

/-- Twin of `structUnitCert`. -/
def structUnitCertI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  let ta ← r.inferIO depth a
  let wta ← r.whnf depth ta
  match Expr.getAppFn wta with
  | .const T us' => do
    let Tn ← pure T
    match fe.find? Tn with
    | some (.indInfo cvT caps) => do
      let targs ← pure (Expr.getAppArgsC wta)
      if caps.unitlike = true ∧
          reservedBasisNames.contains Tn = false ∧
          targs.length = caps.unitParams ∧
          us'.length = cvT.levelParams.length then do
        let tb ← r.inferIO depth b
        let wtb ← r.whnf depth tb
        if ← r.defeq depth wta wtb then do
          -- the type-former telescope certificate (a certificate
          -- family: official's `is_def_eq_unit_like` stops at the
          -- defeq above); off at `.trusted`
          let tyT ← constTyAtM fe T Tn us'
          certAtI mode (iotaCertsI r fe depth false tyT targs)
        else pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- Twin of `etaCert` (the λ's pieces come pre-destructured, as in the
spec). -/
def etaCertI (r : CoreFnsI) (_fe : FEnv) (depth : Nat)
    (ty₁ body₁ : Expr) (m₁ : BinderMeta) (b : Expr) :
    CheckCM Bool := do
  let tb ← r.inferIO depth b
  let wtb ← r.whnf depth tb
  match wtb with
  | .forallE ty₂ _ m₂ => do
    -- prop-ness agreement checked LAST (task #161); see `etaCert`
    if ← r.defeq depth ty₂ ty₁ then do
      let fv ← pure (Expr.fvar depth ty₁)
      let b₁ ← inst1M body₁ fv
      let ba ← pure (Expr.app b fv)
      unless ← r.defeq (depth + 1) b₁ ba do return false
      if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
        throw (.notImplemented "sort-annotation mismatch (eta)")
      pure true
    else pure false
  | _ => pure false

/-- Twin of `stuckIrrel`. -/
def stuckIrrelI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool := do
  if ← structEtaCertI mode r fe depth a b then pure true
  else if ← structEtaCertI mode r fe depth b a then pure true
  else if ← structUnitCertI mode r fe depth a b then pure true
  else proofIrrelI r depth a b

/-- Twin of `majorToCtor`. -/
def majorToCtorI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (_recName : Name) (rules : List RecRule) (major : Expr) :
    CheckCM Expr := do
  if ← pure (isCtorAppC fe major) then pure major else
  match rules with
  | [rl] =>
    match fe.find? rl.ctor with
    | some (.ctorInfo cvj cnP _cnF) =>
      match (cvj.type.piResult).getAppFn with
      | .const T _ =>
        match fe.find? T with
        | some (.indInfo cvT caps) =>
          if rl.k = true then do
            let tmaj₀ ← r.inferIO depth major
            let tmaj ← r.whnf depth tmaj₀
            match Expr.getAppFn tmaj with
            | .const T' ust =>
              if (← pure (T' == T)) ∧ cvj.levelParams.length = ust.length then do
                let margs ← pure (Expr.getAppArgsC tmaj)
                if cnP ≤ margs.length then do
                  let ctorI ← pure rl.ctor
                  let h ← pure (Expr.const ctorI ust)
                  let fab ← mkAppNM h (margs.take cnP)
                  if ← pure (Expr.wscopedBC depth fab &&
                      Expr.looseBVarsBounded 0 fab &&
                      Expr.leafGuard fab major) then do
                    -- synthetic-spine certification (task #71): a
                    -- fabricated constructor spine keeps the ungated
                    -- telescope certificate, relocated here from the
                    -- fire path
                    let tyCtor ← constTyAtM fe ctorI rl.ctor ust
                    -- (a certificate family; off at `.trusted`)
                    if ← certAtI mode (iotaCertsI r fe depth false tyCtor
                        (margs.take cnP)) then do
                      -- official `to_cnstr_when_K` fabrication type
                      -- check (load-bearing with the major-slot
                      -- certificate gated at nonzero motives, tasks
                      -- #49/#71; arena bad/098_ruleKbad) — runs in
                      -- both modes; `proofIrrelI` stays as the
                      -- soundness certificate, a certificate family
                      -- (official stops at the type check), off at
                      -- `.trusted`
                      let tfab ← r.inferIO depth fab
                      if ← r.defeq depth tmaj tfab then
                        if ← certAtI mode (proofIrrelI r depth fab major) then
                          pure fab
                        else pure major
                      else pure major
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else if rl.eta = true then do
            let tmaj₀ ← r.inferIO depth major
            let tmaj ← r.whnf depth tmaj₀
            match Expr.getAppFn tmaj with
            | .const T' ust => do
              let margs ← pure (Expr.getAppArgsC tmaj)
              let ustL ← pure ust
              -- instantiated non-Prop guard, as in the spec body
              -- `majorToCtor` (task #61)
              if (← pure (T' == T)) ∧ margs.length = caps.etaParams ∧
                  ust.length = cvT.levelParams.length ∧
                  capsNeverZero cvT.levelParams ustL caps = true then do
                let TI ← pure T
                let projs ← projAppsI fe T TI ust margs major caps.etaFields
                let ctorI ← pure caps.etaCtor
                let h ← pure (Expr.const ctorI ust)
                let fab ← mkAppNM h (margs ++ projs)
                if ← pure (Expr.wscopedBC depth fab &&
                    Expr.looseBVarsBounded 0 fab &&
                    Expr.leafGuard fab major) then do
                  -- synthetic-spine certification, as in the K
                  -- branch (task #71)
                  let tyCtor ← constTyAtM fe ctorI rl.ctor ust
                  -- (a certificate family; off at `.trusted`)
                  if ← certAtI mode (iotaCertsI r fe depth false tyCtor
                      (margs ++ projs)) then do
                    if ← structEtaCertWithI mode r fe depth fab major
                        tmaj then
                      pure fab
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else if T = andName then do
            -- the `And`-only rescue, as in the spec body
            let tmaj₀ ← r.inferIO depth major
            let tmaj ← r.whnf depth tmaj₀
            match Expr.getAppFn tmaj with
            | .const T' ust => do
              let margs ← pure (Expr.getAppArgsC tmaj)
              if (← pure (T' == T)) ∧ margs.length = cnP ∧
                  cvj.levelParams.length = ust.length ∧
                  fe.andRescueSlotsF rl.ctor cnP ust = true then do
                let TI ← pure T
                let projs ← projNodesI TI major [0, 1]
                let ctorI ← pure rl.ctor
                let h ← pure (Expr.const ctorI ust)
                let fab ← mkAppNM h (margs ++ projs)
                if ← pure (Expr.wscopedBC depth fab &&
                    Expr.looseBVarsBounded 0 fab &&
                    Expr.leafGuard fab major) then do
                  let tyCtor ← constTyAtM fe ctorI rl.ctor ust
                  if ← certAtI mode (iotaCertsI r fe depth false tyCtor
                      (margs ++ projs)) then do
                    let tfab ← r.inferIO depth fab
                    if ← r.defeq depth tmaj tfab then
                      if ← certAtI mode (proofIrrelI r depth fab major) then
                        pure fab
                      else pure major
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else pure major
        | _ => pure major
      | _ => pure major
    | _ => pure major
  | _ => pure major

/-- Twin of `litMajorToCtor`. -/
def litMajorToCtorI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (e : Expr) :
    CheckCM Expr := do
  match e with
  | .lit (.strVal s) =>
    if strLitSupportedF fe then do
      let x ← pure (strLitToConstructor s)
      r.whnf depth x
    else pure e
  | _ => litToCtorIfNatI fe e

/-- Twin of `projLitToCtor`. -/
def projLitToCtorI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (e : Expr) :
    CheckCM Expr := do
  match e with
  | .lit (.strVal s) =>
    if strLitSupportedF fe then do
      let x ← pure (strLitToConstructor s)
      r.whnf depth x
    else pure e
  | _ => pure e

/-- Twin of `prepareMajor`: the major's preparation in the official
order (K rescue on the raw major, then whnf and the literal
conversion; elsewhere whnf, literal, eta).  The K flag is the single
rule's stored bit, as in the spec (`recRuleK`). -/
def prepareMajorI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (recName : Name) (rules : List RecRule) (major : Expr) :
    CheckCM Expr := do
  if recRuleK rules then do
    let majorK ← majorToCtorI mode r fe depth recName rules major
    let major₀ ← r.whnf depth majorK
    litMajorToCtorI r fe depth major₀
  else do
    let major₀ ← r.whnf depth major
    let major₁ ← litMajorToCtorI r fe depth major₀
    majorToCtorI mode r fe depth recName rules major₁

/-- The nested-rule pin instantiations (structural recursion;
the spec side is `(recFireComparands …).2`'s `List.map`). -/
def pinArgsI (lps : List Name) (us : List Level) (args : List Expr)
    (t : Nat) : List Expr → CheckCM (List Expr)
  | [] => pure []
  | p :: ps => do
    let praw ← pure p
    let pi ← instLevelParamsM lps us praw
    let r ← instSpineM args t pi
    let rs ← pinArgsI lps us args t ps
    pure (r :: rs)

/-- The length of an application spine, without building its argument
list. -/
def iotaNumArgs : Expr → Nat → Nat
  | .app f _, n => iotaNumArgs f (n + 1)
  | _, n => n

/-- The arity pre-check of the ι step: `iotaRecI` returns `none`
unless the head is a stored recursor applied to exactly `majorIdx + 1`
arguments with the recursor's own number of levels
(`iotaRecI_of_arityOk_false`).  The whnf spine loop asks this before
every ι attempt, which is allocation-free where the ι step's own guard
would first materialise the argument list. -/
def iotaArityOk (fe : FEnv) (e : Expr) : Bool :=
  match Expr.getAppFn e with
  | .const c us =>
    match fe.find? c with
    | some (.recInfo cv mI _ _) =>
      iotaNumArgs e 0 == mI + 1 && us.length == cv.levelParams.length
    | _ => false
  | _ => false

/-- Twin of `iotaRec`. -/
def iotaRecI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (e : Expr) :
    CheckCM (Option Expr) := do
  match Expr.getAppFn e with
  | .const c us => do
    let cn ← pure c
    match fe.find? cn with
    | some (.recInfo cv mI rP rules) => do
      let args ← pure (Expr.getAppArgsC e)
      -- checker change #9 (twin of `Core.lean`'s `iotaRec`): guard the
      -- recursor's level arity before the rule's RHS is instantiated.
      if args.length = mI + 1 ∧ us.length = cv.levelParams.length then do
        let bvar0 ← pure (Expr.mkBvar 0)
        let major ← prepareMajorI mode r fe depth cn rules (args.getD mI bvar0)
        match Expr.getAppFn major with
        | .const cj usj => do
          let cjn ← pure cj
          match fe.find? cjn with
          | some (.ctorInfo cvj _ _) =>
            match rules.find? (fun r' => r'.ctor == cjn) with
            | some rl => do
              let margs ← pure (Expr.getAppArgsC major)
              if margs.length = rl.ctorParams + rl.nfields then
               if rl.fire = .inert then
                 throw (.notImplemented
                   "iota reduction over a nested auxiliary recursor rule")
               else do
                -- (the ι batch: the two `stripPis` pins are gone — see
                -- the spec's `iotaRec`)
                -- the comparands (canonical: recursor's levels/args;
                -- nested: the stored major-domain instantiations)
                let cmpLvls : List Level ←
                  match rl.fire with
                  | .nested lvls _ => substLevelTreesM cv.levelParams us lvls
                  | _ =>
                    substLevelTreesM cv.levelParams us
                      (cvj.levelParams.map Level.param)
                let cmpArgs : List Expr ←
                  match rl.fire with
                  | .nested _ pins =>
                    pinArgsI cv.levelParams us (args.take rP) (rP - 1) pins
                  | _ => pure (args.take rl.ctorParams)
                if ← liftFueled "level comparison"
                    (← isEquivListLM usj cmpLvls) then do
                 -- the parameter comparison: not run at all for a
                 -- `.plain` rule the installing route marked
                 -- `paramsBlind` (`RecRule.compareParams`; official's
                 -- `inductive_reduce_rec` compares nothing).  Where it
                 -- is run it is verdict-relevant for a nested rule
                 -- (the comparands ARE the pins) and for a
                 -- projection-function rule, and a certificate family
                 -- for every other plain rule — the retired twin's
                 -- judgement, kept
                 if ← (if rl.compareParams then
                    certUnlessI mode
                      ((match rl.fire with | .nested _ _ => true | _ => false)
                        || Name.isProjFnShape cn)
                      (defEqListI r fe depth (margs.take rl.ctorParams)
                        cmpArgs)
                    else pure true) then do
                  -- ONE certificate family: the two instantiated
                  -- types, the two telescope runs and the
                  -- canonical-index comparison (which exists only
                  -- where indices do — the spec's `iotaRec`).  The
                  -- telescope runs are licensed (`iotaCertsIAux`) off
                  -- `mode.betaGate` — the same function the β site
                  -- reads, `true` at `.verified`.  Nothing here is
                  -- read outside the family, so the whole block is
                  -- what `.trusted` omits: the types are looked up
                  -- only where a certificate consumes them (DESIGN.md,
                  -- "CORET RETIRED", inversion 22).
                  if ← certAtI mode (do
                      let tyRec ← constTyAtM fe c cn us
                      if ← iotaCertsI r fe depth mode.betaGate tyRec
                          (args.take mI ++ [major]) then do
                        let tyCtor ← constTyAtM fe cj cjn usj
                        if ← iotaCertsI r fe depth mode.betaGate tyCtor
                            margs then
                          iotaIndexOkI r fe depth mI rP rl.ctorParams tyCtor
                            margs ((args.take mI).drop rP)
                        else pure false
                      else pure false) then do
                      let rhs ← ruleRhsAtM fe c cj cn cjn us
                      let red ← mkAppNM rhs
                        (args.take rP ++ margs.drop rl.ctorParams)
                      pure (some red)
                  else pure none
                 else pure none
                else pure none
              else pure none
            | none => pure none
          | _ => pure none
        | _ => pure none
      else pure none
    | _ => pure none
  | _ => pure none

/-- Twin of `projCert`. -/
def projCertI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (lic : Bool)
    (c : Name) (us : List Level) (args : List Expr) : CheckCM Bool := do
  let cn ← pure c
  match fe.find? cn with
  | some (.ctorInfo _ _ _) => do
    let tyC ← constTyAtM fe c cn us
    iotaCertsI r fe depth lic tyC args
  | _ => pure false

/-- Twin of `projCertAt`. -/
def projCertAtI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (verified lic : Bool)
    (c : Name) (us : List Level) (args : List Expr) : CheckCM Bool :=
  if verified then projCertI r fe depth lic c us args else pure true

/-- Twin of `reduceProjCore`. -/
def reduceProjCoreI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (sn : Name)
    (i : Nat) (c : Expr) : CheckCM (Option Expr) := do
  let e' ← projLitToCtorI r fe depth c
  let snn ← pure sn
  match fe.findProj? snn i with
  | some entry =>
    match Expr.getAppFn e' with
    | .const k us => do
      let args ← pure (Expr.getAppArgsC e')
      if (← pure (k == entry.ctor)) ∧ i < entry.numFields ∧
          args.length = entry.numParams + entry.numFields ∧
          us.length = entry.levelParams.length ∧
          entry.fireOk us = true then do
        let bvar0 ← pure (Expr.mkBvar 0)
        let arg := args.getD (entry.numParams + i) bvar0
        -- task #100 de-gating / task #175 W6 / `projCertAt`: see the
        -- spec `reduceProjCore`
        if ← projCertAtI r fe depth mode.verifiedChecks mode.betaGate k us args then
          pure (some arg)
        else pure none
      else pure none
    | _ => pure none
  | none => pure none

mutual

/-- Bulk-beta argument loop (task #50): consume the whole application
spine against the whnf'd head `v`.  A lambda head enters the peel loop
(first binder inline, which keeps the argument count decreasing);
other heads try iota with one more argument and otherwise accumulate a
stuck application — exactly the per-level `whnfCoreBody` app clauses,
but with the chained per-argument `instantiate1` of the beta path
replaced by one bulk substitution per peeled group
(`ConLeche/Verify/BetaSpine.lean` proves the identification).  The
head-normalization loop's continuation `k` is threaded through
(task #106). -/
def whnfAppI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (k : Expr → CheckCM Expr) :
    Expr → List Expr → CheckCM Expr
  | v, [] => pure v
  | v, a :: rest => do
    match v with
    | .lam ty body mb => do
        -- task #161: the β gate is a pure early return; the `else`
        -- arm is the pre-gate clause, verbatim (`betaGateFires`)
        if mode.betaSkip mb.pw then
          betaPeelI r fe depth k body [a] rest
        else do
          -- task #172 B4: the β certificate's inference at the io grade
          let ta ← r.inferIO depth a
          if ← r.defeq depth ta ty then
            betaPeelI r fe depth k body [a] rest
          else do
            let fa ← pure (Expr.app v a)
            mkAppNM fa rest
    | _ => do
      let fa ← pure (Expr.app v a)
      -- the ι step is tried only where it could fire; every other
      -- prefix of the spine returns `none` by `iotaRecI`'s own guard
      match ← (if iotaArityOk fe fa then iotaRecI mode r fe depth fa
               else pure none) with
      | some e'' => do
        let v' ← k e''
        whnfAppI r fe depth k v' rest
      | none => whnfAppI r fe depth k fa rest
termination_by _ args => (args.length, 0)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp; done)
    | (apply Prod.Lex.right' <;> simp)

/-- Peel loop of `whnfAppI`: `t` is the raw (unsubstituted) lambda body
after the binders consumed so far, `acc` their arguments (innermost
first).  Each binder's argument certificate (unconditional since the
task-#100 de-gating) substitutes only the *domain*; the body is
substituted once, when peeling stops. -/
def betaPeelI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (k : Expr → CheckCM Expr) :
    Expr → List Expr → List Expr → CheckCM Expr
  | t, acc, [] => do
    let e' ← instListM t acc
    k e'
  | t, acc, a :: rest => do
    match t with
    | .lam ty body mb => do
        -- task #161: the β gate is a pure early return; the `else`
        -- arm is the pre-gate clause, verbatim (`betaGateFires`)
        if mode.betaSkip mb.pw then
          betaPeelI r fe depth k body (a :: acc) rest
        else do
          let ty' ← instListM ty acc
          -- task #172 B4: the io grade (see `whnfAppI`)
          let ta ← r.inferIO depth a
          if ← r.defeq depth ta ty' then
            betaPeelI r fe depth k body (a :: acc) rest
          else do
            let f' ← instListM t acc
            let fa ← pure (Expr.app f' a)
            mkAppNM fa rest
    | _ => do
      let e' ← instListM t acc
      let v ← k e'
      whnfAppI r fe depth k v (a :: rest)
termination_by _ _acc args => (args.length, 1)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp; done)
    | (apply Prod.Lex.right' <;> simp)

end

/-- One head-normalization step of `whnfCoreBody` (beta, iota,
projection) with the loop's continuation `k` abstracted, in the
open-recursion style of the whole module; `cheap` is the official
`cheap_proj` flag (see `whnfCoreBody`).  Only the spine head's
normalization stays a knot call (genuine nesting, bounded by the
term's depth); every *reduction* step is iteration, so a chain no
longer charges the shared recursion-depth budget one unit per step
(task #106 — that is what made the `Nat.brecOn` grind of
`Std.Time…toDays._proof_1` exhaust `checkFuel`). -/
def whnfCoreStepI (r : CoreFnsI) (fe : FEnv) (cheap : Bool) (depth : Nat)
    (k : Expr → CheckCM Expr) (e : Expr) : CheckCM Expr := do
    match e with
    | .sort _ | .fvar .. | .forallE ..
    | .lam .. | .const .. | .lit _ => pure e
    | .app _ _ => do
      -- Bulk beta (task #50): normalize the spine head once and run the
      -- argument loop over the whole spine, batching consecutive
      -- lambda binders into one substitution.
      let h ← pure (Expr.getAppFn e)
      let args ← pure (Expr.getAppArgsC e)
      let v ← r.whnfCore cheap depth h
      whnfAppI mode r fe depth k v args
    | .proj sn i pe => do
      -- the scrutinee by `whnf`, or by the cheap `whnfCore` in the
      -- cheap mode; stuck: the input itself, scrutinee as it was (see
      -- `whnfCoreBody`)
      let c ← if cheap then r.whnfCore true depth pe else r.whnf depth pe
      match ← reduceProjCoreI mode r fe depth sn i c with
      | some m' => k m'
      | none => pure e
    | .letE _ _ _ =>
      -- unreachable by construction, as in the spec body (task #241):
      -- the annotate pass returns the ζ reduct, so no `letE` node
      -- survives into the checked world
      throw (.internal "whnfCore: `let` in an annotated expression")
    | .bvar _ =>
      throw (.notImplemented "whnf beyond the supported fragment")

/-- Iterate `whnfCoreStepI` on its own step budget (pure mirror:
`whnfCoreLoopM`, `ConLeche/Verify/BetaSpine.lean`). -/
def whnfCoreLoopI (r : CoreFnsI) (fe : FEnv) (cheap : Bool) (depth : Nat) :
    Nat → Expr → CheckCM Expr
  | 0, _ => throw (.internal "fuel exhausted: whnfCore loop")
  | n + 1, e =>
    whnfCoreStepI mode r fe cheap depth (whnfCoreLoopI r fe cheap depth n) e

/-- Twin of `whnfCoreBody`: the head-normalization loop at its own step
budget. -/
def whnfCoreBodyI (r : CoreFnsI) (fe : FEnv) : Bool → Nat → Expr → CheckCM Expr :=
  fun cheap depth e => whnfCoreLoopI mode r fe cheap depth whnfCoreLoopFuel e

/-- Application-inference spine loop (task #50): walk the raw
Π-telescope against the arguments with deferred substitution — each
argument's certificate substitutes only its *domain*; the codomain is
substituted once per peeled group.  A non-syntactic telescope step
substitutes and normalizes, exactly like the chained `inferBody`
recursion (`ConLeche/Verify/BetaSpine.lean` proves the
identification). -/
def inferSpineI (r : CoreFnsI) (fe : FEnv) (depth : Nat) :
    Expr → Array Expr → List Expr → CheckCM Expr
  | ty, acc, [] => instListRevM ty acc
  | ty, acc, a :: rest => do
    match ty with
    | .forallE dom body _mt => do
      -- per-argument re-check (task #100 de-gating: the former
      -- possibly-Prop gate of task #49 is unsound-to-model under the
      -- domain-relative collapse; the certificate runs
      -- unconditionally, as in the spec body `inferBody`)
      let dom' ← instListRevM dom acc
      let ta ← r.infer depth a
      unless ← r.defeq depth ta dom' do
        throw (.invalid "application type mismatch")
      inferSpineI r fe depth body (acc.push a) rest
    | _ => do
      let ty' ← instListRevM ty acc
      let w ← r.whnf depth ty'
      match w with
      | .forallE dom body _mt => do
        let ta ← r.infer depth a
        unless ← r.defeq depth ta dom do
          throw (.invalid "application type mismatch")
        inferSpineI r fe depth body #[a] rest
      | _ => throw (.invalid "function expected")

/-- **The io-grade spine walk** (task #172 B4): `inferSpineI` with the
per-argument certificate gated — the ONE io-graded check
(`inferBodyIO`'s app clause, `ConLeche/Kernel/Core.lean`), in the bulk
telescope form.  At a ∀ step whose annotation datum is `.never` the
argument's inference and the domain comparison are skipped; the
returned type is the same telescope walk either way, so the lane is
annotation-blind in its results.  A syntactic `.forallE` is its own
whnf, so the syntactic step's datum is the datum the pure io body
reads off the whnf'd type.

**The licence reads the datum and nothing else** (the ruling of
2026-09-06).  It used to carry a `mode.verifiedChecks &&` mode conjunct; that
conjunct made the *trusted* core run the certificate the verified core
skips — an inversion of what the trusted mode is defined to be (the
real mode with certification-only steps omitted).  Validating the
datum is certification-only work and stays in group A; consuming it is
not.  The P tier's licensing theorem (`io_domain_transfer`,
`Model/IOLicense.lean`) never used the mode conjunct either: it spends
only `pwBit_ne_zero_of_isNever`.

**The read is `mode.ioSkip mt.pw`** (the twin's retirement): at
`.verified` that is `mt.pw.isNever` by `rfl` — the datum alone, as
above — and at `.trusted` it is `true`: the per-argument
certificate at an internal inference is a certificate family
(official's `infer_only` runs none), skipped wholesale. -/
def inferSpineIOI (r : CoreFnsI) (fe : FEnv) (depth : Nat) :
    Expr → Array Expr → List Expr → CheckCM Expr
  | ty, acc, [] => instListRevM ty acc
  | ty, acc, a :: rest => do
    match ty with
    | .forallE dom body mt => do
      unless mode.ioSkip mt.pw do
        let dom' ← instListRevM dom acc
        let ta ← r.infer depth a
        unless ← r.defeq depth ta dom' do
          throw (.invalid "application type mismatch")
      inferSpineIOI r fe depth body (acc.push a) rest
    | _ => do
      let ty' ← instListRevM ty acc
      let w ← r.whnf depth ty'
      match w with
      | .forallE dom body mt => do
        unless mode.ioSkip mt.pw do
          let ta ← r.infer depth a
          unless ← r.defeq depth ta dom do
            throw (.invalid "application type mismatch")
        inferSpineIOI r fe depth body #[a] rest
      | _ => throw (.invalid "function expected")

/-- Twin of `whnfStep`. -/
def whnfStepI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (k : Expr → CheckCM Expr) (e : Expr) : CheckCM Expr := do
  let e₁ ← r.whnfCore false depth e
  match ← reduceNatI r fe depth e₁ with
  | some e₂ => k e₂
  | none =>
    match ← unfoldDefinitionI fe e₁ with
    | some e₂ => k e₂
    | none => pure e₁

/-- Twin of `whnfLoop`. -/
def whnfLoopI (r : CoreFnsI) (fe : FEnv) (depth : Nat) :
    Nat → Expr → CheckCM Expr
  | 0, _ => throw (.internal "fuel exhausted: whnf loop")
  | n + 1, e => whnfStepI r fe depth (whnfLoopI r fe depth n) e

/-- Twin of `whnfBody`. -/
def whnfBodyI (r : CoreFnsI) (fe : FEnv) : Nat → Expr → CheckCM Expr :=
  fun depth e => whnfLoopI r fe depth whnfLoopFuel e

/-- Twin of `ensureSort` (returns the level; no readback needed). -/
def ensureSortI (r : CoreFnsI) (depth : Nat) (e : Expr) : CheckCM Level := do
  let w ← r.whnf depth e
  match w with
  | .sort u => pure u
  | _ => throw (.invalid "expected a sort")

/-! ### Binder-telescope loops (task #72)

The official-kernel discipline (lean4lean's `inferLambda`/`inferForall`
loops): peel a whole binder telescope accumulating opened free
variables, substituting only each binder's *domain* on the way in
(domains are small; `instListM` against the accumulator), infer or
annotate the leaf once on the bulk-opened body, then rebuild with one
`abstractRange` per domain and one over the leaf.  Each loop replays
exactly the per-binder checks of the chained recursion, in order; the
value-level identification with the chained spec bodies is
`ConLeche/Verify/BinderLoop.lean` (`Verify/Cached/BinderLoopC.lean` relates the loops to
their pure mirrors, and `_sound` theorems reproduce a mirror run
in the original one-binder-at-a-time body at some fuel).
The peel fuel is semantically transparent: on exhaustion the leaf phase hands
the residual binder chain back to the knot, which is exactly the
chained spec's next step. -/

/-- Stack entry of `inferLamsI`: binder name, opened domain and binder
meta. -/
abbrev InferLamEntry := Expr × BinderMeta

/-- Rebuild loop of `inferLamsI`: fold the stack (innermost binder
first, `j` its binder level relative to the ambient depth `d`).  The
intermediate `∀`-node inferences of the chained body are
value-determined by the peel phase's domain sorts and the leaf phase's
body-type sort and cannot fail (task #100 stage 6: the per-level
λ-annotation re-check is gone with the stored annotations). -/
def inferLamsOutI (d : Nat) :
    List InferLamEntry → Nat → Expr → PropWhen → CheckCM Expr
  | [], _j, cur, _prevPw => pure cur
  | (tyo, mb) :: rest, j, cur, prevPw => do
    -- Task #161, the chain rule (see `inferBody`'s `.lam` clause): a
    -- node's prop-ness annotation must agree with its inner
    -- neighbour's (the innermost step compares the entry with itself
    -- — vacuously true).
    if mode.verifiedChecks && !(mb.pw == prevPw) then
      throw (.notImplemented "sort-annotation mismatch (lam-cod-chain)")
    let tyAbs ← abstractRangeM tyo d j
    let node ← pure (Expr.forallE tyAbs cur mb)
    inferLamsOutI d rest (j - 1) node mb.pw

/-- Leaf phase of `inferLamsI`: bulk-open the residual body, infer it,
then rebuild outward.

Task #152: at the verified modes the chain's body type is
sort-checked here — the spec's codomain check (`inferBody`'s `.lam`
clause), which fires at the innermost binder of a λ-chain, i.e.
exactly when the peel stops on a non-λ residual.  The guard is the
same one the spec uses, on the same term. -/
def inferLamsLeafI (r : CoreFnsI) (d : Nat) (t : Expr) (k : Nat)
    (fvs : Array Expr) (stk : List InferLamEntry) : CheckCM Expr := do
  let ob ← instListRevM t fvs
  let bt ← r.infer (d + k) ob
  match t with
  | .lam .. => pure ()
  | _ =>
    if mode.verifiedChecks then
      let btt ← r.inferIO (d + k) bt
      let wbtt ← r.whnf (d + k) btt
      match wbtt with
      | .sort vb =>
        -- Task #161: validate the innermost binder's prop-ness
        -- annotation against the chain's body-type sort — the leaf
        -- half of the spec's `.lam` clause check.
        match stk with
        | (_, mb₀) :: _ => do
          let pv ← pure (Level.zeronessOf vb)
          unless pv == mb₀.pw do
            throw (.notImplemented
              "sort-annotation mismatch (lam-cod-leaf)")
        | [] => pure ()
      | _ => throw (.invalid "expected a sort")
  let cur ← abstractRangeM bt d k
  -- The fold's initial neighbour: a λ residual (the fuel-exhausted
  -- path) supplies its own annotation — the head entry's chain check
  -- then compares against it, exactly as the spec's per-node clause
  -- does; a non-λ residual makes the head entry's step vacuous (its
  -- codomain fact is the leaf check above).
  let prevPw ← do
    match t with
    | .lam _ _ mbT => pure mbT.pw
    | _ =>
      pure (match stk with
        | (_, mb₀) :: _ => mb₀.pw
        | [] => .never)
  inferLamsOutI mode d stk (k - 1) cur prevPw

/-- λ-telescope inference loop (task #72; used by `inferBodyI`'s and
`inferBodyIOI`'s lam cases): peel the raw λ-chain, checking each opened
domain to be a type on the way in.  `k` counts the opened binders
(`≥ 1`: the caller peels the first binder inline), `fvs` their free
variables innermost-first. -/
def inferLamsI (r : CoreFnsI) (d : Nat) :
    Nat → Expr → Nat → Array Expr → List InferLamEntry → CheckCM Expr
  | fuel + 1, t, k, fvs, stk => do
    match t with
    | .lam ty body mb => do
      let tyo ← instListRevM ty fvs
      let tty ← r.infer (d + k) tyo
      let wtty ← r.whnf (d + k) tty
      match wtty with
      | .sort _ => do
        let fv ← pure (Expr.fvar (d + k) tyo)
        inferLamsI r d fuel body (k + 1) (fvs.push fv)
          ((tyo, mb) :: stk)
      | _ => throw (.invalid "expected a sort")
    | _ => inferLamsLeafI mode r d t k fvs stk
  | 0, t, k, fvs, stk => inferLamsLeafI mode r d t k fvs stk

/-- Rebuild loop of `inferPisI`: fold the accumulated domain sorts by
`imax`, innermost binder first — exactly the chained `∀`-rule's result
value.

Task #272 (GitHub issue #9): the codomain sort's zero-ness datum is
THREADED, not recomputed.  `zeronessOf (imax u v) = zeronessOf v`
holds definitionally, so every node of a ∀ telescope shares the leaf's
datum — the chain the annotation loop already folds
(`annotateBindersOutI`).  The fold used to read it out of a
`Level`-keyed memo, which MISSED at every step (a node's key
`.imax u v` is new each time) and then walked `zeronessOf` down the
growing right spine: `O(k²)` in the telescope depth `k`, and it was
90 % of the check phase on a ∀ chain of 40 000 binders. -/
def inferPisOutI : List (Level × PropWhen) → Level → PropWhen →
    CheckCM Level
  | [], v, _pv => pure v
  | (u, pw) :: rest, v, pv => do
    -- Task #161: validate the node's prop-ness annotation against its
    -- inferred codomain sort (`pv` is the zero-ness of `v`, the spec
    -- `∀`-clause's `v` at this node).
    if mode.verifiedChecks && !(pv == pw) then
      throw (.notImplemented "sort-annotation mismatch (forall-cod)")
    let v' ← pure (.imax u v)
    -- `zeronessOf v' = zeronessOf v = pv` (the `.imax` clause).
    inferPisOutI rest v' pv

/-- Leaf phase of `inferPisI`: bulk-open the residual body, infer its
sort, then fold the domain sorts outward. -/
def inferPisLeafI (r : CoreFnsI) (d : Nat) (t : Expr) (k : Nat)
    (fvs : Array Expr) (stk : List (Level × PropWhen)) : CheckCM Expr := do
  let ob ← instListRevM t fvs
  let bt ← r.infer (d + k) ob
  let wbt ← r.whnf (d + k) bt
  match wbt with
  | .sort v => do
    let iv ← inferPisOutI mode stk v (Level.zeronessOf v)
    pure (Expr.sort iv)
  | _ => throw (.invalid "expected a sort")

/-- ∀-telescope inference loop (task #100 stage 6: the `∀`-rule infers
its codomain sort — the stored annotation is not read): peel the raw
∀-chain, checking each opened domain to be a type on the way in and
accumulating its sort, infer the bulk-opened leaf's sort once, and
fold `imax` outward. -/
def inferPisI (r : CoreFnsI) (d : Nat) :
    Nat → Expr → Nat → Array Expr → List (Level × PropWhen) →
      CheckCM Expr
  | fuel + 1, t, k, fvs, stk => do
    match t with
    | .forallE ty body mb => do
      let tyo ← instListRevM ty fvs
      let tty ← r.infer (d + k) tyo
      let wtty ← r.whnf (d + k) tty
      match wtty with
      | .sort u => do
        let fv ← pure (Expr.fvar (d + k) tyo)
        inferPisI r d fuel body (k + 1) (fvs.push fv)
          ((u, mb.pw) :: stk)
      | _ => throw (.invalid "expected a sort")
    | _ => inferPisLeafI mode r d t k fvs stk
  | 0, t, k, fvs, stk => inferPisLeafI mode r d t k fvs stk

/-- Twin of `inferBody`. -/
def inferBodyI (r : CoreFnsI) (fe : FEnv) : Nat → Expr → CheckCM Expr :=
  fun depth e => do
    match e with
    | .sort u => do
      let su ← pure (.succ u)
      pure (Expr.sort su)
    | .fvar idx ty =>
      if idx < depth then pure ty
      else throw (.invalid "free variable out of scope")
    | .const n us => do
      let nm ← pure n
      match fe.find? nm with
      | none => throw (unknownConstError nm)
      | some ci =>
        unless !ci.isTowerEntry do
          throw (.invalid s!"projection table entry used as a constant {nm}")
        let cv := ci.toConstantVal
        unless us.length = cv.levelParams.length do
          throw (.invalid s!"incorrect number of universe levels for {nm}")
        constTyAtM fe n nm us
    | .lit (.natVal _) => do
      if natLitSupportedF fe then do
        let ni ← pure natName
        pure (Expr.const ni [])
      else throw (.invalid "Nat literal without the Nat basis declarations")
    | .lit (.strVal _) => do
      if strLitSupportedF fe then do
        let si ← pure stringName
        pure (Expr.const si [])
      else throw (.notImplemented
        "string literals before the String support declarations")
    | .forallE ty body mb => do
      -- Binder-telescope loop (task #72 discipline; the codomain sort
      -- is inferred; task #161: each node's prop-ness annotation is
      -- validated against it in the rebuild fold).
      let tty ← r.infer depth ty
      let wtty ← r.whnf depth tty
      match wtty with
      | .sort u => do
        let fv ← pure (Expr.fvar depth ty)
        let fuel ← peelFuelM
        inferPisI mode r depth fuel body 1 #[fv] [(u, mb.pw)]
      | _ => throw (.invalid "expected a sort")
    | .lam ty body mb => do
      let tty ← r.infer depth ty
      let wtty ← r.whnf depth tty
      match wtty with
      | .sort _ => do
        -- Binder-telescope loop (task #72): peel the whole λ-chain,
        -- open in bulk, rebuild with `abstractRange`.
        let fv ← pure (Expr.fvar depth ty)
        let fuel ← peelFuelM
        inferLamsI mode r depth fuel body 1 #[fv] [(ty, mb)]
      | _ => throw (.invalid "expected a sort")
    | .app _ _ => do
      -- Bulk telescope consumption (task #50): infer the spine head
      -- once and walk its Π-telescope against the whole spine.
      let h ← pure (Expr.getAppFn e)
      let args ← pure (Expr.getAppArgsC e)
      let tf ← r.infer depth h
      inferSpineI r fe depth tf #[] args
    | .proj sn i pe => do
      let tpe ← r.infer depth pe
      let te ← r.whnf depth tpe
      match Expr.getAppFn te with
      | .const T us => do
        let Tn ← pure T
        match fe.findProj? Tn i with
        | some entry => do
          let targs ← pure (Expr.getAppArgsC te)
          if T = sn ∧ targs.length = entry.numParams ∧
              us.length = entry.levelParams.length then do
            -- the official `infer_proj` restriction (task #175
            -- W4c/O4), as in the spec body
            if Level.isEquiv entry.structSort .zero == some true then
              unless Level.isEquiv
                  (Level.subst entry.levelParams us entry.fieldSort) .zero
                  == some true do
                throw (.invalid
                  "projection from a propositional structure must be a proposition")
            -- the body at the arguments and the subject, as in the
            -- spec body (task #175 S1) — through the memoized,
            -- sharing-preserving `Expr` instantiations
            -- (`ProjEntry.typeAtI`; the spec's `typeAt` is a tree walk
            -- that copied the subject and the parameters — the affine
            -- frontier's out-of-memory, DESIGN.md "The affine frontier")
            pure (entry.typeAtI us targs pe)
          else throw (.notImplemented "projection without a native entry")
        | none => throw (.notImplemented "projection without a native entry")
      | _ => throw (.notImplemented "projection without a native entry")
    | .letE _ _ _ =>
      -- unreachable by construction, as in the spec body (task #241):
      -- the official `infer_let` triple lives in `annotateBodyI`'s own
      -- `.letE` clause, which returns the ζ reduct (task #217)
      throw (.internal "inferType: `let` in an annotated expression")
    | .bvar _ =>
      throw (.notImplemented "inferType beyond the supported fragment")

/-- **The io-grade inference body** (task #172 B4): `inferBodyI` with
exactly the application clause changed — the spine walk is the gated
`inferSpineIOI` (the ONE io-graded check).  Every non-application
view dispatches to `inferBodyI`'s own clause, so there is no textual
clone to drift: the two bodies differ in one clause by construction.
Recursion grade is the record's: the knot ties this body to
`CoreFnsI.ioView`, so `r.infer` here is the io slot one level down —
the grade propagates exactly as official's `infer_only` does. -/
def inferBodyIOI (r : CoreFnsI) (fe : FEnv) : Nat → Expr → CheckCM Expr :=
  fun depth e => do
    match e with
    | .app _ _ => do
      let h ← pure (Expr.getAppFn e)
      let args ← pure (Expr.getAppArgsC e)
      let tf ← r.infer depth h
      inferSpineIOI mode r fe depth tf #[] args
    | .forallE ty body mb => do
      -- the pure io ∀ clause, **chained** (deliberately not the
      -- task-#72 telescope loop: the loops are the front door's
      -- optimization, and looping the io lane would owe the whole
      -- loop-identification walk family a second, io-graded instance
      -- for a lane whose subjects are internal re-inferences —
      -- recorded in the B4 seal as a measured-need follow-up)
      let tty ← r.infer depth ty
      let wtty ← r.whnf depth tty
      match wtty with
      | .sort u => do
        let fv ← pure (Expr.fvar depth ty)
        let ob ← inst1M body fv
        let bt ← r.infer (depth + 1) ob
        let v ← ensureSortI r (depth + 1) bt
        if mode.verifiedChecks then
          unless Level.zeronessOf v == mb.pw do
            throw (.notImplemented "sort-annotation mismatch (forall-cod)")
        let iu ← pure (.imax u v)
        pure (Expr.sort iu)
      | _ => throw (.invalid "expected a sort")
    | .lam ty body mb => do
      -- the pure io λ clause, chained; no domain-sort run (task #168
      -- stage 2, as in the spec)
      let fv ← pure (Expr.fvar depth ty)
      let ob ← inst1M body fv
      let bt ← r.infer (depth + 1) ob
      if mode.verifiedChecks then
        match body.lamPw with
        | some pwI =>
          unless mb.pw == pwI do
            throw (.notImplemented
              "sort-annotation mismatch (lam-cod-chain)")
        | none =>
          let btt ← r.infer (depth + 1) bt
          let vb ← ensureSortI r (depth + 1) btt
          unless Level.zeronessOf vb == mb.pw do
            throw (.notImplemented
              "sort-annotation mismatch (lam-cod-leaf)")
      let bAbs ← abstract1M bt depth
      pure (Expr.forallE ty bAbs mb)
    | _ => inferBodyI mode r fe depth e

/-- Twin of `boolTrueShortcut`. -/
def boolTrueShortcutI (r : CoreFnsI) (depth : Nat) (a : Expr) : CheckCM Bool := do
  let w ← r.whnf depth a
  pure (Expr.isBoolTrue w)

/-- Twin of `quickDefEq`. -/
def quickDefEqI (r : CoreFnsI) (depth : Nat) (a b : Expr) :
    CheckCM (Option Bool) :=
  if a == b then pure (some true) else
  match a, b with
  | .sort u, .sort v => do
    let ok ← liftFueled "level comparison" (← isEquivLM u v)
    pure (some ok)
  | .lit l₁, .lit l₂ => pure (some (l₁ == l₂))
  | .forallE ty₁ body₁ m₁, .forallE ty₂ body₂ m₂ => do
    unless ← r.defeq depth ty₁ ty₂ do return some false
    let fv ← pure (Expr.fvar depth ty₂)
    let b₁ ← inst1M body₁ fv
    let b₂ ← inst1M body₂ fv
    unless ← r.defeq (depth + 1) b₁ b₂ do return some false
    if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
      throw (.notImplemented "sort-annotation mismatch (defeq-forall)")
    pure (some true)
  | .lam ty₁ body₁ m₁, .lam ty₂ body₂ m₂ => do
    unless ← r.defeq depth ty₁ ty₂ do return some false
    let fv ← pure (Expr.fvar depth ty₂)
    let b₁ ← inst1M body₁ fv
    let b₂ ← inst1M body₂ fv
    unless ← r.defeq (depth + 1) b₁ b₂ do return some false
    if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
      throw (.notImplemented "sort-annotation mismatch (defeq-lam)")
    pure (some true)
  | _, _ => pure none

/-- Twin of `defeqOffset`. -/
def defeqOffsetI (r : CoreFnsI) (depth : Nat) (a b : Expr) :
    CheckCM (Option Bool) :=
  if a.isNatZero && b.isNatZero then pure (some true) else
  if a.isLit && b.isLit then pure none else
  match a.natPred?, b.natPred? with
  | some x, some y => do
    let ok ← r.defeq depth x y
    pure (some ok)
  | _, _ => pure none

/-- Twin of `tryUnfoldProjApp`. -/
def tryUnfoldProjAppI (r : CoreFnsI) (depth : Nat) (e : Expr) :
    CheckCM (Option Expr) :=
  if Expr.headIsProj e then do
    let e' ← r.whnfCore false depth e
    if e' == e then pure none else pure (some e')
  else pure none

/-- Twin of `deltaQuick`. -/
def deltaQuickI (r : CoreFnsI) (depth : Nat) (a b : Expr) : CheckCM DeltaStep := do
  match ← quickDefEqI mode r depth a b with
  | some true => pure .eq
  | some false => pure .diff
  | none => pure (.cont a b)

/-- Twin of `lazyDeltaStep`. -/
def lazyDeltaStepI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM DeltaStep := do
  match ← pure (unfoldableHeadC fe a), ← pure (unfoldableHeadC fe b) with
  | false, false => pure .unknown
  | true, false =>
    match ← tryUnfoldProjAppI r depth b with
    | some b₂ => deltaQuickI mode r depth a b₂
    | none =>
      match ← unfoldDefinitionI fe a with
      | some a₂ => do
        let a₃ ← r.whnfCore true depth a₂
        deltaQuickI mode r depth a₃ b
      | none => pure .unknown
  | false, true =>
    match ← tryUnfoldProjAppI r depth a with
    | some a₂ => deltaQuickI mode r depth a₂ b
    | none =>
      match ← unfoldDefinitionI fe b with
      | some b₂ => do
        let b₃ ← r.whnfCore true depth b₂
        deltaQuickI mode r depth a b₃
      | none => pure .unknown
  | true, true => do
    let ha ← pure (headHintC fe a)
    let hb ← pure (headHintC fe b)
    if ReducibilityHint.lt hb ha then
      match ← unfoldDefinitionI fe a with
      | some a₂ => do
        let a₃ ← r.whnfCore true depth a₂
        deltaQuickI mode r depth a₃ b
      | none => pure .unknown
    else if ReducibilityHint.lt ha hb then
      match ← unfoldDefinitionI fe b with
      | some b₂ => do
        let b₃ ← r.whnfCore true depth b₂
        deltaQuickI mode r depth a b₃
      | none => pure .unknown
    else if ← (if ReducibilityHint.sameRegular ha hb &&
        (← pure (sameConstHeadsC a b)) then
        defeqSpineI r fe depth a b else pure false) then pure .eq
    else
      match ← unfoldDefinitionI fe a, ← unfoldDefinitionI fe b with
      | some a₂, some b₂ => do
        let a₃ ← r.whnfCore true depth a₂
        let b₃ ← r.whnfCore true depth b₂
        deltaQuickI mode r depth a₃ b₃
      | _, _ => pure .unknown

/-- Twin of `lazyDeltaReduction`. -/
def lazyDeltaReductionI (r : CoreFnsI) (fe : FEnv) (depth : Nat) :
    Nat → Expr → Expr → CheckCM LazyRes
  | 0, _, _ => throw (.internal "fuel exhausted: defeq loop")
  | n + 1, a, b => do
    match ← defeqOffsetI r depth a b with
    | some v => pure (.verdict v)
    | none =>
    let fold ← pure (!Expr.hasFvar a && !Expr.hasFvar b)
    match ← (if fold then reduceNatI r fe depth a else pure none) with
    | some a₂ => do
      let v ← r.defeq depth a₂ b
      pure (.verdict v)
    | none =>
    match ← (if fold then reduceNatI r fe depth b else pure none) with
    | some b₂ => do
      let v ← r.defeq depth a b₂
      pure (.verdict v)
    | none =>
    match ← lazyDeltaStepI mode r fe depth a b with
    | .cont a' b' => lazyDeltaReductionI r fe depth n a' b'
    | .eq => pure (.verdict true)
    | .diff => pure (.verdict false)
    | .unknown => pure (.unknown a b)

/-- Twin of `lazyDeltaProjReduction`. -/
def lazyDeltaProjReductionI (r : CoreFnsI) (fe : FEnv) (depth : Nat)
    (sn : Name) (i : Nat) : Nat → Expr → Expr → CheckCM Bool
  | 0, _, _ => throw (.internal "fuel exhausted: lazy delta projection loop")
  | n + 1, a, b => do
    match ← lazyDeltaStepI mode r fe depth a b with
    | .cont a' b' => lazyDeltaProjReductionI r fe depth sn i n a' b'
    | .eq => pure true
    | .diff | .unknown =>
      match ← reduceProjCoreI mode r fe depth sn i a with
      | some x =>
        match ← reduceProjCoreI mode r fe depth sn i b with
        | some y => r.defeq depth x y
        | none => r.defeq depth a b
      | none => r.defeq depth a b

/-- Twin of `defeqProjPair`. -/
def defeqProjPairI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool :=
  match a, b with
  | .proj s₁ i₁ e₁, .proj s₂ i₂ e₂ =>
    if s₁ == s₂ && i₁ == i₂ then
      lazyDeltaProjReductionI mode r fe depth s₁ i₁ defeqLoopFuel e₁ e₂
    else pure false
  | _, _ => pure false

/-- Twin of `defeqStuck`. -/
def defeqStuckI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (a b : Expr) :
    CheckCM Bool :=
  match a, b with
  | .lit l, .app fO _x => do
    match l, fO with
    | .strVal s, .const cO usO =>
      if (← pure (cO == stringOfListName)) ∧ usO = [] ∧ strLitSupportedF fe then do
        let sc ← pure (strLitToConstructor s)
        r.defeq depth sc b
      else stuckIrrelI mode r fe depth a b
    | _, _ => stuckIrrelI mode r fe depth a b
  | .app fO _x, .lit l => do
    match l, fO with
    | .strVal s, .const cO usO =>
      if (← pure (cO == stringOfListName)) ∧ usO = [] ∧ strLitSupportedF fe then do
        let sc ← pure (strLitToConstructor s)
        r.defeq depth a sc
      else stuckIrrelI mode r fe depth a b
    | _, _ => stuckIrrelI mode r fe depth a b
  | .fvar i _, .fvar j _ =>
    if i == j then pure true
    else stuckIrrelI mode r fe depth a b
  | .const n us, .const n' us' =>
    if n = n' then do
      if ← liftFueled "level comparison" (← isEquivListLM us us') then
        pure true
      else stuckIrrelI mode r fe depth a b
    else stuckIrrelI mode r fe depth a b
  | .app _f₁ _a₁, .app _f₂ _a₂ => do
    -- spine-wise congruence, as in the spec (official `is_def_eq_app`)
    let as₁ ← pure (Expr.getAppArgsC a)
    let as₂ ← pure (Expr.getAppArgsC b)
    if as₁.length = as₂.length then do
      let h₁ ← pure (Expr.getAppFn a)
      let h₂ ← pure (Expr.getAppFn b)
      if ← r.defeq depth h₁ h₂ then do
        if ← defEqListI r fe depth as₁ as₂ then pure true
        else stuckIrrelI mode r fe depth a b
      else stuckIrrelI mode r fe depth a b
    else stuckIrrelI mode r fe depth a b
  | .lam ty₁ body₁ m₁, _ => do
    if ← etaCertI mode r fe depth ty₁ body₁ m₁ b then pure true
    else stuckIrrelI mode r fe depth a b
  | _, .lam ty₂ body₂ m₂ => do
    if ← etaCertI mode r fe depth ty₂ body₂ m₂ a then pure true
    else stuckIrrelI mode r fe depth a b
  | _, _ => stuckIrrelI mode r fe depth a b

/-- Twin of `defeqBody`. -/
def defeqBodyI (r : CoreFnsI) (fe : FEnv) : Nat → Expr → Expr → CheckCM Bool :=
  fun depth a b => do
    if a == b then pure true else
    -- the eq-true shortcut (E2), as in the spec
    let bt ← pure (Expr.isBoolTrue b)
    let af ← pure (Expr.hasFvar a)
    if ← (if bt && !af then boolTrueShortcutI r depth a
        else pure false) then pure true else
    let a' ← r.whnfCore true depth a
    let b' ← r.whnfCore true depth b
    match ← quickDefEqI mode r depth a' b' with
    | some v => pure v
    | none =>
    if ← propIrrelI r fe depth a' b' then pure true else
    match ← lazyDeltaReductionI mode r fe depth defeqLoopFuel a' b' with
    | .verdict v => pure v
    | .unknown a₁ b₁ =>
    if ← defeqProjPairI mode r fe depth a₁ b₁ then pure true else
    if !(Expr.headIsProj a₁) && !(Expr.headIsProj b₁) then
      defeqStuckI mode r fe depth a₁ b₁ else
    let a₂ ← r.whnfCore false depth a₁
    let b₂ ← r.whnfCore false depth b₁
    if a₂ == a₁ && b₂ == b₁ then defeqStuckI mode r fe depth a₁ b₁
    else r.defeq depth a₂ b₂

/-! ### Annotation binder-telescope loops (task #72; see the
`inferLamsI` block comment) -/

/-- Stack entry of the annotation loops: binder name, annotated opened
domain, binder info. -/
abbrev AnnotBinderEntry := Expr × BinderMeta

/-- The cached twin of `annotBinderMeta`. -/
def annotBinderMetaI (pw? : Option PropWhen) (mb : BinderMeta) : BinderMeta :=
  match pw? with
  | some pw => if pwWritten mb.pw then mb else ⟨pw⟩
  | none => mb

/-- Rebuild loop of the annotation binder-telescope loops: fold the
stack (innermost binder first, `j` its binder level), rebuilding one
binder node per entry.

Task #161 P5 — the untrusted write: `pw?` is the datum written just
below, threaded outward (`zeronessOf (imax u v) = zeronessOf v` makes
every ∀ node's codomain-sort zero-ness its inner neighbour's, and the
λ chain rule says the same of λ nodes — so the telescope pays one
computation, in the leaf phase, and every node above reads).  `none` =
no write (unverified mode).  A node whose input datum is a real
annotation (`pwWritten`) is left alone — validation judges it, and it
is that datum that travels on. -/
def annotateBindersOutI (mk : Expr → Expr → BinderMeta → Expr)
    (d : Nat) (pw? : Option PropWhen) :
    List AnnotBinderEntry → Nat → Expr → CheckCM Expr
  | [], _j, cur => pure cur
  | (ty', mb) :: rest, j, cur => do
    let tyAbs ← abstractRangeM ty' d j
    let node ← pure (mk tyAbs cur (annotBinderMetaI pw? mb))
    -- Task #161 P5 (proof-lane repair): thread the datum *just
    -- written* outward rather than re-stamping the leaf's.  The two
    -- differ only above an explicitly-annotated binder, and there the
    -- chain rule is what the spec's `annotPwPi`/`annotPwLam` read —
    -- they see the rebuilt inner node, not the leaf.  One fold, one
    -- rule, both passes.
    annotateBindersOutI mk d
      (pw?.map fun _ => (annotBinderMetaI pw? mb).pw)
      rest (j - 1) node

/-- The ∀ telescope's datum (task #161 P5), computed once: the leaf
codomain sort's zero-ness — shared by every node of the telescope
because `zeronessOf (imax u v) = zeronessOf v`.  A ∀ residual (the
fuel path) supplies its own already-written datum instead, exactly as `annotPwPi` reads it. -/
def annotPwPiI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (body' : Expr) :
    CheckCM PropWhen := do
  -- task #168 stage 2: the head-symbol reader first (it subsumes the
  -- chain read), as in the spec
  match typeSortPW fe.find? body' with
  | some pw => pure pw
  | none => do
    let bt ← r.inferIO depth body'
    let v ← ensureSortI r depth bt
    pure (Level.zeronessOf v)

/-- The telescope loop's write.  UNGATED since 2026-09-06: writing the
datum is part of the real checker's algorithm (the readers and the
licences consume it); only *validating* it is certification-only work,
so the trusted mode annotates exactly as the verified mode does.  The
`Option` shape is kept — `annotBinderMetaI` still leaves an
already-written annotation alone. -/
def annotatePisPwI (r : CoreFnsI) (fe : FEnv) (d k : Nat) (leaf' : Expr) :
    CheckCM (Option PropWhen) := do
  let p ← annotPwPiI r fe (d + k) leaf'
  pure (some p)

/-- Leaf phase of `annotatePisI`: bulk-open and annotate the residual
body, then rebuild outward. -/
def annotatePisLeafI (r : CoreFnsI) (fe : FEnv) (d : Nat) (t : Expr) (k : Nat)
    (fvs : Array Expr) (stk : List AnnotBinderEntry) : CheckCM Expr := do
  let to ← instListRevM t fvs
  let leaf' ← r.annotate (d + k) to
  let pw? ← annotatePisPwI r fe d k leaf'
  let cur ← abstractRangeM leaf' d k
  annotateBindersOutI (fun ty b mb => .forallE ty b mb) d pw?
    stk (k - 1) cur

/-- ∀-telescope annotation loop (task #72; `annotateBodyI`'s forallE
case): peel the raw ∀-chain, annotating each opened domain on the way
in.  `k ≥ 1` counts the opened binders (first binder peeled inline by
the caller), `fvs` their free variables innermost-first. -/
def annotatePisI (r : CoreFnsI) (fe : FEnv) (d : Nat) :
    Nat → Expr → Nat → Array Expr → List AnnotBinderEntry → CheckCM Expr
  | fuel + 1, t, k, fvs, stk => do
    match t with
    | .forallE ty body mb => do
      let tyo ← instListRevM ty fvs
      let ty' ← r.annotate (d + k) tyo
      let fv ← pure (Expr.fvar (d + k) ty')
      annotatePisI r fe d fuel body (k + 1) (fvs.push fv)
        ((ty', mb) :: stk)
    | _ => annotatePisLeafI r fe d t k fvs stk
  | 0, t, k, fvs, stk => annotatePisLeafI r fe d t k fvs stk

/-- The λ chain's datum (task #161 P5): the zero-ness of the sort of
the innermost body's TYPE; every λ node of the chain shares it (the
`(lam-cod-chain)` rule).  A λ residual supplies its own already-written
datum, exactly as `inferLamsLeafI` reads it. -/
def annotPwLamI (r : CoreFnsI) (fe : FEnv) (depth : Nat) (body' : Expr) :
    CheckCM PropWhen := do
  -- task #168 stage 2: the reader first, as in the spec
  match proofPW fe.find? body' with
  | some pw => pure pw
  | none => do
    let bt ← r.inferIO depth body'
    let btt ← r.inferIO depth bt
    let vb ← ensureSortI r depth btt
    pure (Level.zeronessOf vb)

/-- The λ twin of `annotatePisPwI`, ungated with it. -/
def annotateLamsPwI (r : CoreFnsI) (fe : FEnv) (d k : Nat) (leaf' : Expr) :
    CheckCM (Option PropWhen) := do
  let p ← annotPwLamI r fe (d + k) leaf'
  pure (some p)

/-- Leaf phase of `annotateLamsI` (as `annotatePisLeafI`, rebuilding
λ-nodes). -/
def annotateLamsLeafI (r : CoreFnsI) (fe : FEnv) (d : Nat) (t : Expr) (k : Nat)
    (fvs : Array Expr) (stk : List AnnotBinderEntry) : CheckCM Expr := do
  let to ← instListRevM t fvs
  let leaf' ← r.annotate (d + k) to
  let pw? ← annotateLamsPwI r fe d k leaf'
  let cur ← abstractRangeM leaf' d k
  annotateBindersOutI (fun ty b mb => .lam ty b mb) d pw?
    stk (k - 1) cur

/-- λ-telescope annotation loop (task #72; `annotateBodyI`'s lam
case). -/
def annotateLamsI (r : CoreFnsI) (fe : FEnv) (d : Nat) :
    Nat → Expr → Nat → Array Expr → List AnnotBinderEntry → CheckCM Expr
  | fuel + 1, t, k, fvs, stk => do
    match t with
    | .lam ty body mb => do
      let tyo ← instListRevM ty fvs
      let ty' ← r.annotate (d + k) tyo
      let fv ← pure (Expr.fvar (d + k) ty')
      annotateLamsI r fe d fuel body (k + 1) (fvs.push fv)
        ((ty', mb) :: stk)
    | _ => annotateLamsLeafI r fe d t k fvs stk
  | 0, t, k, fvs, stk => annotateLamsLeafI r fe d t k fvs stk

/-- Twin of `annotateBody`. -/
def annotateBodyI (r : CoreFnsI) (fe : FEnv) : Nat → Expr → CheckCM Expr :=
  fun depth e => do
    match e with
    | .bvar _ => pure e
    | .fvar idx _ =>
      if idx < depth then pure e
      else throw (.invalid "free variable out of scope")
    | .sort _ => pure e
    | .const .. => pure e
    | .lit (.natVal _) => do
      if natLitSupportedF fe then pure e
      else throw (.invalid "Nat literal without the Nat basis declarations")
    | .lit (.strVal _) => do
      if strLitSupportedF fe then pure e
      else throw (.notImplemented
        "string literals before the String support declarations")
    | .app f a => do
      -- structural (task #100 stage 6: the application checks moved to
      -- the driver's inference sweep)
      let f' ← r.annotate depth f
      let a' ← r.annotate depth a
      pure (Expr.app f' a')
    | .forallE ty body mb => do
      -- Binder-telescope loop (task #72): peel the whole ∀-chain,
      -- open in bulk, rebuild with `abstractRange`.
      let ty' ← r.annotate depth ty
      let fv ← pure (Expr.fvar depth ty')
      let fuel ← peelFuelM
      annotatePisI r fe depth fuel body 1 #[fv] [(ty', mb)]
    | .lam ty body mb => do
      -- The λ-loop is chain-identical only on bvar-closed nodes (the
      -- chained tails re-open exactly what they closed); disciplined
      -- inputs always are, and the cached bound decides in O(1).
      if (← bvarBoundM e) = 0 then do
        let ty' ← r.annotate depth ty
        let fv ← pure (Expr.fvar depth ty')
        let fuel ← peelFuelM
        annotateLamsI r fe depth fuel body 1 #[fv] [(ty', mb)]
      else do
        let ty' ← r.annotate depth ty
        let fv ← pure (Expr.fvar depth ty')
        let ob ← inst1M body fv
        let body' ← r.annotate (depth + 1) ob
        let bAbs ← abstract1M body' depth
        -- task #161 P5: the single-binder write (the λ-loop's rule at
        -- a chain of length one; see `annotateLamsLeafI`)
        let pw ← if !pwWritten mb.pw then
            annotPwLamI r fe (depth + 1) body'
          else pure mb.pw
        pure (Expr.lam ty' bAbs ⟨pw⟩)
    | .letE ty v b => do
      -- official `infer_let` check order (see the spec body): the
      -- annotation is a type, the value's inferred type matches it,
      -- then the body with the value transparent (zeta at annotate;
      -- `inst1M` keeps the substitution sharing-preserving).  Task #217
      -- (audit follow-up #206-S1) put the triple back: the pass returns
      -- the ζ reduct, so `inferBodyI`'s `.letE` arm never sees the node
      -- — task #241 made that arm a positive `.internal` error.
      let ty' ← r.annotate depth ty
      let tty ← r.infer depth ty'
      let _ ← ensureSortI r depth tty
      let v' ← r.annotate depth v
      let tv ← r.infer depth v'
      unless ← r.defeq depth tv ty' do
        throw (.invalid "let value type mismatch")
      let ob ← inst1M b v
      r.annotate depth ob
    | .proj sn i pe => do
      let e' ← r.annotate depth pe
      let tpe ← r.inferIO depth e'
      let te ← r.whnf depth tpe
      match Expr.getAppFn te with
      | .const T _ => do
        let Tn ← pure T
        match fe.findProj? Tn i with
        | some entry => do
          let targs ← pure (Expr.getAppArgsC te)
          -- TASK #271 (issue #7), as in the pure twin
          unless T = sn do
            throw (.invalid "invalid projection: the node names another structure")
          unless targs.length = entry.numParams do
            throw (.invalid "projection parameter mismatch")
          pure (Expr.proj T i e')
        | none =>
          -- official's `infer_proj` verdict, as in the pure twin
          throw (projMissError fe.find? (fe.find? (projTableName Tn)).isSome Tn sn i
            (Expr.getAppArgsC te).length)
      | _ => throw (.invalid "invalid projection: not a structure-like type, or no such field")

/-! ## The memoized knot -/

/-- Memoize a unary entry point under its node (`O(1)` key).

`@[inline]` (the retired twin's perf-eng E2, now the one knot's): after
inlining the getter/setter lambdas beta-reduce away and the memo probe
compiles into the record field's own closure.  A compiler attribute
only — the term the proofs unfold is unchanged. -/
@[inline] def memoEI (get' : CState → Std.HashMap Expr Expr)
    (set' : CState → Std.HashMap Expr Expr → CState)
    (f : Nat → Expr → CheckCM Expr) : Nat → Expr → CheckCM Expr :=
  fun d e => do
    match (get' (← get))[e]? with
    | some r => pure r
    | none =>
      let r ← f d e
      modify fun st =>
          let mp := get' st
        let st := set' st ∅
        set' st (mp.insert e r)
      pure r

/-- Memoize the definitional-equality entry point under the
index pair (`@[inline]` as `memoEI`). -/
@[inline] def memoBI (f : Nat → Expr → Expr → CheckCM Bool) :
    Nat → Expr → Expr → CheckCM Bool :=
  fun d a b => do
    match (← get).defeqC[(a, b)]? with
    | some r => pure r
    | none =>
      let r ← f d a b
      modify fun st =>
        let mp := st.defeqC
        let st := { st with defeqC := ∅ }
        { st with defeqC := mp.insert (a, b) r }
      pure r

/-- Tie the bodies at the memoizing state monad (fuel only
here, as in `coreKnot`; levels built lazily).

**The knot takes the mode** (task #185; from 2026-09-06 to then it
took a configuration record standing in for it).  `coreKnotI .verified`
is the verified core the capstones are stated about, and
`coreKnotI .trusted` is the trusted core `--trusted` runs — the same
function at the other mode.  The mode-parametric simulation tower
(`ConLeche/Verify/Cached/*`) is stated at `coreKnotI mode` under
`hμ : mode.verifiedChecks = true`. -/
def coreKnotI (fe : FEnv) : Nat → CoreFnsI
  | 0 =>
    { whnfCore := fun _ _ _ => throw (.internal "fuel exhausted: whnfCore")
      whnf := fun _ _ => throw (.internal "fuel exhausted: whnf")
      infer := fun _ _ => throw (.internal "fuel exhausted: infer")
      defeq := fun _ _ _ => throw (.internal "fuel exhausted: defeq")
      annotate := fun _ _ => throw (.internal "fuel exhausted: annotate")
      inferIO := fun _ _ => throw (.internal "fuel exhausted: infer") }
  | fuel + 1 =>
    -- **NOT a `Thunk`** (task #179).  The previous fuel level used to be
    -- `Thunk`-cached (perf-eng E1: built once per record rather than once
    -- per cache-missing call), and that single word cost 13.8 % of
    -- `init-full`.  `lean_thunk_get_core` calls `mark_mt` on the forced
    -- **value** — the runtime's invariant is that a single-threaded object
    -- may not be reachable from a multi-threaded one, and a thunk may be
    -- forced from another thread — so forcing this thunk marked the whole
    -- reachable graph of its value multi-threaded, and the value's six
    -- closures capture `fe`.  Two consequences, both `O(|env|)` per
    -- *declaration*: (i) the mark itself walks the index's whole bucket
    -- array, and (ii) an MT object is never `lean_is_exclusive`, so
    -- `FEnv.push`'s `idx.insert` stopped updating in place and copied the
    -- bucket array (with an atomic `lean_inc` per slot) at every accepted
    -- constant — the two symbols task #177 left unattributed,
    -- `lean_mark_mt` (7.6 %) and `lean_copy_expand_array` (6.2 %).  The
    -- copy re-created the array as single-threaded, the next force marked
    -- it again, and the loop sustained itself.  A plain `Unit`-closure
    -- forces nothing and marks nothing; it pays E1 back (one record per
    -- cache-missing call) and that is the smaller number by 5×.
    -- `Thunk.get ⟨f⟩` is `f ()` by structure eta, so this is the same
    -- term: no proof in `ConLeche/Verify/Cached/*` moved.
    let prev : Unit → CoreFnsI := fun _ => coreKnotI fe fuel
    -- task #172 B2 / #185: the template's parameter is the mode, an
    -- enum passed down once per *driver* — nothing is built per knot
    -- level or per call (at B2 a record allocation at every
    -- head-normalization entry cost +0.155 % on `init-prelude`).
    -- The two modes of `whnfCore` (official `cheap_proj`) under two
    -- memos: their results differ on a stuck projection.
    { whnfCore := fun c => if c then
          memoEI (·.whnfCoreCheapC)
            (fun st mp => { st with whnfCoreCheapC := mp })
            (fun d e => whnfCoreBodyI mode (prev ()) fe true d e)
        else memoEI (·.whnfCoreC)
          (fun st mp => { st with whnfCoreC := mp })
          (fun d e => whnfCoreBodyI mode (prev ()) fe false d e)
      whnf := memoEI (·.whnfC) (fun st mp => { st with whnfC := mp })
        (fun d e => whnfBodyI (prev ()) fe d e)
      infer := memoEI (·.inferC) (fun st mp => { st with inferC := mp })
        (fun d e => inferBodyI mode (prev ()) fe d e)
      defeq := memoBI
        (fun d a b => defeqBodyI mode (prev ()) fe d a b)
      annotate := memoEI (·.annotC) (fun st mp => { st with annotC := mp })
        (fun d e => annotateBodyI (prev ()) fe d e)
      -- **The io slot** (task #170 / #172 B4), selected once per knot
      -- level: at `ioGate` the io body under its OWN memo
      -- (`CState.inferIOC` — the task-#170 memo ruling: a hit in the io
      -- memo never serves a full-infer query), tied to the io-grade
      -- view of the previous level (the grade propagates); at
      -- `ioGate = false` — no mode any more — the full inference
      -- closure, verbatim, under one memo, because the two grades are
      -- the same function there (task #170: "in R mode infer_only is
      -- just equivalent to infer").
      inferIO := if mode.ioGate then
          memoEI (·.inferIOC) (fun st mp => { st with inferIOC := mp })
            (fun d e => inferBodyIOI mode (prev ()).ioView fe d e)
        else
          memoEI (·.inferC) (fun st mp => { st with inferC := mp })
            (fun d e => inferBodyI mode (prev ()) fe d e) }

end ConLeche.Cached

end -- original EOF public section of ConLeche.Cached.CoreC
/- END full source origin ConLeche.Cached.CoreC -/

/- BEGIN project source origin CachedForwardRuns -/
-- Cached bundle original import: import ConLeche.Cached.CoreC

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Successful runs of the actual cached primitives

Source candidate only: not compiled or accepted.  The imported executable
definitions are the original con-leche sources at commit
67f04630d88718e81aa4d07ab64501f68f105398.  This module supplies operational
success, independently of the successful-run simulation tower.  No checker
driver, state representation, cache key, or initial state is replaced.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedForward

open ConLeche
open ConLeche.Cached

/-- A successful run from the state actually supplied by the caller. -/
def Succeeds {α : Type} (action : CheckCM α) (state : CState) : Prop :=
  ∃ value state', action state = .ok (value, state')

theorem succeeds_pure {α : Type} (value : α) (state : CState) :
    Succeeds (pure value) state := by
  exact ⟨value, state, rfl⟩

theorem succeeds_modifyGet {α : Type} (step : CState → α × CState)
    (state : CState) : Succeeds (modifyGet step) state := by
  exact ⟨(step state).1, (step state).2, rfl⟩

theorem succeeds_modify (step : CState → CState) (state : CState) :
    Succeeds (modify step) state := by
  exact ⟨(), step state, rfl⟩

/-- Compose actual successful runs.  The continuation receives their actual
intermediate state and the equation identifying how it was reached. -/
theorem succeeds_bind {α β : Type} {action : CheckCM α}
    {next : α → CheckCM β} {state : CState}
    (first : Succeeds action state)
    (rest : ∀ value state', action state = .ok (value, state') →
      Succeeds (next value) state') :
    Succeeds (action >>= next) state := by
  obtain ⟨value, state', firstRun⟩ := first
  obtain ⟨result, final, nextRun⟩ := rest value state' firstRun
  refine ⟨result, final, ?_⟩
  simp only [Bind.bind, StateT.bind, firstRun, Except.bind, nextRun]

/-- A hit reads the supplied memo and leaves every state component unchanged. -/
theorem memoEI_hit
    (getCache : CState → Std.HashMap Expr Expr)
    (setCache : CState → Std.HashMap Expr Expr → CState)
    (body : Nat → Expr → CheckCM Expr)
    (depth : Nat) (query value : Expr) (state : CState)
    (hit : (getCache state)[query]? = some value) :
    memoEI getCache setCache body depth query state = .ok (value, state) := by
  simp only [memoEI, Bind.bind, StateT.bind, get, getThe,
    MonadStateOf.get, StateT.get, hit, pure, StateT.pure, Except.pure,
    Except.bind]

/-- The miss equation retains the original detach/insert/update sequence.
No compatibility laws for an arbitrary setter are silently assumed. -/
theorem memoEI_miss
    (getCache : CState → Std.HashMap Expr Expr)
    (setCache : CState → Std.HashMap Expr Expr → CState)
    (body : Nat → Expr → CheckCM Expr)
    (depth : Nat) (query value : Expr) (state final : CState)
    (miss : (getCache state)[query]? = none)
    (run : body depth query state = .ok (value, final)) :
    memoEI getCache setCache body depth query state =
      .ok (value, setCache (setCache final ∅)
        ((getCache final).insert query value)) := by
  simp only [memoEI, Bind.bind, StateT.bind, get, getThe,
    MonadStateOf.get, StateT.get, miss, pure, StateT.pure, Except.pure,
    Except.bind, run, modify, modifyGet, MonadStateOf.modifyGet,
    StateT.modifyGet]

/-- Positive fuel is needed before the original knot consults its cache. -/
theorem whnf_hit (mode : CheckMode) (fe : FEnv) (fuel depth : Nat)
    (query value : Expr) (state : CState)
    (hit : state.whnfC[query]? = some value) :
    (coreKnotI mode fe (fuel + 1)).whnf depth query state =
      .ok (value, state) := by
  change memoEI (·.whnfC) (fun s cache => { s with whnfC := cache })
    (fun d e => whnfBodyI (coreKnotI mode fe fuel) fe d e)
    depth query state = .ok (value, state)
  exact memoEI_hit _ _ _ depth query value state hit

/-- An actual successful body run is sufficient for the original miss arm. -/
theorem whnf_miss (mode : CheckMode) (fe : FEnv) (fuel depth : Nat)
    (query value : Expr) (state final : CState)
    (miss : state.whnfC[query]? = none)
    (run : whnfBodyI (coreKnotI mode fe fuel) fe depth query state =
      .ok (value, final)) :
    (coreKnotI mode fe (fuel + 1)).whnf depth query state =
      .ok (value, { final with whnfC := final.whnfC.insert query value }) := by
  change memoEI (·.whnfC) (fun s cache => { s with whnfC := cache })
    (fun d e => whnfBodyI (coreKnotI mode fe fuel) fe d e)
    depth query state = _
  exact memoEI_miss _ _ _ depth query value state final miss run

theorem whnf_zero (mode : CheckMode) (fe : FEnv) (depth : Nat)
    (query : Expr) (state : CState) :
    (coreKnotI mode fe 0).whnf depth query state =
      .error (.internal "fuel exhausted: whnf") := rfl

theorem whnfCore_hit (mode : CheckMode) (fe : FEnv) (fuel depth : Nat)
    (query value : Expr) (state : CState)
    (hit : state.whnfCoreC[query]? = some value) :
    (coreKnotI mode fe (fuel + 1)).whnfCore false depth query state =
      .ok (value, state) := by
  change memoEI (·.whnfCoreC)
    (fun s cache => { s with whnfCoreC := cache })
    (fun d e => whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false d e)
    depth query state = .ok (value, state)
  exact memoEI_hit _ _ _ depth query value state hit

theorem whnfCore_miss (mode : CheckMode) (fe : FEnv) (fuel depth : Nat)
    (query value : Expr) (state final : CState)
    (miss : state.whnfCoreC[query]? = none)
    (run : whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query state =
      .ok (value, final)) :
    (coreKnotI mode fe (fuel + 1)).whnfCore false depth query state =
      .ok (value, { final with whnfCoreC := final.whnfCoreC.insert query value }) := by
  change memoEI (·.whnfCoreC)
    (fun s cache => { s with whnfCoreC := cache })
    (fun d e => whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false d e)
    depth query state = _
  exact memoEI_miss _ _ _ depth query value state final miss run

theorem instListM_succeeds (expression : Expr) (values : List Expr)
    (depth : Nat) (state : CState) :
    Succeeds (instListM expression values depth) state := by
  unfold instListM
  exact succeeds_modifyGet _ state

theorem instLevelParamsM_succeeds (names : List Name) (levels : List Level)
    (expression : Expr) (state : CState) :
    Succeeds (instLevelParamsM names levels expression) state := by
  exact succeeds_pure _ state

theorem storedTyIdxM_succeeds (name : Name) (expression : Expr)
    (state : CState) : Succeeds (storedTyIdxM name expression) state := by
  unfold storedTyIdxM
  refine succeeds_bind (succeeds_modifyGet _ state) ?_
  intro entry nextState _
  cases entry with
  | none => exact succeeds_pure _ nextState
  | some entry =>
    change Succeeds
      (if entry.tyE.exprPtrBEq expression then pure entry.ty else pure expression) nextState
    split <;> exact succeeds_pure _ nextState

theorem storedValIdxM_succeeds (name : Name) (expression : Expr)
    (state : CState) : Succeeds (storedValIdxM name expression) state := by
  unfold storedValIdxM
  refine succeeds_bind (succeeds_modifyGet _ state) ?_
  intro entry nextState _
  cases entry with
  | none => exact succeeds_pure _ nextState
  | some entry =>
    obtain ⟨_, _, value⟩ := entry
    cases value with
    | none => exact succeeds_pure _ nextState
    | some pair =>
      obtain ⟨valueExpression, valueValue⟩ := pair
      change Succeeds
        (if valueExpression.exprPtrBEq expression then pure valueValue else pure expression) nextState
      split <;> exact succeeds_pure _ nextState

/-- Lookup validity suffices for operational success, even before a cache
invariant is supplied.  The invariant is needed for the result specification. -/
theorem constTyAtM_succeeds (fe : FEnv) (indexName name : Name)
    (levels : List Level) (info : ConstantInfo) (state : CState)
    (found : fe.find? name = some info) :
    Succeeds (constTyAtM fe indexName name levels) state := by
  unfold constTyAtM
  refine succeeds_bind (succeeds_modifyGet _ state) ?_
  intro hit nextState _
  cases hit with
  | some value => exact succeeds_pure _ nextState
  | none =>
    rw [found]
    dsimp only
    refine succeeds_bind
      (storedTyIdxM_succeeds name info.toConstantVal.type nextState) ?_
    intro raw convertedState _
    refine succeeds_bind (instLevelParamsM_succeeds
      info.toConstantVal.levelParams levels raw convertedState) ?_
    intro result instantiatedState _
    refine succeeds_bind (succeeds_modify _ instantiatedState) ?_
    intro _ finalState _
    exact succeeds_pure result finalState

theorem constValAtM_succeeds (fe : FEnv) (indexName name : Name)
    (levels : List Level) (constant : ConstantVal) (value : Expr)
    (hint : ReducibilityHint) (state : CState)
    (found : fe.find? name = some (.defnInfo constant value hint)) :
    Succeeds (constValAtM fe indexName name levels) state := by
  unfold constValAtM
  refine succeeds_bind (succeeds_modifyGet _ state) ?_
  intro hit nextState _
  cases hit with
  | some result => exact succeeds_pure _ nextState
  | none =>
    rw [found]
    dsimp only
    refine succeeds_bind (storedValIdxM_succeeds name value nextState) ?_
    intro raw convertedState _
    refine succeeds_bind
      (instLevelParamsM_succeeds constant.levelParams levels raw convertedState) ?_
    intro result instantiatedState _
    refine succeeds_bind (succeeds_modify _ instantiatedState) ?_
    intro _ finalState _
    exact succeeds_pure result finalState

theorem ruleRhsAtM_succeeds (fe : FEnv) (recursorIndex constructorIndex : Name)
    (recursor constructor : Name) (levels : List Level)
    (constant : ConstantVal) (majorIndex parameterCount : Nat)
    (rules : List RecRule) (rule : RecRule) (state : CState)
    (found : fe.find? recursor = some
      (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) =
      some rule) :
    Succeeds (ruleRhsAtM fe recursorIndex constructorIndex
      recursor constructor levels) state := by
  unfold ruleRhsAtM
  refine succeeds_bind (succeeds_modifyGet _ state) ?_
  intro hit nextState _
  cases hit with
  | some result => exact succeeds_pure _ nextState
  | none =>
    rw [found]
    dsimp only
    rw [ruleFound]
    dsimp only
    refine succeeds_bind
      (instLevelParamsM_succeeds constant.levelParams levels rule.rhs nextState) ?_
    intro result instantiatedState _
    refine succeeds_bind (succeeds_modify _ instantiatedState) ?_
    intro _ finalState _
    exact succeeds_pure result finalState

#print axioms succeeds_pure
#print axioms succeeds_modifyGet
#print axioms succeeds_modify
#print axioms succeeds_bind
#print axioms memoEI_hit
#print axioms memoEI_miss
#print axioms whnf_hit
#print axioms whnf_miss
#print axioms whnf_zero
#print axioms whnfCore_hit
#print axioms whnfCore_miss
#print axioms instListM_succeeds
#print axioms instLevelParamsM_succeeds
#print axioms storedTyIdxM_succeeds
#print axioms storedValIdxM_succeeds
#print axioms constTyAtM_succeeds
#print axioms constValAtM_succeeds
#print axioms ruleRhsAtM_succeeds

end ADWH.Experiments.Chapter15.KernelCachedForward

/- END project source origin CachedForwardRuns -/

/- BEGIN project source origin CachedForwardLicensed -/
-- Cached bundle original import: import CachedForwardRuns

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual callback-free licensed paths

Uncompiled source candidate.  These lemmas read the actual stored metadata.
They do not certify that metadata or that a declaration is well typed.  Those
are separate annotation/installation obligations.  In particular no arbitrary
inference/defeq callback is assumed to succeed.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedForward

open ConLeche
open ConLeche.Cached

/-- A raw telescope has enough successive binders licensed `.never`.
The domains and residual body are unrestricted; no substitution is performed
on this actual cached fast path. -/
inductive NeverPiPrefix : Nat → Expr → Prop
  | zero (type : Expr) : NeverPiPrefix 0 type
  | succ {length : Nat} {domain body : Expr} (metadata : BinderMeta)
      (never : metadata.pw.isNever = true)
      (tail : NeverPiPrefix length body) :
      NeverPiPrefix (length + 1) (.forallE domain body metadata)

theorem iotaCertsIAux_never (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (type : Expr) (accumulated arguments : List Expr)
    (state : CState) (licensed : NeverPiPrefix arguments.length type) :
    iotaCertsIAux callbacks fe depth true type accumulated arguments state =
      .ok (true, state) := by
  induction arguments generalizing type accumulated with
  | nil =>
    rw [iotaCertsIAux.eq_def]
    all_goals rfl
  | cons argument rest ih =>
    cases licensed with
    | succ metadata never tail =>
      rw [iotaCertsIAux.eq_def]
      simp only [Bool.true_and, never, ↓reduceIte]
      exact ih _ _ tail

theorem iotaCertsI_never (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (type : Expr) (arguments : List Expr) (state : CState)
    (licensed : NeverPiPrefix arguments.length type) :
    iotaCertsI callbacks fe depth true type arguments state =
      .ok (true, state) := by
  exact iotaCertsIAux_never callbacks fe depth type [] arguments state licensed

theorem defEqListI_empty (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (state : CState) :
    defEqListI callbacks fe depth [] [] state = .ok (true, state) := rfl

theorem iotaIndexOkI_noIndices (callbacks : CoreFnsI) (fe : FEnv)
    (depth majorIndex constructorParameters : Nat) (type : Expr)
    (majorArguments indices : List Expr) (state : CState) :
    iotaIndexOkI callbacks fe depth majorIndex majorIndex constructorParameters
      type majorArguments indices state = .ok (true, state) := by
  simp only [iotaIndexOkI, ↓reduceIte]
  all_goals rfl

theorem whnfAppI_never (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (domain body argument : Expr)
    (rest : List Expr) :
    whnfAppI .verified callbacks fe depth next
      (.lam domain body ⟨.never⟩) (argument :: rest) =
    betaPeelI .verified callbacks fe depth next body [argument] rest := by
  rw [whnfAppI.eq_def]
  all_goals rfl

theorem betaPeelI_never (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (domain body argument : Expr)
    (accumulated rest : List Expr) :
    betaPeelI .verified callbacks fe depth next
      (.lam domain body ⟨.never⟩) accumulated (argument :: rest) =
    betaPeelI .verified callbacks fe depth next body
      (argument :: accumulated) rest := by
  rw [betaPeelI.eq_def]
  all_goals rfl

/-- Once the licensed telescope has been consumed, the real bulk substitution
and the supplied continuation still have to run.  This equation neither
removes their cost nor postulates their success. -/
theorem betaPeelI_done (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (body : Expr) (accumulated : List Expr) :
    betaPeelI mode callbacks fe depth next body accumulated [] =
      (instListM body accumulated >>= next) := by
  rw [betaPeelI.eq_def]

#print axioms iotaCertsIAux_never
#print axioms iotaCertsI_never
#print axioms defEqListI_empty
#print axioms iotaIndexOkI_noIndices
#print axioms whnfAppI_never
#print axioms betaPeelI_never
#print axioms betaPeelI_done

end ADWH.Experiments.Chapter15.KernelCachedForward

/- END project source origin CachedForwardLicensed -/

