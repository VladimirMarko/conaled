# Thirty-two direct Boolean certificate proofs

Status: separate source-only cost candidate, pending independent review and a
fresh complete selected gate. No compiler, gate, preflight, evaluator, exporter,
profiler, retained generator or saved-result reader has been executed by the
author. Existing sources, reviews, accepted results and consumed attempts are
unchanged. This package is not selected in the consumed Wrapper136 gate.

## Exact change

The selected evaluator owner still contains the original proof-carrying Boolean
walks `Expr.wscopedBXP` and `Expr.leavesSubXP`. Each returns an actual Boolean,
its equality to the corresponding plain descent, and its actual returned memo.
Sixteen equality certificates in each walk used broad simplification after
unfolding the plain descent. This candidate replaces exactly those thirty-two
proof fields with one-step `.eq_def` rewriting, the existing false-cutoff fact,
an explicit constructor goal and the supplied branch/child equalities.

| Constructor branch per walk | Certificates | Facts used |
| --- | ---: | --- |
| bvar, sort, constant, literal | 4 | One descent equation and its cutoff |
| fvar accepted or rejected | 2 | Actual comparison/membership guard; child proof only in the accepted branch |
| application, lambda, forall | 6 | First-child Boolean and, only when it is true, the next child's certificate |
| let body, false value, false type | 3 | Actual left-to-right short-circuit certificates |
| projection | 1 | Actual child certificate |

For example, the successful application proof reduces to equality with
`(wscopedBP f d && wscopedBP a d)`. The two child facts rewrite that Boolean to
`true && ra`, which reduces to `ra`. The false-first-child proof reduces to
`false && ...`, without inventing a proof about the unvisited child. Let proofs
preserve the left-associated conjunction and the original type/value/body order.
The scoping fvar branch retains the child's own index as its cursor; binder
bodies keep the original free-variable cursor. No de Bruijn-cursor replacement
is made.

The positive/negative Nat comparison uses the pinned standard
`decide_eq_true`/`decide_eq_false` lemmas. The negative Boolean membership branch
uses the current `Bool.eq_false_of_ne_true` lemma. No deprecated alias, general
simplifier invocation, `omega`, `decide` tactic, new theorem, axiom or import is
introduced. The twenty-five existing project report commands remain identical;
this is not a claim that the entire inherited owner has only twenty-five theorem
declarations.

## Computational and representation correspondence

The physical candidate starts from the exact 207,542-byte evaluator Cached owner
after the existing omission and leading-comment repairs. It has thirty-two proof
edits and one ordinary scope comment. Every returned value, constructor, recursive
call, borrowed argument, cutoff, pointer/exclusivity test, memo key, memo read,
memo write, short-circuit branch and state field remains byte-identical outside
the recorded equality-proof spans. All six cached callback families and their
knot remain literal. Every existing theorem statement, report command, import and
source option is retained. Core is unchanged, including `instantiateList_cons`.

The companion `source/ConLeche/Cached/ExprOpsC.lean` starts from the full native
ExprOpsC source after the independently reviewed earlier forty-proof layer. It
receives the same thirty-two proof substitutions, with no documentation prefix,
declaration removal, module/import/visibility edit or API change. Both complete
original walk blocks and both candidate walk blocks are byte-identical across
the physical and native representations. The native companion is provenance for
future integration, not a second compiled owner in a current gate.

The physical owner retains its already disclosed evaluator/driver omissions.
This candidate does not restore original installation guards or `recordCConst`,
and does not claim whole-native compilation or identical generated private names
or machine code. The full native companion preserves the complete source API of
its exact predecessor. The earlier full-origin header/explicit-universe map,
forty-proof overlay, physical omission map and leading-comment repair remain
separate inputs. No missing declaration is hidden by this proof-only change.

Each modified field is a proof of the same Boolean equality proposition. Proof
irrelevance explains why substituting a checked proof at that field preserves
the existing logical data value; ordinary compilation erases such proofs. Fresh
elaboration remains necessary to establish that these proposed proof terms check.
Source correspondence is not a substitute for that gate.

## Preserved pre-review corrections

The first metadata draft ambiguously labeled the twenty-five report roots as a
public-theorem/report count. Its exact overlay and correspondence are preserved
under `pre-review-metadata-01`; METADATA-WORDING-CORRECTION.json records the
clarification without a source change.

Source inspection then found that Lean's equality notation has precedence50 and
Boolean conjunction has precedence35. The full Boolean RHS of each new `change`
goal therefore needs parentheses. The initial source pair and maps are preserved
under `unselected-draft-v1`; SOURCE-GRAMMAR-CORRECTION.json records twenty-two
parenthesizations per representation, with explicit recovery identities for the
earlier canonical paths. The final baseline-to-candidate overlay still changes
only the same thirty-two proof fields. No compiler was run and no mathematical
attempt was consumed by either draft correction. The relevant pinned Prelude
and Notation sources are retained as uncompiled SDK context.

## Cost hypothesis and selection boundary

The consumed SyntaxHasLP120 attempt accepted112 reports but exhausted its budget
before Literal could emit a report. The later unchanged-owner Wrapper136 attempt
accepted71 reports and stopped at two actual Literal scope-proof errors; its
Core/Cached times were approximately14.24/12.57 seconds. These are root-recorded
results, bound as context. They do not measure this candidate or identify which
individual declaration consumed the module time.

The purpose of the new scripts is to avoid broad simplification at these32 proof
sites while retaining the executable algorithms. There is no measured speedup,
minimum saving, successful native compilation or complete-budget claim. The
earlier direct certificate layer did not establish sufficient headroom for the
larger selections. These additional proof rewrites may also be insufficient.

The next authorized mathematical selection is a genuinely new complete closure
combining this independently reviewed owner with the separately diagnosed Literal
repair and the existing reviewed wrapper/frame dependencies. The Literal repair
is not authored or selected by this package's inventory. All actual owners must
still be freshly compiled under the unchanged one cumulative30-second,
one-CPU/thread,1-GiB, default-limit and three-axiom policy. No standalone unchanged
base timing run, split compilation, prepared object or source-key reset is
authorized by this candidate.
