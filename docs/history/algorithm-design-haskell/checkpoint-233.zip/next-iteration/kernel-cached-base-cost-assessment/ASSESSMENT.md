# Cached base-cost assessment after the consumed Syntax/Bulk prefix

Status: static source assessment only. No new mathematical source is selected,
no tactic has been executed, and no compiler, profiler, evaluator, exporter,
preflight or saved-result reader has been run by the author. Current owners and
all consumed attempts remain unchanged.

## What the actual result establishes

Root's frozen complete120 attempt at
`kernel-cached-syntax-haslp-repair/gate` accepted 112 reports and produced twelve
ordinary artifacts before the cumulative wall deadline stopped Literal before
any report. Root reported 30.260967175001497 seconds total, with Core taking
13.193248179 seconds and Cached taking 11.655351567 seconds. Syntax11 and Bulk30
were accepted in that prefix. The report, marker and recovery are exact inputs
of this assessment; their mathematical/control acceptance remains root's recorded
result, not a new saved-result audit by this author. No unchanged120 retry is
proposed, and accepted prefix objects cannot be reused in a later fresh gate.

The source-level evidence does not identify which individual declaration consumed
those module times. Source size, number of tactics, broad simplification sites
and imported declarations are not a substitute for such a measurement.

## A concrete proof-only candidate for later independent review

The current Cached owner retains 32 broad-simplification certificate branches:
sixteen in `wscopedBXP` and sixteen in `leavesSubXP`. These are the two Boolean
proof-carrying traversals. Their computational steps already return an actual
Boolean together with an equality to the corresponding plain descent. The
remaining proof scripts first unfold that descent and then call the general
simplifier with branch and child equalities.

A future distinct candidate can replace those certificate proofs with one-step
`.eq_def` rewriting, the already supplied cutoff equality, the actual branch
fact and the actual child equality. For example, the successful application
branch has facts `true = wscopedBP f d` and `ra = wscopedBP a d`; after the false
cutoff selects the constructor descent, those facts give exactly
`ra = true && ra`. The false-first-child branch gives `false = false && ...`
and needs no assumption about an unvisited child. Analogous equations hold for
the leaf-subset walk. The fvar branches additionally require the exact `idx < d`
or `leafMem ... = true` guard; a negative guard must be converted to the matching
Boolean equation explicitly rather than treated as a propositionally equal
replacement without a proof.

This candidate must keep every returned Boolean, memo read/write, memo key,
short-circuit order, recursive call, pointer/exclusivity guard and cutoff literal.
Only the proof fields can change. Exact logical and physical overlays must bind
the full ExprOpsC origin and current ordinary owner; all earlier proof-sharing,
omission and header-repair scopes remain at their historical identities. The
candidate would receive a new independent source review before any selection.

The exact census also records ten single-substitution leaf proofs, eighteen
bulk/reversed-substitution leaf or bvar proofs and nine public cutoff proofs
that still invoke broad simplification. They are secondary proof-only sites;
array indexing and dependent branch equalities make the bulk bvar proofs less
suitable for a mechanical initial replacement. No claim is made that these
69 sites dominate cost, that every replacement elaborates, or that any specific
number of seconds will be saved. Earlier direct rewriting of the Expr-valued
compound certificates did not establish the headroom needed by complete120.

## Durable restrictions on further reduction

The current pure and cached owners retain all six callback families and their
actual knots: ordinary head reduction, full reduction, inference, definitional
equality, annotation and infer-only inference. The original theorem wrapper
requires inference, annotation and conversion. Removing those families to get a
small reducer would fail the intended original-checker integration obligation.

`instantiateList_cons` remains required by the actual whole-query lambda-spine
route and GeneratedScope7. Its recursive theorem and its pure computational
`instantiateList` stay selected. The unused-looking `sizeB_instantiate1` theorem
is not omitted by this assessment. Current omitted parsed-driver/installation
APIs remain a separate explicit restoration obligation; a proof-only certificate
candidate cannot claim that it restores them.

Consolidating physical files or moving proof commands is not, by itself, a
license to retry a consumed source selection. No source-key reset through path,
metadata or runner changes is proposed. Any future consolidation would also
need a separate exact private-name, section, import and option correspondence.

## Immediate next selection

Root has requested the genuinely new Wrapper136 dependency closure: the unchanged
reviewed Core, Cached, Stable and Helper owners, followed by Literal8,
HelperFrame16 and the separately repaired Wrapper41. Syntax/Bulk and unrelated
operational leaves are not imports of that closure. All seven selected owners
must be freshly compiled in the same unchanged 30-second/one-CPU-thread/1-GiB
interval. This directly tests new wrapper/frame/literal obligations; it does not
repeat the failed120 selection or inherit an exemption for accepted base objects.
Its fit is unknown. The proposed Boolean certificate candidate is deliberately
not selected in that next gate.
