# Independent review: diagnosed Boolean terminal proof repairs

**Status: passed source-only review of the sixty exact proof-field changes.
The repaired files are uncompiled; no timing improvement or closure fit is
established.** Reviewer: book_scope_review. Author: reflection_evidence_review.

The complete changed walk bodies, all thirty actual residual diagnostic
goals, both exact source maps, their ordinary/native correspondence and all
new pinned identity lemmas were read. All 264 author input identities match.
Every one of the fifteen primary intervals matches its retained complete
source file. The three new complete SDK copies also match the restored
pinned SDK directly. No compiler, gate, preflight, mathematical computation,
exporter, profiler or retained evidence reader ran during this review.

## What actually failed

The preserved complete136 attempt with source key
`de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a`
failed in the physical Cached owner. Its raw stdout contains exactly thirty
unsolved-goal diagnostics: fifteen in wscopedBXP and fifteen in leavesSubXP.
Each literal diagnostic span matches the new diagnostic map and the original
proof field's line and column. The map covers every error in that raw output.
The two projection proof fields have no reported diagnostic and remain
unchanged.

Core's single report was accepted, and all twenty-five observed reports from
the failed Cached module were unaccepted. The later Stable, Helper, Literal,
Frame and Wrapper modules did not start. The retained root report records
24.491039530003036 seconds, peak 866408 KiB, and a proof failure rather than a
resource-limit event. Error-recovery sorryAx in downstream report text is not
an admission in either source. These facts describe the consumed predecessor;
they are not a fresh run of this repair and are not a native companion run.

The prior forty-input Boolean32 review remains bound to its original files.
This separate layer addresses the explicit terminal equations that the
subsequent compiler found missing. Neither that historical source review
nor the failed execution evidence has been rewritten.

## Mathematical review of all thirty physical proof fields

Eight leaf fields retain the same original descent and cutoff rewrites.
Those rewrites leave the actual proposition `false = true` as the condition
of an if-expression. The additional `ite_eq_right Bool.false_ne_true` uses
the current pinned theorem to select the else branch. The remaining match
has the concrete bvar, sort, const or lit constructor and returns true. No
new semantic assumption or proof about the node's packed fields is needed.
The term is added to the existing rewrite sequence and has no following
proof command that would require a still-open goal.

The sixteen non-let composite fields divide into eight true and eight false
cases. Their already observed residual types are respectively
`result = (true && result)` and `false = (false && child)`. The new terms are
exactly the symmetries of the pinned `Bool.true_and` and `Bool.false_and`
equations. The child in a false branch is only a Boolean expression appearing
in the equality; no result or certificate for a skipped recursive visit is
assumed. The existing scope-fvar true branch still uses the variable's own
index as the annotation cursor, and its false branch still uses the original
negative index guard. The leaf-subset fvar branches retain the actual
membership guard and the existing false-of-not-true conversion.

The six let fields preserve the original left-associated conjunction of
type, value and body. In the two all-success branches, congrArg transports
`true && true = true` through the outer conjunction with the returned body
bit, then Eq.trans composes the outer true-and identity. Taking symmetry
gives the observed residual goal. In the two value-failure branches the
inner equation is `true && false = false`, followed by the outer false-and
identity. In the two type-failure branches the inner equation is
`false && value = false`, again followed by the outer false-and identity.
This preserves association without reassociating the original program or
requiring certificates from unvisited children.

The existing parenthesized `change` expressions remain unchanged. The new
terms use only current pinned names: ite_eq_right, Bool.false_ne_true,
Bool.true_and, Bool.false_and, congrArg, Eq.trans and Eq.symm. Their exact
signatures and directions were checked in the retained SDK intervals.
In particular, the proof uses explicit Boolean identities and does not
depend on the opaque/implicit-reducible Boolean conjunction reducing at the
end of the earlier rewrite tactic. No new broad simp invocation, deprecated
alias, repeated recursive unfolding, speculative fallback, custom theorem,
axiom or admission is introduced.

## Byte correspondence and unchanged operational behavior

The physical candidate is 211978 bytes, SHA-256
`9106a2d9b63f90a0fdcabe5d2c9e8cf6205d01eefeee11eb666b4b008bc59661`.
The complete native ExprOpsC companion is 79440 bytes, SHA-256
`b9a949607e4b0c6f4f9a717a3d79297a72e904246201f164a8f07f497ef623e3`.
Each differs from its immediate predecessor in exactly thirty recorded
proof fields and gains exactly 1828 bytes and twenty-two lines.

All sixty forward replacements reconstruct the complete candidates, and
all inverse maps reconstruct the complete predecessors. The sixty-two
complementary spans match their recorded hashes and are byte-identical.
The two original and two repaired full walk blocks are byte-identical
between ordinary and native representations, with their own absolute
offsets retained. Both projection proofs are in unchanged complements.
All existing declaration headers, imports, options, attributes and report
commands are unchanged; the physical owner still has its same twenty-five
explicit report roots.

Only propositions inside existing subtype certificate fields change. Every
returned Boolean, child visit, short-circuit order, scope cursor, binder
depth, packed-field test, exclusivity read, borrowed argument, memo key,
memo read/write and operational branch remains literal. The source
correspondence therefore preserves the algorithm and its intrinsic result
specification. It does not assert generated private-name identity,
machine-code equality or successful native elaboration.

The native file retains its full predecessor API; it is a source companion,
not an additional selected compiled owner. The ordinary owner retains its
explicit earlier evaluator and driver omissions and the older ordinary Core
representation boundary. This proof-only repair restores none of those
missing APIs. Any later exact driver restoration remains a separately
reviewed ownership layer.

## Selection and remaining verification

The audit binds this new scope separately from the previous Boolean32
overlay, its grammar and wording history, the original proof-sharing and
evaluator-omission scopes, the diagnosed Literal repair and the consumed
complete136 controls/evidence. No historical review is rebased. Source-only
identity checks do not establish elaboration of the candidates.

No semantic blocker was found in these terminal equations. A next selection
must bind this exact new owner and every actual dependency of its target,
including the separately reviewed Literal correction where applicable, and
freshly compile the complete closure under the unchanged common thirty-second,
one-CPU/thread, 1-GiB, default-heartbeat/recursion and three-axiom policy.
The consumed predecessor remains consumed; this review authorizes no
unchanged retry and permits no reuse of accepted prefix objects or budget.

The repaired source is not evidence of cached whole-query success or its
bound, actual installed annotations/program pins, true-prefix validity,
EnvWF, original GroupChecked or the stock numeral theorem. The recorded
failed-module duration cannot establish a successful optimization or
complete-closure fit. Those conclusions still require their own successful
fresh evidence and mathematical links.
