# Actual terminal-repaired complete136 result

The sole fresh complete attempt **failed in KernelCachedHelperFrame** after
**28.222689836002246 seconds**, with peak process-group RSS **885556 KiB**.
The metadata preflight passed. Core, the repaired Cached owner, Stable, Helper
and the repaired Literal owner all passed: **79 accepted reports**. This was a
proof failure, not a resource-limit event. Wrapper did not start.

| Module | Seconds | Exit | Accepted reports | Observed reports |
| --- | ---: | ---: | ---: | ---: |
| KernelCompactCore | 12.674421079002059 | 0 | 1 | 1 |
| KernelCachedForward | 12.75440677699953 | 0 | 25 | 25 |
| KernelCachedStableForward | 0.43393963599737617 | 0 | 20 | 20 |
| KernelCachedHelperDirect | 0.8079588549990149 | 0 | 25 | 25 |
| KernelCachedLiteralForward | 0.4022323419994791 | 0 | 8 | 8 |
| KernelCachedHelperFrame | 0.7299084910009697 | 1 | 0 | 16 |
| KernelCachedRecordWrapper | Unstarted | — | 0 | 0 |

The five actual HelperFrame diagnostics are:

- At 101:14, stored-type identity preserves a residual if-expression whose two
  branches are pure. The supplied pure-preservation theorem does not by itself
  split that conditional.
- At 118:16, the two stored-value branches have the same residual conditional
  problem, producing two diagnostics at that source location.
- At 198:16 and 200:8, rule-RHS preservation still has outer matches on known
  option/recursor constructors and the rule lookup. The selected failure/success
  proof is applied before those matches have been reduced using the rule fact.

All sixteen reports from the failed Frame module are unaccepted; five contain
Lean error-recovery sorryAx. No source admission is present. The earlier thirty
Boolean terminal errors are repaired in this attempt: the exact new Cached
owner passed all twenty-five reports. The separate Literal scope repair also
passed its eight reports. The successful Cached duration is 12.75440677699953
seconds; this run does not demonstrate a useful cost reduction relative to the
older accepted owner. Complete-wrapper and final trace cost fit remain open.

The permanent consumed key is
`92de445d5e26edc3aaf051c6276c80117260704ed000a5458224b7e69708b9a7`.
The report is 510321 bytes, SHA-256
`c419078c5fcac341d7b229cecf2bdb1d970beff3371852e7d2564397c18be230`.
Actual source/control/snapshot/compiler/runtime/log/marker postchecks passed.
Root independently compared all 483 read-only snapshots with canonical bytes,
rehashing twelve raw logs and the consumed marker. SNAPSHOT-RECOVERY.json records
those exact mappings. No duplicated attempt inputs, prepared objects or SDK
binaries are needed in the source/evidence checkpoint. The dedicated complete
saved-result reader remains pending; this is not a new mathematical run.

## Next authorized work

Retain this failed source and evidence unchanged. Make a separately mapped and
independently reviewed correction to the three affected Frame proofs, addressing
these five observed goals. A new selection must freshly compile its entire
closure under the same cumulative thirty-second, one-CPU/thread, 1-GiB and
default-resource policy. There is no unchanged retry, isolated diagnostic run,
prepared-prefix reuse or inference that source review already implies success.

Continue review and completion of the finite input-parametric query construction
and actual record driver. Current drafted query bounds and conditional record
success still need complete fresh checking and their concrete installed pins,
annotations and true-prefix/cache lifecycle. EnvWF, original GroupChecked,
native integration and the stock `cqueens 16 = 14772512` theorem remain open.
