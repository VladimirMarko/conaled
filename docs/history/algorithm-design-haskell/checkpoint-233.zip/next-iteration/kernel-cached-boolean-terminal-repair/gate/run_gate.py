#!/usr/bin/env python3
"""Fresh 136-report cached closure with diagnosed terminal Boolean certificates and retained Literal scope repair. Root alone executes; no Lean without --run."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CORRECTION = ROOT / 'next-iteration/kernel-cached-forward-proof-corrections'
STABLE = ROOT / 'next-iteration/kernel-cached-stable-forward'
STABLE_CORRECTION = ROOT / 'next-iteration/kernel-cached-stable-proof-corrections'
DIRECT = ROOT / 'next-iteration/kernel-cached-helper-direct'
DIAGNOSED = ROOT / 'next-iteration/kernel-cached-helper-proof-repairs'
ACCEPTED_PREDECESSOR = DIAGNOSED / 'gate'
SYNTAX = ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections'
SHARING = ROOT / 'next-iteration/kernel-cached-forward-proof-sharing'
BULK = ROOT / 'next-iteration/kernel-cached-bulk-bound'
LITERAL = ROOT / 'next-iteration/kernel-cached-literal-forward'
COST_PREDECESSOR = ROOT / 'next-iteration/kernel-cached-complete-120/gate'
PRESENTATION = ROOT / 'next-iteration/kernel-cached-presentation-slice'
COUNT_SHARING = ROOT / 'next-iteration/kernel-cached-syntax-count-sharing'
OMISSION = ROOT / 'next-iteration/kernel-cached-evaluator-slice'
OMISSION_PREDECESSOR = ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate'
COMMENT_REPAIR = ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair'
COMMENT_PREDECESSOR = ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate'
HASLP_REPAIR = ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair'
HASLP_PREDECESSOR = COMMENT_REPAIR / 'gate'
PREDECESSOR = DIRECT / 'gate'
STABLE_PREDECESSOR = CORRECTION / 'gate'
ORIGINAL_GATE = ROOT / 'next-iteration/kernel-cached-forward-work/gate'
BUNDLED = ORIGINAL_GATE.parent / 'bundled'
MANIFEST = HERE / 'source-manifest.json'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
FORMAT = 'adwh-kernel-cached-boolean-terminal-136-gate-v1'
HISTORICAL_MANIFEST_FORMAT = 'adwh-kernel-cached-syntax-haslp-repair-120-manifest-v1'
HISTORICAL_MODULES = ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedStableForward', 'KernelCachedHelperDirect', 'KernelCachedSyntaxCorrespondence', 'KernelCachedBulkBound', 'KernelCachedLiteralForward']
NAMESPACE = 'ADWH.Experiments.Chapter15.KernelCachedForward.'
ROOT_NAMES = [
    'succeeds_pure', 'succeeds_modifyGet', 'succeeds_modify', 'succeeds_bind',
    'memoEI_hit', 'memoEI_miss', 'whnf_hit', 'whnf_miss', 'whnf_zero',
    'whnfCore_hit', 'whnfCore_miss', 'instListM_succeeds',
    'instLevelParamsM_succeeds', 'storedTyIdxM_succeeds', 'storedValIdxM_succeeds',
    'constTyAtM_succeeds', 'constValAtM_succeeds', 'ruleRhsAtM_succeeds',
    'iotaCertsIAux_never', 'iotaCertsI_never', 'defEqListI_empty',
    'iotaIndexOkI_noIndices', 'whnfAppI_never', 'betaPeelI_never', 'betaPeelI_done',
]
STABLE_ROOT_NAMES = [
    'stable_run_of_unscoped', 'stable_whnf_of_runs_above', 'stable_head_of_runs_above',
    'stable_run_has_one_fuel', 'stable_run_unique', 'stable_map_empty', 'stable_map_insert',
    'stable_nf_empty', 'stable_nf_frame', 'stable_nf_insert_whnf', 'stable_nf_insert_head',
    'whnf_cache_value', 'head_cache_value', 'stable_nf_flushed', 'flushed_whnf_miss',
    'flushed_head_miss', 'flush_starts_unseeded', 'true_memo_frame',
    'whnf_forward_of_body', 'head_forward_of_body',
]
HELPER_ROOT_NAMES = [
    'map_backed_empty', 'map_backed_insert', 'ienv_tags_empty', 'helper_cache_empty',
    'helper_cache_frame', 'helper_cache_memo_frame', 'helper_cache_flushed',
    'helper_result_of_unchanged', 'helper_result_stable_nf', 'instantiateListC_cut',
    'instantiateListC_eq_plain', 'instLevelParams_eq_plain', 'instLevelParamsM_correct',
    'storedTyIdxM_correct', 'storedValIdxM_correct', 'instLevelParamsM_helper_result',
    'storedTyIdxM_helper_result', 'storedValIdxM_helper_result', 'instListM_correct',
    'constTyAtM_correct', 'constValAtM_correct', 'ruleRhsAtM_correct',
    'constTyAtM_from_prefix', 'constValAtM_from_prefix', 'ruleRhsAtM_from_prefix',
]
SYNTAX_ROOT_NAMES = ['level_params_cutoff',
 'plain_level_params_eq_pure',
 'level_params_eq_pure',
 'pure_bulk_fixed',
 'plain_bulk_eq_pure',
 'bulk_eq_pure',
 'instListM_pure_result',
 'instLevelParamsM_pure_result',
 'constTyAtM_pure_result',
 'constValAtM_pure_result',
 'ruleRhsAtM_pure_result']
BULK_ROOTS = ['ConLeche.bvarOfData_lt',
 'ConLeche.fvarOfData_lt',
 'ConLeche.satSucc_lt',
 'ConLeche.toNat_max',
 'ConLeche.toNat_sub_one',
 'ConLeche.satPred_lt',
 'ConLeche.max_lt_32768',
 'ConLeche.bvarOfData_pack',
 'ConLeche.Expr.bvarBRaw_lt',
 'ConLeche.Expr.bvarBRaw_bvar',
 'ConLeche.Expr.bvarBRaw_fvar',
 'ConLeche.Expr.bvarBRaw_sort',
 'ConLeche.Expr.bvarBRaw_const',
 'ConLeche.Expr.bvarBRaw_lit',
 'ConLeche.Expr.bvarBRaw_app',
 'ConLeche.Expr.bvarBRaw_lam',
 'ConLeche.Expr.bvarBRaw_forallE',
 'ConLeche.Expr.bvarBRaw_letE',
 'ConLeche.Expr.bvarBRaw_proj',
 'ConLeche.Expr.looseBVarsBounded_iff',
 'ConLeche.Expr.bvarBRaw_exact',
 'ConLeche.Expr.MemoBInv.empty',
 'ConLeche.Expr.MemoBInv.insert',
 'ConLeche.Expr.bvarBoundGo_spec',
 'ConLeche.Expr.bvarBoundMemo_eq',
 'ConLeche.Expr.bvarB_eq',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_cutoff_sound',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.plain_bulk_eq_pure',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_eq_pure',
 'ADWH.Experiments.Chapter15.KernelCachedBulkBound.instListM_pure_result']
LITERAL_ROOT_NAMES = ['pure_head_nat',
 'pure_full_nat',
 'stable_head_nat',
 'stable_full_nat',
 'head_body_nat',
 'full_loop_nat_of_head',
 'cached_head_nat',
 'cached_full_nat']
HISTORICAL_REQUIRED = {
    'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero'],
    'KernelCachedForward': [NAMESPACE + n for n in ROOT_NAMES],
    'KernelCachedStableForward': ['ADWH.Experiments.Chapter15.KernelCachedStableForward.' + n
                                  for n in STABLE_ROOT_NAMES],
    'KernelCachedHelperDirect': ['ADWH.Experiments.Chapter15.KernelCachedHelperDirect.' + n
                                 for n in HELPER_ROOT_NAMES],
    'KernelCachedSyntaxCorrespondence': ['ADWH.Experiments.Chapter15.KernelCachedSyntaxCorrespondence.' + n
                                         for n in SYNTAX_ROOT_NAMES],
    'KernelCachedBulkBound': BULK_ROOTS,
    'KernelCachedLiteralForward': ['ADWH.Experiments.Chapter15.KernelCachedLiteralForward.' + n
                                   for n in LITERAL_ROOT_NAMES],
}
HISTORICAL_RAW_REQUIRED = {
    'KernelCompactCore': HISTORICAL_REQUIRED['KernelCompactCore'],
    'KernelCachedForward': ROOT_NAMES,
    'KernelCachedStableForward': STABLE_ROOT_NAMES,
    'KernelCachedHelperDirect': HELPER_ROOT_NAMES,
    'KernelCachedSyntaxCorrespondence': SYNTAX_ROOT_NAMES,
    'KernelCachedBulkBound': BULK_ROOTS,
    'KernelCachedLiteralForward': LITERAL_ROOT_NAMES,
}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
POLICY = {'Elab.async': False, 'autoImplicit': False, 'compiler_threads': 1,
          'cumulative_wall_seconds': 30,
          'default_heartbeats_recursion_and_compiler_options': True,
          'lean_memory_mib': 1024, 'resident_memory_kib': 1048576,
          'warningAsError': True}
HISTORICAL_120_SOURCE_PINS = [('next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCompactCore.lean',
  336027,
  'b91de3074ab7d61d07d8655cb0340ea855794c1af309a892c73f0343c85d4b17'),
 ('next-iteration/kernel-cached-forward-proof-sharing/source/KernelCachedForward.lean',
  219068,
  'f55d286c9df4cb31f12e9148bcc7b82bf0737c180709eaa585f2ea6062585041'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCachedSyntaxCorrespondence.lean',
  22155,
  '0429b107d8ad196772ed6af52d3fb5024226addd176ef18ef08a3e7a57e8eed8'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
HISTORICAL_COST_SOURCE_PINS = [('next-iteration/kernel-cached-presentation-slice/source/KernelCompactCore.lean',
  335500,
  'aaaccdd190332c305e355392cb6ef8045f5a74ce4e0081d0cc92481c72002044'),
 ('next-iteration/kernel-cached-forward-proof-sharing/source/KernelCachedForward.lean',
  219068,
  'f55d286c9df4cb31f12e9148bcc7b82bf0737c180709eaa585f2ea6062585041'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean',
  21993,
  '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
HISTORICAL_OMISSION_SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-slice/source/KernelCompactCore.lean',
  297743,
  '573ab19b394b85f494711e994970e858e0c1bf5171f69c62b49921cf7e3b22ee'),
 ('next-iteration/kernel-cached-evaluator-slice/source/KernelCachedForward.lean',
  207543,
  '66cb3f9a5b4d50bcc1859414db516288e84f530874babf08f63759630aa182e4'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean',
  21993,
  '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
HISTORICAL_COMMENT_SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean',
  297742,
  '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648'),
 ('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCachedForward.lean',
  207542,
  '126c0ceafb7e354723812c42f1ccff52e73004d80b194e4dcf35796c8073ab2e'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean',
  21993,
  '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]
HISTORICAL_HASLP_SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean',
  297742,
  '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648'),
 ('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCachedForward.lean',
  207542,
  '126c0ceafb7e354723812c42f1ccff52e73004d80b194e4dcf35796c8073ab2e'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-syntax-haslp-repair/source/KernelCachedSyntaxCorrespondence.lean',
  22107,
  'a40eb68c70456557b75c687aa3964f84a482d02a7a1d0dc5d9b44da057810f1a'),
 ('next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean',
  16982,
  '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325')]

OMITTED_WHOLE_ORIGINS = ['ConLeche.Kernel.Basis.Builder',
 'ConLeche.Kernel.Basis.Eq',
 'ConLeche.Kernel.Basis.Nat',
 'ConLeche.Kernel.Basis.Empty',
 'ConLeche.Kernel.Basis.False',
 'ConLeche.Kernel.Basis.Quot',
 'ConLeche.Kernel.Basis.And',
 'ConLeche.Kernel.Canon',
 'ConLeche.Kernel.Basis']

HISTORICAL_FIXED = {
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
    BUNDLED / 'SOURCE-CORRESPONDENCE.json': '264fd7e7cef66082b8f116c6b3e8eb511363bc68f22384c6c715b89fdd4b328f',
    BUNDLED / 'SOURCE-INVENTORY.json': 'c001e9b25724b572a6c8ae48c605276fc791c33665a97afb148b39b533c92f5e',
    BUNDLED / 'SOURCE-AUDIT.json': 'a837f17f55ea29041e6012092c06ede8c9928b1cff4638f9eb92519a8add2139',
    BUNDLED / 'SOURCE-REVIEW.md': 'd61dd5c508517aedf291a06ac0d85b68e46369474ddac0b863640286c2c17b7e',
    CORRECTION / 'PROOF-CORRECTION.json': '921c4a15b9e77b5d00df0a0d27a63496f511873ddafa4073191a9f93f2359c4b',
    CORRECTION / 'SOURCE-AUDIT.json': '5d664f252cb76f0634a5091bbda4f494b2787f725de1df119684beed55354223',
    CORRECTION / 'SOURCE-REVIEW.md': 'd26809c70fc75505585cf5b934ebbd7939b4b7f045a6178b34165916c0909ed8',
    STABLE / 'SOURCE-INVENTORY.json': '12b93b51c94f77758b79f36ecd412ed57193a1957c85fe0eb670992fb3c7c3fb',
    STABLE / 'SOURCE-AUDIT.json': 'f4bcac938b6f00f46e9e7b4f53924cd1286bfa7c86436f1b88d7bd5cc4d38e14',
    STABLE / 'SOURCE-REVIEW.md': 'e309c82f1b9263a02911195fde542660c204961804ff1eaf0ead97be3f149be8',
    STABLE_CORRECTION / 'PROOF-CORRECTION.json': '4e559e46e14450d25ce621212d045635056bc9af25f45436b8b40428815a3b0d',
    STABLE_CORRECTION / 'SOURCE-AUDIT.json': 'ed234c0ec2e4d528b191783baade14bb7e66c569b1a355d02f6d1842540c3e25',
    STABLE_CORRECTION / 'SOURCE-REVIEW.md': '5aec4f93f875601b980debefa608506ae13b12b8cad24e0fffaf1ceace985a9d',
    DIRECT / 'PROOF-CORRECTION.json': '452dea5fa7d99bea9a02a771c1f9a8c01fabcc9f6808d908a6dfe76425fbfc41',
    DIRECT / 'SOURCE-INVENTORY.json': '4a2d1c43edda021d5f9495d8b538e041e4c41f9303aa2dbaafde5a3e3d612039',
    DIRECT / 'SOURCE-AUDIT.json': 'e37b164c2fe9b5862da224231879dc4045bc42bfc6c04f6e6bd7d145c22bae48',
    DIRECT / 'SOURCE-REVIEW.md': 'ca06e8cd3b5d91067e9aeffaf92aa8c4054210f701b752d2c863abf3a9e3ead3',
    DIAGNOSED / 'PROOF-CORRECTION.json': 'b2e80318564bb23ecdf7b377c5f490574049a9ff1e9537baf063f887e14c1794',
    DIAGNOSED / 'SOURCE-INVENTORY.json': 'ab226bf4cb7ce175d1b403104e602bb05b1c195e9d146d6763ac5d2a8dbc7742',
    DIAGNOSED / 'SOURCE-AUDIT.json': '0a9ed6e2cc91c9698c31bfa4e731b13b8729d13ca557a15b83f857e4ee4d1e52',
    DIAGNOSED / 'SOURCE-REVIEW.md': 'fe5d0304726eba2fd26645cc3aa5e94c814ced133fbbfb10dd9dad7eb6347bd7',
    PREDECESSOR / 'attempts/complete-01/report.json': '9eb9fef9f6d5d1ded434675495e9e2ab6ed77f3d1cdd0d898c3fbfc80c4d5635',
    PREDECESSOR / 'attempts/complete-01/KernelCachedHelperDirect.stdout.log': '76ce4f727a29c7648689b39cd3014986503a9c1616c32e17bbf8ac9c861fd82e',
    PREDECESSOR / 'execution-markers/complete-c7be13545fb772ae734d0aa6c3568a22709662870f3b7058ab0f66a8561ab321.json':
        '5437ec3caadf299854848cf47494f000d0fc6d09c1149cdd1cd6e803fe4ffc76',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/PROOF-CORRECTION.json': 'd47cb05c4b9c3b1b1a7af9832e2bfbe865593f6928e5e796f7ae09e540d784df',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-INVENTORY.json': 'b2fd5f6372a8f50dc10360bd3fbcca2a5eb35353f04fdf7401f3f2f6645776de',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-AUDIT.json': '9ce96ceffce8d01396e7c126e70257db6a77d88eb66d1f854be16576d6ac9110',
    ROOT / 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-REVIEW.md': 'a5aacb07793e5b82df9280070fba62801197cc98a4e17ad7aab5b98efd04a378',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/PROOF-OVERLAY.json': 'afb29fcbc1e31ae87c8d4e203c6930f49786754c5d7b0128fe4d269df681f589',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-CORRESPONDENCE.json': 'e9888035205452549c7080acef2b75a9fed00aed7d822eb1941549347fffec9b',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-INVENTORY.json': '7e03b38816335ecbc8685e84ddcd58b6e908ba267fbedcf660b03a4cf174262a',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-AUDIT.json': 'a473f95514dac7fcc6fbfa3fb18702d22c7d3073527024a6079b523e0c635cd7',
    ROOT / 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-REVIEW.md': 'c70c25643de2f329e95248b425e57a2db89eca30c033fef2e363cfb2bbdf5a54',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-CORRESPONDENCE.json': 'a6a245aa258ec3fb75879be5ef4a59d47f1ca94d8f73a97d088071a49c70d750',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SLICE-BOUNDARY-CORRECTION.json': '9d5636dabea34d84b99e0c035ff2cd6cf53c33d7bac91236709b0222835dac6a',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-INVENTORY.json': '3ec1eb8f5fdcdf5ba2533ce332b8b7bdd740059bd24ca73e30e30b38ea454847',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-AUDIT.json': '584941f93555a1165a30079084e39b41b0e3562639bb5623a0cc409ecc82e438',
    ROOT / 'next-iteration/kernel-cached-bulk-bound/SOURCE-REVIEW.md': '56d4daad9e53a46759def8b53299f371b61c0daee7b4295bf386e1f3de8a47c8',
    ROOT / 'next-iteration/kernel-cached-literal-forward/REVIEW-WORDING-CORRECTION.json': '0fa2132d2467be55126c14f8cf2c3245f0074a43295e381c40cc462e429e7b53',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-INVENTORY.json': '2f2f5588a3c048b62adba38783f469f95486536c4225cc507b3b60cbef84df96',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-AUDIT.json': '271bd3647fbffba3e3d1ba04ccda5922f758a947fa1ebb4b766b6bfbeb0ca4a2',
    ROOT / 'next-iteration/kernel-cached-literal-forward/SOURCE-REVIEW.md': '0f2ec16817a349b2f9ac63a110f39204bb80f96c3f65450c0ea0604d86ae8984',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/run_gate.py': '663ae3b965c439ddf48205c28213fcce76f5b690e110a4449f097cd71cc0e138',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/source-manifest.json': 'feb9df79f0ff7c610494ffa017e3d6eb8dfcb5fc8ba6b3d4a1953b5e33b3f684',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/PROTOCOL.md': '9ed08c7ab1fbf0e1c2c173671d4894237443ec1b78104500e00dcf2dc12ee9c3',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/INDEPENDENT-CONTROL-REVIEW.md': 'd0fe46684410ca6639ebd12a698e831e6d56fcc86a2b8e04dcde4bbca17fc8ce',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/report.json': 'e5df6430b847459c7572db232b4f1699b21cb1253d76b2e8b5434324e7ef625c',
    ROOT / 'next-iteration/kernel-cached-helper-proof-repairs/gate/execution-markers/complete-efb1eed69cd6102398244e005a8cba75455a39e4c687b2fad539ba5aa1f8c444.json': '62add59871126874e8adb4920598f6cfbf3cc0980351daafbf0f925655590543',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/PRESENTATION-OMISSIONS.json': 'ae680f4611cfcf92167f63abaad1edbb509d896a5358563695ca194cb4159be4',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/STATIC-CENSUS.json': '42c52902151cf2382657090112ecef5b56adcbb8da7dc32ada29d8a205cbae66',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-INVENTORY.json': '073c5dceee9d5c348ec78e8cff4bc0561ca16e0dae2dbd2f48979356dcca8c12',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-AUDIT.json': '44cd82ab8006080a7cb686400da941980db575a370152b6d9e5866ab40bfe4c4',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/SOURCE-REVIEW.md': 'a5bcff768a0c6fe5d7d1bc6e76201993aa47b268097c9c8494caf8c1e0ad9970',
    ROOT / 'next-iteration/kernel-cached-presentation-slice/PLAN.md': 'c61100b3c50d918a339ff56fd4ed5abdf764981ca7b4a110a066ea5e90809142',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/PROOF-OVERLAY.json': 'bd7b10024da7925f9b568c4c1adf83e3bb94e77dd4aeec35f58e645e22b9bf92',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-INVENTORY.json': '4a26aa56b016f7f22ef8b96d6dabd24768a46f087a08eb6e027716b9441c0d5d',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-AUDIT.json': 'ece74d9a5fda51ee34b5114e1cdc9ea1b296323e113d27f5ca1a870ecf28a7ed',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-REVIEW.md': '70d6f0cb92e886093945041df302d559c254be43977a0a64facc8d279c86aefa',
    ROOT / 'next-iteration/kernel-cached-syntax-count-sharing/PLAN.md': '534d7c40b714995377d4a96c0d8a5e488ee34010808dfb05139e79ad8ac3bdcd',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/run_gate.py': 'dca4f133beec0cd8488f063973ea68a316caa17e74e80ea4f0462e582dc29f2f',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/source-manifest.json': '21e7a9cdb086c9440869c9e9fb0355b2edfd0047e9b4c59312d179c265b91e20',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/PROTOCOL.md': '001fc582953bd92aed68e531ca87bc7f76cf7fc95b3258cf808800fe5e175b7e',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/AUTHORING.md': '68e4b7e3acfb07d12cf04793114c3c1278d95906643c1b3c49cba1682df915a1',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/INDEPENDENT-CONTROL-REVIEW.md': '202aa19627bcea128634fc8a546f283f4f7e865c96827fcb660e2d02079589d4',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/report.json': '78f26ceecef3ee2345fcae825faf9c3c2c9adc2a102629e475a788443160cc11',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120/gate/execution-markers/complete-785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e.json': 'f4df56cb45dfdf40fa8a85a5125b0aaab772ebfc97728bd021e30f41986efd4c',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-OMISSIONS.json': '3107123cf85d5952e3007f662f71bdd1b6bc93d2f6f5d87a61d195237f162b09',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-CENSUS.json': '60cc15b6a20bb35fa22a29c085ce2767c572e31fb218566e7563bb80ab28ba01',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-INVENTORY.json': 'a1331f78878ff382eefd967faeeb90491725ddc15dcac2ca9daa73685f1cb273',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-AUDIT.json': '8e491b44a84f3b2a84af35a8e07e3297ffb407b8ac573e91269aebad31685383',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/SOURCE-REVIEW.md': '4c51622961d69aab5ce1372df96742e4bc3e0464994a43d17e94953b6e4e7522',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/PLAN.md': 'e4fb5feb67b637a3a529a92e18b1f123f2d4a2f754e4902ba5da2040521972d2',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/AUTHOR-REVIEW.md': 'f89a6bff3b4c2d79021d81858b1faff66a3a922f19f1412c45f3ed094243788a',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/ALTERNATIVE-COST-ROUTES.md': '4f88ee6ccbc6dde4381959eee8986bdc61803d5dff69c6c2d4ec784eab559ba9',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/run_gate.py': '706acbb38dc5129f2e63f637e6828afc8fa994183a6f6024ad977408346647a2',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/source-manifest.json': 'd3db0d88fdb63e6cf70c27b81e5d7251223f3f2ecb136d3630ba7cf10c5a5e19',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/PROTOCOL.md': '014cb95b03bd3b60b1c87c24237dd4c4f82e4e7d00a9e40a5fdadb0970e75111',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/AUTHORING.md': '9de6176fe79b3cc85e06b1cd9bebc8bf77741c5e0ae8cfc793a78733d3cdfa66',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/CONTROL-CORRESPONDENCE.json': 'efbcea4dc10788530ee6ec2df7284de85672322ae6c3e872087264e1b8e90d33',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/INDEPENDENT-CONTROL-REVIEW.md': '568460741d60b04c67e6875c56c1278244ca15848dedec9a01a1262d418ce29a',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/report.json': '90af5dd72031f041a5c7a8674ad7f039cc5d59e1f7f3120e3b0172ab9bb3d828',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-complete-120-cost/gate/execution-markers/complete-3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5.json': 'e0ec22c88b955a3cfc432078e43dc60fc434a242c8b65f9f8d23929ec01b7650',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/PROOF-CORRECTION.json': '72056b7c85fb9d7f90b63bfde1896a66407094bbed0134dd8fbd99401b601885',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-INVENTORY.json': '21d6d5fc094a230f4cebe2efce7ecea8acaa43c898820d6a2cc9314e49039969',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-AUDIT.json': 'aa4898305d8d195f2033df240d154ebf47f8b55406db52e6cac5e069727cce9c',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-REVIEW.md': '532b5ca2695b4dfd8481ef4a60e7e4a8a30ee6455615ee14f878e3a7fb364df5',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/PLAN.md': '9c1c94fc69aae5309a994eb33cb98b1d4bfeacb17071cff46fd73daa835ab7d6',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/run_gate.py': '38ae4c7fa21c95c7ea98ee82f90135b07bfbcf8a0908d01b310b29f0915d752f',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/source-manifest.json': 'fe94740d96a2b75d58af6244ba9ec531935f98ec708227cf485d51f9612e6523',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/PROTOCOL.md': '61d0a26f4739e1ee9568dba1505f665ea088a43bf9fa4362a7b05833b94c5282',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/AUTHORING.md': '45442bb2a7ce202251884ec5202c4a04c9750454c425f5be903120ad34159014',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/CONTROL-CORRESPONDENCE.json': 'c7dbd2c8f505be4de17144583b16151b463624605aa794210991d09d765f4a69',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/INDEPENDENT-CONTROL-REVIEW.md': 'df870b14fbff102228ac20a85959fb7f0615db8b0b63c38b6693ab7f9b9f8475',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/report.json': 'db069a45089d773595ad4b8d43d21143f1f521df64d3d4dc8c1213d80c5b8da1',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/KernelCompactCore.stdout.log': '314dfb02e434e235beaab75ee4d13cd00a9eb64af71fda3ab1060234bd5daf9c',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/execution-markers/complete-1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06.json': '90c749c35587991001cc3674a1a459b655f1ac816be81d71e04bbac0099283e6',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/SNAPSHOT-RECOVERY.json': '61dcb8cb0b9bdcfce52a44e75e164515f66599ef9863b4eba7c93440d7ff0625',
    ROOT / 'next-iteration/kernel-cached-evaluator-slice/gate/RESULT-AND-NEXT.md': '387480b043590960fea95b73b6685c1ab785b955bb843ef9493996a2d3fe2781',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/PROOF-CORRECTION.json': 'a4476ece3cd9513671c7d3ee7af65734fcedb224e07fbf04fcb339b7668d15ed',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/PRIMARY-SOURCE-INTERVALS.json': '6ed2829e44f2d55410918f8e1bd7a3803e4270de6dfd0148e1e01b9d09165023',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-INVENTORY.json': 'e32efdf475f116a559c2ad647d4598eba45b88407c15308e29561cde03f4c2d8',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-AUDIT.json': '57f0d1b8438cc361a21d785600a53dbbecb8697a2805dfabce8aaae36ad61d5f',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-REVIEW.md': '8336b966534a818e23c6216b5a9915294957206b5fe43ce83a4b80c00c870b81',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/PLAN.md': '22c1a8b51a5425bb78d6471b089b6971516840fa4e52ec46868ec33ee0867d1f',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/AUTHOR-REVIEW.md': '1ce28ef8bbeec2a30e73ccb397fbaf8d257480ad48cfafd2e4a0b40480190bc4',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/run_gate.py': '68b3d9095d0478c1132e732962952ed0641a48e9811001b7a53df99c47ce4671',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/source-manifest.json': 'b965bc9028f84c5c4098f0a6efdc309230e6f6b677b99a7045871f0f68019bba',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/PROTOCOL.md': '9ac747a03365eaebe737a95be2a940f36ea58cc2704365b2edca0060993a1cd0',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/AUTHORING.md': '3532fd26c3bb4d1eae4d2e2f282f5324e1d2a23ef4d7e47524196615e30ff151',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/CONTROL-CORRESPONDENCE.json': '66d2e83aa799719d97f560c90f2e36df7fa9396d75723633c3273bde230d6f9f',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': 'fcb5d0a4fcd9702c55bbf967c928fe7d3009141a13d84ca0df2385b5a7f75349',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/RESULT-AND-NEXT.md': '0ce4a760464826271e9f225aa5a2e65a9434bdfcd6331804ad3bf6e2023924b4',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/SNAPSHOT-RECOVERY.json': '2ee545f04a73afb3ab36c159a10b4928ed9aabf18f6ee890641e5f36077012b4',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/report.json': '8e9302670e457e8ca31d31d4ebbed41a6a32e6421ad1b8d25abce813c6a18ad1',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/execution-markers/complete-cf693905054730e65c5f5dc7b79c8dd6a2544a459ebd689b3b42b1ceb68f5b94.json': 'eae0d7261d2f8a76647cdb6ec648be096350c2a1d865a5fea5c636943817bf2b',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': '802d31d4fce3f0a78bb9eb4da559b3c44f94aa291614de6dbc83f35fc476b1ef',
    ROOT / 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
}


# The current selection is independent of the historical complete120 metadata context.
HISTORICAL_HERE = HASLP_REPAIR / 'gate'
HISTORICAL_MANIFEST = HISTORICAL_HERE / 'source-manifest.json'
WRAPPER_PREDECESSOR = HISTORICAL_HERE
FRAME = ROOT / 'next-iteration/kernel-cached-helper-frame'
WRAPPER = ROOT / 'next-iteration/kernel-cached-record-wrapper'
WRAPPER_REPAIR = ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness'
MANIFEST_FORMAT = 'adwh-kernel-cached-record-wrapper-136-manifest-v1'
MODULES = ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedStableForward', 'KernelCachedHelperDirect', 'KernelCachedLiteralForward', 'KernelCachedHelperFrame', 'KernelCachedRecordWrapper']
REQUIRED = {'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero'],
 'KernelCachedForward': ['ADWH.Experiments.Chapter15.KernelCachedForward.succeeds_pure',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.succeeds_modifyGet',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.succeeds_modify',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.succeeds_bind',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_zero',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.instListM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.instLevelParamsM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.storedTyIdxM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.storedValIdxM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.constTyAtM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.constValAtM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.ruleRhsAtM_succeeds',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsIAux_never',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsI_never',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.defEqListI_empty',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.iotaIndexOkI_noIndices',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfAppI_never',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_never',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_done'],
 'KernelCachedStableForward': ['ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_run_of_unscoped',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_whnf_of_runs_above',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_head_of_runs_above',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_run_has_one_fuel',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_run_unique',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_map_empty',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_map_insert',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_nf_empty',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_nf_frame',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_nf_insert_whnf',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_nf_insert_head',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.whnf_cache_value',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.head_cache_value',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.stable_nf_flushed',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.flushed_whnf_miss',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.flushed_head_miss',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.flush_starts_unseeded',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.true_memo_frame',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.whnf_forward_of_body',
                               'ADWH.Experiments.Chapter15.KernelCachedStableForward.head_forward_of_body'],
 'KernelCachedHelperDirect': ['ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_empty',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_insert',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ienv_tags_empty',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_empty',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_frame',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_memo_frame',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_flushed',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_result_of_unchanged',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_result_stable_nf',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_cut',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_eq_plain',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParams_eq_plain',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_helper_result',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_helper_result',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_helper_result',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instListM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_correct',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_from_prefix',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_from_prefix',
                              'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_from_prefix'],
 'KernelCachedLiteralForward': ['ADWH.Experiments.Chapter15.KernelCachedLiteralForward.pure_head_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.pure_full_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.stable_head_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.stable_full_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.head_body_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.full_loop_nat_of_head',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.cached_head_nat',
                                'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.cached_full_nat'],
 'KernelCachedHelperFrame': ['ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_pure',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_throw',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_bind',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modifyGet',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modify',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instLevelParamsM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedTyIdxM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedValIdxM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instListM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constTyAtM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constValAtM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.ruleRhsAtM_preserves',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.helper_result_with_auxiliary',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.helper_result_stable_with_auxiliary',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.restCaches_helper_frame',
                             'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.restCaches_memo_frame'],
 'KernelCachedRecordWrapper': ['ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.true_defeq_empty',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.true_defeq_insert',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.working_empty',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.working_after_rest',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.working_insert_cheap',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.working_insert_defeq',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_forward_of_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_same_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_same',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.cheap_forward_of_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.cheap_nat',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.cheap_const',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.no_iota_of_no_recursor',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.whnf_spine_no_recursor',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.cheap_application_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.cheap_application',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.add_not_recursor',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.eq_not_recursor',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.full_nat_with_rest',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.prop_irrel_literal',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.offset_literal_add',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.reduce_add_zero',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.lazy_literal_add',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_literal_add_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_literal_add',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.eq_not_proof',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.prop_irrel_eq',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.eq_not_unfoldable',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.lazy_eq',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.eq_argument_list',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.stuck_eq',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.defeq_eq_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.eq_refl_type_defeq',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.infer_nat_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.infer_const_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.infer_application_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.infer_spine_done',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.infer_spine_forall',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.annotate_const_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.annotate_nat_body',
                               'ADWH.Experiments.Chapter15.KernelCachedRecordWrapper.annotate_application_body']}
RAW_REQUIRED = {'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero'],
 'KernelCachedForward': ['succeeds_pure',
                         'succeeds_modifyGet',
                         'succeeds_modify',
                         'succeeds_bind',
                         'memoEI_hit',
                         'memoEI_miss',
                         'whnf_hit',
                         'whnf_miss',
                         'whnf_zero',
                         'whnfCore_hit',
                         'whnfCore_miss',
                         'instListM_succeeds',
                         'instLevelParamsM_succeeds',
                         'storedTyIdxM_succeeds',
                         'storedValIdxM_succeeds',
                         'constTyAtM_succeeds',
                         'constValAtM_succeeds',
                         'ruleRhsAtM_succeeds',
                         'iotaCertsIAux_never',
                         'iotaCertsI_never',
                         'defEqListI_empty',
                         'iotaIndexOkI_noIndices',
                         'whnfAppI_never',
                         'betaPeelI_never',
                         'betaPeelI_done'],
 'KernelCachedStableForward': ['stable_run_of_unscoped',
                               'stable_whnf_of_runs_above',
                               'stable_head_of_runs_above',
                               'stable_run_has_one_fuel',
                               'stable_run_unique',
                               'stable_map_empty',
                               'stable_map_insert',
                               'stable_nf_empty',
                               'stable_nf_frame',
                               'stable_nf_insert_whnf',
                               'stable_nf_insert_head',
                               'whnf_cache_value',
                               'head_cache_value',
                               'stable_nf_flushed',
                               'flushed_whnf_miss',
                               'flushed_head_miss',
                               'flush_starts_unseeded',
                               'true_memo_frame',
                               'whnf_forward_of_body',
                               'head_forward_of_body'],
 'KernelCachedHelperDirect': ['map_backed_empty',
                              'map_backed_insert',
                              'ienv_tags_empty',
                              'helper_cache_empty',
                              'helper_cache_frame',
                              'helper_cache_memo_frame',
                              'helper_cache_flushed',
                              'helper_result_of_unchanged',
                              'helper_result_stable_nf',
                              'instantiateListC_cut',
                              'instantiateListC_eq_plain',
                              'instLevelParams_eq_plain',
                              'instLevelParamsM_correct',
                              'storedTyIdxM_correct',
                              'storedValIdxM_correct',
                              'instLevelParamsM_helper_result',
                              'storedTyIdxM_helper_result',
                              'storedValIdxM_helper_result',
                              'instListM_correct',
                              'constTyAtM_correct',
                              'constValAtM_correct',
                              'ruleRhsAtM_correct',
                              'constTyAtM_from_prefix',
                              'constValAtM_from_prefix',
                              'ruleRhsAtM_from_prefix'],
 'KernelCachedLiteralForward': ['pure_head_nat',
                                'pure_full_nat',
                                'stable_head_nat',
                                'stable_full_nat',
                                'head_body_nat',
                                'full_loop_nat_of_head',
                                'cached_head_nat',
                                'cached_full_nat'],
 'KernelCachedHelperFrame': ['preserves_pure',
                             'preserves_throw',
                             'preserves_bind',
                             'preserves_modifyGet',
                             'preserves_modify',
                             'instLevelParamsM_preserves',
                             'storedTyIdxM_preserves',
                             'storedValIdxM_preserves',
                             'instListM_preserves',
                             'constTyAtM_preserves',
                             'constValAtM_preserves',
                             'ruleRhsAtM_preserves',
                             'helper_result_with_auxiliary',
                             'helper_result_stable_with_auxiliary',
                             'restCaches_helper_frame',
                             'restCaches_memo_frame'],
 'KernelCachedRecordWrapper': ['true_defeq_empty',
                               'true_defeq_insert',
                               'working_empty',
                               'working_after_rest',
                               'working_insert_cheap',
                               'working_insert_defeq',
                               'defeq_forward_of_body',
                               'defeq_same_body',
                               'defeq_same',
                               'cheap_forward_of_body',
                               'cheap_nat',
                               'cheap_const',
                               'no_iota_of_no_recursor',
                               'whnf_spine_no_recursor',
                               'cheap_application_body',
                               'cheap_application',
                               'add_not_recursor',
                               'eq_not_recursor',
                               'full_nat_with_rest',
                               'prop_irrel_literal',
                               'offset_literal_add',
                               'reduce_add_zero',
                               'lazy_literal_add',
                               'defeq_literal_add_body',
                               'defeq_literal_add',
                               'eq_not_proof',
                               'prop_irrel_eq',
                               'eq_not_unfoldable',
                               'lazy_eq',
                               'eq_argument_list',
                               'stuck_eq',
                               'defeq_eq_body',
                               'eq_refl_type_defeq',
                               'infer_nat_body',
                               'infer_const_body',
                               'infer_application_body',
                               'infer_spine_done',
                               'infer_spine_forall',
                               'annotate_const_body',
                               'annotate_nat_body',
                               'annotate_application_body']}
WRAPPER_SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean',
  297742,
  '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648'),
 ('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCachedForward.lean',
  207542,
  '126c0ceafb7e354723812c42f1ccff52e73004d80b194e4dcf35796c8073ab2e'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean',
  6239,
  'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325'),
 ('next-iteration/kernel-cached-helper-frame/source/KernelCachedHelperFrame.lean',
  11880,
  '4fd43799ca834ab45dca23d23b89cba1ad9ea2c10cdf6286863f52680c36efdc'),
 ('next-iteration/kernel-cached-record-wrapper-proof-robustness/source/KernelCachedRecordWrapper.lean',
  40501,
  '25fd836ae854920b375a07c8f6eaee4708f21abe4a7a338f65cbec132b04535d')]


HISTORICAL_REVIEW_KEYS = ['reviewed_direct_inputs',
 'reviewed_correction_inputs',
 'reviewed_stable_inputs',
 'reviewed_stable_correction_inputs',
 'reviewed_helper_inputs',
 'reviewed_diagnosed_helper_inputs',
 'new_separate_review_scopes',
 'new_separate_author_inventory_scopes',
 'cost_separate_review_scopes',
 'cost_separate_author_inventory_scopes',
 'omission_separate_review_scope',
 'omission_separate_author_inventory_scope',
 'comment_repair_separate_review_scope',
 'comment_repair_separate_author_inventory_scope',
 'syntax_haslp_separate_review_scope',
 'syntax_haslp_separate_author_inventory_scope']
HISTORICAL_SELECTION_KEYS = ['module_order',
 'sources',
 'source_fingerprint',
 'source_fingerprint_scope',
 'ordered_report_counts',
 'selected_physical_source_bytes',
 'origin_ownership',
 'source_segment_ownership',
 'logical_origins',
 'complete_origin_source_rows',
 'distinct_upstream_origin_count',
 'distinct_project_origin_count',
 'distinct_logical_origin_count',
 'source_segment_count',
 'inherited_omissions',
 'separate_selected_source_layers']
REPAIR_AUTHOR_INPUT_COUNT = 333
REPAIR_REVIEW_INPUT_COUNT = 15
WRAPPER_FIXED = {**HISTORICAL_FIXED,
    ROOT / 'next-iteration/kernel-cached-helper-frame/AUTHOR-REVIEW.md': 'f0eef12a5b20e953178224e88ecd9b0ba42e2256fe5b4de6d28c9f98ca0690d4',
    ROOT / 'next-iteration/kernel-cached-helper-frame/PLAN.md': '7865867ee19f7b6233e33b34630e67e60500cd2f49c8bed3ad673bf27e4f4598',
    ROOT / 'next-iteration/kernel-cached-helper-frame/PRIMARY-SOURCE-INTERVALS.json': 'f7a363bf5a2dc663fc2c31a2a51eb5da31c1225a2a2c43458cb05ed65e474d08',
    ROOT / 'next-iteration/kernel-cached-helper-frame/SOURCE-AUDIT.json': '56a995ba571cb1b8fa3d79200e17e2a0ccbcf0476b261796ec0b6e98b739355a',
    ROOT / 'next-iteration/kernel-cached-helper-frame/SOURCE-INVENTORY.json': '36620cba3ea0d7641899fe870be3167f96bae3dd4717d9ecbfdec8e4068094b9',
    ROOT / 'next-iteration/kernel-cached-helper-frame/SOURCE-REVIEW.md': '6a0f015c6cfe452949a9544b49db543f9a89352e45c468f8c8e563c2f31959e2',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/AUTHOR-REVIEW.md': 'f9b86be3ca488613aa37936e7dc88d01f1895c80d9e4528519eb2f13628ab0e1',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/PLAN.md': '933df78ef400679fd527c33c9e30ba2ab9b00f7c29dd54ab9737281b74fa93f2',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/PRIMARY-SOURCE-INTERVALS.json': '1021dd4d1d9ac4957556bd4632151d0e799d4eb54a6aefd752b6c1d49b4a380f',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/SOURCE-AUDIT.json': '6fa57f2a28e439c6a780d79b93e9d48c785bfd7e8f4cb110fdbe5a6641341011',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/SOURCE-CENSUS.json': 'bd58243ae6b2f4f2ada0a3669fc95c6164470b5bbea1b6779f5a5441a9bf3802',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/SOURCE-INVENTORY.json': 'f27256ea3ab4420b2b2a7e03a2db3692c9c17ab527b5d78c77db46cb34e9b3b0',
    ROOT / 'next-iteration/kernel-cached-record-wrapper/SOURCE-REVIEW.md': 'a375219cee4340cdd923acd2c454e613a19142eeb1e7d214ae7c9642313622ee',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/AUTHOR-REVIEW.md': '01838386d960a869861a6dd681171e3b081f8b24d3e9753d96318d9aa71af8b9',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/PLAN.md': '83855d0f278ab3b88f7f8d81f41ada998549d0de96674dda99a85d40cada351d',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/PROOF-CORRECTION.json': 'a357398d60990e3ea3f3a6c659b2acf48f16412b9f9da226cf98b020c9a11e3b',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-AUDIT.json': '977991f7ead3c8e060b59b3bd2bf3654639e9e6f0f08c1b1021a162b8c1bd118',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-INVENTORY.json': 'eb3d52bbd378f33e199977c72c047847ee6de46a11f653dd9aadcc96609e84f2',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-REVIEW.md': '741e14d22aeadb9cd9f9bc14348abefbf3b7483de7b35d0d6d92194d0fa31d5c',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/run_gate.py': '46d2514051f9f16430e9053801d834d0701207396ebddf487db805e6c8d64740',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/source-manifest.json': '01029b15cd065a4138c044dc814597052c9b45942e6ab937c48ee9092d9f325f',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/PROTOCOL.md': 'c496f12532a1ca31651d1efef5c9cec2f6b8fa2cf012f9da397c34c77cb80b07',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/AUTHORING.md': 'e649e932a7dffa622a9324b826fddb54d2b418e58ad39d9a3615548ebbf3bf83',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/CONTROL-CORRESPONDENCE.json': '43e6126af6c1dac7764ddde0efd68684944402734c72cea9ea45b17bb8ff2746',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': '1334b77763cb95b7890ad89f4208cf9c5f4b42a0f6e37985d849f5045d0317a1',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/SNAPSHOT-RECOVERY.json': 'c826e783d52da1f538123b8214baef58eede14fdc8173db7d613e46eb87b4be7',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/RESULT-AND-NEXT.md': 'c13f8e2f0d34a4132446e74f4557eead2184cbd7ee5d8bd5413b478c6928f596',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/report.json': '35441bb778bba6744b34678a176f4800643f30edebb5f5b916abb51089dc09fc',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/execution-markers/complete-a3553975ea502e13ffc11acd48dc4717fafc4e81d1478f977d1fff33e9a578f6.json': 'c866fe85d5d89eb6b821eb91bb4da6d09a92ee55e1ef627d60479987fc27cf98',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedBulkBound.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedBulkBound.stdout.log': '489a0dec3bc393816b17a94a3496c3daac623422b8dd5bd08864f963b69a27ab',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'cb50063fd9407935f77e12332af0e808bba78dab210d3a2d9d549191d743820e',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
}

# The previous Wrapper136 metadata is preserved at its consumed source identity.
WRAPPER_HERE = ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate'
WRAPPER_MANIFEST = WRAPPER_HERE / 'source-manifest.json'
WRAPPER_MANIFEST_FORMAT = 'adwh-kernel-cached-record-wrapper-136-manifest-v1'
BOOLEAN_LITERAL_PREDECESSOR = WRAPPER_HERE
BOOLEAN_REWRITE = ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites'
LITERAL_REPAIR = ROOT / 'next-iteration/kernel-cached-literal-scope-repair'
BOOLEAN_LITERAL_MANIFEST_FORMAT = 'adwh-kernel-cached-boolean-literal-136-manifest-v1'
BOOLEAN_LITERAL_SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean',
  297742,
  '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648'),
 ('next-iteration/kernel-cached-boolean-proof-rewrites/source/KernelCachedForward.lean',
  210150,
  '285b257310da159cd60570a33eac6b5a5396a234b3a7c166762062c381e45565'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-literal-scope-repair/source/KernelCachedLiteralForward.lean',
  6331,
  '26e0a7166ff9656cc6cb737f257ae9335cf93883f9b97b98f029da8c364ebdd0'),
 ('next-iteration/kernel-cached-helper-frame/source/KernelCachedHelperFrame.lean',
  11880,
  '4fd43799ca834ab45dca23d23b89cba1ad9ea2c10cdf6286863f52680c36efdc'),
 ('next-iteration/kernel-cached-record-wrapper-proof-robustness/source/KernelCachedRecordWrapper.lean',
  40501,
  '25fd836ae854920b375a07c8f6eaee4708f21abe4a7a338f65cbec132b04535d')]

WRAPPER_REVIEW_KEYS = ['historical_complete120_review_context',
 'historical_independent_review_scope_count',
 'current_total_separate_independent_review_scope_count',
 'historical_reviews_rebased',
 'current_separate_review_scopes',
 'current_separate_author_inventory_scopes',
 'original_wrapper_review_rebased_to_overlay',
 'frame_historical_selection_rebased_to_current_owners']
WRAPPER_SELECTION_KEYS = ['historical_complete120_selection_context',
 'module_order',
 'sources',
 'source_fingerprint',
 'source_fingerprint_scope',
 'ordered_report_counts',
 'selected_physical_source_bytes',
 'logical_origins',
 'origin_ownership',
 'source_segment_ownership',
 'complete_origin_source_rows',
 'distinct_upstream_origin_count',
 'distinct_project_origin_count',
 'distinct_logical_origin_count',
 'source_segment_count',
 'current_mathematical_leaf_selection',
 'historical_Syntax_Bulk_sources_are_context_only',
 'preserved_consumed_SyntaxHasLP120_predecessor',
 'separate_preexecution_metadata_repair']
BOOLEAN_REVIEW_STATUS = 'passed_source_only_no_compilation_or_measured_cost_claim'
LITERAL_REVIEW_STATUS = 'passed_source_only_not_compiled'
LITERAL_REVIEW_INPUT_COUNT = 48
BOOLEAN_LITERAL_FIXED = {**WRAPPER_FIXED,
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/AUTHOR-REVIEW.md': '64e8d345f0df4efe87dc7aaff6cf6c2d29b62e8ccd9bdeb9396b01832930909e',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/METADATA-WORDING-CORRECTION.json': 'af80755c321692264118d44bd03804bbe17821e5205fb84d39583bc0459c28bf',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/PLAN.md': '49961d8006733f914a72b27d7f0cdc473fc97f1771679e0a7618825330104f2c',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/PRIMARY-SOURCE-INTERVALS.json': '7223f1d833785c0796ecadf762ad9819b97b0e927afa8ae849f106000a5f52bd',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/PROOF-OVERLAY.json': 'a8a294b9bbaadba9be642eb0cfb53f07ef19610a6c928dd76a482bbabdfc4309',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-AUDIT.json': '6675b4e5f6c504663827d3d0a8d43cf3c2ee38bda4106495167bad8e2f9aef65',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-CORRESPONDENCE.json': 'c75e3a90151b3d940d0840a6e8097be01c04ea60798490aca6540242fed63bdf',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-GRAMMAR-CORRECTION.json': 'a336a072f7e6be6d7994db62e4c5b80d256d51e2ce6e93caa83087a48ddf83dc',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-INVENTORY.json': 'dd95f167c1d2a2ebb6a7dbabfc79c99397870d4cf19f29f8a4470ac8b2776257',
    ROOT / 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-REVIEW.md': 'a0944f09943f273a180ef83076f0e3dbdbe650d136fdcfcaa7ecc7f5cc74d04c',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/AUTHOR-REVIEW.md': '114df06fe67f32bc529022651a056bd16805c2e1d38b9f05c54e9c1b45fc2bec',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/PLAN.md': '77a8979c534f9abef9cf449a9d5cf7dcdadced1532647d6c86c920ef0a4b6383',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/PRIMARY-SOURCE-INTERVALS.json': 'ed719b324b6210f492069b41538be54051df7cbcf9ae6417d34725228ab9ab60',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/PROOF-CORRECTION.json': 'f01a5e2587e9ff0c6fa8ef331ee93392e69ff6a629b52dca2f2234b73bd5d1d6',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-AUDIT.json': '20a539c2b210f89a6d3e47801f97b868bc1fa0e1cd77dd83bc9afd696abdcb60',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-INVENTORY.json': '56efa01bf13c1b4f313066b543f9be43ed6a87040d96e40f4431af7059377b61',
    ROOT / 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-REVIEW.md': '071082c79d6cbd2695b0e7f37b329faf6d95f7b4bbeb15aa48eb85c5b6b44813',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/AUTHORING.md': '459cb3c5b9d63d833e613ba21959510c501e151157cf230388c649eb97dcc563',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/CONTROL-CORRESPONDENCE.json': '2f62e3321e8db404cdbc776b1ee19f49d8d102c6050302d97bf486eccd8f0df4',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/INDEPENDENT-CONTROL-REVIEW.md': 'ac5f50c0f0755ec2f3ef740e8e8859c07a64990d025cb32af90345b8c9b05f22',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/METADATA-REPAIR.json': 'd3694d2e2e1fc6a5e50711b83a39f3b10942b6516626cbc1e050cbb9cb6f6a24',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/PROTOCOL.md': '37bcc195a1ebc9773db2fadce7dadc93658436629040c4b06abf90fdb1f5add7',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/RESULT-AND-NEXT.md': '97379e8b6d5402068dd79663b10eb21714de0165d981c7b00e547671a78c1073',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/ROOT-EXECUTION-RECEIPT.json': 'c527e77954eef769b43bd072ab3116135dd8f53daaaf3c8b0ad0b8ab061e7388',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/SNAPSHOT-RECOVERY.json': 'f3e8a815b466b9cc2137861d5c16f8fec6d48acd1a07db0829fd5900bf27f4eb',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': '76820b17ab6fe4f63badd154565cbf6b9eb240a865a421b6f5873ec86361f477',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/report.json': 'aa7d43fc7174f6e2294c7fc95143c6d58f28338c264e8ad1aa962321aba57f60',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/execution-markers/complete-6ffb699dd88cf34e0ac1a3ca5d2702c14bad45ec2c24b743f5f67dde984b3e02.json': '0f28ee05ccbba907e61f3c06a0c4f1e6bd9626b1037bca1bf2285c7b337b4cd4',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/run_gate.py': 'ada305e8494c6bf3bf178d4d69bd630f02f12ab7c25e7de64c19dc558eab077a',
    ROOT / 'next-iteration/kernel-cached-record-wrapper-136/gate/source-manifest.json': '050fa169f344a66fcfd486b57460179ed95722cd8b2e616c709e799ebcc07739',
}
# Q remains at its consumed source identity; only the next current selection changes.
BOOLEAN_LITERAL_HERE = ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate'
BOOLEAN_LITERAL_MANIFEST = BOOLEAN_LITERAL_HERE / 'source-manifest.json'
TERMINAL_PREDECESSOR = BOOLEAN_LITERAL_HERE
TERMINAL_REPAIR = ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair'
MANIFEST_FORMAT = 'adwh-kernel-cached-boolean-terminal-136-manifest-v1'
SOURCE_PINS = [('next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean',
  297742,
  '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648'),
 ('next-iteration/kernel-cached-boolean-terminal-repair/source/KernelCachedForward.lean',
  211978,
  '9106a2d9b63f90a0fdcabe5d2c9e8cf6205d01eefeee11eb666b4b008bc59661'),
 ('next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean',
  14667,
  'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b'),
 ('next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean',
  23406,
  '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72'),
 ('next-iteration/kernel-cached-literal-scope-repair/source/KernelCachedLiteralForward.lean',
  6331,
  '26e0a7166ff9656cc6cb737f257ae9335cf93883f9b97b98f029da8c364ebdd0'),
 ('next-iteration/kernel-cached-helper-frame/source/KernelCachedHelperFrame.lean',
  11880,
  '4fd43799ca834ab45dca23d23b89cba1ad9ea2c10cdf6286863f52680c36efdc'),
 ('next-iteration/kernel-cached-record-wrapper-proof-robustness/source/KernelCachedRecordWrapper.lean',
  40501,
  '25fd836ae854920b375a07c8f6eaee4708f21abe4a7a338f65cbec132b04535d')]

TERMINAL_REVIEW_KEYS = ['preserved_Wrapper136_review_context',
 'historical_independent_review_scope_count',
 'current_total_separate_independent_review_scope_count',
 'historical_reviews_rebased',
 'current_separate_review_scopes',
 'current_separate_author_inventory_scopes']
TERMINAL_SELECTION_KEYS = ['preserved_Wrapper136_selection_context',
 'module_order',
 'sources',
 'source_fingerprint',
 'source_fingerprint_scope',
 'ordered_report_counts',
 'selected_physical_source_bytes',
 'logical_origins',
 'origin_ownership',
 'source_segment_ownership',
 'complete_origin_source_rows',
 'distinct_upstream_origin_count',
 'distinct_project_origin_count',
 'distinct_logical_origin_count',
 'source_segment_count',
 'separate_Boolean32_proof_overlay',
 'separate_native_ordinary_Boolean_correspondence',
 'separate_preserved_Boolean_draft_grammar_correction',
 'separate_Literal2_proof_overlay',
 'current_mathematical_leaf_selection',
 'historical_Syntax_Bulk_sources_are_context_only',
 'preserved_consumed_Wrapper136_predecessor']
FIXED = {**BOOLEAN_LITERAL_FIXED,
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/AUTHORING.md': '4fda4eebd547a9474f00eb3a1ab5dbcdb01c39b55d32e3a9a3e33480c7ddcc3a',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/CONTROL-CORRESPONDENCE.json': 'e5229b1fcfbb758f08c1c19fa3b93ce2a48f858802c901083b09aa9b3ff169af',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/INDEPENDENT-CONTROL-REVIEW.md': '483adac5a272805b0695769efbf12e6ecc0b2dcc3a2621626cbdf0d2844fd2d9',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/PROTOCOL.md': '3f3f781d2fb17964f19b50e332e1e09e121c0827a023e17e20e923c3bb3391a1',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/RESULT-AND-NEXT.md': '1dce88c6d7aa3c5191eccad1de415f20183dc3138f00137fb89230c8f3ddd085',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/ROOT-EXECUTION-RECEIPT.json': '9c72fd22e86a67124326da2037e97dd436b489fc6924972b44321812c8cf722e',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/SNAPSHOT-RECOVERY.json': '9ef0650de52c04d5b7a80067ab3847a820091e13edfbc78be1ef5f19aabc59dd',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCachedForward.stdout.log': 'ac28d97511a31dbfcb5ff0a63882eb3028095650004f77615b4d4726d5783e64',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/report.json': 'b4fa5cd51387815e38c44912d66b83ef7b29f5640a7cabd98303188c82a182c6',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/execution-markers/complete-de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a.json': 'af48791e353f03b883c2a2d684bab440d86be9dc0c28697767bc1fb52967869d',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/run_gate.py': '453a823c3aa11fc6678933fc1dd315dde4e46d2b6771b778b463a428acc54b6f',
    ROOT / 'next-iteration/kernel-cached-boolean-literal-136/gate/source-manifest.json': 'd6f9067cc7edc35492dff33e7a3812065b8c3c1bf0aaa8c4c11ee55b8772edeb',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/AUTHOR-REVIEW.md': 'baa9a3724ea8e771b306f39870445ee6aa8cd79afd195348242ba3b6f6107bd7',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/DIAGNOSTIC-CORRESPONDENCE.json': 'd4900f568677fcf29f3c9e68452a7197142d68f64a4a330a38dd8337247d66b1',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/PLAN.md': '41737283bd1d368abcfe43d05b05483dd9f981c709c5e3f763c61d474a78d1d0',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/PRIMARY-SOURCE-INTERVALS.json': '1416403feafb2b02b23f45f5cdcb03c00e7df6b4c782d748da353dd8614094f4',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/PROOF-CORRECTION.json': '698a799d3bb9f5c884e4b78a5173de5bdc3c1d1ed3f25c547a44ac4a0f0d9b21',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-AUDIT.json': '32f1e627ac984c34fee0dec79baa2e931e7bac9c4830f3ae0d6b900194217f5b',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-CORRESPONDENCE.json': '09288e8f7d53d18b411f088877a4f297f986805c0f600417d07f55c94c809508',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-INVENTORY.json': '72122aedbcf3a18a78304a21bd785f921b74a0214fc7b6db58d189a95a6e9d9e',
    ROOT / 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-REVIEW.md': 'f042d7891a6e1d4778f1309bfcf8150fb19cc7f1048707b80748e93441ea3c9d',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def local_path(name):
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name,
            'Nonlocal input path: ' + name)
    path = ROOT.joinpath(*rel.parts)
    require(path.resolve().is_relative_to(ROOT), 'Escaping input path: ' + name)
    require(path.is_file() and not path.is_symlink(), 'Missing ordinary input: ' + name)
    return path


def identity(row, h):
    path = local_path(row['path'])
    actual = h.binding(path)
    require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
            'Input identity differs: ' + row['path'])
    return actual


def verify(rows, readonly=False):
    for row in rows:
        path = Path(row['path'])
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
                and sha(path) == row['sha256'], 'Input/output identity differs: ' + str(path))
        if readonly:
            require(path.stat().st_mode & 0o222 == 0, 'Writable frozen evidence: ' + str(path))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fingerprint(sources):
    # A control/metadata edit or attempt rename does not reset a consumed source key.
    body = {'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
            'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def imports(code):
    return [name for group in re.findall(
        r'^\s*(?:(?:public|private|meta)\s+)*import[ \t]+(?:all[ \t]+)?([^\n]+)', code, re.M)
        for name in group.split()]


def check_source(row, guard):
    module = row['module']
    path = local_path(row['path'])
    code = guard.check_lean_source(path, path.read_text())
    require(imports(code) == row['imports'], 'Physical import census: ' + module)
    require(not re.search(r'^\s*module\s*$', code, re.M), 'Unexpected module format: ' + module)
    options = ([('linter.unusedSimpArgs', 'false')] * 2 if module == HISTORICAL_MODULES[0] else
               [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]
               * (3 if module == HISTORICAL_MODULES[1] else 1))
    require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)', code) == options,
            'Source option or resource override: ' + module)
    require(not re.search(r'^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b', code, re.M),
            'Executable elaborator command: ' + module)
    require(re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
            == row['raw_source_print_identifiers'], 'Ordered source reports: ' + module)
    require(not re.search(r'^\s*(?:public\b|meta\s+import|import\s+all)|@\[(?:expose|no_expose)\]', code, re.M),
            'Unsupported legacy visibility command: ' + module)


def apply_edits(original, edits, offset_key, before_key, after_key):
    output, cursor = bytearray(), 0
    for edit in edits:
        start = edit[offset_key]
        before, after = edit[before_key].encode(), edit[after_key].encode()
        require(type(start) is int and cursor <= start <= len(original), 'Overlapping or invalid edit')
        require(original[start:start + len(before)] == before, 'Recorded edit does not match source')
        output.extend(original[cursor:start])
        output.extend(after)
        cursor = start + len(before)
    output.extend(original[cursor:])
    return bytes(output)


def verify_correspondence(mapping, h):
    historical = read(ROOT / 'next-iteration/kernel-sliced-selector/SOURCE-BUNDLE.json')
    unit = historical['physical_units'][0]
    require(unit['module'] == HISTORICAL_MODULES[0] and len(unit['origin_units']) == 21,
            'Inherited Core origin census')
    identity(unit['source'], h)
    assembled = bytearray(unit['bundle_header'].encode())
    for origin in unit['origin_units']:
        identity(origin['original'], h)
        raw = local_path(origin['original']['path']).read_bytes()
        body = apply_edits(raw, origin['edits'], 'original_offset', 'original_text', 'replacement_text')
        assembled.extend(origin['prefix_text'].encode())
        require(len(assembled) == origin['bundle_body_start_byte']
                and len(body) == origin['bundle_body_bytes']
                and hashlib.sha256(body).hexdigest() == origin['bundle_body_sha256'], 'Inherited origin span')
        assembled.extend(body)
        assembled.extend(origin['suffix_text'].encode())
    require(bytes(assembled) == local_path(unit['source']['path']).read_bytes(), 'Inherited Core assembly')
    overlays = []
    for component, count in [('kernel-legacy-core-selector', 24), ('kernel-ordinary-fields-core', 4)]:
        overlay = read(ROOT / f'next-iteration/{component}/SOURCE-CORRESPONDENCE.json')
        identity(overlay['original_source'], h)
        identity(overlay['candidate_source'], h)
        original = local_path(overlay['original_source']['path']).read_bytes()
        candidate = local_path(overlay['candidate_source']['path']).read_bytes()
        require(overlay['edit_count'] == len(overlay['edits']) == count, 'Inherited overlay edit count')
        require(apply_edits(original, overlay['edits'], 'original_start_byte', 'before', 'after') == candidate
                and apply_edits(candidate, overlay['edits'], 'candidate_start_byte', 'after', 'before') == original,
                'Inherited overlay forward/inverse: ' + component)
        overlays.append({'component': component, 'edits': count, 'exact_forward_and_inverse': True})
    current = mapping['physical_units'][1]
    identity(current['selected_source'], h)
    complete = local_path(current['selected_source']['path']).read_bytes()
    assembled = bytearray(current['bundle_header'].encode())
    segments = []
    for origin in current['source_segments']:
        if origin['kind'] == 'exact_supplemental_slice':
            identity(origin['full_origin_input'], h)
            original = local_path(origin['full_origin_input']['path']).read_bytes()
            first, stop = origin['upstream_original_start_byte'], origin['upstream_original_end_byte_exclusive']
            require(type(first) is int and type(stop) is int and 0 <= first <= stop <= len(original),
                    'Supplement source interval')
            body = original[first:stop]
            require(not origin['edits'] and body == origin['source_text'].encode()
                    and len(body) == origin['source_slice_bytes']
                    and hashlib.sha256(body).hexdigest() == origin['source_slice_sha256'],
                    'Supplement is not the exact original source interval')
        else:
            require(origin['kind'] in ('full_upstream_unit', 'full_project_unit'), 'Unknown source segment')
            identity(origin['original'], h)
            original = local_path(origin['original']['path']).read_bytes()
            body = apply_edits(original, origin['edits'], 'original_offset', 'original_text', 'replacement_text')
            require(apply_edits(body, origin['edits'], 'transformed_offset', 'replacement_text', 'original_text')
                    == original, 'Full new origin inverse')
        require(len(assembled) == origin['bundle_prefix_start_byte'], 'New origin prefix offset')
        assembled.extend(origin['prefix_text'].encode())
        require(len(assembled) == origin['bundle_body_start_byte']
                and len(body) == origin['bundle_body_bytes']
                and hashlib.sha256(body).hexdigest() == origin['bundle_body_sha256'], 'New origin body span')
        assembled.extend(body)
        assembled.extend(origin['suffix_text'].encode())
        segments.append({'owner': origin['module'], 'kind': origin['kind'], 'exact_source_correspondence': True})
    require(bytes(assembled) == complete, 'Complete cached assembly reconstruction')
    require(len(segments) == 9 and sum(x['kind'] == 'exact_supplemental_slice' for x in segments) == 2
            and sum(x['kind'] == 'full_upstream_unit' for x in segments) == 5
            and sum(x['kind'] == 'full_project_unit' for x in segments) == 2,
            'New segment census')
    return {'inherited_Core_origins': 21, 'inherited_Core_literal_reconstruction': True,
            'separate_Core_overlays': overlays, 'new_source_segments': segments,
            'new_physical_source_literal_reconstruction': True,
            'historical_reviews_rebased': False, 'elaborated_API_equivalence_asserted': False}


def verify_proof_correction(correction, h):
    require(correction['author'] == 'root' and len(correction['corrections']) == 3,
            'Correction authorship/source scope')
    outcomes = []
    for row, expected in zip(correction['corrections'], [2, 4, 6]):
        identity(row['original'], h)
        identity(row['candidate'], h)
        original = local_path(row['original']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        edits = row['exact_source_edits']
        require(row['edit_count'] == len(edits) == expected, 'Proof-correction edit count')
        require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
                == candidate, 'Complete proof-correction forward reconstruction')
        reverse, delta = [], 0
        for edit in edits:
            before, after = edit['original_text'], edit['replacement_text']
            reverse.append({'offset': edit['original_start_byte'] + delta,
                            'before': after, 'after': before})
            delta += len(after.encode()) - len(before.encode())
        require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
                'Complete proof-correction inverse')
        outcomes.append({'original': row['original'], 'candidate': row['candidate'],
                         'edit_count': expected, 'exact_forward_and_inverse': True})
    return {'logical_and_physical_source_overlays': outcomes,
            'historical_source_review_rebased': False,
            'theorem_header_changes': correction['theorem_header_changes']}


def verify_leaf_corrections(stable_correction, helper_correction, h):
    outcomes = []
    for label, correction, author, field, expected in [
            ('stable', stable_correction, 'root', 'edits', 13),
            ('helper', helper_correction, 'reflection_evidence_review', 'exact_source_edits', 2)]:
        require(correction['author'] == author, 'Leaf correction author: ' + label)
        identity(correction['original'], h)
        identity(correction['candidate'], h)
        original = local_path(correction['original']['path']).read_bytes()
        candidate = local_path(correction['candidate']['path']).read_bytes()
        edits = correction[field]
        require(correction['edit_count'] == len(edits) == expected, 'Leaf correction count: ' + label)
        require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
                == candidate, 'Leaf correction forward: ' + label)
        reverse, delta = [], 0
        for edit in edits:
            before, after = edit['original_text'], edit['replacement_text']
            reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
            delta += len(after.encode()) - len(before.encode())
        require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
                'Leaf correction inverse: ' + label)
        outcomes.append({'component': label, 'original': correction['original'],
                         'candidate': correction['candidate'], 'edit_count': expected,
                         'exact_forward_and_inverse': True})
    copies = []
    for row in helper_correction['preserved_unselected_draft']:
        copy = identity(row['preserved_copy'], h)
        require(all(copy[key] == row['original'][key] for key in ('bytes', 'sha256')),
                'Unselected draft copy differs from its historical source identity')
        copies.append(row['preserved_copy'])
    return {'separate_leaf_overlays': outcomes, 'preserved_unselected_helper_draft': copies,
            'historical_reviews_rebased': False}


def verify_diagnosed_helper_repair(repair, h):
    require(repair['author'] == 'reflection_evidence_review'
            and repair['edit_count'] == len(repair['exact_source_edits']) == 16,
            'Diagnosed Helper repair authorship/edit scope')
    identity(repair['original'], h)
    identity(repair['candidate'], h)
    original = local_path(repair['original']['path']).read_bytes()
    candidate = local_path(repair['candidate']['path']).read_bytes()
    edits = repair['exact_source_edits']
    require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
            == candidate, 'Diagnosed Helper forward reconstruction')
    reverse, delta = [], 0
    for edit in edits:
        before, after = edit['original_text'], edit['replacement_text']
        reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
        delta += len(after.encode()) - len(before.encode())
    require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
            'Diagnosed Helper inverse reconstruction')
    headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
    roots = lambda data: re.findall(r'^#print axioms (\S+)$', data.decode(), re.M)
    require(len(headers(original)) == len(headers(candidate)) == 26
            and headers(original) == headers(candidate)
            and roots(original) == roots(candidate) == HELPER_ROOT_NAMES,
            'Diagnosed Helper theorem headers or reports differ')
    require(not re.search(r'\b(?:if_pos|if_neg|dif_pos|dif_neg)\b', candidate.decode()),
            'Diagnosed Helper still uses a deprecated conditional alias')
    return {'original': repair['original'], 'candidate': repair['candidate'],
            'edit_count': 16, 'exact_forward_and_inverse': True,
            'unchanged_public_and_private_theorem_header_count': 26,
            'ordered_report_count': 25,
            'IEnvTags_explicit_types_are_only_definition_text_change': True,
            'equality_to_an_accepted_predecessor_IEnvTags_claimed': False,
            'historical_reviews_rebased': False}



def verify_recorded_overlay(row, expected, h, field='exact_source_edits'):
    identity(row['original'], h)
    identity(row['candidate'], h)
    original = local_path(row['original']['path']).read_bytes()
    candidate = local_path(row['candidate']['path']).read_bytes()
    edits = row[field]
    require(len(edits) == expected, 'Separate overlay edit census')
    require(apply_edits(original, edits, 'original_start_byte', 'original_text', 'replacement_text')
            == candidate, 'Separate overlay forward reconstruction')
    reverse, delta = [], 0
    for edit in edits:
        before, after = edit['original_text'], edit['replacement_text']
        reverse.append({'offset': edit['original_start_byte'] + delta, 'before': after, 'after': before})
        delta += len(after.encode()) - len(before.encode())
    require(apply_edits(candidate, reverse, 'offset', 'before', 'after') == original,
            'Separate overlay inverse reconstruction')
    return {'original': row['original'], 'candidate': row['candidate'],
            'edit_count': expected, 'exact_forward_and_inverse': True}


def verify_observer_syntax_overlay(overlay, h):
    require(overlay['author'] == 'reflection_evidence_review'
            and [r['label'] for r in overlay['source_variants']]
            == ['ordinary_core_observer_laws', 'syntax_metadata_cutoff'],
            'Observer/Syntax overlay identity')
    outcomes = [verify_recorded_overlay(row, count, h)
                for row, count in zip(overlay['source_variants'], [3, 2])]
    originals = [r['original'] for r in overlay['source_variants']]
    candidates = [r['candidate'] for r in overlay['source_variants']]
    require(candidates == [dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_120_SOURCE_PINS[n])) for n in (0, 4)],
            'Observer/Syntax historical owners differ')
    require(len(overlay['restored_exact_upstream_declarations']) == 2,
            'Observer restoration scope')
    for index, law in enumerate(overlay['restored_exact_upstream_declarations']):
        identity(law['source'], h)
        lines = local_path(law['source']['path']).read_text().splitlines(keepends=True)
        text = ''.join(lines[law['start_line'] - 1:law['end_line_inclusive']]).encode()
        require(text == law['text'].encode() and len(text) == law['bytes']
                and hashlib.sha256(text).hexdigest() == law['sha256']
                and text == overlay['source_variants'][0]['exact_source_edits'][index]['replacement_text'].encode(),
                'Restored observer is not the exact upstream law')
    headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
    syntax_old, syntax_new = [local_path(row['path']).read_bytes() for row in (originals[1], candidates[1])]
    require(headers(syntax_old) == headers(syntax_new) and len(headers(syntax_new)) == 31,
            'Syntax theorem interface census')
    require(overlay['new_core_public_axiom_report'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[0]][0]
            and overlay['core_executable_definitions_changed'] is False
            and overlay['external_private_representation_workaround_used'] is False
            and overlay['hasParams_never_restored'] is False, 'Observer scope boundary')
    return {'separate_source_overlays': outcomes, 'restored_exact_upstream_law_count': 2,
            'added_Core_public_simp_registration_count': 1,
            'added_Core_report_count': 1, 'Syntax_unchanged_theorem_header_count': 31,
            'effective_remaining_optional_PropWhen_proof_omissions': 34,
            'effective_remaining_optional_PropWhen_simp_omissions': 14,
            'historical_omission_maps_rebased': False,
            'historical_reviews_rebased': False}


def verify_cached_proof_sharing(overlay, correspondence, mapping, h):
    require(overlay['author'] == 'reflection_evidence_review'
            and [v['label'] for v in overlay['variants']]
            == ['physical_corrected_owner', 'full_logical_ExprOpsC'],
            'Cached proof-sharing variant identities')
    outcomes = [verify_recorded_overlay(row, count, h)
                for row, count in zip(overlay['variants'], [41, 40])]
    physical, logical = overlay['variants']
    require(physical['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[1]))
            and physical['original'] == correspondence['accepted_physical_baseline']
            and logical['original'] == correspondence['original_raw_upstream_source']
            and logical['candidate'] == correspondence['selected_full_logical_source'],
            'Cached proof-sharing source ownership')
    for row in overlay['variants']:
        kinds = Counter(e['kind'] for e in row['exact_source_edits'])
        require(kinds['constructor_subtype_proof_only'] == 36
                and kinds['termination_proof_search_order_only'] == 4
                and kinds['documentation_only'] == (1 if row is physical else 0)
                and sum(kinds.values()) == (41 if row is physical else 40),
                'Cached proof-only edit census')
        original, candidate = [local_path(row[k]['path']).read_text() for k in ('original', 'candidate')]
        headers = lambda text: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', text)
        require(headers(original) == headers(candidate)
                and re.findall(r'^\s*#print axioms \S+$', original, re.M)
                == re.findall(r'^\s*#print axioms \S+$', candidate, re.M),
                'Cached proof-sharing statement/report interfaces')
    inherited = next(s for s in mapping['physical_units'][1]['source_segments']
                     if s['module'] == 'ConLeche.Cached.ExprOpsC')
    edits = correspondence['unchanged_legacy_header_and_explicit_universe_edits']
    require(edits == inherited['edits'] and len(edits) == 5,
            'Cached full-origin header/visibility/universe edits changed')
    body = apply_edits(local_path(logical['candidate']['path']).read_bytes(), edits,
                       'original_offset', 'original_text', 'replacement_text')
    new = local_path(physical['candidate']['path']).read_bytes()
    prior = local_path(physical['original']['path']).read_bytes()
    first, stop = (correspondence['selected_full_origin_body_start_byte'],
                   correspondence['selected_full_origin_body_end_byte_exclusive'])
    prefix, suffix = correspondence['full_origin_prefix'].encode(), correspondence['full_origin_suffix'].encode()
    doc = correspondence['physical_variant_scope_prefix'].encode()
    prior_first = prior.index(prefix) + len(prefix)
    prior_stop = prior.index(suffix, prior_first)
    require(new[first:stop] == body and len(body) == correspondence['selected_full_origin_body_bytes']
            and hashlib.sha256(body).hexdigest() == correspondence['selected_full_origin_body_sha256']
            and new[first - len(prefix):first] == prefix and new[stop:stop + len(suffix)] == suffix
            and new.startswith(doc) and new[len(doc):first] == prior[:prior_first]
            and new[stop:] == prior[prior_stop:], 'Cached full-origin or complement correspondence')
    return {'separate_source_overlays': outcomes, 'complete_full_origin': 'ConLeche.Cached.ExprOpsC',
            'constructor_equality_certificate_edits': 36, 'termination_search_order_edits': 4,
            'new_declarations_or_reports': [], 'new_omissions': [],
            'complete_logical_to_physical_body_byte_exact': True,
            'physical_complement_unchanged_after_documentation_prefix': True,
            'no_compiler_equivalence_or_native_performance_claim': True,
            'historical_reviews_rebased': False}


def verify_bulk_and_literal_maps(bulk_map, boundary, literal_wording, h):
    identity(bulk_map['selected_source'], h)
    identity(boundary['original'], h)
    identity(boundary['candidate'], h)
    require(boundary['candidate'] == bulk_map['selected_source']
            == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_HASLP_SOURCE_PINS[5])),
            'Bulk selected source or comment boundary identity')
    selected = local_path(boundary['candidate']['path']).read_bytes()
    removed = selected
    for line in boundary['added_exact_comment_lines']:
        text = line.encode()
        require(removed.count(text) == 1, 'Bulk boundary line is not unique')
        removed = removed.replace(text, b'', 1)
    require(removed == local_path(boundary['original']['path']).read_bytes()
            and len(boundary['added_exact_comment_lines']) == 2,
            'Bulk comment-only boundary correction differs')
    segments = bulk_map['segments']
    require(len(segments) == 6, 'Bulk supplement slice census')
    for segment in segments:
        identity(segment['origin'], h)
        lines = local_path(segment['origin']['path']).read_text().splitlines(keepends=True)
        original = ''.join(lines[segment['start_line'] - 1:segment['end_line_inclusive']]).encode()
        body = segment['selected_text'].encode()
        require(original == segment['original_text'].encode() and len(original) == segment['original_bytes']
                and hashlib.sha256(original).hexdigest() == segment['original_sha256'],
                'Bulk exact original interval differs')
        first = segment['selected_start_byte']
        require(selected[first:first + len(body)] == body and len(body) == segment['selected_bytes']
                and hashlib.sha256(body).hexdigest() == segment['selected_sha256']
                and segment['byte_identical'] == (original == body),
                'Bulk selected interval/adaptation differs')
    require(bulk_map['required_axiom_reports'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[5]]
            and bulk_map['required_axiom_report_count'] == 30
            and bulk_map['no_existing_actual_definition_replaced'] is True,
            'Bulk roots or actual definition ownership')
    wording = dict(literal_wording)
    require(wording['author'] == 'root' and wording['edit_count'] == 1
            and wording['mathematical_source_tokens_changed'] is False
            and wording['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_HASLP_SOURCE_PINS[6])),
            'Literal comment-only review correction scope')
    wording['exact_source_edits'] = [{k: wording[k] for k in
                                    ('original_start_byte', 'original_text', 'replacement_text')}]
    literal_result = verify_recorded_overlay(wording, 1, h)
    return {'bulk_selected_source': bulk_map['selected_source'],
            'bulk_exact_upstream_intervals_checked': 6,
            'bulk_comment_opening_lines_restored': 2,
            'bulk_owning_Expr_and_ExprOps_supplements_not_duplicate_imports': True,
            'literal_comment_only_overlay': literal_result,
            'historical_reviews_rebased': False}



def verify_cost_overlays(presentation, census, count_overlay, historical, h, guard):
    require(presentation['author'] == count_overlay['author'] == 'reflection_evidence_review',
            'Cost overlay authorship')
    presentation_result = verify_recorded_overlay(presentation, 21, h)
    count_result = verify_recorded_overlay(count_overlay, 2, h)
    for overlay, index in ((presentation, 0), (count_overlay, 4)):
        require(overlay['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_120_SOURCE_PINS[index]))
                and overlay['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[index])),
                'Cost overlay original/current source identity')
        old = local_path(overlay['original']['path']).read_bytes()
        new = local_path(overlay['candidate']['path']).read_bytes()
        delta = 0
        for edit in overlay['exact_source_edits']:
            before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
            require(edit['candidate_start_byte'] == edit['original_start_byte'] + delta
                    and edit['original_text_bytes'] == len(before)
                    and edit['replacement_text_bytes'] == len(after)
                    and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest(),
                    'Cost overlay exact byte-offset/text metadata')
            delta += len(after) - len(before)
        headers = lambda data: re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=', data.decode())
        reports = lambda data: re.findall(r'^\s*#print axioms (\S+)$', data.decode(), re.M)
        require(headers(old) == headers(new) and reports(old) == reports(new) == HISTORICAL_RAW_REQUIRED[HISTORICAL_MODULES[index]],
                'Cost overlay theorem header/report preservation')
        if index == 4:
            require(len(headers(new)) == 31, 'Syntax count-sharing theorem-header census')
    kinds = Counter(edit['kind'] for edit in presentation['exact_source_edits'])
    require(kinds == Counter({'documentation_only': 1, 'omit_unused_repr_deriving_request': 19,
                            'omit_unused_display_definition_and_instance': 1})
            and presentation['omitted_repr_deriving_request_count'] == 19
            and presentation['omitted_explicit_display_definitions'] == ["ConLeche.PropWhen.reprPrec'"]
            and presentation['omitted_explicit_display_instances'] == ['Repr ConLeche.PropWhen']
            and presentation['generated_declaration_count_claim'] is None
            and presentation['cached_owner_edits'] == []
            and presentation['selected_cached_owner'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[1])),
            'Presentation-only omission or retained Cached owner census')
    deriving_edits = [edit for edit in presentation['exact_source_edits']
                      if edit['kind'] == 'omit_unused_repr_deriving_request']
    require(len({edit['type'] for edit in deriving_edits}) == 19, 'Repeated Repr deriving type')
    for edit in deriving_edits:
        before, after = edit['original_text'], edit['replacement_text']
        expected = (before.replace('Repr, ', '', 1) if 'Repr, ' in before else
                    '  -- Presentation-only slice: unused Repr deriving request omitted.\n')
        require(re.fullmatch(r'[ \t]*deriving[^\n]*\bRepr\b[^\n]*\n', before)
                and before.count('Repr') == 1 and after == expected
                and ('Repr, ' in before or before == '  deriving Repr\n'),
                'Non-display content removed by deriving edit')
    historical_rows = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                       for row in historical['sources']]
    require(census['scope'] == historical_rows and census['status'] == 'source_text_census_not_elaborated_dependency_export'
            and census['cached_repr_deriving_requests'] == census['cached_repr_instances']
            == census['cached_display_formatter_definitions'] == []
            and census['measured_benefit'] is None,
            'Static presentation census scope')
    old_core_path = local_path(presentation['original']['path'])
    old_core = old_core_path.read_text()
    old_code = guard.lean_code(old_core)
    old_lines = old_core.splitlines(keepends=True)
    actual_sites = []
    for match in re.finditer(r'(?m)^[ \t]*deriving[^\n]*\bRepr\b[^\n]*$', old_code):
        line = old_code.count('\n', 0, match.start()) + 1
        actual_sites.append({'line': line, 'text': old_lines[line - 1]})
    require(actual_sites == [{'line': row['line'], 'text': row['text']}
                             for row in census['core_repr_deriving_sites']]
            and len(actual_sites) == 19
            and [(row['type'], row['line'], row['text']) for row in census['core_repr_deriving_sites']]
                == [(edit['type'], edit['original_line_start'], edit['original_text']) for edit in deriving_edits],
            'Actual source Repr deriving request census')
    for row in (presentation['candidate'], presentation['selected_cached_owner']):
        visible = guard.lean_code(local_path(row['path']).read_text())
        require(not re.search(r'\bRepr\b|\breprPrec\b|\breprArg\b|\breprStr\b', visible),
                'Unexpected retained display dependency in Core/Cached owner')
    require(len(census['primary_intervals']) == 5, 'Presentation primary-interval census')
    for interval in census['primary_intervals']:
        identity(interval['source'], h)
        lines = local_path(interval['source']['path']).read_text().splitlines(keepends=True)
        text = ''.join(lines[interval['start_line'] - 1:interval['end_line_inclusive']]).encode()
        require(text == interval['text'].encode() and len(text) == interval['bytes']
                and hashlib.sha256(text).hexdigest() == interval['sha256'],
                'Presentation primary interval differs')
    require(Counter(edit['kind'] for edit in count_overlay['exact_source_edits']) ==
            Counter({'documentation_only': 1, 'proof_only_common_case_before_structural_induction': 1})
            and count_overlay['exact_source_edits'][1]['declaration'] ==
                'ADWH.Experiments.Chapter15.KernelCachedSyntaxCorrespondence.plain_bulk_eq_pure'
            and count_overlay['changed_existing_theorem_headers'] == []
            and count_overlay['new_or_removed_declarations'] == []
            and count_overlay['new_or_removed_axiom_reports'] == []
            and count_overlay['proof_reorganization']['shared_count_zero_case'] == 1
            and count_overlay['proof_reorganization']['former_per_constructor_zero_count_cases'] == 10
            and count_overlay['proof_reorganization']['remaining_per_constructor_zero_count_cases'] == 0,
            'Syntax common-count proof-only scope')
    require(presentation['claimed_compilation_or_speedup'] is False
            and count_overlay['claimed_compilation_or_speedup'] is False,
            'Source-cost overlays must not claim measured acceptance')
    return {'presentation_overlay': presentation_result, 'syntax_count_overlay': count_result,
            'Core_omitted_Repr_deriving_requests': 19,
            'Core_omitted_display_definitions': ["ConLeche.PropWhen.reprPrec'"],
            'Core_omitted_display_instances': ['Repr ConLeche.PropWhen'],
            'generated_declaration_count_claimed': False, 'static_primary_intervals_checked': 5,
            'Cached_owner_unchanged': True, 'all_existing_theorem_headers_and_reports_preserved': True,
            'Syntax_common_zero_count_case_shared_once': True,
            'new_computational_definition_or_resource_change': False,
            'historical_review_scopes_rebased': False, 'budget_fit_assumed': False}



def explicit_named_declarations(text, guard):
    """Literal named-source census only; generated and implicit declarations are excluded."""
    code_lines, raw_lines = guard.lean_code(text).splitlines(), text.splitlines()
    frames, rows, byte_offset = [], [], 0
    pattern = re.compile(r'^(?:@\[[^\n]*\]\s*)?(?:(?:private|protected|noncomputable|unsafe)\s+)*'
                         r'(def|abbrev|theorem|lemma|inductive|structure|opaque)\s+([^\s:({]+)')
    for line_no, (visible, raw) in enumerate(zip(code_lines, raw_lines), 1):
        namespace = re.match(r'^namespace\s+(\S+)', visible)
        if namespace:
            frames.append(('namespace', namespace.group(1)))
        elif re.match(r'^section(?:\s|$)', visible):
            frames.append(('section', ''))
        elif re.match(r'^mutual(?:\s|$)', visible):
            frames.append(('mutual', ''))
        elif re.match(r'^end(?:\s|$)', visible):
            require(bool(frames), 'Unbalanced source scope in declaration census')
            frames.pop()
        match = pattern.match(visible)
        if match:
            kind, source_name = match.groups()
            prefix = '.'.join(name for tag, name in frames if tag == 'namespace')
            name = (source_name[len('_root_.'):] if source_name.startswith('_root_.')
                    else '.'.join(part for part in (prefix, source_name) if part))
            rows.append({'name': name, 'source_name': source_name, 'kind': kind,
                         'line': line_no, 'start_byte': byte_offset,
                         'declaration_start_line_text': raw})
        byte_offset += len(raw.encode()) + 1
    require(not frames and len(code_lines) == len(raw_lines), 'Incomplete source scope census')
    return rows


def verify_evaluator_omissions(overlay, census, inventory, source_audit, historical, h, guard):
    require(overlay['format'] == 'adwh-cached-evaluator-scope-exact-omission-overlay-v1'
            and overlay['author'] == 'nat_only_gap_review'
            and overlay['exact_source_edit_count'] == 8
            and [row['module'] for row in overlay['variants']] == HISTORICAL_MODULES[:2]
            and overlay['removed_whole_upstream_origins'] == OMITTED_WHOLE_ORIGINS
            and len(OMITTED_WHOLE_ORIGINS) == 9,
            'Evaluator extraction overlay identity and exact omission census')
    outcomes, removed_names, removed_theorems = [], [], []
    for index, (variant, declared, edit_count, old_count, new_count) in enumerate(zip(
            overlay['variants'], census['source_variants'], [5, 3], [466, 277], [387, 267])):
        require(variant['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COST_SOURCE_PINS[index]))
                and variant['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_OMISSION_SOURCE_PINS[index])),
                'Evaluator extraction selected historical/current owner')
        outcomes.append(verify_recorded_overlay(variant, edit_count, h))
        original = local_path(variant['original']['path']).read_text()
        candidate = local_path(variant['candidate']['path']).read_text()
        delta = 0
        cut_intervals = []
        for edit in variant['exact_source_edits']:
            before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
            require(edit['candidate_start_byte'] == edit['original_start_byte'] + delta
                    and edit['original_text_bytes'] == len(before)
                    and edit['replacement_text_bytes'] == len(after)
                    and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest(),
                    'Evaluator omission exact offset, length or text hash')
            delta += len(after) - len(before)
            if before:
                cut_intervals.append((edit['original_start_byte'], edit['original_start_byte'] + len(before)))
        old_rows = explicit_named_declarations(original, guard)
        new_rows = explicit_named_declarations(candidate, guard)
        is_removed = lambda row: any(lo <= row['start_byte'] < hi for lo, hi in cut_intervals)
        removed = [row for row in old_rows if is_removed(row)]
        retained = [row for row in old_rows if not is_removed(row)]
        headers = lambda rows: [(row['name'], row['kind'], row['declaration_start_line_text']) for row in rows]
        reports = lambda raw: re.findall(r'^\s*#print\s+axioms\s+(\S+)', guard.lean_code(raw), re.M)
        require(declared['module'] == HISTORICAL_MODULES[index]
                and declared['original_explicit_named_declaration_count'] == len(old_rows) == old_count
                and declared['candidate_explicit_named_declaration_count'] == len(new_rows) == new_count
                and declared['omitted_explicit_named_declaration_count'] == len(removed) == old_count - new_count
                and removed == declared['omitted_explicit_named_declarations']
                and headers(retained) == headers(new_rows)
                and declared['retained_explicit_declaration_start_headers_literal'] is True
                and declared['all_retained_declaration_bodies_literal_by_complement_map'] is True
                and reports(original) == reports(candidate) == declared['ordered_axiom_prints'] == HISTORICAL_RAW_REQUIRED[HISTORICAL_MODULES[index]]
                and declared['ordered_axiom_prints_unchanged'] is True
                and declared['generated_declaration_count_claimed'] is False,
                'Evaluator explicit source declaration/header/report census')
        removed_names += [row['name'] for row in removed]
        removed_theorems += [row['name'] for row in removed if row['kind'] in ('theorem', 'lemma')]
        require(variant['exact_forward_inverse_and_complement_verified'] is True
                and variant['removed_source_bytes'] == sum(len(edit['original_text'].encode()) for edit in variant['exact_source_edits'])
                and variant['replacement_source_bytes'] == sum(len(edit['replacement_text'].encode()) for edit in variant['exact_source_edits'])
                and variant['net_source_bytes_removed'] == len(original.encode()) - len(candidate.encode()),
                'Evaluator omission byte accounting')
    require(census['status'] == 'literal_source_census_not_elaborated_dependency_export'
            and census['removed_qualified_names'] == removed_names
            and len(set(removed_names)) == 89
            and removed_theorems == ['ConLeche.Expr.allLevelParamsDefinedP_cut']
            and census['only_explicit_theorem_removed'] == removed_theorems[0]
            and census['removed_theorem_was_registered_simp'] is False
            and census['scanned_source_count'] == len(census['scanned_sources']) == 25
            and census['remaining_qualified_removed_name_hits'] == []
            and census['remaining_unambiguous_removed_short_name_hits'] == []
            and census['generated_declaration_count_claimed'] is False
            and census['removed_cached_intrinsic_result_certificate_branch_count'] == 29
            and census['complete_elaborated_dependency_or_implicit_resolution_claimed'] is False,
            'Bounded source dependency census and limitation')
    qualified_pattern = lambda name: r"(?<![A-Za-z0-9_'.])" + re.escape(name) + r"(?![A-Za-z0-9_'])"
    short_pattern = lambda name: r"(?<![A-Za-z0-9_'])" + re.escape(name) + r"(?![A-Za-z0-9_'])"
    short_names = sorted({name.rsplit('.', 1)[-1] for name in removed_names})
    ambiguous = sorted(set(short_names) - set(census['unambiguous_removed_short_names']))
    require(ambiguous == sorted(['bn', 'u', 'v', 'uN', 'vN', 'u1N', 'u1', 'bv', 'srt', 'prop',
            'type1', 'cnst', 'pi', 'piI', 'piA', 'lm', 'lmI', 'ap2', 'ap3', 'ap4', 'rule',
            'canon', 'canonEq', 'slot', 'decls', 'names']), 'Ambiguous source-token census')
    actual_ambiguous = []
    for row in census['scanned_sources']:
        identity(row, h)
        visible = guard.lean_code(local_path(row['path']).read_text())
        require(not any(re.search(qualified_pattern(name), visible) for name in removed_names)
                and not any(re.search(short_pattern(name), visible) for name in census['unambiguous_removed_short_names']),
                'Deleted declaration has a retained explicit source reference: ' + row['path'])
        counts = {name: len(re.findall(short_pattern(name), visible)) for name in ambiguous}
        actual_ambiguous.append({'path': row['path'], 'counts': {name: count for name, count in counts.items() if count}})
    require(actual_ambiguous == census['ambiguous_short_name_census'],
            'Ambiguous source-token counts differ from independently reviewed census')
    current_origins = [name for name in historical['logical_origins'] if name not in OMITTED_WHOLE_ORIGINS]
    require(overlay['historical_logical_origin_order'] == historical['logical_origins']
            and overlay['current_logical_origin_order'] == current_origins
            and inventory['current_logical_origin_order'] == current_origins
            and (overlay['historical_upstream_origin_count'], overlay['current_upstream_origin_count'],
                 overlay['current_project_origin_count'], overlay['current_logical_origin_count'],
                 overlay['historical_source_segment_count'], overlay['current_source_segment_count'])
                == (26, 17, 7, 24, 35, 26)
            and overlay['retained_declaration_bodies_proofs_imports_options_literal'] is True
            and overlay['all_six_pure_and_cached_callback_bodies_and_knots_retained'] is True
            and overlay['actual_CState_layout_flushed_and_helper_operations_retained'] is True
            and overlay['new_computational_definitions_or_proof_bodies'] == []
            and overlay['noncomputable_modifiers_introduced'] is False
            and overlay['resource_or_compiler_option_changes'] is False
            and overlay['native_full_original_driver_API_preserved'] is False
            and overlay['later_driver_restoration_required'] is True
            and overlay['historical_reviews_rebased'] is False
            and overlay['compilation_or_budget_fit_claimed'] is False,
            'Current evaluator ownership, retained algorithms or driver boundary')
    require(source_audit['exact_overlay_forward_inverse_and_complement_verified'] is True
            and source_audit['retained_declaration_bodies_and_proofs_literal_unchanged'] is True
            and source_audit['all_six_actual_pure_and_cached_slots_and_knots_retained'] is True
            and source_audit['full_original_driver_API_preserved'] is False
            and source_audit['later_original_driver_restoration_required'] is True,
            'Independent evaluator omission source-review conclusions')
    return {'variants': outcomes, 'exact_edit_count': 8, 'removed_named_declarations': 89,
            'removed_intrinsic_certificate_branches': 29, 'static_consumer_sources_checked': 25,
            'net_selected_source_bytes_removed': 49282, 'current_logical_origins': current_origins,
            'removed_whole_upstream_origins': OMITTED_WHOLE_ORIGINS,
            'all_retained_source_text_literal': True, 'historical_review_scopes_rebased': False,
            'static_census_is_complete_elaborated_dependency_proof': False,
            'full_original_driver_native_API_preserved': False, 'later_driver_restoration_required': True,
            'budget_fit_assumed': False}



def verify_comment_header_repair(correction, h):
    require(correction['format'] == 'adwh-cached-evaluator-comment-diagnostic-repair-v1'
            and correction['author'] == 'nat_only_gap_review'
            and correction['exact_source_edit_count'] == 2
            and [row['module'] for row in correction['variants']] == HISTORICAL_MODULES[:2]
            and correction['source_command_classification_changed'] is True
            and correction['retained_declarations_proofs_import_text_options_and_prints_literal'] is True
            and correction['new_theorem_headers_or_reports'] == []
            and correction['algorithm_or_native_semantics_change'] is False
            and correction['resource_policy_or_profiler_change'] is False,
            'Diagnosed comment-header repair scope')
    outcomes = []
    for index, variant in enumerate(correction['variants']):
        require(variant['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_OMISSION_SOURCE_PINS[index]))
                and variant['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COMMENT_SOURCE_PINS[index])),
                'Comment repair historical/current source identities')
        outcomes.append(verify_recorded_overlay(variant, 1, h))
        edit = variant['exact_source_edits'][0]
        original = local_path(variant['original']['path']).read_bytes()
        candidate = local_path(variant['candidate']['path']).read_bytes()
        require(edit['original_start_byte'] == edit['candidate_start_byte'] == 0
                and edit['original_text'] == '/-!' and edit['replacement_text'] == '/-'
                and edit['original_text_bytes'] == 3 and edit['replacement_text_bytes'] == 2
                and edit['original_text_sha256'] == hashlib.sha256(b'/-!').hexdigest()
                and edit['replacement_text_sha256'] == hashlib.sha256(b'/-').hexdigest()
                and original.startswith(b'/-! ') and candidate.startswith(b'/- ')
                and original[3:] == candidate[2:]
                and variant['unchanged_suffix_start_original_byte'] == 3
                and variant['unchanged_suffix_start_candidate_byte'] == 2
                and variant['unchanged_suffix_bytes'] == len(original) - 3
                and variant['unchanged_suffix_sha256'] == hashlib.sha256(original[3:]).hexdigest(),
                'Comment repair is exactly the diagnosed leading one-byte omission')
    return {'variants': outcomes, 'exact_edit_count': 2,
            'all_retained_declarations_import_text_proofs_options_reports_literal': True,
            'module_doc_before_imports_changed_to_ordinary_comment': True,
            'unstarted_Cached_owner_same_header_defect_also_repaired': True,
            'algorithm_or_resource_policy_changed': False,
            'historical_source_reviews_rebased': False, 'budget_fit_assumed': False}


def verify_syntax_haslp_repair(correction, primary, h):
    names = ['level_flag_' + name for name in ('fvar', 'app', 'lam', 'forall', 'let', 'proj')]
    require(correction['format'] == 'adwh-cached-syntax-haslp-diagnostic-repair-v1'
            and correction['author'] == 'reflection_evidence_review'
            and correction['exact_source_edit_count'] == 6
            and correction['diagnosed_private_lemmas'] == names
            and correction['diagnosed_lines'] == [50, 70, 76, 82, 88, 93]
            and correction['new_theorem_headers_or_reports'] == []
            and correction['unchanged_report_roots'] == HISTORICAL_RAW_REQUIRED[HISTORICAL_MODULES[4]]
            and correction['all_theorem_statements_unchanged'] is True
            and correction['original_header_and_report_suffix_literal'] is True
            and correction['computational_definitions_imports_options_and_other_proofs_literal'] is True
            and correction['historical_review_scopes_rebased'] is False
            and correction['resource_policy_or_profiler_change'] is False,
            'Diagnosed Syntax hasLP repair scope')
    variant = correction['variant']
    require(variant['module'] == HISTORICAL_MODULES[4]
            and variant['original'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_COMMENT_SOURCE_PINS[4]))
            and variant['candidate'] == dict(zip(('path', 'bytes', 'sha256'), HISTORICAL_HASLP_SOURCE_PINS[4])),
            'Syntax repair historical/current physical identities')
    result = verify_recorded_overlay(variant, 6, h)
    original = local_path(variant['original']['path']).read_bytes()
    candidate = local_path(variant['candidate']['path']).read_bytes()
    before, after = b'  rw [packed_level_bit]\n', b'  simp only [packed_level_bit, Expr.hasLP]\n'
    original_complement, candidate_complement = [], []
    old_cursor = new_cursor = 0
    for name, edit in zip(names, variant['exact_source_edits']):
        old_start, new_start = edit['original_start_byte'], edit['candidate_start_byte']
        block_start = original.index(('private theorem ' + name + ' ').encode())
        block_end = original.index(b'\nprivate theorem ', block_start + 1)
        require(edit['label'] == name
                and edit['kind'] == 'diagnosed_child_hasLP_observer_unfolding'
                and edit['original_text'].encode() == before
                and edit['replacement_text'].encode() == after
                and edit['original_text_bytes'] == len(before)
                and edit['replacement_text_bytes'] == len(after)
                and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest()
                and original[block_start:block_end].count(before) == 1
                and old_start == original.index(before, block_start, block_end)
                and original[old_start:old_start + len(before)] == before
                and candidate[new_start:new_start + len(after)] == after
                and edit['original_line_start'] == original[:old_start].count(b'\n') + 1
                and edit['candidate_line_start'] == candidate[:new_start].count(b'\n') + 1,
                'Exactly one explicit hasLP simplification in each diagnosed constructor')
        original_complement.append(original[old_cursor:old_start])
        candidate_complement.append(candidate[new_cursor:new_start])
        old_cursor, new_cursor = old_start + len(before), new_start + len(after)
    original_complement.append(original[old_cursor:])
    candidate_complement.append(candidate[new_cursor:])
    require(original_complement == candidate_complement
            and variant['unchanged_complement_bytes'] == sum(map(len, original_complement))
            and variant['unchanged_complement_sha256'] == hashlib.sha256(b''.join(original_complement)).hexdigest(),
            'Unchanged Syntax header, statement and proof complement')
    theorem_pattern = rb'(?ms)^(?:private )?theorem .+? := by\n'
    require(re.findall(theorem_pattern, original) == re.findall(theorem_pattern, candidate)
            and len(re.findall(theorem_pattern, original)) == 30,
            'All public and private theorem statements stay literal')
    require(primary['format'] == 'adwh-cached-syntax-haslp-primary-intervals-v1'
            and primary['interval_count'] == len(primary['intervals']) == 5,
            'Syntax repair primary interval census')
    for interval in primary['intervals']:
        identity(interval['source'], h)
        lines = local_path(interval['source']['path']).read_bytes().splitlines(keepends=True)
        require(1 <= interval['start_line'] <= interval['end_line'] <= len(lines), 'Primary interval bounds')
        body = b''.join(lines[interval['start_line'] - 1:interval['end_line']])
        require(body == interval['text'].encode() and len(body) == interval['bytes']
                and hashlib.sha256(body).hexdigest() == interval['sha256'], 'Primary interval bytes differ')
    return {**result, 'exact_diagnosed_private_lemma_count': 6, 'primary_interval_count': 5,
            'all_30_theorem_statements_and_11_reports_literal': True,
            'actual_Expr_hasLP_explicitly_unfolded': True,
            'algorithm_or_resource_policy_changed': False,
            'historical_source_reviews_rebased': False, 'budget_fit_assumed': False}


def historical_preflight(args, h, guard):
    manifest = read(HISTORICAL_MANIFEST)
    mapping = read(BUNDLED / 'SOURCE-CORRESPONDENCE.json')
    inventory = read(BUNDLED / 'SOURCE-INVENTORY.json')
    audit = read(BUNDLED / 'SOURCE-AUDIT.json')
    correction = read(CORRECTION / 'PROOF-CORRECTION.json')
    correction_audit = read(CORRECTION / 'SOURCE-AUDIT.json')
    stable_inventory = read(STABLE / 'SOURCE-INVENTORY.json')
    stable_audit = read(STABLE / 'SOURCE-AUDIT.json')
    stable_correction = read(STABLE_CORRECTION / 'PROOF-CORRECTION.json')
    stable_correction_audit = read(STABLE_CORRECTION / 'SOURCE-AUDIT.json')
    helper_correction = read(DIRECT / 'PROOF-CORRECTION.json')
    helper_inventory = read(DIRECT / 'SOURCE-INVENTORY.json')
    helper_audit = read(DIRECT / 'SOURCE-AUDIT.json')
    diagnosed_repair = read(DIAGNOSED / 'PROOF-CORRECTION.json')
    diagnosed_inventory = read(DIAGNOSED / 'SOURCE-INVENTORY.json')
    diagnosed_audit = read(DIAGNOSED / 'SOURCE-AUDIT.json')
    syntax_overlay = read(SYNTAX / 'PROOF-CORRECTION.json')
    syntax_inventory = read(SYNTAX / 'SOURCE-INVENTORY.json')
    syntax_audit = read(SYNTAX / 'SOURCE-AUDIT.json')
    sharing_overlay = read(SHARING / 'PROOF-OVERLAY.json')
    sharing_correspondence = read(SHARING / 'SOURCE-CORRESPONDENCE.json')
    sharing_inventory = read(SHARING / 'SOURCE-INVENTORY.json')
    sharing_audit = read(SHARING / 'SOURCE-AUDIT.json')
    bulk_map = read(BULK / 'SOURCE-CORRESPONDENCE.json')
    bulk_boundary = read(BULK / 'SLICE-BOUNDARY-CORRECTION.json')
    bulk_inventory = read(BULK / 'SOURCE-INVENTORY.json')
    bulk_audit = read(BULK / 'SOURCE-AUDIT.json')
    literal_wording = read(LITERAL / 'REVIEW-WORDING-CORRECTION.json')
    literal_inventory = read(LITERAL / 'SOURCE-INVENTORY.json')
    literal_audit = read(LITERAL / 'SOURCE-AUDIT.json')
    historical_120 = read(COST_PREDECESSOR / 'source-manifest.json')
    presentation_overlay = read(PRESENTATION / 'PRESENTATION-OMISSIONS.json')
    presentation_census = read(PRESENTATION / 'STATIC-CENSUS.json')
    presentation_inventory = read(PRESENTATION / 'SOURCE-INVENTORY.json')
    presentation_audit = read(PRESENTATION / 'SOURCE-AUDIT.json')
    count_overlay = read(COUNT_SHARING / 'PROOF-OVERLAY.json')
    count_inventory = read(COUNT_SHARING / 'SOURCE-INVENTORY.json')
    count_audit = read(COUNT_SHARING / 'SOURCE-AUDIT.json')
    historical_cost = read(OMISSION_PREDECESSOR / 'source-manifest.json')
    omission_overlay = read(OMISSION / 'SOURCE-OMISSIONS.json')
    omission_census = read(OMISSION / 'SOURCE-CENSUS.json')
    omission_inventory = read(OMISSION / 'SOURCE-INVENTORY.json')
    omission_audit = read(OMISSION / 'SOURCE-AUDIT.json')
    historical_omission = read(COMMENT_PREDECESSOR / 'source-manifest.json')
    historical_omission_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                                     for row in historical_omission['sources']]
    comment_correction = read(COMMENT_REPAIR / 'PROOF-CORRECTION.json')
    comment_inventory = read(COMMENT_REPAIR / 'SOURCE-INVENTORY.json')
    comment_audit = read(COMMENT_REPAIR / 'SOURCE-AUDIT.json')
    historical_comment = read(HASLP_PREDECESSOR / 'source-manifest.json')
    historical_comment_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                                    for row in historical_comment['sources']]
    haslp_correction = read(HASLP_REPAIR / 'PROOF-CORRECTION.json')
    haslp_primary = read(HASLP_REPAIR / 'PRIMARY-SOURCE-INTERVALS.json')
    haslp_inventory = read(HASLP_REPAIR / 'SOURCE-INVENTORY.json')
    haslp_audit = read(HASLP_REPAIR / 'SOURCE-AUDIT.json')
    require(manifest['format'] == HISTORICAL_MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY and manifest['module_order'] == HISTORICAL_MODULES
            and manifest['prepared_objects'] == [] and manifest['export_targets'] == []
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 120
            and manifest['expected_artifact_count'] == 14, 'Manifest selection or policy differs')
    require(audit['status'] == 'passed_source_only_review_not_compiled'
            and audit['reviewer'] == 'reflection_evidence_review'
            and audit['source_author'] == 'book_scope_review'
            and audit['independent_of_source_author'] is True
            and audit['audited_input_count'] == len(audit['audited_inputs']) == 27
            and manifest['reviewed_direct_inputs'] == audit['audited_inputs'], 'Independent review scope')
    require(correction_audit['status'] == 'passed_source_only_review_not_compiled'
            and correction_audit['reviewer'] == 'book_scope_review'
            and correction_audit['correction_author'] == 'root'
            and correction_audit['independent_of_correction_author'] is True
            and correction_audit['direct_input_count'] == len(correction_audit['inputs']) == 18
            and manifest['reviewed_correction_inputs'] == correction_audit['inputs']
            and correction_audit['fully_qualified_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[1]],
            'Independent correction review scope')
    require(audit['physical_module_order'] == HISTORICAL_MODULES[:2]
            and audit['required_axiom_report_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[1]]
            and audit['required_axiom_report_count'] == 25, 'Reviewed source/root selection')
    require(mapping['physical_module_order'] == HISTORICAL_MODULES[:2]
            and mapping['distinct_upstream_origin_count'] == 26
            and mapping['distinct_project_origin_count'] == 2
            and mapping['distinct_mathematical_origin_count'] == 28
            and mapping['selected_source_segment_count'] == 30,
            'Origin and supplemental ownership census')
    require(stable_audit['status'] == 'passed_source_only_review_not_compiled'
            and stable_audit['reviewer'] == 'book_scope_review'
            and stable_audit['source_author'] == 'nat_only_gap_review'
            and stable_audit['independent_of_source_author'] is True
            and stable_audit['direct_input_count'] == len(stable_audit['inputs']) == 17
            and manifest['reviewed_stable_inputs'] == stable_audit['inputs']
            and stable_audit['fully_qualified_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[2]]
            and stable_inventory['physical_module_order'] == HISTORICAL_MODULES[:3]
            and stable_inventory['new_required_axiom_reports'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[2]]
            and stable_inventory['required_total_axiom_reports'] == 45
            and stable_inventory['expected_default_artifact_count'] == 6
            and stable_inventory['input_count'] == len(stable_inventory['inputs']) == 44
            and helper_inventory['logical_origins'][:29] == stable_inventory['logical_origins'],
            'Original stable source/review scope must remain unchanged')
    require(stable_correction_audit['status'] == 'passed_source_only_review_not_compiled'
            and stable_correction_audit['reviewer'] == 'book_scope_review'
            and stable_correction_audit['correction_author'] == 'root'
            and stable_correction_audit['independent_of_correction_author'] is True
            and stable_correction_audit['direct_input_count'] == len(stable_correction_audit['inputs']) == 12
            and manifest['reviewed_stable_correction_inputs'] == stable_correction_audit['inputs']
            and stable_correction_audit['fully_qualified_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[2]]
            and stable_correction_audit['original'] == stable_correction['original'] == stable_audit['source']
            and stable_correction_audit['candidate'] == stable_correction['candidate'],
            'Independent stable correction scope')
    require(helper_audit['status'] == 'passed_source_only_review_not_compiled'
            and helper_audit['reviewer'] == 'book_scope_review'
            and helper_audit['source_author'] == 'reflection_evidence_review'
            and helper_audit['independent_of_source_author'] is True
            and helper_audit['direct_input_count'] == len(helper_audit['inputs']) == 25
            and manifest['reviewed_helper_inputs'] == helper_audit['inputs']
            and helper_audit['fully_qualified_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[3]]
            and helper_audit['source'] == helper_correction['candidate'] == helper_inventory['new_source']
            and helper_audit['original_source'] == helper_correction['original']
            and helper_inventory['input_count'] == len(helper_inventory['inputs']) == 75
            and helper_inventory['physical_module_order'] == HISTORICAL_MODULES[:4]
            and helper_inventory['new_required_axiom_reports'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[3]]
            and helper_inventory['required_total_axiom_reports'] == 70
            and helper_inventory['expected_default_artifact_count'] == 8
            and historical_cost['logical_origins'][:30] == helper_inventory['logical_origins']
            and len(set(historical_cost['logical_origins'])) == 33
            and historical_cost['source_segment_count'] == 35,
            'Independent helper source and complete closure scope')
    require(diagnosed_audit['status'] == 'passed_source_only_review_not_compiled'
            and diagnosed_audit['reviewer'] == 'book_scope_review'
            and diagnosed_audit['correction_author'] == 'reflection_evidence_review'
            and diagnosed_audit['independent_of_correction_author'] is True
            and diagnosed_audit['direct_input_count'] == len(diagnosed_audit['inputs']) == 18
            and manifest['reviewed_diagnosed_helper_inputs'] == diagnosed_audit['inputs']
            and diagnosed_audit['new_source_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[3]]
            and diagnosed_audit['original'] == diagnosed_repair['original'] == helper_audit['source']
            and diagnosed_audit['candidate'] == diagnosed_repair['candidate'] == diagnosed_inventory['new_source']
            and diagnosed_inventory['input_count'] == len(diagnosed_inventory['inputs']) == 84
            and diagnosed_inventory['new_required_axiom_reports'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[3]]
            and diagnosed_inventory['physical_module_order'] == HISTORICAL_MODULES[:4]
            and diagnosed_inventory['logical_origins'] == historical_cost['logical_origins'][:30]
            and diagnosed_inventory['required_total_axiom_reports'] == 70
            and diagnosed_inventory['expected_default_artifact_count'] == 8
            and diagnosed_inventory['selected_physical_source_bytes'] == 592064
            and diagnosed_inventory['syntax_candidate_selected'] is False,
            'Independent diagnosed Helper repair/current complete closure scope')
    failed = read(PREDECESSOR / 'attempts/complete-01/report.json')
    require(failed['status'] == 'failed' and failed['source_fingerprint'] ==
            'c7be13545fb772ae734d0aa6c3568a22709662870f3b7058ab0f66a8561ab321'
            and failed['module_order'] == HISTORICAL_MODULES[:4]
            and [m['status'] for m in failed['modules']] == ['passed', 'passed', 'passed', 'failed']
            and failed['accepted_axiom_report_count'] == 45
            and failed['observed_axiom_report_count'] == 70
            and failed['all_selected_mathematical_sources_freshly_checked'] is False
            and failed['direct_helper_25_roots_checked'] is False,
            'Consumed Helper attempt or accepted-prefix boundary differs')
    failed_marker = local_path(manifest['preserved_failed_predecessors'][-1]['consumed_marker']['path'])
    verify([h.binding(failed_marker)], True)
    require(read(failed_marker)['source_fingerprint'] == failed['source_fingerprint'],
            'Consumed Helper marker differs')
    require(historical_cost['origin_ownership'] == mapping['distinct_upstream_origin_order']
            and len(set(historical_cost['origin_ownership'])) == 26
            and manifest['source_segment_ownership'] == [x['module'] for x in mapping['physical_units'][1]['source_segments']] + HISTORICAL_MODULES[2:]
            and manifest['inherited_omissions'] == mapping['inherited_omissions'] == audit['inherited_omissions']
            and manifest['core_correspondence_layers'] == mapping['core_layers_unchanged'],
            'Origin ownership, omission or historical-layer disclosure changed')
    sources, done = [], set()
    require(len(manifest['sources']) == len(HISTORICAL_HASLP_SOURCE_PINS), 'Source count')
    for row, module, pin in zip(manifest['sources'], HISTORICAL_MODULES, HISTORICAL_HASLP_SOURCE_PINS):
        require(row['module'] == module and (row['path'], row['bytes'], row['sha256']) == pin,
                'Frozen physical source pin: ' + module)
        require(row['module_format'] is False and row['expected_default_output_suffixes'] == ['.olean', '.ilean']
                and row['fully_qualified_roots'] == HISTORICAL_REQUIRED[module]
                and row['raw_source_print_identifiers'] == HISTORICAL_RAW_REQUIRED[module],
                'Physical output/report contract: ' + module)
        require(all(n in done or n == 'Init' or n.startswith(('Init.', 'Std.')) for n in row['imports']),
                'External experimental or forward physical import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']})
        done.add(module)
    require(audit['selected_physical_sources'] == [u['selected_source'] for u in mapping['physical_units']],
            'Original review scope must remain at original physical source identities')
    original_stable_selection = [mapping['physical_units'][0]['selected_source'],
                                 correction['corrections'][2]['candidate'], stable_audit['source']]
    require(original_stable_selection == [u['selected_source'] for u in stable_inventory['physical_units']],
            'Original stable inventory keeps its exact historical three owners')
    corrected_selection = original_stable_selection[:2] + [stable_correction['candidate'], helper_audit['source']]
    require(corrected_selection == [u['selected_source'] for u in helper_inventory['physical_units']],
            'Helper inventory must select the exact four corrected source owners')
    diagnosed_selection = corrected_selection[:3] + [diagnosed_repair['candidate']]
    require(diagnosed_selection == [u['selected_source'] for u in diagnosed_inventory['physical_units']]
            == diagnosed_audit['physical_sources'], 'Diagnosed Helper complete selection')
    require(manifest['accepted_70_historical_physical_selection'] == diagnosed_selection,
            'Accepted 70 closure must retain its historical physical source identities')
    require(correction['corrections'][2]['original'] == mapping['physical_units'][1]['selected_source']
            and manifest['corrected_project_origins'] == [x['candidate'] for x in correction['corrections'][:2]]
            and manifest['historical_corrected_leaf_origins'] == [stable_correction['candidate'], helper_correction['candidate']]
            and manifest['corrected_leaf_origins'] == [stable_correction['candidate'], diagnosed_repair['candidate']]
            and manifest['source_origin_rows_precede_separate_proof_overlay'] is True,
            'Physical correction must start from the exact original assembly')

    for label, source_audit, expected_count, count_key, reviewer, author, author_key, status in [
            ('observer_syntax', syntax_audit, 33, 'direct_input_count', 'book_scope_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled'),
            ('cached_proof_sharing', sharing_audit, 26, 'direct_input_count', 'book_scope_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled_or_measured'),
            ('bulk_bound', bulk_audit, 119, 'direct_input_count', 'nat_only_gap_review',
             'reflection_evidence_review', 'source_author', 'passed_source_only_review_not_compiled'),
            ('literal_forward', literal_audit, 16, 'input_count', 'nat_only_gap_review',
             'root', 'source_author', 'passed_source_only_review_not_compiled')]:
        require(source_audit['status'] == status and source_audit['reviewer'] == reviewer
                and source_audit[author_key] == author and source_audit['independent_of_source_author'] is True
                and source_audit[count_key] == len(source_audit['inputs']) == expected_count
                and manifest['new_separate_review_scopes'][label]['inputs'] == source_audit['inputs']
                and manifest['new_separate_review_scopes'][label]['input_count'] == expected_count,
                'Independent new review scope: ' + label)
    for label, inv, count in [('observer_syntax', syntax_inventory, 104),
                              ('cached_proof_sharing', sharing_inventory, 129),
                              ('bulk_bound', bulk_inventory, 116),
                              ('literal_forward', literal_inventory, 15)]:
        require(inv['input_count'] == len(inv['inputs']) == count
                and manifest['new_separate_author_inventory_scopes'][label]['inputs'] == inv['inputs']
                and manifest['new_separate_author_inventory_scopes'][label]['input_count'] == count,
                'Frozen new author inventory scope: ' + label)
    require(syntax_audit['fully_qualified_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[4]]
            and syntax_audit['Core_candidate'] == syntax_overlay['source_variants'][0]['candidate']
            and syntax_audit['source'] == syntax_overlay['source_variants'][1]['candidate']
            and syntax_inventory['physical_module_order'] == HISTORICAL_MODULES[:5]
            and syntax_inventory['required_total_axiom_reports'] == 82
            and syntax_inventory['expected_default_artifact_count'] == 10,
            'Observer/Syntax original reviewed selection')
    require(sharing_audit['fully_qualified_owner_report_roots'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[1]]
            and sharing_audit['selected_physical_source'] == sharing_overlay['variants'][0]['candidate']
            and sharing_inventory['physical_module_order'] == HISTORICAL_MODULES[:6]
            and sharing_inventory['required_total_axiom_reports'] == 112
            and sharing_inventory['expected_default_artifact_count'] == 12
            and sharing_inventory['logical_origin_order'] == historical_cost['logical_origins'][:32],
            'Proof-sharing reviewed and author selection')
    require(bulk_audit['new_report_roots'] == bulk_inventory['new_required_axiom_reports']
            == HISTORICAL_REQUIRED[HISTORICAL_MODULES[5]] and bulk_audit['new_source'] == bulk_map['selected_source']
            and bulk_inventory['physical_module_order'] == HISTORICAL_MODULES[:6]
            and bulk_inventory['required_total_axiom_reports'] == 112
            and bulk_inventory['expected_default_artifact_count'] == 12
            and bulk_inventory['logical_origin_order'] == historical_cost['logical_origins'][:32]
            and bulk_audit['new_proof_sharing_owner_automatically_covered'] is False,
            'Bulk independent scope or unchanged owner-context boundary')
    require(literal_audit['ordered_axiom_reports'] == literal_inventory['new_required_axiom_reports']
            == HISTORICAL_REQUIRED[HISTORICAL_MODULES[6]] and literal_audit['selected_new_source'] == literal_wording['candidate']
            and literal_inventory['physical_module_order'] == HISTORICAL_MODULES[:3] + [HISTORICAL_MODULES[6]]
            and literal_inventory['required_total_axiom_reports'] == 53
            and literal_inventory['expected_default_artifact_count'] == 8
            and literal_inventory['logical_origins'][:29] == historical_cost['logical_origins'][:29]
            and literal_inventory['logical_origins'][-1] == historical_cost['logical_origins'][-1],
            'Literal independent scope or historical four-owner selection')
    actual_selection = [{k: row[k] for k in ('path', 'bytes', 'sha256')} for row in manifest['sources']]
    require(actual_selection == [comment_correction['variants'][0]['candidate'],
            comment_correction['variants'][1]['candidate'], stable_correction['candidate'],
            diagnosed_repair['candidate'], haslp_correction['variant']['candidate'],
            bulk_map['selected_source'], literal_wording['candidate']]
            and sum(len(roots) for roots in HISTORICAL_REQUIRED.values()) == 120
            and len({root for roots in HISTORICAL_REQUIRED.values() for root in roots}) == 120,
            'Complete current owner/report selection')
    accepted = read(ACCEPTED_PREDECESSOR / 'attempts/complete-01/report.json')
    require(accepted['status'] == 'passed' and accepted['module_order'] == HISTORICAL_MODULES[:4]
            and accepted['source_fingerprint'] == 'efb1eed69cd6102398244e005a8cba75455a39e4c687b2fad539ba5aa1f8c444'
            and accepted['accepted_axiom_report_count'] == accepted['observed_axiom_report_count'] == 70
            and accepted['all_selected_mathematical_sources_freshly_checked'] is True,
            'Accepted 70 predecessor identity or acceptance boundary')
    accepted_marker = local_path(manifest['preserved_accepted_predecessor']['consumed_marker']['path'])
    verify([h.binding(accepted_marker)], True)
    require(read(accepted_marker)['source_fingerprint'] == accepted['source_fingerprint']
            and manifest['preserved_accepted_predecessor']['source_fingerprint'] == accepted['source_fingerprint'],
            'Accepted predecessor marker identity')
    require(manifest['new_independent_review_scopes_rebased'] is False
            and manifest['effective_Core_optional_PropWhen_omissions'] == {'proofs': 34, 'simp_registrations': 14}
            and manifest['new_existing_origin_supplements']['bulk_slices'] == 6
            and manifest['new_existing_origin_supplements']['PropWhen_exact_observer_laws'] == 2,
            'Current supplement and inherited-omission disclosure')


    historical_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                            for row in historical_120['sources']]
    require(historical_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                     for pin in HISTORICAL_120_SOURCE_PINS]
            == manifest['consumed_120_historical_physical_selection']
            and historical_120['policy'] == POLICY and historical_120['module_order'] == HISTORICAL_MODULES
            and historical_120['source_fingerprint'] ==
                '785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e',
            'Consumed 120 selection/source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor'):
        require(manifest[key] == historical_120[key], 'Historical 120 scope rebased: ' + key)
    historical_cost_selection = [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                                 for row in historical_cost['sources']]
    require([index for index, (old, new) in enumerate(zip(historical_selection, historical_cost_selection))
             if old != new] == [0, 4]
            and presentation_overlay['original'] == historical_selection[0]
            and count_overlay['original'] == historical_selection[4]
            and sum(row['bytes'] for row in historical_cost['sources']) ==
                historical_cost['selected_physical_source_bytes'] == 637855,
            'Historical cost selection changes only Core and Syntax')
    for label, source_audit, inv, overlay, index, review_count, inventory_count in (
            ('presentation', presentation_audit, presentation_inventory, presentation_overlay, 0, 210, 209),
            ('syntax_count_sharing', count_audit, count_inventory, count_overlay, 4, 214, 213)):
        require(source_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
                and source_audit['reviewer'] == 'root'
                and source_audit['source_author'] == 'reflection_evidence_review'
                and source_audit['independent_of_source_author'] is True
                and source_audit['direct_input_count'] == len(source_audit['inputs']) == review_count
                and manifest['cost_separate_review_scopes'][label]['input_count'] == review_count
                and manifest['cost_separate_review_scopes'][label]['inputs'] == source_audit['inputs']
                and source_audit['original'] == overlay['original']
                and source_audit['candidate'] == overlay['candidate']
                and source_audit['required_axiom_reports'] == HISTORICAL_REQUIRED[HISTORICAL_MODULES[index]]
                and source_audit['public_and_private_theorem_headers_literal_unchanged'] is True
                and source_audit['algorithmic_computational_definitions_changed'] is False
                and source_audit['historical_reviews_rebased'] is False
                and inv['review_input_count'] == len(inv['review_inputs']) == inventory_count
                and manifest['cost_separate_author_inventory_scopes'][label]['input_count'] == inventory_count
                and manifest['cost_separate_author_inventory_scopes'][label]['inputs'] == inv['review_inputs']
                and inv['selected_physical_variant'] == overlay['candidate']
                and inv['predecessor_source'] == overlay['original'],
                'Independent cost source review/inventory scope: ' + label)
    consumed_120 = read(COST_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_120['status'] == 'failed'
            and consumed_120['source_fingerprint'] == historical_120['source_fingerprint']
            and consumed_120['module_order'] == HISTORICAL_MODULES
            and [row['module'] for row in consumed_120['modules']] == HISTORICAL_MODULES[:5]
            and [row['status'] for row in consumed_120['modules']] == ['passed'] * 4 + ['failed']
            and consumed_120['accepted_axiom_report_count'] == consumed_120['observed_axiom_report_count'] == 71
            and consumed_120['modules'][-1]['limit_exceeded'] == 'wall_time'
            and consumed_120['modules'][-1]['exit_code'] == -9
            and consumed_120['modules'][-1]['axiom_audit']['observed_count'] == 0
            and consumed_120['all_selected_mathematical_sources_freshly_checked'] is False,
            'Consumed 120 timeout or accepted-prefix boundary differs')
    consumed_marker = local_path(manifest['preserved_consumed_120_predecessor']['consumed_marker']['path'])
    verify([h.binding(consumed_marker)], True)
    require(read(consumed_marker)['source_fingerprint'] == consumed_120['source_fingerprint']
            and manifest['preserved_consumed_120_predecessor']['source_fingerprint'] ==
                consumed_120['source_fingerprint'], 'Consumed 120 permanent marker differs')
    require(manifest['cost_historical_review_scopes_rebased'] is False
            and manifest['cost_new_leaves_selected'] == []
            and manifest['cost_presentation_omissions'] == {
                'Repr_deriving_requests': 19, 'display_definitions': ["ConLeche.PropWhen.reprPrec'"],
                'display_instances': ['Repr ConLeche.PropWhen'], 'generated_declaration_count_claimed': False},
            'Cost selection disclosures differ')

    require(historical_cost_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                          for pin in HISTORICAL_COST_SOURCE_PINS]
            == manifest['consumed_cost120_historical_physical_selection']
            and historical_cost['policy'] == POLICY and historical_cost['module_order'] == HISTORICAL_MODULES
            and historical_cost['source_fingerprint'] ==
                '3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5',
            'Consumed cost120 complete historical source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'cost_separate_review_scopes',
                'cost_separate_author_inventory_scopes', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor', 'preserved_consumed_120_predecessor',
                'consumed_120_historical_physical_selection', 'accepted_70_historical_physical_selection'):
        require(manifest[key] == historical_cost[key], 'Historical cost120 scope rebased: ' + key)
    require([index for index, (old, new) in enumerate(zip(historical_cost_selection, historical_omission_selection))
             if old != new] == [0, 1]
            and sum(row['bytes'] for row in historical_omission['sources']) ==
                historical_omission['selected_physical_source_bytes'] == 588573
            and manifest['ordered_report_counts'] == [1, 25, 20, 25, 11, 30, 8]
            and manifest['omission_historical_review_scopes_rebased'] is False
            and manifest['omission_new_leaves_selected'] == []
            and manifest['full_original_driver_native_API_preserved'] is False
            and manifest['later_original_driver_restoration_required'] is True,
            'Only evaluator Core/Cached extraction may change the consumed cost selection')
    require(omission_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
            and omission_audit['reviewer'] == 'root'
            and omission_audit['source_author'] == 'nat_only_gap_review'
            and omission_audit['independent_of_source_author'] is True
            and omission_audit['direct_input_count'] == len(omission_audit['inputs']) == 61
            and manifest['omission_separate_review_scope']['input_count'] == 61
            and manifest['omission_separate_review_scope']['inputs'] == omission_audit['inputs']
            and omission_inventory['input_count'] == len(omission_inventory['inputs']) == 60
            and manifest['omission_separate_author_inventory_scope']['input_count'] == 60
            and manifest['omission_separate_author_inventory_scope']['inputs'] == omission_inventory['inputs']
            and omission_inventory['prospective_physical_sources'] == historical_omission['sources']
            and omission_audit['source_variants'] == omission_inventory['source_variants']
            == [{key: row[key] for key in ('module', 'original', 'candidate')} for row in omission_overlay['variants']]
            and omission_audit['required_axiom_report_count'] == 120
            and omission_audit['static_consumer_sources_checked'] == 25
            and omission_audit['predecessor_key'] == historical_cost['source_fingerprint'],
            'Separate evaluator extraction independent review and author inventory')
    require(manifest['logical_origins'] == omission_inventory['current_logical_origin_order']
            == [name for name in historical_cost['logical_origins'] if name not in OMITTED_WHOLE_ORIGINS]
            and manifest['origin_ownership'] == [name for name in historical_cost['origin_ownership']
                                                if name not in OMITTED_WHOLE_ORIGINS]
            and (manifest['distinct_upstream_origin_count'], manifest['distinct_project_origin_count'],
                 manifest['distinct_logical_origin_count'], manifest['source_segment_count']) == (17, 7, 24, 26)
            and len(set(manifest['logical_origins'])) == 24
            and manifest['removed_whole_upstream_origins'] == OMITTED_WHOLE_ORIGINS
            and manifest['partially_omitted_current_origins'] == omission_overlay['partially_omitted_retained_origins']
            and manifest['historical_cost_origin_context'] == {
                key: historical_cost[key] for key in ('origin_ownership', 'logical_origins',
                'complete_origin_source_rows', 'distinct_upstream_origin_count', 'distinct_project_origin_count',
                'distinct_logical_origin_count', 'source_segment_count')},
            'Current evaluator ownership must remain distinct from historical full-origin scope')
    consumed_cost = read(OMISSION_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_cost['status'] == 'failed'
            and consumed_cost['source_fingerprint'] == historical_cost['source_fingerprint']
            and consumed_cost['module_order'] == HISTORICAL_MODULES
            and [row['module'] for row in consumed_cost['modules']] == HISTORICAL_MODULES[:5]
            and [row['status'] for row in consumed_cost['modules']] == ['passed'] * 4 + ['failed']
            and consumed_cost['accepted_axiom_report_count'] == consumed_cost['observed_axiom_report_count'] == 71
            and consumed_cost['modules'][-1]['limit_exceeded'] == 'wall_time'
            and consumed_cost['modules'][-1]['exit_code'] == -9
            and consumed_cost['modules'][-1]['axiom_audit']['observed_count'] == 0
            and consumed_cost['all_selected_mathematical_sources_freshly_checked'] is False,
            'Consumed cost120 timeout and exact accepted-prefix boundary')
    cost_marker = local_path(manifest['preserved_consumed_cost120_predecessor']['consumed_marker']['path'])
    verify([h.binding(cost_marker)], True)
    require(read(cost_marker)['source_fingerprint'] == consumed_cost['source_fingerprint']
            and manifest['preserved_consumed_cost120_predecessor']['source_fingerprint'] == consumed_cost['source_fingerprint'],
            'Consumed cost120 permanent marker differs')


    require(historical_omission_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                             for pin in HISTORICAL_OMISSION_SOURCE_PINS]
            == manifest['consumed_omission120_historical_physical_selection']
            and historical_omission['policy'] == POLICY and historical_omission['module_order'] == HISTORICAL_MODULES
            and historical_omission['source_fingerprint'] ==
                '1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06',
            'Consumed omission120 exact physical source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'cost_separate_review_scopes',
                'cost_separate_author_inventory_scopes', 'omission_separate_review_scope',
                'omission_separate_author_inventory_scope', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor', 'preserved_consumed_120_predecessor',
                'preserved_consumed_cost120_predecessor', 'historical_cost_origin_context',
                'origin_ownership', 'logical_origins', 'complete_origin_source_rows',
                'removed_whole_upstream_origins', 'partially_omitted_current_origins'):
        require(manifest[key] == historical_omission[key], 'Historical omission scope rebased: ' + key)
    require([index for index, (old, new) in enumerate(zip(historical_omission_selection, historical_comment_selection))
             if old != new] == [0, 1]
            and sum(row['bytes'] for row in historical_comment['sources']) ==
                historical_comment['selected_physical_source_bytes'] == 588571
            and manifest['comment_header_only_repair'] is True
            and manifest['comment_repair_historical_review_scopes_rebased'] is False
            and manifest['comment_repair_new_leaves_selected'] == [],
            'Only the diagnosed Core/Cached leading-comment repair may change')
    require(comment_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
            and comment_audit['reviewer'] == 'root'
            and comment_audit['source_author'] == 'nat_only_gap_review'
            and comment_audit['independent_of_source_author'] is True
            and comment_audit['direct_input_count'] == len(comment_audit['inputs']) == 32
            and manifest['comment_repair_separate_review_scope']['input_count'] == 32
            and manifest['comment_repair_separate_review_scope']['inputs'] == comment_audit['inputs']
            and comment_inventory['input_count'] == len(comment_inventory['inputs']) == 31
            and manifest['comment_repair_separate_author_inventory_scope']['input_count'] == 31
            and manifest['comment_repair_separate_author_inventory_scope']['inputs'] == comment_inventory['inputs']
            and comment_inventory['prospective_physical_sources'] == historical_comment['sources']
            and comment_inventory['source_variants'] == [{key: row[key] for key in ('module', 'original', 'candidate')}
                                                        for row in comment_correction['variants']]
            and comment_inventory['predecessor_source_fingerprint'] == historical_omission['source_fingerprint'],
            'Separate diagnosed comment repair review/inventory scope')
    consumed_omission = read(COMMENT_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_omission['status'] == 'failed'
            and consumed_omission['source_fingerprint'] == historical_omission['source_fingerprint']
            and consumed_omission['module_order'] == HISTORICAL_MODULES
            and [row['module'] for row in consumed_omission['modules']] == HISTORICAL_MODULES[:1]
            and consumed_omission['modules'][0]['status'] == 'failed'
            and consumed_omission['modules'][0]['exit_code'] == 1
            and consumed_omission['modules'][0]['limit_exceeded'] is None
            and consumed_omission['accepted_axiom_report_count'] == consumed_omission['observed_axiom_report_count'] == 0
            and consumed_omission['modules'][0]['axiom_audit']['unparsed_stdout'] ==
                comment_correction['actual_diagnostic'].strip()
            and consumed_omission['all_sources_snapshots_controls_runtime_unchanged'] is True
            and consumed_omission['all_selected_mathematical_sources_freshly_checked'] is False,
            'Actual consumed import-header failure and zero-report boundary')
    omission_marker = local_path(manifest['preserved_consumed_omission120_predecessor']['consumed_marker']['path'])
    verify([h.binding(omission_marker)], True)
    require(read(omission_marker)['source_fingerprint'] == consumed_omission['source_fingerprint']
            and manifest['preserved_consumed_omission120_predecessor']['source_fingerprint'] ==
                consumed_omission['source_fingerprint'], 'Consumed omission120 permanent marker differs')

    require(historical_comment_selection == [dict(zip(('path', 'bytes', 'sha256'), pin))
                                            for pin in HISTORICAL_COMMENT_SOURCE_PINS]
            == manifest['consumed_comment120_historical_physical_selection']
            and historical_comment['policy'] == POLICY and historical_comment['module_order'] == HISTORICAL_MODULES
            and historical_comment['source_fingerprint'] ==
                'cf693905054730e65c5f5dc7b79c8dd6a2544a459ebd689b3b42b1ceb68f5b94',
            'Consumed comment-repair120 exact source-policy identity')
    for key in ('reviewed_direct_inputs', 'reviewed_correction_inputs', 'reviewed_stable_inputs',
                'reviewed_stable_correction_inputs', 'reviewed_helper_inputs',
                'reviewed_diagnosed_helper_inputs', 'new_separate_review_scopes',
                'new_separate_author_inventory_scopes', 'cost_separate_review_scopes',
                'cost_separate_author_inventory_scopes', 'omission_separate_review_scope',
                'omission_separate_author_inventory_scope', 'comment_repair_separate_review_scope',
                'comment_repair_separate_author_inventory_scope', 'preserved_failed_predecessors',
                'preserved_accepted_predecessor', 'preserved_consumed_120_predecessor',
                'preserved_consumed_cost120_predecessor', 'preserved_consumed_omission120_predecessor',
                'historical_cost_origin_context', 'origin_ownership', 'logical_origins',
                'complete_origin_source_rows', 'removed_whole_upstream_origins',
                'partially_omitted_current_origins', 'accepted_70_historical_physical_selection',
                'consumed_120_historical_physical_selection', 'consumed_cost120_historical_physical_selection',
                'consumed_omission120_historical_physical_selection'):
        require(manifest[key] == historical_comment[key], 'Historical comment-repair scope rebased: ' + key)
    require([index for index, (old, new) in enumerate(zip(historical_comment_selection, actual_selection))
             if old != new] == [4]
            and sum(row['bytes'] for row in manifest['sources']) ==
                manifest['selected_physical_source_bytes'] == 588685
            and manifest['syntax_haslp_six_proof_repairs_only'] is True
            and manifest['syntax_haslp_historical_review_scopes_rebased'] is False
            and manifest['syntax_haslp_new_leaves_selected'] == [],
            'Only the six diagnosed Syntax child-observer proofs may change')
    require(haslp_audit['format'] == 'adwh-cached-syntax-haslp-independent-source-audit-v1'
            and haslp_audit['status'] == 'passed_source_only_review_not_compiled_or_measured'
            and haslp_audit['reviewer'] == 'root'
            and haslp_audit['source_author'] == 'reflection_evidence_review'
            and haslp_audit['independent_of_source_author'] is True
            and haslp_audit['direct_input_count'] == len(haslp_audit['inputs']) == 51
            and haslp_audit['author_input_count_verified'] == 50
            and manifest['syntax_haslp_separate_review_scope']['input_count'] == 51
            and manifest['syntax_haslp_separate_review_scope']['inputs'] == haslp_audit['inputs']
            and haslp_inventory['input_count'] == len(haslp_inventory['inputs']) == 50
            and manifest['syntax_haslp_separate_author_inventory_scope']['input_count'] == 50
            and manifest['syntax_haslp_separate_author_inventory_scope']['inputs'] == haslp_inventory['inputs']
            and haslp_inventory['prospective_physical_sources'] == manifest['sources']
            and haslp_audit['source_variant'] == haslp_inventory['source_variant']
                == {key: haslp_correction['variant'][key] for key in ('original', 'candidate')}
            and haslp_audit['correction_map'] == haslp_inventory['correction_map']
            and haslp_audit['exact_edit_count'] == haslp_correction['exact_source_edit_count'] == 6
            and haslp_audit['primary_interval_count_verified'] == 5
            and haslp_audit['exact_forward_inverse_and_complement_verified'] is True
            and haslp_audit['all_theorem_statements_header_imports_options_and_reports_literal'] is True
            and haslp_audit['historical_review_scopes_rebased'] is False
            and haslp_inventory['predecessor_key'] == haslp_audit['predecessor_key']
                == historical_comment['source_fingerprint'],
            'Separate diagnosed Syntax repair review/inventory scope')
    consumed_comment = read(HASLP_PREDECESSOR / 'attempts/complete-01/report.json')
    require(consumed_comment['status'] == 'failed'
            and consumed_comment['source_fingerprint'] == historical_comment['source_fingerprint']
            and consumed_comment['module_order'] == HISTORICAL_MODULES
            and [row['module'] for row in consumed_comment['modules']] == HISTORICAL_MODULES[:5]
            and [row['status'] for row in consumed_comment['modules']] == ['passed'] * 4 + ['failed']
            and consumed_comment['accepted_axiom_report_count'] == 71
            and consumed_comment['observed_axiom_report_count'] == 82
            and consumed_comment['modules'][-1]['exit_code'] == 1
            and consumed_comment['modules'][-1]['limit_exceeded'] is None
            and consumed_comment['modules'][-1]['axiom_audit']['observed_count'] == 11
            and consumed_comment['modules'][-1]['axiom_audit']['all_raw_axiom_names_permitted'] is False
            and consumed_comment['modules'][-1]['axiom_audit']['stderr_empty'] is True
            and [r['root'] for r in consumed_comment['modules'][-1]['axiom_audit']['raw_reports']]
                == HISTORICAL_REQUIRED[HISTORICAL_MODULES[4]]
            and 'sorryAx' in {axis for row in consumed_comment['modules'][-1]['axiom_audit']['raw_reports']
                             for axis in row['axioms']}
            and consumed_comment['seconds'] <= 30
            and consumed_comment['peak_child_rss_kib'] <= 1048576
            and consumed_comment['all_sources_snapshots_controls_runtime_unchanged'] is True
            and consumed_comment['all_selected_mathematical_sources_freshly_checked'] is False,
            'Actual consumed Syntax diagnostic and failed-module acceptance boundary')
    diagnostic = local_path(haslp_correction['observed_stdout']['path']).read_text()
    require(re.findall(r'^KernelCachedSyntaxCorrespondence\.lean:(\d+):\d+: error: unsolved goals$',
                       diagnostic, re.M) == ['50', '70', '76', '82', '88', '93'],
            'Actual six constructor-observer failure locations')
    comment_marker = local_path(manifest['preserved_consumed_comment120_predecessor']['consumed_marker']['path'])
    verify([h.binding(comment_marker)], True)
    require(read(comment_marker)['source_fingerprint'] == consumed_comment['source_fingerprint']
            and manifest['preserved_consumed_comment120_predecessor']['source_fingerprint'] ==
                consumed_comment['source_fingerprint']
            and manifest['preserved_consumed_comment120_predecessor']['report'] == haslp_correction['failed_report']
            and manifest['preserved_consumed_comment120_predecessor']['consumed_marker'] ==
                haslp_correction['consumed_marker'], 'Consumed comment-repair120 permanent marker differs')

    require(manifest['source_fingerprint_scope'] == {
                'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]},
            'Current source-fingerprint scope differs')

    require(manifest['source_fingerprint'] == fingerprint(sources), 'Source/policy fingerprint')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({r['path'] for r in controls}) == len(controls)
            and len({r['role'] for r in controls}) == len(controls), 'Repeated control identity/role')
    controls.append({**h.binding(HISTORICAL_MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'Source/control overlap')
    historical = read(ROOT / 'next-iteration/kernel-sliced-selector/SOURCE-BUNDLE.json')['physical_units'][0]
    origin_rows = [o['original'] for o in historical['origin_units']]
    origin_rows += [o['original'] for o in mapping['physical_units'][1]['source_segments'] if 'original' in o]
    origin_rows += [stable_audit['source'], helper_correction['original']]
    origin_rows += [syntax_overlay['source_variants'][1]['original'],
                    bulk_boundary['original'], literal_wording['original']]
    require(historical_cost['complete_origin_source_rows'] == origin_rows and len(origin_rows) == 33,
            'Historical full-origin source rows before evaluator extraction')
    current_origin_rows = [row for name, row in zip(historical_cost['logical_origins'], origin_rows)
                           if name not in OMITTED_WHOLE_ORIGINS]
    require(manifest['complete_origin_source_rows'] == current_origin_rows
            == omission_inventory['current_origin_source_rows'] and len(current_origin_rows) == 24,
            'Current evaluator projected origin source rows')
    required_inputs = (audit['audited_inputs'] + correction_audit['inputs'] + stable_audit['inputs']
                       + stable_correction_audit['inputs'] + helper_audit['inputs'] + diagnosed_audit['inputs']
                       + inventory['inputs'] + stable_inventory['inputs'] + helper_inventory['inputs']
                       + diagnosed_inventory['inputs']
                       + syntax_audit['inputs'] + sharing_audit['inputs'] + bulk_audit['inputs'] + literal_audit['inputs']
                       + syntax_inventory['inputs'] + sharing_inventory['inputs'] + bulk_inventory['inputs']
                       + literal_inventory['inputs']
                       + presentation_audit['inputs'] + count_audit['inputs']
                       + presentation_inventory['review_inputs'] + count_inventory['review_inputs']
                       + historical_selection + historical_cost_selection
                       + omission_audit['inputs'] + omission_inventory['inputs']
                       + historical_omission_selection + comment_audit['inputs'] + comment_inventory['inputs']
                       + historical_comment_selection + haslp_audit['inputs'] + haslp_inventory['inputs']
                       + origin_rows + mapping['core_layers_unchanged'])
    for component in ('kernel-legacy-core-selector', 'kernel-ordinary-fields-core'):
        overlay = read(ROOT / f'next-iteration/{component}/SOURCE-CORRESPONDENCE.json')
        required_inputs += [overlay['original_source'], overlay['candidate_source']]
    for row in required_inputs:
        actual = identity(row, h)
        require(actual['path'] in bound and all(bound[actual['path']][key] == actual[key]
                for key in ('bytes', 'sha256')), 'Reviewed input, origin or overlay not bound')
    for path in list(HISTORICAL_FIXED) + [HISTORICAL_HERE / 'run_gate.py', HISTORICAL_HERE / 'PROTOCOL.md',
                              HISTORICAL_HERE / 'AUTHORING.md', HISTORICAL_HERE / 'CONTROL-CORRESPONDENCE.json']:
        require(str(path) in bound, 'Execution/selection control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls), 'Snapshot census')
    correspondence = verify_correspondence(mapping, h)
    proof_overlay = verify_proof_correction(correction, h)
    leaf_overlays = verify_leaf_corrections(stable_correction, helper_correction, h)
    diagnosed_overlay = verify_diagnosed_helper_repair(diagnosed_repair, h)
    observer_syntax_result = verify_observer_syntax_overlay(syntax_overlay, h)
    proof_sharing_result = verify_cached_proof_sharing(sharing_overlay, sharing_correspondence, mapping, h)
    bulk_literal_result = verify_bulk_and_literal_maps(bulk_map, bulk_boundary, literal_wording, h)
    cost_result = verify_cost_overlays(presentation_overlay, presentation_census, count_overlay,
                                       historical_120, h, guard)
    omission_result = verify_evaluator_omissions(omission_overlay, omission_census, omission_inventory,
                                                  omission_audit, historical_cost, h, guard)
    comment_result = verify_comment_header_repair(comment_correction, h)
    haslp_result = verify_syntax_haslp_repair(haslp_correction, haslp_primary, h)
    compiler_path = args.lean.resolve()
    h.TOOLCHAIN = compiler_path.parent.parent
    pin, compiler = read(PIN), h.binding(compiler_path)
    require(compiler_path.name == 'lean' and pin['version'] == '4.35.0'
            and pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and all(compiler[key] == pin['binaries']['lean'][key] for key in ('bytes', 'sha256')),
            'Pinned Lean compiler differs')
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in read(RUNTIME_REFERENCE)['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((h.TOOLCHAIN / 'lib/lean').glob('*.so'))]
    require(len(runtime) == 5 and {Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime}
            == expected_runtime, 'Pinned runtime differs')
    verify(sources + controls + [compiler] + runtime)
    return {'sources': sources, 'controls': controls, 'roots': HISTORICAL_REQUIRED,
            'source_fingerprint': fingerprint(sources), 'compiler': compiler, 'runtime': runtime,
            'correspondence': correspondence, 'proof_overlay': proof_overlay, 'leaf_overlays': leaf_overlays,
            'review': h.binding(BUNDLED / 'SOURCE-AUDIT.json'),
            'correction_review': h.binding(CORRECTION / 'SOURCE-AUDIT.json'),
            'stable_review': h.binding(STABLE / 'SOURCE-AUDIT.json'),
            'stable_correction_review': h.binding(STABLE_CORRECTION / 'SOURCE-AUDIT.json'),
            'helper_review': h.binding(DIRECT / 'SOURCE-AUDIT.json'),
            'diagnosed_helper_review': h.binding(DIAGNOSED / 'SOURCE-AUDIT.json'),
            'diagnosed_helper_overlay': diagnosed_overlay,
            'failed_helper_predecessor': manifest['preserved_failed_predecessors'][-1],
            'accepted_70_predecessor': manifest['preserved_accepted_predecessor'],
            'observer_syntax_overlay': observer_syntax_result,
            'cached_proof_sharing_overlay': proof_sharing_result,
            'bulk_literal_correspondence': bulk_literal_result,
            'cost_overlays': cost_result,
            'consumed_120_predecessor': manifest['preserved_consumed_120_predecessor'],
            'cost_separate_reviews': {name: {'audit': h.binding(path / 'SOURCE-AUDIT.json'), 'input_count': count}
                                      for name, path, count in [('presentation', PRESENTATION, 210),
                                        ('syntax_count_sharing', COUNT_SHARING, 214)]},
            'new_separate_reviews': {name: {'audit': h.binding(path / 'SOURCE-AUDIT.json'), 'input_count': count}
                                     for name, path, count in [('observer_syntax', SYNTAX, 33),
                                       ('cached_proof_sharing', SHARING, 26), ('bulk_bound', BULK, 119),
                                       ('literal_forward', LITERAL, 16)]},
            'syntax_haslp_overlay': haslp_result,
            'syntax_haslp_review': h.binding(HASLP_REPAIR / 'SOURCE-AUDIT.json'),
            'consumed_comment120_predecessor': manifest['preserved_consumed_comment120_predecessor'],
            'comment_repair_overlay': comment_result,
            'comment_repair_review': h.binding(COMMENT_REPAIR / 'SOURCE-AUDIT.json'),
            'consumed_omission120_predecessor': manifest['preserved_consumed_omission120_predecessor'],
            'omission_overlay': omission_result,
            'omission_review': h.binding(OMISSION / 'SOURCE-AUDIT.json'),
            'consumed_cost120_predecessor': manifest['preserved_consumed_cost120_predecessor'],
            'historical_cost_origin_context': manifest['historical_cost_origin_context'],
            'origin_ownership': manifest['origin_ownership'], 'origin_sources': current_origin_rows,
            'supplemental_ownership': manifest['source_segment_ownership'][:2],
            'inherited_omissions': manifest['inherited_omissions']}



def verify_wrapper_proof_repair(correction, h):
    require(correction['format'] == 'adwh-cached-record-wrapper-preexecution-proof-robustness-v1'
            and correction['author'] == 'book_scope_review'
            and correction['trigger_kind'] == 'independent_source_review_observation_not_observed_compiler_failure'
            and correction['edit_count'] == len(correction['edits']) == 4
            and correction['historical_review_rebased'] is False
            and correction['failed_gate_or_compiler_diagnostic_for_this_leaf_exists'] is False,
            'Separate pre-execution Wrapper proof-overlay scope')
    identity(correction['original'], h)
    identity(correction['candidate'], h)
    original = local_path(correction['original']['path']).read_bytes()
    candidate = local_path(correction['candidate']['path']).read_bytes()
    expected = [('defeq_same_body', 158, b'  rfl\n'),
                ('lazy_literal_add.fold', 401, b'    rfl\n'),
                ('infer_nat_body', 679, b'  rfl\n'),
                ('annotate_nat_body', 736, b'  rfl\n')]
    require(apply_edits(original, correction['edits'], 'original_start_byte',
                        'original_text', 'replacement_text') == candidate
            and apply_edits(candidate, correction['edits'], 'candidate_start_byte',
                            'replacement_text', 'original_text') == original,
            'Exact four-line forward and inverse Wrapper reconstruction')
    old_cursor = new_cursor = 0
    complements = []
    for edit, (name, line, before) in zip(correction['edits'], expected):
        after = before.replace(b'rfl', b'all_goals rfl')
        old_start, new_start = edit['original_start_byte'], edit['candidate_start_byte']
        require(edit['declaration_or_local_proof'] == name
                and edit['original_line'] == edit['candidate_line'] == line
                and edit['original_text'].encode() == before
                and edit['replacement_text'].encode() == after
                and edit['original_end_byte_exclusive'] == old_start + len(before)
                and edit['candidate_end_byte_exclusive'] == new_start + len(after)
                and original[:old_start].count(b'\n') + 1 == line
                and candidate[:new_start].count(b'\n') + 1 == line,
                'Only the four independently reviewed fallback proof lines may change')
        part = original[old_cursor:old_start]
        require(part == candidate[new_cursor:new_start], 'Wrapper unchanged complement differs')
        complements.append({'original_start_byte': old_cursor, 'original_end_byte_exclusive': old_start,
                            'candidate_start_byte': new_cursor, 'candidate_end_byte_exclusive': new_start,
                            'bytes': len(part), 'sha256': hashlib.sha256(part).hexdigest()})
        old_cursor, new_cursor = old_start + len(before), new_start + len(after)
    part = original[old_cursor:]
    require(part == candidate[new_cursor:], 'Wrapper final complement differs')
    complements.append({'original_start_byte': old_cursor, 'original_end_byte_exclusive': len(original),
                        'candidate_start_byte': new_cursor, 'candidate_end_byte_exclusive': len(candidate),
                        'bytes': len(part), 'sha256': hashlib.sha256(part).hexdigest()})
    pattern = rb'(?ms)^(?:private )?theorem\s+.*?\s*:='
    require(complements == correction['unchanged_complement_segments']
            and re.findall(pattern, original) == re.findall(pattern, candidate)
            and len(re.findall(pattern, original)) == 44
            and original.count(b'\n') == candidate.count(b'\n')
            and correction['unchanged_public_and_private_theorem_header_count'] == 44
            and correction['unchanged_public_theorem_and_report_count'] == 41
            and correction['unchanged_definition_count'] == 7
            and correction['unchanged_structure_count'] == 2
            and correction['imports_options_names_statements_and_report_order_unchanged'] is True,
            'All Wrapper statements, definitions, imports, options and reports remain literal')
    return {'original': correction['original'], 'candidate': correction['candidate'],
            'exact_proof_edit_count': 4, 'all_44_theorem_statements_literal': True,
            'unchanged_complement_exact': True, 'own_wrapper_body_success_assumed': False,
            'preexecution_review_observation_not_failed_compiler_diagnostic': True}


def verify_wrapper_primary_intervals(document, expected_count, h):
    require(len(document['intervals']) == expected_count, 'New leaf exact primary interval count')
    retained = 0
    for row in document['intervals']:
        identity(row['source'], h)
        lines = local_path(row['source']['path']).read_bytes().splitlines(keepends=True)
        first, last = row['start_line'], row['end_line_inclusive']
        require(1 <= first <= last <= len(lines), 'Primary source interval bounds')
        body = b''.join(lines[first - 1:last])
        require(body == row['text'].encode() and len(body) == row['bytes']
                and hashlib.sha256(body).hexdigest() == row['sha256'], 'Exact primary interval differs')
        if 'selected_owner' in row:
            identity(row['selected_owner'], h)
            selected = local_path(row['selected_owner']['path']).read_bytes()
            selected_lines = selected.splitlines(keepends=True)
            a, b = row['selected_start_line'], row['selected_end_line_inclusive']
            require(1 <= a <= b <= len(selected_lines)
                    and b''.join(selected_lines[a - 1:b]) == body
                    and selected.count(body) == row['literal_occurrences_in_selected_owner'] == 1
                    and row['literal_exact_match'] is True, 'Actual retained implementation interval differs')
            retained += 1
    return {'exact_interval_count': expected_count, 'literal_selected_owner_intervals': retained}


def wrapper136_historical_preflight(args, h, guard):
    # This is the unchanged predecessor's metadata/source scope at its original
    # seven-owner identity. It performs no Lean/compiler/native execution.
    historical_plan = historical_preflight(args, h, guard)
    historical_manifest = read(HISTORICAL_MANIFEST)
    manifest = read(WRAPPER_MANIFEST)
    frame_inventory = read(FRAME / 'SOURCE-INVENTORY.json')
    frame_audit = read(FRAME / 'SOURCE-AUDIT.json')
    wrapper_inventory = read(WRAPPER / 'SOURCE-INVENTORY.json')
    wrapper_audit = read(WRAPPER / 'SOURCE-AUDIT.json')
    repair = read(WRAPPER_REPAIR / 'PROOF-CORRECTION.json')
    repair_inventory = read(WRAPPER_REPAIR / 'SOURCE-INVENTORY.json')
    repair_audit = read(WRAPPER_REPAIR / 'SOURCE-AUDIT.json')
    require(manifest['format'] == WRAPPER_MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY and manifest['module_order'] == MODULES
            and manifest['prepared_objects'] == [] and manifest['export_targets'] == []
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 136
            and manifest['expected_artifact_count'] == 14
            and manifest['ordered_report_counts'] == [1, 25, 20, 25, 8, 16, 41]
            and manifest['selected_physical_source_bytes'] == 601977,
            'Current Wrapper136 source/report/output/resource selection')
    sources, done = [], set()
    require(len(manifest['sources']) == len(WRAPPER_SOURCE_PINS) == len(MODULES) == 7, 'Current source count')
    for row, module, pin in zip(manifest['sources'], MODULES, WRAPPER_SOURCE_PINS):
        require(row['module'] == module and (row['path'], row['bytes'], row['sha256']) == pin
                and row['module_format'] is False
                and row['expected_default_output_suffixes'] == ['.olean', '.ilean']
                and row['fully_qualified_roots'] == REQUIRED[module]
                and row['raw_source_print_identifiers'] == RAW_REQUIRED[module],
                'Current frozen physical source/report pin: ' + module)
        require(all(name in done or name == 'Init' or name.startswith(('Init.', 'Std.'))
                    for name in row['imports']), 'External experimental or forward current import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']})
        done.add(module)
    selected = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in manifest['sources']]
    require(selected == wrapper_inventory['selected_physical_sources'][:-1] + [repair['candidate']]
            and [{key: row[key] for key in ('path', 'bytes', 'sha256')}
                 for row in wrapper_audit['selected_physical_sources']] == wrapper_inventory['selected_physical_sources']
            and wrapper_inventory['source'] == wrapper_audit['source'] == repair['original']
            and selected[5] == frame_inventory['source'] == frame_audit['new_source']
            and sum(len(REQUIRED[name]) for name in MODULES) == 136
            and len({root for name in MODULES for root in REQUIRED[name]}) == 136
            and sum(row['bytes'] for row in selected) == 601977,
            'Exact current owner closure differs from reviewed Wrapper plus separate repair')
    require(manifest['historical_complete120_review_context'] == {
                key: historical_manifest[key] for key in HISTORICAL_REVIEW_KEYS}
            and manifest['historical_complete120_selection_context'] == {
                key: historical_manifest[key] for key in HISTORICAL_SELECTION_KEYS}
            and manifest['historical_independent_review_scope_count'] == 15
            and manifest['current_total_separate_independent_review_scope_count'] == 18
            and manifest['historical_reviews_rebased'] is False,
            'All fifteen recorded historical review scopes stay at original input identities')
    scopes = [('helper_frame', FRAME, frame_inventory, frame_audit, 232, 23, 'root', 'book_scope_review'),
              ('original_wrapper', WRAPPER, wrapper_inventory, wrapper_audit, 326, 50, 'book_scope_review', 'root'),
              ('wrapper_proof_robustness', WRAPPER_REPAIR, repair_inventory, repair_audit,
               REPAIR_AUTHOR_INPUT_COUNT, REPAIR_REVIEW_INPUT_COUNT, 'book_scope_review', 'root')]
    expected_statuses = {
        'helper_frame': 'passed_source_only_review_not_compiled',
        'original_wrapper': 'passed_conditional_source_review_with_separate_preexecution_tactic_overlay_requested',
        'wrapper_proof_robustness': 'passed_source_only_not_compiled',
    }
    required_inputs = []
    for label, directory, inv, audit, author_count, review_count, author, reviewer in scopes:
        author_field = inv.get('source_author', inv.get('author'))
        audit_author = audit.get('source_author', audit.get('correction_author'))
        independent = audit.get('independent_of_source_author', audit.get('independent_of_correction_author'))
        require(author_field == author and audit_author == author and audit['reviewer'] == reviewer
                and independent is True and audit['status'] == expected_statuses[label]
                and inv['input_count'] == len(inv['inputs']) == author_count
                and audit['direct_input_count'] == len(audit['inputs']) == review_count
                and manifest['current_separate_author_inventory_scopes'][label]['inputs'] == inv['inputs']
                and manifest['current_separate_author_inventory_scopes'][label]['input_count'] == author_count
                and manifest['current_separate_review_scopes'][label]['inputs'] == audit['inputs']
                and manifest['current_separate_review_scopes'][label]['input_count'] == review_count,
                'Separate new leaf/overlay review scope: ' + label)
        for name in ('SOURCE-INVENTORY.json', 'SOURCE-AUDIT.json', 'SOURCE-REVIEW.md'):
            require(manifest['current_separate_review_scopes'][label][name] == {
                        'path': (directory / name).relative_to(ROOT).as_posix(),
                        **{key: h.binding(directory / name)[key] for key in ('bytes', 'sha256')}},
                    'New review/inventory identity pin: ' + label + '/' + name)
        required_inputs += inv['inputs'] + audit['inputs']
    require(frame_audit['new_required_axiom_reports'] == frame_inventory['required_new_axiom_reports']
                == REQUIRED['KernelCachedHelperFrame']
            and wrapper_inventory['required_new_axiom_reports'] == REQUIRED['KernelCachedRecordWrapper']
            and wrapper_audit['independent_scope_contains_future_overlay'] is False
            and manifest['original_wrapper_review_rebased_to_overlay'] is False
            and manifest['frame_historical_selection_rebased_to_current_owners'] is False,
            'Frame/Wrapper reports and historical versus separate correction boundary')
    require(repair_inventory['source'] == repair_audit['source'] == repair['candidate']
            and repair_inventory['selected_physical_sources'] == repair_audit['selected_physical_sources'] == selected
            and repair_audit['author_input_count_verified'] == 333
            and repair_audit['exact_edits_verified'] == 4
            and repair_audit['unchanged_complement_segments_verified'] == 5
            and repair_audit['old_and_new_theorem_headers_equal_count'] == 44
            and repair_audit['old_and_new_public_report_count'] == 41
            and repair_audit['historical_source_review_scopes_rebased'] is False
            and repair_audit['compiler_failure_observed'] is False,
            'Separate root Wrapper robustness review at its actual corrected source')
    proof_overlay = verify_wrapper_proof_repair(repair, h)
    frame_primary = verify_wrapper_primary_intervals(read(FRAME / 'PRIMARY-SOURCE-INTERVALS.json'), 7, h)
    wrapper_primary = verify_wrapper_primary_intervals(read(WRAPPER / 'PRIMARY-SOURCE-INTERVALS.json'), 30, h)
    current_origins = historical_manifest['complete_origin_source_rows'][:21] + [
        historical_manifest['complete_origin_source_rows'][-1], frame_inventory['source'], repair['original']]
    require(manifest['logical_origins'] == wrapper_inventory['current_logical_origins']
            and manifest['complete_origin_source_rows'] == current_origins
            and len(set(manifest['logical_origins'])) == len(current_origins) == 24
            and manifest['origin_ownership'] == historical_manifest['origin_ownership']
            and manifest['source_segment_ownership'] == historical_manifest['source_segment_ownership'][:11]
                + MODULES[4:]
            and (manifest['distinct_upstream_origin_count'], manifest['distinct_project_origin_count'],
                 manifest['distinct_logical_origin_count'], manifest['source_segment_count']) == (17, 7, 24, 26)
            and manifest['current_mathematical_leaf_selection'] == ['Literal8', 'HelperFrame16', 'Wrapper41']
            and manifest['historical_Syntax_Bulk_sources_are_context_only'] is True
            and manifest['full_original_driver_native_API_preserved'] is False
            and manifest['later_original_driver_restoration_required'] is True
            and manifest['six_original_callback_slots_retained'] is True,
            'Current ownership and omitted-driver restoration boundary')
    consumed = read(WRAPPER_PREDECESSOR / 'attempts/complete-01/report.json')
    predecessor = manifest['preserved_consumed_SyntaxHasLP120_predecessor']
    require(consumed['status'] == 'failed'
            and consumed['source_fingerprint'] == historical_manifest['source_fingerprint']
                == 'a3553975ea502e13ffc11acd48dc4717fafc4e81d1478f977d1fff33e9a578f6'
            and consumed['module_order'] == HISTORICAL_MODULES
            and [row['module'] for row in consumed['modules']] == HISTORICAL_MODULES
            and [row['status'] for row in consumed['modules']] == ['passed'] * 6 + ['failed']
            and consumed['accepted_axiom_report_count'] == consumed['observed_axiom_report_count'] == 112
            and consumed['modules'][-1]['limit_exceeded'] == 'wall_time'
            and consumed['modules'][-1]['exit_code'] == -9
            and consumed['modules'][-1]['axiom_audit']['observed_count'] == 0
            and consumed['modules'][-1]['stdout']['bytes'] == consumed['modules'][-1]['stderr']['bytes'] == 0
            and len(consumed['artifacts']) == 12
            and consumed['all_sources_snapshots_controls_runtime_unchanged'] is True
            and consumed['all_selected_mathematical_sources_freshly_checked'] is False,
            'Actual consumed112 prefix and unaccepted Literal boundary')
    marker = local_path(predecessor['consumed_marker']['path'])
    verify([identity(predecessor['consumed_marker'], h)], True)
    require(read(marker)['source_fingerprint'] == consumed['source_fingerprint']
            and predecessor['source_fingerprint'] == consumed['source_fingerprint']
            and manifest['source_fingerprint'] == fingerprint(sources)
            and manifest['source_fingerprint'] != consumed['source_fingerprint']
            and manifest['source_fingerprint_scope'] == {
                'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]},
            'New genuine source closure and permanent consumed predecessor key')
    require(manifest['own_current_wrapper_body_success_assumed'] is False
            and manifest['query_callback_and_actual_stored_annotation_premises_remain_explicit'] is True
            and manifest['whole_query_cached_success_claimed'] is False
            and manifest['original_GroupChecked_claimed'] is False
            and manifest['stock_numeral_theorem_claimed'] is False
            and manifest['complete_gate_acceptance_or_budget_fit_claimed_before_run'] is False,
            'Conditional wrapper result must not be promoted to the final query or record theorem')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({row['path'] for row in controls}) == len(controls)
            and len({row['role'] for row in controls}) == len(controls), 'Repeated current control path or role')
    controls.append({**h.binding(WRAPPER_MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'Current source/control overlap')
    for row in historical_plan['sources'] + historical_plan['controls']:
        required_inputs.append({**row, 'path': Path(row['path']).relative_to(ROOT).as_posix()})
    required_inputs += current_origins
    for row in required_inputs:
        actual = identity(row, h)
        require(actual['path'] in bound and all(bound[actual['path']][key] == actual[key]
                    for key in ('bytes', 'sha256')), 'Historical or new reviewed input omitted from current binding')
    for path in list(WRAPPER_FIXED) + [WRAPPER_HERE / 'run_gate.py', WRAPPER_HERE / 'PROTOCOL.md',
                              WRAPPER_HERE / 'AUTHORING.md', WRAPPER_HERE / 'CONTROL-CORRESPONDENCE.json']:
        require(str(path) in bound, 'Current execution/selection control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls), 'Current snapshot census')
    verify(sources + controls + [historical_plan['compiler']] + historical_plan['runtime'])
    return {**historical_plan, 'sources': sources, 'controls': controls, 'roots': REQUIRED,
            'source_fingerprint': fingerprint(sources), 'origin_sources': current_origins,
            'origin_ownership': manifest['origin_ownership'],
            'supplemental_ownership': manifest['source_segment_ownership'][:2],
            'consumed_haslp120_predecessor': predecessor,
            'wrapper_separate_reviews': manifest['current_separate_review_scopes'],
            'wrapper_proof_overlay': proof_overlay,
            'wrapper_primary_intervals': {'helper_frame': frame_primary, 'original_wrapper': wrapper_primary}}




def verify_exact_complements(row, h):
    result = verify_recorded_overlay(row, len(row['exact_source_edits']), h)
    original = local_path(row['original']['path']).read_bytes()
    candidate = local_path(row['candidate']['path']).read_bytes()
    complements, old_cursor, new_cursor = [], 0, 0
    for edit in row['exact_source_edits']:
        before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
        a, b = edit['original_start_byte'], edit['candidate_start_byte']
        require(original[a:a + len(before)] == before and candidate[b:b + len(after)] == after,
                'Recorded current proof edit offsets differ')
        part = original[old_cursor:a]
        require(part == candidate[new_cursor:b], 'Unchanged proof-overlay complement differs')
        complements.append({'original_start_byte': old_cursor, 'original_end_byte_exclusive': a,
                            'candidate_start_byte': new_cursor, 'candidate_end_byte_exclusive': b,
                            'bytes': len(part), 'sha256': hashlib.sha256(part).hexdigest()})
        old_cursor, new_cursor = a + len(before), b + len(after)
    part = original[old_cursor:]
    require(part == candidate[new_cursor:], 'Final unchanged proof-overlay complement differs')
    complements.append({'original_start_byte': old_cursor, 'original_end_byte_exclusive': len(original),
                        'candidate_start_byte': new_cursor, 'candidate_end_byte_exclusive': len(candidate),
                        'bytes': len(part), 'sha256': hashlib.sha256(part).hexdigest()})
    require(complements == row['unchanged_complement_segments'], 'Exact complement inventory differs')
    return {**result, 'exact_unchanged_complement_count': len(complements)}


def verify_boolean_rewrite(overlay, correspondence, grammar, h):
    require(overlay['format'] == 'adwh-cached-boolean-subtype-certificate-rewrite-overlay-v1'
            and overlay['author'] == 'reflection_evidence_review'
            and overlay['proof_edits_per_source'] == 32 and len(overlay['variants']) == 2
            and overlay['physical_owner_axiom_report_count_unchanged'] == 25
            and overlay['added_propositions_or_assumptions'] == []
            and overlay['source_option_or_resource_change'] is False,
            'Boolean32 proof-only scope')
    labels = ['bvar', 'sort', 'const', 'lit', 'fvar_true', 'fvar_false', 'app_true', 'app_false',
              'lam_true', 'lam_false', 'forall_true', 'forall_false', 'let_body',
              'let_value_false', 'let_type_false', 'proj']
    summaries, proof_lists = [], []
    for index, row in enumerate(overlay['variants']):
        require(row['label'] == ('physical_evaluator_owner' if index == 0 else 'full_native_ExprOpsC')
                and row['proof_edit_count'] == 32 and row['documentation_edit_count'] == (1 - index)
                and row['exact_edit_count'] == len(row['exact_source_edits']) == (33 - index),
                'Boolean32 native/ordinary edit census')
        summaries.append(verify_exact_complements(row, h))
        original = local_path(row['original']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        proof_edits = [edit for edit in row['exact_source_edits']
                       if edit['kind'] == 'Bool_equality_subtype_certificate_proof_only']
        require(len(proof_edits) == 32
                and [edit['constructor_branch'] for edit in proof_edits] == labels * 2,
                'Boolean32 exact constructor certificate order')
        proof_lists.append([(edit['original_text'], edit['replacement_text']) for edit in proof_edits])
        for j, edit in enumerate(proof_edits):
            walk, plain = ('wscopedBXP', 'wscopedBP') if j < 16 else ('leavesSubXP', 'leavesSubP')
            start = original.index(('def ' + walk + ' ').encode())
            stop = original.index(('\ndef ' + ('wscopedBC' if j < 16 else 'leavesSubC') + ' ').encode(), start)
            a = edit['original_start_byte']
            require(edit['owner'] == 'ConLeche.Expr.' + walk and start <= a < stop
                    and re.fullmatch(r'by rw \[' + plain + r'\]; simp \[[^\n\]]*\]', edit['original_text'])
                    and edit['replacement_text'].startswith('by')
                    and 'rw [' + plain + '.eq_def, hcut]' in edit['replacement_text'],
                    'Boolean rewrite is confined to the actual named equality-proof field')
        for edit in row['exact_source_edits']:
            before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
            require(edit['original_text_bytes'] == len(before) and edit['replacement_text_bytes'] == len(after)
                    and edit['original_text_sha256'] == hashlib.sha256(before).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after).hexdigest()
                    and edit['original_line_start'] == original[:edit['original_start_byte']].count(b'\n') + 1
                    and edit['candidate_line_start'] == candidate[:edit['candidate_start_byte']].count(b'\n') + 1,
                    'Boolean proof edit text/hash/line identity')
        documentation = [edit for edit in row['exact_source_edits'] if edit['kind'] == 'documentation_only']
        require(len(documentation) == (1 - index)
                and (index == 1 or (documentation[0]['original_text'] == ''
                    and documentation[0]['original_start_byte'] == documentation[0]['candidate_start_byte'] == 0
                    and documentation[0]['replacement_text'].startswith('/- Thirty-two'))),
                'Only the physical ordinary scope comment may be added')
    require(proof_lists[0] == proof_lists[1], 'Native/ordinary certificate substitutions differ')
    blocks = correspondence['matched_actual_and_native_walk_blocks']
    observed = []
    for row in overlay['variants']:
        original = local_path(row['original']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        pairs = []
        for block in blocks[row['label']]:
            left = original[block['original_start_byte']:block['original_end_byte_exclusive']]
            right = candidate[block['candidate_start_byte']:block['candidate_end_byte_exclusive']]
            require(len(left) == block['original_bytes'] and len(right) == block['candidate_bytes']
                    and hashlib.sha256(left).hexdigest() == block['original_sha256']
                    and hashlib.sha256(right).hexdigest() == block['candidate_sha256'],
                    'Full actual/native Boolean walk block identity')
            pairs.append((left, right))
        observed.append(pairs)
    require(observed[0] == observed[1] and len(observed[0]) == 2
            and correspondence['physical_variant'] == overlay['variants'][0]['candidate']
            and correspondence['full_native_variant'] == overlay['variants'][1]['candidate']
            and correspondence['full_original_driver_API_restored_in_ordinary_owner'] is False,
            'Exact native/ordinary block correspondence and driver boundary')
    require(len(grammar['variants']) == 2, 'Preserved draft grammar-correction source count')
    for index, row in enumerate(grammar['variants']):
        identity(row['original_preserved_source'], h)
        original = local_path(row['original_preserved_source']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        require(row['candidate'] == overlay['variants'][index]['candidate']
                and row['edit_count'] == len(row['exact_source_edits']) == 22
                and apply_edits(original, row['exact_source_edits'], 'original_start_byte',
                                'original_text', 'replacement_text') == candidate
                and apply_edits(candidate, row['exact_source_edits'], 'candidate_start_byte',
                                'replacement_text', 'original_text') == original,
                'Exact preserved draft forward/inverse goal-parenthesization correction')
        for edit in row['exact_source_edits']:
            match = re.fullmatch(r'(\s*change [A-Za-z_][A-Za-z0-9_]* = )(.*&&.*)\n', edit['original_text'])
            require(match is not None and edit['replacement_text'] == match[1] + '(' + match[2] + ')\n',
                    'Only the complete Bool RHS is parenthesized in a draft correction')
    return {'variants': summaries, 'same_32_certificate_edits_in_each_representation': True,
            'full_original_and_candidate_block_pairs': 2, 'new_declarations_or_axioms': [],
            'native_companion_is_context_only': True, 'unmeasured_cost_hypothesis': True}


def verify_literal_scope_repair(correction, h):
    require(correction['format'] == 'adwh-cached-literal-diagnosed-scope-proof-repair-v1'
            and correction['author'] == 'reflection_evidence_review'
            and correction['exact_source_edit_count'] == 2,
            'Separate diagnosed Literal scope-proof repair')
    result = verify_exact_complements(correction, h)
    original = local_path(correction['original']['path']).read_bytes()
    candidate = local_path(correction['candidate']['path']).read_bytes()
    for edit, name, line in zip(correction['exact_source_edits'], ['cached_head_nat', 'cached_full_nat'], [111, 127]):
        require(edit['theorem'] == name and edit['original_line'] == edit['candidate_line'] == line
                and edit['original_text'] == 'rfl'
                and edit['replacement_text'] == '(by unfold natLiteral; simp only [Expr.wscopedB])'
                and original[:edit['original_start_byte']].count(b'\n') + 1 == line
                and candidate[:edit['candidate_start_byte']].count(b'\n') + 1 == line,
                'Only the two actual diagnosed scope proof arguments may change')
    pattern = rb'(?ms)^(?:private )?theorem\s+.*?\s*:='
    require(re.findall(pattern, original) == re.findall(pattern, candidate)
            and len(re.findall(pattern, original)) == 9
            and original.count(b'\n') == candidate.count(b'\n') == 150
            and correction['unchanged_report_roots'] == RAW_REQUIRED['KernelCachedLiteralForward'],
            'Literal statement, line and report preservation')
    return {**result, 'all_9_theorem_statements_literal': True,
            'actual_literal_scope_equation_explicit': True, 'new_assumptions_or_declarations': []}


def boolean_literal_historical_preflight(args, h, guard):
    previous_plan = wrapper136_historical_preflight(args, h, guard)
    previous = read(WRAPPER_MANIFEST)
    manifest = read(BOOLEAN_LITERAL_MANIFEST)
    boolean_overlay = read(BOOLEAN_REWRITE / 'PROOF-OVERLAY.json')
    boolean_correspondence = read(BOOLEAN_REWRITE / 'SOURCE-CORRESPONDENCE.json')
    boolean_grammar = read(BOOLEAN_REWRITE / 'SOURCE-GRAMMAR-CORRECTION.json')
    boolean_inventory = read(BOOLEAN_REWRITE / 'SOURCE-INVENTORY.json')
    boolean_audit = read(BOOLEAN_REWRITE / 'SOURCE-AUDIT.json')
    literal_correction = read(LITERAL_REPAIR / 'PROOF-CORRECTION.json')
    literal_inventory = read(LITERAL_REPAIR / 'SOURCE-INVENTORY.json')
    literal_audit = read(LITERAL_REPAIR / 'SOURCE-AUDIT.json')
    require(manifest['format'] == BOOLEAN_LITERAL_MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY and manifest['module_order'] == MODULES
            and manifest['prepared_objects'] == [] and manifest['export_targets'] == []
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 136
            and manifest['expected_artifact_count'] == 14
            and manifest['ordered_report_counts'] == [1, 25, 20, 25, 8, 16, 41]
            and manifest['selected_physical_source_bytes'] == 604677,
            'Combined Boolean32/Literal2 complete136 selection')
    sources, done = [], set()
    require(len(manifest['sources']) == len(BOOLEAN_LITERAL_SOURCE_PINS) == len(MODULES) == 7, 'Combined source count')
    for row, module, pin in zip(manifest['sources'], MODULES, BOOLEAN_LITERAL_SOURCE_PINS):
        require(row['module'] == module and (row['path'], row['bytes'], row['sha256']) == pin
                and row['module_format'] is False and row['expected_default_output_suffixes'] == ['.olean', '.ilean']
                and row['fully_qualified_roots'] == REQUIRED[module]
                and row['raw_source_print_identifiers'] == RAW_REQUIRED[module], 'Combined physical source/report pin')
        require(all(name in done or name == 'Init' or name.startswith(('Init.', 'Std.'))
                    for name in row['imports']), 'External experimental or forward combined import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']})
        done.add(module)
    current = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in manifest['sources']]
    old = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in previous['sources']]
    require([i for i, pair in enumerate(zip(old, current)) if pair[0] != pair[1]] == [1, 4]
            and old[1] == boolean_overlay['variants'][0]['original']
            and current[1] == boolean_overlay['variants'][0]['candidate'] == boolean_inventory['physical_variant']
            and old[4] == literal_correction['original']
            and current[4] == literal_correction['candidate'] == literal_inventory['source_variant']['candidate']
            and sum(row['bytes'] for row in current) == 604677
            and len({root for roots in REQUIRED.values() for root in roots}) == 136,
            'Only the exact reviewed Cached proof fields and diagnosed Literal proof arguments change')
    require(manifest['preserved_Wrapper136_review_context'] == {key: previous[key] for key in WRAPPER_REVIEW_KEYS}
            and manifest['preserved_Wrapper136_selection_context'] == {key: previous[key] for key in WRAPPER_SELECTION_KEYS}
            and manifest['historical_independent_review_scope_count'] == 18
            and manifest['current_total_separate_independent_review_scope_count'] == 20
            and manifest['historical_reviews_rebased'] is False,
            'All eighteen predecessor source-review scopes stay at their exact original inputs')
    required_inputs = []
    for label, directory, inv, audit, author_count, review_count, reviewer, status in [
            ('Boolean32', BOOLEAN_REWRITE, boolean_inventory, boolean_audit, 234, 40, 'book_scope_review', BOOLEAN_REVIEW_STATUS),
            ('Literal2', LITERAL_REPAIR, literal_inventory, literal_audit, 47, LITERAL_REVIEW_INPUT_COUNT, 'root', LITERAL_REVIEW_STATUS)]:
        require(inv['author'] == audit['source_author'] == 'reflection_evidence_review'
                and audit['reviewer'] == reviewer and audit['independent_of_source_author'] is True
                and audit['status'] == status and inv['input_count'] == len(inv['inputs']) == author_count
                and audit['direct_input_count'] == len(audit['inputs']) == review_count
                and manifest['current_separate_review_scopes'][label]['inputs'] == audit['inputs']
                and manifest['current_separate_review_scopes'][label]['input_count'] == review_count
                and manifest['current_separate_author_inventory_scopes'][label]['inputs'] == inv['inputs']
                and manifest['current_separate_author_inventory_scopes'][label]['input_count'] == author_count,
                'Independent current source/correction review scope: ' + label)
        for name in ('SOURCE-INVENTORY.json', 'SOURCE-AUDIT.json', 'SOURCE-REVIEW.md'):
            binding = h.binding(directory / name)
            require(manifest['current_separate_review_scopes'][label][name] == {
                        'path': (directory / name).relative_to(ROOT).as_posix(),
                        **{key: binding[key] for key in ('bytes', 'sha256')}}, 'Current review identity differs')
        required_inputs += inv['inputs'] + audit['inputs']
    require(boolean_audit['source'] == current[1]
            and boolean_audit['full_native_companion'] == boolean_inventory['full_native_companion']
                == boolean_overlay['variants'][1]['candidate']
            and boolean_audit['author_input_count_verified'] == 234
            and boolean_audit['physical_proof_edit_count'] == boolean_audit['native_proof_edit_count'] == 32
            and boolean_audit['primary_interval_count_verified'] == 12
            and boolean_audit['historical_reviews_rebased'] is False
            and literal_audit['source'] == current[4]
            and literal_audit['author_input_count_verified'] == 47
            and literal_audit['exact_edits_verified'] == 2
            and literal_audit['unchanged_complement_segments_verified'] == 3
            and literal_audit['theorem_header_count_unchanged'] == 9
            and literal_audit['axiom_report_count_unchanged'] == 8
            and literal_audit['primary_intervals_verified'] == 6
            and literal_audit['historical_review_scopes_rebased'] is False,
            'Separate completed reviews apply to these exact current sources and overlays')
    boolean_result = verify_boolean_rewrite(boolean_overlay, boolean_correspondence, boolean_grammar, h)
    literal_result = verify_literal_scope_repair(literal_correction, h)
    primary = {'Boolean32': verify_wrapper_primary_intervals(read(BOOLEAN_REWRITE / 'PRIMARY-SOURCE-INTERVALS.json'), 12, h),
               'Literal2': verify_wrapper_primary_intervals(read(LITERAL_REPAIR / 'PRIMARY-SOURCE-INTERVALS.json'), 6, h)}
    consumed = read(BOOLEAN_LITERAL_PREDECESSOR / 'attempts/complete-01/report.json')
    predecessor = manifest['preserved_consumed_Wrapper136_predecessor']
    require(consumed['status'] == 'failed' and consumed['source_fingerprint'] == previous['source_fingerprint']
                == '6ffb699dd88cf34e0ac1a3ca5d2702c14bad45ec2c24b743f5f67dde984b3e02'
            and consumed['module_order'] == MODULES
            and [row['module'] for row in consumed['modules']] == MODULES[:5]
            and [row['status'] for row in consumed['modules']] == ['passed'] * 4 + ['failed']
            and consumed['accepted_axiom_report_count'] == 71 and consumed['observed_axiom_report_count'] == 79
            and consumed['modules'][-1]['exit_code'] == 1 and consumed['modules'][-1]['limit_exceeded'] is None
            and consumed['modules'][-1]['axiom_audit']['observed_count'] == 8
            and consumed['modules'][-1]['axiom_audit']['all_raw_axiom_names_permitted'] is False
            and [row['root'] for row in consumed['modules'][-1]['axiom_audit']['raw_reports']]
                == REQUIRED['KernelCachedLiteralForward']
            and 'sorryAx' in {axis for row in consumed['modules'][-1]['axiom_audit']['raw_reports'] for axis in row['axioms']}
            and len(consumed['artifacts']) == 8
            and consumed['all_sources_snapshots_controls_runtime_unchanged'] is True
            and consumed['all_selected_mathematical_sources_freshly_checked'] is False,
            'Actual failed Wrapper136 Literal diagnostics and accepted71 prefix boundary')
    diagnostic = local_path(literal_correction['observed_stdout']['path']).read_text()
    require(re.findall(r'^KernelCachedLiteralForward\.lean:(\d+):41: error: Application type mismatch:', diagnostic, re.M)
                == ['111', '127'] and 'Expr.wscopedB depth (natLiteral n) = true' in diagnostic,
            'Actual two literal-scope diagnostic locations and expected type')
    verify([identity(predecessor['consumed_marker'], h)], True)
    require(read(local_path(predecessor['consumed_marker']['path']))['source_fingerprint'] == consumed['source_fingerprint']
            and predecessor['report'] == literal_correction['failed_report']
            and predecessor['consumed_marker'] == literal_correction['consumed_marker']
            and manifest['source_fingerprint'] == fingerprint(sources) != consumed['source_fingerprint']
            and manifest['source_fingerprint_scope'] == {
                'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]},
            'Permanent consumed key and genuinely changed combined source identity')
    require(manifest['logical_origins'] == previous['logical_origins']
            and manifest['complete_origin_source_rows'] == previous['complete_origin_source_rows']
            and manifest['source_segment_ownership'] == previous['source_segment_ownership']
            and manifest['origin_ownership'] == previous['origin_ownership']
            and (manifest['distinct_upstream_origin_count'], manifest['distinct_project_origin_count'],
                 manifest['distinct_logical_origin_count'], manifest['source_segment_count']) == (17, 7, 24, 26)
            and manifest['full_native_Boolean_companion_is_extra_compiled_owner'] is False
            and manifest['full_original_driver_native_API_preserved'] is False
            and manifest['later_original_driver_restoration_required'] is True
            and manifest['six_original_callback_slots_retained'] is True
            and manifest['measured_cost_benefit_or_complete_budget_fit_claimed_before_run'] is False
            and manifest['whole_query_GroupChecked_or_stock_numeral_claimed'] is False,
            'Proof-only current ownership, native context, cost and theorem boundaries')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({row['path'] for row in controls}) == len(controls)
            and len({row['role'] for row in controls}) == len(controls), 'Repeated combined control path or role')
    controls.append({**h.binding(BOOLEAN_LITERAL_MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'Combined source/control overlap')
    for row in previous_plan['sources'] + previous_plan['controls']:
        required_inputs.append({**row, 'path': Path(row['path']).relative_to(ROOT).as_posix()})
    for row in required_inputs:
        actual = identity(row, h)
        require(actual['path'] in bound and all(bound[actual['path']][key] == actual[key]
                for key in ('bytes', 'sha256')), 'Historical or new input not bound in complete combined selection')
    for path in list(BOOLEAN_LITERAL_FIXED) + [BOOLEAN_LITERAL_HERE / 'run_gate.py', BOOLEAN_LITERAL_HERE / 'PROTOCOL.md', BOOLEAN_LITERAL_HERE / 'AUTHORING.md',
                              BOOLEAN_LITERAL_HERE / 'CONTROL-CORRESPONDENCE.json']:
        require(str(path) in bound, 'Combined execution/selection control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls), 'Combined snapshot census')
    verify(sources + controls + [previous_plan['compiler']] + previous_plan['runtime'])
    return {**previous_plan, 'sources': sources, 'controls': controls, 'roots': REQUIRED,
            'source_fingerprint': fingerprint(sources), 'boolean_proof_overlay': boolean_result,
            'literal_scope_overlay': literal_result, 'boolean_literal_reviews': manifest['current_separate_review_scopes'],
            'boolean_literal_primary_intervals': primary, 'consumed_wrapper136_predecessor': predecessor}
def verify_terminal_boolean_repair(overlay, correspondence, diagnostics, h):
    require(overlay['format'] == 'adwh-cached-boolean-diagnosed-terminal-equation-repair-v1'
            and overlay['author'] == 'reflection_evidence_review'
            and overlay['exact_source_edit_count'] == 60
            and overlay['physical_diagnosed_error_count'] == 30
            and len(overlay['variants']) == 2
            and overlay['source_admission_or_new_axiom'] is False
            and overlay['source_option_resource_policy_or_runtime_definition_change'] is False
            and overlay['native_companion_compiled_or_diagnosed'] is False,
            'Diagnosed terminal Boolean repair scope')
    labels = ['bvar', 'sort', 'const', 'lit', 'fvar_true', 'fvar_false', 'app_true', 'app_false',
              'lam_true', 'lam_false', 'forall_true', 'forall_false', 'let_body',
              'let_value_false', 'let_type_false']
    summaries, proof_pairs, all_blocks = [], [], []
    for index, row in enumerate(overlay['variants']):
        require(row['label'] == ('physical_evaluator_owner' if index == 0 else 'full_native_ExprOpsC')
                and row['proof_edit_count'] == row['exact_edit_count'] == len(row['exact_source_edits']) == 30
                and row['documentation_edit_count'] == 0 and row['projection_proofs_unchanged'] is True
                and [edit['constructor_branch'] for edit in row['exact_source_edits']] == labels * 2,
                'Thirty diagnosed nonprojection proof fields per owner')
        summaries.append(verify_exact_complements(row, h))
        original = local_path(row['original']['path']).read_bytes()
        candidate = local_path(row['candidate']['path']).read_bytes()
        proof_pairs.append([(edit['original_text'], edit['replacement_text']) for edit in row['exact_source_edits']])
        for j, edit in enumerate(row['exact_source_edits']):
            walk, plain, following = ('wscopedBXP', 'wscopedBP', 'wscopedBC') if j < 15 else ('leavesSubXP', 'leavesSubP', 'leavesSubC')
            start = original.index(('def ' + walk + ' ').encode())
            stop = original.index(('\ndef ' + following + ' ').encode(), start)
            before, after = edit['original_text'], edit['replacement_text']
            require(edit['kind'] == 'diagnosed_terminal_proof_only' and edit['owner'] == 'ConLeche.Expr.' + walk
                    and start <= edit['original_start_byte'] < stop
                    and edit['original_text_bytes'] == len(before.encode())
                    and edit['replacement_text_bytes'] == len(after.encode())
                    and edit['original_text_sha256'] == hashlib.sha256(before.encode()).hexdigest()
                    and edit['replacement_text_sha256'] == hashlib.sha256(after.encode()).hexdigest()
                    and edit['original_line_start'] == original[:edit['original_start_byte']].count(b'\n') + 1
                    and edit['candidate_line_start'] == candidate[:edit['candidate_start_byte']].count(b'\n') + 1,
                    'Terminal proof field, offsets, hashes and line identity')
            if j % 15 < 4:
                require(before == 'by rw [' + plain + '.eq_def, hcut]'
                        and after == before[:-1] + ', ite_eq_right Bool.false_ne_true]'
                        and edit['terminal_pinned_equation_proof'] == 'ite_eq_right Bool.false_ne_true',
                        'Exact false-condition leaf equation addition')
            else:
                indent = '          ' if labels[j % 15] in ('let_body', 'let_value_false') else '        '
                terminal = edit['terminal_pinned_equation_proof']
                require(after == before + '\n' + indent + 'exact ' + terminal
                        and (terminal.startswith('(Bool.') or terminal.startswith('((congrArg '))
                        and terminal.endswith('.symm'), 'Only the pinned terminal Boolean equality proof is appended')
        blocks = row['whole_walk_blocks']
        require(blocks == correspondence['walk_block_rows'][row['label']]
                and [(block['walk'], block['state']) for block in blocks]
                    == [('wscopedBXP', 'original'), ('wscopedBXP', 'candidate'),
                        ('leavesSubXP', 'original'), ('leavesSubXP', 'candidate')],
                'Complete old/new Boolean walk block census')
        current_blocks = []
        for block in blocks:
            data = original if block['state'] == 'original' else candidate
            part = data[block['start_byte']:block['end_byte_exclusive']]
            require(len(part) == block['bytes'] and hashlib.sha256(part).hexdigest() == block['sha256'],
                    'Complete terminal-repaired walk block identity')
            current_blocks.append(part)
        all_blocks.append(current_blocks)
        require(re.findall(rb'(?m)^#print axioms .*$', original) == re.findall(rb'(?m)^#print axioms .*$', candidate),
                'Terminal repair changes no report command')
    require(proof_pairs[0] == proof_pairs[1] and all_blocks[0] == all_blocks[1]
            and sum(row['exact_unchanged_complement_count'] for row in summaries) == 62
            and correspondence['physical_original'] == overlay['variants'][0]['original']
            and correspondence['physical_candidate'] == overlay['variants'][0]['candidate']
            and correspondence['full_native_original'] == overlay['variants'][1]['original']
            and correspondence['full_native_candidate'] == overlay['variants'][1]['candidate']
            and correspondence['native_companion_compiled_or_extra_selected_owner'] is False
            and correspondence['ordinary_original_driver_API_restored'] is False
            and correspondence['historical_proof_and_omission_layers_rebased'] is False,
            'Exact native/ordinary terminal repairs and preserved driver boundary')
    for row in (diagnostics['report'], diagnostics['stdout'], diagnostics['stderr']):
        identity(row, h)
    require(diagnostics['report'] == overlay['actual_failed_report']
            and diagnostics['stdout'] == overlay['actual_stdout']
            and diagnostics['stderr'] == overlay['actual_stderr']
            and diagnostics['source'] == overlay['variants'][0]['original']
            and diagnostics['candidate'] == overlay['variants'][0]['candidate']
            and diagnostics['diagnostic_count'] == len(diagnostics['diagnostics']) == 30
            and diagnostics['projection_proof_errors_observed'] is False
            and diagnostics['native_companion_executed'] is False, 'Actual diagnosed physical owner linkage')
    raw = local_path(diagnostics['stdout']['path']).read_bytes()
    observed = re.findall(rb'^KernelCachedForward\.lean:(\d+):(\d+): error: ([^\n]*)', raw, re.M)
    require(len(observed) == 30 and all(message == b'unsolved goals' for _, _, message in observed),
            'Exactly thirty actual unsolved terminal goals, without a different compiler error class')
    last_end = 0
    for edit, diagnostic, (line, column, _) in zip(overlay['variants'][0]['exact_source_edits'],
                                                diagnostics['diagnostics'], observed):
        a, b = diagnostic['stdout_start_byte'], diagnostic['stdout_end_byte_exclusive']
        part = raw[a:b]
        require(last_end <= a < b <= len(raw) and part == diagnostic['raw_diagnostic'].encode()
                and len(part) == diagnostic['bytes'] and hashlib.sha256(part).hexdigest() == diagnostic['sha256']
                and int(line) == diagnostic['source_line'] == edit['observed_error']['line'] == edit['original_line_start']
                and int(column) == diagnostic['source_column'] == edit['observed_error']['column']
                and diagnostic['owner'] == edit['owner']
                and diagnostic['constructor_branch'] == edit['constructor_branch']
                and diagnostic['original_proof_start_byte'] == edit['original_start_byte']
                and diagnostic['candidate_proof_start_byte'] == edit['candidate_start_byte']
                and diagnostic['candidate_line_start'] == edit['candidate_line_start']
                and diagnostic['terminal_pinned_equation_proof'] == edit['terminal_pinned_equation_proof'],
                'Exact raw terminal diagnostic span and actual corrected proof field')
        last_end = b
    return {'variants': summaries, 'physical_diagnosed_proof_fields': 30, 'native_corresponding_proof_fields': 30,
            'exact_unchanged_complement_count': 62, 'full_cross_representation_walk_block_pairs': 4,
            'exact_raw_diagnostic_spans': 30, 'native_companion_is_context_only': True,
            'compiler_or_resource_success_claimed_by_metadata': False}


def preflight(args, h, guard):
    previous_plan = boolean_literal_historical_preflight(args, h, guard)
    previous = read(BOOLEAN_LITERAL_MANIFEST)
    manifest = read(MANIFEST)
    overlay = read(TERMINAL_REPAIR / 'PROOF-CORRECTION.json')
    correspondence = read(TERMINAL_REPAIR / 'SOURCE-CORRESPONDENCE.json')
    diagnostics = read(TERMINAL_REPAIR / 'DIAGNOSTIC-CORRESPONDENCE.json')
    inventory = read(TERMINAL_REPAIR / 'SOURCE-INVENTORY.json')
    audit = read(TERMINAL_REPAIR / 'SOURCE-AUDIT.json')
    require(manifest['format'] == MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY and manifest['module_order'] == MODULES
            and manifest['prepared_objects'] == [] and manifest['export_targets'] == []
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 136
            and manifest['expected_artifact_count'] == 14
            and manifest['ordered_report_counts'] == [1, 25, 20, 25, 8, 16, 41]
            and manifest['selected_physical_source_bytes'] == 606505,
            'Terminal-repaired complete136 selection')
    sources, done = [], set()
    require(len(manifest['sources']) == len(SOURCE_PINS) == len(MODULES) == 7, 'Terminal complete source count')
    for row, module, pin in zip(manifest['sources'], MODULES, SOURCE_PINS):
        require(row['module'] == module and (row['path'], row['bytes'], row['sha256']) == pin
                and row['module_format'] is False and row['expected_default_output_suffixes'] == ['.olean', '.ilean']
                and row['fully_qualified_roots'] == REQUIRED[module]
                and row['raw_source_print_identifiers'] == RAW_REQUIRED[module], 'Terminal physical source/report pin')
        require(all(name in done or name == 'Init' or name.startswith(('Init.', 'Std.')) for name in row['imports']),
                'External experimental or forward terminal import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']})
        done.add(module)
    current = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in manifest['sources']]
    old = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in previous['sources']]
    require([i for i, pair in enumerate(zip(old, current)) if pair[0] != pair[1]] == [1]
            and old[1] == inventory['physical_predecessor'] == overlay['variants'][0]['original']
            and current[1] == inventory['physical_variant'] == overlay['variants'][0]['candidate'] == audit['source']
            and inventory['full_native_companion'] == overlay['variants'][1]['candidate'] == audit['full_native_companion']
            and sum(row['bytes'] for row in current) == 606505
            and len({root for roots in REQUIRED.values() for root in roots}) == 136,
            'Only the exact diagnosed Cached terminal proof fields change from Q')
    require(manifest['preserved_BooleanLiteral136_review_context'] == {key: previous[key] for key in TERMINAL_REVIEW_KEYS}
            and manifest['preserved_BooleanLiteral136_selection_context'] == {key: previous[key] for key in TERMINAL_SELECTION_KEYS}
            and manifest['historical_independent_review_scope_count'] == 20
            and manifest['current_total_separate_independent_review_scope_count'] == 21
            and manifest['historical_reviews_rebased'] is False,
            'All twenty predecessor review scopes remain at their exact historical inputs')
    scope = manifest['current_separate_review_scopes']['Terminal30']
    author_scope = manifest['current_separate_author_inventory_scopes']['Terminal30']
    require(inventory['author'] == audit['source_author'] == 'reflection_evidence_review'
            and audit['reviewer'] == 'book_scope_review' and audit['independent_of_source_author'] is True
            and audit['status'] == 'passed_source_only_no_compilation_or_measured_cost_claim'
            and inventory['input_count'] == len(inventory['inputs']) == audit['author_input_count_verified'] == 264
            and audit['direct_input_count'] == len(audit['inputs']) == 30
            and scope['inputs'] == audit['inputs'] and scope['input_count'] == 30
            and author_scope['inputs'] == inventory['inputs'] and author_scope['input_count'] == 264
            and audit['accepted_mathematical_result_claimed'] is False
            and audit['resource_fit_or_timing_improvement_claimed'] is False
            and not any(audit['execution'].values())
            and all(audit['exact_checks'].values())
            and audit['prior_scope']['rebased'] is False,
            'Distinct completed Terminal30 independent source review and unchanged author inventory')
    for name in ('SOURCE-INVENTORY.json', 'SOURCE-AUDIT.json', 'SOURCE-REVIEW.md'):
        binding = h.binding(TERMINAL_REPAIR / name)
        require(scope[name] == {'path': (TERMINAL_REPAIR / name).relative_to(ROOT).as_posix(),
                              **{key: binding[key] for key in ('bytes', 'sha256')}}, 'Terminal review identity differs')
    require(audit['author_inventory'] == scope['SOURCE-INVENTORY.json']
            and audit['source_review'] == scope['SOURCE-REVIEW.md'], 'Terminal audit binds its exact reviewed records')
    terminal_result = verify_terminal_boolean_repair(overlay, correspondence, diagnostics, h)
    primary = verify_wrapper_primary_intervals(read(TERMINAL_REPAIR / 'PRIMARY-SOURCE-INTERVALS.json'), 15, h)
    consumed = read(TERMINAL_PREDECESSOR / 'attempts/complete-01/report.json')
    predecessor = manifest['preserved_consumed_BooleanLiteral136_predecessor']
    require(consumed['status'] == 'failed' and consumed['source_fingerprint'] == previous['source_fingerprint']
                == 'de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a'
            and consumed['module_order'] == MODULES
            and [row['module'] for row in consumed['modules']] == MODULES[:2]
            and [row['status'] for row in consumed['modules']] == ['passed', 'failed']
            and consumed['accepted_axiom_report_count'] == 1 and consumed['observed_axiom_report_count'] == 26
            and consumed['modules'][1]['exit_code'] == 1 and consumed['modules'][1]['limit_exceeded'] is None
            and consumed['modules'][1]['axiom_audit']['observed_count'] == 25
            and consumed['modules'][1]['axiom_audit']['all_raw_axiom_names_permitted'] is False
            and [row['root'] for row in consumed['modules'][1]['axiom_audit']['raw_reports']] == REQUIRED['KernelCachedForward']
            and 'sorryAx' in {axis for row in consumed['modules'][1]['axiom_audit']['raw_reports'] for axis in row['axioms']}
            and len(consumed['artifacts']) == 2
            and consumed['all_sources_snapshots_controls_runtime_unchanged'] is True
            and consumed['all_selected_mathematical_sources_freshly_checked'] is False,
            'Actual failed Q Cached diagnostics and accepted Core1 prefix only')
    verify([identity(predecessor['consumed_marker'], h)], True)
    require(read(local_path(predecessor['consumed_marker']['path']))['source_fingerprint'] == consumed['source_fingerprint']
            and predecessor['report'] == overlay['actual_failed_report'] == diagnostics['report']
            and predecessor['consumed_marker'] == overlay['consumed_marker']
            and manifest['source_fingerprint'] == fingerprint(sources) != consumed['source_fingerprint']
            and manifest['source_fingerprint_scope'] == {'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]},
            'Permanent consumed Q key and genuinely changed complete source identity')
    require(manifest['logical_origins'] == previous['logical_origins']
            and manifest['complete_origin_source_rows'] == previous['complete_origin_source_rows']
            and manifest['source_segment_ownership'] == previous['source_segment_ownership']
            and manifest['origin_ownership'] == previous['origin_ownership']
            and (manifest['distinct_upstream_origin_count'], manifest['distinct_project_origin_count'],
                 manifest['distinct_logical_origin_count'], manifest['source_segment_count']) == (17, 7, 24, 26)
            and manifest['full_native_Boolean_companion_is_extra_compiled_owner'] is False
            and manifest['full_original_driver_native_API_preserved'] is False
            and manifest['later_original_driver_restoration_required'] is True
            and manifest['six_original_callback_slots_retained'] is True
            and manifest['measured_cost_benefit_or_complete_budget_fit_claimed_before_run'] is False
            and manifest['whole_query_GroupChecked_or_stock_numeral_claimed'] is False,
            'Unchanged ownership and conditional theorem/driver/resource boundaries')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({row['path'] for row in controls}) == len(controls)
            and len({row['role'] for row in controls}) == len(controls), 'Repeated terminal control path or role')
    controls.append({**h.binding(MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'Terminal source/control overlap')
    required_inputs = inventory['inputs'] + audit['inputs']
    for row in previous_plan['sources'] + previous_plan['controls']:
        required_inputs.append({**row, 'path': Path(row['path']).relative_to(ROOT).as_posix()})
    for row in required_inputs:
        actual = identity(row, h)
        require(actual['path'] in bound and all(bound[actual['path']][key] == actual[key] for key in ('bytes', 'sha256')),
                'Historical or terminal reviewed input not bound in complete selection')
    for path in list(FIXED) + [Path(__file__).resolve(), HERE / 'PROTOCOL.md', HERE / 'AUTHORING.md',
                              HERE / 'CONTROL-CORRESPONDENCE.json']:
        require(str(path) in bound, 'Terminal execution/selection control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls), 'Terminal snapshot census')
    verify(sources + controls + [previous_plan['compiler']] + previous_plan['runtime'])
    return {**previous_plan, 'sources': sources, 'controls': controls, 'roots': REQUIRED,
            'source_fingerprint': fingerprint(sources), 'terminal_boolean_overlay': terminal_result,
            'terminal_boolean_review': scope, 'terminal_boolean_primary_intervals': primary,
            'consumed_boolean_literal136_predecessor': predecessor}



def audit_logs(required, stdout_path, stderr_path):
    out = stdout_path.read_text() if stdout_path.is_file() else ''
    err = stderr_path.read_text() if stderr_path.is_file() else ''
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [row['root'] for row in raw]
    allowed = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'passed': stdout_path.is_file() and stderr_path.is_file() and names == required
                and allowed and not err and not pattern.sub('', out).strip(),
            'required_count': len(required), 'observed_count': len(raw),
            'observed_unique_count': len(set(names)), 'raw_reports': raw,
            'duplicate_names': [name for name, count in Counter(names).items() if count > 1],
            'exact_ordered_names': names == required, 'all_raw_axiom_names_permitted': allowed,
            'stderr_empty': not err, 'unparsed_stdout': pattern.sub('', out).strip()}


def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    predecessor_markers = [path / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
                           for path in (TERMINAL_PREDECESSOR, BOOLEAN_LITERAL_PREDECESSOR, WRAPPER_PREDECESSOR, HASLP_PREDECESSOR, COMMENT_PREDECESSOR, OMISSION_PREDECESSOR, COST_PREDECESSOR, ACCEPTED_PREDECESSOR, PREDECESSOR, STABLE_PREDECESSOR, ORIGINAL_GATE)]
    require(not attempt.exists() and not marker.exists() and not any(path.exists() for path in predecessor_markers),
            'Attempt or unchanged source closure already consumed')
    require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt,
              'executor': 'root', 'gate_author': 'reflection_evidence_review',
              'module_order': MODULES, 'physical_module_count': 7,
              'distinct_upstream_origin_count': 17, 'distinct_project_origin_count': 7,
              'distinct_logical_origin_count': 24, 'source_segment_count': 26, 'origin_ownership': plan['origin_ownership'],
              'complete_origin_source_rows': plan['origin_sources'],
              'supplemental_ownership': plan['supplemental_ownership'],
              'inherited_omissions': plan['inherited_omissions'],
              'source_bindings': plan['sources'], 'controls': plan['controls'],
              'source_fingerprint': plan['source_fingerprint'], 'source_correspondence': plan['correspondence'],
              'separate_proof_correction_overlay': plan['proof_overlay'],
              'separate_stable_and_helper_proof_overlays': plan['leaf_overlays'],
              'independent_source_review': plan['review'], 'reviewed_direct_input_count': 27,
              'independent_proof_correction_review': plan['correction_review'],
              'proof_correction_review_input_count': 18,
              'independent_stable_leaf_review': plan['stable_review'],
              'stable_leaf_review_input_count': 17,
              'independent_stable_correction_review': plan['stable_correction_review'],
              'stable_correction_review_input_count': 12,
              'independent_helper_review': plan['helper_review'], 'helper_review_input_count': 25,
              'independent_diagnosed_helper_review': plan['diagnosed_helper_review'],
              'diagnosed_helper_review_input_count': 18,
              'separate_diagnosed_helper_proof_overlay': plan['diagnosed_helper_overlay'],
              'preserved_failed_helper_predecessor': plan['failed_helper_predecessor'],
              'preserved_accepted_70_predecessor': plan['accepted_70_predecessor'],
              'separate_observer_syntax_overlay': plan['observer_syntax_overlay'],
              'separate_cached_proof_sharing_overlay': plan['cached_proof_sharing_overlay'],
              'bulk_and_literal_correspondence': plan['bulk_literal_correspondence'],
              'new_separate_independent_reviews': plan['new_separate_reviews'],
              'diagnosed_syntax_haslp_proof_repair': plan['syntax_haslp_overlay'],
              'syntax_haslp_independent_review': plan['syntax_haslp_review'],
              'syntax_haslp_review_input_count': 51,
              'preserved_consumed_comment120_predecessor': plan['consumed_comment120_predecessor'],
              'diagnosed_comment_header_repair': plan['comment_repair_overlay'],
              'comment_repair_independent_review': plan['comment_repair_review'],
              'comment_repair_review_input_count': 32,
              'preserved_consumed_omission120_predecessor': plan['consumed_omission120_predecessor'],
              'evaluator_omission_overlay': plan['omission_overlay'],
              'evaluator_omission_independent_review': plan['omission_review'],
              'evaluator_omission_review_input_count': 61,
              'preserved_consumed_cost120_predecessor': plan['consumed_cost120_predecessor'],
              'historical_cost_origin_context': plan['historical_cost_origin_context'],
              'source_correspondence_scope': 'historical_BooleanLiteral136_then_exact_diagnosed_terminal_Boolean_proofs',
              'separate_Boolean32_proof_overlay': plan['boolean_proof_overlay'],
              'separate_diagnosed_Literal_scope_proof_overlay': plan['literal_scope_overlay'],
              'separate_Boolean32_and_Literal_scope_reviews': plan['boolean_literal_reviews'],
              'separate_Boolean32_and_Literal_primary_intervals': plan['boolean_literal_primary_intervals'],
              'total_separate_independent_review_scope_count': 21,
              'separate_diagnosed_terminal_Boolean_overlay': plan['terminal_boolean_overlay'],
              'separate_diagnosed_terminal_Boolean_review': plan['terminal_boolean_review'],
              'terminal_Boolean_independent_review_input_count': 30,
              'terminal_Boolean_author_inventory_input_count': 264,
              'terminal_Boolean_primary_intervals': plan['terminal_boolean_primary_intervals'],
              'preserved_consumed_BooleanLiteral136_predecessor': plan['consumed_boolean_literal136_predecessor'],
              'preserved_consumed_Wrapper136_predecessor': plan['consumed_wrapper136_predecessor'],
              'Boolean32_cost_benefit_is_unmeasured_before_this_gate': True,
              'historical_Syntax_Bulk_reviews_are_context_only': True,
              'preserved_consumed_SyntaxHasLP120_predecessor': plan['consumed_haslp120_predecessor'],
              'current_separate_source_reviews': plan['wrapper_separate_reviews'],
              'separate_wrapper_preexecution_proof_overlay': plan['wrapper_proof_overlay'],
              'current_leaf_primary_intervals': plan['wrapper_primary_intervals'],
              'full_original_driver_native_API_preserved': False,
              'later_original_driver_restoration_required': True,
              'separate_cost_source_overlays': plan['cost_overlays'],
              'separate_cost_independent_reviews': plan['cost_separate_reviews'],
              'preserved_consumed_120_predecessor': plan['consumed_120_predecessor'],
              'cost_historical_review_scopes_rebased': False, 'cost_new_leaves_selected': [],
              'effective_Core_optional_PropWhen_omissions': {'proofs': 34, 'simp_registrations': 14},
              'Syntax11_selected': False, 'Bulk30_selected': False, 'Literal8_selected': True,
              'HelperFrame16_selected': True, 'Wrapper41_selected': True,
              'source_origin_rows_precede_separate_proof_overlay': True,
              'historical_reviews_rebased': False, 'compiler': plan['compiler'],
              'compiler_release': '4.35.0', 'compiler_commit': 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'runtime_libraries': plan['runtime'], 'constraints': {**POLICY, 'cpu_affinity': []},
              'execution_marker': None, 'required_prints': REQUIRED,
              'required_axiom_report_count': 136, 'required_unique_axiom_name_count': 136,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'each_physical_module_acceptance_is_all_or_nothing': True,
              'modules': [], 'seconds': None, 'peak_child_rss_kib': 0, 'artifacts': [],
              'expected_artifact_count': 14, 'prepared_objects': [], 'object_search_path': str(build),
              'all_selected_mathematical_sources_freshly_checked': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'exact_build_artifact_inventory': False,
              'cached_operational_and_licensed_25_roots_checked': False,
              'stable_memo_20_roots_checked': False,
              'direct_helper_25_roots_checked': False,
              'actual_cached_syntactic_functions_equal_separate_pure_tree_functions': False,
              'all_cached_syntactic_operations_correspondence_claimed': False,
              'actual_instantiateListC_equals_pure_instantiateList_for_all_exprs': False,
              'actual_instLevelParams_equals_pure_substitution_for_all_exprs': False,
              'bulk_cutoff_soundness_assumption_discharged': False,
              'cached_literal_forward_success_from_StableNF_and_MemoFrame': False,
              'cached_literal_forward_preserves_StableNF_and_auxiliary_not_map_equality': False,
              'helper_frame_16_roots_checked': False,
              'wrapper_41_roots_checked': False,
              'conditional_original_conversion_success_from_QueryWithRest': False,
              'finite_inference_and_annotation_body_equations_checked': False,
              'literal_forward_applies_to_arbitrary_invalid_initial_cache': False,
              'actual_driver_prefix_lookup_agreement_proved': False,
              'whole_query_cached_forward_success_proved': False,
              'CSOK_or_EnvWF_discharged': False, 'actual_installed_annotation_pins_discharged': False,
              'whole_structural_evaluator_normalization_proved': False,
              'original_GroupChecked_proved': False, 'optimized_kernel_installed': False,
              'compiled_experimental_or_upstream_imports_reused': False,
              'exporter_or_native_program_or_counter_executed': False,
              'stock_numeral_theorem_proved': False, 'integrated_project_modified': False}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings'] + report['controls']:
            destination = (frozen / (row['module'] + '.lean') if 'module' in row else
                           inputs / Path(row['path']).relative_to(ROOT))
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            destination.chmod(0o444)
            row['snapshot'] = h.binding(destination)
            require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')), 'Snapshot differs')
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
        verify([row['snapshot'] for row in report['source_bindings'] + report['controls']], True)
        marker.parent.mkdir(exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': args.attempt,
                'source_fingerprint': plan['source_fingerprint'], 'source_bindings': report['source_bindings'],
                'controls': report['controls'], 'compiler': report['compiler'],
                'runtime_libraries': report['runtime_libraries'], 'policy': POLICY,
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for name in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(name, None)
        env['LEAN_IMPORT_WORKERS'] = '1'
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                       '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / (module + '.olean')),
                       '-i', str(build / (module + '.ilean')), module + '.lean']
            stdout_path, stderr_path = attempt / (module + '.stdout.log'), attempt / (module + '.stderr.log')
            record = {'module': module, 'command': command, 'status': 'running'}
            report['modules'].append(record)
            h.save(report_path, report)
            try:
                record.update(h.child(command, frozen, env, stdout_path, stderr_path, cpu, deadline))
            finally:
                for key, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                    if path.is_file():
                        record[key] = h.binding(path)
                audit = audit_logs(REQUIRED[module], stdout_path, stderr_path)
                record['axiom_audit'] = audit
                objects = all((build / (module + suffix)).is_file() for suffix in ('.olean', '.ilean'))
                record['required_outputs_present'] = objects
                good = (record.get('exit_code') == 0 and record.get('within_limits') is True
                        and audit['passed'] and objects)
                record['status'] = 'passed' if good else 'failed'
                report['observed_axiom_report_count'] = sum(m['axiom_audit']['observed_count'] for m in report['modules'])
                report['observed_unique_axiom_root_count'] = len({r['root'] for m in report['modules']
                                                                for r in m['axiom_audit']['raw_reports']})
                report['accepted_axiom_report_count'] = sum(m['axiom_audit']['observed_count']
                                                           for m in report['modules'] if m['status'] == 'passed')
                h.save(report_path, report)
            require(record['status'] == 'passed', 'Fresh module/axiom/output/resource failure: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            require(len(snapshots) == len(report['source_bindings']) + len(report['controls']), 'Incomplete snapshots')
            verify(snapshots, True)
            verify([m[key] for m in report['modules'] for key in ('stdout', 'stderr') if key in m])
            require(report['execution_marker'] is not None, 'No execution marker reserved')
            verify([report['execution_marker']], True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected = {str(build / (module + suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = ({row['path'] for row in report['artifacts']} == expected
                                                       and len(report['artifacts']) == 14)
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((m.get('sampled_tree_and_wait4_peak_rss_kib', 0)
                                          for m in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [m['module'] for m in report['modules']] == MODULES
                  and all(m['status'] == 'passed' for m in report['modules'])
                  and report['accepted_axiom_report_count'] == 136
                  and report['observed_unique_axiom_root_count'] == 136
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['cached_operational_and_licensed_25_roots_checked'] = passed
        report['stable_memo_20_roots_checked'] = passed
        report['direct_helper_25_roots_checked'] = passed
        report['observer_Core_1_root_checked'] = passed
        report['syntax_11_roots_checked'] = False
        report['bulk_bound_30_roots_checked'] = False
        report['literal_forward_8_roots_checked'] = passed
        report['helper_frame_16_roots_checked'] = passed
        report['wrapper_41_roots_checked'] = passed
        report['conditional_original_conversion_success_from_QueryWithRest'] = passed
        report['finite_inference_and_annotation_body_equations_checked'] = passed
        report['cached_literal_forward_success_from_StableNF_and_MemoFrame'] = passed
        report['cached_literal_forward_preserves_StableNF_and_auxiliary_not_map_equality'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path), 'seconds': report['seconds'],
                      'peak_rss_kib': report['peak_child_rss_kib'], 'accepted_roots': report['accepted_axiom_report_count'],
                      'observed_roots': report['observed_axiom_report_count']}, sort_keys=True))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True, help='Pinned Lean 4.35.0 bin/lean; relocation is permitted')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt), 'Invalid attempt name')
    for path, expected in FIXED.items():
        require(path.is_file() and not path.is_symlink() and sha(path) == expected,
                'Pinned control differs before loading: ' + str(path))
    h = load(HELPER, 'cached_forward_resource_helper')
    guard = load(GUARD, 'cached_forward_source_guard')
    require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Resource/axiom helper contract')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
                          'physical_module_count': 7, 'distinct_upstream_origin_count': 17,
                          'distinct_project_origin_count': 7, 'distinct_logical_origin_count': 24,
                          'source_segment_count': 26,
                          'full_original_driver_native_API_preserved': False,
                          'required_axiom_report_count': 136, 'required_unique_axiom_name_count': 136,
                          'expected_artifact_count': 14, 'prepared_objects': 0,
                          'source_fingerprint': plan['source_fingerprint'],
                          'snapshot_count': len(plan['sources']) + len(plan['controls']),
                          'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
