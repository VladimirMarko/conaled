# Diagnosed terminal equations for the two Boolean certificate walks

This is a distinct source-only repair of the consumed Boolean32 Cached owner.
It does not modify that source, its native companion, previous reviews, any
gate, source key, marker or result. It selects no gate and claims no new
compilation or cost result. Root alone may execute a future independently
reviewed complete closure under the unchanged resource policy.

## Actual failure

The complete Boolean32/Literal2 Wrapper136 attempt used source key
`de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a`.
It failed in KernelCachedForward with thirty unsolved certificate goals.
Core's one report was accepted; twenty-five Cached reports were observed and
all rejected as one failed module. Stable, Helper, Literal, Frame and Wrapper
did not start. Two ordinary Core artifacts were produced. Total time was
24.491039530003036 seconds with peak 866408 KiB. This was a proof failure,
not a resource-limit event. All recorded integrity postchecks passed.

There are fifteen actual errors in each Boolean walk: four cutoff-leaf
conditional/match goals, eight ordinary true/false conjunction goals and
three left-associated let goals. No projection proof error was reported.
The raw diagnostics are retained byte-for-byte and mapped to the exact
physical proof fields. Several downstream reports contain error-recovery
sorryAx; neither old nor repaired source contains an admission. No failed
module report is treated as accepted.

The native ExprOpsC companion was not run. Its repair is justified by exact
original/candidate walk-block correspondence with the actual physical owner,
not by a fabricated native compiler diagnostic.

## Minimal repair

Each actual descent, cutoff, branch and child-equality rewrite stays in
place. Only the thirty diagnosed proof fields receive terminal equations:

| Residual goal | Terminal proof |
| --- | --- |
| Leaf conditional with condition `false = true` | Add `ite_eq_right Bool.false_ne_true` to the existing rewrite list; the selected constructor match then reduces. |
| `value = (true && value)` | Symmetry of the pinned `Bool.true_and value`. |
| `false = (false && untouched)` | Symmetry of the pinned `Bool.false_and untouched`; no skipped-child certificate is needed. |
| `value = ((true && true) && value)` | Congruence transports `Bool.true_and true` through the outer conjunction, then composes `Bool.true_and value`, finally taking symmetry. |
| `false = ((true && false) && body)` | The same congruence/transitivity pattern uses `Bool.true_and false` and `Bool.false_and body`. |
| `false = ((false && value) && body)` | It uses `Bool.false_and value` and `Bool.false_and body`, preserving the original left association. |

These explicit terms use current pinned names. The two Boolean identities
are read from Init/SimpLemmas; false_ne_true from Init/Data/Bool; ite_eq_right
from Init/Core. The complete three SDK files are retained as uncompiled
context. Existing retained Init/Prelude supplies congrArg, Eq.trans,
Eq.symm and the actual implicit-reducible Bool.and definition. This is not
an assumption that the existing rewrites will close by reflexivity.

The repair adds no general simplification pass, recursive unfolding,
unused-simp argument, deprecated if_pos/if_neg alias, fallback admission,
axiom, theorem or runtime function. The two projection proofs remain literal.

## Exact ordinary/native correspondence

The ordinary candidate is 211,978 bytes; the full native companion is
79,440 bytes. Each gains the same 1,828 bytes in thirty proof fields. All
sixty replacements and sixty-two complementary spans have exact forward
and inverse maps. The two original and two repaired walk blocks remain
byte-identical across representations. The full ordinary and native files
outside those fields are literal predecessors.

Actual returned Boolean values, short-circuit order, child descents, the
fvar scope cursor, binder depth, pointers/borrowing, memo guards, keys,
reads/writes, annotations, declarations, public/private interfaces, imports,
source options and report commands do not change. The ordinary owner still
has its same twenty-five explicit report commands; this is not a claim
that it contains only twenty-five public theorem declarations.

The full native companion preserves the full predecessor API. The ordinary
owner retains its earlier explicit evaluator/driver omissions and all six
original callback families. This repair neither restores the original
parsed driver nor claims native compilation, private generated-name
identity or machine-code equivalence. Native representation reconciliation
and actual original-driver restoration remain explicit later obligations.

## Reviews, source selection and budget

The previous Boolean32 author inventory, independent forty-input review,
original proof overlay, ordinary/native map, unselected grammar draft and
earlier historical scopes stay exact. This new correction binds their
identities separately, together with the actual failed complete136 controls,
report, logs, permanent marker, root receipt and snapshot recovery. Fifteen
new primary intervals and thirty exact diagnostic spans are retained.

No future complete source selection is created by this package. The intended
next selection must include this repaired owner, the already reviewed
Literal2 owner and every other actual dependency of its mathematical target.
All selected proof owners must compile freshly in the same interval. No
accepted prefix object or historical compilation budget can be reused.

The fixed policy remains one cumulative thirty seconds, one CPU/thread,
1 GiB, default heartbeat/recursion, autoImplicit=false,
warningAsError=true, Elab.async=false and only propext, Quot.sound and
Classical.choice. A failed source key stays consumed. The failed Cached
duration is not evidence of a measured optimization or future complete fit.

This repair establishes no actual cached whole-query trace or bound,
installed annotation/program pins, EnvWF, original GroupChecked or stock
numeral theorem. It is an exact diagnosed proof candidate awaiting
independent source review and a new complete mathematical gate.
