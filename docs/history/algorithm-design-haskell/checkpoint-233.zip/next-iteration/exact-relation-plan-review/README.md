# Independent review of the fixed exact-relation plan

## Conclusion and scope

The revised v2 design has no mathematical blocker. It specifies a meaningful next diagnostic: compute one fixed batch of sixteen candidate signed identities from the already saved sample matrix, then attempt to prove or refute those exact identities over the complete original guarded functions. The candidate calculation and the function-identity calculation share the same 50,000-request allowance. Completion within that allowance is unknown.

This is a design review. It neither implements nor runs rational elimination, source validation, symbolic restriction, a counter, an independent replay, or Lean. It authorizes no execution. The parent has separately authorized implementation; the executable producer, replayer, protocol, and bounded runner still require their source/control review before the one proposed run and replay. No earlier frozen bundle was changed, and no compilation lock was acquired.

The accompanying `review.json` records exact bindings for the reviewed v2 DESIGN/schema/evidence, preserved v1 files and patches, and their declared source inputs. The review read both complete v2 files, compared the v1-to-v2 changes, and checked file bytes and hashes. It did not recompute the saved sample, its rank, a nullspace, or any source function.

## Why a completed identity would mean more than a sampled relation

The nineteen saved rows and thirty-five saved columns determine only the proposal. The fixed Gauss–Jordan order captures each pivot and elimination coefficient before changing cells, tracks the current cell result references, and performs a final pivot-pattern check. It does not permit resampling, reordering, a different pivot policy, or changing the proposals after a global failure. The initial rows are integer data lifted to canonical rationals; all scalar operations and normalization steps remain within the recorded work budget.

For each free column, setting its free coordinate to one and all other free coordinates to zero gives a distinct canonical sample-null direction. Multiplication by the positive product of the nineteen recorded denominators preserves that direction and makes its designated free coefficient positive. The design correctly avoids also imposing a potentially conflicting first-nonzero-positive convention. This fixed denominator product can create large coefficients; no efficiency claim follows from the small matrix dimensions.

The global checker does not use sample correctness as an identity premise. It binds each coefficient to one complete original view, including its positive and negative guards, and works with the resulting integer-valued sum. Consequently even a poor proposal matrix cannot justify an incorrect completed identity. For a later Lean theorem, RREF can remain outside the trusted proof path: a checked concrete identity can use explicit coefficients directly.

If several canonical candidates are proved, their distinct nonzero free coordinates make those relations independent. Subject to the later formal bridge, proving k of them yields a B-span upper bound of 35 minus k. Conversely, refuting all sixteen selected candidates does not prove independence of the thirty-five global functions: a linear combination of failed sample-null basis directions can still be a true global identity. The design preserves this distinction.

## Guarded source and signed-state reasoning

The source validator is restricted to node zero and the ancestors of the thirty-five selected views. It derives support from checked descriptors, requires strict prior child IDs and variable ordering, validates complete guards, rejects conflicting or unflattened guards, and does not trust an old maximum-value annotation. Guard/core support disjointness and the common sixteen-variable support bound are explicit obligations.

A signed state is a sparse, sorted list of full views with integer coefficients. Exact insertion and collection preserve every occurrence, add matching coefficients as integers, and remove a term only when its resulting coefficient is zero or its complete view is the checked zero view. Bare core equality is insufficient. The same collector is used after every restriction, so duplicates, negative coefficients, and cancellation have an explicit semantic meaning.

Selecting the least variable in the checked support union makes the local cofactor cases sufficient: a current guard is satisfied or contradicted, a branch at that variable selects its actual child, or a checked absent variable leaves the view unchanged. The chosen variable disappears from each result. This gives depth at most sixteen, but does not bound the number of distinct coefficient states or their integer sizes.

For a zero proof, both restricted children must be completely proved zero. For refutation, one completely checked nonzero terminal and its restriction path suffice; the other branch need not be searched. Reconstructing the assignment while lifting the refutation preserves the exact nonzero value and requires no fresh evaluator. A cap or an incomplete branch is neither a proof nor a refutation.

The split is a pointwise Boolean case distinction. It has no absent-variable factor of two. Any later counting integration must still preserve projection multiplicity and the original natural-valued total. Signed or scaled identities may require signed intermediate factors and explicit denominator cancellation; discovering an identity alone does not provide those transfers.

## The three v2 clarifications

The exact revision addresses the parent's three findings without changing the candidate policy or resource limits:

1. A digest indexes a state-cache bucket only. Every inspected bucket candidate, including a miss or collision, has a charged comparison; every inspected full term comparison is charged until mismatch or complete equality. There can be no implicit whole-state Python dictionary or tuple comparison before those requests. A hash collision cannot establish equality.
2. Integer `divmod` requires a positive divisor, including when the numerator is negative. Denominator sign normalization occurs first. Thus the recorded remainder is a natural number below the divisor, and exact coefficient division checks a zero remainder.
3. A zero-cache hit reuses an existing earlier completed proof ID. It creates no alias proof node and does not republish an alias cache entry. Work start IDs and completed zero-proof IDs remain distinct orderings.

The preserved DESIGN patch changes only these clarifications and the implementation-authorization status. The parsed schema changes correspond to those same items, the new charged cache-candidate request, the diagnostic digest output, and its v2/status labels. Both preserved patch files reproduce the exact corresponding v1-to-v2 textual differences.

## Required executable checks

These are implementation review obligations, not new changes to the fixed design:

- A ticket must be reserved and its start written before arithmetic, cache inspection, support scanning, shortcut selection, or expected-output computation. In particular, replay must not evaluate arithmetic while constructing the arguments of a later charged request.
- Rational shortcuts must return canonical results. Every nontrivial scalar child, Euclidean step, exact denominator division, sign correction, coefficient addition, and terminal product/sum must appear at the declared granularity. Library fraction normalization and hidden vector arithmetic remain excluded.
- RREF cell origins, captured pivot values, captured elimination factors, row-swap references, final candidate entries, and the all-candidates-before-checks boundary must follow the fixed schedule. A collection of locally correct scalar equations with stale or substituted origins is insufficient.
- View support and cofactor rules must use explicit completed validation dependencies; source metadata, pending requests, and unreferenced residual-core cache reads cannot supply semantic facts.
- Completion references must point to already completed results. Parent-first ticket IDs do not establish this. Newly allocated zero-proof nodes must use strictly earlier completed child proofs; repeated child occurrences must be retained.
- State-cache equality must cover every full view and signed coefficient after the bucket lookup, including failed candidate comparisons. Nonzero or pending states cannot enter the zero-proof cache.
- The independent replay must bind exact numeric types, finite field sets and inactive fields, original input hashes, all result statuses, and partial-state bookkeeping. Previously completed candidate results may remain in a cap footer, but unfinished candidates cannot be promoted.

The planned candidate arithmetic can itself exhaust the cap. The declared dense-wrapper bounds deliberately exclude scalar and normalization children, and the existing wall/memory limits still constrain integer growth. The separate historical cut probe's work count must not be combined with this new budget and described as one complete bounded counting certificate.

## Remaining formal boundary

The accepted generic signed laws establish composition of signed collection, restriction, case splitting and earlier completed dependencies under explicit semantic premises. They are not a serialized guarded-source checker. A concrete Lean identity would still need that interpreter and checker, exact view binding, checked local support/cofactor laws, and the completed signed proof DAG. Applying an identity to the original count would additionally require the cut-grouping and source-count transfers.

No relation, improved contraction, rank reduction, new queens count, or size-sixteen completion is claimed by this review.
