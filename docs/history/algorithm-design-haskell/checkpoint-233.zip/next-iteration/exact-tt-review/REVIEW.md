# Exact tensor trains for queens: a read-only assessment

## Recommendation

Do not replace the current certificate route with a tensor-train implementation on the strength of the published rank table. Exact linear compression is a mathematically valid additional option, but its advantage over dead-state removal, equality of residual functions, and the existing count DAG has not been established. The most defensible next step, if this direction is selected, is one bounded exact rank audit of the eight-queen middle cut. No new count, rank calculation, Lean execution, or larger-board experiment was performed for this review.

This assessment concerns proof and certificate cost. A fast numerical contraction after a tensor has been built does not by itself supply a cheap kernel proof that the tensor represents every permitted board exactly once. The sixteen-queen result and Chapter 15 remain open.

## Primary evidence and its limits

Ryzhakov and Oseledets, arXiv:2206.03832v2, Appendix B.5 and Table 1, use one N-valued coordinate per column and a 3N-bit attack state. Their unrounded construction enumerates reachable states. The reported maximum bond dimensions are:

| Board | Unrounded | Threshold 0 | Threshold 10^-6 |
|---:|---:|---:|---:|
| 8 | 538 | 74 | 74 |
| 9 | 2,153 | 712 | 246 |
| 10 | 8,838 | 1,820 | 606 |

Table 1 reports totals 92, 352 and 724, with floating error annotations after rounding. Appendix C.1 merges indistinguishable states; C.2 discusses singular-value rounding. These are numerical observations, not exact rank or count certificates. [P1]

The currently visible implementation contains exact set/index construction and sparse transition routines, but its `matrix_svd` uses NumPy floating eigendecomposition, square roots and thresholding. The repository listing exposes `construct_TT.py` and a cooperative-games notebook; I did not find a separately exposed queens reproduction notebook there. This inspection does not identify the precise historical code that produced Table 1. [P2]

The PDF fetched through the unversioned URL explicitly carries the v2 header dated 15 June 2022; its title page says 16 June. The requested v2 URL failed through the retrieval tool, so the successful URL and visible version are both recorded. No OpenReview access restriction was bypassed.

## What the ranks actually describe

For a fixed coordinate order, let

`T(q0,...,q(N-1)) = 1` exactly when the queens do not attack, and `0` otherwise.

At cut k, form the matrix `M_k(prefix,suffix) = T(prefix ++ suffix)`. The minimum exact TT bond dimension at that cut is the matrix rank of `M_k`. The lower bound follows by factoring the unfolding through that bond; the matching existence result is Oseledets's Theorem 2.1. [P3]

For an integer matrix, its rank over the rationals equals its rank over the reals: both are the largest size of a nonzero integer minor. Thus there is no irrational-coefficient obstruction to exact compression at the true real rank. A floating SVD is useful for suggesting a basis; it is not the proof of the resulting exact identity.

There are at least three separate reductions to measure:

1. **Reachability:** retain only attack states reached by some legal prefix.
2. **Residual equality:** remove states with no legal completion, then merge states having identical suffix indicator functions. Backward signatures can certify this using only exact transition identities.
3. **Linear dependence:** express different residual functions as linear combinations of a smaller basis. For example, residual rows `(1,0)`, `(0,1)` and `(1,1)` are all distinct but span dimension two.

Only the third reduction demonstrates an advantage of linear rank over exact residual equality. Comparing it only with the raw forward states credits linear algebra for reductions that a deterministic graph can already make. Our residual count DAG also uses forced choices and compatibility-preserving relabeling, so even the equality-minimized fixed-order automaton is not the same baseline as that DAG.

### A useful consistency check

A zero-one tensor with S nonzero entries is a sum of S elementary outer products. Every unfolding therefore has rank at most S. Using the paper's own totals as a consistency check, its threshold-zero peaks 712 and 1,820 exceed the bounds 352 and 724. Those dimensions cannot be the minimal exact ranks of the stated indicators. They may describe a nonminimal representation or a floating approximation retaining numerical residuals. This is not a contradiction in TT representation: an exact tensor can also have unnecessarily large bond dimensions. It does prevent interpreting “threshold zero” as an exact optimal-rank certificate.

The eight-queen value 74 is compatible with exact rank, but the paper does not tell us whether all of its reduction survives exact arithmetic, or how much remains after dead and identical residuals are removed.

## Rank is not certificate size

For physical dimension N and bond sizes `r0,...,rN`, a dense TT stores

`E_dense = N * sum(k=1..N, r(k-1) * r(k))`

coefficients. A deterministic raw state transition has at most one target per state and physical symbol, so all its transition probes are bounded by

`E_raw = N * sum(k=0..N-1, s(k))`.

Substituting the published rank vectors gives the following arithmetic estimates; no queens computation was run:

| Board | Raw state/choice probes, upper bound | Dense rounded-core coefficient slots | Rounded interior bond dimensions, sum |
|---:|---:|---:|---:|
| 8 | 14,192 | 113,856 | 286 |
| 10 | 308,110 | 9,786,360 | 2,390 |

These measure different data representations, not runtime. A rounded train might retain exploitable sparsity or structure. Conversely, an exact change of basis may introduce signed coefficients and large denominators. Neither property is documented for these queens cores. The full exact certificate would also contain its change-of-basis data and the checked identities connecting it to the source transitions.

For comparison, checkpoint 165's accepted eight-queen count DAG has **136 total nodes and 323 branch edges**, with additional normalization witnesses. Its complete fresh source-linked proof took 25.899367069 seconds. Peak TT rank 74 is not a smaller version of those 136 total nodes. [W1]

The frozen zero-short-circuit lazy experiment uses 45,901 claims at the completed frontier 153 of 210 eliminated wire variables. The newer frozen common-factor variant reduces that to 42,402 claims and 1,984 live nodes, but still stops at the 50,000-claim cap inside `[153,160)`, without an n8 count. These are arithmetic-trace statistics for partially contracted line-network factors. They cannot be compared directly with the final full-indicator rank. A small rank for the final tensor does not bound the ranks or construction costs of those intermediate factors. [W2, W3]

## A precise exact certificate is possible

The following is a proposed algebraic design, not implemented mathematics.

Let `A_k(a)` be the original sparse transition matrix for coordinate k and choice a, of shape `s(k-1) × s(k)`. Let u be the starting row vector and b the accepting column vector. Source correctness must establish

`T(a1,...,aN) = u A_1(a1) ... A_N(aN) b`.

A producer proposes reduced matrices `B_k(a)` of shape `r(k-1) × r(k)`, maps `H_k : s(k) × r(k)`, and a terminal vector b'. The checker verifies every finite identity

`A_k(a) H_k = H_(k-1) B_k(a)`

for **every** coordinate and physical symbol, plus `H_N b' = b`. Set `u' = u H_0`. Repeated substitution then proves, for every assignment,

`u A_1(a1) ... A_N(aN) b = u' B_1(a1) ... B_N(aN) b'`.

Summation over all assignments gives the count equality. The proof needs exact dimensions, complete symbol coverage, all source transition equations, and both boundaries. It needs neither an SVD theorem nor a proof that the proposed rank is minimal. An independently checked low-rank factorization is sufficient.

This interface was sanity-checked read-only by the sibling diagnostics agent. The check emphasized that all H/B data and original A verification work must be charged: the map H can itself carry a large state enumeration.

### Rational coefficients

A rational certificate can be converted into integer equations by clearing explicitly nonzero denominators. For example, with `H_k = P_k/d_k` and `B_k = Q_k/e_k`, its transition obligation becomes

`d_(k-1) e_k A_k(a) P_k = d_k P_(k-1) Q_k(a)`.

This avoids trusting floating reconstruction or Gaussian elimination. It does not eliminate integer coefficient growth, signs, or matrix-product verification cost. The existing natural-valued ADD proofs do not already provide this new signed/rational layer.

### Modular coefficients

The same identities over a fixed modulus prove equality of counts **modulo that modulus**. A single field factorization is not a rational rank upper bound: integer matrices can lose rank modulo a prime. Conversely, a nonzero minor modulo a prime proves that the corresponding integer minor is nonzero, so it gives a valid rational rank lower bound.

There are two sound completion choices:

- Recover rational factors and check their exact integer identities, using modular computations only to discover candidates.
- Keep the counting proof modular and prove an independent interval containing the true natural count whose width is smaller than the modulus, or than a checked CRT product. The interval must bound the source count, not merely the producer's proposed answer. The elementary bounds `count ≤ N^N`, or the sharper `count ≤ N!` after establishing row uniqueness, are available mathematical starting points.

No trusted probabilistic rank test is required. The very fast interactive rank certificates in Dumas and Kaltofen use Monte Carlo verification and, for their noninteractive transformation, a Fiat–Shamir heuristic. Those guarantees do not turn one accepted sample into the unconditional equality required here. [P4]

## Full-indicator compression and scalar compression differ

The full-indicator identities above must hold separately for every symbol a. To preserve only the total, one can instead work with `M_k = sum_a A_k(a)` and check an aggregated relation. This is weaker and could compress more, but it must be justified separately; a proof of some sampled matrix products would not suffice.

At the extreme, each state's exact number of completions can be stored in one column. The equations `M_k c_k = c_(k-1)` certify those counts. Calling that construction “rank one” would conceal that the vectors still contain every state count and the checker still verifies the entire dynamic program. This illustrates why scalar rank alone is not an engineering metric.

The same distinction favors the existing count DAG in some cases: transformations preserving a count after relabeling need not preserve the original full indicator as a function of its fixed coordinate labels. Conversely, full TT semantics could be useful if many different conditioned queries were required. Our current target is one source-linked scalar numeral.

## Could certified approximation still prove an integer count?

Yes in principle. If an exact argument establishes an absolute Frobenius residual bound `||T - U||_F ≤ E`, then Cauchy–Schwarz gives

`|sum T - sum U| ≤ N^(N/2) E`.

A rigorously bounded contraction and a resulting interval containing exactly one integer would determine the count. A requested floating truncation threshold or a small observed error is not that rigorous residual certificate. It would also need roundoff bounds, norm/threshold conventions, and the exact source binding. This is an additional proof route, not a justification for rounding the table's displayed result. No scaling conclusion follows from the small examples.

## One conditional bounded milestone

An immediate Lean port is not justified. If the parent chooses to resolve this direction's central uncertainty, the smallest useful experiment is:

**One exact eight-queen cut audit, after four columns, with no order or prime sweep.** Construct the compatibility matrix between all internally legal four-column prefixes and all internally legal four-column suffixes. Source row/column definitions and every matrix entry must be independently replayable. No list of expected solutions or expected answer is an input.

Record, in this order:

1. The reachable half-state sizes and sparse compatibility data.
2. The number of nonzero, distinct residual rows after exact zero and duplicate removal.
3. An exact rational factorization `M = U V`, with all coefficients, nonzero counts and numerator/denominator bit lengths. A pivot minor certified nonsingular modulo the single preselected prime 65,537 can prove a matching rank lower bound; it is not used as a count certificate.
4. All verification arithmetic, source-binding work, reference occurrences and serialized bytes, including data discarded by the final factorization.

Keep one CPU, a 30-second bound per producer/replayer process and 1 GiB, with the existing 50,000-record cap on any emitted arithmetic witness. Precommit the format and accounting before a run; do not replace scalar witness accounting by treating a whole matrix identity as one cheap operation. Preserve a stopped or rejected attempt. This review authorizes no such execution.

The outcome has a useful stop condition. If exact rank equals the number of distinct nonzero residual rows, this cut has no linear compression beyond equality merging. If rank is smaller but coefficient data and exact verification cost erase the gain, do not proceed to a TT counting port. Only a clear sparse, low-coefficient advantage at this cut would justify a subsequent complete small source-linked certificate. Even that would say nothing yet about N=16 or the unfinished lazy factor boundary.

## Sources and local bindings

- **[P1]** G. Ryzhakov and I. Oseledets, *Constructive TT-representation of the tensors given as index interaction functions with applications*, arXiv:2206.03832v2. Requested stable reference: https://arxiv.org/abs/2206.03832v2 . Successfully read PDF: https://arxiv.org/pdf/2206.03832 , visible v2 header; Appendix B.5 and Table 1, printed pages 23–24; Appendix C, printed pages 27–28.
- **[P2]** Authors' implementation: https://github.com/G-Ryzhakov/Constructive-TT and https://github.com/G-Ryzhakov/Constructive-TT/blob/main/construct_TT.py . Inspected `next_indices`, `build_cores_by_indices`, `TT_func_mat_vec`, `reindex_None_all`, and `matrix_svd`. This is the visible `main`, not a pinned historical reproduction. Raw/API retrieval was unavailable; no source was executed.
- **[P3]** I. V. Oseledets, *Tensor-Train Decomposition*, SIAM J. Sci. Comput. 33(5), 2295–2317 (2011), Theorem 2.1 and preceding lower bound; Theorem 2.2 for the approximate distinction. DOI: https://doi.org/10.1137/090752286 . The original paper was read from https://users.math.msu.edu/users/iwenmark/Teaching/CMSE890/TENSOR_oseledets2011.pdf . No copy is redistributed here.
- **[P4]** J.-G. Dumas and E. Kaltofen, *Essentially Optimal Interactive Certificates in Linear Algebra*, arXiv:1401.4567v4, abstract and Sections 2 and 4: https://arxiv.org/html/1401.4567v4 . Used only to qualify the probabilistic guarantee of a tempting low-cost verification approach.
- **[W1]** `/workspace/scratch/90ff2dc39267/project/experiments/chapter15-queens-model-counting/residual-dag/MILESTONE-REPORT.md` and `diagnostics/comparison.json`.
- **[W2]** `/workspace/scratch/90ff2dc39267/next-iteration/lazy-zero-circuit/README.md` and `RESULTS.json`.
- **[W3]** `/workspace/scratch/90ff2dc39267/next-iteration/lazy-factored-circuit/README.md`, `RESULTS.json` and `evidence.json` (the newer frozen diagnostic is outside checkpoint 174).

This was a targeted primary-source assessment, not an exhaustive literature review. `evidence.json` binds this review, the numeric substitutions, and the exact workspace documents consulted. No frozen parent was edited, no compiled or counter output was created, no checkpoint 175 was assembled, and no upload was attempted.
