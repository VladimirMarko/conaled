"""Root literal durability recovery for the consumed iota-repaired-interpreter185 attempt.

This checks existing bytes and captures paths; it does not rerun or accept a proof.
"""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPORT=HERE/'attempts/complete-01/report.json'
def binding(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def check(row):
    p=Path(row['path']);p=p if p.is_absolute() else ROOT/p
    actual=binding(p)
    assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256'])
    assert p.is_file() and not p.is_symlink()
    return p,actual
report_binding=binding(REPORT)
assert (report_binding['bytes'],report_binding['sha256'])==(1041645,'384f8a13525a2543b922e12faacc07b95f0cdeb7ba89a62a6dd3caec56dd347f')
r=json.loads(REPORT.read_text())
assert r['status']=='failed' and r['source_fingerprint']=='e83b4b93eed3f30889ab452f532fbf6799b75969f42def71f8f711e9087b653d'
pairs=[]
for row in r['source_bindings']+r['controls']:
    p,a=check(row);q,b=check(row['snapshot'])
    assert p.read_bytes()==q.read_bytes() and not (q.stat().st_mode & 0o222)
    pairs.append({'canonical':a['path'],'snapshot':b['path'],'bytes':a['bytes'],'sha256':a['sha256'],'snapshot_mode_octal':oct(q.stat().st_mode & 0o777),'literal_bytes_compared':True})
assert len(pairs)==1415
logs=[]
for module in r['modules']:
    for key in ('stdout','stderr'):
        _,b=check(module[key]);logs.append(b)
assert len(logs)==6
marker,marker_binding=check(r['execution_marker'])
assert not (marker.stat().st_mode & 0o222)
recovery={'format':'adwh-iota-repaired-interpreter185-current-attempt-durability-snapshot-recovery-v1','status':'all_actual_current_snapshot_and_canonical_bytes_equal','attempt':'complete-01','source_fingerprint':r['source_fingerprint'],'report':report_binding,'execution_marker':marker_binding,'snapshot_mapping_count':len(pairs),'snapshot_mappings':pairs,'raw_log_count':len(logs),'raw_logs':logs,'original_attempt_status_modified':False,'compiled_object_reuse_or_new_math_execution':False,'dedicated_saved_result_reader_executed':False}
out=HERE/'SNAPSHOT-RECOVERY.json';out.write_text(json.dumps(recovery,sort_keys=True,indent=2)+'\n')
receipt={'format':'adwh-root-iota-repaired-interpreter185-actual-execution-receipt-v1','executor':'/root','status':r['status'],'source_fingerprint_consumed':r['source_fingerprint'],'report':report_binding,'actual_source_snapshot_recovery':binding(out),'independent_control_review':binding(HERE/'INDEPENDENT-CONTROL-REVIEW.md'),'independent_static_check':binding(HERE/'INDEPENDENT-CONTROL-CHECK.json'),'actual_seconds':r['seconds'],'peak_rss_kib':r['peak_child_rss_kib'],'accepted_report_count':r['accepted_axiom_report_count'],'observed_report_count':r['observed_axiom_report_count'],'failed_physical_owner':'KernelCachedEventualInterpreter','all_failed_owner_reports_rejected':True,'prepared_object_reuse':False,'no_unchanged_retry_allowed':True,'dedicated_complete_saved_result_reader_executed':False,'whole_query_or_installed_or_stock_numeral_result_proved':False}
receipt_path=HERE/'ROOT-EXECUTION-RECEIPT.json';receipt_path.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':recovery['status'],'snapshots':len(pairs),'logs':len(logs),'recovery':binding(out),'receipt':binding(receipt_path),'marker':marker_binding},sort_keys=True,indent=2))
