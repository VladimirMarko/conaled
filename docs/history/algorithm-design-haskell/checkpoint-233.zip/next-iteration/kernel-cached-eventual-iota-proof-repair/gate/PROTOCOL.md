# Fresh corrected eventual interpreter: three owners, 185 reports

Only root may import or execute this runner, including its metadata preflight.
The control author has not imported, AST-checked, preflighted or executed it.
Root independently reviews these controls before using the metadata mode
without `--run`. A subsequent `--run --attempt complete-01 --lean
<pinned-bin/lean>` selects the sole complete fresh mathematical attempt.

## Current exact source selection

The physical order remains `KernelCompactCore`, `KernelCachedForward`, and
`KernelCachedEventualInterpreter`. Their sizes are 208582, 202799 and 207128
bytes, totaling 618509 bytes. Their unchanged ordered report counts are
2, 6 and 177, totaling 185 distinct roots. Exactly six fresh ordinary `.olean`
and `.ilean` outputs are required; no previous object is imported or reused.

Core and Cached are exact unchanged sources. The combined proof owner is the
separately reviewed diagnosed iota variant. One final proof span changes in
the logical OperationalContracts owner and the corresponding span changes in
the physical owner. Both overlays are checked in both directions, with their
two exhaustive unchanged complements. Every theorem statement, runtime
definition, premise, guard, state flow, bound, report, import and global option
is preserved. The proof adds local constructor discrimination and stages
existing definitional reductions and run-equation rewrites.

The candidate is reconstructed from the same five logical inputs. The four
other inputs remain literal, the eight original leading import comments are
unchanged, and thirteen complements plus the original initial/boundary
comments are checked. All physical endpoints use explicit half-open
`physical_end_byte_exclusive` fields. Empty spans retain the previously
reviewed insertion-line convention. All 183 theorem headers, 177 proof-owner
reports, 18 namespace blocks and the existing strict options retain their
original ownership. The old combined owner and old canonical alternatives
must not be imported alongside the selected owner.

The current logical-origin convention remains 28 names and 30 source segments.
Only the OperationalContracts current source identity changes in the origin
row array. Historical source rows remain in their original scope and are not
rebased to this new source.

## Historical scopes and evidence

The immutable consumed Interpreter185 validator is called only through its
metadata `preflight`. It retains the entire Foundation134, Pilot41 and
Interface111 validation chain and all 38 original independent source scopes.
No predecessor `main` or `run` is called. Only dependency handles normally
initialized by those old `main` functions are initialized; their selections,
manifests, policies, roots and review tables remain unchanged.

The new layer adds exactly one independent scope: the repair's 1342-input
author inventory and root's 1343-input audit. Its exact review, source maps,
23 primary intervals, six SDK context copies and thirteen actual diagnostic
spans are bound separately. The old Trace1051/1052, QueryBridge1264/1267 and
Assembly1305/1306 scopes remain literal. The total distinct review census is
39. Overlapping input arrays do not create additional review scopes.

All eight historical external-context tuples retain their exact routing.
No new external mapping is introduced. Every current source, metadata file,
control, exact reviewed input and predecessor control is bound before any
retained Python helper or validator is imported. The whole canonical union
is snapshotted read-only. The new SDK files are review context only.

The consumed attempt failed after 27.61938600800204 seconds. Core and Cached
passed eight reports; the combined owner failed, so none of its 177 reports
is accepted. All 185 names were observed. Its report, six raw logs, marker,
root receipt and snapshot-recovery map remain exact inputs. The failure and
error-recovery `sorryAx` reports do not establish new acceptance. The new
metadata maps raw captured diagnostic text without running a mathematical
saved-result acceptance reader.

This gate checks the reusable non-atomic interpreter and conditional query
interface. It does not include FN construction, Typing, Driver, guards,
numerical evaluation or native installation. No actual installed pins,
original GroupChecked result or stock numeral theorem is claimed.

## Unchanged execution and acceptance policy

All three sources are freshly compiled under one cumulative 30-second wall
interval, one selected CPU, one compiler thread, one import worker, a 1024-MiB
Lean cap and a 1048576-KiB process-tree/RSS cap. Heartbeat, recursion and compiler
defaults remain unchanged. Compiler flags are exactly `-j1 -M1024
-DautoImplicit=false -DwarningAsError=true -DElab.async=false`.

The pinned compiler, five runtime libraries, resource helper, source guard,
axiom parser, clean environment, affinity, watchdog, snapshot procedure and
post-run identity checks retain their original behavior. Core keeps its two
previously reviewed unused-simp exceptions; the current proof variant adds
no linter or resource option. No native program, exporter or counter runs.

The permanent fingerprint retains `cached-forward-runs-and-licensed` and
the exact policy plus ordered module/hash rule. All predecessor no-retry
directories are retained, with the consumed Interpreter185 directory added.
Before any compiler child, an exclusive read-only marker reserves the new
source key. An attempt rename or metadata edit cannot reset a consumed source.
There is no partial or per-owner retry and no per-owner wall allowance.

Acceptance requires all 185 distinct ordered reports, only `propext`,
`Quot.sound` and `Classical.choice`, empty stderr and no residual diagnostic
stdout, the exact six fresh artifacts, successful source/runtime/snapshot/
marker integrity checks and affinity restoration, elapsed time at most
30 seconds, and RSS within the fixed cap. A failed combined owner accepts
none of its 177 reports. The prior timing supplies no new fit guarantee.

## Explicit control correspondence

Four bounded logical run-block replacements add the predecessor marker
directory, update its comment, and change only the historical/total review
counts from 35/38 to 38/39. Complete byte edits, complements and forward/inverse
reconstruction are recorded in `CONTROL-CORRESPONDENCE.json`.

The snapshot/marker/affinity setup, complete cumulative timer/compiler/watchdog
and module audit, all post-run integrity/artifact/elapsed checks, and the full
acceptance predicate/flags/report tail are literal. Common identity/fingerprint
helpers and axiom-audit delegation are also literal. Whole-run-block identity
is not claimed. New metadata and bootstrap templates are explicit pinned
controls, not hidden changes to predecessor validators.
