#!/usr/bin/env python3
"""Author exact corrected185 controls as text/JSON; no retained code execution."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import pprint
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = HERE.parent
BASE = ROOT / 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)}


def load(path):
    path = Path(path)
    return json.loads((path if path.is_absolute() else ROOT / path).read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def array_ref(path, field):
    values = load(path)[field]
    data = canonical(values)
    return {'source': pin(path), 'json_field': field, 'item_count': len(values),
            'canonical_json_bytes': len(data), 'canonical_json_sha256': sha(data)}


def dump(name, data):
    path = HERE / name
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return pin(path)


def span(data, start, end):
    piece = data[start:end]
    return {'start_byte': start, 'end_byte_exclusive': end, 'bytes': len(piece), 'sha256': sha(piece)}


base_manifest = load(BASE / 'source-manifest.json')
base_runner = (BASE / 'run_gate.py').read_text()
source_inventory = load(PACKAGE / 'SOURCE-INVENTORY.json')
source_audit = load(PACKAGE / 'SOURCE-AUDIT.json')
source_census = load(PACKAGE / 'PROSPECTIVE-SOURCE-CENSUS.json')
assert pin(BASE / 'run_gate.py')['sha256'] == 'a4e8a9ce5260c025824ce6de6659cdf2a574a02b65b4384a28a3c251d32410a6'
assert pin(BASE / 'source-manifest.json')['sha256'] == 'd9816b3d1af507c83d6e2b2f3542c243a859f56e5fd9d80e4fa2d7449635957d'
assert base_manifest['current_total_separate_independent_review_scope_count'] == 38
assert source_inventory['input_count'] == len(source_inventory['inputs']) == 1342
assert source_audit['direct_input_count'] == len(source_audit['inputs']) == 1343
assert source_audit['checks']['author_input_count'] == 1342
assert source_audit['status'] == 'passed_independent_diagnosed_source_review_uncompiled'
assert pin(PACKAGE / 'SOURCE-AUDIT.json')['sha256'] == 'a3642f3cf55348a6115b2db6a4f8fc284fa2d659b877fbc7433587c76b2b2869'
assert pin(PACKAGE / 'SOURCE-REVIEW.md')['sha256'] == 'dae38a4bdac4a34632b0d8447d15892090e7e331b8f296d5b46c14983c98160f'

sources = copy.deepcopy(base_manifest['sources'])
sources[2].update(source_inventory['physical_source'])
assert source_inventory['selected_physical_sources'] == [{k: r[k] for k in ('path', 'bytes', 'sha256')} for r in sources]
assert sum(r['bytes'] for r in sources) == 618509
modules = [r['module'] for r in sources]
required = {r['module']: r['fully_qualified_roots'] for r in sources}
raw_required = {r['module']: r['raw_source_print_identifiers'] for r in sources}
assert modules == ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedEventualInterpreter']
assert [len(required[m]) for m in modules] == [2, 6, 177]
assert len({n for values in required.values() for n in values}) == 185
assert re.findall(r'^\s*#print\s+axioms\s+(\S+)', (ROOT / sources[2]['path']).read_text(), re.M) == raw_required[modules[2]]

scope = {'name': 'DiagnosedEventualIotaRepair',
         'author_inventory': pin(PACKAGE / 'SOURCE-INVENTORY.json'),
         'source_audit': pin(PACKAGE / 'SOURCE-AUDIT.json'),
         'source_review': pin(PACKAGE / 'SOURCE-REVIEW.md'),
         'author_inputs': array_ref(PACKAGE / 'SOURCE-INVENTORY.json', 'inputs'),
         'review_inputs': array_ref(PACKAGE / 'SOURCE-AUDIT.json', 'inputs'),
         'author_input_count': 1342, 'review_input_count': 1343,
         'audit_status': source_audit['status'], 'reviewer': source_audit['reviewer'],
         'original_scope_or_selection_rebased': False}
assert scope['source_audit']['path'] not in {r['path'] for r in base_manifest['controls']}
recovery = copy.deepcopy(base_manifest['external_review_context_recovery'])
assert len(recovery) == 8
bound = {}


def add(row):
    selected = {k: row[k] for k in ('path', 'bytes', 'sha256')}
    if selected['path'].startswith('../'):
        matches = [r for r in recovery if r['original_context'] == selected]
        assert len(matches) == 1, selected
        selected = matches[0]['retained_copy']
    assert not Path(selected['path']).is_absolute() and '..' not in Path(selected['path']).parts
    assert pin(selected['path']) == selected, selected['path']
    assert selected['path'] not in bound or bound[selected['path']] == selected, selected['path']
    bound[selected['path']] = selected


for row in base_manifest['sources'] + base_manifest['controls']:
    add(row)
add(pin(BASE / 'source-manifest.json'))
for document in (source_inventory, source_audit):
    for row in document['inputs']:
        add(row)
for key in ('author_inventory', 'source_audit', 'source_review'):
    add(scope[key])
for row in sources:
    add(row)
for name in ('AUTHOR-CONTROLS.py', 'runner-metadata.py.txt', 'runner-main.py.txt', 'PROTOCOL.md', 'AUTHORING.md'):
    add(pin(HERE / name))

policy = copy.deepcopy(base_manifest['policy'])
fingerprint_body = {'stage': 'cached-forward-runs-and-licensed', 'policy': policy,
                    'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
source_key = sha(json.dumps(fingerprint_body, sort_keys=True, separators=(',', ':')).encode())
assert source_key != base_manifest['source_fingerprint'] == source_inventory['consumed_source_key']


def literal(value):
    return pprint.pformat(value, sort_dicts=True, width=120)


prefix = base_runner[:base_runner.index('HERE = Path(__file__)')]
prefix = prefix.replace('Fresh consolidated non-atomic eventual interpreter185.',
                        'Fresh diagnosed-iota corrected eventual interpreter185.')
globals_text = """HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate'
REPAIR = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-iota-repaired185-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-iota-repaired185-manifest-v1'
PREVIOUS = None
HISTORICAL = None
"""
constants = {
    'POLICY': policy, 'ALLOWED': {'propext', 'Classical.choice', 'Quot.sound'},
    'PREVIOUS_RUNNER_PIN': tuple(pin(BASE / 'run_gate.py')[k] for k in ('path', 'bytes', 'sha256')),
    'PREVIOUS_MANIFEST_PIN': tuple(pin(BASE / 'source-manifest.json')[k] for k in ('path', 'bytes', 'sha256')),
    'MODULES': modules, 'SOURCE_PINS': [tuple(r[k] for k in ('path', 'bytes', 'sha256')) for r in sources],
    'EXPECTED_IMPORTS': {r['module']: r['imports'] for r in sources},
    'REQUIRED': required, 'RAW_REQUIRED': raw_required,
    'CURRENT_LOGICAL': source_inventory['logical_source'],
    'REPAIR_SCOPE': scope, 'REPAIR_REVIEW_FACTS': source_audit['checks'],
    'CONSUMED_SOURCE_KEY': base_manifest['source_fingerprint'],
    'EXTERNAL_RECOVERY': recovery,
    'NEW_FIXED': {p: r['sha256'] for p, r in sorted(bound.items())}}
for name, value in constants.items():
    globals_text += name + ' = ' + literal(value) + '\n'

common_helpers = base_runner[base_runner.index('def require('):base_runner.index('def check_source(')]
audit_logs = base_runner[base_runner.index('def audit_logs('):base_runner.index('def run(')]
old_run = base_runner[base_runner.index('def run('):base_runner.index('def main(')]
new_run = old_run
replacements = [
    ('# Every historical no-retry directory is retained, with the consumed134 foundation appended.',
     '# Every historical no-retry directory is retained, with the consumed185 interpreter appended.'),
    ('for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR]\n'
     '                           + [getattr(HISTORICAL, name) for name in prior_names]]',
     'for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR,\n'
     '                                        PREVIOUS.PREVIOUS.PREVIOUS.PREDECESSOR]\n'
     '                           + [getattr(HISTORICAL, name) for name in prior_names]]'),
    ("'historical_independent_review_scope_count': 35,", "'historical_independent_review_scope_count': 38,"),
    ("'total_separate_independent_review_scope_count': 38,", "'total_separate_independent_review_scope_count': 39,")]
for before, after in replacements:
    assert new_run.count(before) == 1, before
    new_run = new_run.replace(before, after, 1)

metadata = (HERE / 'runner-metadata.py.txt').read_text()
main = (HERE / 'runner-main.py.txt').read_text()
runner_text = prefix + globals_text + '\n' + common_helpers + metadata + '\n' + audit_logs + new_run + main
runner_path = HERE / 'run_gate.py'
assert not runner_path.exists()
runner_path.write_text(runner_text)
runner_pin = pin(runner_path)

old_bytes, new_bytes = old_run.encode(), new_run.encode()
old_full, new_full = base_runner.encode(), runner_text.encode()
old_offset = old_full.index(old_bytes); new_offset = new_full.index(new_bytes)
edits = []; complements = []
for kind, a, b, c, d in difflib.SequenceMatcher(None, old_bytes, new_bytes, autojunk=False).get_opcodes():
    row = {'original': span(old_bytes, a, b), 'candidate': span(new_bytes, c, d),
           'original_file_start_byte': old_offset+a, 'original_file_end_byte_exclusive': old_offset+b,
           'candidate_file_start_byte': new_offset+c, 'candidate_file_end_byte_exclusive': new_offset+d}
    if kind == 'equal':
        assert old_bytes[a:b] == new_bytes[c:d]
        complements.append(row)
    else:
        row.update({'kind': kind, 'before': old_bytes[a:b].decode(), 'after': new_bytes[c:d].decode()})
        edits.append(row)
forward = old_bytes
for row in reversed(edits):
    a, b = row['original']['start_byte'], row['original']['end_byte_exclusive']
    assert forward[a:b] == row['before'].encode()
    forward = forward[:a] + row['after'].encode() + forward[b:]
assert forward == new_bytes
inverse = new_bytes
for row in reversed(edits):
    a, b = row['candidate']['start_byte'], row['candidate']['end_byte_exclusive']
    assert inverse[a:b] == row['after'].encode()
    inverse = inverse[:a] + row['before'].encode() + inverse[b:]
assert inverse == old_bytes

literal_sections = []
for label, start, end in [
    ('snapshot_marker_affinity_environment_setup', '    h.save(report_path, report)\n    began = None', '        began = time.monotonic()'),
    ('complete_cumulative_timer_compiler_watchdog_and_module_audit', '        began = time.monotonic()', '    except BaseException as exc:'),
    ('postrun_readonly_runtime_artifact_affinity_and_elapsed_checks', "    finally:\n        try:\n            report['artifacts']", '        passed = (')]:
    a = old_run.index(start); b = old_run.index(end, a)
    c = new_run.index(start); d = new_run.index(end, c)
    assert old_run[a:b] == new_run[c:d], label
    literal_sections.append({'label': label,
        'original_file_span': span(old_full, old_offset+a, old_offset+b),
        'candidate_file_span': span(new_full, new_offset+c, new_offset+d)})
start = '        passed = ('
a, c = old_run.index(start), new_run.index(start)
assert old_run[a:] == new_run[c:]
literal_sections.append({'label': 'complete_acceptance_flags_and_final_report_tail',
    'original_file_span': span(old_full, old_offset+a, old_offset+len(old_bytes)),
    'candidate_file_span': span(new_full, new_offset+c, new_offset+len(new_bytes))})
for label, text in [('common_identity_fingerprint_integrity_helpers', common_helpers),
                    ('unchanged_axiom_audit_delegation', audit_logs)]:
    data = text.encode(); a, c = old_full.index(data), new_full.index(data)
    literal_sections.append({'label': label, 'original_file_span': span(old_full, a, a+len(data)),
                             'candidate_file_span': span(new_full, c, c+len(data))})
assert len(literal_sections) == 6

correspondence = dump('CONTROL-CORRESPONDENCE.json', {
    'format': 'adwh-iota-repaired185-from-consumed-interpreter185-controls-v1',
    'status': 'source_only_controls_awaiting_independent_root_review',
    'baseline_runner': pin(BASE / 'run_gate.py'), 'baseline_manifest': pin(BASE / 'source-manifest.json'),
    'baseline_control_review': pin(BASE / 'INDEPENDENT-CONTROL-REVIEW.md'),
    'baseline_control_audit': pin(BASE / 'INDEPENDENT-CONTROL-CHECK.json'),
    'baseline_consumed_report_identity_only': pin(BASE / 'attempts/complete-01/report.json'),
    'baseline_root_execution_receipt': pin(BASE / 'ROOT-EXECUTION-RECEIPT.json'),
    'baseline_snapshot_recovery': pin(BASE / 'SNAPSHOT-RECOVERY.json'),
    'candidate_runner': runner_pin,
    'source_of_new_metadata': pin(HERE / 'runner-metadata.py.txt'),
    'source_of_new_bootstrap': pin(HERE / 'runner-main.py.txt'),
    'run_block_original_file_span': span(old_full, old_offset, old_offset+len(old_bytes)),
    'run_block_candidate_file_span': span(new_full, new_offset, new_offset+len(new_bytes)),
    'run_block_exact_logical_replacement_count': len(replacements),
    'run_block_logical_replacements': [{'before': a, 'after': b} for a, b in replacements],
    'run_block_actual_edit_count': len(edits), 'run_block_actual_edits': edits,
    'run_block_unchanged_complement_count': len(complements), 'run_block_unchanged_complements': complements,
    'complete_run_block_forward_and_inverse_verified': True,
    'whole_run_block_literal_claimed': False, 'literal_execution_sections': literal_sections,
    'resource_limits_default_options_compiler_flags_timer_watchdog_affinity_and_three_axioms_changed': False,
    'complete_acceptance_predicate_or_report_flags_changed': False,
    'permanent_stage_or_fingerprint_policy_changed': False,
    'additional_predecessor_marker_directory': 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate',
    'all_prior_marker_directories_retained': True,
    'metadata_only_validation_chain': ['corrected185', 'unchanged185', 'unchanged134', 'unchanged41', 'unchanged111'],
    'old_run_or_main_called': False,
    'old_selection_policy_manifest_or_review_globals_modified': False,
    'old_dependency_handles_initialized_as_in_their_original_main': True,
    'historical_review_scope_count': 38, 'new_exact_independent_audit_scopes': 1,
    'total_distinct_review_scope_count': 39,
    'external_tuple_routes': 8, 'all_eight_external_tuple_routes_unchanged': True,
    'current_sources_and_metadata_bound_before_any_retained_import': True,
    'physical_module_acceptance_all_or_nothing': True,
    'author_imported_AST_checked_preflighted_or_executed_runner_or_math': False})
add(runner_pin); add(correspondence)

source_paths = {r['path'] for r in sources}
controls = [{**row, 'role': f'bound-input-{index:04d}'} for index, row in enumerate(
    [bound[p] for p in sorted(bound) if p not in source_paths], 1)]
assert len({r['path'] for r in controls}) == len(controls)
assert all(not r['path'].endswith(('.olean', '.ilean', '.c', '.o', '.so')) for r in controls)
origin_rows = copy.deepcopy(base_manifest['complete_origin_source_rows'])
assert len(origin_rows) == 28 and origin_rows[24]['path'] == 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedOperationalContracts.lean'
origin_rows[24] = source_inventory['logical_source']
historical_fields = ['historical_context', 'new_separate_review_scopes',
                     'external_review_context_recovery', 'logical_origins', 'complete_origin_source_rows']
manifest = {
    'format': 'adwh-kernel-cached-eventual-iota-repaired185-manifest-v1',
    'status': 'frozen_ready_for_independent_root_control_review',
    'policy': policy, 'module_order': modules, 'sources': sources, 'prepared_objects': [], 'export_targets': [],
    'ordered_report_counts': [2, 6, 177], 'required_axiom_report_count': 185,
    'required_unique_axiom_name_count': 185, 'selected_physical_source_bytes': 618509,
    'expected_artifact_count': 6,
    'logical_origins': base_manifest['logical_origins'], 'complete_origin_source_rows': origin_rows,
    'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,
    'distinct_logical_origin_count': 28, 'source_segment_count': 30,
    'source_segment_count_convention': base_manifest['source_segment_count_convention'],
    'historical_context': {'runner': pin(BASE / 'run_gate.py'), 'manifest': pin(BASE / 'source-manifest.json'),
        'validator': 'preflight', 'historical_review_scope_count': 38,
        'exact_field_references': {field: array_ref(BASE / 'source-manifest.json', field) for field in historical_fields},
        'old_main_or_run_called': False, 'old_source_selection_or_review_arrays_mutated': False,
        'old_dependency_handles_initialized': True, 'old_complete_preflight_checks_retained': True},
    'historical_independent_review_scope_count': 38,
    'current_total_separate_independent_review_scope_count': 39,
    'historical_reviews_rebased': False, 'new_separate_review_scopes': [scope],
    'new_independent_review_scope_count': 1,
    'review_scope_deduplication': 'Only exact audit identity; overlapping input arrays are not additional source reviews',
    'external_review_context_recovery': recovery,
    'root_only_preflight_and_run': True, 'all_current_cached_runtime_declarations_preserved': True,
    'actual_reference_state_is_empty_CState': True, 'conditional_record_wrapper_only': True,
    'non_atomic_trace_interpreter_and_query_interface_included': True,
    'FN_construction_Typing_Driver_or_guards_selected': False,
    'whole_query_cached_success_claimed': False, 'original_GroupChecked_claimed': False,
    'stock_numeral_theorem_claimed': False, 'measured_cost_benefit_or_budget_fit_claimed_before_run': False,
    'consumed_predecessor_source_key': base_manifest['source_fingerprint'],
    'source_fingerprint': source_key, 'controls': controls,
    'snapshot_count_including_manifest': len(sources)+len(controls)+1}
manifest_pin = dump('source-manifest.json', manifest)
print(json.dumps({'runner': runner_pin, 'manifest': manifest_pin, 'correspondence': correspondence,
                  'source_fingerprint': source_key, 'controls': len(controls),
                  'snapshots_including_manifest': len(sources)+len(controls)+1,
                  'run_logical_replacements': len(replacements), 'run_actual_edits': len(edits),
                  'run_unchanged_complements': len(complements), 'literal_sections': len(literal_sections)}, indent=2))
