#!/usr/bin/env python3
"""New literal source/provenance authoring only; no Lean, gate, or saved-result reader.

This script is not a mathematical test or a reusable preflight. It creates a
distinct candidate by one explicitly supplied proof-text replacement, records
the inverse, and preserves the consumed inputs. It reads the raw diagnostic log
only to locate its captured error spans; it does not parse the execution report.
"""
from pathlib import Path
import copy
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/618374bfa892/adwh-work')
SDK = Path('/workspace/scratch/618374bfa892/toolchains/lean-4.35.0-linux/src/lean')
REL = 'next-iteration/kernel-cached-eventual-iota-proof-repair'
HERE = ROOT / REL
OLD_REL = 'next-iteration/kernel-cached-eventual-interpreter-assembly'
OLD = ROOT / OLD_REL
LOGICAL = 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedOperationalContracts.lean'
PHYSICAL = OLD_REL + '/source/KernelCachedEventualInterpreter.lean'
NEW_LOGICAL = REL + '/logical-source/KernelCachedOperationalContracts.lean'
NEW_PHYSICAL = REL + '/source/KernelCachedEventualInterpreter.lean'
OLD_KEY = '6d1c0f24fe1c4f55b520bf9e52b95884dc9e964065a107d0ebc1fcc89fe6370d'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return (ROOT / path).read_bytes()


def ident(path):
    data = read(path)
    return {'path': path, 'bytes': len(data), 'sha256': sha(data)}


def check_id(row):
    assert ident(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}, row


def write(path, data):
    dest = ROOT / path
    assert not dest.exists(), f'Frozen or already-authored destination exists: {dest}'
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data if isinstance(data, bytes) else data.encode())
    return ident(path)


def dump(name, value):
    return write(REL + '/' + name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def span(data, lo, hi):
    assert 0 <= lo <= hi <= len(data)
    first = data[:lo].count(b'\n') + 1
    last = max(first, data[:hi].count(b'\n') + (0 if hi and data[hi-1:hi] == b'\n' else 1))
    return {'start_byte': lo, 'end_byte_exclusive': hi,
            'first_line': first, 'last_line_inclusive': last,
            'bytes': hi-lo, 'sha256': sha(data[lo:hi])}


def one_overlay(old_path, new_path, before, after):
    old = read(old_path)
    assert old.count(before) == 1
    at = old.index(before)
    new = old[:at] + after + old[at+len(before):]
    write(new_path, new)
    assert new[:at] + before + new[at+len(after):] == old
    complements = [
        {'original': span(old, 0, at), 'candidate': span(new, 0, at)},
        {'original': span(old, at+len(before), len(old)),
         'candidate': span(new, at+len(after), len(new))}]
    for c in complements:
        a, b = c['original'], c['candidate']
        assert old[a['start_byte']:a['end_byte_exclusive']] == new[b['start_byte']:b['end_byte_exclusive']]
    return {'original': ident(old_path), 'candidate': ident(new_path),
            'edit_count': 1, 'edits': [{
                'kind': 'diagnosed_iota_proof_staging_only',
                'original': span(old, at, at+len(before)),
                'candidate': span(new, at, at+len(after)),
                'before': before.decode(), 'after': after.decode()}],
            'unchanged_complement_count': 2,
            'unchanged_complements': complements,
            'complete_forward_and_inverse_verified': True}


old_inventory = json.loads((OLD / 'SOURCE-INVENTORY.json').read_text())
old_map = json.loads((OLD / 'SOURCE-CORRESPONDENCE.json').read_text())
old_census = json.loads((OLD / 'SOURCE-CENSUS.json').read_text())
assert old_inventory['input_count'] == len(old_inventory['inputs']) == 1305
for row in old_inventory['inputs']:
    check_id(row)
assert ident(LOGICAL)['sha256'] == '1d1599494d88cb0e1c26c260b71996000d860fb9a2491cd98439166e665c1bdf'
assert ident(PHYSICAL)['sha256'] == '9c60b1c565372d266a15c7bc40e2f59e3a5cbded8b0f97cc497934546abc949a'
assert read(PHYSICAL) == read(OLD_REL + '/gate/attempts/complete-01/source/KernelCachedEventualInterpreter.lean')

before = b'''  simp only [substLevelTreesM, List.map_nil, isEquivListLM, liftFueled,
    RecRule.compareParams, certAtI, CheckMode.certs, CheckMode.betaGate,
    Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind,
    \xe2\x86\x93reduceIte, recursorTypeRun, recursorCert, constructorTypeRun, constructorCert,
    indexCert, rhsRun, mkAppNM]
  all_goals rfl
'''
after = '''  have plainNotInert : RecRuleFire.plain ≠ RecRuleFire.inert := by
    intro impossible
    cases impossible
  rw [ite_eq_right plainNotInert]
  dsimp only [substLevelTreesM, List.map, List.take, List.drop, List.append,
    isEquivListLM, liftFueled, RecRule.compareParams, certAtI,
    CheckMode.certs, CheckMode.betaGate, mkAppNM,
    Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind,
    Bool.not, ite, dite, Bool.decEq, Bool.beq]
  rw [recursorTypeRun]
  dsimp only [Except.bind]
  rw [recursorCert]
  dsimp only [Except.bind]
  rw [constructorTypeRun]
  dsimp only [Except.bind]
  rw [constructorCert]
  dsimp only [Except.bind]
  rw [indexCert]
  dsimp only [Except.bind]
  rw [rhsRun]
  all_goals rfl
'''.encode()

logical_overlay = one_overlay(LOGICAL, NEW_LOGICAL, before, after)
physical_overlay = one_overlay(PHYSICAL, NEW_PHYSICAL, before, after)
assert logical_overlay['edits'][0]['original']['first_line'] == 613
assert physical_overlay['edits'][0]['original']['first_line'] == 3086

decl_start = read(LOGICAL).index(b'theorem iota_plain_of_prepared ')
header_end = read(LOGICAL).index(b' := by\n', decl_start) + len(b' := by\n')
logical_header = read(LOGICAL)[decl_start:header_end]
assert read(NEW_LOGICAL)[decl_start:header_end] == logical_header
physical_decl_start = read(PHYSICAL).index(b'theorem iota_plain_of_prepared ')
assert read(PHYSICAL)[physical_decl_start:physical_decl_start+len(logical_header)] == logical_header
assert read(NEW_PHYSICAL)[physical_decl_start:physical_decl_start+len(logical_header)] == logical_header

def token_lines(data, pattern):
    return re.findall(pattern, data, flags=re.M)

for base, candidate in [(LOGICAL, NEW_LOGICAL), (PHYSICAL, NEW_PHYSICAL)]:
    a, b = read(base), read(candidate)
    for pattern in [rb'^#print axioms .*$', rb'^set_option .*$', rb'^(?:namespace|end|open|section|variable|attribute|instance|syntax|macro).*$',
                    rb'^(?:private )?(?:theorem|def|abbrev|structure|inductive) .*$', rb'^import .*$']:
        assert token_lines(a, pattern) == token_lines(b, pattern), (base, pattern)
    assert not re.search(rb'\b(?:sorry|admit|axiom|unsafe)\b', after)

proof_map = dump('PROOF-CORRECTION.json', {
    'format': 'adwh-eventual-iota-terminal-proof-repair-v1',
    'status': 'source_only_uncompiled_pending_independent_review',
    'theorem': 'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared',
    'diagnostic_scope': 'one failed terminal proof plus twelve unused simp arguments in the same proof',
    'logical': logical_overlay, 'physical': physical_overlay,
    'shared_replacement_text_literal': True,
    'theorem_header': {'logical_original': span(read(LOGICAL), decl_start, header_end),
                       'physical_original': span(read(PHYSICAL), physical_decl_start, physical_decl_start+len(logical_header)),
                       'literal_text': logical_header.decode()},
    'premises_definitions_guards_budget_state_order_and_report_roots_unchanged': True,
    'new_local_fact_only': 'RecRuleFire.plain ≠ RecRuleFire.inert, discharged by constructor discrimination',
    'new_global_declarations_instances_options_attributes_or_reports': False})

# Reconstruct the combined candidate independently from its five selected
# logical files and the eight original import-comment replacements.
assembled = old_map['header_literal'].encode()
origins = []
for old_origin in old_map['origins']:
    source_path = NEW_LOGICAL if old_origin['order'] == 2 else old_origin['source']['path']
    raw = read(source_path)
    transformed = b''
    cursor = 0
    edits = []
    complements = []
    for old_edit in old_origin['edits']:
        lo = old_edit['original']['start_byte']
        hi = old_edit['original']['end_byte_exclusive']
        bef, aft = old_edit['before'].encode(), old_edit['after'].encode()
        assert raw[lo:hi] == bef
        unchanged_start = len(transformed)
        transformed += raw[cursor:lo]
        complements.append({'original': span(raw, cursor, lo),
                            'transformed_start_byte': unchanged_start,
                            'transformed_end_byte_exclusive': len(transformed)})
        new_start = len(transformed)
        transformed += aft
        edits.append({'kind': old_edit['kind'], 'imported_module': old_edit['imported_module'],
                      'original': span(raw, lo, hi), 'before': bef.decode(), 'after': aft.decode(),
                      'transformed_start_byte': new_start,
                      'transformed_end_byte_exclusive': len(transformed)})
        cursor = hi
    unchanged_start = len(transformed)
    transformed += raw[cursor:]
    complements.append({'original': span(raw, cursor, len(raw)),
                        'transformed_start_byte': unchanged_start,
                        'transformed_end_byte_exclusive': len(transformed)})
    inverse = transformed
    for edit in reversed(edits):
        lo, hi = edit['transformed_start_byte'], edit['transformed_end_byte_exclusive']
        assert inverse[lo:hi] == edit['after'].encode()
        inverse = inverse[:lo] + edit['before'].encode() + inverse[hi:]
    assert inverse == raw
    banner = old_origin['banner']['literal'].encode()
    footer = old_origin['footer']['literal'].encode()
    banner_lo = len(assembled)
    assembled += banner
    body_lo = len(assembled)
    assembled += transformed
    footer_lo = len(assembled)
    assembled += footer
    for edit in edits:
        lo, hi = edit.pop('transformed_start_byte'), edit.pop('transformed_end_byte_exclusive')
        edit.update({'transformed': span(transformed, lo, hi),
                     'physical_start_byte': body_lo+lo, 'physical_end_byte_exclusive': body_lo+hi})
    for c in complements:
        lo, hi = c.pop('transformed_start_byte'), c.pop('transformed_end_byte_exclusive')
        c.update({'transformed': span(transformed, lo, hi),
                  'physical_start_byte': body_lo+lo, 'physical_end_byte_exclusive': body_lo+hi})
        assert raw[c['original']['start_byte']:c['original']['end_byte_exclusive']] == transformed[lo:hi]
    origins.append({'order': old_origin['order'], 'original_module': old_origin['original_module'],
                    'source': ident(source_path), 'historical_original_source': old_origin['source'],
                    'logical_proof_overlay_selected': old_origin['order'] == 2,
                    'banner': {'literal': banner.decode(), 'physical_start_byte': banner_lo,
                               'physical_end_byte_exclusive': body_lo},
                    'body': {'physical_start_byte': body_lo, 'physical_end_byte_exclusive': footer_lo,
                             'bytes': len(transformed), 'sha256': sha(transformed)},
                    'footer': {'literal': footer.decode(), 'physical_start_byte': footer_lo,
                               'physical_end_byte_exclusive': len(assembled)},
                    'edits': edits, 'edit_count': len(edits),
                    'unchanged_complements': complements,
                    'unchanged_complement_count_including_empty_spans': len(complements),
                    'complete_forward_and_inverse_verified': True,
                    'all_bytes_of_selected_logical_source_literal_except_original_import_comments': True,
                    'ordered_report_roots': old_origin['ordered_report_roots'],
                    'report_count': old_origin['report_count']})
assert assembled == read(NEW_PHYSICAL)
assert sum(o['edit_count'] for o in origins) == 8
assert sum(len(o['unchanged_complements']) for o in origins) == 13
assert sum(o['report_count'] for o in origins) == 177
lineage = dump('ASSEMBLY-LINEAGE.json', {
    'format': 'adwh-eventual-iota-repaired-five-origin-assembly-v1',
    'original_assembly_map': ident(OLD_REL + '/SOURCE-CORRESPONDENCE.json'),
    'original_assembly_scope_preserved_without_rebase': True,
    'original_physical_source': ident(PHYSICAL), 'candidate': ident(NEW_PHYSICAL),
    'proof_overlay': proof_map, 'header_literal': old_map['header_literal'],
    'header_span': span(assembled, 0, len(old_map['header_literal'].encode())),
    'origins': origins, 'direct_physical_input_count': 5,
    'unchanged_logical_inputs': 4, 'changed_logical_inputs': 1,
    'internalized_import_count': 8, 'unchanged_complement_count_including_empty_spans': 13,
    'new_boundary_comment_count_from_original_assembly': 10,
    'new_initial_comment_count_from_original_assembly': 1,
    'complete_new_five_origin_forward_and_inverse_verified': True,
    'candidate_equals_single_physical_proof_overlay': True,
    'namespace_private_global_simp_option_and_import_environment_changed': False,
    'local_fact_added_within_existing_proof_only': True})

log_path = OLD_REL + '/gate/attempts/complete-01/KernelCachedEventualInterpreter.stdout.log'
report_path = OLD_REL + '/gate/attempts/complete-01/report.json'
assert ident(report_path)['sha256'] == 'a8ab666d2f7d52d02248b3f9447c0dd8102309d7ed702f24b9bbcb1e655ce45e'
log = read(log_path)
heads = list(re.finditer(rb'^KernelCachedEventualInterpreter\.lean:(\d+):(\d+): error: ([^\n]*)', log, re.M))
assert len(heads) == 13
old_contract_body_lo = old_map['origins'][1]['body']['physical_start_byte']
line_offset = read(PHYSICAL)[:old_contract_body_lo].count(b'\n')
logical_lines = read(LOGICAL).splitlines(keepends=True)
physical_lines = read(PHYSICAL).splitlines(keepends=True)
diagnostics = []
for n, head in enumerate(heads):
    end = heads[n+1].start() if n+1 < len(heads) else len(log)
    following_report = re.search(rb"^'[^\n]+' depends on axioms:", log[head.end():end], re.M)
    if following_report:
        end = head.end() + following_report.start()
    pline, col = int(head[1]), int(head[2])
    lline = pline - line_offset
    assert 613 <= lline <= 618
    assert logical_lines[lline-1] == physical_lines[pline-1]
    diagnostics.append({'id': f'IOTA-{n+1:02d}',
                        'kind': 'terminal_rfl_failure' if n == 0 else 'unused_simp_argument',
                        'log_span': span(log, head.start(), end),
                        'captured_text': log[head.start():end].decode(),
                        'physical_line': pline, 'logical_line': lline, 'column': col,
                        'source_line': logical_lines[lline-1].decode(),
                        'theorem': 'iota_plain_of_prepared',
                        'correction_scope': 'single_terminal_proof_overlay'})
assert diagnostics[0]['physical_line'] == 3091
assert all(d['physical_line'] in (3086, 3088, 3089, 3090) for d in diagnostics[1:])
assert len(re.findall(rb"^'[^\n]+' depends on axioms:", log, re.M)) == 177
diagnostic_map = dump('CAPTURED-DIAGNOSTICS.json', {
    'format': 'adwh-eventual-iota-complete-captured-diagnostics-v1',
    'raw_stdout': ident(log_path), 'report_identity_only': ident(report_path),
    'root_execution_receipt': ident(OLD_REL + '/gate/ROOT-EXECUTION-RECEIPT.json'),
    'root_result_note': ident(OLD_REL + '/gate/RESULT-AND-NEXT.md'),
    'consumed_source_key': OLD_KEY,
    'raw_stdout_ends_in_newline': log.endswith(b'\n'),
    'raw_stdout_line_count': len(log.splitlines()),
    'complete_captured_error_headers': len(heads),
    'failed_terminal_proof_headers': 1, 'unused_simp_argument_headers': 12,
    'all_captured_errors_in_one_existing_proof_scope': True,
    'raw_stdout_report_headers_observed': 177,
    'report_was_executed_or_parsed_by_author': False,
    'captured_recovery_axiom_output_is_not_source_admission_or_acceptance': True,
    'diagnostics': diagnostics})

# Pin exact primary implementations and small SDK support intervals. SDK files
# are durable literal copies, not compiled inputs or replacement dependencies.
sdk_files = ['Init/Prelude.lean', 'Init/Control/State.lean', 'Init/Control/Except.lean',
             'Init/Data/List/Basic.lean', 'Lean/Elab/Tactic/Simp.lean',
             'Lean/Meta/Tactic/Simp/BuiltinSimprocs/Core.lean']
sdk_rows = []
for name in sdk_files:
    data = (SDK / name).read_bytes()
    row = write(REL + '/sdk/' + name, data)
    sdk_rows.append({'sdk_relative_path': name, 'copy': row,
                     'complete_copy_matches_pinned_SDK': True})

core = old_inventory['selected_physical_sources'][0]['path']
cached = old_inventory['selected_physical_sources'][1]['path']
interval_specs = [
    ('recursor_rule_fire', core, 2822, 2826),
    ('recursor_parameter_comparison', core, 2877, 2880),
    ('actual_lift_fueled', core, 4582, 4587),
    ('actual_mk_app', cached, 2078, 2081),
    ('actual_level_substitution', cached, 2100, 2104),
    ('actual_level_list_comparison', cached, 2146, 2154),
    ('actual_certificate_gate', cached, 2539, 2542),
    ('complete_actual_iota', cached, 2982, 3075),
    ('existing_telescope_certificate_lemmas', LOGICAL, 36, 78),
    ('complete_logical_failed_theorem', LOGICAL, 554, 618),
    ('complete_physical_failed_theorem', PHYSICAL, 3027, 3091),
    ('bool_not', REL + '/sdk/Init/Prelude.lean', 1079, 1087),
    ('bool_beq', REL + '/sdk/Init/Prelude.lean', 1115, 1118),
    ('bool_decidable_equality', REL + '/sdk/Init/Prelude.lean', 1266, 1281),
    ('dependent_conditional', REL + '/sdk/Init/Prelude.lean', 1318, 1320),
    ('ordinary_conditional', REL + '/sdk/Init/Prelude.lean', 1344, 1346),
    ('state_pure_bind', REL + '/sdk/Init/Control/State.lean', 72, 85),
    ('except_pure', REL + '/sdk/Init/Control/Except.lean', 19, 24),
    ('except_bind', REL + '/sdk/Init/Control/Except.lean', 65, 69),
    ('list_take_drop', REL + '/sdk/Init/Data/List/Basic.lean', 902, 929),
    ('simp_argument_reporting', REL + '/sdk/Lean/Elab/Tactic/Simp.lean', 788, 799),
    ('dsimp_elaboration', REL + '/sdk/Lean/Elab/Tactic/Simp.lean', 819, 843),
    ('conditional_reduction_boundary', REL + '/sdk/Lean/Meta/Tactic/Simp/BuiltinSimprocs/Core.lean', 15, 24)]
intervals = []
for label, path, first, last in interval_specs:
    data = read(path)
    lines = data.splitlines(keepends=True)
    lo = sum(map(len, lines[:first-1])); hi = sum(map(len, lines[:last]))
    assert 1 <= first <= last <= len(lines)
    intervals.append({'label': label, 'source': ident(path), 'span': span(data, lo, hi),
                      'literal_text': data[lo:hi].decode()})
primary = dump('PRIMARY-SOURCE-CONTEXT.json', {
    'format': 'adwh-eventual-iota-proof-primary-context-v1',
    'SDK_full_copies': sdk_rows, 'interval_count': len(intervals), 'intervals': intervals,
    'SDK_source_or_intervals_are_compiled_inputs': False,
    'tactic_options_resource_options_or_linter_settings_changed': False})

history = dump('HISTORICAL-REVIEW-SCOPES.json', {
    'format': 'adwh-eventual-iota-proof-preserved-scopes-v1',
    'original_assembly_historical_scope_ledger': ident(OLD_REL + '/HISTORICAL-REVIEW-SCOPES.json'),
    'original_foundation_35_trace_and_bridge_scopes_preserved_in_consumed_controls': ident(OLD_REL + '/gate/source-manifest.json'),
    'new_scope_is_one_diagnosed_overlay_over_separate_prior_scopes': True,
    'original_arrays_statuses_and_source_selections_rebased': False,
    'immediate_scopes': [
        {'name': 'logical_trace', 'author_count': 1051, 'review_count': 1052,
         'inventory': ident('next-iteration/kernel-cached-eventual-trace/SOURCE-INVENTORY.json'),
         'audit': ident('next-iteration/kernel-cached-eventual-trace/SOURCE-AUDIT.json'),
         'review': ident('next-iteration/kernel-cached-eventual-trace/SOURCE-REVIEW.md')},
        {'name': 'query_bridge', 'author_count': 1264, 'review_count': 1267,
         'inventory': ident('next-iteration/kernel-cached-eventual-query-bridge/SOURCE-INVENTORY.json'),
         'audit': ident('next-iteration/kernel-cached-eventual-query-bridge/SOURCE-AUDIT.json'),
         'review': ident('next-iteration/kernel-cached-eventual-query-bridge/SOURCE-REVIEW.md')},
        {'name': 'consumed_interpreter_assembly', 'author_count': 1305, 'review_count': 1306,
         'inventory': ident(OLD_REL + '/SOURCE-INVENTORY.json'),
         'audit': ident(OLD_REL + '/SOURCE-AUDIT.json'),
         'review': ident(OLD_REL + '/SOURCE-REVIEW.md')}],
    'original_private_scope_audit': ident(OLD_REL + '/PRIVATE-AND-SCOPE-AUDIT.json'),
    'no_new_global_scope_or_instance_or_simp_environment': True})

selection = copy.deepcopy(old_census)
selection['format'] = 'adwh-eventual-iota-repair-prospective-source-census-v1'
selection['status'] = 'source_only_no_gate_selected'
selection['selected_physical_sources'] = old_inventory['selected_physical_sources'][:2] + [ident(NEW_PHYSICAL)]
selection['source_bytes'] = sum(row['bytes'] for row in selection['selected_physical_sources'])
for row in selection['physical_modules']:
    if row.get('module') == 'KernelCachedEventualInterpreter':
        # Preserve all root metadata; update an embedded identity only when present.
        for key in ('source', 'source_identity'):
            if isinstance(row.get(key), dict) and row[key].get('path') == PHYSICAL:
                row[key] = ident(NEW_PHYSICAL)
        if row.get('path') == PHYSICAL:
            row.update(ident(NEW_PHYSICAL))
selection['logical_proof_overlay'] = proof_map
selection['assembly_lineage'] = lineage
selection['consumed_selection_retained_as_history'] = ident(OLD_REL + '/SOURCE-CENSUS.json')
selection['Core_and_Cached_unchanged'] = True
selection['only_one_of_177_proof_bodies_changed'] = True
selection['complete_new_closure_compiled_or_budget_fit_claimed'] = False
selection['source_key_unconsumed_and_no_gate_authored_here'] = True
current = dump('PROSPECTIVE-SOURCE-CENSUS.json', selection)

plan = '''# Diagnosed eventual iota proof repair

This is a separate source-only candidate after the sole Interpreter185 attempt failed. That complete attempt took 27.61938600800204 seconds and accepted only the two Core and six Cached reports. All 185 report names were observed, but the combined interpreter owner failed and none of its 177 reports is accepted. The consumed source, controls, report, marker and snapshot recovery remain unchanged.

## Exact mathematical correction

The failed final proof remains underneath the test `RecRuleFire.plain = RecRuleFire.inert`. The existing restricted simplification does not prove that constructor inequality. In that unreduced StateT branch it also does not expose the empty-level comparison and the six pointwise helper/certificate equations. Its final reflexivity fails, and the strict linter reports twelve unused simplification arguments in this same scope.

The new proof first proves that the two constructors differ and rewrites only that actual guard. It then definitionally unfolds the concrete empty lists, the plain rule's parameter-blind comparison, verified certificate switches, the StateT/Except plumbing, and the Boolean conditional definitions. These are the existing definitions, not new equations or assumed behavior. The saved recursor-type, telescope, constructor-type, constructor-telescope, index and RHS runs are then rewritten in their actual order, with explicit Except.bind reduction between them. The final `all_goals rfl` is safe whether the final rewrite already closes the goal or leaves a reflexive constructor equation.

Only the old six-line final proof block is replaced. The complete theorem header, all lookup/arity/metadata/license premises, all executable definitions and branches, every returned state, the local/fuel bounds, all 185 report roots, imports, global options and attributes remain unchanged. The only new fact is local constructor discrimination. No success or numerical-answer premise is added.

## Physical and historical ownership

`logical-source/KernelCachedOperationalContracts.lean` is a new alternate logical owner; it must replace, never accompany, the frozen old canonical owner. `source/KernelCachedEventualInterpreter.lean` is a separate new physical assembly owner. It is reconstructed from the same five logical inputs and original eight import comments; only the selected OperationalContracts proof block differs. The other four logical files, both runtime owners, all original boundary comments and the lexical/import/private/simp environments remain literal. The old combined owner must not be imported alongside the new one.

The two one-span overlays have complete forward/inverse reconstruction and two unchanged complements each. `ASSEMBLY-LINEAGE.json` records the five-input reconstruction, all eight import edits and thirteen complements without rebasing the original 1305/1306 assembly scope, 1051/1052 trace scope, 1264/1267 bridge scope or inherited Foundation scopes. All half-open byte fields use an explicit `end_byte_exclusive` spelling; empty spans retain the original insertion-line convention.

## Evidence and limits

`CAPTURED-DIAGNOSTICS.json` retains all thirteen complete error spans in the actual captured stdout, their physical/logical source lines, and exact identities of the report and root receipt. The author read and mapped the raw text but did not execute or parse the mathematical report with a saved-result reader. The error-recovery `sorryAx` reports are rejected evidence, not author admissions or accepted theorems.

This package is uncompiled and awaits an independent full proof/source review. It authors no gate. A later selected gate must freshly compile the entire three-owner, 185-report closure under the unchanged cumulative 30-second, one-CPU, one-GiB/default-options policy, with no prepared object reuse. The failed attempt's timing establishes no fit guarantee for this candidate. The concrete FN construction, actual installed guards, original record/GroupChecked bridge and stock numeral remain separate obligations.
'''
write(REL + '/PLAN.md', plan)
write(REL + '/AUTHOR-REVIEW.md', '''# Bounded author source review

The author read the full failed iota theorem, complete actual iotaRecI definition, rule-fire/parameter decisions, empty level comparison, verified certificate gate and six pointwise run premises. The sequential state flow is unchanged: afterMajor → afterRecursorType → afterConstructorType → afterRhs, with the existing telescope/index certificates preserving the intermediate state.

The new block uses constructor discrimination for the actual inert-rule guard, then explicit definitional setup reduction and six ordered premise rewrites. No theorem header, dynamic guard, evaluator operation, exception path or certificate license is changed. The source remains uncompiled; elaboration and complete fresh acceptance are not claimed.

New literal bookkeeping reconstructs both proof overlays in both directions, all five physical input segments, eight original import changes and all complements. It verifies all old 1305 author identities, unchanged declaration-line/report/option/import sequences, and the failed theorem's full header. It maps the complete captured diagnostic headers directly from the raw log. It does not execute Lean, any mathematical program, compiler, exporter, gate, metadata preflight, old generator or saved-evidence reader. Independent review remains required.
''')

evidence_paths = [
    OLD_REL + '/SOURCE-INVENTORY.json', OLD_REL + '/SOURCE-AUDIT.json', OLD_REL + '/SOURCE-REVIEW.md',
    OLD_REL + '/INDEPENDENT-STATIC-CHECK.json', OLD_REL + '/gate/run_gate.py',
    OLD_REL + '/gate/source-manifest.json', OLD_REL + '/gate/CONTROL-CORRESPONDENCE.json',
    OLD_REL + '/gate/INDEPENDENT-CONTROL-REVIEW.md', OLD_REL + '/gate/INDEPENDENT-CONTROL-CHECK.json',
    OLD_REL + '/gate/ROOT-EXECUTION-RECEIPT.json', OLD_REL + '/gate/SNAPSHOT-RECOVERY.json',
    OLD_REL + '/gate/RESULT-AND-NEXT.md',
    OLD_REL + '/gate/execution-markers/complete-' + OLD_KEY + '.json', report_path]
for module in ('KernelCompactCore', 'KernelCachedForward', 'KernelCachedEventualInterpreter'):
    for stream in ('stdout', 'stderr'):
        evidence_paths.append(OLD_REL + f'/gate/attempts/complete-01/{module}.{stream}.log')

all_inputs = {}
def add(row):
    check_id(row)
    if row['path'] in all_inputs:
        assert all_inputs[row['path']] == row
    else:
        all_inputs[row['path']] = row

for row in old_inventory['inputs']:
    add(row)
for path in evidence_paths:
    add(ident(path))
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        add(ident(path.relative_to(ROOT).as_posix()))

logical_reports = len(token_lines(read(NEW_LOGICAL), rb'^#print axioms .*$'))
physical_reports = len(token_lines(read(NEW_PHYSICAL), rb'^#print axioms .*$'))
assert logical_reports == 32 and physical_reports == 177
inventory = {
    'format': 'adwh-eventual-iota-proof-repair-source-inventory-v1',
    'author': '/root/nat_only_gap_review',
    'status': 'frozen_source_only_uncompiled_pending_independent_review',
    'input_count': len(all_inputs), 'inputs': [all_inputs[p] for p in sorted(all_inputs)],
    'logical_source': ident(NEW_LOGICAL), 'physical_source': ident(NEW_PHYSICAL),
    'logical_correction_map': proof_map, 'physical_assembly_lineage': lineage,
    'diagnostic_map': diagnostic_map, 'primary_source_context': primary,
    'historical_review_scopes': history, 'prospective_source_census': current,
    'selected_physical_sources': selection['selected_physical_sources'],
    'source_bytes': selection['source_bytes'], 'physical_owner_count': 3,
    'report_count': 185, 'ordered_report_counts': [2, 6, 177],
    'ordered_reports': old_inventory['ordered_reports'], 'ordinary_output_count': 6,
    'logical_report_count': logical_reports, 'physical_proof_report_count': physical_reports,
    'one_logical_and_one_physical_proof_span_only': True,
    'logical_and_physical_unchanged_complements_each': 2,
    'five_input_assembly_import_edits': 8, 'five_input_assembly_complements': 13,
    'unchanged_logical_origins': 4, 'selected_changed_logical_origin': 'KernelCachedOperationalContracts',
    'unchanged_runtime_owners': ['KernelCompactCore', 'KernelCachedForward'],
    'all_public_headers_premises_runtime_definitions_guards_states_budgets_and_roots_unchanged': True,
    'namespace_import_private_global_option_and_simp_environment_unchanged': True,
    'historical_scopes_rebased': False, 'consumed_source_key': OLD_KEY,
    'new_source_or_gate_executed_or_accepted': False, 'gate_authored': False,
    'compiler_preflight_exporter_profiler_mathematical_generator_or_saved_reader_executed': False,
    'whole_query_installed_record_GroupChecked_or_numeral_claim': False,
    'independent_review_or_budget_fit_claim': False}
dump('SOURCE-INVENTORY.json', inventory)
for path in [NEW_LOGICAL, NEW_PHYSICAL, REL + '/PROOF-CORRECTION.json',
             REL + '/ASSEMBLY-LINEAGE.json', REL + '/CAPTURED-DIAGNOSTICS.json', REL + '/SOURCE-INVENTORY.json']:
    print(json.dumps(ident(path)))
print(json.dumps({'author_inputs': len(all_inputs), 'reports': 185,
                  'source_bytes': selection['source_bytes'], 'captured_diagnostic_headers': 13,
                  'new_mathematical_or_gate_execution': False}))
