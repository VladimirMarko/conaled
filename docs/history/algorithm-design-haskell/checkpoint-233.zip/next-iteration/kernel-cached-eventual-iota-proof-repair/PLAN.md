# Diagnosed eventual iota proof repair

This is a separate source-only candidate after the sole Interpreter185 attempt failed. That complete attempt took 27.61938600800204 seconds and accepted only the two Core and six Cached reports. All 185 report names were observed, but the combined interpreter owner failed and none of its 177 reports is accepted. The consumed source, controls, report, marker and snapshot recovery remain unchanged.

## Exact mathematical correction

The failed final proof remains underneath the test `RecRuleFire.plain = RecRuleFire.inert`. The existing restricted simplification does not prove that constructor inequality. In that unreduced StateT branch it also does not expose the empty-level comparison and the six pointwise helper/certificate equations. Its final reflexivity fails, and the strict linter reports twelve unused simplification arguments in this same scope.

The new proof first proves that the two constructors differ and rewrites only that actual guard. It then definitionally unfolds the concrete empty lists, the plain rule's parameter-blind comparison, verified certificate switches, the StateT/Except plumbing, and the Boolean conditional definitions. These are the existing definitions, not new equations or assumed behavior. The saved recursor-type, telescope, constructor-type, constructor-telescope, index and RHS runs are then rewritten in their actual order, with explicit Except.bind reduction between them. The final `all_goals rfl` is safe whether the final rewrite already closes the goal or leaves a reflexive constructor equation.

Only the old six-line final proof block is replaced. The complete theorem header, all lookup/arity/metadata/license premises, all executable definitions and branches, every returned state, the local/fuel bounds, all 185 report roots, imports, global options and attributes remain unchanged. The only new fact is local constructor discrimination. No success or numerical-answer premise is added.

## Physical and historical ownership

`logical-source/KernelCachedOperationalContracts.lean` is a new alternate logical owner; it must replace, never accompany, the frozen old canonical owner. `source/KernelCachedEventualInterpreter.lean` is a separate new physical assembly owner. It is reconstructed from the same five logical inputs and original eight import comments; only the selected OperationalContracts proof block differs. The other four logical files, both runtime owners, all original boundary comments and the lexical/import/private/simp environments remain literal. The old combined owner must not be imported alongside the new one.

The two one-span overlays have complete forward/inverse reconstruction and two unchanged complements each. `ASSEMBLY-LINEAGE.json` records the five-input reconstruction, all eight import edits and thirteen complements without rebasing the original 1305/1306 assembly scope, 1051/1052 trace scope, 1264/1267 bridge scope or inherited Foundation scopes. All half-open byte fields use an explicit `end_byte_exclusive` spelling; empty spans retain the original insertion-line convention.

## Evidence and limits

`CAPTURED-DIAGNOSTICS.json` retains all thirteen complete error spans in the actual captured stdout, their physical/logical source lines, and exact identities of the report and root receipt. The author read and mapped the raw text but did not execute or parse the mathematical report with a saved-result reader. The error-recovery `sorryAx` reports are rejected evidence, not author admissions or accepted theorems.

This package is uncompiled and awaits an independent full proof/source review. It authors no gate. A later selected gate must freshly compile the entire three-owner, 185-report closure under the unchanged cumulative 30-second, one-CPU, one-GiB/default-options policy, with no prepared object reuse. The failed attempt's timing establishes no fit guarantee for this candidate. The concrete FN construction, actual installed guards, original record/GroupChecked bridge and stock numeral remain separate obligations.
