# Bounded author source review

The author read the full failed iota theorem, complete actual iotaRecI definition, rule-fire/parameter decisions, empty level comparison, verified certificate gate and six pointwise run premises. The sequential state flow is unchanged: afterMajor → afterRecursorType → afterConstructorType → afterRhs, with the existing telescope/index certificates preserving the intermediate state.

The new block uses constructor discrimination for the actual inert-rule guard, then explicit definitional setup reduction and six ordered premise rewrites. No theorem header, dynamic guard, evaluator operation, exception path or certificate license is changed. The source remains uncompiled; elaboration and complete fresh acceptance are not claimed.

New literal bookkeeping reconstructs both proof overlays in both directions, all five physical input segments, eight original import changes and all complements. It verifies all old 1305 author identities, unchanged declaration-line/report/option/import sequences, and the failed theorem's full header. It maps the complete captured diagnostic headers directly from the raw log. It does not execute Lean, any mathematical program, compiler, exporter, gate, metadata preflight, old generator or saved-evidence reader. Independent review remains required.
