"""Root source/metadata review; no Lean, gate, helper, or mathematical execution."""
from pathlib import Path
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def binding(p):
    b=p.read_bytes();return {'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)}
cache={}
def check(r):
    p=ROOT/r['path'];assert p.is_file() and not p.is_symlink(),r['path']
    if p not in cache:cache[p]=p.read_bytes()
    b=cache[p];assert (len(b),sha(b))==(r['bytes'],r['sha256']),r['path'];return b
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def span(b,r):
    a,z=r['start_byte'],r['end_byte_exclusive'];assert 0<=a<=z<=len(b)
    v=b[a:z];assert (len(v),sha(v))==(r['bytes'],r['sha256'])
    first=b[:a].count(b'\n')+1
    last=max(first,b[:z].count(b'\n')+(0 if z and b[z-1:z]==b'\n' else 1))
    assert (first,last)==(r['first_line'],r['last_line_inclusive'])
    return v
def code_only(s):
    out=[];i=0;depth=0;quoted=False
    while i<len(s):
        if depth:
            if s.startswith('/-',i):depth+=1;out.extend('  ');i+=2
            elif s.startswith('-/',i):depth-=1;out.extend('  ');i+=2
            else:out.append('\n' if s[i]=='\n' else ' ');i+=1
        elif quoted:
            if s[i]=='\\' and i+1<len(s):out.extend('  ');i+=2
            elif s[i]=='"':quoted=False;out.append(' ');i+=1
            else:out.append('\n' if s[i]=='\n' else ' ');i+=1
        elif s.startswith('/-',i):depth=1;out.extend('  ');i+=2
        elif s.startswith('--',i):
            end=s.find('\n',i);end=len(s) if end<0 else end;out.extend(' '*(end-i));i=end
        elif s[i]=='"':quoted=True;out.append(' ');i+=1
        else:out.append(s[i]);i+=1
    assert depth==0 and not quoted
    return ''.join(out)
def census(b):
    code=code_only(b.decode());stack=[];roots=[];decls=[]
    for i,line in enumerate(code.splitlines(),1):
        line=line.strip()
        ns=re.fullmatch(r'namespace\s+(\S+)',line)
        sec=re.fullmatch(r'section(?:\s+(\S+))?',line)
        close=re.fullmatch(r'end(?:\s+(\S+))?',line)
        if ns:stack.append(('namespace',ns[1]))
        elif sec:stack.append(('section',sec[1]))
        elif line=='mutual':stack.append(('mutual',None))
        elif close:
            assert stack
            kind,name=stack.pop();assert close[1] is None or close[1]==name
        namespace='.'.join(n for kind,n in stack if kind=='namespace')
        printed=re.fullmatch(r'#print axioms\s+(\S+)',line)
        if printed:
            n=printed[1];roots.append(n.removeprefix('_root_.') if n.startswith(('ADWH.','ConLeche.','_root_.')) else namespace+'.'+n)
        d=re.match(r'(private\s+)?(?:noncomputable\s+)?(def|abbrev|theorem|structure|inductive)\s+(\S+)',line)
        if d:decls.append({'name':d[3].removeprefix('_root_.') if d[3].startswith('_root_.') else namespace+'.'+d[3],'kind':d[2],'private':bool(d[1]),'line':i})
    assert not stack
    return re.findall(r'^import\s+(\S+)\s*$',code,re.M),roots,decls,code

inventory_path=HERE/'SOURCE-INVENTORY.json';inventory_binding=binding(inventory_path)
assert (inventory_binding['bytes'],inventory_binding['sha256'])==(310804,'35815a003b7b603dd382a9551778cc1f97872d847c926c2985a929d28faca5e4')
author=read(inventory_path);assert len(author['inputs'])==author['input_count']==1342
assert len({r['path'] for r in author['inputs']})==1342
for r in author['inputs']:check(r)
correction=read(HERE/'PROOF-CORRECTION.json');changed=[]
for name in ('logical','physical'):
    row=correction[name];old,new=check(row['original']),check(row['candidate'])
    assert row['edit_count']==len(row['edits'])==1 and row['unchanged_complement_count']==len(row['unchanged_complements'])==2
    e=row['edits'][0];before,after=span(old,e['original']),span(new,e['candidate'])
    assert before==e['before'].encode() and after==e['after'].encode()
    a,z=e['original']['start_byte'],e['original']['end_byte_exclusive'];x,y=e['candidate']['start_byte'],e['candidate']['end_byte_exclusive']
    assert old[:a]+after+old[z:]==new and new[:x]+before+new[y:]==old and a==x
    c0,c1=row['unchanged_complements']
    assert (c0['original']['start_byte'],c0['original']['end_byte_exclusive'])==(0,a)
    assert (c0['candidate']['start_byte'],c0['candidate']['end_byte_exclusive'])==(0,x)
    assert (c1['original']['start_byte'],c1['original']['end_byte_exclusive'])==(z,len(old))
    assert (c1['candidate']['start_byte'],c1['candidate']['end_byte_exclusive'])==(y,len(new))
    for c in (c0,c1):assert span(old,c['original'])==span(new,c['candidate'])
    oldcode,newcode=code_only(old.decode()),code_only(new.decode())
    headers=lambda s:re.findall(r'(?ms)^(?:private )?theorem\s+.*?\s*:=',s)
    commands=lambda s:re.findall(r'(?m)^(?:namespace |end |section|mutual|set_option |open |universe |import |#print axioms |attribute |instance ).*$',s)
    assert headers(oldcode)==headers(newcode) and commands(oldcode)==commands(newcode)
    assert not re.search(r'\b(sorry|admit|native_decide|unsafe|partial|axiom)\b',code_only(after.decode()))
    changed.append((before,after))
assert changed[0]==changed[1]
logical_old=check(correction['logical']['original']);physical_old=check(correction['physical']['original'])
assert span(logical_old,correction['theorem_header']['logical_original'])==span(physical_old,correction['theorem_header']['physical_original'])==correction['theorem_header']['literal_text'].encode()
lineage=read(HERE/'ASSEMBLY-LINEAGE.json');physical=check(lineage['candidate'])
assert physical==check(correction['physical']['candidate'])
check(lineage['original_assembly_map']);check(lineage['original_physical_source']);check(lineage['proof_overlay'])
reconstructed=bytearray(span(physical,lineage['header_span']));assert bytes(reconstructed)==lineage['header_literal'].encode()
assert len(lineage['origins'])==5
edit_count=comp_count=changed_inputs=0
for i,row in enumerate(lineage['origins'],1):
    assert row['order']==i
    source=check(row['source']);historical=check(row['historical_original_source'])
    if row['logical_proof_overlay_selected']:
        assert source==check(correction['logical']['candidate']) and historical==logical_old;changed_inputs+=1
    else:assert source==historical
    banner=row['banner'];assert len(reconstructed)==banner['physical_start_byte'];reconstructed.extend(banner['literal'].encode());assert len(reconstructed)==banner['physical_end_byte_exclusive']
    bodyrow=row['body'];start=bodyrow['physical_start_byte'];end=bodyrow['physical_end_byte_exclusive']
    body=physical[start:end];assert start==len(reconstructed) and (len(body),sha(body))==(bodyrow['bytes'],bodyrow['sha256'])
    edited=source;inverse=body
    for e in reversed(row['edits']):
        before,after=span(source,e['original']),span(body,e['transformed'])
        assert before==e['before'].encode() and after==e['after'].encode()
        assert after==b'-- [assembly import internalized] '+before
        a,z=e['original']['start_byte'],e['original']['end_byte_exclusive'];x,y=e['transformed']['start_byte'],e['transformed']['end_byte_exclusive']
        assert (e['physical_start_byte'],e['physical_end_byte_exclusive'])==(start+x,start+y)
        edited=edited[:a]+after+edited[z:];inverse=inverse[:x]+before+inverse[y:]
    assert edited==body and inverse==source
    assert len(row['unchanged_complements'])==len(row['edits'])+1
    pos=other=0
    for j,c in enumerate(row['unchanged_complements']):
        assert (pos,other)==(c['original']['start_byte'],c['transformed']['start_byte'])
        assert span(source,c['original'])==span(body,c['transformed'])
        assert (c['physical_start_byte'],c['physical_end_byte_exclusive'])==(start+c['transformed']['start_byte'],start+c['transformed']['end_byte_exclusive'])
        pos,other=c['original']['end_byte_exclusive'],c['transformed']['end_byte_exclusive']
        if j<len(row['edits']):
            e=row['edits'][j];assert (pos,other)==(e['original']['start_byte'],e['transformed']['start_byte'])
            pos,other=e['original']['end_byte_exclusive'],e['transformed']['end_byte_exclusive']
    assert (pos,other)==(len(source),len(body))
    reconstructed.extend(body);footer=row['footer'];assert len(reconstructed)==footer['physical_start_byte'];reconstructed.extend(footer['literal'].encode());assert len(reconstructed)==footer['physical_end_byte_exclusive']
    edit_count+=len(row['edits']);comp_count+=len(row['unchanged_complements'])
assert bytes(reconstructed)==physical and (changed_inputs,edit_count,comp_count)==(1,8,13)
primary=read(HERE/'PRIMARY-SOURCE-CONTEXT.json');assert primary['interval_count']==len(primary['intervals'])==23 and len(primary['SDK_full_copies'])==6
for row in primary['SDK_full_copies']:
    retained=check(row['copy']);sdk=ROOT.parent/'toolchains/lean-4.35.0-linux/src/lean'/row['sdk_relative_path'];assert sdk.read_bytes()==retained
for row in primary['intervals']:assert span(check(row['source']),row['span'])==row['literal_text'].encode()
diag=read(HERE/'CAPTURED-DIAGNOSTICS.json');raw=check(diag['raw_stdout'])
for key in ('report_identity_only','root_execution_receipt','root_result_note'):check(diag[key])
errors=list(re.finditer(rb'(?m)^KernelCachedEventualInterpreter\.lean:(\d+):(\d+): error:',raw))
assert len(errors)==len(diag['diagnostics'])==diag['complete_captured_error_headers']==13
for i,(r,m) in enumerate(zip(diag['diagnostics'],errors)):
    piece=span(raw,r['log_span']);assert piece==r['captured_text'].encode() and r['log_span']['start_byte']==m.start()
    if i+1<len(errors):assert r['log_span']['end_byte_exclusive']==errors[i+1].start()
    else:
        next_report=re.search(rb"(?m)^'ADWH\.",raw[m.start():]);assert next_report
        assert r['log_span']['end_byte_exclusive']==m.start()+next_report.start()
assert diag['failed_terminal_proof_headers']==1 and diag['unused_simp_argument_headers']==12
history=read(HERE/'HISTORICAL-REVIEW-SCOPES.json');scope_counts=[]
for row in history['immediate_scopes']:
    inv=json.loads(check(row['inventory']));audit=json.loads(check(row['audit']));check(row['review'])
    assert len(inv['inputs'])==row['author_count'] and len(audit['inputs'])==row['review_count']
    scope_counts.append([row['author_count'],row['review_count']])
assert sorted(scope_counts)==sorted([[1051,1052],[1264,1267],[1305,1306]])
census_doc=read(HERE/'PROSPECTIVE-SOURCE-CENSUS.json');roots=[];seen=set();total=0
for row in census_doc['physical_modules']:
    b=check(row['source']);imports,reported,decls,code=census(b)
    assert imports==row['imports'] and reported==row['ordered_reports'] and len(reported)==row['report_count']
    assert all(n in seen or n=='Init' or n.startswith(('Init.','Std.')) for n in imports)
    seen.add(row['module']);roots.extend(reported);total+=len(b)
assert len(seen)==3 and total==618509 and len(roots)==len(set(roots))==185 and roots==author['ordered_reports']==census_doc['ordered_reports']
assert len(census(check(author['logical_source']))[1])==32 and len(census(physical)[1])==177
inputs=list(author['inputs'])+[inventory_binding];assert len(inputs)==1343 and len({r['path'] for r in inputs})==1343
result={'status':'passed_independent_static_source_review','author_input_count':1342,'direct_input_count':1343,'logical_and_physical_edits_each':1,'logical_and_physical_complements_each':2,'exact_full_forward_inverse_partitions':True,'shared_literal_replacement':True,'header_runtime_options_imports_namespaces_reports_unchanged':True,'physical_inputs':5,'changed_logical_inputs':1,'original_internalized_imports':8,'assembly_complements':13,'complete_assembly_reconstructed':True,'primary_intervals':23,'complete_SDK_pairs':6,'actual_error_spans':13,'separate_scope_counts':scope_counts,'fresh_owner_count':3,'fresh_source_bytes':618509,'report_count':185,'ordinary_outputs':6,'gate_preflight_compiler_or_mathematical_execution':False}
(HERE/'INDEPENDENT-STATIC-CHECK.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
audit={'format':'adwh-eventual-iota-proof-independent-source-audit-v1','status':'passed_independent_diagnosed_source_review_uncompiled','reviewer':'/root','author':'/root/nat_only_gap_review','author_inventory':inventory_binding,'direct_input_count':len(inputs),'inputs':inputs,'logical_source':author['logical_source'],'physical_source':author['physical_source'],'checks':result,'old_source_or_author_metadata_modified':False,'historical_source_or_review_scope_rebased':False,'current_185_roots_accepted_or_fit_claimed':False,'new_gate_preflight_compiler_or_mathematical_execution':False,'known_new_mathematical_source_blocker':None}
(HERE/'SOURCE-AUDIT.json').write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True,indent=2))
