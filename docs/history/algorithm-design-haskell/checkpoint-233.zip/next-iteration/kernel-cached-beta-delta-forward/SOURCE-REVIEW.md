# Independent source review: actual cached beta, delta and spine forwarding

Status: **passed source-only review; BetaDelta23 is uncompiled**.

Reviewer: book_scope_review. Source author: reflection_evidence_review. The complete 27,161-byte source, all 23 public theorem proofs, four definitions and one inductive proposition were read against the actual selected implementation and its established helper/memo interfaces. All 220 author-inventory identities and all 24 literal primary intervals match their recorded bytes and hashes. The separate audit binds 29 direct source/context inputs. No source, author inventory or historical review was changed.

## Scope and current evidence

The source SHA-256 is ffaab83ea1d35f689768bc1c844aca26378f5227a1ed5dac71fc36ea369a39f8. It imports only KernelCachedHelperDirect and has precisely three strict source options. There are exactly 23 ordered print-axiom commands, matching the 23 public theorem declarations. No executable reducer, resource constant, existing definition, new axiom, admission or evaluation command is added or replaced.

Its exact source-only dependency inventory selects the presentation Core, shared Cached owner, corrected Stable, repaired Helper and this new leaf: five physical modules, 94 reports, ten ordinary objects, and 619,802 source bytes. The presentation and sharing overlays keep their distinct reviews and historical source identities. This review does not silently re-review or rebase the entire source provenance of those owners.

After the author inventory froze, root consumed the separate cost120 gate. That attempt failed at the common wall deadline after 30.265804238999408 seconds. Its first four modules accepted 71 reports; Syntax returned no report and Bulk/Literal were not reached. The new report and permanent marker are separate context inputs to this review. BetaDelta was not selected in that attempt and has no compiled acceptance. The result supplies no budget-fit claim for a larger or smaller future graph and permits no unchanged retry of the consumed cost120 selection.

## Actual state proposition and memo discipline

Forward quantifies over the actual supplied CState. It requires both StableNF for the stated pure environment and HelperCache for the stated FEnv, then returns the actual action equation and both invariants at its returned state. These invariants are deliberately distinct. The definition does not manufacture an empty state, assert an environment relation, or implement a substitute evaluator.

Each final cached theorem invokes the actual positive-fuel head/full memo adapter from the corrected Stable leaf. A cache hit is identified using eventual pure backing and actual query scoping. A miss executes the concrete body proof and then inserts the result into the real NF map. The auxiliary MemoFrame is the existing helper_cache_memo_frame, so the helper invariant survives that actual insertion. StableHead/StableWhnf backing remains an explicit premise where the new source has not proved it. There is no inversion of a successful-cached-to-pure simulation and no global fuel-monotonicity assumption.

HeadAtom lists exactly the six terminal branches of the actual pure and cached head steps: sort, fvar, forall, lambda, constant and literal. These branches return their input without a callback or body-state change. The pure positive-fuel proof supplies stable head backing; cached_head_atom handles actual hit/miss behavior. A memo miss may change the NF map, so this is not a claim that the whole cached knot preserves the complete state.

get_app_fn_scoped follows the actual Expr.wscopedB application conjunction and Expr.getAppFn recursion. It derives the raw spine head's free-variable scoping from the query's scoping. It does not establish typing, bound-variable closure or annotation validity.

## Application spine and local head step

whnf_app_done follows the actual empty argument-list clause. whnf_app_skip retains both the real nonlambda test and the false iotaArityOk condition; it neither calls the continuation nor assumes an iota result. whnf_app_iota_of_runs threads the exact supplied states in order: iota returns afterIota, next returns afterNext, and the remaining spine starts at afterNext. Its assumptions are the actual equations for those three component runs. It does not claim their invariant preservation by itself.

head_loop_app_of_runs exposes one positive whnfCoreLoopI iteration. The real callback normalizes the input's getAppFn, then whnfAppI receives the actual getAppArgsC list and that callback's returned state. The continuation is the same original head loop with the predecessor local budget. The knot callback and local-loop budgets are not conflated.

## Licensed beta and actual substitution

NeverBetaPeels is an inductive relation over the real raw expression, accumulator and remaining argument list. Each step demands a lambda with literal never metadata, pushes the next actual argument onto the innermost-first accumulator, and continues on the raw body. Its done constructor applies only when no arguments remain. This is an explicit syntactic license; it is not a theorem that installation checked those metadata.

beta_peel_never_equation composes the already accepted actual betaPeelI_never/done equations. beta_peel_forward then proves the actual instListM result using HelperCache, obtains the exact Expr.instantiateListC residual values 0 output and helper-returned state, transports StableNF through the proven NF-map frame, and invokes the supplied continuation at that returned state. It does not assume helper success or substitute the separate pure instantiateList operation.

The application and positive head-loop beta theorems compose those actual steps with the real normalized lambda-head callback and actual argument-list equations. cached_head_beta discharges that lambda-head call via cached_head_atom, derives its scope from the query, proves the concrete head-miss body, and lifts it through the actual head memo.

The outer cached head knot is fuel + 2, its callbacks are at fuel + 1, and the reduct continuation uses the original head-loop budget 999999 after one iteration of 1000000. These values are exactly the existing constants and their predecessors. The remaining nextSuccess premise is the actual reduct continuation under that smaller local budget. The arbitrary current miss-body result is not a premise. Whole-query induction and the pure stable backing must still establish the remaining recursive obligations.

This beta interface intentionally covers a complete supplied argument list aligned with a raw licensed lambda prefix. It does not cover an unlicensed binder requiring inferIO/defeq, or the betaPeel fallback that encounters a nonlambda while arguments remain. The plan explicitly leaves these cases separate if the concrete query needs them.

## Delta, native guards and returned states

NatBypass exactly mirrors the possible reduceNatI entry branches. The unary shape negates successor plus Nat literal support. The binary shape negates the exact fourteen-operation disjunction plus natOpStoredF, and separately negates the later unsupported-operation guard. Nonempty level lists and other shapes follow the actual immediate-none branches. The second binary condition matters: ignoring it could reach the original notImplemented failure instead of delta.

reduce_nat_bypass proves the actual state-preserving none result from those syntactic guard facts. It does not assume the reducer's success equation as a premise and does not equate a nonliteral operand with bypassing the branch. definition_head_no_iota correctly excludes the recursor-only guard using the actual .defnInfo lookup.

unfold_definition_of_run follows the exact getAppFn constant, indexed record, level-arity test, constValAtM fe name name levels and pure mkAppNM sequence. deltaReduct is precisely the actual Expr.instLevelParams result applied to Expr.getAppArgsC, not a tree-substitution approximation. unfold_definition_forward discharges the constVal helper with the existing actual-result theorem and retains its returned state and both invariants.

The prefix corollary composes an explicit PrefixLookup equality with the visible prefix's record lookup. It never substitutes fe.env for that prefix and does not infer canonical indexing, uniqueness or EnvWF. Invariant initialization and cache validity after restricting visibility remain separate obligations.

full_loop_delta_of_runs expands one original full-loop iteration: actual head callback, state-preserving native-Nat decline, actual delta helper, and reduct continuation, each at the preceding operation's returned state. The invariant-level theorem obtains all three actual run witnesses in that same order.

cached_full_delta lifts this concrete body through both branches of the actual full memo. Its outer fuel is fuel + 1; the body callbacks use fuel; the remaining local full-loop budget is 99999 after one step of 100000. The constant instance discharges the head-call premise through cached_head_atom and uses outer fuel + 2. Query scope is explicit in the generic case and immediate for the constant instance. No expected count or current full-miss-body equation is assumed.

## Verdict and limits

No blocking semantic or source-correspondence issue was found. The proofs use real success equations, state threading, guards, memo operations and local budgets, with the remaining recursive run and stable-backing premises stated explicitly. The actual cached syntax outputs remain in the statements; their separate pure correspondence is not assumed implicitly.

This is not elaboration, strict-warning, axiom-report or fixed-budget acceptance. Those checks remain root-only future work. No gate, compiler, preflight, retained generator, exporter, evaluator, profiler or saved-evidence reader was executed during this review. Only source/metadata/log reads, literal interval comparisons and hashes were used. Actual installed annotations, true-prefix EnvWF, complete record processing, original GroupChecked and the stock numeral theorem are not established here.
