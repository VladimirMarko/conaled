# Actual cached beta, delta and spine transitions

## Status and purpose

This new source-only leaf is separate from the frozen complete120 selection, the presentation/Syntax cost overlays, Arithmetic17 and NatIota8. It has 23 public theorem/report roots, four small definitions and one inductive proposition. No Lean/compiler, preflight, gate, exporter, native evaluator or mathematical program was run while authoring it. No proof acceptance, timing benefit or budget fit is asserted.

The direct import is only `KernelCachedHelperDirect`. The candidate uses the actual-result helper interfaces. It does not import Syntax, BulkBound, Literal, Arithmetic, the pure Nat reference or a second Core owner. The separately reviewed pure syntax equalities remain available as later adapters, with their distinct complete compilation obligation.

## Actual-state interface

`Forward mode environment fe action value` means the real `CheckCM Expr` action succeeds from every supplied state satisfying `StableNF mode environment` and `HelperCache fe`, and returns both invariants at its actual final state. It is a proposition about the original action. It does not define another evaluator or manufacture an empty state.

The two invariants are kept distinct. `StableNF` backs the two actual normal-form memo maps by eventual pure runs; `HelperCache` checks the exact persistent bulk/value/type/rule keys and converted-entry tags. The final knot adapters use the already proved `helper_cache_memo_frame` for the actual NF memo insertion. Helper steps transfer `StableNF` through their real two-map frames while allowing their own caches to change.

## Application-spine and local-loop interfaces

`whnf_app_done` proves the actual empty-spine result. `whnf_app_skip` handles an explicitly nonlambda head when the real `iotaArityOk` guard is false. `whnf_app_iota_of_runs` consumes the successful actual iota equation at the supplied state, calls the real continuation on the reduct at iota's returned state, then handles the remaining arguments at the continuation's returned state. The NatIota8 leaf can supply the iota equation and its invariant facts; no Nat-specific record or rule logic is duplicated here.

`head_loop_app_of_runs` exposes exactly one positive original head-loop iteration. Its real head callback receives the input's actual `getAppFn`; the spine receives the actual cached argument list; its continuation is the same original head loop at the predecessor local budget. This equation does not itself assert invariant preservation or a successful continuation.

`HeadAtom` identifies the six actual terminal head constructors. Its pure and cached head lemmas include both actual memo branches, with scoping explicit at memo use. The generic `get_app_fn_scoped` theorem derives head scoping from actual query scoping.

## Beta rule and fuel

`NeverBetaPeels` records the actual raw lambda telescope, explicit `.never` metadata and the real innermost-first argument accumulator. The final `done` case is allowed only when all supplied arguments have been consumed. Each `step` adds the actual argument to the accumulator; no binder check or annotation fact is silently dropped. Installation and validation of those metadata values are separate obligations.

The peel equation follows the existing original `betaPeelI_never` and `betaPeelI_done` equations. The higher forward theorem proves the actual `instListM` run from `HelperCache`, obtains its actual `Expr.instantiateListC residual values 0` result, and calls the real continuation from the returned helper state. It does not assume that helper succeeds. The application and head-loop wrappers compose those runs with the original lambda-head callback.

`cached_head_beta` proves the actual non-cheap head knot at `fuel + 2`. The body callbacks are `coreKnotI .verified fe (fuel + 1)`. The actual lambda-head memo call is proved by the terminal-head interface. One original local head-loop step is consumed, so the reduct continuation remains at **999999**, the predecessor of the unchanged **1000000** head-loop budget. The final theorem assumes an actual forward run only for that smaller local continuation, plus the independent pure stable backing and query scope needed by the outer memo. It has no current head-miss-body success premise.

This beta interface covers a complete supplied argument list matching an explicitly licensed raw lambda prefix. It does not yet cover the `betaPeelI` fallback that encounters a nonlambda residual while additional arguments remain, or the unlicensed branch that calls inference/defeq. Those cases must be proved separately if the concrete query requires them.

## Delta rule and fuel

`NatBypass` is a syntactic guard predicate, not an assumed equation about reducer success. It mirrors every actual native-Nat entry condition: unary successor, the exact fourteen-name binary disjunction with stored-definition guard, and the later unsupported-operation guard. Expressions with nonempty constant level arguments or another shape use the original immediate-none branches. `reduce_nat_bypass` proves that those explicit guard facts make the real native-Nat probe return none without changing state. It does not claim that a recognized operation with nonliteral operands bypasses that probe.

`deltaReduct` is the actual definition body's `Expr.instLevelParams` result applied with the actual cached argument list. The actual `unfoldDefinitionI` proof uses an explicit `fe.find? name = some (.defnInfo constant body hint)` witness and exact level arity. `unfold_definition_forward` discharges the actual `constValAtM fe name name levels` call using the helper invariant, then follows the original pure `mkAppNM`. The optional visible-prefix form requires `PrefixLookup fe visiblePrefix`; it never substitutes `fe.env` for the true prefix.

The full-loop delta theorem threads the actual head callback state, helper state and reduct continuation state in that order. `cached_full_delta` uses the original outer knot at `fuel + 1`, actual body callbacks at `fuel`, and the remaining local full-loop budget **99999**, the predecessor of the unchanged **100000** budget. The constant instance discharges its head-call premise using the actual positive head memo; its outer knot is `fuel + 2`. Every final NF insertion has explicit pure stable backing and scope, and preserves the real helper invariant through its proven MemoFrame.

The final delta result has no expected-numeral or current-miss-body-success premise. Its unresolved operational premises concern only the actual smaller head callback and the actual reduct continuation at the stated budgets. Whole-query induction must establish them.

## Coherent prospective selection

The inventory binds the consumed historical complete120 scope and its preserved failure context, plus the separately reviewed presentation-only Core slice. The prospective operational closure is five physical modules: presentation Core, shared Cached owner, corrected Stable, repaired Helper and this new leaf. It has **94 ordered/distinct required reports**: 1 + 25 + 20 + 25 + 23, and ten normal `.olean`/`.ilean` artifacts. This is an inventory, not a gate authorization or resource result.

A later combined source selection may add the independently reviewed NatIota8, Arithmetic17 and pure syntax bridges, but must state that exact full closure and compile every actual selected source afresh in the existing single cumulative30-second, one-CPU/thread, 1GiB strict-default gate. Prior accepted objects cannot be prepared inputs. No unchanged rerun, split compile interval or resource override is part of this work.

## Outstanding complete-query work

The reusable transitions need concrete source/export recognition, actual indexed prefix and annotation pin adapters, pure syntax correspondence, actual recursive operand/major/reduct runs and their finite local/knot bounds. The two NF-map backing and helper invariants must be initialized on the actual supplied state and preserved through real record processing. The original `GroupChecked` integration and full cqueens16 success remain unproved by this leaf.
