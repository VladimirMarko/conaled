import KernelCachedHelperDirect

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual cached beta, delta and application-spine forwarding

Source candidate only. All runs start from the supplied state and use the
original cached functions. The beta rule reads explicit `.never` metadata,
performs the actual memoized bulk substitution, and resumes the original
local loop from the helper's returned state. Delta uses the actual indexed
definition lookup, level-arity test and constant-value helper before the
original local continuation. No current miss-body success is a premise of
the final knot lemmas.

The reducts use the actual Expr.instantiateListC and Expr.instLevelParams
outputs. Their correspondence with the pure tree operations is a separate
reviewed interface; this operational leaf imports only HelperDirect. Stable
pure backing is still an explicit premise at each top-level memo insertion.
No annotation installation, environment-prefix agreement, expected numeral,
or global fuel monotonicity is inferred from an operational run.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedStableForward
open KernelCachedHelperDirect

/-- Actual success from every supplied state satisfying the two independent
invariants. It is a proposition about the real StateT action, not an evaluator.
-/
def Forward (mode : CheckMode) (environment : Env) (fe : FEnv)
    (action : CheckCM Expr) (value : Expr) : Prop :=
  ∀ state, StableNF mode environment state → HelperCache fe state →
    ∃ final, action state = .ok (value, final) ∧
      StableNF mode environment final ∧ HelperCache fe final

/-- Exactly the terminal constructor cases of the actual head step. -/
def HeadAtom : Expr → Prop
  | .sort _ | .fvar .. | .forallE .. | .lam .. | .const .. | .lit _ => True
  | _ => False

theorem pure_head_atom (mode : CheckMode) (environment : Env)
    (fuel depth : Nat) (expression : Expr) (atom : HeadAtom expression) :
    whnfCore mode environment (fuel + 1) depth expression = .ok expression := by
  cases expression <;> try cases atom
  all_goals rfl

theorem stable_head_atom (mode : CheckMode) (environment : Env)
    (expression : Expr) (atom : HeadAtom expression) :
    StableHead mode environment expression expression := by
  refine ⟨1, ?_⟩
  intro fuel depth large _
  cases fuel with
  | zero => omega
  | succ predecessor => exact pure_head_atom mode environment predecessor depth expression atom

theorem head_body_atom (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (cheap : Bool) (depth : Nat) (expression : Expr)
    (atom : HeadAtom expression) (state : CState) :
    whnfCoreBodyI mode callbacks fe cheap depth expression state =
      .ok (expression, state) := by
  unfold whnfCoreBodyI whnfCoreLoopFuel
  cases expression <;> try cases atom
  all_goals rfl

/-- The actual head memo is handled in both branches. The auxiliary memo
frame here is the proved frame of the real helper-cache invariant. -/
theorem cached_head_atom (mode : CheckMode) (environment : Env) (fe : FEnv)
    (fuel depth : Nat) (expression : Expr) (atom : HeadAtom expression)
    (queryScoped : Expr.wscopedB depth expression = true) :
    Forward mode environment fe
      ((coreKnotI mode fe (fuel + 1)).whnfCore false depth expression) expression := by
  intro state valid helpers
  apply head_forward_of_body mode environment fe fuel depth expression expression
    (HelperCache fe) (helper_cache_memo_frame fe)
    (stable_head_atom mode environment expression atom) queryScoped state valid helpers
  intro _
  exact ⟨state, head_body_atom mode (coreKnotI mode fe fuel) fe false depth
    expression atom state, valid, helpers⟩

theorem get_app_fn_scoped : ∀ (expression : Expr) (depth : Nat),
    Expr.wscopedB depth expression = true →
      Expr.wscopedB depth (Expr.getAppFn expression) = true := by
  intro expression
  induction expression with
  | app function argument ihf _ =>
    intro depth queryScoped
    rw [Expr.wscopedB] at queryScoped
    have parts : Expr.wscopedB depth function = true ∧
        Expr.wscopedB depth argument = true := by
      exact Bool.and_eq_true.mp queryScoped
    exact ihf depth parts.1
  | _ => intro depth queryScoped; exact queryScoped

theorem whnf_app_done (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (expression : Expr) (state : CState) :
    whnfAppI mode callbacks fe depth next expression [] state =
      .ok (expression, state) := by
  rw [whnfAppI.eq_def]
  all_goals rfl

/-- One real nonlambda spine step with the actual iota pre-check false. -/
theorem whnf_app_skip (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (head argument : Expr) (rest : List Expr)
    (nonLambda : head.isLam = false)
    (noIota : iotaArityOk fe (.app head argument) = false) :
    whnfAppI mode callbacks fe depth next head (argument :: rest) =
      whnfAppI mode callbacks fe depth next (.app head argument) rest := by
  cases head with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [whnfAppI.eq_def]
    simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.bind, noIota]
    all_goals rfl

/-- The original iota branch passes the state returned by iota to `next`,
then passes that continuation's returned state to the remaining spine. -/
theorem whnf_app_iota_of_runs (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (head argument reduct normalized value : Expr) (rest : List Expr)
    (state afterIota afterNext final : CState)
    (nonLambda : head.isLam = false)
    (enabled : iotaArityOk fe (.app head argument) = true)
    (iotaRun : iotaRecI mode callbacks fe depth (.app head argument) state =
      .ok (some reduct, afterIota))
    (nextRun : next reduct afterIota = .ok (normalized, afterNext))
    (restRun : whnfAppI mode callbacks fe depth next normalized rest afterNext =
      .ok (value, final)) :
    whnfAppI mode callbacks fe depth next head (argument :: rest) state =
      .ok (value, final) := by
  cases head with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [whnfAppI.eq_def]
    simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.bind,
      enabled, iotaRun, nextRun]
    all_goals exact restRun

/-- One original positive head-loop iteration. The spine continuation uses
exactly the predecessor local budget, independently of the knot fuel. -/
theorem head_loop_app_of_runs (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (cheap : Bool) (depth budget : Nat)
    (function argument normalized value : Expr)
    (state afterHead final : CState)
    (headRun : callbacks.whnfCore cheap depth
      (Expr.getAppFn (.app function argument)) state = .ok (normalized, afterHead))
    (spineRun : whnfAppI mode callbacks fe depth
      (whnfCoreLoopI mode callbacks fe cheap depth budget) normalized
      (Expr.getAppArgsC (.app function argument)) afterHead = .ok (value, final)) :
    whnfCoreLoopI mode callbacks fe cheap depth (budget + 1)
      (.app function argument) state = .ok (value, final) := by
  change whnfCoreStepI mode callbacks fe cheap depth
    (whnfCoreLoopI mode callbacks fe cheap depth budget) (.app function argument) state = _
  simp only [whnfCoreStepI, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.bind, headRun]
  all_goals exact spineRun

/-- Exact raw binder/argument alignment for the original licensed peel.
Each constructor records the real innermost-first accumulator order. The
metadata is a syntactic premise; no installation certificate is asserted. -/
inductive NeverBetaPeels : Expr → List Expr → List Expr → Expr → List Expr → Prop
  | done (body : Expr) (accumulated : List Expr) :
      NeverBetaPeels body accumulated [] body accumulated
  | step (domain body argument : Expr) (accumulated rest : List Expr)
      (residual : Expr) (values : List Expr)
      (tail : NeverBetaPeels body (argument :: accumulated) rest residual values) :
      NeverBetaPeels (.lam domain body ⟨.never⟩) accumulated
        (argument :: rest) residual values

theorem beta_peel_never_equation (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (next : Expr → CheckCM Expr) (target residual : Expr)
    (accumulated arguments values : List Expr)
    (licensed : NeverBetaPeels target accumulated arguments residual values) :
    betaPeelI .verified callbacks fe depth next target accumulated arguments =
      (instListM residual values >>= next) := by
  induction licensed with
  | done body accumulated =>
    exact betaPeelI_done .verified callbacks fe depth next body accumulated
  | step domain body argument accumulated rest residual values _ ih =>
    rw [betaPeelI_never]
    exact ih

/-- The real bulk helper is run and proved correct, then the actual
continuation is invoked at its returned state. Its result is the cached
syntax operation's value, with all persistent memo keys and cutoff cases. -/
theorem beta_peel_forward (environment : Env) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (target residual value : Expr) (accumulated arguments values : List Expr)
    (licensed : NeverBetaPeels target accumulated arguments residual values)
    (nextSuccess : Forward .verified environment fe
      (next (Expr.instantiateListC residual values 0)) value) :
    Forward .verified environment fe
      (betaPeelI .verified callbacks fe depth next target accumulated arguments) value := by
  intro state valid helpers
  obtain ⟨afterInst, instRun, instValid, instHelpers⟩ :=
    helper_result_stable_nf fe .verified environment (instListM residual values)
      (Expr.instantiateListC residual values 0) state valid
      (instListM_correct fe residual values 0 state helpers)
  obtain ⟨final, nextRun, finalValid, finalHelpers⟩ :=
    nextSuccess afterInst instValid instHelpers
  refine ⟨final, ?_, finalValid, finalHelpers⟩
  rw [beta_peel_never_equation callbacks fe depth next target residual
    accumulated arguments values licensed]
  simp only [Bind.bind, StateT.bind, instRun, Except.bind]
  all_goals exact nextRun

theorem whnf_app_beta_forward (environment : Env) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (domain body first residual value : Expr) (rest values : List Expr)
    (licensed : NeverBetaPeels body [first] rest residual values)
    (nextSuccess : Forward .verified environment fe
      (next (Expr.instantiateListC residual values 0)) value) :
    Forward .verified environment fe
      (whnfAppI .verified callbacks fe depth next
        (.lam domain body ⟨.never⟩) (first :: rest)) value := by
  rw [whnfAppI_never]
  exact beta_peel_forward environment callbacks fe depth next body residual value
    [first] rest values licensed nextSuccess

theorem head_loop_beta_forward (environment : Env) (callbacks : CoreFnsI)
    (fe : FEnv) (depth budget : Nat) (function argument domain body first residual value : Expr)
    (rest values : List Expr)
    (head : Expr.getAppFn (.app function argument) = .lam domain body ⟨.never⟩)
    (arguments : Expr.getAppArgsC (.app function argument) = first :: rest)
    (licensed : NeverBetaPeels body [first] rest residual values)
    (headSuccess : Forward .verified environment fe
      (callbacks.whnfCore false depth (.lam domain body ⟨.never⟩))
        (.lam domain body ⟨.never⟩))
    (nextSuccess : Forward .verified environment fe
      (whnfCoreLoopI .verified callbacks fe false depth budget
        (Expr.instantiateListC residual values 0)) value) :
    Forward .verified environment fe
      (whnfCoreLoopI .verified callbacks fe false depth (budget + 1)
        (.app function argument)) value := by
  intro state valid helpers
  obtain ⟨afterHead, headRun, headValid, headHelpers⟩ :=
    headSuccess state valid helpers
  obtain ⟨final, appRun, finalValid, finalHelpers⟩ :=
    whnf_app_beta_forward environment callbacks fe depth
      (whnfCoreLoopI .verified callbacks fe false depth budget)
      domain body first residual value rest values licensed nextSuccess
      afterHead headValid headHelpers
  refine ⟨final, ?_, finalValid, finalHelpers⟩
  apply head_loop_app_of_runs .verified callbacks fe false depth budget
    function argument (.lam domain body ⟨.never⟩) value state afterHead final
  · rw [head]
    exact headRun
  · rw [arguments]
    exact appRun

/-- Actual non-cheap head-knot beta success. Both real head memo branches are
handled, and the miss body performs the normalized lambda-head call, the
licensed peel and the actual substitution. The only remaining recursive
premise concerns the reduct at the original smaller local-loop budget. -/
theorem cached_head_beta (environment : Env) (fe : FEnv) (fuel depth : Nat)
    (function argument domain body first residual value : Expr) (rest values : List Expr)
    (head : Expr.getAppFn (.app function argument) = .lam domain body ⟨.never⟩)
    (arguments : Expr.getAppArgsC (.app function argument) = first :: rest)
    (licensed : NeverBetaPeels body [first] rest residual values)
    (backing : StableHead .verified environment (.app function argument) value)
    (queryScoped : Expr.wscopedB depth (.app function argument) = true)
    (nextSuccess : Forward .verified environment fe
      (whnfCoreLoopI .verified (coreKnotI .verified fe (fuel + 1)) fe false depth 999999
        (Expr.instantiateListC residual values 0)) value) :
    Forward .verified environment fe
      ((coreKnotI .verified fe (fuel + 2)).whnfCore false depth
        (.app function argument)) value := by
  intro state valid helpers
  apply head_forward_of_body .verified environment fe (fuel + 1) depth
    (.app function argument) value (HelperCache fe) (helper_cache_memo_frame fe)
    backing queryScoped state valid helpers
  intro _
  have headScoped := get_app_fn_scoped (.app function argument) depth queryScoped
  rw [head] at headScoped
  have atom : HeadAtom (.lam domain body ⟨.never⟩) := trivial
  have headSuccess := cached_head_atom .verified environment fe fuel depth
    (.lam domain body ⟨.never⟩) atom headScoped
  change ∃ final, whnfCoreLoopI .verified (coreKnotI .verified fe (fuel + 1))
    fe false depth whnfCoreLoopFuel (.app function argument) state = .ok (value, final) ∧
      StableNF .verified environment final ∧ HelperCache fe final
  have budget : whnfCoreLoopFuel = 999999 + 1 := by
    unfold whnfCoreLoopFuel
    rfl
  rw [budget]
  exact head_loop_beta_forward environment (coreKnotI .verified fe (fuel + 1))
    fe depth 999999 function argument domain body first residual value rest values
    head arguments licensed headSuccess nextSuccess state valid helpers

/-- An actual definition cannot pass the recursor-only iota pre-check. -/
theorem definition_head_no_iota (fe : FEnv) (expression : Expr)
    (name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint)
    (head : Expr.getAppFn expression = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    iotaArityOk fe expression = false := by
  unfold iotaArityOk
  rw [head, found]

/-- Syntactic conditions for bypassing every actual native-Nat guard. The
binary condition includes the later unsupported-operation guard, so a
nonrecognized definition is not silently treated as a successful decline. -/
def NatBypass (fe : FEnv) : Expr → Prop
  | .app (.const name []) _ =>
      ¬ (name = natSuccName ∧ natLitSupportedF fe = true)
  | .app (.app (.const name []) _) _ =>
      ¬ ((name = natAddName ∨ name = natSubName ∨ name = natMulName ∨
        name = natPowName ∨ name = natBeqName ∨ name = natBleName ∨
        name = natDivName ∨ name = natModName ∨ name = natGcdName ∨
        name = natLandName ∨ name = natLorName ∨ name = natXorName ∨
        name = natShiftLeftName ∨ name = natShiftRightName) ∧
        natOpStoredF fe name = true) ∧
      ¬ (natOpWfNames.contains name = true ∧ natLitSupportedF fe = true)
  | _ => True

theorem reduce_nat_bypass (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (expression : Expr) (bypass : NatBypass fe expression) (state : CState) :
    reduceNatI callbacks fe depth expression state = .ok (none, state) := by
  cases expression with
  | app function argument =>
    cases function with
    | const name levels =>
      cases levels with
      | nil =>
        simp only [reduceNatI, Bind.bind, StateT.bind, pure, StateT.pure,
          Except.bind, ite_eq_right bypass]
        all_goals rfl
      | cons first rest => rfl
    | app head first =>
      cases head with
      | const name levels =>
        cases levels with
        | nil =>
          simp only [reduceNatI, Bind.bind, StateT.bind, pure, StateT.pure,
            Except.bind, ite_eq_right bypass.1, ite_eq_right bypass.2]
          all_goals rfl
        | cons level rest => rfl
      | _ => rfl
    | _ => rfl
  | _ => rfl

/-- The exact cached delta reduct, before the original local continuation. -/
def deltaReduct (expression : Expr) (constant : ConstantVal)
    (body : Expr) (levels : List Level) : Expr :=
  Expr.mkAppN (Expr.instLevelParams constant.levelParams levels body)
    (Expr.getAppArgsC expression)

theorem unfold_definition_of_run (fe : FEnv) (expression : Expr)
    (name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint) (state final : CState)
    (head : Expr.getAppFn expression = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (helperRun : constValAtM fe name name levels state =
      .ok (Expr.instLevelParams constant.levelParams levels body, final)) :
    unfoldDefinitionI fe expression state =
      .ok (some (deltaReduct expression constant body levels), final) := by
  simp only [unfoldDefinitionI, head, Bind.bind, StateT.bind, pure,
    StateT.pure, Except.bind, found, ite_eq_left arity, helperRun, mkAppNM,
    deltaReduct]
  all_goals rfl

/-- The actual indexed helper is proved to return its value and preserve both
invariants; its success is not a premise of this operational delta theorem. -/
theorem unfold_definition_forward (mode : CheckMode) (environment : Env)
    (fe : FEnv) (expression : Expr) (name : Name) (levels : List Level)
    (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint)
    (head : Expr.getAppFn expression = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (state : CState) (valid : StableNF mode environment state)
    (helpers : HelperCache fe state) :
    ∃ final, unfoldDefinitionI fe expression state =
      .ok (some (deltaReduct expression constant body levels), final) ∧
      StableNF mode environment final ∧ HelperCache fe final := by
  obtain ⟨final, helperRun, finalValid, finalHelpers⟩ :=
    helper_result_stable_nf fe mode environment (constValAtM fe name name levels)
      (Expr.instLevelParams constant.levelParams levels body) state valid
      (constValAtM_correct fe name name levels constant body hint state helpers found)
  exact ⟨final, unfold_definition_of_run fe expression name levels constant body hint
    state final head found arity helperRun, finalValid, finalHelpers⟩

/-- A visible-prefix version requires actual lookup agreement. The stored
fe.env field is never silently substituted for that visible prefix. -/
theorem unfold_definition_from_prefix (mode : CheckMode) (environment : Env)
    (fe : FEnv) (visiblePrefix : Env) (agreement : PrefixLookup fe visiblePrefix)
    (expression : Expr) (name : Name) (levels : List Level)
    (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint)
    (head : Expr.getAppFn expression = .const name levels)
    (found : visiblePrefix.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (state : CState) (valid : StableNF mode environment state)
    (helpers : HelperCache fe state) :
    ∃ final, unfoldDefinitionI fe expression state =
      .ok (some (deltaReduct expression constant body levels), final) ∧
      StableNF mode environment final ∧ HelperCache fe final := by
  exact unfold_definition_forward mode environment fe expression name levels
    constant body hint head ((agreement name).trans found) arity state valid helpers

theorem full_loop_delta_of_runs (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (query head reduct value : Expr)
    (state afterHead afterDelta final : CState)
    (headRun : callbacks.whnfCore false depth query state = .ok (head, afterHead))
    (bypass : NatBypass fe head)
    (deltaRun : unfoldDefinitionI fe head afterHead = .ok (some reduct, afterDelta))
    (nextRun : whnfLoopI callbacks fe depth budget reduct afterDelta = .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 1) query state = .ok (value, final) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind,
    reduce_nat_bypass callbacks fe depth head bypass afterHead, deltaRun]
  all_goals exact nextRun

/-- One real full-loop delta iteration, with the exact head-call state,
helper-call state and smaller local-continuation state threaded in order. -/
theorem full_loop_delta_forward (mode : CheckMode) (environment : Env)
    (callbacks : CoreFnsI) (fe : FEnv) (depth budget : Nat)
    (query head value : Expr) (name : Name) (levels : List Level)
    (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint)
    (headForm : Expr.getAppFn head = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (bypass : NatBypass fe head)
    (headSuccess : Forward mode environment fe (callbacks.whnfCore false depth query) head)
    (nextSuccess : Forward mode environment fe
      (whnfLoopI callbacks fe depth budget (deltaReduct head constant body levels)) value) :
    Forward mode environment fe (whnfLoopI callbacks fe depth (budget + 1) query) value := by
  intro state valid helpers
  obtain ⟨afterHead, headRun, headValid, headHelpers⟩ := headSuccess state valid helpers
  obtain ⟨afterDelta, deltaRun, deltaValid, deltaHelpers⟩ :=
    unfold_definition_forward mode environment fe head name levels constant body hint
      headForm found arity afterHead headValid headHelpers
  obtain ⟨final, nextRun, finalValid, finalHelpers⟩ :=
    nextSuccess afterDelta deltaValid deltaHelpers
  exact ⟨final, full_loop_delta_of_runs callbacks fe depth budget query head
    (deltaReduct head constant body levels) value state afterHead afterDelta final
    headRun bypass deltaRun nextRun, finalValid, finalHelpers⟩

/-- Actual positive-fuel full memo, including cache hits. The miss body is
proved through real head normalization, syntactic Nat bypass, actual indexed
delta and the original remaining local budget 99999. Only the genuinely
recursive head and reduct-continuation runs remain as induction premises. -/
theorem cached_full_delta (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (query head value : Expr)
    (name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint)
    (headForm : Expr.getAppFn head = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (bypass : NatBypass fe head)
    (backing : StableWhnf mode environment query value)
    (queryScoped : Expr.wscopedB depth query = true)
    (headSuccess : Forward mode environment fe
      ((coreKnotI mode fe fuel).whnfCore false depth query) head)
    (nextSuccess : Forward mode environment fe
      (whnfLoopI (coreKnotI mode fe fuel) fe depth 99999
        (deltaReduct head constant body levels)) value) :
    Forward mode environment fe ((coreKnotI mode fe (fuel + 1)).whnf depth query) value := by
  intro state valid helpers
  apply whnf_forward_of_body mode environment fe fuel depth query value
    (HelperCache fe) (helper_cache_memo_frame fe) backing queryScoped state valid helpers
  intro _
  change ∃ final, whnfLoopI (coreKnotI mode fe fuel) fe depth whnfLoopFuel query state =
    .ok (value, final) ∧ StableNF mode environment final ∧ HelperCache fe final
  have budget : whnfLoopFuel = 99999 + 1 := by
    unfold whnfLoopFuel
    rfl
  rw [budget]
  exact full_loop_delta_forward mode environment (coreKnotI mode fe fuel) fe depth
    99999 query head value name levels constant body hint headForm found arity bypass
    headSuccess nextSuccess state valid helpers

/-- The constant-head instance discharges the recursive head-call premise
using the actual positive-fuel head memo. It still executes the genuine
level-instantiated definition body through the local full-loop continuation. -/
theorem cached_full_delta_const (mode : CheckMode) (environment : Env)
    (fe : FEnv) (fuel depth : Nat) (name : Name) (levels : List Level)
    (constant : ConstantVal) (body value : Expr) (hint : ReducibilityHint)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (backing : StableWhnf mode environment (.const name levels) value)
    (nextSuccess : Forward mode environment fe
      (whnfLoopI (coreKnotI mode fe (fuel + 1)) fe depth 99999
        (deltaReduct (.const name levels) constant body levels)) value) :
    Forward mode environment fe
      ((coreKnotI mode fe (fuel + 2)).whnf depth (.const name levels)) value := by
  exact cached_full_delta mode environment fe (fuel + 1) depth (.const name levels)
    (.const name levels) value name levels constant body hint rfl found arity trivial
    backing rfl (cached_head_atom mode environment fe fuel depth (.const name levels)
      trivial rfl) nextSuccess

#print axioms pure_head_atom
#print axioms stable_head_atom
#print axioms head_body_atom
#print axioms cached_head_atom
#print axioms get_app_fn_scoped
#print axioms whnf_app_done
#print axioms whnf_app_skip
#print axioms whnf_app_iota_of_runs
#print axioms head_loop_app_of_runs
#print axioms beta_peel_never_equation
#print axioms beta_peel_forward
#print axioms whnf_app_beta_forward
#print axioms head_loop_beta_forward
#print axioms cached_head_beta
#print axioms definition_head_no_iota
#print axioms reduce_nat_bypass
#print axioms unfold_definition_of_run
#print axioms unfold_definition_forward
#print axioms unfold_definition_from_prefix
#print axioms full_loop_delta_of_runs
#print axioms full_loop_delta_forward
#print axioms cached_full_delta
#print axioms cached_full_delta_const

end ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward
