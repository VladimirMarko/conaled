# Checkpoint 233: transposition accepted, exact failures retained, strong-CSP producer

The authorized objective remains the closed theorem

```lean
ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

**That stock theorem is still open, as are the original Installed/GroupChecked obligations.** Continue autonomously; keep publishing, exposing and uploading standalone durability checkpoints. The user values transferable computational-proof infrastructure. Do not replace the actual original counter with a newly defined number or treat a compiled external count as a stock Lean proof.

## Actual new execution evidence

| Complete fresh selection | Actual result | Time / peak RSS | Durable recovery |
| --- | --- | --- | --- |
| Original combined word112 | First nine owners passed; Transposition14 failed; later Adjacency19 unstarted. 79 accepted / 93 observed. | 4.663276732004306 s / 508648 KiB | 290 canonical snapshot pairs and20 logs |
| Transposition-repaired word112 | First ten owners passed, including all14 repaired Transposition roots. Final Adjacency19 failed; all19 rejected. 93 accepted /112 observed. | 5.562896967996494 s /508960 KiB | 356 pairs and22 logs |
| Equation-repaired Interpreter185 | Core2 and Cached6 passed. Interpreter177 failed and all177 were rejected. Eight accepted /185 observed. | 27.428755360997457 s /878672 KiB | 1453 pairs and six logs |

The complete word112 selection is not accepted yet. Its useful accepted prefix does not authorize reusing compiled objects. Every later candidate must rebuild the whole selected closure within the original single budget.

The corrected Transposition source has14981 bytes, SHA-256 `0a74004b30e2ffd74f1b2d81a984572cf72ccaf593fc8e532d48604b3ece6492`. Its one proof span canonicalizes the definitionally equal width, then rewrites with the full packet equality. All statements, runtime definitions,14 reports, original indices and field/padding obligations are literal. The independent304/305-input source review is retained. Its actual gate accepted this owner.

The final Adjacency owner reports four error headers in two proof scopes. The zero-bit branch leaves `(decide (0 ≥ 1) && decide (0 - 1 < fieldBits)) = false` and reports two unused simp arguments. A second goal differs only by adding zero to a lane-start index. A new diagnosed proof-only repair is being prepared separately; it is not in this cut. Preserve all executable check definitions, complete-key/payload contracts, guards and19 statements.

The equation-repaired interpreter source has209696 bytes, SHA-256 `611ece23121c54c99a8f1a5fc2e4951f15be73c7e6743bde45295c5c7481e358`; its logical origin has34809 bytes, SHA-256 `f657ae191ae791940a241106113f12b228d553965ea815c399d2b4a34b04b23c`. Its1375/1378-input source scope and40-scope controls are retained. The actual three failures are physical lines3097,3121 and3137: the first two distribute state application through an unknown Boolean conditional in a way Lean does not regard as definitional equality; the last leaves actual preceding level/parameter checks and the verified certificate wrapper. The proposed next repair keeps the conditional over the action until a checked successful run supplies the Boolean, and explicitly stages the real preliminary helpers. No runtime, premise or state-order change is authorized by this diagnosis.

## Consumed keys and reports

* Original word112: key `60a40315a09947384bf26bffede38421461768fb36b9a46f2c0e0bb72a6b28ba`; report284292 bytes, SHA-256 `747a0c825aa1446e9e84aa44f6e05999c6b81c55fc4d8cb324a579cee90caf56`.
* Transposition-repaired112: key `1cdba7f19b794e47fcf02245454677f4e21a7f7549a53c807b1d47e938c7f698`; report346920 bytes, SHA-256 `2ba9621c503218037fbf079472a5f9cba9729f0cb48537418b74a015d57df27e`.
* Equation-repaired185: key `43f7b74d12a8033903f3f95006980b0ad7f92f757812bffab1917cd2e872c035`; report1067195 bytes, SHA-256 `fe09ca2275ec960a331b99c202004c3c64dcb2202889b85dfebf75310b7a0710`.

Each gate directory contains its actual raw logs, report, marker, independent reviews, ROOT-EXECUTION-RECEIPT, SNAPSHOT-RECOVERY and RESULT-AND-NEXT. Root compared all actual snapshot/canonical bytes. The recovery records do not replay a retained mathematical checker or transfer acceptance. All older accepted runs, including word59, Foundation134 and the native reflection/numerical checks, remain in their original exact scopes.

## Preflight-only schema correction

The first Transposition successor metadata preflight stopped before any compiler or marker reservation. Its new validator compared the preserved `field/count` array schema with an inherited helper's `json_field/item_count` schema. Exact values and hashes agreed. All eleven held files and the actual failure receipt are preserved under `gate/preflight-schema-01`; an explicit two-edit/three-complement adapter map preserves both schemas without rewriting old arrays. Root independently reviewed the corrected controls, then preflight passed and the sole mathematical attempt above ran. This was not a source-key reset or mathematical retry.

The corrected runner is196743 bytes, SHA-256 `c1e8e0d55a9299a38119c568f411ff32bc78aab2ce0d35342e19da09a072ebac`; manifest142329 bytes, SHA-256 `50ce3361def6436d924574acbb3790f11d8c3c29b6b32b3bc2c47e94d14963c8`. It preserves all eight separate scopes and356 snapshots.

## Current original-counter CSP endpoint

`kernel-strong-csp-source-endpoint` has an independent92/95-input review. The complete selected graph is25 owners,209833 source bytes,72 distinct reports and50 ordinary outputs. It explicitly reuses the reviewed symbolic primitive and scoped original counting variants, and introduces two exact scoped owners retaining only the generic table-count and residual source bridge. Full forward/inverse maps preserve original runtime definitions, statements, private contexts and source multiplicity conditions.

The original `cqueens` definition and `n ≤ 16` theorem premise remain literal. The source chain goes from the original Word16 counter through the source solution list, finite initial table and tagged residual model count, then the actual finite normalization and certificate checker. Neither the source target nor a checked-success premise is replaced by an expected number. The historical76/77-input strong-CSP quotient review remains separate. This25-owner selection is still uncompiled in this cut.

## New bounded strong-CSP producer

`kernel-strong-csp-producer` contains a new32081-byte C++ source, a5066-byte five-theorem support owner and a739-byte fixed original-counter target. The author inventory freezes123 inputs,31 primary intervals, four new complete SDK copies and the separate76/77 and92/95 historical arrays. No generated mathematical data or executable is included. The separate independent source review has passed, binding123 author inputs plus the inventory as124 direct inputs. SOURCE-REVIEW.md is17782 bytes, SHA-256 `0cdb921f0a1113720ec0899fdedeaa685375f2f9adafc6f2a6e232f04f573252`; SOURCE-AUDIT.json is71861 bytes, SHA-256 `8f3f37f8eedb93f20ce4d22f648754e4424a2dd833cdc0291f9d0cff5b957fd1`. Root read the complete independent review. This is source acceptance only; C++/Lean compilation and a concrete result remain untested.

The producer uses actual smallest-domain branching, support-deletion and singleton-forcing traces, exact completed residual-state memoization, and only row/column translations/reflections that preserve the row-domain problem structure. Row gaps remain represented. Every proposed reference is still checked by the actual finite normalization checker; the C++ memo hash is not a proof. Every branch occurrence contributes to its count. Each local known list is justified by earlier kernel-checked node-count theorems.

All resource arguments are mandatory. Cap, interruption or emission failure yields diagnostic failure, never a completed certificate or accepted frontier. Search computes its own count; the expected numeral is absent from its input. Generated source uses ordinary kernel decisions and the actual checker equations. An exit-zero complete output is still untrusted until Lean accepts all dependencies and the fixed original-counter type assertion.

The proposed first complete discriminator is n8, with110000 calls,4096 completed nodes,65536 propagation steps,16MiB source and5000ms internal producer limit. The fixed `StrongCSPFirstTarget` proves exactly original `cqueens 8 = 92` by applying the generated theorem; the producer never reads that file. Full selection:25 endpoint owners, support, generated proof and fixed target, totaling28 fresh Lean owners,81 reports and56 ordinary outputs, plus C++ compilation and generation inside the same30-second/oneCPU/oneGiB budget. No execution or n16-fit claim follows from this proposal.

The permanent mathematical key must bind the actual static mathematical sources, including generator and fixed target. Cap/compiler/control/attempt-path changes cannot reset an unchanged key. A future genuinely different target requires its own reviewed mathematical source. Producer controls are being authored separately and are excluded from this cut until reviewed.

## Work after restoration

1. Finish the independently reviewed two-scope Adjacency repair and run a new complete fresh112 selection. Preserve the accepted Transposition and all actual earlier failures separately.
2. Finish the new iota continuation proof repair against the actual three diagnostics; review both logical/physical overlays and complete assembly, then review controls before a new complete185 attempt. Do not reuse any old object or retry an unchanged source key.
3. Review the new producer's complete native/source/target controls, then perform its one complete fresh small-case discriminator. Native compilation, producer generation, every project import and the generated/fixed theorem must share the same budget. Inspect the actual result before selecting n16 or any algorithmic repair.
4. Continue toward the real sixteen-queen theorem and reusable checked evaluation infrastructure. Do not confuse a generic helper theorem or compiled external numerical result with the closed stock numeral or original installation obligations.

The exact n6 source-census assessment from232 remains useful: its old479-report timing omitted seven original ADWH owners built outside that timed run. The new word infrastructure alone supplies no complete concrete conversion/route/recurrence certificate. The strong-CSP approach was prioritized because it provides a semantic quotient with explicit finite witnesses, not because an n16 resource fit has been measured.

## Durability and policy

This cut preserves every prior payload path and adds only current frozen source/evidence. It excludes prepared objects, SDK/compiler binaries, duplicate attempt input/source/build trees, full textbook/upstream metatheory and in-progress successor packages. Exact living-handoff identities from232 and the earlier231 documents remain only where needed to recover frozen review references; no old review array is rebased. Checkpoint232's clean-restoration/upload receipt is included.

Read `checkpoint233-selection-review.json` for the measured storage guard and exact dependency/recovery checks. Any storage-only increase does not alter mathematical limits. All mathematical work remains root-only with one cumulative30-second, oneCPU/thread/import-worker, oneGiB/default-resource/strict-warning policy and only `propext`, `Quot.sound`, `Classical.choice`. Source/static agents must not invoke a compiler, gate/preflight, generator, mathematical evaluator, exporter or retained-result reader.
