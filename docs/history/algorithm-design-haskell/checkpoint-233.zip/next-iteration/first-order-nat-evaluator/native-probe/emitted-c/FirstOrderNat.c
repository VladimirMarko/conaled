// Lean compiler output
// Module: FirstOrderNat
// Imports: public import Init public meta import Init public import FiniteFold
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_lor(lean_object*, lean_object*);
lean_object* lean_nat_land(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_shiftl(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_pow(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_low(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_low___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_available(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_available___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_count(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_count___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_branches___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6___boxed(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__0 = (const lean_object*)&l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__0_value;
static const lean_closure_object l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__1 = (const lean_object*)&l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__1_value;
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedCount(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedCount___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedBranches(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedBranches___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_low(lean_object* v_modulus_1_, lean_object* v_cursor_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; lean_object* v___x_5_; 
v___x_3_ = lean_nat_sub(v_modulus_1_, v_cursor_2_);
v___x_4_ = lean_nat_mod(v___x_3_, v_modulus_1_);
lean_dec(v___x_3_);
v___x_5_ = lean_nat_land(v_cursor_2_, v___x_4_);
lean_dec(v___x_4_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_low___boxed(lean_object* v_modulus_6_, lean_object* v_cursor_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_low(v_modulus_6_, v_cursor_7_);
lean_dec(v_cursor_7_);
lean_dec(v_modulus_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_available(lean_object* v_modulus_9_, lean_object* v_mask_10_, lean_object* v_left_11_, lean_object* v_columns_12_, lean_object* v_right_13_){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; 
v___x_14_ = lean_unsigned_to_nat(1u);
v___x_15_ = lean_nat_sub(v_modulus_9_, v___x_14_);
v___x_16_ = lean_nat_lor(v_left_11_, v_columns_12_);
v___x_17_ = lean_nat_lor(v___x_16_, v_right_13_);
lean_dec(v___x_16_);
v___x_18_ = lean_nat_sub(v___x_15_, v___x_17_);
lean_dec(v___x_17_);
lean_dec(v___x_15_);
v___x_19_ = lean_nat_land(v___x_18_, v_mask_10_);
lean_dec(v___x_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_available___boxed(lean_object* v_modulus_20_, lean_object* v_mask_21_, lean_object* v_left_22_, lean_object* v_columns_23_, lean_object* v_right_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_available(v_modulus_20_, v_mask_21_, v_left_22_, v_columns_23_, v_right_24_);
lean_dec(v_right_24_);
lean_dec(v_columns_23_);
lean_dec(v_left_22_);
lean_dec(v_mask_21_);
lean_dec(v_modulus_20_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(lean_object* v_modulus_26_, lean_object* v_mask_27_, lean_object* v_budget_28_, lean_object* v_depth_29_, lean_object* v_left_30_, lean_object* v_columns_31_, lean_object* v_right_32_, lean_object* v_fuel_33_, lean_object* v_cursor_34_){
_start:
{
lean_object* v_zero_35_; uint8_t v_isZero_36_; 
v_zero_35_ = lean_unsigned_to_nat(0u);
v_isZero_36_ = lean_nat_dec_eq(v_fuel_33_, v_zero_35_);
if (v_isZero_36_ == 1)
{
return v_zero_35_;
}
else
{
uint8_t v___x_37_; 
v___x_37_ = lean_nat_dec_eq(v_cursor_34_, v_zero_35_);
if (v___x_37_ == 0)
{
lean_object* v_one_38_; lean_object* v_n_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v_bit_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; 
v_one_38_ = lean_unsigned_to_nat(1u);
v_n_39_ = lean_nat_sub(v_fuel_33_, v_one_38_);
v___x_40_ = lean_nat_sub(v_modulus_26_, v_cursor_34_);
v___x_41_ = lean_nat_mod(v___x_40_, v_modulus_26_);
lean_dec(v___x_40_);
v_bit_42_ = lean_nat_land(v_cursor_34_, v___x_41_);
lean_dec(v___x_41_);
v___x_43_ = lean_nat_lor(v_left_30_, v_bit_42_);
v___x_44_ = lean_unsigned_to_nat(2u);
v___x_45_ = lean_nat_mul(v___x_43_, v___x_44_);
lean_dec(v___x_43_);
v___x_46_ = lean_nat_mod(v___x_45_, v_modulus_26_);
lean_dec(v___x_45_);
v___x_47_ = lean_nat_lor(v_columns_31_, v_bit_42_);
v___x_48_ = lean_nat_lor(v_right_32_, v_bit_42_);
v___x_49_ = lean_nat_shiftr(v___x_48_, v_one_38_);
lean_dec(v___x_48_);
v___x_50_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_count(v_modulus_26_, v_mask_27_, v_budget_28_, v_depth_29_, v___x_46_, v___x_47_, v___x_49_);
lean_dec(v___x_49_);
lean_dec(v___x_47_);
lean_dec(v___x_46_);
v___x_51_ = lean_nat_sub(v_cursor_34_, v_bit_42_);
lean_dec(v_bit_42_);
v___x_52_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(v_modulus_26_, v_mask_27_, v_budget_28_, v_depth_29_, v_left_30_, v_columns_31_, v_right_32_, v_n_39_, v___x_51_);
lean_dec(v___x_51_);
lean_dec(v_n_39_);
v___x_53_ = lean_nat_add(v___x_50_, v___x_52_);
lean_dec(v___x_52_);
lean_dec(v___x_50_);
return v___x_53_;
}
else
{
return v_zero_35_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_count(lean_object* v_modulus_54_, lean_object* v_mask_55_, lean_object* v_budget_56_, lean_object* v_depth_57_, lean_object* v_left_58_, lean_object* v_columns_59_, lean_object* v_right_60_){
_start:
{
lean_object* v_zero_61_; uint8_t v_isZero_62_; 
v_zero_61_ = lean_unsigned_to_nat(0u);
v_isZero_62_ = lean_nat_dec_eq(v_depth_57_, v_zero_61_);
if (v_isZero_62_ == 1)
{
uint8_t v___x_63_; 
v___x_63_ = lean_nat_dec_eq(v_columns_59_, v_mask_55_);
if (v___x_63_ == 0)
{
return v_zero_61_;
}
else
{
lean_object* v___x_64_; 
v___x_64_ = lean_unsigned_to_nat(1u);
return v___x_64_;
}
}
else
{
uint8_t v___x_65_; 
v___x_65_ = lean_nat_dec_eq(v_columns_59_, v_mask_55_);
if (v___x_65_ == 0)
{
lean_object* v_one_66_; lean_object* v_n_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; 
v_one_66_ = lean_unsigned_to_nat(1u);
v_n_67_ = lean_nat_sub(v_depth_57_, v_one_66_);
v___x_68_ = lean_nat_sub(v_modulus_54_, v_one_66_);
v___x_69_ = lean_nat_lor(v_left_58_, v_columns_59_);
v___x_70_ = lean_nat_lor(v___x_69_, v_right_60_);
lean_dec(v___x_69_);
v___x_71_ = lean_nat_sub(v___x_68_, v___x_70_);
lean_dec(v___x_70_);
lean_dec(v___x_68_);
v___x_72_ = lean_nat_land(v___x_71_, v_mask_55_);
lean_dec(v___x_71_);
v___x_73_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(v_modulus_54_, v_mask_55_, v_budget_56_, v_n_67_, v_left_58_, v_columns_59_, v_right_60_, v_budget_56_, v___x_72_);
lean_dec(v___x_72_);
lean_dec(v_n_67_);
return v___x_73_;
}
else
{
lean_object* v___x_74_; 
v___x_74_ = lean_unsigned_to_nat(1u);
return v___x_74_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_count___boxed(lean_object* v_modulus_75_, lean_object* v_mask_76_, lean_object* v_budget_77_, lean_object* v_depth_78_, lean_object* v_left_79_, lean_object* v_columns_80_, lean_object* v_right_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_count(v_modulus_75_, v_mask_76_, v_budget_77_, v_depth_78_, v_left_79_, v_columns_80_, v_right_81_);
lean_dec(v_right_81_);
lean_dec(v_columns_80_);
lean_dec(v_left_79_);
lean_dec(v_depth_78_);
lean_dec(v_budget_77_);
lean_dec(v_mask_76_);
lean_dec(v_modulus_75_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_branches___boxed(lean_object* v_modulus_83_, lean_object* v_mask_84_, lean_object* v_budget_85_, lean_object* v_depth_86_, lean_object* v_left_87_, lean_object* v_columns_88_, lean_object* v_right_89_, lean_object* v_fuel_90_, lean_object* v_cursor_91_){
_start:
{
lean_object* v_res_92_; 
v_res_92_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(v_modulus_83_, v_mask_84_, v_budget_85_, v_depth_86_, v_left_87_, v_columns_88_, v_right_89_, v_fuel_90_, v_cursor_91_);
lean_dec(v_cursor_91_);
lean_dec(v_fuel_90_);
lean_dec(v_right_89_);
lean_dec(v_columns_88_);
lean_dec(v_left_87_);
lean_dec(v_depth_86_);
lean_dec(v_budget_85_);
lean_dec(v_mask_84_);
lean_dec(v_modulus_83_);
return v_res_92_;
}
}
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___redArg(lean_object* v_depth_93_, lean_object* v_h__1_94_, lean_object* v_h__2_95_){
_start:
{
lean_object* v_zero_96_; uint8_t v_isZero_97_; 
v_zero_96_ = lean_unsigned_to_nat(0u);
v_isZero_97_ = lean_nat_dec_eq(v_depth_93_, v_zero_96_);
if (v_isZero_97_ == 1)
{
lean_object* v___x_98_; lean_object* v___x_99_; 
lean_dec(v_h__2_95_);
v___x_98_ = lean_box(0);
v___x_99_ = lean_apply_1(v_h__1_94_, v___x_98_);
return v___x_99_;
}
else
{
lean_object* v_one_100_; lean_object* v_n_101_; lean_object* v___x_102_; 
lean_dec(v_h__1_94_);
v_one_100_ = lean_unsigned_to_nat(1u);
v_n_101_ = lean_nat_sub(v_depth_93_, v_one_100_);
v___x_102_ = lean_apply_1(v_h__2_95_, v_n_101_);
return v___x_102_;
}
}
}
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___redArg___boxed(lean_object* v_depth_103_, lean_object* v_h__1_104_, lean_object* v_h__2_105_){
_start:
{
lean_object* v_res_106_; 
v_res_106_ = l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___redArg(v_depth_103_, v_h__1_104_, v_h__2_105_);
lean_dec(v_depth_103_);
return v_res_106_;
}
}
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter(lean_object* v_motive_107_, lean_object* v_depth_108_, lean_object* v_h__1_109_, lean_object* v_h__2_110_){
_start:
{
lean_object* v_zero_111_; uint8_t v_isZero_112_; 
v_zero_111_ = lean_unsigned_to_nat(0u);
v_isZero_112_ = lean_nat_dec_eq(v_depth_108_, v_zero_111_);
if (v_isZero_112_ == 1)
{
lean_object* v___x_113_; lean_object* v___x_114_; 
lean_dec(v_h__2_110_);
v___x_113_ = lean_box(0);
v___x_114_ = lean_apply_1(v_h__1_109_, v___x_113_);
return v___x_114_;
}
else
{
lean_object* v_one_115_; lean_object* v_n_116_; lean_object* v___x_117_; 
lean_dec(v_h__1_109_);
v_one_115_ = lean_unsigned_to_nat(1u);
v_n_116_ = lean_nat_sub(v_depth_108_, v_one_115_);
v___x_117_ = lean_apply_1(v_h__2_110_, v_n_116_);
return v___x_117_;
}
}
}
LEAN_EXPORT lean_object* l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter___boxed(lean_object* v_motive_118_, lean_object* v_depth_119_, lean_object* v_h__1_120_, lean_object* v_h__2_121_){
_start:
{
lean_object* v_res_122_; 
v_res_122_ = l___private_FirstOrderNat_0__ADWH_Experiments_Chapter15_FirstOrderNat_count_match__1_splitter(v_motive_118_, v_depth_119_, v_h__1_120_, v_h__2_121_);
lean_dec(v_depth_119_);
return v_res_122_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate(lean_object* v_width_123_, lean_object* v_mask_124_, lean_object* v_depth_125_, lean_object* v_left_126_, lean_object* v_columns_127_, lean_object* v_right_128_){
_start:
{
lean_object* v___x_129_; lean_object* v___x_130_; lean_object* v___x_131_; 
v___x_129_ = lean_unsigned_to_nat(2u);
v___x_130_ = lean_nat_pow(v___x_129_, v_width_123_);
v___x_131_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_count(v___x_130_, v_mask_124_, v_width_123_, v_depth_125_, v_left_126_, v_columns_127_, v_right_128_);
lean_dec(v___x_130_);
return v___x_131_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate___boxed(lean_object* v_width_132_, lean_object* v_mask_133_, lean_object* v_depth_134_, lean_object* v_left_135_, lean_object* v_columns_136_, lean_object* v_right_137_){
_start:
{
lean_object* v_res_138_; 
v_res_138_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate(v_width_132_, v_mask_133_, v_depth_134_, v_left_135_, v_columns_136_, v_right_137_);
lean_dec(v_right_137_);
lean_dec(v_columns_136_);
lean_dec(v_left_135_);
lean_dec(v_depth_134_);
lean_dec(v_mask_133_);
lean_dec(v_width_132_);
return v_res_138_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext(lean_object* v_modulus_139_, lean_object* v_state_140_, lean_object* v_bit_141_){
_start:
{
lean_object* v_snd_142_; lean_object* v_fst_143_; lean_object* v___x_145_; uint8_t v_isShared_146_; uint8_t v_isSharedCheck_166_; 
v_snd_142_ = lean_ctor_get(v_state_140_, 1);
v_fst_143_ = lean_ctor_get(v_state_140_, 0);
v_isSharedCheck_166_ = !lean_is_exclusive(v_state_140_);
if (v_isSharedCheck_166_ == 0)
{
v___x_145_ = v_state_140_;
v_isShared_146_ = v_isSharedCheck_166_;
goto v_resetjp_144_;
}
else
{
lean_inc(v_snd_142_);
lean_inc(v_fst_143_);
lean_dec(v_state_140_);
v___x_145_ = lean_box(0);
v_isShared_146_ = v_isSharedCheck_166_;
goto v_resetjp_144_;
}
v_resetjp_144_:
{
lean_object* v_fst_147_; lean_object* v_snd_148_; lean_object* v___x_150_; uint8_t v_isShared_151_; uint8_t v_isSharedCheck_165_; 
v_fst_147_ = lean_ctor_get(v_snd_142_, 0);
v_snd_148_ = lean_ctor_get(v_snd_142_, 1);
v_isSharedCheck_165_ = !lean_is_exclusive(v_snd_142_);
if (v_isSharedCheck_165_ == 0)
{
v___x_150_ = v_snd_142_;
v_isShared_151_ = v_isSharedCheck_165_;
goto v_resetjp_149_;
}
else
{
lean_inc(v_snd_148_);
lean_inc(v_fst_147_);
lean_dec(v_snd_142_);
v___x_150_ = lean_box(0);
v_isShared_151_ = v_isSharedCheck_165_;
goto v_resetjp_149_;
}
v_resetjp_149_:
{
lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; lean_object* v___x_160_; 
v___x_152_ = lean_nat_lor(v_fst_143_, v_bit_141_);
lean_dec(v_fst_143_);
v___x_153_ = lean_unsigned_to_nat(1u);
v___x_154_ = lean_nat_shiftl(v___x_152_, v___x_153_);
lean_dec(v___x_152_);
v___x_155_ = lean_nat_mod(v___x_154_, v_modulus_139_);
lean_dec(v___x_154_);
v___x_156_ = lean_nat_lor(v_fst_147_, v_bit_141_);
lean_dec(v_fst_147_);
v___x_157_ = lean_nat_lor(v_snd_148_, v_bit_141_);
lean_dec(v_snd_148_);
v___x_158_ = lean_nat_shiftr(v___x_157_, v___x_153_);
lean_dec(v___x_157_);
if (v_isShared_151_ == 0)
{
lean_ctor_set(v___x_150_, 1, v___x_158_);
lean_ctor_set(v___x_150_, 0, v___x_156_);
v___x_160_ = v___x_150_;
goto v_reusejp_159_;
}
else
{
lean_object* v_reuseFailAlloc_164_; 
v_reuseFailAlloc_164_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_164_, 0, v___x_156_);
lean_ctor_set(v_reuseFailAlloc_164_, 1, v___x_158_);
v___x_160_ = v_reuseFailAlloc_164_;
goto v_reusejp_159_;
}
v_reusejp_159_:
{
lean_object* v___x_162_; 
if (v_isShared_146_ == 0)
{
lean_ctor_set(v___x_145_, 1, v___x_160_);
lean_ctor_set(v___x_145_, 0, v___x_155_);
v___x_162_ = v___x_145_;
goto v_reusejp_161_;
}
else
{
lean_object* v_reuseFailAlloc_163_; 
v_reuseFailAlloc_163_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_163_, 0, v___x_155_);
lean_ctor_set(v_reuseFailAlloc_163_, 1, v___x_160_);
v___x_162_ = v_reuseFailAlloc_163_;
goto v_reusejp_161_;
}
v_reusejp_161_:
{
return v___x_162_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext___boxed(lean_object* v_modulus_167_, lean_object* v_state_168_, lean_object* v_bit_169_){
_start:
{
lean_object* v_res_170_; 
v_res_170_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext(v_modulus_167_, v_state_168_, v_bit_169_);
lean_dec(v_bit_169_);
lean_dec(v_modulus_167_);
return v_res_170_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0(lean_object* v_mask_171_, lean_object* v_state_172_){
_start:
{
lean_object* v_snd_173_; lean_object* v_fst_174_; uint8_t v___x_175_; 
v_snd_173_ = lean_ctor_get(v_state_172_, 1);
v_fst_174_ = lean_ctor_get(v_snd_173_, 0);
v___x_175_ = lean_nat_dec_eq(v_fst_174_, v_mask_171_);
return v___x_175_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0___boxed(lean_object* v_mask_176_, lean_object* v_state_177_){
_start:
{
uint8_t v_res_178_; lean_object* v_r_179_; 
v_res_178_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0(v_mask_176_, v_state_177_);
lean_dec_ref(v_state_177_);
lean_dec(v_mask_176_);
v_r_179_ = lean_box(v_res_178_);
return v_r_179_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1(lean_object* v_x_180_){
_start:
{
lean_object* v___x_181_; 
v___x_181_ = lean_unsigned_to_nat(1u);
return v___x_181_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1___boxed(lean_object* v_x_182_){
_start:
{
lean_object* v_res_183_; 
v_res_183_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__1(v_x_182_);
lean_dec_ref(v_x_182_);
return v_res_183_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2(lean_object* v_modulus_184_, lean_object* v_mask_185_, lean_object* v_state_186_){
_start:
{
lean_object* v_snd_187_; lean_object* v_fst_188_; lean_object* v_fst_189_; lean_object* v_snd_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; 
v_snd_187_ = lean_ctor_get(v_state_186_, 1);
v_fst_188_ = lean_ctor_get(v_state_186_, 0);
v_fst_189_ = lean_ctor_get(v_snd_187_, 0);
v_snd_190_ = lean_ctor_get(v_snd_187_, 1);
v___x_191_ = lean_unsigned_to_nat(1u);
v___x_192_ = lean_nat_sub(v_modulus_184_, v___x_191_);
v___x_193_ = lean_nat_lor(v_fst_188_, v_fst_189_);
v___x_194_ = lean_nat_lor(v___x_193_, v_snd_190_);
lean_dec(v___x_193_);
v___x_195_ = lean_nat_sub(v___x_192_, v___x_194_);
lean_dec(v___x_194_);
lean_dec(v___x_192_);
v___x_196_ = lean_nat_land(v___x_195_, v_mask_185_);
lean_dec(v___x_195_);
return v___x_196_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2___boxed(lean_object* v_modulus_197_, lean_object* v_mask_198_, lean_object* v_state_199_){
_start:
{
lean_object* v_res_200_; 
v_res_200_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2(v_modulus_197_, v_mask_198_, v_state_199_);
lean_dec_ref(v_state_199_);
lean_dec(v_mask_198_);
lean_dec(v_modulus_197_);
return v_res_200_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3(lean_object* v_cursor_201_){
_start:
{
lean_object* v___x_202_; uint8_t v___x_203_; 
v___x_202_ = lean_unsigned_to_nat(0u);
v___x_203_ = lean_nat_dec_eq(v_cursor_201_, v___x_202_);
return v___x_203_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3___boxed(lean_object* v_cursor_204_){
_start:
{
uint8_t v_res_205_; lean_object* v_r_206_; 
v_res_205_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__3(v_cursor_204_);
lean_dec(v_cursor_204_);
v_r_206_ = lean_box(v_res_205_);
return v_r_206_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4(lean_object* v_modulus_207_, lean_object* v_cursor_208_){
_start:
{
lean_object* v___x_209_; lean_object* v___x_210_; lean_object* v___x_211_; lean_object* v___x_212_; 
v___x_209_ = lean_nat_sub(v_modulus_207_, v_cursor_208_);
v___x_210_ = lean_nat_mod(v___x_209_, v_modulus_207_);
lean_dec(v___x_209_);
v___x_211_ = lean_nat_land(v_cursor_208_, v___x_210_);
lean_dec(v___x_210_);
v___x_212_ = lean_nat_sub(v_cursor_208_, v___x_211_);
lean_dec(v___x_211_);
return v___x_212_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4___boxed(lean_object* v_modulus_213_, lean_object* v_cursor_214_){
_start:
{
lean_object* v_res_215_; 
v_res_215_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4(v_modulus_213_, v_cursor_214_);
lean_dec(v_cursor_214_);
lean_dec(v_modulus_213_);
return v_res_215_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5(lean_object* v_budget_216_, lean_object* v_x_217_){
_start:
{
lean_inc(v_budget_216_);
return v_budget_216_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5___boxed(lean_object* v_budget_218_, lean_object* v_x_219_){
_start:
{
lean_object* v_res_220_; 
v_res_220_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5(v_budget_218_, v_x_219_);
lean_dec_ref(v_x_219_);
lean_dec(v_budget_218_);
return v_res_220_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6(lean_object* v_modulus_221_, lean_object* v___y_222_){
_start:
{
lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v___x_225_; 
v___x_223_ = lean_nat_sub(v_modulus_221_, v___y_222_);
v___x_224_ = lean_nat_mod(v___x_223_, v_modulus_221_);
lean_dec(v___x_223_);
v___x_225_ = lean_nat_land(v___y_222_, v___x_224_);
lean_dec(v___x_224_);
return v___x_225_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6___boxed(lean_object* v_modulus_226_, lean_object* v___y_227_){
_start:
{
lean_object* v_res_228_; 
v_res_228_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6(v_modulus_226_, v___y_227_);
lean_dec(v___y_227_);
lean_dec(v_modulus_226_);
return v_res_228_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_spec(lean_object* v_modulus_231_, lean_object* v_mask_232_, lean_object* v_budget_233_){
_start:
{
lean_object* v___f_234_; lean_object* v___f_235_; lean_object* v___f_236_; lean_object* v___f_237_; lean_object* v___f_238_; lean_object* v___f_239_; lean_object* v___f_240_; lean_object* v___x_241_; lean_object* v___x_242_; 
lean_inc(v_mask_232_);
v___f_234_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__0___boxed), 2, 1);
lean_closure_set(v___f_234_, 0, v_mask_232_);
v___f_235_ = ((lean_object*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__0));
lean_inc_n(v_modulus_231_, 3);
v___f_236_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__2___boxed), 3, 2);
lean_closure_set(v___f_236_, 0, v_modulus_231_);
lean_closure_set(v___f_236_, 1, v_mask_232_);
v___f_237_ = ((lean_object*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___closed__1));
v___f_238_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__4___boxed), 2, 1);
lean_closure_set(v___f_238_, 0, v_modulus_231_);
v___f_239_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__5___boxed), 2, 1);
lean_closure_set(v___f_239_, 0, v_budget_233_);
v___f_240_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_spec___lam__6___boxed), 2, 1);
lean_closure_set(v___f_240_, 0, v_modulus_231_);
v___x_241_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FirstOrderNat_referenceNext___boxed), 3, 1);
lean_closure_set(v___x_241_, 0, v_modulus_231_);
v___x_242_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v___x_242_, 0, v___f_234_);
lean_ctor_set(v___x_242_, 1, v___f_235_);
lean_ctor_set(v___x_242_, 2, v___f_236_);
lean_ctor_set(v___x_242_, 3, v___f_237_);
lean_ctor_set(v___x_242_, 4, v___f_240_);
lean_ctor_set(v___x_242_, 5, v___f_238_);
lean_ctor_set(v___x_242_, 6, v___x_241_);
lean_ctor_set(v___x_242_, 7, v___f_239_);
return v___x_242_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedCount(lean_object* v_modulus_243_, lean_object* v_mask_244_, lean_object* v_budget_245_, lean_object* v_depth_246_, lean_object* v_state_247_){
_start:
{
lean_object* v_snd_248_; lean_object* v_fst_249_; lean_object* v_fst_250_; lean_object* v_snd_251_; lean_object* v___x_252_; 
v_snd_248_ = lean_ctor_get(v_state_247_, 1);
v_fst_249_ = lean_ctor_get(v_state_247_, 0);
v_fst_250_ = lean_ctor_get(v_snd_248_, 0);
v_snd_251_ = lean_ctor_get(v_snd_248_, 1);
v___x_252_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_count(v_modulus_243_, v_mask_244_, v_budget_245_, v_depth_246_, v_fst_249_, v_fst_250_, v_snd_251_);
return v___x_252_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedCount___boxed(lean_object* v_modulus_253_, lean_object* v_mask_254_, lean_object* v_budget_255_, lean_object* v_depth_256_, lean_object* v_state_257_){
_start:
{
lean_object* v_res_258_; 
v_res_258_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedCount(v_modulus_253_, v_mask_254_, v_budget_255_, v_depth_256_, v_state_257_);
lean_dec_ref(v_state_257_);
lean_dec(v_depth_256_);
lean_dec(v_budget_255_);
lean_dec(v_mask_254_);
lean_dec(v_modulus_253_);
return v_res_258_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedBranches(lean_object* v_modulus_259_, lean_object* v_mask_260_, lean_object* v_budget_261_, lean_object* v_depth_262_, lean_object* v_state_263_, lean_object* v_fuel_264_, lean_object* v_cursor_265_){
_start:
{
lean_object* v_snd_266_; lean_object* v_fst_267_; lean_object* v_fst_268_; lean_object* v_snd_269_; lean_object* v___x_270_; 
v_snd_266_ = lean_ctor_get(v_state_263_, 1);
v_fst_267_ = lean_ctor_get(v_state_263_, 0);
v_fst_268_ = lean_ctor_get(v_snd_266_, 0);
v_snd_269_ = lean_ctor_get(v_snd_266_, 1);
v___x_270_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_branches(v_modulus_259_, v_mask_260_, v_budget_261_, v_depth_262_, v_fst_267_, v_fst_268_, v_snd_269_, v_fuel_264_, v_cursor_265_);
return v___x_270_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedBranches___boxed(lean_object* v_modulus_271_, lean_object* v_mask_272_, lean_object* v_budget_273_, lean_object* v_depth_274_, lean_object* v_state_275_, lean_object* v_fuel_276_, lean_object* v_cursor_277_){
_start:
{
lean_object* v_res_278_; 
v_res_278_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_liftedBranches(v_modulus_271_, v_mask_272_, v_budget_273_, v_depth_274_, v_state_275_, v_fuel_276_, v_cursor_277_);
lean_dec(v_cursor_277_);
lean_dec(v_fuel_276_);
lean_dec_ref(v_state_275_);
lean_dec(v_depth_274_);
lean_dec(v_budget_273_);
lean_dec(v_mask_272_);
lean_dec(v_modulus_271_);
return v_res_278_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_FiniteFold(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_FirstOrderNat(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_FiniteFold(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
