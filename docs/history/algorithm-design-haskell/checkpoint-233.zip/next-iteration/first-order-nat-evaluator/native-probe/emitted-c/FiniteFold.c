// Lean compiler output
// Module: FiniteFold
// Imports: public import Init public meta import Init public import Init
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(lean_object* v_spec_1_, lean_object* v_f_2_, lean_object* v_state_3_, lean_object* v_x_4_, lean_object* v_x_5_){
_start:
{
lean_object* v_zero_6_; uint8_t v_isZero_7_; 
v_zero_6_ = lean_unsigned_to_nat(0u);
v_isZero_7_ = lean_nat_dec_eq(v_x_4_, v_zero_6_);
if (v_isZero_7_ == 1)
{
lean_dec(v_x_5_);
lean_dec(v_state_3_);
lean_dec_ref(v_f_2_);
lean_dec_ref(v_spec_1_);
return v_zero_6_;
}
else
{
lean_object* v_empty_8_; lean_object* v_head_9_; lean_object* v_rest_10_; lean_object* v_next_11_; lean_object* v___x_12_; uint8_t v___x_13_; 
v_empty_8_ = lean_ctor_get(v_spec_1_, 3);
v_head_9_ = lean_ctor_get(v_spec_1_, 4);
v_rest_10_ = lean_ctor_get(v_spec_1_, 5);
v_next_11_ = lean_ctor_get(v_spec_1_, 6);
lean_inc_ref(v_empty_8_);
lean_inc(v_x_5_);
v___x_12_ = lean_apply_1(v_empty_8_, v_x_5_);
v___x_13_ = lean_unbox(v___x_12_);
if (v___x_13_ == 0)
{
lean_object* v_one_14_; lean_object* v_n_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; 
v_one_14_ = lean_unsigned_to_nat(1u);
v_n_15_ = lean_nat_sub(v_x_4_, v_one_14_);
lean_inc(v_head_9_);
lean_inc(v_x_5_);
v___x_16_ = lean_apply_1(v_head_9_, v_x_5_);
lean_inc(v_next_11_);
lean_inc(v_state_3_);
v___x_17_ = lean_apply_2(v_next_11_, v_state_3_, v___x_16_);
lean_inc_ref(v_f_2_);
v___x_18_ = lean_apply_1(v_f_2_, v___x_17_);
lean_inc(v_rest_10_);
v___x_19_ = lean_apply_1(v_rest_10_, v_x_5_);
v___x_20_ = l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(v_spec_1_, v_f_2_, v_state_3_, v_n_15_, v___x_19_);
lean_dec(v_n_15_);
v___x_21_ = lean_nat_add(v___x_18_, v___x_20_);
lean_dec(v___x_20_);
lean_dec(v___x_18_);
return v___x_21_;
}
else
{
lean_dec(v_x_5_);
lean_dec(v_state_3_);
lean_dec_ref(v_f_2_);
lean_dec_ref(v_spec_1_);
return v_zero_6_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg___boxed(lean_object* v_spec_22_, lean_object* v_f_23_, lean_object* v_state_24_, lean_object* v_x_25_, lean_object* v_x_26_){
_start:
{
lean_object* v_res_27_; 
v_res_27_ = l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(v_spec_22_, v_f_23_, v_state_24_, v_x_25_, v_x_26_);
lean_dec(v_x_25_);
return v_res_27_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop(lean_object* v_State_28_, lean_object* v_Cursor_29_, lean_object* v_Choice_30_, lean_object* v_spec_31_, lean_object* v_f_32_, lean_object* v_state_33_, lean_object* v_x_34_, lean_object* v_x_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(v_spec_31_, v_f_32_, v_state_33_, v_x_34_, v_x_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_loop___boxed(lean_object* v_State_37_, lean_object* v_Cursor_38_, lean_object* v_Choice_39_, lean_object* v_spec_40_, lean_object* v_f_41_, lean_object* v_state_42_, lean_object* v_x_43_, lean_object* v_x_44_){
_start:
{
lean_object* v_res_45_; 
v_res_45_ = l_ADWH_Experiments_Chapter15_FiniteFold_loop(v_State_37_, v_Cursor_38_, v_Choice_39_, v_spec_40_, v_f_41_, v_state_42_, v_x_43_, v_x_44_);
lean_dec(v_x_43_);
return v_res_45_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0___boxed(lean_object* v_spec_46_, lean_object* v_n_47_, lean_object* v_child_48_){
_start:
{
lean_object* v_res_49_; 
v_res_49_ = l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0(v_spec_46_, v_n_47_, v_child_48_);
lean_dec(v_n_47_);
return v_res_49_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg(lean_object* v_spec_50_, lean_object* v_x_51_, lean_object* v_x_52_){
_start:
{
lean_object* v_zero_53_; uint8_t v_isZero_54_; 
v_zero_53_ = lean_unsigned_to_nat(0u);
v_isZero_54_ = lean_nat_dec_eq(v_x_51_, v_zero_53_);
if (v_isZero_54_ == 1)
{
lean_object* v_terminal_55_; lean_object* v_terminalValue_56_; lean_object* v___x_57_; uint8_t v___x_58_; 
v_terminal_55_ = lean_ctor_get(v_spec_50_, 0);
lean_inc_ref(v_terminal_55_);
v_terminalValue_56_ = lean_ctor_get(v_spec_50_, 1);
lean_inc_ref(v_terminalValue_56_);
lean_dec_ref(v_spec_50_);
lean_inc(v_x_52_);
v___x_57_ = lean_apply_1(v_terminal_55_, v_x_52_);
v___x_58_ = lean_unbox(v___x_57_);
if (v___x_58_ == 0)
{
lean_dec_ref(v_terminalValue_56_);
lean_dec(v_x_52_);
return v_zero_53_;
}
else
{
lean_object* v___x_59_; 
v___x_59_ = lean_apply_1(v_terminalValue_56_, v_x_52_);
return v___x_59_;
}
}
else
{
lean_object* v_terminal_60_; lean_object* v_terminalValue_61_; lean_object* v_start_62_; lean_object* v_budget_63_; lean_object* v___x_64_; uint8_t v___x_65_; 
v_terminal_60_ = lean_ctor_get(v_spec_50_, 0);
v_terminalValue_61_ = lean_ctor_get(v_spec_50_, 1);
v_start_62_ = lean_ctor_get(v_spec_50_, 2);
v_budget_63_ = lean_ctor_get(v_spec_50_, 7);
lean_inc_ref(v_terminal_60_);
lean_inc(v_x_52_);
v___x_64_ = lean_apply_1(v_terminal_60_, v_x_52_);
v___x_65_ = lean_unbox(v___x_64_);
if (v___x_65_ == 0)
{
lean_object* v_one_66_; lean_object* v_n_67_; lean_object* v___f_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; 
v_one_66_ = lean_unsigned_to_nat(1u);
v_n_67_ = lean_nat_sub(v_x_51_, v_one_66_);
lean_inc_ref(v_spec_50_);
v___f_68_ = lean_alloc_closure((void*)(l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0___boxed), 3, 2);
lean_closure_set(v___f_68_, 0, v_spec_50_);
lean_closure_set(v___f_68_, 1, v_n_67_);
lean_inc_ref(v_budget_63_);
lean_inc_n(v_x_52_, 2);
v___x_69_ = lean_apply_1(v_budget_63_, v_x_52_);
lean_inc(v_start_62_);
v___x_70_ = lean_apply_1(v_start_62_, v_x_52_);
v___x_71_ = l_ADWH_Experiments_Chapter15_FiniteFold_loop___redArg(v_spec_50_, v___f_68_, v_x_52_, v___x_69_, v___x_70_);
lean_dec(v___x_69_);
return v___x_71_;
}
else
{
lean_object* v___x_72_; 
lean_inc_ref(v_terminalValue_61_);
lean_dec_ref(v_spec_50_);
v___x_72_ = lean_apply_1(v_terminalValue_61_, v_x_52_);
return v___x_72_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___lam__0(lean_object* v_spec_73_, lean_object* v_n_74_, lean_object* v_child_75_){
_start:
{
lean_object* v___x_76_; 
v___x_76_ = l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg(v_spec_73_, v_n_74_, v_child_75_);
return v___x_76_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg___boxed(lean_object* v_spec_77_, lean_object* v_x_78_, lean_object* v_x_79_){
_start:
{
lean_object* v_res_80_; 
v_res_80_ = l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg(v_spec_77_, v_x_78_, v_x_79_);
lean_dec(v_x_78_);
return v_res_80_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold(lean_object* v_State_81_, lean_object* v_Cursor_82_, lean_object* v_Choice_83_, lean_object* v_spec_84_, lean_object* v_x_85_, lean_object* v_x_86_){
_start:
{
lean_object* v___x_87_; 
v___x_87_ = l_ADWH_Experiments_Chapter15_FiniteFold_fold___redArg(v_spec_84_, v_x_85_, v_x_86_);
return v___x_87_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Experiments_Chapter15_FiniteFold_fold___boxed(lean_object* v_State_88_, lean_object* v_Cursor_89_, lean_object* v_Choice_90_, lean_object* v_spec_91_, lean_object* v_x_92_, lean_object* v_x_93_){
_start:
{
lean_object* v_res_94_; 
v_res_94_ = l_ADWH_Experiments_Chapter15_FiniteFold_fold(v_State_88_, v_Cursor_89_, v_Choice_90_, v_spec_91_, v_x_92_, v_x_93_);
lean_dec(v_x_92_);
return v_res_94_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_FiniteFold(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
