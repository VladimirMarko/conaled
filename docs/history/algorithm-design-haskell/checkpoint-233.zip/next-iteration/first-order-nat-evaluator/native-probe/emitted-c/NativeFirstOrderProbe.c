// Lean compiler output
// Module: NativeFirstOrderProbe
// Imports: public import Init public meta import Init public import FirstOrderNat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_BitVec_ofNat(lean_object*, lean_object*);
lean_object* l_BitVec_pow(lean_object*, lean_object*, lean_object*);
lean_object* l_BitVec_sub(lean_object*, lean_object*, lean_object*);
lean_object* lean_get_stdout();
lean_object* lean_io_mono_nanos_now();
lean_object* l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_IO_FS_Stream_putStrLn(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0;
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___boxed(lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "expected exactly one argument: 8, 10, or 12"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_ctor_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__0_value)}};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_string_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 54, .m_capacity = 54, .m_length = 53, .m_data = "{\"format\":\"adwh-native-first-order-nat-count-v1\",\"n\":"};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_string_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"count\":"};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_string_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = ",\"formal_evidence\":false}"};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_string_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 55, .m_capacity = 55, .m_length = 54, .m_data = "{\"format\":\"adwh-native-first-order-nat-timing-v1\",\"n\":"};
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_string_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = ",\"elapsed_ns\":"};
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_string_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = ",\"scope\":\"count_format_write_flush\"}"};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_string_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "8"};
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_string_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "10"};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_string_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "12"};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_unsigned_to_nat(2u);
v___x_2_ = lean_unsigned_to_nat(16u);
v___x_3_ = l_BitVec_ofNat(v___x_2_, v___x_1_);
return v___x_3_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1(void){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_unsigned_to_nat(1u);
v___x_5_ = lean_unsigned_to_nat(16u);
v___x_6_ = l_BitVec_ofNat(v___x_5_, v___x_4_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask(lean_object* v_n_7_){
_start:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; 
v___x_8_ = lean_unsigned_to_nat(16u);
v___x_9_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0);
v___x_10_ = l_BitVec_pow(v___x_8_, v___x_9_, v_n_7_);
v___x_11_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1, &l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__1);
v___x_12_ = l_BitVec_sub(v___x_8_, v___x_10_, v___x_11_);
lean_dec(v___x_10_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___boxed(lean_object* v_n_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_13_);
lean_dec(v_n_13_);
return v_res_14_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_27_; lean_object* v___x_28_; 
v___x_27_ = 0;
v___x_28_ = lean_box_uint32(v___x_27_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_29_){
_start:
{
lean_object* v_n_35_; 
if (lean_obj_tag(v_args_29_) == 1)
{
lean_object* v_head_107_; lean_object* v_tail_108_; lean_object* v___x_109_; uint8_t v___x_110_; 
v_head_107_ = lean_ctor_get(v_args_29_, 0);
lean_inc(v_head_107_);
v_tail_108_ = lean_ctor_get(v_args_29_, 1);
lean_inc(v_tail_108_);
lean_dec_ref_known(v_args_29_, 2);
v___x_109_ = ((lean_object*)(l_main___closed__8));
v___x_110_ = lean_string_dec_eq(v_head_107_, v___x_109_);
if (v___x_110_ == 0)
{
lean_object* v___x_111_; uint8_t v___x_112_; 
v___x_111_ = ((lean_object*)(l_main___closed__9));
v___x_112_ = lean_string_dec_eq(v_head_107_, v___x_111_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; uint8_t v___x_114_; 
v___x_113_ = ((lean_object*)(l_main___closed__10));
v___x_114_ = lean_string_dec_eq(v_head_107_, v___x_113_);
lean_dec(v_head_107_);
if (v___x_114_ == 0)
{
lean_dec(v_tail_108_);
goto v___jp_31_;
}
else
{
if (lean_obj_tag(v_tail_108_) == 0)
{
lean_object* v___x_115_; 
v___x_115_ = lean_unsigned_to_nat(12u);
v_n_35_ = v___x_115_;
goto v___jp_34_;
}
else
{
lean_dec(v_tail_108_);
goto v___jp_31_;
}
}
}
else
{
lean_dec(v_head_107_);
if (lean_obj_tag(v_tail_108_) == 0)
{
lean_object* v___x_116_; 
v___x_116_ = lean_unsigned_to_nat(10u);
v_n_35_ = v___x_116_;
goto v___jp_34_;
}
else
{
lean_dec(v_tail_108_);
goto v___jp_31_;
}
}
}
else
{
lean_dec(v_head_107_);
if (lean_obj_tag(v_tail_108_) == 0)
{
lean_object* v___x_117_; 
v___x_117_ = lean_unsigned_to_nat(8u);
v_n_35_ = v___x_117_;
goto v___jp_34_;
}
else
{
lean_dec(v_tail_108_);
goto v___jp_31_;
}
}
}
else
{
lean_dec(v_args_29_);
goto v___jp_31_;
}
v___jp_31_:
{
lean_object* v___x_32_; lean_object* v___x_33_; 
v___x_32_ = ((lean_object*)(l_main___closed__1));
v___x_33_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_33_, 0, v___x_32_);
return v___x_33_;
}
v___jp_34_:
{
lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; 
v___x_36_ = lean_get_stdout();
v___x_37_ = lean_io_mono_nanos_now();
v___x_38_ = lean_unsigned_to_nat(16u);
v___x_39_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_35_);
v___x_40_ = lean_unsigned_to_nat(0u);
v___x_41_ = l_ADWH_Experiments_Chapter15_FirstOrderNat_evaluate(v___x_38_, v___x_39_, v___x_38_, v___x_40_, v___x_40_, v___x_40_);
lean_dec(v___x_39_);
v___x_42_ = ((lean_object*)(l_main___closed__2));
v___x_43_ = l_Nat_reprFast(v_n_35_);
v___x_44_ = lean_string_append(v___x_42_, v___x_43_);
v___x_45_ = ((lean_object*)(l_main___closed__3));
v___x_46_ = lean_string_append(v___x_44_, v___x_45_);
v___x_47_ = l_Nat_reprFast(v___x_41_);
v___x_48_ = lean_string_append(v___x_46_, v___x_47_);
lean_dec_ref(v___x_47_);
v___x_49_ = ((lean_object*)(l_main___closed__4));
v___x_50_ = lean_string_append(v___x_48_, v___x_49_);
lean_inc_ref(v___x_36_);
v___x_51_ = l_IO_FS_Stream_putStrLn(v___x_36_, v___x_50_);
if (lean_obj_tag(v___x_51_) == 0)
{
lean_object* v_flush_52_; lean_object* v___x_53_; 
lean_dec_ref_known(v___x_51_, 1);
v_flush_52_ = lean_ctor_get(v___x_36_, 0);
lean_inc_ref_n(v_flush_52_, 2);
v___x_53_ = lean_apply_1(v_flush_52_, lean_box(0));
if (lean_obj_tag(v___x_53_) == 0)
{
lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; 
lean_dec_ref_known(v___x_53_, 1);
v___x_54_ = lean_io_mono_nanos_now();
v___x_55_ = ((lean_object*)(l_main___closed__5));
v___x_56_ = lean_string_append(v___x_55_, v___x_43_);
lean_dec_ref(v___x_43_);
v___x_57_ = ((lean_object*)(l_main___closed__6));
v___x_58_ = lean_string_append(v___x_56_, v___x_57_);
v___x_59_ = lean_nat_sub(v___x_54_, v___x_37_);
lean_dec(v___x_37_);
lean_dec(v___x_54_);
v___x_60_ = l_Nat_reprFast(v___x_59_);
v___x_61_ = lean_string_append(v___x_58_, v___x_60_);
lean_dec_ref(v___x_60_);
v___x_62_ = ((lean_object*)(l_main___closed__7));
v___x_63_ = lean_string_append(v___x_61_, v___x_62_);
v___x_64_ = l_IO_FS_Stream_putStrLn(v___x_36_, v___x_63_);
if (lean_obj_tag(v___x_64_) == 0)
{
lean_object* v___x_65_; 
lean_dec_ref_known(v___x_64_, 1);
v___x_65_ = lean_apply_1(v_flush_52_, lean_box(0));
if (lean_obj_tag(v___x_65_) == 0)
{
lean_object* v___x_67_; uint8_t v_isShared_68_; uint8_t v_isSharedCheck_73_; 
v_isSharedCheck_73_ = !lean_is_exclusive(v___x_65_);
if (v_isSharedCheck_73_ == 0)
{
lean_object* v_unused_74_; 
v_unused_74_ = lean_ctor_get(v___x_65_, 0);
lean_dec(v_unused_74_);
v___x_67_ = v___x_65_;
v_isShared_68_ = v_isSharedCheck_73_;
goto v_resetjp_66_;
}
else
{
lean_dec(v___x_65_);
v___x_67_ = lean_box(0);
v_isShared_68_ = v_isSharedCheck_73_;
goto v_resetjp_66_;
}
v_resetjp_66_:
{
lean_object* v___x_69_; lean_object* v___x_71_; 
v___x_69_ = l_main___boxed__const__1;
if (v_isShared_68_ == 0)
{
lean_ctor_set(v___x_67_, 0, v___x_69_);
v___x_71_ = v___x_67_;
goto v_reusejp_70_;
}
else
{
lean_object* v_reuseFailAlloc_72_; 
v_reuseFailAlloc_72_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_72_, 0, v___x_69_);
v___x_71_ = v_reuseFailAlloc_72_;
goto v_reusejp_70_;
}
v_reusejp_70_:
{
return v___x_71_;
}
}
}
else
{
lean_object* v_a_75_; lean_object* v___x_77_; uint8_t v_isShared_78_; uint8_t v_isSharedCheck_82_; 
v_a_75_ = lean_ctor_get(v___x_65_, 0);
v_isSharedCheck_82_ = !lean_is_exclusive(v___x_65_);
if (v_isSharedCheck_82_ == 0)
{
v___x_77_ = v___x_65_;
v_isShared_78_ = v_isSharedCheck_82_;
goto v_resetjp_76_;
}
else
{
lean_inc(v_a_75_);
lean_dec(v___x_65_);
v___x_77_ = lean_box(0);
v_isShared_78_ = v_isSharedCheck_82_;
goto v_resetjp_76_;
}
v_resetjp_76_:
{
lean_object* v___x_80_; 
if (v_isShared_78_ == 0)
{
v___x_80_ = v___x_77_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_81_; 
v_reuseFailAlloc_81_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_81_, 0, v_a_75_);
v___x_80_ = v_reuseFailAlloc_81_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
return v___x_80_;
}
}
}
}
else
{
lean_object* v_a_83_; lean_object* v___x_85_; uint8_t v_isShared_86_; uint8_t v_isSharedCheck_90_; 
lean_dec_ref(v_flush_52_);
v_a_83_ = lean_ctor_get(v___x_64_, 0);
v_isSharedCheck_90_ = !lean_is_exclusive(v___x_64_);
if (v_isSharedCheck_90_ == 0)
{
v___x_85_ = v___x_64_;
v_isShared_86_ = v_isSharedCheck_90_;
goto v_resetjp_84_;
}
else
{
lean_inc(v_a_83_);
lean_dec(v___x_64_);
v___x_85_ = lean_box(0);
v_isShared_86_ = v_isSharedCheck_90_;
goto v_resetjp_84_;
}
v_resetjp_84_:
{
lean_object* v___x_88_; 
if (v_isShared_86_ == 0)
{
v___x_88_ = v___x_85_;
goto v_reusejp_87_;
}
else
{
lean_object* v_reuseFailAlloc_89_; 
v_reuseFailAlloc_89_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_89_, 0, v_a_83_);
v___x_88_ = v_reuseFailAlloc_89_;
goto v_reusejp_87_;
}
v_reusejp_87_:
{
return v___x_88_;
}
}
}
}
else
{
lean_object* v_a_91_; lean_object* v___x_93_; uint8_t v_isShared_94_; uint8_t v_isSharedCheck_98_; 
lean_dec_ref(v_flush_52_);
lean_dec_ref(v___x_43_);
lean_dec(v___x_37_);
lean_dec_ref(v___x_36_);
v_a_91_ = lean_ctor_get(v___x_53_, 0);
v_isSharedCheck_98_ = !lean_is_exclusive(v___x_53_);
if (v_isSharedCheck_98_ == 0)
{
v___x_93_ = v___x_53_;
v_isShared_94_ = v_isSharedCheck_98_;
goto v_resetjp_92_;
}
else
{
lean_inc(v_a_91_);
lean_dec(v___x_53_);
v___x_93_ = lean_box(0);
v_isShared_94_ = v_isSharedCheck_98_;
goto v_resetjp_92_;
}
v_resetjp_92_:
{
lean_object* v___x_96_; 
if (v_isShared_94_ == 0)
{
v___x_96_ = v___x_93_;
goto v_reusejp_95_;
}
else
{
lean_object* v_reuseFailAlloc_97_; 
v_reuseFailAlloc_97_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_97_, 0, v_a_91_);
v___x_96_ = v_reuseFailAlloc_97_;
goto v_reusejp_95_;
}
v_reusejp_95_:
{
return v___x_96_;
}
}
}
}
else
{
lean_object* v_a_99_; lean_object* v___x_101_; uint8_t v_isShared_102_; uint8_t v_isSharedCheck_106_; 
lean_dec_ref(v___x_43_);
lean_dec(v___x_37_);
lean_dec_ref(v___x_36_);
v_a_99_ = lean_ctor_get(v___x_51_, 0);
v_isSharedCheck_106_ = !lean_is_exclusive(v___x_51_);
if (v_isSharedCheck_106_ == 0)
{
v___x_101_ = v___x_51_;
v_isShared_102_ = v_isSharedCheck_106_;
goto v_resetjp_100_;
}
else
{
lean_inc(v_a_99_);
lean_dec(v___x_51_);
v___x_101_ = lean_box(0);
v_isShared_102_ = v_isSharedCheck_106_;
goto v_resetjp_100_;
}
v_resetjp_100_:
{
lean_object* v___x_104_; 
if (v_isShared_102_ == 0)
{
v___x_104_ = v___x_101_;
goto v_reusejp_103_;
}
else
{
lean_object* v_reuseFailAlloc_105_; 
v_reuseFailAlloc_105_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_105_, 0, v_a_99_);
v___x_104_ = v_reuseFailAlloc_105_;
goto v_reusejp_103_;
}
v_reusejp_103_:
{
return v___x_104_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_118_, lean_object* v_a_119_){
_start:
{
lean_object* v_res_120_; 
v_res_120_ = _lean_main(v_args_118_);
return v_res_120_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_FirstOrderNat(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_NativeFirstOrderProbe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_FirstOrderNat(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_NativeFirstOrderProbe(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
