# Native diagnostic of the first-order Nat evaluator

## Source and mathematical scope

The candidate is prepared source only; the author has not invoked Lean,
a native compiler, a counter, the generator or the probe runner. Root is
the sole executor. The fixed comparison boundary is exactly 8, 10 and 12,
matching the preceding exact-source native diagnostic. Expected counts are
not inputs to the driver, generator or runner.

The mathematical `FirstOrderNat` helper has already passed its separate
two-module generic gate: eighteen roots, report SHA256
`49ce08dd3eb5560e42504e37b337bee721191edad62d2a124ecfa22db7619a47`.
This new native probe must nevertheless compile all three source modules
freshly: `FiniteFold`, `FirstOrderNat`, and `NativeFirstOrderProbe`. It reuses
no experimental object or previously generated C. The actual-source
adapter is not imported by this diagnostic; its separate proof gate is
not replaced by this native observation.

`FirstOrderNat` is the unchanged generic scalar Nat worker with explicit
depth/fuel and a multiplication-by-two transition proved equal to its
source left shift. It introduces no UInt64 range assumption or new search
algorithm. The proof-side reference functions legitimately contain products
and callbacks. Only the generated call graph reachable from the driver is
relevant to the intended removal of dynamic state/callback overhead.

## Exact original mask and driver correspondence

The only copied project declarations in the new driver are the original
`Word := BitVec 16` and `mask n := (2 : Word)^n - 1`, in their original
namespace. Both are copied byte for byte from the pinned
`QueensBitRepresentation.lean`. No neighboring `State` declaration is
included. The generated record stores source/output byte spans and a full
inverse that reconstructs the original project file exactly. No project
file is modified.

The IO driver is copied from the accepted baseline `NativeNatProbe.lean`
with exactly three substitutions: the evaluated function expression and
the two JSON format identifiers. The new expression is:

```lean
ADWH.Experiments.Chapter15.FirstOrderNat.evaluate 16
  (ADWH.Chapter15.Queens.BitRepresentation.mask n).toNat 16 0 0 0
```

This keeps the exact original Word16 mask, outer depth16 and inner budget16.
The source-adapter wrapper uses that same expression. The driver inverse
reverses the three substitutions and reconstructs the entire baseline
source, including its unchanged prefix. The generator checks both inverse
recoveries. Its `--verify` mode checks text only and invokes no compiler,
counter or retained generator. The author prepared the output by source
slicing/AST-literal checks without importing or running this generator.

Arguments must be exactly one of `['8']`, `['10']`, `['12']`; every other
vector throws an error. The selected input is parsed before timing. The
clock starts before evaluation, and the computed count is formatted,
written and flushed before the end clock. Thus the internal interval is
labelled `count_format_write_flush`, not pure computation time. Whole child
and whole probe resource observations are separate.

The two output lines have these strict schemas:

```text
{"format":"adwh-native-first-order-nat-count-v1","n":N,"count":K,"formal_evidence":false}
{"format":"adwh-native-first-order-nat-timing-v1","n":N,"elapsed_ns":T,"scope":"count_format_write_flush"}
```

N, K and T must be nonnegative JSON integers of the expected roles; Boolean
values cannot substitute for integers. N must equal the fixed invoked
case. The runner requires the exact key sets and no other output, and does
not compare K with an expected answer.

## What this comparison can establish

The native baseline and this candidate have different whole-build source
closures, so whole-probe build time is not an isolated evaluator benchmark.
The two selected implementation transformations are combined; any runtime
difference is not separately attributed to one of them. The same-case
count intervals and the generated hot code are the operational evidence.

Inspect the actual generated mutual recursion for state/continuation
packing, direct calls versus callback dispatch, and the use of native Nat
multiplication in the left transition. Source first-order form does not
prove that well-founded mutual elaboration preserves it. Also inspect the
driver's generated order to confirm the count lies within the reported
clock/output interval. No speedup, allocation frequency, n16 forecast or
numerical theorem is asserted before those observations.

The reported counts remain external native observations. The generic
refinement and the source adapter do not turn them into ordinary Lean proof
terms. The restricted verified checker and any later source numerical
acceptance have their own explicit proof/execution boundary.
