import FirstOrderNat

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Native diagnostic of the proved generic first-order evaluator. The original
Word16 type and mask below are copied exactly. The fixed driver evaluates
only its selected input and includes formatting/output in the timed interval.
This module states no numerical theorem and imports no ADWH object.
-/
namespace ADWH.Chapter15.Queens.BitRepresentation

abbrev Word := BitVec 16

def mask (n : Nat) : Word := (2 : Word) ^ n - 1

end ADWH.Chapter15.Queens.BitRepresentation

/-- Native execution observation only; this declaration proves no count. -/
def main (args : List String) : IO UInt32 := do
  let n : Nat ← match args with
    | ["8"] => pure 8
    | ["10"] => pure 10
    | ["12"] => pure 12
    | _ => throw (IO.userError "expected exactly one argument: 8, 10, or 12")
  let out ← IO.getStdout
  let started ← IO.monoNanosNow
  let value := ADWH.Experiments.Chapter15.FirstOrderNat.evaluate 16
    (ADWH.Chapter15.Queens.BitRepresentation.mask n).toNat 16 0 0 0
  out.putStrLn ("{\"format\":\"adwh-native-first-order-nat-count-v1\",\"n\":" ++ toString n ++
    ",\"count\":" ++ toString value ++ ",\"formal_evidence\":false}")
  out.flush
  let finished ← IO.monoNanosNow
  out.putStrLn ("{\"format\":\"adwh-native-first-order-nat-timing-v1\",\"n\":" ++ toString n ++
    ",\"elapsed_ns\":" ++ toString (finished - started) ++
    ",\"scope\":\"count_format_write_flush\"}")
  out.flush
  return 0
