# Independent source review: first-order native Nat probe

**Passed source-only review; the reviewer did not execute a generator, compiler, counter or gate.** The exact eight source/control inputs are bound in `SOURCE-AUDIT.json`. This reviewer authored neither the candidate nor its generator.

## Source identity and inverse recovery

The two copied project declarations, `Word` and `mask`, preserve their original namespace and exact bytes. Independent span, uniqueness and hash checks passed. The stored inverse reconstructs the whole 10,751-byte representation source exactly, including all omitted material. No adjacent project declaration enters the executable.

The IO driver has exactly three substitutions from the accepted 2,123-byte baseline: the evaluated expression and two JSON format tags. Independently reversing these substitutions recovers the baseline driver and its entire source through the retained prefix. Reassembling the new header, two copies, namespace closure and driver recovers all 1,527 candidate bytes exactly. Every input and fresh-module manifest binding matches current bytes.

The evaluated expression is `FirstOrderNat.evaluate 16 (original mask n).toNat 16 0 0 0`, matching the source-adapter wrapper. Thus original Word16 mask semantics, outer depth16, inner budget16 and the initial three zero masks are preserved. The unchanged generic evaluator combines scalar state arguments and the separately proved multiplication-by-two substitution for a left shift. Their individual runtime effects are not isolated here.

## Execution contract

Only argument vectors `['8']`, `['10']`, `['12']` are accepted. No expected answers occur in executable source or generator inputs. The driver imports only `FirstOrderNat`; its fresh closure is exactly `FiniteFold`, `FirstOrderNat`, and the driver. It imports neither ADWH objects nor the actual-source adapter. Its only source options are the three strict, resource-neutral controls.

The source starts its clock before counting, then formats, writes and flushes the count before its end clock. Its internal interval is correctly labelled `count_format_write_flush`; whole-child measurements have a separate scope. The output uses the computed value and explicitly declares `formal_evidence:false`. No numerical theorem or evaluation command is introduced.

The generator was read and AST-parsed, never imported or invoked. Its actual inputs are four pinned sources and its own bytes, with explicit deterministic slicing and inverse records. Independent checks covered all copied spans, both inverses, entire generated text, fixed arguments, imports/options and absence of implementation overrides.

## Remaining operational evidence

The bounded gate must compile all three modules fresh and retain emitted C. Mutual well-founded source syntax alone does not establish elimination of sum/tuple packing or callback dispatch. Inspect the reachable generated worker call graph and clock/count order before interpreting timings. This review asserts no speedup, allocation frequency, larger-board result or n16 forecast. Generic and source function equivalences do not turn a native numerical observation into an ordinary Lean proof.
