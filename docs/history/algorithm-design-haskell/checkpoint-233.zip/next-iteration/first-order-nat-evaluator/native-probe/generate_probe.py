#!/usr/bin/env python3
"""Prepare source text only; never invoke Lean, a compiler, or a counter."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
REP = 'project/adwh-lean/ADWH/Chapter15/QueensBitRepresentation.lean'
BASELINE = 'next-iteration/native-nat-evaluator-probe/source/NativeNatProbe.lean'
FOLD = 'next-iteration/finite-fold-evaluator/source/FiniteFold.lean'
FIRST = 'next-iteration/first-order-nat-evaluator/source/FirstOrderNat.lean'
PINS = {
    REP: 'eb261d73bd9de53a8dd493a9772fea3a5580bb6f42ba22dabe81dd1c3eacc918',
    BASELINE: 'f03c2e36df29ec44f2d8f8940d48d2d602e3b6af4a46888b95cc1fae324ef238',
    FOLD: '25d84a52adca5f4c60163640aee8f31ded88322b8bd98c27f96d1aeb0c8b5d4e',
    FIRST: 'e453954c94771eddda4d21ce52a7befb07093c9117202f886844a3507a02da1b',
}
TARGET = 'source/NativeFirstOrderProbe.lean'
HEADER = 'import FirstOrderNat\n\nset_option autoImplicit false\nset_option warningAsError true\nset_option Elab.async false\n\n/-!\nNative diagnostic of the proved generic first-order evaluator. The original\nWord16 type and mask below are copied exactly. The fixed driver evaluates\nonly its selected input and includes formatting/output in the timed interval.\nThis module states no numerical theorem and imports no ADWH object.\n-/\nnamespace ADWH.Chapter15.Queens.BitRepresentation\n\n'
DRIVER_MARKER = '/-- Native execution observation only; this declaration proves no count. -/'
DRIVER_REWRITES = [('ADWH.Chapter15.Queens.BitRepresentation.NatCounting.cqueensNat n', 'ADWH.Experiments.Chapter15.FirstOrderNat.evaluate 16\n    (ADWH.Chapter15.Queens.BitRepresentation.mask n).toNat 16 0 0 0'), ('adwh-native-nat-count-v1', 'adwh-native-first-order-nat-count-v1'), ('adwh-native-nat-timing-v1', 'adwh-native-first-order-nat-timing-v1')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(WORK)), 'bytes': len(raw), 'sha256': sha(raw)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def prepare():
    originals = {}
    for name, expected in PINS.items():
        raw = (WORK / name).read_bytes()
        require(sha(raw) == expected, 'Source pin differs: ' + name)
        originals[name] = raw.decode()
    rep, baseline = originals[REP], originals[BASELINE]
    copied = []
    for marker, name in [('abbrev Word :=', 'Word'), ('def mask (', 'mask')]:
        require(rep.count(marker) == 1, 'Copy marker is not unique: ' + name)
        start = rep.index(marker)
        stop = rep.index('\n', start) + 1
        text = rep[start:stop]
        copied.append({'name': 'ADWH.Chapter15.Queens.BitRepresentation.' + name,
                       'source_path': REP, 'source_utf8_span': [len(rep[:start].encode()), len(rep[:stop].encode())],
                       'text': text, 'bytes': len(text.encode()), 'sha256': sha(text.encode())})
    require(baseline.count(DRIVER_MARKER) == 1, 'Baseline driver marker is not unique')
    driver_start = baseline.index(DRIVER_MARKER)
    original_driver = baseline[driver_start:]
    driver = original_driver
    for before, after in DRIVER_REWRITES:
        require(driver.count(before) == 1 and after not in driver, 'Driver rewrite does not match exactly')
        driver = driver.replace(before, after)
    recovered_driver = driver
    for before, after in reversed(DRIVER_REWRITES):
        require(recovered_driver.count(after) == 1, 'Driver inverse is ambiguous')
        recovered_driver = recovered_driver.replace(after, before)
    require(recovered_driver == original_driver, 'Driver inverse failed')
    result = HEADER + '\n'.join(row['text'] for row in copied)
    result += '\nend ADWH.Chapter15.Queens.BitRepresentation\n\n' + driver
    encoded = result.encode()
    for row in copied:
        data = row.pop('text').encode()
        require(encoded.count(data) == 1, 'Copied declaration occurs more than once')
        a = encoded.index(data);row['generated_utf8_span'] = [a, a + len(data)]
    cursor, parts, recovered = 0, [], b''
    raw = rep.encode()
    for row in copied:
        a, b = row['source_utf8_span'];c, d = row['generated_utf8_span']
        parts.extend([{'literal_utf8': raw[cursor:a].decode()}, {'copied_declaration': row['name']}])
        recovered += raw[cursor:a] + encoded[c:d];cursor = b
    parts.append({'literal_utf8': raw[cursor:].decode()});recovered += raw[cursor:]
    require(recovered == raw, 'Original Word source inverse failed')
    manifest = {
        'format': 'adwh-native-first-order-source-v1',
        'status': 'prepared_source_only_not_executed',
        'inputs': [binding(WORK / name) for name in PINS] + [binding(Path(__file__).resolve())],
        'source': {'path': str((HERE / TARGET).relative_to(WORK)), 'bytes': len(encoded), 'sha256': sha(encoded)},
        'imports': ['FirstOrderNat'], 'resource_options': {},
        'fresh_modules': [
            {'module': 'FiniteFold', 'imports': ['Init'], **binding(WORK / FOLD)},
            {'module': 'FirstOrderNat', 'imports': ['FiniteFold'], **binding(WORK / FIRST)},
            {'module': 'NativeFirstOrderProbe', 'imports': ['FirstOrderNat'],
             'path': str((HERE / TARGET).relative_to(WORK)), 'bytes': len(encoded), 'sha256': sha(encoded)}],
        'copied_declarations': copied,
        'word_source_inverse': {'original_path': REP, 'segments': parts,
                                'reconstructed_bytes': len(recovered), 'reconstructed_sha256': sha(recovered)},
        'baseline_driver_inverse': {'original_path': BASELINE,
            'original_prefix_utf8': baseline[:driver_start],
            'driver_marker': DRIVER_MARKER,
            'rewrites': [{'before': a, 'after': b} for a, b in DRIVER_REWRITES],
            'reconstructed_bytes': len(baseline.encode()), 'reconstructed_sha256': sha(baseline.encode())},
        'driver': {'allowed_argument_vectors': [['8'], ['10'], ['12']],
            'expected_answers_are_inputs': False,
            'original_word_mask_and_depth_and_budget_preserved': True,
            'count_format': 'adwh-native-first-order-nat-count-v1',
            'timing_format': 'adwh-native-first-order-nat-timing-v1',
            'timing_scope': 'count_format_write_flush'},
        'candidate_transformations': ['scalar-state first-order mutual recursion',
                                      'left shift by one replaced by universally equal Nat multiplication by two'],
        'mathematical_count_proved': False,
        'all_three_source_modules_must_be_freshly_compiled': True,
        'source_adapter_imported': False,
    }
    return {TARGET: result}, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    outputs, manifest = prepare()
    rendered = json.dumps(manifest, indent=2, sort_keys=True) + '\n'
    outputs['generation.json'] = rendered
    for relative, text in outputs.items():
        path = HERE / relative
        if args.verify:
            require(path.is_file() and path.read_text() == text, 'Generated file differs: ' + relative)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text)
    print(json.dumps({'status': 'verified_source_only' if args.verify else 'prepared_source_only',
                      'compiler_or_counter_executed': False, 'source': manifest['source']}, sort_keys=True))


if __name__ == '__main__':
    main()
