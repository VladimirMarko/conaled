# Independent gate review — first-order native probe

Reviewer and sole planned executor: root. Source/generator/runner author:
counting_route. Independent source/inverse reviewer: regression_audit.
No execution blocker was found. This review predates preflight and execution;
it is not an outcome or a numerical theorem.

I read the complete runner/protocol, source, generator and independent source
review, and compared the runner with the completed exact-source native baseline.
I independently checked all eighteen input-manifest role/size/hash records,
the exact source closure and the new failure-reporting guards. The generator
and runner were parsed as Python syntax, without importing or executing them.

## Frozen inputs

| File | Bytes | SHA256 |
|---|---:|---|
| `gate/run_probe.py` | 23,073 | `a16bf6e78cdba67ec534fbb3c1c281e309922abceb5f113374e519f737188815` |
| `gate/PROTOCOL.md` | 6,956 | `8d3a0685baf6ac6c2dde4abb81657bc5ba0b3701536def64dbb5424f4c348f8d` |
| `gate/input-manifest.json` | 4,611 | `f03b78f148ec059defae45f807291563b26bf225291ba52a81a4bf207a19cf03` |
| `source/NativeFirstOrderProbe.lean` | 1,527 | `a54e89a58d9d1a87a96606b76ed8aafa0310fa7874ac5f764037a025a4660c03` |
| `SOURCE-REVIEW.md` | 3,210 | `0ad4e7b56e429fbba0249da67aba2cb46aca7242b3ea7b50883a2c22884d39a5` |
| `SOURCE-AUDIT.json` | 3,809 | `d6d67e52a1f5ed50639a13037f40173c0af93b3aaebfd994137df42dfac3786a` |

## Checked boundary

Three Lean modules are compiled freshly to C and ordinary objects: FiniteFold,
FirstOrderNat and the driver. The first two must report their exact nine roots
each; the driver must emit no diagnostic. One native link and the fixed8/10/12
cases complete seven commands under one30-second deadline. The accepted generic
report is the actual49ce08dd… report with matching source bindings, not a report
under a substituted role. It provides provenance; all eighteen reports are
freshly required again during C generation. No ADWH/experimental object is
reused and no retained C file supplies the build.

The independent inverse check preserves the exact original Word16 mask and
reverses precisely the driver expression and two format tags. Input/depth/budget
semantics match the checked source adapter. No expected count is an input or
output acceptance criterion. The strict two-record native schema reports
formal_evidence=false and count_format_write_flush, with actual integer values.

All nineteen source/control inputs are snapshotted read-only. The native runtime
inventory must exactly match the completed baseline's compiler, linker, headers
and static/shared libraries. The runner uses the same explicit loader/sysroot
setup, clean compiler search environment and pinned resource helper. It checks
/proc before reserving the attempt, obtains the shared compile lock, and reserves
an exclusive permanent source-keyed marker before any command. It does not
allow deletion, relabelling, budget overrides or unchanged repetition.

OneCPU/thread, oneGiB observed RSS, Lean -M1024 and default heartbeat/recursion
limits are unchanged. All children receive the remaining shared deadline; the
final limit check includes source/runtime/log/marker/artifact postchecks. Exact
success requires seven zero-exit bounded commands, eighteen accepted roots,
three strict diagnostic records, nineteen intact snapshots and exactly ten
build artifacts. Failure retains logs, marker, snapshots and partial expected
artifacts. Affinity restoration failure is now explicitly recorded before the
final report is saved. No hidden resource or code-generation exemption appears.

The remaining questions are empirical: whether mutual compilation preserves
scalar calls, whether closure/state packing disappears from the reachable hot
workers, and what same-input timings are observed. Generated-code inspection
and raw timings are needed; source syntax is not an allocation or speedup proof.
The native result cannot by itself fill a stock-kernel numeral theorem.
