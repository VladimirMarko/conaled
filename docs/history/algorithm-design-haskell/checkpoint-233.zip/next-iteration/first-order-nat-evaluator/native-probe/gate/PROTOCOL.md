# One fresh native diagnostic of the first-order evaluator

## Fixed scope and command

Root runs one source-keyed attempt under the unchanged one-CPU,
30-cumulative-second, 1,048,576-KiB RSS boundary. It freshly generates C and
ordinary Lean objects for `FiniteFold`, `FirstOrderNat` and
`NativeFirstOrderProbe`, links those three C files, then invokes exactly
the fixed 8, 10 and 12 cases. No ADWH or experimental object is reused.
There are seven child commands under one deadline, not seven separate
allowances. Default Lean heartbeat/recursion limits remain unchanged.

From this gate directory, after independent source/gate review:

```sh
python3 -I run_probe.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux
python3 -I run_probe.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux --run
```

The first mode only reads and validates source/control/runtime metadata.
Only `--run` invokes the compiler or native program. The author has invoked
neither mode and has only AST-parsed the prepared Python source. No source
generator is run by preflight or execution.

The attempt path is fixed at `attempts/native-01`; the permanent marker is
`execution-markers/native-<source-fingerprint>.json`. Both must be absent.
The fingerprint binds all three ordered source hashes, generator identity,
fixed cases, compiler options and complete budget. It excludes mutable
attempt names and review prose. The existing project compile lock is taken
nonblockingly, and the marker is exclusively reserved read-only before any
child command. Failure preserves the attempt and marker. No deletion,
overwrite, budget override or unchanged retry option exists.

## Mathematical and source crosslinks

The manifest binds eighteen explicit inputs plus itself: runner, protocol,
resource helper, toolchain pin, source generator, generation record, source
contract, three selected Lean sources, original Word/mask source, baseline
driver source, independent source review/audit, actual accepted generic
report, original project verification report, baseline native report and
baseline runner. All nineteen are snapshotted read-only before execution.

The generation record must bind exactly its five actual inputs and the
three selected source modules/imports. The independent source audit must
bind its exact eight reviewed inputs, both copied declarations, the driver
inverse and the complete generated source. The only baseline IO changes
are the evaluated expression and two format tags, as disclosed in
`SOURCE-CONTRACT.md`. No expected count is supplied to the program or used
by the output validator.

The actual prior generic report must report eighteen accepted roots, both
fresh modules and unchanged inputs. Its source hashes must equal the
selected `FiniteFold` and `FirstOrderNat` files. This acceptance report is
explicitly identified and snapshotted; it is not a baseline report placed
under a generic-report role. Nevertheless this probe recompiles those
modules and requires all eighteen reports again during C generation.

The original project report binds the copied Word16 definition/mask. The
prior native report fixes the comparison cases and complete compiler,
linker, header and static/shared-library bytes. These provenance reports
are not numerical premises. The actual-source adapter is not imported or
claimed checked here.

## Commands, runtime and resources

Each Lean command uses the exact pinned binary with `-j1 -M1024`, strict
source options, and explicit fresh `-o`, `-i` and `-c` destinations. Its
working directory is the snapshotted source's directory. `LEAN_PATH` is
only the fresh build directory, so later modules resolve just-created
objects. The native command is the pinned `leanc -O3 -Werror` over all three
fresh C files with one explicit executable destination. It runs from the
fresh build directory, as do the three case processes.

The unchanged `lean435-kernel-comparison/run_comparison.py` helper
(SHA256 `2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0`)
supplies `h.child`. It enforces process-group isolation, one selected CPU,
remaining shared deadline, descendant aggregate RSS sampling and exit
high-water checks. Lean gets 1,024 MiB internal memory. The report does not
describe sampled RSS as an address-space limit. The final cumulative check
includes command-result audits and post-execution identity/artifact checks.

The environment retains the previously successful native setup explicitly:
`LEAN_SYSROOT` is the selected pinned toolchain, and `LD_LIBRARY_PATH` is
its `lib/lean` then `lib`. The pinned `bin` directory is first in `PATH`.
Lean/Lake/comparator, compiler flags/search paths, Python, cache and loader
injection overrides are removed; relevant thread counts are one.
`LEAN_ABORT_ON_PANIC=1` is fixed. The whole compiler/header/library inventory
must match the accepted native baseline by relative path, bytes and hash,
and is checked again after execution. Required `/proc` visibility and
loader access are the same environment requirements as the baseline;
neither changes the CPU, time or RSS budget.

## Output and acceptance

The first two Lean commands must emit exactly their nine fully qualified
axiom reports, in order, with only `propext`, `Quot.sound` or
`Classical.choice`. Every raw occurrence is retained. The driver has zero
roots and must emit no diagnostic text. All compiler stderr must be empty;
native compiler stdout must also be empty. Every command needs zero exit
and no resource event before its successor is started.

Each native case must print exactly the two JSON lines from the source
contract, with exact key sets and tags, strict integer fields, the invoked
input, a nonnegative count/time and `formal_evidence:false`. The internal
scope includes count formatting, writing and flushing. Counts are observed
without comparing them with expected answers. Inspect the emitted driver
before interpreting the internal interval, and inspect the reachable
mutual-worker code before claiming allocation removal.

Success means all seven commands completed within the shared limits, all
three diagnostics were retained, all eighteen fresh theorem reports were
accepted, all nineteen source/control snapshots and the marker are intact,
and the build contains exactly the nine `.c`/`.olean`/`.ilean` files plus
the executable. Every artifact, log, source, control and runtime binding is
postchecked. Partial expected artifacts are captured after failure as well.
The report is saved before execution and after each child/result audit.

The status is `completed_within_limits`, never a numerical theorem result.
`mathematical_count_proved` and `kernel_extension_implemented` remain false.
The comparison does not isolate the two combined source transformations,
and its extra fresh proof modules make whole-build time different from the
one-module baseline. No larger case or native16 invocation is included.
