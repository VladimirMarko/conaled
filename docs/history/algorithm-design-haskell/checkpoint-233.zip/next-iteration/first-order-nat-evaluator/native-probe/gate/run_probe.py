#!/usr/bin/env python3
"""Fresh first-order Nat native diagnostic; no numerical theorem is certified."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
WORK = CANDIDATE.parents[2]
HELPER = WORK / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
HELPER_SHA = '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0'
PIN = WORK / 'next-iteration/lean435-migration/toolchain.json'
PIN_SHA = 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c'
LOCK = WORK / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
CASES = [8, 10, 12]
FORMAT = 'adwh-first-order-native-nat-probe-v1'
MODULES = ['FiniteFold', 'FirstOrderNat', 'NativeFirstOrderProbe']
MODULE_ROLES = ['finite_fold_source', 'first_order_source', 'source']
RAW_ROOTS = {
    'FiniteFold': ['loop_zero', 'loop_succ', 'fold_zero', 'fold_succ', 'canonical_equations',
        'loop_unique_of_equations', 'fold_unique_of_equations', 'branches_unique_of_equations',
        'implementations_agree'],
    'FirstOrderNat': ['shiftLeft_one', 'count_zero', 'count_succ', 'branches_zero',
        'branches_succ', 'equations', 'count_eq_fold', 'branches_eq_loop', 'evaluate_eq_fold'],
    'NativeFirstOrderProbe': [],
}
ROOTS = {module: ['ADWH.Experiments.Chapter15.' + module + '.' + root for root in RAW_ROOTS[module]]
         for module in MODULES}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and path.stat().st_size == row['bytes']
                  and sha(path) == row['sha256'], 'Changed input: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot or marker: ' + str(path))


def preflight(toolchain, h):
    h.require(sha(PIN) == PIN_SHA, 'The historical toolchain pin changed')
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    pin = read(PIN)
    h.require(pin['version'] == '4.35.0'
              and pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc', 'Toolchain revision differs')
    manifest_path = HERE / 'input-manifest.json'
    manifest = read(manifest_path)
    h.require(manifest['format'] == 'adwh-first-order-native-probe-inputs-v1'
              and manifest['cases'] == CASES and manifest['module_order'] == MODULES,
              'Input manifest scope differs')
    inputs = []
    for row in manifest['inputs']:
        path = (WORK / row['path']).resolve()
        h.require(path.is_relative_to(WORK) and path.is_file() and not path.is_symlink(),
                  'Input must be an ordinary file inside work')
        actual = h.binding(path)
        h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']), 'Manifest binding differs: ' + str(path))
        inputs.append({**actual, 'relative_path': path.relative_to(WORK).as_posix(), 'role': row['role']})
    inputs.append({**h.binding(manifest_path), 'relative_path': manifest_path.relative_to(WORK).as_posix(),
                   'role': 'input_manifest'})
    h.require(len(inputs) == 19 and len({r['path'] for r in inputs}) == len(inputs), 'Input count or identity differs')
    roles = {row['role']: row for row in inputs}
    expected_roles = {'runner', 'protocol', 'resource_helper', 'toolchain_pin', 'source_generator',
        'generation_record', 'source_contract', 'source', 'finite_fold_source', 'first_order_source',
        'word_source', 'baseline_source', 'source_review', 'source_audit', 'accepted_generic_report',
        'accepted_project_report', 'baseline_native_report', 'baseline_runner', 'input_manifest'}
    h.require(set(roles) == expected_roles and len(roles) == len(inputs), 'Input roles differ')
    h.require(roles['runner']['path'] == str(Path(__file__).resolve())
              and roles['protocol']['path'] == str(HERE / 'PROTOCOL.md')
              and roles['resource_helper']['path'] == str(HELPER)
              and roles['resource_helper']['sha256'] == HELPER_SHA
              and roles['toolchain_pin']['path'] == str(PIN)
              and roles['toolchain_pin']['sha256'] == PIN_SHA, 'Mandatory control missing')
    def identity(row):
        return {'path': row['relative_path'], 'bytes': row['bytes'], 'sha256': row['sha256']}
    generation = read(Path(roles['generation_record']['path']))
    h.require(generation['format'] == 'adwh-native-first-order-source-v1'
              and generation['source'] == identity(roles['source'])
              and generation['imports'] == ['FirstOrderNat'] and generation['resource_options'] == {}
              and generation['driver']['allowed_argument_vectors'] == [[str(n)] for n in CASES]
              and generation['driver']['expected_answers_are_inputs'] is False
              and generation['source_adapter_imported'] is False,
              'Generation record describes a different program')
    generated_inputs = ['word_source', 'baseline_source', 'finite_fold_source', 'first_order_source', 'source_generator']
    h.require(generation['inputs'] == [identity(roles[k]) for k in generated_inputs],
              'Generator inputs differ')
    selected = [{**identity(roles[role]), 'module': module,
                 'imports': ['Init'] if module == 'FiniteFold' else [MODULES[index - 1]]}
                for index, (module, role) in enumerate(zip(MODULES, MODULE_ROLES))]
    h.require(generation['fresh_modules'] == selected, 'Fresh module closure differs')
    expected_paths = [WORK / 'next-iteration/finite-fold-evaluator/source/FiniteFold.lean',
                      CANDIDATE.parent / 'source/FirstOrderNat.lean',
                      CANDIDATE / 'source/NativeFirstOrderProbe.lean']
    for row, expected in zip(selected, expected_paths):
        h.require((WORK / row['path']).resolve() == expected.resolve(), 'Different mathematical source selected')
        text = expected.read_text()
        h.require(re.findall(r'^import (\S+)$', text, re.M) == row['imports'], 'Source import differs')
        h.require(re.findall(r'^#print axioms (\S+)$', text, re.M) == RAW_ROOTS[row['module']], 'Source roots differ')
        h.require(not re.search(r'\b(sorry|admit|axiom|unsafe|partial|implemented_by|native_decide)\b', text),
                  'Forbidden source mechanism')
        h.require(not re.search(r'set_option\s+(maxRecDepth|maxHeartbeats|maxMemory|debug\.|compiler\.)', text),
                  'Resource/compiler override in source')
    source_audit = read(Path(roles['source_audit']['path']))
    reviewed = ['source_generator', 'source', 'generation_record', 'source_contract',
                'word_source', 'baseline_source', 'finite_fold_source', 'first_order_source']
    h.require(source_audit['format'] == 'adwh-native-first-order-independent-source-audit-v1'
              and source_audit['status'] == 'passed_source_only_review_execution_not_run'
              and source_audit['copied_declaration_count'] == len(generation['copied_declarations']) == 2
              and source_audit['all_copied_blocks_driver_inverse_and_full_source_match'] is True
              and source_audit['expected_counts_present_in_executable_source'] is False
              and source_audit['fixed_argument_vectors'] == [[str(n)] for n in CASES]
              and len(source_audit['bound_inputs']) == len(reviewed)
              and {r['path']: r for r in source_audit['bound_inputs']} ==
              {roles[k]['relative_path']: identity(roles[k]) for k in reviewed},
              'Independent source audit does not bind this program')
    accepted = read(Path(roles['accepted_generic_report']['path']))
    h.require(accepted['format'] == 'adwh-first-order-nat-generic-gate-v1'
              and accepted['status'] == 'passed' and accepted['module_order'] == MODULES[:2]
              and accepted['accepted_axiom_report_count'] == 18
              and accepted['all_selected_mathematical_sources_freshly_checked'] is True
              and accepted['all_sources_snapshots_controls_runtime_unchanged'] is True
              and accepted['source_adapter_checked'] is False, 'The actual generic proof is not accepted')
    h.require([(r['module'], r['bytes'], r['sha256']) for r in accepted['source_bindings']] ==
              [(r['module'], r['bytes'], r['sha256']) for r in selected[:2]],
              'Generic report does not bind the selected helper sources')
    project = read(Path(roles['accepted_project_report']['path']))
    h.require(project['status'] == 'passed' and project['run_id'] == '6e376337ca5b4b34a679cd9588e3bfc1',
              'Original project source gate differs')
    h.require({r['path']: r['sha256'] for r in project['files']}['ADWH/Chapter15/QueensBitRepresentation.lean']
              == roles['word_source']['sha256'], 'Word/mask source not bound by accepted project')
    baseline = read(Path(roles['baseline_native_report']['path']))
    h.require(baseline['format'] == 'adwh-exact-native-nat-probe-v1'
              and baseline['status'] == 'completed_within_limits' and baseline['cases'] == CASES,
              'Baseline native boundary differs')
    toolchain = toolchain.resolve()
    runtime_paths = [toolchain / 'bin' / name for name in ['lean', 'leanc', 'clang', 'ld.lld']]
    runtime_paths.extend(path.resolve() for path in (toolchain / 'include/lean').rglob('*') if path.is_file())
    for directory in [toolchain / 'lib', toolchain / 'lib/lean']:
        runtime_paths.extend(path.resolve() for path in directory.iterdir()
            if path.is_file() and not path.name.startswith('.') and (path.suffix == '.a' or '.so' in path.name))
    runtime = [h.binding(path) for path in sorted(set(runtime_paths))]
    previous_toolchain = Path(baseline['toolchain'])
    expected_runtime = {str(Path(r['path']).relative_to(previous_toolchain)): (r['bytes'], r['sha256'])
                        for r in baseline['runtime']}
    h.require({str(Path(r['path']).relative_to(toolchain)): (r['bytes'], r['sha256']) for r in runtime}
              == expected_runtime, 'Native compiler/header/library bytes differ from the pinned baseline')
    lean = next(row for row in runtime if row['path'] == str(toolchain / 'bin/lean'))
    h.require(all(lean[k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']), 'Compiler differs')
    program_identity = {'format': FORMAT,
        'sources': [{'module': r['module'], 'sha256': r['sha256']} for r in selected],
        'generator_sha256': roles['source_generator']['sha256'], 'cases': CASES,
        'lean_options': ['-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true', '-DElab.async=false'],
        'native_options': ['-O3', '-Werror'], 'complete_budget_seconds': 30}
    fingerprint = hashlib.sha256(json.dumps(program_identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    verify(inputs + runtime, h)
    return {'inputs': inputs, 'runtime': runtime, 'source_identity': program_identity,
            'source_fingerprint': fingerprint, 'toolchain': str(toolchain),
            'source_modules': selected, 'cases': CASES,
            'actual_accepted_generic_report': identity(roles['accepted_generic_report'])}


def audit_axioms(module, row, h):
    out = Path(row['stdout']['path']).read_text()
    err = Path(row['stderr']['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out)]
    h.require(not err and not pattern.sub('', out).strip()
              and [r['root'] for r in raw] == ROOTS[module]
              and all(set(r['axioms']) <= ALLOWED for r in raw), 'Fresh module axioms/diagnostics differ: ' + module)
    return {'required_roots': ROOTS[module], 'raw_reports': raw, 'accepted_count': len(raw)}


def audit_native_output(row, n, h):
    out = Path(row['stdout']['path']).read_text()
    err = Path(row['stderr']['path']).read_text()
    h.require(not err and len(out.splitlines()) == 2, 'Unexpected native output')
    count, timing = [json.loads(line, object_pairs_hook=h.strict_object) for line in out.splitlines()]
    h.require(set(count) == {'format', 'n', 'count', 'formal_evidence'}
              and count['format'] == 'adwh-native-first-order-nat-count-v1'
              and type(count['n']) is int and count['n'] == n
              and type(count['count']) is int and count['count'] >= 0
              and count['formal_evidence'] is False, 'Malformed count diagnostic')
    h.require(set(timing) == {'format', 'n', 'elapsed_ns', 'scope'}
              and timing['format'] == 'adwh-native-first-order-nat-timing-v1'
              and type(timing['n']) is int and timing['n'] == n
              and type(timing['elapsed_ns']) is int and timing['elapsed_ns'] >= 0
              and timing['scope'] == 'count_format_write_flush', 'Malformed timing diagnostic')
    return {'count': count, 'timing': timing, 'mathematical_acceptance': False}


def run(plan, h):
    attempt = HERE / 'attempts/native-01'
    marker = HERE / 'execution-markers' / ('native-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Attempt or source marker already exists')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    attempt.mkdir(parents=True)
    build = attempt / 'build'
    build.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', **plan, 'snapshots': [], 'commands': [],
              'execution_marker': None, 'artifacts': [], 'diagnostics': [], 'axiom_audits': [],
              'required_fresh_axiom_report_count': 18, 'accepted_fresh_axiom_report_count': 0,
              'limits': {'cumulative_seconds': 30, 'cpu_count': 1, 'rss_kib': 1048576},
              'inputs_and_outputs_postchecked': False,
              'mathematical_count_proved': False, 'kernel_extension_implemented': False,
              'scope': 'Three fresh source/C compilations, one native link and three fixed external diagnostic executions.'}
    h.save(report_path, report)
    cpus = os.sched_getaffinity(0)
    began = None
    try:
        for row in plan['inputs']:
            target = attempt / 'inputs' / row['relative_path']
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            target.chmod(0o444)
            frozen = h.binding(target)
            h.require(all(frozen[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot differs')
            report['snapshots'].append({**frozen, 'original_path': row['path'], 'role': row['role']})
        verify(plan['inputs'] + plan['runtime'], h)
        verify(report['snapshots'], h, readonly=True)
        marker.parent.mkdir(parents=True, exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': str(attempt), **plan}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(cpus)
        os.sched_setaffinity(0, {cpu})
        toolchain = Path(plan['toolchain'])
        env = {k: v for k, v in os.environ.items()
               if not k.startswith(('LEAN_', 'LAKE_', 'COMPARATOR_', 'PYTHON', 'CCACHE_', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS'))
               and k not in {'LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'CC', 'CXX', 'CXXFLAGS',
                             'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH',
                             'COMPILER_PATH', 'GCC_EXEC_PREFIX'}}
        env.update(LEAN_PATH=str(build), LEAN_NUM_THREADS='1', LEAN_ABORT_ON_PANIC='1',
                   LEAN_SYSROOT=str(toolchain),
                   LD_LIBRARY_PATH=str(toolchain / 'lib/lean') + ':' + str(toolchain / 'lib'),
                   OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        env['PATH'] = str(toolchain / 'bin') + os.pathsep + env.get('PATH', '')
        executable = build / 'native-first-order-probe'
        commands = []
        for module in plan['source_modules']:
            name = module['module']
            source = attempt / 'inputs' / module['path']
            commands.append(('lean-' + name, [str(toolchain / 'bin/lean'),
                *plan['source_identity']['lean_options'], '-o', str(build / (name + '.olean')),
                '-i', str(build / (name + '.ilean')), '-c', str(build / (name + '.c')), str(source)], source.parent))
        commands.append(('native-compilation', [str(toolchain / 'bin/leanc'),
            *plan['source_identity']['native_options'], *[str(build / (name + '.c')) for name in MODULES],
            '-o', str(executable)], build))
        commands.extend(('native-n' + str(n), [str(executable), str(n)], build) for n in CASES)
        report.update(status='running', cpu=cpu, declared_environment={key: env[key] for key in
            ['LEAN_PATH', 'LEAN_NUM_THREADS', 'LEAN_ABORT_ON_PANIC', 'LEAN_SYSROOT', 'LD_LIBRARY_PATH',
             'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']})
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for index, (label, command, cwd) in enumerate(commands):
            result = h.child(command, cwd, env, attempt / (label + '.stdout.log'),
                             attempt / (label + '.stderr.log'), cpu, deadline)
            report['commands'].append({'label': label, 'cwd': str(cwd), **result})
            h.save(report_path, report)
            h.require(result['exit_code'] == 0 and result['within_limits'], 'Child failed: ' + label)
            if index < 3:
                audit = audit_axioms(MODULES[index], result, h)
                report['axiom_audits'].append({'module': MODULES[index], **audit})
                report['accepted_fresh_axiom_report_count'] += audit['accepted_count']
                for suffix in ['.c', '.olean', '.ilean']:
                    report['artifacts'].append(h.binding(build / (MODULES[index] + suffix)))
            elif index == 3:
                h.require(not Path(result['stdout']['path']).read_text()
                          and not Path(result['stderr']['path']).read_text(), 'Native compiler emitted diagnostics')
                report['artifacts'].append(h.binding(executable))
            else:
                report['diagnostics'].append(audit_native_output(result, CASES[index - 4], h))
            h.save(report_path, report)
        h.require(report['accepted_fresh_axiom_report_count'] == 18, 'Incomplete fresh proof reports')
        h.require(len(report['diagnostics']) == 3, 'Incomplete fixed diagnostic list')
        report['status'] = 'completed_within_limits'
    except BaseException as exc:
        report.update(status='failed', failure={'type': type(exc).__name__, 'message': str(exc)})
    finally:
        captured = {row['path'] for row in report['artifacts']}
        for name in [module + suffix for module in MODULES for suffix in ['.c', '.olean', '.ilean']] + ['native-first-order-probe']:
            artifact = build / name
            if artifact.is_file() and str(artifact.resolve()) not in captured:
                report['artifacts'].append({**h.binding(artifact), 'captured_after_failure': True})
        try:
            verify(plan['inputs'] + plan['runtime'] + report['artifacts'], h)
            verify(report['snapshots'], h, readonly=True)
            verify([r[k] for r in report['commands'] for k in ['stdout', 'stderr']], h)
            h.require(len(report['snapshots']) == len(plan['inputs']), 'Incomplete snapshots')
            h.require(report['execution_marker'] is not None, 'No reserved execution marker')
            verify([report['execution_marker']], h, readonly=True)
            if report['status'] == 'completed_within_limits':
                expected_artifacts = {str(build / (module + suffix)) for module in MODULES
                                      for suffix in ['.c', '.olean', '.ilean']} | {str(build / 'native-first-order-probe')}
                h.require({str(p) for p in build.rglob('*') if p.is_file()} == expected_artifacts,
                          'Unexpected fresh build artifact inventory')
                h.require(len(report['commands']) == 7 and len(report['diagnostics']) == 3, 'Incomplete commands')
            report['inputs_and_outputs_postchecked'] = True
        except BaseException as exc:
            report.update(status='failed', postcheck_failure={'type': type(exc).__name__, 'message': str(exc)})
        report['cumulative_execution_seconds'] = None if began is None else time.monotonic() - began
        report['peak_rss_kib'] = max((r['sampled_tree_and_wait4_peak_rss_kib'] for r in report['commands']), default=0)
        if began is not None and report['cumulative_execution_seconds'] > 30:
            report.update(status='failed', cumulative_limit_exceeded=True)
        try:
            os.sched_setaffinity(0, cpus)
        except BaseException as exc:
            report.update(status='failed', affinity_restore_failure={'type': type(exc).__name__, 'message': str(exc)})
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
        'seconds': report['cumulative_execution_seconds'], 'peak_rss_kib': report['peak_rss_kib'],
        'diagnostics': report['diagnostics'], 'mathematical_count_proved': False}, sort_keys=True))
    return 0 if report['status'] == 'completed_within_limits' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain', required=True, type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if sha(HELPER) != HELPER_SHA:
        raise ValueError('Pinned resource helper differs')
    spec = importlib.util.spec_from_file_location('first_order_native_probe_resource', HELPER)
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    h.require(h.MEMORY_KIB == 1048576, 'RSS policy changed')
    plan = preflight(args.toolchain, h)
    if not args.run:
        print(json.dumps({'status': 'source_only_preflight', 'source_fingerprint': plan['source_fingerprint'],
                          'input_count': len(plan['inputs']), 'runtime_count': len(plan['runtime'])}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
