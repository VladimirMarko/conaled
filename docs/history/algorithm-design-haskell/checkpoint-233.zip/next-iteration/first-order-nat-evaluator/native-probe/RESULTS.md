# First-order native diagnostic: saved result

**The first fixed native attempt completed within the unchanged budget.**
All seven commands succeeded: three fresh Lean/C compilations, one native
link and the fixed 8/10/12 executions. Eighteen actual ordinary-kernel axiom
reports were accepted during the fresh helper compilations. Whole-probe
elapsed time was **2.5806708649979555 seconds**, with peak **504020 KiB**.
The immutable raw report is `gate/attempts/native-01/report.json`, 49,087
bytes, SHA256 `82d5140a0fc47199df8f4a5632ffaa4facfb11a0063788f325fdb985eead994f`.

These are external native observations, not numerical Lean theorems. No
n16 case, new kernel reduction or concrete checker acceptance was run by
this diagnostic. Root executed the experiment. `counting_route` audited
its saved report/logs and emitted C; that reviewer also authored the
candidate and runner, while source review came from `regression_audit`
and gate review from root. No execution was repeated during the audit.

## Observed same-case intervals

The internal interval includes count formatting, writing and flushing.
Each entry is one observation from its respective fixed experiment.

| Input | Candidate count | Baseline interval (ns) | Candidate interval (ns) | Baseline / candidate |
| --- | --- | --- | --- | --- |
| 8 | 92 | 248,138 | 96,433 | 2.573 |
| 10 | 724 | 4,427,533 | 1,053,090 | 4.204 |
| 12 | 14200 | 105,247,886 | 21,655,703 | 4.860 |

The n12 interval ratio is approximately **4.86**. This is a comparison of
the combined first-order/multiplication candidate with the preceding exact
source implementation. It does not isolate one transformation's effect,
provide repeated-sample statistics, or forecast n16 performance. The
candidate's whole build checked three fresh modules whereas the baseline
checked one, so their whole-probe times are not an isolated evaluator
comparison. No expected count was a driver or validator input.

## The intended representation change reached emitted C

The exact emitted sources are retained under `emitted-c/`. The saved-result
auditor extracts complete function bodies and checks the direct call graph.

| Function in `FirstOrderNat.c` | Definition line | Direct mathematical calls |
| --- | --- | --- |
| `evaluate` | 325 | `count` |
| `count` | 172 | `branches` |
| `branches` | 117 | `count`, `branches` |

All three selected bodies have no explicit `lean_alloc_ctor`,
`lean_alloc_closure`, `lean_apply_*` or `lean_ctor_get`. Thus the mutual
well-founded definition did compile to direct scalar-argument workers;
it did not reintroduce dynamic state products or callback dispatch in
those bodies. The recursive child transition uses `lean_nat_mul` at
line 143, and the branch sum retains `lean_nat_add`. The old left-shift
call is absent from these workers.

This is a statement about the inspected generated C. It is not a global
allocation profile: Nat runtime primitives retain arbitrary-precision
fallbacks, and I/O necessarily uses other runtime machinery. Later tuple,
closure and callback code in the generated module belongs to the reference
transition/specification wrappers and proof-related splitters. Those
functions are absent from the evaluator's direct recursive call graph.

The driver C calls the start clock at 206, the original mask at 208, and
`evaluate` at 210. It formats the resulting count at 217, writes it at 223,
flushes it at 230, and calls the end clock at 235. The reported internal
scope is therefore consistent with the inspected emitted order; the
whole child wall/CPU observations remain separate from that interval.

## Saved evidence audit and recovery

`audit_saved_result.py` reads only stored evidence. Both full/live and
source-only audit modes passed. Full/live mode checked nineteen inputs,
nineteen read-only snapshots, the marker, fourteen logs, forty-four
runtime bindings and all ten build artifacts. The complete per-module
axiom reports and three JSON diagnostics were reparsed rather than assumed
from summary counters. It also verified the selected command vectors,
working directories, environment, source fingerprint and actual generic
report role. `RESULTS.json` records that live audit;
`SOURCE-ONLY-AUDIT.json` records the source-only mode.

`SNAPSHOT-RECOVERY.json` maps all nineteen duplicate snapshots to exact
retained canonical files and maps the three temporary build C paths to the
byte-identical `emitted-c/` copies. A source-only checkpoint may omit the
six `.olean`/`.ilean` files, executable, duplicate snapshot tree and temporary
build directory. Their original identities remain in the immutable report.
The source-only auditor accepts ordinary ZIP-restored permission bits;
it still requires exact content hashes. Full/live mode retains read-only
snapshot/marker enforcement. Neither mode compiles or executes anything,
and neither may remove or reuse the completed native execution marker.

From the recovered `work/` directory, the read-only recovery check is:

```sh
python3 -I next-iteration/first-order-nat-evaluator/native-probe/audit_saved_result.py --source-only
```

The accepted generic/source refinements remain reusable mathematical
infrastructure. Numerical ordinary-kernel acceptance or an explicitly
reported verified external-checker result still requires its own complete
proof/execution boundary; this timing diagnostic supplies neither by itself.
