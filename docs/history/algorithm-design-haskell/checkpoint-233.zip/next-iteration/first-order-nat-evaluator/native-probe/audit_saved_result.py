#!/usr/bin/env python3
"""Audit fixed saved evidence only; never run a compiler, generator or program."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
ATTEMPT = HERE / 'gate/attempts/native-01'
REPORT = ATTEMPT / 'report.json'
REPORT_SHA = '82d5140a0fc47199df8f4a5632ffaa4facfb11a0063788f325fdb985eead994f'
FORMAT = 'adwh-first-order-native-nat-probe-v1'
MODULES = ['FiniteFold', 'FirstOrderNat', 'NativeFirstOrderProbe']
CASES = [8, 10, 12]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def strict_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'Duplicate JSON key: ' + key)
        value[key] = item
    return value


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': str(path.relative_to(WORK)), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def function_body(text, name):
    match = re.search(r'^LEAN_EXPORT lean_object\* ' + re.escape(name) + r'\([^;\n]*\)\{', text, re.M)
    require(match is not None, 'Missing emitted function: ' + name)
    opening = text.index('{', match.start())
    depth, cursor = 1, opening + 1
    # The selected bodies contain no braces in literals or comments.
    while depth:
        require(cursor < len(text), 'Unclosed emitted function')
        depth += (text[cursor] == '{') - (text[cursor] == '}')
        cursor += 1
    return text[opening + 1:cursor - 1], text.count('\n', 0, match.start()) + 1


def audit(source_only=False):
    require(REPORT.stat().st_size == 49087 and sha(REPORT) == REPORT_SHA, 'Different saved report')
    r = read(REPORT)
    require(r['format'] == FORMAT and r['status'] == 'completed_within_limits'
            and r['cases'] == CASES and r['inputs_and_outputs_postchecked'] is True, 'Completion/scope differs')
    require(r['limits'] == {'cumulative_seconds': 30, 'cpu_count': 1, 'rss_kib': 1048576}
            and 0 <= r['cumulative_execution_seconds'] <= 30 and r['peak_rss_kib'] <= 1048576,
            'Saved limits differ')
    require(r['mathematical_count_proved'] is False and r['kernel_extension_implemented'] is False,
            'Native observation was upgraded to a proof')
    old_work = Path(r['inputs'][0]['path'])
    for _ in Path(r['inputs'][0]['relative_path']).parts:
        old_work = old_work.parent

    def local(value):
        path = Path(value)
        return WORK / path.relative_to(old_work) if path.is_relative_to(old_work) else path

    def verify(row, readonly=False, replacement=None):
        path = replacement or local(row['path'])
        require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Binding mismatch: ' + str(path))
        if readonly and not source_only:
            require(path.stat().st_mode & 0o222 == 0, 'Writable live snapshot/marker: ' + str(path))

    roles = {row['role']: row for row in r['inputs']}
    expected_roles = {'runner', 'protocol', 'resource_helper', 'toolchain_pin', 'source_generator',
        'generation_record', 'source_contract', 'source', 'finite_fold_source', 'first_order_source',
        'word_source', 'baseline_source', 'source_review', 'source_audit', 'accepted_generic_report',
        'accepted_project_report', 'baseline_native_report', 'baseline_runner', 'input_manifest'}
    require(len(r['inputs']) == 19 and set(roles) == expected_roles, 'Input roles differ')
    for row in r['inputs']:
        verify(row)
        require(local(row['path']) == WORK / row['relative_path'], 'Input relative path differs')
    manifest = read(local(roles['input_manifest']['path']))
    expected_rows = [{k: x[k] for k in ['role', 'bytes', 'sha256']} | {'path': x['relative_path']}
                     for x in r['inputs'] if x['role'] != 'input_manifest']
    require(manifest['inputs'] == expected_rows and manifest['cases'] == CASES
            and manifest['module_order'] == MODULES, 'Manifest/report mismatch')
    require(len(r['snapshots']) == 19 and {x['role'] for x in r['snapshots']} == expected_roles,
            'Snapshot roles differ')
    mappings = []
    for snapshot in r['snapshots']:
        original = roles[snapshot['role']]
        require(snapshot['original_path'] == original['path']
                and all(snapshot[k] == original[k] for k in ['bytes', 'sha256']), 'Snapshot identity differs')
        path = local(snapshot['path'])
        require(path == ATTEMPT / 'inputs' / original['relative_path'], 'Snapshot destination differs')
        if path.is_file():
            verify(snapshot, readonly=True)
        else:
            require(source_only, 'Missing live snapshot')
        mappings.append({'snapshot': str(path.relative_to(WORK)), 'canonical': original['relative_path'],
                         'role': snapshot['role'], 'bytes': snapshot['bytes'], 'sha256': snapshot['sha256']})
    verify(r['execution_marker'], readonly=True)
    marker = read(local(r['execution_marker']['path']))
    plan_keys = ['inputs', 'runtime', 'source_identity', 'source_fingerprint', 'toolchain',
                 'source_modules', 'cases', 'actual_accepted_generic_report']
    require(marker['format'] == FORMAT and local(marker['attempt']) == ATTEMPT
            and all(marker[k] == r[k] for k in plan_keys), 'Marker/report mismatch')
    identity = r['source_identity']
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(fingerprint == r['source_fingerprint']
            and Path(r['execution_marker']['path']).name == 'native-' + fingerprint + '.json',
            'Source fingerprint mismatch')
    require(identity['sources'] == [{'module': m['module'], 'sha256': m['sha256']} for m in r['source_modules']]
            and identity['generator_sha256'] == roles['source_generator']['sha256']
            and identity['cases'] == CASES and identity['complete_budget_seconds'] == 30
            and identity['lean_options'] == ['-j1', '-M1024', '-DautoImplicit=false',
                '-DwarningAsError=true', '-DElab.async=false']
            and identity['native_options'] == ['-O3', '-Werror'], 'Fixed compilation scope differs')
    generation = read(local(roles['generation_record']['path']))
    relative = lambda x: {'path': x['relative_path'], 'bytes': x['bytes'], 'sha256': x['sha256']}
    require(generation['fresh_modules'] == r['source_modules']
            and generation['source'] == relative(roles['source'])
            and generation['driver']['expected_answers_are_inputs'] is False, 'Source-generation mismatch')
    accepted = read(local(roles['accepted_generic_report']['path']))
    require(accepted['status'] == 'passed' and accepted['accepted_axiom_report_count'] == 18
            and r['actual_accepted_generic_report'] == relative(roles['accepted_generic_report'])
            and [(x['module'], x['sha256']) for x in accepted['source_bindings']]
              == [(x['module'], x['sha256']) for x in r['source_modules'][:2]], 'Wrong generic acceptance role')
    require(len(r['runtime']) == 44, 'Runtime count differs')
    if not source_only:
        for row in r['runtime']:
            verify(row)

    build_old = str(old_work / ATTEMPT.relative_to(WORK) / 'build')
    executable = build_old + '/native-first-order-probe'
    commands = []
    for module in r['source_modules']:
        name = module['module']
        source = str(old_work / ATTEMPT.relative_to(WORK) / 'inputs' / module['path'])
        command = [r['toolchain'] + '/bin/lean', *identity['lean_options'],
            '-o', build_old + '/' + name + '.olean', '-i', build_old + '/' + name + '.ilean',
            '-c', build_old + '/' + name + '.c', source]
        commands.append(('lean-' + name, command, str(Path(source).parent)))
    commands.append(('native-compilation', [r['toolchain'] + '/bin/leanc', '-O3', '-Werror',
        *[build_old + '/' + name + '.c' for name in MODULES], '-o', executable], build_old))
    commands.extend(('native-n' + str(n), [executable, str(n)], build_old) for n in CASES)
    require(len(r['commands']) == len(commands) == 7, 'Command count differs')
    axioms, diagnostics = [], []
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    for index, (row, expected) in enumerate(zip(r['commands'], commands)):
        require((row['label'], row['command'], row['cwd']) == expected, 'Command/cwd selection differs')
        require(row['exit_code'] == 0 and row['within_limits'] is True and row['limit_exceeded'] is None
                and row['seconds'] >= 0 and row['sampled_tree_and_wait4_peak_rss_kib'] <= 1048576,
                'Unsuccessful child')
        verify(row['stdout']); verify(row['stderr'])
        require(local(row['stderr']['path']).read_text() == '', 'Nonempty child stderr')
        out = local(row['stdout']['path']).read_text()
        if index < 3:
            module = MODULES[index]
            names = re.findall(r'^#print axioms (\S+)$', (WORK / r['source_modules'][index]['path']).read_text(), re.M)
            roots = ['ADWH.Experiments.Chapter15.' + module + '.' + name for name in names]
            raw = [{'root': name, 'axioms': [a.strip() for a in values.split(',') if a.strip()]}
                   for name, values in pattern.findall(out)]
            require([x['root'] for x in raw] == roots and all(set(x['axioms']) <= ALLOWED for x in raw)
                    and not pattern.sub('', out).strip(), 'Axiom/diagnostic mismatch')
            axioms.append({'module': module, 'required_roots': roots, 'raw_reports': raw, 'accepted_count': len(raw)})
        elif index == 3:
            require(out == '', 'Native compiler diagnostic')
        else:
            lines = out.splitlines(); require(len(lines) == 2, 'Native output line count')
            count, timing = [json.loads(line, object_pairs_hook=strict_object) for line in lines]
            n = CASES[index - 4]
            require(set(count) == {'format', 'n', 'count', 'formal_evidence'}
                    and count['format'] == 'adwh-native-first-order-nat-count-v1'
                    and type(count['n']) is int and count['n'] == n
                    and type(count['count']) is int and count['count'] >= 0 and count['formal_evidence'] is False,
                    'Native count schema differs')
            require(set(timing) == {'format', 'n', 'elapsed_ns', 'scope'}
                    and timing['format'] == 'adwh-native-first-order-nat-timing-v1'
                    and type(timing['n']) is int and timing['n'] == n
                    and type(timing['elapsed_ns']) is int and timing['elapsed_ns'] >= 0
                    and timing['scope'] == 'count_format_write_flush', 'Timing schema differs')
            diagnostics.append({'count': count, 'timing': timing, 'mathematical_acceptance': False})
    require(axioms == r['axiom_audits'] and sum(a['accepted_count'] for a in axioms) == 18
            and r['accepted_fresh_axiom_report_count'] == 18 and diagnostics == r['diagnostics'],
            'Parsed reports differ from saved summary')
    require(r['peak_rss_kib'] == max(c['sampled_tree_and_wait4_peak_rss_kib'] for c in r['commands']), 'Peak mismatch')
    require(r['declared_environment']['LEAN_PATH'] == build_old
            and r['declared_environment']['LEAN_SYSROOT'] == r['toolchain']
            and r['declared_environment']['LD_LIBRARY_PATH'] == r['toolchain'] + '/lib/lean:' + r['toolchain'] + '/lib'
            and all(r['declared_environment'][k] == '1' for k in ['LEAN_NUM_THREADS', 'LEAN_ABORT_ON_PANIC',
                'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']), 'Environment mismatch')
    expected_artifacts = {name + suffix for name in MODULES for suffix in ['.c', '.olean', '.ilean']} | {'native-first-order-probe'}
    require(len(r['artifacts']) == 10 and {Path(x['path']).name for x in r['artifacts']} == expected_artifacts,
            'Artifact inventory differs')
    c_mappings = []
    for row in r['artifacts']:
        if not source_only:
            verify(row)
        if Path(row['path']).suffix == '.c':
            retained = HERE / 'emitted-c' / Path(row['path']).name
            verify(row, replacement=retained)
            c_mappings.append({'recorded_artifact': str(local(row['path']).relative_to(WORK)),
                'canonical': str(retained.relative_to(WORK)), 'bytes': row['bytes'], 'sha256': row['sha256']})

    prefix = 'l_ADWH_Experiments_Chapter15_FirstOrderNat_'
    code = (HERE / 'emitted-c/FirstOrderNat.c').read_text()
    expected_calls = {'evaluate': [prefix + 'count'], 'count': [prefix + 'branches'],
                      'branches': [prefix + 'branches', prefix + 'count']}
    workers = {}
    for name, calls in expected_calls.items():
        body, line = function_body(code, prefix + name)
        actual = sorted(set(re.findall(r'\b(l_ADWH_[A-Za-z0-9_]+)\(', body)))
        require(actual == calls, 'Reachable worker call graph differs')
        forbidden = ['lean_alloc_ctor', 'lean_alloc_closure', 'lean_apply_', 'lean_ctor_get', 'lean_nat_shiftl']
        require(not any(token in body for token in forbidden), 'Unexpected worker packing/dispatch/left shift')
        workers[name] = {'definition_line': line, 'direct_program_calls': actual,
            'no_explicit_state_or_callback_allocations': True, 'no_indirect_callback_call': True}
    branches, _ = function_body(code, prefix + 'branches')
    require(branches.count('lean_nat_mul(') == 1 and branches.count('lean_nat_add(') == 1,
            'Transition multiplication or child+tail addition differs')
    driver = (HERE / 'emitted-c/NativeFirstOrderProbe.c').read_text()
    main, _ = function_body(driver, '_lean_main')
    ordered = ['v___x_37_ = lean_io_mono_nanos_now();',
        'v___x_39_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_35_);',
        'v___x_41_ = ' + prefix + 'evaluate(v___x_38_, v___x_39_, v___x_38_, v___x_40_, v___x_40_, v___x_40_);',
        'v___x_47_ = l_Nat_reprFast(v___x_41_);',
        'v___x_51_ = l_IO_FS_Stream_putStrLn(v___x_36_, v___x_50_);',
        'v___x_53_ = lean_apply_1(v_flush_52_, lean_box(0));',
        'v___x_54_ = lean_io_mono_nanos_now();']
    positions = [main.index(x) for x in ordered]
    require(positions == sorted(positions) and len(set(positions)) == len(positions), 'Clock/evaluation/output order differs')
    locations = [{'statement': x, 'line': driver.count('\n', 0, driver.index(x)) + 1} for x in ordered]
    baseline = read(local(roles['baseline_native_report']['path']))
    old_times = {x['count']['n']: x['timing']['elapsed_ns'] for x in baseline['diagnostics']}
    ratios = {str(x['count']['n']): old_times[x['count']['n']] / x['timing']['elapsed_ns'] for x in diagnostics}
    return {'format': 'adwh-first-order-native-saved-audit-v1', 'status': 'passed_saved_evidence_audit',
        'mode': 'source-only' if source_only else 'full-live', 'report': binding(REPORT),
        'review_scope': 'Independent check of root execution; auditor author also authored candidate/runner.',
        'seconds': r['cumulative_execution_seconds'], 'peak_rss_kib': r['peak_rss_kib'],
        'fresh_roots': 18, 'commands': 7, 'inputs': 19, 'snapshots': 19, 'runtime_bindings': 44,
        'diagnostics': diagnostics, 'baseline_over_candidate_internal_interval_ratios': ratios,
        'hot_worker_graph': workers, 'driver_timing_order': locations,
        'snapshot_mappings': mappings, 'generated_source_artifact_mappings': c_mappings,
        'runtime_and_compiled_artifacts_live_verified': not source_only,
        'source_only_ignores_archive_mode_bits': source_only,
        'mathematical_count_proved': False, 'n16_measured': False,
        'isolated_transformation_effect_or_n16_forecast': False,
        'compiler_counter_generator_or_executable_run_by_auditor': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(audit(args.source_only), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
