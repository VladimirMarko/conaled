# Independent mathematical review of FirstOrderNat

**No concrete mathematical or source/API blocker found.** The two proposed
files preserve the stated recurrence and have a coherent ordinary-proof route.
They have not been compiled or evaluated by this reviewer. Mutual well-founded
elaboration, strict simplifier diagnostics and eventual native representation
remain questions for the parent's bounded gates.

| Reviewed source | Bytes | SHA256 |
|---|---:|---|
| `source/FirstOrderNat.lean` | 7,348 | `e453954c94771eddda4d21ce52a7befb07093c9117202f886844a3507a02da1b` |
| `source/FirstOrderNatSource.lean` | 3,090 | `187d06ec3cdd74cce8181e99a25cadf4ed3e302b22b79a48ba5414c81a59aef6` |
| `SOURCE-INVENTORY.json` | 17,969 | `e458d562f2ad0b8b2b3645958dec1a70ee8b77ac31b37791f6b84dfad7772e48` |

The source author is `counting_route`; the independent reviewer is
`regression_audit`. [SOURCE-AUDIT.json](SOURCE-AUDIT.json) binds 32 input identities
and records independently extracted complete statements for all 14 new printed
roots. Import lists, namespaces, declaration/print order and strict options match
the inventory. No admission, unsafe/native proof shortcut, resource override or
expected-answer premise occurs in the mathematical source.

## Recurrence and totality

The scalar `count`/`branches` definitions preserve terminal columns at every
depth, including zero; nonterminal depth zero; fuel exhaustion before cursor
inspection; and the positive-fuel zero-cursor case. The order is still
`child + tail`, so repeated choices retain their multiplicity. Arithmetic stays
unbounded `Nat`, with saturating subtraction, explicit left-transition modulo
and the original unmasked right shift.

The lexicographic measure is mathematically sufficient for all natural inputs,
including modulus zero or a cursor whose low value is zero:

| Recursive edge | Caller rank | Callee rank | Strict decrease |
|---|---|---|---|
| Outer successor to branch loop | `(depth+1, 0)` | `(depth, budget+1)` | first component |
| Branch loop to child | `(depth, fuel+2)` | `(depth, 0)` | second component |
| Branch loop to residual cursor | `(depth, fuel+2)` | `(depth, fuel+1)` | second component |

The pinned `Prod.Lex.left` and `Prod.Lex.right` constructors have the signatures
used by the termination proof. This review does not assume that Lean will expose
every generated mutual-recursion goal in the anticipated form; the actual
compiler must accept the proof and equation lemmas.

Replacing `value <<< 1` with `value * 2` is justified for every Nat by the pinned
`Nat.shiftLeft_eq value 1` and `Nat.pow_one`. It does not require a machine-range
assumption. The reference transition deliberately retains the shift, and the
`equations` proof applies the replacement equality when matching the child state.
The pinned theorem and accepted FiniteFold function signatures match these calls.

## Generic contract and original source adapter

The four worker equations match `FiniteFold.Equations` exactly after lifting the
three scalar masks into the proof-side state. Terminal/empty predicates use
`decide`; the proof's conversion through `decide_eq_true_eq` preserves the guards.
The uniqueness transports are pointwise and introduce no numerical premise.
The generic fresh closure is **FiniteFold plus FirstOrderNat, 18 roots**.

The second module imports the actual `ADWH.Chapter15.QueensNatCounting`.
Its `sourceBranches` uses the original `sumBits` continuation. At modulus 65536
and budget 16, the original `low`, `available`, transition and recursion equations
match the proposed specification. `count_eq_source` covers every Nat mask,
depth and state triple; `branches_eq_source` additionally covers every fuel and
cursor. The endpoint retains the actual Word16 mask and both original budgets
16, then uses the existing `cqueensNat_eq` theorem. Its all-n function equality
does not enlarge the separate board-correctness range.

Those **five adapter roots are not checked by the generic closure**. I
independently reconstructed the 12-module unchanged ADWH reference import graph
and checked all 12 source hashes against the accepted integrated source gate.
That graph includes the original primitive and example dependencies; it is not
a prepared import pool or an approved execution plan. Any use of the earlier
proved symbolic primitive/scoped-counting sources must be disclosed in a new
complete closure with every selected new mathematical module freshly checked.

## What remains to establish

The hot source workers take scalar arguments and contain neither a state tuple
construction nor a continuation parameter. That does not prove the generated
code will retain this representation: mutual well-founded compilation can add
its own packing or closures. Native inspection must follow reachable workers,
separating proof-side reference functions, and verify both direct calls and the
intended multiplication. No dynamic allocation profile, speedup or n16 runtime
claim follows from this source review.

Before review freeze, one provenance path was corrected to the retained
`native-nat-evaluator-probe/emitted-c/NativeNatProbe.c` copy. Its bytes and both
mathematical files stayed unchanged. The four pinned standard-library source
references remain external provenance available from the exact toolchain; they
are not new imports or numerical premises.

The next compiler outcomes must be recorded as actual accepted roots. Even a
successful adapter gate would establish pure function refinement, not certify
native output or install a kernel reducer. No code generation, gate, source
guard, Lean compiler, generator or counter was executed for this review.
