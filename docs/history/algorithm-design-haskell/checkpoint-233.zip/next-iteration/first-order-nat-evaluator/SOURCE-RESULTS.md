# Actual-source bridge: independent saved-result review

**Accepted:** all ten selected modules were freshly checked, with all **67 of
67** required theorem reports accepted. The cumulative recorded time was
**5.742802972003119 seconds** and the highest observed child RSS was
**790,644 KiB**. No compiler, source gate, native counter or generator was rerun
for this review.

The fixed raw report is
`source-bridge-gate/attempts/source-bridge-01/report.json` (107,309 bytes), SHA256
`9413510d8e533781a89e2b00419f8d669b1e2a1f96950e71a3281e083510d29f`.
The separate source-only auditor, `audit_source_result.py`, reads and hashes
saved evidence without importing any execution runner. Both its live-binding
and source-only modes passed. Its full live findings are in `SOURCE-RESULTS.json`.

## What is now checked

The actual source adapter proves, for every natural `n`,

```lean
ADWH.Experiments.Chapter15.FirstOrderNat.SourceBridge.cqueens n =
  ADWH.Chapter15.Queens.BitRepresentation.cqueens n
```

The proof uses the imported original counter definitions, the checked symbolic
Word16 primitive refinement, the retained source-counting prefix and the exact
original FastCounting and NatCounting modules. The scoped counting file's four
recorded inverse edits independently reconstruct the complete original file
byte for byte. The adapter's final report uses exactly `propext`,
`Classical.choice` and `Quot.sound`.

| Fresh module group | Accepted reports |
| --- | ---: |
| Symbolic Word16 core and recurrence | 17 |
| Original-namespace primitive refinement | 7 |
| Scoped original counting source | 10 |
| FiniteFold | 9 |
| FirstOrderNat | 9 |
| FirstOrderNatSource | 5 |
| Original FastCounting/NatCounting roots, printed by the audit module | 10 |
| **Total** | **67** |

The original FastCounting and NatCounting files have no print commands; they
were nevertheless freshly compiled, and the final audit-only module supplies
their ten exact reports. Every raw report was reparsed from stdout in the
required per-module order. All stderr logs were empty, with no unparsed stdout,
duplicate roots, `sorryAx`, other axioms, failed module or resource event.
The axiom histogram is nine roots with no axioms, two with only `propext`,
21 with `propext` and `Quot.sound`, and 35 with all three permitted axioms.

## Provenance, freshness and limits

The report binds 12 current control roles, 35 retained historical reference
roles, all ten selected sources, six compiler/runtime files and 20 raw logs.
The direct report census is 219 binding occurrences / 167 distinct identities;
the permanent marker has 113 / 109. The separately retained original preparation
report has 64 / 62. These are different, explicitly scoped counts.

Only fourteen objects from the accepted seven-module original ADWH preparation
were copied. Their hashes and the preparation's seven successful commands,
empty logs and source/runtime bindings were independently checked. The new
directory contains exactly those fourteen copies and twenty fresh objects;
no experimental object was reused. Original preparation had its own earlier
fixed gate, and its time is not included in the new 5.7428-second observation.

Every fresh command used the pinned Lean 4.35.0 release with `-j1 -M1024`,
strict warnings, disabled asynchronous elaboration and default heartbeat and
recursion limits. The new closure shared one 30-second deadline, one CPU and
the unchanged 1,048,576-KiB observed-RSS ceiling. Source, control, runtime,
snapshot, log, marker and object bindings agree before and after execution.
The accepted source fingerprint is
`e98d216018c8a48dd5d5cfdff8a36805b3e05c8e6bf60f1403915aa301a3fd09`.

The runtime comparison report remains a compiler/runtime reference. It is not
an accepted generic proof report. This gate has no prior generic-acceptance
premise and freshly checks FiniteFold and FirstOrderNat itself.

## Durable source recovery

`SOURCE-SNAPSHOT-RECOVERY.json` maps all 22 new read-only snapshots (220,591
bytes) to 21 unchanged canonical files. There are no superseded source variants.
It also preserves the four standard-library source mappings already retained
by `GENERIC-SNAPSHOT-RECOVERY.json` (50,744 bytes). These source references must
not be dropped as if they were runtime binaries. Recover the existing baseline
derived sources and original-preparation evidence before recreating these
snapshot paths. All 34 compiled artifacts are deliberately omitted from the
checkpoint; their identities remain in the raw report and recovery metadata.

Live audit requires the new snapshots and marker to be read-only. Source-only
audit verifies exact bytes and hashes without requiring archive-restored Unix
mode bits or runtime/object availability. It also verifies missing snapshot
content against the corresponding canonical file. The historical preparation's
restored mode bits are not reinterpreted as live execution permissions.

## Scope and authorship

This is a universal source-equivalence result. It does not prove a numerical
queen count, execute the restricted checker or a native evaluator, establish a
compiled program's concrete result, or close `cqueens 16`. The stock-kernel
numeral proof remains open.

The first-order source author is `counting_route`; `regression_audit` reviewed
the mathematical sources. Root authored and executed this adapter gate and its
audit-only module. `validity_contracts` independently reviewed this gate and
the saved result, and is also the author of the imported FiniteFold helper.
