#!/usr/bin/env python3
"""Fresh native objects for seven unchanged originals; no link or count execution."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
HELPER = WORK / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
HELPER_SHA = '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0'
PIN = WORK / 'next-iteration/lean435-migration/toolchain.json'
PIN_SHA = 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c'
ORIGINAL_REPORT_SHA = '2a8670767de8261255e65b92ed69de85b015669a86cae7a854c26c7d166f2c14'
ORIGINAL_MANIFEST_SHA = 'fb73d244e7bd3fbf01a761ff6caa7c9b92c6066fa16591d76d5d3d0480a378b0'
PROJECT_SHA = 'f7f000482a7a655e092fb30b2969302cdf2b037f8c08b3b1f15a6d85e46e9c5f'
NATIVE_REPORT_SHA = '094ba1ca38f8ec8f8b096d3fec0e0c80f79865a33a89e37afcba870be45572b4'
LOCK = WORK / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FORMAT = 'adwh-seven-original-native-preparation-v1'
MODULES = ['ADWH.Chapter01.Lists', 'ADWH.Chapter01.Permutations',
    'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensVariants',
    'ADWH.Chapter15.QueensSearch', 'ADWH.Chapter15.QueensBitRepresentation',
    'ADWH.Chapter15.QueensBitMoves']
LEAN_OPTIONS = ['-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true', '-DElab.async=false']
NATIVE_OPTIONS = ['-O3', '-Werror', '-c']
SUFFIXES = ['.c', '.o', '.olean', '.ilean']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def relative(module, suffix='.lean'):
    return Path(*module.split('.')).with_suffix(suffix)


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and path.stat().st_size == row['bytes']
                  and sha(path) == row['sha256'], 'Binding differs: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot/marker: ' + str(path))


def preflight(toolchain, h):
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    manifest_path = HERE / 'input-manifest.json'
    manifest = read(manifest_path)
    h.require(manifest['format'] == 'adwh-seven-original-native-inputs-v1'
              and manifest['module_order'] == MODULES and manifest['output_suffixes'] == SUFFIXES
              and manifest['lean_options'] == LEAN_OPTIONS and manifest['native_options'] == NATIVE_OPTIONS
              and manifest['link_or_program_execution'] is False
              and manifest['experimental_objects_reused'] is False,
              'Different preparation boundary')
    inputs = []
    for row in manifest['inputs']:
        path = (WORK / row['path']).resolve()
        h.require(path.is_relative_to(WORK) and path.is_file() and not path.is_symlink(),
                  'Input is not a canonical workspace file')
        actual = h.binding(path)
        h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']), 'Input manifest mismatch')
        inputs.append({**actual, 'relative_path': path.relative_to(WORK).as_posix(), 'role': row['role']})
    inputs.append({**h.binding(manifest_path), 'relative_path': manifest_path.relative_to(WORK).as_posix(),
                   'role': 'input_manifest'})
    roles = {row['role']: row for row in inputs}
    expected_roles = {'runner', 'protocol', 'resource_helper', 'toolchain_pin',
        'original_preparation_report', 'original_preparation_manifest', 'accepted_project_report',
        'native_runtime_reference_report', 'native_runner_reference', 'leanc_wrapper_source',
        'input_manifest'} | {'source_' + str(i) for i in range(7)}
    h.require(len(inputs) == len(roles) == len({row['path'] for row in inputs}) == 18
              and set(roles) == expected_roles, 'Input role or file inventory differs')
    expected_paths = {
        'runner': Path(__file__).resolve(), 'protocol': HERE / 'PROTOCOL.md',
        'resource_helper': HELPER, 'toolchain_pin': PIN,
        'original_preparation_report': WORK / 'next-iteration/scoped-counting-bridge/import-preparation/attempts/originals-01/report.json',
        'original_preparation_manifest': WORK / 'next-iteration/scoped-counting-bridge/import-preparation/dependency-manifest.json',
        'accepted_project_report': WORK / 'project/adwh-lean/reports/verification.json',
        'native_runtime_reference_report': WORK / 'next-iteration/native-nat-evaluator-probe/gate/attempts/native-01/report.json',
        'native_runner_reference': WORK / 'next-iteration/first-order-nat-evaluator/native-probe/gate/run_probe.py',
        'leanc_wrapper_source': HERE / 'provenance/Leanc.lean',
        'input_manifest': manifest_path,
    }
    for role, path in expected_paths.items():
        h.require(roles[role]['path'] == str(path), 'Different role path: ' + role)
    for role, digest in [('resource_helper', HELPER_SHA), ('toolchain_pin', PIN_SHA),
            ('original_preparation_report', ORIGINAL_REPORT_SHA),
            ('original_preparation_manifest', ORIGINAL_MANIFEST_SHA), ('accepted_project_report', PROJECT_SHA),
            ('native_runtime_reference_report', NATIVE_REPORT_SHA)]:
        h.require(roles[role]['sha256'] == digest, 'Historical input changed: ' + role)
    pin = read(PIN)
    h.require(pin['version'] == '4.35.0' and
              pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc', 'Compiler revision differs')
    original = read(Path(roles['original_preparation_report']['path']))
    original_manifest = read(Path(roles['original_preparation_manifest']['path']))
    project = read(Path(roles['accepted_project_report']['path']))
    h.require(original['status'] == 'passed' and original['module_order'] == MODULES
              and original['all_7_original_imports_freshly_compiled'] is True
              and original['exact_original_only_object_inventory'] is True
              and original['compiled_imports_reused'] is False
              and original['compiled_new_mathematical_inputs'] is False
              and original['all_dependencies_independent_of_new_primitive'] is True
              and original['source_manifest']['sha256'] == ORIGINAL_MANIFEST_SHA,
              'Original pool provenance differs')
    h.require(original_manifest['module_order'] == MODULES
              and original_manifest['all_sources_previously_accepted_and_unchanged'] is True
              and original_manifest['compiled_new_mathematical_inputs'] is False
              and original_manifest['source_fingerprint'] == original['source_fingerprint'],
              'Original source manifest differs')
    h.require(project['status'] == 'passed' and project['run_id'] == '6e376337ca5b4b34a679cd9588e3bfc1'
              and original['accepted_original_source_gate']['sha256'] == PROJECT_SHA,
              'Integrated original-source provenance differs')
    project_files = {row['path']: row['sha256'] for row in project['files']}
    h.require(len(manifest['sources']) == len(original['source_bindings']) ==
              len(original_manifest['sources']) == 7, 'Source census differs')
    selected = []
    for index, (row, prior, declared) in enumerate(zip(manifest['sources'],
            original['source_bindings'], original_manifest['sources'])):
        module = MODULES[index]
        expected = WORK / 'project/adwh-lean' / relative(module)
        actual = roles['source_' + str(index)]
        h.require(row['module'] == prior['module'] == declared['module'] == module
                  and actual['path'] == str(expected) and row['path'] == expected.relative_to(WORK).as_posix()
                  and row['imports'] == prior['imports'] == declared['imports']
                  and prior['resource_overrides'] == declared['resource_overrides'] == []
                  and all(row[k] == prior[k] == declared[k] == actual[k] for k in ['bytes', 'sha256'])
                  and row['sha256'] == project_files[relative(module).as_posix()],
                  'Original-source identity mismatch: ' + module)
        text = expected.read_text()
        h.require(re.findall(r'^import (\S+)$', text, re.M) == row['imports'], 'Imports changed')
        h.require(not re.search(r'^#(?:eval|print|check|reduce)\b', text, re.M)
                  and not re.search(r'set_option\s+(maxRecDepth|maxHeartbeats|maxMemory|debug\.|compiler\.)', text),
                  'New evaluation/audit command or resource override')
        h.require(all(not imp.startswith('ADWH.') or imp in MODULES[:index] for imp in row['imports']),
                  'Preparation includes an unprepared project import')
        selected.append({**row})
    baseline = read(Path(roles['native_runtime_reference_report']['path']))
    h.require(baseline['format'] == 'adwh-exact-native-nat-probe-v1'
              and baseline['status'] == 'completed_within_limits', 'Native runtime reference differs')
    toolchain = toolchain.resolve()
    runtime_paths = [toolchain / 'bin' / name for name in ['lean', 'leanc', 'clang', 'ld.lld']]
    runtime_paths.extend(path.resolve() for path in (toolchain / 'include/lean').rglob('*') if path.is_file())
    for directory in [toolchain / 'lib', toolchain / 'lib/lean']:
        runtime_paths.extend(path.resolve() for path in directory.iterdir()
            if path.is_file() and not path.name.startswith('.') and (path.suffix == '.a' or '.so' in path.name))
    runtime = [h.binding(path) for path in sorted(set(runtime_paths))]
    old_toolchain = Path(baseline['toolchain'])
    h.require(len(runtime) == len(baseline['runtime']) == 44 and
              {str(Path(row['path']).relative_to(toolchain)): (row['bytes'], row['sha256']) for row in runtime} ==
              {str(Path(row['path']).relative_to(old_toolchain)): (row['bytes'], row['sha256'])
               for row in baseline['runtime']}, 'Native compiler/header/runtime identities differ')
    lean = next(row for row in runtime if row['path'] == str(toolchain / 'bin/lean'))
    h.require(all(lean[k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']), 'Lean pin differs')
    h.require((toolchain / 'src/lean/Leanc.lean').read_bytes() ==
              Path(roles['leanc_wrapper_source']['path']).read_bytes(), 'Retained Leanc source differs')
    identity = {'format': FORMAT, 'output_mode': 'fresh_lean_c_and_native_objects_no_link',
        'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in selected],
        'lean_options': LEAN_OPTIONS, 'native_options': NATIVE_OPTIONS,
        'output_suffixes': SUFFIXES, 'complete_budget_seconds': 30}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    verify(inputs + runtime, h)
    return {'inputs': inputs, 'runtime': runtime, 'toolchain': str(toolchain),
        'compiler_release': pin['version'], 'compiler_commit': pin['commit'],
        'source_modules': selected, 'module_order': MODULES, 'source_identity': identity,
        'source_fingerprint': fingerprint,
        'original_preparation_provenance': roles['original_preparation_report'],
        'original_preparation_objects_read_or_reused': False}


def run(plan, h):
    attempt = HERE / 'attempts/original-native-01'
    marker = HERE / 'execution-markers' / ('original-native-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Preparation attempt/source marker already exists')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    attempt.mkdir(parents=True)
    build = attempt / 'build'
    build.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': 'original-native-01', **plan,
        'snapshots': [], 'commands': [], 'artifacts': [], 'execution_marker': None,
        'limits': {'cumulative_seconds': 30, 'cpu_count': 1, 'rss_kib': 1048576,
                   'lean_memory_mib': 1024, 'default_heartbeats_and_recursion': True},
        'inputs_and_outputs_postchecked': False, 'all_7_originals_fresh_lean_c_native': False,
        'compiled_experimental_or_checker_objects': False, 'native_program_linked_or_executed': False,
        'new_axiom_root_census_performed': False, 'mathematical_count_proved': False,
        'n16_target_proved': False, 'object_search_path': str(build),
        'future_full_gate_requirement': 'Every new mathematical/checker source must be freshly checked/C-generated, '
            'then native-compiled/linked and its concrete certificate executed within one separate complete budget. '
            'Only these seven unchanged original modules may be reused as disclosed imports/native objects.'}
    h.save(report_path, report)
    cpus = os.sched_getaffinity(0)
    began = None
    try:
        for row in plan['inputs']:
            target = attempt / 'inputs' / row['relative_path']
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            target.chmod(0o444)
            frozen = h.binding(target)
            h.require(all(frozen[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot differs')
            report['snapshots'].append({**frozen, 'original_path': row['path'], 'role': row['role']})
        verify(plan['inputs'] + plan['runtime'], h)
        verify(report['snapshots'], h, readonly=True)
        marker.parent.mkdir(parents=True, exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': str(attempt), **plan}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(cpus)
        os.sched_setaffinity(0, {cpu})
        toolchain = Path(plan['toolchain'])
        env = {k: v for k, v in os.environ.items()
               if not k.startswith(('LEAN_', 'LAKE_', 'COMPARATOR_', 'PYTHON', 'CCACHE_', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS'))
               and k not in {'LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'CC', 'CXX', 'CXXFLAGS',
                             'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH',
                             'COMPILER_PATH', 'GCC_EXEC_PREFIX'}}
        env.update(LEAN_PATH=str(build), LEAN_NUM_THREADS='1', LEAN_ABORT_ON_PANIC='1',
                   LEAN_SYSROOT=str(toolchain),
                   LD_LIBRARY_PATH=str(toolchain / 'lib/lean') + ':' + str(toolchain / 'lib'),
                   OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        env['PATH'] = str(toolchain / 'bin') + os.pathsep + env.get('PATH', '')
        source_root = attempt / 'inputs/project/adwh-lean'
        commands = []
        for module in MODULES:
            (build / relative(module)).parent.mkdir(parents=True, exist_ok=True)
            commands.append(('lean-' + module, module, 'lean_c', [str(toolchain / 'bin/lean'),
                *LEAN_OPTIONS, '-o', str(build / relative(module, '.olean')),
                '-i', str(build / relative(module, '.ilean')), '-c', str(build / relative(module, '.c')),
                str(relative(module))], source_root))
        for module in MODULES:
            commands.append(('native-' + module, module, 'native_object', [str(toolchain / 'bin/leanc'),
                *NATIVE_OPTIONS, str(build / relative(module, '.c')), '-o', str(build / relative(module, '.o'))], build))
        report.update(status='running', cpu=cpu, declared_environment={key: env[key] for key in
            ['LEAN_PATH', 'LEAN_NUM_THREADS', 'LEAN_ABORT_ON_PANIC', 'LEAN_SYSROOT', 'LD_LIBRARY_PATH',
             'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']})
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for label, module, kind, command, cwd in commands:
            result = h.child(command, cwd, env, attempt / (label + '.stdout.log'),
                             attempt / (label + '.stderr.log'), cpu, deadline)
            report['commands'].append({'label': label, 'module': module, 'kind': kind, 'cwd': str(cwd), **result})
            h.save(report_path, report)
            h.require(result['exit_code'] == 0 and result['within_limits'], 'Child failed: ' + label)
            h.require(not Path(result['stdout']['path']).read_bytes() and
                      not Path(result['stderr']['path']).read_bytes(), 'Unexpected compiler diagnostics: ' + label)
            for suffix in (['.c', '.olean', '.ilean'] if kind == 'lean_c' else ['.o']):
                report['artifacts'].append(h.binding(build / relative(module, suffix)))
            h.save(report_path, report)
        h.require(len(report['commands']) == 14 and len(report['artifacts']) == 28, 'Incomplete original outputs')
        report['status'] = 'completed_within_limits'
    except BaseException as exc:
        report.update(status='failed', failure={'type': type(exc).__name__, 'message': str(exc)})
    finally:
        captured = {row['path'] for row in report['artifacts']}
        for artifact in sorted(build.rglob('*')):
            if artifact.is_file() and str(artifact.resolve()) not in captured:
                report['artifacts'].append({**h.binding(artifact), 'captured_after_failure': True})
        try:
            verify(plan['inputs'] + plan['runtime'] + report['artifacts'], h)
            verify(report['snapshots'], h, readonly=True)
            verify([row[k] for row in report['commands'] for k in ['stdout', 'stderr']], h)
            h.require(len(report['snapshots']) == len(plan['inputs']), 'Incomplete snapshots')
            h.require(report['execution_marker'] is not None, 'No reserved execution marker')
            verify([report['execution_marker']], h, readonly=True)
            if report['status'] == 'completed_within_limits':
                expected = {str(build / relative(module, suffix)) for module in MODULES for suffix in SUFFIXES}
                h.require(len(report['artifacts']) == 28 and {row['path'] for row in report['artifacts']} == expected
                          and {str(path) for path in build.rglob('*') if path.is_file()} == expected,
                          'Unexpected final artifact inventory')
                h.require(len(report['commands']) == 14, 'Incomplete command list')
            report['inputs_and_outputs_postchecked'] = True
        except BaseException as exc:
            report.update(status='failed', postcheck_failure={'type': type(exc).__name__, 'message': str(exc)})
        report['cumulative_execution_seconds'] = None if began is None else time.monotonic() - began
        report['peak_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['commands']), default=0)
        if began is not None and report['cumulative_execution_seconds'] > 30:
            report.update(status='failed', cumulative_limit_exceeded=True)
        try:
            os.sched_setaffinity(0, cpus)
        except BaseException as exc:
            report.update(status='failed', affinity_restore_failure={'type': type(exc).__name__, 'message': str(exc)})
        report['all_7_originals_fresh_lean_c_native'] = report['status'] == 'completed_within_limits'
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
        'seconds': report['cumulative_execution_seconds'], 'peak_rss_kib': report['peak_rss_kib'],
        'commands': len(report['commands']), 'artifacts': len(report['artifacts']),
        'native_program_linked_or_executed': False}, sort_keys=True))
    return 0 if report['status'] == 'completed_within_limits' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain', required=True, type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if sha(HELPER) != HELPER_SHA:
        raise ValueError('Pinned resource helper differs')
    spec = importlib.util.spec_from_file_location('original_native_preparation_resource', HELPER)
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    h.require(h.MEMORY_KIB == 1048576, 'RSS policy changed')
    plan = preflight(args.toolchain, h)
    if not args.run:
        print(json.dumps({'status': 'source_only_preflight', 'source_fingerprint': plan['source_fingerprint'],
            'original_modules': 7, 'input_count': len(plan['inputs']), 'runtime_count': len(plan['runtime']),
            'link_or_count_executed': False}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
