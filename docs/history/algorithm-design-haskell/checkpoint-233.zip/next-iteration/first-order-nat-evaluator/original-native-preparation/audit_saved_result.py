#!/usr/bin/env python3
"""Read-only audit of the saved seven-original native preparation.

No candidate, runner, compiler, gate, generator or native executable is imported
or invoked. --source-only validates the recorded binary identities and source
recovery maps without requiring the omitted distribution or compiled objects.
"""
import argparse
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
WORK = BASE.parents[2]
OLD_WORK = Path('/workspace/scratch/40ff1d6addf0/work')
ATTEMPT = BASE / 'attempts/original-native-01'
REPORT = ATTEMPT / 'report.json'
RECOVERY = BASE / 'SNAPSHOT-RECOVERY.json'
REPORT_SHA = 'fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5'
MANIFEST_SHA = '89d5868e92f1a4cd04c62ed6ebba5989a6a911896dff97eea179e503fcb7477a'
MODULES = [
    'ADWH.Chapter01.Lists', 'ADWH.Chapter01.Permutations',
    'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensVariants',
    'ADWH.Chapter15.QueensSearch', 'ADWH.Chapter15.QueensBitRepresentation',
    'ADWH.Chapter15.QueensBitMoves',
]
LEAN_OPTIONS = ['-j1', '-M1024', '-DautoImplicit=false',
                '-DwarningAsError=true', '-DElab.async=false']
NATIVE_OPTIONS = ['-O3', '-Werror', '-c']
SUFFIXES = ['.c', '.o', '.olean', '.ilean']
COMMIT = 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': str(path.relative_to(WORK)), 'bytes': path.stat().st_size,
            'sha256': digest(path)}


def identity(row):
    return row['bytes'], row['sha256']


def local(path):
    path = Path(path)
    if not path.is_absolute():
        return WORK / path
    if path.is_relative_to(OLD_WORK):
        return WORK / path.relative_to(OLD_WORK)
    return path


def walk(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def audit(source_only):
    require(REPORT.stat().st_size == 66928 and digest(REPORT) == REPORT_SHA,
            'The immutable raw report differs')
    report = json.loads(REPORT.read_text())
    recovery = json.loads(RECOVERY.read_text())
    manifest_path = BASE / 'input-manifest.json'
    require(digest(manifest_path) == MANIFEST_SHA, 'Input manifest differs')
    manifest = json.loads(manifest_path.read_text())
    old_base = OLD_WORK / BASE.relative_to(WORK)
    old_attempt = old_base / 'attempts/original-native-01'
    old_build = old_attempt / 'build'
    toolchain = Path(report['toolchain'])

    require(report['format'] == 'adwh-seven-original-native-preparation-v1', 'Report format')
    require(report['status'] == 'completed_within_limits', 'Preparation did not pass')
    require(report['attempt'] == 'original-native-01', 'Wrong attempt label')
    require(report['module_order'] == manifest['module_order'] == MODULES, 'Module order')
    require(report['source_modules'] == manifest['sources'], 'Source manifest/report correspondence')
    require(report['compiler_release'] == '4.35.0' and report['compiler_commit'] == COMMIT,
            'Compiler revision')
    require(report['all_7_originals_fresh_lean_c_native'] is True and
            report['inputs_and_outputs_postchecked'] is True, 'Freshness/postcheck flags')
    for flag in ['compiled_experimental_or_checker_objects', 'mathematical_count_proved',
                 'n16_target_proved', 'native_program_linked_or_executed',
                 'new_axiom_root_census_performed', 'original_preparation_objects_read_or_reused']:
        require(report[flag] is False, 'Unsupported result flag: ' + flag)
    require(report['limits'] == {'cpu_count': 1, 'cumulative_seconds': 30,
            'default_heartbeats_and_recursion': True, 'lean_memory_mib': 1024,
            'rss_kib': 1048576}, 'Resource contract')
    require(0 < report['cumulative_execution_seconds'] <= 30 and
            0 < report['peak_rss_kib'] <= 1048576, 'Observed resource bound')
    require(report['object_search_path'] == str(old_build), 'Object search path')
    require(manifest['lean_options'] == LEAN_OPTIONS and
            manifest['native_options'] == NATIVE_OPTIONS and
            manifest['output_suffixes'] == SUFFIXES and
            manifest['experimental_objects_reused'] is False and
            manifest['link_or_program_execution'] is False, 'Manifest execution contract')

    expected_identity = {
        'complete_budget_seconds': 30, 'format': report['format'],
        'lean_options': LEAN_OPTIONS, 'native_options': NATIVE_OPTIONS,
        'output_mode': 'fresh_lean_c_and_native_objects_no_link',
        'output_suffixes': SUFFIXES,
        'sources': [{'module': r['module'], 'sha256': r['sha256']}
                    for r in report['source_modules']],
    }
    require(report['source_identity'] == expected_identity, 'Source identity contract')
    fingerprint = hashlib.sha256(json.dumps(expected_identity, sort_keys=True,
                                            separators=(',', ':')).encode()).hexdigest()
    require(fingerprint == report['source_fingerprint'], 'Source fingerprint')

    inputs = report['inputs']
    roles = {r['role']: r for r in inputs}
    expected_roles = ['source_' + str(i) for i in range(7)] + [
        'runner', 'protocol', 'resource_helper', 'toolchain_pin',
        'original_preparation_report', 'original_preparation_manifest',
        'accepted_project_report', 'native_runtime_reference_report',
        'native_runner_reference', 'leanc_wrapper_source', 'input_manifest']
    require(len(inputs) == len(roles) == 18 and list(roles) == expected_roles,
            'Input role contract')
    for actual, expected in zip(inputs[:-1], manifest['inputs']):
        require(actual['relative_path'] == expected['path'] and
                actual['path'] == str(OLD_WORK / expected['path']) and
                actual['role'] == expected['role'] and identity(actual) == identity(expected),
                'Manifest input mismatch')
    require(len(manifest['inputs']) == 17, 'Manifest input count')
    require(identity(roles['input_manifest']) == (6759, MANIFEST_SHA), 'Self manifest role')

    snapshots = report['snapshots']
    require(len(snapshots) == 18, 'Snapshot count')
    require(recovery['format'] == 'adwh-seven-original-native-source-recovery-v1',
            'Recovery format')
    require(recovery['raw_report']['sha256'] == REPORT_SHA, 'Recovery report binding')
    snapshot_map = {}
    require(len(recovery['snapshot_mappings']) == 18, 'Recovery snapshot count')
    for original, snapshot, mapping in zip(inputs, snapshots, recovery['snapshot_mappings']):
        expected_path = str(old_attempt / 'inputs' / original['relative_path'])
        require(snapshot['path'] == expected_path and snapshot['original_path'] == original['path']
                and snapshot['role'] == original['role'] and identity(snapshot) == identity(original),
                'Snapshot identity/role')
        require(mapping['snapshot_path'] == str(Path(expected_path).relative_to(OLD_WORK)) and
                mapping['canonical_path'] == original['relative_path'] and
                mapping['role'] == original['role'] and identity(mapping) == identity(original),
                'Snapshot recovery identity')
        snapshot_map[expected_path] = WORK / mapping['canonical_path']

    artifacts = report['artifacts']
    expected_artifacts = {str(old_build / (m.replace('.', '/') + s))
                          for m in MODULES for s in SUFFIXES}
    require(len(artifacts) == 28 and {r['path'] for r in artifacts} == expected_artifacts,
            'Artifact inventory')
    objects = {r['path']: r for r in artifacts if not r['path'].endswith('.c')}
    c_sources = {r['path']: r for r in artifacts if r['path'].endswith('.c')}
    require(len(objects) == 21 and len(c_sources) == 7, 'Output kinds')
    require(len(recovery['emitted_c_mappings']) == 7 and
            len(recovery['omitted_compiled_artifacts']) == 21, 'Recovery artifact inventory')
    c_map = {}
    for mapping in recovery['emitted_c_mappings']:
        raw = str(OLD_WORK / mapping['recorded_path'])
        relative_c = Path(raw).relative_to(old_build)
        canonical = BASE / 'emitted-c' / relative_c
        require(raw in c_sources and identity(mapping) == identity(c_sources[raw]) and
                mapping['canonical_path'] == str(canonical.relative_to(WORK)),
                'Generated C recovery identity')
        c_map[raw] = canonical
    require(set(c_map) == set(c_sources), 'Complete generated C preservation')
    omissions = {str(OLD_WORK / r['path']): r for r in recovery['omitted_compiled_artifacts']}
    require(set(omissions) == set(objects) and
            all(identity(omissions[p]) == identity(r) for p, r in objects.items()),
            'Compiled omission identities')
    require(recovery['snapshot_count'] == 18 and recovery['snapshot_bytes'] == 1701717 and
            recovery['emitted_c_count'] == 7 and recovery['emitted_c_bytes'] == 251025,
            'Recovery totals')

    runtime = {r['path']: r for r in report['runtime']}
    require(len(runtime) == len(report['runtime']) == 44, 'Runtime inventory')
    require(recovery['omitted_runtime_files'] == report['runtime'], 'Runtime omission identities')
    runtime_reference = json.loads(local(roles['native_runtime_reference_report']['path']).read_text())
    reference_runtime = {str(Path(r['path']).relative_to(Path(runtime_reference['toolchain']))): identity(r)
                         for r in runtime_reference['runtime']}
    require({str(Path(p).relative_to(toolchain)): identity(r) for p, r in runtime.items()} ==
            reference_runtime, 'Accepted native runtime identities differ')

    seen = set()
    skipped_runtime, skipped_objects, recovered = set(), set(), set()

    def verify(row):
        path = row['path']
        key = (path, *identity(row))
        if key in seen:
            return
        seen.add(key)
        if source_only and path in runtime:
            require(identity(row) == identity(runtime[path]), 'Runtime identity mismatch')
            skipped_runtime.add(path)
            return
        if source_only and path in objects:
            require(identity(row) == identity(objects[path]), 'Object identity mismatch')
            skipped_objects.add(path)
            return
        if source_only and path in snapshot_map:
            target = snapshot_map[path]
            recovered.add(path)
        elif source_only and path in c_map:
            target = c_map[path]
            recovered.add(path)
        else:
            target = local(path)
        require(target.is_file() and target.stat().st_size == row['bytes'] and
                digest(target) == row['sha256'], 'File binding mismatch: ' + path)

    report_bindings = list(walk(report))
    for row in report_bindings:
        verify(row)
    for raw, canonical in c_map.items():
        require(canonical.is_file() and canonical.stat().st_size == c_sources[raw]['bytes'] and
                digest(canonical) == c_sources[raw]['sha256'], 'Retained C differs')
    if not source_only:
        for row in snapshots + [report['execution_marker']]:
            require(local(row['path']).stat().st_mode & 0o222 == 0,
                    'Live frozen evidence is writable')
        build = ATTEMPT / 'build'
        require({str(p.relative_to(build)) for p in build.rglob('*') if p.is_file()} ==
                {str(Path(p).relative_to(old_build)) for p in expected_artifacts},
                'Actual build contains omitted/extra output')

    marker = json.loads(local(report['execution_marker']['path']).read_text())
    require(marker['format'] == report['format'] and marker['attempt'] == str(old_attempt),
            'Marker identity')
    for key in ['compiler_commit', 'compiler_release', 'inputs', 'module_order',
                'original_preparation_objects_read_or_reused', 'original_preparation_provenance',
                'runtime', 'source_fingerprint', 'source_identity', 'source_modules', 'toolchain']:
        require(marker[key] == report[key], 'Marker/report mismatch: ' + key)
    require(Path(report['execution_marker']['path']).name == 'original-native-' + fingerprint + '.json',
            'Permanent marker source fingerprint')
    marker_bindings = list(walk(marker))
    for row in marker_bindings:
        verify(row)

    prior = json.loads(local(roles['original_preparation_report']['path']).read_text())
    prior_manifest = json.loads(local(roles['original_preparation_manifest']['path']).read_text())
    project = json.loads(local(roles['accepted_project_report']['path']).read_text())
    require(prior['status'] == 'passed' and prior['module_order'] == MODULES,
            'Prior source provenance is not accepted')
    require(report['original_preparation_provenance'] == roles['original_preparation_report'],
            'Prior report role')
    require(prior['compiler_commit'] == COMMIT and prior_manifest['compiler_commit'] == COMMIT,
            'Prior source revision')
    project_sources = {r['module']: r for r in project['files']}
    for i, source in enumerate(report['source_modules']):
        earlier = prior['source_bindings'][i]
        manifest_source = prior_manifest['sources'][i]
        original = roles['source_' + str(i)]
        require(source['module'] == MODULES[i] and identity(source) == identity(earlier) ==
                identity(manifest_source) == identity(original), 'Original source correspondence')
        require(source['imports'] == earlier['imports'] == manifest_source['imports'],
                'Original import correspondence')
        require(source['sha256'] == project_sources[source['module']]['sha256'],
                'Integrated source identity')

    expected_environment = {
        'LD_LIBRARY_PATH': str(toolchain / 'lib/lean') + ':' + str(toolchain / 'lib'),
        'LEAN_ABORT_ON_PANIC': '1', 'LEAN_NUM_THREADS': '1', 'LEAN_PATH': str(old_build),
        'LEAN_SYSROOT': str(toolchain), 'MKL_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
        'OPENBLAS_NUM_THREADS': '1',
    }
    require(report['declared_environment'] == expected_environment, 'Declared environment')
    commands = report['commands']
    require(len(commands) == 14, 'Compiler command count')
    for i, command in enumerate(commands):
        module = MODULES[i % 7]
        rel = module.replace('.', '/')
        if i < 7:
            expected = [str(toolchain / 'bin/lean'), *LEAN_OPTIONS,
                        '-o', str(old_build / (rel + '.olean')),
                        '-i', str(old_build / (rel + '.ilean')),
                        '-c', str(old_build / (rel + '.c')), rel + '.lean']
            kind, label, cwd = 'lean_c', 'lean-' + module, old_attempt / 'inputs/project/adwh-lean'
        else:
            expected = [str(toolchain / 'bin/leanc'), *NATIVE_OPTIONS,
                        str(old_build / (rel + '.c')), '-o', str(old_build / (rel + '.o'))]
            kind, label, cwd = 'native_object', 'native-' + module, old_build
        require(command['command'] == expected and command['kind'] == kind and
                command['module'] == module and command['label'] == label and
                command['cwd'] == str(cwd), 'Unexpected command or working directory')
        require(command['exit_code'] == 0 and command['within_limits'] is True and
                command['limit_exceeded'] is None, 'Compiler failed or exceeded resources')
        require(0 <= command['seconds'] <= 30 and
                0 < command['sampled_tree_and_wait4_peak_rss_kib'] <= 1048576, 'Child resources')
        for stream in ['stdout', 'stderr']:
            row = command[stream]
            require(row['path'] == str(old_attempt / (label + '.' + stream + '.log')) and
                    row['bytes'] == 0 and row['sha256'] == hashlib.sha256(b'').hexdigest(),
                    'Unexpected compiler diagnostic')
    require(sum(c['seconds'] for c in commands) <= report['cumulative_execution_seconds'],
            'Cumulative time excludes compiler intervals')
    require(max(c['sampled_tree_and_wait4_peak_rss_kib'] for c in commands) == report['peak_rss_kib'],
            'Peak RSS summary')
    if source_only:
        require(len(skipped_runtime) == 44 and len(skipped_objects) == 21 and len(recovered) == 25,
                'Source-only recovery/omission scope')

    def census(rows):
        return {'binding_occurrences': len(rows),
                'distinct_recorded_path_identities': len({(r['path'], *identity(r)) for r in rows}),
                'distinct_normalized_file_identities': len({(str(local(r['path'])), *identity(r))
                                                           for r in rows})}

    return {
        'format': 'adwh-seven-original-native-independent-result-audit-v1',
        'status': 'saved_evidence_verified',
        'mode': 'source_only_recovery' if source_only else 'live_saved_artifacts',
        'reviewer': 'validity_contracts', 'runner_author': 'counting_route',
        'gate_reviewer_and_executor': 'root',
        'auditor_authored_runner_or_original_sources': False,
        'raw_report': binding(REPORT), 'auditor': binding(Path(__file__).resolve()),
        'recovery_map': binding(RECOVERY),
        'preparation_status': report['status'], 'source_fingerprint': fingerprint,
        'cumulative_execution_seconds': report['cumulative_execution_seconds'],
        'peak_rss_kib': report['peak_rss_kib'], 'module_order': MODULES,
        'fresh_original_source_count': 7, 'lean_commands': 7, 'native_object_commands': 7,
        'all14_exits_zero_and_within_limits': True, 'empty_raw_log_count': 28,
        'artifact_count': 28, 'artifact_kinds': {s: 7 for s in SUFFIXES},
        'snapshots_verified': 18, 'snapshot_bytes': 1701717,
        'retained_generated_C_count': 7, 'retained_generated_C_bytes': 251025,
        'input_roles': expected_roles, 'all18_input_and_snapshot_roles_match': True,
        'runtime_identity_count': 44, 'runtime_matches_accepted_native_reference': True,
        'correct_original_source_provenance': True, 'permanent_marker_verified': True,
        'all_source_control_runtime_artifact_log_bindings_verified_in_selected_mode': True,
        'report_binding_census': census(report_bindings), 'marker_binding_census': census(marker_bindings),
        'source_only_omissions': {'runtime_files': 44, 'compiled_original_artifacts': 21},
        'source_only_uses_canonical_snapshot_and_C_bytes': True,
        'mode_bits_enforced_only_for_live_snapshot_and_marker': True,
        'old_original_compiled_pool_reused_or_required_by_audit': False,
        'experimental_objects_prepared': False, 'executable_linked_or_run': False,
        'new_axiom_census_claimed': False, 'concrete_count_or_stock_numeral_proof': False,
        'native_compiler_or_runtime_correctness_proved_by_audit': False,
        'compiler_gate_counter_or_generator_executed_by_auditor': False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(audit(args.source_only), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
