# Original native dependency preparation: independent saved-result review

**The seven-original preparation passed its single complete budget.** All
fourteen compiler commands exited successfully with empty stdout and stderr.
The saved report records **10.480943722002849 seconds** and a maximum observed
resident set of **799,192 KiB**, within the fixed 30-second, one-CPU,
1,048,576-KiB contract. No executable was linked or run. This result prepares
unchanged dependencies; it proves no new count or concrete checker acceptance.

The immutable raw report is `attempts/original-native-01/report.json`,
66,928 bytes, SHA256
`fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5`.
`RESULTS.json` records the independent audit and exact source/marker identities.

## What was checked

The ordered sources are Lists, Permutations, Queens, QueensVariants,
QueensSearch, QueensBitRepresentation and QueensBitMoves. Their exact bytes
and imports match the earlier accepted original-only preparation and its
manifest, and their hashes match the accepted integrated project report.
The earlier object pool served only as source provenance: none of its objects
was read, copied or required by this preparation or by this saved-result audit.

The new build contains exactly seven each of `.c`, `.o`, `.olean` and `.ilean`:
twenty-eight artifacts. Seven fresh Lean commands produced the Lean objects
and C; seven bundled `leanc -O3 -Werror -c` commands produced native objects.
All fourteen commands share the same cumulative interval and use only the
fresh original build as the project object search path. The Lean options
include `-j1 -M1024`, strict warnings and disabled asynchronous elaboration;
heartbeat and recursion defaults are unchanged. Every saved command, working
directory, output path, exit status and resource outcome matches that protocol.

The review verified all eighteen current input roles and their read-only
snapshots, all twenty-eight empty raw logs, all twenty-eight artifacts, and
the permanent source-fingerprint marker. The marker's source/control/runtime
records match the completed report. Its identity is
`7ba5a0c1e6566984d4a3d58846b42e9f93e1caefb2fe88aaed2d11b027704391`.
The source-only audit does not treat archive-restored permission bits as
evidence of the original snapshot permissions; the live audit checked the
original snapshots and marker directly.

All forty-four recorded compiler/runtime/header identities match the accepted
native runtime reference exactly, and their actual files were hashed in the
live audit. The retained `provenance/Leanc.lean` is a source input, included in
the eighteen-input snapshot/recovery contract. The review neither invokes
that wrapper nor claims a new proof of compiler or runtime correctness.

For an unambiguous binding census, the raw report contains 145 binding
occurrences, 144 distinct recorded path identities and 137 distinct files
after normalizing work-relative versus absolute paths. The marker contains
70 occurrences, 69 recorded path identities and 62 normalized files. These
counts inspect the saved report and marker directly; they do not recursively
claim to re-audit the contents of every historical report named as provenance.

## Durable source-only recovery

`SNAPSHOT-RECOVERY.json` maps all eighteen duplicate input snapshots to exact
canonical files. Their combined size is 1,701,717 bytes, including the already
retained integrated project report. No failed or superseded source variant
needs a separate recovery copy for this successful first attempt.

The seven emitted C files are preserved once under `emitted-c/ADWH/...`,
totalling **251,025 bytes**. Their hashes match the C files produced during
the accepted preparation. The recovery map connects the raw build paths to
these retained source files. It records the identities of the twenty-one
compiled outputs and forty-four distribution files that a source-only
checkpoint omits. It retains the raw report, logs and permanent marker.
No executable exists in this preparation.

The read-only auditor supports both views:

```sh
python3 -I audit_saved_result.py
python3 -I audit_saved_result.py --source-only
```

Both modes passed during this review. The first checks actual saved binaries,
runtime files and live snapshot modes. The second deliberately resolves all
eighteen snapshots and seven C sources through the canonical recovery map;
it checks the omitted binary identities without requiring or executing them.
Neither mode imports a candidate, gate, runner, generator or compiler.

## Scope of the result

There is no new printed-axiom census in this unchanged-original preparation.
It contains no symbolic primitive refinement, FiniteFold, first-order or
UInt64 evaluator, checker, driver or numerical test. The preparation's time
is reported separately. A later full native checker must freshly check all
selected new mathematical sources, generate and compile their C, link, and
execute its actual certificate within that later gate's single complete
budget. This preparation does not discharge the concrete successful-check
equation needed for a stock Lean numeral theorem.

Runner/source author: `counting_route`. Gate reviewer and executor: parent/root.
Independent saved-result reviewer: `validity_contracts`, who authored none of
these seven original sources or this preparation runner. This review used
source reading, JSON/hash checks and its own read-only audit script; it ran
no Lean, compiler, gate, generator, counter or native checker. Existing raw
reports, sources, controls and markers remain unchanged.
