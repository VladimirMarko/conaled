# Seven-original native dependency preparation

This is a distinct operational preparation for the eventual verified-checker
native workflow. The existing original-only pool supplies fourteen Lean object
files; it has no generated C or native objects. This preparation produces those
missing output forms from the **same seven unchanged original sources**, with
fresh Lean checking/C generation as well as native compilation. It makes no
new mathematical or numerical claim.

| Ordered original module | Allowed project imports |
| --- | --- |
| `ADWH.Chapter01.Lists` | None (`Std` only) |
| `ADWH.Chapter01.Permutations` | Lists |
| `ADWH.Chapter15.Queens` | Permutations |
| `ADWH.Chapter15.QueensVariants` | Queens |
| `ADWH.Chapter15.QueensSearch` | QueensVariants |
| `ADWH.Chapter15.QueensBitRepresentation` | QueensSearch |
| `ADWH.Chapter15.QueensBitMoves` | QueensBitRepresentation |

The representation module also imports the pinned standard-library
`Init.Data.BitVec.Bitblast`. No primitive refinement, experimental helper,
counting module, checker or driver is in this preparation. No old project or
experimental object is loaded or copied. The only project objects available
to each compilation are the preceding freshly checked originals in the new
build directory. The pinned release standard library remains an ordinary
toolchain dependency.

## Exact source and runtime provenance

Every source path, byte count, SHA256 and import list must match the accepted
seven-original report and its manifest, and the source hashes must also match
the accepted integrated project report. The original report is SHA256
`2a8670767de8261255e65b92ed69de85b015669a86cae7a854c26c7d166f2c14`;
the corresponding manifest is
`fb73d244e7bd3fbf01a761ff6caa7c9b92c6066fa16591d76d5d3d0480a378b0`.
They are used as source provenance. Their compiled objects, duplicate snapshots
and original timing budget are not inputs to this execution.

The current manifest binds seventeen files plus itself: seven sources, the
runner/protocol/resource helper/toolchain pin, four provenance records, the
accepted native runner reference and a small retained `Leanc.lean` source.
All eighteen inputs receive read-only snapshots. The runner checks exact
roles and hashes before starting and again after the work. It does not invoke
any retained generator, source guard, prior runner or their `main` functions.
Only the unchanged, hash-pinned resource helper is imported for its file and
process-monitoring functions.

The native compiler, linker, every Lean runtime header, and selected static
and shared libraries must have the **same exact forty-four identities** as
the accepted original native probe. The compiler release is Lean 4.35.0,
commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. The retained Leanc source
documents that command arguments are forwarded to the bundled C compiler:
`-c` requests an object, and its trailing
`-Wno-unused-command-line-argument` handles the wrapper's unused linker flags.
This is source inspection, not an additional compiler invocation or a new
compiler correctness proof.

## One complete preparation budget

After source review, root may run from this directory:

```sh
python3 -I run_preparation.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux
python3 -I run_preparation.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux --run
```

The first command validates source/runtime metadata without starting a
compiler. The second obtains the shared nonblocking compile lock and reserves
the single `attempts/original-native-01` directory and a source-keyed permanent
marker. The identity includes all seven ordered source hashes, the new output
mode and the exact compiler options. The previous original-pool markers remain
untouched. Preserve this attempt and marker after either outcome; a renamed
attempt or changed control file cannot repeat this unchanged preparation.

There are exactly fourteen subprocesses:

1. Seven ordered Lean invocations, each producing `.olean`, `.ilean` and `.c`
   using `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`.
2. Seven `leanc -O3 -Werror -c <module.c> -o <module.o>` invocations.

There is **no linking and no executable invocation**. In particular, no queen
counter or checker is called. Success requires empty stdout/stderr and a zero
exit code for every compiler. The sources contain no added audit/evaluation
commands. There is no fresh printed-axiom census in this unchanged-original
preparation; eventual new theorem roots must audit their actual transitive
axioms in the complete proof/native gate.

All fourteen commands share one CPU, one cumulative 30-second deadline and
the existing 1,048,576-KiB observed resident-memory ceiling. The unchanged
`h.child` helper monitors process groups and checks exit high-water usage.
There are no heartbeat, recursion, compiler-resource or address-space
overrides. The timer starts immediately before the first Lean command and
includes every later compiler and the final integrity checks; it is never
reset between Lean and native compilation. Input validation and snapshotting
precede this interval. `/proc` visibility is required for RSS enforcement.

The environment matches the accepted native probe: `LEAN_PATH` is only the
new build, `LEAN_SYSROOT` is the pinned toolchain, `LD_LIBRARY_PATH` names its
`lib/lean` and `lib` directories, its `bin` is first in `PATH`, and runtime
thread counts are one. Prior Lean/Lake/compiler/loader/search-path overrides
are removed. Lean runs from the snapshot's `project/adwh-lean` root using
module-relative source paths. Native compilation runs from the new build.

## Output contract and later use

Acceptance requires exactly twenty-eight files under the build directory:
seven each of `.c`, `.o`, `.olean` and `.ilean`, with no extra object or binary.
The report preserves every command, raw log, elapsed time, exit status, source,
control, runtime, snapshot, marker and output hash. Failures retain available
partial artifacts and their evidence. Postchecks and affinity-restoration
errors make the result fail; exceeding the final cumulative deadline also
makes it fail. No old marker is deleted and no retry is performed.

A later complete native checker may reuse only the explicitly disclosed
objects for these seven unchanged originals. **Every new mathematical source**
—including the symbolic primitive refinement, source bridges, FiniteFold,
first-order/UInt64 helpers and checker—must still be freshly checked and
C-generated, then natively compiled/linked with the prepared originals, and
the concrete certificate executed within that later gate's single complete
budget. This preparation does not exempt any new helper or discharge a
checker-acceptance premise. Its time is reported separately and never
presented as part of the later new-mathematics timing.

Author: `counting_route`. Parent/root reviews and is the sole executor.
