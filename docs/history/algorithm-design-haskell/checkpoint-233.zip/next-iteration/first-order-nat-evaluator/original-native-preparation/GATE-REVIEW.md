# Root review of the original-native preparation

Root read the entire runner and protocol before execution on 25 October 2026.
No gate-control blocker was found. The preparation has no native program or
counting invocation and no new mathematical claim. Its purpose is to produce
the missing C and native object forms for seven unchanged original modules.

The reviewed runner is 21,021 bytes, SHA256
`e0b682c9a1cf2241a726aa5e78a246d74aa76581b82ec977c502ead697df119f`.
The protocol is 6,988 bytes, SHA256
`5c15484bc3abca142f5bbfc6493e411f3812188ee6db541bbac0349cd28b9ee8`.
The input manifest is 6,759 bytes, SHA256
`89d5868e92f1a4cd04c62ed6ebba5989a6a911896dff97eea179e503fcb7477a`.

The exact seven original sources are bound to both their accepted source-only
preparation and the accepted integrated project report. The new build starts
empty and its object search path includes only freshly produced originals.
Seven Lean commands and seven native object commands share one 30-second
deadline, one CPU and the unchanged 1,048,576-KiB resource helper. No relaxed
heartbeat/recursion setting, experimental import, old object or executable
invocation appears. The native environment and 44 distribution bindings match
the accepted baseline. All 18 input roles are explicitly checked and snapshotted.

The source-keyed marker includes the distinct required output mode and is
exclusive and permanent. Failures retain logs, snapshots and partial outputs.
Postchecks bind source/runtime/artifacts/marker, and success requires exactly
28 build files. Final cumulative time and affinity failures reject the run.

This is disclosed original dependency preparation. A later complete checker
must freshly check and C-generate all selected new mathematics, compile/link
and execute its actual certificate within one complete budget; this pool
cannot exempt experimental proofs or supply a numerical acceptance premise.
The original modules have no added print audit; the later full proof roots
must still report their exact transitive axioms. Root is the sole executor.
