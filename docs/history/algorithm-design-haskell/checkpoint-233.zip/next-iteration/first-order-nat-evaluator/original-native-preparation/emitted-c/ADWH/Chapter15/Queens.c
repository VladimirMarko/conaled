// Lean compiler output
// Module: ADWH.Chapter15.Queens
// Imports: public import Init public meta import Init public import ADWH.Chapter01.Permutations
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* l_List_range_x27TR_go(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_zipWith___at___00List_zip_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
uint8_t l_List_elem___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_foldl___at___00Array_appendList_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_distance(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_distance___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_indexed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_indexed___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_check(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_check___boxed(lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_check_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_check_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_safeQ(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_safeQ___boxed(lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_newDiag(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_newDiag___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_columns(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_perms(lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_queens_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens(lean_object*);
static lean_once_cell_t l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0;
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place_spec__2(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_ADWH_Chapter15_Queens_place___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_ADWH_Chapter15_Queens_place___closed__0 = (const lean_object*)&l_ADWH_Chapter15_Queens_place___closed__0_value;
static const lean_array_object l_ADWH_Chapter15_Queens_place___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_ADWH_Chapter15_Queens_place___closed__1 = (const lean_object*)&l_ADWH_Chapter15_Queens_place___closed__1_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens2(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_distance(lean_object* v_a_1_, lean_object* v_b_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; lean_object* v___x_5_; 
v___x_3_ = lean_nat_sub(v_a_1_, v_b_2_);
v___x_4_ = lean_nat_sub(v_b_2_, v_a_1_);
v___x_5_ = lean_nat_add(v___x_3_, v___x_4_);
lean_dec(v___x_4_);
lean_dec(v___x_3_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_distance___boxed(lean_object* v_a_6_, lean_object* v_b_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = l_ADWH_Chapter15_Queens_distance(v_a_6_, v_b_7_);
lean_dec(v_b_7_);
lean_dec(v_a_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_indexed(lean_object* v_start_9_, lean_object* v_qs_10_){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; 
v___x_11_ = l_List_lengthTR___redArg(v_qs_10_);
v___x_12_ = lean_unsigned_to_nat(1u);
v___x_13_ = lean_nat_add(v_start_9_, v___x_11_);
v___x_14_ = lean_box(0);
v___x_15_ = l_List_range_x27TR_go(v___x_12_, v___x_11_, v___x_13_, v___x_14_);
v___x_16_ = l_List_zipWith___at___00List_zip_spec__0___redArg(v___x_15_, v_qs_10_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_indexed___boxed(lean_object* v_start_17_, lean_object* v_qs_18_){
_start:
{
lean_object* v_res_19_; 
v_res_19_ = l_ADWH_Chapter15_Queens_indexed(v_start_17_, v_qs_18_);
lean_dec(v_start_17_);
return v_res_19_;
}
}
LEAN_EXPORT uint8_t l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0(lean_object* v_head_20_, lean_object* v_x_21_){
_start:
{
if (lean_obj_tag(v_x_21_) == 0)
{
uint8_t v___x_22_; 
lean_dec_ref(v_head_20_);
v___x_22_ = 1;
return v___x_22_;
}
else
{
lean_object* v_head_23_; lean_object* v_tail_24_; lean_object* v_fst_25_; lean_object* v_snd_26_; lean_object* v_fst_27_; lean_object* v_snd_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; uint8_t v___x_34_; 
v_head_23_ = lean_ctor_get(v_x_21_, 0);
lean_inc(v_head_23_);
v_tail_24_ = lean_ctor_get(v_x_21_, 1);
lean_inc(v_tail_24_);
lean_dec_ref_known(v_x_21_, 2);
v_fst_25_ = lean_ctor_get(v_head_20_, 0);
v_snd_26_ = lean_ctor_get(v_head_20_, 1);
v_fst_27_ = lean_ctor_get(v_head_23_, 0);
lean_inc(v_fst_27_);
v_snd_28_ = lean_ctor_get(v_head_23_, 1);
lean_inc(v_snd_28_);
lean_dec(v_head_23_);
v___x_29_ = l_ADWH_Chapter15_Queens_distance(v_snd_26_, v_snd_28_);
lean_dec(v_snd_28_);
v___x_30_ = lean_nat_to_int(v___x_29_);
v___x_31_ = lean_nat_to_int(v_fst_27_);
lean_inc(v_fst_25_);
v___x_32_ = lean_nat_to_int(v_fst_25_);
v___x_33_ = lean_int_sub(v___x_31_, v___x_32_);
lean_dec(v___x_32_);
lean_dec(v___x_31_);
v___x_34_ = lean_int_dec_eq(v___x_30_, v___x_33_);
lean_dec(v___x_33_);
lean_dec(v___x_30_);
if (v___x_34_ == 0)
{
v_x_21_ = v_tail_24_;
goto _start;
}
else
{
uint8_t v___x_36_; 
lean_dec(v_tail_24_);
lean_dec_ref(v_head_20_);
v___x_36_ = 0;
return v___x_36_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0___boxed(lean_object* v_head_37_, lean_object* v_x_38_){
_start:
{
uint8_t v_res_39_; lean_object* v_r_40_; 
v_res_39_ = l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0(v_head_37_, v_x_38_);
v_r_40_ = lean_box(v_res_39_);
return v_r_40_;
}
}
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0(lean_object* v_head_41_, lean_object* v_x_42_){
_start:
{
if (lean_obj_tag(v_x_42_) == 0)
{
uint8_t v___x_43_; 
lean_dec_ref(v_head_41_);
v___x_43_ = 1;
return v___x_43_;
}
else
{
lean_object* v_head_44_; lean_object* v_tail_45_; lean_object* v_fst_46_; lean_object* v_snd_47_; lean_object* v_fst_48_; lean_object* v_snd_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; uint8_t v___x_55_; 
v_head_44_ = lean_ctor_get(v_x_42_, 0);
lean_inc(v_head_44_);
v_tail_45_ = lean_ctor_get(v_x_42_, 1);
lean_inc(v_tail_45_);
lean_dec_ref_known(v_x_42_, 2);
v_fst_46_ = lean_ctor_get(v_head_41_, 0);
v_snd_47_ = lean_ctor_get(v_head_41_, 1);
v_fst_48_ = lean_ctor_get(v_head_44_, 0);
lean_inc(v_fst_48_);
v_snd_49_ = lean_ctor_get(v_head_44_, 1);
lean_inc(v_snd_49_);
lean_dec(v_head_44_);
v___x_50_ = l_ADWH_Chapter15_Queens_distance(v_snd_47_, v_snd_49_);
lean_dec(v_snd_49_);
v___x_51_ = lean_nat_to_int(v___x_50_);
v___x_52_ = lean_nat_to_int(v_fst_48_);
lean_inc(v_fst_46_);
v___x_53_ = lean_nat_to_int(v_fst_46_);
v___x_54_ = lean_int_sub(v___x_52_, v___x_53_);
lean_dec(v___x_53_);
lean_dec(v___x_52_);
v___x_55_ = lean_int_dec_eq(v___x_51_, v___x_54_);
lean_dec(v___x_54_);
lean_dec(v___x_51_);
if (v___x_55_ == 0)
{
uint8_t v___x_56_; 
v___x_56_ = l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_check_spec__0_spec__0(v_head_41_, v_tail_45_);
return v___x_56_;
}
else
{
uint8_t v___x_57_; 
lean_dec(v_tail_45_);
lean_dec_ref(v_head_41_);
v___x_57_ = 0;
return v___x_57_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0___boxed(lean_object* v_head_58_, lean_object* v_x_59_){
_start:
{
uint8_t v_res_60_; lean_object* v_r_61_; 
v_res_60_ = l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0(v_head_58_, v_x_59_);
v_r_61_ = lean_box(v_res_60_);
return v_r_61_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_check(lean_object* v_x_62_){
_start:
{
if (lean_obj_tag(v_x_62_) == 0)
{
uint8_t v___x_63_; 
v___x_63_ = 1;
return v___x_63_;
}
else
{
lean_object* v_head_64_; lean_object* v_tail_65_; uint8_t v___x_66_; 
v_head_64_ = lean_ctor_get(v_x_62_, 0);
lean_inc(v_head_64_);
v_tail_65_ = lean_ctor_get(v_x_62_, 1);
lean_inc_n(v_tail_65_, 2);
lean_dec_ref_known(v_x_62_, 2);
v___x_66_ = l_List_all___at___00ADWH_Chapter15_Queens_check_spec__0(v_head_64_, v_tail_65_);
if (v___x_66_ == 0)
{
lean_dec(v_tail_65_);
return v___x_66_;
}
else
{
v_x_62_ = v_tail_65_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_check___boxed(lean_object* v_x_68_){
_start:
{
uint8_t v_res_69_; lean_object* v_r_70_; 
v_res_69_ = l_ADWH_Chapter15_Queens_check(v_x_68_);
v_r_70_ = lean_box(v_res_69_);
return v_r_70_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_check_match__1_splitter___redArg(lean_object* v_x_71_, lean_object* v_h__1_72_, lean_object* v_h__2_73_){
_start:
{
if (lean_obj_tag(v_x_71_) == 0)
{
lean_object* v___x_74_; lean_object* v___x_75_; 
lean_dec(v_h__2_73_);
v___x_74_ = lean_box(0);
v___x_75_ = lean_apply_1(v_h__1_72_, v___x_74_);
return v___x_75_;
}
else
{
lean_object* v_head_76_; lean_object* v_tail_77_; lean_object* v___x_78_; 
lean_dec(v_h__1_72_);
v_head_76_ = lean_ctor_get(v_x_71_, 0);
lean_inc(v_head_76_);
v_tail_77_ = lean_ctor_get(v_x_71_, 1);
lean_inc(v_tail_77_);
lean_dec_ref_known(v_x_71_, 2);
v___x_78_ = lean_apply_2(v_h__2_73_, v_head_76_, v_tail_77_);
return v___x_78_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_check_match__1_splitter(lean_object* v_motive_79_, lean_object* v_x_80_, lean_object* v_h__1_81_, lean_object* v_h__2_82_){
_start:
{
if (lean_obj_tag(v_x_80_) == 0)
{
lean_object* v___x_83_; lean_object* v___x_84_; 
lean_dec(v_h__2_82_);
v___x_83_ = lean_box(0);
v___x_84_ = lean_apply_1(v_h__1_81_, v___x_83_);
return v___x_84_;
}
else
{
lean_object* v_head_85_; lean_object* v_tail_86_; lean_object* v___x_87_; 
lean_dec(v_h__1_81_);
v_head_85_ = lean_ctor_get(v_x_80_, 0);
lean_inc(v_head_85_);
v_tail_86_ = lean_ctor_get(v_x_80_, 1);
lean_inc(v_tail_86_);
lean_dec_ref_known(v_x_80_, 2);
v___x_87_ = lean_apply_2(v_h__2_82_, v_head_85_, v_tail_86_);
return v___x_87_;
}
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_safeQ(lean_object* v_qs_88_){
_start:
{
lean_object* v___x_89_; lean_object* v___x_90_; uint8_t v___x_91_; 
v___x_89_ = lean_unsigned_to_nat(1u);
v___x_90_ = l_ADWH_Chapter15_Queens_indexed(v___x_89_, v_qs_88_);
v___x_91_ = l_ADWH_Chapter15_Queens_check(v___x_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_safeQ___boxed(lean_object* v_qs_92_){
_start:
{
uint8_t v_res_93_; lean_object* v_r_94_; 
v_res_93_ = l_ADWH_Chapter15_Queens_safeQ(v_qs_92_);
v_r_94_ = lean_box(v_res_93_);
return v_r_94_;
}
}
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0(lean_object* v_q_95_, lean_object* v_x_96_){
_start:
{
if (lean_obj_tag(v_x_96_) == 0)
{
uint8_t v___x_97_; 
v___x_97_ = 1;
return v___x_97_;
}
else
{
lean_object* v_head_98_; lean_object* v_tail_99_; lean_object* v_fst_100_; lean_object* v_snd_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v___x_104_; uint8_t v___x_105_; 
v_head_98_ = lean_ctor_get(v_x_96_, 0);
v_tail_99_ = lean_ctor_get(v_x_96_, 1);
v_fst_100_ = lean_ctor_get(v_head_98_, 0);
v_snd_101_ = lean_ctor_get(v_head_98_, 1);
v___x_102_ = l_ADWH_Chapter15_Queens_distance(v_q_95_, v_snd_101_);
v___x_103_ = lean_unsigned_to_nat(1u);
v___x_104_ = lean_nat_sub(v_fst_100_, v___x_103_);
v___x_105_ = lean_nat_dec_eq(v___x_102_, v___x_104_);
lean_dec(v___x_104_);
lean_dec(v___x_102_);
if (v___x_105_ == 0)
{
v_x_96_ = v_tail_99_;
goto _start;
}
else
{
uint8_t v___x_107_; 
v___x_107_ = 0;
return v___x_107_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0___boxed(lean_object* v_q_108_, lean_object* v_x_109_){
_start:
{
uint8_t v_res_110_; lean_object* v_r_111_; 
v_res_110_ = l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0(v_q_108_, v_x_109_);
lean_dec(v_x_109_);
lean_dec(v_q_108_);
v_r_111_ = lean_box(v_res_110_);
return v_r_111_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_newDiag(lean_object* v_q_112_, lean_object* v_qs_113_){
_start:
{
lean_object* v___x_114_; lean_object* v___x_115_; uint8_t v___x_116_; 
v___x_114_ = lean_unsigned_to_nat(2u);
v___x_115_ = l_ADWH_Chapter15_Queens_indexed(v___x_114_, v_qs_113_);
v___x_116_ = l_List_all___at___00ADWH_Chapter15_Queens_newDiag_spec__0(v_q_112_, v___x_115_);
lean_dec(v___x_115_);
return v___x_116_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_newDiag___boxed(lean_object* v_q_117_, lean_object* v_qs_118_){
_start:
{
uint8_t v_res_119_; lean_object* v_r_120_; 
v_res_119_ = l_ADWH_Chapter15_Queens_newDiag(v_q_117_, v_qs_118_);
lean_dec(v_q_117_);
v_r_120_ = lean_box(v_res_119_);
return v_r_120_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_columns(lean_object* v_n_121_){
_start:
{
lean_object* v___x_122_; lean_object* v___x_123_; lean_object* v___x_124_; lean_object* v___x_125_; 
v___x_122_ = lean_unsigned_to_nat(1u);
v___x_123_ = lean_nat_add(v___x_122_, v_n_121_);
v___x_124_ = lean_box(0);
v___x_125_ = l_List_range_x27TR_go(v___x_122_, v_n_121_, v___x_123_, v___x_124_);
return v___x_125_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_perms(lean_object* v_n_126_){
_start:
{
lean_object* v___x_127_; lean_object* v___x_128_; 
v___x_127_ = l_ADWH_Chapter15_Queens_columns(v_n_126_);
v___x_128_ = l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg(v___x_127_);
return v___x_128_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_queens_spec__0(lean_object* v_a_129_, lean_object* v_a_130_){
_start:
{
if (lean_obj_tag(v_a_129_) == 0)
{
lean_object* v___x_131_; 
v___x_131_ = l_List_reverse___redArg(v_a_130_);
return v___x_131_;
}
else
{
lean_object* v_head_132_; lean_object* v_tail_133_; lean_object* v___x_135_; uint8_t v_isShared_136_; uint8_t v_isSharedCheck_143_; 
v_head_132_ = lean_ctor_get(v_a_129_, 0);
v_tail_133_ = lean_ctor_get(v_a_129_, 1);
v_isSharedCheck_143_ = !lean_is_exclusive(v_a_129_);
if (v_isSharedCheck_143_ == 0)
{
v___x_135_ = v_a_129_;
v_isShared_136_ = v_isSharedCheck_143_;
goto v_resetjp_134_;
}
else
{
lean_inc(v_tail_133_);
lean_inc(v_head_132_);
lean_dec(v_a_129_);
v___x_135_ = lean_box(0);
v_isShared_136_ = v_isSharedCheck_143_;
goto v_resetjp_134_;
}
v_resetjp_134_:
{
uint8_t v___x_137_; 
lean_inc(v_head_132_);
v___x_137_ = l_ADWH_Chapter15_Queens_safeQ(v_head_132_);
if (v___x_137_ == 0)
{
lean_del_object(v___x_135_);
lean_dec(v_head_132_);
v_a_129_ = v_tail_133_;
goto _start;
}
else
{
lean_object* v___x_140_; 
if (v_isShared_136_ == 0)
{
lean_ctor_set(v___x_135_, 1, v_a_130_);
v___x_140_ = v___x_135_;
goto v_reusejp_139_;
}
else
{
lean_object* v_reuseFailAlloc_142_; 
v_reuseFailAlloc_142_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_142_, 0, v_head_132_);
lean_ctor_set(v_reuseFailAlloc_142_, 1, v_a_130_);
v___x_140_ = v_reuseFailAlloc_142_;
goto v_reusejp_139_;
}
v_reusejp_139_:
{
v_a_129_ = v_tail_133_;
v_a_130_ = v___x_140_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens(lean_object* v_n_144_){
_start:
{
lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; 
v___x_145_ = l_ADWH_Chapter15_Queens_perms(v_n_144_);
v___x_146_ = lean_box(0);
v___x_147_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_queens_spec__0(v___x_145_, v___x_146_);
return v___x_147_;
}
}
static lean_object* _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0(void){
_start:
{
lean_object* v___x_148_; lean_object* v___f_149_; 
v___x_148_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___f_149_ = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_149_, 0, v___x_148_);
return v___f_149_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0(lean_object* v_q_150_, lean_object* v_a_151_, lean_object* v_a_152_){
_start:
{
if (lean_obj_tag(v_a_151_) == 0)
{
lean_object* v___x_153_; 
lean_dec(v_q_150_);
v___x_153_ = l_List_reverse___redArg(v_a_152_);
return v___x_153_;
}
else
{
lean_object* v_head_154_; lean_object* v_tail_155_; lean_object* v___x_157_; uint8_t v_isShared_158_; uint8_t v_isSharedCheck_168_; 
v_head_154_ = lean_ctor_get(v_a_151_, 0);
v_tail_155_ = lean_ctor_get(v_a_151_, 1);
v_isSharedCheck_168_ = !lean_is_exclusive(v_a_151_);
if (v_isSharedCheck_168_ == 0)
{
v___x_157_ = v_a_151_;
v_isShared_158_ = v_isSharedCheck_168_;
goto v_resetjp_156_;
}
else
{
lean_inc(v_tail_155_);
lean_inc(v_head_154_);
lean_dec(v_a_151_);
v___x_157_ = lean_box(0);
v_isShared_158_ = v_isSharedCheck_168_;
goto v_resetjp_156_;
}
v_resetjp_156_:
{
lean_object* v___f_159_; uint8_t v___x_160_; 
v___f_159_ = lean_obj_once(&l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0, &l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0_once, _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0___closed__0);
lean_inc(v_head_154_);
lean_inc(v_q_150_);
v___x_160_ = l_List_elem___redArg(v___f_159_, v_q_150_, v_head_154_);
if (v___x_160_ == 0)
{
uint8_t v___x_161_; 
lean_inc(v_head_154_);
v___x_161_ = l_ADWH_Chapter15_Queens_newDiag(v_q_150_, v_head_154_);
if (v___x_161_ == 0)
{
lean_del_object(v___x_157_);
lean_dec(v_head_154_);
v_a_151_ = v_tail_155_;
goto _start;
}
else
{
lean_object* v___x_164_; 
if (v_isShared_158_ == 0)
{
lean_ctor_set(v___x_157_, 1, v_a_152_);
v___x_164_ = v___x_157_;
goto v_reusejp_163_;
}
else
{
lean_object* v_reuseFailAlloc_166_; 
v_reuseFailAlloc_166_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_166_, 0, v_head_154_);
lean_ctor_set(v_reuseFailAlloc_166_, 1, v_a_152_);
v___x_164_ = v_reuseFailAlloc_166_;
goto v_reusejp_163_;
}
v_reusejp_163_:
{
v_a_151_ = v_tail_155_;
v_a_152_ = v___x_164_;
goto _start;
}
}
}
else
{
lean_del_object(v___x_157_);
lean_dec(v_head_154_);
v_a_151_ = v_tail_155_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place_spec__1(lean_object* v_q_169_, lean_object* v_a_170_, lean_object* v_a_171_){
_start:
{
if (lean_obj_tag(v_a_170_) == 0)
{
lean_object* v___x_172_; 
lean_dec(v_q_169_);
v___x_172_ = l_List_reverse___redArg(v_a_171_);
return v___x_172_;
}
else
{
lean_object* v_head_173_; lean_object* v_tail_174_; lean_object* v___x_176_; uint8_t v_isShared_177_; uint8_t v_isSharedCheck_183_; 
v_head_173_ = lean_ctor_get(v_a_170_, 0);
v_tail_174_ = lean_ctor_get(v_a_170_, 1);
v_isSharedCheck_183_ = !lean_is_exclusive(v_a_170_);
if (v_isSharedCheck_183_ == 0)
{
v___x_176_ = v_a_170_;
v_isShared_177_ = v_isSharedCheck_183_;
goto v_resetjp_175_;
}
else
{
lean_inc(v_tail_174_);
lean_inc(v_head_173_);
lean_dec(v_a_170_);
v___x_176_ = lean_box(0);
v_isShared_177_ = v_isSharedCheck_183_;
goto v_resetjp_175_;
}
v_resetjp_175_:
{
lean_object* v___x_179_; 
lean_inc(v_q_169_);
if (v_isShared_177_ == 0)
{
lean_ctor_set(v___x_176_, 1, v_head_173_);
lean_ctor_set(v___x_176_, 0, v_q_169_);
v___x_179_ = v___x_176_;
goto v_reusejp_178_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v_q_169_);
lean_ctor_set(v_reuseFailAlloc_182_, 1, v_head_173_);
v___x_179_ = v_reuseFailAlloc_182_;
goto v_reusejp_178_;
}
v_reusejp_178_:
{
lean_object* v___x_180_; 
v___x_180_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_180_, 0, v___x_179_);
lean_ctor_set(v___x_180_, 1, v_a_171_);
v_a_170_ = v_tail_174_;
v_a_171_ = v___x_180_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place_spec__2(lean_object* v_qss_184_, lean_object* v_a_185_, lean_object* v_a_186_){
_start:
{
if (lean_obj_tag(v_a_185_) == 0)
{
lean_object* v___x_187_; 
lean_dec(v_qss_184_);
v___x_187_ = lean_array_to_list(v_a_186_);
return v___x_187_;
}
else
{
lean_object* v_head_188_; lean_object* v_tail_189_; lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; 
v_head_188_ = lean_ctor_get(v_a_185_, 0);
lean_inc_n(v_head_188_, 2);
v_tail_189_ = lean_ctor_get(v_a_185_, 1);
lean_inc(v_tail_189_);
lean_dec_ref_known(v_a_185_, 2);
v___x_190_ = lean_box(0);
lean_inc(v_qss_184_);
v___x_191_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place_spec__0(v_head_188_, v_qss_184_, v___x_190_);
v___x_192_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place_spec__1(v_head_188_, v___x_191_, v___x_190_);
v___x_193_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_186_, v___x_192_);
v_a_185_ = v_tail_189_;
v_a_186_ = v___x_193_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place(lean_object* v_n_199_, lean_object* v_x_200_){
_start:
{
lean_object* v_zero_201_; uint8_t v_isZero_202_; 
v_zero_201_ = lean_unsigned_to_nat(0u);
v_isZero_202_ = lean_nat_dec_eq(v_x_200_, v_zero_201_);
if (v_isZero_202_ == 1)
{
lean_object* v___x_203_; 
lean_dec(v_n_199_);
v___x_203_ = ((lean_object*)(l_ADWH_Chapter15_Queens_place___closed__0));
return v___x_203_;
}
else
{
lean_object* v_one_204_; lean_object* v_n_205_; lean_object* v_qss_206_; lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_209_; 
v_one_204_ = lean_unsigned_to_nat(1u);
v_n_205_ = lean_nat_sub(v_x_200_, v_one_204_);
lean_inc(v_n_199_);
v_qss_206_ = l_ADWH_Chapter15_Queens_place(v_n_199_, v_n_205_);
lean_dec(v_n_205_);
v___x_207_ = l_ADWH_Chapter15_Queens_columns(v_n_199_);
v___x_208_ = ((lean_object*)(l_ADWH_Chapter15_Queens_place___closed__1));
v___x_209_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place_spec__2(v_qss_206_, v___x_207_, v___x_208_);
return v___x_209_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place___boxed(lean_object* v_n_210_, lean_object* v_x_211_){
_start:
{
lean_object* v_res_212_; 
v_res_212_ = l_ADWH_Chapter15_Queens_place(v_n_210_, v_x_211_);
lean_dec(v_x_211_);
return v_res_212_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___redArg(lean_object* v_x_213_, lean_object* v_h__1_214_, lean_object* v_h__2_215_){
_start:
{
lean_object* v_zero_216_; uint8_t v_isZero_217_; 
v_zero_216_ = lean_unsigned_to_nat(0u);
v_isZero_217_ = lean_nat_dec_eq(v_x_213_, v_zero_216_);
if (v_isZero_217_ == 1)
{
lean_object* v___x_218_; lean_object* v___x_219_; 
lean_dec(v_h__2_215_);
v___x_218_ = lean_box(0);
v___x_219_ = lean_apply_1(v_h__1_214_, v___x_218_);
return v___x_219_;
}
else
{
lean_object* v_one_220_; lean_object* v_n_221_; lean_object* v___x_222_; 
lean_dec(v_h__1_214_);
v_one_220_ = lean_unsigned_to_nat(1u);
v_n_221_ = lean_nat_sub(v_x_213_, v_one_220_);
v___x_222_ = lean_apply_1(v_h__2_215_, v_n_221_);
return v___x_222_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___redArg___boxed(lean_object* v_x_223_, lean_object* v_h__1_224_, lean_object* v_h__2_225_){
_start:
{
lean_object* v_res_226_; 
v_res_226_ = l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___redArg(v_x_223_, v_h__1_224_, v_h__2_225_);
lean_dec(v_x_223_);
return v_res_226_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter(lean_object* v_motive_227_, lean_object* v_x_228_, lean_object* v_h__1_229_, lean_object* v_h__2_230_){
_start:
{
lean_object* v_zero_231_; uint8_t v_isZero_232_; 
v_zero_231_ = lean_unsigned_to_nat(0u);
v_isZero_232_ = lean_nat_dec_eq(v_x_228_, v_zero_231_);
if (v_isZero_232_ == 1)
{
lean_object* v___x_233_; lean_object* v___x_234_; 
lean_dec(v_h__2_230_);
v___x_233_ = lean_box(0);
v___x_234_ = lean_apply_1(v_h__1_229_, v___x_233_);
return v___x_234_;
}
else
{
lean_object* v_one_235_; lean_object* v_n_236_; lean_object* v___x_237_; 
lean_dec(v_h__1_229_);
v_one_235_ = lean_unsigned_to_nat(1u);
v_n_236_ = lean_nat_sub(v_x_228_, v_one_235_);
v___x_237_ = lean_apply_1(v_h__2_230_, v_n_236_);
return v___x_237_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter___boxed(lean_object* v_motive_238_, lean_object* v_x_239_, lean_object* v_h__1_240_, lean_object* v_h__2_241_){
_start:
{
lean_object* v_res_242_; 
v_res_242_ = l___private_ADWH_Chapter15_Queens_0__ADWH_Chapter15_Queens_place_match__1_splitter(v_motive_238_, v_x_239_, v_h__1_240_, v_h__2_241_);
lean_dec(v_x_239_);
return v_res_242_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens2(lean_object* v_n_243_){
_start:
{
lean_object* v___x_244_; 
lean_inc(v_n_243_);
v___x_244_ = l_ADWH_Chapter15_Queens_place(v_n_243_, v_n_243_);
lean_dec(v_n_243_);
return v___x_244_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter01_Permutations(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter15_Queens(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter01_Permutations(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
