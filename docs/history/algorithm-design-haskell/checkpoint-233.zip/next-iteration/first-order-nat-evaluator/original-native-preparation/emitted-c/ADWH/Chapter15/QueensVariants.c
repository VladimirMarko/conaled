// Lean compiler output
// Module: ADWH.Chapter15.QueensVariants
// Imports: public import Init public meta import Init public import ADWH.Chapter15.Queens
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_ADWH_Chapter15_Queens_columns(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
uint8_t l_List_elem___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
lean_object* l_List_foldl___at___00Array_appendList_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter15_Queens_indexed(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter15_Queens_distance(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t l_ADWH_Chapter15_Queens_newDiag(lean_object*, lean_object*);
lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place_spec__1(lean_object*, lean_object*, lean_object*);
uint8_t l_List_nodupDecidable___redArg(lean_object*, lean_object*);
uint8_t l_ADWH_Chapter15_Queens_safeQ(lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_newDiag1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_newDiag1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_good(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_good___boxed(lean_object*);
static const lean_ctor_object l_ADWH_Chapter15_Queens_words___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_ADWH_Chapter15_Queens_words___closed__0 = (const lean_object*)&l_ADWH_Chapter15_Queens_words___closed__0_value;
static const lean_array_object l_ADWH_Chapter15_Queens_words___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_ADWH_Chapter15_Queens_words___closed__1 = (const lean_object*)&l_ADWH_Chapter15_Queens_words___closed__1_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_words(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_words___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__1(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0;
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_placePerms_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_placePerms(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_placePerms___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_perms2(lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens1(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place4_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place4(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place4___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_queens4_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens4(lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0(lean_object* v_q_1_, lean_object* v_r_2_, lean_object* v_x_3_){
_start:
{
if (lean_obj_tag(v_x_3_) == 0)
{
uint8_t v___x_4_; 
lean_dec(v_r_2_);
v___x_4_ = 1;
return v___x_4_;
}
else
{
lean_object* v_head_5_; lean_object* v_tail_6_; lean_object* v_fst_7_; lean_object* v_snd_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; uint8_t v___x_14_; 
v_head_5_ = lean_ctor_get(v_x_3_, 0);
lean_inc(v_head_5_);
v_tail_6_ = lean_ctor_get(v_x_3_, 1);
lean_inc(v_tail_6_);
lean_dec_ref_known(v_x_3_, 2);
v_fst_7_ = lean_ctor_get(v_head_5_, 0);
lean_inc(v_fst_7_);
v_snd_8_ = lean_ctor_get(v_head_5_, 1);
lean_inc(v_snd_8_);
lean_dec(v_head_5_);
v___x_9_ = l_ADWH_Chapter15_Queens_distance(v_q_1_, v_snd_8_);
lean_dec(v_snd_8_);
v___x_10_ = lean_nat_to_int(v___x_9_);
lean_inc(v_r_2_);
v___x_11_ = lean_nat_to_int(v_r_2_);
v___x_12_ = lean_nat_to_int(v_fst_7_);
v___x_13_ = lean_int_sub(v___x_11_, v___x_12_);
lean_dec(v___x_12_);
lean_dec(v___x_11_);
v___x_14_ = lean_int_dec_eq(v___x_10_, v___x_13_);
lean_dec(v___x_13_);
lean_dec(v___x_10_);
if (v___x_14_ == 0)
{
v_x_3_ = v_tail_6_;
goto _start;
}
else
{
uint8_t v___x_16_; 
lean_dec(v_tail_6_);
lean_dec(v_r_2_);
v___x_16_ = 0;
return v___x_16_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0___boxed(lean_object* v_q_17_, lean_object* v_r_18_, lean_object* v_x_19_){
_start:
{
uint8_t v_res_20_; lean_object* v_r_21_; 
v_res_20_ = l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0(v_q_17_, v_r_18_, v_x_19_);
lean_dec(v_q_17_);
v_r_21_ = lean_box(v_res_20_);
return v_r_21_;
}
}
LEAN_EXPORT uint8_t l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0(lean_object* v_q_22_, lean_object* v_r_23_, lean_object* v_x_24_){
_start:
{
if (lean_obj_tag(v_x_24_) == 0)
{
uint8_t v___x_25_; 
lean_dec(v_r_23_);
v___x_25_ = 1;
return v___x_25_;
}
else
{
lean_object* v_head_26_; lean_object* v_tail_27_; lean_object* v_fst_28_; lean_object* v_snd_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; uint8_t v___x_35_; 
v_head_26_ = lean_ctor_get(v_x_24_, 0);
lean_inc(v_head_26_);
v_tail_27_ = lean_ctor_get(v_x_24_, 1);
lean_inc(v_tail_27_);
lean_dec_ref_known(v_x_24_, 2);
v_fst_28_ = lean_ctor_get(v_head_26_, 0);
lean_inc(v_fst_28_);
v_snd_29_ = lean_ctor_get(v_head_26_, 1);
lean_inc(v_snd_29_);
lean_dec(v_head_26_);
v___x_30_ = l_ADWH_Chapter15_Queens_distance(v_q_22_, v_snd_29_);
lean_dec(v_snd_29_);
v___x_31_ = lean_nat_to_int(v___x_30_);
lean_inc(v_r_23_);
v___x_32_ = lean_nat_to_int(v_r_23_);
v___x_33_ = lean_nat_to_int(v_fst_28_);
v___x_34_ = lean_int_sub(v___x_32_, v___x_33_);
lean_dec(v___x_33_);
lean_dec(v___x_32_);
v___x_35_ = lean_int_dec_eq(v___x_31_, v___x_34_);
lean_dec(v___x_34_);
lean_dec(v___x_31_);
if (v___x_35_ == 0)
{
uint8_t v___x_36_; 
v___x_36_ = l_List_all___at___00List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0_spec__0(v_q_22_, v_r_23_, v_tail_27_);
return v___x_36_;
}
else
{
uint8_t v___x_37_; 
lean_dec(v_tail_27_);
lean_dec(v_r_23_);
v___x_37_ = 0;
return v___x_37_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0___boxed(lean_object* v_q_38_, lean_object* v_r_39_, lean_object* v_x_40_){
_start:
{
uint8_t v_res_41_; lean_object* v_r_42_; 
v_res_41_ = l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0(v_q_38_, v_r_39_, v_x_40_);
lean_dec(v_q_38_);
v_r_42_ = lean_box(v_res_41_);
return v_r_42_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_newDiag1(lean_object* v_r_43_, lean_object* v_q_44_, lean_object* v_qs_45_){
_start:
{
lean_object* v___x_46_; lean_object* v___x_47_; uint8_t v___x_48_; 
v___x_46_ = lean_unsigned_to_nat(1u);
v___x_47_ = l_ADWH_Chapter15_Queens_indexed(v___x_46_, v_qs_45_);
v___x_48_ = l_List_all___at___00ADWH_Chapter15_Queens_newDiag1_spec__0(v_q_44_, v_r_43_, v___x_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_newDiag1___boxed(lean_object* v_r_49_, lean_object* v_q_50_, lean_object* v_qs_51_){
_start:
{
uint8_t v_res_52_; lean_object* v_r_53_; 
v_res_52_ = l_ADWH_Chapter15_Queens_newDiag1(v_r_49_, v_q_50_, v_qs_51_);
lean_dec(v_q_50_);
v_r_53_ = lean_box(v_res_52_);
return v_r_53_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_good(lean_object* v_qs_54_){
_start:
{
lean_object* v___x_55_; uint8_t v___x_56_; 
v___x_55_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
lean_inc(v_qs_54_);
v___x_56_ = l_List_nodupDecidable___redArg(v___x_55_, v_qs_54_);
if (v___x_56_ == 0)
{
lean_dec(v_qs_54_);
return v___x_56_;
}
else
{
uint8_t v___x_57_; 
v___x_57_ = l_ADWH_Chapter15_Queens_safeQ(v_qs_54_);
return v___x_57_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_good___boxed(lean_object* v_qs_58_){
_start:
{
uint8_t v_res_59_; lean_object* v_r_60_; 
v_res_59_ = l_ADWH_Chapter15_Queens_good(v_qs_58_);
v_r_60_ = lean_box(v_res_59_);
return v_r_60_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_words(lean_object* v_n_65_, lean_object* v_x_66_){
_start:
{
lean_object* v_zero_67_; uint8_t v_isZero_68_; 
v_zero_67_ = lean_unsigned_to_nat(0u);
v_isZero_68_ = lean_nat_dec_eq(v_x_66_, v_zero_67_);
if (v_isZero_68_ == 1)
{
lean_object* v___x_69_; 
lean_dec(v_n_65_);
v___x_69_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__0));
return v___x_69_;
}
else
{
lean_object* v_one_70_; lean_object* v_n_71_; lean_object* v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; 
v_one_70_ = lean_unsigned_to_nat(1u);
v_n_71_ = lean_nat_sub(v_x_66_, v_one_70_);
lean_inc(v_n_65_);
v___x_72_ = l_ADWH_Chapter15_Queens_columns(v_n_65_);
v___x_73_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__1));
v___x_74_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0(v_n_65_, v_n_71_, v___x_72_, v___x_73_);
lean_dec(v_n_71_);
return v___x_74_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0(lean_object* v_n_75_, lean_object* v_n_76_, lean_object* v_a_77_, lean_object* v_a_78_){
_start:
{
if (lean_obj_tag(v_a_77_) == 0)
{
lean_object* v___x_79_; 
lean_dec(v_n_75_);
v___x_79_ = lean_array_to_list(v_a_78_);
return v___x_79_;
}
else
{
lean_object* v_head_80_; lean_object* v_tail_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; 
v_head_80_ = lean_ctor_get(v_a_77_, 0);
lean_inc(v_head_80_);
v_tail_81_ = lean_ctor_get(v_a_77_, 1);
lean_inc(v_tail_81_);
lean_dec_ref_known(v_a_77_, 2);
lean_inc(v_n_75_);
v___x_82_ = l_ADWH_Chapter15_Queens_words(v_n_75_, v_n_76_);
v___x_83_ = lean_box(0);
v___x_84_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place_spec__1(v_head_80_, v___x_82_, v___x_83_);
v___x_85_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_78_, v___x_84_);
v_a_77_ = v_tail_81_;
v_a_78_ = v___x_85_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0___boxed(lean_object* v_n_87_, lean_object* v_n_88_, lean_object* v_a_89_, lean_object* v_a_90_){
_start:
{
lean_object* v_res_91_; 
v_res_91_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_words_spec__0(v_n_87_, v_n_88_, v_a_89_, v_a_90_);
lean_dec(v_n_88_);
return v_res_91_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_words___boxed(lean_object* v_n_92_, lean_object* v_x_93_){
_start:
{
lean_object* v_res_94_; 
v_res_94_ = l_ADWH_Chapter15_Queens_words(v_n_92_, v_x_93_);
lean_dec(v_x_93_);
return v_res_94_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___redArg(lean_object* v_x_95_, lean_object* v_h__1_96_, lean_object* v_h__2_97_){
_start:
{
lean_object* v_zero_98_; uint8_t v_isZero_99_; 
v_zero_98_ = lean_unsigned_to_nat(0u);
v_isZero_99_ = lean_nat_dec_eq(v_x_95_, v_zero_98_);
if (v_isZero_99_ == 1)
{
lean_object* v___x_100_; lean_object* v___x_101_; 
lean_dec(v_h__2_97_);
v___x_100_ = lean_box(0);
v___x_101_ = lean_apply_1(v_h__1_96_, v___x_100_);
return v___x_101_;
}
else
{
lean_object* v_one_102_; lean_object* v_n_103_; lean_object* v___x_104_; 
lean_dec(v_h__1_96_);
v_one_102_ = lean_unsigned_to_nat(1u);
v_n_103_ = lean_nat_sub(v_x_95_, v_one_102_);
v___x_104_ = lean_apply_1(v_h__2_97_, v_n_103_);
return v___x_104_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___redArg___boxed(lean_object* v_x_105_, lean_object* v_h__1_106_, lean_object* v_h__2_107_){
_start:
{
lean_object* v_res_108_; 
v_res_108_ = l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___redArg(v_x_105_, v_h__1_106_, v_h__2_107_);
lean_dec(v_x_105_);
return v_res_108_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter(lean_object* v_motive_109_, lean_object* v_x_110_, lean_object* v_h__1_111_, lean_object* v_h__2_112_){
_start:
{
lean_object* v_zero_113_; uint8_t v_isZero_114_; 
v_zero_113_ = lean_unsigned_to_nat(0u);
v_isZero_114_ = lean_nat_dec_eq(v_x_110_, v_zero_113_);
if (v_isZero_114_ == 1)
{
lean_object* v___x_115_; lean_object* v___x_116_; 
lean_dec(v_h__2_112_);
v___x_115_ = lean_box(0);
v___x_116_ = lean_apply_1(v_h__1_111_, v___x_115_);
return v___x_116_;
}
else
{
lean_object* v_one_117_; lean_object* v_n_118_; lean_object* v___x_119_; 
lean_dec(v_h__1_111_);
v_one_117_ = lean_unsigned_to_nat(1u);
v_n_118_ = lean_nat_sub(v_x_110_, v_one_117_);
v___x_119_ = lean_apply_1(v_h__2_112_, v_n_118_);
return v___x_119_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter___boxed(lean_object* v_motive_120_, lean_object* v_x_121_, lean_object* v_h__1_122_, lean_object* v_h__2_123_){
_start:
{
lean_object* v_res_124_; 
v_res_124_ = l___private_ADWH_Chapter15_QueensVariants_0__ADWH_Chapter15_Queens_words_match__1_splitter(v_motive_120_, v_x_121_, v_h__1_122_, v_h__2_123_);
lean_dec(v_x_121_);
return v_res_124_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__1(lean_object* v_qs_125_, lean_object* v_a_126_, lean_object* v_a_127_){
_start:
{
if (lean_obj_tag(v_a_126_) == 0)
{
lean_object* v___x_128_; 
lean_dec(v_qs_125_);
v___x_128_ = l_List_reverse___redArg(v_a_127_);
return v___x_128_;
}
else
{
lean_object* v_head_129_; lean_object* v_tail_130_; lean_object* v___x_132_; uint8_t v_isShared_133_; uint8_t v_isSharedCheck_141_; 
v_head_129_ = lean_ctor_get(v_a_126_, 0);
v_tail_130_ = lean_ctor_get(v_a_126_, 1);
v_isSharedCheck_141_ = !lean_is_exclusive(v_a_126_);
if (v_isSharedCheck_141_ == 0)
{
v___x_132_ = v_a_126_;
v_isShared_133_ = v_isSharedCheck_141_;
goto v_resetjp_131_;
}
else
{
lean_inc(v_tail_130_);
lean_inc(v_head_129_);
lean_dec(v_a_126_);
v___x_132_ = lean_box(0);
v_isShared_133_ = v_isSharedCheck_141_;
goto v_resetjp_131_;
}
v_resetjp_131_:
{
lean_object* v___x_134_; lean_object* v___x_136_; 
v___x_134_ = lean_box(0);
if (v_isShared_133_ == 0)
{
lean_ctor_set(v___x_132_, 1, v___x_134_);
v___x_136_ = v___x_132_;
goto v_reusejp_135_;
}
else
{
lean_object* v_reuseFailAlloc_140_; 
v_reuseFailAlloc_140_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_140_, 0, v_head_129_);
lean_ctor_set(v_reuseFailAlloc_140_, 1, v___x_134_);
v___x_136_ = v_reuseFailAlloc_140_;
goto v_reusejp_135_;
}
v_reusejp_135_:
{
lean_object* v___x_137_; lean_object* v___x_138_; 
lean_inc(v_qs_125_);
v___x_137_ = l_List_appendTR___redArg(v_qs_125_, v___x_136_);
v___x_138_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_138_, 0, v___x_137_);
lean_ctor_set(v___x_138_, 1, v_a_127_);
v_a_126_ = v_tail_130_;
v_a_127_ = v___x_138_;
goto _start;
}
}
}
}
}
static lean_object* _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0(void){
_start:
{
lean_object* v___x_142_; lean_object* v___f_143_; 
v___x_142_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___f_143_ = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_143_, 0, v___x_142_);
return v___f_143_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0(lean_object* v_qs_144_, lean_object* v_a_145_, lean_object* v_a_146_){
_start:
{
if (lean_obj_tag(v_a_145_) == 0)
{
lean_object* v___x_147_; 
lean_dec(v_qs_144_);
v___x_147_ = l_List_reverse___redArg(v_a_146_);
return v___x_147_;
}
else
{
lean_object* v_head_148_; lean_object* v_tail_149_; lean_object* v___x_151_; uint8_t v_isShared_152_; uint8_t v_isSharedCheck_160_; 
v_head_148_ = lean_ctor_get(v_a_145_, 0);
v_tail_149_ = lean_ctor_get(v_a_145_, 1);
v_isSharedCheck_160_ = !lean_is_exclusive(v_a_145_);
if (v_isSharedCheck_160_ == 0)
{
v___x_151_ = v_a_145_;
v_isShared_152_ = v_isSharedCheck_160_;
goto v_resetjp_150_;
}
else
{
lean_inc(v_tail_149_);
lean_inc(v_head_148_);
lean_dec(v_a_145_);
v___x_151_ = lean_box(0);
v_isShared_152_ = v_isSharedCheck_160_;
goto v_resetjp_150_;
}
v_resetjp_150_:
{
lean_object* v___f_153_; uint8_t v___x_154_; 
v___f_153_ = lean_obj_once(&l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0, &l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0_once, _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0);
lean_inc(v_qs_144_);
lean_inc(v_head_148_);
v___x_154_ = l_List_elem___redArg(v___f_153_, v_head_148_, v_qs_144_);
if (v___x_154_ == 0)
{
lean_object* v___x_156_; 
if (v_isShared_152_ == 0)
{
lean_ctor_set(v___x_151_, 1, v_a_146_);
v___x_156_ = v___x_151_;
goto v_reusejp_155_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v_head_148_);
lean_ctor_set(v_reuseFailAlloc_158_, 1, v_a_146_);
v___x_156_ = v_reuseFailAlloc_158_;
goto v_reusejp_155_;
}
v_reusejp_155_:
{
v_a_145_ = v_tail_149_;
v_a_146_ = v___x_156_;
goto _start;
}
}
else
{
lean_del_object(v___x_151_);
lean_dec(v_head_148_);
v_a_145_ = v_tail_149_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_placePerms_spec__2(lean_object* v_n_161_, lean_object* v_a_162_, lean_object* v_a_163_){
_start:
{
if (lean_obj_tag(v_a_162_) == 0)
{
lean_object* v___x_164_; 
lean_dec(v_n_161_);
v___x_164_ = lean_array_to_list(v_a_163_);
return v___x_164_;
}
else
{
lean_object* v_head_165_; lean_object* v_tail_166_; lean_object* v___x_167_; lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; 
v_head_165_ = lean_ctor_get(v_a_162_, 0);
lean_inc_n(v_head_165_, 2);
v_tail_166_ = lean_ctor_get(v_a_162_, 1);
lean_inc(v_tail_166_);
lean_dec_ref_known(v_a_162_, 2);
lean_inc(v_n_161_);
v___x_167_ = l_ADWH_Chapter15_Queens_columns(v_n_161_);
v___x_168_ = lean_box(0);
v___x_169_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0(v_head_165_, v___x_167_, v___x_168_);
v___x_170_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__1(v_head_165_, v___x_169_, v___x_168_);
v___x_171_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_163_, v___x_170_);
v_a_162_ = v_tail_166_;
v_a_163_ = v___x_171_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_placePerms(lean_object* v_n_173_, lean_object* v_x_174_){
_start:
{
lean_object* v_zero_175_; uint8_t v_isZero_176_; 
v_zero_175_ = lean_unsigned_to_nat(0u);
v_isZero_176_ = lean_nat_dec_eq(v_x_174_, v_zero_175_);
if (v_isZero_176_ == 1)
{
lean_object* v___x_177_; 
lean_dec(v_n_173_);
v___x_177_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__0));
return v___x_177_;
}
else
{
lean_object* v_one_178_; lean_object* v_n_179_; lean_object* v___x_180_; lean_object* v___x_181_; lean_object* v___x_182_; 
v_one_178_ = lean_unsigned_to_nat(1u);
v_n_179_ = lean_nat_sub(v_x_174_, v_one_178_);
lean_inc(v_n_173_);
v___x_180_ = l_ADWH_Chapter15_Queens_placePerms(v_n_173_, v_n_179_);
lean_dec(v_n_179_);
v___x_181_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__1));
v___x_182_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_placePerms_spec__2(v_n_173_, v___x_180_, v___x_181_);
return v___x_182_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_placePerms___boxed(lean_object* v_n_183_, lean_object* v_x_184_){
_start:
{
lean_object* v_res_185_; 
v_res_185_ = l_ADWH_Chapter15_Queens_placePerms(v_n_183_, v_x_184_);
lean_dec(v_x_184_);
return v_res_185_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_perms2(lean_object* v_n_186_){
_start:
{
lean_object* v___x_187_; 
lean_inc(v_n_186_);
v___x_187_ = l_ADWH_Chapter15_Queens_placePerms(v_n_186_, v_n_186_);
lean_dec(v_n_186_);
return v___x_187_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0(lean_object* v_qs_188_, lean_object* v_n_189_, lean_object* v_a_190_, lean_object* v_a_191_){
_start:
{
if (lean_obj_tag(v_a_190_) == 0)
{
lean_object* v___x_192_; 
lean_dec(v_qs_188_);
v___x_192_ = l_List_reverse___redArg(v_a_191_);
return v___x_192_;
}
else
{
lean_object* v_head_193_; lean_object* v_tail_194_; lean_object* v___x_196_; uint8_t v_isShared_197_; uint8_t v_isSharedCheck_209_; 
v_head_193_ = lean_ctor_get(v_a_190_, 0);
v_tail_194_ = lean_ctor_get(v_a_190_, 1);
v_isSharedCheck_209_ = !lean_is_exclusive(v_a_190_);
if (v_isSharedCheck_209_ == 0)
{
v___x_196_ = v_a_190_;
v_isShared_197_ = v_isSharedCheck_209_;
goto v_resetjp_195_;
}
else
{
lean_inc(v_tail_194_);
lean_inc(v_head_193_);
lean_dec(v_a_190_);
v___x_196_ = lean_box(0);
v_isShared_197_ = v_isSharedCheck_209_;
goto v_resetjp_195_;
}
v_resetjp_195_:
{
lean_object* v___f_198_; uint8_t v___x_199_; 
v___f_198_ = lean_obj_once(&l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0, &l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0_once, _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0);
lean_inc(v_qs_188_);
lean_inc(v_head_193_);
v___x_199_ = l_List_elem___redArg(v___f_198_, v_head_193_, v_qs_188_);
if (v___x_199_ == 0)
{
lean_object* v___x_200_; lean_object* v___x_201_; uint8_t v___x_202_; 
v___x_200_ = lean_unsigned_to_nat(1u);
v___x_201_ = lean_nat_add(v_n_189_, v___x_200_);
lean_inc(v_qs_188_);
v___x_202_ = l_ADWH_Chapter15_Queens_newDiag1(v___x_201_, v_head_193_, v_qs_188_);
if (v___x_202_ == 0)
{
lean_del_object(v___x_196_);
lean_dec(v_head_193_);
v_a_190_ = v_tail_194_;
goto _start;
}
else
{
lean_object* v___x_205_; 
if (v_isShared_197_ == 0)
{
lean_ctor_set(v___x_196_, 1, v_a_191_);
v___x_205_ = v___x_196_;
goto v_reusejp_204_;
}
else
{
lean_object* v_reuseFailAlloc_207_; 
v_reuseFailAlloc_207_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_207_, 0, v_head_193_);
lean_ctor_set(v_reuseFailAlloc_207_, 1, v_a_191_);
v___x_205_ = v_reuseFailAlloc_207_;
goto v_reusejp_204_;
}
v_reusejp_204_:
{
v_a_190_ = v_tail_194_;
v_a_191_ = v___x_205_;
goto _start;
}
}
}
else
{
lean_del_object(v___x_196_);
lean_dec(v_head_193_);
v_a_190_ = v_tail_194_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0___boxed(lean_object* v_qs_210_, lean_object* v_n_211_, lean_object* v_a_212_, lean_object* v_a_213_){
_start:
{
lean_object* v_res_214_; 
v_res_214_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0(v_qs_210_, v_n_211_, v_a_212_, v_a_213_);
lean_dec(v_n_211_);
return v_res_214_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1(lean_object* v_n_215_, lean_object* v_n_216_, lean_object* v_a_217_, lean_object* v_a_218_){
_start:
{
if (lean_obj_tag(v_a_217_) == 0)
{
lean_object* v___x_219_; 
lean_dec(v_n_215_);
v___x_219_ = lean_array_to_list(v_a_218_);
return v___x_219_;
}
else
{
lean_object* v_head_220_; lean_object* v_tail_221_; lean_object* v___x_222_; lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v___x_225_; lean_object* v___x_226_; 
v_head_220_ = lean_ctor_get(v_a_217_, 0);
lean_inc_n(v_head_220_, 2);
v_tail_221_ = lean_ctor_get(v_a_217_, 1);
lean_inc(v_tail_221_);
lean_dec_ref_known(v_a_217_, 2);
lean_inc(v_n_215_);
v___x_222_ = l_ADWH_Chapter15_Queens_columns(v_n_215_);
v___x_223_ = lean_box(0);
v___x_224_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0(v_head_220_, v_n_216_, v___x_222_, v___x_223_);
v___x_225_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__1(v_head_220_, v___x_224_, v___x_223_);
v___x_226_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_218_, v___x_225_);
v_a_217_ = v_tail_221_;
v_a_218_ = v___x_226_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1___boxed(lean_object* v_n_228_, lean_object* v_n_229_, lean_object* v_a_230_, lean_object* v_a_231_){
_start:
{
lean_object* v_res_232_; 
v_res_232_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1(v_n_228_, v_n_229_, v_a_230_, v_a_231_);
lean_dec(v_n_229_);
return v_res_232_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1(lean_object* v_n_233_, lean_object* v_n_234_, lean_object* v_a_235_, lean_object* v_a_236_){
_start:
{
if (lean_obj_tag(v_a_235_) == 0)
{
lean_object* v___x_237_; 
lean_dec(v_n_234_);
v___x_237_ = lean_array_to_list(v_a_236_);
return v___x_237_;
}
else
{
lean_object* v_head_238_; lean_object* v_tail_239_; lean_object* v___x_240_; lean_object* v___x_241_; lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; 
v_head_238_ = lean_ctor_get(v_a_235_, 0);
lean_inc_n(v_head_238_, 2);
v_tail_239_ = lean_ctor_get(v_a_235_, 1);
lean_inc(v_tail_239_);
lean_dec_ref_known(v_a_235_, 2);
lean_inc(v_n_234_);
v___x_240_ = l_ADWH_Chapter15_Queens_columns(v_n_234_);
v___x_241_ = lean_box(0);
v___x_242_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place1_spec__0(v_head_238_, v_n_233_, v___x_240_, v___x_241_);
v___x_243_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__1(v_head_238_, v___x_242_, v___x_241_);
v___x_244_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_236_, v___x_243_);
v___x_245_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00__private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1_spec__1(v_n_234_, v_n_233_, v_tail_239_, v___x_244_);
return v___x_245_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1___boxed(lean_object* v_n_246_, lean_object* v_n_247_, lean_object* v_a_248_, lean_object* v_a_249_){
_start:
{
lean_object* v_res_250_; 
v_res_250_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1(v_n_246_, v_n_247_, v_a_248_, v_a_249_);
lean_dec(v_n_246_);
return v_res_250_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place1(lean_object* v_n_251_, lean_object* v_x_252_){
_start:
{
lean_object* v_zero_253_; uint8_t v_isZero_254_; 
v_zero_253_ = lean_unsigned_to_nat(0u);
v_isZero_254_ = lean_nat_dec_eq(v_x_252_, v_zero_253_);
if (v_isZero_254_ == 1)
{
lean_object* v___x_255_; 
lean_dec(v_n_251_);
v___x_255_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__0));
return v___x_255_;
}
else
{
lean_object* v_one_256_; lean_object* v_n_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_260_; 
v_one_256_ = lean_unsigned_to_nat(1u);
v_n_257_ = lean_nat_sub(v_x_252_, v_one_256_);
lean_inc(v_n_251_);
v___x_258_ = l_ADWH_Chapter15_Queens_place1(v_n_251_, v_n_257_);
v___x_259_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__1));
v___x_260_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place1_spec__1(v_n_257_, v_n_251_, v___x_258_, v___x_259_);
lean_dec(v_n_257_);
return v___x_260_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place1___boxed(lean_object* v_n_261_, lean_object* v_x_262_){
_start:
{
lean_object* v_res_263_; 
v_res_263_ = l_ADWH_Chapter15_Queens_place1(v_n_261_, v_x_262_);
lean_dec(v_x_262_);
return v_res_263_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens1(lean_object* v_n_264_){
_start:
{
lean_object* v___x_265_; 
lean_inc(v_n_264_);
v___x_265_ = l_ADWH_Chapter15_Queens_place1(v_n_264_, v_n_264_);
lean_dec(v_n_264_);
return v___x_265_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__1(lean_object* v_qs_266_, lean_object* v_a_267_, lean_object* v_a_268_){
_start:
{
if (lean_obj_tag(v_a_267_) == 0)
{
lean_object* v___x_269_; 
lean_dec(v_qs_266_);
v___x_269_ = l_List_reverse___redArg(v_a_268_);
return v___x_269_;
}
else
{
lean_object* v_head_270_; lean_object* v_tail_271_; lean_object* v___x_273_; uint8_t v_isShared_274_; uint8_t v_isSharedCheck_280_; 
v_head_270_ = lean_ctor_get(v_a_267_, 0);
v_tail_271_ = lean_ctor_get(v_a_267_, 1);
v_isSharedCheck_280_ = !lean_is_exclusive(v_a_267_);
if (v_isSharedCheck_280_ == 0)
{
v___x_273_ = v_a_267_;
v_isShared_274_ = v_isSharedCheck_280_;
goto v_resetjp_272_;
}
else
{
lean_inc(v_tail_271_);
lean_inc(v_head_270_);
lean_dec(v_a_267_);
v___x_273_ = lean_box(0);
v_isShared_274_ = v_isSharedCheck_280_;
goto v_resetjp_272_;
}
v_resetjp_272_:
{
lean_object* v___x_276_; 
lean_inc(v_qs_266_);
if (v_isShared_274_ == 0)
{
lean_ctor_set(v___x_273_, 1, v_qs_266_);
v___x_276_ = v___x_273_;
goto v_reusejp_275_;
}
else
{
lean_object* v_reuseFailAlloc_279_; 
v_reuseFailAlloc_279_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_279_, 0, v_head_270_);
lean_ctor_set(v_reuseFailAlloc_279_, 1, v_qs_266_);
v___x_276_ = v_reuseFailAlloc_279_;
goto v_reusejp_275_;
}
v_reusejp_275_:
{
lean_object* v___x_277_; 
v___x_277_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_277_, 0, v___x_276_);
lean_ctor_set(v___x_277_, 1, v_a_268_);
v_a_267_ = v_tail_271_;
v_a_268_ = v___x_277_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__0(lean_object* v_qs_281_, lean_object* v_a_282_, lean_object* v_a_283_){
_start:
{
if (lean_obj_tag(v_a_282_) == 0)
{
lean_object* v___x_284_; 
lean_dec(v_qs_281_);
v___x_284_ = l_List_reverse___redArg(v_a_283_);
return v___x_284_;
}
else
{
lean_object* v_head_285_; lean_object* v_tail_286_; lean_object* v___x_288_; uint8_t v_isShared_289_; uint8_t v_isSharedCheck_299_; 
v_head_285_ = lean_ctor_get(v_a_282_, 0);
v_tail_286_ = lean_ctor_get(v_a_282_, 1);
v_isSharedCheck_299_ = !lean_is_exclusive(v_a_282_);
if (v_isSharedCheck_299_ == 0)
{
v___x_288_ = v_a_282_;
v_isShared_289_ = v_isSharedCheck_299_;
goto v_resetjp_287_;
}
else
{
lean_inc(v_tail_286_);
lean_inc(v_head_285_);
lean_dec(v_a_282_);
v___x_288_ = lean_box(0);
v_isShared_289_ = v_isSharedCheck_299_;
goto v_resetjp_287_;
}
v_resetjp_287_:
{
lean_object* v___f_290_; uint8_t v___x_291_; 
v___f_290_ = lean_obj_once(&l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0, &l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0_once, _init_l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_placePerms_spec__0___closed__0);
lean_inc(v_qs_281_);
lean_inc(v_head_285_);
v___x_291_ = l_List_elem___redArg(v___f_290_, v_head_285_, v_qs_281_);
if (v___x_291_ == 0)
{
uint8_t v___x_292_; 
lean_inc(v_qs_281_);
v___x_292_ = l_ADWH_Chapter15_Queens_newDiag(v_head_285_, v_qs_281_);
if (v___x_292_ == 0)
{
lean_del_object(v___x_288_);
lean_dec(v_head_285_);
v_a_282_ = v_tail_286_;
goto _start;
}
else
{
lean_object* v___x_295_; 
if (v_isShared_289_ == 0)
{
lean_ctor_set(v___x_288_, 1, v_a_283_);
v___x_295_ = v___x_288_;
goto v_reusejp_294_;
}
else
{
lean_object* v_reuseFailAlloc_297_; 
v_reuseFailAlloc_297_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_297_, 0, v_head_285_);
lean_ctor_set(v_reuseFailAlloc_297_, 1, v_a_283_);
v___x_295_ = v_reuseFailAlloc_297_;
goto v_reusejp_294_;
}
v_reusejp_294_:
{
v_a_282_ = v_tail_286_;
v_a_283_ = v___x_295_;
goto _start;
}
}
}
else
{
lean_del_object(v___x_288_);
lean_dec(v_head_285_);
v_a_282_ = v_tail_286_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place4_spec__2(lean_object* v_n_300_, lean_object* v_a_301_, lean_object* v_a_302_){
_start:
{
if (lean_obj_tag(v_a_301_) == 0)
{
lean_object* v___x_303_; 
lean_dec(v_n_300_);
v___x_303_ = lean_array_to_list(v_a_302_);
return v___x_303_;
}
else
{
lean_object* v_head_304_; lean_object* v_tail_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_309_; lean_object* v___x_310_; 
v_head_304_ = lean_ctor_get(v_a_301_, 0);
lean_inc_n(v_head_304_, 2);
v_tail_305_ = lean_ctor_get(v_a_301_, 1);
lean_inc(v_tail_305_);
lean_dec_ref_known(v_a_301_, 2);
lean_inc(v_n_300_);
v___x_306_ = l_ADWH_Chapter15_Queens_columns(v_n_300_);
v___x_307_ = lean_box(0);
v___x_308_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__0(v_head_304_, v___x_306_, v___x_307_);
v___x_309_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__1(v_head_304_, v___x_308_, v___x_307_);
v___x_310_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_302_, v___x_309_);
v_a_301_ = v_tail_305_;
v_a_302_ = v___x_310_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place4(lean_object* v_n_312_, lean_object* v_x_313_){
_start:
{
lean_object* v_zero_314_; uint8_t v_isZero_315_; 
v_zero_314_ = lean_unsigned_to_nat(0u);
v_isZero_315_ = lean_nat_dec_eq(v_x_313_, v_zero_314_);
if (v_isZero_315_ == 1)
{
lean_object* v___x_316_; 
lean_dec(v_n_312_);
v___x_316_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__0));
return v___x_316_;
}
else
{
lean_object* v_one_317_; lean_object* v_n_318_; lean_object* v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; 
v_one_317_ = lean_unsigned_to_nat(1u);
v_n_318_ = lean_nat_sub(v_x_313_, v_one_317_);
lean_inc(v_n_312_);
v___x_319_ = l_ADWH_Chapter15_Queens_place4(v_n_312_, v_n_318_);
lean_dec(v_n_318_);
v___x_320_ = ((lean_object*)(l_ADWH_Chapter15_Queens_words___closed__1));
v___x_321_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_place4_spec__2(v_n_312_, v___x_319_, v___x_320_);
return v___x_321_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_place4___boxed(lean_object* v_n_322_, lean_object* v_x_323_){
_start:
{
lean_object* v_res_324_; 
v_res_324_ = l_ADWH_Chapter15_Queens_place4(v_n_322_, v_x_323_);
lean_dec(v_x_323_);
return v_res_324_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_queens4_spec__0(lean_object* v_a_325_, lean_object* v_a_326_){
_start:
{
if (lean_obj_tag(v_a_325_) == 0)
{
lean_object* v___x_327_; 
v___x_327_ = l_List_reverse___redArg(v_a_326_);
return v___x_327_;
}
else
{
lean_object* v_head_328_; lean_object* v_tail_329_; lean_object* v___x_331_; uint8_t v_isShared_332_; uint8_t v_isSharedCheck_338_; 
v_head_328_ = lean_ctor_get(v_a_325_, 0);
v_tail_329_ = lean_ctor_get(v_a_325_, 1);
v_isSharedCheck_338_ = !lean_is_exclusive(v_a_325_);
if (v_isSharedCheck_338_ == 0)
{
v___x_331_ = v_a_325_;
v_isShared_332_ = v_isSharedCheck_338_;
goto v_resetjp_330_;
}
else
{
lean_inc(v_tail_329_);
lean_inc(v_head_328_);
lean_dec(v_a_325_);
v___x_331_ = lean_box(0);
v_isShared_332_ = v_isSharedCheck_338_;
goto v_resetjp_330_;
}
v_resetjp_330_:
{
lean_object* v___x_333_; lean_object* v___x_335_; 
v___x_333_ = l_List_reverse___redArg(v_head_328_);
if (v_isShared_332_ == 0)
{
lean_ctor_set(v___x_331_, 1, v_a_326_);
lean_ctor_set(v___x_331_, 0, v___x_333_);
v___x_335_ = v___x_331_;
goto v_reusejp_334_;
}
else
{
lean_object* v_reuseFailAlloc_337_; 
v_reuseFailAlloc_337_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_337_, 0, v___x_333_);
lean_ctor_set(v_reuseFailAlloc_337_, 1, v_a_326_);
v___x_335_ = v_reuseFailAlloc_337_;
goto v_reusejp_334_;
}
v_reusejp_334_:
{
v_a_325_ = v_tail_329_;
v_a_326_ = v___x_335_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens4(lean_object* v_n_339_){
_start:
{
lean_object* v___x_340_; lean_object* v___x_341_; lean_object* v___x_342_; 
lean_inc(v_n_339_);
v___x_340_ = l_ADWH_Chapter15_Queens_place4(v_n_339_, v_n_339_);
lean_dec(v_n_339_);
v___x_341_ = lean_box(0);
v___x_342_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_queens4_spec__0(v___x_340_, v___x_341_);
return v___x_342_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter15_Queens(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter15_QueensVariants(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter15_Queens(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
