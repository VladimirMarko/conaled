// Lean compiler output
// Module: ADWH.Chapter15.QueensBitMoves
// Imports: public import Init public meta import Init public import ADWH.Chapter15.QueensBitRepresentation
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_nat_land(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_move(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask(lean_object*);
lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_available(lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0;
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_successorsBits_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1(lean_object*);
LEAN_EXPORT lean_object* l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_countRows(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_countRows___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__0(lean_object* v_a_1_, lean_object* v_a_2_){
_start:
{
if (lean_obj_tag(v_a_1_) == 0)
{
lean_object* v___x_3_; 
v___x_3_ = l_List_reverse___redArg(v_a_2_);
return v___x_3_;
}
else
{
lean_object* v_head_4_; lean_object* v_tail_5_; lean_object* v___x_7_; uint8_t v_isShared_8_; uint8_t v_isSharedCheck_16_; 
v_head_4_ = lean_ctor_get(v_a_1_, 0);
v_tail_5_ = lean_ctor_get(v_a_1_, 1);
v_isSharedCheck_16_ = !lean_is_exclusive(v_a_1_);
if (v_isSharedCheck_16_ == 0)
{
v___x_7_ = v_a_1_;
v_isShared_8_ = v_isSharedCheck_16_;
goto v_resetjp_6_;
}
else
{
lean_inc(v_tail_5_);
lean_inc(v_head_4_);
lean_dec(v_a_1_);
v___x_7_ = lean_box(0);
v_isShared_8_ = v_isSharedCheck_16_;
goto v_resetjp_6_;
}
v_resetjp_6_:
{
lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_13_; 
v___x_9_ = lean_unsigned_to_nat(1u);
v___x_10_ = lean_nat_add(v_head_4_, v___x_9_);
lean_dec(v_head_4_);
v___x_11_ = l_ADWH_Chapter15_Queens_BitRepresentation_singleton(v___x_10_);
lean_dec(v___x_10_);
if (v_isShared_8_ == 0)
{
lean_ctor_set(v___x_7_, 1, v_a_2_);
lean_ctor_set(v___x_7_, 0, v___x_11_);
v___x_13_ = v___x_7_;
goto v_reusejp_12_;
}
else
{
lean_object* v_reuseFailAlloc_15_; 
v_reuseFailAlloc_15_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_15_, 0, v___x_11_);
lean_ctor_set(v_reuseFailAlloc_15_, 1, v_a_2_);
v___x_13_ = v_reuseFailAlloc_15_;
goto v_reusejp_12_;
}
v_reusejp_12_:
{
v_a_1_ = v_tail_5_;
v_a_2_ = v___x_13_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1(lean_object* v_v_17_, lean_object* v_a_18_, lean_object* v_a_19_){
_start:
{
if (lean_obj_tag(v_a_18_) == 0)
{
lean_object* v___x_20_; 
v___x_20_ = l_List_reverse___redArg(v_a_19_);
return v___x_20_;
}
else
{
lean_object* v_head_21_; lean_object* v_tail_22_; lean_object* v___x_24_; uint8_t v_isShared_25_; uint8_t v_isSharedCheck_33_; 
v_head_21_ = lean_ctor_get(v_a_18_, 0);
v_tail_22_ = lean_ctor_get(v_a_18_, 1);
v_isSharedCheck_33_ = !lean_is_exclusive(v_a_18_);
if (v_isSharedCheck_33_ == 0)
{
v___x_24_ = v_a_18_;
v_isShared_25_ = v_isSharedCheck_33_;
goto v_resetjp_23_;
}
else
{
lean_inc(v_tail_22_);
lean_inc(v_head_21_);
lean_dec(v_a_18_);
v___x_24_ = lean_box(0);
v_isShared_25_ = v_isSharedCheck_33_;
goto v_resetjp_23_;
}
v_resetjp_23_:
{
lean_object* v___x_26_; uint8_t v___x_27_; 
v___x_26_ = lean_nat_land(v_v_17_, v_head_21_);
v___x_27_ = lean_nat_dec_eq(v___x_26_, v_head_21_);
lean_dec(v___x_26_);
if (v___x_27_ == 0)
{
lean_del_object(v___x_24_);
lean_dec(v_head_21_);
v_a_18_ = v_tail_22_;
goto _start;
}
else
{
lean_object* v___x_30_; 
if (v_isShared_25_ == 0)
{
lean_ctor_set(v___x_24_, 1, v_a_19_);
v___x_30_ = v___x_24_;
goto v_reusejp_29_;
}
else
{
lean_object* v_reuseFailAlloc_32_; 
v_reuseFailAlloc_32_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_32_, 0, v_head_21_);
lean_ctor_set(v_reuseFailAlloc_32_, 1, v_a_19_);
v___x_30_ = v_reuseFailAlloc_32_;
goto v_reusejp_29_;
}
v_reusejp_29_:
{
v_a_18_ = v_tail_22_;
v_a_19_ = v___x_30_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1___boxed(lean_object* v_v_34_, lean_object* v_a_35_, lean_object* v_a_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1(v_v_34_, v_a_35_, v_a_36_);
lean_dec(v_v_34_);
return v_res_37_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0(void){
_start:
{
lean_object* v___x_38_; lean_object* v___x_39_; 
v___x_38_ = lean_unsigned_to_nat(16u);
v___x_39_ = l_List_range(v___x_38_);
return v___x_39_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_40_ = lean_box(0);
v___x_41_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__0);
v___x_42_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__0(v___x_41_, v___x_40_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits(lean_object* v_v_43_){
_start:
{
lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; 
v___x_44_ = lean_box(0);
v___x_45_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1, &l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___closed__1);
v___x_46_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_candidateBits_spec__1(v_v_43_, v___x_45_, v___x_44_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits___boxed(lean_object* v_v_47_){
_start:
{
lean_object* v_res_48_; 
v_res_48_ = l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits(v_v_47_);
lean_dec(v_v_47_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_successorsBits_spec__0(lean_object* v_s_49_, lean_object* v_a_50_, lean_object* v_a_51_){
_start:
{
if (lean_obj_tag(v_a_50_) == 0)
{
lean_object* v___x_52_; 
lean_dec_ref(v_s_49_);
v___x_52_ = l_List_reverse___redArg(v_a_51_);
return v___x_52_;
}
else
{
lean_object* v_head_53_; lean_object* v_tail_54_; lean_object* v___x_56_; uint8_t v_isShared_57_; uint8_t v_isSharedCheck_63_; 
v_head_53_ = lean_ctor_get(v_a_50_, 0);
v_tail_54_ = lean_ctor_get(v_a_50_, 1);
v_isSharedCheck_63_ = !lean_is_exclusive(v_a_50_);
if (v_isSharedCheck_63_ == 0)
{
v___x_56_ = v_a_50_;
v_isShared_57_ = v_isSharedCheck_63_;
goto v_resetjp_55_;
}
else
{
lean_inc(v_tail_54_);
lean_inc(v_head_53_);
lean_dec(v_a_50_);
v___x_56_ = lean_box(0);
v_isShared_57_ = v_isSharedCheck_63_;
goto v_resetjp_55_;
}
v_resetjp_55_:
{
lean_object* v___x_58_; lean_object* v___x_60_; 
lean_inc_ref(v_s_49_);
v___x_58_ = l_ADWH_Chapter15_Queens_BitRepresentation_move(v_s_49_, v_head_53_);
lean_dec(v_head_53_);
if (v_isShared_57_ == 0)
{
lean_ctor_set(v___x_56_, 1, v_a_51_);
lean_ctor_set(v___x_56_, 0, v___x_58_);
v___x_60_ = v___x_56_;
goto v_reusejp_59_;
}
else
{
lean_object* v_reuseFailAlloc_62_; 
v_reuseFailAlloc_62_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_62_, 0, v___x_58_);
lean_ctor_set(v_reuseFailAlloc_62_, 1, v_a_51_);
v___x_60_ = v_reuseFailAlloc_62_;
goto v_reusejp_59_;
}
v_reusejp_59_:
{
v_a_50_ = v_tail_54_;
v_a_51_ = v___x_60_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits(lean_object* v_n_64_, lean_object* v_s_65_){
_start:
{
lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; 
v___x_66_ = l_ADWH_Chapter15_Queens_BitRepresentation_available(v_n_64_, v_s_65_);
v___x_67_ = l_ADWH_Chapter15_Queens_BitRepresentation_candidateBits(v___x_66_);
lean_dec(v___x_66_);
v___x_68_ = lean_box(0);
v___x_69_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_successorsBits_spec__0(v_s_65_, v___x_67_, v___x_68_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits___boxed(lean_object* v_n_70_, lean_object* v_s_71_){
_start:
{
lean_object* v_res_72_; 
v_res_72_ = l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits(v_n_70_, v_s_71_);
lean_dec(v_n_70_);
return v_res_72_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits(lean_object* v_n_73_, lean_object* v_s_74_){
_start:
{
lean_object* v_snd_75_; lean_object* v_fst_76_; lean_object* v___x_77_; uint8_t v___x_78_; 
v_snd_75_ = lean_ctor_get(v_s_74_, 1);
v_fst_76_ = lean_ctor_get(v_snd_75_, 0);
v___x_77_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_73_);
v___x_78_ = lean_nat_dec_eq(v_fst_76_, v___x_77_);
lean_dec(v___x_77_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits___boxed(lean_object* v_n_79_, lean_object* v_s_80_){
_start:
{
uint8_t v_res_81_; lean_object* v_r_82_; 
v_res_81_ = l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits(v_n_79_, v_s_80_);
lean_dec_ref(v_s_80_);
lean_dec(v_n_79_);
v_r_82_ = lean_box(v_res_81_);
return v_r_82_;
}
}
LEAN_EXPORT lean_object* l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1(lean_object* v_init_83_, lean_object* v_x_84_){
_start:
{
if (lean_obj_tag(v_x_84_) == 0)
{
lean_inc(v_init_83_);
return v_init_83_;
}
else
{
lean_object* v_head_85_; lean_object* v_tail_86_; lean_object* v___x_87_; lean_object* v___x_88_; 
v_head_85_ = lean_ctor_get(v_x_84_, 0);
v_tail_86_ = lean_ctor_get(v_x_84_, 1);
v___x_87_ = l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1(v_init_83_, v_tail_86_);
v___x_88_ = lean_nat_add(v_head_85_, v___x_87_);
lean_dec(v___x_87_);
return v___x_88_;
}
}
}
LEAN_EXPORT lean_object* l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1___boxed(lean_object* v_init_89_, lean_object* v_x_90_){
_start:
{
lean_object* v_res_91_; 
v_res_91_ = l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1(v_init_89_, v_x_90_);
lean_dec(v_x_90_);
lean_dec(v_init_89_);
return v_res_91_;
}
}
LEAN_EXPORT lean_object* l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1(lean_object* v_l_92_){
_start:
{
lean_object* v___x_93_; lean_object* v___x_94_; 
v___x_93_ = lean_unsigned_to_nat(0u);
v___x_94_ = l_List_foldr___at___00List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1_spec__1(v___x_93_, v_l_92_);
return v___x_94_;
}
}
LEAN_EXPORT lean_object* l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1___boxed(lean_object* v_l_95_){
_start:
{
lean_object* v_res_96_; 
v_res_96_ = l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1(v_l_95_);
lean_dec(v_l_95_);
return v_res_96_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_countRows(lean_object* v_n_97_, lean_object* v_x_98_, lean_object* v_x_99_){
_start:
{
lean_object* v_zero_100_; uint8_t v_isZero_101_; 
v_zero_100_ = lean_unsigned_to_nat(0u);
v_isZero_101_ = lean_nat_dec_eq(v_x_98_, v_zero_100_);
if (v_isZero_101_ == 1)
{
uint8_t v___x_102_; 
v___x_102_ = l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits(v_n_97_, v_x_99_);
lean_dec_ref(v_x_99_);
if (v___x_102_ == 0)
{
return v_zero_100_;
}
else
{
lean_object* v___x_103_; 
v___x_103_ = lean_unsigned_to_nat(1u);
return v___x_103_;
}
}
else
{
uint8_t v___x_104_; 
v___x_104_ = l_ADWH_Chapter15_Queens_BitRepresentation_solvedBits(v_n_97_, v_x_99_);
if (v___x_104_ == 0)
{
lean_object* v_one_105_; lean_object* v_n_106_; lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; 
v_one_105_ = lean_unsigned_to_nat(1u);
v_n_106_ = lean_nat_sub(v_x_98_, v_one_105_);
v___x_107_ = l_ADWH_Chapter15_Queens_BitRepresentation_successorsBits(v_n_97_, v_x_99_);
v___x_108_ = lean_box(0);
v___x_109_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0(v_n_97_, v_n_106_, v___x_107_, v___x_108_);
lean_dec(v_n_106_);
v___x_110_ = l_List_sum___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__1(v___x_109_);
lean_dec(v___x_109_);
return v___x_110_;
}
else
{
lean_object* v___x_111_; 
lean_dec_ref(v_x_99_);
v___x_111_ = lean_unsigned_to_nat(1u);
return v___x_111_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0(lean_object* v_n_112_, lean_object* v_n_113_, lean_object* v_a_114_, lean_object* v_a_115_){
_start:
{
if (lean_obj_tag(v_a_114_) == 0)
{
lean_object* v___x_116_; 
v___x_116_ = l_List_reverse___redArg(v_a_115_);
return v___x_116_;
}
else
{
lean_object* v_head_117_; lean_object* v_tail_118_; lean_object* v___x_120_; uint8_t v_isShared_121_; uint8_t v_isSharedCheck_127_; 
v_head_117_ = lean_ctor_get(v_a_114_, 0);
v_tail_118_ = lean_ctor_get(v_a_114_, 1);
v_isSharedCheck_127_ = !lean_is_exclusive(v_a_114_);
if (v_isSharedCheck_127_ == 0)
{
v___x_120_ = v_a_114_;
v_isShared_121_ = v_isSharedCheck_127_;
goto v_resetjp_119_;
}
else
{
lean_inc(v_tail_118_);
lean_inc(v_head_117_);
lean_dec(v_a_114_);
v___x_120_ = lean_box(0);
v_isShared_121_ = v_isSharedCheck_127_;
goto v_resetjp_119_;
}
v_resetjp_119_:
{
lean_object* v___x_122_; lean_object* v___x_124_; 
v___x_122_ = l_ADWH_Chapter15_Queens_BitRepresentation_countRows(v_n_112_, v_n_113_, v_head_117_);
if (v_isShared_121_ == 0)
{
lean_ctor_set(v___x_120_, 1, v_a_115_);
lean_ctor_set(v___x_120_, 0, v___x_122_);
v___x_124_ = v___x_120_;
goto v_reusejp_123_;
}
else
{
lean_object* v_reuseFailAlloc_126_; 
v_reuseFailAlloc_126_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_126_, 0, v___x_122_);
lean_ctor_set(v_reuseFailAlloc_126_, 1, v_a_115_);
v___x_124_ = v_reuseFailAlloc_126_;
goto v_reusejp_123_;
}
v_reusejp_123_:
{
v_a_114_ = v_tail_118_;
v_a_115_ = v___x_124_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0___boxed(lean_object* v_n_128_, lean_object* v_n_129_, lean_object* v_a_130_, lean_object* v_a_131_){
_start:
{
lean_object* v_res_132_; 
v_res_132_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_BitRepresentation_countRows_spec__0(v_n_128_, v_n_129_, v_a_130_, v_a_131_);
lean_dec(v_n_129_);
lean_dec(v_n_128_);
return v_res_132_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_countRows___boxed(lean_object* v_n_133_, lean_object* v_x_134_, lean_object* v_x_135_){
_start:
{
lean_object* v_res_136_; 
v_res_136_ = l_ADWH_Chapter15_Queens_BitRepresentation_countRows(v_n_133_, v_x_134_, v_x_135_);
lean_dec(v_x_134_);
lean_dec(v_n_133_);
return v_res_136_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___redArg(lean_object* v_x_137_, lean_object* v_x_138_, lean_object* v_h__1_139_, lean_object* v_h__2_140_){
_start:
{
lean_object* v_zero_141_; uint8_t v_isZero_142_; 
v_zero_141_ = lean_unsigned_to_nat(0u);
v_isZero_142_ = lean_nat_dec_eq(v_x_137_, v_zero_141_);
if (v_isZero_142_ == 1)
{
lean_object* v___x_143_; 
lean_dec(v_h__2_140_);
v___x_143_ = lean_apply_1(v_h__1_139_, v_x_138_);
return v___x_143_;
}
else
{
lean_object* v_one_144_; lean_object* v_n_145_; lean_object* v___x_146_; 
lean_dec(v_h__1_139_);
v_one_144_ = lean_unsigned_to_nat(1u);
v_n_145_ = lean_nat_sub(v_x_137_, v_one_144_);
v___x_146_ = lean_apply_2(v_h__2_140_, v_n_145_, v_x_138_);
return v___x_146_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___redArg___boxed(lean_object* v_x_147_, lean_object* v_x_148_, lean_object* v_h__1_149_, lean_object* v_h__2_150_){
_start:
{
lean_object* v_res_151_; 
v_res_151_ = l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___redArg(v_x_147_, v_x_148_, v_h__1_149_, v_h__2_150_);
lean_dec(v_x_147_);
return v_res_151_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter(lean_object* v_motive_152_, lean_object* v_x_153_, lean_object* v_x_154_, lean_object* v_h__1_155_, lean_object* v_h__2_156_){
_start:
{
lean_object* v_zero_157_; uint8_t v_isZero_158_; 
v_zero_157_ = lean_unsigned_to_nat(0u);
v_isZero_158_ = lean_nat_dec_eq(v_x_153_, v_zero_157_);
if (v_isZero_158_ == 1)
{
lean_object* v___x_159_; 
lean_dec(v_h__2_156_);
v___x_159_ = lean_apply_1(v_h__1_155_, v_x_154_);
return v___x_159_;
}
else
{
lean_object* v_one_160_; lean_object* v_n_161_; lean_object* v___x_162_; 
lean_dec(v_h__1_155_);
v_one_160_ = lean_unsigned_to_nat(1u);
v_n_161_ = lean_nat_sub(v_x_153_, v_one_160_);
v___x_162_ = lean_apply_2(v_h__2_156_, v_n_161_, v_x_154_);
return v___x_162_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter___boxed(lean_object* v_motive_163_, lean_object* v_x_164_, lean_object* v_x_165_, lean_object* v_h__1_166_, lean_object* v_h__2_167_){
_start:
{
lean_object* v_res_168_; 
v_res_168_ = l___private_ADWH_Chapter15_QueensBitMoves_0__ADWH_Chapter15_Queens_BitRepresentation_countRows_match__1_splitter(v_motive_163_, v_x_164_, v_x_165_, v_h__1_166_, v_h__2_167_);
lean_dec(v_x_164_);
return v_res_168_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter15_QueensBitRepresentation(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter15_QueensBitMoves(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter15_QueensBitRepresentation(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
