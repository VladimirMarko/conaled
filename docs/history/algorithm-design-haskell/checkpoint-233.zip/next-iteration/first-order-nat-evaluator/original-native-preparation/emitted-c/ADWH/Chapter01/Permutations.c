// Lean compiler output
// Module: ADWH.Chapter01.Permutations
// Imports: public import Init public meta import Init public import ADWH.Chapter01.Lists
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_array_to_list(lean_object*);
uint8_t l_List_instDecidableEqNil___redArg(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_List_foldl___at___00Array_appendList_spec__0___redArg(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter01_Lists_concatMap___redArg(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter01_Lists_foldr___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_ADWH_Chapter01_Lists_map___redArg(lean_object*, lean_object*);
lean_object* l_ADWH_Chapter01_Lists_head___redArg(lean_object*);
lean_object* l_ADWH_Chapter01_Lists_tail___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_inserts___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_inserts(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_inserts_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_inserts_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_picks___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_picks(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0___redArg(lean_object*, lean_object*, lean_object*);
static const lean_array_object l_ADWH_Chapter01_Permutations_perms1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_ADWH_Chapter01_Permutations_perms1___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Permutations_perms1___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg___lam__0(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Permutations_perms1Fold___redArg___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__0_value;
static const lean_ctor_object l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1 = (const lean_object*)&l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___lam__0(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0___boxed(lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Permutations_insertsFast___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Permutations_insertsFast___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertStep___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertStep(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsByFold___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsByFold(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_factorial(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_factorial___boxed(lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0___redArg(lean_object* v_head_1_, lean_object* v_a_2_, lean_object* v_a_3_){
_start:
{
if (lean_obj_tag(v_a_2_) == 0)
{
lean_object* v___x_4_; 
lean_dec(v_head_1_);
v___x_4_ = l_List_reverse___redArg(v_a_3_);
return v___x_4_;
}
else
{
lean_object* v_head_5_; lean_object* v_tail_6_; lean_object* v___x_8_; uint8_t v_isShared_9_; uint8_t v_isSharedCheck_15_; 
v_head_5_ = lean_ctor_get(v_a_2_, 0);
v_tail_6_ = lean_ctor_get(v_a_2_, 1);
v_isSharedCheck_15_ = !lean_is_exclusive(v_a_2_);
if (v_isSharedCheck_15_ == 0)
{
v___x_8_ = v_a_2_;
v_isShared_9_ = v_isSharedCheck_15_;
goto v_resetjp_7_;
}
else
{
lean_inc(v_tail_6_);
lean_inc(v_head_5_);
lean_dec(v_a_2_);
v___x_8_ = lean_box(0);
v_isShared_9_ = v_isSharedCheck_15_;
goto v_resetjp_7_;
}
v_resetjp_7_:
{
lean_object* v___x_11_; 
lean_inc(v_head_1_);
if (v_isShared_9_ == 0)
{
lean_ctor_set(v___x_8_, 1, v_head_5_);
lean_ctor_set(v___x_8_, 0, v_head_1_);
v___x_11_ = v___x_8_;
goto v_reusejp_10_;
}
else
{
lean_object* v_reuseFailAlloc_14_; 
v_reuseFailAlloc_14_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_14_, 0, v_head_1_);
lean_ctor_set(v_reuseFailAlloc_14_, 1, v_head_5_);
v___x_11_ = v_reuseFailAlloc_14_;
goto v_reusejp_10_;
}
v_reusejp_10_:
{
lean_object* v___x_12_; 
v___x_12_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_12_, 0, v___x_11_);
lean_ctor_set(v___x_12_, 1, v_a_3_);
v_a_2_ = v_tail_6_;
v_a_3_ = v___x_12_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_inserts___redArg(lean_object* v_x_16_, lean_object* v_x_17_){
_start:
{
if (lean_obj_tag(v_x_17_) == 0)
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; 
v___x_18_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_18_, 0, v_x_16_);
lean_ctor_set(v___x_18_, 1, v_x_17_);
v___x_19_ = lean_box(0);
v___x_20_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_20_, 0, v___x_18_);
lean_ctor_set(v___x_20_, 1, v___x_19_);
return v___x_20_;
}
else
{
lean_object* v_head_21_; lean_object* v_tail_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; 
v_head_21_ = lean_ctor_get(v_x_17_, 0);
lean_inc(v_head_21_);
v_tail_22_ = lean_ctor_get(v_x_17_, 1);
lean_inc(v_tail_22_);
lean_inc(v_x_16_);
v___x_23_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_23_, 0, v_x_16_);
lean_ctor_set(v___x_23_, 1, v_x_17_);
v___x_24_ = l_ADWH_Chapter01_Permutations_inserts___redArg(v_x_16_, v_tail_22_);
v___x_25_ = lean_box(0);
v___x_26_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0___redArg(v_head_21_, v___x_24_, v___x_25_);
v___x_27_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_27_, 0, v___x_23_);
lean_ctor_set(v___x_27_, 1, v___x_26_);
return v___x_27_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_inserts(lean_object* v_00_u03b1_28_, lean_object* v_x_29_, lean_object* v_x_30_){
_start:
{
lean_object* v___x_31_; 
v___x_31_ = l_ADWH_Chapter01_Permutations_inserts___redArg(v_x_29_, v_x_30_);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0(lean_object* v_00_u03b1_32_, lean_object* v_head_33_, lean_object* v_a_34_, lean_object* v_a_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0___redArg(v_head_33_, v_a_34_, v_a_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_inserts_match__1_splitter___redArg(lean_object* v_x_37_, lean_object* v_h__1_38_, lean_object* v_h__2_39_){
_start:
{
if (lean_obj_tag(v_x_37_) == 0)
{
lean_object* v___x_40_; lean_object* v___x_41_; 
lean_dec(v_h__2_39_);
v___x_40_ = lean_box(0);
v___x_41_ = lean_apply_1(v_h__1_38_, v___x_40_);
return v___x_41_;
}
else
{
lean_object* v_head_42_; lean_object* v_tail_43_; lean_object* v___x_44_; 
lean_dec(v_h__1_38_);
v_head_42_ = lean_ctor_get(v_x_37_, 0);
lean_inc(v_head_42_);
v_tail_43_ = lean_ctor_get(v_x_37_, 1);
lean_inc(v_tail_43_);
lean_dec_ref_known(v_x_37_, 2);
v___x_44_ = lean_apply_2(v_h__2_39_, v_head_42_, v_tail_43_);
return v___x_44_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_inserts_match__1_splitter(lean_object* v_00_u03b1_45_, lean_object* v_motive_46_, lean_object* v_x_47_, lean_object* v_h__1_48_, lean_object* v_h__2_49_){
_start:
{
if (lean_obj_tag(v_x_47_) == 0)
{
lean_object* v___x_50_; lean_object* v___x_51_; 
lean_dec(v_h__2_49_);
v___x_50_ = lean_box(0);
v___x_51_ = lean_apply_1(v_h__1_48_, v___x_50_);
return v___x_51_;
}
else
{
lean_object* v_head_52_; lean_object* v_tail_53_; lean_object* v___x_54_; 
lean_dec(v_h__1_48_);
v_head_52_ = lean_ctor_get(v_x_47_, 0);
lean_inc(v_head_52_);
v_tail_53_ = lean_ctor_get(v_x_47_, 1);
lean_inc(v_tail_53_);
lean_dec_ref_known(v_x_47_, 2);
v___x_54_ = lean_apply_2(v_h__2_49_, v_head_52_, v_tail_53_);
return v___x_54_;
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0___redArg(lean_object* v_head_55_, lean_object* v_a_56_, lean_object* v_a_57_){
_start:
{
if (lean_obj_tag(v_a_56_) == 0)
{
lean_object* v___x_58_; 
lean_dec(v_head_55_);
v___x_58_ = l_List_reverse___redArg(v_a_57_);
return v___x_58_;
}
else
{
lean_object* v_head_59_; lean_object* v_tail_60_; lean_object* v___x_62_; uint8_t v_isShared_63_; uint8_t v_isSharedCheck_78_; 
v_head_59_ = lean_ctor_get(v_a_56_, 0);
v_tail_60_ = lean_ctor_get(v_a_56_, 1);
v_isSharedCheck_78_ = !lean_is_exclusive(v_a_56_);
if (v_isSharedCheck_78_ == 0)
{
v___x_62_ = v_a_56_;
v_isShared_63_ = v_isSharedCheck_78_;
goto v_resetjp_61_;
}
else
{
lean_inc(v_tail_60_);
lean_inc(v_head_59_);
lean_dec(v_a_56_);
v___x_62_ = lean_box(0);
v_isShared_63_ = v_isSharedCheck_78_;
goto v_resetjp_61_;
}
v_resetjp_61_:
{
lean_object* v_fst_64_; lean_object* v_snd_65_; lean_object* v___x_67_; uint8_t v_isShared_68_; uint8_t v_isSharedCheck_77_; 
v_fst_64_ = lean_ctor_get(v_head_59_, 0);
v_snd_65_ = lean_ctor_get(v_head_59_, 1);
v_isSharedCheck_77_ = !lean_is_exclusive(v_head_59_);
if (v_isSharedCheck_77_ == 0)
{
v___x_67_ = v_head_59_;
v_isShared_68_ = v_isSharedCheck_77_;
goto v_resetjp_66_;
}
else
{
lean_inc(v_snd_65_);
lean_inc(v_fst_64_);
lean_dec(v_head_59_);
v___x_67_ = lean_box(0);
v_isShared_68_ = v_isSharedCheck_77_;
goto v_resetjp_66_;
}
v_resetjp_66_:
{
lean_object* v___x_70_; 
lean_inc(v_head_55_);
if (v_isShared_63_ == 0)
{
lean_ctor_set(v___x_62_, 1, v_snd_65_);
lean_ctor_set(v___x_62_, 0, v_head_55_);
v___x_70_ = v___x_62_;
goto v_reusejp_69_;
}
else
{
lean_object* v_reuseFailAlloc_76_; 
v_reuseFailAlloc_76_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_76_, 0, v_head_55_);
lean_ctor_set(v_reuseFailAlloc_76_, 1, v_snd_65_);
v___x_70_ = v_reuseFailAlloc_76_;
goto v_reusejp_69_;
}
v_reusejp_69_:
{
lean_object* v___x_72_; 
if (v_isShared_68_ == 0)
{
lean_ctor_set(v___x_67_, 1, v___x_70_);
v___x_72_ = v___x_67_;
goto v_reusejp_71_;
}
else
{
lean_object* v_reuseFailAlloc_75_; 
v_reuseFailAlloc_75_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_75_, 0, v_fst_64_);
lean_ctor_set(v_reuseFailAlloc_75_, 1, v___x_70_);
v___x_72_ = v_reuseFailAlloc_75_;
goto v_reusejp_71_;
}
v_reusejp_71_:
{
lean_object* v___x_73_; 
v___x_73_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_73_, 0, v___x_72_);
lean_ctor_set(v___x_73_, 1, v_a_57_);
v_a_56_ = v_tail_60_;
v_a_57_ = v___x_73_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_picks___redArg(lean_object* v_x_79_){
_start:
{
if (lean_obj_tag(v_x_79_) == 0)
{
lean_object* v___x_80_; 
v___x_80_ = lean_box(0);
return v___x_80_;
}
else
{
lean_object* v_head_81_; lean_object* v_tail_82_; lean_object* v___x_84_; uint8_t v_isShared_85_; uint8_t v_isSharedCheck_93_; 
v_head_81_ = lean_ctor_get(v_x_79_, 0);
v_tail_82_ = lean_ctor_get(v_x_79_, 1);
v_isSharedCheck_93_ = !lean_is_exclusive(v_x_79_);
if (v_isSharedCheck_93_ == 0)
{
v___x_84_ = v_x_79_;
v_isShared_85_ = v_isSharedCheck_93_;
goto v_resetjp_83_;
}
else
{
lean_inc(v_tail_82_);
lean_inc(v_head_81_);
lean_dec(v_x_79_);
v___x_84_ = lean_box(0);
v_isShared_85_ = v_isSharedCheck_93_;
goto v_resetjp_83_;
}
v_resetjp_83_:
{
lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_91_; 
lean_inc(v_tail_82_);
lean_inc(v_head_81_);
v___x_86_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_86_, 0, v_head_81_);
lean_ctor_set(v___x_86_, 1, v_tail_82_);
v___x_87_ = l_ADWH_Chapter01_Permutations_picks___redArg(v_tail_82_);
v___x_88_ = lean_box(0);
v___x_89_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0___redArg(v_head_81_, v___x_87_, v___x_88_);
if (v_isShared_85_ == 0)
{
lean_ctor_set(v___x_84_, 1, v___x_89_);
lean_ctor_set(v___x_84_, 0, v___x_86_);
v___x_91_ = v___x_84_;
goto v_reusejp_90_;
}
else
{
lean_object* v_reuseFailAlloc_92_; 
v_reuseFailAlloc_92_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_92_, 0, v___x_86_);
lean_ctor_set(v_reuseFailAlloc_92_, 1, v___x_89_);
v___x_91_ = v_reuseFailAlloc_92_;
goto v_reusejp_90_;
}
v_reusejp_90_:
{
return v___x_91_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_picks(lean_object* v_00_u03b1_94_, lean_object* v_x_95_){
_start:
{
lean_object* v___x_96_; 
v___x_96_ = l_ADWH_Chapter01_Permutations_picks___redArg(v_x_95_);
return v___x_96_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0(lean_object* v_00_u03b1_97_, lean_object* v_head_98_, lean_object* v_a_99_, lean_object* v_a_100_){
_start:
{
lean_object* v___x_101_; 
v___x_101_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_picks_spec__0___redArg(v_head_98_, v_a_99_, v_a_100_);
return v___x_101_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0___redArg(lean_object* v_head_102_, lean_object* v_a_103_, lean_object* v_a_104_){
_start:
{
if (lean_obj_tag(v_a_103_) == 0)
{
lean_object* v___x_105_; 
lean_dec(v_head_102_);
v___x_105_ = lean_array_to_list(v_a_104_);
return v___x_105_;
}
else
{
lean_object* v_head_106_; lean_object* v_tail_107_; lean_object* v___x_108_; lean_object* v___x_109_; 
v_head_106_ = lean_ctor_get(v_a_103_, 0);
lean_inc(v_head_106_);
v_tail_107_ = lean_ctor_get(v_a_103_, 1);
lean_inc(v_tail_107_);
lean_dec_ref_known(v_a_103_, 2);
lean_inc(v_head_102_);
v___x_108_ = l_ADWH_Chapter01_Permutations_inserts___redArg(v_head_102_, v_head_106_);
v___x_109_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_104_, v___x_108_);
v_a_103_ = v_tail_107_;
v_a_104_ = v___x_109_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1___redArg(lean_object* v_x_113_){
_start:
{
if (lean_obj_tag(v_x_113_) == 0)
{
lean_object* v___x_114_; lean_object* v___x_115_; 
v___x_114_ = lean_box(0);
v___x_115_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_115_, 0, v_x_113_);
lean_ctor_set(v___x_115_, 1, v___x_114_);
return v___x_115_;
}
else
{
lean_object* v_head_116_; lean_object* v_tail_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; 
v_head_116_ = lean_ctor_get(v_x_113_, 0);
lean_inc(v_head_116_);
v_tail_117_ = lean_ctor_get(v_x_113_, 1);
lean_inc(v_tail_117_);
lean_dec_ref_known(v_x_113_, 2);
v___x_118_ = l_ADWH_Chapter01_Permutations_perms1___redArg(v_tail_117_);
v___x_119_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1___redArg___closed__0));
v___x_120_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0___redArg(v_head_116_, v___x_118_, v___x_119_);
return v___x_120_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1(lean_object* v_00_u03b1_121_, lean_object* v_x_122_){
_start:
{
lean_object* v___x_123_; 
v___x_123_ = l_ADWH_Chapter01_Permutations_perms1___redArg(v_x_122_);
return v___x_123_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0(lean_object* v_00_u03b1_124_, lean_object* v_head_125_, lean_object* v_a_126_, lean_object* v_a_127_){
_start:
{
lean_object* v___x_128_; 
v___x_128_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms1_spec__0___redArg(v_head_125_, v_a_126_, v_a_127_);
return v___x_128_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg___lam__0(lean_object* v_x_129_, lean_object* v_xss_130_){
_start:
{
lean_object* v___x_131_; lean_object* v___x_132_; 
v___x_131_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_inserts), 3, 2);
lean_closure_set(v___x_131_, 0, lean_box(0));
lean_closure_set(v___x_131_, 1, v_x_129_);
v___x_132_ = l_ADWH_Chapter01_Lists_concatMap___redArg(v___x_131_, v_xss_130_);
return v___x_132_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold___redArg(lean_object* v_xs_136_){
_start:
{
lean_object* v___f_137_; lean_object* v___x_138_; lean_object* v___x_139_; 
v___f_137_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__0));
v___x_138_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1));
v___x_139_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_137_, v___x_138_, v_xs_136_);
return v___x_139_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1Fold(lean_object* v_00_u03b1_140_, lean_object* v_xs_141_){
_start:
{
lean_object* v___x_142_; 
v___x_142_ = l_ADWH_Chapter01_Permutations_perms1Fold___redArg(v_xs_141_);
return v___x_142_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___lam__0(lean_object* v___y_143_, lean_object* v___y_144_){
_start:
{
lean_object* v___x_145_; lean_object* v___x_146_; 
v___x_145_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_inserts), 3, 2);
lean_closure_set(v___x_145_, 0, lean_box(0));
lean_closure_set(v___x_145_, 1, v___y_143_);
v___x_146_ = l_ADWH_Chapter01_Lists_concatMap___redArg(v___x_145_, v___y_144_);
return v___x_146_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg(lean_object* v_xs_148_){
_start:
{
lean_object* v___f_149_; lean_object* v___x_150_; lean_object* v___x_151_; 
v___f_149_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg___closed__0));
v___x_150_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1));
v___x_151_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_149_, v___x_150_, v_xs_148_);
return v___x_151_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms1FoldComp(lean_object* v_00_u03b1_152_, lean_object* v_xs_153_){
_start:
{
lean_object* v___x_154_; 
v___x_154_ = l_ADWH_Chapter01_Permutations_perms1FoldComp___redArg(v_xs_153_);
return v___x_154_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg(lean_object* v_p_155_, lean_object* v_a_156_, lean_object* v_a_157_){
_start:
{
if (lean_obj_tag(v_a_156_) == 0)
{
lean_object* v___x_158_; 
v___x_158_ = l_List_reverse___redArg(v_a_157_);
return v___x_158_;
}
else
{
lean_object* v_head_159_; lean_object* v_tail_160_; lean_object* v___x_162_; uint8_t v_isShared_163_; uint8_t v_isSharedCheck_170_; 
v_head_159_ = lean_ctor_get(v_a_156_, 0);
v_tail_160_ = lean_ctor_get(v_a_156_, 1);
v_isSharedCheck_170_ = !lean_is_exclusive(v_a_156_);
if (v_isSharedCheck_170_ == 0)
{
v___x_162_ = v_a_156_;
v_isShared_163_ = v_isSharedCheck_170_;
goto v_resetjp_161_;
}
else
{
lean_inc(v_tail_160_);
lean_inc(v_head_159_);
lean_dec(v_a_156_);
v___x_162_ = lean_box(0);
v_isShared_163_ = v_isSharedCheck_170_;
goto v_resetjp_161_;
}
v_resetjp_161_:
{
lean_object* v_fst_164_; lean_object* v___x_166_; 
v_fst_164_ = lean_ctor_get(v_p_155_, 0);
lean_inc(v_fst_164_);
if (v_isShared_163_ == 0)
{
lean_ctor_set(v___x_162_, 1, v_head_159_);
lean_ctor_set(v___x_162_, 0, v_fst_164_);
v___x_166_ = v___x_162_;
goto v_reusejp_165_;
}
else
{
lean_object* v_reuseFailAlloc_169_; 
v_reuseFailAlloc_169_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_169_, 0, v_fst_164_);
lean_ctor_set(v_reuseFailAlloc_169_, 1, v_head_159_);
v___x_166_ = v_reuseFailAlloc_169_;
goto v_reusejp_165_;
}
v_reusejp_165_:
{
lean_object* v___x_167_; 
v___x_167_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_167_, 0, v___x_166_);
lean_ctor_set(v___x_167_, 1, v_a_157_);
v_a_156_ = v_tail_160_;
v_a_157_ = v___x_167_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg___boxed(lean_object* v_p_171_, lean_object* v_a_172_, lean_object* v_a_173_){
_start:
{
lean_object* v_res_174_; 
v_res_174_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg(v_p_171_, v_a_172_, v_a_173_);
lean_dec_ref(v_p_171_);
return v_res_174_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1___redArg(lean_object* v_a_175_, lean_object* v_a_176_){
_start:
{
if (lean_obj_tag(v_a_175_) == 0)
{
lean_object* v___x_177_; 
v___x_177_ = lean_array_to_list(v_a_176_);
return v___x_177_;
}
else
{
lean_object* v_head_178_; lean_object* v_tail_179_; lean_object* v_snd_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; 
v_head_178_ = lean_ctor_get(v_a_175_, 0);
lean_inc(v_head_178_);
v_tail_179_ = lean_ctor_get(v_a_175_, 1);
lean_inc(v_tail_179_);
lean_dec_ref_known(v_a_175_, 2);
v_snd_180_ = lean_ctor_get(v_head_178_, 1);
lean_inc(v_snd_180_);
v___x_181_ = l_ADWH_Chapter01_Permutations_perms2___redArg(v_snd_180_);
v___x_182_ = lean_box(0);
v___x_183_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg(v_head_178_, v___x_181_, v___x_182_);
lean_dec(v_head_178_);
v___x_184_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_176_, v___x_183_);
v_a_175_ = v_tail_179_;
v_a_176_ = v___x_184_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2___redArg(lean_object* v_xs_186_){
_start:
{
uint8_t v___x_187_; 
v___x_187_ = l_List_instDecidableEqNil___redArg(v_xs_186_);
if (v___x_187_ == 0)
{
lean_object* v___x_188_; lean_object* v___x_189_; lean_object* v___x_190_; 
v___x_188_ = l_ADWH_Chapter01_Permutations_picks___redArg(v_xs_186_);
v___x_189_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1___redArg___closed__0));
v___x_190_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1___redArg(v___x_188_, v___x_189_);
return v___x_190_;
}
else
{
lean_object* v___x_191_; 
lean_dec(v_xs_186_);
v___x_191_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1));
return v___x_191_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2(lean_object* v_00_u03b1_192_, lean_object* v_xs_193_){
_start:
{
lean_object* v___x_194_; 
v___x_194_ = l_ADWH_Chapter01_Permutations_perms2___redArg(v_xs_193_);
return v___x_194_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0(lean_object* v_00_u03b1_195_, lean_object* v_p_196_, lean_object* v_a_197_, lean_object* v_a_198_){
_start:
{
lean_object* v___x_199_; 
v___x_199_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___redArg(v_p_196_, v_a_197_, v_a_198_);
return v___x_199_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0___boxed(lean_object* v_00_u03b1_200_, lean_object* v_p_201_, lean_object* v_a_202_, lean_object* v_a_203_){
_start:
{
lean_object* v_res_204_; 
v_res_204_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_perms2_spec__0(v_00_u03b1_200_, v_p_201_, v_a_202_, v_a_203_);
lean_dec_ref(v_p_201_);
return v_res_204_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1(lean_object* v_00_u03b1_205_, lean_object* v_a_206_, lean_object* v_a_207_){
_start:
{
lean_object* v___x_208_; 
v___x_208_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter01_Permutations_perms2_spec__1___redArg(v_a_206_, v_a_207_);
return v___x_208_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__0(lean_object* v_fst_209_, lean_object* v_x_210_){
_start:
{
lean_object* v___x_211_; 
v___x_211_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_211_, 0, v_fst_209_);
lean_ctor_set(v___x_211_, 1, v_x_210_);
return v___x_211_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg(lean_object* v_xs_212_){
_start:
{
uint8_t v___x_213_; 
v___x_213_ = l_List_instDecidableEqNil___redArg(v_xs_212_);
if (v___x_213_ == 0)
{
lean_object* v___f_214_; lean_object* v___x_215_; lean_object* v___x_216_; 
v___f_214_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__1), 1, 0);
v___x_215_ = l_ADWH_Chapter01_Permutations_picks___redArg(v_xs_212_);
v___x_216_ = l_ADWH_Chapter01_Lists_concatMap___redArg(v___f_214_, v___x_215_);
return v___x_216_;
}
else
{
lean_object* v___x_217_; 
lean_dec(v_xs_212_);
v___x_217_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_perms1Fold___redArg___closed__1));
return v___x_217_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__1(lean_object* v_p_218_){
_start:
{
lean_object* v_fst_219_; lean_object* v_snd_220_; lean_object* v___f_221_; lean_object* v___x_222_; lean_object* v___x_223_; 
v_fst_219_ = lean_ctor_get(v_p_218_, 0);
lean_inc(v_fst_219_);
v_snd_220_ = lean_ctor_get(v_p_218_, 1);
lean_inc(v_snd_220_);
lean_dec_ref(v_p_218_);
v___f_221_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_perms2Map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_221_, 0, v_fst_219_);
v___x_222_ = l_ADWH_Chapter01_Permutations_perms2Map___redArg(v_snd_220_);
v___x_223_ = l_ADWH_Chapter01_Lists_map___redArg(v___f_221_, v___x_222_);
return v___x_223_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_perms2Map(lean_object* v_00_u03b1_224_, lean_object* v_xs_225_){
_start:
{
lean_object* v___x_226_; 
v___x_226_ = l_ADWH_Chapter01_Permutations_perms2Map___redArg(v_xs_225_);
return v___x_226_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc___redArg___lam__0(lean_object* v_head_227_, lean_object* v_f_228_, lean_object* v_zs_229_){
_start:
{
lean_object* v___x_230_; lean_object* v___x_231_; 
v___x_230_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_230_, 0, v_head_227_);
lean_ctor_set(v___x_230_, 1, v_zs_229_);
v___x_231_ = lean_apply_1(v_f_228_, v___x_230_);
return v___x_231_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc___redArg(lean_object* v_f_232_, lean_object* v_x_233_, lean_object* v_x_234_){
_start:
{
if (lean_obj_tag(v_x_234_) == 0)
{
lean_object* v___x_235_; lean_object* v___x_236_; lean_object* v___x_237_; lean_object* v___x_238_; 
v___x_235_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_235_, 0, v_x_233_);
lean_ctor_set(v___x_235_, 1, v_x_234_);
v___x_236_ = lean_apply_1(v_f_232_, v___x_235_);
v___x_237_ = lean_box(0);
v___x_238_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_238_, 0, v___x_236_);
lean_ctor_set(v___x_238_, 1, v___x_237_);
return v___x_238_;
}
else
{
lean_object* v_head_239_; lean_object* v_tail_240_; lean_object* v___f_241_; lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; 
v_head_239_ = lean_ctor_get(v_x_234_, 0);
v_tail_240_ = lean_ctor_get(v_x_234_, 1);
lean_inc(v_tail_240_);
lean_inc(v_f_232_);
lean_inc(v_head_239_);
v___f_241_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_insertsAcc___redArg___lam__0), 3, 2);
lean_closure_set(v___f_241_, 0, v_head_239_);
lean_closure_set(v___f_241_, 1, v_f_232_);
lean_inc(v_x_233_);
v___x_242_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_242_, 0, v_x_233_);
lean_ctor_set(v___x_242_, 1, v_x_234_);
v___x_243_ = lean_apply_1(v_f_232_, v___x_242_);
v___x_244_ = l_ADWH_Chapter01_Permutations_insertsAcc___redArg(v___f_241_, v_x_233_, v_tail_240_);
v___x_245_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_245_, 0, v___x_243_);
lean_ctor_set(v___x_245_, 1, v___x_244_);
return v___x_245_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsAcc(lean_object* v_00_u03b1_246_, lean_object* v_00_u03b2_247_, lean_object* v_f_248_, lean_object* v_x_249_, lean_object* v_x_250_){
_start:
{
lean_object* v___x_251_; 
v___x_251_ = l_ADWH_Chapter01_Permutations_insertsAcc___redArg(v_f_248_, v_x_249_, v_x_250_);
return v___x_251_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0(lean_object* v___y_252_){
_start:
{
lean_inc(v___y_252_);
return v___y_252_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0___boxed(lean_object* v___y_253_){
_start:
{
lean_object* v_res_254_; 
v_res_254_ = l_ADWH_Chapter01_Permutations_insertsFast___redArg___lam__0(v___y_253_);
lean_dec(v___y_253_);
return v_res_254_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast___redArg(lean_object* v_x_256_, lean_object* v_xs_257_){
_start:
{
lean_object* v___f_258_; lean_object* v___x_259_; 
v___f_258_ = ((lean_object*)(l_ADWH_Chapter01_Permutations_insertsFast___redArg___closed__0));
v___x_259_ = l_ADWH_Chapter01_Permutations_insertsAcc___redArg(v___f_258_, v_x_256_, v_xs_257_);
return v___x_259_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsFast(lean_object* v_00_u03b1_260_, lean_object* v_x_261_, lean_object* v_xs_262_){
_start:
{
lean_object* v___x_263_; 
v___x_263_ = l_ADWH_Chapter01_Permutations_insertsFast___redArg(v_x_261_, v_xs_262_);
return v___x_263_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertStep___redArg(lean_object* v_x_264_, lean_object* v_y_265_, lean_object* v_yss_266_){
_start:
{
lean_object* v___x_267_; 
v___x_267_ = l_ADWH_Chapter01_Lists_head___redArg(v_yss_266_);
if (lean_obj_tag(v___x_267_) == 0)
{
lean_object* v___x_268_; 
lean_dec(v_yss_266_);
lean_dec(v_y_265_);
lean_dec(v_x_264_);
v___x_268_ = lean_box(0);
return v___x_268_;
}
else
{
lean_object* v_val_269_; lean_object* v___x_270_; 
v_val_269_ = lean_ctor_get(v___x_267_, 0);
lean_inc(v_val_269_);
lean_dec_ref_known(v___x_267_, 1);
v___x_270_ = l_ADWH_Chapter01_Lists_tail___redArg(v_val_269_);
lean_dec(v_val_269_);
if (lean_obj_tag(v___x_270_) == 0)
{
lean_object* v___x_271_; 
lean_dec(v_yss_266_);
lean_dec(v_y_265_);
lean_dec(v_x_264_);
v___x_271_ = lean_box(0);
return v___x_271_;
}
else
{
lean_object* v_val_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; lean_object* v___x_276_; lean_object* v___x_277_; 
v_val_272_ = lean_ctor_get(v___x_270_, 0);
lean_inc(v_val_272_);
lean_dec_ref_known(v___x_270_, 1);
lean_inc(v_y_265_);
v___x_273_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_273_, 0, v_y_265_);
lean_ctor_set(v___x_273_, 1, v_val_272_);
v___x_274_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_274_, 0, v_x_264_);
lean_ctor_set(v___x_274_, 1, v___x_273_);
v___x_275_ = lean_box(0);
v___x_276_ = l_List_mapTR_loop___at___00ADWH_Chapter01_Permutations_inserts_spec__0___redArg(v_y_265_, v_yss_266_, v___x_275_);
v___x_277_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_277_, 0, v___x_274_);
lean_ctor_set(v___x_277_, 1, v___x_276_);
return v___x_277_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertStep(lean_object* v_00_u03b1_278_, lean_object* v_x_279_, lean_object* v_y_280_, lean_object* v_yss_281_){
_start:
{
lean_object* v___x_282_; 
v___x_282_ = l_ADWH_Chapter01_Permutations_insertStep___redArg(v_x_279_, v_y_280_, v_yss_281_);
return v___x_282_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsByFold___redArg(lean_object* v_x_283_, lean_object* v_xs_284_){
_start:
{
lean_object* v___x_285_; lean_object* v___x_286_; lean_object* v___x_287_; lean_object* v___x_288_; lean_object* v___x_289_; 
lean_inc(v_x_283_);
v___x_285_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Permutations_insertStep), 4, 2);
lean_closure_set(v___x_285_, 0, lean_box(0));
lean_closure_set(v___x_285_, 1, v_x_283_);
v___x_286_ = lean_box(0);
v___x_287_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_287_, 0, v_x_283_);
lean_ctor_set(v___x_287_, 1, v___x_286_);
v___x_288_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_288_, 0, v___x_287_);
lean_ctor_set(v___x_288_, 1, v___x_286_);
v___x_289_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___x_285_, v___x_288_, v_xs_284_);
lean_dec_ref_known(v___x_288_, 2);
return v___x_289_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_insertsByFold(lean_object* v_00_u03b1_290_, lean_object* v_x_291_, lean_object* v_xs_292_){
_start:
{
lean_object* v___x_293_; 
v___x_293_ = l_ADWH_Chapter01_Permutations_insertsByFold___redArg(v_x_291_, v_xs_292_);
return v___x_293_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_factorial(lean_object* v_x_294_){
_start:
{
lean_object* v_zero_295_; uint8_t v_isZero_296_; 
v_zero_295_ = lean_unsigned_to_nat(0u);
v_isZero_296_ = lean_nat_dec_eq(v_x_294_, v_zero_295_);
if (v_isZero_296_ == 1)
{
lean_object* v___x_297_; 
v___x_297_ = lean_unsigned_to_nat(1u);
return v___x_297_;
}
else
{
lean_object* v_one_298_; lean_object* v_n_299_; lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; 
v_one_298_ = lean_unsigned_to_nat(1u);
v_n_299_ = lean_nat_sub(v_x_294_, v_one_298_);
v___x_300_ = lean_nat_add(v_n_299_, v_one_298_);
v___x_301_ = l_ADWH_Chapter01_Permutations_factorial(v_n_299_);
lean_dec(v_n_299_);
v___x_302_ = lean_nat_mul(v___x_300_, v___x_301_);
lean_dec(v___x_301_);
lean_dec(v___x_300_);
return v___x_302_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Permutations_factorial___boxed(lean_object* v_x_303_){
_start:
{
lean_object* v_res_304_; 
v_res_304_ = l_ADWH_Chapter01_Permutations_factorial(v_x_303_);
lean_dec(v_x_303_);
return v_res_304_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___redArg(lean_object* v_x_305_, lean_object* v_h__1_306_, lean_object* v_h__2_307_){
_start:
{
lean_object* v_zero_308_; uint8_t v_isZero_309_; 
v_zero_308_ = lean_unsigned_to_nat(0u);
v_isZero_309_ = lean_nat_dec_eq(v_x_305_, v_zero_308_);
if (v_isZero_309_ == 1)
{
lean_object* v___x_310_; lean_object* v___x_311_; 
lean_dec(v_h__2_307_);
v___x_310_ = lean_box(0);
v___x_311_ = lean_apply_1(v_h__1_306_, v___x_310_);
return v___x_311_;
}
else
{
lean_object* v_one_312_; lean_object* v_n_313_; lean_object* v___x_314_; 
lean_dec(v_h__1_306_);
v_one_312_ = lean_unsigned_to_nat(1u);
v_n_313_ = lean_nat_sub(v_x_305_, v_one_312_);
v___x_314_ = lean_apply_1(v_h__2_307_, v_n_313_);
return v___x_314_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___redArg___boxed(lean_object* v_x_315_, lean_object* v_h__1_316_, lean_object* v_h__2_317_){
_start:
{
lean_object* v_res_318_; 
v_res_318_ = l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___redArg(v_x_315_, v_h__1_316_, v_h__2_317_);
lean_dec(v_x_315_);
return v_res_318_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter(lean_object* v_motive_319_, lean_object* v_x_320_, lean_object* v_h__1_321_, lean_object* v_h__2_322_){
_start:
{
lean_object* v_zero_323_; uint8_t v_isZero_324_; 
v_zero_323_ = lean_unsigned_to_nat(0u);
v_isZero_324_ = lean_nat_dec_eq(v_x_320_, v_zero_323_);
if (v_isZero_324_ == 1)
{
lean_object* v___x_325_; lean_object* v___x_326_; 
lean_dec(v_h__2_322_);
v___x_325_ = lean_box(0);
v___x_326_ = lean_apply_1(v_h__1_321_, v___x_325_);
return v___x_326_;
}
else
{
lean_object* v_one_327_; lean_object* v_n_328_; lean_object* v___x_329_; 
lean_dec(v_h__1_321_);
v_one_327_ = lean_unsigned_to_nat(1u);
v_n_328_ = lean_nat_sub(v_x_320_, v_one_327_);
v___x_329_ = lean_apply_1(v_h__2_322_, v_n_328_);
return v___x_329_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter___boxed(lean_object* v_motive_330_, lean_object* v_x_331_, lean_object* v_h__1_332_, lean_object* v_h__2_333_){
_start:
{
lean_object* v_res_334_; 
v_res_334_ = l___private_ADWH_Chapter01_Permutations_0__ADWH_Chapter01_Permutations_factorial_match__1_splitter(v_motive_330_, v_x_331_, v_h__1_332_, v_h__2_333_);
lean_dec(v_x_331_);
return v_res_334_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter01_Lists(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter01_Permutations(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter01_Lists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
