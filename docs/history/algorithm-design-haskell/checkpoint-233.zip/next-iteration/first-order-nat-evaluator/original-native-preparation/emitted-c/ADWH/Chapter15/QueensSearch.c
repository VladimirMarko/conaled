// Lean compiler output
// Module: ADWH.Chapter15.QueensSearch
// Imports: public import Init public meta import Init public import ADWH.Chapter15.QueensVariants
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_ADWH_Chapter15_Queens_columns(lean_object*);
lean_object* l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_List_foldl___at___00Array_appendList_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_moves(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_successors(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_solved(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_solved___boxed(lean_object*, lean_object*);
static const lean_array_object l_ADWH_Chapter15_Queens_expandRows___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_ADWH_Chapter15_Queens_expandRows___closed__0 = (const lean_object*)&l_ADWH_Chapter15_Queens_expandRows___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_expandRows(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_expandRows___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_solutionsQ(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_searchQ_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_searchQ(lean_object*, lean_object*);
static const lean_ctor_object l_ADWH_Chapter15_Queens_queens3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_ADWH_Chapter15_Queens_queens3___closed__0 = (const lean_object*)&l_ADWH_Chapter15_Queens_queens3___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens3(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_searchStep(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Nat_Basic_0__Nat_repeatTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_trace(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_trace___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_moves(lean_object* v_n_1_, lean_object* v_qs_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; lean_object* v___x_5_; 
v___x_3_ = l_ADWH_Chapter15_Queens_columns(v_n_1_);
v___x_4_ = lean_box(0);
v___x_5_ = l_List_filterTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__0(v_qs_2_, v___x_3_, v___x_4_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_successors(lean_object* v_n_6_, lean_object* v_qs_7_){
_start:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
lean_inc(v_qs_7_);
v___x_8_ = l_ADWH_Chapter15_Queens_moves(v_n_6_, v_qs_7_);
v___x_9_ = lean_box(0);
v___x_10_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_place4_spec__1(v_qs_7_, v___x_8_, v___x_9_);
return v___x_10_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_solved(lean_object* v_n_11_, lean_object* v_qs_12_){
_start:
{
lean_object* v___x_13_; uint8_t v___x_14_; 
v___x_13_ = l_List_lengthTR___redArg(v_qs_12_);
v___x_14_ = lean_nat_dec_eq(v___x_13_, v_n_11_);
lean_dec(v___x_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_solved___boxed(lean_object* v_n_15_, lean_object* v_qs_16_){
_start:
{
uint8_t v_res_17_; lean_object* v_r_18_; 
v_res_17_ = l_ADWH_Chapter15_Queens_solved(v_n_15_, v_qs_16_);
lean_dec(v_qs_16_);
lean_dec(v_n_15_);
v_r_18_ = lean_box(v_res_17_);
return v_r_18_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_expandRows(lean_object* v_n_21_, lean_object* v_x_22_, lean_object* v_x_23_){
_start:
{
lean_object* v_zero_24_; uint8_t v_isZero_25_; 
v_zero_24_ = lean_unsigned_to_nat(0u);
v_isZero_25_ = lean_nat_dec_eq(v_x_22_, v_zero_24_);
if (v_isZero_25_ == 1)
{
lean_object* v___x_26_; lean_object* v___x_27_; 
lean_dec(v_n_21_);
v___x_26_ = lean_box(0);
v___x_27_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_27_, 0, v_x_23_);
lean_ctor_set(v___x_27_, 1, v___x_26_);
return v___x_27_;
}
else
{
lean_object* v_one_28_; lean_object* v_n_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v_one_28_ = lean_unsigned_to_nat(1u);
v_n_29_ = lean_nat_sub(v_x_22_, v_one_28_);
lean_inc(v_n_21_);
v___x_30_ = l_ADWH_Chapter15_Queens_successors(v_n_21_, v_x_23_);
v___x_31_ = ((lean_object*)(l_ADWH_Chapter15_Queens_expandRows___closed__0));
v___x_32_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0(v_n_21_, v_n_29_, v___x_30_, v___x_31_);
lean_dec(v_n_29_);
return v___x_32_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0(lean_object* v_n_33_, lean_object* v_n_34_, lean_object* v_a_35_, lean_object* v_a_36_){
_start:
{
if (lean_obj_tag(v_a_35_) == 0)
{
lean_object* v___x_37_; 
lean_dec(v_n_33_);
v___x_37_ = lean_array_to_list(v_a_36_);
return v___x_37_;
}
else
{
lean_object* v_head_38_; lean_object* v_tail_39_; lean_object* v___x_40_; lean_object* v___x_41_; 
v_head_38_ = lean_ctor_get(v_a_35_, 0);
lean_inc(v_head_38_);
v_tail_39_ = lean_ctor_get(v_a_35_, 1);
lean_inc(v_tail_39_);
lean_dec_ref_known(v_a_35_, 2);
lean_inc(v_n_33_);
v___x_40_ = l_ADWH_Chapter15_Queens_expandRows(v_n_33_, v_n_34_, v_head_38_);
v___x_41_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_36_, v___x_40_);
v_a_35_ = v_tail_39_;
v_a_36_ = v___x_41_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0___boxed(lean_object* v_n_43_, lean_object* v_n_44_, lean_object* v_a_45_, lean_object* v_a_46_){
_start:
{
lean_object* v_res_47_; 
v_res_47_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_expandRows_spec__0(v_n_43_, v_n_44_, v_a_45_, v_a_46_);
lean_dec(v_n_44_);
return v_res_47_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_expandRows___boxed(lean_object* v_n_48_, lean_object* v_x_49_, lean_object* v_x_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = l_ADWH_Chapter15_Queens_expandRows(v_n_48_, v_x_49_, v_x_50_);
lean_dec(v_x_49_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___redArg(lean_object* v_x_52_, lean_object* v_x_53_, lean_object* v_h__1_54_, lean_object* v_h__2_55_){
_start:
{
lean_object* v_zero_56_; uint8_t v_isZero_57_; 
v_zero_56_ = lean_unsigned_to_nat(0u);
v_isZero_57_ = lean_nat_dec_eq(v_x_52_, v_zero_56_);
if (v_isZero_57_ == 1)
{
lean_object* v___x_58_; 
lean_dec(v_h__2_55_);
v___x_58_ = lean_apply_1(v_h__1_54_, v_x_53_);
return v___x_58_;
}
else
{
lean_object* v_one_59_; lean_object* v_n_60_; lean_object* v___x_61_; 
lean_dec(v_h__1_54_);
v_one_59_ = lean_unsigned_to_nat(1u);
v_n_60_ = lean_nat_sub(v_x_52_, v_one_59_);
v___x_61_ = lean_apply_2(v_h__2_55_, v_n_60_, v_x_53_);
return v___x_61_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___redArg___boxed(lean_object* v_x_62_, lean_object* v_x_63_, lean_object* v_h__1_64_, lean_object* v_h__2_65_){
_start:
{
lean_object* v_res_66_; 
v_res_66_ = l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___redArg(v_x_62_, v_x_63_, v_h__1_64_, v_h__2_65_);
lean_dec(v_x_62_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter(lean_object* v_motive_67_, lean_object* v_x_68_, lean_object* v_x_69_, lean_object* v_h__1_70_, lean_object* v_h__2_71_){
_start:
{
lean_object* v_zero_72_; uint8_t v_isZero_73_; 
v_zero_72_ = lean_unsigned_to_nat(0u);
v_isZero_73_ = lean_nat_dec_eq(v_x_68_, v_zero_72_);
if (v_isZero_73_ == 1)
{
lean_object* v___x_74_; 
lean_dec(v_h__2_71_);
v___x_74_ = lean_apply_1(v_h__1_70_, v_x_69_);
return v___x_74_;
}
else
{
lean_object* v_one_75_; lean_object* v_n_76_; lean_object* v___x_77_; 
lean_dec(v_h__1_70_);
v_one_75_ = lean_unsigned_to_nat(1u);
v_n_76_ = lean_nat_sub(v_x_68_, v_one_75_);
v___x_77_ = lean_apply_2(v_h__2_71_, v_n_76_, v_x_69_);
return v___x_77_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter___boxed(lean_object* v_motive_78_, lean_object* v_x_79_, lean_object* v_x_80_, lean_object* v_h__1_81_, lean_object* v_h__2_82_){
_start:
{
lean_object* v_res_83_; 
v_res_83_ = l___private_ADWH_Chapter15_QueensSearch_0__ADWH_Chapter15_Queens_expandRows_match__1_splitter(v_motive_78_, v_x_79_, v_x_80_, v_h__1_81_, v_h__2_82_);
lean_dec(v_x_79_);
return v_res_83_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_solutionsQ(lean_object* v_n_84_, lean_object* v_qs_85_){
_start:
{
lean_object* v___x_86_; uint8_t v___x_87_; 
v___x_86_ = l_List_lengthTR___redArg(v_qs_85_);
v___x_87_ = lean_nat_dec_le(v___x_86_, v_n_84_);
if (v___x_87_ == 0)
{
lean_object* v___x_88_; 
lean_dec(v___x_86_);
lean_dec(v_qs_85_);
lean_dec(v_n_84_);
v___x_88_ = lean_box(0);
return v___x_88_;
}
else
{
lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_89_ = lean_nat_sub(v_n_84_, v___x_86_);
lean_dec(v___x_86_);
v___x_90_ = l_ADWH_Chapter15_Queens_expandRows(v_n_84_, v___x_89_, v_qs_85_);
lean_dec(v___x_89_);
return v___x_90_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_searchQ_spec__0(lean_object* v_n_91_, lean_object* v_a_92_, lean_object* v_a_93_){
_start:
{
if (lean_obj_tag(v_a_92_) == 0)
{
lean_object* v___x_94_; 
lean_dec(v_n_91_);
v___x_94_ = lean_array_to_list(v_a_93_);
return v___x_94_;
}
else
{
lean_object* v_head_95_; lean_object* v_tail_96_; lean_object* v___x_97_; lean_object* v___x_98_; 
v_head_95_ = lean_ctor_get(v_a_92_, 0);
lean_inc(v_head_95_);
v_tail_96_ = lean_ctor_get(v_a_92_, 1);
lean_inc(v_tail_96_);
lean_dec_ref_known(v_a_92_, 2);
lean_inc(v_n_91_);
v___x_97_ = l_ADWH_Chapter15_Queens_solutionsQ(v_n_91_, v_head_95_);
v___x_98_ = l_List_foldl___at___00Array_appendList_spec__0___redArg(v_a_93_, v___x_97_);
v_a_92_ = v_tail_96_;
v_a_93_ = v___x_98_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_searchQ(lean_object* v_n_100_, lean_object* v_pending_101_){
_start:
{
lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_102_ = ((lean_object*)(l_ADWH_Chapter15_Queens_expandRows___closed__0));
v___x_103_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00ADWH_Chapter15_Queens_searchQ_spec__0(v_n_100_, v_pending_101_, v___x_102_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_queens3(lean_object* v_n_106_){
_start:
{
lean_object* v___x_107_; lean_object* v___x_108_; 
v___x_107_ = ((lean_object*)(l_ADWH_Chapter15_Queens_queens3___closed__0));
v___x_108_ = l_ADWH_Chapter15_Queens_searchQ(v_n_106_, v___x_107_);
return v___x_108_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_searchStep(lean_object* v_n_109_, lean_object* v_x_110_){
_start:
{
if (lean_obj_tag(v_x_110_) == 0)
{
lean_dec(v_n_109_);
return v_x_110_;
}
else
{
lean_object* v_head_111_; lean_object* v_tail_112_; uint8_t v___x_113_; 
v_head_111_ = lean_ctor_get(v_x_110_, 0);
lean_inc(v_head_111_);
v_tail_112_ = lean_ctor_get(v_x_110_, 1);
lean_inc(v_tail_112_);
lean_dec_ref_known(v_x_110_, 2);
v___x_113_ = l_ADWH_Chapter15_Queens_solved(v_n_109_, v_head_111_);
if (v___x_113_ == 0)
{
lean_object* v___x_114_; lean_object* v___x_115_; 
v___x_114_ = l_ADWH_Chapter15_Queens_successors(v_n_109_, v_head_111_);
v___x_115_ = l_List_appendTR___redArg(v___x_114_, v_tail_112_);
return v___x_115_;
}
else
{
lean_dec(v_head_111_);
lean_dec(v_n_109_);
return v_tail_112_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Nat_Basic_0__Nat_repeatTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__0(lean_object* v_n_116_, lean_object* v_x_117_, lean_object* v_x_118_){
_start:
{
lean_object* v_zero_119_; uint8_t v_isZero_120_; 
v_zero_119_ = lean_unsigned_to_nat(0u);
v_isZero_120_ = lean_nat_dec_eq(v_x_117_, v_zero_119_);
if (v_isZero_120_ == 1)
{
lean_dec(v_x_117_);
lean_dec(v_n_116_);
return v_x_118_;
}
else
{
lean_object* v_one_121_; lean_object* v_n_122_; lean_object* v___x_123_; 
v_one_121_ = lean_unsigned_to_nat(1u);
v_n_122_ = lean_nat_sub(v_x_117_, v_one_121_);
lean_dec(v_x_117_);
lean_inc(v_n_116_);
v___x_123_ = l_ADWH_Chapter15_Queens_searchStep(v_n_116_, v_x_118_);
v_x_117_ = v_n_122_;
v_x_118_ = v___x_123_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__1(lean_object* v_n_125_, lean_object* v_a_126_, lean_object* v_a_127_){
_start:
{
if (lean_obj_tag(v_a_126_) == 0)
{
lean_object* v___x_128_; 
lean_dec(v_n_125_);
v___x_128_ = l_List_reverse___redArg(v_a_127_);
return v___x_128_;
}
else
{
lean_object* v_head_129_; lean_object* v_tail_130_; lean_object* v___x_132_; uint8_t v_isShared_133_; uint8_t v_isSharedCheck_140_; 
v_head_129_ = lean_ctor_get(v_a_126_, 0);
v_tail_130_ = lean_ctor_get(v_a_126_, 1);
v_isSharedCheck_140_ = !lean_is_exclusive(v_a_126_);
if (v_isSharedCheck_140_ == 0)
{
v___x_132_ = v_a_126_;
v_isShared_133_ = v_isSharedCheck_140_;
goto v_resetjp_131_;
}
else
{
lean_inc(v_tail_130_);
lean_inc(v_head_129_);
lean_dec(v_a_126_);
v___x_132_ = lean_box(0);
v_isShared_133_ = v_isSharedCheck_140_;
goto v_resetjp_131_;
}
v_resetjp_131_:
{
lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_137_; 
v___x_134_ = ((lean_object*)(l_ADWH_Chapter15_Queens_queens3___closed__0));
lean_inc(v_n_125_);
v___x_135_ = l___private_Init_Data_Nat_Basic_0__Nat_repeatTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__0(v_n_125_, v_head_129_, v___x_134_);
if (v_isShared_133_ == 0)
{
lean_ctor_set(v___x_132_, 1, v_a_127_);
lean_ctor_set(v___x_132_, 0, v___x_135_);
v___x_137_ = v___x_132_;
goto v_reusejp_136_;
}
else
{
lean_object* v_reuseFailAlloc_139_; 
v_reuseFailAlloc_139_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_139_, 0, v___x_135_);
lean_ctor_set(v_reuseFailAlloc_139_, 1, v_a_127_);
v___x_137_ = v_reuseFailAlloc_139_;
goto v_reusejp_136_;
}
v_reusejp_136_:
{
v_a_126_ = v_tail_130_;
v_a_127_ = v___x_137_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_trace(lean_object* v_n_141_, lean_object* v_steps_142_){
_start:
{
lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; 
v___x_143_ = lean_unsigned_to_nat(1u);
v___x_144_ = lean_nat_add(v_steps_142_, v___x_143_);
v___x_145_ = l_List_range(v___x_144_);
v___x_146_ = lean_box(0);
v___x_147_ = l_List_mapTR_loop___at___00ADWH_Chapter15_Queens_trace_spec__1(v_n_141_, v___x_145_, v___x_146_);
return v___x_147_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_trace___boxed(lean_object* v_n_148_, lean_object* v_steps_149_){
_start:
{
lean_object* v_res_150_; 
v_res_150_ = l_ADWH_Chapter15_Queens_trace(v_n_148_, v_steps_149_);
lean_dec(v_steps_149_);
return v_res_150_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter15_QueensVariants(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter15_QueensSearch(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter15_QueensVariants(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
