// Lean compiler output
// Module: ADWH.Chapter01.Lists
// Imports: public import Init public meta import Init public import Std
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t l_List_instDecidableEqNil___redArg(lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_pop(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_List_getLast___redArg(lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t l_List_isEmpty___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_map___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_map(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_filter___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_filter(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldl___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_map_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_map_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_lengthR___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_lengthR___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_lengthL___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_lengthL___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_concat1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_List_appendTR___redArg, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_concat1___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_concat1___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat1___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat2___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__1___boxed(lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_concatD___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_concatD___redArg___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_concatD___redArg___closed__0_value;
static const lean_closure_object l_ADWH_Chapter01_Lists_concatD___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_concatD___redArg___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___closed__1 = (const lean_object*)&l_ADWH_Chapter01_Lists_concatD___redArg___closed__1_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatMap___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatMap(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverseAcc___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverseAcc(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse___redArg___lam__0(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_reverse___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_reverse___redArg___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_reverse___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_reverse___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_reverseAcc_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_reverseAcc_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_flip___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_flip(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanl___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanr___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_labelFrom___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_labelFrom(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_label___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_label(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_uncons___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_uncons(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_wrap___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_wrap(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter01_Lists_single___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_single___redArg___boxed(lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter01_Lists_single(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_single___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_unwrap_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_unwrap_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_init___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_init(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_ADWH_Chapter01_Lists_headByFold___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg___closed__0 = (const lean_object*)&l_ADWH_Chapter01_Lists_headByFold___redArg___closed__0_value;
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_last_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_last_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlByInit___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlByInit(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_map___redArg(lean_object* v_f_1_, lean_object* v_x_2_){
_start:
{
if (lean_obj_tag(v_x_2_) == 0)
{
lean_object* v___x_3_; 
lean_dec(v_f_1_);
v___x_3_ = lean_box(0);
return v___x_3_;
}
else
{
lean_object* v_head_4_; lean_object* v_tail_5_; lean_object* v___x_7_; uint8_t v_isShared_8_; uint8_t v_isSharedCheck_14_; 
v_head_4_ = lean_ctor_get(v_x_2_, 0);
v_tail_5_ = lean_ctor_get(v_x_2_, 1);
v_isSharedCheck_14_ = !lean_is_exclusive(v_x_2_);
if (v_isSharedCheck_14_ == 0)
{
v___x_7_ = v_x_2_;
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
else
{
lean_inc(v_tail_5_);
lean_inc(v_head_4_);
lean_dec(v_x_2_);
v___x_7_ = lean_box(0);
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
v_resetjp_6_:
{
lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_12_; 
lean_inc(v_f_1_);
v___x_9_ = lean_apply_1(v_f_1_, v_head_4_);
v___x_10_ = l_ADWH_Chapter01_Lists_map___redArg(v_f_1_, v_tail_5_);
if (v_isShared_8_ == 0)
{
lean_ctor_set(v___x_7_, 1, v___x_10_);
lean_ctor_set(v___x_7_, 0, v___x_9_);
v___x_12_ = v___x_7_;
goto v_reusejp_11_;
}
else
{
lean_object* v_reuseFailAlloc_13_; 
v_reuseFailAlloc_13_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_13_, 0, v___x_9_);
lean_ctor_set(v_reuseFailAlloc_13_, 1, v___x_10_);
v___x_12_ = v_reuseFailAlloc_13_;
goto v_reusejp_11_;
}
v_reusejp_11_:
{
return v___x_12_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_map(lean_object* v_00_u03b1_15_, lean_object* v_00_u03b2_16_, lean_object* v_f_17_, lean_object* v_x_18_){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = l_ADWH_Chapter01_Lists_map___redArg(v_f_17_, v_x_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_filter___redArg(lean_object* v_p_20_, lean_object* v_x_21_){
_start:
{
if (lean_obj_tag(v_x_21_) == 0)
{
lean_dec_ref(v_p_20_);
return v_x_21_;
}
else
{
lean_object* v_head_22_; lean_object* v_tail_23_; lean_object* v___x_25_; uint8_t v_isShared_26_; uint8_t v_isSharedCheck_34_; 
v_head_22_ = lean_ctor_get(v_x_21_, 0);
v_tail_23_ = lean_ctor_get(v_x_21_, 1);
v_isSharedCheck_34_ = !lean_is_exclusive(v_x_21_);
if (v_isSharedCheck_34_ == 0)
{
v___x_25_ = v_x_21_;
v_isShared_26_ = v_isSharedCheck_34_;
goto v_resetjp_24_;
}
else
{
lean_inc(v_tail_23_);
lean_inc(v_head_22_);
lean_dec(v_x_21_);
v___x_25_ = lean_box(0);
v_isShared_26_ = v_isSharedCheck_34_;
goto v_resetjp_24_;
}
v_resetjp_24_:
{
lean_object* v___x_27_; uint8_t v___x_28_; 
lean_inc_ref(v_p_20_);
lean_inc(v_head_22_);
v___x_27_ = lean_apply_1(v_p_20_, v_head_22_);
v___x_28_ = lean_unbox(v___x_27_);
if (v___x_28_ == 0)
{
lean_del_object(v___x_25_);
lean_dec(v_head_22_);
v_x_21_ = v_tail_23_;
goto _start;
}
else
{
lean_object* v___x_30_; lean_object* v___x_32_; 
v___x_30_ = l_ADWH_Chapter01_Lists_filter___redArg(v_p_20_, v_tail_23_);
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v___x_30_);
v___x_32_ = v___x_25_;
goto v_reusejp_31_;
}
else
{
lean_object* v_reuseFailAlloc_33_; 
v_reuseFailAlloc_33_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_33_, 0, v_head_22_);
lean_ctor_set(v_reuseFailAlloc_33_, 1, v___x_30_);
v___x_32_ = v_reuseFailAlloc_33_;
goto v_reusejp_31_;
}
v_reusejp_31_:
{
return v___x_32_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_filter(lean_object* v_00_u03b1_35_, lean_object* v_p_36_, lean_object* v_x_37_){
_start:
{
lean_object* v___x_38_; 
v___x_38_ = l_ADWH_Chapter01_Lists_filter___redArg(v_p_36_, v_x_37_);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___redArg(lean_object* v_f_39_, lean_object* v_e_40_, lean_object* v_x_41_){
_start:
{
if (lean_obj_tag(v_x_41_) == 0)
{
lean_dec(v_f_39_);
lean_inc(v_e_40_);
return v_e_40_;
}
else
{
lean_object* v_head_42_; lean_object* v_tail_43_; lean_object* v___x_44_; lean_object* v___x_45_; 
v_head_42_ = lean_ctor_get(v_x_41_, 0);
lean_inc(v_head_42_);
v_tail_43_ = lean_ctor_get(v_x_41_, 1);
lean_inc(v_tail_43_);
lean_dec_ref_known(v_x_41_, 2);
lean_inc(v_f_39_);
v___x_44_ = l_ADWH_Chapter01_Lists_foldr___redArg(v_f_39_, v_e_40_, v_tail_43_);
v___x_45_ = lean_apply_2(v_f_39_, v_head_42_, v___x_44_);
return v___x_45_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___redArg___boxed(lean_object* v_f_46_, lean_object* v_e_47_, lean_object* v_x_48_){
_start:
{
lean_object* v_res_49_; 
v_res_49_ = l_ADWH_Chapter01_Lists_foldr___redArg(v_f_46_, v_e_47_, v_x_48_);
lean_dec(v_e_47_);
return v_res_49_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr(lean_object* v_00_u03b1_50_, lean_object* v_00_u03b2_51_, lean_object* v_f_52_, lean_object* v_e_53_, lean_object* v_x_54_){
_start:
{
lean_object* v___x_55_; 
v___x_55_ = l_ADWH_Chapter01_Lists_foldr___redArg(v_f_52_, v_e_53_, v_x_54_);
return v___x_55_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldr___boxed(lean_object* v_00_u03b1_56_, lean_object* v_00_u03b2_57_, lean_object* v_f_58_, lean_object* v_e_59_, lean_object* v_x_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = l_ADWH_Chapter01_Lists_foldr(v_00_u03b1_56_, v_00_u03b2_57_, v_f_58_, v_e_59_, v_x_60_);
lean_dec(v_e_59_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldl___redArg(lean_object* v_f_62_, lean_object* v_e_63_, lean_object* v_x_64_){
_start:
{
if (lean_obj_tag(v_x_64_) == 0)
{
lean_dec(v_f_62_);
return v_e_63_;
}
else
{
lean_object* v_head_65_; lean_object* v_tail_66_; lean_object* v___x_67_; 
v_head_65_ = lean_ctor_get(v_x_64_, 0);
lean_inc(v_head_65_);
v_tail_66_ = lean_ctor_get(v_x_64_, 1);
lean_inc(v_tail_66_);
lean_dec_ref_known(v_x_64_, 2);
lean_inc(v_f_62_);
v___x_67_ = lean_apply_2(v_f_62_, v_e_63_, v_head_65_);
v_e_63_ = v___x_67_;
v_x_64_ = v_tail_66_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldl(lean_object* v_00_u03b1_69_, lean_object* v_00_u03b2_70_, lean_object* v_f_71_, lean_object* v_e_72_, lean_object* v_x_73_){
_start:
{
lean_object* v___x_74_; 
v___x_74_ = l_ADWH_Chapter01_Lists_foldl___redArg(v_f_71_, v_e_72_, v_x_73_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_map_match__1_splitter___redArg(lean_object* v_x_75_, lean_object* v_h__1_76_, lean_object* v_h__2_77_){
_start:
{
if (lean_obj_tag(v_x_75_) == 0)
{
lean_object* v___x_78_; lean_object* v___x_79_; 
lean_dec(v_h__2_77_);
v___x_78_ = lean_box(0);
v___x_79_ = lean_apply_1(v_h__1_76_, v___x_78_);
return v___x_79_;
}
else
{
lean_object* v_head_80_; lean_object* v_tail_81_; lean_object* v___x_82_; 
lean_dec(v_h__1_76_);
v_head_80_ = lean_ctor_get(v_x_75_, 0);
lean_inc(v_head_80_);
v_tail_81_ = lean_ctor_get(v_x_75_, 1);
lean_inc(v_tail_81_);
lean_dec_ref_known(v_x_75_, 2);
v___x_82_ = lean_apply_2(v_h__2_77_, v_head_80_, v_tail_81_);
return v___x_82_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_map_match__1_splitter(lean_object* v_00_u03b1_83_, lean_object* v_motive_84_, lean_object* v_x_85_, lean_object* v_h__1_86_, lean_object* v_h__2_87_){
_start:
{
if (lean_obj_tag(v_x_85_) == 0)
{
lean_object* v___x_88_; lean_object* v___x_89_; 
lean_dec(v_h__2_87_);
v___x_88_ = lean_box(0);
v___x_89_ = lean_apply_1(v_h__1_86_, v___x_88_);
return v___x_89_;
}
else
{
lean_object* v_head_90_; lean_object* v_tail_91_; lean_object* v___x_92_; 
lean_dec(v_h__1_86_);
v_head_90_ = lean_ctor_get(v_x_85_, 0);
lean_inc(v_head_90_);
v_tail_91_ = lean_ctor_get(v_x_85_, 1);
lean_inc(v_tail_91_);
lean_dec_ref_known(v_x_85_, 2);
v___x_92_ = lean_apply_2(v_h__2_87_, v_head_90_, v_tail_91_);
return v___x_92_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0(lean_object* v_x_93_, lean_object* v_n_94_){
_start:
{
lean_object* v___x_95_; lean_object* v___x_96_; 
v___x_95_ = lean_unsigned_to_nat(1u);
v___x_96_ = lean_nat_add(v_n_94_, v___x_95_);
return v___x_96_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0___boxed(lean_object* v_x_97_, lean_object* v_n_98_){
_start:
{
lean_object* v_res_99_; 
v_res_99_ = l_ADWH_Chapter01_Lists_lengthR___redArg___lam__0(v_x_97_, v_n_98_);
lean_dec(v_n_98_);
lean_dec(v_x_97_);
return v_res_99_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR___redArg(lean_object* v_xs_101_){
_start:
{
lean_object* v___f_102_; lean_object* v___x_103_; lean_object* v___x_104_; 
v___f_102_ = ((lean_object*)(l_ADWH_Chapter01_Lists_lengthR___redArg___closed__0));
v___x_103_ = lean_unsigned_to_nat(0u);
v___x_104_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_102_, v___x_103_, v_xs_101_);
return v___x_104_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthR(lean_object* v_00_u03b1_105_, lean_object* v_xs_106_){
_start:
{
lean_object* v___x_107_; 
v___x_107_ = l_ADWH_Chapter01_Lists_lengthR___redArg(v_xs_106_);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0(lean_object* v_n_108_, lean_object* v_x_109_){
_start:
{
lean_object* v___x_110_; lean_object* v___x_111_; 
v___x_110_ = lean_unsigned_to_nat(1u);
v___x_111_ = lean_nat_add(v_n_108_, v___x_110_);
return v___x_111_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0___boxed(lean_object* v_n_112_, lean_object* v_x_113_){
_start:
{
lean_object* v_res_114_; 
v_res_114_ = l_ADWH_Chapter01_Lists_lengthL___redArg___lam__0(v_n_112_, v_x_113_);
lean_dec(v_x_113_);
lean_dec(v_n_112_);
return v_res_114_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL___redArg(lean_object* v_xs_116_){
_start:
{
lean_object* v___f_117_; lean_object* v___x_118_; lean_object* v___x_119_; 
v___f_117_ = ((lean_object*)(l_ADWH_Chapter01_Lists_lengthL___redArg___closed__0));
v___x_118_ = lean_unsigned_to_nat(0u);
v___x_119_ = l_ADWH_Chapter01_Lists_foldl___redArg(v___f_117_, v___x_118_, v_xs_116_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_lengthL(lean_object* v_00_u03b1_120_, lean_object* v_xs_121_){
_start:
{
lean_object* v___x_122_; 
v___x_122_ = l_ADWH_Chapter01_Lists_lengthL___redArg(v_xs_121_);
return v___x_122_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat1___redArg(lean_object* v_xss_124_){
_start:
{
lean_object* v___f_125_; lean_object* v___x_126_; lean_object* v___x_127_; 
v___f_125_ = ((lean_object*)(l_ADWH_Chapter01_Lists_concat1___redArg___closed__0));
v___x_126_ = lean_box(0);
v___x_127_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_125_, v___x_126_, v_xss_124_);
return v___x_127_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat1(lean_object* v_00_u03b1_128_, lean_object* v_xss_129_){
_start:
{
lean_object* v___x_130_; 
v___x_130_ = l_ADWH_Chapter01_Lists_concat1___redArg(v_xss_129_);
return v___x_130_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat2___redArg(lean_object* v_xss_131_){
_start:
{
lean_object* v___f_132_; lean_object* v___x_133_; lean_object* v___x_134_; 
v___f_132_ = ((lean_object*)(l_ADWH_Chapter01_Lists_concat1___redArg___closed__0));
v___x_133_ = lean_box(0);
v___x_134_ = l_ADWH_Chapter01_Lists_foldl___redArg(v___f_132_, v___x_133_, v_xss_131_);
return v___x_134_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concat2(lean_object* v_00_u03b1_135_, lean_object* v_xss_136_){
_start:
{
lean_object* v___x_137_; 
v___x_137_ = l_ADWH_Chapter01_Lists_concat2___redArg(v_xss_136_);
return v___x_137_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__0(lean_object* v_f_138_, lean_object* v_xs_139_, lean_object* v_ys_140_){
_start:
{
lean_object* v___x_141_; lean_object* v___x_142_; 
v___x_141_ = l_List_appendTR___redArg(v_xs_139_, v_ys_140_);
v___x_142_ = lean_apply_1(v_f_138_, v___x_141_);
return v___x_142_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__1(lean_object* v___y_143_){
_start:
{
lean_inc(v___y_143_);
return v___y_143_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg___lam__1___boxed(lean_object* v___y_144_){
_start:
{
lean_object* v_res_145_; 
v_res_145_ = l_ADWH_Chapter01_Lists_concatD___redArg___lam__1(v___y_144_);
lean_dec(v___y_144_);
return v_res_145_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD___redArg(lean_object* v_xss_148_){
_start:
{
lean_object* v___f_149_; lean_object* v___f_150_; lean_object* v___x_151_; lean_object* v___x_23__overap_152_; lean_object* v___x_153_; 
v___f_149_ = ((lean_object*)(l_ADWH_Chapter01_Lists_concatD___redArg___closed__0));
v___f_150_ = ((lean_object*)(l_ADWH_Chapter01_Lists_concatD___redArg___closed__1));
v___x_151_ = lean_box(0);
v___x_23__overap_152_ = l_ADWH_Chapter01_Lists_foldl___redArg(v___f_149_, v___f_150_, v_xss_148_);
v___x_153_ = lean_apply_1(v___x_23__overap_152_, v___x_151_);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatD(lean_object* v_00_u03b1_154_, lean_object* v_xss_155_){
_start:
{
lean_object* v___x_156_; 
v___x_156_ = l_ADWH_Chapter01_Lists_concatD___redArg(v_xss_155_);
return v___x_156_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatMap___redArg(lean_object* v_f_157_, lean_object* v_xs_158_){
_start:
{
lean_object* v___x_159_; lean_object* v___x_160_; 
v___x_159_ = l_ADWH_Chapter01_Lists_map___redArg(v_f_157_, v_xs_158_);
v___x_160_ = l_ADWH_Chapter01_Lists_concat1___redArg(v___x_159_);
return v___x_160_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_concatMap(lean_object* v_00_u03b1_161_, lean_object* v_00_u03b2_162_, lean_object* v_f_163_, lean_object* v_xs_164_){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = l_ADWH_Chapter01_Lists_concatMap___redArg(v_f_163_, v_xs_164_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverseAcc___redArg(lean_object* v_x_166_, lean_object* v_x_167_){
_start:
{
if (lean_obj_tag(v_x_166_) == 0)
{
return v_x_167_;
}
else
{
lean_object* v_head_168_; lean_object* v_tail_169_; lean_object* v___x_171_; uint8_t v_isShared_172_; uint8_t v_isSharedCheck_177_; 
v_head_168_ = lean_ctor_get(v_x_166_, 0);
v_tail_169_ = lean_ctor_get(v_x_166_, 1);
v_isSharedCheck_177_ = !lean_is_exclusive(v_x_166_);
if (v_isSharedCheck_177_ == 0)
{
v___x_171_ = v_x_166_;
v_isShared_172_ = v_isSharedCheck_177_;
goto v_resetjp_170_;
}
else
{
lean_inc(v_tail_169_);
lean_inc(v_head_168_);
lean_dec(v_x_166_);
v___x_171_ = lean_box(0);
v_isShared_172_ = v_isSharedCheck_177_;
goto v_resetjp_170_;
}
v_resetjp_170_:
{
lean_object* v___x_174_; 
if (v_isShared_172_ == 0)
{
lean_ctor_set(v___x_171_, 1, v_x_167_);
v___x_174_ = v___x_171_;
goto v_reusejp_173_;
}
else
{
lean_object* v_reuseFailAlloc_176_; 
v_reuseFailAlloc_176_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_176_, 0, v_head_168_);
lean_ctor_set(v_reuseFailAlloc_176_, 1, v_x_167_);
v___x_174_ = v_reuseFailAlloc_176_;
goto v_reusejp_173_;
}
v_reusejp_173_:
{
v_x_166_ = v_tail_169_;
v_x_167_ = v___x_174_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverseAcc(lean_object* v_00_u03b1_178_, lean_object* v_x_179_, lean_object* v_x_180_){
_start:
{
lean_object* v___x_181_; 
v___x_181_ = l_ADWH_Chapter01_Lists_reverseAcc___redArg(v_x_179_, v_x_180_);
return v___x_181_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse___redArg___lam__0(lean_object* v_ys_182_, lean_object* v_x_183_){
_start:
{
lean_object* v___x_184_; 
v___x_184_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_184_, 0, v_x_183_);
lean_ctor_set(v___x_184_, 1, v_ys_182_);
return v___x_184_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse___redArg(lean_object* v_xs_186_){
_start:
{
lean_object* v___f_187_; lean_object* v___x_188_; lean_object* v___x_189_; 
v___f_187_ = ((lean_object*)(l_ADWH_Chapter01_Lists_reverse___redArg___closed__0));
v___x_188_ = lean_box(0);
v___x_189_ = l_ADWH_Chapter01_Lists_foldl___redArg(v___f_187_, v___x_188_, v_xs_186_);
return v___x_189_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_reverse(lean_object* v_00_u03b1_190_, lean_object* v_xs_191_){
_start:
{
lean_object* v___x_192_; 
v___x_192_ = l_ADWH_Chapter01_Lists_reverse___redArg(v_xs_191_);
return v___x_192_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_reverseAcc_match__1_splitter___redArg(lean_object* v_x_193_, lean_object* v_x_194_, lean_object* v_h__1_195_, lean_object* v_h__2_196_){
_start:
{
if (lean_obj_tag(v_x_193_) == 0)
{
lean_object* v___x_197_; 
lean_dec(v_h__2_196_);
v___x_197_ = lean_apply_1(v_h__1_195_, v_x_194_);
return v___x_197_;
}
else
{
lean_object* v_head_198_; lean_object* v_tail_199_; lean_object* v___x_200_; 
lean_dec(v_h__1_195_);
v_head_198_ = lean_ctor_get(v_x_193_, 0);
lean_inc(v_head_198_);
v_tail_199_ = lean_ctor_get(v_x_193_, 1);
lean_inc(v_tail_199_);
lean_dec_ref_known(v_x_193_, 2);
v___x_200_ = lean_apply_3(v_h__2_196_, v_head_198_, v_tail_199_, v_x_194_);
return v___x_200_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_reverseAcc_match__1_splitter(lean_object* v_00_u03b1_201_, lean_object* v_motive_202_, lean_object* v_x_203_, lean_object* v_x_204_, lean_object* v_h__1_205_, lean_object* v_h__2_206_){
_start:
{
if (lean_obj_tag(v_x_203_) == 0)
{
lean_object* v___x_207_; 
lean_dec(v_h__2_206_);
v___x_207_ = lean_apply_1(v_h__1_205_, v_x_204_);
return v___x_207_;
}
else
{
lean_object* v_head_208_; lean_object* v_tail_209_; lean_object* v___x_210_; 
lean_dec(v_h__1_205_);
v_head_208_ = lean_ctor_get(v_x_203_, 0);
lean_inc(v_head_208_);
v_tail_209_ = lean_ctor_get(v_x_203_, 1);
lean_inc(v_tail_209_);
lean_dec_ref_known(v_x_203_, 2);
v___x_210_ = lean_apply_3(v_h__2_206_, v_head_208_, v_tail_209_, v_x_204_);
return v___x_210_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_flip___redArg(lean_object* v_f_211_, lean_object* v_y_212_, lean_object* v_x_213_){
_start:
{
lean_object* v___x_214_; 
v___x_214_ = lean_apply_2(v_f_211_, v_x_213_, v_y_212_);
return v___x_214_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_flip(lean_object* v_00_u03b1_215_, lean_object* v_00_u03b2_216_, lean_object* v_00_u03b3_217_, lean_object* v_f_218_, lean_object* v_y_219_, lean_object* v_x_220_){
_start:
{
lean_object* v___x_221_; 
v___x_221_ = lean_apply_2(v_f_218_, v_x_220_, v_y_219_);
return v___x_221_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg___lam__0(lean_object* v_f_222_, lean_object* v___y_223_, lean_object* v___y_224_){
_start:
{
lean_object* v___x_225_; 
v___x_225_ = lean_apply_2(v_f_222_, v___y_224_, v___y_223_);
return v___x_225_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg(lean_object* v_f_226_, lean_object* v_e_227_, lean_object* v_xs_228_){
_start:
{
lean_object* v___f_229_; lean_object* v___x_230_; lean_object* v___x_231_; 
v___f_229_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Lists_foldlViaReverse___redArg___lam__0), 3, 1);
lean_closure_set(v___f_229_, 0, v_f_226_);
v___x_230_ = l_ADWH_Chapter01_Lists_reverse___redArg(v_xs_228_);
v___x_231_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_229_, v_e_227_, v___x_230_);
return v___x_231_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___redArg___boxed(lean_object* v_f_232_, lean_object* v_e_233_, lean_object* v_xs_234_){
_start:
{
lean_object* v_res_235_; 
v_res_235_ = l_ADWH_Chapter01_Lists_foldlViaReverse___redArg(v_f_232_, v_e_233_, v_xs_234_);
lean_dec(v_e_233_);
return v_res_235_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse(lean_object* v_00_u03b1_236_, lean_object* v_00_u03b2_237_, lean_object* v_f_238_, lean_object* v_e_239_, lean_object* v_xs_240_){
_start:
{
lean_object* v___x_241_; 
v___x_241_ = l_ADWH_Chapter01_Lists_foldlViaReverse___redArg(v_f_238_, v_e_239_, v_xs_240_);
return v___x_241_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaReverse___boxed(lean_object* v_00_u03b1_242_, lean_object* v_00_u03b2_243_, lean_object* v_f_244_, lean_object* v_e_245_, lean_object* v_xs_246_){
_start:
{
lean_object* v_res_247_; 
v_res_247_ = l_ADWH_Chapter01_Lists_foldlViaReverse(v_00_u03b1_242_, v_00_u03b2_243_, v_f_244_, v_e_245_, v_xs_246_);
lean_dec(v_e_245_);
return v_res_247_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanl___redArg(lean_object* v_f_248_, lean_object* v_e_249_, lean_object* v_x_250_){
_start:
{
if (lean_obj_tag(v_x_250_) == 0)
{
lean_object* v___x_251_; lean_object* v___x_252_; 
lean_dec(v_f_248_);
v___x_251_ = lean_box(0);
v___x_252_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_252_, 0, v_e_249_);
lean_ctor_set(v___x_252_, 1, v___x_251_);
return v___x_252_;
}
else
{
lean_object* v_head_253_; lean_object* v_tail_254_; lean_object* v___x_256_; uint8_t v_isShared_257_; uint8_t v_isSharedCheck_263_; 
v_head_253_ = lean_ctor_get(v_x_250_, 0);
v_tail_254_ = lean_ctor_get(v_x_250_, 1);
v_isSharedCheck_263_ = !lean_is_exclusive(v_x_250_);
if (v_isSharedCheck_263_ == 0)
{
v___x_256_ = v_x_250_;
v_isShared_257_ = v_isSharedCheck_263_;
goto v_resetjp_255_;
}
else
{
lean_inc(v_tail_254_);
lean_inc(v_head_253_);
lean_dec(v_x_250_);
v___x_256_ = lean_box(0);
v_isShared_257_ = v_isSharedCheck_263_;
goto v_resetjp_255_;
}
v_resetjp_255_:
{
lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_261_; 
lean_inc(v_f_248_);
lean_inc(v_e_249_);
v___x_258_ = lean_apply_2(v_f_248_, v_e_249_, v_head_253_);
v___x_259_ = l_ADWH_Chapter01_Lists_scanl___redArg(v_f_248_, v___x_258_, v_tail_254_);
if (v_isShared_257_ == 0)
{
lean_ctor_set(v___x_256_, 1, v___x_259_);
lean_ctor_set(v___x_256_, 0, v_e_249_);
v___x_261_ = v___x_256_;
goto v_reusejp_260_;
}
else
{
lean_object* v_reuseFailAlloc_262_; 
v_reuseFailAlloc_262_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_262_, 0, v_e_249_);
lean_ctor_set(v_reuseFailAlloc_262_, 1, v___x_259_);
v___x_261_ = v_reuseFailAlloc_262_;
goto v_reusejp_260_;
}
v_reusejp_260_:
{
return v___x_261_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanl(lean_object* v_00_u03b1_264_, lean_object* v_00_u03b2_265_, lean_object* v_f_266_, lean_object* v_e_267_, lean_object* v_x_268_){
_start:
{
lean_object* v___x_269_; 
v___x_269_ = l_ADWH_Chapter01_Lists_scanl___redArg(v_f_266_, v_e_267_, v_x_268_);
return v___x_269_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanr___redArg(lean_object* v_f_270_, lean_object* v_e_271_, lean_object* v_x_272_){
_start:
{
if (lean_obj_tag(v_x_272_) == 0)
{
lean_object* v___x_273_; lean_object* v___x_274_; 
lean_dec(v_f_270_);
v___x_273_ = lean_box(0);
v___x_274_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_274_, 0, v_e_271_);
lean_ctor_set(v___x_274_, 1, v___x_273_);
return v___x_274_;
}
else
{
lean_object* v_head_275_; lean_object* v_tail_276_; lean_object* v___x_278_; uint8_t v_isShared_279_; uint8_t v_isSharedCheck_288_; 
v_head_275_ = lean_ctor_get(v_x_272_, 0);
v_tail_276_ = lean_ctor_get(v_x_272_, 1);
v_isSharedCheck_288_ = !lean_is_exclusive(v_x_272_);
if (v_isSharedCheck_288_ == 0)
{
v___x_278_ = v_x_272_;
v_isShared_279_ = v_isSharedCheck_288_;
goto v_resetjp_277_;
}
else
{
lean_inc(v_tail_276_);
lean_inc(v_head_275_);
lean_dec(v_x_272_);
v___x_278_ = lean_box(0);
v_isShared_279_ = v_isSharedCheck_288_;
goto v_resetjp_277_;
}
v_resetjp_277_:
{
lean_object* v_ys_280_; lean_object* v___y_282_; lean_object* v_head_287_; 
lean_inc(v_f_270_);
v_ys_280_ = l_ADWH_Chapter01_Lists_scanr___redArg(v_f_270_, v_e_271_, v_tail_276_);
v_head_287_ = lean_ctor_get(v_ys_280_, 0);
lean_inc(v_head_287_);
v___y_282_ = v_head_287_;
goto v___jp_281_;
v___jp_281_:
{
lean_object* v___x_283_; lean_object* v___x_285_; 
v___x_283_ = lean_apply_2(v_f_270_, v_head_275_, v___y_282_);
if (v_isShared_279_ == 0)
{
lean_ctor_set(v___x_278_, 1, v_ys_280_);
lean_ctor_set(v___x_278_, 0, v___x_283_);
v___x_285_ = v___x_278_;
goto v_reusejp_284_;
}
else
{
lean_object* v_reuseFailAlloc_286_; 
v_reuseFailAlloc_286_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_286_, 0, v___x_283_);
lean_ctor_set(v_reuseFailAlloc_286_, 1, v_ys_280_);
v___x_285_ = v_reuseFailAlloc_286_;
goto v_reusejp_284_;
}
v_reusejp_284_:
{
return v___x_285_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_scanr(lean_object* v_00_u03b1_289_, lean_object* v_00_u03b2_290_, lean_object* v_f_291_, lean_object* v_e_292_, lean_object* v_x_293_){
_start:
{
lean_object* v___x_294_; 
v___x_294_ = l_ADWH_Chapter01_Lists_scanr___redArg(v_f_291_, v_e_292_, v_x_293_);
return v___x_294_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_labelFrom___redArg(lean_object* v_n_295_, lean_object* v_x_296_){
_start:
{
if (lean_obj_tag(v_x_296_) == 0)
{
lean_object* v___x_297_; 
lean_dec(v_n_295_);
v___x_297_ = lean_box(0);
return v___x_297_;
}
else
{
lean_object* v_head_298_; lean_object* v_tail_299_; lean_object* v___x_301_; uint8_t v_isShared_302_; uint8_t v_isSharedCheck_310_; 
v_head_298_ = lean_ctor_get(v_x_296_, 0);
v_tail_299_ = lean_ctor_get(v_x_296_, 1);
v_isSharedCheck_310_ = !lean_is_exclusive(v_x_296_);
if (v_isSharedCheck_310_ == 0)
{
v___x_301_ = v_x_296_;
v_isShared_302_ = v_isSharedCheck_310_;
goto v_resetjp_300_;
}
else
{
lean_inc(v_tail_299_);
lean_inc(v_head_298_);
lean_dec(v_x_296_);
v___x_301_ = lean_box(0);
v_isShared_302_ = v_isSharedCheck_310_;
goto v_resetjp_300_;
}
v_resetjp_300_:
{
lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_308_; 
lean_inc(v_n_295_);
v___x_303_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_303_, 0, v_n_295_);
lean_ctor_set(v___x_303_, 1, v_head_298_);
v___x_304_ = lean_unsigned_to_nat(1u);
v___x_305_ = lean_nat_add(v_n_295_, v___x_304_);
lean_dec(v_n_295_);
v___x_306_ = l_ADWH_Chapter01_Lists_labelFrom___redArg(v___x_305_, v_tail_299_);
if (v_isShared_302_ == 0)
{
lean_ctor_set(v___x_301_, 1, v___x_306_);
lean_ctor_set(v___x_301_, 0, v___x_303_);
v___x_308_ = v___x_301_;
goto v_reusejp_307_;
}
else
{
lean_object* v_reuseFailAlloc_309_; 
v_reuseFailAlloc_309_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_309_, 0, v___x_303_);
lean_ctor_set(v_reuseFailAlloc_309_, 1, v___x_306_);
v___x_308_ = v_reuseFailAlloc_309_;
goto v_reusejp_307_;
}
v_reusejp_307_:
{
return v___x_308_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_labelFrom(lean_object* v_00_u03b1_311_, lean_object* v_n_312_, lean_object* v_x_313_){
_start:
{
lean_object* v___x_314_; 
v___x_314_ = l_ADWH_Chapter01_Lists_labelFrom___redArg(v_n_312_, v_x_313_);
return v___x_314_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_label___redArg(lean_object* v_xs_315_){
_start:
{
lean_object* v___x_316_; lean_object* v___x_317_; 
v___x_316_ = lean_unsigned_to_nat(0u);
v___x_317_ = l_ADWH_Chapter01_Lists_labelFrom___redArg(v___x_316_, v_xs_315_);
return v___x_317_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_label(lean_object* v_00_u03b1_318_, lean_object* v_xs_319_){
_start:
{
lean_object* v___x_320_; 
v___x_320_ = l_ADWH_Chapter01_Lists_label___redArg(v_xs_319_);
return v___x_320_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_uncons___redArg(lean_object* v_x_321_){
_start:
{
if (lean_obj_tag(v_x_321_) == 0)
{
lean_object* v___x_322_; 
v___x_322_ = lean_box(0);
return v___x_322_;
}
else
{
lean_object* v_head_323_; lean_object* v_tail_324_; lean_object* v___x_326_; uint8_t v_isShared_327_; uint8_t v_isSharedCheck_332_; 
v_head_323_ = lean_ctor_get(v_x_321_, 0);
v_tail_324_ = lean_ctor_get(v_x_321_, 1);
v_isSharedCheck_332_ = !lean_is_exclusive(v_x_321_);
if (v_isSharedCheck_332_ == 0)
{
v___x_326_ = v_x_321_;
v_isShared_327_ = v_isSharedCheck_332_;
goto v_resetjp_325_;
}
else
{
lean_inc(v_tail_324_);
lean_inc(v_head_323_);
lean_dec(v_x_321_);
v___x_326_ = lean_box(0);
v_isShared_327_ = v_isSharedCheck_332_;
goto v_resetjp_325_;
}
v_resetjp_325_:
{
lean_object* v___x_329_; 
if (v_isShared_327_ == 0)
{
lean_ctor_set_tag(v___x_326_, 0);
v___x_329_ = v___x_326_;
goto v_reusejp_328_;
}
else
{
lean_object* v_reuseFailAlloc_331_; 
v_reuseFailAlloc_331_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_331_, 0, v_head_323_);
lean_ctor_set(v_reuseFailAlloc_331_, 1, v_tail_324_);
v___x_329_ = v_reuseFailAlloc_331_;
goto v_reusejp_328_;
}
v_reusejp_328_:
{
lean_object* v___x_330_; 
v___x_330_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_330_, 0, v___x_329_);
return v___x_330_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_uncons(lean_object* v_00_u03b1_333_, lean_object* v_x_334_){
_start:
{
lean_object* v___x_335_; 
v___x_335_ = l_ADWH_Chapter01_Lists_uncons___redArg(v_x_334_);
return v___x_335_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_wrap___redArg(lean_object* v_x_336_){
_start:
{
lean_object* v___x_337_; lean_object* v___x_338_; 
v___x_337_ = lean_box(0);
v___x_338_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_338_, 0, v_x_336_);
lean_ctor_set(v___x_338_, 1, v___x_337_);
return v___x_338_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_wrap(lean_object* v_00_u03b1_339_, lean_object* v_x_340_){
_start:
{
lean_object* v___x_341_; 
v___x_341_ = l_ADWH_Chapter01_Lists_wrap___redArg(v_x_340_);
return v___x_341_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___redArg(lean_object* v_x_342_){
_start:
{
if (lean_obj_tag(v_x_342_) == 1)
{
lean_object* v_tail_343_; 
v_tail_343_ = lean_ctor_get(v_x_342_, 1);
if (lean_obj_tag(v_tail_343_) == 0)
{
lean_object* v_head_344_; lean_object* v___x_345_; 
v_head_344_ = lean_ctor_get(v_x_342_, 0);
lean_inc(v_head_344_);
v___x_345_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_345_, 0, v_head_344_);
return v___x_345_;
}
else
{
lean_object* v___x_346_; 
v___x_346_ = lean_box(0);
return v___x_346_;
}
}
else
{
lean_object* v___x_347_; 
v___x_347_ = lean_box(0);
return v___x_347_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___redArg___boxed(lean_object* v_x_348_){
_start:
{
lean_object* v_res_349_; 
v_res_349_ = l_ADWH_Chapter01_Lists_unwrap___redArg(v_x_348_);
lean_dec(v_x_348_);
return v_res_349_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap(lean_object* v_00_u03b1_350_, lean_object* v_x_351_){
_start:
{
lean_object* v___x_352_; 
v___x_352_ = l_ADWH_Chapter01_Lists_unwrap___redArg(v_x_351_);
return v___x_352_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_unwrap___boxed(lean_object* v_00_u03b1_353_, lean_object* v_x_354_){
_start:
{
lean_object* v_res_355_; 
v_res_355_ = l_ADWH_Chapter01_Lists_unwrap(v_00_u03b1_353_, v_x_354_);
lean_dec(v_x_354_);
return v_res_355_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter01_Lists_single___redArg(lean_object* v_x_356_){
_start:
{
if (lean_obj_tag(v_x_356_) == 1)
{
lean_object* v_tail_357_; 
v_tail_357_ = lean_ctor_get(v_x_356_, 1);
if (lean_obj_tag(v_tail_357_) == 0)
{
uint8_t v___x_358_; 
v___x_358_ = 1;
return v___x_358_;
}
else
{
uint8_t v___x_359_; 
v___x_359_ = 0;
return v___x_359_;
}
}
else
{
uint8_t v___x_360_; 
v___x_360_ = 0;
return v___x_360_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_single___redArg___boxed(lean_object* v_x_361_){
_start:
{
uint8_t v_res_362_; lean_object* v_r_363_; 
v_res_362_ = l_ADWH_Chapter01_Lists_single___redArg(v_x_361_);
lean_dec(v_x_361_);
v_r_363_ = lean_box(v_res_362_);
return v_r_363_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter01_Lists_single(lean_object* v_00_u03b1_364_, lean_object* v_x_365_){
_start:
{
uint8_t v___x_366_; 
v___x_366_ = l_ADWH_Chapter01_Lists_single___redArg(v_x_365_);
return v___x_366_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_single___boxed(lean_object* v_00_u03b1_367_, lean_object* v_x_368_){
_start:
{
uint8_t v_res_369_; lean_object* v_r_370_; 
v_res_369_ = l_ADWH_Chapter01_Lists_single(v_00_u03b1_367_, v_x_368_);
lean_dec(v_x_368_);
v_r_370_ = lean_box(v_res_369_);
return v_r_370_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_unwrap_match__1_splitter___redArg(lean_object* v_x_371_, lean_object* v_h__1_372_, lean_object* v_h__2_373_){
_start:
{
if (lean_obj_tag(v_x_371_) == 1)
{
lean_object* v_tail_374_; 
v_tail_374_ = lean_ctor_get(v_x_371_, 1);
if (lean_obj_tag(v_tail_374_) == 0)
{
lean_object* v_head_375_; lean_object* v___x_376_; 
lean_dec(v_h__2_373_);
v_head_375_ = lean_ctor_get(v_x_371_, 0);
lean_inc(v_head_375_);
lean_dec_ref_known(v_x_371_, 2);
v___x_376_ = lean_apply_1(v_h__1_372_, v_head_375_);
return v___x_376_;
}
else
{
lean_object* v___x_377_; 
lean_dec(v_h__1_372_);
v___x_377_ = lean_apply_2(v_h__2_373_, v_x_371_, lean_box(0));
return v___x_377_;
}
}
else
{
lean_object* v___x_378_; 
lean_dec(v_h__1_372_);
v___x_378_ = lean_apply_2(v_h__2_373_, v_x_371_, lean_box(0));
return v___x_378_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_unwrap_match__1_splitter(lean_object* v_00_u03b1_379_, lean_object* v_motive_380_, lean_object* v_x_381_, lean_object* v_h__1_382_, lean_object* v_h__2_383_){
_start:
{
if (lean_obj_tag(v_x_381_) == 1)
{
lean_object* v_tail_384_; 
v_tail_384_ = lean_ctor_get(v_x_381_, 1);
if (lean_obj_tag(v_tail_384_) == 0)
{
lean_object* v_head_385_; lean_object* v___x_386_; 
lean_dec(v_h__2_383_);
v_head_385_ = lean_ctor_get(v_x_381_, 0);
lean_inc(v_head_385_);
lean_dec_ref_known(v_x_381_, 2);
v___x_386_ = lean_apply_1(v_h__1_382_, v_head_385_);
return v___x_386_;
}
else
{
lean_object* v___x_387_; 
lean_dec(v_h__1_382_);
v___x_387_ = lean_apply_2(v_h__2_383_, v_x_381_, lean_box(0));
return v___x_387_;
}
}
else
{
lean_object* v___x_388_; 
lean_dec(v_h__1_382_);
v___x_388_ = lean_apply_2(v_h__2_383_, v_x_381_, lean_box(0));
return v___x_388_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___redArg(lean_object* v_x_389_){
_start:
{
if (lean_obj_tag(v_x_389_) == 0)
{
lean_object* v___x_390_; 
v___x_390_ = lean_box(0);
return v___x_390_;
}
else
{
lean_object* v_head_391_; lean_object* v___x_392_; 
v_head_391_ = lean_ctor_get(v_x_389_, 0);
lean_inc(v_head_391_);
v___x_392_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_392_, 0, v_head_391_);
return v___x_392_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___redArg___boxed(lean_object* v_x_393_){
_start:
{
lean_object* v_res_394_; 
v_res_394_ = l_ADWH_Chapter01_Lists_head___redArg(v_x_393_);
lean_dec(v_x_393_);
return v_res_394_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head(lean_object* v_00_u03b1_395_, lean_object* v_x_396_){
_start:
{
lean_object* v___x_397_; 
v___x_397_ = l_ADWH_Chapter01_Lists_head___redArg(v_x_396_);
return v___x_397_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_head___boxed(lean_object* v_00_u03b1_398_, lean_object* v_x_399_){
_start:
{
lean_object* v_res_400_; 
v_res_400_ = l_ADWH_Chapter01_Lists_head(v_00_u03b1_398_, v_x_399_);
lean_dec(v_x_399_);
return v_res_400_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___redArg(lean_object* v_x_401_){
_start:
{
if (lean_obj_tag(v_x_401_) == 0)
{
lean_object* v___x_402_; 
v___x_402_ = lean_box(0);
return v___x_402_;
}
else
{
lean_object* v_tail_403_; lean_object* v___x_404_; 
v_tail_403_ = lean_ctor_get(v_x_401_, 1);
lean_inc(v_tail_403_);
v___x_404_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_404_, 0, v_tail_403_);
return v___x_404_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___redArg___boxed(lean_object* v_x_405_){
_start:
{
lean_object* v_res_406_; 
v_res_406_ = l_ADWH_Chapter01_Lists_tail___redArg(v_x_405_);
lean_dec(v_x_405_);
return v_res_406_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail(lean_object* v_00_u03b1_407_, lean_object* v_x_408_){
_start:
{
lean_object* v___x_409_; 
v___x_409_ = l_ADWH_Chapter01_Lists_tail___redArg(v_x_408_);
return v___x_409_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_tail___boxed(lean_object* v_00_u03b1_410_, lean_object* v_x_411_){
_start:
{
lean_object* v_res_412_; 
v_res_412_ = l_ADWH_Chapter01_Lists_tail(v_00_u03b1_410_, v_x_411_);
lean_dec(v_x_411_);
return v_res_412_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___redArg(lean_object* v_x_413_){
_start:
{
if (lean_obj_tag(v_x_413_) == 0)
{
lean_object* v___x_414_; 
v___x_414_ = lean_box(0);
return v___x_414_;
}
else
{
lean_object* v_tail_415_; 
v_tail_415_ = lean_ctor_get(v_x_413_, 1);
if (lean_obj_tag(v_tail_415_) == 0)
{
lean_object* v_head_416_; lean_object* v___x_417_; 
v_head_416_ = lean_ctor_get(v_x_413_, 0);
lean_inc(v_head_416_);
v___x_417_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_417_, 0, v_head_416_);
return v___x_417_;
}
else
{
v_x_413_ = v_tail_415_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___redArg___boxed(lean_object* v_x_419_){
_start:
{
lean_object* v_res_420_; 
v_res_420_ = l_ADWH_Chapter01_Lists_last___redArg(v_x_419_);
lean_dec(v_x_419_);
return v_res_420_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last(lean_object* v_00_u03b1_421_, lean_object* v_x_422_){
_start:
{
lean_object* v___x_423_; 
v___x_423_ = l_ADWH_Chapter01_Lists_last___redArg(v_x_422_);
return v___x_423_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_last___boxed(lean_object* v_00_u03b1_424_, lean_object* v_x_425_){
_start:
{
lean_object* v_res_426_; 
v_res_426_ = l_ADWH_Chapter01_Lists_last(v_00_u03b1_424_, v_x_425_);
lean_dec(v_x_425_);
return v_res_426_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_init___redArg(lean_object* v_x_427_){
_start:
{
if (lean_obj_tag(v_x_427_) == 0)
{
lean_object* v___x_428_; 
v___x_428_ = lean_box(0);
return v___x_428_;
}
else
{
lean_object* v_tail_429_; 
v_tail_429_ = lean_ctor_get(v_x_427_, 1);
lean_inc(v_tail_429_);
if (lean_obj_tag(v_tail_429_) == 0)
{
lean_object* v___x_430_; 
lean_dec_ref_known(v_x_427_, 2);
v___x_430_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_430_, 0, v_tail_429_);
return v___x_430_;
}
else
{
lean_object* v_head_431_; lean_object* v___x_433_; uint8_t v_isShared_434_; uint8_t v_isSharedCheck_447_; 
v_head_431_ = lean_ctor_get(v_x_427_, 0);
v_isSharedCheck_447_ = !lean_is_exclusive(v_x_427_);
if (v_isSharedCheck_447_ == 0)
{
lean_object* v_unused_448_; 
v_unused_448_ = lean_ctor_get(v_x_427_, 1);
lean_dec(v_unused_448_);
v___x_433_ = v_x_427_;
v_isShared_434_ = v_isSharedCheck_447_;
goto v_resetjp_432_;
}
else
{
lean_inc(v_head_431_);
lean_dec(v_x_427_);
v___x_433_ = lean_box(0);
v_isShared_434_ = v_isSharedCheck_447_;
goto v_resetjp_432_;
}
v_resetjp_432_:
{
lean_object* v___x_435_; 
v___x_435_ = l_ADWH_Chapter01_Lists_init___redArg(v_tail_429_);
if (lean_obj_tag(v___x_435_) == 0)
{
lean_del_object(v___x_433_);
lean_dec(v_head_431_);
return v___x_435_;
}
else
{
lean_object* v_val_436_; lean_object* v___x_438_; uint8_t v_isShared_439_; uint8_t v_isSharedCheck_446_; 
v_val_436_ = lean_ctor_get(v___x_435_, 0);
v_isSharedCheck_446_ = !lean_is_exclusive(v___x_435_);
if (v_isSharedCheck_446_ == 0)
{
v___x_438_ = v___x_435_;
v_isShared_439_ = v_isSharedCheck_446_;
goto v_resetjp_437_;
}
else
{
lean_inc(v_val_436_);
lean_dec(v___x_435_);
v___x_438_ = lean_box(0);
v_isShared_439_ = v_isSharedCheck_446_;
goto v_resetjp_437_;
}
v_resetjp_437_:
{
lean_object* v___x_441_; 
if (v_isShared_434_ == 0)
{
lean_ctor_set(v___x_433_, 1, v_val_436_);
v___x_441_ = v___x_433_;
goto v_reusejp_440_;
}
else
{
lean_object* v_reuseFailAlloc_445_; 
v_reuseFailAlloc_445_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_445_, 0, v_head_431_);
lean_ctor_set(v_reuseFailAlloc_445_, 1, v_val_436_);
v___x_441_ = v_reuseFailAlloc_445_;
goto v_reusejp_440_;
}
v_reusejp_440_:
{
lean_object* v___x_443_; 
if (v_isShared_439_ == 0)
{
lean_ctor_set(v___x_438_, 0, v___x_441_);
v___x_443_ = v___x_438_;
goto v_reusejp_442_;
}
else
{
lean_object* v_reuseFailAlloc_444_; 
v_reuseFailAlloc_444_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_444_, 0, v___x_441_);
v___x_443_ = v_reuseFailAlloc_444_;
goto v_reusejp_442_;
}
v_reusejp_442_:
{
return v___x_443_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_init(lean_object* v_00_u03b1_449_, lean_object* v_x_450_){
_start:
{
lean_object* v___x_451_; 
v___x_451_ = l_ADWH_Chapter01_Lists_init___redArg(v_x_450_);
return v___x_451_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0(lean_object* v_x_452_, lean_object* v_x_453_){
_start:
{
lean_object* v___x_454_; 
v___x_454_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_454_, 0, v_x_452_);
return v___x_454_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0___boxed(lean_object* v_x_455_, lean_object* v_x_456_){
_start:
{
lean_object* v_res_457_; 
v_res_457_ = l_ADWH_Chapter01_Lists_headByFold___redArg___lam__0(v_x_455_, v_x_456_);
lean_dec(v_x_456_);
return v_res_457_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold___redArg(lean_object* v_xs_459_){
_start:
{
lean_object* v___f_460_; lean_object* v___x_461_; lean_object* v___x_462_; 
v___f_460_ = ((lean_object*)(l_ADWH_Chapter01_Lists_headByFold___redArg___closed__0));
v___x_461_ = lean_box(0);
v___x_462_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_460_, v___x_461_, v_xs_459_);
return v___x_462_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_headByFold(lean_object* v_00_u03b1_463_, lean_object* v_xs_464_){
_start:
{
lean_object* v___x_465_; 
v___x_465_ = l_ADWH_Chapter01_Lists_headByFold___redArg(v_xs_464_);
return v___x_465_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_last_match__1_splitter___redArg(lean_object* v_x_466_, lean_object* v_h__1_467_, lean_object* v_h__2_468_, lean_object* v_h__3_469_){
_start:
{
if (lean_obj_tag(v_x_466_) == 0)
{
lean_object* v___x_470_; lean_object* v___x_471_; 
lean_dec(v_h__3_469_);
lean_dec(v_h__2_468_);
v___x_470_ = lean_box(0);
v___x_471_ = lean_apply_1(v_h__1_467_, v___x_470_);
return v___x_471_;
}
else
{
lean_object* v_tail_472_; 
lean_dec(v_h__1_467_);
v_tail_472_ = lean_ctor_get(v_x_466_, 1);
if (lean_obj_tag(v_tail_472_) == 0)
{
lean_object* v_head_473_; lean_object* v___x_474_; 
lean_dec(v_h__3_469_);
v_head_473_ = lean_ctor_get(v_x_466_, 0);
lean_inc(v_head_473_);
lean_dec_ref_known(v_x_466_, 2);
v___x_474_ = lean_apply_1(v_h__2_468_, v_head_473_);
return v___x_474_;
}
else
{
lean_object* v_head_475_; lean_object* v_head_476_; lean_object* v_tail_477_; lean_object* v___x_478_; 
lean_inc_ref(v_tail_472_);
lean_dec(v_h__2_468_);
v_head_475_ = lean_ctor_get(v_x_466_, 0);
lean_inc(v_head_475_);
lean_dec_ref_known(v_x_466_, 2);
v_head_476_ = lean_ctor_get(v_tail_472_, 0);
lean_inc(v_head_476_);
v_tail_477_ = lean_ctor_get(v_tail_472_, 1);
lean_inc(v_tail_477_);
lean_dec_ref_known(v_tail_472_, 2);
v___x_478_ = lean_apply_3(v_h__3_469_, v_head_475_, v_head_476_, v_tail_477_);
return v___x_478_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter01_Lists_0__ADWH_Chapter01_Lists_last_match__1_splitter(lean_object* v_00_u03b1_479_, lean_object* v_motive_480_, lean_object* v_x_481_, lean_object* v_h__1_482_, lean_object* v_h__2_483_, lean_object* v_h__3_484_){
_start:
{
if (lean_obj_tag(v_x_481_) == 0)
{
lean_object* v___x_485_; lean_object* v___x_486_; 
lean_dec(v_h__3_484_);
lean_dec(v_h__2_483_);
v___x_485_ = lean_box(0);
v___x_486_ = lean_apply_1(v_h__1_482_, v___x_485_);
return v___x_486_;
}
else
{
lean_object* v_tail_487_; 
lean_dec(v_h__1_482_);
v_tail_487_ = lean_ctor_get(v_x_481_, 1);
if (lean_obj_tag(v_tail_487_) == 0)
{
lean_object* v_head_488_; lean_object* v___x_489_; 
lean_dec(v_h__3_484_);
v_head_488_ = lean_ctor_get(v_x_481_, 0);
lean_inc(v_head_488_);
lean_dec_ref_known(v_x_481_, 2);
v___x_489_ = lean_apply_1(v_h__2_483_, v_head_488_);
return v___x_489_;
}
else
{
lean_object* v_head_490_; lean_object* v_head_491_; lean_object* v_tail_492_; lean_object* v___x_493_; 
lean_inc_ref(v_tail_487_);
lean_dec(v_h__2_483_);
v_head_490_ = lean_ctor_get(v_x_481_, 0);
lean_inc(v_head_490_);
lean_dec_ref_known(v_x_481_, 2);
v_head_491_ = lean_ctor_get(v_tail_487_, 0);
lean_inc(v_head_491_);
v_tail_492_ = lean_ctor_get(v_tail_487_, 1);
lean_inc(v_tail_492_);
lean_dec_ref_known(v_tail_487_, 2);
v___x_493_ = lean_apply_3(v_h__3_484_, v_head_490_, v_head_491_, v_tail_492_);
return v___x_493_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___redArg(lean_object* v_f_494_, lean_object* v_e_495_, lean_object* v_xs_496_){
_start:
{
uint8_t v___x_497_; 
v___x_497_ = l_List_instDecidableEqNil___redArg(v_xs_496_);
if (v___x_497_ == 0)
{
lean_object* v___x_498_; 
v___x_498_ = l_ADWH_Chapter01_Lists_head___redArg(v_xs_496_);
if (lean_obj_tag(v___x_498_) == 1)
{
lean_object* v_val_499_; lean_object* v___x_500_; 
v_val_499_ = lean_ctor_get(v___x_498_, 0);
lean_inc(v_val_499_);
lean_dec_ref_known(v___x_498_, 1);
v___x_500_ = l_ADWH_Chapter01_Lists_tail___redArg(v_xs_496_);
if (lean_obj_tag(v___x_500_) == 1)
{
lean_object* v_val_501_; lean_object* v___x_502_; lean_object* v___x_503_; 
v_val_501_ = lean_ctor_get(v___x_500_, 0);
lean_inc(v_val_501_);
lean_dec_ref_known(v___x_500_, 1);
lean_inc(v_f_494_);
v___x_502_ = l_ADWH_Chapter01_Lists_foldr___redArg(v_f_494_, v_e_495_, v_val_501_);
v___x_503_ = lean_apply_2(v_f_494_, v_val_499_, v___x_502_);
return v___x_503_;
}
else
{
lean_dec(v___x_500_);
lean_dec(v_val_499_);
lean_dec(v_f_494_);
lean_inc(v_e_495_);
return v_e_495_;
}
}
else
{
lean_dec(v___x_498_);
lean_dec(v_f_494_);
lean_inc(v_e_495_);
return v_e_495_;
}
}
else
{
lean_dec(v_f_494_);
lean_inc(v_e_495_);
return v_e_495_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___redArg___boxed(lean_object* v_f_504_, lean_object* v_e_505_, lean_object* v_xs_506_){
_start:
{
lean_object* v_res_507_; 
v_res_507_ = l_ADWH_Chapter01_Lists_foldrByHead___redArg(v_f_504_, v_e_505_, v_xs_506_);
lean_dec(v_xs_506_);
lean_dec(v_e_505_);
return v_res_507_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead(lean_object* v_00_u03b1_508_, lean_object* v_00_u03b2_509_, lean_object* v_f_510_, lean_object* v_e_511_, lean_object* v_xs_512_){
_start:
{
lean_object* v___x_513_; 
v___x_513_ = l_ADWH_Chapter01_Lists_foldrByHead___redArg(v_f_510_, v_e_511_, v_xs_512_);
return v___x_513_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrByHead___boxed(lean_object* v_00_u03b1_514_, lean_object* v_00_u03b2_515_, lean_object* v_f_516_, lean_object* v_e_517_, lean_object* v_xs_518_){
_start:
{
lean_object* v_res_519_; 
v_res_519_ = l_ADWH_Chapter01_Lists_foldrByHead(v_00_u03b1_514_, v_00_u03b2_515_, v_f_516_, v_e_517_, v_xs_518_);
lean_dec(v_xs_518_);
lean_dec(v_e_517_);
return v_res_519_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlByInit___redArg(lean_object* v_f_520_, lean_object* v_e_521_, lean_object* v_xs_522_){
_start:
{
uint8_t v___x_523_; 
v___x_523_ = l_List_instDecidableEqNil___redArg(v_xs_522_);
if (v___x_523_ == 0)
{
lean_object* v___x_524_; 
lean_inc(v_xs_522_);
v___x_524_ = l_ADWH_Chapter01_Lists_init___redArg(v_xs_522_);
if (lean_obj_tag(v___x_524_) == 1)
{
lean_object* v_val_525_; lean_object* v___x_526_; 
v_val_525_ = lean_ctor_get(v___x_524_, 0);
lean_inc(v_val_525_);
lean_dec_ref_known(v___x_524_, 1);
v___x_526_ = l_ADWH_Chapter01_Lists_last___redArg(v_xs_522_);
lean_dec(v_xs_522_);
if (lean_obj_tag(v___x_526_) == 1)
{
lean_object* v_val_527_; lean_object* v___x_528_; lean_object* v___x_529_; 
v_val_527_ = lean_ctor_get(v___x_526_, 0);
lean_inc(v_val_527_);
lean_dec_ref_known(v___x_526_, 1);
lean_inc(v_f_520_);
v___x_528_ = l_ADWH_Chapter01_Lists_foldl___redArg(v_f_520_, v_e_521_, v_val_525_);
v___x_529_ = lean_apply_2(v_f_520_, v___x_528_, v_val_527_);
return v___x_529_;
}
else
{
lean_dec(v___x_526_);
lean_dec(v_val_525_);
lean_dec(v_f_520_);
return v_e_521_;
}
}
else
{
lean_dec(v___x_524_);
lean_dec(v_xs_522_);
lean_dec(v_f_520_);
return v_e_521_;
}
}
else
{
lean_dec(v_xs_522_);
lean_dec(v_f_520_);
return v_e_521_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlByInit(lean_object* v_00_u03b1_530_, lean_object* v_00_u03b2_531_, lean_object* v_f_532_, lean_object* v_e_533_, lean_object* v_xs_534_){
_start:
{
lean_object* v___x_535_; 
v___x_535_ = l_ADWH_Chapter01_Lists_foldlByInit___redArg(v_f_532_, v_e_533_, v_xs_534_);
return v___x_535_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___redArg(lean_object* v_f_536_, lean_object* v_e_537_, lean_object* v_xs_538_){
_start:
{
uint8_t v___x_539_; 
v___x_539_ = l_List_instDecidableEqNil___redArg(v_xs_538_);
if (v___x_539_ == 0)
{
lean_object* v_head_540_; lean_object* v_tail_541_; lean_object* v___x_542_; lean_object* v___x_543_; 
v_head_540_ = lean_ctor_get(v_xs_538_, 0);
lean_inc(v_head_540_);
v_tail_541_ = lean_ctor_get(v_xs_538_, 1);
lean_inc(v_tail_541_);
lean_dec(v_xs_538_);
lean_inc(v_f_536_);
v___x_542_ = l_ADWH_Chapter01_Lists_foldrViaHead___redArg(v_f_536_, v_e_537_, v_tail_541_);
v___x_543_ = lean_apply_2(v_f_536_, v_head_540_, v___x_542_);
return v___x_543_;
}
else
{
lean_dec(v_xs_538_);
lean_dec(v_f_536_);
lean_inc(v_e_537_);
return v_e_537_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___redArg___boxed(lean_object* v_f_544_, lean_object* v_e_545_, lean_object* v_xs_546_){
_start:
{
lean_object* v_res_547_; 
v_res_547_ = l_ADWH_Chapter01_Lists_foldrViaHead___redArg(v_f_544_, v_e_545_, v_xs_546_);
lean_dec(v_e_545_);
return v_res_547_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead(lean_object* v_00_u03b1_548_, lean_object* v_00_u03b2_549_, lean_object* v_f_550_, lean_object* v_e_551_, lean_object* v_xs_552_){
_start:
{
lean_object* v___x_553_; 
v___x_553_ = l_ADWH_Chapter01_Lists_foldrViaHead___redArg(v_f_550_, v_e_551_, v_xs_552_);
return v___x_553_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldrViaHead___boxed(lean_object* v_00_u03b1_554_, lean_object* v_00_u03b2_555_, lean_object* v_f_556_, lean_object* v_e_557_, lean_object* v_xs_558_){
_start:
{
lean_object* v_res_559_; 
v_res_559_ = l_ADWH_Chapter01_Lists_foldrViaHead(v_00_u03b1_554_, v_00_u03b2_555_, v_f_556_, v_e_557_, v_xs_558_);
lean_dec(v_e_557_);
return v_res_559_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___redArg(lean_object* v_f_560_, lean_object* v_e_561_, lean_object* v_xs_562_){
_start:
{
uint8_t v___x_563_; 
v___x_563_ = l_List_instDecidableEqNil___redArg(v_xs_562_);
if (v___x_563_ == 0)
{
lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; 
lean_inc(v_xs_562_);
v___x_564_ = lean_array_mk(v_xs_562_);
v___x_565_ = lean_array_pop(v___x_564_);
v___x_566_ = lean_array_to_list(v___x_565_);
lean_inc(v_f_560_);
v___x_567_ = l_ADWH_Chapter01_Lists_foldlViaInit___redArg(v_f_560_, v_e_561_, v___x_566_);
v___x_568_ = l_List_getLast___redArg(v_xs_562_);
lean_dec(v_xs_562_);
v___x_569_ = lean_apply_2(v_f_560_, v___x_567_, v___x_568_);
return v___x_569_;
}
else
{
lean_dec(v_xs_562_);
lean_dec(v_f_560_);
lean_inc(v_e_561_);
return v_e_561_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___redArg___boxed(lean_object* v_f_570_, lean_object* v_e_571_, lean_object* v_xs_572_){
_start:
{
lean_object* v_res_573_; 
v_res_573_ = l_ADWH_Chapter01_Lists_foldlViaInit___redArg(v_f_570_, v_e_571_, v_xs_572_);
lean_dec(v_e_571_);
return v_res_573_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit(lean_object* v_00_u03b1_574_, lean_object* v_00_u03b2_575_, lean_object* v_f_576_, lean_object* v_e_577_, lean_object* v_xs_578_){
_start:
{
lean_object* v___x_579_; 
v___x_579_ = l_ADWH_Chapter01_Lists_foldlViaInit___redArg(v_f_576_, v_e_577_, v_xs_578_);
return v___x_579_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_foldlViaInit___boxed(lean_object* v_00_u03b1_580_, lean_object* v_00_u03b2_581_, lean_object* v_f_582_, lean_object* v_e_583_, lean_object* v_xs_584_){
_start:
{
lean_object* v_res_585_; 
v_res_585_ = l_ADWH_Chapter01_Lists_foldlViaInit(v_00_u03b1_580_, v_00_u03b2_581_, v_f_582_, v_e_583_, v_xs_584_);
lean_dec(v_e_583_);
return v_res_585_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile___redArg___lam__0(lean_object* v_p_586_, lean_object* v_x_587_, lean_object* v_ys_588_){
_start:
{
lean_object* v___x_589_; uint8_t v___x_590_; 
lean_inc(v_x_587_);
v___x_589_ = lean_apply_1(v_p_586_, v_x_587_);
v___x_590_ = lean_unbox(v___x_589_);
if (v___x_590_ == 0)
{
lean_object* v___x_591_; 
lean_dec(v_ys_588_);
lean_dec(v_x_587_);
v___x_591_ = lean_box(0);
return v___x_591_;
}
else
{
lean_object* v___x_592_; 
v___x_592_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_592_, 0, v_x_587_);
lean_ctor_set(v___x_592_, 1, v_ys_588_);
return v___x_592_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile___redArg(lean_object* v_p_593_, lean_object* v_xs_594_){
_start:
{
lean_object* v___f_595_; lean_object* v___x_596_; lean_object* v___x_597_; 
v___f_595_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Lists_takeWhile___redArg___lam__0), 3, 1);
lean_closure_set(v___f_595_, 0, v_p_593_);
v___x_596_ = lean_box(0);
v___x_597_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_595_, v___x_596_, v_xs_594_);
return v___x_597_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_takeWhile(lean_object* v_00_u03b1_598_, lean_object* v_p_599_, lean_object* v_xs_600_){
_start:
{
lean_object* v___x_601_; 
v___x_601_ = l_ADWH_Chapter01_Lists_takeWhile___redArg(v_p_599_, v_xs_600_);
return v___x_601_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd___redArg___lam__0(lean_object* v_p_602_, lean_object* v_x_603_, lean_object* v_ys_604_){
_start:
{
lean_object* v___x_605_; uint8_t v___x_606_; 
lean_inc(v_x_603_);
v___x_605_ = lean_apply_1(v_p_602_, v_x_603_);
v___x_606_ = lean_unbox(v___x_605_);
if (v___x_606_ == 0)
{
lean_object* v___x_607_; 
v___x_607_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_607_, 0, v_x_603_);
lean_ctor_set(v___x_607_, 1, v_ys_604_);
return v___x_607_;
}
else
{
uint8_t v___x_608_; 
v___x_608_ = l_List_isEmpty___redArg(v_ys_604_);
if (v___x_608_ == 0)
{
lean_object* v___x_609_; 
v___x_609_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_609_, 0, v_x_603_);
lean_ctor_set(v___x_609_, 1, v_ys_604_);
return v___x_609_;
}
else
{
lean_object* v___x_610_; 
lean_dec(v_ys_604_);
lean_dec(v_x_603_);
v___x_610_ = lean_box(0);
return v___x_610_;
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd___redArg(lean_object* v_p_611_, lean_object* v_xs_612_){
_start:
{
lean_object* v___f_613_; lean_object* v___x_614_; lean_object* v___x_615_; 
v___f_613_ = lean_alloc_closure((void*)(l_ADWH_Chapter01_Lists_dropWhileEnd___redArg___lam__0), 3, 1);
lean_closure_set(v___f_613_, 0, v_p_611_);
v___x_614_ = lean_box(0);
v___x_615_ = l_ADWH_Chapter01_Lists_foldr___redArg(v___f_613_, v___x_614_, v_xs_612_);
return v___x_615_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter01_Lists_dropWhileEnd(lean_object* v_00_u03b1_616_, lean_object* v_p_617_, lean_object* v_xs_618_){
_start:
{
lean_object* v___x_619_; 
v___x_619_ = l_ADWH_Chapter01_Lists_dropWhileEnd___redArg(v_p_617_, v_xs_618_);
return v___x_619_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Std(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter01_Lists(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
