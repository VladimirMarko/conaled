// Lean compiler output
// Module: ADWH.Chapter15.QueensBitRepresentation
// Imports: public import Init public meta import Init public import ADWH.Chapter15.QueensSearch public import Init.Data.BitVec.Bitblast
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_BitVec_ofNat(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_BitVec_shiftLeft(lean_object*, lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_List_get___redArg(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t l___private_Init_Data_Nat_Lemmas_0__Nat_anyLTTR_loop___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_BitVec_pow(lean_object*, lean_object*, lean_object*);
lean_object* l_BitVec_sub(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_lor(lean_object*, lean_object*);
lean_object* l_BitVec_not(lean_object*, lean_object*);
lean_object* lean_nat_land(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_move(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_move___boxed(lean_object*, lean_object*);
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0;
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1;
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode___boxed(lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitRepresentation_0__ADWH_Chapter15_Queens_BitRepresentation_encode_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitRepresentation_0__ADWH_Chapter15_Queens_BitRepresentation_encode_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0;
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_available(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_available___boxed(lean_object*, lean_object*);
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_unsigned_to_nat(16u);
v___x_3_ = l_BitVec_ofNat(v___x_2_, v___x_1_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton(lean_object* v_q_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; 
v___x_5_ = lean_unsigned_to_nat(16u);
v___x_6_ = lean_unsigned_to_nat(1u);
v___x_7_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0);
v___x_8_ = lean_nat_sub(v_q_4_, v___x_6_);
v___x_9_ = l_BitVec_shiftLeft(v___x_5_, v___x_7_, v___x_8_);
lean_dec(v___x_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_singleton___boxed(lean_object* v_q_10_){
_start:
{
lean_object* v_res_11_; 
v_res_11_ = l_ADWH_Chapter15_Queens_BitRepresentation_singleton(v_q_10_);
lean_dec(v_q_10_);
return v_res_11_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_move(lean_object* v_s_12_, lean_object* v_b_13_){
_start:
{
lean_object* v_snd_14_; lean_object* v_fst_15_; lean_object* v___x_17_; uint8_t v_isShared_18_; uint8_t v_isSharedCheck_38_; 
v_snd_14_ = lean_ctor_get(v_s_12_, 1);
v_fst_15_ = lean_ctor_get(v_s_12_, 0);
v_isSharedCheck_38_ = !lean_is_exclusive(v_s_12_);
if (v_isSharedCheck_38_ == 0)
{
v___x_17_ = v_s_12_;
v_isShared_18_ = v_isSharedCheck_38_;
goto v_resetjp_16_;
}
else
{
lean_inc(v_snd_14_);
lean_inc(v_fst_15_);
lean_dec(v_s_12_);
v___x_17_ = lean_box(0);
v_isShared_18_ = v_isSharedCheck_38_;
goto v_resetjp_16_;
}
v_resetjp_16_:
{
lean_object* v_fst_19_; lean_object* v_snd_20_; lean_object* v___x_22_; uint8_t v_isShared_23_; uint8_t v_isSharedCheck_37_; 
v_fst_19_ = lean_ctor_get(v_snd_14_, 0);
v_snd_20_ = lean_ctor_get(v_snd_14_, 1);
v_isSharedCheck_37_ = !lean_is_exclusive(v_snd_14_);
if (v_isSharedCheck_37_ == 0)
{
v___x_22_ = v_snd_14_;
v_isShared_23_ = v_isSharedCheck_37_;
goto v_resetjp_21_;
}
else
{
lean_inc(v_snd_20_);
lean_inc(v_fst_19_);
lean_dec(v_snd_14_);
v___x_22_ = lean_box(0);
v_isShared_23_ = v_isSharedCheck_37_;
goto v_resetjp_21_;
}
v_resetjp_21_:
{
lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_32_; 
v___x_24_ = lean_unsigned_to_nat(16u);
v___x_25_ = lean_nat_lor(v_fst_15_, v_b_13_);
lean_dec(v_fst_15_);
v___x_26_ = lean_unsigned_to_nat(1u);
v___x_27_ = l_BitVec_shiftLeft(v___x_24_, v___x_25_, v___x_26_);
lean_dec(v___x_25_);
v___x_28_ = lean_nat_lor(v_fst_19_, v_b_13_);
lean_dec(v_fst_19_);
v___x_29_ = lean_nat_lor(v_snd_20_, v_b_13_);
lean_dec(v_snd_20_);
v___x_30_ = lean_nat_shiftr(v___x_29_, v___x_26_);
lean_dec(v___x_29_);
if (v_isShared_23_ == 0)
{
lean_ctor_set(v___x_22_, 1, v___x_30_);
lean_ctor_set(v___x_22_, 0, v___x_28_);
v___x_32_ = v___x_22_;
goto v_reusejp_31_;
}
else
{
lean_object* v_reuseFailAlloc_36_; 
v_reuseFailAlloc_36_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_36_, 0, v___x_28_);
lean_ctor_set(v_reuseFailAlloc_36_, 1, v___x_30_);
v___x_32_ = v_reuseFailAlloc_36_;
goto v_reusejp_31_;
}
v_reusejp_31_:
{
lean_object* v___x_34_; 
if (v_isShared_18_ == 0)
{
lean_ctor_set(v___x_17_, 1, v___x_32_);
lean_ctor_set(v___x_17_, 0, v___x_27_);
v___x_34_ = v___x_17_;
goto v_reusejp_33_;
}
else
{
lean_object* v_reuseFailAlloc_35_; 
v_reuseFailAlloc_35_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_35_, 0, v___x_27_);
lean_ctor_set(v_reuseFailAlloc_35_, 1, v___x_32_);
v___x_34_ = v_reuseFailAlloc_35_;
goto v_reusejp_33_;
}
v_reusejp_33_:
{
return v___x_34_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_move___boxed(lean_object* v_s_39_, lean_object* v_b_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = l_ADWH_Chapter15_Queens_BitRepresentation_move(v_s_39_, v_b_40_);
lean_dec(v_b_40_);
return v_res_41_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0(void){
_start:
{
lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; 
v___x_42_ = lean_unsigned_to_nat(0u);
v___x_43_ = lean_unsigned_to_nat(16u);
v___x_44_ = l_BitVec_ofNat(v___x_43_, v___x_42_);
return v___x_44_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1(void){
_start:
{
lean_object* v___x_45_; lean_object* v___x_46_; 
v___x_45_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0);
v___x_46_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_46_, 0, v___x_45_);
lean_ctor_set(v___x_46_, 1, v___x_45_);
return v___x_46_;
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2(void){
_start:
{
lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; 
v___x_47_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1, &l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__1);
v___x_48_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__0);
v___x_49_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_49_, 0, v___x_48_);
lean_ctor_set(v___x_49_, 1, v___x_47_);
return v___x_49_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode(lean_object* v_x_50_){
_start:
{
if (lean_obj_tag(v_x_50_) == 0)
{
lean_object* v___x_51_; 
v___x_51_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2, &l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_encode___closed__2);
return v___x_51_;
}
else
{
lean_object* v_head_52_; lean_object* v_tail_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; 
v_head_52_ = lean_ctor_get(v_x_50_, 0);
v_tail_53_ = lean_ctor_get(v_x_50_, 1);
v___x_54_ = l_ADWH_Chapter15_Queens_BitRepresentation_encode(v_tail_53_);
v___x_55_ = l_ADWH_Chapter15_Queens_BitRepresentation_singleton(v_head_52_);
v___x_56_ = l_ADWH_Chapter15_Queens_BitRepresentation_move(v___x_54_, v___x_55_);
lean_dec(v___x_55_);
return v___x_56_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_encode___boxed(lean_object* v_x_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = l_ADWH_Chapter15_Queens_BitRepresentation_encode(v_x_57_);
lean_dec(v_x_57_);
return v_res_58_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0(lean_object* v_qs_59_, lean_object* v_i_60_, lean_object* v_i_61_, lean_object* v_x_62_){
_start:
{
lean_object* v___x_63_; uint8_t v___x_64_; 
v___x_63_ = l_List_lengthTR___redArg(v_qs_59_);
v___x_64_ = lean_nat_dec_lt(v_i_61_, v___x_63_);
lean_dec(v___x_63_);
if (v___x_64_ == 0)
{
uint8_t v___x_65_; 
lean_dec(v_i_61_);
v___x_65_ = 1;
return v___x_65_;
}
else
{
lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; uint8_t v___x_71_; 
lean_inc(v_i_61_);
v___x_66_ = l_List_get___redArg(v_qs_59_, v_i_61_);
v___x_67_ = lean_nat_add(v___x_66_, v_i_61_);
lean_dec(v_i_61_);
lean_dec(v___x_66_);
v___x_68_ = lean_unsigned_to_nat(1u);
v___x_69_ = lean_nat_add(v___x_67_, v___x_68_);
lean_dec(v___x_67_);
v___x_70_ = lean_nat_add(v_i_60_, v___x_68_);
v___x_71_ = lean_nat_dec_eq(v___x_69_, v___x_70_);
lean_dec(v___x_70_);
lean_dec(v___x_69_);
return v___x_71_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0___boxed(lean_object* v_qs_72_, lean_object* v_i_73_, lean_object* v_i_74_, lean_object* v_x_75_){
_start:
{
uint8_t v_res_76_; lean_object* v_r_77_; 
v_res_76_ = l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0(v_qs_72_, v_i_73_, v_i_74_, v_x_75_);
lean_dec(v_i_73_);
lean_dec(v_qs_72_);
v_r_77_ = lean_box(v_res_76_);
return v_r_77_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack(lean_object* v_qs_78_, lean_object* v_i_79_){
_start:
{
lean_object* v___f_80_; lean_object* v___x_81_; uint8_t v___x_82_; 
lean_inc(v_qs_78_);
v___f_80_ = lean_alloc_closure((void*)(l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___lam__0___boxed), 4, 2);
lean_closure_set(v___f_80_, 0, v_qs_78_);
lean_closure_set(v___f_80_, 1, v_i_79_);
v___x_81_ = l_List_lengthTR___redArg(v_qs_78_);
lean_dec(v_qs_78_);
lean_inc(v___x_81_);
v___x_82_ = l___private_Init_Data_Nat_Lemmas_0__Nat_anyLTTR_loop___redArg(v___x_81_, v___f_80_, v___x_81_);
lean_dec(v___x_81_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack___boxed(lean_object* v_qs_83_, lean_object* v_i_84_){
_start:
{
uint8_t v_res_85_; lean_object* v_r_86_; 
v_res_85_ = l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableLeftAttack(v_qs_83_, v_i_84_);
v_r_86_ = lean_box(v_res_85_);
return v_r_86_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0(lean_object* v_qs_87_, lean_object* v_i_88_, lean_object* v_i_89_, lean_object* v_x_90_){
_start:
{
lean_object* v___x_91_; uint8_t v___x_92_; 
v___x_91_ = l_List_lengthTR___redArg(v_qs_87_);
v___x_92_ = lean_nat_dec_lt(v_i_89_, v___x_91_);
lean_dec(v___x_91_);
if (v___x_92_ == 0)
{
uint8_t v___x_93_; 
lean_dec(v_i_89_);
v___x_93_ = 1;
return v___x_93_;
}
else
{
lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; uint8_t v___x_98_; 
lean_inc(v_i_89_);
v___x_94_ = l_List_get___redArg(v_qs_87_, v_i_89_);
v___x_95_ = lean_nat_add(v_i_88_, v_i_89_);
lean_dec(v_i_89_);
v___x_96_ = lean_unsigned_to_nat(2u);
v___x_97_ = lean_nat_add(v___x_95_, v___x_96_);
lean_dec(v___x_95_);
v___x_98_ = lean_nat_dec_eq(v___x_94_, v___x_97_);
lean_dec(v___x_97_);
lean_dec(v___x_94_);
return v___x_98_;
}
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0___boxed(lean_object* v_qs_99_, lean_object* v_i_100_, lean_object* v_i_101_, lean_object* v_x_102_){
_start:
{
uint8_t v_res_103_; lean_object* v_r_104_; 
v_res_103_ = l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0(v_qs_99_, v_i_100_, v_i_101_, v_x_102_);
lean_dec(v_i_100_);
lean_dec(v_qs_99_);
v_r_104_ = lean_box(v_res_103_);
return v_r_104_;
}
}
LEAN_EXPORT uint8_t l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack(lean_object* v_qs_105_, lean_object* v_i_106_){
_start:
{
lean_object* v___f_107_; lean_object* v___x_108_; uint8_t v___x_109_; 
lean_inc(v_qs_105_);
v___f_107_ = lean_alloc_closure((void*)(l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___lam__0___boxed), 4, 2);
lean_closure_set(v___f_107_, 0, v_qs_105_);
lean_closure_set(v___f_107_, 1, v_i_106_);
v___x_108_ = l_List_lengthTR___redArg(v_qs_105_);
lean_dec(v_qs_105_);
lean_inc(v___x_108_);
v___x_109_ = l___private_Init_Data_Nat_Lemmas_0__Nat_anyLTTR_loop___redArg(v___x_108_, v___f_107_, v___x_108_);
lean_dec(v___x_108_);
return v___x_109_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack___boxed(lean_object* v_qs_110_, lean_object* v_i_111_){
_start:
{
uint8_t v_res_112_; lean_object* v_r_113_; 
v_res_112_ = l_ADWH_Chapter15_Queens_BitRepresentation_instDecidableRightAttack(v_qs_110_, v_i_111_);
v_r_113_ = lean_box(v_res_112_);
return v_r_113_;
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitRepresentation_0__ADWH_Chapter15_Queens_BitRepresentation_encode_match__1_splitter___redArg(lean_object* v_x_114_, lean_object* v_h__1_115_, lean_object* v_h__2_116_){
_start:
{
if (lean_obj_tag(v_x_114_) == 0)
{
lean_object* v___x_117_; lean_object* v___x_118_; 
lean_dec(v_h__2_116_);
v___x_117_ = lean_box(0);
v___x_118_ = lean_apply_1(v_h__1_115_, v___x_117_);
return v___x_118_;
}
else
{
lean_object* v_head_119_; lean_object* v_tail_120_; lean_object* v___x_121_; 
lean_dec(v_h__1_115_);
v_head_119_ = lean_ctor_get(v_x_114_, 0);
lean_inc(v_head_119_);
v_tail_120_ = lean_ctor_get(v_x_114_, 1);
lean_inc(v_tail_120_);
lean_dec_ref_known(v_x_114_, 2);
v___x_121_ = lean_apply_2(v_h__2_116_, v_head_119_, v_tail_120_);
return v___x_121_;
}
}
}
LEAN_EXPORT lean_object* l___private_ADWH_Chapter15_QueensBitRepresentation_0__ADWH_Chapter15_Queens_BitRepresentation_encode_match__1_splitter(lean_object* v_motive_122_, lean_object* v_x_123_, lean_object* v_h__1_124_, lean_object* v_h__2_125_){
_start:
{
if (lean_obj_tag(v_x_123_) == 0)
{
lean_object* v___x_126_; lean_object* v___x_127_; 
lean_dec(v_h__2_125_);
v___x_126_ = lean_box(0);
v___x_127_ = lean_apply_1(v_h__1_124_, v___x_126_);
return v___x_127_;
}
else
{
lean_object* v_head_128_; lean_object* v_tail_129_; lean_object* v___x_130_; 
lean_dec(v_h__1_124_);
v_head_128_ = lean_ctor_get(v_x_123_, 0);
lean_inc(v_head_128_);
v_tail_129_ = lean_ctor_get(v_x_123_, 1);
lean_inc(v_tail_129_);
lean_dec_ref_known(v_x_123_, 2);
v___x_130_ = lean_apply_2(v_h__2_125_, v_head_128_, v_tail_129_);
return v___x_130_;
}
}
}
static lean_object* _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0(void){
_start:
{
lean_object* v___x_131_; lean_object* v___x_132_; lean_object* v___x_133_; 
v___x_131_ = lean_unsigned_to_nat(2u);
v___x_132_ = lean_unsigned_to_nat(16u);
v___x_133_ = l_BitVec_ofNat(v___x_132_, v___x_131_);
return v___x_133_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask(lean_object* v_n_134_){
_start:
{
lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; 
v___x_135_ = lean_unsigned_to_nat(16u);
v___x_136_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_mask___closed__0);
v___x_137_ = l_BitVec_pow(v___x_135_, v___x_136_, v_n_134_);
v___x_138_ = lean_obj_once(&l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0, &l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0_once, _init_l_ADWH_Chapter15_Queens_BitRepresentation_singleton___closed__0);
v___x_139_ = l_BitVec_sub(v___x_135_, v___x_137_, v___x_138_);
lean_dec(v___x_137_);
return v___x_139_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_mask___boxed(lean_object* v_n_140_){
_start:
{
lean_object* v_res_141_; 
v_res_141_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_140_);
lean_dec(v_n_140_);
return v_res_141_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_available(lean_object* v_n_142_, lean_object* v_s_143_){
_start:
{
lean_object* v_snd_144_; lean_object* v_fst_145_; lean_object* v_fst_146_; lean_object* v_snd_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; 
v_snd_144_ = lean_ctor_get(v_s_143_, 1);
v_fst_145_ = lean_ctor_get(v_s_143_, 0);
v_fst_146_ = lean_ctor_get(v_snd_144_, 0);
v_snd_147_ = lean_ctor_get(v_snd_144_, 1);
v___x_148_ = lean_unsigned_to_nat(16u);
v___x_149_ = lean_nat_lor(v_fst_145_, v_fst_146_);
v___x_150_ = lean_nat_lor(v___x_149_, v_snd_147_);
lean_dec(v___x_149_);
v___x_151_ = l_BitVec_not(v___x_148_, v___x_150_);
lean_dec(v___x_150_);
v___x_152_ = l_ADWH_Chapter15_Queens_BitRepresentation_mask(v_n_142_);
v___x_153_ = lean_nat_land(v___x_151_, v___x_152_);
lean_dec(v___x_152_);
lean_dec(v___x_151_);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* l_ADWH_Chapter15_Queens_BitRepresentation_available___boxed(lean_object* v_n_154_, lean_object* v_s_155_){
_start:
{
lean_object* v_res_156_; 
v_res_156_ = l_ADWH_Chapter15_Queens_BitRepresentation_available(v_n_154_, v_s_155_);
lean_dec_ref(v_s_155_);
lean_dec(v_n_154_);
return v_res_156_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ADWH_Chapter15_QueensSearch(uint8_t builtin);
lean_object* initialize_Init_Data_BitVec_Bitblast(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ADWH_Chapter15_QueensBitRepresentation(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ADWH_Chapter15_QueensSearch(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init_Data_BitVec_Bitblast(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
