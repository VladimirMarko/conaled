# First-order Nat evaluation with an exact source bridge

## Status and selected change

Prepared source only. The author has not invoked Lean, a compiler, an evaluator,
a counter, a generator, or a proof gate. The two new mathematical files need
independent review and the parent's fresh bounded checks. Earlier sources,
artifacts, attempts and execution markers remain unchanged.

The baseline is the accepted source copied by
`../native-nat-evaluator-probe/`: its first native diagnostic compiled and ran
the fixed 8/10/12 cases in 1.8205765509992489 seconds overall, with a peak of
488640 KiB. The report is bound in `SOURCE-INVENTORY.json`. Those are native
observations, not mathematical proofs of counts. The emitted C exposes a
specific implementation cost: a closure allocated at each entered positive
depth/nonterminal branch, an indirect callback application per chosen bit,
and nested state products with allocation fallbacks. Its left shift also
uses the runtime multiprecision path. See `EMITTED-C-REVIEW.md`.

The selected candidate combines two explicit transformations:

1. Replace the callback-based bit sum and product state with mutually
   recursive scalar-argument `count` and `branches` workers.
2. Replace only the left transition's `value <<< 1` by `value * 2`, using the
   universal equality derived from `Nat.shiftLeft_eq`.

The candidate does not change the search tree, introduce symmetry or
memoization, shorten depth or fuel, or switch to fixed-width arithmetic.
Any future measured difference belongs to this combined candidate; it cannot
be attributed separately to the two transformations without new evidence.

## Reusable computational interface

Namespace: `ADWH.Experiments.Chapter15.FirstOrderNat`.

```text
count    (modulus mask budget depth left columns right : Nat) : Nat
branches (modulus mask budget depth left columns right fuel cursor : Nat) : Nat
evaluate (width mask depth left columns right : Nat) : Nat
```

`evaluate` calls `count (2^width) mask width depth left columns right`.
The modulus is computed at this wrapper, outside the recursive workers.
`count` and `branches` themselves accept arbitrary natural moduli, budgets
and masks, including zero. Neither takes a function argument or constructs a
state tuple. `low` and `available` are inline scalar operations.

The termination ranks are `(depth, 0)` for `count` and `(depth, fuel+1)` for
`branches`. A successor-depth outer call lowers the first component before
entering the bit loop. A loop child call has the same first component and
second component zero; its remaining-cursor call lowers the second
component. This proves totality without assuming that a cursor becomes
empty or that `low cursor` is positive. That distinction matters for inputs
outside a reachable board-state invariant.

The result remains an unbounded Nat sum, using exactly `child + tail`.
There is no accumulator reassociation theorem or accumulator-specific
implementation in this candidate. Natural subtraction still saturates;
left motion still applies the explicit modulus; right motion remains
unclipped. Terminal columns return one even at depth zero. Nonterminal
depth zero returns zero. Inner fuel zero returns zero before examining the
cursor. Repeated choices retain their multiplicity.

The width parameter is an evaluator interface, not an arbitrary-width
queens correctness theorem. The existing source bridge below specializes
to width 16 and keeps the original Word16 mask and both budgets 16.

## Ordinary proof boundary

`FirstOrderNat.lean` imports only the accepted `FiniteFold` source. Its
tuple-based `referenceNext` and `spec`, and the `liftedCount` /
`liftedBranches` wrappers, exist to express the mathematical contract.
They are not called by the scalar workers. The reference transition keeps
the original left shift; the Equations proof explicitly applies
`shiftLeft_one` to connect it with multiplication.

Nine printed roots cover the universal doubling identity, four worker
equations, the unconditional `FiniteFold.Equations` instance, and three
transports to canonical fold/loop semantics. Every theorem quantifies over
its indicated Nat inputs. There is no expected answer, range assumption,
overflow hypothesis, reachability restriction or external acceptance
premise. The generic fresh closure is exactly `FiniteFold` then
`FirstOrderNat`, with eighteen printed theorem roots in total.

`FirstOrderNatSource.lean` imports the actual
`ADWH.Chapter15.QueensNatCounting`. Its `sourceBranches` is the original
`sumBits` callback, used only to prove the original four equations for
`spec 65536 mask 16`. `implementations_agree` then proves
`count_eq_source` for every Nat mask, depth and triple of states.
`branches_eq_source` likewise covers every inner fuel and cursor.
Finally, `cqueens_eq_source` and `cqueens_eq` retain the original mask,
depth 16 and loop budget 16, and use the actual `NatCounting.cqueensNat_eq`.
The adapter prints five roots, with no numeral equality result.

The all-n executor equality is distinct from board correctness. The original
board/source counting theorem still has its original `n ≤ 16` condition.

### Import preparation is a separate, explicit obligation

The source adapter's canonical import reaches `QueensFastCounting`, then
`QueensBitCounting`, and its original dependency closure. It cannot be
claimed checked merely because the two-module generic stage passes.
A full source protocol must list every original prepared import and every
freshly checked replacement/new module. The already accepted symbolic
primitive refinement and scoped counting bridge may provide that closure,
with their exact public definitions/statements and recorded omissions;
their compiled objects must not silently enter a claimed fresh new closure.
The parent owns this protocol decision. No import-pool construction is
included or executed by this source proposal.

## What the next bounded checks should resolve

First, freshly check `FiniteFold` and `FirstOrderNat` under the unchanged
30-second, one-CPU, 1-GiB gate, default Lean resource options and ordinary
axiom policy. Preserve failed source/control snapshots if proof scripts
need correction. Then check the exact source adapter under its explicitly
declared complete new closure; its additional five roots must actually be
reported and accepted.

A separately fixed native diagnostic may reuse the prior 8/10/12 boundary
with freshly compiled candidate source and the same original mask. It
must force the computed result into output before the end clock and must
not take expected counts as inputs. No new driver, native count or larger
case has been prepared or executed here; the parent will fix and review the
actual protocol before execution.

Inspect the reachable generated worker code, not a global grep for closure
symbols: the proof-side canonical fold and reference functions legitimately
contain products and callbacks. In particular, mutual well-founded
elaboration may introduce its own packing or closures. The source shape
does not prove their absence. Also verify that the hot left transition
uses native multiplication rather than the old shift call. Only after
those checks can runtime observations support an implementation claim.

Ordinary refinement of these functions does not turn a native diagnostic
result into a Lean theorem. A validating evaluator/kernel integration still
needs exact source matching, its execution/refinement proof, actual
discharge of acceptance premises, and the original source-count endpoint.
This candidate supplies a concrete reusable function and proposed ordinary
proof interface for that work; it does not bypass that trust boundary.
