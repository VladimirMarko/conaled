# Two fresh modules for the first-order Nat equations

## Exact boundary

This generic gate compiles exactly `FiniteFold` followed by `FirstOrderNat`.
Both are freshly checked from snapshotted source under the pinned Lean
4.35.0 ordinary kernel. The former imports only `Init`; the latter imports
only the just-checked `FiniteFold`. Their nine plus nine exact theorem roots
must all appear in actual compiler axiom reports. `source-manifest.json`
records the complete ordered inventory.

This gate does not compile `FirstOrderNatSource`, import an ADWH object pool,
run a native evaluator or counter, or install a kernel hook. The pending
five-root source adapter is a snapshotted review control so the source
review's complete input remains available; it is not part of the selected
mathematical closure. A later source-adapter check requires a separate
explicit import preparation and fresh full closure. There is no prior
generic-acceptance report prerequisite in this runner.

The source and runner author is `counting_route`; `regression_audit`
independently reviews the sources and this runner. Root owns execution.
The author has only prepared and AST-parsed the runner, without importing
it, running preflight or invoking a compiler.

## Fixed command and one-use identity

From this directory, the reviewed root commands are:

```sh
python3 -I run_gate.py
python3 -I run_gate.py --run --attempt generic-01
```

The first command performs read-only source/control/runtime checks and
creates no attempt or marker. Only `--run` dispatches Lean. The runner
obtains the existing nonblocking project compile lock and requires both a
new attempt directory and an absent `generic-<source-fingerprint>.json`
marker. That fingerprint contains the generic stage and the two ordered
source hashes, not the attempt label or documentation. The read-only
marker is reserved exclusively before the first compiler command and
remains after success or failure. A relabelled attempt or changed control
metadata cannot rerun unchanged mathematical sources. A genuine source
correction must receive a new review/manifest and preserve the prior
attempt's evidence.

There are no delete, overwrite, budget, object-reuse or skip-check switches.
`--lean` may relocate the same pinned binary; a changed version, hash or
shared runtime is rejected.

## Freshness and cumulative resource accounting

The build directory starts empty. The only source snapshots in the compiler
working directory are `FiniteFold.lean` and `FirstOrderNat.lean`.
`LEAN_PATH` points only to the fresh build directory. No experimental or
ADWH object is copied. The pinned release's `Init` distribution is the
standard-library dependency.

Each command has the same fixed form, with the module name substituted:

```text
<pinned lean> -j1 -M1024
  -DautoImplicit=false -DwarningAsError=true -DElab.async=false
  -o <fresh build>/<module>.olean
  -i <fresh build>/<module>.ilean
  <module>.lean
```

The unmodified resource helper is
`next-iteration/lean435-kernel-comparison/run_comparison.py`, SHA256
`2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0`.
Its `h.child` enforces the selected CPU, process-group isolation, aggregate
descendant RSS sampling and exit high-water checks. Both compiler calls
receive the same deadline: **30 cumulative seconds, one CPU/thread,
1,024 MiB Lean memory and 1,048,576 KiB resident-memory limit**. There is
no separate 30-second allowance per module and no address-space-limit
claim. Default heartbeat and recursion limits remain unchanged.

The timer starts before the first compiler call. Final elapsed accounting
also includes log audits, postchecks and artifact hashing. Source checks
and read-only snapshot preparation happen before that interval. A final
time/RSS breach fails the gate even if both compilers returned zero.

The pinned clean environment removes Lean/Lake/comparator overrides, fixes
thread counts to one and strips loader injection variables. Compiler and
all five shared Lean runtime libraries are checked before and after the
run. Their historical comparison report identifies those library bytes
only; it is not a mathematical acceptance premise.

## Input roles and restoration

The exact nine current controls are snapshotted read-only: runner, protocol,
source manifest, `PLAN.md`, `EMITTED-C-REVIEW.md`, author inventory,
independent source review, independent source audit and the pending source
adapter. Together with the two mathematical sources this makes **eleven
read-only source/control snapshots**. Every snapshot is checked against its
source by size/hash and retains its path relative to `work/` where relevant.

Thirty historical references are bound in place: the fixed resource
helper, source guard, toolchain pin, runtime-reference report, the independently
reviewed canonical project reference report, and the
twenty-five additional source/provenance files from the author's inventory
after excluding the already snapshotted `FiniteFold`. The retained baseline
C is `native-nat-evaluator-probe/emitted-c/NativeNatProbe.c`; its temporary
build copy is not needed. The original twelve-module ADWH graph is source
provenance only and is neither imported nor compiled by this gate.

The source manifest binds all six review controls and all twenty-six
inventory provenance entries, including `FiniteFold`, plus the canonical
project report identified by the independent audit. Preflight checks
the two exact source/import/root lists, strict source options, statement
inventories, independent review status/root lists/input coverage and each
provenance identity. No manifest generator is executed. Runtime and every
source/control role are rechecked afterward. Independent audit inputs must
be among these explicit bound sources/controls; unrelated files cannot be
substituted under an audit role.

## Acceptance and retained failure evidence

For each module require a zero compiler exit, no resource violation, both
fresh object files and exactly its nine fully qualified axiom reports in
order. Every raw occurrence is retained, so duplicate names or unexpected
reports cannot disappear in a dictionary. Allowed axioms are only
`propext`, `Quot.sound`, and `Classical.choice`. Stderr and stdout outside
the report records must be empty. A failed module's observed reports are
retained but contribute zero to the accepted count; later modules are not
started after a failed predecessor.

Final success requires eighteen accepted reports, both modules in order,
the exact four `.olean`/`.ilean` artifacts, all eleven immutable snapshots,
the reserved source-keyed marker, unchanged inputs/runtime/logs and final
time/RSS bounds. Partial artifacts are recorded before other postchecks,
including after failure. The report is saved before execution and after
each compiler call; failures preserve their source, controls, logs, marker
and any artifacts.

The report's scope flags keep `source_adapter_checked`,
`source_count_proved`, `native_evaluator_or_counter_executed`,
`kernel_integration_implemented` and `n16_target_proved` false. Passing this
gate establishes the generic first-order refinement and equations under
the ordinary-kernel trust boundary. It does not establish a numeral result
or the pending actual-source adapter.
