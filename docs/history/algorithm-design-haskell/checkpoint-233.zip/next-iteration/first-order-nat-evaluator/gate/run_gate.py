#!/usr/bin/env python3
"""Two fresh ordinary-kernel modules; only --run invokes Lean."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
PROJECT_REFERENCE = ROOT / 'project/adwh-lean/reports/verification.json'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FIXED = {
    PROJECT_REFERENCE: 'f7f000482a7a655e092fb30b2969302cdf2b037f8c08b3b1f15a6d85e46e9c5f',
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
}
MODULES = ['FiniteFold', 'FirstOrderNat']
SOURCE_PATHS = {
    'FiniteFold': ROOT / 'next-iteration/finite-fold-evaluator/source/FiniteFold.lean',
    'FirstOrderNat': CANDIDATE / 'source/FirstOrderNat.lean',
}
IMPORTS = {'FiniteFold': ['Init'], 'FirstOrderNat': ['FiniteFold']}
RAW_ROOTS = {
    'FiniteFold': ['loop_zero', 'loop_succ', 'fold_zero', 'fold_succ', 'canonical_equations',
                   'loop_unique_of_equations', 'fold_unique_of_equations',
                   'branches_unique_of_equations', 'implementations_agree'],
    'FirstOrderNat': ['shiftLeft_one', 'count_zero', 'count_succ', 'branches_zero',
                     'branches_succ', 'equations', 'count_eq_fold', 'branches_eq_loop',
                     'evaluate_eq_fold'],
}
ROOTS = {name: ['ADWH.Experiments.Chapter15.' + name + '.' + root for root in RAW_ROOTS[name]]
         for name in MODULES}
ADAPTER_RAW = ['source_equations', 'count_eq_source', 'branches_eq_source',
               'cqueens_eq_source', 'cqueens_eq']
ADAPTER_ROOTS = ['ADWH.Experiments.Chapter15.FirstOrderNat.SourceBridge.' + r for r in ADAPTER_RAW]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
FORMAT = 'adwh-first-order-nat-generic-gate-v1'
MANIFEST_FORMAT = 'adwh-first-order-nat-generic-manifest-v1'
CURRENT = [
    ('runner', HERE / 'run_gate.py'),
    ('protocol', HERE / 'PROTOCOL.md'),
    ('source_manifest', MANIFEST),
    ('mathematical_design', CANDIDATE / 'PLAN.md'),
    ('baseline_c_review', CANDIDATE / 'EMITTED-C-REVIEW.md'),
    ('author_source_inventory', CANDIDATE / 'SOURCE-INVENTORY.json'),
    ('independent_source_review', CANDIDATE / 'SOURCE-REVIEW.md'),
    ('independent_source_audit', CANDIDATE / 'SOURCE-AUDIT.json'),
    ('pending_source_adapter_not_compiled', CANDIDATE / 'source/FirstOrderNatSource.lean'),
]
HISTORICAL_BASE = [
    ('resource_helper', HELPER), ('source_guard', GUARD), ('toolchain_pin', PIN),
    ('pinned_runtime_reference_report', RUNTIME_REFERENCE),
    ('canonical_project_reference_report', PROJECT_REFERENCE),
]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and not path.is_symlink()
                  and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                  'Evidence binding differs: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot/marker: ' + str(path))


def resolved_binding(row, expected_path, h):
    path = (ROOT / row['path']).resolve()
    h.require(path == expected_path.resolve(), 'Evidence has the wrong path/role: ' + str(expected_path))
    actual = h.binding(path)
    h.require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
              'Declared source/control binding differs: ' + str(path))
    verify([actual], h)
    return actual


def source_fingerprint(sources):
    identity = {'stage': 'generic', 'sources': [
        {'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def control_role(controls, role, expected_path, h, snapshot=False):
    expected = h.binding(expected_path.resolve())
    rows = [row for row in controls if row['role'] == role]
    h.require(len(rows) == 1 and {key: rows[0][key] for key in ('path', 'bytes', 'sha256')} == expected,
              'Missing or substituted control role: ' + role)
    if snapshot:
        frozen = rows[0].get('snapshot')
        h.require(rows[0]['snapshot_required'] and frozen is not None
                  and all(frozen[key] == expected[key] for key in ('bytes', 'sha256')),
                  'Current control has no matching snapshot: ' + role)
        verify([frozen], h, readonly=True)
    return expected


def preflight(args, h, guard):
    for path, expected in FIXED.items():
        h.require(path.is_file() and sha(path) == expected, 'Pinned historical input differs: ' + str(path))
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    manifest, inventory = read(MANIFEST), read(CANDIDATE / 'SOURCE-INVENTORY.json')
    independent = read(CANDIDATE / 'SOURCE-AUDIT.json')
    h.require(manifest['format'] == MANIFEST_FORMAT and manifest['module_order'] == MODULES
              and manifest['root_module'] == 'FirstOrderNat'
              and manifest['required_axiom_report_count'] == 18
              and manifest['required_prints'] == ROOTS
              and manifest['raw_source_print_identifiers'] == RAW_ROOTS
              and manifest['imports'] == IMPORTS and manifest['prepared_objects'] == [],
              'Two-module source/root/import manifest differs')
    h.require(len(manifest['sources']) == 2, 'Mathematical source count differs')
    sources = []
    for row, module in zip(manifest['sources'], MODULES):
        h.require(row['module'] == module and row['imports'] == IMPORTS[module], 'Source module/order differs')
        sources.append({**resolved_binding(row, SOURCE_PATHS[module], h),
                        'module': module, 'imports': IMPORTS[module]})
    h.require(sources[0]['sha256'] == '25d84a52adca5f4c60163640aee8f31ded88322b8bd98c27f96d1aeb0c8b5d4e',
              'Canonical FiniteFold source differs')
    review_paths = [path for role, path in CURRENT if role not in {'runner', 'protocol', 'source_manifest'}]
    h.require(len(manifest['review_controls']) == len(review_paths) == 6, 'Review controls differ')
    for row, path in zip(manifest['review_controls'], review_paths):
        resolved_binding(row, path, h)
    h.require(inventory['format'] == 'adwh-first-order-nat-source-inventory-v1'
              and inventory['generic_stage']['module_order'] == MODULES
              and inventory['generic_stage']['required_root_count'] == 18
              and inventory['generic_stage']['axiom_roots'] == ROOTS['FiniteFold'] + ROOTS['FirstOrderNat']
              and len(inventory['sources']) == 2 and len(inventory['frozen_inputs']) == 14,
              'Author inventory describes a different boundary')
    candidate, adapter = inventory['sources']
    h.require(candidate['module'] == 'FirstOrderNat' and candidate['imports'] == IMPORTS['FirstOrderNat']
              and candidate['axiom_roots'] == ROOTS['FirstOrderNat']
              and candidate['source_print_identifiers'] == RAW_ROOTS['FirstOrderNat']
              and adapter['module'] == 'FirstOrderNatSource'
              and adapter['imports'] == ['FirstOrderNat', 'ADWH.Chapter15.QueensNatCounting']
              and adapter['axiom_roots'] == ADAPTER_ROOTS
              and adapter['source_print_identifiers'] == ADAPTER_RAW,
              'Candidate/adapter root or import identities differ')
    resolved_binding(candidate, SOURCE_PATHS['FirstOrderNat'], h)
    resolved_binding(adapter, CANDIDATE / 'source/FirstOrderNatSource.lean', h)
    h.require(len(inventory['documents']) == 2, 'Author document inventory differs')
    for row, filename in zip(inventory['documents'], ['PLAN.md', 'EMITTED-C-REVIEW.md']):
        resolved_binding(row, CANDIDATE / filename, h)
    for module, source in zip(MODULES, sources):
        path = Path(source['path'])
        code = guard.check_lean_source(path, path.read_text())
        imports = [name for line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M)
                   for name in line.split()]
        h.require(imports == IMPORTS[module], 'Unexpected mathematical import: ' + module)
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]:
            found = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
            h.require(found and set(found) == {value}, 'Strict source option differs: ' + module + '/' + option)
        h.require(not re.search(r'\bset_option\s+(maxHeartbeats|maxRecDepth|maxMemory)\b', code),
                  'Source resource override is forbidden')
        h.require(re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M) == RAW_ROOTS[module]
                  and re.findall(r'^\s*theorem\s+(\S+)', code, re.M) == RAW_ROOTS[module]
                  and re.findall(r'^\s*namespace\s+(\S+)', code, re.M)
                  == ['ADWH.Experiments.Chapter15.' + module], 'Exact declaration/print namespace differs')
    for row in inventory['sources']:
        text = (ROOT / row['path']).read_text()
        h.require([x['name'] for x in row['theorem_statements']] == row['axiom_roots'],
                  'Statement inventory root order differs')
        for item in row['theorem_statements']:
            h.require(item['statement'] in text, 'Theorem statement inventory differs')
    expected_audit_roots = {'FirstOrderNat': ROOTS['FirstOrderNat'], 'FirstOrderNatSource': ADAPTER_ROOTS}
    h.require(independent['format'] == 'adwh-first-order-nat-independent-source-audit-v1'
              and independent['status'] == 'passed_source_only_review_not_compiled'
              and independent['fully_qualified_roots'] == expected_audit_roots,
              'Independent source audit differs')

    # All inventory provenance is bound in place; none supplies a proof premise or object.
    refs = inventory['frozen_inputs'] + inventory['source_adapter_stage']['unchanged_project_source_closure_for_reference_only']
    h.require(len(refs) == 26, 'Historical source/provenance count differs')
    historical = list(HISTORICAL_BASE)
    for index, row in enumerate(refs):
        path = (ROOT / row['path']).resolve()
        h.require(path.is_relative_to(ROOT.parent), 'Provenance path escapes the workspace')
        resolved_binding(row, path, h)
        if path not in SOURCE_PATHS.values():
            historical.append(('source_provenance_' + str(index), path))
    h.require(manifest['provenance_references'] == refs, 'Manifest provenance differs from author inventory')
    h.require(len(manifest['extra_review_references']) == 1, 'Extra review reference count differs')
    resolved_binding(manifest['extra_review_references'][0], PROJECT_REFERENCE, h)
    controls = [{**h.binding(path), 'role': role, 'snapshot_required': True,
                 'retained_historical_reference': False} for role, path in CURRENT]
    controls += [{**h.binding(path), 'role': role, 'snapshot_required': False,
                  'retained_historical_reference': True} for role, path in historical]
    h.require(len(controls) == 39 and len(historical) == 30
              and len({row['role'] for row in controls}) == len(controls)
              and len({row['path'] for row in controls}) == len(controls), 'Duplicate control identity or role')
    expected_inputs = {row['path']: row for row in sources + controls}
    audited_paths = []
    for row in independent['inputs']:
        path = (ROOT / row['path']).resolve()
        h.require(str(path) in expected_inputs, 'Independent audit input is not bound by the gate')
        resolved_binding(row, path, h)
        audited_paths.append(str(path))
    required_audit_paths = {str(path) for path in [*SOURCE_PATHS.values(),
        CANDIDATE / 'source/FirstOrderNatSource.lean', CANDIDATE / 'PLAN.md',
        CANDIDATE / 'EMITTED-C-REVIEW.md', CANDIDATE / 'SOURCE-INVENTORY.json']}
    h.require(len(audited_paths) == len(set(audited_paths))
              and required_audit_paths <= set(audited_paths), 'Independent audit input coverage differs')

    compiler_path = args.lean.resolve()
    h.TOOLCHAIN = compiler_path.parent.parent
    pins = read(PIN)
    compiler = h.binding(compiler_path)
    h.require(compiler_path.name == 'lean' and pins['version'] == '4.35.0'
              and pins['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
              and all(compiler[key] == pins['binaries']['lean'][key] for key in ('bytes', 'sha256')),
              'Pinned compiler identity differs')
    reference = read(RUNTIME_REFERENCE)
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in reference['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((h.TOOLCHAIN / 'lib/lean').glob('*.so'))]
    h.require(len(runtime) == 5
              and {Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime} == expected_runtime,
              'Pinned shared runtime inventory differs')
    for role, path in CURRENT + historical:
        control_role(controls, role, path, h)
    verify(sources + [compiler] + runtime + controls, h)
    return {'sources': sources, 'source_fingerprint': source_fingerprint(sources),
            'controls': controls, 'control_paths': CURRENT + historical,
            'compiler': compiler, 'runtime_libraries': runtime,
            'compiler_release': pins['version'], 'compiler_commit': pins['commit']}


def audit_logs(module, stdout, stderr):
    out, err = Path(stdout['path']).read_text(), Path(stderr['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [row['root'] for row in raw]
    permitted = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'passed': names == ROOTS[module] and permitted and not err and not pattern.sub('', out).strip(),
            'required_count': 9, 'observed_count': len(raw), 'observed_unique_count': len(set(names)),
            'exact_ordered_names': names == ROOTS[module], 'all_raw_axiom_names_permitted': permitted,
            'duplicate_names': [name for name, n in Counter(names).items() if n > 1],
            'reports': {row['root']: row['axioms'] for row in raw}, 'raw_reports': raw,
            'stderr_empty': not err, 'unparsed_stdout': pattern.sub('', out).strip()}


def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker_path = HERE / 'execution-markers' / ('generic-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker_path.exists(), 'Attempt or unchanged source already executed')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, input_copies = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    input_copies.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt, 'stage': 'generic',
              'module_order': MODULES, 'root_module': 'FirstOrderNat',
              'source_fingerprint': plan['source_fingerprint'], 'source_manifest': h.binding(MANIFEST),
              'source_bindings': plan['sources'], 'controls': plan['controls'],
              'compiler': plan['compiler'], 'compiler_release': plan['compiler_release'],
              'compiler_commit': plan['compiler_commit'], 'runtime_libraries': plan['runtime_libraries'],
              'execution_marker': None, 'current_control_snapshot_count': 9, 'historical_reference_count': 30,
              'modules': [], 'required_prints': ROOTS,
              'raw_source_print_identifiers': RAW_ROOTS, 'required_axiom_report_count': 18,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'seconds': None, 'peak_child_rss_kib': 0,
              'artifacts': [], 'prepared_objects': [], 'object_search_path': str(build),
              'standard_library': 'Pinned Lean 4.35 release Init distribution',
              'constraints': {'cumulative_wall_seconds': 30, 'resident_memory_kib': 1048576,
                  'lean_memory_mib': 1024, 'compiler_threads': 1, 'cpu_affinity': [],
                  'default_heartbeats_and_recursion': True},
              'exact_build_artifact_inventory': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'all_selected_mathematical_sources_freshly_checked': False,
              'complete_first_order_generic_proof_checked': False,
              'compiled_experimental_imports_reused': False, 'original_ADWH_imports_used': False,
              'source_count_proved': False, 'n16_target_proved': False,
              'native_evaluator_or_counter_executed': False, 'kernel_integration_implemented': False,
              'integrated_project_modified': False, 'source_adapter_checked': False,
              'authorship': {'source_and_runner_author': 'counting_route',
                            'independent_source_reviewer': 'regression_audit', 'execution_owner': 'root'}}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings']:
            path = frozen / (row['module'] + '.lean')
            with path.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            path.chmod(0o444)
            row['snapshot'] = h.binding(path)
            h.require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')),
                      'Source snapshot differs')
        for control in report['controls']:
            if control['snapshot_required']:
                control_path = Path(control['path'])
                target = input_copies / control_path.relative_to(ROOT)
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(control_path.read_bytes())
                target.chmod(0o444)
                control['snapshot'] = h.binding(target)
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
        verify([row['snapshot'] for row in report['source_bindings']], h, readonly=True)
        for role, path in plan['control_paths']:
            control_role(report['controls'], role, path, h, snapshot=(role in {x[0] for x in CURRENT}))
        marker_path.parent.mkdir(exist_ok=True)
        marker_body = {'format': FORMAT, 'attempt': args.attempt, 'stage': 'generic',
                       'source_fingerprint': plan['source_fingerprint'],
                       'source_manifest': report['source_manifest'],
                       'source_bindings': report['source_bindings'], 'controls': report['controls'],
                       'compiler': report['compiler'], 'runtime_libraries': report['runtime_libraries'],
                       'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        with marker_path.open('x') as stream:
            stream.write(json.dumps(marker_body, indent=2, sort_keys=True) + '\n')
        marker_path.chmod(0o444)
        report['execution_marker'] = h.binding(marker_path)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                       '-DwarningAsError=true', '-DElab.async=false',
                       '-o', str(build / (module + '.olean')), '-i', str(build / (module + '.ilean')),
                       module + '.lean']
            result = h.child(command, frozen, env, attempt / (module + '.stdout.log'),
                             attempt / (module + '.stderr.log'), cpu, deadline)
            audit = audit_logs(module, result['stdout'], result['stderr'])
            objects = all((build / (module + suffix)).is_file() for suffix in ('.olean', '.ilean'))
            good = result['exit_code'] == 0 and result['within_limits'] and audit['passed'] and objects
            report['modules'].append({'module': module, **result, 'axiom_audit': audit,
                                      'observed_report_occurrences': audit['observed_count'],
                                      'required_objects_present': objects, 'status': 'passed' if good else 'failed'})
            report['observed_axiom_report_count'] += audit['observed_count']
            report['observed_unique_axiom_root_count'] = len({
                row['root'] for item in report['modules'] for row in item['axiom_audit']['raw_reports']})
            report['accepted_axiom_report_count'] += audit['observed_count'] if good else 0
            h.save(report_path, report)
            h.require(good, 'Fresh compiler module, exact axiom reports, or resource check failed: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            h.require(len(snapshots) == 11, 'Incomplete source/control snapshots')
            verify(snapshots, h, readonly=True)
            verify([row[key] for row in report['modules'] for key in ('stdout', 'stderr')], h)
            for row in report['source_bindings']:
                h.require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')),
                          'Source snapshot identity changed')
            for role, path in plan['control_paths']:
                control_role(report['controls'], role, path, h, snapshot=(role in {x[0] for x in CURRENT}))
            h.require(report['execution_marker'] is not None, 'Execution marker was not reserved')
            verify([report['execution_marker']], h, readonly=True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected_objects = {str(build / (module + suffix)) for module in MODULES
                                for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = {row['path'] for row in report['artifacts']} == expected_objects
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [row['module'] for row in report['modules']] == MODULES
                  and all(row['status'] == 'passed' for row in report['modules'])
                  and report['accepted_axiom_report_count'] == 18
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['complete_first_order_generic_proof_checked'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
                      'seconds': report['seconds'], 'peak_rss_kib': report['peak_child_rss_kib'],
                      'observed_roots': report['observed_axiom_report_count'],
                      'accepted_roots': report['accepted_axiom_report_count']}, sort_keys=True))
    return 0 if report['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path,
                        default=ROOT.parent / 'toolchains/lean-4.35.0-linux/bin/lean')
    parser.add_argument('--attempt', default='generic-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'generic-(?:0[1-9]|[1-9][0-9])', args.attempt):
        raise ValueError('Attempt must be generic-01 through generic-99')
    for path, expected in FIXED.items():
        if sha(path) != expected:
            raise ValueError('Pinned code/evidence differs before loading: ' + str(path))
    h = load(HELPER, 'first_order_nat_resource_helper')
    guard = load(GUARD, 'first_order_nat_source_guard')
    h.require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Pinned helper contract differs')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
                          'required_axiom_report_count': 18, 'prepared_objects': 0,
                          'current_controls_to_snapshot': 9, 'historical_references_bound_in_place': 30,
                          'source_fingerprint': plan['source_fingerprint'],
                          'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
