# FirstOrderNat generic proof: accepted result

The first `generic-01` attempt freshly compiled **FiniteFold and FirstOrderNat**
and accepted **18 required / 18 observed / 18 distinct / 18 accepted roots**.
Both compiler exits were zero, with no warnings, extra output or resource event.
The complete gate took **1.1119027979948441 seconds** and recorded
**503,196 KiB** peak RSS under the unchanged 30-second, one-CPU, one-GiB policy.

The immutable [raw report](gate/attempts/generic-01/report.json) is 32,880 bytes,
SHA256 `49ce08dd3eb5560e42504e37b337bee721191edad62d2a124ecfa22db7619a47`.
The source fingerprint is
`cefd4c1a4c6d94c6bcf396ce68cdbd79e36521b598f6fc6043bf89a74776d8b0`.

| Fresh module | Compiler wall seconds | Peak RSS KiB | Accepted roots |
|---|---:|---:|---:|
| `FiniteFold` | 0.42917499999748543 | 495,664 | 9 |
| `FirstOrderNat` | 0.49725697299436433 | 503,196 | 9 |

All nine FiniteFold roots reported no axioms. FirstOrderNat's `shiftLeft_one`
reported `propext`; its other eight roots reported `propext` and `Quot.sound`.
The actual ordered reports were independently parsed from all four raw logs,
with empty stderr and no unmatched stdout. The exact lists are retained in
[GENERIC-RESULTS.json](GENERIC-RESULTS.json).

## Accepted scope

The generic first-order workers are now ordinarily checked total functions.
Their lexicographic termination proofs and equation lemmas compiled without
correction. Their universal equations agree with the accepted finite-fold
semantics for arbitrary Nat parameters/states, and the shift-by-one replacement
is justified by its general Nat equality.

This gate did not compile `FirstOrderNatSource`, import ADWH objects, execute a
native counter, inspect newly emitted C or accept a numerical queen result.
The pending adapter was a snapshotted review control. Acceptance of its five
roots and the actual original-source connection belongs to a separate full
gate. Native representation and execution correctness likewise require their
own evidence; successful ordinary refinement does not certify an external
return value.

## Saved-evidence audit and recovery

The independent auditor checked **68 report binding occurrences / 67 identities**
and **59 marker occurrences / 58 identities**. It verified all source/control
roles, 30 historical references, 11 read-only snapshots, the compiler and five
runtime libraries, four fresh objects and four raw logs. The source manifest,
review input bindings and permanent marker agree. All 18 reports were accepted
in this fresh invocation; no prepared experimental object was reused.

The source/gate author was `counting_route`, the independent source/gate/result
reviewer was `regression_audit`, and `root` alone ran the compilers. This audit
used only saved-file parsing and hashing; no gate, compiler, generator or counter
was rerun. Sources, controls, marker and raw report remain unchanged.

[GENERIC-SNAPSHOT-RECOVERY.json](GENERIC-SNAPSHOT-RECOVERY.json) maps the **11
snapshots, totalling 122,976 bytes**, to unchanged canonical files. There are no
unique superseded inputs. Four pinned standard-library source references that
originally lived outside `work/` are preserved byte-for-byte under
`recovery-provenance/`, totalling **50,744 bytes**. Their mappings allow source-only
auditing without requiring an installed toolchain merely to recover those
review inputs. The map lists 26 candidate payload paths, the 30 historical
references and the separately retained FiniteFold mathematical source.

The four compiled objects and external runtime distribution may be omitted from
the source-only checkpoint while keeping their recorded hashes. Run
`audit_generic_result.py --source-only` to validate retained evidence and mapped
source bytes. That mode does not require ZIP extraction to preserve read-only
permission bits and records this explicitly; every content hash and role check
remains mandatory. Full/live mode retains the original read-only requirements.
Historical markers must remain intact during any later dependency materialization.
