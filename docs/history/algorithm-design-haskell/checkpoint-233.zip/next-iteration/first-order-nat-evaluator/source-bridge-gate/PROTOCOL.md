# Fresh connection to the original source counter

The selected root is `FirstOrderNatSourceAudit`. This gate freshly checks ten
modules, with 67 exact axiom reports, using only the seven previously prepared
unchanged ADWH modules as project imports. It establishes the universal
first-order/source-counter adapter. It runs no native program and proves no
numeral. The integrated project remains unchanged.

The four first modules are the byte-identical accepted symbolic Word16 core,
recurrence, original-namespace primitive refinement and scoped counting source
from `legacy-list-clause-compatibility/count-migration`. The primitive refinement
preserves original executable definitions and theorem statements; its accepted
source-preservation records remain pinned. The scoped counter retains all six
executable definitions and all ten structural/source correctness theorems. It
omits only the unrelated QueensExamples import and three numerical convenience
theorems. Preflight independently reverses its exact edit map to reconstruct the
complete original file byte for byte. No source endpoint is replaced by a
similar name or a copied expected answer.

Next come the exact original `QueensFastCounting` and `QueensNatCounting`, then
fresh `FiniteFold`, `FirstOrderNat`, `FirstOrderNatSource` and a small audit-only
module. The audit module prints the three FastCounting and seven NatCounting
roots, which have no print commands in their original sources. The other seven
mathematical source files supply 57 reports. All 67 must actually appear in the
fixed per-module order, with no duplicate/substituted reports or extra output.
All axiom names must belong to propext, Quot.sound and Classical.choice.

## Explicit original import preparation

The sole object pool is the accepted `scoped-counting-bridge/import-preparation`
`originals-01` result, SHA256
`2a8670767de8261255e65b92ed69de85b015669a86cae7a854c26c7d166f2c14`.
It contains exactly the .olean/.ilean pairs for Lists, Permutations, Queens,
QueensVariants, QueensSearch, QueensBitRepresentation and QueensBitMoves.
Those seven original sources are independent of the new symbolic primitive.
They were separately freshly prepared under the same fixed limits. No
experimental module, count helper or earlier generic object is copied.

The new runner reuses only the pinned read-only `preparation` function in the
accepted packed-row gate to recheck this exact pool and all its raw bindings.
It reuses only the new generic runner's `preflight` and simple verification
helpers to validate the two new helper sources, pending adapter, independent
reviews, exact original provenance and compiler/runtime. Neither imported
runner's `main` or execution function is called. Their exact source hashes are
checked before loading. No prior generic result is an acceptance prerequisite
or computational premise. The first-order generic gate may already have passed,
but both helper sources must still be freshly checked here.

All sources, imported reader code and control roles are bound. Twelve current
controls and ten mathematical sources are copied into 22 read-only snapshots.
The original fourteen objects are copied into a fresh build directory and
verified by size/hash. The mathematical path is exactly that build directory
plus the pinned standard library. Final inventory must contain exactly 34
objects: the fourteen original copies and twenty newly generated files.

## One run and unchanged limits

After independent source/protocol review, root may run:

```sh
python3 -I run_gate.py
python3 -I run_gate.py --run --attempt source-bridge-01
```

No-run mode checks sources/controls/runtime only. The execution mode obtains the
shared nonblocking compile lock, requires a new attempt directory and reserves
an exclusive read-only source-keyed marker. Its fingerprint covers the stage
and all ten ordered source hashes. Altering a label or documentation cannot
repeat this unchanged closure. Preserve the marker and all failed evidence;
only an actual source correction with new review can justify another attempt.

All ten commands use the pinned Lean 4.35.0 binary with `-j1 -M1024`,
autoImplicit=false, warningAsError=true and Elab.async=false. The exact original
Fast/Nat files lack a source-level async option, so the fixed command supplies
it. No heartbeat or recursion override is permitted. Each child uses the
unchanged pinned resource helper and the same cumulative deadline.

The limit remains 30 cumulative seconds, one CPU/thread and 1,048,576 KiB RSS,
including final log/object/input checks. The timer starts before the first
compiler; preparation/copying occurs before it. CPU affinity, process-group
monitoring, descendant RSS and exit high-water accounting match the earlier
gates. This is not an address-space-limit claim. Final time or memory excess
fails even after zero compiler exits. Loader/Lean overrides are stripped.

The runner records each module's actual reports and accepts none from a failed
module. It stops at the first failure, retains logs, snapshots, partial artifacts
and marker, and writes a failed raw report. Postchecks revalidate controls,
snapshots, compiler/runtime, logs, copied original objects, source pool and exact
artifact inventory before accepting the complete source adapter.

Source author: counting_route. Source reviewer: regression_audit. This adapter
gate and audit-only source: root; a separate agent must review them before
execution. No source-count equality, native result, custom checker acceptance
or stock-kernel numeral theorem follows merely from this universal adapter.
