# Independent source review of the actual-source bridge gate

**Finding: no execution blocker found.** This is a source/control review, not a preflight or compiler outcome. Reviewer `validity_contracts` did not author this gate or the first-order evaluator/adapter. The reviewer authored the separately accepted FiniteFold helper and the new restricted-checker candidate.

Reviewed frozen identities:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `run_gate.py` | 21,653 | `3903de3e12f4e75ceb58dc888ca80cbf9c304bb66acf5640cbe1a99b024ff8b1` |
| `PROTOCOL.md` | 5,603 | `3e7ba25caea4d12423edc3f8d537078187b2427c350fd408108837fe1b8a49d1` |
| `source-manifest.json` | 20,525 | `e63c13e2c263a75902c2829622c1d3720b2d67befe1c63a951a597911ffe8f3b` |

## Mathematical and source boundary

I checked all ten manifest source bindings, their printed-root lists, and the exact total of **67 distinct roots**. The selected sequence freshly compiles the symbolic Word16 core/recurrence, preserved original-namespace primitive refinement, preserved scoped source counter, actual original Fast/Nat counters, FiniteFold, first-order evaluator, source adapter, and audit-only import. The two original Fast/Nat modules emit no reports themselves; the final audit module requests all three and seven original theorem roots explicitly. Its source contains no new definition, theorem, evaluator invocation, or numeric premise.

The audit-only module is pinned at `6704cfdb14d1d4d0f1bc0b2431085350577c43f2ba6786ef281cf59a89dc438e`. The independent mathematical review of that file is retained in `../SOURCE-AUDIT-MODULE-REVIEW.json`, SHA-256 `3dc8c4cf606069c7c942284b7321b1c08d6787ca72ce14479c703c06ca8c360a`. It is separate review evidence; the runner directly pins the mathematical source itself.

I independently reversed the scoped counter's four edit records and recovered the exact original `QueensBitCounting.lean` bytes and hash. The original `cqueens` definition and structural correctness theorems are retained. The omitted examples import and three convenience numeral theorems are explicit and do not become a substitute endpoint.

## Freshness and preserved imports

The only copied object pool is the fixed accepted seven-module original-only preparation, report SHA-256 `2a8670767de8261255e65b92ed69de85b015669a86cae7a854c26c7d166f2c14`. I checked the fourteen recorded object identities. The pinned `preparation` reader checks the original sources, exact pool inventory, compiler/runtime, raw preparation evidence, accepted status and prior resource boundary before and after the new run.

No experimental or earlier generic object is copied. Both FiniteFold and FirstOrderNat are fresh in this gate regardless of earlier generic success. The source/import inventory permits only the selected preceding modules, the seven original imports, and the pinned standard library. The build directory starts with exactly fourteen original files and must finish with exactly those plus twenty fresh files: **34 artifacts**.

The imported generic runner is used only for its read-only `preflight` and binding helpers. The packed-row runner is used only for its original-pool reader and binding traversal. Both are checked by fixed source hashes before import. Their execution entry points, generators and accepted-generic-report function are not called. There is no previous generic result pointer that can be confused with the runtime reference report.

## Controls, resources and acceptance

The runner snapshots ten sources and twelve current controls into **22 read-only copies**. It retains all 47 role-labelled control records, their historical references, exact compiler/runtime identities and the original-object provenance. Source fingerprints cover all ten ordered source hashes. A read-only source-keyed marker and exclusive new attempt directory are required before Lean starts; changing an attempt label or documentation cannot repeat the same source closure.

The nonblocking shared compile lock and the unchanged pinned `h.child` enforce the existing one-CPU/process-group boundary. Every compiler receives `-j1 -M1024`, strict elaboration/warning flags, and the same cumulative deadline. Source heartbeat/recursion overrides are rejected. The 30-second final budget includes log analysis, object hashing, original-pool revalidation and postchecks; preparation/copying precedes the timer. RSS remains the existing sampled/exit-high-water **1,048,576 KiB** limit, not an address-space claim.

Every selected module must exit zero, remain within limits, create both objects and emit exactly its ordered allowed-axiom reports with empty stderr and no unparsed stdout. A failed module contributes zero accepted roots even if error recovery prints reports. The first failure stops subsequent compilation. Final success additionally requires all 67 accepted roots, all ten successful modules, exact artifacts, unchanged original/snapshot/runtime/log/marker/object bindings, and final time/RSS bounds.

The success claim is the universal adapter to the actual source counter. It is not a numerical count, external checker acceptance or stock-kernel numeral theorem. Preparation of the restricted checker does not alter this gate's scope.

Review activities were source reading, AST parsing, JSON/statement checks, SHA-256 checks and the read-only source inverse. I did **not** import either runner, call preflight/preparation/source guards, run Lean, invoke a compiler, or execute a counter. No bound source, control, report or marker was modified.
