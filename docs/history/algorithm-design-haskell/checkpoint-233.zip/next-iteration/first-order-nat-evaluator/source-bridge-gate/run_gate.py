#!/usr/bin/env python3
"""Fresh actual-source bridge; only --run executes Lean."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
GENERIC = CANDIDATE / 'gate/run_gate.py'
PREP_READER = ROOT / 'next-iteration/packed-row-descriptor-cache/gate/run_gate.py'
BASELINE = ROOT / 'next-iteration/legacy-list-clause-compatibility/count-migration'
INVENTORY = CANDIDATE / 'SOURCE-INVENTORY.json'
FIXED_READER_HASHES = {
    GENERIC: '3aeb4e2067e8f3602991677b89dc59fec1c25b0de9070932c894754ccecb31ec',
    PREP_READER: 'b33b20262684fa8326123ab4c537f6459ab4cbe4051ef1ace577ac08729a2201',
}
MODULES = ['SymbolicWord16Core', 'SymbolicWord16Recurrence',
           'ADWH.Chapter15.QueensBitsPrimitives', 'ADWH.Chapter15.QueensBitCounting',
           'ADWH.Chapter15.QueensFastCounting', 'ADWH.Chapter15.QueensNatCounting',
           'FiniteFold', 'FirstOrderNat', 'FirstOrderNatSource', 'FirstOrderNatSourceAudit']
FORMAT = 'adwh-first-order-nat-actual-source-gate-v1'
OWN_CURRENT = [('source_bridge_runner', HERE / 'run_gate.py'),
               ('source_bridge_protocol', HERE / 'PROTOCOL.md'),
               ('source_bridge_manifest', MANIFEST)]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rel(module, suffix='.lean'):
    return Path(*module.split('.')).with_suffix(suffix)


def preflight(args, g, p, h, guard):
    # Reuse only the reviewed read-only source/control/runtime checks, not its run.
    generic = g.preflight(args, h, guard)
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    manifest, baseline, inventory = read(MANIFEST), read(BASELINE / 'generation.json'), read(INVENTORY)
    h.require(manifest['format'] == 'adwh-first-order-nat-source-bridge-manifest-v1'
              and manifest['module_order'] == MODULES and manifest['root_module'] == MODULES[-1]
              and manifest['required_axiom_report_count'] == 67
              and manifest['new_mathematical_objects_all_fresh']
              and manifest['prepared_original_objects'] == 14
              and manifest['no_numeral_evaluation']
              and len(manifest['sources']) == 10,
              'Actual-source manifest boundary differs')
    h.require(manifest['unchanged_original_import_sources'] == baseline['unchanged_original_import_sources']
              and manifest['scoped_original_source_bridge'] == baseline['scoped_original_source_bridge'],
              'Original source/dependency scope differs')
    expected_paths = [ROOT / row['path'] for row in baseline['sources'][:4]] + [
        ROOT / 'project/adwh-lean' / rel(MODULES[4]),
        ROOT / 'project/adwh-lean' / rel(MODULES[5]),
        g.SOURCE_PATHS['FiniteFold'], g.SOURCE_PATHS['FirstOrderNat'],
        CANDIDATE / 'source/FirstOrderNatSource.lean',
        CANDIDATE / 'source/FirstOrderNatSourceAudit.lean']
    expected_roots = {module: baseline['axiom_roots'][module] for module in MODULES[:4]}
    expected_roots.update({MODULES[4]: [], MODULES[5]: [], **g.ROOTS,
                          'FirstOrderNatSource': g.ADAPTER_ROOTS})
    fast = ['sumBitsLoop_eq', 'countFast_eq', 'cqueensFast_eq']
    nat = ['low_refines', 'remainder_refines', 'next_refines', 'available_refines',
           'sumBits_refines', 'count_refines', 'cqueensNat_eq']
    expected_roots['FirstOrderNatSourceAudit'] = [
        'ADWH.Chapter15.Queens.BitRepresentation.' + name for name in fast] + [
        'ADWH.Chapter15.Queens.BitRepresentation.NatCounting.' + name for name in nat]
    h.require(manifest['source_adapter_statement'] == inventory['sources'][1]['theorem_statements'][-1],
              'Original endpoint theorem statement differs')
    sources = []
    available = set(p.ORIGINALS)
    for index, (row, module, path) in enumerate(zip(manifest['sources'], MODULES, expected_paths)):
        bound = g.resolved_binding(row, path, h)
        code = guard.check_lean_source(path, path.read_text())
        imports = [name for line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M)
                   for name in line.split()]
        h.require(row['module'] == module and row['imports'] == imports
                  and row['roots'] == expected_roots[module]
                  and re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M) == row['raw_prints'],
                  'Source module/import/root inventory differs: ' + module)
        h.require(all(name in available or name == 'Init' or name.startswith('Init.')
                      or name == 'Std' or name.startswith('Std.') for name in imports),
                  'Unexpected or forward mathematical dependency: ' + module)
        h.require(not re.search(r'\bset_option\s+(maxHeartbeats|maxRecDepth|maxMemory)\b', code),
                  'Source resource override: ' + module)
        # Original Fast/Nat modules receive serial elaboration from the fixed CLI.
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true')]:
            values = re.findall(r'\bset_option\s+' + option + r'\s+(\S+)', code)
            h.require(values and set(values) == {value}, 'Source strict option differs: ' + module)
        async_values = re.findall(r'\bset_option\s+Elab\.async\s+(\S+)', code)
        h.require(not async_values or set(async_values) == {'false'}, 'Async source override')
        if index < 4:
            old = baseline['sources'][index]
            h.require(all(row[key] == old[key] for key in ('module', 'path', 'bytes', 'sha256', 'imports')),
                      'Changed retained source refinement')
        if index in (6, 7):
            ref = generic['sources'][index - 6]
            h.require(all(bound[key] == ref[key] for key in ('path', 'bytes', 'sha256')),
                      'Generic source differs')
        if index == 8:
            g.resolved_binding(inventory['sources'][1], path, h)
        if index == 9:
            h.require(bound['sha256'] == '6704cfdb14d1d4d0f1bc0b2431085350577c43f2ba6786ef281cf59a89dc438e',
                      'Original Fast/Nat audit source differs')
        sources.append({**bound, 'module': module, 'imports': imports,
                        'roots': row['roots'], 'raw_prints': row['raw_prints']})
        available.add(module)
    h.require(sum(len(row['roots']) for row in sources) == 67, 'Axiom root total differs')
    # Independently reapply the retained exact inverse for the scoped counter.
    scope = manifest['scoped_original_source_bridge']
    text = Path(sources[3]['path']).read_text()
    for edit in reversed(scope['source_edits']):
        start, end = edit['new_character_start'], edit['new_character_end']
        h.require(text[start:end] == edit['new'], 'Scoped counter inverse edit differs')
        text = text[:start] + edit['old'] + text[end:]
    original = ROOT / scope['original']['path']
    h.require(text.encode() == original.read_bytes()
              and sha(original) == scope['exact_inverse_sha256'], 'Source counter exact inverse failed')
    prep = p.preparation(manifest, [generic['compiler']] + generic['runtime_libraries'], h)
    controls = [{**row, 'role': 'generic_review_' + row['role']} for row in generic['controls']]
    controls += [{**h.binding(path), 'role': role, 'snapshot_required': True,
                  'retained_historical_reference': False} for role, path in OWN_CURRENT]
    controls += [{**h.binding(path), 'role': 'pinned_reader_' + str(index),
                  'snapshot_required': False, 'retained_historical_reference': True}
                 for index, path in enumerate(FIXED_READER_HASHES)]
    for index, row in enumerate(manifest['provenance']):
        path = ROOT / row['path']
        bound = g.resolved_binding(row, path, h)
        controls.append({**bound, 'role': 'retained_source_provenance_' + str(index),
                         'snapshot_required': False, 'retained_historical_reference': True})
    h.require(len(controls) == 47 and len({row['role'] for row in controls}) == 47,
              'Full source/control role census differs')
    g.verify(sources + controls + [generic['compiler']] + generic['runtime_libraries'], h)
    fingerprint = hashlib.sha256(json.dumps({'stage': 'source-bridge', 'sources': [
        {'module': row['module'], 'sha256': row['sha256']} for row in sources]},
        sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {'sources': sources, 'controls': controls, 'source_fingerprint': fingerprint,
            'compiler': generic['compiler'], 'runtime_libraries': generic['runtime_libraries'],
            'original_preparation': prep, 'manifest': manifest}


def audit_logs(row, result, allowed):
    out = Path(result['stdout']['path']).read_text()
    err = Path(result['stderr']['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [item['root'] for item in raw]
    return {'passed': names == row['roots'] and all(set(t['axioms']) <= allowed for t in raw)
            and not err and not pattern.sub('', out).strip(), 'raw_reports': raw,
            'required_count': len(row['roots']), 'observed_count': len(raw),
            'exact_ordered_names': names == row['roots'], 'stderr_empty': not err,
            'unparsed_stdout': pattern.sub('', out).strip()}


def run(args, plan, g, p, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('source-bridge-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Attempt or unchanged source closure already executed')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt, 'stage': 'source-bridge',
              'module_order': MODULES, 'root_module': MODULES[-1], 'source_fingerprint': plan['source_fingerprint'],
              'source_manifest': h.binding(MANIFEST), 'source_bindings': plan['sources'],
              'controls': plan['controls'], 'compiler': plan['compiler'], 'compiler_release': '4.35.0',
              'compiler_commit': 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'runtime_libraries': plan['runtime_libraries'], 'original_preparation': plan['original_preparation'],
              'execution_marker': None, 'prepared_original_objects': [], 'modules': [], 'artifacts': [],
              'required_axiom_report_count': 67, 'observed_axiom_report_count': 0,
              'accepted_axiom_report_count': 0, 'seconds': None, 'peak_child_rss_kib': 0,
              'object_search_path': str(build), 'constraints': {'cumulative_wall_seconds': 30,
                  'resident_memory_kib': 1048576, 'lean_memory_mib': 1024, 'compiler_threads': 1,
                  'default_heartbeats_and_recursion': True, 'cpu_affinity': []},
              'all_inputs_snapshots_objects_runtime_unchanged': False, 'exact_artifact_inventory': False,
              'all_selected_mathematical_sources_freshly_checked': False,
              'original_source_adapter_checked': False, 'compiled_experimental_imports_reused': False,
              'original_ADWH_preparation_used': True, 'source_count_proved': False, 'n16_target_proved': False,
              'native_evaluator_or_counter_executed': False, 'kernel_integration_implemented': False,
              'integrated_project_modified': False}
    h.save(report_path, report)
    began = None
    affinity = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings']:
            dest = frozen / rel(row['module'])
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            dest.chmod(0o444)
            row['snapshot'] = h.binding(dest)
        for row in report['controls']:
            if row['snapshot_required']:
                dest = inputs / Path(row['path']).relative_to(ROOT)
                dest.parent.mkdir(parents=True, exist_ok=True)
                with dest.open('xb') as stream:
                    stream.write(Path(row['path']).read_bytes())
                dest.chmod(0o444)
                row['snapshot'] = h.binding(dest)
        old_build = p.PREPARATION / 'attempts/originals-01/build'
        for row in plan['original_preparation']['artifacts']:
            dest = build / Path(row['path']).relative_to(old_build)
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            dest.chmod(0o444)
            copied = h.binding(dest)
            h.require(all(copied[k] == row[k] for k in ('bytes', 'sha256')), 'Original object copy differs')
            report['prepared_original_objects'].append({'source': row, 'copy': copied})
        snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
        h.require(len(snapshots) == 22, 'Snapshot census differs')
        g.verify(snapshots, h, readonly=True)
        for row in report['source_bindings'] + report['controls']:
            if 'snapshot' in row:
                h.require(all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')), 'Snapshot identity differs')
        marker.parent.mkdir(exist_ok=True)
        body = {'format': FORMAT, 'attempt': args.attempt, 'stage': 'source-bridge',
                'source_fingerprint': plan['source_fingerprint'], 'source_bindings': report['source_bindings'],
                'controls': report['controls'], 'compiler': report['compiler'],
                'runtime_libraries': report['runtime_libraries'],
                'prepared_original_objects': report['prepared_original_objects'],
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        with marker.open('x') as stream:
            stream.write(json.dumps(body, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(affinity)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for row in report['source_bindings']:
            module = row['module']
            (build / rel(module)).parent.mkdir(parents=True, exist_ok=True)
            cmd = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                   '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / rel(module, '.olean')),
                   '-i', str(build / rel(module, '.ilean')), str(rel(module))]
            result = h.child(cmd, frozen, env, attempt / (module + '.stdout.log'),
                             attempt / (module + '.stderr.log'), cpu, deadline)
            audit = audit_logs(row, result, g.ALLOWED)
            objects = all((build / rel(module, suffix)).is_file() for suffix in ('.olean', '.ilean'))
            passed = result['exit_code'] == 0 and result['within_limits'] and audit['passed'] and objects
            report['modules'].append({'module': module, **result, 'axiom_audit': audit,
                                      'required_objects_present': objects, 'status': 'passed' if passed else 'failed'})
            report['observed_axiom_report_count'] += audit['observed_count']
            report['accepted_axiom_report_count'] += audit['observed_count'] if passed else 0
            h.save(report_path, report)
            h.require(passed, 'Fresh source/axiom/resource gate failed: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            g.verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            h.require(len(snapshots) == 22, 'Incomplete final snapshots')
            g.verify(snapshots, h, readonly=True)
            g.verify([report['execution_marker']], h, readonly=True)
            g.verify([row[key] for row in report['modules'] for key in ('stdout', 'stderr')], h)
            g.verify(p.all_bindings(report['prepared_original_objects']), h)
            for row in report['source_bindings'] + report['controls']:
                if 'snapshot' in row:
                    h.require(all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')), 'Final snapshot mismatch')
            p.preparation(plan['manifest'], [report['compiler']] + report['runtime_libraries'], h)
            expected = {str(build / rel(module, suffix)) for module in MODULES + p.ORIGINALS
                        for suffix in ('.olean', '.ilean')}
            report['exact_artifact_inventory'] = {row['path'] for row in report['artifacts']} == expected
            report['all_inputs_snapshots_objects_runtime_unchanged'] = True
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, affinity)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((r['sampled_tree_and_wait4_peak_rss_kib'] for r in report['modules']), default=0)
        passed = (not any(k in report for k in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [r['module'] for r in report['modules']] == MODULES
                  and all(r['status'] == 'passed' for r in report['modules'])
                  and report['accepted_axiom_report_count'] == 67
                  and len(report['prepared_original_objects']) == 14
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_artifact_inventory'] and report['all_inputs_snapshots_objects_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['original_source_adapter_checked'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'seconds': report['seconds'],
                      'peak_rss_kib': report['peak_child_rss_kib'], 'accepted_roots': report['accepted_axiom_report_count'],
                      'observed_roots': report['observed_axiom_report_count'], 'report': h.binding(report_path)}, sort_keys=True))
    return 0 if report['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--attempt', default='source-bridge-01')
    parser.add_argument('--lean', type=Path, default=ROOT.parent / 'toolchains/lean-4.35.0-linux/bin/lean')
    args = parser.parse_args()
    if not re.fullmatch(r'source-bridge-(?:0[1-9]|[1-9][0-9])', args.attempt):
        raise ValueError('Expected source-bridge-01 through source-bridge-99')
    for path, expected in FIXED_READER_HASHES.items():
        if sha(path) != expected:
            raise ValueError('Reviewed source reader differs: ' + str(path))
    g, p = load(GENERIC, 'source_bridge_generic_checks'), load(PREP_READER, 'source_bridge_original_checks')
    for path, expected in g.FIXED.items():
        if sha(path) != expected:
            raise ValueError('Pinned enforcement/runtime input differs: ' + str(path))
    h, guard = g.load(g.HELPER, 'source_bridge_resources'), g.load(g.GUARD, 'source_bridge_guard')
    h.require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == g.ALLOWED, 'Resource contract differs')
    plan = preflight(args, g, p, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'modules': MODULES,
                          'required_roots': 67, 'prepared_original_objects': 14,
                          'source_fingerprint': plan['source_fingerprint']}, sort_keys=True))
        return 0
    with g.LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, g, p, h)


if __name__ == '__main__':
    raise SystemExit(main())
