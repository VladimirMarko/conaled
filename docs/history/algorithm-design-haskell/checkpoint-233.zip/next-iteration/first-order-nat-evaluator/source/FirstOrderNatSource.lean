import FirstOrderNat
import ADWH.Chapter15.QueensNatCounting

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Exact bridge to the existing Word16 source counter

This module imports the actual ADWH counter. It does not substitute a copied
numeric endpoint or assume a computed result. The import preparation and its
whole new mathematical closure must be disclosed by any execution protocol.
-/

namespace ADWH.Experiments.Chapter15.FirstOrderNat.SourceBridge

open ADWH.Chapter15.Queens.BitRepresentation

def sourceBranches (mask depth : Nat) (state : Masks) (fuel cursor : Nat) : Nat :=
  NatCounting.sumBits
    (fun bit => NatCounting.count mask depth (NatCounting.next state bit))
    fuel cursor

theorem source_equations (mask : Nat) :
    FiniteFold.Equations (spec 65536 mask 16)
      (NatCounting.count mask) (sourceBranches mask) := by
  refine { fold_zero := ?_, fold_succ := ?_, loop_zero := ?_, loop_succ := ?_ }
  · intro state
    simp only [NatCounting.count, spec, decide_eq_true_eq]
  · intro depth state
    simp only [NatCounting.count, spec, decide_eq_true_eq, sourceBranches,
      available, NatCounting.available]
  · intro depth state cursor
    rfl
  · intro depth state fuel cursor
    simp only [sourceBranches, NatCounting.sumBits, spec, decide_eq_true_eq,
      NatCounting.low, low, referenceNext, NatCounting.next]

theorem count_eq_source (mask depth left columns right : Nat) :
    count 65536 mask 16 depth left columns right =
      NatCounting.count mask depth (left, columns, right) := by
  simpa only [liftedCount] using
    FiniteFold.implementations_agree (spec 65536 mask 16)
      (liftedCount 65536 mask 16) (NatCounting.count mask)
      (liftedBranches 65536 mask 16) (sourceBranches mask)
      (equations 65536 mask 16) (source_equations mask)
      depth (left, columns, right)

theorem branches_eq_source
    (mask depth left columns right fuel cursor : Nat) :
    branches 65536 mask 16 depth left columns right fuel cursor =
      sourceBranches mask depth (left, columns, right) fuel cursor := by
  have hs := FiniteFold.branches_unique_of_equations (spec 65536 mask 16)
    (NatCounting.count mask) (sourceBranches mask) (source_equations mask)
    depth (left, columns, right) fuel cursor
  exact (branches_eq_loop 65536 mask 16 depth left columns right fuel cursor).trans hs.symm

/-- The exact original Word16 mask and both original budgets are retained. -/
def cqueens (n : Nat) : Nat :=
  evaluate 16 (mask n).toNat 16 0 0 0

theorem cqueens_eq_source (n : Nat) : cqueens n = NatCounting.cqueensNat n := by
  unfold cqueens evaluate NatCounting.cqueensNat
  exact count_eq_source (mask n).toNat 16 0 0 0

theorem cqueens_eq (n : Nat) :
    cqueens n = ADWH.Chapter15.Queens.BitRepresentation.cqueens n :=
  (cqueens_eq_source n).trans (NatCounting.cqueensNat_eq n)

#print axioms source_equations
#print axioms count_eq_source
#print axioms branches_eq_source
#print axioms cqueens_eq_source
#print axioms cqueens_eq

end ADWH.Experiments.Chapter15.FirstOrderNat.SourceBridge
