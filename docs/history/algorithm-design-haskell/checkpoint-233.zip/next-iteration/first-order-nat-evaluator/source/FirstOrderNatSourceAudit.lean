import FirstOrderNatSource

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/- Transitive axiom reports for the exact original Fast/Nat bridge sources. -/
#print axioms ADWH.Chapter15.Queens.BitRepresentation.sumBitsLoop_eq
#print axioms ADWH.Chapter15.Queens.BitRepresentation.countFast_eq
#print axioms ADWH.Chapter15.Queens.BitRepresentation.cqueensFast_eq
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.low_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.remainder_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.next_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.available_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.sumBits_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.count_refines
#print axioms ADWH.Chapter15.Queens.BitRepresentation.NatCounting.cqueensNat_eq
