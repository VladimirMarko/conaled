import FiniteFold

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# First-order natural-mask finite evaluation

The hot mutually recursive functions take three separate natural masks and
never take a continuation or construct a state product. Their ordinary Lean
termination proof uses the lexicographic ranks `(depth, 0)` and
`(depth, fuel + 1)`. Whether the compiler preserves this first-order shape is
a separate generated-code question.

All arithmetic is `Nat` arithmetic. In particular, subtraction saturates,
addition and multiplication do not wrap, the left component is reduced
modulo the supplied modulus, and the right component is not newly masked.
The modulus, mask, depth, and inner-loop budget are arbitrary naturals.
-/

namespace ADWH.Experiments.Chapter15.FirstOrderNat

@[inline] def low (modulus cursor : Nat) : Nat :=
  cursor &&& ((modulus - cursor) % modulus)

@[inline] def available (modulus mask left columns right : Nat) : Nat :=
  (modulus - 1 - (left ||| columns ||| right)) &&& mask

mutual
  /-- Evaluate one state, preserving the terminal test at depth zero. -/
  def count (modulus mask budget depth left columns right : Nat) : Nat :=
    match depth with
    | 0 => if columns = mask then 1 else 0
    | depth + 1 =>
        if columns = mask then 1 else
          branches modulus mask budget depth left columns right budget
            (available modulus mask left columns right)
  termination_by (depth, 0)
  decreasing_by
    exact Prod.Lex.left _ _ (Nat.lt_succ_self _)

  /-- Add one child per cursor occurrence. The parent masks are explicit
  arguments; the recursive child has the already smaller outer depth. -/
  def branches (modulus mask budget depth left columns right fuel cursor : Nat) : Nat :=
    match fuel with
    | 0 => 0
    | fuel + 1 =>
        if cursor = 0 then 0 else
          let bit := low modulus cursor
          count modulus mask budget depth
              (((left ||| bit) * 2) % modulus)
              (columns ||| bit) ((right ||| bit) >>> 1) +
            branches modulus mask budget depth left columns right fuel
              (cursor - bit)
  termination_by (depth, fuel + 1)
  decreasing_by
    all_goals
      apply Prod.Lex.right
      omega
end

/-- The width wrapper computes the modulus outside the recursive workers.
It does not assert that arbitrary input masks describe a valid board. -/
def evaluate (width mask depth left columns right : Nat) : Nat :=
  count (2 ^ width) mask width depth left columns right

theorem shiftLeft_one (value : Nat) : value <<< 1 = value * 2 := by
  simpa only [Nat.pow_one] using Nat.shiftLeft_eq value 1

theorem count_zero (modulus mask budget left columns right : Nat) :
    count modulus mask budget 0 left columns right =
      if columns = mask then 1 else 0 := by
  simp only [count]

theorem count_succ (modulus mask budget depth left columns right : Nat) :
    count modulus mask budget (depth + 1) left columns right =
      if columns = mask then 1 else
        branches modulus mask budget depth left columns right budget
          (available modulus mask left columns right) := by
  simp only [count]

theorem branches_zero (modulus mask budget depth left columns right cursor : Nat) :
    branches modulus mask budget depth left columns right 0 cursor = 0 := by
  simp only [branches]

theorem branches_succ
    (modulus mask budget depth left columns right fuel cursor : Nat) :
    branches modulus mask budget depth left columns right (fuel + 1) cursor =
      if cursor = 0 then 0 else
        count modulus mask budget depth
            (((left ||| low modulus cursor) * 2) % modulus)
            (columns ||| low modulus cursor)
            ((right ||| low modulus cursor) >>> 1) +
          branches modulus mask budget depth left columns right fuel
            (cursor - low modulus cursor) := by
  simp only [branches]

/- The following products and callbacks belong to the mathematical contract,
not to the worker definitions above. The reference transition deliberately
retains the original shift so that its replacement is proved explicitly. -/

abbrev Masks := Nat × Nat × Nat

def referenceNext (modulus : Nat) (state : Masks) (bit : Nat) : Masks :=
  (((state.1 ||| bit) <<< 1) % modulus,
    state.2.1 ||| bit, (state.2.2 ||| bit) >>> 1)

def spec (modulus mask budget : Nat) : FiniteFold.Spec Masks Nat Nat where
  terminal state := decide (state.2.1 = mask)
  terminalValue _ := 1
  start state := available modulus mask state.1 state.2.1 state.2.2
  empty cursor := decide (cursor = 0)
  head := low modulus
  rest cursor := cursor - low modulus cursor
  next := referenceNext modulus
  budget _ := budget

def liftedCount (modulus mask budget depth : Nat) (state : Masks) : Nat :=
  count modulus mask budget depth state.1 state.2.1 state.2.2

def liftedBranches (modulus mask budget depth : Nat) (state : Masks)
    (fuel cursor : Nat) : Nat :=
  branches modulus mask budget depth state.1 state.2.1 state.2.2 fuel cursor

theorem equations (modulus mask budget : Nat) :
    FiniteFold.Equations (spec modulus mask budget)
      (liftedCount modulus mask budget) (liftedBranches modulus mask budget) := by
  refine { fold_zero := ?_, fold_succ := ?_, loop_zero := ?_, loop_succ := ?_ }
  · intro state
    simp only [liftedCount, count_zero, spec, decide_eq_true_eq]
  · intro depth state
    simp only [liftedCount, liftedBranches, count_succ, spec, decide_eq_true_eq]
  · intro depth state cursor
    simp only [liftedBranches, branches_zero]
  · intro depth state fuel cursor
    simp only [liftedBranches, liftedCount, branches_succ, spec,
      decide_eq_true_eq, referenceNext, shiftLeft_one]

theorem count_eq_fold (modulus mask budget depth left columns right : Nat) :
    count modulus mask budget depth left columns right =
      FiniteFold.fold (spec modulus mask budget) depth (left, columns, right) := by
  simpa only [liftedCount] using
    FiniteFold.fold_unique_of_equations (spec modulus mask budget)
      (liftedCount modulus mask budget) (liftedBranches modulus mask budget)
      (equations modulus mask budget) depth (left, columns, right)

theorem branches_eq_loop
    (modulus mask budget depth left columns right fuel cursor : Nat) :
    branches modulus mask budget depth left columns right fuel cursor =
      FiniteFold.loop (spec modulus mask budget)
        (FiniteFold.fold (spec modulus mask budget) depth)
        (left, columns, right) fuel cursor := by
  simpa only [liftedBranches] using
    FiniteFold.branches_unique_of_equations (spec modulus mask budget)
      (liftedCount modulus mask budget) (liftedBranches modulus mask budget)
      (equations modulus mask budget) depth (left, columns, right) fuel cursor

theorem evaluate_eq_fold (width mask depth left columns right : Nat) :
    evaluate width mask depth left columns right =
      FiniteFold.fold (spec (2 ^ width) mask width) depth (left, columns, right) := by
  unfold evaluate
  exact count_eq_fold (2 ^ width) mask width depth left columns right

#print axioms shiftLeft_one
#print axioms count_zero
#print axioms count_succ
#print axioms branches_zero
#print axioms branches_succ
#print axioms equations
#print axioms count_eq_fold
#print axioms branches_eq_loop
#print axioms evaluate_eq_fold

end ADWH.Experiments.Chapter15.FirstOrderNat
