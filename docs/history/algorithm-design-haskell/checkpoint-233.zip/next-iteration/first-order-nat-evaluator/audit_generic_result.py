#!/usr/bin/env python3
"""Hash and parse immutable generic-01 evidence; never invoke Lean or a gate."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPORT = HERE / 'gate/attempts/generic-01/report.json'
REPORT_SHA = '49ce08dd3eb5560e42504e37b337bee721191edad62d2a124ecfa22db7619a47'
MODULES = ['FiniteFold', 'FirstOrderNat']
RAW = {
    'FiniteFold': ['loop_zero', 'loop_succ', 'fold_zero', 'fold_succ', 'canonical_equations',
                   'loop_unique_of_equations', 'fold_unique_of_equations',
                   'branches_unique_of_equations', 'implementations_agree'],
    'FirstOrderNat': ['shiftLeft_one', 'count_zero', 'count_succ', 'branches_zero',
                     'branches_succ', 'equations', 'count_eq_fold', 'branches_eq_loop', 'evaluate_eq_fold'],
}
ROOTS = {m: ['ADWH.Experiments.Chapter15.' + m + '.' + n for n in RAW[m]] for m in MODULES}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
CURRENT = ['runner', 'protocol', 'source_manifest', 'mathematical_design', 'baseline_c_review',
           'author_source_inventory', 'independent_source_review', 'independent_source_audit',
           'pending_source_adapter_not_compiled']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def strict_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'Duplicate JSON key: ' + key)
        out[key] = value
    return out


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': path.relative_to(WORK).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def census(value):
    rows = []
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            rows.append(value)
        for child in value.values():
            rows.extend(census(child))
    elif isinstance(value, list):
        for child in value:
            rows.extend(census(child))
    return rows


def audit(source_only=False):
    require(REPORT.is_file() and REPORT.stat().st_size == 32880 and sha(REPORT) == REPORT_SHA,
            'Different fixed generic report')
    r = read(REPORT)
    require(r['format'] == 'adwh-first-order-nat-generic-gate-v1' and r['status'] == 'passed'
            and r['stage'] == 'generic' and r['attempt'] == 'generic-01', 'Result scope differs')
    require(r['module_order'] == MODULES and r['root_module'] == 'FirstOrderNat'
            and r['required_prints'] == ROOTS and r['raw_source_print_identifiers'] == RAW,
            'Selected module/root identities differ')
    old_work = Path(r['source_bindings'][0]['path']).parents[3]
    old_toolchain = Path(r['compiler']['path']).parent.parent
    controls = r['controls']
    roles = {row['role']: row for row in controls}
    require(len(controls) == len(roles) == 39
            and [row['role'] for row in controls if row['snapshot_required']] == CURRENT
            and sum(row['retained_historical_reference'] for row in controls) == 30,
            'Control counts/roles differ')
    external = [row for row in controls if not Path(row['path']).is_relative_to(old_work)]
    require(len(external) == 4 and all(Path(row['path']).is_relative_to(old_toolchain / 'src/lean')
            for row in external), 'External source provenance differs')
    mirrors = {row['path']: HERE / 'recovery-provenance' /
               Path(row['path']).relative_to(old_toolchain / 'src/lean') for row in external}

    def local(path):
        path = Path(path)
        if path.is_relative_to(old_work):
            return WORK / path.relative_to(old_work)
        if source_only and str(path) in mirrors:
            return mirrors[str(path)]
        return path

    def verify(row, readonly=False):
        path = local(row['path'])
        require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Binding mismatch: ' + str(path))
        if readonly and not source_only:
            require(path.stat().st_mode & 0o222 == 0, 'Writable live snapshot/marker: ' + str(path))

    for row in r['source_bindings'] + controls:
        verify(row)
    for row in external:
        p = mirrors[row['path']]
        require(p.is_file() and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'],
                'Canonical provenance copy differs')
    snapshots = []
    physical = 0
    for row in r['source_bindings'] + [roles[role] for role in CURRENT]:
        snap = row['snapshot']
        require(all(snap[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot content differs')
        canonical = local(row['path']).relative_to(WORK).as_posix()
        expected = (HERE / 'gate/attempts/generic-01/source' / (row['module'] + '.lean')
                    if 'module' in row else HERE / 'gate/attempts/generic-01/inputs' / canonical)
        require(local(snap['path']) == expected, 'Snapshot role/path differs')
        if local(snap['path']).is_file():
            verify(snap, readonly=True)
            physical += 1
        else:
            require(source_only, 'Missing live snapshot')
        snapshots.append({'snapshot': local(snap['path']).relative_to(WORK).as_posix(),
                          'canonical': canonical, 'bytes': row['bytes'], 'sha256': row['sha256'],
                          'role': row.get('role', row.get('module'))})
    require(len(snapshots) == 11, 'Snapshot count differs')
    verify(r['source_manifest'])
    manifest = read(local(r['source_manifest']['path']))
    require(manifest['required_prints'] == ROOTS and manifest['module_order'] == MODULES
            and manifest['required_axiom_report_count'] == 18
            and manifest['prepared_objects'] == r['prepared_objects'] == [], 'Manifest scope differs')
    for selected, declared in zip(r['source_bindings'], manifest['sources']):
        require(declared['module'] == selected['module'] and declared['imports'] == selected['imports']
                and all(declared[k] == selected[k] for k in ['bytes', 'sha256'])
                and WORK / declared['path'] == local(selected['path']), 'Manifest source binding differs')
    require([row['imports'] for row in r['source_bindings']] == [['Init'], ['FiniteFold']], 'Import closure differs')
    audit_source = read(local(roles['independent_source_audit']['path']))
    bound = {row['path']: row for row in r['source_bindings'] + controls}
    require(len(audit_source['inputs']) == 32, 'Source audit input count differs')
    for row in audit_source['inputs']:
        historical_path = str((old_work / row['path']).resolve())
        require(historical_path in bound and all(row[k] == bound[historical_path][k] for k in ['bytes', 'sha256']),
                'Independent source review input not bound by this gate')
    require(audit_source['fully_qualified_roots']['FirstOrderNat'] == ROOTS['FirstOrderNat'], 'Review roots differ')

    verify(r['execution_marker'], readonly=True)
    marker = read(local(r['execution_marker']['path']))
    for key in ['format', 'attempt', 'stage', 'source_fingerprint', 'source_manifest', 'source_bindings',
                'controls', 'compiler', 'runtime_libraries']:
        require(marker[key] == r[key], 'Marker/report role differs: ' + key)
    fingerprint = hashlib.sha256(json.dumps({'stage': 'generic', 'sources':
        [{'module': row['module'], 'sha256': row['sha256']} for row in r['source_bindings']]},
        sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(r['source_fingerprint'] == fingerprint and Path(r['execution_marker']['path']).name ==
            'generic-' + fingerprint + '.json', 'Fingerprint/marker differs')
    pin = read(local(roles['toolchain_pin']['path']))
    require(r['compiler_release'] == pin['version'] == '4.35.0'
            and r['compiler_commit'] == pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and all(r['compiler'][k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']), 'Compiler pin differs')
    runtime_reference = read(local(roles['pinned_runtime_reference_report']['path']))
    require(len(r['runtime_libraries']) == 5 and
            {Path(x['path']).name: (x['bytes'], x['sha256']) for x in r['runtime_libraries']} ==
            {Path(x['path']).name: (x['bytes'], x['sha256']) for x in runtime_reference['controls']
             if x['path'].endswith('.so')}, 'Runtime identities differ')
    if not source_only:
        for row in [r['compiler'], *r['runtime_libraries'], *r['artifacts']]:
            verify(row)

    old_build = str(old_work / HERE.relative_to(WORK) / 'gate/attempts/generic-01/build')
    require(r['object_search_path'] == old_build and [x['module'] for x in r['modules']] == MODULES,
            'Fresh compilation order/path differs')
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    observed = []
    module_results = []
    for row in r['modules']:
        name = row['module']
        expected = [r['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true',
                    '-DElab.async=false', '-o', old_build + '/' + name + '.olean',
                    '-i', old_build + '/' + name + '.ilean', name + '.lean']
        require(row['command'] == expected and row['exit_code'] == 0 and row['status'] == 'passed'
                and row['within_limits'] and row['limit_exceeded'] is None and row['required_objects_present'],
                'Compiler outcome/config differs')
        verify(row['stdout']); verify(row['stderr'])
        out, err = local(row['stdout']['path']).read_text(), local(row['stderr']['path']).read_text()
        raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
               for root, axes in pattern.findall(out)]
        require(not err and not pattern.sub('', out).strip() and [x['root'] for x in raw] == ROOTS[name]
                and all(set(x['axioms']) <= ALLOWED for x in raw), 'Raw theorem evidence differs')
        require(raw == row['axiom_audit']['raw_reports'] and row['axiom_audit']['passed'], 'Recorded audit differs')
        observed.extend(raw)
        module_results.append({'module': name, 'wall_seconds': row['seconds'], 'cpu_seconds': row['cpu_seconds'],
                               'peak_rss_kib': row['sampled_tree_and_wait4_peak_rss_kib'], 'accepted_roots': len(raw)})
    require(all(r[key] == len(observed) == 18 for key in ['required_axiom_report_count',
            'observed_axiom_report_count', 'observed_unique_axiom_root_count', 'accepted_axiom_report_count']),
            'Acceptance counts differ')
    require(len(r['artifacts']) == 4 and {x['path'] for x in r['artifacts']} ==
            {old_build + '/' + name + suffix for name in MODULES for suffix in ['.olean', '.ilean']}
            and r['exact_build_artifact_inventory'], 'Four fresh object inventory differs')
    c = r['constraints']
    require(c['cumulative_wall_seconds'] == 30 and c['resident_memory_kib'] == 1048576
            and c['lean_memory_mib'] == 1024 and c['compiler_threads'] == 1
            and c['default_heartbeats_and_recursion'] and len(c['cpu_affinity']) == 1
            and 0 <= r['seconds'] <= 30 and r['peak_child_rss_kib'] ==
            max(x['peak_rss_kib'] for x in module_results) <= 1048576, 'Resource bounds differ')
    for key in ['all_selected_mathematical_sources_freshly_checked', 'all_sources_snapshots_controls_runtime_unchanged',
                'complete_first_order_generic_proof_checked']:
        require(r[key] is True, 'Incomplete gate flag: ' + key)
    for key in ['source_adapter_checked', 'source_count_proved', 'n16_target_proved', 'native_evaluator_or_counter_executed',
                'kernel_integration_implemented', 'compiled_experimental_imports_reused',
                'original_ADWH_imports_used', 'integrated_project_modified']:
        require(r[key] is False, 'Scope enlarged: ' + key)
    rb, mb = census(r), census(marker)
    distinct = lambda xs: len({(x['path'], x['bytes'], x['sha256']) for x in xs})
    return {'format': 'adwh-first-order-generic-saved-result-audit-v1', 'status': 'passed_saved_evidence_audit',
        'audit_mode': 'source_only' if source_only else 'live_bindings',
        'audit_execution': 'Saved file parsing/hashing only; no compiler, generator, counter or gate execution.',
        'authorship': {**r['authorship'], 'independent_gate_and_saved_result_reviewer': 'regression_audit'},
        'report': binding(REPORT), 'source_fingerprint': fingerprint,
        'report_binding_occurrences': len(rb), 'report_distinct_binding_identities': distinct(rb),
        'marker_binding_occurrences': len(mb), 'marker_distinct_binding_identities': distinct(mb),
        'module_results': module_results, 'required_roots': 18, 'observed_roots': 18, 'accepted_roots': 18,
        'raw_axiom_reports': observed, 'cumulative_seconds': r['seconds'], 'peak_rss_kib': r['peak_child_rss_kib'],
        'current_controls': 9, 'historical_references': 30, 'source_count': 2, 'snapshot_count': 11,
        'snapshot_bytes': sum(x['bytes'] for x in snapshots), 'snapshot_mappings': snapshots,
        'physical_snapshots_verified': physical, 'unique_superseded_inputs': 0,
        'external_source_mappings': [{'recorded_path': x['path'],
            'canonical': mirrors[x['path']].relative_to(WORK).as_posix(), 'bytes': x['bytes'], 'sha256': x['sha256']}
            for x in external], 'runtime_files_rehashed': not source_only, 'compiled_artifacts_rehashed': not source_only,
        'filesystem_readonly_mode_required': not source_only, 'filesystem_readonly_mode_checked': not source_only,
        'artifacts': r['artifacts'], 'source_adapter_checked': False, 'native_representation_checked': False,
        'native_execution_certified': False, 'numerical_queens_equality_proved': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(audit(args.source_only), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
