#!/usr/bin/env python3
"""Audit saved actual-source evidence only; never import a gate or invoke Lean."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
ATTEMPT = HERE / 'source-bridge-gate/attempts/source-bridge-01'
REPORT = ATTEMPT / 'report.json'
REPORT_SHA = '9413510d8e533781a89e2b00419f8d669b1e2a1f96950e71a3281e083510d29f'
MANIFEST_SHA = 'e63c13e2c263a75902c2829622c1d3720b2d67befe1c63a951a597911ffe8f3b'
PREP_SHA = '2a8670767de8261255e65b92ed69de85b015669a86cae7a854c26c7d166f2c14'
MODULES = ['SymbolicWord16Core', 'SymbolicWord16Recurrence',
    'ADWH.Chapter15.QueensBitsPrimitives', 'ADWH.Chapter15.QueensBitCounting',
    'ADWH.Chapter15.QueensFastCounting', 'ADWH.Chapter15.QueensNatCounting',
    'FiniteFold', 'FirstOrderNat', 'FirstOrderNatSource', 'FirstOrderNatSourceAudit']
ORIGINALS = ['ADWH.Chapter01.Lists', 'ADWH.Chapter01.Permutations',
    'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensVariants',
    'ADWH.Chapter15.QueensSearch', 'ADWH.Chapter15.QueensBitRepresentation',
    'ADWH.Chapter15.QueensBitMoves']
ROOT_COUNTS = [4, 13, 7, 10, 0, 0, 9, 9, 5, 10]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': path.relative_to(WORK).as_posix(),
            'bytes': path.stat().st_size, 'sha256': sha(path)}


def census(value):
    rows = []
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            rows.append(value)
        for child in value.values():
            rows.extend(census(child))
    elif isinstance(value, list):
        for child in value:
            rows.extend(census(child))
    return rows


def rel(module, suffix='.lean'):
    return Path(*module.split('.')).with_suffix(suffix)


def audit(source_only=False):
    require(REPORT.stat().st_size == 107309 and sha(REPORT) == REPORT_SHA,
            'Different fixed source-bridge report')
    r = read(REPORT)
    require(r['format'] == 'adwh-first-order-nat-actual-source-gate-v1'
            and r['stage'] == 'source-bridge' and r['attempt'] == 'source-bridge-01'
            and r['status'] == 'passed' and r['module_order'] == MODULES
            and r['root_module'] == MODULES[-1], 'Result boundary differs')
    old_work = Path(r['source_bindings'][6]['path']).parents[3]
    old_toolchain = Path(r['compiler']['path']).parent.parent
    roles = {x['role']: x for x in r['controls']}
    current = [x for x in r['controls'] if x['snapshot_required']]
    require(len(roles) == len(r['controls']) == 47 and len(current) == 12
            and sum(x['retained_historical_reference'] for x in r['controls']) == 35,
            'Control census differs')
    recovery = read(HERE / 'GENERIC-SNAPSHOT-RECOVERY.json')
    external = recovery['external_source_mappings']
    require(len(external) == 4, 'External source recovery census differs')
    mirrors = {x['recorded_path']: WORK / x['canonical'] for x in external}
    actual_external = [x for x in r['controls'] if not Path(x['path']).is_relative_to(old_work)]
    require({(x['path'], x['bytes'], x['sha256']) for x in actual_external} ==
            {(x['recorded_path'], x['bytes'], x['sha256']) for x in external}
            and all(Path(x['path']).is_relative_to(old_toolchain / 'src/lean')
                    for x in actual_external), 'External source provenance differs')

    def local(path):
        value = Path(path)
        if value.is_relative_to(old_work):
            return WORK / value.relative_to(old_work)
        if source_only and str(value) in mirrors:
            return mirrors[str(value)]
        return value

    aliases = {}
    readonly = {r['execution_marker']['path']}
    for row in r['source_bindings'] + r['controls'] + r['original_preparation']['sources']:
        if 'snapshot' in row:
            snap = row['snapshot']
            require(all(snap[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot identity differs')
            aliases[snap['path']] = row['path']
            if row in r['source_bindings'] + r['controls']:
                readonly.add(snap['path'])
    runtime = [r['compiler'], *r['runtime_libraries']]
    skip = {x['path'] for x in runtime + r['artifacts'] + r['original_preparation']['artifacts']}
    seen = {}

    def verify(row, enforce_readonly=False):
        identity = row['bytes'], row['sha256']
        require(row['path'] not in seen or seen[row['path']] == identity,
                'Conflicting identity for one path')
        seen[row['path']] = identity
        if source_only and row['path'] in skip:
            return
        path = local(row['path'])
        if source_only and not path.is_file() and row['path'] in aliases:
            path = local(aliases[row['path']])
        require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Binding mismatch: ' + str(path))
        # ZIPs may normalize modes. Live evidence alone must retain read-only modes.
        if not source_only and (enforce_readonly or row['path'] in readonly):
            require(path.stat().st_mode & 0o222 == 0, 'Writable live snapshot/marker: ' + str(path))

    for row in census(r):
        verify(row)
    for row in external:
        path = WORK / row['canonical']
        require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Missing/different retained standard-library source')
    manifest_path = local(r['source_manifest']['path'])
    require(sha(manifest_path) == MANIFEST_SHA, 'Different source/root contract')
    manifest = read(manifest_path)
    require(manifest['module_order'] == MODULES and manifest['required_axiom_report_count'] == 67
            and manifest['prepared_original_objects'] == 14
            and manifest['new_mathematical_objects_all_fresh'] and manifest['no_numeral_evaluation'],
            'Manifest scope differs')
    snapshots = []
    for row in r['source_bindings'] + current:
        canonical = local(row['path']).relative_to(WORK).as_posix()
        snap = row['snapshot']
        expected = ATTEMPT / 'source' / rel(row['module']) if 'module' in row else ATTEMPT / 'inputs' / canonical
        require(local(snap['path']) == expected, 'Snapshot role/path differs')
        snapshots.append({'snapshot': expected.relative_to(WORK).as_posix(), 'canonical': canonical,
            'bytes': row['bytes'], 'sha256': row['sha256'], 'role': row.get('role', row.get('module'))})
    require(len(snapshots) == 22, 'Snapshot count differs')
    for declared, row, n in zip(manifest['sources'], r['source_bindings'], ROOT_COUNTS):
        require(WORK / declared['path'] == local(row['path']) and all(declared[k] == row[k]
                for k in ['bytes', 'sha256', 'module', 'imports', 'roots', 'raw_prints'])
                and len(row['roots']) == n, 'Fresh source inventory differs')
    scope = manifest['scoped_original_source_bridge']
    text = local(r['source_bindings'][3]['path']).read_text()
    for edit in reversed(scope['source_edits']):
        a, b = edit['new_character_start'], edit['new_character_end']
        require(text[a:b] == edit['new'], 'Scoped source inverse mismatch')
        text = text[:a] + edit['old'] + text[b:]
    original = WORK / scope['original']['path']
    require(text.encode() == original.read_bytes() and sha(original) == scope['exact_inverse_sha256'],
            'Original source counter inverse differs')
    endpoint = 'ADWH.Experiments.Chapter15.FirstOrderNat.SourceBridge.cqueens_eq'
    require(r['source_bindings'][8]['roots'][-1] == endpoint and
            manifest['source_adapter_statement']['name'] == endpoint and
            manifest['source_adapter_statement']['statement'] == 'theorem cqueens_eq (n : Nat) :\n'
            '    cqueens n = ADWH.Chapter15.Queens.BitRepresentation.cqueens n',
            'Original cqueens endpoint differs')

    marker = read(local(r['execution_marker']['path']))
    for key in ['format', 'stage', 'attempt', 'source_fingerprint', 'source_bindings', 'controls',
                'compiler', 'runtime_libraries', 'prepared_original_objects']:
        require(marker[key] == r[key], 'Marker/report role mismatch: ' + key)
    for row in census(marker):
        verify(row)
    fingerprint = hashlib.sha256(json.dumps({'stage': 'source-bridge', 'sources': [
        {'module': row['module'], 'sha256': row['sha256']} for row in r['source_bindings']]},
        sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(r['source_fingerprint'] == fingerprint and Path(r['execution_marker']['path']).name ==
            'source-bridge-' + fingerprint + '.json', 'Source-keyed permanent marker differs')
    pin = read(local(roles['generic_review_toolchain_pin']['path']))
    require(r['compiler_release'] == pin['version'] == '4.35.0' and
            r['compiler_commit'] == pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and all(r['compiler'][k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']),
            'Compiler pin differs')
    reference = read(local(roles['generic_review_pinned_runtime_reference_report']['path']))
    require(len(r['runtime_libraries']) == 5 and
            {Path(x['path']).name: (x['bytes'], x['sha256']) for x in r['runtime_libraries']} ==
            {Path(x['path']).name: (x['bytes'], x['sha256']) for x in reference['controls']
             if x['path'].endswith('.so')}, 'Runtime-only reference differs')

    prep = r['original_preparation']
    require(prep['report']['sha256'] == PREP_SHA and prep['module_order'] == ORIGINALS,
            'Original-only preparation identity differs')
    old = read(local(prep['report']['path']))
    require(old['status'] == 'passed' and old['module_order'] == ORIGINALS
            and old['all_7_original_imports_freshly_compiled']
            and old['exact_original_only_object_inventory']
            and not old['compiled_new_mathematical_inputs'] and not old['compiled_imports_reused'],
            'Original-only preparation boundary differs')
    for key, original_key in [('sources', 'source_bindings'), ('controls', 'controls'),
            ('runtime', 'runtime'), ('artifacts', 'artifacts'), ('source_manifest', 'source_manifest'),
            ('execution_marker', 'execution_marker')]:
        require(prep[key] == old[original_key], 'Selected original preparation evidence differs')
    for row in census(old):
        verify(row)
    require(len(old['modules']) == 7 and len(prep['artifacts']) == 14
            and 0 <= old['cumulative_seconds'] <= 30 and old['peak_child_rss_kib'] <= 1048576,
            'Original preparation resources/count differs')
    for row in old['modules']:
        require(row['exit_code'] == 0 and row['status'] == 'passed' and row['within_limits']
                and row['limit_exceeded'] is None and row['required_objects_present']
                and not local(row['stdout']['path']).read_text()
                and not local(row['stderr']['path']).read_text(), 'Original import outcome differs')
    require(len(r['prepared_original_objects']) == 14 and
            {x['source']['path'] for x in r['prepared_original_objects']} ==
            {x['path'] for x in prep['artifacts']}, 'Original copied-object set differs')
    for row in r['prepared_original_objects']:
        require(all(row['source'][k] == row['copy'][k] for k in ['bytes', 'sha256'])
                and local(row['copy']['path']) == ATTEMPT / 'build' /
                Path(row['source']['path']).relative_to(Path(old['object_search_path'])),
                'Original object copy identity/path differs')
    build = str(old_work / ATTEMPT.relative_to(WORK) / 'build')
    require(r['object_search_path'] == build and [x['module'] for x in r['modules']] == MODULES,
            'Fresh compilation order/search path differs')
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    observed, results = [], []
    for selected, row in zip(r['source_bindings'], r['modules']):
        module = row['module']
        command = [r['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
            '-DwarningAsError=true', '-DElab.async=false', '-o', build + '/' + str(rel(module, '.olean')),
            '-i', build + '/' + str(rel(module, '.ilean')), str(rel(module))]
        require(row['command'] == command and row['status'] == 'passed' and row['exit_code'] == 0
                and row['within_limits'] and row['limit_exceeded'] is None and row['required_objects_present'],
                'Compiler outcome or exact configuration differs')
        out, err = local(row['stdout']['path']).read_text(), local(row['stderr']['path']).read_text()
        raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
               for root, axes in pattern.findall(out)]
        require(not err and not pattern.sub('', out).strip()
                and [x['root'] for x in raw] == selected['roots']
                and all(set(x['axioms']) <= ALLOWED for x in raw)
                and row['axiom_audit']['passed'] and raw == row['axiom_audit']['raw_reports'],
                'Raw theorem reports or accepted roots differ')
        observed.extend(raw)
        results.append({'module': module, 'accepted_roots': len(raw), 'seconds': row['seconds'],
                        'peak_rss_kib': row['sampled_tree_and_wait4_peak_rss_kib']})
    require(len({x['root'] for x in observed}) == len(observed) == 67 and all(r[k] == 67 for k in
            ['required_axiom_report_count', 'observed_axiom_report_count', 'accepted_axiom_report_count']),
            'Root totals differ')
    artifact_paths = {build + '/' + str(rel(module, suffix)) for module in MODULES + ORIGINALS
                      for suffix in ['.olean', '.ilean']}
    require(len(r['artifacts']) == 34 and {x['path'] for x in r['artifacts']} == artifact_paths
            and r['exact_artifact_inventory'], 'Fresh/original artifact inventory differs')
    c = r['constraints']
    require(c['cumulative_wall_seconds'] == 30 and c['resident_memory_kib'] == 1048576
            and c['lean_memory_mib'] == 1024 and c['compiler_threads'] == 1
            and c['default_heartbeats_and_recursion'] and len(c['cpu_affinity']) == 1
            and 0 <= r['seconds'] <= 30 and r['peak_child_rss_kib'] ==
            max(x['peak_rss_kib'] for x in results) <= 1048576, 'Resource contract differs')
    for key in ['all_inputs_snapshots_objects_runtime_unchanged',
                'all_selected_mathematical_sources_freshly_checked', 'original_source_adapter_checked',
                'original_ADWH_preparation_used']:
        require(r[key] is True, 'Incomplete accepted result')
    for key in ['compiled_experimental_imports_reused', 'source_count_proved', 'n16_target_proved',
                'native_evaluator_or_counter_executed', 'kernel_integration_implemented', 'integrated_project_modified']:
        require(r[key] is False, 'Unsupported enlarged claim')
    require(not any(k in r for k in ['failure', 'postcheck_failure', 'affinity_restore_failure']),
            'Recorded execution failure')
    distinct = lambda xs: len({(x['path'], x['bytes'], x['sha256']) for x in xs})
    return {'format': 'adwh-first-order-source-saved-result-audit-v1', 'status': 'passed_saved_evidence_audit',
        'audit_mode': 'source_only' if source_only else 'live_bindings',
        'audit_execution': 'Saved file parsing/hashing only; no gate imports, preflight, compiler or counter.',
        'authorship': {'source_author': 'counting_route', 'mathematical_reviewer': 'regression_audit',
            'gate_author_and_executor': 'root', 'gate_and_saved_result_reviewer': 'validity_contracts',
            'reviewer_authored_FiniteFold': True},
        'report': binding(REPORT), 'source_fingerprint': fingerprint,
        'report_binding_occurrences': len(census(r)), 'report_distinct_binding_identities': distinct(census(r)),
        'marker_binding_occurrences': len(census(marker)), 'marker_distinct_binding_identities': distinct(census(marker)),
        'original_preparation_binding_occurrences': len(census(old)),
        'original_preparation_distinct_binding_identities': distinct(census(old)),
        'verified_distinct_binding_paths': len(seen), 'current_controls': 12, 'historical_references': 35,
        'sources': 10, 'fresh_objects': 20, 'original_object_copies': 14, 'artifacts': r['artifacts'],
        'snapshot_count': len(snapshots), 'snapshot_bytes': sum(x['bytes'] for x in snapshots),
        'canonical_snapshot_file_count': len({x['canonical'] for x in snapshots}),
        'snapshot_mappings': snapshots, 'external_source_mappings': external,
        'physical_snapshots_verified': sum((WORK / x['snapshot']).is_file() for x in snapshots),
        'unique_superseded_inputs': 0, 'filesystem_readonly_mode_required': not source_only,
        'filesystem_readonly_mode_checked': not source_only,
        'compiler_runtime_and_objects_rehashed': not source_only,
        'raw_axiom_reports': observed, 'required_roots': 67, 'observed_roots': 67, 'accepted_roots': 67,
        'axiom_histogram': dict(Counter(','.join(sorted(x['axioms'])) or '(none)' for x in observed)),
        'module_results': results, 'seconds': r['seconds'], 'peak_rss_kib': r['peak_child_rss_kib'],
        'original_source_adapter_checked': True, 'native_program_executed': False,
        'external_checker_implemented_by_this_gate': False, 'numeral_equality_proved': False,
        'n16_target_proved': False, 'kernel_integration_implemented': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(audit(args.source_only), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
