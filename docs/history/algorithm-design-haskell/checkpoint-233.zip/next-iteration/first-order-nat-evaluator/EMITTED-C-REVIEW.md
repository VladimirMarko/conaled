# Source inspection of the exact-source native baseline

This is source inspection, not an allocation profile, timing experiment or
new execution. The inspected C is the first native probe artifact:

`../native-nat-evaluator-probe/emitted-c/NativeNatProbe.c`

It has 32,305 bytes and SHA256
`c67955234da2bad76b8e169178285fcad115356b6a7d3fb46bb952eee89282ec`.
The actual run report has SHA256
`094ba1ca38f8ec8f8b096d3fec0e0c80f79865a33a89e37afcba870be45572b4`.
The associated source is the exact copied safe-Lean Nat counter, not a C++
algorithm variant. Complete bindings appear in `SOURCE-INVENTORY.json`.

## Actual operations visible in this artifact

| C location / function | Source-backed observation | Limitation |
| --- | --- | --- |
| `NatCounting_count`, around 392 | The positive-depth, nonterminal branch calls `lean_alloc_closure`, capturing the state, mask and smaller depth. | This is a control-flow-specific allocation, not a claim about terminal states. |
| `NatCounting_sumBits`, around 309 | Each nonempty, positive-fuel branch calls the callback with `lean_apply_1`, then recursively sums the remainder. | No measured fraction of runtime is attributed to dispatch. |
| `NatCounting_next`, around 145–248 | State is a nested pair. Both pair nodes have exclusivity/reuse tests and `lean_alloc_ctor(0,2,0)` fallback paths. | It would be incorrect to say both constructors allocate on every transition; no allocation trace was collected. |
| `NatCounting_next`, around 195 | The left component calls `lean_nat_shiftl` by one, then `lean_nat_mod` by 65536. | A source-level call identifies an operation, not its measured cost. |
| `main`, lines 559–560 | `lean_io_mono_nanos_now` precedes the `cqueensNat` call. Formatting, writing and flushing follow before the end clock. | The internal interval includes count formatting/output; the whole child measurement remains separate. |

The report records whole-probe wall time 1.8205765509992489 seconds and
peak 488640 KiB, including Lean code generation, native compilation and all
three fixed cases. The internal count/format/write/flush intervals were
248138 ns, 4427533 ns and 105247886 ns for 8, 10 and 12 respectively. These are
reported observations, not a forecast for 16 and not proof of the reported
numeric counts.

## Native Nat arithmetic gives a precise second transformation

Pinned source in
`../packed-row-descriptor-cache/primitive-evidence/src__runtime__object.cpp`
shows `lean_nat_shiftl` at 1573 onward. Except for a zero shifted value, it
creates an `mpz` input, invokes `mul2k`, and converts the result back with
`mpz_to_nat`. The retained `mpz.cpp` contains the GMP and fallback
implementations; the GMP branch uses `mpz_mul_2exp` and constructors with
`mpz_init_set_*`/`mpz_add`. This is a multiprecision code path even when the
mathematical value fits a tagged Nat. It does not establish a heap-byte
count or measured runtime cost.

By contrast, the pinned `lean.h` implementation of `lean_nat_mul`, around
1678, handles two tagged scalar inputs directly, checks that the product
fits, and otherwise calls its arbitrary-precision overflow/big-input
fallback. Replacing `x <<< 1` by `x * 2` can therefore avoid that shift
path while preserving all-Nat semantics. The exact source theorem is
`Nat.shiftLeft_eq x 1`, simplified using `Nat.pow_one`; it requires no
fixed-width bound. This is an explicitly selected additional transformation
alongside flattening the state and replacing the callback loop.

The candidate's eventual emitted C must confirm that native multiplication
is used at the intended transition and that its well-founded mutual
definition has not reintroduced another dynamic representation. No
speedup, memory reduction or n16 feasibility follows from this inspection
alone.
