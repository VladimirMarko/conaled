# Complete cached120 result and next work

Root executed this independently reviewed complete selection once. The gate
FAILED at the common wall deadline: 30.255617265000183 seconds measured in
total, peak group/child RSS 910000 KiB. The source-policy key is permanently
consumed:
`785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e`.

The report is207153bytes, SHA256
`78f26ceecef3ee2345fcae825faf9c3c2c9adc2a102629e475a788443160cc11`.

| Fresh module | Seconds | Accepted reports | Outcome |
| --- | ---: | ---: | --- |
| Core with restored observer law | 12.757794695000484 | 1 | Passed |
| Cached with proof sharing | 12.655750765999983 | 25 | Passed |
| Corrected Stable | 0.43998461900082475 | 20 | Passed |
| Corrected Helper | 0.7112289689994213 | 25 | Passed |
| Syntax correspondence | 3.4273768519997247 | 0 | Killed at common deadline |
| BulkBound | — | 0 | Not reached |
| LiteralForward | — | 0 | Not reached |

The first71 reports were accepted. Syntax produced no stdout or stderr and
neither required object; its explicit limit event is wall_time, exit -9.
There is no diagnosed Syntax proof error from this attempt, and no completed
timing for that module. All selected sources, controls, runtime identities
and snapshots remained unchanged. The complete expected artifact inventory
was not produced. No larger-closure, syntax, bulk, literal, installed-kernel,
whole-query or numeral acceptance follows from this failed attempt.

The recovery map independently matches202actual frozen source/control files
to their canonical identities, plus ten raw logs and the permanent marker.
Its SHA256 is
`708025b127d835bbfc9f832536926f6bf69acd56e6752c77610c7c5542e6b275`.
Duplicate snapshots and build objects need not be retained in checkpoints.
This metadata map is not a complete saved-result reader, which remains pending.

The selected base costs about26.6seconds before Syntax. The proof-sharing
variant did not provide enough headroom for this complete closure. The next
selection needs substantive source/proof work, not a timing retry, raised
limits, omitted failed owner or prepared imports. Current source-only work
investigates exact presentation-only Core omissions and a shared zero-count
case in the bulk-substitution proof. Actual computation, fields, lookup
guards, all relevant fold laws and theorem interfaces must remain explicit.
Those candidates have no measured improvement or acceptance yet.

Arithmetic17 and GeneratedScope7 are separately source-reviewed follow-ons.
They are not accepted by this gate. Actual beta/delta and Nat iota forward
lemmas are being developed with returned-state threading and explicit real
helper/cache premises. All fixed resource, axiom and no-retry rules continue.
