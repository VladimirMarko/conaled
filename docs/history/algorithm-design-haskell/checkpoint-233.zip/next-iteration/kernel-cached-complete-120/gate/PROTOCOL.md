# Complete fresh cached 120-report gate

Status: authored source/control selection, frozen for independent root control review.
The gate author has not executed this runner, a preflight, Lean, an exporter,
a native mathematical program, a retained generator, or a saved-evidence reader.
Only root may perform the independent control review, preflight and single
fresh complete run.

## Selected closure

| Order | Physical module | Reports | Ordinary outputs |
| --- | --- | ---: | ---: |
| 1 | KernelCompactCore | 1 | 2 |
| 2 | KernelCachedForward | 25 | 2 |
| 3 | KernelCachedStableForward | 20 | 2 |
| 4 | KernelCachedHelperDirect | 25 | 2 |
| 5 | KernelCachedSyntaxCorrespondence | 11 | 2 |
| 6 | KernelCachedBulkBound | 30 | 2 |
| 7 | KernelCachedLiteralForward | 8 | 2 |
| Total | Seven fresh physical owners | 120 | 14 |

The exact source paths, byte counts, hashes, imports, ordered raw print names,
fully qualified expected roots and outputs are in source-manifest.json.
The selection has 638,544 Lean source bytes, 26 distinct upstream ownership
origins and seven project origins: 33 logical origins and 35 full-origin or
supplemental source segments. BulkBound's six exact upstream proof intervals
supplement existing Expr/ExprOps ownership inside one new project leaf; they
are disclosed separately and do not create duplicate imported owners.
LiteralForward imports StableForward directly. The dependency check allows
only an earlier physical owner or the named SDK Init/Std imports.

All seven owners are fresh in this run. The accepted predecessor's objects
are context only and cannot satisfy any dependency. The full alternative
ExprOpsC source is correspondence context for the same existing cached origin,
not a second selected physical source. No export, native counter, generated
program, installed optimizer, or integration build is selected.

## Why this is a new selection

The accepted four-module closure passed 70 reports in its recorded
29.206988490001095-second interval. Its source identities, independent
reviews, manifest, runner, permanent marker and report remain frozen.
It did not include the observer law, Syntax, BulkBound or LiteralForward.

This new complete selection combines the exact independently reviewed
two-law Core observer restoration, the complete cached ExprOpsC proof-sharing
variant, the accepted corrected Stable and Helper sources, the repaired
Syntax leaf, the separately reviewed BulkBound supplement and the
independently reviewed LiteralForward leaf. This is new mathematical source
work under the same resource policy. No budget-fit or speedup claim is made.
Changing timing conditions, metadata, controls, directory names or attempt
labels does not authorize a retry of an unchanged mathematical closure.

## Independent review scopes

The original cached assembly review retains 27 inputs. Its correction
review retains 18. The original Stable review retains 17 and its correction
review 12. The original Helper review retains 25 and the diagnosed correction
review 18. These six scopes remain at their original source identities.

Four additional scopes are bound individually: observer/Syntax, 33 inputs;
cached proof sharing, 26; BulkBound, 119; LiteralForward, 16. Their frozen
author inventories retain 104, 129, 116 and 15 inputs respectively.
The scopes are not combined by rewriting any old review. In particular,
BulkBound and LiteralForward retain their earlier cached owner context;
the separately reviewed exact proof-sharing overlay is what selects the
new current cached owner.

The current review and inventory lists are embedded as separate named scopes
in the complete manifest. Every listed input is bound as a selected source
or a control/context file and receives a read-only attempt snapshot.
All exact raw full origins, supplemental source inputs, predecessor
correspondence layers, disclosure files and review evidence are included.
Binding a historical source or report does not compile it or promote a
conditional historical proposition into a stronger current one.

## Literal source and overlay checks before compilation

The runner reconstructs the historical 21-origin Core assembly, its 24
legacy command/visibility edits and its four ordinary-field edits. It
separately reconstructs the nine-segment cached assembly, including both
exact helper supplements, five complete upstream cached units and the
Runs/Licensed project sources. All inherited raw origins and omissions
remain bound.

It reconstructs both directions of the existing cached project correction,
the Stable correction, the initial Helper empty-map correction, and the
diagnosed 16-span Helper correction. The five preserved initial Helper
draft files retain their exact old identities.

The new observer/Syntax overlay is checked separately: three Core edits
restore the exact original private observer proof and public observer law
and add its one report; two Syntax edits correct the metadata proof and
qualify its source comment. The two restored declarations are matched to
their exact pinned upstream line intervals. All 31 Syntax theorem headers
remain identical to the retained predecessor.

The new cached sharing overlay has 41 physical spans, including one
documentation prefix, and 40 logical spans. Thirty-six constructor subtype
equality certificates use direct rewriting; four termination scripts reverse
the same two lexicographic search alternatives. Both overlays reconstruct
forward and inverse. The five inherited header/visibility/universe
transformations map the complete new logical ExprOpsC source to exactly
the selected physical origin body. Removing only the documentation prefix
leaves the complement outside that origin byte-identical to the accepted
predecessor. There are no new declarations, omissions, imports or reports
in that owner.

BulkBound's six original upstream line intervals and six selected intervals
are checked with byte counts, hashes and exact text. Adapted proof text is
explicit in the frozen map and covered by its independent review. Removing
only the two recorded restored comment-opening lines recovers the retained
unselected draft. LiteralForward's one wording correction reconstructs in
both directions and changes only the distinction between preserving map
validity and preserving map equality.

These source checks supplement fresh Lean checking; they do not replace
it. The new observer simp registration can affect downstream elaboration.
The proof-sharing review makes no claim of identical generated private
helper names, object files, native performance or a formal compiler
equivalence theorem.

## Historical cuts and current supplements

The inherited Core ordinary-field representation and native/compiler
implementation cuts remain in force. The old PropWhen omission maps retain
their historical 36 optional proof and 15 simp-registration omissions.
The separately recorded restoration leaves 34 such proof omissions and 14
simp omissions in the current Core. No old omission map or old source review
is silently rebased. BulkBound's additions restore the specified loose-bound
specification, raw-field laws and memoized fallback proof without replacing
the actual bound accessor or cached algorithms.

The original general model, CSOK, environment and installation metatheory
tower is not imported. Exact helper supplement declarations and new proof
intervals are disclosed; no claim of complete upstream native implementation
or unrestricted upstream API equivalence follows.

## Fixed resource and evidence contract

The same pinned Lean 4.35.0 binary and five runtime shared-library identities
are required, with the same toolchain commit. A portable --lean path can
point to the identical restored SDK; relocation does not change the source
fingerprint. The runner pins and loads only the existing resource helper
and source guard. It does not import a predecessor gate.

Compilation uses one CPU, one compiler thread, one import worker, -M1024,
a 1,048,576-KiB resident limit, autoImplicit=false, warningAsError=true and
Elab.async=false. Default heartbeats, recursion limits and compiler settings
remain unchanged. Existing source-local options are checked exactly; no
new override is allowed.

There is one common 30-second wall-clock interval for all seven fresh
compiler calls and their report/output/integrity checks. The final
successful acceptance requires the measured complete interval, including
final source/control/runtime/snapshot/log and artifact checks, to be at
most 30 seconds. The child helper receives the same absolute deadline for
every module and enforces the memory policy. There is no per-module reset.

The build and source snapshot directories must be new. The experiment
object search path contains only that fresh build. Only the SDK's ordinary
Init/Std imports may be reused. Each module must produce exactly its default
.olean and .ilean objects, and the final fresh build must contain precisely
the fourteen declared artifacts.

A module is accepted only if its compiler exits successfully within the
limits, both objects exist, stderr is empty, stdout contains only the exact
ordered requested reports, and every raw axiom is one of propext, Quot.sound
or Classical.choice. A failed module contributes zero accepted reports,
even if it printed some or all roots before its diagnostic. The report keeps
observed and accepted counts separate. Complete acceptance requires all
120 distinct ordered roots and every module.

Inputs and controls are snapshotted read-only before compilation and checked
again afterward. Runtime and compiler identities are checked before and
after; every child log and the permanent read-only execution marker is
checked as well. JSON parsing rejects duplicate keys. Relative input paths
cannot escape the project root or designate symlinks. Source guard and
additional command/import/option checks prohibit admissions, unsafe code,
unexpected executable commands and hidden experimental imports.

The fingerprint is the unchanged historical stage name plus the exact
ordered mathematical source module/hash pairs and fixed policy. It excludes
runner bytes, metadata, SDK paths, attempt labels and source filenames.
The gate checks its own and all four predecessor marker directories for
the selected fingerprint. Root reserves a permanent marker before the first
compiler call. A consumed source closure stays consumed after failure,
interruption or a result-reading problem.

## Exact source fingerprint

785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e

This marker key is a source/policy identity, not a theorem or a timing claim.

## What a complete pass can establish

A pass checks the operational/license roots, scoped stable cache invariant
lemmas, supplied-state helper-cache semantics, exact level-parameter
correspondence, the unconditional actual bulk-substitution correspondence,
and the concrete actual cached literal base cases. BulkBound discharges the
earlier explicit BulkCutoffSound premise; it covers the actual saturated
fallback as well as the packed unsaturated path. LiteralForward discharges
its actual miss-body premises while retaining StableNF and the supplied
MemoFrame condition for any auxiliary invariant.

The result report uses narrow flags for the actual instantiateListC and
instLevelParams correspondences. It does not claim that every cached
syntactic operation has been related to every pure operation. Literal
success preserves validity of the normal-form maps; real misses insert
entries, so it is not a statement of unchanged maps. It does not supply
validity for an arbitrary invalid initial cache.

The true driver prefix lookup agreement, environment validity, annotation
and installed ProgramPins, real record initialization/intervening-state
preservation, recursive whole-query cached success, original GroupChecked
and the stock numeral theorem remain open. No queen count is evaluated.

## Root-only commands after independent control review

Run the metadata-only preflight with the identical SDK path, for example:

    python next-iteration/kernel-cached-complete-120/gate/run_gate.py --lean /workspace/scratch/618374bfa892/toolchains/lean-4.35.0-linux/bin/lean

Only after root has reviewed the frozen controls and that preflight succeeds,
the single complete run adds:

    --run --attempt complete-01

The gate author has performed neither command. If the selected complete
source fails or exceeds the policy, preserve its source, logs, report and
marker. Diagnose the actual remaining issue and propose substantive new
mathematical source work before any later selection. No unchanged retry,
prepared-object substitution, omitted failed module or expanded budget is
authorized.
