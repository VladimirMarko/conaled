# Fixed exact-relation batch: all sixteen candidates refuted

The one prescribed batch completed and its entire transcript independently
replayed. **All sixteen candidate roots were refuted.** No global signed
identity, reduced basis, Lean theorem, or new queens count was established.

| Measurement | Producer | Independent replay |
| --- | ---: | ---: |
| Child elapsed seconds | 0.685939207 | 1.442813577 |
| Peak child RSS, KiB | 92,468 | 98,712 |
| Separately reported snapshot preparation | See `run-report.json` | See `run-report.json` |
| Outcome | Complete fixed batch | Complete transcript accepted |

Both runs used one CPU, a 30-second wall/CPU limit, and 1 GiB address space.
The producer used **11,366 charged requests**, all completed, with zero pending
requests and **22,734 physical transcript records**. Candidate generation,
original-source validation and every identity/refutation check shared the same
50,000-request allowance.

| Phase | Charged requests |
| --- | ---: |
| Fixed view and matrix loading | 700 |
| Exact rational row reduction | 2,657 |
| Freezing all sixteen candidate vectors | 940 |
| Original descriptor and full-view validation | 1,956 |
| Full-function identity/refutation checks | 5,113 |

The exact 19-by-35 matrix yielded nineteen pivots. All sixteen free-column
vectors were frozen before source validation or identity checking. Each
candidate then reached a checked nonzero terminal and a complete restriction
path. The six distinct reported assignments are counterexamples to their
corresponding candidates; they were not fed back into proposal generation.

The transcript validates 1,253 distinct original nodes. Its normalized states
have at most four terms, and the recorded coefficient and rational numerator/
denominator maxima are two bits. Five zero proofs were completed for proper
substates. **None is a proof of a candidate root.** Seventy-seven exact cache
hits reuse such completed zero substates.

## What this resolves

These sixteen particular directions from the sample nullspace cannot be used
as global identities. Refuting a basis of sampled candidate directions does
not prove that every linear combination fails. It therefore does not establish
global right rank 35, minimality of the 35-term grouping, or impossibility of a
context-dependent factorization. The known sampled lower-bound evidence and
the distinction between global functions and their use with outside factors
remain as before.

No new samples, primes, column orders, adaptive feedback or larger boards were
used. There was one producer attempt and one independent replay, with unchanged
source/input bindings. No Lean process ran for this diagnostic. The generic
signed-relation laws remain useful, but there is no successful concrete root
to justify implementing a guarded Lean certificate checker at this point.

## Recovery evidence

- `RESULTS.json` records the exact coefficients, outcomes, phase totals and
  byte bindings, extracted from completed records without new semantic work.
- `attempts/relations-01/work.jsonl` is the one canonical complete transcript.
- `attempts/relations-01/run-report.json` and
  `attempts/relations-replay-01/run-report.json` record the bounded processes.
- `attempts/relations-replay-01/replay-report.json` records the complete checked
  outcome, SHA256
  `5570f52bb43ec81405bcf686e749f2e5078ae1d1b052b8a4b7f71fd23c556bba`.

The transcript is 3,918,899 bytes. Future durability snapshots should include
it once, the canonical programs/protocol and necessary existing input once,
plus these small final reports. They need not carry the repeated attempt input
and source snapshots. This result is subsequent to compact checkpoint 176.

For the next recovery snapshot, the current relation transcript replaces the
older large factor-n8 and cut-work diagnostic transcripts in the explicit
selection. Their sources, fixed inputs and result reports remain; those derived
transcripts can be regenerated if needed. No workspace file or older archive
is deleted, and every accepted Lean proof source remains retained.
