# Exact relation producer: fixed batch completed

The producer and independent replayer completed the prescribed batch after source/control review. All sixteen candidate roots were refuted in11,366 charged requests. See `RESULTS.md` for the accepted transcript and precise scope. The preparation descriptions below record the state before that one run; they are not current pending-execution instructions.

## Current files and ownership

- `diagnostics/produce_relations.py`: reuse_diagnostics; complete source draft, held stable for independent source review.
- `PROTOCOL.md`: reuse_diagnostics; exact records, reference selectors, arithmetic order, origin dependencies and cap-prefix rules.
- `run_probe.py`: root; unchanged by this work.
- `replay/replay_relations.py`: residual_rules; independently authored against the protocol, never imported by the producer.

The plan lives in `../exact-relation-plan/`. Its exact v1 files and v1-to-v2 patches are preserved there. V2 adds charged cache comparisons on misses/collisions, positive divisors for integer divmod, and explicit reuse of an existing proof ID on a cache hit. The independent design review found no mathematical blocker; executable source/control review remains pending.

## Implemented scope

The fixed 19×35 saved Nat matrix proposes all16 canonical free-column relations. Rational wrappers, their primitive integer children, explicit Euclidean steps and candidate extraction share the same50,000-ticket counter as selected-source validation and the complete signed relation search. A cap may occur in any phase.

Source validation reads only selected ancestors after a ticket starts. Complete view masks and cores remain bound to the original guarded descriptors. Signed collection preserves coefficient multiplicity. The recursive checker uses the least supported variable, completes the false branch first, and requires both branches for a zero identity. A nonzero terminal returns a concrete path refutation. It never updates the frozen candidate basis from that path.

Zero-state memoization uses a digest only to choose a completion-ordered bucket. Every inspected bucket entry and term comparison is charged, including failed comparisons. A hit reuses its earlier proof ID. No whole-state tuple/dictionary equality supplies an unmetered semantic match.

There are no extra scalar test fixtures or semantic trial runs in preparation. The planned first run remains blocked on complete root/runtime review of both programs and the runner. No expected queens answer is a premise, and this diagnostic alone would establish no Lean theorem or new source count.

## Continuation

The fixed batch and its independent replay are finished. Retain one transcript,
the canonical source/protocol/input files, and the selected final reports. Do not
repeat the batch, change its candidates, or reinterpret its five zero substates
as successful global identities. The next selected exact-basis direction has
its own assessment and requires its own fixed design and review.

`producer-origin/preparation.json` preserves the original source/protocol and
input binding before execution. Current source identities remain unchanged by
the run. Current durable packaging follows the explicit compact selection.
