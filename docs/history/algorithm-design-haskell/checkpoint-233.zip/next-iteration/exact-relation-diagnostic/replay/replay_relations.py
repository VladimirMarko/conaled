#!/usr/bin/env python3
"""Independent replay of the fixed exact-relation diagnostic.

The fixed v2 controller checks scheduled requests, local results, exact origins
and completion order. No producer, evaluator, algebra package, or previous
semantic checker is imported. This file is an unexecuted implementation until
its independent source review and one authorized bounded replay are recorded.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import sys
import time


SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
SAMPLE_SHA = "ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2"
DESIGN_SHA = "7bb9f40efe72a6d72dd952ed27716f852457b0883bc7770a83d80ebc737a56b8"
SCHEMA_SHA = "9fa33aebe3c47fae30e59e9910172e10e15bb1142830a6abc1556bddfa3f1d00"
PROTOCOL_SHA = "28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147"
ROWS, COLUMNS, CAP, VARIABLES = 19, 35, 50000, 210
ZERO_VIEW = (0, 0, 0)
MASK_LIMIT = 1 << VARIABLES
Y_VARIABLES = (171, 174, 175, 177, 186, 187, 189, 191,
               192, 193, 195, 200, 202, 203, 206, 208)
Y_MASK = sum(1 << index for index in Y_VARIABLES)


class Rejected(Exception):
    """The supplied transcript or fixture is inconsistent."""


class EndOfPrefix(Exception):
    """A retained footer occurred before the next semantic request."""

    def __init__(self, footer, location):
        self.footer = footer
        self.location = location


def need(condition, message):
    if not condition:
        raise Rejected(message)


def integer(value, label):
    need(type(value) is int, label + ": integer required")
    return value


def natural(value, label, bound=None):
    integer(value, label)
    need(value >= 0, label + ": nonnegative integer required")
    if bound is not None:
        need(value < bound, label + ": upper bound exceeded")
    return value


def unique_fields(items):
    result = {}
    for key, value in items:
        need(key not in result, "duplicate JSON field: " + str(key))
        result[key] = value
    return result


def parse_json(raw):
    return json.loads(raw, object_pairs_hook=unique_fields)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def same(actual, expected, label):
    # Exact JSON comparison preserves the distinction between bool and int.
    left, right = encoded(actual), encoded(expected)
    need(left == right, f"{label}: observed {left[:500]}, expected {right[:500]}")


def binding(path):
    path = Path(path)
    h, length = hashlib.sha256(), 0
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
            length += len(block)
    return {"path": str(path), "bytes": length, "sha256": h.hexdigest()}


def checked_view(raw):
    need(type(raw) in (list, tuple) and len(raw) == 3, "view shape")
    positive, negative, core = raw
    natural(positive, "positive mask", MASK_LIMIT)
    natural(negative, "negative mask", MASK_LIMIT)
    natural(core, "bare core ID")
    need(positive & negative == 0, "contradictory full view")
    return positive, negative, core


class RawInputs:
    """Byte binding and raw indexing only; no graph validation or evaluation."""

    def __init__(self, trace, sample):
        self.trace_binding = binding(trace)
        self.sample_binding = binding(sample)
        same(self.trace_binding["sha256"], SOURCE_SHA, "fixed original trace")
        same(self.sample_binding["sha256"], SAMPLE_SHA, "fixed saved sample")
        self.index, self.parsed_records = {}, 0
        with Path(trace).open(encoding="utf-8") as stream:
            for text in stream:
                row = parse_json(text)
                self.parsed_records += 1
                if row.get("type") == "node":
                    # Preserve duplicates and distinguish malformed bool IDs
                    # from integer IDs. Only a charged validate request may
                    # inspect the actual descriptor and reject its semantics.
                    self.index.setdefault(encoded(row.get("id")), []).append(row)
        self.sample = parse_json(Path(sample).read_text())

    def descriptor(self, index):
        natural(index, "source descriptor ID")
        rows = self.index.get(encoded(index), [])
        need(len(rows) == 1, f"missing or duplicated selected descriptor {index}")
        same(rows[0]["id"], index, "selected descriptor ID")
        return rows[0]


@dataclass(frozen=True)
class Completed:
    work_id: int
    output: dict
    operation: str = ""
    inputs: dict | None = None

    def reference(self, name, *indices):
        return [self.work_id, name, *indices]


@dataclass
class Frame:
    work_id: int
    explicit: list = field(default_factory=list)
    children: list = field(default_factory=list)


OPERATIONS = (
    "view_load", "matrix_load", "pivot_probe", "row_swap", "cell_swap",
    "eliminate_probe", "pivot_commit", "rref_entry", "rref_complete",
    "int_scalar", "rat_mul", "rat_sub", "rat_div", "rat_normalize", "gcd_step",
    "candidate_entry", "candidate_complete", "validate", "view_validate",
    "normalize", "term_add", "term_compare", "state", "state_lookup",
    "cache_candidate", "cache_term", "view_support", "support_join",
    "select_variable", "branch", "cofactor", "terminal_decide",
    "refute_lift", "candidate_outcome",
)


class Journal:
    """Consume one scheduled request before performing its local checks."""

    def __init__(self, path):
        self.path = Path(path)
        self.stream = self.path.open(encoding="utf-8")
        self.lines = 0
        self.started = 0
        self.completed = {}
        self.stack = []
        self.counts = {name: 0 for name in OPERATIONS}
        self.cache_counts = {name: {"hits": 0, "misses": 0}
                             for name in ("validate", "zero_state")}
        self.context = {"phase": "load", "candidate": None}
        self.maxima = {name: 0 for name in (
            "numerator_bits", "denominator_bits", "candidate_coefficient_bits",
            "state_coefficient_bits", "terminal_integer_bits", "state_terms",
            "pending_depth", "zero_cache_entries")}
        self.header = self.read()
        need(self.header.get("kind") == "header", "missing initial header")

    def read(self):
        line = self.stream.readline()
        need(bool(line), "transcript ended without its complete footer")
        self.lines += 1
        result = parse_json(line)
        need(type(result) is dict, "record must be an object")
        return result

    def event(self, location):
        row = self.read()
        if row.get("kind") == "footer":
            raise EndOfPrefix(row, location)
        return row

    def record(self, index):
        natural(index, "completed work reference")
        need(index in self.completed, f"reference to unfinished work {index}")
        return self.completed[index]

    def value(self, reference):
        need(type(reference) is list and len(reference) >= 2, "Ref shape")
        item = self.record(reference[0]).output
        name = reference[1]
        need(type(name) is str and name in item, "Ref output field")
        item = item[name]
        for index in reference[2:]:
            natural(index, "Ref list selector")
            need(type(item) in (list, tuple) and index < len(item), "Ref list selection")
            item = item[index]
        return item

    def use(self, frame, reference):
        value = self.value(reference)
        frame.explicit.append(reference[0])
        return value

    def use_record(self, frame, index):
        result = self.record(index)
        frame.explicit.append(index)
        return result

    def argument(self, frame, argument):
        need(type(argument) is dict and len(argument) == 1, "integer argument shape")
        if "literal" in argument:
            return integer(argument["literal"], "integer literal")
        need("ref" in argument, "unknown integer argument tag")
        return integer(self.use(frame, argument["ref"]), "integer argument reference")

    def inspect_argument(self, argument):
        # Used only inside an already charged wrapper after the operand's
        # origin has already been recorded, or for reporting metadata.
        if "literal" in argument:
            return integer(argument["literal"], "integer literal")
        return integer(self.value(argument["ref"]), "integer argument reference")

    def set_context(self, phase, candidate=None):
        self.context = {"phase": phase, "candidate": candidate}

    def observe(self, operation, output):
        if operation in {"matrix_load", "rat_mul", "rat_sub", "rat_div", "rat_normalize"}:
            numerator, denominator = output["value"]
            self.maxima["numerator_bits"] = max(self.maxima["numerator_bits"], numerator.bit_length())
            self.maxima["denominator_bits"] = max(self.maxima["denominator_bits"], denominator.bit_length())
        if operation == "cell_swap":
            for numerator, denominator in (output["new_a"], output["new_b"]):
                self.maxima["numerator_bits"] = max(self.maxima["numerator_bits"], numerator.bit_length())
                self.maxima["denominator_bits"] = max(self.maxima["denominator_bits"], denominator.bit_length())
        if operation == "candidate_entry":
            self.maxima["candidate_coefficient_bits"] = max(
                self.maxima["candidate_coefficient_bits"], output["coefficient"].bit_length())
        if operation == "term_add":
            state = output["state"]
            self.maxima["state_terms"] = max(self.maxima["state_terms"], len(state))
            for _, coefficient in state:
                self.maxima["state_coefficient_bits"] = max(
                    self.maxima["state_coefficient_bits"], coefficient.bit_length())

    def terminal_observation(self, value):
        self.maxima["terminal_integer_bits"] = max(
            self.maxima["terminal_integer_bits"], value.bit_length())

    def call(self, operation, inputs, body):
        row = self.event("start")
        need(self.started < CAP and operation in self.counts, "request cap or vocabulary")
        index = self.started
        self.started += 1
        self.counts[operation] += 1
        frame = Frame(index)
        self.stack.append(frame)
        self.maxima["pending_depth"] = max(self.maxima["pending_depth"], len(self.stack))
        same(row, {"kind": "work", "id": index, "operation": operation,
                   "inputs": inputs, "context": self.context}, "scheduled request")
        output = body(frame)
        dependencies = frame.explicit + frame.children
        need(all(type(index) is int and index in self.completed for index in dependencies),
             "dependency is not already complete")
        done = self.event("done")
        same(done, {"kind": "done", "id": index, "finish": len(self.completed),
                    "dependencies": dependencies, "output": output}, "local completion")
        need(self.stack[-1] is frame, "completion does not close the top frame")
        self.stack.pop()
        result = Completed(index, output, operation, inputs)
        self.completed[index] = result
        self.observe(operation, output)
        if self.stack:
            self.stack[-1].children.append(index)
        return result


def literal(value):
    return {"literal": value}


def referenced(reference):
    return {"ref": reference}


def rat_fields(raw):
    need(type(raw) in (list, tuple) and len(raw) == 2, "rational pair shape")
    numerator, denominator = raw
    integer(numerator, "rational numerator")
    integer(denominator, "rational denominator")
    need(denominator > 0, "rational denominator must be positive")
    # Coprimality follows from the checked construction history. No hidden gcd
    # is performed here or used as an extra semantic request.
    need(numerator != 0 or denominator == 1, "noncanonical rational zero")
    return numerator, denominator


class ExactArithmetic:
    def __init__(self, journal):
        self.j = journal

    def scalar(self, op, a, b=None):
        def body(frame):
            x = self.j.argument(frame, a)
            y = self.j.argument(frame, b) if b is not None else None
            if op in {"neg", "abs"}:
                need(y is None, "unary scalar has a second operand")
                value = -x if op == "neg" else abs(x)
            else:
                need(y is not None, "binary scalar lacks its second operand")
                if op == "add":
                    value = x + y
                elif op == "sub":
                    value = x - y
                elif op == "mul":
                    value = x * y
                else:
                    need(op == "divmod" and y > 0, "divmod requires a positive divisor")
                    quotient, remainder = divmod(x, y)
                    value = [quotient, remainder]
            return {"value": value}
        return self.j.call("int_scalar", {"op": op, "a": a, "b": b}, body)

    def gcd_step(self, x_arg, y_arg):
        def body(frame):
            x = self.j.argument(frame, x_arg)
            y = self.j.argument(frame, y_arg)
            natural(x, "gcd x")
            natural(y, "gcd y")
            if y == 0:
                return {"terminal": True, "quotient": None, "remainder": None}
            quotient, remainder = divmod(x, y)
            return {"terminal": False, "quotient": quotient, "remainder": remainder}
        return self.j.call("gcd_step", {"x": x_arg, "y": y_arg}, body)

    def normalize(self, numerator, denominator):
        def body(frame):
            n_arg, d_arg = numerator, denominator
            n = self.j.argument(frame, n_arg)
            d = self.j.argument(frame, d_arg)
            need(d != 0, "zero normalization denominator")
            if d < 0:
                new_n = self.scalar("neg", n_arg)
                new_d = self.scalar("neg", d_arg)
                n_arg, d_arg = referenced(new_n.reference("value")), referenced(new_d.reference("value"))
                n, d = new_n.output["value"], new_d.output["value"]
            if n == 0:
                return {"value": [0, 1], "rule": "zero"}
            if d == 1:
                return {"value": [n, 1], "rule": "denominator_one"}
            magnitude = self.scalar("abs", n_arg)
            x_arg, y_arg = referenced(magnitude.reference("value")), d_arg
            while True:
                step = self.gcd_step(x_arg, y_arg)
                if step.output["terminal"]:
                    gcd_arg = x_arg
                    break
                x_arg, y_arg = y_arg, referenced(step.reference("remainder"))
            need(self.j.inspect_argument(gcd_arg) > 0, "normalization gcd is not positive")
            n_div = self.scalar("divmod", n_arg, gcd_arg)
            d_div = self.scalar("divmod", d_arg, gcd_arg)
            need(n_div.output["value"][1] == d_div.output["value"][1] == 0,
                 "normalization division is not exact")
            return {"value": [n_div.output["value"][0], d_div.output["value"][0]], "rule": "gcd"}
        return self.j.call("rat_normalize", {"numerator": numerator, "denominator": denominator}, body)

    def rational(self, op, left, right):
        def body(frame):
            a = rat_fields(self.j.use(frame, left))
            b = rat_fields(self.j.use(frame, right))
            an, ad = referenced(left + [0]), referenced(left + [1])
            bn, bd = referenced(right + [0]), referenced(right + [1])
            if op == "rat_mul":
                if a[0] == 0 or b[0] == 0:
                    return {"value": [0, 1], "rule": "zero"}
                if a == (1, 1):
                    return {"value": list(b), "rule": "left_unit"}
                if b == (1, 1):
                    return {"value": list(a), "rule": "right_unit"}
                n = self.scalar("mul", an, bn)
                d = self.scalar("mul", ad, bd)
            elif op == "rat_sub":
                if b[0] == 0:
                    return {"value": list(a), "rule": "right_zero"}
                if a == b:
                    return {"value": [0, 1], "rule": "equal"}
                if a[0] == 0:
                    negative = self.scalar("neg", bn)
                    return {"value": [negative.output["value"], b[1]], "rule": "left_zero"}
                if a[1] == b[1]:
                    n = self.scalar("sub", an, bn)
                    result = self.normalize(referenced(n.reference("value")), ad)
                    return {"value": result.output["value"], "rule": "equal_denominator"}
                first = self.scalar("mul", an, bd)
                second = self.scalar("mul", bn, ad)
                n = self.scalar("sub", referenced(first.reference("value")), referenced(second.reference("value")))
                d = self.scalar("mul", ad, bd)
            else:
                need(op == "rat_div", "unknown rational operation")
                need(b[0] != 0, "zero rational divisor")
                if a[0] == 0:
                    return {"value": [0, 1], "rule": "zero"}
                if b == (1, 1):
                    return {"value": list(a), "rule": "unit_divisor"}
                if a == b:
                    return {"value": [1, 1], "rule": "equal"}
                n = self.scalar("mul", an, bd)
                d = self.scalar("mul", ad, bn)
            result = self.normalize(referenced(n.reference("value")), referenced(d.reference("value")))
            return {"value": result.output["value"], "rule": "general"}
        return self.j.call(op, {"a": left, "b": right}, body)


class Controller:
    """Reconstruct the fixed schedule from checked predecessors only."""

    def __init__(self, source, journal):
        self.src, self.j = source, journal
        self.a = ExactArithmetic(journal)
        self.views = []
        self.matrix = []
        self.pivots = []
        self.pivot_commits = []
        self.free_columns = []
        self.rref_done = None
        self.candidates = []
        self.validation = {}
        self.zero_validation = None
        self.validated_views = []
        self.zero_buckets = {}
        self.proofs = []
        self.outcomes = []

    def load(self):
        # Retrieving raw fields creates request inputs; their shape and exact
        # fixed source positions are checked only after their work ticket.
        sample = self.src.sample
        raw_views = sample["grouping"]["b_views"]
        raw_rows = sample["sides"]["B"]["sample_rows"]
        for column in range(COLUMNS):
            raw = raw_views[column]

            def view_body(frame, column=column, raw=raw):
                need(type(raw_views) is list and len(raw_views) == COLUMNS,
                     "fixed view dimensions")
                same(raw, raw_views[column], "saved view position")
                return {"view": list(checked_view(raw))}

            result = self.j.call("view_load", {"column": column, "saved_view": raw}, view_body)
            self.views.append(result)
        for row in range(ROWS):
            refs = []
            for column in range(COLUMNS):
                raw = raw_rows[row]["nat_values"][column]

                def matrix_body(frame, row=row, column=column, raw=raw):
                    need(type(raw_rows) is list and len(raw_rows) == ROWS,
                         "fixed sample row dimensions")
                    values = raw_rows[row]["nat_values"]
                    need(type(values) is list and len(values) == COLUMNS,
                         "fixed sample column dimensions")
                    same(raw, values[column], "saved sample position")
                    return {"value": [natural(raw, "saved Nat cell"), 1]}

                result = self.j.call("matrix_load", {
                    "row": row, "column": column, "saved_nat": raw}, matrix_body)
                refs.append(result.reference("value"))
            self.matrix.append(refs)

    def pivot_probe(self, row, column):
        cell = self.matrix[row][column]

        def body(frame):
            numerator, _ = rat_fields(self.j.use(frame, cell))
            return {"nonzero": numerator != 0}
        return self.j.call("pivot_probe", {"row": row, "column": column, "cell": cell}, body)

    def swap_rows(self, row_a, row_b):
        def body(frame):
            new_a, new_b = [], []
            for column in range(COLUMNS):
                cell_a, cell_b = self.matrix[row_a][column], self.matrix[row_b][column]

                def swap(child, cell_a=cell_a, cell_b=cell_b):
                    a = list(rat_fields(self.j.use(child, cell_a)))
                    b = list(rat_fields(self.j.use(child, cell_b)))
                    return {"new_a": b, "new_b": a}

                result = self.j.call("cell_swap", {
                    "column": column, "cell_a": cell_a, "cell_b": cell_b}, swap)
                new_a.append(result.reference("new_a"))
                new_b.append(result.reference("new_b"))
            return {"row_a_refs": new_a, "row_b_refs": new_b}

        result = self.j.call("row_swap", {"row_a": row_a, "row_b": row_b}, body)
        self.matrix[row_a] = result.output["row_a_refs"]
        self.matrix[row_b] = result.output["row_b_refs"]

    def eliminate_probe(self, row, pivot_column):
        cell = self.matrix[row][pivot_column]

        def body(frame):
            value = list(rat_fields(self.j.use(frame, cell)))
            return {"skip": value[0] == 0, "factor": value}
        return self.j.call("eliminate_probe", {
            "row": row, "pivot_column": pivot_column, "cell": cell}, body)

    def reduce_matrix(self):
        self.j.set_context("rref")
        pivot_row = 0
        for column in range(COLUMNS):
            selected = None
            for row in range(pivot_row, ROWS):
                if self.pivot_probe(row, column).output["nonzero"]:
                    selected = row
                    break
            if selected is None:
                self.free_columns.append(column)
                continue
            if selected != pivot_row:
                self.swap_rows(pivot_row, selected)
            original_pivot = self.matrix[pivot_row][column]
            for target_column in range(COLUMNS):
                result = self.a.rational("rat_div", self.matrix[pivot_row][target_column], original_pivot)
                self.matrix[pivot_row][target_column] = result.reference("value")
            for target_row in range(ROWS):
                if target_row == pivot_row:
                    continue
                coefficient = self.eliminate_probe(target_row, column)
                if coefficient.output["skip"]:
                    continue
                factor = coefficient.reference("factor")
                for target_column in range(COLUMNS):
                    product = self.a.rational("rat_mul", factor, self.matrix[pivot_row][target_column])
                    difference = self.a.rational("rat_sub", self.matrix[target_row][target_column],
                                                 product.reference("value"))
                    self.matrix[target_row][target_column] = difference.reference("value")
            current_row = list(self.matrix[pivot_row])

            def commit(frame, current_row=current_row):
                for ref in current_row:
                    rat_fields(self.j.use(frame, ref))
                return {"pivot_index": len(self.pivots)}

            committed = self.j.call("pivot_commit", {
                "row": pivot_row, "column": column, "row_cell_refs": current_row}, commit)
            self.pivots.append(column)
            self.pivot_commits.append(committed)
            pivot_row += 1
        checks = []
        all_entries_match = True
        for row in range(ROWS):
            for column in range(COLUMNS):
                cell = self.matrix[row][column]
                position = self.pivots.index(column) if column in self.pivots else None

                def check(frame, cell=cell, row=row, position=position):
                    value = rat_fields(self.j.use(frame, cell))
                    matches = position is None or value == ((1 if row == position else 0), 1)
                    return {"matches": matches}

                checked = self.j.call("rref_entry", {
                    "row": row, "column": column, "cell": cell, "pivot_row": position}, check)
                checks.append(checked)
                all_entries_match = all_entries_match and checked.output["matches"]
        current = [list(row) for row in self.matrix]

        def finish(frame):
            for result in checks:
                self.j.use_record(frame, result.work_id)
            for result in self.pivot_commits:
                self.j.use_record(frame, result.work_id)
            matches = (all_entries_match and len(self.pivots) == ROWS
                       and len(self.free_columns) == COLUMNS - ROWS)
            return {"free_columns": list(self.free_columns), "matches": matches}

        self.rref_done = self.j.call("rref_complete", {
            "current_cell_refs": current, "pivot_columns": list(self.pivots),
            "entry_check_refs": [item.work_id for item in checks]}, finish)
        need(self.rref_done.output["matches"], "fixed RREF dimensions/pattern mismatch")

    def freeze_candidates(self):
        for free_column in self.free_columns:
            self.j.set_context("candidates", free_column)
            scale_arg = literal(1)
            scale = None
            for row in range(ROWS):
                scale = self.a.scalar("mul", scale_arg,
                                      referenced(self.matrix[row][free_column] + [1]))
                scale_arg = referenced(scale.reference("value"))
            scale_ref = scale.reference("value")
            entries = []
            for column in range(COLUMNS):
                if column == free_column:
                    role, cell = "free_target", None
                elif column in self.pivots:
                    role = "pivot"
                    cell = self.matrix[self.pivots.index(column)][free_column]
                else:
                    role, cell = "other_free", None

                def entry(frame, role=role, cell=cell):
                    scale_value = integer(self.j.use(frame, scale_ref), "candidate positive scale")
                    need(scale_value > 0, "candidate scale is not positive")
                    pivot = rat_fields(self.j.use(frame, cell)) if cell is not None else None
                    if role == "free_target":
                        return {"coefficient": scale_value, "rule": role}
                    if role == "other_free":
                        return {"coefficient": 0, "rule": role}
                    if pivot[0] == 0:
                        return {"coefficient": 0, "rule": "pivot_zero"}
                    quotient = self.a.scalar("divmod", referenced(scale_ref), referenced(cell + [1]))
                    need(quotient.output["value"][1] == 0, "candidate denominator does not divide product")
                    product = self.a.scalar("mul", referenced(cell + [0]),
                                            referenced(quotient.reference("value", 0)))
                    negative = self.a.scalar("neg", referenced(product.reference("value")))
                    return {"coefficient": negative.output["value"], "rule": role}

                result = self.j.call("candidate_entry", {
                    "free_column": free_column, "column": column, "scale": scale_ref,
                    "rref_cell": cell, "role": role}, entry)
                entries.append(result)
            entry_refs = [entry.reference("coefficient") for entry in entries]

            def complete(frame):
                scale_value = integer(self.j.use(frame, scale_ref), "frozen scale")
                coefficients = [integer(self.j.use(frame, ref), "frozen coefficient")
                                for ref in entry_refs]
                reduced = self.j.use_record(frame, self.rref_done.work_id)
                need(reduced.output["matches"] and free_column in reduced.output["free_columns"],
                     "candidate does not refer to the fixed RREF")
                positive = scale_value > 0 and coefficients[free_column] == scale_value
                need(positive, "candidate target is not its positive denominator product")
                return {"coefficients": coefficients, "positive_target": positive}

            frozen = self.j.call("candidate_complete", {
                "free_column": free_column, "scale": scale_ref, "entry_refs": entry_refs,
                "rref_complete": self.rref_done.work_id}, complete)
            self.candidates.append(frozen)

    def validate(self, node_id):
        def body(frame):
            natural(node_id, "selected source ID")
            if node_id in self.validation:
                self.j.cache_counts["validate"]["hits"] += 1
                prior = self.j.use_record(frame, self.validation[node_id].work_id)
                return dict(prior.output, cache_hit=True, prior=prior.work_id)
            self.j.cache_counts["validate"]["misses"] += 1
            raw = self.src.descriptor(node_id)
            kind, value = raw.get("kind"), None
            if kind == "constant":
                value = natural(raw.get("value"), "original constant")
                support, flat = 0, [0, 0, node_id]
            elif kind == "ite":
                variable = natural(raw.get("variable"), "original branch variable", VARIABLES)
                low = natural(raw.get("low"), "original low child", node_id)
                high = natural(raw.get("high"), "original high child", node_id)
                lo = self.validate(low)
                hi = self.validate(high)
                child_support = lo.output["support"] | hi.output["support"]
                need(child_support & ((1 << (variable + 1)) - 1) == 0,
                     "original branch violates strict variable order")
                support, flat = (1 << variable) | child_support, [0, 0, node_id]
            elif kind == "guard":
                positive = natural(raw.get("positive"), "original positive guard", MASK_LIMIT)
                negative = natural(raw.get("negative"), "original negative guard", MASK_LIMIT)
                need(positive | negative != 0 and positive & negative == 0,
                     "original guard is empty or contradictory")
                core = natural(raw.get("core"), "original guard core", node_id)
                child = self.validate(core)
                need(child.output["node_kind"] != "guard", "original guard has nested guard core")
                need((positive | negative) & child.output["support"] == 0,
                     "original guard overlaps core support")
                support = positive | negative | child.output["support"]
                flat = [positive, negative, core]
            else:
                raise Rejected("unknown selected source node kind")
            natural(support, "derived original support", MASK_LIMIT)
            if node_id == 0:
                need(kind == "constant" and value == 0, "designated zero is not constant zero")
            return {"node_kind": kind, "support": support, "flat": flat,
                    "value": value, "cache_hit": False, "prior": None}

        checked = self.j.call("validate", {"source_node_id": node_id}, body)
        if not checked.output["cache_hit"]:
            need(node_id not in self.validation, "source validation cache overwrite")
            self.validation[node_id] = checked
        return checked

    def cached_core(self, frame, core):
        natural(core, "cached bare core")
        need(core in self.validation, "use of unvalidated original core")
        return self.j.use_record(frame, self.validation[core].work_id)

    @staticmethod
    def support_from(view, validated):
        positive, negative, core = checked_view(view)
        info = validated.output
        need(validated.inputs["source_node_id"] == core, "view/core validation binding")
        need(info["node_kind"] != "guard", "view core is not bare")
        need((positive | negative) & info["support"] == 0, "view guard/core support overlap")
        return positive | negative | info["support"]

    def validate_views(self):
        self.j.set_context("validate")
        self.zero_validation = self.validate(0)
        for column, loaded in enumerate(self.views):
            value, ref = loaded.output["view"], loaded.reference("view")

            def body(frame, value=value, ref=ref):
                same(self.j.use(frame, ref), value, "original selected view binding")
                zero = self.j.use_record(frame, self.zero_validation.work_id)
                need(zero.output["node_kind"] == "constant" and zero.output["value"] == 0,
                     "initial zero validation")
                view = checked_view(value)
                core = self.validate(view[2])
                support = self.support_from(view, core)
                need(support & ~Y_MASK == 0, "selected view has support outside fixed Y")
                return {"view": list(view), "support": support, "inside_y": True}

            checked = self.j.call("view_validate", {
                "column": column, "view": value, "load": ref}, body)
            self.validated_views.append(checked)

    def term_compare(self, incoming, existing):
        def body(frame):
            left = checked_view(self.j.use(frame, incoming))
            right = checked_view(self.j.use(frame, existing))
            order = -1 if left < right else (1 if left > right else 0)
            return {"order": order}
        return self.j.call("term_compare", {"incoming": incoming, "existing": existing}, body)

    def term_add(self, accumulator, view, coefficient):
        def body(frame):
            old = [] if accumulator is None else self.j.use(frame, accumulator)
            incoming = list(checked_view(self.j.use(frame, view)))
            amount = integer(self.j.use(frame, coefficient), "incoming signed coefficient")
            if amount == 0:
                return {"state": list(old), "rule": "zero_coefficient"}
            if tuple(incoming) == ZERO_VIEW:
                return {"state": list(old), "rule": "zero_view"}
            for position in range(len(old)):
                comparison = self.term_compare(view, accumulator + [position, 0])
                order = comparison.output["order"]
                if order < 0:
                    return {"state": old[:position] + [[incoming, amount]] + old[position:],
                            "rule": "insert"}
                if order == 0:
                    added = self.a.scalar("add", referenced(accumulator + [position, 1]),
                                          referenced(coefficient))
                    total = added.output["value"]
                    middle = [] if total == 0 else [[incoming, total]]
                    return {"state": old[:position] + middle + old[position + 1:],
                            "rule": "cancel" if total == 0 else "combine"}
            return {"state": list(old) + [[incoming, amount]], "rule": "append"}

        return self.j.call("term_add", {
            "accumulator": accumulator, "view": view, "coefficient": coefficient}, body)

    def normalize(self, terms):
        def body(frame):
            for term in terms:
                self.j.use(frame, term["view"])
                self.j.use(frame, term["coefficient"])
            current, last = None, None
            for term in terms:
                last = self.term_add(current, term["view"], term["coefficient"])
                current = last.reference("state")
            return {"state": [] if last is None else last.output["state"]}
        return self.j.call("normalize", {"terms": terms}, body)

    def cache_term(self, current, cached):
        def body(frame):
            left, right = self.j.use(frame, current), self.j.use(frame, cached)
            # This charged request is the only full-term cache comparison.
            need(type(left) is list and len(left) == 2 and type(right) is list and len(right) == 2,
                 "cache term shape")
            left_view, right_view = checked_view(left[0]), checked_view(right[0])
            a = integer(left[1], "current cached coefficient")
            b = integer(right[1], "prior cached coefficient")
            return {"equal": left_view == right_view and a == b}
        return self.j.call("cache_term", {"current": current, "cached": cached}, body)

    def cache_candidate(self, state_ref, prior_state, prior_zero, prior_proof):
        def body(frame):
            current = self.j.use(frame, state_ref)
            cached = self.j.use(frame, prior_state)
            proof = self.j.use_record(frame, prior_zero)
            natural(prior_proof, "prior zero proof", len(self.proofs))
            need(self.proofs[prior_proof].work_id == prior_zero
                 and proof.output["outcome"] == "zero"
                 and proof.output["proof_id"] == prior_proof,
                 "cache entry is not a completed zero proof")
            if len(current) != len(cached):
                return {"equal": False}
            for position in range(len(current)):
                result = self.cache_term(state_ref + [position], prior_state + [position])
                if not result.output["equal"]:
                    return {"equal": False}
            return {"equal": True}
        return self.j.call("cache_candidate", {
            "state": state_ref, "prior_state": prior_state,
            "prior_zero": prior_zero, "prior_proof": prior_proof}, body)

    def state_lookup(self, state_ref):
        def body(frame):
            state = self.j.use(frame, state_ref)
            digest = hashlib.sha256(json.dumps(
                state, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
            for prior_state, prior_zero, prior_proof in self.zero_buckets.get(digest, []):
                result = self.cache_candidate(state_ref, prior_state, prior_zero, prior_proof)
                if result.output["equal"]:
                    self.j.cache_counts["zero_state"]["hits"] += 1
                    return {"hit": True, "prior": prior_zero,
                            "proof_id": prior_proof, "digest": digest}
            self.j.cache_counts["zero_state"]["misses"] += 1
            return {"hit": False, "prior": None, "proof_id": None, "digest": digest}
        return self.j.call("state_lookup", {"state": state_ref}, body)

    def view_support(self, view_ref):
        def body(frame):
            value = checked_view(self.j.use(frame, view_ref))
            core = self.cached_core(frame, value[2])
            return {"support": self.support_from(value, core)}
        return self.j.call("view_support", {"view": view_ref}, body)

    def support_join(self, before, term_support):
        def body(frame):
            a = natural(self.j.argument(frame, before), "accumulated support", MASK_LIMIT)
            b = natural(self.j.use(frame, term_support), "term support", MASK_LIMIT)
            return {"after": a | b}
        return self.j.call("support_join", {"before": before, "term_support": term_support}, body)

    def select_variable(self, support):
        def body(frame):
            value = natural(self.j.argument(frame, support), "selected support", MASK_LIMIT)
            variable = (value & -value).bit_length() - 1 if value else None
            return {"variable": variable}
        return self.j.call("select_variable", {"support": support}, body)

    def cofactor(self, view_ref, variable_ref, bit):
        def body(frame):
            value = checked_view(self.j.use(frame, view_ref))
            variable = natural(self.j.use(frame, variable_ref), "cofactor variable", VARIABLES)
            need(type(bit) is int and bit in (0, 1), "cofactor Boolean choice")
            positive, negative, core = value
            validated = self.cached_core(frame, core)
            self.j.use_record(frame, self.zero_validation.work_id)
            support = self.support_from(value, validated)
            need(support & ((1 << variable) - 1) == 0,
                 "cofactor is below a still-supported variable")
            selected_bit = 1 << variable
            if value == ZERO_VIEW:
                result, result_support, rule = ZERO_VIEW, 0, "zero"
            elif (positive | negative) & selected_bit:
                if bool(positive & selected_bit) == bool(bit):
                    result = positive & ~selected_bit, negative & ~selected_bit, core
                    result_support, rule = support & ~selected_bit, "guard_satisfied"
                else:
                    result, result_support, rule = ZERO_VIEW, 0, "guard_contradiction"
            elif support & selected_bit == 0:
                result, result_support, rule = value, support, "absent"
            else:
                descriptor = self.src.descriptor(core)
                need(descriptor["kind"] == "ite" and descriptor["variable"] == variable,
                     "cofactor does not select the original branch head")
                child_id = descriptor["high"] if bit else descriptor["low"]
                child = self.cached_core(frame, child_id)
                cp, cn, cc = checked_view(child.output["flat"])
                rp, rn = positive | cp, negative | cn
                result = ZERO_VIEW if (cp, cn, cc) == ZERO_VIEW or rp & rn else (rp, rn, cc)
                # The selected child's validated flat form already proves its
                # bare support. No implicit new-core cache read is needed.
                bare_support = child.output["support"] & ~(cp | cn)
                need((rp | rn) & bare_support == 0, "merged guard overlaps selected core")
                result_support = 0 if result == ZERO_VIEW else rp | rn | bare_support
                rule = "branch"
            need(result_support & ((1 << (variable + 1)) - 1) == 0,
                 "cofactor did not remove the selected variable")
            return {"view": list(result), "support": result_support, "rule": rule}

        return self.j.call("cofactor", {"view": view_ref, "variable": variable_ref, "bit": bit}, body)

    def branch(self, state_ref, variable_ref, bit):
        def body(frame):
            state = self.j.use(frame, state_ref)
            natural(self.j.use(frame, variable_ref), "branch variable", VARIABLES)
            cofactored = []
            # Every occurrence is restricted before any collection, including
            # occurrences that later cancel or share an identical flat view.
            for position in range(len(state)):
                cofactored.append(self.cofactor(state_ref + [position, 0], variable_ref, bit))
            terms = [{"view": value.reference("view"),
                      "coefficient": state_ref + [position, 1]}
                     for position, value in enumerate(cofactored)]
            normalized = self.normalize(terms)
            child = self.state(normalized.reference("state"))
            return {"child_state": normalized.output["state"], "child_ref": child.work_id,
                    "outcome": child.output["outcome"], "proof_id": child.output["proof_id"],
                    "assignment": child.output["assignment"],
                    "nonzero_value": child.output["nonzero_value"]}

        return self.j.call("branch", {"state": state_ref, "variable": variable_ref, "bit": bit}, body)

    def refute_lift(self, variable_ref, bit, branch_id):
        def body(frame):
            variable = natural(self.j.use(frame, variable_ref), "lift variable", VARIABLES)
            child = self.j.use_record(frame, branch_id)
            need(child.operation == "branch" and child.inputs["variable"] == variable_ref
                 and child.inputs["bit"] == bit and child.output["outcome"] == "refuted",
                 "refutation does not match the chosen branch")
            assignment = natural(child.output["assignment"], "child assignment", MASK_LIMIT)
            nonzero = integer(child.output["nonzero_value"], "child nonzero value")
            need(nonzero != 0 and type(bit) is int and bit in (0, 1), "invalid refutation lift")
            selected_bit = 1 << variable
            assignment = assignment | selected_bit if bit else assignment & ~selected_bit
            return {"assignment": assignment, "nonzero_value": nonzero}

        return self.j.call("refute_lift", {
            "variable": variable_ref, "bit": bit, "branch": branch_id}, body)

    def terminal_decide(self, state_ref, selection_ref, total):
        def body(frame):
            self.j.use(frame, state_ref)
            selection = self.j.use(frame, selection_ref)
            value = self.j.argument(frame, total)
            need(selection is None, "terminal decision has nonempty support")
            return {"zero": value == 0, "value": value}
        return self.j.call("terminal_decide", {
            "state": state_ref, "selection": selection_ref, "sum": total}, body)

    def state(self, normalization):
        publication = {}

        def zero_result(rule, children=(), cached_id=None):
            proof_id = len(self.proofs) if cached_id is None else cached_id
            for child in children:
                natural(child, "split child proof ID", proof_id)
            return {"outcome": "zero", "rule": rule, "proof_id": proof_id,
                    "proof_new": cached_id is None, "proof_children": list(children),
                    "assignment": None, "nonzero_value": None}

        def refuted_result(rule, assignment, value):
            natural(assignment, "state refutation assignment", MASK_LIMIT)
            need(integer(value, "state refutation value") != 0, "zero value is not a refutation")
            return {"outcome": "refuted", "rule": rule, "proof_id": None,
                    "proof_new": False, "proof_children": [],
                    "assignment": assignment, "nonzero_value": value}

        def body(frame):
            current = self.j.use(frame, normalization)
            need(len(current) <= 20, "normalized state exceeds the fixed candidate support bound")
            lookup = self.state_lookup(normalization)
            if lookup.output["hit"]:
                return zero_result("cache", cached_id=lookup.output["proof_id"])
            publication["digest"] = lookup.output["digest"]
            support_arg = literal(0)
            for position in range(len(current)):
                support = self.view_support(normalization + [position, 0])
                joined = self.support_join(support_arg, support.reference("support"))
                support_arg = referenced(joined.reference("after"))
            selected = self.select_variable(support_arg)
            variable_ref = selected.reference("variable")
            if selected.output["variable"] is None:
                total = literal(0)
                for position in range(len(current)):
                    # Source-value origins remain explicit scalar arguments.
                    # Zero derived support ensures these bare cores are the
                    # validated constant descriptors, without new evaluation.
                    core_id = current[position][0][2]
                    need(core_id in self.validation, "terminal core lacks validation")
                    source_value = self.validation[core_id].reference("value")
                    product = self.a.scalar("mul", referenced(normalization + [position, 1]),
                                            referenced(source_value))
                    self.j.terminal_observation(product.output["value"])
                    added = self.a.scalar("add", total, referenced(product.reference("value")))
                    self.j.terminal_observation(added.output["value"])
                    total = referenced(added.reference("value"))
                decided = self.terminal_decide(normalization, variable_ref, total)
                if decided.output["zero"]:
                    return zero_result("terminal")
                return refuted_result("terminal", 0, decided.output["value"])
            false_branch = self.branch(normalization, variable_ref, 0)
            if false_branch.output["outcome"] == "refuted":
                lifted = self.refute_lift(variable_ref, 0, false_branch.work_id)
                return refuted_result("refuted_low", lifted.output["assignment"],
                                      lifted.output["nonzero_value"])
            true_branch = self.branch(normalization, variable_ref, 1)
            if true_branch.output["outcome"] == "refuted":
                lifted = self.refute_lift(variable_ref, 1, true_branch.work_id)
                return refuted_result("refuted_high", lifted.output["assignment"],
                                      lifted.output["nonzero_value"])
            need(false_branch.output["outcome"] == true_branch.output["outcome"] == "zero",
                 "split lacks two complete zero children")
            return zero_result("split", (false_branch.output["proof_id"], true_branch.output["proof_id"]))

        result = self.j.call("state", {"normalization": normalization}, body)
        if result.output["proof_new"]:
            same(result.output["proof_id"], len(self.proofs), "new proof completion order")
            self.proofs.append(result)
            self.zero_buckets.setdefault(publication["digest"], []).append(
                (normalization, result.work_id, result.output["proof_id"]))
            self.j.maxima["zero_cache_entries"] = len(self.proofs)
        return result

    def identities(self):
        for candidate in self.candidates:
            free_column = candidate.inputs["free_column"]
            self.j.set_context("identities", free_column)
            terms = [{"view": view.reference("view"),
                      "coefficient": candidate.reference("coefficients", column)}
                     for column, view in enumerate(self.validated_views)]
            normalized = self.normalize(terms)
            root = self.state(normalized.reference("state"))

            def outcome(frame):
                frozen = self.j.use_record(frame, candidate.work_id)
                checked = self.j.use_record(frame, root.work_id)
                need(frozen.operation == "candidate_complete" and checked.operation == "state",
                     "candidate outcome origin")
                return {"free_column": free_column,
                        "outcome": "proved_zero" if checked.output["outcome"] == "zero" else "refuted",
                        "proof_id": checked.output["proof_id"], "assignment": checked.output["assignment"],
                        "nonzero_value": checked.output["nonzero_value"]}

            result = self.j.call("candidate_outcome", {
                "candidate": candidate.work_id, "root_state": root.work_id}, outcome)
            self.outcomes.append(result.output)

    def run(self):
        self.load()
        self.reduce_matrix()
        self.freeze_candidates()
        self.validate_views()
        self.identities()


def verify_header(journal, source):
    """Bind bytes only; source files are never imported or evaluated."""
    base = Path(__file__).resolve().parent.parent
    policies = {
        "program": binding(base / "diagnostics" / "produce_relations.py"),
        "protocol": binding(base / "PROTOCOL.md"),
        "design": binding(base / "DESIGN.md"),
        "schema": binding(base / "schema.json"),
    }
    same(policies["design"]["sha256"], DESIGN_SHA, "fixed v2 design snapshot")
    same(policies["schema"]["sha256"], SCHEMA_SHA, "fixed v2 schema snapshot")
    same(policies["protocol"]["sha256"], PROTOCOL_SHA, "fixed v2 implementation protocol")
    header = journal.header
    need(set(header) == {"kind", "version", "input_bindings", "policy_bindings", "limits"},
         "header field set")
    same(header["kind"], "header", "header kind")
    same(header["version"], "exact-guarded-relations-v2", "header version")
    for group, expected in (("input_bindings", {"trace": source.trace_binding, "sample": source.sample_binding}),
                            ("policy_bindings", policies)):
        observed = header[group]
        need(type(observed) is dict and set(observed) == set(expected), group + " fields")
        for name, actual in expected.items():
            item = observed[name]
            need(type(item) is dict and set(item) == {"path", "bytes", "sha256"}, "byte-binding shape")
            need(type(item["path"]) is str and Path(item["path"]).is_absolute(), "snapshot path metadata")
            natural(item["bytes"], "snapshot byte length")
            same(item["bytes"], actual["bytes"], group + "." + name + " bytes")
            same(item["sha256"], actual["sha256"], group + "." + name + " SHA256")
    same(header["limits"], {"charged_request_cap": CAP, "wall_seconds": 30,
                            "cpu_seconds": 30, "cpu_count": 1,
                            "address_space_bytes": 1073741824}, "fixed diagnostic limits")
    return policies


def verify_footer(journal, controller, footer, completed, location):
    if completed:
        need(not journal.stack and len(controller.candidates) == 16 and len(controller.outcomes) == 16,
             "completed footer lacks the entire fixed candidate batch")
        status, error = "completed_fixed_batch", None
    else:
        need(location == "start" and journal.started == CAP,
             "request-cap footer does not precede exactly request 50001")
        status = "request_cap"
        error = {"type": "LimitReached", "message": "charged request cap 50000 reached before next request"}
    expected = {
        "kind": "footer", "status": status, "charged_starts": journal.started,
        "completed_requests": len(journal.completed),
        "pending_stack": [frame.work_id for frame in journal.stack],
        "physical_records": journal.lines,
        "operation_counts": journal.counts, "cache_counts": journal.cache_counts,
        "phase": journal.context, "rref_pivots": controller.pivots,
        "candidate_outcomes": controller.outcomes, "maxima": journal.maxima,
        "error": error,
    }
    same(footer, expected, "complete accounting footer")
    need(journal.stream.read() == "", "trailing records after footer")
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--sample", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    began = time.monotonic()
    journal = controller = source = None
    report = {"status": "rejected", "qualification": "No relation or count claim is accepted."}
    exit_code = 1
    try:
        source = RawInputs(args.trace, args.sample)
        journal = Journal(args.certificate)
        policies = verify_header(journal, source)
        controller = Controller(source, journal)
        try:
            controller.run()
        except EndOfPrefix as prefix:
            producer_status = verify_footer(journal, controller, prefix.footer, False, prefix.location)
        else:
            producer_status = verify_footer(journal, controller, journal.read(), True, None)
        report = {
            "status": "passed",
            "qualification": (
                "The exact fixed transcript is independently checked. Only completed proved_zero outcomes "
                "establish the explicit signed identities over the original guarded descriptors; refutations "
                "apply only to their individual candidates. A cap prefix proves nothing about unfinished "
                "candidates. This is diagnostic evidence, not a Lean rank theorem, queens count, or n16 result."),
            "producer_status": producer_status,
            "charged_starts": journal.started,
            "completed_requests": len(journal.completed),
            "pending_requests": [frame.work_id for frame in journal.stack],
            "physical_records": journal.lines,
            "operation_counts": journal.counts,
            "cache_counts": journal.cache_counts,
            "phase": journal.context,
            "rref_pivots": controller.pivots,
            "candidate_outcomes": controller.outcomes,
            "completed_candidate_proposals": len(controller.candidates),
            "new_zero_proofs": len(controller.proofs),
            "validated_original_nodes": len(controller.validation),
            "maxima": journal.maxima,
            "input_bindings": {"trace": source.trace_binding, "sample": source.sample_binding,
                               "certificate": binding(args.certificate)},
            "policy_bindings": policies,
            "replayer": binding(Path(__file__).resolve()),
            "source_preparation": {"parsed_records": source.parsed_records,
                                   "semantic_processing_before_tickets": False},
            "checks": {
                "fixed_sample_positions_and_schedule": True,
                "exact_scalar_and_rational_arithmetic": True,
                "all_candidates_frozen_before_identities": True,
                "selected_original_descriptors_validated": bool(controller.validated_views)
                    and len(controller.validated_views) == COLUMNS,
                "no_producer_or_evaluator_import": True,
                "exact_occurrence_collection_and_full_view_cache": True,
                "completed_dependencies_and_proof_children": True,
                "pending_results_never_published": True,
                "every_started_record_accounted": True,
                "sample_values_not_global_identity_premises": True,
                "no_new_sample_or_board_count": True,
            },
        }
        exit_code = 0
    except Exception as error:
        report.update({"error": {"type": type(error).__name__, "message": str(error)},
                       "qualification": (
                           "Replay did not accept the whole transcript or a completely framed cap prefix. "
                           "The retained bytes are failure evidence, not a new identity, rank, or count claim.")})
        if journal is not None:
            report.update({"charged_starts": journal.started,
                           "completed_requests": len(journal.completed),
                           "pending_requests": [frame.work_id for frame in journal.stack],
                           "physical_records": journal.lines})
    finally:
        if journal is not None:
            journal.stream.close()
    report["seconds"] = time.monotonic() - began
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

