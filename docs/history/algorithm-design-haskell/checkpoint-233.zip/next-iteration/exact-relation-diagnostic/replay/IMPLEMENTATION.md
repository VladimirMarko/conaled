# Independent exact-relation replayer

**Status: independently reviewed and executed once; the complete fixed transcript passed.**

All sixteen candidate roots are refuted. See `../RESULTS.md`. The implementation
preparation statements below describe the period before that recorded run.

`replay_relations.py` implements the fixed v2 protocol. Its CLI is
`--trace --sample --certificate --output`. The intended execution is exclusively
through the parent's bounded snapshot runner after review and authorization.
No producer, evaluator, algebra package, or prior checker is imported.

The controller reconstructs the exact recorded schedule: 35 view loads and the
19-by-35 sample matrix; fixed rational row reduction; all 16 candidate proposals
before source validation; original guarded descriptor validation; occurrence
preserving signed collection; charged exact cache comparisons; and full Boolean
case proofs or individually refuted candidates. Scalar/rational results, input
origins, completion ordering, cache publication, proof IDs, pending stacks,
counters and maxima are compared with the transcript. Every local check occurs
after consuming the corresponding work record. The prior cut replayer was read
only to confirm the original descriptor schema and its flat-view semantics; it
is neither imported nor invoked.

A successful exit requires either the complete fixed batch or a completely
framed request-cap prefix at exactly 50,000 starts. A cap does not accept pending
results. Other failure footers, malformed input and physically truncated logs
are conservatively rejected and retained rather than promoted to relation
evidence. The report distinguishes `status`, `producer_status` and
`qualification`, and exposes `pending_requests` for the parent's runner.

The sample matrix proposes coefficients only. A completed zero outcome depends
on the exact original guarded functions and both Boolean cases. A refutation
applies only to its own candidate; even 16 refutations would not prove global
rank 35. No count, Lean rank theorem or n16 result follows from this source file.

The only preparation was AST parsing, a static import/dynamic-execution check,
and byte hashing. No candidate arithmetic, semantic traversal, evaluation,
producer, replay, counter or Lean compiler was executed. Exact source and policy
identities are in `preparation.json`. Before any run, the parent and independent
reviewer must inspect the actual source/control versions. Any correction must
preserve the reviewed predecessor and explain its change.

Frozen source: 59,259 bytes,
SHA256 `029ad7a95d6d37c66b53b9d78fb1e3d6a341852eb7596491dda314700c617cbc`.

Fixed implementation protocol: 21,029 bytes,
SHA256 `28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147`.
