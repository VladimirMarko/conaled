#!/usr/bin/env python3
"""Untrusted, explicitly metered fixed proposals and guarded-function identities.

This program has not been executed during implementation.  It proves no Lean
theorem and uses no expected queens count.  A separate implementation replays
its local arithmetic, source and relation records.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import time


VERSION = "exact-guarded-relations-v2"
CAP, VARIABLES, ROWS, COLS = 50_000, 210, 19, 35
ZERO = [0, 0, 0]
Y = [171, 174, 175, 177, 186, 187, 189, 191, 192, 193, 195, 200, 202, 203, 206, 208]
Y_MASK = sum(1 << v for v in Y)
SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
SAMPLE_SHA = "ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2"
KINDS = [
    "view_load", "matrix_load", "pivot_probe", "row_swap", "cell_swap",
    "eliminate_probe", "pivot_commit", "rref_entry", "rref_complete",
    "int_scalar", "rat_mul", "rat_sub", "rat_div", "rat_normalize", "gcd_step",
    "candidate_entry", "candidate_complete", "validate", "view_validate",
    "normalize", "term_add", "term_compare", "state", "state_lookup",
    "cache_candidate", "cache_term", "view_support", "support_join",
    "select_variable", "branch", "cofactor", "terminal_decide",
    "refute_lift", "candidate_outcome",
]
MAXIMA = ["numerator_bits", "denominator_bits", "candidate_coefficient_bits",
          "state_coefficient_bits", "terminal_integer_bits", "state_terms",
          "pending_depth", "zero_cache_entries"]


class LimitReached(RuntimeError):
    pass


class FixtureRejected(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise FixtureRejected(message)


def integer(value):
    require(type(value) is int, "expected an integer")
    return value


def natural(value):
    require(integer(value) >= 0, "expected a natural number")
    return value


def binding(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def ref(ticket, field, *indices):
    return [ticket, field, *indices]


def ra(reference):
    return {"ref": reference}


def lit(value):
    return {"literal": value}


def arg_ids(*args):
    return [a["ref"][0] for a in args if a is not None and "ref" in a]


class Meter:
    def __init__(self, stream):
        self.stream = stream
        self.charged = self.completed = self.physical = 0
        self.stack = []
        self.outputs = {}
        self.counts = dict.fromkeys(KINDS, 0)
        self.cache_counts = {k: {"hits": 0, "misses": 0} for k in ("validate", "zero_state")}
        self.context = {"phase": "load", "candidate": None}
        self.maxima = dict.fromkeys(MAXIMA, 0)

    def write(self, record):
        self.stream.write(json.dumps(record, separators=(",", ":"), ensure_ascii=True) + "\n")
        self.stream.flush()
        self.physical += 1

    def begin(self, operation, inputs):
        if self.charged == CAP:
            raise LimitReached("charged request cap 50000 reached before next request")
        require(operation in self.counts, "unknown request kind")
        ticket = self.charged
        self.charged += 1
        self.counts[operation] += 1
        self.stack.append({"id": ticket, "children": []})
        self.maxima["pending_depth"] = max(self.maxima["pending_depth"], len(self.stack))
        self.write({"kind": "work", "id": ticket, "operation": operation,
                    "inputs": inputs, "context": dict(self.context)})
        return ticket

    def finish(self, ticket, output, explicit=()):
        require(self.stack and self.stack[-1]["id"] == ticket, "non-nested completion")
        dependencies = list(explicit) + self.stack[-1]["children"]
        require(all(i in self.outputs for i in dependencies), "unfinished dependency")
        self.write({"kind": "done", "id": ticket, "finish": self.completed,
                    "dependencies": dependencies, "output": output})
        self.stack.pop()
        self.outputs[ticket] = output
        self.completed += 1
        if self.stack:
            self.stack[-1]["children"].append(ticket)
        return ticket

    def get(self, reference):
        require(type(reference) is list and len(reference) >= 2, "malformed reference")
        ticket, field, *indices = reference
        require(type(ticket) is int and ticket in self.outputs and type(field) is str,
                "reference is not to completed output")
        value = self.outputs[ticket][field]
        for index in indices:
            natural(index)
            require(type(value) is list and index < len(value), "reference selector out of bounds")
            value = value[index]
        return value

    def arg(self, argument):
        require(type(argument) is dict, "malformed integer argument")
        if set(argument) == {"literal"}:
            return integer(argument["literal"])
        require(set(argument) == {"ref"}, "malformed integer argument fields")
        return integer(self.get(argument["ref"]))

    def rational(self, reference):
        value = self.get(reference)
        require(type(value) is list and len(value) == 2, "malformed rational")
        integer(value[0])
        require(natural(value[1]) > 0, "nonpositive rational denominator")
        return value

    def rational_max(self, value):
        self.maxima["numerator_bits"] = max(self.maxima["numerator_bits"], value[0].bit_length())
        self.maxima["denominator_bits"] = max(self.maxima["denominator_bits"], value[1].bit_length())

    def count_cache(self, name, hit):
        self.cache_counts[name]["hits" if hit else "misses"] += 1


def prepare(trace_path, sample_path):
    """Bytes and raw index only.  No support, rational, cofactor or identity work."""
    started = time.monotonic()
    tb, sb = binding(trace_path), binding(sample_path)
    require(tb["sha256"] == SOURCE_SHA and sb["sha256"] == SAMPLE_SHA, "fixed input hash differs")
    raw = defaultdict(list)
    records = 0
    with trace_path.open() as stream:
        for line in stream:
            record = json.loads(line)
            records += 1
            if record.get("type") == "node":
                raw[record.get("id")].append(record)
    sample = json.loads(sample_path.read_text())
    return raw, sample, {"trace": tb, "sample": sb}, {
        "seconds": time.monotonic() - started, "raw_records": records,
        "semantic_processing": False,
    }


class Relations:
    def __init__(self, meter, raw, sample):
        self.m, self.raw, self.sample = meter, raw, sample
        self.views = []
        self.matrix = [[None] * COLS for _ in range(ROWS)]
        self.pivots, self.free, self.commits = [], [], []
        self.pivot_row = {}
        self.rref_id = None
        self.candidates, self.candidate_columns = [], []
        self.valid = {}
        self.zero_id = None
        self.view_validations = []
        self.buckets = defaultdict(list)
        self.proof_count = 0
        self.outcomes = []

    def phase(self, phase, candidate=None):
        self.m.context = {"phase": phase, "candidate": candidate}

    def scalar(self, op, a, b=None):
        t = self.m.begin("int_scalar", {"op": op, "a": a, "b": b})
        av = self.m.arg(a)
        if op in ("neg", "abs"):
            require(b is None, "unary scalar argument")
            value = -av if op == "neg" else abs(av)
        else:
            require(b is not None, "missing binary scalar argument")
            bv = self.m.arg(b)
            if op == "add":
                value = av + bv
            elif op == "sub":
                value = av - bv
            elif op == "mul":
                value = av * bv
            elif op == "divmod":
                require(bv > 0, "divmod divisor must be positive")
                value = list(divmod(av, bv))
            else:
                raise FixtureRejected("unknown scalar operation")
        self.m.finish(t, {"value": value}, arg_ids(a, b))
        return ref(t, "value")

    def gcd_step(self, x, y):
        t = self.m.begin("gcd_step", {"x": x, "y": y})
        xv, yv = self.m.arg(x), self.m.arg(y)
        require(xv >= 0 and yv >= 0, "negative gcd argument")
        if yv == 0:
            out = {"terminal": True, "quotient": None, "remainder": None}
        else:
            q, r = divmod(xv, yv)
            out = {"terminal": False, "quotient": q, "remainder": r}
        self.m.finish(t, out, arg_ids(x, y))
        return t

    def rat_normalize(self, numerator, denominator):
        t = self.m.begin("rat_normalize", {"numerator": numerator, "denominator": denominator})
        original = arg_ids(numerator, denominator)
        n, d = self.m.arg(numerator), self.m.arg(denominator)
        require(d != 0, "zero rational denominator")
        if d < 0:
            numerator = ra(self.scalar("neg", numerator))
            denominator = ra(self.scalar("neg", denominator))
            n, d = self.m.arg(numerator), self.m.arg(denominator)
        if n == 0:
            value, rule = [0, 1], "zero"
        elif d == 1:
            value, rule = [n, 1], "denominator_one"
        else:
            x, y = ra(self.scalar("abs", numerator)), denominator
            while True:
                step = self.gcd_step(x, y)
                if self.m.outputs[step]["terminal"]:
                    break
                x, y = y, ra(ref(step, "remainder"))
            nr = self.scalar("divmod", numerator, x)
            dr = self.scalar("divmod", denominator, x)
            nq, remn = self.m.get(nr)
            dq, remd = self.m.get(dr)
            require(remn == 0 and remd == 0 and dq > 0, "nonexact rational normalization")
            value, rule = [nq, dq], "gcd"
        self.m.finish(t, {"value": value, "rule": rule}, original)
        self.m.rational_max(value)
        return ref(t, "value")

    def rat(self, operation, a, b):
        t = self.m.begin(operation, {"a": a, "b": b})
        av, bv = self.m.rational(a), self.m.rational(b)
        if operation == "rat_mul":
            if av[0] == 0 or bv[0] == 0:
                value, rule = [0, 1], "zero"
            elif av == [1, 1]:
                value, rule = bv[:], "left_unit"
            elif bv == [1, 1]:
                value, rule = av[:], "right_unit"
            else:
                n = self.scalar("mul", ra(a + [0]), ra(b + [0]))
                d = self.scalar("mul", ra(a + [1]), ra(b + [1]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        elif operation == "rat_sub":
            if bv[0] == 0:
                value, rule = av[:], "right_zero"
            elif av == bv:
                value, rule = [0, 1], "equal"
            elif av[0] == 0:
                n = self.scalar("neg", ra(b + [0]))
                value, rule = [self.m.get(n), bv[1]], "left_zero"
            elif av[1] == bv[1]:
                n = self.scalar("sub", ra(a + [0]), ra(b + [0]))
                value = self.m.get(self.rat_normalize(ra(n), ra(a + [1])))
                rule = "equal_denominator"
            else:
                left = self.scalar("mul", ra(a + [0]), ra(b + [1]))
                right = self.scalar("mul", ra(b + [0]), ra(a + [1]))
                n = self.scalar("sub", ra(left), ra(right))
                d = self.scalar("mul", ra(a + [1]), ra(b + [1]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        else:
            require(operation == "rat_div" and bv[0] != 0, "unknown operation or zero rational divisor")
            if av[0] == 0:
                value, rule = [0, 1], "zero"
            elif bv == [1, 1]:
                value, rule = av[:], "unit_divisor"
            elif av == bv:
                value, rule = [1, 1], "equal"
            else:
                n = self.scalar("mul", ra(a + [0]), ra(b + [1]))
                d = self.scalar("mul", ra(a + [1]), ra(b + [0]))
                value, rule = self.m.get(self.rat_normalize(ra(n), ra(d))), "general"
        self.m.finish(t, {"value": value, "rule": rule}, [a[0], b[0]])
        self.m.rational_max(value)
        return ref(t, "value")

    def load(self):
        self.phase("load")
        for column in range(COLS):
            saved = self.sample["grouping"]["b_views"][column]
            t = self.m.begin("view_load", {"column": column, "saved_view": saved})
            require(len(self.sample["grouping"]["b_views"]) == COLS, "view dimension mismatch")
            require(type(saved) is list and len(saved) == 3, "malformed saved view")
            for item in saved:
                natural(item)
            self.m.finish(t, {"view": saved[:]})
            self.views.append(ref(t, "view"))
        for row in range(ROWS):
            for column in range(COLS):
                rows = self.sample["sides"]["B"]["sample_rows"]
                saved = rows[row]["nat_values"][column]
                t = self.m.begin("matrix_load", {"row": row, "column": column, "saved_nat": saved})
                require(len(rows) == ROWS and len(rows[row]["nat_values"]) == COLS, "matrix dimension mismatch")
                value = [natural(saved), 1]
                self.m.finish(t, {"value": value})
                self.m.rational_max(value)
                self.matrix[row][column] = ref(t, "value")

    def row_swap(self, a, b):
        t = self.m.begin("row_swap", {"row_a": a, "row_b": b})
        for column in range(COLS):
            ar, br = self.matrix[a][column], self.matrix[b][column]
            c = self.m.begin("cell_swap", {"column": column, "cell_a": ar, "cell_b": br})
            av, bv = self.m.rational(ar), self.m.rational(br)
            self.m.finish(c, {"new_a": bv[:], "new_b": av[:]}, [ar[0], br[0]])
            self.m.rational_max(av)
            self.m.rational_max(bv)
            self.matrix[a][column], self.matrix[b][column] = ref(c, "new_a"), ref(c, "new_b")
        self.m.finish(t, {"row_a_refs": [x[:] for x in self.matrix[a]],
                          "row_b_refs": [x[:] for x in self.matrix[b]]})

    def rref(self):
        self.phase("rref")
        row = 0
        for column in range(COLS):
            selected = None
            for candidate_row in range(row, ROWS):
                cell = self.matrix[candidate_row][column]
                t = self.m.begin("pivot_probe", {"row": candidate_row, "column": column, "cell": cell})
                nonzero = self.m.rational(cell)[0] != 0
                self.m.finish(t, {"nonzero": nonzero}, [cell[0]])
                if nonzero:
                    selected = candidate_row
                    break
            if selected is None:
                self.free.append(column)
                continue
            if selected != row:
                self.row_swap(row, selected)
            pivot = self.matrix[row][column]
            for j in range(COLS):
                self.matrix[row][j] = self.rat("rat_div", self.matrix[row][j], pivot)
            for target_row in range(ROWS):
                if target_row == row:
                    continue
                cell = self.matrix[target_row][column]
                t = self.m.begin("eliminate_probe", {"row": target_row, "pivot_column": column, "cell": cell})
                value = self.m.rational(cell)
                skip = value[0] == 0
                self.m.finish(t, {"skip": skip, "factor": value[:]}, [cell[0]])
                if skip:
                    continue
                factor = ref(t, "factor")
                for j in range(COLS):
                    product = self.rat("rat_mul", factor, self.matrix[row][j])
                    self.matrix[target_row][j] = self.rat("rat_sub", self.matrix[target_row][j], product)
            t = self.m.begin("pivot_commit", {"row": row, "column": column,
                                               "row_cell_refs": [x[:] for x in self.matrix[row]]})
            self.m.finish(t, {"pivot_index": row}, [x[0] for x in self.matrix[row]])
            self.commits.append(t)
            self.pivots.append(column)
            self.pivot_row[column] = row
            row += 1
        checks = []
        all_matches = True
        for r in range(ROWS):
            for c in range(COLS):
                cell = self.matrix[r][c]
                pr = self.pivot_row.get(c)
                t = self.m.begin("rref_entry", {"row": r, "column": c, "cell": cell, "pivot_row": pr})
                value = self.m.rational(cell)
                matches = pr is None or value == [int(r == pr), 1]
                self.m.finish(t, {"matches": matches}, [cell[0]])
                all_matches = all_matches and matches
                checks.append(t)
        t = self.m.begin("rref_complete", {"current_cell_refs": [[x[:] for x in r] for r in self.matrix],
                                            "pivot_columns": self.pivots[:], "entry_check_refs": checks})
        matches = all_matches and len(self.pivots) == ROWS and len(self.free) == COLS - ROWS
        self.m.finish(t, {"free_columns": self.free[:], "matches": matches}, checks + self.commits)
        require(matches, "fixed RREF shape or identity pattern differs")
        self.rref_id = t

    def propose(self):
        for free_column in self.free:
            self.phase("candidates", free_column)
            scale_arg = lit(1)
            for row in range(ROWS):
                scale = self.scalar("mul", scale_arg, ra(self.matrix[row][free_column] + [1]))
                scale_arg = ra(scale)
            entries = []
            for column in range(COLS):
                pr = self.pivot_row.get(column)
                role = "free_target" if column == free_column else "pivot" if pr is not None else "other_free"
                cell = self.matrix[pr][free_column] if pr is not None else None
                t = self.m.begin("candidate_entry", {"free_column": free_column, "column": column,
                                                      "scale": scale, "rref_cell": cell, "role": role})
                scale_value = self.m.get(scale)
                require(scale_value > 0, "nonpositive candidate scale")
                rule = role
                if role == "free_target":
                    coefficient = scale_value
                elif role == "other_free":
                    coefficient = 0
                elif self.m.rational(cell)[0] == 0:
                    coefficient, rule = 0, "pivot_zero"
                else:
                    quotient = self.scalar("divmod", ra(scale), ra(cell + [1]))
                    require(self.m.get(quotient)[1] == 0, "candidate denominator does not divide product")
                    product = self.scalar("mul", ra(cell + [0]), ra(quotient + [0]))
                    coefficient = self.m.get(self.scalar("neg", ra(product)))
                self.m.finish(t, {"coefficient": coefficient, "rule": rule},
                              [scale[0]] + ([] if cell is None else [cell[0]]))
                self.m.maxima["candidate_coefficient_bits"] = max(
                    self.m.maxima["candidate_coefficient_bits"], coefficient.bit_length())
                entries.append(ref(t, "coefficient"))
            t = self.m.begin("candidate_complete", {"free_column": free_column, "scale": scale,
                                                     "entry_refs": entries, "rref_complete": self.rref_id})
            coefficients = [self.m.get(e) for e in entries]
            positive = coefficients[free_column] > 0
            self.m.finish(t, {"coefficients": coefficients, "positive_target": positive},
                          [scale[0]] + [e[0] for e in entries] + [self.rref_id])
            require(positive, "candidate target not positive")
            self.candidates.append(t)
            self.candidate_columns.append(free_column)

    def record(self, node):
        records = self.raw.get(node, [])
        require(len(records) == 1, "missing or duplicate selected source definition")
        return records[0]

    def info(self, node):
        require(node in self.valid, "unvalidated source read")
        return self.valid[node]

    def validate(self, node):
        t = self.m.begin("validate", {"source_node_id": node})
        natural(node)
        if node in self.valid:
            info, prior = self.valid[node]
            self.m.count_cache("validate", True)
            self.m.finish(t, {**info, "cache_hit": True, "prior": prior}, [prior])
            return t
        self.m.count_cache("validate", False)
        r = self.record(node)
        require(r.get("type") == "node" and natural(r["id"]) == node, "source node binding")
        kind, value = r["kind"], None
        if kind == "constant":
            value = natural(r["value"])
            support, flat = 0, [0, 0, node]
        elif kind == "ite":
            v, low, high = natural(r["variable"]), natural(r["low"]), natural(r["high"])
            require(v < VARIABLES and low < node and high < node, "source branch bounds/order")
            low_id, high_id = self.validate(low), self.validate(high)
            child_support = self.m.outputs[low_id]["support"] | self.m.outputs[high_id]["support"]
            require(child_support & ((1 << (v + 1)) - 1) == 0, "source variable order")
            support, flat = (1 << v) | child_support, [0, 0, node]
        elif kind == "guard":
            p, n, core = natural(r["positive"]), natural(r["negative"]), natural(r["core"])
            require(p < 1 << VARIABLES and n < 1 << VARIABLES and core < node, "source guard bounds")
            require(p | n and p & n == 0, "source guard conflict or empty guard")
            child_id = self.validate(core)
            child = self.m.outputs[child_id]
            require(child["node_kind"] != "guard" and (p | n) & child["support"] == 0,
                    "source guard/core overlap or nested guard")
            support, flat = p | n | child["support"], [p, n, core]
        else:
            raise FixtureRejected("unsupported original node kind")
        require(node != 0 or (kind == "constant" and value == 0), "source node0 is not zero")
        info = {"node_kind": kind, "support": support, "flat": flat, "value": value}
        self.m.finish(t, {**info, "cache_hit": False, "prior": None})
        self.valid[node] = (info, t)
        return t

    def check_view(self, view, info):
        require(type(view) is list and len(view) == 3, "malformed view")
        p, n, core = (natural(x) for x in view)
        require(p < 1 << VARIABLES and n < 1 << VARIABLES and info["node_kind"] != "guard",
                "view bounds or nonbare core")
        require(p & n == 0 and (p | n) & info["support"] == 0, "view support conflict")
        support = p | n | info["support"]
        require(support & ~Y_MASK == 0, "view support outside fixed side")
        return support

    def validate_selected(self):
        self.phase("validate")
        self.zero_id = self.validate(0)
        for column, load in enumerate(self.views):
            view = self.m.get(load)
            t = self.m.begin("view_validate", {"column": column, "view": view, "load": load})
            child = self.validate(view[2])
            support = self.check_view(view, self.m.outputs[child])
            self.m.finish(t, {"view": view[:], "support": support, "inside_y": True},
                          [load[0], self.zero_id])
            self.view_validations.append(t)

    def term_add(self, accumulator, view, coefficient):
        t = self.m.begin("term_add", {"accumulator": accumulator, "view": view, "coefficient": coefficient})
        before = [] if accumulator is None else self.m.get(accumulator)
        incoming, c = self.m.get(view), integer(self.m.get(coefficient))
        out = before[:]
        if c == 0:
            rule = "zero_coefficient"
        elif incoming == ZERO:
            rule = "zero_view"
        else:
            rule = "append"
            for position in range(len(before)):
                existing = accumulator + [position, 0]
                compare = self.m.begin("term_compare", {"incoming": view, "existing": existing})
                ev = self.m.get(existing)
                order = -1 if incoming < ev else 1 if incoming > ev else 0
                self.m.finish(compare, {"order": order}, [view[0], existing[0]])
                if order < 0:
                    out.insert(position, [incoming[:], c])
                    rule = "insert"
                    break
                if order == 0:
                    summed = self.scalar("add", ra(accumulator + [position, 1]), ra(coefficient))
                    combined = self.m.get(summed)
                    if combined == 0:
                        out.pop(position)
                        rule = "cancel"
                    else:
                        out[position] = [incoming[:], combined]
                        rule = "combine"
                    break
            if rule == "append":
                out.append([incoming[:], c])
        require(len(out) <= 20, "relation state exceeds fixed term bound")
        self.m.finish(t, {"state": out, "rule": rule},
                      ([] if accumulator is None else [accumulator[0]]) + [view[0], coefficient[0]])
        self.m.maxima["state_terms"] = max(self.m.maxima["state_terms"], len(out))
        if rule in ("insert", "append"):
            self.m.maxima["state_coefficient_bits"] = max(self.m.maxima["state_coefficient_bits"], c.bit_length())
        elif rule == "combine":
            self.m.maxima["state_coefficient_bits"] = max(
                self.m.maxima["state_coefficient_bits"], combined.bit_length())
        return ref(t, "state")

    def normalize(self, terms):
        t = self.m.begin("normalize", {"terms": terms})
        acc = None
        explicit = []
        for term in terms:
            explicit.extend([term["view"][0], term["coefficient"][0]])
            acc = self.term_add(acc, term["view"], term["coefficient"])
        state = [] if acc is None else self.m.get(acc)
        self.m.finish(t, {"state": state}, explicit)
        return ref(t, "state")

    def state_lookup(self, state_ref):
        t = self.m.begin("state_lookup", {"state": state_ref})
        state = self.m.get(state_ref)
        encoded = json.dumps(state, separators=(",", ":"), ensure_ascii=True).encode("ascii")
        digest = hashlib.sha256(encoded).hexdigest()
        found = None
        for entry in self.buckets.get(digest, []):
            previous = entry["state_ref"]
            c = self.m.begin("cache_candidate", {"state": state_ref, "prior_state": previous,
                                                  "prior_zero": entry["work"], "prior_proof": entry["proof"]})
            other = self.m.get(previous)
            equal = len(state) == len(other)
            if equal:
                for position in range(len(state)):
                    current_term, cached_term = state_ref + [position], previous + [position]
                    e = self.m.begin("cache_term", {"current": current_term, "cached": cached_term})
                    equal = self.m.get(current_term) == self.m.get(cached_term)
                    self.m.finish(e, {"equal": equal}, [current_term[0], cached_term[0]])
                    if not equal:
                        break
            self.m.finish(c, {"equal": equal}, [state_ref[0], previous[0], entry["work"]])
            if equal:
                found = entry
                break
        hit = found is not None
        self.m.count_cache("zero_state", hit)
        output = {"hit": hit, "prior": found["work"] if hit else None,
                  "proof_id": found["proof"] if hit else None, "digest": digest}
        self.m.finish(t, output, [state_ref[0]])
        return t

    def view_support(self, view_ref):
        t = self.m.begin("view_support", {"view": view_ref})
        view = self.m.get(view_ref)
        info, validation = self.info(view[2])
        support = self.check_view(view, info)
        self.m.finish(t, {"support": support}, [view_ref[0], validation])
        return ref(t, "support")

    def join_support(self, before, support):
        t = self.m.begin("support_join", {"before": before, "term_support": support})
        a, b = natural(self.m.arg(before)), natural(self.m.get(support))
        require(a < 1 << VARIABLES and b < 1 << VARIABLES, "support mask bound")
        self.m.finish(t, {"after": a | b}, arg_ids(before) + [support[0]])
        return ref(t, "after")

    def select_variable(self, support):
        t = self.m.begin("select_variable", {"support": support})
        value = natural(self.m.arg(support))
        require(value < 1 << VARIABLES, "support selection mask bound")
        variable = None if value == 0 else (value & -value).bit_length() - 1
        self.m.finish(t, {"variable": variable}, arg_ids(support))
        return ref(t, "variable")

    def cofactor(self, view_ref, variable_ref, bit):
        t = self.m.begin("cofactor", {"view": view_ref, "variable": variable_ref, "bit": bit})
        view, v = self.m.get(view_ref), natural(self.m.get(variable_ref))
        require(v < VARIABLES and type(bit) is int and bit in (0, 1), "cofactor variable/bit")
        p, n, core = view
        info, validation = self.info(core)
        support = self.check_view(view, info)
        deps = [view_ref[0], variable_ref[0], validation, self.zero_id]
        require(support & ((1 << v) - 1) == 0, "cofactor below least variable")
        mark = 1 << v
        if view == ZERO:
            rule, result, remaining = "zero", ZERO[:], 0
        elif p & mark:
            if bit:
                rule, result, remaining = "guard_satisfied", [p ^ mark, n, core], support ^ mark
            else:
                rule, result, remaining = "guard_contradiction", ZERO[:], 0
        elif n & mark:
            if bit:
                rule, result, remaining = "guard_contradiction", ZERO[:], 0
            else:
                rule, result, remaining = "guard_satisfied", [p, n ^ mark, core], support ^ mark
        elif not support & mark:
            rule, result, remaining = "absent", view[:], support
        else:
            source = self.record(core)
            require(source["kind"] == "ite" and source["variable"] == v, "cofactor branch mismatch")
            child = source["high"] if bit else source["low"]
            child_info, child_validation = self.info(child)
            deps.append(child_validation)
            cp, cn, cc = child_info["flat"]
            pp, nn = p | cp, n | cn
            if child_info["flat"] == ZERO or pp & nn:
                result, remaining = ZERO[:], 0
            else:
                bare_support = child_info["support"] & ~(cp | cn)
                require((pp | nn) & bare_support == 0, "merged cofactor guard/core overlap")
                result, remaining = [pp, nn, cc], pp | nn | bare_support
            rule = "branch"
        require(remaining & ((1 << (v + 1)) - 1) == 0 and remaining & ~Y_MASK == 0,
                "cofactor did not reduce supported variables")
        self.m.finish(t, {"view": result, "support": remaining, "rule": rule}, deps)
        return ref(t, "view")

    def branch(self, state_ref, variable, bit):
        t = self.m.begin("branch", {"state": state_ref, "variable": variable, "bit": bit})
        state = self.m.get(state_ref)
        cofactors = []
        for position in range(len(state)):
            cofactors.append(self.cofactor(state_ref + [position, 0], variable, bit))
        terms = [{"view": c, "coefficient": state_ref + [i, 1]} for i, c in enumerate(cofactors)]
        normalized = self.normalize(terms)
        child = self.prove_state(normalized)
        result = self.m.outputs[child]
        self.m.finish(t, {"child_state": self.m.get(normalized), "child_ref": child,
                          "outcome": result["outcome"], "proof_id": result["proof_id"],
                          "assignment": result["assignment"], "nonzero_value": result["nonzero_value"]},
                      [state_ref[0], variable[0]])
        return t

    def refute_lift(self, variable, bit, branch):
        t = self.m.begin("refute_lift", {"variable": variable, "bit": bit, "branch": branch})
        v = natural(self.m.get(variable))
        child = self.m.outputs[branch]
        require(child["outcome"] == "refuted" and child["nonzero_value"] != 0,
                "refutation lift needs completed nonzero child")
        assignment = natural(child["assignment"])
        require(v < VARIABLES and assignment < 1 << VARIABLES and bit in (0, 1), "refutation bound")
        assignment = (assignment | (1 << v)) if bit else (assignment & ~(1 << v))
        self.m.finish(t, {"assignment": assignment, "nonzero_value": child["nonzero_value"]},
                      [variable[0], branch])
        return t

    def prove_state(self, state_ref):
        t = self.m.begin("state", {"normalization": state_ref})
        state = self.m.get(state_ref)
        lookup_id = self.state_lookup(state_ref)
        lookup = self.m.outputs[lookup_id]
        if lookup["hit"]:
            output = {"outcome": "zero", "rule": "cache", "proof_id": lookup["proof_id"],
                      "proof_new": False, "proof_children": [], "assignment": None, "nonzero_value": None}
        else:
            support = lit(0)
            for position in range(len(state)):
                term_support = self.view_support(state_ref + [position, 0])
                support = ra(self.join_support(support, term_support))
            variable = self.select_variable(support)
            if self.m.get(variable) is None:
                summed = lit(0)
                for position, term in enumerate(state):
                    validation = self.info(term[0][2])[1]
                    product = self.scalar("mul", ra(state_ref + [position, 1]), ra(ref(validation, "value")))
                    self.m.maxima["terminal_integer_bits"] = max(
                        self.m.maxima["terminal_integer_bits"], self.m.get(product).bit_length())
                    total = self.scalar("add", summed, ra(product))
                    self.m.maxima["terminal_integer_bits"] = max(
                        self.m.maxima["terminal_integer_bits"], self.m.get(total).bit_length())
                    summed = ra(total)
                terminal = self.m.begin("terminal_decide", {"state": state_ref, "selection": variable, "sum": summed})
                value = self.m.arg(summed)
                zero = value == 0
                self.m.finish(terminal, {"zero": zero, "value": value},
                              [state_ref[0], variable[0]] + arg_ids(summed))
                output = {"outcome": "zero" if zero else "refuted", "rule": "terminal",
                          "proof_id": self.proof_count if zero else None, "proof_new": zero,
                          "proof_children": [], "assignment": None if zero else 0,
                          "nonzero_value": None if zero else value}
            else:
                low = self.branch(state_ref, variable, 0)
                if self.m.outputs[low]["outcome"] == "refuted":
                    failure = self.refute_lift(variable, 0, low)
                    output = {"outcome": "refuted", "rule": "refuted_low", "proof_id": None,
                              "proof_new": False, "proof_children": [], **self.m.outputs[failure]}
                else:
                    high = self.branch(state_ref, variable, 1)
                    if self.m.outputs[high]["outcome"] == "refuted":
                        failure = self.refute_lift(variable, 1, high)
                        output = {"outcome": "refuted", "rule": "refuted_high", "proof_id": None,
                                  "proof_new": False, "proof_children": [], **self.m.outputs[failure]}
                    else:
                        output = {"outcome": "zero", "rule": "split", "proof_id": self.proof_count,
                                  "proof_new": True, "proof_children": [self.m.outputs[low]["proof_id"],
                                                                          self.m.outputs[high]["proof_id"]],
                                  "assignment": None, "nonzero_value": None}
        self.m.finish(t, output, [state_ref[0]])
        if output["proof_new"]:
            self.proof_count += 1
            self.buckets[lookup["digest"]].append({"state_ref": state_ref, "work": t, "proof": output["proof_id"]})
            self.m.maxima["zero_cache_entries"] = max(self.m.maxima["zero_cache_entries"], self.proof_count)
        return t

    def identities(self):
        for candidate, column in zip(self.candidates, self.candidate_columns):
            self.phase("identities", column)
            terms = [{"view": ref(self.view_validations[j], "view"),
                      "coefficient": ref(candidate, "coefficients", j)} for j in range(COLS)]
            normalized = self.normalize(terms)
            root = self.prove_state(normalized)
            t = self.m.begin("candidate_outcome", {"candidate": candidate, "root_state": root})
            result = self.m.outputs[root]
            output = {"free_column": column, "outcome": "proved_zero" if result["outcome"] == "zero" else "refuted",
                      "proof_id": result["proof_id"], "assignment": result["assignment"],
                      "nonzero_value": result["nonzero_value"]}
            self.m.finish(t, output, [candidate, root])
            self.outcomes.append(output)

    def run(self):
        self.load()
        self.rref()
        self.propose()
        self.validate_selected()
        self.identities()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", required=True, type=Path)
    parser.add_argument("--sample", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    engine = None
    status, error, exit_code = "unexpected_error", None, 2
    preparation = None
    with args.output.open("x") as stream:
        meter = Meter(stream)
        try:
            raw, sample, inputs, preparation = prepare(args.trace, args.sample)
            source_dir = Path(__file__).resolve().parents[1]
            policies = {"program": binding(Path(__file__).resolve()),
                        "protocol": binding(source_dir / "PROTOCOL.md"),
                        "design": binding(source_dir / "DESIGN.md"),
                        "schema": binding(source_dir / "schema.json")}
            meter.write({"kind": "header", "version": VERSION, "input_bindings": inputs,
                         "policy_bindings": policies,
                         "limits": {"charged_request_cap": CAP, "wall_seconds": 30, "cpu_seconds": 30,
                                    "cpu_count": 1, "address_space_bytes": 1 << 30}})
            engine = Relations(meter, raw, sample)
            engine.run()
            require(not meter.stack, "completed batch has pending requests")
            status, exit_code = "completed_fixed_batch", 0
        except LimitReached as exc:
            status, exit_code = "request_cap", 4
            error = {"type": type(exc).__name__, "message": str(exc)}
        except FixtureRejected as exc:
            status = "source_invalid" if meter.context["phase"] in ("validate", "identities") else "fixture_mismatch"
            error = {"type": type(exc).__name__, "message": str(exc)}
        except Exception as exc:
            status = "unexpected_error"
            error = {"type": type(exc).__name__, "message": str(exc)}
        footer = {"kind": "footer", "status": status, "charged_starts": meter.charged,
                  "completed_requests": meter.completed,
                  "pending_stack": [f["id"] for f in meter.stack],
                  "physical_records": meter.physical + 1,
                  "operation_counts": meter.counts, "cache_counts": meter.cache_counts,
                  "phase": dict(meter.context), "rref_pivots": [] if engine is None else engine.pivots,
                  "candidate_outcomes": [] if engine is None else engine.outcomes,
                  "maxima": meter.maxima, "error": error}
        meter.write(footer)
    print(json.dumps({"status": status, "charged_starts": meter.charged,
                      "completed_requests": meter.completed, "pending_requests": footer["pending_stack"],
                      "seconds": time.monotonic() - started, "preparation": preparation,
                      "source_count_computed": False, "output": binding(args.output)}, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
