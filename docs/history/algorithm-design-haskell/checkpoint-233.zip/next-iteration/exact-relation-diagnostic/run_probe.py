#!/usr/bin/env python3
"""Snapshot and bound one fixed exact-relation batch or its independent transcript replay."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LOCK = ROOT / "project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock"
SECONDS, MEMORY_BYTES, WORK_CAP = 30, 1 << 30, 50_000
PLAN = ROOT / "next-iteration/exact-relation-plan"
SOURCE_FILES = {
    "run_probe.py": HERE / "run_probe.py",
    "diagnostics/produce_relations.py": HERE / "diagnostics/produce_relations.py",
    "replay/replay_relations.py": HERE / "replay/replay_relations.py",
    "PROTOCOL.md": HERE / "PROTOCOL.md",
    "DESIGN.md": PLAN / "DESIGN.md",
    "schema.json": PLAN / "schema.json",
}
INPUTS = {
    "trace": (ROOT / "next-iteration/cut-rank-review/attempts/cut-rank-01/input/trace.jsonl",
              "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"),
    "sample": (ROOT / "next-iteration/cut-rank-review/attempts/cut-rank-replay-01/replay-report.json",
               "ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2"),
}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def binding(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def snapshot(original, target):
    entry = binding(original)
    target.parent.mkdir(parents=True, exist_ok=True)
    with original.open("rb") as src, target.open("xb") as dst:
        shutil.copyfileobj(src, dst)
    entry.update(snapshot=str(target), snapshot_sha256=digest(target))
    if entry["sha256"] != entry["snapshot_sha256"]:
        raise RuntimeError("File changed while being snapshotted: " + str(original))
    return entry


def unchanged(entries):
    for entry in entries:
        try:
            if not (digest(Path(entry["path"])) == entry["sha256"] ==
                    digest(Path(entry["snapshot"]))):
                return False
        except OSError:
            return False
    return True


def read_result(path, mode):
    # Report parsing only: mathematical acceptance belongs to the independent replayer.
    if mode == "replay":
        return json.loads(path.read_text())
    last = None
    with path.open() as stream:
        for line in stream:
            last = line
    if last is None:
        raise ValueError("Empty producer transcript")
    return json.loads(last)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    parser.add_argument("--mode", choices=("producer", "replay"), required=True)
    parser.add_argument("--certificate", type=Path)
    args = parser.parse_args()
    if re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", args.attempt) is None:
        parser.error("Invalid attempt name")
    if (args.mode == "replay") != (args.certificate is not None):
        parser.error("Only replay mode requires --certificate")

    destination = HERE / "attempts" / args.attempt
    destination.mkdir(parents=True, exist_ok=False)
    report_path = destination / "run-report.json"
    output = destination / ("work.jsonl" if args.mode == "producer" else "replay-report.json")
    sources, inputs = [], []
    report = {
        "kind": "bounded-fixed-exact-relation-diagnostic-" + args.mode,
        "attempt": args.attempt, "mode": args.mode,
        "formal_evidence": False, "source_count_computed": False,
        "semantic_execution_attempted": False,
        "semantic_work_accounting": "Every semantic request, including cache hits and incomplete requests, is charged by the fixed protocol; report parsing is not a mathematical check.",
        "budget_scope": "One budget covers candidate arithmetic, source validation and every global identity check; separate from all historical diagnostic and counter attempts.",
        "sources": sources, "inputs": inputs, "executed_snapshots": True,
        "constraints": {"wall_seconds": SECONDS, "cpu_seconds": SECONDS,
                        "threads": 1, "address_space_bytes": MEMORY_BYTES,
                        "charged_semantic_requests_cap": WORK_CAP,
                        "shared_lock": str(LOCK), "lock_mode": "exclusive_nonblocking",
                        "board_size": 8, "fixed_candidate_matrix": [19, 35]},
        "deadline_checked_after_exit": True,
    }
    status, exit_code, peak_rss = "preparation_failed", None, None
    started, child = None, None
    preparing = time.monotonic()
    try:
        for name, original in SOURCE_FILES.items():
            sources.append(snapshot(original, destination / "source" / name))
        executable = binding(Path(sys.executable).resolve())
        report["python_executable"] = executable
        script = "diagnostics/produce_relations.py" if args.mode == "producer" else "replay/replay_relations.py"
        command = [sys.executable, "-I", str(destination / "source" / script)]
        for name, (original, expected) in INPUTS.items():
            target = destination / "input" / (name + (".jsonl" if name == "trace" else ".json"))
            entry = snapshot(original, target)
            inputs.append(entry)
            if entry["sha256"] != expected:
                raise RuntimeError("Fixed input hash differs: " + name)
            command.extend(["--" + name, str(target)])
        if args.certificate is not None:
            original = args.certificate.resolve(strict=True)
            target = destination / "input/certificate.jsonl"
            inputs.append(snapshot(original, target))
            command.extend(["--certificate", str(target)])
        command.extend(["--output", str(output)])
        cpu = min(os.sched_getaffinity(0))
        report["constraints"]["cpu_affinity"] = [cpu]
        report["command"] = command
        report["preparation_seconds"] = time.monotonic() - preparing
        environment = dict(os.environ)
        environment.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                           NUMEXPR_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", PYTHONHASHSEED="0")

        def limits():
            os.setsid()
            os.sched_setaffinity(0, {cpu})
            resource.setrlimit(resource.RLIMIT_AS, (MEMORY_BYTES, MEMORY_BYTES))
            resource.setrlimit(resource.RLIMIT_CPU, (SECONDS, SECONDS))

        status = "startup_failed"
        waiting = time.monotonic()
        with LOCK.open("r") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            report["lock_wait_seconds"] = time.monotonic() - waiting
            with (destination / "stdout.log").open("xb") as stdout, (destination / "stderr.log").open("xb") as stderr:
                started = time.monotonic()
                child = subprocess.Popen(command, cwd=destination, env=environment,
                                         stdout=stdout, stderr=stderr, preexec_fn=limits)
                killed = False
                while True:
                    pid, wait_status, usage = os.wait4(child.pid, os.WNOHANG)
                    if pid:
                        break
                    if time.monotonic() - started >= SECONDS:
                        killed = True
                        os.killpg(child.pid, signal.SIGKILL)
                        _, wait_status, usage = os.wait4(child.pid, 0)
                        break
                    time.sleep(0.005)
                elapsed = time.monotonic() - started
                exit_code = os.waitstatus_to_exitcode(wait_status)
                child.returncode = exit_code
                peak_rss = usage.ru_maxrss
                report.update(seconds=elapsed, user_seconds=usage.ru_utime,
                              system_seconds=usage.ru_stime, killed_for_deadline=killed)
                status = ("wall_timeout_killed" if killed else
                          "wall_deadline_exceeded" if elapsed > SECONDS else "process_exited")
        if status == "process_exited":
            result = read_result(output, args.mode)
            if args.mode == "producer":
                report["diagnostic_status"] = result.get("status")
                report["charged_semantic_requests"] = result.get("charged_starts")
                report["completed_requests"] = result.get("completed_requests")
                report["pending_requests"] = result.get("pending_stack")
                report["physical_records"] = result.get("physical_records")
                report["global_identity_claims_require_independent_replay_and_later_Lean_check"] = True
                if exit_code == 0 and result.get("status") == "completed_fixed_batch":
                    status = "passed"
                elif exit_code == 4 and result.get("status") == "request_cap":
                    status = "capped_prefix"
                else:
                    status = "process_failed"
            else:
                report["replay_qualification"] = result.get("qualification")
                report["producer_status"] = result.get("producer_status")
                report["charged_semantic_requests"] = result.get("charged_starts")
                report["completed_requests"] = result.get("completed_requests")
                report["pending_requests"] = result.get("pending_requests")
                report["physical_records"] = result.get("physical_records")
                status = "passed" if exit_code == 0 and result.get("status") == "passed" else "replay_rejected"
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        if status == "process_exited":
            status = "output_rejected"
        if child is not None and child.returncode is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
                _, wait_status, usage = os.wait4(child.pid, 0)
                child.returncode = os.waitstatus_to_exitcode(wait_status)
                exit_code, peak_rss = child.returncode, usage.ru_maxrss
            except ProcessLookupError:
                pass
        if started is not None:
            report["seconds"] = time.monotonic() - started
    report.setdefault("preparation_seconds", time.monotonic() - preparing)
    sources_unchanged, inputs_unchanged = unchanged(sources), unchanged(inputs)
    if status in ("passed", "capped_prefix") and (not sources_unchanged or not inputs_unchanged):
        status = "binding_failed"
    report.update(status=status, exit_code=exit_code, peak_rss_kib=peak_rss,
                  child_process_started=child is not None,
                  semantic_execution_attempted=child is not None,
                  source_hashes_unchanged=sources_unchanged,
                  input_hashes_unchanged=inputs_unchanged,
                  source_bindings_complete=len(sources) == len(SOURCE_FILES),
                  input_bindings_complete=len(inputs) == len(INPUTS) + (args.mode == "replay"))
    report["artifacts"] = [binding(path) for path in sorted(destination.rglob("*")) if path.is_file()]
    report_path.open("x").write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": status, "mode": args.mode, "attempt": args.attempt,
                      "seconds": report.get("seconds"), "peak_rss_kib": peak_rss,
                      "diagnostic_status": report.get("diagnostic_status"),
                      "replay_qualification": report.get("replay_qualification"),
                      "report": str(report_path), "report_sha256": digest(report_path)}, sort_keys=True))
    return 0 if status == "passed" else 4


if __name__ == "__main__":
    sys.exit(main())
