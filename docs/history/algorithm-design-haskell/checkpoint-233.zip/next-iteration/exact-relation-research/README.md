# Targeted primary-source check for exact relation certification

This note records a small literature follow-up after the fixed cut-rank experiment. It contains no implementation, semantic evaluation, candidate search or complexity claim for the queens instance. It is outside the frozen checkpoint 175 scope.

## Arithmetic branching-program identity testing

Rohit Gurjar, Arpita Korwar, Nitin Saxena and Thomas Thierauf, *Deterministic Identity Testing for Sum of Read-once Oblivious Arithmetic Branching Programs*, CCC 2015, DOI10.4230/LIPIcs.CCC.2015.323.

Primary paper: https://drops.dagstuhl.de/storage/00lipics/lipics-vol033-ccc2015/LIPIcs.CCC.2015.323/LIPIcs.CCC.2015.323.pdf

The paper checks linear dependencies between partial functions. Section3.1 notes that functions with the same variable order can be combined into one branching program for their difference, then subjected to an exact identity test. Its general treatment also allows differing orders.

Inference for this project: a proposed linear relation between existing ordered guarded ADD functions is an exact identity-testing problem. The saved sample can suggest coefficients but supplies no global equality premise. A source-bound proof of the resulting zero function would justify that one relation. Our proposed recursive Shannon certificate is not an implementation of the paper's polynomial-time algorithm, and no published bound is being imported as evidence that it fits 50,000 requests or the Lean gate.

## Context-free decision diagrams

Meghana Aparna Sistla, Swarat Chaudhuri and Thomas Reps, *CFLOBDDs: Context-Free-Language Ordered Binary Decision Diagrams*, author manuscript for the 2024 TOPLAS work.

Primary manuscript: https://research.cs.wisc.edu/wpis/papers/TOPLAS-CFLOBDDs-R2.pdf

Author implementation: https://github.com/trishullab/cflobdd

This representation adds sharing of internal diagram segments through a procedure-call structure. The reported compression advantages are best-case results, with synthetic and quantum-simulation experiments. Searching the fetched manuscript for “queen” returned no match. This check did not establish an applicable queens certificate or justify a port under the current limits; no code was fetched or run.

## Decision

Continue the narrow exact-relation design using the already fixed sample as proposal data and the original descriptors as the semantic target. Preserve complete identity proofs, refutations and cap failures. Do not replace source verification with numerical rank, random identity testing, or the mere existence of a more expressive diagram language.
