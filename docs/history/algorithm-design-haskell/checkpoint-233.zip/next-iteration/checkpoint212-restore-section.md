## Checkpoint 212: reflection diagnostics and Nat-only route

The latest standalone snapshot is `adwh-lean-212-reflection-diagnostics-and-nat-only-route.zip`. It retains every checkpoint 211 payload path and all earlier accepted achievements. Restore the ZIP itself; an older ZIP is unnecessary. Restore the pinned compiler and any required original-only prepared binaries separately as documented. Do not import old experimental objects into a new complete mathematical gate.

The ordinary-field selector failure has a complete standalone saved-evidence reader:

```text
python3 -I next-iteration/kernel-ordinary-fields-selector/audit_saved_result.py --source-only
```

It checks 225 bindings, 16 canonical snapshot mappings, six raw logs, the exact failed full attempt and 56-root accepted prefix. Root passed both live and source-only modes before packaging. Keep all four unexecuted initial metadata controls and the consumed source marker. The descriptive correction did not consume a separate mathematical attempt.

The reflection failure retains the raw report, 40 logs, consumed marker and actual root execution receipt. Its 76 duplicate snapshots map to exact canonical files through SNAPSHOT-RECOVERY.json. A dedicated reader for this latest failure is still pending; the map was checked against actual snapshot bytes, and every canonical file is retained and archive-hashed. Nineteen prefix modules/128 roots passed, but the failed reflection module contributes no accepted report and no native call occurred.

The new reflection and Nat-only sources have explicit individual review statuses. The expression-major Nat candidate is frozen author source awaiting independent review. The generic local-WHNF component has an independent source review but its joint dependency selection is pending. The old explicit pure-fuel candidate is reviewed and uncompiled; cached forward success remains unproved. Read the latest continuation before selecting any new gate.

Checkpoint 211's actual saved-copy and clean restoration receipt is included. Checkpoint 212's own postpublication receipt belongs in a later snapshot. Continue the authorized work toward the stock numeral theorem after recovery; checkpoint publication is a durability action.
