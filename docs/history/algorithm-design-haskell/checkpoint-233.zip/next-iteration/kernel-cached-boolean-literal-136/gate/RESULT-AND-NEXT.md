# Actual Boolean32/Literal2 complete136 result

The sole fresh complete attempt **failed in KernelCachedForward**. The root
metadata preflight passed, and the mathematical run took
**24.491039530003036 seconds**, with peak process-group RSS **866408 KiB**.
This was a proof failure, not a resource-limit event.

| Module | Seconds | Exit | Accepted reports | Observed reports |
| --- | ---: | ---: | ---: | ---: |
| KernelCompactCore | 13.368945369998983 | 0 | 1 | 1 |
| KernelCachedForward | 10.842959020999842 | 1 | 0 | 25 |
| Stable, Helper, Literal, Frame, Wrapper | Unstarted | — | 0 | 0 |

The failed Cached module reported thirty unresolved terminal Boolean goals,
fifteen in each of the two rewritten intrinsic Boolean walks. The four leaf
cases retain an `if false = true` and constructor match after rewriting. The
fvar/application/binder/let cases retain elementary conjunction identities,
such as `rt = (true && rt)` or `false = (false && child)`. The two projection
proofs have no reported diagnostic. These are actual compiler observations,
not inferred errors in unexecuted later sources.

All twenty-five reports from the failed module are unaccepted. Eight depend
on Lean's error-recovery `sorryAx`; the source contains no admission. Only
Core's one report and two ordinary artifacts are accepted in this attempt.
The corrected Literal, HelperFrame and Wrapper have not been reached here.
Earlier independently accepted results retain their earlier exact scopes.

The permanent consumed key is
`de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a`.
The report is 456298 bytes, SHA-256
`b4fa5cd51387815e38c44912d66b83ef7b29f5640a7cabd98303188c82a182c6`.
The marker is 300332 bytes, SHA-256
`af48791e353f03b883c2a2d684bab440d86be9dc0c28697767bc1fb52967869d`.
The actual Cached stdout is 17438 bytes, SHA-256
`ac28d97511a31dbfcb5ff0a63882eb3028095650004f77615b4d4726d5783e64`.

Source/control/snapshot/compiler/runtime and log postchecks passed. The actual
read-only snapshots and canonical bytes were independently compared for all
454 mappings; all four logs and the permanent marker were rehashed. The
source-only recovery record retains canonical mappings rather than duplicate
snapshots or compiled objects. A dedicated complete saved-result reader is
still pending. Packaging and these byte checks are not new mathematical runs.

## Next authorized work

Preserve this failed source and all evidence. Make a distinct diagnosed
correction that explicitly closes the remaining elementary Boolean goals in
both the physical and full native source representations, with exact maps
and an independent review. Any next mathematical selection must freshly
compile the complete closure under the unchanged cumulative 30-second,
one-CPU/thread, 1-GiB and default-resource policy. The failed timing is not
evidence of a successful speedup or of full-closure fit. No unchanged retry,
standalone timing run or prepared prefix-object reuse is authorized.

Continue the independently progressing count-trace construction and actual
record-driver proofs. Whole-query cached success and its final bound, installed
annotations/program pins, true-prefix lifecycle, EnvWF, original GroupChecked,
native integration and the stock `cqueens 16 = 14772512` theorem remain open.
