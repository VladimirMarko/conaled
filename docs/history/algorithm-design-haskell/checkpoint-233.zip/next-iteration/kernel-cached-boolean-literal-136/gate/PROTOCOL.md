# Complete cached Wrapper136 gate with two separate proof overlays

Status: frozen for independent root control review. Root alone may execute the
metadata preflight and the single complete mathematical attempt. The author has
not executed this runner, a preflight, Lean, an exporter, evaluator, profiler,
retained generator, native mathematical program or saved-result reader.

## Current mathematical selection

| Physical module, in dependency order | Reports | Source bytes |
| --- | ---: | ---: |
| KernelCompactCore | 1 | 297742 |
| KernelCachedForward | 25 | 210150 |
| KernelCachedStableForward | 20 | 14667 |
| KernelCachedHelperDirect | 25 | 23406 |
| KernelCachedLiteralForward | 8 | 6331 |
| KernelCachedHelperFrame | 16 | 11880 |
| KernelCachedRecordWrapper | 41 | 40501 |

The seven ordinary sources total 604,677 bytes and require 136 ordered, distinct
axiom reports and fourteen fresh outputs: one olean and one ilean per module.
All experimental imports refer to preceding owners in the table. Pinned SDK
Init/Std imports remain permitted. No prepared experimental objects, incremental
reuse, native compilation, exporter, count or extra mathematical stage is used.

This selection retains the complete Wrapper136 dependency closure. The current
Cached owner contains the separately reviewed Boolean32 proof rewrites. The
current Literal owner contains the separately reviewed repair of two diagnosed
scope-proof arguments. Core, Stable, Helper, Frame and repaired Wrapper are
literal predecessor sources. Syntax, Bulk, arithmetic, beta/delta, Nat-iota,
trace, finite record typing, actual installation and original parsed-driver
sources are not selected imports. Historical files remain uncompiled context.

The unchanged ownership census is seventeen upstream and seven project origins,
twenty-four distinct logical origins and twenty-six source segments. Expr and
ExprOps supplemental slices span already owned origins. Logical origin rows
describe the retained origin sources before the separately mapped proof layers.
The complete native ExprOpsC companion is provenance context, not an additional
compiled owner. The earlier evaluator omissions remain explicit; all six
original callback families, knots and CState fields remain. Original driver and
installation APIs and native representation reconciliation must still be restored
and checked for the final original-record theorem.

## Exact source changes and independent reviews

Boolean32 changes sixteen Boolean equality certificate proofs in each actual
`Expr.wscopedBXP` and `Expr.leavesSubXP`. Each replacement uses one-step plain
descent, the actual cutoff/branch fact, an explicit Boolean goal and returned
child equalities. No runtime value, call, guard, memo key/write, borrowing
annotation, cursor, statement, import, option or report command changes. One
ordinary leading comment describes this separate layer. The same thirty-two
certificate replacements are retained in the full native ExprOpsC companion.
Its two original and two candidate walk blocks match the ordinary blocks
exactly. Sixty-four proof replacements, one comment and all sixty-seven
unchanged spans have forward/inverse maps. The preserved unselected draft and
its forty-four goal-parenthesization corrections remain separately bound.

Literal2 changes only the two actual scope arguments at source lines 111 and
127. Each old `rfl` becomes
`(by unfold natLiteral; simp only [Expr.wscopedB])`. This invokes the actual
literal scope equation explicitly. All nine theorem headers, eight reports,
150 source lines and three complementary spans remain exact. Neither source
adds an assumption, declaration, axiom, computational change or resource option.

The eighteen independent scopes of the consumed Wrapper136 predecessor remain
at their original input identities. They include the original fifteen
complete120 scopes, HelperFrame23, original Wrapper50 and the distinct
four-line Wrapper robustness15 scope. The runner validates their original
metadata against their original manifests; no historical compiler is run.
The two current reviews are additional scopes:

| Current scope | Independent reviewer | Independent inputs | Author inputs |
| --- | --- | ---: | ---: |
| Boolean32, native/ordinary correspondence and preserved drafts | book_scope_review | 40 | 234 |
| Diagnosed Literal2 scope arguments | root | 48 | 47 |

The manifest preserves all twenty scopes separately, including complete exact
input arrays. The new metadata checks bind both completed reviews to the current
candidate hashes, check the overlays forward and backward and compare every
unchanged span. They check twelve Boolean primary intervals and six Literal
primary intervals. All earlier review arrays and source selections stay at their
historical identities. No earlier review is rebased onto either new owner.

The Boolean rewrite is a substantive elaboration-cost hypothesis. No speedup,
complete-budget fit or compilation acceptance is claimed before this run. Its
native companion has not been compiled, and no generated-name or machine-code
identity claim is made.

## Consumed result and permanent fresh-source rule

The immediate consumed key is
`6ffb699dd88cf34e0ac1a3ca5d2702c14bad45ec2c24b743f5f67dde984b3e02`.
That complete Wrapper136 attempt failed at Literal with two application type
mismatches, at 111:41 and 127:41. It accepted 71 reports from Core, Cached,
Stable and Helper, observed 79 reports and produced eight ordinary artifacts.
All eight Literal reports were rejected as one failed module; two error-recovery
reports contain `sorryAx`. There is no source admission. Frame and Wrapper did
not start. The actual result was 28.56823542299753 seconds and 883916 KiB, with
no Literal resource-limit event. Its controls, 401 recovered snapshots, ten
logs, report, root receipt, review, recovery and permanent marker remain bound.

The new selection combines the diagnosed Literal repair with the reviewed
Boolean proof-cost candidate. It does not rerun an unchanged owner selection or
reuse accepted prefix objects. All seven current sources must compile freshly
within the same complete budget; the predecessor timing gives no fit guarantee.

The permanent fingerprint hashes the unchanged stage
`cached-forward-runs-and-licensed`, unchanged policy and ordered module/source
hashes. Path, metadata, runner and attempt renaming cannot reset a consumed key.
The runner checks its own marker directory and all ten historical cached gate
directories. It reserves the exclusive permanent marker before the first
compiler starts. Every mathematical attempt consumes its source key.

## Conditional theorem boundary

Literal8 proves actual cached literal forwarding under StableNF and an explicit
MemoFrame. Frame16 preserves an auxiliary predicate through actual helpers under
helper-write closure and supplies the exact nine-field RestCaches projection.
Preservation alone does not establish helper success.

Wrapper41 proves conditional actual original conversion from a query callback at
the required smaller fuel that preserves RestCaches. It retains actual returned
states, positive-fuel memo hits, left-to-right Nat primitive calls, stored Eq
annotation and level-arity premises, the actual Nat.add guard and explicit
reachable cheap-head/positive-defeq cache conditions. Its finite inference and
annotation equations expose actual child runs. No theorem assumes the success
of its own enclosing conversion body. The expected numeral is a parameter.

Even complete acceptance of this gate establishes no cached whole-query success
or bound, actual installed annotations, EnvWF, original GroupChecked or stock
numeral theorem. The original local loop budgets are unchanged; the separately
accepted pure bound 5053 is not promoted to a cached bound. Every final whole-query,
installed-record, GroupChecked and numeral flag remains false.

## Metadata, snapshots and trust controls

The required `--lean` argument points to the pinned Lean 4.35.0 executable.
Without `--run`, the runner performs metadata/source checks only; root remains
the sole executor. Strict JSON rejects duplicate keys. All context paths must be
ordinary local project files; absolute paths, escapes, symlinks and missing files
are rejected. Historical helper bindings are converted back to project-relative
identities when merged into the current input set.

Only the existing pinned resource helper and source guard are dynamically loaded
after their fixed hashes match. The guard checks actual imports, options and
ordered reports and rejects holes, trusted shortcuts, executable elaborator
commands, resource overrides and unsupported visibility commands. Compiler and
five runtime library identities remain pinned to the existing SDK and commit.

The manifest binds the deduplicated union of all historical/current reviewed
inputs, source maps, full source files, controls and raw result evidence. Sources
and controls are disjoint; control paths and roles are unique. The manifest is
one additional snapshot. Root's subsequent independent control review is a
separate record and does not recursively enter its own review target. These
metadata checks do not replace the separately pending full saved-result reader.

Every input is copied into a fresh attempt directory, checked and made read-only.
The build directory starts empty. The original affinity mask is saved, one
permitted CPU is selected and the pinned helper constructs a clean environment.
Loader injection variables are removed; compiler threads and import workers are
one. Experimental object search includes only the fresh build directory.

## One cumulative fixed mathematical interval

The timer starts exactly once immediately before the sequential seven-module
compilation loop. Its deadline is thirty seconds later. Each command retains
`-j1`, `-M1024`, `-DautoImplicit=false`, `-DwarningAsError=true` and
`-DElab.async=false`, with ordinary olean/ilean outputs and default heartbeat,
recursion and other compiler settings. The same pinned process-tree watchdog
enforces one CPU/thread, 1,048,576 KiB and the shared deadline. There is no budget
reset, profiling, extra diagnostic run or separate compilation allowance.

Each module is accepted only on successful exit within limits, both fresh
artifacts, empty stderr and exactly its ordered reports. Every raw axiom must be
in `propext`, `Quot.sound`, `Classical.choice`. A failed module rejects all its
reports and stops further compilation. Error-recovery output is never accepted.

Postchecking rehashes sources, controls, read-only snapshots, compiler/runtime,
logs and marker, and checks the exact fourteen-artifact inventory. Postchecks and
affinity restoration remain inside total elapsed time. Complete success requires
seven passed modules, all 136 ordered/distinct reports, all fourteen fresh
outputs, unchanged identities, no failure and total time at most thirty seconds
with peak child memory at most 1 GiB. Any failure consumes the key.

## Literal execution-code correspondence

The entire 8080-byte mathematical execution block, from the first preparing-report
save through the return before `main`, is literal to the consumed Wrapper136
runner. Snapshot/marker creation, environment, compiler arguments, deadline,
watchdog, log audit, artifact inventory, integrity checks, affinity restoration,
136-report acceptance and all final conditional/global flags are unchanged.
The policy, permanent fingerprint, source guard wrapper, raw log auditor and
`main` are also literal.

The exact complete old/new runner correspondence separately records changes to
scope labels, current source pins, extra fixed metadata pins, historical
metadata scoping, the new overlay/input validators, one additional predecessor
marker directory and report provenance fields. No execution or resource-policy
change is hidden inside an assertion of whole-runner identity.
