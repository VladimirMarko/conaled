# Exact basis: final executable review

**No blocker found in the frozen producer, independent replayer, protocol,
schema, runner or corrected result collector.** This is a source/control review;
no semantic program was imported or executed, and no basis dimension, identity
or count is asserted.

## Source semantics and origins

The programs start with no basis or witnesses. The old sample contributes only
its 35 original `grouping.b_views`; sample values, ranks and old counterexamples
are not read as algorithm inputs. The selected source closure, full guards and
Y-contained supports are checked before column work. Both implementations use
only standard-library imports and read the inherited programs for byte identity,
without importing them.

The deterministic controller threads each completed elimination vector into the
next current residual. Dot products evaluate individual original functions at
the retained witness; they do not infer those values from a signed residual.
Every nonzero sparse entry gets an evaluation, rational multiplication and
rational addition. Sparse subtraction preserves column order and removes only
an exactly zero resulting coefficient.

The clearing vector has positive scale D, retains the current column with
coefficient D, and binds every integer coefficient to its original view. The
global oracle uses the unchanged complete guarded Shannon rules, with the
derived term bound enlarged from 20 to 35. Its exact source meaning does not
depend on the sampled matrix. A new basis vector divides the cleared integer
coefficients by the oracle's **signed** nonzero value z. The checked controller
therefore establishes the triangular invariant without treating an asserted
truth value or sample rank as a premise.

Static comparison found 18 inherited producer mathematical methods unchanged.
The replayer retains 17 unchanged guarded-controller methods; the state bound
and controller initialization are the intended changes. All 42 request kinds
agree with the current schema; the eleven old matrix/proposal kinds are absent.

## Metering and publication

Each new arithmetic, merge, evaluation or cache-comparison body runs after its
request start. The replayer independently reconstructs the schedule and checks
the exact request inputs, output and dependency list. In particular, original
column selection for `dot_term` and `origin_term` occurs within the charged
request and its validation WorkID is preserved in the output/dependencies.

Source-cache keys contain the full guarded view and full assignment. Digest
buckets select candidates only; charged comparisons establish exact equality,
including failed inspections. Misses interpret the full guard before a
constant or selected original child. Cache entries, zero proofs, basis vectors,
column outcomes and the final basis are published only after their respective
requests complete. Duplicate dependency occurrences remain recorded.

The footer is accepted only after either the complete fixed schedule or the
next scheduled start at exactly 50,000 consumed requests. A footer encountered
where a completion is required is rejected. Exact field sets, nesting,
completion counts, pending frames, cache counts, maxima, context and trailing
bytes are checked. Only complete coverage of all 35 original columns publishes
`final_basis`; partial independent directions are not advertised as spanning.

## Controls and reporting

The new programs' CLI and snapshot-relative paths match the runner's nine-file
layout. The replayer checks all seven policy identities in the producer header,
as well as the fixed trace/sample bytes and limits. Producer and replay snapshot
paths may differ; matching byte identities, not path text, bind their contents.

The runner preserves the reviewed 30-second CPU/wall bounds, one CPU, one-thread
environment, 1 GiB address-space limit, shared nonblocking lock, isolated Python
invocation, post-exit deadline check, unchanged-byte guards and failure retention.
Preparation copies/hashes files; semantic parsing and computation occur in the
bounded child. The runner's result parsing is not itself mathematical validation.

The collector's initial result-pairing gap was fixed before execution. It now
matches the actual producer transcript to its recorded artifact, both replay
certificate hashes, the replayer's certificate binding, and the actual replay
result to its recorded artifact. It also matches the replay's producer status
to the summarized footer. It preserves a null final basis for a prefix and
performs metadata extraction only.

A successful replay would provide external diagnostic evidence of the exact
basis result for these fixed guarded functions. A complete dimension 35 would
concern this fixed cut under its separate grouping/independence assumptions;
neither result is a Lean rank theorem or a queens count. No completion-cost or
compression prediction follows from this review.
