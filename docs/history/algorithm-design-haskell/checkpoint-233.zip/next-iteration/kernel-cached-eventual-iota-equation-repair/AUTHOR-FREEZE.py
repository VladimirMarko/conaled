"""Literal source/JSON bookkeeping only. No compiler, evaluator, gate or retained reader."""
from pathlib import Path
import copy
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/618374bfa892/adwh-work')
OLD = ROOT / 'next-iteration/kernel-cached-eventual-iota-proof-repair'
NEW = ROOT / 'next-iteration/kernel-cached-eventual-iota-equation-repair'
SDK = ROOT.parent / 'toolchains/lean-4.35.0-linux/src/lean'
CONSUMED_KEY = 'e83b4b93eed3f30889ab452f532fbf6799b75969f42def71f8f711e9087b653d'
THEOREM = 'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ident(path):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    data = p.read_bytes()
    return {'path': str(p.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha(data)}

def checked(row):
    data = (ROOT / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
    return data

def read(path):
    return json.loads(Path(path).read_text())

def write(name, value):
    (NEW / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return ident(NEW / name)

def span(data, a, b):
    assert 0 <= a <= b <= len(data)
    first = data[:a].count(b'\n') + 1
    last = max(first, data[:b].count(b'\n') + int(not data[:b].endswith(b'\n')))
    cut = data[a:b]
    return {'start_byte': a, 'end_byte_exclusive': b, 'first_line': first,
            'last_line_inclusive': last, 'bytes': len(cut), 'sha256': sha(cut)}

def reports(data):
    return re.findall(rb'^#print axioms\s+([^\n]+)$', data, re.M)

def overlay(relative):
    old, new = (OLD / relative).read_bytes(), (NEW / relative).read_bytes()
    needle = b'  dsimp only [substLevelTreesM, List.map, List.take, List.drop, List.append,\n'
    assert old.count(needle) == 1
    a = old.index(needle)
    b = old.index(b'  all_goals rfl\n', a) + len(b'  all_goals rfl\n')
    d = len(new) - (len(old) - b)
    assert old[:a] == new[:a] and old[b:] == new[d:]
    assert new[a:d].startswith(b'  let constructorCertificate (ty : Expr) : CheckCM Bool := do\n')
    before, after = old[a:b], new[a:d]
    assert old[:a] + after + old[b:] == new
    assert new[:a] + before + new[d:] == old
    assert reports(old) == reports(new)
    return {'original': ident(OLD / relative), 'candidate': ident(NEW / relative),
            'edit_count': 1, 'edits': [{'kind': 'diagnosed_pointwise_except_equation_proof_only',
              'original': span(old, a, b), 'candidate': span(new, a, d),
              'before': before.decode(), 'after': after.decode()}],
            'unchanged_complement_count': 2,
            'unchanged_complements': [
                {'original': span(old, 0, a), 'candidate': span(new, 0, a)},
                {'original': span(old, b, len(old)), 'candidate': span(new, d, len(new))}],
            'complete_forward_and_inverse_verified': True}

logical = overlay('logical-source/KernelCachedOperationalContracts.lean')
physical = overlay('source/KernelCachedEventualInterpreter.lean')
assert logical['edits'][0]['before'] == physical['edits'][0]['before']
assert logical['edits'][0]['after'] == physical['edits'][0]['after']
correction_id = write('PROOF-CORRECTION.json', {
    'format': 'adwh-eventual-iota-explicit-equation-proof-repair-v1',
    'status': 'source_only_uncompiled_pending_independent_review', 'theorem': THEOREM,
    'diagnostic_scope': 'Single actual rewrite failure after partially unfolded Boolean decisions',
    'logical': logical, 'physical': physical,
    'all_theorem_headers_premises_runtime_definitions_guards_states_bounds_imports_options_and_reports_unchanged': True,
    'local_continuations_and_local_run_facts_only': True,
    'no_decision_instance_unfolding_or_options_added': True,
    'previous_overlay_retained_separately': ident(OLD / 'PROOF-CORRECTION.json'),
    'consumed_source_key': CONSUMED_KEY})

# Reconstruct the physical owner from all five complete selected logical files.
previous_assembly = read(OLD / 'ASSEMBLY-LINEAGE.json')
pieces = [previous_assembly['header_literal'].encode()]
current = len(pieces[0])
origins = []
for previous in previous_assembly['origins']:
    row = copy.deepcopy(previous)
    source = logical['candidate'] if row['original_module'] == 'KernelCachedOperationalContracts' else row['source']
    original = checked(source)
    edits = []
    transformed_parts = []
    old_cursor = new_cursor = 0
    complements = []
    for edit in previous['edits']:
        a, b = edit['original']['start_byte'], edit['original']['end_byte_exclusive']
        assert original[a:b] == edit['before'].encode()
        copied = original[old_cursor:a]
        transformed_parts.append(copied)
        complements.append((old_cursor, a, new_cursor, new_cursor + len(copied)))
        new_cursor += len(copied)
        replacement = edit['after'].encode()
        transformed_parts.append(replacement)
        edits.append((a, b, new_cursor, new_cursor + len(replacement), edit))
        new_cursor += len(replacement)
        old_cursor = b
    transformed_parts.append(original[old_cursor:])
    complements.append((old_cursor, len(original), new_cursor, new_cursor + len(original) - old_cursor))
    transformed = b''.join(transformed_parts)
    inverse = []
    cursor = 0
    for a, b, c, d, edit in edits:
        inverse += [transformed[cursor:c], edit['before'].encode()]
        cursor = d
    inverse.append(transformed[cursor:])
    assert b''.join(inverse) == original
    banner, footer = row['banner']['literal'].encode(), row['footer']['literal'].encode()
    row['previous_selected_source'] = previous['source']
    row['source'] = source
    row['logical_proof_overlay_selected'] = row['original_module'] == 'KernelCachedOperationalContracts'
    row['banner'] = {'literal': banner.decode(), 'physical_start_byte': current,
                     'physical_end_byte_exclusive': current + len(banner)}
    current += len(banner)
    body_start = current
    row['body'] = {'physical_start_byte': current, 'physical_end_byte_exclusive': current + len(transformed),
                   'bytes': len(transformed), 'sha256': sha(transformed)}
    row['edits'] = []
    for a, b, c, d, prior_edit in edits:
        e = copy.deepcopy(prior_edit)
        e['original'], e['transformed'] = span(original, a, b), span(transformed, c, d)
        e['physical_start_byte'], e['physical_end_byte_exclusive'] = body_start + c, body_start + d
        row['edits'].append(e)
    row['unchanged_complements'] = [
        {'original': span(original, a, b), 'transformed': span(transformed, c, d),
         'physical_start_byte': body_start + c, 'physical_end_byte_exclusive': body_start + d}
        for a, b, c, d in complements]
    assert all(original[a:b] == transformed[c:d] for a, b, c, d in complements)
    current += len(transformed)
    row['footer'] = {'literal': footer.decode(), 'physical_start_byte': current,
                     'physical_end_byte_exclusive': current + len(footer)}
    current += len(footer)
    pieces += [banner, transformed, footer]
    origins.append(row)
assembled = b''.join(pieces)
assert assembled == checked(physical['candidate'])
assembly = copy.deepcopy(previous_assembly)
assembly.update({
    'format': 'adwh-eventual-iota-equation-five-origin-assembly-v1',
    'previous_assembly_map': ident(OLD / 'ASSEMBLY-LINEAGE.json'),
    'previous_selected_physical_source': physical['original'],
    'candidate': physical['candidate'], 'proof_overlay': correction_id, 'origins': origins,
    'header_span': span(assembled, 0, len(pieces[0])),
    'local_continuations_and_run_facts_added_within_existing_proof_only': True})
assembly_id = write('ASSEMBLY-LINEAGE.json', assembly)

# Preserve the prior primary scope literally; add only exact new source context.
previous_context = read(OLD / 'PRIMARY-SOURCE-CONTEXT.json')
sdk_path = 'Lean/Elab/Tactic/Change.lean'
sdk_copy = NEW / 'sdk' / sdk_path
sdk_copy.parent.mkdir(parents=True, exist_ok=True)
sdk_copy.write_bytes((SDK / sdk_path).read_bytes())

def lines_interval(label, path, first, last):
    data = Path(path).read_bytes()
    lines = data.splitlines(keepends=True)
    assert 1 <= first <= last <= len(lines)
    a, b = sum(map(len, lines[:first-1])), sum(map(len, lines[:last]))
    return {'label': label, 'source': ident(path), 'span': span(data, a, b),
            'literal_text': data[a:b].decode()}

def theorem_interval(label, path):
    data = Path(path).read_bytes()
    a = data.index(b'theorem iota_plain_of_prepared ')
    b = data.index(b'\n#print axioms partial_iota_arity', a)
    return {'label': label, 'source': ident(path), 'span': span(data, a, b),
            'literal_text': data[a:b].decode()}

extra_intervals = [
    theorem_interval('consumed_logical_failed_theorem', OLD / 'logical-source/KernelCachedOperationalContracts.lean'),
    theorem_interval('new_logical_staged_theorem', NEW / 'logical-source/KernelCachedOperationalContracts.lean'),
    theorem_interval('new_physical_staged_theorem', NEW / 'source/KernelCachedEventualInterpreter.lean'),
    lines_interval('change_checks_definitional_equality', sdk_copy, 26, 49),
    lines_interval('change_replaces_target_only_after_elaboration', sdk_copy, 73, 84)]
context_id = write('PRIMARY-SOURCE-CONTEXT.json', {
    'format': 'adwh-eventual-iota-equation-primary-context-v1',
    'previous_context': ident(OLD / 'PRIMARY-SOURCE-CONTEXT.json'),
    'previous_intervals_preserved_exactly': previous_context['intervals'],
    'previous_interval_count': len(previous_context['intervals']),
    'new_intervals': extra_intervals, 'new_interval_count': len(extra_intervals),
    'total_interval_count': len(previous_context['intervals']) + len(extra_intervals),
    'SDK_full_copies': previous_context['SDK_full_copies'] + [
        {'sdk_relative_path': sdk_path, 'copy': ident(sdk_copy), 'complete_copy_matches_pinned_SDK': True}],
    'SDK_source_or_intervals_are_compiled_inputs': False,
    'tactic_options_resource_options_or_linter_settings_changed': False})

gate = OLD / 'gate'
stdout = gate / 'attempts/complete-01/KernelCachedEventualInterpreter.stdout.log'
log = stdout.read_bytes()
headers = list(re.finditer(rb'^KernelCachedEventualInterpreter\.lean:(\d+):(\d+): error:.*$', log, re.M))
assert len(headers) == 1
match = headers[0]
following_report = re.search(rb"^'[^\n]+' depends on axioms:", log[match.end():], re.M)
assert following_report is not None
end = match.end() + following_report.start()
physical_line, column = map(int, match.groups())
assert physical_line == 3095
logical_line = physical_line - 2473
assert logical_line == 622
source_line = (OLD / 'source/KernelCachedEventualInterpreter.lean').read_text().splitlines()[physical_line-1]
assert source_line == '  rw [recursorTypeRun]'
diagnostic_id = write('CAPTURED-DIAGNOSTICS.json', {
    'format': 'adwh-eventual-iota-equation-captured-diagnostics-v1',
    'raw_stdout': ident(stdout), 'report_identity_only': ident(gate / 'attempts/complete-01/report.json'),
    'root_execution_receipt': ident(gate / 'ROOT-EXECUTION-RECEIPT.json'),
    'root_result_note': ident(gate / 'RESULT-AND-NEXT.md'),
    'actual_snapshot_recovery': ident(gate / 'SNAPSHOT-RECOVERY.json'),
    'consumed_marker': ident(gate / 'execution-markers' / ('complete-' + CONSUMED_KEY + '.json')),
    'consumed_source_key': CONSUMED_KEY,
    'raw_stdout_ends_in_newline': log.endswith(b'\n'), 'raw_stdout_line_count': len(log.splitlines()),
    'complete_captured_error_headers': 1, 'unused_simp_argument_headers': 0,
    'all_captured_errors_in_one_existing_proof_scope': True,
    'raw_stdout_report_headers_observed': len(re.findall(rb"^'[^\n]+' depends on axioms:", log, re.M)),
    'report_was_executed_or_parsed_by_author': False,
    'captured_recovery_axiom_output_is_not_source_admission_or_acceptance': True,
    'diagnostics': [{'id': '001', 'kind': 'pointwise_rewrite_after_partial_bool_decision_unfolding',
       'log_span': span(log, match.start(), end), 'captured_text': log[match.start():end].decode(),
       'physical_line': physical_line, 'logical_line': logical_line, 'column': column,
       'source_line': source_line, 'theorem': THEOREM,
       'correction_scope': 'The single terminal proof span; exact grouped Except equations preserve all operations.'}]})

old_scopes = read(OLD / 'HISTORICAL-REVIEW-SCOPES.json')
old_manifest = read(gate / 'source-manifest.json')
scopes_id = write('HISTORICAL-REVIEW-SCOPES.json', {
    'format': 'adwh-eventual-iota-equation-preserved-scopes-v1',
    'previous_scope_ledger': ident(OLD / 'HISTORICAL-REVIEW-SCOPES.json'),
    'previous_ledger_literal': old_scopes,
    'previous_consumed_manifest': ident(gate / 'source-manifest.json'),
    'prior_total_separate_control_review_scope_count': old_manifest['current_total_separate_independent_review_scope_count'],
    'previous_added_separate_control_scope_literal': old_manifest['new_separate_review_scopes'],
    'prior_iota_repair': {'author_count': 1342, 'review_count': 1343,
        'inventory': ident(OLD / 'SOURCE-INVENTORY.json'), 'review': ident(OLD / 'SOURCE-REVIEW.md'),
        'audit': ident(OLD / 'SOURCE-AUDIT.json')},
    'original_arrays_statuses_and_source_selections_rebased': False,
    'new_scope_is_one_diagnosed_overlay_over_separate_prior_scopes': True,
    'no_new_global_scope_or_instance_or_simp_environment': True})

old_census = read(OLD / 'PROSPECTIVE-SOURCE-CENSUS.json')
census = copy.deepcopy(old_census)
census.update({'format': 'adwh-eventual-iota-equation-prospective-source-census-v1',
    'logical_proof_overlay': correction_id, 'assembly_lineage': assembly_id,
    'consumed_selection_retained_as_history': ident(OLD / 'PROSPECTIVE-SOURCE-CENSUS.json')})
census['physical_modules'][-1]['source'] = physical['candidate']
census['selected_physical_sources'][-1] = physical['candidate']
census['source_bytes'] = sum(r['bytes'] for r in census['selected_physical_sources'])
assert census['source_bytes'] == 621077
assert len(census['ordered_reports']) == len(set(census['ordered_reports'])) == 185
assert reports(checked(physical['candidate'])) == reports(checked(physical['original']))
census_id = write('PROSPECTIVE-SOURCE-CENSUS.json', census)

# All previous author identities are retained without changing their input array.
previous_inventory = read(OLD / 'SOURCE-INVENTORY.json')
assert previous_inventory['input_count'] == len(previous_inventory['inputs']) == 1342
inputs = {}
def add(row):
    checked(row)
    if row['path'] in inputs:
        assert inputs[row['path']] == row
    else:
        inputs[row['path']] = row
for row in previous_inventory['inputs']:
    add(row)
for name in ['SOURCE-INVENTORY.json', 'SOURCE-REVIEW.md', 'SOURCE-AUDIT.json',
             'INDEPENDENT-STATIC-CHECK.py', 'INDEPENDENT-STATIC-CHECK.json']:
    add(ident(OLD / name))
for name in ['run_gate.py', 'source-manifest.json', 'CONTROL-CORRESPONDENCE.json',
             'PROTOCOL.md', 'AUTHORING.md', 'AUTHOR-CONTROLS.py', 'runner-metadata.py.txt',
             'INDEPENDENT-CONTROL-REVIEW.md', 'INDEPENDENT-CONTROL-CHECK.json',
             'ROOT-EXECUTION-RECEIPT.json', 'SNAPSHOT-RECOVERY.json', 'RESULT-AND-NEXT.md',
             'attempts/complete-01/report.json',
             'attempts/complete-01/KernelCachedEventualInterpreter.stdout.log',
             'attempts/complete-01/KernelCachedEventualInterpreter.stderr.log',
             'execution-markers/complete-' + CONSUMED_KEY + '.json']:
    add(ident(gate / name))
for path in [NEW / 'logical-source/KernelCachedOperationalContracts.lean',
             NEW / 'source/KernelCachedEventualInterpreter.lean', NEW / 'PROOF-CORRECTION.json',
             NEW / 'ASSEMBLY-LINEAGE.json', NEW / 'PRIMARY-SOURCE-CONTEXT.json',
             NEW / 'CAPTURED-DIAGNOSTICS.json', NEW / 'HISTORICAL-REVIEW-SCOPES.json',
             NEW / 'PROSPECTIVE-SOURCE-CENSUS.json', NEW / 'PLAN.md', NEW / 'AUTHOR-REVIEW.md',
             NEW / 'AUTHOR-FREEZE.py', sdk_copy]:
    add(ident(path))
inventory_id = write('SOURCE-INVENTORY.json', {
    'format': 'adwh-eventual-iota-equation-repair-source-inventory-v1',
    'author': '/root/nat_only_gap_review',
    'status': 'frozen_source_only_uncompiled_pending_independent_review',
    'input_count': len(inputs), 'inputs': sorted(inputs.values(), key=lambda r: r['path']),
    'logical_source': logical['candidate'], 'physical_source': physical['candidate'],
    'logical_correction_map': correction_id, 'physical_assembly_lineage': assembly_id,
    'diagnostic_map': diagnostic_id, 'primary_source_context': context_id,
    'historical_review_scopes': scopes_id, 'prospective_source_census': census_id,
    'previous_author_input_array_preserved_exactly': previous_inventory['inputs'],
    'previous_author_input_count': 1342,
    'selected_physical_sources': census['selected_physical_sources'],
    'source_bytes': census['source_bytes'], 'physical_owner_count': 3, 'report_count': 185,
    'ordered_report_counts': [2, 6, 177], 'ordered_reports': census['ordered_reports'],
    'ordinary_output_count': 6, 'logical_report_count': 32, 'physical_proof_report_count': 177,
    'one_logical_and_one_physical_proof_span_only': True,
    'logical_and_physical_unchanged_complements_each': 2,
    'five_input_assembly_import_edits': 8, 'five_input_assembly_complements': 13,
    'unchanged_logical_origins': 4, 'selected_changed_logical_origin': 'KernelCachedOperationalContracts',
    'unchanged_runtime_owners': 2,
    'all_public_headers_premises_runtime_definitions_guards_states_budgets_and_roots_unchanged': True,
    'namespace_import_private_global_option_and_simp_environment_unchanged': True,
    'historical_scopes_rebased': False, 'consumed_source_key': CONSUMED_KEY,
    'new_source_or_gate_executed_or_accepted': False, 'gate_authored': False,
    'compiler_preflight_exporter_profiler_mathematical_generator_or_saved_reader_executed': False,
    'whole_query_installed_record_GroupChecked_or_numeral_claim': False,
    'independent_review_or_budget_fit_claim': False})
print(json.dumps({'inventory': inventory_id, 'input_count': len(inputs),
                  'logical': logical['candidate'], 'physical': physical['candidate'],
                  'correction': correction_id, 'assembly': assembly_id,
                  'diagnostics': diagnostic_id, 'source_bytes': census['source_bytes']}, indent=2))
