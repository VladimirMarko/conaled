# Independent review: eventual iota equations

**Result: passed independent source review, uncompiled.** The replacement preserves the original `iota_plain_of_prepared` statement, actual certificate grouping and returned-state sequence. I found no new mathematical or source-interface blocker. This is a review of one diagnosed proof replacement and its exact physical assembly; it is not Lean acceptance or a budget result.

Reviewer: `/root/reflection_evidence_review`. Author: `/root/nat_only_gap_review`.

I read the complete 34,809-byte logical candidate, the changed theorem in its physical owner, the actual cached iota implementation and the relevant helper, mode, rule and SDK definitions. I independently checked all 1,375 author input identities. The previous 1,342-input array, the immediate original reviews and the 39 separate historical control review scopes retain their original identities and statuses. The independent byte checker reads files and metadata only. It does not import a gate/helper, run Lean, execute a compiler or mathematical program, or run a saved-result reader.

## Exact selected change

| Representation | Consumed source | New source | Changed interval |
|---|---:|---:|---|
| Logical operational contracts | 32,241 bytes | 34,809 bytes | old lines 617–633; new lines 617–681 |
| Combined interpreter | 207,128 bytes | 209,696 bytes | old lines 3090–3106; new lines 3090–3154 |

The selected logical SHA-256 is `f657ae191ae791940a241106113f12b228d553965ea815c399d2b4a34b04b23c`; the physical SHA-256 is `611ece23121c54c99a8f1a5fc2e4951f15be73c7e6743bde45295c5c7481e358`.

Each representation has exactly one replacement: 584 old bytes become 3,152 bytes. The identical 2,568-byte increase appears in both. I reconstructed each candidate from its consumed source and reversed each replacement to recover every original byte. Both unchanged complements of each representation match exactly, including the full theorem header and the rest of the file.

All 33 logical and 183 physical named theorem headers are literal. The 32 logical and 177 physical `#print axioms` commands, source imports, namespaces, options, global declaration headers and attributes are unchanged. The extra local `let` actions and local run facts are contained inside this one existing theorem proof; they create no public runtime API. No premise, stored record guard, license, fuel, state field or target expression changes.

## What the actual diagnostic establishes

The consumed corrected Interpreter185 run failed. Root's retained `gate/RESULT-AND-NEXT.md` records 25.563569123994967 seconds, eight accepted Core/Cached reports and rejection of all 177 reports from the failed interpreter owner. That historical result is bound separately and remains failed.

I read the full captured diagnostic at raw stdout lines 451–602. Its single plain error header identifies physical line 3095 / logical line 622, `rw [recursorTypeRun]`. The rewrite cannot find the applied-state helper expression. The displayed target still contains nested `Bool.rec`, `StateT.bind` and `decide` terms. The additional diagnostic identifies the concrete mismatch: the proposition has reduced to `false = true`, while a decision-instance argument still mentions the stored rule's `compareParams` expression at implicit transparency.

This supports changing the proof's normalization method. It does not identify a false theorem, a missing helper-success premise or a resource failure. The raw output contains 177 report headers, but the failed owner gives none of them acceptance. The reported recovery `sorryAx` is rejected output, not a source admission. The independent check verified the exact 8,937-byte diagnostic span and its source-line relocation, and bound the report, receipt, marker and recovery by identity without parsing a mathematical saved result.

## Actual branch and mode correspondence

The retained cached `iotaRecI` body is at `kernel-cached-eventual-owner-slice/source/KernelCachedForward.lean`, lines 2982–3075. That complete interval is byte-identical to the native `ConLeche/Cached/CoreC.lean` body. The operational review also checked the real `certAtI`, level substitution/comparison, application construction, `RecRule.compareParams`, mode accessors and monad definitions.

Before the replacement begins, the unchanged proof has already consumed the genuine recursor lookup, level and argument arity, successful preparation, constructor head and stored constructor, matching rule, constructor level list and field arity. It proves `.plain ≠ .inert` by constructor disjointness. The replacement does not weaken or replace any of these checks.

For this exact stored plain rule, `ctorParams = 0` and `paramsBlind = true`. Its actual `compareParams` definition returns false, so the parameter comparison takes the original `pure true` branch. The constructor level list and prepared constructor levels are both empty. `substLevelTreesM` therefore produces an empty list, `isEquivListLM [] []` returns `some true`, and `liftFueled` returns that true value with the state unchanged. These are closed reductions of the actual selected definitions. They do not replace an arbitrary level comparison or bypass an error result.

The theorem selects `.verified`. Both `CheckMode.certs` and `CheckMode.betaGate` reduce to true there. Consequently, `certAtI` runs the real grouped certificate block, and the two telescope walks use their actual licensed mode. The proof does not substitute a trusted-mode result or assume installation validity for the stored `.never` metadata. The existing `NeverPiPrefix` premises remain explicit.

## The four local continuations preserve the real state chain

The local actions reconstruct the nested certificate block in its original grouping:

| Operation or local block | Starting state | Successful returned state | Evidence used |
|---|---|---|---|
| Major preparation | `state` | `afterMajor` | unchanged `preparedRun` premise |
| Recursor type helper | `afterMajor` | `afterRecursorType` | unchanged `recursorTypeRun` premise |
| Recursor telescope | `afterRecursorType` | `afterRecursorType` | existing `iotaCertsI_never` applied to `recursorLicensed` |
| Constructor type helper | `afterRecursorType` | `afterConstructorType` | unchanged `constructorTypeRun` premise |
| Constructor telescope | `afterConstructorType` | `afterConstructorType` | existing `iotaCertsI_never` applied to `constructorLicensed` |
| Canonical-index check | `afterConstructorType` | `afterConstructorType` | existing no-index equation at major/parameter indices 3 and 3 |
| Complete certificate block | `afterMajor` | `afterConstructorType` | the four locally proved continuation equations |
| Rule RHS helper | `afterConstructorType` | `afterRhs` | unchanged `rhsRun` premise |
| Application construction and final `some` | `afterRhs` | `afterRhs` | actual `mkAppNM` and monadic `pure` definitions |

`constructorCertificate` first runs the actual constructor telescope and then the actual index check. `constructorBlock` obtains its type from the actual constructor helper. `recursorCertificate` runs the recursor telescope before this constructor block. `certificate` first obtains the recursor type. Each local success proof uses the precise output state of the preceding call, never the initial state by convenience.

The certificate arguments are also exact. The recursor uses `[motive, zero, step, prepared]`, which is the original `args.take 3 ++ [prepared]`. The constructor uses the complete `fields` list. The index arguments reduce to `3 3 0`, `fields`, and `[]`. The returned reduct is `Expr.mkAppN rhs ([motive, zero, step] ++ fields)`, with the actual `rhs` returned by the RHS helper and the actual `afterRhs` state.

The final target keeps the entire certificate action grouped as the first argument of `Except.bind`, followed by the success/false branch and RHS continuation. It does not replace `bind (bind x f) g` by a reassociated expression on an unknown result. The false telescope branches still return false at their current states; the outer false certificate branch still returns `none` at the certificate's returned state. `Except.bind` still propagates errors. The proof establishes the successful path using the same strict sub-run facts already present in the theorem statement.

## Why the proposed target changes are legitimate

The selected SDK defines `StateT σ m α` as a state-to-result function and `StateT.bind` by feeding both components of the preceding result to the continuation. The explicit equations use `found.1` or `checked.1` for the returned value and `.2` for precisely that returned state. The selected `Except.bind` propagates `.error` and applies the continuation only to `.ok`.

I checked each of the four local `change Except.bind ...` equations against those definitions and each final equation against the actual iota body. They preserve the function arguments, Boolean branches, exception behavior and nesting. The final application construction is state-neutral under the actual helper definition. The local `all_goals exact` and terminal `all_goals rfl` forms merely handle the possibility that a preceding rewrite closes a definitionally trivial goal.

The retained pinned SDK `Lean/Elab/Tactic/Change.lean` explicitly elaborates the proposed target and checks `isDefEq` against the existing goal before replacing the target. The new proof adds no unchecked replacement primitive, decision-instance unfolding, custom tactic, option change or new axiom. It avoids the previous broad simplification through Boolean decision implementation details. Whether these exact tactic scripts elaborate under the strict complete gate remains a compiler obligation; this static review does not certify their execution.

## Assembly, provenance and closure checks

I independently reconstructed every physical byte from the same five selected logical sources. Only the operational-contract source differs. The other four origins, two runtime owners, initial comment and ten boundary comments remain exact. All eight pre-existing import internalizations have the original before/after spellings. All thirteen assembly complements, including empty ones, match; reversing the internalizations recovers each selected logical source.

The new inventory retains the preceding 1,342 author rows literally and extends them to 1,375. The original historical ledger and the consumed manifest's one separately added iota-repair scope remain literal; their canonical input-array hashes match. The prior 39 control review scopes are historical dependencies, not new mathematical acceptance. The old initial assembly and first iota correction are not silently rebased to this candidate.

All 28 primary intervals are exact: the previous 23 remain literal and the five additions identify the consumed/new theorem and SDK target-change behavior. Seven retained complete SDK files match the pinned installed SDK. Six selected operational intervals also match the native originals verbatim; the three relevant full retained native files match the pinned checkout. The existing ordinary representation's removed `Repr` derivation and explicit `liftFueled` type binder are historical owner adaptations, not new proof changes or a claim that every native header is byte-identical.

The prospective selection is three owners with ordered report counts `[2, 6, 177]`: 185 distinct required names, 621,077 source bytes and six ordinary artifacts. The existing raw print spellings and previously reviewed fully qualified ordering remain unchanged. Old logical or physical owners must not be imported alongside their replacements. The higher FN construction, typing, driver, installed guards and native `Installed` are outside this selection.

## Limits and next step

The candidate has a passed independent source review and still needs root's separately reviewed complete fresh gate. No new preflight, compiler, evaluator, generator or numerical computation was run during this review. Previous failed stages remain consumed, and no existing project object supplies a fresh-build exemption. The fixed resource and axiom policy remains unchanged.

This review establishes neither complete cached query success nor actual installed annotations, original `GroupChecked`, or the stock `cqueens 16 = 14772512` theorem. It supports selecting this exact proof-only successor for the next full Interpreter185 attempt, with all earlier scopes and actual failure evidence retained separately.
