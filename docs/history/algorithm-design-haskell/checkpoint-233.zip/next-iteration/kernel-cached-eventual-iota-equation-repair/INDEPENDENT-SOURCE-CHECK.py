#!/usr/bin/env python3
"""Independent byte/provenance review only. Never imports or runs Lean or a gate."""
from pathlib import Path
import hashlib
import json
import re

PACKAGE = Path(__file__).resolve().parent
ROOT = PACKAGE.parent.parent
WORKSPACE = ROOT.parent
SDK = WORKSPACE / "toolchains/lean-4.35.0-linux/src/lean"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_path(name):
    path = (ROOT / name).resolve()
    assert path.is_relative_to(WORKSPACE), name
    assert path.is_file(), name
    return path.read_bytes()


verified = {}


def bound(row):
    key = (row["path"], row["bytes"], row["sha256"])
    if key not in verified:
        data = read_path(row["path"])
        assert len(data) == row["bytes"], row["path"]
        assert sha(data) == row["sha256"], row["path"]
        verified[key] = data
    return verified[key]


def load_name(name):
    return json.loads((PACKAGE / name).read_bytes())


def load_row(row):
    return json.loads(bound(row))


def span(data, row):
    first, end = row["start_byte"], row["end_byte_exclusive"]
    assert 0 <= first <= end <= len(data)
    part = data[first:end]
    assert len(part) == row["bytes"]
    assert sha(part) == row["sha256"]
    first_line = data.count(b"\n", 0, first) + 1
    last_line = (first_line if first == end else
                 data.count(b"\n", 0, end) + (0 if data[end - 1] == 10 else 1))
    assert (first_line, last_line) == (row["first_line"], row["last_line_inclusive"])
    return part


def exact_overlay(old, new, edits, complements, new_key):
    forward = bytearray()
    old_pos = new_pos = 0
    assert len(complements) == len(edits) + 1
    for index, edit in enumerate(edits):
        a, b = edit["original"], edit[new_key]
        assert a["start_byte"] >= old_pos and b["start_byte"] >= new_pos
        prior = complements[index]
        assert prior["original"]["start_byte"] == old_pos
        assert prior["original"]["end_byte_exclusive"] == a["start_byte"]
        assert prior[new_key]["start_byte"] == new_pos
        assert prior[new_key]["end_byte_exclusive"] == b["start_byte"]
        assert span(old, prior["original"]) == span(new, prior[new_key])
        assert span(old, a) == edit["before"].encode()
        assert span(new, b) == edit["after"].encode()
        forward += old[old_pos:a["start_byte"]] + edit["after"].encode()
        old_pos, new_pos = a["end_byte_exclusive"], b["end_byte_exclusive"]
    tail = complements[-1]
    assert (tail["original"]["start_byte"], tail["original"]["end_byte_exclusive"]) == (old_pos, len(old))
    assert (tail[new_key]["start_byte"], tail[new_key]["end_byte_exclusive"]) == (new_pos, len(new))
    assert span(old, tail["original"]) == span(new, tail[new_key])
    forward += old[old_pos:]
    assert bytes(forward) == new
    inverse = new
    for edit in reversed(edits):
        b = edit[new_key]
        inverse = inverse[:b["start_byte"]] + edit["before"].encode() + inverse[b["end_byte_exclusive"]:]
    assert inverse == old


def reports(data):
    return re.findall(rb"(?m)^#print axioms ([^\s]+)\s*$", data)


def theorem_headers(data):
    return re.findall(rb"(?ms)^(?:private )?theorem\s+.*?\s*:=", data)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


inventory = load_name("SOURCE-INVENTORY.json")
assert inventory["input_count"] == len(inventory["inputs"]) == 1375
assert len({r["path"] for r in inventory["inputs"]}) == 1375
for row in inventory["inputs"]:
    bound(row)

proof = load_name("PROOF-CORRECTION.json")
logical_old = bound(proof["logical"]["original"])
logical_new = bound(proof["logical"]["candidate"])
physical_old = bound(proof["physical"]["original"])
physical_new = bound(proof["physical"]["candidate"])
header_counts = {}
for kind, old, new in (("logical", logical_old, logical_new), ("physical", physical_old, physical_new)):
    row = proof[kind]
    assert row["edit_count"] == len(row["edits"]) == 1
    assert row["unchanged_complement_count"] == len(row["unchanged_complements"]) == 2
    exact_overlay(old, new, row["edits"], row["unchanged_complements"], "candidate")
    assert theorem_headers(old) == theorem_headers(new)
    assert reports(old) == reports(new)
    header_counts[kind] = len(theorem_headers(new))
    for pattern in [rb"(?m)^import .*?$", rb"(?m)^\s*set_option .*?$",
                    rb"(?m)^(?:namespace|section|end|open|attribute|instance|noncomputable|unsafe|partial)\b.*?$",
                    rb"(?m)^(?:(?:private|protected) )?(?:def|abbrev|inductive|structure)\s+.*?$"]:
        assert re.findall(pattern, old) == re.findall(pattern, new)
    edit = row["edits"][0]
    before_header = old.rfind(b"theorem iota_plain_of_prepared ", 0, edit["original"]["start_byte"])
    assert before_header >= 0
    header_end = old.index(b":= by\n", before_header) + len(b":= by\n")
    assert header_end < edit["original"]["start_byte"]
    assert old[before_header:header_end] == new[before_header:header_end]
    assert b"\n#print axioms partial_iota_arity" in old[edit["original"]["end_byte_exclusive"]:]
    assert not re.search(rb"(?m)^\s*(?:set_option|axiom|sorry|admit|unsafe|native_decide|run_tac)\b", edit["after"].encode())
assert proof["logical"]["edits"][0]["before"] == proof["physical"]["edits"][0]["before"]
assert proof["logical"]["edits"][0]["after"] == proof["physical"]["edits"][0]["after"]
assert len(logical_new) - len(logical_old) == len(physical_new) - len(physical_old) == 2568

lineage = load_name("ASSEMBLY-LINEAGE.json")
assert bound(lineage["candidate"]) == physical_new
assert span(physical_new, lineage["header_span"]) == lineage["header_literal"].encode()
rebuilt = bytearray(lineage["header_literal"].encode())
assembly_edits = complements = 0
origin_reports = []
previous_lineage = load_row(lineage["previous_assembly_map"])
assert len(lineage["origins"]) == len(previous_lineage["origins"]) == 5
for index, row in enumerate(lineage["origins"], 1):
    original = bound(row["source"])
    banner, body, footer = row["banner"], row["body"], row["footer"]
    assert row["order"] == index
    assert banner["physical_start_byte"] == len(rebuilt)
    assert banner["physical_end_byte_exclusive"] == len(rebuilt) + len(banner["literal"].encode())
    rebuilt += banner["literal"].encode()
    assert body["physical_start_byte"] == len(rebuilt)
    transformed = physical_new[body["physical_start_byte"]:body["physical_end_byte_exclusive"]]
    assert (len(transformed), sha(transformed)) == (body["bytes"], body["sha256"])
    exact_overlay(original, transformed, row["edits"], row["unchanged_complements"], "transformed")
    assert row["edit_count"] == len(row["edits"])
    assert row["unchanged_complement_count_including_empty_spans"] == len(row["unchanged_complements"])
    for edit in row["edits"]:
        assert edit["kind"] == "internalize_import_as_literal_line_comment"
        assert edit["before"] == "import " + edit["imported_module"] + "\n"
        assert edit["after"] == "-- [assembly import internalized] " + edit["before"]
        assert edit["physical_start_byte"] == body["physical_start_byte"] + edit["transformed"]["start_byte"]
        assert edit["physical_end_byte_exclusive"] == body["physical_start_byte"] + edit["transformed"]["end_byte_exclusive"]
    for keep in row["unchanged_complements"]:
        assert keep["physical_start_byte"] == body["physical_start_byte"] + keep["transformed"]["start_byte"]
        assert keep["physical_end_byte_exclusive"] == body["physical_start_byte"] + keep["transformed"]["end_byte_exclusive"]
    prior = previous_lineage["origins"][index-1]
    assert row["original_module"] == prior["original_module"]
    assert row["historical_original_source"] == prior["historical_original_source"]
    assert row["previous_selected_source"] == prior["source"]
    assert [e["before"] for e in row["edits"]] == [e["before"] for e in prior["edits"]]
    assert [e["after"] for e in row["edits"]] == [e["after"] for e in prior["edits"]]
    assert row["ordered_report_roots"] == prior["ordered_report_roots"]
    assert len(reports(original)) == row["report_count"]
    if index != 2:
        assert row["source"] == prior["source"]
    else:
        assert row["source"] == proof["logical"]["candidate"]
    rebuilt += transformed
    assert footer["physical_start_byte"] == len(rebuilt)
    assert footer["physical_end_byte_exclusive"] == len(rebuilt) + len(footer["literal"].encode())
    rebuilt += footer["literal"].encode()
    assembly_edits += len(row["edits"])
    complements += len(row["unchanged_complements"])
    origin_reports += row["ordered_report_roots"]
assert bytes(rebuilt) == physical_new
assert assembly_edits == lineage["internalized_import_count"] == 8
assert complements == lineage["unchanged_complement_count_including_empty_spans"] == 13
assert len(origin_reports) == len(set(origin_reports)) == len(reports(physical_new)) == 177

primary = load_name("PRIMARY-SOURCE-CONTEXT.json")
previous_primary = load_row(primary["previous_context"])
assert primary["previous_intervals_preserved_exactly"] == previous_primary["intervals"]
intervals = primary["previous_intervals_preserved_exactly"] + primary["new_intervals"]
assert len(intervals) == primary["total_interval_count"] == 28
assert len(primary["previous_intervals_preserved_exactly"]) == 23
assert len(primary["new_intervals"]) == 5
for row in intervals:
    assert span(bound(row["source"]), row["span"]) == row["literal_text"].encode()
for row in primary["SDK_full_copies"]:
    assert bound(row["copy"]) == (SDK / row["sdk_relative_path"]).read_bytes()
assert len(primary["SDK_full_copies"]) == 7

historical = load_name("HISTORICAL-REVIEW-SCOPES.json")
assert historical["previous_ledger_literal"] == load_row(historical["previous_scope_ledger"])
prior_inventory = load_row(historical["prior_iota_repair"]["inventory"])
assert inventory["previous_author_input_array_preserved_exactly"] == prior_inventory["inputs"]
assert inventory["previous_author_input_count"] == len(prior_inventory["inputs"]) == 1342
assert all(r in inventory["inputs"] for r in prior_inventory["inputs"])
prior_audit = load_row(historical["prior_iota_repair"]["audit"])
assert len(prior_audit["inputs"]) == historical["prior_iota_repair"]["review_count"] == 1343
old_manifest = load_row(historical["previous_consumed_manifest"])
assert historical["previous_added_separate_control_scope_literal"] == old_manifest["new_separate_review_scopes"]
assert historical["prior_total_separate_control_review_scope_count"] == old_manifest["current_total_separate_independent_review_scope_count"] == 39
for row in historical["previous_added_separate_control_scope_literal"]:
    for field in ["author_inputs", "review_inputs"]:
        desc = row[field]
        values = load_row(desc["source"])[desc["json_field"]]
        assert (len(values),len(canonical(values)),sha(canonical(values))) == (
            desc["item_count"],desc["canonical_json_bytes"],desc["canonical_json_sha256"])
for row in historical["previous_ledger_literal"]["immediate_scopes"]:
    assert len(load_row(row["inventory"])["inputs"]) == row["author_count"]
    assert len(load_row(row["audit"])["inputs"]) == row["review_count"]

diagnostic = load_name("CAPTURED-DIAGNOSTICS.json")
stdout = bound(diagnostic["raw_stdout"])
assert len(stdout.splitlines()) == diagnostic["raw_stdout_line_count"] == 696
assert stdout.endswith(b"\n") == diagnostic["raw_stdout_ends_in_newline"]
errors = re.findall(rb"(?m)^KernelCachedEventualInterpreter\.lean:(\d+):(\d+): error:", stdout)
assert len(errors) == diagnostic["complete_captured_error_headers"] == 1
assert len(re.findall(rb"(?m)^'[^\n]+' depends on axioms:", stdout)) == diagnostic["raw_stdout_report_headers_observed"] == 177
assert len(diagnostic["diagnostics"]) == 1
for row in diagnostic["diagnostics"]:
    assert span(stdout, row["log_span"]) == row["captured_text"].encode()
    assert physical_old.splitlines()[row["physical_line"]-1].decode() == row["source_line"]
    assert logical_old.splitlines()[row["logical_line"]-1].decode() == row["source_line"]
    assert errors[0] == (str(row["physical_line"]).encode(), str(row["column"]).encode())
assert diagnostic["consumed_source_key"] == proof["consumed_source_key"] == inventory["consumed_source_key"] == old_manifest["source_fingerprint"]
# Identity-only report/recovery/receipt bindings: no report, marker or recovery reader is invoked.
for key in ["report_identity_only", "root_execution_receipt", "root_result_note", "actual_snapshot_recovery", "consumed_marker"]:
    bound(diagnostic[key])

census = load_name("PROSPECTIVE-SOURCE-CENSUS.json")
prior_census = load_row(census["consumed_selection_retained_as_history"])
assert census["selected_physical_sources"] == inventory["selected_physical_sources"]
assert census["selected_physical_sources"][:2] == prior_census["selected_physical_sources"][:2]
assert census["selected_physical_sources"][2] == proof["physical"]["candidate"]
assert census["physical_owner_count"] == len(census["physical_modules"]) == 3
assert census["ordered_reports"] == prior_census["ordered_reports"] == inventory["ordered_reports"]
assert census["ordered_report_counts"] == [2,6,177]
assert len(census["ordered_reports"]) == len(set(census["ordered_reports"])) == 185
assert census["source_bytes"] == sum(r["bytes"] for r in census["selected_physical_sources"]) == 621077
assert census["ordinary_output_count"] == 6
combined = []
for row, prior in zip(census["physical_modules"], prior_census["physical_modules"]):
    assert row["module"] == prior["module"]
    assert row["imports"] == prior["imports"]
    assert row["ordered_reports"] == prior["ordered_reports"]
    data = bound(row["source"])
    assert re.findall(rb"(?m)^import (\S+)$", data) == [x.encode() for x in row["imports"]]
    assert len(reports(data)) == row["report_count"]
    combined += row["ordered_reports"]
assert combined == census["ordered_reports"]
assert origin_reports == census["physical_modules"][2]["ordered_reports"]

# Six exact primary body intervals are also present verbatim in the retained native originals.
native_paths = {
    "recursor_parameter_comparison": "next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Env.lean",
    "actual_mk_app": "next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/StateC.lean",
    "actual_level_substitution": "next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/StateC.lean",
    "actual_level_list_comparison": "next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/StateC.lean",
    "actual_certificate_gate": "next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/CoreC.lean",
    "complete_actual_iota": "next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/CoreC.lean",
}
input_by_path = {r["path"]:r for r in inventory["inputs"]}
native_pair_records = []
for label, path in native_paths.items():
    row = next(r for r in intervals if r["label"] == label)
    native = bound(input_by_path[path])
    text = row["literal_text"].encode()
    assert native.count(text) == 1
    offset = native.index(text)
    native_pair_records.append({"label":label,"current_source":row["source"],"current_span":row["span"],
                                "retained_native_source":input_by_path[path],"native_start_byte":offset,
                                "native_end_byte_exclusive":offset+len(text),"sha256":sha(text)})
for path in set(native_paths.values()):
    relative = path.split("/upstream/",1)[1]
    checkout = WORKSPACE / "upstream-source/con-leche-67f04630d88718e81aa4d07ab64501f68f105398" / relative
    assert bound(input_by_path[path]) == checkout.read_bytes()

result = {
    "format":"adwh-independent-eventual-iota-equation-source-check-v1",
    "status":"passed_static_identity_and_correspondence_checks_only",
    "author_input_count_verified":1375,
    "previous_1342_input_array_literal":True,
    "logical_and_physical_edit_counts":[1,1],
    "logical_and_physical_unchanged_complement_counts":[2,2],
    "exact_forward_inverse_and_whole_file_reconstruction":True,
    "unchanged_theorem_header_counts":header_counts,
    "unchanged_logical_and_physical_print_counts":[32,177],
    "five_origin_assembly_import_edits":assembly_edits,
    "five_origin_assembly_unchanged_complements":complements,
    "primary_intervals_verified":28,
    "complete_SDK_copies_verified":7,
    "exact_native_current_interval_pairs":native_pair_records,
    "native_complete_copy_pairs_verified":3,
    "captured_error_headers":1,
    "raw_diagnostic_span_bytes":8937,
    "historical_control_review_scopes_preserved":39,
    "selected_physical_owners":3,
    "selected_source_bytes":621077,
    "ordered_distinct_report_count":185,
    "ordinary_outputs":6,
    "gate_or_helper_imported":False,
    "gate_preflight_Lean_compiler_native_or_mathematical_execution":False,
    "saved_report_marker_or_recovery_reader_executed":False,
    "mathematical_acceptance_or_budget_fit_claimed":False,
}
(PACKAGE/"INDEPENDENT-SOURCE-CHECK.json").write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n")
print(json.dumps({k:v for k,v in result.items() if k != "exact_native_current_interval_pairs"},indent=2))
