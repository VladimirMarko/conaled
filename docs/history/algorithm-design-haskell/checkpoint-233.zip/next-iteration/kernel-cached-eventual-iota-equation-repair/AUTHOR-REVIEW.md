# Author review: explicit eventual iota equations

This is an author source review, not independent review or Lean acceptance.

I read the complete actual `iotaRecI` branch and the captured single diagnostic. The replacement starts after the already established plain/inert discrimination. Its four local do-continuations mirror the exact original grouping and state order of the certificate block. Constructor and recursor telescope success preserve the explicit states supplied by the existing `NeverPiPrefix`-derived runs; constructor and recursor type helpers use their actual returned states; the RHS helper runs only after the complete certificate succeeds. Every error and false-certificate branch is retained in the local definitional equations.

The initial empty level comparison uses the actual empty-list operations, the plain rule's parameter comparison is disabled by its actual stored bit, and the verified certificate switch selects the actual certificate block. The final `change` requests the exact nested Except equation after those closed reductions. No unconditional monad associativity, arbitrary state equality or whole iota success is assumed. Each local success fact is proved from an existing strict sub-run premise; the final RHS is constructed from the actual returned expression.

The new source avoids the observed partially unfolded Boolean decision-instance terms. `change` checks definitional equality of the whole well-typed proposed target. It does not bypass kernel checking, hide a branch or introduce a new axiom. `all_goals` after rewrites is only a proof-script safeguard for already closed goals.

Both alternate files are exact one-span overlays. The theorem header and all other declarations are literal. The physical file is also independently reconstructed from the same five complete logical inputs, keeping all original import comments and boundaries. Historical scopes retain their old identities, statuses and input arrays. The new span has not been elaborated, compiled, preflighted or evaluated; a definitional-equality or strict-warning failure remains possible until the reviewed complete gate is run by root.
