# Complete fresh equation-repaired interpreter185 protocol

## Scope

Only root may review, preflight and execute these controls. Authoring this directory does not execute or import any gate, compiler, helper, generator or mathematical program. The selected sources are the unchanged reduced ordinary Core (2 reports), unchanged complete Cached owner (6 reports), and the separately reviewed equation-corrected Interpreter (177 reports). All three owners are built afresh, yielding 185 distinct reports and exactly six default `.olean` / `.ilean` outputs from 621,077 source bytes.

This selection tests the complete non-atomic trace interpreter and bounded query interface together with the accepted foundation source. It does not select FN construction, Typing, Driver, record guards, installed guards or native Installed. A successful result would not discharge a concrete complete query, annotated ProgramPins, original GroupChecked, or the stock numeral theorem.

## Exact source lineage

The consumed first185 assembly has its own1305/1306 source scope. The next consumed iota-proof repair preserves one logical/physical overlay and its1342/1343 scope. This successor adds the separately reviewed1375/1378 equation scope; it never rewrites earlier arrays, selections, statuses or diagnoses. The immutable preceding39-scope validator is called only for metadata. Its `main` and `run` are never invoked. The current total is40 separate source-review scopes.

Current metadata verifies both one-span equation overlays in both directions, all unchanged complements and headers, and reconstructs every byte of the five-input physical owner from the selected sources with the original eight import-comment edits, thirteen complements and unchanged boundary text. The original assembly, preceding overlay and current overlay remain separately bound. All three current source identities,177 proof reports and the complete185 root sequence are exact.

The primary-context check preserves the original23 intervals and adds five, retaining seven complete SDK copies. Six exact ordinary/native operational body intervals and their three retained native source copies are checked separately as evidence. They are not compiled imports and do not imply native installation compatibility. The latest raw diagnostic, receipt, report, marker and recovery identities remain bound; the previous failed owner is still rejected.

## Bootstrap and input integrity

Every current source, manifest-listed control and fixed metadata identity is checked before importing any retained validator or helper. The explicit immutable chain is equation185 → diagnosed185 → original185 → Foundation134 → Eventual41 → interface111. Only the dependency handles that each historical `main` ordinarily initializes are connected. All old policy, selection, manifest and review globals remain unchanged. The eight exact external-context recovery tuples remain literal; no path search or arbitrary fallback is allowed.

The current snapshot union includes every previous source/control plus all1375 author inputs and1378 independent review inputs, deduplicating only identical path/size/hash identities. The selected sources and controls, compiler and runtime are checked before compilation; immutable snapshots are compared again after the run. An independent root control review and metadata-only preflight must precede the sole mathematical attempt.

## Fixed execution policy

The complete fresh computation receives one cumulative30-second deadline, one CPU, one compiler thread, and one GiB memory. Heartbeat, recursion and compiler resource defaults are unchanged. Compiler arguments remain `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`, with ordinary `.olean` and `.ilean` outputs. No native executable, exporter, proof cache or prepared experimental object is imported or run. Only the pinned SDK/runtime search path and fresh build directory are admitted.

The consumed source key `e83b4b93eed3f30889ab452f532fbf6799b75969f42def71f8f711e9087b653d` is preserved permanently. The new key uses the unchanged `cached-forward-runs-and-licensed` stage and policy with the new exact source hashes. All older no-retry marker directories remain checked and the consumed diagnosed185 directory is appended. Existing attempts, the current marker, or any historical marker for this exact source key forbid execution.

The actual compiler invocation, cumulative timer, process-tree watchdog, CPU affinity, clean environment, memory enforcement, snapshot/post-run integrity, output inventory, strict diagnostic audit and final pass predicate are literal to the consumed predecessor. The mapped `run` changes only the newly appended predecessor directory, its explanatory comment and two review-count fields. A full forward/inverse map covers the complete runner as well as the run block.

## Acceptance and limits

Every physical owner is accepted only as a whole: zero compiler exit, within the cumulative limits, exactly the required reports, no unrecognized diagnostic or recovery admission, permitted axioms only (`propext`, `Classical.choice`, `Quot.sound`), and both required outputs. All185 reports, six exact artifacts, unchanged inputs/runtime/snapshots, complete module order, total elapsed≤30 seconds and peak resident memory≤1048576 KiB are required for a complete pass. Partial or recovered report output is never acceptance.

The preceding attempt failed after25.563569123994967 seconds with8 accepted and185 observed reports. The new proof is independently source-reviewed; it has not been compiled or timed. The proof repair supplies no evidence of a cost improvement or complete resource fit. Any diagnostic or resource failure consumes the new key and requires a genuine separately reviewed source change before another attempt.
