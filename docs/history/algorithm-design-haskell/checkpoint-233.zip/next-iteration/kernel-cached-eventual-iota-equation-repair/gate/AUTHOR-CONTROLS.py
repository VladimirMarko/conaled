#!/usr/bin/env python3
"""New literal source/control authoring only; no project imports or execution."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import pprint
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = HERE.parent
BASE = ROOT / 'next-iteration/kernel-cached-eventual-iota-proof-repair/gate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)}


def read_json(path):
    path = Path(path)
    return json.loads((path if path.is_absolute() else ROOT / path).read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def array_ref(path, field):
    values = read_json(path)[field]
    raw = canonical(values)
    return {'source': pin(path), 'json_field': field, 'item_count': len(values),
            'canonical_json_bytes': len(raw), 'canonical_json_sha256': sha(raw)}


def dump(name, value):
    path = HERE / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return pin(path)


def span(data, start, end):
    assert 0 <= start <= end <= len(data)
    return {'start_byte': start, 'end_byte_exclusive': end,
            'bytes': end-start, 'sha256': sha(data[start:end])}


def complete_overlay(old, new):
    """Exact line-aligned byte map, not a Python/Lean parser or validator."""
    old_lines, new_lines = old.splitlines(keepends=True), new.splitlines(keepends=True)
    def offsets(lines):
        out = [0]
        for line in lines:
            out.append(out[-1] + len(line))
        return out
    old_pos, new_pos = offsets(old_lines), offsets(new_lines)
    edits, complements = [], []
    for kind, a0, b0, c0, d0 in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes():
        a, b, c, d = old_pos[a0], old_pos[b0], new_pos[c0], new_pos[d0]
        row = {'original': span(old, a, b), 'candidate': span(new, c, d)}
        if kind == 'equal':
            assert old[a:b] == new[c:d]
            complements.append(row)
        else:
            row.update({'kind': kind, 'before': old[a:b].decode(), 'after': new[c:d].decode()})
            edits.append(row)
    forward = old
    for edit in reversed(edits):
        a, b = edit['original']['start_byte'], edit['original']['end_byte_exclusive']
        assert forward[a:b] == edit['before'].encode()
        forward = forward[:a] + edit['after'].encode() + forward[b:]
    inverse = new
    for edit in reversed(edits):
        a, b = edit['candidate']['start_byte'], edit['candidate']['end_byte_exclusive']
        assert inverse[a:b] == edit['after'].encode()
        inverse = inverse[:a] + edit['before'].encode() + inverse[b:]
    assert forward == new and inverse == old
    return {'original_bytes': len(old), 'original_sha256': sha(old),
            'candidate_bytes': len(new), 'candidate_sha256': sha(new),
            'edit_count': len(edits), 'edits': edits,
            'unchanged_complement_count': len(complements), 'unchanged_complements': complements,
            'complete_forward_and_inverse_verified': True}


base_manifest = read_json(BASE / 'source-manifest.json')
base_runner = (BASE / 'run_gate.py').read_text()
author = read_json(PACKAGE / 'SOURCE-INVENTORY.json')
audit = read_json(PACKAGE / 'SOURCE-AUDIT.json')
assert pin(BASE / 'run_gate.py')['sha256'] == 'a2c36d37633581ed3dbcdb4e8c8880e80fbc2b862164211bb79639b2f0cd535a'
assert pin(BASE / 'source-manifest.json')['sha256'] == '473e720f1617334201b8cde8e5a2a2fe5ca6164f2ac44296167d27d16b60da9e'
assert base_manifest['current_total_separate_independent_review_scope_count'] == 39
assert author['input_count'] == len(author['inputs']) == 1375
assert audit['author_input_count_verified'] == 1375
assert audit['direct_input_count'] == len(audit['inputs']) == 1378
assert audit['status'] == 'passed_independent_diagnosed_source_review_uncompiled'
assert pin(PACKAGE / 'SOURCE-AUDIT.json')['sha256'] == '474c181b8046b3e0750bb672231ad24bb415009ce758ea43d1917885fb855d4a'
assert pin(PACKAGE / 'SOURCE-REVIEW.md')['sha256'] == '914f9b260f099a9ee1bff94b36e2bda83b805266dcbc091df2a966a5114a8a42'

sources = copy.deepcopy(base_manifest['sources'])
sources[2].update(author['physical_source'])
assert author['selected_physical_sources'] == [{k:r[k] for k in ('path','bytes','sha256')} for r in sources]
assert sum(row['bytes'] for row in sources) == 621077
modules = [row['module'] for row in sources]
required = {row['module']: row['fully_qualified_roots'] for row in sources}
raw_required = {row['module']: row['raw_source_print_identifiers'] for row in sources}
assert modules == ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedEventualInterpreter']
assert [len(required[m]) for m in modules] == [2,6,177]
assert len({name for values in required.values() for name in values}) == 185
assert re.findall(r'^\s*#print\s+axioms\s+(\S+)', (ROOT / sources[2]['path']).read_text(), re.M) == raw_required[modules[2]]

scope = {'name': 'DiagnosedEventualIotaExplicitEquationRepair',
         'author_inventory': pin(PACKAGE / 'SOURCE-INVENTORY.json'),
         'source_audit': pin(PACKAGE / 'SOURCE-AUDIT.json'),
         'source_review': pin(PACKAGE / 'SOURCE-REVIEW.md'),
         'author_inputs': array_ref(PACKAGE / 'SOURCE-INVENTORY.json', 'inputs'),
         'review_inputs': array_ref(PACKAGE / 'SOURCE-AUDIT.json', 'inputs'),
         'author_input_count': 1375, 'review_input_count': 1378,
         'audit_status': audit['status'], 'reviewer': audit['reviewer'],
         'original_scope_or_selection_rebased': False}
assert scope['source_audit']['path'] not in {row['path'] for row in base_manifest['controls']}
recovery = copy.deepcopy(base_manifest['external_review_context_recovery'])
assert len(recovery) == 8
bound = {}


def add(row):
    item = {k:row[k] for k in ('path','bytes','sha256')}
    if item['path'].startswith('../'):
        matches = [r for r in recovery if r['original_context'] == item]
        assert len(matches) == 1, item
        item = matches[0]['retained_copy']
    assert not Path(item['path']).is_absolute() and '..' not in Path(item['path']).parts
    assert pin(item['path']) == item, item['path']
    assert item['path'] not in bound or bound[item['path']] == item
    bound[item['path']] = item


for row in base_manifest['sources'] + base_manifest['controls']:
    add(row)
add(pin(BASE / 'source-manifest.json'))
for document in (author, audit):
    for row in document['inputs']:
        add(row)
for key in ('author_inventory','source_audit','source_review'):
    add(scope[key])
for row in sources:
    add(row)
for name in ('AUTHOR-CONTROLS.py','TEXT-AUTHOR.py','runner-metadata.py.txt','runner-main.py.txt','PROTOCOL.md','AUTHORING.md'):
    add(pin(HERE / name))
for name in ('INDEPENDENT-CONTROL-CHECK.py','INDEPENDENT-CONTROL-CHECK.json','INDEPENDENT-CONTROL-REVIEW.md'):
    add(pin(BASE / name))

policy = copy.deepcopy(base_manifest['policy'])
fingerprint_body = {'stage':'cached-forward-runs-and-licensed','policy':policy,
                    'sources':[{'module':r['module'],'sha256':r['sha256']} for r in sources]}
source_key = sha(json.dumps(fingerprint_body,sort_keys=True,separators=(',',':')).encode())
assert source_key != base_manifest['source_fingerprint'] == author['consumed_source_key']


def literal(value):
    return pprint.pformat(value, sort_dicts=True, width=120)


prefix = base_runner[:base_runner.index('HERE = Path(__file__)')]
prefix = prefix.replace('Fresh diagnosed-iota corrected eventual interpreter185.',
                        'Fresh explicit-equation corrected eventual interpreter185.')
globals_text = """HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-iota-proof-repair/gate'
REPAIR = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-iota-equation185-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-iota-equation185-manifest-v1'
PREVIOUS = None
HISTORICAL = None
"""
constants = {
    'POLICY':policy,'ALLOWED':{'propext','Classical.choice','Quot.sound'},
    'PREVIOUS_RUNNER_PIN':tuple(pin(BASE/'run_gate.py')[k] for k in ('path','bytes','sha256')),
    'PREVIOUS_MANIFEST_PIN':tuple(pin(BASE/'source-manifest.json')[k] for k in ('path','bytes','sha256')),
    'MODULES':modules,'SOURCE_PINS':[tuple(r[k] for k in ('path','bytes','sha256')) for r in sources],
    'EXPECTED_IMPORTS':{r['module']:r['imports'] for r in sources},
    'REQUIRED':required,'RAW_REQUIRED':raw_required,'CURRENT_LOGICAL':author['logical_source'],
    'REPAIR_SCOPE':scope,'REPAIR_REVIEW_FACTS':audit['checks'],
    'CONSUMED_SOURCE_KEY':base_manifest['source_fingerprint'],'EXTERNAL_RECOVERY':recovery,
    'NEW_FIXED':{p:r['sha256'] for p,r in sorted(bound.items())}}
for name,value in constants.items():
    globals_text += name+' = '+literal(value)+'\n'

common_helpers = base_runner[base_runner.index('def require('):base_runner.index('def check_source(')]
audit_logs = base_runner[base_runner.index('def audit_logs('):base_runner.index('def run(')]
old_run = base_runner[base_runner.index('def run('):base_runner.index('def main(')]
new_run = old_run
replacements = [
    ('# Every historical no-retry directory is retained, with the consumed185 interpreter appended.',
     '# Every historical no-retry directory is retained, with the consumed185 iota-proof repair appended.'),
    ('for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR,\n'
     '                                        PREVIOUS.PREVIOUS.PREVIOUS.PREDECESSOR]',
     'for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR,\n'
     '                                        PREVIOUS.PREVIOUS.PREVIOUS.PREDECESSOR,\n'
     '                                        PREVIOUS.PREVIOUS.PREVIOUS.PREVIOUS.PREDECESSOR]'),
    ("'historical_independent_review_scope_count': 38,","'historical_independent_review_scope_count': 39,"),
    ("'total_separate_independent_review_scope_count': 39,","'total_separate_independent_review_scope_count': 40,")]
for before,after in replacements:
    assert new_run.count(before) == 1, before
    new_run = new_run.replace(before,after,1)

metadata = (HERE/'runner-metadata.py.txt').read_text()
main = (HERE/'runner-main.py.txt').read_text()
runner_text = prefix+globals_text+'\n'+common_helpers+metadata+'\n'+audit_logs+new_run+main
runner_path = HERE/'run_gate.py'
assert not runner_path.exists()
runner_path.write_text(runner_text)
runner_pin = pin(runner_path)

old_full,new_full = base_runner.encode(),runner_text.encode()
old_bytes,new_bytes = old_run.encode(),new_run.encode()
old_offset,new_offset = old_full.index(old_bytes),new_full.index(new_bytes)
run_overlay = complete_overlay(old_bytes,new_bytes)
runner_overlay = complete_overlay(old_full,new_full)
literal_sections=[]
for label,start,end in [
    ('snapshot_marker_affinity_environment_setup','    h.save(report_path, report)\n    began = None','        began = time.monotonic()'),
    ('complete_cumulative_timer_compiler_watchdog_and_module_audit','        began = time.monotonic()','    except BaseException as exc:'),
    ('postrun_readonly_runtime_artifact_affinity_and_elapsed_checks',"    finally:\n        try:\n            report['artifacts']",'        passed = (')]:
    a=old_run.index(start);b=old_run.index(end,a)
    c=new_run.index(start);d=new_run.index(end,c)
    assert old_run[a:b]==new_run[c:d],label
    literal_sections.append({'label':label,'original_file_span':span(old_full,old_offset+a,old_offset+b),
                             'candidate_file_span':span(new_full,new_offset+c,new_offset+d)})
a,c=old_run.index('        passed = ('),new_run.index('        passed = (')
assert old_run[a:]==new_run[c:]
literal_sections.append({'label':'complete_acceptance_flags_and_final_report_tail',
    'original_file_span':span(old_full,old_offset+a,old_offset+len(old_bytes)),
    'candidate_file_span':span(new_full,new_offset+c,new_offset+len(new_bytes))})
for label,text in [('common_identity_fingerprint_integrity_helpers',common_helpers),('unchanged_axiom_audit_delegation',audit_logs)]:
    data=text.encode();a,c=old_full.index(data),new_full.index(data)
    literal_sections.append({'label':label,'original_file_span':span(old_full,a,a+len(data)),
                             'candidate_file_span':span(new_full,c,c+len(data))})
assert len(literal_sections)==6

control_file_overlays=[]
for name in ['runner-metadata.py.txt','runner-main.py.txt','PROTOCOL.md','AUTHORING.md','AUTHOR-CONTROLS.py']:
    old_path,new_path=BASE/name,HERE/name
    control_file_overlays.append({'name':name,'original':pin(old_path),'candidate':pin(new_path),
                                  'complete_overlay':complete_overlay(old_path.read_bytes(),new_path.read_bytes())})

correspondence=dump('CONTROL-CORRESPONDENCE.json',{
    'format':'adwh-equation185-from-consumed-iota185-controls-v1',
    'status':'source_only_controls_awaiting_independent_root_review',
    'baseline_runner':pin(BASE/'run_gate.py'),'baseline_manifest':pin(BASE/'source-manifest.json'),
    'baseline_control_review':pin(BASE/'INDEPENDENT-CONTROL-REVIEW.md'),
    'baseline_control_audit':pin(BASE/'INDEPENDENT-CONTROL-CHECK.json'),
    'baseline_consumed_report_identity_only':pin(BASE/'attempts/complete-01/report.json'),
    'baseline_root_execution_receipt':pin(BASE/'ROOT-EXECUTION-RECEIPT.json'),
    'baseline_snapshot_recovery':pin(BASE/'SNAPSHOT-RECOVERY.json'),
    'baseline_consumed_marker':pin(BASE/'execution-markers'/('complete-'+author['consumed_source_key']+'.json')),
    'candidate_runner':runner_pin,'source_of_new_metadata':pin(HERE/'runner-metadata.py.txt'),
    'source_of_new_bootstrap':pin(HERE/'runner-main.py.txt'),'text_only_author':pin(HERE/'TEXT-AUTHOR.py'),
    'complete_runner_overlay':runner_overlay,'complete_runner_forward_and_inverse_verified':True,
    'complete_control_file_overlays':control_file_overlays,
    'run_block_original_file_span':span(old_full,old_offset,old_offset+len(old_bytes)),
    'run_block_candidate_file_span':span(new_full,new_offset,new_offset+len(new_bytes)),
    'run_block_exact_logical_replacement_count':len(replacements),
    'run_block_logical_replacements':[{'before':a,'after':b} for a,b in replacements],
    'run_block_overlay':run_overlay,'complete_run_block_forward_and_inverse_verified':True,
    'whole_run_block_literal_claimed':False,'literal_execution_sections':literal_sections,
    'resource_limits_default_options_compiler_flags_timer_watchdog_affinity_and_three_axioms_changed':False,
    'complete_acceptance_predicate_or_report_flags_changed':False,
    'permanent_stage_or_fingerprint_policy_changed':False,
    'additional_predecessor_marker_directory':'next-iteration/kernel-cached-eventual-iota-proof-repair/gate',
    'all_prior_marker_directories_retained':True,
    'metadata_only_validation_chain':['equation185','diagnosed185','original185','unchanged134','unchanged41','unchanged111'],
    'old_run_or_main_called':False,'old_selection_policy_manifest_or_review_globals_modified':False,
    'old_dependency_handles_initialized_as_in_their_original_main':True,
    'historical_review_scope_count':39,'new_exact_independent_audit_scopes':1,'total_distinct_review_scope_count':40,
    'external_tuple_routes':8,'all_eight_external_tuple_routes_unchanged':True,
    'current_sources_and_metadata_bound_before_any_retained_import':True,
    'physical_module_acceptance_all_or_nothing':True,
    'old_source_arrays_and_diagnostics_retained_without_rebase':True,
    'new_native_interval_pairs':6,'new_primary_intervals_including_inherited':28,'new_complete_SDK_copies':7,
    'author_imported_AST_checked_preflighted_or_executed_runner_or_math':False})
add(runner_pin);add(correspondence)

source_paths={r['path'] for r in sources}
controls=[{**row,'role':f'bound-input-{i:04d}'} for i,row in enumerate(
    [bound[p] for p in sorted(bound) if p not in source_paths],1)]
assert len({r['path'] for r in controls})==len(controls)
assert all(not row['path'].endswith(('.olean','.ilean','.c','.o','.so')) for row in controls)
origin_rows=copy.deepcopy(base_manifest['complete_origin_source_rows'])
assert len(origin_rows)==28 and origin_rows[24]['path']=='next-iteration/kernel-cached-eventual-iota-proof-repair/logical-source/KernelCachedOperationalContracts.lean'
origin_rows[24]=author['logical_source']
historical_fields=['historical_context','new_separate_review_scopes','external_review_context_recovery',
                   'logical_origins','complete_origin_source_rows']
manifest={
    'format':'adwh-kernel-cached-eventual-iota-equation185-manifest-v1',
    'status':'frozen_ready_for_independent_root_control_review',
    'policy':policy,'module_order':modules,'sources':sources,'prepared_objects':[],'export_targets':[],
    'ordered_report_counts':[2,6,177],'required_axiom_report_count':185,'required_unique_axiom_name_count':185,
    'selected_physical_source_bytes':621077,'expected_artifact_count':6,
    'logical_origins':base_manifest['logical_origins'],'complete_origin_source_rows':origin_rows,
    'distinct_upstream_origin_count':16,'distinct_project_origin_count':12,'distinct_logical_origin_count':28,
    'source_segment_count':30,'source_segment_count_convention':base_manifest['source_segment_count_convention'],
    'historical_context':{'runner':pin(BASE/'run_gate.py'),'manifest':pin(BASE/'source-manifest.json'),
        'validator':'preflight','historical_review_scope_count':39,
        'exact_field_references':{field:array_ref(BASE/'source-manifest.json',field) for field in historical_fields},
        'old_main_or_run_called':False,'old_source_selection_or_review_arrays_mutated':False,
        'old_dependency_handles_initialized':True,'old_complete_preflight_checks_retained':True},
    'historical_independent_review_scope_count':39,'current_total_separate_independent_review_scope_count':40,
    'historical_reviews_rebased':False,'new_separate_review_scopes':[scope],'new_independent_review_scope_count':1,
    'review_scope_deduplication':'Only exact audit identity; overlapping input arrays are not additional source reviews',
    'external_review_context_recovery':recovery,'root_only_preflight_and_run':True,
    'all_current_cached_runtime_declarations_preserved':True,'actual_reference_state_is_empty_CState':True,
    'conditional_record_wrapper_only':True,'non_atomic_trace_interpreter_and_query_interface_included':True,
    'FN_construction_Typing_Driver_or_guards_selected':False,'whole_query_cached_success_claimed':False,
    'original_GroupChecked_claimed':False,'stock_numeral_theorem_claimed':False,
    'measured_cost_benefit_or_budget_fit_claimed_before_run':False,
    'consumed_predecessor_source_key':base_manifest['source_fingerprint'],
    'source_fingerprint':source_key,'controls':controls,
    'snapshot_count_including_manifest':len(sources)+len(controls)+1}
manifest_pin=dump('source-manifest.json',manifest)
for row in sources+controls:
    assert pin(row['path'])=={k:row[k] for k in ('path','bytes','sha256')}
print(json.dumps({'runner':runner_pin,'manifest':manifest_pin,'correspondence':correspondence,
                  'source_fingerprint':source_key,'controls':len(controls),
                  'snapshots_including_manifest':len(sources)+len(controls)+1,
                  'run_logical_replacements':len(replacements),'run_actual_edits':run_overlay['edit_count'],
                  'run_unchanged_complements':run_overlay['unchanged_complement_count'],
                  'complete_runner_actual_edits':runner_overlay['edit_count'],
                  'literal_sections':len(literal_sections)},indent=2))
