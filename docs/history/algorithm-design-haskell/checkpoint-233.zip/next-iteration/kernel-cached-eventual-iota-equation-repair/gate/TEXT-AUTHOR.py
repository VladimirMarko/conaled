"""New text-only authoring of successor controls; imports no project code."""
from pathlib import Path

ROOT = Path('/workspace/scratch/618374bfa892/adwh-work')
BASE = ROOT / 'next-iteration/kernel-cached-eventual-iota-proof-repair/gate'
HERE = ROOT / 'next-iteration/kernel-cached-eventual-iota-equation-repair/gate'
HERE.mkdir()
old_metadata = (BASE / 'runner-metadata.py.txt').read_text()

def section(name, following):
    return old_metadata[old_metadata.index('def '+name+'('):old_metadata.index('def '+following+'(')]

prefix = old_metadata[:old_metadata.index('def verify_repair_scope(')]
assert prefix.count("'diagnosed_iota_proof_staging_only'") == 1
prefix = prefix.replace("'diagnosed_iota_proof_staging_only'", "'diagnosed_pointwise_except_equation_proof_only'")

scope = '''def verify_repair_scope(manifest, recovery, h):
    row = manifest['new_separate_review_scopes'][0]
    require(row == REPAIR_SCOPE and row['author_input_count'] == 1375
            and row['review_input_count'] == 1378 and row['original_scope_or_selection_rebased'] is False,
            'Exact separate independent1378-input equation repair scope')
    for key in ('author_inventory', 'source_audit', 'source_review'):
        identity(row[key], h)
    author_path = local_path(row['author_inventory']['path'])
    audit_path = local_path(row['source_audit']['path'])
    author, audit = read(author_path), read(audit_path)
    require(row['author_inputs'] == array_reference(author_path, 'inputs', h)
            and row['review_inputs'] == array_reference(audit_path, 'inputs', h)
            and author['input_count'] == len(author['inputs']) == 1375
            and audit['author_input_count_verified'] == 1375
            and audit['direct_input_count'] == len(audit['inputs']) == 1378
            and audit['author_inventory'] == row['author_inventory']
            and audit['source_review'] == row['source_review']
            and audit['checks'] == REPAIR_REVIEW_FACTS
            and audit['status'] == row['audit_status'] == 'passed_independent_diagnosed_source_review_uncompiled'
            and audit['reviewer'] == row['reviewer'] == '/root/reflection_evidence_review'
            and audit['source_scope']['new_known_semantic_or_source_interface_blocker'] is False
            and audit['historical_statuses_inputs_source_choices_or_consumed_controls_rebased'] is False
            and audit['source_or_author_metadata_modified_by_reviewer'] is False
            and audit['gate_preflight_Lean_compiler_native_generator_evaluator_or_saved_reader_executed'] is False
            and audit['new_source_scope_compile_or_resource_fit_claim'] is False,
            'The independent equation review is source review, not fresh acceptance')
    candidate = {k: manifest['sources'][2][k] for k in ('path', 'bytes', 'sha256')}
    require(author['logical_source'] == audit['logical_source'] == CURRENT_LOGICAL
            and author['physical_source'] == audit['source'] == audit['candidate'] == candidate
            and author['selected_physical_sources'] == audit['selected_physical_sources']
            == [{k: r[k] for k in ('path', 'bytes', 'sha256')} for r in manifest['sources']]
            and author['source_bytes'] == audit['source_bytes'] == 621077
            and author['report_count'] == audit['ordered_report_count'] == audit['distinct_report_count'] == 185
            and author['ordered_reports'] == audit['ordered_reports']
            == [name for module in MODULES for name in REQUIRED[module]]
            and author['physical_owner_count'] == audit['physical_owner_count'] == 3
            and author['ordinary_output_count'] == audit['ordinary_output_count'] == 6
            and author['one_logical_and_one_physical_proof_span_only'] is True
            and author['all_public_headers_premises_runtime_definitions_guards_states_budgets_and_roots_unchanged'] is True
            and author['namespace_import_private_global_option_and_simp_environment_unchanged'] is True
            and author['historical_scopes_rebased'] is False
            and author['consumed_source_key'] == CONSUMED_SOURCE_KEY,
            'Current selection matches the separately reviewed pointwise equation overlay')
    for author_key, audit_key in (
            ('logical_correction_map', 'correction_map'), ('physical_assembly_lineage', 'assembly_lineage'),
            ('diagnostic_map', 'diagnostic_map'), ('primary_source_context', 'primary_context'),
            ('historical_review_scopes', 'historical_scopes'), ('prospective_source_census', 'prospective_census')):
        require(author[author_key] == audit[audit_key], 'Exact author/reviewer map identity')
        identity(author[author_key], h)
    prior_author = read(PREDECESSOR.parent / 'SOURCE-INVENTORY.json')
    require(author['previous_author_input_count'] == len(prior_author['inputs']) == 1342
            and author['previous_author_input_array_preserved_exactly'] == prior_author['inputs']
            and audit['previous_author_1342_input_array_preserved_literal'] is True
            and audit['prior_39_control_review_scopes_preserved_separately'] is True,
            'The prior1342 input array and39 review scopes are preserved without rebasing')
    for key in ('independent_static_checker', 'independent_static_result'):
        identity(audit[key], h)
    for item in author['inputs'] + audit['inputs']:
        review_identity(item, recovery, h)
    return author, audit, author['inputs'] + audit['inputs']


'''

assembly_old = section('verify_repaired_assembly', 'verify_repair_context')
assembly_tail = assembly_old[assembly_old.index("    output = bytearray(lineage['header_literal'].encode())"):]
assembly_tail = assembly_tail.replace(
    "'prior_source_correspondence': relative_binding(PREDECESSOR.parent / 'SOURCE-CORRESPONDENCE.json', h),",
    "'original_assembly_correspondence': lineage['original_assembly_map'],\n"
    "            'prior_source_correspondence': relative_binding(PREDECESSOR.parent / 'ASSEMBLY-LINEAGE.json', h),")
assembly = '''def verify_repaired_assembly(manifest, author, h):
    mapping = read(REPAIR / 'PROOF-CORRECTION.json')
    lineage = read(REPAIR / 'ASSEMBLY-LINEAGE.json')
    previous_lineage = read(PREDECESSOR.parent / 'ASSEMBLY-LINEAGE.json')
    previous_author = read(PREDECESSOR.parent / 'SOURCE-INVENTORY.json')
    identity(lineage['original_assembly_map'], h)
    old_mapping = read(local_path(lineage['original_assembly_map']['path']))
    previous_manifest = read(PREDECESSOR / 'source-manifest.json')
    candidate_pin = {k: manifest['sources'][2][k] for k in ('path', 'bytes', 'sha256')}
    old_candidate_pin = {k: previous_manifest['sources'][2][k] for k in ('path', 'bytes', 'sha256')}
    require(mapping['theorem'] == 'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared'
            and mapping['all_theorem_headers_premises_runtime_definitions_guards_states_bounds_imports_options_and_reports_unchanged'] is True
            and mapping['local_continuations_and_local_run_facts_only'] is True
            and mapping['no_decision_instance_unfolding_or_options_added'] is True
            and mapping['previous_overlay_retained_separately']
                == relative_binding(PREDECESSOR.parent / 'PROOF-CORRECTION.json', h)
            and mapping['consumed_source_key'] == CONSUMED_SOURCE_KEY,
            'Only the diagnosed existing iota proof is restated as exact pointwise equations')
    old_logical, new_logical, logical_edit = verify_overlay(
        mapping['logical'], previous_author['logical_source'], CURRENT_LOGICAL, h)
    old_physical, candidate, physical_edit = verify_overlay(
        mapping['physical'], old_candidate_pin, candidate_pin, h)
    require(logical_edit['before'] == physical_edit['before']
            and logical_edit['after'] == physical_edit['after'], 'Logical and physical proof replacements are literal')
    def theorem_header(data):
        begin = data.index(b'theorem iota_plain_of_prepared ')
        end = data.index(b' := by\\n', begin) + len(b' := by\\n')
        return data[begin:end]
    require(theorem_header(old_logical) == theorem_header(new_logical)
            == theorem_header(old_physical) == theorem_header(candidate),
            'Complete existing theorem statement remains literal in all four owners')
    require(lineage['original_assembly_map'] == previous_lineage['original_assembly_map']
            and lineage['original_assembly_map']
                == relative_binding(PREVIOUS.PREDECESSOR.parent / 'SOURCE-CORRESPONDENCE.json', h)
            and lineage['original_assembly_scope_preserved_without_rebase'] is True
            and lineage['original_physical_source'] == old_mapping['candidate']
            and lineage['candidate'] == candidate_pin
            and lineage['proof_overlay'] == author['logical_correction_map']
            and lineage['previous_assembly_map']
                == relative_binding(PREDECESSOR.parent / 'ASSEMBLY-LINEAGE.json', h)
            and lineage['previous_selected_physical_source'] == old_candidate_pin
            and lineage['direct_physical_input_count'] == len(lineage['origins']) == 5
            and lineage['unchanged_logical_inputs'] == 4 and lineage['changed_logical_inputs'] == 1
            and lineage['internalized_import_count'] == 8
            and lineage['unchanged_complement_count_including_empty_spans'] == 13
            and lineage['new_boundary_comment_count_from_original_assembly'] == 10
            and lineage['new_initial_comment_count_from_original_assembly'] == 1
            and lineage['namespace_private_global_simp_option_and_import_environment_changed'] is False
            and lineage['local_fact_added_within_existing_proof_only'] is True
            and lineage['local_continuations_and_run_facts_added_within_existing_proof_only'] is True
            and lineage['complete_new_five_origin_forward_and_inverse_verified'] is True
            and lineage['candidate_equals_single_physical_proof_overlay'] is True,
            'Original1305/1306 assembly and first1342/1343 repair remain separate exact scopes')
''' + assembly_tail

context = '''def verify_repair_context(author, manifest, recovery, h):
    context = read(REPAIR / 'PRIMARY-SOURCE-CONTEXT.json')
    previous_context = read(PREDECESSOR.parent / 'PRIMARY-SOURCE-CONTEXT.json')
    require(context['previous_context']
                == relative_binding(PREDECESSOR.parent / 'PRIMARY-SOURCE-CONTEXT.json', h)
            and context['previous_intervals_preserved_exactly'] == previous_context['intervals']
            and context['previous_interval_count'] == len(context['previous_intervals_preserved_exactly']) == 23
            and context['new_interval_count'] == len(context['new_intervals']) == 5
            and context['total_interval_count'] == 28
            and len(context['SDK_full_copies']) == 7
            and context['SDK_full_copies'][:6] == previous_context['SDK_full_copies']
            and context['SDK_source_or_intervals_are_compiled_inputs'] is False
            and context['tactic_options_resource_options_or_linter_settings_changed'] is False,
            'Exact inherited23 plus5 new primary intervals and seven SDK copies')
    for row in context['SDK_full_copies']:
        identity(row['copy'], h)
        require(row['complete_copy_matches_pinned_SDK'] is True, 'Frozen reviewed complete SDK-copy identity')
    intervals = context['previous_intervals_preserved_exactly'] + context['new_intervals']
    for row in intervals:
        identity(row['source'], h)
        require(verify_span(local_path(row['source']['path']).read_bytes(), row['span'])
                    == row['literal_text'].encode(), 'Exact current primary interval')
    # Recheck the six ordinary/native byte correspondences from the independent
    # source review. These retained native sources are evidence, not imports.
    pairs = REPAIR_REVIEW_FACTS['exact_native_current_interval_pairs']
    require(len(pairs) == 6 and REPAIR_REVIEW_FACTS['native_complete_copy_pairs_verified'] == 3,
            'Six exact current/native intervals and three reviewed complete native source copies')
    native_sources = set()
    for pair in pairs:
        identity(pair['current_source'], h); identity(pair['retained_native_source'], h)
        current = local_path(pair['current_source']['path']).read_bytes()
        native = local_path(pair['retained_native_source']['path']).read_bytes()
        piece = verify_span(current, pair['current_span'])
        begin, end = pair['native_start_byte'], pair['native_end_byte_exclusive']
        require(0 <= begin <= end <= len(native) and piece == native[begin:end]
                and hashlib.sha256(piece).hexdigest() == pair['sha256']
                and native.count(piece) == 1, 'Exact retained native operational body interval')
        matching = [row for row in intervals if row['label'] == pair['label']]
        require(len(matching) == 1 and matching[0]['source'] == pair['current_source']
                and matching[0]['span'] == pair['current_span'], 'Native pair names the pinned current interval')
        native_sources.add(pair['retained_native_source']['path'])
    require(len(native_sources) == 3, 'Three complete native originals are bound separately')
    diagnostics = read(REPAIR / 'CAPTURED-DIAGNOSTICS.json')
    require(diagnostics['complete_captured_error_headers'] == len(diagnostics['diagnostics']) == 1
            and diagnostics['unused_simp_argument_headers'] == 0
            and diagnostics['all_captured_errors_in_one_existing_proof_scope'] is True
            and diagnostics['consumed_source_key'] == CONSUMED_SOURCE_KEY
            and diagnostics['raw_stdout_report_headers_observed'] == 177
            and diagnostics['report_was_executed_or_parsed_by_author'] is False
            and diagnostics['captured_recovery_axiom_output_is_not_source_admission_or_acceptance'] is True,
            'The single actual pointwise rewrite failure stays rejected')
    for key in ('raw_stdout', 'report_identity_only', 'root_execution_receipt', 'root_result_note',
                'actual_snapshot_recovery', 'consumed_marker'):
        identity(diagnostics[key], h)
    require(diagnostics['consumed_marker'] == relative_binding(PREDECESSOR / 'execution-markers'
                / ('complete-' + CONSUMED_SOURCE_KEY + '.json'), h), 'Exact latest consumed permanent marker')
    log = local_path(diagnostics['raw_stdout']['path']).read_bytes()
    error_heads = list(re.finditer(rb'^KernelCachedEventualInterpreter\\.lean:(\\d+):(\\d+): error: ([^\\n]*)', log, re.M))
    require(len(error_heads) == 1 and len(log.splitlines()) == diagnostics['raw_stdout_line_count'] == 696
            and log.endswith(b'\\n') is diagnostics['raw_stdout_ends_in_newline']
            and len(re.findall(rb"^'[^']+' depends on axioms:", log, re.M)) == 177,
            'Complete captured stdout, one diagnostic and177 observed failed-owner reports')
    prior_lineage = read(PREDECESSOR.parent / 'ASSEMBLY-LINEAGE.json')
    old_physical = local_path(prior_lineage['candidate']['path']).read_bytes()
    old_logical = local_path(prior_lineage['origins'][1]['source']['path']).read_bytes()
    offset = old_physical[:prior_lineage['origins'][1]['body']['physical_start_byte']].count(b'\\n')
    row, head = diagnostics['diagnostics'][0], error_heads[0]
    piece = verify_span(log, row['log_span'])
    require(row['id'] == '001' and row['log_span']['start_byte'] == head.start()
            and piece == row['captured_text'].encode() and len(piece) == 8937
            and row['physical_line'] == int(head[1]) == 3095 and row['column'] == int(head[2]) == 6
            and row['logical_line'] == row['physical_line'] - offset == 622
            and row['source_line'].encode() == old_logical.splitlines()[row['logical_line']-1]
            == old_physical.splitlines()[row['physical_line']-1]
            and row['kind'] == 'pointwise_rewrite_after_partial_bool_decision_unfolding'
            and row['theorem'] == 'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared',
            'Exact latest physical/logical error correspondence')
    history = read(REPAIR / 'HISTORICAL-REVIEW-SCOPES.json')
    previous_manifest = read(PREDECESSOR / 'source-manifest.json')
    require(history['previous_scope_ledger']
                == relative_binding(PREDECESSOR.parent / 'HISTORICAL-REVIEW-SCOPES.json', h)
            and history['previous_ledger_literal'] == read(PREDECESSOR.parent / 'HISTORICAL-REVIEW-SCOPES.json')
            and history['previous_consumed_manifest'] == relative_binding(PREDECESSOR / 'source-manifest.json', h)
            and history['prior_total_separate_control_review_scope_count'] == 39
            and history['previous_added_separate_control_scope_literal'] == previous_manifest['new_separate_review_scopes']
            and history['original_arrays_statuses_and_source_selections_rebased'] is False
            and history['new_scope_is_one_diagnosed_overlay_over_separate_prior_scopes'] is True
            and history['no_new_global_scope_or_instance_or_simp_environment'] is True,
            'All original39 review scopes retain their exact statuses and selections')
    prior = history['prior_iota_repair']; previous_scope = previous_manifest['new_separate_review_scopes'][0]
    require(prior['inventory'] == previous_scope['author_inventory']
            and prior['audit'] == previous_scope['source_audit']
            and prior['review'] == previous_scope['source_review']
            and prior['author_count'] == previous_scope['author_input_count'] == 1342
            and prior['review_count'] == previous_scope['review_input_count'] == 1343,
            'Literal preceding1342/1343 repair scope')
    census = read(REPAIR / 'PROSPECTIVE-SOURCE-CENSUS.json')
    require(census['selected_physical_sources'] == author['selected_physical_sources']
            and census['source_bytes'] == 621077 and census['physical_owner_count'] == 3
            and census['ordered_report_counts'] == [2, 6, 177]
            and census['ordered_report_count'] == census['distinct_report_count'] == 185
            and census['ordered_reports'] == [n for module in MODULES for n in REQUIRED[module]]
            and census['ordinary_output_count'] == 6 and census['Core_and_Cached_unchanged'] is True
            and census['only_one_of_177_proof_bodies_changed'] is True
            and census['complete_new_closure_compiled_or_budget_fit_claimed'] is False,
            'Exact complete equation-repaired185 source/root census')
    for actual, selected in zip(census['physical_modules'], manifest['sources']):
        require(actual['module'] == selected['module'] and actual['source'] == {k: selected[k] for k in ('path', 'bytes', 'sha256')}
                and actual['imports'] == selected['imports'] and actual['ordered_reports'] == selected['fully_qualified_roots'],
                'Current module rows match the separately reviewed source identities')


'''

preflight = old_metadata[old_metadata.index('def preflight('):]
preflight = preflight.replace('consumed185 validator retains all38', 'consumed185 validator retains all39')
preflight = preflight.replace('618509', '621077')
preflight = preflight.replace("== 39", "== 40")
preflight = preflight.replace("== 38", "== 39")
preflight = preflight.replace('All38 original source scopes plus the separate1342/1343 repair review',
                              'All39 original source scopes plus the separate1375/1378 equation review')
preflight = preflight.replace('corrected three-owner185', 'equation-repaired three-owner185')
(HERE / 'runner-metadata.py.txt').write_text(prefix + scope + assembly + context + preflight)

main = '''def main():
    global PREVIOUS, HISTORICAL
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True, help='Pinned Lean4.35.0 bin/lean; relocation permitted')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt), 'Invalid attempt name')
    # Bind every current source/control and exact metadata identity before any
    # historical module import. JSON is read only as metadata here.
    manifest_before_import = read(MANIFEST)
    require(manifest_before_import['format'] == MANIFEST_FORMAT
            and manifest_before_import['policy'] == POLICY, 'Current pre-import manifest format/policy')
    for row in manifest_before_import['sources'] + manifest_before_import['controls']:
        path = local_path(row['path'])
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Current source/control differs before import: ' + row['path'])
    for path, expected in NEW_FIXED.items():
        actual = local_path(path)
        require(sha(actual) == expected, 'Pinned current metadata differs before import: ' + path)
    for row in SOURCE_PINS + [PREVIOUS_RUNNER_PIN, PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Exact current/predecessor source before import')
    spec = importlib.util.spec_from_file_location('iota_equation_historical_repair185', PREDECESSOR / 'run_gate.py')
    PREVIOUS = importlib.util.module_from_spec(spec); spec.loader.exec_module(PREVIOUS)
    for row in [PREVIOUS.PREVIOUS_RUNNER_PIN, PREVIOUS.PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable first185 controls before import')
    spec = importlib.util.spec_from_file_location('iota_equation_historical_interpreter185', PREVIOUS.PREDECESSOR / 'run_gate.py')
    interpreter = importlib.util.module_from_spec(spec); spec.loader.exec_module(interpreter)
    for row in [interpreter.PREVIOUS_RUNNER_PIN, interpreter.PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable134 controls before import')
    spec = importlib.util.spec_from_file_location('iota_equation_historical_foundation134', interpreter.PREDECESSOR / 'run_gate.py')
    foundation = importlib.util.module_from_spec(spec); spec.loader.exec_module(foundation)
    for row in [foundation.PREVIOUS_RUNNER_PIN, foundation.PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable41 controls before import')
    spec = importlib.util.spec_from_file_location('iota_equation_historical_pilot41', foundation.PREDECESSOR / 'run_gate.py')
    pilot = importlib.util.module_from_spec(spec); spec.loader.exec_module(pilot)
    for row in [pilot.HISTORICAL_RUNNER_PIN, pilot.HISTORICAL_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable111 controls before import')
    spec = importlib.util.spec_from_file_location('iota_equation_historical_interface111', pilot.HISTORICAL_RUNNER)
    HISTORICAL = importlib.util.module_from_spec(spec); spec.loader.exec_module(HISTORICAL)
    # Initialize only dependency handles each unchanged historical main sets.
    # No old manifest, selection, policy, source or review table is rewritten.
    pilot.HISTORICAL = HISTORICAL
    foundation.PREVIOUS = pilot
    foundation.HISTORICAL = HISTORICAL
    interpreter.PREVIOUS = foundation
    interpreter.HISTORICAL = HISTORICAL
    PREVIOUS.PREVIOUS = interpreter
    PREVIOUS.HISTORICAL = HISTORICAL
    require(PREVIOUS.POLICY == interpreter.POLICY == foundation.POLICY == pilot.POLICY == HISTORICAL.POLICY == POLICY
            and PREVIOUS.ALLOWED == interpreter.ALLOWED == foundation.ALLOWED == pilot.ALLOWED == HISTORICAL.ALLOWED == ALLOWED,
            'Unchanged complete resource and axiom policy')
    fixed = {}
    for group in [HISTORICAL.FIXED, pilot.NEW_FIXED,
                  {ROOT / p: value for p, value in foundation.NEW_FIXED.items()},
                  {ROOT / p: value for p, value in interpreter.NEW_FIXED.items()},
                  {ROOT / p: value for p, value in PREVIOUS.NEW_FIXED.items()},
                  {ROOT / p: value for p, value in NEW_FIXED.items()}]:
        for path, expected in group.items():
            require(path not in fixed or fixed[path] == expected,
                    'Conflicting historical/current fixed identity: ' + str(path))
            fixed[path] = expected
    for path, expected in fixed.items():
        require(path.is_file() and not path.is_symlink() and sha(path) == expected,
                'Pinned helper/control differs before loading: ' + str(path))
    h = HISTORICAL.load(HISTORICAL.HELPER, 'cached_forward_resource_helper')
    guard = HISTORICAL.load(HISTORICAL.GUARD, 'cached_forward_source_guard')
    require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Resource/axiom helper contract')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
            'physical_module_count': 3, 'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,
            'distinct_logical_origin_count': 28, 'source_segment_count': 30,
            'required_axiom_report_count': 185, 'required_unique_axiom_name_count': 185,
            'expected_artifact_count': 6, 'prepared_objects': 0, 'source_fingerprint': plan['source_fingerprint'],
            'snapshot_count': len(plan['sources']) + len(plan['controls']),
            'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with HISTORICAL.LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
'''
(HERE / 'runner-main.py.txt').write_text(main)

protocol = '''# Complete fresh equation-repaired interpreter185 protocol

## Scope

Only root may review, preflight and execute these controls. Authoring this directory does not execute or import any gate, compiler, helper, generator or mathematical program. The selected sources are the unchanged reduced ordinary Core (2 reports), unchanged complete Cached owner (6 reports), and the separately reviewed equation-corrected Interpreter (177 reports). All three owners are built afresh, yielding 185 distinct reports and exactly six default `.olean` / `.ilean` outputs from 621,077 source bytes.

This selection tests the complete non-atomic trace interpreter and bounded query interface together with the accepted foundation source. It does not select FN construction, Typing, Driver, record guards, installed guards or native Installed. A successful result would not discharge a concrete complete query, annotated ProgramPins, original GroupChecked, or the stock numeral theorem.

## Exact source lineage

The consumed first185 assembly has its own1305/1306 source scope. The next consumed iota-proof repair preserves one logical/physical overlay and its1342/1343 scope. This successor adds the separately reviewed1375/1378 equation scope; it never rewrites earlier arrays, selections, statuses or diagnoses. The immutable preceding39-scope validator is called only for metadata. Its `main` and `run` are never invoked. The current total is40 separate source-review scopes.

Current metadata verifies both one-span equation overlays in both directions, all unchanged complements and headers, and reconstructs every byte of the five-input physical owner from the selected sources with the original eight import-comment edits, thirteen complements and unchanged boundary text. The original assembly, preceding overlay and current overlay remain separately bound. All three current source identities,177 proof reports and the complete185 root sequence are exact.

The primary-context check preserves the original23 intervals and adds five, retaining seven complete SDK copies. Six exact ordinary/native operational body intervals and their three retained native source copies are checked separately as evidence. They are not compiled imports and do not imply native installation compatibility. The latest raw diagnostic, receipt, report, marker and recovery identities remain bound; the previous failed owner is still rejected.

## Bootstrap and input integrity

Every current source, manifest-listed control and fixed metadata identity is checked before importing any retained validator or helper. The explicit immutable chain is equation185 → diagnosed185 → original185 → Foundation134 → Eventual41 → interface111. Only the dependency handles that each historical `main` ordinarily initializes are connected. All old policy, selection, manifest and review globals remain unchanged. The eight exact external-context recovery tuples remain literal; no path search or arbitrary fallback is allowed.

The current snapshot union includes every previous source/control plus all1375 author inputs and1378 independent review inputs, deduplicating only identical path/size/hash identities. The selected sources and controls, compiler and runtime are checked before compilation; immutable snapshots are compared again after the run. An independent root control review and metadata-only preflight must precede the sole mathematical attempt.

## Fixed execution policy

The complete fresh computation receives one cumulative30-second deadline, one CPU, one compiler thread, and one GiB memory. Heartbeat, recursion and compiler resource defaults are unchanged. Compiler arguments remain `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`, with ordinary `.olean` and `.ilean` outputs. No native executable, exporter, proof cache or prepared experimental object is imported or run. Only the pinned SDK/runtime search path and fresh build directory are admitted.

The consumed source key `e83b4b93eed3f30889ab452f532fbf6799b75969f42def71f8f711e9087b653d` is preserved permanently. The new key uses the unchanged `cached-forward-runs-and-licensed` stage and policy with the new exact source hashes. All older no-retry marker directories remain checked and the consumed diagnosed185 directory is appended. Existing attempts, the current marker, or any historical marker for this exact source key forbid execution.

The actual compiler invocation, cumulative timer, process-tree watchdog, CPU affinity, clean environment, memory enforcement, snapshot/post-run integrity, output inventory, strict diagnostic audit and final pass predicate are literal to the consumed predecessor. The mapped `run` changes only the newly appended predecessor directory, its explanatory comment and two review-count fields. A full forward/inverse map covers the complete runner as well as the run block.

## Acceptance and limits

Every physical owner is accepted only as a whole: zero compiler exit, within the cumulative limits, exactly the required reports, no unrecognized diagnostic or recovery admission, permitted axioms only (`propext`, `Classical.choice`, `Quot.sound`), and both required outputs. All185 reports, six exact artifacts, unchanged inputs/runtime/snapshots, complete module order, total elapsed≤30 seconds and peak resident memory≤1048576 KiB are required for a complete pass. Partial or recovered report output is never acceptance.

The preceding attempt failed after25.563569123994967 seconds with8 accepted and185 observed reports. The new proof is independently source-reviewed; it has not been compiled or timed. The proof repair supplies no evidence of a cost improvement or complete resource fit. Any diagnostic or resource failure consumes the new key and requires a genuine separately reviewed source change before another attempt.
'''
(HERE / 'PROTOCOL.md').write_text(protocol)
(HERE / 'AUTHORING.md').write_text('''# Source-only control authoring

These controls select the frozen explicit-equation iota repair over the consumed diagnosed185 gate. The source package and its independent1378-input review are immutable. The previous39 scopes are retained recursively under their exact manifests; the current review is a separate40th scope.

The author only reads text/JSON, hashes exact files, assembles new Python source and writes metadata. No retained Python module, gate, helper, preflight, compiler, mathematical program, exporter, profiler or saved-evidence reader is imported or executed. The new authoring script is ordinary literal-bookkeeping code, not a validator execution. Root must independently inspect the controls before any preflight or mathematical attempt.

The new source/root census is three physical owners,621077 source bytes,185 distinct reports and six default outputs. Core and Cached stay literal; only the Interpreter path and its OperationalContracts origin row change. All native runtime branches and actual returned-state sequencing remain in their original sources.

Exact control correspondence records the complete runner and run-block forward/inverse maps. The cumulative timer, compiler command, watchdog, environment, CPU/memory enforcement, strict axiom audit, snapshot/post-run checks and complete pass predicate stay literal. The small run-block changes append the latest consumed predecessor directory and update review-count bookkeeping. The permanent stage and resource policy are unchanged.

The protocol and metadata preserve the known failed diagnostic rather than crediting recovered reports. No new compilation, acceptance, endpoint or timing claim is made.
''')
print('Wrote held control metadata/bootstrap/protocol text only; no imports or execution.')
