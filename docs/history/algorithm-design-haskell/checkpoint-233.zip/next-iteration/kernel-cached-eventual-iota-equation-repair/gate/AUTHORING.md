# Source-only control authoring

These controls select the frozen explicit-equation iota repair over the consumed diagnosed185 gate. The source package and its independent1378-input review are immutable. The previous39 scopes are retained recursively under their exact manifests; the current review is a separate40th scope.

The author only reads text/JSON, hashes exact files, assembles new Python source and writes metadata. No retained Python module, gate, helper, preflight, compiler, mathematical program, exporter, profiler or saved-evidence reader is imported or executed. The new authoring script is ordinary literal-bookkeeping code, not a validator execution. Root must independently inspect the controls before any preflight or mathematical attempt.

The new source/root census is three physical owners,621077 source bytes,185 distinct reports and six default outputs. Core and Cached stay literal; only the Interpreter path and its OperationalContracts origin row change. All native runtime branches and actual returned-state sequencing remain in their original sources.

Exact control correspondence records the complete runner and run-block forward/inverse maps. The cumulative timer, compiler command, watchdog, environment, CPU/memory enforcement, strict axiom audit, snapshot/post-run checks and complete pass predicate stay literal. The small run-block changes append the latest consumed predecessor directory and update review-count bookkeeping. The permanent stage and resource policy are unchanged.

The protocol and metadata preserve the known failed diagnostic rather than crediting recovered reports. No new compilation, acceptance, endpoint or timing claim is made.
