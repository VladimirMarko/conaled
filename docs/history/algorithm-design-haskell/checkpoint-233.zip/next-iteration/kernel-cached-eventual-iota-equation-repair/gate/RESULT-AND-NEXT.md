# Actual equation-repaired interpreter185 result

**FAILED; this exact mathematical source key is consumed.** Root performed the sole complete fresh attempt after independent source/control review and metadata-only preflight. All three selected owners were rebuilt without prepared experimental objects.

The source key is `43f7b74d12a8033903f3f95006980b0ad7f92f757812bffab1917cd2e872c035`. The actual report is 1067195 bytes, SHA-256 `fe09ca2275ec960a331b99c202004c3c64dcb2202889b85dfebf75310b7a0710`. Elapsed time was27.428755360997457 seconds, peak878672KiB. Core2 and Cached6 passed. The Interpreter emitted177 reports but failed, so all177 were rejected; the total is eight accepted and185 observed.

The three errors occur at physical lines3097,3121 and3137 of the actual frozen Interpreter. The first two `change` steps attempt to replace a monadic conditional continuation by an `Except.bind` continuation with the state application distributed into the branches. Lean rejects definitional equality. The final `change` additionally has not explicitly discharged the actual preceding level/parameter checks and verified certificate wrapper. The raw diagnostic retains those operations and their exact state sequencing.

The actual selected source contains no admission. Any error-recovery `sorryAx` appearing in printed failed-owner reports is rejected. Neither the earlier independent source review nor the valid elapsed/RSS measurements transfer acceptance to this failed owner.

Root compared every1453 snapshot/canonical pair byte-for-byte and preserved all six raw logs, the permanent read-only marker, report, independent reviews and receipt. `SNAPSHOT-RECOVERY.json` provides the portable canonical mapping; it is a durability mapping, not a replayed proof checker. No dedicated saved-result evaluator was run.

The next source candidate must preserve the real `StateT` continuation placement and discharge the actual preliminary helper checks before claiming the final equation. A promising proof repair is to reduce each known successful monadic run before distributing or eliminating its Boolean conditional, or to keep the conditional over the action and apply the resulting action to the returned state. That is a diagnosis and proposed repair, not a proof or compilation result. The actual runtime branches, guards, state order and theorem premises must remain unchanged.

No unchanged retry, control rename or prepared-object continuation is permitted. Any new candidate needs a genuine source edit, an explicit inverse correspondence, independent source/control reviews and a new complete fresh attempt under the same cumulative30-second/oneCPU/oneGiB/default-resource/three-axiom policy. Complete query, Installed/GroupChecked and the stock `cqueens 16 = 14772512` theorem remain open.
