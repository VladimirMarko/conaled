"""Independent root byte/AST review. Does not import any gate or helper."""
from pathlib import Path
import ast
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def sha(b): return hashlib.sha256(b).hexdigest()
def strict(pairs):
    d = {}
    for k, v in pairs:
        assert k not in d
        d[k] = v
    return d
def read(p): return json.loads(p.read_text(), object_pairs_hook=strict)
def check(r):
    p = ROOT / r['path']
    assert p.is_file() and not p.is_symlink(), str(p)
    b = p.read_bytes()
    assert (len(b), sha(b)) == (r['bytes'], r['sha256']), str(p)
    return b
def canonical(v): return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def literals(s):
    d = {}
    for n in ast.parse(s).body:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    try: d[t.id] = ast.literal_eval(n.value)
                    except (ValueError, TypeError): pass
    return d
def functions(s): return {n.name: n for n in ast.parse(s).body if isinstance(n, ast.FunctionDef)}
def function(s, name):
    n = functions(s)[name]
    return (''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno]).rstrip() + '\n\n').encode()
def span(b, r):
    a, z = r['start_byte'], r['end_byte_exclusive']
    assert 0 <= a <= z <= len(b)
    v = b[a:z]
    assert (len(v), sha(v)) == (r['bytes'], r['sha256'])
    return v

c = read(HERE / 'CONTROL-CORRESPONDENCE.json')
m = read(HERE / 'source-manifest.json')
old = check(c['baseline_runner']); new = check(c['candidate_runner'])
for k in ('baseline_manifest', 'baseline_control_review', 'baseline_control_audit'): check(c[k])
oldtext, newtext = old.decode(), new.decode()
oldrun = span(old, c['run_block_original_file_span'])
newrun = span(new, c['run_block_candidate_file_span'])
assert oldrun == function(oldtext, 'run') + b'\n' and newrun == function(newtext, 'run') + b'\n'
rebuilt = oldrun.decode()
assert len(c['run_block_logical_replacements']) == c['run_block_exact_logical_replacement_count'] == 4
for r in c['run_block_logical_replacements']:
    assert rebuilt.count(r['before']) == 1, r
    rebuilt = rebuilt.replace(r['before'], r['after'])
assert rebuilt.encode() == newrun
def overlay(a, b, m):
    assert (len(a),sha(a)) == (m['original_bytes'],m['original_sha256'])
    assert (len(b),sha(b)) == (m['candidate_bytes'],m['candidate_sha256'])
    edits, gaps = m['edits'], m['unchanged_complements']
    assert len(edits) == m['edit_count'] and len(gaps) == m['unchanged_complement_count']
    forward, inverse = a, b
    for e in reversed(edits):
        x,z = e['original']['start_byte'],e['original']['end_byte_exclusive']
        y,w = e['candidate']['start_byte'],e['candidate']['end_byte_exclusive']
        assert span(a,e['original']) == e['before'].encode()
        assert span(b,e['candidate']) == e['after'].encode()
        forward = forward[:x] + e['after'].encode() + forward[z:]
        inverse = inverse[:y] + e['before'].encode() + inverse[w:]
    assert forward == b and inverse == a
    for g in gaps:
        assert span(a,g['original']) == span(b,g['candidate'])
    # SequenceMatcher retains nonempty equal blocks; a changed first/last block
    # need not have an empty complement in these five full-file maps.
    for side,data in [('original',a),('candidate',b)]:
        parts = sorted([r[side] for r in edits+gaps], key=lambda r:(r['start_byte'],r['end_byte_exclusive']))
        cursor = 0
        for part in parts:
            assert part['start_byte'] == cursor
            cursor = part['end_byte_exclusive']
        assert cursor == len(data)
    return len(edits),len(gaps)
assert overlay(old,new,c['complete_runner_overlay']) == (65,66)
assert overlay(oldrun,newrun,c['run_block_overlay']) == (4,5)
assert len(c['complete_control_file_overlays']) == 5
for item in c['complete_control_file_overlays']:
    overlay(check(item['original']),check(item['candidate']),item['complete_overlay'])
assert len(c['literal_execution_sections']) == 6
for r in c['literal_execution_sections']:
    assert span(old, r['original_file_span']) == span(new, r['candidate_file_span'])
literal_names = ['require', 'sha', 'strict_object', 'read', 'local_path', 'pin_tuple', 'identity', 'relative_binding', 'canonical', 'array_reference', 'verify', 'fingerprint', 'audit_logs']
for name in literal_names:
    assert function(oldtext, name) == function(newtext, name), name
    assert ast.dump(functions(oldtext)[name], include_attributes=False) == ast.dump(functions(newtext)[name], include_attributes=False)
oldlit, lit = literals(oldtext), literals(newtext)
policy = {'Elab.async': False, 'autoImplicit': False, 'compiler_threads': 1, 'cumulative_wall_seconds': 30, 'default_heartbeats_recursion_and_compiler_options': True, 'lean_memory_mib': 1024, 'resident_memory_kib': 1048576, 'warningAsError': True}
assert lit['POLICY'] == oldlit['POLICY'] == m['policy'] == policy
assert lit['ALLOWED'] == oldlit['ALLOWED'] == {'propext', 'Quot.sound', 'Classical.choice'}
sources, controls = m['sources'], m['controls']
assert lit['MODULES'] == m['module_order'] == [r['module'] for r in sources]
assert len(sources) == 3 and sum(r['bytes'] for r in sources) == 621077
assert [tuple(r[k] for k in ('path', 'bytes', 'sha256')) for r in sources] == lit['SOURCE_PINS']
for r in sources + controls: check(r)
bound = {r['path']: (r['bytes'], r['sha256']) for r in sources + controls}
assert len(bound) == len(sources) + len(controls) == 1452
assert len(controls) == len({r['role'] for r in controls}) == 1449
assert m['snapshot_count_including_manifest'] == 1453
required, raw, imports = lit['REQUIRED'], lit['RAW_REQUIRED'], lit['EXPECTED_IMPORTS']
assert [len(required[n]) for n in lit['MODULES']] == [2, 6, 177]
assert len({n for rows in required.values() for n in rows}) == 185
seen = set()
for r in sources:
    b = check(r); name = r['module']
    assert re.findall(rb'^import (\S+)', b, re.M) == [x.encode() for x in imports[name]]
    assert r['imports'] == imports[name] and all(x in seen or x == 'Init' or x.startswith(('Init.', 'Std.')) for x in imports[name])
    assert re.findall(rb'^#print axioms (\S+)', b, re.M) == [x.encode() for x in raw[name]]
    assert r['raw_source_print_identifiers'] == raw[name] and r['fully_qualified_roots'] == required[name]
    seen.add(name)
key = sha(canonical({'stage': 'cached-forward-runs-and-licensed', 'policy': policy, 'sources': [{'module': r['module'], 'sha256': r['sha256']} for r in sources]}))
assert key == m['source_fingerprint'] == '43f7b74d12a8033903f3f95006980b0ad7f92f757812bffab1917cd2e872c035'
assert len(lit['NEW_FIXED']) == 1450
for p, digest in lit['NEW_FIXED'].items():
    assert p in bound and sha((ROOT / p).read_bytes()) == digest == bound[p][1]
recovery = lit['EXTERNAL_RECOVERY']
assert recovery == m['external_review_context_recovery'] and len(recovery) == 8
routes = {}
for row in recovery:
    assert row['only_exact_original_identity_may_use_this_recovery'] is True
    assert check(row['original_context']) == check(row['retained_copy'])
    a, b = row['original_context'], row['retained_copy']
    routes[tuple(a[k] for k in ('path', 'bytes', 'sha256'))] = b
scopes = [lit['REPAIR_SCOPE']]
assert scopes == m['new_separate_review_scopes'] and len(scopes) == 1
scope_counts = []
for s in scopes:
    for k in ('author_inventory', 'source_audit', 'source_review'): check(s[k])
    pair = []
    for k in ('author_inputs', 'review_inputs'):
        d = s[k]; a = json.loads(check(d['source']))[d['json_field']]; b = canonical(a)
        assert len(a) == d['item_count'] == len({r['path'] for r in a})
        assert (len(b), sha(b)) == (d['canonical_json_bytes'], d['canonical_json_sha256'])
        for r in a:
            resolved = routes.get(tuple(r[k] for k in ('path', 'bytes', 'sha256')), r)
            check(resolved)
            assert bound[resolved['path']] == (resolved['bytes'], resolved['sha256'])
        pair.append(len(a))
    scope_counts.append(pair)
assert scope_counts == [[1375, 1378]]
pm = json.loads(check(c['baseline_manifest']))
for r in pm['sources'] + pm['controls']:
    assert bound[r['path']] == (r['bytes'], r['sha256'])
assert recovery == pm['external_review_context_recovery']
assert m['logical_origins'] == pm['logical_origins'] and len(set(m['logical_origins'])) == 28
assert len(pm['complete_origin_source_rows']) == 28
for i, (current, prior) in enumerate(zip(m['complete_origin_source_rows'], pm['complete_origin_source_rows'])):
    assert current == (lit['CURRENT_LOGICAL'] if i == 24 else prior)
assert len(m['complete_origin_source_rows']) == 28 and m['source_segment_count'] == 30
for r in m['complete_origin_source_rows']: check(r)
assert m['historical_independent_review_scope_count'] == 39 and m['current_total_separate_independent_review_scope_count'] == 40
assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('exec', 'eval', 'compile', '__import__') for n in ast.walk(ast.parse(newtext)))
main = function(newtext, 'main').decode()
assert main.index('for row in manifest_before_import') < main.index('spec = importlib')
assert main.index('for path, expected in NEW_FIXED.items()') < main.index('spec = importlib')
assert main.index('for path, expected in fixed.items()') < main.index('h = HISTORICAL.load')
assert all(value in main for value in ['pilot.HISTORICAL = HISTORICAL', 'foundation.PREVIOUS = pilot', 'foundation.HISTORICAL = HISTORICAL', 'interpreter.PREVIOUS = foundation', 'interpreter.HISTORICAL = HISTORICAL', 'PREVIOUS.PREVIOUS = interpreter', 'PREVIOUS.HISTORICAL = HISTORICAL'])

for name in ('baseline_consumed_report_identity_only', 'baseline_root_execution_receipt', 'baseline_snapshot_recovery'):
    check(c[name])
metadata = check(c['source_of_new_metadata']).decode()
bootstrap = check(c['source_of_new_bootstrap']).decode()
assert metadata in newtext and bootstrap in newtext
assert newtext.endswith(bootstrap)
assert all(function(metadata, name) == function(newtext, name) for name in functions(metadata))
assert function(bootstrap, 'main') == function(newtext, 'main')
assert pm['current_total_separate_independent_review_scope_count'] == 39
assert m['sources'][:2] == pm['sources'][:2]
assert len(m['historical_context']['exact_field_references']) == 5
for field, reference in m['historical_context']['exact_field_references'].items():
    assert reference['source'] == c['baseline_manifest'] and reference['json_field'] == field
    b = canonical(pm[field])
    assert (len(b), sha(b)) == (reference['canonical_json_bytes'], reference['canonical_json_sha256'])
    assert reference['item_count'] == len(pm[field])
assert lit['REPAIR_SCOPE']['source_audit'] == scopes[0]['source_audit']
assert json.loads(check(scopes[0]['source_audit']))['checks'] == lit['REPAIR_REVIEW_FACTS']
assert lit['CONSUMED_SOURCE_KEY'] == pm['source_fingerprint']
assert 'PREVIOUS.PREVIOUS.PREVIOUS.PREDECESSOR' in newrun.decode()
result = {'status': 'passed_independent_static_control_review', 'source_fingerprint': key, 'selected_sources': 3, 'source_bytes': 621077, 'reports': 185, 'expected_artifacts': 6, 'controls': 1449, 'snapshots_including_manifest': 1453, 'literal_common_function_AST_and_bytes': literal_names, 'run_replacement_groups': 4, 'run_byte_edits': 4, 'run_unchanged_complements': 5, 'full_runner_edits': 65, 'full_runner_complements': 66, 'additional_control_inverse_maps': 5, 'literal_execution_sections': 6, 'complete_forward_inverse_and_partitions': True, 'new_review_scope_array_counts': scope_counts, 'previous_scope_count': 39, 'total_scope_count': 40, 'exact_external_routes': 8, 'fixed_current_identities': 1450, 'gate_or_helper_imported': False, 'compiler_or_mathematical_execution': False, 'new_metadata_and_bootstrap_full_text_checked': True, 'all_39_historical_scope_references_literal': True, 'only_origin_index_24_replaced': True}
(HERE / 'INDEPENDENT-CONTROL-CHECK.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
