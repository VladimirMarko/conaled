# Diagnosed eventual iota: explicit staged equations

This is a new source-only proof candidate after the corrected Interpreter185 selection was consumed and failed. That complete root execution took 25.563569123994967 seconds, observed 185 reports and accepted only the two Core and six Cached reports. All 177 reports from the failed combined interpreter owner remain unaccepted. The failure, consumed source, controls, marker, report, receipt and recovery map are preserved unchanged.

## Observed failure

The captured stdout has one error header, at physical line 3095, in `iota_plain_of_prepared`. The prior broad `dsimp` unfolded Boolean conditional machinery into `Bool.rec` and `decide` expressions. It left the typeclass argument of one comparison at the stored rule's `compareParams` expression while the proposition had become `false = true`. The next `rw [recursorTypeRun]` could not expose the pointwise helper call, and its own diagnostic reported that implicit-transparency mismatch. This is an actual elaboration failure, not a newly inferred semantic flaw or a resource timeout.

## Exact correction

The theorem header, all premises, the head/argument/arity/preparation steps and the plain-versus-inert proof stay literal. Only the remaining terminal proof span changes.

The replacement introduces four local continuations inside this existing proof. They spell the original nested certificate block in its actual order:

1. The constructor telescope and then its index certificate.
2. The actual constructor-type helper followed by that continuation.
3. The recursor telescope followed by the constructor block.
4. The actual recursor-type helper followed by the recursor continuation.

Each local run is derived by an explicit pointwise `change Except.bind ...` equation and the existing success premise for its actual returned state. The final goal is changed to the original certificate block followed by the original guarded RHS helper and application construction. It deliberately keeps the certificate block grouped before the RHS continuation, so no reassociation law for unknown monadic results is silently required. `change` must establish definitional equality; it creates no semantic assumption.

No Boolean decision-instance definition, `ite`/`dite` implementation or simplifier resource setting is unfolded or changed by the new span. The closed empty-level comparison, plain parameter-blind switch, verified certificate switch and application plumbing are reduced only as part of establishing the explicit definitional goal. The success rewrites still use the actual recursor-type, recursor-telescope, constructor-type, constructor-telescope, index and RHS facts. False certificate branches and errors remain in the continuation equations. The fallback `all_goals` form tolerates an earlier rewrite already closing a definitionally trivial goal.

## Preserved mathematical and physical boundary

There is one proof-only logical overlay and the corresponding one-span physical overlay. All public theorem statements, metadata/lookup/arity/license premises, executable definitions and branches, states, bounds, imports, options, attributes and 185 report roots remain unchanged. The new local functions and their run facts are inside one theorem proof; they add no public runtime API or global scope.

The physical source is reconstructed from the same five direct logical inputs and eight literal internalized-import comments. Four logical inputs and both actual runtime owners are unchanged. The original boundary comments, namespace/private resolution, global simp environment and source order stay literal. The original assembly and first iota-repair review scopes are retained separately, with their exact original arrays and source selections; none is rebased onto this candidate.

The prospective closure is still three physical owners and 185 reports, now 621,077 source bytes and six ordinary outputs. The new logical and physical alternatives must replace their old canonical owners in any later selection, never accompany them. This package authors no gate and performs no preflight or mathematical execution.

## Evidence and limits

`CAPTURED-DIAGNOSTICS.json` binds the complete captured error span, its logical and physical locations, and the actual consumed report/receipt/recovery identities. The report is bound as bytes only; no saved-result reader is executed. Its recovery `sorryAx` reports are rejected, not source admissions or accepted proofs.

`PROOF-CORRECTION.json` records both exact before/after spans, forward and inverse reconstruction, and the two unchanged complements of each file. `ASSEMBLY-LINEAGE.json` reconstructs every physical byte from the five selected sources. `PRIMARY-SOURCE-CONTEXT.json` retains the previous 23 exact intervals unchanged and adds the explicit new proof/diagnostic/change-tactic context. The old actual failed source and the new source are separately identified throughout.

The candidate awaits independent source review and a separately reviewed sole complete fresh run. The prior timings do not establish budget fit for the candidate, the larger FN query construction, an installed record, original `GroupChecked`, or the stock numeral. No options, limits, proof axioms, algorithms, theorem premises or target values are changed.
