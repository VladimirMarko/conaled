import KernelCachedHelperContract
import KernelCachedLiteralContract

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Canonical operational contracts for eventual cached traces

These literal declaration slices contain actual callback/run equations,
stored-record and metadata guards, and cached syntax constructors. Their
original namespaces are preserved. Pure evaluator backing, Stable invariant
wrappers and old trace/interpreter definitions are outside this selection.
The original physical owners must not be imported alongside this owner.

This restores the seven callback-free licensed equations as a separate
proof layer over the unchanged six-root cached runtime owner. No actual
runtime definition, guard, local budget, state field or operation is edited.
Source candidate only; no compilation or execution is claimed.
-/

/- BEGIN exact operational selection: next-iteration/kernel-cached-forward-proof-corrections/source/CachedForwardLicensed.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedForward

open ConLeche
open ConLeche.Cached

inductive NeverPiPrefix : Nat → Expr → Prop
  | zero (type : Expr) : NeverPiPrefix 0 type
  | succ {length : Nat} {domain body : Expr} (metadata : BinderMeta)
      (never : metadata.pw.isNever = true)
      (tail : NeverPiPrefix length body) :
      NeverPiPrefix (length + 1) (.forallE domain body metadata)


theorem iotaCertsIAux_never (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (type : Expr) (accumulated arguments : List Expr)
    (state : CState) (licensed : NeverPiPrefix arguments.length type) :
    iotaCertsIAux callbacks fe depth true type accumulated arguments state =
      .ok (true, state) := by
  induction arguments generalizing type accumulated with
  | nil =>
    rw [iotaCertsIAux.eq_def]
    all_goals rfl
  | cons argument rest ih =>
    cases licensed with
    | succ metadata never tail =>
      rw [iotaCertsIAux.eq_def]
      simp only [Bool.true_and, never, ↓reduceIte]
      exact ih _ _ tail


theorem iotaCertsI_never (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (type : Expr) (arguments : List Expr) (state : CState)
    (licensed : NeverPiPrefix arguments.length type) :
    iotaCertsI callbacks fe depth true type arguments state =
      .ok (true, state) := by
  exact iotaCertsIAux_never callbacks fe depth type [] arguments state licensed


theorem defEqListI_empty (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (state : CState) :
    defEqListI callbacks fe depth [] [] state = .ok (true, state) := rfl


theorem iotaIndexOkI_noIndices (callbacks : CoreFnsI) (fe : FEnv)
    (depth majorIndex constructorParameters : Nat) (type : Expr)
    (majorArguments indices : List Expr) (state : CState) :
    iotaIndexOkI callbacks fe depth majorIndex majorIndex constructorParameters
      type majorArguments indices state = .ok (true, state) := by
  simp only [iotaIndexOkI, ↓reduceIte]
  all_goals rfl


theorem whnfAppI_never (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (domain body argument : Expr)
    (rest : List Expr) :
    whnfAppI .verified callbacks fe depth next
      (.lam domain body ⟨.never⟩) (argument :: rest) =
    betaPeelI .verified callbacks fe depth next body [argument] rest := by
  rw [whnfAppI.eq_def]
  all_goals rfl


theorem betaPeelI_never (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (domain body argument : Expr)
    (accumulated rest : List Expr) :
    betaPeelI .verified callbacks fe depth next
      (.lam domain body ⟨.never⟩) accumulated (argument :: rest) =
    betaPeelI .verified callbacks fe depth next body
      (argument :: accumulated) rest := by
  rw [betaPeelI.eq_def]
  all_goals rfl


theorem betaPeelI_done (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (body : Expr) (accumulated : List Expr) :
    betaPeelI mode callbacks fe depth next body accumulated [] =
      (instListM body accumulated >>= next) := by
  rw [betaPeelI.eq_def]


#print axioms iotaCertsIAux_never
#print axioms iotaCertsI_never
#print axioms defEqListI_empty
#print axioms iotaIndexOkI_noIndices
#print axioms whnfAppI_never
#print axioms betaPeelI_never
#print axioms betaPeelI_done

end ADWH.Experiments.Chapter15.KernelCachedForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-literal-scope-repair/source/KernelCachedLiteralForward.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedLiteralForward

open ConLeche
open ConLeche.Cached

theorem full_loop_nat_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget n : Nat) (state final : CState)
    (headRun : callbacks.whnfCore false depth (natLiteral n) state =
      .ok (natLiteral n, final)) :
    whnfLoopI callbacks fe depth (budget + 1) (natLiteral n) state =
      .ok (natLiteral n, final) := by
  change whnfStepI callbacks fe depth
    (whnfLoopI callbacks fe depth budget) (natLiteral n) state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind]
  all_goals rfl


#print axioms full_loop_nat_of_head

end ADWH.Experiments.Chapter15.KernelCachedLiteralForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedArithmeticForward.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedArithmeticForward

open ConLeche
open ConLeche.Cached
open KernelCachedLiteralForward

def NatBinaryName (operator : Name) : Prop :=
  operator = natAddName ∨ operator = natSubName ∨ operator = natMulName ∨
  operator = natPowName ∨ operator = natBeqName ∨ operator = natBleName ∨
  operator = natDivName ∨ operator = natModName ∨ operator = natGcdName ∨
  operator = natLandName ∨ operator = natLorName ∨ operator = natXorName ∨
  operator = natShiftLeftName ∨ operator = natShiftRightName


def binaryApplication (operator : Name) (left right : Expr) : Expr :=
  .app (.app (.const operator []) left) right


def NoDefinition (fe : FEnv) (name : Name) : Prop :=
  ∀ (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint),
    fe.find? name ≠ some (.defnInfo constant body hint)


def PrimitiveResult (fe : FEnv) (value : Expr) : Prop :=
  (∃ number, value = natLiteral number) ∨
  ∃ name levels, value = .const name levels ∧ NoDefinition fe name


theorem primitive_result_nat (fe : FEnv) (number : Nat) :
    PrimitiveResult fe (natLiteral number) := Or.inl ⟨number, rfl⟩


theorem primitive_result_const (fe : FEnv) (name : Name) (levels : List Level)
    (notDefinition : NoDefinition fe name) :
    PrimitiveResult fe (.const name levels) :=
  Or.inr ⟨name, levels, rfl, notDefinition⟩


theorem stored_definition (fe : FEnv) (operator : Name)
    (stored : natOpStoredF fe operator = true) :
    ∃ constant body hint, fe.find? operator = some (.defnInfo constant body hint) := by
  cases found : fe.find? operator with
  | none => simp [natOpStoredF, found] at stored
  | some info =>
    cases info <;> simp_all [natOpStoredF]


theorem stored_head_no_iota (fe : FEnv) (operator : Name) (expression : Expr)
    (head : Expr.getAppFn expression = .const operator [])
    (stored : natOpStoredF fe operator = true) :
    iotaArityOk fe expression = false := by
  obtain ⟨constant, body, hint, found⟩ := stored_definition fe operator stored
  unfold iotaArityOk
  rw [head]
  dsimp only []
  rw [found]
  all_goals rfl


theorem reduce_nat_binary (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (operator : Name) (left right : Expr) (leftNumber rightNumber : Nat)
    (value : Expr) (state afterLeft final : CState)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (leftRun : callbacks.whnf depth left state =
      .ok (.lit (.natVal leftNumber), afterLeft))
    (rightRun : callbacks.whnf depth right afterLeft =
      .ok (.lit (.natVal rightNumber), final))
    (computed : natOpResult operator leftNumber rightNumber = some value) :
    reduceNatI callbacks fe depth (binaryApplication operator left right) state =
      .ok (some value, final) := by
  have enabled : NatBinaryName operator ∧ natOpStoredF fe operator = true :=
    ⟨recognized, stored⟩
  unfold NatBinaryName at enabled
  change reduceNatI callbacks fe depth
    (.app (.app (.const operator []) left) right) state = _
  dsimp only [reduceNatI, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.pure, Except.bind]
  rw [ite_eq_left enabled]
  simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind,
    leftRun, rawNatLitC?, rightRun, computed]
  all_goals rfl


private theorem unfold_const_none (fe : FEnv) (name : Name)
    (levels : List Level) (notDefinition : NoDefinition fe name) (state : CState) :
    unfoldDefinitionI fe (.const name levels) state = .ok (none, state) := by
  cases found : fe.find? name with
  | none =>
    simp only [unfoldDefinitionI, Expr.getAppFn, Bind.bind, StateT.bind,
      pure, StateT.pure, Except.pure, Except.bind, found]
    all_goals rfl
  | some info =>
    cases info with
    | defnInfo constant body hint =>
      exact False.elim (notDefinition constant body hint found)
    | _ =>
      simp only [unfoldDefinitionI, Expr.getAppFn, Bind.bind, StateT.bind,
        pure, StateT.pure, Except.pure, Except.bind, found]
      all_goals rfl


theorem full_loop_const_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (name : Name) (levels : List Level)
    (state final : CState) (notDefinition : NoDefinition fe name)
    (headRun : callbacks.whnfCore false depth (.const name levels) state =
      .ok (.const name levels, final)) :
    whnfLoopI callbacks fe depth (budget + 1) (.const name levels) state =
      .ok (.const name levels, final) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget)
    (.const name levels) state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind, reduceNatI,
    pure, StateT.pure, Except.pure, unfold_const_none fe name levels notDefinition final]
  all_goals rfl


theorem full_loop_result_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (value : Expr) (state final : CState)
    (resultForm : PrimitiveResult fe value)
    (headRun : callbacks.whnfCore false depth value state = .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 1) value state = .ok (value, final) := by
  rcases resultForm with ⟨number, rfl⟩ | ⟨name, levels, rfl, notDefinition⟩
  · exact full_loop_nat_of_head callbacks fe depth budget number state final headRun
  · exact full_loop_const_of_head callbacks fe depth budget name levels state final
      notDefinition headRun


#print axioms primitive_result_nat
#print axioms primitive_result_const
#print axioms stored_definition
#print axioms stored_head_no_iota
#print axioms reduce_nat_binary
#print axioms full_loop_const_of_head
#print axioms full_loop_result_of_head

end ADWH.Experiments.Chapter15.KernelCachedArithmeticForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedBetaDeltaForward.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedHelperDirect

theorem get_app_fn_scoped : ∀ (expression : Expr) (depth : Nat),
    Expr.wscopedB depth expression = true →
      Expr.wscopedB depth (Expr.getAppFn expression) = true := by
  intro expression
  induction expression with
  | app function argument ihf _ =>
    intro depth queryScoped
    rw [Expr.wscopedB] at queryScoped
    have parts : Expr.wscopedB depth function = true ∧
        Expr.wscopedB depth argument = true := by
      exact Bool.and_eq_true_iff.mp queryScoped
    exact ihf depth parts.1
  | _ => intro depth queryScoped; exact queryScoped


theorem whnf_app_done (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (expression : Expr) (state : CState) :
    whnfAppI mode callbacks fe depth next expression [] state =
      .ok (expression, state) := by
  rw [whnfAppI.eq_def]
  all_goals rfl


theorem whnf_app_skip (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (head argument : Expr) (rest : List Expr)
    (nonLambda : head.isLam = false)
    (noIota : iotaArityOk fe (.app head argument) = false) :
    whnfAppI mode callbacks fe depth next head (argument :: rest) =
      whnfAppI mode callbacks fe depth next (.app head argument) rest := by
  funext state
  cases head with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [whnfAppI.eq_def]
    simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
      Except.bind, noIota]
    all_goals rfl


theorem whnf_app_iota_of_runs (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth : Nat) (next : Expr → CheckCM Expr)
    (head argument reduct normalized value : Expr) (rest : List Expr)
    (state afterIota afterNext final : CState)
    (nonLambda : head.isLam = false)
    (enabled : iotaArityOk fe (.app head argument) = true)
    (iotaRun : iotaRecI mode callbacks fe depth (.app head argument) state =
      .ok (some reduct, afterIota))
    (nextRun : next reduct afterIota = .ok (normalized, afterNext))
    (restRun : whnfAppI mode callbacks fe depth next normalized rest afterNext =
      .ok (value, final)) :
    whnfAppI mode callbacks fe depth next head (argument :: rest) state =
      .ok (value, final) := by
  cases head with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [whnfAppI.eq_def]
    simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
      Except.bind, enabled, ite_true, iotaRun, nextRun]
    all_goals exact restRun


theorem head_loop_app_of_runs (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (cheap : Bool) (depth budget : Nat)
    (function argument normalized value : Expr)
    (state afterHead final : CState)
    (headRun : callbacks.whnfCore cheap depth
      (Expr.getAppFn (.app function argument)) state = .ok (normalized, afterHead))
    (spineRun : whnfAppI mode callbacks fe depth
      (whnfCoreLoopI mode callbacks fe cheap depth budget) normalized
      (Expr.getAppArgsC (.app function argument)) afterHead = .ok (value, final)) :
    whnfCoreLoopI mode callbacks fe cheap depth (budget + 1)
      (.app function argument) state = .ok (value, final) := by
  change whnfCoreStepI mode callbacks fe cheap depth
    (whnfCoreLoopI mode callbacks fe cheap depth budget) (.app function argument) state = _
  simp only [whnfCoreStepI, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.pure, Except.bind, headRun]
  all_goals exact spineRun


theorem definition_head_no_iota (fe : FEnv) (expression : Expr)
    (name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint)
    (head : Expr.getAppFn expression = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    iotaArityOk fe expression = false := by
  unfold iotaArityOk
  rw [head]
  dsimp only []
  rw [found]


def NatBypass (fe : FEnv) : Expr → Prop
  | .app (.const name []) _ =>
      ¬ (name = natSuccName ∧ natLitSupportedF fe = true)
  | .app (.app (.const name []) _) _ =>
      ¬ ((name = natAddName ∨ name = natSubName ∨ name = natMulName ∨
        name = natPowName ∨ name = natBeqName ∨ name = natBleName ∨
        name = natDivName ∨ name = natModName ∨ name = natGcdName ∨
        name = natLandName ∨ name = natLorName ∨ name = natXorName ∨
        name = natShiftLeftName ∨ name = natShiftRightName) ∧
        natOpStoredF fe name = true) ∧
      ¬ (natOpWfNames.contains name = true ∧ natLitSupportedF fe = true)
  | _ => True


theorem reduce_nat_bypass (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (expression : Expr) (bypass : NatBypass fe expression) (state : CState) :
    reduceNatI callbacks fe depth expression state = .ok (none, state) := by
  cases expression with
  | app function argument =>
    cases function with
    | const name levels =>
      cases levels with
      | nil =>
        simp only [reduceNatI, Bind.bind, StateT.bind, pure, StateT.pure,
          Except.pure, Except.bind, ite_eq_right bypass]
        all_goals rfl
      | cons first rest => rfl
    | app head first =>
      cases head with
      | const name levels =>
        cases levels with
        | nil =>
          simp only [reduceNatI, Bind.bind, StateT.bind, pure, StateT.pure,
            Except.pure, Except.bind, ite_eq_right bypass.1, ite_eq_right bypass.2]
          all_goals rfl
        | cons level rest => rfl
      | _ => rfl
    | _ => rfl
  | _ => rfl


def deltaReduct (expression : Expr) (constant : ConstantVal)
    (body : Expr) (levels : List Level) : Expr :=
  Expr.mkAppN (Expr.instLevelParams constant.levelParams levels body)
    (Expr.getAppArgsC expression)


theorem unfold_definition_of_run (fe : FEnv) (expression : Expr)
    (name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint) (state final : CState)
    (head : Expr.getAppFn expression = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (helperRun : constValAtM fe name name levels state =
      .ok (Expr.instLevelParams constant.levelParams levels body, final)) :
    unfoldDefinitionI fe expression state =
      .ok (some (deltaReduct expression constant body levels), final) := by
  simp only [unfoldDefinitionI, head, Bind.bind, StateT.bind, pure,
    StateT.pure, Except.pure, Except.bind, found, ite_eq_left arity, helperRun, mkAppNM,
    deltaReduct]
  all_goals rfl


theorem full_loop_delta_of_runs (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (query head reduct value : Expr)
    (state afterHead afterDelta final : CState)
    (headRun : callbacks.whnfCore false depth query state = .ok (head, afterHead))
    (bypass : NatBypass fe head)
    (deltaRun : unfoldDefinitionI fe head afterHead = .ok (some reduct, afterDelta))
    (nextRun : whnfLoopI callbacks fe depth budget reduct afterDelta = .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 1) query state = .ok (value, final) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind,
    reduce_nat_bypass callbacks fe depth head bypass afterHead, deltaRun]
  all_goals exact nextRun


#print axioms get_app_fn_scoped
#print axioms whnf_app_done
#print axioms whnf_app_skip
#print axioms whnf_app_iota_of_runs
#print axioms head_loop_app_of_runs
#print axioms definition_head_no_iota
#print axioms reduce_nat_bypass
#print axioms unfold_definition_of_run
#print axioms full_loop_delta_of_runs

end ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedNatIotaForward.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedNatIotaForward

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedHelperDirect

def recursorName : Name := natName.str "rec"


def plainNatRule (constructor : Name) (fields : Nat) (rhs : Expr) : RecRule :=
  { ctor := constructor, nfields := fields, ctorParams := 0, fire := .plain,
    rhs := rhs, k := false, eta := false, paramsBlind := true }


def natRecApplication (levels : List Level) (motive zero step major : Expr) : Expr :=
  .app (.app (.app (.app (.const recursorName levels) motive) zero) step) major


structure NatIotaPins (fe : FEnv) (levels : List Level) where
  recursor : ConstantVal
  zero : ConstantVal
  successor : ConstantVal
  zeroRhs : Expr
  successorRhs : Expr
  recursorStored : fe.find? recursorName = some (.recInfo recursor 3 3
    [plainNatRule natZeroName 0 zeroRhs, plainNatRule natSuccName 1 successorRhs])
  levelArity : levels.length = recursor.levelParams.length
  zeroStored : fe.find? natZeroName = some (.ctorInfo zero 0 0)
  successorStored : fe.find? natSuccName = some (.ctorInfo successor 0 1)
  zeroLevels : zero.levelParams = []
  successorLevels : successor.levelParams = []
  recursorLicensed : NeverPiPrefix 4
    (Expr.instLevelParams recursor.levelParams levels recursor.type)
  successorLicensed : NeverPiPrefix 1
    (Expr.instLevelParams successor.levelParams [] successor.type)
  literals : natLitSupportedF fe = true


theorem partial_iota_arity (fe : FEnv) (levels : List Level)
    (pins : NatIotaPins fe levels) (motive zero step : Expr) :
    iotaArityOk fe (.app (.const recursorName levels) motive) = false ∧
    iotaArityOk fe (.app (.app (.const recursorName levels) motive) zero) = false ∧
    iotaArityOk fe (.app (.app (.app (.const recursorName levels) motive) zero) step) =
      false := by
  refine ⟨?_, ?_, ?_⟩ <;>
    simp only [iotaArityOk, Expr.getAppFn, pins.recursorStored, iotaNumArgs] <;> rfl


theorem complete_iota_arity (fe : FEnv) (levels : List Level)
    (pins : NatIotaPins fe levels) (motive zero step major : Expr) :
    iotaArityOk fe (natRecApplication levels motive zero step major) = true := by
  simp only [iotaArityOk, natRecApplication, Expr.getAppFn, pins.recursorStored,
    iotaNumArgs, pins.levelArity, beq_self_eq_true, Bool.true_and]
  all_goals rfl


theorem major_to_ctor_two (mode : CheckMode) (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (first second : RecRule) (major : Expr) (state : CState) :
    majorToCtorI mode callbacks fe depth recursorName [first, second] major state =
      .ok (major, state) := by
  change (if isCtorAppC fe major then (pure major : CheckCM Expr)
    else pure major) state = _
  split <;> rfl


theorem prepare_nat_of_run (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (first second : RecRule) (major : Expr) (number : Nat)
    (state afterMajor : CState) (literals : natLitSupportedF fe = true)
    (majorRun : callbacks.whnf depth major state =
      .ok (.lit (.natVal number), afterMajor)) :
    prepareMajorI .verified callbacks fe depth recursorName [first, second]
      major state = .ok (natLitToConstructor number, afterMajor) := by
  simp only [prepareMajorI, recRuleK, Bool.false_eq_true, ↓reduceIte,
    Bind.bind, StateT.bind, Except.bind, majorRun]
  simp only [litMajorToCtorI, litToCtorIfNatI, literals, ↓reduceIte,
    pure, StateT.pure, Except.pure]
  exact major_to_ctor_two .verified callbacks fe depth first second
    (natLitToConstructor number) afterMajor


theorem iota_plain_of_prepared (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (levels : List Level) (recursor constructorValue : ConstantVal)
    (first second : RecRule) (motive zero step major prepared : Expr)
    (constructor : Name) (fields : List Expr) (rawRhs recursorType constructorType rhs : Expr)
    (state afterMajor afterRecursorType afterConstructorType afterRhs : CState)
    (recursorStored : fe.find? recursorName =
      some (.recInfo recursor 3 3 [first, second]))
    (levelArity : levels.length = recursor.levelParams.length)
    (preparedRun : prepareMajorI .verified callbacks fe depth recursorName
      [first, second] major state = .ok (prepared, afterMajor))
    (constructorHead : prepared.getAppFn = .const constructor [])
    (constructorArgs : prepared.getAppArgsC = fields)
    (constructorStored : fe.find? constructor =
      some (.ctorInfo constructorValue 0 fields.length))
    (constructorLevels : constructorValue.levelParams = [])
    (ruleFound : [first, second].find? (fun rule => rule.ctor == constructor) =
      some (plainNatRule constructor fields.length rawRhs))
    (recursorTypeRun : constTyAtM fe recursorName recursorName levels afterMajor =
      .ok (recursorType, afterRecursorType))
    (recursorLicensed : NeverPiPrefix 4 recursorType)
    (constructorTypeRun : constTyAtM fe constructor constructor [] afterRecursorType =
      .ok (constructorType, afterConstructorType))
    (constructorLicensed : NeverPiPrefix fields.length constructorType)
    (rhsRun : ruleRhsAtM fe recursorName constructor recursorName constructor levels
      afterConstructorType = .ok (rhs, afterRhs)) :
    iotaRecI .verified callbacks fe depth (natRecApplication levels motive zero step major)
      state = .ok (some (Expr.mkAppN rhs ([motive, zero, step] ++ fields)), afterRhs) := by
  have headEq : (natRecApplication levels motive zero step major).getAppFn =
      .const recursorName levels := rfl
  have argsEq : (natRecApplication levels motive zero step major).getAppArgsC =
      [motive, zero, step, major] := rfl
  have arity : [motive, zero, step, major].length = 3 + 1 ∧
      levels.length = recursor.levelParams.length := ⟨rfl, levelArity⟩
  have majorArg : [motive, zero, step, major].getD 3 (Expr.mkBvar 0) = major := rfl
  have fieldArity : fields.length = 0 + fields.length := (Nat.zero_add _).symm
  have recursorCert := iotaCertsI_never callbacks fe depth recursorType
    [motive, zero, step, prepared] afterRecursorType recursorLicensed
  have constructorCert := iotaCertsI_never callbacks fe depth constructorType
    fields afterConstructorType constructorLicensed
  have indexCert := iotaIndexOkI_noIndices callbacks fe depth 3 0 constructorType
    fields ([] : List Expr) afterConstructorType
  unfold iotaRecI
  rw [headEq]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [recursorStored]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [argsEq, ite_eq_left arity]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [majorArg]
  rw [preparedRun]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [constructorHead]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [constructorStored]
  dsimp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  rw [ruleFound]
  dsimp only [plainNatRule, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.pure, Except.bind]
  rw [constructorArgs, constructorLevels, ite_eq_left fieldArity]
  have plainNotInert : RecRuleFire.plain ≠ RecRuleFire.inert := by
    intro impossible
    cases impossible
  rw [ite_eq_right plainNotInert]
  let constructorCertificate (ty : Expr) : CheckCM Bool := do
    if ← iotaCertsI callbacks fe depth true ty fields then
      iotaIndexOkI callbacks fe depth 3 3 0 ty fields []
    else pure false
  have constructorCertificateRun :
      constructorCertificate constructorType afterConstructorType =
        .ok (true, afterConstructorType) := by
    change Except.bind
      (iotaCertsI callbacks fe depth true constructorType fields afterConstructorType)
      (fun checked =>
        if checked.1 then
          iotaIndexOkI callbacks fe depth 3 3 0 constructorType fields [] checked.2
        else .ok (false, checked.2)) = .ok (true, afterConstructorType)
    rw [constructorCert]
    all_goals exact indexCert
  let constructorBlock : CheckCM Bool := do
    let ty ← constTyAtM fe constructor constructor []
    constructorCertificate ty
  have constructorBlockRun : constructorBlock afterRecursorType =
      .ok (true, afterConstructorType) := by
    change Except.bind (constTyAtM fe constructor constructor [] afterRecursorType)
      (fun found => constructorCertificate found.1 found.2) =
        .ok (true, afterConstructorType)
    rw [constructorTypeRun]
    all_goals exact constructorCertificateRun
  let recursorCertificate (ty : Expr) : CheckCM Bool := do
    if ← iotaCertsI callbacks fe depth true ty [motive, zero, step, prepared] then
      constructorBlock
    else pure false
  have recursorCertificateRun : recursorCertificate recursorType afterRecursorType =
      .ok (true, afterConstructorType) := by
    change Except.bind
      (iotaCertsI callbacks fe depth true recursorType
        [motive, zero, step, prepared] afterRecursorType)
      (fun checked => if checked.1 then constructorBlock checked.2
        else .ok (false, checked.2)) = .ok (true, afterConstructorType)
    rw [recursorCert]
    all_goals exact constructorBlockRun
  let certificate : CheckCM Bool := do
    let ty ← constTyAtM fe recursorName recursorName levels
    recursorCertificate ty
  have certificateRun : certificate afterMajor = .ok (true, afterConstructorType) := by
    change Except.bind (constTyAtM fe recursorName recursorName levels afterMajor)
      (fun found => recursorCertificate found.1 found.2) =
        .ok (true, afterConstructorType)
    rw [recursorTypeRun]
    all_goals exact recursorCertificateRun
  change Except.bind (certificate afterMajor)
    (fun checked =>
      if checked.1 then
        Except.bind
          (ruleRhsAtM fe recursorName constructor recursorName constructor levels checked.2)
          (fun found => .ok
            (some (Expr.mkAppN found.1 ([motive, zero, step] ++ fields)), found.2))
      else .ok (none, checked.2)) =
        .ok (some (Expr.mkAppN rhs ([motive, zero, step] ++ fields)), afterRhs)
  rw [certificateRun]
  all_goals
    change Except.bind
      (ruleRhsAtM fe recursorName constructor recursorName constructor levels afterConstructorType)
      (fun found => .ok
        (some (Expr.mkAppN found.1 ([motive, zero, step] ++ fields)), found.2)) =
          .ok (some (Expr.mkAppN rhs ([motive, zero, step] ++ fields)), afterRhs)
    rw [rhsRun]
    all_goals rfl


#print axioms partial_iota_arity
#print axioms complete_iota_arity
#print axioms major_to_ctor_two
#print axioms prepare_nat_of_run
#print axioms iota_plain_of_prepared

end ADWH.Experiments.Chapter15.KernelCachedNatIotaForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-trace-binary-head/source/KernelCachedBinaryHeadForward.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedBinaryHeadForward

open ConLeche
open ConLeche.Cached
open KernelCachedArithmeticForward
open KernelCachedLiteralForward

theorem full_loop_binary_query_of_runs (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (query : Expr) (operator : Name) (left right : Expr)
    (leftNumber rightNumber : Nat) (value : Expr)
    (state afterHead afterLeft afterRight final : CState)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (computed : natOpResult operator leftNumber rightNumber = some value)
    (resultForm : PrimitiveResult fe value)
    (headRun : callbacks.whnfCore false depth query state =
      .ok (binaryApplication operator left right, afterHead))
    (leftRun : callbacks.whnf depth left afterHead =
      .ok (natLiteral leftNumber, afterLeft))
    (rightRun : callbacks.whnf depth right afterLeft =
      .ok (natLiteral rightNumber, afterRight))
    (resultHeadRun : callbacks.whnfCore false depth value afterRight =
      .ok (value, final)) :
    whnfLoopI callbacks fe depth (budget + 2) query state = .ok (value, final) := by
  have primitiveRun := reduce_nat_binary callbacks fe depth operator left right
    leftNumber rightNumber value afterHead afterLeft afterRight recognized stored
    leftRun rightRun computed
  have finishRun := full_loop_result_of_head callbacks fe depth budget value
    afterRight final resultForm resultHeadRun
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth (budget + 1)) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind, primitiveRun]
  all_goals exact finishRun


#print axioms full_loop_binary_query_of_runs

end ADWH.Experiments.Chapter15.KernelCachedBinaryHeadForward
/- END exact operational selection -/

/- BEGIN exact operational selection: next-iteration/kernel-cached-trace-binary-head/source/KernelCachedLicensedTrace.lean -/
namespace ADWH.Experiments.Chapter15.KernelCachedLicensedTrace

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedBetaDeltaForward
open KernelCachedNatIotaForward

theorem beta_peel_stop_equation (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (next : Expr → CheckCM Expr) (body argument : Expr)
    (accumulated rest : List Expr) (nonLambda : body.isLam = false) :
    betaPeelI .verified callbacks fe depth next body accumulated (argument :: rest) =
      (do
        let reduct ← instListM body accumulated
        let normalized ← next reduct
        whnfAppI .verified callbacks fe depth next normalized (argument :: rest)) := by
  cases body with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [betaPeelI.eq_def]
    all_goals rfl


theorem nat_spine_iota_with_rest (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (next : Expr → CheckCM Expr) (levels : List Level)
    (pins : NatIotaPins fe levels) (motive zero step major reduct normalized value : Expr)
    (rest : List Expr) (state afterIota afterNext final : CState)
    (iotaRun : iotaRecI .verified callbacks fe depth
      (natRecApplication levels motive zero step major) state =
        .ok (some reduct, afterIota))
    (nextRun : next reduct afterIota = .ok (normalized, afterNext))
    (restRun : whnfAppI .verified callbacks fe depth next normalized rest afterNext =
      .ok (value, final)) :
    whnfAppI .verified callbacks fe depth next (.const recursorName levels)
      (motive :: zero :: step :: major :: rest) state = .ok (value, final) := by
  obtain ⟨first, second, third⟩ := partial_iota_arity fe levels pins motive zero step
  rw [whnf_app_skip .verified callbacks fe depth next (.const recursorName levels)
    motive (zero :: step :: major :: rest) rfl first]
  rw [whnf_app_skip .verified callbacks fe depth next
    (.app (.const recursorName levels) motive) zero (step :: major :: rest) rfl second]
  rw [whnf_app_skip .verified callbacks fe depth next
    (.app (.app (.const recursorName levels) motive) zero) step (major :: rest) rfl third]
  exact whnf_app_iota_of_runs .verified callbacks fe depth next
    (.app (.app (.app (.const recursorName levels) motive) zero) step)
    major reduct normalized value rest state afterIota afterNext final rfl
    (complete_iota_arity fe levels pins motive zero step major) iotaRun nextRun restRun


#print axioms beta_peel_stop_equation
#print axioms nat_spine_iota_with_rest

end ADWH.Experiments.Chapter15.KernelCachedLicensedTrace
/- END exact operational selection -/

