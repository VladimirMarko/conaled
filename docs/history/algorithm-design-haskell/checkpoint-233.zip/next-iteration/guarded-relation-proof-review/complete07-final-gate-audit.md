# Independent audit of complete-07

**Passed.** The saved eight-module fresh gate is supported by matching canonical and snapshot source/control bytes, all eight successful logs, and all **113** required axiom reports. No Lean process or source-function evaluation was run during this audit.

## Run and controls

The recorded cumulative compiler time is **28.019105929998 seconds** under the unchanged 30-second deadline. Peak child RSS is **779,936 KiB** (761.65625 MiB). Every command uses the pinned Lean commit `62eed1db4d67327ec8120be05f1a1b0847d74561`, one CPU, `-j1` and `-M1024`. Source preparation/version inspection precedes the established compiler timer; all eight compiler invocations and intervening log checks share its single deadline. The memory option is Lean's limit; RSS is separately reported.

| Fresh module | Seconds | Peak RSS, KiB | Axiom reports |
|---|---:|---:|---:|
| ArithmeticSemantics | 0.528292 | 500,616 | 6 |
| SignedRelations | 0.527540 | 511,144 | 27 |
| GuardedSource | 1.083374 | 530,488 | 8 |
| GuardedRelationChecker | 0.671331 | 511,920 | 8 |
| TableCheck | 0.244829 | 493,920 | 6 |
| SignedBlockRewrite | 0.336631 | 496,668 | 5 |
| GeneratedGuardedData | 9.458527 | 779,936 | 23 |
| GeneratedGuardedRelations | 15.164507 | 613,052 | 30 |

The runner creates new source/build directories, removes inherited Lean/Lake search paths, and gives every module the same initially empty build import root. All experimental imports are earlier modules rebuilt within this run; external imports are only pinned-toolchain `Init` modules. No previous experimental object is copied or imported. Source/control hashes match their snapshots, and all 16 resulting object/interface hashes were checked live. The independent audit checked **51 distinct file bindings**.

All 113 print occurrences match the source declarations exactly, including multiplicity. Every reported axiom set is a subset of `propext`, `Classical.choice`, and `Quot.sound`. The 16 concrete zero/binding/natural/block theorem reports contain exactly those three. No warning, error, sorry axiom, native-decide trust axiom, or other unmatched log output occurs.

## What the completed proof establishes

The internal interpretation of **866 literal guarded descriptors**, **909 views**, and **332 proof records** establishes four equalities of natural-valued functions on arbitrary Boolean assignments:

- `B 0 + B 3 = B 1 + B 2`.
- `B 6 + B 9 = B 7 + B 8`.
- `B 11 + B 14 = B 12 + B 13`.
- `B 17 + B 20 = B 18 + B 19`.

The root proofs also bind the 16 selected original-view tuples. For each quartet `(p,q,r,s)`, and arbitrary integer-valued coefficient functions, the checked signed rewrite is

`Ap*Bp + Aq*Bq + Ar*Br + As*Bs = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br`.

These are closed identities about the internally interpreted literal source data. Sample equalities, an external function evaluator, an expected count, and the proposed basis dimension are not premises. The generic checker verifies both Boolean branches with strictly earlier proof references; exact signed occurrence collection preserves multiplicities. The 133 finite range leaves compose into the three whole-table checks inside this same gate. The separately frozen direct8 review confirms all 2,439 ordered entries, dispatch intervals/defaults, 16 bindings and four roots, with the root proofs unchanged from the previous page layout except two generator-hash comments.

## Limits and recovery

This component does **not** prove a rational rank (including the diagnostic dimension31), verify the adaptive basis procedure, bind a complete selected cut contraction or the whole guarded operation stream, integrate the signed replacement into whole-board factor accounting, or establish a new queens count. In particular it does not prove `cqueens 16 = 14772512`.

This audit checks saved evidence and module imports; it is not an additional declaration-body dependency audit or kernel invocation. A fresh recovery run needs the eight current Lean sources, current runner/plan, project source guard, shared lock, and pinned Lean toolchain. It needs no old generated layout, diagnostic execution, earlier experimental object, or historical attempt. The audit script itself is explicitly a live-workspace check of original snapshots/objects; its frozen result can be retained in a compact checkpoint without pretending that historical paths remain independently executable.

## Exact bindings

- Accepted report: `7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`.
- Runner: `7cc99dd195884b1c57cff63eb2caeedbdc0cee9d464d4989b297d65405c69f94`.
- Plan: `7003e895b1851f1fbd7714e93a092122dcdcc9646e307713166cd8bfd6a7adc1`.
- Full machine-readable audit: `complete07-final-gate-audit.json`, SHA256 `0758da834edd9b3572fdcb7ce6b4dbb37d070ab5c9095394b01bfbba899c9755`.
- Prior direct8 metadata review: `594b2649fa86ebedf4cca297f889a9daab87ccdf9acf84bf460079df97649346`.
