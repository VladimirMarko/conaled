#!/usr/bin/env python3
"""Audit the saved complete-07 run; never invoke Lean or evaluate source functions.

This is a live-workspace audit, requiring the original attempt snapshots and objects.
Its resulting JSON/Markdown are evidence summaries, not a portable restoration gate.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / 'next-iteration/guarded-relation-proof'
ATTEMPT = BASE / 'attempts/complete-07'
MODULES = ['ArithmeticSemantics', 'SignedRelations', 'GuardedSource',
           'GuardedRelationChecker', 'TableCheck', 'SignedBlockRewrite',
           'GeneratedGuardedData', 'GeneratedGuardedRelations']
PRINT_COUNTS = [6, 27, 8, 8, 6, 5, 23, 30]
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
EXPECTED_REPORT = '7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314'
EXPECTED_RUNNER = '7cc99dd195884b1c57cff63eb2caeedbdc0cee9d464d4989b297d65405c69f94'
EXPECTED_PLAN = '7003e895b1851f1fbd7714e93a092122dcdcc9646e307713166cd8bfd6a7adc1'
COMMIT = '62eed1db4d67327ec8120be05f1a1b0847d74561'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def binding(path):
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
            'sha256': sha(path)}


checked = {}


def check_record(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = ROOT / path
    assert path.is_relative_to(ROOT) and path.is_file(), path
    actual = binding(path)
    assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], path
    checked[actual['path']] = actual
    return actual


report_path = ATTEMPT / 'report.json'
assert sha(report_path) == EXPECTED_REPORT
r = json.loads(report_path.read_text())
plan = json.loads((BASE / 'gate-plan.json').read_text())
assert sha(BASE / 'run_gate.py') == EXPECTED_RUNNER
assert sha(BASE / 'gate-plan.json') == EXPECTED_PLAN
assert plan['modules'] == MODULES and plan['roots'] == ['GeneratedGuardedRelations']
assert r['status'] == 'passed' and r['all_input_and_control_bindings_unchanged']
assert r['all_selected_mathematical_sources_freshly_checked']
assert r['compiled_experimental_imports_reused'] is False
assert r['source_count_proved'] is False and r['complete_circuit_checker'] is False
assert set(r['allowed_axioms']) == ALLOWED and COMMIT in r['lean_version']
assert r['root_modules'] == plan['roots']
assert [x['module'] for x in r['inputs']] == MODULES
assert [x['module'] for x in r['modules']] == MODULES
assert r['seconds'] == 28.01910592999775 and 0 < r['seconds'] < 30
c = r['constraints']
assert c == {'wall_seconds': 30, 'threads': 1, 'lean_memory_mib': 1024,
             'cpu_affinity': [0], 'shared_lock': str(ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock')}
assert (ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock').is_file()
check_record(r['compiler'])
assert r['compiler']['sha256'] == 'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'

seen, graph, module_rows, printed = set(), {}, [], []
pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
for source, item, print_count in zip(r['inputs'], r['modules'], PRINT_COUNTS):
    name = source['module']
    canonical = check_record(source)
    snapshot = Path(source['snapshot'])
    assert snapshot == ATTEMPT / 'source' / (name + '.lean')
    assert source['snapshot_sha256'] == source['sha256']
    check_record({'path': str(snapshot), 'bytes': source['bytes'], 'sha256': source['sha256']})
    code = snapshot.read_text()
    imports = [x for row in re.findall(r'^import ([^\n]+)$', code, re.M) for x in row.split()]
    assert imports == source['imports']
    assert all(x in seen or x.split('.')[0] in {'Init', 'Std'} for x in imports)
    graph[name] = [x for x in imports if x in MODULES]
    seen.add(name)
    for option, expected in [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]:
        assert re.findall(r'^set_option ' + re.escape(option) + r' (\S+)$', code, re.M) == [expected]
    required = re.findall(r'^#print axioms (\S+)$', code, re.M)
    assert required == r['required_prints'][name] == item['required_prints']
    assert len(required) == print_count
    assert item['status'] == 'passed' and item['exit_code'] == 0
    assert item['timeout'] is False and item['axiom_check_passed'] is True
    assert 0 < item['seconds'] <= r['seconds']
    assert item['command'] == [r['compiler']['path'], '-j1', '-M1024',
        '-o', str(ATTEMPT / 'build' / (name + '.olean')),
        '-i', str(ATTEMPT / 'build' / (name + '.ilean')), name + '.lean']
    log_binding = check_record(item['log'])
    assert Path(item['log']['path']) == ATTEMPT / (name + '.log')
    log = Path(item['log']['path']).read_text()
    occurrences = list(pattern.finditer(log))
    assert Counter(m[1] for m in occurrences) == Counter(required)
    assert not pattern.sub('', log).strip(), 'Unexpected non-axiom log output'
    axiom_map = {m[1]: sorted(x.strip() for x in (m[2] or '').split(',') if x.strip()) for m in occurrences}
    assert axiom_map == item['axiom_reports']
    assert all(set(x) <= ALLOWED for x in axiom_map.values())
    assert not any(word in log for word in ['sorryAx', 'Lean.ofReduceBool', 'Lean.ofReduceNat', 'Lean.trustCompiler', '_native'])
    printed.extend({'declaration': m[1], 'axioms': axiom_map[m[1]], 'module': name} for m in occurrences)
    module_rows.append({'module': name, 'source': canonical, 'log': log_binding,
                        'imports': imports, 'seconds': item['seconds'],
                        'peak_child_rss_kib': item['peak_child_rss_kib'],
                        'expected_and_observed_axiom_prints': len(required)})

reachable = set()
def visit(name):
    if name not in reachable:
        reachable.add(name)
        for child in graph[name]:
            visit(child)
visit('GeneratedGuardedRelations')
assert reachable == set(MODULES)
assert len(printed) == 113
assert sum(x['seconds'] for x in r['modules']) <= r['seconds']
assert r['peak_child_rss_kib'] == max(x['peak_child_rss_kib'] for x in r['modules']) == 779936
assert len(r['controls']) == 7 and len(r['artifacts']) == 16
for record in r['controls'] + r['artifacts']:
    check_record(record)
for current, snapshot_name in [(BASE / 'run_gate.py', 'run_gate-attempt.py'),
                               (BASE / 'gate-plan.json', 'gate-plan-attempt.json'),
                               (ROOT / 'project/adwh-lean/scripts/check.py', 'source-guard-attempt.py')]:
    assert current.read_bytes() == (ATTEMPT / snapshot_name).read_bytes()
assert r['source_guard_sha256'] == sha(ROOT / 'project/adwh-lean/scripts/check.py')
assert {Path(x['path']).name for x in r['artifacts']} == {name + ext for name in MODULES for ext in ['.olean', '.ilean']}
assert {p.name for p in (ATTEMPT / 'build').iterdir()} == {Path(x['path']).name for x in r['artifacts']}
assert {p.name for p in (ATTEMPT / 'source').iterdir()} == {name + '.lean' for name in MODULES}

layout_path = HERE / 'direct8-layout-preservation-01.json'
assert sha(layout_path) == '594b2649fa86ebedf4cca297f889a9daab87ccdf9acf84bf460079df97649346'
layout = json.loads(layout_path.read_text())
assert layout['status'] == 'passed' and layout['semantic_evaluations'] == 0
assert layout['same_leaf_predicates'] == 133 and layout['same_joins'] == 130
for record in layout['inputs']:
    if record['path'].startswith('next-iteration/guarded-relation-proof/') and '/attempts/' not in record['path']:
        check_record(record)

prefix = 'ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.'
final_axioms = r['modules'][-1]['axiom_reports']
quartets = [[0, 1, 2, 3], [6, 7, 8, 9], [11, 12, 13, 14], [17, 18, 19, 20]]
targets = []
for i, quartet in enumerate(quartets):
    for suffix in ['zero', 'bound', 'nat', 'block']:
        target = prefix + f'relation{i}_{suffix}'
        assert set(final_axioms[target]) == ALLOWED
        targets.append({'declaration': target, 'quartet': quartet, 'axioms': final_axioms[target]})

review = {
    'format': 'guarded-relations-complete07-final-gate-audit-v1', 'status': 'passed',
    'method': 'Independent saved-byte, log, command, import-closure and source-statement review; no Lean invocation or source-function evaluation.',
    'report': binding(report_path), 'reviewer': binding(Path(__file__)),
    'resources': {**c, 'cumulative_seconds': r['seconds'], 'module_seconds_sum': sum(x['seconds'] for x in r['modules']),
                  'peak_child_rss_kib': r['peak_child_rss_kib'],
                  'timer_scope': 'One deadline for all eight compiler processes and intervening log checks. Initial version/hash/source-snapshot preparation is outside this established compiler timer.',
                  'memory_scope': 'Unchanged Lean -M1024 limit; RSS is the separately observed process maximum.'},
    'freshness': {'all_eight_mathematical_modules_fresh': True, 'experimental_compiled_imports_reused': False,
                  'external_imports': 'Only pinned-toolchain Init modules; no earlier experiment or ADWH module import.',
                  'static_runner_checks': ['New source/build directories created without reuse', 'Single build LEAN_PATH',
                    'Inherited LEAN_/LAKE_ environment removed', 'One CPU affinity and -j1',
                    'Shared exclusive nonblocking compile lock', 'One 30-second deadline',
                    'Exit/timeout/exact print multiplicity/allowed axiom checks', 'Before/after source and control hashes'],
                  'import_graph': graph},
    'modules': module_rows, 'axiom_reports_rechecked': 113, 'allowed_axioms': sorted(ALLOWED),
    'all_axiom_reports': printed, 'concrete_targets': targets,
    'file_bindings_rechecked': list(checked.values()), 'distinct_file_bindings_rechecked': len(checked),
    'layout_review': binding(layout_path),
    'proved_scope': {'interpretation': 'Literal original guarded descriptors interpreted internally as natural-valued functions of arbitrary Boolean assignments.',
                     'checked_tables': {'nodes': 866, 'views': 909, 'proof_records': 332},
                     'identities': [{'quartet': q, 'equation': f'B {q[0]} + B {q[3]} = B {q[1]} + B {q[2]} pointwise'} for q in quartets],
                     'original_view_bindings': 16,
                     'block_rewrite': 'Ap*Bp + Aq*Bq + Ar*Br + As*Bs = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br, for arbitrary Int-valued coefficient functions.',
                     'closed_identity_premises': 'No sample value, proposed basis dimension, external equality, expected count, or supplied function meaning is a premise.'},
    'not_proved_by_this_component': ['Exact or minimal rational rank, including diagnostic dimension31',
        'Correctness of the adaptive basis algorithm', 'Full guarded operation stream or complete selected cut expansion/contraction',
        'A signed replacement integrated into whole-board factor accounting', 'Any new queens count, cqueens8 or cqueens16'],
    'audit_limit': 'No declaration-body dependency traversal or new kernel execution was performed. Hash/log evidence substantiates the recorded run; retained Lean source remains the mathematical deliverable.',
    'recovery': {'fresh_command': 'python next-iteration/guarded-relation-proof/run_gate.py --attempt fresh-recovery --plan gate-plan.json',
                 'needs': 'Eight current Lean sources, runner/plan, unchanged project source guard, existing shared lock, pinned Lean toolchain and standard library.',
                 'does_not_need_for_Lean': 'Diagnostic producer/replay execution, source trace/work logs, old layouts/attempts, or old experimental objects.',
                 'audit_script_portability': 'This audit script checks live original snapshots and object hashes. A compact archive may retain its frozen result without those regenerable files; rerun the fresh gate for new recovery evidence.'}}
json_path = HERE / 'complete07-final-gate-audit.json'
md_path = HERE / 'complete07-final-gate-audit.md'
assert not json_path.exists() and not md_path.exists()
json_path.write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
rows = '\n'.join(f"| {x['module']} | {x['seconds']:.6f} | {x['peak_child_rss_kib']:,} | {x['expected_and_observed_axiom_prints']} |" for x in module_rows)
md_path.write_text(f'''# Independent audit of complete-07

**Passed.** The saved eight-module fresh gate is supported by matching canonical and snapshot source/control bytes, all eight successful logs, and all **113** required axiom reports. No Lean process or source-function evaluation was run during this audit.

## Run and controls

The recorded cumulative compiler time is **{r['seconds']:.12f} seconds** under the unchanged 30-second deadline. Peak child RSS is **779,936 KiB** (761.65625 MiB). Every command uses the pinned Lean commit `{COMMIT}`, one CPU, `-j1` and `-M1024`. Source preparation/version inspection precedes the established compiler timer; all eight compiler invocations and intervening log checks share its single deadline. The memory option is Lean's limit; RSS is separately reported.

| Fresh module | Seconds | Peak RSS, KiB | Axiom reports |
|---|---:|---:|---:|
{rows}

The runner creates new source/build directories, removes inherited Lean/Lake search paths, and gives every module the same initially empty build import root. All experimental imports are earlier modules rebuilt within this run; external imports are only pinned-toolchain `Init` modules. No previous experimental object is copied or imported. Source/control hashes match their snapshots, and all 16 resulting object/interface hashes were checked live. The independent audit checked **{len(checked)} distinct file bindings**.

All 113 print occurrences match the source declarations exactly, including multiplicity. Every reported axiom set is a subset of `propext`, `Classical.choice`, and `Quot.sound`. The 16 concrete zero/binding/natural/block theorem reports contain exactly those three. No warning, error, sorry axiom, native-decide trust axiom, or other unmatched log output occurs.

## What the completed proof establishes

The internal interpretation of **866 literal guarded descriptors**, **909 views**, and **332 proof records** establishes four equalities of natural-valued functions on arbitrary Boolean assignments:

- `B 0 + B 3 = B 1 + B 2`.
- `B 6 + B 9 = B 7 + B 8`.
- `B 11 + B 14 = B 12 + B 13`.
- `B 17 + B 20 = B 18 + B 19`.

The root proofs also bind the 16 selected original-view tuples. For each quartet `(p,q,r,s)`, and arbitrary integer-valued coefficient functions, the checked signed rewrite is

`Ap*Bp + Aq*Bq + Ar*Br + As*Bs = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br`.

These are closed identities about the internally interpreted literal source data. Sample equalities, an external function evaluator, an expected count, and the proposed basis dimension are not premises. The generic checker verifies both Boolean branches with strictly earlier proof references; exact signed occurrence collection preserves multiplicities. The 133 finite range leaves compose into the three whole-table checks inside this same gate. The separately frozen direct8 review confirms all 2,439 ordered entries, dispatch intervals/defaults, 16 bindings and four roots, with the root proofs unchanged from the previous page layout except two generator-hash comments.

## Limits and recovery

This component does **not** prove a rational rank (including the diagnostic dimension31), verify the adaptive basis procedure, bind a complete selected cut contraction or the whole guarded operation stream, integrate the signed replacement into whole-board factor accounting, or establish a new queens count. In particular it does not prove `cqueens 16 = 14772512`.

This audit checks saved evidence and module imports; it is not an additional declaration-body dependency audit or kernel invocation. A fresh recovery run needs the eight current Lean sources, current runner/plan, project source guard, shared lock, and pinned Lean toolchain. It needs no old generated layout, diagnostic execution, earlier experimental object, or historical attempt. The audit script itself is explicitly a live-workspace check of original snapshots/objects; its frozen result can be retained in a compact checkpoint without pretending that historical paths remain independently executable.

## Exact bindings

- Accepted report: `{EXPECTED_REPORT}`.
- Runner: `{EXPECTED_RUNNER}`.
- Plan: `{EXPECTED_PLAN}`.
- Full machine-readable audit: `complete07-final-gate-audit.json`, SHA256 `{sha(json_path)}`.
- Prior direct8 metadata review: `{sha(layout_path)}`.
''')
print(json.dumps({'status': 'passed', 'bindings': len(checked), 'axiom_reports': len(printed),
                  'json': binding(json_path), 'markdown': binding(md_path), 'script': binding(Path(__file__))}, sort_keys=True))
