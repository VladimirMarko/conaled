# Four guarded identities: concrete source boundary

**The four fixed additive identities are accepted by Lean**, for explicitly specified guarded functions interpreted internally from a finite node table. The root source proves each signed identity, the equivalent natural additive equality, and the corresponding weighted integer rewrite. It does not state a new queens count or a full rank31 theorem.

This review uses source inspection, saved report/log inspection, byte hashing and equality comparisons between saved records and literal data. It invokes no Lean process, function evaluator, cofactor procedure, normalizer, rank calculation or new diagnostic. The accompanying JSON binds the exact files reviewed. The independent compilation evidence is `guarded-relation-proof/attempts/complete-07/report.json`, SHA256 `7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`: all eight modules passed fresh in 28.01910592999775 seconds, with peak child RSS 779,936 KiB, under the unchanged cumulative 30-second/one-CPU/`-j1 -M1024` gate. No compiled experimental imports were reused. All 113 required axiom reports were present and used only `propext`, `Quot.sound` and `Classical.choice`. The root log explicitly reports all four `relationN_zero`, `relationN_bound`, `relationN_nat` and `relationN_block` theorems.

## Exact identities and original columns

| Original columns | Signed relation | Saved ProofID | Dense root |
|---|---|---:|---:|
| 0, 1, 2, 3 | B0 − B1 − B2 + B3 = 0 | 134 | 130 |
| 6, 7, 8, 9 | B6 − B7 − B8 + B9 = 0 | 216 | 205 |
| 11, 12, 13, 14 | B11 − B12 − B13 + B14 = 0 | 289 | 278 |
| 17, 18, 19, 20 | B17 − B18 − B19 + B20 = 0 | 343 | 331 |

The JSON records all sixteen exact original `(positive mask, negative mask, core ID)` tuples, their dense view indices, and their completed validation WorkIDs. The generated `bN_original` theorems check those tuples through `toOriginalView`. Each `relationN_bound` explicitly conjoins its four original-view bindings with its signed identity. The function `B` is total for convenience, but only these sixteen original column numbers are specified or used by a conclusion. Its fallback case is not a binding for any of the other nineteen columns.

The 866-node table retains each original source ID and exact raw constructor fields. Branches and guards carry both original child IDs and separate dense child links. The checker requires earlier dense links and equality of each raw child ID with the linked node's original ID. Strict adjacent original-ID order prevents duplicate labels. The literal supports are checked proposals; no externally reported maximum or function value is used to justify a semantic shortcut.

The 909 views and 332 proofs are selected from completed records. Dense proof 0 is the sole empty terminal. The other 331 proofs have two prior child references. Root goal order is not assumed: each root proof uses a checked `List.Perm` to the desired four-term list. The original ProofID table is provenance metadata; the accepted concrete table checks and generic soundness theorem establish the meaning of every in-bounds dense proof.

The accepted representation reads contiguous chunks of at most eight entries directly through balanced interval dispatch. Each leaf subtracts its fixed chunk offset; the final chunk retains the original out-of-range default. Checked chunk sizes sum to the declared table counts. This representation changes no ordered entry or main identity statement. The independent direct8 layout review checks all 2,439 ordered entries, all intervals/offsets/defaults, the sixteen bindings and four roots. Earlier rejected representations and resource failures remain preserved; acceptance here is tied to the exact complete-07 source bytes.

## False acceptance review

The node meaning is internal recursion on earlier dense IDs. `checkNodes` fixes original node0 as constant0, validates every active reference, and checks support, variable order and guard conditions. `cofactorView` validates the actual view and either handles a checked guard literal, a proved absent variable, or the exact branch head. Other dependent-variable cases reject. Guard flattening preserves the cube; contradictory literals produce zero through a proved equality.

The relation checker preserves every signed occurrence. It merges only equal complete views, using integer addition, and deletes only a zero coefficient or the distinguished view whose zero meaning is proved. Both collected lists are compared by permutation. Both Boolean branches and strictly earlier proof indices are required. An empty step requires a literally empty goal. Every dense view reference is bounded. Total array defaults therefore cannot provide an unverified active source or a circular proof.

The public view-table premise is redundant for the semantic induction because every actual cofactor checks its own view. This is safe: the internally defined meaning is total, the terminal goal is empty, and cancellation is exact for arbitrary integer coefficients. The concrete module still separately checks the entire view table.

The accepted root checks the original predicates in contiguous ranges of at most sixteen indices, then applies the proved `TableCheck.checkRange_append` rule. Each join names its exact predicate, start and two lengths; the right child starts at the left endpoint plus its length. The final ranges are exactly `[0,866)`, `[0,909)` and `[0,332)`. The 133 leaf proofs and 130 joins yield the unchanged global checker conclusions through proved wrappers, including the distinguished zero-node condition. Coverage is proved in Lean, and every range belongs to the same cumulative resource budget. The earlier empty root logs in `complete-05` and `complete-06` are not used to infer acceptance or an internal stopping phase.

No mathematical false acceptance blocker was found in these rules or in their concrete root interface. Compilation errors in rejected development attempts concerned syntax or proof scripts; the accepted checker revision changes no executable definition or theorem statement.

## How external candidates become kernel-checked equalities

The external discovery algorithm proposes relations and recorded local proof steps. The generator selects those records and emits literal data. Neither program's correctness, success status nor claimed rank is a hypothesis of the Lean theorem.

Lean defines the selected functions internally from constants, branches and guarded cores. Ordinary `decide +kernel` proofs then establish the actual node, view and proof checks for the supplied literals. These are kernel-validated computations and ordinary proof terms; the gate does not substitute a native or external evaluator's answer. Generic soundness, itself checked fresh, turns those finite checked conditions into equality for every assignment `Nat → Bool`: each split has both Boolean cases, every proof reference points backward, and all signed collection is proved to preserve the represented function. The four root permutations expose the advertised original-column relations; the algebraic theorems then yield the natural equalities and signed block rewrites.

The correctness of the finite certificate is therefore verified within Lean. The separate question of whether these exact functions are the intended factors of a larger queens computation still requires the source agreement and complete cut bridge below.

## What the original-ID binding does and does not prove

The copied raw descriptors and original-ID equalities make the selected graph auditable against the retained source trace. Those byte and record comparisons establish provenance. The Lean statements themselves are about the explicitly supplied finite graph and its internal meaning; a file hash is never a logical premise.

In particular, equal original IDs alone do **not** prove agreement with a future, larger semantic table. Such a table may use different dense coordinates. Before transporting these identities into that table, a separate agreement theorem must establish that each selected original node occurs there with the same raw constructor, corresponding children and constant values. Induction on the checked prior-node relation can then establish equality of the internal meanings, followed by equality of the selected guarded views. The arbitrary default entries cannot substitute for this agreement proof.

The same boundary applies to the counting algorithm. Full cut coverage and multiplicity, identification of the grouped B functions, and factor/source lineage are still required before these identities justify a rewritten contraction or source count. The present certificate establishes no such integration and supplies no runtime improvement claim.

## Signed rewrite scope

For each quartet, the natural equality is `Bp + Bs = Bq + Br`. The weighted rewrite is

    Ap*Bp + Aq*Bq + Ar*Br + As*Bs
      = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br.

The four coefficient functions are arbitrary integer-valued functions. This statement preserves actual subtraction, all multiplicities and overlapping contributions. It does not imply that `Ap-As` is nonnegative or that the resulting representation with 31 terms is a natural-valued basis. A later source-linked use must retain integer semantics or prove an additional nonnegativity result.
