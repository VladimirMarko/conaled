## Active completion work — checkpoint 225

Continue the user's instruction to complete the original n16 theorem, publish
standalone durability checkpoints promptly, expose and upload them, then keep
working. The stock numeral and installed validating-kernel result remain open.
The integrated project, accepted reflection/numerical result and complete
conditional pure177 result retain their earlier exact scopes. A successful
external numerical checker is not the missing stock or original-record proof.

Two new complete changed runs are now consumed and preserved. Both freshly
checked the new Core retraction proof, including its explicit eq_of_toList
report. It remains a roughly12-second dependency; no substantial speedup was
established. The native companion remains source-only and separately owned.

The five-owner numeric475 run accepted Core2 and Cached25, then its combined
TraceSupport owner failed on proof errors and the cumulative deadline. The
whole interval was30.357974432998162seconds, peak885844KiB. Core12.215362275997904
plus Cached11.765872735999437 used about23.98seconds. TraceSupport printed123
reports, including error-recovery axioms; all123 are unaccepted because the
physical owner failed. The later PureSupport/NumericTrace owners never started.
Its114688-byte stdout contains75 captured error headers and ends mid-goal.
The captured defects lie in Arithmetic, BetaDelta, ForwardInterface and NatIota
logical inputs. This is a partial diagnostic census. The consumed assembly
and all earlier logical source scopes remain unchanged. Separate diagnosed
corrections to those four logical owners are being authored after this cut.

Read kernel-nat-only-trace-numeric-assembly/gate/RESULT-AND-NEXT.md. It retains
the actual report, six logs, permanent marker, root tool receipts and all961
read-only snapshot-to-canonical mappings, independently compared byte for byte.
All identity/runtime/affinity postchecks passed; only four expected prefix
artifacts existed. An earlier metadata preflight failed on two incorrect map
keys before any compiler or marker. Its controls/review/receipt were preserved
read-only, the exact two-key correction independently reviewed, and corrected
preflight passed. This was not a mathematical retry or changed source key.

The distinct repaired Wrapper137 run finished within resource limits at
29.748504211002seconds, peak884780KiB. Core2/Cached25/Stable20/Helper25/Literal8/
Frame16 passed:96 accepted reports. Wrapper exited1 after14 errors in four
proof scopes and all41 reports; all41 are unaccepted, including error-recovery
reports. The14955-byte stdout reaches the end, unlike S's truncated log.
Remaining scopes are Nat literal reduction in add-zero, the false tower-entry
branch in equality type-sort lookup, stuck-application equality and Boolean
negation in constant inference. A separate exact four-scope repair is the next
root source task; it is not already accepted or part of this checkpoint.

Read kernel-cached-record-wrapper-diagnosed-repairs/gate/RESULT-AND-NEXT.md. The
actual report, fourteen logs, permanent marker, root receipts and572 independently
compared canonical snapshot mappings are retained. All source/control/runtime
postchecks passed; twelve prefix artifacts exist. No deadline or memory kill
occurred. S's earlier partial failure and all earlier evidence remain intact.

The actual five-owner assembly has its own693-input independent review. It
preserves two complete owners and34 import-relocated proof inputs,60 removed
imports/94 literal spans,475 ordered roots,66 logical origins/68 source segments
and50 separate historical review scopes. Consolidation changes available
elaboration environments; literal source preservation was not equated with
successful compilation. The control reviews and both exact consumed attempts
preserve the distinction between observed and accepted report counts.

The direct numeric trace and its reviewed six-alias correction retain their
input-parametric FirstOrderNat result. Their query bound is12+depth*(14+5*width),
hence1516 at16/16 for the actual callback99998/depth0. No numeral is assumed.
The four-root kernel-nat-only-record-composition source is independently
reviewed (28 inputs) but uncompiled. It constructs QueryWithRest using the
actual nine-field RestCaches frame and composes the numeric query with the
existing original checkPending driver theorem. Actual stored Program/NatRec/
Arithmetic/RecordPins, true-prefix lookup, record/type/raw annotation shapes
and computed-result equality remain explicit; it supplies no concrete record
or native InstalledEnv. A complete shared closure must reconcile physical
imports and freshly compile the corrected owners, Typing, Driver and composition.

The native optional-certificate interface in
kernel-native-record-certificate-fallback has one dispatcher/four proofs/five
reports, with a73-input independent source review. It imports the actual native
Installed module. For an in-bounds record, original GroupChecked supplies the
actual checkPending-from-{} run, so original checkRecord equals success with
the supplied lifted proof. The none branch is the literal original checkRecord;
the universal equality covers every optional certificate and preserves the
original CheckError×fold-position result. It supplies no producer, concrete
certificate, integration, numeral or timing gain. Its57 native dependencies
(58 including leaf) remain uncompiled and ineligible for the current ordinary
gate because of original pin-loader/default-resource and ownership facilities.

The earlier actual annotation/storage package retains15 source-only native
equations and its separate review. Phase A stores annotated values; the original
pending-record check starts Phase B from{}. Guards must inspect the actual
annotated newest-first restricted prefix; restrictTo retains the full env field.
Successful installation, complete actual program/recursor/record recognition,
canonical index/Nodup, numeric comparison yielding the literal from computation,
cache lifecycle, native ownership, EnvWF/model linkage and original GroupChecked
remain open. Neither a proof of success-to-pure nor the known numerical answer
can substitute for these forward obligations.

Next: finish precisely mapped repairs to the four numeric support owners and
four Wrapper scopes, independently review them, and select genuinely changed
complete consumers. The roughly24-second Core+Cached cost leaves little room;
do not assume module consolidation alone provides a practical complete path.
Continue the exact native eligibility and actual-record recognizer assessment.
The optional-certificate dispatcher is a reusable interface, not the producer.
Do not run an unchanged consumed closure or repeat a known failing dependency
under another gate merely to obtain the same diagnostics.

Checkpoint224's successful publication and clean-restoration receipt is included.
All accepted mathematical sources/results remain recoverable. Compiler binaries,
prepared objects, duplicate attempt input/build trees, full textbook and full
upstream metatheory build are omitted. Restore SDK/upstream from
session215-runtime-restoration.json. The explicit publication guard is storage
only. Dedicated complete saved-result readers for recent runs remain pending;
the byte-checked recovery maps do not claim those broader reader audits.

Root alone executes compilers, mathematical/native programs, gates/preflights,
exporters and saved readers. Every new complete mathematical closure freshly
checks all selected upstream/experimental dependencies in one cumulative
30-second, one-CPU/thread,1-GiB interval with default resources and only
propext, Quot.sound and Classical.choice. No admission, prepared experimental
imports, split budget, metatheory exemption, kernel bypass or unchanged retry.
