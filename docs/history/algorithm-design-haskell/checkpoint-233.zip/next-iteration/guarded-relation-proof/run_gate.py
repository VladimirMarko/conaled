#!/usr/bin/env python3
"""Fresh selected Lean component gate for guarded identities and signed block transfer."""
from __future__ import annotations
import argparse
from collections import Counter
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LEAN = ROOT / 'runtime-restore/lean-4.33.0-rc1-linux/bin/lean'
LEAN_SHA = 'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
COMMIT = '62eed1db4d67327ec8120be05f1a1b0847d74561'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
DEPENDENCY_PINS = {
    'ArithmeticSemantics': 'c16315d993face4dd5e54cdab7f6b63c5279f3a5af1e2ffd1d41c60f1afc4559',
    'SignedRelations': '2fb5d47a1b5a12fbebf55cea3485c7b44183026aecfa33a76b143bf70f8736ec',
}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
FORBIDDEN = ['sorryAx', 'Lean.ofReduceBool', 'Lean.ofReduceNat', 'Lean.trustCompiler', '_native']


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def binding(p):
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}


def save(target, report):
    (target / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')


def child(command, source, env, log, cpu, deadline):
    def setup():
        os.setsid()
        os.sched_setaffinity(0, {cpu})
    began = time.monotonic()
    timeout = False
    with log.open('w') as out:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=out,
                                   stderr=subprocess.STDOUT, preexec_fn=setup)
        try:
            while True:
                done, status, usage = os.wait4(process.pid, os.WNOHANG)
                if done:
                    timeout = time.monotonic() > deadline
                    break
                if time.monotonic() >= deadline:
                    os.killpg(process.pid, signal.SIGKILL)
                    _, status, usage = os.wait4(process.pid, 0)
                    timeout = True
                    break
                time.sleep(0.01)
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
            raise
        process.returncode = os.waitstatus_to_exitcode(status)
    return {'command': command, 'exit_code': process.returncode, 'timeout': timeout,
            'seconds': time.monotonic() - began, 'peak_child_rss_kib': usage.ru_maxrss}


def axioms_in(text):
    found = {}
    for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", text, re.S):
        found[m[1]] = sorted(x.strip() for x in m[2].split(',') if x.strip())
    for m in re.finditer(r"'([^']+)' does not depend on any axioms", text):
        found[m[1]] = []
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--plan', required=True, type=Path)
    args = parser.parse_args()
    plan_path = (HERE / args.plan).resolve()
    if plan_path.parent != HERE:
        raise ValueError('gate plan must be a direct file in this component directory')
    plan = json.loads(plan_path.read_text())
    modules = plan['modules']
    if not modules or len(set(modules)) != len(modules) or not all(
            type(name) is str and re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', name) for name in modules):
        raise ValueError('invalid module list')
    roots = plan.get('roots', [modules[-1]])
    if not roots or not set(roots) <= set(modules):
        raise ValueError('invalid root modules')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', args.attempt):
        raise ValueError('invalid attempt identifier')
    target = HERE / 'attempts' / args.attempt
    target.mkdir(parents=True, exist_ok=False)
    report = {'kind': 'fresh-guarded-relation-component-gate', 'status': 'preparing',
              'scope': plan['scope'], 'root_modules': roots,
              'complete_circuit_checker': False, 'source_count_proved': False,
              'compiled_experimental_imports_reused': False, 'modules': [],
              'constraints': {'wall_seconds': 30, 'threads': 1, 'lean_memory_mib': 1024,
                              'shared_lock': str(LOCK)}, 'allowed_axioms': sorted(ALLOWED)}
    save(target, report)
    queued = time.monotonic()
    try:
        with LOCK.open('r') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            report['lock_wait_seconds'] = time.monotonic() - queued
            assert sha(LEAN) == LEAN_SHA
            for name, expected in DEPENDENCY_PINS.items():
                if name in modules:
                    assert sha(HERE / (name + '.lean')) == expected
            version = subprocess.run([str(LEAN), '--version'], text=True,
                                     capture_output=True, timeout=10, check=True).stdout.strip()
            assert COMMIT in version
            report['lean_version'] = version
            report['compiler'] = binding(LEAN)
            guard = types.ModuleType('unchanged_project_source_guard')
            guard.__file__ = str(GUARD)
            exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
            source, build = target / 'source', target / 'build'
            source.mkdir(); build.mkdir()
            runner_copy = target / 'run_gate-attempt.py'
            runner_copy.write_bytes(Path(__file__).read_bytes())
            guard_copy = target / 'source-guard-attempt.py'
            guard_copy.write_bytes(GUARD.read_bytes())
            plan_copy = target / 'gate-plan-attempt.json'
            plan_copy.write_bytes(plan_path.read_bytes())
            controls = [binding(p) for p in (Path(__file__), runner_copy, GUARD, guard_copy,
                                             plan_path, plan_copy, LEAN)]
            inputs, previous, required = [], set(), {}
            imports_by_module = {}
            for name in modules:
                original = HERE / (name + '.lean')
                raw = original.read_bytes()
                code = guard.check_lean_source(original, raw.decode())
                for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'),
                                      ('Elab.async', 'false')]:
                    matches = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
                    assert matches and set(matches) == {value}, (name, option)
                imports = [m for line in re.findall(r'^\s*import\s+([^\n]+)$', code, re.M)
                           for m in line.split()]
                assert all(m in previous or m.split('.')[0] in {'Init', 'Std'} for m in imports)
                imports_by_module[name] = imports
                previous.add(name)
                required[name] = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
                assert required[name]
                frozen = source / (name + '.lean')
                frozen.write_bytes(raw)
                frozen.chmod(0o444)
                inputs.append({**binding(original), 'module': name, 'imports': imports,
                               'snapshot': str(frozen), 'snapshot_sha256': sha(frozen)})
            reached = set()
            def reach(name):
                if name in reached:
                    return
                reached.add(name)
                for imported in imports_by_module[name]:
                    if imported in imports_by_module:
                        reach(imported)
            for root_name in roots:
                reach(root_name)
            assert reached == set(modules)
            cpu = min(os.sched_getaffinity(0))
            report['constraints']['cpu_affinity'] = [cpu]
            env = dict(os.environ)
            for key in list(env):
                if key.startswith('LEAN_') or key.startswith('LAKE_'):
                    del env[key]
            env.update(LEAN_PATH=str(build), LEAN_NUM_THREADS='1', OMP_NUM_THREADS='1',
                       OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
            report.update(inputs=inputs, controls=controls, required_prints=required,
                          status='running', source_guard_sha256=sha(GUARD))
            save(target, report)
            began = time.monotonic()
            deadline = began + 30.0
            good = True
            for name in modules:
                if time.monotonic() >= deadline:
                    good = False
                    break
                command = [str(LEAN), '-j1', '-M1024', '-o', str(build / (name + '.olean')),
                           '-i', str(build / (name + '.ilean')), name + '.lean']
                log = target / (name + '.log')
                item = child(command, source, env, log, cpu, deadline)
                text = log.read_text()
                ax = axioms_in(text)
                occurrences = re.findall(r"'([^']+)' (?:depends on axioms:|does not depend on any axioms)", text)
                item.update(module=name, log=binding(log), axiom_reports=ax,
                            required_prints=required[name])
                item['axiom_check_passed'] = (Counter(occurrences) == Counter(required[name])
                    and set(ax) == set(required[name])
                    and all(set(v) <= ALLOWED for v in ax.values())
                    and not any(word in text for word in FORBIDDEN))
                item['status'] = 'passed' if (item['exit_code'] == 0 and not item['timeout']
                                               and item['axiom_check_passed']) else 'failed'
                report['modules'].append(item)
                if item['status'] != 'passed':
                    good = False
                    break
            report['seconds'] = time.monotonic() - began
            report['peak_child_rss_kib'] = max((m['peak_child_rss_kib'] for m in report['modules']), default=0)
            good = good and len(report['modules']) == len(modules) and report['seconds'] <= 30.0
            report['all_selected_mathematical_sources_freshly_checked'] = good
            for row in inputs:
                assert sha(Path(row['path'])) == sha(Path(row['snapshot'])) == row['sha256']
            for row in controls:
                assert sha(Path(row['path'])) == row['sha256']
            report['all_input_and_control_bindings_unchanged'] = True
            report['artifacts'] = [binding(p) for p in sorted(build.rglob('*')) if p.is_file()]
            report['status'] = 'passed' if good else 'failed'
            save(target, report)
    except BaseException as error:
        report['status'] = 'failed'
        report['exception'] = {'type': type(error).__name__, 'message': str(error)}
        save(target, report)
        raise
    print(json.dumps({'status': report['status'], 'seconds': report.get('seconds'),
                      'peak_child_rss_kib': report.get('peak_child_rss_kib'),
                      'report': str(target / 'report.json'), 'sha256': sha(target / 'report.json')}))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
