import SignedRelations

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Transfer a checked four-term relation between natural-valued functions to an
exact signed block rewrite. The left coefficients may already be signed.
No independence, nonnegativity of a difference, count, or rank is assumed.
Projection below preserves both Boolean contributions at every occurrence.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite

open SignedRelations

def originalBlock (Ap Aq Ar As : Value) (Bp Bq Br Bs : Weight) : Value :=
  fun σ => Ap σ * (Bp σ : Int) + Aq σ * (Bq σ : Int) +
    Ar σ * (Br σ : Int) + As σ * (Bs σ : Int)

def reducedBlock (Ap Aq Ar As : Value) (Bp Bq Br : Weight) : Value :=
  fun σ => (Ap σ - As σ) * (Bp σ : Int) +
    (Aq σ + As σ) * (Bq σ : Int) + (Ar σ + As σ) * (Br σ : Int)

theorem four_term_int (ap aq ar as bp bq br bs : Int)
    (h : bp + bs = bq + br) :
    ap * bp + aq * bq + ar * br + as * bs =
      (ap - as) * bp + (aq + as) * bq + (ar + as) * br := by
  have hbs : bs = bq + br - bp := by
    symm
    apply Int.sub_eq_iff_eq_add.mpr
    exact h.symm.trans (Int.add_comm bp bs)
  rw [hbs, Int.mul_sub, Int.mul_add, Int.sub_mul, Int.add_mul, Int.add_mul]
  simp only [Int.sub_eq_add_neg]
  ac_rfl

theorem nat_four_of_signed_zero {ι : Type} (meaning : ι → Weight) (p q r s : ι)
    (h : Zero (combine (fun i => lift (meaning i))
      [(1, p), (-1, q), (-1, r), (1, s)])) :
    add (meaning p) (meaning s) = add (meaning q) (meaning r) := by
  apply lift_injective
  funext σ
  apply Int.sub_eq_zero.mp
  calc
    lift (add (meaning p) (meaning s)) σ -
        lift (add (meaning q) (meaning r)) σ =
        combine (fun i => lift (meaning i))
          [(1, p), (-1, q), (-1, r), (1, s)] σ := by
      simp only [lift, add, Int.natCast_add, combine, zero,
        Int.one_mul, Int.neg_one_mul, Int.add_zero,
        Int.sub_eq_add_neg, Int.neg_add]
      ac_rfl
    _ = 0 := h σ

theorem four_term_rewrite (Ap Aq Ar As : Value) (Bp Bq Br Bs : Weight)
    (h : ∀ σ, Bp σ + Bs σ = Bq σ + Br σ) :
    originalBlock Ap Aq Ar As Bp Bq Br Bs = reducedBlock Ap Aq Ar As Bp Bq Br := by
  funext σ
  have hcast : (Bp σ : Int) + (Bs σ : Int) = (Bq σ : Int) + (Br σ : Int) := by
    simpa only [Int.natCast_add] using congrArg (fun n : Nat => (n : Int)) (h σ)
  exact four_term_int (Ap σ) (Aq σ) (Ar σ) (As σ)
    (Bp σ : Int) (Bq σ : Int) (Br σ : Int) (Bs σ : Int) hcast

theorem four_term_rewrite_of_signed_zero {ι : Type} (meaning : ι → Weight)
    (p q r s : ι) (Ap Aq Ar As : Value)
    (h : Zero (combine (fun i => lift (meaning i))
      [(1, p), (-1, q), (-1, r), (1, s)])) :
    originalBlock Ap Aq Ar As (meaning p) (meaning q) (meaning r) (meaning s) =
      reducedBlock Ap Aq Ar As (meaning p) (meaning q) (meaning r) := by
  apply four_term_rewrite
  intro σ
  exact congrFun (nat_four_of_signed_zero meaning p q r s h) σ

theorem project_context_congr {f g : Value} (h : f = g)
    (context rest : Value) (vars : List Nat) :
    project vars (fun σ => context σ * f σ + rest σ) =
      project vars (fun σ => context σ * g σ + rest σ) := by
  exact congrArg (fun value : Value =>
    project vars (fun σ => context σ * value σ + rest σ)) h

end ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite.four_term_int
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite.nat_four_of_signed_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite.four_term_rewrite
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite.four_term_rewrite_of_signed_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedBlockRewrite.project_context_congr
