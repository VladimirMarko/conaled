# Four guarded relations: fixed module contract

Namespace: `ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations`.

Ownership: `GuardedSource.lean` and this API are residual_rules; `GuardedRelationChecker.lean` is runtime_evidence; concrete extraction/generation is reuse_diagnostics; compilation and the combined fresh gate are root. No agent invokes Lean independently.

## Source data and semantics

```lean
inductive RawNode where
  | constant (value : Nat)
  | ite (varIdx originalLow originalHigh : Nat)
  | guard (positive negative originalCore : Nat)
  deriving DecidableEq

structure NodeDesc where
  originalId : Nat
  raw : RawNode
  low : Nat
  high : Nat
  core : Nat
  support : Nat
  deriving DecidableEq

structure View where
  positive : Nat
  negative : Nat
  core : Nat
  deriving DecidableEq

structure OriginalView where
  positive : Nat
  negative : Nat
  core : Nat
  deriving DecidableEq
```

Dense node IDs are ordered by original source ID. `RawNode` retains the exact original descriptor fields and child IDs; `low/high/core` are the checked dense links (unused links are zero). `support` is copied from completed validation metadata and checked afresh. Node0 must be original node0 and constant0. Each active dense child is earlier, its original ID equals the raw child ID, and original IDs strictly increase. Constants, branches and guards retain their exact support/order/disjointness checks. No function meaning is supplied externally.

```lean
checkNodes (V nodeCount : Nat) (nodes : Nat → NodeDesc) : Bool
checkViews (V nodeCount : Nat) (nodes : Nat → NodeDesc)
  (viewCount : Nat) (views : Nat → View) : Bool

viewMeaning (V nodeCount : Nat) (nodes : Nat → NodeDesc) (view : View) : Weight
toOriginalView (nodes : Nat → NodeDesc) (view : View) : OriginalView
zeroView : View -- { positive := 0, negative := 0, core := 0 }
```

The internal node interpretation recurses on earlier dense IDs. A guard/view means its cube indicator times the core meaning, without an ordered-branch-prefix assumption. The semantic cube may use classical propositional choice; the finite descriptor and certificate checks remain executable Boolean functions. The ordinary allowed-axiom gate remains unchanged.

```lean
cofactorView (V nodeCount : Nat) (nodes : Nat → NodeDesc)
  (varIdx : Nat) (bit : Bool) (view : View) : Option View

cofactorView_sound
  (hnodes : checkNodes V nodeCount nodes = true)
  (h : cofactorView V nodeCount nodes varIdx bit view = some result) :
  cofactor varIdx bit (viewMeaning V nodeCount nodes view) =
    viewMeaning V nodeCount nodes result

zeroView_meaning (hnodes : checkNodes V nodeCount nodes = true) :
  viewMeaning V nodeCount nodes zeroView = constant 0
```

`cofactorView` checks the input view and local side conditions itself, and returns `none` for unsupported cases. The proof checker must not assume that the generator selected a least variable or a valid source branch.

## Completed zero-proof certificate

```lean
abbrev Goal := List (Int × Nat) -- coefficient, dense view ID
inductive Step where
  | empty
  | split (varIdx low high : Nat) -- earlier dense proof IDs
  deriving DecidableEq
structure ProofNode where
  goal : Goal
  step : Step
  deriving DecidableEq

checkProofs (V nodeCount : Nat) (nodes : Nat → NodeDesc)
  (viewCount : Nat) (views : Nat → View)
  (proofCount : Nat) (proofs : Nat → ProofNode) : Bool

checkProofs_sound
  (hnodes : checkNodes V nodeCount nodes = true)
  (hviews : checkViews V nodeCount nodes viewCount views = true)
  (hproofs : checkProofs V nodeCount nodes viewCount views proofCount proofs = true) :
  ∀ root, root < proofCount →
    SignedRelations.Zero
      (SignedRelations.combine
        (fun j => SignedRelations.lift (viewMeaning V nodeCount nodes (views j)))
        (proofs root).goal)
```

The sole selected terminal goal is literally empty. Splits check both cofactors, every occurrence, zero-view deletion and signed collection against the exact earlier child goals. The implementation may restrict goals to length at most4 and coefficients±1, which every selected goal satisfies. Source/proof/view defaults must not create an accepted out-of-bounds reference.

## Concrete conclusion and original binding

The generator extracts only completed proof metadata and the exact corresponding original raw descriptors. It emits866 dense source nodes,909 dense views and332 proof nodes, preserving original-node/proof maps and the sixteen selected original B tuples. Theorems expose `toOriginalView nodes selectedView = literalOriginalView` with the original core IDs and check the raw child/dense-link correspondence through `checkNodes`.

The four root states may be transported by a checked `List.Perm` to
`[(1,p),(-1,q),(-1,r),(1,s)]`, then passed directly to
`SignedBlockRewrite.nat_four_of_signed_zero` and
`SignedBlockRewrite.four_term_rewrite_of_signed_zero`.

This certificate proves four function identities and their signed block rewrites. It does not certify the adaptive basis algorithm, the exact rank31 independence argument, the full cut-to-count bridge, or a new queens count.
