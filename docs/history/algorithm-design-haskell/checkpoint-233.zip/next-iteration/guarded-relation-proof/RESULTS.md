# Four guarded identities accepted in Lean

The fresh `complete-07` gate accepted all four selected guarded-function identities and their natural and signed weighted consequences. It checked all eight mathematical modules in **28.01910592999775 seconds**, with peak child RSS **779,936 KiB**, under one cumulative 30-second deadline, one CPU and `-j1 -M1024`. No compiled experimental imports were reused. All **113 required axiom reports** passed with only `propext`, `Quot.sound` and `Classical.choice`.

The authoritative report is `attempts/complete-07/report.json`, SHA256 `7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`. `RESULTS.json` binds this report, the current sources and generator manifest, and the accepted logs. This is a certificate-checking milestone; it is not a new queens count.

## Exact accepted conclusions

The public namespace is `ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut`. Each `B j` denotes the internally defined natural-valued meaning of one selected guarded view.

| Relation | Natural equality, for every Boolean assignment | Saved ProofID | Dense root |
|---|---|---:|---:|
| 0 | B0 + B3 = B1 + B2 | 134 | 130 |
| 1 | B6 + B9 = B7 + B8 | 216 | 205 |
| 2 | B11 + B14 = B12 + B13 | 289 | 278 |
| 3 | B17 + B20 = B18 + B19 | 343 | 331 |

For each relation, `relationN_zero` proves the corresponding signed sum is zero for every assignment. `relationN_bound` conjoins that equality with four exact original `(positive mask, negative mask, core ID)` bindings. `relationN_nat` proves the natural equality above. `relationN_block` proves, for arbitrary integer-valued coefficient functions:

```text
Ap*Bp + Aq*Bq + Ar*Br + As*Bs
  = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br.
```

The subtraction is integer subtraction. No nonnegativity assumption for `Ap-As`, natural subtraction, or loss of overlapping contributions is hidden in this rewrite.

## What Lean checked

The certificate contains 866 source nodes, 909 guarded views and 332 proof nodes. Its data also records the 332 original ProofIDs and sixteen selected original-view tuples. All 2,439 ordered entries use direct balanced dispatch into literal pages of at most eight entries. Local size facts, offsets, defaults and exact original-view/root bindings are retained.

The root checks all original semantic predicates through 133 adjacent Boolean leaf checks of at most sixteen entries and 130 proved range joins. The global `nodes_checked`, `views_checked` and `proofs_checked` conclusions cover every in-bounds entry. The source checker validates earlier references, raw/dense child correspondence, support, variable order and guard conditions. The proof checker validates exact signed collection, both Boolean branches and earlier proof references; its only terminal rule requires an empty goal.

An external program found candidate relations and a proof graph. The generator merely extracted saved records and rendered literals. Lean independently validated their finite local conditions with ordinary `decide +kernel` proofs. The freshly checked generic soundness theorem then established each function equality by induction over the proof graph, for every assignment `Nat → Bool`. The external program's success status, sampled values, rank and file hashes are not logical premises. No native evaluator or external arithmetic answer replaces kernel checking.

## Resource result and representation change

The accepted data module took 9.45852695699432 seconds; the root theorem module took 15.164507017005235 seconds. All six generic modules were also rebuilt within the same 28.01910592999775-second gate. These are observed run times, not a future timing guarantee.

The successful revision changed only literal page size from 32 to eight. All ordered records and all semantic checks stayed the same. Compared with `complete-06`, the root source differs only in its two generator-hash comments. No checker refactor, pointwise range theorem, noncomputable annotation, changed leaf proof, or relaxed resource limit was introduced. The earlier rejected attempts and profiling evidence remain preserved.

## Remaining boundaries

The theorem is about the exact finite graph and selected views supplied to Lean. Original source labels make the extraction auditable, but label equality alone does not transfer semantics into another, larger table. Such transport requires matching constructors, constants and child references, followed by an agreement proof for the internal meanings.

Only the sixteen named B columns are specified by this certificate; the other cases of its total lookup use a default. No full rank31 theorem, proof of the adaptive basis algorithm, complete cut coverage, contraction completion, factor/source bridge, or new queens count follows from this gate. A source-linked contraction must still preserve every term and its multiplicity and bind these functions to its actual factors. The ultimate `cqueens 16 = 14772512` goal remains open.

## Recovery

Retain the eight accepted Lean sources, both current generators, `generation.json`, the gate controls, and the accepted report/logs. The three canonical discovery inputs named by the generation manifest permit regeneration; the extracted-record JSON can be regenerated from them. Neither native objects nor historical generation-manifest chains are required for a fresh recovery. This result note was written by reading and hashing existing evidence; it did not invoke Lean or rerun a semantic diagnostic.
