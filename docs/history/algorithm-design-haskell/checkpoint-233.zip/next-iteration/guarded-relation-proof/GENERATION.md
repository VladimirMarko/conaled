# Fixed guarded-relation certificate

The generator selects four completed zero proofs from the retained exact-basis transcript. It emits the literal tables and ordinary Lean theorems needed to check those identities for every Boolean assignment. The generator does not evaluate a guarded function, recompute a cofactor or support, normalize a relation, search for a proof, or calculate a rank.

**All four concrete identities and their signed block rewrites are now kernel-checked.** The `complete-07` combined gate passed in 28.01910592999775 seconds with peak child RSS 779,936 KiB. All eight mathematical modules were checked fresh under one cumulative 30-second deadline, one CPU and `-j1 -M1024`; no compiled experimental imports were reused. All 113 required axiom reports passed with only `propext`, `Quot.sound` and `Classical.choice`. The accepted data uses eight-entry pages. The exact result concerns the selected internally interpreted guarded functions; it proves no new queens count. See `RESULTS.md`, `RESULTS.json` and `attempts/complete-07/report.json`.

## Inputs and selection

The exact input paths, sizes and SHA256 identities are in `generation.json`. They are the original guarded trace, the completed basis work transcript, and its result summary. No copied input tree is needed.

The four original-column relations are:

| Columns | Signed identity | Saved root ProofID | Dense root |
|---|---|---:|---:|
| 0, 1, 2, 3 | B0 − B1 − B2 + B3 = 0 | 134 | 130 |
| 6, 7, 8, 9 | B6 − B7 − B8 + B9 = 0 | 216 | 205 |
| 11, 12, 13, 14 | B11 − B12 − B13 + B14 = 0 | 289 | 278 |
| 17, 18, 19, 20 | B17 − B18 − B19 + B20 = 0 | 343 | 331 |

Selection follows recorded proof-child references from these four roots. Source selection follows recorded validation dependencies from the sixteen corresponding original-view validations. The resulting closure has 332 proof nodes, 866 source nodes and 909 distinct guarded views. Exactly one selected proof is terminal; its normalized signed goal is literally empty. All remaining selected proofs split on a recorded Boolean variable and reference both completed child proofs.

Every source node retains its original ID and exact original constant, branch or guard fields. The dense child links are additional fields. Source nodes are sorted by original ID; proof nodes are sorted by original ProofID. These are identifier remappings, not semantic simplifications. The support masks and normalized goals are copied proposals that the Lean checks must independently validate.

`extracted-records.json` records the mappings and relevant original WorkIDs for review. It can be regenerated from the three bound inputs. It is not a Lean premise.

## Generated modules

`GeneratedGuardedData.lean` contains the three literal tables, total lookup functions, sixteen exact `OriginalView` literals, and checked equalities connecting those literals to the selected dense views. Each literal has at most eight entries. Balanced comparisons select the appropriate contiguous chunk, and the leaf reads that chunk at the original index minus its fixed offset. No checked lookup constructs a concatenated array. Each chunk has a local size fact; the aggregate count is the sum of those sizes. Original raw child IDs are separate from dense child indices. Array defaults are available only to make the lookup functions total; the semantic checks require all active references to be in bounds. Including the 332 original ProofID entries, all 2,439 ordered entries are preserved. This exact source passed in `complete-07`; the earlier 32-entry layout remains in its accepted attempt snapshots.

`GeneratedGuardedRelations.lean` checks the original node, view and proof predicates on adjacent ranges of at most sixteen entries, using ordinary `decide +kernel`. Proved range composition recovers the unchanged `checkNodes`, `checkViews` and `checkProofs` conclusions. There are 55, 57 and 21 leaf checks respectively, covering every index exactly once, plus a separate check of the distinguished original zero node. The proof combines them through proved adjacent-range lemmas; no external coverage list is a premise. It then applies the generic soundness theorem and a checked permutation of each root goal to expose the four original-column identities. Each `relationN_bound` theorem explicitly conjoins the four original-view bindings with its signed identity. These concrete root proofs all passed in the combined gate.

The root module applies the separately proved `SignedBlockRewrite` laws to derive each natural additive equality `Bp + Bs = Bq + Br`, and the exact signed weighted rewrite

    Ap*Bp + Aq*Bq + Ar*Br + As*Bs
      = (Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br.

The coefficient functions are arbitrary integer-valued functions. The difference is integer subtraction; no unproved nonnegativity condition or truncated natural subtraction is used.

## Trust and limits

The internally defined meaning of a node follows the guarded source constructors. The source checker validates prior dense references, original-ID correspondence, supports, variable order and guard conditions. The proof checker validates both cofactor branches and exact signed collection. External transcript outcomes and SHA256 bindings guide extraction and provenance; they are not hypotheses of the Lean identities.

The trust transfer has three concrete stages. First, the external search and generator propose literal descriptors and a finite proof graph. Second, `decide +kernel` produces ordinary proof terms for the closed Boolean checks, whose computation is validated by Lean's kernel; no external success flag, sampled function value, expected count or native evaluator result is accepted as a proof. Third, the generic soundness theorem—also checked fresh in this gate—uses those checked conditions and induction over the prior proof references to establish the signed equality for every Boolean assignment. Both branches are checked at every split. The final natural equality and weighted integer rewrite follow from separately proved algebraic laws.

This establishes equality for the exact finite graph supplied to Lean. The original-ID fields and sixteen tuple equalities identify that graph's selected views, but equal labels alone do not establish semantic agreement with a future larger table. Transport into such a table still needs exact constructor/child correspondence and an inductive agreement theorem. The retained byte comparisons make the extraction auditable; file hashes are not logical premises.

This certificate does not formalize the adaptive basis discovery, prove the full rank31 conclusion, connect these four source-view identities to a newly completed contraction, or prove any new queens count. The complete cut coverage and factor/source lineage remain separate obligations before a counting algorithm can use the rewrite. Selecting only the four zero-proof closures reduces verification data; it does not erase the 29,360 requests used by the completed discovery experiment.

## Regeneration

Starting with an empty generation output set, run `python generate_guarded_relations.py`, followed by `python generate_guarded_checks.py`. The first program verifies the three fixed input hashes and emits the current literal layout and an initial whole-table root. The second verifies those exact bytes, preserves the data and extracted records, and replaces only the root's whole-table proof evaluation with adjacent-range proof composition. Both programs refuse an unexpected source state. The final `generation.json` directly binds both current generators, current outputs, the range helper and the canonical inputs. There is no dependency on a historical generation report. Neither program invokes Lean or evaluates a semantic predicate.

For a compact recovery checkpoint, retain both current generators, generated Lean sources, generic helper sources, final fresh-gate controls/report and this note. The extraction JSON is optional if the canonical input transcript and generators are retained. No historical input/source snapshots, compilation objects or authoring patches are required for that recovery set.

The first concrete gate, `attempts/complete-01`, rejected the flat-array representation at Lean's default elaboration recursion-depth limit. The second, `complete-02`, timed out while checking the data module with appended-array lookups. Direct lookup in `complete-03` was substantially cheaper, but full 128-entry chunk size proofs still exceeded the default recursion depth. The 32-entry data module passed in `complete-04`; its root then exceeded the fixed kernel memory bound while reducing each whole-table check. `complete-05` and `complete-06` stayed within memory but timed out with no root axiom output captured. Empty logs do not establish the exact internal stopping point. These attempts and their source snapshots remain intact.

The successful change reduced only the literal page size from 32 to eight. The root source is identical to `complete-06` apart from its two generator-hash comments: the same 133 sixteen-entry leaf checks, 130 adjacent-range joins, explicit predicate/table/index arguments, checker prints, public Boolean conclusions and four identity statements remain required. No Boolean-checker refactor, pointwise range theorem, noncomputable annotation or alternative leaf proof was introduced. The extracted-record JSON remains byte-identical. The independent eight-entry layout comparison passed, followed by `complete-07` with all eight mathematical modules, data, local ranges and final roots inside **one cumulative 30-second gate**. Individual ranges received no separate processes or time budgets. No recursion, time or memory limit was raised. The accepted mathematical sources, generators and generation manifest are frozen.
