# Development outcomes

This concise record replaces failed-attempt trees in future durability
checkpoints. The working directory still retains those trees. A failed run is
never evidence for an accepted theorem.

| Attempt | Outcome | Relevant finding |
| --- | --- | --- |
| `rewrite-01` | Passed; 1.181573675 s | Generic signed four-term rewrite and projection/context transfer, with all three sources rebuilt. |
| `source-01` | Failed; 1.188621866 s | Reserved binder name, Boolean-expression precedence and proof-script/linter issues. |
| `source-02` | Failed; 1.572542731 s | Remaining dependent-if simplification and function-extensionality proof scripts. |
| `source-03` | Passed; 1.562608906 s | Internal guarded-source semantics, validation and cofactor soundness. |
| `checker-01` | Failed; 2.508125265 s | Two recursive-definition unfoldings and one unavailable congruence helper. |
| `checker-02` | Passed; 2.714958261 s | Generic signed certificate checker, with all four sources rebuilt. |
| `complete-01` | Failed; 10.755206562 s | All generic modules passed. Large concrete array literals and size proofs reached the default elaborator recursion-depth limit; the concrete root module was not reached. |
| `complete-02` | Failed; 30.028208615 s | The chunked data preserved every literal, but processing the data module exhausted the cumulative wall budget. The root module was not reached. Peak child RSS was 1,050,288 KiB. |
| `complete-03` | Failed; 9.238032614 s | Direct lookup made the data module cheaper, but the local 128-entry size proofs still hit the default elaborator recursion-depth limit. All original view and proof-root bindings checked. |
| `complete-04` | Failed; 14.490730271 s | Direct 32-entry chunks passed the entire data module. The three monolithic kernel table checks in the root module exceeded the existing memory limit. |
| `table-01` | Passed; 2.954760555 s | Five fresh modules, including complete adjacent-range coverage and wrappers restoring all three unchanged checker booleans. |
| `complete-05` | Failed; 30.024124927 s | Local 16-entry checks avoided the memory failure (698,060 KiB peak overall), but the cumulative wall gate stopped before the first full-table result printed. |
| `complete-06` | Failed; 30.021577614 s | Explicit range parameters did not resolve the timeout. All seven preceding modules passed; the final module's log remained empty when the gate stopped. Peak child RSS was 697,180 KiB. |
| `profile01` | Failed; 30.026066213 s | Standard stream unbuffering alone did not expose command-local timings because Lean also captures diagnostic streams. No mathematical source changed. |
| `profile02` | Failed; 30.029630977 s | Disabling diagnostic stream capture exposed 132 completed kernel-checking scopes. Their sequence and page-position pattern supported repeated logical table lookup as the next target. |
| `complete-07` | Passed; 28.019105930 s | Direct 8-entry pages preserve all data and all check predicates. All eight modules, all four concrete identities and signed rewrites, and 113 axiom reports passed one fresh cumulative gate. Peak child RSS was 779,936 KiB. |

The response to `complete-01` is a representation change: bounded array chunks
with a balanced append tree and explicit size lemmas, preserving the complete
ordered data. No recursion limit, wall-time allowance, memory limit, counting
cap or trust boundary is increased. This does not perform new arithmetic
search, cofactoring, function evaluation or basis discovery.

The next representation correction removes concatenated arrays from the lookup
path: lookups select the required literal chunk directly. Independent review
must again verify complete ordered data and original bindings. This targets
the cost of checking the fixed certificate, without changing its mathematics.

After `complete-04`, the remaining change is bounded local table-check lemmas
with a generic complete-range coverage proof. Every node, view and proof step
still has to be checked. All selected modules and local lemmas share one
cumulative 30-second fresh gate; there are no separate time allowances for
pieces of the certificate and no increase of the memory limit. This is a
proof-term organization change, not another counting run or a partition of
enumeration into independent budgets.

The next proof-script correction makes the test, start and both lengths
explicit at every range composition. This avoids asking the elaborator to
infer range lengths through a reducible Boolean computation. Selected first
and last local checks print their axiom dependencies to locate any remaining
cost. This is a hypothesis about the observed timeout, not a demonstrated
speedup before the next complete gate.

`complete-06` did not establish that proposed speedup. The subsequent inspection
found existing kernel reduction for the relevant Nat bitwise operations. It also
found Lean's command-local diagnostic capture, which explains why standard
stream unbuffering alone was insufficient. The useful second profile exposed
anonymous timings. The strongest alignment is 55 node leaves, 57 view leaves,
and 20 proof leaves. Every second 16-entry half of a full 32-entry node or view
page was slower than its first half. Logical array lookup traverses a list in
the pinned Lean definitions, making a smaller literal page a specific
optimization candidate.

An earlier provisional attribution of the expensive tail to range joins was
withdrawn. `decide +kernel` uses a cached auxiliary lemma; two declaration
insertions do not imply two expensive logged decision computations. The
thresholded profile did not name individual declarations, so the leaf mapping
remains an inference supported by its boundary and page-position pattern.

The only mathematical-source representation change for `complete-07` was
32-entry to 8-entry literal pages. Independent review compared all 2,439
ordered entries (including original proof IDs), 307 page intervals, defaults,
sizes, original bindings, 133 leaf predicates and 130 joins. All six generic
sources were unchanged. The successful full gate now supersedes the component
gates as acceptance evidence for this source closure. Its report SHA256 is
`7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`.
No resource limit or trust boundary was increased. This completed milestone
did not run another basis search or prove a whole-board count. The historical
steps above explain the successive corrections; they are not pending work.

Compiler-generated `sorryAx` entries in failed elaboration logs are rejected
by the gate. They are not admitted source proofs or accepted theorem evidence.
The successful final gate rebuilt every selected generic and concrete module
together, within the original cumulative 30-second allowance.
