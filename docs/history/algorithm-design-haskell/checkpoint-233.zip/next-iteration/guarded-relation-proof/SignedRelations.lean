import ArithmeticSemantics
import Init.Data.Int.Lemmas

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Signed linear relations between natural-valued assignment functions.
Boolean splitting here proves a pointwise identity. It is distinct from
projection, which sums both assignments and retains their multiplicities.
The DAG theorem has explicit local semantic premises; this module does not
implement a concrete source-descriptor or serialized-certificate checker.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations

abbrev Value := Assignment → Int

def zero : Value := fun _ => 0
def addValue (f g : Value) : Value := fun σ => f σ + g σ
def lift (f : Weight) : Value := fun σ => (f σ : Int)
def restrict (v : Nat) (b : Bool) (f : Value) : Value :=
  fun σ => f (setVar σ v b)
def Zero (f : Value) : Prop := ∀ σ, f σ = 0

theorem zero_zero : Zero zero := by intro σ; rfl

theorem zero_of_eq {f g : Value} (h : f = g) (hg : Zero g) : Zero f := by
  simpa only [h] using hg

theorem restrict_zero (v : Nat) (b : Bool) : restrict v b zero = zero := rfl

theorem restrict_add (v : Nat) (b : Bool) (f g : Value) :
    restrict v b (addValue f g) = addValue (restrict v b f) (restrict v b g) := rfl

theorem lift_restrict (v : Nat) (b : Bool) (f : Weight) :
    lift (cofactor v b f) = restrict v b (lift f) := rfl

theorem lift_add (f g : Weight) : lift (add f g) = addValue (lift f) (lift g) := by
  funext σ
  simp [lift, add, addValue]

theorem lift_injective {f g : Weight} (h : lift f = lift g) : f = g := by
  funext σ
  exact Int.ofNat_inj.mp (congrFun h σ)

theorem zero_lift_iff (f : Weight) : Zero (lift f) ↔ ∀ σ, f σ = 0 := by
  simp [Zero, lift]

theorem zero_split (v : Nat) (f : Value)
    (hl : Zero (restrict v false f)) (hr : Zero (restrict v true f)) : Zero f := by
  intro σ
  have h : restrict v (σ v) f σ = 0 := by
    cases σ v with
    | false => exact hl σ
    | true => exact hr σ
  simpa only [restrict, setVar_restore] using h

theorem zero_restrict {f : Value} (h : Zero f) (v : Nat) (b : Bool) :
    Zero (restrict v b f) := by
  intro σ
  exact h (setVar σ v b)

def combine {ι : Type} (meaning : ι → Value) : List (Int × ι) → Value
  | [] => zero
  | (coefficient, index) :: terms =>
      fun σ => coefficient * meaning index σ + combine meaning terms σ

theorem combine_nil {ι : Type} (meaning : ι → Value) :
    combine meaning [] = zero := rfl

theorem combine_append {ι : Type} (meaning : ι → Value) (xs ys : List (Int × ι)) :
    combine meaning (xs ++ ys) = addValue (combine meaning xs) (combine meaning ys) := by
  induction xs with
  | nil => funext σ; simp [combine, zero, addValue]
  | cons term terms ih =>
    rcases term with ⟨c, i⟩
    funext σ
    simp [combine, ih, addValue, Int.add_assoc]

theorem combine_perm {ι : Type} (meaning : ι → Value) {xs ys : List (Int × ι)}
    (h : xs.Perm ys) : combine meaning xs = combine meaning ys := by
  induction h with
  | nil => rfl
  | cons term h ih =>
    rcases term with ⟨c, i⟩
    funext σ
    simp only [combine, ih]
  | swap a b terms =>
    rcases a with ⟨c, i⟩
    rcases b with ⟨d, j⟩
    funext σ
    simp [combine, Int.add_left_comm]
  | trans _ _ ih₁ ih₂ => exact ih₁.trans ih₂

theorem combine_zero_coefficient {ι : Type} (meaning : ι → Value)
    (i : ι) (terms : List (Int × ι)) :
    combine meaning ((0, i) :: terms) = combine meaning terms := by
  funext σ
  simp [combine]

theorem combine_merge {ι : Type} (meaning : ι → Value)
    (c d : Int) (i : ι) (terms : List (Int × ι)) :
    combine meaning ((c, i) :: (d, i) :: terms) =
      combine meaning ((c + d, i) :: terms) := by
  funext σ
  simp [combine, Int.add_mul, Int.add_assoc]

theorem combine_cancel {ι : Type} (meaning : ι → Value)
    (c : Int) (i : ι) (terms : List (Int × ι)) :
    combine meaning ((c, i) :: (-c, i) :: terms) = combine meaning terms := by
  rw [combine_merge, Int.add_right_neg, combine_zero_coefficient]

theorem combine_restrict {ι : Type} (meaning : ι → Value)
    (terms : List (Int × ι)) (v : Nat) (b : Bool) :
    restrict v b (combine meaning terms) =
      combine (fun i => restrict v b (meaning i)) terms := by
  induction terms with
  | nil => rfl
  | cons term terms ih =>
    rcases term with ⟨c, i⟩
    funext σ
    have hs := congrFun ih σ
    simpa only [combine, restrict] using congrArg (fun n => c * meaning i (setVar σ v b) + n) hs

theorem combine_congr {ι : Type} {first second : ι → Value}
    (terms : List (Int × ι))
    (h : ∀ term ∈ terms, first term.2 = second term.2) :
    combine first terms = combine second terms := by
  induction terms with
  | nil => rfl
  | cons term terms ih =>
    rcases term with ⟨c, i⟩
    have hh := h (c, i) (by simp)
    have ht := ih (fun term ht => h term (by simp [ht]))
    funext σ
    simp only [combine, hh, ht]

theorem combine_transport {ι κ : Type} (first : ι → Value) (second : κ → Value)
    (route : ι → κ) (terms : List (Int × ι))
    (h : ∀ term ∈ terms, first term.2 = second (route term.2)) :
    combine first terms = combine second (terms.map (fun term => (term.1, route term.2))) := by
  induction terms with
  | nil => rfl
  | cons term terms ih =>
    rcases term with ⟨c, i⟩
    have hh := h (c, i) (by simp)
    have ht := ih (fun term ht => h term (by simp [ht]))
    funext σ
    simp only [List.map_cons, combine, hh, ht]

theorem combine_terminal {ι : Type} (meaning : ι → Value) (values : ι → Int)
    (terms : List (Int × ι))
    (h : ∀ term ∈ terms, ∀ σ, meaning term.2 σ = values term.2) :
    ∀ σ, combine meaning terms σ =
      (terms.map (fun term => term.1 * values term.2)).foldr (fun x total => x + total) 0 := by
  induction terms with
  | nil => intro σ; rfl
  | cons term terms ih =>
    rcases term with ⟨c, i⟩
    intro σ
    have hh := h (c, i) (by simp) σ
    have ht := ih (fun term ht => h term (by simp [ht])) σ
    simp only [combine, List.map_cons, List.foldr_cons, hh, ht]

theorem nat_equality_of_signed_pair {ι : Type} (meaning : ι → Weight) (i j : ι)
    (h : Zero (combine (fun k => lift (meaning k)) [(1, i), (-1, j)])) :
    meaning i = meaning j := by
  apply lift_injective
  funext σ
  apply Int.sub_eq_zero.mp
  simpa [combine, zero, Int.sub_eq_add_neg] using h σ

def sumOutValue (v : Nat) (f : Value) : Value :=
  addValue (restrict v false f) (restrict v true f)

def project : List Nat → Value → Value
  | [], f => f
  | v :: vs, f => project vs (sumOutValue v f)

theorem lift_sumOut (v : Nat) (f : Weight) :
    lift (sumOut v f) = sumOutValue v (lift f) := by
  rw [sumOut, lift_add, lift_restrict, lift_restrict]
  rfl

theorem lift_sumVars (vs : List Nat) (f : Weight) :
    lift (sumVars vs f) = project vs (lift f) := by
  induction vs generalizing f with
  | nil => rfl
  | cons v vs ih =>
    simp only [sumVars, project, ih, lift_sumOut]

theorem sumOutValue_zero (v : Nat) : sumOutValue v zero = zero := by
  funext σ
  simp [sumOutValue, addValue, restrict, zero]

theorem project_zero (vs : List Nat) : project vs zero = zero := by
  induction vs with
  | nil => rfl
  | cons v vs ih => simp only [project, sumOutValue_zero, ih]

theorem nat_projection_eq {f g : Weight} (h : lift f = lift g) (vs : List Nat) :
    sumVars vs f = sumVars vs g := by
  apply lift_injective
  simp only [lift_sumVars, h]

inductive Step where
  | zero
  | reuse (previous : Nat)
  | split (v low high : Nat)

def ValidAt (goals : Nat → Value) (index : Nat) : Step → Prop
  | .zero => Zero (goals index)
  | .reuse previous => previous < index ∧ goals index = goals previous
  | .split v low high =>
      low < index ∧ high < index ∧
      restrict v false (goals index) = goals low ∧
      restrict v true (goals index) = goals high

theorem earlier_dag_sound (count : Nat) (goals : Nat → Value) (steps : Nat → Step)
    (valid : ∀ index, index < count → ValidAt goals index (steps index)) :
    ∀ index, index < count → Zero (goals index) := by
  intro index
  induction index using Nat.strongRecOn with
  | ind index ih =>
    intro hi
    have hv := valid index hi
    cases hs : steps index with
    | zero => simpa only [hs, ValidAt] using hv
    | reuse previous =>
      rcases (show previous < index ∧ goals index = goals previous from
        by simpa only [hs, ValidAt] using hv) with ⟨hlt, heq⟩
      exact zero_of_eq heq (ih previous hlt (Nat.lt_trans hlt hi))
    | split v low high =>
      rcases (show low < index ∧ high < index ∧
          restrict v false (goals index) = goals low ∧
          restrict v true (goals index) = goals high from
        by simpa only [hs, ValidAt] using hv) with ⟨hl, hr, hlow, hhigh⟩
      apply zero_split v
      · exact zero_of_eq hlow (ih low hl (Nat.lt_trans hl hi))
      · exact zero_of_eq hhigh (ih high hr (Nat.lt_trans hr hi))

end ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.zero_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.zero_of_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.restrict_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.restrict_add
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.lift_restrict
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.lift_add
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.lift_injective
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.zero_lift_iff
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.zero_split
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.zero_restrict
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_nil
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_append
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_perm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_zero_coefficient
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_merge
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_cancel
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_restrict
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_congr
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_transport
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.combine_terminal
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.nat_equality_of_signed_pair
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.lift_sumOut
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.lift_sumVars
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.sumOutValue_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.project_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.nat_projection_eq
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.SignedRelations.earlier_dag_sound
