#!/usr/bin/env python3
"""Replace whole-table proof evaluation with fixed adjacent range proofs.

This is a Lean source transformation only.  It does not evaluate a table
predicate, guarded function, cofactor, signed state or certificate rule.
This stage preserves the exact data emitted by the pinned data generator.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LEAF_SIZE = 16
NAMESPACE = "ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut"
BASE_ROOT_SHA = "eff7ac12bdb53eb060ede586ab39fa8cdf70504a74b9aaf99f38d4f7389a3fe6"
DATA_SHA = "3789f270ab96f4b4af0b7da64863ab8586c042dba4b8390205381b643836fd92"
RECORDS_SHA = "71d0d13c5e9bf971288bde9ce0cfd391a56505025bedf454038c1fe0494795d8"
DATA_GENERATOR_SHA = "52a2da29956b41b1c66110d8230351c6e7216c544738a162eb2e771b3b7a88a9"
HELPER_SHA = "b5d29eaa031b3fdff7bdd8bd4e0683f8aa1803f892dab7460b8ec160b0e5c297"
INPUT_SHAS = {
    "work": "52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6",
    "results": "59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb",
    "source": "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def binding(path: Path) -> dict:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size, "sha256": digest}


def replace_once(text: str, before: str, after: str) -> str:
    require(text.count(before) == 1, "fixed source fragment missing or duplicated")
    return text.replace(before, after, 1)


def range_proofs(prefix: str, predicate: str, count: int) -> tuple[str, str, dict]:
    """Render literal intervals and exact adjacent-range composition proofs."""
    lines = []
    leaves = []
    joins = []
    for start in range(0, count, LEAF_SIZE):
        length = min(LEAF_SIZE, count - start)
        name = f"{prefix}_range_{start}_{length}"
        lines += [f"theorem {name} : checkRange ({predicate}) {start} {length} = true := by",
                  "  decide +kernel", ""]
        if start == 0 or start + length == count:
            lines += [f"#print axioms {NAMESPACE}.{name}", ""]
        leaves.append((start, length, name))

    # Keep the renderer explicitly separate from any table-predicate evaluator.
    def append_composition(parts: list[tuple[int, int, str]]) -> tuple[int, int, str]:
        if len(parts) == 1:
            return parts[0]
        middle = len(parts) // 2
        left = append_composition(parts[:middle])
        right = append_composition(parts[middle:])
        require(left[0] + left[1] == right[0], "generated ranges are not adjacent")
        start, length = left[0], left[1] + right[1]
        name = f"{prefix}_range_{start}_{length}"
        lines.extend([f"theorem {name} : checkRange ({predicate}) {start} {length} = true :=",
                      f"  checkRange_append (test := {predicate}) (start := {start})",
                      f"    (left := {left[1]}) (right := {right[1]}) {left[2]} {right[2]}", ""])
        joins.append((start, length, left[2], right[2]))
        return start, length, name

    total = append_composition(leaves)
    require(total[:2] == (0, count), "generated ranges do not cover the full table")
    return "\n".join(lines), total[2], {
        "count": count, "leaf_size": LEAF_SIZE, "leaf_count": len(leaves),
        "join_count": len(joins), "start": 0, "end_exclusive": count,
    }


def main() -> None:
    target = HERE / "GeneratedGuardedRelations.lean"
    data = HERE / "GeneratedGuardedData.lean"
    records = HERE / "extracted-records.json"
    data_generator = HERE / "generate_guarded_relations.py"
    helper = HERE / "TableCheck.lean"
    report_path = HERE / "generation.json"
    for path, expected in ((target, BASE_ROOT_SHA), (data, DATA_SHA), (records, RECORDS_SHA),
                           (data_generator, DATA_GENERATOR_SHA), (helper, HELPER_SHA)):
        require(binding(path)["sha256"] == expected, "fixed source identity differs: " + path.name)
    report = json.loads(report_path.read_text())
    for key, expected in INPUT_SHAS.items():
        item = report["inputs"][key]
        require(item["sha256"] == expected and binding(ROOT / item["path"]) == item,
                "fixed canonical input differs: " + key)
    for item in report["outputs"]:
        require(binding(ROOT / item["path"]) == item, "base generation output differs")

    generator = binding(Path(__file__).resolve())
    text = target.read_text()
    text = replace_once(text, "import GuardedRelationChecker\n", "import GuardedRelationChecker\nimport TableCheck\n")
    text = replace_once(text, "open SignedRelations SignedBlockRewrite\n", "open SignedRelations SignedBlockRewrite TableCheck\n")
    text = replace_once(text, f"Generator SHA256: {DATA_GENERATOR_SHA}",
                        f"Data generator SHA256: {DATA_GENERATOR_SHA}\nRange-check generator SHA256: {generator['sha256']}")
    ranges = {}
    node_checks, node_total, ranges["nodes"] = range_proofs("nodes", "checkNode 210 866 nodes", 866)
    view_checks, view_total, ranges["views"] = range_proofs("views", "fun i => checkView 210 866 nodes (views i)", 909)
    proof_checks, proof_total, ranges["proofs"] = range_proofs("proofs", "checkProofAt 210 866 nodes 909 views proofs", 332)
    text = replace_once(text,
        "theorem nodes_checked : checkNodes 210 866 nodes = true := by\n  decide +kernel\n",
        node_checks + "\n" +
        "theorem node_zero_checked : 0 < 866 ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0 := by\n  decide +kernel\n\n" +
        "theorem nodes_checked : checkNodes 210 866 nodes = true :=\n" +
        "  checkNodes_of_range (V := 210) (nodeCount := 866) (nodes := nodes)\n" +
        f"    node_zero_checked {node_total}\n")
    text = replace_once(text,
        "theorem views_checked : checkViews 210 866 nodes 909 views = true := by\n  decide +kernel\n",
        view_checks + "\n" +
        "theorem views_checked : checkViews 210 866 nodes 909 views = true :=\n" +
        "  checkViews_of_range (V := 210) (nodeCount := 866) (viewCount := 909)\n" +
        f"    (nodes := nodes) (views := views) {view_total}\n")
    text = replace_once(text,
        "theorem proofs_checked : checkProofs 210 866 nodes 909 views 332 proofs = true := by\n  decide +kernel\n",
        proof_checks + "\n" +
        "theorem proofs_checked : checkProofs 210 866 nodes 909 views 332 proofs = true :=\n" +
        "  checkProofs_of_range (V := 210) (nodeCount := 866) (viewCount := 909) (proofCount := 332)\n" +
        f"    (nodes := nodes) (views := views) (proofs := proofs) {proof_total}\n")

    target.write_text(text)
    require(binding(data)["sha256"] == DATA_SHA and binding(records)["sha256"] == RECORDS_SHA,
            "pinned data or extracted records changed")
    report.update({
        "format": "fixed-guarded-relation-generation-v7",
        "root_generator": generator, "root_checker_helper": binding(helper),
        "base_root_sha256": BASE_ROOT_SHA,
        "outputs": [binding(records), binding(data), binding(target)],
        "table_checks": ranges,
        "range_proof_elaboration": "Every join and whole-table wrapper has explicit predicate, index and table parameters; first and last leaves are printed for each table.",
        "resource_scope": "All generic sources, all ranges, data and roots must pass one fresh cumulative30s one-CPU -M1024 gate; ranges are not separate resource budgets.",
        "scope": "Saved-record data plus proof-source range composition only. Every original table predicate and public checker conclusion is unchanged. No semantic recomputation or Lean invocation by either generator.",
    })
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "generated_unchecked", "ranges": ranges,
                      "root": binding(target), "generation": binding(report_path)}, sort_keys=True))


if __name__ == "__main__":
    main()
