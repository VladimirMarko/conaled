import ArithmeticSemantics
import Init.Data.Nat.Bitwise.Lemmas

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

namespace ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations

inductive RawNode where
  | constant (value : Nat)
  | ite (varIdx originalLow originalHigh : Nat)
  | guard (positive negative originalCore : Nat)
  deriving DecidableEq

structure NodeDesc where
  originalId : Nat
  raw : RawNode
  low : Nat
  high : Nat
  core : Nat
  support : Nat
  deriving DecidableEq

structure View where
  positive : Nat
  negative : Nat
  core : Nat
  deriving DecidableEq

structure OriginalView where
  positive : Nat
  negative : Nat
  core : Nat
  deriving DecidableEq

def toOriginalView (nodes : Nat → NodeDesc) (view : View) : OriginalView :=
  ⟨view.positive, view.negative, (nodes view.core).originalId⟩

def zeroView : View := ⟨0, 0, 0⟩

def isGuard : RawNode → Bool
  | .guard _ _ _ => true
  | _ => false

def Holds (positive negative : Nat) (σ : Assignment) : Prop :=
  ∀ v, (positive.testBit v = true → σ v = true) ∧
    (negative.testBit v = true → σ v = false)

/-- The guard is a conjunction of literals, not an ordered branch prefix.
Only this semantic indicator uses classical decidability. All finite source
and certificate checks below are executable Boolean functions. -/
noncomputable def cube (positive negative : Nat) : Weight := by
  classical
  exact fun σ => if Holds positive negative σ then 1 else 0

theorem cube_congr {p n q r : Nat} {σ τ : Assignment}
    (h : Holds p n σ ↔ Holds q r τ) : cube p n σ = cube q r τ := by
  classical
  simp only [cube]
  rw [h]

theorem cube_zero : cube 0 0 = constant 1 := by
  classical
  funext σ
  have h : Holds 0 0 σ := by simp [Holds]
  simp [cube, h, constant]

theorem bit_or_left {a b i : Nat} (h : a.testBit i = true) :
    (a ||| b).testBit i = true := by simp [h]

theorem bit_or_right {a b i : Nat} (h : b.testBit i = true) :
    (a ||| b).testBit i = true := by simp [h]

theorem holds_or (p n q r : Nat) (σ : Assignment) :
    Holds (p ||| q) (n ||| r) σ ↔ Holds p n σ ∧ Holds q r σ := by
  constructor
  · intro h
    exact ⟨fun v => ⟨fun hp => (h v).1 (bit_or_left hp),
      fun hn => (h v).2 (bit_or_left hn)⟩,
      fun v => ⟨fun hq => (h v).1 (bit_or_right hq),
      fun hr => (h v).2 (bit_or_right hr)⟩⟩
  · rintro ⟨hleft, hright⟩ v
    constructor
    · intro h
      rcases Bool.or_eq_true_iff.mp (by simpa only [Nat.testBit_or] using h) with hp | hq
      · exact (hleft v).1 hp
      · exact (hright v).1 hq
    · intro h
      rcases Bool.or_eq_true_iff.mp (by simpa only [Nat.testBit_or] using h) with hn | hr
      · exact (hleft v).2 hn
      · exact (hright v).2 hr

theorem cube_or (p n q r : Nat) :
    cube (p ||| q) (n ||| r) = mul (cube p n) (cube q r) := by
  classical
  funext σ
  simp only [cube, mul, holds_or]
  by_cases hp : Holds p n σ <;> by_cases hq : Holds q r σ <;> simp [hp, hq]

theorem cube_contradiction {p n : Nat} (h : p &&& n ≠ 0) : cube p n = constant 0 := by
  classical
  funext σ
  have hnot : ¬ Holds p n σ := by
    intro hh
    apply h
    apply Nat.eq_of_testBit_eq
    intro v
    have ht : (p.testBit v && n.testBit v) = false := by
      cases hp : p.testBit v with
      | false => rfl
      | true =>
        cases hn : n.testBit v with
        | false => rfl
        | true => exact ((hh v).1 hp).symm.trans ((hh v).2 hn)
    simpa only [Nat.testBit_and, Nat.zero_testBit] using ht
  simp [cube, hnot, constant]

def eraseBit (mask varIdx : Nat) : Nat :=
  if mask.testBit varIdx then mask ^^^ 2 ^ varIdx else mask

theorem eraseBit_of_false {mask varIdx : Nat} (h : mask.testBit varIdx = false) :
    eraseBit mask varIdx = mask := by simp [eraseBit, h]

theorem testBit_eraseBit (mask varIdx index : Nat) :
    (eraseBit mask varIdx).testBit index =
      if index = varIdx then false else mask.testBit index := by
  by_cases hi : index = varIdx
  · subst index
    cases h : mask.testBit varIdx <;>
      simp [eraseBit, h, Nat.testBit_xor]
  · have hn : varIdx ≠ index := Ne.symm hi
    cases h : mask.testBit varIdx <;>
      simp [eraseBit, h, Nat.testBit_xor, hi, hn]

theorem holds_setVar (p n v : Nat) (b : Bool) (σ : Assignment) :
    Holds p n (setVar σ v b) ↔
      (p.testBit v = true → b = true) ∧
      (n.testBit v = true → b = false) ∧ Holds (eraseBit p v) (eraseBit n v) σ := by
  constructor
  · intro h
    refine ⟨?_, ?_, ?_⟩
    · simpa only [setVar_same] using (h v).1
    · simpa only [setVar_same] using (h v).2
    · intro w
      by_cases hw : w = v
      · subst w
        simp [testBit_eraseBit]
      · constructor
        · intro hp
          have hp' : p.testBit w = true := by simpa only [testBit_eraseBit, if_neg hw] using hp
          simpa only [setVar_other σ v w b hw] using (h w).1 hp'
        · intro hn
          have hn' : n.testBit w = true := by simpa only [testBit_eraseBit, if_neg hw] using hn
          simpa only [setVar_other σ v w b hw] using (h w).2 hn'
  · rintro ⟨hp, hn, hrest⟩ w
    by_cases hw : w = v
    · subst w
      simpa only [setVar_same] using And.intro hp hn
    · constructor
      · intro h
        have hh : (eraseBit p v).testBit w = true := by
          simpa only [testBit_eraseBit, if_neg hw] using h
        simpa only [setVar_other σ v w b hw] using (hrest w).1 hh
      · intro h
        have hh : (eraseBit n v).testBit w = true := by
          simpa only [testBit_eraseBit, if_neg hw] using h
        simpa only [setVar_other σ v w b hw] using (hrest w).2 hh

theorem cube_cofactor_good {p n v : Nat} {b : Bool}
    (hp : p.testBit v = true → b = true)
    (hn : n.testBit v = true → b = false) :
    cofactor v b (cube p n) = cube (eraseBit p v) (eraseBit n v) := by
  funext σ
  apply cube_congr
  rw [holds_setVar]
  exact ⟨fun h => h.2.2, fun h => ⟨hp, hn, h⟩⟩

theorem cube_cofactor_bad_positive {p n v : Nat} (hp : p.testBit v = true) :
    cofactor v false (cube p n) = constant 0 := by
  classical
  funext σ
  have hn : ¬ Holds p n (setVar σ v false) := by
    intro h
    have bad := (h v).1 hp
    simp at bad
  simp [cofactor, cube, hn, constant]

theorem cube_cofactor_bad_negative {p n v : Nat} (hn : n.testBit v = true) :
    cofactor v true (cube p n) = constant 0 := by
  classical
  funext σ
  have hp : ¬ Holds p n (setVar σ v true) := by
    intro h
    have bad := (h v).2 hn
    simp at bad
  simp [cofactor, cube, hp, constant]

theorem cube_cofactor_absent {p n v : Nat} (b : Bool)
    (hp : p.testBit v = false) (hn : n.testBit v = false) :
    cofactor v b (cube p n) = cube p n := by
  rw [cube_cofactor_good (by simp [hp]) (by simp [hn]),
    eraseBit_of_false hp, eraseBit_of_false hn]

def MaskSupported (mask : Nat) (f : Weight) : Prop :=
  ∀ σ τ, (∀ v, mask.testBit v = true → σ v = τ v) → f σ = f τ

theorem mask_supported_constant (mask value : Nat) : MaskSupported mask (constant value) := by
  intro σ τ h
  rfl

theorem mask_supported_cube (p n : Nat) : MaskSupported (p ||| n) (cube p n) := by
  intro σ τ hagree
  apply cube_congr
  constructor
  · intro h v
    constructor
    · intro hp
      exact (hagree v (bit_or_left hp)).symm.trans ((h v).1 hp)
    · intro hn
      exact (hagree v (bit_or_right hn)).symm.trans ((h v).2 hn)
  · intro h v
    constructor
    · intro hp
      exact (hagree v (bit_or_left hp)).trans ((h v).1 hp)
    · intro hn
      exact (hagree v (bit_or_right hn)).trans ((h v).2 hn)

theorem mask_supported_mul {s t : Nat} {f g : Weight}
    (hf : MaskSupported s f) (hg : MaskSupported t g) :
    MaskSupported (s ||| t) (mul f g) := by
  intro σ τ h
  have hfirst := hf σ τ (fun v hv => h v (bit_or_left hv))
  have hsecond := hg σ τ (fun v hv => h v (bit_or_right hv))
  simp only [mul, hfirst, hsecond]

theorem mask_supported_branch {s t : Nat} {f g : Weight} (v : Nat)
    (hf : MaskSupported s f) (hg : MaskSupported t g) :
    MaskSupported ((2 ^ v ||| s) ||| t) (branch v f g) := by
  intro σ τ h
  have hv : σ v = τ v := h v (by simp)
  have hfirst := hf σ τ (fun w hw => h w (bit_or_left (bit_or_right hw)))
  have hsecond := hg σ τ (fun w hw => h w (bit_or_right hw))
  simp only [branch, hv, hfirst, hsecond]

theorem independent_of_mask {mask v : Nat} {f : Weight}
    (hs : MaskSupported mask f) (hv : mask.testBit v = false) : Independent v f := by
  intro σ b
  apply hs
  intro w hw
  have hne : w ≠ v := by
    intro he
    subst w
    rw [hv] at hw
    cases hw
  exact setVar_other σ v w b hne

theorem bit_false_of_disjoint {left right v : Nat}
    (h : left &&& right = 0) (hl : left.testBit v = true) : right.testBit v = false := by
  have hb := congrArg (fun mask : Nat => mask.testBit v) h
  simpa only [Nat.testBit_and, hl, Bool.true_and, Nat.zero_testBit] using hb

def NodeValid (V nodeCount : Nat) (nodes : Nat → NodeDesc) (i : Nat) : Prop :=
  i < nodeCount ∧ (nodes i).support >>> V = 0 ∧
    (i = 0 ∨ (nodes (i - 1)).originalId < (nodes i).originalId) ∧
    match (nodes i).raw with
    | .constant _ => (nodes i).low = 0 ∧ (nodes i).high = 0 ∧
        (nodes i).core = 0 ∧ (nodes i).support = 0
    | .ite v oldLow oldHigh =>
        v < V ∧ (nodes i).low < i ∧ (nodes i).high < i ∧ (nodes i).core = 0 ∧
        oldLow = (nodes (nodes i).low).originalId ∧
        oldHigh = (nodes (nodes i).high).originalId ∧
        (nodes i).support = ((2 ^ v ||| (nodes (nodes i).low).support) |||
          (nodes (nodes i).high).support) ∧
        ((nodes (nodes i).low).support ||| (nodes (nodes i).high).support) &&&
          (2 ^ (v + 1) - 1) = 0
    | .guard positive negative oldCore =>
        (nodes i).low = 0 ∧ (nodes i).high = 0 ∧ (nodes i).core < i ∧
        oldCore = (nodes (nodes i).core).originalId ∧
        isGuard (nodes (nodes i).core).raw = false ∧
        positive ||| negative ≠ 0 ∧ positive &&& negative = 0 ∧
        (positive ||| negative) &&& (nodes (nodes i).core).support = 0 ∧
        (nodes i).support = ((positive ||| negative) ||| (nodes (nodes i).core).support)

def checkNode (V nodeCount : Nat) (nodes : Nat → NodeDesc) (i : Nat) : Bool :=
  @decide (NodeValid V nodeCount nodes i) (by
    unfold NodeValid
    cases (nodes i).raw <;> infer_instance)

def checkNodes (V nodeCount : Nat) (nodes : Nat → NodeDesc) : Bool :=
  decide (0 < nodeCount ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0) &&
    (List.range nodeCount).all (checkNode V nodeCount nodes)

def NodesValid (V nodeCount : Nat) (nodes : Nat → NodeDesc) : Prop :=
  0 < nodeCount ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0 ∧
    ∀ i, i < nodeCount → NodeValid V nodeCount nodes i

theorem checkNode_iff (V nodeCount : Nat) (nodes : Nat → NodeDesc) (i : Nat) :
    checkNode V nodeCount nodes i = true ↔ NodeValid V nodeCount nodes i := by
  simp only [checkNode, decide_eq_true_eq]

theorem checkNodes_sound {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (h : checkNodes V nodeCount nodes = true) : NodesValid V nodeCount nodes := by
  have hh : (0 < nodeCount ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0) ∧
      (List.range nodeCount).all (checkNode V nodeCount nodes) = true := by
    simpa only [checkNodes, Bool.and_eq_true, decide_eq_true_eq] using h
  refine ⟨hh.1.1, hh.1.2.1, hh.1.2.2, ?_⟩
  intro i hi
  exact (checkNode_iff V nodeCount nodes i).mp
    (List.all_eq_true.mp hh.2 i (List.mem_range.mpr hi))

noncomputable def nodeMeaning (nodeCount : Nat) (nodes : Nat → NodeDesc) (i : Nat) : Weight :=
  if i < nodeCount then
    match (nodes i).raw with
    | .constant value => constant value
    | .ite v _ _ =>
        if _hl : (nodes i).low < i then
          if _hh : (nodes i).high < i then
            branch v (nodeMeaning nodeCount nodes (nodes i).low)
              (nodeMeaning nodeCount nodes (nodes i).high)
          else constant 0
        else constant 0
    | .guard positive negative _ =>
        if _hc : (nodes i).core < i then
          mul (cube positive negative) (nodeMeaning nodeCount nodes (nodes i).core)
        else constant 0
  else constant 0
termination_by i
decreasing_by all_goals assumption

theorem nodeMeaning_constant {nodeCount : Nat} {nodes : Nat → NodeDesc} {i value : Nat}
    (hi : i < nodeCount) (hraw : (nodes i).raw = .constant value) :
    nodeMeaning nodeCount nodes i = constant value := by
  rw [nodeMeaning]
  simp only [hi, hraw, ↓reduceIte]

theorem nodeMeaning_ite {nodeCount : Nat} {nodes : Nat → NodeDesc} {i v low high : Nat}
    (hi : i < nodeCount) (hraw : (nodes i).raw = .ite v low high)
    (hl : (nodes i).low < i) (hh : (nodes i).high < i) :
    nodeMeaning nodeCount nodes i = branch v
      (nodeMeaning nodeCount nodes (nodes i).low) (nodeMeaning nodeCount nodes (nodes i).high) := by
  rw [nodeMeaning]
  simp only [hi, hraw, hl, hh, ↓reduceIte, ↓reduceDIte]

theorem nodeMeaning_guard {nodeCount : Nat} {nodes : Nat → NodeDesc} {i p n original : Nat}
    (hi : i < nodeCount) (hraw : (nodes i).raw = .guard p n original)
    (hc : (nodes i).core < i) :
    nodeMeaning nodeCount nodes i = mul (cube p n) (nodeMeaning nodeCount nodes (nodes i).core) := by
  rw [nodeMeaning]
  simp only [hi, hraw, hc, ↓reduceIte, ↓reduceDIte]

theorem nodeMeaning_supported {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) :
    ∀ i, i < nodeCount → MaskSupported (nodes i).support (nodeMeaning nodeCount nodes i) := by
  intro i
  induction i using Nat.strongRecOn with
  | ind i ih =>
    intro hi
    have hv := (hvalid.2.2.2 i hi).2.2.2
    cases hraw : (nodes i).raw with
    | constant value =>
      rw [nodeMeaning_constant hi hraw]
      exact mask_supported_constant _ _
    | ite v oldLow oldHigh =>
      have hb := hv
      simp only [hraw] at hb
      obtain ⟨_, hl, hh, _, _, _, hs, _⟩ := hb
      rw [nodeMeaning_ite hi hraw hl hh, hs]
      exact mask_supported_branch v (ih _ hl (Nat.lt_trans hl hi))
        (ih _ hh (Nat.lt_trans hh hi))
    | guard p n oldCore =>
      have hg := hv
      simp only [hraw] at hg
      obtain ⟨_, _, hc, _, _, _, _, _, hs⟩ := hg
      rw [nodeMeaning_guard hi hraw hc, hs]
      exact mask_supported_mul (mask_supported_cube p n) (ih _ hc (Nat.lt_trans hc hi))

theorem nodeMeaning_independent {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {i v : Nat}
    (hi : i < nodeCount) (hv : (nodes i).support.testBit v = false) :
    Independent v (nodeMeaning nodeCount nodes i) :=
  independent_of_mask (nodeMeaning_supported hvalid i hi) hv

noncomputable def viewMeaning (_V nodeCount : Nat) (nodes : Nat → NodeDesc) (view : View) : Weight :=
  mul (cube view.positive view.negative) (nodeMeaning nodeCount nodes view.core)

def ViewValid (V nodeCount : Nat) (nodes : Nat → NodeDesc) (view : View) : Prop :=
  view.core < nodeCount ∧ isGuard (nodes view.core).raw = false ∧
    view.positive &&& view.negative = 0 ∧
    (view.positive ||| view.negative) >>> V = 0 ∧
    (view.positive ||| view.negative) &&& (nodes view.core).support = 0

def checkView (V nodeCount : Nat) (nodes : Nat → NodeDesc) (view : View) : Bool :=
  @decide (ViewValid V nodeCount nodes view) (by unfold ViewValid; infer_instance)

def checkViews (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (viewCount : Nat) (views : Nat → View) : Bool :=
  (List.range viewCount).all (fun i => checkView V nodeCount nodes (views i))

theorem checkView_iff (V nodeCount : Nat) (nodes : Nat → NodeDesc) (view : View) :
    checkView V nodeCount nodes view = true ↔ ViewValid V nodeCount nodes view := by
  simp only [checkView, decide_eq_true_eq]

theorem checkViews_sound {V nodeCount viewCount : Nat} {nodes : Nat → NodeDesc}
    {views : Nat → View} (h : checkViews V nodeCount nodes viewCount views = true) :
    ∀ i, i < viewCount → ViewValid V nodeCount nodes (views i) := by
  intro i hi
  exact (checkView_iff V nodeCount nodes (views i)).mp
    (List.all_eq_true.mp h i (List.mem_range.mpr hi))

theorem zeroView_meaning {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) :
    viewMeaning V nodeCount nodes zeroView = constant 0 := by
  have hvalid := checkNodes_sound hnodes
  rw [viewMeaning, zeroView, nodeMeaning_constant hvalid.1 hvalid.2.2.1]
  funext σ
  simp [mul, constant]

def flatView (nodes : Nat → NodeDesc) (i : Nat) : View :=
  match (nodes i).raw with
  | .guard positive negative _ => ⟨positive, negative, (nodes i).core⟩
  | _ => ⟨0, 0, i⟩

theorem flatView_meaning {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {i : Nat} (hi : i < nodeCount) :
    viewMeaning V nodeCount nodes (flatView nodes i) = nodeMeaning nodeCount nodes i := by
  cases hraw : (nodes i).raw with
  | constant value =>
    funext σ
    simp [flatView, hraw, viewMeaning, cube_zero, mul, constant]
  | ite v oldLow oldHigh =>
    funext σ
    simp [flatView, hraw, viewMeaning, cube_zero, mul, constant]
  | guard p n oldCore =>
    have hg := (hvalid.2.2.2 i hi).2.2.2
    simp only [hraw] at hg
    rw [nodeMeaning_guard hi hraw hg.2.2.1]
    simp only [flatView, hraw, viewMeaning]

def joinedView (positive negative : Nat) (child : View) : View :=
  ⟨positive ||| child.positive, negative ||| child.negative, child.core⟩

def mergeView (positive negative : Nat) (child : View) : View :=
  if child = zeroView then zeroView
  else
    let result := joinedView positive negative child
    if result.positive &&& result.negative = 0 then result else zeroView

theorem joinedView_meaning (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (positive negative : Nat) (child : View) :
    viewMeaning V nodeCount nodes (joinedView positive negative child) =
      mul (cube positive negative) (viewMeaning V nodeCount nodes child) := by
  simp only [viewMeaning, joinedView, cube_or]
  funext σ
  exact Nat.mul_assoc _ _ _

theorem mergeView_meaning {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) (positive negative : Nat) (child : View) :
    viewMeaning V nodeCount nodes (mergeView positive negative child) =
      mul (cube positive negative) (viewMeaning V nodeCount nodes child) := by
  by_cases hz : child = zeroView
  · subst child
    funext σ
    simp [mergeView, zeroView_meaning hnodes, mul, constant]
  · by_cases hc : (joinedView positive negative child).positive &&&
        (joinedView positive negative child).negative = 0
    · simp only [mergeView, hz, if_false, hc, if_true]
      exact joinedView_meaning V nodeCount nodes positive negative child
    · simp only [mergeView, hz, if_false, hc]
      rw [zeroView_meaning hnodes, ← joinedView_meaning V nodeCount nodes positive negative child]
      unfold viewMeaning
      rw [cube_contradiction hc]
      funext σ
      simp [mul, constant]

theorem cofactor_mul (v : Nat) (b : Bool) (f g : Weight) :
    cofactor v b (mul f g) = mul (cofactor v b f) (cofactor v b g) := rfl

theorem cofactor_of_independent {v : Nat} {f : Weight} (b : Bool) (h : Independent v f) :
    cofactor v b f = f := by
  funext σ
  exact h σ b

theorem nodeMeaning_cofactor_ite {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {i v oldLow oldHigh : Nat}
    (hi : i < nodeCount) (hraw : (nodes i).raw = .ite v oldLow oldHigh) (b : Bool) :
    cofactor v b (nodeMeaning nodeCount nodes i) =
      nodeMeaning nodeCount nodes (if b then (nodes i).high else (nodes i).low) := by
  have hb := (hvalid.2.2.2 i hi).2.2.2
  simp only [hraw] at hb
  obtain ⟨_, hl, hh, _, _, _, _, hcut⟩ := hb
  have hbits := congrArg (fun mask : Nat => mask.testBit v) hcut
  have hfalse : ((nodes (nodes i).low).support |||
      (nodes (nodes i).high).support).testBit v = false := by
    simpa only [Nat.testBit_and, Nat.testBit_two_pow_sub_one,
      Nat.lt_succ_self, decide_true, Bool.and_true, Nat.zero_testBit] using hbits
  have hleft : (nodes (nodes i).low).support.testBit v = false := by
    have h := Bool.or_eq_false_iff.mp (by simpa only [Nat.testBit_or] using hfalse)
    exact h.1
  have hright : (nodes (nodes i).high).support.testBit v = false := by
    have h := Bool.or_eq_false_iff.mp (by simpa only [Nat.testBit_or] using hfalse)
    exact h.2
  have hindl := nodeMeaning_independent hvalid (Nat.lt_trans hl hi) hleft
  have hindr := nodeMeaning_independent hvalid (Nat.lt_trans hh hi) hright
  rw [nodeMeaning_ite hi hraw hl hh]
  funext σ
  simp only [cofactor, branch, setVar_same, hindl σ b, hindr σ b]
  cases b <;> rfl

theorem view_cofactor_bad_positive {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) {view : View} {v : Nat}
    (hp : view.positive.testBit v = true) :
    cofactor v false (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes zeroView := by
  rw [viewMeaning, cofactor_mul, cube_cofactor_bad_positive hp, zeroView_meaning hnodes]
  funext σ
  simp [mul, constant]

theorem view_cofactor_bad_negative {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) {view : View} {v : Nat}
    (hn : view.negative.testBit v = true) :
    cofactor v true (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes zeroView := by
  rw [viewMeaning, cofactor_mul, cube_cofactor_bad_negative hn, zeroView_meaning hnodes]
  funext σ
  simp [mul, constant]

theorem view_cofactor_positive {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {view : View} {v : Nat}
    (hview : ViewValid V nodeCount nodes view) (hp : view.positive.testBit v = true) :
    cofactor v true (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes ⟨eraseBit view.positive v, view.negative, view.core⟩ := by
  have hn := bit_false_of_disjoint hview.2.2.1 hp
  have hc := bit_false_of_disjoint hview.2.2.2.2 (bit_or_left hp)
  have hi := nodeMeaning_independent hvalid hview.1 hc
  rw [viewMeaning, cofactor_mul,
    cube_cofactor_good (by intro h; rfl) (by simp [hn]), eraseBit_of_false hn,
    cofactor_of_independent true hi]
  rfl

theorem view_cofactor_negative {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {view : View} {v : Nat}
    (hview : ViewValid V nodeCount nodes view) (hn : view.negative.testBit v = true) :
    cofactor v false (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes ⟨view.positive, eraseBit view.negative v, view.core⟩ := by
  have hp : view.positive.testBit v = false := by
    have h := congrArg (fun mask : Nat => mask.testBit v) hview.2.2.1
    simpa only [Nat.testBit_and, hn, Bool.and_true, Nat.zero_testBit] using h
  have hc := bit_false_of_disjoint hview.2.2.2.2 (bit_or_right hn)
  have hi := nodeMeaning_independent hvalid hview.1 hc
  rw [viewMeaning, cofactor_mul,
    cube_cofactor_good (by simp [hp]) (by intro h; rfl), eraseBit_of_false hp,
    cofactor_of_independent false hi]
  rfl

theorem view_cofactor_absent {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hvalid : NodesValid V nodeCount nodes) {view : View} {v : Nat} (b : Bool)
    (hview : ViewValid V nodeCount nodes view)
    (hp : view.positive.testBit v = false) (hn : view.negative.testBit v = false)
    (hc : (nodes view.core).support.testBit v = false) :
    cofactor v b (viewMeaning V nodeCount nodes view) = viewMeaning V nodeCount nodes view := by
  have hi := nodeMeaning_independent hvalid hview.1 hc
  rw [viewMeaning, cofactor_mul, cube_cofactor_absent b hp hn, cofactor_of_independent b hi]

theorem view_cofactor_head {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) {view : View} {v oldLow oldHigh : Nat}
    (b : Bool) (hview : ViewValid V nodeCount nodes view)
    (hp : view.positive.testBit v = false) (hn : view.negative.testBit v = false)
    (hraw : (nodes view.core).raw = .ite v oldLow oldHigh) :
    cofactor v b (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes
        (mergeView view.positive view.negative
          (flatView nodes (if b then (nodes view.core).high else (nodes view.core).low))) := by
  have hvalid := checkNodes_sound hnodes
  have hb := (hvalid.2.2.2 view.core hview.1).2.2.2
  simp only [hraw] at hb
  have hchild : (if b then (nodes view.core).high else (nodes view.core).low) < nodeCount := by
    cases b
    · exact Nat.lt_trans hb.2.1 hview.1
    · exact Nat.lt_trans hb.2.2.1 hview.1
  rw [viewMeaning, cofactor_mul, cube_cofactor_absent b hp hn,
    nodeMeaning_cofactor_ite hvalid hview.1 hraw b,
    ← flatView_meaning hvalid hchild]
  exact (mergeView_meaning hnodes view.positive view.negative _).symm

/-- Returns no result unless every local source/cofactor case is justified.
The checker does not assume that the requested variable is a least variable. -/
def cofactorView (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (varIdx : Nat) (bit : Bool) (view : View) : Option View :=
  if checkView V nodeCount nodes view then
    if varIdx < V then
      if view.positive.testBit varIdx then
        if bit then some ⟨eraseBit view.positive varIdx, view.negative, view.core⟩
        else some zeroView
      else if view.negative.testBit varIdx then
        if bit then some zeroView
        else some ⟨view.positive, eraseBit view.negative varIdx, view.core⟩
      else if (nodes view.core).support.testBit varIdx then
        match (nodes view.core).raw with
        | .ite head _ _ =>
            if varIdx = head then
              some (mergeView view.positive view.negative
                (flatView nodes (if bit then (nodes view.core).high else (nodes view.core).low)))
            else none
        | _ => none
      else some view
    else none
  else none

theorem cofactorView_sound {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    {varIdx : Nat} {bit : Bool} {view result : View}
    (hnodes : checkNodes V nodeCount nodes = true)
    (h : cofactorView V nodeCount nodes varIdx bit view = some result) :
    cofactor varIdx bit (viewMeaning V nodeCount nodes view) =
      viewMeaning V nodeCount nodes result := by
  have hvalid := checkNodes_sound hnodes
  by_cases hv : checkView V nodeCount nodes view = true
  · have hview := (checkView_iff V nodeCount nodes view).mp hv
    by_cases hbound : varIdx < V
    · cases hp : view.positive.testBit varIdx with
      | true =>
        cases bit with
        | false =>
          have hr : zeroView = result := by simpa [cofactorView, hv, hbound, hp] using h
          rw [← hr]
          exact view_cofactor_bad_positive hnodes hp
        | true =>
          have hr : (⟨eraseBit view.positive varIdx, view.negative, view.core⟩ : View) = result := by
            simpa [cofactorView, hv, hbound, hp] using h
          rw [← hr]
          exact view_cofactor_positive hvalid hview hp
      | false =>
        cases hn : view.negative.testBit varIdx with
        | true =>
          cases bit with
          | false =>
            have hr : (⟨view.positive, eraseBit view.negative varIdx, view.core⟩ : View) = result := by
              simpa [cofactorView, hv, hbound, hp, hn] using h
            rw [← hr]
            exact view_cofactor_negative hvalid hview hn
          | true =>
            have hr : zeroView = result := by simpa [cofactorView, hv, hbound, hp, hn] using h
            rw [← hr]
            exact view_cofactor_bad_negative hnodes hn
        | false =>
          cases hc : (nodes view.core).support.testBit varIdx with
          | false =>
            have hr : view = result := by simpa [cofactorView, hv, hbound, hp, hn, hc] using h
            rw [← hr]
            exact view_cofactor_absent hvalid bit hview hp hn hc
          | true =>
            cases hraw : (nodes view.core).raw with
            | constant value => simp [cofactorView, hv, hbound, hp, hn, hc, hraw] at h
            | guard positive negative original => simp [cofactorView, hv, hbound, hp, hn, hc, hraw] at h
            | ite head oldLow oldHigh =>
              by_cases he : varIdx = head
              · subst head
                have hr : mergeView view.positive view.negative
                    (flatView nodes (if bit then (nodes view.core).high else (nodes view.core).low)) = result := by
                  simpa [cofactorView, hv, hbound, hp, hn, hc, hraw] using h
                rw [← hr]
                exact view_cofactor_head hnodes bit hview hp hn hraw
              · simp [cofactorView, hv, hbound, hp, hn, hc, hraw, he] at h
    · simp [cofactorView, hv, hbound] at h
  · have hv' : checkView V nodeCount nodes view = false := Bool.eq_false_iff.mpr hv
    simp [cofactorView, hv'] at h

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.checkNodes_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.nodeMeaning_supported
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.nodeMeaning_independent
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.checkViews_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.zeroView_meaning
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.flatView_meaning
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.mergeView_meaning
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.cofactorView_sound

end ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations
