import GuardedRelationChecker
import Init.Data.List.Nat.Range

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Compose finite Boolean table checks from adjacent ranges. Each checked range
has an explicit starting index and length. Composition covers their exact
concatenation; no coverage list or table predicate is accepted on trust.
These lemmas recover the unchanged source/view/proof checker booleans.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck

def checkRange (test : Nat → Bool) (start count : Nat) : Bool :=
  (List.range' start count).all test

theorem checkRange_zero (test : Nat → Bool) (start : Nat) :
    checkRange test start 0 = true := rfl

theorem checkRange_append {test : Nat → Bool} {start left right : Nat}
    (hl : checkRange test start left = true)
    (hr : checkRange test (start + left) right = true) :
    checkRange test start (left + right) = true := by
  change (List.range' start (left + right)).all test = true
  rw [← List.range'_append_1, List.all_append]
  exact Bool.and_eq_true_iff.mpr ⟨hl, hr⟩

theorem range_all_of_checkRange {test : Nat → Bool} {count : Nat}
    (h : checkRange test 0 count = true) :
    (List.range count).all test = true := by
  rw [List.range_eq_range']
  exact h

theorem checkNodes_of_range {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hzero : 0 < nodeCount ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0)
    (h : checkRange (checkNode V nodeCount nodes) 0 nodeCount = true) :
    checkNodes V nodeCount nodes = true := by
  apply Bool.and_eq_true_iff.mpr
  refine ⟨?_, range_all_of_checkRange h⟩
  simpa only [decide_eq_true_eq] using hzero

theorem checkViews_of_range {V nodeCount viewCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View}
    (h : checkRange (fun i => checkView V nodeCount nodes (views i)) 0 viewCount = true) :
    checkViews V nodeCount nodes viewCount views = true :=
  range_all_of_checkRange h

theorem checkProofs_of_range {V nodeCount viewCount proofCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    (h : checkRange (checkProofAt V nodeCount nodes viewCount views proofs) 0 proofCount = true) :
    checkProofs V nodeCount nodes viewCount views proofCount proofs = true :=
  range_all_of_checkRange h

end ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.checkRange_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.checkRange_append
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.range_all_of_checkRange
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.checkNodes_of_range
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.checkViews_of_range
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.TableCheck.checkProofs_of_range
