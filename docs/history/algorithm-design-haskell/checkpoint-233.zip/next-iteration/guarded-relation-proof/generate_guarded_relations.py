#!/usr/bin/env python3
"""Extract fixed guarded-relation proof records; no source-function evaluator.

Select completed JSON records and translate their identifiers to closed dense
Lean tables.  This program never computes a cofactor, support, normalized
relation, function value, rank or basis.  The generated ordinary Lean checks
must establish all local semantic conditions independently of this selection.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WORK = ROOT / "next-iteration/exact-basis-diagnostic/attempts/basis-01/work.jsonl"
RESULTS = ROOT / "next-iteration/exact-basis-diagnostic/RESULTS.json"
SOURCE = ROOT / "next-iteration/cut-rank-review/attempts/cut-rank-01/input/trace.jsonl"
EXPECTED = {
    "work": "52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6",
    "results": "59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb",
    "source": "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea",
}
QUARTETS = [(0, 1, 2, 3), (6, 7, 8, 9), (11, 12, 13, 14), (17, 18, 19, 20)]
SIGNS = [1, -1, -1, 1]
CHUNK_SIZE = 8


def binding(path: Path) -> dict:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size, "sha256": digest}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def extract() -> dict:
    """Selection, reference resolution and identifier remapping only."""
    inputs = {name: binding(path) for name, path in (("work", WORK), ("results", RESULTS), ("source", SOURCE))}
    require(all(inputs[name]["sha256"] == digest for name, digest in EXPECTED.items()), "fixed input differs")
    result = json.loads(RESULTS.read_text())
    require(result["producer_status"] == "completed_exact_basis" and result["replay_status"] == "passed",
            "fixed diagnostic not complete and replayed")
    starts, dones, proofs = {}, {}, {}
    for line in WORK.open():
        record = json.loads(line)
        if record["kind"] == "work":
            require(record["id"] not in starts, "duplicate work ID")
            starts[record["id"]] = record
        elif record["kind"] == "done":
            work_id = record["id"]
            require(work_id not in dones and work_id in starts, "duplicate or unstarted completion")
            dones[work_id] = record
            output = record["output"]
            if starts[work_id]["operation"] == "state" and output["proof_new"]:
                require(output["outcome"] == "zero" and output["proof_id"] not in proofs, "invalid new proof record")
                proofs[output["proof_id"]] = work_id

    def selected(reference):
        value = dones[reference[0]]["output"][reference[1]]
        for index in reference[2:]:
            value = value[index]
        return value

    dependent = {x["column"]: x for x in result["completed_columns"] if x["outcome"] == "dependent"}
    require(sorted(dependent) == [3, 9, 14, 20], "fixed dependent columns differ")
    root_proofs = []
    for quartet in QUARTETS:
        outcome = dependent[quartet[-1]]
        require(outcome["positive_scale"] == 1 and outcome["integer_original_column_coefficients"] ==
                [[column, sign] for column, sign in zip(quartet, SIGNS)], "fixed identity vector differs")
        root_proofs.append(outcome["proof_id"])
    require(root_proofs == [134, 216, 289, 343], "fixed root ProofIDs differ")

    needed_proofs = set()
    def follow_proof(proof_id):
        if proof_id in needed_proofs:
            return
        needed_proofs.add(proof_id)
        for child in dones[proofs[proof_id]]["output"]["proof_children"]:
            follow_proof(child)
    for proof_id in root_proofs:
        follow_proof(proof_id)
    original_proofs = sorted(needed_proofs)
    proof_index = {original: dense for dense, original in enumerate(original_proofs)}

    selected_columns = [column for quartet in QUARTETS for column in quartet]
    view_validation = {}
    for work_id, record in starts.items():
        if record["operation"] == "view_validate" and record["inputs"]["column"] in selected_columns:
            column = record["inputs"]["column"]
            require(column not in view_validation and work_id in dones, "missing or duplicate selected view validation")
            view_validation[column] = work_id
    require(sorted(view_validation) == selected_columns, "selected view coverage differs")

    needed_dependencies = set()
    def follow_dependency(work_id):
        if work_id in needed_dependencies:
            return
        needed_dependencies.add(work_id)
        for child in dones[work_id]["dependencies"]:
            follow_dependency(child)
    for work_id in view_validation.values():
        follow_dependency(work_id)
    original_nodes = sorted({starts[i]["inputs"]["source_node_id"] for i in needed_dependencies
                             if starts[i]["operation"] == "validate"})
    node_index = {original: dense for dense, original in enumerate(original_nodes)}
    first_validation = {}
    for work_id, record in starts.items():
        if record["operation"] == "validate" and work_id in dones:
            output = dones[work_id]["output"]
            original = record["inputs"]["source_node_id"]
            if original in node_index and not output["cache_hit"]:
                require(original not in first_validation, "multiple original validation misses")
                first_validation[original] = work_id
    require(sorted(first_validation) == original_nodes, "node validation closure incomplete")

    raw_nodes = {}
    for line in SOURCE.open():
        record = json.loads(line)
        if record.get("type") == "node" and record.get("id") in node_index:
            require(record["id"] not in raw_nodes, "duplicate selected raw source node")
            raw_nodes[record["id"]] = record
    require(sorted(raw_nodes) == original_nodes, "raw node closure incomplete")

    nodes = []
    for original in original_nodes:
        raw = raw_nodes[original]
        validation_id = first_validation[original]
        validated = dones[validation_id]["output"]
        item = {"original_id": original, "raw": raw, "validation_work_id": validation_id,
                "support": validated["support"], "low": 0, "high": 0, "core": 0}
        if raw["kind"] == "ite":
            item["low"], item["high"] = node_index[raw["low"]], node_index[raw["high"]]
        elif raw["kind"] == "guard":
            item["core"] = node_index[raw["core"]]
        else:
            require(raw["kind"] == "constant", "unsupported selected raw node")
        nodes.append(item)

    goals = {}
    recorded_views = set()
    for original in original_proofs:
        work_id = proofs[original]
        state = selected(starts[work_id]["inputs"]["normalization"])
        goals[original] = state
        for view, coefficient in state:
            recorded_views.add(tuple(view))
    original_views = sorted(recorded_views)
    view_index = {view: dense for dense, view in enumerate(original_views)}
    views = [{"positive": view[0], "negative": view[1], "core": node_index[view[2]],
              "original_core": view[2]} for view in original_views]

    proof_nodes = []
    for original in original_proofs:
        work_id = proofs[original]
        output = dones[work_id]["output"]
        goal = [[coefficient, view_index[tuple(view)]] for view, coefficient in goals[original]]
        if output["rule"] == "terminal":
            require(goal == [] and output["proof_children"] == [], "nonempty terminal needs another checker rule")
            step = {"kind": "empty"}
        else:
            require(output["rule"] == "split" and len(output["proof_children"]) == 2, "unsupported zero proof rule")
            branches = [i for i in dones[work_id]["dependencies"] if starts[i]["operation"] == "branch"]
            require(len(branches) == 2 and [starts[i]["inputs"]["bit"] for i in branches] == [0, 1],
                    "split branch occurrences differ")
            variables = [selected(starts[i]["inputs"]["variable"]) for i in branches]
            require(variables[0] == variables[1], "split variables differ")
            step = {"kind": "split", "variable": variables[0],
                    "low": proof_index[output["proof_children"][0]],
                    "high": proof_index[output["proof_children"][1]]}
        proof_nodes.append({"original_proof_id": original, "state_work_id": work_id, "goal": goal, "step": step})

    bindings = []
    for column in selected_columns:
        work_id = view_validation[column]
        view = dones[work_id]["output"]["view"]
        bindings.append({"column": column, "view_validation_work_id": work_id, "original_view": view,
                         "view_index": view_index[tuple(view)]})
    by_column = {item["column"]: item["view_index"] for item in bindings}
    relations = [{"index": i, "columns": list(quartet), "original_root_proof_id": root_proofs[i],
                  "root": proof_index[root_proofs[i]],
                  "target_goal": [[sign, by_column[column]] for column, sign in zip(quartet, SIGNS)]}
                 for i, quartet in enumerate(QUARTETS)]
    require((len(nodes), len(views), len(proof_nodes)) == (866, 909, 332), "recorded proof closure dimensions differ")
    return {"format": "fixed-guarded-relation-record-extraction-v1", "variable_limit": 210,
            "semantic_recomputation": False, "inputs": inputs, "nodes": nodes, "views": views,
            "proofs": proof_nodes, "original_view_bindings": bindings, "relations": relations,
            "scope": "Only saved metadata/reference selection and identifier remapping; Lean must check every local semantic condition."}


NAMESPACE = "ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut"


def goal_literal(goal: list) -> str:
    return "[" + ", ".join(f"({coefficient}, {view})" for coefficient, view in goal) + "]"


def raw_literal(raw: dict) -> str:
    if raw["kind"] == "constant":
        return f".constant {raw['value']}"
    if raw["kind"] == "ite":
        return f".ite {raw['variable']} {raw['low']} {raw['high']}"
    require(raw["kind"] == "guard", "unsupported raw constructor")
    return f".guard {raw['positive']} {raw['negative']} {raw['core']}"


def original_literal(view: list) -> str:
    return "⟨" + ", ".join(map(str, view)) + "⟩"


def common_header(imports: list[str], generator_sha: str) -> list[str]:
    return [*(f"import {module}" for module in imports), "",
            "set_option autoImplicit false", "set_option warningAsError true",
            "set_option Elab.async false", "", "/-!",
            "Four fixed identities extracted from completed zero-proof records.",
            "No external function value, sampled equality, rank or count is a premise.",
            f"Generator SHA256: {generator_sha}",
            f"Completed work SHA256: {EXPECTED['work']}",
            f"Original guarded trace SHA256: {EXPECTED['source']}",
            f"Diagnostic result SHA256: {EXPECTED['results']}",
            "-/", "", f"namespace {NAMESPACE}", ""]


def render_array(name: str, element_type: str, entries: list[str], size_theorem: str) -> list[str]:
    """Render unchanged ordered literals and their total number of entries."""
    chunks = [entries[start:start + CHUNK_SIZE] for start in range(0, len(entries), CHUNK_SIZE)]
    require(bool(chunks), "fixed certificate arrays are nonempty")
    names = [f"{name}_chunk{i}" for i in range(len(chunks))]
    lines = []
    for chunk_name, chunk in zip(names, chunks):
        lines.append(f"def {chunk_name} : Array {element_type} := #[")
        for index, entry in enumerate(chunk):
            lines.append("  " + entry + ("," if index + 1 < len(chunk) else ""))
        lines += ["]", "", f"theorem {chunk_name}_size : {chunk_name}.size = {len(chunk)} := rfl", ""]

    def balanced(parts: list[str]) -> str:
        if len(parts) == 1:
            return parts[0]
        middle = len(parts) // 2
        return f"({balanced(parts[:middle])} + {balanced(parts[middle:])})"

    lines += [f"def {name}Size : Nat := {balanced([chunk_name + '.size' for chunk_name in names])}", "",
              f"theorem {size_theorem} : {name}Size = {len(entries)} := by",
              "  simp only [" + ", ".join([name + "Size"] +
                                          [f"{chunk_name}_size" for chunk_name in names]) + "]", ""]
    if size_theorem in ("nodes_size", "views_size", "proofs_size"):
        lines += [f"#print axioms {NAMESPACE}.{size_theorem}", ""]
    return lines


def render_lookup(name: str, element_type: str, table: str, count: int, default: str) -> list[str]:
    """Use direct chunk lookup; do not reconstruct any concatenated array."""
    chunks = list(range((count + CHUNK_SIZE - 1) // CHUNK_SIZE))

    def dispatch(parts: list[int], indent: str) -> list[str]:
        if len(parts) == 1:
            chunk = parts[0]
            offset = "i" if chunk == 0 else f"i - {CHUNK_SIZE * chunk}"
            return [f"{indent}({table}_chunk{chunk}[{offset}]?).getD {default}"]
        middle = len(parts) // 2
        boundary = CHUNK_SIZE * parts[middle]
        return [f"{indent}if i < {boundary} then", *dispatch(parts[:middle], indent + "  "),
                f"{indent}else", *dispatch(parts[middle:], indent + "  ")]

    return [f"def {name} (i : Nat) : {element_type} :=", *dispatch(chunks, "  "), ""]


def render_data(data: dict, generator_sha: str) -> str:
    lines = common_header(["GuardedRelationChecker"], generator_sha)
    lines += ["/- Dense links are separate from the exact original source IDs in raw.",
              "Support masks below are proposals checked locally by checkNodes.",
              f"Each literal has at most {CHUNK_SIZE} entries; direct dispatch uses its fixed offset.",
              "No checked lookup reconstructs a concatenated array. -/", ""]
    node_entries = [f"⟨{node['original_id']}, {raw_literal(node['raw'])}, "
                    f"{node['low']}, {node['high']}, {node['core']}, {node['support']}⟩"
                    for node in data["nodes"]]
    lines += render_array("nodeData", "NodeDesc", node_entries, "nodes_size")
    lines += render_lookup("nodes", "NodeDesc", "nodeData", len(data["nodes"]), "⟨0, .constant 0, 0, 0, 0, 0⟩")
    view_entries = [f"⟨{view['positive']}, {view['negative']}, {view['core']}⟩" for view in data["views"]]
    lines += render_array("viewData", "View", view_entries, "views_size")
    lines += render_lookup("views", "View", "viewData", len(data["views"]), "zeroView")
    proof_entries = []
    for proof in data["proofs"]:
        step = proof["step"]
        rendered_step = ".empty" if step["kind"] == "empty" else (
            f".split {step['variable']} {step['low']} {step['high']}")
        proof_entries.append(f"⟨{goal_literal(proof['goal'])}, {rendered_step}⟩")
    lines += render_array("proofData", "ProofNode", proof_entries, "proofs_size")
    lines += render_lookup("proofs", "ProofNode", "proofData", len(data["proofs"]), "⟨[], .empty⟩")
    lines += ["/- Proof IDs identify saved metadata only; their correctness is not assumed. -/", ""]
    lines += render_array("originalProofIds", "Nat", [str(proof["original_proof_id"])
                                                     for proof in data["proofs"]], "originalProofIds_size")
    lines += render_lookup("originalProofId", "Nat", "originalProofIds", len(data["proofs"]), "0")
    lines += ["/- Only the following sixteen original column numbers are specified.",
              "Every conclusion below uses those cases; the total default is not a source binding. -/",
              "def bView : Nat → Nat"]
    for item in data["original_view_bindings"]:
        lines.append(f"  | {item['column']} => {item['view_index']}")
    lines += ["  | _ => 0", ""]
    for item in data["original_view_bindings"]:
        column = item["column"]
        lines += [f"def originalB{column} : OriginalView := {original_literal(item['original_view'])}",
                  f"theorem b{column}_original :",
                  f"    toOriginalView nodes (views (bView {column})) = originalB{column} := by",
                  "  decide +kernel", "",
                  f"#print axioms {NAMESPACE}.b{column}_original", ""]
    for relation in data["relations"]:
        index, root = relation["index"], relation["root"]
        lines += [f"def root{index} : Nat := {root}",
                  f"theorem root{index}_original :",
                  f"    originalProofId root{index} = {relation['original_root_proof_id']} := by",
                  "  decide +kernel", "",
                  f"#print axioms {NAMESPACE}.root{index}_original", ""]
    lines += [f"end {NAMESPACE}", ""]
    return "\n".join(lines) + "\n"


def render_relations(data: dict, generator_sha: str) -> str:
    lines = common_header(["GeneratedGuardedData", "GuardedRelationChecker", "SignedBlockRewrite"], generator_sha)
    lines += ["open SignedRelations SignedBlockRewrite", "",
              "noncomputable def meaning (i : Nat) : Weight := viewMeaning 210 866 nodes (views i)",
              "noncomputable def B (column : Nat) : Weight := meaning (bView column)", "",
              "theorem nodes_checked : checkNodes 210 866 nodes = true := by",
              "  decide +kernel", "",
              f"#print axioms {NAMESPACE}.nodes_checked", "",
              "theorem views_checked : checkViews 210 866 nodes 909 views = true := by",
              "  decide +kernel", "",
              f"#print axioms {NAMESPACE}.views_checked", "",
              "theorem proofs_checked : checkProofs 210 866 nodes 909 views 332 proofs = true := by",
              "  decide +kernel", "",
              f"#print axioms {NAMESPACE}.proofs_checked", "",
              "theorem all_proofs_correct : ∀ root, root < 332 →",
              "    Zero (combine (fun j => lift (meaning j)) (proofs root).goal) :=",
              "  checkProofs_sound nodes_checked views_checked proofs_checked", ""]
    printed = ["all_proofs_correct"]
    for relation in data["relations"]:
        index = relation["index"]
        p, q, r, s = relation["columns"]
        columns = relation["columns"]
        dense_goal = "[" + ", ".join(f"({sign}, bView {column})" for column, sign in zip(columns, SIGNS)) + "]"
        original_goal = "[" + ", ".join(f"({sign}, {column})" for column, sign in zip(columns, SIGNS)) + "]"
        lines += [f"theorem root{index}_goal_perm : (proofs root{index}).goal.Perm {dense_goal} := by",
                  "  decide +kernel", "",
                  f"theorem relation{index}_zero : Zero (combine (fun j => lift (B j))",
                  f"    {original_goal}) := by",
                  f"  change Zero (combine (fun j => lift (meaning j)) {dense_goal})",
                  f"  exact zero_of_eq (combine_perm (fun j => lift (meaning j)) root{index}_goal_perm).symm",
                  f"    (all_proofs_correct root{index} (by decide))", "",
                  f"theorem relation{index}_bound :",
                  f"    toOriginalView nodes (views (bView {p})) = originalB{p} ∧",
                  f"    toOriginalView nodes (views (bView {q})) = originalB{q} ∧",
                  f"    toOriginalView nodes (views (bView {r})) = originalB{r} ∧",
                  f"    toOriginalView nodes (views (bView {s})) = originalB{s} ∧",
                  f"    Zero (combine (fun j => lift (B j)) {original_goal}) :=",
                  f"  ⟨b{p}_original, b{q}_original, b{r}_original, b{s}_original, relation{index}_zero⟩", "",
                  f"theorem relation{index}_nat : add (B {p}) (B {s}) = add (B {q}) (B {r}) :=",
                  f"  nat_four_of_signed_zero B {p} {q} {r} {s} relation{index}_zero", "",
                  f"theorem relation{index}_block (Ap Aq Ar As : Value) :",
                  f"    originalBlock Ap Aq Ar As (B {p}) (B {q}) (B {r}) (B {s}) =",
                  f"      reducedBlock Ap Aq Ar As (B {p}) (B {q}) (B {r}) :=",
                  f"  four_term_rewrite_of_signed_zero B {p} {q} {r} {s} Ap Aq Ar As relation{index}_zero", ""]
        printed += [f"root{index}_goal_perm", f"relation{index}_zero", f"relation{index}_bound",
                    f"relation{index}_nat", f"relation{index}_block"]
    lines += [f"end {NAMESPACE}", ""]
    lines += [f"#print axioms {NAMESPACE}.{name}" for name in printed]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=HERE)
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    require(destination == HERE, "fixed concrete module destination differs")
    outputs = [destination / name for name in (
        "extracted-records.json", "GeneratedGuardedData.lean", "GeneratedGuardedRelations.lean",
        "generation.json")]
    require(not any(path.exists() for path in outputs), "refuse to replace a retained generation")
    generator = binding(Path(__file__).resolve())
    data = extract()
    outputs[0].write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    outputs[1].write_text(render_data(data, generator["sha256"]))
    outputs[2].write_text(render_relations(data, generator["sha256"]))
    report = {
        "format": "fixed-guarded-relation-generation-v4", "generator": generator,
        "inputs": data["inputs"], "outputs": [binding(path) for path in outputs[:3]],
        "counts": {"nodes": len(data["nodes"]), "views": len(data["views"]),
                   "proofs": len(data["proofs"]), "original_views": len(data["original_view_bindings"]),
                   "relations": len(data["relations"])},
        "semantic_recomputation": False, "lean_executed": False,
        "representation": {"literal_chunk_limit": CHUNK_SIZE, "lookup": "balanced interval dispatch with direct offset lookup",
                           "aggregate_size": "sum of checked literal chunk sizes; no concatenated arrays",
                           "exact_ordered_data_changed": False},
        "scope": "Saved record extraction only. The generated conditions and conclusions remain unverified until an ordinary fresh Lean gate accepts them.",
    }
    outputs[3].write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "generated_unchecked", "counts": report["counts"],
                      "generation": binding(outputs[3])}, sort_keys=True))


if __name__ == "__main__":
    main()
