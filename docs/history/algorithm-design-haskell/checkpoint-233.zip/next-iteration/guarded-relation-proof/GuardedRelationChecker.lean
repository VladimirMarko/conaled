import GuardedSource
import SignedRelations

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
A finite checker for signed identities of the internally interpreted guarded
source functions. Each split checks both restrictions and earlier proof IDs.
Collection preserves every signed occurrence, merges only equal complete Views,
and deletes only a zero coefficient or the checked distinguished zero View.
The sole terminal certificate is a literally empty goal.
-/
namespace ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations

open SignedRelations

abbrev Goal := List (Int × Nat)

inductive Step where
  | empty
  | split (v low high : Nat)
  deriving DecidableEq

structure ProofNode where
  goal : Goal
  step : Step
  deriving DecidableEq

abbrev ViewTerms := List (Int × View)

def expandGoal (views : Nat → View) (goal : Goal) : ViewTerms :=
  goal.map (fun term => (term.1, views term.2))

noncomputable def viewValue (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (view : View) : Value :=
  lift (viewMeaning V nodeCount nodes view)

noncomputable def goalValue (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (goal : Goal) : Value :=
  combine (fun j => viewValue V nodeCount nodes (views j)) goal

theorem expandGoal_sound (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (goal : Goal) :
    goalValue V nodeCount nodes views goal =
      combine (viewValue V nodeCount nodes) (expandGoal views goal) :=
  combine_transport (fun j => viewValue V nodeCount nodes (views j))
    (viewValue V nodeCount nodes) views goal (fun _ _ => rfl)

theorem zeroView_value {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) :
    viewValue V nodeCount nodes zeroView = SignedRelations.zero := by
  unfold viewValue
  rw [zeroView_meaning hnodes]
  rfl

def insertViewTerm (c : Int) (view : View) (terms : ViewTerms) : ViewTerms :=
  if c = 0 then terms
  else if view = zeroView then terms
  else match terms with
    | [] => [(c, view)]
    | (d, other) :: tail =>
        if view = other then
          if c + d = 0 then tail else (c + d, view) :: tail
        else (d, other) :: insertViewTerm c view tail

theorem insertViewTerm_sound (meaning : View → Value)
    (hzero : meaning zeroView = SignedRelations.zero)
    (c : Int) (view : View) (terms : ViewTerms) :
    combine meaning (insertViewTerm c view terms) =
      combine meaning ((c, view) :: terms) := by
  by_cases hc : c = 0
  · subst c
    rw [insertViewTerm.eq_def, if_pos rfl, combine_zero_coefficient]
  · by_cases hv : view = zeroView
    · subst view
      rw [insertViewTerm.eq_def, if_neg hc, if_pos rfl]
      funext σ
      change combine meaning terms σ =
        c * meaning zeroView σ + combine meaning terms σ
      rw [hzero]
      simp only [SignedRelations.zero, Int.mul_zero, Int.zero_add]
    · induction terms with
      | nil => rw [insertViewTerm, if_neg hc, if_neg hv]
      | cons term tail ih =>
        rcases term with ⟨d, other⟩
        by_cases heq : view = other
        · subst other
          rw [insertViewTerm, if_neg hc, if_neg hv, if_pos rfl]
          rw [combine_merge]
          by_cases hs : c + d = 0
          · rw [if_pos hs, hs, combine_zero_coefficient]
          · rw [if_neg hs]
        · rw [insertViewTerm, if_neg hc, if_neg hv, if_neg heq]
          funext σ
          change d * meaning other σ + combine meaning (insertViewTerm c view tail) σ =
            c * meaning view σ + (d * meaning other σ + combine meaning tail σ)
          rw [ih]
          exact Int.add_left_comm (d * meaning other σ) (c * meaning view σ)
            (combine meaning tail σ)

def collectTerms : ViewTerms → ViewTerms
  | [] => []
  | (c, view) :: tail => insertViewTerm c view (collectTerms tail)

theorem collectTerms_sound (meaning : View → Value)
    (hzero : meaning zeroView = SignedRelations.zero) (terms : ViewTerms) :
    combine meaning (collectTerms terms) = combine meaning terms := by
  induction terms with
  | nil => rfl
  | cons term tail ih =>
    rcases term with ⟨c, view⟩
    change combine meaning (insertViewTerm c view (collectTerms tail)) =
      combine meaning ((c, view) :: tail)
    rw [insertViewTerm_sound meaning hzero]
    funext σ
    exact congrArg (fun total : Int => c * meaning view σ + total) (congrFun ih σ)

def cofactorTerms (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (v : Nat) (b : Bool) : ViewTerms → Option ViewTerms
  | [] => some []
  | (c, view) :: tail =>
      match cofactorView V nodeCount nodes v b view with
      | none => none
      | some result =>
          match cofactorTerms V nodeCount nodes v b tail with
          | none => none
          | some rest => some ((c, result) :: rest)

theorem cofactorTerms_sound {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    (hnodes : checkNodes V nodeCount nodes = true) (v : Nat) (b : Bool)
    {terms result : ViewTerms}
    (h : cofactorTerms V nodeCount nodes v b terms = some result) :
    restrict v b (combine (viewValue V nodeCount nodes) terms) =
      combine (viewValue V nodeCount nodes) result := by
  induction terms generalizing result with
  | nil =>
    have hr : result = [] := by
      exact (Option.some.inj h).symm
    subst result
    rfl
  | cons term tail ih =>
    rcases term with ⟨c, view⟩
    cases hhead : cofactorView V nodeCount nodes v b view with
    | none =>
      rw [cofactorTerms, hhead] at h
      cases h
    | some next =>
      cases htail : cofactorTerms V nodeCount nodes v b tail with
      | none =>
        rw [cofactorTerms, hhead, htail] at h
        cases h
      | some rest =>
        have hr : (c, next) :: rest = result := by
          simpa only [cofactorTerms, hhead, htail, Option.some.injEq] using h
        subst result
        have hh := congrArg lift (cofactorView_sound hnodes hhead)
        have ht := ih htail
        funext σ
        exact (congrArg
          (fun x : Int => c * x + restrict v b (combine (viewValue V nodeCount nodes) tail) σ)
          (congrFun hh σ)).trans
          (congrArg (fun y : Int => c * viewValue V nodeCount nodes next σ + y)
            (congrFun ht σ))

def checkBranch (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (parent child : Goal) (v : Nat) (b : Bool) : Bool :=
  match cofactorTerms V nodeCount nodes v b (expandGoal views parent) with
  | none => false
  | some restricted =>
      decide ((collectTerms restricted).Perm (collectTerms (expandGoal views child)))

theorem checkBranch_sound {V nodeCount : Nat} {nodes : Nat → NodeDesc}
    {views : Nat → View} {parent child : Goal} {v : Nat} {b : Bool}
    (hnodes : checkNodes V nodeCount nodes = true)
    (h : checkBranch V nodeCount nodes views parent child v b = true) :
    restrict v b (goalValue V nodeCount nodes views parent) =
      goalValue V nodeCount nodes views child := by
  cases hrestriction : cofactorTerms V nodeCount nodes v b (expandGoal views parent) with
  | none =>
    rw [checkBranch, hrestriction] at h
    cases h
  | some restricted =>
    have hp : (collectTerms restricted).Perm (collectTerms (expandGoal views child)) := by
      apply of_decide_eq_true
      simpa only [checkBranch, hrestriction] using h
    calc
      restrict v b (goalValue V nodeCount nodes views parent) =
          restrict v b (combine (viewValue V nodeCount nodes) (expandGoal views parent)) :=
        congrArg (restrict v b) (expandGoal_sound V nodeCount nodes views parent)
      _ = combine (viewValue V nodeCount nodes) restricted :=
        cofactorTerms_sound hnodes v b hrestriction
      _ = combine (viewValue V nodeCount nodes) (collectTerms restricted) :=
        (collectTerms_sound (viewValue V nodeCount nodes) (zeroView_value hnodes) restricted).symm
      _ = combine (viewValue V nodeCount nodes) (collectTerms (expandGoal views child)) :=
        combine_perm (viewValue V nodeCount nodes) hp
      _ = combine (viewValue V nodeCount nodes) (expandGoal views child) :=
        collectTerms_sound (viewValue V nodeCount nodes) (zeroView_value hnodes)
          (expandGoal views child)
      _ = goalValue V nodeCount nodes views child :=
        (expandGoal_sound V nodeCount nodes views child).symm

def checkGoal (viewCount : Nat) (goal : Goal) : Bool :=
  goal.all (fun term => decide (term.2 < viewCount))

def checkStep (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (views : Nat → View) (proofs : Nat → ProofNode) (index : Nat) : Step → Bool
  | .empty => decide ((proofs index).goal = [])
  | .split v low high =>
      decide (low < index ∧ high < index) &&
        (checkBranch V nodeCount nodes views (proofs index).goal (proofs low).goal v false &&
         checkBranch V nodeCount nodes views (proofs index).goal (proofs high).goal v true)

def checkProofAt (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (viewCount : Nat) (views : Nat → View) (proofs : Nat → ProofNode) (index : Nat) : Bool :=
  checkGoal viewCount (proofs index).goal &&
    checkStep V nodeCount nodes views proofs index (proofs index).step

def checkProofs (V nodeCount : Nat) (nodes : Nat → NodeDesc)
    (viewCount : Nat) (views : Nat → View)
    (proofCount : Nat) (proofs : Nat → ProofNode) : Bool :=
  (List.range proofCount).all
    (fun index => checkProofAt V nodeCount nodes viewCount views proofs index)

def semanticStep : Step → SignedRelations.Step
  | .empty => .zero
  | .split v low high => .split v low high

theorem checkProofAt_sound {V nodeCount viewCount : Nat} {nodes : Nat → NodeDesc}
    {views : Nat → View} {proofs : Nat → ProofNode} {index : Nat}
    (hnodes : checkNodes V nodeCount nodes = true)
    (h : checkProofAt V nodeCount nodes viewCount views proofs index = true) :
    SignedRelations.ValidAt
      (fun i => goalValue V nodeCount nodes views (proofs i).goal)
      index (semanticStep (proofs index).step) := by
  have hstep : checkStep V nodeCount nodes views proofs index (proofs index).step = true :=
    (Bool.and_eq_true_iff.mp h).2
  cases hs : (proofs index).step with
  | empty =>
    have hg : (proofs index).goal = [] := by
      apply of_decide_eq_true
      simpa only [hs, checkStep] using hstep
    have hz : Zero (goalValue V nodeCount nodes views (proofs index).goal) := by
      rw [hg]
      exact zero_zero
    simpa only [hs, semanticStep, SignedRelations.ValidAt] using hz
  | split v low high =>
    have hb : decide (low < index ∧ high < index) = true ∧
        (checkBranch V nodeCount nodes views (proofs index).goal (proofs low).goal v false &&
         checkBranch V nodeCount nodes views (proofs index).goal (proofs high).goal v true) = true := by
      apply Bool.and_eq_true_iff.mp
      simpa only [hs, checkStep] using hstep
    have hbounds : low < index ∧ high < index := of_decide_eq_true hb.1
    have hbranches := Bool.and_eq_true_iff.mp hb.2
    have hv : low < index ∧ high < index ∧
        restrict v false (goalValue V nodeCount nodes views (proofs index).goal) =
          goalValue V nodeCount nodes views (proofs low).goal ∧
        restrict v true (goalValue V nodeCount nodes views (proofs index).goal) =
          goalValue V nodeCount nodes views (proofs high).goal :=
      ⟨hbounds.1, hbounds.2, checkBranch_sound hnodes hbranches.1,
        checkBranch_sound hnodes hbranches.2⟩
    simpa only [hs, semanticStep, SignedRelations.ValidAt] using hv

/- The table check is part of the public certificate interface. Each actual
cofactor additionally checks its View locally, so the relation induction does
not rely on a caller-provided function meaning or on a trusted view lookup. -/
theorem checkProofs_sound {V nodeCount viewCount proofCount : Nat}
    {nodes : Nat → NodeDesc} {views : Nat → View} {proofs : Nat → ProofNode}
    (hnodes : checkNodes V nodeCount nodes = true)
    (_hviews : checkViews V nodeCount nodes viewCount views = true)
    (hproofs : checkProofs V nodeCount nodes viewCount views proofCount proofs = true) :
    ∀ root, root < proofCount →
      Zero (combine (fun j => lift (viewMeaning V nodeCount nodes (views j)))
        (proofs root).goal) := by
  apply earlier_dag_sound proofCount
    (fun i => goalValue V nodeCount nodes views (proofs i).goal)
    (fun i => semanticStep (proofs i).step)
  intro index hi
  apply checkProofAt_sound hnodes
  exact List.all_eq_true.mp hproofs index (List.mem_range.mpr hi)

end ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.expandGoal_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.zeroView_value
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.insertViewTerm_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.collectTerms_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.cofactorTerms_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.checkBranch_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.checkProofAt_sound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.checkProofs_sound
