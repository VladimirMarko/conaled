import GeneratedGuardedData
import GuardedRelationChecker
import TableCheck
import SignedBlockRewrite

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Four fixed identities extracted from completed zero-proof records.
No external function value, sampled equality, rank or count is a premise.
Data generator SHA256: 52a2da29956b41b1c66110d8230351c6e7216c544738a162eb2e771b3b7a88a9
Range-check generator SHA256: d6a2d47003fbbec1bbb2126fdebf5f2a2a61680c8be49d2c8e4c701fad86a4c2
Completed work SHA256: 52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6
Original guarded trace SHA256: 6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea
Diagnostic result SHA256: 59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb
-/

namespace ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut

open SignedRelations SignedBlockRewrite TableCheck

noncomputable def meaning (i : Nat) : Weight := viewMeaning 210 866 nodes (views i)
noncomputable def B (column : Nat) : Weight := meaning (bView column)

theorem nodes_range_0_16 : checkRange (checkNode 210 866 nodes) 0 16 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.nodes_range_0_16

theorem nodes_range_16_16 : checkRange (checkNode 210 866 nodes) 16 16 = true := by
  decide +kernel

theorem nodes_range_32_16 : checkRange (checkNode 210 866 nodes) 32 16 = true := by
  decide +kernel

theorem nodes_range_48_16 : checkRange (checkNode 210 866 nodes) 48 16 = true := by
  decide +kernel

theorem nodes_range_64_16 : checkRange (checkNode 210 866 nodes) 64 16 = true := by
  decide +kernel

theorem nodes_range_80_16 : checkRange (checkNode 210 866 nodes) 80 16 = true := by
  decide +kernel

theorem nodes_range_96_16 : checkRange (checkNode 210 866 nodes) 96 16 = true := by
  decide +kernel

theorem nodes_range_112_16 : checkRange (checkNode 210 866 nodes) 112 16 = true := by
  decide +kernel

theorem nodes_range_128_16 : checkRange (checkNode 210 866 nodes) 128 16 = true := by
  decide +kernel

theorem nodes_range_144_16 : checkRange (checkNode 210 866 nodes) 144 16 = true := by
  decide +kernel

theorem nodes_range_160_16 : checkRange (checkNode 210 866 nodes) 160 16 = true := by
  decide +kernel

theorem nodes_range_176_16 : checkRange (checkNode 210 866 nodes) 176 16 = true := by
  decide +kernel

theorem nodes_range_192_16 : checkRange (checkNode 210 866 nodes) 192 16 = true := by
  decide +kernel

theorem nodes_range_208_16 : checkRange (checkNode 210 866 nodes) 208 16 = true := by
  decide +kernel

theorem nodes_range_224_16 : checkRange (checkNode 210 866 nodes) 224 16 = true := by
  decide +kernel

theorem nodes_range_240_16 : checkRange (checkNode 210 866 nodes) 240 16 = true := by
  decide +kernel

theorem nodes_range_256_16 : checkRange (checkNode 210 866 nodes) 256 16 = true := by
  decide +kernel

theorem nodes_range_272_16 : checkRange (checkNode 210 866 nodes) 272 16 = true := by
  decide +kernel

theorem nodes_range_288_16 : checkRange (checkNode 210 866 nodes) 288 16 = true := by
  decide +kernel

theorem nodes_range_304_16 : checkRange (checkNode 210 866 nodes) 304 16 = true := by
  decide +kernel

theorem nodes_range_320_16 : checkRange (checkNode 210 866 nodes) 320 16 = true := by
  decide +kernel

theorem nodes_range_336_16 : checkRange (checkNode 210 866 nodes) 336 16 = true := by
  decide +kernel

theorem nodes_range_352_16 : checkRange (checkNode 210 866 nodes) 352 16 = true := by
  decide +kernel

theorem nodes_range_368_16 : checkRange (checkNode 210 866 nodes) 368 16 = true := by
  decide +kernel

theorem nodes_range_384_16 : checkRange (checkNode 210 866 nodes) 384 16 = true := by
  decide +kernel

theorem nodes_range_400_16 : checkRange (checkNode 210 866 nodes) 400 16 = true := by
  decide +kernel

theorem nodes_range_416_16 : checkRange (checkNode 210 866 nodes) 416 16 = true := by
  decide +kernel

theorem nodes_range_432_16 : checkRange (checkNode 210 866 nodes) 432 16 = true := by
  decide +kernel

theorem nodes_range_448_16 : checkRange (checkNode 210 866 nodes) 448 16 = true := by
  decide +kernel

theorem nodes_range_464_16 : checkRange (checkNode 210 866 nodes) 464 16 = true := by
  decide +kernel

theorem nodes_range_480_16 : checkRange (checkNode 210 866 nodes) 480 16 = true := by
  decide +kernel

theorem nodes_range_496_16 : checkRange (checkNode 210 866 nodes) 496 16 = true := by
  decide +kernel

theorem nodes_range_512_16 : checkRange (checkNode 210 866 nodes) 512 16 = true := by
  decide +kernel

theorem nodes_range_528_16 : checkRange (checkNode 210 866 nodes) 528 16 = true := by
  decide +kernel

theorem nodes_range_544_16 : checkRange (checkNode 210 866 nodes) 544 16 = true := by
  decide +kernel

theorem nodes_range_560_16 : checkRange (checkNode 210 866 nodes) 560 16 = true := by
  decide +kernel

theorem nodes_range_576_16 : checkRange (checkNode 210 866 nodes) 576 16 = true := by
  decide +kernel

theorem nodes_range_592_16 : checkRange (checkNode 210 866 nodes) 592 16 = true := by
  decide +kernel

theorem nodes_range_608_16 : checkRange (checkNode 210 866 nodes) 608 16 = true := by
  decide +kernel

theorem nodes_range_624_16 : checkRange (checkNode 210 866 nodes) 624 16 = true := by
  decide +kernel

theorem nodes_range_640_16 : checkRange (checkNode 210 866 nodes) 640 16 = true := by
  decide +kernel

theorem nodes_range_656_16 : checkRange (checkNode 210 866 nodes) 656 16 = true := by
  decide +kernel

theorem nodes_range_672_16 : checkRange (checkNode 210 866 nodes) 672 16 = true := by
  decide +kernel

theorem nodes_range_688_16 : checkRange (checkNode 210 866 nodes) 688 16 = true := by
  decide +kernel

theorem nodes_range_704_16 : checkRange (checkNode 210 866 nodes) 704 16 = true := by
  decide +kernel

theorem nodes_range_720_16 : checkRange (checkNode 210 866 nodes) 720 16 = true := by
  decide +kernel

theorem nodes_range_736_16 : checkRange (checkNode 210 866 nodes) 736 16 = true := by
  decide +kernel

theorem nodes_range_752_16 : checkRange (checkNode 210 866 nodes) 752 16 = true := by
  decide +kernel

theorem nodes_range_768_16 : checkRange (checkNode 210 866 nodes) 768 16 = true := by
  decide +kernel

theorem nodes_range_784_16 : checkRange (checkNode 210 866 nodes) 784 16 = true := by
  decide +kernel

theorem nodes_range_800_16 : checkRange (checkNode 210 866 nodes) 800 16 = true := by
  decide +kernel

theorem nodes_range_816_16 : checkRange (checkNode 210 866 nodes) 816 16 = true := by
  decide +kernel

theorem nodes_range_832_16 : checkRange (checkNode 210 866 nodes) 832 16 = true := by
  decide +kernel

theorem nodes_range_848_16 : checkRange (checkNode 210 866 nodes) 848 16 = true := by
  decide +kernel

theorem nodes_range_864_2 : checkRange (checkNode 210 866 nodes) 864 2 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.nodes_range_864_2

theorem nodes_range_16_32 : checkRange (checkNode 210 866 nodes) 16 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 16)
    (left := 16) (right := 16) nodes_range_16_16 nodes_range_32_16

theorem nodes_range_0_48 : checkRange (checkNode 210 866 nodes) 0 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 0)
    (left := 16) (right := 32) nodes_range_0_16 nodes_range_16_32

theorem nodes_range_64_32 : checkRange (checkNode 210 866 nodes) 64 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 64)
    (left := 16) (right := 16) nodes_range_64_16 nodes_range_80_16

theorem nodes_range_48_48 : checkRange (checkNode 210 866 nodes) 48 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 48)
    (left := 16) (right := 32) nodes_range_48_16 nodes_range_64_32

theorem nodes_range_0_96 : checkRange (checkNode 210 866 nodes) 0 96 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 0)
    (left := 48) (right := 48) nodes_range_0_48 nodes_range_48_48

theorem nodes_range_112_32 : checkRange (checkNode 210 866 nodes) 112 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 112)
    (left := 16) (right := 16) nodes_range_112_16 nodes_range_128_16

theorem nodes_range_96_48 : checkRange (checkNode 210 866 nodes) 96 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 96)
    (left := 16) (right := 32) nodes_range_96_16 nodes_range_112_32

theorem nodes_range_144_32 : checkRange (checkNode 210 866 nodes) 144 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 144)
    (left := 16) (right := 16) nodes_range_144_16 nodes_range_160_16

theorem nodes_range_176_32 : checkRange (checkNode 210 866 nodes) 176 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 176)
    (left := 16) (right := 16) nodes_range_176_16 nodes_range_192_16

theorem nodes_range_144_64 : checkRange (checkNode 210 866 nodes) 144 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 144)
    (left := 32) (right := 32) nodes_range_144_32 nodes_range_176_32

theorem nodes_range_96_112 : checkRange (checkNode 210 866 nodes) 96 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 96)
    (left := 48) (right := 64) nodes_range_96_48 nodes_range_144_64

theorem nodes_range_0_208 : checkRange (checkNode 210 866 nodes) 0 208 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 0)
    (left := 96) (right := 112) nodes_range_0_96 nodes_range_96_112

theorem nodes_range_224_32 : checkRange (checkNode 210 866 nodes) 224 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 224)
    (left := 16) (right := 16) nodes_range_224_16 nodes_range_240_16

theorem nodes_range_208_48 : checkRange (checkNode 210 866 nodes) 208 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 208)
    (left := 16) (right := 32) nodes_range_208_16 nodes_range_224_32

theorem nodes_range_256_32 : checkRange (checkNode 210 866 nodes) 256 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 256)
    (left := 16) (right := 16) nodes_range_256_16 nodes_range_272_16

theorem nodes_range_288_32 : checkRange (checkNode 210 866 nodes) 288 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 288)
    (left := 16) (right := 16) nodes_range_288_16 nodes_range_304_16

theorem nodes_range_256_64 : checkRange (checkNode 210 866 nodes) 256 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 256)
    (left := 32) (right := 32) nodes_range_256_32 nodes_range_288_32

theorem nodes_range_208_112 : checkRange (checkNode 210 866 nodes) 208 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 208)
    (left := 48) (right := 64) nodes_range_208_48 nodes_range_256_64

theorem nodes_range_336_32 : checkRange (checkNode 210 866 nodes) 336 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 336)
    (left := 16) (right := 16) nodes_range_336_16 nodes_range_352_16

theorem nodes_range_320_48 : checkRange (checkNode 210 866 nodes) 320 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 320)
    (left := 16) (right := 32) nodes_range_320_16 nodes_range_336_32

theorem nodes_range_368_32 : checkRange (checkNode 210 866 nodes) 368 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 368)
    (left := 16) (right := 16) nodes_range_368_16 nodes_range_384_16

theorem nodes_range_400_32 : checkRange (checkNode 210 866 nodes) 400 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 400)
    (left := 16) (right := 16) nodes_range_400_16 nodes_range_416_16

theorem nodes_range_368_64 : checkRange (checkNode 210 866 nodes) 368 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 368)
    (left := 32) (right := 32) nodes_range_368_32 nodes_range_400_32

theorem nodes_range_320_112 : checkRange (checkNode 210 866 nodes) 320 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 320)
    (left := 48) (right := 64) nodes_range_320_48 nodes_range_368_64

theorem nodes_range_208_224 : checkRange (checkNode 210 866 nodes) 208 224 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 208)
    (left := 112) (right := 112) nodes_range_208_112 nodes_range_320_112

theorem nodes_range_0_432 : checkRange (checkNode 210 866 nodes) 0 432 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 0)
    (left := 208) (right := 224) nodes_range_0_208 nodes_range_208_224

theorem nodes_range_448_32 : checkRange (checkNode 210 866 nodes) 448 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 448)
    (left := 16) (right := 16) nodes_range_448_16 nodes_range_464_16

theorem nodes_range_432_48 : checkRange (checkNode 210 866 nodes) 432 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 432)
    (left := 16) (right := 32) nodes_range_432_16 nodes_range_448_32

theorem nodes_range_480_32 : checkRange (checkNode 210 866 nodes) 480 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 480)
    (left := 16) (right := 16) nodes_range_480_16 nodes_range_496_16

theorem nodes_range_512_32 : checkRange (checkNode 210 866 nodes) 512 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 512)
    (left := 16) (right := 16) nodes_range_512_16 nodes_range_528_16

theorem nodes_range_480_64 : checkRange (checkNode 210 866 nodes) 480 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 480)
    (left := 32) (right := 32) nodes_range_480_32 nodes_range_512_32

theorem nodes_range_432_112 : checkRange (checkNode 210 866 nodes) 432 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 432)
    (left := 48) (right := 64) nodes_range_432_48 nodes_range_480_64

theorem nodes_range_560_32 : checkRange (checkNode 210 866 nodes) 560 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 560)
    (left := 16) (right := 16) nodes_range_560_16 nodes_range_576_16

theorem nodes_range_544_48 : checkRange (checkNode 210 866 nodes) 544 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 544)
    (left := 16) (right := 32) nodes_range_544_16 nodes_range_560_32

theorem nodes_range_592_32 : checkRange (checkNode 210 866 nodes) 592 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 592)
    (left := 16) (right := 16) nodes_range_592_16 nodes_range_608_16

theorem nodes_range_624_32 : checkRange (checkNode 210 866 nodes) 624 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 624)
    (left := 16) (right := 16) nodes_range_624_16 nodes_range_640_16

theorem nodes_range_592_64 : checkRange (checkNode 210 866 nodes) 592 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 592)
    (left := 32) (right := 32) nodes_range_592_32 nodes_range_624_32

theorem nodes_range_544_112 : checkRange (checkNode 210 866 nodes) 544 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 544)
    (left := 48) (right := 64) nodes_range_544_48 nodes_range_592_64

theorem nodes_range_432_224 : checkRange (checkNode 210 866 nodes) 432 224 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 432)
    (left := 112) (right := 112) nodes_range_432_112 nodes_range_544_112

theorem nodes_range_672_32 : checkRange (checkNode 210 866 nodes) 672 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 672)
    (left := 16) (right := 16) nodes_range_672_16 nodes_range_688_16

theorem nodes_range_656_48 : checkRange (checkNode 210 866 nodes) 656 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 656)
    (left := 16) (right := 32) nodes_range_656_16 nodes_range_672_32

theorem nodes_range_704_32 : checkRange (checkNode 210 866 nodes) 704 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 704)
    (left := 16) (right := 16) nodes_range_704_16 nodes_range_720_16

theorem nodes_range_736_32 : checkRange (checkNode 210 866 nodes) 736 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 736)
    (left := 16) (right := 16) nodes_range_736_16 nodes_range_752_16

theorem nodes_range_704_64 : checkRange (checkNode 210 866 nodes) 704 64 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 704)
    (left := 32) (right := 32) nodes_range_704_32 nodes_range_736_32

theorem nodes_range_656_112 : checkRange (checkNode 210 866 nodes) 656 112 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 656)
    (left := 48) (right := 64) nodes_range_656_48 nodes_range_704_64

theorem nodes_range_784_32 : checkRange (checkNode 210 866 nodes) 784 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 784)
    (left := 16) (right := 16) nodes_range_784_16 nodes_range_800_16

theorem nodes_range_768_48 : checkRange (checkNode 210 866 nodes) 768 48 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 768)
    (left := 16) (right := 32) nodes_range_768_16 nodes_range_784_32

theorem nodes_range_816_32 : checkRange (checkNode 210 866 nodes) 816 32 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 816)
    (left := 16) (right := 16) nodes_range_816_16 nodes_range_832_16

theorem nodes_range_848_18 : checkRange (checkNode 210 866 nodes) 848 18 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 848)
    (left := 16) (right := 2) nodes_range_848_16 nodes_range_864_2

theorem nodes_range_816_50 : checkRange (checkNode 210 866 nodes) 816 50 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 816)
    (left := 32) (right := 18) nodes_range_816_32 nodes_range_848_18

theorem nodes_range_768_98 : checkRange (checkNode 210 866 nodes) 768 98 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 768)
    (left := 48) (right := 50) nodes_range_768_48 nodes_range_816_50

theorem nodes_range_656_210 : checkRange (checkNode 210 866 nodes) 656 210 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 656)
    (left := 112) (right := 98) nodes_range_656_112 nodes_range_768_98

theorem nodes_range_432_434 : checkRange (checkNode 210 866 nodes) 432 434 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 432)
    (left := 224) (right := 210) nodes_range_432_224 nodes_range_656_210

theorem nodes_range_0_866 : checkRange (checkNode 210 866 nodes) 0 866 = true :=
  checkRange_append (test := checkNode 210 866 nodes) (start := 0)
    (left := 432) (right := 434) nodes_range_0_432 nodes_range_432_434

theorem node_zero_checked : 0 < 866 ∧ (nodes 0).originalId = 0 ∧ (nodes 0).raw = .constant 0 := by
  decide +kernel

theorem nodes_checked : checkNodes 210 866 nodes = true :=
  checkNodes_of_range (V := 210) (nodeCount := 866) (nodes := nodes)
    node_zero_checked nodes_range_0_866

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.nodes_checked

theorem views_range_0_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 16 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.views_range_0_16

theorem views_range_16_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 16 16 = true := by
  decide +kernel

theorem views_range_32_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 32 16 = true := by
  decide +kernel

theorem views_range_48_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 48 16 = true := by
  decide +kernel

theorem views_range_64_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 64 16 = true := by
  decide +kernel

theorem views_range_80_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 80 16 = true := by
  decide +kernel

theorem views_range_96_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 96 16 = true := by
  decide +kernel

theorem views_range_112_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 112 16 = true := by
  decide +kernel

theorem views_range_128_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 128 16 = true := by
  decide +kernel

theorem views_range_144_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 144 16 = true := by
  decide +kernel

theorem views_range_160_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 160 16 = true := by
  decide +kernel

theorem views_range_176_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 176 16 = true := by
  decide +kernel

theorem views_range_192_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 192 16 = true := by
  decide +kernel

theorem views_range_208_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 208 16 = true := by
  decide +kernel

theorem views_range_224_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 224 16 = true := by
  decide +kernel

theorem views_range_240_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 240 16 = true := by
  decide +kernel

theorem views_range_256_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 256 16 = true := by
  decide +kernel

theorem views_range_272_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 272 16 = true := by
  decide +kernel

theorem views_range_288_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 288 16 = true := by
  decide +kernel

theorem views_range_304_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 304 16 = true := by
  decide +kernel

theorem views_range_320_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 320 16 = true := by
  decide +kernel

theorem views_range_336_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 336 16 = true := by
  decide +kernel

theorem views_range_352_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 352 16 = true := by
  decide +kernel

theorem views_range_368_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 368 16 = true := by
  decide +kernel

theorem views_range_384_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 384 16 = true := by
  decide +kernel

theorem views_range_400_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 400 16 = true := by
  decide +kernel

theorem views_range_416_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 416 16 = true := by
  decide +kernel

theorem views_range_432_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 432 16 = true := by
  decide +kernel

theorem views_range_448_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 448 16 = true := by
  decide +kernel

theorem views_range_464_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 464 16 = true := by
  decide +kernel

theorem views_range_480_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 480 16 = true := by
  decide +kernel

theorem views_range_496_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 496 16 = true := by
  decide +kernel

theorem views_range_512_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 512 16 = true := by
  decide +kernel

theorem views_range_528_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 528 16 = true := by
  decide +kernel

theorem views_range_544_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 544 16 = true := by
  decide +kernel

theorem views_range_560_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 560 16 = true := by
  decide +kernel

theorem views_range_576_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 576 16 = true := by
  decide +kernel

theorem views_range_592_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 592 16 = true := by
  decide +kernel

theorem views_range_608_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 608 16 = true := by
  decide +kernel

theorem views_range_624_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 624 16 = true := by
  decide +kernel

theorem views_range_640_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 640 16 = true := by
  decide +kernel

theorem views_range_656_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 656 16 = true := by
  decide +kernel

theorem views_range_672_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 672 16 = true := by
  decide +kernel

theorem views_range_688_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 688 16 = true := by
  decide +kernel

theorem views_range_704_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 704 16 = true := by
  decide +kernel

theorem views_range_720_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 720 16 = true := by
  decide +kernel

theorem views_range_736_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 736 16 = true := by
  decide +kernel

theorem views_range_752_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 752 16 = true := by
  decide +kernel

theorem views_range_768_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 768 16 = true := by
  decide +kernel

theorem views_range_784_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 784 16 = true := by
  decide +kernel

theorem views_range_800_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 800 16 = true := by
  decide +kernel

theorem views_range_816_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 816 16 = true := by
  decide +kernel

theorem views_range_832_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 832 16 = true := by
  decide +kernel

theorem views_range_848_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 848 16 = true := by
  decide +kernel

theorem views_range_864_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 864 16 = true := by
  decide +kernel

theorem views_range_880_16 : checkRange (fun i => checkView 210 866 nodes (views i)) 880 16 = true := by
  decide +kernel

theorem views_range_896_13 : checkRange (fun i => checkView 210 866 nodes (views i)) 896 13 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.views_range_896_13

theorem views_range_16_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 16 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 16)
    (left := 16) (right := 16) views_range_16_16 views_range_32_16

theorem views_range_0_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 0)
    (left := 16) (right := 32) views_range_0_16 views_range_16_32

theorem views_range_48_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 48 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 48)
    (left := 16) (right := 16) views_range_48_16 views_range_64_16

theorem views_range_80_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 80 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 80)
    (left := 16) (right := 16) views_range_80_16 views_range_96_16

theorem views_range_48_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 48 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 48)
    (left := 32) (right := 32) views_range_48_32 views_range_80_32

theorem views_range_0_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 0)
    (left := 48) (right := 64) views_range_0_48 views_range_48_64

theorem views_range_128_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 128 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 128)
    (left := 16) (right := 16) views_range_128_16 views_range_144_16

theorem views_range_112_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 112 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 112)
    (left := 16) (right := 32) views_range_112_16 views_range_128_32

theorem views_range_160_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 160 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 160)
    (left := 16) (right := 16) views_range_160_16 views_range_176_16

theorem views_range_192_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 192 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 192)
    (left := 16) (right := 16) views_range_192_16 views_range_208_16

theorem views_range_160_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 160 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 160)
    (left := 32) (right := 32) views_range_160_32 views_range_192_32

theorem views_range_112_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 112 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 112)
    (left := 48) (right := 64) views_range_112_48 views_range_160_64

theorem views_range_0_224 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 224 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 0)
    (left := 112) (right := 112) views_range_0_112 views_range_112_112

theorem views_range_240_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 240 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 240)
    (left := 16) (right := 16) views_range_240_16 views_range_256_16

theorem views_range_224_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 224 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 224)
    (left := 16) (right := 32) views_range_224_16 views_range_240_32

theorem views_range_272_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 272 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 272)
    (left := 16) (right := 16) views_range_272_16 views_range_288_16

theorem views_range_304_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 304 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 304)
    (left := 16) (right := 16) views_range_304_16 views_range_320_16

theorem views_range_272_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 272 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 272)
    (left := 32) (right := 32) views_range_272_32 views_range_304_32

theorem views_range_224_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 224 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 224)
    (left := 48) (right := 64) views_range_224_48 views_range_272_64

theorem views_range_352_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 352 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 352)
    (left := 16) (right := 16) views_range_352_16 views_range_368_16

theorem views_range_336_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 336 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 336)
    (left := 16) (right := 32) views_range_336_16 views_range_352_32

theorem views_range_384_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 384 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 384)
    (left := 16) (right := 16) views_range_384_16 views_range_400_16

theorem views_range_416_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 416 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 416)
    (left := 16) (right := 16) views_range_416_16 views_range_432_16

theorem views_range_384_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 384 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 384)
    (left := 32) (right := 32) views_range_384_32 views_range_416_32

theorem views_range_336_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 336 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 336)
    (left := 48) (right := 64) views_range_336_48 views_range_384_64

theorem views_range_224_224 : checkRange (fun i => checkView 210 866 nodes (views i)) 224 224 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 224)
    (left := 112) (right := 112) views_range_224_112 views_range_336_112

theorem views_range_0_448 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 448 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 0)
    (left := 224) (right := 224) views_range_0_224 views_range_224_224

theorem views_range_464_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 464 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 464)
    (left := 16) (right := 16) views_range_464_16 views_range_480_16

theorem views_range_448_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 448 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 448)
    (left := 16) (right := 32) views_range_448_16 views_range_464_32

theorem views_range_496_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 496 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 496)
    (left := 16) (right := 16) views_range_496_16 views_range_512_16

theorem views_range_528_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 528 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 528)
    (left := 16) (right := 16) views_range_528_16 views_range_544_16

theorem views_range_496_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 496 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 496)
    (left := 32) (right := 32) views_range_496_32 views_range_528_32

theorem views_range_448_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 448 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 448)
    (left := 48) (right := 64) views_range_448_48 views_range_496_64

theorem views_range_576_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 576 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 576)
    (left := 16) (right := 16) views_range_576_16 views_range_592_16

theorem views_range_560_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 560 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 560)
    (left := 16) (right := 32) views_range_560_16 views_range_576_32

theorem views_range_608_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 608 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 608)
    (left := 16) (right := 16) views_range_608_16 views_range_624_16

theorem views_range_640_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 640 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 640)
    (left := 16) (right := 16) views_range_640_16 views_range_656_16

theorem views_range_608_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 608 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 608)
    (left := 32) (right := 32) views_range_608_32 views_range_640_32

theorem views_range_560_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 560 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 560)
    (left := 48) (right := 64) views_range_560_48 views_range_608_64

theorem views_range_448_224 : checkRange (fun i => checkView 210 866 nodes (views i)) 448 224 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 448)
    (left := 112) (right := 112) views_range_448_112 views_range_560_112

theorem views_range_688_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 688 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 688)
    (left := 16) (right := 16) views_range_688_16 views_range_704_16

theorem views_range_672_48 : checkRange (fun i => checkView 210 866 nodes (views i)) 672 48 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 672)
    (left := 16) (right := 32) views_range_672_16 views_range_688_32

theorem views_range_720_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 720 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 720)
    (left := 16) (right := 16) views_range_720_16 views_range_736_16

theorem views_range_752_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 752 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 752)
    (left := 16) (right := 16) views_range_752_16 views_range_768_16

theorem views_range_720_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 720 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 720)
    (left := 32) (right := 32) views_range_720_32 views_range_752_32

theorem views_range_672_112 : checkRange (fun i => checkView 210 866 nodes (views i)) 672 112 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 672)
    (left := 48) (right := 64) views_range_672_48 views_range_720_64

theorem views_range_784_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 784 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 784)
    (left := 16) (right := 16) views_range_784_16 views_range_800_16

theorem views_range_816_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 816 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 816)
    (left := 16) (right := 16) views_range_816_16 views_range_832_16

theorem views_range_784_64 : checkRange (fun i => checkView 210 866 nodes (views i)) 784 64 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 784)
    (left := 32) (right := 32) views_range_784_32 views_range_816_32

theorem views_range_848_32 : checkRange (fun i => checkView 210 866 nodes (views i)) 848 32 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 848)
    (left := 16) (right := 16) views_range_848_16 views_range_864_16

theorem views_range_880_29 : checkRange (fun i => checkView 210 866 nodes (views i)) 880 29 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 880)
    (left := 16) (right := 13) views_range_880_16 views_range_896_13

theorem views_range_848_61 : checkRange (fun i => checkView 210 866 nodes (views i)) 848 61 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 848)
    (left := 32) (right := 29) views_range_848_32 views_range_880_29

theorem views_range_784_125 : checkRange (fun i => checkView 210 866 nodes (views i)) 784 125 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 784)
    (left := 64) (right := 61) views_range_784_64 views_range_848_61

theorem views_range_672_237 : checkRange (fun i => checkView 210 866 nodes (views i)) 672 237 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 672)
    (left := 112) (right := 125) views_range_672_112 views_range_784_125

theorem views_range_448_461 : checkRange (fun i => checkView 210 866 nodes (views i)) 448 461 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 448)
    (left := 224) (right := 237) views_range_448_224 views_range_672_237

theorem views_range_0_909 : checkRange (fun i => checkView 210 866 nodes (views i)) 0 909 = true :=
  checkRange_append (test := fun i => checkView 210 866 nodes (views i)) (start := 0)
    (left := 448) (right := 461) views_range_0_448 views_range_448_461

theorem views_checked : checkViews 210 866 nodes 909 views = true :=
  checkViews_of_range (V := 210) (nodeCount := 866) (viewCount := 909)
    (nodes := nodes) (views := views) views_range_0_909

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.views_checked

theorem proofs_range_0_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 0 16 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.proofs_range_0_16

theorem proofs_range_16_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 16 16 = true := by
  decide +kernel

theorem proofs_range_32_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 32 16 = true := by
  decide +kernel

theorem proofs_range_48_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 48 16 = true := by
  decide +kernel

theorem proofs_range_64_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 64 16 = true := by
  decide +kernel

theorem proofs_range_80_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 80 16 = true := by
  decide +kernel

theorem proofs_range_96_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 96 16 = true := by
  decide +kernel

theorem proofs_range_112_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 112 16 = true := by
  decide +kernel

theorem proofs_range_128_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 128 16 = true := by
  decide +kernel

theorem proofs_range_144_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 144 16 = true := by
  decide +kernel

theorem proofs_range_160_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 160 16 = true := by
  decide +kernel

theorem proofs_range_176_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 176 16 = true := by
  decide +kernel

theorem proofs_range_192_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 192 16 = true := by
  decide +kernel

theorem proofs_range_208_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 208 16 = true := by
  decide +kernel

theorem proofs_range_224_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 224 16 = true := by
  decide +kernel

theorem proofs_range_240_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 240 16 = true := by
  decide +kernel

theorem proofs_range_256_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 256 16 = true := by
  decide +kernel

theorem proofs_range_272_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 272 16 = true := by
  decide +kernel

theorem proofs_range_288_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 288 16 = true := by
  decide +kernel

theorem proofs_range_304_16 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 304 16 = true := by
  decide +kernel

theorem proofs_range_320_12 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 320 12 = true := by
  decide +kernel

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.proofs_range_320_12

theorem proofs_range_0_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 0 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 0)
    (left := 16) (right := 16) proofs_range_0_16 proofs_range_16_16

theorem proofs_range_48_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 48 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 48)
    (left := 16) (right := 16) proofs_range_48_16 proofs_range_64_16

theorem proofs_range_32_48 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 32 48 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 32)
    (left := 16) (right := 32) proofs_range_32_16 proofs_range_48_32

theorem proofs_range_0_80 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 0 80 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 0)
    (left := 32) (right := 48) proofs_range_0_32 proofs_range_32_48

theorem proofs_range_80_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 80 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 80)
    (left := 16) (right := 16) proofs_range_80_16 proofs_range_96_16

theorem proofs_range_128_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 128 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 128)
    (left := 16) (right := 16) proofs_range_128_16 proofs_range_144_16

theorem proofs_range_112_48 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 112 48 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 112)
    (left := 16) (right := 32) proofs_range_112_16 proofs_range_128_32

theorem proofs_range_80_80 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 80 80 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 80)
    (left := 32) (right := 48) proofs_range_80_32 proofs_range_112_48

theorem proofs_range_0_160 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 0 160 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 0)
    (left := 80) (right := 80) proofs_range_0_80 proofs_range_80_80

theorem proofs_range_160_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 160 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 160)
    (left := 16) (right := 16) proofs_range_160_16 proofs_range_176_16

theorem proofs_range_208_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 208 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 208)
    (left := 16) (right := 16) proofs_range_208_16 proofs_range_224_16

theorem proofs_range_192_48 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 192 48 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 192)
    (left := 16) (right := 32) proofs_range_192_16 proofs_range_208_32

theorem proofs_range_160_80 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 160 80 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 160)
    (left := 32) (right := 48) proofs_range_160_32 proofs_range_192_48

theorem proofs_range_256_32 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 256 32 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 256)
    (left := 16) (right := 16) proofs_range_256_16 proofs_range_272_16

theorem proofs_range_240_48 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 240 48 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 240)
    (left := 16) (right := 32) proofs_range_240_16 proofs_range_256_32

theorem proofs_range_304_28 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 304 28 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 304)
    (left := 16) (right := 12) proofs_range_304_16 proofs_range_320_12

theorem proofs_range_288_44 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 288 44 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 288)
    (left := 16) (right := 28) proofs_range_288_16 proofs_range_304_28

theorem proofs_range_240_92 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 240 92 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 240)
    (left := 48) (right := 44) proofs_range_240_48 proofs_range_288_44

theorem proofs_range_160_172 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 160 172 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 160)
    (left := 80) (right := 92) proofs_range_160_80 proofs_range_240_92

theorem proofs_range_0_332 : checkRange (checkProofAt 210 866 nodes 909 views proofs) 0 332 = true :=
  checkRange_append (test := checkProofAt 210 866 nodes 909 views proofs) (start := 0)
    (left := 160) (right := 172) proofs_range_0_160 proofs_range_160_172

theorem proofs_checked : checkProofs 210 866 nodes 909 views 332 proofs = true :=
  checkProofs_of_range (V := 210) (nodeCount := 866) (viewCount := 909) (proofCount := 332)
    (nodes := nodes) (views := views) (proofs := proofs) proofs_range_0_332

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.proofs_checked

theorem all_proofs_correct : ∀ root, root < 332 →
    Zero (combine (fun j => lift (meaning j)) (proofs root).goal) :=
  checkProofs_sound nodes_checked views_checked proofs_checked

theorem root0_goal_perm : (proofs root0).goal.Perm [(1, bView 0), (-1, bView 1), (-1, bView 2), (1, bView 3)] := by
  decide +kernel

theorem relation0_zero : Zero (combine (fun j => lift (B j))
    [(1, 0), (-1, 1), (-1, 2), (1, 3)]) := by
  change Zero (combine (fun j => lift (meaning j)) [(1, bView 0), (-1, bView 1), (-1, bView 2), (1, bView 3)])
  exact zero_of_eq (combine_perm (fun j => lift (meaning j)) root0_goal_perm).symm
    (all_proofs_correct root0 (by decide))

theorem relation0_bound :
    toOriginalView nodes (views (bView 0)) = originalB0 ∧
    toOriginalView nodes (views (bView 1)) = originalB1 ∧
    toOriginalView nodes (views (bView 2)) = originalB2 ∧
    toOriginalView nodes (views (bView 3)) = originalB3 ∧
    Zero (combine (fun j => lift (B j)) [(1, 0), (-1, 1), (-1, 2), (1, 3)]) :=
  ⟨b0_original, b1_original, b2_original, b3_original, relation0_zero⟩

theorem relation0_nat : add (B 0) (B 3) = add (B 1) (B 2) :=
  nat_four_of_signed_zero B 0 1 2 3 relation0_zero

theorem relation0_block (Ap Aq Ar As : Value) :
    originalBlock Ap Aq Ar As (B 0) (B 1) (B 2) (B 3) =
      reducedBlock Ap Aq Ar As (B 0) (B 1) (B 2) :=
  four_term_rewrite_of_signed_zero B 0 1 2 3 Ap Aq Ar As relation0_zero

theorem root1_goal_perm : (proofs root1).goal.Perm [(1, bView 6), (-1, bView 7), (-1, bView 8), (1, bView 9)] := by
  decide +kernel

theorem relation1_zero : Zero (combine (fun j => lift (B j))
    [(1, 6), (-1, 7), (-1, 8), (1, 9)]) := by
  change Zero (combine (fun j => lift (meaning j)) [(1, bView 6), (-1, bView 7), (-1, bView 8), (1, bView 9)])
  exact zero_of_eq (combine_perm (fun j => lift (meaning j)) root1_goal_perm).symm
    (all_proofs_correct root1 (by decide))

theorem relation1_bound :
    toOriginalView nodes (views (bView 6)) = originalB6 ∧
    toOriginalView nodes (views (bView 7)) = originalB7 ∧
    toOriginalView nodes (views (bView 8)) = originalB8 ∧
    toOriginalView nodes (views (bView 9)) = originalB9 ∧
    Zero (combine (fun j => lift (B j)) [(1, 6), (-1, 7), (-1, 8), (1, 9)]) :=
  ⟨b6_original, b7_original, b8_original, b9_original, relation1_zero⟩

theorem relation1_nat : add (B 6) (B 9) = add (B 7) (B 8) :=
  nat_four_of_signed_zero B 6 7 8 9 relation1_zero

theorem relation1_block (Ap Aq Ar As : Value) :
    originalBlock Ap Aq Ar As (B 6) (B 7) (B 8) (B 9) =
      reducedBlock Ap Aq Ar As (B 6) (B 7) (B 8) :=
  four_term_rewrite_of_signed_zero B 6 7 8 9 Ap Aq Ar As relation1_zero

theorem root2_goal_perm : (proofs root2).goal.Perm [(1, bView 11), (-1, bView 12), (-1, bView 13), (1, bView 14)] := by
  decide +kernel

theorem relation2_zero : Zero (combine (fun j => lift (B j))
    [(1, 11), (-1, 12), (-1, 13), (1, 14)]) := by
  change Zero (combine (fun j => lift (meaning j)) [(1, bView 11), (-1, bView 12), (-1, bView 13), (1, bView 14)])
  exact zero_of_eq (combine_perm (fun j => lift (meaning j)) root2_goal_perm).symm
    (all_proofs_correct root2 (by decide))

theorem relation2_bound :
    toOriginalView nodes (views (bView 11)) = originalB11 ∧
    toOriginalView nodes (views (bView 12)) = originalB12 ∧
    toOriginalView nodes (views (bView 13)) = originalB13 ∧
    toOriginalView nodes (views (bView 14)) = originalB14 ∧
    Zero (combine (fun j => lift (B j)) [(1, 11), (-1, 12), (-1, 13), (1, 14)]) :=
  ⟨b11_original, b12_original, b13_original, b14_original, relation2_zero⟩

theorem relation2_nat : add (B 11) (B 14) = add (B 12) (B 13) :=
  nat_four_of_signed_zero B 11 12 13 14 relation2_zero

theorem relation2_block (Ap Aq Ar As : Value) :
    originalBlock Ap Aq Ar As (B 11) (B 12) (B 13) (B 14) =
      reducedBlock Ap Aq Ar As (B 11) (B 12) (B 13) :=
  four_term_rewrite_of_signed_zero B 11 12 13 14 Ap Aq Ar As relation2_zero

theorem root3_goal_perm : (proofs root3).goal.Perm [(1, bView 17), (-1, bView 18), (-1, bView 19), (1, bView 20)] := by
  decide +kernel

theorem relation3_zero : Zero (combine (fun j => lift (B j))
    [(1, 17), (-1, 18), (-1, 19), (1, 20)]) := by
  change Zero (combine (fun j => lift (meaning j)) [(1, bView 17), (-1, bView 18), (-1, bView 19), (1, bView 20)])
  exact zero_of_eq (combine_perm (fun j => lift (meaning j)) root3_goal_perm).symm
    (all_proofs_correct root3 (by decide))

theorem relation3_bound :
    toOriginalView nodes (views (bView 17)) = originalB17 ∧
    toOriginalView nodes (views (bView 18)) = originalB18 ∧
    toOriginalView nodes (views (bView 19)) = originalB19 ∧
    toOriginalView nodes (views (bView 20)) = originalB20 ∧
    Zero (combine (fun j => lift (B j)) [(1, 17), (-1, 18), (-1, 19), (1, 20)]) :=
  ⟨b17_original, b18_original, b19_original, b20_original, relation3_zero⟩

theorem relation3_nat : add (B 17) (B 20) = add (B 18) (B 19) :=
  nat_four_of_signed_zero B 17 18 19 20 relation3_zero

theorem relation3_block (Ap Aq Ar As : Value) :
    originalBlock Ap Aq Ar As (B 17) (B 18) (B 19) (B 20) =
      reducedBlock Ap Aq Ar As (B 17) (B 18) (B 19) :=
  four_term_rewrite_of_signed_zero B 17 18 19 20 Ap Aq Ar As relation3_zero

end ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut

#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.all_proofs_correct
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.root0_goal_perm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation0_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation0_bound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation0_nat
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation0_block
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.root1_goal_perm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation1_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation1_bound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation1_nat
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation1_block
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.root2_goal_perm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation2_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation2_bound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation2_nat
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation2_block
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.root3_goal_perm
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation3_zero
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation3_bound
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation3_nat
#print axioms ADWH.Experiments.Chapter15.ArithmeticCounting.GuardedRelations.FixedCut.relation3_block
