# Concrete guarded identities: accepted Lean proofs

The completed milestone is four ordinary Lean proofs for the exact guarded
functions selected by the completed basis diagnostic:

```text
B0 + B3 = B1 + B2
B6 + B9 = B7 + B8
B11 + B14 = B12 + B13
B17 + B20 = B18 + B19
```

The existing external transcript supplies candidate certificate data. Lean
interprets the source descriptors internally and checks the source links,
views, cofactors, cancellation and both children of every zero-proof split.
Neither the Python producer, its independent replayer, the sampled matrix nor
the adaptive basis algorithm is a theorem premise. File hashes identify the
inputs; they do not establish a mathematical equality.

## Current status

**The four concrete identities and their signed block rewrites are accepted.**
Attempt `complete-07` rebuilt all eight selected generic and concrete modules
under one cumulative 30-second allowance, one CPU, `-j1 -M1024`. Every module
passed. The measured total was **28.019105930 seconds**, with **779,936 KiB** peak
child RSS. All 113 required axiom reports passed; only `propext`,
`Classical.choice`, and `Quot.sound` occur. There was no reuse of compiled
experimental helpers, admitted proof, native decision, or compiler-trust axiom.
Exact sources and controls were unchanged across the gate.

The accepted report is `attempts/complete-07/report.json`, SHA256
`7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`.
Its eight logs record the axiom reports. `RESULTS.md` and `RESULTS.json` give
the current result and its source bindings.

The complete gate includes internal source/cofactor semantics, the generic
signed certificate checker, exact range-composition laws, signed block algebra,
the concrete data, and the final identity module. There are 133 local checks
covering all 866 source descriptors, 909 views, and 332 proof nodes. The proved
adjacent-range composition recovers the original three full-table checker
booleans, including the node-zero condition. Every local check shared the same
gate; no range received a separate time allowance.

The change from the last timeout was solely the literal table page size:
32 entries became 8. The 16-entry checking ranges, their 130 joins, all generic
mathematics, and all concrete theorem statements were unchanged. Independent
layout review verified every ordered entry, lookup interval, default, original
view binding, and root mapping. Profiling supported repeated logical table
lookup as the optimization target; the final successful gate establishes the
actual result without relying on that performance explanation.

The accepted sources and generators are frozen for recovery. There is no reason
to repeat this unchanged gate. `DEVELOPMENT.md` records useful failed outcomes
and the corrected profiling conclusion without requiring their transient trees
in durability checkpoints. The portable `run_gate.py` and `gate-plan.json`
rebuild the entire selected source closure when a new check is needed.

## Data and proof scope

The recorded four-root closure has 332 zero-proof nodes, at most four terms per
state, and one empty terminal. The sixteen original B views use 866 source
descriptors. `API.md` specifies the internally interpreted constant/ite/guard
source, dense links with original-ID correspondence, views, local Boolean
checks and the earlier-proof DAG interface.

The generator extracts existing records and remaps their references. It does
not search for another relation, evaluate the functions or create new
cofactors. The concrete literals retain original IDs and raw child IDs. A
later transfer to a larger source table or the counting factor plan needs an
explicit agreement/equality bridge; matching numeric IDs alone is insufficient.

The accepted signed block law removes one term per identity using a coefficient
such as `Ap - As` over integers. It does not establish nonnegative intermediate
coefficients or justify truncated natural subtraction. A smaller separated
term count has not yet demonstrated a faster complete counter.

The public concrete theorems are `relation0_nat` through `relation3_nat` and
`relation0_block` through `relation3_block` in the `GuardedRelations.FixedCut`
namespace. The natural-valued identities hold for every Boolean assignment.
The block theorems allow arbitrary integer-valued coefficient functions. The
`B` selector binds the sixteen named column slots used by these identities;
its default at other slots is not a formal model of all 35 original columns.

This milestone is neither a Lean rank-31 theorem nor a whole-board count. The
target `BitRepresentation.cqueens 16 = 14772512` remains open. The full accepted
basis diagnostic and its source/result evidence remain in
`../exact-basis-diagnostic/` and the current standalone recovery selection.

The next selected discriminator is the fixed projected-context plan in
`../projected-context-plan/DESIGN.md`. It asks whether the Boolean support of
one outside factor yields much stronger conditional relations. Its acceptance
screen is a complete conditional dimension at most 15 within one 50,000-request
budget and an independent replay. The plan has not yet been executed. Any
counting integration must preserve the original natural weights and establish
an explicit source/factor bridge and a complete small source count before
larger-board scaling.
