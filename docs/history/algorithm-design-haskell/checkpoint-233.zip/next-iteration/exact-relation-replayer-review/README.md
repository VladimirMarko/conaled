# Static review of the independent exact-relation replayer

**Result: no blocking soundness, scheduling or serialization defect found.** This is a source review of the frozen replayer against the final protocol and the producer where exact agreement matters. It is not a semantic test, an accepted transcript, a discovered identity, a Lean theorem or a count result. Neither program was executed or imported during this review. The new review directory lies outside the selected compact checkpoint176 tree.

Reviewed identities:

| Artifact | SHA256 |
| --- | --- |
| `replay/replay_relations.py` | `029ad7a95d6d37c66b53b9d78fb1e3d6a341852eb7596491dda314700c617cbc` |
| `diagnostics/produce_relations.py` | `5c5ba4f6d8a87f9931f6da9fe2d64ff3598aaf1c0c9d7dc3637678efbe817029` |
| `PROTOCOL.md` | `28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147` |

These three paths are within `next-iteration/exact-relation-diagnostic/`. Exact byte bindings also appear in `review.json`.

## Charge and completion discipline

`Journal.call` consumes and checks the expected work start before invoking the local body. Each expected scalar calculation, rational normalization, gcd step, source validation, support/cofactor rule, state/cache comparison and branch therefore has its scheduled ticket first. The replayer does not import the producer, a function evaluator or an algebra package. Raw preparation binds bytes and indexes original node records; selected descriptor interpretation begins only in a charged validation body.

The journal compares complete record field sets and exact JSON values, including the distinction between booleans and integers. Completion references must already exist in the completed-result map. The dependency list retains explicit origins followed by nested child completions in order, including duplicates. A parent cannot consume a child's started-but-unfinished result. Source-validation and zero-state caches publish only after matching completion records.

The cap path is deliberately narrow: it accepts a footer only where the controller expects the next start, with exactly50,000 preceding starts. A footer at an expected completion is rejected. Its operation counts, completion count, pending stack, context, proof outcomes and maxima must match the independently reconstructed prefix; trailing records are rejected. Thus completed candidates may survive a cap, but pending arithmetic or states acquire no result. A completed-batch footer additionally requires all16 frozen proposals and all16 outcomes, with no pending stack.

## Arithmetic and fixed candidate origins

RREF uses the same fixed row/column order while reconstructing the matrix from completed field references. Pivot-row division retains the captured original pivot reference throughout that row. Other-row elimination captures the factor from its completed probe, then uses the current target-cell and pivot-row references. Row swaps preserve both source origins. The final entry checks and the complete record bind the exact current matrix,19 pivot columns and16 free columns.

Rational shortcuts have the specified priority. General operations descend to the exact integer operations and the explicit Euclidean normalization transcript. Divmod requires a positive divisor; denominator sign changes occur before normalization division. Coprimality follows from the checked construction history rather than a hidden gcd pass.

Every candidate retains its prescribed free coordinate, positive denominator-product scaling and exact pivot coefficients. Whole-result WorkIDs and field Refs match the final protocol, including the potentially ambiguous `rref_complete`, `entry_check_refs` and `entry_refs` fields. All proposals finish before any identity checking. A counterexample cannot modify the matrix or candidate batch.

## Original guarded semantics and signed identities

The selected source closure is checked independently for unique definitions, strict prior child IDs, bounded variables/guards, ordered branches and guard/core support disjointness. Node0 must be constant zero. The `maximum` annotation is unused. Each full view preserves both masks and its bare-core identity; selected B support is checked against the fixed Y set.

Cofactoring uses only completed source validations and the actual selected child. A literal is removed only when satisfied; contradiction yields the checked canonical zero. At a branch, the child flat guard is merged with the residual masks, and bare support is derived from that child's checked support. The result removes the selected least variable. No fabricated source node or bare-core-only equality replaces a full view.

Collection compares full views under charged requests, adds signed coefficients in the specified existing-first order and removes only an exact zero coefficient or the checked zero view. Occurrences are not deduplicated as sets. The complete-state cache uses a digest only to select a bucket; every inspected candidate and term is checked explicitly, including mismatches. A hit must name an earlier completed zero proof associated with that cached state. It reuses that ProofID without an alias node.

New zero proofs are created in completion order. A split requires both completed zero children; repeated proof references retain both branch occurrences. Constant terminals use actual original Nat values embedded into exact Int products/sums. A nonzero terminal yields an assignment0 base, and each recorded lift sets or clears the original variable bit. The first complete nonzero path refutes that candidate; a partial path or cap does not. These are pointwise restrictions, so no projection multiplicity is silently dropped.

## Limits of this review

The source agreement was checked statically. There was no arithmetic run, sample evaluation, new fixture, altered certificate, negative-test campaign, resource measurement or compiler run. Physical runtime, actual cap position and candidate outcomes remain unknown. Prefix metadata flags describe the verified portion of a future transcript; they must not be quoted as completion of later phases. Even all16 candidate refutations would not exclude a true linear combination of those sample-null directions.

The separate original source/count and future Lean-checker obligations remain unchanged. Root's complete source/control review and explicit internal execution gate remain prerequisites for the one bounded producer/replay sequence. No selected source or checkpoint file was modified.
