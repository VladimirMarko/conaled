# Checkpoint231 — accepted routing and exact fresh-proof diagnostics

The active user instruction is to complete
`ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512`, work
autonomously, and expose/upload periodic standalone checkpoints. **That stock
Lean theorem and the original installed validating-kernel endpoint remain
open.** This checkpoint preserves concrete fresh execution evidence and
source-reviewed progress without promoting partial attempts to complete passes.

## Actual results newly secured

| Selection | Overall result | Accepted / observed reports | Seconds | Peak KiB |
| --- | --- | ---: | ---: | ---: |
| Original word foundation59 | failed in Routing |21 /37|2.2848216820057132|494336|
| Repaired Routing plus Addition59 | failed in Addition |37 /59|3.49208853100572|509216|
| Combined Interpreter185 | failed in iota proof |8 /185|27.61938600800204|876532|

Every selection was freshly compiled with all selected project/upstream
sources, one cumulative30-second deadline, one CPU/thread/import worker,
1,024-MiB Lean and1,048,576-KiB process-group limits, default recursion and
heartbeats, strict warnings and only propext/Quot.sound/Classical.choice.
No prepared experimental imports, native evaluator or exporter was used.

The prior Foundation134 remains a complete accepted run:134 reports/six
outputs in25.97892414099988seconds,877200KiB. Nothing here supersedes that
actual result or transfers it to a larger unaccepted closure.

### Reusable word routing

Original Routing failed in a missing `by_contra` tactic and a dependent-ite
rewrite. Its source and consumed controls remain immutable. The reviewed repair
uses an explicit case split and conditional simplification, preserving18
headers,15 runtime declaration blocks and16 reports. The next fresh run
accepted all five owners RoutedLookup, IndexedPackets, PackedSwitch, MaskCheck
and WordMajorRouting:37 reports. Its sixth owner, Addition, failed at line233:
`Nat.pow_succ` normalized the goal modulus but not the two residue hypotheses.
The separate minimal correction must normalize those occurrences together.
The actual report rejects all22 Addition roots; three expose error-recovery
sorryAx. No admitted mathematical source was added.

The exact two consumed keys and report bindings are:

- Original59: `e6ec41e51d948b96198439fe0a087cbde78f36124be139d7d27fc5e4448c2ba0`;
  report114994bytes SHA256`cff4aca95f04ea35caa832776daabd1884383573b795f5e93b93ed3b0d6e9c2c`.
- Repaired59: `c34a49f3969cd2e0e3b942c7a03630fa4751fa114c61337173d9f35f35f798ae`;
  report149566bytes SHA256`b9b3cf11b4fad05544902a8c54515ed6374377d23a99911aa7dc519ec7d6d22c`.

Their gate directories are kernel-word-major-foundation and
kernel-word-major-routing-proof-repairs. Each retains the report, raw logs,
permanent marker, root receipt and exact snapshot recovery. They contain125/163
snapshot mappings and10/12 raw logs. The repaired control run function is
literal to the consumed predecessor; the separate third repair scope is
explicit in provenance while the two historical family scopes remain intact.

### Larger actual-cached interpreter

The reviewed assembly combines the entire Foundation proof owner with the
three Trace sources and QueryBridge, changing only explicit internal imports
and comments. The selected Core/Cached sources are unchanged. It contains185
reports across three owners, with38 separate retained review scopes and1374
read-only source/control snapshots. All current sources and controls passed
root independent byte/AST review and metadata preflight before compilation.

Core passed2 reports in10.706477762003487seconds; Cached passed6 in
11.405159952999384seconds. The combined interpreter ran5.061290778001421seconds
and failed only in `KernelCachedNatIotaForward.iota_plain_of_prepared` at
combined-source lines3086–3091. The final reflexivity reduction leaves the
actual recursor-rule and empty-level comparison branches; twelve simplifier
arguments are reported unused. The full177-report owner is rejected, including
otherwise clean reports. No trace/query result is promoted to acceptance.

Consumed key:
`6d1c0f24fe1c4f55b520bf9e52b95884dc9e964065a107d0ebc1fcc89fe6370d`.
Report1027241bytes SHA256
`a8ab666d2f7d52d02248b3f9447c0dd8102309d7ed702f24b9bbcb1e655ce45e`.
Recovery680911bytes SHA256
`5ecaf7378613fced1420e2559a90ccecad6259a2dff866e6610f648aa04c61ea`.
Root receipt1628bytes SHA256
`b06d5414d7cd8d86f66480f3471c1f1a5278a0e6b45388f57cb7056d6a2f7e55`.
Six raw logs and the read-only permanent marker remain. Dedicated complete
saved-result readers are separate and unexecuted; these recoveries establish
literal preservation of actual snapshots and evidence.

## New source/interface status

| Package | Status at this cut | Exact scope |
| --- | --- | --- |
| Interpreter assembly | source/control review passed; actual owner failed |1305/1306;185 reports|
| Eventual installed guards | full independent source review; uncompiled |1347/1350;22 reports|
| Eventual record composition | full independent source review; uncompiled |1380/1381;4 reports|
| WordMajorAddition | full source review; actual owner failed |68/69;22 reports|
| WordMajorRouting proof repair | full source/control review; actual five-owner prefix passed |76/77;16 new reports|
| WordMajor integration | author frozen; independent review pending |139;26 reports|
| Eventual pending certifier | author frozen; independent review pending |1545;two sources|
| Whole-word adjacency | author frozen; independent review pending |184;19 reports|

RecordComposition4 constructs its own finite trace and knot bound, preserves
general lookup depth, and connects the exact six-literal evaluator call to the
actual original pending operation. For16 it uses callback99998/depth0 and the
proved expression bound1516. The result is still parametric FirstOrderNat;
14772512 is neither assumed nor proved. Complete pins, shape/binder conditions,
actual restricted lookup, original fuel100000 and original checkPending from{}
remain. Its individual-file prospective graph is35 owners/449 reports/
996754bytes, not a selected gate or a fit claim.

The installed-guard22 source changes only its imported foundation. Its exact
record/program/arithmetic guards remain literal. The new pending certifier
retains canonical NumericBackend/directBackend, evaluates six inputs before
comparing a record's asserted numeral, and uses the real restricted lookup
view. Its two sources total16807bytes; the prospective graph is40 owners/
500 reports/1052028bytes. The new failed interpreter is explicit dependency
context. A masked numerical backend is not silently selected: two omitted
numerical origins must be restored before the former adapter is complete.

Integration26 proves the closed interior-mask coverage and complete packet
transposition interfaces. Its complete69-bit n6 packet retains the marker,
17 key bits and all51 payload bits, including unused fields. Padding requests
still address node0 and preserve the original validity contract. It remains
source-only and does not silently retarget its original failed Routing owner.
Concrete whole-word adjacency, complete numerical data and full source,
recurrence, terminal, multiplicity, padding and root obligations remain.

## Next work, without resetting consumed evidence

1. Author/review the separate diagnosed iota proof correction and explicit
   physical assembly variant, then one entire fresh interpreter closure.
2. Author/review the separate Addition residue-normalization correction and
   new controls, then one entire fresh six-owner59 closure.
3. Independently review the pending certifier and Integration26. Finish the
   universal whole-word adjacency leaf and its source/control review.
4. Freeze the exact complete n6 substitution graph before any performance
   experiment. Historical n6 successes prepared original ADWH imports outside
   their timed closures. Existing symbolic-primitive and scoped-counting
   repairs already solve the old resource-setting defects; preserve them.
   No prepared timing establishes current all-fresh fit or n16 scalability.
5. Pursue the concrete ground proof and original installed-kernel endpoints
   with their distinct obligations. The retained native reflection acceptance
   is useful evidence but is not the stock numeral theorem or original
   installed/GroupChecked result.

The new whole-word adjacency author package contains six definitions,19 public
and two private proofs,30 exact primary intervals and eight complete SDK copies.
Its checker derives request selectors from the actual stored marker bits and
compares every key/payload bit with the preceding complete packet. Its seven-
owner78-report prospective graph remains not compile-ready because the selected
Addition source failed. Independent source review is pending; no numerical
acceptance is claimed. A later corrected Addition selection needs explicit
provenance rather than a silent source replacement.

New in-progress iota/Addition repairs and n6 census are excluded from this fixed
cut unless explicitly named in its selection review. Sources
and author/reviewer scope arrays already frozen above stay immutable.

## Recovery

All230 selected payload paths remain. The230 publication and clean-restoration
receipt is included. All current actual report/snapshot bindings were compared
to their literal canonical bytes, and the new selection is checked for exact
historical aliases and retained pinned SDK copies. The explicit storage guard
is chosen from the measured selection and changes no mathematical limit.

The archive contains sources, reviews, controls, manifests, logs and markers.
It omits SDK binaries, compiled objects, duplicate attempt input/source/build
trees, full textbook and complete upstream metatheory. Runtime restoration uses
the existing exact pins. A clean archive verifier establishes byte recovery;
it neither reruns the mathematical attempts nor accepts uncompiled proofs.
