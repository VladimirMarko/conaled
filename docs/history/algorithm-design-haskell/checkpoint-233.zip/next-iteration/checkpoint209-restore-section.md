## Checkpoint 209: accepted masked native evaluator

The latest snapshot is `adwh-lean-209-masked-evaluator-native-accepted.zip`. It retains all checkpoint 208 payload paths and the newly accepted masked evaluator result. The complete 22-module, 141-report proof/C/link/native workload passed in 25.57449162499688seconds. The actual original-source n16 call took 13.22057051298907seconds and printed the canonical ACCEPT. The stock Lean numeral theorem and optimized validating-kernel installation remain open.

The successful attempt's report, 48 logs, exact control/source reviews, permanent marker, 59 canonical snapshot mappings and two actual generated C files are retained under `next-iteration/uint64-masked-count-lintfix/`. The earlier failed masked worker, its raw warning and marker are retained under `uint64-masked-nat-checker/`. Keep the old failed-worker snapshot at its actual `native-gate/attempts/complete-01/source/UInt64MaskedCount.lean` path; the new gate explicitly binds that file.

The new complete legacy-selector attempt also remains a failure with 56 accepted prefix reports and empty final-module logs. Its exact 15 snapshot mappings, 126 bindings, 6 logs and 4 output identities are retained. Root's live and source-only saved-evidence audits passed for this failure and the original masked warning failure. After extraction, these read-only commands require no compiler or earlier ZIP:

```text
python3 -I next-iteration/uint64-masked-nat-checker/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-legacy-core-selector/audit_saved_result.py --source-only
```

A separate new-success auditor is being prepared; consult its exact saved status before claiming it ran. Root's actual native-gate preflight, run and final postchecks are already preserved. Canonical source/evidence recovery is distinct from rebuilding executable proof objects. All complete native artifacts have exact hashes; binaries are omitted. New live compilation requires the pinned runtime and validated original-only dependency materialization, while all selected experimental proof/code dependencies remain fresh in the same unchanged resource budget.

The reviewed whole-count source assembly is uncompiled and does not inherit acceptance from any base prefix. Read the latest continuation for the shared-iota proof-cost revision and actual pending-check cache integration obligations. The actual upload and clean-restoration receipt for 208 is included; a postpublication receipt for 209 belongs to a later checkpoint.

