# Cached cost120: common deadline reached; 71 accepted prefix reports

Root independently reviewed the new complete controls and passed their metadata
preflight, then executed the selection once under the unchanged resource policy.
The complete attempt failed at the common wall deadline after
30.265804238999408 seconds, peak902180KiB. It accepted71 reports from the first
four fresh modules. Syntax emitted no report or diagnostic before termination;
BulkBound and LiteralForward were not started. There is no evidence here of a
Syntax proof error. No complete120 acceptance follows from the accepted prefix.

| Fresh module | Seconds | Result | Accepted reports |
| --- | ---: | --- | ---: |
| KernelCompactCore | 13.635718599000029 | passed | 1 |
| KernelCachedForward | 13.587641752999843 | passed | 25 |
| KernelCachedStableForward | 0.4307403000002523 | passed | 20 |
| KernelCachedHelperDirect | 0.7592982400001347 | passed | 25 |
| KernelCachedSyntaxCorrespondence | 1.570265426998958 | deadline, exit -9 | 0 |

The report has229601bytes and SHA256
`90af5dd72031f041a5c7a8674ad7f039cc5d59e1f7f3120e3b0172ab9bb3d828`.
The consumed source/policy key is
`3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5`.
All source/control/compiler/runtime/snapshot/log/marker integrity checks passed;
only the resource/module completion obligation failed. Both Syntax logs are empty.

The presentation-only Core source is accepted as a prefix in its actual current
context, including its observer report. This attempt provides no useful measured
base-cost improvement: Core plus Cached took about27.22seconds, leaving too
little time for the remaining closure. Sharing the Syntax zero-count case did
not receive enough time to be judged. Neither source alteration changes the
actual evaluator algorithms or relaxes the proof/resource policy.

Root verified all225 frozen snapshots against canonical source/control bytes,
ten raw logs and the permanent marker. SNAPSHOT-RECOVERY.json retains exact
canonical mappings for standalone recovery without duplicate input/build trees.
The dedicated complete saved-result reader is pending. All historical attempts,
sources and separate reviews remain unchanged. This selection is consumed;
never retry it unchanged or substitute prepared experimental objects.

The separate pure177 closure is accepted in22.027658245000566seconds. Its result
is conditional on exact program/arithmetic/recursor pins and concerns the pure
reducer. It supplies stable semantic backing, not cached-success or an installed
record proof. The original numeral theorem remains open.

Next: a substantive, explicitly reviewed reduction of the base source/proof
closure, preserving actual operational definitions and all selected dependencies;
then actual syntax/Bulk/Literal and the further operational leaves. Keep the
true-prefix, installed annotation, complete fixed-fuel original record and
validating-kernel integration obligations explicit. Publish the standalone
checkpoint and continue authorized work afterward.
