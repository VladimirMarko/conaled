# Independent root review: complete cached cost120 gate

Root independently read the complete new runner diff, full protocol and authoring
note, source-selection and separate-review manifest fields, every new preflight
branch and overlay validator, and the execution/acceptance/finalizer section.
The gate author is nat_only_gap_review; this is independent of that author.
The Core210 and Syntax214 source reviews were already completed independently
by root and remain exact separate scopes.

Root AST-parsed both runners without importing them. Twenty-one functions are
literal unchanged; verify_observer_syntax_overlay, preflight and run have the
reviewed changes, and verify_cost_overlays is the sole new function. The actual
18 recorded text edits reconstruct the runner forward and inverse. The complete
snapshot, marker, child-execution, acceptance and finalizer section is literal
unchanged:8059bytes including all three trailing newlines, SHA256
cec07e096bfc72a55b5f06065ae722705f8e7c0fbf166281906625d4718a2c58.
The author correspondence records8058bytes and d026f37710ceaf9c89a049a70a9b1fc232b7a4e3f04db112188183d4cc30153c,
which excludes the final separator newline before def main. Root's first
metadata-only comparison expected the complete8059bytes to match that shorter
binding and stopped; the precise one-newline boundary was then independently
checked. No runner/source/manifest was changed and no compiler ran during that
comparison. The metadata preflight passed before this note was written.

All seven selected source and217control/context identities were independently
rehash-checked. Only source indices0and4 differ from the consumed120selection;
the complete new source size is637855bytes, with120ordered distinct roots and
14required ordinary artifacts. The old ten source-review scopes and consumed
71-report timeout are preserved; the two cost overlays are separate. Full
source-map, source-guard, historical failure, compiler/runtime and ordered axiom
checks remain. No newly authored arithmetic, Nat, beta/delta or prefix leaf is
selected. The source/policy fingerprint remains independent of controls and
paths; the old120marker directory is added to the no-retry search.

The new preflight checks exact Core display-only omissions, Syntax proof-only
sharing, historical owner selection, root review/inventory counts and identities,
all underlying forward/inverse maps, and the actual earlier timeout boundary.
The run changes outside its literal enforcement section are only the additional
predecessor marker search, authorship and narrowly descriptive report fields.
The single cumulative30-second interval,singleCPU/thread,1GiB resident cap,
default resources,fresh selected experimental/upstream dependency closure,
exact outputs and permitted propext/Quot.sound/Classical.choice set are unchanged.
The result leaves installed,whole-query,GroupChecked and stock numeral flags
false; module-level acceptance cannot be promoted after a later failure.

Reviewed controls:
- run_gate.py:103528bytes,SHA256706acbb38dc5129f2e63f637e6828afc8fa994183a6f6024ad977408346647a2
- source-manifest.json:466619bytes,SHA256d3db0d88fdb63e6cf70c27b81e5d7251223f3f2ecb136d3630ba7cf10c5a5e19
- PROTOCOL.md:15162bytes,SHA256014cb95b03bd3b60b1c87c24237dd4c4f82e4e7d00a9e40a5fdadb0970e75111
- AUTHORING.md:3776bytes,SHA2569de6176fe79b3cc85e06b1cd9bebc8bf77741c5e0ae8cfc793a78733d3cdfa66
- CONTROL-CORRESPONDENCE.json:33065bytes,SHA256efbcea4dc10788530ee6ec2df7284de85672322ae6c3e872087264e1b8e90d33

Root's metadata-only preflight passed:7modules,120roots,14outputs,225snapshots,
no prepared objects; key3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5.
Proceed with one fresh complete run under the already-authorized policy.
This review records no mathematical acceptance or timing improvement. Preserve
the consumed key and all evidence regardless of result; never retry unchanged.
