# Actual branch-selector and local-loop composition

**Status: source-only author preparation, uncompiled; no gate selected.**
`source/KernelBranchComposition.lean` contains eight proposed public roots.
They use the real ConLeche `Expr`, `whnfCore`, `whnfLoop`, `whnf`, native
operation table and stored-definition guards. No compiler, counter, native
program, exporter, checker, gate or preflight was executed by the author.

The author is `regression_audit`. Existing Natrec, Bool, Delta, StructuralHead,
source-template and source-counter files are unchanged. Their independent
reviews and accepted results retain their own scopes; in particular the
operational Natrec dependency is not yet accepted.

## The new source-specific step

The actual branch body tests `Nat.beq cursor 0`. A true test returns literal
zero. A false test adds these exact two source subexpressions:

1. The child-count function applied to the three update expressions using
   `low modulus cursor`, the original left modulus, OR operations and right
   shift.
2. The predecessor branch function applied to
   `cursor - low modulus cursor`.

The new public syntax aliases `childApplication`, `previousApplication`
and `branchAddition` expand to precisely those existing source subtrees.
They introduce no alternative expression datatype, evaluation semantics,
source program or machine-word approximation.

The condition run is derived from the actual cursor run and the unchanged
primitive table, including the actual `natOpStored` guard and stored Bool
constructors. Zero and nonzero Nat values supply the table equation inside
the proof. No public theorem assumes the result of the condition, addition,
selector or current branch call.

For a nonempty cursor, the sum is derived from actual full-WHNF runs of its
two exact operands. The source-specific successor theorem fixes the
predecessor operand to `branchesRec ... (natExpr n)` while its conclusion
concerns fuel `n + 1`. The predecessor is therefore the actual smaller-fuel
source expression. The child-count function remains an explicit closed
expression; the later outer-depth induction must provide its run contract.

The zero-cursor theorem needs neither child-count nor predecessor execution.
It still requires syntactic closedness of the unselected addition because
the imported actual Bool beta-composition theorem retains that guard.

## Premises and the noncircular induction they support

The local composition has the following operational inputs:

| Input | Actual expression | Future source of the evidence |
|---|---|---|
| Cursor run | The supplied cursor expression | Scalar composition from the source cursor and state expressions |
| Child-count run, only for a nonzero cursor | `childApplication modulus child left columns right cursor` | Outer-depth induction, after proving actual runs of the three arithmetic update arguments |
| Predecessor run, only for a nonzero cursor | `previousApplication modulus (branchesRec ... (natExpr n)) cursor` | Inner-fuel induction at `n`, after proving the actual rest-cursor run |
| Closed captures | Modulus, child, left, columns and right; plus cursor and predecessor syntax where traversed | The corresponding syntactic closedness lemmas and source construction |
| Stored operation/basis pins | The actual Nat/Bool records read by the reducer | The future installed-source and basis-guard discharge |

The intended inner induction quantifies over a **closed cursor expression
and its actual Nat-valued run**, rather than only literal cursor syntax.
Its predecessor hypothesis can then be instantiated at the exact unevaluated
rest-cursor expression. Likewise, the outer-depth hypothesis must quantify
over closed state expressions with actual Nat-valued runs, so the child
application can retain the exported update syntax instead of silently
replacing it by literals.

The natural recurrence is already established by the accepted ordinary
Lean source connection. `StructuralNatReference.branches_succ` has exactly
the two sum operands above, and `count_succ` supplies the smaller-depth
child. Its universal equalities to `FirstOrderNat`, followed by
`FirstOrderNat.SourceBridge.count_eq_source` and `cqueens_eq`, connect that
recurrence to the actual ADWH source counter. The present module does not
re-prove or numerically evaluate that recurrence. The remaining operational
induction must identify its result using those equations.

A generic local composition lemma can be misused by supplying circular run
premises. This proposal does not claim to eliminate that possibility for
arbitrary expressions. Its source-specific successor statement fixes the
proper predecessor syntax, and the whole proof still needs the explicit
outer-depth/inner-fuel induction to justify both recursive inputs. There is
no `RunsAbove` premise for the current selector or branch application.

## Separate knot and local-loop bounds

Write

`B(L,R) = max 1 (max 3 (max L R))`.

The cursor comparison starts from a proved cursor threshold `C` and the
literal-zero threshold 2. Its full-WHNF threshold is `T(C) = B(C,2) + 1`.
The exact knot formulas retained in the source are:

- Empty selector: `E(C) = max (max T(C) 1 + 7) 1`.
- Nonempty selector: `N(C,A,P) = max (max T(C) 3 + 7) B(A,P)`.
- Transfer from the actual branch-recursion application:
  `H(S) = max 10 (max 5 S)`.

They come directly from the public Bool, scalar and same-head interfaces.
No generic fuel-monotonicity or desired-whole-run premise is substituted for
an actual child run. The final full-WHNF entry adds one knot level.

The local budget is constant across the branch-fuel input:

| Path | Local loop iterations needed |
|---|---:|
| Zero branch fuel, after its actual head reduction | 1 |
| Successor fuel and empty cursor | 2 |
| Successor fuel and nonempty cursor | 3 |

The addition uses two iterations: one to produce the scalar and one to
finish it. The ordinary `Bool.casesOn` delta adds one. Transferring between
the branch application and its proved identical selector head preserves a
positive local budget. Arithmetic and recursive child operands call the
actual full-WHNF entry point, which starts its own existing local loop;
their work is not deducted from the parent's three iterations.

The three full-WHNF corollaries discharge their 1/2/3 bounds against the
unchanged `whnfLoopFuel` definition. They do not change its value or impose a
new input-dependent loop limit. These are uncompiled proof claims, not
resource measurements.

For later source wrappers, one additional ordinary branch-definition delta
would make the corresponding local bound 4. The outer count selector and
count/evaluate wrappers suggest further small constant additions. Those
wrapper and count bounds are not proved here. The useful result of this
step is that inner branch fuel itself does not increase the local bound;
the whole-fold proof still needs to establish its finite knot threshold.

## Proposed public roots

The two selector roots are `loopRunsAbove_branchSelection_zero` and
`loopRunsAbove_branchSelection_nonzero`. They are reusable local composition
statements for exact source subexpressions.

Three source-specific loop roots cover zero fuel, successor fuel with an
empty cursor, and successor fuel with a nonempty cursor:
`loopRunsAbove_branchesApply_zero`,
`loopRunsAbove_branchesApply_succ_zero`, and
`loopRunsAbove_branchesApply_succ_nonzero`.

The corresponding three `runsAbove_branchesApply_*` roots enter actual full
WHNF only after proving the fixed local budget is sufficient. Each axiom
print follows its theorem; any future failed module leaves all its reports
unaccepted under the usual gate.

## Fresh closure and trust boundary

This module imports `KernelStructuralHead` and `KernelDeltaSteps`. With the
previous branch-head planning base, that is a prospective **34 modules,
101 printed roots and 152 default artifacts**. This is not a selected gate.
Any later selected closure must bind the chosen source variants and rebuild
all new mathematical dependencies together under the unchanged cumulative
30-second, one-CPU/thread, 1-GiB policy with default heartbeat and recursion
settings. There is no compiled-import exemption.

The installed Nat, Bool and program-body pins remain open, as do annotation
and let-substitution correctness, the source wrappers, arithmetic update
run lemmas, both full operational fold inductions, the licensed cached
reducer installation, and the concrete stock theorem. External native
`ACCEPT` evidence is not a premise of this source proof.
