import KernelStructuralHead
import KernelDeltaSteps

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual branch-selector composition

The condition and addition use the existing reducer's primitive table. In
the nonempty case, the only recursive run premises are the exact child-count
application and the predecessor-branch application. The public branch-step
theorems fix that predecessor at one smaller branch-fuel literal.

The local WHNF loop uses two iterations for an addition and one more for the
ordinary Bool.casesOn delta. Child operands invoke the actual full-WHNF entry
point and start its unchanged local loop. Knot thresholds remain separate.

This is source-only preparation. It does not discharge the smaller-call
premises by induction, install any source pins, or assert a numerical result.
-/

namespace ADWH.Experiments.Chapter15.KernelBranchComposition

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (HeadRunsAbove RunsAbove NatRecPins app2 app3 one)
open KernelBoolSelector (BoolPins LoopRunsAbove boolExpr)
open KernelScalarSteps (NatOperation ScalarResult)
open KernelStructuralBodies
open KernelStructuralHead (BranchParametersClosed)

/-- These are exactly the two operands of the source branch addition. -/
def childApplication (modulus child left columns right cursor : Expr) : Expr :=
  app3 child (nextLeft modulus left (low modulus cursor))
    (nextColumns columns (low modulus cursor))
    (nextRight right (low modulus cursor))

def previousApplication (modulus previous cursor : Expr) : Expr :=
  .app previous (binary natSubName cursor (low modulus cursor))

def branchAddition (modulus child left columns right previous cursor : Expr) : Expr :=
  binary natAddName (childApplication modulus child left columns right cursor)
    (previousApplication modulus previous cursor)

/-- Knot arithmetic only; these definitions do not evaluate expressions. -/
def binaryThreshold (left right : Nat) : Nat :=
  Nat.max 1 (Nat.max 3 (Nat.max left right))

def testThreshold (cursor : Nat) : Nat := binaryThreshold cursor 2 + 1

def emptySelectorThreshold (cursor : Nat) : Nat :=
  Nat.max (Nat.max (testThreshold cursor) 1 + 7) 1

def nonemptySelectorThreshold (cursor child previous : Nat) : Nat :=
  Nat.max (Nat.max (testThreshold cursor) 3 + 7) (binaryThreshold child previous)

def branchThreshold (selector : Nat) : Nat := Nat.max 10 (Nat.max 5 selector)

private theorem head_literal (env : Env) (n : Nat) :
    HeadRunsAbove env (natExpr n) (natExpr n) 1 := by
  intro fuel depth enough
  have shape : fuel = (fuel - 1) + 1 := by omega
  rw [shape]
  all_goals rfl

private theorem runs_literal (env : Env) (n : Nat) :
    RunsAbove env (natExpr n) (natExpr n) 2 := by
  intro fuel depth enough
  have shape : fuel = (fuel - 2) + 2 := by omega
  rw [shape]
  all_goals exact KernelLowOperation.whnf_nat_literal env (fuel - 2) depth n

private theorem head_binary (env : Env) (name : ConLeche.Name) (left right : Expr)
    (stored : natOpStored env name = true) :
    HeadRunsAbove env (binary name left right) (binary name left right) 3 := by
  intro fuel depth enough
  have shape : fuel = (fuel - 3) + 3 := by omega
  rw [shape]
  all_goals exact KernelScalarSteps.whnfCore_binary env (fuel - 3) depth name left right stored

private theorem boolean_normal (env : Env) (pins : BoolPins env) (value : Bool) :
    ScalarResult env (boolExpr value) := by
  cases value with
  | false => exact Or.inr ⟨boolFalseName, pins.falseVal, 0, 0, rfl, pins.falseStored⟩
  | true => exact Or.inr ⟨boolTrueName, pins.trueVal, 0, 0, rfl, pins.trueStored⟩

private theorem test_closed (cursor : Expr)
    (closed : cursor.looseBVarsBounded 0 = true) :
    (binary natBeqName cursor (natExpr 0)).looseBVarsBounded 0 = true := by
  change ((true && cursor.looseBVarsBounded 0) && true) = true
  rw [closed]
  all_goals rfl

private theorem addition_closed (modulus child left columns right previous cursor : Expr)
    (closed : BranchParametersClosed modulus child left columns right)
    (previousClosed : previous.looseBVarsBounded 0 = true)
    (cursorClosed : cursor.looseBVarsBounded 0 = true) :
    (branchAddition modulus child left columns right previous cursor).looseBVarsBounded 0 =
      true := by
  simp [branchAddition, childApplication, previousApplication,
    nextLeft, nextColumns, nextRight, low, binary, natExpr, app3, app2,
    Expr.looseBVarsBounded, closed.modulus_closed, closed.child_closed,
    closed.left_closed, closed.columns_closed, closed.right_closed,
    previousClosed, cursorClosed]

private theorem head_branchSelection (env : Env) (pins : BoolPins env)
    (modulus child left columns right previous cursor : Expr) :
    HeadRunsAbove env (branchSelection modulus child left columns right previous cursor)
      (branchSelection modulus child left columns right previous cursor) 5 := by
  let addition := binary natAddName
    (app3 child (nextLeft modulus left (low modulus cursor))
      (nextColumns columns (low modulus cursor)) (nextRight right (low modulus cursor)))
    (.app previous (binary natSubName cursor (low modulus cursor)))
  exact KernelDefinitionSpines.headRunsAbove_definition_spine env
    KernelBoolSelector.casesName [one]
    [boolMotive, binary natBeqName cursor (natExpr 0), addition, natExpr 0]
    pins.casesVal pins.casesRawRhs .abbrev pins.casesStored

/-- The table equation here is private and is supplied below by exact zero
or nonzero Nat equality. It is not a premise of a public branch theorem. -/
private theorem runs_cursor_test (env : Env) (pins : BoolPins env)
    (cursor : Expr) (value threshold : Nat) (answer : Bool)
    (stored : natOpStored env natBeqName = true)
    (cursorRun : RunsAbove env cursor (natExpr value) threshold)
    (table : natOpResult natBeqName value 0 = some (boolExpr answer)) :
    RunsAbove env (binary natBeqName cursor (natExpr 0)) (boolExpr answer)
      (testThreshold threshold) := by
  have operation : NatOperation natBeqName :=
    Or.inr (Or.inr (Or.inr (Or.inr (Or.inl rfl))))
  have loop := KernelBoolSelector.loopRunsAbove_binary env
    (binary natBeqName cursor (natExpr 0)) cursor (natExpr 0) (boolExpr answer)
    natBeqName value 0 3 threshold 2 operation stored
    (head_binary env natBeqName cursor (natExpr 0) stored)
    cursorRun (runs_literal env 0) table (boolean_normal env pins answer)
  exact KernelBoolSelector.runsAbove_of_loop env _ _ (binaryThreshold threshold 2) 2
    loop (by unfold whnfLoopFuel; omega)

private theorem loop_addition (env : Env)
    (modulus child left columns right previous cursor : Expr)
    (childValue previousValue childThreshold previousThreshold : Nat)
    (stored : natOpStored env natAddName = true)
    (childRun : RunsAbove env (childApplication modulus child left columns right cursor)
      (natExpr childValue) childThreshold)
    (previousRun : RunsAbove env (previousApplication modulus previous cursor)
      (natExpr previousValue) previousThreshold) :
    LoopRunsAbove env (branchAddition modulus child left columns right previous cursor)
      (natExpr (childValue + previousValue))
      (binaryThreshold childThreshold previousThreshold) 2 :=
  KernelBoolSelector.loopRunsAbove_binary env
    (branchAddition modulus child left columns right previous cursor)
    (childApplication modulus child left columns right cursor)
    (previousApplication modulus previous cursor) (natExpr (childValue + previousValue))
    natAddName childValue previousValue 3 childThreshold previousThreshold
    (Or.inl rfl) stored
    (head_binary env natAddName (childApplication modulus child left columns right cursor)
      (previousApplication modulus previous cursor) stored)
    childRun previousRun rfl (Or.inl ⟨childValue + previousValue, rfl⟩)

/-- An empty cursor needs no child-count or predecessor-branch run. The
unselected addition must still satisfy the actual closed-substitution guard. -/
theorem loopRunsAbove_branchSelection_zero (env : Env) (pins : BoolPins env)
    (modulus child left columns right previous cursor : Expr) (cursorThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (previousClosed : previous.looseBVarsBounded 0 = true)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (beqStored : natOpStored env natBeqName = true)
    (cursorRun : RunsAbove env cursor (natExpr 0) cursorThreshold) :
    LoopRunsAbove env (branchSelection modulus child left columns right previous cursor)
      (natExpr 0) (emptySelectorThreshold cursorThreshold) 2 := by
  have testRun := runs_cursor_test env pins cursor 0 cursorThreshold true
    beqStored cursorRun rfl
  have branchLoop := KernelBoolSelector.loopRunsAbove_scalar env
    (natExpr 0) (natExpr 0) 1 (head_literal env 0) (Or.inl ⟨0, rfl⟩)
  exact KernelBoolSelector.loopRunsAbove_cases env pins boolMotive
    (binary natBeqName cursor (natExpr 0))
    (branchAddition modulus child left columns right previous cursor) (natExpr 0)
    (natExpr 0) (natExpr 0) true (testThreshold cursorThreshold) 1 1 1
    rfl (test_closed cursor cursorClosed)
    (addition_closed modulus child left columns right previous cursor closed
      previousClosed cursorClosed)
    testRun (head_literal env 0) branchLoop (by omega)

#print axioms loopRunsAbove_branchSelection_zero

/-- The only recursive premises are runs of the exact two source addition
operands. The current selector or enclosing branch call is not a premise. -/
theorem loopRunsAbove_branchSelection_nonzero (env : Env) (pins : BoolPins env)
    (modulus child left columns right previous cursor : Expr)
    (cursorValue childValue previousValue : Nat)
    (cursorThreshold childThreshold previousThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (previousClosed : previous.looseBVarsBounded 0 = true)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (nonzero : cursorValue ≠ 0)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (cursorRun : RunsAbove env cursor (natExpr cursorValue) cursorThreshold)
    (childRun : RunsAbove env (childApplication modulus child left columns right cursor)
      (natExpr childValue) childThreshold)
    (previousRun : RunsAbove env (previousApplication modulus previous cursor)
      (natExpr previousValue) previousThreshold) :
    LoopRunsAbove env (branchSelection modulus child left columns right previous cursor)
      (natExpr (childValue + previousValue))
      (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold) 3 := by
  have table : natOpResult natBeqName cursorValue 0 = some (boolExpr false) := by
    change some (.const (if cursorValue = 0 then boolTrueName else boolFalseName) []) = _
    rw [ite_eq_right nonzero]
    all_goals rfl
  have testRun := runs_cursor_test env pins cursor cursorValue cursorThreshold false
    beqStored cursorRun table
  have branchLoop := loop_addition env modulus child left columns right previous cursor
    childValue previousValue childThreshold previousThreshold addStored childRun previousRun
  have branchHead := head_binary env natAddName
    (childApplication modulus child left columns right cursor)
    (previousApplication modulus previous cursor) addStored
  exact KernelBoolSelector.loopRunsAbove_cases env pins boolMotive
    (binary natBeqName cursor (natExpr 0))
    (branchAddition modulus child left columns right previous cursor) (natExpr 0)
    (branchAddition modulus child left columns right previous cursor)
    (natExpr (childValue + previousValue)) false (testThreshold cursorThreshold) 3
    (binaryThreshold childThreshold previousThreshold) 2
    rfl (test_closed cursor cursorClosed)
    (addition_closed modulus child left columns right previous cursor closed
      previousClosed cursorClosed)
    testRun branchHead branchLoop (by omega)

#print axioms loopRunsAbove_branchSelection_nonzero

/-- Zero branch fuel finishes in one actual local iteration after its head
reduction, independently of the cursor or any recursive child. -/
theorem loopRunsAbove_branchesApply_zero (env : Env) (pins : NatRecPins env)
    (modulus child left columns right cursor : Expr) :
    LoopRunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr 0)) cursor)
      (natExpr 0) 8 1 :=
  KernelBoolSelector.loopRunsAbove_scalar env _ (natExpr 0) 8
    (KernelStructuralHead.headRunsAbove_branchesApply_zero env pins
      modulus child left columns right cursor) (Or.inl ⟨0, rfl⟩)

#print axioms loopRunsAbove_branchesApply_zero

/-- The empty-cursor successor case transfers through the actual recursor
and cursor beta heads without spending another local loop iteration. -/
theorem loopRunsAbove_branchesApply_succ_zero (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (modulus child left columns right cursor : Expr)
    (n cursorThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (beqStored : natOpStored env natBeqName = true)
    (cursorRun : RunsAbove env cursor (natExpr 0) cursorThreshold) :
    LoopRunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
      (natExpr 0) (branchThreshold (emptySelectorThreshold cursorThreshold)) 2 := by
  let previous := branchesRec modulus child left columns right (natExpr n)
  let selection := branchSelection modulus child left columns right previous cursor
  have previousClosed : previous.looseBVarsBounded 0 = true :=
    KernelStructuralHead.branchesRec_closed modulus child left columns right n closed
  have loop := loopRunsAbove_branchSelection_zero env boolPins
    modulus child left columns right previous cursor cursorThreshold closed
    previousClosed cursorClosed beqStored cursorRun
  exact KernelDeltaSteps.loopRunsAbove_of_same_head env
    (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
    selection selection (natExpr 0) 10 5 (emptySelectorThreshold cursorThreshold) 2
    (KernelStructuralHead.headRunsAbove_branchesApply_succ env natPins boolPins
      modulus child left columns right cursor n closed)
    (head_branchSelection env boolPins modulus child left columns right previous cursor) loop

#print axioms loopRunsAbove_branchesApply_succ_zero

/-- A genuine source-specific successor step: the predecessor premise is
the same branch recursor at fuel n, applied to the exact source rest cursor.
Its child-count premise retains the exact unevaluated state-update arguments. -/
theorem loopRunsAbove_branchesApply_succ_nonzero (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (modulus child left columns right cursor : Expr)
    (n cursorValue childValue previousValue : Nat)
    (cursorThreshold childThreshold previousThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (nonzero : cursorValue ≠ 0)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (cursorRun : RunsAbove env cursor (natExpr cursorValue) cursorThreshold)
    (childRun : RunsAbove env (childApplication modulus child left columns right cursor)
      (natExpr childValue) childThreshold)
    (previousRun : RunsAbove env
      (previousApplication modulus
        (branchesRec modulus child left columns right (natExpr n)) cursor)
      (natExpr previousValue) previousThreshold) :
    LoopRunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
      (natExpr (childValue + previousValue))
      (branchThreshold
        (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold)) 3 := by
  let previous := branchesRec modulus child left columns right (natExpr n)
  let selection := branchSelection modulus child left columns right previous cursor
  have previousClosed : previous.looseBVarsBounded 0 = true :=
    KernelStructuralHead.branchesRec_closed modulus child left columns right n closed
  have loop := loopRunsAbove_branchSelection_nonzero env boolPins
    modulus child left columns right previous cursor cursorValue childValue previousValue
    cursorThreshold childThreshold previousThreshold closed previousClosed cursorClosed
    nonzero beqStored addStored cursorRun childRun previousRun
  exact KernelDeltaSteps.loopRunsAbove_of_same_head env
    (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
    selection selection (natExpr (childValue + previousValue)) 10 5
    (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold) 3
    (KernelStructuralHead.headRunsAbove_branchesApply_succ env natPins boolPins
      modulus child left columns right cursor n closed)
    (head_branchSelection env boolPins modulus child left columns right previous cursor) loop

#print axioms loopRunsAbove_branchesApply_succ_nonzero

theorem runsAbove_branchesApply_zero (env : Env) (pins : NatRecPins env)
    (modulus child left columns right cursor : Expr) :
    RunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr 0)) cursor)
      (natExpr 0) 9 :=
  KernelBoolSelector.runsAbove_of_loop env _ (natExpr 0) 8 1
    (loopRunsAbove_branchesApply_zero env pins modulus child left columns right cursor)
    (by unfold whnfLoopFuel; omega)

#print axioms runsAbove_branchesApply_zero

theorem runsAbove_branchesApply_succ_zero (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (modulus child left columns right cursor : Expr)
    (n cursorThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (beqStored : natOpStored env natBeqName = true)
    (cursorRun : RunsAbove env cursor (natExpr 0) cursorThreshold) :
    RunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
      (natExpr 0) (branchThreshold (emptySelectorThreshold cursorThreshold) + 1) :=
  KernelBoolSelector.runsAbove_of_loop env _ (natExpr 0)
    (branchThreshold (emptySelectorThreshold cursorThreshold)) 2
    (loopRunsAbove_branchesApply_succ_zero env natPins boolPins
      modulus child left columns right cursor n cursorThreshold
      closed cursorClosed beqStored cursorRun)
    (by unfold whnfLoopFuel; omega)

#print axioms runsAbove_branchesApply_succ_zero

theorem runsAbove_branchesApply_succ_nonzero (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (modulus child left columns right cursor : Expr)
    (n cursorValue childValue previousValue : Nat)
    (cursorThreshold childThreshold previousThreshold : Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (nonzero : cursorValue ≠ 0)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (cursorRun : RunsAbove env cursor (natExpr cursorValue) cursorThreshold)
    (childRun : RunsAbove env (childApplication modulus child left columns right cursor)
      (natExpr childValue) childThreshold)
    (previousRun : RunsAbove env
      (previousApplication modulus
        (branchesRec modulus child left columns right (natExpr n)) cursor)
      (natExpr previousValue) previousThreshold) :
    RunsAbove env
      (.app (branchesRec modulus child left columns right (natExpr (n + 1))) cursor)
      (natExpr (childValue + previousValue))
      (branchThreshold
        (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold) + 1) :=
  KernelBoolSelector.runsAbove_of_loop env _ (natExpr (childValue + previousValue))
    (branchThreshold
      (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold)) 3
    (loopRunsAbove_branchesApply_succ_nonzero env natPins boolPins
      modulus child left columns right cursor n cursorValue childValue previousValue
      cursorThreshold childThreshold previousThreshold closed cursorClosed nonzero
      beqStored addStored cursorRun childRun previousRun)
    (by unfold whnfLoopFuel; omega)

#print axioms runsAbove_branchesApply_succ_nonzero

end ADWH.Experiments.Chapter15.KernelBranchComposition
