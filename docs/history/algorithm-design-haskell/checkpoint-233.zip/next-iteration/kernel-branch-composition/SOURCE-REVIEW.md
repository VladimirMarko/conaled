# Independent review: actual branch selection and local-loop composition

**Passed source-only mathematical review; uncompiled, with no gate selected.**
Root reviewed the source authored by regression_audit. No Lean, gate,
preflight, counter, exporter or native program was run for this review.
The check consisted of reading the complete proof source and its actual
public dependencies, plus exact hash, header, copied-proof and policy checks.
No missing mathematical premise was identified. Elaboration, kernel checking
and resource compliance still require the complete fresh gate.

## Frozen source and direct provenance

The source is 20,391 bytes, SHA256
`11027ee18168d3a98f256efae7f49778c42517301774cbf90d79ea3b5b780778`.
It imports KernelStructuralHead and KernelDeltaSteps, with eight public roots
and nine private supporting statements. All eight public and nine private
headers match the inventory. The two copied proof bodies match their exact
StructuralHead origins, including the documented terminal-newline convention.
All 21 author input bindings were checked against the actual files. The
independent audit binds those inputs, the candidate and the inventory: 23
distinct direct inputs in total.

Root corrected one documentation word: childApplication, previousApplication
and branchAddition are public definitions, not private aliases. No Lean source
was changed. PLAN is now 8,563 bytes, SHA256
`d4787435a7d602ba22c9841af50ba829cfa6aa1b818bbf21b82985583be37ca8`;
the inventory is 21,539 bytes, SHA256
`a5798e515d06fba216f4bb274c859f45fac9981af798483982915eb4bc1332b3`.

The direct dependency reviews are source evidence only. Natrec05 remains a
failed complete attempt. Bool's separate historical review uses retained04
provenance. Neither is promoted to acceptance here. A future selection must
bind one consistent actual closure and freshly compile it in full.

## Exact source subexpressions and noncircular premises

The candidate's three public syntax definitions expand to the actual branch
template's child application, predecessor application and addition. The child
receives the exact next-left, next-columns and next-right expressions, each
using the unchanged low-bit expression. The predecessor receives precisely
the subtraction of that low-bit expression from the original cursor. No
argument expression is replaced by a literal merely from a mathematical
value equality.

The selector test is computed by the existing actual natOpResult table for
Nat.beq, with the actual stored-operation guard and stored Bool constructor
facts. Its zero equation is definitional. The nonzero equation uses the
explicit cursorValue ≠ 0 premise to select Bool.false. No public theorem asks
the caller to supply the Boolean test's result as an unchecked table answer.

The addition proof invokes the existing actual binary composition theorem
and its two child full-WHNF runs. Its result is childValue + previousValue
through the fixed addition table, without an expected count or whole-call
result premise. The zero-cursor path requires no recursive execution premise.

The general selector interface permits an arbitrary predecessor expression.
The source-specific successor interface fixes it to the same branchesRec at
fuel n while the conclusion is at n + 1. This is the proper predecessor
syntax for a future fuel induction. The other recursive premise is exactly
the source child-count application, to be supplied by the outer-depth
induction. These local theorems do not themselves establish that outer
induction or discharge arbitrary child runs. They contain no run premise
for the current selector or current successor branch application.

## Closedness and heads

BranchParametersClosed supplies the five capture closedness facts. Cursor
closedness is a separate premise. The actual predecessor closedness follows
from the source-specific branchesRec_closed theorem at fuel n. These facts
discharge the existing Bool composition theorem's substitution requirements,
including the unselected addition on the zero-cursor path. They do not assert
semantic typing or an installation invariant for the environment.

The head of the actual four-argument Bool.casesOn call is provided by the
generic definition-spine theorem using BoolPins.casesStored. The branch
application's head is provided by the reviewed StructuralHead theorem.
KernelDeltaSteps.loopRunsAbove_of_same_head then transfers the actual loop
run between those two expressions with their proved common head. No generic
fuel monotonicity, head idempotence or successful enclosing run is assumed.

## Knot fuel and the fixed local loop

The arithmetic threshold B(L,R) is max 1 (max 3 (max L R)). The comparison
has full-WHNF threshold B(C,2) + 1. The selector thresholds are exactly those
obtained from loopRunsAbove_cases: max(max(test, selected-head) + 7,
selected-loop-knot). The branch transfer takes max 10 (max 5 selector).
The three full-WHNF corollaries add the one knot level required by
runsAbove_of_loop. These calculations were checked against the actual
dependency statements, not inferred from a timing or an abstract evaluator.

The local loop needs one iteration for zero branch fuel, two for an empty
cursor at successor fuel, and three for a nonempty cursor. The last path
composes two iterations for addition with one ordinary casesOn delta. The
same-head transfer preserves a positive local budget. Recursive and
arithmetic operands enter the actual full-WHNF function, whose own defined
local loop starts afresh; the three iterations do not bound the total tree.
Each final corollary proves its constant bound against the unchanged
whnfLoopFuel. No resource or mathematical fuel option is increased.

## Remaining obligations and checks

The comment-masked source contains only the three strict options, the two
declared imports and eight ordered axiom prints. It contains no admission,
new axiom, unsafe/partial code, native decision, external implementation or
executable elaborator command. This lexical policy check is not compilation.

The 34-module / 101-root / 152-default-artifact census is expressly a planning
census for the earlier physical layout. It is not a selected gate and gives
no dependency reuse exemption; a bundled layout must state its own physical
units while preserving the full mathematical closure.

The installed seven-argument branch wrapper, count heads and wrappers,
arithmetic child evidence, finite branch/depth inductions, source/annotation
pin discharge, actual checker integration and concrete original numeral
remain open. The retained native count is not a premise of any theorem here.
