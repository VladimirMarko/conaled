# Actual arithmetic child normalization

Prepared source only. This module has not been compiled or selected for a
mathematical gate. Its Bool, recursor and structural-body dependencies remain
unaccepted as complete closures. No count or native program has been run.

The next whole-fold proof must evaluate actual arithmetic operand expressions,
including expressions created by earlier source beta substitutions. Replacing
those expressions with literals merely because they have the same mathematical
value would skip a reduction obligation. `NatRuns` instead records an actual
full-WHNF run above an existential knot-fuel threshold at every ambient depth.

`natRuns_binary` composes two independent operand witnesses using the existing
`KernelScalarSteps.whnf_binary_of_runs`, its actual binary head theorem, and
the existing fourteen-name operation table. Its chosen threshold is the
maximum of the two child thresholds plus four. The scalar theorem already
proves the local-loop budget requirement against the unchanged reducer.
This new layer does not alter that budget or claim it bounds the recursion tree.

Eight proposed public roots cover literals, general binary composition, the
actual low-bit expression, all three next-state expressions, the actual
available-mask expression and the wrapper's power-of-two modulus. The state
and cursor operations accept arbitrary natural values, with no positivity,
board validity or expected-answer assumption. Nat subtraction and modulo keep
their existing behavior at arbitrary operands, including zero. The modulus
lemma additionally requires width ≤ 16,777,216, exactly the existing native
power-table cutoff. Above it that table declines; an unbounded modulus result
would require a separate ordinary-definition proof and is not claimed.

Each composed expression keeps its actual input `ConLeche.Expr` operands.
The operational guards inspect the existing reducer's stored-operation test.
They do not establish correct installation or semantic validity of an arbitrary
environment. This is neither a new expression interpreter nor an acceleration
rule, and it proves no recursive whole-call result by assumption.

The two later finite inductions can obtain individual witnesses for the finitely
many child calls made at one step and take their maxima. They need not assume
one fuel bound simultaneously for all natural states of a higher-order child.
The predecessor and outer-depth calls must still be justified by the proper
smaller induction hypotheses. General subtraction composition also supplies
the cursor-rest expression through `natRuns_binary`.

No existing source was modified. The inventory binds the exact direct source
and API provenance. Independent source review and one complete fresh gate,
including all selected dependencies under the unchanged limits, are required
before any acceptance claim.
