import KernelStructuralBodies

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual arithmetic child computations with individual fuel witnesses

NatRuns abbreviates an existential threshold for the existing actual full
ConLeche WHNF. It is not another evaluator or a denotation of expressions.
Every operand retains its own expression and its own actual run witness.
The finite composition chooses a maximum of those thresholds; it never
requires a uniform threshold over all states of a recursive child function.

The exact stored-operation guards are operational premises of the actual
reducer. They do not assert installation validity. These sources are prepared
for independent review and have not been compiled.
-/

namespace ADWH.Experiments.Chapter15.KernelArithmeticRuns

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (RunsAbove)
open KernelScalarSteps (NatOperation)

/-- An actual full-WHNF result, uniform above one threshold and at every
ambient depth. Different expressions may have different thresholds. -/
def NatRuns (env : Env) (e : Expr) (value : Nat) : Prop :=
  ∃ threshold, RunsAbove env e (natExpr value) threshold

/-- Exactly the arithmetic guards used by the source's state/cursor updates.
The Boolean and addition guards of the fold selection are separate. -/
structure ArithmeticPins (env : Env) : Prop where
  sub : natOpStored env natSubName = true
  mod : natOpStored env natModName = true
  land : natOpStored env natLandName = true
  lor : natOpStored env natLorName = true
  mul : natOpStored env natMulName = true
  shiftRight : natOpStored env natShiftRightName = true
  pow : natOpStored env natPowName = true

theorem natRuns_literal (env : Env) (value : Nat) :
    NatRuns env (natExpr value) value := by
  refine ⟨2, ?_⟩
  intro fuel depth enough
  have shape : fuel = (fuel - 2) + 2 := by omega
  rw [shape]
  all_goals exact KernelLowOperation.whnf_nat_literal env (fuel - 2) depth value

/-- Composition through the unchanged fourteen-name native-operation table.
The table equation is a fixed reducer equation, not a whole-call result. -/
theorem natRuns_binary (env : Env) (name : ConLeche.Name) (left right : Expr)
    (a b value : Nat) (operation : NatOperation name)
    (stored : natOpStored env name = true)
    (leftRun : NatRuns env left a) (rightRun : NatRuns env right b)
    (table : natOpResult name a b = some (natExpr value)) :
    NatRuns env (binary name left right) value := by
  obtain ⟨leftThreshold, leftAbove⟩ := leftRun
  obtain ⟨rightThreshold, rightAbove⟩ := rightRun
  refine ⟨Nat.max leftThreshold rightThreshold + 4, ?_⟩
  intro fuel depth enough
  have leftMax := Nat.le_max_left leftThreshold rightThreshold
  have rightMax := Nat.le_max_right leftThreshold rightThreshold
  have shape : fuel = (fuel - 4) + 4 := by omega
  have leftEnough : leftThreshold ≤ (fuel - 4) + 3 := by omega
  have rightEnough : rightThreshold ≤ (fuel - 4) + 3 := by omega
  rw [shape]
  exact KernelScalarSteps.whnf_binary_of_runs env (fuel - 4) depth
    (binary name left right) operation stored
    (KernelScalarSteps.whnfCore_binary env (fuel - 4) depth name left right stored)
    (leftAbove ((fuel - 4) + 3) depth leftEnough)
    (rightAbove ((fuel - 4) + 3) depth rightEnough) table
    (Or.inl ⟨value, rfl⟩)

private theorem run_sub (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natSubName left right) (a - b) :=
  natRuns_binary env natSubName left right a b (a - b)
    (Or.inr (Or.inl rfl)) pins.sub hl hr rfl

private theorem run_mod (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natModName left right) (a % b) :=
  natRuns_binary env natModName left right a b (a % b)
    (by simp [NatOperation]) pins.mod hl hr rfl

private theorem run_land (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natLandName left right) (a &&& b) :=
  natRuns_binary env natLandName left right a b (a &&& b)
    (by simp [NatOperation]) pins.land hl hr rfl

private theorem run_lor (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natLorName left right) (a ||| b) :=
  natRuns_binary env natLorName left right a b (a ||| b)
    (by simp [NatOperation]) pins.lor hl hr rfl

private theorem run_mul (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natMulName left right) (a * b) :=
  natRuns_binary env natMulName left right a b (a * b)
    (Or.inr (Or.inr (Or.inl rfl))) pins.mul hl hr rfl

private theorem run_shiftRight (env : Env) (pins : ArithmeticPins env)
    (left right : Expr) (a b : Nat)
    (hl : NatRuns env left a) (hr : NatRuns env right b) :
    NatRuns env (binary natShiftRightName left right) (a >>> b) :=
  natRuns_binary env natShiftRightName left right a b (a >>> b)
    (by simp [NatOperation]) pins.shiftRight hl hr rfl

/-- The bit expression is evaluated with its actual, possibly nonliteral,
modulus and cursor arguments. No range or positive-modulus premise is used. -/
theorem natRuns_low (env : Env) (pins : ArithmeticPins env)
    (modulus cursor : Expr) (m q : Nat)
    (hm : NatRuns env modulus m) (hq : NatRuns env cursor q) :
    NatRuns env (KernelStructuralBodies.low modulus cursor)
      (FirstOrderNat.low m q) := by
  exact run_land env pins _ _ q ((m - q) % m) hq
    (run_mod env pins _ _ (m - q) m
      (run_sub env pins modulus cursor m q hm hq) hm)

theorem natRuns_nextLeft (env : Env) (pins : ArithmeticPins env)
    (modulus left bit : Expr) (m l b : Nat)
    (hm : NatRuns env modulus m) (hl : NatRuns env left l)
    (hb : NatRuns env bit b) :
    NatRuns env (KernelStructuralBodies.nextLeft modulus left bit)
      (((l ||| b) * 2) % m) := by
  exact run_mod env pins _ _ ((l ||| b) * 2) m
    (run_mul env pins _ _ (l ||| b) 2
      (run_lor env pins left bit l b hl hb) (natRuns_literal env 2)) hm

theorem natRuns_nextColumns (env : Env) (pins : ArithmeticPins env)
    (columns bit : Expr) (c b : Nat)
    (hc : NatRuns env columns c) (hb : NatRuns env bit b) :
    NatRuns env (KernelStructuralBodies.nextColumns columns bit) (c ||| b) :=
  run_lor env pins columns bit c b hc hb

theorem natRuns_nextRight (env : Env) (pins : ArithmeticPins env)
    (right bit : Expr) (r b : Nat)
    (hr : NatRuns env right r) (hb : NatRuns env bit b) :
    NatRuns env (KernelStructuralBodies.nextRight right bit) ((r ||| b) >>> 1) := by
  exact run_shiftRight env pins _ _ (r ||| b) 1
    (run_lor env pins right bit r b hr hb) (natRuns_literal env 1)

theorem natRuns_available (env : Env) (pins : ArithmeticPins env)
    (modulus mask left columns right : Expr) (m k l c r : Nat)
    (hm : NatRuns env modulus m) (hk : NatRuns env mask k)
    (hl : NatRuns env left l) (hc : NatRuns env columns c)
    (hr : NatRuns env right r) :
    NatRuns env (KernelStructuralBodies.available modulus mask left columns right)
      (FirstOrderNat.available m k l c r) := by
  exact run_land env pins _ _ (m - 1 - ((l ||| c) ||| r)) k
    (run_sub env pins _ _ (m - 1) ((l ||| c) ||| r)
      (run_sub env pins _ _ m 1 hm (natRuns_literal env 1))
      (run_lor env pins _ _ (l ||| c) r
        (run_lor env pins left columns l c hl hc) hr)) hk

/-- The wrapper's actual power expression; the width is allowed to be an
expression whose own full-WHNF computation has already been proved. -/
theorem natRuns_modulus (env : Env) (pins : ArithmeticPins env)
    (width : Expr) (n : Nat) (hw : NatRuns env width n)
    (supportedExponent : n ≤ 16777216) :
    NatRuns env (binary natPowName (natExpr 2) width) (2 ^ n) := by
  have within : ¬ n > 16777216 := by omega
  have table : natOpResult natPowName 2 n = some (natExpr (2 ^ n)) := by
    change (if n > 16777216 then none else some (natExpr (2 ^ n))) = _
    rw [ite_eq_right within]
  exact natRuns_binary env natPowName (natExpr 2) width 2 n (2 ^ n)
    (by simp [NatOperation]) pins.pow (natRuns_literal env 2) hw table

#print axioms natRuns_literal
#print axioms natRuns_binary
#print axioms natRuns_low
#print axioms natRuns_nextLeft
#print axioms natRuns_nextColumns
#print axioms natRuns_nextRight
#print axioms natRuns_available
#print axioms natRuns_modulus

end ADWH.Experiments.Chapter15.KernelArithmeticRuns
