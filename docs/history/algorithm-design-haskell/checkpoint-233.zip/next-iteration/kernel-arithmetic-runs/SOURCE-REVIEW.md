# Independent source review: actual arithmetic runs

**Result: no remaining mathematical or concrete API blocker was found in
the corrected source. This is a source-only review; the eight new roots
have not been compiled or accepted. No gate is selected.**

Root authored `KernelArithmeticRuns.lean`. The reviewer is
`regression_audit`, who did not edit that module or its author controls.
The reviewer authored parts of the earlier imported low/Natrec work; this
review is independent of the new arithmetic module's authorship, not a new
independent certification of every dependency. Their previous reviews,
failures and accepted scopes remain distinct.

The reviewed source is 8,715 bytes, SHA-256
`75cc6d28fa111980611098f623ea7e5138202e487259170ca17551d8fadbfcfe`.
Its inventory is 8,031 bytes, SHA-256
`f283c7eb8688320c027004f1137a81dd6fe6570d15e00354812309eb1839db26`.
All nine author-provenance inputs, the source and the inventory resolve to
their recorded bytes. The companion audit records the eleven distinct
project bindings, all eight public and six private statement headers, and
the exact ordered axiom-print inventory.

## Actual run predicate and fuel composition

`NatRuns env e value` is precisely an existential knot threshold for the
existing `RunsAbove env e (natExpr value)`. The latter quantifies over every
larger knot fuel and every ambient depth for actual `whnf .verified`.
There is no second evaluator, denotation function or assumption that an
expression may be replaced by a mathematically equal literal.

The binary theorem eliminates the two operand existentials separately and
chooses `max leftThreshold rightThreshold + 4`. For any fuel above that
threshold, `fuel = (fuel - 4) + 4`, and both child thresholds are at most
`(fuel - 4) + 3`. These are exactly the levels used by the existing scalar
composition theorem. Its binary head theorem supplies the actual head run;
the two original child witnesses supply actual full-WHNF runs; the fixed
native-operation table supplies the result. A Nat literal satisfies the
scalar normal-form condition.

The chosen witness is uniform in ambient depth because each child witness
already has that quantification. Different expressions may retain different
witnesses. Nothing assumes one threshold simultaneously covers all states
of a higher-order recursive child. This is the appropriate interface for
the later finite outer-depth and inner-fuel inductions.

The general table premise is a concrete equation of the existing reducer's
`natOpResult`, accompanied by its exact fourteen-name whitelist and
`natOpStored` guard. It does not assert a source-program or whole-fold run.
The source-specific arithmetic lemmas discharge the relevant table
equations themselves. The scalar theorem already handles its local-loop
budget; this module does not alter `whnfLoopFuel` or interpret it as a bound
on total recursive work.

## Exact operand and source formula preservation

The low proof composes subtraction of the actual cursor expression from
the actual modulus expression, modulus by that same modulus expression,
and AND with the original cursor expression. Its result is exactly
`FirstOrderNat.low m q`. Neither the cursor nor modulus is syntactically
replaced by a literal in the expression being normalized.

The three next-state proofs retain the actual OR operands, multiplication
by literal 2, the explicit modulus on the left component, and the right
shift by literal 1. There is no additional right-mask clipping. The
available-mask proof retains both saturated Nat subtractions, the source's
left-associated `(left OR columns) OR right`, and the final mask AND.
These expression trees agree directly with `KernelStructuralBodies` and
the corresponding `FirstOrderNat` formulas.

All of these state and cursor claims apply to arbitrary Nat operands.
No positive-modulus, board-validity, word-width, result-bound or expected
answer premise was inserted. In particular, subtraction and modulo keep
their ordinary Nat behavior when the modulus is zero. Their operational
stored-function guards remain explicit.

## Power-table restriction found and corrected before execution

The initial uncompiled modulus draft supplied its table equation by `rfl`
for arbitrary exponents. That was not justified by the actual reducer:
`CoreDefs.natOpResult` returns `none` for `Nat.pow` when the exponent is
greater than **16,777,216**. The source-only review identified this blocker;
root independently confirmed it in the pinned source and corrected the
claim before any execution.

The reviewed `natRuns_modulus` now requires
`supportedExponent : n ≤ 16777216`. Its proof derives the negation of the
actual cutoff test and rewrites the complete table conditional. It therefore
uses the existing fast path only where that path returns a literal. It
does not claim an unbounded power normalization theorem or an unproved
ordinary-definition fallback. The source counter's width 16 falls within
the stated bound; that observation is not a new computed-count premise.

The correction record also replaces the literal proof's trailing `exact`
by `all_goals exact`, so an automatically closed definitional rewrite goal
does not produce an extra-tactic error. The new power proof uses the current
`ite_eq_right` API. The earlier spelling `if_neg` is explicitly deprecated
in the pinned Lean 4.35 `Init/Core.lean` and would conflict with the strict
warning setting. This was likewise corrected before execution.

The two recorded source replacements invert exactly to the initial
8,436-byte draft, SHA-256
`4a0b90cfb9cdc4f7a62d7406ff96e937aefae1159c3190c7a164f876cd3c3b3d`.
The old PLAN is likewise exactly recoverable through its recorded inverse.
No old draft was compiled or accepted, and this review makes no claim about
its compiler diagnostics.

## Proof/API and boundary checks

The whitelist injections for subtraction and multiplication occupy the
correct positions in `NatOperation`. The remaining named operations are
members of the same fourteen-name disjunction. Each private helper applies
the actual scalar API with the original expression operands and their
individual witnesses. The literal theorem uses the accepted low helper's
two-level full-WHNF equation. The source's only options are
`autoImplicit false`, `warningAsError true` and `Elab.async false`.

No admission, new axiom, unsafe implementation, native decision procedure,
partial definition or heartbeat/recursion override appears in the
comment/string-masked source. The eight prints match the eight public roots
in order. No proof term, object, timing result or acceptance is inferred from
these source checks; elaboration still needs a reviewed fresh gate.

The operation guards establish the conditions actually read by the reducer.
They do not prove correct installation or semantic validity of an arbitrary
environment. The candidate also does not establish closedness of arbitrary
operands, the recursive child contracts, either whole-fold induction,
program-body recognition or annotation, a licensed cache rule, or a stock
numerical theorem. Those remain separate obligations. Every selected new
mathematical dependency must be freshly checked under the unchanged policy;
this review supplies no dependency or resource exemption.
