# Diagnosed leading-comment repair of the evaluator extraction

Author: `nat_only_gap_review`. Status: source-only, uncompiled, frozen for
independent root source review. No compiler, gate, metadata preflight, evaluator,
exporter or saved-evidence reader was executed by the author.

## Actual failure and correction

The consumed evaluator-slice120 run failed in its first module with zero observed
and zero accepted reports. The actual diagnostic is:

```
KernelCompactCore.lean:35:0: error: invalid 'import' command, it must be used in the beginning of the file
```

The newly introduced leading notice began with `/-!`. Lean treats that spelling
as a module-documentation command, so the unchanged imports that follow are no
longer at the beginning of the command stream. The notice should be an ordinary
comment. The same leading spelling occurs in the unstarted Cached owner.

This separate overlay changes exactly the first `/-!` to `/-` in each physical
source. Each source loses one byte. The full suffix beginning immediately after
the opener is identical, including all notice text, imports, declarations,
proofs, options and axiom-report commands. The inverse inserts exactly that one
`!` and reconstructs the complete consumed source. No frozen file is overwritten.

| Owner | Consumed bytes | Corrected bytes |
| --- | ---: | ---: |
| KernelCompactCore | 297,743 | 297,742 |
| KernelCachedForward | 207,543 | 207,542 |

PROOF-CORRECTION.json records both exact edits, the complete unchanged suffix
identities and the actual consumed report, marker and diagnostic logs. The name
of this map follows the existing diagnosed-correction convention; these are
comment-header fixes, not changed mathematical proof bodies. Source command
classification changes deliberately so the imports are accepted as imports.

## Scope and preserved evidence

The current mathematical selection remains seven owners / 120 distinct ordered
reports / fourteen ordinary output artifacts. Its corrected source total is
588,571 bytes. Current ownership remains 17 upstream, seven project, 24 logical
origins and 26 segments. All prior omission, presentation, proof-sharing and
source-review scopes remain at their exact earlier bytes. The preceding
evaluator-scope omission and its independent 61-input review are a historical
layer, followed by this separate two-edit repair.

The consumed key is
`1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06`.
Its failed result, permanent marker, all 272 canonical snapshot mappings, two
diagnostic logs and independent control review remain preserved. The retained
failure finished after 0.5471648200000345 seconds with peak 474,440 KiB; this is
an import failure, not a performance measurement of the evaluator closure.
The source inventory binds root's frozen recovery and result documents directly.

Only the diagnosed leading-comment defect is corrected. The actual evaluator
definitions and all selected proofs still require a complete fresh gate. There
is no retry of the consumed source bytes, no changed stage or policy, no extra
diagnostic allowance and no profiler. The default-resource, common-30-second,
one-CPU/thread, 1-GiB and strict three-axiom policy remain unchanged.

This remains an evaluator-only extraction. Its omitted installer and parsed
driver APIs must be restored for later original-driver integration; the comment
repair does not alter or discharge that obligation. No cached whole-query
success, installed environment validity, GroupChecked or stock numeral theorem
is established. Root must independently review the source overlay and successor
controls before the sole complete attempt.
