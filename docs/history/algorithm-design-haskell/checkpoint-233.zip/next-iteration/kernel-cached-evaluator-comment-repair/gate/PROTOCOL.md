# Complete evaluator-scope 120-report gate after diagnosed comment repair

Status: authored for independent root control review; the author has not executed
the runner, a metadata preflight, a compiler, an exporter, a saved-evidence reader
or a native mathematical program. Root alone may perform the metadata preflight
and the one fresh complete run after reviewing the concrete source/control set.

## Current selection and exact source change

Seven ordinary physical modules are selected, in dependency order:

| Module | Reports |
| --- | ---: |
| KernelCompactCore | 1 |
| KernelCachedForward | 25 |
| KernelCachedStableForward | 20 |
| KernelCachedHelperDirect | 25 |
| KernelCachedSyntaxCorrespondence | 11 |
| KernelCachedBulkBound | 30 |
| KernelCachedLiteralForward | 8 |

The required reports are exactly the existing 120 distinct ordered axiom names.
Every selected source is freshly compiled. The only allowed experimental imports
are earlier owners in this order; external ordinary SDK Init/Std imports remain
permitted. No previously prepared experimental objects, cached build directory,
export target, arithmetic, Nat-iota, beta/delta, prefix, generated-scope or
installed-guard leaf is selected. Fourteen ordinary outputs are required: one
olean and one ilean for each of the seven modules. No extension or extra artifact
is silently accepted.

Only the Core and Cached physical sources differ from the consumed cost120
selection. Eight literal omission edits remove 89 explicit named declarations
and 29 intrinsic cached driver-guard result certificates. Every retained byte
outside those edits remains unchanged. After the separate comment-header repair the current total is 588,571 source
bytes, 49,284 fewer than the consumed 637,855-byte cost selection. These counts establish
source scope; they do not establish compilation-time improvement or budget fit.

The omission layer is kernel-cached-evaluator-slice/SOURCE-OMISSIONS.json;
the current owner is then produced by ../PROOF-CORRECTION.json. Both complete old sources
remain available, and the runner checks forward and inverse reconstruction,
offset/text metadata, named declaration start headers, selected report names and
the frozen 25-source consumer census. This census is literal source evidence;
it is not a complete elaborated dependency export or implicit-instance proof.
The complete fresh run is still needed to check actual elaboration and all roots.

All six cached callback families and coreKnotI, all six pure callback families
and coreKnot, the actual CState/cache layout, flushing, helper operations and
constant/recursor metadata remain literal. No new algorithm, noncomputable
modifier, proof term, axiom, native substitution, resource option or profiler is
introduced. The removed Basis/Canon installers and parsed-driver guards are
explicitly unavailable in this evaluator-only owner. Later original Parsed /
Installed / checkPending work must restore the actual omitted declarations and
establish their initialization, guard and installation obligations. This gate
does not claim a complete original checker closure or its native API.

## Current and historical origins

The current scope is 17 upstream plus seven project origins: 24 logical origins
and 26 source segments. Nine whole upstream origins are removed: Basis.Builder,
Basis.Eq, Basis.Nat, Basis.Empty, Basis.False, Basis.Quot, Basis.And, Canon and
Basis. Basis.Names remains. Env, Cached.ExprOpsC and Cached.StateC remain current
origins with explicit partial omissions. The fourteen cached/project segment
labels are unchanged; Core now contains twelve current upstream segments.

The former 26 upstream / 33 logical / 35 segment scope remains exact historical
provenance. Historical whole-origin reconstruction is performed first against
its original owners; the separate omission overlay then produces the current
owners. The manifest and report label these scopes separately. Full original
origin files remain read-only context inputs and are not separately compiled.

All twelve prior independent source-review scopes retain their exact inputs:

| Historical scope | Inputs |
| --- | ---: |
| Original cached bundle | 27 |
| Cached diagnosed correction | 18 |
| Original stable leaf | 17 |
| Stable correction | 12 |
| Helper source | 25 |
| Diagnosed Helper correction | 18 |
| Observer / Syntax correction | 33 |
| Cached proof sharing | 26 |
| Bulk bound | 119 |
| Literal forwarding | 16 |
| Core presentation omission | 210 |
| Syntax count sharing | 214 |

The historical omission root source review has 61 exact inputs and binds the
source author's separate 60-input inventory. The current diagnosed-comment
repair has a separate 32-input independent root review and 31-input author inventory. Neither replaces or rebases an old scope.
Forthcoming operation sources in the 25-file census are context for dependency
review only; the new gate makes no fresh acceptance claim for them or pure177.

## Frozen result and permanent source key

The consumed cost120 source key is
`3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5`.
Its retained report is failed: 71 reports accepted, Syntax killed at the common
deadline, no Syntax diagnostic or report, and no Bulk/Literal process started.
Its complete report, empty Syntax logs, consumed marker, controls and source
selection are pinned. Earlier failed and accepted result scopes remain pinned
at their original boundaries, including the accepted 70-report result.

The immediate consumed omission120 key is
`1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06`.
That run failed at the first Core import with zero observed and accepted reports:
the new leading `/-!` notice was a module-documentation command before imports.
The same spelling was present in the unstarted Cached owner. The exact separate
repair changes only each initial `/-!` to `/-`, deleting one byte per owner and
preserving every following byte. Its two variants, failed report, diagnostic
logs, consumed marker, independent control review and 272-snapshot recovery are
bound. The source-command classification is intentionally corrected; no
mathematical body, selected report, import text or source option changes.
The 0.5471648200000345-second parser failure measures no evaluator cost.

The new key is the SHA-256 of canonical JSON containing exactly the permanent
stage `cached-forward-runs-and-licensed`, the unchanged policy object and the
ordered seven module/source hashes. Filenames, metadata, attempt names, source
audit wording, compiler relocation and runner edits do not reset a consumed key.
The runner refuses a consumed key in its own marker directory or any of the seven
historical cached gate directories. The immediate new source change repairs a concrete observed import failure;
no consumed source bytes are retried with diagnostics or changed resources.

## Metadata preflight and control binding

The script requires `--lean` pointing to the pinned Lean 4.35.0 executable.
Without `--run` it performs only the metadata/source/control preflight. It reads
strict JSON with duplicate keys rejected, rejects absolute/escaping/symlinked
context paths, verifies every byte count and SHA-256, and loads only the pinned
resource helper and source guard after checking their hashes. No Lean process,
experimental import, generator, exporter or native mathematical program runs in
that mode. Root alone executes this preflight.

The preflight checks the actual current source manifest, ordered imports,
ordinary module/output contract, selected prints and source option census. It
rejects holes, forbidden trusted shortcuts, resource overrides, executable
elaborator commands and unsupported visibility commands using the pinned source
guard. All historical source maps, proof overlays, exact review inventories,
primary-source contexts, failure reports, current sources, this runner, protocol,
authoring note and exact control-correspondence map are bound in one deduplicated
input union. No selected source may also be a control and no role or path repeats.
The manifest itself is added as a separately hashed snapshot input.

The compiler is pinned to Lean 4.35.0 commit
`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`; binary bytes/hash and all five runtime
libraries are checked. Relocating this identical toolchain is permitted. No
different compiler build, executable or runtime library is accepted.

## One common fresh execution interval

The permanent policy is unchanged: one compiler thread, one CPU affinity,
30 cumulative wall seconds, 1,024 MiB Lean memory and 1,048,576 KiB measured
resident memory. Default heartbeat, recursion and compiler resource options are
retained. `autoImplicit=false`, `warningAsError=true` and `Elab.async=false`
remain enabled; `LEAN_IMPORT_WORKERS=1` and `-j1` preserve the single-thread
process contract. No profiler or diagnostic exceptions are selected.

Root acquires the shared nonblocking compile lock. A new ordinary source/build
directory is created only for an unused attempt and permanent source key. Every
bound source/control is copied to a read-only snapshot and checked. The marker
is created exclusively before the first compiler call. The build search path
contains only the new empty experimental build plus the allowed SDK paths.

The common wall deadline starts before the first compiler and ends after all
child processes, exact artifact census, immutable-input/runtime verification and
CPU-affinity restoration. Every process gets only the remaining time; later
modules cannot reset the clock. Every prefix is freshly recompiled in that same
interval. Snapshot/control/native resource accounting, output collection,
timeout killing, failure classification and final acceptance are copied
literally from the consumed gate's execution block. The control map records the
literal 8,058-byte unchanged block. The author has not executed it.

## Acceptance and claims

Each module is all-or-nothing. Exit zero, the exact ordered required axiom names,
only `propext`, `Quot.sound`, and `Classical.choice`, empty stderr, and no other
stdout text are all required. A printed root from a failed or timed-out module
is observed evidence only and receives zero accepted credit. No warning,
diagnostic, recovered sorryAx, duplicate, missing or extra report is tolerated.

The complete result passes only with all 120 accepted reports, all fourteen
ordinary artifacts, unchanged snapshots/controls/compiler/runtime, no common
time or memory breach and restored affinity. Prior accepted prefixes never
substitute for the fresh current compilation. An early failure terminates the
attempt and consumes the source key; any further attempt requires a concrete
new mathematical source correction or substantive scope change and review.

Even a complete pass establishes only the selected conditional evaluator
interfaces and literal base cases. StableNF/MemoFrame/helper premises remain
as stated. It does not establish an entire cached queens query, real driver
prefix/annotation guards, installed EnvWF, the original GroupChecked bridge or
a stock-Lean numeral theorem. Those integration obligations remain separate.
