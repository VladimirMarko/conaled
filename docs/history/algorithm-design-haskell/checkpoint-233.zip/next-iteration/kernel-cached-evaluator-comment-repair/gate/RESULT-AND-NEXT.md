# Consumed repaired evaluator120 result and next step

The sole root-executed complete gate failed in the Syntax proof module, without
hitting the wall or memory limits. The total interval was28.52848948599967seconds,
peak883,184KiB. Core, Cached, Stable and Helper passed, accepting71 reports and
producing eight ordinary artifacts. Syntax observed11 additional reports but
its module failed, so those reports receive zero accepted credit. Bulk and
Literal were not started. All canonical source, read-only snapshot, control,
runtime, marker and log integrity checks passed.

| Module | Seconds | Status |
| --- | ---: | --- |
| Core | 12.58586298499904 | Passed,1 report |
| Cached | 12.707182587999341 | Passed,25 reports |
| Stable | 0.41557587799979956 | Passed,20 reports |
| Helper | 0.6601776200004679 | Passed,25 reports |
| Syntax | 1.9042559219997202 | Failed,0 accepted reports |

The import-header repair worked. Syntax now reports six exact unsolved goals at
lines50,70,76,82,88,93: the constructor observer equations leave `lpOfData e.data`
versus `e.hasLP` for fvar, app, lambda, forall, let and projection subexpressions.
The failing module's downstream axiom reports include Lean's error-recovery
sorryAx and are rejected; this is not a source admission or accepted theorem.
The actual logs are retained. A separate diagnosed proof repair should unfold
the observer at those exact six proof steps, preserve all theorem statements and
report roots, and receive independent review before a new complete fresh gate.

The full source key is
`cf693905054730e65c5f5dc7b79c8dd6a2544a459ebd689b3b42b1ceb68f5b94`.
The report is306,045bytes, SHA-256
`8e9302670e457e8ca31d31d4ebbed41a6a32e6421ad1b8d25abce813c6a18ad1`.
The recovery map preserves all291 canonical snapshot mappings and ten raw logs.
No duplicate snapshot/build tree is needed for source recovery. A dedicated
complete saved-result reader remains pending; root checked the actual immutable
snapshots and canonical/log identities when constructing this record.

The base pair took25.29304557299838seconds in this run. Reaching the Syntax
module's diagnostics is useful progress, but it does not establish enough room
for Syntax, Bulk, Literal and later integration. Do not retry unchanged, increase
resources or import prepared experimental objects. The source omission removes
original installer/parsed-driver API that a later full checker must restore.
Neither whole-query cached success, actual installed pins/annotations, EnvWF,
original GroupChecked nor the stock numeral theorem is established by this gate.
The separate accepted pure177 proof remains conditional pure backing.
