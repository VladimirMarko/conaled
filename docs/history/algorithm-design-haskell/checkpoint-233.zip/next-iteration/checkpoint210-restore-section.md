## Checkpoint 210: reviewed seeded checker/model and preserved proof failure

The latest standalone snapshot is `adwh-lean-210-seeded-model-bridge-reviewed.zip`.
It retains all checkpoint 209 payload paths, the accepted masked native result
and earlier mathematical achievements. No previous ZIP is required. The stock
numeral theorem and installed validating-kernel acceptance remain open.

The new shared-iota complete-01 is a deadline failure, with 56 accepted
Foundation reports, empty selector logs and no selector outputs. Its exact
source/control reviews, report, six logs, marker and eighteen canonical snapshot
mappings are retained. The consumed source key is not a new execution slot
after restoration. Root's actual live/source-only audit receipts are included.

The dedicated successful masked-native auditor is also now retained, together
with its independent recovery review and root's actual two successful runs.
After extraction, these commands require no compiler, old archive or executable
proof objects:

```text
python3 -I next-iteration/uint64-masked-count-lintfix/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-shared-iota-selector/audit_saved_result.py --source-only
```

Keep the earlier failed masked worker physically at its recorded
`uint64-masked-nat-checker/native-gate/attempts/complete-01/source/UInt64MaskedCount.lean`
path. It is an explicit input of the corrected native gate and saved auditors.

The actual seeded pending checker, automatic query discovery, all-record typed
checking result and adapted installation-model proof are preserved with their
independent source reviews. They are **uncompiled**. Their dependency graph is
recorded exactly, including 509 upstream modules and 114 raw resource-option
occurrences for the model union. That full upstream checkout is an external
source dependency, pinned by repository revision, archive digest and every
relevant module hash. The archive retains the small directly reviewed primary
copies; it does not bundle the full checkout or its compiled metatheory.
This recovery qualification does not exempt any selected future mathematical
dependency from the current complete fresh resource gate.

The separately reviewed masked query overlay must replace, rather than coexist
with, the older source of the same module in any future selection. Read the
latest continuation for the beta-chain sharing hypothesis and the unchanged
policy. The integrated project and accepted ledger remain unchanged.

The exact upload/clean-extraction receipt for checkpoint 209 is included.
A receipt created after publishing 210 belongs to a later checkpoint and is
not retroactively claimed as payload of this archive.
