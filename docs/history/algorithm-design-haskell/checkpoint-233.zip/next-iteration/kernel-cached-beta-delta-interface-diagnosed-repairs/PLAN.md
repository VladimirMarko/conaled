# Diagnosed BetaDelta and ForwardInterface proof repairs

Author: `reflection_evidence_review`. This is a source-only alternate package,
not a gate, compilation result or replacement for any consumed source.

## Actual failure and bounded repair scope

The consumed numeric475 assembly's partial TraceSupport stdout contains 75
captured diagnostic headers. The exact complete captured-log map is retained
separately in `kernel-cached-trace-support-diagnosed-repairs`. This package
addresses its BetaDelta IDs 034–065 and ForwardInterface IDs 066–067: 34
captured headers in nine theorem proof scopes. The whole stream ends later,
mid-goal in NatIota. These counts describe the retained partial stream, not a
complete compiler-error census. TraceSupport's error-recovery theorem reports
were rejected as a whole; no individual report from that owner is accepted
here.

The logical bases are the original reviewed BetaDelta23 and
ForwardInterface14 sources. Their declarations were retained literally in
the consumed assembly except for separately recorded import relocation.
Their physical source ranges were 1357–1878 and 2168–2577 respectively.
This package changes ten exact BetaDelta proof spans and two exact Interface
proof spans. The full map gives forward and inverse edits plus all fourteen
unchanged complementary spans. All 37 theorem headers, all 37 report
commands, the nine definitions, two structures, one inductive proposition,
imports, namespaces, source options and fuel values remain literal.

## Concrete proof repairs

The pinned Bool API distinguishes `Bool.and_eq_true`, an equality of
propositions, from `Bool.and_eq_true_iff`, an Iff. The captured unknown
identifier `Bool.and_eq_true.mp` is repaired by using the actual Iff's `.mp`
at the head-scope projection and the outer binary-scope projection. The same
binary proof's following inner projection uses the identical corrected API;
that latter edit is a same-scope companion after the captured outer failure,
not a separately observed error.

The function-valued StateT skip equation first introduces its actual supplied
state with `funext state`. Its simplification then exposes the actual
Except.pure constructor. The other captured monadic goals already have their
state supplied; explicit Except.pure reduction exposes their name/expression
and state pair before rewriting the actual guard, helper, head or continuation
equations. This affects the iota spine, application head step, both Nat-bypass
branches and indexed delta helper equation. The callbacks and all intermediate
returned states remain exactly those in the existing statements. The proof
does not assume success of a body it is intended to establish.

The definition-head iota exclusion reduces the outer constant constructor
match before rewriting the actual indexed definition lookup. The constant
delta instance supplies the public wscopedB constructor equation explicitly;
the same local scope witness is used at both original scope arguments. The
captured diagnostic points to the nested argument. Reusing that witness at
its outer companion makes the same fact explicit without changing a premise
or proving a stronger result.

## Ownership, evidence and next consumer

The old source reviews retain their exact original inputs. The new map binds
both original author inventories and independent reviews, the consumed
assembly source/map and evidence, the complete captured-log map, actual
selected Core/Cached operational intervals and pinned SDK source copies.
The two new logical sources still have their original imports. A later
physical selection must relocate those imports through an exact separately
reviewed assembly map; this package does not silently claim a new full
five-owner selection.

Arithmetic and NatIota repairs and their full combined TraceSupport assembly
are owned by `nat_only_gap_review`. They are separate from these twelve edits.
The current package does not modify those logical sources, the consumed
physical owner, any old source/control/review, or the active/repaired Wrapper
selection.

No new computational declaration, annotation premise, environment pin,
expected numeral, current-query success assumption or budget relaxation is
introduced. The existing explicit StableNF/HelperCache/auxiliary invariants,
pure backing, actual helper results, beta metadata licenses, prefix lookup
and actual knot/local-loop budgets remain unchanged. No complete-query,
installed-annotation, EnvWF/CSOK, original GroupChecked or stock numeral
claim follows from this source correction.

The author ran no compiler, gate, metadata preflight, exporter, retained
generator, mathematical evaluator/native program, profiler or dedicated
saved-result reader. Static source reads, byte/hash comparisons and artifact
authoring are the only operations. A future complete fresh gate remains under
the unchanged cumulative thirty-second, one-CPU/thread, 1-GiB,
default-resource, strict-warning and permitted-axiom policy. These proof
changes make no measured speedup or resource-fit claim.
