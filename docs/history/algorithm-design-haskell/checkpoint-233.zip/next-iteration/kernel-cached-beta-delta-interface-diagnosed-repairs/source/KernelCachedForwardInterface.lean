import KernelCachedBetaDeltaForward
import KernelCachedArithmeticForward
import KernelCachedHelperFrame

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Uniform interfaces for actual cached head and full reduction

Knot fuel and the two local loop budgets remain separate. Each interface
quantifies over the actual supplied state and preserves both independent
invariants and an explicit auxiliary predicate. Scope is required at the
actual memo key; no closedness or visibility transport is inferred.

Threshold weakening restricts an existing universal quantifier. It is not
monotonicity of arbitrary successful runs. Pure backing remains a distinct
obligation, and every auxiliary frame used by a real state update is explicit.
This source does not prove a generic pure-to-cached simulation or whole query.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedForwardInterface

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedStableForward
open KernelCachedHelperDirect
open KernelCachedHelperFrame
open KernelCachedBetaDeltaForward
open KernelCachedArithmeticForward
open KernelCachedLiteralForward (natLiteral)

/-- The auxiliary predicate may carry the wrapper's inference, annotation,
cheap-head, definitional-equality and level-cache obligations. -/
def ForwardWith (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (action : CheckCM Expr) (value : Expr) : Prop :=
  ∀ state, StableNF mode environment state → HelperCache fe state → auxiliary state →
    ∃ final, action state = .ok (value, final) ∧
      StableNF mode environment final ∧ HelperCache fe final ∧ auxiliary final

def FullRunsAbove (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (threshold : Nat) : Prop :=
  ∀ fuel depth, threshold ≤ fuel → Expr.wscopedB depth query = true →
    ForwardWith mode environment fe auxiliary
      ((coreKnotI mode fe fuel).whnf depth query) value

def HeadRunsAbove (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (threshold : Nat) : Prop :=
  ∀ fuel depth, threshold ≤ fuel → Expr.wscopedB depth query = true →
    ForwardWith mode environment fe auxiliary
      ((coreKnotI mode fe fuel).whnfCore false depth query) value

def FullLoopRunsAbove (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr)
    (knotThreshold localThreshold : Nat) : Prop :=
  ∀ fuel depth budget, knotThreshold ≤ fuel → localThreshold ≤ budget →
    Expr.wscopedB depth query = true →
    ForwardWith mode environment fe auxiliary
      (whnfLoopI (coreKnotI mode fe fuel) fe depth budget query) value

def HeadLoopRunsAbove (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr)
    (knotThreshold localThreshold : Nat) : Prop :=
  ∀ fuel depth budget, knotThreshold ≤ fuel → localThreshold ≤ budget →
    Expr.wscopedB depth query = true →
    ForwardWith mode environment fe auxiliary
      (whnfCoreLoopI mode (coreKnotI mode fe fuel) fe false depth budget query) value

/-- Pure backing and actual cached execution are distinct obligations. -/
structure FullCertificate (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (threshold : Nat) : Prop where
  backing : StableWhnf mode environment query value
  cached : FullRunsAbove mode environment fe auxiliary query value threshold

structure HeadCertificate (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (threshold : Nat) : Prop where
  backing : StableHead mode environment query value
  cached : HeadRunsAbove mode environment fe auxiliary query value threshold

theorem memo_frame_and (left right : CState → Prop)
    (leftFrame : MemoFrame left) (rightFrame : MemoFrame right) :
    MemoFrame (fun state => left state ∧ right state) := by
  constructor
  · intro state query value valid
    exact ⟨leftFrame.whnfC state query value valid.1,
      rightFrame.whnfC state query value valid.2⟩
  · intro state query value valid
    exact ⟨leftFrame.whnfCoreC state query value valid.1,
      rightFrame.whnfCoreC state query value valid.2⟩

theorem full_runs_weaken (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (lower upper : Nat)
    (run : FullRunsAbove mode environment fe auxiliary query value lower)
    (larger : lower ≤ upper) :
    FullRunsAbove mode environment fe auxiliary query value upper := by
  intro fuel depth enough queryScoped
  exact run fuel depth (Nat.le_trans larger enough) queryScoped

theorem head_runs_weaken (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr) (lower upper : Nat)
    (run : HeadRunsAbove mode environment fe auxiliary query value lower)
    (larger : lower ≤ upper) :
    HeadRunsAbove mode environment fe auxiliary query value upper := by
  intro fuel depth enough queryScoped
  exact run fuel depth (Nat.le_trans larger enough) queryScoped

theorem full_loop_runs_weaken (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr)
    (lowerKnot upperKnot lowerLocal upperLocal : Nat)
    (run : FullLoopRunsAbove mode environment fe auxiliary query value lowerKnot lowerLocal)
    (largerKnot : lowerKnot ≤ upperKnot) (largerLocal : lowerLocal ≤ upperLocal) :
    FullLoopRunsAbove mode environment fe auxiliary query value upperKnot upperLocal := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped
  exact run fuel depth budget (Nat.le_trans largerKnot enoughKnot)
    (Nat.le_trans largerLocal enoughLocal) queryScoped

theorem head_loop_runs_weaken (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query value : Expr)
    (lowerKnot upperKnot lowerLocal upperLocal : Nat)
    (run : HeadLoopRunsAbove mode environment fe auxiliary query value lowerKnot lowerLocal)
    (largerKnot : lowerKnot ≤ upperKnot) (largerLocal : lowerLocal ≤ upperLocal) :
    HeadLoopRunsAbove mode environment fe auxiliary query value upperKnot upperLocal := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped
  exact run fuel depth budget (Nat.le_trans largerKnot enoughKnot)
    (Nat.le_trans largerLocal enoughLocal) queryScoped

/-- Close the original full memo only when the proved local bound fits its
unchanged fixed budget. Both actual cache branches preserve the auxiliary. -/
theorem full_runs_of_loop (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (query value : Expr) (knotThreshold localThreshold : Nat)
    (backing : StableWhnf mode environment query value)
    (run : FullLoopRunsAbove mode environment fe auxiliary query value
      knotThreshold localThreshold)
    (withinFixedLoop : localThreshold ≤ whnfLoopFuel) :
    FullRunsAbove mode environment fe auxiliary query value (knotThreshold + 1) := by
  intro fuel depth enough queryScoped state valid helpers auxiliaryValid
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have previous : knotThreshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    apply whnf_forward_of_body mode environment fe predecessor depth query value
      (fun current => HelperCache fe current ∧ auxiliary current)
      (memo_frame_and (HelperCache fe) auxiliary (helper_cache_memo_frame fe) frame)
      backing queryScoped state valid ⟨helpers, auxiliaryValid⟩
    intro _
    exact run predecessor depth whnfLoopFuel previous withinFixedLoop
      queryScoped state valid helpers auxiliaryValid

theorem head_runs_of_loop (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (query value : Expr) (knotThreshold localThreshold : Nat)
    (backing : StableHead mode environment query value)
    (run : HeadLoopRunsAbove mode environment fe auxiliary query value
      knotThreshold localThreshold)
    (withinFixedLoop : localThreshold ≤ whnfCoreLoopFuel) :
    HeadRunsAbove mode environment fe auxiliary query value (knotThreshold + 1) := by
  intro fuel depth enough queryScoped state valid helpers auxiliaryValid
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have previous : knotThreshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    apply head_forward_of_body mode environment fe predecessor depth query value
      (fun current => HelperCache fe current ∧ auxiliary current)
      (memo_frame_and (HelperCache fe) auxiliary (helper_cache_memo_frame fe) frame)
      backing queryScoped state valid ⟨helpers, auxiliaryValid⟩
    intro _
    exact run predecessor depth whnfCoreLoopFuel previous withinFixedLoop
      queryScoped state valid helpers auxiliaryValid

theorem head_loop_runs_atom (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (expression : Expr) (atom : HeadAtom expression) :
    HeadLoopRunsAbove mode environment fe auxiliary expression expression 0 1 := by
  intro fuel depth budget _ enough _ state valid helpers auxiliaryValid
  cases budget with
  | zero => omega
  | succ predecessor =>
    refine ⟨state, ?_, valid, helpers, auxiliaryValid⟩
    change whnfCoreStepI mode (coreKnotI mode fe fuel) fe false depth
      (whnfCoreLoopI mode (coreKnotI mode fe fuel) fe false depth predecessor)
      expression state = .ok (expression, state)
    cases expression <;> try cases atom
    all_goals rfl

theorem head_runs_atom (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (expression : Expr) (atom : HeadAtom expression) :
    HeadRunsAbove mode environment fe auxiliary expression expression 1 := by
  intro fuel depth enough queryScoped state valid helpers auxiliaryValid
  cases fuel with
  | zero => omega
  | succ predecessor =>
    apply head_forward_of_body mode environment fe predecessor depth expression expression
      (fun current => HelperCache fe current ∧ auxiliary current)
      (memo_frame_and (HelperCache fe) auxiliary (helper_cache_memo_frame fe) frame)
      (stable_head_atom mode environment expression atom) queryScoped state valid
      ⟨helpers, auxiliaryValid⟩
    intro _
    exact ⟨state, head_body_atom mode (coreKnotI mode fe predecessor) fe false depth
      expression atom state, valid, helpers, auxiliaryValid⟩

/-- The actual input query need not itself be a literal: its head callback
returns the literal, and that exact callback state is the full-loop result. -/
theorem full_loop_nat_of_head_run (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget number : Nat) (query : Expr) (state final : CState)
    (headRun : callbacks.whnfCore false depth query state =
      .ok (natLiteral number, final)) :
    whnfLoopI callbacks fe depth (budget + 1) query state =
      .ok (natLiteral number, final) := by
  change whnfStepI callbacks fe depth
    (whnfLoopI callbacks fe depth budget) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind]
  all_goals rfl

theorem full_loop_runs_nat (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (query : Expr) (number threshold : Nat)
    (headRun : HeadRunsAbove mode environment fe auxiliary query (natLiteral number)
      threshold) :
    FullLoopRunsAbove mode environment fe auxiliary query (natLiteral number) threshold 1 := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped state valid helpers auxiliaryValid
  cases budget with
  | zero => omega
  | succ predecessor =>
    obtain ⟨final, run, finalValid, finalHelpers, finalAuxiliary⟩ :=
      headRun fuel depth enoughKnot queryScoped state valid helpers auxiliaryValid
    exact ⟨final, full_loop_nat_of_head_run (coreKnotI mode fe fuel) fe depth predecessor
      number query state final run, finalValid, finalHelpers, finalAuxiliary⟩

/-- Licensed bulk beta spends one local iteration. Scope of the actual bulk
reduct and both kinds of state-write frame are explicit premises. -/
theorem head_loop_runs_beta (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (memoFrame : MemoFrame auxiliary)
    (helperFrame : HelperFrame auxiliary)
    (function argument domain body first residual value : Expr) (rest values : List Expr)
    (nextKnot nextLocal : Nat)
    (head : Expr.getAppFn (.app function argument) = .lam domain body ⟨.never⟩)
    (arguments : Expr.getAppArgsC (.app function argument) = first :: rest)
    (licensed : NeverBetaPeels body [first] rest residual values)
    (reductScoped : ∀ depth, Expr.wscopedB depth (.app function argument) = true →
      Expr.wscopedB depth (Expr.instantiateListC residual values 0) = true)
    (next : HeadLoopRunsAbove .verified environment fe auxiliary
      (Expr.instantiateListC residual values 0) value nextKnot nextLocal) :
    HeadLoopRunsAbove .verified environment fe auxiliary (.app function argument) value
      (max 1 nextKnot) (nextLocal + 1) := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped state valid helpers auxiliaryValid
  have headLarge : 1 ≤ fuel := Nat.le_trans (Nat.le_max_left 1 nextKnot) enoughKnot
  have nextLarge : nextKnot ≤ fuel := Nat.le_trans (Nat.le_max_right 1 nextKnot) enoughKnot
  have headScoped := get_app_fn_scoped (.app function argument) depth queryScoped
  rw [head] at headScoped
  cases budget with
  | zero => omega
  | succ predecessor =>
    have nextBudget : nextLocal ≤ predecessor := Nat.le_of_succ_le_succ enoughLocal
    obtain ⟨afterHead, headRun, headValid, headHelpers, headAuxiliary⟩ :=
      head_runs_atom .verified environment fe auxiliary memoFrame
        (.lam domain body ⟨.never⟩) trivial fuel depth headLarge headScoped
        state valid helpers auxiliaryValid
    obtain ⟨afterInst, instRun, instValid, instHelpers, instAuxiliary⟩ :=
      helper_result_stable_with_auxiliary .verified environment fe auxiliary
        (instListM residual values) (Expr.instantiateListC residual values 0)
        afterHead headValid (instListM_correct fe residual values 0 afterHead headHelpers)
        (instListM_preserves auxiliary helperFrame residual values 0) headAuxiliary
    obtain ⟨final, nextRun, finalValid, finalHelpers, finalAuxiliary⟩ :=
      next fuel depth predecessor nextLarge nextBudget (reductScoped depth queryScoped)
        afterInst instValid instHelpers instAuxiliary
    have spineRun : whnfAppI .verified (coreKnotI .verified fe fuel) fe depth
        (whnfCoreLoopI .verified (coreKnotI .verified fe fuel) fe false depth predecessor)
        (.lam domain body ⟨.never⟩) (Expr.getAppArgsC (.app function argument)) afterHead =
        .ok (value, final) := by
      rw [arguments, whnfAppI_never,
        beta_peel_never_equation (coreKnotI .verified fe fuel) fe depth
          (whnfCoreLoopI .verified (coreKnotI .verified fe fuel) fe false depth predecessor)
          body residual [first] rest values licensed]
      simp only [Bind.bind, StateT.bind, instRun, Except.bind]
      all_goals exact nextRun
    refine ⟨final, ?_, finalValid, finalHelpers, finalAuxiliary⟩
    apply head_loop_app_of_runs .verified (coreKnotI .verified fe fuel) fe false depth
      predecessor function argument (.lam domain body ⟨.never⟩) value state afterHead final
    · rw [head]
      exact headRun
    · exact spineRun

/-- Actual indexed delta spends one local full-loop iteration after its head
call. The real helper's returned state starts the recursive continuation. -/
theorem full_loop_runs_delta (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (helperFrame : HelperFrame auxiliary)
    (query head value : Expr) (name : Name) (levels : List Level)
    (constant : ConstantVal) (body : Expr) (hint : ReducibilityHint)
    (headThreshold nextKnot nextLocal : Nat)
    (headForm : Expr.getAppFn head = .const name levels)
    (found : fe.find? name = some (.defnInfo constant body hint))
    (arity : levels.length = constant.levelParams.length)
    (bypass : NatBypass fe head)
    (headRun : HeadRunsAbove mode environment fe auxiliary query head headThreshold)
    (reductScoped : ∀ depth, Expr.wscopedB depth query = true →
      Expr.wscopedB depth (deltaReduct head constant body levels) = true)
    (next : FullLoopRunsAbove mode environment fe auxiliary
      (deltaReduct head constant body levels) value nextKnot nextLocal) :
    FullLoopRunsAbove mode environment fe auxiliary query value
      (max headThreshold nextKnot) (nextLocal + 1) := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped state valid helpers auxiliaryValid
  have headLarge : headThreshold ≤ fuel :=
    Nat.le_trans (Nat.le_max_left headThreshold nextKnot) enoughKnot
  have nextLarge : nextKnot ≤ fuel :=
    Nat.le_trans (Nat.le_max_right headThreshold nextKnot) enoughKnot
  cases budget with
  | zero => omega
  | succ predecessor =>
    have nextBudget : nextLocal ≤ predecessor := Nat.le_of_succ_le_succ enoughLocal
    obtain ⟨afterHead, headEq, headValid, headHelpers, headAuxiliary⟩ :=
      headRun fuel depth headLarge queryScoped state valid helpers auxiliaryValid
    obtain ⟨afterDelta, helperRun, deltaValid, deltaHelpers, deltaAuxiliary⟩ :=
      helper_result_stable_with_auxiliary mode environment fe auxiliary
        (constValAtM fe name name levels)
        (Expr.instLevelParams constant.levelParams levels body) afterHead headValid
        (constValAtM_correct fe name name levels constant body hint afterHead headHelpers found)
        (constValAtM_preserves auxiliary helperFrame fe name name levels) headAuxiliary
    have deltaRun := unfold_definition_of_run fe head name levels constant body hint
      afterHead afterDelta headForm found arity helperRun
    obtain ⟨final, nextRun, finalValid, finalHelpers, finalAuxiliary⟩ :=
      next fuel depth predecessor nextLarge nextBudget (reductScoped depth queryScoped)
        afterDelta deltaValid deltaHelpers deltaAuxiliary
    exact ⟨final, full_loop_delta_of_runs (coreKnotI mode fe fuel) fe depth predecessor
      query head (deltaReduct head constant body levels) value state afterHead afterDelta
      final headEq bypass deltaRun nextRun, finalValid, finalHelpers, finalAuxiliary⟩

/-- Actual native Nat composition. The real head and result-head bodies use
the conjunctive memo frame; only the two operand runs are recursive premises. -/
theorem full_loop_runs_binary (mode : CheckMode) (environment : Env) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (operator : Name) (left right value : Expr) (leftNumber rightNumber : Nat)
    (leftThreshold rightThreshold : Nat)
    (recognized : NatBinaryName operator)
    (stored : natOpStoredF fe operator = true)
    (computed : natOpResult operator leftNumber rightNumber = some value)
    (resultForm : PrimitiveResult fe value)
    (headBacking : StableHead mode environment (binaryApplication operator left right)
      (binaryApplication operator left right))
    (leftRun : FullRunsAbove mode environment fe auxiliary left (natLiteral leftNumber)
      leftThreshold)
    (rightRun : FullRunsAbove mode environment fe auxiliary right (natLiteral rightNumber)
      rightThreshold) :
    FullLoopRunsAbove mode environment fe auxiliary (binaryApplication operator left right)
      value (max 2 (max leftThreshold rightThreshold)) 2 := by
  intro fuel depth budget enoughKnot enoughLocal queryScoped state valid helpers auxiliaryValid
  have positive : 2 ≤ fuel :=
    Nat.le_trans (Nat.le_max_left 2 (max leftThreshold rightThreshold)) enoughKnot
  have childLarge : max leftThreshold rightThreshold ≤ fuel :=
    Nat.le_trans (Nat.le_max_right 2 (max leftThreshold rightThreshold)) enoughKnot
  have leftLarge : leftThreshold ≤ fuel :=
    Nat.le_trans (Nat.le_max_left leftThreshold rightThreshold) childLarge
  have rightLarge : rightThreshold ≤ fuel :=
    Nat.le_trans (Nat.le_max_right leftThreshold rightThreshold) childLarge
  have outer := queryScoped
  change Expr.wscopedB depth (.app (.app (.const operator []) left) right) = true at outer
  rw [Expr.wscopedB] at outer
  have parts := Bool.and_eq_true_iff.mp outer
  have inner := parts.1
  rw [Expr.wscopedB] at inner
  have leftScoped := (Bool.and_eq_true_iff.mp inner).2
  have rightScoped := parts.2
  have combinedFrame := memo_frame_and (HelperCache fe) auxiliary
    (helper_cache_memo_frame fe) frame
  cases fuel with
  | zero => omega
  | succ fuel =>
    cases fuel with
    | zero => omega
    | succ fuel =>
      cases budget with
      | zero => omega
      | succ budget =>
        cases budget with
        | zero => omega
        | succ budget =>
          obtain ⟨afterHead, headRun, headValid, headHelpers, headAuxiliary⟩ :=
            cached_head_binary mode environment fe fuel depth operator left right
              (fun current => HelperCache fe current ∧ auxiliary current) combinedFrame
              stored headBacking queryScoped state valid ⟨helpers, auxiliaryValid⟩
          obtain ⟨afterLeft, leftEq, leftValid, leftHelpers, leftAuxiliary⟩ :=
            leftRun (fuel + 2) depth leftLarge leftScoped afterHead headValid headHelpers
              headAuxiliary
          obtain ⟨afterRight, rightEq, rightValid, rightHelpers, rightAuxiliary⟩ :=
            rightRun (fuel + 2) depth rightLarge rightScoped afterLeft leftValid leftHelpers
              leftAuxiliary
          obtain ⟨final, resultHeadRun, finalValid, finalHelpers, finalAuxiliary⟩ :=
            cached_head_result mode environment fe (fuel + 1) depth value resultForm
              (fun current => HelperCache fe current ∧ auxiliary current) combinedFrame
              afterRight rightValid ⟨rightHelpers, rightAuxiliary⟩
          exact ⟨final, full_loop_binary_of_runs (coreKnotI mode fe (fuel + 2)) fe depth
            budget operator left right leftNumber rightNumber value state afterHead
            afterLeft afterRight final recognized stored computed resultForm headRun
            leftEq rightEq resultHeadRun, finalValid, finalHelpers, finalAuxiliary⟩

#print axioms memo_frame_and
#print axioms full_runs_weaken
#print axioms head_runs_weaken
#print axioms full_loop_runs_weaken
#print axioms head_loop_runs_weaken
#print axioms full_runs_of_loop
#print axioms head_runs_of_loop
#print axioms head_loop_runs_atom
#print axioms head_runs_atom
#print axioms full_loop_nat_of_head_run
#print axioms full_loop_runs_nat
#print axioms head_loop_runs_beta
#print axioms full_loop_runs_delta
#print axioms full_loop_runs_binary

end ADWH.Experiments.Chapter15.KernelCachedForwardInterface
