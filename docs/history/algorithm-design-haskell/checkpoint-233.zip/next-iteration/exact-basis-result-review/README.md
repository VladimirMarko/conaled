# Exact basis: saved result and its scope

The single producer and independent replay completed the fixed 35-column
algorithm. The externally checked basis dimension is **31**, with four complete
global identities over the selected guarded B functions. This is diagnostic
evidence; no Lean identity, rank theorem, n8 count or n16 count was established.

## Metadata audit

The audit passed 118 exact byte-binding checks across 46 files. It checked the
canonical reviewed sources, original/snapshot inputs, execution commands,
artifact hashes, interpreter identity, and the exact producer-certificate to
replay-result pairing. The current summary matches the completed transcript
outputs, phase counts, operation counts, maxima and recorded timings.

| Process | Result | Wall time | Peak RSS |
| --- | --- | ---: | ---: |
| `basis-01` | Completed exact basis, exit 0 | 0.867624396996689 s | 108,660 KiB |
| `basis-replay-01` | Independent replay passed, exit 0 | 2.310043217992643 s | 114,024 KiB |

Both processes retain the 30-second CPU/wall limit, one CPU, one thread, 1 GiB
address-space limit, shared lock and 50,000 charged-request cap. All 29,360
started requests completed. There are 58,722 physical records, no pending
requests, 35 completed column outcomes, 31 committed basis entries and one
completed final-coverage result. The recorded counts include 1,101 completed
source evaluations and 344 zero-substate proofs, including the four dependent
column roots. Maximum vector/state size was four terms; observed coefficient
and denominator widths were at most two bits. These are measurements of this
one run, not guarantees for a larger problem.

`audit_saved_pair.py` only hashes saved files, checks process/report metadata,
scans transcript framing/dependencies and copies completed outputs for
comparison. It imports no semantic program and performs no basis arithmetic,
source evaluation, cofactor computation, rank calculation, replay or Lean run.
It expects live snapshot paths; compact recovery can retain canonical bytes
and these audit results without duplicate snapshot trees.

## The four recorded identities

Indices are the fixed original zero-based column order. Every clearing scale
is one, and the displayed coefficients are copied from completed outputs:

\[
\begin{aligned}
B_0+B_3&=B_1+B_2,\\
B_6+B_9&=B_7+B_8,\\
B_{11}+B_{14}&=B_{12}+B_{13},\\
B_{17}+B_{20}&=B_{18}+B_{19}.
\end{aligned}
\]

The dependent columns are 3, 9, 14 and 20; the other 31 original columns are
the recorded pivots. Complete global identities give spanning, while the
source-bound triangular witnesses give independence. This combination is
stronger than merely refuting the earlier sixteen individual proposals.
Those earlier refutations never excluded another true linear combination.

## What dimension 31 rules out

Let the separately established designated cut be

\[
F(x,y)=\sum_{j=0}^{34}A_j(x)B_j(y),
\]

where A denotes the **grouped** left functions, X and Y are disjoint domains,
the equality covers every required assignment, and the 35 A functions are
linearly independent over the rationals. Under those separate premises,
the rational separation rank of F at this cut is exactly 31.

For the upper bound, express every B in the checked 31-dimensional span and
collect its A coefficients. The four displayed relations already permit
eliminating the four dependent columns with integer coefficients. For example,
the first four terms become

\[
(A_0-A_3)B_0+(A_1+A_3)B_1+(A_2+A_3)B_2.
\]

For the lower bound, independence of the A functions supplies rational linear
functionals that extract each coefficient B_j from F. If F had an alternative
unconditional separation into r rational products f_i(x)g_i(y), applying
those functionals would place every B_j in the span of the r right functions
g_i. Their span could not contain a 31-dimensional space unless r is at
least 31. The prior A-independence and complete-cut premises are not recomputed
by this metadata audit, and this argument has not been checked in Lean here.

Thus this route offers only four fewer terms out of 35, about 11.4%, for that
unconditional rational separation. It supplies no runtime or proof-size saving
estimate. Signed left coefficients may require extra representation and
verification work.

The conclusion does not exclude a different partition or contraction order,
identities valid after restrictions from the remaining factors, or cheaper
internal sharing within 31 terms. Separation rank is not an ADD-node,
arithmetic-operation or certificate-size lower bound. Summing the whole network
can also discard information that a full boundary function must preserve.
No complete n8 or n16 count follows from this isolated cut result.

## Canonical evidence

`metadata-audit.json` binds current canonical sources and result files; it
summarizes snapshot checks without retaining an authoring-history chain.
The producer transcript is the single canonical certificate copy:
`../exact-basis-diagnostic/attempts/basis-01/work.jsonl`, SHA-256
`52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6`.
The independent result is SHA-256
`48cf7f62c41be1c64ff34e01e7235e08c29553fda08576a9ba7e18ba16e11d9b`;
the current `RESULTS.json` is
`59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb`.
