#!/usr/bin/env python3
"""Check saved bytes and transcript metadata; never repeat basis arithmetic."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / 'next-iteration/exact-basis-diagnostic'
EXPECTED = {
    'attempts/basis-01/run-report.json': '03bbad23d6cc39ed8156ad52e886e748fd34412658fac17379942e5183f0b408',
    'attempts/basis-01/work.jsonl': '52f5c111c53c09bb81c5d81a328f8899def7bf091662aa1685824a7c4afdeff6',
    'attempts/basis-replay-01/run-report.json': '970d1d2f00117409afdeae4a2179136ae73a677ddfcdeb8bc17c8bfaebab5037',
    'attempts/basis-replay-01/replay-report.json': '48cf7f62c41be1c64ff34e01e7235e08c29553fda08576a9ba7e18ba16e11d9b',
    'RESULTS.json': '59eed762add11241db2f9fb232860f9c4c51fb24dcd5b42612f2e30bbfb770eb',
}


def binding(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


def main():
    output = HERE / 'metadata-audit.json'
    assert not output.exists()
    checks, distinct, retained = 0, set(), {}

    def check(row, keep=False):
        nonlocal checks
        path = Path(row['path'])
        if not path.is_absolute():
            path = ROOT / path
        actual = binding(path)
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), path
        checks += 1
        distinct.add(str(path))
        if keep:
            retained[str(path.relative_to(ROOT))] = {**actual, 'path': str(path.relative_to(ROOT))}
        return actual

    prior_path = ROOT / 'next-iteration/exact-basis-review/executable-review.json'
    prior = json.loads(prior_path.read_text())
    check(binding(prior_path), True)
    assert prior['status'] == 'no_blocker_found'
    for row in prior['canonical_bindings']:
        check(row, True)
    for relative, expected in EXPECTED.items():
        actual = binding(BASE / relative)
        assert actual['sha256'] == expected, relative
        check(actual, True)

    reports = []
    for attempt, mode in [('basis-01', 'producer'), ('basis-replay-01', 'replay')]:
        directory = BASE / 'attempts' / attempt
        report = json.loads((directory / 'run-report.json').read_text())
        assert report['status'] == 'passed' and report['exit_code'] == 0
        assert report['mode'] == mode and report['attempt'] == attempt
        for key in ['child_process_started', 'semantic_execution_attempted', 'executed_snapshots',
                    'source_bindings_complete', 'source_hashes_unchanged', 'input_bindings_complete',
                    'input_hashes_unchanged', 'deadline_checked_after_exit']:
            assert report[key] is True, key
        for key in ['formal_evidence', 'source_count_computed', 'killed_for_deadline']:
            assert report[key] is False, key
        constraints = report['constraints']
        for key, value in {'wall_seconds':30, 'cpu_seconds':30, 'threads':1,
                           'address_space_bytes':1073741824, 'charged_semantic_requests_cap':50000,
                           'board_size':8, 'fixed_original_columns':35, 'initial_basis_dimension':0,
                           'fixed_column_order':'original 0..34',
                           'old_sample_values_or_counterexamples_used':False,
                           'lock_mode':'exclusive_nonblocking'}.items():
            assert constraints[key] == value, key
        assert constraints['shared_lock'] == str(ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock')
        assert len(constraints['cpu_affinity']) == 1 and type(constraints['cpu_affinity'][0]) is int
        assert math.isfinite(report['seconds']) and 0 <= report['seconds'] <= 30
        assert 0 <= report['peak_rss_kib'] <= 1048576
        assert 0 <= report['user_seconds'] + report['system_seconds'] <= 30
        assert len(report['sources']) == 9 and len(report['inputs']) == (2 if mode == 'producer' else 3)
        for group in ['sources', 'inputs']:
            for row in report[group]:
                check(row, True)
                assert row['sha256'] == row['snapshot_sha256']
                check({'path':row['snapshot'], 'bytes':row['bytes'], 'sha256':row['snapshot_sha256']})
        for row in report['artifacts']:
            check(row)
        check(report['python_executable'])
        command = report['command']
        assert Path(command[0]).resolve() == Path(report['python_executable']['path'])
        script = 'diagnostics/produce_basis.py' if mode == 'producer' else 'replay/replay_basis.py'
        expected_command = ['-I', str(directory / 'source' / script),
                            '--trace', str(directory / 'input/trace.jsonl'),
                            '--sample', str(directory / 'input/sample.json')]
        if mode == 'replay':
            expected_command += ['--certificate', str(directory / 'input/certificate.jsonl')]
        expected_command += ['--output', str(directory / ('work.jsonl' if mode == 'producer' else 'replay-report.json'))]
        assert command[1:] == expected_command
        assert report['charged_semantic_requests'] == report['completed_requests'] == 29360
        assert report['physical_records'] == 58722 and report['pending_requests'] == []
        assert report.get('diagnostic_status', report.get('producer_status')) == 'completed_exact_basis'
        reports.append(report)

    checked = json.loads((BASE / 'attempts/basis-replay-01/replay-report.json').read_text())
    summary = json.loads((BASE / 'RESULTS.json').read_text())
    assert checked['status'] == 'passed' and checked['producer_status'] == 'completed_exact_basis'
    for group in ['input_bindings', 'policy_bindings']:
        for row in checked[group].values():
            check(row)
    check(checked['replayer'])
    for row in summary['bindings']:
        check(row, True)
    work = BASE / 'attempts/basis-01/work.jsonl'
    assert checked['input_bindings']['certificate']['sha256'] == binding(work)['sha256']

    operations = Counter({name:0 for name in checked['operation_counts']})
    phases = Counter()
    starts, done, stack, selected = {}, set(), [], {}
    columns, commits = [], []
    final = header = footer = None
    records = zero_proofs = evaluations = 0
    for line in work.open():
        row = json.loads(line)
        records += 1
        kind = row['kind']
        if kind == 'header':
            assert records == 1 and header is None
            header = row
        elif kind == 'work':
            assert footer is None and row['id'] == len(starts) and row['operation'] in operations
            starts[row['id']] = row['operation']
            operations[row['operation']] += 1
            phases[row['context']['phase']] += 1
            stack.append(row['id'])
        elif kind == 'done':
            assert footer is None and stack and row['id'] == stack.pop()
            assert row['finish'] == len(done) and row['id'] not in done
            assert all(type(i) is int and i in done for i in row['dependencies'])
            done.add(row['id'])
            operation = starts[row['id']]
            value = row['output']
            if operation in ['clear_vector','oracle_bridge']:
                selected[row['id']] = value
            elif operation == 'column_complete':
                columns.append(value)
            elif operation == 'basis_commit':
                commits.append(value)
            elif operation == 'basis_finish':
                assert final is None
                final = value
            elif operation == 'state' and value['proof_new'] is True:
                zero_proofs += 1
            elif operation == 'evaluate' and value['cache_hit'] is False:
                evaluations += 1
        elif kind == 'footer':
            assert footer is None
            footer = row
        else:
            raise AssertionError(kind)
    assert header is not None and footer is not None and not stack
    assert records == 58722 and len(starts) == len(done) == 29360
    assert dict(operations) == footer['operation_counts'] == checked['operation_counts'] == summary['operation_counts']
    assert dict(phases) == summary['phase_counts']
    assert sum(operations.values()) == 29360
    assert footer['status'] == 'completed_exact_basis' and footer['error'] is None
    assert footer['charged_starts'] == footer['completed_requests'] == 29360
    assert footer['physical_records'] == records and footer['pending_stack'] == []
    assert columns == footer['completed_columns'] == checked['completed_columns']
    assert [item['column'] for item in columns] == list(range(35))
    assert commits == footer['basis_commits'] == checked['basis_commits'] == summary['basis_commits']
    assert [item['basis_index'] for item in commits] == list(range(31))
    assert final == footer['final_basis'] == checked['final_basis'] == summary['final_basis']
    assert final['dimension'] == 31 and final['columns_complete'] == 35
    assert final['dependent_columns'] == [3,9,14,20]
    assert final['pivot_columns'] == [item['pivot_column'] for item in commits]
    assert operations['coverage_entry'] == 35 and operations['basis_finish'] == 1
    assert zero_proofs == checked['new_zero_proofs'] == 344
    assert evaluations == checked['completed_source_evaluations'] == 1101
    assert checked['pending_requests'] == []
    for key in ['cache_counts','maxima']:
        assert footer[key] == checked[key] == summary[key]
    assert footer['phase'] == checked['phase'] == {'phase':'finish','column':None,'basis_index':None}
    extracted = []
    for item in columns:
        cleared, oracle = selected[item['cleared']], selected[item['oracle']]
        extracted.append({'column':item['column'], 'outcome':item['outcome'],
                          'positive_scale':cleared['scale'],
                          'integer_original_column_coefficients':cleared['entries'],
                          'root_state':oracle['root_state'], 'proof_id':item['proof_id'],
                          'basis_commit':item['basis_commit']})
    assert extracted == summary['completed_columns']
    dependent = [item for item in extracted if item['outcome'] == 'dependent']
    assert len(dependent) == 4 and all(item['positive_scale'] == 1 for item in dependent)
    assert all(coef in (-1,1) for item in dependent for _,coef in item['integer_original_column_coefficients'])
    assert summary['producer_status'] == 'completed_exact_basis' and summary['replay_status'] == 'passed'
    assert summary['charged_starts'] == summary['completed_requests'] == 29360
    assert summary['physical_records'] == 58722 and summary['pending_stack'] == [] and summary['error'] is None
    assert summary['formal_evidence'] is False and summary['source_count_computed'] is False
    assert summary['replay_qualification'] == checked['qualification'] == reports[1]['replay_qualification']
    for label, report in [('producer',reports[0]),('replay',reports[1])]:
        for key in ['seconds','peak_rss_kib']:
            assert summary['timings'][label+'_'+key] == report[key]
    for group in ['input_bindings','policy_bindings']:
        for row in header[group].values():
            check(row)

    result = {
        'kind':'saved_exact_basis_pair_metadata_audit','status':'passed',
        'semantic_rerun':False,
        'scope':'Exact bytes, process bounds, paired certificate/result identities, transcript framing/dependencies, completed-output copying and summary consistency only. No basis arithmetic, source evaluation, cofactor, rank computation, replay or Lean execution.',
        'binding_checks':checks,'distinct_bound_files':len(distinct),
        'canonical_bindings':list(retained.values()),
        'snapshot_checks':'All original/snapshot/artifact entries were rehashed in the live workspace. Duplicate snapshots are not canonical retention requirements.',
        'processes':[{key:r[key] for key in ['attempt','mode','status','exit_code','seconds','peak_rss_kib']} for r in reports],
        'recorded_result':{'dimension':31,'complete_original_columns':35,'dependent_columns':[3,9,14,20],
                           'charged_starts':29360,'completed_requests':29360,'pending_requests':0,
                           'physical_records':58722,'zero_substate_proofs_including_roots':344,
                           'completed_source_evaluations':1101,'validated_original_nodes':checked['validated_original_nodes'],
                           'maxima':checked['maxima']},
        'recorded_identities':dependent,
        'interpretation':'External exact-function basis evidence only. Conditional on the complete fixed-cut decomposition, disjoint domains and independence of its35 grouped A functions, dimension31 is exact rational separation rank for that cut. No n8/n16 count or Lean theorem follows.'}
    output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({key:result[key] for key in ['status','binding_checks','distinct_bound_files','recorded_result']},indent=2))


if __name__ == '__main__':
    main()
