# Independent exact-relation executable review

**No source, mathematical-semantics, accounting, or runner-interface blocker was found.** This review covers the complete producer, independent replayer, implementation protocol, fixed v2 plan/schema, and the unchanged bounded runner. The exact identities are recorded in `review.json`. No program was imported or executed, no fixture was generated, and no algebra, restriction, counter, replay, or Lean calculation was run during this review.

The parent may conduct the already planned one bounded producer attempt and its independent replay. This review does not assert that the proposal arithmetic or any global identity will finish within the fixed budget.

## Exact origin and arithmetic checks

The replayer does not import the producer or another semantic checker. Its own controller loads the exact recorded nineteen rows and thirty-five full views, reconstructs the fixed request order, and computes each expected local result from already checked predecessors. Work records must match the controller's complete expected inputs and context. A sequence of individually valid equations with substituted or stale origins therefore cannot pass.

Both implementations capture the original pivot before changing its row and capture an elimination coefficient before updating the target row. Swaps retain distinct source references; every subsequent cell uses the latest result. Candidate generation visits the fixed free columns, uses the positive product of the nineteen denominators, and freezes all sixteen vectors before original-source validation or identity checking. No failed candidate changes the matrix, ordering, or remaining vectors.

Scalar operations, rational wrappers, normalization, each Euclidean step, exact divisions, coefficient collection and terminal arithmetic are charged at the stated protocol granularity. Actual arithmetic occurs after its request begins. The replayer's deferred bodies avoid computing expected arithmetic before consuming that request. Denominators are normalized to positive values; signed division uses a positive divisor and checks zero remainders where exact division is required. Canonical rational results follow from their checked construction history, without a hidden gcd check or fraction library.

## Complete guarded-function semantics

Selected descriptors are validated from the original bound bytes. Missing or duplicate selected definitions, non-prior children, bad variable order, conflicting/nested guards, and guard/core support overlap reject. Support is derived from descriptors, and the selected views are confined to the fixed sixteen-variable side. An old maximum-value annotation is never a semantic premise.

Signed states retain full positive/negative guards and the bare core ID. Exact sorted collection preserves occurrences and integer coefficients, merging only equal full views and removing an entry only through checked zero semantics or exact coefficient cancellation. Initial states have at most twenty nonzero terms; restriction does not introduce extra occurrences.

The least supported variable permits the local guard, absent-variable and original branch-head cofactor rules. Selected child guards merge with the residual guards, with contradiction and support checks. The resulting support excludes the chosen variable. Thus the Boolean split is a genuine pointwise restriction and the recursion decreases the remaining support.

A zero parent requires two completed zero children. A nonzero terminal and its composed restriction path refute only that exact candidate; stopping the opposite branch is valid for this existential counterexample. Assignment lifting is tied to the actual completed branch and chosen variable. No fresh evaluator is called. Absent variables introduce no factor of two in an identity case split; later counting projections remain a separate obligation.

## Cache and completion discipline

The digest is only a bucket index. Every inspected cached candidate, including a miss or collision, receives its own request, followed by charged full-term comparisons until mismatch or complete equality. Only completed zero states are published. A hit returns the existing earlier proof ID; it does not allocate an alias. A newly proved split preserves both child occurrences, even when they refer to the same proof.

Work IDs are allocated at starts, so they are not used as a substitute for completed-result causality. Both streams enforce top-of-stack completion, exact explicit and direct-child dependency order, and already completed dependencies. New zero-proof IDs are allocated in completion order and their child proofs are strictly earlier. Mutable matrix bookkeeping does not mutate previously checked result values.

## Partial results and interfaces

The same counter covers proposal arithmetic, source validation and all identity checks. A replayed cap is accepted only when a complete footer appears at the next request start with exactly 50,000 prior starts. The complete operation counts, cache counts, context, pending stack, maxima, committed pivots and completed candidate outcomes must agree. A footer where a completion is required, an early cap, truncation, trailing records, unknown fields, or an invalid exact type rejects. Other producer errors remain retained failure evidence; the replayer conservatively accepts only a complete fixed batch or a completely framed cap prefix.

The producer and replayer CLI flags match the runner's snapshotted `--trace`, `--sample`, `--output`, and replay-only `--certificate` arguments. Both locate the snapshotted protocol, DESIGN and schema in the runner's source layout. Header byte bindings allow the producer and replay attempts' distinct absolute paths while requiring equal bytes and hashes. This is appropriate relocation of metadata, not a semantic path oracle.

The runner remains the previously reviewed source: one CPU, 30 seconds wall/CPU, 1 GiB, the existing shared lock, executed snapshots, exact input pins, and post-run byte bindings. It classifies process metadata; mathematical transcript acceptance belongs to the independent replayer. No limit or policy change is introduced by this review.

## Interpretation of the eventual result

Completed `proved_zero` outcomes are external exact identity evidence over the original descriptor functions. Refutations apply only to their individual candidates. A cap says nothing about unfinished candidates, and refuting all sixteen selected directions still does not exclude another true linear combination. Policy-check booleans in a replay report are not evidence that every rule was exercised; actual coverage must come from the retained request counts.

None of this is a Lean identity theorem, a source-bound rank reduction, a queens count, or completion of size sixteen. Those further claims require the concrete ordinary-kernel checker and the appropriate guarded-source, cut, signed/scaled-factor and counting transfers. No sampled value or expected queens count is used to bypass those obligations.
