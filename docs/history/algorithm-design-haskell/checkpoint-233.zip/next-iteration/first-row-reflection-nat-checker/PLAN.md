# Complete first-row reflection original-source checker candidate

## Selected experiment, pending source and control acceptance

Root selected one changed-evaluator experiment with **24 fresh Lean/C modules, 154 exact theorem reports, one fresh link and one actual canonical n16 certificate execution**. The complete execution will use one cumulative 30-second, one-CPU/thread, 1-GiB/default-option gate. It includes the new universal reflection proofs, the endpoint and every selected experimental dependency. There is no separately accepted proof stage or reused experimental object. Source preparation and this document do not run the experiment.

`regression_audit` authored only two new endpoint/driver files and these selection controls. `counting_route` authored the two existing reflection files; `validity_contracts` independently reviewed that 39-input source scope. Its prospective 20-module/131-report proof closure remains its own scope. Root will independently review this endpoint/driver selection before the final native-gate manifest is frozen. All earlier mathematical sources, reviews, attempts and markers are unchanged.

## Exact changed endpoint and driver

`FirstRowReflectionQueensNatChecker` imports the unchanged `CertifiedNatChecker` and the new `FirstRowReflectionSource`. Its `Endpoint` still has the actual imported source type `ADWH.Chapter15.Queens.BitRepresentation.cqueens` and the identical canonical declaration-name string. Only its implementation/correctness pair changes to the total `FirstRowReflection.SourceBridge.cqueens` and universal `cqueens_eq` theorem. The four endpoint theorem statements and proofs are identical to the accepted masked endpoint, apart from their enclosing namespace.

`FirstRowReflectionRestrictedNatCheckerMain` is the accepted masked driver's unchanged IO/parser/decision logic with three exact endpoint-name substitutions: import, `accept`, and `endpoint`. Neither new source contains a concrete board size or candidate answer. The canonical parser, refusal behavior, exit codes and rendering are unchanged; no source selector, dynamic import, alternative evaluator or precomputed result is added.

`SOURCE-CORRESPONDENCE.json` stores complete exact forward/inverse edits to both accepted masked source files: seven endpoint edits (including two comments and two namespace commands), and three driver substitutions. Removing these two new files leaves all existing sources unchanged. No generator is needed or selected.

## Actual mathematical computation

The reflection wrapper is generic in board size. For positive sizes within the original Word16 range, it sums the lower-half first-row child counts, doubles that Nat sum and adds the center child once for odd sizes. Each child uses the original `encode [q]`, actual mask and the already source-linked masked evaluator at the original width/budget/depth. Its saturation test, supported-state guards and exact Nat fallback remain intact. Zero and sizes outside the optimized range keep the wrapper's separately proved exact original-source behavior. The final total theorem has no expected-answer, machine-fit or count-bound premise.

This changes the algorithm that supplies the endpoint's computed value. It does not change the candidate claim or use that value as a proof assumption. Actual compiled performance and new proof elaboration are unmeasured until root's selected gate. The previously accepted masked run is provenance and context, not acceptance of reflection or a prediction of runtime.

## Exact fresh closure and report inventory

| Module | Reports |
|---|---:|
| SymbolicWord16Core | 4 |
| SymbolicWord16Recurrence | 13 |
| ADWH.Chapter15.QueensBitsPrimitives | 7 |
| ADWH.Chapter15.QueensBitCounting | 10 |
| ADWH.Chapter15.QueensFastCounting | 0 |
| ADWH.Chapter15.QueensNatCounting | 0 |
| FiniteFold | 9 |
| FirstOrderNat | 9 |
| FirstOrderNatSource | 5 |
| FirstOrderNatSourceAudit | 10 |
| SaturatingUInt64 | 8 |
| UInt64MaskOps | 16 |
| UInt64SaturatingCount | 9 |
| UInt64ExactEvaluator | 2 |
| UInt64SourceBridge | 4 |
| UInt64PowerTwoOps | 2 |
| UInt64MaskedCount | 12 |
| UInt64MaskedExact | 4 |
| UInt64MaskedSource | 4 |
| FirstRowReflection | 10 |
| FirstRowReflectionSource | 3 |
| CertifiedNatChecker | 9 |
| FirstRowReflectionQueensNatChecker | 4 |
| FirstRowReflectionRestrictedNatCheckerMain | 0 |

The driver's strict transitive project closure has **23 modules and 144 reports**. The explicitly selected `FirstOrderNatSourceAudit` adds ten reports and one module, retaining the accepted protocol's audit of actual Fast/Nat source theorems. That module is charged to the same interval and linked from its freshly generated C. The complete selected scope is therefore **24/154**, not the old 22/141.

Twenty selected sources are byte-identical to the accepted masked-lintfix manifest: all old dependencies and the canonical parser/audit module. The corrected masked worker remains the exact accepted `_hl` variant. The two reflection files are the frozen independently reviewed sources, and the final two are the new endpoint/driver. All 24 are legacy-format sources and would emit `.olean`, `.ilean`, and `.c` files under the selected native protocol.

The same scoped `QueensBitCounting` file and symbolic primitive replacement are selected. Their generic original-source definitions and count theorem remain unchanged. They are experimental dependencies and are rebuilt here; their previously accepted compiled objects are not reused.

## Original-only prepared dependency pool

The only reusable project objects are the exact original-native preparation from `first-order-nat-evaluator/original-native-preparation/attempts/original-native-01/report.json`, 66,928 bytes, SHA-256 `fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5`.

Its seven unchanged original modules are Lists, Permutations, Queens, QueensVariants, QueensSearch, QueensBitRepresentation and QueensBitMoves. The complete gate must validate that preparation's source/control/runtime identities and copy exactly **21 files: fourteen `.olean`/`.ilean` files and seven native `.o` files**. Its seven C files are retained provenance, not experimental inputs. The actual original preparation cost was 10.480943722002849 seconds and 799,192 KiB, disclosed separately under the established original-dependency policy.

No old UInt64, masked, reflection, parser, endpoint or driver object is eligible for reuse. Missing original pool files require explicit bounded restoration with their provenance preserved; no runner may silently rebuild or relabel that historical preparation, erase a marker, or obtain a hidden second budget for experimental mathematics.

## Complete native execution contract

The proposed gate directly adapts the accepted masked-lintfix resource/runtime/one-use lifecycle. Root alone may execute its reviewed controls. It must:

1. Validate source identities, actual imports and all 154 distinct ordered roots; all exact source inverses and original review scopes; the pinned Lean 4.35.0 compiler/runtime; and the accepted original-only pool.
2. Snapshot the selected current inputs, copy only the 21 original objects, and reserve one permanent source-keyed marker before the first compiler child.
3. In one shared 30-second interval, run 24 Lean commands with `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`, default heartbeat/recursion settings, and the same 1-GiB process-group RSS/one-CPU enforcement. Each command must freshly check the module and emit C plus both Lean objects.
4. Run one `leanc -O3 -Werror` link using all 24 fresh C files and exactly the seven original native objects.
5. Run the new executable once with the unchanged actual-source claim tokens: `ADWH.Chapter15.Queens.BitRepresentation.cqueens`, `16`, `=`, `14772512`. It must compute through the reflection endpoint and emit exactly the corresponding canonical `ACCEPT` line with zero exit, empty stderr and remaining-budget completion.
6. Check all source/control/runtime/output identities and the exact **94-artifact** inventory: 72 fresh Lean/C files, 21 copied original files and one executable. Preserve every failure, raw log, source/control snapshot and consumed marker.

The expected command count is **26**. Both the proof and numerical stages are conditional on the preceding successful commands, but share the one deadline; there is no staged mathematical acceptance used as an input premise. Observed reports from a failed module remain unaccepted. No small-board probe or repeated old numerical baseline is selected.

The numeral in the gate argv is only the candidate certificate to check. It is absent from the evaluator, endpoint and driver sources and does not determine any optimization decision, range proof or saturation branch. All semantic equality comes from the freshly checked universal source proofs.

## Trust boundary and recovery

A successful complete run would establish fresh ordinary Lean acceptance of all selected universal proofs plus a new source-linked external native certificate check under the pinned compiler/runtime/I/O boundary. It would not create a stock Lean proof of the concrete acceptance equation, install an optimized kernel, prove the cached checker success contract, or close the stock numeral theorem. Those remain separately identified integration work.

Historical masked/helper reviews retain their exact old source scopes, including the old worker before its narrow lint correction where applicable. The accepted lintfix selection and its focused correction review are explicit provenance. Reflection's 39-input review is separately bound. No review is silently relabeled as covering this complete selection.

A source-only checkpoint must retain both new sources, the reflection sources, every selected dependency or exact reconstruction input, all source correspondence/selection/review controls, and any resulting raw evidence/marker. Compiled objects and the installed toolchain remain reproducible dependencies, not proof artifacts to reuse silently. Root owns packaging and any later execution. No Lean, compiler, native counter/checker, retained generator, gate/preflight or saved auditor was executed or imported during this source preparation.
