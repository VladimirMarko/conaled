#!/usr/bin/env python3
"""Read-only reflection failure audit: saved bytes only, no project/tool imports.

Authored by regression_audit (also the endpoint/driver/gate author); this is not
an independent mathematical review. Root reviews and executes this reader.
Digest/path/strict-JSON helpers and original-pool recovery logic follow the
accepted masked saved reader; that reader is neither imported nor executed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
WORK = BASE.parents[1]
OLD_WORK = Path('/workspace/scratch/40ff1d6addf0/work')
GATE = BASE / 'native-gate'
ATTEMPT = GATE / 'attempts/complete-01'
REPORT_SHA = '0f75dc5c075c45000ac679a491b84232a90c9a193996c61b9fe8001f3092b0ff'
RECOVERY_SHA = '7584c1b5e43472dc47ee7ce63944dc9ef91a7fe3afe242d0face289fbf453764'
MANIFEST_SHA = '69da6c5421f1f2471d070160faeee44590cc1e4650dd39082daf40a636c01e47'
POOL_SHA = 'fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5'
POOL_RECOVERY_SHA = 'd9467a395d09f208c1533369f507fff554109de625eb092764947743589016e1'
KEY = '9347a908caea495bf245c1780ab23ba687a04ead28ee6c5da6ded87bd6cb2221'
ARGV = ['ADWH.Chapter15.Queens.BitRepresentation.cqueens', '16', '=', '14772512']
LEAN_OPTIONS = ['-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true', '-DElab.async=false']
NATIVE_OPTIONS = ['-O3', '-Werror']
ORIGINALS = ['ADWH.Chapter01.Lists', 'ADWH.Chapter01.Permutations',
    'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensVariants', 'ADWH.Chapter15.QueensSearch',
    'ADWH.Chapter15.QueensBitRepresentation', 'ADWH.Chapter15.QueensBitMoves']
MODULES = ['SymbolicWord16Core', 'SymbolicWord16Recurrence',
    'ADWH.Chapter15.QueensBitsPrimitives', 'ADWH.Chapter15.QueensBitCounting',
    'ADWH.Chapter15.QueensFastCounting', 'ADWH.Chapter15.QueensNatCounting',
    'FiniteFold', 'FirstOrderNat', 'FirstOrderNatSource', 'FirstOrderNatSourceAudit',
    'SaturatingUInt64', 'UInt64MaskOps', 'UInt64SaturatingCount', 'UInt64ExactEvaluator',
    'UInt64SourceBridge', 'UInt64PowerTwoOps', 'UInt64MaskedCount', 'UInt64MaskedExact',
    'UInt64MaskedSource', 'FirstRowReflection', 'FirstRowReflectionSource', 'CertifiedNatChecker',
    'FirstRowReflectionQueensNatChecker', 'FirstRowReflectionRestrictedNatCheckerMain']
COUNTS = [4, 13, 7, 10, 0, 0, 9, 9, 5, 10, 8, 16, 9, 2, 4, 2, 12, 4, 4, 10, 3, 9, 4, 0]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
PATTERN = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
PINS = {
    'RESULTS.md': (2429, 'a391ee3ae2a1db14ff07b99436fac16b23f7047e1d7250b5e7536cbba66c6fbc'),
    'RESULTS.json': (1819, 'd6620a553af8debe492bdca0e1328cf058fd13faa5e5caae76a479d4b34e448b'),
    'SNAPSHOT-RECOVERY.json': (76804, RECOVERY_SHA),
    'native-gate/input-manifest.json': (41044, MANIFEST_SHA),
    'native-gate/GATE-REVIEW.md': (3375, '08c8f0787ea2bd8d85f3a3ae37e05880fc68028a097a194cc90705ba815c68c6'),
    'native-gate/GATE-AUDIT.json': (18246, 'c5d1c1a52812a4c707792bece6df3888bcc685ecc8ad6353e6ea1de1e6c0ccd7'),
    'native-gate/ROOT-EXECUTION-RECEIPT.json': (1938, 'f247a2465f2e1e865f938d49db4ba60a76e8ef1d6dff069602bef4238b206645'),
    'native-gate/attempts/complete-01/report.json': (338228, REPORT_SHA),
}
CACHE = {}
DIAGNOSTICS = "FirstRowReflection.lean:146:36: error(lean.unknownIdentifier): Unknown identifier `q`\nFirstRowReflection.lean:181:71: error: unsolved goals\nn : Nat\nhn : 0 < n\nhb : PartialBoard n 0 []\nhs : solved n [] = false\nhe : solutionsQ n [] = searchQ n (successors n [])\n⊢ (List.map (fun x => (solutionsQ n [x]).length) (columns n)).sum = (List.map (firstChild n) (columns n)).sum\nFirstRowReflection.lean:191:23: error: This simp argument is unused:\n  firstChild\n\nHint: Omit it from the simp argument list.\n  [apply] simp only [searchQ, List.length_flatMap, successors, moves_nil, List.map_map, Function.comp_def]\n\nNote: This linter can be disabled with `set_option linter.unusedSimpArgs false`\nFirstRowReflection.lean:253:16: error: This simp argument is unused:\n  List.range'\n\nHint: Omit it from the simp argument list.\n  [apply] simp [hc, Nat.add_comm]\n\nNote: This linter can be disabled with `set_option linter.unusedSimpArgs false`"


def require(value, message):
    if not value:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def identity(row):
    return row['bytes'], row['sha256']


def digest(path):
    require(path.is_file() and not path.is_symlink(), 'Missing/symlink evidence: ' + str(path))
    stat = path.stat()
    key = str(path), stat.st_size, stat.st_mtime_ns
    if key not in CACHE:
        with path.open('rb') as stream:
            CACHE[key] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return stat.st_size, CACHE[key]


def recorded(path):
    p = Path(path)
    return os.path.normpath(str(p if p.is_absolute() else OLD_WORK / p))


def local(path):
    p = Path(recorded(path))
    return WORK / p.relative_to(OLD_WORK) if p.is_relative_to(OLD_WORK) else p


def walk(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true',
        help='Check retained canonical sources/evidence without build objects or toolchain; no mode-bit inference.')
    args = parser.parse_args()
    for name, pinned in PINS.items():
        require(digest(BASE / name) == pinned, 'Frozen root evidence differs: ' + name)
    r = read(ATTEMPT / 'report.json')
    rec = read(BASE / 'SNAPSHOT-RECOVERY.json')
    manifest = read(GATE / 'input-manifest.json')
    results = read(BASE / 'RESULTS.json')
    gate_audit = read(GATE / 'GATE-AUDIT.json')
    receipt = read(GATE / 'ROOT-EXECUTION-RECEIPT.json')
    old_base = OLD_WORK / BASE.relative_to(WORK)
    old_attempt = old_base / 'native-gate/attempts/complete-01'
    build, source_root = old_attempt / 'build', old_attempt / 'source'
    require(r['format'] == 'adwh-first-row-reflection-native-original-checker-v1'
            and r['status'] == 'failed' and r['attempt'] == 'complete-01'
            and r['failure'] == {'message': 'Lean child/report/output validation failed: lean-FirstRowReflection',
                                'type': 'ValueError'}
            and all(k not in r for k in ['cumulative_limit_exceeded', 'postcheck_failure',
                                         'affinity_restore_failure']),
            'Actual proof failure or absence of resource/integrity failure differs')
    require(r['cumulative_execution_seconds'] == 10.829759938002098
            and r['peak_rss_kib'] == 789892
            and r['limits'] == {'cpu_count': 1, 'cumulative_seconds': 30,
                'default_heartbeats_and_recursion': True, 'lean_memory_mib': 1024, 'rss_kib': 1048576}
            and r['inputs_and_outputs_postchecked'] is True
            and r['all_current_mathematics_charged_to_single_complete_interval'] is True,
            'Resource policy or final integrity outcome differs')
    false_flags = ['acceptance_output_observed', 'all_new_mathematical_sources_freshly_checked_and_c_generated',
        'canonical_certificate_accepted', 'complete_external_checker_acceptance',
        'fresh_universal_source_proofs_passed', 'native_certificate_executed',
        'compiled_experimental_objects_reused', 'concrete_Lean_acceptance_equation_proved',
        'kernel_extension_implemented', 'new_masked_generic_acceptance_assumed',
        'new_reflection_acceptance_assumed', 'stock_kernel_numeral_proof',
        'stock_numeral_theorem_proved', 'historical_source_reviews_rebased']
    for key in false_flags:
        require(r[key] is False, 'Failed run was relabelled as acceptance: ' + key)
    require('concrete_certificate' not in r, 'Unexpected numerical certificate')
    require(r['module_order'] == manifest['module_order'] == MODULES
            and r['source_modules'] == manifest['sources']
            and [len(s['roots']) for s in r['source_modules']] == COUNTS
            and r['required_axiom_report_count'] == manifest['required_root_count'] == 154
            and len({name for s in r['source_modules'] for name in s['roots']}) == 154,
            'Selected full fresh closure differs')
    require(manifest['lean_options'] == LEAN_OPTIONS and manifest['native_options'] == NATIVE_OPTIONS
            and manifest['argv'] == r['argv'] == ARGV and r['compiler_release'] == '4.35.0'
            and r['compiler_commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
            'Compiler/options/selected unexecuted claim differ')
    expected_identity = {'format': r['format'],
        'sources': [{'module': s['module'], 'sha256': s['sha256']} for s in r['source_modules']],
        'prepared_pool_sha256': POOL_SHA, 'argv': ARGV, 'lean_options': LEAN_OPTIONS,
        'native_options': NATIVE_OPTIONS, 'complete_budget_seconds': 30}
    key = hashlib.sha256(json.dumps(expected_identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(r['source_identity'] == expected_identity and r['source_fingerprint'] == key == KEY,
            'Permanent source-and-claim identity differs')
    require(rec['format'] == 'adwh-first-row-reflection-failure-snapshot-recovery-v1'
            and rec['status'] == 'exact_source_recovery_map_for_failed_full_attempt'
            and identity(rec['report']) == PINS['native-gate/attempts/complete-01/report.json']
            and rec['source_fingerprint'] == KEY
            and rec['snapshot_count'] == len(rec['snapshot_mappings']) == 76
            and rec['snapshot_bytes'] == 2286194 and rec['canonical_text_copies_needed'] == []
            and rec['source_only_restore_needs_previous_archive'] is False
            and rec['reader_status'] == 'dedicated_saved_reader_not_yet_prepared'
            and rec['mathematical_status'] == 'failed_with128_accepted_prefix_roots_and_no_native_run'
            and rec['accepted_stock_numeral_theorem'] is False,
            'Frozen recovery scope or its historical preparation-time status differs')
    inputs, snaps = r['inputs'], r['snapshots']
    roles = {x['role']: x for x in inputs}
    expected_inputs = manifest['controls'] + [{**s, 'role': 'source_' + s['module']} for s in manifest['sources']]
    require(len(inputs) == len(roles) == len(snaps) == 76 and len(expected_inputs) == 75,
            'Input/role/snapshot count differs')
    for actual, expected in zip(inputs[:-1], expected_inputs):
        require(actual['relative_path'] == expected['path']
                and actual['path'] == str(OLD_WORK / expected['path'])
                and actual['role'] == expected['role'] and identity(actual) == identity(expected),
                'Executed input differs from frozen manifest')
    require(inputs[-1] == roles['input_manifest']
            and identity(roles['input_manifest']) == PINS['native-gate/input-manifest.json'],
            'Actual manifest role differs')
    maps, readonly_paths = {}, set()
    for inp, snap, entry in zip(inputs, snaps, rec['snapshot_mappings']):
        require(snap['original_path'] == inp['path'] and snap['role'] == inp['role']
                and identity(snap) == identity(inp) == identity(entry)
                and recorded(entry['snapshot']) == snap['path']
                and entry['canonical'] == inp['relative_path'] and entry['role'] == inp['role'],
                'Canonical current snapshot mapping differs')
        expected = source_root / (inp['role'][7:].replace('.', '/') + '.lean') \
            if inp['role'] in {'source_' + m for m in MODULES} else old_attempt / 'inputs' / inp['relative_path']
        require(snap['path'] == str(expected) and snap['path'] not in maps, 'Snapshot path differs')
        maps[snap['path']] = WORK / entry['canonical']
        readonly_paths.add(snap['path'])
    require(sum(s['bytes'] for s in snaps) == 2286194, 'Snapshot byte total differs')
    readonly_paths |= {roles['failed_worker_snapshot']['path'], roles['failed_masked_marker']['path']}

    # The accepted original-only preparation is separate disclosed dependency
    # materialization. Its exact seven modules/21 copied files remain original.
    pool_dir = WORK / 'next-iteration/first-order-nat-evaluator/original-native-preparation'
    pool_rec_path = pool_dir / 'SNAPSHOT-RECOVERY.json'
    require(digest(pool_rec_path) == (27122, POOL_RECOVERY_SHA), 'Original-pool recovery changed')
    pool_rec = read(pool_rec_path)
    prep_path = pool_dir / 'attempts/original-native-01/report.json'
    require(digest(prep_path) == (66928, POOL_SHA), 'Original-pool accepted report changed')
    prep, pool = read(prep_path), r['original_native_pool']
    require(prep['format'] == 'adwh-seven-original-native-preparation-v1'
            and prep['status'] == 'completed_within_limits' and prep['module_order'] == ORIGINALS
            and prep['all_7_originals_fresh_lean_c_native'] is True
            and prep['inputs_and_outputs_postchecked'] is True
            and prep['native_program_linked_or_executed'] is False
            and identity(pool['report']) == (66928, POOL_SHA)
            and pool['sources'] == prep['source_modules'] and pool['runtime'] == prep['runtime'] == r['runtime']
            and len(r['runtime']) == 44 and len(prep['inputs']) == len(prep['snapshots']) == 18
            and len(prep['commands']) == 14 and len(prep['artifacts']) == 28,
            'Original-only preparation scope differs')
    expected_pool = [pool['report'], *prep['inputs'], *prep['artifacts'], *prep['snapshots'],
        prep['execution_marker'], *[c[k] for c in prep['commands'] for k in ['stdout', 'stderr']]]
    require(pool['bindings'] == expected_pool
            and pool['readonly'] == [*prep['snapshots'], prep['execution_marker']]
            and pool['preparation_seconds_separate'] == prep['cumulative_execution_seconds'] == 10.480943722002849,
            'Original-only pool provenance differs')
    require(len(pool_rec['snapshot_mappings']) == 18 and len(pool_rec['emitted_c_mappings']) == 7,
            'Original-pool recovery census differs')
    for snap, entry in zip(prep['snapshots'], pool_rec['snapshot_mappings']):
        require(recorded(entry['snapshot_path']) == snap['path'] and identity(entry) == identity(snap),
                'Original-pool snapshot map differs')
        maps[snap['path']] = WORK / entry['canonical_path']
        readonly_paths.add(snap['path'])
    prepared = {a['path']: a for a in prep['artifacts']}
    for entry in pool_rec['emitted_c_mappings']:
        raw = recorded(entry['recorded_path'])
        require(raw in prepared and raw.endswith('.c') and identity(entry) == identity(prepared[raw]),
                'Original emitted-C recovery differs')
        maps[raw] = WORK / entry['canonical_path']
    readonly_paths.add(prep['execution_marker']['path'])
    expected_copies = []
    for module in ORIGINALS:
        for suffix in ['.olean', '.ilean', '.o']:
            src = prepared[str(Path(prep['object_search_path']) / (module.replace('.', '/') + suffix))]
            expected_copies.append({**src, 'module': module, 'suffix': suffix})
    require(pool['copy_inputs'] == expected_copies and len(r['copied_original_objects']) == 21,
            'Exact original-only copy inventory differs')
    for pair, src in zip(r['copied_original_objects'], expected_copies):
        require(pair['source'] == src and identity(pair['copy']) == identity(src)
                and pair['copy']['path'] == str(build / (src['module'].replace('.', '/') + src['suffix'])),
                'Original copied artifact differs')

    # Only the first19 successful modules generated new outputs. The failed
    # module generated no accepted objects; there was no link/native child.
    expected_outputs = {str(build / (m.replace('.', '/') + suffix))
                        for m in MODULES[:19] for suffix in ['.c', '.olean', '.ilean']}
    expected_outputs |= {x['copy']['path'] for x in r['copied_original_objects']}
    artifacts = r['artifacts']
    require(len(artifacts) == len(expected_outputs) == 78
            and {a['path'] for a in artifacts} == expected_outputs
            and rec['omit_compiled_artifacts'] == artifacts
            and rec['live_only_runtime_bindings'] == r['runtime'],
            'Actual failed-attempt output census differs')
    omitted = {a['path']: a for a in artifacts}
    for row in pool_rec['omitted_compiled_artifacts']:
        raw = recorded(row['path'])
        require(raw in prepared and identity(row) == identity(prepared[raw])
                and Path(raw).suffix in ['.olean', '.ilean', '.o'], 'Original binary omission differs')
        omitted[raw] = prepared[raw]
    require(len(omitted) == 99 and len(maps) == 101,
            'Current78/original21 omissions or76+18+7 recovery census differs')
    runtime = {x['path']: x for x in r['runtime']}
    require(len(runtime) == 44, 'Runtime paths are not unique')
    marker_row = r['execution_marker']
    require(identity(marker_row) == identity(rec['execution_marker']) ==
            (176021, '725af67d124fb42e388bc963a0465a667648c7978778627d37eea20fa8508108')
            and Path(marker_row['path']).name == 'complete-' + KEY + '.json', 'Consumed marker differs')
    readonly_paths.add(marker_row['path'])
    require(digest(local(marker_row['path'])) == identity(marker_row), 'Marker bytes changed')
    marker = read(local(marker_row['path']))
    require(set(marker) == {'all_current_mathematics_charged_to_single_complete_interval', 'argv',
        'attempt', 'authorship', 'compiler_commit', 'compiler_release', 'correction_review_check',
        'current_endpoint_review_check', 'format', 'historical_accepted_masked_selection',
        'historical_accepted_native_sources', 'historical_masked_failure', 'historical_source_manifest',
        'historical_source_reviews_rebased', 'inputs', 'module_order', 'new_masked_generic_acceptance_assumed',
        'new_reflection_acceptance_assumed', 'original_native_pool', 'review_provenance', 'runtime',
        'source_fingerprint', 'source_identity', 'source_modules', 'source_review_checks',
        'source_review_input_occurrences_including_correction', 'toolchain'}, 'Marker field inventory differs')
    for name, value in marker.items():
        require(value == (str(old_attempt) if name == 'attempt' else r[name]),
                'Marker/report field differs: ' + name)
    checked, skipped, recovered, path_identities = set(), set(), set(), {}

    def verify(row):
        raw, ident = recorded(row['path']), identity(row)
        require(raw not in path_identities or path_identities[raw] == ident, 'Conflicting identity: ' + raw)
        path_identities[raw] = ident
        token = raw, *ident
        if token in checked:
            return
        checked.add(token)
        if args.source_only and (raw in runtime or raw in omitted):
            require(ident == identity((runtime if raw in runtime else omitted)[raw]), 'Omitted identity differs')
            skipped.add(raw)
            return
        path = maps[raw] if args.source_only and raw in maps else local(raw)
        require(digest(path) == ident, 'Changed saved evidence: ' + str(path))
        if raw in maps:
            require(digest(maps[raw]) == ident, 'Canonical recovery bytes differ')
            recovered.add(raw)
        if not args.source_only and raw in readonly_paths:
            require(path.stat().st_mode & 0o222 == 0, 'Writable original live snapshot/marker')

    # No source-only filesystem permission claim: ZIP extraction can preserve
    # exact bytes while changing mode bits. Live mode retains strict checks.
    for value in [r, manifest, marker, rec, pool_rec, gate_audit, results, receipt]:
        for row in walk(value):
            verify(row)
    require(set(maps) <= recovered, 'Incomplete current/original canonical recovery coverage')

    # Six reviews keep their distinct historical/current scopes. Earlier
    # mathematical acceptance is never a premise for this failed full gate.
    accepted_masked = read(local(roles['masked_accepted_report']['path']))
    require(roles['masked_accepted_report']['sha256'] ==
            '229b123eeda36f20cd1e2edb7f70fde30e22a2c4800c96e5174f3435d1c44828'
            and accepted_masked['status'] == 'completed_within_limits'
            and r['source_review_checks'][:3] == accepted_masked['source_review_checks']
            and r['correction_review_check'] == accepted_masked['correction_review_check']
            and r['review_provenance'][:35] == accepted_masked['review_provenance'],
            'Historical masked review scopes were changed/rebased')
    contracts = [
        ('masked_source_audit', 'adwh-uint64-masked-evaluator-independent-source-audit-v1', 33),
        ('checker_source_audit', 'adwh-uint64-masked-checker-independent-source-audit-v1', 53),
        ('power_two_source_audit', 'adwh-uint64-power-two-ops-independent-source-audit-v1', 22),
        ('reflection_source_audit', 'adwh-first-row-reflection-independent-source-audit-v1', 39),
        ('current_checker_source_audit', 'adwh-first-row-reflection-checker-independent-source-audit-v1', 52)]
    require(len(r['source_review_checks']) == 5 and len(r['review_provenance']) == 55
            and r['current_endpoint_review_check'] == r['source_review_checks'][-1],
            'Current/source review evidence scope differs')
    reviewed, audits, occurrences = {}, {}, 0
    for entry, (role, fmt, count) in zip(r['source_review_checks'], contracts):
        verify(entry['audit']); verify(entry['review'])
        audit = read(local(entry['audit']['path']))
        require(entry['review_role'] == role and audit['format'] == fmt
                and audit['status'] == 'passed_source_only_review_not_compiled'
                and len(audit['inputs']) == entry['verified_input_occurrences']
                    == entry['verified_distinct_input_count'] == count
                and identity(audit['review']) == identity(entry['review'])
                and recorded(audit['review']['path']) == entry['review']['path']
                and entry['source_only_review_not_mathematical_acceptance'] is True,
                'Exact source-review contract differs: ' + role)
        audits[role] = audit
        local_seen = set()
        for row in audit['inputs']:
            raw = recorded(row['path']); ident = identity(row)
            require(raw not in local_seen and (raw not in reviewed or reviewed[raw] == ident),
                    'Duplicate/conflicting source-review identity')
            local_seen.add(raw); reviewed[raw] = ident; occurrences += 1; verify(row)
        if role in ['reflection_source_audit', 'current_checker_source_audit']:
            modules = MODULES[19:21] if role == 'reflection_source_audit' else MODULES
            require(entry['current_selected_modules_checked'] == modules
                    and entry['current_selected_report_count'] == (13 if role == 'reflection_source_audit' else 154)
                    and entry['historical_scope_rebased'] is False,
                    'Current selected source-review scope differs')
            for source in r['source_modules']:
                if source['module'] in modules:
                    require(reviewed[recorded(source['path'])] == identity(source)
                            and audit['fully_qualified_roots'][source['module']] == source['roots'],
                            'Current source/root identity absent from independent review')
    correction = r['correction_review_check']
    correction_audit = read(local(correction['audit']['path']))
    verify(correction['audit']); verify(correction['review'])
    require(correction_audit['format'] == 'adwh-masked-count-lintfix-independent-source-audit-v1'
            and correction_audit['status'] == 'passed_source_only_review_not_compiled'
            and len(correction_audit['inputs']) == correction['verified_distinct_input_count'] == 18
            and correction['exact_one_character_inverse'] is True
            and correction['old_review_scopes_preserved'] is True
            and correction['source_only_review_not_mathematical_acceptance'] is True
            and identity(correction_audit['review']) == identity(correction['review']),
            'Historical18-input correction review differs')
    for row in correction_audit['inputs']:
        raw = recorded(row['path']); ident = identity(row)
        require(raw not in reviewed or reviewed[raw] == ident, 'Correction conflicts with another review')
        reviewed[raw] = ident; occurrences += 1; verify(row)
    require(occurrences == r['source_review_input_occurrences_including_correction'] == 217
            and len(reviewed) == 103, 'Six-review217-occurrence/103-path census differs')
    for row in r['review_provenance']:
        require(row['review_role'] in audits and row['retained_reference_not_prepared_object'] is True,
                'Unexpected prepared/relabelled provenance')
        origin = audits[row['review_role']]['inputs'][row['review_index']]
        require(origin['path'] == row['recorded_review_path']
                and recorded(origin['path']) == row['path'] and identity(origin) == identity(row),
                'Recorded provenance does not match its exact historical review row')
        verify(row)

    # Reparse actual raw logs independently of the saved summary. All10 reports
    # from FirstRowReflection are unaccepted, including the six allowed-only rows.
    require(len(r['commands']) == len(r['axiom_audits']) == 20,
            'Attempted Lean command/audit census differs')
    reports, accepted, logs = [], [], []
    toolchain = Path(r['toolchain'])
    for index, (command, audit) in enumerate(zip(r['commands'], r['axiom_audits'])):
        module, source = MODULES[index], r['source_modules'][index]
        stem = module.replace('.', '/')
        expected_command = [str(toolchain / 'bin/lean'), *LEAN_OPTIONS,
            '-o', str(build / (stem + '.olean')), '-i', str(build / (stem + '.ilean')),
            '-c', str(build / (stem + '.c')), stem + '.lean']
        passed = index < 19
        require(command['command'] == expected_command and command['cwd'] == str(source_root)
                and command['label'] == 'lean-' + module and audit['module'] == module
                and command['exit_code'] == (0 if passed else 1)
                and command['within_limits'] is True and command['limit_exceeded'] is None,
                'Actual fresh Lean command/result differs')
        out, err = local(command['stdout']['path']).read_text(), local(command['stderr']['path']).read_text()
        logs += [command['stdout'], command['stderr']]
        raw = [{'root': name, 'axioms': [a.strip() for a in axioms.split(',') if a.strip()]}
               for name, axioms in PATTERN.findall(out)]
        require(raw == audit['raw_reports'] and [x['root'] for x in raw] == source['roots']
                == audit['required_roots'] and len(raw) == audit['observed_count']
                == audit['observed_unique_count'] == COUNTS[index]
                and audit['accepted_count'] == (COUNTS[index] if passed else 0)
                and audit['exact_ordered_roots'] is True
                and audit['module_passed'] is passed and audit['reports_passed'] is passed
                and audit['required_outputs_present'] is passed
                and audit['allowed_axioms_only'] is passed
                and PATTERN.sub('', out).strip() == audit['unparsed_stdout'] == ('' if passed else DIAGNOSTICS)
                and not err and audit['stderr_empty'] is True,
                'Raw axiom/diagnostic/acceptance boundary differs')
        if passed:
            require(all(set(x['axioms']) <= ALLOWED for x in raw), 'Accepted prefix has a forbidden axiom')
            accepted.extend(raw)
        else:
            sorry_names = [x['root'].rsplit('.', 1)[-1] for x in raw if 'sorryAx' in x['axioms']]
            require(sorry_names == ['expandRows_length_reflect', 'solutionsQ_length_reflect',
                                   'firstChild_reflect', 'solutionsQ_empty_sum']
                    and all(set(x['axioms']) <= ALLOWED | {'sorryAx'} for x in raw)
                    and command['seconds'] == 1.1099559590074932,
                    'Failed-module generated placeholders or timing differ')
        reports.extend(raw)
    require(len(reports) == len({x['root'] for x in reports}) == r['observed_axiom_report_count']
            == r['observed_unique_axiom_root_count'] == 138
            and len(accepted) == len({x['root'] for x in accepted}) == r['accepted_axiom_report_count']
            == r['accepted_unique_axiom_root_count'] == 128
            and sum(a['module_passed'] for a in r['axiom_audits']) == 19,
            'Actual observed138/accepted128/module19 census differs')
    require(logs == rec['logs'] and len(logs) == 40
            and max(c['sampled_tree_and_wait4_peak_rss_kib'] for c in r['commands']) == r['peak_rss_kib'],
            'Raw40-log or peak-RSS inventory differs')
    failed_source = local(roles['source_FirstRowReflection']['path']).read_text()
    require(not re.search(r'\b(?:sorry|admit|axiom|unsafe|implemented_by|native_decide)\b', failed_source),
            'Unexpected explicit admission or execution escape in frozen failed source')
    declared = r['declared_environment']
    require(declared['LEAN_PATH'] == str(build) and declared['LEAN_SYSROOT'] == str(toolchain)
            and declared['LD_LIBRARY_PATH'] == str(toolchain / 'lib/lean') + ':' + str(toolchain / 'lib')
            and declared['LEAN_NUM_THREADS'] == declared['OMP_NUM_THREADS']
                == declared['OPENBLAS_NUM_THREADS'] == declared['MKL_NUM_THREADS'] == '1'
            and declared['LEAN_ABORT_ON_PANIC'] == '1', 'Declared bounded environment differs')
    if not args.source_only:
        require({str(path.relative_to(WORK)) for path in local(build).rglob('*') if path.is_file()}
                == {str(Path(x).relative_to(OLD_WORK)) for x in expected_outputs},
                'Unrecorded live build artifact exists')

    # Root control review and actual execution receipt are separate from this
    # gate-author-written saved-data reader, and remain immutable.
    require(gate_audit['format'] == 'adwh-first-row-reflection-native-independent-gate-audit-v1'
            and gate_audit['status'] == 'passed_source_control_review_not_executed'
            and gate_audit['reviewer'] == 'root' and gate_audit['gate_author'] == 'regression_audit'
            and gate_audit['compiler_preflight_or_native_execution'] is False
            and gate_audit['source_fingerprint'] == KEY and gate_audit['input_count'] == 76
            and gate_audit['scope'] == {'fresh_modules': 24, 'roots': 154, 'subprocesses': 26,
                                      'artifacts': 94, 'snapshots': 76}
            and gate_audit['review_input_occurrences'] == 217
            and gate_audit['distinct_review_input_paths'] == 103,
            'Root control review scope differs')
    require(len(gate_audit['inputs']) == 76
            and {recorded(row['path']): identity(row) for row in gate_audit['inputs']}
                == {row['path']: identity(row) for row in inputs}, 'Root control review/input coverage differs')
    require(results['status'] == 'failed_proof_module_no_native_execution'
            and identity(results['report']) == (338228, REPORT_SHA)
            and results['seconds'] == r['cumulative_execution_seconds']
            and results['peak_rss_kib'] == r['peak_rss_kib']
            and results['attempted_modules'] == 20 and results['accepted_modules'] == 19
            and results['accepted_roots'] == 128 and results['observed_reports'] == 138
            and results['failed_module'] == 'FirstRowReflection'
            and results['failed_module_reports_not_accepted'] == 10
            and results['generated_error_placeholder_axiom_present_in_failed_module_logs'] is True
            and results['source_admission_added'] is False
            and results['canonical_certificate_accepted'] is False
            and results['native_certificate_executed'] is False
            and results['stock_numeral_theorem_proved'] is False
            and results['failure'] == r['failure'] and results['all_input_output_postchecks_passed'] is True
            and results['source_fingerprint'] == KEY and results['consumed_marker'] == marker_row,
            'Frozen root result summary differs')
    require(receipt['format'] == 'adwh-first-row-reflection-root-execution-receipt-v1'
            and receipt['status'] == 'failed_complete_gate_with_concrete_proof_diagnostics'
            and receipt['executor'] == 'root' and receipt['unchanged_mathematical_retry'] is False
            and receipt['source_only_preflight_count'] == receipt['mathematical_attempt_count'] == 1
            and receipt['preflight_completion']['exit_code'] == 0
            and receipt['run_completion']['exit_code'] == 1
            and receipt['complete_external_checker_acceptance'] is False
            and receipt['stock_numeral_theorem_proved'] is False, 'Actual root receipt boundary differs')
    preflight = json.loads(receipt['preflight_completion']['output'], object_pairs_hook=strict_object)
    final = json.loads(receipt['run_completion']['output'], object_pairs_hook=strict_object)
    require(preflight == {'concrete_certificate_executed': False, 'fresh_modules': 24,
        'input_count': 76, 'original_objects': 21, 'required_roots': 154, 'runtime_count': 44,
        'source_fingerprint': KEY, 'status': 'source_only_preflight'}, 'Root preflight receipt differs')
    require(final['status'] == 'failed' and identity(final['report']) == (338228, REPORT_SHA)
            and recorded(final['report']['path']) == str(old_attempt / 'report.json')
            and final['accepted_roots'] == 128 and final['seconds'] == r['cumulative_execution_seconds']
            and final['peak_rss_kib'] == 789892
            and all(final[k] is False for k in ['canonical_certificate_accepted',
                'complete_external_checker_acceptance', 'fresh_universal_source_proofs_passed',
                'native_certificate_executed', 'stock_kernel_numeral_proof', 'stock_numeral_theorem_proved']),
            'Root execution receipt points to a different result')
    print(json.dumps({'status': 'passed_saved_evidence_audit',
        'mode': 'source-only' if args.source_only else 'live', 'raw_report_sha256': REPORT_SHA,
        'result': 'failed_reflection_proof_module_no_native_execution',
        'current_input_bindings': 76, 'current_snapshot_mappings': 76, 'current_snapshot_bytes': 2286194,
        'inherited_original_snapshot_mappings': 18, 'inherited_original_C_mappings': 7,
        'source_review_scopes': {'masked': 33, 'old_endpoint': 53, 'power_two': 22,
                                'worker_correction': 18, 'reflection': 39, 'current_endpoint': 52},
        'source_review_input_occurrences': 217, 'distinct_review_input_paths': 103,
        'raw_current_logs': 40, 'actual_current_commands': 20, 'current_artifact_identities': 78,
        'observed_reports': 138, 'accepted_reports': 128, 'accepted_modules': 19,
        'failed_module_reports_all_unaccepted': 10, 'failed_module_generated_sorryAx_reports': 4,
        'actual_diagnostics': ['unknown_identifier_q', 'unresolved_mapped_sum',
                               'unused_firstChild_simp_argument', 'unused_List.range_simp_argument'],
        'watchdog_event': False, 'native_certificate_executed': False,
        'canonical_certificate_accepted': False, 'stock_numeral_theorem_proved': False,
        'live_filesystem_mode_checks_enforced': not args.source_only,
        'source_only_archive_mode_bits_not_claimed_original': args.source_only,
        'current_artifact_omissions': 78 if args.source_only else 0,
        'original_pool_binary_omissions': 21 if args.source_only else 0,
        'runtime_omissions': 44 if args.source_only else 0,
        'distinct_binding_identities_checked_or_explicitly_omitted': len(checked),
        'explicitly_omitted_distinct_paths': len(skipped),
        'root_result_and_recovery_files_unchanged': True,
        'historical_reader_pending_status_preserved': True,
        'reader_author_is_also_gate_author': True,
        'previous_auditor_or_gate_imported_or_executed': False,
        'new_mathematical_or_native_execution': False}, sort_keys=True))


if __name__ == '__main__':
    main()
