# Complete first-row reflection original-source proof/native gate

## Selected scope and authorship

This is one changed-evaluator experiment: **24 fresh Lean/C modules, 154 exact theorem reports, one fresh native link, and one canonical original-source n16 certificate execution**, all inside one cumulative 30-second interval. The mathematical change is the generic reflected first-row wrapper and its source-correct endpoint. The unchanged masked recursive evaluator supplies exact child values, including its range checks, saturation sentinel and Nat fallback. The proof, C generation, link and numerical call are not separately staged accepted prerequisites.

The runner is adapted directly from the accepted masked-lintfix native protocol. Its original-pool validator, file binding, axiom parser, snapshot/marker/lock procedure, runtime environment, child watchdog, failure capture, final integrity checks and acceptance logic are retained. The `run` body's only substitutions are the executable filename and the selected source/root/command/artifact indices: 22→24 modules, 141→154 reports, 24→26 commands and 88→94 artifacts. `main` changes only its displayed module/root census. Old correspondence/review validators retain their old scope via `MASKED_MODULES`; the lintfix source path is explicitly historical.

`counting_route` authored the reflection sources; `validity_contracts` independently reviewed that 39-input source scope. `regression_audit` authored the current endpoint, driver, selection and gate. Root independently reviews the endpoint/selection and controls and is the sole executor. Historical authorship and review scopes remain separately recorded. Writing or reviewing any of these files does not execute the proofs or a numerical claim.

## Exact source closure

| Fresh module | Reports |
|---|---:|
| SymbolicWord16Core | 4 |
| SymbolicWord16Recurrence | 13 |
| ADWH.Chapter15.QueensBitsPrimitives | 7 |
| ADWH.Chapter15.QueensBitCounting | 10 |
| ADWH.Chapter15.QueensFastCounting | 0 |
| ADWH.Chapter15.QueensNatCounting | 0 |
| FiniteFold | 9 |
| FirstOrderNat | 9 |
| FirstOrderNatSource | 5 |
| FirstOrderNatSourceAudit | 10 |
| SaturatingUInt64 | 8 |
| UInt64MaskOps | 16 |
| UInt64SaturatingCount | 9 |
| UInt64ExactEvaluator | 2 |
| UInt64SourceBridge | 4 |
| UInt64PowerTwoOps | 2 |
| UInt64MaskedCount | 12 |
| UInt64MaskedExact | 4 |
| UInt64MaskedSource | 4 |
| FirstRowReflection | 10 |
| FirstRowReflectionSource | 3 |
| CertifiedNatChecker | 9 |
| FirstRowReflectionQueensNatChecker | 4 |
| FirstRowReflectionRestrictedNatCheckerMain | 0 |

The driver's strict transitive project closure is **23 modules / 144 reports**. The deliberately retained `FirstOrderNatSourceAudit` adds one module and ten actual Fast/Nat source reports. It too is freshly checked and C-generated inside the complete interval. No source or import is silently dropped to obtain the current 24/154 total.

Twenty selected source files are exactly those in the accepted masked-lintfix manifest, including the actual corrected worker. Two are the independently reviewed reflection files. The final two are the current endpoint/driver. Imports, raw print identifiers, fully qualified report roots, exact bytes and hash identities are checked against the frozen inventory. All 154 roots are distinct. Source guards reject admissions, unsafe/partial/native proof escapes, resource-option changes and extra evaluation commands.

The scoped original Counting source retains its exact inverse to the original project source. The original symbolic primitive replacement and every FirstOrder/UInt64/masked proof remain inside the fresh closure. Their prior accepted objects and C files are not used. Each selected source is read from its new readonly snapshot and emits fresh `.olean`, `.ilean` and `.c` files.

## Exact endpoint change and real computation

The current `Endpoint` type and declaration-name token are the actual imported `ADWH.Chapter15.Queens.BitRepresentation.cqueens`. The run/correct fields select `FirstRowReflection.SourceBridge.cqueens` and its all-input source equality. The canonical parser, four theorem statement/proof bodies, input/output claim format and driver IO logic are unchanged from the accepted masked endpoint, apart from the endpoint namespace and exact adapter selection.

The correspondence checks seven endpoint edits and three driver substitutions in both directions, recovering each complete predecessor source. Neither new executable source contains a concrete board-size or expected-answer numeral. For every supported positive board size the reflection implementation pairs actual encoded first-row children; its upper-level arithmetic is Nat. Zero and unsupported sizes retain exact source behavior. No child, total, overflow-bound or expected-answer assumption is supplied to the proofs.

The sole native argv remains the actual canonical claim:

```text
ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

The numeral is a candidate value that the new executable must compare with its own computation. Required stdout is exactly `ACCEPT ` followed by those four tokens separated by spaces, with one final newline. Zero exit, empty stderr and remaining-budget completion are required. No small-count probes or repeated old baseline are selected.

## Original-only object preparation

Only the accepted seven-original native pool may supply prepared objects. Its report is 66,928 bytes, SHA-256 `fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5`. Its unchanged modules are Lists, Permutations, Queens, QueensVariants, QueensSearch, QueensBitRepresentation and QueensBitMoves.

The unchanged validator checks the accepted preparation's full source/control identities, 18 readonly snapshots, permanent marker, 14 commands and empty logs, 28 outputs, and 44 current compiler/header/runtime bindings. The new build copies exactly **21 files: fourteen `.olean`/`.ilean` files and seven `.o` files**. The seven prepared C files are checked provenance, not additional experimental inputs. The separate original preparation cost is 10.480943722002849 seconds and 799,192 KiB.

All 24 experimental/current selected modules remain fresh. The runner cannot silently rebuild missing original objects or accept a different preparation. A source-only restore must separately disclose and validate materialization of this original pool without resetting historical markers or relabeling its old run.

## Source and review control boundaries

The current manifest binds **51 controls and 24 sources**; the manifest itself adds one input, for **76 readonly snapshots**. The controls include the actual current runner/protocol, pinned helper/toolchain, original pool, original Counting/source-bridge identity, exact historical masked/native sources and correction records, the current reflection and endpoint author/review controls, and the two exact predecessor endpoint/driver files. No control is imported as mathematical execution.

The old broad reviews retain their original inputs: masked evaluator33, prior masked endpoint53, and power-two helper22. The actual one-binder lintfix review retains its separate18-input scope and the exact failed snapshot/diagnostic inverse. Its source-only status is preserved; the current gate does not use a prior proof pass as acceptance of current mathematics. The accepted masked report and manifest supply exact source-selection provenance.

The reflection source review contributes **39 exact inputs** and remains a review of two new modules and its own prospective20/131 proof closure. Root's current endpoint/selection review contributes **52 inputs**:24 selected sources,20 author controls,7 original source rows and the current author inventory. Each actual input identity is rehashed; source/root mappings are checked rather than merely trusting a review file's hash. The combined source-review census is **217 input occurrences across six scopes**, including the separately reported18-input correction review. Historical reviews are not rewritten or silently rebased to the current worker, endpoint or gate.

Review-only source/API/provenance inputs not already in the current snapshot set are retained exact references and are rehashed after execution. They supply no compiled experimental object. The resource helper is the only dynamically imported control code, pinned at SHA-256 `2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0`; no prior runner, generator, auditor or mathematical program is imported.

The compiler is Lean4.35.0, commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. All44 native runtime identities must match the accepted original pool. Earlier masked/header/SDK source reviews retain their exact identities and source scopes.

## Invocation and immutable lifecycle

After independent source and control review, root may invoke from this gate directory:

```sh
python3 -I run_complete.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux
python3 -I run_complete.py --toolchain /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux --run
```

The first is metadata-only preflight. The second acquires the unchanged nonblocking shared compile lock, requires an unused `attempts/complete-01` and source-keyed marker, snapshots inputs and copies the original pool, then reserves a permanent readonly marker. The fingerprint binds all24 ordered source identities, current gate format, original pool hash, compiler options, exact argv and complete budget.

No unchanged-source retry is permitted. Failed or successful reports, logs, source/control snapshots and markers are retained. A genuine diagnosed source correction must have a distinct reviewed identity with the failed predecessor preserved. The runner has no retry mode or mechanism to erase a marker.

## One cumulative budget and acceptance

One CPU, one thread, `-j1 -M1024`, a 1,048,576-KiB process-group RSS ceiling, strict warnings/autoImplicit/async settings and default heartbeat/recursion/compiler limits apply. The same watchdog helper monitors all child processes and preserves exit status, high-water usage and raw logs.

The timer begins immediately before the first Lean child. All **26 subprocesses** share that deadline:24 ordered Lean/C commands, one `leanc -O3 -Werror` command over all24 fresh C files plus the seven original native objects, and one actual certificate invocation. The final source/control/runtime/output checks also count within the recorded complete interval. Metadata preparation, snapshots and original copies precede the interval; they perform no mathematical check or numerical evaluation.

The inherited environment is scrubbed of Lean/Lake/compiler/loader/search overrides; only the fresh build and pinned installation are used, with explicit one-thread settings and one-CPU affinity. Every Lean module needs zero exit, no resource event, both Lean objects plus C output, empty stderr, exactly its ordered reports and no residual diagnostic text. Allowed axioms remain `propext`, `Quot.sound` and `Classical.choice`. Failed-module reports contribute zero accepted roots.

Complete success additionally requires exactly **94 artifacts** (72 fresh Lean/C outputs,21 original copies,1 executable), all154 accepted reports, canonical native acceptance, exact final identities and cumulative completion within30seconds. Partial source acceptance, a successful link or an observed line on a later failed run is not complete external-checker acceptance.

## Evidence limits

A successful result would establish fresh ordinary Lean acceptance of all selected universal proofs plus a source-linked compiled external certificate check under the pinned compiler/runtime/I/O boundary. It would not produce a stock Lean proof of the concrete acceptance equation, a stock numeral theorem, a licensed cached-kernel installation or a general checker-success refinement. All such result fields remain false.

No mathematical/compiled/native execution occurred during control authoring. Performance improvement and complete budget fit remain experimental questions. Root independently reviews the actual final controls and alone executes them.
