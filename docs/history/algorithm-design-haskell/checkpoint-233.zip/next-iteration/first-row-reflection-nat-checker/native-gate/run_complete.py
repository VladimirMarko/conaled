#!/usr/bin/env python3
"""Fresh reflected first-row proof/C/native closure and actual original-source certificate."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
WORK = CANDIDATE.parents[1]
MASKED_LINTFIX = WORK / 'next-iteration/uint64-masked-count-lintfix'
REFLECTION = WORK / 'next-iteration/first-row-reflection'
HISTORICAL_CHECKER = WORK / 'next-iteration/uint64-masked-nat-checker'
FAILED_GATE = HISTORICAL_CHECKER / 'native-gate'
FAILED_ATTEMPT = FAILED_GATE / 'attempts/complete-01'
HELPER = WORK / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
HELPER_SHA = '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0'
PIN = WORK / 'next-iteration/lean435-migration/toolchain.json'
PIN_SHA = 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c'
POOL = WORK / 'next-iteration/first-order-nat-evaluator/original-native-preparation/attempts/original-native-01/report.json'
POOL_SHA = 'fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5'
BRIDGE_SHA = 'e63c13e2c263a75902c2829622c1d3720b2d67befe1c63a951a597911ffe8f3b'
BASE_NATIVE_MANIFEST_SHA = 'd85e62dafbed936608b2e8aeaeaa3453b4bdd400b09d96d914b3f1a34f62be8a'
BASE_NATIVE_REPORT_SHA = 'ed6b8c8f8162ee0027900ca8df267cbc3227c4101ec1b362fbb3f200355fef88'
FAILED_MASKED_RUNNER_SHA = '0ae7c415e03466d0f99a190692bd81000d3411c39ae2dbfb880746858b4de7e0'
FAILED_MASKED_PROTOCOL_SHA = 'a4f635c7cf8544ea23319e0715c26eeda89226448b814b1a9b2c16b6d5c80fd8'
FAILED_MASKED_MANIFEST_SHA = '92ed08da4f4c196a3b79481c834ea78a4ea92775e0e8f93ef874a39df1bbe63f'
FAILED_MASKED_REPORT_SHA = '2b5958522701add1d16687403f418872faf4e43c1235871462b3d99c28bb5066'
OLD_WORKER_SHA = '1d2e8e19d420c015a8d6ed3feb1f56b1a442c1c5461ea3514da4a42e7b62e7b1'
CORRECTED_WORKER_SHA = 'ca3cce089bc0f672e85fa1f05057e2ca4a9d6c29d224168b9af258498d63e71d'
LOCK = WORK / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FORMAT = 'adwh-first-row-reflection-native-original-checker-v1'
ORIGINALS = ['ADWH.Chapter01.Lists', 'ADWH.Chapter01.Permutations',
    'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensVariants', 'ADWH.Chapter15.QueensSearch',
    'ADWH.Chapter15.QueensBitRepresentation', 'ADWH.Chapter15.QueensBitMoves']
MASKED_MODULES = ['SymbolicWord16Core', 'SymbolicWord16Recurrence',
    'ADWH.Chapter15.QueensBitsPrimitives', 'ADWH.Chapter15.QueensBitCounting',
    'ADWH.Chapter15.QueensFastCounting', 'ADWH.Chapter15.QueensNatCounting',
    'FiniteFold', 'FirstOrderNat', 'FirstOrderNatSource', 'FirstOrderNatSourceAudit',
    'SaturatingUInt64', 'UInt64MaskOps', 'UInt64SaturatingCount', 'UInt64ExactEvaluator',
    'UInt64SourceBridge', 'UInt64PowerTwoOps', 'UInt64MaskedCount', 'UInt64MaskedExact',
    'UInt64MaskedSource', 'CertifiedNatChecker', 'UInt64MaskedQueensNatChecker',
    'UInt64MaskedRestrictedNatCheckerMain']
MASKED_ROOT_COUNTS = [4, 13, 7, 10, 0, 0, 9, 9, 5, 10, 8, 16, 9, 2, 4, 2, 12, 4, 4, 9, 4, 0]
MODULES = MASKED_MODULES[:19] + ['FirstRowReflection', 'FirstRowReflectionSource',
    'CertifiedNatChecker', 'FirstRowReflectionQueensNatChecker', 'FirstRowReflectionRestrictedNatCheckerMain']
ROOT_COUNTS = MASKED_ROOT_COUNTS[:19] + [10, 3, 9, 4, 0]
MASKED_ACCEPTED_MANIFEST_SHA = '673dbc81d17fdd81e5f666febe59eb1d076d3ce9d71190492dbc4c7eda0f431e'
MASKED_ACCEPTED_REPORT_SHA = '229b123eeda36f20cd1e2edb7f70fde30e22a2c4800c96e5174f3435d1c44828'
MASKED_ACCEPTED_RUNNER_SHA = '3cb469f3138a0c45233edaf6a6ce7dae26da40d953ff158f8a8129c90b47f739'
MASKED_ACCEPTED_PROTOCOL_SHA = '87a9c98409f613fe3927388794aeff0e8793e652989ee4e468a3f03fff02bbb4'
CURRENT_REVIEW_INPUT_COUNT = 52
LEAN_OPTIONS = ['-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true', '-DElab.async=false']
NATIVE_OPTIONS = ['-O3', '-Werror']
ARGV = ['ADWH.Chapter15.Queens.BitRepresentation.cqueens', '16', '=', '14772512']
EXPECTED_STDOUT = ('ACCEPT ' + ' '.join(ARGV) + '\n').encode()
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def relative(module, suffix='.lean'):
    return Path(*module.split('.')).with_suffix(suffix)


def verify(rows, h, readonly=False):
    seen = {}
    for row in rows:
        path = Path(row['path'])
        identity = row['bytes'], row['sha256']
        h.require(str(path) not in seen or seen[str(path)] == identity, 'Conflicting file identities')
        if str(path) not in seen:
            h.require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                      'Changed binding: ' + str(path))
            seen[str(path)] = identity
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot/marker: ' + str(path))


def read(path, h):
    return json.loads(path.read_text(), object_pairs_hook=h.strict_object)


def pool_plan(toolchain, h):
    h.require(POOL.stat().st_size == 66928 and sha(POOL) == POOL_SHA, 'Different original-native preparation')
    p = read(POOL, h)
    h.require(p['format'] == 'adwh-seven-original-native-preparation-v1'
              and p['status'] == 'completed_within_limits' and p['module_order'] == ORIGINALS
              and p['all_7_originals_fresh_lean_c_native'] is True
              and p['inputs_and_outputs_postchecked'] is True
              and p['compiled_experimental_or_checker_objects'] is False
              and p['native_program_linked_or_executed'] is False
              and p['original_preparation_objects_read_or_reused'] is False,
              'Original-native preparation was not accepted in the required scope')
    h.require(len(p['inputs']) == len(p['snapshots']) == 18 and len(p['commands']) == 14
              and len(p['source_modules']) == 7 and len(p['artifacts']) == 28
              and len(p['runtime']) == 44 and 0 <= p['cumulative_execution_seconds'] <= 30
              and p['peak_rss_kib'] <= 1048576, 'Prepared pool census/resources differ')
    h.require(p['limits'] == {'cpu_count': 1, 'cumulative_seconds': 30,
              'default_heartbeats_and_recursion': True, 'lean_memory_mib': 1024, 'rss_kib': 1048576},
              'Prepared pool resource policy differs')
    old_work = Path(p['inputs'][0]['path']).parents[4]
    old_toolchain = Path(p['toolchain'])

    def remap(row):
        path = Path(row['path'])
        if path.is_relative_to(old_work):
            path = WORK / path.relative_to(old_work)
        elif path.is_relative_to(old_toolchain):
            path = toolchain / path.relative_to(old_toolchain)
        else:
            raise ValueError('Pool binding outside work/toolchain: ' + str(path))
        return {**row, 'path': str(path)}

    bindings = [h.binding(POOL)]
    bindings.extend(remap(row) for row in p['inputs'] + p['artifacts'])
    readonly = [remap(row) for row in p['snapshots']] + [remap(p['execution_marker'])]
    bindings.extend(readonly)
    for original, snapshot in zip(p['inputs'], p['snapshots']):
        h.require(snapshot['original_path'] == original['path'] and snapshot['role'] == original['role']
                  and all(snapshot[k] == original[k] for k in ['bytes', 'sha256']), 'Pool snapshot role differs')
    marker = read(Path(remap(p['execution_marker'])['path']), h)
    for key in ['format', 'inputs', 'runtime', 'source_modules', 'module_order', 'source_identity',
                'source_fingerprint', 'original_preparation_provenance']:
        h.require(marker[key] == p[key], 'Pool marker/report mismatch')
    identity = {'format': 'adwh-seven-original-native-preparation-v1',
        'output_mode': 'fresh_lean_c_and_native_objects_no_link',
        'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in p['source_modules']],
        'lean_options': LEAN_OPTIONS, 'native_options': ['-O3', '-Werror', '-c'],
        'output_suffixes': ['.c', '.o', '.olean', '.ilean'], 'complete_budget_seconds': 30}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    h.require(p['source_identity'] == identity and p['source_fingerprint'] == fingerprint
              and Path(p['execution_marker']['path']).name == 'original-native-' + fingerprint + '.json',
              'Pool source-keyed identity differs')
    old_build = Path(p['object_search_path'])
    expected_artifacts = {str(old_build / relative(module, suffix)) for module in ORIGINALS
                          for suffix in ['.c', '.o', '.olean', '.ilean']}
    h.require({row['path'] for row in p['artifacts']} == expected_artifacts, 'Pool includes another object')
    for i, command in enumerate(p['commands']):
        module = ORIGINALS[i % 7]
        if i < 7:
            expected = [str(old_toolchain / 'bin/lean'), *LEAN_OPTIONS,
                '-o', str(old_build / relative(module, '.olean')), '-i', str(old_build / relative(module, '.ilean')),
                '-c', str(old_build / relative(module, '.c')), str(relative(module))]
            cwd = old_build.parent / 'inputs/project/adwh-lean'
            kind = 'lean_c'
        else:
            expected = [str(old_toolchain / 'bin/leanc'), '-O3', '-Werror', '-c',
                str(old_build / relative(module, '.c')), '-o', str(old_build / relative(module, '.o'))]
            cwd, kind = old_build, 'native_object'
        h.require(command['command'] == expected and command['cwd'] == str(cwd)
                  and command['kind'] == kind and command['module'] == module
                  and command['exit_code'] == 0 and command['within_limits'] is True
                  and command['limit_exceeded'] is None, 'Pool command/outcome differs')
        for key in ['stdout', 'stderr']:
            row = remap(command[key])
            bindings.append(row)
            h.require(row['bytes'] == 0, 'Pool command emitted diagnostics')
    runtime_paths = [toolchain / 'bin' / name for name in ['lean', 'leanc', 'clang', 'ld.lld']]
    runtime_paths.extend(path.resolve() for path in (toolchain / 'include/lean').rglob('*') if path.is_file())
    for directory in [toolchain / 'lib', toolchain / 'lib/lean']:
        runtime_paths.extend(path.resolve() for path in directory.iterdir()
            if path.is_file() and not path.name.startswith('.') and (path.suffix == '.a' or '.so' in path.name))
    runtime = [h.binding(path) for path in sorted(set(runtime_paths))]
    h.require(len(runtime) == 44 and
              {str(Path(row['path']).relative_to(toolchain)): (row['bytes'], row['sha256']) for row in runtime} ==
              {str(Path(row['path']).relative_to(old_toolchain)): (row['bytes'], row['sha256'])
               for row in p['runtime']}, 'Native runtime differs from accepted original pool')
    selected = []
    indexed = {row['path']: row for row in p['artifacts']}
    for module in ORIGINALS:
        for suffix in ['.olean', '.ilean', '.o']:
            selected.append({**remap(indexed[str(old_build / relative(module, suffix))]),
                             'module': module, 'suffix': suffix})
    verify(bindings + runtime, h)
    verify(readonly, h, readonly=True)
    return {'report': h.binding(POOL), 'sources': p['source_modules'], 'copy_inputs': selected,
            'bindings': bindings, 'readonly': readonly, 'runtime': runtime,
            'preparation_seconds_separate': p['cumulative_execution_seconds']}


def verify_correspondences(roles, declared, h):
    selected = {row['module']: row for row in declared}
    bridge = read(Path(roles['source_bridge_manifest']['path']), h)
    scope = bridge['scoped_original_source_bridge']
    text = (WORK / selected['ADWH.Chapter15.QueensBitCounting']['path']).read_text()
    for edit in reversed(scope['source_edits']):
        lo, hi = edit['new_character_start'], edit['new_character_end']
        h.require(text[lo:hi] == edit['new'], 'Original count source inverse mismatch')
        text = text[:lo] + edit['old'] + text[hi:]
    h.require(text.encode() == Path(roles['original_count_source']['path']).read_bytes()
              and roles['original_count_source']['sha256'] == scope['exact_inverse_sha256'],
              'Scoped source no longer recovers the actual original counter')

    correspondence = read(Path(roles['checker_correspondence']['path']), h)
    expected = {
        'endpoint': [
            ('import UInt64SourceBridge\n', 'import UInt64MaskedSource\n', 1),
            ('# The exact original cqueens endpoint with the UInt64 exact evaluator',
             '# The exact original cqueens endpoint with the masked UInt64 exact evaluator', 1),
            ('ADWH.Experiments.Chapter15.UInt64QueensNatChecker',
             'ADWH.Experiments.Chapter15.UInt64MaskedQueensNatChecker', 2),
            ('UInt64SaturatingEvaluator.SourceBridge', 'UInt64MaskedEvaluator.SourceBridge', 2)],
        'driver': [('UInt64QueensNatChecker', 'UInt64MaskedQueensNatChecker', 3)]}
    for part, module, predecessor_role in [
            ('endpoint', MASKED_MODULES[-2], 'original_endpoint_source'),
            ('driver', MASKED_MODULES[-1], 'original_driver_source')]:
        item = correspondence[part]
        source = selected[module]
        predecessor = roles[predecessor_role]
        h.require(item['candidate']['path'] == source['path']
                  and all(item['candidate'][k] == source[k] for k in ['bytes', 'sha256'])
                  and item['predecessor']['path'] == predecessor['relative_path']
                  and all(item['predecessor'][k] == predecessor[k] for k in ['bytes', 'sha256']),
                  'Endpoint/driver correspondence identity differs')
        edits = [(e['old'], e['new'], e['occurrences']) for e in item['edits']]
        h.require(edits == expected[part], 'Different endpoint/driver transformation')
        original = Path(predecessor['path']).read_text()
        current = (WORK / source['path']).read_text()
        forward = original
        for before, after, count in edits:
            h.require(forward.count(before) == count, 'Forward source inverse multiplicity differs')
            forward = forward.replace(before, after)
        h.require(forward == current, 'New endpoint/driver is not the exact reviewed variant')
        inverse = current
        for before, after, count in reversed(edits):
            h.require(inverse.count(after) == count, 'Reverse source inverse multiplicity differs')
            inverse = inverse.replace(after, before)
        h.require(inverse == original, 'Full endpoint/driver inverse failed')

    masked = read(Path(roles['masked_correspondence']['path']), h)
    pairs = [('UInt64SaturatingCount', 'UInt64MaskedCount'),
             ('UInt64ExactEvaluator', 'UInt64MaskedExact'),
             ('UInt64SourceBridge', 'UInt64MaskedSource')]
    texts = {}
    for index, (old_module, new_module) in enumerate(pairs):
        for key, module in [('old_sources', old_module), ('new_sources', new_module)]:
            row, source = masked[key][index], selected[module]
            h.require(all(row[k] == source[k] for k in ['path', 'bytes', 'sha256']),
                      'Masked inverse points to another source')
            texts[module] = (WORK / source['path']).read_text()
    def worker(text):
        return text[text.index('mutual\n'):text.index('\ndef evaluate')].rstrip() + '\n'
    old_worker, new_worker = worker(texts[pairs[0][0]]), worker(texts[pairs[0][1]])
    record = masked['mutual_worker_block']
    for label, text in [('old', old_worker), ('new', new_worker)]:
        data = text.encode()
        h.require(len(data) == record[label + '_bytes']
                  and hashlib.sha256(data).hexdigest() == record[label + '_sha256'],
                  'Masked mutual-worker identity differs')
    edits = record['exact_reversible_edits']
    h.require(len(edits) == record['edit_count'] == 3, 'Different masked worker edit count')
    forward = old_worker
    for edit in edits:
        h.require(forward.count(edit['old']) == 1, 'Masked forward edit is ambiguous')
        forward = forward.replace(edit['old'], edit['new'], 1)
    h.require(forward == new_worker, 'Masked worker forward comparison failed')
    for edit in reversed(edits):
        h.require(forward.count(edit['new']) == 1, 'Masked reverse edit is ambiguous')
        forward = forward.replace(edit['new'], edit['old'], 1)
    h.require(forward == old_worker, 'Masked worker inverse failed')
    def fragment(text, start, end):
        return text[text.index(start):text.index(end)] + '\n'
    fragments = [
        (fragment(texts['UInt64SaturatingCount'], 'def evaluate', '\ntheorem count_zero'),
         fragment(texts['UInt64MaskedCount'], 'def evaluate', '\n/-- The tail')),
        (fragment(texts['UInt64ExactEvaluator'], 'def countExact', '\ntheorem countExact_eq'),
         fragment(texts['UInt64MaskedExact'], 'def countExact', '\ntheorem countExact_eq')),
        (fragment(texts['UInt64SourceBridge'], 'def cqueens', '\ntheorem cqueens_eq_firstOrder'),
         fragment(texts['UInt64MaskedSource'], 'def cqueens', '\ntheorem cqueens_eq_saturating'))]
    h.require(len(masked['unchanged_text_fragments']) == 3, 'Different exact-wrapper inventory')
    for (old_text, new_text), row in zip(fragments, masked['unchanged_text_fragments']):
        data = old_text.encode()
        h.require(old_text == new_text and len(data) == row['bytes']
                  and hashlib.sha256(data).hexdigest() == row['sha256'],
                  'Guard/sentinel/Nat fallback/source-entry fragment changed')


def verify_correction(roles, inputs, historical, selected, inventory, h):
    """Validate one source overlay and its real failed predecessor, without executing either."""
    correction = read(Path(roles['correction_map']['path']), h)
    audit = read(Path(roles['correction_source_audit']['path']), h)
    old_worker = historical[16]
    worker = selected[16]
    h.require(old_worker['module'] == worker['module'] == 'UInt64MaskedCount'
              and old_worker['sha256'] == OLD_WORKER_SHA
              and worker['sha256'] == CORRECTED_WORKER_SHA
              and worker['path'] == (MASKED_LINTFIX / 'source/UInt64MaskedCount.lean').relative_to(WORK).as_posix(),
              'Wrong old or corrected worker')
    h.require(correction['format'] == 'adwh-masked-count-unused-binder-correction-v1'
              and correction['edit_count'] == len(correction['edits']) == 1
              and correction['theorem'] ==
                  'ADWH.Experiments.Chapter15.UInt64MaskedEvaluator.branches_eq_of_count',
              'Different correction boundary')
    for key, row in [('predecessor', old_worker), ('candidate', worker)]:
        h.require(correction[key] == {k: row[k] for k in ['path', 'bytes', 'sha256']},
                  'Correction map points to another worker')
    for key, role in [('failed_report', 'failed_masked_report'),
                      ('diagnostic_stdout', 'failed_masked_stdout')]:
        h.require(correction[key] == {'path': roles[role]['relative_path'],
                  'bytes': roles[role]['bytes'], 'sha256': roles[role]['sha256']},
                  'Correction diagnostic/report binding differs')
    before = (WORK / old_worker['path']).read_text()
    after = (WORK / worker['path']).read_text()
    edit = correction['edits'][0]
    h.require(edit['before'].startswith('theorem branches_eq_of_count\n')
              and edit['before'].endswith('(hl : InRange width left)')
              and edit['before'].count('(hl : InRange width left)') == 1
              and edit['after'] == edit['before'].replace(
                  '(hl : InRange width left)', '(_hl : InRange width left)', 1)
              and before.count(edit['before']) == after.count(edit['after']) == 1
              and len(before[:before.index(edit['before'])].encode()) == edit['original_byte_offset']
              and before.replace(edit['before'], edit['after'], 1) == after
              and after.replace(edit['after'], edit['before'], 1) == before,
              'Correction is not the exact one-character binder inverse')
    expected = [dict(row) for row in historical]
    expected[16].update(correction['candidate'])
    h.require(selected == expected, 'Another source/root/import changed with the binder correction')
    h.require(inventory['format'] == 'adwh-masked-count-lintfix-source-inventory-v1'
              and inventory['module_order'] == MASKED_MODULES
              and inventory['required_axiom_report_count'] == 141
              and inventory['fully_qualified_roots'] == {row['module']: row['roots'] for row in selected}
              and inventory['selected_change_count'] == 1
              and inventory['historical_reviews_rebased'] is False
              and len(inventory['inputs']) == inventory['input_count'] == 16,
              'Correction author inventory differs')
    h.require(audit['format'] == 'adwh-masked-count-lintfix-independent-source-audit-v1'
              and audit['status'] == 'passed_source_only_review_not_compiled'
              and len(audit['inputs']) == audit['input_count'] == 18
              and audit['sources'] == [
                  {k: row[k] for k in ['module', 'path', 'bytes', 'sha256']} for row in selected]
              and audit['module_order'] == MASKED_MODULES and audit['required_axiom_report_count'] == 141
              and audit['fully_qualified_roots'] == {'UInt64MaskedCount': worker['roots']},
              'Focused correction review has another boundary')
    for key, role in [('review', 'correction_source_review'),
                      ('historical_source_manifest', 'failed_masked_manifest')]:
        h.require(audit[key] == {'path': roles[role]['relative_path'],
                  'bytes': roles[role]['bytes'], 'sha256': roles[role]['sha256']},
                  'Focused review document/historical scope binding differs')
    expected_review_inputs = inventory['inputs'] + [
        {'path': roles[role]['relative_path'], 'bytes': roles[role]['bytes'],
         'sha256': roles[role]['sha256']}
        for role in ['correction_inventory', 'failed_worker_snapshot']]
    h.require(audit['inputs'] == expected_review_inputs, 'Focused review input list differs')
    known = {row['relative_path']: row for row in inputs}
    h.require(len({row['path'] for row in audit['inputs']}) == 18,
              'Duplicate focused correction input')
    for row in audit['inputs']:
        h.require(row['path'] in known
                  and all(known[row['path']][k] == row[k] for k in ['bytes', 'sha256']),
                  'Correction review input is not explicitly bound by this gate')

    failed = read(Path(roles['failed_masked_report']['path']), h)
    h.require(failed['format'] == 'adwh-uint64-masked-native-original-checker-v1'
              and failed['status'] == 'failed' and failed['source_modules'] == historical
              and failed['module_order'] == MASKED_MODULES
              and len(failed['commands']) == len(failed['axiom_audits']) == 17
              and failed['accepted_axiom_report_count'] == 108
              and failed['observed_axiom_report_count'] == 120
              and failed['inputs_and_outputs_postchecked'] is True
              and failed['native_certificate_executed'] is False
              and failed['canonical_certificate_accepted'] is False
              and failed['fresh_universal_source_proofs_passed'] is False
              and 0 <= failed['cumulative_execution_seconds'] <= 30
              and not failed.get('cumulative_limit_exceeded', False),
              'Actual preceding failure/proof status differs')
    h.require(all(command['exit_code'] == 0 and command['within_limits']
                  and command['limit_exceeded'] is None for command in failed['commands'][:16])
              and all(item['module_passed'] is True for item in failed['axiom_audits'][:16]),
              'Failed predecessor prefix differs')
    command, failed_audit = failed['commands'][-1], failed['axiom_audits'][-1]
    h.require(command['label'] == 'lean-UInt64MaskedCount' and command['exit_code'] == 1
              and command['within_limits'] is True and command['limit_exceeded'] is None
              and failed_audit['module_passed'] is False and failed_audit['accepted_count'] == 0,
              'Preceding failure was not the recorded strict worker rejection')
    raw = audit_axioms(old_worker, {'stdout': roles['failed_masked_stdout'],
                                  'stderr': roles['failed_masked_stderr']}, h)
    h.require(raw['raw_reports'] == failed_audit['raw_reports']
              and raw['unparsed_stdout'] == failed_audit['unparsed_stdout']
              and raw['exact_ordered_roots'] and raw['allowed_axioms_only'] and raw['stderr_empty']
              and raw['unparsed_stdout'].startswith(
                  'UInt64MaskedCount.lean:112:5: error: Variable name `hl` is not explicitly referenced.')
              and not raw['reports_passed'], 'Recorded worker diagnostic/raw roots differ')
    old_inputs = {row['role']: row for row in failed['inputs']}
    old_work = Path(old_inputs['runner']['path']).parents[3]
    def current_saved_path(path):
        path = Path(path)
        h.require(path.is_relative_to(old_work), 'Failure binding outside its recorded workspace')
        return WORK / path.relative_to(old_work)
    for old_role, role in [('runner', 'failed_masked_runner'),
            ('protocol', 'failed_masked_protocol'), ('input_manifest', 'failed_masked_manifest'),
            ('source_UInt64MaskedCount', 'historical_masked_worker')]:
        row = old_inputs[old_role]
        h.require(str(current_saved_path(row['path'])) == roles[role]['path']
                  and all(row[k] == roles[role][k] for k in ['bytes', 'sha256']),
                  'Historical execution input crosslink differs')
    snapshot = next(row for row in failed['snapshots'] if row['role'] == 'source_UInt64MaskedCount')
    h.require(snapshot['original_path'] == old_inputs['source_UInt64MaskedCount']['path']
              and str(current_saved_path(snapshot['path'])) == roles['failed_worker_snapshot']['path']
              and all(snapshot[k] == roles['failed_worker_snapshot'][k] for k in ['bytes', 'sha256'])
              and Path(roles['failed_worker_snapshot']['path']).read_text() == before,
              'Actual failed worker snapshot differs')
    for key, role in [('stdout', 'failed_masked_stdout'), ('stderr', 'failed_masked_stderr')]:
        h.require(str(current_saved_path(command[key]['path'])) == roles[role]['path']
                  and all(command[key][k] == roles[role][k] for k in ['bytes', 'sha256']),
                  'Failed command log crosslink differs')
    marker_row = failed['execution_marker']
    h.require(str(current_saved_path(marker_row['path'])) == roles['failed_masked_marker']['path']
              and all(marker_row[k] == roles['failed_masked_marker'][k] for k in ['bytes', 'sha256']),
              'Failed permanent marker crosslink differs')
    marker = read(Path(roles['failed_masked_marker']['path']), h)
    for key in ['format', 'inputs', 'source_identity', 'source_fingerprint', 'source_modules',
                'module_order', 'runtime', 'argv']:
        h.require(marker[key] == failed[key], 'Failed marker/report content differs')
    verify([roles['failed_masked_marker'], roles['failed_worker_snapshot']], h, readonly=True)
    return {'audit': roles['correction_source_audit'], 'review': roles['correction_source_review'],
        'verified_distinct_input_count': 18, 'exact_one_character_inverse': True,
        'old_worker': correction['predecessor'], 'selected_worker': correction['candidate'],
        'old_review_scopes_preserved': True, 'all_other_21_sources_exact': True,
        'failed_report': roles['failed_masked_report'], 'failed_worker_observed_reports': 12,
        'failed_worker_accepted_reports': 0, 'native_predecessor_execution': False,
        'source_only_review_not_mathematical_acceptance': True,
        'authorship': {'original_masked_source': 'validity_contracts',
                      'correction': 'root', 'correction_review_and_new_gate': 'validity_contracts'}}


def audit_reflection_selection(roles, inputs, declared, inventory, reflection, accepted_masked, pool, toolchain, h):
    """Validate current selection and its two new review scopes without rebasing older ones."""
    h.require(inventory['format'] == 'adwh-first-row-reflection-checker-source-inventory-v1'
              and inventory['module_order'] == MODULES
              and inventory['required_axiom_report_count'] == 154
              and inventory['sources'] == declared
              and len(inventory['inputs']) == inventory['input_count'] == 20
              and inventory['fully_qualified_roots'] == {row['module']: row['roots'] for row in declared}
              and inventory['original_dependency_sources'] == pool['sources'],
              'Current checker inventory differs')
    h.require(inventory['prospective_complete_scope'] == {
        'fresh_modules': 24, 'required_roots': 154, 'Lean_C_generation_commands': 24,
        'native_link_commands': 1, 'actual_certificate_commands': 1, 'total_subprocesses': 26,
        'fresh_Lean_C_outputs': 72, 'copied_original_objects': 21, 'new_executables': 1,
        'expected_total_artifacts': 94, 'all_experimental_mathematics_fresh_in_single_cumulative_interval': True,
        'final_gate_controls_frozen': False}, 'Current24/154/26/94 scope differs')
    h.require(inventory['strict_transitive_import_scope'] == {
        'root_module': MODULES[-1], 'module_count': 23, 'required_roots': 144,
        'explicit_extra_audit_module': 'FirstOrderNatSourceAudit', 'explicit_extra_roots': 10,
        'extra_audit_charged_and_C_generated': True}, 'Explicit source-audit module was omitted or hidden')
    contract = inventory['endpoint_contract']
    h.require(contract['actual_source'] == ARGV[0]
              and contract['run'] == 'ADWH.Experiments.Chapter15.FirstRowReflection.SourceBridge.cqueens'
              and contract['correct'] == 'ADWH.Experiments.Chapter15.FirstRowReflection.SourceBridge.cqueens_eq'
              and inventory['proposed_invocation']['argv'] == ARGV
              and inventory['proposed_invocation']['expected_stdout'].encode() == EXPECTED_STDOUT,
              'Current endpoint does not select the exact source-correct reflection wrapper')
    original_scope = reflection['prospective_source_proof_closure']
    expected_proof = [row for row in declared if row['module'] not in
        ['FirstOrderNatSourceAudit', 'CertifiedNatChecker', *MODULES[-2:]]]
    normalized_proof = [{**{k: row[k] for k in ['module', 'path', 'bytes', 'sha256', 'imports']},
        'roots': row['fully_qualified_roots'], 'raw_prints': row['raw_source_print_identifiers']}
        for row in original_scope['sources']]
    h.require(reflection['format'] == 'adwh-first-row-reflection-source-inventory-v1'
              and normalized_proof == expected_proof
              and original_scope['fresh_module_count'] == 20
              and original_scope['required_axiom_report_count'] == 131
              and original_scope['expected_default_artifact_count'] == 40
              and reflection['required_new_axiom_report_count'] == 13,
              'Historical reflection20/131 source-only scope was silently rebased')
    correspondence = read(Path(roles['current_checker_correspondence']['path']), h)
    h.require(correspondence['format'] == 'adwh-first-row-reflection-checker-source-correspondence-v1'
              and correspondence['edit_count'] == 10
              and correspondence['endpoint_edits'] == 7 and correspondence['driver_edits'] == 3
              and [row['module'] for row in correspondence['files']] == MODULES[-2:],
              'Current endpoint/driver inverse inventory differs')
    old_modules = MASKED_MODULES[-2:]
    for index, item in enumerate(correspondence['files']):
        source, old_source = declared[-2 + index], accepted_masked[-2 + index]
        role = ['predecessor_endpoint_source', 'predecessor_driver_source'][index]
        h.require(old_source['module'] == old_modules[index]
                  and item['candidate'] == {k: source[k] for k in ['path', 'bytes', 'sha256']}
                  and item['original'] == {k: old_source[k] for k in ['path', 'bytes', 'sha256']}
                  and roles[role]['relative_path'] == old_source['path']
                  and all(roles[role][k] == old_source[k] for k in ['bytes', 'sha256'])
                  and len(item['edits']) == [7, 3][index], 'Inverse source identity differs')
        original, current = (WORK / old_source['path']).read_text(), (WORK / source['path']).read_text()
        forward, inverse = original, current
        for edit in item['edits']:
            h.require(forward.count(edit['before']) == 1, 'Ambiguous current forward edit')
            forward = forward.replace(edit['before'], edit['after'], 1)
        for edit in reversed(item['edits']):
            h.require(inverse.count(edit['after']) == 1, 'Ambiguous current inverse edit')
            inverse = inverse.replace(edit['after'], edit['before'], 1)
        h.require(forward == current and inverse == original,
                  'Complete current endpoint/driver forward/inverse differs')
        h.require(not re.search(r'\b(?:16|14772512)\b', current),
                  'Input numeral or candidate answer embedded in current endpoint/driver')
    endpoint = (WORK / declared[-2]['path']).read_text()
    h.require('def endpoint : Endpoint ' + ARGV[0] + ' where' in endpoint
              and '  name := "' + ARGV[0] + '"' in endpoint
              and '  run := FirstRowReflection.SourceBridge.cqueens\n' in endpoint
              and '  correct := FirstRowReflection.SourceBridge.cqueens_eq\n' in endpoint,
              'Actual endpoint body differs from its reviewed source contract')
    known = {row['path']: row for row in inputs}
    provenance, checks, shared = [], [], {}
    scopes = [
        ('reflection_source_audit', 'reflection_source_review',
         'adwh-first-row-reflection-independent-source-audit-v1', 39, ['FirstRowReflection', 'FirstRowReflectionSource']),
        ('current_checker_source_audit', 'current_checker_source_review',
         'adwh-first-row-reflection-checker-independent-source-audit-v1', CURRENT_REVIEW_INPUT_COUNT, MODULES)]
    selected = {row['module']: row for row in declared}
    current_check = None
    for audit_role, review_role, fmt, count, modules in scopes:
        audit_path, review_path = Path(roles[audit_role]['path']), Path(roles[review_role]['path'])
        audit = read(audit_path, h)
        h.require(audit['format'] == fmt and audit['status'] == 'passed_source_only_review_not_compiled'
                  and len(audit['inputs']) == count
                  and (WORK / audit['review']['path']).resolve() == review_path
                  and all(audit['review'][k] == roles[review_role][k] for k in ['bytes', 'sha256']),
                  'Current source-review format, scope or review identity differs')
        seen = {}
        for index, row in enumerate(audit['inputs']):
            name = row['path'];prefix = '../toolchains/lean-4.35.0-linux/'
            path = (toolchain / name[len(prefix):]).resolve() if name.startswith(prefix) else (WORK / name).resolve()
            h.require(path.is_relative_to(WORK) or path.is_relative_to(toolchain / 'src/lean'),
                      'Current review evidence outside work/pinned SDK')
            actual = h.binding(path)
            h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']), 'Changed current review input: ' + name)
            identity = row['bytes'], row['sha256']
            h.require(str(path) not in seen and (str(path) not in shared or shared[str(path)] == identity),
                      'Duplicate/conflicting current review identity')
            seen[str(path)] = shared[str(path)] = identity
            if str(path) in known:
                h.require(all(actual[k] == known[str(path)][k] for k in ['bytes', 'sha256']),
                          'Current review contradicts selected source/control identity')
            else:
                provenance.append({**actual, 'review_role': audit_role, 'review_index': index,
                    'recorded_review_path': name, 'retained_reference_not_prepared_object': True})
        for module in modules:
            row = selected[module]
            h.require(seen.get(str(WORK / row['path'])) == (row['bytes'], row['sha256']),
                      'Current source is absent from its actual review: ' + module)
        h.require({module: audit['fully_qualified_roots'][module] for module in modules} ==
                  {module: selected[module]['roots'] for module in modules}, 'Current reviewed roots differ')
        if audit_role == 'reflection_source_audit':
            expected_rows = reflection['sources'] + reflection['inputs'] + [
                {k: roles['reflection_inventory'][k] for k in ['bytes', 'sha256']} |
                {'path': roles['reflection_inventory']['relative_path']}]
        else:
            expected_rows = inventory['sources'] + inventory['inputs'] + inventory['original_dependency_sources'] + [
                {k: roles['current_checker_inventory'][k] for k in ['bytes', 'sha256']} |
                {'path': roles['current_checker_inventory']['relative_path']}]
            h.require(audit['sources'] == declared and audit['module_order'] == MODULES
                      and audit['required_axiom_report_count'] == 154, 'Current endpoint review selection differs')
        h.require({str((WORK / row['path']).resolve()): (row['bytes'], row['sha256']) for row in expected_rows} == seen,
                  'Current review input set is not the complete declared source/control boundary')
        check = {'review_role': audit_role, 'audit': roles[audit_role], 'review': roles[review_role],
            'verified_input_occurrences': len(audit['inputs']), 'verified_distinct_input_count': len(seen),
            'current_selected_modules_checked': modules,
            'current_selected_report_count': sum(len(selected[module]['roots']) for module in modules),
            'source_only_review_not_mathematical_acceptance': True,
            'historical_scope_rebased': False}
        checks.append(check)
        if audit_role == 'current_checker_source_audit': current_check = check
    verify(provenance, h)
    h.require(current_check is not None, 'Current endpoint/selection review was not bound')
    return provenance, checks, current_check


def preflight(toolchain, h):
    manifest_path = HERE / 'input-manifest.json'
    m = read(manifest_path, h)
    h.require(m['format'] == 'adwh-first-row-reflection-native-checker-inputs-v1'
              and m['frozen_for_review'] is True and m['module_order'] == MODULES
              and m['required_root_count'] == 154 and m['argv'] == ARGV
              and m['lean_options'] == LEAN_OPTIONS and m['native_options'] == NATIVE_OPTIONS,
              'Unfrozen/different complete reflection workload')
    toolchain = toolchain.resolve()
    pool = pool_plan(toolchain, h)
    inputs, roles = [], {}
    for row in m['controls']:
        path = (WORK / row['path']).resolve()
        h.require(path.is_relative_to(WORK) and path.is_file(), 'Control is outside workspace')
        actual = h.binding(path)
        h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']) and row['role'] not in roles,
                  'Control identity/role mismatch')
        entry = {**actual, 'relative_path': path.relative_to(WORK).as_posix(), 'role': row['role']}
        inputs.append(entry)
        roles[row['role']] = entry
    fixed = {'runner': Path(__file__).resolve(), 'protocol': HERE / 'PROTOCOL.md',
        'resource_helper': HELPER, 'toolchain_pin': PIN, 'original_native_report': POOL,
        'source_bridge_manifest': WORK / 'next-iteration/first-order-nat-evaluator/source-bridge-gate/source-manifest.json',
        'original_count_source': WORK / 'project/adwh-lean/ADWH/Chapter15/QueensBitCounting.lean',
        'accepted_native_manifest': WORK / 'next-iteration/uint64-restricted-nat-checker/native-gate/input-manifest.json',
        'accepted_native_report': WORK / 'next-iteration/uint64-restricted-nat-checker/native-gate/attempts/complete-01/report.json',
        'masked_inventory': WORK / 'next-iteration/uint64-masked-evaluator/SOURCE-INVENTORY.json',
        'masked_correspondence': WORK / 'next-iteration/uint64-masked-evaluator/SOURCE-CORRESPONDENCE.json',
        'masked_source_review': WORK / 'next-iteration/uint64-masked-evaluator/INDEPENDENT-REVIEW.md',
        'masked_source_audit': WORK / 'next-iteration/uint64-masked-evaluator/INDEPENDENT-SOURCE-AUDIT.json',
        'checker_inventory': HISTORICAL_CHECKER / 'SOURCE-INVENTORY.json',
        'checker_correspondence': HISTORICAL_CHECKER / 'SOURCE-CORRESPONDENCE.json',
        'checker_plan': HISTORICAL_CHECKER / 'PLAN.md',
        'checker_source_review': HISTORICAL_CHECKER / 'SOURCE-REVIEW.md',
        'checker_source_audit': HISTORICAL_CHECKER / 'SOURCE-AUDIT.json',
        'original_endpoint_source': WORK / 'next-iteration/uint64-restricted-nat-checker/source/UInt64QueensNatChecker.lean',
        'original_driver_source': WORK / 'next-iteration/uint64-restricted-nat-checker/source/UInt64RestrictedNatCheckerMain.lean',
        'correction_plan': MASKED_LINTFIX / 'PLAN.md',
        'correction_map': MASKED_LINTFIX / 'PROOF-CORRECTION.json',
        'correction_inventory': MASKED_LINTFIX / 'SOURCE-INVENTORY.json',
        'correction_source_review': MASKED_LINTFIX / 'SOURCE-REVIEW.md',
        'correction_source_audit': MASKED_LINTFIX / 'SOURCE-AUDIT.json',
        'historical_masked_worker': WORK / 'next-iteration/uint64-masked-evaluator/source/UInt64MaskedCount.lean',
        'failed_masked_runner': FAILED_GATE / 'run_complete.py',
        'failed_masked_protocol': FAILED_GATE / 'PROTOCOL.md',
        'failed_masked_manifest': FAILED_GATE / 'input-manifest.json',
        'failed_masked_gate_review': FAILED_GATE / 'GATE-REVIEW.md',
        'failed_masked_gate_audit': FAILED_GATE / 'GATE-AUDIT.json',
        'failed_masked_report': FAILED_ATTEMPT / 'report.json',
        'failed_masked_stdout': FAILED_ATTEMPT / 'lean-UInt64MaskedCount.stdout.log',
        'failed_masked_stderr': FAILED_ATTEMPT / 'lean-UInt64MaskedCount.stderr.log',
        'failed_masked_marker': FAILED_GATE / 'execution-markers/complete-45967bf2869758069f1442203d025dd71e6110cdf898f8253d509bbd0df19110.json',
        'failed_worker_snapshot': FAILED_ATTEMPT / 'source/UInt64MaskedCount.lean',
        'reflection_plan': REFLECTION / 'PLAN.md',
        'reflection_inventory': REFLECTION / 'SOURCE-INVENTORY.json',
        'reflection_source_review': REFLECTION / 'SOURCE-REVIEW.md',
        'reflection_source_audit': REFLECTION / 'SOURCE-AUDIT.json',
        'current_checker_plan': CANDIDATE / 'PLAN.md',
        'current_checker_correspondence': CANDIDATE / 'SOURCE-CORRESPONDENCE.json',
        'current_checker_inventory': CANDIDATE / 'SOURCE-INVENTORY.json',
        'current_checker_source_review': CANDIDATE / 'SOURCE-REVIEW.md',
        'current_checker_source_audit': CANDIDATE / 'SOURCE-AUDIT.json',
        'masked_accepted_manifest': MASKED_LINTFIX / 'native-gate/input-manifest.json',
        'masked_accepted_report': MASKED_LINTFIX / 'native-gate/attempts/complete-01/report.json',
        'masked_accepted_protocol': MASKED_LINTFIX / 'native-gate/PROTOCOL.md',
        'masked_accepted_runner': MASKED_LINTFIX / 'native-gate/run_complete.py',
        'predecessor_endpoint_source': HISTORICAL_CHECKER / 'source/UInt64MaskedQueensNatChecker.lean',
        'predecessor_driver_source': HISTORICAL_CHECKER / 'source/UInt64MaskedRestrictedNatCheckerMain.lean'}
    h.require(set(roles) == set(fixed) and len(roles) == 51, 'Complete-gate role set differs')
    for role, path in fixed.items():
        h.require(roles[role]['path'] == str(path), 'Control role path differs: ' + role)
    for role, digest in [('resource_helper', HELPER_SHA), ('toolchain_pin', PIN_SHA),
            ('original_native_report', POOL_SHA), ('source_bridge_manifest', BRIDGE_SHA),
            ('accepted_native_manifest', BASE_NATIVE_MANIFEST_SHA),
            ('accepted_native_report', BASE_NATIVE_REPORT_SHA),
            ('failed_masked_runner', FAILED_MASKED_RUNNER_SHA),
            ('failed_masked_protocol', FAILED_MASKED_PROTOCOL_SHA),
            ('failed_masked_manifest', FAILED_MASKED_MANIFEST_SHA),
            ('failed_masked_report', FAILED_MASKED_REPORT_SHA),
            ('historical_masked_worker', OLD_WORKER_SHA),
            ('failed_worker_snapshot', OLD_WORKER_SHA),
            ('masked_accepted_manifest', MASKED_ACCEPTED_MANIFEST_SHA),
            ('masked_accepted_report', MASKED_ACCEPTED_REPORT_SHA),
            ('masked_accepted_protocol', MASKED_ACCEPTED_PROTOCOL_SHA),
            ('masked_accepted_runner', MASKED_ACCEPTED_RUNNER_SHA)]:
        h.require(roles[role]['sha256'] == digest, 'Pinned control differs: ' + role)
    pin = read(PIN, h)
    h.require(pin['version'] == '4.35.0' and pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'Compiler revision differs')
    lean = next(row for row in pool['runtime'] if row['path'] == str(toolchain / 'bin/lean'))
    h.require(all(lean[k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']), 'Lean binary differs')
    old_manifest = read(Path(roles['accepted_native_manifest']['path']), h)
    old_report = read(Path(roles['accepted_native_report']['path']), h)
    h.require(old_report['status'] == 'completed_within_limits'
              and old_report['fresh_universal_source_proofs_passed'] is True
              and old_report['accepted_axiom_report_count'] == 119
              and old_report['source_modules'] == old_manifest['sources'],
              'Historical accepted source provenance differs')
    masked = read(Path(roles['masked_inventory']['path']), h)
    checker = read(Path(roles['checker_inventory']['path']), h)
    h.require(masked['source_bridge_prospective_scope']['module_order'] == MODULES[:19]
              and masked['source_bridge_prospective_scope']['required_axiom_report_count'] == 128
              and masked['sources'][:15] == old_manifest['sources'][:15],
              'Masked source bridge does not preserve the accepted mathematical prefix')
    certified = next(row for row in old_manifest['sources'] if row['module'] == 'CertifiedNatChecker')
    historical_declared = masked['sources'] + [certified] + checker['new_sources']
    failed_manifest = read(Path(roles['failed_masked_manifest']['path']), h)
    correction_inventory = read(Path(roles['correction_inventory']['path']), h)
    accepted_masked_declared = correction_inventory['sources']
    selected_inventory = read(Path(roles['current_checker_inventory']['path']), h)
    reflection_inventory = read(Path(roles['reflection_inventory']['path']), h)
    declared = selected_inventory['sources']
    accepted_masked_manifest = read(Path(roles['masked_accepted_manifest']['path']), h)
    accepted_masked_report = read(Path(roles['masked_accepted_report']['path']), h)
    h.require(accepted_masked_report['status'] == 'completed_within_limits'
              and accepted_masked_report['fresh_universal_source_proofs_passed'] is True
              and accepted_masked_report['complete_external_checker_acceptance'] is True
              and accepted_masked_report['inputs_and_outputs_postchecked'] is True
              and accepted_masked_report['accepted_axiom_report_count'] == 141
              and accepted_masked_report['module_order'] == MASKED_MODULES
              and accepted_masked_report['source_modules'] == accepted_masked_manifest['sources']
                  == accepted_masked_declared
              and accepted_masked_manifest['argv'] == accepted_masked_report['argv'] == ARGV,
              'Historical accepted masked source-selection provenance differs')
    converted_reflection = [
        {**{k: row[k] for k in ['path', 'bytes', 'sha256', 'module', 'imports']},
         'roots': row['fully_qualified_roots'], 'raw_prints': row['raw_source_print_identifiers']}
        for row in reflection_inventory['sources']]
    expected = accepted_masked_declared[:19] + converted_reflection + [accepted_masked_declared[19]] + selected_inventory['new_sources']
    h.require(historical_declared == checker['sources'] == failed_manifest['sources']
              and m['sources'] == declared == expected
              and [row['module'] for row in declared] == MODULES
              and [len(row['roots']) for row in declared] == ROOT_COUNTS
              and checker['required_axiom_report_count'] == 141
              and selected_inventory['required_axiom_report_count'] == 154
              and selected_inventory['fresh_module_order'] == MODULES,
              'Exact current24-source or retained22-source selection differs')
    h.require(checker['original_dependency_sources'] == pool['sources'],
              'Original-only source dependency identities differ')
    seen = set(ORIGINALS)
    for row in declared:
        path = (WORK / row['path']).resolve()
        h.require(path.is_relative_to(WORK) and path.is_file(), 'Source is not a canonical workspace file')
        actual = h.binding(path)
        h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']), 'Fresh source identity differs')
        text = path.read_text()
        h.require(re.findall(r'^import (\S+)$', text, re.M) == row['imports']
                  and re.findall(r'^#print axioms (\S+)$', text, re.M) == row['raw_prints'],
                  'Imports/printed roots differ from final source')
        h.require(not re.search(r'\b(sorry|admit|native_decide|implemented_by|skipKernelTC)\b', text)
                  and not re.search(r'^\s*(axiom|unsafe|partial)\b', text, re.M)
                  and not re.search(r'set_option\s+(maxRecDepth|maxHeartbeats|maxMemory|debug\.|compiler\.)', text)
                  and not re.search(r'^#(?:eval|reduce|check)\b', text, re.M), 'Forbidden source mechanism')
        h.require(all(imp in seen or imp.startswith(('Init', 'Std', 'Lean')) for imp in row['imports']),
                  'Fresh source closure requires another project/experimental import')
        seen.add(row['module'])
        inputs.append({**actual, 'relative_path': row['path'], 'role': 'source_' + row['module']})
    roots = [root for row in declared for root in row['roots']]
    h.require(len(roots) == len(set(roots)) == 154, 'Full root inventory is not exact')
    contract = checker['endpoint_contract']
    h.require(contract['source_type_parameter'] == contract['canonical_name'] == ARGV[0]
              and contract['run'] == 'ADWH.Experiments.Chapter15.UInt64MaskedEvaluator.SourceBridge.cqueens'
              and contract['correct'] == 'ADWH.Experiments.Chapter15.UInt64MaskedEvaluator.SourceBridge.cqueens_eq',
              'Different actual original masked endpoint')
    # The older reviews and their algebraic correspondence keep their exact old rows.
    # Only the separately reviewed one-character overlay selects the new worker.
    verify_correspondences(roles, historical_declared, h)
    review_provenance, review_checks = audit_source_reviews(
        roles, inputs, historical_declared, toolchain, h)
    for check in review_checks:
        check['historically_reviewed_modules_checked'] = check.pop('current_selected_modules_checked')
        check['historically_reviewed_report_count'] = check.pop('current_selected_report_count')
        check['historical_source_rows_not_rebased'] = True
        check['corrected_worker_covered_only_by_separate_overlay_review'] = True
    correction_check = verify_correction(
        roles, inputs, historical_declared, accepted_masked_declared, correction_inventory, h)
    reflection_provenance, reflection_checks, current_check = audit_reflection_selection(
        roles, inputs, declared, selected_inventory, reflection_inventory,
        accepted_masked_declared, pool, toolchain, h)
    review_provenance.extend(reflection_provenance)
    review_checks.extend(reflection_checks)
    review_occurrences = sum(row['verified_input_occurrences'] for row in review_checks) + correction_check['verified_distinct_input_count']
    h.require(len(review_checks) == 5 and review_occurrences == 217,
              'The six distinct historical/current source-review scopes differ')
    inputs.append({**h.binding(manifest_path), 'relative_path': manifest_path.relative_to(WORK).as_posix(),
                   'role': 'input_manifest'})
    h.require(len(inputs) == len({row['path'] for row in inputs}) == 76, 'Input role/path inventory differs')
    identity = {'format': FORMAT, 'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in declared],
        'prepared_pool_sha256': POOL_SHA, 'argv': ARGV, 'lean_options': LEAN_OPTIONS,
        'native_options': NATIVE_OPTIONS, 'complete_budget_seconds': 30}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    verify(inputs, h)
    return {'inputs': inputs, 'source_modules': declared, 'module_order': MODULES,
        'source_identity': identity, 'source_fingerprint': fingerprint, 'toolchain': str(toolchain),
        'compiler_release': pin['version'], 'compiler_commit': pin['commit'],
        'original_native_pool': pool, 'runtime': pool['runtime'], 'argv': ARGV,
        'review_provenance': review_provenance, 'source_review_checks': review_checks,
        'correction_review_check': correction_check,
        'historical_source_manifest': roles['failed_masked_manifest'],
        'historical_masked_failure': roles['failed_masked_report'],
        'historical_source_reviews_rebased': False,
        'historical_accepted_native_sources': roles['accepted_native_report'],
        'new_masked_generic_acceptance_assumed': False,
        'historical_accepted_masked_selection': roles['masked_accepted_report'],
        'current_endpoint_review_check': current_check,
        'source_review_input_occurrences_including_correction': review_occurrences,
        'new_reflection_acceptance_assumed': False,
        'all_current_mathematics_charged_to_single_complete_interval': True,
        'authorship': {'reflection_source': 'counting_route',
                      'reflection_review': 'validity_contracts',
                      'endpoint_driver_selection_and_gate': 'regression_audit',
                      'current_endpoint_and_control_review': 'root', 'executor': 'root'}}


def audit_source_reviews(roles, inputs, declared, toolchain, h):
    known = {row['path']: row for row in inputs}
    selected = {row['module']: row for row in declared}
    provenance, checks = [], []
    helper_audit = WORK / 'next-iteration/uint64-power-two-ops/INDEPENDENT-SOURCE-AUDIT.json'
    helper_review = WORK / 'next-iteration/uint64-power-two-ops/INDEPENDENT-REVIEW.md'
    contracts = [
        ('masked_source_audit', Path(roles['masked_source_audit']['path']),
         Path(roles['masked_source_review']['path']),
         'adwh-uint64-masked-evaluator-independent-source-audit-v1', MASKED_MODULES[:19], 33),
        ('checker_source_audit', Path(roles['checker_source_audit']['path']),
         Path(roles['checker_source_review']['path']),
         'adwh-uint64-masked-checker-independent-source-audit-v1', MASKED_MODULES, 53),
        ('power_two_source_audit', helper_audit, helper_review,
         'adwh-uint64-power-two-ops-independent-source-audit-v1', ['UInt64PowerTwoOps'], 22)]
    verified_review_inputs = {}
    for audit_role, audit_path, review_path, fmt, modules, expected_input_count in contracts:
        if audit_role == 'power_two_source_audit':
            for path in [audit_path, review_path]:
                h.require(str(path) in verified_review_inputs, 'Helper review was not bound by current masked review')
                h.require(all(h.binding(path)[k] == verified_review_inputs[str(path)][k]
                              for k in ['bytes', 'sha256']), 'Nested helper review identity differs')
        audit = read(audit_path, h)
        h.require(audit['format'] == fmt and audit['status'] == 'passed_source_only_review_not_compiled'
                  and len(audit['inputs']) == expected_input_count,
                  'Source audit differs from its declared review boundary')
        review = audit['review']
        actual_review = h.binding(review_path)
        h.require((WORK / review['path']).resolve() == review_path and
                  all(actual_review[k] == review[k] for k in ['bytes', 'sha256']),
                  'Source audit points to a different review document')
        seen = {}
        for index, row in enumerate(audit['inputs']):
            name = row['path']
            prefix = '../toolchains/lean-4.35.0-linux/'
            path = (toolchain / name[len(prefix):]).resolve() if name.startswith(prefix) else (WORK / name).resolve()
            h.require(path.is_relative_to(WORK) or path.is_relative_to(toolchain / 'src/lean'),
                      'Source-review evidence outside work/pinned API sources')
            actual = h.binding(path)
            h.require(all(actual[k] == row[k] for k in ['bytes', 'sha256']), 'Changed reviewed input: ' + name)
            identity = row['bytes'], row['sha256']
            h.require(str(path) not in seen or seen[str(path)] == identity, 'Conflicting audit input identities')
            seen[str(path)] = identity
            h.require(str(path) not in verified_review_inputs or
                      all(verified_review_inputs[str(path)][k] == actual[k] for k in ['bytes', 'sha256']),
                      'Conflicting identities across source reviews')
            verified_review_inputs[str(path)] = actual
            if str(path) in known:
                h.require(all(actual[k] == known[str(path)][k] for k in ['bytes', 'sha256']),
                          'Review input disagrees with selected source/control role')
            else:
                provenance.append({**actual, 'review_role': audit_role, 'review_index': index,
                    'recorded_review_path': name, 'retained_reference_not_prepared_object': True})
        for module in modules:
            source = selected[module]
            h.require(seen.get(str(WORK / source['path'])) == (source['bytes'], source['sha256']),
                      'Selected source absent from its source review: ' + module)
        reviewed_roots = audit['fully_qualified_roots']
        if isinstance(reviewed_roots, dict):
            h.require({module: reviewed_roots[module] for module in modules} ==
                      {module: selected[module]['roots'] for module in modules}, 'Reviewed roots differ')
        else:
            h.require(modules == ['UInt64PowerTwoOps'] and reviewed_roots == selected[modules[0]]['roots'],
                      'Reviewed helper roots differ')
        if audit_role == 'masked_source_audit':
            h.require(audit['sources'] == declared[:19]
                      and audit['source_bridge_prospective_scope']['module_order'] == MASKED_MODULES[:19]
                      and audit['source_bridge_prospective_scope']['required_axiom_report_count'] == 128,
                      'Masked review has another original-source scope')
        if audit_role == 'checker_source_audit':
            h.require(audit['sources'] == declared and audit['module_order'] == MASKED_MODULES
                      and audit['required_axiom_report_count'] == 141, 'Endpoint review has another full scope')
        checks.append({'review_role': audit_role, 'audit': h.binding(audit_path), 'review': actual_review,
            'verified_input_occurrences': len(audit['inputs']), 'verified_distinct_input_count': len(seen),
            'current_selected_modules_checked': modules,
            'current_selected_report_count': sum(len(selected[module]['roots']) for module in modules),
            'source_only_review_not_mathematical_acceptance': True,
            'historical_helper_prospective_scope_not_relabelled_as_current_complete_gate':
                audit_role == 'power_two_source_audit'})
    verify(provenance, h)
    h.require(sum(row['verified_input_occurrences'] for row in checks) == 108,
              'Source-review input occurrence census differs')
    return provenance, checks


def audit_axioms(source, result, h):
    out, err = Path(result['stdout']['path']).read_text(), Path(result['stderr']['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axioms.split(',') if a.strip()]}
           for root, axioms in pattern.findall(out)]
    residual = pattern.sub('', out).strip()
    exact = [row['root'] for row in raw] == source['roots']
    allowed = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'module': source['module'], 'required_roots': source['roots'], 'raw_reports': raw,
        'observed_count': len(raw), 'observed_unique_count': len({row['root'] for row in raw}),
        'exact_ordered_roots': exact, 'allowed_axioms_only': allowed, 'stderr_empty': not err,
        'unparsed_stdout': residual, 'reports_passed': exact and allowed and not err and not residual,
        'accepted_count': 0}


def run(plan, h):
    attempt = HERE / 'attempts/complete-01'
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Complete attempt or source-keyed marker exists')
    h.require(Path('/proc/self/status').is_file(), 'RSS monitoring requires /proc')
    attempt.mkdir(parents=True)
    source_root, build = attempt / 'source', attempt / 'build'
    source_root.mkdir()
    build.mkdir()
    report_path = attempt / 'report.json'
    executable = build / 'first-row-reflection-original-queens-checker'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': 'complete-01', **plan,
        'snapshots': [], 'copied_original_objects': [], 'execution_marker': None,
        'commands': [], 'artifacts': [], 'axiom_audits': [], 'accepted_axiom_report_count': 0,
        'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
        'accepted_unique_axiom_root_count': 0,
        'required_axiom_report_count': 154, 'inputs_and_outputs_postchecked': False,
        'all_new_mathematical_sources_freshly_checked_and_c_generated': False,
        'fresh_universal_source_proofs_passed': False, 'native_certificate_executed': False,
        'canonical_certificate_accepted': False, 'stock_numeral_theorem_proved': False,
        'compiled_experimental_objects_reused': False, 'complete_external_checker_acceptance': False,
        'acceptance_output_observed': False, 'stock_kernel_numeral_proof': False,
        'concrete_Lean_acceptance_equation_proved': False, 'kernel_extension_implemented': False,
        'limits': {'cumulative_seconds': 30, 'cpu_count': 1, 'rss_kib': 1048576,
                   'lean_memory_mib': 1024, 'default_heartbeats_and_recursion': True}}
    h.save(report_path, report)
    cpus, began = os.sched_getaffinity(0), None
    try:
        for row in plan['inputs']:
            if row['role'].startswith('source_') and row['role'][7:] in MODULES:
                target = source_root / relative(row['role'][7:])
            else:
                target = attempt / 'inputs' / row['relative_path']
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            target.chmod(0o444)
            binding = h.binding(target)
            h.require(all(binding[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot mismatch')
            report['snapshots'].append({**binding, 'original_path': row['path'], 'role': row['role']})
        for row in plan['original_native_pool']['copy_inputs']:
            target = build / relative(row['module'], row['suffix'])
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            binding = h.binding(target)
            h.require(all(binding[k] == row[k] for k in ['bytes', 'sha256']), 'Prepared object copy mismatch')
            report['copied_original_objects'].append({'source': row, 'copy': binding})
            report['artifacts'].append(binding)
        verify(plan['inputs'] + plan['runtime'] + plan['original_native_pool']['bindings'] +
               plan['review_provenance'], h)
        verify(report['snapshots'] + plan['original_native_pool']['readonly'], h, readonly=True)
        marker.parent.mkdir(parents=True, exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': str(attempt), **plan}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(cpus)
        os.sched_setaffinity(0, {cpu})
        toolchain = Path(plan['toolchain'])
        env = {k: v for k, v in os.environ.items()
               if not k.startswith(('LEAN_', 'LAKE_', 'COMPARATOR_', 'PYTHON', 'CCACHE_', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS'))
               and k not in {'LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'CC', 'CXX', 'CXXFLAGS',
                             'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH',
                             'COMPILER_PATH', 'GCC_EXEC_PREFIX'}}
        env.update(LEAN_PATH=str(build), LEAN_NUM_THREADS='1', LEAN_ABORT_ON_PANIC='1',
                   LEAN_SYSROOT=str(toolchain),
                   LD_LIBRARY_PATH=str(toolchain / 'lib/lean') + ':' + str(toolchain / 'lib'),
                   OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        env['PATH'] = str(toolchain / 'bin') + os.pathsep + env.get('PATH', '')
        commands = []
        for module in MODULES:
            (build / relative(module)).parent.mkdir(parents=True, exist_ok=True)
            commands.append(('lean-' + module, [str(toolchain / 'bin/lean'), *LEAN_OPTIONS,
                '-o', str(build / relative(module, '.olean')), '-i', str(build / relative(module, '.ilean')),
                '-c', str(build / relative(module, '.c')), str(relative(module))], source_root))
        commands.append(('native-link', [str(toolchain / 'bin/leanc'), *NATIVE_OPTIONS,
            *[str(build / relative(module, '.c')) for module in MODULES],
            *[str(build / relative(module, '.o')) for module in ORIGINALS], '-o', str(executable)], build))
        commands.append(('certificate-n16', [str(executable), *ARGV], build))
        report.update(status='running', cpu=cpu, object_search_path=str(build),
            declared_environment={key: env[key] for key in ['LEAN_PATH', 'LEAN_NUM_THREADS',
                'LEAN_ABORT_ON_PANIC', 'LEAN_SYSROOT', 'LD_LIBRARY_PATH', 'OMP_NUM_THREADS',
                'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']})
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for index, (label, command, cwd) in enumerate(commands):
            result = h.child(command, cwd, env, attempt / (label + '.stdout.log'),
                             attempt / (label + '.stderr.log'), cpu, deadline)
            report['commands'].append({'label': label, 'cwd': str(cwd), **result})
            if index == 25:
                report['native_certificate_executed'] = True
            h.save(report_path, report)
            if index < 24:
                audit = audit_axioms(plan['source_modules'][index], result, h)
                outputs = [build / relative(MODULES[index], suffix) for suffix in ['.c', '.olean', '.ilean']]
                present = all(path.is_file() for path in outputs)
                passed = result['exit_code'] == 0 and result['within_limits'] and audit['reports_passed'] and present
                audit.update(required_outputs_present=present, module_passed=passed,
                             accepted_count=len(audit['raw_reports']) if passed else 0)
                report['axiom_audits'].append(audit)
                report['observed_axiom_report_count'] += audit['observed_count']
                report['observed_unique_axiom_root_count'] = len({row['root'] for item in report['axiom_audits']
                                                                for row in item['raw_reports']})
                report['accepted_axiom_report_count'] += audit['accepted_count']
                report['accepted_unique_axiom_root_count'] = len({row['root'] for item in report['axiom_audits']
                    if item['module_passed'] for row in item['raw_reports']})
                for path in outputs:
                    if path.is_file():
                        report['artifacts'].append(h.binding(path))
                h.save(report_path, report)
                h.require(passed, 'Lean child/report/output validation failed: ' + label)
                if index == 23:
                    h.require(report['accepted_axiom_report_count'] == 154, 'Incomplete fresh source proof closure')
                    report['fresh_universal_source_proofs_passed'] = True
            elif index == 24:
                h.require(result['exit_code'] == 0 and result['within_limits'], 'Child failed: ' + label)
                h.require(not Path(result['stdout']['path']).read_bytes() and
                          not Path(result['stderr']['path']).read_bytes(), 'Native compiler diagnostics')
                report['artifacts'].append(h.binding(executable))
            else:
                h.require(result['exit_code'] == 0 and result['within_limits'], 'Child failed: ' + label)
                h.require(Path(result['stdout']['path']).read_bytes() == EXPECTED_STDOUT and
                          not Path(result['stderr']['path']).read_bytes(), 'Concrete certificate was not accepted canonically')
                report['acceptance_output_observed'] = True
                report['canonical_certificate_accepted'] = True
                report['concrete_certificate'] = {'argv': ARGV, 'stdout': result['stdout'],
                    'stderr': result['stderr'], 'exit_code': result['exit_code'],
                    'executable': h.binding(executable), 'evidence_kind': 'compiled_external_checker_acceptance'}
            h.save(report_path, report)
        h.require(report['accepted_axiom_report_count'] == 154 and len(report['axiom_audits']) == 24
                  and report['acceptance_output_observed'] is True, 'Incomplete proof/execution closure')
        report['status'] = 'completed_within_limits'
    except BaseException as exc:
        report.update(status='failed', failure={'type': type(exc).__name__, 'message': str(exc)})
    finally:
        captured = {row['path'] for row in report['artifacts']}
        for artifact in sorted(build.rglob('*')):
            if artifact.is_file() and str(artifact.resolve()) not in captured:
                report['artifacts'].append({**h.binding(artifact), 'captured_after_failure': True})
        try:
            verify(plan['inputs'] + plan['runtime'] + plan['original_native_pool']['bindings'] +
                   plan['review_provenance'] + report['artifacts'], h)
            verify(report['snapshots'] + plan['original_native_pool']['readonly'], h, readonly=True)
            verify([row[key] for row in report['commands'] for key in ['stdout', 'stderr']], h)
            h.require(len(report['snapshots']) == len(plan['inputs']) and len(report['copied_original_objects']) == 21,
                      'Incomplete input snapshots/original copies')
            h.require(report['execution_marker'] is not None, 'Missing permanent execution marker')
            verify([report['execution_marker']], h, readonly=True)
            if report['status'] == 'completed_within_limits':
                expected = {str(build / relative(module, suffix)) for module in MODULES
                            for suffix in ['.c', '.olean', '.ilean']}
                expected |= {str(build / relative(module, suffix)) for module in ORIGINALS
                             for suffix in ['.o', '.olean', '.ilean']}
                expected.add(str(executable))
                h.require(len(report['artifacts']) == len(expected) == 94
                          and {row['path'] for row in report['artifacts']} == expected
                          and {str(path) for path in build.rglob('*') if path.is_file()} == expected
                          and len(report['commands']) == 26, 'Different final build/command inventory')
            report['inputs_and_outputs_postchecked'] = True
        except BaseException as exc:
            report.update(status='failed', postcheck_failure={'type': type(exc).__name__, 'message': str(exc)})
        report['cumulative_execution_seconds'] = None if began is None else time.monotonic() - began
        report['peak_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['commands']), default=0)
        if began is not None and report['cumulative_execution_seconds'] > 30:
            report.update(status='failed', cumulative_limit_exceeded=True)
        try:
            os.sched_setaffinity(0, cpus)
        except BaseException as exc:
            report.update(status='failed', affinity_restore_failure={'type': type(exc).__name__, 'message': str(exc)})
        accepted = report['status'] == 'completed_within_limits'
        report['all_new_mathematical_sources_freshly_checked_and_c_generated'] = accepted
        report['complete_external_checker_acceptance'] = accepted
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
        'seconds': report['cumulative_execution_seconds'], 'peak_rss_kib': report['peak_rss_kib'],
        'accepted_roots': report['accepted_axiom_report_count'],
        'fresh_universal_source_proofs_passed': report['fresh_universal_source_proofs_passed'],
        'native_certificate_executed': report['native_certificate_executed'],
        'canonical_certificate_accepted': report['canonical_certificate_accepted'],
        'complete_external_checker_acceptance': report['complete_external_checker_acceptance'],
        'stock_kernel_numeral_proof': False, 'stock_numeral_theorem_proved': False}, sort_keys=True))
    return 0 if report['status'] == 'completed_within_limits' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain', required=True, type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if sha(HELPER) != HELPER_SHA:
        raise ValueError('Pinned resource helper differs')
    spec = importlib.util.spec_from_file_location('uint64_complete_native_resource', HELPER)
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    h.require(h.MEMORY_KIB == 1048576, 'RSS policy changed')
    plan = preflight(args.toolchain, h)
    if not args.run:
        print(json.dumps({'status': 'source_only_preflight', 'source_fingerprint': plan['source_fingerprint'],
            'fresh_modules': 24, 'required_roots': 154, 'original_objects': 21,
            'input_count': len(plan['inputs']), 'runtime_count': len(plan['runtime']),
            'concrete_certificate_executed': False}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
