import CertifiedNatChecker
import FirstRowReflectionSource

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# The exact original cqueens endpoint with the first-row reflection evaluator

The source in the endpoint type is the actual imported ADWH definition.
Its implementation uses the total first-row reflection wrapper. Each selected
child retains the masked UInt64 evaluator's exact Nat fallback, and the
correctness field is the universal original-source theorem.
The candidate numeral is only compared with the computed result.

The canonical parser is reused unchanged. A successful compiled execution
would be external-checker evidence under its compiler/runtime and I/O boundary;
it does not create a stock Lean proof of the concrete acceptance equation.
This module remains a source candidate until its full import closure is
freshly checked under a separate reviewed gate.
-/

namespace ADWH.Experiments.Chapter15.FirstRowReflectionQueensNatChecker

open CertifiedNatChecker

def endpoint : Endpoint ADWH.Chapter15.Queens.BitRepresentation.cqueens where
  name := "ADWH.Chapter15.Queens.BitRepresentation.cqueens"
  run := FirstRowReflection.SourceBridge.cqueens
  correct := FirstRowReflection.SourceBridge.cqueens_eq

def accept (tokens : List String) : Option Claim :=
  acceptTokens endpoint tokens

theorem endpoint_name :
    endpoint.name = "ADWH.Chapter15.Queens.BitRepresentation.cqueens" := rfl

theorem checks_actual_source (claim : Claim) :
    checkClaim endpoint claim = true ↔
      ADWH.Chapter15.Queens.BitRepresentation.cqueens claim.input = claim.value :=
  checkClaim_iff endpoint claim

/-- Success binds both the exact canonical request and its equality to the
actual original source function. No count bound is assumed. -/
theorem accepts_original {tokens : List String} {claim : Claim}
    (h : accept tokens = some claim) :
    tokens = ["ADWH.Chapter15.Queens.BitRepresentation.cqueens",
      Nat.repr claim.input, "=", Nat.repr claim.value] ∧
      ADWH.Chapter15.Queens.BitRepresentation.cqueens claim.input = claim.value :=
  acceptTokens_sound endpoint h

theorem accepts_canonical_iff (claim : Claim) :
    accept ["ADWH.Chapter15.Queens.BitRepresentation.cqueens",
      Nat.repr claim.input, "=", Nat.repr claim.value] = some claim ↔
      ADWH.Chapter15.Queens.BitRepresentation.cqueens claim.input = claim.value :=
  acceptTokens_render_iff endpoint claim

#print axioms endpoint_name
#print axioms checks_actual_source
#print axioms accepts_original
#print axioms accepts_canonical_iff

end ADWH.Experiments.Chapter15.FirstRowReflectionQueensNatChecker
