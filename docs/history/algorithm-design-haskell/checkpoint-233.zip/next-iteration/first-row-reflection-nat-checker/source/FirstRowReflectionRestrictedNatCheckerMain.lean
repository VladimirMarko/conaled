import FirstRowReflectionQueensNatChecker

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/- The command-line arguments themselves are the certificate token vector.
No file parser, evaluator selector, alternate declaration, or dynamic loading
is present. The external runner must retain the exact argv, output, source,
compiler/runtime and executable bindings. -/

def main (args : List String) : IO UInt32 := do
  match ADWH.Experiments.Chapter15.FirstRowReflectionQueensNatChecker.accept args with
  | none =>
      IO.println "REJECT"
      return 1
  | some claim =>
      let tokens := ADWH.Experiments.Chapter15.CertifiedNatChecker.renderTokens
        ADWH.Experiments.Chapter15.FirstRowReflectionQueensNatChecker.endpoint claim
      IO.println ("ACCEPT " ++ String.intercalate " " tokens)
      return 0
