# The actual typed cache-insertion seam

Status: source-only assessment of ConLeche revision
`67f04630d88718e81aa4d07ab64501f68f105398`. No source variant, theorem,
compiler run, gate, cache insertion or count was executed. The checkpoint203
results and controls are unchanged. `SOURCE-INVENTORY.json` gives the exact
source bindings, imported module closures, resource options and retained
excerpts underlying this note.

## Decision

There is a concrete insertion point: **inside `ConLeche.Cached.checkPending`,
after `flushC`, at the restricted declaration-prefix view, before the first
inference**. The pure reducer need not change. The existing driver does not
expose a hook at that point, however, and its typed success evidence refers to
the exact current function. A new cached-driver variant and a corresponding
adaptation of the actual `checkPending_run` proof are necessary. An externally
prepared cache or a new record carrying an assumed run theorem is not that
integration.

The principal missing mathematics is still an actual whole-evaluator
normalization theorem. The new operational guards do not supply it. The
existing verification imports also exceed the previously accepted logical
reference closure substantially and contain explicit resource overrides and
unsafe metaprogramming. No claim is made that this integration fits the fixed
fresh gate. The next useful source step, once whole normalization is available,
is a dependency-preserving cut for the real cached-driver proof, not a gate
that merely reproves an abstract insertion contract.

## Ownership and the exact view

All paths in this section are relative to the pinned upstream checkout;
line ranges are reproduced as evidence excerpts in the inventory.

| Actual source | State or evidence it owns |
|---|---|
| `ConLeche/Cached/StateC.lean:115–153` | `CState` and `CheckCM := StateT CState CheckM`; the full-normalization cache is `whnfC`. |
| `ConLeche/Cached/Installed.lean:144–185` | Phase A `annotStepC` installs annotated definitions and theorem headers and queues `PendingCheck` records. Their `vis` is read **before** pushing the declaration. Ordinary value checks remain deferred. |
| `ConLeche/Cached/Installed.lean:269–285` | `checkPending` threads the state during one record's actual checking. It flushes, selects `fe.restrictTo pc.vis`, infers the type, checks the sort, annotates theorem values, then infers and compares the value type. |
| `ConLeche/Cached/Installed.lean:291–296,369–393,435–440` | `GroupChecked` is success of that exact `checkPending` from `{}`. `checkRecord`, `checkRecordResult` and `checkPendingList` create/use that fresh-state computation. |
| `Main.lean:169–184,245–260` | The actual sequential and worker entry points call those typed record checkers. No `CState` seeding argument is exposed here. |

Thus the whole source environment is physically installed before phase B,
but the record is checked against its original prefix, and installation is
not semantic certification of all queued definitions. A seed inserted during
phase A or passed to the current `checkPending` would be cleared immediately.

`FEnv.restrictTo` changes only `visibleBelow`; **its `.env` field still contains
the full final environment** (`Kernel/FEnv.lean:73–94`). In particular,
passing `(fe.restrictTo pc.vis).env` to the current `Env`-based NatRec guard
would inspect declarations that the real checker may hide. The new hook must
inspect the restricted `find?`, then transport its facts through the actual
prefix lookup agreement. Alternatively, a separately proved implementation
may inspect `Env.prefixTo`. The latter is a newest-first list tail, and the
existing index/prefix equality requires name uniqueness
(`Verify/EnvBound.lean:113–123,190–199`).

The existing `InstalledC.checkPending_run` already has the correct premise:

```lean
hfind : ∀ n, (feFinal.restrictTo pc.vis).find? n = env.find? n
```

`Model.InstallRun.installRun_model` obtains this agreement from the actual
installation chain and invokes the pending-check theorem at the declaration's
earlier environment (`Model/InstallRun.lean:108–123`). This is the relevant
existing bridge; assuming that the final environment is interchangeable with
the prefix would bypass it.

## What insertion proves, and what it does not

The exact existing theorem is `CSOK.insertWhnfC` in
`Verify/Cached/KnotC.lean:79–96`. Its extra premise is:

```lean
∃ F, ∀ d, Expr.wscopedB d i = true →
  ConLeche.whnf mode env F d i = .ok j
```

Together with `CSOK mode env s`, it proves the same invariant for
`{ s with whnfC := s.whnfC.insert i j }`. The witness fuel is common to every
scoped ambient depth. Equality of an evaluator's mathematical count to the
desired number is insufficient: this is a run of the **actual pure reducer
on the actual installed expression**. A mere head step is also insufficient
for a `whnfC` entry. The other two WHNF caches have different contracts.

`CSOK` records that exact clause (`Verify/Cached/SimC.lean:226–279`).
`memoEI` performs the real lookup, and `coreKnotI` uses it for the full-WHNF
slot (`Cached/CoreC.lean:1916–1930,1998–2009`).
`memoEI_whnf_sim` consumes the cached clause on a hit and returns the same
expression as a pure successful run (`Verify/Cached/KnotC.lean:309–359`).
Hash equality is not the justification: insertion uses
`Std.HashMap.getElem?_insert` and `Expr.beq_sound`, which establishes actual
expression equality. Names can select records to inspect; names or hashes
alone cannot identify their semantics.

There is an important typed-entry boundary. `GroupChecked` asserts successful
execution of the **unmodified** `checkPending ... {}`. A successful seeded
variant does not directly inhabit it. `CSOK.insertWhnfC` establishes an
invariant, not equality with the old driver's complete run. Cached simulation
provides an existential pure fuel; it does not assert that the original
fresh-cache checker succeeds at its fixed `checkFuel = 100000`
(`Kernel/Core.lean:2063`). That algorithm constant is separate from the
external 30-second/one-CPU/1-GiB proof gate.

The smallest concrete driver patch is therefore:

1. Retain the actual pending-check body and insert one guarded state update
   after its flush and prefix-view selection. Decline without changing state
   unless the actual view, exact query and complete source/operation pins
   match. Compute the value through the proved evaluator; no expected-answer
   literal or external success token becomes a premise.
2. In the actual `InstalledC.checkPending_run` proof, keep the flush proof,
   use `flushC_csok`, then apply `CSOK.insertWhnfC` on the successful guard
   branch; use the unchanged invariant on the declined branch. The remaining
   inference/annotation/defeq simulations consume that invariant.
3. Reconnect the revised pending checker to the real `GroupChecked`, record
   driver, installation fold and its model theorem. Fresh checking must cover
   changed dependent proofs; renaming the function does not inherit the old
   soundness theorem. This remains an external-checker integration, not a
   stock Lean numeral proof.

This describes an actual source patch boundary, not a prepared or checked
implementation.

## Cache lifetime

`FEnv.push` and `FEnv.restrictTo` do not clear any state themselves.
The drivers explicitly enforce the environment boundary. `CState.flushed`
clears the three stored/instantiated-constant caches, all normalization,
inference, annotation and defeq caches, and `instC`. It preserves only the
tagged, self-certifying `ienv` and the three level-operation caches
(`Cached/StateC.lean:355–365`). `CSOKF` expresses precisely this residue, and
`flushC_csok` rebuilds `CSOK` for **any** new environment
(`Verify/Cached/SimC.lean:281–320`).

Phase A's ordinary value installation and theorem-header installation each
flush. The staged inductive checker flushes on its explicit environment
transitions, including entry/exit of the rule-less recursor view
(`Cached/CheckerC.lean:113–177`). Every phase-B record starts fresh and
flushes again. The proposed optimization should preserve this discipline;
cross-record sharing would introduce a different invariant obligation.

## Exact imported boundaries and remaining cost

The table counts local upstream Lean modules, excluding the pinned toolchain
imports. Counts/bytes were derived from the retained import graph and checked
against all corresponding local source hashes. They are **source import
closures**, not measurements and not minimal elaborated declaration cones.

| Existing import boundary | Modules | Source bytes | Resource-option occurrences / files |
|---|---:|---:|---:|
| `Cached.StateC` | 24 | 573,301 | 0 / 0 |
| `Verify.Cached.SimC` (`CSOK`, flush facts) | 52 | 1,252,621 | 10 / 4 |
| `Verify.Cached.KnotC` (actual insertion theorem) | 95 | 2,376,810 | 16 / 9 |
| `Cached.Installed` (actual typed record checker) | 57 | 1,119,416 | 2 / 1 |
| `KnotC` together with `Cached.Installed` | 97 | 2,409,244 | 16 / 9 |
| `Verify.Cached.InstalledC` (actual pending-check simulation) | 146 | 3,237,128 | 18 / 11 |
| `Model.InstallRun` (typed installation/model bridge) | 510 | 9,959,859 | 115 / 54 |
| `Verify.Cached.MainC` (whole declaration-fold soundness) | 511 | 9,963,191 | 115 / 54 |

The exact ordered closures and every resource-option site are in the
inventory. In the 146-module pending-check closure, `NatOpPins` sets
`maxRecDepth 1000000` and `maxHeartbeats 1000000` for its pin loader; the
verification tower has heartbeat overrides from 800,000 through 3,200,000
and three depth overrides of 2,048. It also imports three JSON pin bundles
totalling 2,050,633 bytes. These are actual non-Lean build inputs omitted
from the Lean source-byte totals, not optional metadata. Their applicability
to a particular new export has not been tested here.

A masked source scan also finds the original `Exclusive` unsafe/implemented-by
pair and three such metaprogramming pairs in `Kernel.BasisGen`. The accepted
21-module logical slice does not automatically settle these broader imports.
Its compatibility changes, omitted compiler-simplification proofs, strict
implicit-binder setting and any newly required definitions must be reconciled
explicitly. None of the observed overrides or trust mechanisms is approved
by this assessment.

There is a potentially smaller **declaration extraction**, but it is not the
existing imported theorem: `RelC`, `CSOK` and its residue/flush facts can be
separated from the unrelated simulation combinators, and the exact
`insertWhnfC` proof needs the expression-key equality/hash laws. The current
`StateC` plus `Verify.Cached.Erase` import union is 26 modules / 602,650 bytes
with no resource options. This identifies a concrete possible input boundary
for moving those existing declarations with exact correspondence, not an
accepted 26-module proof or a finished checker. It still contains original
compatibility/trust issues, and it does **not** replace the `ssimC` and
`checkPending_run` dependency work required for actual acceptance. An exact
declaration cut has not been implemented or compiled.

## Open obligations before selecting an integration gate

- Recognize the complete installed evaluator body and its dependency records
  at the actual prefix. The current NatRec guard checks real recursor records,
  types and RHSs, but remains prepared source and supplies only those pins.
- Prove whole normalization to the computed literal, including the exported
  raw-numeral bodies, both `Nat.rec` uses, the Boolean branch operations and
  annotation/ζ treatment of the remaining let. The fuel/depth contract must
  be strong enough for the actual `CSOK` clause.
- Prove the concrete query matcher, prefix lookup transport and safe declined
  branch, then modify the real cached pending-check proof as above. Preserve
  verified mode and the complete input declaration validation.
- Establish a source-preserving default-limit dependency closure for the
  actual checker theorem, including generated pin inputs and source guards.
  Neither the earlier 26-module result nor a successful insertion lemma
  establishes this larger closure's budget or acceptance.

These are semantic and dependency obligations. A further numerical run of
the already accepted external n16 checker would not discharge them.
