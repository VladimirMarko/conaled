# Checkpoint 229 current state

## Active completion work — checkpoint 229

Continue the user's instruction to complete `cqueens 16 = 14772512`, publish
standalone durability checkpoints, expose/upload them promptly, and keep working.
The original stock numeral theorem and installed validating-kernel result remain
open. Checkpoint229 secures an actual new41-report pass plus independently
reviewed next source layers; it is not a claim that the final theorem is done.

### New complete actual-cached pilot passed

The five-owner Eventual41 gate passed all41 ordered/distinct reports and exactly
ten ordinary artifacts in26.449959310997656seconds, peak877264KiB. Every selected
source was freshly compiled within the unchanged cumulative30-second,
one-CPU/thread,1-GiB limits. Read
`next-iteration/kernel-cached-eventual-pilot/gate/RESULT-AND-NEXT.md`.

The report is614535bytes, SHA256
`e858925d7e508eee3203b6a3704bb5e0f71113709b3532d5c38d21a371765197`.
The permanently consumed source key is
`492bf86674732afb57fd0844d3da8d9f236ddecf2168ad137fa458f232bcdeaf`.
Do not retry it unchanged. All879 actual readonly source/control snapshots and
ten raw logs have exact checked canonical recovery mappings. Snapshot recovery
is425971bytes SHA256
`42f88147908ce11bc64782fdf0c3c0467334954d9c312d5cce3923ec01e99404`;
root receipt1922bytes SHA256
`fdcd9951941059bb1919a62a4e7593be372e13c31bcfa28b9ab6dae2dc14b83f`.
A dedicated complete saved-result reader remains separate and unexecuted.

The selected sources are reduced Core208582bytes, reduced Cached202799,
unchanged GenericMemo11887, EventualEmpty6934 and EventualAtoms12346. The exact
source total is442548bytes with report counts2/6/16/8/9. The owner source review
has514 author/517 root inputs; the eventual proof review420 author/421 independent
inputs. The controls retain29 historical scopes plus these two distinct scopes.
The compact runner pins and invokes the old interface111 metadata preflight
against its original files; it does not rewrite or retarget that history. Root
independently checked879 bindings,432 original plus23 new hard pins and the six
explicit execution-tail substitution groups before preflight and the sole run.

### What the accepted proof changes

The actual cached implementation prefix remains literal, including all helpers,
Lift APIs, six knot slots, cache keys, guards, state fields, intrinsic proofs and
error paths. The Core selection omits52 pure evaluator definitions; Cached omits
21 unused project declarations while retaining six actual memo equations. All
retained source spans reconstruct exactly. Root's lexical correction is392→340
Core declarations, versus the author's preserved389→337 filter that missed three
retained `_root_` spellings. The52 actual omissions are unchanged.

The new Eventual relation uses real runs from genuine empty CState, uniformly
for every sufficiently large fuel and each scoped depth. Its functionality
compares the same actual call at a common threshold. A finite memo trace first
obtains a strict child's actual empty-state body run, constructs the root's
run witness through the original miss/insertion, and only then uses that witness
to validate hits or insertion. This avoids circular cached-result premises.
Natural literals and sorts are accepted instances; beta/delta/arithmetic/Nat
recursion and the whole query are not covered by this pilot.

The measured Core/Cached cost is24.888318388999323seconds
(13.412948659002723+11.4753697299966). The three small proof leaves took about
1.166seconds combined. This is not evidence of a substantial cost saving from
pure-source omission; complete-budget headroom remains only3.55seconds. Do not
select a larger computation by adding separately measured component budgets.

### Independently reviewed next sources, not yet compiled

| Package | Source/report scope | Author/review inputs |
| --- | --- | ---: |
| kernel-cached-eventual-helpers | Canonical HelperContract37 plus14 actual NF/helper/frame adapters |576/581|
| kernel-cached-literal-contract | Canonical natLiteral and unchanged head_body_nat, one report |59/60|
| kernel-cached-eventual-record-wrapper | New namespace,41 wrapper reports with actual EventualNF |911/912|

The helper contract retains original canonical definitions and proofs; exactly
four old Stable-specific wrappers are omitted and replaced under a new namespace.
All five helper clauses, actual keys/tags and the nine-field rest projection stay.
Flush validity still requires the surviving IEnvTags residue. LiteralContract
owns only canonical natLiteral/head_body_nat; never additionally import the old
full Literal owner. The wrapper removes the unused pure Env argument, uses the
new NF frame/empty-state proofs and accepted cached_nat at fuel+2. Its original
conversion/inference/annotation bodies and actual callback obligations remain.
All old sources, report scopes and review arrays are preserved separately.

The separate32-input numeric dependency assessment is retained as source-only
advice. It is not a deletion certificate or a selected gate. In particular the
Lift family and Expr.resBool_eq must remain for real later checker consumers.

### Next concrete work and remaining endpoint boundary

1. Complete and independently review the finite actual trace for beta, delta,
   arithmetic and Nat recursion, with real helper guards and returned states.
2. Port the numeric count/branches construction so it returns the actual query
   result as FirstOrderNat.evaluate and a concrete sufficient fuel bound. At16,
   the existing intended bound is1516; the new proof must establish it. Produce
   QueryWithRest at the original driver callback fuel99998, including NF,
   HelperCache and restCaches preservation from every supplied valid state.
3. Adapt finite RecordTyping and DriverForward to the new wrapper without
   replacing the original DriverCore/checkPending. Compose the pending certifier
   with that new proof, actual restricted lookup and finite record recognition.
4. Reconcile genuine InstalledEnv/GroupChecked ownership and basis-generation
   dependencies before claiming the original installed-kernel result. The
   original installed type contains the real installation run; quantifying over
   it does not erase its declaration dependencies. The pure BasisGen annotator
   and later model bridges are independent obligations.
5. Keep the stock numeral route explicit: existing universal numerical/source
   equalities can transport a kernel-checked ground backend equality. Historical
   native ACCEPT or erased PLift does not supply that missing ground proof.

New Trace/Typing and last-mile assessment drafts after this cut are not part of
checkpoint229. Continue those active tasks after publication. Do not stop at
checkpoint creation. Preserve the user's priority for reusable parametric
computational-proof infrastructure rather than a one-off expected-value premise.

### Prior evidence and failed paths remain intact

Checkpoint228's interface111 failure remains consumed:72 accepted reports,
11 unaccepted Lookup error-recovery reports, Generic/Compatibility unstarted,
28.168504104seconds. Its new648-input Lookup repair is still source-only. The
older52 explicit-modifier Core did not establish a cost gain. The held475
successor remains unselected; do not run its stale controls. The previous
Wrapper137 pass, Pure177 proof, reflection154 numerical run, pending-certifier67
review, masked-backend134 review and separate21-input context correction all keep
their original scopes. Read checkpoint228-current-state.md and each exact report
for those details; no past acceptance is reassigned to a new source owner.

Checkpoint228's actual publication and clean-restoration receipt is included.
All previous payload paths remain retained. The archive guard is storage-only,
with measured selection justification in checkpoint229-selection-review.json.
Do not package SDK binaries, prepared objects, duplicate attempt source/input/
build trees, the full textbook, or full upstream metatheory builds. Restore the
pinned runtime through session215-runtime-restoration.json when needed.

