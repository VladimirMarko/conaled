# One exact basis test at the fixed cut — draft v1

**Status: design only. No implementation or execution is authorized by this file.**

The goal is to decide, within one fixed budget, whether the35 original guarded B functions have a smaller rational function-space basis. This replaces the earlier fixed-candidate policy with one newly specified deterministic algorithm. The completed sixteen-candidate experiment remains unchanged.

## Inputs and exclusions

Use the same exact guarded trace and the same saved grouping file as the preceding relation test. The grouping file contributes **only `grouping.b_views`, in its original35-column order**. Do not read its sample values, selected rows, ranks or assignments as algorithm inputs. Do not load the six subsequent counterexamples. Start with an empty basis and no witnesses.

The source functions are the Nat-valued meanings of those full `(positive mask, negative mask, bare core)` views. The fixed source side is the same16 variables within the original210-variable numbering. Load all35 views, then validate node0 and the selected ancestor closure exactly as in the retained base rules. Hashes bind bytes and provenance; they do not establish semantic equality.

`PROTOCOL.md` binds the exact inherited arithmetic, guarded interpretation and global zero/refutation rules. New requests are specified incrementally. No RREF, matrix proposal, numerical tolerance, modular oracle, random choice, polynomial expansion or outside-factor premise is used.

## Basis invariant and fixed algorithm

A coefficient vector is a sparse, strictly increasing list of original column indices with nonzero canonical rational coefficients. It denotes the corresponding rational linear combination of the original35 B functions. Retained basis vectors are immutable. In insertion order they satisfy

`G_k(w_l) = 0 for l < k`, and `G_k(w_k) = 1`.

Older G_i need not vanish at later witnesses. This is a triangular invariant, not a delta basis.

For each original column j = 0,…,34:

1. Start the residual vector r at the unit vector e_j.
2. Visit retained basis entries k in insertion order. Evaluate the **current** r at w_k using its individual source B values and an ordered exact rational dot product. Set `a = r(w_k)` and update `r := r − a G_k`. A zero a permits the specified zero-factor update shortcut. Do not update any older G.
3. Multiply the positive denominators of r's nonzero entries in increasing column order, obtaining D > 0. Form the exact integer vector `c = D r`, with exact quotient checks. Its coefficient on j is D; all other columns are smaller than j.
4. Run the retained global signed zero/refutation oracle on c, binding every coefficient to its original view. A complete zero result gives an exact identity for B_j against earlier retained columns. A complete refutation gives a full assignment w and signed nonzero integer `z = c(w)`.
5. In the refutation case, append the basis vector **`G = c/z`**, normalizing each rational coefficient with the inherited sign/gcd rules, and retain w. This gives G(w)=1 even when z is negative. Do not divide r by z, and do not replace z by its absolute value. In the zero case, append no basis entry.

Complete this column before proceeding. A cap or other failure stops the one run; there is no different order, new initial sample, revised normalization, alternate oracle or second attempt under this plan.

The induction is exact: subtracting a G_k zeros the current witness while preserving the zeros at earlier witnesses. Earlier basis vectors use only their original pivot columns and preceding columns, so r's j coefficient stays1. Positive clearing preserves all zeros. The oracle's nonzero z makes the new witness distinct in the required algebraic sense, and division by z establishes the new unit diagonal. No separate uncharged witness search or deduplication is needed.

A completed run supplies both parts of an exact basis certificate: complete global identities for every discarded original column, and a triangular source-bound witness argument for the retained columns. A residual refutation value alone does not provide its constituent B values; those needed by subsequent dot products are evaluated explicitly.

## Determinism and accounting

Sparse vectors are used to avoid obligatory35-slot arithmetic on zeros. Their at-most35-entry bound is derived from the original column universe; it is not a changed resource cap. Every executed scalar operation, gcd step, sparse merge comparison, zero deletion, source evaluation/cache lookup, oracle call and local oracle descendant is charged before work. The exact scalar shortcut priority is fixed by the retained rules plus the new rational-add rule in the protocol.

Source evaluation uses a cache keyed by the exact full view and full210-bit assignment, within this one original source. Every lookup and inspected cache candidate is charged; digest buckets are indexes only. Every hit names the earlier completed evaluation whose key is compared exactly. A miss interprets one guarded source descriptor and recursively evaluates only its selected child. No function evaluator, support traversal or semantic cache prepopulation runs during parsing/preparation.

There is no dot-product, rational-operation, failed-oracle or vector-result memoization. The retained completed-zero-state oracle cache is shared across columns. Its exact-state comparisons, including collisions and unsuccessful comparisons, remain charged. Source validation and source-value caches publish only after completion.

One global counter covers all loading, validation, basis construction, arithmetic, evaluation and oracle work. It stops before request50,001. The producer has the unchanged30-second wall/CPU, one-CPU and1GiB limits; the independent replayer has the separately bounded controls already used by the project. A resource interruption may leave no footer; preserve the complete physical prefix and process evidence.

## Cost and result limits

At most35 column-level oracle decisions occur, but this is not a50,000-request completion guarantee. There can be595 elimination stages; each can require several scalar source values, a rational dot product and a sparse vector update. General coefficients and denominators may grow. A full16-variable Shannon zero proof can exceed the request cap before its per-term work is counted.

The previous11,366-request batch had at most four-term states and two-bit coefficients and found only refutations at candidate roots. It supplies no bound for this algorithm. No claim is made that the new basis will be smaller or that a smaller basis improves the counting certificate enough to matter.

If all35 columns finish, report the exact basis dimension, immutable basis vectors/witnesses, all discarded-column identities, coefficient widths, nonzero entry counts and full request counts. If a prefix stops, report completed identities and committed independent basis entries separately; do not call the prefix a spanning basis or infer the unresolved dimension. No rank claim follows solely from a request count.

A complete dimension35 result closes unconditional rational separated-term reduction at this fixed partition, conditional on the existing complete cut/grouping and A-independence witnesses. It does not exclude other partitions, context-restricted identities or a cheaper representation of35 terms. A smaller basis still requires signed/denominator-aware counting algebra and an exact bridge to the current contraction before it can change the source count proof. This diagnostic itself is neither a Lean theorem nor a queens count.

## Review boundary

First review this plan and its fixed incremental protocol. Later, if separately authorized, implement producer and independent replayer without running semantic code, freeze their sources and controls, and obtain source review before the one bounded run. No Lean implementation is planned before an actual useful exact identity. Retain prior certificates and failures unchanged.
