# Incremental transcript protocol — draft v1

This document replaces only the proposal/basis schedule and adds source evaluation and sparse rational-vector requests. It does not authorize code or execution.

## Exact inherited base

Read the existing protocol at `next-iteration/exact-relation-diagnostic/PROTOCOL.md`, SHA256 `28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147`. Its frozen producer is SHA256 `5c5ba4f6d8a87f9931f6da9fe2d64ff3598aaf1c0c9d7dc3637678efbe817029`; the independent replayer is `029ad7a95d6d37c66b53b9d78fb1e3d6a341852eb7596491dda314700c617cbc`. These are specifications to reimplement/adapt after authorization, not programs to import during design.

Unchanged rules: work/done nesting and completion publication; Ref/IntArg types; `int_scalar`, `rat_mul`, `rat_sub`, `rat_div`, `rat_normalize`, `gcd_step`; view loading and selected-source validation; integer-state normalization and every exact cache comparison; the complete signed guarded zero/refutation oracle. Retain every original scalar shortcut and its exact child order, positive divmod divisors, full-view semantics, false-before-true search, both-child requirement for zero, and completed ProofID reuse. No old matrix/RREF/candidate requests occur.

Every actual request begins before its argument-dependent calculation, comparison, cache inspection or source inspection. Explicit referenced dependencies precede direct nested child completions, preserving order and duplicate occurrences. Only completed outputs can be referenced. A WorkID denotes a whole completed output; a Ref remains `[WorkID,field,index…]`. New vectors contain entries `[column,[numerator,denominator]]`; integer vectors contain `[column,coefficient]`.

## One fixed schedule

Load35 views in original order; validate0 then the35 view cores using the inherited schedule. For each j from0 to34: `column_start`; for each currently committed basis entry k in insertion order `eliminate`; `clear_vector`; `oracle_bridge`; `column_complete`. Refuted columns run `basis_commit` inside `column_complete`. After all35, run `basis_finish` with35 charged coverage checks. No state or basis entry is mutated after publication.

`column_start` returns the sparse unit vector `[[j,[1,1]]]`. It binds the expected j and previous completed column (null for0). The scheduler, independently checked on replay, supplies exactly the current committed basis in insertion order. Original column indices never refer to positions in a changing basis.

`eliminate(r,basis)` is a charged wrapper. It reads the completed basis vector G and witness w, invokes `dot(r,w)`, then invokes `vector_sub(r,a,G)` with that result a even when a=0. Its output binds the resulting vector and the next triangular-prefix index. Replay checks that the current residual follows the preceding elimination and that k is the next retained basis entry; it cannot substitute the original e_j for r.

## New scalar addition and dot products

`rat_add(a,b)` has fixed rule priority: b.num=0 → a; a.num=0 → b; equal denominators → scalar add numerators then normalize against that denominator; otherwise scalar `a.num*b.den`, scalar `b.num*a.den`, scalar add those products, scalar `a.den*b.den`, then normalize. Every wrapper and listed scalar/normalizer/gcd child counts. There is no equal-operands doubling shortcut. Returned rationals are canonical with positive denominator.

`dot(vector,assignment)` starts with a referenced canonical zero supplied by `column_start`. Visit every nonzero vector entry in increasing original-column order. Each `dot_term` starts with the previous accumulator and that entry, then selects and checks its original view-validation record inside the charged body; it records that WorkID in its output and explicit dependencies and requests `evaluate(view,assignment)` even on a cache hit, then `rat_mul(coefficient,evaluation.rational)`, then `rat_add(accumulator,product)`. No zero-valued source shortcut removes those two rational requests. The final sum Ref is the dot value; an empty vector returns canonical zero. Copying completed references is structural bookkeeping, not a free arithmetic computation.

## Exact source evaluation

`evaluate` is a charged wrapper on a full View Ref and full Assignment Ref. It calls `evaluation_lookup` first. The lookup serializes `(view,assignment)` in the fixed canonical JSON format and indexes a SHA256-string bucket. The source is globally fixed by this run's validated input. Each bucket entry is inspected in completion order by a charged `evaluation_candidate`; it compares the exact three view fields and full assignment, not hashes. Stop at the first equal candidate. Hash equality is never a semantic premise. Lookup output binds `hit,prior,digest`; prior is a completed evaluation WorkID or null.

On a hit, return the prior value and name that record. On a miss, bind the input View Ref and first completed bare-core validation. Check the full masks/assignment bounds and guarded-view conditions inside the charged request. A contradictory guard returns0. A satisfied guard with a constant core returns its validated Nat. For an ite core, inspect its tested assignment bit, bind the selected child's first validation record, and recursively evaluate that child's checked flat view under the **same full assignment**. Do not traverse the other child. An outer guard is fully checked before selecting a core branch.

Every evaluation outputs `value:Nat` and `rational:[value,1]`; this denominator-one embedding occurs within the same charged request. No separate source evaluator or projected-assignment cache key is allowed. Cache publication happens only after `evaluate` completes; hits do not publish aliases. Lookup hit/miss counters update only after `evaluation_lookup` completes, even if a later miss computation is interrupted. Validation reads always appear as explicit dependencies. All stored witnesses have no bits outside the fixed Y support; that fact is checked when committed and is already justified by the oracle's bound lifts.

## Sparse subtraction and clearing

`vector_sub(r,a,G)` first checks a under its charged wrapper. If a=0, return the unchanged r reference/value with rule `zero_factor`; do not scan G. Otherwise invoke `vector_merge` repeatedly, starting at both cursors0 and including a final terminal request when both inputs are exhausted. Each merge request inspects at most the two current original-column tags and records which cursor(s) advance.

- A left-only entry is copied unchanged.
- A right-only entry requests `rat_mul(a,Gcoef)`, then `rat_sub(zero,product)`.
- Equal tags request `rat_mul(a,Gcoef)`, then `rat_sub(rcoef,product)`.

The merge request tests the resulting numerator, omitting the entry exactly when it is zero. It records the entry or null and next cursors. Sortedness, uniqueness and coefficient origins follow from these local merges; no uncharged sort, dictionary collection or whole-vector equality is used. The wrapper collects the completed entries in order. There is no vector or dot cache.

`clear_vector` requires the residual's final tag j with coefficient[1,1], a fact derived from the preceding origins. Start D at referenced integer1; multiply by every nonzero entry's positive denominator in column order, including denominators1. For each entry, `clear_entry` requests divmod(D,denominator), checks remainder0, then multiplies its numerator by the quotient. No post-clearing gcd reduction is performed. Output the positive D and exact sparse integer vector; its j coefficient is D. All scales, quotient checks and products are recorded.

`oracle_bridge` creates one charged `origin_term` per integer entry. Inside its charged body it selects and binds its original column, the corresponding loaded/validated view and its integer coefficient, and records the selected view-validation WorkID in its output and dependencies; no basis index may be used as a source column. In that order call the inherited integer `normalize` and then `state`. The resulting complete zero or refutation has exactly the inherited meaning. The sparse integer state may contain at most35 terms by construction. That derived bound replaces the old proposal-specific bound20, with no change to the50,000 cap.

## Column outcomes, normalization and coverage

`column_complete` binds the clear-vector record and completed oracle-bridge/root-state records. Zero returns a discarded-column identity: positive D, the original integer coefficients, and the existing root ProofID. It publishes no basis entry.

Refutation invokes `basis_commit` with that exact cleared vector, assignment and signed nonzero z. Visit entries in increasing original-column order; every `basis_entry` calls inherited `rat_normalize(coefficient,z)`. Its output is the new rational coefficient. The resulting immutable vector is c/z, **not r/z**, and denominator sign normalization is mandatory. Commit outputs the next basis index, original pivot column j, vector, witness, z and exact oracle/clearing origins. The j coefficient must remain nonzero. Its unit and earlier-zero claims are derived from these origins and the sequential elimination invariant, not externally asserted truth values. Publish this basis entry only after its completion.

`column_complete` then reports `independent` with that commit WorkID. Completed global identities and committed basis entries remain available if a later request caps. An unfinished basis normalization cannot supply a new basis direction. `basis_finish` contains one `coverage_entry` for every original column0…34, in order, binding its unique completed outcome. Only complete coverage authorizes the final dimension/spanning result.

## Envelope, counters and failure

Use the inherited four physical record kinds. Version is `exact-guarded-basis-v1`; context has exactly `phase,column,basis_index`, with phase `load`, `validate`, `columns` or `finish`, and null indices outside their active scope. Header input bindings remain trace/sample; policy bindings additionally name this incremental protocol and its exact inherited-base bindings. Limits are unchanged.

The footer retains exact starts/completions, stack, physical count, operation/cache counts, current context, error and maxima. Replace old RREF/candidate fields with `completed_columns`, `basis_commits` and `final_basis`, the last null unless `basis_finish` completed. A complete status is `completed_exact_basis`, exit0; cap is `request_cap`, exit4, with the inherited exact cap message. Other failures retain their exception and unfinished stack. A completion immediately at50,000 is valid only if no additional scheduled request remains; otherwise the next attempted start emits the cap footer before any work.

Cache categories are `validate`, `zero_state`, `source_evaluation`, retaining zero counts. Validation and zero-state accounting follow the base; source-evaluation counts follow completed lookup decisions. Maxima update on completed canonical rationals, completed sparse vector outputs, completed clearing entries, completed integer-state outputs and terminal scalars; stack depth updates at start, cache sizes after completed publication. New vector/source-value widths are descriptive only. Exact field sets and selector details for the future implementation are listed in `schema.json`; any necessary serialization correction must be reviewed and frozen before code execution.


## Implementation serialization clarification

These choices refine fields/origins only; the algorithm and charged request schedule above are unchanged. `dot_term` inputs are exactly `entry,assignment,before`; its output additionally records `view_validation`. `origin_term` inputs are exactly `clear_entry`; its output additionally records `view_validation`. Both select that binding only after their work start. The independent replay derives the same original-column selection.

Explicit dependencies for new requests follow these exact orders (nested child completions follow afterward): column_start: previous column if present; eliminate: residualID,basisCommitID; rat_add: aID,bID; dot: vectorID,assignmentID,zeroID; dot_term: entryID,assignmentID,beforeID,selectedViewValidationID; evaluation_lookup: viewID,assignmentID; evaluation_candidate: viewID,assignmentID,priorEvaluationID; evaluate: viewID,assignmentID,then priorEvaluationID on a hit, otherwise firstBareCoreValidationID and selectedChildValidationID only for an ite branch; vector_sub: leftID,factorID,rightID,zeroID; vector_merge: leftID,rightID,factorID,zeroID; clear_vector: vectorID,oneID; clear_entry: entryID,scaleID; origin_term: clearEntryID,selectedViewValidationID; oracle_bridge: clearedID; column_complete and basis_commit: clearedID,oracleID; basis_entry: clearEntryID,nonzeroValueRefID; basis_finish: all column-outcome IDs then all basis-commit IDs; coverage_entry: its outcomeID. Preserve every duplicate.

`column_start.previous_column`, all basis/column/clearing/oracle arguments named without Ref in the schema, and dot_term/origin_term.view_validation are plain WorkIDs. Dot's accumulator and final `last` advance using `[dotTermID,"value"]`, not the internal sum Ref. Each dot_term also records the exact product and sum child Refs. Clearing entries all use the last denominator-product int_scalar `value` Ref; basis_entry uses `[oracleBridgeID,"nonzero_value"]`. A child evaluation receives `[selectedChildValidationID,"flat"]`. The oracle bridge's initial terms use origin_term's view/coefficient Refs. `column_start.rational_zero` and `integer_one` supply the seed Refs for that column.

A column's residual is first `[columnStartID,"vector"]`, then each successive `[eliminateID,"vector"]`. Context has basis_index=k only during that elimination and its descendants, or during new basis_commit and its descendants. Restore null before clearing, oracle_bridge and column_complete; a column_complete start has null, although its basis_commit child has k. The finish wrapper and every coverage child have phase=finish and both indices null. Interrupted contexts remain unchanged in the footer.

Header policy_bindings has exactly program,protocol,design,schema,inherited_protocol,inherited_producer,inherited_replayer. The last three are files under snapshot `inherited/` with the frozen base hashes above. They are read for byte identity only and never imported. Complete footer lists contain the actual completed output dictionaries, not WorkIDs; final_basis is the basis_finish output or null. FixtureRejected maps to source_invalid during validate/columns and fixture_mismatch otherwise; other exceptions retain their type/message as unexpected_error. This diagnostic does not reinterpret a failure as a refutation.

All completed canonical rational outputs, including evaluation.rational and the column's zero/unit seeds, update rational maxima. Vector maxima concern completed column_start/eliminate/vector_sub/basis_commit outputs; clearing coefficient maxima update after each clear_entry; source-value maxima after each evaluate. Integer-state/terminal and stack/cache update rules remain as specified. Source lookup hit/miss counts update after lookup done; source cache size updates after a completed miss evaluation is published. No maximum selects work.
