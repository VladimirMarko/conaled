"""Independent source-assembly review. No retained program or Lean execution."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
PKG = Path(__file__).resolve().parent

def sha(b): return hashlib.sha256(b).hexdigest()
def check(r):
    b = (ROOT/r['path']).read_bytes()
    assert (len(b), sha(b)) == (r['bytes'], r['sha256']), r['path']
    return b
def obj(r): return json.loads(check(r))
def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def span(b,s):
    a,z=s['start_byte'],s['end_byte_exclusive'];assert 0<=a<=z<=len(b)
    v=b[a:z];assert (len(v),sha(v))==(s['bytes'],s['sha256'])
    assert s['first_line']==b[:a].count(b'\n')+1
    last=b[:z].count(b'\n')+(0 if z and b[z-1:z]==b'\n' else 1)
    # This map anchors an empty interval at its insertion line. It does not
    # claim any source line is consumed; byte size/hash must still be empty.
    if a==z: last=s['first_line']
    assert s['last_line_inclusive']==last,(a,z,s,last)
    return v
def census(b):
    stack=[];blocks=[];decls=[];opens=[];options=[];imports=[];reports=[];visible=[];at={}
    for no,line in enumerate(b.decode().splitlines(),1):
        if line.startswith('namespace '):
            name=line.split()[1];stack.append((name,no,list(visible)));visible=[]
        elif line.startswith('end '):
            name,start,outer=stack.pop();assert line=='end '+name
            blocks.append({'namespace':name,'start_line':start,'end_line':no});visible=outer
        ns='.'.join(x[0] for x in stack)
        at[no]={'namespace':ns,'opened':list(visible)}
        if line.startswith('open '):
            assert stack,line
            raw=line[5:];assert '(' not in raw and ' in ' not in raw
            names=[x if x.startswith(('ConLeche','ADWH.')) else 'ADWH.Experiments.Chapter15.'+x for x in raw.split()]
            opens.append({'line':no,'namespace':ns,'literal':line,'resolved_namespace_prefixes':names})
            visible+=names;at[no]['opened']=list(visible)
        if line.startswith('set_option '):options.append({'line':no,'setting':line[11:]})
        if line.startswith('import '):imports.append({'line':no,'module':line[7:]})
        m=re.match(r'(?:(private) )?(theorem|def|abbrev|structure|inductive) ([^\s(:]+)',line)
        if m:
            private,kind,short=m.groups();name=short[7:] if short.startswith('_root_.') else ns+'.'+short
            decls.append({'line':no,'kind':kind,'name':name,'short_name':short,'private':bool(private),'namespace':ns,'literal_header_line':line})
        if line.startswith('#print axioms '):
            n=line[14:];reports.append(n if n.startswith(('ADWH.','ConLeche.')) else ns+'.'+n)
        assert not re.match(r'(?:@\[|attribute |instance |syntax |notation |macro |initialize |section\b|noncomputable |unsafe |partial |axiom )',line),line
    assert not stack and not visible
    return {'namespace_blocks':blocks,'open_commands':opens,'explicit_options':options,'imports':imports,'explicit_declarations':decls,'ordered_reports':reports},at

inv=json.loads((PKG/'SOURCE-INVENTORY.json').read_text())
assert inv['input_count']==len(inv['inputs'])==1305
assert len({r['path'] for r in inv['inputs']})==1305
for row in inv['inputs']:check(row)
mapping=obj(inv['source_correspondence']);candidate=check(inv['source'])
rebuilt=mapping['header_literal'].encode();assert span(candidate,mapping['header_span'])==rebuilt
assert rebuilt.startswith(b'/-\n') and not rebuilt.startswith(b'/-!')
all_roots=[];all_decls=[];all_censuses=[];contexts={};edits=0;complements=0
for order,origin in enumerate(mapping['origins'],1):
    assert order==origin['order'];original=check(origin['source'])
    transformed=original
    for edit in reversed(origin['edits']):
        a,z=edit['original']['start_byte'],edit['original']['end_byte_exclusive']
        assert span(original,edit['original'])==edit['before'].encode()
        assert edit['before']=='import '+edit['imported_module']+'\n'
        assert edit['after']=='-- [assembly import internalized] '+edit['before']
        transformed=transformed[:a]+edit['after'].encode()+transformed[z:]
    inverse=transformed
    for edit in reversed(origin['edits']):
        a,z=edit['transformed']['start_byte'],edit['transformed']['end_byte_exclusive']
        assert span(transformed,edit['transformed'])==edit['after'].encode()
        inverse=inverse[:a]+edit['before'].encode()+inverse[z:]
    assert inverse==original
    before_pos=after_pos=0
    for i,comp in enumerate(origin['unchanged_complements']):
        assert comp['original']['start_byte']==before_pos and comp['transformed']['start_byte']==after_pos
        assert span(original,comp['original'])==span(transformed,comp['transformed'])
        before_pos=comp['original']['end_byte_exclusive'];after_pos=comp['transformed']['end_byte_exclusive']
        if i<len(origin['edits']):
            edit=origin['edits'][i]
            assert before_pos==edit['original']['start_byte'] and after_pos==edit['transformed']['start_byte']
            before_pos=edit['original']['end_byte_exclusive'];after_pos=edit['transformed']['end_byte_exclusive']
    assert before_pos==len(original) and after_pos==len(transformed)
    banner=origin['banner'];assert len(rebuilt)==banner['physical_start_byte'];rebuilt+=banner['literal'].encode();assert len(rebuilt)==banner['physical_end_byte_exclusive']
    body=origin['body'];start=len(rebuilt);assert start==body['physical_start_byte']
    assert (len(transformed),sha(transformed))==(body['bytes'],body['sha256'])
    rebuilt+=transformed;assert len(rebuilt)==body['physical_end_byte_exclusive']
    for item in origin['edits']+origin['unchanged_complements']:
        a,z=item['transformed']['start_byte'],item['transformed']['end_byte_exclusive']
        assert (item['physical_start_byte'],item['physical_end_byte_exclusive'])==(start+a,start+z)
        assert candidate[start+a:start+z]==transformed[a:z]
    footer=origin['footer'];assert len(rebuilt)==footer['physical_start_byte'];rebuilt+=footer['literal'].encode();assert len(rebuilt)==footer['physical_end_byte_exclusive']
    cs,ct=census(original);assert cs['ordered_reports']==origin['ordered_report_roots'] and len(cs['ordered_reports'])==origin['report_count']
    all_censuses.append(cs);all_decls+=cs['explicit_declarations'];all_roots+=cs['ordered_reports'];contexts[origin['original_module']]=(original,ct)
    edits+=len(origin['edits']);complements+=len(origin['unchanged_complements'])
    assert len(origin['edits'])==origin['edit_count'] and len(origin['unchanged_complements'])==origin['unchanged_complement_count_including_empty_spans']
assert rebuilt==candidate and edits==8 and complements==13 and len(mapping['origins'])==5
assert mapping['origins'][0]['edits']==[] and mapping['origins'][0]['body']['bytes']==119150
assert re.findall(rb'^import (\S+)',candidate,re.M)==[b'KernelCachedForward']
cs,_=census(candidate)
assert cs['ordered_reports']==all_roots and len(all_roots)==len(set(all_roots))==177
assert [r['literal_header_line'] for r in cs['explicit_declarations']]==[r['literal_header_line'] for r in all_decls]

scope=obj(inv['private_and_scope_audit'])
for expected,actual in zip(scope['origin_censuses'],all_censuses,strict=True):
    for k,v in actual.items():assert expected[k]==v,(expected['module'],k)
public=[d for d in all_decls if not d['private']];private=[d for d in all_decls if d['private']]
assert len(public)==len({r['name'] for r in public})==231
assert len(private)==6 and sum(d['kind']=='theorem' for d in public)==177
assert sum(len(x['namespace_blocks']) for x in all_censuses)==18
assert sum(len(x['explicit_options']) for x in all_censuses)==36
assert {x['setting'] for c in all_censuses for x in c['explicit_options']}=={'autoImplicit false','warningAsError true','Elab.async false'}
assert all(d['kind']=='theorem' for d in private)
occ=[]
for origin in mapping['origins']:
    original,ct=contexts[origin['original_module']]
    for pd in scope['private_headers']:
        if pd['origin_module']==origin['original_module']:continue
        for no,line in enumerate(original.decode().splitlines(),1):
            if re.search(r'(?<![A-Za-z0-9_])'+re.escape(pd['short_name'])+r'(?![A-Za-z0-9_])',line):
                env=ct[no];assert pd['namespace']!=env['namespace'] and pd['namespace'] not in env['opened']
                occ.append((pd['name'],origin['original_module'],no,line,env['namespace'],env['opened']))
recorded=[(r['private_declaration'],r['occurrence_module'],r['line'],r['literal_line'],r['namespace'],r['opened']) for r in scope['cross_origin_private_spelling_occurrences']]
assert occ==recorded and len(occ)==6
assert not re.search(rb'_private\.|\._match_|\._proof_',candidate)

historical=obj(inv['historical_review_scopes']);counts=[]
for s in historical['scopes']:
    pair=[]
    for desc in s['unchanged_input_arrays']:
        rows=obj(desc['source'])[desc['json_field']];raw=canonical(rows)
        assert len(rows)==desc['count'] and (len(raw),sha(raw))==(desc['canonical_json_bytes'],desc['canonical_json_sha256'])
        pair.append(len(rows))
    counts.append(pair)
assert counts==[[916,917],[1051,1052],[1264,1267]]
sdk=obj(inv['SDK_name_resolution_context'])
for pair in sdk['whole_file_pairs']:assert check(pair['original'])==check(pair['retained_copy'])
for interval in sdk['literal_intervals']:assert span(check(interval['source']),interval)==interval['text'].encode()

census_map=obj(inv['source_census']);seen=set();ordered=[];size=0
for owner in census_map['physical_modules']:
    b=check(owner['source']);size+=len(b);imports=[s.decode() for s in re.findall(rb'^import (\S+)',b,re.M)]
    assert imports==owner['imports']
    assert all(x in seen or x.startswith(('Init.','Std.','Lean.')) for x in imports)
    seen.add(owner['module']);assert owner['report_count']==len(owner['ordered_reports'])==len(re.findall(rb'^#print axioms ',b,re.M))
    assert owner['ordinary_outputs']==[owner['module']+'.olean',owner['module']+'.ilean'];ordered+=owner['ordered_reports']
assert size==618132==census_map['source_bytes'] and len(seen)==3
assert ordered==inv['ordered_reports']==census_map['ordered_reports'] and len(ordered)==len(set(ordered))==185
assert census_map['ordinary_output_count']==6
result={'status':'passed_independent_static_assembly_review','author_inputs_verified':1305,'exact_input_files':5,'whole_foundation_bytes_literal':119150,'import_edits':8,'unchanged_complements_including_empty':13,'full_forward_inverse_reconstructions':5,'public_declarations':231,'public_theorem_headers':177,'private_theorem_headers':6,'namespace_blocks':18,'strict_option_occurrences':36,'cross_origin_private_spelling_occurrences':6,'historical_scope_pairs':counts,'SDK_whole_file_pairs':2,'SDK_literal_intervals':3,'whole_selected_sources':3,'whole_source_bytes':618132,'ordered_distinct_reports':185,'ordinary_outputs':6,'compiler_gate_or_mathematical_execution':False}
(PKG/'INDEPENDENT-STATIC-CHECK.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
