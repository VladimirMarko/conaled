# Consolidated non-atomic eventual interpreter

## Selected source work

This is a distinct source-only physical assembly authorized by `/root`. It selects the unchanged reduced `KernelCompactCore` and `KernelCachedForward` owners and one new `KernelCachedEventualInterpreter` proof owner. The complete selection has **185 ordered public reports in three physical owners**, with report counts **2 / 6 / 177** and six ordinary outputs.

The proof owner contains these five exact physical inputs, in order:

| Input | Reports | Transformation |
|---|---:|---|
| Accepted `KernelCachedEventualFoundation` | 126 | Entire file literal, including its sole external Cached import |
| Frozen `KernelCachedOperationalContracts` | 32 | Two header imports internalized |
| Frozen `KernelCachedEventualSteps` | 6 | Three header imports internalized |
| Frozen `KernelCachedEventualTrace` | 11 | One header import internalized |
| Frozen `KernelCachedEventualQueryBridge` | 2 | Two header imports internalized |

Internalization adds the exact comment prefix `-- [assembly import internalized] ` before each of those eight original complete import lines. Their declarations are already present in earlier segments. The other additions are an ordinary initial comment and ten ordinary boundary comments. All mathematical statements, definitions, proof bodies, strict options, namespace boundaries, report commands, and all other original bytes remain literal. There is no new lemma, weakened premise, fuel change, runtime branch change, or altered cache invariant.

The new initial comment uses `/-`, not a module-doc command before imports. The proof owner has exactly one actual import, `KernelCachedForward`, inherited from the complete Foundation segment. Core and Cached remain separate at their exact previously selected paths and hashes. No retained compiled object is an input.

## Why this intermediate closure matters

The accepted Foundation134 supplied exact-result memo functionality, genuine-empty eventual semantics, atomic finite traces, actual helper/state frames, the literal contract, and the conditional record wrapper. The added Trace49 source extends finite traces to the actual non-atomic full/head loops, delta, arithmetic, application spines, beta peeling and Nat recursion. Its root memo witnesses are still built from strictly smaller body traces before forwarding from arbitrary valid states. Actual helper results, stored metadata licenses, scope, local budgets and returned-state ordering remain explicit.

QueryBridge2 interprets a supplied finite trace under its explicit knot bound and preserves NF, HelperCache and the exact nine-field rest projection. Its record-fuel specialization uses the actual 99,998 budget and depth zero. This assembly does **not** construct a trace for the complete Nat-only counting program. It validates the reusable non-atomic interpreter on which the separately reviewed bounded FN construction depends.

The nineteen-owner FN construction, RecordTyping, DriverCore/DriverForward, record guards, installed guards, pending certifier, numerical backend and native Installed are outside this selected compilation graph. Earlier historical files can still occur as review context within frozen inventories; that does not select them as imports.

## Scope and resolution audit

`SOURCE-CORRESPONDENCE.json` maps all eight import edits and thirteen unchanged complements, including empty header spans, with complete forward and inverse reconstruction. The complete 119,150-byte accepted Foundation file is one literal span. The inherited Foundation assembly and all its earlier mappings remain separate, unchanged inputs.

`PRIVATE-AND-SCOPE-AUDIT.json` records every explicit named declaration header, namespace block, open command, strict option, report, and private-name spelling occurrence for each input. All namespaces and sections close inside their original files. There are no new root opens or explicit attribute, instance, syntax, notation, macro, or initializer commands. All repeated options retain the same three values: `autoImplicit false`, `warningAsError true`, and `Elab.async false`.

The six private theorem spellings are the five inherited Foundation helpers and Contracts' `unfold_const_none`. The wrapper-private `whnf_app_skip` shares its short spelling with the distinct public `KernelCachedBetaDeltaForward.whnf_app_skip`. Cross-input occurrences are recorded with their current namespaces and opens. The wrapper namespace is not open at those BetaDelta/Steps/Trace occurrences; the QueryBridge opens the wrapper but does not refer to that spelling. This source-level assessment is not an assertion that elaboration has run.

The original logical import graph also records environmental widening. Contracts now follows the whole Foundation rather than only its HelperContract/Literal dependencies. Steps and Trace also see the earlier Wrapper declarations. QueryBridge already depends on the trace and wrapper union. These additional declarations remain under their existing namespaces; no new global registration command is introduced. The exact prior-private-name environment and physical module identity still change. Compiler-generated private/auxiliary names can therefore change, and textual preservation alone is not a proof of identical elaborated terms or resolution. Pinned SDK PrivateName/ResolveName context is retained to make that boundary explicit. Complete fresh elaboration remains mandatory.

All old alternative physical owners must be excluded from the same compilation selection. This includes the seven individual Foundation origins, the Foundation owner itself, the three separate Trace owners, QueryBridge, and old full canonical operational owners whose selected declarations are supplied here. Their historical source/review files remain available; they are not additional imports.

## Preserved review and actual-run evidence

Three immediate historical scopes are retained at their original identities and input-array digests:

| Scope | Author inputs | Independent review inputs |
|---|---:|---:|
| Foundation assembly | 916 | 917 |
| Trace49 | 1,051 | 1,052 |
| QueryBridge2 | 1,264 | 1,267 |

The six original Foundation ingredient scopes and the Trace/Bridge earlier scopes remain separately bound inside those unchanged files. The new inventory does not rebase their source selection or historical status text. Trace49 and QueryBridge2 have passed source review but have not been accepted in this new physical context.

`PRIOR-ACCEPTANCE-CONTEXT.json` separately binds root's actual Foundation134 result, consumed marker, current-run recovery, receipt and control context. Root reported 134 accepted roots and six outputs in 25.97892414099988 seconds with peak RSS 877,200 KiB. The assembly author hashes those immutable files and reads root's result note; it does not execute a saved-result reader or reuse compiled outputs. The old source fingerprint remains consumed. No prior acceptance is transferred to the new 185-report owner.

The current-file origin convention extends Foundation's 24-origin census by four new project proof files, giving 28. The proof owner has five direct physical inputs and eleven granular project proof-file origins, since Foundation already combines seven. The seven historical operational slices inside Contracts are a separate provenance count; they are not silently added as seven current imported owners.

## Review and execution boundary

This package contains source and provenance only. No controls are authored until root independently reviews the frozen assembly. No Lean/compiler invocation, mathematical or native evaluation, exporter, gate, preflight, profiler, retained generator, or saved-result reader is run by the author.

The next complete gate, if independently selected, must rebuild all three owners under the unchanged cumulative 30-second, one-CPU/thread, 1-GiB/default-option policy and three-axiom audit. Physical consolidation retains all elaboration/kernel work, may reduce loading/serialization overhead, and can increase the proof process's live memory. The Foundation134 run leaves no proven bound for the added 51 reports, especially the larger mutual trace interpreter. This source assembly makes no timing, memory-fit, full-query, actual-pin, installation, EnvWF, GroupChecked, or stock-numeral claim.

This package is after the fixed checkpoint230 cut. All consumed sources, markers, author inventories and earlier independent reviews remain unchanged.
