#!/usr/bin/env python3
"""Author the newly authorized literal source assembly and static metadata only.

This script does not import/run any retained script, Lean, mathematical program,
gate, preflight, exporter, profiler, or saved-result reader. Historical run files
are hashed as immutable context; their results are not interpreted by this script.
"""
from pathlib import Path
import hashlib
import json
import re

BASE = Path(__file__).resolve().parents[2]
PKG = Path(__file__).resolve().parent
REL = PKG.relative_to(BASE).as_posix()
OUT = PKG / 'source' / 'KernelCachedEventualInterpreter.lean'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    if path.is_absolute():
        path = Path(path.relative_to(BASE))
    data = (BASE / path).read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': digest(data)}


def load(path):
    return json.loads((BASE / path).read_text())


def checked(row):
    data = (BASE / row['path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
    return data


def write_json(name, value):
    path = PKG / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return identity(path)


def span(data, start, end):
    piece = data[start:end]
    line = data[:start].count(b'\n') + 1
    last = data[:end].count(b'\n') + (0 if piece.endswith(b'\n') else 1)
    return {'start_byte': start, 'end_byte_exclusive': end,
            'first_line': line, 'last_line_inclusive': max(line, last),
            'bytes': len(piece), 'sha256': digest(piece)}


def strip_comments_strings(text):
    """Preserve positions/newlines; this is a bounded textual census, not Lean."""
    out = []
    i = depth = 0
    string = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                out.extend('  '); depth += 1; i += 2
            elif text.startswith('-/', i):
                out.extend('  '); depth -= 1; i += 2
            else:
                out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif string:
            if text[i] == '\\' and i + 1 < len(text):
                out.extend('  '); i += 2
            elif text[i] == '"':
                out.append(' '); string = False; i += 1
            else:
                out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif text.startswith('/-', i):
            out.extend('  '); depth = 1; i += 2
        elif text.startswith('--', i):
            end = text.find('\n', i)
            end = len(text) if end < 0 else end
            out.extend(' ' * (end - i)); i = end
        elif text[i] == '"':
            out.append(' '); string = True; i += 1
        else:
            out.append(text[i]); i += 1
    assert depth == 0 and not string
    return ''.join(out)


def qualify(namespace, name):
    if name.startswith('_root_.'):
        return name[len('_root_.'):]
    return (namespace + '.' if namespace else '') + name


def census(row):
    text = checked(row).decode()
    code = strip_comments_strings(text)
    ns = ''
    opened = []
    stack = []
    namespaces = []
    declarations = []
    imports = []
    options = []
    opens = []
    commands = []
    reports = []
    line_context = []
    for number, line in enumerate(code.splitlines(), 1):
        literal = text.splitlines()[number - 1]
        line_context.append({'namespace': ns, 'opened': list(opened)})
        m = re.match(r'^\s*namespace\s+(\S+)\s*$', line)
        if m:
            stack.append((ns, list(opened), number, 'namespace'))
            ns = qualify(ns, m[1]); continue
        if re.match(r'^\s*(?:(?:noncomputable\s+)?section(?:\s+\S+)?|mutual)\s*$', line):
            stack.append((ns, list(opened), number, 'section_or_mutual')); continue
        if re.match(r'^\s*end(?:\s+\S+)?\s*$', line):
            assert stack, (row['path'], number, line)
            old_ns, old_opened, start, kind = stack.pop()
            if kind == 'namespace':
                namespaces.append({'namespace': ns, 'start_line': start, 'end_line': number})
            ns, opened = old_ns, old_opened
            continue
        m = re.match(r'^\s*open\s+(.+?)\s*$', line)
        if m:
            tokens = m[1].split()
            assert tokens and '(' not in m[1] and ')' not in m[1], (row['path'], number)
            for name in tokens:
                full = 'ADWH.Experiments.Chapter15.' + name if name.startswith('Kernel') else name
                opened.append(full)
            opens.append({'line': number, 'namespace': ns, 'literal': literal,
                          'resolved_namespace_prefixes': list(opened[-len(tokens):])})
            continue
        m = re.match(r'^import\s+(\S+)\s*$', line)
        if m:
            imports.append({'line': number, 'module': m[1]}); continue
        m = re.match(r'^set_option\s+(.+?)\s*$', line)
        if m:
            options.append({'line': number, 'setting': m[1]}); continue
        m = re.match(r'^(?P<mods>(?:(?:private|protected|noncomputable|unsafe)\s+)*)'
                     r'(?P<kind>theorem|def|abbrev|structure|inductive|opaque|axiom|class)\s+'
                     r'(?P<name>[^\s(:{]+)', line)
        if m:
            declarations.append({'line': number, 'kind': m['kind'],
                                 'name': qualify(ns, m['name']),
                                 'short_name': m['name'].split('.')[-1],
                                 'private': 'private' in m['mods'].split(),
                                 'namespace': ns, 'literal_header_line': literal})
        m = re.match(r'^\s*#print\s+axioms\s+(\S+)\s*$', line)
        if m:
            name = m[1]
            if name.startswith('_root_.'):
                name = name[len('_root_.'):]
            elif not name.startswith(('ConLeche.', 'ADWH.')):
                name = qualify(ns, name)
            reports.append(name)
        if re.match(r'^\s*(?:attribute|local|scoped|instance|notation|syntax|macro|elab|initialize|builtin_initialize)\b|^\s*@\[', line):
            commands.append({'line': number, 'namespace': ns, 'literal': literal})
    assert not stack and not ns and not opened, row['path']
    return {'source': row, 'imports': imports, 'namespace_blocks': namespaces,
            'open_commands': opens, 'explicit_options': options,
            'explicit_declarations': declarations, 'ordered_reports': reports,
            'explicit_attribute_instance_syntax_or_initializer_commands': commands,
            '_code': code, '_line_context': line_context}


foundation_path = 'next-iteration/kernel-cached-eventual-foundation'
trace_path = 'next-iteration/kernel-cached-eventual-trace'
bridge_path = 'next-iteration/kernel-cached-eventual-query-bridge'
foundation = load(foundation_path + '/SOURCE-INVENTORY.json')
foundation_map = load(foundation_path + '/SOURCE-CORRESPONDENCE.json')
foundation_census = load(foundation_path + '/SOURCE-CENSUS.json')
trace = load(trace_path + '/SOURCE-INVENTORY.json')
bridge = load(bridge_path + '/SOURCE-INVENTORY.json')
sources = [foundation['source']] + trace['new_sources'] + [bridge['source']]
module_names = ['KernelCachedEventualFoundation', 'KernelCachedOperationalContracts',
                'KernelCachedEventualSteps', 'KernelCachedEventualTrace',
                'KernelCachedEventualQueryBridge']
expected_reports = [126, 32, 6, 11, 2]
assert len(sources) == len(module_names) == 5

header = ("/-\nExact physical assembly of the frozen eventual foundation, non-atomic trace\n"
          "interpreter, and bounded query interface. Only the recorded imports are\n"
          "internalized; all declaration, proof, option, namespace, and report bytes\n"
          "remain literal. Core and Cached keep their separate unchanged owners.\n"
          "This new 185-report selection has not been compiled or timed.\n-/\n\n").encode()
assembled = bytearray(header)
maps = []
all_censuses = []
import_prefix = b'-- [assembly import internalized] '
for index, (source, module, expected_count) in enumerate(zip(sources, module_names, expected_reports), 1):
    original = checked(source)
    assert original.endswith(b'\n')
    c = census(source)
    assert len(c['ordered_reports']) == expected_count
    all_censuses.append(c)
    transformed = bytearray()
    edits = []
    complements = []
    cursor = 0
    for match in re.finditer(rb'^import [^\n]+\n', original, re.M):
        if index == 1:
            assert match.group() == b'import KernelCachedForward\n'
            continue
        before = match.group()
        after = import_prefix + before
        chunk_start = len(transformed)
        transformed.extend(original[cursor:match.start()])
        complements.append({'original': span(original, cursor, match.start()),
                            '_transformed_start': chunk_start,
                            '_transformed_end': len(transformed)})
        edit_start = len(transformed)
        transformed.extend(after)
        edits.append({'original': span(original, match.start(), match.end()),
                      '_transformed_start': edit_start, '_transformed_end': len(transformed),
                      'before': before.decode(), 'after': after.decode(),
                      'kind': 'internalize_import_as_literal_line_comment',
                      'imported_module': before.decode().strip().split()[1]})
        cursor = match.end()
    tail_start = len(transformed)
    transformed.extend(original[cursor:])
    complements.append({'original': span(original, cursor, len(original)),
                        '_transformed_start': tail_start, '_transformed_end': len(transformed)})
    transformed = bytes(transformed)
    banner = f'/- BEGIN EXACT PHYSICAL INPUT {index}: {module} -/\n'.encode()
    footer = f'/- END EXACT PHYSICAL INPUT {index}: {module} -/\n\n'.encode()
    banner_start = len(assembled); assembled.extend(banner)
    body_start = len(assembled); assembled.extend(transformed)
    body_end = len(assembled); assembled.extend(footer)
    footer_end = len(assembled)
    for entry in edits + complements:
        start = entry.pop('_transformed_start'); end = entry.pop('_transformed_end')
        entry['transformed'] = span(transformed, start, end)
        entry['physical_start_byte'] = body_start + start
        entry['physical_end_byte_exclusive'] = body_start + end
    # Complete source-only reconstruction in both directions.
    pieces = sorted(edits + complements, key=lambda r: (r['original']['start_byte'], r['original']['end_byte_exclusive']))
    rebuilt_original = bytearray(); rebuilt_transformed = bytearray()
    o = t = 0
    for piece in pieces:
        os = piece['original']; ts = piece['transformed']
        assert os['start_byte'] == o and ts['start_byte'] == t
        ob = original[o:os['end_byte_exclusive']]
        tb = transformed[t:ts['end_byte_exclusive']]
        assert digest(ob) == os['sha256'] and digest(tb) == ts['sha256']
        if 'before' in piece:
            assert ob == piece['before'].encode() and tb == piece['after'].encode()
        else:
            assert ob == tb
        rebuilt_original.extend(ob); rebuilt_transformed.extend(tb)
        o, t = os['end_byte_exclusive'], ts['end_byte_exclusive']
    assert bytes(rebuilt_original) == original and bytes(rebuilt_transformed) == transformed
    maps.append({'order': index, 'original_module': module, 'source': source,
                 'banner': {'literal': banner.decode(), 'physical_start_byte': banner_start,
                            'physical_end_byte_exclusive': body_start},
                 'body': {'physical_start_byte': body_start, 'physical_end_byte_exclusive': body_end,
                          'bytes': len(transformed), 'sha256': digest(transformed)},
                 'footer': {'literal': footer.decode(), 'physical_start_byte': body_end,
                            'physical_end_byte_exclusive': footer_end},
                 'edits': edits, 'edit_count': len(edits), 'unchanged_complements': complements,
                 'unchanged_complement_count_including_empty_spans': len(complements),
                 'entire_original_file_literal': not edits,
                 'all_non_import_bytes_literal': True,
                 'complete_forward_and_inverse_reconstruction_verified': True,
                 'ordered_report_roots': c['ordered_reports'], 'report_count': expected_count})
assert sum(x['edit_count'] for x in maps) == 8
assert sum(x['unchanged_complement_count_including_empty_spans'] for x in maps) == 13
OUT.parent.mkdir(parents=True, exist_ok=True)
assert not OUT.exists()
OUT.write_bytes(assembled)
candidate = identity(OUT)
candidate_census = census(candidate)
expected_roots = sum([x['ordered_reports'] for x in all_censuses], [])
assert len(expected_roots) == len(set(expected_roots)) == 177
assert candidate_census['ordered_reports'] == expected_roots
assert candidate_census['imports'] == [{'line': candidate_census['imports'][0]['line'], 'module': 'KernelCachedForward'}]
original_declarations = sum([x['explicit_declarations'] for x in all_censuses], [])
assert [(x['kind'], x['name'], x['private'], x['literal_header_line']) for x in candidate_census['explicit_declarations']] == [(x['kind'], x['name'], x['private'], x['literal_header_line']) for x in original_declarations]
public_names = [x['name'] for x in original_declarations if not x['private']]
assert len(public_names) == len(set(public_names))
assert not candidate_census['explicit_attribute_instance_syntax_or_initializer_commands']
assert {x['setting'] for x in candidate_census['explicit_options']} == {'autoImplicit false', 'warningAsError true', 'Elab.async false'}
source_code = re.sub(r'^\s*#print\s+axioms.*$', '', candidate_census['_code'], flags=re.M)
assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide|implemented_by|run_tac)\b', source_code)
assert not re.search(r'\b_private\.|\._aux\b|\.match_\d+', source_code)

correspondence = write_json('SOURCE-CORRESPONDENCE.json', {
    'format': 'adwh-eventual-interpreter-five-input-physical-assembly-v1',
    'status': 'source_only_frozen_candidate_no_execution',
    'candidate': candidate, 'header_literal': header.decode(), 'header_span': span(bytes(assembled), 0, len(header)),
    'origins': maps, 'direct_physical_input_count': 5,
    'internalized_import_count': 8, 'unchanged_complement_count_including_empty_spans': 13,
    'new_boundary_comment_count': 10, 'new_initial_comment_count': 1,
    'foundation_complete_file_literal': True,
    'mathematical_header_definition_body_proof_option_namespace_or_report_edits': 0,
    'complete_forward_and_inverse_reconstruction_verified': True,
    'Core_and_Cached_source_changed': False,
    'new_mathematical_declarations_or_lemmas': 0})

# Original logical import graph, solely for explicit environmental widening.
logical_sources = {x['origin_module']: x['source'] for x in foundation_map['origins']}
logical_sources.update(dict(zip(module_names[1:], sources[1:])))
logical_imports = {name: [x['module'] for x in census(row)['imports']]
                   for name, row in logical_sources.items()}


def dependency_modules(module):
    out = set()
    for imported in logical_imports.get(module, []):
        if imported in logical_sources:
            out.add(imported)
            out.update(dependency_modules(imported))
    return out


earlier = set(logical_sources) - set(module_names[1:])
widening = [{'module': module_names[0], 'source': sources[0],
             'baseline': 'same complete accepted foundation segment; its seven-origin scope is separately preserved',
             'newly_earlier_public_origin_modules': [], 'private_names_change_physical_module': True}]
for module, source in zip(module_names[1:], sources[1:]):
    original_dependencies = dependency_modules(module)
    assert original_dependencies <= earlier
    widening.append({'module': module, 'source': source,
                     'original_transitive_proof_modules': sorted(original_dependencies),
                     'earlier_current_proof_modules': sorted(earlier),
                     'newly_earlier_public_origin_modules': sorted(earlier - original_dependencies),
                     'private_names_change_physical_module': True})
    earlier.add(module)

private_headers = []
private_cross_occurrences = []
for index, c in enumerate(all_censuses):
    for declaration in c['explicit_declarations']:
        if not declaration['private']:
            continue
        private_headers.append({'origin_module': module_names[index], 'source': sources[index],
                                **declaration})
        name = declaration['short_name']
        pattern = r'(?<![A-Za-z0-9_])' + re.escape(name) + r'(?![A-Za-z0-9_])'
        for later_index, later in enumerate(all_censuses):
            if later_index == index:
                continue
            for match in re.finditer(pattern, later['_code']):
                line = later['_code'][:match.start()].count('\n') + 1
                context = later['_line_context'][line - 1]
                active = declaration['namespace'] in context['opened'] or context['namespace'] == declaration['namespace']
                private_cross_occurrences.append({'private_declaration': declaration['name'],
                    'private_origin_module': module_names[index], 'occurrence_module': module_names[later_index],
                    'line': line, 'namespace': context['namespace'], 'opened': context['opened'],
                    'literal_line': checked(sources[later_index]).decode().splitlines()[line - 1],
                    'private_namespace_is_current_or_open': active,
                    'assessment': 'distinct BetaDelta public declaration/reference; Wrapper private namespace is not current or opened' if name == 'whnf_app_skip' and not active else 'requires manual resolution review'})
assert len(private_headers) == 6
assert all(not x['private_namespace_is_current_or_open'] for x in private_cross_occurrences)
scope_censuses = []
for module, c in zip(module_names, all_censuses):
    scope_censuses.append({'module': module, **{k: v for k, v in c.items() if not k.startswith('_')}})
scope = write_json('PRIVATE-AND-SCOPE-AUDIT.json', {
    'format': 'adwh-eventual-interpreter-static-environment-census-v1', 'candidate': candidate,
    'origin_censuses': scope_censuses, 'environment_widening': widening,
    'namespace_block_count': len(candidate_census['namespace_blocks']),
    'all_namespace_and_section_scopes_closed_within_original_files': True,
    'root_level_open_commands': [], 'private_headers': private_headers,
    'private_theorem_header_count': len(private_headers),
    'cross_origin_private_spelling_occurrences': private_cross_occurrences,
    'private_compiled_names_may_change': True,
    'explicit_generated_private_auxiliary_or_matcher_name_references': [],
    'explicit_attribute_instance_syntax_or_initializer_commands': [],
    'global_simp_or_instance_registration_changes_from_new_source_commands': [],
    'strict_option_occurrence_count': len(candidate_census['explicit_options']),
    'strict_options': sorted({x['setting'] for x in candidate_census['explicit_options']}),
    'public_named_declaration_count': len(public_names),
    'public_theorem_header_count': sum(x['kind'] == 'theorem' and not x['private'] for x in original_declarations),
    'all_theorem_header_count': sum(x['kind'] == 'theorem' for x in original_declarations),
    'ordered_report_count': 177, 'duplicate_public_textual_declaration_names': [],
    'exhaustive_elaborated_generated_declaration_census_or_identical_name_resolution_claimed': False,
    'fresh_elaboration_still_required': True})

# Retain exact SDK source context for the static private-name boundary.
sdk_rows = []
sdk_intervals = []
for filename, intervals in [('PrivateName.lean', [(16, 30)]),
                            ('ResolveName.lean', [(118, 174), (189, 216)])]:
    source = Path('../toolchains/lean-4.35.0-linux/src/lean/Lean') / filename
    original = identity(source)
    destination = PKG / 'sdk' / 'Lean' / filename
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(checked(original))
    retained = identity(destination)
    sdk_rows.append({'original': original, 'retained_copy': retained})
    data = checked(retained)
    lines = data.splitlines(keepends=True)
    for start, end in intervals:
        start_byte = len(b''.join(lines[:start - 1])); end_byte = len(b''.join(lines[:end]))
        sdk_intervals.append({'source': retained, 'start_line': start, 'end_line_inclusive': end,
                              **span(data, start_byte, end_byte),
                              'text': data[start_byte:end_byte].decode()})
sdk = write_json('SDK-NAME-RESOLUTION-CONTEXT.json', {
    'format': 'adwh-eventual-interpreter-private-name-sdk-context-v1',
    'whole_file_pairs': sdk_rows, 'literal_intervals': sdk_intervals,
    'SDK_files_are_context_only_not_selected_compilation_inputs': True})

runtime_sources = foundation['selected_physical_sources'][:2]
runtime_rows = foundation_census['physical_modules'][:2]
runtime_reports = []
for row in runtime_rows:
    roots = row.get('required_axiom_reports', row.get('ordered_report_roots', row.get('ordered_reports')))
    assert roots is not None, row.keys()
    runtime_reports.extend(roots)
physical_sources = runtime_sources + [candidate]
total_reports = runtime_reports + expected_roots
assert len(runtime_reports) == 8 and len(total_reports) == len(set(total_reports)) == 185
logical_origins = foundation_census['logical_origins'] + module_names[1:]
assert len(logical_origins) == len(set(logical_origins)) == 28
source_census = write_json('SOURCE-CENSUS.json', {
    'format': 'adwh-eventual-interpreter-three-owner-source-census-v1',
    'physical_modules': [
        {'module': 'KernelCompactCore', 'source': runtime_sources[0],
         'imports': ['Std.Data.HashMap', 'Init.Util'], 'ordered_reports': runtime_reports[:2],
         'report_count': 2, 'ordinary_outputs': ['KernelCompactCore.olean', 'KernelCompactCore.ilean']},
        {'module': 'KernelCachedForward', 'source': runtime_sources[1],
         'imports': ['KernelCompactCore'], 'ordered_reports': runtime_reports[2:],
         'report_count': 6, 'ordinary_outputs': ['KernelCachedForward.olean', 'KernelCachedForward.ilean']},
        {'module': 'KernelCachedEventualInterpreter', 'source': candidate,
         'imports': ['KernelCachedForward'], 'ordered_reports': expected_roots,
         'report_count': 177, 'ordinary_outputs': ['KernelCachedEventualInterpreter.olean', 'KernelCachedEventualInterpreter.ilean']}],
    'selected_physical_sources': physical_sources, 'physical_owner_count': 3,
    'ordered_report_counts': [2, 6, 177], 'ordered_report_count': 185,
    'ordered_reports': total_reports, 'distinct_report_count': 185,
    'source_bytes': sum(x['bytes'] for x in physical_sources), 'ordinary_output_count': 6,
    'direct_proof_input_count': 5, 'granular_project_proof_file_origin_count': 11,
    'current_file_convention_logical_origins': logical_origins,
    'current_file_convention_logical_origin_count': 28,
    'trace_operational_historical_slice_origin_count': trace['retained_canonical_operational_origin_count'],
    'old_foundation_24_origin_census_retained_separately': True,
    'old_physical_proof_owners_and_old_canonical_operational_owners_must_be_excluded': True,
    'FN_construction_Typing_Driver_record_guards_installed_guards_or_native_Installed_selected': False,
    'complete_new_closure_compiled_or_budget_fit_claimed': False})

historical_scopes = []
input_map = {}


def add(row):
    checked(row)
    previous = input_map.get(row['path'])
    assert previous is None or previous == row, row['path']
    input_map[row['path']] = row


for name in [foundation_path, trace_path, bridge_path]:
    inv_pin = identity(name + '/SOURCE-INVENTORY.json')
    audit_pin = identity(name + '/SOURCE-AUDIT.json')
    author = load(inv_pin['path']); audit = load(audit_pin['path'])
    review_pin = audit['source_review']; checked(review_pin)
    arrays = []
    for label, pin, data in [('author', inv_pin, author), ('review', audit_pin, audit)]:
        rows = data['inputs']
        expected_count = data['input_count'] if label == 'author' else data['direct_input_count']
        assert len(rows) == expected_count
        raw = json.dumps(rows, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
        arrays.append({'role': label, 'source': pin, 'json_field': 'inputs', 'count': len(rows),
                       'canonical_json_bytes': len(raw), 'canonical_json_sha256': digest(raw)})
        for row in rows:
            add(row)
    for row in [inv_pin, audit_pin, review_pin]:
        add(row)
    historical_scopes.append({'scope': name.split('/')[-1], 'author_inventory': inv_pin,
                              'independent_audit': audit_pin, 'independent_review': review_pin,
                              'unchanged_input_arrays': arrays,
                              'original_scope_selection_or_status_rebased': False})
history = write_json('HISTORICAL-REVIEW-SCOPES.json', {
    'format': 'adwh-eventual-interpreter-preserved-review-scopes-v1', 'scope_count': 3,
    'scopes': historical_scopes,
    'foundation_six_ingredient_scope_ledger': identity(foundation_path + '/INGREDIENT-REVIEW-SCOPES.json'),
    'trace_nine_prior_scopes_preserved_in_original_inventory': True,
    'query_bridge_original_scopes_and_later_trace_review_preserved': True,
    'nested_original_input_arrays_or_source_statuses_rebased': False,
    'new_assembly_independent_review': 'pending'})

evidence_paths = [foundation_path + '/gate/' + name for name in [
    'RESULT-AND-NEXT.md', 'ROOT-EXECUTION-RECEIPT.json', 'SNAPSHOT-RECOVERY.json',
    'INDEPENDENT-CONTROL-REVIEW.md', 'STATIC-INDEPENDENT-CONTROL-AUDIT.json',
    'source-manifest.json', 'CONTROL-CORRESPONDENCE.json', 'PROTOCOL.md', 'run_gate.py',
    'attempts/complete-01/report.json',
    'execution-markers/complete-c66c83974aaa9b0b059fc2b136a81a711964933c6d4e939752df41395890f9ce.json']]
evidence = [identity(x) for x in evidence_paths]
for row in evidence:
    add(row)
prior = write_json('PRIOR-ACCEPTANCE-CONTEXT.json', {
    'format': 'adwh-eventual-interpreter-separate-foundation134-evidence-v1',
    'evidence': evidence,
    'result_description_source': identity(foundation_path + '/gate/RESULT-AND-NEXT.md'),
    'reported_by_root': {'accepted_reports': 134, 'ordinary_outputs': 6,
                         'elapsed_seconds': 25.97892414099988, 'peak_rss_kib': 877200,
                         'consumed_source_key': 'c66c83974aaa9b0b059fc2b136a81a711964933c6d4e939752df41395890f9ce'},
    'actual_run_report_and_recovery_hashed_only_by_assembly_author': True,
    'dedicated_saved_result_reader_executed_by_assembly_author': False,
    'compiled_objects_selected_or_reused': False,
    'old_source_key_or_marker_reset': False,
    'prior_acceptance_transferred_to_new_185_selection': False,
    'larger_selection_timing_or_resource_fit_inferred': False})

for pair in sdk_rows:
    add(pair['original']); add(pair['retained_copy'])
for row in physical_sources + sources:
    add(row)
for row in [correspondence, scope, sdk, source_census, history, prior,
            identity(Path(__file__).relative_to(BASE)),
            identity(PKG / 'PLAN.md'), identity(PKG / 'AUTHOR-REVIEW.md')]:
    add(row)
inputs = [input_map[key] for key in sorted(input_map)]
inventory = write_json('SOURCE-INVENTORY.json', {
    'format': 'adwh-eventual-interpreter-assembly-author-inventory-v1',
    'author': '/root/nat_only_gap_review',
    'status': 'frozen_source_only_exact_assembly_awaiting_independent_review',
    'input_count': len(inputs), 'inputs': inputs,
    'source': candidate, 'baseline_proof_inputs': sources,
    'selected_physical_sources': physical_sources,
    'source_correspondence': correspondence, 'private_and_scope_audit': scope,
    'SDK_name_resolution_context': sdk, 'source_census': source_census,
    'historical_review_scopes': history, 'separate_prior_acceptance_context': prior,
    'preserved_immediate_scope_pairs': [[916, 917], [1051, 1052], [1264, 1267]],
    'direct_proof_inputs': 5, 'granular_project_proof_file_origins': 11,
    'internalized_import_edits': 8, 'unchanged_complements_including_empty': 13,
    'new_boundary_comments': 10, 'new_initial_comment': 1,
    'all_mathematical_source_statements_proofs_options_and_reports_literal': True,
    'accepted_foundation_full_source_file_literal': True,
    'Core_and_Cached_unchanged': True,
    'private_theorem_count': 6,
    'public_theorem_header_count': sum(x['kind'] == 'theorem' and not x['private'] for x in original_declarations),
    'all_theorem_header_count': sum(x['kind'] == 'theorem' for x in original_declarations),
    'new_proof_owner_report_count': 177, 'physical_owner_count': 3,
    'ordered_report_counts': [2, 6, 177], 'report_count': 185, 'ordered_reports': total_reports,
    'source_bytes': sum(x['bytes'] for x in physical_sources), 'ordinary_output_count': 6,
    'old_canonical_alternative_physical_owners_must_be_excluded': True,
    'FN_construction_Typing_Driver_guards_or_native_Installed_selected': False,
    'prior_acceptance_or_private_compiled_term_identity_transferred': False,
    'gate_controls_authored_or_selected': False,
    'compiler_gate_preflight_exporter_profiler_evaluator_mathematical_generator_or_saved_reader_executed': False,
    'independent_source_review_fresh_acceptance_or_budget_fit_claimed': False,
    'actual_complete_query_pins_installation_GroupChecked_EnvWF_or_numeral_proved_by_assembly': False})
print(json.dumps({'source': candidate, 'inventory': inventory,
                  'input_count': len(inputs), 'source_bytes': sum(x['bytes'] for x in physical_sources),
                  'public_theorem_headers': sum(x['kind'] == 'theorem' and not x['private'] for x in original_declarations),
                  'all_theorem_headers': sum(x['kind'] == 'theorem' for x in original_declarations),
                  'cross_private_spelling_occurrences': len(private_cross_occurrences)}, indent=2))
