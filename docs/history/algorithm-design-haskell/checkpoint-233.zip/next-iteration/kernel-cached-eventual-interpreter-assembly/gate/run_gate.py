#!/usr/bin/env python3
"""Fresh consolidated non-atomic eventual interpreter185. Root alone executes; no Lean without --run."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-foundation/gate'
ASSEMBLY = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-interpreter185-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-interpreter185-manifest-v1'
PREVIOUS = None
HISTORICAL = None
POLICY = {'Elab.async': False,
 'autoImplicit': False,
 'compiler_threads': 1,
 'cumulative_wall_seconds': 30,
 'default_heartbeats_recursion_and_compiler_options': True,
 'lean_memory_mib': 1024,
 'resident_memory_kib': 1048576,
 'warningAsError': True}
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
PREVIOUS_RUNNER_PIN = ('next-iteration/kernel-cached-eventual-foundation/gate/run_gate.py',
 80267,
 '9c1178c0bfc029991f736e46210c57936d4f763f716bbc535f3ccb4b5da76244')
PREVIOUS_MANIFEST_PIN = ('next-iteration/kernel-cached-eventual-foundation/gate/source-manifest.json',
 289593,
 '11dbcea246364c9951cd1255225c6846936ac3b174610a62fcec16d21df9d12e')
MODULES = ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedEventualInterpreter']
SOURCE_PINS = [('next-iteration/kernel-cached-eventual-owner-slice/source/KernelCompactCore.lean',
  208582,
  '6aacedb54c0facfe362112a156c2e3a877b83ccca043d55f8e22f99cd4404447'),
 ('next-iteration/kernel-cached-eventual-owner-slice/source/KernelCachedForward.lean',
  202799,
  '323da5194486ccf72b8732869415b6d27a9ff2c0dc57406c17c1cd83ef742804'),
 ('next-iteration/kernel-cached-eventual-interpreter-assembly/source/KernelCachedEventualInterpreter.lean',
  206751,
  '9c60b1c565372d266a15c7bc40e2f59e3a5cbded8b0f97cc497934546abc949a')]
EXPECTED_IMPORTS = {'KernelCachedEventualInterpreter': ['KernelCachedForward'],
 'KernelCachedForward': ['KernelCompactCore'],
 'KernelCompactCore': ['Std.Data.HashMap', 'Init.Util']}
REQUIRED = {'KernelCachedEventualInterpreter': ['ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_insert',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_hit_value',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_full',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_head',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_cache_value',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_cache_value',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_flushed',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_full_miss',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_head_miss',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flush_starts_unseeded',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.true_memo_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_forward_of_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_forward_of_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.eventual_functional',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_functional',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_functional',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.empty_valid',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_miss_from_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_miss_from_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_eventual_of_body_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_eventual_of_body_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_loop_atom',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_loop_terminal_of_head',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.trace_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_trace_eventual',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_trace_eventual',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_atom_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_terminal_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_nat',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_sort',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_insert',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ienv_tags_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_flushed',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_result_of_unchanged',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_cut',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_eq_plain',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParams_eq_plain',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_helper_result',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_helper_result',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_helper_result',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instListM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_correct',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_from_prefix',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_from_prefix',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_from_prefix',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_pure',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_throw',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_bind',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modifyGet',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modify',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instLevelParamsM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedTyIdxM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedValIdxM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instListM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constTyAtM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constValAtM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.ruleRhsAtM_preserves',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.helper_result_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.restCaches_helper_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_cache_memo_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helpers_auxiliary_memo_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.restCaches_memo_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.true_helper_frame',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_eventual_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.empty_valid',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.flushed_valid',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instLevelParamsM_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instListM_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constTyAtM_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constValAtM_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.ruleRhsAtM_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.head_body_nat',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_insert',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_after_rest',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_cheap',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_defeq',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_forward_of_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_forward_of_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_nat',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_const',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.no_iota_of_no_recursor',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.whnf_spine_no_recursor',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.add_not_recursor',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_recursor',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.full_nat_with_rest',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_literal',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.offset_literal_add',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.reduce_add_zero',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_literal_add',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_proof',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_eq',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_unfoldable',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_eq',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_argument_list',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.stuck_eq',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_eq_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_refl_type_defeq',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_nat_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_const_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_application_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_done',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_forall',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_const_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_nat_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_application_body',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsIAux_never',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsI_never',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.defEqListI_empty',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.iotaIndexOkI_noIndices',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.whnfAppI_never',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_never',
                                     'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_done',
                                     'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.full_loop_nat_of_head',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.primitive_result_nat',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.primitive_result_const',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.stored_definition',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.stored_head_no_iota',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.reduce_nat_binary',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.full_loop_const_of_head',
                                     'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.full_loop_result_of_head',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.get_app_fn_scoped',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_done',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_skip',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_iota_of_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.head_loop_app_of_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.definition_head_no_iota',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.reduce_nat_bypass',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.unfold_definition_of_run',
                                     'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.full_loop_delta_of_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.partial_iota_arity',
                                     'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.complete_iota_arity',
                                     'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.major_to_ctor_two',
                                     'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.prepare_nat_of_run',
                                     'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared',
                                     'ADWH.Experiments.Chapter15.KernelCachedBinaryHeadForward.full_loop_binary_query_of_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedLicensedTrace.beta_peel_stop_equation',
                                     'ADWH.Experiments.Chapter15.KernelCachedLicensedTrace.nat_spine_iota_with_rest',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.head_atom_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.primitive_head_forward',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.unfold_definition_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_plain_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_nat_zero_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_nat_successor_with_auxiliary',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.trace_runs',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_eventual',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.head_trace_eventual',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_forward_of_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.head_forward_of_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_preserves_rest',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_at_record_fuel',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.atom_head_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.literal_full_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.binary_self_head_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.binary_full_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualQueryBridge.query_with_rest_of_trace',
                                     'ADWH.Experiments.Chapter15.KernelCachedEventualQueryBridge.query_with_rest_at_record_fuel'],
 'KernelCachedForward': ['ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_miss'],
 'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero', 'ConLeche.PropWhen.eq_of_toList']}
RAW_REQUIRED = {'KernelCachedEventualInterpreter': ['map_empty',
                                     'map_insert',
                                     'map_hit_value',
                                     'nf_empty',
                                     'nf_frame',
                                     'nf_insert_full',
                                     'nf_insert_head',
                                     'full_cache_value',
                                     'head_cache_value',
                                     'nf_flushed',
                                     'flushed_full_miss',
                                     'flushed_head_miss',
                                     'flush_starts_unseeded',
                                     'true_memo_frame',
                                     'full_forward_of_body',
                                     'head_forward_of_body',
                                     'eventual_functional',
                                     'full_functional',
                                     'head_functional',
                                     'empty_valid',
                                     'full_miss_from_empty',
                                     'head_miss_from_empty',
                                     'full_eventual_of_body_runs',
                                     'head_eventual_of_body_runs',
                                     'head_loop_atom',
                                     'full_loop_terminal_of_head',
                                     'trace_runs',
                                     'full_trace_eventual',
                                     'head_trace_eventual',
                                     'head_atom_trace',
                                     'full_terminal_trace',
                                     'cached_nat',
                                     'cached_sort',
                                     'map_backed_empty',
                                     'map_backed_insert',
                                     'ienv_tags_empty',
                                     'helper_cache_empty',
                                     'helper_cache_frame',
                                     'helper_cache_flushed',
                                     'helper_result_of_unchanged',
                                     'instantiateListC_cut',
                                     'instantiateListC_eq_plain',
                                     'instLevelParams_eq_plain',
                                     'instLevelParamsM_correct',
                                     'storedTyIdxM_correct',
                                     'storedValIdxM_correct',
                                     'instLevelParamsM_helper_result',
                                     'storedTyIdxM_helper_result',
                                     'storedValIdxM_helper_result',
                                     'instListM_correct',
                                     'constTyAtM_correct',
                                     'constValAtM_correct',
                                     'ruleRhsAtM_correct',
                                     'constTyAtM_from_prefix',
                                     'constValAtM_from_prefix',
                                     'ruleRhsAtM_from_prefix',
                                     'preserves_pure',
                                     'preserves_throw',
                                     'preserves_bind',
                                     'preserves_modifyGet',
                                     'preserves_modify',
                                     'instLevelParamsM_preserves',
                                     'storedTyIdxM_preserves',
                                     'storedValIdxM_preserves',
                                     'instListM_preserves',
                                     'constTyAtM_preserves',
                                     'constValAtM_preserves',
                                     'ruleRhsAtM_preserves',
                                     'helper_result_with_auxiliary',
                                     'restCaches_helper_frame',
                                     'helper_cache_memo_frame',
                                     'helpers_auxiliary_memo_frame',
                                     'restCaches_memo_frame',
                                     'true_helper_frame',
                                     'helper_result_nf',
                                     'helper_result_nf_with_auxiliary',
                                     'helper_result_eventual_with_auxiliary',
                                     'empty_valid',
                                     'flushed_valid',
                                     'instLevelParamsM_forward',
                                     'instListM_forward',
                                     'constTyAtM_forward',
                                     'constValAtM_forward',
                                     'ruleRhsAtM_forward',
                                     'head_body_nat',
                                     'true_defeq_empty',
                                     'true_defeq_insert',
                                     'working_empty',
                                     'working_after_rest',
                                     'working_insert_cheap',
                                     'working_insert_defeq',
                                     'defeq_forward_of_body',
                                     'defeq_same_body',
                                     'defeq_same',
                                     'cheap_forward_of_body',
                                     'cheap_nat',
                                     'cheap_const',
                                     'no_iota_of_no_recursor',
                                     'whnf_spine_no_recursor',
                                     'cheap_application_body',
                                     'cheap_application',
                                     'add_not_recursor',
                                     'eq_not_recursor',
                                     'full_nat_with_rest',
                                     'prop_irrel_literal',
                                     'offset_literal_add',
                                     'reduce_add_zero',
                                     'lazy_literal_add',
                                     'defeq_literal_add_body',
                                     'defeq_literal_add',
                                     'eq_not_proof',
                                     'prop_irrel_eq',
                                     'eq_not_unfoldable',
                                     'lazy_eq',
                                     'eq_argument_list',
                                     'stuck_eq',
                                     'defeq_eq_body',
                                     'eq_refl_type_defeq',
                                     'infer_nat_body',
                                     'infer_const_body',
                                     'infer_application_body',
                                     'infer_spine_done',
                                     'infer_spine_forall',
                                     'annotate_const_body',
                                     'annotate_nat_body',
                                     'annotate_application_body',
                                     'iotaCertsIAux_never',
                                     'iotaCertsI_never',
                                     'defEqListI_empty',
                                     'iotaIndexOkI_noIndices',
                                     'whnfAppI_never',
                                     'betaPeelI_never',
                                     'betaPeelI_done',
                                     'full_loop_nat_of_head',
                                     'primitive_result_nat',
                                     'primitive_result_const',
                                     'stored_definition',
                                     'stored_head_no_iota',
                                     'reduce_nat_binary',
                                     'full_loop_const_of_head',
                                     'full_loop_result_of_head',
                                     'get_app_fn_scoped',
                                     'whnf_app_done',
                                     'whnf_app_skip',
                                     'whnf_app_iota_of_runs',
                                     'head_loop_app_of_runs',
                                     'definition_head_no_iota',
                                     'reduce_nat_bypass',
                                     'unfold_definition_of_run',
                                     'full_loop_delta_of_runs',
                                     'partial_iota_arity',
                                     'complete_iota_arity',
                                     'major_to_ctor_two',
                                     'prepare_nat_of_run',
                                     'iota_plain_of_prepared',
                                     'full_loop_binary_query_of_runs',
                                     'beta_peel_stop_equation',
                                     'nat_spine_iota_with_rest',
                                     'head_atom_forward',
                                     'primitive_head_forward',
                                     'unfold_definition_with_auxiliary',
                                     'iota_plain_with_auxiliary',
                                     'iota_nat_zero_with_auxiliary',
                                     'iota_nat_successor_with_auxiliary',
                                     'trace_runs',
                                     'full_trace_eventual',
                                     'head_trace_eventual',
                                     'full_forward_of_trace',
                                     'head_forward_of_trace',
                                     'full_trace_preserves_rest',
                                     'full_trace_at_record_fuel',
                                     'atom_head_trace',
                                     'literal_full_trace',
                                     'binary_self_head_trace',
                                     'binary_full_trace',
                                     'query_with_rest_of_trace',
                                     'query_with_rest_at_record_fuel'],
 'KernelCachedForward': ['memoEI_hit', 'memoEI_miss', 'whnf_hit', 'whnf_miss', 'whnfCore_hit', 'whnfCore_miss'],
 'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero', 'ConLeche.PropWhen.eq_of_toList']}
ASSEMBLY_INPUTS = [{'bytes': 119150,
  'path': 'next-iteration/kernel-cached-eventual-foundation/source/KernelCachedEventualFoundation.lean',
  'sha256': 'b88b25aa807de203419c1d50b860b08950f44de8e5bf03172a91e132c162ccd5'},
 {'bytes': 31864,
  'path': 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedOperationalContracts.lean',
  'sha256': '1d1599494d88cb0e1c26c260b71996000d860fb9a2491cd98439166e665c1bdf'},
 {'bytes': 13716,
  'path': 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedEventualSteps.lean',
  'sha256': 'c9dd32403173d0ade2bcaedbf40e0b2b85e03b6b1dd2d306d1c548cd06e47930'},
 {'bytes': 38923,
  'path': 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedEventualTrace.lean',
  'sha256': '6ee8fcc263ec3feb779ae8fb217ca6a278793ff81593da43d0abbfc50e735107'},
 {'bytes': 1814,
  'path': 'next-iteration/kernel-cached-eventual-query-bridge/source/KernelCachedEventualQueryBridge.lean',
  'sha256': '3c8a381c992edb45aa24ccdf90fb529962f98286bc5a92dba18f540196f2cf27'}]
ASSEMBLY_INPUT_MODULES = ['KernelCachedEventualFoundation',
 'KernelCachedOperationalContracts',
 'KernelCachedEventualSteps',
 'KernelCachedEventualTrace',
 'KernelCachedEventualQueryBridge']
ASSEMBLY_INPUT_ROOTS = [['ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_empty',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_insert',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_hit_value',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_empty',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_frame',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_full',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_head',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_cache_value',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_cache_value',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_flushed',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_full_miss',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_head_miss',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flush_starts_unseeded',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.true_memo_frame',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_forward_of_body',
  'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_forward_of_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.eventual_functional',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_functional',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_functional',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.empty_valid',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_miss_from_empty',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_miss_from_empty',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_eventual_of_body_runs',
  'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_eventual_of_body_runs',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_loop_atom',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_loop_terminal_of_head',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.trace_runs',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_trace_eventual',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_trace_eventual',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_atom_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_terminal_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_nat',
  'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_sort',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_empty',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_insert',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ienv_tags_empty',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_empty',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_frame',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_flushed',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_result_of_unchanged',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_cut',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_eq_plain',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParams_eq_plain',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_helper_result',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_helper_result',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_helper_result',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instListM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_correct',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_from_prefix',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_from_prefix',
  'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_from_prefix',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_pure',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_throw',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_bind',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modifyGet',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modify',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instLevelParamsM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedTyIdxM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedValIdxM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instListM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constTyAtM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constValAtM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.ruleRhsAtM_preserves',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.helper_result_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.restCaches_helper_frame',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_cache_memo_frame',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helpers_auxiliary_memo_frame',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.restCaches_memo_frame',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.true_helper_frame',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_eventual_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.empty_valid',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.flushed_valid',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instLevelParamsM_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instListM_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constTyAtM_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constValAtM_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.ruleRhsAtM_forward',
  'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.head_body_nat',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_empty',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_insert',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_empty',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_after_rest',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_cheap',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_defeq',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_forward_of_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_forward_of_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_nat',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_const',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.no_iota_of_no_recursor',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.whnf_spine_no_recursor',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.add_not_recursor',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_recursor',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.full_nat_with_rest',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_literal',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.offset_literal_add',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.reduce_add_zero',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_literal_add',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_proof',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_eq',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_unfoldable',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_eq',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_argument_list',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.stuck_eq',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_eq_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_refl_type_defeq',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_nat_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_const_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_application_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_done',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_forall',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_const_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_nat_body',
  'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_application_body'],
 ['ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsIAux_never',
  'ADWH.Experiments.Chapter15.KernelCachedForward.iotaCertsI_never',
  'ADWH.Experiments.Chapter15.KernelCachedForward.defEqListI_empty',
  'ADWH.Experiments.Chapter15.KernelCachedForward.iotaIndexOkI_noIndices',
  'ADWH.Experiments.Chapter15.KernelCachedForward.whnfAppI_never',
  'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_never',
  'ADWH.Experiments.Chapter15.KernelCachedForward.betaPeelI_done',
  'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.full_loop_nat_of_head',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.primitive_result_nat',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.primitive_result_const',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.stored_definition',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.stored_head_no_iota',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.reduce_nat_binary',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.full_loop_const_of_head',
  'ADWH.Experiments.Chapter15.KernelCachedArithmeticForward.full_loop_result_of_head',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.get_app_fn_scoped',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_done',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_skip',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.whnf_app_iota_of_runs',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.head_loop_app_of_runs',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.definition_head_no_iota',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.reduce_nat_bypass',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.unfold_definition_of_run',
  'ADWH.Experiments.Chapter15.KernelCachedBetaDeltaForward.full_loop_delta_of_runs',
  'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.partial_iota_arity',
  'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.complete_iota_arity',
  'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.major_to_ctor_two',
  'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.prepare_nat_of_run',
  'ADWH.Experiments.Chapter15.KernelCachedNatIotaForward.iota_plain_of_prepared',
  'ADWH.Experiments.Chapter15.KernelCachedBinaryHeadForward.full_loop_binary_query_of_runs',
  'ADWH.Experiments.Chapter15.KernelCachedLicensedTrace.beta_peel_stop_equation',
  'ADWH.Experiments.Chapter15.KernelCachedLicensedTrace.nat_spine_iota_with_rest'],
 ['ADWH.Experiments.Chapter15.KernelCachedEventualSteps.head_atom_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.primitive_head_forward',
  'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.unfold_definition_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_plain_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_nat_zero_with_auxiliary',
  'ADWH.Experiments.Chapter15.KernelCachedEventualSteps.iota_nat_successor_with_auxiliary'],
 ['ADWH.Experiments.Chapter15.KernelCachedEventualTrace.trace_runs',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_eventual',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.head_trace_eventual',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_forward_of_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.head_forward_of_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_preserves_rest',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.full_trace_at_record_fuel',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.atom_head_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.literal_full_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.binary_self_head_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualTrace.binary_full_trace'],
 ['ADWH.Experiments.Chapter15.KernelCachedEventualQueryBridge.query_with_rest_of_trace',
  'ADWH.Experiments.Chapter15.KernelCachedEventualQueryBridge.query_with_rest_at_record_fuel']]
INTERNAL_IMPORTS = [[],
 ['KernelCachedHelperContract', 'KernelCachedLiteralContract'],
 ['KernelCachedEventualHelpers', 'KernelCachedEventualAtoms', 'KernelCachedOperationalContracts'],
 ['KernelCachedEventualSteps'],
 ['KernelCachedEventualTrace', 'KernelCachedEventualRecordWrapper']]
ASSEMBLY_REVIEW_FACTS = {'SDK_literal_intervals': 3,
 'SDK_whole_file_pairs': 2,
 'author_inputs_verified': 1305,
 'compiler_gate_or_mathematical_execution': False,
 'cross_origin_private_spelling_occurrences': 6,
 'exact_input_files': 5,
 'full_forward_inverse_reconstructions': 5,
 'historical_scope_pairs': [[916, 917], [1051, 1052], [1264, 1267]],
 'import_edits': 8,
 'namespace_blocks': 18,
 'ordered_distinct_reports': 185,
 'ordinary_outputs': 6,
 'private_theorem_headers': 6,
 'public_declarations': 231,
 'public_theorem_headers': 177,
 'status': 'passed_independent_static_assembly_review',
 'strict_option_occurrences': 36,
 'unchanged_complements_including_empty': 13,
 'whole_foundation_bytes_literal': 119150,
 'whole_selected_sources': 3,
 'whole_source_bytes': 618132}
NEW_SCOPE_CONTRACTS = [{'audit_status': 'passed_source_only_uncompiled',
  'author_input_count': 1051,
  'author_inputs': {'canonical_json_bytes': 190172,
                    'canonical_json_sha256': '147cd819b5d80c612acc236a9dbde451afe3594334f930808d805808533a06b2',
                    'item_count': 1051,
                    'json_field': 'inputs',
                    'source': {'bytes': 270106,
                               'path': 'next-iteration/kernel-cached-eventual-trace/SOURCE-INVENTORY.json',
                               'sha256': 'aa79104beb4a6265e68f401768f4014726ce46595e8035b210368ed148a264b5'}},
  'author_inventory': {'bytes': 270106,
                       'path': 'next-iteration/kernel-cached-eventual-trace/SOURCE-INVENTORY.json',
                       'sha256': 'aa79104beb4a6265e68f401768f4014726ce46595e8035b210368ed148a264b5'},
  'name': 'Trace49',
  'original_scope_or_selection_rebased': False,
  'review_input_count': 1052,
  'review_inputs': {'canonical_json_bytes': 190340,
                    'canonical_json_sha256': '855085b9e1d8903cfa8ce35a123241434d1aa99982d89bb1ed7d2b07905c3db7',
                    'item_count': 1052,
                    'json_field': 'inputs',
                    'source': {'bytes': 273303,
                               'path': 'next-iteration/kernel-cached-eventual-trace/SOURCE-AUDIT.json',
                               'sha256': '65c781fd6c621dd338f7a3a25c490ffc15820732ad7dbf916f61157e1c25e02e'}},
  'reviewer': '/root/book_scope_review',
  'source_audit': {'bytes': 273303,
                   'path': 'next-iteration/kernel-cached-eventual-trace/SOURCE-AUDIT.json',
                   'sha256': '65c781fd6c621dd338f7a3a25c490ffc15820732ad7dbf916f61157e1c25e02e'},
  'source_review': {'bytes': 11724,
                    'path': 'next-iteration/kernel-cached-eventual-trace/SOURCE-REVIEW.md',
                    'sha256': '72fb998a62dd7caab1c78026510f39feb3e35b888952a6bc0c09d118fc33b4d5'}},
 {'audit_status': 'passed_source_only_uncompiled',
  'author_input_count': 1264,
  'author_inputs': {'canonical_json_bytes': 231659,
                    'canonical_json_sha256': '4493f75ba5a92fbcb05ffbec82136aab1fd1d7fb19277e7a095ca5a06719a463',
                    'item_count': 1264,
                    'json_field': 'inputs',
                    'source': {'bytes': 315505,
                               'path': 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-INVENTORY.json',
                               'sha256': '78cdd25d8054b11e52c72bccc0a40a1be9c4fbbd3013057bc160afd25ef71ce8'}},
  'author_inventory': {'bytes': 315505,
                       'path': 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-INVENTORY.json',
                       'sha256': '78cdd25d8054b11e52c72bccc0a40a1be9c4fbbd3013057bc160afd25ef71ce8'},
  'name': 'QueryBridge2',
  'original_scope_or_selection_rebased': False,
  'review_input_count': 1267,
  'review_inputs': {'canonical_json_bytes': 232160,
                    'canonical_json_sha256': '5f842dadfcb96dbcc0197400fa097355c844975607b41ad732d2c3dbfc4ef010',
                    'item_count': 1267,
                    'json_field': 'inputs',
                    'source': {'bytes': 318409,
                               'path': 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-AUDIT.json',
                               'sha256': '15a2dfc269b3d4df21be10af8b14dc9c7711dee72794fd513669f0244023f16f'}},
  'reviewer': '/root/book_scope_review',
  'source_audit': {'bytes': 318409,
                   'path': 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-AUDIT.json',
                   'sha256': '15a2dfc269b3d4df21be10af8b14dc9c7711dee72794fd513669f0244023f16f'},
  'source_review': {'bytes': 5058,
                    'path': 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-REVIEW.md',
                    'sha256': 'abffa4302e84ba75874c040eda3234fba0f143fa2b0b91e013cb87a863e85172'}},
 {'audit_status': 'passed_independent_source_assembly_review_not_compiled',
  'author_input_count': 1305,
  'author_inputs': {'canonical_json_bytes': 239011,
                    'canonical_json_sha256': '24c258913fd4489ea8059d6610a54517bc7e7f8f0663c8a2085a3ca056ead407',
                    'item_count': 1305,
                    'json_field': 'inputs',
                    'source': {'bytes': 303491,
                               'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-INVENTORY.json',
                               'sha256': '919875e7082ba0154336f972a3595273df7e18321d922e37925eab98253c78fb'}},
  'author_inventory': {'bytes': 303491,
                       'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-INVENTORY.json',
                       'sha256': '919875e7082ba0154336f972a3595273df7e18321d922e37925eab98253c78fb'},
  'name': 'Interpreter185Assembly',
  'original_scope_or_selection_rebased': False,
  'review_input_count': 1306,
  'review_inputs': {'canonical_json_bytes': 239194,
                    'canonical_json_sha256': 'd1176b2a5bbf00dfeceb37466bd8c2425b02ab04ff4947274e24691a0be827e7',
                    'item_count': 1306,
                    'json_field': 'inputs',
                    'source': {'bytes': 286608,
                               'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-AUDIT.json',
                               'sha256': '2534bb336c8ff10350713683c6989cd32351d86a894a575c52f609e579747683'}},
  'reviewer': '/root',
  'source_audit': {'bytes': 286608,
                   'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-AUDIT.json',
                   'sha256': '2534bb336c8ff10350713683c6989cd32351d86a894a575c52f609e579747683'},
  'source_review': {'bytes': 8287,
                    'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-REVIEW.md',
                    'sha256': 'f68791f5cd118f758743ef629c50cef2c25df105a35f71db291c60796656ee20'}}]
EXTERNAL_RECOVERY = [{'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 3027,
                       'path': '../toolchains/lean-4.35.0-linux/src/lean/Init/Data/BEq.lean',
                       'sha256': '7c60c30768d646020cc4e4e504e5f234ed717afa70637cd1c0e0e1053741e442'},
  'retained_copy': {'bytes': 3027,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Init/Data/BEq.lean',
                    'sha256': '7c60c30768d646020cc4e4e504e5f234ed717afa70637cd1c0e0e1053741e442'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 886,
                       'path': '../toolchains/lean-4.35.0-linux/src/lean/Init/Data/LawfulHashable.lean',
                       'sha256': '14a5635bf79ab8693d34e2c9dc8166f1ec37de9e5996cab1b03c88ed41d47d19'},
  'retained_copy': {'bytes': 886,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Init/Data/LawfulHashable.lean',
                    'sha256': '14a5635bf79ab8693d34e2c9dc8166f1ec37de9e5996cab1b03c88ed41d47d19'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 144893,
                       'path': '../toolchains/lean-4.35.0-linux/src/lean/Std/Data/HashMap/Lemmas.lean',
                       'sha256': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882'},
  'retained_copy': {'bytes': 144893,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Std/Data/HashMap/Lemmas.lean',
                    'sha256': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 88344,
                       'path': '../upstream-source/con-leche-67f04630d88718e81aa4d07ab64501f68f105398/ConLeche/Cached/CoreC.lean',
                       'sha256': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f'},
  'retained_copy': {'bytes': 88344,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/CoreC.lean',
                    'sha256': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 20136,
                       'path': '../upstream-source/con-leche-67f04630d88718e81aa4d07ab64501f68f105398/ConLeche/Cached/StateC.lean',
                       'sha256': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0'},
  'retained_copy': {'bytes': 20136,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/StateC.lean',
                    'sha256': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 119234,
                       'path': '../upstream-source/con-leche-67f04630d88718e81aa4d07ab64501f68f105398/ConLeche/Kernel/ExprOps.lean',
                       'sha256': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6'},
  'retained_copy': {'bytes': 119234,
                    'path': 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/ExprOps.lean',
                    'sha256': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 1932,
                       'path': '../toolchains/lean-4.35.0-linux/src/lean/Lean/PrivateName.lean',
                       'sha256': '21569296df3d69ca3f48dd109ed875c040509f9f693419e44cea9fa130b08179'},
  'retained_copy': {'bytes': 1932,
                    'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/sdk/Lean/PrivateName.lean',
                    'sha256': '21569296df3d69ca3f48dd109ed875c040509f9f693419e44cea9fa130b08179'}},
 {'only_exact_original_identity_may_use_this_recovery': True,
  'original_context': {'bytes': 30735,
                       'path': '../toolchains/lean-4.35.0-linux/src/lean/Lean/ResolveName.lean',
                       'sha256': '29568f90bc8c5b713b7462096b94e898f30d0eca21119ae9abac695604615d13'},
  'retained_copy': {'bytes': 30735,
                    'path': 'next-iteration/kernel-cached-eventual-interpreter-assembly/sdk/Lean/ResolveName.lean',
                    'sha256': '29568f90bc8c5b713b7462096b94e898f30d0eca21119ae9abac695604615d13'}}]
NEW_FIXED = {'next-iteration/kernel-cached-arithmetic-forward/PLAN.md': 'dbafdc7e36b68060f9a72601a2b2d668be6ad7a85ec3d9e578750be5044b18a1',
 'next-iteration/kernel-cached-arithmetic-forward/PRIMARY-SOURCE-INTERVALS.json': '6ed1bad00ff9c78a4b1347b2b43b5639a1a191b2c52f9ca5f20dbe10eca1eaf5',
 'next-iteration/kernel-cached-arithmetic-forward/SOURCE-AUDIT.json': 'eec0530fe386aaef3132cb900ec4ee1e62d91529bae150a7752bfef77509664a',
 'next-iteration/kernel-cached-arithmetic-forward/SOURCE-INVENTORY.json': '86977522f8aad6e29f801bddf3f8246350f62c8743126ab90e406bb75cc8dc67',
 'next-iteration/kernel-cached-arithmetic-forward/SOURCE-REVIEW.md': 'c69abb938d75a2454ec13712738e532db47a5c5b4fc1175fb67cc26b12dfa233',
 'next-iteration/kernel-cached-arithmetic-forward/source/KernelCachedArithmeticForward.lean': '9488897da7437e42f71e9bdc31f60dba491bf5c347571bff50a41d1dd41b53ca',
 'next-iteration/kernel-cached-base-cost-assessment/ASSESSMENT.md': '4b8e296a2d1a6daa7e1b716cf7c19386552bf1da1f5fe2b7588438905b05c74f',
 'next-iteration/kernel-cached-base-cost-assessment/PRIMARY-SOURCE-INTERVALS.json': 'b1f638dfe1387496e9c03381f56084d2aaec42fa9271e7662649dc7d85f1f34f',
 'next-iteration/kernel-cached-base-cost-assessment/SOURCE-INVENTORY.json': 'a331068b1a0fea4e6696acf6a19495e402fdcb211e9164105672d3b4c013d935',
 'next-iteration/kernel-cached-base-cost-assessment/STATIC-CENSUS.json': 'e0b832bed09dd42199fb0c2d04308b8af0a3ac94c8b025540ea427723d93f8a6',
 'next-iteration/kernel-cached-beta-delta-forward/AUTHOR-REVIEW.md': '2e2f4434ecf6ec6943fc0907ce3a8dbe619cdf9be573ec232337f59914972925',
 'next-iteration/kernel-cached-beta-delta-forward/PLAN.md': 'e8fa96418852962f86f4bde728b5fdc519838619854fbbd29e8e4faf98af0eff',
 'next-iteration/kernel-cached-beta-delta-forward/PRIMARY-SOURCE-INTERVALS.json': '0e2e6e7abbf284a5b665e470f7d0a36746b6c8dadd375877efb9795239855e70',
 'next-iteration/kernel-cached-beta-delta-forward/SOURCE-AUDIT.json': 'b281b3a7261025b8563c43e1e8fa48c6c22dcaff27a2438533a5de26ea4fb064',
 'next-iteration/kernel-cached-beta-delta-forward/SOURCE-INVENTORY.json': '2d15f23a1322c6e2c3fc4443a488282d0a430f3f2bc4409df748bd5d1c8fab96',
 'next-iteration/kernel-cached-beta-delta-forward/SOURCE-REVIEW.md': '7f8650f7516cd7252fba8024761b999c76d84af11a16d3a6c86f641d9e456a57',
 'next-iteration/kernel-cached-beta-delta-forward/source/KernelCachedBetaDeltaForward.lean': 'ffaab83ea1d35f689768bc1c844aca26378f5227a1ed5dac71fc36ea369a39f8',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/ASSEMBLY-LOCATION-CONTEXT.json': '4099b4f35cbe10273fae4fa6be2881ccccd834a40f4553e587820c28029c8436',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/AUTHOR-REVIEW.md': 'a4f62f1f026dbac0ac8c9e834e8ae5faa30019245bf0c535a60d582a975d5b47',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/DIAGNOSTIC-CORRESPONDENCE.json': '7353cb472dacb60259b1176d7aab5d483fd1f52b162ca0f43bbe5ab4d6503230',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/DRAFT-EDIT-LEDGER.json': 'f95669cfa3ccf49215989765431407397164760c821fefdad5423f1fdff01a4e',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/PLAN.md': '5134d5b3d3ad327c00c5877cafd67c285ec8c7cb4f3b5d4da783a819bcc8cfd4',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/PRIMARY-SOURCE-INTERVALS.json': '7a190a584aee2360aa06eccab5bbb108c7a0108637cf23e4aa4520165a03c888',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/PROOF-CORRECTION.json': '7848856f3c960fefeb37b141cdcf77a41772a4667dfc660d33404c2d666252a9',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/SDK-PROOF-CONTEXT.json': 'f6e496808495036b86f7abc8179593ae0bd8d3e8e57e7b13d636ac49f265d80d',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/SOURCE-INVENTORY.json': 'a79135fec6cebfea11099362e36ed9a77e60c3c250621adbc30484d12aefbd82',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/sdk/Init/Control/Except.lean': '2073e491eefd9ab091aade1b84b7f5c89a244c47f0cff37dc7a1bc59bef86767',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/sdk/Init/Control/State.lean': '1eaa3725f72bd22af1510fcb5b004f395a1d2eef877cd33d520bfb9bff85bf18',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/sdk/Init/Data/Bool.lean': '182702f903573fe03983e39b23f2af383692e356ad50463eb7264c0152316c3a',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/sdk/Init/SimpLemmas.lean': '0aa122da77386bd084dac91b5921f1cf97a8c99871528d72da6dd6cf0de1074e',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/sdk/Lean/Elab/Tactic/Simp.lean': '22f8ae5a56c71ed9f65c58f242b626e2382916d624d89a5b73e5bbe7bc421978',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/source/KernelCachedBetaDeltaForward.lean': 'a3c65c1947da5a68fa113053f9cc4df270d2225eaca26ee97753513b4c3be6e4',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/source/KernelCachedForwardInterface.lean': '2fa483d4071d451c3fb9efcaac820c785ee882bcf85222fbce40b7c9cf126fd3',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/upstream/ConLeche/Kernel/Core.lean': 'f198f10b3fe5c3bc98e23aef65e6f0d02ad3027f077fd2191b4752e0f50ec886',
 'next-iteration/kernel-cached-beta-delta-interface-diagnosed-repairs/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-boolean-literal-136/gate/AUTHORING.md': '4fda4eebd547a9474f00eb3a1ab5dbcdb01c39b55d32e3a9a3e33480c7ddcc3a',
 'next-iteration/kernel-cached-boolean-literal-136/gate/CONTROL-CORRESPONDENCE.json': 'e5229b1fcfbb758f08c1c19fa3b93ce2a48f858802c901083b09aa9b3ff169af',
 'next-iteration/kernel-cached-boolean-literal-136/gate/INDEPENDENT-CONTROL-REVIEW.md': '483adac5a272805b0695769efbf12e6ecc0b2dcc3a2621626cbdf0d2844fd2d9',
 'next-iteration/kernel-cached-boolean-literal-136/gate/PROTOCOL.md': '3f3f781d2fb17964f19b50e332e1e09e121c0827a023e17e20e923c3bb3391a1',
 'next-iteration/kernel-cached-boolean-literal-136/gate/RESULT-AND-NEXT.md': '1dce88c6d7aa3c5191eccad1de415f20183dc3138f00137fb89230c8f3ddd085',
 'next-iteration/kernel-cached-boolean-literal-136/gate/ROOT-EXECUTION-RECEIPT.json': '9c72fd22e86a67124326da2037e97dd436b489fc6924972b44321812c8cf722e',
 'next-iteration/kernel-cached-boolean-literal-136/gate/SNAPSHOT-RECOVERY.json': '9ef0650de52c04d5b7a80067ab3847a820091e13edfbc78be1ef5f19aabc59dd',
 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCachedForward.stdout.log': 'ac28d97511a31dbfcb5ff0a63882eb3028095650004f77615b4d4726d5783e64',
 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-boolean-literal-136/gate/attempts/complete-01/report.json': 'b4fa5cd51387815e38c44912d66b83ef7b29f5640a7cabd98303188c82a182c6',
 'next-iteration/kernel-cached-boolean-literal-136/gate/execution-markers/complete-de370fa20c22b2e83a93dbab4d80385d83b7673b0e2cbe855433d732a5da797a.json': 'af48791e353f03b883c2a2d684bab440d86be9dc0c28697767bc1fb52967869d',
 'next-iteration/kernel-cached-boolean-literal-136/gate/run_gate.py': '453a823c3aa11fc6678933fc1dd315dde4e46d2b6771b778b463a428acc54b6f',
 'next-iteration/kernel-cached-boolean-literal-136/gate/source-manifest.json': 'd6f9067cc7edc35492dff33e7a3812065b8c3c1bf0aaa8c4c11ee55b8772edeb',
 'next-iteration/kernel-cached-boolean-proof-rewrites/AUTHOR-REVIEW.md': '64e8d345f0df4efe87dc7aaff6cf6c2d29b62e8ccd9bdeb9396b01832930909e',
 'next-iteration/kernel-cached-boolean-proof-rewrites/METADATA-WORDING-CORRECTION.json': 'af80755c321692264118d44bd03804bbe17821e5205fb84d39583bc0459c28bf',
 'next-iteration/kernel-cached-boolean-proof-rewrites/PLAN.md': '49961d8006733f914a72b27d7f0cdc473fc97f1771679e0a7618825330104f2c',
 'next-iteration/kernel-cached-boolean-proof-rewrites/PRIMARY-SOURCE-INTERVALS.json': '7223f1d833785c0796ecadf762ad9819b97b0e927afa8ae849f106000a5f52bd',
 'next-iteration/kernel-cached-boolean-proof-rewrites/PROOF-OVERLAY.json': 'a8a294b9bbaadba9be642eb0cfb53f07ef19610a6c928dd76a482bbabdfc4309',
 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-AUDIT.json': '6675b4e5f6c504663827d3d0a8d43cf3c2ee38bda4106495167bad8e2f9aef65',
 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-CORRESPONDENCE.json': 'c75e3a90151b3d940d0840a6e8097be01c04ea60798490aca6540242fed63bdf',
 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-GRAMMAR-CORRECTION.json': 'a336a072f7e6be6d7994db62e4c5b80d256d51e2ce6e93caa83087a48ddf83dc',
 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-INVENTORY.json': 'dd95f167c1d2a2ebb6a7dbabfc79c99397870d4cf19f29f8a4470ac8b2776257',
 'next-iteration/kernel-cached-boolean-proof-rewrites/SOURCE-REVIEW.md': 'a0944f09943f273a180ef83076f0e3dbdbe650d136fdcfcaa7ecc7f5cc74d04c',
 'next-iteration/kernel-cached-boolean-proof-rewrites/pre-review-metadata-01/PROOF-OVERLAY.json': '3f4b9fde1bd427271d87efe7cb5c10290055bcf8d74c19fb9c7f67d85f722d45',
 'next-iteration/kernel-cached-boolean-proof-rewrites/pre-review-metadata-01/SOURCE-CORRESPONDENCE.json': 'efe829d45442f44dc0c5f406846da13147adac1a4344d1e041c28afc870cfe89',
 'next-iteration/kernel-cached-boolean-proof-rewrites/source/ConLeche/Cached/ExprOpsC.lean': '10cc8c786c7550a087ec9fc11b17f87b7353d7942c6e720716e3ac0884a85cfb',
 'next-iteration/kernel-cached-boolean-proof-rewrites/source/KernelCachedForward.lean': '285b257310da159cd60570a33eac6b5a5396a234b3a7c166762062c381e45565',
 'next-iteration/kernel-cached-boolean-proof-rewrites/unselected-draft-v1/PROOF-OVERLAY.json': 'c0c6c37c51be836c23c74f46235157bf41bd11ba5d35b2efb47887ea589ba7eb',
 'next-iteration/kernel-cached-boolean-proof-rewrites/unselected-draft-v1/SOURCE-CORRESPONDENCE.json': 'ee3e08a923c16e926b1f0fe57793c0da20a33fe61577ab5405b7507be940e475',
 'next-iteration/kernel-cached-boolean-proof-rewrites/unselected-draft-v1/source/ConLeche/Cached/ExprOpsC.lean': '3f2aa61d8faa0f965474f00b6263fd81304bda684d3e96eeb3ced0c7259f84d6',
 'next-iteration/kernel-cached-boolean-proof-rewrites/unselected-draft-v1/source/KernelCachedForward.lean': 'e8c3077f5db9dd5603fecf6797062a5ae61371b28072156c71d28f680eccc939',
 'next-iteration/kernel-cached-boolean-proof-rewrites/upstream-sdk/Init/Notation.lean': 'ff626e7d1359362b5501af9c13cb9cb641259025c377432e7e5842013740652c',
 'next-iteration/kernel-cached-boolean-proof-rewrites/upstream-sdk/Init/Prelude.lean': '390e6b57ead28cb821a65533b21357f2f02d0a1525602f5a1ce9ee3eeb81fd12',
 'next-iteration/kernel-cached-boolean-terminal-repair/AUTHOR-REVIEW.md': 'baa9a3724ea8e771b306f39870445ee6aa8cd79afd195348242ba3b6f6107bd7',
 'next-iteration/kernel-cached-boolean-terminal-repair/DIAGNOSTIC-CORRESPONDENCE.json': 'd4900f568677fcf29f3c9e68452a7197142d68f64a4a330a38dd8337247d66b1',
 'next-iteration/kernel-cached-boolean-terminal-repair/PLAN.md': '41737283bd1d368abcfe43d05b05483dd9f981c709c5e3f763c61d474a78d1d0',
 'next-iteration/kernel-cached-boolean-terminal-repair/PRIMARY-SOURCE-INTERVALS.json': '1416403feafb2b02b23f45f5cdcb03c00e7df6b4c782d748da353dd8614094f4',
 'next-iteration/kernel-cached-boolean-terminal-repair/PROOF-CORRECTION.json': '698a799d3bb9f5c884e4b78a5173de5bdc3c1d1ed3f25c547a44ac4a0f0d9b21',
 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-AUDIT.json': '32f1e627ac984c34fee0dec79baa2e931e7bac9c4830f3ae0d6b900194217f5b',
 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-CORRESPONDENCE.json': '09288e8f7d53d18b411f088877a4f297f986805c0f600417d07f55c94c809508',
 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-INVENTORY.json': '72122aedbcf3a18a78304a21bd785f921b74a0214fc7b6db58d189a95a6e9d9e',
 'next-iteration/kernel-cached-boolean-terminal-repair/SOURCE-REVIEW.md': 'f042d7891a6e1d4778f1309bfcf8150fb19cc7f1048707b80748e93441ea3c9d',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/AUTHORING.md': '8c28aff9af2444ea8383d2dda3eaaec469b68c03cf99f5cffd0f228444e9971c',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/CONTROL-CORRESPONDENCE.json': '245cdc9a25494d92a6fab5ceae8bcb6f14088502def11e8ddd9e70aa2424a1eb',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': '3043581a475fde80d74e822fbfe7b8ccb701314edc8bb1de240ebcbedf76a888',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/PROTOCOL.md': '289d523bc5d87c43d5e91079ce980983d7351b9a81140a5b92e4b2be50dd1d35',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/RESULT-AND-NEXT.md': 'ceb720298a3e1d7909b50b0ef3ee1b4d976a8d9c0a3b4810faafaf517fdc5a23',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/ROOT-EXECUTION-RECEIPT.json': 'b33661d81effdcf6d1b24e8bbe08a6dd42eedef93230b6571d2d2264c0f41e34',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/SNAPSHOT-RECOVERY.json': '4b421824c8808a054f42f5f7015232184f9fc679624487d48461a8657a4ffac3',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedHelperFrame.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedHelperFrame.stdout.log': '0e7dd6f8c5aac9f540158c9ab797d3689df2f4719ddae3fa23c2b1603e8afad5',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'a0daffc9aa4a67520c35df79e7cf5bbc73a1469d1a94bdefdbf174154db8b5a6',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/attempts/complete-01/report.json': 'c419078c5fcac341d7b229cecf2bdb1d970beff3371852e7d2564397c18be230',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/execution-markers/complete-92de445d5e26edc3aaf051c6276c80117260704ed000a5458224b7e69708b9a7.json': 'e0f974fe98467d65ab04c4aed58d7bd3405726b109899531d37c81b44bf960bc',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/run_gate.py': '2cdebf9e1c1135eaede6a2483d67ce1d4027cac2fb7892a95fba8d89e7aa6843',
 'next-iteration/kernel-cached-boolean-terminal-repair/gate/source-manifest.json': '7d6e8514f8d46369ba4c71c09eb1de3512ab6a59bf93543ee2b3c2866b3acb9b',
 'next-iteration/kernel-cached-boolean-terminal-repair/source/ConLeche/Cached/ExprOpsC.lean': 'b9a949607e4b0c6f4f9a717a3d79297a72e904246201f164a8f07f497ef623e3',
 'next-iteration/kernel-cached-boolean-terminal-repair/source/KernelCachedForward.lean': '9106a2d9b63f90a0fdcabe5d2c9e8cf6205d01eefeee11eb666b4b008bc59661',
 'next-iteration/kernel-cached-boolean-terminal-repair/upstream-sdk/Init/Core.lean': '264a0b48fedc91fadf55fc5caac8d91003e3908a6e5e42736e2ac8bf1f7cdf99',
 'next-iteration/kernel-cached-boolean-terminal-repair/upstream-sdk/Init/Data/Bool.lean': '182702f903573fe03983e39b23f2af383692e356ad50463eb7264c0152316c3a',
 'next-iteration/kernel-cached-boolean-terminal-repair/upstream-sdk/Init/SimpLemmas.lean': '0aa122da77386bd084dac91b5921f1cf97a8c99871528d72da6dd6cf0de1074e',
 'next-iteration/kernel-cached-bulk-bound/AUTHOR-REVIEW.md': 'df1e3b6248444186c9004747ccb7c87806a325ed78bb43b10bf0cfff1a60a328',
 'next-iteration/kernel-cached-bulk-bound/PLAN.md': '6ba9db9be5b615b3bc70f3b032b3cf0b5c332447a103c785bfdb65a7824dbed0',
 'next-iteration/kernel-cached-bulk-bound/SLICE-BOUNDARY-CORRECTION.json': '9d5636dabea34d84b99e0c035ff2cd6cf53c33d7bac91236709b0222835dac6a',
 'next-iteration/kernel-cached-bulk-bound/SOURCE-AUDIT.json': '584941f93555a1165a30079084e39b41b0e3562639bb5623a0cc409ecc82e438',
 'next-iteration/kernel-cached-bulk-bound/SOURCE-CORRESPONDENCE.json': 'a6a245aa258ec3fb75879be5ef4a59d47f1ca94d8f73a97d088071a49c70d750',
 'next-iteration/kernel-cached-bulk-bound/SOURCE-INVENTORY.json': '3ec1eb8f5fdcdf5ba2533ce332b8b7bdd740059bd24ca73e30e30b38ea454847',
 'next-iteration/kernel-cached-bulk-bound/SOURCE-REVIEW.md': '56d4daad9e53a46759def8b53299f371b61c0daee7b4295bf386e1f3de8a47c8',
 'next-iteration/kernel-cached-bulk-bound/primary/lean-4.35.0/Init/Data/Nat/Basic.lean': 'e26b5a54eab922f6b650cfe9032fe23172fa8cc0b63c75cff0c8bf99f6175289',
 'next-iteration/kernel-cached-bulk-bound/primary/lean-4.35.0/Init/Data/Nat/MinMax.lean': '8421d0c74512a48937f454d411278900d15aa6dca67d8e7617d6604369194cd2',
 'next-iteration/kernel-cached-bulk-bound/source/KernelCachedBulkBound.lean': '04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666',
 'next-iteration/kernel-cached-bulk-bound/unselected-draft-v1/AUTHOR-REVIEW.md': 'df1e3b6248444186c9004747ccb7c87806a325ed78bb43b10bf0cfff1a60a328',
 'next-iteration/kernel-cached-bulk-bound/unselected-draft-v1/PLAN.md': '6ba9db9be5b615b3bc70f3b032b3cf0b5c332447a103c785bfdb65a7824dbed0',
 'next-iteration/kernel-cached-bulk-bound/unselected-draft-v1/SOURCE-CORRESPONDENCE.json': '841f3298930f9b7fd6bb9d5fc6e53ff9fd39b475eb0286d59599f14f71a18780',
 'next-iteration/kernel-cached-bulk-bound/unselected-draft-v1/source/KernelCachedBulkBound.lean': '97cd5e462f59a443a96a90c3352c5f71e1fdb71fca16af580c9f9f1697669c7f',
 'next-iteration/kernel-cached-complete-120-cost/gate/AUTHORING.md': '9de6176fe79b3cc85e06b1cd9bebc8bf77741c5e0ae8cfc793a78733d3cdfa66',
 'next-iteration/kernel-cached-complete-120-cost/gate/CONTROL-CORRESPONDENCE.json': 'efbcea4dc10788530ee6ec2df7284de85672322ae6c3e872087264e1b8e90d33',
 'next-iteration/kernel-cached-complete-120-cost/gate/INDEPENDENT-CONTROL-REVIEW.md': '568460741d60b04c67e6875c56c1278244ca15848dedec9a01a1262d418ce29a',
 'next-iteration/kernel-cached-complete-120-cost/gate/PROTOCOL.md': '014cb95b03bd3b60b1c87c24237dd4c4f82e4e7d00a9e40a5fdadb0970e75111',
 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-complete-120-cost/gate/attempts/complete-01/report.json': '90af5dd72031f041a5c7a8674ad7f039cc5d59e1f7f3120e3b0172ab9bb3d828',
 'next-iteration/kernel-cached-complete-120-cost/gate/execution-markers/complete-3d9da15cc0ee95db79c64e3a0cae0eaf2974beee79d237b3205e18822666cfe5.json': 'e0ec22c88b955a3cfc432078e43dc60fc434a242c8b65f9f8d23929ec01b7650',
 'next-iteration/kernel-cached-complete-120-cost/gate/run_gate.py': '706acbb38dc5129f2e63f637e6828afc8fa994183a6f6024ad977408346647a2',
 'next-iteration/kernel-cached-complete-120-cost/gate/source-manifest.json': 'd3db0d88fdb63e6cf70c27b81e5d7251223f3f2ecb136d3630ba7cf10c5a5e19',
 'next-iteration/kernel-cached-complete-120/gate/AUTHORING.md': '68e4b7e3acfb07d12cf04793114c3c1278d95906643c1b3c49cba1682df915a1',
 'next-iteration/kernel-cached-complete-120/gate/INDEPENDENT-CONTROL-REVIEW.md': '202aa19627bcea128634fc8a546f283f4f7e865c96827fcb660e2d02079589d4',
 'next-iteration/kernel-cached-complete-120/gate/PROTOCOL.md': '001fc582953bd92aed68e531ca87bc7f76cf7fc95b3258cf808800fe5e175b7e',
 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-complete-120/gate/attempts/complete-01/report.json': '78f26ceecef3ee2345fcae825faf9c3c2c9adc2a102629e475a788443160cc11',
 'next-iteration/kernel-cached-complete-120/gate/execution-markers/complete-785badf526e1aee2f804d1636fd13db0e35e556d5d819c081b3d899910d7f96e.json': 'f4df56cb45dfdf40fa8a85a5125b0aaab772ebfc97728bd021e30f41986efd4c',
 'next-iteration/kernel-cached-complete-120/gate/run_gate.py': 'dca4f133beec0cd8488f063973ea68a316caa17e74e80ea4f0462e582dc29f2f',
 'next-iteration/kernel-cached-complete-120/gate/source-manifest.json': '21e7a9cdb086c9440869c9e9fb0355b2edfd0047e9b4c59312d179c265b91e20',
 'next-iteration/kernel-cached-evaluator-comment-repair/PLAN.md': '9c1c94fc69aae5309a994eb33cb98b1d4bfeacb17071cff46fd73daa835ab7d6',
 'next-iteration/kernel-cached-evaluator-comment-repair/PROOF-CORRECTION.json': '72056b7c85fb9d7f90b63bfde1896a66407094bbed0134dd8fbd99401b601885',
 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-AUDIT.json': 'aa4898305d8d195f2033df240d154ebf47f8b55406db52e6cac5e069727cce9c',
 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-INVENTORY.json': '21d6d5fc094a230f4cebe2efce7ecea8acaa43c898820d6a2cc9314e49039969',
 'next-iteration/kernel-cached-evaluator-comment-repair/SOURCE-REVIEW.md': '532b5ca2695b4dfd8481ef4a60e7e4a8a30ee6455615ee14f878e3a7fb364df5',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/AUTHORING.md': '3532fd26c3bb4d1eae4d2e2f282f5324e1d2a23ef4d7e47524196615e30ff151',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/CONTROL-CORRESPONDENCE.json': '66d2e83aa799719d97f560c90f2e36df7fa9396d75723633c3273bde230d6f9f',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': 'fcb5d0a4fcd9702c55bbf967c928fe7d3009141a13d84ca0df2385b5a7f75349',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/PROTOCOL.md': '9ac747a03365eaebe737a95be2a940f36ea58cc2704365b2edca0060993a1cd0',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/RESULT-AND-NEXT.md': '0ce4a760464826271e9f225aa5a2e65a9434bdfcd6331804ad3bf6e2023924b4',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/SNAPSHOT-RECOVERY.json': '2ee545f04a73afb3ab36c159a10b4928ed9aabf18f6ee890641e5f36077012b4',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': '802d31d4fce3f0a78bb9eb4da559b3c44f94aa291614de6dbc83f35fc476b1ef',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/attempts/complete-01/report.json': '8e9302670e457e8ca31d31d4ebbed41a6a32e6421ad1b8d25abce813c6a18ad1',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/execution-markers/complete-cf693905054730e65c5f5dc7b79c8dd6a2544a459ebd689b3b42b1ceb68f5b94.json': 'eae0d7261d2f8a76647cdb6ec648be096350c2a1d865a5fea5c636943817bf2b',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/run_gate.py': '68b3d9095d0478c1132e732962952ed0641a48e9811001b7a53df99c47ce4671',
 'next-iteration/kernel-cached-evaluator-comment-repair/gate/source-manifest.json': 'b965bc9028f84c5c4098f0a6efdc309230e6f6b677b99a7045871f0f68019bba',
 'next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCachedForward.lean': '126c0ceafb7e354723812c42f1ccff52e73004d80b194e4dcf35796c8073ab2e',
 'next-iteration/kernel-cached-evaluator-comment-repair/source/KernelCompactCore.lean': '5508d7e2c269b922870d65877621b1b0f8df13dc0aa577cdf8c57f95472ee648',
 'next-iteration/kernel-cached-evaluator-slice/ALTERNATIVE-COST-ROUTES.md': '4f88ee6ccbc6dde4381959eee8986bdc61803d5dff69c6c2d4ec784eab559ba9',
 'next-iteration/kernel-cached-evaluator-slice/AUTHOR-REVIEW.md': 'f89a6bff3b4c2d79021d81858b1faff66a3a922f19f1412c45f3ed094243788a',
 'next-iteration/kernel-cached-evaluator-slice/PLAN.md': 'e4fb5feb67b637a3a529a92e18b1f123f2d4a2f754e4902ba5da2040521972d2',
 'next-iteration/kernel-cached-evaluator-slice/SOURCE-AUDIT.json': '8e491b44a84f3b2a84af35a8e07e3297ffb407b8ac573e91269aebad31685383',
 'next-iteration/kernel-cached-evaluator-slice/SOURCE-CENSUS.json': '60cc15b6a20bb35fa22a29c085ce2767c572e31fb218566e7563bb80ab28ba01',
 'next-iteration/kernel-cached-evaluator-slice/SOURCE-INVENTORY.json': 'a1331f78878ff382eefd967faeeb90491725ddc15dcac2ca9daa73685f1cb273',
 'next-iteration/kernel-cached-evaluator-slice/SOURCE-OMISSIONS.json': '3107123cf85d5952e3007f662f71bdd1b6bc93d2f6f5d87a61d195237f162b09',
 'next-iteration/kernel-cached-evaluator-slice/SOURCE-REVIEW.md': '4c51622961d69aab5ce1372df96742e4bc3e0464994a43d17e94953b6e4e7522',
 'next-iteration/kernel-cached-evaluator-slice/gate/AUTHORING.md': '45442bb2a7ce202251884ec5202c4a04c9750454c425f5be903120ad34159014',
 'next-iteration/kernel-cached-evaluator-slice/gate/CONTROL-CORRESPONDENCE.json': 'c7dbd2c8f505be4de17144583b16151b463624605aa794210991d09d765f4a69',
 'next-iteration/kernel-cached-evaluator-slice/gate/INDEPENDENT-CONTROL-REVIEW.md': 'df870b14fbff102228ac20a85959fb7f0615db8b0b63c38b6693ab7f9b9f8475',
 'next-iteration/kernel-cached-evaluator-slice/gate/PROTOCOL.md': '61d0a26f4739e1ee9568dba1505f665ea088a43bf9fa4362a7b05833b94c5282',
 'next-iteration/kernel-cached-evaluator-slice/gate/RESULT-AND-NEXT.md': '387480b043590960fea95b73b6685c1ab785b955bb843ef9493996a2d3fe2781',
 'next-iteration/kernel-cached-evaluator-slice/gate/SNAPSHOT-RECOVERY.json': '61dcb8cb0b9bdcfce52a44e75e164515f66599ef9863b4eba7c93440d7ff0625',
 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/KernelCompactCore.stdout.log': '314dfb02e434e235beaab75ee4d13cd00a9eb64af71fda3ab1060234bd5daf9c',
 'next-iteration/kernel-cached-evaluator-slice/gate/attempts/complete-01/report.json': 'db069a45089d773595ad4b8d43d21143f1f521df64d3d4dc8c1213d80c5b8da1',
 'next-iteration/kernel-cached-evaluator-slice/gate/execution-markers/complete-1c85c909cae953c464dd809848f215281be3e6a727a48191726fa46e02c02a06.json': '90c749c35587991001cc3674a1a459b655f1ac816be81d71e04bbac0099283e6',
 'next-iteration/kernel-cached-evaluator-slice/gate/run_gate.py': '38ae4c7fa21c95c7ea98ee82f90135b07bfbcf8a0908d01b310b29f0915d752f',
 'next-iteration/kernel-cached-evaluator-slice/gate/source-manifest.json': 'fe94740d96a2b75d58af6244ba9ec531935f98ec708227cf485d51f9612e6523',
 'next-iteration/kernel-cached-evaluator-slice/source/KernelCachedForward.lean': '66cb3f9a5b4d50bcc1859414db516288e84f530874babf08f63759630aa182e4',
 'next-iteration/kernel-cached-evaluator-slice/source/KernelCompactCore.lean': '573ab19b394b85f494711e994970e858e0c1bf5171f69c62b49921cf7e3b22ee',
 'next-iteration/kernel-cached-eventual-empty/AUTHOR-REVIEW.md': 'e051cbd119d5c57a313de51f5915dbf817575f7c5886ed0a61b0cbb7cfc8b3be',
 'next-iteration/kernel-cached-eventual-empty/PLAN.md': '6bb2342d9bceb8af59200d553a599b262d3c2417e4f4ccf208058692dbf24c8b',
 'next-iteration/kernel-cached-eventual-empty/PRIMARY-SOURCE-CONTEXT.json': 'f72b38e7ad684db6bd0419a82fc69f2db2adf4eccece73fb4242926a4900ed1b',
 'next-iteration/kernel-cached-eventual-empty/PROOF-DEPENDENCIES.json': 'e96e94b1cbc85980a81370c52a2592c19e6d0406bab5b67daf97f7e5146f7a50',
 'next-iteration/kernel-cached-eventual-empty/SOURCE-AUDIT.json': '86b69bd4a02a988fd59139d745ec2dded165ff536b7b24fb225708cdebd25b52',
 'next-iteration/kernel-cached-eventual-empty/SOURCE-CORRESPONDENCE.json': 'e39ce2fa86b34884781974e4c58d1b3164bf852008e836388ed41c0add4f9548',
 'next-iteration/kernel-cached-eventual-empty/SOURCE-INVENTORY.json': '8b1027e2daac2a1a7f241bb4235897bf026535276af8683b635a30fbd40086d8',
 'next-iteration/kernel-cached-eventual-empty/SOURCE-REVIEW.md': '10ce3651603884c342967b0f1adbad8e02e9f4182d131c8fdb26e75588f3853f',
 'next-iteration/kernel-cached-eventual-empty/source/KernelCachedEventualAtoms.lean': '6feb84ae704bb4af4d4e5f201b8756ded29bd8f5c42a6337cc67a9243f593bf1',
 'next-iteration/kernel-cached-eventual-empty/source/KernelCachedEventualEmpty.lean': '014129760a2a3be76a8f26c80c1dca1529712ab4cdf45b85d08f044e1addad16',
 'next-iteration/kernel-cached-eventual-foundation/ASSEMBLE-SOURCE.py': 'f74e2fc0a2408101bf0e1d2205e70d0334670a3a7c0e025159536cbc90150829',
 'next-iteration/kernel-cached-eventual-foundation/INGREDIENT-REVIEW-SCOPES.json': '728ba6f9e8304caa12479e0f7a7537c1accc0e91785dd4b1c92416fc79c7c890',
 'next-iteration/kernel-cached-eventual-foundation/PLAN.md': '904d48e56ce43bd888ce248c111e4edc284b758f0c187c6c097900ebffb215ca',
 'next-iteration/kernel-cached-eventual-foundation/PRIVATE-AND-SCOPE-AUDIT.json': '6da2e15ca445ec00da8b49a5c551ffdeb5a4f3ce5093e6f425ff51e090969c80',
 'next-iteration/kernel-cached-eventual-foundation/REVIEW-STATIC-CHECK.py': '568ba41f18b26ef8e3185998bd270a8c00269f73ee4cf40070cfe59dd3a32d2d',
 'next-iteration/kernel-cached-eventual-foundation/REVIEW-STATIC-RESULT.json': '636219f266b9b26ed9236df7eb193776d5831b1b285b88c2ff2f02b78d9b42be',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-AUDIT.json': '29b0993edbc47b091d6ea0b3080765dce6425967081443c8c3ec0716d69cd6dc',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-CENSUS.json': 'cea26fccb60d3d3f9216b5b64a2186c7e18e3a2e3021c96c9a45ec7b20b4f599',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-CORRESPONDENCE.json': '8ecf5ba4328efdae2b24518315cc10c3891e6708dfd3e097a0b5a7c1702f1cc9',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-INVENTORY.json': '19d3419d750c772a9205f86297ceb68e62be0ed8b43f9eb668a0d742782ecbe0',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-REVIEW.md': 'dd3576309e2fc6585f42d13fa1dbb6f62b11b5818a0cc106c6e09bbabef20401',
 'next-iteration/kernel-cached-eventual-foundation/gate/AUTHOR-CONTROLS.py': '2f3e8f03081a5c12d1bb502d18b49110e82f349952681c00ddd0634317fd1139',
 'next-iteration/kernel-cached-eventual-foundation/gate/AUTHORING.md': 'e40b0b9d3767ad04bf887893ea9cc495546994f8c42d65f52ae9762b4cae8a65',
 'next-iteration/kernel-cached-eventual-foundation/gate/CONTROL-CORRESPONDENCE.json': 'f56e91939ccf1fb382b5a43170ccf4956cf5d98ef64166c115cde41564855918',
 'next-iteration/kernel-cached-eventual-foundation/gate/INDEPENDENT-CONTROL-REVIEW.md': 'f798c0662bc47ceb0b7295a24521d30c8439ec699473b9efead6ab2109988aad',
 'next-iteration/kernel-cached-eventual-foundation/gate/PROTOCOL.md': 'ec62eff2cefa8874236d794ad600eb85d1bf896c4f25cbe09998389925f5adc8',
 'next-iteration/kernel-cached-eventual-foundation/gate/RESULT-AND-NEXT.md': '43c794ac1296b570f12a8ea2160ed96188df2a17196932255fab918f009c608f',
 'next-iteration/kernel-cached-eventual-foundation/gate/ROOT-EXECUTION-RECEIPT.json': 'df50b0dd3da80e6712d309a77a20ee0f50a89cabf2ba691a332bb8beafd62d83',
 'next-iteration/kernel-cached-eventual-foundation/gate/SNAPSHOT-RECOVERY.json': '25244cfd2c8a6bf13fd71af7646bfe04da94114b5065c65854cf0845b2c7f7af',
 'next-iteration/kernel-cached-eventual-foundation/gate/STATIC-INDEPENDENT-CONTROL-AUDIT.json': '684a3d2b8bcf61f6a33e2a13b3236b39ed28332124c4ab2699dfd54f463fe5a3',
 'next-iteration/kernel-cached-eventual-foundation/gate/attempts/complete-01/report.json': 'b56173fec0f9d10dd0902c348ee71b23f911ed889e9389ddd5de3722d962d822',
 'next-iteration/kernel-cached-eventual-foundation/gate/execution-markers/complete-c66c83974aaa9b0b059fc2b136a81a711964933c6d4e939752df41395890f9ce.json': '9e49c1609e6b7176480595b885b6a4b25e45032ab78d52ae001957b459f9a5a7',
 'next-iteration/kernel-cached-eventual-foundation/gate/run_gate.py': '9c1178c0bfc029991f736e46210c57936d4f763f716bbc535f3ccb4b5da76244',
 'next-iteration/kernel-cached-eventual-foundation/gate/source-manifest.json': '11dbcea246364c9951cd1255225c6846936ac3b174610a62fcec16d21df9d12e',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/AUTHOR-CONTROLS.py': '9fc3c6511cce777a1d836b2ed2d462e3844271c6ab1013dcae5286b03b14ab26',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/AUTHORING.md': 'e40b0b9d3767ad04bf887893ea9cc495546994f8c42d65f52ae9762b4cae8a65',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/CONTROL-CORRESPONDENCE.json': 'a5c9761b37bce3698c0f6d1f4495dc37a06fc42fca22f62835c4caad65e3dafb',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/PROTOCOL.md': 'ec62eff2cefa8874236d794ad600eb85d1bf896c4f25cbe09998389925f5adc8',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/RECOVERY.json': '6ccebf530a463ae421bf6fc4c9cf26ba5434aec94ea34281063a0f1bb11775b1',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/run_gate.py': '747ae669742a37d758c7b4ac1f7812a431050de6d2ece7cefb8d4b0d008e6cf4',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/source-manifest.json': '387ecc9004f4ddf10103e97c9e6d32613d8c0e8d9f91d856e22cb1a6be94c77d',
 'next-iteration/kernel-cached-eventual-foundation/source/KernelCachedEventualFoundation.lean': 'b88b25aa807de203419c1d50b860b08950f44de8e5bf03172a91e132c162ccd5',
 'next-iteration/kernel-cached-eventual-helpers/AUTHOR-REVIEW.md': '740646f807fa151b9765a83310a95731e6639e1949dd64c9ef75f0ecd5ae0ea9',
 'next-iteration/kernel-cached-eventual-helpers/PLAN.md': 'f026384f793a4a50db5f5a6db6a407372674c1ba1bbd40a1603958f667927a19',
 'next-iteration/kernel-cached-eventual-helpers/PRIMARY-SOURCE-CONTEXT.json': '0831d99eb778fd7596343976e38bd8b89489f28b52828d36cc7c22af31507de8',
 'next-iteration/kernel-cached-eventual-helpers/PROOF-DEPENDENCIES.json': 'cbd2e1757ecfa00424b1a5ab4806b594ce063630ef80cee54b24a37274b456b7',
 'next-iteration/kernel-cached-eventual-helpers/SOURCE-AUDIT.json': '92d251f51a3a3b45115a14925728766fecd5d2f31945f51e255cc5db986fad9b',
 'next-iteration/kernel-cached-eventual-helpers/SOURCE-CORRESPONDENCE.json': '34d393563c2997fff9161718ddbb8d4456491ba99d56b4a0984896089370f72b',
 'next-iteration/kernel-cached-eventual-helpers/SOURCE-INVENTORY.json': '30e5a79ac538cf06908a02fca75b528d0f157294626ddd69fe3969cb58b70907',
 'next-iteration/kernel-cached-eventual-helpers/SOURCE-REVIEW.md': '0b895796eb931670578e56d9ca9147b10d5ce7bbf66eca5fc1a2db949731dcc6',
 'next-iteration/kernel-cached-eventual-helpers/authoring/assemble-contract.py.txt': '9b43077dcf8fca50f7cdadd05d63f9e54d6fab0e7c2d1dbb492f4656b6d2398b',
 'next-iteration/kernel-cached-eventual-helpers/authoring/freeze-source-metadata.py.txt': '95a989d474e292b58809e319301566de239e0df68effea2ec344216004c88d08',
 'next-iteration/kernel-cached-eventual-helpers/source/KernelCachedEventualHelpers.lean': '066d4c57e76e1f6567ee85598baf5d63a4ed48c0028d5f6fc5ca38938a05bd3f',
 'next-iteration/kernel-cached-eventual-helpers/source/KernelCachedHelperContract.lean': 'c9c70d0f1e36b8ae1bf35fa566e4659f9d139f170234fbbd46f2e2c8e47fb727',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/AUTHOR-ASSEMBLY.py': 'b5eae00b0f7edb67d0dde39910a93009c8301003b0780c7337c03ca238cdc804',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/AUTHOR-REVIEW.md': '5e6507754d52106d16eda0a22b869dfdef5282373b03a8784e4d500680c59970',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/HISTORICAL-REVIEW-SCOPES.json': 'd5e77e9898f7858032b123db5fe1e04e1bcb7f86b455530eb8c5003fb3418597',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/INDEPENDENT-STATIC-CHECK.json': 'ffe92918740a9e9fba74ab98085e76bd92afecc4f90cd2982030043a281e9c3e',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/INDEPENDENT-STATIC-CHECK.py': 'a0b7122be328a664fafcbbb465a1229fae82236ee2757ba1a75327d7dac3b7ae',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/PLAN.md': '13f686d2f99bd839ee1d0298b8c6fef12071cc6920d643c1781c1da6ccb1bf7c',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/PRIOR-ACCEPTANCE-CONTEXT.json': '6b127661938a63a1d8b391673785fd5e57e1b1fd224f5e626a418f91dc6f6c8c',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/PRIVATE-AND-SCOPE-AUDIT.json': 'bce8e88053ef0e0aaebb6b89000d50bbb1e20e5bf76ab301165335cf6e69ffd0',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SDK-NAME-RESOLUTION-CONTEXT.json': 'de8e92ef31776ba25c3ea146d0e130536cb5cd7f96659b6831d988caff463b85',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-AUDIT.json': '2534bb336c8ff10350713683c6989cd32351d86a894a575c52f609e579747683',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-CENSUS.json': '894ed67893a675047ace3a3813e5c2bd41b72577c435c9c8561da5b8d701676f',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-CORRESPONDENCE.json': '45dc10b6987a5f8d5aa26a6cc9a9fb4e03bdc5a61554b292d20ed108cb3cd01d',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-INVENTORY.json': '919875e7082ba0154336f972a3595273df7e18321d922e37925eab98253c78fb',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/SOURCE-REVIEW.md': 'f68791f5cd118f758743ef629c50cef2c25df105a35f71db291c60796656ee20',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate/AUTHOR-CONTROLS.py': '5114030b8f5320596a0884aea629b75c0b5c03b1c75b2b06c1f747f30199ae34',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate/AUTHORING.md': '296ee098ded8040b2472da182e156f1cd1bed4dbd6b315f03145172c5881bfd3',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate/PROTOCOL.md': '56e8489c41ed6ff879b008b18ffb159b0215ac471bb0ee88ab5fff0a58b0786c',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate/runner-main.py.txt': '90ff5f10658805ddb326872f154c0c63c7a0460e202b22846309e59204433c10',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/gate/runner-metadata.py.txt': '7759f1e2e13590de3fc9b2e9159db009750b693fe1cb6acb796a87f6ff77c892',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/sdk/Lean/PrivateName.lean': '21569296df3d69ca3f48dd109ed875c040509f9f693419e44cea9fa130b08179',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/sdk/Lean/ResolveName.lean': '29568f90bc8c5b713b7462096b94e898f30d0eca21119ae9abac695604615d13',
 'next-iteration/kernel-cached-eventual-interpreter-assembly/source/KernelCachedEventualInterpreter.lean': '9c60b1c565372d266a15c7bc40e2f59e3a5cbded8b0f97cc497934546abc949a',
 'next-iteration/kernel-cached-eventual-owner-slice/AUTHOR-REVIEW.md': '4a8e62aea71906d680f59218025143664cc1bcb2afa11eb8157431663095c959',
 'next-iteration/kernel-cached-eventual-owner-slice/CONSUMER-CENSUS.json': 'b7b5a4718ae157897d123b788ac06384e15a70b4eb6aad007b6e6922a4d667c4',
 'next-iteration/kernel-cached-eventual-owner-slice/DECLARATION-SCOPE.json': '0ef8ff0d9d59234cf7debb043427bc551d45710c7afe45e8b305091a04545490',
 'next-iteration/kernel-cached-eventual-owner-slice/EXTERNAL-CONTEXT-RECOVERY.json': 'd32fd0960dd4366836d3fdc3f91b1485f33cbec4dea8c5ef046e700c53311084',
 'next-iteration/kernel-cached-eventual-owner-slice/HISTORICAL-CONTEXT.json': '4acaabba171fcc4d3c654760cf4c36d8038418005fb591ce3bc3f667a1ecd0b2',
 'next-iteration/kernel-cached-eventual-owner-slice/PLAN.md': '840f0b7b736fb5fea621b0d93d60f27c94ad499718cc228918b74bfd3b5819fa',
 'next-iteration/kernel-cached-eventual-owner-slice/PRIMARY-SOURCE-INTERVALS.json': 'b2a0b02875bec97576354bd462df97814c67372df304155cb9ab3e527ac4d60b',
 'next-iteration/kernel-cached-eventual-owner-slice/REVIEW-DIRECT-INPUTS.json': '0d93a0295878e23b724ded1694fbfdbe4a2ac7d0ba6c8dc18def0029ad3b96d2',
 'next-iteration/kernel-cached-eventual-owner-slice/REVIEW-STATIC-CHECK.py': 'ddcfbf064109f8dea08b69c9b3498af5a5528a156b5e5fb63a8e0775bcf15cde',
 'next-iteration/kernel-cached-eventual-owner-slice/REVIEW-STATIC-RESULT.json': 'e6007a23642f7d3c2c26d154b5309a80b0b027d8b305371e69035382906366f5',
 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-AUDIT.json': '38377da414622a5d3af6d6edc8afb1aba5e2e6145dd8c33fbb052eabb607a5af',
 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-CENSUS.json': 'bd2f4e58cbcd2a42d7a034f110482dc70e6c1b3b9c43e1c98d553595dad32f5d',
 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-CORRESPONDENCE.json': '9564a5bfef7710dfaacc78e23c85282ce261dc6f00ea02e872af1cd5dd6ce187',
 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-INVENTORY.json': '773ab923a8fc0cb9ac61f44af3efff68152729207b75e4e3a123c92a36d57e3f',
 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-REVIEW.md': '24e9e9cf0da4a22857aa0bff3c55ce8d900fa09389fe87bd4f7d39e43a9f9d2b',
 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Init/Data/BEq.lean': '7c60c30768d646020cc4e4e504e5f234ed717afa70637cd1c0e0e1053741e442',
 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Init/Data/LawfulHashable.lean': '14a5635bf79ab8693d34e2c9dc8166f1ec37de9e5996cab1b03c88ed41d47d19',
 'next-iteration/kernel-cached-eventual-owner-slice/sdk/Std/Data/HashMap/Lemmas.lean': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882',
 'next-iteration/kernel-cached-eventual-owner-slice/source/KernelCachedForward.lean': '323da5194486ccf72b8732869415b6d27a9ff2c0dc57406c17c1cd83ef742804',
 'next-iteration/kernel-cached-eventual-owner-slice/source/KernelCompactCore.lean': '6aacedb54c0facfe362112a156c2e3a877b83ccca043d55f8e22f99cd4404447',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/ExprNodes.lean': '0260b877f8dd17cbd3b6b9786d2f8465abc6c3958704533dc7022133b9b31c97',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/ExprOpsC.lean': 'fbebab6fbe1d856a7b950db763f9ab0a16930ae1069658b7493117f71fd14740',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/BasisGen.lean': '95aaa106e2e124cac6fd1e7b8f1320c3f4f31eabaee83f72e8a869b94bb7453b',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/CheckerBase.lean': '1a21f7d385ffe94589f1078f4e36ff18643cb36c9650cf7b920e209be1ffc36a',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/Core.lean': 'f198f10b3fe5c3bc98e23aef65e6f0d02ad3027f077fd2191b4752e0f50ec886',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/FEnv.lean': 'ae7229dd68a736d026d3025572fc30d852bf5028b3d115f2604007589f956040',
 'next-iteration/kernel-cached-eventual-owner-slice/upstream/ConLeche/Kernel/TypeChecker.lean': '5af4102c6ae2fc195d866b20d9d5e48d360a6724470153c25dbd502e648d087f',
 'next-iteration/kernel-cached-eventual-pilot/gate/AUTHORING.md': '787304ee6584f081e0f85b9aa4a3f0437c71efaea20e183b1c736525ea08cc6b',
 'next-iteration/kernel-cached-eventual-pilot/gate/CONTROL-CORRESPONDENCE.json': 'a79b5fd6ad8849b8c2648dd6f2a9ead48d6963e39f3914fba1026113aabadcaf',
 'next-iteration/kernel-cached-eventual-pilot/gate/INDEPENDENT-CONTROL-REVIEW.md': '09027773d8d569626ed8e19ac309dfa284685d6da5f4f8bba2c15173eef62eac',
 'next-iteration/kernel-cached-eventual-pilot/gate/PROTOCOL.md': 'f83f00edd0197dddd9c5b00b563f2c4c46ecdfa5b4403255814124a20e4289ce',
 'next-iteration/kernel-cached-eventual-pilot/gate/RESULT-AND-NEXT.md': '47149f53608c2390844f3256a6a0a41279f53c0ab4171de40b8366e7482239d4',
 'next-iteration/kernel-cached-eventual-pilot/gate/ROOT-EXECUTION-RECEIPT.json': 'fdcd9951941059bb1919a62a4e7593be372e13c31bcfa28b9ab6dae2dc14b83f',
 'next-iteration/kernel-cached-eventual-pilot/gate/SNAPSHOT-RECOVERY.json': '42f88147908ce11bc64782fdf0c3c0467334954d9c312d5cce3923ec01e99404',
 'next-iteration/kernel-cached-eventual-pilot/gate/STATIC-INDEPENDENT-CONTROL-AUDIT.json': '4c22ccce74e9b9b6135ea700e032eb07541e0c4b7966ebaa198a01813a93256f',
 'next-iteration/kernel-cached-eventual-pilot/gate/STATIC-INDEPENDENT-CONTROL-CHECK.py': '69246849515de90d59542083f7d65e37bde86d027b0d48d70b2bccc998d24971',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualAtoms.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualAtoms.stdout.log': 'ee2d677409857f6574019bbf1c19f1ccd90f789c2cda360665c31c438236e2bc',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualEmpty.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualEmpty.stdout.log': '190c62a01bba14df8060c50a1df7e546a1e76679ef5d9178b26ecc919163244b',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedForward.stdout.log': 'cd390502717d4b03e7e5206bc9deb9c8f4b2e8babed4efebe60b78ac22e638b7',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedMemoRelation.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedMemoRelation.stdout.log': '461c9706b809a418eb850597d8f7dc3daf4ccb2ad4e9950d2bff9a1f993a3330',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/report.json': 'e858925d7e508eee3203b6a3704bb5e0f71113709b3532d5c38d21a371765197',
 'next-iteration/kernel-cached-eventual-pilot/gate/execution-markers/complete-492bf86674732afb57fd0844d3da8d9f236ddecf2168ad137fa458f232bcdeaf.json': '23e881c5a6f776add894ebda50960efad07c5964685e6c5c8bd0db11c1f734a5',
 'next-iteration/kernel-cached-eventual-pilot/gate/run_gate.py': '82a929203be2bc4f4361c4c620b2eaa970962aaf2fa021c2e0bbdf8998c49692',
 'next-iteration/kernel-cached-eventual-pilot/gate/source-manifest.json': '54180080c39f17e420e7c23367cfc5723df027a902cb1a5a046763345bac4e5a',
 'next-iteration/kernel-cached-eventual-query-bridge/PLAN.md': 'd71534d42a2f86d92e94908c594129b349277ff63f7db26c55cc1b554268a27c',
 'next-iteration/kernel-cached-eventual-query-bridge/PRIMARY-SOURCE-CONTEXT.json': '0150e2df58d4ba1189bf880b25637e2f291b410e2f06e550a60b236c234879fb',
 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-AUDIT.json': '15a2dfc269b3d4df21be10af8b14dc9c7711dee72794fd513669f0244023f16f',
 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-INVENTORY.json': '78cdd25d8054b11e52c72bccc0a40a1be9c4fbbd3013057bc160afd25ef71ce8',
 'next-iteration/kernel-cached-eventual-query-bridge/SOURCE-REVIEW.md': 'abffa4302e84ba75874c040eda3234fba0f143fa2b0b91e013cb87a863e85172',
 'next-iteration/kernel-cached-eventual-query-bridge/freeze-source-metadata.py.txt': 'a3e3b025d999648905444701e1754821ce9c22f49cbea1f247834d188158e7d4',
 'next-iteration/kernel-cached-eventual-query-bridge/source/KernelCachedEventualQueryBridge.lean': '3c8a381c992edb45aa24ccdf90fb529962f98286bc5a92dba18f540196f2cf27',
 'next-iteration/kernel-cached-eventual-record-wrapper/AUTHOR-REVIEW.md': 'a605c72a477d40f2bf2327d78afb366c6ea110f7438216347b9ffacda93a0f96',
 'next-iteration/kernel-cached-eventual-record-wrapper/DRAFT-STATUS.md': '3e00f3abf6cee8542077062dd41fc2d8edd03ad37198ddcead1d1c76b5304773',
 'next-iteration/kernel-cached-eventual-record-wrapper/HISTORICAL-CONTEXT.json': '2affb0e7c778327236b105e6bc319745d039c5e412633e3ccfc7fc9395f2412b',
 'next-iteration/kernel-cached-eventual-record-wrapper/PLAN.md': 'd3173f705a705d8df07681935e4418580cd1f3bebe3e847dc3dba8b9ed764d32',
 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-AUDIT.json': '4dbd8c84513d459ca43d889675ea53ef23097968411c8e10e9c569ecf90e6d25',
 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-CORRESPONDENCE.json': '57769a5606a1264965ed7cd613144c43d6197a82edd456960f5b3b6796c389c9',
 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-INVENTORY.json': 'bfe1947c0d6880ecc4d9c31cc9be02ce0c7f571a495caa8dedc7fdd5a2e46db1',
 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-REVIEW.md': 'f20120dffee8671c5002842092af375a320ecbacf13c9f041f71467c589d4609',
 'next-iteration/kernel-cached-eventual-record-wrapper/source/KernelCachedEventualRecordWrapper.lean': '015c44c716347e9b63f1ebaa044c25803ca8627603dc36c14e0395674b19cc47',
 'next-iteration/kernel-cached-eventual-trace/AUTHOR-REVIEW.md': '3949beac8efc1f0d11bbff6ab7267818eaf5e28b930d8d4b71e6c8aab4642358',
 'next-iteration/kernel-cached-eventual-trace/OPERATIONAL-SOURCE-CORRESPONDENCE.json': '4954cc7ca511a65c880d522d3fc66e3c18416559702926767c8039d0d748d1f2',
 'next-iteration/kernel-cached-eventual-trace/PLAN.md': '66a2ac76ee469f852050a41b483d68423ddaf9cfed20c7fb8df69d983c288e2c',
 'next-iteration/kernel-cached-eventual-trace/PRIMARY-SOURCE-CONTEXT.json': '154e41f646faa5b7bb30f282af0064f88b0f36ece790a398c3a39b321e451f12',
 'next-iteration/kernel-cached-eventual-trace/PROOF-DEPENDENCIES.json': 'ba578cba3112c72a98f21c68be2a91dea0f20147d12afeb10b729d6c0533f683',
 'next-iteration/kernel-cached-eventual-trace/PROSPECTIVE-SOURCE-CLOSURE.json': 'c90227904369b8539cccf76a13605d0e07b85df053c81398abb21486dc0487d4',
 'next-iteration/kernel-cached-eventual-trace/SOURCE-AUDIT.json': '65c781fd6c621dd338f7a3a25c490ffc15820732ad7dbf916f61157e1c25e02e',
 'next-iteration/kernel-cached-eventual-trace/SOURCE-INVENTORY.json': 'aa79104beb4a6265e68f401768f4014726ce46595e8035b210368ed148a264b5',
 'next-iteration/kernel-cached-eventual-trace/SOURCE-REVIEW.md': '72fb998a62dd7caab1c78026510f39feb3e35b888952a6bc0c09d118fc33b4d5',
 'next-iteration/kernel-cached-eventual-trace/STEPS-SOURCE-CORRESPONDENCE.json': 'fac9de1ea5e5dcd1314c6db1b6a6ef878d63d36ad1b4db89cd336b568e37a203',
 'next-iteration/kernel-cached-eventual-trace/TRACE-SOURCE-CORRESPONDENCE.json': '1afafe34c03015c41ba71d98f27a3377be84956c916f58e5ebfcdad8861ed5a0',
 'next-iteration/kernel-cached-eventual-trace/authoring/assemble-eventual-steps.py.txt': '6c577127379ff45445de2e2c3ebb8d1b2200d512c75c85c44984f72dcf08531c',
 'next-iteration/kernel-cached-eventual-trace/authoring/assemble-eventual-trace.py.txt': '2aa588090c34195c52a25a59a5cbda56fa980776998fa7258c8c53feeac384c1',
 'next-iteration/kernel-cached-eventual-trace/authoring/extract-operational-contracts.py.txt': 'e5fc1663c4cdb83e90b6982fbe0950afdf6b1d0672b32d201b7ef85892532327',
 'next-iteration/kernel-cached-eventual-trace/authoring/freeze-source-metadata.py.txt': '59239340e710691f682aadeabdee65a26fe80b83047b105538e33ddc3d7744a5',
 'next-iteration/kernel-cached-eventual-trace/authoring/steps-prefix.lean.txt': 'fbcb0ac06ed5200819baa8874235af67506ec8f87fe2e1ad5f2e3f27407b04ef',
 'next-iteration/kernel-cached-eventual-trace/authoring/trace-footer.lean.txt': '4e363c469cf45a2140aab45965322bd8af7c51d4a53440a4bd06f636cf4f2a51',
 'next-iteration/kernel-cached-eventual-trace/authoring/trace-interpreter-prefix.lean.txt': '3427461f9351f13dc71982b2ca61f127bff034c42cb08b1774f3629c79826cb0',
 'next-iteration/kernel-cached-eventual-trace/authoring/trace-prefix.lean.txt': '0a02568fe46bff41d9aab1d5c93398128fe6ea959feb5008ce132355e95aa4e0',
 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedEventualSteps.lean': 'c9dd32403173d0ade2bcaedbf40e0b2b85e03b6b1dd2d306d1c548cd06e47930',
 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedEventualTrace.lean': '6ee8fcc263ec3feb779ae8fb217ca6a278793ff81593da43d0abbfc50e735107',
 'next-iteration/kernel-cached-eventual-trace/source/KernelCachedOperationalContracts.lean': '1d1599494d88cb0e1c26c260b71996000d860fb9a2491cd98439166e665c1bdf',
 'next-iteration/kernel-cached-forward-interface/AUTHOR-REVIEW.md': '83d53f56dac46af7899e2292d9f23c227c83ba0e07d6dee5aac8a45af0f20e2c',
 'next-iteration/kernel-cached-forward-interface/PLAN.md': '3b2d77cded55bba104a14af4061efa00de87cfe550f817cc7d1ecc6dc1a9df4e',
 'next-iteration/kernel-cached-forward-interface/PRIMARY-SOURCE-INTERVALS.json': 'e801a92dff1005268c193f1fca286eeae6545c40eace2b78b6971f0263fd537d',
 'next-iteration/kernel-cached-forward-interface/RESTRICTED-TRANSFER.md': 'a68ffd7c18988bfd0d14f7f714a56cf9a106d14a78284990c72d7b1267c489ae',
 'next-iteration/kernel-cached-forward-interface/SOURCE-AUDIT.json': 'e2e3c22892a3259f4cd243b852f49559c8db2452081ed207776dc976b720418d',
 'next-iteration/kernel-cached-forward-interface/SOURCE-INVENTORY.json': '3e94e0b283cc17e4c64fad3fbd630c2097bdd12a2fb4f34108475190137da0d2',
 'next-iteration/kernel-cached-forward-interface/SOURCE-REVIEW.md': '81cdbd4ad1565e08e1d74a27d363e75ea58c4333c4466ab62e4e988b327c2b4e',
 'next-iteration/kernel-cached-forward-interface/source/KernelCachedForwardInterface.lean': '7d5d8ab73e3074e2dc61d70c5a251417fac2529798bc3b6067be3868f4d26979',
 'next-iteration/kernel-cached-forward-interface/upstream/ConLeche/Verify/BetaSpine.lean': 'd6d605f5ed900bbc20b414ca2975f4b334279c65020e3dfc64dd9cf20cf8e006',
 'next-iteration/kernel-cached-forward-interface/upstream/ConLeche/Verify/Cached/SimC.lean': '901f3c0f3b5bc165489c97561a39c27082f8a5276d69ae6443485280f58fcba5',
 'next-iteration/kernel-cached-forward-proof-corrections/PROOF-CORRECTION.json': '921c4a15b9e77b5d00df0a0d27a63496f511873ddafa4073191a9f93f2359c4b',
 'next-iteration/kernel-cached-forward-proof-corrections/SOURCE-AUDIT.json': '5d664f252cb76f0634a5091bbda4f494b2787f725de1df119684beed55354223',
 'next-iteration/kernel-cached-forward-proof-corrections/SOURCE-REVIEW.md': 'd26809c70fc75505585cf5b934ebbd7939b4b7f045a6178b34165916c0909ed8',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/AUTHORING.md': 'cb5bbfd095a9495b92c4b22f0da04a6d8bc9230b2e200b54e46132422ffac350',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/INDEPENDENT-CONTROL-REVIEW.md': 'eabc7f423fbf0e5fdee8672cce932570204e0818f589dcac7a5233f1188c8105',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/PROTOCOL.md': '739e4099a028ced3824a8d8ab821e5e185fd48854615a00a54b590c9c703a33f',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': 'bc351fa3f54c8aa7c996579155fd6ff2ea5a3a112b61ca177dd6e7c5d88b558f',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/attempts/complete-01/report.json': 'd7e269afdc22c70839388fe183a31b74a58804a4f45c4e68a56df47972dcf2c5',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/execution-markers/complete-d8139671ab0d14335fb13e6abaf0d7e154925fd6e550530d9d4dbf0d3667065f.json': 'd9d64aa08965dc85622273c457719cbc81678f9ece2b28f1773e878dcace6726',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/run_gate.py': '4ec4adc12e3272bddc67f533b9e627149c5aceedcaa1d5e27344b1c3ac6dc305',
 'next-iteration/kernel-cached-forward-proof-corrections/gate/source-manifest.json': '5233b82332496ec0afc2ed0ca1f723bfc5b0d33368356c2e6b08811dc5251e03',
 'next-iteration/kernel-cached-forward-proof-corrections/source/CachedForwardLicensed.lean': '33490f91e3b459362093c9ae60b6fea43695b07fa6bbd4fe125303040168ecad',
 'next-iteration/kernel-cached-forward-proof-corrections/source/CachedForwardRuns.lean': 'f09763ebaa40e91d170bd86c0eef846caae123f34312cbf6b4317368553325bb',
 'next-iteration/kernel-cached-forward-proof-corrections/source/KernelCachedForward.lean': '839e7a7bc891f01ac6c6b7bb5f5cbe370ff0966b312284672ebe6423fcc7b3a4',
 'next-iteration/kernel-cached-forward-proof-sharing/AUTHOR-REVIEW.md': 'c8879bfe32ce1611ee2a7b05456aaad121d0a67547fa6b77a3ee0fe558a2d3fe',
 'next-iteration/kernel-cached-forward-proof-sharing/PLAN.md': '38b38f6f964895eafd1a1f39984f731822bdb8178f779ad8139ca17cdeae2176',
 'next-iteration/kernel-cached-forward-proof-sharing/PROOF-OVERLAY.json': 'afb29fcbc1e31ae87c8d4e203c6930f49786754c5d7b0128fe4d269df681f589',
 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-AUDIT.json': 'a473f95514dac7fcc6fbfa3fb18702d22c7d3073527024a6079b523e0c635cd7',
 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-CORRESPONDENCE.json': 'e9888035205452549c7080acef2b75a9fed00aed7d822eb1941549347fffec9b',
 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-INVENTORY.json': '7e03b38816335ecbc8685e84ddcd58b6e908ba267fbedcf660b03a4cf174262a',
 'next-iteration/kernel-cached-forward-proof-sharing/SOURCE-REVIEW.md': 'c70c25643de2f329e95248b425e57a2db89eca30c033fef2e363cfb2bbdf5a54',
 'next-iteration/kernel-cached-forward-proof-sharing/source/ConLeche/Cached/ExprOpsC.lean': '1cca5e7d97edb9e86aceaaddabd7d839ebd13f549fac5128c41066c1c2adbad8',
 'next-iteration/kernel-cached-forward-proof-sharing/source/KernelCachedForward.lean': 'f55d286c9df4cb31f12e9148bcc7b82bf0737c180709eaa585f2ea6062585041',
 'next-iteration/kernel-cached-forward-work/DEPENDENCY-PLAN.json': 'a8de42c187b7bb4cb903f48f592bfa4c9aa0eccbaad245bcca8d9bc3518d2e67',
 'next-iteration/kernel-cached-forward-work/PLAN.md': '0bdc6cc294e1176c95be3af4fabf71322b1dc86620db4acf52854846d25791f0',
 'next-iteration/kernel-cached-forward-work/SOURCE-PROVENANCE.json': '5b36c0bd6926fa420ba14637b45d9d411752f10634477b5c125b8814c29c1556',
 'next-iteration/kernel-cached-forward-work/bundled/PLAN.md': '419dc3ec960ebbd09fb5207f667040037e01169297d75c264cea060cfaa52424',
 'next-iteration/kernel-cached-forward-work/bundled/SOURCE-AUDIT.json': 'a837f17f55ea29041e6012092c06ede8c9928b1cff4638f9eb92519a8add2139',
 'next-iteration/kernel-cached-forward-work/bundled/SOURCE-CORRESPONDENCE.json': '264fd7e7cef66082b8f116c6b3e8eb511363bc68f22384c6c715b89fdd4b328f',
 'next-iteration/kernel-cached-forward-work/bundled/SOURCE-INVENTORY.json': 'c001e9b25724b572a6c8ae48c605276fc791c33665a97afb148b39b533c92f5e',
 'next-iteration/kernel-cached-forward-work/bundled/SOURCE-REVIEW.md': 'd61dd5c508517aedf291a06ac0d85b68e46369474ddac0b863640286c2c17b7e',
 'next-iteration/kernel-cached-forward-work/bundled/source/KernelCachedForward.lean': '332728019b39a656f1608815d3d38b3d71d623d38c5bd883bb98458d615a8a5a',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Cached/ExprNodes.lean': '0260b877f8dd17cbd3b6b9786d2f8465abc6c3958704533dc7022133b9b31c97',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Cached/ExprOpsC.lean': 'fbebab6fbe1d856a7b950db763f9ab0a16930ae1069658b7493117f71fd14740',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Kernel/Expr.lean': '0c1d4afe69c951a1d0e883433e289b41cc646305a476bd2e9349363fa3672a37',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-forward-work/bundled/upstream/ConLeche/Kernel/FEnv.lean': 'ae7229dd68a736d026d3025572fc30d852bf5028b3d115f2604007589f956040',
 'next-iteration/kernel-cached-forward-work/gate/AUTHORING.md': 'fe30cd6c021eefd3a31c4777dc5db015a5a4fa682f83dfda9c0f3487994f42a5',
 'next-iteration/kernel-cached-forward-work/gate/INDEPENDENT-CONTROL-REVIEW.md': '8ef7b714ffe582a78de5799121541d59abd8e2baa76dfbe000e48e016782d480',
 'next-iteration/kernel-cached-forward-work/gate/PROTOCOL.md': '69cc2305a443abb07aca98b0c8ac132da1fa2d9fdf3f1b20f3e0699ed201b26c',
 'next-iteration/kernel-cached-forward-work/gate/attempts/complete-01/KernelCachedForward.stdout.log': '22c971e6fb05c396d70d12395fc38096e23d21a94308c9e01e4b479dc1d7784d',
 'next-iteration/kernel-cached-forward-work/gate/attempts/complete-01/report.json': '65437a2c4e9b896ecc5243a004c60493ece72e5d1ab9880c3c17c68470911fff',
 'next-iteration/kernel-cached-forward-work/gate/execution-markers/complete-35826d09ded58c24f5aac57e28d50a051a605e7fae4c332e59c4aee1bb76aebf.json': 'e4bb83611b4ab1008cead018c4c7f376a5ca5d90405d2691665360dad81a50a7',
 'next-iteration/kernel-cached-forward-work/gate/run_gate.py': 'ef7f4cb8768222594f45949c9400647985d57beef03e585051c13859672e31dc',
 'next-iteration/kernel-cached-forward-work/gate/source-manifest.json': 'ef9656e4889888c2abca508d1fb34418b9aa3c0d0d0b6762c929abce43a5e867',
 'next-iteration/kernel-cached-forward-work/source/CachedForwardHelpers.lean': '93cae644b96e54622f1c282ce683638ff8ff911640a0d5a08668c94c1fdb4c96',
 'next-iteration/kernel-cached-forward-work/source/CachedForwardInvariant.lean': 'c13072839390c1bde862df2ec6762f4a958e8886e60f5ac26752e0fd638f0dbe',
 'next-iteration/kernel-cached-forward-work/source/CachedForwardLicensed.lean': '34aab3f643babd3f0fa436cd551e3e932fbb8ecb4b9d2d15417b8c38dc536ead',
 'next-iteration/kernel-cached-forward-work/source/CachedForwardRuns.lean': '0017be9511bb5b148f4f78b7556c4fb7eb6b4552c1cb069326e7c4655d4ae308',
 'next-iteration/kernel-cached-helper-direct/AUTHOR-REVIEW.md': 'ded7ae8583030b5cf9bd2e849d6da00c9aed6e45227602cdace09db6c3e6ce4f',
 'next-iteration/kernel-cached-helper-direct/PLAN.md': '21b0573f21a20dcb273090e3900c47572b1c5e8babbef030859dc25a5ef48565',
 'next-iteration/kernel-cached-helper-direct/PRIMARY-SOURCE-EXCERPTS.json': '7694f58d5de60bee65fd52611628ac9dee75848d1b5a28cb97cc349eb838332d',
 'next-iteration/kernel-cached-helper-direct/PROOF-CORRECTION.json': '452dea5fa7d99bea9a02a771c1f9a8c01fabcc9f6808d908a6dfe76425fbfc41',
 'next-iteration/kernel-cached-helper-direct/SDK-ADDITIONAL-KEY-LAWS.json': 'f54f0c28d05fedab1778ba413f8baca73c16790aedf394b3c736bdbbef2916f0',
 'next-iteration/kernel-cached-helper-direct/SOURCE-AUDIT.json': 'e37b164c2fe9b5862da224231879dc4045bc42bfc6c04f6e6bd7d145c22bae48',
 'next-iteration/kernel-cached-helper-direct/SOURCE-INVENTORY.json': '4a2d1c43edda021d5f9495d8b538e041e4c41f9303aa2dbaafde5a3e3d612039',
 'next-iteration/kernel-cached-helper-direct/SOURCE-REVIEW.md': 'ca06e8cd3b5d91067e9aeffaf92aa8c4054210f701b752d2c863abf3a9e3ead3',
 'next-iteration/kernel-cached-helper-direct/corrected-source/KernelCachedHelperDirect.lean': '3a74b801028de11ea0460d74f84ec563deb2d11dae76ee012690e81a94c672f1',
 'next-iteration/kernel-cached-helper-direct/gate/AUTHORING.md': '3b845a50966b89e307b14d1701e9794fe898d4dfeb50c757ca30c30d19a242e7',
 'next-iteration/kernel-cached-helper-direct/gate/INDEPENDENT-CONTROL-REVIEW.md': 'f428d5ca426a945e40e5c8e3a385b4d6d253e168b63b1ca3bd336bfaabf9aa8c',
 'next-iteration/kernel-cached-helper-direct/gate/PROTOCOL.md': 'db4c5c22109a864e3657ae55933fa45574c1cd8ab8c56b212e15f7db586388cf',
 'next-iteration/kernel-cached-helper-direct/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '76ce4f727a29c7648689b39cd3014986503a9c1616c32e17bbf8ac9c861fd82e',
 'next-iteration/kernel-cached-helper-direct/gate/attempts/complete-01/report.json': '9eb9fef9f6d5d1ded434675495e9e2ab6ed77f3d1cdd0d898c3fbfc80c4d5635',
 'next-iteration/kernel-cached-helper-direct/gate/execution-markers/complete-c7be13545fb772ae734d0aa6c3568a22709662870f3b7058ab0f66a8561ab321.json': '5437ec3caadf299854848cf47494f000d0fc6d09c1149cdd1cd6e803fe4ffc76',
 'next-iteration/kernel-cached-helper-direct/gate/run_gate.py': '47a2e1732f42b2195c1174becb6c3ba2bac76f3a7f781a6e5a95598326a2432c',
 'next-iteration/kernel-cached-helper-direct/gate/source-manifest.json': '3f722badc8d43f69f7916730e77a0ff182eb0d4d33cc1e403a99a5149eec50af',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Init/Control/State.lean': '1eaa3725f72bd22af1510fcb5b004f395a1d2eef877cd33d520bfb9bff85bf18',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Init/Data/BEq.lean': '7c60c30768d646020cc4e4e504e5f234ed717afa70637cd1c0e0e1053741e442',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Init/Data/LawfulHashable.lean': '14a5635bf79ab8693d34e2c9dc8166f1ec37de9e5996cab1b03c88ed41d47d19',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Init/Util.lean': '853410d6970bf94c7501d4fa50763e5db210cb6ab6869d9e1b3f484021b9cfd0',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Std/Data/HashMap/Basic.lean': '09f88380eb02e29684bf4c0ba512fe714a662c90690e580570fab350cdf7d59e',
 'next-iteration/kernel-cached-helper-direct/primary/lean-4.35.0/Std/Data/HashMap/Lemmas.lean': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882',
 'next-iteration/kernel-cached-helper-direct/source/KernelCachedHelperDirect.lean': 'ccce056587248f6326d7a2d498bd0f331dbcd7f8a0961b940216d0b39bfe4f33',
 'next-iteration/kernel-cached-helper-direct/unselected-draft-v1/AUTHOR-REVIEW.md': 'b91d1fb9b594a4bc50ca141392a930234ad8d11b20308b084629e330a91ea6ab',
 'next-iteration/kernel-cached-helper-direct/unselected-draft-v1/PLAN.md': 'b57c619ca138c76795724e3a4322b861b93fe155447f5eba4d1f17438124ce15',
 'next-iteration/kernel-cached-helper-direct/unselected-draft-v1/PRIMARY-SOURCE-EXCERPTS.json': '7694f58d5de60bee65fd52611628ac9dee75848d1b5a28cb97cc349eb838332d',
 'next-iteration/kernel-cached-helper-direct/unselected-draft-v1/SOURCE-INVENTORY.json': '81930b64773dba60d93d328e24164b673f613edbc4ca76dc7c143872203f06b0',
 'next-iteration/kernel-cached-helper-direct/unselected-draft-v1/source/KernelCachedHelperDirect.lean': 'ccce056587248f6326d7a2d498bd0f331dbcd7f8a0961b940216d0b39bfe4f33',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/AUTHOR-REVIEW.md': '46eb94f4f7334279e895c6398ac2055de90c2517d4842689211789ebfa1be7e5',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/DIAGNOSTIC-CORRESPONDENCE.json': '65cbe2d8fcbec50cd6e9ea2c59c7e97a0b0c1487cfa4541964ce19fbb5fa073c',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/PLAN.md': 'b304c3f3d91213d286463b3d64db5545e4bed91629a89724d4c38b174d1b5ec9',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/PRIMARY-SOURCE-INTERVALS.json': '49b1615861923928f809eb8154fc49b8b7dd22f495dbe86007a93765a086667c',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/PROOF-CORRECTION.json': '295d0b55a0ce5c0ad4ce0a7942bbc3243ded95c7602293e7aab3c8408fd45957',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/SDK-REDUCTION-CONTEXT.json': '184ae7b32f4329359f8810e27e0f93340b5576609f96b5f900138829c5a08846',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/SOURCE-AUDIT.json': '109e7b5514426e51f948ec4748d89c034e9868bc745c1c7a38adc5dfdf044160',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/SOURCE-INVENTORY.json': '11f07d7e32230a8e2947c7a6d514352129d7da8f9cc82a5316117839c771b79b',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/SOURCE-REVIEW.md': '0a308b05915c31e27daf07072d62e22eebeef3088a790c05cfa91a1f1c6d1aa0',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/AUTHORING.md': '5309eacf31d17b0ff0dc0cd2f3e1c9887689b8a53b82233c294199c863c5ae9b',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/CONTROL-CORRESPONDENCE.json': 'b7ad66487031ed585368da26b3ac1d86112d0f7f1f69bf11db7cc47e34572b51',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/INDEPENDENT-CONTROL-REVIEW.md': '397992929fd2abf719f4be84e415ba4538c47a4d81a7f6e71af9eec21f09394a',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/PROTOCOL.md': 'c322178fefa41a3a858dc864cd6be77e82ae2dda428e791c94a6eb9221a4e30b',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/RESULT-AND-NEXT.md': '9a48ba295a2e4cc444656b3bcb1394eb84c11a732504d4ddc84471c33748243a',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/ROOT-EXECUTION-RECEIPT.json': 'fa4bfcf9f9c1f3d110485edaaa4da97c1051f5d541fbbf718e816b79ae76f988',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/SNAPSHOT-RECOVERY.json': 'a7e549b17a307f341e7d32ebd8bf916ecb7f9138f9bc96b952aa80521dd8f0fc',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedHelperFrame.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedHelperFrame.stdout.log': 'e6ced11b35b6b20128c6764ca28e71a4fc66508a3cc2cd3656fa047f0a411b35',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'a0daffc9aa4a67520c35df79e7cf5bbc73a1469d1a94bdefdbf174154db8b5a6',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedRecordWrapper.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedRecordWrapper.stdout.log': '1f0676100b787fbe888437740285c5025b91155861991083d35f51a2b65fe623',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/attempts/complete-01/report.json': '8dbd0c94bd95b77acb6cb01af73c51500156ac8ece8c1f0d2316e455c0337ce2',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/execution-markers/complete-9e17b1c37b883f2d1d869052df0cf5a11d3cf124903fa5a489637a60eeccae83.json': 'f16ce13869097f092d822dd77f9faf097c747434d1b38c5aa724fb6aef6bb1d4',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/run_gate.py': '346036325e175a416b2cfce540a9f8e53eb61d528194a69201b8b18089016e71',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/gate/source-manifest.json': 'f82d388494531b5d48e950e71cb4f3e8423316a20d31863e6be2a24f14514331',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/sdk/Init/MetaTypes.lean': '6ce9ae712999c2b8837cd19a66a262023b31fc0530bb2fd822871d25173cfc7d',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/sdk/Lean/Elab/Tactic/Simp.lean': '22f8ae5a56c71ed9f65c58f242b626e2382916d624d89a5b73e5bbe7bc421978',
 'next-iteration/kernel-cached-helper-frame-proof-repairs/source/KernelCachedHelperFrame.lean': '21d20688902af833b08390c2a7f61d51358b305020fe8c50537bd55a3fa4fab5',
 'next-iteration/kernel-cached-helper-frame/AUTHOR-REVIEW.md': 'f0eef12a5b20e953178224e88ecd9b0ba42e2256fe5b4de6d28c9f98ca0690d4',
 'next-iteration/kernel-cached-helper-frame/PLAN.md': '7865867ee19f7b6233e33b34630e67e60500cd2f49c8bed3ad673bf27e4f4598',
 'next-iteration/kernel-cached-helper-frame/PRIMARY-SOURCE-INTERVALS.json': 'f7a363bf5a2dc663fc2c31a2a51eb5da31c1225a2a2c43458cb05ed65e474d08',
 'next-iteration/kernel-cached-helper-frame/SOURCE-AUDIT.json': '56a995ba571cb1b8fa3d79200e17e2a0ccbcf0476b261796ec0b6e98b739355a',
 'next-iteration/kernel-cached-helper-frame/SOURCE-INVENTORY.json': '36620cba3ea0d7641899fe870be3167f96bae3dd4717d9ecbfdec8e4068094b9',
 'next-iteration/kernel-cached-helper-frame/SOURCE-REVIEW.md': '6a0f015c6cfe452949a9544b49db543f9a89352e45c468f8c8e563c2f31959e2',
 'next-iteration/kernel-cached-helper-frame/source/KernelCachedHelperFrame.lean': '4fd43799ca834ab45dca23d23b89cba1ad9ea2c10cdf6286863f52680c36efdc',
 'next-iteration/kernel-cached-helper-proof-repairs/PLAN.md': '7ee5eebe0f79271448e34842f979eb4fea5892d1c0c697b464c870452d05d971',
 'next-iteration/kernel-cached-helper-proof-repairs/PROOF-CORRECTION.json': 'b2e80318564bb23ecdf7b377c5f490574049a9ff1e9537baf063f887e14c1794',
 'next-iteration/kernel-cached-helper-proof-repairs/SDK-REPAIR-EXCERPTS.json': '3bdc7ded07b67e1a3670395f6355becbb72e8fe55225e7e4cd12244c087694ec',
 'next-iteration/kernel-cached-helper-proof-repairs/SOURCE-AUDIT.json': '0a9ed6e2cc91c9698c31bfa4e731b13b8729d13ca557a15b83f857e4ee4d1e52',
 'next-iteration/kernel-cached-helper-proof-repairs/SOURCE-INVENTORY.json': 'ab226bf4cb7ce175d1b403104e602bb05b1c195e9d146d6763ac5d2a8dbc7742',
 'next-iteration/kernel-cached-helper-proof-repairs/SOURCE-REVIEW.md': 'fe5d0304726eba2fd26645cc3aa5e94c814ced133fbbfb10dd9dad7eb6347bd7',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/AUTHORING.md': 'a07a344fa4b0ab1d7c5a069fe9d9fe98c41bb4b5f9d5b4b711f6d80bc56f0102',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/INDEPENDENT-CONTROL-REVIEW.md': 'd0fe46684410ca6639ebd12a698e831e6d56fcc86a2b8e04dcde4bbca17fc8ce',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/PROTOCOL.md': '9ed08c7ab1fbf0e1c2c173671d4894237443ec1b78104500e00dcf2dc12ee9c3',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/attempts/complete-01/report.json': 'e5df6430b847459c7572db232b4f1699b21cb1253d76b2e8b5434324e7ef625c',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/execution-markers/complete-efb1eed69cd6102398244e005a8cba75455a39e4c687b2fad539ba5aa1f8c444.json': '62add59871126874e8adb4920598f6cfbf3cc0980351daafbf0f925655590543',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/run_gate.py': '663ae3b965c439ddf48205c28213fcce76f5b690e110a4449f097cd71cc0e138',
 'next-iteration/kernel-cached-helper-proof-repairs/gate/source-manifest.json': 'feb9df79f0ff7c610494ffa017e3d6eb8dfcb5fc8ba6b3d4a1953b5e33b3f684',
 'next-iteration/kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean': '159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72',
 'next-iteration/kernel-cached-licensed-trace/AUTHOR-REVIEW.md': 'dffb78253c4204202bdbbdd509987786977df10d7a917213c909be5be4960fd5',
 'next-iteration/kernel-cached-licensed-trace/EXTRACTION-PLAN.md': 'ba0e494f5127246dcd8fd5c31c14d5191b798748e0aab35e64198255af89fa91',
 'next-iteration/kernel-cached-licensed-trace/PLAN.md': '60fe7333cc61a3584e89625741cc9befddc8e4340ea88f29ef91c27a2918472b',
 'next-iteration/kernel-cached-licensed-trace/PRIMARY-SOURCE-INTERVALS.json': '9c564d68ab891c3700de64c6b2855dfea008190424f07e3a24e4bc4260d310f6',
 'next-iteration/kernel-cached-licensed-trace/SOURCE-AUDIT.json': 'd9a10bc62c1c1befd44271720be1a06a30c1425f28c9728aa197291ead85d520',
 'next-iteration/kernel-cached-licensed-trace/SOURCE-CORRESPONDENCE.json': '78fd573181b3ec3630e37e885a21ab397e3a79fd26276272c6e301d958259ef5',
 'next-iteration/kernel-cached-licensed-trace/SOURCE-INVENTORY.json': '52fe9a1cb7794f5bafe99a20dc61e4e1160d5eff268f3f942517b267ccb45226',
 'next-iteration/kernel-cached-licensed-trace/SOURCE-REVIEW.md': '1116842d86edf003357d7ce1d1aae8a6e7c9d12a5df528ea2198e06ad57bff89',
 'next-iteration/kernel-cached-licensed-trace/source/KernelCachedLicensedTrace.lean': '6c7d20a6af0bc0f37dae49c9c93c90822ec70a01fbc86d6de4964ea86b5d7426',
 'next-iteration/kernel-cached-literal-contract/AUTHOR-REVIEW.md': 'b42fda1105c83d78b87ece4855eb201ee68a82a1fdf953c0431f6f51fa9ef323',
 'next-iteration/kernel-cached-literal-contract/PLAN.md': '48bd2aec3cac6527cd29d8a3f6280e3c4662fd6eb1cd805c5f67f43d369fee80',
 'next-iteration/kernel-cached-literal-contract/SOURCE-AUDIT.json': 'b4116691db3ba7fec9b834e84e4aa458f707b8e39767c67a43abae7fef4a4e4a',
 'next-iteration/kernel-cached-literal-contract/SOURCE-CORRESPONDENCE.json': 'e15b8223f10dc981fe3ee7d32df62f348a001f55a03a8aa128fc78aad3cae8e2',
 'next-iteration/kernel-cached-literal-contract/SOURCE-INVENTORY.json': 'a64b4a1dc0e8cb006f8244d7d8a98d24a446e56399b5535515771435b219e860',
 'next-iteration/kernel-cached-literal-contract/SOURCE-REVIEW.md': '0db9b01e008e450069728ee87539e4accd992bf023222994880ad181f4648e2f',
 'next-iteration/kernel-cached-literal-contract/source/KernelCachedLiteralContract.lean': '1faab276e927e3f22c7ce5e9c9c718dac9d8c2a11c6e61c6f7bcf7668a32a621',
 'next-iteration/kernel-cached-literal-forward/PLAN.md': 'c285a2bfd7e4b2f0cadca64ab0482862eeeca48a2307cd5b06621e59f6914490',
 'next-iteration/kernel-cached-literal-forward/REVIEW-WORDING-CORRECTION.json': '0fa2132d2467be55126c14f8cf2c3245f0074a43295e381c40cc462e429e7b53',
 'next-iteration/kernel-cached-literal-forward/SOURCE-AUDIT.json': '271bd3647fbffba3e3d1ba04ccda5922f758a947fa1ebb4b766b6bfbeb0ca4a2',
 'next-iteration/kernel-cached-literal-forward/SOURCE-INVENTORY.json': '2f2f5588a3c048b62adba38783f469f95486536c4225cc507b3b60cbef84df96',
 'next-iteration/kernel-cached-literal-forward/SOURCE-REVIEW.md': '0f2ec16817a349b2f9ac63a110f39204bb80f96c3f65450c0ea0604d86ae8984',
 'next-iteration/kernel-cached-literal-forward/pre-review-01/SOURCE-INVENTORY.json': '94ae11998eb665bcd6f50bd5e57023fe69d056bfef5ce800132e046b59ab5fdf',
 'next-iteration/kernel-cached-literal-forward/pre-review-01/source/KernelCachedLiteralForward.lean': '5414582afd9396f534961b61c8ce97253b16a2d745520a47423cecb1e5401b75',
 'next-iteration/kernel-cached-literal-forward/source/KernelCachedLiteralForward.lean': 'e7e02659d58c06b3f1c6f826e16914462af41bcc2797558b231cf6dea72dd325',
 'next-iteration/kernel-cached-literal-scope-repair/AUTHOR-REVIEW.md': '114df06fe67f32bc529022651a056bd16805c2e1d38b9f05c54e9c1b45fc2bec',
 'next-iteration/kernel-cached-literal-scope-repair/PLAN.md': '77a8979c534f9abef9cf449a9d5cf7dcdadced1532647d6c86c920ef0a4b6383',
 'next-iteration/kernel-cached-literal-scope-repair/PRIMARY-SOURCE-INTERVALS.json': 'ed719b324b6210f492069b41538be54051df7cbcf9ae6417d34725228ab9ab60',
 'next-iteration/kernel-cached-literal-scope-repair/PROOF-CORRECTION.json': 'f01a5e2587e9ff0c6fa8ef331ee93392e69ff6a629b52dca2f2234b73bd5d1d6',
 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-AUDIT.json': '20a539c2b210f89a6d3e47801f97b868bc1fa0e1cd77dd83bc9afd696abdcb60',
 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-INVENTORY.json': '56efa01bf13c1b4f313066b543f9be43ed6a87040d96e40f4431af7059377b61',
 'next-iteration/kernel-cached-literal-scope-repair/SOURCE-REVIEW.md': '071082c79d6cbd2695b0e7f37b329faf6d95f7b4bbeb15aa48eb85c5b6b44813',
 'next-iteration/kernel-cached-literal-scope-repair/source/KernelCachedLiteralForward.lean': '26e0a7166ff9656cc6cb737f257ae9335cf93883f9b97b98f029da8c364ebdd0',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/AUTHORING.md': 'fd39964880c27fc862ba978e1f8d4ee8ac466a344e2678927c9c467aa37f30a0',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/CONTROL-CORRESPONDENCE.json': '31326939e1289eae64a5d347519b6d3f828b0da2373306d1e4284be43c0e300d',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/INDEPENDENT-CONTROL-REVIEW.md': '87db42e4ddee997968e0ea350561e88487dac82f804b585ca8c51d05e0202ab0',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/PROTOCOL.md': 'd606d1139898f7ac4f90f62c9db0a53ab21e39fc6c9141db2177d195e141fa6b',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/RESULT-AND-NEXT.md': '2f081773b15791007a5c0e1b6aea319fadb178d0434c03f1c165064a65c2d6bf',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/ROOT-EXECUTION-RECEIPT.json': '73d639efefbdf995c1f194b1b803e3f6d07671676997163af6fda9c2f210c04f',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/SNAPSHOT-RECOVERY.json': '259e62ef8178af25b7fa016b19a1e31927bf935d619621396df3bb68998ec792',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/attempts/complete-01/report.json': '2e7b86ce0bb6489b097730f39ef4f0678041f35ae5a188419eeefebf74151f2f',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/run_gate.py': 'c8aeb8fbd678e18302db09c204aafbde45588f2ab6414d2c67d7fe2cd221d73f',
 'next-iteration/kernel-cached-lookup-memo-interfaces/gate/source-manifest.json': '46b29ea8e512be0d0c58cb53715d0c2c2d43e8cba157620517a469cf84cfaa82',
 'next-iteration/kernel-cached-memo-denotation-assessment/ASSESSMENT.md': '220059bc73e3dec6a06223a394b5a7ed907a8d6259e6dab8c3a8650a5732be2e',
 'next-iteration/kernel-cached-memo-denotation-assessment/PRIMARY-SOURCE-INTERVALS.json': 'ba7b7ac01abb5bf1539ddf72b271d799abca43208ddc655a61f977a7334b57a1',
 'next-iteration/kernel-cached-memo-denotation-assessment/SOURCE-CENSUS.json': '076a68e2d121f1519cbc8f070225756c0523474beffa784e3c38905589b226e6',
 'next-iteration/kernel-cached-memo-denotation-assessment/SOURCE-INVENTORY.json': '283acca1f4a83821671772ad9c42b7a870ad0af059895c477691a14a50aa4e13',
 'next-iteration/kernel-cached-memo-relation-compatibility/AUTHOR-REVIEW.md': '3ef61ce99ce698f05af6425ebbf6e7de238c571a2a55abdecc93f4a57c2b95c9',
 'next-iteration/kernel-cached-memo-relation-compatibility/INTERFACE-CORRESPONDENCE.json': 'd3560f020dde1a6cf956a26056462c36f2885bd951dc1ef1e09b2f5ae279a514',
 'next-iteration/kernel-cached-memo-relation-compatibility/PLAN.md': '95116189c3ce57669078aaeca914fb9983538ecedef6f9f1fc458155de83945a',
 'next-iteration/kernel-cached-memo-relation-compatibility/PRIMARY-SOURCE-INTERVALS.json': 'ab7046ecbb92ac26a07b4c0350d3487753b590d638f087fba1fd89f2249187dd',
 'next-iteration/kernel-cached-memo-relation-compatibility/SOURCE-AUDIT.json': '7818331337b0e6f84f942a6a293c7d873874e803e7f774e41e79dc550f87d3b7',
 'next-iteration/kernel-cached-memo-relation-compatibility/SOURCE-CENSUS.json': 'f4d589d826799875b7eb0bbfe92d195857f6095ef7210d503e16f894f21ee4ae',
 'next-iteration/kernel-cached-memo-relation-compatibility/SOURCE-INVENTORY.json': '4f663518ec6b9d926092f1a5bfa5b7b5537c3e5cc66f997eafd68203082e479a',
 'next-iteration/kernel-cached-memo-relation-compatibility/SOURCE-REVIEW.md': 'dbcf9c619039b1f63912af848a2b50de8413ab2b7abc36c0bd1a1136fef9d6ee',
 'next-iteration/kernel-cached-memo-relation-compatibility/source/KernelCachedMemoRelationCompatibility.lean': '6919e5a82eadaf9a547d37fb9ba445b1ed707b2e691c7dba7cf4ac1b157438cf',
 'next-iteration/kernel-cached-memo-relation/AUTHOR-REVIEW.md': '28e5b4ff7267df8b4ffb435d2c812f461c274fc4252569d3ea1bf1be2bb4e4e5',
 'next-iteration/kernel-cached-memo-relation/PLAN.md': '788895061209d7b560d1e6661814dfff9373efeb668ab3cb2270d68ad956e547',
 'next-iteration/kernel-cached-memo-relation/PRIMARY-SOURCE-INTERVALS.json': '43c2effd0f02961c5bec36d7b5b9d08b89d63c21c0aa733b39fedc8137181938',
 'next-iteration/kernel-cached-memo-relation/SOURCE-AUDIT.json': '5e9890691a1b99039d958c5f5177268e435c8c37ae8d4a6d04da284711c9adef',
 'next-iteration/kernel-cached-memo-relation/SOURCE-CENSUS.json': '715e60577c0de859341cab8130af005689d98af3fee7d86e8b31e344fb5e4f7a',
 'next-iteration/kernel-cached-memo-relation/SOURCE-INVENTORY.json': '83059b2508e89548aedfb2179fde5b4a679b9d273073c9d2f0bdfbfc92cd111a',
 'next-iteration/kernel-cached-memo-relation/SOURCE-REVIEW.md': '9bcea8a5a140504a2b642367878641b2d5efde1ee507e777e4291a3295d60ef5',
 'next-iteration/kernel-cached-memo-relation/sdk/Init/Data/BEq.lean': '7c60c30768d646020cc4e4e504e5f234ed717afa70637cd1c0e0e1053741e442',
 'next-iteration/kernel-cached-memo-relation/sdk/Init/Data/LawfulHashable.lean': '14a5635bf79ab8693d34e2c9dc8166f1ec37de9e5996cab1b03c88ed41d47d19',
 'next-iteration/kernel-cached-memo-relation/sdk/Std/Data/HashMap/Lemmas.lean': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882',
 'next-iteration/kernel-cached-memo-relation/source/KernelCachedMemoRelation.lean': 'acbbdc6f57d34f582bf422e49fca973127575c830a3ae58de2243ac8626ac2b9',
 'next-iteration/kernel-cached-memo-relation/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-cached-memo-relation/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-cached-memo-relation/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-nat-head-loop/AUTHOR-REVIEW.md': '77b236a7ffcdd11b256d2e08dddcd15aa5587783d321ffc60bfed8729b947793',
 'next-iteration/kernel-cached-nat-head-loop/PLAN.md': '404243eb67ec0b57c90eeb31694df1ca3fc54d9be2d31b4f10260d4c4a26198a',
 'next-iteration/kernel-cached-nat-head-loop/PRIMARY-SOURCE-INTERVALS.json': 'b204a709f5f394872919d5cf7ad64ed13e2c1667e0208542490c9218a36d02b2',
 'next-iteration/kernel-cached-nat-head-loop/SELECTION-CENSUS.json': '11bc350bbe2fcc3d459eaf001ce2a5224c82817ab84e6d9c161aec1f44729b82',
 'next-iteration/kernel-cached-nat-head-loop/SOURCE-AUDIT.json': '029303a38c6584bdf75a9fe3442965bb729ee74b522dade713381fdb64e2e728',
 'next-iteration/kernel-cached-nat-head-loop/SOURCE-INVENTORY.json': 'be661a1dfc5c3ac4213cb2e49efc95ec8787057a95401337c562cd27f408bd4c',
 'next-iteration/kernel-cached-nat-head-loop/SOURCE-REVIEW.md': '760f2421af5b228480e8b26a8927f60a231b5a3e4950e7910d9e8168ff63f57e',
 'next-iteration/kernel-cached-nat-head-loop/source/KernelCachedNatHeadLoop.lean': '358e15243e00bf83a92276db20d8a0e46f778f8dff3a3e6729ca9d0f3744f060',
 'next-iteration/kernel-cached-nat-iota-forward/AUTHOR-REVIEW.md': '1bb9a8d2642acea7a42fb8ccad64eb619bf313ccf774efc3f108e7d01e99c006',
 'next-iteration/kernel-cached-nat-iota-forward/PLAN.md': '819a46841ddbfce64faa02cb68f782871acbe06b67533100869bec9135eb236f',
 'next-iteration/kernel-cached-nat-iota-forward/PRIMARY-SOURCE-INTERVALS.json': '36bf3df2445ad16b15ed865070185ba3af796259f6b85fcaf09ec86032b91ed2',
 'next-iteration/kernel-cached-nat-iota-forward/REVIEW-WORDING-CORRECTION.json': '6769cb86e80c5395e43782760a5374ed38da88bfc5318d01848f6911795de1d8',
 'next-iteration/kernel-cached-nat-iota-forward/SOURCE-AUDIT.json': '6eb87fd67263ec726857a7755f49aced2c61521a239f17e8ceec23d95534732d',
 'next-iteration/kernel-cached-nat-iota-forward/SOURCE-INVENTORY.json': 'dfbec3eb7761e97a20fc486148a3611ee9dce8630120e4ef89af9d3c20905a4b',
 'next-iteration/kernel-cached-nat-iota-forward/SOURCE-REVIEW.md': '48fee3b647beebb3b3db8a05129f5fbc23aa5acea32800ef2fbaf2f7fcfeefb5',
 'next-iteration/kernel-cached-nat-iota-forward/pre-review-01/SOURCE-INVENTORY.json': '03773c70f6a8c29bcc99a8f433b610672c83e6099891e380a49137fedc6272e0',
 'next-iteration/kernel-cached-nat-iota-forward/pre-review-01/source/KernelCachedNatIotaForward.lean': 'c47b228c011e1cdc091c7ebcab484098cc2179f199bceeace6f650a85459c29a',
 'next-iteration/kernel-cached-nat-iota-forward/source/KernelCachedNatIotaForward.lean': 'cc96662ab10c69973d2bf5166b77e3fd42a0aa619ae09cae77a4dbd3efc6217e',
 'next-iteration/kernel-cached-nat-iota-framed/AUTHOR-REVIEW.md': '7610a4b244eca1fe50a21bff9ba1d39248f464811df2942aa957182ff7b36e15',
 'next-iteration/kernel-cached-nat-iota-framed/PLAN.md': 'a69ba1ce987acfc6d368ce05248f6bef92a872562c02cfbcd4dae7e710d76afb',
 'next-iteration/kernel-cached-nat-iota-framed/PRIMARY-SOURCE-INTERVALS.json': '634603bb5c10fc4e9a33a1fcdc4e8545fc56e75ee9ddce0e05eb383ba2b9333b',
 'next-iteration/kernel-cached-nat-iota-framed/SOURCE-AUDIT.json': 'f7559d4972754c4b56b183e075fd41a8e6f0ba4897f804d4bab3a4831fc8a774',
 'next-iteration/kernel-cached-nat-iota-framed/SOURCE-INVENTORY.json': '7cdcee62bb621232ddfba92fbea292554c0303e6190106323444142a5b6fe22e',
 'next-iteration/kernel-cached-nat-iota-framed/SOURCE-REVIEW.md': 'effffe71f214cfaf6b7c236422914e121f5326462ef90b1408000a49c8ce1c84',
 'next-iteration/kernel-cached-nat-iota-framed/source/KernelCachedNatIotaFramed.lean': '316150fd06ea1803189daee27f6515de9ee99aa97741e400e479116081981c8a',
 'next-iteration/kernel-cached-nat-pin-adapter/AUTHOR-REVIEW.md': '775e1d0e421799b05d28d139a6cdaae9e60be1e1d5b8d91cb97d081fa878a45d',
 'next-iteration/kernel-cached-nat-pin-adapter/PLAN.md': 'aa61e98edab8ea98c380129b898bb5d752d56e3084ad5dab3a54f19ff62e08c4',
 'next-iteration/kernel-cached-nat-pin-adapter/PRIMARY-SOURCE-INTERVALS.json': '5ecaaf69560e754a093e8b9582edb7d853d9740e5629012695fe4b7196f8dc6f',
 'next-iteration/kernel-cached-nat-pin-adapter/SOURCE-AUDIT.json': 'dcd2db4b87d4001730fbafafd2e69d23ad83862303647976a9398748aa574348',
 'next-iteration/kernel-cached-nat-pin-adapter/SOURCE-INVENTORY.json': '668ea97d2e896c48cc3ef23fb45956010af98eb3def720eab842b1a9aafddba0',
 'next-iteration/kernel-cached-nat-pin-adapter/SOURCE-REVIEW.md': 'f4b2c8597f0c520eccef0fb77924664a2942824997f9e6eff3f8334107b1454b',
 'next-iteration/kernel-cached-nat-pin-adapter/source/KernelCachedNatPinAdapter.lean': 'ea0dd4b38df8638bb46be635f9fb780aa8a57f3647ff43c00f2e2a1ea27b7a52',
 'next-iteration/kernel-cached-operational-lookup-view/AUTHOR-REVIEW.md': '5c5c4851f8493df353de74cf48673292153f7100fbd2bbfaa0f4ebaf0b52868f',
 'next-iteration/kernel-cached-operational-lookup-view/PLAN.md': 'adf376c714dae8f6cbd11a012aa2dac3daeda8f81912b9be328c44fbe0744629',
 'next-iteration/kernel-cached-operational-lookup-view/PRIMARY-SOURCE-INTERVALS.json': 'af5f56865a0f765b8f98e1a7480564531dd8a6138a49b6c975483bc52863ba8a',
 'next-iteration/kernel-cached-operational-lookup-view/SOURCE-AUDIT.json': '3db87570e47be846a14485abcdf1cb76d8ec8b2ac2a3b48d6f98bf21104f3c6e',
 'next-iteration/kernel-cached-operational-lookup-view/SOURCE-INVENTORY.json': 'f55ec4090d6d6660c69dd8400bd1880ece270bcb5588c71c0bac44de9f1a66c0',
 'next-iteration/kernel-cached-operational-lookup-view/SOURCE-REVIEW.md': '9aea9336bf07ab0f96958497f3ca8d4f024950bb9d6b8da6d94a36885b1f75f6',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Init/Core.lean': '264a0b48fedc91fadf55fc5caac8d91003e3908a6e5e42736e2ac8bf1f7cdf99',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Init/Data/List/Find.lean': 'a6c652c553d9752ce238f3943aa1a39c125148358a178240a84afe0524b22b0e',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Init/Data/List/Lemmas.lean': '9365fb1c6da0313a4c73e8cf096377e69c28ece28d38290a0423e5f8cc1fdfdb',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Init/Data/Option/Lemmas.lean': '07352a5ba0376bb4b37f5cae891a4df439666cbd63aecd1abc00f7cfebee2586',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Init/Prelude.lean': '390e6b57ead28cb821a65533b21357f2f02d0a1525602f5a1ce9ee3eeb81fd12',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Std/Data/HashMap.lean': '2220ba445b21283323f0ffecd450792ba3560612ff63dc8cd0ac8c239061db4a',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Std/Data/HashMap/Basic.lean': '09f88380eb02e29684bf4c0ba512fe714a662c90690e580570fab350cdf7d59e',
 'next-iteration/kernel-cached-operational-lookup-view/sdk/Std/Data/HashMap/Lemmas.lean': '577cd743355337df26b5d33fbc2b15d24bf54228e72d2a55376e70f4b25db882',
 'next-iteration/kernel-cached-operational-lookup-view/source/KernelCachedOperationalLookupView.lean': '535fa27f1ebc632e9688c0236ca5310d713a0ab7e2196574dfad6939dbb64805',
 'next-iteration/kernel-cached-operational-lookup-view/upstream/ConLeche/Cached/Installed.lean': '7ba12e5273637766d32cce2aa6ebd78d6b19a582687d4b042775f93b999aaf80',
 'next-iteration/kernel-cached-operational-lookup-view/upstream/ConLeche/Kernel/Env.lean': '01bfa40488838cdfd943148bc0bda6e333bdaf4f860cd01b810f4d221eace1b2',
 'next-iteration/kernel-cached-operational-lookup-view/upstream/ConLeche/Kernel/FEnv.lean': 'ae7229dd68a736d026d3025572fc30d852bf5028b3d115f2604007589f956040',
 'next-iteration/kernel-cached-operational-lookup-view/upstream/ConLeche/Kernel/Name.lean': '46e1005573233f5306444d4c12a5b204614d46e3b7a13064804174e2960a433a',
 'next-iteration/kernel-cached-prefix-lookup/PLAN.md': 'e94354a1a4d847af3c2eb1186c260aef682291df53f2103fc086316a5b94786a',
 'next-iteration/kernel-cached-prefix-lookup/SOURCE-AUDIT.json': 'f859ec2f84c1be8f549e1138a9590dda87ce47f9673dcac29876f41003b2a812',
 'next-iteration/kernel-cached-prefix-lookup/SOURCE-BUNDLE.json': 'a58be3054a06c38aa20a350499e7c699c1647aa3f0b7b18ad9d09f560ec5f01e',
 'next-iteration/kernel-cached-prefix-lookup/SOURCE-INVENTORY.json': '84d9272480582cb9d22797623796ae7540542de36961c34f21e0a760d628aedf',
 'next-iteration/kernel-cached-prefix-lookup/SOURCE-REVIEW.md': 'db811c34a7576eae5f74dfa25e6a045fbc017dd19a1f0524234521b84da32c4f',
 'next-iteration/kernel-cached-prefix-lookup/UPSTREAM-SLICE.json': 'be5f54b02a0cab20e53f4200f43dd0dd230eeb34d0a9db3e72073a2847790370',
 'next-iteration/kernel-cached-prefix-lookup/source/EnvBoundPrefix.lean': '84ba38c61f29229799762607026047095d80796ee3c0574919ccf6ceadf1ade2',
 'next-iteration/kernel-cached-prefix-lookup/source/KernelCachedPrefixLookup.lean': '31d478a06ca5e3341d756381f7198732691f4a75dcd9695d6d8d7c4c45e5d292',
 'next-iteration/kernel-cached-prefix-lookup/source/PrefixLookupAdapters.lean': '387a3c989469536fa5e4d78b0aa14f78a4e604806cab03904187984e0558d600',
 'next-iteration/kernel-cached-presentation-slice/PLAN.md': 'c61100b3c50d918a339ff56fd4ed5abdf764981ca7b4a110a066ea5e90809142',
 'next-iteration/kernel-cached-presentation-slice/PRESENTATION-OMISSIONS.json': 'ae680f4611cfcf92167f63abaad1edbb509d896a5358563695ca194cb4159be4',
 'next-iteration/kernel-cached-presentation-slice/SOURCE-AUDIT.json': '44cd82ab8006080a7cb686400da941980db575a370152b6d9e5866ab40bfe4c4',
 'next-iteration/kernel-cached-presentation-slice/SOURCE-INVENTORY.json': '073c5dceee9d5c348ec78e8cff4bc0561ca16e0dae2dbd2f48979356dcca8c12',
 'next-iteration/kernel-cached-presentation-slice/SOURCE-REVIEW.md': 'a5bcff768a0c6fe5d7d1bc6e76201993aa47b268097c9c8494caf8c1e0ad9970',
 'next-iteration/kernel-cached-presentation-slice/STATIC-CENSUS.json': '42c52902151cf2382657090112ecef5b56adcbb8da7dc32ada29d8a205cbae66',
 'next-iteration/kernel-cached-presentation-slice/source/KernelCompactCore.lean': 'aaaccdd190332c305e355392cb6ef8045f5a74ce4e0081d0cc92481c72002044',
 'next-iteration/kernel-cached-record-driver/SOURCE-AUDIT.json': '372c7c8040c2607b16e47b0d608b2b96c8d8208aa23385c5c4b0b4e77418b471',
 'next-iteration/kernel-cached-record-driver/SOURCE-CENSUS.json': '88e702c81903f0f1bc9e5acc869e5fda07c2af3948b7b132acb928ee5eb3e761',
 'next-iteration/kernel-cached-record-driver/SOURCE-INVENTORY.json': '5737e80c92b7bd5e30ee7fc623de88efa3d78c42fd4ab7f5b4035aa27063cc3c',
 'next-iteration/kernel-cached-record-driver/SOURCE-REVIEW.md': '4ae4bb45f676359ec33f038cea4fade1dd193aa29857c572a64e9515ebd5da8c',
 'next-iteration/kernel-cached-record-driver/source/KernelCachedRecordDriverCore.lean': '4253e57609cd0598c5d2b100f530ec758494aa16aec21d9eee38ae5ed990a50b',
 'next-iteration/kernel-cached-record-driver/source/KernelCachedRecordDriverForward.lean': 'c99fd7bd57c4d84b842d55f70467afc7791ac4cf3824c46fed812c992f9fc468',
 'next-iteration/kernel-cached-record-driver/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-cached-record-driver/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-cached-record-driver/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-record-shape-guards/REVIEW.md': '9c53f39220a1093f96773d7d8102f2ba17d08d3a76f79937d28fd7439ceef5a5',
 'next-iteration/kernel-cached-record-shape-guards/SOURCE-AUDIT.json': '54297452c16817841c32082fe0895ff1512cf90d08ec40516718552ce615e381',
 'next-iteration/kernel-cached-record-shape-guards/SOURCE-CENSUS.json': '401d23c17fc989c5659387f5837b9cdb883222f90c14fb331e5382d6cc1878b3',
 'next-iteration/kernel-cached-record-shape-guards/SOURCE-INVENTORY.json': 'cd042df5f546fc723c9967880ec7000d0bc28ce01638788cf540675e6bab1c55',
 'next-iteration/kernel-cached-record-shape-guards/source/KernelCachedPendingRecordGuard.lean': '3238ae96b00826e55a1f87a50a50fa453e76fc2acae6b65c0c4bebaba9ce0e35',
 'next-iteration/kernel-cached-record-shape-guards/source/KernelCachedRecordPinGuard.lean': 'a86822a964c5a169b539b3cdf7b3e48a67c4667778ec2951ba3e37713f39ef5f',
 'next-iteration/kernel-cached-record-typing/SOURCE-AUDIT.json': '0a129965aa910fd2406e57ade5e3ccc5391a63c709a5d2463feb40d414d22cc9',
 'next-iteration/kernel-cached-record-typing/SOURCE-CENSUS.json': '29e5b93ff071bbefc8ba17a0d9253fb050617b7d6428b62d9465314d76e7c4a1',
 'next-iteration/kernel-cached-record-typing/SOURCE-INVENTORY.json': 'e3092455c33560722a0f99955094c3c75e0151e9136910168cae6e4a792ea891',
 'next-iteration/kernel-cached-record-typing/SOURCE-REVIEW.md': '3380674dcb27fb7f91b8c1f5072e34399c2cd20b691675f65e7d53fef7448d3e',
 'next-iteration/kernel-cached-record-typing/source/KernelCachedRecordTyping.lean': '36802008c65e8b34924e99e469ce62cc7d6e748eaf4438518003568887e8d92d',
 'next-iteration/kernel-cached-record-wrapper-136/gate/AUTHORING.md': '459cb3c5b9d63d833e613ba21959510c501e151157cf230388c649eb97dcc563',
 'next-iteration/kernel-cached-record-wrapper-136/gate/CONTROL-CORRESPONDENCE.json': '2f62e3321e8db404cdbc776b1ee19f49d8d102c6050302d97bf486eccd8f0df4',
 'next-iteration/kernel-cached-record-wrapper-136/gate/INDEPENDENT-CONTROL-REVIEW.md': 'ac5f50c0f0755ec2f3ef740e8e8859c07a64990d025cb32af90345b8c9b05f22',
 'next-iteration/kernel-cached-record-wrapper-136/gate/METADATA-REPAIR.json': 'd3694d2e2e1fc6a5e50711b83a39f3b10942b6516626cbc1e050cbb9cb6f6a24',
 'next-iteration/kernel-cached-record-wrapper-136/gate/PROTOCOL.md': '37bcc195a1ebc9773db2fadce7dadc93658436629040c4b06abf90fdb1f5add7',
 'next-iteration/kernel-cached-record-wrapper-136/gate/RESULT-AND-NEXT.md': '97379e8b6d5402068dd79663b10eb21714de0165d981c7b00e547671a78c1073',
 'next-iteration/kernel-cached-record-wrapper-136/gate/ROOT-EXECUTION-RECEIPT.json': 'c527e77954eef769b43bd072ab3116135dd8f53daaaf3c8b0ad0b8ab061e7388',
 'next-iteration/kernel-cached-record-wrapper-136/gate/SNAPSHOT-RECOVERY.json': 'f3e8a815b466b9cc2137861d5c16f8fec6d48acd1a07db0829fd5900bf27f4eb',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': '76820b17ab6fe4f63badd154565cbf6b9eb240a865a421b6f5873ec86361f477',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-record-wrapper-136/gate/attempts/complete-01/report.json': 'aa7d43fc7174f6e2294c7fc95143c6d58f28338c264e8ad1aa962321aba57f60',
 'next-iteration/kernel-cached-record-wrapper-136/gate/execution-markers/complete-6ffb699dd88cf34e0ac1a3ca5d2702c14bad45ec2c24b743f5f67dde984b3e02.json': '0f28ee05ccbba907e61f3c06a0c4f1e6bd9626b1037bca1bf2285c7b337b4cd4',
 'next-iteration/kernel-cached-record-wrapper-136/gate/pre-review-metadata-01/AUTHORING.md': '459cb3c5b9d63d833e613ba21959510c501e151157cf230388c649eb97dcc563',
 'next-iteration/kernel-cached-record-wrapper-136/gate/pre-review-metadata-01/CONTROL-CORRESPONDENCE.json': '0e60f07cf9edafa70b3452d4b56178d81b6999f79ffc35879298656c9602057a',
 'next-iteration/kernel-cached-record-wrapper-136/gate/pre-review-metadata-01/PROTOCOL.md': '37bcc195a1ebc9773db2fadce7dadc93658436629040c4b06abf90fdb1f5add7',
 'next-iteration/kernel-cached-record-wrapper-136/gate/pre-review-metadata-01/run_gate.py': '0bde1ed1b64dcefeb33d585b497a73c06ff86d7ebce2a4116bc33cd90bf5f61e',
 'next-iteration/kernel-cached-record-wrapper-136/gate/pre-review-metadata-01/source-manifest.json': '266ef28436a5eb14911c327449621aa3f36217b1872b41d25522b80d5affc829',
 'next-iteration/kernel-cached-record-wrapper-136/gate/run_gate.py': 'ada305e8494c6bf3bf178d4d69bd630f02f12ab7c25e7de64c19dc558eab077a',
 'next-iteration/kernel-cached-record-wrapper-136/gate/source-manifest.json': '050fa169f344a66fcfd486b57460179ed95722cd8b2e616c709e799ebcc07739',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/AUTHOR-REVIEW.md': '24bc4349224601b4104ee774e646b5bf82351f6a878d030bb14fa2ded6d20770',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/DIAGNOSTIC-CORRESPONDENCE.json': 'd65ef09802ba67917394785fa28c801f6ccff7c242fbc0f754d679f872d3f5b0',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/DRAFT-EDIT-LEDGER.json': 'e5ebb8086260ac49ad2410e1d06d790d24b648efd45c8dc8648dc1b666614ec1',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/PLAN.md': '51e95d8e6755e9c4533f985d03be326ab20c2235fed4f3372ba034f2a0c35040',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/PRIMARY-SOURCE-INTERVALS.json': '0d7de64aa03acec1364ce7b26444d377f39297fc0f0996cdc35bb2c140dbda52',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/PROOF-CORRECTION.json': 'de82262c21fb1632da0f9dbcb7e359812269455b7847f28bf6c9111ee8050ef1',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/SDK-PROOF-CONTEXT.json': 'd057bcbcf17fa8b8237dfeae485915f83909d721fd1b18a89b67040315b231f2',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/SOURCE-AUDIT.json': '30b2d910e20624a8eca8b35f60643bf0a0d09a666aeee662f7e2c5704045def1',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/SOURCE-INVENTORY.json': 'ba1652ac489276b485949a11291ba807d380a4e4ffffff4132c6147d95b195b6',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/SOURCE-REVIEW.md': 'f485912712ae19b4af97574d1742f0591b53af496979103bcf73fbccaa5a2e0d',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/AUTHORING.md': '4a103cd66859cde5b74dbd5939f7940228f5f43f14fc5f03b2e72897272144d1',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/CONTROL-CORRESPONDENCE.json': 'b6916f6b2d74a25c970cfeaf090831f568b2f078ae1383c0ec93121165af1028',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/INDEPENDENT-CONTROL-AUDIT.json': '94e759d019290a337587cca9cb580c8e2724342f6dc6434647255a02cba0ad3e',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/INDEPENDENT-CONTROL-REVIEW.md': '01d16410bc14cee9da3d76acb738eb09abf9ed205ba21a4024b5f514012b89a2',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/PROTOCOL.md': '9c937bb8abfb7a2fe7c7e6c0ff8a1fb1a983cc1e73e246cc985d93fc153d64c3',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/RESULT-AND-NEXT.md': '287f70af28b51c84f5d7dd7f856233efd7c82b70f378e5c78026cc5cd4086f6f',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/ROOT-EXECUTION-RECEIPT.json': '6162a29252a6c73670103c58f326382642fbce8099e3f4da172be6c139654c4f',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/SNAPSHOT-RECOVERY.json': '4ed15d67996feb0957d431f473ad2e5a890e2bc5daa43582a7a530a2ec22034f',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/STATIC-INDEPENDENT-CONTROL-CHECK.py': '089b063f76d06c7407ad738a9442cc325957148f6b7ff8ede65bd686c4719293',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedHelperFrame.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedHelperFrame.stdout.log': 'e6ced11b35b6b20128c6764ca28e71a4fc66508a3cc2cd3656fa047f0a411b35',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'a0daffc9aa4a67520c35df79e7cf5bbc73a1469d1a94bdefdbf174154db8b5a6',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedRecordWrapper.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedRecordWrapper.stdout.log': '02dc2daf88409eb5e7d938b65b007558a5921831a91ada1c2975d5e26bf1881d',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/attempts/complete-01/report.json': 'cec3c2532b4a4ff8b1271cdde7583b91e27f6bdd629a4b6a3b744c07510ca075',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/execution-markers/complete-22cfa01f0de23f0e68657db057fcbd6f94dd822c39268ec09c85c591b5975a81.json': 'f776bf1175b25569235c7df4b14108daa17d2acb94ff55275983667bc2d768f0',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/run_gate.py': 'd5b97e6adf0084dd6800a8e8af57db0d822a1dd49afb1d2f41c425c85fc40002',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/gate/source-manifest.json': 'e7ebccb7a940829e40b612b76268e791ed59b80d5b73a1e06d7fb214dea15bcb',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Init/Control/Except.lean': '2073e491eefd9ab091aade1b84b7f5c89a244c47f0cff37dc7a1bc59bef86767',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Init/Control/State.lean': '1eaa3725f72bd22af1510fcb5b004f395a1d2eef877cd33d520bfb9bff85bf18',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Init/Data/Bool.lean': '182702f903573fe03983e39b23f2af383692e356ad50463eb7264c0152316c3a',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Init/SimpLemmas.lean': '0aa122da77386bd084dac91b5921f1cf97a8c99871528d72da6dd6cf0de1074e',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Lean/Elab/Tactic/Simp.lean': '22f8ae5a56c71ed9f65c58f242b626e2382916d624d89a5b73e5bbe7bc421978',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/sdk/Lean/Meta/Tactic/Simp/BuiltinSimprocs/Core.lean': 'e3be23f84e2df3c96221de69aed6c41b3a8a47dfdffb9cb2ff51f47af2acad62',
 'next-iteration/kernel-cached-record-wrapper-diagnosed-repairs/source/KernelCachedRecordWrapper.lean': 'd0324f77472157e721e9edeb5bbc88270b9f19296af77a44a293cf6b0a70e5ef',
 'next-iteration/kernel-cached-record-wrapper-guard-application/PLAN.md': '6ae531477b4b8cefbcc94cfd8c1b9343de541b7dd3b03349efe67c4a14b07ef0',
 'next-iteration/kernel-cached-record-wrapper-guard-application/PRIMARY-SOURCE-CONTEXT.json': '24c1babc7403b28c55dbb780663c9991ad7892145bfa66098349ab09ccf66ece',
 'next-iteration/kernel-cached-record-wrapper-guard-application/PROOF-CORRECTION.json': '0f47db75cce5128583eb0b2e5621cadf124e7d29c38acfda7dcb66434e152233',
 'next-iteration/kernel-cached-record-wrapper-guard-application/SOURCE-AUDIT.json': '9691ea208eace194a53f92b28f8abf5fcb1b7ceaf974699dde9084ccef94c893',
 'next-iteration/kernel-cached-record-wrapper-guard-application/SOURCE-INVENTORY.json': '7973f7142e40e48a0e8904c83aa7eda66903cfe2e484dde68736474c0578477e',
 'next-iteration/kernel-cached-record-wrapper-guard-application/SOURCE-REVIEW.md': 'b01ea90e39a2f19d1d576d037c10718013f6911dd1886c78e6d08e30dc7c933a',
 'next-iteration/kernel-cached-record-wrapper-guard-application/gate/attempts/complete-01/report.json': 'c6ff4d1e918effb0a3c5c321ff7154b180079149a030423e237f0700489f23b2',
 'next-iteration/kernel-cached-record-wrapper-guard-application/source/KernelCachedRecordWrapper.lean': '80b68ee87d848ab13efcef5bb737ee2b609c2e06fd83ccd5cb00c0cfafeb2f60',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/DIAGNOSTIC-CORRESPONDENCE.json': 'a6fee65104bf2cf4d94e5a65fd572df497dcd06fad61a20028d51df2d0abadfa',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/PLAN.md': 'fbf987c6b7d92703e4ced2062465e5e8ce297359783b97aa25265a317d1ac5f0',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/PRIMARY-SOURCE-INTERVALS.json': 'f54ddfaa5d5188a6b678da6c8c95455824094f6eacb1bf0619fd75ba0d55b18a',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/PROOF-CORRECTION.json': '07ee232034755c7346ea2ca2fd3545b0e63303190f2c61bacfd4b863e3a3ffc2',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/SOURCE-AUDIT.json': '77526afad940895076f2eb6e9ecff9efa772c46896f806c06ac23d8f5ccfc529',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/SOURCE-INVENTORY.json': 'b52f6d2c36c0b372b4682eaf630891699c5e86a9722776cc7a09c18bb79dbb3e',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/SOURCE-REVIEW-CONTEXT.json': '4de2f5a021bf35ca560a6ca20172b96140c4fe95c763d218dca995e587a1c2a1',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/SOURCE-REVIEW.md': '312d1520c6d3a5885147e1a4a824b23c6afa89f0de7d1fdba47bfa531d852a3f',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/review-context/sdk/Init/MetaTypes.lean': '6ce9ae712999c2b8837cd19a66a262023b31fc0530bb2fd822871d25173cfc7d',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/review-context/sdk/Lean/Elab/PreDefinition/Eqns.lean': '59644308b84ec8c1c6b8886b3524e239cc8a97aa6210feb6046b90eb126e1ee6',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/review-context/sdk/Lean/Meta/Eqns.lean': 'c031884b35f9fab9714ca5bcf1d92bc7d716350a8aaabdf38fb079f5055ea4a0',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/review-context/sdk/Lean/Meta/Tactic/Simp/Main.lean': '868a8f709f798aa9ab46c50b4ccfc11750269b5c4a02461db26e0fca9b938b7b',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/sdk/Init_Core.lean': '264a0b48fedc91fadf55fc5caac8d91003e3908a6e5e42736e2ac8bf1f7cdf99',
 'next-iteration/kernel-cached-record-wrapper-guard-selection/source/KernelCachedRecordWrapper.lean': 'b65d8dc5e148a29d40a58081a4e08bbe6ebbb3f029419f4ae7850ad2a67e5a82',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/AUTHOR-REVIEW.md': '01838386d960a869861a6dd681171e3b081f8b24d3e9753d96318d9aa71af8b9',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/PLAN.md': '83855d0f278ab3b88f7f8d81f41ada998549d0de96674dda99a85d40cada351d',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/PROOF-CORRECTION.json': 'a357398d60990e3ea3f3a6c659b2acf48f16412b9f9da226cf98b020c9a11e3b',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-AUDIT.json': '977991f7ead3c8e060b59b3bd2bf3654639e9e6f0f08c1b1021a162b8c1bd118',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-INVENTORY.json': 'eb3d52bbd378f33e199977c72c047847ee6de46a11f653dd9aadcc96609e84f2',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/SOURCE-REVIEW.md': '741e14d22aeadb9cd9f9bc14348abefbf3b7483de7b35d0d6d92194d0fa31d5c',
 'next-iteration/kernel-cached-record-wrapper-proof-robustness/source/KernelCachedRecordWrapper.lean': '25fd836ae854920b375a07c8f6eaee4708f21abe4a7a338f65cbec132b04535d',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/DIAGNOSTIC-CORRESPONDENCE.json': 'df8ea8564672910e34e48addaf9b426bf0aecf79bfbc210bf61ce9130662545c',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/PLAN.md': '89a19db3a9f25c6d21912057a2f855b2c9e3fadfdb2c150e787b90cf9910c9ee',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/PRIMARY-SOURCE-INTERVALS.json': '4b3d1b36ad237887f27c511dd92eaa566e78e5134118d551e6a8face854287ff',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/PROOF-CORRECTION.json': '255869776478c1a38e1ad93f5b59377e42edcf251ed4e9746308957360e8b047',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/SOURCE-AUDIT.json': 'a9fa80e883771dcb0134b2fcef452d326c440de57b8db8b482b1f29eb9460f15',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/SOURCE-INVENTORY.json': '0920fdc44b19ef664ab7951c8668bbc2c95010cca49f9d4ebc549b01cd136158',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/SOURCE-REVIEW.md': '4839b68f7db84e1df8b12ff82e9420f11b43149b5bdfa7d0c0877205563ec3a4',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/AUTHORING.md': '95e569dc7a65ad5690d4bd69310c36d21a45637db83fcd91560c0ec170312c9e',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/CONTROL-CORRESPONDENCE.json': '4b020b5e045220cd6ebf7fb750e492f1553a360587fdf759f86cff5be20b1a3b',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/INDEPENDENT-CONTROL-AUDIT.json': 'cfe45c6c24d71d9f6bf406d051a2498dcb2cc481f1689f84eae53f24f04f7ff4',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/INDEPENDENT-CONTROL-REVIEW.md': '40b12dc4f9517d3afc2fba012e32f10d95723c387094dbddc341dac14e3e2a60',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/PROTOCOL.md': '0274d33ccd7e15061ae5366e6e9d7f6036cd2309c20fd340df9850361934b2b8',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/RESULT-AND-NEXT.md': '1de182893b90d647fcca1da9dbf0516b04e2f55db2458070f7d66610a6781b30',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/ROOT-EXECUTION-RECEIPT.json': 'bd982f5753397c8ca6b4e1e643cb28865026b97ac36d287f90ce1e86a3a725d6',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/SNAPSHOT-RECOVERY.json': '913fa371bf6fd0dec437bfb9e258a6079801b35429b280dd3bb9ea58c644fa4b',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/STATIC-INDEPENDENT-CONTROL-CHECK.py': '69b744fbfb1921f0593ea03069c7b4b7e56f996e5e480d2e1603dd5190980bf0',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedHelperFrame.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedHelperFrame.stdout.log': 'e6ced11b35b6b20128c6764ca28e71a4fc66508a3cc2cd3656fa047f0a411b35',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'a0daffc9aa4a67520c35df79e7cf5bbc73a1469d1a94bdefdbf174154db8b5a6',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedRecordWrapper.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedRecordWrapper.stdout.log': '222631ba3197dca93c9ffa471986ad11a017a1b7fe8da85a2fa7251fd6b0af00',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/attempts/complete-01/report.json': '2913f3ecf04b4770ec3e795f8a25bc01fbc60919d6a81d3a13137c290ffd5440',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/execution-markers/complete-1c814bfbf8a9d640ae6feb77523b85436e8cddbd968cbb51ab1b7cce22dd60fa.json': '2a44589ab7ef2dc225c70b494c3f4bcc9f1544df996c2b64641e93fbaebed611',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/run_gate.py': '958f0c4c2f7070a9f7d2828ae6654705987d99637a48a1c63b9d9e4c2c29f939',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/gate/source-manifest.json': 'a2b234be3d8ceb70d12aff7abad2458d963c722bb9a9be780d98d9c84e798ea5',
 'next-iteration/kernel-cached-record-wrapper-terminal-reductions/source/KernelCachedRecordWrapper.lean': 'a2720a7029edb880b4d45700055a577ed27d59124a04aabb1ca7d0eb37d33f19',
 'next-iteration/kernel-cached-record-wrapper/AUTHOR-REVIEW.md': 'f9b86be3ca488613aa37936e7dc88d01f1895c80d9e4528519eb2f13628ab0e1',
 'next-iteration/kernel-cached-record-wrapper/PLAN.md': '933df78ef400679fd527c33c9e30ba2ab9b00f7c29dd54ab9737281b74fa93f2',
 'next-iteration/kernel-cached-record-wrapper/PRIMARY-SOURCE-INTERVALS.json': '1021dd4d1d9ac4957556bd4632151d0e799d4eb54a6aefd752b6c1d49b4a380f',
 'next-iteration/kernel-cached-record-wrapper/SOURCE-AUDIT.json': '6fa57f2a28e439c6a780d79b93e9d48c785bfd7e8f4cb110fdbe5a6641341011',
 'next-iteration/kernel-cached-record-wrapper/SOURCE-CENSUS.json': 'bd58243ae6b2f4f2ada0a3669fc95c6164470b5bbea1b6779f5a5441a9bf3802',
 'next-iteration/kernel-cached-record-wrapper/SOURCE-INVENTORY.json': 'f27256ea3ab4420b2b2a7e03a2db3692c9c17ab527b5d78c77db46cb34e9b3b0',
 'next-iteration/kernel-cached-record-wrapper/SOURCE-REVIEW.md': 'a375219cee4340cdd923acd2c454e613a19142eeb1e7d214ae7c9642313622ee',
 'next-iteration/kernel-cached-record-wrapper/source/KernelCachedRecordWrapper.lean': '98a042f392215f309a590d01dccf3ca52846f8195d63c807f9689b8607d23184',
 'next-iteration/kernel-cached-record-wrapper/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-cached-record-wrapper/upstream/ConLeche/Kernel/Level.lean': '1891be2da55612ea02bb32cedc69caf3dffcd7ed31a45563ee8bb5e48e69eb90',
 'next-iteration/kernel-cached-record-wrapper/upstream/ConLeche/Kernel/PropWhen.lean': 'e71acd70868c5bd3ecdf1ad9e8ec66a2f76d14cd9c3630880d3418565639d959',
 'next-iteration/kernel-cached-scope-equation-overlays/PLAN.md': '787e2f530ced83f7940e72a3c2f3cda7943157e77dec5eb3fa467246b4202003',
 'next-iteration/kernel-cached-scope-equation-overlays/PROOF-CORRECTION.json': '1a15ba4cbd213c71eba4fe246665e377e45b43a4e299f1d99b8eef023c3bbd18',
 'next-iteration/kernel-cached-scope-equation-overlays/SOURCE-AUDIT.json': 'c8b5a9d6b6b1dbba2d9a2d725805651799cab7a78990a5a3f09b6ce75a4520bc',
 'next-iteration/kernel-cached-scope-equation-overlays/SOURCE-INVENTORY.json': '5255c3b18c77d632986b28ed5839706e36ac3ae4d927da6a5b513930deb3d201',
 'next-iteration/kernel-cached-scope-equation-overlays/SOURCE-REVIEW.md': '35284ddce1e21ab107532fc5ffb8845058de4cacc7163a5ab424b0d9b6cc26dc',
 'next-iteration/kernel-cached-scope-equation-overlays/source/KernelCachedArithmeticForward.lean': '3b1d9dc08e8a68f55ca591fa2edfe923c3f9e6ee51d9d7a2bf0c5006b9b6373f',
 'next-iteration/kernel-cached-scope-equation-overlays/source/KernelCachedTraceArithmetic.lean': '6414f7cc76bba703111f0e9777299ce03289c9a6d34f2b08fd72d2a4b65ba9ee',
 'next-iteration/kernel-cached-stable-forward/AUTHOR-REVIEW.md': 'dc87fe20c7bfa72e97116dbdfd5c9bc64b37f1f4b047344861fc28c39373ca2a',
 'next-iteration/kernel-cached-stable-forward/PLAN.md': '678ee26bbe5896f3d15db392ba8b334ce5685140255d21a59e6d77353c7efc00',
 'next-iteration/kernel-cached-stable-forward/PRIMARY-SOURCE-EXCERPTS.json': '1c9574bfc663af129ace7830e2562de7e87edff8672d2084eb30d78dbef0a1ce',
 'next-iteration/kernel-cached-stable-forward/SDK-KEY-LAW-EVIDENCE.json': '033c644c4f95b92d1c1c2982182d58616ca8e277ef8f94d643792d852b3a24bc',
 'next-iteration/kernel-cached-stable-forward/SOURCE-AUDIT.json': 'f4bcac938b6f00f46e9e7b4f53924cd1286bfa7c86436f1b88d7bd5cc4d38e14',
 'next-iteration/kernel-cached-stable-forward/SOURCE-INVENTORY.json': '12b93b51c94f77758b79f36ecd412ed57193a1957c85fe0eb670992fb3c7c3fb',
 'next-iteration/kernel-cached-stable-forward/SOURCE-REVIEW.md': 'e309c82f1b9263a02911195fde542660c204961804ff1eaf0ead97be3f149be8',
 'next-iteration/kernel-cached-stable-forward/source/KernelCachedStableForward.lean': 'ea33539ed4a6133627dafc3815efd2dbb3c5b136dbe9b432000c3a8e123b03cf',
 'next-iteration/kernel-cached-stable-proof-corrections/PLAN.md': '74020ef855d02f1c2c338a9bf0db9831d8e6c580994fc98aad3b7fca93a5164c',
 'next-iteration/kernel-cached-stable-proof-corrections/PROOF-CORRECTION.json': '4e559e46e14450d25ce621212d045635056bc9af25f45436b8b40428815a3b0d',
 'next-iteration/kernel-cached-stable-proof-corrections/SOURCE-AUDIT.json': 'ed234c0ec2e4d528b191783baade14bb7e66c569b1a355d02f6d1842540c3e25',
 'next-iteration/kernel-cached-stable-proof-corrections/SOURCE-REVIEW.md': '5aec4f93f875601b980debefa608506ae13b12b8cad24e0fffaf1ceace985a9d',
 'next-iteration/kernel-cached-stable-proof-corrections/source/KernelCachedStableForward.lean': 'a551afb009c9b85e357db510f4a5a71d28199cc20d7bf0704d645bc45b2cf02b',
 'next-iteration/kernel-cached-syntax-correspondence/AUTHOR-REVIEW.md': '35838c0b0bf02a8f501d77cbb4771a856c20d41139c069dbd60cdc9c33dd6f19',
 'next-iteration/kernel-cached-syntax-correspondence/PLAN.md': '439fd843281c6d2543ed643cacdd9a2a19219b03317913f902ee35bb053aa4ee',
 'next-iteration/kernel-cached-syntax-correspondence/PRIMARY-SOURCE-EXCERPTS.json': 'dcd2fa7e6d578b23654d71919a9713d6b977450a2594ec9fadd98d638242f1af',
 'next-iteration/kernel-cached-syntax-correspondence/SOURCE-INVENTORY.json': '12c4c59cbef5cbb38a58ab4221ee7343f744429f06aebdb0a4ef6d112748b3aa',
 'next-iteration/kernel-cached-syntax-correspondence/primary/lean-4.35.0/Init/Data/Array/Basic.lean': '3215940809832a7a1b8ea8cdaecc8ea52e840a454bbfe358e277db09a8eb7183',
 'next-iteration/kernel-cached-syntax-correspondence/primary/upstream/ConLeche/Verify/Cached/Erase.lean': '8d71e5acdbd51392b8d7fa1558293a9247c3c0a05b5a31ca87f188118c3ba595',
 'next-iteration/kernel-cached-syntax-correspondence/primary/upstream/ConLeche/Verify/Cached/OpsC.lean': '300c16ba0ca8ff11069ac16a6bbd283b7ec6693bf61ea191e17dfccadfc51169',
 'next-iteration/kernel-cached-syntax-correspondence/primary/upstream/ConLeche/Verify/InstList.lean': '8ef494e1bf3a548db866f2e28d74990d1bf898642d9fc2059e0aa102f0dc36b9',
 'next-iteration/kernel-cached-syntax-correspondence/source/KernelCachedSyntaxCorrespondence.lean': '01cafc8427416668e8dab9b7fa92f0a424bd3387c7330f1798497dc1bf8c76b9',
 'next-iteration/kernel-cached-syntax-count-sharing/PLAN.md': '534d7c40b714995377d4a96c0d8a5e488ee34010808dfb05139e79ad8ac3bdcd',
 'next-iteration/kernel-cached-syntax-count-sharing/PROOF-OVERLAY.json': 'bd7b10024da7925f9b568c4c1adf83e3bb94e77dd4aeec35f58e645e22b9bf92',
 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-AUDIT.json': 'ece74d9a5fda51ee34b5114e1cdc9ea1b296323e113d27f5ca1a870ecf28a7ed',
 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-INVENTORY.json': '4a26aa56b016f7f22ef8b96d6dabd24768a46f087a08eb6e027716b9441c0d5d',
 'next-iteration/kernel-cached-syntax-count-sharing/SOURCE-REVIEW.md': '70d6f0cb92e886093945041df302d559c254be43977a0a64facc8d279c86aefa',
 'next-iteration/kernel-cached-syntax-count-sharing/source/KernelCachedSyntaxCorrespondence.lean': '6cc39c4ec59df011a47df407399c557f9db2d5fc965c68199dd5109e73f2177c',
 'next-iteration/kernel-cached-syntax-haslp-repair/AUTHOR-REVIEW.md': '1ce28ef8bbeec2a30e73ccb397fbaf8d257480ad48cfafd2e4a0b40480190bc4',
 'next-iteration/kernel-cached-syntax-haslp-repair/PLAN.md': '22c1a8b51a5425bb78d6471b089b6971516840fa4e52ec46868ec33ee0867d1f',
 'next-iteration/kernel-cached-syntax-haslp-repair/PRIMARY-SOURCE-INTERVALS.json': '6ed2829e44f2d55410918f8e1bd7a3803e4270de6dfd0148e1e01b9d09165023',
 'next-iteration/kernel-cached-syntax-haslp-repair/PROOF-CORRECTION.json': 'a4476ece3cd9513671c7d3ee7af65734fcedb224e07fbf04fcb339b7668d15ed',
 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-AUDIT.json': '57f0d1b8438cc361a21d785600a53dbbecb8697a2805dfabce8aaae36ad61d5f',
 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-INVENTORY.json': 'e32efdf475f116a559c2ad647d4598eba45b88407c15308e29561cde03f4c2d8',
 'next-iteration/kernel-cached-syntax-haslp-repair/SOURCE-REVIEW.md': '8336b966534a818e23c6216b5a9915294957206b5fe43ce83a4b80c00c870b81',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/AUTHORING.md': 'e649e932a7dffa622a9324b826fddb54d2b418e58ad39d9a3615548ebbf3bf83',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/CONTROL-CORRESPONDENCE.json': '43e6126af6c1dac7764ddde0efd68684944402734c72cea9ea45b17bb8ff2746',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': '1334b77763cb95b7890ad89f4208cf9c5f4b42a0f6e37985d849f5045d0317a1',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/PROTOCOL.md': 'c496f12532a1ca31651d1efef5c9cec2f6b8fa2cf012f9da397c34c77cb80b07',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/RESULT-AND-NEXT.md': 'c13f8e2f0d34a4132446e74f4557eead2184cbd7ee5d8bd5413b478c6928f596',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/SNAPSHOT-RECOVERY.json': 'c826e783d52da1f538123b8214baef58eede14fdc8173db7d613e46eb87b4be7',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedBulkBound.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedBulkBound.stdout.log': '489a0dec3bc393816b17a94a3496c3daac623422b8dd5bd08864f963b69a27ab',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedHelperDirect.stdout.log': '4a247f2a3ea981b2066ce89b44d59e68dcb8d6bb549f8365ec5acbe4898399c4',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedLiteralForward.stdout.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedStableForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedStableForward.stdout.log': '406dc7b54ea79cf1ed074381685ddc36a7b24b2434e60c2f7aa948cf75de0bcd',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCachedSyntaxCorrespondence.stdout.log': 'cb50063fd9407935f77e12332af0e808bba78dab210d3a2d9d549191d743820e',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': '8d966457a033ff9249999bc11fcd5cc76a476045f258c7aeffc50a9e16b0da7a',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/attempts/complete-01/report.json': '35441bb778bba6744b34678a176f4800643f30edebb5f5b916abb51089dc09fc',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/execution-markers/complete-a3553975ea502e13ffc11acd48dc4717fafc4e81d1478f977d1fff33e9a578f6.json': 'c866fe85d5d89eb6b821eb91bb4da6d09a92ee55e1ef627d60479987fc27cf98',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/run_gate.py': '46d2514051f9f16430e9053801d834d0701207396ebddf487db805e6c8d64740',
 'next-iteration/kernel-cached-syntax-haslp-repair/gate/source-manifest.json': '01029b15cd065a4138c044dc814597052c9b45942e6ab937c48ee9092d9f325f',
 'next-iteration/kernel-cached-syntax-haslp-repair/source/KernelCachedSyntaxCorrespondence.lean': 'a40eb68c70456557b75c687aa3964f84a482d02a7a1d0dc5d9b44da057810f1a',
 'next-iteration/kernel-cached-syntax-proof-corrections/AUTHOR-REVIEW.md': 'f50c525d15a3c30b4a723de24235735c5b73f9028d56d045650fd87f95a82eec',
 'next-iteration/kernel-cached-syntax-proof-corrections/PLAN.md': '88a074b36ff199d99f6a55f84effa7185b0f929aea76d15d31d04653e0d4ee3a',
 'next-iteration/kernel-cached-syntax-proof-corrections/PROOF-CORRECTION.json': 'd47cb05c4b9c3b1b1a7af9832e2bfbe865593f6928e5e796f7ae09e540d784df',
 'next-iteration/kernel-cached-syntax-proof-corrections/SDK-REVIEW-EXCERPTS.json': '9cf0d38ccc5bb9e6a170bc13f2206d4ea8809364b8d9765b5080cef6c4749883',
 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-AUDIT.json': '9ce96ceffce8d01396e7c126e70257db6a77d88eb66d1f854be16576d6ac9110',
 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-INVENTORY.json': 'b2fd5f6372a8f50dc10360bd3fbcca2a5eb35353f04fdf7401f3f2f6645776de',
 'next-iteration/kernel-cached-syntax-proof-corrections/SOURCE-REVIEW.md': 'a5aacb07793e5b82df9280070fba62801197cc98a4e17ad7aab5b98efd04a378',
 'next-iteration/kernel-cached-syntax-proof-corrections/primary/upstream/ConLeche/Kernel/PropWhen.lean': 'e71acd70868c5bd3ecdf1ad9e8ec66a2f76d14cd9c3630880d3418565639d959',
 'next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCachedSyntaxCorrespondence.lean': '0429b107d8ad196772ed6af52d3fb5024226addd176ef18ef08a3e7a57e8eed8',
 'next-iteration/kernel-cached-syntax-proof-corrections/source/KernelCompactCore.lean': 'b91de3074ab7d61d07d8655cb0340ea855794c1af309a892c73f0343c85d4b17',
 'next-iteration/kernel-cached-trace-binary-head/AUTHOR-REVIEW.md': '3dcbe3558965e8a7a7ae9aaae94da9e34ef44a6360330a9929d2ef9ae0d7d0ea',
 'next-iteration/kernel-cached-trace-binary-head/PLAN.md': '983c676454298a4355a9fadcf7640fa234b02ff46db359fdd8854e7220007155',
 'next-iteration/kernel-cached-trace-binary-head/PRIMARY-SOURCE-INTERVALS.json': '250f2cfc352e4435d8f7622fbedead13c533e3be9d23d833893391113fdb8f84',
 'next-iteration/kernel-cached-trace-binary-head/SOURCE-AUDIT.json': 'c1b12aeea591f99e629ae76f8b5a5a2f7b244ea9da45138054022c77c770e587',
 'next-iteration/kernel-cached-trace-binary-head/SOURCE-INVENTORY.json': '5803265399cbe9cdc0586ff046eb33b455636f3d4fac82804efd16a5247d4077',
 'next-iteration/kernel-cached-trace-binary-head/SOURCE-REVIEW.md': '6560e9b637acaf3f8974abddae2e2fdb5cbdafaf1e3ddea4d7012c0bf77311fc',
 'next-iteration/kernel-cached-trace-binary-head/TRACE-EXTENSION.json': '7ebf8e0b680e816fb64028742a7630d54c31fae4310ca874347efd3a22fb222c',
 'next-iteration/kernel-cached-trace-binary-head/source/KernelCachedBinaryHeadForward.lean': 'eb7103011275bf306c765d8f1c68ff54b17038497b184cd3242506940aa5dbb5',
 'next-iteration/kernel-cached-trace-binary-head/source/KernelCachedLicensedTrace.lean': 'b8c25623c8137fa951d575bd2a38f3378434fdda6725e05707d438b384c0c576',
 'next-iteration/kernel-cached-trace-builders-scope-equations/PLAN.md': '98deb4b4698698ca6ecd80f113763f295ca19c9653a2cc15f58f7aefe7047870',
 'next-iteration/kernel-cached-trace-builders-scope-equations/PROOF-CORRECTION.json': 'ffbcc1746e3843502b2fd54575e7a53bdba25ac5d890dfea3e0b98ae2630cceb',
 'next-iteration/kernel-cached-trace-builders-scope-equations/SOURCE-INVENTORY.json': 'c375095e5738636183e9825fb5ab1baa4c607351a90248242b7d4247be00305a',
 'next-iteration/kernel-cached-trace-builders-scope-equations/source/KernelCachedTraceArithmetic.lean': '6414f7cc76bba703111f0e9777299ce03289c9a6d34f2b08fd72d2a4b65ba9ee',
 'next-iteration/kernel-cached-trace-builders/AUTHOR-REVIEW.md': 'a7adee1d291d1784145ff648c420c7003d50eebd6fc97a6d21a5f163afdc6813',
 'next-iteration/kernel-cached-trace-builders/PLAN.md': '3df38a3bbd660d60ebec0144e46119091a4237dfaed6e8f58383c4308010fb8e',
 'next-iteration/kernel-cached-trace-builders/PRIMARY-SOURCE-INTERVALS.json': '207f23cf0cc296861a5521ab0e1ff1107210b0e2b14acefe9f3330546c523608',
 'next-iteration/kernel-cached-trace-builders/SOURCE-AUDIT.json': 'eea002ec4de10c9a87091ec11af0e348eb270582b9acbb887a9c245e80fde192',
 'next-iteration/kernel-cached-trace-builders/SOURCE-CORRESPONDENCE.json': '216a3d6551839f982bad9c4e3f174900a1cb95a0e953691620978ce29bd25612',
 'next-iteration/kernel-cached-trace-builders/SOURCE-INVENTORY.json': '5e09298c21195f97960ccb9a1f972e53045fa4406592373bfd4b2d3bb87c86ea',
 'next-iteration/kernel-cached-trace-builders/SOURCE-REVIEW.md': '7ae30e5bad071dc046a5ba88b2a908729614f99aa033b44576e53990954e2687',
 'next-iteration/kernel-cached-trace-builders/source/KernelCachedTraceArithmetic.lean': 'd12503ab883ae5e69af7d7586c5a560a961698a50f4ff75febc19d7914ceabe6',
 'next-iteration/kernel-cached-trace-builders/source/KernelCachedTraceBuilders.lean': '40d20d87b980f99e932b3257d2bfdcce09e4ac8ad8132553c707e703f4285aef',
 'next-iteration/kernel-cached-trace-head-transport/AUTHOR-REVIEW.md': 'feeb3a67a8aea1e3bd6c9bf2eb8f217a65b173c3ff5945ee12566674ac81bfd0',
 'next-iteration/kernel-cached-trace-head-transport/PLAN.md': 'ddef2c928b2e7a02154c34cbdb531f6a0d95b3ed57c343ea352ea659c637d13a',
 'next-iteration/kernel-cached-trace-head-transport/PRIMARY-SOURCE-INTERVALS.json': '7f5e9d474793eaae835a18c816f1d07fbe2c5e2f06a016d824906ef872eb1aaa',
 'next-iteration/kernel-cached-trace-head-transport/SOURCE-AUDIT.json': 'adf70010cd2b0f0c3b1daa4f5e7d07087dadc3269862432245eec0f0dfeb4580',
 'next-iteration/kernel-cached-trace-head-transport/SOURCE-CORRESPONDENCE.json': '550d74d4b04d3a83a513a969a9e6b303ff3f2f50409fd249b6fd80f0d79fee18',
 'next-iteration/kernel-cached-trace-head-transport/SOURCE-INVENTORY.json': 'edbdf92aa43a8d93ccbb5610cacb31898e1ac68b72543b48a46cb263973781d2',
 'next-iteration/kernel-cached-trace-head-transport/SOURCE-REVIEW.md': 'eb1ea342d6e0b3cddb92d861a7e359703836e91229d4df93aeb186f22233db6b',
 'next-iteration/kernel-cached-trace-head-transport/source/KernelCachedTraceHeadTransport.lean': 'e5ff127684b1f2a87633947b71381165e5ae4b5b74d96a54ad37d159f6831218',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/PLAN.md': '51ea08e788f1bf0b9f9b16e5707a3009d35f64c2c012d41e435c5fdfd4bfecce',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/PROOF-CORRECTION.json': '5b719b5611a7829007fd6f35dca64e9ecb8433907029939f0fa543c2b0213122',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/SOURCE-AUDIT.json': '1a4a9c6171366d0b16787d29f16ee2c47afedbb90455e3502a8e720d1cc79dc1',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/SOURCE-INVENTORY.json': '9154354d627cdde46fe0dadc2be9327a2331a6d02db667fb2116ceb78e56fd86',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/SOURCE-REVIEW.md': 'cf8518c7f0897c34a4603d8594d65b1f840cd94fe5ff5b1cb8ba530bce843579',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/source/KernelCachedTraceArithmetic.lean': '69d26637fedfe1979e7f8ef8851e30a0458a41fc6a6560bd7a00641e5f72e5ed',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/source/KernelCachedTraceHeadTransport.lean': '493d76dc657a5f3c5f537842fcef4514b22ce22441d28cab20568e85c52ab9e0',
 'next-iteration/kernel-cached-trace-scope-alpha-repair/source/KernelNatOnlyTracePlans.lean': '5a723d42fe98691ecb6552202cfe7ea17fe641e1473ca73680998fd3255dc40e',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/ARITHMETIC-NAT-PROOF-CORRECTION.json': 'a7e3e726eeed2472ba978df360f192f5a8791c06f6ea654f3d23fbe63c4ba0ed',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/AUTHOR-METADATA-CORRECTION.json': 'b539406b77938cc3e2356efbe1dc1929bc93a175c993fb8343f4e7119455e5a9',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/AUTHOR-REVIEW.md': 'e9ff0829c13a251a37a374c68aa8ec5dba0266eab8973f1fe1baf76c97d6fb1f',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/CAPTURED-DIAGNOSTICS.json': '35a8fddcfb468c0498c569702baea1ed4e3a89c5a9ffa0059fd05a2fff338b7b',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/CURRENT-SELECTION.json': '33f59bb7f3beb57b62de2d0b03fdf0370da67461712659b57c1771a6f0b2efb5',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/CURRENT-SOURCE-CORRESPONDENCE.json': '77532604a5154561e797f9ac05bbee653d9a601e33a882da15a583fceb0922dd',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/HEADER-AND-OPTIONS-CENSUS.json': 'b5c210935e00799efe8e6db422e8d808eb866a2337214440eb31a43646fb319f',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/PHYSICAL-PROOF-CORRECTION.json': '7594fb9c00f57e13e8cb119c33e67c95cdb8a1c40e47d3f7b91790edb1a6271a',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/PLAN.md': '04c5f9ce645d03d5c4356e2cc78396ee9ccdd5457f95d316a23c7a28e57afd6d',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/PRIMARY-SOURCE-CONTEXT.json': 'a780dbb592144c3ad773c3b9e29985874472ada457e306378d5855856f18c9ec',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/REVIEW-PACKET.md': 'fa3aa95cf808c06c6d7a96269f2705edc488d3220a02b6464c57762e5e5f20aa',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/SOURCE-AUDIT.json': 'f539bbe38672140e79957a79b8388ffca449e9be8c7a34d099b93d5b9c42bdc6',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/SOURCE-INVENTORY.json': 'a55ca5d9012a5e309fa28256815b1e62dcce5cbda183b075c33f325ca4da7e46',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/SOURCE-REVIEW.md': 'fb8a019b900202657f67c731f194b53a528089d94c1e9cd53ec31c2734bed6e9',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/logical-source/KernelCachedArithmeticForward.lean': 'ef046d3381d4c1b39cb11593d8d162d83b7ca06d263a024c01048c61e633cefd',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/logical-source/KernelCachedNatIotaForward.lean': 'ffe48a3fc77fadb7d709d122879067d065e8c366ad1a5dc8a292d900b8b7fbe4',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/pre-review-01/ARITHMETIC-NAT-PROOF-CORRECTION.json': 'f98d9c0f1e0411e329f8a61d49a3014d56b686ffa7f5e5094fbf09d81c6f67c2',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/pre-review-01/CURRENT-SELECTION.json': '300f6bd35c264ea760d25e56c9e4d091f82dc0cbe4c22b16cd2e5e6648524d5a',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/pre-review-01/CURRENT-SOURCE-CORRESPONDENCE.json': '76f88afcc29f279f12eabc35df11d344f24986d633f203b78ab02cfc8da838c7',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/pre-review-01/PHYSICAL-PROOF-CORRECTION.json': '5072f92b255e34495de11dd584d50334d66d7cc1cffc3a364f3fddfbc3581085',
 'next-iteration/kernel-cached-trace-support-diagnosed-repairs/source/KernelCachedTraceSupport.lean': '6c931f0edbb7f9f725ab8966e34a3983ec7d4f230ef04b472ea6c4ab52154ad8',
 'next-iteration/kernel-cached-trace-support-guard-repairs/AUTHOR-REVIEW.md': '07f854c92cf4d1ca2751656bdaafb4cc7f7c8e6b138882bf431557cfcd1b4cfe',
 'next-iteration/kernel-cached-trace-support-guard-repairs/CAPTURED-DIAGNOSTICS.json': 'e1492ff14a3defeeb990b06870c859f3f6f9f20cd279a38354a5e427c6054114',
 'next-iteration/kernel-cached-trace-support-guard-repairs/CURRENT-SELECTION.json': '86d58d077d0b5414076b4701a1a0cf2deb7bc427b718110bd809ebf8fb3dff3f',
 'next-iteration/kernel-cached-trace-support-guard-repairs/CURRENT-SOURCE-CORRESPONDENCE.json': 'd5a5bc3a8dbe315fbc5fa693ec6785aea314d01d8a23e681ac0d4a5d0fc5e892',
 'next-iteration/kernel-cached-trace-support-guard-repairs/LOGICAL-PROOF-CORRECTION.json': 'ecacb1f97339c78807230d3d0f582b8e49ef34f729ebd81ae00a20f9e0f1bd3a',
 'next-iteration/kernel-cached-trace-support-guard-repairs/PHYSICAL-PROOF-CORRECTION.json': '1b8edbdec2f959ae08b2ab5a6cfc1f624806769cc859b317e831fc714c4ab224',
 'next-iteration/kernel-cached-trace-support-guard-repairs/PLAN.md': '15a3bb3af0caab5c2b2a71d70aa3bd866f58ed866e0ba6daefae03042427124b',
 'next-iteration/kernel-cached-trace-support-guard-repairs/PRIMARY-SOURCE-CONTEXT.json': '22fd2e2e423e8d63f6b6db636bcb8338e518faf77b0659cd4a6c1a8586f9eeff',
 'next-iteration/kernel-cached-trace-support-guard-repairs/REVIEW-PACKET.md': '7250f821da0e336d636ff5eee4f9c0c138275beabfa425238d06cd578358efca',
 'next-iteration/kernel-cached-trace-support-guard-repairs/REVIEW.md': '127212a5158dff98a479f10f180ccd78cfe8cfa1cc01e1d0724f35a772cba356',
 'next-iteration/kernel-cached-trace-support-guard-repairs/SOURCE-AUDIT.json': '1999119c7e8ce4cf5ae3f8ec0c34820b6e7accddf7a13bb79b9f597b7ee45e8a',
 'next-iteration/kernel-cached-trace-support-guard-repairs/SOURCE-INVENTORY.json': 'bbbfeb661e6e58196c8d4e28ce3f800f5af6f48141f47c4ece6ce09e2a53dc90',
 'next-iteration/kernel-cached-trace-support-guard-repairs/STATEMENT-CORRESPONDENCE.json': 'f1726fb253f002637b83488763aeb708340660e7ced7ee44f33a09d6dd50e1a5',
 'next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedArithmeticForward.lean': 'cd86be1e0e39e14030cb79946b5eadd9696c15c8d237214d005bf5862882811a',
 'next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedBetaDeltaForward.lean': '77ab9126a7a18faeb8781112b04088435e015580f31f6647fef7099b91df4d49',
 'next-iteration/kernel-cached-trace-support-guard-repairs/logical-source/KernelCachedNatIotaForward.lean': '19928dfa1912d9a89d8df2fb65c0b09333a206f9d6303d07b23c07db37b6b6d6',
 'next-iteration/kernel-cached-trace-support-guard-repairs/sdk/Init/Control/Except.lean': '2073e491eefd9ab091aade1b84b7f5c89a244c47f0cff37dc7a1bc59bef86767',
 'next-iteration/kernel-cached-trace-support-guard-repairs/sdk/Init/Control/State.lean': '1eaa3725f72bd22af1510fcb5b004f395a1d2eef877cd33d520bfb9bff85bf18',
 'next-iteration/kernel-cached-trace-support-guard-repairs/sdk/Init/Core.lean': '264a0b48fedc91fadf55fc5caac8d91003e3908a6e5e42736e2ac8bf1f7cdf99',
 'next-iteration/kernel-cached-trace-support-guard-repairs/sdk/Init/SimpLemmas.lean': '0aa122da77386bd084dac91b5921f1cf97a8c99871528d72da6dd6cf0de1074e',
 'next-iteration/kernel-cached-trace-support-guard-repairs/source/KernelCachedTraceSupport.lean': '0cb5c9150aa42eb53b0e6af5ba59978e6916ebf77e140a128e9a8b889bca64dd',
 'next-iteration/kernel-compact-reference/SOURCE-CUTS.json': 'b4dad3ab4b7b1fcf2815bf0603b3e49afe57f88b2d4c4d8d9f5ebdb14f42f4cf',
 'next-iteration/kernel-compact-reference/failed-complete-01/source/ConLeche/Kernel/Canon.lean': '24e6c1abf511cdaee6237121b59e28da6c75ac198a7b04702fe35416f480552a',
 'next-iteration/kernel-compact-reference/failed-complete-01/source/ConLeche/Kernel/Expr.lean': '9afb8a1c16dba1c6c6e06a6c288e18f1f22b6cfb6801f683af48b63775cbf30b',
 'next-iteration/kernel-computed-fields-assessment/LEAN-LICENSE.txt': '8b28515ffffc5c0fe2807d8ae3735b00b324d9b7ce807dd63ff6ac8922fbce7e',
 'next-iteration/kernel-core-proof-term-producer/gate/RESULT-AND-NEXT.md': 'a7f5a7526fd97261f05c942751ae1b6d5064993b50f2676dcf5ddc167f4d52fb',
 'next-iteration/kernel-core-proof-term-producer/gate/ROOT-EXECUTION-RECEIPT.json': '5588d1dcd9f7688a90a51a9a64dd6799e9cc03bbdc06b676ce9e8c78241cf0f4',
 'next-iteration/kernel-core-proof-term-producer/gate/attempts/complete-01/report.json': '5d97508b9c6a4677e9c3a60d4874e1a29d63eb4d8c1e1edd20e24adf44a9d387',
 'next-iteration/kernel-generated-scope/PLAN.md': '0890939acba18d57ed892df1eb2d867e2eae7f2eab37d4f4d8f66bcfabb41aec',
 'next-iteration/kernel-generated-scope/SOURCE-AUDIT.json': '1c8eff2f2ea78b40d66f7597e0858b12c0bf1a4a190d77fbd086a8dbddc7e35b',
 'next-iteration/kernel-generated-scope/SOURCE-INVENTORY.json': '0f599edade7a38b4f22368dd5d797508c7d3b0cd0865a167b58f4eeda3655ca8',
 'next-iteration/kernel-generated-scope/SOURCE-REVIEW.md': 'f01dae31e643bd1ee530cd7161588ec9978ce54216cf4e48f68630472757a955',
 'next-iteration/kernel-generated-scope/primary/ConLeche/Verify/BridgeWfImp.lean': '78e888f390c870222a5ec517d33929a381047d5be67e2141449796ee7bc6eb53',
 'next-iteration/kernel-generated-scope/primary/ConLeche/Verify/InstLevels.lean': 'db5dca1a9be268f0b152ba6295bc43f95a4305637b568e252809e90c7b301fd8',
 'next-iteration/kernel-generated-scope/source/KernelGeneratedScope.lean': '11b3cbef56c5b6bbd12d129899e3885f6c0e68f5eb3533ca9b5e464f440acae4',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/CheckerC.lean': 'a98b1db812b85a1abddddb03b1c430ef6c4c94471343f7ae50997698ec371130',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/ExprNodes.lean': '0260b877f8dd17cbd3b6b9786d2f8465abc6c3958704533dc7022133b9b31c97',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/ExprOpsC.lean': 'fbebab6fbe1d856a7b950db763f9ab0a16930ae1069658b7493117f71fd14740',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/Installed.lean': '7ba12e5273637766d32cce2aa6ebd78d6b19a582687d4b042775f93b999aaf80',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/ParsedC.lean': '6cbfbf8db2a5f291ecf4724e8b7110922a7bd26c00360aa76dfe2c249ebc66f0',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis.lean': '44e228cf35aaef28d2ce39313342f06fa560bb6c45e220d83404b9eb918b682a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/And.lean': 'daa200309fe76ad003c31537b0480a99876cd5230406ddea2580ab0cbc4aec0b',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Builder.lean': '20d3d1318701c6d29f585c453c66db60bc24ae5a2b2560ef451c2746eecbbe89',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Empty.lean': '2defa7e2e6f9cc3430fdb1daf44901921dbe9fbb6ee71ee6b085eff93a7a0681',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Eq.lean': 'fb0d495e5954570e35baf271dba9fed1c05e86710f48cca43430e751e9c156fd',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/False.lean': '61d745f549ef8cf4ee7d20b966810ad584bb9d472f99392ac2e6e7b914fbfb0d',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Names.lean': '56caf109dd516a1f93d81afdfc176329ae5430222abdb58fb9d9a1a7bc71bd15',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Nat.lean': '5d83226e4e789647ba908ba9d714ec49ed7778e21298bed5563a04484e4abded',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Basis/Quot.lean': '4abb3ced9c0870e4ab0706d516b3866262e34c826b86c634dd250988a9ae4eeb',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/BasisA.lean': '2988ae63357f7004cbf3efd03bddd031638c4ff47205622e6b764fd32949c7ad',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/BasisGen.lean': '95aaa106e2e124cac6fd1e7b8f1320c3f4f31eabaee83f72e8a869b94bb7453b',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Canon.lean': 'da3d6c8b4f493a6ae391c0fd8d902c1126f629c8b6e324d43b220a5afd5f9a39',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Checker.lean': 'beee8053de606670779616ea52ef39f873b7b54e0ebfffd97e35e1e890c1a497',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/CheckerBase.lean': '1a21f7d385ffe94589f1078f4e36ff18643cb36c9650cf7b920e209be1ffc36a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/CheckerSplit.lean': 'fa4a4c976de37b2b725a63e15f7eece2b1766cb16ff30d92668f0a8e8b7cd16f',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Core.lean': 'f198f10b3fe5c3bc98e23aef65e6f0d02ad3027f077fd2191b4752e0f50ec886',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/CoreDefs.lean': '8a94b694efa21a45e9fdb91d1a500a6e692c8b1cdfae120ea0ebdd63347d4629',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/DeclCheck.lean': 'bf030b5b8968e2ad1ae9bfd76db818644ba64af722d7e780289c2da7c53a7c3e',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Env.lean': '01bfa40488838cdfd943148bc0bda6e333bdaf4f860cd01b810f4d221eace1b2',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Exclusive.lean': 'a3c468945c66f409c57a53f9c2769ec8f61d2917e430e159e5193a9151b412bd',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Expr.lean': '0c1d4afe69c951a1d0e883433e289b41cc646305a476bd2e9349363fa3672a37',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/ExprOps.lean': 'd4f838a5a77b6d9ed299c9b4de781f9e2eedf60798390cf39a7f664875d3b3f6',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/FEnv.lean': 'ae7229dd68a736d026d3025572fc30d852bf5028b3d115f2604007589f956040',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/BlockInstall.lean': 'b77b22da2b66cd124636c988c8ee91b0d9f6d8b1ca160ded03aaf713b265842f',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/BlockInstallF.lean': '8b33a8b09ac95e176ef7c8aa06c25d4322c68988abc72a866b1c1d4eb399251f',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/BlockParts.lean': 'feb913bc7f7d5c4adb3410ecaeb72b2c1ec97c426adb56bcc3c6d1127ceaf7b5',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/BlockRec.lean': '5250ce7da2388d0c612f5a3460d772c6053ca1bdc6ab4ea835fddfe3c9a6c15b',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/BlockTail.lean': 'dea7c6d495a2bb42bc4abea246959ced3c84f114265d4f062f70822b24aa4f64',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/ClassRead.lean': '81e6fc86d7e74df2a2f9dce1af41de814d3e6132d73901f39e38188a34c2d01c',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/FieldTele.lean': '0fd5bc7ac5c8e1ace5d8c133af1282875b3ed7547dd04a22a16de407c732961d',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/GenRec.lean': 'e33002cb1a46dfe981a6400417c876f0c0af423c8542a4d264322f9c518baa68',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/Positivity.lean': 'd13862e2ee7d887282b14b2136b02d87eb5396a32577892af290b3d2bf97e7b6',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/RecCheck.lean': 'e401801b73a5527c8de6f99ca2a55c8e2f68fa3a1e5f2e8717bb3de305c6531a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/StructInstall.lean': 'ba9156474aea9c35b462ff38e4242b5d64cd93f98d2497110c3e3256741c8e0a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/StructInstallF.lean': 'de80fc80aebff327e24abb22a3b1fa5d51a8862e8464bb52032cba86cbb2b120',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/StructParts.lean': '14c63ce33029dc1cf4c282275e157e1484d9141c3e469a4e83ec7ec6ead0be66',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/SumInstall.lean': '40593a5b8f7bdd6ef3f6d3b0e78b751bc36f644b92aae5941106773f9f972d3a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/SumInstallF.lean': '749f6c0a46cdd27a34daf7677504949b7a6c133eac532a3fb41ebb3895173509',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Inductives/SumParts.lean': '70bae149ad2fb95d8408f32a046f4bc76b8495b8ee650371525df3ef7ad8940a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Level.lean': '1891be2da55612ea02bb32cedc69caf3dffcd7ed31a45563ee8bb5e48e69eb90',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/Name.lean': '46e1005573233f5306444d4c12a5b204614d46e3b7a13064804174e2960a433a',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/NatOpPinSet.lean': '4fc2ff657643c87f8522549517f078600c901a5bcf0f3c66479c165b2c36e397',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/NatOpPins.lean': '8540e427652f12802a1d6d10027461d34e85a8b79ca30c276b9dd6c904dc8df2',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/PropRead.lean': '95277d1575a6ede73e604f6e5bd1c8d83ff0e33bc621205a6feab50f8a28bd0b',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/PropWhen.lean': 'e71acd70868c5bd3ecdf1ad9e8ec66a2f76d14cd9c3630880d3418565639d959',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/StdAxioms.lean': '7fc8e4d604fc38730d7b3d75b2b9b1c5ad29cb47fa550164dc97d65baa7c7167',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/TrustAxioms.lean': '165934cd0b4f0456fed0af1030325ce0c5b4fd3595bac61c9f50b65aa8eee7c3',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/TrustPins.lean': '4177e539a845c9fbdbc94d88ab5b1f0ca2075aa0f6718db4b6a1347a67c681f2',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/Kernel/TypeChecker.lean': '5af4102c6ae2fc195d866b20d9d5e48d360a6724470153c25dbd502e648d087f',
 'next-iteration/kernel-installed-annotation-storage/upstream/ConLeche/PinGen/Dump.lean': '7a1840fdb683d638e3ecbdee39c990ec28db28e6443babac6c2495d8560ec439',
 'next-iteration/kernel-legacy-core-selector/PLAN.md': '5a7990f81175d1451cce16f707eecd39c005c648ba53a323a2378e4135b1380a',
 'next-iteration/kernel-legacy-core-selector/SOURCE-CORRESPONDENCE.json': 'a3bc38c710e390502ae2319ffbd38ddeb2751c0e863b7263114c925945312ddf',
 'next-iteration/kernel-legacy-core-selector/source/KernelCompactCore.lean': 'f5239cfa739ad76f058fc2c337cd70c73427d331965a708aebb61805b331421b',
 'next-iteration/kernel-logical-reference/PRESERVATION-CENSUS.json': 'db8bb03c966862d452a46044e7dff5cd9ce8be7489c6898b1b773d90dac56124',
 'next-iteration/kernel-logical-reference/UPSTREAM-COMPATIBILITY.json': '7e071ea351bbfa5f0f4273df5cf02e48293231f6de4a523f33820cfa14b824de',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis.lean': '44e228cf35aaef28d2ce39313342f06fa560bb6c45e220d83404b9eb918b682a',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/And.lean': 'daa200309fe76ad003c31537b0480a99876cd5230406ddea2580ab0cbc4aec0b',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Builder.lean': '20d3d1318701c6d29f585c453c66db60bc24ae5a2b2560ef451c2746eecbbe89',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Empty.lean': '2defa7e2e6f9cc3430fdb1daf44901921dbe9fbb6ee71ee6b085eff93a7a0681',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Eq.lean': 'fb0d495e5954570e35baf271dba9fed1c05e86710f48cca43430e751e9c156fd',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/False.lean': '61d745f549ef8cf4ee7d20b966810ad584bb9d472f99392ac2e6e7b914fbfb0d',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Names.lean': '56caf109dd516a1f93d81afdfc176329ae5430222abdb58fb9d9a1a7bc71bd15',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Nat.lean': '5d83226e4e789647ba908ba9d714ec49ed7778e21298bed5563a04484e4abded',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Basis/Quot.lean': '4abb3ced9c0870e4ab0706d516b3866262e34c826b86c634dd250988a9ae4eeb',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Core.lean': 'ba80bceb575eb1b7116ecfb57c1f1b54fead4fbcb5dd33e13c84c6d81d6cb681',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/CoreDefs.lean': '8a94b694efa21a45e9fdb91d1a500a6e692c8b1cdfae120ea0ebdd63347d4629',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Env.lean': '01bfa40488838cdfd943148bc0bda6e333bdaf4f860cd01b810f4d221eace1b2',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Exclusive.lean': 'efbfa8c4daef984f4082e8f83d86be43baea82e8b2f58557c602297de67ca931',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/ExprOps.lean': 'ef512138f26c087ab78db16e7455a0bcf4b08ebb2bd568e8233197e3eb2d9542',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Level.lean': 'd6ae0e4073ffc564fdb4ee6cb56bf811a9bd97ef8e5e4c6086e8e5fb41264abc',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/Name.lean': '46e1005573233f5306444d4c12a5b204614d46e3b7a13064804174e2960a433a',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/PropRead.lean': '95277d1575a6ede73e604f6e5bd1c8d83ff0e33bc621205a6feab50f8a28bd0b',
 'next-iteration/kernel-logical-reference/source/ConLeche/Kernel/TypeChecker.lean': '5af4102c6ae2fc195d866b20d9d5e48d360a6724470153c25dbd502e648d087f',
 'next-iteration/kernel-low-operation-refinement/MATHEMATICAL-REVIEW.md': '41bc0fed744032b34fcff67deef4359c74a9bf482d20d837854873083aed1a1b',
 'next-iteration/kernel-low-operation-refinement/source/KernelLowOperation.lean': '126516626cb530f71754f0b787b898bb50774e9f4bd6489abf8b085c1ad68714',
 'next-iteration/kernel-nat-only-bodies-syntax-correction/SOURCE-AUDIT.json': '7dc0c663916220e7e73b10559e3544bcbc939bc3e40b93f09cf7caa48cfe1e3d',
 'next-iteration/kernel-nat-only-bodies-syntax-correction/source/KernelNatOnlyBodies.lean': '4fccdeb4cb56a6f6769fa18db3ee61250a3ad86be5780aad52ef467cb5b1aa82',
 'next-iteration/kernel-nat-only-control-proof-corrections/source/KernelLocalWhnf.lean': 'c84dafd0d40fdaecaee88f95dc97b17a34c0dced8a71a74379d3647e301f729c',
 'next-iteration/kernel-nat-only-control-proof-corrections/source/KernelNatOnlyControls.lean': '22404ed20bc0ed807841702492197addfeb08e0af7c3e41f9d6cc092595dc2bd',
 'next-iteration/kernel-nat-only-control-rule-projection-repair/PROOF-CORRECTION.json': '250cd2272ba04b5ff12745cb8ada367744f774a7948b2151a2c3003c2ca4204f',
 'next-iteration/kernel-nat-only-control-rule-projection-repair/SOURCE-AUDIT.json': '8c561f28196ec04d4a603956ec53e138516171cf3afc83924a81f7ca8e358432',
 'next-iteration/kernel-nat-only-control-rule-projection-repair/SOURCE-REVIEW.md': '102f12e590530353231a344e79118f838b0d9b3ca9d82d097d6d15779c228e6f',
 'next-iteration/kernel-nat-only-control-rule-projection-repair/source/KernelNatOnlyControls.lean': '47a97d3f467c6ff4e65d4e8373772c716d7319ba62b5bbb640c39217da60a6be',
 'next-iteration/kernel-nat-only-control-rule-projection-repair/source/KernelNatRecursor.lean': '8f1f8d1b1ed3033953724d3da4f8ce8a4583a5f22032b9ae74becd1975b2ef48',
 'next-iteration/kernel-nat-only-control-sharing/PROOF-SHARING.json': 'ad7229d465d62d41b8e43f41fa8b14b8495fae3cf3efc6fd886f905426ab978b',
 'next-iteration/kernel-nat-only-control-sharing/SOURCE-AUDIT.json': 'a44b409231a8e366227e0b2602bb39975634ad42f48756eaaedd5eadb22b61e3',
 'next-iteration/kernel-nat-only-control-sharing/SOURCE-CORRESPONDENCE.json': '65ae74ffa93c9694b75c16891326818998497c643b2063c6465ded3fa39b3613',
 'next-iteration/kernel-nat-only-control-sharing/SOURCE-REVIEW.md': '7fcb3d2ac6c858011986ddcfff20b8786394f9fd8ee1760289f81bc9dd0cc338',
 'next-iteration/kernel-nat-only-installed-guards/SOURCE-AUDIT.json': 'a2eaa41cfbb73d09de115996436b585cd2bf592baf331e8056d6117b8a3a7a65',
 'next-iteration/kernel-nat-only-installed-guards/bundled/source/KernelNatOnlyInstalledGuards.lean': 'd6d698e72caaee7de0eb60b9e9bbe042978d7c3e37ed722c441e9c667ca28443',
 'next-iteration/kernel-nat-only-installed-guards/source/NatOnlyBasisGuard.lean': '967c469d952647f37d758868904c66f98f378ba9bb59e670822c5fb3bbf9f5f6',
 'next-iteration/kernel-nat-only-installed-guards/source/NatOnlyPrefixGuard.lean': '197f984b5054446637d6aa30364913bb7908f1985cb6bf0c706d26012a10c1aa',
 'next-iteration/kernel-nat-only-installed-guards/source/NatOnlyProgramGuard.lean': '8b2ff06183a64489906d0cafd501f42403d46fe75a265961676bb63768f799b6',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/PLAN.md': 'aff8ded8f77cc7285e0627bd9f2eba20e933cd75915b9c546d723e720ff4cba8',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/PROOF-CORRECTION.json': '23bd570dcc3f50168f9efa8779e6526fc60ff9ea49981f624f4013aded51fa82',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/REVIEW-CORRECTION.json': '51f8e3f1f61eb955a417408e2c659b5490e28394fb30f73987b2be148ceeb436',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/SOURCE-AUDIT.json': 'f846f2e00afd7725853b2925e2cf3e3053b90aa6992eafba77b6463b4682f6a1',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/SOURCE-INVENTORY.json': '66dacdddd4dc9fc352f97fdc8d70e4e886e27915c6e043ff1e501a4ee442322e',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/SOURCE-REVIEW.md': '24fbd50278f6d57c9b6ecc0842927dca55213585fc174dc8ff6dc2eb24b94c60',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/gate/RESULT-AND-NEXT.md': '9a0eb9542cd7705e82b79fca726d6ebb886488dd302702c142bc43039ce82973',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/gate/attempts/complete-01/report.json': '601a9b9b1f77e4bc92552396f45a22154f49ba90e58f0179b874a82d3b28f345',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/gate/source-manifest.json': '9c34cea8bbd2c77fa57a0d655c3b7a6aa22be4aae1cc2eca0c88922e9e818cca',
 'next-iteration/kernel-nat-only-lambda-spine-equation-repair/source/KernelNatOnlyWholeCount.lean': '638f6e79d53eb00c9d5b7be4dd9710a03afec7c4ae22fd50714745a225000273',
 'next-iteration/kernel-nat-only-record-composition/PLAN.md': '00bf64c715913726ed3e6ca0aa19a39d84e0356034d5e21a0f97a40f5de2dd42',
 'next-iteration/kernel-nat-only-record-composition/SOURCE-AUDIT.json': 'e0dfb29cd5185c6c95f150c6b1aeb25eb03ac916d3d98c0da18b8f725d94e5ad',
 'next-iteration/kernel-nat-only-record-composition/SOURCE-INVENTORY.json': '1bbce153ff7ae1db0540ea50b6f0a21c8e42a37a0b44ab42c49f7fc657de391b',
 'next-iteration/kernel-nat-only-record-composition/SOURCE-REVIEW.md': '663ac0afb2f03408cdd90d7adba2b3bce67f7854a43d8f2ea4b013258c3515b7',
 'next-iteration/kernel-nat-only-record-composition/source/KernelNatOnlyRecordComposition.lean': '7d0d070d0b90ef396eed162c2eaf1eec4cab1542d862b6fdfad887795910606e',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/AUTHOR-REVIEW.md': 'f607da80f73fc7eab4842524f0a987864402be5611eae5b6967f874a5b1d1eb3',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/COMPATIBILITY-CENSUS.json': 'd8a9c4427e053aacab9f04b5ead1d4c4f6ef096fd3e3f8d0ccb6f1b29a858597',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/CURRENT-SELECTION.json': '06520c9d08a0da7150710f00fc54b6e7f24b585d38e1bff302a230ac2b315100',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/CURRENT-SOURCE-CORRESPONDENCE.json': 'e4fae0a87e9be2ccaa960a65a6cdd3b277ba0924bd2f96543641c36e186872d2',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/LOGICAL-PROOF-CORRECTION.json': '68fe59fb085c8c662f48b45c204611dfd4e630f4a26551fd8dc8acd2339fbe09',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/PHYSICAL-PROOF-CORRECTION.json': 'dad03e363aa4dd6a5a720d6bcee6868b7a6455981c57d5fbc1aed6dd1a33216d',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/PLAN.md': 'e9ebd7bbbe00dfe1d62e0210715e255808f234d5a6214ffb1482e946c4aa53a6',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/PRIMARY-SOURCE-CONTEXT.json': '352ab2f4760f70ca996ab5bf6a9606967e6c495ee2222ea051b73cb126ecbee4',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/SOURCE-AUDIT.json': 'b1fa46a237e6f5115547cc603e5c0d4add95c03b951c4348d82f4e70f6f47479',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/SOURCE-INVENTORY.json': '24482664cb38734228d03de8a4cbd018c510976698d4749f6452bf1978072a7f',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/SOURCE-REVIEW.md': '0b0dfc15c157b2802925ea34edec37b054ba8bb47a3d43bd608a4cacb4d42554',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/AUTHORING.md': 'da93b13b9be19cb44dc27452a5fca92ccb920a836ac82fe18a83bc645f775450',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/CONTROL-CORRESPONDENCE.json': '1f76845b1c68a5150b0f35c76ae73d6fa8003653224a4521123e77712c0f85b0',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/INDEPENDENT-CONTROL-AUDIT.json': '7e9cff9500703c95808bc7eae2fad7ffdb0476f1b9c5ddda3dd5ab9c4c887302',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/INDEPENDENT-CONTROL-REVIEW.md': '89b969f2047440ce91b9c2e9b0643765c05903f9478dee809dc2f1219fb434f6',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/PROTOCOL.md': '8b9e7d5eba60b9c4afe2276305f9d5d39373798893d837835d8833e2099ef72c',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/RESULT-AND-NEXT.md': '0a512df332c36682fb33fc8ef15364e3a358ddef2ee467d1c2a78ad139976826',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/ROOT-EXECUTION-RECEIPT.json': '062b8e8afe5478661714407af5b47310c9994ee911640ff5bf5a1277e569f147',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/SNAPSHOT-RECOVERY.json': '24d2329b643d529b219c32f0ec781bc02051f50cba5299b3b441bbf5dd29bd5c',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCachedTraceSupport.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCachedTraceSupport.stdout.log': 'e33a55cde0faa39c64c3c9ee23d8d3b6f1930d40f8fd0914e8196a25be51382c',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/attempts/complete-01/report.json': '390d9ea51b59ae10ccc497909a5bfe9e95e7a365bb0e925d829dd1a736b738ac',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/execution-markers/complete-e5f5b4e567d4fe12efb442f2ac1d4be574abd2ae623d408735caeda46bd54767.json': 'fcdde2374ec38a32258d65706c98518abdc52ad3d413990f488c7aed8e03f000',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/run_gate.py': '444a727e904ab8a955534adaa95295207bed008e772b26df0429db1af27d8cf9',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/gate/source-manifest.json': '623f0f9dca5162e0b5acf7ad139425de17293d2697b27ae40ef47edd41fed15c',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelCachedTraceArithmetic.lean': '02548b69bff053a3d84b83aa9cc0b4eac48f4a065e64c66b059efe6f9bc1fc10',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelCachedTraceHeadTransport.lean': '5500a94a1ade67b947da056e83d199325683df48bf6c486cd56606b22cf6ed6b',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelCachedTracePureBody.lean': '7d03aba16a31af19920acabf8b23e5a763bf89d2ca20238f553de85b61b2f065',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelNatOnlyTraceBranchHeads.lean': '26ee41fcfd863996c03296a736296b6d4efb7671229cacf43d2340f879756602',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelNatOnlyTraceCaptures.lean': '6ee36946ddba80c65162a03624dcc85bd0e9332c03fe30b70bc40edd7ed53470',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/logical-source/KernelNatOnlyTraceRecursors.lean': '80d42befd0571710965ff694e0ce31f6790a2530af2eed5bc1019c88f4ab4156',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/primary/lean-4.35.0/Init/Data/Bool.lean': '182702f903573fe03983e39b23f2af383692e356ad50463eb7264c0152316c3a',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/primary/lean-4.35.0/Init/SimpLemmas.lean': '0aa122da77386bd084dac91b5921f1cf97a8c99871528d72da6dd6cf0de1074e',
 'next-iteration/kernel-nat-only-trace-bool-iff-repair/source/KernelNatOnlyNumericTrace.lean': 'cb1775756abd9302be9b165afd32402e1170d8c4bcc585d75d0af283604a8bd9',
 'next-iteration/kernel-nat-only-trace-branches/AUTHOR-REVIEW.md': 'cbeed4055534c45a98a55010da4c016bbdc74748b55c347c2a15961104d8ea83',
 'next-iteration/kernel-nat-only-trace-branches/PLAN.md': '1dac37bf61c01b8689ecdecb90be430fe6fd4f1fd0f6532f5c73b40c0785f2ce',
 'next-iteration/kernel-nat-only-trace-branches/PRIMARY-SOURCE-INTERVALS.json': 'fe5ca0a6b84f3e45fa5d3d01a00e3047a452d4e17c4104e4e5249414b98bdd2c',
 'next-iteration/kernel-nat-only-trace-branches/SOURCE-AUDIT.json': '920235d1c0cceb0169acdf0286f3adbca61f982269936f9e385ba65f90276bc2',
 'next-iteration/kernel-nat-only-trace-branches/SOURCE-CORRESPONDENCE.json': '339d3031dd7d01b7666515a058856ede2f05c675c593fcb7ba383eab2c47b570',
 'next-iteration/kernel-nat-only-trace-branches/SOURCE-INVENTORY.json': 'b53de18010ddfbeb27af0344b94b2d1ef1e06050c827c2a6979df61b9e467b13',
 'next-iteration/kernel-nat-only-trace-branches/SOURCE-REVIEW.md': '9818d0fe9508a65c410ea48f0ae8b9aecfd596d85876f65520b7b4ed2db5aa7c',
 'next-iteration/kernel-nat-only-trace-branches/source/KernelNatOnlyTraceBranchHeads.lean': '1c49f4b04911c2407adbef4e5141bcbf9f1c4b2c411a4a523e8d2a3f277aa8e7',
 'next-iteration/kernel-nat-only-trace-branches/source/KernelNatOnlyTraceBranches.lean': 'c7aede772e775f97695f97ad6918768bc963a9cdb482b32ab3ee6c7e9250e39d',
 'next-iteration/kernel-nat-only-trace-consolidation-assessment/ASSESSMENT.md': '05f82ec74d4f72cd3cc4f05918ffd8c55e7cc13f2fa84238b51e5f36517fbc36',
 'next-iteration/kernel-nat-only-trace-consolidation-assessment/BUNDLE-PROPOSAL.json': 'd0d4288d80bcee2d1b587f568ff3ecf8ec865282d35754c7b55531a7cf8916f9',
 'next-iteration/kernel-nat-only-trace-consolidation-assessment/SOURCE-ASSESSMENT.json': 'b2357b4a84e0cb0461deb5abff7e9c2368f0a9e43d0932d1507e20ee22713696',
 'next-iteration/kernel-nat-only-trace-consolidation-assessment/SOURCE-CENSUS.json': 'aada2bf90c79f479bcc40228cd52385d8ec38f8b0e4dd3af0f708d8f59d30656',
 'next-iteration/kernel-nat-only-trace-cost-assessment/ASSESSMENT.md': 'bcc8dd073ed23324d39ea19493594af5d5ab687473c7092fe899e22663117de3',
 'next-iteration/kernel-nat-only-trace-cost-assessment/PRIMARY-PROOF-TERM-CONTEXT.json': 'f6a3957eec3f20a092ddba79b55987696a345b56259599f2eb5b5a8c22e20960',
 'next-iteration/kernel-nat-only-trace-cost-assessment/SOURCE-ASSESSMENT.json': '0430decf1d9ad742fcd031850be0e41c45bc9959874884080a6bcd093e7e6455',
 'next-iteration/kernel-nat-only-trace-count/AUTHOR-REVIEW.md': 'f616f54eac4dd0d044ed2f73cb9546565328dbc438844d47cbfba835263209a6',
 'next-iteration/kernel-nat-only-trace-count/PLAN.md': '0bfceead0537befcf9062f1a5951632d2f457aaa185bf4ef9408be07986e1fbb',
 'next-iteration/kernel-nat-only-trace-count/PRIMARY-SOURCE-INTERVALS.json': '68cf01965a522ad69c0f73f999554d166e01105efa6d4bef463473807b1a93ae',
 'next-iteration/kernel-nat-only-trace-count/SOURCE-AUDIT.json': '2824e2f43bf9dd1d42b6139305e126adacf29c4f7831bbd5cd2235b9c8c5ee51',
 'next-iteration/kernel-nat-only-trace-count/SOURCE-CORRESPONDENCE.json': 'c5aeb67be2461ac0df57dc58a2578f19495308dce47e3efdaf1ff77360a9f85e',
 'next-iteration/kernel-nat-only-trace-count/SOURCE-INVENTORY.json': '574fb05a9195248044babb83e93c7fffb10e34b187c52c440ac5f62f58f70937',
 'next-iteration/kernel-nat-only-trace-count/SOURCE-REVIEW.md': '6ac5f6fef7e06492c1bebf2219434467dc5d68f9054249509c0a7a77197b9121',
 'next-iteration/kernel-nat-only-trace-count/source/KernelNatOnlyTraceCount.lean': '46149234804c842eebc67222a2a51027d3819663207483d96e71668a30165f03',
 'next-iteration/kernel-nat-only-trace-count/source/KernelNatOnlyTraceCountHeads.lean': '68b22260e35e05e9fc1fcc8455fd71a83b222b4d9f3d922a1edab0d37c8416e8',
 'next-iteration/kernel-nat-only-trace-count/source/KernelNatOnlyTraceQuery.lean': '41b5c7793de057b97e1090aa0523fb36cf8977a6e6cebf0177689887d18fbad0',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/PLAN.md': 'ec502fac9b4fb5b29eec4a11a3dcfd3c059f22451569e4d7e06033b1fb540605',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/PROOF-CORRECTION.json': '60eba9c0bbc9c1409b0eb97e513445900b0bc0933c273d570c1b01fff4c43a13',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/SDK-NOTATION-CONTEXT.json': 'fbc21aff6c6f2241aa258ae736ecbd39ed4ed97381935fe6c98c14be5ec2b67d',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/SOURCE-AUDIT.json': '03da151b1300473f464a24c1a33325e8d9742158753f534feb8e741705cc400a',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/SOURCE-INVENTORY.json': '43c1e06f059df7c3fec810245aa89e2fce5b66e18cb14b626ed5ec1862445b01',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/SOURCE-REVIEW.md': '93f32735e3ffeb9a2dffe419e0846bb42bcac82725fa2492f45f88ee1bb63e26',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/source/KernelCachedNatPinAdapter.lean': '9df0179221685fe826ae7c754c664c19d6461745ddaabb011cf61601dc38c7d4',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/source/KernelNatOnlyTraceBranchHeads.lean': 'fc74b0ddbeb5a70236d1206e7eb5de45a618e04689137aeb25e50a31a61d2ac7',
 'next-iteration/kernel-nat-only-trace-goal-parentheses/source/KernelNatOnlyTracePlans.lean': '4ab80f3c2409a85112e77c4494eafc0c4300deb8e37ccbd58677c525fb263975',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/AUTHOR-REVIEW.md': '881ce56e13f25c61580b53496cc6485d61abe8d273a15fce2a111782c2e87889',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/PLAN.md': 'a80105a8f9defff2016fe281ecbb5e295a8661a2d6a96080569f4148fc1cd265',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/PROOF-CORRECTION.json': '7dead79ec6a1872de0fe918f6782a35582c07c72d7106eb90a5269f401f47285',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/SDK-ALIAS-CONTEXT.json': '95cf79d09f883949d9e12fec82fb13ac56ff9cd899e527b51fb6df36117ee1d3',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/SOURCE-AUDIT.json': 'a4239ef3bab3e6db9a312f0746d6140cf40bcc2ae3f1a764d96c7c29385907b9',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/SOURCE-INVENTORY.json': '49fdb8f2422afe6ae169c481ef1b63dc58b80957a0641ed3e21e18beda313080',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/SOURCE-REVIEW.md': 'a6a8a1ca8e579f98ca8f554d1450f0c3c8c5404400e0aa22f1a5c728963521dd',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/source/KernelNatOnlyTraceBranches.lean': 'dd53b199a64147ff99bec8746b4f1664b1c30239820800fcdd26632fd1aafe97',
 'next-iteration/kernel-nat-only-trace-numeric-alias-repair/source/KernelNatOnlyTraceCount.lean': '074dfca86de5adb6bbd0e362c9f647f926e8962be43ebe50abec922cc8f58ad7',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/AUTHOR-REVIEW.md': '5a2b3797cbaa0e206c5a6a4294bb8b10b9aed501f7231b31b7b8ccf54fb30dce',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/DEPENDENCY-SELECTION.json': '5274eb4d38771f82c74cf1db46d98d4fc147966868191f73c4c5dec137328dbe',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/PLAN.md': 'f279e7ac4893bf4a37111cf7a77419c0ff5133b3d07c172fd45272c79dc673df',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/REVIEW-PACKET.md': '7c0245cd2ac55bd84ae99c94b5f61fd6182a93106f243e9e52187494bcafd43a',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SCOPE-AND-DEPENDENCY-CENSUS.json': 'bb1f7dc2668b4fa30c40c92298847fb2cbdcf0e8c32ffc8522ad8620df96017d',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SDK-NAME-RESOLUTION-CONTEXT.json': '1eff3ca3c4005eef1fa1f424954e3bf05f882104d03900c953120a7aaf8ec1e9',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SELECTED-SOURCES.json': '728199b3ea725246011b0aa3516d4365f89474146816b89f5128be21029fb951',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SOURCE-AUDIT.json': 'a5f65c01ccd986df531e75e970a2801ed6058179b14fb60e2efcfa24c48f96d7',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SOURCE-CORRESPONDENCE.json': 'c064d89508ad6af63c29d114becb878cd00c2305ab1b99171f3854ce2f271985',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SOURCE-INVENTORY.json': '8136bf59baa03216e709a3e1db1ee305f560b13cc81e43c042f0f558a17655c7',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SOURCE-REVIEW-SCOPES.json': '33b090960df0b73f95396598468ae62467f9ccd9d7a215923c277dab43c7a4c4',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/SOURCE-REVIEW.md': 'c25f81c34b7df775cdbc12e5a6669a7d172e8b57b3876684e7ca62231079c48c',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/WORKING-STATUS.md': 'af2cc79dbeca5a5d7a9f547efed7dc43ea03cd91fe58ae83aadacd5cbb4c6978',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/AUTHORING.md': '2d2456176ca51fc073e62bd3ae00aaaddede8fa593d6c5a897904215e98d3f0b',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/CONTROL-CORRESPONDENCE.json': 'cc524042488ddee0cef3581c07776f2735605389ca1ab73ea282dfcf21df4950',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/INDEPENDENT-CONTROL-AUDIT.json': 'c8e0b359685a7be8ba3f1ae635f460b4bd43760c3382094018d74d13f4e7ee79',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/INDEPENDENT-CONTROL-REVIEW.md': 'c6a7511e9ba0a0f48fe78ea43dd3735d762fd653b1ded45190ca9090715c09a3',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/PREFLIGHT-01-RECEIPT.json': 'f9d6873323adbcdb56178ef122f851a5a010e9d56b2d4d9031e65deefbec9694',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/PREFLIGHT-01-RECOVERY.json': 'ae4565566d6564132345b18a9bd08fd8e9091d4a31f5ffac5965573270bf44b0',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/PREFLIGHT-SCHEMA-CORRECTION.json': 'c36e3e4b62cb5c580eb479eca5948e0f11fdbe422f17f283d6eb323e86ccf12c',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/PROTOCOL.md': 'c56a55a154b8654aaa34ea8bccc95b016e9ad497c809bd257a0b7c21fed6d694',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/RESULT-AND-NEXT.md': '4fa4b27a90dc0a505227f4967d80718b82be309cc98911093939b6d0457f0720',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/ROOT-EXECUTION-RECEIPT.json': '6c299113bdbcf85dd56f87046509a15f2bea0b3a402cf0e778e865b3df17c87a',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/SNAPSHOT-RECOVERY.json': 'fc680a87a065f283c71bfa19f8ab560c5a38bba5ff69e5448ab555015b549b6f',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/STATIC-INDEPENDENT-CONTROL-CHECK.py': '7fe50e85142412092533b6fe3c38dd9800a6e319f1f5d47359df96127fc81d78',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCachedForward.stdout.log': '0fb7f86e22a385b82d0b733864a2a50c68c9794e263443ea77835bcb9182027f',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCachedTraceSupport.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCachedTraceSupport.stdout.log': '94419877e701eab89bef9fe116de7bfc1a89afb362dd5a073ef98c44df680a1b',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/report.json': '4fc64ada12d2250871ddcdf43f195a964adac4425f4ede2906938e05b35df190',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/attempts/complete-01/source/KernelCachedTraceSupport.lean': '6f69e94f962b8b71710f946ac1c6650230decdf962a1df7e989db5fde792404b',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/execution-markers/complete-90f715be49edceb2bf48d1a4e62c3cba39a7c34cb5d8737e07cd4e342bfa296a.json': '5b33de943f62f34ec861499a7c5ef39468523d5e1a2d854fe1da6df5033dc9aa',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/run_gate.py': '12cf6da39000ef788b40e34ef2bbf84e85c0e2e5f5077d15835d4d25289264da',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/gate/source-manifest.json': '0c2077d2fdfc174ea41d18fa12e4ef7a94e39ff3c247e24b84957a94385974c3',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/review-context/lean/Lean/PrivateName.lean': '21569296df3d69ca3f48dd109ed875c040509f9f693419e44cea9fa130b08179',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/review-context/lean/Lean/ResolveName.lean': '29568f90bc8c5b713b7462096b94e898f30d0eca21119ae9abac695604615d13',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/source/KernelCachedForward.lean': '9106a2d9b63f90a0fdcabe5d2c9e8cf6205d01eefeee11eb666b4b008bc59661',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/source/KernelCachedTraceSupport.lean': '6f69e94f962b8b71710f946ac1c6650230decdf962a1df7e989db5fde792404b',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/source/KernelCompactCore.lean': '82d26d6ab2de3d140da6c04c15f0ee91a129b372428a15788508e74f56045b81',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/source/KernelNatOnlyNumericTrace.lean': '862db60faddabf5e917a83c84382a463cbb029c5353f735be4a6ded6f827f58e',
 'next-iteration/kernel-nat-only-trace-numeric-assembly/source/KernelNatOnlyPureSupport.lean': '73bf1a0180f0cdccf5c379365c5b9b149a00b577fcbf7cac4c137ba88aa0a682',
 'next-iteration/kernel-nat-only-trace-numeric/AUTHOR-REVIEW.md': '6e8e9750d50bc7c80356b435044429b3c7db52fb3ad1b2e00202518a6760a36b',
 'next-iteration/kernel-nat-only-trace-numeric/DEPENDENCY-CENSUS.json': 'ce47e526b99ae00f40ab5c3fea765e7cc90b669bbe35d15e521069278b0340f8',
 'next-iteration/kernel-nat-only-trace-numeric/PLAN.md': 'c58fa87d2faa2145f7b6a396a1b444733c681c6180c45a1c397eb49333e5391f',
 'next-iteration/kernel-nat-only-trace-numeric/PRIMARY-SOURCE-INTERVALS.json': '072554170d9f8a77fe3a2eaa2acff1fd9ff3f2906e7e8610fd773d43863e28db',
 'next-iteration/kernel-nat-only-trace-numeric/SOURCE-AUDIT.json': 'ee2d886729b8a42095695292fa3fe37ebd0652e850083a72c13176f9e6676784',
 'next-iteration/kernel-nat-only-trace-numeric/SOURCE-CHANGES.json': '072d6ec82842e345f4a5184f42b87dc13b44e78de82cf79f7e7f707f450b1067',
 'next-iteration/kernel-nat-only-trace-numeric/SOURCE-INVENTORY.json': 'c15c57b14b48cc09cef1cf43f53c9f940232937fde45642e5fd922b1599e7d37',
 'next-iteration/kernel-nat-only-trace-numeric/SOURCE-OMISSIONS.json': '4a8afdc795b4d039f3926480e8fc1f75f6c440bb3e9e557fe6f673c127fd08db',
 'next-iteration/kernel-nat-only-trace-numeric/SOURCE-REVIEW.md': '9e4a59d8b2ca60b8d329a86e96c35f9163f9ad3e1458544a5fa774535e6ae3ab',
 'next-iteration/kernel-nat-only-trace-numeric/STATEMENT-CORRESPONDENCE.json': 'b4e4bc6c7226b9a5c5d9f948c786acd97d64ca9478edfbaa84751ab3584013eb',
 'next-iteration/kernel-nat-only-trace-numeric/source/KernelNatOnlyTraceBranches.lean': 'a94d714486c97d1fff87bf8d5b89052a04f20c248733c8b3a9d08f3476acc1ba',
 'next-iteration/kernel-nat-only-trace-numeric/source/KernelNatOnlyTraceCount.lean': '04c7c84ab5de7c6dd48333ec6d2648e179327f3578a95f437433e308cd342e59',
 'next-iteration/kernel-nat-only-trace-numeric/source/KernelNatOnlyTraceQuery.lean': 'a6fb85795aae630e37e41714c64c3fdc0e52a81f4f4aecc5096af9d8070ba79c',
 'next-iteration/kernel-nat-only-trace-numeric/source/KernelNatOnlyWholeCount.lean': 'df075c7b9a715da6c67f379ac5919aa12200fbfb3218644f44a1bc317fc0f009',
 'next-iteration/kernel-nat-only-trace-recursors/AUTHOR-REVIEW.md': '9f0cd4ea30addd2d2b420206478197fa6ccc1b8e492fd1c1f30ac227895bda87',
 'next-iteration/kernel-nat-only-trace-recursors/PLAN.md': '89eac24d24aeaf320e58b4d5c8ab074c3e868991aae9715cbb91db8757406518',
 'next-iteration/kernel-nat-only-trace-recursors/PRIMARY-SOURCE-INTERVALS.json': 'eeae30ab1c4e0b36e4abd7ce831c45c772a6ab1baa8f5805a5a0147211196a9d',
 'next-iteration/kernel-nat-only-trace-recursors/REVIEW-PRIMARY-SOURCE-CONTEXT.json': '6b934abeadff453f9118b8976366bd936b69909e6cba58631b9b36aa58c56ba2',
 'next-iteration/kernel-nat-only-trace-recursors/SOURCE-AUDIT.json': 'ea264dee191af0d3e6d3a63653171c1bc2f977a5eff3fa0e12dd232da54110a8',
 'next-iteration/kernel-nat-only-trace-recursors/SOURCE-CORRESPONDENCE.json': '397ca669a58ec5e972fb3ef2e271c8416714da442d897800b977e71010c5cf82',
 'next-iteration/kernel-nat-only-trace-recursors/SOURCE-INVENTORY.json': '04256ed4afe44961f7c98755309e660809842f5121a0d4ff878c6a254198cc97',
 'next-iteration/kernel-nat-only-trace-recursors/SOURCE-REVIEW.md': '5b54b6cffa05c1dcb55dd634bb14efa8ddd87fade473466609b56fcda71f3cde',
 'next-iteration/kernel-nat-only-trace-recursors/source/KernelNatOnlyTracePlans.lean': 'b0d7104c1185b67e08337d2df2421a038257d628248cbab7e65b3b5b5aafc8e3',
 'next-iteration/kernel-nat-only-trace-recursors/source/KernelNatOnlyTraceRecursors.lean': '848f145aebba657cf2af7536fc3f9ec5263ff694b8eb628474506880299395b4',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/PLAN.md': '7c24adf9d2474b3e8c54c049ce584d3ac3ae5854ed5cbbb625d7d11104ed09fd',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/PROOF-CORRECTION.json': 'a4083dde62a5127431a1a2f484d04b3f5ef37c51345ac7b6141f11d2104e7db3',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/SDK-RW-CONTEXT.json': '8ac4fd287acc4eed9096938b50b6a152b444c78fae29045ecca6165f6dc70dbb',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/SOURCE-AUDIT.json': 'fcd6c6741648dc6f9b8a03789be360ba0c350d53a8b43347d86e48c7e7fe1782',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/SOURCE-INVENTORY.json': '478aea66230f654091053696145a00e8d9429885b4b919a2ec35b1474b2a3cd9',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/SOURCE-REVIEW.md': 'b50d879579ddcde8264b924e1dadcc3a62e9f2d71cff2208d2947a8e708e2772',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/review-context/Init/Tactics.lean': '0f98c09e7e56ed3431292d6996a20237ec8e5eb4d322e5701b33d6396638e056',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/source/KernelNatOnlyTraceBranchHeads.lean': '031b2ff293b1b41bf29f96a47c7867ef7a92c692903228c413f1d5d7bf6900d1',
 'next-iteration/kernel-nat-only-trace-rfl-fallback/source/KernelNatOnlyTracePlans.lean': 'd48a26024df352cd7161175133f339185621f5d86dc4b710ed4087503c25231f',
 'next-iteration/kernel-nat-only-trace-scalars/AUTHOR-REVIEW.md': '406123b060f91e453787275f3a04e00667b86cbf641c48043bba66967d792df2',
 'next-iteration/kernel-nat-only-trace-scalars/PLAN.md': '623d4cbfcb87ec2ac3053b385cdcc0806a00f9b02067e522b51e59d1d00a88d2',
 'next-iteration/kernel-nat-only-trace-scalars/PRIMARY-SOURCE-INTERVALS.json': '7bbe64ee767bc126300488bc3d2fbb110301dac8da69eea59597e4115cf4ceb5',
 'next-iteration/kernel-nat-only-trace-scalars/REVIEW-PRIMARY-SOURCE-CONTEXT.json': '076b9998a213b60dc0a289daadbda55816218db96db0b2483b9f3286ca7fb535',
 'next-iteration/kernel-nat-only-trace-scalars/SOURCE-AUDIT.json': 'a5916537e892a7f1a3944f1bd081caf57b1f79b94b8e6397814fe2f7be4b2cb5',
 'next-iteration/kernel-nat-only-trace-scalars/SOURCE-CORRESPONDENCE.json': '1974670b0021b114f6305f23e5854ed8799b588fe3f983aacc1df921f62bf8e0',
 'next-iteration/kernel-nat-only-trace-scalars/SOURCE-INVENTORY.json': 'b75fcafb7b02686dd62b475727e3632f99f1064c0eccfa99fdf7099d9a29f44f',
 'next-iteration/kernel-nat-only-trace-scalars/SOURCE-REVIEW.md': 'c8de5ea86a30ec14014b5db09667db62f63a4141d4b5725878c53eff09935490',
 'next-iteration/kernel-nat-only-trace-scalars/source/KernelNatOnlyTraceScalars.lean': '47e8544ee1e88b3e5afb90ef79e8aa61fa6942636c87d8d1b8b3c24a6c373faf',
 'next-iteration/kernel-nat-only-trace-wrappers/AUTHOR-REVIEW.md': 'eb5181469d7d1c9a4fa0201655383237009acdc9f063671bd5a6fdc906ad24f0',
 'next-iteration/kernel-nat-only-trace-wrappers/CAPTURE-SOURCE-CORRESPONDENCE.json': 'a8dd2c1a64816ec0b27cb17f6b9be5a954fea9218df6ed22a9fedb3cd250cc08',
 'next-iteration/kernel-nat-only-trace-wrappers/PLAN.md': '3a298de2d2592c21431aa53212d332fcba6487c8cb839795f8785c90c29f6672',
 'next-iteration/kernel-nat-only-trace-wrappers/PRIMARY-SOURCE-INTERVALS.json': '050d144a291a82ec2aaae57c5efad25ba791abcd5eb9782838c32eaa0c463246',
 'next-iteration/kernel-nat-only-trace-wrappers/SOURCE-AUDIT.json': '2835d8fa20fb842a17530acb8680fe191980641876149328a21026ece6c998a5',
 'next-iteration/kernel-nat-only-trace-wrappers/SOURCE-CORRESPONDENCE.json': 'b313e7eaa3aabd0955387ccd5a455dcc317de45fea25886b0fb515eeb6d2bc06',
 'next-iteration/kernel-nat-only-trace-wrappers/SOURCE-INVENTORY.json': '5dad31adf61ad09d7043aaaa0a5f060087385f9f26f218f69810498e98825ddc',
 'next-iteration/kernel-nat-only-trace-wrappers/SOURCE-REVIEW.md': '233eb80ce3d139ea89c5ae770e8cfe6faf7da0f2be29a52b5966dc5be598c629',
 'next-iteration/kernel-nat-only-trace-wrappers/source/KernelCachedTracePureBody.lean': '23fe9b8e5ecc49f4a960a9cedc5846bbce805a573b0b641a76116bb4271f1573',
 'next-iteration/kernel-nat-only-trace-wrappers/source/KernelNatOnlyTraceBranchWrappers.lean': '0a92a15a445ebf994ef609808c9121ba6786adc7b4fc2949240d409b5c6bfe60',
 'next-iteration/kernel-nat-only-trace-wrappers/source/KernelNatOnlyTraceCaptures.lean': '609d269e04becb82122046bf5045bc38e021660a642dd2eb8e40d847576dd869',
 'next-iteration/kernel-nat-only-trace-wrappers/source/KernelNatOnlyTraceDefinitions.lean': '6d06c8727009a219ef3184ca1fa5ecc6eb643911ecb82ab7ed74b004bd9c2463',
 'next-iteration/kernel-nat-only-trace-wrappers/source/KernelNatOnlyTraceTelescopes.lean': 'b6199ebb4a296a7bf3d8ad8cd2e7839e0217add347dc1dcc7113320e0fe03d7d',
 'next-iteration/kernel-nat-only-whole-count-assembly/source/KernelNatOnlyReference.lean': '0c67b429174161435f7657936fc6acd22739d2afdfd636d94911db9c1bf31319',
 'next-iteration/kernel-nat-only-whole-count-shared-assembly/SOURCE-AUDIT.json': '3c4125a795ff4f50d7f8851e0bf1ad94985d944171f83e474210470e715ab17b',
 'next-iteration/kernel-nat-only-whole-count-shared-assembly/SOURCE-INVENTORY.json': '7ab9047aa354d4d8ad3063820a95ef3f0f6feb0b0c7f6e7f34d8a32bf6efcf14',
 'next-iteration/kernel-nat-only-whole-count-shared-assembly/SOURCE-REVIEW.md': '83649e15531eb29353fe55f7a963708ad6ac015659a04332af848d345adc0149',
 'next-iteration/kernel-native-installed-eligibility/ASSESSMENT.md': '00d74f1010b3ce2029883e6bf35c6150bad8a89364ef71f22b70d65832b3dd83',
 'next-iteration/kernel-native-installed-eligibility/SOURCE-CENSUS.json': '66c040672549350d11cdf631fd0f05542bb323b91987c8595d9215d48e63f715',
 'next-iteration/kernel-native-installed-eligibility/SOURCE-INVENTORY.json': '18a03474f32399187fed9a36af49bda834a2a97cb06b31eca31908442266e0bd',
 'next-iteration/kernel-native-record-certificate-fallback/PLAN.md': '62dd5cb8fc90b624d71aa3ebe93917dff65bd988f108a2efbfd26ba058c68e25',
 'next-iteration/kernel-native-record-certificate-fallback/SOURCE-AUDIT.json': 'd48a7b2fc3cd0eaa5162a172ffcbd54bb82a587b74ae5cc8f3d8777596c42635',
 'next-iteration/kernel-native-record-certificate-fallback/SOURCE-INVENTORY.json': '2b1782d50e0d71d9db94fd62ac6021ce55d364a9ce57b0dabc57709ee04f3c6c',
 'next-iteration/kernel-native-record-certificate-fallback/SOURCE-REVIEW.md': 'b0a5ae0341b9e5016e85d3521b28da4a031a9fd49aecd398a3d86ad8b937b647',
 'next-iteration/kernel-ordinary-fields-core/PLAN.md': 'f1f1e886e29ff53d4a5e1560f6da3b2020748084ea4f004bbefba6df7c7e2896',
 'next-iteration/kernel-ordinary-fields-core/SOURCE-AUDIT.json': 'c7867e58fb0caa9923db8f984afab5adab3ac699c827408fb6743fd2ad8d1f9e',
 'next-iteration/kernel-ordinary-fields-core/SOURCE-CORRESPONDENCE.json': '819dcad5de27e29385a2334b6e9b48ae3a48ff5e45187da0fd13c72b14f3d771',
 'next-iteration/kernel-ordinary-fields-core/SOURCE-REVIEW.md': '6e0d27dfc305e5bdd10fd0bb2273e1685b0021cd7b4bb35a12f951bb090a5e94',
 'next-iteration/kernel-ordinary-fields-core/source/KernelCompactCore.lean': '5085d1427673452718f936b80707dd4be5b328b0612f026961dfa53c62943636',
 'next-iteration/kernel-original-record-contract/ARTIFACT-RECIPE.md': '43fee252437635fb479a2f085776f9f2b066bd31bea6b4e7b4ad0f2d1cf5ba3f',
 'next-iteration/kernel-original-record-contract/CACHED-FIXED-FUEL.md': '47caa4481fc4ca8b9a86fa7f20f61ce09324622fe27f48813e5ca9f41a71fc3c',
 'next-iteration/kernel-original-record-contract/CONTRACT.md': 'f08326f21e2a59d1881882dc91d42478a739c556fb84e39b2fb6fb494fb2019f',
 'next-iteration/kernel-original-record-contract/SOURCE-EVIDENCE.json': '45ecdfe60779b4c45e29a7b33368c026c373dfd9385fa9cdbc264d03d426e3d8',
 'next-iteration/kernel-original-record-forward-route/PRIMARY-SOURCE-INTERVALS.json': 'a87b128d24e09adc426c5ae85c0b51bc8584ac040e3c38bb79601e5adcbf07bc',
 'next-iteration/kernel-original-record-forward-route/ROUTE.md': '252e6c68639b0938b3226c381b18bfe27b4f4de65a7471f2fc30d085040e96c9',
 'next-iteration/kernel-original-record-forward-route/SOURCE-CENSUS.json': '10577ead84074461d30e116e4437bcf2b82c8d60fcdee43b032eba0120a562fa',
 'next-iteration/kernel-original-record-forward-route/SOURCE-INVENTORY.json': 'ffc052fb7703d1863300acd5e3e9657cc0ec7f350a20143bbf93c5464559efc7',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Cached/CoreC.lean': '9eccfb679e08b927654e0a6f4a51f120bf9f2ff1fe61b5d3eaa67d56b6c3594f',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Cached/Installed.lean': '7ba12e5273637766d32cce2aa6ebd78d6b19a582687d4b042775f93b999aaf80',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Cached/ParsedC.lean': '6cbfbf8db2a5f291ecf4724e8b7110922a7bd26c00360aa76dfe2c249ebc66f0',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Cached/StateC.lean': 'bf7c7a21174e469ea7099cdbbdca6d1bb45003249513d0c2cabd7554e36eafc0',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/Basis/Eq.lean': 'fb0d495e5954570e35baf271dba9fed1c05e86710f48cca43430e751e9c156fd',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/BasisA.lean': '2988ae63357f7004cbf3efd03bddd031638c4ff47205622e6b764fd32949c7ad',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/CheckerBase.lean': '1a21f7d385ffe94589f1078f4e36ff18643cb36c9650cf7b920e209be1ffc36a',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/CheckerSplit.lean': 'fa4a4c976de37b2b725a63e15f7eece2b1766cb16ff30d92668f0a8e8b7cd16f',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/Core.lean': 'f198f10b3fe5c3bc98e23aef65e6f0d02ad3027f077fd2191b4752e0f50ec886',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/CoreDefs.lean': '8a94b694efa21a45e9fdb91d1a500a6e692c8b1cdfae120ea0ebdd63347d4629',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/FEnv.lean': 'ae7229dd68a736d026d3025572fc30d852bf5028b3d115f2604007589f956040',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Kernel/PropRead.lean': '95277d1575a6ede73e604f6e5bd1c8d83ff0e33bc621205a6feab50f8a28bd0b',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Model/InstallRun.lean': '152159eb8b0804c1a620f6ae6d6c7d7593d3b631bd08f511bab34ec428e35b41',
 'next-iteration/kernel-original-record-forward-route/upstream/ConLeche/Verify/Cached/InstalledC.lean': '905edec773e27a49bf9ce8495b6a7b0e4dc004bfc505f328b778d3922ad78064',
 'next-iteration/kernel-propwhen-retraction-proof/PLAN.md': 'eacd8ea1c37fbc6fbaf71f40b0cd06d0a0d8a7fcf819d45f814b2ce46f4361d9',
 'next-iteration/kernel-propwhen-retraction-proof/PRIMARY-SOURCE-INTERVALS.json': 'c472fe22f93b552d437c91ca4d7fc11c40269618325766641c5c2cc4d7eeafe2',
 'next-iteration/kernel-propwhen-retraction-proof/PROOF-CORRECTION.json': '6a162352d2c38e986636b6e8d1344e323576dc0f1b8ed6f095d38e602e28133e',
 'next-iteration/kernel-propwhen-retraction-proof/SOURCE-AUDIT.json': '1d9e7d6e445af6b7c5925587e2ac7f200b7f050eb0ab31485520a5d55b7c552e',
 'next-iteration/kernel-propwhen-retraction-proof/SOURCE-INVENTORY.json': 'b5a1f938075ed436dced61523970177e3e5e8821ff80ab59ea88ee7a300f20f3',
 'next-iteration/kernel-propwhen-retraction-proof/SOURCE-REVIEW.md': '99cda118c39a1eb85074ebe6d04b77908880fb1af18d40d5bcc6677eaf5955db',
 'next-iteration/kernel-propwhen-retraction-proof/native/ConLeche/Kernel/PropWhen.lean': '0e65057a5a62ef12b9e64a8eb2317394ce25e74d3a2cc3e2a7c2e5d8210e639d',
 'next-iteration/kernel-propwhen-retraction-proof/source/KernelCompactCore.lean': '82d26d6ab2de3d140da6c04c15f0ee91a129b372428a15788508e74f56045b81',
 'next-iteration/kernel-propwhen-slice/PROOF-CUTS.json': '6be627aa4e7a3c77fe2f2dd9a3f7a62cee2331dede2aa2b16c346149d828dfbf',
 'next-iteration/kernel-propwhen-slice/source/ConLeche/Kernel/PropWhen.lean': '7268cb1683ea72d2827e777840c082b287e0393474b4ee89a58cb845ce6c1ac1',
 'next-iteration/kernel-pure-reference-codegen-assessment/ASSESSMENT.md': '008dadd7544020cce74de3ead23908e8ef94e8d5580a27d551b951875b71abab',
 'next-iteration/kernel-pure-reference-codegen-assessment/PRIMARY-SOURCE-EXCERPTS.json': '01e47cce48c9c5f727e95fb3fe2e0767a5f18b53a1e5bfb64fdf7cdc89f61559',
 'next-iteration/kernel-pure-reference-codegen-assessment/SOURCE-ASSESSMENT.json': 'b5c25f7105d6ac7f00d0d31bbf5ea1c3502d7ae25d5242fd4abf0e28af7c6dc2',
 'next-iteration/kernel-pure-reference-explicit-modifiers/AUTHOR-REVIEW.md': '1dac872b69db7d4661f7ebe75daeb832d4249bd4b394c7e59a996b804a1c4741',
 'next-iteration/kernel-pure-reference-explicit-modifiers/CONSUMER-CENSUS.json': '77088ff1120289f069b53e6222f6c5fafeeaf9ae471c325c55add372f3ed20df',
 'next-iteration/kernel-pure-reference-explicit-modifiers/DECLARATION-SCOPE.json': '66b8396834dd1badeb682b8aa6e5e7f455282b35326d6d106ba4f2d4db693c20',
 'next-iteration/kernel-pure-reference-explicit-modifiers/PLAN.md': '1c8f6e97efc285b5ac9f464135dffa80b5904cb5bd418ced31e3e2361a716952',
 'next-iteration/kernel-pure-reference-explicit-modifiers/PROSPECTIVE-SELECTIONS.json': 'f0b195622d3402b9665185ca315d31acdfdf972b6c83807759aabc7125b2b2fb',
 'next-iteration/kernel-pure-reference-explicit-modifiers/REVIEW-COMPILER-CONTEXT.json': 'ea0353293afb113717e724176bad1b60aa090d431a1b9531b53736c670350047',
 'next-iteration/kernel-pure-reference-explicit-modifiers/REVIEW-PACKET.md': '00e94edc261c3301da1495044d50f720fe4d10f2e3f8468360d4df86dc0c6809',
 'next-iteration/kernel-pure-reference-explicit-modifiers/SDK-COMPILATION-CONTEXT.json': 'c58f7181360a4334a9115f7c12913ca2f779b8e675f1067bba98f49bf2463ab1',
 'next-iteration/kernel-pure-reference-explicit-modifiers/SOURCE-AUDIT.json': 'b2c4e88f57384abd0ea454cfa829c70bb9c1131a0b1fe594902eb5d7a5fbca16',
 'next-iteration/kernel-pure-reference-explicit-modifiers/SOURCE-CORRESPONDENCE.json': '85556c821d04aa289a2ad30c7ddccc09ec0cea5c4484a8591384f27bab80702f',
 'next-iteration/kernel-pure-reference-explicit-modifiers/SOURCE-INVENTORY.json': '7f206e583198994be308b884f8448c672108054a74b7c7db21e3023522065659',
 'next-iteration/kernel-pure-reference-explicit-modifiers/SOURCE-REVIEW.md': 'f33f2be1e5949dd270968f3a7c1b47313b9de0c43f9a29f9a360ffaef83fc1ee',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/Command.lean': '829047d7681916f3bb3d8688c05910051eada45816e79e816a5e4c7646b12f1e',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/DeclModifiers.lean': '9665a12a50dfb92b42f87759941bad09e9f7357f6042cd660c3795859c804749',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/MutualDef.lean': '73a278e79b6fa2a355c3076c40eec8f0cd607c8b68f21e1fa344b56d14e6c3b9',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/Basic.lean': '46a2876ccbe1efc4cc491dc24658fea5e972544a64da888334fe2ffcc9c1a5c7',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/Main.lean': 'b384fe2a3fd637f36194cab22821440871e9112d700a8dbb1c4c7392fe399647',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/Mutual.lean': '2ece19ee6fe171c6621a463ab122384f97ca7fdca6bda9831c688b1faefc5698',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/Structural/Main.lean': '8a86ae2d1bae7f1b6c3e52a86f20e3460eecf0dbb7f7a891a16f89971d36be29',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/Structural/SmartUnfolding.lean': '54402d6a84560042821d560107e35121b6bb1de39baf86caf47fd8054e3d7150',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Elab/PreDefinition/WF/Main.lean': 'cc673e422dd83756dda6cfc04ea3a02f3aae04dc00b37d11e61e18b6cde0b01d',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Meta/Match/Match.lean': '58a36e74cef6409af96281b55239de4201cd64d7d40f7eb9d8904848c7b2606f',
 'next-iteration/kernel-pure-reference-explicit-modifiers/primary/lean-4.35.0/Lean/Meta/Match/MatchEqs.lean': '69923ec1ee92377a50634c752d5c57129207136379406127edc14087dc5dd116',
 'next-iteration/kernel-pure-reference-explicit-modifiers/review-context/lean-4.35.0/Lean/Compiler/LCNF/ToLCNF.lean': 'dd59611da7cf49f418f89fba79cb4299de0331581bbb5948d3e028e0f13da4f0',
 'next-iteration/kernel-pure-reference-explicit-modifiers/review-context/lean-4.35.0/Lean/Compiler/NoncomputableAttr.lean': '8d1ba44757e2a2b4d1916ee97b8c0dd54171ff1890db8a1452f0346119d65859',
 'next-iteration/kernel-pure-reference-explicit-modifiers/source/KernelCompactCore.lean': '7b86980a0513dc0a888edddbfb1e3b9c97eab6aafe6fa878755a7e4c59f928ec',
 'next-iteration/kernel-sliced-selector/SOURCE-AUDIT.json': 'df274ce3a255895ca8baeba9049276453c68d6f1be4186ea5dfccc23fc72c98a',
 'next-iteration/kernel-sliced-selector/SOURCE-BUNDLE.json': 'c83fe60ddcd66d4411111392e979746b2719eb207cd8b410a6a311398dd19d30',
 'next-iteration/kernel-sliced-selector/SOURCE-INVENTORY.json': '2ece8a10cd633ef37ce9ee159cef348cc84a21d8baeeb57d6a6729e1657e8876',
 'next-iteration/kernel-sliced-selector/SOURCE-REVIEW.md': '612a202743ac3c41bde8195c17375f3ff3cd5bad80d9d2278216e6ebe945d9b5',
 'next-iteration/kernel-sliced-selector/source/KernelCompactCore.lean': 'ff8b7a7dd3054d01d337fc025af634b6075568ef215ad7ded55d133ac51dd7ba',
 'next-iteration/kernel-sliced-selector/source/KernelSelectorFoundation.lean': '8b0ab9fabbc69910c641356040160cf34e6ab98b84eadb5de5f5f5779e1a81ed',
 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json': 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
 'next-iteration/lean435-kernel-comparison/run_comparison.py': '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
 'next-iteration/lean435-kernel-research/con-leche-release/LICENSE': '8b28515ffffc5c0fe2807d8ae3735b00b324d9b7ce807dd63ff6ac8922fbce7e',
 'next-iteration/lean435-migration/toolchain.json': 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
 'next-iteration/structural-nat-only-source-bridge/source/NatOnlySourceBridge.lean': 'a726ff16e93c10480559cec08cf01b9f692fa1f7735e4dea1b51dadd4d1f1554',
 'project/adwh-lean/scripts/check.py': 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result

def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)

def local_path(name):
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name,
            'Nonlocal input path: ' + name)
    path = ROOT.joinpath(*rel.parts)
    require(path.resolve().is_relative_to(ROOT), 'Escaping input path: ' + name)
    require(path.is_file() and not path.is_symlink(), 'Missing ordinary input: ' + name)
    return path

def pin_tuple(row):
    return tuple(row[key] for key in ('path', 'bytes', 'sha256'))

def identity(row, h):
    actual = h.binding(local_path(row['path']))
    require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
            'Input identity differs: ' + row['path'])
    return actual

def relative_binding(path, h):
    return {**h.binding(path), 'path': path.relative_to(ROOT).as_posix()}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def array_reference(path, field, h):
    value = read(path)[field]
    data = canonical(value)
    return {'source': relative_binding(path, h), 'json_field': field,
            'item_count': len(value), 'canonical_json_bytes': len(data),
            'canonical_json_sha256': hashlib.sha256(data).hexdigest()}

def review_identity(row, recovery, h):
    if row['path'].startswith('../'):
        matches = [r for r in recovery if r['original_context'] ==
                   {key: row[key] for key in ('path', 'bytes', 'sha256')}]
        require(len(matches) == 1, 'No exact historical external-context route')
        retained = matches[0]['retained_copy']
        require(all(retained[key] == row[key] for key in ('bytes', 'sha256')),
                'External context copy differs')
        return identity(retained, h)
    return identity(row, h)

def verify(rows, readonly=False):
    # The complete unchanged historical integrity checker is reused.
    return HISTORICAL.verify(rows, readonly)

def fingerprint(sources):
    # Identical permanent stage/policy rule: metadata or an attempt rename cannot reset it.
    body = {'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
            'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()



def check_source(row, guard):
    module = row['module']
    if module in MODULES[:2]:
        return PREVIOUS.check_source(row, guard)
    path = local_path(row['path'])
    code = guard.check_lean_source(path, path.read_text())
    require(HISTORICAL.imports(code) == row['imports'] == ['KernelCachedForward'],
            'Exact interpreter direct import')
    strict = [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]
    require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)', code) == strict * 12,
            'Twelve unchanged strict option scopes')
    require(not re.search(r'^\s*module\s*$|^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b', code, re.M),
            'Unexpected module or elaborator execution command')
    require(not re.search(r'^\s*(?:public\b|meta\s+import|import\s+all)|@\[(?:expose|no_expose)\]', code, re.M),
            'Unsupported visibility command')
    raw = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
    require(raw == RAW_REQUIRED[module] == row['raw_source_print_identifiers'],
            'Literal ordered interpreter print spellings')
    stack = []; roots = []; blocks = 0
    for line in code.splitlines():
        opening = re.fullmatch(r'namespace\s+(\S+)\s*', line)
        closing = re.fullmatch(r'end\s+(\S+)\s*', line)
        printed = re.fullmatch(r'#print\s+axioms\s+(\S+)\s*', line)
        if opening:
            require(not stack, 'Unexpected nested namespace in reviewed interpreter')
            stack.append(opening.group(1)); blocks += 1
        elif closing:
            require(stack and stack.pop() == closing.group(1), 'Exact closed namespace boundary')
        elif printed:
            require(stack, 'Expected original namespace at each proof report')
            name = printed.group(1)
            roots.append(name if name.startswith(('ADWH.', 'ConLeche.')) else stack[-1] + '.' + name)
    require(not stack and blocks == 18 and roots == REQUIRED[module] == row['fully_qualified_roots']
            and len(roots) == len(set(roots)) == 177,
            'Actual canonical roots, not physical-module prefixes')
    return code


def verify_new_scope(row, recovery, h):
    for field in ('author_inventory', 'source_audit', 'source_review'):
        identity(row[field], h)
    author_path = local_path(row['author_inventory']['path'])
    audit_path = local_path(row['source_audit']['path'])
    author = read(author_path); audit = read(audit_path)
    require(row['author_inputs'] == array_reference(author_path, 'inputs', h)
            and row['review_inputs'] == array_reference(audit_path, 'inputs', h)
            and len(author['inputs']) == author['input_count'] == row['author_input_count']
            and len(audit['inputs']) == audit['direct_input_count'] == row['review_input_count']
            and audit['author_input_count_verified'] == row['author_input_count']
            and audit['author_inventory'] == row['author_inventory']
            and audit['source_review'] == row['source_review']
            and audit['status'] == row['audit_status'] and audit['reviewer'] == row['reviewer'],
            'Exact separate original source-review scope: ' + row['name'])
    require(row['original_scope_or_selection_rebased'] is False,
            'Historical review scope must remain unchanged')
    for item in author['inputs'] + audit['inputs']:
        review_identity(item, recovery, h)
    return author, audit, author['inputs'] + audit['inputs']


def verify_span(data, desc):
    start, end = desc['start_byte'], desc['end_byte_exclusive']
    require(isinstance(start, int) and isinstance(end, int) and 0 <= start <= end <= len(data),
            'Bounded half-open source span')
    piece = data[start:end]
    first = data[:start].count(b'\n') + 1
    # The reviewed map anchors empty complements at their insertion first_line.
    last = max(first, data[:end].count(b'\n') + (0 if piece.endswith(b'\n') else 1))
    require(len(piece) == desc['bytes'] and hashlib.sha256(piece).hexdigest() == desc['sha256']
            and desc['first_line'] == first and desc['last_line_inclusive'] == last,
            'Exact source-span bytes, identity and reviewed empty-line convention')
    return piece


def verify_interpreter_assembly(manifest, h):
    mapping = read(ASSEMBLY / 'SOURCE-CORRESPONDENCE.json')
    census = read(ASSEMBLY / 'SOURCE-CENSUS.json')
    scope = read(ASSEMBLY / 'PRIVATE-AND-SCOPE-AUDIT.json')
    candidate_pin = {key: manifest['sources'][2][key] for key in ('path', 'bytes', 'sha256')}
    require(mapping['candidate'] == candidate_pin and mapping['direct_physical_input_count'] == 5
            and len(mapping['origins']) == 5 and mapping['internalized_import_count'] == 8
            and mapping['unchanged_complement_count_including_empty_spans'] == 13
            and mapping['new_boundary_comment_count'] == 10 and mapping['new_initial_comment_count'] == 1
            and mapping['foundation_complete_file_literal'] is True
            and mapping['mathematical_header_definition_body_proof_option_namespace_or_report_edits'] == 0
            and mapping['Core_and_Cached_source_changed'] is False
            and mapping['new_mathematical_declarations_or_lemmas'] == 0,
            'Exact reviewed interpreter assembly scope')
    candidate = local_path(candidate_pin['path']).read_bytes()
    output = bytearray(mapping['header_literal'].encode())
    require(verify_span(candidate, mapping['header_span']) == bytes(output), 'Exact ordinary initial comment')
    literal_headers = []; raw_reports = []; edits = complements = 0
    for index, row in enumerate(mapping['origins']):
        require(row['order'] == index + 1 and row['source'] == ASSEMBLY_INPUTS[index]
                and row['original_module'] == ASSEMBLY_INPUT_MODULES[index]
                and [entry['imported_module'] for entry in row['edits']] == INTERNAL_IMPORTS[index],
                'Exact original source/order and fulfilled imports')
        identity(row['source'], h); original = local_path(row['source']['path']).read_bytes()
        transformed = bytearray(); cursor = 0
        require(len(row['edits']) == row['edit_count']
                and len(row['unchanged_complements']) == row['unchanged_complement_count_including_empty_spans']
                == len(row['edits']) + 1, 'Exhaustive source partition')
        for number, change in enumerate(row['edits'], 1):
            old = change['original']; new = change['transformed']
            start, end = old['start_byte'], old['end_byte_exclusive']
            require(cursor <= start <= end <= len(original)
                    and verify_span(original, old) == change['before'].encode()
                    and re.fullmatch(r'import \S+\n', change['before'])
                    and change['before'] == 'import ' + change['imported_module'] + '\n'
                    and old['first_line'] == old['last_line_inclusive'] == number
                    and change['after'] == '-- [assembly import internalized] ' + change['before']
                    and change['kind'] == 'internalize_import_as_literal_line_comment',
                    'Only the exact leading import line is internalized')
            transformed.extend(original[cursor:start])
            require(new['start_byte'] == len(transformed), 'Transformed import start')
            transformed.extend(change['after'].encode())
            require(new['end_byte_exclusive'] == len(transformed), 'Transformed import end')
            cursor = end; edits += 1
        transformed.extend(original[cursor:]); transformed = bytes(transformed)
        require(len(transformed) == row['body']['bytes']
                and hashlib.sha256(transformed).hexdigest() == row['body']['sha256'], 'Full transformed source')
        inverse = transformed
        for change in reversed(row['edits']):
            new = change['transformed']; start, end = new['start_byte'], new['end_byte_exclusive']
            require(verify_span(transformed, new) == change['after'].encode()
                    and inverse[start:end] == change['after'].encode(), 'Exact inverse import span')
            inverse = inverse[:start] + change['before'].encode() + inverse[end:]
        require(inverse == original and row['complete_forward_and_inverse_reconstruction_verified'] is True
                and row['all_non_import_bytes_literal'] is True,
                'Full inverse reconstruction preserves every original source byte')
        require(row['entire_original_file_literal'] is (index == 0), 'Complete Foundation file remains literal')
        banner, body, footer = row['banner'], row['body'], row['footer']
        require(banner['physical_start_byte'] == len(output), 'Exact banner start')
        output.extend(banner['literal'].encode())
        require(banner['physical_end_byte_exclusive'] == len(output) == body['physical_start_byte'],
                'Exact banner end and physical body start')
        body_start = len(output)
        old_cursor = new_cursor = 0
        for number, gap in enumerate(row['unchanged_complements']):
            old, new = gap['original'], gap['transformed']
            old_stop = row['edits'][number]['original']['start_byte'] if number < len(row['edits']) else len(original)
            new_stop = row['edits'][number]['transformed']['start_byte'] if number < len(row['edits']) else len(transformed)
            require((old['start_byte'], old['end_byte_exclusive']) == (old_cursor, old_stop)
                    and (new['start_byte'], new['end_byte_exclusive']) == (new_cursor, new_stop)
                    and verify_span(original, old) == verify_span(transformed, new),
                    'Complete literal unchanged complement including empty spans')
            require(gap['physical_start_byte'] == body_start + new_cursor
                    and gap['physical_end_byte_exclusive'] == body_start + new_stop,
                    'Exact complement physical relocation')
            if number < len(row['edits']):
                old_cursor = row['edits'][number]['original']['end_byte_exclusive']
                new_cursor = row['edits'][number]['transformed']['end_byte_exclusive']
            complements += 1
        for change in row['edits']:
            require(change['physical_start_byte'] == body_start + change['transformed']['start_byte']
                    and change['physical_end_byte_exclusive'] == body_start + change['transformed']['end_byte_exclusive'],
                    'Exact edit physical relocation')
        output.extend(transformed)
        require(body['physical_end_byte_exclusive'] == footer['physical_start_byte'] == len(output),
                'Exact physical body/footer boundary')
        output.extend(footer['literal'].encode())
        require(footer['physical_end_byte_exclusive'] == len(output), 'Exact footer end')
        literal_headers.extend(re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', original))
        raw_reports.extend(re.findall(rb'^\s*#print\s+axioms\s+(\S+)', original, re.M))
        require(row['ordered_report_roots'] == ASSEMBLY_INPUT_ROOTS[index]
                and row['report_count'] == len(ASSEMBLY_INPUT_ROOTS[index]), 'Original ordered report scope')
    require(bytes(output) == candidate and edits == 8 and complements == 13,
            'Complete exact five-input forward reconstruction')
    require(literal_headers == re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', candidate)
            and len(literal_headers) == 183
            and raw_reports == re.findall(rb'^\s*#print\s+axioms\s+(\S+)', candidate, re.M)
            and len(raw_reports) == 177, 'All theorem headers and report bytes remain literal')
    require(scope['namespace_block_count'] == 18 and scope['private_theorem_header_count'] == 6
            and scope['strict_option_occurrence_count'] == 36
            and scope['public_named_declaration_count'] == 231
            and scope['public_theorem_header_count'] == 177 and scope['all_theorem_header_count'] == 183
            and len(scope['cross_origin_private_spelling_occurrences']) == 6
            and all(x['private_namespace_is_current_or_open'] is False for x in scope['cross_origin_private_spelling_occurrences'])
            and scope['explicit_attribute_instance_syntax_or_initializer_commands'] == []
            and scope['explicit_generated_private_auxiliary_or_matcher_name_references'] == []
            and scope['duplicate_public_textual_declaration_names'] == [],
            'Separate reviewed namespace, private-name, and global-environment scope')
    require(census['selected_physical_sources'] == [{k: r[k] for k in ('path', 'bytes', 'sha256')} for r in manifest['sources']]
            and census['ordered_report_counts'] == [2, 6, 177]
            and census['ordered_report_count'] == census['distinct_report_count'] == 185
            and census['source_bytes'] == 618132 and census['physical_owner_count'] == 3
            and census['ordinary_output_count'] == 6
            and census['current_file_convention_logical_origins'] == manifest['logical_origins']
            and census['current_file_convention_logical_origin_count'] == 28,
            'Exact complete current source/import/root/origin census')
    for actual, row in zip(census['physical_modules'], manifest['sources']):
        require(actual['module'] == row['module'] and actual['imports'] == row['imports']
                and actual['ordered_reports'] == row['fully_qualified_roots'], 'Full rooted owner census')
    return {'complete_forward_inverse_input_count': 5, 'import_comment_edits': 8,
            'literal_complements_including_empty': 13, 'literal_theorem_headers': 183,
            'literal_proof_reports': 177, 'namespace_blocks': 18, 'private_headers': 6,
            'whole_foundation_bytes_literal': 119150,
            'source_correspondence': relative_binding(ASSEMBLY / 'SOURCE-CORRESPONDENCE.json', h)}


def verify_sdk_and_history(manifest, recovery, h):
    sdk = read(ASSEMBLY / 'SDK-NAME-RESOLUTION-CONTEXT.json')
    require(len(sdk['whole_file_pairs']) == 2 and len(sdk['literal_intervals']) == 3
            and sdk['SDK_files_are_context_only_not_selected_compilation_inputs'] is True,
            'Exact new SDK context, not mathematical imports')
    for pair in sdk['whole_file_pairs']:
        actual = review_identity(pair['original'], recovery, h)
        retained = identity(pair['retained_copy'], h)
        require(all(actual[k] == retained[k] for k in ('path', 'bytes', 'sha256')),
                'Exact external tuple selects its original whole-file copy')
    for interval in sdk['literal_intervals']:
        identity(interval['source'], h)
        data = local_path(interval['source']['path']).read_bytes()
        piece = verify_span(data, interval)
        lines = data.splitlines(keepends=True)
        require(piece == interval['text'].encode()
                and interval['start_byte'] == len(b''.join(lines[:interval['start_line'] - 1]))
                and interval['end_byte_exclusive'] == len(b''.join(lines[:interval['end_line_inclusive']])),
                'Exact SDK text, line and byte interval')
    history = read(ASSEMBLY / 'HISTORICAL-REVIEW-SCOPES.json')
    require(history['scope_count'] == len(history['scopes']) == 3
            and history['nested_original_input_arrays_or_source_statuses_rebased'] is False
            and history['new_assembly_independent_review'] == 'pending',
            'Frozen author scope history and later independent review remain separate')
    expected = [read(PREDECESSOR / 'source-manifest.json')['new_assembly_review']] + manifest['new_separate_review_scopes'][:2]
    for row, required in zip(history['scopes'], expected):
        require(row['author_inventory'] == required['author_inventory']
                and row['independent_audit'] == required['source_audit']
                and row['independent_review'] == required['source_review']
                and row['original_scope_selection_or_status_rebased'] is False,
                'Exact preserved immediate source scope')
        for descriptor in row['unchanged_input_arrays']:
            identity(descriptor['source'], h)
            values = read(local_path(descriptor['source']['path']))[descriptor['json_field']]
            encoded = canonical(values)
            require(len(values) == descriptor['count']
                    and len(encoded) == descriptor['canonical_json_bytes']
                    and hashlib.sha256(encoded).hexdigest() == descriptor['canonical_json_sha256'],
                    'Original source-review array remains exact')
    prior = read(ASSEMBLY / 'PRIOR-ACCEPTANCE-CONTEXT.json')
    require(prior['prior_acceptance_transferred_to_new_185_selection'] is False
            and prior['compiled_objects_selected_or_reused'] is False
            and prior['old_source_key_or_marker_reset'] is False
            and prior['larger_selection_timing_or_resource_fit_inferred'] is False,
            'Prior actual134 evidence remains a separate consumed selection')
    for row in prior['evidence']:
        identity(row, h)


def preflight(args, h, guard):
    # The immutable consumed Foundation validator validates its own complete35 scope.
    # Its run/main is never called, and none of its selection globals is changed.
    previous_plan = PREVIOUS.preflight(args, h, guard)
    previous_manifest = read(PREDECESSOR / 'source-manifest.json')
    manifest = read(MANIFEST)
    require(manifest['format'] == MANIFEST_FORMAT
            and manifest['status'] == 'frozen_ready_for_independent_root_control_review'
            and manifest['policy'] == POLICY == PREVIOUS.POLICY == HISTORICAL.POLICY
            and manifest['module_order'] == MODULES and manifest['prepared_objects'] == []
            and manifest['export_targets'] == [] and manifest['ordered_report_counts'] == [2, 6, 177]
            and manifest['required_axiom_report_count'] == manifest['required_unique_axiom_name_count'] == 185
            and manifest['selected_physical_source_bytes'] == 618132 and manifest['expected_artifact_count'] == 6,
            'Fresh exact three-owner185 closure')
    history = manifest['historical_context']
    require(pin_tuple(history['runner']) == PREVIOUS_RUNNER_PIN
            and pin_tuple(history['manifest']) == PREVIOUS_MANIFEST_PIN
            and history['validator'] == 'preflight' and history['historical_review_scope_count'] == 35
            and previous_manifest['current_total_separate_independent_review_scope_count'] == 35
            and manifest['historical_independent_review_scope_count'] == 35
            and manifest['current_total_separate_independent_review_scope_count'] == 38
            and manifest['historical_reviews_rebased'] is False,
            'All35 prior reviews plus three exact new independent scopes')
    require(set(history['exact_field_references']) == {'historical_context', 'ingredient_review_scopes',
            'overlapping_historical_ingredient_scopes', 'new_ingredient_scopes', 'new_assembly_review',
            'external_review_context_recovery'}, 'Complete original manifest field references')
    for field, reference in history['exact_field_references'].items():
        require(reference == array_reference(PREDECESSOR / 'source-manifest.json', field, h),
                'Exact original manifest field, not a rebased nested selection')
    recovery = manifest['external_review_context_recovery']
    require(recovery == EXTERNAL_RECOVERY and len(recovery) == 8
            and recovery[:6] == previous_manifest['external_review_context_recovery'],
            'Six original exact external routes plus the two reviewed SDK-name copies')
    sources = []; seen = set()
    require(len(manifest['sources']) == 3 and manifest['sources'][:2] == previous_manifest['sources'][:2],
            'Exact unchanged reduced Core/Cached source rows')
    for row, module, pin in zip(manifest['sources'], MODULES, SOURCE_PINS):
        require(row['module'] == module and pin_tuple(row) == pin
                and row['imports'] == EXPECTED_IMPORTS[module]
                and row['raw_source_print_identifiers'] == RAW_REQUIRED[module]
                and row['fully_qualified_roots'] == REQUIRED[module]
                and row['module_format'] is False and row['expected_default_output_suffixes'] == ['.olean', '.ilean'],
                'Exact selected source and canonical ordered reports')
        require(all(name in seen or name == 'Init' or name.startswith(('Init.', 'Std.')) for name in row['imports']),
                'Unselected or forward experimental import')
        check_source(row, guard)
        sources.append({**identity(row, h), 'module': module, 'imports': row['imports']}); seen.add(module)
    require(len(set(n for names in REQUIRED.values() for n in names)) == 185
            and sum(r['bytes'] for r in sources) == 618132 and manifest['source_fingerprint'] == fingerprint(sources),
            'Exact source/root counts and unchanged permanent fingerprint rule')
    require(manifest['new_separate_review_scopes'] == NEW_SCOPE_CONTRACTS
            and len({pin_tuple(r['source_audit']) for r in NEW_SCOPE_CONTRACTS}) == 3
            and all(r['source_audit']['path'] not in {x['path'] for x in previous_manifest['controls']}
                    for r in NEW_SCOPE_CONTRACTS),
            'Three new exact audit identities, with no double counting of overlapping input arrays')
    inputs = []; documents = []
    for row in NEW_SCOPE_CONTRACTS:
        author, audit, rows = verify_new_scope(row, recovery, h)
        inputs.extend(rows); documents.append((author, audit))
    trace_author, trace_audit = documents[0]
    bridge_author, bridge_audit = documents[1]
    assembly_author, assembly_audit = documents[2]
    require(trace_author['new_sources'] == trace_audit['new_sources'] == ASSEMBLY_INPUTS[1:4]
            and trace_audit['known_material_source_blocker'] is None
            and trace_audit['historical_scopes_rebased'] is False
            and trace_audit['author_source_or_metadata_modified'] is False
            and bridge_author['source'] == bridge_audit['source'] == ASSEMBLY_INPUTS[4]
            and bridge_audit['new_public_report_count'] == 2
            and bridge_audit['known_material_source_blocker'] is None
            and bridge_audit['historical_source_or_review_scope_rebased'] is False
            and bridge_audit['author_source_or_metadata_modified'] is False,
            'Original full Trace49 and Bridge2 source scopes remain distinct')
    require(assembly_author['source'] == assembly_audit['source'] == {k: manifest['sources'][2][k] for k in ('path', 'bytes', 'sha256')}
            and assembly_author['baseline_proof_inputs'] == ASSEMBLY_INPUTS
            and assembly_audit['checks'] == ASSEMBLY_REVIEW_FACTS
            and assembly_audit['reviewer'] == '/root'
            and assembly_audit['all_mathematical_source_bytes_preserved_except_explicit_import_comments'] is True
            and assembly_audit['new_source_assembly_scope_separate_from_original_mathematical_reviews'] is True
            and assembly_audit['prior_acceptance_or_generated_private_identity_transferred'] is False
            and assembly_audit['author_or_historical_source_metadata_changed'] is False
            and assembly_audit['compiler_preflight_gate_or_mathematical_execution'] is False,
            'Exact independent1306-input interpreter assembly review')
    assembly = verify_interpreter_assembly(manifest, h)
    verify_sdk_and_history(manifest, recovery, h)
    for key in ('logical_origins', 'complete_origin_source_rows'):
        require(manifest[key][:len(previous_manifest[key])] == previous_manifest[key],
                'All original24 origin rows remain literal')
    require(manifest['logical_origins'][24:] == ASSEMBLY_INPUT_MODULES[1:]
            and manifest['complete_origin_source_rows'][24:] == ASSEMBLY_INPUTS[1:]
            and len(manifest['logical_origins']) == len(set(manifest['logical_origins'])) == 28
            and len(manifest['complete_origin_source_rows']) == 28
            and manifest['source_segment_count'] == previous_manifest['source_segment_count'] + 4 == 30,
            'Four added current project proof origins, with explicit inherited segment convention')
    for row in manifest['complete_origin_source_rows']:
        identity(row, h); inputs.append(row)
    require(manifest['root_only_preflight_and_run'] is True
            and manifest['all_current_cached_runtime_declarations_preserved'] is True
            and manifest['actual_reference_state_is_empty_CState'] is True
            and manifest['conditional_record_wrapper_only'] is True
            and manifest['non_atomic_trace_interpreter_and_query_interface_included'] is True
            and manifest['FN_construction_Typing_Driver_or_guards_selected'] is False
            and manifest['whole_query_cached_success_claimed'] is False
            and manifest['original_GroupChecked_claimed'] is False
            and manifest['stock_numeral_theorem_claimed'] is False
            and manifest['measured_cost_benefit_or_budget_fit_claimed_before_run'] is False,
            'Reusable non-atomic interpreter, without an unconstructed complete query claim')
    controls = [{**identity(row, h), 'role': row['role']} for row in manifest['controls']]
    require(len({r['path'] for r in controls}) == len(controls)
            and len({r['role'] for r in controls}) == len(controls), 'Unique exact control bindings')
    controls.append({**h.binding(MANIFEST), 'role': 'manifest'})
    bound = {row['path']: row for row in sources + controls}
    require(len(bound) == len(sources) + len(controls), 'No current source/control overlap')
    for row in previous_plan['sources'] + previous_plan['controls']:
        require(row['path'] in bound and all(bound[row['path']][k] == row[k] for k in ('bytes', 'sha256')),
                'Original source/control omitted from current read-only snapshot union')
    for row in inputs:
        actual = review_identity(row, recovery, h)
        require(actual['path'] in bound and all(bound[actual['path']][k] == actual[k] for k in ('bytes', 'sha256')),
                'Reviewed exact input omitted from current snapshot union')
    for path in [local_path(p) for p in NEW_FIXED] + [Path(__file__).resolve(), HERE / 'PROTOCOL.md',
            HERE / 'AUTHORING.md', HERE / 'CONTROL-CORRESPONDENCE.json', HERE / 'AUTHOR-CONTROLS.py',
            HERE / 'runner-metadata.py.txt', HERE / 'runner-main.py.txt']:
        require(str(path) in bound, 'Current exact control omitted: ' + str(path))
    require(manifest['snapshot_count_including_manifest'] == len(sources) + len(controls),
            'Complete snapshot count')
    verify(sources + controls + [previous_plan['compiler']] + previous_plan['runtime'])
    return {'sources': sources, 'controls': controls, 'roots': REQUIRED,
            'source_fingerprint': fingerprint(sources), 'compiler': previous_plan['compiler'],
            'runtime': previous_plan['runtime'], 'historical_context': history,
            'new_review_scopes': manifest['new_separate_review_scopes'],
            'external_context_recovery': recovery, 'owner_omissions': previous_plan['owner_omissions'],
            'primary_interval_counts': previous_plan['primary_interval_counts'],
            'logical_origins': manifest['logical_origins'], 'origin_sources': manifest['complete_origin_source_rows'],
            'foundation_assembly': previous_plan['foundation_assembly'], 'interpreter_assembly': assembly}


def audit_logs(required, stdout_path, stderr_path):
    # Exact unchanged axiom report parser, name order, whitelist and residual-output policy.
    return HISTORICAL.audit_logs(required, stdout_path, stderr_path)

def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    # Every historical no-retry directory is retained, with the consumed134 foundation appended.
    prior_names = ('TERMINAL_GATE_HERE', 'INTERFACE_GUARD137_MARKERS', 'WRAPPER_TERMINAL_PREDECESSOR',
        'CORE_WRAPPER_PREDECESSOR', 'FRAME_REPAIR_PREDECESSOR', 'TERMINAL_PREDECESSOR',
        'BOOLEAN_LITERAL_PREDECESSOR', 'WRAPPER_PREDECESSOR', 'HASLP_PREDECESSOR',
        'COMMENT_PREDECESSOR', 'OMISSION_PREDECESSOR', 'COST_PREDECESSOR', 'ACCEPTED_PREDECESSOR',
        'PREDECESSOR', 'STABLE_PREDECESSOR', 'ORIGINAL_GATE')
    predecessor_markers = [path / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
                           for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR]
                           + [getattr(HISTORICAL, name) for name in prior_names]]
    require(not attempt.exists() and not marker.exists() and not any(path.exists() for path in predecessor_markers),
            'Attempt or unchanged source closure already consumed')
    require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt,
              'executor': 'root', 'gate_author': 'nat_only_gap_review',
              'module_order': MODULES, 'physical_module_count': 3,
              'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,
              'distinct_logical_origin_count': 28, 'source_segment_count': 30,
              'logical_origins': plan['logical_origins'],
              'complete_origin_source_rows': plan['origin_sources'],
              'source_bindings': plan['sources'], 'controls': plan['controls'],
              'source_fingerprint': plan['source_fingerprint'],
              'historical_context': plan['historical_context'],
              'historical_independent_review_scope_count': 35,
              'new_separate_source_reviews': plan['new_review_scopes'],
              'total_separate_independent_review_scope_count': 38,
              'external_review_context_recovery': plan['external_context_recovery'],
              'owner_omission_correspondence': plan['owner_omissions'],
              'foundation_assembly_correspondence': plan['foundation_assembly'],
              'interpreter_assembly_correspondence': plan['interpreter_assembly'],
              'primary_source_interval_counts': plan['primary_interval_counts'],
              'historical_reviews_rebased': False,
              'source_origin_rows_precede_separate_proof_and_omission_overlays': True,
              'pure_evaluator_absent_from_selected_Core': True,
              'all_current_cached_runtime_declarations_preserved': True,
              'all_six_runtime_slots_and_Lift_APIs_retained': True,
              'compiler': plan['compiler'], 'compiler_release': '4.35.0',
              'compiler_commit': 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'runtime_libraries': plan['runtime'], 'constraints': {**POLICY, 'cpu_affinity': []},
              'execution_marker': None, 'required_prints': REQUIRED,
              'required_axiom_report_count': 185, 'required_unique_axiom_name_count': 185,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'each_physical_module_acceptance_is_all_or_nothing': True,
              'modules': [], 'seconds': None, 'peak_child_rss_kib': 0, 'artifacts': [],
              'expected_artifact_count': 6, 'prepared_objects': [], 'object_search_path': str(build),
              'all_selected_mathematical_sources_freshly_checked': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'exact_build_artifact_inventory': False,
              'Core_2_roots_checked': False, 'PropWhen_eq_of_toList_checked': False,
              'cached_memo_6_roots_checked': False,
              'generic_memo_relation_16_roots_checked': False,
              'eventual_empty_8_roots_checked': False,
              'eventual_terminal_trace_9_roots_checked': False,
              'eventual_scoped_functionality_from_actual_empty_runs_checked': False,
              'finite_terminal_trace_constructs_its_own_eventual_witness_checked': False,
              'literal_sort_forwarding_under_new_relational_validity_checked': False,
              'eventual_helper_51_roots_checked': False,
              'literal_contract_1_root_checked': False,
              'conditional_eventual_wrapper_41_roots_checked': False,
              'foundation_126_roots_checked': False,
              'non_atomic_trace_49_roots_checked': False, 'query_bridge_2_roots_checked': False,
              'interpreter_177_roots_checked': False,
              'actual_reference_state_is_empty_CState': True,
              'functionality_requires_actual_query_scoping': True,
              'generic_map_validity_covers_every_actual_entry': True,
              'terminal_fragment_only': False, 'conditional_record_wrapper_only': True,
              'non_atomic_trace_interpreter_and_query_interface_included': True,
              'FN_construction_Typing_Driver_or_guards_selected': False,
              'finite_trace_root_success_or_relation_premise': False,
              'whole_query_cached_forward_success_proved': False,
              'actual_installed_annotation_pins_discharged': False,
              'CSOK_or_EnvWF_discharged': False,
              'whole_structural_evaluator_normalization_proved': False,
              'original_GroupChecked_proved': False, 'optimized_kernel_installed': False,
              'full_original_driver_native_API_preserved': False,
              'native_BasisGen_or_Installed_compatibility_claimed': False,
              'later_original_driver_and_pure_client_restoration_required': True,
              'compiled_experimental_or_upstream_imports_reused': False,
              'exporter_or_native_program_or_counter_executed': False,
              'stock_numeral_theorem_proved': False, 'integrated_project_modified': False}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings'] + report['controls']:
            destination = (frozen / (row['module'] + '.lean') if 'module' in row else
                           inputs / Path(row['path']).relative_to(ROOT))
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            destination.chmod(0o444)
            row['snapshot'] = h.binding(destination)
            require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')), 'Snapshot differs')
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
        verify([row['snapshot'] for row in report['source_bindings'] + report['controls']], True)
        marker.parent.mkdir(exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': args.attempt,
                'source_fingerprint': plan['source_fingerprint'], 'source_bindings': report['source_bindings'],
                'controls': report['controls'], 'compiler': report['compiler'],
                'runtime_libraries': report['runtime_libraries'], 'policy': POLICY,
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for name in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(name, None)
        env['LEAN_IMPORT_WORKERS'] = '1'
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                       '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / (module + '.olean')),
                       '-i', str(build / (module + '.ilean')), module + '.lean']
            stdout_path, stderr_path = attempt / (module + '.stdout.log'), attempt / (module + '.stderr.log')
            record = {'module': module, 'command': command, 'status': 'running'}
            report['modules'].append(record)
            h.save(report_path, report)
            try:
                record.update(h.child(command, frozen, env, stdout_path, stderr_path, cpu, deadline))
            finally:
                for key, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                    if path.is_file():
                        record[key] = h.binding(path)
                audit = audit_logs(REQUIRED[module], stdout_path, stderr_path)
                record['axiom_audit'] = audit
                objects = all((build / (module + suffix)).is_file() for suffix in ('.olean', '.ilean'))
                record['required_outputs_present'] = objects
                good = (record.get('exit_code') == 0 and record.get('within_limits') is True
                        and audit['passed'] and objects)
                record['status'] = 'passed' if good else 'failed'
                report['observed_axiom_report_count'] = sum(m['axiom_audit']['observed_count'] for m in report['modules'])
                report['observed_unique_axiom_root_count'] = len({r['root'] for m in report['modules']
                                                                for r in m['axiom_audit']['raw_reports']})
                report['accepted_axiom_report_count'] = sum(m['axiom_audit']['observed_count']
                                                           for m in report['modules'] if m['status'] == 'passed')
                h.save(report_path, report)
            require(record['status'] == 'passed', 'Fresh module/axiom/output/resource failure: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            require(len(snapshots) == len(report['source_bindings']) + len(report['controls']), 'Incomplete snapshots')
            verify(snapshots, True)
            verify([m[key] for m in report['modules'] for key in ('stdout', 'stderr') if key in m])
            require(report['execution_marker'] is not None, 'No execution marker reserved')
            verify([report['execution_marker']], True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected = {str(build / (module + suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = ({row['path'] for row in report['artifacts']} == expected
                                                       and len(report['artifacts']) == 6)
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((m.get('sampled_tree_and_wait4_peak_rss_kib', 0)
                                          for m in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [m['module'] for m in report['modules']] == MODULES
                  and all(m['status'] == 'passed' for m in report['modules'])
                  and report['accepted_axiom_report_count'] == 185
                  and report['observed_unique_axiom_root_count'] == 185
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['Core_2_roots_checked'] = passed
        report['PropWhen_eq_of_toList_checked'] = passed
        report['cached_memo_6_roots_checked'] = passed
        report['generic_memo_relation_16_roots_checked'] = passed
        report['eventual_empty_8_roots_checked'] = passed
        report['eventual_terminal_trace_9_roots_checked'] = passed
        report['eventual_scoped_functionality_from_actual_empty_runs_checked'] = passed
        report['finite_terminal_trace_constructs_its_own_eventual_witness_checked'] = passed
        report['literal_sort_forwarding_under_new_relational_validity_checked'] = passed
        report['eventual_helper_51_roots_checked'] = passed
        report['literal_contract_1_root_checked'] = passed
        report['conditional_eventual_wrapper_41_roots_checked'] = passed
        report['foundation_126_roots_checked'] = passed
        report['non_atomic_trace_49_roots_checked'] = passed
        report['query_bridge_2_roots_checked'] = passed
        report['interpreter_177_roots_checked'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path), 'seconds': report['seconds'],
                      'peak_rss_kib': report['peak_child_rss_kib'], 'accepted_roots': report['accepted_axiom_report_count'],
                      'observed_roots': report['observed_axiom_report_count']}, sort_keys=True))
    return 0 if passed else 1


def main():
    global PREVIOUS, HISTORICAL
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True, help='Pinned Lean4.35.0 bin/lean; relocation permitted')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt), 'Invalid attempt name')
    # Bind current sources, metadata and manifest-listed controls before loading
    # any retained Python helper or historical validator. JSON is data only.
    manifest_before_import = read(MANIFEST)
    require(manifest_before_import['format'] == MANIFEST_FORMAT
            and manifest_before_import['policy'] == POLICY, 'Current pre-import manifest format/policy')
    for row in manifest_before_import['sources'] + manifest_before_import['controls']:
        path = local_path(row['path'])
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'Current source/control differs before import: ' + row['path'])
    for path, expected in NEW_FIXED.items():
        actual = local_path(path)
        require(sha(actual) == expected, 'Pinned current metadata differs before import: ' + path)
    for row in SOURCE_PINS + [PREVIOUS_RUNNER_PIN, PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Exact current/predecessor source before import')
    spec = importlib.util.spec_from_file_location('interpreter_historical_foundation134', PREDECESSOR / 'run_gate.py')
    PREVIOUS = importlib.util.module_from_spec(spec); spec.loader.exec_module(PREVIOUS)
    for row in [PREVIOUS.PREVIOUS_RUNNER_PIN, PREVIOUS.PREVIOUS_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable41 controls before import')
    spec = importlib.util.spec_from_file_location('interpreter_historical_pilot41', PREVIOUS.PREDECESSOR / 'run_gate.py')
    pilot = importlib.util.module_from_spec(spec); spec.loader.exec_module(pilot)
    for row in [pilot.HISTORICAL_RUNNER_PIN, pilot.HISTORICAL_MANIFEST_PIN]:
        path = local_path(row[0])
        require(path.stat().st_size == row[1] and sha(path) == row[2], 'Immutable111 controls before import')
    spec = importlib.util.spec_from_file_location('interpreter_historical_interface111', pilot.HISTORICAL_RUNNER)
    HISTORICAL = importlib.util.module_from_spec(spec); spec.loader.exec_module(HISTORICAL)
    # Only the dependency handles normally initialized by each old main are set.
    # No original source selection, manifest path, policy or review table changes.
    pilot.HISTORICAL = HISTORICAL
    PREVIOUS.PREVIOUS = pilot
    PREVIOUS.HISTORICAL = HISTORICAL
    require(PREVIOUS.POLICY == pilot.POLICY == HISTORICAL.POLICY == POLICY
            and PREVIOUS.ALLOWED == pilot.ALLOWED == HISTORICAL.ALLOWED == ALLOWED,
            'Unchanged complete resource and axiom policy')
    fixed = {}
    for group in [HISTORICAL.FIXED, pilot.NEW_FIXED,
                  {ROOT / p: value for p, value in PREVIOUS.NEW_FIXED.items()},
                  {ROOT / p: value for p, value in NEW_FIXED.items()}]:
        for path, expected in group.items():
            require(path not in fixed or fixed[path] == expected,
                    'Conflicting historical/current fixed identity: ' + str(path))
            fixed[path] = expected
    for path, expected in fixed.items():
        require(path.is_file() and not path.is_symlink() and sha(path) == expected,
                'Pinned helper/control differs before loading: ' + str(path))
    h = HISTORICAL.load(HISTORICAL.HELPER, 'cached_forward_resource_helper')
    guard = HISTORICAL.load(HISTORICAL.GUARD, 'cached_forward_source_guard')
    require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Resource/axiom helper contract')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
            'physical_module_count': 3, 'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,
            'distinct_logical_origin_count': 28, 'source_segment_count': 30,
            'required_axiom_report_count': 185, 'required_unique_axiom_name_count': 185,
            'expected_artifact_count': 6, 'prepared_objects': 0, 'source_fingerprint': plan['source_fingerprint'],
            'snapshot_count': len(plan['sources']) + len(plan['controls']),
            'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with HISTORICAL.LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
