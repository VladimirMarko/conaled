#!/usr/bin/env python3
"""Author source-only interpreter185 controls from immutable foundation134 text.

No retained runner, validator, generator, mathematical source, exporter, or
saved-result reader is imported or executed. This script writes exact source
text and JSON/hash correspondence; root alone may preflight or run the result.
"""
from pathlib import Path
import difflib
import hashlib
import json
import pprint
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = HERE.parent
BASE = ROOT / 'next-iteration/kernel-cached-eventual-foundation/gate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


def load(path):
    path = Path(path)
    return json.loads((path if path.is_absolute() else ROOT / path).read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def array_ref(path, field):
    values = load(path)[field]
    raw = canonical(values)
    return {'source': pin(path), 'json_field': field, 'item_count': len(values),
            'canonical_json_bytes': len(raw), 'canonical_json_sha256': sha(raw)}


def dump(name, data):
    path = HERE / name
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    return pin(path)


def span(data, start, end):
    piece = data[start:end]
    return {'start_byte': start, 'end_byte_exclusive': end,
            'bytes': len(piece), 'sha256': sha(piece)}


base_manifest = load(BASE / 'source-manifest.json')
base_runner = (BASE / 'run_gate.py').read_text()
source_inventory = load(PACKAGE / 'SOURCE-INVENTORY.json')
source_audit = load(PACKAGE / 'SOURCE-AUDIT.json')
source_census = load(PACKAGE / 'SOURCE-CENSUS.json')
mapping = load(PACKAGE / 'SOURCE-CORRESPONDENCE.json')
sdk = load(PACKAGE / 'SDK-NAME-RESOLUTION-CONTEXT.json')
assert base_manifest['current_total_separate_independent_review_scope_count'] == 35
assert source_inventory['input_count'] == 1305 and source_audit['direct_input_count'] == 1306
assert source_audit['status'] == 'passed_independent_source_assembly_review_not_compiled'

sources = [dict(row) for row in base_manifest['sources'][:2]]
proof = source_census['physical_modules'][2]
proof_text = (ROOT / proof['source']['path']).read_text()
sources.append({**proof['source'], 'module': proof['module'], 'imports': proof['imports'],
                'raw_source_print_identifiers': re.findall(r'^\s*#print\s+axioms\s+(\S+)', proof_text, re.M),
                'fully_qualified_roots': proof['ordered_reports'], 'module_format': False,
                'expected_default_output_suffixes': ['.olean', '.ilean']})
modules = [row['module'] for row in sources]
required = {row['module']: row['fully_qualified_roots'] for row in sources}
raw_required = {row['module']: row['raw_source_print_identifiers'] for row in sources}
assert [len(required[module]) for module in modules] == [2, 6, 177]
assert sum(row['bytes'] for row in sources) == 618132
assert len({root for names in required.values() for root in names}) == 185

scopes = []
scope_documents = []
for name, package, counts in [
        ('Trace49', ROOT / 'next-iteration/kernel-cached-eventual-trace', (1051, 1052)),
        ('QueryBridge2', ROOT / 'next-iteration/kernel-cached-eventual-query-bridge', (1264, 1267)),
        ('Interpreter185Assembly', PACKAGE, (1305, 1306))]:
    inventory = load(package / 'SOURCE-INVENTORY.json')
    audit = load(package / 'SOURCE-AUDIT.json')
    assert inventory['input_count'] == len(inventory['inputs']) == counts[0]
    assert audit['direct_input_count'] == len(audit['inputs']) == counts[1]
    assert audit['author_input_count_verified'] == counts[0]
    scopes.append({'name': name, 'author_inventory': pin(package / 'SOURCE-INVENTORY.json'),
                   'source_audit': pin(package / 'SOURCE-AUDIT.json'),
                   'source_review': audit['source_review'],
                   'author_inputs': array_ref(package / 'SOURCE-INVENTORY.json', 'inputs'),
                   'review_inputs': array_ref(package / 'SOURCE-AUDIT.json', 'inputs'),
                   'author_input_count': counts[0], 'review_input_count': counts[1],
                   'audit_status': audit['status'], 'reviewer': audit['reviewer'],
                   'original_scope_or_selection_rebased': False})
    scope_documents.extend([inventory, audit])
assert len({(r['source_audit']['path'], r['source_audit']['bytes'], r['source_audit']['sha256']) for r in scopes}) == 3
assert all(row['source_audit']['path'] not in {x['path'] for x in base_manifest['controls']} for row in scopes)

recovery = list(base_manifest['external_review_context_recovery'])
assert len(recovery) == 6
for pair in sdk['whole_file_pairs']:
    recovery.append({'original_context': pair['original'], 'retained_copy': pair['retained_copy'],
                     'only_exact_original_identity_may_use_this_recovery': True})
assert len(recovery) == 8
assert len({tuple(row['original_context'][k] for k in ('path', 'bytes', 'sha256')) for row in recovery}) == 8

bound = {}


def add(row):
    selected = {key: row[key] for key in ('path', 'bytes', 'sha256')}
    if selected['path'].startswith('../'):
        matches = [r for r in recovery if r['original_context'] == selected]
        assert len(matches) == 1, selected
        selected = matches[0]['retained_copy']
    assert not Path(selected['path']).is_absolute() and '..' not in Path(selected['path']).parts
    assert pin(selected['path']) == selected, selected['path']
    assert selected['path'] not in bound or bound[selected['path']] == selected, selected['path']
    bound[selected['path']] = selected


for row in base_manifest['sources'] + base_manifest['controls']:
    add(row)
add(pin(BASE / 'source-manifest.json'))
for document in scope_documents:
    for row in document['inputs']:
        add(row)
for scope in scopes:
    for key in ('author_inventory', 'source_audit', 'source_review'):
        add(scope[key])
for key in ('independent_static_checker', 'independent_static_result'):
    add(source_audit[key])
for row in sources:
    add(row)
for filename in ['AUTHOR-CONTROLS.py', 'runner-metadata.py.txt', 'runner-main.py.txt', 'PROTOCOL.md', 'AUTHORING.md']:
    add(pin(HERE / filename))

policy = base_manifest['policy']
fingerprint_body = {'stage': 'cached-forward-runs-and-licensed', 'policy': policy,
                    'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
source_key = sha(json.dumps(fingerprint_body, sort_keys=True, separators=(',', ':')).encode())
assert source_key != base_manifest['source_fingerprint']

def literal(value):
    return pprint.pformat(value, sort_dicts=True, width=120)

prefix = base_runner[:base_runner.index('HERE = Path(__file__)')]
prefix = prefix.replace('Fresh consolidated eventual foundation134.', 'Fresh consolidated non-atomic eventual interpreter185.')
globals_text = """HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-foundation/gate'
ASSEMBLY = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-interpreter185-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-interpreter185-manifest-v1'
PREVIOUS = None
HISTORICAL = None
"""
constants = {
    'POLICY': policy, 'ALLOWED': {'propext', 'Quot.sound', 'Classical.choice'},
    'PREVIOUS_RUNNER_PIN': tuple(pin(BASE / 'run_gate.py')[key] for key in ('path', 'bytes', 'sha256')),
    'PREVIOUS_MANIFEST_PIN': tuple(pin(BASE / 'source-manifest.json')[key] for key in ('path', 'bytes', 'sha256')),
    'MODULES': modules,
    'SOURCE_PINS': [tuple(row[key] for key in ('path', 'bytes', 'sha256')) for row in sources],
    'EXPECTED_IMPORTS': {row['module']: row['imports'] for row in sources},
    'REQUIRED': required, 'RAW_REQUIRED': raw_required,
    'ASSEMBLY_INPUTS': [row['source'] for row in mapping['origins']],
    'ASSEMBLY_INPUT_MODULES': [row['original_module'] for row in mapping['origins']],
    'ASSEMBLY_INPUT_ROOTS': [row['ordered_report_roots'] for row in mapping['origins']],
    'INTERNAL_IMPORTS': [[entry['imported_module'] for entry in row['edits']] for row in mapping['origins']],
    'ASSEMBLY_REVIEW_FACTS': source_audit['checks'],
    'NEW_SCOPE_CONTRACTS': scopes, 'EXTERNAL_RECOVERY': recovery,
    'NEW_FIXED': {path: row['sha256'] for path, row in sorted(bound.items())}}
for name, value in constants.items():
    globals_text += name + ' = ' + literal(value) + '\n'

common_helpers = base_runner[base_runner.index('def require('):base_runner.index('def check_source(')]
audit_logs = base_runner[base_runner.index('def audit_logs('):base_runner.index('def run(')]
old_run = base_runner[base_runner.index('def run('):base_runner.index('def main(')]
new_run = old_run
replacements = [
 ('# Every historical no-retry directory is retained, with the consumed41 pilot appended.',
  '# Every historical no-retry directory is retained, with the consumed134 foundation appended.'),
 ('for path in [PREDECESSOR, PREVIOUS.PREDECESSOR] + [getattr(HISTORICAL, name) for name in prior_names]]',
  'for path in [PREDECESSOR, PREVIOUS.PREDECESSOR, PREVIOUS.PREVIOUS.PREDECESSOR]\n'
  '                           + [getattr(HISTORICAL, name) for name in prior_names]]'),
 ("'gate_author': 'reflection_evidence_review'", "'gate_author': 'nat_only_gap_review'"),
 ("'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 8,", "'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,"),
 ("'distinct_logical_origin_count': 24, 'source_segment_count': 26,", "'distinct_logical_origin_count': 28, 'source_segment_count': 30,"),
 ("'historical_independent_review_scope_count': 31,", "'historical_independent_review_scope_count': 35,"),
 ("'total_separate_independent_review_scope_count': 35,", "'total_separate_independent_review_scope_count': 38,"),
 ("'foundation_assembly_correspondence': plan['foundation_assembly'],", "'foundation_assembly_correspondence': plan['foundation_assembly'],\n"
  "              'interpreter_assembly_correspondence': plan['interpreter_assembly'],"),
 ("'required_axiom_report_count': 134, 'required_unique_axiom_name_count': 134,", "'required_axiom_report_count': 185, 'required_unique_axiom_name_count': 185,"),
 ("'foundation_126_roots_checked': False,", "'foundation_126_roots_checked': False,\n"
  "              'non_atomic_trace_49_roots_checked': False, 'query_bridge_2_roots_checked': False,\n"
  "              'interpreter_177_roots_checked': False,"),
 ("'terminal_fragment_only': False, 'conditional_record_wrapper_only': True,", "'terminal_fragment_only': False, 'conditional_record_wrapper_only': True,\n"
  "              'non_atomic_trace_interpreter_and_query_interface_included': True,\n"
  "              'FN_construction_Typing_Driver_or_guards_selected': False,"),
 ("and report['accepted_axiom_report_count'] == 134", "and report['accepted_axiom_report_count'] == 185"),
 ("and report['observed_unique_axiom_root_count'] == 134", "and report['observed_unique_axiom_root_count'] == 185"),
 ("report['foundation_126_roots_checked'] = passed", "report['foundation_126_roots_checked'] = passed\n"
  "        report['non_atomic_trace_49_roots_checked'] = passed\n"
  "        report['query_bridge_2_roots_checked'] = passed\n"
  "        report['interpreter_177_roots_checked'] = passed")]
for before, after in replacements:
    assert new_run.count(before) == 1, before
    new_run = new_run.replace(before, after, 1)

metadata_text = (HERE / 'runner-metadata.py.txt').read_text()
main_text = (HERE / 'runner-main.py.txt').read_text()
runner_text = prefix + globals_text + '\n' + common_helpers + metadata_text + '\n' + audit_logs + new_run + main_text
runner_path = HERE / 'run_gate.py'
assert not runner_path.exists()
runner_path.write_text(runner_text)
runner_pin = pin(runner_path)

old_bytes, new_bytes = old_run.encode(), new_run.encode()
old_full, new_full = base_runner.encode(), runner_text.encode()
old_offset = old_full.index(old_bytes); new_offset = new_full.index(new_bytes)
edits = []; complements = []
for tag, a, b, c, d in difflib.SequenceMatcher(None, old_bytes, new_bytes, autojunk=False).get_opcodes():
    row = {'original': span(old_bytes, a, b), 'candidate': span(new_bytes, c, d),
           'original_file_start_byte': old_offset + a, 'original_file_end_byte_exclusive': old_offset + b,
           'candidate_file_start_byte': new_offset + c, 'candidate_file_end_byte_exclusive': new_offset + d}
    if tag == 'equal':
        assert old_bytes[a:b] == new_bytes[c:d]
        complements.append(row)
    else:
        row.update({'kind': tag, 'before': old_bytes[a:b].decode(), 'after': new_bytes[c:d].decode()})
        edits.append(row)
forward = old_bytes
for row in reversed(edits):
    a, b = row['original']['start_byte'], row['original']['end_byte_exclusive']
    assert forward[a:b] == row['before'].encode()
    forward = forward[:a] + row['after'].encode() + forward[b:]
assert forward == new_bytes
inverse = new_bytes
for row in reversed(edits):
    a, b = row['candidate']['start_byte'], row['candidate']['end_byte_exclusive']
    assert inverse[a:b] == row['after'].encode()
    inverse = inverse[:a] + row['before'].encode() + inverse[b:]
assert inverse == old_bytes
literal_execution_sections = []
for label, start, end in [
        ('snapshot_marker_affinity_environment_setup', '    h.save(report_path, report)\n    began = None', '        began = time.monotonic()'),
        ('complete_cumulative_timer_compiler_watchdog_and_module_audit', '        began = time.monotonic()', '    except BaseException as exc:'),
        ('postrun_readonly_runtime_artifact_affinity_and_elapsed_checks', '    finally:\n        try:\n            report[\'artifacts\']', '        passed = (')]:
    a = old_run.index(start); b = old_run.index(end, a)
    c = new_run.index(start); d = new_run.index(end, c)
    assert old_run[a:b] == new_run[c:d], label
    literal_execution_sections.append({'label': label,
        'original_file_span': span(old_full, old_offset + a, old_offset + b),
        'candidate_file_span': span(new_full, new_offset + c, new_offset + d)})
for label, text in [('common_identity_fingerprint_integrity_helpers', common_helpers),
                    ('unchanged_axiom_audit_delegation', audit_logs)]:
    raw = text.encode(); a = old_full.index(raw); c = new_full.index(raw)
    literal_execution_sections.append({'label': label, 'original_file_span': span(old_full, a, a + len(raw)),
                                       'candidate_file_span': span(new_full, c, c + len(raw))})

correspondence = dump('CONTROL-CORRESPONDENCE.json', {
    'format': 'adwh-interpreter185-from-consumed-foundation134-controls-v1',
    'status': 'source_only_controls_awaiting_independent_root_review',
    'baseline_runner': pin(BASE / 'run_gate.py'), 'baseline_manifest': pin(BASE / 'source-manifest.json'),
    'baseline_control_review': pin(BASE / 'INDEPENDENT-CONTROL-REVIEW.md'),
    'baseline_control_audit': pin(BASE / 'STATIC-INDEPENDENT-CONTROL-AUDIT.json'),
    'candidate_runner': runner_pin,
    'source_of_new_metadata': pin(HERE / 'runner-metadata.py.txt'),
    'source_of_new_bootstrap': pin(HERE / 'runner-main.py.txt'),
    'run_block_original_file_span': span(old_full, old_offset, old_offset + len(old_bytes)),
    'run_block_candidate_file_span': span(new_full, new_offset, new_offset + len(new_bytes)),
    'run_block_exact_logical_replacement_count': len(replacements),
    'run_block_logical_replacements': [{'before': a, 'after': b} for a, b in replacements],
    'run_block_actual_edit_count': len(edits), 'run_block_actual_edits': edits,
    'run_block_unchanged_complement_count': len(complements), 'run_block_unchanged_complements': complements,
    'complete_run_block_forward_and_inverse_verified': True,
    'whole_run_block_literal_claimed': False,
    'literal_execution_sections': literal_execution_sections,
    'resource_limits_default_options_compiler_flags_timer_watchdog_affinity_and_three_axioms_changed': False,
    'permanent_stage_or_fingerprint_policy_changed': False,
    'additional_predecessor_marker_directory': 'next-iteration/kernel-cached-eventual-foundation/gate',
    'all_prior_marker_directories_retained': True,
    'metadata_only_validation_chain': ['new185', 'unchanged134', 'unchanged41', 'unchanged111'],
    'old_run_or_main_called': False,
    'old_selection_policy_manifest_or_review_globals_modified': False,
    'old_dependency_handles_initialized_as_in_their_original_main': True,
    'historical_review_scope_count': 35, 'new_exact_independent_audit_scopes': 3,
    'total_distinct_review_scope_count': 38,
    'external_tuple_routes': 8, 'old_six_external_tuple_routes_unchanged': True,
    'current_sources_and_metadata_bound_before_any_retained_import': True,
    'raw_print_names_and_actual_namespace_qualified_roots_separate': True,
    'physical_module_acceptance_all_or_nothing': True,
    'author_imported_AST_checked_preflighted_or_executed_runner_or_math': False})

add(runner_pin); add(correspondence)
for row in scopes:
    assert row['source_audit']['path'] in bound and row['source_review']['path'] in bound
source_paths = {row['path'] for row in sources}
controls = [{**row, 'role': f'bound-input-{index:04d}'} for index, row in enumerate(
    [bound[path] for path in sorted(bound) if path not in source_paths], 1)]
assert len({row['path'] for row in controls}) == len(controls)
assert all(not row['path'].endswith(('.olean', '.ilean', '.c', '.o', '.so')) for row in controls)
assert not any(row['path'].endswith('/CONTROL-CORRESPONDENCE-DRAFT.json') for row in controls)
historical_fields = ['historical_context', 'ingredient_review_scopes',
                     'overlapping_historical_ingredient_scopes', 'new_ingredient_scopes',
                     'new_assembly_review', 'external_review_context_recovery']
manifest = {
    'format': 'adwh-kernel-cached-eventual-interpreter185-manifest-v1',
    'status': 'frozen_ready_for_independent_root_control_review',
    'policy': policy, 'module_order': modules, 'sources': sources, 'prepared_objects': [], 'export_targets': [],
    'ordered_report_counts': [2, 6, 177], 'required_axiom_report_count': 185,
    'required_unique_axiom_name_count': 185, 'selected_physical_source_bytes': 618132,
    'expected_artifact_count': 6,
    'logical_origins': base_manifest['logical_origins'] + [row['original_module'] for row in mapping['origins'][1:]],
    'complete_origin_source_rows': base_manifest['complete_origin_source_rows'] + [row['source'] for row in mapping['origins'][1:]],
    'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 12,
    'distinct_logical_origin_count': 28, 'source_segment_count': 30,
    'source_segment_count_convention': 'retained Foundation26 source segments plus four new physical proof-file segments',
    'historical_context': {'runner': pin(BASE / 'run_gate.py'), 'manifest': pin(BASE / 'source-manifest.json'),
        'validator': 'preflight', 'historical_review_scope_count': 35,
        'exact_field_references': {field: array_ref(BASE / 'source-manifest.json', field) for field in historical_fields},
        'old_main_or_run_called': False, 'old_source_selection_or_review_arrays_mutated': False,
        'old_dependency_handles_initialized': True, 'old_complete_preflight_checks_retained': True},
    'historical_independent_review_scope_count': 35,
    'current_total_separate_independent_review_scope_count': 38,
    'historical_reviews_rebased': False, 'new_separate_review_scopes': scopes,
    'new_independent_review_scope_count': 3,
    'review_scope_deduplication': 'Only exact audit identity; overlapping input arrays are not additional review scopes',
    'external_review_context_recovery': recovery,
    'root_only_preflight_and_run': True, 'all_current_cached_runtime_declarations_preserved': True,
    'actual_reference_state_is_empty_CState': True, 'conditional_record_wrapper_only': True,
    'non_atomic_trace_interpreter_and_query_interface_included': True,
    'FN_construction_Typing_Driver_or_guards_selected': False,
    'whole_query_cached_success_claimed': False, 'original_GroupChecked_claimed': False,
    'stock_numeral_theorem_claimed': False, 'measured_cost_benefit_or_budget_fit_claimed_before_run': False,
    'source_fingerprint': source_key, 'controls': controls,
    'snapshot_count_including_manifest': len(sources) + len(controls) + 1,
    'unselected_stale41_draft_included': False}
manifest_pin = dump('source-manifest.json', manifest)
print(json.dumps({'runner': runner_pin, 'manifest': manifest_pin, 'correspondence': correspondence,
                  'source_fingerprint': source_key, 'controls': len(controls),
                  'snapshots_including_manifest': len(sources) + len(controls) + 1,
                  'run_logical_replacements': len(replacements), 'run_actual_edits': len(edits),
                  'run_unchanged_complements': len(complements)}, indent=2))
