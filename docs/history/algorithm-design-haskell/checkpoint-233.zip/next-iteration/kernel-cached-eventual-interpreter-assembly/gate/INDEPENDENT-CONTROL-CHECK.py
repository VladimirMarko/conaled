"""Independent root byte/AST review. Does not import any gate or helper."""
from pathlib import Path
import ast
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def sha(b): return hashlib.sha256(b).hexdigest()
def strict(pairs):
    d = {}
    for k, v in pairs:
        assert k not in d
        d[k] = v
    return d
def read(p): return json.loads(p.read_text(), object_pairs_hook=strict)
def check(r):
    p = ROOT / r['path']
    assert p.is_file() and not p.is_symlink(), str(p)
    b = p.read_bytes()
    assert (len(b), sha(b)) == (r['bytes'], r['sha256']), str(p)
    return b
def canonical(v): return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def literals(s):
    d = {}
    for n in ast.parse(s).body:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    try: d[t.id] = ast.literal_eval(n.value)
                    except (ValueError, TypeError): pass
    return d
def functions(s): return {n.name: n for n in ast.parse(s).body if isinstance(n, ast.FunctionDef)}
def function(s, name):
    n = functions(s)[name]
    return (''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno]).rstrip() + '\n\n').encode()
def span(b, r):
    a, z = r['start_byte'], r['end_byte_exclusive']
    assert 0 <= a <= z <= len(b)
    v = b[a:z]
    assert (len(v), sha(v)) == (r['bytes'], r['sha256'])
    return v

c = read(HERE / 'CONTROL-CORRESPONDENCE.json')
m = read(HERE / 'source-manifest.json')
old = check(c['baseline_runner']); new = check(c['candidate_runner'])
for k in ('baseline_manifest', 'baseline_control_review', 'baseline_control_audit'): check(c[k])
oldtext, newtext = old.decode(), new.decode()
oldrun = span(old, c['run_block_original_file_span'])
newrun = span(new, c['run_block_candidate_file_span'])
assert oldrun == function(oldtext, 'run') + b'\n' and newrun == function(newtext, 'run') + b'\n'
rebuilt = oldrun.decode()
assert len(c['run_block_logical_replacements']) == c['run_block_exact_logical_replacement_count'] == 14
for r in c['run_block_logical_replacements']:
    assert rebuilt.count(r['before']) == 1, r
    rebuilt = rebuilt.replace(r['before'], r['after'])
assert rebuilt.encode() == newrun
edits = c['run_block_actual_edits']; complements = c['run_block_unchanged_complements']
assert len(edits) == c['run_block_actual_edit_count'] == 24
assert len(complements) == c['run_block_unchanged_complement_count'] == 25
forward, inverse = oldrun, newrun
for e in reversed(edits):
    a, z = e['original']['start_byte'], e['original']['end_byte_exclusive']
    x, y = e['candidate']['start_byte'], e['candidate']['end_byte_exclusive']
    assert span(oldrun, e['original']) == e['before'].encode()
    assert span(newrun, e['candidate']) == e['after'].encode()
    forward = forward[:a] + e['after'].encode() + forward[z:]
    inverse = inverse[:x] + e['before'].encode() + inverse[y:]
assert forward == newrun and inverse == oldrun
pos = other = 0
for i, r in enumerate(complements):
    assert (pos, other) == (r['original']['start_byte'], r['candidate']['start_byte'])
    assert span(oldrun, r['original']) == span(newrun, r['candidate'])
    pos, other = r['original']['end_byte_exclusive'], r['candidate']['end_byte_exclusive']
    if i < len(edits):
        e = edits[i]
        assert (pos, other) == (e['original']['start_byte'], e['candidate']['start_byte'])
        pos, other = e['original']['end_byte_exclusive'], e['candidate']['end_byte_exclusive']
assert pos == len(oldrun) and other == len(newrun)
for rows, oldoff, newoff in [(edits, c['run_block_original_file_span']['start_byte'], c['run_block_candidate_file_span']['start_byte']), (complements, c['run_block_original_file_span']['start_byte'], c['run_block_candidate_file_span']['start_byte'])]:
    for r in rows:
        for k, off in [('original', oldoff), ('candidate', newoff)]:
            assert r[k + '_file_start_byte'] == off + r[k]['start_byte']
            assert r[k + '_file_end_byte_exclusive'] == off + r[k]['end_byte_exclusive']
assert len(c['literal_execution_sections']) == 5
for r in c['literal_execution_sections']:
    assert span(old, r['original_file_span']) == span(new, r['candidate_file_span'])
literal_names = ['require', 'sha', 'strict_object', 'read', 'local_path', 'pin_tuple', 'identity', 'relative_binding', 'canonical', 'array_reference', 'verify', 'fingerprint', 'audit_logs']
for name in literal_names:
    assert function(oldtext, name) == function(newtext, name), name
    assert ast.dump(functions(oldtext)[name], include_attributes=False) == ast.dump(functions(newtext)[name], include_attributes=False)
oldlit, lit = literals(oldtext), literals(newtext)
policy = {'Elab.async': False, 'autoImplicit': False, 'compiler_threads': 1, 'cumulative_wall_seconds': 30, 'default_heartbeats_recursion_and_compiler_options': True, 'lean_memory_mib': 1024, 'resident_memory_kib': 1048576, 'warningAsError': True}
assert lit['POLICY'] == oldlit['POLICY'] == m['policy'] == policy
assert lit['ALLOWED'] == oldlit['ALLOWED'] == {'propext', 'Quot.sound', 'Classical.choice'}
sources, controls = m['sources'], m['controls']
assert lit['MODULES'] == m['module_order'] == [r['module'] for r in sources]
assert len(sources) == 3 and sum(r['bytes'] for r in sources) == 618132
assert [tuple(r[k] for k in ('path', 'bytes', 'sha256')) for r in sources] == lit['SOURCE_PINS']
for r in sources + controls: check(r)
bound = {r['path']: (r['bytes'], r['sha256']) for r in sources + controls}
assert len(bound) == len(sources) + len(controls) == 1373
assert len(controls) == len({r['role'] for r in controls}) == 1370
assert m['snapshot_count_including_manifest'] == 1374
required, raw, imports = lit['REQUIRED'], lit['RAW_REQUIRED'], lit['EXPECTED_IMPORTS']
assert [len(required[n]) for n in lit['MODULES']] == [2, 6, 177]
assert len({n for rows in required.values() for n in rows}) == 185
seen = set()
for r in sources:
    b = check(r); name = r['module']
    assert re.findall(rb'^import (\S+)', b, re.M) == [x.encode() for x in imports[name]]
    assert r['imports'] == imports[name] and all(x in seen or x == 'Init' or x.startswith(('Init.', 'Std.')) for x in imports[name])
    assert re.findall(rb'^#print axioms (\S+)', b, re.M) == [x.encode() for x in raw[name]]
    assert r['raw_source_print_identifiers'] == raw[name] and r['fully_qualified_roots'] == required[name]
    seen.add(name)
key = sha(canonical({'stage': 'cached-forward-runs-and-licensed', 'policy': policy, 'sources': [{'module': r['module'], 'sha256': r['sha256']} for r in sources]}))
assert key == m['source_fingerprint'] == '6d1c0f24fe1c4f55b520bf9e52b95884dc9e964065a107d0ebc1fcc89fe6370d'
assert len(lit['NEW_FIXED']) == 1371
for p, digest in lit['NEW_FIXED'].items():
    assert p in bound and sha((ROOT / p).read_bytes()) == digest == bound[p][1]
recovery = lit['EXTERNAL_RECOVERY']
assert recovery == m['external_review_context_recovery'] and len(recovery) == 8
routes = {}
for row in recovery:
    assert row['only_exact_original_identity_may_use_this_recovery'] is True
    assert check(row['original_context']) == check(row['retained_copy'])
    a, b = row['original_context'], row['retained_copy']
    routes[tuple(a[k] for k in ('path', 'bytes', 'sha256'))] = b
scopes = lit['NEW_SCOPE_CONTRACTS']
assert scopes == m['new_separate_review_scopes'] and len(scopes) == 3
scope_counts = []
for s in scopes:
    for k in ('author_inventory', 'source_audit', 'source_review'): check(s[k])
    pair = []
    for k in ('author_inputs', 'review_inputs'):
        d = s[k]; a = json.loads(check(d['source']))[d['json_field']]; b = canonical(a)
        assert len(a) == d['item_count'] == len({r['path'] for r in a})
        assert (len(b), sha(b)) == (d['canonical_json_bytes'], d['canonical_json_sha256'])
        for r in a:
            resolved = routes.get(tuple(r[k] for k in ('path', 'bytes', 'sha256')), r)
            check(resolved)
            assert bound[resolved['path']] == (resolved['bytes'], resolved['sha256'])
        pair.append(len(a))
    scope_counts.append(pair)
assert scope_counts == [[1051, 1052], [1264, 1267], [1305, 1306]]
pm = json.loads(check(c['baseline_manifest']))
for r in pm['sources'] + pm['controls']:
    assert bound[r['path']] == (r['bytes'], r['sha256'])
assert recovery[:6] == pm['external_review_context_recovery']
assert m['logical_origins'][:24] == pm['logical_origins'] and len(set(m['logical_origins'])) == 28
assert m['complete_origin_source_rows'][:24] == pm['complete_origin_source_rows']
assert len(m['complete_origin_source_rows']) == 28 and m['source_segment_count'] == 30
for r in m['complete_origin_source_rows']: check(r)
assert m['historical_independent_review_scope_count'] == 35 and m['current_total_separate_independent_review_scope_count'] == 38
assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('exec', 'eval', 'compile', '__import__') for n in ast.walk(ast.parse(newtext)))
main = function(newtext, 'main').decode()
assert main.index('for row in manifest_before_import') < main.index('spec = importlib')
assert main.index('for path, expected in NEW_FIXED.items()') < main.index('spec = importlib')
assert main.index('for path, expected in fixed.items()') < main.index('h = HISTORICAL.load')
assert 'pilot.HISTORICAL = HISTORICAL' in main and 'PREVIOUS.PREVIOUS = pilot' in main and 'PREVIOUS.HISTORICAL = HISTORICAL' in main
result = {'status': 'passed_independent_static_control_review', 'source_fingerprint': key, 'selected_sources': 3, 'source_bytes': 618132, 'reports': 185, 'expected_artifacts': 6, 'controls': 1370, 'snapshots_including_manifest': 1374, 'literal_common_function_AST_and_bytes': literal_names, 'run_replacement_groups': 14, 'run_byte_edits': 24, 'run_unchanged_complements': 25, 'literal_execution_sections': 5, 'complete_forward_inverse_and_partitions': True, 'new_review_scope_array_counts': scope_counts, 'previous_scope_count': 35, 'total_scope_count': 38, 'exact_external_routes': 8, 'fixed_current_identities': 1371, 'gate_or_helper_imported': False, 'compiler_or_mathematical_execution': False}
(HERE / 'INDEPENDENT-CONTROL-CHECK.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
