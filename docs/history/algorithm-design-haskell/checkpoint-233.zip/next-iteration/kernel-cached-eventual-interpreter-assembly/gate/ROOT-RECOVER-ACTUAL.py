"""Root literal durability recovery for the consumed interpreter185 attempt.

This checks existing bytes and captures paths; it does not rerun or accept a proof.
"""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPORT=HERE/'attempts/complete-01/report.json'
def binding(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def check(row):
    p=Path(row['path']);p=p if p.is_absolute() else ROOT/p
    actual=binding(p)
    assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256'])
    assert p.is_file() and not p.is_symlink()
    return p,actual
report_binding=binding(REPORT)
assert (report_binding['bytes'],report_binding['sha256'])==(1027241,'a8ab666d2f7d52d02248b3f9447c0dd8102309d7ed702f24b9bbcb1e655ce45e')
r=json.loads(REPORT.read_text())
assert r['status']=='failed' and r['source_fingerprint']=='6d1c0f24fe1c4f55b520bf9e52b95884dc9e964065a107d0ebc1fcc89fe6370d'
pairs=[]
for row in r['source_bindings']+r['controls']:
    p,a=check(row);q,b=check(row['snapshot'])
    assert p.read_bytes()==q.read_bytes() and not (q.stat().st_mode & 0o222)
    pairs.append({'canonical':a['path'],'snapshot':b['path'],'bytes':a['bytes'],'sha256':a['sha256'],'snapshot_mode_octal':oct(q.stat().st_mode & 0o777),'literal_bytes_compared':True})
assert len(pairs)==1374
logs=[]
for module in r['modules']:
    for key in ('stdout','stderr'):
        _,b=check(module[key]);logs.append(b)
assert len(logs)==6
marker,marker_binding=check(r['execution_marker'])
assert not (marker.stat().st_mode & 0o222)
recovery={'format':'adwh-interpreter185-current-attempt-durability-snapshot-recovery-v1','status':'all_actual_current_snapshot_and_canonical_bytes_equal','attempt':'complete-01','source_fingerprint':r['source_fingerprint'],'report':report_binding,'execution_marker':marker_binding,'snapshot_mapping_count':len(pairs),'snapshot_mappings':pairs,'raw_log_count':len(logs),'raw_logs':logs,'original_attempt_status_modified':False,'compiled_object_reuse_or_new_math_execution':False,'dedicated_saved_result_reader_executed':False}
out=HERE/'SNAPSHOT-RECOVERY.json';out.write_text(json.dumps(recovery,sort_keys=True,indent=2)+'\n')
receipt={'format':'adwh-root-interpreter185-actual-execution-receipt-v1','executor':'/root','status':r['status'],'source_fingerprint_consumed':r['source_fingerprint'],'report':report_binding,'actual_source_snapshot_recovery':binding(out),'independent_control_review':binding(HERE/'INDEPENDENT-CONTROL-REVIEW.md'),'independent_static_check':binding(HERE/'INDEPENDENT-CONTROL-CHECK.json'),'actual_seconds':r['seconds'],'peak_rss_kib':r['peak_child_rss_kib'],'accepted_report_count':r['accepted_axiom_report_count'],'observed_report_count':r['observed_axiom_report_count'],'failed_physical_owner':'KernelCachedEventualInterpreter','all_failed_owner_reports_rejected':True,'prepared_object_reuse':False,'no_unchanged_retry_allowed':True,'dedicated_complete_saved_result_reader_executed':False,'whole_query_or_installed_or_stock_numeral_result_proved':False}
receipt_path=HERE/'ROOT-EXECUTION-RECEIPT.json';receipt_path.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':recovery['status'],'snapshots':len(pairs),'logs':len(logs),'recovery':binding(out),'receipt':binding(receipt_path),'marker':marker_binding},sort_keys=True,indent=2))
