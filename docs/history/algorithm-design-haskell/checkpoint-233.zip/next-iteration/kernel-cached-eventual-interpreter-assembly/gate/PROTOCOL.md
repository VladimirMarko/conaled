# Fresh eventual interpreter: three owners and 185 reports

Only root may execute this runner, including its metadata preflight. The control
author has not imported, AST-checked, preflighted, or executed the runner or any
mathematical input. Root first reviews the complete controls, then uses the
metadata mode without `--run`. A subsequent
`--run --attempt complete-01 --lean <pinned-bin/lean>` selects the sole complete
fresh attempt. An attempt rename or metadata change does not reset a consumed
source key.

## Exact mathematical selection

The physical order is `KernelCompactCore`, `KernelCachedForward`, and
`KernelCachedEventualInterpreter`. Their source sizes are 208582, 202799, and
206751 bytes: 618132 bytes in total. Their ordered report counts are 2, 6, and
177: 185 distinct canonical names. The required outputs are precisely the six
fresh ordinary `.olean` and `.ilean` files for these owners.

Core and Cached are the unchanged reduced runtime owners used by the accepted
Foundation134 selection. The new proof owner contains the entire 119150-byte
Foundation file literally, followed by the three frozen Trace49 files and the
frozen QueryBridge2 file. Eight leading imports are internalized by literal
line-comment prefixes; an ordinary initial comment and ten boundary comments
are added. No theorem header, proof, definition, namespace, option, or report
text is otherwise changed. Five complete forward and inverse reconstructions,
eight edits, and thirteen unchanged complements (including empty complements)
are checked. Every physical endpoint uses the map's half-open
`physical_end_byte_exclusive` key. Empty spans retain the reviewed convention
that their last line is at least their insertion first line.

There are 28 current file-convention logical origins: 16 upstream and 12
project origins. The source-segment convention is the inherited Foundation26
segments plus four added proof-file segments, giving 30. The combined owner has
18 closed namespace blocks, 177 public theorem headers, six private theorem
headers, and twelve copies of the original three strict source options.

Raw print spellings and fully qualified report names are recorded separately.
The latter are derived from the actual original namespaces; they are not
prefixed with the physical module name. A failed combined proof owner accepts
none of its 177 reports, even if it prints a successful-looking prefix.
Generated private declaration identities can change when physical ownership
changes, so source review and earlier module acceptance do not replace the
fresh complete compilation.

The added scope is the non-atomic finite trace interpreter and its conditional
query interface. The finite trace constructs its own exact eventual backing
from genuine-empty-state runs before using generic memo forwarding. Its
arithmetic, beta/delta, Nat-recursion and returned-state obligations remain
explicit. QueryBridge2 requires a supplied finite trace, scope, frames, pins,
and a sufficient concrete knot bound; it does not construct the queens trace.
No FN construction, Typing, Driver, record guards, numerical backend, original
native installation, or stock numeral proof is selected. All whole-query,
installed-pin, original GroupChecked, and concrete numeral result flags remain
false.

## Historical evidence and distinct review scopes

The consumed Foundation134 runner and manifest are immutable predecessor
inputs. The new runner calls their unchanged metadata `preflight`, which in
turn retains the complete unchanged Pilot41 and Interface111 validation chain.
No predecessor `main` or `run` is called. Only the dependency handles ordinarily
initialized by those old `main` functions are populated; no old selection,
policy, manifest path, review table, or source array is overwritten.

The Foundation selection's 35 distinct independent scopes stay exact. The new
layer separately binds Trace49's 1051/1052 author/review inputs, QueryBridge2's
1264/1267 inputs, and the interpreter assembly's 1305/1306 inputs. These three
audit identities are absent from the old control selection, so the complete
review census is 38. Overlapping input arrays are preserved verbatim and are
not counted as extra reviews. The original author records whose then-future
review status was pending remain unchanged; the later independent reviews are
separate inputs.

The manifest retains exact file and JSON-field references for the original
35-scope context. Both original SDK name-resolution files, all three literal
intervals, the private-name/environment audit, and the root's assembly checker
and result are retained. The checker is evidence only and is not executed by
the new runner. The same six historical external tuples remain authorized for
their exact retained copies; two exact SDK file tuples are added. No other
external path or arbitrary path remapping is permitted. All current sources,
metadata, review inputs, and predecessor controls are bound and checked before
any retained Python validator/helper is imported. Every selected canonical
input is included in the read-only snapshot union.

The actual Foundation134 acceptance and its consumed marker remain separate
evidence. Its 134 reports passed in 25.97892414099988 seconds. That result does
not establish correctness or timing for the larger 185-report selection, and
no prepared Foundation object is imported.

## Unchanged resource, compiler, and axiom policy

All three owners are freshly compiled under one cumulative 30-second wall
interval, one selected CPU, one compiler thread, one import worker, a 1024-MiB
Lean cap, and a 1048576-KiB process-tree/RSS cap. Default heartbeats, recursion
limits, and compiler options remain unchanged. The compiler flags are exactly
`-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`.
The compiler, five runtime libraries, source guard, axiom parser, resource
helper, environment cleaning, affinity, watchdog, snapshots, and post-run
integrity checks retain their original pins and behavior.

Core keeps its two inherited reviewed unused-simp linter exceptions. Cached
keeps its two strict option blocks. The combined proof owner keeps all twelve
literal strict option blocks. No new resource, linter, compiler, or source
exception is introduced. No C/native program, exporter, counter, or old
experimental object is executed or imported.

The permanent source fingerprint retains the
`cached-forward-runs-and-licensed` stage and the exact policy plus ordered
module/hash rule. Before the first compiler child the runner checks every
inherited no-retry directory and adds the consumed Foundation134 directory,
then reserves an exclusive read-only marker for the current source key. All
three owners share the same deadline; no per-owner budget or partial retry is
available.

Acceptance requires all 185 distinct ordered axiom reports, only `propext`,
`Quot.sound`, and `Classical.choice`, empty stderr, no residual diagnostic
stdout, the exact six fresh artifacts, unchanged canonical inputs/snapshots/
runtime/marker, successful affinity restoration, elapsed time at most 30
seconds, and RSS within the cap. Physical-owner acceptance is all-or-nothing.
No speedup or complete budget fit is assumed before the run.

## Explicit control correspondence

`CONTROL-CORRESPONDENCE.json` records fourteen logical run-block replacements,
their actual exact edit spans, all unchanged complements, and complete forward
and inverse reconstruction. The changes are author/selection/census/result
bookkeeping, 134-to-185 required reports, and the added predecessor marker
directory. The snapshot/marker/affinity setup, complete timer/compiler/watchdog
and module audit, and post-run integrity/artifact/elapsed checks are separately
recorded as literal byte spans. The common identity/fingerprint helpers and
axiom-audit delegation also remain literal. Whole-run-block identity is not
claimed. The new metadata and bootstrap source templates are independently
bound controls rather than hidden mutations of an old validator.
