# Actual inner-fuel induction

**Status: source-only candidate with a complete proposed proof body,
uncompiled; no gate selected.** The single proposed public root is
`KernelBranchInduction.natRuns_branches`. It derives an actual full-WHNF
run of the applied structural branch recursor, for every natural fuel
literal, to the corresponding `StructuralNatReference.branches` result.

The author is `regression_audit`. No existing source or control was edited.
No compiler, exporter, counter, native evaluator, checker, gate or preflight
was executed. Imported operational candidates retain their unaccepted
status until a complete fresh proof closure succeeds.

## The exact statement

The actual source expression is

`(branchesRec modulus child left columns right (natExpr fuel)) cursor`.

The result is the Nat literal for

`StructuralNatReference.branches m callback l c r fuel q`.

The five captured expressions are closed according to
`BranchParametersClosed`. The modulus and three parent-state expressions
have actual `NatRuns` results `m`, `l`, `c` and `r`. The cursor is an
arbitrary closed expression with an actual `NatRuns` result `q`. These
expressions remain in the actual source term throughout the proof. They
may contain unevaluated arithmetic; no syntactic replacement by literals
is inferred merely from equality of mathematical values.

The remaining child contract, `ChildRuns env child callback`, is pointwise
in three **actual closed argument expressions**, their three natural
results, and actual `NatRuns` evidence for those arguments. Its conclusion
is `NatRuns` for the actual three-argument application of `child`, with
result `callback l c r`.

Every `NatRuns` contains its own existential threshold. In particular the
child contract has the order “for each argument tuple, there exists a
threshold,” not a common threshold that works for every natural state.
It is a proposed input from the later smaller-depth induction, not a
denotation of expressions or a result supplied by native execution.

The theorem also retains the actual Nat/Bool recursor pins, arithmetic
operation guards, and separate stored guards for Nat equality and addition.
It does not discharge their installation or source-validity obligations.

## Noncircular induction

The proof performs induction on `fuel`, generalizing both `cursor : Expr`
and its natural result `q`, including their dependent closedness/run
evidence. The parent captures and callback stay fixed throughout this
inner fold.

At zero fuel, the accepted mathematical recurrence says the result is zero.
The proposed operational zero-fuel composition produces precisely that
literal, without invoking the child contract or a predecessor run.

At successor fuel, the mathematical `branches_succ` equation splits on
`q = 0`. The empty-cursor branch uses the actual cursor run to establish
the real equality test and selector result; it evaluates no child.

For a nonzero cursor, the proof constructs these exact source expressions
and their actual runs:

1. `bit = low modulus cursor`, with result `FirstOrderNat.low m q`.
2. The three state-update expressions, with the original OR, multiplication,
   modulus and right-shift formulas, from that actual bit run and the
   captured state runs.
3. The actual child application, from the pointwise `ChildRuns` contract
   instantiated at those still-unevaluated update expressions.
4. `rest = cursor - bit`, from actual binary subtraction composition.
5. The predecessor branch application at the smaller fuel, by the induction
   hypothesis instantiated at the exact closed `rest` expression and its
   proved Nat result.

The final branch-composition theorem consumes the independently obtained
cursor, child and predecessor threshold witnesses and produces the actual
parent run. Its Nat result is exactly the sum in the mathematical
`branches_succ` equation. There is no premise asserting a run of the current
selector, current branch call or whole counter. The predecessor retains the
same parent masks, and only its cursor changes, matching the source.

This closes the **inner** induction relative to the explicit pointwise child
contract. The contract is not claimed as an unconditional fact about an
arbitrary child expression. The outer count proof must supply it at a
strictly smaller depth.

## Closedness and substitution boundary

Five small private lemmas derive closedness of the actual binary, low and
three next-state expression trees. They inspect `Expr.looseBVarsBounded`
only and do not invoke an evaluator. This ensures both the child contract
and the generalized predecessor hypothesis receive the required exact
closed expressions.

The branch-head and selector layers already account for the actual Nat.rec
and Bool.casesOn substitutions and preserve the predecessor recursor under
the intermediate lambda. This induction does not duplicate or replace
those operational proofs. It continues to distinguish no loose bound
variables from full typing, ambient free-variable validity or correct
installed annotations.

## Knot fuel and the unchanged local loop

The result is an existential knot threshold, uniform over every larger
fuel and every ambient depth. At each finite induction step, only the
finitely many actual child witnesses are unpacked. Their thresholds need
not agree with each other or with witnesses at other states.

The branch-composition layer supplies the constant local bounds: one
iteration for zero fuel, two for an empty cursor at successor fuel, and
three for the nonempty selector/addition path. It has already included an
explicit proof that each bound fits the existing `whnfLoopFuel` definition
in its proposed full-WHNF corollaries. Arithmetic and recursive operands
use actual full-WHNF calls with their own defined local loops. This
induction introduces no new budget, option, monotonicity oracle or bound
on total search-tree work.

The claim remains about encoded **literal** branch fuel. Extending a source
wrapper with a nonliteral recursor major would need the corresponding
actual-major normalization bridge; that is not silently assumed here.

## Source connection and scope

The imported `StructuralNatReference` supplies the already established
ordinary Lean `branches_zero` and `branches_succ` equations. Its child
callback, source low-bit operation, state updates, subtraction and addition
match the reviewed `KernelStructuralBodies` templates. The primitive
reference's separate accepted pointwise equality and the actual export-tree
comparison remain the source-recognition provenance; installed annotated
identity is still a separate check.

The proof imports `KernelBranchComposition`, `KernelArithmeticRuns` and
`StructuralNatReference`. Relative to the branch-composition planning
closure, the last two are new dependencies and this new module is the
third addition: a prospective **37 modules, 118 printed roots and 158
default artifacts**. This is a planning census only. A selected gate must
bind its actual dependency variants and rebuild every selected new
mathematical module under the unchanged cumulative 30-second,
one-CPU/thread, 1-GiB/default-options policy. No compiled import reuse or
separate preparation exemption is authorized.

The outer count function heads and induction, complete program wrappers,
installed Nat/Bool/program annotations and guards, licensed cached-reducer
integration, and the concrete stock numerical theorem remain open. The
previous external native `ACCEPT` result is not a proof premise here.
