import KernelBranchComposition
import KernelArithmeticRuns
import StructuralNatReference

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual inner branch-fold normalization

The induction ranges over branch fuel and generalizes the exact closed cursor
expression together with its actual Nat-valued WHNF run. The recursive call
therefore receives the source's unevaluated rest-cursor expression directly.

The child contract is pointwise in actual closed argument expressions and
their actual runs. Every call may have its own threshold witness. In the
outer fold this contract must come from the strictly smaller depth; it is
not a premise that the current branch call or whole counter succeeds.

Source-only preparation. No evaluator, counter, gate or compiler has been
executed for this candidate, and all prospective dependencies remain subject
to a complete fresh proof gate and their exact source/installation guards.
-/

namespace ADWH.Experiments.Chapter15.KernelBranchInduction

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (NatRecPins app3)
open KernelBoolSelector (BoolPins)
open KernelStructuralBodies
open KernelStructuralHead (BranchParametersClosed)
open KernelArithmeticRuns (NatRuns ArithmeticPins)
open KernelBranchComposition (childApplication previousApplication
  branchThreshold emptySelectorThreshold nonemptySelectorThreshold)

/-- A contract for actual applications of the child expression. The
existential knot threshold remains inside each NatRuns conclusion. -/
def ChildRuns (env : Env) (child : Expr)
    (callback : Nat → Nat → Nat → Nat) : Prop :=
  ∀ (left columns right : Expr) (l c r : Nat),
    left.looseBVarsBounded 0 = true →
    columns.looseBVarsBounded 0 = true →
    right.looseBVarsBounded 0 = true →
    NatRuns env left l → NatRuns env columns c → NatRuns env right r →
    NatRuns env (app3 child left columns right) (callback l c r)

private theorem binary_closed (name : ConLeche.Name) (left right : Expr)
    (hl : left.looseBVarsBounded 0 = true)
    (hr : right.looseBVarsBounded 0 = true) :
    (binary name left right).looseBVarsBounded 0 = true := by
  change ((true && left.looseBVarsBounded 0) && right.looseBVarsBounded 0) = true
  rw [hl, hr]
  all_goals rfl

private theorem low_closed (modulus cursor : Expr)
    (hm : modulus.looseBVarsBounded 0 = true)
    (hq : cursor.looseBVarsBounded 0 = true) :
    (low modulus cursor).looseBVarsBounded 0 = true :=
  binary_closed natLandName cursor _ hq
    (binary_closed natModName _ modulus
      (binary_closed natSubName modulus cursor hm hq) hm)

private theorem nextLeft_closed (modulus left bit : Expr)
    (hm : modulus.looseBVarsBounded 0 = true)
    (hl : left.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextLeft modulus left bit).looseBVarsBounded 0 = true :=
  binary_closed natModName _ modulus
    (binary_closed natMulName _ (natExpr 2)
      (binary_closed natLorName left bit hl hb) rfl) hm

private theorem nextColumns_closed (columns bit : Expr)
    (hc : columns.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextColumns columns bit).looseBVarsBounded 0 = true :=
  binary_closed natLorName columns bit hc hb

private theorem nextRight_closed (right bit : Expr)
    (hr : right.looseBVarsBounded 0 = true)
    (hb : bit.looseBVarsBounded 0 = true) :
    (nextRight right bit).looseBVarsBounded 0 = true :=
  binary_closed natShiftRightName _ (natExpr 1)
    (binary_closed natLorName right bit hr hb) rfl

/-- The actual inner fold reaches the mathematical structural-reference
result for every fuel and every closed cursor expression with its proved
Nat result. No run of the current fold is an assumption. -/
theorem natRuns_branches (env : Env) (natPins : NatRecPins env)
    (boolPins : BoolPins env) (arithmeticPins : ArithmeticPins env)
    (modulus child left columns right : Expr) (m l c r : Nat)
    (callback : Nat → Nat → Nat → Nat)
    (closed : BranchParametersClosed modulus child left columns right)
    (modulusRun : NatRuns env modulus m)
    (leftRun : NatRuns env left l) (columnsRun : NatRuns env columns c)
    (rightRun : NatRuns env right r)
    (childCorrect : ChildRuns env child callback)
    (beqStored : natOpStored env natBeqName = true)
    (addStored : natOpStored env natAddName = true)
    (fuel : Nat) (cursor : Expr) (q : Nat)
    (cursorClosed : cursor.looseBVarsBounded 0 = true)
    (cursorRun : NatRuns env cursor q) :
    NatRuns env
      (.app (branchesRec modulus child left columns right (natExpr fuel)) cursor)
      (StructuralNatReference.branches m callback l c r fuel q) := by
  induction fuel generalizing cursor q with
  | zero =>
      rw [StructuralNatReference.branches_zero]
      exact ⟨9, KernelBranchComposition.runsAbove_branchesApply_zero env natPins
        modulus child left columns right cursor⟩
  | succ fuel ih =>
      rw [StructuralNatReference.branches_succ]
      by_cases empty : q = 0
      · rw [ite_eq_left empty]
        have cursorZero : NatRuns env cursor 0 := by
          simpa only [empty] using cursorRun
        obtain ⟨cursorThreshold, cursorAbove⟩ := cursorZero
        exact ⟨branchThreshold (emptySelectorThreshold cursorThreshold) + 1,
          KernelBranchComposition.runsAbove_branchesApply_succ_zero env natPins boolPins
            modulus child left columns right cursor fuel cursorThreshold
            closed cursorClosed beqStored cursorAbove⟩
      · rw [ite_eq_right empty]
        let bit := low modulus cursor
        have bitRun : NatRuns env bit (FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_low env arithmeticPins modulus cursor m q
            modulusRun cursorRun
        have bitClosed : bit.looseBVarsBounded 0 = true :=
          low_closed modulus cursor closed.modulus_closed cursorClosed
        have updatedLeft : NatRuns env (nextLeft modulus left bit)
            (((l ||| FirstOrderNat.low m q) * 2) % m) :=
          KernelArithmeticRuns.natRuns_nextLeft env arithmeticPins modulus left bit
            m l (FirstOrderNat.low m q) modulusRun leftRun bitRun
        have updatedColumns : NatRuns env (nextColumns columns bit)
            (c ||| FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_nextColumns env arithmeticPins columns bit
            c (FirstOrderNat.low m q) columnsRun bitRun
        have updatedRight : NatRuns env (nextRight right bit)
            ((r ||| FirstOrderNat.low m q) >>> 1) :=
          KernelArithmeticRuns.natRuns_nextRight env arithmeticPins right bit
            r (FirstOrderNat.low m q) rightRun bitRun
        have childRun : NatRuns env (childApplication modulus child left columns right cursor)
            (callback (((l ||| FirstOrderNat.low m q) * 2) % m)
              (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1)) :=
          childCorrect (nextLeft modulus left bit) (nextColumns columns bit)
            (nextRight right bit) (((l ||| FirstOrderNat.low m q) * 2) % m)
            (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1)
            (nextLeft_closed modulus left bit closed.modulus_closed closed.left_closed
              bitClosed)
            (nextColumns_closed columns bit closed.columns_closed bitClosed)
            (nextRight_closed right bit closed.right_closed bitClosed)
            updatedLeft updatedColumns updatedRight
        let rest := binary natSubName cursor bit
        have restRun : NatRuns env rest (q - FirstOrderNat.low m q) :=
          KernelArithmeticRuns.natRuns_binary env natSubName cursor bit q
            (FirstOrderNat.low m q) (q - FirstOrderNat.low m q)
            (Or.inr (Or.inl rfl)) arithmeticPins.sub cursorRun bitRun rfl
        have restClosed : rest.looseBVarsBounded 0 = true :=
          binary_closed natSubName cursor bit cursorClosed bitClosed
        have predecessorRun : NatRuns env
            (previousApplication modulus
              (branchesRec modulus child left columns right (natExpr fuel)) cursor)
            (StructuralNatReference.branches m callback l c r fuel
              (q - FirstOrderNat.low m q)) :=
          ih rest (q - FirstOrderNat.low m q) restClosed restRun
        obtain ⟨cursorThreshold, cursorAbove⟩ := cursorRun
        obtain ⟨childThreshold, childAbove⟩ := childRun
        obtain ⟨previousThreshold, previousAbove⟩ := predecessorRun
        exact ⟨branchThreshold
            (nonemptySelectorThreshold cursorThreshold childThreshold previousThreshold) + 1,
          KernelBranchComposition.runsAbove_branchesApply_succ_nonzero env natPins boolPins
            modulus child left columns right cursor fuel q
            (callback (((l ||| FirstOrderNat.low m q) * 2) % m)
              (c ||| FirstOrderNat.low m q) ((r ||| FirstOrderNat.low m q) >>> 1))
            (StructuralNatReference.branches m callback l c r fuel
              (q - FirstOrderNat.low m q))
            cursorThreshold childThreshold previousThreshold closed cursorClosed empty
            beqStored addStored cursorAbove childAbove previousAbove⟩

#print axioms natRuns_branches

end ADWH.Experiments.Chapter15.KernelBranchInduction
