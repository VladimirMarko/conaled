# Independent source review: actual inner branch-fold induction

**No mathematical/source-level blocker found in this uncompiled candidate.** The review concerns `KernelBranchInduction.natRuns_branches`, not acceptance of its still-uncompiled operational dependencies. Regression_audit authored the source; validity_contracts independently read its complete proof, the actual arithmetic and branch-composition interfaces, the structural recurrence, and the 17 bound source/control inputs. No Lean, compiler, preflight, gate, exporter, native evaluator or counter was executed.

## Exact reviewed contract

The source is 9,278 bytes, SHA256 `953da58e283617c0fbfdf24644e2847a8e94cf26970f196df979fcbb75ad8d3c`. Its one public theorem derives actual ConLeche full WHNF of the applied branch recursor at a literal natural fuel. The result is exactly `StructuralNatReference.branches m callback l c r fuel q`. All six theorem headers, the complete ChildRuns definition, three imports, strict options and single axiom-print name match the author's inventory literally.

The modulus, child and three captured masks are actual ConLeche expressions with the stated closedness. The modulus and masks also have actual Nat-valued runs. The cursor is an arbitrary closed expression with its own actual run to q. No mathematical equality is used to substitute a literal expression for an unevaluated operand. The theorem allows arbitrary natural modulus/state values, including modulus zero; it adds no board-width, expected-answer or count-fit premise.

`ChildRuns` is explicitly conditional. For each triple of actual closed argument expressions and their actual runs, it supplies a run of the actual child application to the callback result. Its existential knot threshold is inside that particular conclusion. It does not demand one uniform threshold for all states. The later outer-depth induction must prove this child contract from a strictly smaller depth; this file does not assert it for arbitrary child syntax.

## Induction and expression preservation

The proof inducts on inner fuel and generalizes cursor, q and their dependent closedness/run evidence. Captured parent masks and callback remain fixed. The zero-fuel branch uses the structural recurrence and the actual zero-recursor composition, yielding zero without using a child/predecessor result.

At successor fuel, the q=0 branch consumes the actual cursor run to establish the actual equality test and selector result. It does not evaluate the child. In the nonzero branch, low and all three state updates are actual syntax trees whose NatRuns follow from the arithmetic interfaces. The pointwise child contract receives those exact closed update expressions, not substituted literal arguments.

The predecessor cursor is exactly `binary natSubName cursor (low modulus cursor)`. Its run follows from actual subtraction composition. The IH is applied to that same closed expression, with fuel decreased from successor fuel to fuel and parent masks unchanged. Its result is exactly the predecessor summand in `branches_succ`. This is a genuine smaller-fuel induction; neither the current selector nor the current branch call nor the complete counter is assumed to run.

The final branch-composition theorem fixes the predecessor recursor at that smaller literal fuel. The cursor, child and predecessor witnesses are extracted separately and combined through the existing explicit threshold formula. The argument and result formulas match the source OR, multiplication, modulus, right shift, subtraction and addition. The imported structural zero/successor equations are bound to the accepted structural generic02 report; no compiled artifacts are reused by this review or authorized for a future gate.

## Closedness, guards and fuel

The five private lemmas prove only the required no-loose-bound-variable facts for binary/low/state-update expressions. The direct binary constructor equation and child conjunctions match the actual Expr templates. They do not establish typing, environment validity or ambient free-variable scoping.

The actual NatRecPins, BoolPins and ArithmeticPins remain premises, with separate stored Nat equality/addition guards. The inner proof does not discharge their installation. ArithmeticPins includes the power guard for its reusable arithmetic interface; this inner induction does not compute a power or use an exponent bound.

Each NatRuns is an existential threshold uniform over every larger knot fuel and every ambient depth. The proof combines only finitely many actual witnesses at each induction step. The imported branch layer supplies local-loop bounds 1, 2 and 3 for zero fuel, empty successor and nonempty successor respectively; its full-WHNF corollaries retain the unchanged fixed whnfLoopFuel obligation. This theorem does not reset or enlarge that local budget and makes no time/RSS bound on a complete search.

The recursor major in the conclusion is the literal `natExpr fuel`. A wrapper whose major is a nonliteral computation still needs its actual-major bridge; it is not supplied by the cursor generalization.

## Scope and remaining work

The author's 37-module, 118-root, 158-output census is a prospective separate-module dependency plan, not a selected gate or a claim that this closure fits the resource allowance. It retains explicitly historical Natrec05 and Bool04 references through its dependencies. Those references do not imply successful operational acceptance, and a future selected bundle/variant must be rebound and reviewed explicitly.

The remaining obligations include the outer count heads and induction, source wrapper/annotation recognition, actual installed guards, environment-validity/metatheory conditions and the licensed cached-reducer integration. This theorem does not turn the native ACCEPT result into a stock proof and does not prove the concrete cqueens16 numeral theorem. Any future execution must rebuild its complete selected mathematical closure under the unchanged cumulative30-second, one-CPU/thread, 1-GiB/default-options policy.
