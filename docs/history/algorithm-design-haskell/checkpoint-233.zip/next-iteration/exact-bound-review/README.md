# Exact contraction bounds and algebraic compression: read-only assessment

## Decision and scope

**The reviewed literature supplies a different certificate idea, but no presently justified Queens16 implementation under the fixed gates.** The useful idea is an exact rational bound on a normalized count with a known reference weight, followed by integer uniqueness. It could avoid certifying the existing cofactor stream. What is missing is a small, valid relaxation of the actual finite queens network that gives sufficiently tight bounds. Neither a suitable relaxation nor a compact signed/modular rank witness is exhibited here.

This is a narrow primary-source review dated 2026-10-24, not an exhaustive literature survey or an impossibility result. Only this new directory is written. No counter, replay, Lean compiler, numerical optimizer, matrix-rank computation, minimum-fill rerun, expanded board truth table, or compile-lock acquisition was performed. The conditions remain one CPU/thread, 30 seconds, 1 GiB, and at most 50,000 recorded claims. No new theorem or board count is claimed.

## What the primary sources establish

| Source | Relevant result and applicability boundary |
| --- | --- |
| **[S1] Ono, Zhang, Po, arXiv:2603.17856v1** | Bounds normalized local-observable expectations using necessary conditions on positive environment operators. Its explicit constructions concern translationally invariant matrix product states. The initial formulation ranges over positive boundary operators; useful higher-dimensional relaxations and a practical algorithm remain open in the discussion. This is not a supplied finite Queens16 partition-function bound. See II.1, equations (1)–(3), II.4, and III. |
| **[S2] Midha, Zhang, PRX Quantum 7, 033010 (2026)** | A cluster expansion bounds free-energy error under a sufficiently strong uniform decay condition on loop contributions, after belief-propagation normalization. The published Theorem III.1 is conditional; its experiments concern the Ising model. Section IV also exposes the increasing cluster-enumeration work. The published paper is used here, rather than adopting constants from its earlier arXiv appendix. |
| **[S3] Dostert, de Laat, Moustrou, arXiv:2001.00256v3** | Converts numerical semidefinite-programming output into exact rational or quadratic-field solutions, including boundary solutions. Section 3.3 checks affine equations and positive semidefiniteness exactly. The applications are packing bounds. This supports an external-proposal/exact-verification architecture, not the existence of a tight queens bound. |
| **[S4] Yang et al., arXiv:1708.08932v2** | Compression/decimation uses local tensor factorizations to count solutions of reversible classical circuits. Section III.1 uses SVD thresholds treated as zero at machine precision for counting. Section V.3 makes intermediate bond dimension central to cost. Numerical threshold decisions do not constitute exact kernel certificates. No queens-specific rank or resource result is supplied. |

These are useful papers. Their results do not establish that the required instance satisfies the hypotheses, that a certificate fits the claim budget, or that its complete source-linked proof fits the Lean gate.

## One concrete candidate: reference weight plus integer uniqueness

The following is this review's elementary certificate design, not a construction claimed by [S1]. Let `Z` denote the natural number of source-valid boards, and let `m > 0` be a proposed answer. Form the **symbolic disjoint union** of the board space and one reference point. Give the reference point weight `m`, each valid board weight one, and each invalid board weight zero. The selector is zero at the reference point and one on the board side. Its normalized expectation is

\[
p=\frac{Z}{Z+m}.
\]

Using the proposed numeral as a chosen reference weight does not assume the answer. The identity holds for every natural `Z`, and its denominator is positive even when `Z = 0`. This description is a finite-sum specification; implementing it must retain a symbolic tensor/factor encoding rather than enumerate boards. A direct-sum selector and a scalar reference weight are the intended algebraic operations. No pure-state square-root amplitude or numerical normalization is needed for this classical nonnegative measure.

Suppose an exact certificate proves rational bounds `L ≤ p ≤ U` and

\[
\frac{m-1}{2m-1}<L,\qquad U<\frac{m+1}{2m+1}.
\]

Multiplication by positive denominators gives `m − 1 < Z < m + 1`. Since `Z` is an integer, this forces `Z = m`. There is no appeal to numerical rounding of an approximately computed count. For the proposed `m = 14772512`, the actual obligations remain these exact rational inequalities.

At `Z=m`, the selector expectation is one half. The distances to the two forbidden adjacent integers are exactly

\[
\frac12-\frac{m-1}{2m-1}=\frac1{4m-2},\qquad
\frac{m+1}{2m+1}-\frac12=\frac1{4m+2}.
\]

Thus the needed absolute accuracy is on the order of `1/m`. For comparison, encoding the count as the success probability of a uniform choice of one column per row gives `Z/16^16`; an absolute count error below one half then needs probability error below `2^-65`. That normalization is not compulsory. The reference-weight construction avoids that particular accuracy penalty, while leaving the hard contraction problem intact.

### What Lean would need to verify

A possible exact certificate would have four parts:

1. **Source identity.** A symbolic proof connects the actual book count, the finite queens factors with their prescribed boundaries, and the selector ratio above. Auxiliary assignments must retain their unique-extension accounting.
2. **Relaxation containment.** A generic proof shows that the actual finite-network environment satisfies every affine equation and positive-semidefinite or cone constraint used by the proposed small relaxation. A relaxation may include extra environments, but may not exclude the actual one.
3. **Two exact bound witnesses.** Rational dual multipliers and exact coefficient identities imply the lower and upper objective bounds. A convenient deterministic positivity witness is `S = Rᵀ D R` with rational entries and nonnegative diagonal `D`. Every matrix identity and sign is checked. Weak duality suffices; the solver's convergence, optimality report, and floating eigenvalues need not be trusted. [S3] supplies precedent for exact postprocessing; this particular Gram/dual interface is a proposed adaptation.
4. **Integer uniqueness.** Exact rational comparisons and the natural-valued source count finish the argument.

No numerical optimizer is a trusted premise. Conversely, an external interval labelled “certified” is not enough: the validity of its constraints, its exact dual or error witness, and its source interpretation must enter the checked proof.

### Why this does not yet justify implementation

The selector's two sectors retain global information. If a relaxation allows their relative boundary weight to vary, it can permit selector values from zero to one. The prescribed reference weight therefore must survive the finite-network constraints. Treating the selector as an ordinary local observable and discarding the relevant boundary information would not deliver the required tightness. This is an applicability concern, not a proof that every useful relaxation is loose.

No reviewed source or retained artifact supplies the needed Queens16 relaxation, its rational witnesses, its matrix dimensions, coefficient bit lengths, or bound width. Grouping the board into a one-dimensional chain does not solve this: the exact boundary dimension and the cost of checking its representation still have to be bounded. Invertible transfer maps, decay, or effective small environments cannot be silently assumed.

Even a mathematically valid rational certificate has a resource cost. The complete new cone/finite-sum soundness development, concrete affine/Gram checks, and source bridge would have to fit one fresh 30-second, 1-GiB gate. A record called “one SDP certificate” cannot hide unchecked global contractions or coefficient tables. Proved bulk arithmetic could help verification, but no such end-to-end certificate or measurement is supplied here.

## Cluster bounds: a different error theorem, an unproved premise

To apply the conditional framework in [S2], the queens instance would need a rigorous bound for **all** relevant loop corrections, together with valid normalization and fixed-point data. Observed decay on a handful of small loops would not prove the universal premise. Exact zero constraints alone neither establish nor disprove that decay; this review makes neither claim.

One must also turn the free-energy enclosure into an enclosure of the integer partition function, restore the normalization, and control every numerical or truncation error. For example, a proved `|log Z − f| ≤ δ` implies a multiplicative interval using `exp(f ± δ)`; exact outward bounds are still required before integer uniqueness applies. A small free-energy-density error alone is not an absolute count error below one half.

The retained work contains no certified queens decay constants or small cluster certificate. Enumeration, local contractions, repeated-cluster coefficients, normalization and the omitted-tail proof all belong in the accounting. No cluster cutoff is proposed or tried here.

## Signed and modular rank: exact interfaces, missing compression evidence

Allowing signed coefficients is a substantive representation change. An externally supplied exact factorization `A = U V` can express linear dependencies that a nonnegative ADD cannot use. It is valid only after the full identity is checked over the chosen ring or field. Small floating singular values do not establish it. Local numerical compression in [S4] would therefore need exact factorization witnesses or independently proved global error bounds before entering this trust model.

An invertible change of basis cannot reduce a fixed matrix flattening's exact rank: `rank(P A Q) = rank(A)` for invertible `P,Q`. A successful smaller representation needs actual dependencies or a restricted reachable subspace, not just a gauge change. This observation does not prove that the queens boundary functions have high rank.

A concrete modular interface could use externally supplied bases and transition matrices satisfying

\[
v_0=B_0c_0,\qquad T_tB_t=B_{t+1}C_t,
\]

with the final scalar obtained from the smaller `C_t` matrices. All equalities must be exact and their full source-boundary meaning proved. The large `B_t` objects must themselves have compact checked descriptions; expanding every boundary assignment to check these equations would violate the task's representation restriction. Dense storage and intermediate products can dominate even when the recorded number of high-level equations is small.

For modular uniqueness, a prospective permutation injection gives the elementary bound `0 ≤ Z ≤ 16!`. If a deterministic certificate proves `Z ≡ m (mod M)`, with `0 ≤ m ≤ 16! < M`, then `Z=m`. For instance `M=2^45` is larger than `16!`; this uses a ring, not a field. Field-based rank arguments would instead need a suitable prime or several moduli and the appropriate algebraic proofs. All residue computations share the same total budget; each modulus does not get a new 50,000-claim allowance.

A lower rank in one finite field is not evidence of the same rank over the rationals, nor does a residue modulo a small prime determine the count. Enough exact residues plus the bound would be sound, but no useful queens bases, dimensions, compact identity witnesses, or resulting total work are known from this review. Probabilistic matrix-identity tests, random-prime fingerprints and cryptographic assurances are excluded.

## Decision against the retained evidence

The latest factored lazy n8 producer stops at exactly 50,000 claims after 153 of 210 variables, with `[153,160)` pending. Its independent replay accepts the preserved prefix and asserts no count. At the completed 153 frontier it has 42,402 claims and 1,984 live nodes. [L1–L4]

The already accepted packed ADD source proof for n6 rebuilt 58 mathematical bodies in 27.329427591 seconds, peaking at 988,024 KiB. [L5–L6] These facts explain why reducing verification cost alone is insufficient and why a new exact arithmetic representation needs evidence of actual compression. They do not imply a lower bound on all possible certificates or predict the cost of a different one.

**Recommendation:** preserve the reference-weight/dual-bound interface as a concrete research lead, but do not build a new general checker or authorize a counting experiment on its strength alone. Reopen the implementation decision only after someone supplies a specific finite queens relaxation with exact narrow bound witnesses, or a compact exact signed/modular boundary relation with an explicit full checking cost. Any subsequent scale claim would still require the existing complete source-linked acceptance process. This review supplies neither witness and establishes no new value of `cqueens`.

## Sources and local evidence

- **[S1]** Seishiro Ono, Yanbai Zhang, Hoi Chun Po, *Toward bootstrapping tensor-network contractions*, arXiv:2603.17856v1 (18 March 2026). [Primary text](https://arxiv.org/html/2603.17856v1), [abstract/version](https://arxiv.org/abs/2603.17856v1). Read II.1, II.4 and III; key equations (1)–(3), (17)–(22).
- **[S2]** Siddhant Midha, Yifan F. Zhang, *Beyond Belief Propagation: Cluster-Corrected Tensor Network Contraction with Exponential Convergence*, PRX Quantum **7**, 033010 (9 July 2026). [Publisher](https://journals.aps.org/prxquantum/abstract/10.1103/sdlx-d3tn), [published PDF](https://journals.aps.org/prxquantum/pdf/10.1103/sdlx-d3tn), [earlier arXiv v2](https://arxiv.org/html/2510.02290v2). Published sections III B, IV and V D were consulted. No numerical constant from the older appendix is adopted.
- **[S3]** Maria Dostert, David de Laat, Philippe Moustrou, *Exact semidefinite programming bounds for packing problems*, arXiv:2001.00256v3 (9 July 2020). [Primary text](https://arxiv.org/html/2001.00256v3), [abstract/version](https://arxiv.org/abs/2001.00256v3). Read introduction and sections 3.1–3.3. Published DOI: [10.1137/20M1351692](https://doi.org/10.1137/20M1351692).
- **[S4]** Zhi-Cheng Yang, Stefanos Kourtis, Claudio Chamon, Eduardo R. Mucciolo, Andrei E. Ruckenstein, *Tensor network method for reversible classical computation*, arXiv:1708.08932v2 (5 February 2018). [Primary text](https://arxiv.org/html/1708.08932v2), [abstract/version](https://arxiv.org/abs/1708.08932v2). Read III.1, V.3 and VI. The version date is used, not the regenerated HTML's displayed manuscript date.

`sources.json` records exact literature URLs and review scope. `review.json` records assumptions and negative claim flags. `evidence.json` binds these notes and the nine read-only local inputs; its `L1`–`L9` identifiers resolve the local citations. It is an inventory, not a rerun of the historical evidence verifier.
