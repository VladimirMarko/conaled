# Checkpoint232 — accepted word foundation and stronger CSP contracts

The active task remains to complete
`ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512`, preserve transferable proof infrastructure, and publish/upload standalone durability checkpoints while continuing autonomously. **The stock numeral theorem and the original installed-kernel/GroupChecked endpoint remain open.** The accepted external numerical reflection result is preserved separately.

## New actual execution evidence

| Complete fresh selection | Result | Accepted / observed reports | Seconds | Peak KiB |
| --- | --- | ---: | ---: | ---: |
| Corrected word foundation59 | passed |59 /59|2.9150907550065313|509208|
| Corrected iota Interpreter185 | failed in one proof rewrite |8 /185|25.563569123994967|876708|

Both attempts rebuilt every selected source under the unchanged cumulative30-second, one-CPU/thread/import-worker,1-GiB/default-resource/strict-warning policy. Permitted axioms remain propext, Quot.sound and Classical.choice. No prepared experimental imports, native evaluator or exporter was used. Success and failure both permanently consume their source key.

### Complete reusable word foundation

All six owners passed: RoutedLookup7, IndexedPackets5, PackedSwitch6, MaskCheck3, WordMajorRouting16 and KernelWordMajorAddition22. The source includes the separately reviewed two-proof Routing correction and one-line Addition residue normalization. The Addition correction rewrites `Nat.pow_succ` in both strict residue hypotheses as well as the goal, preserving every theorem statement and executable definition. Its author169/independent170 scope remains separate from the original68/69 scope and the Routing30/38 and repair76/77 scopes.

Consumed key: `72f3af56d3caa8f258c49e20c17bcc4199c1a8a4492ef2b90fcf8de1353ffdc7`.
Report173191bytes SHA256`62a03c6b8969228b7d8564b58d9142d556f15f89334446ad1e33367158631a1c`.
Recovery97079bytes SHA256`b87ae631aa7bfeb6d3e4927dcbdcaecaa1934320543e7ecea7b5e2139a5289ae`.
Receipt1597bytes SHA256`b1656c424c447c0edc79eff9d04282f48bcda51fb16117ac31de5cdc73c93b4b`.
All194 read-only snapshot pairs, twelve raw logs and the permanent marker have exact canonical preservation. See `kernel-word-major-addition-proof-repair/gate/RESULT-AND-NEXT.md`.

This result establishes reusable bounded natural-number routing and guarded addition proofs. It does not evaluate a concrete complete queens certificate.

### Actual iota failure after the diagnosed repair

The corrected interpreter selected three owners,618509bytes and185 roots. Core2 and Cached6 passed, but the entire177-report combined owner is rejected. Its source had independent1342/1343 review, and its controls preserved all38 previous review scopes plus this separate39th scope. The complete execution predicate, compiler and resource enforcement remained literal apart from the disclosed marker/review-count bookkeeping.

The single new error is at the first `rw [recursorTypeRun]` in `iota_plain_of_prepared`, physical line3095. The preceding `dsimp` leaves reflected Boolean recursion over `decide` conditions and an implicit-transparency mismatch in the `compareParams` decidability expression. The previous twelve unused-simp diagnostics are absent. Error-recovery `sorryAx` output is rejected with the entire owner; no admission was inserted into source.

Consumed key: `e83b4b93eed3f30889ab452f532fbf6799b75969f42def71f8f711e9087b653d`.
Report1041645bytes SHA256`384f8a13525a2543b922e12faacc07b95f0cdeb7ba89a62a6dd3caec56dd347f`.
Recovery697583bytes SHA256`76cecb96b05bc6934cbdbf1cf29d2edfc26c90c19e464e4b76d28962e2aaeb81`.
Receipt1631bytes SHA256`162aecfc49ea37d3e8acf48d45ec4563ace977724330a57070d9c4ce09a80210`.
All1415 actual snapshot pairs and six logs are retained. See `kernel-cached-eventual-iota-proof-repair/gate/RESULT-AND-NEXT.md`.

A separate targeted proof-only successor should expose the exact staged monadic equation without leaving mismatched reflected Boolean decisions. Preserve all branches, certificate calls, states, budgets and theorem premises. It needs new source/control reviews and a genuinely new complete fresh attempt; no unchanged rerun or reused Core/Cached objects.

The prior Foundation134 complete pass and both earlier Interpreter/word failure records remain unchanged. A larger source review does not transfer earlier acceptance.

## Newly completed independent reviews

| Package | Status at this cut | Exact source scope |
| --- | --- | --- |
| Eventual PendingCertifier | independently reviewed; uncompiled |1545/1549|
| Iota proof-only repair | independently reviewed; actual owner failed |1342/1343|
| Addition proof-only repair | independently reviewed; complete59 passed |169/170|
| Mask integration and exact transposition | independently reviewed; uncompiled |139/140;26 reports|
| Whole-word adjacency | independently reviewed; uncompiled |184/185;19 reports|
| Combined word infrastructure112 selection | independently reviewed; controls outside this cut |279/280|
| Strong-CSP quotient | independently reviewed; uncompiled |76/77;17 new reports|

PendingCertifier preserves the actual restricted lookup, complete record/program/arithmetic pins and the compute-before-compare operation. Its conclusion remains tied to the exact original checkPending from the empty state. It does not install a numerical backend or assume14772512. Its prospective40-owner500-root graph remains uncompiled; restoring the masked backend requires the explicitly omitted numerical origins as well as the adapter.

### Complete word selection after accepted59

The distinct `kernel-word-major-infrastructure112` source selection contains eleven owners,107501bytes,112 distinct roots and22 prospective outputs. It joins accepted59 with Integration26, the two complete original plane helpers8, and Adjacency19. No source is modified or concatenated. There is one canonical owner per imported module, with176 explicit public and19 private declarations retaining their original contexts.

The original Integration93-source selection is interpreted through exactly two identity substitutions, repaired Routing and repaired Addition. Original Adjacency78 needs exactly one, repaired Addition. All other rows and all interfaces remain literal. Both complete array inverses, both existing proof overlays, six separate original source-review scopes and all22 source intervals passed root's independent selection check. The separate279/280 review does not rebase any earlier array.

Integration proves canonical full finite packet conversion, retaining the marker, all17 n6 key bits and all51 payload bits. Adjacency derives request selectors from stored marker bits, broadcasts without cross-lane carries, rejects a first request and compares the full key/payload word with its predecessor. Concrete masks, route/output equality, source definition validity, recurrence and final root remain obligations. The new112 controls are being authored separately and are excluded from this fixed cut unless later explicitly added by the selection review.

## Exact small-certificate assessment and route choice

`kernel-word-major-small-certificate-route` records the complete current n6 source graph and recommendation, with141 exact inputs. The correct retained packed-row baseline used479 reports in25.786490248996415seconds and981228KiB **after seven original ADWH imports were prepared separately**. Its true all-fresh union has17 physical owners,72 logical origins,4256450source bytes and34 ordinary outputs. The retained symbolic primitive and scoped-counting repairs already address historical limit/example defects; do not redo or silently omit them.

The n6 certificate has9454 nodes,11956 claims,21410 prefix records and131072 routed rows. Its complete packet width is69 bits. Word packing reduces repeated kernel operations, but does not reduce the ADD node/claim/search-state count. A complete port still needs actual canonical conversion, valid masks/output, selected guarded claim-key arithmetic, and a replacement of the real ADDTable lookup dependency. Adding an unused helper theorem does not remove the old costly path. No complete n16 ADD certificate exists in this retained route.

The assessment therefore prioritizes a stronger residual-CSP semantic quotient and a complete compressed witness. The diagnostic stronger solver is not retained as executable source. Its n16 sample covered only32 selected prefixes, not the whole838816-prefix frontier; its observed reductions are not a full count or general resource bound.

## New strong-CSP contracts

The frozen `kernel-strong-csp-quotient` package adds pruning8, quotient/checker6 and source endpoint3 reports. It passed independent76/77 source review of all17 new proofs, six complete retained owners, four exact proof-token edits/ten complements,30 primary intervals and nine complete pinned SDK copies. Review16912bytes has SHA256`fe805373a0954bfd57c757411fa15e493a4b83343a56f437c75048b34db324d8`; audit80996bytes has SHA256`5c465e5d97ce336a40b67b3ddb03478cab333b196bfc48bda3dd60ab230fb6f7`. Its generic rule selection is eight fresh owners,32 distinct roots and58404bytes. No runtime definition, statement, import, option or report is omitted.

The new primitive proves equality of the entire ordered model lists after deleting every occurrence of an unsupported candidate. The witness is an actual different domain occurrence in the residual tail, obtained by a real optional index lookup. The relation direction is selected candidate to every witness member. Duplicates, empty witnesses and absent candidates preserve their exact semantics. General target-domain movement uses a checked permutation and explicit relation symmetry to preserve counts.

Propagation alternates actual pruning and singleton forcing, using each returned state for the next step. Children invoke the full retained terminal/normalization/reference checker. Branching covers every candidate occurrence. Entries contain a problem and proof data, with no proposed count; counts are computed by the checker and references access only earlier established entries. The known-count invariant is constructed from an empty environment.

The separate new endpoint concludes the original cqueens equality for n≤16 from actual finite normalization and complete certificate success. Its raw historical import closure is32owners/295613bytes and is explicitly unselected because two historical resource-override owners remain. A future endpoint selection must bind the already retained original-name primitive/scoped-counting repairs and exact bridge imports. It is not hidden inside the small generic closure.

Column regrouping, geometry that changes domain partitions, grouped branch multiplicities and component products are not supplied by these rules. They require their own exact refinements. No new producer, certificate, concrete count or timing is claimed here. A separate producer implementation is the next measured route, with source/control review and all mathematical work inside the unchanged limits.

## Next authorized work

1. Prepare a concrete reusable producer and exact complete endpoint selection using the independently reviewed strong-CSP contracts. Review every new pruning, normalization, reference and branch witness before a complete source-linked discriminator.
2. Review112 controls and run its entire fresh union once. Treat its result as generic infrastructure, not evidence of n16 certificate size or fit.
3. Repair the captured iota Boolean-reduction failure through a separate source scope, then review and run the complete interpreter closure once. Continue the actual cached-query and full record interface work only with its dependency status explicit.
4. Preserve the distinction between the stock ground theorem and original installed-kernel/GroupChecked route. The retained fast compiled n16 numerical acceptance does not discharge either.

## Recovery and fixed cut

All231 payload paths and the231 publication/clean-restoration receipt remain. This archive adds the exact accepted59 and failed185 evidence, completed independent reviews, the small-certificate census, frozen112 selection and frozen strong-CSP source package. In-progress112 controls, subsequent iota repair and producer work are excluded unless explicitly listed by the final selection review.

The standalone archive contains sources, exact context copies, reviews, manifests, controls, logs and permanent markers. It omits SDK binaries, prepared objects, duplicate attempt input/source/build trees, the full textbook and full upstream metatheory builds. Restore the exact runtime from session215-runtime-restoration.json. The measured storage-only guard changes no mathematical limit. Clean restoration checks saved bytes; it neither reruns mathematical work nor promotes a source-only result to acceptance.
