# Common-payload padding: implementation checks passed

Root executed the single fixed `tests-01` attempt. **Both the exact source-
preservation check and all twelve named scalar-codec tests passed**, under one
cumulative **0.19858322300569853-second** observation with **38,616 KiB** peak RSS.
Both child processes exited zero with no resource violation. The tests exercise
the actual new producer/replayer shape and scalar-codec functions, including the
formerly rejected case where node records require the wider common payload.

This is finite implementation regression evidence. The separate accepted Lean
helper proves universal padding/field facts; neither result establishes a
Python-to-Lean execution correspondence or a complete larger-board count.

## Actual run and raw outputs

| Fixed child command | Result | Wall seconds | Peak RSS KiB |
| --- | --- | ---: | ---: |
| `python3 -I verify_source_preservation.py` | Both exact inverses, unchanged `main()` bodies and support source accepted | 0.077898096 | 38,600 |
| `python3 -I tests/test_common_payload.py` | All 12 named tests reported `ok`; final `OK` | 0.078450228 | 38,616 |
| **Cumulative verification** | **Passed, including output audits and final binding checks** | **0.198583223** | **38,616** |

The [raw report](python-gate/attempts/tests-01/report.json) is 27,632 bytes,
SHA-256:

```text
dc6254ec03d56f16550507d2aa4c83ec48b3b11bd237a35ca29d6c256ccc0838
```

The source fingerprint is
`088f559ad0594f24f4c0455ece2f40a2be8b365edd32b76e0332f9cdbb0c6f7e`.
The read-only [permanent marker](python-gate/execution-markers/checks-088f559ad0594f24f4c0455ece2f40a2be8b365edd32b76e0332f9cdbb0c6f7e.json)
is 10,216 bytes, SHA-256
`66c5901be6e35472e1cccb70b0ca81b061f209c31019c9fec0746d3cb7e3b1d6`.
This candidate had no failed attempt and no unchanged repeat.

The first child's [stdout](python-gate/attempts/tests-01/source-preservation.stdout.log)
contains the exact expected inverse-verification JSON; its stderr is empty. The
second child's stdout is empty, while its
[stderr](python-gate/attempts/tests-01/scalar-codec-tests.stderr.log) contains the
normal unittest report: every required name once, `Ran 12 tests in 0.002s`, and
`OK`. The unittest's internal 0.002-second figure covers its test execution; it
does not replace the measured child or cumulative times above.

## What was repaired and checked

The isolated variants use the maximum of node width and claim width as their
common payload width. When nodes are wider, the producer adds an explicit zero
high field to claims. The independent replayer derives the same shape, rejects
nonzero unused padding, and returns the original five semantic claim fields.
Appending high zeros leaves the encoded integer unchanged. Numeric validation
rejects malformed/negative values before width calculations and invalid widths
before shifts or powers.

| Test family | Concrete coverage |
| --- | --- |
| Width ordering | Claim-wide, equal-width, node-wide and an 81-bit constant `2^80 + 7`; the last case requires 76 claim-padding bits. |
| Existing serialization | Fixed ordinary layouts and golden integers `1029` for a node and `8462` for a claim; the claim remains `8462` after zero padding. |
| Semantic decoding | Exact node/claim fields and absence of an extra `unused` result field. |
| Zero-padding validation | Explicit zero padding, zero-width padding, and rejection of nonzero node/claim padding. |
| Malformed data | Negative, Boolean, missing and noninteger constant values; empty constant families; invalid field widths; semantic-field and payload overflow. |
| Input-derived shape | Changing ignored expected-answer metadata to a 513-bit value leaves widths derived from actual records unchanged. |
| Existing guard boundary | Invalid format, invalid board value and an operation cap above 50,000 remain rejected. |

Each synthetic fixture has four node records, three claim slots and five
variables. The tests call only producer `configure`/`encode` and replayer
`infer_shape`/`node_decode`/`claim_decode`/`decode_fields`. They do not constitute
a queen-count trace. Neither retained `main()` entry point, routing support,
counter nor full semantic replay was called.

The executed preservation checker accepted the exact inverse edits back to both
original files, byte-identical `main()` bodies, and unchanged routing-support
bytes. The frozen originals were not modified. The retained CLI entry points
still have their original pinned n6 input contract; the repair does not silently
turn those entry points into a general larger-board producer. Full changes and
source qualifications remain in [SOURCE-EDITS.json](SOURCE-EDITS.json), the two
diffs, [PLAN.md](PLAN.md), and the
[independent Python source review](PYTHON-SOURCE-REVIEW.md).

## Saved-evidence audit

The result reviewer did not author the Python variants, tests, wrapper or
protocol. The reviewer did author the separate mathematical gate, whose
authorship is disclosed in [MATH-RESULTS.md](MATH-RESULTS.md). This audit read
saved files and outputs only: it reran no test, preservation command, variant,
producer, replayer, counter, generator or Lean process.

The audit verified **50 direct report bindings covering 50 distinct files**,
plus **23 marker bindings covering 23 identities**. These groups overlap.
Every original input, all 22 read-only snapshots, the interpreter, four raw
output logs and the read-only marker matched their recorded sizes and hashes.
Every snapshot also matched its canonical original byte for byte. All twelve
raw test names were independently parsed and checked against the fixed
inventory, with no missing, duplicated, skipped, failed or errored required test.
The first child's JSON was checked against the two exact variant identities and
the fixed edit-manifest hash. Saved outcome fields agree with those raw outputs.

Both commands ran from the frozen snapshot directory using the recorded Python
3.12.14 interpreter with `-I`. Its executable hash was checked. The fixed wrapper
used one CPU and one shared 30-second/1-GiB deadline, the unchanged process-tree
resource helper, and the existing nonblocking project lock. Actual command paths,
execution order, cumulative time, RSS and final postchecks match the reviewed
[Python gate](PYTHON-GATE.md) and its [independent review](PYTHON-GATE-REVIEW.md).
No `.pyc` or Lean object was created in this Python attempt. This does not seal
the complete Python/OS environment into the source checkpoint.

The frozen Python inventory contains pre-execution status wording for its
separate mathematical evidence. That historical control is preserved unchanged;
the actual subsequent mathematical acceptance is recorded in MATH-RESULTS and
its raw report. A pre-run inventory status is not a replacement for either
executed result.

## Combined recovery and remaining boundary

[SNAPSHOT-RECOVERY.json](SNAPSHOT-RECOVERY.json) maps **all 31 recorded snapshots**:

- Nine mathematical source/control snapshots: **364,414 bytes**.
- Twenty-two Python input/control snapshots: **268,620 bytes**.
- Combined: **633,034 snapshot bytes**, mapped to **29 distinct unchanged
  canonical payload paths**. The helper and its mathematical inventory are shared
  by both attempts.

There are no unique superseded inputs and no source-generation step. Retain the
canonical files, both raw reports, ten raw log files across the two gates, two
permanent markers, reviews and result records. Repeated snapshots can be omitted
using the exact mapping. The six mathematical objects, Lean runtime and Python
interpreter are separate environment material, not source-only archive payloads.
Restoring canonical bytes does not authorize resetting either execution marker
or representing a rebuild as the historical run.

The common-payload representation restriction is repaired and these exact
implementation checks pass. The ordinary-kernel padding helper also passes its
separate 239-root complete proof gate. This combination supplies reusable
serialization work; a complete larger-instance certificate, its concrete
acceptance and the original source-count bridge remain necessary to close
`cqueens 16 = 14772512`.
