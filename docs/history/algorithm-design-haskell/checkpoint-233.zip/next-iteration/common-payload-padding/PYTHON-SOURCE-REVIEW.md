# Independent source review of the Python padding repair

## Finding and scope

No source-level blocker was found for the proposed bounded preservation and
scalar-codec tests. The new variants remove the claim-dominates-node width
restriction, preserve semantic field order and exact integer values, validate
unused padding as zero, and independently decode the five original claim
fields. The associated numeric-validation changes prevent negative or
malformed values from reaching width arithmetic.

This reviewer did not author or edit the Python variants, tests, edit manifest
or preservation script. The reviewer authored the separate Lean helper; its
mathematical source has a different independent reviewer. This review does
not identify the Python implementation with the Lean functions or claim
universal Python correctness.

I read both complete source diffs, the changed functions, all twelve test
methods, the preservation script and the verification plan. Independent
read-only hashing, text inversion and AST comparison confirmed the recorded
source boundary. No variant was imported or executed, no test/preservation
script was run, and no counter, router, semantic replay or Lean process was
invoked by this reviewer. `PYTHON-SOURCE-AUDIT.json` records the bindings and
static checks.

## Exact reviewed implementation

| File | SHA-256 |
| --- | --- |
| `source/produce_common_payload.py` | `4c4c1ecafb3874ba36fb4be30f3409ef2bf7d2d9cc6bb58954c9b2b9b017865c` |
| `source/replay_common_payload.py` | `85583ecc40d96b731d0df6cfc27a32d49d637ecfaf8b02346bad0a141b510ba9` |
| `tests/test_common_payload.py` | `6fdcc01ace5a178ea8276b7aa068ed3627112bdc658ac8217752d93e14a000ef` |
| `SOURCE-EDITS.json` | `60e3fcaba9f0169f3aced50f159550e3df12d52707c5638f7bceb0b3cd1c5a16` |
| `PYTHON-INVENTORY.json` | `b8e15f6a5498af63a2d17535473bbbcf97a785699182c724d1674d351cdb3f34` |

The six producer edits and seven replayer edits invert to the exact original
files. At top-level AST scope, only the module documentation and the following
functions differ:

- Producer: `configure`, `encode`.
- Replayer: `infer_shape`, `decode_fields`, `claim_decode`.

Both `main()` bodies are byte-identical, not merely AST-equivalent. The trace
pins, operation cap, rule codes, counting/routing functions and complete replay
checks are unchanged. The separate `route_support.py` copy is byte-identical
to its retained source. No test calls or imports that router. These findings
are stronger than simply trusting the edit manifest's own success flags.

## Padding and validation semantics

Both implementations derive the common width as the maximum of the complete
node and claim widths. The producer conditionally appends a high `unused`
claim field only when it is needed. Thus the ordinary claim field list is
unchanged when claims already determine the common width, including the tie
case. Appending a zero high field leaves the encoded integer unchanged.

The replayer derives the widths independently, using its own division-based
width calculation. It introduces the matching optional field, checks zero,
then removes that field before returning `kind`, `left`, `right`, `result`,
`variable`. It neither imports the producer nor relies on producer-provided
field dimensions. `node_decode` retains its existing explicit zero check.
[Sources: `configure`, `encode`, `infer_shape`, `decode_fields`,
`node_decode`, `claim_decode`; complete changes are in the two `.diff` files.]

The new constant-family validation occurs before `max`/width calculation;
Boolean values are rejected as distinct from integers. The replayer's width
loop additionally validates its argument before repeatedly dividing it. This
matters for negative Python integers: the old loop could stabilize at `-1`.
Both codecs validate field widths before a shift or power. Existing value and
payload overflow checks remain in place. These are explicitly disclosed
implementation repairs, not extra assumptions in the formal theorem.

The layout calculation reads the supplied variable order, table sizes and
actual constant-node values. It does not use expected/diagnostic answer
metadata. This is a deterministic input-derived encoding algorithm. It does
not prove that the supplied constants are correct arithmetic results; the
complete semantic certificate checks remain responsible for that question.

## Why the proposed tests are meaningful

The tests call only six variant entry points: producer `configure`/`encode`
and replayer `infer_shape`/`node_decode`/`claim_decode`/`decode_fields`.
Each fixture has four synthetic node records, three claim slots and five
variables. These records are deliberately not passed through a counting or
complete-certificate entry point.

The fixed positive cases cover claim-wide, equal-width and formerly rejected
node-wide records, plus an 81-bit constant. The latter produces 76 padding
bits on the claim side. Golden words `1029` and `8462` check a concrete
ordinary encoding independently of a round-trip assertion; the claim word
remains `8462` after high zero padding. The tests also check the exact semantic
field set after decoding. These are width-boundary cases, not fixtures chosen
to reproduce an expected queens answer.

Negative cases exercise missing/malformed/negative constant values, invalid
field widths, semantic and payload overflow, nonzero node/claim padding and
zero-width padding. Another case changes ignored answer metadata while
holding actual records fixed. Existing format, board and operation-cap guards
are checked separately. No board-size sweep or performance comparison is
proposed.

Passing these finite tests would be useful regression evidence for the actual
changed code. It would not prove all possible Python executions, producer
termination, global trace completeness or a queens count. The source-level
review also does not substitute for the proposed executed test result.

## Execution and mathematical boundary

The verification plan calls for one named, hash-bound attempt containing the
preservation command and the twelve tests under one cumulative 30-second,
one-CPU, 1-GiB allowance. Sources, controls and raw outputs should remain bound
before and after execution; actual statuses and test counts must determine
acceptance. A diagnosed correction must preserve the failed attempt rather
than reuse its identity. The root coordinates runner review and owns the
execution decision.

The unchanged pinned CLI wrappers still describe their original exact n6
input. This repair makes the shape/codec logic reusable; it does not silently
broaden those wrappers into a complete larger-board producer. A new complete
instance still needs its reviewed input and source-certificate protocol.

The Lean helper proves universal facts about zero extension and field
decoding, with an explicit dense claim-key premise. It does not prove the
Python implementation. Conversely, no Python test result is a premise of its
theorems. Both forms of evidence retain the ordinary-kernel route and its
existing native-primitive trust boundary; neither constitutes adoption or
verification of a replacement kernel.
