# Proposed bounded verification — root execution only

Status: source prepared; no test, source-audit script, producer/replayer main,
router, counter, or Lean process has been executed by the implementation author.
The author performed only source reading/writing, parsing, hashing and inverse
comparison. Root must review and bind the final sources/controls before runs.

## A. Python source preservation and scalar encoding

Use one named attempt, preserving command logs, source/control snapshots and
pre/post hashes. Run the following two commands sequentially under one
cumulative 30-second deadline, one CPU, and a 1-GiB process-memory limit:

```text
python3 -I verify_source_preservation.py
python3 -I tests/test_common_payload.py
```

Working directory is `work/next-iteration/common-payload-padding/`.
The first command imports or executes no variant; it checks exact inverse
recovery, immutable original/variant bindings, unchanged `main()` bodies and
the unchanged support source. The second imports only the two new Python
variants, with bytecode writes disabled, and runs their shape/scalar-codec
functions on the fixed synthetic records described in PLAN.

Acceptance requires both zero exits, twelve reported tests passing, unchanged
bound source/control identities, no timeout or memory event, and a saved
report distinguishing source checks from executed tests. Bind at least both
variants, the support copy, SOURCE-EDITS.json, the two diffs, test source,
preservation script, PLAN and this verification proposal, plus the independent
Python source review. The original sources remain hash-bound at retained paths.

No command-line producer/replayer entry point, route, finite ADD semantics
routine, retained generator or queen counter is called. The largest real
test constant is `2^80+7`; deliberately ignored answer metadata has 513 bits
and is not used to allocate a shape. These are tiny scalar tests, not a new
source-count fixture. Root should not create an unchanged second attempt merely
to obtain another observation; a diagnostic correction requires preserved
failed evidence and a reviewed actual source change.

## B. Fresh ordinary-kernel mathematical contract

The proposed generic closure is exactly:

1. The unchanged accepted `LegacyListClause.lean`.
2. The unchanged accepted `ConsolidatedGeneric.lean`.
3. New `CommonPayloadPadding.lean`.

Compile all three fresh, with no reused experimental object, in dependency
order under the existing single cumulative 30-second, one-CPU/thread,
`-j1 -M1024` protocol and peak RSS limit of 1,048,576 KiB. Standard-library
imports are pinned runtime preparation. There are no ADWH project imports in
this generic closure. Existing root prints contribute 6+224 roots; the new
helper prints nine, for a proposed inventory of **239**, to be independently
verified and frozen before execution.

The nine new roots are `wordAt_pad`, `length_pad`, `added_field_zero`,
`nodePlanes_at`, `claimPlanes_at`, `nodePlanes_pad_at`, `claimPlanes_pad_at`,
`node_reference`, and `claim_reference`, under
`ADWH.Experiments.Chapter15.CommonPayloadPadding`. Require actual reports for
every root with only the existing allowed axioms, strict warnings, no
admissions and no native trust path. Preserve source/control snapshots,
execution markers, compiler/runtime identities and raw diagnostics.

This is a complete generic-library gate. It proves exact zero-extension and
field decoding, including node-dominant widths, and retains the dense claim
key premise. It does not establish the correctness of the Python programs or
recheck a complete n6/n8/n16 source-count fixture. Combining the independent
Python tests with this theorem family supplies reusable serialization work;
a future concrete source-count claim would still require its complete fresh
mathematical closure and source correspondence.
