# Common payload padding: verified repair and reusable contract

The requested representation repair is complete. Separate Python producer and
replayer variants pass twelve finite boundary tests and exact source-preservation
checks. Nine general Lean padding/codec theorems pass the ordinary Lean 4.35
kernel with their complete three-module, 239-root dependency closure.

The original Chapter 15 target remains open:

```lean
ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

No new board count, larger producer run, Python-to-Lean implementation theorem,
or replacement kernel is claimed. This result removes a representation defect
and supplies mathematics reusable across record widths and inputs. It is not a
new speed result for queens counting.

## Why the repair was needed

The old packer and independent replayer required a node payload to fit within a
claim payload. If rank width is `r`, node identifier width is `d`, and constant
value width is `v`, their widths are:

```text
nodeWidth  = r + d + d + v
claimWidth = 2 + d + d + d + r
```

The restriction was therefore `v <= d + 2`. It was unrelated to whether the
arithmetic certificate was mathematically correct. Conditionally, a stored
constant 14772512 needs 24 bits and could trigger that restriction even with
relatively few nodes. That numeral is an illustration of the width boundary,
not an input or premise of this repair. Widths come from actual trace constants.

The new variants choose `max(nodeWidth, claimWidth)` for the common payload.
The shorter record receives zero padding. A claim gains an `unused` field only
when its semantic fields are shorter than the node fields, preserving the old
ordinary layout and serialized words. Independent replay derives the layout,
rejects any nonzero unused field, discards validated padding, and returns the
original five semantic claim fields.

The repair also validates natural-number values and field widths before
computing bit lengths, shifts or powers. Negative numbers, booleans masquerading
as integers, malformed values, missing constant values, overflows and nonzero
padding cannot pass the reviewed scalar interfaces. These changes are exactly
enumerated in [SOURCE-EDITS.json](SOURCE-EDITS.json), with unified diffs and an
inverse verifier. The frozen original sources are unchanged, as are both copied
`main()` bodies and their original trace, board and operation-cap guards. This
is not a new arbitrary-board command-line producer.

## General Lean result

[CommonPayloadPadding.lean](source/CommonPayloadPadding.lean) imports the retained
generic checker semantics and defines a layout with arbitrary natural rank,
identifier and value widths. Its padding operation zero-extends to the common
width without truncating an already longer input list.

The nine accepted theorems establish:

- Every decoded row word is preserved by padding.
- The resulting length is the maximum of the common width and original length.
- The added high field is zero.
- Node and claim field slices decode to the same semantic records as the generic
  word decoders, under their explicit width bounds.
- Common-width padding supplies both width bounds, regardless of which record
  is wider.
- Exact payload lookup transports node and claim rows to their table reference
  decoders. Claim transport retains the explicit dense key equality.

These results quantify over arbitrary layouts, plane lists and row positions.
They cover zero widths, empty inputs and overlong inputs. They assume no board
size, expected answer, producer correctness or pre-masked-plane property.
Each new theorem has exactly `propext` and `Quot.sound` in its transitive axiom
report. [MATHEMATICAL-DESIGN.md](MATHEMATICAL-DESIGN.md) explains the exact contracts;
[INDEPENDENT-MATH-REVIEW.md](INDEPENDENT-MATH-REVIEW.md) records the independent
source review.

The first complete gate freshly checked `LegacyListClause`,
`ConsolidatedGeneric`, and `CommonPayloadPadding` together:

| Observation | Accepted result |
| --- | ---: |
| Required / observed / accepted theorem reports | 239 / 239 / 239 |
| New padding/codec roots | 9 |
| Fresh mathematical modules | 3 |
| Cumulative execution seconds | 7.89377424599661 |
| Peak child RSS, KiB | 700396 |

All three processes exited zero with empty stderr and no warning, error or
resource event. The existing policy was unchanged: one CPU, one cumulative
30-second gate, at most 1,048,576 KiB observed RSS, default heartbeat/recursion
limits, strict warnings, synchronous elaboration, and only the permitted three
axioms. No earlier experimental object or original-ADWH preparation pool was
used. See [MATH-RESULTS.md](MATH-RESULTS.md), its machine-readable counterpart and
the independent [PROOF-RESULT-REVIEW.md](PROOF-RESULT-REVIEW.md).

Raw mathematical report SHA256:

```text
292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8
```

## Python implementation checks

The separate bounded Python gate ran only the inverse source verifier and the
twelve reviewed scalar-codec tests, from 22 read-only input snapshots. It did
not call a producer/replayer `main()`, route a certificate, execute the queens
counter, or import a large trace. Both commands passed on their first attempt:
**0.19858322300569853 seconds**, peak **38,616 KiB**.

The tests cover the old ordinary serialization, both payload-width orderings,
equal widths, a value exceeding a machine word, explicit zero padding,
nonzero-padding rejection, malformed natural values, semantic and payload
overflow, missing constants, and the unchanged existing input guards. Changing
fake expected-answer metadata from zero to an enormous integer leaves the
derived shape unchanged. Expected scalar words are independently specified in
the ordinary-layout test, rather than merely checking a producer/replayer
round-trip.

The inverse verifier reconstructs both old sources exactly and checks that
their `main()` bodies and support source are unchanged. These checks establish
finite implementation regression evidence for the exact new Python bytes.
They are separate from the universal Lean theorem and do not constitute a formal
proof of Python semantics. See [PYTHON-RESULTS.md](PYTHON-RESULTS.md), the frozen
test inventory and the independent source/gate reviews.

Raw Python report SHA256:

```text
dc6254ec03d56f16550507d2aa4c83ec48b3b11bd237a35ca29d6c256ccc0838
```

## Reusability and next direction

The user's 25 October clarification is a durable research priority: a reusable
method is more valuable than repeated tuning of the same small fixture. The
retained counting algorithm computes its answer; known answers are diagnostic
comparisons. A fixture freezes an algorithmic computation for reproducible
checking. It is not a logical requirement to know the count beforehand.

The surrounding source emitters and small-board CLI remain specialized. General
soundness of the checker does not demonstrate an automatic arbitrary-instance
producer, complete larger-board traces or acceptable scaling. The desired
interface is a producer returning a count and certificate, with a reusable
checker theorem connecting acceptance to the specified counting function.

There is also a separate implementation boundary: the original source counter
uses Word16 and depth sixteen; its correctness bridge assumes `n <= 16`. Larger
boards need a width/depth-parametric implementation and a proved connection to
the general queens specification, with compatibility at width16. Wider
certificate fields alone do not supply that result.

No custom kernel has been built. The approved direction remains open. A useful
next kernel/evaluator proposal should identify a measured costly operation,
state a precise refinement theorem, and account for actual input, source,
execution and integration. The old compression-witness requirement applies to
another nearby trial of the capped ADD producer, not to every alternative
computation method. The two reusable avenues are a certified evaluator/checker
for a general finite computation language, and a proved optimization of a
general kernel operation. [RESEARCH-DIRECTION.md](RESEARCH-DIRECTION.md) records
the evidence, primary sources and scope of those options.

## Recovery

Checkpoint197 retains this directory's canonical sources, controls, reviews,
raw logs, reports and permanent markers. [SNAPSHOT-RECOVERY.json](SNAPSHOT-RECOVERY.json)
maps the nine mathematical and twenty-two Python input snapshots to directly
retained, byte-identical canonical files. No generator, earlier ZIP or compiler
is needed to recover these new source bytes. Duplicated snapshots and compiled
objects are intentionally omitted.

Both execution markers are permanent; do not reset them or rerun unchanged
attempts. Source-only restoration verifies saved identities and evidence without
making a new compilation claim. The latest complete numerical source-count
fixture remains checkpoint195's accepted packed-row proof of `cqueens 6 = 4`.
All its sources and recovery instructions, along with older selected results,
remain in checkpoint197.

All checkpoints are the same standalone source/evidence backup format. The
earlier labels for195 and196 described what changed, not different backup
protection. [DURABILITY-REVIEW.md](DURABILITY-REVIEW.md) gives the exact archive
comparison and external dependencies. For new-chat transfer, attach the latest
ZIP and begin with root CONTINUATION, project CONTINUATION and RESTORE. The
compiler/environment, full textbook and complete upstream kernel proof projects
are external; these compact archives are not full machine images.
