import ConsolidatedGeneric

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
Common-width payload padding and exact node/claim codecs.

All widths, planes and row indices are arbitrary natural-number data. The
claim kind retains the existing two-bit operation language. No board size,
expected count, producer correctness or positive-width premise is assumed.
Zero extension preserves every row word and never truncates an overlong input.
-/
namespace ADWH.Experiments.Chapter15.CommonPayloadPadding

open ADWH.Experiments.Chapter15.BulkRouting
open ADWH.Experiments.Chapter15.BulkFields
open ADWH.Experiments.Chapter15.BulkFormula
open ADWH.Experiments.Chapter15.BulkADD

structure Layout where
  rankBits : Nat
  nodeIdBits : Nat
  valueBits : Nat

def Layout.nodeWidth (layout : Layout) : Nat :=
  layout.rankBits + layout.nodeIdBits + layout.nodeIdBits + layout.valueBits

def Layout.claimWidth (layout : Layout) : Nat :=
  2 + layout.nodeIdBits + layout.nodeIdBits + layout.nodeIdBits + layout.rankBits

def Layout.payloadWidth (layout : Layout) : Nat :=
  max layout.nodeWidth layout.claimWidth

def pad (layout : Layout) (planes : List Nat) : List Nat :=
  zeroExtend layout.payloadWidth planes

theorem wordAt_pad (layout : Layout) (planes : List Nat) (i : Nat) :
    wordAt (pad layout planes) i = wordAt planes i := by
  unfold pad
  exact wordAt_zeroExtend layout.payloadWidth planes i

theorem length_pad (layout : Layout) (planes : List Nat) :
    (pad layout planes).length = max layout.payloadWidth planes.length := by
  unfold pad
  exact length_zeroExtend layout.payloadWidth planes

/-- The newly appended high field is zero at every row. This also covers
empty fields and inputs already longer than the common payload width. -/
theorem added_field_zero (layout : Layout) (planes : List Nat) (i : Nat) :
    decodeField planes.length (layout.payloadWidth - planes.length)
      (wordAt (pad layout planes) i) = 0 := by
  change (wordAt (pad layout planes) i / 2 ^ planes.length) %
    2 ^ (layout.payloadWidth - planes.length) = 0
  have hdiv : wordAt (pad layout planes) i / 2 ^ planes.length = 0 :=
    (congrArg (fun value => value / 2 ^ planes.length)
      (wordAt_pad layout planes i)).trans
        (Nat.div_eq_of_lt (wordAt_lt planes i))
  exact (congrArg (fun value => value % 2 ^ (layout.payloadWidth - planes.length))
    hdiv).trans (Nat.zero_mod _)

def decodeNode (layout : Layout) (value : Nat) : NodeDesc :=
  ⟨decodeField 0 layout.rankBits value,
    decodeField layout.rankBits layout.nodeIdBits value,
    decodeField (layout.rankBits + layout.nodeIdBits) layout.nodeIdBits value,
    decodeField (layout.rankBits + layout.nodeIdBits + layout.nodeIdBits)
      layout.valueBits value⟩

def decodeClaim (layout : Layout) (value : Nat) : ClaimDesc :=
  ⟨decodeField 0 2 value,
    decodeField 2 layout.nodeIdBits value,
    decodeField (2 + layout.nodeIdBits) layout.nodeIdBits value,
    decodeField (2 + layout.nodeIdBits + layout.nodeIdBits) layout.nodeIdBits value,
    decodeField (2 + layout.nodeIdBits + layout.nodeIdBits + layout.nodeIdBits)
      layout.rankBits value⟩

def nodePlanes (layout : Layout) (payloads : List Nat) : NodePlanes :=
  ⟨field 0 layout.rankBits payloads,
    field layout.rankBits layout.nodeIdBits payloads,
    field (layout.rankBits + layout.nodeIdBits) layout.nodeIdBits payloads,
    field (layout.rankBits + layout.nodeIdBits + layout.nodeIdBits)
      layout.valueBits payloads⟩

def claimPlanes (layout : Layout) (payloads : List Nat) : ClaimPlanes :=
  ⟨field 0 2 payloads,
    field 2 layout.nodeIdBits payloads,
    field (2 + layout.nodeIdBits) layout.nodeIdBits payloads,
    field (2 + layout.nodeIdBits + layout.nodeIdBits) layout.nodeIdBits payloads,
    field (2 + layout.nodeIdBits + layout.nodeIdBits + layout.nodeIdBits)
      layout.rankBits payloads⟩

theorem nodePlanes_at (layout : Layout) (payloads : List Nat) (i : Nat)
    (hwidth : layout.nodeWidth ≤ payloads.length) :
    (nodePlanes layout payloads).at i = decodeNode layout (wordAt payloads i) := by
  unfold Layout.nodeWidth at hwidth
  have h₀ := wordAt_field payloads 0 layout.rankBits i (by omega)
  have h₁ := wordAt_field payloads layout.rankBits layout.nodeIdBits i (by omega)
  have h₂ := wordAt_field payloads (layout.rankBits + layout.nodeIdBits)
    layout.nodeIdBits i (by omega)
  have h₃ := wordAt_field payloads
    (layout.rankBits + layout.nodeIdBits + layout.nodeIdBits) layout.valueBits i hwidth
  simp only [nodePlanes, NodePlanes.at, decodeNode, h₀, h₁, h₂, h₃]

theorem claimPlanes_at (layout : Layout) (payloads : List Nat) (i : Nat)
    (hwidth : layout.claimWidth ≤ payloads.length) :
    (claimPlanes layout payloads).at i = decodeClaim layout (wordAt payloads i) := by
  unfold Layout.claimWidth at hwidth
  have h₀ := wordAt_field payloads 0 2 i (by omega)
  have h₁ := wordAt_field payloads 2 layout.nodeIdBits i (by omega)
  have h₂ := wordAt_field payloads (2 + layout.nodeIdBits) layout.nodeIdBits i (by omega)
  have h₃ := wordAt_field payloads (2 + layout.nodeIdBits + layout.nodeIdBits)
    layout.nodeIdBits i (by omega)
  have h₄ := wordAt_field payloads
    (2 + layout.nodeIdBits + layout.nodeIdBits + layout.nodeIdBits) layout.rankBits i hwidth
  simp only [claimPlanes, ClaimPlanes.at, decodeClaim, h₀, h₁, h₂, h₃, h₄]

/-- Common padding supplies the node width bound even for a short input. -/
theorem nodePlanes_pad_at (layout : Layout) (payloads : List Nat) (i : Nat) :
    (nodePlanes layout (pad layout payloads)).at i =
      decodeNode layout (wordAt payloads i) := by
  have hwidth : layout.nodeWidth ≤ (pad layout payloads).length := by
    rw [length_pad]
    exact Nat.le_trans
      (Nat.le_max_left layout.nodeWidth layout.claimWidth)
      (Nat.le_max_left layout.payloadWidth payloads.length)
  exact (nodePlanes_at layout (pad layout payloads) i hwidth).trans
    (congrArg (decodeNode layout) (wordAt_pad layout payloads i))

/-- Common padding also supplies the claim bound when the node record is wider. -/
theorem claimPlanes_pad_at (layout : Layout) (payloads : List Nat) (i : Nat) :
    (claimPlanes layout (pad layout payloads)).at i =
      decodeClaim layout (wordAt payloads i) := by
  have hwidth : layout.claimWidth ≤ (pad layout payloads).length := by
    rw [length_pad]
    exact Nat.le_trans
      (Nat.le_max_right layout.nodeWidth layout.claimWidth)
      (Nat.le_max_left layout.payloadWidth payloads.length)
  exact (claimPlanes_at layout (pad layout payloads) i hwidth).trans
    (congrArg (decodeClaim layout) (wordAt_pad layout payloads i))

def nodesFrom (layout : Layout) (table : Nat → Nat) (i : Nat) : NodeDesc :=
  decodeNode layout (table i)

def claimsFrom (layout : Layout) (nodeCount : Nat) (table : Nat → Nat) (i : Nat) : ClaimDesc :=
  decodeClaim layout (table (nodeCount + i))

theorem node_reference (layout : Layout)
    {table : Nat → Nat} {payloads keys : List Nat} {i : Nat}
    (hwidth : layout.nodeWidth ≤ payloads.length)
    (hlookup : wordAt payloads i = table (wordAt keys i)) :
    (nodePlanes layout payloads).at i = nodesFrom layout table (wordAt keys i) := by
  exact (nodePlanes_at layout payloads i hwidth).trans
    (congrArg (decodeNode layout) hlookup)

/-- The dense claim key remains an explicit premise. Padding and a valid
pooled-table lookup alone do not type a request as a claim descriptor. -/
theorem claim_reference (layout : Layout)
    {table : Nat → Nat} {payloads keys : List Nat} {nodeCount i j : Nat}
    (hwidth : layout.claimWidth ≤ payloads.length)
    (hlookup : wordAt payloads i = table (wordAt keys i))
    (hkey : wordAt keys i = nodeCount + j) :
    (claimPlanes layout payloads).at i = claimsFrom layout nodeCount table j := by
  have hvalue : wordAt payloads i = table (nodeCount + j) :=
    hlookup.trans (congrArg table hkey)
  exact (claimPlanes_at layout payloads i hwidth).trans
    (congrArg (decodeClaim layout) hvalue)

end ADWH.Experiments.Chapter15.CommonPayloadPadding

#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.wordAt_pad
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.length_pad
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.added_field_zero
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.nodePlanes_at
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.claimPlanes_at
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.nodePlanes_pad_at
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.claimPlanes_pad_at
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.node_reference
#print axioms ADWH.Experiments.Chapter15.CommonPayloadPadding.claim_reference
