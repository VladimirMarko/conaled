#!/usr/bin/env python3
"""Untrusted fixed-n6 ADD descriptor, reference, and routing producer.

The output is data, not a theorem. All semantic rows and reference slots have
fixed contiguous indices. The copied router is only an untrusted producer.

Common-payload variant: either descriptor family may determine the payload
width. The CLI still accepts only the same pinned n6 trace. Shape/codec tests
use synthetic records directly and do not constitute a counting certificate.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path

TRACE_SHA256 = "39cc75cf079d071dc9d93418b7db23653b0e1d6233277ab96334abe8d6ba2ade"
OPERATION_CAP = 50000
RULES = {("add", "zero"): 0, ("mul", "zero"): 1, ("mul", "one"): 2,
         ("add", "split"): 3, ("mul", "split"): 4,
         ("project", "head"): 5, ("project", "absent"): 6,
         ("add", "constant"): 7, ("mul", "constant"): 8}


def configure(header, nraw, craw):
    """Derive the finite encoding from the pinned input, never from an answer."""
    global NODE_COUNT, CLAIM_COUNT, VARIABLE_LIMIT, TABLE_COUNT, LANES, KEY_BITS, PAYLOAD_BITS
    global NODE_BITS, CLAIM_BITS, RANK_BITS, VALUE_BITS, RULE_BITS, OCCUPIED, SEMANTIC_PLANES
    global NODE_FIELDS, CLAIM_FIELDS, WITNESS_FIELDS, PACKET_FIELDS, BLOCKS, PARAMETERS
    require(header["format"] == "queens-line-add-v1" and header["n"] == 6,
            "Wrong source trace format/board")
    require(header["operation_cap"] == OPERATION_CAP and len(craw) <= OPERATION_CAP,
            "Operation cap changed or exceeded")
    NODE_COUNT, CLAIM_COUNT = len(nraw), len(craw)
    VARIABLE_LIMIT = len(header["variable_order"])
    require(NODE_COUNT > 2 and CLAIM_COUNT > 0 and VARIABLE_LIMIT > 0, "Empty fixture")
    NODE_BITS, CLAIM_BITS = NODE_COUNT.bit_length(), CLAIM_COUNT.bit_length()
    RANK_BITS = VARIABLE_LIMIT.bit_length()
    constant_values = [r.get("value") for r in nraw if r["kind"] == "constant"]
    require(bool(constant_values) and
            all(type(value) is int and value >= 0 for value in constant_values),
            "Invalid constant-node values")
    VALUE_BITS = max(1, max(constant_values).bit_length())
    RULE_BITS = max(RULES.values()).bit_length()
    node_width = RANK_BITS + 2 * NODE_BITS + VALUE_BITS
    claim_width = 2 + 3 * NODE_BITS + RANK_BITS
    PAYLOAD_BITS = max(node_width, claim_width)
    NODE_FIELDS = [("rank", RANK_BITS), ("low", NODE_BITS), ("high", NODE_BITS),
                   ("value", VALUE_BITS), ("unused", PAYLOAD_BITS - node_width)]
    CLAIM_FIELDS = [("kind", 2), ("left", NODE_BITS), ("right", NODE_BITS),
                    ("result", NODE_BITS), ("variable", RANK_BITS)]
    if PAYLOAD_BITS > claim_width:
        CLAIM_FIELDS.append(("unused", PAYLOAD_BITS - claim_width))
    WITNESS_FIELDS = [("rule", RULE_BITS), ("splitRank", RANK_BITS),
                      ("lowOp", CLAIM_BITS), ("highOp", CLAIM_BITS)]
    TABLE_COUNT = NODE_COUNT + CLAIM_COUNT
    BLOCKS, offset = [], TABLE_COUNT
    for name, count in (("node_low", NODE_COUNT), ("node_high", NODE_COUNT),
                        ("operation_left", CLAIM_COUNT), ("operation_right", CLAIM_COUNT),
                        ("operation_result", CLAIM_COUNT), ("child_low", CLAIM_COUNT),
                        ("child_high", CLAIM_COUNT)):
        BLOCKS.append((name, offset, count))
        offset += count
    OCCUPIED = offset
    KEY_BITS = (OCCUPIED - 1).bit_length()
    LANES = 1 << KEY_BITS
    SEMANTIC_PLANES = 1 + KEY_BITS + PAYLOAD_BITS
    PACKET_FIELDS = [{"name": "isDefinition", "bits": 1}, {"name": "key", "bits": KEY_BITS},
                     {"name": "payload", "bits": PAYLOAD_BITS}]
    PARAMETERS = {"board": 6, "variables": VARIABLE_LIMIT, "nodes": NODE_COUNT,
                  "claims": CLAIM_COUNT, "table_definitions": TABLE_COUNT, "lanes": LANES,
                  "key_bits": KEY_BITS, "payload_bits": PAYLOAD_BITS,
                  "node_bits": NODE_BITS, "claim_bits": CLAIM_BITS, "rank_bits": RANK_BITS,
                  "value_bits": VALUE_BITS, "rule_bits": RULE_BITS, "operation_cap": OPERATION_CAP}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def hword(value, rows):
    require(type(value) is int and 0 <= value < 1 << rows, "Invalid finite bitplane")
    return f"0x{value:0{(rows + 3) // 4}x}"


def planes(values, width):
    require(all(type(v) is int and 0 <= v < 1 << width for v in values), "Field overflow")
    buffers = [bytearray((len(values) + 7) // 8) for _ in range(width)]
    for row, value in enumerate(values):
        byte, flag = row >> 3, 1 << (row & 7)
        while value:
            bit = value & -value
            buffers[bit.bit_length() - 1][byte] |= flag
            value -= bit
    return [int.from_bytes(buffer, "little") for buffer in buffers]


def pjson(values, width):
    return [hword(p, len(values)) for p in planes(values, width)]


def encode(row, fields):
    result, shift = 0, 0
    for name, width in fields:
        require(type(width) is int and width >= 0, "Invalid descriptor field width")
        value = row.get(name, 0)
        require(type(value) is int and 0 <= value < 1 << width, f"{name} overflows")
        if name == "unused":
            require(value == 0, "Nonzero descriptor padding")
        result |= value << shift
        shift += width
    require(shift == PAYLOAD_BITS, "Descriptor width mismatch")
    return result


def packed_add(as_, bs, carry):
    require(len(as_) == len(bs), "Adder input widths differ")
    output = []
    for a, b in zip(as_, bs, strict=True):
        output.append(a ^ b ^ carry)
        carry = (a & b) | (carry & (a ^ b))
    output.append(carry)
    return output


def order_record(name, rows, width, active, left, right):
    require(len(active) == len(left) == len(right) == rows, "Order row mismatch")
    slack = []
    for selected, a, b in zip(active, left, right, strict=True):
        require(not selected or a < b, f"Order failed: {name}: {a} < {b}")
        slack.append(b - a - 1 if selected else 0)
    selector = sum(int(flag) << i for i, flag in enumerate(active))
    ap, bp, sp = (planes(vs, width) for vs in (left, right, slack))
    added = packed_add(ap, sp, selector)
    require(all(((a ^ b) & selector) == 0 for a, b in zip(added, bp + [0], strict=True)),
            f"Packed order equation failed: {name}")
    return {"name": name, "rows": rows, "width": width, "selected_rows": sum(active),
            "selector": hword(selector, rows), "left": [hword(x, rows) for x in ap],
            "right": [hword(x, rows) for x in bp], "slack": [hword(x, rows) for x in sp],
            "sum_with_final_carry": [hword(x, rows) for x in added]}


def orders(nodes, claims, witnesses):
    rows, result = NODE_COUNT, []
    branch = [d["rank"] < VARIABLE_LIMIT for d in nodes]
    nids, ranks = list(range(rows)), [d["rank"] for d in nodes]
    result.append(order_record("node_variable_bound", rows, RANK_BITS, branch, ranks, [VARIABLE_LIMIT] * rows))
    for role in ("low", "high"):
        ids = [d[role] for d in nodes]
        result.append(order_record(f"node_{role}_before", rows, NODE_BITS, branch, ids, nids))
        result.append(order_record(f"node_{role}_rank", rows, RANK_BITS, branch, ranks,
                                   [nodes[i]["rank"] for i in ids]))
    rows = CLAIM_COUNT
    binary = [c["kind"] != 2 for c in claims]
    project = [not b for b in binary]
    split = [w["rule"] in (3, 4) for w in witnesses]
    low_use = [w["rule"] in (3, 4, 5, 6) for w in witnesses]
    for role in ("left", "right", "result"):
        active = binary if role == "right" else [True] * rows
        result.append(order_record(f"claim_{role}_bound", rows, NODE_BITS, active,
                                   [c[role] for c in claims], [NODE_COUNT] * rows))
    result.append(order_record("claim_variable_bound", rows, RANK_BITS, project,
                               [c["variable"] for c in claims], [VARIABLE_LIMIT] * rows))
    result.append(order_record("split_variable_bound", rows, RANK_BITS, split,
                               [w["splitRank"] for w in witnesses], [VARIABLE_LIMIT] * rows))
    for role in ("left", "right"):
        top = [nodes[c[role]]["rank"] for c in claims]
        active = [flag and top[i] != witnesses[i]["splitRank"] for i, flag in enumerate(split)]
        result.append(order_record(f"split_{role}_above", rows, RANK_BITS, active,
                                   [w["splitRank"] for w in witnesses], top))
    for role, active in (("low", low_use), ("high", split)):
        result.append(order_record(f"child_{role}_before", rows, CLAIM_BITS, active,
                                   [w[role + "Op"] for w in witnesses], list(range(rows))))
    result.append(order_record("absent_variable_below_rank", rows, RANK_BITS,
                               [w["rule"] == 6 for w in witnesses],
                               [c["variable"] for c in claims], [nodes[c["left"]]["rank"] for c in claims]))
    return result


def unordered(a, b, x, y):
    return (a, b) == (x, y) or (a, b) == (y, x)


def producer_local_check(nodes, claims, witnesses):
    require(nodes[:3] == [{"rank": VARIABLE_LIMIT, "low": 0, "high": 0, "value": v} for v in range(3)],
            "Distinguished zero/one/two descriptors differ")
    for i, node in enumerate(nodes):
        if node["rank"] == VARIABLE_LIMIT:
            require(node["low"] == node["high"] == 0, "Noncanonical constant")
        else:
            require(node["rank"] < VARIABLE_LIMIT and node["value"] == 0, "Invalid branch")
            for role in ("low", "high"):
                require(node[role] < i and node["rank"] < nodes[node[role]]["rank"], "Invalid node order")
    for i, (claim, witness) in enumerate(zip(claims, witnesses, strict=True)):
        kind, left, right, result, variable = (claim[k] for k in ("kind", "left", "right", "result", "variable"))
        rule = witness["rule"]
        require(kind in (0, 1, 2) and max(left, right, result) < NODE_COUNT, "Invalid claim bound")
        require((kind == 2 and variable < VARIABLE_LIMIT and right == 0) or (kind != 2 and variable == 0), "Invalid unused claim fields")
        a, b, r = nodes[left], nodes[right], nodes[result]
        const = lambda d, v: d["rank"] == VARIABLE_LIMIT and d["value"] == v
        if rule in (0, 1, 2):
            require(witness["splitRank"] == witness["lowOp"] == witness["highOp"] == 0, "Unused base witness")
            if rule == 0:
                require(kind == 0 and ((const(a, 0) and result == right) or (const(b, 0) and result == left)), "Bad add zero")
            elif rule == 1:
                require(kind == 1 and (const(a, 0) or const(b, 0)) and const(r, 0), "Bad mul zero")
            else:
                require(kind == 1 and ((const(a, 1) and result == right) or (const(b, 1) and result == left)), "Bad mul one")
        elif rule in (3, 4):
            require(kind == rule - 3 and witness["splitRank"] < VARIABLE_LIMIT, "Bad split kind/variable")
            v, lo, hi = (witness[k] for k in ("splitRank", "lowOp", "highOp"))
            require(lo < i and hi < i, "Split child is not earlier")
            require(a["rank"] >= v and b["rank"] >= v, "Split variable exceeds operand rank")
            ac = (a["low"], a["high"]) if a["rank"] == v else (left, left)
            bc = (b["low"], b["high"]) if b["rank"] == v else (right, right)
            for index, cid in enumerate((lo, hi)):
                child = claims[cid]
                require(child["kind"] == kind and unordered(child["left"], child["right"], ac[index], bc[index]), "Wrong split child claim")
            rl, rh = claims[lo]["result"], claims[hi]["result"]
            require(result == rl if rl == rh else (r["rank"], r["low"], r["high"]) == (v, rl, rh), "Wrong split result")
        elif rule in (5, 6):
            require(kind == 2 and witness["splitRank"] == witness["highOp"] == 0, "Bad projection fields")
            cid = witness["lowOp"]
            require(cid < i, "Projection child is not earlier")
            child = claims[cid]
            require(child["result"] == result, "Projection result mismatch")
            if rule == 5:
                require(a["rank"] == variable and child["kind"] == 0 and
                        unordered(child["left"], child["right"], a["low"], a["high"]), "Bad head projection")
            else:
                require(variable < a["rank"] and child["kind"] == 1 and
                        unordered(child["left"], child["right"], 2, left), "Bad absent projection or missing factor two")
        elif rule in (7, 8):
            require(kind == rule - 7, "Wrong constant arithmetic kind")
            require(witness["splitRank"] == witness["lowOp"] == witness["highOp"] == 0,
                    "Unused constant arithmetic witness")
            require(a["rank"] == b["rank"] == VARIABLE_LIMIT, "Nonconstant arithmetic operands")
            expected = a["value"] + b["value"] if kind == 0 else a["value"] * b["value"]
            require(const(r, expected), "Wrong exact natural constant arithmetic result")
        else:
            raise ValueError("Unsupported local rule")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.trace.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == TRACE_SHA256, "Only the frozen n6 trace is authorized")
    records = [json.loads(line) for line in raw.splitlines()]
    header = next(r for r in records if r["type"] == "header")
    nraw = [r for r in records if r["type"] == "node"]
    craw = [r for r in records if r["type"] == "operation"]
    configure(header, nraw, craw)
    print(json.dumps({"phase": "schema", **PARAMETERS}), flush=True)
    require([r["id"] for r in nraw] == list(range(NODE_COUNT)), "Node occurrence coverage changed")
    require([r["id"] for r in craw] == list(range(CLAIM_COUNT)), "Claim occurrence coverage changed")
    nodes = [{"rank": r.get("variable", VARIABLE_LIMIT), "low": r.get("low", 0),
              "high": r.get("high", 0), "value": r.get("value", 0)} for r in nraw]
    kinds = {"add": 0, "mul": 1, "project": 2}
    claims, witnesses = [], []
    for r in craw:
        projection = r["kind"] == "project"
        claims.append({"kind": kinds[r["kind"]], "left": r["input"] if projection else r["left"],
                       "right": 0 if projection else r["right"], "result": r["result"],
                       "variable": r["variable"] if projection else 0})
        rule = RULES[(r["kind"], r["rule"])]
        witnesses.append({"rule": rule, "splitRank": r["variable"] if rule in (3, 4) else 0,
                          "lowOp": r.get("low_operation", r.get("arithmetic_operation", 0)),
                          "highOp": r.get("high_operation", 0)})
    producer_local_check(nodes, claims, witnesses)
    table = [encode(n, NODE_FIELDS) for n in nodes] + [encode(c, CLAIM_FIELDS) for c in claims]
    packets = [{"isDefinition": True, "key": i, "payload": value} for i, value in enumerate(table)]
    block_details = []
    for name, offset, count in BLOCKS:
        require(len(packets) == offset, "Fixed block offset mismatch")
        active_bits, target_ids = [], []
        for i in range(count):
            node, claim, witness = nodes[i] if i < NODE_COUNT else None, claims[i] if i < CLAIM_COUNT else None, witnesses[i] if i < CLAIM_COUNT else None
            if name in ("node_low", "node_high"):
                active = node["rank"] != VARIABLE_LIMIT
                target = node[name.removeprefix("node_")] if active else 0
                key = target
            elif name.startswith("operation_"):
                role = name.removeprefix("operation_")
                active = role != "right" or claim["kind"] != 2
                target = claim[role] if active else 0
                key = target
            else:
                role = name.removeprefix("child_")
                active = witness["rule"] in ((3, 4, 5, 6) if role == "low" else (3, 4))
                target = witness[role + "Op"] if active else 0
                key = NODE_COUNT + target if active else 0
            require(0 <= key < TABLE_COUNT, "Out-of-range reference")
            packets.append({"isDefinition": False, "key": key, "payload": table[key]})
            active_bits.append(active)
            target_ids.append(target)
        block_details.append({"name": name, "offset": offset, "rows": count,
                              "active_rows": sum(active_bits),
                              "active_selector": hword(sum(int(v) << i for i, v in enumerate(active_bits)), count),
                              "target_ids": target_ids})
    occupied = len(packets)
    require(occupied == OCCUPIED, "Occupied row count mismatch")
    packets += [{"isDefinition": False, "key": 0, "payload": table[0]} for _ in range(LANES - occupied)]
    permutation = [0] * LANES
    for destination, source in enumerate(sorted(range(LANES), key=lambda i: (packets[i]["key"], not packets[i]["isDefinition"], i))):
        permutation[source] = destination
    helper = Path(__file__).with_name("route_support.py")
    spec = importlib.util.spec_from_file_location("untrusted_router", helper)
    router = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(router)
    print(json.dumps({"phase": "routing", "lanes": LANES, "planes": SEMANTIC_PLANES}), flush=True)
    route = router.route_case("fixed-n6-add-descriptor-lookups", packets, permutation, PACKET_FIELDS)
    print(json.dumps({"phase": "routing-complete", "stages": len(route["stages"])}), flush=True)
    order_checks = orders(nodes, claims, witnesses)
    key_additions = []
    for name, field, allowed in (("child_low", "lowOp", (3, 4, 5, 6)), ("child_high", "highOp", (3, 4))):
        selector = sum(int(w["rule"] in allowed) << i for i, w in enumerate(witnesses))
        lhs = planes([w[field] for w in witnesses], KEY_BITS)
        rhs = planes([NODE_COUNT] * CLAIM_COUNT, KEY_BITS)
        result = packed_add(lhs, rhs, 0)
        offset = next(o for n, o, _ in BLOCKS if n == name)
        targets = planes([packets[offset + i]["key"] for i in range(CLAIM_COUNT)], KEY_BITS)
        require(all(((a ^ b) & selector) == 0 for a, b in zip(result, targets + [0], strict=True)), "Dense child key translation failed")
        key_additions.append({"name": name, "rows": CLAIM_COUNT, "width": KEY_BITS,
                              "selector": hword(selector, CLAIM_COUNT),
                              "left": [hword(x, CLAIM_COUNT) for x in lhs],
                              "right": [hword(x, CLAIM_COUNT) for x in rhs],
                              "sum_with_final_carry": [hword(x, CLAIM_COUNT) for x in result],
                              "request_key": [hword(x, CLAIM_COUNT) for x in targets]})
    # One payload bit changes, with definition table and every switch unchanged.
    bad_row, bad_bit = TABLE_COUNT + 3, RANK_BITS + 2 * NODE_BITS
    bad_before = packets[bad_row]["payload"]
    negative_planes = {name: [int(v, 16) for v in values] for name, values in route["initial_bitplanes"].items()}
    negative_planes["payload"][bad_bit] ^= 1 << bad_row
    for stage in route["stages"]:
        distance, mask = stage["distance"], int(stage["mask"], 16)
        for values in negative_planes.values():
            for i, word in enumerate(values):
                delta = ((word >> distance) ^ word) & mask
                values[i] = word ^ delta ^ (delta << distance)
    first_split = next(i for i, w in enumerate(witnesses) if w["rule"] in (3, 4))
    bad_witness = dict(witnesses[first_split])
    bad_witness["lowOp"] = first_split
    bad_key = NODE_COUNT + first_split
    rule_counts = Counter(f"{r['kind']}/{r['rule']}" for r in craw)
    output = {
        "format": "frozen-n6-packed-add-v1", "formal_evidence": False,
        "scope": "Fixed trace descriptor/local-rule/routing diagnostic; no queens source bridge",
        "input_trace_sha256": TRACE_SHA256,
        "parameters": PARAMETERS,
        "rule_codes": {f"{kind}/{rule}": value for (kind, rule), value in RULES.items()},
        "descriptor_fields": {"node": NODE_FIELDS, "claim": CLAIM_FIELDS, "witness": WITNESS_FIELDS},
        "packet_fields": PACKET_FIELDS, "nodes": nodes, "claims": claims, "witnesses": witnesses,
        "table_payloads": table, "blocks": block_details,
        "witness_bitplanes": {name: pjson([w[name] for w in witnesses], width) for name, width in WITNESS_FIELDS},
        "order_checks": order_checks, "key_addition_checks": key_additions,
        "coefficient_two": {"node_id": 2, "descriptor": nodes[2], "payload": table[2],
                            "projection_claim_ids": [i for i, w in enumerate(witnesses) if w["rule"] == 6]},
        "packets": packets, "destination_of_input": permutation, "route": route,
        "negative_reference": {"row": bad_row, "field": "payload", "bit": bad_bit,
                               "before": bad_before, "after": bad_before ^ (1 << bad_bit),
                               "routing_controls_unchanged": True,
                               "final_bitplanes": {name: [hword(x, LANES) for x in values] for name, values in negative_planes.items()}},
        "negative_self_reference": {"claim_id": first_split, "field": "lowOp",
                                    "before": witnesses[first_split]["lowOp"], "after": first_split,
                                    "witness": bad_witness, "request_row": next(o for n, o, _ in BLOCKS if n == "child_low") + first_split,
                                    "request_key": bad_key, "request_payload": table[bad_key],
                                    "scope": "Local proof witness rejection with a genuine referenced table value; no second routing claim"},
        "statistics": {"rule_counts": dict(sorted(rule_counts.items())), "node_branches": sum(n["rank"] < VARIABLE_LIMIT for n in nodes),
                       "occupied_rows": occupied, "padding_requests": LANES - occupied,
                       "reference_slots": occupied - TABLE_COUNT, "active_references": sum(b["active_rows"] for b in block_details),
                       "request_occurrences": LANES - TABLE_COUNT, "semantic_planes": SEMANTIC_PLANES,
                       "routing_stages": len(route["stages"]), "stage_plane_transitions": SEMANTIC_PLANES * len(route["stages"]),
                       "strict_order_selected_rows": sum(c["selected_rows"] for c in order_checks),
                       "known_expected_counts_used_as_premises": False},
    }
    print(json.dumps({"phase": "writing-certificate"}), flush=True)
    with args.output.open("x") as stream:
        json.dump(output, stream, sort_keys=True, separators=(",", ":"))
        stream.write("\n")
    print(json.dumps({"status": "produced", "formal_evidence": False, "output_bytes": args.output.stat().st_size,
                      "output_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(), **output["statistics"]}, sort_keys=True))


if __name__ == "__main__":
    main()
