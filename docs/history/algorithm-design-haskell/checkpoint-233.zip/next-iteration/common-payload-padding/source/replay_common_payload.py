#!/usr/bin/env python3
"""Independent replay of the fixed n6 packed ADD certificate.

This file imports neither producer nor router. It reconstructs typed records,
checks every local rule, derives canonical ADD functions, verifies all packed
order/addition equations, and replays routing both as whole-occurrence swaps
and as packed words. Python acceptance is diagnostic evidence only.

Common-payload variant: shape derivation remains independent of the producer.
Optional claim padding is checked as zero and removed before semantic checks;
the same pinned n6 CLI input and complete replay obligations are retained.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

PINNED_TRACE = "39cc75cf079d071dc9d93418b7db23653b0e1d6233277ab96334abe8d6ba2ade"
OPERATION_CAP = 50000


def infer_shape(source):
    """Independent shape derivation from the exact source, ignoring answer metadata."""
    global V, NN, NO, M, N, RANK_WIDTH, NODE_WIDTH, OP_WIDTH, VALUE_WIDTH, RULE_WIDTH
    global KEY_WIDTH, PAYLOAD_WIDTH, OCCUPIED, SEMANTIC_WIDTH, ROLE_LAYOUT, FIELD_WIDTHS
    global PARAMETERS, DESCRIPTOR_FIELDS
    headers = [r for r in source if r["type"] == "header"]
    must(len(headers) == 1, "Source header occurrence count")
    h = headers[0]
    must(h["format"] == "queens-line-add-v1" and h["n"] == 6, "Source kind differs")
    must(h["operation_cap"] == OPERATION_CAP, "Source operation cap changed")
    ns = [r for r in source if r["type"] == "node"]
    cs = [r for r in source if r["type"] == "operation"]
    NN, NO, V = len(ns), len(cs), len(h["variable_order"])
    must(NN > 2 and 0 < NO <= OPERATION_CAP and V > 0, "Source size bound")
    def width(bound):
        natural(bound)
        result = 0
        while bound:
            result += 1
            bound //= 2
        return max(1, result)
    RANK_WIDTH, NODE_WIDTH, OP_WIDTH = width(V), width(NN), width(NO)
    constant_values = [r.get("value") for r in ns if r["kind"] == "constant"]
    must(bool(constant_values), "Missing constant-node values")
    for value in constant_values:
        natural(value)
    VALUE_WIDTH = width(max(constant_values))
    RULE_WIDTH = width(8)
    node_width, claim_width = RANK_WIDTH + 2 * NODE_WIDTH + VALUE_WIDTH, 2 + 3 * NODE_WIDTH + RANK_WIDTH
    PAYLOAD_WIDTH = max(node_width, claim_width)
    M = NN + NO
    ROLE_LAYOUT, offset = {}, M
    for name, size in (("node_low", NN), ("node_high", NN), ("operation_left", NO),
                       ("operation_right", NO), ("operation_result", NO),
                       ("child_low", NO), ("child_high", NO)):
        ROLE_LAYOUT[name] = (offset, size)
        offset += size
    OCCUPIED = offset
    N, KEY_WIDTH = 1, 0
    while N < OCCUPIED:
        N *= 2
        KEY_WIDTH += 1
    SEMANTIC_WIDTH = 1 + KEY_WIDTH + PAYLOAD_WIDTH
    FIELD_WIDTHS = {"isDefinition": 1, "key": KEY_WIDTH, "payload": PAYLOAD_WIDTH}
    DESCRIPTOR_FIELDS = {
        "node": [["rank", RANK_WIDTH], ["low", NODE_WIDTH], ["high", NODE_WIDTH],
                 ["value", VALUE_WIDTH], ["unused", PAYLOAD_WIDTH - node_width]],
        "claim": [["kind", 2], ["left", NODE_WIDTH], ["right", NODE_WIDTH],
                  ["result", NODE_WIDTH], ["variable", RANK_WIDTH]],
        "witness": [["rule", RULE_WIDTH], ["splitRank", RANK_WIDTH], ["lowOp", OP_WIDTH], ["highOp", OP_WIDTH]]}
    if PAYLOAD_WIDTH > claim_width:
        DESCRIPTOR_FIELDS["claim"].append(["unused", PAYLOAD_WIDTH - claim_width])
    PARAMETERS = {"board": 6, "variables": V, "nodes": NN, "claims": NO,
                  "table_definitions": M, "lanes": N, "key_bits": KEY_WIDTH, "payload_bits": PAYLOAD_WIDTH,
                  "node_bits": NODE_WIDTH, "claim_bits": OP_WIDTH, "rank_bits": RANK_WIDTH,
                  "value_bits": VALUE_WIDTH, "rule_bits": RULE_WIDTH, "operation_cap": OPERATION_CAP}


class Rejected(ValueError):
    pass


def must(condition, message):
    if not condition:
        raise Rejected(message)


def natural(value, maximum=None):
    must(type(value) is int and value >= 0 and (maximum is None or value < maximum), "Invalid finite natural")
    return value


def word(raw, rows):
    must(type(raw) is str and re.fullmatch(r"0x[0-9a-f]{" + str((rows + 3) // 4) + "}", raw) is not None,
         "Noncanonical finite bitplane")
    value = int(raw, 16)
    must(value < 2 ** rows, "Bitplane leaves its finite rows")
    return value


def word_list(raw, width, rows):
    must(type(raw) is list and len(raw) == width, "Bitplane width differs")
    return [word(p, rows) for p in raw]


def scalar_planes(values, width):
    """Independent byte-oriented transposition; no producer/router import."""
    result = []
    for value in values:
        natural(value, 2 ** width)
    for bit in range(width):
        bytes_ = bytearray()
        for start in range(0, len(values), 8):
            byte = 0
            for offset, value in enumerate(values[start:start + 8]):
                byte |= ((value >> bit) & 1) << offset
            bytes_.append(byte)
        result.append(int.from_bytes(bytes_, "little"))
    return result


def at(ps, row):
    result = 0
    for bit in range(len(ps) - 1, -1, -1):
        result = 2 * result + ((ps[bit] >> row) & 1)
    return result


def decode_fields(payload, fields):
    must(all(type(width) is int and width >= 0 for _, width in fields),
         "Invalid descriptor field width")
    natural(payload, 2 ** sum(width for _, width in fields))
    result = {}
    for name, width in fields:
        result[name] = payload % (2 ** width)
        payload //= 2 ** width
    must(payload == 0, "Descriptor upper bits")
    return result


def node_decode(payload):
    result = decode_fields(payload, DESCRIPTOR_FIELDS["node"])
    must(result.pop("unused") == 0, "Node unused high bits")
    return result


def claim_decode(payload):
    result = decode_fields(payload, DESCRIPTOR_FIELDS["claim"])
    if "unused" in result:
        must(result.pop("unused") == 0, "Claim unused high bits")
    return result


def pair_matches(c, kind, x, y):
    return c["kind"] == kind and ((c["left"] == x and c["right"] == y) or
                                  (c["left"] == y and c["right"] == x))


def check_local(nodes, claims, ws):
    def terminal(n, val):
        return n == {"rank": V, "low": 0, "high": 0, "value": val}
    must(all(terminal(nodes[i], i) for i in range(3)), "distinguished_constants")
    for i in range(NN):
        d = nodes[i]
        must(set(d) == {"rank", "low", "high", "value"}, "node_fields")
        for value in d.values():
            natural(value)
        if d["rank"] == V:
            must(d["low"] == 0 and d["high"] == 0, "constant_unused_fields")
        else:
            must(d["rank"] < V and d["value"] == 0, "branch_fields")
            for role in ["low", "high"]:
                child = d[role]
                must(child < i, "node_child_before")
                must(nodes[child]["rank"] > d["rank"], "node_child_rank")
    for i in range(NO):
        c, w = claims[i], ws[i]
        must(set(c) == {"kind", "left", "right", "result", "variable"}, "claim_fields")
        must(set(w) == {"rule", "splitRank", "lowOp", "highOp"}, "witness_fields")
        for value in list(c.values()) + list(w.values()):
            natural(value)
        must(c["kind"] < 3, "claim_kind")
        must(c["left"] < NN and c["result"] < NN, "node_reference_bound")
        if c["kind"] == 2:
            must(c["right"] == 0 and c["variable"] < V, "projection_fields")
        else:
            must(c["right"] < NN and c["variable"] == 0, "binary_fields")
        a, b, out = nodes[c["left"]], nodes[c["right"]], nodes[c["result"]]
        tag = w["rule"]
        must(tag < 9, "rule_code")
        if tag <= 2:
            must(w["splitRank"] == w["lowOp"] == w["highOp"] == 0, "base_unused_fields")
            if tag == 0:
                must(c["kind"] == 0, "add_zero_kind")
                must((terminal(a, 0) and c["result"] == c["right"]) or
                     (terminal(b, 0) and c["result"] == c["left"]), "add_zero_result")
            elif tag == 1:
                must(c["kind"] == 1, "mul_zero_kind")
                must((terminal(a, 0) or terminal(b, 0)) and terminal(out, 0), "mul_zero_result")
            else:
                must(c["kind"] == 1, "mul_one_kind")
                must((terminal(a, 1) and c["result"] == c["right"]) or
                     (terminal(b, 1) and c["result"] == c["left"]), "mul_one_result")
        elif tag <= 4:
            must(c["kind"] == tag - 3, "split_kind")
            split = w["splitRank"]
            must(split < V, "split_variable_bound")
            must(w["lowOp"] < i, "child_low_before")
            must(w["highOp"] < i, "child_high_before")
            cofactors = []
            for target, desc in [(c["left"], a), (c["right"], b)]:
                must(split <= desc["rank"], "split_operand_order")
                cofactors.append([desc["low"], desc["high"]] if split == desc["rank"] else [target, target])
            subclaims = [claims[w["lowOp"]], claims[w["highOp"]]]
            for side, subclaim in enumerate(subclaims):
                must(pair_matches(subclaim, c["kind"], cofactors[0][side], cofactors[1][side]), "split_child_inputs")
            lo, hi = subclaims[0]["result"], subclaims[1]["result"]
            if lo == hi:
                must(c["result"] == lo, "split_reduced_output")
            else:
                must(out["rank"] == split and out["low"] == lo and out["high"] == hi,
                     "split_branch_output")
        elif tag in (5, 6):
            must(c["kind"] == 2, "projection_kind")
            must(w["splitRank"] == 0 and w["highOp"] == 0, "projection_unused_fields")
            must(w["lowOp"] < i, "child_low_before")
            subclaim = claims[w["lowOp"]]
            must(subclaim["result"] == c["result"], "projection_child_result")
            if tag == 5:
                must(a["rank"] == c["variable"], "projection_head_variable")
                must(pair_matches(subclaim, 0, a["low"], a["high"]), "projection_head_inputs")
            else:
                must(c["variable"] < a["rank"], "projection_absent_rank")
                must(pair_matches(subclaim, 1, 2, c["left"]), "projection_factor_two")
        else:
            must(c["kind"] == tag - 7, "constant_arithmetic_kind")
            must(w["splitRank"] == w["lowOp"] == w["highOp"] == 0, "constant_unused_witness")
            must(a["rank"] == b["rank"] == V, "constant_arithmetic_operands")
            actual = a["value"] + b["value"] if tag == 7 else a["value"] * b["value"]
            must(terminal(out, actual), "constant_arithmetic_result")


class CanonicalADD:
    """An independent symbolic function calculation, without operation witnesses."""
    def __init__(self):
        self.terms, self.interned, self.apply_cache, self.project_cache = [], {}, {}, {}
        self.apply_calls, self.project_calls = 0, 0

    def intern(self, term):
        if term not in self.interned:
            self.interned[term] = len(self.terms)
            self.terms.append(term)
        return self.interned[term]

    def const(self, value):
        return self.intern(("constant", value))

    def branch(self, variable, low, high):
        return low if low == high else self.intern(("branch", variable, low, high))

    def top(self, i):
        t = self.terms[i]
        return V if t[0] == "constant" else t[1]

    def apply(self, kind, x, y):
        self.apply_calls += 1
        key = (kind, min(x, y), max(x, y))
        if key in self.apply_cache:
            return self.apply_cache[key]
        tx, ty = self.terms[x], self.terms[y]
        if tx[0] == ty[0] == "constant":
            answer = self.const(tx[1] + ty[1] if kind == 0 else tx[1] * ty[1])
        else:
            variable = min(self.top(x), self.top(y))
            xc = tx[2:] if self.top(x) == variable else (x, x)
            yc = ty[2:] if self.top(y) == variable else (y, y)
            answer = self.branch(variable, self.apply(kind, xc[0], yc[0]), self.apply(kind, xc[1], yc[1]))
        self.apply_cache[key] = answer
        return answer

    def project(self, variable, x):
        self.project_calls += 1
        key = (variable, x)
        if key in self.project_cache:
            return self.project_cache[key]
        top, t = self.top(x), self.terms[x]
        if top > variable:
            answer = self.apply(0, x, x)
        elif top == variable:
            answer = self.apply(0, t[2], t[3])
        else:
            answer = self.branch(top, self.project(variable, t[2]), self.project(variable, t[3]))
        self.project_cache[key] = answer
        return answer


def independent_semantics(nodes, claims):
    model, meanings = CanonicalADD(), []
    for d in nodes:
        meanings.append(model.const(d["value"]) if d["rank"] == V else
                        model.branch(d["rank"], meanings[d["low"]], meanings[d["high"]]))
    initial_canonical_nodes = len(model.terms)
    for i, c in enumerate(claims):
        x = meanings[c["left"]]
        actual = model.project(c["variable"], x) if c["kind"] == 2 else model.apply(c["kind"], x, meanings[c["right"]])
        must(actual == meanings[c["result"]], f"Independently computed function differs at claim {i}")
    return {"all_claim_functions_match": True, "claims": len(claims),
            "node_meanings_constructed_from_descriptors": True,
            "witnesses_used_in_semantic_calculation": False,
            "initial_canonical_nodes": initial_canonical_nodes, "allocated_canonical_nodes": len(model.terms),
            "unique_apply_operations": len(model.apply_cache), "apply_calls": model.apply_calls,
            "unique_projections": len(model.project_cache), "project_calls": model.project_calls,
            "maximum_constant": max(t[1] for t in model.terms if t[0] == "constant")}


def packet_fields(p):
    must(type(p) is dict and set(p) == set(FIELD_WIDTHS), "Packet omits a semantic field")
    must(type(p["isDefinition"]) is bool, "Marker is not Boolean")
    natural(p["key"], 2 ** KEY_WIDTH)
    natural(p["payload"], 2 ** PAYLOAD_WIDTH)


def expected_reference(name, i, nodes, claims, ws):
    if name.startswith("node_"):
        used = nodes[i]["rank"] < V
        ident = nodes[i][name[5:]] if used else 0
        key = ident
    elif name.startswith("operation_"):
        role = name[10:]
        used = role != "right" or claims[i]["kind"] < 2
        ident = claims[i][role] if used else 0
        key = ident
    else:
        low = name == "child_low"
        used = ws[i]["rule"] in ((3, 4, 5, 6) if low else (3, 4))
        ident = ws[i]["lowOp" if low else "highOp"] if used else 0
        key = NN + ident if used else 0
    return used, ident, key


def check_blocks(data, nodes, claims, ws, table):
    packets = data["packets"]
    must(len(packets) == N, "Packet count differs")
    for i, packet in enumerate(packets):
        packet_fields(packet)
        must(packet["isDefinition"] == (i < M), "Definition prefix differs")
        if i < M:
            must(packet["key"] == i and packet["payload"] == table[i], "Definition differs from exact table")
        else:
            must(packet["key"] < M and packet["payload"] == table[packet["key"]], "Direct reference table mismatch")
    must(len(data["blocks"]) == len(ROLE_LAYOUT), "Role block coverage differs")
    active_total = 0
    for (name, (offset, size)), metadata in zip(ROLE_LAYOUT.items(), data["blocks"], strict=True):
        must(metadata["name"] == name and metadata["offset"] == offset and metadata["rows"] == size,
             "Fixed role layout changed")
        selected, targets = [], []
        for i in range(size):
            used, target, key = expected_reference(name, i, nodes, claims, ws)
            selected.append(int(used))
            targets.append(target)
            packet = packets[offset + i]
            must(packet["key"] == key and packet["payload"] == table[key], "Role reference disagrees with descriptor/witness")
        bits = scalar_planes(selected, 1)[0]
        must(word(metadata["active_selector"], size) == bits and metadata["active_rows"] == sum(selected),
             "Role activity mask differs")
        must(metadata["target_ids"] == targets, "Role target metadata differs")
        active_total += sum(selected)
    must(all(p == {"isDefinition": False, "key": 0, "payload": table[0]} for p in packets[OCCUPIED:]),
         "Padding is not the documented genuine zero-node request")
    return {"fixed_reference_slots": OCCUPIED - M, "active_reference_occurrences": active_total,
            "inactive_reference_slots": OCCUPIED - M - active_total, "padding_request_occurrences": N - OCCUPIED,
            "all_semantic_rows_covered": True, "external_gather_map_used": False}


def order_spec(name, nodes, claims, ws):
    if name.startswith("node_"):
        selected = [n["rank"] < V for n in nodes]
        if name == "node_variable_bound":
            return RANK_WIDTH, selected, [n["rank"] for n in nodes], [V] * NN
        role = "low" if "_low_" in name else "high"
        if name.endswith("before"):
            return NODE_WIDTH, selected, [n[role] for n in nodes], list(range(NN))
        return RANK_WIDTH, selected, [n["rank"] for n in nodes], [nodes[n[role]]["rank"] for n in nodes]
    if name in ("claim_left_bound", "claim_right_bound", "claim_result_bound"):
        role = name.split("_")[1]
        return NODE_WIDTH, [role != "right" or c["kind"] != 2 for c in claims], [c[role] for c in claims], [NN] * NO
    if name == "claim_variable_bound":
        return RANK_WIDTH, [c["kind"] == 2 for c in claims], [c["variable"] for c in claims], [V] * NO
    if name == "split_variable_bound":
        return RANK_WIDTH, [w["rule"] in (3, 4) for w in ws], [w["splitRank"] for w in ws], [V] * NO
    if name in ("split_left_above", "split_right_above"):
        role = name.split("_")[1]
        right = [nodes[c[role]]["rank"] for c in claims]
        return RANK_WIDTH, [w["rule"] in (3, 4) and right[i] > w["splitRank"] for i, w in enumerate(ws)], [w["splitRank"] for w in ws], right
    if name in ("child_low_before", "child_high_before"):
        low = name == "child_low_before"
        return OP_WIDTH, [w["rule"] in ((3, 4, 5, 6) if low else (3, 4)) for w in ws], [w["lowOp" if low else "highOp"] for w in ws], list(range(NO))
    must(name == "absent_variable_below_rank", "Unknown order obligation")
    return RANK_WIDTH, [w["rule"] == 6 for w in ws], [c["variable"] for c in claims], [nodes[c["left"]]["rank"] for c in claims]


def add_with_majority(as_, bs, carry):
    must(len(as_) == len(bs), "Unequal adder widths")
    result = []
    for a, b in zip(as_, bs, strict=True):
        result.append(a ^ b ^ carry)
        carry = (a & b) | (a & carry) | (b & carry)
    return result + [carry]


def check_arithmetic(data, nodes, claims, ws):
    names = ["node_variable_bound", "node_low_before", "node_low_rank", "node_high_before", "node_high_rank",
             "claim_left_bound", "claim_right_bound", "claim_result_bound", "claim_variable_bound",
             "split_variable_bound", "split_left_above", "split_right_above", "child_low_before",
             "child_high_before", "absent_variable_below_rank"]
    must([r["name"] for r in data["order_checks"]] == names, "Order obligation coverage differs")
    selected_total = 0
    details = []
    for record in data["order_checks"]:
        width, flags, left, right = order_spec(record["name"], nodes, claims, ws)
        rows = len(flags)
        selector = scalar_planes([int(f) for f in flags], 1)[0]
        must(record["rows"] == rows and record["width"] == width, "Order width/rows differ")
        must(word(record["selector"], rows) == selector and record["selected_rows"] == sum(flags), "Order selector differs")
        ap, bp, sp = [word_list(record[name], width, rows) for name in ["left", "right", "slack"]]
        must(ap == scalar_planes(left, width) and bp == scalar_planes(right, width), "Order operand field binding differs")
        for i, selected in enumerate(flags):
            slack = at(sp, i)
            must(left[i] + slack + 1 == right[i] if selected else slack == 0, "Invalid strict natural slack")
        actual = add_with_majority(ap, sp, selector)
        supplied = word_list(record["sum_with_final_carry"], width + 1, rows)
        must(actual == supplied, "Full ripple carry equation differs")
        must(all(((a ^ b) & selector) == 0 for a, b in zip(actual, bp + [0], strict=True)), "Packed strict order comparison failed")
        selected_total += sum(flags)
        details.append({"name": record["name"], "selected": sum(flags), "width": width, "full_carry_retained": True})
    must([r["name"] for r in data["key_addition_checks"]] == ["child_low", "child_high"], "Dense key addition coverage differs")
    for record in data["key_addition_checks"]:
        low = record["name"] == "child_low"
        flags = [w["rule"] in ((3, 4, 5, 6) if low else (3, 4)) for w in ws]
        selector = scalar_planes([int(f) for f in flags], 1)[0]
        ids = [w["lowOp" if low else "highOp"] for w in ws]
        offset = ROLE_LAYOUT[record["name"]][0]
        keys = [data["packets"][offset + i]["key"] for i in range(NO)]
        must(record["rows"] == NO and record["width"] == KEY_WIDTH and word(record["selector"], NO) == selector,
             "Dense key addition shape differs")
        left, right, kp = [word_list(record[name], KEY_WIDTH, NO) for name in ["left", "right", "request_key"]]
        must(left == scalar_planes(ids, KEY_WIDTH) and right == scalar_planes([NN] * NO, KEY_WIDTH) and kp == scalar_planes(keys, KEY_WIDTH),
             "Dense key operands do not bind to IDs and role block")
        full = add_with_majority(left, right, 0)
        must(full == word_list(record["sum_with_final_carry"], KEY_WIDTH + 1, NO), "Dense key addition differs")
        must(all(((a ^ b) & selector) == 0 for a, b in zip(full, kp + [0], strict=True)), "Dense key translation failed")
        must(all(not flags[i] or keys[i] == NN + ids[i] for i in range(NO)), "Scalar dense key translation failed")
    return {"order_families": details, "strict_order_lane_checks": selected_total,
            "dense_key_addition_lane_checks": sum(w["rule"] in (3, 4, 5, 6) for w in ws) + sum(w["rule"] in (3, 4) for w in ws), "all_final_carries_checked": True}


def read_route_planes(raw):
    must(type(raw) is dict and set(raw) == set(FIELD_WIDTHS), "Route omits fields")
    return {name: word_list(raw[name], width, N) for name, width in FIELD_WIDTHS.items()}


def encode_packets(packets):
    return {name: scalar_planes([int(p[name]) for p in packets], width) for name, width in FIELD_WIDTHS.items()}


def adjacency(planes):
    queries = (2 ** N - 1) ^ planes["isDefinition"][0]
    return (queries & 1) == 0 and all(((p ^ (p << 1)) & queries) == 0
                                    for name in ("key", "payload") for p in planes[name])


def check_route(data):
    packets, route, permutation = data["packets"], data["route"], data["destination_of_input"]
    must(len(permutation) == N and all(type(i) is int for i in permutation) and sorted(permutation) == list(range(N)),
         "Destination mapping is not a permutation")
    must(route["n"] == N and route["k"] == KEY_WIDTH, "Wrong route dimensions")
    distances = [2 ** i for i in range(KEY_WIDTH)] + [2 ** i for i in range(KEY_WIDTH - 2, -1, -1)]
    must(len(route["stages"]) == len(distances), "Wrong route stage count")
    packed = read_route_planes(route["initial_bitplanes"])
    must(packed == encode_packets(packets), "Initial bitplanes do not encode every packet field")
    must(packed["isDefinition"] == [2 ** M - 1], "Marker is not exact prefix")
    occurrences = list(range(N))
    selected_switches = 0
    for number, (stage, distance) in enumerate(zip(route["stages"], distances, strict=True)):
        must(set(stage) == {"number", "distance", "mask", "input_bitplanes", "output_bitplanes"}, "Unexpected stage fields")
        must(stage["number"] == number and stage["distance"] == distance, "Fixed stage topology differs")
        mask = word(stage["mask"], N)
        must((mask & (mask >> distance)) == 0 and ((mask << distance) >> N) == 0, "Mask is not proper and bounded")
        must(read_route_planes(stage["input_bitplanes"]) == packed, "Stage input chain differs")
        next_packed = {}
        for name, values in packed.items():
            changed = []
            for value in values:
                delta = (value ^ (value >> distance)) & mask
                changed.append(value ^ delta ^ (delta << distance))
            next_packed[name] = changed
        must(next_packed == read_route_planes(stage["output_bitplanes"]), "Packed stage calculation differs")
        for byte_index, byte in enumerate(mask.to_bytes((N + 7) // 8, "little")):
            for bit in range(8):
                if (byte >> bit) & 1:
                    row = 8 * byte_index + bit
                    must((row & distance) == 0, "Benes switch is not a lower wire")
                    occurrences[row], occurrences[row + distance] = occurrences[row + distance], occurrences[row]
                    selected_switches += 1
        packed = next_packed
    must(all(occurrences[permutation[source]] == source for source in range(N)), "Whole occurrence route differs from target")
    output = [packets[source] for source in occurrences]
    must(route["output_packets"] == output, "Final packet records do not match scalar swaps")
    must(packed == encode_packets(output), "Final packed and scalar routes differ")
    tup = lambda p: (p["isDefinition"], p["key"], p["payload"])
    must(Counter(map(tup, output)) == Counter(map(tup, packets)), "Semantic packet multiplicities changed")
    must(adjacency(packed), "Packed routed adjacency rejected positive certificate")
    must(output[0]["isDefinition"] and all(p["isDefinition"] or
         (p["key"], p["payload"]) == (output[i - 1]["key"], output[i - 1]["payload"])
         for i, p in enumerate(output) if i > 0), "Scalar routed adjacency rejected positive certificate")
    neg = data["negative_reference"]
    badrow, bit = natural(neg["row"], N), natural(neg["bit"], PAYLOAD_WIDTH)
    must(neg["field"] == "payload" and not packets[badrow]["isDefinition"], "Negative does not mutate a request payload")
    must(neg["before"] == packets[badrow]["payload"] and neg["after"] == neg["before"] ^ (1 << bit), "Negative is not exactly one bit")
    must(neg["routing_controls_unchanged"] is True, "Negative controls claim differs")
    mutated = read_route_planes(route["initial_bitplanes"])
    mutated["payload"][bit] ^= 2 ** badrow
    for stage in route["stages"]:
        distance, mask = stage["distance"], word(stage["mask"], N)
        for name, values in list(mutated.items()):
            mutated[name] = [v ^ (((v ^ (v >> distance)) & mask)) ^
                             (((v ^ (v >> distance)) & mask) << distance) for v in values]
    must(mutated == read_route_planes(neg["final_bitplanes"]), "Negative final route differs")
    expected = {name: list(values) for name, values in packed.items()}
    expected["payload"][bit] ^= 2 ** permutation[badrow]
    must(mutated == expected, "Negative does not preserve all other output fields/occurrences")
    must(not adjacency(mutated), "Corrupt request unexpectedly passed adjacency")
    return {"lanes": N, "definitions": M, "requests": N - M, "semantic_planes": SEMANTIC_WIDTH,
            "stages": len(distances), "stage_plane_transitions_checked": SEMANTIC_WIDTH * len(distances),
            "selected_switches": selected_switches, "whole_occurrences_preserved": True,
            "all_semantic_fields_jointly_routed": True, "scalar_and_packed_routes_agree": True,
            "positive_adjacency": True, "single_payload_bit_mutation_rejected": True,
            "negative_changed_request_row": badrow, "negative_output_row": permutation[badrow],
            "negative_routing_controls_unchanged": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw_trace, raw_certificate = args.trace.read_bytes(), args.certificate.read_bytes()
    trace_hash, certificate_hash = (hashlib.sha256(raw).hexdigest() for raw in (raw_trace, raw_certificate))
    must(trace_hash == PINNED_TRACE, "Replay only accepts the fixed n6 input")
    source = [json.loads(line) for line in raw_trace.splitlines()]
    infer_shape(source)
    print(json.dumps({"phase": "schema", **PARAMETERS}), flush=True)
    data = json.loads(raw_certificate)
    del raw_certificate
    must(data["format"] == "frozen-n6-packed-add-v1" and data["formal_evidence"] is False,
         "Wrong certificate format or formal-status claim")
    must(data["input_trace_sha256"] == trace_hash, "Certificate input binding differs")
    must(data["parameters"] == PARAMETERS, "Fixture parameters changed")
    table = data["table_payloads"]
    must(len(table) == M, "Definition table count differs")
    nodes = [node_decode(p) for p in table[:NN]]
    claims = [claim_decode(p) for p in table[NN:]]
    must(data["nodes"] == nodes and data["claims"] == claims, "Scalar descriptors do not decode from payload table")
    source_nodes = [r for r in source if r["type"] == "node"]
    source_claims = [r for r in source if r["type"] == "operation"]
    must([r["id"] for r in source_nodes] == list(range(NN)) and
         [r["id"] for r in source_claims] == list(range(NO)), "Source occurrence coverage differs")
    for d, r in zip(nodes, source_nodes, strict=True):
        wanted = {"rank": V, "low": 0, "high": 0, "value": r["value"]} if r["kind"] == "constant" else {
                  "rank": r["variable"], "low": r["low"], "high": r["high"], "value": 0}
        must(d == wanted, "Node descriptor does not encode the frozen trace")
    ws = data["witnesses"]
    must(len(ws) == NO, "Witness coverage differs")
    code = {"add": {"zero": 0, "split": 3, "constant": 7}, "mul": {"zero": 1, "one": 2, "split": 4, "constant": 8},
            "project": {"head": 5, "absent": 6}}
    must(data["rule_codes"] == {f"{kind}/{rule}": value for kind, rules in code.items() for rule, value in rules.items()},
         "Rule-code layout differs")
    for c, w, r in zip(claims, ws, source_claims, strict=True):
        kind = ["add", "mul", "project"].index(r["kind"])
        wanted = {"kind": kind, "left": r["input"] if kind == 2 else r["left"],
                  "right": 0 if kind == 2 else r["right"], "result": r["result"],
                  "variable": r["variable"] if kind == 2 else 0}
        must(c == wanted, "Claim descriptor differs from frozen trace")
        rule = code[r["kind"]][r["rule"]]
        expected = {"rule": rule, "splitRank": r["variable"] if r["rule"] == "split" else 0,
                    "lowOp": r["low_operation"] if r["rule"] == "split" else r["arithmetic_operation"] if kind == 2 else 0,
                    "highOp": r["high_operation"] if r["rule"] == "split" else 0}
        must(w == expected, "Local witness differs from frozen trace")
    must(data["packet_fields"] == [{"name": name, "bits": width} for name, width in FIELD_WIDTHS.items()],
         "Packet field declaration differs")
    must(data["descriptor_fields"] == DESCRIPTOR_FIELDS, "Descriptor layout differs")
    for name, width in DESCRIPTOR_FIELDS["witness"]:
        must(word_list(data["witness_bitplanes"][name], width, NO) == scalar_planes([w[name] for w in ws], width),
             "Witness planes do not encode the witness rows")
    check_local(nodes, claims, ws)
    print(json.dumps({"phase": "local-rules-complete"}), flush=True)
    blocks = check_blocks(data, nodes, claims, ws, table)
    arithmetic = check_arithmetic(data, nodes, claims, ws)
    print(json.dumps({"phase": "packed-arithmetic-complete"}), flush=True)
    symbolic = independent_semantics(nodes, claims)
    print(json.dumps({"phase": "independent-semantics-complete"}), flush=True)
    routing = check_route(data)
    absent_ids = [i for i, w in enumerate(ws) if w["rule"] == 6]
    must(data["coefficient_two"] == {"node_id": 2, "descriptor": nodes[2], "payload": table[2],
                                    "projection_claim_ids": absent_ids}, "Coefficient-two evidence differs")
    neg = data["negative_self_reference"]
    i = natural(neg["claim_id"], NO)
    must(ws[i]["rule"] in (3, 4) and neg["field"] == "lowOp" and neg["before"] == ws[i]["lowOp"] and neg["after"] == i,
         "Wrong negative proof-edge mutation")
    changed = dict(ws[i])
    changed["lowOp"] = i
    must(neg["witness"] == changed, "Negative witness changes extra fields")
    must(neg["request_row"] == ROLE_LAYOUT["child_low"][0] + i and neg["request_key"] == NN + i and
         neg["request_payload"] == table[NN + i], "Negative reference is not a genuine table lookup")
    modified = list(ws)
    modified[i] = changed
    error = None
    try:
        check_local(nodes, claims, modified)
    except Rejected as rejected:
        error = str(rejected)
    must(error == "child_low_before", "Self-reference was not rejected at strict operation order")
    statistics = data["statistics"]
    observed_rules = dict(sorted(Counter(f"{r['kind']}/{r['rule']}" for r in source_claims).items()))
    must(statistics == {"rule_counts": observed_rules, "node_branches": sum(n["rank"] < V for n in nodes), "occupied_rows": OCCUPIED,
         "padding_requests": N - OCCUPIED, "reference_slots": OCCUPIED - M, "active_references": blocks["active_reference_occurrences"],
         "request_occurrences": N - M, "semantic_planes": SEMANTIC_WIDTH, "routing_stages": 2 * KEY_WIDTH - 1,
         "stage_plane_transitions": SEMANTIC_WIDTH * (2 * KEY_WIDTH - 1), "strict_order_selected_rows": arithmetic["strict_order_lane_checks"],
         "known_expected_counts_used_as_premises": False}, "Reported statistics differ from replay")
    report = {"status": "accepted", "formal_evidence": False,
              "scope": "Exact fixed-n6 diagnostic replay; no Lean batch theorem, factor accounting, or queens source bridge",
              "input_trace_sha256": trace_hash, "certificate_sha256": certificate_hash,
              "replay_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "nodes": NN, "claims": NO, "variable_limit": V, "rules": observed_rules,
              "parameters": PARAMETERS, "descriptor_fields": DESCRIPTOR_FIELDS,
              "fixed_blocks": blocks, "packed_arithmetic": arithmetic, "independent_ADD_semantics": symbolic,
              "routing": routing, "absent_projection_claim_ids": absent_ids,
              "constant_two_descriptor_checked": True,
              "negative_self_reference": {"claim_id": i, "referenced_table_payload_is_genuine": True,
                                          "rejected_by": error, "second_route_claimed": False},
              "known_expected_counts_used_as_premises": False}
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": "accepted", "formal_evidence": False, "nodes": NN, "claims": NO,
                      "strict_order_lane_checks": arithmetic["strict_order_lane_checks"],
                      "stage_plane_transitions": SEMANTIC_WIDTH * (2 * KEY_WIDTH - 1), "all_claim_functions_match": True,
                      "negative_reference_rejected": True, "negative_self_reference_rejected": True}))


if __name__ == "__main__":
    main()
