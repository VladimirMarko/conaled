#!/usr/bin/env python3
"""Untrusted exact Beneš router and deterministic synthetic input producer.

This program supplies data.  It does not supply a Lean theorem, and its output
must be checked independently before it is used as evidence of anything.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


INPUT_FORMAT = "benes-routing-input-v1"
TRACE_FORMAT = "benes-routing-trace-v1"
SEED = 0x6B18D2E4795A30CF
FIELDS = [
    {"name": "id", "bits": 10},
    {"name": "isDefinition", "bits": 1},
    {"name": "key", "bits": 8},
    {"name": "payload", "bits": 24},
]


class Random64:
    """Specified reproducible generator; this is not a security primitive."""

    def __init__(self, seed: int):
        self.state = seed & ((1 << 64) - 1)

    def next(self) -> int:
        self.state = (6364136223846793005 * self.state + 1442695040888963407) & ((1 << 64) - 1)
        return self.state

    def shuffle(self, values: list) -> None:
        for i in range(len(values) - 1, 0, -1):
            j = self.next() % (i + 1)
            values[i], values[j] = values[j], values[i]


def mix32(x: int) -> int:
    x = (x ^ (x >> 16)) & 0xFFFFFFFF
    x = (x * 0x7FEB352D) & 0xFFFFFFFF
    x = (x ^ (x >> 15)) & 0xFFFFFFFF
    x = (x * 0x846CA68B) & 0xFFFFFFFF
    return x ^ (x >> 16)


def validate_permutation(permutation: list[int]) -> None:
    n = len(permutation)
    if n == 0 or n & (n - 1):
        raise ValueError("The packet count must be a nonzero power of two")
    if any(type(i) is not int for i in permutation) or sorted(permutation) != list(range(n)):
        raise ValueError("destination_of_input must be a permutation of range(N)")


SPREAD_BYTE = [sum(((value >> bit) & 1) << (2 * bit) for bit in range(8)) for value in range(256)]

def benes(permutation: list[int]) -> list[tuple[int, int]]:
    """Return (distance, lower-wire switch mask), with pi[input] = output.

    Each edge is an input occurrence.  Its two neighboring edges share its
    input pair or its requested output pair.  Alternating edge colors selects
    the even/odd subnetworks, including parallel-edge two-cycles.
    """
    validate_permutation(permutation)
    n = len(permutation)
    if n == 1:
        return []
    if n == 2:
        return [(1, permutation[0])]

    inverse = [0] * n
    for source, destination in enumerate(permutation):
        inverse[destination] = source
    color = [-1] * n
    for first in range(n):
        if color[first] != -1:
            continue
        color[first] = 0
        pending = [first]
        while pending:
            edge = pending.pop()
            for neighbor in (edge ^ 1, inverse[permutation[edge] ^ 1]):
                needed = 1 - color[edge]
                if color[neighbor] == -1:
                    color[neighbor] = needed
                    pending.append(neighbor)
                elif color[neighbor] != needed:
                    raise ValueError("Cycle coloring conflict")

    first_bytes, last_bytes = bytearray((n + 7) // 8), bytearray((n + 7) // 8)
    for i in range(0, n, 2):
        if color[i] == 1:
            first_bytes[i >> 3] |= 1 << (i & 7)
        if color[inverse[i]] == 1:
            last_bytes[i >> 3] |= 1 << (i & 7)
    first_mask, last_mask = int.from_bytes(first_bytes, "little"), int.from_bytes(last_bytes, "little")
    subpermutations = [[0] * (n // 2), [0] * (n // 2)]
    for edge, destination in enumerate(permutation):
        subpermutations[color[edge]][edge // 2] = destination // 2
    left, right = (benes(p) for p in subpermutations)
    if [d for d, _ in left] != [d for d, _ in right]:
        raise ValueError("Subnetwork stage layout mismatch")
    middle = []
    for (distance, even_mask), (_, odd_mask) in zip(left, right, strict=True):
        width = (n // 2 + 7) // 8
        even_bytes, odd_bytes = even_mask.to_bytes(width, "little"), odd_mask.to_bytes(width, "little")
        merged = bytearray(2 * width)
        for j, (even_byte, odd_byte) in enumerate(zip(even_bytes, odd_bytes, strict=True)):
            value = SPREAD_BYTE[even_byte] | (SPREAD_BYTE[odd_byte] << 1)
            merged[2 * j], merged[2 * j + 1] = value & 255, value >> 8
        middle.append((2 * distance, int.from_bytes(merged, "little")))
    return [(1, first_mask), *middle, (1, last_mask)]


def bitplanes(packets: list[dict], fields: list[dict]) -> dict[str, list[int]]:
    result = {}
    for field in fields:
        buffers = [bytearray((len(packets) + 7) // 8) for _ in range(field["bits"])]
        for row, packet in enumerate(packets):
            value, byte, flag = int(packet[field["name"]]), row >> 3, 1 << (row & 7)
            while value:
                bit = value & -value
                buffers[bit.bit_length() - 1][byte] |= flag
                value -= bit
        result[field["name"]] = [int.from_bytes(buffer, "little") for buffer in buffers]
    return result


def decode(planes: dict[str, list[int]], n: int) -> list[dict]:
    packets = [{} for _ in range(n)]
    for name, values in planes.items():
        encoded = [value.to_bytes((n + 7) // 8, "little") for value in values]
        for row, packet in enumerate(packets):
            byte, offset = row >> 3, row & 7
            value = sum(((plane[byte] >> offset) & 1) << bit for bit, plane in enumerate(encoded))
            packet[name] = bool(value) if name == "isDefinition" else value
    return packets


def hexplanes(planes: dict[str, list[int]], n: int) -> dict[str, list[str]]:
    digits = (n + 3) // 4
    return {name: [f"0x{value:0{digits}x}" for value in values] for name, values in planes.items()}


def route_case(name: str, packets: list[dict], permutation: list[int], fields: list[dict]) -> dict:
    validate_permutation(permutation)
    n = len(permutation)
    if len(packets) != n:
        raise ValueError("Packet/permutation length mismatch")
    field_names = {field["name"] for field in fields}
    if len(field_names) != len(fields):
        raise ValueError("Duplicate packet field name")
    for packet in packets:
        if set(packet) != field_names:
            raise ValueError("Every packet field must be represented by bitplanes")
        for field in fields:
            value = packet[field["name"]]
            if type(value) not in (int, bool) or not 0 <= value < 1 << field["bits"]:
                raise ValueError("Packet field does not fit declared width")
    planes = bitplanes(packets, fields)
    initial = hexplanes(planes, n)
    stages = []
    for number, (distance, mask) in enumerate(benes(permutation)):
        before = hexplanes(planes, n)
        after = {}
        for name_, values in planes.items():
            outputs = []
            for value in values:
                delta = ((value >> distance) ^ value) & mask
                outputs.append(value ^ delta ^ (delta << distance))
            after[name_] = outputs
        planes = after
        stages.append({
            "number": number,
            "distance": distance,
            "mask": f"0x{mask:0{(n + 3) // 4}x}",
            "input_bitplanes": before,
            "output_bitplanes": hexplanes(planes, n),
        })
    output = decode(planes, n)
    expected = [None] * n
    for i, destination in enumerate(permutation):
        expected[destination] = packets[i]
    if output != expected:
        raise ValueError("Producer self-check: routed packets do not match requested permutation")
    return {
        "name": name,
        "n": n,
        "k": n.bit_length() - 1,
        "initial_bitplanes": initial,
        "stages": stages,
        "output_packets": output,
    }


def fixture() -> dict:
    rng = Random64(SEED)
    values = {key: mix32(key + 0x31415927) & ((1 << 24) - 1) for key in range(128)}
    values[128] = 0
    packets = [{"id": key, "isDefinition": True, "key": key, "payload": values[key]}
               for key in range(128)]
    heavy = [3, 7, 11, 23, 47, 63, 97]
    for index in range(768):
        if index < 128:
            key = index
        elif index % 11 < 5:
            key = heavy[(rng.next() >> 32) % len(heavy)]
        else:
            key = (rng.next() >> 32) % 128
        packets.append({"id": 128 + index, "isDefinition": False, "key": key, "payload": values[key]})
    packets.extend({"id": 896 + index, "isDefinition": True, "key": 128, "payload": 0}
                   for index in range(128))
    rng.shuffle(packets)
    ordered = sorted(packets, key=lambda p: (p["key"], not p["isDefinition"], p["id"]))
    destinations = {packet["id"]: i for i, packet in enumerate(ordered)}
    permutation = [destinations[packet["id"]] for packet in packets]
    negative = [dict(packet) for packet in packets]
    changed_id = 128 + 7
    changed = next(packet for packet in negative if packet["id"] == changed_id)
    before = changed["payload"]
    changed["payload"] ^= 1

    campaign = []
    for n in (1, 2, 4):
        for number, p in enumerate(itertools.permutations(range(n))):
            campaign.append({"name": f"exhaustive-n{n}-{number:02d}", "n": n, "destination_of_input": list(p)})
    campaign_rng = Random64(SEED ^ 0xFEDA5819370246CB)
    for k in range(3, 11):
        n = 1 << k
        permutations = [
            list(range(n)),
            list(reversed(range(n))),
            [int(f"{i:0{k}b}"[::-1], 2) for i in range(n)],
            [(i + (n // 2 + 1)) % n for i in range(n)],
        ]
        for _ in range(4):
            shuffled = list(range(n))
            campaign_rng.shuffle(shuffled)
            permutations.append(shuffled)
        for number, p in enumerate(permutations):
            campaign.append({"name": f"structured-n{n}-{number:02d}", "n": n, "destination_of_input": p})

    return {
        "format": INPUT_FORMAT,
        "formal_evidence": False,
        "scope": "Synthetic routing and lookup diagnostic only; no queens input or Lean theorem",
        "seed": f"0x{SEED:016x}",
        "packet_fields": FIELDS,
        "definition_table": [{"key": key, "payload": value} for key, value in values.items()],
        "fixture_counts": {"real_definitions": 128, "requests": 768, "padding_definitions": 128,
                           "packets": 1024, "reserved_padding_key": 128},
        "lookup_cases": [
            {"name": "valid", "expected_lookup": True, "packets": packets,
             "destination_of_input": permutation},
            {"name": "mutated-query", "expected_lookup": False, "packets": negative,
             "destination_of_input": permutation},
        ],
        "negative_mutation": {"positive_case": "valid", "negative_case": "mutated-query",
                              "packet_id": changed_id, "field": "payload", "bit": 0,
                              "before": before, "after": changed["payload"]},
        "permutation_cases": campaign,
    }


def write_json(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subcommands = parser.add_subparsers(dest="mode", required=True)
    create = subcommands.add_parser("fixture")
    create.add_argument("--output", type=Path, required=True)
    route = subcommands.add_parser("route")
    route.add_argument("--input", type=Path, required=True)
    route.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "fixture":
        data = fixture()
        write_json(args.output, data)
        print(json.dumps({"status": "created", "packets_per_lookup_case": 1024,
                          "lookup_cases": len(data["lookup_cases"]),
                          "permutation_cases": len(data["permutation_cases"]),
                          "formal_evidence": False}))
        return

    raw = args.input.read_bytes()
    supplied = json.loads(raw)
    if supplied["format"] != INPUT_FORMAT:
        raise ValueError("Unknown input format")
    lookups = [route_case(case["name"], case["packets"], case["destination_of_input"], supplied["packet_fields"])
               for case in supplied["lookup_cases"]]
    permutations = []
    for case in supplied["permutation_cases"]:
        n = case["n"]
        if n != len(case["destination_of_input"]):
            raise ValueError("Permutation case length mismatch")
        fields = [{"name": "id", "bits": max(1, (n - 1).bit_length())}]
        permutations.append(route_case(case["name"], [{"id": i} for i in range(n)],
                                       case["destination_of_input"], fields))
    result = {
        "format": TRACE_FORMAT,
        "formal_evidence": False,
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "packet_fields": supplied["packet_fields"],
        "lookup_cases": lookups,
        "permutation_cases": permutations,
    }
    write_json(args.output, result)
    print(json.dumps({"status": "produced", "lookup_cases": len(lookups),
                      "permutation_cases": len(permutations), "formal_evidence": False,
                      "stages": sum(len(case["stages"]) for case in lookups + permutations)}))


if __name__ == "__main__":
    main()
