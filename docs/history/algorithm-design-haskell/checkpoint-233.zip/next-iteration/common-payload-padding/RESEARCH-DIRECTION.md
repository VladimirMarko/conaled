# Transferable computation after the user's 25 October clarification

## Goal and scope

The user asked why checkpoints 195 and 196 were described differently, whether
they survive a workspace wipe or new-chat handoff, what happened to a custom
optimized kernel, and whether the current certificate approach is too dependent
on hand-built instances and already suspected answers. The user explicitly
authorized fixing the padding defects. The n16 numeral remains a goal, but a
reusable computational-proof method is now an explicit criterion for useful
progress. This note records that direction; it is not a new kernel implementation
or numerical result.

Every checkpoint uses the same standalone source/evidence format. The exact
comparison and external-environment limits are in [DURABILITY-REVIEW.md](DURABILITY-REVIEW.md).
Checkpoint 196 retains all 195 mathematical sources/results and adds a review.
Future labels should describe changes without suggesting different backup types.

## Answer generation and certificate generation

The retained `add_line_counter.py` computes geometry, chooses an elimination
order from scopes, constructs local factors, and applies exact multiplication
and projection operations. Its final `count` is read from the resulting constant
node. The expected small counts appear in the diagnostic header and final
comparison; they do not feed those arithmetic operations. The producer and
independent replay derive widths from actual nodes and ignore answer metadata.

Relevant source anchors are `choose_order`, `run`, `configure`, `infer_shape`,
and the final `finish` emission in these retained files:

- `project/experiments/chapter15-queens-model-counting/arithmetic-counting/diagnostics/add_line_counter.py`
- `project/experiments/chapter15-queens-model-counting/packed-add-size-six/six-diagnostic/diagnostics/produce_packed_add.py`
- `project/experiments/chapter15-queens-model-counting/packed-add-size-six/six-diagnostic/diagnostics/replay_packed_add.py`

Thus an expected numerical answer is not a logical prerequisite. The natural
reusable interface would have a producer return both a proposed count and its
certificate, with a theorem that successful checking implies the specified
count. That is a target interface, not a claim that the current small-board CLI
already provides a polished arbitrary-instance tool.

The current limitations are real: the CLI allows only selected small boards,
source emitters contain n6 constants, and capped n8 traces remain incomplete.
Finding a representation that compresses the required work is research; it is
not a requirement to hand-select a magical certificate for every n. Once a
successful representation is implemented, its producer should generate the
count and certificate algorithmically. Soundness for all accepted inputs alone
does not demonstrate producer coverage, automation, or acceptable scaling.

## Reusable layers and the current Word16 boundary

The existing arithmetic semantics, node/claim induction, exact routed lookup,
range composition, factor accounting, and board/model correspondence are
generic. Concrete literals, request inventories, site scopes, selected exceptions
and source-code permutations are instance data. They belong behind a systematic
generator and checked interface rather than accumulating handwritten adaptations.

The existing source counter deliberately has `Word := BitVec 16` and
`stateCount n s := literalCountRows n 16 s`. Its source correspondence assumes
`n <= 16`; the generic queens specification is not restricted that way. A larger-n
API therefore needs a width/depth-parametric counter and its proved bridge to
the specification, plus agreement with the current source counter at width16.
Do not silently redefine the original textbook-facing implementation.

The completed padding repair is useful at this reusable layer. Its nine accepted
mathematical contracts quantify over layouts, payload lists and rows, preserve
semantic fields under zero-extension, and prove the new unused high field is
zero. They mention no board size or expected count. All twelve finite Python
boundary tests and the exact source-preservation checks also passed. Those
tests do not make Python code a proved Lean implementation. The full three-module
mathematical closure accepted 239 roots in 7.89377424599661 seconds, peak
700,396 KiB; see the separate MATH-RESULTS and PYTHON-RESULTS for evidence.

## The optimized-kernel direction remains open

No custom kernel has been built. The completed work consists of exact-source
contract research, two fixed external-kernel comparisons and the invalid-export
negative control. The comparisons did not establish a twofold improvement on
their chosen inputs; they do not establish that a custom optimization is futile.
The current reviews also found that bounded instantiation-cache clearing is
already implemented and proved in con-leche. Reimplementing that existing idea
without evidence would not constitute progress.

There are two transferable routes worth keeping distinct:

1. A reusable certified evaluator or certificate checker for an explicit finite
   arithmetic/bitwise computation language, with a proved source translation.
   This keeps the trusted boundary small and can serve problems beyond queens.
2. A general kernel reduction/representation optimization for a measured costly
   operation, with a refinement proof to a pinned reference checker. This can
   benefit ordinary Lean terms beyond a particular certificate language.

For the second route, successful optimized checking must imply the appropriate
reference checking/typing judgment. Caches, term representations or reduction
order may differ; matching every rejection or resource failure is unnecessary.
The actual parser/input, source identity, compiled execution and integration
still need an explicit account. A proof of checker soundness plus an externally
observed exit status does not automatically supply an ordinary proof term for
the arithmetic acceptance premise.

Current primary sources confirm that such representation-changing infrastructure
exists: con-ron changes term representation and caching while refining con-leche;
con-leche's public theorem assumes mathematical acceptance and a set-theory model.
The official proof-irrelevance ordering change PR15103 is an example of active
kernel work, not evidence of an ADWH speedup. These sources were consulted on
25 October 2026:

- https://github.com/leanprover/con-ron
- https://leanprover.github.io/con-leche/con-leche-proof-idea.html
- https://github.com/leanprover/lean4/pull/15103

The retained release-pinned evidence and measured results remain authoritative
for what this project actually ran:
`next-iteration/lean435-kernel-research/`, `lean435-kernel-comparison/`,
`lean435-primitive-kernel-comparison/`, and `kernel-validity-reconciliation/`.
No later upstream result is silently substituted for those pins.

## Next-work criterion

The universal padding repair is checked as its own mathematical closure,
without another unchanged n6 count gate. Next choose a reusable operation or
pipeline milestone with a concrete success criterion and evidence that it
addresses the actual cost. Prefer systematic input support and tests of distinct
input shapes over further tuning of one frozen fixture. The existing fixed
resource and allowed-axiom policy remains unchanged.

The earlier requirement for a new compression witness concerned another nearby
variation of the capped ADD producer. It is not a universal prerequisite for
kernel/evaluator research: faster direct evaluation is a different route. A
kernel-side proposal instead needs an operation-level measurement, a precise
refinement relation, and a feasible fresh proof/integration boundary. No
particular cache cap, patch or performance claim is selected by this note.
