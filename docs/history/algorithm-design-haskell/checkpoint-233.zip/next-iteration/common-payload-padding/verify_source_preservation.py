#!/usr/bin/env python3
"""Read-only source/inverse checks; imports or executes no source variant."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def checked_file(relative: str, expected_sha: str, expected_size: int) -> bytes:
    path = WORK / relative
    raw = path.read_bytes()
    if digest(raw) != expected_sha or len(raw) != expected_size:
        raise ValueError(f"Changed source binding: {relative}")
    return raw


def main() -> None:
    manifest_raw = (HERE / "SOURCE-EDITS.json").read_bytes()
    manifest = json.loads(manifest_raw)
    results = []
    for item in manifest["variants"]:
        original = checked_file(item["original_path"], item["original_sha256"],
                                item["original_bytes"]).decode()
        variant = checked_file(item["variant_path"], item["variant_sha256"],
                               item["variant_bytes"]).decode()
        recovered = variant
        for edit in reversed(item["edits"]):
            start = edit["offset_at_application"]
            new = edit["new_text"]
            if recovered[start:start + len(new)] != new:
                raise ValueError("Edit inverse anchor mismatch")
            recovered = recovered[:start] + edit["old_text"] + recovered[start + len(new):]
        if recovered != original:
            raise ValueError("Inverse does not recover exact original bytes")
        bodies = []
        for text in [original, variant]:
            tree = ast.parse(text)
            functions = [node for node in tree.body
                         if isinstance(node, ast.FunctionDef) and node.name == "main"]
            if len(functions) != 1:
                raise ValueError("Missing unique main entry point")
            bodies.append(ast.get_source_segment(text, functions[0]))
        if bodies[0] != bodies[1] or digest(bodies[0].encode()) != item["main_body_sha256"]:
            raise ValueError("Pinned CLI main body changed")
        results.append({"variant": item["variant_path"], "exact_inverse": True,
                        "unchanged_main": True, "source_sha256": item["variant_sha256"]})
    for item in manifest["unchanged_support"]:
        original = checked_file(item["original_path"], item["sha256"], item["bytes"])
        copied = checked_file(item["variant_path"], item["sha256"], item["bytes"])
        if original != copied:
            raise ValueError("Support source changed")
    print(json.dumps({"status": "passed_source_preservation", "variant_results": results,
                      "manifest_sha256": digest(manifest_raw),
                      "variants_imported_or_executed": False,
                      "support_sources_unchanged": True}, sort_keys=True))


if __name__ == "__main__":
    main()
