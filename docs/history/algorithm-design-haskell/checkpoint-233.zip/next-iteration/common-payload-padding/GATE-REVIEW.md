# Independent review of the common-payload mathematical gate

## Finding and independence

No source/protocol blocker was found for the proposed first execution. The
gate checks the complete selected reusable-helper closure under the existing
limits. It does not run a queens instance or the Python producer/replayer.

This reviewer authored `CommonPayloadPadding.lean` and its mathematical design
and inventory, but did not author or modify this runner, manifest preparer or
protocol. This is an independent **gate** review, not an independent review of
the reviewer's own mathematical source. The separate counting-route reviewer
read the mathematical source; its frozen `INDEPENDENT-MATH-REVIEW.md` has
SHA-256 `364c89b41a047f3d7dbce40ff6e86bd2e9475944334cb99fb80b7cc0f28f54eb`.

No runner, manifest preparer, Lean process, producer/replayer, counter or test
suite was executed by this reviewer. The source-only preflight recorded by
the runner author is evidence of preparation, not mathematical acceptance.

## Exact reviewed identities

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `gate/run_gate.py` | 25,566 | `daf6cf968af8e1f9d2149b8994335bd5511353c3e7f933f3ad7fa3b08b9f12a8` |
| `gate/PROTOCOL.md` | 11,412 | `917b05fbfaa16cbb4d2e9163d8a8cc3b6e4ca403de24a9f18fbb6dcefb2cc4bf` |
| `gate/prepare_manifest.py` | 5,517 | `c9a8b08388a469109340548ee43b1e1d4c7215626178368d151c641b354260e3` |
| `gate/source-manifest.json` | 37,883 | `6ffe50b3a8883176c501b92fa44d33443a81ff7e3ced5aab01d820106f3241a2` |
| `gate/SOURCE-ONLY-REVIEW.json` | 4,921 | `9476c4e9aa42cb7b6218fbbdd125b3e0815614704b5673fe35c0dfa22260608f` |
| `source/CommonPayloadPadding.lean` | 8,782 | `c809c9e1514615787b3eb3b335fd7cd4842e8db1f6d0884db05a23ece0a2cf08` |
| `MATHEMATICAL-DESIGN.md` | 8,059 | `6ec7948160bcb1fa5adaf13eefcc377ea9341c5455963e16181cd6a12017c22d` |
| `MATHEMATICAL-INVENTORY.json` | 10,895 | `a3167887108d76bbc6dc754a576daf92147462035b09a999a6829e9f87462baf` |

The prepared source fingerprint is
`25fff9bbae333af326b14cfbd566ba6bf450dde5baa41ab80387a7574fe69b76`.
This review is separate from the six bound current controls, avoiding a
self-referential snapshot or review-hash cycle.

## Source closure and actual acceptance

The only selected mathematical modules are fresh `LegacyListClause` (six
roots), `ConsolidatedGeneric` (224) and `CommonPayloadPadding` (nine), in that
order. The preparer pins the first two source identities and complete ordered
root lists against the retained accepted baseline. The runner checks exact
source paths, byte counts, hashes, imports, strict options and raw/full print
name mappings, and computes the dependency closure from the helper. Only
selected earlier modules and the pinned distribution's Init/Std imports are
admitted. [Preparer: `prepare`; runner: `preflight`]

All three source files are copied into a new read-only directory. The selected
object search path starts empty. No original ADWH preparation pool or prior
experimental object is used. Successful acceptance requires exactly the six
expected `.olean`/`.ilean` outputs. The source guard and default resource-option
restrictions are unchanged. [Runner: source guard/import checks and `main`]

For each module, a zero exit, intact resource allowance, successful actual
axiom audit and both object files are necessary. The 239 expected roots are
distinct and fully identified; matching only the count is insufficient.
The runner retains observed reports separately from accepted reports and
accepts reports only from passing modules. It stops at the first rejected
module and requires all three modules and all 239 roots for final success.
Recovery reports from a failed module cannot establish the new theorem flag.
[Runner: `counts`, compilation loop and final acceptance predicate]

## Resources and preserved provenance

One cumulative deadline surrounds the full three-module compiler sequence.
Each command uses `-j1 -M1024`, explicit strict source options and one selected
CPU. The unchanged pinned process-tree helper enforces the deadline and the
1,048,576-KiB RSS condition; the final predicate also checks the cumulative
seconds and peak RSS. Static preparation and post-run evidence audits do not
invoke hidden mathematical compilation. The protocol accurately distinguishes
sampled RSS enforcement from an address-space cap. [Runner: fixed helper pins,
`main`; protocol: resource section]

The compiler and five shared libraries must match their pinned identities.
The environment uses the new object directory, clears inherited Lean/Lake
configuration through the retained helper and removes loader injection
variables. The nonblocking compiler lock serializes Lean work. No configurable
budget or alternate compiler branch is exposed. [Runner: runtime preflight and
environment/command construction]

The old baseline's generic-pointer recording defect is disclosed. Here the
actual baseline report and the runtime reference report have separate roles
and exact path/hash/size assertions; neither supplies proof acceptance.
`control_role` checks these identities at preflight, before the permanent
marker and after execution. There is no generic/full stage transition or
generic-result pointer to substitute. [Runner: `control_role`; preparer and
protocol: baseline provenance sections]

The three source snapshots and six current-control snapshots precede Lean
execution and are checked for exact bytes and read-only permissions. Eight
historical controls are bound in place. A source-fingerprint marker is created
exclusively and retained permanently; changing only the attempt name or
metadata cannot repeat the same mathematical sources. A diagnosed source
correction requires changed bytes, a new manifest and a new reviewed attempt,
while preserving the earlier evidence. The post-run checks include source,
control, snapshot, runtime, compiler and marker identities. [Runner: `main`]

## Scope of a later passing result

A passing report would establish the selected nine universal padding/codec
theorems with actual allowed-axiom reports under this fresh closure. It would
not establish Python execution correspondence, larger-producer termination,
a complete source-count certificate, a new queens numeral or an optimized
kernel. The report's flags and the protocol retain these distinctions. The
existing three-axiom allowance and ordinary-kernel trust assumptions remain
unchanged. No such passing result is asserted by this pre-execution review.
