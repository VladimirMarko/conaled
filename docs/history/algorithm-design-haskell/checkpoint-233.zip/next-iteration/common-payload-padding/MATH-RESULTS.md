# Common-payload padding: complete mathematical gate passed

The single `complete-01` gate freshly compiled all three selected mathematical
modules and accepted **239 of 239 required axiom reports** in
**7.89377424599661 seconds**, with **700,396 KiB** peak child RSS. All three
processes exited zero, without a limit event, warning/error diagnostic, or stderr
output. This accepts the reusable nine-theorem padding and codec helper.

This report covers the mathematical gate only. The Python producer/replayer
repair and its unit checks have separate evidence. No board count, complete
larger-instance trace, or Python-execution correspondence was proved here.

## Exact accepted run

| Module | Required / observed / accepted | Wall seconds | Peak RSS KiB |
| --- | ---: | ---: | ---: |
| `LegacyListClause` | 6 / 6 / 6 | 0.329452383 | 493,312 |
| `ConsolidatedGeneric` | 224 / 224 / 224 | 7.099344482 | 700,396 |
| `CommonPayloadPadding` | 9 / 9 / 9 | 0.455821713 | 505,468 |
| **Complete sequence** | **239 / 239 / 239** | **7.893774246** | **700,396** |

The cumulative measurement includes the compilation sequence and its intervening
report/audit work, so it is slightly larger than the sum of process times.
These are the recorded measurements of this one proof gate, not a performance
comparison or a forecast for a larger counting certificate.

The [raw report](gate/attempts/complete-01/report.json) is 89,999 bytes, SHA-256:

```text
292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8
```

Its source fingerprint is
`25fff9bbae333af326b14cfbd566ba6bf450dde5baa41ab80387a7574fe69b76`.
The [permanent start marker](gate/execution-markers/complete-25fff9bbae333af326b14cfbd566ba6bf450dde5baa41ab80387a7574fe69b76.json)
is 10,379 bytes, SHA-256
`0b0734cf1a430c9baddff3c390b2d9958a2a892d11dea971ad9ad0b299107016`.
There was no failed mathematical development attempt and no unchanged rerun.

## What the new helper establishes

The accepted source is
[CommonPayloadPadding.lean](source/CommonPayloadPadding.lean), 8,782 bytes,
SHA-256 `c809c9e1514615787b3eb3b335fd7cd4842e8db1f6d0884db05a23ece0a2cf08`.
Its layout has arbitrary natural rank, node-ID and value widths. It uses the
existing two-bit claim-kind language and chooses the maximum of the node and
claim widths as the common payload width.

| New theorem roots | Accepted meaning |
| --- | --- |
| `wordAt_pad`, `length_pad` | Appending the necessary zero planes preserves every row word. The resulting length is the maximum of the common width and the original length. |
| `added_field_zero` | The newly added high field decodes to zero for every row, including zero-width cases. |
| `nodePlanes_at`, `claimPlanes_at` | The plane representation decodes to the existing node/claim descriptor fields when the explicit width bound holds. |
| `nodePlanes_pad_at`, `claimPlanes_pad_at` | Common zero extension supplies either descriptor's width bound, even when the original list is short or the node record is wider than the claim record. |
| `node_reference`, `claim_reference` | Explicit table-lookup equality transports to the decoded descriptors. Claim transport also retains the dense-key equation identifying the particular claim. |

All nine names are fully qualified under
`ADWH.Experiments.Chapter15.CommonPayloadPadding`. Their actual printed axiom
dependencies are exactly **`propext` and `Quot.sound`**. The complete 239-root
closure uses only the permitted set `{propext, Quot.sound, Classical.choice}`.
The [helper's raw output](gate/attempts/complete-01/CommonPayloadPadding.stdout.log)
and [source inventory](MATHEMATICAL-INVENTORY.json) preserve the exact names and
statement headers.

The qualifications matter: padding does not truncate an overlong input, so
exact equality to the common length additionally needs the original length to
fit. The zero-field theorem concerns the field appended by this construction;
it does not accept arbitrary nonzero padding in external input. Lookup and claim
key premises remain explicit. The helper has no board size or expected-answer
premise. See the [mathematical design](MATHEMATICAL-DESIGN.md) and
[independent mathematical review](INDEPENDENT-MATH-REVIEW.md).

## Fresh compilation and evidence audit

The two imported mathematical modules are the unchanged accepted baseline191
sources. **Both were compiled freshly in this attempt along with the helper.**
The object search directory started empty, contained no original ADWH object
pool, and finished with exactly six new `.olean`/`.ilean` outputs. Every recorded
object byte count and hash matched the live file during this saved-result audit.
The pinned Lean distribution's Init/Std remains the standard-library boundary.

The run used Lean **4.35.0**, commit
`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`, its exact executable and five shared
runtime libraries, one CPU/thread, `-j1 -M1024`, default recursion/heartbeats,
strict warnings and disabled auto-implicit arguments/async elaboration. All three
modules shared one 30-second deadline and the 1,048,576 KiB RSS allowance. The
unchanged process-tree watchdog and source guard remain bound by hash. The
watchdog's finite sampling interval is not a hard prevention of all transient
RSS overshoot; no violation was recorded in this run.

The separate saved-result audit:

- Verified **47 direct report-binding occurrences covering 45 distinct files**,
  plus **30 marker-binding occurrences covering 26 identities**. These censuses
  overlap; they are not additive counts of unique evidence.
- Independently parsed all 239 raw axiom reports, checked exact required names
  and multiplicities, and compared the results with the saved gate census.
- Checked all three source snapshots, six current-control snapshots, six raw
  stdout/stderr logs, six compiled objects, compiler/runtime bytes, and the
  permanent marker. All source/control snapshots and the marker remain read-only.
- Confirmed exact commands, source order, strict source options, root inventory,
  resource outcomes, object inventory and source fingerprint.
- Confirmed that the actual baseline full report occupies its explicit
  `accepted_baseline_source_report` role. The runtime comparison report has a
  different role. The old baseline's generic-pointer defect remains disclosed
  and supplies no acceptance for this fresh proof.

The result documents and auditor are authored by the **gate author**; this is
not presented as an independent review of that author's runner. The separate
[gate review](GATE-REVIEW.md) and independent mathematical review were completed
before root executed the compiler. The source author's design/inventory are
likewise labeled as authored source documentation.

## Exact source-only recovery requirements

The mathematical attempt has **nine source/control snapshots**, totaling
**364,414 bytes**. Each maps directly to an unchanged canonical file; no source
generation, unique superseded input or earlier archive is required:

| Snapshot role | Canonical file to retain |
| --- | --- |
| Source: `LegacyListClause` | Baseline191 `count-migration/source/LegacyListClause.lean` |
| Source: `ConsolidatedGeneric` | Baseline191 `count-migration/source/ConsolidatedGeneric.lean` |
| Source: new helper | `source/CommonPayloadPadding.lean` |
| Current control: runner | `gate/run_gate.py` |
| Current control: protocol | `gate/PROTOCOL.md` |
| Current control: source manifest | `gate/source-manifest.json` |
| Current control: manifest preparer | `gate/prepare_manifest.py` |
| Current control: mathematical design | `MATHEMATICAL-DESIGN.md` |
| Current control: mathematical inventory | `MATHEMATICAL-INVENTORY.json` |

[MATH-RESULTS.json](MATH-RESULTS.json) records all nine exact snapshot paths,
canonical paths, byte counts and hashes, plus the eight historical references.
Also retain the raw report, six raw logs, permanent marker, source/gate reviews
and these derived results. Six compiled outputs and the installed toolchain may
be omitted under the existing source-only checkpoint policy. Their omission
must not be confused with their absence from the completed run.

[audit_math_result.py](audit_math_result.py) reads saved evidence without running
Lean, a gate or a generator. Its default mode requires and rechecks the live
runtime, objects and actual snapshots. Its explicit `--source-only` mode can
relocate retained paths and use the nine exact canonical copies when snapshots
are omitted, while reporting the twelve runtime/object bindings as **not
rechecked**. It does not convert source-only restoration into a new live gate.
It writes nothing unless `--write` is supplied. The saved MATH-RESULTS.json records
the completed full live-byte audit, not a source-only substitute.

The mathematical repair is available for later instance-specific proof work.
A complete larger counting certificate, its concrete checks and its source
bridge remain separate obligations; `cqueens 16 = 14772512` is still open.
