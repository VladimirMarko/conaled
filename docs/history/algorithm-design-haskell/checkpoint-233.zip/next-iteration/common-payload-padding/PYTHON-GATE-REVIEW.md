# Independent source review of the bounded Python checks

## Decision and reviewed identities

**No source-level blocker remains for the one fixed `tests-01` run described in `PYTHON-GATE.md`.** This is a review of the wrapper and acceptance rules, not a report that either command has executed. At this review, the attempt directory and its source-keyed marker are absent. The root agent owns execution.

Reviewed files:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `run_python_checks.py` | 12,828 | `85fd0bb0dd28ddc78d8d2923ccc4953fb32a870fbb86c5d84830874e35c4bebc` |
| `PYTHON-GATE.md` | 4,902 | `0338035f0eb5b3dfef992a8b66dc401f7f1b8cd1817bbee2c2e8aa0d56dd6c63` |
| Existing resource helper `../lean435-kernel-comparison/run_comparison.py` | 23,607 | `2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0` |

`counting_route` authored the Python repair, tests, wrapper, and protocol. This reviewer (`validity_contracts`) independently reviewed their source and did not edit them. I authored the separate Lean padding helper, whose source review and completed mathematical gate are separate evidence. No wrapper mode, test, source-preservation verifier, variant import, producer, replay, router, counter, or Lean compiler was run by this reviewer. The checks here read text, parse Python syntax/JSON, and compare file identities and the declared input set.

## Exact execution scope and input coverage

The only two child commands are the bound Python interpreter with `-I` and, in order, `verify_source_preservation.py` and `tests/test_common_payload.py`. The wrapper has no argument for an alternate command, fixture, count, or test selection. A first-child rejection prevents the second child from starting. The test module's frozen source imports only the two new variants and calls the six shape/scalar-codec entry points covered by [PYTHON-SOURCE-REVIEW.md](PYTHON-SOURCE-REVIEW.md); the retained `main()` entry points remain dormant. The copied routing support is an identity/provenance input and is not imported by this test module.

I independently reconstructed the input inventory from the frozen JSON files and checked each size and SHA256. Its **17 distinct reviewed inputs** exactly equal `PYTHON-SOURCE-AUDIT.json`'s complete binding map. Adding the independent Python review, its audit, the resource helper, wrapper, and protocol gives **22 distinct input files**, matching the runner contract. The wrapper separately records the resolved interpreter's size, hash, and Python version.

All 22 inputs are copied into read-only snapshots with their paths relative to `work/`. Both children run from the snapshot's common-payload directory. Consequently, the inverse verifier's `WORK` calculation points at the snapshot tree and resolves the frozen original producer/replayer/support files there; the tests' `ROOT` calculation resolves the frozen variants there. The source verifier and tests do not need a live trace file or generated count artifact.

The marker identity covers exactly the five Python implementation/support/test/verifier sources. Independently deriving it gives:

`088f559ad0594f24f4c0455ece2f40a2be8b365edd32b76e0332f9cdbb0c6f7e`.

The fixed attempt directory and permanent marker are checked for absence before starting. Marker creation is exclusive and precedes the first child. Neither metadata changes nor a different command-line label can reopen this fixed attempt. The wrapper provides no deletion, overwrite, or retry path. The original source and review files remain unchanged.

## Resource and acceptance rules

The same nonblocking project compile lock serializes this work against other bounded gates. The exact pinned `h.child` helper gives each child one selected CPU, a separate process group, the unchanged CPU/file/core safeguards, aggregate descendant RSS sampling, exit high-water RSS checking, and rejection above **1,048,576 KiB**. One deadline, created before the first child as `began + 30`, is passed unchanged to both calls. Final elapsed checking includes both output audits and final binding checks. Snapshot preparation occurs before this execution interval, as the protocol states. No new per-command 30-second allowance is introduced.

Python uses isolated mode. Python/Lean/Lake/comparator environment overrides and dynamic-loader injection settings are removed, while numerical-library thread counts are set to one. The pinned helper retains its existing sampled-RSS enforcement; this review does not recast that as an address-space cap or an additional formal guarantee.

Success requires both zero exits and the helper's resource-compliance result. The first stdout must parse to the exact expected source-preservation JSON: both exact inverse results, unchanged original `main()` bodies, fixed edit-manifest hash, unchanged support, and no execution of the variants by that verifier. Its stderr must be empty.

The test command must emit no stdout, give exactly the twelve inventory test names once each as `ok`, include exactly one `Ran 12 tests` summary, and finish with `OK`. The parser accepts the two normal unittest method-name formats while retaining exact identity matching. A skipped, missing, duplicated, failed, or errored required test cannot supply the required twelve `ok` entries.

After execution the wrapper rechecks the original inputs, interpreter, every read-only snapshot, both stdout/stderr bindings for each attempted child, and the read-only marker. Incomplete snapshots, changed evidence, or a cumulative deadline breach reject the result. A report is saved before execution and after each child; exceptions retain a failed report rather than accepting partial work. The reviewed final wrapper includes the explicit child-log postcheck.

## What acceptance would establish

A successful run would establish the recorded finite regression outcomes for these exact Python sources and the exact source-preservation checks. The tests cover both payload-width orderings, the tie, wide integer constants, unchanged ordinary words/layout, zero-padding behavior, and malformed input rejection. These are implementation checks on small synthetic records, not a complete queen-count trace or an all-input proof of Python correctness.

The universal Lean theorem gate proves the separate field/padding semantics. This Python gate does not join those two trust boundaries into a proved Python-to-Lean correspondence, prove producer completeness, construct a larger-board certificate, adopt a replacement kernel, or close `cqueens 16`. Those qualifications in the protocol are accurate.
