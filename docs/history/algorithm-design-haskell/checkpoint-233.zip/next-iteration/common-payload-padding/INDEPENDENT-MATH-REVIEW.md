# Independent source review of the Lean padding contract

Reviewer: counting-route agent, author of the separate Python variants and
tests. The mathematical-contract agent authored `CommonPayloadPadding.lean`;
this reviewer did not edit it. This is source inspection only, with no Lean
run and no claim of kernel acceptance.

Reviewed identities:

- `source/CommonPayloadPadding.lean`: SHA256
  `c809c9e1514615787b3eb3b335fd7cd4842e8db1f6d0884db05a23ece0a2cf08`.
- `MATHEMATICAL-DESIGN.md`: SHA256
  `6ec7948160bcb1fa5adaf13eefcc377ea9341c5455963e16181cd6a12017c22d`.
- `MATHEMATICAL-INVENTORY.json`: SHA256
  `a3167887108d76bbc6dc754a576daf92147462035b09a999a6829e9f87462baf`.

## Finding

No missing mathematical premise was found in the nine theorem contracts.
The file supplies the intended arbitrary-width Lean semantics for the padding
repair. It assumes neither a board size nor an expected count, producer
correctness, positive widths, equal node/claim widths, or masked input planes.

The layout matches the retained ordering: node rank, low, high and value;
claim kind in two bits, then left, right, result and variable. Its payload
width is the maximum of both complete record widths. The four field-transport
and reference theorems use the existing general `wordAt_field` proof, with
the necessary width hypotheses and exact cumulative offsets.

`wordAt_pad` and `length_pad` follow the existing zero-extension semantics,
which append zeros and never truncate an overlong input. The added-field-zero
proof first preserves the original row word, then uses `wordAt_lt` to show its
quotient by `2^planes.length` is zero. This covers zero-width added fields and
inputs longer than the requested common width. The node and claim padding
corollaries derive both width bounds from the same maximum; neither assumes
the claim layout is the wider one.

`claim_reference` keeps `key = nodeCount + j` as an explicit premise. An
untyped pooled-table lookup alone therefore cannot be used as a claim
descriptor. `node_reference` preserves the corresponding exact numeric table
lookup. No reference validity, source-count completeness or arithmetic-rule
premise is weakened.

The nine printed roots agree with the stated theorem inventory. The proof
bodies are ordinary source proofs and contain no admission, custom axiom or
native evaluation path. The existing dependency module and this new helper
must still be freshly checked under the reviewed gate; source inspection
cannot establish elaboration success or actual axiom reports.

## Boundary with the Python repair

The theorem family establishes Lean field decoding and zero-extension
properties. It does not prove that Python emits those encodings or rejects
malformed JSON. Those engineering claims belong to independently derived
producer/replayer logic, exact source-preservation checks and the proposed
small executed tests. Conversely, passing Python tests is not a premise of
any theorem in this helper. No new concrete queen count follows from either
result alone or from their combination.
