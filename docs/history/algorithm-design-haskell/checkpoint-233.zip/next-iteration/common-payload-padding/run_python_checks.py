#!/usr/bin/env python3
"""Two frozen small Python checks; only --run executes their fixed commands."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
HELPER = WORK / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
LOCK = WORK / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
GATE = HERE / 'python-gate'
FORMAT = 'adwh-common-payload-padding-python-gate-v1'
FIXED = {
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    HERE / 'PYTHON-INVENTORY.json': 'b8e15f6a5498af63a2d17535473bbbcf97a785699182c724d1674d351cdb3f34',
    HERE / 'SOURCE-EDITS.json': '60e3fcaba9f0169f3aced50f159550e3df12d52707c5638f7bceb0b3cd1c5a16',
    HERE / 'PYTHON-SOURCE-REVIEW.md': '362acf4907bd38f3858ac09abc74cfa490cc73b37e204f9664bc7a3f6277fdfb',
    HERE / 'PYTHON-SOURCE-AUDIT.json': '3f2463b484468703e2e32bf89e24d794dd95a00d6d8635e94d414745191b0bb6',
}
COMMAND_FILES = ['verify_source_preservation.py', 'tests/test_common_payload.py']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
                  and sha(path) == row['sha256'], 'Changed evidence binding: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot/marker: ' + str(path))


def preflight(h):
    for path, expected in FIXED.items():
        h.require(path.is_file() and sha(path) == expected, 'Fixed reviewed input differs: ' + str(path))
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    inventory, edits, audit = (read(HERE / name) for name in
                               ['PYTHON-INVENTORY.json', 'SOURCE-EDITS.json', 'PYTHON-SOURCE-AUDIT.json'])
    h.require(inventory['format'] == 'adwh-common-payload-padding-python-inventory-v1'
              and inventory['tests']['count'] == 12 and len(set(inventory['tests']['names'])) == 12
              and inventory['tests']['calling_main_router_counter_or_semantic_replay'] is False,
              'Frozen Python scope differs')
    h.require(audit['status'] == 'passed_source_review_no_variant_or_test_execution'
              and Counter(audit['test_source_review']['names']) == Counter(inventory['tests']['names']),
              'Independent source review or test inventory differs')
    entries = {}

    def add(row, role):
        path = (WORK / row['path']).resolve()
        h.require(path.is_relative_to(WORK), 'Input leaves the work tree')
        actual = h.binding(path)
        h.require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
                  'Input identity differs: ' + str(path))
        if str(path) not in entries:
            entries[str(path)] = {**actual, 'relative_path': path.relative_to(WORK).as_posix(), 'roles': []}
        entries[str(path)]['roles'].append(role)

    for key in ['files', 'original_bindings']:
        for row in inventory[key]:
            add(row, key)
    for key in ['helper', 'inventory', 'independent_review']:
        add(inventory['separate_mathematical_evidence'][key], 'separate_mathematical_' + key)
    add(h.binding(HERE / 'PYTHON-INVENTORY.json'), 'python_inventory')
    for row in edits['unchanged_support']:
        for key in ['original_path', 'variant_path']:
            add({'path': row[key], 'bytes': row['bytes'], 'sha256': row['sha256']}, 'unchanged_support')
    reviewed = {str((WORK / row['path']).resolve()): (row['bytes'], row['sha256']) for row in audit['bindings']}
    h.require(audit['binding_count'] == len(audit['bindings']) == len(reviewed) == 17
              and reviewed == {path: (row['bytes'], row['sha256']) for path, row in entries.items()},
              'Review does not cover the exact input inventory')
    add(audit['review'], 'independent_python_review')
    for path, role in [(HERE / 'PYTHON-SOURCE-AUDIT.json', 'independent_python_audit'),
                       (HELPER, 'resource_helper'), (Path(__file__).resolve(), 'runner'),
                       (HERE / 'PYTHON-GATE.md', 'protocol')]:
        add(h.binding(path), role)
    sources = sorted(({'path': row['path'], 'sha256': row['sha256']} for row in inventory['files']
                      if row['path'].endswith('.py')), key=lambda row: row['path'])
    h.require(len(sources) == 5 and len(entries) == 22, 'Exact source/control inventory differs')
    identity = {'stage': 'common-payload-padding-python-checks-v1', 'sources': sources}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    inputs = list(entries.values())
    interpreter = {**h.binding(Path(sys.executable).resolve()), 'version': sys.version}
    verify([*inputs, interpreter], h)
    return {'inputs': inputs, 'source_identity': identity, 'source_fingerprint': fingerprint,
            'interpreter': interpreter, 'required_tests': inventory['tests']['names'],
            'expected_inverse_results': [{'variant': row['variant_path'], 'exact_inverse': True,
                'unchanged_main': True, 'source_sha256': row['variant_sha256']} for row in edits['variants']]}


def audit_output(index, result, plan, h):
    out, err = (Path(result[key]['path']).read_text() for key in ('stdout', 'stderr'))
    h.require(result['exit_code'] == 0 and result['within_limits'], 'Child failed or exceeded the fixed budget')
    if index == 0:
        value = json.loads(out, object_pairs_hook=h.strict_object)
        h.require(not err and value == {'status': 'passed_source_preservation',
                  'variant_results': plan['expected_inverse_results'],
                  'manifest_sha256': FIXED[HERE / 'SOURCE-EDITS.json'],
                  'variants_imported_or_executed': False, 'support_sources_unchanged': True},
                  'Inverse verifier output differs from the exact expected audit')
        return {'passed': True, 'inverse_verifier': value}
    names = re.findall(r'^(test_\w+) \(__main__\.CommonPayloadTests(?:\.\1)?\) \.\.\. ok$', err, re.M)
    h.require(not out and Counter(names) == Counter(plan['required_tests'])
              and len(re.findall(r'^Ran 12 tests in [0-9.]+s$', err, re.M)) == 1
              and err.strip().splitlines()[-1] == 'OK', 'All twelve named tests did not report OK')
    return {'passed': True, 'reported_ok_tests': names, 'reported_count': len(names)}


def run(plan, h):
    attempt = GATE / 'attempts/tests-01'
    marker = GATE / 'execution-markers' / ('checks-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Fixed attempt or source-keyed execution marker already exists')
    attempt.mkdir(parents=True)
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', **plan, 'attempt': str(attempt), 'commands': [],
              'limits': {'cumulative_seconds': 30, 'cpu_count': 1, 'peak_rss_kib': 1048576},
              'snapshots': [], 'execution_marker': None, 'inputs_and_snapshots_postchecked': False,
              'inverse_verifier_passed': False, 'all_12_tests_passed': False,
              'scope': 'Two source-preservation/scalar-codec checks; no queen count, routing or retained main()'}
    h.save(report_path, report)
    began = None
    previous_cpus = os.sched_getaffinity(0)
    try:
        for row in plan['inputs']:
            target = attempt / 'inputs' / row['relative_path']
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            target.chmod(0o444)
            frozen = h.binding(target)
            h.require(all(frozen[key] == row[key] for key in ('bytes', 'sha256')), 'Snapshot bytes differ')
            report['snapshots'].append({**frozen, 'original_path': row['path'], 'roles': row['roles']})
        verify([*plan['inputs'], plan['interpreter']], h)
        verify(report['snapshots'], h, readonly=True)
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker_body = {'format': FORMAT, 'source_identity': plan['source_identity'],
                       'source_fingerprint': plan['source_fingerprint'], 'attempt': str(attempt),
                       'inputs': plan['inputs'], 'interpreter': plan['interpreter']}
        with marker.open('x') as stream:
            stream.write(json.dumps(marker_body, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(previous_cpus)
        os.sched_setaffinity(0, {cpu})
        report.update(status='running', cpu=cpu)
        h.save(report_path, report)
        env = {key: value for key, value in os.environ.items()
               if not key.startswith(('PYTHON', 'LEAN_', 'LAKE_', 'COMPARATOR_'))
               and key not in {'LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'}}
        env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        cwd = attempt / 'inputs' / HERE.relative_to(WORK)
        began = time.monotonic()
        deadline = began + 30
        for index, filename in enumerate(COMMAND_FILES):
            label = ['source-preservation', 'scalar-codec-tests'][index]
            command = [plan['interpreter']['path'], '-I', filename]
            result = h.child(command, cwd, env, attempt / (label + '.stdout.log'),
                             attempt / (label + '.stderr.log'), cpu, deadline)
            report['commands'].append({'label': label, 'cwd': str(cwd), **result})
            h.save(report_path, report)
            result_audit = audit_output(index, result, plan, h)
            report['commands'][-1]['output_audit'] = result_audit
            report['inverse_verifier_passed' if index == 0 else 'all_12_tests_passed'] = True
        report['status'] = 'passed'
    except BaseException as exc:
        report.update(status='failed', failure={'type': type(exc).__name__, 'message': str(exc)})
    finally:
        try:
            verify([*plan['inputs'], plan['interpreter']], h)
            verify(report['snapshots'], h, readonly=True)
            verify([row[key] for row in report['commands'] for key in ('stdout', 'stderr')], h)
            h.require(len(report['snapshots']) == len(plan['inputs']), 'Incomplete input snapshot inventory')
            h.require(report['execution_marker'] is not None, 'Execution marker was not reserved')
            verify([report['execution_marker']], h, readonly=True)
            report['inputs_and_snapshots_postchecked'] = True
        except BaseException as exc:
            report.update(status='failed', postcheck_failure={'type': type(exc).__name__, 'message': str(exc)})
        report['cumulative_verification_seconds'] = None if began is None else time.monotonic() - began
        report['peak_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['commands']), default=0)
        if began is not None and report['cumulative_verification_seconds'] > 30:
            report.update(status='failed', cumulative_limit_exceeded=True)
        os.sched_setaffinity(0, previous_cpus)
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
                      'seconds': report['cumulative_verification_seconds'], 'peak_rss_kib': report['peak_rss_kib']}, sort_keys=True))
    return 0 if report['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if sha(HELPER) != FIXED[HELPER]:
        raise ValueError('Pinned resource helper differs')
    spec = importlib.util.spec_from_file_location('common_payload_python_resource_helper', HELPER)
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    h.require(h.MEMORY_KIB == 1048576, 'Resource helper memory limit differs')
    plan = preflight(h)
    if not args.run:
        print(json.dumps({'status': 'passed_source_only_preflight', 'source_fingerprint': plan['source_fingerprint'],
                          'bound_inputs': len(plan['inputs']), 'required_tests': plan['required_tests']}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
