# Common payload padding: mathematical contract

## Purpose and status

`source/CommonPayloadPadding.lean` is a compact reusable codec module. It
imports only the existing `ConsolidatedGeneric` and introduces one record of
three natural widths. Its contracts apply to arbitrary layouts, bitplane
lists and row indices. They contain no board size, expected count or premise
about the correctness of an external producer.

This document is the **source author's assessment**, not an independent
review or a compilation result. The source and exact theorem statements are
bound by `MATHEMATICAL-INVENTORY.json`. Root will execute the fresh bounded
mathematical gate after source/protocol review. No Lean or other checker was
run while preparing this source and inventory.

## Layout and padding

`Layout` contains `rankBits`, `nodeIdBits` and `valueBits`. The field order
matches the retained producer and replayer:

| Record | Low-to-high semantic fields | Total semantic width |
| --- | --- | --- |
| Node | rank `r`, low `d`, high `d`, value `v` | `r+d+d+v` |
| Claim | kind `2`, left `d`, right `d`, result `d`, variable `r` | `2+d+d+d+r` |

The common payload width is the maximum of these two widths. The two-bit
claim kind is the existing operation-code convention; the other widths may
be zero. Offsets are derived by addition from the widths, not independently
supplied numbers that could disagree with the field layout. Definitions use
the existing `BulkFields.field` and `decodeField` operations.

`pad layout planes` appends zero planes up to the common payload width using
the already proved `BulkFormula.zeroExtend`. It does not truncate an input
that is already longer. Hence its general length is
`max layout.payloadWidth planes.length`. Exact common length additionally
requires `planes.length ≤ layout.payloadWidth`. That condition follows for
an unpadded node or claim record of its declared semantic width. It remains
the producer/replayer's responsibility to enforce the exact external format.

The definition and every theorem remain meaningful for zero field widths,
an empty input list, arbitrary row indices and overlong input lists. These
cases need no positivity assumption or finite row-enumeration proof.

## Nine proof contracts

All names below are under
`ADWH.Experiments.Chapter15.CommonPayloadPadding`. The inventory preserves
the complete source signatures and the ordered `#print axioms` names.

| Theorem | Exact purpose and relevant premise |
| --- | --- |
| `wordAt_pad` | Every row word is unchanged by padding; no length premise. |
| `length_pad` | Padded length is the maximum of common width and input length, so an overlong input is retained. |
| `added_field_zero` | The field starting at the old plane-list length, with width `commonWidth-oldLength`, decodes to zero after padding. |
| `nodePlanes_at` | Sliced node fields equal decoding the full row word, with explicit `nodeWidth ≤ payloads.length`. |
| `claimPlanes_at` | Sliced claim fields equal decoding the full row word, with explicit `claimWidth ≤ payloads.length`. |
| `nodePlanes_pad_at` | Padding supplies the node bound for any input; the sliced padded record equals decoding the original row word. |
| `claimPlanes_pad_at` | Padding supplies the claim bound even when nodes are wider; the sliced padded record equals decoding the original row word. |
| `node_reference` | A genuine routed payload transports to the supplied node table, with the explicit width and full payload-lookup premises. |
| `claim_reference` | The corresponding claim transport retains the additional dense-key equation `key = nodeCount + claimIndex`. |

There are no private theorem declarations, axioms or native computations in
the new source. All nine theorem roots are printed for the gate's actual
axiom audit. The underlying `NodeDesc`, `ClaimDesc`, `NodePlanes` and
`ClaimPlanes` types are the existing ones; no new arithmetic or counting
semantics is introduced.

### Proof construction

The word and length results are direct applications of the accepted
`wordAt_zeroExtend` and `length_zeroExtend` lemmas. `added_field_zero` uses
the existing bound `wordAt planes i < 2^planes.length`: the quotient by
`2^planes.length` is zero, so the appended field's remainder is zero. The
source uses the actual pinned signatures of `Nat.div_eq_of_lt` and
`Nat.zero_mod`, rather than an assumed Boolean equivalence API.

Each field transport applies `wordAt_field` once per semantic field. The
given whole-record width implies every slice bound by natural addition;
the final slice uses the supplied bound directly. The padded transports
combine these results with the two `Nat.le_max_*` bounds and `wordAt_pad`.
The reference transports use equality congruence. In the claim case, lookup
equality is insufficient without the explicit `nodeCount+j` key equation.

The proof dependency and API anchors are recorded in the inventory. They
come from the already retained `ConsolidatedGeneric` source and the installed
source for the pinned Lean 4.35 toolchain. This author inspection does not
substitute for compiling and kernel-checking the module.

## Relation to the Python repair

The Python producer and independent replayer derive their actual widths from
the supplied variable order, table sizes and constant-node values. They can
append an unused zero field to whichever record is narrower. The Lean
contract supplies the mathematical fact needed to interpret that padding:
zero high planes preserve the full row word and all semantic fields.

The theorem `added_field_zero` proves a property of the constructed padding.
It does not assert that arbitrary supplied high bits are zero. The replayer
must independently reject nonzero unused fields, just as the producer must
reject a nonzero value for a declared unused field. The external schemas,
field-width validation and independent decoding must agree.

Python validation is **not formally proved by this module**. Finite
regression tests can check the changed implementations on synthetic cases,
including malformed and negative inputs, but do not prove them universally.
In particular, rejecting negative constants before a division-based width
loop is an implementation termination repair, not a Lean theorem about raw
JSON or Python integers. Lean's width fields are natural numbers already.

Neither a successful Python test nor a correct layout proves that an ADD
producer finishes a larger board, that all semantic certificate obligations
close, or that a final count is correct. A complete source-linked certificate
still requires the separate arithmetic, factor, geometry and source
correspondence proofs. The universal codec now makes its own contribution
reusable without selecting a queens fixture or inserting a new numerical
count proof.

## Proposed fresh mathematical gate

The selected mathematical closure is exactly:

1. The retained `LegacyListClause.lean` source: six existing printed roots.
2. The retained `ConsolidatedGeneric.lean` source: 224 existing printed roots.
3. The new `CommonPayloadPadding.lean`: nine new printed roots.

The resulting inventory is **239 roots in three freshly compiled modules**.
No experimental object is reused; there is no n6 arithmetic module or
numerical endpoint in this gate. The same cumulative 30-second, one-CPU and
one-thread budget, `-j1 -M1024`, 1,048,576-KiB RSS ceiling, default Lean
resource options and allowed axioms (`propext`, `Quot.sound`,
`Classical.choice`) apply. Root and the gate author own the exact runner,
snapshot and changed-source development protocol.

The ordinary kernel remains the mathematical checker. This work neither
adopts an optimized kernel nor moves Python validation into the logical
trust boundary. The ordinary Lean runtime, kernel primitives and pinned
standard-library objects retain the same trust assumptions as the accepted
route. Source-level proof reuse, a compiler success report and an audit of
actual theorem axioms must remain distinct from a claim that Python or a
replacement kernel has been verified.
