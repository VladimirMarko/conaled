# Complete common-payload padding proof gate

This is a new proof gate for the reusable padding and codec helper. It checks
one exact three-module source closure on the pinned Lean 4.35.0 release. The
root agent reviews the frozen sources and controls and alone invokes `--run`.
Preparing the manifest or running preflight executes no Lean, producer, replayer,
counter, exporter, or older experiment.

## Mathematical boundary

The exact fresh module order is:

| Module | Source | Required axiom reports |
| --- | --- | ---: |
| `LegacyListClause` | Accepted baseline191 source | 6 |
| `ConsolidatedGeneric` | Accepted baseline191 source | 224 |
| `CommonPayloadPadding` | New helper in this candidate's `source/` | 9 |
| **Complete closure** | **All three rebuilt in this attempt** | **239** |

The helper imports exactly `ConsolidatedGeneric`, which imports
`LegacyListClause`. Every other import must belong to the pinned distribution's
Init/Std. No original ADWH preparation objects, mathematical objects from another
attempt, or numeric size-six count modules are used. The source files are copied
to a new read-only source directory; the only selected object search directory
starts empty. The expected final artifact inventory is exactly the six `.olean`
and `.ilean` files for these three modules.

The nine helper roots, in order, use namespace
`ADWH.Experiments.Chapter15.CommonPayloadPadding`:

1. `wordAt_pad`
2. `length_pad`
3. `added_field_zero`
4. `nodePlanes_at`
5. `claimPlanes_at`
6. `nodePlanes_pad_at`
7. `claimPlanes_pad_at`
8. `node_reference`
9. `claim_reference`

`source-manifest.json` fixes all 239 fully qualified names and the corresponding
raw source-print identifiers. The 230 baseline roots must equal those in the
accepted baseline full report; an equal count with different names is rejected.
Every required print must occur exactly once in actual compiler output. The
helper author records its actual statements, definitions and qualifications in
`../MATHEMATICAL-DESIGN.md` and `../MATHEMATICAL-INVENTORY.json`.

This is a complete proof of the selected reusable helper, if accepted. Its
statements concern arbitrary natural widths and lists, common zero extension,
existing node/claim decoding, and explicit lookup/key transport premises. There
is no board-instance, complete-trace, source-count, Python-execution-correspondence
or end-to-end producer/replayer correctness claim. Success does not recheck
`cqueens 6`, prove `cqueens 16`, or replace a later fixture's concrete obligations.
The Python padding repair has its own source review and bounded checks.

## Inputs and exact report roles

The two baseline sources are read directly from
`legacy-list-clause-compatibility/count-migration/source/`. No duplicate canonical
copy or previous helper source is needed. The manifest preparer verifies both
against the accepted baseline full report and its source manifest:

```text
baseline full report
bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa
baseline generation manifest
535b0d34f18c48ec6013fb32197896ab46cf482a1c9be4dd10803511b1d19720
```

That full report has the preserved historical generic-pointer defect described
by its `GENERIC-PROVENANCE-ADDENDUM.md` and `GENERIC-PROVENANCE-AUDIT.json`. This
gate uses it only as a source/root provenance reference. All selected mathematics
is freshly checked here; no earlier successful generic result or compiled
baseline object supplies this gate's acceptance.

The runner explicitly distinguishes `accepted_baseline_source_report` from
`pinned_runtime_reference_report`. It checks the former against the actual
baseline path, byte count and hash at manifest preparation, preflight, immediately
before the permanent start marker, and after execution. A different valid report
cannot silently occupy that role. A separate `source_manifest` role must identify
the actual prepared manifest and its read-only snapshot. There is no generic/full
stage split and consequently no accepted-generic-report argument or unused
numeric full branch.

Each attempt copies these **six current controls** to read-only snapshots before
its start marker or compiler invocation:

- `gate/run_gate.py`
- `gate/PROTOCOL.md`
- `gate/source-manifest.json`
- `gate/prepare_manifest.py`
- `MATHEMATICAL-DESIGN.md`
- `MATHEMATICAL-INVENTORY.json`

Each of the three mathematical sources receives its own read-only snapshot too.
Current controls have `snapshot_required: true`; all snapshots are checked for
exact size/hash identity and read-only mode. This preserves a failed proof variant
and its authored contract without relying on later working-file contents.

Eight unchanged historical controls are bound in place with
`retained_historical_reference: true`: the resource helper, source guard,
toolchain pin, runtime reference report, baseline full report, baseline generation
manifest, and the two provenance qualifications. Their complete transitive old
object inventories are not inputs to this new proof gate. The manifest preparer
reads no older mathematical generator and never regenerates a previous candidate.

Source/gate review notes and derived results may be written separately. A review
is not turned into an independent review merely by being authored alongside the
helper. The root's actual source/gate approval remains required before execution.

## Fixed compiler, guard and resources

The only compiler is Lean 4.35.0, commit
`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. Its executable size and SHA-256 must
match `lean435-migration/toolchain.json`; the exact five shared libraries must
match the already-pinned runtime inventory. The executable pin is:

```text
bf8d54e4714cc4b03d3f6bb34c83b7202b87e49c8bfcbff6895c085bb90ceb38
```

This gate uses the unchanged source guard and process-tree resource helper:

```text
project/adwh-lean/scripts/check.py
a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae

next-iteration/lean435-kernel-comparison/run_comparison.py
2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0
```

Every selected source must have `autoImplicit false`, `warningAsError true` and
`Elab.async false`. Source resource overrides (`maxHeartbeats`, `maxRecDepth`,
`maxMemory`) are rejected. The source guard rejects admissions, added axioms,
unsafe/partial shortcuts, native proof evaluation and kernel bypasses. The only
permitted transitive axioms are `propext`, `Quot.sound`, and `Classical.choice`.
The runner also passes the strict options explicitly on every compiler command.

The complete three-module compilation sequence shares **one cumulative
30-second deadline**, **one CPU**, **one compiler thread**, `-j1 -M1024`, and
**1,048,576 KiB resident-memory allowance**. No command-line resource overrides
are available. The deadline is never restarted between modules. Static source,
hash, manifest and snapshot preparation runs before this compilation allowance;
it performs no hidden mathematical compilation. The source and object audits
after the measured sequence are evidence checks, not another compiler gate.

The existing nonblocking `residual-dag/compile.lock` serializes compiler work.
Execution requires ordinary `/proc` visibility. The unchanged helper samples
process-tree RSS every 10 ms, checks the exit high-water mark, and kills the
process group on the deadline or an observed RSS violation. Brief between-sample
overshoot remains possible; this is not an address-space cap. Lean's `-M1024`
allocation limit is a separate constraint. CPU, file-size and core-file limits
are inherited from the same reviewed helper.

The environment clears inherited Lean/Lake configuration and loader injections,
sets `LEAN_PATH` to only the new build directory, and fixes relevant thread
counts to one. The distribution's standard library is the only precompiled
mathematical dependency. No package manager or compiler-discovery subprocess is
invoked.

## Execution identity and failure preservation

There is one stage, `complete`. The intended first attempt is `complete-01`.
The permanent start marker is
`gate/execution-markers/complete-<source-fingerprint>.json`, where the fingerprint
hashes the stage and all three ordered module names/source hashes. It is created
exclusively, after sources/controls have been frozen and before any Lean process,
and then made read-only. The attempt directory must also be absent.

Changing an attempt name, protocol text, resource setting or metadata cannot
permit an unchanged source candidate to execute again. Any actual diagnosed
proof correction requires root review, a newly prepared manifest, a different
mathematical source fingerprint, and a new attempt. The earlier source/control
snapshots, marker, reports and raw logs remain unchanged. A passing candidate
is complete and should not be benchmarked again under another name.

The marker records the exact sources and all controls, including their roles and
snapshot bindings. The report is initially prepared, then running, then records
the actual pass/failure. Exceptions preserve a failed report. The permanent
marker is never deleted to recover from a failure or interruption.

## Acceptance

All three compiler processes must exit zero within the common allowances. Each
must produce both expected objects and exactly its required permitted-axiom
reports. The runner preserves **required**, **observed**, and **accepted** report
counts separately: permitted roots printed by a failing module are observed
only. It stops after the first failed module.

Final success also requires the exact six-object inventory, no imported prior
objects, all 239 observed and accepted reports, all source/control/snapshot/
compiler/runtime/marker bindings unchanged, and the correct explicit report
roles. Actual stdout/stderr bytes, child commands, exit codes, limit outcomes,
elapsed times and RSS measurements are retained. The result's
`complete_common_payload_padding_proof_checked` flag is true only on this full
three-module success; every numeric count flag remains false.

## Commands

From the restored work root, after the helper and its authored metadata are
frozen, prepare its source-only manifest:

```sh
python3 -B next-iteration/common-payload-padding/gate/prepare_manifest.py
python3 -B next-iteration/common-payload-padding/gate/prepare_manifest.py --verify
```

Reviewed source-only preflight, using the actual pinned executable path:

```sh
python3 -B next-iteration/common-payload-padding/gate/run_gate.py \
  --lean /workspace/scratch/40ff1d6addf0/toolchains/lean-4.35.0-linux/bin/lean \
  --attempt complete-01
```

The root alone adds `--run` after reviewing the exact candidate and protocol.
Preflight otherwise creates no attempt directory, snapshots or execution marker.

## Source-only durability

Retain the new helper, six controls, successful or useful failed raw reports/logs
and markers, and the already-retained two baseline sources and eight historical
references. Preserve any unique earlier helper/current-control versions in
failed attempts. Repeated snapshots can be mapped to identical retained bytes;
compiled objects and toolchain binaries need not be duplicated in a checkpoint.
After restoration, recreating source bytes does not authorize resetting an old
marker or representing a rebuild as the historical run. New future mathematical
work must rebuild all its new selected dependencies under its own reviewed gate.
