#!/usr/bin/env python3
"""Fresh complete three-module padding proof gate; only --run executes Lean."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CANDIDATE = HERE.parent
MANIFEST = HERE / 'source-manifest.json'
PREPARER = HERE / 'prepare_manifest.py'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FIXED = {
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
}
BASELINE = ROOT / 'next-iteration/legacy-list-clause-compatibility/count-migration'
BASELINE_REPORT = BASELINE / 'attempts/full-01/report.json'
BASELINE_PINS = {
    BASELINE_REPORT: 'bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa',
    BASELINE / 'generation.json': '535b0d34f18c48ec6013fb32197896ab46cf482a1c9be4dd10803511b1d19720',
    BASELINE / 'GENERIC-PROVENANCE-ADDENDUM.md': 'cfe41eb9e57521430dc2c73b6fd80346de461241f7ce108c42e031569543f0f1',
    BASELINE / 'GENERIC-PROVENANCE-AUDIT.json': '979cc314e668e48923042beab8eeef2ff8d8d116946fb0a7a7574b07c250bd3b',
}
MODULES = ['LegacyListClause', 'ConsolidatedGeneric', 'CommonPayloadPadding']
HELPER_ROOTS = ['ADWH.Experiments.Chapter15.CommonPayloadPadding.' + name for name in
                ('wordAt_pad', 'length_pad', 'added_field_zero', 'nodePlanes_at', 'claimPlanes_at',
                 'nodePlanes_pad_at', 'claimPlanes_pad_at', 'node_reference', 'claim_reference')]
REQUIRED = 239
FORMAT = 'adwh-common-payload-padding-fresh-proof-gate-v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relative(module, suffix):
    return Path(*module.split('.')).with_suffix(suffix)


def verify(rows, h):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                  'Evidence binding differs: ' + str(path))


def fingerprint(stage, sources):
    identity = {'stage': stage, 'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def control_role(plan, role, path, h, require_snapshot=False):
    """Bind this file in its intended role; a different valid report cannot substitute."""
    expected = h.binding(path.resolve())
    rows = [row for row in plan['controls'] if row['role'] == role]
    h.require(len(rows) == 1 and {key: rows[0][key] for key in ('path', 'bytes', 'sha256')} == expected,
              'Exact control role is absent or points to a different file: ' + role)
    if require_snapshot:
        row = rows[0]
        frozen = row.get('snapshot')
        h.require(row['snapshot_required'] and frozen is not None
                  and frozen['bytes'] == expected['bytes'] and frozen['sha256'] == expected['sha256'],
                  'Required current-control snapshot differs: ' + role)
        verify([frozen], h)
        h.require(Path(frozen['path']).stat().st_mode & 0o222 == 0
                  and Path(frozen['path']).read_bytes() == path.resolve().read_bytes(),
                  'Current control snapshot is not read-only and byte-identical: ' + role)
    return expected


def preflight(args, h, guard):
    preparer = load(PREPARER, 'common_payload_padding_manifest')
    manifest = preparer.prepare()
    h.require(MANIFEST.read_bytes() == (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode(),
              'Proof manifest did not reproduce; prepare and review the exact changed source')
    h.require(manifest['format'] == 'adwh-common-payload-padding-proof-manifest-v1'
              and manifest['modules'] == MODULES and manifest['root_module'] == MODULES[-1]
              and manifest['required_axiom_report_count'] == REQUIRED
              and manifest['per_module_axiom_report_counts'] ==
              {'LegacyListClause': 6, 'ConsolidatedGeneric': 224, 'CommonPayloadPadding': 9},
              'Fixed three-module/root inventory differs')
    for path, expected in BASELINE_PINS.items():
        h.require(path.is_file() and sha(path) == expected, 'Accepted baseline reference differs: ' + str(path))
    supplied_baseline = h.binding(BASELINE_REPORT)
    declared_baseline = manifest['accepted_baseline_source_report']
    h.require((ROOT / declared_baseline['path']).resolve() == BASELINE_REPORT
              and all(declared_baseline[key] == supplied_baseline[key] for key in ('bytes', 'sha256')),
              'Manifest identifies a different accepted baseline report')
    baseline_report = json.loads(BASELINE_REPORT.read_text())
    baseline_rows = {row['module']: row for row in baseline_report['source_bindings']}
    h.require(baseline_report['status'] == 'passed' and baseline_report['accepted_axiom_report_count'] == 378,
              'Accepted baseline mathematical scope differs')
    h.require([row['module'] for row in manifest['sources']] == MODULES
              and manifest['axiom_roots']['CommonPayloadPadding'] == HELPER_ROOTS,
              'Source order or nine padding roots differ')
    all_roots = [root for module in MODULES for root in manifest['axiom_roots'][module]]
    h.require(len(all_roots) == len(set(all_roots)) == REQUIRED, 'Required roots are not exact and distinct')
    sources, imports_by_module, available = [], {}, set()
    for entry in manifest['sources']:
        module = entry['module']
        path = (ROOT / entry['path']).resolve()
        expected_path = ((BASELINE / 'source' / relative(module, '.lean')) if module in MODULES[:2]
                         else (CANDIDATE / 'source/CommonPayloadPadding.lean'))
        h.require(path == expected_path and path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'],
                  'Source path or bytes differ: ' + module)
        if module in MODULES[:2]:
            h.require(all(entry[key] == baseline_rows[module][key] for key in ('bytes', 'sha256'))
                      and manifest['axiom_roots'][module] == baseline_report['required_prints'][module]
                      and manifest['source_print_identifiers'][module] == baseline_report['raw_source_print_identifiers'][module],
                      'Accepted baseline source/root identity differs: ' + module)
        code = guard.check_lean_source(path, path.read_text())
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]:
            values = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
            h.require(values and set(values) == {value}, 'Strict source option differs: ' + module)
        h.require(not re.search(r'\bset_option\s+(maxRecDepth|maxHeartbeats|maxMemory)\b', code),
                  'Resource override in selected mathematical source')
        imports = [name for line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M) for name in line.split()]
        h.require(imports == entry['imports'] and all(name in available or name.split('.')[0] in {'Init', 'Std'} for name in imports),
                  'Unlisted or out-of-order mathematical import: ' + module)
        if module == 'CommonPayloadPadding':
            h.require(imports == ['ConsolidatedGeneric'], 'The helper imports more than its exact generic dependency')
        raw_roots = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
        required_roots = manifest['axiom_roots'][module]
        h.require(raw_roots == manifest['source_print_identifiers'][module] and len(raw_roots) == len(required_roots)
                  and all(full == raw or full.endswith('.' + raw) for raw, full in zip(raw_roots, required_roots)),
                  'Raw/full source-print mapping differs: ' + module)
        sources.append({**h.binding(path), 'module': module, 'imports': imports})
        imports_by_module[module] = imports
        available.add(module)
    reached = set()
    def visit(module):
        if module in reached:
            return
        reached.add(module)
        for dependency in imports_by_module[module]:
            if dependency in imports_by_module:
                visit(dependency)
    visit(MODULES[-1])
    h.require(reached == set(MODULES), 'Selected mathematical closure is not exact')

    author_inventory = json.loads((CANDIDATE / 'MATHEMATICAL-INVENTORY.json').read_text())
    h.require(author_inventory['format'] == 'adwh-common-payload-padding-mathematical-source-inventory-v1'
              and author_inventory['ordered_axiom_roots'] == HELPER_ROOTS
              and author_inventory['proposed_fresh_gate']['modules'] == MODULES
              and author_inventory['proposed_fresh_gate']['total_roots'] == REQUIRED,
              'Authored mathematical inventory describes a different source contract')
    for row in [author_inventory['source'], author_inventory['design'], *author_inventory['dependencies']]:
        path = (ROOT / row['path']).resolve()
        h.require(path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                  'Authored mathematical source/design binding differs: ' + str(path))
    h.require((ROOT / author_inventory['source']['path']).resolve()
              == CANDIDATE / 'source/CommonPayloadPadding.lean'
              and (ROOT / author_inventory['design']['path']).resolve() == CANDIDATE / 'MATHEMATICAL-DESIGN.md'
              and [(ROOT / row['path']).resolve() for row in author_inventory['dependencies']]
              == [Path(row['path']) for row in sources[:2]], 'Authored inventory source roles differ')

    lean = args.lean.resolve()
    h.TOOLCHAIN = lean.parent.parent
    pins = json.loads(PIN.read_text())
    compiler = h.binding(lean)
    h.require(pins['version'] == '4.35.0' and pins['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
              and lean.name == 'lean' and compiler['bytes'] == pins['binaries']['lean']['bytes']
              and compiler['sha256'] == pins['binaries']['lean']['sha256'], 'Pinned compiler binary differs')
    reference = json.loads(RUNTIME_REFERENCE.read_text())
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in reference['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((lean.parent.parent / 'lib/lean').glob('*.so'))]
    h.require(len(runtime) == 5 and {Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime} == expected_runtime,
              'Pinned shared-runtime inventory differs')

    current_controls = [
        ('runner', Path(__file__).resolve()), ('protocol', HERE / 'PROTOCOL.md'),
        ('source_manifest', MANIFEST), ('manifest_preparer', PREPARER),
        ('mathematical_design', CANDIDATE / 'MATHEMATICAL-DESIGN.md'),
        ('mathematical_inventory', CANDIDATE / 'MATHEMATICAL-INVENTORY.json'),
    ]
    historical_controls = [
        ('resource_helper', HELPER), ('source_guard', GUARD), ('toolchain_pin', PIN),
        ('pinned_runtime_reference_report', RUNTIME_REFERENCE),
        ('accepted_baseline_source_report', BASELINE_REPORT),
        ('accepted_baseline_source_manifest', BASELINE / 'generation.json'),
        ('baseline_provenance_addendum', BASELINE / 'GENERIC-PROVENANCE-ADDENDUM.md'),
        ('baseline_provenance_audit', BASELINE / 'GENERIC-PROVENANCE-AUDIT.json'),
    ]
    controls = [{**h.binding(path), 'role': role, 'snapshot_required': True, 'retained_historical_reference': False}
                for role, path in current_controls]
    controls += [{**h.binding(path), 'role': role, 'snapshot_required': False, 'retained_historical_reference': True}
                 for role, path in historical_controls]
    h.require(len({row['path'] for row in controls}) == len(controls)
              and len({row['role'] for row in controls}) == len(controls), 'Duplicate control path or role')
    plan = {'manifest': manifest, 'sources': sources, 'source_fingerprint': fingerprint('complete', sources),
            'controls': controls, 'compiler': compiler, 'runtime_libraries': runtime,
            'compiler_release': pins['version'], 'compiler_commit': pins['commit'],
            'accepted_baseline_source_report': supplied_baseline}
    h.require(control_role(plan, 'accepted_baseline_source_report', BASELINE_REPORT, h) == supplied_baseline,
              'The actual baseline report is not bound in its exact role')
    control_role(plan, 'source_manifest', MANIFEST, h)
    control_role(plan, 'pinned_runtime_reference_report', RUNTIME_REFERENCE, h)
    return plan


def counts(report):
    report['observed_axiom_report_count'] = sum(row['observed_report_occurrences'] for row in report['modules'])
    report['observed_unique_axiom_root_count'] = sum(len(row['axiom_audit']['reports']) for row in report['modules'])
    report['accepted_axiom_report_count'] = sum(row['observed_report_occurrences'] for row in report['modules']
                                               if row['status'] == 'passed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'complete-[0-9]{2}', args.attempt) or int(args.attempt[-2:]) < 1:
        parser.error('Attempt must be complete-01, or a later reviewed changed-source development attempt')
    for path, expected in FIXED.items():
        if sha(path) != expected:
            raise ValueError('Unchanged helper/control differs: ' + str(path))
    h = load(HELPER, 'common_payload_padding_resource_helper')
    guard = load(GUARD, 'common_payload_padding_source_guard')
    plan = preflight(args, h, guard)
    manifest = plan['manifest']
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'stage': 'complete',
            'modules': MODULES, 'required_axiom_report_count': REQUIRED,
            'source_fingerprint': plan['source_fingerprint'], 'manifest_sha256': sha(MANIFEST),
            'prepared_objects': 0, 'current_controls_to_snapshot': 6, 'historical_references_bound_in_place': 8,
            'actual_baseline_report_bound_in_its_role': True, 'source_count_proved': False}))
        return 0
    target = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires normal /proc visibility')
        h.require(not target.exists() and not marker.exists(), 'Attempt or unchanged mathematical source already executed')
        frozen, build, input_copies = target / 'source', target / 'build', target / 'inputs'
        frozen.mkdir(parents=True)
        build.mkdir()
        input_copies.mkdir()
        for row in plan['sources']:
            snapshot = frozen / relative(row['module'], '.lean')
            shutil.copyfile(Path(row['path']), snapshot)
            snapshot.chmod(0o444)
            row['snapshot'] = h.binding(snapshot)
            h.require(row['snapshot']['bytes'] == row['bytes'] and row['snapshot']['sha256'] == row['sha256'],
                      'Source snapshot differs')
            h.require(snapshot.stat().st_mode & 0o222 == 0, 'Source snapshot is not read-only')
        for row in plan['controls']:
            if not row['snapshot_required']:
                continue
            path = Path(row['path'])
            snapshot = input_copies / path.relative_to(ROOT)
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, snapshot)
            snapshot.chmod(0o444)
            row['snapshot'] = h.binding(snapshot)
            h.require(row['snapshot']['bytes'] == row['bytes'] and row['snapshot']['sha256'] == row['sha256'],
                      'Current input/control snapshot differs')
        for row in plan['controls']:
            control_role(plan, row['role'], Path(row['path']), h, require_snapshot=row['snapshot_required'])
        h.require(control_role(plan, 'accepted_baseline_source_report', BASELINE_REPORT, h)
                  == plan['accepted_baseline_source_report'], 'Baseline report role changed before start')
        marker.parent.mkdir(exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': args.attempt, 'stage': 'complete',
                'source_fingerprint': plan['source_fingerprint'], 'source_manifest': h.binding(MANIFEST),
                'runner': h.binding(Path(__file__).resolve()), 'protocol': h.binding(HERE / 'PROTOCOL.md'),
                'source_bindings': plan['sources'], 'controls': plan['controls'],
                'accepted_baseline_source_report': plan['accepted_baseline_source_report'],
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        cpu = min(os.sched_getaffinity(0))
        os.sched_setaffinity(0, {cpu})
        env = h.clean_environment(build)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        report = {'format': FORMAT, 'status': 'prepared', 'attempt': args.attempt, 'stage': 'complete',
            'module_order': MODULES, 'root_module': MODULES[-1], 'source_fingerprint': plan['source_fingerprint'],
            'source_manifest': h.binding(MANIFEST), 'source_bindings': plan['sources'],
            'controls': plan['controls'], 'execution_marker': h.binding(marker),
            'compiler': plan['compiler'], 'compiler_release': plan['compiler_release'], 'compiler_commit': plan['compiler_commit'],
            'runtime_libraries': plan['runtime_libraries'],
            'accepted_baseline_source_report': plan['accepted_baseline_source_report'],
            'current_control_snapshot_count': 6, 'historical_reference_count': 8,
            'baseline_generic_provenance_defect_disclosed': True,
            'object_search_path': str(build), 'standard_library': 'Pinned Lean 4.35 release distribution',
            'required_prints': manifest['axiom_roots'], 'raw_source_print_identifiers': manifest['source_print_identifiers'],
            'required_axiom_report_count': REQUIRED,
            'constraints': {'cumulative_wall_seconds': 30, 'cpu_affinity': [cpu], 'compiler_threads': 1,
                            'lean_memory_mib': 1024, 'resident_memory_kib': 1048576,
                            'default_heartbeats_and_recursion': True},
            'compiled_experimental_imports_reused': False, 'prepared_objects': [], 'original_ADWH_imports_used': False,
            'all_selected_mathematical_sources_freshly_checked': False,
            'complete_common_payload_padding_proof_checked': False,
            'all_sources_snapshots_controls_runtime_unchanged': False,
            'actual_baseline_report_bound_in_its_role': True,
            'integrated_project_modified': False, 'source_count_proved': False, 'n16_target_proved': False,
            'producer_or_replayer_executed': False, 'helper_producer_execution_correspondence_proved': False,
            'modules': [], 'artifacts': [], 'observed_axiom_report_count': 0,
            'observed_unique_axiom_root_count': 0, 'accepted_axiom_report_count': 0}
        report_path = target / 'report.json'
        save = lambda: h.save(report_path, report)
        save()
        began = time.monotonic()
        deadline = began + 30.0
        try:
            report['status'] = 'running'
            good = True
            for module in MODULES:
                if time.monotonic() >= deadline:
                    report['cumulative_limit_exceeded'] = 'wall_time'
                    good = False
                    break
                command = [str(args.lean.resolve()), '-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true',
                    '-DElab.async=false', '-o', str(build / relative(module, '.olean')),
                    '-i', str(build / relative(module, '.ilean')), str(relative(module, '.lean'))]
                row = h.child(command, frozen, env, target / (module + '.stdout.log'),
                              target / (module + '.stderr.log'), cpu, deadline)
                output = Path(row['stdout']['path']).read_text() + '\n' + Path(row['stderr']['path']).read_text()
                audit = h.axiom_reports(output, manifest['axiom_roots'][module])
                observed = len(re.findall(r"'([^']+)' (?:depends on axioms:|does not depend on any axioms)", output))
                objects_present = all((build / relative(module, suffix)).is_file() for suffix in ('.olean', '.ilean'))
                passed = (row['exit_code'] == 0 and row['within_limits'] and row['limit_exceeded'] is None
                          and audit['passed'] and objects_present)
                row.update(module=module, status='passed' if passed else 'failed', axiom_audit=audit,
                           observed_report_occurrences=observed, required_objects_present=objects_present)
                report['modules'].append(row)
                counts(report)
                save()
                if not passed:
                    good = False
                    break
            report['seconds'] = time.monotonic() - began
            report['peak_child_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']), default=0)
            verify(plan['sources'] + plan['controls'] + plan['runtime_libraries'] + [plan['compiler'], report['execution_marker']], h)
            verify([row['snapshot'] for row in plan['sources'] + plan['controls'] if 'snapshot' in row], h)
            h.require(all(Path(row['snapshot']['path']).stat().st_mode & 0o222 == 0 for row in plan['sources']),
                      'A source snapshot lost its read-only mode')
            for row in plan['controls']:
                control_role(plan, row['role'], Path(row['path']), h, require_snapshot=row['snapshot_required'])
            h.require(control_role(plan, 'accepted_baseline_source_report', BASELINE_REPORT, h)
                      == report['accepted_baseline_source_report'], 'Baseline report role changed after execution')
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            expected_paths = {str(build / relative(module, suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = {row['path'] for row in report['artifacts']} == expected_paths
            counts(report)
            report['all_selected_mathematical_sources_freshly_checked'] = (good and len(report['modules']) == len(MODULES)
                and report['seconds'] <= 30 and report['peak_child_rss_kib'] <= 1048576
                and report['observed_axiom_report_count'] == report['accepted_axiom_report_count'] == REQUIRED
                and report['exact_build_artifact_inventory'])
            report['status'] = 'passed' if report['all_selected_mathematical_sources_freshly_checked'] else 'failed'
            report['complete_common_payload_padding_proof_checked'] = report['status'] == 'passed'
            save()
        except BaseException as error:
            report.update(status='failed', seconds=time.monotonic() - began,
                all_selected_mathematical_sources_freshly_checked=False,
                complete_common_payload_padding_proof_checked=False,
                exception={'type': type(error).__name__, 'message': str(error)})
            counts(report)
            save()
            raise
    print(json.dumps({'status': report['status'], 'stage': 'complete', 'seconds': report.get('seconds'),
        'peak_child_rss_kib': report.get('peak_child_rss_kib'), 'required_axiom_report_count': REQUIRED,
        'observed_axiom_report_count': report['observed_axiom_report_count'],
        'accepted_axiom_report_count': report['accepted_axiom_report_count'],
        'complete_common_payload_padding_proof_checked': report['complete_common_payload_padding_proof_checked'],
        'source_count_proved': False, 'report': str(report_path), 'report_sha256': sha(report_path)}))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
