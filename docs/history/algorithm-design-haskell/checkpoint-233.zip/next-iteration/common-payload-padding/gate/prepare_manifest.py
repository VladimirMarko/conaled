#!/usr/bin/env python3
"""Prepare the exact three-module padding proof inventory; never executes Lean."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CANDIDATE = HERE.parent
MANIFEST = HERE / 'source-manifest.json'
BASELINE = ROOT / 'next-iteration/legacy-list-clause-compatibility/count-migration'
BASELINE_MANIFEST = BASELINE / 'generation.json'
BASELINE_REPORT = BASELINE / 'attempts/full-01/report.json'
BASELINE_PINS = {
    BASELINE_MANIFEST: '535b0d34f18c48ec6013fb32197896ab46cf482a1c9be4dd10803511b1d19720',
    BASELINE_REPORT: 'bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa',
    BASELINE / 'GENERIC-PROVENANCE-ADDENDUM.md': 'cfe41eb9e57521430dc2c73b6fd80346de461241f7ce108c42e031569543f0f1',
    BASELINE / 'GENERIC-PROVENANCE-AUDIT.json': '979cc314e668e48923042beab8eeef2ff8d8d116946fb0a7a7574b07c250bd3b',
}
MODULES = ['LegacyListClause', 'ConsolidatedGeneric', 'CommonPayloadPadding']
ROOT_SUFFIXES = ['wordAt_pad', 'length_pad', 'added_field_zero', 'nodePlanes_at', 'claimPlanes_at',
                 'nodePlanes_pad_at', 'claimPlanes_pad_at', 'node_reference', 'claim_reference']
HELPER_ROOTS = ['ADWH.Experiments.Chapter15.CommonPayloadPadding.' + name for name in ROOT_SUFFIXES]
COUNTS = {'LegacyListClause': 6, 'ConsolidatedGeneric': 224, 'CommonPayloadPadding': 9}


def binding(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def prepare():
    for path, expected in BASELINE_PINS.items():
        require(binding(path)['sha256'] == expected, 'Pinned baseline control differs: ' + str(path))
    baseline = json.loads(BASELINE_MANIFEST.read_text())
    report = json.loads(BASELINE_REPORT.read_text())
    require(report['status'] == 'passed' and report['accepted_axiom_report_count'] == 378,
            'The historical baseline is not the accepted 378-root full gate')
    old_sources = {row['module']: row for row in baseline['sources']}
    checked_sources = {row['module']: row for row in report['source_bindings']}
    sources, roots, raw_roots = [], {}, {}
    for module in MODULES[:2]:
        row = old_sources[module]
        actual = binding(ROOT / row['path'])
        require(all(actual[key] == row[key] == checked_sources[module][key]
                    for key in ('bytes', 'sha256')), 'Baseline mathematical source differs: ' + module)
        require(actual['path'] == row['path'], 'Baseline source location differs')
        sources.append({**actual, 'module': module, 'imports': row['imports']})
        roots[module] = baseline['axiom_roots'][module]
        raw_roots[module] = baseline['source_print_identifiers'][module]
        require(roots[module] == report['required_prints'][module], 'Baseline root identities differ')
        require(raw_roots[module] == report['raw_source_print_identifiers'][module], 'Baseline raw print identities differ')
    helper = CANDIDATE / 'source/CommonPayloadPadding.lean'
    text = helper.read_text()
    actual_prints = re.findall(r'^\s*#print\s+axioms\s+(\S+)', text, re.M)
    require(actual_prints == HELPER_ROOTS, 'The exact nine padding roots differ')
    sources.append({**binding(helper), 'module': MODULES[-1], 'imports': ['ConsolidatedGeneric']})
    roots[MODULES[-1]] = HELPER_ROOTS
    raw_roots[MODULES[-1]] = actual_prints
    require({module: len(roots[module]) for module in MODULES} == COUNTS, 'Per-module root count differs')
    all_roots = [name for module in MODULES for name in roots[module]]
    require(len(all_roots) == len(set(all_roots)) == 239, 'The exact 239 roots are not distinct')
    return {
        'format': 'adwh-common-payload-padding-proof-manifest-v1',
        'modules': MODULES, 'root_module': MODULES[-1], 'sources': sources,
        'axiom_roots': roots, 'source_print_identifiers': raw_roots,
        'per_module_axiom_report_counts': COUNTS, 'required_axiom_report_count': 239,
        'accepted_baseline_source_report': binding(BASELINE_REPORT),
        'baseline_source_manifest': binding(BASELINE_MANIFEST),
        'baseline_provenance_qualification': [binding(path) for path in list(BASELINE_PINS)[2:]],
        'all_three_mathematical_sources_must_be_fresh': True,
        'compiled_imports_reused': False, 'original_ADWH_imports_used': False,
        'scope': 'Universal common-payload padding and exact existing node/claim field transports.',
        'new_source_count_proved': False, 'board_instance_or_trace_produced': False,
        'helper_producer_execution_correspondence_proved': False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    manifest = prepare()
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    if args.verify:
        require(MANIFEST.is_file() and MANIFEST.read_bytes() == raw, 'Current proof manifest differs')
    else:
        MANIFEST.write_bytes(raw)
    print(json.dumps({'status': 'verified' if args.verify else 'prepared', 'compiler_executed': False,
                      'modules': MODULES, 'required_axiom_report_count': 239,
                      'manifest': binding(MANIFEST)}, sort_keys=True))


if __name__ == '__main__':
    main()
