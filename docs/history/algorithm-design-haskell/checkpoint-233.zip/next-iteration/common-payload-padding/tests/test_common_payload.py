#!/usr/bin/env python3
"""Small encoding tests only; no counter, routing run, trace generator or main().

The synthetic records deliberately do not constitute a queen-count trace.
Only the new variants' shape and scalar codec functions are called. Their CLI
trace guards are unchanged and are not bypassed to generate a certificate.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def load_variant(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "source" / filename)
    if spec is None or spec.loader is None:
        raise RuntimeError("Missing reviewed source variant")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


P = load_variant("common_payload_producer_under_test", "produce_common_payload.py")
R = load_variant("common_payload_replayer_under_test", "replay_common_payload.py")


def synthetic_shape(maximum: int = 2):
    """Four nodes, three claim slots and five variables; no counting semantics."""
    header = {"type": "header", "format": "queens-line-add-v1", "n": 6,
              "operation_cap": 50000, "variable_order": ["a", "b", "c", "d", "e"]}
    nodes = [{"type": "node", "id": i, "kind": "constant", "value": value}
             for i, value in enumerate([0, 1, 2, maximum])]
    claims = [{"type": "operation", "id": i} for i in range(3)]
    return header, nodes, claims


def configure_both(maximum: int = 2):
    header, nodes, claims = synthetic_shape(maximum)
    P.configure(header, nodes, claims)
    R.infer_shape([header, *nodes, *claims])
    return header, nodes, claims


def normalized(fields):
    return [[name, width] for name, width in fields]


class CommonPayloadTests(unittest.TestCase):
    def setUp(self):
        configure_both()

    def test_ordinary_serialization_layout_and_known_words(self):
        # Exact legacy layout for this fixed small shape: no new claim key.
        self.assertEqual(P.NODE_FIELDS,
                         [("rank", 3), ("low", 3), ("high", 3),
                          ("value", 2), ("unused", 3)])
        self.assertEqual(P.CLAIM_FIELDS,
                         [("kind", 2), ("left", 3), ("right", 3),
                          ("result", 3), ("variable", 3)])
        self.assertEqual(P.WITNESS_FIELDS,
                         [("rule", 4), ("splitRank", 3), ("lowOp", 2), ("highOp", 2)])
        self.assertEqual(P.PARAMETERS, {
            "board": 6, "variables": 5, "nodes": 4, "claims": 3,
            "table_definitions": 7, "lanes": 32, "key_bits": 5,
            "payload_bits": 14, "node_bits": 3, "claim_bits": 2,
            "rank_bits": 3, "value_bits": 2, "rule_bits": 4,
            "operation_cap": 50000})
        self.assertEqual(P.PARAMETERS, R.PARAMETERS)
        node = {"rank": 5, "low": 0, "high": 0, "value": 2}
        claim = {"kind": 2, "left": 3, "right": 0, "result": 1, "variable": 4}
        self.assertEqual(P.encode(node, P.NODE_FIELDS), 1029)
        self.assertEqual(P.encode(claim, P.CLAIM_FIELDS), 8462)
        self.assertEqual(R.node_decode(1029), node)
        self.assertEqual(R.claim_decode(8462), claim)

    def test_both_payload_orderings_tie_and_multiword_values(self):
        # These are width-boundary cases, not board-size or performance sweeps.
        cases = [(2, 2, 14, None), (31, 5, 14, None),
                 (32, 6, 15, 1), ((1 << 80) + 7, 81, 90, 76)]
        for maximum, value_bits, payload_bits, padding_bits in cases:
            with self.subTest(value_bits=value_bits):
                configure_both(maximum)
                self.assertEqual(P.VALUE_BITS, value_bits)
                self.assertEqual(R.VALUE_WIDTH, value_bits)
                self.assertEqual(P.PAYLOAD_BITS, payload_bits)
                self.assertEqual(R.PAYLOAD_WIDTH, payload_bits)
                self.assertEqual(P.PARAMETERS, R.PARAMETERS)
                self.assertEqual(normalized(P.NODE_FIELDS), R.DESCRIPTOR_FIELDS["node"])
                self.assertEqual(normalized(P.CLAIM_FIELDS), R.DESCRIPTOR_FIELDS["claim"])
                self.assertEqual(normalized(P.WITNESS_FIELDS), R.DESCRIPTOR_FIELDS["witness"])
                self.assertEqual(dict(P.CLAIM_FIELDS).get("unused"), padding_bits)
                self.assertEqual(sum(width for _, width in P.NODE_FIELDS), payload_bits)
                self.assertEqual(sum(width for _, width in P.CLAIM_FIELDS), payload_bits)
                node = {"rank": 5, "low": 0, "high": 0, "value": maximum}
                claim = {"kind": 2, "left": 3, "right": 0, "result": 1, "variable": 4}
                self.assertEqual(R.node_decode(P.encode(node, P.NODE_FIELDS)), node)
                self.assertEqual(R.claim_decode(P.encode(claim, P.CLAIM_FIELDS)), claim)
                # A zero high field never changes the integer or five semantic fields.
                self.assertEqual(P.encode(claim, P.CLAIM_FIELDS), 8462)
                self.assertEqual(list(R.claim_decode(8462)),
                                 ["kind", "left", "right", "result", "variable"])

    def test_shape_ignores_answer_metadata(self):
        header, nodes, claims = synthetic_shape(32)
        for proposed_answer in [0, 1 << 512]:
            with self.subTest(proposed_answer_bits=proposed_answer.bit_length()):
                altered = {**header, "expected_diagnostic": proposed_answer}
                finish = {"type": "finish", "count": proposed_answer}
                P.configure(altered, nodes, claims)
                R.infer_shape([altered, *nodes, *claims, finish])
                self.assertEqual(P.VALUE_BITS, 6)
                self.assertEqual(R.VALUE_WIDTH, 6)
                self.assertEqual(P.PAYLOAD_BITS, 15)
                self.assertEqual(P.PARAMETERS, R.PARAMETERS)

    def test_malformed_and_negative_constant_values_rejected_before_widths(self):
        for bad in [-1, -100, True, False, 1.5, "32", None]:
            with self.subTest(value=bad):
                header, nodes, claims = synthetic_shape()
                nodes[-1]["value"] = bad
                with self.assertRaises(ValueError):
                    P.configure(header, nodes, claims)
                with self.assertRaises(R.Rejected):
                    R.infer_shape([header, *nodes, *claims])

    def test_missing_constant_value_and_empty_constant_family_rejected(self):
        header, nodes, claims = synthetic_shape()
        del nodes[-1]["value"]
        with self.assertRaises(ValueError):
            P.configure(header, nodes, claims)
        with self.assertRaises(R.Rejected):
            R.infer_shape([header, *nodes, *claims])
        for node in nodes:
            node["kind"] = "ite"
        with self.assertRaises(ValueError):
            P.configure(header, nodes, claims)
        with self.assertRaises(R.Rejected):
            R.infer_shape([header, *nodes, *claims])

    def test_invalid_field_widths_rejected_before_shifts_or_powers(self):
        for bad_width in [-1, True, False, 1.5, "3", None]:
            with self.subTest(width=bad_width):
                fields = [("kind", bad_width)]
                with self.assertRaisesRegex(ValueError, "Invalid descriptor field width"):
                    P.encode({"kind": 0}, fields)
                with self.assertRaisesRegex(R.Rejected, "Invalid descriptor field width"):
                    R.decode_fields(0, fields)

    def test_negative_noninteger_and_overflow_semantic_fields_rejected(self):
        claim = {"kind": 2, "left": 3, "right": 0, "result": 1, "variable": 4}
        for field, width in P.CLAIM_FIELDS:
            for bad in [-1, True, 0.5, "0", None, 1 << width]:
                with self.subTest(field=field, value=bad):
                    with self.assertRaises(ValueError):
                        P.encode({**claim, field: bad}, P.CLAIM_FIELDS)

    def test_payload_overflow_and_malformed_naturals_rejected(self):
        for bad in [-1, True, 0.5, "0", None, 1 << P.PAYLOAD_BITS]:
            with self.subTest(payload=bad):
                with self.assertRaises(R.Rejected):
                    R.node_decode(bad)
                with self.assertRaises(R.Rejected):
                    R.claim_decode(bad)

    def test_explicit_zero_padding_and_nonzero_node_padding_rejection(self):
        node = {"rank": 5, "low": 0, "high": 0, "value": 2}
        self.assertEqual(P.encode({**node, "unused": 0}, P.NODE_FIELDS), 1029)
        with self.assertRaisesRegex(ValueError, "Nonzero descriptor padding"):
            P.encode({**node, "unused": 1}, P.NODE_FIELDS)
        with self.assertRaisesRegex(R.Rejected, "Node unused high bits"):
            R.node_decode(1029 | (1 << 11))

    def test_nonzero_claim_padding_rejected_and_removed_only_when_zero(self):
        configure_both((1 << 80) + 7)
        claim = {"kind": 2, "left": 3, "right": 0, "result": 1, "variable": 4}
        self.assertEqual(P.encode({**claim, "unused": 0}, P.CLAIM_FIELDS), 8462)
        for padding in [1, 1 << 75]:
            with self.subTest(padding_bits=padding.bit_length()):
                with self.assertRaisesRegex(ValueError, "Nonzero descriptor padding"):
                    P.encode({**claim, "unused": padding}, P.CLAIM_FIELDS)
                with self.assertRaisesRegex(R.Rejected, "Claim unused high bits"):
                    R.claim_decode(8462 | (padding << 14))
        self.assertEqual(R.claim_decode(8462), claim)
        self.assertNotIn("unused", R.claim_decode(8462))

    def test_zero_width_node_padding_is_valid(self):
        configure_both(31)
        self.assertEqual(P.NODE_FIELDS[-1], ("unused", 0))
        node = {"rank": 5, "low": 0, "high": 0, "value": 31}
        word = P.encode({**node, "unused": 0}, P.NODE_FIELDS)
        self.assertEqual(R.node_decode(word), node)
        with self.assertRaises(ValueError):
            P.encode({**node, "unused": 1}, P.NODE_FIELDS)

    def test_existing_shape_authorization_guards_remain(self):
        for patch in [{"n": 0}, {"format": "unapproved-format"}, {"operation_cap": 50001}]:
            with self.subTest(patch=patch):
                header, nodes, claims = synthetic_shape()
                header.update(patch)
                with self.assertRaises(ValueError):
                    P.configure(header, nodes, claims)
                with self.assertRaises(R.Rejected):
                    R.infer_shape([header, *nodes, *claims])


if __name__ == "__main__":
    unittest.main(verbosity=2)
