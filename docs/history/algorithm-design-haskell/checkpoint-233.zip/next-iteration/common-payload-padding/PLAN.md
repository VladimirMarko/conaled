# Common-payload padding repair

## Prepared result and scope

The new Python variants repair the serialization restriction that rejected a
node descriptor wider than a claim descriptor. Both families now use the
common payload width `P = max(nodeWidth, claimWidth)`, with zero padding in the
shorter family. Widths still come from actual record dimensions and actual
constant-node values. No expected queen count determines a width.

The variants are prepared for root-run verification; neither has been executed
by their author. No counting trace, routed certificate or Lean instance was
generated. Accepted sources and execution markers remain unchanged.

The companion `source/CommonPayloadPadding.lean`, authored and separately
reviewed by the mathematical-contract agent, supplies a universal Lean
field/padding contract. Its acceptance is pending a fresh gate. That theorem
family concerns arbitrary natural widths and rows; it does not certify Python
execution or establish a new queen count.

## Exact source changes

`source/produce_common_payload.py` is a separately named variant of the
retained `produce_packed_add.py`.

- Derive `P` exactly as before, then permit either record family to determine
  it. Append an `unused` claim field only when `P > claimWidth`.
- Keep the ordinary claim field list unchanged when no new padding is needed;
  in particular, do not add a zero-width claim field to the old format.
- Reject a nonzero value in every configured `unused` field. All semantic
  fields retain their existing bounds and order.

`source/replay_common_payload.py` independently derives widths using its own
division-based width calculation. It imports neither producer nor router. It
adds the optional claim padding field independently, checks that field is
zero, removes it, and returns exactly the same five semantic claim fields:
`kind`, `left`, `right`, `result`, `variable`.

Separate, disclosed numeric-validation edits reject malformed or negative
constant-node values before width calculation, and reject malformed or
negative descriptor-field widths before shifts or powers. The replay width
function also validates its argument before its division loop. This prevents
negative values from entering the old nonterminating width-loop case. These
are validation changes, recorded separately from padding changes.

The two `main()` bodies are byte-identical to their originals. The exact trace
hash, header `n == 6` check, operation cap, certificate format, rule codes,
source-occurrence checks, and full semantic/routing obligations are preserved.
The existing pinned command-line wrappers have not been broadened to new
inputs. Transferable shape/codec logic and its universal mathematical contract
can later be used by a separately reviewed input protocol.

`source/route_support.py` is an unchanged copy required by the producer's
existing relative import. No test calls or imports that router.

## Recovery and preservation

`SOURCE-EDITS.json` records every old/new text edit, application offset,
original/variant hash and size, source diff and unchanged `main()` hash.
Reversing the recorded edits recovers the exact retained source bytes.
The two `.diff` files expose all changes, including documentation and numeric
validation. `verify_source_preservation.py` checks these bindings and inverse
operations without importing or executing a source variant.

The implementation author has checked source syntax with `ast.parse`, exact
inverse recovery and unchanged `main()` text while writing these files. These
are source checks, not executed codec tests. The bounded test run and formal
proof run remain separate, pending root review.

## Meaningful verification cases

`tests/test_common_payload.py` contains twelve tests. It imports only the new
variants and calls their shape/scalar-codec functions. Synthetic data have
four nodes, three claim slots and five variables; they do not constitute a
queen-count trace and are never passed to a producer/replayer `main()`.

The fixed width-boundary cases cover:

| Maximum actual constant | Value bits | Common payload bits | Added claim padding |
| --- | ---: | ---: | ---: |
| 2 | 2 | 14 | None; ordinary format |
| 31 | 5 | 14 | None; equal node/claim widths |
| 32 | 6 | 15 | 1 bit; formerly rejected ordering |
| `2^80 + 7` | 81 | 90 | 76 bits; beyond machine-word values |

Independent replay must recover the exact original semantic node/claim
records. A golden ordinary case checks the old layout and packed integers
1029 and 8462. The claim word stays 8462 when high zero padding is added, and
the decoded claim retains exactly its five original fields. Other tests check
missing/malformed/negative constant values, malformed field widths, semantic
field overflow, total-payload overflow, nonzero node/claim padding, valid
zero-width node padding, unchanged shape guards, and independence from
diagnostic answer metadata.

These cases test the actual defect and its validation boundary. They are not
a board-size sweep, performance comparison, counting experiment or evidence
that a larger certificate fits the gate. The proposed bounded execution is in
[VERIFICATION-PLAN.md](VERIFICATION-PLAN.md).
