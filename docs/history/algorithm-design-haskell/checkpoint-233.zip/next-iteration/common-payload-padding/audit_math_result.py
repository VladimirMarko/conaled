#!/usr/bin/env python3
"""Audit saved padding-proof evidence without executing Lean, a gate or a generator.

Default mode requires the recorded live snapshots, six compiled objects and
compiler/runtime bytes. --source-only verifies portable retained payloads and
uses exact canonical copies for omitted snapshots; it explicitly skips objects
and runtime bytes. Nothing is written unless --write is supplied.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REPORT = HERE / 'gate/attempts/complete-01/report.json'
REPORT_SHA = '292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8'
MODULES = ['LegacyListClause', 'ConsolidatedGeneric', 'CommonPayloadPadding']
COUNTS = [6, 224, 9]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
HELPER_ROOTS = ['ADWH.Experiments.Chapter15.CommonPayloadPadding.' + name for name in
                ('wordAt_pad', 'length_pad', 'added_field_zero', 'nodePlanes_at', 'claimPlanes_at',
                 'nodePlanes_pad_at', 'claimPlanes_pad_at', 'node_reference', 'claim_reference')]
BASELINE_REPORT = 'next-iteration/legacy-list-clause-compatibility/count-migration/attempts/full-01/report.json'
BASELINE_SHA = 'bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa'
RUNTIME_REPORT = 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
RUNTIME_SHA = 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2'


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def bindings(value):
    rows = []
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            rows.append({key: value[key] for key in ('path', 'bytes', 'sha256')})
        for item in value.values():
            rows.extend(bindings(item))
    elif isinstance(value, list):
        for item in value:
            rows.extend(bindings(item))
    return rows


def parse_axioms(text, required):
    found = {}
    for match in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", text, re.S):
        found[match[1]] = sorted(value.strip() for value in match[2].split(',') if value.strip())
    for match in re.finditer(r"'([^']+)' does not depend on any axioms", text):
        found[match[1]] = []
    occurrences = re.findall(r"'([^']+)' (?:depends on axioms:|does not depend on any axioms)", text)
    require(Counter(occurrences) == Counter(required) and set(found) == set(required),
            'Raw axiom names/multiplicities differ')
    require(all(set(values) <= ALLOWED for values in found.values()), 'Unapproved axiom')
    require(not re.search(r'(?:warning|error)(?:\([^\n]*?\))?:', text), 'Compiler warning/error diagnostic')
    require(not any(value in text for value in ['sorryAx', '_native', 'Lean.ofReduceBool',
                                               'Lean.ofReduceNat', 'Lean.trustCompiler']), 'Forbidden proof mechanism')
    return found, len(occurrences)


def audit(source_only=False):
    require(digest(REPORT) == REPORT_SHA, 'The exact completed raw report differs')
    report = json.loads(REPORT.read_text())
    require(report['format'] == 'adwh-common-payload-padding-fresh-proof-gate-v1'
            and report['attempt'] == 'complete-01' and report['stage'] == 'complete'
            and report['module_order'] == MODULES and report['status'] == 'passed', 'Actual run identity/outcome differs')
    old_root = Path(report['source_manifest']['path']).parents[3]
    snapshots = {}
    recovery = []
    for row in report['source_bindings'] + report['controls']:
        if 'snapshot' not in row:
            continue
        frozen = row['snapshot']
        require(all(row[key] == frozen[key] for key in ('bytes', 'sha256')), 'Snapshot identity differs from original')
        snapshots[frozen['path']] = row['path']
        recovery.append({'snapshot': Path(frozen['path']).relative_to(old_root).as_posix(),
                         'retained_path': Path(row['path']).relative_to(old_root).as_posix(),
                         'bytes': row['bytes'], 'sha256': row['sha256'],
                         'kind': 'source' if 'module' in row else 'current_control',
                         'regeneration_required': False})
    require(len(recovery) == len(snapshots) == 9, 'Nine exact snapshots required')

    def local(recorded):
        path = Path(recorded)
        return ROOT / path.relative_to(old_root) if path.is_relative_to(old_root) else path

    omitted = {row['path'] for row in report['artifacts'] + [report['compiler']] + report['runtime_libraries']}
    resolved, aliases, skipped = {}, {}, set()
    def verify(row):
        recorded = row['path']
        identity = (recorded, row['bytes'], row['sha256'])
        if source_only and recorded in omitted:
            skipped.add(identity)
            return
        path = local(recorded)
        if not path.is_file() and source_only and recorded in snapshots:
            path = local(snapshots[recorded])
            aliases[recorded] = str(path)
        require(path.is_file(), 'Required evidence unavailable: ' + str(path))
        require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'],
                'Saved file binding differs: ' + str(path))
        resolved[identity] = str(path)

    direct = bindings(report)
    for row in direct:
        verify(row)
    marker_path = local(report['execution_marker']['path'])
    marker = json.loads(marker_path.read_text())
    marker_rows = bindings(marker)
    for row in marker_rows:
        verify(row)
    require(marker['format'] == report['format'] and marker['attempt'] == report['attempt']
            and marker['stage'] == report['stage'] and marker['source_fingerprint'] == report['source_fingerprint']
            and marker['source_bindings'] == report['source_bindings'] and marker['controls'] == report['controls']
            and marker['accepted_baseline_source_report'] == report['accepted_baseline_source_report'],
            'Permanent marker and actual report differ')
    if not source_only:
        require(marker_path.stat().st_mode & 0o222 == 0, 'Start marker is no longer read-only')
        require(all(local(path).stat().st_mode & 0o222 == 0 for path in snapshots), 'Snapshot is no longer read-only')

    controls = {row['role']: row for row in report['controls']}
    require(len(controls) == len(report['controls']) == 14, 'Control roles are not distinct')
    current = [row for row in report['controls'] if row['snapshot_required']]
    historical = [row for row in report['controls'] if row['retained_historical_reference']]
    require(len(current) == report['current_control_snapshot_count'] == 6
            and len(historical) == report['historical_reference_count'] == 8
            and all(row['snapshot_required'] != row['retained_historical_reference'] for row in report['controls']),
            'Current/historical control boundary differs')
    for role, path, sha in [('accepted_baseline_source_report', BASELINE_REPORT, BASELINE_SHA),
                           ('pinned_runtime_reference_report', RUNTIME_REPORT, RUNTIME_SHA)]:
        row = controls[role]
        require(Path(row['path']).relative_to(old_root).as_posix() == path and row['sha256'] == sha,
                'A different report occupies role ' + role)
    require({key: controls['accepted_baseline_source_report'][key] for key in ('path', 'bytes', 'sha256')}
            == report['accepted_baseline_source_report'] == marker['accepted_baseline_source_report'],
            'The actual baseline report binding was substituted')
    require({key: controls['source_manifest'][key] for key in ('path', 'bytes', 'sha256')}
            == report['source_manifest'] == marker['source_manifest'], 'The actual source manifest binding differs')
    manifest = json.loads(local(report['source_manifest']['path']).read_text())
    require(manifest['modules'] == MODULES and manifest['axiom_roots'] == report['required_prints']
            and manifest['source_print_identifiers'] == report['raw_source_print_identifiers']
            and manifest['axiom_roots']['CommonPayloadPadding'] == HELPER_ROOTS
            and manifest['required_axiom_report_count'] == 239, 'Exact root manifest differs')
    all_roots = [name for module in MODULES for name in manifest['axiom_roots'][module]]
    require(len(all_roots) == len(set(all_roots)) == 239, 'Required roots are not distinct')
    identity = {'stage': 'complete', 'sources': [{'module': row['module'], 'sha256': row['sha256']}
                                               for row in report['source_bindings']]}
    source_fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(source_fingerprint == report['source_fingerprint'], 'Source fingerprint differs')
    require([row['module'] for row in report['source_bindings']] == MODULES, 'Selected source order differs')
    for row, expected in zip(report['source_bindings'], manifest['sources']):
        require(all(row[key] == expected[key] for key in ('module', 'bytes', 'sha256', 'imports'))
                and Path(row['path']).relative_to(old_root).as_posix() == expected['path'], 'Source manifest binding differs')
        source = local(row['path']).read_text()
        require(re.findall(r'^\s*#print\s+axioms\s+(\S+)', source, re.M)
                == manifest['source_print_identifiers'][row['module']], 'Source print inventory differs')
        require(not re.search(r'\bset_option\s+(maxRecDepth|maxHeartbeats|maxMemory)\b', source), 'Source resource override')
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]:
            values = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', source)
            require(values and set(values) == {value}, 'Strict source option differs')

    constraints = report['constraints']
    require(constraints['cumulative_wall_seconds'] == 30 and constraints['compiler_threads'] == 1
            and len(constraints['cpu_affinity']) == 1 and constraints['lean_memory_mib'] == 1024
            and constraints['resident_memory_kib'] == 1048576 and constraints['default_heartbeats_and_recursion'],
            'Recorded fixed resource contract differs')
    require(report['compiler_release'] == '4.35.0'
            and report['compiler_commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and len(report['runtime_libraries']) == 5, 'Compiler/runtime identity differs')
    require(report['seconds'] <= 30 and report['peak_child_rss_kib'] <= 1048576, 'Completed gate exceeded a limit')
    require(not report['compiled_experimental_imports_reused'] and report['prepared_objects'] == []
            and not report['original_ADWH_imports_used'], 'An unapproved object pool was used')
    require([row['module'] for row in report['modules']] == MODULES, 'Compiled module order differs')
    summaries, helper_axioms = [], {}
    build = Path(report['object_search_path'])
    expected_objects = {str(build / (module + suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
    require({row['path'] for row in report['artifacts']} == expected_objects and len(report['artifacts']) == 6,
            'Recorded object inventory is not exactly the six fresh outputs')
    if not source_only:
        require({str(path) for path in local(str(build)).rglob('*') if path.is_file()}
                == {str(local(path)) for path in expected_objects}, 'Live build directory has unexpected outputs')
    for row, count in zip(report['modules'], COUNTS):
        module = row['module']
        stdout, stderr = local(row['stdout']['path']).read_text(), local(row['stderr']['path']).read_text()
        parsed, observed = parse_axioms(stdout + '\n' + stderr, report['required_prints'][module])
        require(not stderr, 'Nonempty stderr')
        require(parsed == row['axiom_audit']['reports'] and row['axiom_audit']['passed']
                and observed == row['observed_report_occurrences'] == count, 'Raw/recorded axiom census differs')
        require(row['status'] == 'passed' and row['exit_code'] == 0 and row['within_limits']
                and row['limit_exceeded'] is None and row['required_objects_present']
                and row['sampled_tree_and_wait4_peak_rss_kib'] <= 1048576, 'Module did not pass its exact policy')
        expected_command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true',
                            '-DElab.async=false', '-o', str(build / (module + '.olean')),
                            '-i', str(build / (module + '.ilean')), module + '.lean']
        require(row['command'] == expected_command, 'Actual compiler command differs')
        if module == 'CommonPayloadPadding':
            helper_axioms = parsed
            require(all(values == ['Quot.sound', 'propext'] for values in parsed.values()), 'Helper axiom profile differs')
        summaries.append({'module': module, 'status': row['status'], 'seconds': row['seconds'],
                          'peak_rss_kib': row['sampled_tree_and_wait4_peak_rss_kib'],
                          'required': count, 'observed': observed, 'accepted': observed,
                          'exit_code': row['exit_code'], 'limit_exceeded': row['limit_exceeded'],
                          'axiom_profiles': [{'axioms': list(profile), 'roots': amount} for profile, amount in
                                             sorted(Counter(tuple(values) for values in parsed.values()).items())]})
    require(report['peak_child_rss_kib'] == max(row['peak_rss_kib'] for row in summaries)
            and sum(row['seconds'] for row in summaries) <= report['seconds'], 'Aggregate measurements disagree')
    require(report['required_axiom_report_count'] == report['observed_axiom_report_count']
            == report['observed_unique_axiom_root_count'] == report['accepted_axiom_report_count'] == 239,
            'Complete root acceptance differs')
    require(report['all_selected_mathematical_sources_freshly_checked']
            and report['all_sources_snapshots_controls_runtime_unchanged']
            and report['complete_common_payload_padding_proof_checked'] and report['exact_build_artifact_inventory'],
            'Raw report does not record complete acceptance')
    for key in ['source_count_proved', 'n16_target_proved', 'producer_or_replayer_executed',
                'helper_producer_execution_correspondence_proved', 'integrated_project_modified']:
        require(report[key] is False, 'An unrelated mathematical or execution claim was asserted: ' + key)
    census = lambda rows: {'binding_occurrences': len(rows),
                          'distinct_recorded_file_identities': len({(r['path'], r['bytes'], r['sha256']) for r in rows})}
    inventory = json.loads((HERE / 'MATHEMATICAL-INVENTORY.json').read_text())
    require(inventory['ordered_axiom_roots'] == HELPER_ROOTS
            and inventory['source']['sha256'] == report['source_bindings'][-1]['sha256'], 'Helper contract inventory differs')
    return {
        'format': 'adwh-common-payload-padding-mathematical-results-v1',
        'audit_status': 'passed_source_payloads_only' if source_only else 'passed_live_saved_evidence',
        'authorship': 'Derived saved-result audit by the gate author; independent mathematical and gate reviews are separate.',
        'raw_report': binding(REPORT), 'recorded_gate_status': report['status'],
        'stage': report['stage'], 'source_fingerprint': source_fingerprint,
        'seconds': report['seconds'], 'peak_child_rss_kib': report['peak_child_rss_kib'],
        'required': 239, 'observed': 239, 'accepted': 239,
        'modules': summaries, 'source_bindings': manifest['sources'],
        'helper_axiom_reports': helper_axioms, 'helper_theorem_statements': inventory['theorems'],
        'direct_report_binding_census': census(direct), 'marker_binding_census': census(marker_rows),
        'distinct_recorded_bindings_verified': len(resolved),
        'distinct_current_files_read_for_recorded_bindings': len(set(resolved.values())),
        'snapshots_resolved_through_retained_canonical_bytes': aliases,
        'live_compiler_runtime_and_artifacts_verified': not source_only,
        'recorded_runtime_or_artifact_bindings_not_rechecked': len(skipped),
        'compiled_artifacts': report['artifacts'], 'exact_fresh_artifact_count': 6,
        'constraints': constraints, 'compiler_release': report['compiler_release'], 'compiler_commit': report['compiler_commit'],
        'current_control_count': 6, 'historical_reference_count': 8,
        'actual_baseline_report_bound_in_its_role': True,
        'baseline_provenance_defect_preserved_and_not_used_as_new_acceptance': True,
        'source_only_recovery': {'snapshot_count': 9, 'snapshot_bytes': sum(row['bytes'] for row in recovery),
            'snapshot_mappings': recovery, 'unique_superseded_inputs': 0, 'source_generator_needed': False,
            'retain_execution_marker_and_raw_report': True,
            'historical_references': [{key: row[key] for key in ('role', 'bytes', 'sha256')} |
                                      {'path': Path(row['path']).relative_to(old_root).as_posix()} for row in historical],
            'compiled_objects_and_runtime_may_be_omitted': True,
            'restore_does_not_authorize_reexecuting_historical_gate': True},
        'review_artifacts': [binding(HERE / name) for name in ['INDEPENDENT-MATH-REVIEW.md', 'GATE-REVIEW.md']],
        'scope': {'complete_reusable_padding_codec_proof_accepted': True,
                  'Python_unit_gate_outcome': 'Outside this mathematical report.',
                  'Python_producer_execution_correspondence_proved': False,
                  'numeric_count_rechecked_or_proved': False, 'n16_proved': False},
        'audit_activity': {'Lean_executed': False, 'compiler_or_checker_executed': False,
                           'generator_or_counter_executed': False, 'gate_rerun': False},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    parser.add_argument('--write', type=Path)
    args = parser.parse_args()
    result = audit(args.source_only)
    raw = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if args.write:
        args.write.write_text(raw)
    print(raw, end='')


if __name__ == '__main__':
    main()
