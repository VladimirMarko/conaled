# Saved ordinary-kernel result: common payload padding

## Outcome and reviewer scope

**The first complete attempt passed all 239 required theorem reports.** Its three selected mathematical modules were freshly checked with the ordinary pinned Lean 4.35.0 kernel in **7.89377424599661 seconds**, with an observed peak child RSS of **700,396 KiB**. The nine new universal padding/codec theorems each report exactly `propext` and `Quot.sound`; none reports `Classical.choice`, `sorryAx`, or a native-evaluation axiom.

This review independently reads the saved report, raw logs, marker, source/control snapshots, runtime bindings, and object inventory. The reviewer (`validity_contracts`) authored `CommonPayloadPadding.lean` and its mathematical design/inventory, so this is **not an independent authorship review of that helper**. `counting_route` supplied the separate pre-execution [independent mathematical source review](INDEPENDENT-MATH-REVIEW.md). `regression_audit` authored the gate and its own separate result summaries; the parent agent executed the gate. This reviewer ran no Lean compiler, proof checker, producer, replayer, test suite, or gate command while auditing the result.

The primary result is [complete-01/report.json](gate/attempts/complete-01/report.json), 89,999 bytes, SHA256 `292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8`. The accompanying [PROOF-RESULT-AUDIT.json](PROOF-RESULT-AUDIT.json) records the independent checks and evidence bindings.

## Actual mathematical acceptance

| Fresh module | Required / observed / accepted reports | Child elapsed seconds | Peak RSS, KiB |
| --- | ---: | ---: | ---: |
| `LegacyListClause` | 6 / 6 / 6 | 0.32945238299726043 | 493,312 |
| `ConsolidatedGeneric` | 224 / 224 / 224 | 7.099344482005108 | 700,396 |
| `CommonPayloadPadding` | 9 / 9 / 9 | 0.45582171300338814 | 505,468 |

All three processes exited zero, all stderr logs are empty, and no resource watchdog event is recorded. Independently parsing the complete stdout logs gives 239 distinct roots in the exact ordered lists required by the manifest and by their source `#print axioms` commands. The logs contain no remaining non-report output. The accepted counts therefore do not include any failed-module or error-recovery reports.

Across all 239 roots, 8 have no axioms, 18 have only `propext`, 134 have `propext` and `Quot.sound`, and 79 have the three permitted axioms `propext`, `Classical.choice`, and `Quot.sound`. Every raw axiom name is within the original three-name allowance.

All nine new roots are in namespace `ADWH.Experiments.Chapter15.CommonPayloadPadding`:

| Root | Proved contract |
| --- | --- |
| `wordAt_pad` | Appending common-width zero planes preserves every decoded row word. |
| `length_pad` | The padded length is the maximum of the common payload width and the input length; overlong inputs are preserved. |
| `added_field_zero` | The field above the original input length introduced by this padding decodes to zero. |
| `nodePlanes_at` | The four node slices decode as the full row word, under the explicit node-width bound. |
| `claimPlanes_at` | The five claim slices decode as the full row word, under the explicit claim-width bound. |
| `nodePlanes_pad_at` | Common-width padding provides the node-width bound for an arbitrary input list. |
| `claimPlanes_pad_at` | Common-width padding provides the claim-width bound for an arbitrary input list, including layouts with a wider node payload. |
| `node_reference` | Exact payload lookup and the width bound transport a node row to the table decoder. |
| `claim_reference` | Exact payload lookup, the width bound, and the retained dense key equality `wordAt keys i = N + j` transport a claim row to the table decoder. |

Each of these nine exact names occurs once in [CommonPayloadPadding.stdout.log](gate/attempts/complete-01/CommonPayloadPadding.stdout.log), with `[propext, Quot.sound]`. Their statement inventory agrees with the accepted helper source SHA256 `c809c9e1514615787b3eb3b335fd7cd4842e8db1f6d0884db05a23ece0a2cf08`. These statements quantify over natural widths, including zero, and over arbitrary row positions and payload-plane lists; they contain no board size or expected queen count.

## Source, runtime, and provenance checks

I verified all **47 direct binding occurrences / 45 distinct file identities** in the report and all **30 occurrences / 26 identities** in its separately read permanent marker. These counts traverse the saved JSON objects themselves, without treating every nested historical report as part of this new execution. All bytes and SHA256 identities match the available files.

The three source snapshots and six current-control snapshots are read-only and byte-identical to their recorded originals: **nine snapshots, 364,414 bytes**. The six controls are the runner, protocol, source manifest, manifest preparer, mathematical design, and mathematical inventory. Eight additional historical references are hash-bound in place. The marker contains the same source list, controls, attempt, stage, source manifest, and baseline identity as the report. Recomputing its source fingerprint from the stage and ordered module hashes gives `25fff9bbae333af326b14cfbd566ba6bf450dde5baa41ab80387a7574fe69b76`, exactly the fingerprint in the marker filename and report.

`LegacyListClause` and `ConsolidatedGeneric` are the exact accepted baseline-191 source bytes and ordered root lists. They were compiled afresh here. The new gate uses no prepared original-ADWH object pool and reuses no experimental compiled imports. The build directory contains exactly the three `.olean` and three `.ilean` artifacts recorded in the report, with no extra files. The compiled artifacts are verification evidence in the current workspace, not source-checkpoint retention inputs.

The compiler bytes match the pinned Lean **4.35.0**, commit `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`, and all five recorded shared runtime libraries match the pinned runtime reference. Each recorded child command has `-j1 -M1024`, `autoImplicit=false`, `warningAsError=true`, and `Elab.async=false`. The unchanged resource helper supplies one CPU and the shared cumulative 30-second deadline; the report's final elapsed and peak values remain below 30 seconds and 1,048,576 KiB. Default heartbeat and recursion settings remain in force.

The accepted baseline source report is explicitly bound as `accepted_baseline_source_report` with SHA256 `bc8d987a1a30a477212b06aacd42a6000fbe39fbdb34d2c557290704eb0944fa`. The older runtime comparison report is separately bound as `pinned_runtime_reference_report` with SHA256 `c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2`. Their roles, paths, and identities are distinct. The old baseline's generic-provenance recording defect remains disclosed through its retained addendum and audit; this run does not reuse its defective generic-report pointer. This is a single complete three-module proof gate, so it has no separate generic-to-full handoff to reconstruct.

## Meaning and limits of this result

This is a transferable proof of the Lean common-width padding and field-decoding contracts. It addresses the mathematical width boundary without inserting an expected count into the statement or manufacturing a new count fixture. It does not prove that arbitrary submitted high padding bits are zero: the zero-field theorem concerns the padding constructed by `pad`. Exact common-width length additionally requires that the input was not already longer than that width.

Python producer/replayer validation and the finite synthetic regression tests have separate source reviews and a separate bounded execution protocol. This gate proves no correspondence theorem for those Python executions. It also produces no complete larger-board trace, compression bound, new source-count certificate, or proof of `cqueens 16`. The integrated project is unchanged. The ordinary kernel, including its pinned native primitive implementation, remains the trust boundary; this result does not establish or adopt an optimized replacement kernel. The recorded timing is one acceptance observation for this universal proof closure, not a count-scaling or comparative performance result.
