# Bounded Python preservation and codec checks

This is one fixed root-run attempt for the already reviewed common-payload repair. It executes the two commands in `VERIFICATION-PLAN.md`; it does not execute a queen counter, a routing run, a retained generator or replay `main()`, or a large fixture. The twelve tests call only the six reviewed shape/scalar-codec entry points. The result is a finite implementation regression check, separate from the universal Lean field-semantics proof and any source-count certificate.

## Fixed inputs and command

From this directory, the root reviewer may run:

```sh
python3 -I run_python_checks.py --run
```

Without `--run`, the wrapper performs only read-only binding checks; it creates no attempt or marker and executes neither command. The author has prepared and syntax-inspected the wrapper but has executed neither mode.

The wrapper pins `PYTHON-INVENTORY.json`, `SOURCE-EDITS.json`, the independent Python source review/audit, and the exact existing resource helper `next-iteration/lean435-kernel-comparison/run_comparison.py` at SHA256 `2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0`. It verifies all ten inventory files, both original sources, the original/copied unchanged support source, and the inventory's three separate mathematical evidence bindings. Those seventeen inputs must match the independent audit's complete binding list. The review, audit, resource helper, this protocol and the wrapper bring the unique input count to twenty-two. The actual Python interpreter is additionally hash/size-bound and its version recorded; it is not copied.

All twenty-two files are copied byte-for-byte to read-only snapshots under `python-gate/attempts/tests-01/inputs/`, retaining their paths relative to `work/`. The commands execute from the snapshot's `next-iteration/common-payload-padding/` directory, so the inverse checker reads the frozen original sources and the tests import the frozen variants. The support source is retained for provenance and is not imported by the test module. No snapshot of an earlier successful Python result is used.

## One resource budget and one-use evidence

The wrapper obtains the same nonblocking `residual-dag/compile.lock` used by the proof gates. Before any child starts it reserves a read-only source-keyed marker under `python-gate/execution-markers/`. The key covers the five Python source/test/verifier files, excluding documentation and control metadata: editing a protocol cannot permit an unchanged test rerun. The fixed `tests-01` directory and the marker must both be absent. They remain after failure; this protocol offers no overwrite, reset or retry option.

The two child commands are, in order:

```sh
python3 -I verify_source_preservation.py
python3 -I tests/test_common_payload.py
```

The wrapper uses the bound interpreter's absolute path. Both children receive one selected CPU and share a single thirty-second deadline through the unchanged `h.child` helper. The helper samples aggregate descendant RSS, combines it with exit high-water RSS, and rejects more than 1,048,576 KiB. Its CPU/file/core safeguards remain unchanged; no address-space limit or larger allowance is introduced. Python runs in isolated mode. Python/Lean/Lake/comparator environment settings and loader injection variables are removed; numerical-library thread counts are one. The cumulative elapsed check starts immediately before the first child and includes both output audits and final identity checks. Input preparation/snapshot copying is recorded outside that execution interval, as in the existing proof gates. Children are serial, and a rejected first command prevents the second.

## Acceptance and retained report

Success requires zero exit status and resource compliance for both commands. The first stdout must be the exact expected inverse-audit JSON for both variants, the fixed edit-manifest hash, unchanged `main()` bodies and support sources, and no variant execution; its stderr must be empty. The second must emit no stdout, report each of the twelve inventory test names exactly once as `ok`, report `Ran 12 tests`, and finish with `OK`. Both original inputs and every read-only snapshot, the interpreter and the reserved marker are checked again after execution. A failed postcheck or cumulative budget breach rejects the attempt.

`python-gate/attempts/tests-01/report.json` retains the source identity, all input bindings and snapshot mappings, interpreter, marker, commands, separate stdout/stderr bindings, exit statuses, resource observations and output audits. The wrapper saves a report before execution and preserves a failed report on an exception. It does not rewrite any frozen source, inventory, review, earlier experiment or checkpoint. Passing these checks does not prove arbitrary Python correctness, a new instance's complete certificate, or `cqueens 16`.
