## Current source and saved evidence — checkpoint 207

This snapshot preserves every checkpoint 206 payload path and accepted
achievement. It adds the exact shared-selector timeout and its recoverable
source/control history, reviewed higher shared proofs, a reviewed computed
query interface, the finite restricted-lookup assessment, and prepared
source-cost revisions. Higher counting/guard proofs remain uncompiled and
the stock numeral theorem remains open.

The shared-selector complete-01 gate failed at 30.211182990009547 seconds with
zero of 78 roots accepted. Its used source-policy key is permanent. The
38-report buffered prefix cannot identify a slow theorem or prove that later
diagnostics were absent. Both pre-execution control corrections, the failed
first preflight, successful corrected preflight and the actual one-time build
are retained with distinct evidence. An unchanged source-key retry is not
permitted after restoration.

The new count-query recognizer computes its answer without an expected-answer
parameter and checks the full input expression. Its conditional reducer-run
proof and cache premise remain source-only; no actual checker hook or installed
recognition has been accepted. The finite lookup proposal uses exactly twenty
names, checks internal record names, and transports guard evidence to the true
prefix. Never use the restricted FEnv's underlying full Env as that prefix,
and never substitute the finite inspection environment in the reducer theorem.

After extraction, audit the new saved failure without rerunning mathematics:

```sh
python3 -I next-iteration/kernel-shared-selector-bundle/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-selector-bundle/audit_saved_result.py --source-only
python3 -I next-iteration/kernel-bundled-reference/audit_saved_result.py --source-only
```

The first checks 103 source/control bindings, 18 canonical snapshot mappings,
all four logs, six actual artifact identities and both control-correction
inverse chains. Source-only mode explicitly permits omitted objects/runtime;
all retained-file identities remain mandatory. Root already inspected and ran
the first auditor in live and source-only modes before publication.

Use KernelCountLoop instead of the original KernelCountInduction in a future
higher closure; their internal namespaces overlap. The higher shared variant
has exact predecessor maps and independent review. The separate shared
operational-lemma candidate preserves every original statement/visibility and
adds eight audited public aliases; it would raise the preceding selector
layout to 86 reports. The optional PropWhen proof slice is retained as an
uncompiled source candidate, with all computational declarations unchanged
and a separate warning about its fifteen omitted simp registrations. A new
physical source assembly and complete fresh gate are required.

Checkpoint 206's actual saved-copy and clean-restoration receipts are included.
No earlier ZIP is needed. The wrapper's three historical toolchain API-source
references have canonical recovery mappings in its SOURCE-INPUT-RECOVERY.json.
Compiler/runtime binaries, compiled proofs and complete upstream metatheory
builds remain omitted and must be restored from the pinned sources. Broader
checker proof closures need their real dependencies; the finite guard and
existential cache premise do not by themselves establish complete checker
acceptance or the old driver's fixed-fuel success.
