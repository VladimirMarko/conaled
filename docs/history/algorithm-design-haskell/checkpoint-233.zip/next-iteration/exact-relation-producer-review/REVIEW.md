# Independent static review of the exact-relation producer

**Conclusion: no blocking correctness or metering defect found in the reviewed
producer.** This is an executable-source review, not an execution result. The
independent replayer and bounded runner still require their own final review
before the single authorized experiment.

Reviewed producer: `exact-relation-diagnostic/diagnostics/produce_relations.py`,
40,852 bytes, SHA256
`5c5ba4f6d8a87f9931f6da9fe2d64ff3598aaf1c0c9d7dc3637678efbe817029`.
Reviewed protocol: SHA256
`28a28da0c949dd05947a8dc8b6dff9f4b30ae92399775f489e45c5fc40177147`.
The fixed design and schema identities are recorded in `review.json`.

## Findings

1. **Requests precede semantic work.** `Meter.begin` checks the unchanged
   50,000-start cap before allocating or writing another ticket. Arithmetic,
   pivot tests, source validation, view restriction, term comparison, digest
   lookup and cache comparisons occur after their corresponding start. Raw
   input indexing, completed-reference retrieval to construct request fields,
   serialization and fixed control indices do not evaluate functions or hide
   candidate algebra. The imports are standard-library utilities; no fraction,
   symbolic algebra, evaluator or matrix library supplies an unrecorded result.

2. **The RREF schedule preserves exact origins.** The first nonzero unused row
   is selected in ascending order. Each row swap has all 35 cell children. The
   original pivot reference is captured after the swap and remains the divisor
   while the pivot row changes. Each target row's elimination factor is copied
   into its completed probe, so later updates cannot accidentally read a zeroed
   pivot-column cell. Every column update uses the current target and pivot
   references. Final checks cover all 665 cells and require the fixed 19-pivot,
   16-free-column shape.

3. **Rational and candidate arithmetic is exact.** The shortcut priorities
   match the protocol. Nontrivial normalization records sign changes, every
   Euclidean step and both exact divisions. Divisors are positive when used by
   `divmod`. Each denominator product has exactly 19 scalar multiplications;
   every candidate entry is separately charged, and all 16 proposals are
   completed before validating or checking any guarded function. A later
   refutation cannot change the frozen batch or add a new sample.

4. **Original guarded semantics is checked locally.** Selected descriptors
   have unique definitions, prior children, strictly increasing branch
   variables, bounded/disjoint guards and no guard/core support overlap.
   Actual Nat constants are used; source `maximum` fields are ignored. Node0
   is checked as constant zero. Selected views are bound to their complete
   positive-mask/negative-mask/core triples and their derived support lies in
   the fixed Y set. Cofactors satisfy or contradict guard literals, retain an
   absent-variable view, or select the actual original branch child. Merged
   guards retain contradictions and derive bare support from the referenced
   child's checked flat form without an implicit new-core validation read.

5. **Signed occurrences and arbitrary coefficients are preserved.** Each
   occurrence receives a term-add request. Lexicographic comparisons operate
   on complete views and are separately charged. Equal views add the existing
   coefficient to the incoming coefficient using exact integer arithmetic;
   only a resulting zero is removed. Canonical zero views and zero
   coefficients have explicit shortcut requests. Every parent occurrence is
   cofactored before child collection. This is a Boolean case split, so an
   absent variable is not multiplied by two.

6. **Cache reuse and proof completion are well founded.** SHA256 selects only
   a bucket. Every inspected entry has a cache-candidate request and every
   compared term has a cache-term request, including misses and collisions.
   Only completed new zero states enter the bucket. A hit returns its existing
   proof ID, without publishing an alias. New proof IDs are assigned in
   completion order; both child occurrences precede a split parent. Refuted or
   pending states are never reusable zero facts.

7. **Zero and refutation outcomes have the required meanings.** Empty derived
   support permits only checked constant values, whose signed products and
   running sums are explicit requests. Zero needs the exact sum zero or two
   completed zero branches. A nonzero terminal starts with assignment0; each
   recorded lift sets or clears its original variable bit while preserving the
   nonzero integer value. The opposite branch may be omitted only after a
   refutation. These paths refute individual candidates and do not establish a
   full-rank conclusion if every chosen candidate fails.

8. **The cap and footer retain unfinished work.** Starts and completions are
   counted separately; only the top frame can finish, and dependencies must
   already be complete. Nested child completions follow explicit references
   with duplicates preserved. A cap is raised before ticket50001 and retains
   the exact unfinished stack. Validation cache decisions and resolved state
   lookup decisions follow the specified timing. Rational/coefficient/terminal
   maxima and zero-cache size are updated from completed results. Resource
   interruption can leave no footer; such bytes must remain failure evidence,
   not an accepted complete diagnostic.

## Scope and limitations

No producer, replayer, counter, evaluator, candidate algebra, source traversal
or Lean compiler was executed or imported for this review. The review used
source reads, text searches and byte hashes only. No selected or frozen file
was modified, and no additional fixture was created. The new review directory
is outside checkpoint176's fixed selection.

The sample matrix supplies proposals, never a premise for a global identity.
Even a later accepted diagnostic would not itself be a Lean relation theorem,
an exact rank theorem, a new queens count or an n16 result. Runtime acceptance
and the trust transfer to Lean remain separate obligations.
