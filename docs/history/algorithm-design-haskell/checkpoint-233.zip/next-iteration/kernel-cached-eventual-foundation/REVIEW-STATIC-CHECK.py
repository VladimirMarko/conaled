#!/usr/bin/env python3
"""Independent root source/JSON checks; never import a gate or execute Lean."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((HERE / name).read_text())

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

recovery = json.loads((ROOT / 'next-iteration/kernel-cached-eventual-owner-slice/EXTERNAL-CONTEXT-RECOVERY.json').read_text())
aliases = {tuple(r['original_context'][k] for k in ('path', 'bytes', 'sha256')): r['retained_copy'] for r in recovery['mappings']}
assert len(aliases) == 6

def checked(row):
    if Path(row['path']).is_absolute() or '..' in Path(row['path']).parts:
        row = aliases[tuple(row[k] for k in ('path', 'bytes', 'sha256'))]
    path = ROOT / row['path']
    assert path.resolve().is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert (len(data), sha(data)) == (row['bytes'], row['sha256']), row['path']
    return data

def mask(data):
    text = data.decode()
    output = []
    pos = 0
    while pos < len(text):
        if text.startswith('--', pos):
            end = text.find('\n', pos)
            if end < 0:
                end = len(text)
            output.extend(' ' * (end-pos)); pos = end
        elif text.startswith('/-', pos):
            end = pos+2; depth = 1
            while depth:
                assert end < len(text)
                if text.startswith('/-', end): depth += 1; end += 2
                elif text.startswith('-/', end): depth -= 1; end += 2
                else: end += 1
            output.extend('\n' if c == '\n' else ' ' for c in text[pos:end]); pos = end
        elif text[pos] == '"':
            end = pos+1
            while end < len(text):
                if text[end] == '\\': end += 2
                elif text[end] == '"': end += 1; break
                else: end += 1
            else: raise AssertionError('unclosed string')
            output.extend('\n' if c == '\n' else ' ' for c in text[pos:end]); pos = end
        else:
            output.append(text[pos]); pos += 1
    return ''.join(output)

def census(data):
    code = mask(data)
    namespace = None
    roots = []
    blocks = []
    private = []
    declarations = []
    imports = []
    for number, line in enumerate(code.splitlines(), 1):
        line = line.strip()
        if line.startswith('namespace '):
            assert namespace is None
            namespace = line.split()[1]
            blocks.append((namespace, number))
        elif line.startswith('end '):
            assert line.split()[1] == namespace
            namespace = None
        elif line.startswith('open '):
            assert namespace is not None
        elif line.startswith('import '):
            assert namespace is None
            imports.append(line.split()[1])
        elif line.startswith('set_option '):
            assert line in ('set_option autoImplicit false', 'set_option warningAsError true', 'set_option Elab.async false')
        elif line.startswith('#print axioms '):
            assert namespace is not None
            roots.append(namespace + '.' + line.split()[2])
        decl = re.match(r'(private )?(def|abbrev|theorem|structure|inductive)\s+(\S+)', line)
        if decl:
            assert namespace is not None
            declarations.append((namespace + '.' + decl[3], decl[2], bool(decl[1])))
            if decl[1]: private.append((namespace, decl[3]))
    assert namespace is None
    assert not re.search(r'(?m)^\s*(attribute|instance|local|scoped|syntax|macro|elab|notation|infix\w*|initialize)\b|@\[', code)
    assert not re.search(r'\b(sorry|admit|axiom|unsafe|partial|native_decide)\b|_private\.|\._(?:proof|match|aux)\b', code)
    return {'roots': roots, 'blocks': blocks, 'private': private, 'declarations': declarations, 'imports': imports}

inventory = read('SOURCE-INVENTORY.json')
assert inventory['input_count'] == len(inventory['inputs']) == len({r['path'] for r in inventory['inputs']}) == 916
for row in inventory['inputs']:
    assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
    checked(row)
candidate = checked(inventory['source'])
assert (len(candidate), sha(candidate)) == (119150, 'b88b25aa807de203419c1d50b860b08950f44de8e5bf03172a91e132c162ccd5')
mapping = read('SOURCE-CORRESPONDENCE.json')
assert mapping['candidate'] == inventory['source']
assert len(mapping['origins']) == mapping['origin_count'] == 7
assembled = mapping['header_literal'].encode()
assert mask(assembled).strip() == ''
headers = []
root_sequence = []
decl_sequence = []
source_rows = []
edits = complements = 0
seen_modules = {'KernelCachedForward'}
for number, row in enumerate(mapping['origins'], 1):
    assert number == row['order']
    old = checked(row['source'])
    old_census = census(old)
    assert all(name in seen_modules for name in old_census['imports'])
    seen_modules.add(row['origin_module'])
    transformed = bytearray(old)
    for edit in reversed(row['edits']):
        a, b = edit['original_start'], edit['original_end']
        assert old[a:b] == edit['before'].encode()
        assert re.fullmatch(r'import \w+\n', edit['before'])
        assert edit['after'] == '-- [assembly import internalized] ' + edit['before']
        transformed[a:b] = edit['after'].encode()
    transformed = bytes(transformed)
    assert (len(transformed), sha(transformed)) == (row['transformed_bytes'], row['transformed_sha256'])
    assert candidate[row['physical_body_start']:row['physical_body_end']] == transformed
    inverse = bytearray(transformed)
    for edit in reversed(row['edits']):
        a, b = edit['transformed_start'], edit['transformed_end']
        assert transformed[a:b] == edit['after'].encode()
        assert (edit['physical_start'], edit['physical_end']) == (row['physical_body_start']+a, row['physical_body_start']+b)
        inverse[a:b] = edit['before'].encode()
    assert inverse == old
    partition = [(e['original_start'], e['original_end'], e['transformed_start'], e['transformed_end']) for e in row['edits']]
    for comp in row['unchanged_complements']:
        spans = []
        for key, data in [('original', old), ('transformed', transformed)]:
            s = comp[key]; a,b = s['byte_start'],s['byte_end']; value = data[a:b]
            assert 0 <= a <= b <= len(data)
            assert (len(value),sha(value)) == (s['bytes'],s['sha256'])
            assert s['line_start'] == data[:a].count(b'\n')+1
            assert s['line_end'] == data[:b].count(b'\n')+(0 if b and data[b-1:b] == b'\n' else 1)
            spans.append(value)
        assert spans[0] == spans[1]
        o,t = comp['original'],comp['transformed']
        assert (comp['physical_start'],comp['physical_end']) == (row['physical_body_start']+t['byte_start'],row['physical_body_start']+t['byte_end'])
        partition.append((o['byte_start'],o['byte_end'],t['byte_start'],t['byte_end']))
    cursor = other = 0
    for a,b,c,d in sorted(partition):
        assert (a,c) == (cursor,other)
        cursor,other = b,d
    assert (cursor,other) == (len(old),len(transformed))
    assert row['edit_count'] == len(row['edits'])
    assert row['unchanged_complement_count_including_empty_header_spans'] == len(row['unchanged_complements'])
    for key in ['start_marker','end_marker']:
        assert mask(row[key].encode()).strip() == ''
    assembled += row['start_marker'].encode()
    assert len(assembled) == row['physical_body_start']
    assembled += transformed + row['end_marker'].encode()
    source_rows.append((row['origin_module'],old,old_census))
    headers += re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',old)
    root_sequence += old_census['roots']
    decl_sequence += old_census['declarations']
    edits += len(row['edits']); complements += len(row['unchanged_complements'])
assert assembled == candidate and edits == 9 and complements == 16
assert re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',candidate) == headers and len(headers) == 131
whole = census(candidate)
assert whole['roots'] == root_sequence and len(root_sequence) == len(set(root_sequence)) == 126
assert whole['declarations'] == decl_sequence and whole['imports'] == ['KernelCachedForward']
assert len(whole['blocks']) == 8 and len(whole['private']) == 5
for origin, data, c in source_rows:
    for namespace, name in c['private']:
        for other, other_data, _ in source_rows:
            if other != origin:
                assert not re.search(r'(?<![\w.])'+re.escape(name)+r'(?![\w.])',mask(other_data))

scope_metadata = read('PRIVATE-AND-SCOPE-AUDIT.json')
assert len(scope_metadata['origin_censuses']) == 7
for (name, data, c), declared in zip(source_rows,scope_metadata['origin_censuses']):
    assert declared['origin_module'] == name
    assert declared['ordered_report_roots'] == c['roots']
    assert [(x['name'],x['kind'],x['private']) for x in declared['explicit_named_declaration_headers']] == c['declarations']
    assert [(x['namespace'],x['start_line']) for x in declared['namespace_blocks']] == c['blocks']
    code = mask(data).splitlines(); literal = data.decode().splitlines()
    for p in declared['explicit_private_theorems']:
        uses = [{'line':n,'literal_line':literal[n-1]} for n,line in enumerate(code,1) if re.search(r'(?<![\w.])'+re.escape(p['local_source_spelling'])+r'(?![\w.])',line)]
        assert p['all_same_origin_uses'] == uses

scopes = read('INGREDIENT-REVIEW-SCOPES.json')
counts = []
assert scopes['ingredient_scope_count'] == len(scopes['scopes']) == 6
for row in scopes['scopes']:
    for key in ('author_inventory','independent_audit','independent_review'):
        checked(row[key])
    sizes = []
    for document, metadata in [('author_inventory','unchanged_author_array'),('independent_audit','unchanged_review_array')]:
        rec = row[metadata]
        inputs = json.loads(checked(row[document]))[rec['field']]
        assert (len(inputs),sha(canonical(inputs))) == (rec['count'],rec['canonical_json_sha256'])
        for item in inputs: checked(item)
        sizes.append(len(inputs))
    counts.append({'scope':row['name'],'original_author_and_review_counts':sizes})
assert [r['original_author_and_review_counts'] for r in counts] == [[514,517],[405,409],[420,421],[576,581],[59,60],[911,912]]

selected = read('SOURCE-CENSUS.json')
assert selected['selected_physical_sources'] == inventory['selected_physical_sources']
assert [r['module'] for r in selected['physical_modules']] == ['KernelCompactCore','KernelCachedForward','KernelCachedEventualFoundation']
roots = []; total = 0; seen = set()
for row in selected['physical_modules']:
    data = checked(row['source']); total += len(data)
    imports = re.findall(r'^import (\S+)',data.decode(),re.M)
    assert imports == row['imports']
    assert all(name in seen or name.startswith(('Init.','Std.')) for name in imports)
    seen.add(row['module'])
    actual = re.findall(r'^#print axioms (\S+)',data.decode(),re.M)
    expected = row['ordered_report_roots']
    assert [name.rsplit('.',1)[-1] for name in actual] == [name.rsplit('.',1)[-1] for name in expected]
    assert len(actual) == row['ordered_report_count']
    roots += expected
assert len(roots) == len(set(roots)) == selected['ordered_report_count'] == 134
assert total == selected['source_bytes'] == 530531
assert selected['default_ordinary_output_count'] == 6
assert sum(len(data) for _,data,_ in source_rows) == selected['pre_assembly_proof_origin_bytes'] == 117832

result = {'status':'passed_source_only_exact_assembly','author_inputs_verified':916,'direct_review_inputs':917,'physical_owners':3,'source_bytes':530531,'ordinary_outputs':6,'ordered_distinct_reports':134,'proof_origin_count':7,'import_comment_edits':9,'complete_inverse_origin_reconstructions':7,'unchanged_complements_including_empty':16,'literal_theorem_headers':131,'literal_proof_reports':126,'namespace_blocks_closed_within_origins':8,'private_helpers_local_to_origins':5,'separate_ingredient_scopes':counts,'exact_external_context_routes':6,'Core_and_Cached_sources_changed':False,'old_acceptance_transferred':False,'compiler_preflight_gate_mathematical_generator_or_saved_reader_executed':False}
(HERE/'REVIEW-STATIC-RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
