#!/usr/bin/env python3
"""Static exact-source assembly only; no Lean or mathematical execution."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent

ORIGINS = [
    ('KernelCachedMemoRelation', 'kernel-cached-memo-relation/source/KernelCachedMemoRelation.lean', 16),
    ('KernelCachedEventualEmpty', 'kernel-cached-eventual-empty/source/KernelCachedEventualEmpty.lean', 8),
    ('KernelCachedEventualAtoms', 'kernel-cached-eventual-empty/source/KernelCachedEventualAtoms.lean', 9),
    ('KernelCachedHelperContract', 'kernel-cached-eventual-helpers/source/KernelCachedHelperContract.lean', 37),
    ('KernelCachedEventualHelpers', 'kernel-cached-eventual-helpers/source/KernelCachedEventualHelpers.lean', 14),
    ('KernelCachedLiteralContract', 'kernel-cached-literal-contract/source/KernelCachedLiteralContract.lean', 1),
    ('KernelCachedEventualRecordWrapper', 'kernel-cached-eventual-record-wrapper/source/KernelCachedEventualRecordWrapper.lean', 41),
]
SCOPES = [
    ('ReducedOwners', 'kernel-cached-eventual-owner-slice'),
    ('GenericMemo', 'kernel-cached-memo-relation'),
    ('EventualEmptyAtoms', 'kernel-cached-eventual-empty'),
    ('EventualHelpers', 'kernel-cached-eventual-helpers'),
    ('LiteralContract', 'kernel-cached-literal-contract'),
    ('EventualRecordWrapper', 'kernel-cached-eventual-record-wrapper'),
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': digest(data)}

def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def write_json(name, value):
    path = HERE / name
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return identity(path)

def mask_comments_and_strings(text):
    result = list(text)
    index = 0
    depth = 0
    line_comment = False
    string = False
    escape = False
    while index < len(text):
        char = text[index]
        pair = text[index:index + 2]
        if line_comment:
            if char == '\n':
                line_comment = False
            else:
                result[index] = ' '
        elif depth:
            if pair == '/-':
                result[index:index + 2] = [' ', ' ']
                depth += 1
                index += 1
            elif pair == '-/':
                result[index:index + 2] = [' ', ' ']
                depth -= 1
                index += 1
            elif char != '\n':
                result[index] = ' '
        elif string:
            if char != '\n':
                result[index] = ' '
            if escape:
                escape = False
            elif char == '\\':
                escape = True
            elif char == '"':
                string = False
        elif pair == '--':
            result[index:index + 2] = [' ', ' ']
            line_comment = True
            index += 1
        elif pair == '/-':
            result[index:index + 2] = [' ', ' ']
            depth = 1
            index += 1
        elif char == '"':
            result[index] = ' '
            string = True
        index += 1
    assert depth == 0 and not string
    return ''.join(result)

def proof_census(data):
    text = data.decode()
    code = mask_comments_and_strings(text)
    namespace = None
    namespaces = []
    roots = []
    private = []
    declarations = []
    imports = []
    options = []
    for line, statement in enumerate(code.splitlines(), 1):
        raw = text.splitlines()[line - 1]
        found = re.fullmatch(r'namespace (\S+)', statement.strip())
        if found:
            assert namespace is None
            namespace = found.group(1)
            namespaces.append({'namespace': namespace, 'start_line': line})
        found = re.fullmatch(r'end (\S+)', statement.strip())
        if found:
            assert found.group(1) == namespace
            namespaces[-1]['end_line'] = line
            namespace = None
        found = re.match(r'^#print axioms (\S+)', statement)
        if found:
            assert namespace is not None
            roots.append(namespace + '.' + found.group(1))
        found = re.match(r'^(private )?(def|abbrev|theorem|structure|inductive)\s+(\S+)', statement)
        if found:
            assert namespace is not None
            name = found.group(3)
            record = {'line': line, 'kind': found.group(2), 'name': namespace + '.' + name,
                      'private': bool(found.group(1)), 'literal_line': raw}
            declarations.append(record)
            if found.group(1):
                uses = [{'line': n, 'literal_line': original} for n, (c, original) in
                        enumerate(zip(code.splitlines(), text.splitlines()), 1)
                        if re.search(r'(?<![\w.])' + re.escape(name) + r'(?![\w.])', c)]
                private.append({**record, 'local_source_spelling': name, 'all_same_origin_uses': uses})
        if statement.startswith('import '):
            imports.append({'line': line, 'module': statement.split()[1]})
        if statement.startswith('set_option '):
            options.append({'line': line, 'text': raw})
    assert namespace is None
    assert not re.search(r'(?m)^\s*(?:attribute|instance|local|scoped|syntax|macro|elab|notation|infix\w*|initialize)\b|@\[', code)
    assert not re.search(r'_private\.|\._(?:proof|match|aux)\b', code)
    assert all(row['text'] in ['set_option autoImplicit false',
                              'set_option warningAsError true',
                              'set_option Elab.async false'] for row in options)
    headers = re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', data)
    return {'imports': imports, 'namespace_blocks': namespaces, 'ordered_report_roots': roots,
            'ordered_report_count': len(roots), 'explicit_named_declaration_headers': declarations,
            'explicit_theorem_header_count': len(headers),
            'explicit_private_theorems': private, 'options': options,
            'explicit_attributes_instances_syntax_or_notation': [],
            'explicit_generated_name_references': [],
            'theorem_header_sequence_bytes': sum(map(len, headers)),
            'theorem_header_sequence_sha256': digest(b'\0'.join(headers))}

def span(data, start, end):
    return {'byte_start': start, 'byte_end': end, 'bytes': end - start,
            'sha256': digest(data[start:end]),
            'line_start': data[:start].count(b'\n') + 1,
            'line_end': data[:end].count(b'\n') + (0 if end and data[end - 1:end] == b'\n' else 1)}

HEADER = (b'/-\nExact physical assembly of seven frozen eventual cached proof origins.\n'
          b'Only the recorded header imports are internalized. Core and Cached remain separate.\n'
          b'All source bodies, namespaces, strict options and 126 reports are preserved.\n-/\n\n')
physical = HEADER
segments = []
scope_rows = []
all_roots = []
all_headers = []
total_edits = 0
all_original_data = []
for order, (module, relative, expected_reports) in enumerate(ORIGINS, 1):
    path = ROOT / 'next-iteration' / relative
    original = path.read_bytes()
    assert original.endswith(b'\n')
    all_original_data.append((module, original))
    census = proof_census(original)
    assert census['ordered_report_count'] == expected_reports
    start_marker = f'/- BEGIN EXACT ORIGIN {order}: {module} -/\n'.encode()
    end_marker = f'/- END EXACT ORIGIN {order}: {module} -/\n\n'.encode()
    physical += start_marker
    physical_start = len(physical)
    matches = list(re.finditer(rb'(?m)^import [^\n]+\n', original))
    edits = []
    if order != 1:
        for match in matches:
            before = match.group()
            after = b'-- [assembly import internalized] ' + before
            edits.append({'original_start': match.start(), 'original_end': match.end(),
                          'before': before.decode(), 'after': after.decode()})
    else:
        assert [m.group() for m in matches] == [b'import KernelCachedForward\n']
    transformed = original
    for edit in reversed(edits):
        transformed = (transformed[:edit['original_start']] + edit['after'].encode() +
                       transformed[edit['original_end']:])
    inverse = transformed
    shift = 0
    complements = []
    previous_original = 0
    previous_transformed = 0
    for edit in edits:
        edit['transformed_start'] = edit['original_start'] + shift
        edit['transformed_end'] = edit['transformed_start'] + len(edit['after'].encode())
        edit['physical_start'] = physical_start + edit['transformed_start']
        edit['physical_end'] = physical_start + edit['transformed_end']
        assert original[previous_original:edit['original_start']] == transformed[previous_transformed:edit['transformed_start']]
        complements.append({'original': span(original, previous_original, edit['original_start']),
                            'transformed': span(transformed, previous_transformed, edit['transformed_start']),
                            'physical_start': physical_start + previous_transformed,
                            'physical_end': physical_start + edit['transformed_start']})
        shift += len(edit['after'].encode()) - len(edit['before'].encode())
        previous_original = edit['original_end']
        previous_transformed = edit['transformed_end']
    assert original[previous_original:] == transformed[previous_transformed:]
    complements.append({'original': span(original, previous_original, len(original)),
                        'transformed': span(transformed, previous_transformed, len(transformed)),
                        'physical_start': physical_start + previous_transformed,
                        'physical_end': physical_start + len(transformed)})
    for edit in reversed(edits):
        assert inverse[edit['transformed_start']:edit['transformed_end']] == edit['after'].encode()
        inverse = inverse[:edit['transformed_start']] + edit['before'].encode() + inverse[edit['transformed_end']:]
    assert inverse == original
    assert re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', transformed) == re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', original)
    transformed_census = proof_census(transformed)
    assert transformed_census['ordered_report_roots'] == census['ordered_report_roots']
    physical += transformed + end_marker
    segments.append({'order': order, 'origin_module': module, 'source': identity(path),
                     'start_marker': start_marker.decode(), 'end_marker': end_marker.decode(),
                     'physical_body_start': physical_start, 'physical_body_end': physical_start + len(transformed),
                     'transformed_bytes': len(transformed), 'transformed_sha256': digest(transformed),
                     'edits': edits, 'edit_count': len(edits),
                     'unchanged_complements': complements,
                     'unchanged_complement_count_including_empty_header_spans': len(complements),
                     'inverse_reconstructs_complete_original': True})
    scope_rows.append({'origin_module': module, 'source': identity(path), **census})
    total_edits += len(edits)
    all_roots.extend(census['ordered_report_roots'])
    all_headers.extend(re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', original))

assert total_edits == 9 and len(all_roots) == 126 and len(set(all_roots)) == 126
assert len(all_headers) == 131
assert re.findall(rb'(?m)^import [^\n]+', physical) == [b'import KernelCachedForward']
assert re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=', physical) == all_headers
assert proof_census(physical)['ordered_report_roots'] == all_roots
for row in scope_rows:
    for private in row['explicit_private_theorems']:
        name = private['local_source_spelling']
        for module, data in all_original_data:
            if module != row['origin_module']:
                assert not re.search(r'(?<![\w.])' + re.escape(name) + r'(?![\w.])', mask_comments_and_strings(data.decode()))

source_path = HERE / 'source' / 'KernelCachedEventualFoundation.lean'
source_path.parent.mkdir(parents=True, exist_ok=True)
source_path.write_bytes(physical)
candidate = identity(source_path)
correspondence = write_json('SOURCE-CORRESPONDENCE.json', {
    'format': 'adwh-exact-eventual-foundation-assembly-v1', 'candidate': candidate,
    'header_literal': HEADER.decode(), 'origins': segments, 'origin_count': 7,
    'header_import_edit_count': 9, 'origin_boundary_comment_count': 14,
    'unchanged_complement_count_including_empty_header_spans': sum(len(s['unchanged_complements']) for s in segments),
    'source_bodies_statements_options_namespace_boundaries_and_reports_literal': True,
    'complete_forward_and_inverse_reconstruction_verified': True,
    'new_mathematical_declarations_or_proofs': False,
    'current_Core_and_Cached_changed': False})
private_scope = write_json('PRIVATE-AND-SCOPE-AUDIT.json', {
    'format': 'adwh-eventual-foundation-static-scope-census-v1', 'candidate': candidate,
    'origin_censuses': scope_rows, 'namespace_block_count': sum(len(s['namespace_blocks']) for s in scope_rows),
    'explicit_private_theorem_count': sum(len(s['explicit_private_theorems']) for s in scope_rows),
    'private_spelling_used_across_origin_boundary': False,
    'physical_module_change_can_change_generated_private_and_auxiliary_names': True,
    'explicit_generated_private_or_auxiliary_names_in_source': False,
    'public_theorem_header_count': 126, 'all_explicit_theorem_header_count': 131,
    'exact_public_report_count': 126, 'exhaustive_compiler_generated_declaration_census_claimed': False})

owner_base = ROOT / 'next-iteration/kernel-cached-eventual-owner-slice'
owner_census = json.loads((owner_base / 'SOURCE-CENSUS.json').read_text())
physical_rows = owner_census['physical_modules'][:2] + [{
    'module': 'KernelCachedEventualFoundation', 'source': candidate,
    'imports': ['KernelCachedForward'], 'ordered_report_count': 126,
    'ordered_report_roots': all_roots}]
all_complete_roots = sum([r['ordered_report_roots'] for r in physical_rows], [])
assert len(all_complete_roots) == len(set(all_complete_roots)) == 134
logical_origins = owner_census['current_logical_origins'][:-1] + [r[0] for r in ORIGINS]
census_id = write_json('SOURCE-CENSUS.json', {
    'format': 'adwh-eventual-foundation-source-census-v1',
    'physical_modules': physical_rows, 'physical_owner_count': 3,
    'selected_physical_sources': [r['source'] for r in physical_rows],
    'ordered_report_counts': [2, 6, 126], 'ordered_report_count': 134,
    'distinct_report_count': 134, 'default_ordinary_output_count': 6,
    'source_bytes': sum(r['source']['bytes'] for r in physical_rows),
    'pre_assembly_proof_origin_bytes': sum(len(x[1]) for x in all_original_data),
    'logical_origins': logical_origins, 'distinct_upstream_origin_count': 16,
    'distinct_current_project_source_origin_count': 8, 'distinct_current_source_origin_count': 24,
    'source_segment_count': 26,
    'origin_convention': 'Current project source origins count HelperContract as one source; its two canonical source ancestors remain mapped in its frozen correspondence.',
    'unbundled_prospective_owner_count': 9, 'unbundled_prospective_ordinary_output_count': 18,
    'exhaustive_Core_named_declaration_count_claimed_here': False,
    'root_Core_392_to_340_census_qualification_preserved_in_original_review': True,
    'mathematical_headers_or_bodies_changed': False,
    'compiled_or_resource_fit_claimed': False})

recovery_path = owner_base / 'EXTERNAL-CONTEXT-RECOVERY.json'
recovery = json.loads(recovery_path.read_text())
recoveries = {(r['original_context']['path'], r['original_context']['bytes'], r['original_context']['sha256']): r['retained_copy'] for r in recovery['mappings']}
input_map = {}

def bind(record):
    key = (record['path'], record['bytes'], record['sha256'])
    chosen = recoveries.get(key, record)
    assert not Path(chosen['path']).is_absolute() and '..' not in Path(chosen['path']).parts
    path = ROOT / chosen['path']
    assert identity(path) == chosen, str(chosen)
    if chosen['path'] in input_map:
        assert input_map[chosen['path']] == chosen
    input_map[chosen['path']] = chosen

def bind_path(path):
    row = identity(path)
    bind(row)
    return row

review_scopes = []
for label, dirname in SCOPES:
    base = ROOT / 'next-iteration' / dirname
    inv_path = base / 'SOURCE-INVENTORY.json'
    audit_path = base / 'SOURCE-AUDIT.json'
    review_path = base / 'SOURCE-REVIEW.md'
    inv = json.loads(inv_path.read_text())
    audit = json.loads(audit_path.read_text())
    for document in (inv, audit):
        for item in document['inputs']:
            bind(item)
    review_scopes.append({
        'name': label, 'author_inventory': bind_path(inv_path),
        'independent_audit': bind_path(audit_path), 'independent_review': bind_path(review_path),
        'unchanged_author_array': {'field': 'inputs', 'count': len(inv['inputs']),
            'canonical_json_sha256': digest(canonical(inv['inputs']))},
        'unchanged_review_array': {'field': 'inputs', 'count': len(audit['inputs']),
            'canonical_json_sha256': digest(canonical(audit['inputs']))},
        'original_scope_or_selection_rebased': False})
scopes_id = write_json('INGREDIENT-REVIEW-SCOPES.json', {
    'format': 'adwh-eventual-foundation-independent-ingredient-scopes-v1',
    'ingredient_scope_count': 6, 'scopes': review_scopes,
    'new_assembly_independent_review_status': 'pending',
    'historical_nested_input_arrays_remain_exact_in_bound_original_files': True,
    'external_recovery': identity(recovery_path)})

for path in [source_path, HERE / 'PLAN.md', Path(__file__).resolve(),
             HERE / 'SOURCE-CORRESPONDENCE.json', HERE / 'PRIVATE-AND-SCOPE-AUDIT.json',
             HERE / 'SOURCE-CENSUS.json', HERE / 'INGREDIENT-REVIEW-SCOPES.json',
             recovery_path, owner_base / 'SOURCE-CENSUS.json',
             ROOT / 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/report.json']:
    bind_path(path)
for row in physical_rows:
    bind(row['source'])
inventory_id = write_json('SOURCE-INVENTORY.json', {
    'format': 'adwh-eventual-foundation-source-inventory-v1', 'author': '/root/reflection_evidence_review',
    'status': 'frozen_source_only_exact_assembly_pending_independent_review',
    'source': candidate, 'source_correspondence': correspondence, 'scope_audit': private_scope,
    'source_census': census_id, 'ingredient_review_scopes': scopes_id,
    'external_context_recovery': identity(recovery_path),
    'input_count': len(input_map), 'inputs': [input_map[p] for p in sorted(input_map)],
    'selected_physical_sources': [r['source'] for r in physical_rows],
    'prospective_ordered_report_counts': [2, 6, 126], 'prospective_report_count': 134,
    'prospective_physical_owner_count': 3, 'prospective_source_bytes': sum(r['source']['bytes'] for r in physical_rows),
    'prospective_ordinary_output_count': 6, 'logical_origin_count': 24, 'source_segment_count': 26,
    'source_origin_count_uses_current_project_file_convention': True,
    'mathematical_source_edits': 0, 'header_import_edits': 9, 'origin_boundary_comments': 14,
    'all_131_explicit_theorem_headers_and_126_proof_reports_literal': True,
    'all_earlier_source_reviews_and_current_runtime_preserved_separately': True,
    'accepted_pilot41_source_key_remains_consumed': True,
    'gate_authored_selected_or_executed': False,
    'Lean_compiler_preflight_exporter_evaluator_native_profiler_mathematical_generator_or_saved_reader_executed': False,
    'fresh_complete_acceptance_cost_benefit_or_budget_fit_claimed': False,
    'whole_query_installation_GroupChecked_EnvWF_or_stock_numeral_claimed': False})
print(json.dumps({'source': candidate, 'source_correspondence': correspondence,
                  'scope_audit': private_scope, 'source_census': census_id,
                  'inventory': inventory_id, 'input_count': len(input_map),
                  'source_bytes': sum(r['source']['bytes'] for r in physical_rows)}, indent=2))
