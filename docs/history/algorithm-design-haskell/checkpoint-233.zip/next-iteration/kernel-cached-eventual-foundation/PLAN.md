# Consolidated eventual cached foundation

This is a new source-only physical assembly of the seven frozen proof sources
listed in `SOURCE-CORRESPONDENCE.json`. It keeps the reduced Core and Cached
owners byte-for-byte unchanged. One new physical module owns the same 126
public theorem reports, so the proposed complete closure has three modules,
134 distinct reports and six ordinary `.olean`/`.ilean` outputs.

The change is confined to nine one-line imports, which become explicit comments,
and new origin-boundary comments. The first origin retains its existing
`import KernelCachedForward`. All mathematical definitions, theorem statements,
proofs, namespace boundaries, options and report commands are literal source
bytes. No existing file or historical review scope is rebased.

## Exact ownership

| Order | Proof origin | Reports | Explicit private theorems |
| --- | --- | ---: | ---: |
| 1 | KernelCachedMemoRelation | 16 | 0 |
| 2 | KernelCachedEventualEmpty | 8 | 0 |
| 3 | KernelCachedEventualAtoms | 9 | 1 |
| 4 | KernelCachedHelperContract | 37 | 1 |
| 5 | KernelCachedEventualHelpers | 14 | 0 |
| 6 | KernelCachedLiteralContract | 1 | 0 |
| 7 | KernelCachedEventualRecordWrapper | 41 | 3 |

The explicit private names are `full_terminal_head_atom`, `pointer_tag_eq`,
`defeq_memo_hit`, `defeq_memo_miss` and `whnf_app_skip`. Each is used only in its
own origin and under its existing fully qualified namespace. Moving the source
to a different physical module necessarily changes compiler-generated private
and auxiliary declaration identities. No retained source names those generated
identities explicitly. The public names and all private source bindings remain
unchanged. This is a source correspondence claim, not a claim that old compiled
objects or generated proof terms are byte-identical.

The eight namespace blocks close inside their source origins. Opens occur inside
those blocks. The only options are the unchanged strict `autoImplicit=false`,
`warningAsError=true` and `Elab.async=false` settings. There are no new or
pre-existing explicit attributes, instance declarations, syntax, macros or
notation in the seven proof origins. `PRIVATE-AND-SCOPE-AUDIT.json` records the
actual source locations and all private uses.

The seven source modules must not also be imported into this selection: they
would duplicate canonical declarations now owned by
`KernelCachedEventualFoundation`. A later consumer must change only its physical
imports under a separately mapped assembly while retaining the same canonical
declaration names. The current package does not alter any downstream consumer.

## Preserved source and review boundaries

`SOURCE-CORRESPONDENCE.json` records every origin's full identity, exact forward
edits, inverse reconstruction, unchanged complement spans and location in the
physical output. Its origin comments cover all remaining new bytes. The
`SOURCE-CENSUS.json` report order is reconstructed from namespace and `#print
axioms` commands, and includes the unchanged Core2 and Cached6 reports.

The six independent ingredient scopes remain separate: reduced owners,
GenericMemo, EventualEmpty/Atoms, HelperContract/EventualHelpers, LiteralContract,
and EventualRecordWrapper. Their original inventory and audit arrays are bound
by exact file and canonical array identity, without altering their selections
or historical conclusions. The owner review's correction from 389/337 to
392/340 explicit Core declarations is retained in its original review. This
assembly does not use the incomplete 337 figure as an exhaustive census.

Six external SDK/upstream context identities inherited from the old Generic
review use only the exact approved mappings in the reduced owner's
`EXTERNAL-CONTEXT-RECOVERY.json`. The new input inventory contains their matching
retained local copies. The old arrays still contain their original paths.
This does not authorize general parent-directory resolution.

The unchanged Core/Cached runtime includes every actual cached operation,
state field, cache key, guard, error branch, six callback slots, Lift API and
intrinsic expression certificate retained by the independently reviewed owner
slice. The slice's earlier omissions and original native BasisGen/Installed
compatibility limitations also remain. This physical assembly restores none of
the removed pure evaluator, model, installer or driver proofs.

## Cost rationale and uncertainty

The actual, consumed 41-report pilot is retained only as historical evidence.
Its raw report records Core 13.412948659002723 s / 812624 KiB and Cached
11.4753697299966 s / 877264 KiB. The three proof leaves took 0.3897151919991302 s,
0.3121534909987531 s and 0.46391173799929675 s, with peaks 640552, 634476 and
649360 KiB. The complete pilot took 26.449959311 seconds.

The unbundled proposed union would have nine owners. Consolidation removes six
compiler startups, repeated imports and intermediate ordinary serializations;
it does not remove any proof work. The observed three proof leaves total
1.1657804209971801 s including their proofs, so that sum cannot be claimed as
removable overhead. The additional 93 public reports have no timing in this
new source context. At the same observed base and other overhead, a combined
126-report proof owner would have approximately 4.72 seconds before the fixed
30-second deadline. That arithmetic is an illustration, not a prediction.

A combined process retains more local elaboration state. The largest observed
proof-leaf RSS was 649360 KiB, leaving 399216 KiB relative to the fixed 1 GiB
process bound. The seven origins contain 117832 source bytes and 131 explicit
theorem headers, versus 31167 bytes and 34 theorem headers in the three accepted
pilot leaves. RSS is neither additive nor reliably predicted from source bytes.
No budget fit or memory bound follows from this census. The unchanged Core and
Cached processes keep their original separate lifetime.

## Execution boundary

`ASSEMBLE-SOURCE.py` performs static source copying, nine import substitutions,
literal reconstruction, lexical census and identity collection only. It does
not load a gate module or run Lean, a preflight, exporter, evaluator, retained
mathematical generator, native program, profiler or saved-result reader. The
historical report is bound as an immutable file; its measurements above were
read directly by the author.

No gate is authored or selected here. Independent source/assembly review is
required before any complete fresh run. A later run must retain the same
cumulative 30 seconds, one CPU/thread, 1 GiB, default heartbeat/resource options,
three-axiom policy, fresh dependency closure and permanent no-retry source key.
The accepted 41 selection remains consumed and unchanged.

Acceptance of this proposed foundation would establish reusable conditional
helper and record-wrapper facts. It would not establish the full numeric query,
actual annotation/storage pins, original native `GroupChecked`, installation
soundness, or the stock numeral theorem.
