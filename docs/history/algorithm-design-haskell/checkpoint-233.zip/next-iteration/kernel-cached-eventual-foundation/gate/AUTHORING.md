# Control authoring boundary

The author wrote a distinct complete134 control selection from the frozen41
runner using static source and metadata reads only. The author did not import,
compile, AST-check, preflight or execute any runner, Lean source, saved-result
reader, exporter, counter, profiler or mathematical program. Root independently
reviews controls before the metadata stage and sole mathematical attempt.

The authoring script copies the old enforcement block text and applies explicit
bounded string replacements only to selection/report/acceptance bookkeeping and
the added marker directory. The correspondence contains each actual changed
span and every unchanged complement, with a full inverse check. It is not an
assertion that the whole block is literal.

The original41 metadata validator is called unchanged with its own globals and
manifest; its old run/main is never invoked. The new validator checks the current
sources, three physical owners,134 canonical full roots, all seven origin
reconstructions, the original ingredient arrays, and the new917-input review.
It snapshots the union without copying the old manifest's nested structures
into a new historical schema. It does not execute the root static source checker.

No frozen source, old control, consumed key, original review array or old result
is modified. Only exact known external tuples map to retained source copies.
The original31 scopes, six separately named overlapping ingredient scopes and
the new assembly scope remain distinguishable;35 unique scopes are selected.
The unselected stale41 correspondence draft is not an input. All new gate files,
the current root source review and static-review result are included in the
read-only union. Actual runtime behavior and default resource policy are fixed.
