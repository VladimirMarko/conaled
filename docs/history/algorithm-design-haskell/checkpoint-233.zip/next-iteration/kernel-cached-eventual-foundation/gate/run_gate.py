#!/usr/bin/env python3
"""Fresh consolidated eventual foundation134. Root alone executes; no Lean without --run."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-pilot/gate'
FOUNDATION = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-foundation134-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-foundation134-manifest-v1'
PREVIOUS = None
HISTORICAL = None
POLICY = {'Elab.async': False,
 'autoImplicit': False,
 'compiler_threads': 1,
 'cumulative_wall_seconds': 30,
 'default_heartbeats_recursion_and_compiler_options': True,
 'lean_memory_mib': 1024,
 'resident_memory_kib': 1048576,
 'warningAsError': True}
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
PREVIOUS_RUNNER_PIN = ('next-iteration/kernel-cached-eventual-pilot/gate/run_gate.py',
 58160,
 '82a929203be2bc4f4361c4c620b2eaa970962aaf2fa021c2e0bbdf8998c49692')
PREVIOUS_MANIFEST_PIN = ('next-iteration/kernel-cached-eventual-pilot/gate/source-manifest.json',
 240410,
 '54180080c39f17e420e7c23367cfc5723df027a902cb1a5a046763345bac4e5a')
MODULES = ['KernelCompactCore', 'KernelCachedForward', 'KernelCachedEventualFoundation']
SOURCE_PINS = [('next-iteration/kernel-cached-eventual-owner-slice/source/KernelCompactCore.lean',
  208582,
  '6aacedb54c0facfe362112a156c2e3a877b83ccca043d55f8e22f99cd4404447'),
 ('next-iteration/kernel-cached-eventual-owner-slice/source/KernelCachedForward.lean',
  202799,
  '323da5194486ccf72b8732869415b6d27a9ff2c0dc57406c17c1cd83ef742804'),
 ('next-iteration/kernel-cached-eventual-foundation/source/KernelCachedEventualFoundation.lean',
  119150,
  'b88b25aa807de203419c1d50b860b08950f44de8e5bf03172a91e132c162ccd5')]
EXPECTED_IMPORTS = {'KernelCompactCore': ['Std.Data.HashMap', 'Init.Util'],
 'KernelCachedForward': ['KernelCompactCore'],
 'KernelCachedEventualFoundation': ['KernelCachedForward']}
RAW_REQUIRED = {'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero', 'ConLeche.PropWhen.eq_of_toList'],
 'KernelCachedForward': ['memoEI_hit',
                         'memoEI_miss',
                         'whnf_hit',
                         'whnf_miss',
                         'whnfCore_hit',
                         'whnfCore_miss'],
 'KernelCachedEventualFoundation': ['map_empty',
                                    'map_insert',
                                    'map_hit_value',
                                    'nf_empty',
                                    'nf_frame',
                                    'nf_insert_full',
                                    'nf_insert_head',
                                    'full_cache_value',
                                    'head_cache_value',
                                    'nf_flushed',
                                    'flushed_full_miss',
                                    'flushed_head_miss',
                                    'flush_starts_unseeded',
                                    'true_memo_frame',
                                    'full_forward_of_body',
                                    'head_forward_of_body',
                                    'eventual_functional',
                                    'full_functional',
                                    'head_functional',
                                    'empty_valid',
                                    'full_miss_from_empty',
                                    'head_miss_from_empty',
                                    'full_eventual_of_body_runs',
                                    'head_eventual_of_body_runs',
                                    'head_loop_atom',
                                    'full_loop_terminal_of_head',
                                    'trace_runs',
                                    'full_trace_eventual',
                                    'head_trace_eventual',
                                    'head_atom_trace',
                                    'full_terminal_trace',
                                    'cached_nat',
                                    'cached_sort',
                                    'map_backed_empty',
                                    'map_backed_insert',
                                    'ienv_tags_empty',
                                    'helper_cache_empty',
                                    'helper_cache_frame',
                                    'helper_cache_flushed',
                                    'helper_result_of_unchanged',
                                    'instantiateListC_cut',
                                    'instantiateListC_eq_plain',
                                    'instLevelParams_eq_plain',
                                    'instLevelParamsM_correct',
                                    'storedTyIdxM_correct',
                                    'storedValIdxM_correct',
                                    'instLevelParamsM_helper_result',
                                    'storedTyIdxM_helper_result',
                                    'storedValIdxM_helper_result',
                                    'instListM_correct',
                                    'constTyAtM_correct',
                                    'constValAtM_correct',
                                    'ruleRhsAtM_correct',
                                    'constTyAtM_from_prefix',
                                    'constValAtM_from_prefix',
                                    'ruleRhsAtM_from_prefix',
                                    'preserves_pure',
                                    'preserves_throw',
                                    'preserves_bind',
                                    'preserves_modifyGet',
                                    'preserves_modify',
                                    'instLevelParamsM_preserves',
                                    'storedTyIdxM_preserves',
                                    'storedValIdxM_preserves',
                                    'instListM_preserves',
                                    'constTyAtM_preserves',
                                    'constValAtM_preserves',
                                    'ruleRhsAtM_preserves',
                                    'helper_result_with_auxiliary',
                                    'restCaches_helper_frame',
                                    'helper_cache_memo_frame',
                                    'helpers_auxiliary_memo_frame',
                                    'restCaches_memo_frame',
                                    'true_helper_frame',
                                    'helper_result_nf',
                                    'helper_result_nf_with_auxiliary',
                                    'helper_result_eventual_with_auxiliary',
                                    'empty_valid',
                                    'flushed_valid',
                                    'instLevelParamsM_forward',
                                    'instListM_forward',
                                    'constTyAtM_forward',
                                    'constValAtM_forward',
                                    'ruleRhsAtM_forward',
                                    'head_body_nat',
                                    'true_defeq_empty',
                                    'true_defeq_insert',
                                    'working_empty',
                                    'working_after_rest',
                                    'working_insert_cheap',
                                    'working_insert_defeq',
                                    'defeq_forward_of_body',
                                    'defeq_same_body',
                                    'defeq_same',
                                    'cheap_forward_of_body',
                                    'cheap_nat',
                                    'cheap_const',
                                    'no_iota_of_no_recursor',
                                    'whnf_spine_no_recursor',
                                    'cheap_application_body',
                                    'cheap_application',
                                    'add_not_recursor',
                                    'eq_not_recursor',
                                    'full_nat_with_rest',
                                    'prop_irrel_literal',
                                    'offset_literal_add',
                                    'reduce_add_zero',
                                    'lazy_literal_add',
                                    'defeq_literal_add_body',
                                    'defeq_literal_add',
                                    'eq_not_proof',
                                    'prop_irrel_eq',
                                    'eq_not_unfoldable',
                                    'lazy_eq',
                                    'eq_argument_list',
                                    'stuck_eq',
                                    'defeq_eq_body',
                                    'eq_refl_type_defeq',
                                    'infer_nat_body',
                                    'infer_const_body',
                                    'infer_application_body',
                                    'infer_spine_done',
                                    'infer_spine_forall',
                                    'annotate_const_body',
                                    'annotate_nat_body',
                                    'annotate_application_body']}
REQUIRED = {'KernelCompactCore': ['ConLeche.PropWhen.hasParams_ifAllZero', 'ConLeche.PropWhen.eq_of_toList'],
 'KernelCachedForward': ['ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.memoEI_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnf_miss',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_hit',
                         'ADWH.Experiments.Chapter15.KernelCachedForward.whnfCore_miss'],
 'KernelCachedEventualFoundation': ['ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_insert',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.map_hit_value',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_full',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_insert_head',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_cache_value',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_cache_value',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.nf_flushed',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_full_miss',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flushed_head_miss',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.flush_starts_unseeded',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.true_memo_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.full_forward_of_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedMemoRelation.head_forward_of_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.eventual_functional',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_functional',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_functional',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.empty_valid',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_miss_from_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_miss_from_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.full_eventual_of_body_runs',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualEmpty.head_eventual_of_body_runs',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_loop_atom',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_loop_terminal_of_head',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.trace_runs',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_trace_eventual',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_trace_eventual',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.head_atom_trace',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.full_terminal_trace',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_nat',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualAtoms.cached_sort',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.map_backed_insert',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ienv_tags_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_cache_flushed',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.helper_result_of_unchanged',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_cut',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instantiateListC_eq_plain',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParams_eq_plain',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instLevelParamsM_helper_result',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedTyIdxM_helper_result',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.storedValIdxM_helper_result',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.instListM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_correct',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constTyAtM_from_prefix',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.constValAtM_from_prefix',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperDirect.ruleRhsAtM_from_prefix',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_pure',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_throw',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_bind',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modifyGet',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.preserves_modify',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instLevelParamsM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedTyIdxM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.storedValIdxM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.instListM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constTyAtM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.constValAtM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.ruleRhsAtM_preserves',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.helper_result_with_auxiliary',
                                    'ADWH.Experiments.Chapter15.KernelCachedHelperFrame.restCaches_helper_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_cache_memo_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helpers_auxiliary_memo_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.restCaches_memo_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.true_helper_frame',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_nf_with_auxiliary',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.helper_result_eventual_with_auxiliary',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.empty_valid',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.flushed_valid',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instLevelParamsM_forward',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.instListM_forward',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constTyAtM_forward',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.constValAtM_forward',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualHelpers.ruleRhsAtM_forward',
                                    'ADWH.Experiments.Chapter15.KernelCachedLiteralForward.head_body_nat',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.true_defeq_insert',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_empty',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_after_rest',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_cheap',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.working_insert_defeq',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_forward_of_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_same',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_forward_of_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_nat',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_const',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.no_iota_of_no_recursor',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.whnf_spine_no_recursor',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.cheap_application',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.add_not_recursor',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_recursor',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.full_nat_with_rest',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_literal',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.offset_literal_add',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.reduce_add_zero',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_literal_add',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_literal_add',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_proof',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.prop_irrel_eq',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_not_unfoldable',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.lazy_eq',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_argument_list',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.stuck_eq',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.defeq_eq_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.eq_refl_type_defeq',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_nat_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_const_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_application_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_done',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.infer_spine_forall',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_const_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_nat_body',
                                    'ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper.annotate_application_body']}
NEW_FIXED = {'next-iteration/kernel-cached-eventual-foundation/ASSEMBLE-SOURCE.py': 'f74e2fc0a2408101bf0e1d2205e70d0334670a3a7c0e025159536cbc90150829',
 'next-iteration/kernel-cached-eventual-foundation/INGREDIENT-REVIEW-SCOPES.json': '728ba6f9e8304caa12479e0f7a7537c1accc0e91785dd4b1c92416fc79c7c890',
 'next-iteration/kernel-cached-eventual-foundation/PLAN.md': '904d48e56ce43bd888ce248c111e4edc284b758f0c187c6c097900ebffb215ca',
 'next-iteration/kernel-cached-eventual-foundation/PRIVATE-AND-SCOPE-AUDIT.json': '6da2e15ca445ec00da8b49a5c551ffdeb5a4f3ce5093e6f425ff51e090969c80',
 'next-iteration/kernel-cached-eventual-foundation/REVIEW-STATIC-CHECK.py': '568ba41f18b26ef8e3185998bd270a8c00269f73ee4cf40070cfe59dd3a32d2d',
 'next-iteration/kernel-cached-eventual-foundation/REVIEW-STATIC-RESULT.json': '636219f266b9b26ed9236df7eb193776d5831b1b285b88c2ff2f02b78d9b42be',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-AUDIT.json': '29b0993edbc47b091d6ea0b3080765dce6425967081443c8c3ec0716d69cd6dc',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-CENSUS.json': 'cea26fccb60d3d3f9216b5b64a2186c7e18e3a2e3021c96c9a45ec7b20b4f599',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-CORRESPONDENCE.json': '8ecf5ba4328efdae2b24518315cc10c3891e6708dfd3e097a0b5a7c1702f1cc9',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-INVENTORY.json': '19d3419d750c772a9205f86297ceb68e62be0ed8b43f9eb668a0d742782ecbe0',
 'next-iteration/kernel-cached-eventual-foundation/SOURCE-REVIEW.md': 'dd3576309e2fc6585f42d13fa1dbb6f62b11b5818a0cc106c6e09bbabef20401',
 'next-iteration/kernel-cached-eventual-pilot/gate/run_gate.py': '82a929203be2bc4f4361c4c620b2eaa970962aaf2fa021c2e0bbdf8998c49692',
 'next-iteration/kernel-cached-eventual-pilot/gate/source-manifest.json': '54180080c39f17e420e7c23367cfc5723df027a902cb1a5a046763345bac4e5a',
 'next-iteration/kernel-cached-eventual-pilot/gate/PROTOCOL.md': 'f83f00edd0197dddd9c5b00b563f2c4c46ecdfa5b4403255814124a20e4289ce',
 'next-iteration/kernel-cached-eventual-pilot/gate/AUTHORING.md': '787304ee6584f081e0f85b9aa4a3f0437c71efaea20e183b1c736525ea08cc6b',
 'next-iteration/kernel-cached-eventual-pilot/gate/CONTROL-CORRESPONDENCE.json': 'a79b5fd6ad8849b8c2648dd6f2a9ead48d6963e39f3914fba1026113aabadcaf',
 'next-iteration/kernel-cached-eventual-pilot/gate/INDEPENDENT-CONTROL-REVIEW.md': '09027773d8d569626ed8e19ac309dfa284685d6da5f4f8bba2c15173eef62eac',
 'next-iteration/kernel-cached-eventual-pilot/gate/STATIC-INDEPENDENT-CONTROL-CHECK.py': '69246849515de90d59542083f7d65e37bde86d027b0d48d70b2bccc998d24971',
 'next-iteration/kernel-cached-eventual-pilot/gate/STATIC-INDEPENDENT-CONTROL-AUDIT.json': '4c22ccce74e9b9b6135ea700e032eb07541e0c4b7966ebaa198a01813a93256f',
 'next-iteration/kernel-cached-eventual-pilot/gate/RESULT-AND-NEXT.md': '47149f53608c2390844f3256a6a0a41279f53c0ab4171de40b8366e7482239d4',
 'next-iteration/kernel-cached-eventual-pilot/gate/ROOT-EXECUTION-RECEIPT.json': 'fdcd9951941059bb1919a62a4e7593be372e13c31bcfa28b9ab6dae2dc14b83f',
 'next-iteration/kernel-cached-eventual-pilot/gate/SNAPSHOT-RECOVERY.json': '42f88147908ce11bc64782fdf0c3c0467334954d9c312d5cce3923ec01e99404',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/report.json': 'e858925d7e508eee3203b6a3704bb5e0f71113709b3532d5c38d21a371765197',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualAtoms.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualAtoms.stdout.log': 'ee2d677409857f6574019bbf1c19f1ccd90f789c2cda360665c31c438236e2bc',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualEmpty.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedEventualEmpty.stdout.log': '190c62a01bba14df8060c50a1df7e546a1e76679ef5d9178b26ecc919163244b',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedForward.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedForward.stdout.log': 'cd390502717d4b03e7e5206bc9deb9c8f4b2e8babed4efebe60b78ac22e638b7',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedMemoRelation.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCachedMemoRelation.stdout.log': '461c9706b809a418eb850597d8f7dc3daf4ccb2ad4e9950d2bff9a1f993a3330',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCompactCore.stderr.log': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'next-iteration/kernel-cached-eventual-pilot/gate/attempts/complete-01/KernelCompactCore.stdout.log': 'bbe6f26c831d243c813f3d2e524c63bdb9bb8c43b8219670453bec4ad0993e03',
 'next-iteration/kernel-cached-eventual-pilot/gate/execution-markers/complete-492bf86674732afb57fd0844d3da8d9f236ddecf2168ad137fa458f232bcdeaf.json': '23e881c5a6f776add894ebda50960efad07c5964685e6c5c8bd0db11c1f734a5',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/AUTHOR-CONTROLS.py': '9fc3c6511cce777a1d836b2ed2d462e3844271c6ab1013dcae5286b03b14ab26',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/AUTHORING.md': 'e40b0b9d3767ad04bf887893ea9cc495546994f8c42d65f52ae9762b4cae8a65',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/CONTROL-CORRESPONDENCE.json': 'a5c9761b37bce3698c0f6d1f4495dc37a06fc42fca22f62835c4caad65e3dafb',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/PROTOCOL.md': 'ec62eff2cefa8874236d794ad600eb85d1bf896c4f25cbe09998389925f5adc8',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/RECOVERY.json': '6ccebf530a463ae421bf6fc4c9cf26ba5434aec94ea34281063a0f1bb11775b1',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/run_gate.py': '747ae669742a37d758c7b4ac1f7812a431050de6d2ece7cefb8d4b0d008e6cf4',
 'next-iteration/kernel-cached-eventual-foundation/gate/unselected-pre-review-01/source-manifest.json': '387ecc9004f4ddf10103e97c9e6d32613d8c0e8d9f91d856e22cb1a6be94c77d'}
ASSEMBLY_REVIEW_FACTS = {'Core_and_Cached_sources_changed': False,
 'author_inputs_verified': 916,
 'compiler_preflight_gate_mathematical_generator_or_saved_reader_executed': False,
 'complete_inverse_origin_reconstructions': 7,
 'direct_review_inputs': 917,
 'exact_external_context_routes': 6,
 'import_comment_edits': 9,
 'literal_proof_reports': 126,
 'literal_theorem_headers': 131,
 'namespace_blocks_closed_within_origins': 8,
 'old_acceptance_transferred': False,
 'ordered_distinct_reports': 134,
 'ordinary_outputs': 6,
 'physical_owners': 3,
 'private_helpers_local_to_origins': 5,
 'proof_origin_count': 7,
 'separate_ingredient_scopes': [{'original_author_and_review_counts': [514, 517], 'scope': 'ReducedOwners'},
                                {'original_author_and_review_counts': [405, 409], 'scope': 'GenericMemo'},
                                {'original_author_and_review_counts': [420, 421],
                                 'scope': 'EventualEmptyAtoms'},
                                {'original_author_and_review_counts': [576, 581], 'scope': 'EventualHelpers'},
                                {'original_author_and_review_counts': [59, 60], 'scope': 'LiteralContract'},
                                {'original_author_and_review_counts': [911, 912],
                                 'scope': 'EventualRecordWrapper'}],
 'source_bytes': 530531,
 'status': 'passed_source_only_exact_assembly',
 'unchanged_complements_including_empty': 16}
INGREDIENT_CONTRACTS = [{'name': 'ReducedOwners',
  'author_inventory': {'path': 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-INVENTORY.json',
                       'bytes': 115124,
                       'sha256': '773ab923a8fc0cb9ac61f44af3efff68152729207b75e4e3a123c92a36d57e3f'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-AUDIT.json',
                        'bytes': 116299,
                        'sha256': '38377da414622a5d3af6d6edc8afb1aba5e2e6145dd8c33fbb052eabb607a5af'},
  'independent_review': {'path': 'next-iteration/kernel-cached-eventual-owner-slice/SOURCE-REVIEW.md',
                         'bytes': 7838,
                         'sha256': '24e9e9cf0da4a22857aa0bff3c55ce8d900fa09389fe87bd4f7d39e43a9f9d2b'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 514,
                             'canonical_json_sha256': '7098f13dedd3f0dc8d6ee210be18347bdf7dbb07f68637522a6b5f73bdd6b28a'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 517,
                             'canonical_json_sha256': '4a7d1fb4ab2d2f433387c7b92a1bc45c3b72d911edd527570790f50e98b57696'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_source_only_with_explicit_lexical_census_correction_not_compiled'},
 {'name': 'GenericMemo',
  'author_inventory': {'path': 'next-iteration/kernel-cached-memo-relation/SOURCE-INVENTORY.json',
                       'bytes': 107676,
                       'sha256': '83059b2508e89548aedfb2179fde5b4a679b9d273073c9d2f0bdfbfc92cd111a'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-memo-relation/SOURCE-AUDIT.json',
                        'bytes': 127761,
                        'sha256': '5e9890691a1b99039d958c5f5177268e435c8c37ae8d4a6d04da284711c9adef'},
  'independent_review': {'path': 'next-iteration/kernel-cached-memo-relation/SOURCE-REVIEW.md',
                         'bytes': 9664,
                         'sha256': '9bcea8a5a140504a2b642367878641b2d5efde1ee507e777e4291a3295d60ef5'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 405,
                             'canonical_json_sha256': '91bb556e1aa59b318421a8b8b409e8079b5e84fd4665f1d40d9ab0e5f2d4bbf9'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 409,
                             'canonical_json_sha256': '1f4ec923263af4c7ad0a914902432406f7efbf45962f24c2e42bd083968a59ae'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_independent_source_review_uncompiled'},
 {'name': 'EventualEmptyAtoms',
  'author_inventory': {'path': 'next-iteration/kernel-cached-eventual-empty/SOURCE-INVENTORY.json',
                       'bytes': 98053,
                       'sha256': '8b1027e2daac2a1a7f241bb4235897bf026535276af8683b635a30fbd40086d8'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-eventual-empty/SOURCE-AUDIT.json',
                        'bytes': 110054,
                        'sha256': '86b69bd4a02a988fd59139d745ec2dded165ff536b7b24fb225708cdebd25b52'},
  'independent_review': {'path': 'next-iteration/kernel-cached-eventual-empty/SOURCE-REVIEW.md',
                         'bytes': 10437,
                         'sha256': '10ce3651603884c342967b0f1adbad8e02e9f4182d131c8fdb26e75588f3853f'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 420,
                             'canonical_json_sha256': '4cc3669cf38d59e951d1f8d9b09ce62e649843b62bf9fb49dfaa4b73ef4091f9'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 421,
                             'canonical_json_sha256': '99cdd6ac2542cc3c1984e0b08a82cd24beb546164643c0e3ef6d54a17a51e66f'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_bounded_logical_source_and_interface_review_no_execution'},
 {'name': 'EventualHelpers',
  'author_inventory': {'path': 'next-iteration/kernel-cached-eventual-helpers/SOURCE-INVENTORY.json',
                       'bytes': 147329,
                       'sha256': '30e5a79ac538cf06908a02fca75b528d0f157294626ddd69fe3969cb58b70907'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-eventual-helpers/SOURCE-AUDIT.json',
                        'bytes': 177923,
                        'sha256': '92d251f51a3a3b45115a14925728766fecd5d2f31945f51e255cc5db986fad9b'},
  'independent_review': {'path': 'next-iteration/kernel-cached-eventual-helpers/SOURCE-REVIEW.md',
                         'bytes': 11049,
                         'sha256': '0b895796eb931670578e56d9ca9147b10d5ce7bbf66eca5fc1a2db949731dcc6'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 576,
                             'canonical_json_sha256': 'a718240565f8bd6817924c59534e7088ecf6d996ac6f411a88ed54fffd6c0510'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 581,
                             'canonical_json_sha256': '5b233191fb9a6e173fbfea58fe575809fbaa5f01d48b2f4ef30998eca048c0e9'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_canonical_contract_assembly_and_adapter_source_review_no_execution'},
 {'name': 'LiteralContract',
  'author_inventory': {'path': 'next-iteration/kernel-cached-literal-contract/SOURCE-INVENTORY.json',
                       'bytes': 14351,
                       'sha256': 'a64b4a1dc0e8cb006f8244d7d8a98d24a446e56399b5535515771435b219e860'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-literal-contract/SOURCE-AUDIT.json',
                        'bytes': 19766,
                        'sha256': 'b4116691db3ba7fec9b834e84e4aa458f707b8e39767c67a43abae7fef4a4e4a'},
  'independent_review': {'path': 'next-iteration/kernel-cached-literal-contract/SOURCE-REVIEW.md',
                         'bytes': 4511,
                         'sha256': '0db9b01e008e450069728ee87539e4accd992bf023222994880ad181f4648e2f'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 59,
                             'canonical_json_sha256': 'ed0d52eea20434208c1cca849f73d6cd2807f01f1d3121b8348db76e9f0d6bcf'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 60,
                             'canonical_json_sha256': 'cc68c2d1ba60a1c414e6c19d208dfa813aeb9502f6ea402039a4f0b5105a2e20'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_independent_source_review_uncompiled'},
 {'name': 'EventualRecordWrapper',
  'author_inventory': {'path': 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-INVENTORY.json',
                       'bytes': 204829,
                       'sha256': 'bfe1947c0d6880ecc4d9c31cc9be02ce0c7f571a495caa8dedc7fdd5a2e46db1'},
  'independent_audit': {'path': 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-AUDIT.json',
                        'bytes': 220626,
                        'sha256': '4dbd8c84513d459ca43d889675ea53ef23097968411c8e10e9c569ecf90e6d25'},
  'independent_review': {'path': 'next-iteration/kernel-cached-eventual-record-wrapper/SOURCE-REVIEW.md',
                         'bytes': 9724,
                         'sha256': 'f20120dffee8671c5002842092af375a320ecbacf13c9f041f71467c589d4609'},
  'unchanged_author_array': {'field': 'inputs',
                             'count': 911,
                             'canonical_json_sha256': '160a13a6c4d27fd742a615b99bb324d8f434d5f79aa8f48e31d5765f3865ca20'},
  'unchanged_review_array': {'field': 'inputs',
                             'count': 912,
                             'canonical_json_sha256': 'd84963a65fce76f156f75116d3c9c5f6e171ee0da9639072b3744deede3ae0d1'},
  'original_scope_or_selection_rebased': False,
  'audit_status': 'passed_source_adaptation_and_provenance_review_no_execution'}]

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result

def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)

def local_path(name):
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name,
            'Nonlocal input path: ' + name)
    path = ROOT.joinpath(*rel.parts)
    require(path.resolve().is_relative_to(ROOT), 'Escaping input path: ' + name)
    require(path.is_file() and not path.is_symlink(), 'Missing ordinary input: ' + name)
    return path

def pin_tuple(row):
    return tuple(row[key] for key in ('path', 'bytes', 'sha256'))

def identity(row, h):
    actual = h.binding(local_path(row['path']))
    require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
            'Input identity differs: ' + row['path'])
    return actual

def relative_binding(path, h):
    return {**h.binding(path), 'path': path.relative_to(ROOT).as_posix()}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def array_reference(path, field, h):
    value = read(path)[field]
    data = canonical(value)
    return {'source': relative_binding(path, h), 'json_field': field,
            'item_count': len(value), 'canonical_json_bytes': len(data),
            'canonical_json_sha256': hashlib.sha256(data).hexdigest()}

def review_identity(row, recovery, h):
    if row['path'].startswith('../'):
        matches = [r for r in recovery if r['original_context'] ==
                   {key: row[key] for key in ('path', 'bytes', 'sha256')}]
        require(len(matches) == 1, 'No exact historical external-context route')
        retained = matches[0]['retained_copy']
        require(all(retained[key] == row[key] for key in ('bytes', 'sha256')),
                'External context copy differs')
        return identity(retained, h)
    return identity(row, h)

def verify(rows, readonly=False):
    # The complete unchanged historical integrity checker is reused.
    return HISTORICAL.verify(rows, readonly)

def fingerprint(sources):
    # Identical permanent stage/policy rule: metadata or an attempt rename cannot reset it.
    body = {'stage': 'cached-forward-runs-and-licensed', 'policy': POLICY,
            'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()



def check_source(row, guard):
    module = row['module']
    if module in MODULES[:2]:
        return PREVIOUS.check_source(row, guard)
    path = local_path(row['path'])
    code = guard.check_lean_source(path, path.read_text())
    require(HISTORICAL.imports(code) == row['imports'] == ['KernelCachedForward'], 'Foundation direct import')
    strict = [('autoImplicit','false'),('warningAsError','true'),('Elab.async','false')]
    require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)',code) == strict*8, 'Eight literal strict option scopes')
    require(not re.search(r'^\s*module\s*$|^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b',code,re.M),
            'Unexpected module or elaborator execution command')
    require(not re.search(r'^\s*(?:public\b|meta\s+import|import\s+all)|@\[(?:expose|no_expose)\]',code,re.M),
            'Unsupported legacy visibility command')
    raw = re.findall(r'^\s*#print\s+axioms\s+(\S+)',code,re.M)
    require(raw == RAW_REQUIRED[module] == row['raw_source_print_identifiers'], 'Literal ordered print spellings')
    stack=[]; actual=[]; blocks=0
    for line in code.splitlines():
        opening=re.fullmatch(r'namespace\s+(\S+)\s*',line)
        closing=re.fullmatch(r'end\s+(\S+)\s*',line)
        printed=re.fullmatch(r'#print\s+axioms\s+(\S+)\s*',line)
        if opening:
            require(not stack, 'Unexpected nested namespace in reviewed physical owner')
            stack.append(opening.group(1)); blocks+=1
        elif closing:
            require(stack and stack.pop()==closing.group(1), 'Exact closed namespace boundary')
        elif printed:
            name=printed.group(1)
            require(stack, 'Expected original namespace at each foundation print')
            actual.append(name if name.startswith(('ADWH.','ConLeche.')) else stack[-1]+'.'+name)
    require(not stack and blocks==8 and actual==REQUIRED[module]==row['fully_qualified_roots']
            and len(actual)==len(set(actual))==126, 'Actual canonical roots, not physical-module prefixes')
    return code

def verify_scope(row, recovery, h):
    inventory=read(local_path(row['author_inventory']['path']))
    audit=read(local_path(row['independent_audit']['path']))
    for name in ('author_inventory','independent_audit','independent_review'):
        identity(row[name],h)
    for field,document in [('unchanged_author_array',inventory),('unchanged_review_array',audit)]:
        descriptor=row[field]; values=document[descriptor['field']]
        require(len(values)==descriptor['count']
                and hashlib.sha256(canonical(values)).hexdigest()==descriptor['canonical_json_sha256'],
                'Exact original ingredient input array: '+row['name'])
        for item in values: review_identity(item,recovery,h)
    require(audit['status']==row['audit_status']
            and audit['author_input_count_verified']==len(inventory['inputs'])
            and audit['direct_input_count']==len(audit['inputs'])
            and row['original_scope_or_selection_rebased'] is False,
            'Original distinct ingredient review remains passed against its own original inputs')
    return inventory['inputs']+audit['inputs']

def verify_assembly(manifest, h):
    mapping=read(FOUNDATION/'SOURCE-CORRESPONDENCE.json')
    census=read(FOUNDATION/'SOURCE-CENSUS.json')
    scope=read(FOUNDATION/'PRIVATE-AND-SCOPE-AUDIT.json')
    require(mapping['candidate']=={key:manifest['sources'][2][key] for key in ('path','bytes','sha256')}
            and mapping['origin_count']==len(mapping['origins'])==7
            and mapping['header_import_edit_count']==9
            and mapping['origin_boundary_comment_count']==14
            and mapping['unchanged_complement_count_including_empty_header_spans']==16
            and mapping['source_bodies_statements_options_namespace_boundaries_and_reports_literal'] is True
            and mapping['complete_forward_and_inverse_reconstruction_verified'] is True
            and mapping['new_mathematical_declarations_or_proofs'] is False
            and mapping['current_Core_and_Cached_changed'] is False, 'Exact assembly scope')
    candidate=local_path(mapping['candidate']['path']).read_bytes()
    output=bytearray(mapping['header_literal'].encode()); edits=0; complements=0
    literal_headers=[]; original_raw=[]
    for number,row in enumerate(mapping['origins'],1):
        require(row['order']==number, 'Exact origin order')
        identity(row['source'],h); original=local_path(row['source']['path']).read_bytes()
        transformed=bytearray(); cursor=0
        require(len(row['edits'])==row['edit_count']
                and len(row['unchanged_complements'])==len(row['edits'])+1, 'Complete origin edit partition')
        for change in row['edits']:
            a,b=change['original_start'],change['original_end']
            require(cursor<=a<=b<=len(original) and original[a:b]==change['before'].encode()
                    and re.fullmatch(r'import \S+\n',change['before'])
                    and change['after']=='-- [assembly import internalized] '+change['before'],
                    'Only an exact header import is commented')
            transformed.extend(original[cursor:a])
            require(change['transformed_start']==len(transformed), 'Transformed import start')
            transformed.extend(change['after'].encode())
            require(change['transformed_end']==len(transformed), 'Transformed import end')
            cursor=b; edits+=1
        transformed.extend(original[cursor:]); transformed=bytes(transformed)
        require(len(transformed)==row['transformed_bytes']
                and hashlib.sha256(transformed).hexdigest()==row['transformed_sha256'], 'Full transformed origin identity')
        inverse=transformed
        for change in reversed(row['edits']):
            a,b=change['transformed_start'],change['transformed_end']
            require(inverse[a:b]==change['after'].encode(), 'Inverse actual import span')
            inverse=inverse[:a]+change['before'].encode()+inverse[b:]
        require(inverse==original and row['inverse_reconstructs_complete_original'] is True, 'Full inverse origin')
        output.extend(row['start_marker'].encode())
        require(len(output)==row['physical_body_start'], 'Exact physical origin start')
        for change in row['edits']:
            require(change['physical_start']==len(output)+change['transformed_start']
                    and change['physical_end']==len(output)+change['transformed_end'], 'Physical edit relocation')
        last_o=last_t=0
        for index,gap in enumerate(row['unchanged_complements']):
            old,new=gap['original'],gap['transformed']
            stop_o=(row['edits'][index]['original_start'] if index<len(row['edits']) else len(original))
            stop_t=(row['edits'][index]['transformed_start'] if index<len(row['edits']) else len(transformed))
            require((old['byte_start'],old['byte_end'])==(last_o,stop_o)
                    and (new['byte_start'],new['byte_end'])==(last_t,stop_t), 'Exhaustive unchanged complement')
            a=original[last_o:stop_o]; b=transformed[last_t:stop_t]
            require(a==b and len(a)==old['bytes']==new['bytes']
                    and hashlib.sha256(a).hexdigest()==old['sha256']==new['sha256']
                    and gap['physical_start']==len(output)+last_t and gap['physical_end']==len(output)+stop_t,
                    'Literal unchanged complement with physical relocation')
            for desc,data in [(old,original),(new,transformed)]:
                first=data[:desc['byte_start']].count(b'\n')+1
                end=desc['byte_end']; last=data[:end].count(b'\n')+(0 if end and data[end-1:end]==b'\n' else 1)
                require(desc['line_start']==first and desc['line_end']==last, 'Exact complement line bounds')
            if index<len(row['edits']):
                last_o=row['edits'][index]['original_end']; last_t=row['edits'][index]['transformed_end']
            complements+=1
        output.extend(transformed)
        require(len(output)==row['physical_body_end'], 'Exact physical origin end')
        output.extend(row['end_marker'].encode())
        literal_headers.extend(re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',original))
        original_raw.extend(re.findall(rb'^\s*#print\s+axioms\s+(\S+)',original,re.M))
    require(bytes(output)==candidate and edits==9 and complements==16, 'Complete forward assembly')
    require(literal_headers==re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',candidate)
            and len(literal_headers)==131
            and original_raw==re.findall(rb'^\s*#print\s+axioms\s+(\S+)',candidate,re.M)
            and len(original_raw)==126, 'All literal theorem statements and report spellings')
    require(scope['namespace_block_count']==8 and scope['explicit_private_theorem_count']==5
            and scope['private_spelling_used_across_origin_boundary'] is False
            and scope['explicit_generated_private_or_auxiliary_names_in_source'] is False
            and scope['all_explicit_theorem_header_count']==131 and scope['exact_public_report_count']==126,
            'Separate reviewed private and namespace boundary')
    require(census['selected_physical_sources']==[{k:r[k] for k in ('path','bytes','sha256')} for r in manifest['sources']]
            and census['ordered_report_counts']==[2,6,126] and census['ordered_report_count']==134
            and census['distinct_report_count']==134 and census['source_bytes']==530531
            and census['physical_owner_count']==3 and census['default_ordinary_output_count']==6
            and census['logical_origins']==manifest['logical_origins']
            and census['distinct_current_source_origin_count']==24 and census['source_segment_count']==26,
            'Exact current complete source/import/root/origin census')
    for actual,row in zip(census['physical_modules'],manifest['sources']):
        require(actual['module']==row['module'] and actual['imports']==row['imports']
                and actual['ordered_report_roots']==row['fully_qualified_roots'], 'Full rooted owner census')
    return {'complete_forward_inverse_origin_count':7,'import_comment_edits':9,
            'literal_complements':16,'literal_theorem_headers':131,'literal_proof_reports':126,
            'namespace_blocks':8,'private_helpers_local_to_origins':5,
            'source_correspondence':relative_binding(FOUNDATION/'SOURCE-CORRESPONDENCE.json',h)}

def preflight(args,h,guard):
    # Exact earlier metadata validation, never the old run/main or any compiler.
    previous_plan=PREVIOUS.preflight(args,h,guard)
    previous_manifest=read(PREDECESSOR/'source-manifest.json')
    manifest=read(MANIFEST)
    require(manifest['format']==MANIFEST_FORMAT
            and manifest['status']=='frozen_ready_for_independent_root_control_review'
            and manifest['policy']==POLICY==PREVIOUS.POLICY==HISTORICAL.POLICY
            and manifest['module_order']==MODULES and manifest['prepared_objects']==[]
            and manifest['export_targets']==[] and manifest['ordered_report_counts']==[2,6,126]
            and manifest['required_axiom_report_count']==manifest['required_unique_axiom_name_count']==134
            and manifest['selected_physical_source_bytes']==530531 and manifest['expected_artifact_count']==6,
            'Fresh three-owner134 complete selection')
    history=manifest['historical_context']
    require(pin_tuple(history['runner'])==PREVIOUS_RUNNER_PIN
            and pin_tuple(history['manifest'])==PREVIOUS_MANIFEST_PIN
            and history['validator']=='preflight'
            and history['historical_review_scope_count']==31
            and previous_manifest['current_total_separate_independent_review_scope_count']==31
            and manifest['historical_independent_review_scope_count']==31
            and manifest['current_total_separate_independent_review_scope_count']==35
            and manifest['historical_reviews_rebased'] is False,
            'All prior review scopes preserved without rebasing or double counting')
    for field,reference in history['exact_field_references'].items():
        require(reference==array_reference(PREDECESSOR/'source-manifest.json',field,h), 'Exact old manifest field reference')
    require(set(history['exact_field_references'])=={'historical_context','new_separate_review_scopes',
                'external_review_context_recovery','owner_declaration_census_correction'}, 'Complete inherited context references')
    recovery=read(ROOT/'next-iteration/kernel-cached-eventual-owner-slice/EXTERNAL-CONTEXT-RECOVERY.json')['mappings']
    require(manifest['external_review_context_recovery']==recovery and len(recovery)==6, 'Six exact external copy routes')
    sources=[];seen=set()
    require(len(manifest['sources'])==3,'Exactly three physical sources')
    for row,module,pin in zip(manifest['sources'],MODULES,SOURCE_PINS):
        require(row['module']==module and pin_tuple(row)==pin
                and row['imports']==EXPECTED_IMPORTS[module]
                and row['raw_source_print_identifiers']==RAW_REQUIRED[module]
                and row['fully_qualified_roots']==REQUIRED[module]
                and row['module_format'] is False and row['expected_default_output_suffixes']==['.olean','.ilean'],
                'Exact source and canonical ordered reports')
        require(all(name in seen or name=='Init' or name.startswith(('Init.','Std.')) for name in row['imports']),
                'Unselected or forward experimental import')
        check_source(row,guard); sources.append({**identity(row,h),'module':module,'imports':row['imports']});seen.add(module)
    require(len(set(n for names in REQUIRED.values() for n in names))==134
            and sum(r['bytes'] for r in sources)==530531 and manifest['source_fingerprint']==fingerprint(sources),
            'Full distinct root, source byte and permanent key census')
    ingredients=read(FOUNDATION/'INGREDIENT-REVIEW-SCOPES.json')
    require(manifest['ingredient_review_scopes']==INGREDIENT_CONTRACTS
            and ingredients['scopes']==[{k:v for k,v in row.items() if k!='audit_status'} for row in INGREDIENT_CONTRACTS]
            and ingredients['ingredient_scope_count']==6
            and ingredients['new_assembly_independent_review_status']=='pending'
            and manifest['overlapping_historical_ingredient_scopes']==['ReducedOwners','GenericMemo','EventualEmptyAtoms']
            and manifest['new_ingredient_scopes']==['EventualHelpers','LiteralContract','EventualRecordWrapper'],
            'Six original ingredient scopes, historical pending author context retained')
    inputs=[]
    for row in INGREDIENT_CONTRACTS: inputs.extend(verify_scope(row,recovery,h))
    author=read(FOUNDATION/'SOURCE-INVENTORY.json');audit=read(FOUNDATION/'SOURCE-AUDIT.json')
    current=manifest['new_assembly_review']
    for key,name in [('author_inventory','SOURCE-INVENTORY.json'),('source_audit','SOURCE-AUDIT.json'),
                     ('source_review','SOURCE-REVIEW.md')]:
        require(current[key]==relative_binding(FOUNDATION/name,h),'Exact new independent assembly review identity')
    require(current['author_inputs']==array_reference(FOUNDATION/'SOURCE-INVENTORY.json','inputs',h)
            and current['review_inputs']==array_reference(FOUNDATION/'SOURCE-AUDIT.json','inputs',h)
            and len(author['inputs'])==author['input_count']==916
            and len(audit['inputs'])==audit['direct_input_count']==917
            and audit['author_input_count_verified']==916
            and audit['author_inventory']==current['author_inventory'] and audit['source_review']==current['source_review']
            and audit['status']=='passed_source_only_exact_assembly' and audit['reviewer']=='/root'
            and audit['checks']==ASSEMBLY_REVIEW_FACTS
            and audit['source']=={k:manifest['sources'][2][k] for k in ('path','bytes','sha256')}
            and audit['old_acceptance_transferred'] is False and audit['source_or_author_metadata_changed'] is False
            and audit['compiler_preflight_gate_or_mathematical_execution'] is False,
            'Root independent917-input exact assembly scope')
    inputs += author['inputs']+audit['inputs']
    for row in inputs: review_identity(row,recovery,h)
    assembly=verify_assembly(manifest,h)
    for key in ('logical_origins','complete_origin_source_rows'):
        require(manifest[key][:len(previous_manifest[key])]==previous_manifest[key], 'Original20 origins remain literal')
    require(len(manifest['logical_origins'])==len(set(manifest['logical_origins']))==24
            and len(manifest['complete_origin_source_rows'])==24
            and manifest['complete_origin_source_rows'][20:]==[mapping['source'] for mapping in
                read(FOUNDATION/'SOURCE-CORRESPONDENCE.json')['origins'][3:]], 'Four added original proof origins')
    for row in manifest['complete_origin_source_rows']: identity(row,h);inputs.append(row)
    require(manifest['root_only_preflight_and_run'] is True
            and manifest['all_current_cached_runtime_declarations_preserved'] is True
            and manifest['actual_reference_state_is_empty_CState'] is True
            and manifest['conditional_record_wrapper_only'] is True
            and manifest['whole_query_cached_success_claimed'] is False
            and manifest['original_GroupChecked_claimed'] is False
            and manifest['stock_numeral_theorem_claimed'] is False
            and manifest['measured_cost_benefit_or_budget_fit_claimed_before_run'] is False,
            'Conditional helper/wrapper acceptance without query or installation claims')
    controls=[{**identity(row,h),'role':row['role']} for row in manifest['controls']]
    require(len({r['path'] for r in controls})==len(controls)
            and len({r['role'] for r in controls})==len(controls),'Unique control bindings')
    controls.append({**h.binding(MANIFEST),'role':'manifest'})
    bound={row['path']:row for row in sources+controls}
    require(len(bound)==len(sources)+len(controls),'No selected source/control overlap')
    for row in previous_plan['sources']+previous_plan['controls']:
        require(row['path'] in bound and all(bound[row['path']][k]==row[k] for k in ('bytes','sha256')),
                'Prior source/control omitted from new read-only snapshot union')
    for row in inputs:
        actual=review_identity(row,recovery,h)
        require(actual['path'] in bound and all(bound[actual['path']][k]==actual[k] for k in ('bytes','sha256')),
                'Reviewed input omitted from current snapshot union')
    for path in [local_path(p) for p in NEW_FIXED]+[Path(__file__).resolve(),HERE/'PROTOCOL.md',HERE/'AUTHORING.md',
            HERE/'CONTROL-CORRESPONDENCE.json',HERE/'AUTHOR-CONTROLS.py']:
        require(str(path) in bound,'Current exact control omitted: '+str(path))
    require(manifest['snapshot_count_including_manifest']==len(sources)+len(controls),'Complete snapshot count')
    verify(sources+controls+[previous_plan['compiler']]+previous_plan['runtime'])
    return {'sources':sources,'controls':controls,'roots':REQUIRED,'source_fingerprint':fingerprint(sources),
        'compiler':previous_plan['compiler'],'runtime':previous_plan['runtime'],
        'historical_context':history,'new_review_scopes':{'ingredients':manifest['ingredient_review_scopes'],
            'assembly':manifest['new_assembly_review']},'external_context_recovery':recovery,
        'owner_omissions':previous_plan['owner_omissions'],'primary_interval_counts':previous_plan['primary_interval_counts'],
        'logical_origins':manifest['logical_origins'],'origin_sources':manifest['complete_origin_source_rows'],
        'foundation_assembly':assembly}

def audit_logs(required, stdout_path, stderr_path):
    # Exact unchanged axiom report parser, name order, whitelist and residual-output policy.
    return HISTORICAL.audit_logs(required, stdout_path, stderr_path)

def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    # Every historical no-retry directory is retained, with the consumed41 pilot appended.
    prior_names = ('TERMINAL_GATE_HERE', 'INTERFACE_GUARD137_MARKERS', 'WRAPPER_TERMINAL_PREDECESSOR',
        'CORE_WRAPPER_PREDECESSOR', 'FRAME_REPAIR_PREDECESSOR', 'TERMINAL_PREDECESSOR',
        'BOOLEAN_LITERAL_PREDECESSOR', 'WRAPPER_PREDECESSOR', 'HASLP_PREDECESSOR',
        'COMMENT_PREDECESSOR', 'OMISSION_PREDECESSOR', 'COST_PREDECESSOR', 'ACCEPTED_PREDECESSOR',
        'PREDECESSOR', 'STABLE_PREDECESSOR', 'ORIGINAL_GATE')
    predecessor_markers = [path / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
                           for path in [PREDECESSOR, PREVIOUS.PREDECESSOR] + [getattr(HISTORICAL, name) for name in prior_names]]
    require(not attempt.exists() and not marker.exists() and not any(path.exists() for path in predecessor_markers),
            'Attempt or unchanged source closure already consumed')
    require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt,
              'executor': 'root', 'gate_author': 'reflection_evidence_review',
              'module_order': MODULES, 'physical_module_count': 3,
              'distinct_upstream_origin_count': 16, 'distinct_project_origin_count': 8,
              'distinct_logical_origin_count': 24, 'source_segment_count': 26,
              'logical_origins': plan['logical_origins'],
              'complete_origin_source_rows': plan['origin_sources'],
              'source_bindings': plan['sources'], 'controls': plan['controls'],
              'source_fingerprint': plan['source_fingerprint'],
              'historical_context': plan['historical_context'],
              'historical_independent_review_scope_count': 31,
              'new_separate_source_reviews': plan['new_review_scopes'],
              'total_separate_independent_review_scope_count': 35,
              'external_review_context_recovery': plan['external_context_recovery'],
              'owner_omission_correspondence': plan['owner_omissions'],
              'foundation_assembly_correspondence': plan['foundation_assembly'],
              'primary_source_interval_counts': plan['primary_interval_counts'],
              'historical_reviews_rebased': False,
              'source_origin_rows_precede_separate_proof_and_omission_overlays': True,
              'pure_evaluator_absent_from_selected_Core': True,
              'all_current_cached_runtime_declarations_preserved': True,
              'all_six_runtime_slots_and_Lift_APIs_retained': True,
              'compiler': plan['compiler'], 'compiler_release': '4.35.0',
              'compiler_commit': 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc',
              'runtime_libraries': plan['runtime'], 'constraints': {**POLICY, 'cpu_affinity': []},
              'execution_marker': None, 'required_prints': REQUIRED,
              'required_axiom_report_count': 134, 'required_unique_axiom_name_count': 134,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'each_physical_module_acceptance_is_all_or_nothing': True,
              'modules': [], 'seconds': None, 'peak_child_rss_kib': 0, 'artifacts': [],
              'expected_artifact_count': 6, 'prepared_objects': [], 'object_search_path': str(build),
              'all_selected_mathematical_sources_freshly_checked': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'exact_build_artifact_inventory': False,
              'Core_2_roots_checked': False, 'PropWhen_eq_of_toList_checked': False,
              'cached_memo_6_roots_checked': False,
              'generic_memo_relation_16_roots_checked': False,
              'eventual_empty_8_roots_checked': False,
              'eventual_terminal_trace_9_roots_checked': False,
              'eventual_scoped_functionality_from_actual_empty_runs_checked': False,
              'finite_terminal_trace_constructs_its_own_eventual_witness_checked': False,
              'literal_sort_forwarding_under_new_relational_validity_checked': False,
              'eventual_helper_51_roots_checked': False,
              'literal_contract_1_root_checked': False,
              'conditional_eventual_wrapper_41_roots_checked': False,
              'foundation_126_roots_checked': False,
              'actual_reference_state_is_empty_CState': True,
              'functionality_requires_actual_query_scoping': True,
              'generic_map_validity_covers_every_actual_entry': True,
              'terminal_fragment_only': False, 'conditional_record_wrapper_only': True,
              'finite_trace_root_success_or_relation_premise': False,
              'whole_query_cached_forward_success_proved': False,
              'actual_installed_annotation_pins_discharged': False,
              'CSOK_or_EnvWF_discharged': False,
              'whole_structural_evaluator_normalization_proved': False,
              'original_GroupChecked_proved': False, 'optimized_kernel_installed': False,
              'full_original_driver_native_API_preserved': False,
              'native_BasisGen_or_Installed_compatibility_claimed': False,
              'later_original_driver_and_pure_client_restoration_required': True,
              'compiled_experimental_or_upstream_imports_reused': False,
              'exporter_or_native_program_or_counter_executed': False,
              'stock_numeral_theorem_proved': False, 'integrated_project_modified': False}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings'] + report['controls']:
            destination = (frozen / (row['module'] + '.lean') if 'module' in row else
                           inputs / Path(row['path']).relative_to(ROOT))
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            destination.chmod(0o444)
            row['snapshot'] = h.binding(destination)
            require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')), 'Snapshot differs')
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
        verify([row['snapshot'] for row in report['source_bindings'] + report['controls']], True)
        marker.parent.mkdir(exist_ok=True)
        with marker.open('x') as stream:
            stream.write(json.dumps({'format': FORMAT, 'attempt': args.attempt,
                'source_fingerprint': plan['source_fingerprint'], 'source_bindings': report['source_bindings'],
                'controls': report['controls'], 'compiler': report['compiler'],
                'runtime_libraries': report['runtime_libraries'], 'policy': POLICY,
                'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for name in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(name, None)
        env['LEAN_IMPORT_WORKERS'] = '1'
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                       '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / (module + '.olean')),
                       '-i', str(build / (module + '.ilean')), module + '.lean']
            stdout_path, stderr_path = attempt / (module + '.stdout.log'), attempt / (module + '.stderr.log')
            record = {'module': module, 'command': command, 'status': 'running'}
            report['modules'].append(record)
            h.save(report_path, report)
            try:
                record.update(h.child(command, frozen, env, stdout_path, stderr_path, cpu, deadline))
            finally:
                for key, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                    if path.is_file():
                        record[key] = h.binding(path)
                audit = audit_logs(REQUIRED[module], stdout_path, stderr_path)
                record['axiom_audit'] = audit
                objects = all((build / (module + suffix)).is_file() for suffix in ('.olean', '.ilean'))
                record['required_outputs_present'] = objects
                good = (record.get('exit_code') == 0 and record.get('within_limits') is True
                        and audit['passed'] and objects)
                record['status'] = 'passed' if good else 'failed'
                report['observed_axiom_report_count'] = sum(m['axiom_audit']['observed_count'] for m in report['modules'])
                report['observed_unique_axiom_root_count'] = len({r['root'] for m in report['modules']
                                                                for r in m['axiom_audit']['raw_reports']})
                report['accepted_axiom_report_count'] = sum(m['axiom_audit']['observed_count']
                                                           for m in report['modules'] if m['status'] == 'passed')
                h.save(report_path, report)
            require(record['status'] == 'passed', 'Fresh module/axiom/output/resource failure: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']])
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            require(len(snapshots) == len(report['source_bindings']) + len(report['controls']), 'Incomplete snapshots')
            verify(snapshots, True)
            verify([m[key] for m in report['modules'] for key in ('stdout', 'stderr') if key in m])
            require(report['execution_marker'] is not None, 'No execution marker reserved')
            verify([report['execution_marker']], True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected = {str(build / (module + suffix)) for module in MODULES for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = ({row['path'] for row in report['artifacts']} == expected
                                                       and len(report['artifacts']) == 6)
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((m.get('sampled_tree_and_wait4_peak_rss_kib', 0)
                                          for m in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and [m['module'] for m in report['modules']] == MODULES
                  and all(m['status'] == 'passed' for m in report['modules'])
                  and report['accepted_axiom_report_count'] == 134
                  and report['observed_unique_axiom_root_count'] == 134
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['Core_2_roots_checked'] = passed
        report['PropWhen_eq_of_toList_checked'] = passed
        report['cached_memo_6_roots_checked'] = passed
        report['generic_memo_relation_16_roots_checked'] = passed
        report['eventual_empty_8_roots_checked'] = passed
        report['eventual_terminal_trace_9_roots_checked'] = passed
        report['eventual_scoped_functionality_from_actual_empty_runs_checked'] = passed
        report['finite_terminal_trace_constructs_its_own_eventual_witness_checked'] = passed
        report['literal_sort_forwarding_under_new_relational_validity_checked'] = passed
        report['eventual_helper_51_roots_checked'] = passed
        report['literal_contract_1_root_checked'] = passed
        report['conditional_eventual_wrapper_41_roots_checked'] = passed
        report['foundation_126_roots_checked'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path), 'seconds': report['seconds'],
                      'peak_rss_kib': report['peak_child_rss_kib'], 'accepted_roots': report['accepted_axiom_report_count'],
                      'observed_roots': report['observed_axiom_report_count']}, sort_keys=True))
    return 0 if passed else 1


def main():
    global PREVIOUS, HISTORICAL
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean',type=Path,required=True,help='Pinned Lean4.35.0 bin/lean; relocation permitted')
    parser.add_argument('--attempt',default='complete-01')
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])',args.attempt),'Invalid attempt name')
    for row in [PREVIOUS_RUNNER_PIN,PREVIOUS_MANIFEST_PIN]:
        path=local_path(row[0]);require(path.stat().st_size==row[1] and sha(path)==row[2],'Immutable41 control differs')
    spec=importlib.util.spec_from_file_location('foundation_historical_pilot41',PREDECESSOR/'run_gate.py')
    PREVIOUS=importlib.util.module_from_spec(spec);spec.loader.exec_module(PREVIOUS)
    for row in [PREVIOUS.HISTORICAL_RUNNER_PIN,PREVIOUS.HISTORICAL_MANIFEST_PIN]:
        path=local_path(row[0]);require(path.stat().st_size==row[1] and sha(path)==row[2],'Immutable111 control differs')
    spec=importlib.util.spec_from_file_location('foundation_historical_interface111',PREVIOUS.HISTORICAL_RUNNER)
    HISTORICAL=importlib.util.module_from_spec(spec);spec.loader.exec_module(HISTORICAL)
    PREVIOUS.HISTORICAL=HISTORICAL
    require(PREVIOUS.POLICY==HISTORICAL.POLICY==POLICY and PREVIOUS.ALLOWED==HISTORICAL.ALLOWED==ALLOWED,
            'Unchanged resource and axiom policy')
    for path,expected in {**HISTORICAL.FIXED,**PREVIOUS.NEW_FIXED,
                          **{ROOT/p:digest for p,digest in NEW_FIXED.items()}}.items():
        require(path.is_file() and not path.is_symlink() and sha(path)==expected,'Pinned control differs before loading: '+str(path))
    h=HISTORICAL.load(HISTORICAL.HELPER,'cached_forward_resource_helper')
    guard=HISTORICAL.load(HISTORICAL.GUARD,'cached_forward_source_guard')
    require(h.MEMORY_KIB==1048576 and set(h.ALLOWED)==ALLOWED,'Resource/axiom helper contract')
    plan=preflight(args,h,guard)
    if not args.run:
        print(json.dumps({'status':'preflight_passed_no_compiler_executed','module_order':MODULES,
            'physical_module_count':3,'distinct_upstream_origin_count':16,'distinct_project_origin_count':8,
            'distinct_logical_origin_count':24,'source_segment_count':26,
            'required_axiom_report_count':134,'required_unique_axiom_name_count':134,
            'expected_artifact_count':6,'prepared_objects':0,'source_fingerprint':plan['source_fingerprint'],
            'snapshot_count':len(plan['sources'])+len(plan['controls']),'source_manifest':h.binding(MANIFEST)},sort_keys=True))
        return 0
    with HISTORICAL.LOCK.open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return run(args,plan,h)

if __name__=='__main__':
    raise SystemExit(main())
