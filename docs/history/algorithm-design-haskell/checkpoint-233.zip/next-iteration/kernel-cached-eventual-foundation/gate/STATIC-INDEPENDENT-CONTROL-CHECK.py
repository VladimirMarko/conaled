#!/usr/bin/env python3
"""Independent root static review. Parse files; never import or run a gate."""
import ast
import hashlib
import json
import re
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def sha(data):return hashlib.sha256(data).hexdigest()
def strict(pairs):
    result={}
    for k,v in pairs:
        assert k not in result,k
        result[k]=v
    return result
def read(path):return json.loads(path.read_text(),object_pairs_hook=strict)
def binding(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data)}
def checked(row):
    path=ROOT/row['path']
    assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT)
    assert binding(path)=={k:row[k] for k in ('path','bytes','sha256')},row['path']
    return path.read_bytes()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

class StaticValues:
    def __init__(self,tree,path):
        self.nodes={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
        self.cache={'__file__':str(path)}
    def name(self,name):
        if name not in self.cache:self.cache[name]=self.value(self.nodes[name])
        return self.cache[name]
    def value(self,n):
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,ast.Name):return self.name(n.id)
        if isinstance(n,ast.List):return [self.value(x) for x in n.elts]
        if isinstance(n,ast.Tuple):return tuple(self.value(x) for x in n.elts)
        if isinstance(n,ast.Set):return {self.value(x) for x in n.elts}
        if isinstance(n,ast.Dict):
            result={}
            for k,v in zip(n.keys,n.values):
                if k is None:result.update(self.value(v))
                else:
                    key=self.value(k);assert key not in result
                    result[key]=self.value(v)
            return result
        if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Div):
            left,right=self.value(n.left),self.value(n.right)
            assert isinstance(left,Path) and isinstance(right,str)
            return left/right
        if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):return self.value(n.left)+self.value(n.right)
        if isinstance(n,ast.Subscript):return self.value(n.value)[self.value(n.slice)]
        if isinstance(n,ast.Attribute) and n.attr in ('parent','parents'):
            path=self.value(n.value);assert isinstance(path,Path)
            return getattr(path,n.attr)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='Path':
            assert len(n.args)==1 and not n.keywords
            return Path(self.value(n.args[0]))
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='resolve':
            assert not n.args and not n.keywords
            path=self.value(n.func.value);assert isinstance(path,Path)
            return path.resolve()
        raise AssertionError('Unsupported literal expression: '+ast.dump(n))

manifest=read(HERE/'source-manifest.json');mapping=read(HERE/'CONTROL-CORRESPONDENCE.json')
path=HERE/'run_gate.py';oldpath=ROOT/mapping['previous_runner']['path']
assert binding(path)==mapping['current_runner']
assert binding(path)['sha256']=='9c1178c0bfc029991f736e46210c57936d4f763f716bbc535f3ccb4b5da76244'
assert binding(HERE/'source-manifest.json')['sha256']=='11dbcea246364c9951cd1255225c6846936ac3b174610a62fcec16d21df9d12e'
for k in ['previous_runner','previous_manifest','current_runner','current_protocol','current_authoring','author_script']:
    checked(mapping[k])
oldmanifest=read(ROOT/mapping['previous_manifest']['path'])
oldtext,newtext=oldpath.read_text(),path.read_text()
oldtree,newtree=ast.parse(oldtext),ast.parse(newtext)
oldvals,newvals=StaticValues(oldtree,oldpath),StaticValues(newtree,path)
ancestorpath=oldvals.name('HISTORICAL_RUNNER')
ancestor=StaticValues(ast.parse(ancestorpath.read_text()),ancestorpath)
assert newvals.name('POLICY')==oldvals.name('POLICY')==ancestor.name('POLICY')==manifest['policy']
assert newvals.name('ALLOWED')==oldvals.name('ALLOWED')==ancestor.name('ALLOWED')=={'propext','Quot.sound','Classical.choice'}
fixed=[ancestor.name('FIXED'),oldvals.name('NEW_FIXED'),{ROOT/p:h for p,h in newvals.name('NEW_FIXED').items()}]
for collection in fixed:
    for p,digest in collection.items():
        assert p.is_file() and not p.is_symlink() and sha(p.read_bytes())==digest,str(p)

def functions(tree):return {n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
oldfunc,newfunc=functions(oldtree),functions(newtree)
for name in ['require','sha','strict_object','read','local_path','pin_tuple','identity','relative_binding','canonical','array_reference','review_identity','verify','fingerprint','audit_logs']:
    assert ast.dump(oldfunc[name],include_attributes=False)==ast.dump(newfunc[name],include_attributes=False),name
def block(text):return text[text.index('def audit_logs('):text.index('\ndef main():')]
oldblock,newblock=block(oldtext),block(newtext)
for label,value in [('old',oldblock),('new',newblock)]:
    assert {'bytes':len(value.encode()),'sha256':sha(value.encode())}==mapping[label+'_execution_block']
forward=oldblock
for row in mapping['explicit_replacement_contract']:
    assert forward.count(row['before'])==1,row['before']
    forward=forward.replace(row['before'],row['after'])
assert forward==newblock and len(mapping['explicit_replacement_contract'])==16
inverse=newblock
for row in reversed(mapping['explicit_replacement_contract']):
    assert inverse.count(row['after'])==1,row['after']
    inverse=inverse.replace(row['after'],row['before'])
assert inverse==oldblock
segments=[]
for row in mapping['execution_changes']:
    a,b,c,d=[row[k] for k in ['old_start','old_end','new_start','new_end']]
    assert oldblock[a:b]==row['old_text'] and newblock[c:d]==row['new_text']
    segments.append((a,b,c,d))
for row in mapping['unchanged_execution_spans']:
    a,b,c,d=[row[k] for k in ['old_start','old_end','new_start','new_end']]
    assert oldblock[a:b]==newblock[c:d]
    value=oldblock[a:b].encode()
    assert (len(value),sha(value))==(row['bytes'],row['sha256'])
    segments.append((a,b,c,d))
cursor=other=0
for a,b,c,d in sorted(segments):
    assert (a,c)==(cursor,other)
    cursor,other=b,d
assert (cursor,other)==(len(oldblock),len(newblock))
assert len(mapping['execution_changes'])==24 and len(mapping['unchanged_execution_spans'])==25

recovery=read(HERE/'unselected-pre-review-01/RECOVERY.json')
for r in recovery['mappings']:
    checked({'path':r['retained_path'],'bytes':r['bytes'],'sha256':r['sha256']})
first=(HERE/'unselected-pre-review-01/run_gate.py').read_text()
assert block(first)==newblock
fns=functions(ast.parse(first))
def function_text(text,node):return ''.join(text.splitlines(keepends=True)[node.lineno-1:node.end_lineno])
oldverify=function_text(first,fns['verify_assembly']);newverify=function_text(newtext,newfunc['verify_assembly'])
before="last=(first if not desc['bytes'] else data[:desc['byte_end']-1].count(b'\\n')+1)"
after="end=desc['byte_end']; last=data[:end].count(b'\\n')+(0 if end and data[end-1:end]==b'\\n' else 1)"
assert oldverify.count(before)==1 and oldverify.replace(before,after)==newverify
assert recovery['source_key_unchanged']==manifest['source_fingerprint']

modules=newvals.name('MODULES');raw=newvals.name('RAW_REQUIRED');required=newvals.name('REQUIRED')
assert modules==manifest['module_order']==['KernelCompactCore','KernelCachedForward','KernelCachedEventualFoundation']
assert newvals.name('SOURCE_PINS')==[tuple(r[k] for k in ('path','bytes','sha256')) for r in manifest['sources']]
assert newvals.name('EXPECTED_IMPORTS')=={r['module']:r['imports'] for r in manifest['sources']}
assert [len(required[m]) for m in modules]==[2,6,126]
roots=[]
for r in manifest['sources']:
    source=checked(r).decode();module=r['module']
    assert re.findall(r'^import (\S+)',source,re.M)==r['imports']
    assert re.findall(r'^#print axioms (\S+)',source,re.M)==raw[module]==r['raw_source_print_identifiers']
    assert required[module]==r['fully_qualified_roots']
    roots+=required[module]
    if module==modules[2]:
        stack=[];actual=[];blocks=0
        for line in source.splitlines():
            if line.startswith('namespace '):assert not stack;stack.append(line.split()[1]);blocks+=1
            elif line.startswith('end '):assert stack.pop()==line.split()[1]
            elif line.startswith('#print axioms '):actual.append(stack[-1]+'.'+line.split()[2])
        assert not stack and blocks==8 and actual==required[module]
assert len(roots)==len(set(roots))==134 and sum(r['bytes'] for r in manifest['sources'])==530531
fp={'stage':'cached-forward-runs-and-licensed','policy':manifest['policy'],'sources':[{'module':r['module'],'sha256':r['sha256']} for r in manifest['sources']]}
assert sha(canonical(fp))==manifest['source_fingerprint']=='c66c83974aaa9b0b059fc2b136a81a711964933c6d4e939752df41395890f9ce'
bound={}
for row in manifest['sources']+manifest['controls']+[binding(HERE/'source-manifest.json')]:
    checked(row);assert row['path'] not in bound
    bound[row['path']]={k:row[k] for k in ('path','bytes','sha256')}
assert len(bound)==manifest['snapshot_count_including_manifest']==990 and len(manifest['controls'])==986
for row in oldmanifest['sources']+oldmanifest['controls']+[binding(ROOT/mapping['previous_manifest']['path'])]:
    assert bound[row['path']]=={k:row[k] for k in ('path','bytes','sha256')}
for p in fixed[2]:assert bound[p.relative_to(ROOT).as_posix()]==binding(p)

routes={tuple(r['original_context'][k] for k in ('path','bytes','sha256')):r['retained_copy'] for r in manifest['external_review_context_recovery']}
assert len(routes)==6
def review_input(row):
    if row['path'].startswith('../'):row=routes[tuple(row[k] for k in ('path','bytes','sha256'))]
    checked(row);assert bound[row['path']]=={k:row[k] for k in ('path','bytes','sha256')}
def array(row):
    data=json.loads(checked(row['source']))[row['json_field']]
    encoded=canonical(data)
    assert (len(data),len(encoded),sha(encoded))==(row['item_count'],row['canonical_json_bytes'],row['canonical_json_sha256'])
    return data
for row in manifest['historical_context']['exact_field_references'].values():array(row)
contracts=newvals.name('INGREDIENT_CONTRACTS')
assert contracts==manifest['ingredient_review_scopes']
sizes=[]
for scope in contracts:
    for key in ['author_inventory','independent_audit','independent_review']:checked(scope[key])
    author=json.loads(checked(scope['author_inventory']));audit=json.loads(checked(scope['independent_audit']))
    for k,d in [('unchanged_author_array',author),('unchanged_review_array',audit)]:
        ref=scope[k];values=d[ref['field']]
        assert (len(values),sha(canonical(values)))==(ref['count'],ref['canonical_json_sha256'])
        for row in values:review_input(row)
    assert audit['status']==scope['audit_status']
    assert audit['author_input_count_verified']==len(author['inputs']) and audit['direct_input_count']==len(audit['inputs'])
    sizes.append([scope['name'],len(author['inputs']),len(audit['inputs'])])
current=manifest['new_assembly_review']
for key in ['author_inventory','source_audit','source_review']:checked(current[key])
for key in ['author_inputs','review_inputs']:
    for row in array(current[key]):review_input(row)
audit=json.loads(checked(current['source_audit']))
assert audit['checks']==newvals.name('ASSEMBLY_REVIEW_FACTS') and audit['direct_input_count']==917
assert manifest['historical_independent_review_scope_count']==31 and manifest['current_total_separate_independent_review_scope_count']==35
assert manifest['new_ingredient_scopes']==['EventualHelpers','LiteralContract','EventualRecordWrapper']

calls={}
for base in ['PREVIOUS','HISTORICAL']:
    calls[base]=sorted({n.func.attr for n in ast.walk(newtree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id==base})
assert calls=={'PREVIOUS':['check_source','preflight'],'HISTORICAL':['audit_logs','imports','load','verify']}
assert newtext.index("'Immutable41 control differs'")<newtext.index('spec.loader.exec_module(PREVIOUS)')
assert newtext.index("'Immutable111 control differs'")<newtext.index('spec.loader.exec_module(HISTORICAL)')
assert newtext.index("'Pinned control differs before loading: '")<newtext.index('h=HISTORICAL.load')
assert "PREVIOUS.HISTORICAL=HISTORICAL" in newtext
assert "with HISTORICAL.LOCK.open('a+b') as lock:" in newtext
assert "fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)" in newtext
assert not (HERE/'attempts').exists() and not (HERE/'execution-markers').exists()
result={'format':'adwh-root-foundation134-static-control-review-v1','status':'passed_static_review_no_gate_import_or_math','reviewer':'/root','runner':binding(path),'manifest':binding(HERE/'source-manifest.json'),'correspondence':binding(HERE/'CONTROL-CORRESPONDENCE.json'),'source_key':manifest['source_fingerprint'],'fresh_owners':3,'reports':134,'source_bytes':530531,'ordinary_outputs':6,'controls':986,'total_snapshot_bindings':990,'historical_fixed_pins':len(fixed[0]),'pilot41_fixed_pins':len(fixed[1]),'new_fixed_pins':len(fixed[2]),'original31_review_scopes_retained':True,'separate_ingredient_scopes':sizes,'new_assembly_author_review_counts':[916,917],'unique_current_scopes':35,'full_run_block_forward_inverse':True,'explicit_run_replacement_groups':16,'literal_run_diff_changes':24,'literal_run_diff_complements':25,'old_run_block_bytes':len(oldblock.encode()),'new_run_block_bytes':len(newblock.encode()),'first_control_version_preserved':True,'sole_line_end_metadata_correction_checked':True,'first_and_current_run_blocks_literal':True,'historical_call_surface':calls,'resource_compiler_timer_affinity_watchdog_and_integrity_unchanged':True,'root_preflight_and_sole_complete_run_eligible_after_written_review':True}
(HERE/'STATIC-INDEPENDENT-CONTROL-AUDIT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
