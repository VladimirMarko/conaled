# Fresh consolidated eventual foundation: three owners,134 reports

Only root may execute this runner, including metadata preflight. The author has
not imported, AST-checked or executed it. Run without `--run` for the root-only
metadata stage. A separate `--run --attempt complete-01 --lean <pinned-bin/lean>`
selects the sole complete fresh attempt after independent control review.

## Exact selection and mathematical boundary

The physical order is `KernelCompactCore`, `KernelCachedForward`, and
`KernelCachedEventualFoundation`:208582+202799+119150=530531 source bytes;
2+6+126=134 distinct ordered reports; six ordinary `.olean`/`.ilean` outputs.
There are24 current source origins (16 upstream and8 project) and26 source
segments. Core and Cached are byte-for-byte the accepted41 owners. The proof
owner combines seven frozen origins using nine exact import-line comments,
fourteen origin markers and an ordinary header comment. All131 theorem headers,
126 reports, mathematical bodies, namespace blocks and source options are
literal. Generated private identities can change with the physical module;
five explicit private helpers remain within their original namespaces/origins.

The126 report roots span eight original namespaces. The runner retains raw
ordered print identifiers separately and derives the full canonical names from
the actual namespace blocks. It does not prefix short names with the new
physical module name. Duplicate short spellings in different namespaces remain
distinct. Module acceptance is all-or-nothing: a failed combined owner accepts
none of its126 reports, regardless of its diagnostic print prefix.

The selected proof scope is Generic16, Empty8, Atoms9, HelperContract37,
EventualHelpers14, LiteralContract1 and EventualWrapper41. It establishes
conditional actual-helper/result/state/frame and wrapper interfaces alongside
the already accepted eventual empty-state/terminal relations. It does not
construct the whole queens trace, discharge actual installed pins, establish
original native GroupChecked/EnvWF/CSOK, install an optimized kernel, or prove
the concrete stock numeral. All corresponding result flags stay false.

## Exact historical and new reviews

The consumed41 runner and manifest are pinned as immutable files. Only their
metadata `preflight` is called; their `main`/`run` is not called. That preserves
their complete original29-scope validator plus the two owner/pilot scopes, all
original source/annotation/runtime checks, and every historical source array.
No previous source selection is replaced inside that validation.

The new stage separately verifies all six ingredient review arrays verbatim:
owners514/517, Generic405/409, Empty420/421, Helpers576/581, Literal59/60 and
EventualWrapper911/912. The first three overlap inherited scopes. The new
assembly916/917 review is a seventh explicit source scope. Thus the unique
current review census is31+3+1=35, not38. Frozen author metadata which said its
then-future assembly review was pending remains unchanged; the new root review
is separately bound. The independent complete Core lexical census correction
(392→340 versus the older389→337 omission of three retained root spellings)
remains in the original owner scope, not silently rewritten.

The manifest uses exact file/JSON-field references instead of embedding the
whole old manifest. Both directions of all seven origin reconstructions and
the sixteen unchanged spans are checked again by the new metadata layer.
The frozen root static checker/result are retained inputs, not executed by
the new runner. Every reviewed input is in the current read-only snapshot union.
Only the same six explicitly mapped external context tuples may resolve to
the retained exact SDK/upstream copies; old arrays and their original spellings
are unchanged. There is no arbitrary path remapping or prepared-object route.
The unselected stale `CONTROL-CORRESPONDENCE-DRAFT.json` is explicitly excluded.

## Unchanged mathematical execution policy

All three mathematical owners are freshly compiled under one cumulative
30-second wall interval, one selected CPU, one compiler thread, one import
worker,1,024-MiB Lean cap and1,048,576-KiB process-tree/RSS limit. Default
heartbeats, recursion limits and compiler options remain unchanged. The pinned
compiler, all five runtime libraries, resource helper, source guard, axiom parser,
source snapshots, environment cleaning, affinity, watchdog and post-run hashes
retain the accepted41 implementation and pins. The compiler flags are exactly
`-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`.

Core keeps its two reviewed inherited unused-simp linter exceptions; Cached
keeps two strict option blocks. The combined owner keeps eight literal strict
option blocks. No new source, resource or linter exception is introduced.
No C/native/exporter/counter is executed and no experimental object is imported.

Before the first mathematical child, the runner reserves an exclusive permanent
marker for the ordered current module/hash selection under the unchanged
`cached-forward-runs-and-licensed` stage and policy. It checks every inherited
marker directory and adds the consumed41 directory. An attempt rename or control
edit cannot authorize an unchanged-key retry. The coherent three-owner source
assembly has a distinct source fingerprint; no old result is transferred to it.

## Acceptance and explicit execution differences

Exact ordered full axiom names, only `propext`, `Quot.sound`, `Classical.choice`,
empty stderr and no residual stdout/diagnostic are required. Complete success
requires all134 distinct reports, exactly six fresh ordinary artifacts, no
resource/error/integrity/affinity failure, unchanged read-only sources/controls
and runtime, cumulative elapsed time at most30 seconds and RSS within the cap.
No module gets a separate budget. Sources and mathematical checks are not split.

`CONTROL-CORRESPONDENCE.json` records the complete literal old/new run-block
diff, full inverse and all complements. Differences are selection/census/report
scope bookkeeping,41→134 report acceptance,10→6 artifacts, and the added prior
marker directory. The compiler/watchdog/timer/affinity/integrity behavior is
unchanged; whole-block byte identity is not claimed. No speedup or fit is assumed.
