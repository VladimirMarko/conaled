#!/usr/bin/env python3
"""Author exact source/metadata controls only; never import or execute a gate.

This script reads immutable text and JSON metadata, writes a new runner and its
reviewable correspondence, and hashes files. It performs no Lean, mathematical
evaluation, preflight, saved-result reading program, or runtime experiment.
"""
from pathlib import Path
import difflib
import hashlib
import json
import pprint
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
FOUNDATION = HERE.parent
PREVIOUS = ROOT / 'next-iteration/kernel-cached-eventual-pilot/gate'

def read(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def binding(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data)}
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def ref(path,field):
    value=read(path)[field]; data=canonical(value)
    return {'source':binding(path),'json_field':field,'item_count':len(value),
            'canonical_json_bytes':len(data),'canonical_json_sha256':sha(data)}
def dump(name,value): (HERE/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

previous_text=(PREVIOUS/'run_gate.py').read_text()
previous_manifest=read(PREVIOUS/'source-manifest.json')
census=read(FOUNDATION/'SOURCE-CENSUS.json')
mapping=read(FOUNDATION/'SOURCE-CORRESPONDENCE.json')
scope=read(FOUNDATION/'PRIVATE-AND-SCOPE-AUDIT.json')
ingredients=read(FOUNDATION/'INGREDIENT-REVIEW-SCOPES.json')
author=read(FOUNDATION/'SOURCE-INVENTORY.json')
audit=read(FOUNDATION/'SOURCE-AUDIT.json')
policy=previous_manifest['policy']
modules=[r['module'] for r in census['physical_modules']]
sources=[]
raw_required={}
required={}
for row in census['physical_modules']:
    src=row['source']; text=(ROOT/src['path']).read_text()
    raw=re.findall(r'^\s*#print\s+axioms\s+(\S+)',text,re.M)
    raw_required[row['module']]=raw
    required[row['module']]=row['ordered_report_roots']
    sources.append({**src,'module':row['module'],'imports':row['imports'],
        'raw_source_print_identifiers':raw,'fully_qualified_roots':row['ordered_report_roots'],
        'module_format':False,'expected_default_output_suffixes':['.olean','.ilean']})
assert [len(required[m]) for m in modules]==[2,6,126]
assert len(set(n for names in required.values() for n in names))==134
assert sum(s['bytes'] for s in sources)==530531

foundation_fixed=[p for p in sorted(FOUNDATION.iterdir()) if p.is_file()]
previous_context=[PREVIOUS/n for n in [
 'run_gate.py','source-manifest.json','PROTOCOL.md','AUTHORING.md','CONTROL-CORRESPONDENCE.json',
 'INDEPENDENT-CONTROL-REVIEW.md','STATIC-INDEPENDENT-CONTROL-CHECK.py',
 'STATIC-INDEPENDENT-CONTROL-AUDIT.json','RESULT-AND-NEXT.md',
 'ROOT-EXECUTION-RECEIPT.json','SNAPSHOT-RECOVERY.json']]
previous_context += [PREVIOUS/'attempts/complete-01/report.json']
previous_context += sorted((PREVIOUS/'attempts/complete-01').glob('*.log'))
previous_context += sorted((PREVIOUS/'execution-markers').glob('*.json'))
fixed={p.relative_to(ROOT).as_posix():binding(p)['sha256'] for p in foundation_fixed+previous_context}

header='''#!/usr/bin/env python3
"""Fresh consolidated eventual foundation134. Root alone executes; no Lean without --run."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREDECESSOR = ROOT / 'next-iteration/kernel-cached-eventual-pilot/gate'
FOUNDATION = HERE.parent
FORMAT = 'adwh-kernel-cached-eventual-foundation134-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-cached-eventual-foundation134-manifest-v1'
PREVIOUS = None
HISTORICAL = None
'''
constants={
 'POLICY':policy,'ALLOWED':{'propext','Quot.sound','Classical.choice'},
 'PREVIOUS_RUNNER_PIN':tuple(binding(PREVIOUS/'run_gate.py').values()),
 'PREVIOUS_MANIFEST_PIN':tuple(binding(PREVIOUS/'source-manifest.json').values()),
 'MODULES':modules,'SOURCE_PINS':[tuple(s[k] for k in ('path','bytes','sha256')) for s in sources],
 'EXPECTED_IMPORTS':{r['module']:r['imports'] for r in sources},
 'RAW_REQUIRED':raw_required,'REQUIRED':required,'NEW_FIXED':fixed,
 'ASSEMBLY_REVIEW_FACTS':audit['checks'],
 'INGREDIENT_CONTRACTS':[{**row,
    'audit_status':read(ROOT/row['independent_audit']['path'])['status']}
    for row in ingredients['scopes']],
}
for name,value in constants.items(): header += name+' = '+pprint.pformat(value,width=110,sort_dicts=False)+'\n'
utilities=previous_text[previous_text.index('def require('):previous_text.index('def check_source(')]

validation=r'''
def check_source(row, guard):
    module = row['module']
    if module in MODULES[:2]:
        return PREVIOUS.check_source(row, guard)
    path = local_path(row['path'])
    code = guard.check_lean_source(path, path.read_text())
    require(HISTORICAL.imports(code) == row['imports'] == ['KernelCachedForward'], 'Foundation direct import')
    strict = [('autoImplicit','false'),('warningAsError','true'),('Elab.async','false')]
    require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)',code) == strict*8, 'Eight literal strict option scopes')
    require(not re.search(r'^\s*module\s*$|^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b',code,re.M),
            'Unexpected module or elaborator execution command')
    require(not re.search(r'^\s*(?:public\b|meta\s+import|import\s+all)|@\[(?:expose|no_expose)\]',code,re.M),
            'Unsupported legacy visibility command')
    raw = re.findall(r'^\s*#print\s+axioms\s+(\S+)',code,re.M)
    require(raw == RAW_REQUIRED[module] == row['raw_source_print_identifiers'], 'Literal ordered print spellings')
    stack=[]; actual=[]; blocks=0
    for line in code.splitlines():
        opening=re.fullmatch(r'namespace\s+(\S+)\s*',line)
        closing=re.fullmatch(r'end\s+(\S+)\s*',line)
        printed=re.fullmatch(r'#print\s+axioms\s+(\S+)\s*',line)
        if opening:
            require(not stack, 'Unexpected nested namespace in reviewed physical owner')
            stack.append(opening.group(1)); blocks+=1
        elif closing:
            require(stack and stack.pop()==closing.group(1), 'Exact closed namespace boundary')
        elif printed:
            name=printed.group(1)
            require(stack, 'Expected original namespace at each foundation print')
            actual.append(name if name.startswith(('ADWH.','ConLeche.')) else stack[-1]+'.'+name)
    require(not stack and blocks==8 and actual==REQUIRED[module]==row['fully_qualified_roots']
            and len(actual)==len(set(actual))==126, 'Actual canonical roots, not physical-module prefixes')
    return code

def verify_scope(row, recovery, h):
    inventory=read(local_path(row['author_inventory']['path']))
    audit=read(local_path(row['independent_audit']['path']))
    for name in ('author_inventory','independent_audit','independent_review'):
        identity(row[name],h)
    for field,document in [('unchanged_author_array',inventory),('unchanged_review_array',audit)]:
        descriptor=row[field]; values=document[descriptor['field']]
        require(len(values)==descriptor['count']
                and hashlib.sha256(canonical(values)).hexdigest()==descriptor['canonical_json_sha256'],
                'Exact original ingredient input array: '+row['name'])
        for item in values: review_identity(item,recovery,h)
    require(audit['status']==row['audit_status']
            and audit['author_input_count_verified']==len(inventory['inputs'])
            and audit['direct_input_count']==len(audit['inputs'])
            and row['original_scope_or_selection_rebased'] is False,
            'Original distinct ingredient review remains passed against its own original inputs')
    return inventory['inputs']+audit['inputs']

def verify_assembly(manifest, h):
    mapping=read(FOUNDATION/'SOURCE-CORRESPONDENCE.json')
    census=read(FOUNDATION/'SOURCE-CENSUS.json')
    scope=read(FOUNDATION/'PRIVATE-AND-SCOPE-AUDIT.json')
    require(mapping['candidate']=={key:manifest['sources'][2][key] for key in ('path','bytes','sha256')}
            and mapping['origin_count']==len(mapping['origins'])==7
            and mapping['header_import_edit_count']==9
            and mapping['origin_boundary_comment_count']==14
            and mapping['unchanged_complement_count_including_empty_header_spans']==16
            and mapping['source_bodies_statements_options_namespace_boundaries_and_reports_literal'] is True
            and mapping['complete_forward_and_inverse_reconstruction_verified'] is True
            and mapping['new_mathematical_declarations_or_proofs'] is False
            and mapping['current_Core_and_Cached_changed'] is False, 'Exact assembly scope')
    candidate=local_path(mapping['candidate']['path']).read_bytes()
    output=bytearray(mapping['header_literal'].encode()); edits=0; complements=0
    literal_headers=[]; original_raw=[]
    for number,row in enumerate(mapping['origins'],1):
        require(row['order']==number, 'Exact origin order')
        identity(row['source'],h); original=local_path(row['source']['path']).read_bytes()
        transformed=bytearray(); cursor=0
        require(len(row['edits'])==row['edit_count']
                and len(row['unchanged_complements'])==len(row['edits'])+1, 'Complete origin edit partition')
        for change in row['edits']:
            a,b=change['original_start'],change['original_end']
            require(cursor<=a<=b<=len(original) and original[a:b]==change['before'].encode()
                    and re.fullmatch(r'import \S+\n',change['before'])
                    and change['after']=='-- [assembly import internalized] '+change['before'],
                    'Only an exact header import is commented')
            transformed.extend(original[cursor:a])
            require(change['transformed_start']==len(transformed), 'Transformed import start')
            transformed.extend(change['after'].encode())
            require(change['transformed_end']==len(transformed), 'Transformed import end')
            cursor=b; edits+=1
        transformed.extend(original[cursor:]); transformed=bytes(transformed)
        require(len(transformed)==row['transformed_bytes']
                and hashlib.sha256(transformed).hexdigest()==row['transformed_sha256'], 'Full transformed origin identity')
        inverse=transformed
        for change in reversed(row['edits']):
            a,b=change['transformed_start'],change['transformed_end']
            require(inverse[a:b]==change['after'].encode(), 'Inverse actual import span')
            inverse=inverse[:a]+change['before'].encode()+inverse[b:]
        require(inverse==original and row['inverse_reconstructs_complete_original'] is True, 'Full inverse origin')
        output.extend(row['start_marker'].encode())
        require(len(output)==row['physical_body_start'], 'Exact physical origin start')
        for change in row['edits']:
            require(change['physical_start']==len(output)+change['transformed_start']
                    and change['physical_end']==len(output)+change['transformed_end'], 'Physical edit relocation')
        last_o=last_t=0
        for index,gap in enumerate(row['unchanged_complements']):
            old,new=gap['original'],gap['transformed']
            stop_o=(row['edits'][index]['original_start'] if index<len(row['edits']) else len(original))
            stop_t=(row['edits'][index]['transformed_start'] if index<len(row['edits']) else len(transformed))
            require((old['byte_start'],old['byte_end'])==(last_o,stop_o)
                    and (new['byte_start'],new['byte_end'])==(last_t,stop_t), 'Exhaustive unchanged complement')
            a=original[last_o:stop_o]; b=transformed[last_t:stop_t]
            require(a==b and len(a)==old['bytes']==new['bytes']
                    and hashlib.sha256(a).hexdigest()==old['sha256']==new['sha256']
                    and gap['physical_start']==len(output)+last_t and gap['physical_end']==len(output)+stop_t,
                    'Literal unchanged complement with physical relocation')
            for desc,data in [(old,original),(new,transformed)]:
                first=data[:desc['byte_start']].count(b'\n')+1
                last=(first if not desc['bytes'] else data[:desc['byte_end']-1].count(b'\n')+1)
                require(desc['line_start']==first and desc['line_end']==last, 'Exact complement line bounds')
            if index<len(row['edits']):
                last_o=row['edits'][index]['original_end']; last_t=row['edits'][index]['transformed_end']
            complements+=1
        output.extend(transformed)
        require(len(output)==row['physical_body_end'], 'Exact physical origin end')
        output.extend(row['end_marker'].encode())
        literal_headers.extend(re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',original))
        original_raw.extend(re.findall(rb'^\s*#print\s+axioms\s+(\S+)',original,re.M))
    require(bytes(output)==candidate and edits==9 and complements==16, 'Complete forward assembly')
    require(literal_headers==re.findall(rb'(?ms)^(?:private )?theorem\s+.*?\s*:=',candidate)
            and len(literal_headers)==131
            and original_raw==re.findall(rb'^\s*#print\s+axioms\s+(\S+)',candidate,re.M)
            and len(original_raw)==126, 'All literal theorem statements and report spellings')
    require(scope['namespace_block_count']==8 and scope['explicit_private_theorem_count']==5
            and scope['private_spelling_used_across_origin_boundary'] is False
            and scope['explicit_generated_private_or_auxiliary_names_in_source'] is False
            and scope['all_explicit_theorem_header_count']==131 and scope['exact_public_report_count']==126,
            'Separate reviewed private and namespace boundary')
    require(census['selected_physical_sources']==[{k:r[k] for k in ('path','bytes','sha256')} for r in manifest['sources']]
            and census['ordered_report_counts']==[2,6,126] and census['ordered_report_count']==134
            and census['distinct_report_count']==134 and census['source_bytes']==530531
            and census['physical_owner_count']==3 and census['default_ordinary_output_count']==6
            and census['logical_origins']==manifest['logical_origins']
            and census['distinct_current_source_origin_count']==24 and census['source_segment_count']==26,
            'Exact current complete source/import/root/origin census')
    for actual,row in zip(census['physical_modules'],manifest['sources']):
        require(actual['module']==row['module'] and actual['imports']==row['imports']
                and actual['ordered_report_roots']==row['fully_qualified_roots'], 'Full rooted owner census')
    return {'complete_forward_inverse_origin_count':7,'import_comment_edits':9,
            'literal_complements':16,'literal_theorem_headers':131,'literal_proof_reports':126,
            'namespace_blocks':8,'private_helpers_local_to_origins':5,
            'source_correspondence':relative_binding(FOUNDATION/'SOURCE-CORRESPONDENCE.json',h)}

def preflight(args,h,guard):
    # Exact earlier metadata validation, never the old run/main or any compiler.
    previous_plan=PREVIOUS.preflight(args,h,guard)
    previous_manifest=read(PREDECESSOR/'source-manifest.json')
    manifest=read(MANIFEST)
    require(manifest['format']==MANIFEST_FORMAT
            and manifest['status']=='frozen_ready_for_independent_root_control_review'
            and manifest['policy']==POLICY==PREVIOUS.POLICY==HISTORICAL.POLICY
            and manifest['module_order']==MODULES and manifest['prepared_objects']==[]
            and manifest['export_targets']==[] and manifest['ordered_report_counts']==[2,6,126]
            and manifest['required_axiom_report_count']==manifest['required_unique_axiom_name_count']==134
            and manifest['selected_physical_source_bytes']==530531 and manifest['expected_artifact_count']==6,
            'Fresh three-owner134 complete selection')
    history=manifest['historical_context']
    require(pin_tuple(history['runner'])==PREVIOUS_RUNNER_PIN
            and pin_tuple(history['manifest'])==PREVIOUS_MANIFEST_PIN
            and history['validator']=='preflight'
            and history['historical_review_scope_count']==31
            and previous_manifest['current_total_separate_independent_review_scope_count']==31
            and manifest['historical_independent_review_scope_count']==31
            and manifest['current_total_separate_independent_review_scope_count']==35
            and manifest['historical_reviews_rebased'] is False,
            'All prior review scopes preserved without rebasing or double counting')
    for field,reference in history['exact_field_references'].items():
        require(reference==array_reference(PREDECESSOR/'source-manifest.json',field,h), 'Exact old manifest field reference')
    require(set(history['exact_field_references'])=={'historical_context','new_separate_review_scopes',
                'external_review_context_recovery','owner_declaration_census_correction'}, 'Complete inherited context references')
    recovery=read(ROOT/'next-iteration/kernel-cached-eventual-owner-slice/EXTERNAL-CONTEXT-RECOVERY.json')['mappings']
    require(manifest['external_review_context_recovery']==recovery and len(recovery)==6, 'Six exact external copy routes')
    sources=[];seen=set()
    require(len(manifest['sources'])==3,'Exactly three physical sources')
    for row,module,pin in zip(manifest['sources'],MODULES,SOURCE_PINS):
        require(row['module']==module and pin_tuple(row)==pin
                and row['imports']==EXPECTED_IMPORTS[module]
                and row['raw_source_print_identifiers']==RAW_REQUIRED[module]
                and row['fully_qualified_roots']==REQUIRED[module]
                and row['module_format'] is False and row['expected_default_output_suffixes']==['.olean','.ilean'],
                'Exact source and canonical ordered reports')
        require(all(name in seen or name=='Init' or name.startswith(('Init.','Std.')) for name in row['imports']),
                'Unselected or forward experimental import')
        check_source(row,guard); sources.append({**identity(row,h),'module':module,'imports':row['imports']});seen.add(module)
    require(len(set(n for names in REQUIRED.values() for n in names))==134
            and sum(r['bytes'] for r in sources)==530531 and manifest['source_fingerprint']==fingerprint(sources),
            'Full distinct root, source byte and permanent key census')
    ingredients=read(FOUNDATION/'INGREDIENT-REVIEW-SCOPES.json')
    require(manifest['ingredient_review_scopes']==INGREDIENT_CONTRACTS
            and ingredients['scopes']==[{k:v for k,v in row.items() if k!='audit_status'} for row in INGREDIENT_CONTRACTS]
            and ingredients['ingredient_scope_count']==6
            and ingredients['new_assembly_independent_review_status']=='pending'
            and manifest['overlapping_historical_ingredient_scopes']==['ReducedOwners','GenericMemo','EventualEmptyAtoms']
            and manifest['new_ingredient_scopes']==['EventualHelpers','LiteralContract','EventualRecordWrapper'],
            'Six original ingredient scopes, historical pending author context retained')
    inputs=[]
    for row in INGREDIENT_CONTRACTS: inputs.extend(verify_scope(row,recovery,h))
    author=read(FOUNDATION/'SOURCE-INVENTORY.json');audit=read(FOUNDATION/'SOURCE-AUDIT.json')
    current=manifest['new_assembly_review']
    for key,name in [('author_inventory','SOURCE-INVENTORY.json'),('source_audit','SOURCE-AUDIT.json'),
                     ('source_review','SOURCE-REVIEW.md')]:
        require(current[key]==relative_binding(FOUNDATION/name,h),'Exact new independent assembly review identity')
    require(current['author_inputs']==array_reference(FOUNDATION/'SOURCE-INVENTORY.json','inputs',h)
            and current['review_inputs']==array_reference(FOUNDATION/'SOURCE-AUDIT.json','inputs',h)
            and len(author['inputs'])==author['input_count']==916
            and len(audit['inputs'])==audit['direct_input_count']==917
            and audit['author_input_count_verified']==916
            and audit['author_inventory']==current['author_inventory'] and audit['source_review']==current['source_review']
            and audit['status']=='passed_source_only_exact_assembly' and audit['reviewer']=='/root'
            and audit['checks']==ASSEMBLY_REVIEW_FACTS
            and audit['source']=={k:manifest['sources'][2][k] for k in ('path','bytes','sha256')}
            and audit['old_acceptance_transferred'] is False and audit['source_or_author_metadata_changed'] is False
            and audit['compiler_preflight_gate_or_mathematical_execution'] is False,
            'Root independent917-input exact assembly scope')
    inputs += author['inputs']+audit['inputs']
    for row in inputs: review_identity(row,recovery,h)
    assembly=verify_assembly(manifest,h)
    for key in ('logical_origins','complete_origin_source_rows'):
        require(manifest[key][:len(previous_manifest[key])]==previous_manifest[key], 'Original20 origins remain literal')
    require(len(manifest['logical_origins'])==len(set(manifest['logical_origins']))==24
            and len(manifest['complete_origin_source_rows'])==24
            and manifest['complete_origin_source_rows'][20:]==[mapping['source'] for mapping in
                read(FOUNDATION/'SOURCE-CORRESPONDENCE.json')['origins'][3:]], 'Four added original proof origins')
    for row in manifest['complete_origin_source_rows']: identity(row,h);inputs.append(row)
    require(manifest['root_only_preflight_and_run'] is True
            and manifest['all_current_cached_runtime_declarations_preserved'] is True
            and manifest['actual_reference_state_is_empty_CState'] is True
            and manifest['conditional_record_wrapper_only'] is True
            and manifest['whole_query_cached_success_claimed'] is False
            and manifest['original_GroupChecked_claimed'] is False
            and manifest['stock_numeral_theorem_claimed'] is False
            and manifest['measured_cost_benefit_or_budget_fit_claimed_before_run'] is False,
            'Conditional helper/wrapper acceptance without query or installation claims')
    controls=[{**identity(row,h),'role':row['role']} for row in manifest['controls']]
    require(len({r['path'] for r in controls})==len(controls)
            and len({r['role'] for r in controls})==len(controls),'Unique control bindings')
    controls.append({**h.binding(MANIFEST),'role':'manifest'})
    bound={row['path']:row for row in sources+controls}
    require(len(bound)==len(sources)+len(controls),'No selected source/control overlap')
    for row in previous_plan['sources']+previous_plan['controls']:
        require(row['path'] in bound and all(bound[row['path']][k]==row[k] for k in ('bytes','sha256')),
                'Prior source/control omitted from new read-only snapshot union')
    for row in inputs:
        actual=review_identity(row,recovery,h)
        require(actual['path'] in bound and all(bound[actual['path']][k]==actual[k] for k in ('bytes','sha256')),
                'Reviewed input omitted from current snapshot union')
    for path in [local_path(p) for p in NEW_FIXED]+[Path(__file__).resolve(),HERE/'PROTOCOL.md',HERE/'AUTHORING.md',
            HERE/'CONTROL-CORRESPONDENCE.json',HERE/'AUTHOR-CONTROLS.py']:
        require(str(path) in bound,'Current exact control omitted: '+str(path))
    require(manifest['snapshot_count_including_manifest']==len(sources)+len(controls),'Complete snapshot count')
    verify(sources+controls+[previous_plan['compiler']]+previous_plan['runtime'])
    return {'sources':sources,'controls':controls,'roots':REQUIRED,'source_fingerprint':fingerprint(sources),
        'compiler':previous_plan['compiler'],'runtime':previous_plan['runtime'],
        'historical_context':history,'new_review_scopes':{'ingredients':manifest['ingredient_review_scopes'],
            'assembly':manifest['new_assembly_review']},'external_context_recovery':recovery,
        'owner_omissions':previous_plan['owner_omissions'],'primary_interval_counts':previous_plan['primary_interval_counts'],
        'logical_origins':manifest['logical_origins'],'origin_sources':manifest['complete_origin_source_rows'],
        'foundation_assembly':assembly}

'''

run=previous_text[previous_text.index('def audit_logs('):previous_text.index('\ndef main():')]
replacements=[
 ("# Every historical no-retry directory is retained, with interface111 appended.",
  "# Every historical no-retry directory is retained, with the consumed41 pilot appended."),
 ("[PREDECESSOR] + [getattr(HISTORICAL, name) for name in prior_names]",
  "[PREDECESSOR, PREVIOUS.PREDECESSOR] + [getattr(HISTORICAL, name) for name in prior_names]"),
 ("'physical_module_count': 5", "'physical_module_count': 3"),
 ("'distinct_project_origin_count': 4", "'distinct_project_origin_count': 8"),
 ("'distinct_logical_origin_count': 20, 'source_segment_count': 22", "'distinct_logical_origin_count': 24, 'source_segment_count': 26"),
 ("'historical_independent_review_scope_count': 29", "'historical_independent_review_scope_count': 31"),
 ("'total_separate_independent_review_scope_count': 31", "'total_separate_independent_review_scope_count': 35"),
 ("'owner_omission_correspondence': plan['owner_omissions'],", "'owner_omission_correspondence': plan['owner_omissions'],\n              'foundation_assembly_correspondence': plan['foundation_assembly'],"),
 ("'required_axiom_report_count': 41, 'required_unique_axiom_name_count': 41", "'required_axiom_report_count': 134, 'required_unique_axiom_name_count': 134"),
 ("'expected_artifact_count': 10", "'expected_artifact_count': 6"),
 ("'literal_sort_forwarding_under_new_relational_validity_checked': False,", "'literal_sort_forwarding_under_new_relational_validity_checked': False,\n              'eventual_helper_51_roots_checked': False,\n              'literal_contract_1_root_checked': False,\n              'conditional_eventual_wrapper_41_roots_checked': False,\n              'foundation_126_roots_checked': False,"),
 ("'terminal_fragment_only': True", "'terminal_fragment_only': False, 'conditional_record_wrapper_only': True"),
 ("and len(report['artifacts']) == 10", "and len(report['artifacts']) == 6"),
 ("report['accepted_axiom_report_count'] == 41", "report['accepted_axiom_report_count'] == 134"),
 ("report['observed_unique_axiom_root_count'] == 41", "report['observed_unique_axiom_root_count'] == 134"),
 ("report['literal_sort_forwarding_under_new_relational_validity_checked'] = passed", "report['literal_sort_forwarding_under_new_relational_validity_checked'] = passed\n        report['eventual_helper_51_roots_checked'] = passed\n        report['literal_contract_1_root_checked'] = passed\n        report['conditional_eventual_wrapper_41_roots_checked'] = passed\n        report['foundation_126_roots_checked'] = passed"),
]
for before,after in replacements:
    assert run.count(before)==1,(before,run.count(before))
    run=run.replace(before,after)

main=r'''
def main():
    global PREVIOUS, HISTORICAL
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean',type=Path,required=True,help='Pinned Lean4.35.0 bin/lean; relocation permitted')
    parser.add_argument('--attempt',default='complete-01')
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    require(re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])',args.attempt),'Invalid attempt name')
    for row in [PREVIOUS_RUNNER_PIN,PREVIOUS_MANIFEST_PIN]:
        path=local_path(row[0]);require(path.stat().st_size==row[1] and sha(path)==row[2],'Immutable41 control differs')
    spec=importlib.util.spec_from_file_location('foundation_historical_pilot41',PREDECESSOR/'run_gate.py')
    PREVIOUS=importlib.util.module_from_spec(spec);spec.loader.exec_module(PREVIOUS)
    for row in [PREVIOUS.HISTORICAL_RUNNER_PIN,PREVIOUS.HISTORICAL_MANIFEST_PIN]:
        path=local_path(row[0]);require(path.stat().st_size==row[1] and sha(path)==row[2],'Immutable111 control differs')
    spec=importlib.util.spec_from_file_location('foundation_historical_interface111',PREVIOUS.HISTORICAL_RUNNER)
    HISTORICAL=importlib.util.module_from_spec(spec);spec.loader.exec_module(HISTORICAL)
    PREVIOUS.HISTORICAL=HISTORICAL
    require(PREVIOUS.POLICY==HISTORICAL.POLICY==POLICY and PREVIOUS.ALLOWED==HISTORICAL.ALLOWED==ALLOWED,
            'Unchanged resource and axiom policy')
    for path,expected in {**HISTORICAL.FIXED,**PREVIOUS.NEW_FIXED,
                          **{ROOT/p:digest for p,digest in NEW_FIXED.items()}}.items():
        require(path.is_file() and not path.is_symlink() and sha(path)==expected,'Pinned control differs before loading: '+str(path))
    h=HISTORICAL.load(HISTORICAL.HELPER,'cached_forward_resource_helper')
    guard=HISTORICAL.load(HISTORICAL.GUARD,'cached_forward_source_guard')
    require(h.MEMORY_KIB==1048576 and set(h.ALLOWED)==ALLOWED,'Resource/axiom helper contract')
    plan=preflight(args,h,guard)
    if not args.run:
        print(json.dumps({'status':'preflight_passed_no_compiler_executed','module_order':MODULES,
            'physical_module_count':3,'distinct_upstream_origin_count':16,'distinct_project_origin_count':8,
            'distinct_logical_origin_count':24,'source_segment_count':26,
            'required_axiom_report_count':134,'required_unique_axiom_name_count':134,
            'expected_artifact_count':6,'prepared_objects':0,'source_fingerprint':plan['source_fingerprint'],
            'snapshot_count':len(plan['sources'])+len(plan['controls']),'source_manifest':h.binding(MANIFEST)},sort_keys=True))
        return 0
    with HISTORICAL.LOCK.open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return run(args,plan,h)

if __name__=='__main__':
    raise SystemExit(main())
'''
(HERE/'run_gate.py').write_text(header+'\n'+utilities+'\n'+validation+run+main)

protocol='''# Fresh consolidated eventual foundation: three owners,134 reports

Only root may execute this runner, including metadata preflight. The author has
not imported, AST-checked or executed it. Run without `--run` for the root-only
metadata stage. A separate `--run --attempt complete-01 --lean <pinned-bin/lean>`
selects the sole complete fresh attempt after independent control review.

## Exact selection and mathematical boundary

The physical order is `KernelCompactCore`, `KernelCachedForward`, and
`KernelCachedEventualFoundation`:208582+202799+119150=530531 source bytes;
2+6+126=134 distinct ordered reports; six ordinary `.olean`/`.ilean` outputs.
There are24 current source origins (16 upstream and8 project) and26 source
segments. Core and Cached are byte-for-byte the accepted41 owners. The proof
owner combines seven frozen origins using nine exact import-line comments,
fourteen origin markers and an ordinary header comment. All131 theorem headers,
126 reports, mathematical bodies, namespace blocks and source options are
literal. Generated private identities can change with the physical module;
five explicit private helpers remain within their original namespaces/origins.

The126 report roots span eight original namespaces. The runner retains raw
ordered print identifiers separately and derives the full canonical names from
the actual namespace blocks. It does not prefix short names with the new
physical module name. Duplicate short spellings in different namespaces remain
distinct. Module acceptance is all-or-nothing: a failed combined owner accepts
none of its126 reports, regardless of its diagnostic print prefix.

The selected proof scope is Generic16, Empty8, Atoms9, HelperContract37,
EventualHelpers14, LiteralContract1 and EventualWrapper41. It establishes
conditional actual-helper/result/state/frame and wrapper interfaces alongside
the already accepted eventual empty-state/terminal relations. It does not
construct the whole queens trace, discharge actual installed pins, establish
original native GroupChecked/EnvWF/CSOK, install an optimized kernel, or prove
the concrete stock numeral. All corresponding result flags stay false.

## Exact historical and new reviews

The consumed41 runner and manifest are pinned as immutable files. Only their
metadata `preflight` is called; their `main`/`run` is not called. That preserves
their complete original29-scope validator plus the two owner/pilot scopes, all
original source/annotation/runtime checks, and every historical source array.
No previous source selection is replaced inside that validation.

The new stage separately verifies all six ingredient review arrays verbatim:
owners514/517, Generic405/409, Empty420/421, Helpers576/581, Literal59/60 and
EventualWrapper911/912. The first three overlap inherited scopes. The new
assembly916/917 review is a seventh explicit source scope. Thus the unique
current review census is31+3+1=35, not38. Frozen author metadata which said its
then-future assembly review was pending remains unchanged; the new root review
is separately bound. The independent complete Core lexical census correction
(392→340 versus the older389→337 omission of three retained root spellings)
remains in the original owner scope, not silently rewritten.

The manifest uses exact file/JSON-field references instead of embedding the
whole old manifest. Both directions of all seven origin reconstructions and
the sixteen unchanged spans are checked again by the new metadata layer.
The frozen root static checker/result are retained inputs, not executed by
the new runner. Every reviewed input is in the current read-only snapshot union.
Only the same six explicitly mapped external context tuples may resolve to
the retained exact SDK/upstream copies; old arrays and their original spellings
are unchanged. There is no arbitrary path remapping or prepared-object route.
The unselected stale `CONTROL-CORRESPONDENCE-DRAFT.json` is explicitly excluded.

## Unchanged mathematical execution policy

All three mathematical owners are freshly compiled under one cumulative
30-second wall interval, one selected CPU, one compiler thread, one import
worker,1,024-MiB Lean cap and1,048,576-KiB process-tree/RSS limit. Default
heartbeats, recursion limits and compiler options remain unchanged. The pinned
compiler, all five runtime libraries, resource helper, source guard, axiom parser,
source snapshots, environment cleaning, affinity, watchdog and post-run hashes
retain the accepted41 implementation and pins. The compiler flags are exactly
`-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`.

Core keeps its two reviewed inherited unused-simp linter exceptions; Cached
keeps two strict option blocks. The combined owner keeps eight literal strict
option blocks. No new source, resource or linter exception is introduced.
No C/native/exporter/counter is executed and no experimental object is imported.

Before the first mathematical child, the runner reserves an exclusive permanent
marker for the ordered current module/hash selection under the unchanged
`cached-forward-runs-and-licensed` stage and policy. It checks every inherited
marker directory and adds the consumed41 directory. An attempt rename or control
edit cannot authorize an unchanged-key retry. The coherent three-owner source
assembly has a distinct source fingerprint; no old result is transferred to it.

## Acceptance and explicit execution differences

Exact ordered full axiom names, only `propext`, `Quot.sound`, `Classical.choice`,
empty stderr and no residual stdout/diagnostic are required. Complete success
requires all134 distinct reports, exactly six fresh ordinary artifacts, no
resource/error/integrity/affinity failure, unchanged read-only sources/controls
and runtime, cumulative elapsed time at most30 seconds and RSS within the cap.
No module gets a separate budget. Sources and mathematical checks are not split.

`CONTROL-CORRESPONDENCE.json` records the complete literal old/new run-block
diff, full inverse and all complements. Differences are selection/census/report
scope bookkeeping,41→134 report acceptance,10→6 artifacts, and the added prior
marker directory. The compiler/watchdog/timer/affinity/integrity behavior is
unchanged; whole-block byte identity is not claimed. No speedup or fit is assumed.
'''
(HERE/'PROTOCOL.md').write_text(protocol)
authoring='''# Control authoring boundary

The author wrote a distinct complete134 control selection from the frozen41
runner using static source and metadata reads only. The author did not import,
compile, AST-check, preflight or execute any runner, Lean source, saved-result
reader, exporter, counter, profiler or mathematical program. Root independently
reviews controls before the metadata stage and sole mathematical attempt.

The authoring script copies the old enforcement block text and applies explicit
bounded string replacements only to selection/report/acceptance bookkeeping and
the added marker directory. The correspondence contains each actual changed
span and every unchanged complement, with a full inverse check. It is not an
assertion that the whole block is literal.

The original41 metadata validator is called unchanged with its own globals and
manifest; its old run/main is never invoked. The new validator checks the current
sources, three physical owners,134 canonical full roots, all seven origin
reconstructions, the original ingredient arrays, and the new917-input review.
It snapshots the union without copying the old manifest's nested structures
into a new historical schema. It does not execute the root static source checker.

No frozen source, old control, consumed key, original review array or old result
is modified. Only exact known external tuples map to retained source copies.
The original31 scopes, six separately named overlapping ingredient scopes and
the new assembly scope remain distinguishable;35 unique scopes are selected.
The unselected stale41 correspondence draft is not an input. All new gate files,
the current root source review and static-review result are included in the
read-only union. Actual runtime behavior and default resource policy are fixed.
'''
(HERE/'AUTHORING.md').write_text(authoring)

old_run=previous_text[previous_text.index('def audit_logs('):previous_text.index('\ndef main():')]
new_text=(HERE/'run_gate.py').read_text()
new_run=new_text[new_text.index('def audit_logs('):new_text.index('\ndef main():')]
ops=difflib.SequenceMatcher(a=old_run,b=new_run,autojunk=False).get_opcodes()
changes=[];complements=[]
for kind,a,b,c,d in ops:
    item={'old_start':a,'old_end':b,'new_start':c,'new_end':d,
          'old_text':old_run[a:b],'new_text':new_run[c:d]}
    if kind=='equal': complements.append({'old_start':a,'old_end':b,'new_start':c,'new_end':d,
                                         'bytes':len(old_run[a:b].encode()),'sha256':sha(old_run[a:b].encode())})
    else: changes.append(item)
forward=old_run
for row in reversed(changes):forward=forward[:row['old_start']]+row['new_text']+forward[row['old_end']:]
inverse=new_run
for row in reversed(changes):inverse=inverse[:row['new_start']]+row['old_text']+inverse[row['new_end']:]
assert forward==new_run and inverse==old_run
history={'runner':binding(PREVIOUS/'run_gate.py'),'manifest':binding(PREVIOUS/'source-manifest.json'),
    'validator':'preflight','historical_review_scope_count':31,
    'exact_field_references':{field:ref(PREVIOUS/'source-manifest.json',field) for field in [
        'historical_context','new_separate_review_scopes','external_review_context_recovery','owner_declaration_census_correction']},
    'old_main_or_run_called':False,'old_review_arrays_or_selection_globals_mutated':False,
    'prior_HISTORICAL_dependency_handle_initialized':True,
    'old_complete_preflight_checks_retained':True}
new_review={'author_inventory':binding(FOUNDATION/'SOURCE-INVENTORY.json'),
    'source_audit':binding(FOUNDATION/'SOURCE-AUDIT.json'),'source_review':binding(FOUNDATION/'SOURCE-REVIEW.md'),
    'author_inputs':ref(FOUNDATION/'SOURCE-INVENTORY.json','inputs'),
    'review_inputs':ref(FOUNDATION/'SOURCE-AUDIT.json','inputs')}
correspondence={'format':'adwh-foundation134-exact-control-correspondence-v1',
    'status':'frozen_ready_for_independent_root_control_review',
    'previous_runner':binding(PREVIOUS/'run_gate.py'),'previous_manifest':binding(PREVIOUS/'source-manifest.json'),
    'current_runner':binding(HERE/'run_gate.py'),'current_protocol':binding(HERE/'PROTOCOL.md'),
    'current_authoring':binding(HERE/'AUTHORING.md'),'author_script':binding(Path(__file__).resolve()),
    'metadata_delegation':history,'new_assembly_review':new_review,
    'old_execution_block':{'bytes':len(old_run.encode()),'sha256':sha(old_run.encode())},
    'new_execution_block':{'bytes':len(new_run.encode()),'sha256':sha(new_run.encode())},
    'execution_changes':changes,'unchanged_execution_spans':complements,
    'explicit_replacement_contract':[{'before':a,'after':b} for a,b in replacements],
    'full_forward_and_inverse_execution_text_verified':True,
    'whole_execution_block_claimed_literal':False,
    'unchanged_resource_compiler_timer_affinity_watchdog_and_integrity_behavior':True,
    'current_report_bookkeeping_differences':'3 owners,24 origins,26 segments,35 distinct scopes,134 reports,6 artifacts; conditional helpers/wrapper flags',
    'previous_marker_directory_added':True,'unselected_stale41_draft_included':False,
    'gate_preflight_compiler_or_mathematical_program_executed_by_author':False}
dump('CONTROL-CORRESPONDENCE.json',correspondence)

recovery=read(ROOT/'next-iteration/kernel-cached-eventual-owner-slice/EXTERNAL-CONTEXT-RECOVERY.json')['mappings']
all_inputs={}
def add(row):
    item={k:row[k] for k in ('path','bytes','sha256')}
    if item['path'].startswith('../'):
        matches=[r['retained_copy'] for r in recovery if r['original_context']==item]
        assert len(matches)==1,item
        item=matches[0]
    assert not Path(item['path']).is_absolute() and '..' not in Path(item['path']).parts,item
    actual=binding(ROOT/item['path']);assert actual==item,(actual,item)
    if item['path'] in all_inputs:assert all_inputs[item['path']]==item
    all_inputs[item['path']]=item
for row in previous_manifest['sources']+previous_manifest['controls']:add(row)
add(binding(PREVIOUS/'source-manifest.json'))
for row in author['inputs']+audit['inputs']:add(row)
for ingredient in ingredients['scopes']:
    for key in ('author_inventory','independent_audit','independent_review'):add(ingredient[key])
    for key in ('author_inventory','independent_audit'):
        for row in read(ROOT/ingredient[key]['path'])['inputs']:add(row)
for path in foundation_fixed+previous_context:add(binding(path))
for path in [HERE/'run_gate.py',HERE/'PROTOCOL.md',HERE/'AUTHORING.md',HERE/'CONTROL-CORRESPONDENCE.json',Path(__file__).resolve()]:add(binding(path))
for row in sources:add(row)
selected={r['path'] for r in sources}
controls=[{**r,'role':'bound-input-'+str(i).zfill(4)} for i,r in enumerate(
    (all_inputs[p] for p in sorted(all_inputs) if p not in selected),1)]
origin_rows=previous_manifest['complete_origin_source_rows']+[r['source'] for r in mapping['origins'][3:]]
assert len(origin_rows)==24
fingerprint_body={'stage':'cached-forward-runs-and-licensed','policy':policy,
    'sources':[{'module':s['module'],'sha256':s['sha256']} for s in sources]}
manifest={
 'format':'adwh-kernel-cached-eventual-foundation134-manifest-v1',
 'status':'frozen_ready_for_independent_root_control_review','policy':policy,
 'module_order':modules,'sources':sources,'prepared_objects':[],'export_targets':[],
 'ordered_report_counts':[2,6,126],'required_axiom_report_count':134,'required_unique_axiom_name_count':134,
 'selected_physical_source_bytes':530531,'expected_artifact_count':6,
 'logical_origins':census['logical_origins'],'complete_origin_source_rows':origin_rows,
 'distinct_upstream_origin_count':16,'distinct_project_origin_count':8,'distinct_logical_origin_count':24,
 'source_segment_count':26,'historical_context':history,
 'historical_independent_review_scope_count':31,'current_total_separate_independent_review_scope_count':35,
 'historical_reviews_rebased':False,'ingredient_review_scopes':constants['INGREDIENT_CONTRACTS'],
 'overlapping_historical_ingredient_scopes':['ReducedOwners','GenericMemo','EventualEmptyAtoms'],
 'new_ingredient_scopes':['EventualHelpers','LiteralContract','EventualRecordWrapper'],
 'new_assembly_review':new_review,'external_review_context_recovery':recovery,
 'root_only_preflight_and_run':True,'all_current_cached_runtime_declarations_preserved':True,
 'actual_reference_state_is_empty_CState':True,'conditional_record_wrapper_only':True,
 'whole_query_cached_success_claimed':False,'original_GroupChecked_claimed':False,'stock_numeral_theorem_claimed':False,
 'measured_cost_benefit_or_budget_fit_claimed_before_run':False,
 'source_fingerprint':sha(canonical(fingerprint_body)),
 'controls':controls,'snapshot_count_including_manifest':len(sources)+len(controls)+1,
 'unselected_stale41_draft_included':False,
}
dump('source-manifest.json',manifest)
for name in ('run_gate.py','PROTOCOL.md','AUTHORING.md','CONTROL-CORRESPONDENCE.json','source-manifest.json'):
    print(json.dumps(binding(HERE/name)))
print(json.dumps({'source_key':manifest['source_fingerprint'],'snapshot_count':manifest['snapshot_count_including_manifest'],
                  'controls':len(controls),'source_count':len(sources),'new_runner_not_executed':True}))
