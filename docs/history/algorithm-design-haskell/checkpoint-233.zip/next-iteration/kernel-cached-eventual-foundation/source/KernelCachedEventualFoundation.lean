/-
Exact physical assembly of seven frozen eventual cached proof origins.
Only the recorded header imports are internalized. Core and Cached remain separate.
All source bodies, namespaces, strict options and 126 reports are preserved.
-/

/- BEGIN EXACT ORIGIN 1: KernelCachedMemoRelation -/
import KernelCachedForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Relation-parametric validity of the actual normal-form memos

Two relations describe exact Expr results. Their map invariant covers every
actual entry, and result uniqueness is used only at an explicitly supplied
depth where the current key is well scoped. No uniqueness is required for a
key that cannot be scoped at any depth.

Only whnfC and noncheap whnfCoreC are covered. The original cached knot,
state layout, expression-only keys, body callbacks and all runtime branches
remain unchanged. The positive-fuel forwarding theorems retain genuine
miss-body success and returned-state preservation premises. Auxiliary
invariants have their own explicit insertion frame.

Source candidate only. No compiler, guard, evaluator or gate has run for
this source. This abstraction supplies no independent semantic relation.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedMemoRelation

open ConLeche
open ConLeche.Cached

/-- A relation identifies exact output syntax when the shared expression key
is scoped at the supplied current depth. The relation itself is not keyed by
depth; all map entries carry the same relation across later cache reuse. -/
def ScopedFunctional (relation : Expr → Expr → Prop) : Prop :=
  ∀ query left right depth, Expr.wscopedB depth query = true →
    relation query left → relation query right → left = right

/-- Every actual hit is related. No reachability, scoping or literal-only
filter weakens the map quantifier. -/
def MapValid (relation : Expr → Expr → Prop)
    (cache : Std.HashMap Expr Expr) : Prop :=
  ∀ query value, cache[query]? = some value → relation query value

theorem map_empty (relation : Expr → Expr → Prop) :
    MapValid relation (∅ : Std.HashMap Expr Expr) := by
  intro query value hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

/-- The inserted expression/value pair needs its own relation witness;
the unchanged entries keep their previous witnesses. -/
theorem map_insert (relation : Expr → Expr → Prop)
    (cache : Std.HashMap Expr Expr) (query value : Expr)
    (valid : MapValid relation cache) (backing : relation query value) :
    MapValid relation (cache.insert query value) := by
  intro key result hit
  rw [Std.HashMap.getElem?_insert] at hit
  by_cases same : query == key
  · rw [ite_eq_left same] at hit
    cases hit
    have keySame : query = key := eq_of_beq same
    cases keySame
    exact backing
  · rw [ite_eq_right same] at hit
    exact valid key result hit

theorem map_hit_value (relation : Expr → Expr → Prop)
    (functional : ScopedFunctional relation) (cache : Std.HashMap Expr Expr)
    (query cached expected : Expr) (depth : Nat)
    (valid : MapValid relation cache)
    (queryScoped : Expr.wscopedB depth query = true)
    (hit : cache[query]? = some cached)
    (backing : relation query expected) : cached = expected := by
  exact functional query cached expected depth queryScoped
    (valid query cached hit) backing

/-- Exactly the two expression-valued normal-form maps. Cheap head, inference,
annotation, defeq, converted constants and helper/level maps are outside this
property and require any additional invariant independently. -/
structure NFValid (fullRelation headRelation : Expr → Expr → Prop)
    (state : CState) : Prop where
  whnfC : MapValid fullRelation state.whnfC
  whnfCoreC : MapValid headRelation state.whnfCoreC

theorem nf_empty (fullRelation headRelation : Expr → Expr → Prop) :
    NFValid fullRelation headRelation ({} : CState) := by
  exact ⟨map_empty fullRelation, map_empty headRelation⟩

theorem nf_frame (fullRelation headRelation : Expr → Expr → Prop)
    (before after : CState) (valid : NFValid fullRelation headRelation before)
    (full : after.whnfC = before.whnfC)
    (head : after.whnfCoreC = before.whnfCoreC) :
    NFValid fullRelation headRelation after := by
  constructor
  · change MapValid fullRelation after.whnfC
    rw [full]
    exact valid.whnfC
  · change MapValid headRelation after.whnfCoreC
    rw [head]
    exact valid.whnfCoreC

theorem nf_insert_full (fullRelation headRelation : Expr → Expr → Prop)
    (state : CState) (query value : Expr)
    (valid : NFValid fullRelation headRelation state)
    (backing : fullRelation query value) :
    NFValid fullRelation headRelation
      { state with whnfC := state.whnfC.insert query value } := by
  exact ⟨map_insert fullRelation _ query value valid.whnfC backing, valid.whnfCoreC⟩

theorem nf_insert_head (fullRelation headRelation : Expr → Expr → Prop)
    (state : CState) (query value : Expr)
    (valid : NFValid fullRelation headRelation state)
    (backing : headRelation query value) :
    NFValid fullRelation headRelation
      { state with whnfCoreC := state.whnfCoreC.insert query value } := by
  exact ⟨valid.whnfC, map_insert headRelation _ query value valid.whnfCoreC backing⟩

theorem full_cache_value (fullRelation headRelation : Expr → Expr → Prop)
    (functional : ScopedFunctional fullRelation)
    (state : CState) (query cached expected : Expr) (depth : Nat)
    (valid : NFValid fullRelation headRelation state)
    (queryScoped : Expr.wscopedB depth query = true)
    (hit : state.whnfC[query]? = some cached)
    (backing : fullRelation query expected) : cached = expected := by
  exact map_hit_value fullRelation functional state.whnfC query cached expected
    depth valid.whnfC queryScoped hit backing

theorem head_cache_value (fullRelation headRelation : Expr → Expr → Prop)
    (functional : ScopedFunctional headRelation)
    (state : CState) (query cached expected : Expr) (depth : Nat)
    (valid : NFValid fullRelation headRelation state)
    (queryScoped : Expr.wscopedB depth query = true)
    (hit : state.whnfCoreC[query]? = some cached)
    (backing : headRelation query expected) : cached = expected := by
  exact map_hit_value headRelation functional state.whnfCoreC query cached expected
    depth valid.whnfCoreC queryScoped hit backing

/-- Both covered maps are actually cleared. The surviving state fields are
not asserted valid by this theorem. -/
theorem nf_flushed (fullRelation headRelation : Expr → Expr → Prop) (state : CState) :
    NFValid fullRelation headRelation state.flushed := by
  exact ⟨map_empty fullRelation, map_empty headRelation⟩

theorem flushed_full_miss (state : CState) (query : Expr) :
    state.flushed.whnfC[query]? = none := by
  simp [CState.flushed]

theorem flushed_head_miss (state : CState) (query : Expr) :
    state.flushed.whnfCoreC[query]? = none := by
  simp [CState.flushed]

theorem flush_starts_unseeded (fullRelation headRelation : Expr → Expr → Prop)
    (state : CState) (query : Expr) :
    flushC state = .ok ((), state.flushed) ∧
    NFValid fullRelation headRelation state.flushed ∧
    state.flushed.whnfC[query]? = none ∧
    state.flushed.whnfCoreC[query]? = none := by
  exact ⟨rfl, nf_flushed fullRelation headRelation state,
    flushed_full_miss state query, flushed_head_miss state query⟩

/-- Independent auxiliary preservation under each actual memo insertion.
This does not assert preservation through a miss body or through flush. -/
structure MemoFrame (auxiliary : CState → Prop) : Prop where
  whnfC : ∀ state query value, auxiliary state →
    auxiliary { state with whnfC := state.whnfC.insert query value }
  whnfCoreC : ∀ state query value, auxiliary state →
    auxiliary { state with whnfCoreC := state.whnfCoreC.insert query value }

theorem true_memo_frame : MemoFrame (fun _ => True) := by
  exact ⟨fun _ _ _ _ => trivial, fun _ _ _ _ => trivial⟩

/-- A hit uses exact-result functionality at the supplied scoped depth. A
miss uses the real predecessor-fuel body and its returned state, followed by
the original detach/insert memo equation. No body success is inferred from
the relation witness alone. -/
theorem full_forward_of_body (fullRelation headRelation : Expr → Expr → Prop)
    (functional : ScopedFunctional fullRelation)
    (mode : CheckMode) (fe : FEnv) (fuel depth : Nat) (query value : Expr)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (backing : fullRelation query value)
    (queryScoped : Expr.wscopedB depth query = true)
    (state : CState) (valid : NFValid fullRelation headRelation state)
    (auxValid : auxiliary state)
    (bodyForward : state.whnfC[query]? = none →
      ∃ final, whnfBodyI (coreKnotI mode fe fuel) fe depth query state =
        .ok (value, final) ∧ NFValid fullRelation headRelation final ∧ auxiliary final) :
    ∃ final, (coreKnotI mode fe (fuel + 1)).whnf depth query state =
      .ok (value, final) ∧ NFValid fullRelation headRelation final ∧ auxiliary final := by
  cases cached : state.whnfC[query]? with
  | some prior =>
    have same : prior = value := full_cache_value fullRelation headRelation functional
      state query prior value depth valid queryScoped cached backing
    subst prior
    exact ⟨state, KernelCachedForward.whnf_hit mode fe fuel depth query value state cached,
      valid, auxValid⟩
  | none =>
    obtain ⟨final, run, finalValid, finalAux⟩ := bodyForward cached
    exact ⟨{ final with whnfC := final.whnfC.insert query value },
      KernelCachedForward.whnf_miss mode fe fuel depth query value state final cached run,
      nf_insert_full fullRelation headRelation final query value finalValid backing,
      frame.whnfC final query value finalAux⟩

/-- The original noncheap head entry, including its positive-fuel guard and
the exact state returned by its miss body. The cheap memo is not covered. -/
theorem head_forward_of_body (fullRelation headRelation : Expr → Expr → Prop)
    (functional : ScopedFunctional headRelation)
    (mode : CheckMode) (fe : FEnv) (fuel depth : Nat) (query value : Expr)
    (auxiliary : CState → Prop) (frame : MemoFrame auxiliary)
    (backing : headRelation query value)
    (queryScoped : Expr.wscopedB depth query = true)
    (state : CState) (valid : NFValid fullRelation headRelation state)
    (auxValid : auxiliary state)
    (bodyForward : state.whnfCoreC[query]? = none →
      ∃ final, whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query state =
        .ok (value, final) ∧ NFValid fullRelation headRelation final ∧ auxiliary final) :
    ∃ final, (coreKnotI mode fe (fuel + 1)).whnfCore false depth query state =
      .ok (value, final) ∧ NFValid fullRelation headRelation final ∧ auxiliary final := by
  cases cached : state.whnfCoreC[query]? with
  | some prior =>
    have same : prior = value := head_cache_value fullRelation headRelation functional
      state query prior value depth valid queryScoped cached backing
    subst prior
    exact ⟨state, KernelCachedForward.whnfCore_hit mode fe fuel depth query value state cached,
      valid, auxValid⟩
  | none =>
    obtain ⟨final, run, finalValid, finalAux⟩ := bodyForward cached
    exact ⟨{ final with whnfCoreC := final.whnfCoreC.insert query value },
      KernelCachedForward.whnfCore_miss mode fe fuel depth query value state final cached run,
      nf_insert_head fullRelation headRelation final query value finalValid backing,
      frame.whnfCoreC final query value finalAux⟩

#print axioms map_empty
#print axioms map_insert
#print axioms map_hit_value
#print axioms nf_empty
#print axioms nf_frame
#print axioms nf_insert_full
#print axioms nf_insert_head
#print axioms full_cache_value
#print axioms head_cache_value
#print axioms nf_flushed
#print axioms flushed_full_miss
#print axioms flushed_head_miss
#print axioms flush_starts_unseeded
#print axioms true_memo_frame
#print axioms full_forward_of_body
#print axioms head_forward_of_body

end ADWH.Experiments.Chapter15.KernelCachedMemoRelation
/- END EXACT ORIGIN 1: KernelCachedMemoRelation -/

/- BEGIN EXACT ORIGIN 2: KernelCachedEventualEmpty -/
-- [assembly import internalized] import KernelCachedMemoRelation

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Exact memo values from eventual runs of the actual cached evaluator

The reference state is the genuine empty CState. Both relations quantify over
every sufficiently large actual knot fuel and every depth at which the key is
well scoped. The final state may depend on that fuel and depth. Only the exact
returned Expr is part of the relation.

A run-only memo miss equation does not require validity of the inserted value.
It can therefore turn a strictly smaller finite body derivation into the root's
eventual witness. That witness is used afterward by relation-parametric memo
forwarding for arbitrary valid initial maps. No whole-query success, pure
normalization, monotonicity, installation fact or seeded state is assumed.

This is a source-only pilot. Its imports still need a separately reviewed
physical runtime selection before any claim of removing the pure owner or of
fresh default-resource acceptance.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualEmpty

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation

/-- The same expression-key relation is used at every later scoped depth.
No uniqueness is demanded when the key cannot be scoped at any depth. -/
def Eventual (run : Nat → Nat → Expr → CheckCM Expr)
    (query value : Expr) : Prop :=
  ∃ threshold, ∀ fuel depth, threshold ≤ fuel →
    Expr.wscopedB depth query = true →
    ∃ final : CState, run fuel depth query {} = .ok (value, final)

def Full (mode : CheckMode) (fe : FEnv) : Expr → Expr → Prop :=
  Eventual (fun fuel depth query => (coreKnotI mode fe fuel).whnf depth query)

def Head (mode : CheckMode) (fe : FEnv) : Expr → Expr → Prop :=
  Eventual (fun fuel depth query =>
    (coreKnotI mode fe fuel).whnfCore false depth query)

abbrev NF (mode : CheckMode) (fe : FEnv) (state : CState) : Prop :=
  NFValid (Full mode fe) (Head mode fe) state

/-- Both witnesses run the identical actual action from the identical empty
state at one common future fuel. Equality of the returned pair identifies its
first component even though the witness states were independently chosen. -/
theorem eventual_functional (run : Nat → Nat → Expr → CheckCM Expr) :
    ScopedFunctional (Eventual run) := by
  intro query left right depth queryScoped leftValid rightValid
  obtain ⟨leftThreshold, leftRun⟩ := leftValid
  obtain ⟨rightThreshold, rightRun⟩ := rightValid
  obtain ⟨leftState, leftResult⟩ := leftRun (max leftThreshold rightThreshold)
    depth (Nat.le_max_left leftThreshold rightThreshold) queryScoped
  obtain ⟨rightState, rightResult⟩ := rightRun (max leftThreshold rightThreshold)
    depth (Nat.le_max_right leftThreshold rightThreshold) queryScoped
  have pairSame : (left, leftState) = (right, rightState) :=
    Except.ok.inj (leftResult.symm.trans rightResult)
  exact congrArg Prod.fst pairSame

theorem full_functional (mode : CheckMode) (fe : FEnv) :
    ScopedFunctional (Full mode fe) :=
  eventual_functional _

theorem head_functional (mode : CheckMode) (fe : FEnv) :
    ScopedFunctional (Head mode fe) :=
  eventual_functional _

theorem empty_valid (mode : CheckMode) (fe : FEnv) : NF mode fe {} :=
  nf_empty (Full mode fe) (Head mode fe)

/-- This operational equation has no root relation or final invariant premise.
The original memo writes its result after the supplied actual body run. -/
theorem full_miss_from_empty (mode : CheckMode) (fe : FEnv)
    (fuel depth : Nat) (query value : Expr) (afterBody : CState)
    (bodyRun : whnfBodyI (coreKnotI mode fe fuel) fe depth query {} =
      .ok (value, afterBody)) :
    (coreKnotI mode fe (fuel + 1)).whnf depth query {} =
      .ok (value, { afterBody with whnfC := afterBody.whnfC.insert query value }) := by
  apply KernelCachedForward.whnf_miss mode fe fuel depth query value {} afterBody
  · change (∅ : Std.HashMap Expr Expr)[query]? = none
    simp only [Std.HashMap.getElem?_empty]
  · exact bodyRun

theorem head_miss_from_empty (mode : CheckMode) (fe : FEnv)
    (fuel depth : Nat) (query value : Expr) (afterBody : CState)
    (bodyRun : whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query {} =
      .ok (value, afterBody)) :
    (coreKnotI mode fe (fuel + 1)).whnfCore false depth query {} =
      .ok (value, { afterBody with whnfCoreC := afterBody.whnfCoreC.insert query value }) := by
  apply KernelCachedForward.whnfCore_miss mode fe fuel depth query value {} afterBody
  · change (∅ : Std.HashMap Expr Expr)[query]? = none
    simp only [Std.HashMap.getElem?_empty]
  · exact bodyRun

/-- A body equation at each sufficiently large predecessor fuel produces the
root witness. The finite-trace leaf supplies these equations by strict body
induction; this lemma does not obtain them from the current full call. -/
theorem full_eventual_of_body_runs (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (threshold : Nat)
    (bodyRuns : ∀ fuel depth, threshold ≤ fuel →
      Expr.wscopedB depth query = true →
      ∃ afterBody : CState,
        whnfBodyI (coreKnotI mode fe fuel) fe depth query {} =
          .ok (value, afterBody)) :
    Full mode fe query value := by
  refine ⟨threshold + 1, ?_⟩
  intro fuel depth enough queryScoped
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have bodyEnough : threshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    obtain ⟨afterBody, bodyRun⟩ := bodyRuns predecessor depth bodyEnough queryScoped
    exact ⟨{ afterBody with whnfC := afterBody.whnfC.insert query value },
      full_miss_from_empty mode fe predecessor depth query value afterBody bodyRun⟩

theorem head_eventual_of_body_runs (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (threshold : Nat)
    (bodyRuns : ∀ fuel depth, threshold ≤ fuel →
      Expr.wscopedB depth query = true →
      ∃ afterBody : CState,
        whnfCoreBodyI mode (coreKnotI mode fe fuel) fe false depth query {} =
          .ok (value, afterBody)) :
    Head mode fe query value := by
  refine ⟨threshold + 1, ?_⟩
  intro fuel depth enough queryScoped
  cases fuel with
  | zero => omega
  | succ predecessor =>
    have bodyEnough : threshold ≤ predecessor := Nat.le_of_succ_le_succ enough
    obtain ⟨afterBody, bodyRun⟩ := bodyRuns predecessor depth bodyEnough queryScoped
    exact ⟨{ afterBody with whnfCoreC := afterBody.whnfCoreC.insert query value },
      head_miss_from_empty mode fe predecessor depth query value afterBody bodyRun⟩

#print axioms eventual_functional
#print axioms full_functional
#print axioms head_functional
#print axioms empty_valid
#print axioms full_miss_from_empty
#print axioms head_miss_from_empty
#print axioms full_eventual_of_body_runs
#print axioms head_eventual_of_body_runs

end ADWH.Experiments.Chapter15.KernelCachedEventualEmpty
/- END EXACT ORIGIN 2: KernelCachedEventualEmpty -/

/- BEGIN EXACT ORIGIN 3: KernelCachedEventualAtoms -/
-- [assembly import internalized] import KernelCachedEventualEmpty

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# A finite constructor pilot for actual empty-state memo semantics

The trace has separate full/head commands and full/head local loops. Every
memo constructor contains only a strictly smaller body trace and its real
local-budget bound. No constructor carries a root result-relation witness or
a cached-success equation. The full-loop constructor delegates to a strictly
smaller head trace for the same query.

The interpreter first obtains the root's empty-state run from the body IH with
the trivial auxiliary invariant. Its final insertion is an operational step
and needs no proof that the inserted value is already related. Only after
constructing the eventual witness does the interpreter invoke generic memo
forwarding for arbitrary valid initial maps and auxiliary frames.

This pilot covers terminal head constructors and full terminal results,
including natural literals and sorts. It does not cover beta, delta, native
arithmetic, Nat recursion, helper writes or the whole queens query. Those
extensions must supply their actual body equations and state preservation.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualAtoms

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation
open KernelCachedEventualEmpty

/-- Exactly the terminal constructor cases of the actual head step. Raw
bound variables, applications, lets and projections are excluded. -/
def HeadAtom : Expr → Prop
  | .sort _ | .fvar .. | .forallE .. | .lam .. | .const .. | .lit _ => True
  | _ => False

/-- These heads cannot enter either native arithmetic or definition unfolding.
A constant head is deliberately absent because it may unfold. -/
def FullTerminal : Expr → Prop
  | .sort _ | .fvar .. | .forallE .. | .lam .. | .lit _ => True
  | _ => False

private theorem full_terminal_head_atom (expression : Expr)
    (terminal : FullTerminal expression) : HeadAtom expression := by
  cases expression <;> try cases terminal
  all_goals trivial

def Forward (mode : CheckMode) (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) : Prop :=
  ∀ state, NF mode fe state → auxiliary state →
    ∃ final, action state = .ok (value, final) ∧
      NF mode fe final ∧ auxiliary final

inductive Command where
  | full (query : Expr)
  | head (query : Expr)
  | fullLoop (query : Expr)
  | headLoop (query : Expr)

def Runs (mode : CheckMode) (fe : FEnv) (auxiliary : CState → Prop)
    (command : Command) (value : Expr) (knot localBound : Nat) : Prop :=
  match command with
  | .full query =>
    ∀ fuel depth, knot ≤ fuel → Expr.wscopedB depth query = true →
      Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnf depth query) value
  | .head query =>
    ∀ fuel depth, knot ≤ fuel → Expr.wscopedB depth query = true →
      Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnfCore false depth query) value
  | .fullLoop query =>
    ∀ fuel depth budget, knot ≤ fuel → localBound ≤ budget →
      Expr.wscopedB depth query = true →
      Forward mode fe auxiliary
        (whnfLoopI (coreKnotI mode fe fuel) fe depth budget query) value
  | .headLoop query =>
    ∀ fuel depth budget, knot ≤ fuel → localBound ≤ budget →
      Expr.wscopedB depth query = true →
      Forward mode fe auxiliary
        (whnfCoreLoopI mode (coreKnotI mode fe fuel) fe false depth budget query) value

/-- Finite evidence of body structure, not evidence assuming the root run. -/
inductive Trace : Command → Expr → Nat → Nat → Prop where
  | headAtom (expression : Expr) (atom : HeadAtom expression) :
      Trace (.headLoop expression) expression 0 1
  | headMemo (query value : Expr) (knot localBound : Nat)
      (fits : localBound ≤ whnfCoreLoopFuel)
      (body : Trace (.headLoop query) value knot localBound) :
      Trace (.head query) value (knot + 1) 0
  | fullTerminal (query value : Expr) (knot : Nat)
      (terminal : FullTerminal value)
      (head : Trace (.head query) value knot 0) :
      Trace (.fullLoop query) value knot 1
  | fullMemo (query value : Expr) (knot localBound : Nat)
      (fits : localBound ≤ whnfLoopFuel)
      (body : Trace (.fullLoop query) value knot localBound) :
      Trace (.full query) value (knot + 1) 0

theorem head_loop_atom (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (depth budget : Nat) (expression : Expr)
    (atom : HeadAtom expression) (state : CState) :
    whnfCoreLoopI mode callbacks fe false depth (budget + 1) expression state =
      .ok (expression, state) := by
  change whnfCoreStepI mode callbacks fe false depth
    (whnfCoreLoopI mode callbacks fe false depth budget) expression state = _
  cases expression <;> try cases atom
  all_goals rfl

/-- The exact state returned by the head callback threads through the two
actual terminal branches. No relation or cache premise is used here. -/
theorem full_loop_terminal_of_head (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget : Nat) (query value : Expr) (terminal : FullTerminal value)
    (state afterHead : CState)
    (headRun : callbacks.whnfCore false depth query state = .ok (value, afterHead)) :
    whnfLoopI callbacks fe depth (budget + 1) query state =
      .ok (value, afterHead) := by
  change whnfStepI callbacks fe depth (whnfLoopI callbacks fe depth budget) query state = _
  unfold whnfStepI
  simp only [Bind.bind, StateT.bind, headRun, Except.bind]
  cases value <;> try cases terminal
  all_goals rfl

/-- The body IH is available for every auxiliary invariant. In the two memo
cases it is first used with True at the genuine empty state; afterward it is
used with the caller's auxiliary invariant at the caller's actual state. -/
theorem trace_runs (mode : CheckMode) (fe : FEnv)
    (command : Command) (value : Expr) (knot localBound : Nat)
    (trace : Trace command value knot localBound) :
    ∀ auxiliary : CState → Prop, MemoFrame auxiliary →
      Runs mode fe auxiliary command value knot localBound := by
  induction trace with
  | headAtom expression atom =>
    intro auxiliary _frame fuel depth budget _enoughKnot enoughLocal _queryScoped
      state valid auxiliaryValid
    cases budget with
    | zero => omega
    | succ previous =>
      exact ⟨state, head_loop_atom mode (coreKnotI mode fe fuel) fe depth previous
        expression atom state, valid, auxiliaryValid⟩
  | headMemo query value knot localBound fits _body ih =>
    have backing : Head mode fe query value :=
      head_eventual_of_body_runs mode fe query value knot (by
        intro fuel depth enough queryScoped
        obtain ⟨afterBody, bodyRun, _finalValid, _finalAuxiliary⟩ :=
          ih (fun _ => True) true_memo_frame fuel depth whnfCoreLoopFuel
            enough fits queryScoped {} (empty_valid mode fe) trivial
        exact ⟨afterBody, bodyRun⟩)
    intro auxiliary frame fuel depth enough queryScoped state valid auxiliaryValid
    cases fuel with
    | zero => omega
    | succ predecessor =>
      have bodyEnough : knot ≤ predecessor := Nat.le_of_succ_le_succ enough
      exact KernelCachedMemoRelation.head_forward_of_body
        (Full mode fe) (Head mode fe) (head_functional mode fe)
        mode fe predecessor depth query value auxiliary frame backing queryScoped
        state valid auxiliaryValid (fun _miss =>
          ih auxiliary frame predecessor depth whnfCoreLoopFuel bodyEnough fits
            queryScoped state valid auxiliaryValid)
  | fullTerminal query value knot terminal _head ih =>
    intro auxiliary frame fuel depth budget enoughKnot enoughLocal queryScoped
      state valid auxiliaryValid
    cases budget with
    | zero => omega
    | succ previous =>
      obtain ⟨afterHead, headRun, headValid, headAuxiliary⟩ :=
        ih auxiliary frame fuel depth enoughKnot queryScoped state valid auxiliaryValid
      exact ⟨afterHead, full_loop_terminal_of_head (coreKnotI mode fe fuel) fe
        depth previous query value terminal state afterHead headRun,
        headValid, headAuxiliary⟩
  | fullMemo query value knot localBound fits _body ih =>
    have backing : Full mode fe query value :=
      full_eventual_of_body_runs mode fe query value knot (by
        intro fuel depth enough queryScoped
        obtain ⟨afterBody, bodyRun, _finalValid, _finalAuxiliary⟩ :=
          ih (fun _ => True) true_memo_frame fuel depth whnfLoopFuel
            enough fits queryScoped {} (empty_valid mode fe) trivial
        exact ⟨afterBody, bodyRun⟩)
    intro auxiliary frame fuel depth enough queryScoped state valid auxiliaryValid
    cases fuel with
    | zero => omega
    | succ predecessor =>
      have bodyEnough : knot ≤ predecessor := Nat.le_of_succ_le_succ enough
      exact KernelCachedMemoRelation.full_forward_of_body
        (Full mode fe) (Head mode fe) (full_functional mode fe)
        mode fe predecessor depth query value auxiliary frame backing queryScoped
        state valid auxiliaryValid (fun _miss =>
          ih auxiliary frame predecessor depth whnfLoopFuel bodyEnough fits
            queryScoped state valid auxiliaryValid)

theorem full_trace_eventual (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (knot : Nat) (trace : Trace (.full query) value knot 0) :
    Full mode fe query value := by
  refine ⟨knot, ?_⟩
  intro fuel depth enough queryScoped
  obtain ⟨final, run, _valid, _auxiliary⟩ :=
    trace_runs mode fe (.full query) value knot 0 trace
      (fun _ => True) true_memo_frame fuel depth enough queryScoped
      {} (empty_valid mode fe) trivial
  exact ⟨final, run⟩

theorem head_trace_eventual (mode : CheckMode) (fe : FEnv)
    (query value : Expr) (knot : Nat) (trace : Trace (.head query) value knot 0) :
    Head mode fe query value := by
  refine ⟨knot, ?_⟩
  intro fuel depth enough queryScoped
  obtain ⟨final, run, _valid, _auxiliary⟩ :=
    trace_runs mode fe (.head query) value knot 0 trace
      (fun _ => True) true_memo_frame fuel depth enough queryScoped
      {} (empty_valid mode fe) trivial
  exact ⟨final, run⟩

theorem head_atom_trace (expression : Expr) (atom : HeadAtom expression) :
    Trace (.head expression) expression 1 0 := by
  exact Trace.headMemo expression expression 0 1
    (by unfold whnfCoreLoopFuel; decide) (Trace.headAtom expression atom)

theorem full_terminal_trace (expression : Expr) (terminal : FullTerminal expression) :
    Trace (.full expression) expression 2 0 := by
  exact Trace.fullMemo expression expression 1 1 (by unfold whnfLoopFuel; decide)
    (Trace.fullTerminal expression expression 1 terminal
      (head_atom_trace expression (full_terminal_head_atom expression terminal)))

/-- An actual natural literal call with no preexisting answer or success
assumption, from any state whose two memos satisfy the new relations. -/
theorem cached_nat (mode : CheckMode) (fe : FEnv) (fuel depth number : Nat)
    (enough : 2 ≤ fuel) (auxiliary : CState → Prop) (frame : MemoFrame auxiliary) :
    Forward mode fe auxiliary
      ((coreKnotI mode fe fuel).whnf depth (.lit (.natVal number)))
      (.lit (.natVal number)) := by
  exact trace_runs mode fe (.full (.lit (.natVal number))) (.lit (.natVal number))
    2 0 (full_terminal_trace _ trivial) auxiliary frame fuel depth enough
    (by simp only [Expr.wscopedB])

/-- Sort normalization is also needed by the later original record wrapper;
its full and head memo writes satisfy the same exact-expression relations. -/
theorem cached_sort (mode : CheckMode) (fe : FEnv) (fuel depth : Nat) (level : Level)
    (enough : 2 ≤ fuel) (auxiliary : CState → Prop) (frame : MemoFrame auxiliary) :
    Forward mode fe auxiliary ((coreKnotI mode fe fuel).whnf depth (.sort level))
      (.sort level) := by
  exact trace_runs mode fe (.full (.sort level)) (.sort level)
    2 0 (full_terminal_trace _ trivial) auxiliary frame fuel depth enough
    (by simp only [Expr.wscopedB])

#print axioms head_loop_atom
#print axioms full_loop_terminal_of_head
#print axioms trace_runs
#print axioms full_trace_eventual
#print axioms head_trace_eventual
#print axioms head_atom_trace
#print axioms full_terminal_trace
#print axioms cached_nat
#print axioms cached_sort

end ADWH.Experiments.Chapter15.KernelCachedEventualAtoms
/- END EXACT ORIGIN 3: KernelCachedEventualAtoms -/

/- BEGIN EXACT ORIGIN 4: KernelCachedHelperContract -/
-- [assembly import internalized] import KernelCachedForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Direct result correctness for the actual cached syntactic helpers

This physical contract slice imports the actual cached owner directly.
It retains the canonical helper definitions and all non-Stable helper proofs.
Four old Stable-specific wrappers are omitted across the two logical origins;
new relation and eventual adapters live in KernelCachedEventualHelpers.

The five clauses below concern actual CState maps and actual cache keys.
Syntactic results are specified by the actual proof-carrying ExprOpsC
functions. Their equality to the pure kernel's separate tree operations is
not assumed. The two plain-descent equations expose the proof carried by
the traversal; they do not establish that further pure correspondence.

All helper runs start from the state supplied by the caller. The small
invariant does not constrain the NF maps; every helper frames those maps.
The converted-entry tag clause survives a flush only when supplied for the
actual residue. An arbitrary flush does not establish that clause.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedHelperDirect

open ConLeche
open ConLeche.Cached

/-- A result map backed by its explicit, possibly partial reference lookup. -/
def MapBacked {Key : Type} [BEq Key] [Hashable Key]
    (reference : Key → Option Expr) (cache : Std.HashMap Key Expr) : Prop :=
  ∀ key value, cache[key]? = some value → reference key = some value

theorem map_backed_empty {Key : Type} [BEq Key] [Hashable Key]
    (reference : Key → Option Expr) :
    MapBacked reference (∅ : Std.HashMap Key Expr) := by
  intro key value hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

theorem map_backed_insert {Key : Type} [BEq Key] [Hashable Key]
    [LawfulBEq Key] (reference : Key → Option Expr)
    (cache : Std.HashMap Key Expr) (key : Key) (value : Expr)
    (valid : MapBacked reference cache) (backing : reference key = some value) :
    MapBacked reference (cache.insert key value) := by
  intro query result hit
  rw [Std.HashMap.getElem?_insert] at hit
  by_cases same : key == query
  · rw [ite_eq_left same] at hit
    cases hit
    have keys : key = query := eq_of_beq same
    cases keys
    exact backing
  · rw [ite_eq_right same] at hit
    exact valid query result hit

/-- The full expression/list/cursor key used by the actual persistent memo. -/
def instReference (key : Expr × List Expr × Nat) : Option Expr :=
  some (Expr.instantiateListC key.1 key.2.1 key.2.2)

def typeReference (lookup : Name → Option ConstantInfo)
    (key : Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some info => some (Expr.instLevelParams info.toConstantVal.levelParams
      key.2 info.toConstantVal.type)
  | none => none

def valueReference (lookup : Name → Option ConstantInfo)
    (key : Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some (.defnInfo constant value _) =>
    some (Expr.instLevelParams constant.levelParams key.2 value)
  | _ => none

def ruleReference (lookup : Name → Option ConstantInfo)
    (key : Name × Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some (.recInfo constant _ _ rules) =>
    match rules.find? (fun candidate => candidate.ctor == key.2.1) with
    | some rule => some (Expr.instLevelParams constant.levelParams key.2.2 rule.rhs)
    | none => none
  | _ => none

/-- Converted entries certify their own tags, independently of the current
environment. A use must still pass the actual pointer/structural tag test. -/
def IEnvTags (cache : Std.HashMap Name CConstE) : Prop :=
  ∀ (name : Name) (entry : CConstE), cache[name]? = some entry →
    entry.ty = entry.tyE ∧
    ∀ (tag value : Expr), entry.val = some (tag, value) → value = tag

theorem ienv_tags_empty : IEnvTags (∅ : Std.HashMap Name CConstE) := by
  intro name entry hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

/-- Exactly five helper clauses. No invariant on any other CState field is
implicitly included, and the visible FEnv lookup is used without replacing
it by the stored full environment. -/
structure HelperCache (fe : FEnv) (state : CState) : Prop where
  ienv : IEnvTags state.ienv
  inst : MapBacked instReference state.instC
  typeAt : MapBacked (typeReference fe.find?) state.constTyAt
  valueAt : MapBacked (valueReference fe.find?) state.constValAt
  ruleAt : MapBacked (ruleReference fe.find?) state.ruleRhsAt

theorem helper_cache_empty (fe : FEnv) : HelperCache fe ({} : CState) := by
  exact ⟨ienv_tags_empty, map_backed_empty _, map_backed_empty _,
    map_backed_empty _, map_backed_empty _⟩

theorem helper_cache_frame (fe : FEnv) (before after : CState)
    (valid : HelperCache fe before)
    (ienv : after.ienv = before.ienv) (inst : after.instC = before.instC)
    (types : after.constTyAt = before.constTyAt)
    (values : after.constValAt = before.constValAt)
    (rules : after.ruleRhsAt = before.ruleRhsAt) : HelperCache fe after := by
  constructor
  · change IEnvTags after.ienv
    rw [ienv]
    exact valid.ienv
  · change MapBacked instReference after.instC
    rw [inst]
    exact valid.inst
  · change MapBacked (typeReference fe.find?) after.constTyAt
    rw [types]
    exact valid.typeAt
  · change MapBacked (valueReference fe.find?) after.constValAt
    rw [values]
    exact valid.valueAt
  · change MapBacked (ruleReference fe.find?) after.ruleRhsAt
    rw [rules]
    exact valid.ruleAt

/-- Flush clears the four other helper maps but retains ienv. The surviving
tag invariant is a premise about the actual incoming state. -/
theorem helper_cache_flushed (fe : FEnv) (state : CState)
    (residue : IEnvTags state.ienv) : HelperCache fe state.flushed := by
  exact ⟨residue, map_backed_empty _, map_backed_empty _,
    map_backed_empty _, map_backed_empty _⟩

def NFFrame (before after : CState) : Prop :=
  after.whnfC = before.whnfC ∧ after.whnfCoreC = before.whnfCoreC

/-- Result, helper-invariant preservation and both real NF-map frame facts. -/
def HelperResult (fe : FEnv) (action : CheckCM Expr) (value : Expr)
    (state : CState) : Prop :=
  ∃ final, action state = .ok (value, final) ∧
    HelperCache fe final ∧ NFFrame state final

theorem helper_result_of_unchanged (fe : FEnv) (action : CheckCM Expr)
    (value : Expr) (state : CState) (valid : HelperCache fe state)
    (run : action state = .ok (value, state)) :
    HelperResult fe action value state := by
  exact ⟨state, run, valid, rfl, rfl⟩

/-- This is the actual cached function's own cutoff, requiring no claim
about exactness of the saturated loose-variable range implementation. -/
theorem instantiateListC_cut (expression : Expr) (values : List Expr)
    (cursor : Nat) (cut : expression.bvarB ≤ cursor) :
    Expr.instantiateListC expression values cursor = expression := by
  cases values with
  | nil => rfl
  | cons value rest => simp only [Expr.instantiateListC, dite_eq_left cut]

/-- Expose the reference descent already carried in the traversal subtype.
This is not yet equality with Expr.instantiateList. -/
theorem instantiateListC_eq_plain (expression : Expr) (values : List Expr)
    (cursor : Nat) :
    Expr.instantiateListC expression values cursor =
      Expr.instantiateListP values.toArray expression values.toArray.size cursor := by
  cases values with
  | nil =>
    rw [Expr.instantiateListP.eq_def]
    rfl
  | cons value rest =>
    unfold Expr.instantiateListC
    dsimp only []
    by_cases cut : expression.bvarB ≤ cursor
    · rw [dite_eq_left cut]
      exact (Expr.instantiateListP_cut cut).symm
    · rw [dite_eq_right cut]
      exact Expr.resTerm_eq _

theorem instLevelParams_eq_plain (names : List Name) (levels : List Level)
    (expression : Expr) :
    Expr.instLevelParams names levels expression =
      Expr.instLevelParamsP names levels expression := by
  unfold Expr.instLevelParams
  by_cases cut : (!expression.hasLP) = true
  · rw [dite_eq_left cut]
    exact (Expr.instLevelParamsP_cut cut).symm
  · rw [dite_eq_right cut]
    exact Expr.resTerm_eq _

private theorem pointer_tag_eq (left right : Expr)
    (tagged : Expr.exprPtrBEq left right = true) : left = right := by
  change (left == right) = true at tagged
  exact eq_of_beq tagged

theorem instLevelParamsM_correct (names : List Name) (levels : List Level)
    (expression : Expr) (state : CState) :
    instLevelParamsM names levels expression state =
      .ok (Expr.instLevelParams names levels expression, state) := rfl

theorem storedTyIdxM_correct (name : Name) (expression : Expr)
    (state : CState) (valid : IEnvTags state.ienv) :
    storedTyIdxM name expression state = .ok (expression, state) := by
  cases found : state.ienv[name]? with
  | none =>
    simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      found, pure, StateT.pure]
  | some entry =>
    by_cases tagged : Expr.exprPtrBEq entry.tyE expression = true
    · have same : entry.ty = expression :=
        (valid name entry found).1.trans (pointer_tag_eq _ _ tagged)
      simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, ite_eq_left tagged, same, pure, StateT.pure]
    · simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, ite_eq_right tagged, pure, StateT.pure]

theorem storedValIdxM_correct (name : Name) (expression : Expr)
    (state : CState) (valid : IEnvTags state.ienv) :
    storedValIdxM name expression state = .ok (expression, state) := by
  cases found : state.ienv[name]? with
  | none =>
    simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      found, pure, StateT.pure]
  | some entry =>
    rcases entry with ⟨typeTag, typeValue, optionalValue⟩
    cases optionalValue with
    | none =>
      simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, pure, StateT.pure]
    | some pair =>
      rcases pair with ⟨tag, value⟩
      have tagValue : value = tag :=
        (valid name ⟨typeTag, typeValue, some (tag, value)⟩ found).2 tag value rfl
      by_cases tagged : Expr.exprPtrBEq tag expression = true
      · have same : value = expression := tagValue.trans (pointer_tag_eq _ _ tagged)
        simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
          MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
          found, ite_eq_left tagged, same, pure, StateT.pure]
      · simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
          MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
          found, ite_eq_right tagged, pure, StateT.pure]

theorem instLevelParamsM_helper_result (fe : FEnv) (names : List Name)
    (levels : List Level) (expression : Expr) (state : CState)
    (valid : HelperCache fe state) :
    HelperResult fe (instLevelParamsM names levels expression)
      (Expr.instLevelParams names levels expression) state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (instLevelParamsM_correct names levels expression state)

theorem storedTyIdxM_helper_result (fe : FEnv) (name : Name)
    (expression : Expr) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (storedTyIdxM name expression) expression state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (storedTyIdxM_correct name expression state valid.ienv)

theorem storedValIdxM_helper_result (fe : FEnv) (name : Name)
    (expression : Expr) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (storedValIdxM name expression) expression state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (storedValIdxM_correct name expression state valid.ienv)

theorem instListM_correct (fe : FEnv) (expression : Expr) (values : List Expr)
    (cursor : Nat) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (instListM expression values cursor)
      (Expr.instantiateListC expression values cursor) state := by
  by_cases cut : expression.bvarB ≤ cursor
  · apply helper_result_of_unchanged fe _ _ state valid
    rw [instantiateListC_cut expression values cursor cut]
    simp only [instListM, modifyGet, MonadStateOf.modifyGet,
      StateT.modifyGet, ite_eq_left cut]
    all_goals rfl
  · cases hit : state.instC[(expression, values, cursor)]? with
    | some cached =>
      have same : cached = Expr.instantiateListC expression values cursor :=
        (Option.some.inj (valid.inst (expression, values, cursor) cached hit)).symm
      apply helper_result_of_unchanged fe _ _ state valid
      simp only [instListM, modifyGet, MonadStateOf.modifyGet,
        StateT.modifyGet, ite_eq_right cut, hit, same]
      all_goals rfl
    | none =>
      let cache := if state.instC.size < instCCapC then state.instC else ∅
      let value := Expr.instantiateListC expression values cursor
      let final := { state with instC := cache.insert (expression, values, cursor) value }
      have cacheValid : MapBacked instReference cache := by
        dsimp only [cache]
        split
        · exact valid.inst
        · exact map_backed_empty _
      have inserted : MapBacked instReference final.instC :=
        map_backed_insert instReference cache (expression, values, cursor) value
          cacheValid rfl
      refine ⟨final, ?_, ⟨valid.ienv, inserted, valid.typeAt, valid.valueAt,
        valid.ruleAt⟩, rfl, rfl⟩
      simp only [instListM, modifyGet, MonadStateOf.modifyGet,
        StateT.modifyGet, ite_eq_right cut, hit, final, cache, value]
      all_goals rfl

theorem constTyAtM_correct (fe : FEnv) (indexName name : Name)
    (levels : List Level) (info : ConstantInfo) (state : CState)
    (valid : HelperCache fe state) (found : fe.find? name = some info) :
    HelperResult fe (constTyAtM fe indexName name levels)
      (Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type)
      state := by
  let value := Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type
  have reference : typeReference fe.find? (name, levels) = some value := by
    simp only [typeReference, found, value]
  cases hit : state.constTyAt[(name, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.typeAt (name, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [constTyAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with constTyAt := state.constTyAt.insert (name, levels) value }
    have inserted : MapBacked (typeReference fe.find?) final.constTyAt :=
      map_backed_insert _ state.constTyAt (name, levels) value valid.typeAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, inserted, valid.valueAt,
      valid.ruleAt⟩, rfl, rfl⟩
    simp only [constTyAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, storedTyIdxM_correct name info.toConstantVal.type state valid.ienv,
      instLevelParamsM_correct, modify, pure, StateT.pure, final, value]

theorem constValAtM_correct (fe : FEnv) (indexName name : Name)
    (levels : List Level) (constant : ConstantVal) (body : Expr)
    (hint : ReducibilityHint) (state : CState) (valid : HelperCache fe state)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    HelperResult fe (constValAtM fe indexName name levels)
      (Expr.instLevelParams constant.levelParams levels body) state := by
  let value := Expr.instLevelParams constant.levelParams levels body
  have reference : valueReference fe.find? (name, levels) = some value := by
    simp only [valueReference, found, value]
  cases hit : state.constValAt[(name, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.valueAt (name, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [constValAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with constValAt := state.constValAt.insert (name, levels) value }
    have inserted : MapBacked (valueReference fe.find?) final.constValAt :=
      map_backed_insert _ state.constValAt (name, levels) value valid.valueAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, valid.typeAt, inserted,
      valid.ruleAt⟩, rfl, rfl⟩
    simp only [constValAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, storedValIdxM_correct name body state valid.ienv,
      instLevelParamsM_correct, modify, pure, StateT.pure, final, value]

theorem ruleRhsAtM_correct (fe : FEnv) (recursorIndex constructorIndex : Name)
    (recursor constructor : Name) (levels : List Level) (constant : ConstantVal)
    (majorIndex parameterCount : Nat) (rules : List RecRule) (rule : RecRule)
    (state : CState) (valid : HelperCache fe state)
    (found : fe.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    HelperResult fe
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels)
      (Expr.instLevelParams constant.levelParams levels rule.rhs) state := by
  let value := Expr.instLevelParams constant.levelParams levels rule.rhs
  have reference : ruleReference fe.find? (recursor, constructor, levels) = some value := by
    simp only [ruleReference, found, ruleFound, value]
  cases hit : state.ruleRhsAt[(recursor, constructor, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.ruleAt (recursor, constructor, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [ruleRhsAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with ruleRhsAt := state.ruleRhsAt.insert (recursor, constructor, levels) value }
    have inserted : MapBacked (ruleReference fe.find?) final.ruleRhsAt :=
      map_backed_insert _ state.ruleRhsAt (recursor, constructor, levels) value
        valid.ruleAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt,
      inserted⟩, rfl, rfl⟩
    simp only [ruleRhsAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, ruleFound, instLevelParamsM_correct, modify,
      pure, StateT.pure, final, value]

/-- Agreement with the actual visible prefix must be supplied. In particular,
FEnv.env need not be that prefix after restrictTo, and is not substituted. -/
def PrefixLookup (fe : FEnv) (visiblePrefix : Env) : Prop :=
  ∀ name, fe.find? name = visiblePrefix.find? name

theorem constTyAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (indexName name : Name)
    (levels : List Level) (info : ConstantInfo) (state : CState)
    (valid : HelperCache fe state) (found : visiblePrefix.find? name = some info) :
    HelperResult fe (constTyAtM fe indexName name levels)
      (Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type)
      state := by
  exact constTyAtM_correct fe indexName name levels info state valid
    ((agreement name).trans found)

theorem constValAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (indexName name : Name)
    (levels : List Level) (constant : ConstantVal) (body : Expr)
    (hint : ReducibilityHint) (state : CState) (valid : HelperCache fe state)
    (found : visiblePrefix.find? name = some (.defnInfo constant body hint)) :
    HelperResult fe (constValAtM fe indexName name levels)
      (Expr.instLevelParams constant.levelParams levels body) state := by
  exact constValAtM_correct fe indexName name levels constant body hint state valid
    ((agreement name).trans found)

theorem ruleRhsAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (recursorIndex constructorIndex : Name)
    (recursor constructor : Name) (levels : List Level) (constant : ConstantVal)
    (majorIndex parameterCount : Nat) (rules : List RecRule) (rule : RecRule)
    (state : CState) (valid : HelperCache fe state)
    (found : visiblePrefix.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    HelperResult fe
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels)
      (Expr.instLevelParams constant.levelParams levels rule.rhs) state := by
  exact ruleRhsAtM_correct fe recursorIndex constructorIndex recursor constructor levels
    constant majorIndex parameterCount rules rule state valid
    ((agreement recursor).trans found) ruleFound

#print axioms map_backed_empty
#print axioms map_backed_insert
#print axioms ienv_tags_empty
#print axioms helper_cache_empty
#print axioms helper_cache_frame
#print axioms helper_cache_flushed
#print axioms helper_result_of_unchanged
#print axioms instantiateListC_cut
#print axioms instantiateListC_eq_plain
#print axioms instLevelParams_eq_plain
#print axioms instLevelParamsM_correct
#print axioms storedTyIdxM_correct
#print axioms storedValIdxM_correct
#print axioms instLevelParamsM_helper_result
#print axioms storedTyIdxM_helper_result
#print axioms storedValIdxM_helper_result
#print axioms instListM_correct
#print axioms constTyAtM_correct
#print axioms constValAtM_correct
#print axioms ruleRhsAtM_correct
#print axioms constTyAtM_from_prefix
#print axioms constValAtM_from_prefix
#print axioms ruleRhsAtM_from_prefix

end ADWH.Experiments.Chapter15.KernelCachedHelperDirect

/- Canonical helper-state frame origin; its Stable wrappers are omitted. -/

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Auxiliary invariants through actual cached helper calls

Source candidate only; no compilation or accepted theorem report is claimed.
The existing HelperResult is retained unchanged. Its actual run equation is
combined with an independent state-effect theorem to preserve any predicate
that tolerates the four real helper-map updates. No result correctness is
inferred from that effect theorem, and no successful helper call is postulated
in place of the existing correctness witness.

RestCaches records exactly the nine fields the licensed query path should
leave alone. Its frame instances cover helper writes and the two NF writes;
they do not prove that an arbitrary evaluator call stays in those operations.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedHelperFrame

open ConLeche
open ConLeche.Cached
open KernelCachedHelperDirect

/-- A successful action preserves a predicate on its actual returned state.
This proposition alone does not assert that the action succeeds. -/
def Preserves {α : Type} (auxiliary : CState → Prop) (action : CheckCM α) : Prop :=
  ∀ state value final, auxiliary state →
    action state = .ok (value, final) → auxiliary final

/-- The four helper fields may be replaced by any map. This is a sufficient
frame property, not an assertion that actual helpers make arbitrary writes. -/
structure HelperFrame (auxiliary : CState → Prop) : Prop where
  inst : ∀ state cache, auxiliary state → auxiliary { state with instC := cache }
  typeAt : ∀ state cache, auxiliary state → auxiliary { state with constTyAt := cache }
  valueAt : ∀ state cache, auxiliary state → auxiliary { state with constValAt := cache }
  ruleAt : ∀ state cache, auxiliary state → auxiliary { state with ruleRhsAt := cache }

theorem preserves_pure {α : Type} (auxiliary : CState → Prop) (value : α) :
    Preserves auxiliary (pure value) := by
  intro state result final valid run
  change Except.ok (value, state) = Except.ok (result, final) at run
  have states : state = final := congrArg Prod.snd (Except.ok.inj run)
  exact states ▸ valid

theorem preserves_throw {α : Type} (auxiliary : CState → Prop) (error : CheckError) :
    Preserves auxiliary (throw error : CheckCM α) := by
  intro state value final _ run
  change Except.error error = Except.ok (value, final) at run
  cases run

theorem preserves_bind {α β : Type} (auxiliary : CState → Prop)
    (action : CheckCM α) (next : α → CheckCM β)
    (first : Preserves auxiliary action)
    (rest : ∀ value, Preserves auxiliary (next value)) :
    Preserves auxiliary (action >>= next) := by
  intro state result final valid run
  cases firstRun : action state with
  | error error =>
    simp only [Bind.bind, StateT.bind, firstRun, Except.bind] at run
    cases run
  | ok pair =>
    obtain ⟨value, middle⟩ := pair
    have middleValid : auxiliary middle := first state value middle valid firstRun
    simp only [Bind.bind, StateT.bind, firstRun, Except.bind] at run
    exact rest value middle result final middleValid run

theorem preserves_modifyGet {α : Type} (auxiliary : CState → Prop)
    (step : CState → α × CState)
    (frame : ∀ state, auxiliary state → auxiliary (step state).2) :
    Preserves auxiliary (modifyGet step) := by
  intro state value final valid run
  change Except.ok (step state) = Except.ok (value, final) at run
  have states : (step state).2 = final := congrArg Prod.snd (Except.ok.inj run)
  exact states ▸ frame state valid

theorem preserves_modify (auxiliary : CState → Prop) (step : CState → CState)
    (frame : ∀ state, auxiliary state → auxiliary (step state)) :
    Preserves auxiliary (modify step) := by
  exact preserves_modifyGet auxiliary (fun state => ((), step state)) frame

theorem instLevelParamsM_preserves (auxiliary : CState → Prop)
    (names : List Name) (levels : List Level) (expression : Expr) :
    Preserves auxiliary (instLevelParamsM names levels expression) := by
  exact preserves_pure auxiliary _

theorem storedTyIdxM_preserves (auxiliary : CState → Prop)
    (name : Name) (expression : Expr) :
    Preserves auxiliary (storedTyIdxM name expression) := by
  unfold storedTyIdxM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro entry
  cases entry with
  | none => exact preserves_pure auxiliary _
  | some entry =>
    dsimp only []
    split <;> exact preserves_pure auxiliary _

theorem storedValIdxM_preserves (auxiliary : CState → Prop)
    (name : Name) (expression : Expr) :
    Preserves auxiliary (storedValIdxM name expression) := by
  unfold storedValIdxM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro entry
  cases entry with
  | none => exact preserves_pure auxiliary _
  | some entry =>
    obtain ⟨typeTag, typeValue, value⟩ := entry
    cases value with
    | none => exact preserves_pure auxiliary _
    | some pair =>
      obtain ⟨tag, value⟩ := pair
      dsimp only []
      split <;> exact preserves_pure auxiliary _

theorem instListM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (expression : Expr) (values : List Expr)
    (cursor : Nat) : Preserves auxiliary (instListM expression values cursor) := by
  unfold instListM
  apply preserves_modifyGet auxiliary
  intro state valid
  dsimp only []
  split
  · exact valid
  · split
    · exact valid
    · exact frame.inst state _ valid

theorem constTyAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv) (indexName name : Name)
    (levels : List Level) :
    Preserves auxiliary (constTyAtM fe indexName name levels) := by
  unfold constTyAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? name with
    | none => exact preserves_throw auxiliary _
    | some info =>
      apply preserves_bind auxiliary _ _ (storedTyIdxM_preserves auxiliary _ _)
      intro raw
      apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
      intro value
      apply preserves_bind auxiliary _ _
        (preserves_modify auxiliary _ (fun state valid => frame.typeAt state _ valid))
      intro _
      exact preserves_pure auxiliary _

theorem constValAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv) (indexName name : Name)
    (levels : List Level) :
    Preserves auxiliary (constValAtM fe indexName name levels) := by
  unfold constValAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? name with
    | none => exact preserves_throw auxiliary _
    | some info =>
      cases info <;> try exact preserves_throw auxiliary _
      apply preserves_bind auxiliary _ _ (storedValIdxM_preserves auxiliary _ _)
      intro raw
      apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
      intro value
      apply preserves_bind auxiliary _ _
        (preserves_modify auxiliary _ (fun state valid => frame.valueAt state _ valid))
      intro _
      exact preserves_pure auxiliary _

theorem ruleRhsAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv)
    (recursorIndex constructorIndex recursor constructor : Name)
    (levels : List Level) : Preserves auxiliary
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels) := by
  unfold ruleRhsAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? recursor with
    | none => exact preserves_throw auxiliary _
    | some info =>
      cases info <;> try exact preserves_throw auxiliary _
      rename_i constant majorIndex parameterCount rules
      dsimp only []
      cases ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) with
      | none => exact preserves_throw auxiliary _
      | some rule =>
        apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
        intro value
        apply preserves_bind auxiliary _ _
          (preserves_modify auxiliary _ (fun state valid => frame.ruleAt state _ valid))
        intro _
        exact preserves_pure auxiliary _

/-- Lift an existing correctness witness and a separate state-effect proof.
The action equation used by preservation is exactly the witness's equation. -/
theorem helper_result_with_auxiliary (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) (state : CState)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (valid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      HelperCache fe final ∧ NFFrame state final ∧ auxiliary final := by
  obtain ⟨final, run, helpers, frame⟩ := result
  exact ⟨final, run, helpers, frame, preservation state value final valid run⟩

/-- The actual fields untouched by the licensed query's intended operations.
No equality or validity of their contents is assumed by this projection. -/
structure RestCaches where
  ienv : Std.HashMap Name CConstE
  whnfCoreCheapC : Std.HashMap Expr Expr
  inferC : Std.HashMap Expr Expr
  inferIOC : Std.HashMap Expr Expr
  defeqC : Std.HashMap (Expr × Expr) Bool
  annotC : Std.HashMap Expr Expr
  lsimpC : Std.HashMap Level Level
  lnzC : Std.HashMap Level Bool
  eqvC : Std.HashMap (Level × Level) Bool

def restCaches (state : CState) : RestCaches :=
  ⟨state.ienv, state.whnfCoreCheapC, state.inferC, state.inferIOC,
    state.defeqC, state.annotC, state.lsimpC, state.lnzC, state.eqvC⟩

theorem restCaches_helper_frame (initial : CState) :
    HelperFrame (fun state => restCaches state = restCaches initial) := by
  exact ⟨fun _ _ valid => valid, fun _ _ valid => valid,
    fun _ _ valid => valid, fun _ _ valid => valid⟩

#print axioms preserves_pure
#print axioms preserves_throw
#print axioms preserves_bind
#print axioms preserves_modifyGet
#print axioms preserves_modify
#print axioms instLevelParamsM_preserves
#print axioms storedTyIdxM_preserves
#print axioms storedValIdxM_preserves
#print axioms instListM_preserves
#print axioms constTyAtM_preserves
#print axioms constValAtM_preserves
#print axioms ruleRhsAtM_preserves
#print axioms helper_result_with_auxiliary
#print axioms restCaches_helper_frame

end ADWH.Experiments.Chapter15.KernelCachedHelperFrame
/- END EXACT ORIGIN 4: KernelCachedHelperContract -/

/- BEGIN EXACT ORIGIN 5: KernelCachedEventualHelpers -/
-- [assembly import internalized] import KernelCachedEventualEmpty
-- [assembly import internalized] import KernelCachedHelperContract

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual helper calls with eventual actual-cache backing

The helper contracts and returned values retain their original canonical
names and definitions. This namespace supplies only the coupling to the
relation-parametric NF maps and their eventual genuine-empty instantiation.
The five common helper actions preserve the caller's actual NF maps, the
five helper clauses and any explicitly framed auxiliary predicate.

No pure evaluator, StableNF invariant, arbitrary flush-validity assumption,
or precomputed query result is imported or used. Source candidate only.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualHelpers

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation
open KernelCachedHelperDirect
open KernelCachedHelperFrame

/-- The helper clauses ignore both actual normal-form map insertions. -/
theorem helper_cache_memo_frame (fe : FEnv) : MemoFrame (HelperCache fe) := by
  constructor
  · intro state query value valid
    exact ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt, valid.ruleAt⟩
  · intro state query value valid
    exact ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt, valid.ruleAt⟩

/-- Keep the helper clauses and the caller's additional frame at a memo root. -/
theorem helpers_auxiliary_memo_frame (fe : FEnv) (auxiliary : CState → Prop)
    (frame : MemoFrame auxiliary) :
    MemoFrame (fun state => HelperCache fe state ∧ auxiliary state) := by
  constructor
  · intro state query value valid
    exact ⟨(helper_cache_memo_frame fe).whnfC state query value valid.1,
      frame.whnfC state query value valid.2⟩
  · intro state query value valid
    exact ⟨(helper_cache_memo_frame fe).whnfCoreC state query value valid.1,
      frame.whnfCoreC state query value valid.2⟩

/-- This is the original nine-field projection, with the new memo-frame type. -/
theorem restCaches_memo_frame (initial : CState) :
    MemoFrame (fun state => restCaches state = restCaches initial) := by
  exact ⟨fun _ _ _ valid => valid, fun _ _ _ valid => valid⟩

/-- Used only when a root's genuine-empty run needs no extra state property. -/
theorem true_helper_frame : HelperFrame (fun _ => True) := by
  exact ⟨fun _ _ _ => trivial, fun _ _ _ => trivial,
    fun _ _ _ => trivial, fun _ _ _ => trivial⟩

/-- The actual two-map frame transports any pair of memo relations. -/
theorem helper_result_nf (fullRelation headRelation : Expr → Expr → Prop)
    (fe : FEnv) (action : CheckCM Expr) (value : Expr) (state : CState)
    (valid : NFValid fullRelation headRelation state)
    (result : HelperResult fe action value state) :
    ∃ final, action state = .ok (value, final) ∧
      NFValid fullRelation headRelation final ∧ HelperCache fe final := by
  obtain ⟨final, run, helpers, full, head⟩ := result
  exact ⟨final, run,
    nf_frame fullRelation headRelation state final valid full head, helpers⟩

/-- Correctness and state effects use the same actual returned-state witness. -/
theorem helper_result_nf_with_auxiliary
    (fullRelation headRelation : Expr → Expr → Prop)
    (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) (state : CState)
    (valid : NFValid fullRelation headRelation state)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (auxValid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      NFValid fullRelation headRelation final ∧
      HelperCache fe final ∧ auxiliary final := by
  obtain ⟨final, run, helpers, full, head⟩ := result
  exact ⟨final, run,
    nf_frame fullRelation headRelation state final valid full head,
    helpers, preservation state value final auxValid run⟩

/-- Specialization to exact results of eventual actual calls from genuine {}. -/
theorem helper_result_eventual_with_auxiliary (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (action : CheckCM Expr) (value : Expr)
    (state : CState) (valid : KernelCachedEventualEmpty.NF mode fe state)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (auxValid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_nf_with_auxiliary
    (KernelCachedEventualEmpty.Full mode fe)
    (KernelCachedEventualEmpty.Head mode fe)
    fe auxiliary action value state valid result preservation auxValid

/-- Both independent invariants hold in the genuine default state. -/
theorem empty_valid (mode : CheckMode) (fe : FEnv) :
    KernelCachedEventualEmpty.NF mode fe ({} : CState) ∧
      HelperCache fe ({} : CState) := by
  exact ⟨KernelCachedEventualEmpty.empty_valid mode fe, helper_cache_empty fe⟩

/-- Flush keeps converted tags. Their validity is an explicit residue premise. -/
theorem flushed_valid (mode : CheckMode) (fe : FEnv) (state : CState)
    (residue : IEnvTags state.ienv) :
    KernelCachedEventualEmpty.NF mode fe state.flushed ∧
      HelperCache fe state.flushed := by
  exact ⟨nf_flushed (KernelCachedEventualEmpty.Full mode fe)
    (KernelCachedEventualEmpty.Head mode fe) state,
    helper_cache_flushed fe state residue⟩

theorem instLevelParamsM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (names : List Name) (levels : List Level)
    (expression : Expr) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state) :
    ∃ final, instLevelParamsM names levels expression state =
      .ok (Expr.instLevelParams names levels expression, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (instLevelParamsM_helper_result fe names levels expression state helpers)
    (instLevelParamsM_preserves auxiliary names levels expression) auxValid

theorem instListM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (expression : Expr) (values : List Expr) (cursor : Nat) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state) :
    ∃ final, instListM expression values cursor state =
      .ok (Expr.instantiateListC expression values cursor, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (instListM_correct fe expression values cursor state helpers)
    (instListM_preserves auxiliary frame expression values cursor) auxValid

theorem constTyAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (indexName name : Name) (levels : List Level) (info : ConstantInfo)
    (state : CState) (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? name = some info) :
    ∃ final, constTyAtM fe indexName name levels state =
      .ok (Expr.instLevelParams info.toConstantVal.levelParams levels
        info.toConstantVal.type, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (constTyAtM_correct fe indexName name levels info state helpers found)
    (constTyAtM_preserves auxiliary frame fe indexName name levels) auxValid

theorem constValAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (indexName name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    ∃ final, constValAtM fe indexName name levels state =
      .ok (Expr.instLevelParams constant.levelParams levels body, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (constValAtM_correct fe indexName name levels constant body hint state helpers found)
    (constValAtM_preserves auxiliary frame fe indexName name levels) auxValid

theorem ruleRhsAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (recursorIndex constructorIndex recursor constructor : Name)
    (levels : List Level) (constant : ConstantVal) (majorIndex parameterCount : Nat)
    (rules : List RecRule) (rule : RecRule) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    ∃ final, ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels
      state = .ok (Expr.instLevelParams constant.levelParams levels rule.rhs, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (ruleRhsAtM_correct fe recursorIndex constructorIndex recursor constructor levels
      constant majorIndex parameterCount rules rule state helpers found ruleFound)
    (ruleRhsAtM_preserves auxiliary frame fe recursorIndex constructorIndex
      recursor constructor levels) auxValid

#print axioms helper_cache_memo_frame
#print axioms helpers_auxiliary_memo_frame
#print axioms restCaches_memo_frame
#print axioms true_helper_frame
#print axioms helper_result_nf
#print axioms helper_result_nf_with_auxiliary
#print axioms helper_result_eventual_with_auxiliary
#print axioms empty_valid
#print axioms flushed_valid
#print axioms instLevelParamsM_forward
#print axioms instListM_forward
#print axioms constTyAtM_forward
#print axioms constValAtM_forward
#print axioms ruleRhsAtM_forward

end ADWH.Experiments.Chapter15.KernelCachedEventualHelpers
/- END EXACT ORIGIN 5: KernelCachedEventualHelpers -/

/- BEGIN EXACT ORIGIN 6: KernelCachedLiteralContract -/
-- [assembly import internalized] import KernelCachedForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Canonical natural-literal syntax and the actual cached head body

This small owner retains exactly two declarations from the reviewed literal
source, with their original namespace, statements and bodies. It imports only
the actual cached implementation. Pure backing and full-normalization proofs
remain separate historical declarations; this module does not re-own them.
Source selection only; a complete fresh build is still required.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedLiteralForward

open ConLeche
open ConLeche.Cached

def natLiteral (n : Nat) : Expr := .lit (.natVal n)

/-- The actual head body needs neither a callback nor a state update here. -/
theorem head_body_nat (mode : CheckMode) (callbacks : CoreFnsI)
    (fe : FEnv) (cheap : Bool) (depth n : Nat) (state : CState) :
    whnfCoreBodyI mode callbacks fe cheap depth (natLiteral n) state =
      .ok (natLiteral n, state) := by
  unfold whnfCoreBodyI whnfCoreLoopFuel
  rfl

#print axioms head_body_nat

end ADWH.Experiments.Chapter15.KernelCachedLiteralForward
/- END EXACT ORIGIN 6: KernelCachedLiteralContract -/

/- BEGIN EXACT ORIGIN 7: KernelCachedEventualRecordWrapper -/
-- [assembly import internalized] import KernelCachedEventualHelpers
-- [assembly import internalized] import KernelCachedEventualAtoms
-- [assembly import internalized] import KernelCachedLiteralContract

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual theorem-record wrapper with eventual cached-run validity

Source candidate only. This new namespace replaces the old pure-backed state
invariant with eventual actual cached runs. The unused pure Env parameter is
removed. The actual original cached definitions are used without
replacement. The intended wrapper is Eq.{1} Nat (Nat.add query 0) numeral,
with raw proof Eq.refl.{1} Nat numeral. This leaf addresses the actual conversion
tail and exposes finite inference/annotation branch equations separately.

The two additional memo invariants describe the reachable successful wrapper
path: cheap-head results are identities and all stored defeq verdicts are true.
They do not assert general typing, semantic equality, CSOK or EnvWF. The final
record proof must establish them from the original empty state and actual calls.
An abstract query run must return its actual state and preserve RestCaches.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper

open ConLeche
open ConLeche.Cached
open KernelCachedForward
open KernelCachedMemoRelation
open KernelCachedEventualHelpers
open KernelCachedHelperDirect
open KernelCachedHelperFrame
open KernelCachedLiteralForward

def natType : Expr := .const natName []
def addZero (query : Expr) : Expr :=
  .app (.app (.const natAddName []) query) (natLiteral 0)
def eqNat (left right : Expr) : Expr :=
  .app (.app (.app (.const eqName [.succ .zero]) natType) left) right
def reflNat (number : Nat) : Expr :=
  .app (.app (.const eqReflName [.succ .zero]) natType) (natLiteral number)

def TrueDefeqMap (cache : Std.HashMap (Expr × Expr) Bool) : Prop :=
  ∀ (key : Expr × Expr) (value : Bool), cache[key]? = some value → value = true

structure WrapperCache (state : CState) : Prop where
  cheap : MapBacked (fun expression => some expression) state.whnfCoreCheapC
  defeqTrue : TrueDefeqMap state.defeqC

structure WorkingState (fe : FEnv) (state : CState) : Prop where
  nf : KernelCachedEventualEmpty.NF .verified fe state
  helpers : HelperCache fe state
  wrapper : WrapperCache state

theorem true_defeq_empty : TrueDefeqMap (∅ : Std.HashMap (Expr × Expr) Bool) := by
  intro key value hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

theorem true_defeq_insert (cache : Std.HashMap (Expr × Expr) Bool)
    (key : Expr × Expr) (valid : TrueDefeqMap cache) :
    TrueDefeqMap (cache.insert key true) := by
  intro query value hit
  rw [Std.HashMap.getElem?_insert] at hit
  by_cases same : key == query
  · rw [ite_eq_left same] at hit
    cases hit
    rfl
  · rw [ite_eq_right same] at hit
    exact valid query value hit

theorem working_empty (fe : FEnv) :
    WorkingState fe ({} : CState) := by
  exact ⟨KernelCachedEventualEmpty.empty_valid .verified fe, helper_cache_empty fe,
    ⟨map_backed_empty _, true_defeq_empty⟩⟩

theorem working_after_rest (fe : FEnv)
    (before after : CState) (valid : WorkingState fe before)
    (nf : KernelCachedEventualEmpty.NF .verified fe after) (helpers : HelperCache fe after)
    (same : restCaches after = restCaches before) : WorkingState fe after := by
  have cheapEq : after.whnfCoreCheapC = before.whnfCoreCheapC :=
    congrArg RestCaches.whnfCoreCheapC same
  have defeqEq : after.defeqC = before.defeqC := congrArg RestCaches.defeqC same
  refine ⟨nf, helpers, ?_⟩
  constructor
  · change MapBacked (fun expression => some expression) after.whnfCoreCheapC
    rw [cheapEq]
    exact valid.wrapper.cheap
  · change TrueDefeqMap after.defeqC
    rw [defeqEq]
    exact valid.wrapper.defeqTrue

theorem working_insert_cheap (fe : FEnv)
    (state : CState) (expression : Expr) (valid : WorkingState fe state) :
    WorkingState fe
      { state with whnfCoreCheapC := state.whnfCoreCheapC.insert expression expression } := by
  refine ⟨nf_frame (KernelCachedEventualEmpty.Full .verified fe)
      (KernelCachedEventualEmpty.Head .verified fe) state _ valid.nf rfl rfl,
    helper_cache_frame fe state _ valid.helpers rfl rfl rfl rfl rfl, ?_⟩
  exact ⟨map_backed_insert (fun term => some term) state.whnfCoreCheapC
    expression expression valid.wrapper.cheap rfl, valid.wrapper.defeqTrue⟩

theorem working_insert_defeq (fe : FEnv)
    (state : CState) (left right : Expr) (valid : WorkingState fe state) :
    WorkingState fe
      { state with defeqC := state.defeqC.insert (left, right) true } := by
  refine ⟨nf_frame (KernelCachedEventualEmpty.Full .verified fe)
      (KernelCachedEventualEmpty.Head .verified fe) state _ valid.nf rfl rfl,
    helper_cache_frame fe state _ valid.helpers rfl rfl rfl rfl rfl, ?_⟩
  exact ⟨valid.wrapper.cheap,
    true_defeq_insert state.defeqC (left, right) valid.wrapper.defeqTrue⟩

private theorem defeq_memo_hit (body : Nat → Expr → Expr → CheckCM Bool)
    (depth : Nat) (left right : Expr) (state : CState)
    (hit : state.defeqC[(left, right)]? = some true) :
    memoBI body depth left right state = .ok (true, state) := by
  simp only [memoBI, Bind.bind, StateT.bind, get, getThe,
    MonadStateOf.get, StateT.get, hit, pure, StateT.pure, Except.pure, Except.bind]

private theorem defeq_memo_miss (body : Nat → Expr → Expr → CheckCM Bool)
    (depth : Nat) (left right : Expr) (state final : CState)
    (miss : state.defeqC[(left, right)]? = none)
    (run : body depth left right state = .ok (true, final)) :
    memoBI body depth left right state =
      .ok (true, { final with defeqC := final.defeqC.insert (left, right) true }) := by
  simp only [memoBI, Bind.bind, StateT.bind, get, getThe,
    MonadStateOf.get, StateT.get, miss, pure, StateT.pure, Except.pure,
    Except.bind, run, modify, modifyGet, MonadStateOf.modifyGet, StateT.modifyGet]

/-- The current miss-body is exposed here and discharged by the concrete
callers below. Positive fuel is required before the original memo is read. -/
theorem defeq_forward_of_body (fe : FEnv)
    (fuel depth : Nat) (left right : Expr) (state : CState)
    (valid : WorkingState fe state)
    (body : state.defeqC[(left, right)]? = none →
      ∃ final, defeqBodyI .verified (coreKnotI .verified fe fuel) fe depth
          left right state = .ok (true, final) ∧ WorkingState fe final) :
    ∃ final, (coreKnotI .verified fe (fuel + 1)).defeq depth left right state =
      .ok (true, final) ∧ WorkingState fe final := by
  cases cached : state.defeqC[(left, right)]? with
  | some value =>
    have valueEq : value = true := valid.wrapper.defeqTrue (left, right) value cached
    subst value
    refine ⟨state, ?_, valid⟩
    change memoBI (fun d a b => defeqBodyI .verified
      (coreKnotI .verified fe fuel) fe d a b) depth left right state = _
    exact defeq_memo_hit _ depth left right state cached
  | none =>
    obtain ⟨final, run, finalValid⟩ := body cached
    refine ⟨{ final with defeqC := final.defeqC.insert (left, right) true }, ?_,
      working_insert_defeq fe final left right finalValid⟩
    change memoBI (fun d a b => defeqBodyI .verified
      (coreKnotI .verified fe fuel) fe d a b) depth left right state = _
    exact defeq_memo_miss _ depth left right state final cached run

theorem defeq_same_body (callbacks : CoreFnsI) (fe : FEnv)
    (depth : Nat) (expression : Expr) (state : CState) :
    defeqBodyI .verified callbacks fe depth expression expression state =
      .ok (true, state) := by
  have same : (expression == expression) = true := by simp
  simp only [defeqBodyI, same, ↓reduceIte]
  all_goals rfl

theorem defeq_same (fe : FEnv) (fuel depth : Nat)
    (expression : Expr) (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 1)).defeq depth expression expression state =
      .ok (true, final) ∧ WorkingState fe final := by
  apply defeq_forward_of_body fe fuel depth expression expression state valid
  intro _
  exact ⟨state, defeq_same_body _ fe depth expression state, valid⟩

/-- Identity-backed cheap memo, distinct from the existing noncheap NF memo. -/
theorem cheap_forward_of_body (fe : FEnv)
    (fuel depth : Nat) (expression : Expr) (state : CState)
    (valid : WorkingState fe state)
    (body : state.whnfCoreCheapC[expression]? = none →
      ∃ final, whnfCoreBodyI .verified (coreKnotI .verified fe fuel) fe true depth
          expression state = .ok (expression, final) ∧ WorkingState fe final) :
    ∃ final, (coreKnotI .verified fe (fuel + 1)).whnfCore true depth expression state =
      .ok (expression, final) ∧ WorkingState fe final := by
  cases cached : state.whnfCoreCheapC[expression]? with
  | some value =>
    have valueEq : value = expression :=
      (Option.some.inj (valid.wrapper.cheap expression value cached)).symm
    subst value
    refine ⟨state, ?_, valid⟩
    change memoEI (·.whnfCoreCheapC) (fun current cache =>
      { current with whnfCoreCheapC := cache })
      (fun d e => whnfCoreBodyI .verified (coreKnotI .verified fe fuel) fe true d e)
      depth expression state = _
    exact memoEI_hit _ _ _ depth expression expression state cached
  | none =>
    obtain ⟨final, run, finalValid⟩ := body cached
    refine ⟨{ final with whnfCoreCheapC := final.whnfCoreCheapC.insert expression expression },
      ?_, working_insert_cheap fe final expression finalValid⟩
    change memoEI (·.whnfCoreCheapC) (fun current cache =>
      { current with whnfCoreCheapC := cache })
      (fun d e => whnfCoreBodyI .verified (coreKnotI .verified fe fuel) fe true d e)
      depth expression state = _
    exact memoEI_miss _ _ _ depth expression expression state final cached run

theorem cheap_nat (fe : FEnv) (fuel depth number : Nat)
    (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 1)).whnfCore true depth (natLiteral number)
        state = .ok (natLiteral number, final) ∧ WorkingState fe final := by
  apply cheap_forward_of_body fe fuel depth (natLiteral number) state valid
  intro _
  exact ⟨state, head_body_nat .verified _ fe true depth number state, valid⟩

theorem cheap_const (fe : FEnv) (fuel depth : Nat)
    (name : Name) (levels : List Level) (state : CState)
    (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 1)).whnfCore true depth (.const name levels)
        state = .ok (.const name levels, final) ∧ WorkingState fe final := by
  apply cheap_forward_of_body fe fuel depth (.const name levels) state valid
  intro _
  refine ⟨state, ?_, valid⟩
  unfold whnfCoreBodyI whnfCoreLoopFuel
  rfl

/-- This is a logical exclusion of the real recursor record constructor. -/
def NoRecursor (fe : FEnv) (name : Name) : Prop :=
  ∀ (constant : ConstantVal) (major parameters : Nat) (rules : List RecRule),
    fe.find? name ≠ some (.recInfo constant major parameters rules)

theorem no_iota_of_no_recursor (fe : FEnv) (name : Name) (levels : List Level)
    (expression : Expr) (head : expression.getAppFn = .const name levels)
    (notRecursor : NoRecursor fe name) : iotaArityOk fe expression = false := by
  unfold iotaArityOk
  rw [head]
  dsimp only []
  cases found : fe.find? name with
  | none => rfl
  | some info =>
    cases info with
    | recInfo constant major parameters rules =>
      exact False.elim (notRecursor constant major parameters rules found)
    | _ => rfl

private theorem whnf_app_skip (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (function argument : Expr) (rest : List Expr)
    (nonLambda : function.isLam = false)
    (noIota : iotaArityOk fe (.app function argument) = false) :
    whnfAppI .verified callbacks fe depth next function (argument :: rest) =
      whnfAppI .verified callbacks fe depth next (.app function argument) rest := by
  funext state
  cases function with
  | lam domain body metadata => cases nonLambda
  | _ =>
    rw [whnfAppI.eq_def]
    simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
      Except.bind, noIota]
    all_goals rfl

theorem whnf_spine_no_recursor (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (next : Expr → CheckCM Expr) (name : Name) (levels : List Level)
    (notRecursor : NoRecursor fe name) (arguments : List Expr) :
    ∀ function, function.getAppFn = .const name levels →
      whnfAppI .verified callbacks fe depth next function arguments =
        pure (Expr.mkAppN function arguments) := by
  induction arguments with
  | nil =>
    intro function _
    rw [whnfAppI.eq_def]
    rfl
  | cons argument rest ih =>
    intro function head
    have nonLambda : function.isLam = false := by
      cases function <;> try rfl
      cases head
    have noIota := no_iota_of_no_recursor fe name levels (.app function argument)
      head notRecursor
    rw [whnf_app_skip callbacks fe depth next function argument rest nonLambda noIota]
    exact ih (.app function argument) head

theorem cheap_application_body (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (name : Name) (levels : List Level) (function argument : Expr)
    (notRecursor : NoRecursor fe name)
    (head : (Expr.app function argument).getAppFn = Expr.const name levels)
    (rebuild : Expr.mkAppN (.const name levels) (Expr.app function argument).getAppArgsC =
      .app function argument)
    (state final : CState)
    (headRun : callbacks.whnfCore true depth (.const name levels) state =
      .ok (.const name levels, final)) :
    whnfCoreBodyI .verified callbacks fe true depth (.app function argument) state =
      .ok (.app function argument, final) := by
  change whnfCoreLoopI .verified callbacks fe true depth whnfCoreLoopFuel
    (.app function argument) state = _
  have budgetEq : whnfCoreLoopFuel = 999999 + 1 := by
    unfold whnfCoreLoopFuel
    rfl
  rw [budgetEq]
  change whnfCoreStepI .verified callbacks fe true depth
    (whnfCoreLoopI .verified callbacks fe true depth 999999)
    (.app function argument) state = _
  simp only [whnfCoreStepI, head, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.pure, Except.bind, headRun,
    whnf_spine_no_recursor callbacks fe depth
      (whnfCoreLoopI .verified callbacks fe true depth 999999) name levels
      notRecursor (Expr.app function argument).getAppArgsC (.const name levels) rfl,
    rebuild]
  all_goals rfl

theorem cheap_application (fe : FEnv) (fuel depth : Nat)
    (name : Name) (levels : List Level) (function argument : Expr)
    (notRecursor : NoRecursor fe name)
    (head : (Expr.app function argument).getAppFn = Expr.const name levels)
    (rebuild : Expr.mkAppN (.const name levels) (Expr.app function argument).getAppArgsC =
      .app function argument)
    (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 2)).whnfCore true depth
        (.app function argument) state = .ok (.app function argument, final) ∧
      WorkingState fe final := by
  apply cheap_forward_of_body fe (fuel + 1) depth
    (.app function argument) state valid
  intro _
  obtain ⟨final, headRun, finalValid⟩ :=
    cheap_const fe fuel depth name levels state valid
  exact ⟨final, cheap_application_body _ fe depth name levels function argument
    notRecursor head rebuild state final headRun, finalValid⟩

theorem add_not_recursor (fe : FEnv) (stored : natOpStoredF fe natAddName = true) :
    NoRecursor fe natAddName := by
  intro constant major parameters rules found
  unfold natOpStoredF at stored
  rw [found] at stored
  cases stored

theorem eq_not_recursor (fe : FEnv) (constant : ConstantVal) (caps : IndCaps)
    (stored : fe.find? eqName = some (.indInfo constant caps)) : NoRecursor fe eqName := by
  intro other major parameters rules found
  rw [stored] at found
  cases found

/-- Concrete zero normalization preserves the exact wrapper projection. -/
theorem full_nat_with_rest (fe : FEnv) (fuel depth number : Nat)
    (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 2)).whnf depth (natLiteral number) state =
      .ok (natLiteral number, final) ∧ WorkingState fe final ∧
      restCaches final = restCaches state := by
  have frame : MemoFrame (fun current =>
      HelperCache fe current ∧ restCaches current = restCaches state) := by
    constructor
    · intro current query value facts
      exact ⟨(helper_cache_memo_frame fe).whnfC current query value facts.1,
        (restCaches_memo_frame state).whnfC current query value facts.2⟩
    · intro current query value facts
      exact ⟨(helper_cache_memo_frame fe).whnfCoreC current query value facts.1,
        (restCaches_memo_frame state).whnfCoreC current query value facts.2⟩
  obtain ⟨final, run, nf, helpers, rest⟩ :=
    KernelCachedEventualAtoms.cached_nat .verified fe (fuel + 2) depth number
      (by omega) _ frame state
      valid.nf ⟨valid.helpers, rfl⟩
  exact ⟨final, run, working_after_rest fe state final valid nf helpers rest,
    rest⟩

/-! ## The actual primitive-computation conversion arm -/

theorem prop_irrel_literal (callbacks : CoreFnsI) (fe : FEnv)
    (depth number : Nat) (other : Expr) :
    propIrrelI callbacks fe depth (natLiteral number) other = pure false := by
  rfl

theorem offset_literal_add (callbacks : CoreFnsI) (depth number : Nat)
    (query : Expr) :
    defeqOffsetI callbacks depth (natLiteral number) (addZero query) = pure none := by
  cases number <;> rfl

theorem reduce_add_zero (callbacks : CoreFnsI) (fe : FEnv) (depth number : Nat)
    (query : Expr) (state afterQuery final : CState)
    (stored : natOpStoredF fe natAddName = true)
    (queryRun : callbacks.whnf depth query state =
      .ok (natLiteral number, afterQuery))
    (zeroRun : callbacks.whnf depth (natLiteral 0) afterQuery =
      .ok (natLiteral 0, final)) :
    reduceNatI callbacks fe depth (addZero query) state =
      .ok (some (natLiteral number), final) := by
  have enabled :
      (natAddName = natAddName ∨ natAddName = natSubName ∨
       natAddName = natMulName ∨ natAddName = natPowName ∨
       natAddName = natBeqName ∨ natAddName = natBleName ∨
       natAddName = natDivName ∨ natAddName = natModName ∨
       natAddName = natGcdName ∨ natAddName = natLandName ∨
       natAddName = natLorName ∨ natAddName = natXorName ∨
       natAddName = natShiftLeftName ∨ natAddName = natShiftRightName) ∧
      natOpStoredF fe natAddName = true := ⟨Or.inl rfl, stored⟩
  have computed : natOpResult natAddName number 0 = some (natLiteral number) := by
    rfl
  change reduceNatI callbacks fe depth
    (.app (.app (.const natAddName []) query) (natLiteral 0)) state = _
  have literalRead (n : Nat) : rawNatLitC? (natLiteral n) = some n := rfl
  dsimp only [reduceNatI, Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
    Except.bind]
  rw [ite_eq_left enabled]
  simp only [Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind,
    queryRun, literalRead, zeroRun, computed]
  all_goals rfl

theorem lazy_literal_add (callbacks : CoreFnsI) (fe : FEnv)
    (depth budget number : Nat) (query : Expr)
    (state afterQuery afterZero final : CState)
    (closed : Expr.hasFvar query = false)
    (stored : natOpStoredF fe natAddName = true)
    (queryRun : callbacks.whnf depth query state =
      .ok (natLiteral number, afterQuery))
    (zeroRun : callbacks.whnf depth (natLiteral 0) afterQuery =
      .ok (natLiteral 0, afterZero))
    (sameRun : callbacks.defeq depth (natLiteral number) (natLiteral number)
      afterZero = .ok (true, final)) :
    lazyDeltaReductionI .verified callbacks fe depth (budget + 1)
      (natLiteral number) (addZero query) state = .ok (.verdict true, final) := by
  have fold : (!Expr.hasFvar (natLiteral number) &&
      !Expr.hasFvar (addZero query)) = true := by
    simp only [natLiteral, addZero, Expr.hasFvar, closed]
    all_goals rfl
  have literalNone : reduceNatI callbacks fe depth (natLiteral number) = pure none := rfl
  have addRun := reduce_add_zero callbacks fe depth number query
    state afterQuery afterZero stored queryRun zeroRun
  rw [lazyDeltaReductionI]
  simp only [offset_literal_add, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.pure, Except.bind, fold, literalNone, ↓reduceIte, addRun, sameRun]
  all_goals rfl

/-- Every body operation is discharged through its actual branch equation.
Only the five strictly smaller callback runs are supplied. -/
theorem defeq_literal_add_body (callbacks : CoreFnsI) (fe : FEnv)
    (depth number : Nat) (query : Expr)
    (state afterLeft afterRight afterQuery afterZero final : CState)
    (closed : Expr.hasFvar query = false)
    (stored : natOpStoredF fe natAddName = true)
    (leftRun : callbacks.whnfCore true depth (natLiteral number) state =
      .ok (natLiteral number, afterLeft))
    (rightRun : callbacks.whnfCore true depth (addZero query) afterLeft =
      .ok (addZero query, afterRight))
    (queryRun : callbacks.whnf depth query afterRight =
      .ok (natLiteral number, afterQuery))
    (zeroRun : callbacks.whnf depth (natLiteral 0) afterQuery =
      .ok (natLiteral 0, afterZero))
    (sameRun : callbacks.defeq depth (natLiteral number) (natLiteral number)
      afterZero = .ok (true, final)) :
    defeqBodyI .verified callbacks fe depth (natLiteral number) (addZero query) state =
      .ok (true, final) := by
  have different : ((natLiteral number) == addZero query) = false := rfl
  have notBool : Expr.isBoolTrue (addZero query) = false := rfl
  have quick : quickDefEqI .verified callbacks depth
      (natLiteral number) (addZero query) = pure none := rfl
  have lazyRun : lazyDeltaReductionI .verified callbacks fe depth defeqLoopFuel
      (natLiteral number) (addZero query) afterRight = .ok (.verdict true, final) := by
    unfold defeqLoopFuel
    exact lazy_literal_add callbacks fe depth 99999 number query
      afterRight afterQuery afterZero final closed stored queryRun zeroRun sameRun
  simp only [defeqBodyI, different, notBool, Bool.false_and, Bool.false_eq_true,
    ↓reduceIte, Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
    Except.bind, leftRun, rightRun, quick, prop_irrel_literal, lazyRun]
  all_goals rfl

/-- The query assumption is about the original full-WHNF callback, at the
actual smaller fuel, from every supplied valid state. It preserves the exact
rest projection; this is not an assumption that the current defeq body succeeds. -/
def QueryWithRest (fe : FEnv) (fuel depth : Nat)
    (query : Expr) (number : Nat) : Prop :=
  ∀ state, KernelCachedEventualEmpty.NF .verified fe state → HelperCache fe state →
    ∃ final, (coreKnotI .verified fe fuel).whnf depth query state =
      .ok (natLiteral number, final) ∧ KernelCachedEventualEmpty.NF .verified fe final ∧
      HelperCache fe final ∧ restCaches final = restCaches state

theorem defeq_literal_add (fe : FEnv)
    (fuel depth number : Nat) (query : Expr)
    (closed : Expr.hasFvar query = false)
    (stored : natOpStoredF fe natAddName = true)
    (queryForward : QueryWithRest fe (fuel + 2) depth query number)
    (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 3)).defeq depth
      (natLiteral number) (addZero query) state = .ok (true, final) ∧
      WorkingState fe final := by
  apply defeq_forward_of_body fe (fuel + 2) depth
    (natLiteral number) (addZero query) state valid
  intro _
  obtain ⟨afterLeft, leftRun, leftValid⟩ :=
    cheap_nat fe (fuel + 1) depth number state valid
  obtain ⟨afterRight, rightRun, rightValid⟩ :=
    cheap_application fe fuel depth natAddName []
      (.app (.const natAddName []) query) (natLiteral 0)
      (add_not_recursor fe stored) rfl rfl afterLeft leftValid
  obtain ⟨afterQuery, queryRun, queryStable, queryHelpers, queryRest⟩ :=
    queryForward afterRight rightValid.nf rightValid.helpers
  have queryValid := working_after_rest fe afterRight afterQuery
    rightValid queryStable queryHelpers queryRest
  obtain ⟨afterZero, zeroRun, zeroValid, _⟩ :=
    full_nat_with_rest fe fuel depth 0 afterQuery queryValid
  obtain ⟨final, sameRun, finalValid⟩ :=
    defeq_same fe (fuel + 1) depth (natLiteral number) afterZero zeroValid
  exact ⟨final, defeq_literal_add_body _ fe depth number query state afterLeft
    afterRight afterQuery afterZero final closed stored leftRun rightRun
    queryRun zeroRun sameRun, finalValid⟩

/-! ## The actual outer Eq spine -/

/-- The original head reader consumes this precise stored annotation.
This does not assert that installation has produced such a record. -/
theorem eq_not_proof (fe : FEnv) (constant : ConstantVal) (caps : IndCaps)
    (domain body left right : Expr)
    (stored : fe.find? eqName = some (.indInfo constant caps))
    (arity : ([Level.succ .zero] : List Level).length = constant.levelParams.length)
    (annotation : constant.type = .forallE domain body ⟨.never⟩) :
    notProofFast fe.find? (eqNat left right) = true := by
  have datum : headProofPW fe.find? (.const eqName [.succ .zero]) = some .never := by
    unfold headProofPW
    dsimp only []
    rw [stored]
    change (if ([Level.succ .zero] : List Level).length = constant.levelParams.length then
      (typeSortPW fe.find? constant.type).map
        (Level.substPW constant.levelParams [.succ .zero]) else none) = some .never
    rw [ite_eq_left arity, annotation]
    rfl
  change (match headProofPW fe.find? (.const eqName [.succ .zero]) with
    | some pw => !pw.isProp
    | none => false) = true
  rw [datum]
  rfl

theorem prop_irrel_eq (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (left right other : Expr) (notProof : notProofFast fe.find? (eqNat left right) = true) :
    propIrrelI callbacks fe depth (eqNat left right) other = pure false := by
  unfold propIrrelI
  rw [notProof]
  rfl

theorem eq_not_unfoldable (fe : FEnv) (constant : ConstantVal) (caps : IndCaps)
    (left right : Expr) (stored : fe.find? eqName = some (.indInfo constant caps)) :
    unfoldableHeadC fe (eqNat left right) = false := by
  unfold unfoldableHeadC
  change (match fe.find? eqName with
    | some (.defnInfo cv _ _) => ([Level.succ .zero] : List Level).length ==
        cv.levelParams.length
    | _ => false) = false
  rw [stored]

/-- Eq is an inductive constant, so its three-argument applications neither
enter the primitive Nat branch nor unfold. This remains true with open terms. -/
theorem lazy_eq (callbacks : CoreFnsI) (fe : FEnv) (depth budget : Nat)
    (constant : ConstantVal) (caps : IndCaps) (left right last : Expr)
    (stored : fe.find? eqName = some (.indInfo constant caps)) :
    lazyDeltaReductionI .verified callbacks fe depth (budget + 1)
      (eqNat left last) (eqNat right last) =
      pure (.unknown (eqNat left last) (eqNat right last)) := by
  have offset : defeqOffsetI callbacks depth (eqNat left last) (eqNat right last) =
      pure none := rfl
  have leftNone : reduceNatI callbacks fe depth (eqNat left last) = pure none := rfl
  have rightNone : reduceNatI callbacks fe depth (eqNat right last) = pure none := rfl
  have delta : lazyDeltaStepI .verified callbacks fe depth
      (eqNat left last) (eqNat right last) = pure .unknown := by
    unfold lazyDeltaStepI
    rw [eq_not_unfoldable fe constant caps left last stored,
      eq_not_unfoldable fe constant caps right last stored]
    rfl
  funext state
  rw [lazyDeltaReductionI]
  simp only [offset, leftNone, rightNone, ite_self, delta,
    Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind]
  all_goals rfl

theorem eq_argument_list (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (left right last : Expr) (state afterType afterTerm final : CState)
    (typeRun : callbacks.defeq depth natType natType state = .ok (true, afterType))
    (termRun : callbacks.defeq depth left right afterType = .ok (true, afterTerm))
    (lastRun : callbacks.defeq depth last last afterTerm = .ok (true, final)) :
    defEqListI callbacks fe depth [natType, left, last] [natType, right, last] state =
      .ok (true, final) := by
  simp only [defEqListI, Bind.bind, StateT.bind, Except.bind,
    typeRun, termRun, lastRun, ↓reduceIte, pure, StateT.pure, Except.pure]
  all_goals rfl

theorem stuck_eq (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (left right last : Expr) (state afterHead final : CState)
    (headRun : callbacks.defeq depth (.const eqName [.succ .zero])
      (.const eqName [.succ .zero]) state = .ok (true, afterHead))
    (listRun : defEqListI callbacks fe depth [natType, left, last]
      [natType, right, last] afterHead = .ok (true, final)) :
    defeqStuckI .verified callbacks fe depth (eqNat left last) (eqNat right last)
      state = .ok (true, final) := by
  change (do
    if ← callbacks.defeq depth (.const eqName [.succ .zero])
        (.const eqName [.succ .zero]) then
      if ← defEqListI callbacks fe depth [natType, left, last]
          [natType, right, last] then
        pure true
      else stuckIrrelI .verified callbacks fe depth (eqNat left last) (eqNat right last)
    else stuckIrrelI .verified callbacks fe depth (eqNat left last) (eqNat right last))
      state = .ok (true, final)
  simp only [Bind.bind, StateT.bind, Except.bind, headRun, listRun,
    ↓reduceIte, pure, StateT.pure, Except.pure]
  all_goals rfl

theorem defeq_eq_body (callbacks : CoreFnsI) (fe : FEnv) (depth number : Nat)
    (query : Expr) (constant : ConstantVal) (caps : IndCaps)
    (state afterLeft afterRight final : CState)
    (stored : fe.find? eqName = some (.indInfo constant caps))
    (notProof : notProofFast fe.find? (eqNat (natLiteral number) (natLiteral number)) =
      true)
    (leftRun : callbacks.whnfCore true depth (eqNat (natLiteral number) (natLiteral number))
      state = .ok (eqNat (natLiteral number) (natLiteral number), afterLeft))
    (rightRun : callbacks.whnfCore true depth (eqNat (addZero query) (natLiteral number))
      afterLeft = .ok (eqNat (addZero query) (natLiteral number), afterRight))
    (congruence : defeqStuckI .verified callbacks fe depth
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) afterRight = .ok (true, final)) :
    defeqBodyI .verified callbacks fe depth
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) state = .ok (true, final) := by
  have different : ((eqNat (natLiteral number) (natLiteral number)) ==
      eqNat (addZero query) (natLiteral number)) = false := rfl
  have notBool : Expr.isBoolTrue (eqNat (addZero query) (natLiteral number)) = false := rfl
  have quick : quickDefEqI .verified callbacks depth
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) = pure none := rfl
  have lazy : lazyDeltaReductionI .verified callbacks fe depth defeqLoopFuel
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) =
      pure (.unknown (eqNat (natLiteral number) (natLiteral number))
        (eqNat (addZero query) (natLiteral number))) := by
    unfold defeqLoopFuel
    exact lazy_eq callbacks fe depth 99999 constant caps (natLiteral number)
      (addZero query) (natLiteral number) stored
  have noPair : defeqProjPairI .verified callbacks fe depth
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) = pure false := rfl
  have noLeftProj : Expr.headIsProj (eqNat (natLiteral number) (natLiteral number)) =
      false := rfl
  have noRightProj : Expr.headIsProj (eqNat (addZero query) (natLiteral number)) =
      false := rfl
  simp only [defeqBodyI, different, notBool, Bool.false_and, Bool.false_eq_true,
    ↓reduceIte, Bind.bind, StateT.bind, pure, StateT.pure, Except.pure, Except.bind,
    leftRun, rightRun, quick, prop_irrel_eq _ _ _ _ _ _ notProof,
    lazy, noPair, noLeftProj, noRightProj, Bool.not_false, Bool.true_and, congruence]
  all_goals rfl

/-- Conditional success of the original final conversion call, with every
wrapper miss-body discharged. Its query callback is two knot levels smaller.
The fixed driver call therefore offers query fuel 99998, provided all remaining
driver premises and this callback's actual proof have been established. -/
theorem eq_refl_type_defeq (fe : FEnv)
    (fuel depth number : Nat) (query : Expr) (constant : ConstantVal) (caps : IndCaps)
    (domain body : Expr)
    (closed : Expr.hasFvar query = false)
    (addStored : natOpStoredF fe natAddName = true)
    (eqStored : fe.find? eqName = some (.indInfo constant caps))
    (arity : ([Level.succ .zero] : List Level).length = constant.levelParams.length)
    (annotation : constant.type = .forallE domain body ⟨.never⟩)
    (queryForward : QueryWithRest fe (fuel + 2) depth query number)
    (state : CState) (valid : WorkingState fe state) :
    ∃ final, (coreKnotI .verified fe (fuel + 4)).defeq depth
      (eqNat (natLiteral number) (natLiteral number))
      (eqNat (addZero query) (natLiteral number)) state = .ok (true, final) ∧
      WorkingState fe final := by
  apply defeq_forward_of_body fe (fuel + 3) depth
    (eqNat (natLiteral number) (natLiteral number))
    (eqNat (addZero query) (natLiteral number)) state valid
  intro _
  have notRec := eq_not_recursor fe constant caps eqStored
  have noProof := eq_not_proof fe constant caps domain body (natLiteral number)
    (natLiteral number) eqStored arity annotation
  obtain ⟨afterLeft, leftRun, leftValid⟩ :=
    cheap_application fe (fuel + 1) depth eqName [.succ .zero]
      (.app (.app (.const eqName [.succ .zero]) natType) (natLiteral number))
      (natLiteral number) notRec rfl rfl state valid
  obtain ⟨afterRight, rightRun, rightValid⟩ :=
    cheap_application fe (fuel + 1) depth eqName [.succ .zero]
      (.app (.app (.const eqName [.succ .zero]) natType) (addZero query))
      (natLiteral number) notRec rfl rfl afterLeft leftValid
  obtain ⟨afterHead, headRun, headValid⟩ :=
    defeq_same fe (fuel + 2) depth (.const eqName [.succ .zero])
      afterRight rightValid
  obtain ⟨afterType, typeRun, typeValid⟩ :=
    defeq_same fe (fuel + 2) depth natType afterHead headValid
  obtain ⟨afterTerm, termRun, termValid⟩ :=
    defeq_literal_add fe fuel depth number query closed addStored
      queryForward afterType typeValid
  obtain ⟨final, lastRun, finalValid⟩ :=
    defeq_same fe (fuel + 2) depth (natLiteral number) afterTerm termValid
  have listRun := eq_argument_list _ fe depth (natLiteral number) (addZero query)
    (natLiteral number) afterHead afterType afterTerm final typeRun termRun lastRun
  have congruence := stuck_eq _ fe depth (natLiteral number) (addZero query)
    (natLiteral number) afterRight afterHead final headRun listRun
  exact ⟨final, defeq_eq_body _ fe depth number query constant caps
    state afterLeft afterRight final eqStored noProof leftRun rightRun congruence,
    finalValid⟩

/-! ## Finite inference and annotation interfaces

These are equations of the original bodies. An eventual driver proof must
also justify the infer/annotation memo hits from the actual reachable maps,
instantiate the actual stored Eq/Eq.refl/Nat/program types, and compose these
steps at their original fuel. None of those facts follows from an annotation
bit or from final conversion success.
-/

theorem infer_nat_body (callbacks : CoreFnsI) (fe : FEnv) (depth number : Nat)
    (state : CState) (supported : natLitSupportedF fe = true) :
    inferBodyI .verified callbacks fe depth (natLiteral number) state =
      .ok (natType, state) := by
  simp only [inferBodyI, natLiteral, supported]
  all_goals rfl

theorem infer_const_body (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (name : Name) (levels : List Level) (info : ConstantInfo) (type : Expr)
    (state final : CState) (stored : fe.find? name = some info)
    (notTower : info.isTowerEntry = false)
    (arity : levels.length = info.toConstantVal.levelParams.length)
    (helperRun : constTyAtM fe name name levels state = .ok (type, final)) :
    inferBodyI .verified callbacks fe depth (.const name levels) state =
      .ok (type, final) := by
  simp only [inferBodyI, Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
    Except.bind, stored, notTower, Bool.not_false, ↓reduceIte,
    ite_eq_left arity, helperRun]
  all_goals rfl

theorem infer_application_body (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (function argument type result : Expr) (state afterHead final : CState)
    (headRun : callbacks.infer depth (Expr.app function argument).getAppFn state =
      .ok (type, afterHead))
    (spineRun : inferSpineI callbacks fe depth type #[]
      (Expr.app function argument).getAppArgsC afterHead = .ok (result, final)) :
    inferBodyI .verified callbacks fe depth (.app function argument) state =
      .ok (result, final) := by
  simp only [inferBodyI, Bind.bind, StateT.bind, pure, StateT.pure, Except.pure,
    Except.bind, headRun, spineRun]

theorem infer_spine_done (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (type : Expr) (accumulator : Array Expr) (state : CState) :
    inferSpineI callbacks fe depth type accumulator [] state =
      .ok (Expr.instantiateRev type accumulator 0, state) := rfl

/-- A syntactic forall step still checks the argument's actual inferred type;
the original full-grade inferSpineI does not skip that check at a .never bit. -/
theorem infer_spine_forall (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (domain body argument argumentType result : Expr) (metadata : BinderMeta)
    (accumulator : Array Expr) (rest : List Expr)
    (state afterInfer afterDefeq final : CState)
    (inferRun : callbacks.infer depth argument state = .ok (argumentType, afterInfer))
    (defeqRun : callbacks.defeq depth argumentType (Expr.instantiateRev domain accumulator 0)
      afterInfer = .ok (true, afterDefeq))
    (restRun : inferSpineI callbacks fe depth body (accumulator.push argument) rest
      afterDefeq = .ok (result, final)) :
    inferSpineI callbacks fe depth (.forallE domain body metadata) accumulator
      (argument :: rest) state = .ok (result, final) := by
  simp only [inferSpineI, instListRevM, Bind.bind, StateT.bind,
    pure, StateT.pure, Except.pure, Except.bind, inferRun, defeqRun,
    ↓reduceIte, restRun]
  all_goals rfl

theorem annotate_const_body (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (name : Name) (levels : List Level) (state : CState) :
    annotateBodyI callbacks fe depth (.const name levels) state =
      .ok (.const name levels, state) := rfl

theorem annotate_nat_body (callbacks : CoreFnsI) (fe : FEnv) (depth number : Nat)
    (state : CState) (supported : natLitSupportedF fe = true) :
    annotateBodyI callbacks fe depth (natLiteral number) state =
      .ok (natLiteral number, state) := by
  simp only [annotateBodyI, natLiteral, supported]
  all_goals rfl

/-- The raw Eq.refl application uses this structural branch, together with the
constant and literal leaves. No binder or let validation is bypassed. -/
theorem annotate_application_body (callbacks : CoreFnsI) (fe : FEnv) (depth : Nat)
    (function argument annotatedFunction annotatedArgument : Expr)
    (state afterFunction final : CState)
    (functionRun : callbacks.annotate depth function state =
      .ok (annotatedFunction, afterFunction))
    (argumentRun : callbacks.annotate depth argument afterFunction =
      .ok (annotatedArgument, final)) :
    annotateBodyI callbacks fe depth (.app function argument) state =
      .ok (.app annotatedFunction annotatedArgument, final) := by
  simp only [annotateBodyI, Bind.bind, StateT.bind, pure, StateT.pure,
    Except.pure, Except.bind, functionRun, argumentRun]
  all_goals rfl

#print axioms true_defeq_empty
#print axioms true_defeq_insert
#print axioms working_empty
#print axioms working_after_rest
#print axioms working_insert_cheap
#print axioms working_insert_defeq
#print axioms defeq_forward_of_body
#print axioms defeq_same_body
#print axioms defeq_same
#print axioms cheap_forward_of_body
#print axioms cheap_nat
#print axioms cheap_const
#print axioms no_iota_of_no_recursor
#print axioms whnf_spine_no_recursor
#print axioms cheap_application_body
#print axioms cheap_application
#print axioms add_not_recursor
#print axioms eq_not_recursor
#print axioms full_nat_with_rest
#print axioms prop_irrel_literal
#print axioms offset_literal_add
#print axioms reduce_add_zero
#print axioms lazy_literal_add
#print axioms defeq_literal_add_body
#print axioms defeq_literal_add
#print axioms eq_not_proof
#print axioms prop_irrel_eq
#print axioms eq_not_unfoldable
#print axioms lazy_eq
#print axioms eq_argument_list
#print axioms stuck_eq
#print axioms defeq_eq_body
#print axioms eq_refl_type_defeq
#print axioms infer_nat_body
#print axioms infer_const_body
#print axioms infer_application_body
#print axioms infer_spine_done
#print axioms infer_spine_forall
#print axioms annotate_const_body
#print axioms annotate_nat_body
#print axioms annotate_application_body

end ADWH.Experiments.Chapter15.KernelCachedEventualRecordWrapper
/- END EXACT ORIGIN 7: KernelCachedEventualRecordWrapper -/

