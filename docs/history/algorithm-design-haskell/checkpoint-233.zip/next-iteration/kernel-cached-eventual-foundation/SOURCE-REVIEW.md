# Independent review of the consolidated eventual foundation

Reviewer: `/root`, independent of source author
`/root/reflection_evidence_review`.

**Result: PASS for the exact source assembly and its preserved review scope.**
This is a source review. The new three-owner selection has not been compiled or
accepted. Its complete fresh gate still requires separately reviewed controls.
The already consumed Eventual41 selection is not reopened.

## Exact selection and transformation

The new physical proof owner is
`source/KernelCachedEventualFoundation.lean`, 119150 bytes, SHA256
`b88b25aa807de203419c1d50b860b08950f44de8e5bf03172a91e132c162ccd5`.
Its seven frozen origins contain 117832 bytes. Root independently reconstructed
the complete new file and each complete old file using the explicit forward
and inverse records. There are nine one-line import substitutions, sixteen
unchanged complement spans including empty header spans, one initial comment
and fourteen origin-boundary comments. Every other byte is literal. No
definition, theorem statement, proof, namespace boundary, option or axiom-report
command is edited. The author assembly script was read but not executed by root.

| Origin | Public reports | Private theorem headers |
| --- | ---: | ---: |
| KernelCachedMemoRelation |16|0|
| KernelCachedEventualEmpty |8|0|
| KernelCachedEventualAtoms |9|1|
| KernelCachedHelperContract |37|1|
| KernelCachedEventualHelpers |14|0|
| KernelCachedLiteralContract |1|0|
| KernelCachedEventualRecordWrapper |41|3|

The first origin retains `import KernelCachedForward`. All nine other header
imports become the explicit line-comment prefix
`-- [assembly import internalized] ` followed by their original complete import
line. Every internalized import names an earlier physical origin or the one
retained Cached dependency. Their entire mathematical contents are already
present before each former import site. The resulting physical file has exactly
one actual import. No textual import to an omitted experimental object remains.

Core208582 and Cached202799 are the exact reduced-owner sources used in the
accepted Eventual41 run. This selection changes neither. Root checked their
identities against the existing source census and verified the three-owner
topological import graph. The complete prospective selection has 530531 source
bytes, report counts2/6/126, 134 distinct ordered public roots and six ordinary
outputs. These are source-census facts, not a measured cost or successful build.

The literal theorem-header sequence has131 entries, including the five private
helpers. The126 public report sequence and all named declaration kinds/names
match the ordered origin concatenation. Root's static checker first treated the
unchanged Core report spellings as if they were all unqualified. That checker
assertion was corrected to compare the final name component on both sides;
Core's full expected root list remains bound by its unchanged census. The new
proof owner's full qualified roots were independently derived from its actual
namespace commands. No candidate or author metadata changed for this checker
correction, and no mathematical execution occurred.

## Scope, private names and elaboration boundary

All eight namespace blocks close within their own origins. Opens are inside
those blocks. There are no explicit attributes, instances, local/scoped
commands, syntax, macros, notation, initializers or references to generated
private/auxiliary declaration names. The repeated strict options all have the
same original values: `autoImplicit=false`, `warningAsError=true` and
`Elab.async=false`. No heartbeat, recursion-depth, compiler or resource option
is introduced.

The five private source names are `full_terminal_head_atom`, `pointer_tag_eq`,
`defeq_memo_hit`, `defeq_memo_miss` and `whnf_app_skip`. Each appears only in its
own origin under its original namespace. Root independently checked every
recorded private-use line and searched the other origins for each spelling.
The three wrapper helpers do not collide with the atom or helper-contract
helpers. Their declaration/use order remains literal.

Moving declarations between physical modules changes compiler-generated private
and auxiliary identities. This review does not claim elaborated term identity,
compiled object identity, or that a previous accepted object's proof terms can
be reused. The new selection must be freshly elaborated and checked. The seven
old physical proof modules must not also be imported into the same selection;
they would duplicate canonical public declarations. Downstream physical-import
adaptations need their own exact correspondence before selection.

## Mathematical scope inherited, without acceptance transfer

The assembly preserves the six independently reviewed ingredient scopes. Root
verified all original files and both original input arrays for each scope,
including their exact canonical JSON identities:

| Scope | Author inputs | Independent-review inputs |
| --- | ---: | ---: |
| Reduced owners |514|517|
| Generic memo relation |405|409|
| Eventual empty/atoms |420|421|
| Helper contract/eventual helpers |576|581|
| Literal contract |59|60|
| Eventual record wrapper |911|912|

These are six distinct retained reviews. The assembly does not replace them
with a claim that a historical gate checked the union. The first three proof
origins were accepted in Eventual41; the helper, literal and wrapper adaptations
in this union were independently reviewed but remain uncompiled in this exact
context. Historical acceptance is not reassigned to the new physical owner.

In particular, the relation-parametric memo forwarding theorem retains actual
miss-body success, returned-state validity, scoped exact-result functionality
and auxiliary insertion frames. Eventual full/head relations concern genuine
empty-state runs above a common threshold. The finite atomic trace constructs
its root backing from a strict child body run before using memo forwarding.
The helper contract keeps all five helper clauses and actual key/tag/guard
semantics; flush requires its surviving converted-environment residue. The
literal contract owns only the original canonical literal definition and head
body equation. The record wrapper keeps the actual state/inference/annotation/
defeq bodies and its explicit `QueryWithRest` callback. None of these contracts
is weakened by the physical assembly.

The reduced-owner review's exhaustive Core census is392→340, not the author's
older389→337 filter that omitted three retained `_root_` spellings. The number
of actual omissions remains52. That separate correction stays bound in its
original review; this assembly makes no new exhaustive Core declaration claim.
Cached's actual implementation prefix and its six retained memo equations remain
literal. The unchanged reduced owners retain Lift APIs and Expr.resBool_eq.
They still do not provide the omitted pure evaluator or original installer/
BasisGen/model closure.

## Inventory and evidence controls

Root's independent checker verified916 unique author input paths, their byte
counts and SHA256 hashes, all seven origin reconstructions, all complement
spans, report/header/declaration order, namespace and private-use censuses, and
the six separate historical review arrays. The direct review scope is those916
inputs plus the author inventory, totaling917. The checker and its output are
separately bound in `SOURCE-AUDIT.json`.

All new inventory paths are local workspace-relative files. Six old external
SDK/upstream context identities are resolved only through the exact previously
reviewed owner recovery map, matching full original path, length and digest.
The original historical arrays remain unchanged. There is no general
parent-directory or arbitrary external-path resolver.

The actual41 report is retained as immutable historical evidence. Its source
key remains consumed. Its observed Core/Cached subtotal was about24.888seconds;
the complete run took26.450seconds. Consolidation removes physical module
startups, repeated loading and intermediate serializations, while retaining
all proof work and potentially increasing the new proof process's live state.
The three old proof leaves' combined time cannot be treated as wholly removable
overhead. The additional93 public reports and new combined elaboration context
have no accepted timing. No additive or extrapolated budget-fit claim follows.

## Required next gate and limitations

The next selected gate must freshly build these three complete physical sources
inside one cumulative30-second, one-CPU/thread,1-GiB process-group allowance,
with the unchanged default heartbeat/recursion/compiler options, strict flags,
three permitted axioms, ordinary output census and permanent no-retry source
key. It must bind all old scopes separately, plus this new916/917 assembly
scope, and preserve the prior enforcement/readonly snapshot controls under a
separately reviewed correspondence. No gate, compiler, evaluator, exporter,
native program, mathematical generator, preflight or saved-result reader was
executed by this review.

This foundation would provide reusable conditional cache/helper/record-wrapper
facts if accepted. It supplies no whole numeric query trace, actual stored
annotation pins, original native GroupChecked or Installed result, EnvWF/model
bridge, ground backend equality, or stock `cqueens 16 = 14772512` theorem.
