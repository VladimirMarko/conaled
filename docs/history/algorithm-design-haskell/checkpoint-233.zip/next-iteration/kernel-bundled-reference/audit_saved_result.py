#!/usr/bin/env python3
"""Read-only audit of both bundled actual-reducer attempts; never invokes it."""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RECOVERY_SHA = '42184a0bf74b2618ddf98591ea4b6786a4508a92ff2a407027ed755e5e8960a3'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
UPSTREAM = ['ConLeche.Kernel.' + name for name in [
    'Name', 'PropWhen', 'Exclusive', 'Expr', 'Level', 'ExprOps', 'Env', 'PropRead',
    'Basis.Names', 'Basis.Builder', 'Basis.Eq', 'Basis.Nat', 'Basis.Empty', 'Basis.False',
    'Basis.Quot', 'Basis.And', 'Canon', 'Basis', 'CoreDefs', 'Core', 'TypeChecker']]
MODULES = ['KernelCompactCore', 'FiniteFold', 'FirstOrderNat', 'SaturatingUInt64', 'UInt64MaskOps',
           'KernelLowOperation', 'KernelScalarSteps', 'KernelNatRecursor']
ORIGIN_MODULES = UPSTREAM + MODULES[1:]
NEW_ROOTS = {
    'KernelScalarSteps': ['ADWH.Experiments.Chapter15.KernelScalarSteps.' + name for name in
        ['whnfCore_binary', 'whnf_of_scalar_head', 'whnf_constructor', 'whnf_binary_of_runs']],
    'KernelNatRecursor': ['ADWH.Experiments.Chapter15.KernelNatRecursor.' + name for name in
        ['iotaCerts_never_prefix', 'iota_nat_zero', 'iota_nat_succ', 'whnfCore_nat_zero',
         'whnfCore_nat_succ', 'headRunsAbove_nat_zero', 'headRunsAbove_nat_succ',
         'headRunsAbove_apply', 'runsAbove_of_head_nat', 'runsAbove_nat_zero', 'runsAbove_nat_succ']],
}
ATTEMPTS = {
    'complete-01': {'report_sha': 'd7662ad372b19828e830d1911bc9690fb642e2b6d2fbc3e2f7b753893470c7ba',
        'status': 'failed', 'accepted': 51, 'observed': 62, 'attempted_modules': 8,
        'passed_modules': 7, 'artifacts': 18, 'snapshots': 16,
        'current_controls': 8, 'historical_controls': 39, 'failed_module_sorryAx': 6,
        'failed_exit_code': 1, 'failed_limit': None, 'failed_within_limits': True,
        'failed_observed_roots': NEW_ROOTS['KernelNatRecursor'], 'failed_has_diagnostics': True},
    'complete-02': {'report_sha': 'f44b12bcdb20a4ec5171556d55eda94aa9d766ea34666b0257ae8bcd3e8f26e4',
        'status': 'passed', 'accepted': 62, 'observed': 62, 'attempted_modules': 8,
        'passed_modules': 8, 'artifacts': 20, 'snapshots': 20,
        'current_controls': 12, 'historical_controls': 46, 'failed_module_sorryAx': 0,
        'failed_exit_code': None, 'failed_limit': None, 'failed_within_limits': True,
        'failed_observed_roots': [], 'failed_has_diagnostics': False},
}
POLICY = {'cumulative_wall_seconds': 30, 'resident_memory_kib': 1048576,
    'lean_memory_mib': 1024, 'compiler_threads': 1, 'autoImplicit': False,
    'warningAsError': True, 'Elab.async': False,
    'default_heartbeats_recursion_and_compiler_options': True}
PATTERN = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
CACHE = {}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def digest(path):
    require(path.is_file() and not path.is_symlink(), 'Missing/symlink evidence: ' + str(path))
    stat = path.stat()
    key = (str(path), stat.st_size, stat.st_mtime_ns)
    if key not in CACHE:
        with path.open('rb') as stream:
            CACHE[key] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return stat.st_size, CACHE[key]


def local(recorded):
    path = Path(recorded)
    if path.is_absolute():
        require('/work/' in str(path), 'Expected recorded workspace path: ' + str(path))
        path = Path(str(path).split('/work/', 1)[1])
    require(not path.is_absolute() and '..' not in path.parts, 'Escaping evidence path')
    return ROOT / path


def relative(recorded):
    return str(local(recorded).relative_to(ROOT))


def verify(row, path=None, readonly=False):
    path = local(row['path']) if path is None else path
    require(digest(path) == (row['bytes'], row['sha256']), 'Identity differs: ' + str(path))
    if readonly:
        require(path.stat().st_mode & 0o222 == 0, 'Writable frozen evidence: ' + str(path))
    return path


def outputs(module):
    return ['.olean', '.olean.server', '.olean.private', '.ir.sig', '.ir', '.ilean'] \
        if module == 'KernelCompactCore' else ['.olean', '.ilean']


def canonical_json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    recovery_path = HERE / 'SNAPSHOT-RECOVERY.json'
    require(digest(recovery_path)[1] == RECOVERY_SHA, 'Recovery map changed')
    combined = read(recovery_path)
    require(combined['format'] == 'adwh-kernel-bundled-reference-snapshot-recovery-v1'
            and set(combined['attempts']) == set(ATTEMPTS)
            and combined['whole_new_closure_accepted'] is True
            and combined['accepted_attempt'] == 'complete-02'
            and combined['accepted_scalar_root_count'] == 4
            and combined['accepted_recursor_root_count'] == 11
            and combined['source_count_or_stock_numeral_theorem_proved'] is False
            and combined['compact_omissions'] == {'source_cut_count': 7, 'total_csimp': 19,
                'additional_csimp': 4, 'additional_simp': 30, 'additional_inline': 9},
            'Recovery scope or compact-source disclosure differs')
    maps, recoveries = {}, combined['attempts']
    for row in combined['snapshot_mappings']:
        key = row['snapshot']
        require(key not in maps, 'Duplicate snapshot mapping')
        verify(row, local(row['canonical']))
        maps[key] = row
    for attempt, expected in ATTEMPTS.items():
        recovery = recoveries[attempt]
        prefix = str((HERE / 'gate/attempts' / attempt).relative_to(ROOT)) + '/'
        recovery['snapshot_mappings'] = [row for key, row in maps.items() if key.startswith(prefix)]
        require(len(recovery['snapshot_mappings']) == expected['snapshots'], 'Snapshot map count differs')
    require(len(maps) == sum(e['snapshots'] for e in ATTEMPTS.values()), 'Combined snapshot count differs')
    require(len(combined['unique_old_source_and_controls']) == 10, 'Wrong retained old-text census')
    require(len(combined['unique_accepted_current_source_and_controls']) == 8,
            'Wrong accepted current-canonical census')
    for row in combined['unique_old_source_and_controls'] + combined['unique_accepted_current_source_and_controls'] + combined['auxiliary_retained_controls']:
        verify(row)
    prior = combined['prior_complete01_preservation']
    require(prior['previous_recovery_sha256'] == '5f52ecd1591a2b3fa3ced3d8aba79df5f232e9d1bea6fcbf66cdfd3d33f0bb58'
            and prior['all_prior_records_and_canonical_file_identities_unchanged'] is True
            and canonical_json_sha(combined['snapshot_mappings'][:16]) == prior['snapshot_mappings_sha256']
            and canonical_json_sha({k: v for k, v in combined['attempts']['complete-01'].items() if k != 'snapshot_mappings'}) == prior['attempt_record_sha256']
            and canonical_json_sha(combined['unique_old_source_and_controls']) == prior['unique_old_source_and_controls_sha256']
            and canonical_json_sha(combined['auxiliary_retained_controls'][:3]) == prior['initial_auxiliary_controls_sha256'],
            'An original complete01 recovery record changed')

    def check_input(row, snapshot=False):
        path = local(row['path'])
        key = relative(row['path'])
        if key in maps:
            mapping = maps[key]
            require(all(mapping[k] == row[k] for k in ('bytes', 'sha256')), 'Snapshot mapping identity differs')
            verify(row, local(mapping['canonical']))
            if not args.source_only or path.exists():
                verify(row, path, readonly=snapshot and not args.source_only)
        else:
            verify(row, path)
        return local(maps[key]['canonical']) if key in maps else path

    summaries = []
    for attempt, expected in ATTEMPTS.items():
        path = HERE / 'gate/attempts' / attempt / 'report.json'
        require(digest(path)[1] == expected['report_sha'], 'Authoritative report changed')
        report = read(path)
        recovery = recoveries[attempt]
        check_input(recovery['report'])
        passed = expected['status'] == 'passed'
        require(report['format'] == 'adwh-kernel-bundled-reference-full-gate-v1'
                and report['attempt'] == attempt and report['stage'] == 'complete'
                and report['status'] == expected['status'] and report['module_order'] == MODULES
                and report['root_module'] == 'KernelNatRecursor', 'Wrong saved attempt/scope')
        require(report['current_control_snapshot_count'] == expected['current_controls']
                and report['historical_reference_count'] == expected['historical_controls']
                and len(report['source_bindings']) == 8
                and len(report['controls']) == expected['current_controls'] + expected['historical_controls'],
                'Wrong source/control census')
        require(report['prepared_objects'] == [] and report['expected_artifact_count'] == 20,
                'Prepared objects or output policy changed')
        require({k: report['constraints'][k] for k in POLICY} == POLICY
                and len(report['constraints']['cpu_affinity']) == 1
                and 0 < report['seconds'] and report['peak_child_rss_kib'] <= 1048576,
                'Saved resource contract differs')
        if expected['failed_limit'] == 'wall_time':
            require(report['seconds'] > 30 and report['status'] == 'failed',
                    'The recorded cumulative deadline violation must remain a failure')
        else:
            require(report['seconds'] <= 30, 'Unexpected deadline violation')
        for key in ['compiled_experimental_or_upstream_imports_reused', 'native_program_or_counter_executed',
                    'stock_numeral_theorem_proved', 'source_constant_recognition_proved',
                    'universal_count_reducer_refinement_proved', 'optimized_kernel_installed',
                    'actual_recursor_pins_discharged', 'whole_structural_evaluator_normalization_proved',
                    'whole_cached_engine_compatibility_proved', 'source_count_proved', 'integrated_project_modified',
                    'failed_compact01_mathematical_acceptance_assumed', 'native_speedup_claimed',
                    'original_units_compiled_separately', 'identical_elaborated_private_names_claimed']:
            require(report[key] is False, 'Unexpected broader acceptance: ' + key)
        for key in ['all_selected_mathematical_sources_freshly_checked',
                    'actual_reducer_operation_refinement_proved', 'logical_reference_slice_checked',
                    'general_scalar_step_contract_proved', 'conditional_nat_recursor_step_contract_proved',
                    'fuel_uniform_run_composition_proved',
                    'exact_build_artifact_inventory', 'compact_optional_source_slice_checked',
                    'source_module_consolidation_checked', 'all_mathematical_origins_covered_by_fresh_sources']:
            require(report[key] is passed, 'Incorrect whole-attempt acceptance flag: ' + key)
        require(report['all_sources_snapshots_controls_runtime_unchanged'] is True,
                'The saved attempt failed its identity postcheck')
        if attempt == 'complete-02':
            require(report['natrec_length_proof_correction_checked'] is True
                    and report['failed_bundled01_mathematical_acceptance_assumed'] is False,
                    'The successful source correction was not checked or assumes failed acceptance')
        require(report['omitted_compiler_substitution_count'] == 19
                and report['additional_compact_compiler_substitutions_omitted'] == 4
                and report['additional_simp_registrations_omitted'] == 30
                and report['additional_inline_registrations_omitted'] == 9
                and report['compact_source_cut_count'] == 7
                and report['native_compilation_optimization_choices_changed'] is True,
                'Logical-slice disclosure is absent')
        require(report['compiler_release'] == '4.35.0'
                and report['compiler_commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
                and len(report['runtime_libraries']) == 5, 'Pinned compiler/runtime metadata differs')
        if not args.source_only:
            for row in [report['compiler'], *report['runtime_libraries']]:
                recorded = Path(row['path'])
                suffix = str(recorded).split('/toolchains/', 1)[-1]
                runtime_path = ROOT.parent / 'toolchains' / suffix
                verify(row, runtime_path)

        snapshot_keys = set()
        for row in report['source_bindings'] + report['controls']:
            current = 'module' in row or row['snapshot_required']
            if current:
                require('snapshot' in row and all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')),
                        'Missing/substituted source or control snapshot')
                key = relative(row['snapshot']['path'])
                snapshot_keys.add(key)
                check_input(row['snapshot'], snapshot=True)
            else:
                check_input(row)
        require(snapshot_keys == {r['snapshot'] for r in recovery['snapshot_mappings']},
                'Recovery mapping differs from the actual snapshot roles')
        controls = {r['role']: r for r in report['controls']}
        require(len(controls) == len(report['controls']), 'Duplicate saved control role')
        require(controls['resource_helper']['sha256'] ==
                '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
                'Different resource helper')
        pin = read(check_input(controls['toolchain_pin']))
        require(all(report['compiler'][k] == pin['binaries']['lean'][k] for k in ('bytes', 'sha256')),
                'Recorded compiler differs from retained pin')
        runtime_reference = read(check_input(controls['runtime_reference']))
        expected_runtime = {Path(r['path']).name: (r['bytes'], r['sha256'])
                            for r in runtime_reference['controls'] if r['path'].endswith('.so')}
        require({Path(r['path']).name: (r['bytes'], r['sha256']) for r in report['runtime_libraries']}
                == expected_runtime, 'Recorded runtime differs from retained pin')
        require(all(report['source_manifest'][k] == controls['source_manifest'][k]
                    for k in ('path', 'bytes', 'sha256')), 'Report points to the wrong source manifest')
        manifest = read(check_input(controls['source_manifest']['snapshot'], snapshot=True))
        require(manifest['format'] == 'adwh-kernel-bundled-reference-full-manifest-v1'
                and manifest['module_order'] == MODULES and manifest['policy'] == POLICY
                and manifest['required_axiom_report_count'] == 62 and manifest['expected_artifact_count'] == 20
                and manifest['required_prints'] == report['required_prints'], 'Saved manifest scope differs')
        require([r['module'] for r in report['source_bindings']] == MODULES, 'Source module order differs')
        require(report['physical_module_count'] == manifest['physical_module_count'] == combined['physical_module_count'] == 8
                and report['mathematical_origin_count'] == manifest['mathematical_origin_count'] == combined['mathematical_origin_count'] == 28
                and report['mathematical_origin_order'] == manifest['mathematical_origin_order'] == ORIGIN_MODULES
                and [row['module'] for row in report['origin_source_bindings']] == ORIGIN_MODULES
                and len(manifest['origin_sources']) == 28, 'Physical versus origin census differs')
        bound_sources = {relative(row['path']): row for row in report['source_bindings'] + report['controls']}
        require(len(bound_sources) == len(report['source_bindings']) + len(report['controls']),
                'Duplicate actual bound source/control path')
        def bound_path(row):
            key = relative(row['path'])
            require(key in bound_sources and all(row[k] == bound_sources[key][k] for k in ('bytes', 'sha256')),
                    'Inverse/review input was not in the actual bound set')
            actual = bound_sources[key]
            return check_input(actual['snapshot'], snapshot=True) if 'snapshot' in actual else check_input(actual)
        for origin, declared in zip(report['origin_source_bindings'], manifest['origin_sources']):
            require(all(origin[k] == declared[k] for k in ('module', 'bytes', 'sha256', 'imports')),
                    'Saved mathematical origin and manifest differ')
            key = relative(origin['path'])
            require(key in bound_sources and all(origin[k] == bound_sources[key][k] for k in ('bytes', 'sha256')),
                    'An origin was not in the actual bound input set')
            bound_path(origin)
        require([row['module'] for row in report['source_inverse_checks']] == UPSTREAM
                and all(row['source_text_inverse_verified'] is True and row['explicit_eof_section_closures'] == 1
                        for row in report['source_inverse_checks'])
                and sum(row['header_edit_count'] for row in report['source_inverse_checks']) == 60,
                'Saved exact bundle inverse/scope checks differ')
        source_by_module = {row['module']: row for row in report['source_bindings']}
        origin_by_module = {row['module']: row for row in report['origin_source_bindings']}
        bundle = read(bound_path(controls['source_bundle']))
        core = bound_path(source_by_module['KernelCompactCore']).read_bytes()
        assembled = bytearray(bundle['bundle_header'].encode())
        require([row['module'] for row in bundle['origin_units']] == UPSTREAM, 'Inverse origin order differs')
        for row in bundle['origin_units']:
            original = bound_path(origin_by_module[row['module']]).read_bytes()
            require((len(original), hashlib.sha256(original).hexdigest()) ==
                    (row['original']['bytes'], row['original']['sha256']), 'Inverse original differs')
            assembled.extend(row['prefix_text'].encode())
            start, size = row['bundle_body_start_byte'], row['bundle_body_bytes']
            require(start == len(assembled), 'Bundle body offset differs')
            body = core[start:start + size]
            require(len(body) == size and hashlib.sha256(body).hexdigest() == row['bundle_body_sha256'],
                    'Bundle mapped body differs')
            forward, inverse = original, body
            for edit in reversed(row['edits']):
                at, old, new = edit['original_offset'], edit['original_text'].encode(), edit['replacement_text'].encode()
                require(forward[at:at + len(old)] == old, 'Bundle forward header span differs')
                forward = forward[:at] + new + forward[at + len(old):]
            for edit in row['edits']:
                old, new = edit['original_text'].encode(), edit['replacement_text'].encode()
                require(inverse.count(new) == 1, 'Ambiguous bundle inverse')
                inverse = inverse.replace(new, old, 1)
            require(forward == body and inverse == original, 'Exact bundle forward/inverse fails')
            assembled.extend(body); assembled.extend(row['suffix_text'].encode())
        require(bytes(assembled) == core, 'Complete bundle reconstruction differs')
        edit = bundle['project_import_edit']
        original_low = bound_path(origin_by_module['KernelLowOperation']).read_bytes()
        current_low = bound_path(source_by_module['KernelLowOperation']).read_bytes()
        before, after = edit['original_text'].encode(), edit['replacement_text'].encode()
        require(original_low.count(before) == current_low.count(after) == 1
                and original_low.replace(before, after, 1) == current_low
                and current_low.replace(after, before, 1) == original_low, 'Exact Low import inverse fails')
        if attempt == 'complete-02':
            correction = read(bound_path(controls['natrec_length_correction_map']))
            correction_audit = read(bound_path(controls['natrec_correction_audit']))
            original = bound_path(correction['original']).read_text()
            candidate = bound_path(correction['candidate']).read_text()
            forward, inverse = original, candidate
            require(len(correction['edits']) == 3 and correction_audit['exact_edits'] == correction['edits'],
                    'The accepted correction is not the reviewed three-edit variant')
            for index, edit in enumerate(correction['edits'], 1):
                require(edit['target_numeral'] == edit['occurrence_in_original'] == index
                        and forward.count(edit['old']) == 4 - index, 'Correction order/occurrence differs')
                forward = forward.replace(edit['old'], edit['new'], 1)
            for edit in reversed(correction['edits']):
                require(inverse.count(edit['new']) == 1, 'Ambiguous Natrec proof inverse')
                inverse = inverse.replace(edit['new'], edit['old'], 1)
            require(forward == candidate and inverse == original
                    and correction_audit['status'] == 'passed_source_only_correction_review_not_compiled'
                    and correction_audit['fully_qualified_roots'] == NEW_ROOTS['KernelNatRecursor']
                    and len(correction_audit['theorem_headers']) == 25
                    and len(correction_audit['inputs']) == 9, 'Accepted correction boundary differs')
            for header in correction_audit['theorem_headers']:
                require(original.count(header['header']) == candidate.count(header['header']) == 1
                        and hashlib.sha256(header['header'].encode()).hexdigest() == header['sha256'],
                        'A public/private theorem header changed')
            for row in correction_audit['inputs']:
                bound_path(row)
            recorded = report['natrec_source_correction']
            require(recorded['proof_subterm_edits'] == 3
                    and recorded['exact_forward_and_inverse_verified'] is True
                    and recorded['all_25_theorem_headers_preserved'] is True
                    and recorded['all_11_root_names_preserved'] is True,
                    'Saved accepted inverse flags differ')
            for key in ['original', 'candidate', 'actual_failed_report', 'correction_map', 'independent_review']:
                bound_path(recorded[key])
        for source, declared in zip(report['source_bindings'], manifest['sources']):
            require(all(source[k] == declared[k] for k in ('module', 'bytes', 'sha256', 'imports')),
                    'Manifest and actual source disagree')
        for item in manifest['execution_controls'] + manifest['current_controls'] + manifest['historical_controls']:
            require(item['role'] in controls and all(item[k] == controls[item['role']][k]
                    for k in ('bytes', 'sha256')), 'Control manifest crosslink differs')
        fingerprint = hashlib.sha256(json.dumps({'stage': 'complete', 'policy': POLICY,
            'sources': [{'module': r['module'], 'sha256': r['sha256']} for r in report['source_bindings']]},
            sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        require(fingerprint == report['source_fingerprint'] == manifest['source_fingerprint'], 'Source key differs')
        marker_path = verify(report['execution_marker'], readonly=not args.source_only)
        marker = read(marker_path)
        require(marker['attempt'] == attempt and marker['source_fingerprint'] == fingerprint
                and marker['source_bindings'] == report['source_bindings']
                and marker['controls'] == report['controls'] and marker['policy'] == POLICY
                and marker['compiler'] == report['compiler']
                and marker['runtime_libraries'] == report['runtime_libraries']
                and marker['mathematical_origin_order'] == report['mathematical_origin_order']
                and marker['origin_source_bindings'] == report['origin_source_bindings'], 'Permanent marker differs')

        require([m['module'] for m in report['modules']] == MODULES[:expected['attempted_modules']],
                'Saved attempted module prefix differs')
        require({m: report['required_prints'][m] for m in NEW_ROOTS} == NEW_ROOTS
                and sum(map(len, report['required_prints'].values())) == 62, 'Wrong required root census')
        accepted, observed, names, artifact_names = 0, 0, [], set()
        raw_log_bindings = []
        for index, module in enumerate(report['modules']):
            name = module['module']
            success = index < expected['passed_modules']
            out = verify(module['stdout']).read_text()
            err = verify(module['stderr']).read_text()
            raw_log_bindings.extend([module['stdout'], module['stderr']])
            raw = [{'root': root, 'axioms': [x.strip() for x in axes.split(',') if x.strip()]}
                   for root, axes in PATTERN.findall(out + err)]
            raw_names = [r['root'] for r in raw]
            permitted = all(set(r['axioms']) <= ALLOWED for r in raw)
            audit_pass = (raw_names == report['required_prints'][name]
                          and permitted and not err and not PATTERN.sub('', out).strip())
            recorded = module['axiom_audit']
            require(raw == recorded['raw_reports'] and recorded['observed_count'] == len(raw)
                    and recorded['observed_unique_count'] == len(set(raw_names))
                    and recorded['passed'] is audit_pass, 'Saved raw axiom census differs: ' + name)
            require(module['status'] == ('passed' if success else 'failed')
                    and module['exit_code'] == (0 if success else expected['failed_exit_code'])
                    and module['within_limits'] is (True if success else expected['failed_within_limits'])
                    and module['limit_exceeded'] == (None if success else expected['failed_limit'])
                    and module['required_outputs_present'] is success
                    and module['required_output_suffixes'] == outputs(name), 'Saved child acceptance differs')
            build = Path(report['object_search_path'])
            relative_module = name.replace('.', '/')
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                '-DwarningAsError=true', '-DElab.async=false', '-o', str(build / (relative_module + '.olean')),
                '-i', str(build / (relative_module + '.ilean')), relative_module + '.lean']
            require(module['command'] == command, 'Fresh compiler command differs')
            require(module['sampled_tree_and_wait4_peak_rss_kib'] <= 1048576, 'Child memory bound exceeded')
            if success:
                require(audit_pass, 'An accepted module has invalid root output')
                accepted += len(raw)
                artifact_names.update(relative(str(build / (relative_module + suffix))) for suffix in outputs(name))
            else:
                require(not audit_pass and sum('sorryAx' in r['axioms'] for r in raw) == expected['failed_module_sorryAx']
                        and raw_names == expected['failed_observed_roots']
                        and bool(recorded.get('unparsed_stdout', '')) is
                            expected.get('failed_has_diagnostics', True),
                        'Expected proof/parser/deadline diagnostics differ')
                locations = [[int(line), int(column)] for line, column in re.findall(
                    r'KernelNatRecursor\.lean:(\d+):(\d+): error:', out)]
                require(locations == recovery['observed_diagnostic_locations'] == [[535, 45], [540, 45], [542, 43]]
                        and out.count('Expected type must not contain free variables') == 3
                        and module['stdout']['bytes'] == 2187 and err == ''
                        and sum(set(row['axioms']) <= ALLOWED for row in raw) == 5,
                        'The retained three decide errors and five clean-but-unaccepted reports differ')
            observed += len(raw)
            names.extend(raw_names)
        require(accepted == expected['accepted'] == report['accepted_axiom_report_count']
                and observed == report['observed_axiom_report_count'] == expected['observed']
                and len(set(names)) == report['observed_unique_axiom_root_count'] == expected['observed'],
                'Observed and accepted totals differ')
        require(report['peak_child_rss_kib'] == max(m['sampled_tree_and_wait4_peak_rss_kib']
                for m in report['modules']), 'Peak RSS aggregation differs')
        require(report['seconds'] >= sum(m['seconds'] for m in report['modules']), 'Elapsed time excludes children')
        require(len(report['artifacts']) == expected['artifacts']
                and {relative(r['path']) for r in report['artifacts']} == artifact_names,
                'Actual complete/partial artifact inventory differs')
        require(recovery['compiled_artifact_count'] == expected['artifacts']
                and recovery['compiled_artifacts_omitted_from_source_only_archive'] is True
                and recovery['compiled_artifact_inventory_source'].startswith('report.artifacts;'),
                'Explicit artifact omission policy differs')
        for row in report['artifacts']:
            if not args.source_only:
                verify(row)
        if not args.source_only:
            actual = {str(p.relative_to(ROOT)) for p in local(report['object_search_path']).rglob('*') if p.is_file()}
            require(actual == artifact_names, 'Unrecorded file in saved build directory')
        require(len(raw_log_bindings) == recovery['log_count'] == 2 * expected['attempted_modules'] and recovery['all_logs_retained'] is True,
                'Log recovery census differs')
        require(('failure' not in report) is passed
                and 'postcheck_failure' not in report and 'affinity_restore_failure' not in report,
                'Unexpected saved failure class')
        if not passed:
            require(report['failure'] == {'type': 'ValueError',
                    'message': 'Fresh module/axiom/output/resource failure: ' + report['modules'][-1]['module']},
                    'Saved final failure explanation differs')
        else:
            require(recovery['observed_diagnostic_locations'] == [] and recovery['failed_module'] is None,
                    'Successful attempt incorrectly carries a failure classification')
        summaries.append({'attempt': attempt, 'status': report['status'], 'accepted_roots': accepted,
            'observed_roots': observed,
            'accepted_new_scalar_roots': 4 if expected['passed_modules'] >= 7 else 0,
            'accepted_new_recursor_roots': 11 if expected['passed_modules'] >= 8 else 0,
            'snapshots': expected['snapshots'], 'artifacts': expected['artifacts'],
            'seconds': report['seconds'], 'peak_rss_kib': report['peak_child_rss_kib'],
            'failed_module': None if passed else report['modules'][-1]['module'],
            'failed_limit': expected['failed_limit'], 'whole_closure_passed': passed})
    print(json.dumps({'status': 'saved_result_audit_passed', 'mode': 'source_only' if args.source_only else 'live',
        'attempts': summaries, 'snapshot_mappings_verified': len(maps),
        'compiled_artifacts_verified' if not args.source_only else 'compiled_artifacts_explicitly_omitted':
            sum(e['artifacts'] for e in ATTEMPTS.values()),
        'new_gate_compiler_counter_or_native_execution': False,
        'all_selected_whole_closures_failed': False,
        'accepted_attempt': 'complete-02',
        'passed_attempt_count': 1,
        'failed_attempt_count': 1,
        'nat_recursor_roots_accepted': 11,
        'compact_omitted_csimp_total': 19,
        'compact_additional_simp_omissions': 30,
        'failed_Natrec_clean_reports_accepted': False,
        'failed_Natrec_sorryAx_reports_accepted': False,
        'physical_module_count': 8, 'mathematical_origin_count': 28,
        'whole_count_or_stock_numeral_theorem_proved': False}, indent=2))


if __name__ == '__main__':
    main()
