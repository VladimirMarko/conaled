# Three closed spine-length decisions

The actual first bundled gate finished in 28.879820896007004 seconds, within
the unchanged budget, and failed with three proof-script diagnostics. At
Natrec lines 535, 540 and 542, `decide` rejected goals containing free
expression variables in the length of a one-, two- or three-argument spine.
Its complete output showed all eleven requested reports; six depended on
the error placeholder sorryAx. All eleven remain unaccepted because their
module failed. The other seven modules contributed 51 accepted reports.

The new local Natrec candidate is copied from the exact immutable failed05
source used by bundled01. Exactly three proof subterms change: each former
`by decide` first changes the goal to `(1 : Nat) ≠ 4`, `(2 : Nat) ≠ 4` or
`(3 : Nat) ≠ 4` respectively. The application heads are the fixed recursor
constant; getAppArgs only collects the known outer arguments and does not
inspect the unknown motive/zero/step expressions. Each list length therefore
reduces definitionally to its stated numeral. `decide` then has a closed
finite natural inequality.

Every definition, installed-rule pin, public and private theorem statement,
fuel bound, strict option and axiom-print command is unchanged. The source
map records all three literal replacements and exactly recovers the original
31,552-byte source by their inverse. All 25 theorem headers were compared.
The prior raw report, logs, source, controls and permanent execution marker
remain unchanged. This is a genuine correction of observed proof errors,
not an unchanged retry or an added resource allowance.

The corrected source has not been compiled. Its complete eight-unit closure
must be freshly checked after independent source and control review. No
success of the failed module or broader numeral theorem is assumed here.
