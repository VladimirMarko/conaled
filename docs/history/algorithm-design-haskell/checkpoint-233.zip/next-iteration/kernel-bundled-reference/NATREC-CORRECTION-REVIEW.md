# Independent review: three Natrec spine-length proof corrections

**No source-level blocker found in the exact correction. The corrected local module remains uncompiled by this reviewer.** Root authored the three proof edits; validity_contracts independently checked the actual failed output, source text and inverse. No runner, preflight, Lean, compiler or native evaluator was executed. Initial bundle source/gate reviews and all failed-attempt evidence remain unchanged.

## Actual diagnostic and acceptance boundary

Bundled complete01's report is 99,311 bytes, SHA256 `d7662ad372b19828e830d1911bc9690fb642e2b6d2fbc3e2f7b753893470c7ba`. Its recorded elapsed time is 28.879820896007004 seconds and peak RSS is 830,428 KiB. Natrec exited 1 with `within_limits = true` and no limit event. This failure is an observed proof-script failure, not a resource watchdog termination.

The 2,187-byte stdout (SHA256 `9d27e2b92a9208f10d7381081c57147873bcb5c6bedf83b5e1fd58592c5a3238`) has exactly three diagnostics, at lines 535:45, 540:45 and 542:43. Each says the expected type supplied to `decide` must not contain free variables. The displayed goals are the lengths of the one-, two- and three-argument recursor spines being unequal to four. Stderr is empty.

All eleven Natrec roots were printed in the expected order. Six contain the rejected error-recovery axiom `sorryAx`; the other five have only allowed axioms. **None of those eleven reports is accepted**, because the containing module failed. The report correctly retains 62 observed roots, 51 accepted prefix roots and 18 outputs; the two Natrec outputs are absent. The five clean reports are not promoted to a successful Natrec module or complete closure.

## Exact source correction

The current local `source/KernelNatRecursor.lean` is 31,624 bytes, SHA256 `126beff77f617603e5da5bc0662d3c64ee8962645e9ca6262cbf7dda79e358df`. Its original is the canonical failed05 source, 31,552 bytes, SHA256 `09749e3efe9096e732b7cefbc9295903a51b8ecfe188ea2cb131678020293937`. That original matches both the actual bundled01 source/snapshot identities and the original bundle source audit.

Only three subterms in private theorem `rec_prefix` change. In source order, each former `(by decide)` now reads `(by change (1 : Nat) ≠ 4; decide)`, `(by change (2 : Nat) ≠ 4; decide)` or `(by change (3 : Nat) ≠ 4; decide)`. Independent literal application of the three edits reconstructs the current source exactly. Reversing them reconstructs the original source exactly.

The `getAppArgs` recurrence collects outer application arguments, recurses through the function spine, and returns an empty list at the fixed constant head. Consequently these three lengths are definitionally 1, 2 and 3 without inspecting the unknown motive, zero branch or step expressions. `change` exposes the corresponding closed proposition before ordinary `decide`. There is no new premise, numerical queen-count assertion, resource adjustment or native decision procedure.

All 25 public/private theorem headers were compared literally and are identical. The eleven ordered public roots, every definition and installed-rule pin, all fuel/depth conditions, the sole import and the three strict source options are unchanged. Preservation of the rest of the file follows from the exact three-subterm inverse, rather than a declaration-name count alone.

## Relationship to initial source review and next gate

The initial SOURCE-REVIEW/AUDIT remain evidence for the unchanged bundle construction and its original eight-unit closure. They must not be represented as a review of the corrected physical Natrec source. This separate nine-input correction audit supplies the current local source, its exact executed origin, actual report/logs, author edit map/note and those initial reviews. A revised gate must compare the initial physical-source list to the immutable complete01 manifest, then apply this explicitly reviewed source correction when selecting the current eight-module closure.

The next gate must freshly compile all eight physical sources and retain the exact 62-root/20-output contract, source-keyed permanent markers, single cumulative 30-second deadline, one CPU and 1-GiB memory policy. No compiled objects or acceptance of the failed Natrec module may be reused. The three source changes are the basis for a new reviewed variant; changing an attempt label or controls alone would not justify retrying unchanged source.

This review establishes the source-level validity and exact scope of the proposed proof repair. It does not establish successful elaboration, useful resource headroom, installed guard discharge, whole-fold normalization, optimized-checker installation or the stock cqueens16 numeral theorem.
