# Bundled actual-kernel gate: accepted complete-02 and preserved complete-01

## Accepted result

**Complete-02 passed all 62 ordinary axiom reports, including all 11 Natrec
roots, in one fresh eight-module closure.** It finished in
27.806141771987313 seconds with peak child RSS of 834,908 KiB. All 20 default
compiler outputs and every source, snapshot, control, marker, log and runtime
integrity check passed. No old compiled upstream or experimental object was
an input.

The immutable successful report is `gate/attempts/complete-02/report.json`,
105,714 bytes, SHA256
`f44b12bcdb20a4ec5171556d55eda94aa9d766ea34666b0257ae8bcd3e8f26e4`.
Natrec stdout contains exactly the eleven required reports, all with permitted
axioms and no diagnostics; stderr is empty. The Natrec stdout is 1,397 bytes,
SHA256 `53af5c4a0eb81d7b130505f642175f97c0dfc37818177ad11f296f11a9e02cbd`.

| Recorded observation | Complete-01 | Complete-02 |
|---|---:|---:|
| Outcome | Proof diagnostics; failed | Passed |
| Cumulative elapsed seconds | 28.879820896007004 | 27.806141771987313 |
| Peak child RSS, KiB | 830,428 | 834,908 |
| Fresh physical modules passed / selected | 7 / 8 | 8 / 8 |
| Mathematical source origins | 28 | 28 |
| Observed / accepted / required reports | 62 / 51 / 62 | 62 / 62 / 62 |
| Natrec reports accepted | 0 | 11 |
| Actual / required complete outputs | 18 / 20 | 20 / 20 |
| Source/control snapshots | 16 | 20 |
| Retained stdout/stderr logs | 16 | 16 |

In complete-02, the consolidated kernel child took 13.26215455000056 seconds
and Natrec took 11.607050784004969 seconds. These are observations of the
selected run, not an isolated attribution of speedup, a robust headroom
claim, or a forecast for a larger proof closure.

## What is now proved

The passing closure freshly checks the real selected ConLeche kernel source,
the generic evaluator dependencies, Low and Scalar operation contracts, and
the eleven conditional Natrec contracts. These include zero/successor iota
steps, head reduction, application composition, and fuel-uniform full-run
composition. They concern the actual reducer and its explicit environment
and recursor-pin hypotheses, in this exact consolidated module layout.

The full gate permits only `propext`, `Classical.choice`, and `Quot.sound`.
It uses the unchanged single cumulative 30-second, one-CPU, 1-GiB policy,
default heartbeat/recursion limits, strict source options and default compiler
outputs. All eight physical inputs are checked freshly; their source maps
account for the 28 mathematical origins. Consolidation does not claim
identical elaborated private names or full cached-checker compatibility.

**Installed pins, whole structural-fold normalization, a certified cache
insertion for that fold, optimized-kernel installation, the source count and
the stock `cqueens 16` numeral theorem remain unproved by this gate.** No native
program or queen counter ran. The report keeps those broader flags false.

## Preserved first failure and exact correction

Complete-01's immutable report remains
`gate/attempts/complete-01/report.json`, 99,311 bytes, SHA256
`d7662ad372b19828e830d1911bc9690fb642e2b6d2fbc3e2f7b753893470c7ba`.
It finished within limits and failed on three actual proof diagnostics at
Natrec `535:45`, `540:45`, and `542:43`. `decide` rejected expected inequalities
containing free expression variables in the one-, two-, and three-argument
spine lengths. Six Natrec prints contained error-state `sorryAx`, and five
had clean axiom lists; **all eleven remain unaccepted for that attempt**.
The successful second attempt does not retroactively accept those reports.

Exactly three local proof subterms changed. Each now explicitly changes its
goal to `(1 : Nat) ≠ 4`, `(2 : Nat) ≠ 4`, or `(3 : Nat) ≠ 4` before ordinary
`decide`. Every definition, installed-rule pin, all 25 public/private theorem
headers, eleven ordered prints, fuel/depth condition, import and option stayed
unchanged. The three-edit inverse recovers the exact canonical Nat05 bytes
that complete-01 actually attempted. The other seven physical source files
are byte-identical between the attempts.

The initial bundle construction and its independent reviews remain unchanged
as base provenance. Separate correction source/control reviews describe the
local source change. Complete-02 freshly checks the entire corrected closure;
it imports no proof object from complete-01.

## Exact durability and recovery

`SNAPSHOT-RECOVERY.json` maps all **36** actual source/control snapshots to
canonical retained files. All sixteen original complete-01 mappings, its
ten reserved source/control files, its attempt record and its initial
auxiliary controls are unchanged. Preservation digests explicitly bind those
original records. All raw reports, **32** logs and both permanent source-key
markers remain present.

The twenty complete-02 snapshots reuse existing canonical text where their
identities match. Eight new accepted source/control texts are frozen at their
current canonical paths, including the corrected Natrec and current gate
controls. No duplicate accepted-source copies or file moves are required.
Those bound files must remain unchanged; subsequent variants need separate
sources or preservation of these exact accepted versions.

All **38** actual compiler artifacts (18 failed-prefix outputs and 20 accepted
outputs) retain their individual identities in the two raw reports. They are
explicitly omitted from source-only checkpoints, along with toolchain
binaries. Duplicate snapshot directories may be omitted only through the
exact canonical map. All mathematical source, source/control reviews,
inverse evidence, logs and markers needed by the saved audit are retained.

Both source keys remain consumed:

- Complete-01: `adfbe5cee0c7c79656a6ca6f48b81bf268690742b813f029e535ba73465b5c40`.
- Complete-02: `29f7b750eb73376afbe5f6b23f26df63d8fc94fac1125aa695f7e64bf7e7aad4`.

## Read-only independent auditor

`audit_saved_result.py` handles both attempts. It verifies exact reports,
markers, canonical mappings, physical/origin inventories, commands/resources,
raw-versus-accepted reports, source/control bindings, all 21 bundle inverses,
the Low import inverse, and the accepted three-edit Natrec inverse with all
25 preserved theorem headers. It retains the failed report's exact three
diagnostics and rejects any promotion of its clean prints to acceptance.

Live mode additionally hashes the 38 actual compiled artifacts and the pinned
compiler/runtime. `--source-only` uses their explicit omission policy and
does not rely on ZIP extraction preserving read-only permission bits. The
same source/control/log/inverse identities remain mandatory in either mode.

The auditor reads and hashes data only; it never imports or invokes a gate,
Lean, compiler, exporter, native evaluator or counter. The author has
AST-parsed this revision without executing it. Root will review the focused
`AUDITOR-COMPLETE02-CHANGES.patch` and run the read-only audit separately.
