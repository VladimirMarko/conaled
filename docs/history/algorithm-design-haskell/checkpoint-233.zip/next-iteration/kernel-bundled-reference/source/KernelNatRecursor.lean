import KernelScalarSteps

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Forward Nat.rec reduction in the actual pure verified reducer

All expressions and runs below are ConLeche's own. The pins describe active
installed rules and the annotated telescopes after the concrete universe-1
instantiation used by both structural folds. No native value, expected queen
count, successful whole-program run, or inert raw recursor is a premise.

The source is prepared for review, not yet compiled. The pins still have to
be connected to the actual installed/exported declarations. The operational
boundary is a recursor step and its fuel-uniform composition interface; it
is not a proof of the whole structural evaluator or a checker installation.
-/

namespace ADWH.Experiments.Chapter15.KernelNatRecursor

open ConLeche
open KernelLowOperation (natExpr)

def recName : ConLeche.Name := natName.str "rec"
def one : Level := .succ .zero
def natType : Expr := .const natName []

def app2 (fn first second : Expr) : Expr := .app (.app fn first) second
def app3 (fn first second third : Expr) : Expr :=
  .app (app2 fn first second) third
def app4 (fn first second third fourth : Expr) : Expr :=
  .app (app3 fn first second third) fourth

/-- A concrete level-1 Nat.rec call, including function-valued motives. -/
def recCall (motive zero step : Expr) (n : Nat) : Expr :=
  app4 (.const recName [one]) motive zero step (natExpr n)

def motiveType : Expr := .forallE natType (.sort one) ⟨.never⟩
def zeroType : Expr := .app (.bvar 0) (.const natZeroName [])
def stepType : Expr :=
  .forallE natType
    (.forallE (.app (.bvar 2) (.bvar 0))
      (.app (.bvar 3) (.app (.const natSuccName []) (.bvar 1)))
      ⟨.never⟩)
    ⟨.never⟩

/-- The entire consumed annotated recursor telescope, at universe 1. -/
def recType : Expr :=
  .forallE motiveType
    (.forallE zeroType
      (.forallE stepType
        (.forallE natType (.app (.bvar 3) (.bvar 0)) ⟨.never⟩)
        ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩

def zeroRhs : Expr :=
  .lam motiveType
    (.lam zeroType (.lam stepType (.bvar 1) ⟨.never⟩) ⟨.never⟩)
    ⟨.never⟩

def successorBody : Expr :=
  app2 (.bvar 1) (.bvar 0)
    (app4 (.const recName [one]) (.bvar 3) (.bvar 2) (.bvar 1) (.bvar 0))

def successorRhs : Expr :=
  .lam motiveType
    (.lam zeroType
      (.lam stepType (.lam natType successorBody ⟨.never⟩) ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩

/-- These are active installed rule records, not the parser's inert rules. -/
def plainRule (ctor : ConLeche.Name) (fields : Nat) (rhs : Expr) : RecRule :=
  { ctor := ctor, nfields := fields, ctorParams := 0, fire := .plain,
    rhs := rhs, k := false, eta := false, paramsBlind := true }

/-- Exact finite source guards. The theorem below does not claim that an
arbitrary environment is valid or that these pins have already been checked
against an installation. Constructor arities, universe arity, full annotated
types, full instantiated RHSs, and the existing literal-support guard are
all explicit. -/
structure NatRecPins (env : Env) where
  recVal : ConstantVal
  zeroVal : ConstantVal
  succVal : ConstantVal
  zeroRawRhs : Expr
  succRawRhs : Expr
  recNamePin : recVal.name = recName
  zeroNamePin : zeroVal.name = natZeroName
  succNamePin : succVal.name = natSuccName
  recStored : env.find? recName = some (.recInfo recVal 3 3
    [plainRule natZeroName 0 zeroRawRhs, plainRule natSuccName 1 succRawRhs])
  recLevelArity : recVal.levelParams.length = 1
  zeroStored : env.find? natZeroName = some (.ctorInfo zeroVal 0 0)
  succStored : env.find? natSuccName = some (.ctorInfo succVal 0 1)
  zeroLevels : zeroVal.levelParams = []
  succLevels : succVal.levelParams = []
  recTypePin : recVal.type.instantiateLevelParams recVal.levelParams [one] = recType
  zeroTypePin : zeroVal.type.instantiateLevelParams zeroVal.levelParams [] = natType
  succTypePin : succVal.type.instantiateLevelParams succVal.levelParams [] =
    .forallE natType natType ⟨.never⟩
  zeroRhsPin : zeroRawRhs.instantiateLevelParams recVal.levelParams [one] = zeroRhs
  succRhsPin : succRawRhs.instantiateLevelParams recVal.levelParams [one] = successorRhs
  literals : natLitSupported env = true

/-- This guard inspects actual annotated Pi binders, not a surrogate AST. -/
def neverPiPrefix : Nat → Expr → Bool
  | 0, _ => true
  | n + 1, .forallE _ body binderMeta =>
      binderMeta.pw.isNever && neverPiPrefix n body
  | _ + 1, _ => false

private theorem neverPiPrefix_instantiate1 (n : Nat) (e value : Expr) (cutoff : Nat)
    (licensed : neverPiPrefix n e = true) :
    neverPiPrefix n (e.instantiate1 value cutoff) = true := by
  induction n generalizing e cutoff with
  | zero => rfl
  | succ n ih =>
      cases e with
      | forallE domain body binderMeta =>
        change binderMeta.pw.isNever && neverPiPrefix n body = true at licensed
        have parts := Bool.and_eq_true_iff.mp licensed
        change binderMeta.pw.isNever &&
          neverPiPrefix n (body.instantiate1 value (cutoff + 1)) = true
        exact Bool.and_eq_true_iff.mpr
          ⟨parts.1, ih body (cutoff + 1) parts.2⟩
      | _ =>
        change false = true at licensed
        cases licensed

/-- The actual licensed telescope walk succeeds without an inference or
defeq call when each consumed annotated binder carries never. -/
theorem iotaCerts_never_prefix (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (ty : Expr) (args : List Expr)
    (licensed : neverPiPrefix args.length ty = true) :
    iotaCerts r env depth true ty args = .ok true := by
  induction args generalizing ty with
  | nil => rfl
  | cons arg rest ih =>
      cases ty with
      | forallE domain body binderMeta =>
        change binderMeta.pw.isNever && neverPiPrefix rest.length body = true at licensed
        have parts := Bool.and_eq_true_iff.mp licensed
        have tail : neverPiPrefix rest.length (body.instantiate1 arg) = true :=
          neverPiPrefix_instantiate1 rest.length body arg 0 parts.2
        have skip : (true && binderMeta.pw.isNever) = true := by
          rw [parts.1]
          all_goals rfl
        dsimp only [iotaCerts]
        rw [ite_eq_left skip]
        exact ih (body.instantiate1 arg) tail
      | _ =>
        change false = true at licensed
        cases licensed

#print axioms iotaCerts_never_prefix

private theorem majorToCtor_two_rules (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (name : ConLeche.Name) (first second : RecRule) (major : Expr) :
    majorToCtor .verified r env depth name [first, second] major = .ok major := by
  cases condition : isCtorApp env major <;>
    simp only [majorToCtor, condition]
  all_goals rfl

private theorem prepare_literal (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : NatRecPins env) (n : Nat)
    (literalRun : r.whnf depth (natExpr n) = .ok (natExpr n)) :
    prepareMajor .verified r env depth recName
      [plainRule natZeroName 0 pins.zeroRawRhs,
       plainRule natSuccName 1 pins.succRawRhs] (natExpr n) =
      .ok (natLitToConstructor n) := by
  have converted : litMajorToCtor r env depth (natExpr n) =
      .ok (natLitToConstructor n) := by
    change (pure (if natLitSupported env then natLitToConstructor n else natExpr n) :
      CheckM Expr) = _
    rw [ite_eq_left pins.literals]
    all_goals rfl
  change (r.whnf depth (natExpr n) >>= fun major =>
    litMajorToCtor r env depth major >>= fun convertedMajor =>
      majorToCtor .verified r env depth recName
        [plainRule natZeroName 0 pins.zeroRawRhs,
         plainRule natSuccName 1 pins.succRawRhs] convertedMajor) = _
  rw [literalRun]
  dsimp only [Bind.bind, Except.bind]
  rw [converted]
  dsimp only [Bind.bind, Except.bind]
  exact majorToCtor_two_rules r env depth recName
    (plainRule natZeroName 0 pins.zeroRawRhs)
    (plainRule natSuccName 1 pins.succRawRhs) (natLitToConstructor n)

private theorem rec_certificate (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : NatRecPins env) (motive zero step major : Expr) :
    iotaCerts r env depth true
      (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
      [motive, zero, step, major] = .ok true := by
  apply iotaCerts_never_prefix
  rw [pins.recTypePin]
  simp only [List.length_cons, List.length_nil, recType, neverPiPrefix,
    PropWhen.isNever_never, Bool.true_and]

/-- A genuine zero iota step in the existing verified reducer. The local
literal run is discharged by the already accepted literal lemma below. -/
theorem iota_nat_zero (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : NatRecPins env) (motive zero step : Expr)
    (literalRun : r.whnf depth (natExpr 0) = .ok (natExpr 0)) :
    iotaRec .verified r env depth (recCall motive zero step 0) =
      .ok (some (app3 zeroRhs motive zero step)) := by
  have prepared := prepare_literal r env depth pins 0 literalRun
  have recCert := rec_certificate r env depth pins motive zero step
    (.const natZeroName [])
  have arity : [motive, zero, step, natExpr 0].length = 3 + 1 ∧
      [one].length = pins.recVal.levelParams.length :=
    ⟨rfl, pins.recLevelArity.symm⟩
  have headEq : (recCall motive zero step 0).getAppFn =
      .const recName [one] := rfl
  have argsEq : (recCall motive zero step 0).getAppArgs =
      [motive, zero, step, natExpr 0] := rfl
  have majorArg : [motive, zero, step, natExpr 0].getD 3 (.bvar 0) =
      natExpr 0 := rfl
  have constructorHead : (natLitToConstructor 0).getAppFn =
      .const natZeroName [] := rfl
  have constructorArgs : (natLitToConstructor 0).getAppArgs = [] := rfl
  have ruleFound :
      [plainRule natZeroName 0 pins.zeroRawRhs,
       plainRule natSuccName 1 pins.succRawRhs].find?
        (fun rule => rule.ctor == natZeroName) =
        some (plainRule natZeroName 0 pins.zeroRawRhs) := rfl
  unfold iotaRec
  rw [headEq]
  dsimp only []
  rw [pins.recStored]
  dsimp only []
  rw [argsEq, ite_eq_left arity, majorArg, prepared]
  dsimp only [Bind.bind, Except.bind]
  rw [constructorHead]
  dsimp only []
  rw [pins.zeroStored]
  dsimp only []
  rw [ruleFound]
  dsimp only []
  rw [constructorArgs, pins.zeroLevels]
  change (iotaCerts r env depth true
      (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
      [motive, zero, step, .const natZeroName []] >>= fun checked =>
    if checked then
      pure (some (Expr.mkAppN
        (pins.zeroRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
        [motive, zero, step]))
    else pure none) = _
  rw [recCert]
  change (Except.ok (some (Expr.mkAppN
    (pins.zeroRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
    [motive, zero, step])) : CheckM (Option Expr)) = _
  rw [pins.zeroRhsPin]
  all_goals rfl

#print axioms iota_nat_zero

/-- The actual successor rule returns a lambda spine containing the same
Nat.rec at the predecessor literal. No result of that recursive call is
assumed here. -/
theorem iota_nat_succ (r : CoreFns CheckM) (env : Env) (depth n : Nat)
    (pins : NatRecPins env) (motive zero step : Expr)
    (literalRun : r.whnf depth (natExpr (n + 1)) = .ok (natExpr (n + 1))) :
    iotaRec .verified r env depth (recCall motive zero step (n + 1)) =
      .ok (some (app4 successorRhs motive zero step (natExpr n))) := by
  have prepared := prepare_literal r env depth pins (n + 1) literalRun
  have recCert := rec_certificate r env depth pins motive zero step
    (.app (.const natSuccName []) (natExpr n))
  have succTypePin := pins.succTypePin
  rw [pins.succLevels] at succTypePin
  have succCert : iotaCerts r env depth true
      (pins.succVal.type.instantiateLevelParams [] [])
      [natExpr n] = .ok true := by
    apply iotaCerts_never_prefix
    rw [succTypePin]
    simp only [List.length_cons, List.length_nil, neverPiPrefix,
      PropWhen.isNever_never, Bool.and_true]
  have arity : [motive, zero, step, natExpr (n + 1)].length = 3 + 1 ∧
      [one].length = pins.recVal.levelParams.length :=
    ⟨rfl, pins.recLevelArity.symm⟩
  have headEq : (recCall motive zero step (n + 1)).getAppFn =
      .const recName [one] := rfl
  have argsEq : (recCall motive zero step (n + 1)).getAppArgs =
      [motive, zero, step, natExpr (n + 1)] := rfl
  have majorArg : [motive, zero, step, natExpr (n + 1)].getD 3 (.bvar 0) =
      natExpr (n + 1) := rfl
  have constructorHead : (natLitToConstructor (n + 1)).getAppFn =
      .const natSuccName [] := rfl
  have constructorArgs : (natLitToConstructor (n + 1)).getAppArgs = [natExpr n] := rfl
  have ruleFound :
      [plainRule natZeroName 0 pins.zeroRawRhs,
       plainRule natSuccName 1 pins.succRawRhs].find?
        (fun rule => rule.ctor == natSuccName) =
        some (plainRule natSuccName 1 pins.succRawRhs) := rfl
  unfold iotaRec
  rw [headEq]
  dsimp only []
  rw [pins.recStored]
  dsimp only []
  rw [argsEq, ite_eq_left arity, majorArg, prepared]
  dsimp only [Bind.bind, Except.bind]
  rw [constructorHead]
  dsimp only []
  rw [pins.succStored]
  dsimp only []
  rw [ruleFound]
  dsimp only []
  rw [constructorArgs, pins.succLevels]
  change (iotaCerts r env depth true
      (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
      [motive, zero, step, .app (.const natSuccName []) (natExpr n)] >>= fun checked =>
    if checked then
      (iotaCerts r env depth true
        (pins.succVal.type.instantiateLevelParams [] []) [natExpr n] >>= fun ctorChecked =>
        if ctorChecked then
          pure (some (Expr.mkAppN
            (pins.succRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
            [motive, zero, step, natExpr n]))
        else pure none)
    else pure none) = _
  rw [recCert]
  change (iotaCerts r env depth true
    (pins.succVal.type.instantiateLevelParams [] []) [natExpr n] >>= fun checked =>
    if checked then
      pure (some (Expr.mkAppN
        (pins.succRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
        [motive, zero, step, natExpr n]))
    else pure none) = _
  rw [succCert]
  change (Except.ok (some (Expr.mkAppN
    (pins.succRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
    [motive, zero, step, natExpr n])) : CheckM (Option Expr)) = _
  rw [pins.succRhsPin]
  all_goals rfl

#print axioms iota_nat_succ

private theorem bounded_mono {bound larger : Nat} (le : bound ≤ larger) :
    ∀ {e : Expr}, e.looseBVarsBounded bound = true →
      e.looseBVarsBounded larger = true := by
  intro e
  induction e generalizing bound larger with
  | bvar i => simp_all [Expr.looseBVarsBounded]; omega
  | app fn arg ihFn ihArg =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihFn le h.1, ihArg le h.2⟩
  | lam domain body binderMeta ihDomain ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihDomain le h.1, ihBody (by omega) h.2⟩
  | forallE domain body binderMeta ihDomain ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihDomain le h.1, ihBody (by omega) h.2⟩
  | letE domain value body ihDomain ihValue ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨⟨ihDomain le h.1.1, ihValue le h.1.2⟩, ihBody (by omega) h.2⟩
  | proj name index e ih =>
      intro h
      simp only [Expr.looseBVarsBounded] at h ⊢
      exact ih le h
  | _ => simp [Expr.looseBVarsBounded]

private theorem instantiate_bounded {value : Expr} :
    ∀ {e : Expr} {cutoff : Nat}, e.looseBVarsBounded cutoff = true →
      e.instantiate1 value cutoff = e := by
  intro e
  induction e with
  | bvar index =>
      intro cutoff h
      simp only [Expr.looseBVarsBounded, decide_eq_true_eq] at h
      have neq : ¬ index = cutoff := by omega
      have notAbove : ¬ index > cutoff := by omega
      simp [Expr.instantiate1, neq, notAbove]
  | _ =>
      intro cutoff h
      simp_all [Expr.looseBVarsBounded, Expr.instantiate1]

private theorem instantiate_closed (e : Expr) (closed : e.looseBVarsBounded 0 = true)
    (value : Expr) (cutoff : Nat) : e.instantiate1 value cutoff = e :=
  instantiate_bounded (bounded_mono (Nat.zero_le cutoff) closed)

private theorem beta_of_head (env : Env) (fuel depth : Nat)
    (fn argument domain body : Expr)
    (headRun : whnfCore .verified env fuel depth fn =
      .ok (.lam domain body ⟨.never⟩)) :
    whnfCore .verified env (fuel + 1) depth (.app fn argument) =
      whnfCore .verified env fuel depth (body.instantiate1 argument) := by
  let r := pureFns .verified env fuel
  have hh : r.whnfCore false depth fn = .ok (.lam domain body ⟨.never⟩) := headRun
  change whnfCoreBody .verified r env false depth (.app fn argument) =
    r.whnfCore false depth (body.instantiate1 argument)
  dsimp only [whnfCoreBody]
  rw [hh]
  dsimp only [Bind.bind, Except.bind]
  rw [show betaGateFires .verified .never = true from by
    change PropWhen.isNever .never = true
    exact PropWhen.isNever_never]
  all_goals rfl

private theorem zero_rhs_beta (env : Env) (fuel depth : Nat)
    (motive zero step : Expr) (zeroClosed : zero.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 4) depth (app3 zeroRhs motive zero step) =
      whnfCore .verified env (fuel + 3) depth zero := by
  have first : whnfCore .verified env (fuel + 2) depth (.app zeroRhs motive) =
      .ok (.lam (zeroType.instantiate1 motive)
        (.lam (stepType.instantiate1 motive 1) (.bvar 1) ⟨.never⟩) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 1) depth zeroRhs motive motiveType
      (.lam zeroType (.lam stepType (.bvar 1) ⟨.never⟩) ⟨.never⟩) rfl).trans rfl
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 zeroRhs motive zero) =
      .ok (.lam ((stepType.instantiate1 motive 1).instantiate1 zero) zero ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 2) depth (.app zeroRhs motive) zero
      (zeroType.instantiate1 motive)
      (.lam (stepType.instantiate1 motive 1) (.bvar 1) ⟨.never⟩) first).trans rfl
  exact (beta_of_head env (fuel + 3) depth (app2 zeroRhs motive zero) step
    ((stepType.instantiate1 motive 1).instantiate1 zero) zero second).trans
      (congrArg (whnfCore .verified env (fuel + 3) depth)
        (instantiate_closed zero zeroClosed step 0))

private theorem successor_substitution (motive zero step : Expr) (n : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (stepClosed : step.looseBVarsBounded 0 = true) :
    Expr.instantiate1
      (((successorBody.instantiate1 motive 3).instantiate1 zero 2).instantiate1 step 1)
      (natExpr n) =
      app2 step (natExpr n) (recCall motive zero step n) := by
  have hm := instantiate_closed motive motiveClosed
  have hz := instantiate_closed zero zeroClosed
  have hs := instantiate_closed step stepClosed
  simp [successorBody, recCall, app4, app3, app2, Expr.instantiate1, hm, hz, hs]

private theorem successor_rhs_beta (env : Env) (fuel depth n : Nat)
    (motive zero step : Expr)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (stepClosed : step.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 5) depth
        (app4 successorRhs motive zero step (natExpr n)) =
      whnfCore .verified env (fuel + 4) depth
        (app2 step (natExpr n) (recCall motive zero step n)) := by
  have first : whnfCore .verified env (fuel + 2) depth (.app successorRhs motive) =
      .ok (.lam (zeroType.instantiate1 motive)
        (.lam (stepType.instantiate1 motive 1)
          (.lam natType (successorBody.instantiate1 motive 3) ⟨.never⟩)
          ⟨.never⟩) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 1) depth successorRhs motive motiveType
      (.lam zeroType (.lam stepType (.lam natType successorBody ⟨.never⟩)
        ⟨.never⟩) ⟨.never⟩) rfl).trans rfl
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 successorRhs motive zero) =
      .ok (.lam ((stepType.instantiate1 motive 1).instantiate1 zero)
        (.lam natType
          ((successorBody.instantiate1 motive 3).instantiate1 zero 2) ⟨.never⟩)
        ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 2) depth (.app successorRhs motive) zero
      (zeroType.instantiate1 motive)
      (.lam (stepType.instantiate1 motive 1)
        (.lam natType (successorBody.instantiate1 motive 3) ⟨.never⟩) ⟨.never⟩)
      first).trans rfl
  have third : whnfCore .verified env (fuel + 4) depth
      (app3 successorRhs motive zero step) =
      .ok (.lam natType
        (Expr.instantiate1
          ((successorBody.instantiate1 motive 3).instantiate1 zero 2) step 1)
        ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 3) depth (app2 successorRhs motive zero) step
      ((stepType.instantiate1 motive 1).instantiate1 zero)
      (.lam natType
        ((successorBody.instantiate1 motive 3).instantiate1 zero 2) ⟨.never⟩)
      second).trans rfl
  exact (beta_of_head env (fuel + 4) depth (app3 successorRhs motive zero step)
    (natExpr n) natType
    (((successorBody.instantiate1 motive 3).instantiate1 zero 2).instantiate1 step 1)
    third).trans
      (congrArg (whnfCore .verified env (fuel + 4) depth)
        (successor_substitution motive zero step n motiveClosed zeroClosed stepClosed))

private theorem iota_short (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : NatRecPins env) (e : Expr)
    (head : e.getAppFn = .const recName [one])
    (short : e.getAppArgs.length ≠ 4) :
    iotaRec .verified r env depth e = .ok none := by
  have arity : ¬ (e.getAppArgs.length = 3 + 1 ∧
      [one].length = pins.recVal.levelParams.length) := by
    intro h
    exact short h.1
  unfold iotaRec
  rw [head]
  dsimp only []
  rw [pins.recStored]
  dsimp only []
  rw [ite_eq_right arity]
  all_goals rfl

private theorem head_of_no_iota (env : Env) (fuel depth : Nat)
    (fn argument : Expr)
    (notLam : fn.isLam = false)
    (headRun : whnfCore .verified env fuel depth fn = .ok fn)
    (noIota : iotaRec .verified (pureFns .verified env fuel) env depth
      (.app fn argument) = .ok none) :
    whnfCore .verified env (fuel + 1) depth (.app fn argument) =
      .ok (.app fn argument) := by
  have hh : (pureFns .verified env fuel).whnfCore false depth fn = .ok fn := headRun
  change whnfCoreBody .verified (pureFns .verified env fuel) env false depth
    (.app fn argument) = _
  dsimp only [whnfCoreBody]
  rw [hh]
  dsimp only [Bind.bind, Except.bind]
  cases fn with
  | lam =>
      change true = false at notLam
      cases notLam
  | _ =>
      dsimp only []
      rw [noIota]
      all_goals rfl

private theorem rec_prefix (env : Env) (fuel depth : Nat) (pins : NatRecPins env)
    (motive zero step : Expr) :
    whnfCore .verified env (fuel + 4) depth
      (app3 (.const recName [one]) motive zero step) =
      .ok (app3 (.const recName [one]) motive zero step) := by
  have first : whnfCore .verified env (fuel + 2) depth
      (.app (.const recName [one]) motive) =
      .ok (.app (.const recName [one]) motive) :=
    head_of_no_iota env (fuel + 1) depth _ _ rfl rfl
      (iota_short _ env depth pins _ rfl (by change (1 : Nat) ≠ 4; decide))
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 (.const recName [one]) motive zero) =
      .ok (app2 (.const recName [one]) motive zero) :=
    head_of_no_iota env (fuel + 2) depth _ _ rfl first
      (iota_short _ env depth pins _ rfl (by change (2 : Nat) ≠ 4; decide))
  exact head_of_no_iota env (fuel + 3) depth _ _ rfl second
    (iota_short _ env depth pins _ rfl (by change (3 : Nat) ≠ 4; decide))

/-- The actual zero step including its three certified beta reductions.
The fuel shift is explicit and independent of the scoped depth. -/
theorem whnfCore_nat_zero (env : Env) (fuel depth : Nat) (pins : NatRecPins env)
    (motive zero step : Expr) (zeroClosed : zero.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 6) depth (recCall motive zero step 0) =
      whnfCore .verified env (fuel + 4) depth zero := by
  let r := pureFns .verified env (fuel + 5)
  have head : r.whnfCore false depth (app3 (.const recName [one]) motive zero step) =
      .ok (app3 (.const recName [one]) motive zero step) :=
    rec_prefix env (fuel + 1) depth pins motive zero step
  have reduce := iota_nat_zero r env depth pins motive zero step
    (KernelLowOperation.whnf_nat_literal env (fuel + 3) depth 0)
  change whnfCoreBody .verified r env false depth
    (.app (app3 (.const recName [one]) motive zero step) (natExpr 0)) = _
  dsimp only [whnfCoreBody]
  rw [head]
  change (iotaRec .verified r env depth (recCall motive zero step 0) >>= fun value =>
    match value with
    | some next => r.whnfCore false depth next
    | none => pure (recCall motive zero step 0)) = _
  rw [reduce]
  exact zero_rhs_beta env (fuel + 1) depth motive zero step zeroClosed

#print axioms whnfCore_nat_zero

/-- The actual successor step, at every encoded natural input. Its right
side still contains the recursive call at n, ready for a fold induction. -/
theorem whnfCore_nat_succ (env : Env) (fuel depth n : Nat) (pins : NatRecPins env)
    (motive zero step : Expr)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (stepClosed : step.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 6) depth (recCall motive zero step (n + 1)) =
      whnfCore .verified env (fuel + 4) depth
        (app2 step (natExpr n) (recCall motive zero step n)) := by
  let r := pureFns .verified env (fuel + 5)
  have head : r.whnfCore false depth (app3 (.const recName [one]) motive zero step) =
      .ok (app3 (.const recName [one]) motive zero step) :=
    rec_prefix env (fuel + 1) depth pins motive zero step
  have reduce := iota_nat_succ r env depth n pins motive zero step
    (KernelLowOperation.whnf_nat_literal env (fuel + 3) depth (n + 1))
  change whnfCoreBody .verified r env false depth
    (.app (app3 (.const recName [one]) motive zero step) (natExpr (n + 1))) = _
  dsimp only [whnfCoreBody]
  rw [head]
  change (iotaRec .verified r env depth (recCall motive zero step (n + 1)) >>= fun value =>
    match value with
    | some next => r.whnfCore false depth next
    | none => pure (recCall motive zero step (n + 1))) = _
  rw [reduce]
  exact successor_rhs_beta env fuel depth n motive zero step
    motiveClosed zeroClosed stepClosed

#print axioms whnfCore_nat_succ

/-- A uniform lower threshold for actual head normalization. -/
def HeadRunsAbove (env : Env) (e value : Expr) (threshold : Nat) : Prop :=
  ∀ fuel depth, threshold ≤ fuel → whnfCore .verified env fuel depth e = .ok value

/-- A uniform lower threshold for actual full WHNF. This is deliberately
distinct from HeadRunsAbove: full WHNF also performs literal/delta steps. -/
def RunsAbove (env : Env) (e value : Expr) (threshold : Nat) : Prop :=
  ∀ fuel depth, threshold ≤ fuel → whnf .verified env fuel depth e = .ok value

theorem headRunsAbove_nat_zero (env : Env) (pins : NatRecPins env)
    (motive zero step value : Expr) (threshold : Nat)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (base : HeadRunsAbove env zero value threshold) :
    HeadRunsAbove env (recCall motive zero step 0) value (threshold + 6) := by
  intro fuel depth enough
  have shape : fuel = (fuel - 6) + 6 := by omega
  rw [shape, whnfCore_nat_zero env (fuel - 6) depth pins motive zero step zeroClosed]
  exact base ((fuel - 6) + 4) depth (by omega)

#print axioms headRunsAbove_nat_zero

theorem headRunsAbove_nat_succ (env : Env) (pins : NatRecPins env)
    (motive zero step value : Expr) (n threshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (stepClosed : step.looseBVarsBounded 0 = true)
    (branch : HeadRunsAbove env
      (app2 step (natExpr n) (recCall motive zero step n)) value threshold) :
    HeadRunsAbove env (recCall motive zero step (n + 1)) value (threshold + 6) := by
  intro fuel depth enough
  have shape : fuel = (fuel - 6) + 6 := by omega
  rw [shape, whnfCore_nat_succ env (fuel - 6) depth n pins motive zero step
    motiveClosed zeroClosed stepClosed]
  exact branch ((fuel - 6) + 4) depth (by omega)

#print axioms headRunsAbove_nat_succ

/-- General certified beta composition, useful for the function-valued
Nat.rec results after their explicit state/cursor arguments are applied. -/
theorem headRunsAbove_apply (env : Env) (fn argument domain body value : Expr)
    (functionThreshold bodyThreshold : Nat)
    (function : HeadRunsAbove env fn (.lam domain body ⟨.never⟩) functionThreshold)
    (bodyRun : HeadRunsAbove env (body.instantiate1 argument) value bodyThreshold) :
    HeadRunsAbove env (.app fn argument) value
      (Nat.max functionThreshold bodyThreshold + 1) := by
  intro fuel depth enough
  have shape : fuel = (fuel - 1) + 1 := by omega
  have leftMax : functionThreshold ≤ Nat.max functionThreshold bodyThreshold :=
    Nat.le_max_left _ _
  have rightMax : bodyThreshold ≤ Nat.max functionThreshold bodyThreshold :=
    Nat.le_max_right _ _
  have leftEnough : functionThreshold ≤ fuel - 1 := by omega
  have rightEnough : bodyThreshold ≤ fuel - 1 := by omega
  rw [shape, beta_of_head env (fuel - 1) depth fn argument domain body
    (function (fuel - 1) depth leftEnough)]
  exact bodyRun (fuel - 1) depth rightEnough

#print axioms headRunsAbove_apply

/-- Reuse the scalar module's actual full-WHNF composition theorem.
The conservative threshold also covers its positive head-fuel precondition;
the fixed local loop budget is not a bound on the total recursion tree. -/
theorem runsAbove_of_head_nat (env : Env) (e : Expr) (result threshold : Nat)
    (head : HeadRunsAbove env e (natExpr result) threshold) :
    RunsAbove env e (natExpr result) (threshold + 2) := by
  intro fuel depth enough
  have shape : fuel = (fuel - 2) + 2 := by omega
  have headRun := head ((fuel - 2) + 1) depth (by omega)
  rw [shape]
  exact KernelScalarSteps.whnf_of_scalar_head env (fuel - 2) depth e
    (natExpr result) headRun (Or.inl ⟨result, rfl⟩)

#print axioms runsAbove_of_head_nat

theorem runsAbove_nat_zero (env : Env) (pins : NatRecPins env)
    (motive zero step : Expr) (result threshold : Nat)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (base : HeadRunsAbove env zero (natExpr result) threshold) :
    RunsAbove env (recCall motive zero step 0) (natExpr result) (threshold + 8) :=
  runsAbove_of_head_nat env _ result (threshold + 6)
    (headRunsAbove_nat_zero env pins motive zero step (natExpr result)
      threshold zeroClosed base)

#print axioms runsAbove_nat_zero

theorem runsAbove_nat_succ (env : Env) (pins : NatRecPins env)
    (motive zero step : Expr) (n result threshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (zeroClosed : zero.looseBVarsBounded 0 = true)
    (stepClosed : step.looseBVarsBounded 0 = true)
    (branch : HeadRunsAbove env
      (app2 step (natExpr n) (recCall motive zero step n)) (natExpr result) threshold) :
    RunsAbove env (recCall motive zero step (n + 1)) (natExpr result) (threshold + 8) :=
  runsAbove_of_head_nat env _ result (threshold + 6)
    (headRunsAbove_nat_succ env pins motive zero step (natExpr result) n
      threshold motiveClosed zeroClosed stepClosed branch)

#print axioms runsAbove_nat_succ

end ADWH.Experiments.Chapter15.KernelNatRecursor
