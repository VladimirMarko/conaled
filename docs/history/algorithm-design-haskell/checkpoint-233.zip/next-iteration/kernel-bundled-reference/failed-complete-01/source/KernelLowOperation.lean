import KernelCompactCore
import UInt64MaskOps

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# The low-bit operation through the actual pure kernel reducer

This module uses ConLeche.Expr and ConLeche.whnf in verified mode. It proves
normalization of the expanded arithmetic body of FirstOrderNat.low, then
transports its result to the already proved UInt64 implementation.

The three stored-operation guards are explicit operational prerequisites.
They are not a claim that an arbitrary environment is semantically valid:
the upstream declaration installer and its model invariant justify those
guards in an accepted environment. This module does not install declarations,
recognize the source constant by name, accelerate a recursive count, modify
the reducer, or assert a concrete queen count.
-/

namespace ADWH.Experiments.Chapter15.KernelLowOperation

open ConLeche

def natExpr (n : Nat) : Expr := .lit (.natVal n)

def binary (name : ConLeche.Name) (left right : Expr) : Expr :=
  .app (.app (.const name []) left) right

/-- The exact sub/mod/land body of FirstOrderNat.low at literal operands. -/
def lowExpr (modulus cursor : Nat) : Expr :=
  binary natLandName (natExpr cursor)
    (binary natModName
      (binary natSubName (natExpr modulus) (natExpr cursor))
      (natExpr modulus))

private theorem stored_definition {env : Env} {name : ConLeche.Name}
    (h : natOpStored env name = true) :
    ∃ valueType value hint,
      env.find? name = some (.defnInfo valueType value hint) := by
  cases found : env.find? name with
  | none => simp [natOpStored, found] at h
  | some info =>
      cases info <;> simp [natOpStored, found] at h
      exact ⟨_, _, _, rfl⟩

private theorem iota_definition_none
    (r : CoreFns CheckM) (env : Env) (depth : Nat) (e : Expr)
    (name : ConLeche.Name) (valueType : ConstantVal) (value : Expr)
    (hint : ReducibilityHint)
    (head : e.getAppFn = .const name [])
    (found : env.find? name = some (.defnInfo valueType value hint)) :
    iotaRec .verified r env depth e = .ok none := by
  simp only [iotaRec, head, found]
  rfl

private theorem whnfCore_definition_app
    (env : Env) (fuel depth : Nat) (name : ConLeche.Name) (arg : Expr)
    (valueType : ConstantVal) (value : Expr) (hint : ReducibilityHint)
    (found : env.find? name = some (.defnInfo valueType value hint)) :
    whnfCore .verified env (fuel + 2) depth (.app (.const name []) arg) false =
      .ok (.app (.const name []) arg) := by
  let r := pureFns .verified env (fuel + 1)
  have noIota : iotaRec .verified r env depth (.app (.const name []) arg) =
      .ok none :=
    iota_definition_none r env depth _ name valueType value hint rfl found
  change
    (iotaRec .verified r env depth (.app (.const name []) arg) >>= fun result =>
      match result with
      | some e => r.whnfCore false depth e
      | none => pure (.app (.const name []) arg)) = _
  exact congrArg
    (fun result : CheckM (Option Expr) => result >>= fun reduced =>
      match reduced with
      | some e => r.whnfCore false depth e
      | none => pure (.app (.const name []) arg)) noIota

private theorem whnfCore_binary
    (env : Env) (fuel depth : Nat) (name : ConLeche.Name) (left right : Expr)
    (stored : natOpStored env name = true) :
    whnfCore .verified env (fuel + 3) depth (binary name left right) false =
      .ok (binary name left right) := by
  obtain ⟨valueType, value, hint, found⟩ := stored_definition stored
  let r := pureFns .verified env (fuel + 2)
  have headRun : r.whnfCore false depth (.app (.const name []) left) =
      .ok (.app (.const name []) left) :=
    whnfCore_definition_app env fuel depth name left valueType value hint found
  have noIota : iotaRec .verified r env depth (binary name left right) =
      .ok none :=
    iota_definition_none r env depth _ name valueType value hint rfl found
  change whnfCoreBody .verified r env false depth (binary name left right) = _
  dsimp only [binary, whnfCoreBody]
  rw [headRun]
  change
    (iotaRec .verified r env depth (binary name left right) >>= fun result =>
      match result with
      | some e => r.whnfCore false depth e
      | none => pure (binary name left right)) = _
  exact congrArg
    (fun result : CheckM (Option Expr) => result >>= fun reduced =>
      match reduced with
      | some e => r.whnfCore false depth e
      | none => pure (binary name left right)) noIota

private theorem whnfLoop_nat_literal
    (r : CoreFns CheckM) (env : Env) (depth budget n : Nat)
    (headRun : r.whnfCore false depth (natExpr n) = .ok (natExpr n)) :
    whnfLoop r env depth (budget + 1) (natExpr n) = .ok (natExpr n) := by
  change whnfStep r env depth (whnfLoop r env depth budget) (natExpr n) = _
  unfold whnfStep
  rw [headRun]
  all_goals rfl

/-- Actual full WHNF, with sufficient knot fuel, leaves a Nat literal intact. -/
theorem whnf_nat_literal (env : Env) (fuel depth n : Nat) :
    whnf .verified env (fuel + 2) depth (natExpr n) = .ok (natExpr n) := by
  change
    whnfLoop (pureFns .verified env (fuel + 1)) env depth whnfLoopFuel
      (natExpr n) = _
  have positive : ∃ budget, whnfLoopFuel = budget + 1 :=
    ⟨99999, by unfold whnfLoopFuel; rfl⟩
  obtain ⟨budget, budgetEq⟩ := positive
  rw [budgetEq]
  all_goals exact whnfLoop_nat_literal _ env depth budget n rfl

/-- A complete actual-kernel binary normalization step. The child-run
hypotheses are discharged below by actual WHNF lemmas. The result-table
hypothesis is an equation about the existing reducer's fixed operation table,
not a supplied native count or an acceptance premise. -/
theorem whnf_binary_of_runs
    (env : Env) (fuel depth : Nat) {name : ConLeche.Name} {left right : Expr}
    {a b result : Nat}
    (operation : name = natSubName ∨ name = natModName ∨ name = natLandName)
    (stored : natOpStored env name = true)
    (leftRun : whnf .verified env (fuel + 3) depth left = .ok (natExpr a))
    (rightRun : whnf .verified env (fuel + 3) depth right = .ok (natExpr b))
    (table : natOpResult name a b = some (natExpr result)) :
    whnf .verified env (fuel + 4) depth (binary name left right) =
      .ok (natExpr result) := by
  let r := pureFns .verified env (fuel + 3)
  have headRun : r.whnfCore false depth (binary name left right) =
      .ok (binary name left right) :=
    whnfCore_binary env fuel depth name left right stored
  have hl : r.whnf depth left = .ok (natExpr a) := leftRun
  have hr : r.whnf depth right = .ok (natExpr b) := rightRun
  have recognized :
      (name = natAddName ∨ name = natSubName ∨ name = natMulName ∨
        name = natPowName ∨ name = natBeqName ∨ name = natBleName ∨
        name = natDivName ∨ name = natModName ∨ name = natGcdName ∨
        name = natLandName ∨ name = natLorName ∨ name = natXorName ∨
        name = natShiftLeftName ∨ name = natShiftRightName) ∧
        natOpStored env name = true := by
    refine ⟨?_, stored⟩
    rcases operation with rfl | rfl | rfl <;> simp
  have reduceRun : reduceNat r env depth (binary name left right) =
      .ok (some (natExpr result)) := by
    dsimp only [binary, reduceNat]
    rw [ite_eq_left recognized]
    rw [hl]
    dsimp only [Bind.bind, Except.bind, natExpr, rawNatLit?]
    rw [hr]
    dsimp only [Bind.bind, Except.bind, natExpr, rawNatLit?]
    exact congrArg Except.ok table
  change whnfLoop r env depth whnfLoopFuel (binary name left right) = _
  have twoSteps : ∃ budget, whnfLoopFuel = budget + 2 :=
    ⟨99998, by unfold whnfLoopFuel; rfl⟩
  obtain ⟨budget, budgetEq⟩ := twoSteps
  rw [budgetEq]
  change
    whnfStep r env depth (whnfLoop r env depth (budget + 1))
      (binary name left right) = _
  unfold whnfStep
  rw [headRun]
  change
    (reduceNat r env depth (binary name left right) >>= fun reduced =>
      match reduced with
      | some e => whnfLoop r env depth (budget + 1) e
      | none =>
          match unfoldDefinition env (binary name left right) with
          | some e => whnfLoop r env depth (budget + 1) e
          | none => pure (binary name left right)) = _
  rw [reduceRun]
  all_goals exact whnfLoop_nat_literal r env depth budget result rfl

/-- No result premise: all three child computations are proved here from
the existing reducer, for arbitrary natural modulus and cursor, including 0. -/
theorem lowExpr_whnf (env : Env) (fuel depth modulus cursor : Nat)
    (subStored : natOpStored env natSubName = true)
    (modStored : natOpStored env natModName = true)
    (landStored : natOpStored env natLandName = true) :
    whnf .verified env (fuel + 6) depth (lowExpr modulus cursor) =
      .ok (natExpr (FirstOrderNat.low modulus cursor)) := by
  unfold lowExpr
  refine whnf_binary_of_runs env (fuel + 2) depth
    (a := cursor) (b := (modulus - cursor) % modulus)
    (Or.inr (Or.inr rfl)) landStored ?_ ?_ ?_
  · exact whnf_nat_literal env (fuel + 3) depth cursor
  · refine whnf_binary_of_runs env (fuel + 1) depth
      (a := modulus - cursor) (b := modulus)
      (Or.inr (Or.inl rfl)) modStored ?_ ?_ ?_
    · refine whnf_binary_of_runs env fuel depth (a := modulus) (b := cursor)
        (Or.inl rfl) subStored ?_ ?_ ?_
      · exact whnf_nat_literal env (fuel + 1) depth modulus
      · exact whnf_nat_literal env (fuel + 1) depth cursor
      · rfl
    · exact whnf_nat_literal env (fuel + 2) depth modulus
    · rfl
  · rfl

/-- The actual full kernel normalization returns the Nat view of the accepted
scalar UInt64 low operation. No native execution result occurs as a premise. -/
theorem lowExpr_whnf_uint64
    (env : Env) (fuel depth width : Nat) (cursor : UInt64)
    (widthBound : width ≤ 63)
    (cursorBound : UInt64SaturatingEvaluator.InRange width cursor)
    (subStored : natOpStored env natSubName = true)
    (modStored : natOpStored env natModName = true)
    (landStored : natOpStored env natLandName = true) :
    whnf .verified env (fuel + 6) depth (lowExpr (2 ^ width) cursor.toNat) =
      .ok (natExpr
        (UInt64SaturatingEvaluator.low (UInt64SaturatingEvaluator.modulus width)
          cursor).toNat) :=
  (lowExpr_whnf env fuel depth (2 ^ width) cursor.toNat
    subStored modStored landStored).trans
      (congrArg (fun n : Nat => (Except.ok (natExpr n) : CheckM Expr))
        (UInt64SaturatingEvaluator.low_toNat width cursor widthBound cursorBound).symm)

/-- Existential sufficient fuel in the unchanged pure verified reducer. -/
theorem lowExpr_whnf_uint64_exists
    (env : Env) (depth width : Nat) (cursor : UInt64)
    (widthBound : width ≤ 63)
    (cursorBound : UInt64SaturatingEvaluator.InRange width cursor)
    (subStored : natOpStored env natSubName = true)
    (modStored : natOpStored env natModName = true)
    (landStored : natOpStored env natLandName = true) :
    ∃ fuel, whnf .verified env fuel depth (lowExpr (2 ^ width) cursor.toNat) =
      .ok (natExpr
        (UInt64SaturatingEvaluator.low (UInt64SaturatingEvaluator.modulus width)
          cursor).toNat) :=
  ⟨6, lowExpr_whnf_uint64 env 0 depth width cursor widthBound cursorBound
    subStored modStored landStored⟩

#print axioms whnf_nat_literal
#print axioms whnf_binary_of_runs
#print axioms lowExpr_whnf
#print axioms lowExpr_whnf_uint64
#print axioms lowExpr_whnf_uint64_exists

end ADWH.Experiments.Chapter15.KernelLowOperation
