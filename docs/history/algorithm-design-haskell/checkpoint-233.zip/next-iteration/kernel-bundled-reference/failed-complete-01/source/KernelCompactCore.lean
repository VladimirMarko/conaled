module

public import Std.Data.HashMap
import all Init.Util

/-! This is a fresh source bundle of the 21 exact compact logical
kernel units. No compiled objects are inputs. Each original public
section is closed explicitly at its former end of file. See the
exact reversible SOURCE-BUNDLE.json origin and edit map. -/

/- BEGIN exact source origin ConLeche.Kernel.Name -/
-- Bundled origin 00, header line 1: module

-- Bundled origin 00, header line 3: public import Std.Data.HashMap
/- `withPtrEq` is `public` but not `@[expose]`, and its whole point here
is that it is *definitionally* `k ()` — which is what
`Name.beqPtr_eq` proves.  `import all` makes that body visible **in
this module only**; that theorem is the public relay, so no importer
needs it, and the executed `Name.beq` stays the plain
`decide (· = ·)` that the kernel can still reduce. -/
-- Bundled origin 00, header line 10: import all Init.Util

/-!
# Hierarchical names

`ConLeche.Name`, the checker's own mirror of `Lean.Name` (cached hash in
a `@[computed_field]`, pointer-and-hash-guarded equality substituted by
`@[csimp]`).  Split out of `ConLeche/Kernel/Expr.lean` on 2026-09-06 so
that `ConLeche/Kernel/PropWhen.lean` — which needs names and nothing
else — can sit *below* the expression type it annotates.
-/

@[expose] public section

namespace ConLeche

/-- Hierarchical names, same shape as `Lean.Name` — including the
cached hash, which lives in a `@[computed_field]` exactly as
`Lean.Name`'s does (`@[computed_field, inline] hash : Name → UInt64`,
`Init/Prelude.lean`; the C runtime stores it in the object header and
reads it with `lean_name_hash_ptr`).  Logically the field is a
*function of the value*, so it is invisible to every statement:
`DecidableEq` is still the derived structural equality, and the field
only spares the `Hashable` instance a walk (task #176 P3). -/
inductive Name where
  | anonymous
  | str (pre : Name) (s : String)
  | num (pre : Name) (n : Nat)
with
  /-- The cached hash of a name (official: the `uint64` in the `Name`
  object's header). -/
  @[computed_field] hashData : Name → UInt64
    | .anonymous => 1723
    | .str p s => mixHash (mixHash 1 p.hashData) (hash s)
    | .num p n => mixHash (mixHash 2 p.hashData) (hash n)
deriving DecidableEq, Repr, Inhabited

/-- Hashing a name is an `O(1)` field read, not a structural walk with
a byte-wise `String` hash per limb. -/
instance : Hashable Name := ⟨Name.hashData⟩

/-- Name equality in the official kernel's shape (task #176 P1):
**pointer** (`lean_name_eq`'s `if (n1 == n2) return true`), then the
**cached hash** (`lean_name_hash_ptr`), then the structural walk —
`_tmp/lean4-master-kernel/lean4_object.cpp:2762`.  This is the
*implementation* of `Name.beq`; `Name.beqPtr_eq` proves the two guards
redundant. -/
@[inline] def Name.beqPtr (a b : Name) : Bool :=
  withPtrEq a b (fun _ => a.hashData == b.hashData && decide (a = b))
    (fun h => by subst h; simp)

/-- Both guards are redundant: `withPtrEq a b k h` is *defined* as
`k ()`, and `hashData` is a function of the value, so a hash mismatch
**is** an inequality. -/
theorem Name.beqPtr_eq (a b : Name) : Name.beqPtr a b = decide (a = b) := by
  show (a.hashData == b.hashData && decide (a = b)) = decide (a = b)
  by_cases h : a = b
  · subst h; simp
  · simp [h]

/-- The executed name equality.  Definitionally `decide (a = b)` — so
the kernel, `by decide` and `#guard` still see plain structural
equality — with `beqPtr` substituted by the compiler on the strength
of the `@[csimp]` equation below. -/
def Name.beq (a b : Name) : Bool := decide (a = b)

/-- **The compiler substitution, on a kernel-checked equality.**
`@[csimp]` (not `@[implemented_by]`) is what replaces `Name.beq` by
`Name.beqPtr` in compiled code — *"do not use `implemented_by`.  If
you can prove them equal, use `csimp`"* (user ruling, 2026-09-05).
Nothing here is taken on faith: `withPtrEq a b k h` is *defined* as
`k ()` and its obligation is discharged at `beqPtr`, and `hashData` is
a function of the value, so the hash guard cannot reject an equal
pair.  `Expr.beq` is substituted the same way (`Expr.beq_eq_beqMemo`),
so no equality in the tree is an escape. -/
@[csimp] theorem Name.beq_eq_beqPtr : @Name.beq = @Name.beqPtr := by
  funext a b; exact (Name.beqPtr_eq a b).symm

instance : BEq Name := ⟨Name.beq⟩

/-- `Name.beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Name where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Name.beq]

namespace Name

/-- Conversion from `Lean.Name` (dropping macro scopes is the caller's duty). -/
def ofLeanName : Lean.Name → Name
  | .anonymous => .anonymous
  | .str p s => .str (ofLeanName p) s
  | .num p n => .num (ofLeanName p) n

protected def toString : Name → String
  | .anonymous => "[anonymous]"
  | .str .anonymous s => s
  | .str p s => p.toString ++ "." ++ s
  | .num .anonymous n => toString n
  | .num p n => p.toString ++ "." ++ toString n

instance : ToString Name := ⟨Name.toString⟩

end Name

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Name
/- END exact source origin ConLeche.Kernel.Name -/

/- BEGIN exact source origin ConLeche.Kernel.PropWhen -/
-- Bundled origin 01, header line 1: module

-- Bundled origin 01, header line 3: public import ConLeche.Kernel.Name

/-!
# The zero-ness datum `PropWhen` — representation, API and laws
(task #161; the small-list constructors, 2026-09-06; the canonical
representation, task #194, 2026-09-06)

The binder annotation of the validated-annotation design: the reading
of a codomain sort's zero-ness predicate `Z(l) = {φ | eval φ l = 0}`.

**This module is the datum's whole boundary.**  It owns the
representation, the API that is the only way to build, read and
compare a datum, and — following the `Std.HashMap` pattern that
`CLAUDE.md` licenses for a self-contained data-structure verification
— every law about the datum *alone*.  Downstream never re-proves them
and never sees a constructor:

* the readout `holds` and its algebra (`holds_inter`,
  `holds_bindZ_go`, `holds_ext`);
* the comparison — which is **equality**: `=`/`==`/`DecidableEq`
  decide zero-ness agreement at every valuation (`eq_iff_holds`), so
  the checker's validation and defeq sites compare with `==` and no
  separate comparison exists (task #197);
* the `inter`/`bindZ` algebra the substitution laws rest on
  (`inter_assoc`, `bindZ_inter`, `bindZ_go_append`,
  `bindZ_congr_names`, `bindZ_unit`, `paramsDefined_inter_of`).

**Canonical by construction (task #194).**  Every value of the type is
the unique representative of its parameter *set*: the parameter list
is strictly ascending in a total order on names (`Name.cmp`, defined
here), the invariant is carried by the constructors themselves, and
every producer (`ifAllZero`, `inter`, `bindZ`, hence
`Level.zeronessOf`/`Level.substPW`) normalizes.  Consequently
`ifAllZero ps = ifAllZero qs ↔ (∀ n, n ∈ ps ↔ n ∈ qs)`
(`ifAllZero_eq_iff`), `=`/`==`/`DecidableEq`/`Hashable` all decide
zero-ness agreement, and the level-instantiation identity law
(`Level.substPW_self`, `ConLeche/Verify/PropWhen.lean`) holds
unconditionally — amendment 2's counterexample (DESIGN.md, task #161
P1) was a *normalizing* substitution meeting a *non-canonical* input,
and non-canonical inputs no longer exist.

What is *not* here is what is not about the datum alone: the laws
relating it to `Level` (`Level.zeronessOf`, `Level.substPW` —
`zeronessOf_sound`, `zeronessOf_subst`, `substPW_self`,
`substPW_comp`, `holds_substPW`) live in `ConLeche/Verify/PropWhen.lean`,
because `Level` is defined *above* this module, and they are proved
purely through the API exported here.

Layering: this module imports `ConLeche.Kernel.Name` and nothing else.
-/

public section

namespace ConLeche

-- Compatibility edit: explicitly declare the formerly implicit universe.
universe u

/-! ## A strict total order on names

There is no order on `ConLeche.Name` elsewhere in the tree, so
the canonical form needs one.  `Name.cmp` is the structural
lexicographic order — the shape of `Lean.Name.quickLt` minus the hash
short-cut, which would make the order depend on hashing.  Constructor
order is `anonymous < str < num`; equal constructors compare the
prefix first, then the payload with the core `Ord` instances
(`String`/`Nat`), whose `Std.TransCmp`/`Std.LawfulEqCmp` instances
supply the payload half of every law below.  `a < b` is `cmp a b =
.lt`; it is decidable, irreflexive, transitive, asymmetric and
trichotomous (`lt_irrefl`, `lt_trans`, `lt_asymm`, `lt_trichotomy`) —
a strict total order. -/

namespace Name

/-- Structural lexicographic comparison of names. -/
def cmp : Name → Name → Ordering
  | .anonymous, .anonymous => .eq
  | .anonymous, .str _ _ => .lt
  | .anonymous, .num _ _ => .lt
  | .str _ _, .anonymous => .gt
  | .num _ _, .anonymous => .gt
  | .str _ _, .num _ _ => .lt
  | .num _ _, .str _ _ => .gt
  | .str p s, .str q t => (cmp p q).then (compare s t)
  | .num p m, .num q n => (cmp p q).then (compare m n)

/-- The strict order: `cmp` reading `lt`. -/
instance : LT Name := ⟨fun a b => cmp a b = .lt⟩

instance (a b : Name) : Decidable (a < b) :=
  inferInstanceAs (Decidable (cmp a b = .lt))

theorem lt_def {a b : Name} : a < b ↔ cmp a b = .lt := Iff.rfl

theorem cmp_self : ∀ a : Name, cmp a a = .eq
  | .anonymous => rfl
  | .str p s => by
    simp [cmp, cmp_self p, Ordering.then, Std.ReflCmp.compare_self]
  | .num p n => by
    simp [cmp, cmp_self p, Ordering.then, Std.ReflCmp.compare_self]

theorem eq_of_cmp : ∀ {a b : Name}, cmp a b = .eq → a = b
  | .anonymous, .anonymous, _ => rfl
  | .str p s, .str q t, h => by
    rw [cmp, Ordering.then_eq_eq] at h
    rw [eq_of_cmp h.1, Std.LawfulEqCmp.compare_eq_iff_eq.mp h.2]
  | .num p m, .num q n, h => by
    rw [cmp, Ordering.then_eq_eq] at h
    rw [eq_of_cmp h.1, Std.LawfulEqCmp.compare_eq_iff_eq.mp h.2]

theorem cmp_swap : ∀ a b : Name, cmp a b = (cmp b a).swap
  | .anonymous, .anonymous => rfl
  | .anonymous, .str _ _ => rfl
  | .anonymous, .num _ _ => rfl
  | .str _ _, .anonymous => rfl
  | .num _ _, .anonymous => rfl
  | .str _ _, .num _ _ => rfl
  | .num _ _, .str _ _ => rfl
  | .str p s, .str q t => by
    rw [cmp, cmp, Ordering.swap_then, ← cmp_swap p q,
      ← Std.OrientedCmp.eq_swap (cmp := compare)]
  | .num p m, .num q n => by
    rw [cmp, cmp, Ordering.swap_then, ← cmp_swap p q,
      ← Std.OrientedCmp.eq_swap (cmp := compare)]

theorem cmp_trans : ∀ {a b c : Name}, cmp a b = .lt → cmp b c = .lt →
    cmp a c = .lt
  | .anonymous, .str _ _, .str _ _, _, _ => rfl
  | .anonymous, .str _ _, .num _ _, _, _ => rfl
  | .anonymous, .num _ _, .num _ _, _, _ => rfl
  | .str _ _, .num _ _, .num _ _, _, _ => rfl
  | .anonymous, .anonymous, _, h, _ => by simp [cmp] at h
  | .str _ _, .str _ _, .num _ _, _, _ => rfl
  | .str p s, .str q t, .str r u, h1, h2 => by
    rw [cmp, Ordering.then_eq_lt] at h1 h2 ⊢
    rcases h1 with h1 | ⟨h1, hs⟩
    · rcases h2 with h2 | ⟨h2, _⟩
      · exact Or.inl (cmp_trans h1 h2)
      · exact Or.inl (eq_of_cmp h2 ▸ h1)
    · rcases h2 with h2 | ⟨h2, ht⟩
      · exact Or.inl (eq_of_cmp h1 ▸ h2)
      · have hpq : p = q := eq_of_cmp h1
        have hqr : q = r := eq_of_cmp h2
        subst hpq; subst hqr
        exact Or.inr ⟨cmp_self p, Std.TransCmp.lt_trans hs ht⟩
  | .num p m, .num q n, .num r k, h1, h2 => by
    rw [cmp, Ordering.then_eq_lt] at h1 h2 ⊢
    rcases h1 with h1 | ⟨h1, hs⟩
    · rcases h2 with h2 | ⟨h2, _⟩
      · exact Or.inl (cmp_trans h1 h2)
      · exact Or.inl (eq_of_cmp h2 ▸ h1)
    · rcases h2 with h2 | ⟨h2, ht⟩
      · exact Or.inl (eq_of_cmp h1 ▸ h2)
      · have hpq : p = q := eq_of_cmp h1
        have hqr : q = r := eq_of_cmp h2
        subst hpq; subst hqr
        exact Or.inr ⟨cmp_self p, Std.TransCmp.lt_trans hs ht⟩

theorem lt_irrefl (a : Name) : ¬ a < a := by
  simp [lt_def, cmp_self]

theorem lt_trans {a b c : Name} (h1 : a < b) (h2 : b < c) : a < c :=
  cmp_trans h1 h2

theorem lt_asymm {a b : Name} (h : a < b) : ¬ b < a := by
  have h' : cmp a b = .lt := h
  have : cmp b a = .gt := by
    rw [cmp_swap b a, h']; rfl
  simp [lt_def, this]

/-- `gt` read backwards. -/
theorem lt_of_gt {a b : Name} (h : cmp a b = .gt) : b < a := by
  rw [lt_def, cmp_swap b a, h]; rfl

/-- Trichotomy: names are linearly ordered by `<`. -/
theorem lt_trichotomy (a b : Name) : a = b ∨ a < b ∨ b < a := by
  cases h : cmp a b with
  | eq => exact Or.inl (eq_of_cmp h)
  | lt => exact Or.inr (Or.inl h)
  | gt => exact Or.inr (Or.inr (lt_of_gt h))

end Name

/-! ## The sorted-list layer

The representation invariant is one predicate: `Sorted` — strictly
ascending, which is sortedness and duplicate-freeness in a single
clause (`List.Pairwise (· < ·)`).  `merge` is the ordered union of two
sorted lists, `canon` sorts-and-deduplicates an arbitrary list by
folding singletons in, and `sorted_ext` is the canonical-form theorem
the whole module rests on: two sorted lists with the same members are
the same list. -/

namespace PropWhen

/-- Strictly ascending: sorted **and** duplicate-free, in one clause. -/
abbrev Sorted (ps : List Name) : Prop := List.Pairwise (· < ·) ps

/-- Membership-equal lists agree on every `all`. -/
private theorem all_eq_of_mem_iff {ps qs : List Name}
    (h : ∀ n, n ∈ ps ↔ n ∈ qs) (f : Name → Bool) :
    ps.all f = qs.all f := by
  rw [Bool.eq_iff_iff]
  simp only [List.all_eq_true]
  exact ⟨fun hp n hn => hp n ((h n).mpr hn), fun hq n hn => hq n ((h n).mp hn)⟩

/-- The ordered merge of two sorted lists — the union of the two sets,
sorted again (`sorted_merge`). -/
def merge : List Name → List Name → List Name
  | [], bs => bs
  | a :: as, [] => a :: as
  | a :: as, b :: bs =>
    match Name.cmp a b with
    | .lt => a :: merge as (b :: bs)
    | .eq => a :: merge as bs
    | .gt => b :: merge (a :: as) bs
termination_by as bs => as.length + bs.length

@[simp] theorem merge_nil : ∀ as : List Name, merge as [] = as
  | [] => by simp [merge]
  | _ :: _ => by simp [merge]

@[simp] theorem nil_merge (bs : List Name) : merge [] bs = bs := by
  simp [merge]

@[simp] theorem mem_merge : ∀ (as bs : List Name) {n : Name},
    n ∈ merge as bs ↔ n ∈ as ∨ n ∈ bs := by
  intro as bs
  fun_induction merge as bs with
  | case1 bs => simp
  | case2 a as => simp
  | case3 a as b bs hc ih =>
    intro n; simp only [List.mem_cons, ih]; grind
  | case4 a as b bs hc ih =>
    intro n
    have hab : a = b := Name.eq_of_cmp hc
    simp only [List.mem_cons, ih, hab]; grind
  | case5 a as b bs hc ih =>
    intro n; simp only [List.mem_cons, ih]; grind

theorem all_merge (P : Name → Bool) (as bs : List Name) :
    (merge as bs).all P = (as.all P && bs.all P) := by
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, List.all_eq_true, mem_merge]
  exact ⟨fun h => ⟨fun x hx => h x (.inl hx), fun x hx => h x (.inr hx)⟩,
    fun h x hx => hx.elim (h.1 x) (h.2 x)⟩

theorem sorted_merge : ∀ {as bs : List Name}, Sorted as → Sorted bs →
    Sorted (merge as bs) := by
  intro as bs
  fun_induction merge as bs with
  | case1 bs => intro _ h; exact h
  | case2 a as => intro h1 _; exact h1
  | case3 a as b bs hc ih =>
    intro h1 h2
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih h1.2 (List.pairwise_cons.mpr h2)⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · exact h1.1 m hm
    · rcases List.mem_cons.mp hm with rfl | hm
      · exact hc
      · exact Name.lt_trans hc (h2.1 m hm)
  | case4 a as b bs hc ih =>
    intro h1 h2
    have hab : a = b := Name.eq_of_cmp hc
    subst hab
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih h1.2 h2.2⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · exact h1.1 m hm
    · exact h2.1 m hm
  | case5 a as b bs hc ih =>
    intro h1 h2
    have hba : b < a := Name.lt_of_gt hc
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih (List.pairwise_cons.mpr h1) h2.2⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · rcases List.mem_cons.mp hm with rfl | hm
      · exact hba
      · exact Name.lt_trans hba (h1.1 m hm)
    · exact h2.1 m hm

/-- Canonicalize a raw list: sort and deduplicate, by folding the
singletons together. -/
def canon (ps : List Name) : List Name :=
  ps.foldr (fun n s => merge [n] s) []

@[simp] theorem canon_nil : canon [] = [] := by simp [canon]

@[simp] theorem canon_cons (n : Name) (ps : List Name) :
    canon (n :: ps) = merge [n] (canon ps) := by simp [canon]

@[simp] theorem mem_canon {n : Name} : ∀ {ps : List Name},
    n ∈ canon ps ↔ n ∈ ps
  | [] => by simp
  | m :: rest => by simp [mem_canon (ps := rest)]

theorem sorted_canon : ∀ ps : List Name, Sorted (canon ps)
  | [] => List.Pairwise.nil
  | m :: rest => sorted_merge (by simp [Sorted]) (sorted_canon rest)

theorem all_canon (P : Name → Bool) (ps : List Name) :
    (canon ps).all P = ps.all P :=
  all_eq_of_mem_iff (fun _ => mem_canon) P

theorem canon_eq_nil_iff {ps : List Name} : canon ps = [] ↔ ps = [] := by
  rw [List.eq_nil_iff_forall_not_mem, List.eq_nil_iff_forall_not_mem]
  simp only [mem_canon]

theorem isEmpty_canon (ps : List Name) : (canon ps).isEmpty = ps.isEmpty := by
  rw [Bool.eq_iff_iff, List.isEmpty_iff, List.isEmpty_iff, canon_eq_nil_iff]

/-- **The canonical-form theorem**: two sorted lists with the same
members are the same list. -/
theorem sorted_ext : ∀ {as bs : List Name}, Sorted as → Sorted bs →
    (∀ n, n ∈ as ↔ n ∈ bs) → as = bs
  | [], [], _, _, _ => rfl
  | [], b :: _, _, _, h => by simpa using (h b).mpr (by simp)
  | a :: _, [], _, _, h => by simpa using (h a).mp (by simp)
  | a :: as, b :: bs, ha, hb, h => by
    simp only [Sorted, List.pairwise_cons] at ha hb
    have hab : a = b := by
      rcases List.mem_cons.mp ((h a).mp (by simp)) with hx | hx
      · exact hx
      rcases List.mem_cons.mp ((h b).mpr (by simp)) with hy | hy
      · exact hy.symm
      exact absurd (hb.1 a hx) (Name.lt_asymm (ha.1 b hy))
    subst hab
    have htail : ∀ n, n ∈ as ↔ n ∈ bs := by
      intro n
      constructor
      · intro hn
        rcases List.mem_cons.mp ((h n).mp (by simp [hn])) with rfl | hn'
        · exact absurd (ha.1 n hn) (Name.lt_irrefl n)
        · exact hn'
      · intro hn
        rcases List.mem_cons.mp ((h n).mpr (by simp [hn])) with rfl | hn'
        · exact absurd (hb.1 n hn) (Name.lt_irrefl n)
        · exact hn'
    rw [sorted_ext ha.2 hb.2 htail]

/-- Canonicalizing a sorted list is the identity. -/
theorem canon_eq_self {ps : List Name} (h : Sorted ps) : canon ps = ps :=
  sorted_ext (sorted_canon ps) h fun _ => mem_canon

/-- `canon` is idempotent. -/
theorem canon_canon (ps : List Name) : canon (canon ps) = canon ps :=
  canon_eq_self (sorted_canon ps)

theorem canon_pair (p q : Name) : canon [p, q] = merge [p] [q] := by
  simp

end PropWhen

/-- The private representation of the zero-ness datum (canonical since
task #194).  The census (DESIGN.md, "THE PACKED `pw` DATUM" §1) found
the parameter lists tiny: on init-full 605 492 data are `ifAllZero
[]`, 123 332 are one name, 16 are two names and **none** is longer.
So the small cases get dedicated, allocation-free constructors, and
only lists of length ≥ 3 keep a `List` cell chain.

**Every constructor carries its invariant**: `two p q` requires
`p < q`, and `many ps` requires `ps` strictly ascending (sorted and
duplicate-free — `PropWhen.Sorted`) *and* of length > 2, so that no
list a small constructor could hold is ever a `many`.  Together with
`never`/`always`/`one` (which have nothing to get wrong) this makes
the representation a bijection with {`never`} ∪ {finite sets of
names}: **equal sets are equal values**, by construction rather than
by a normalization pass anyone could forget.

This type is `private`: it cannot be named, matched on or constructed
outside this module. -/
private inductive PropWhenRepr where
  | never
  | always
  | one (p : Name)
  | two (p q : Name) (h : p < q)
  | many (ps : List Name) (h : PropWhen.Sorted ps ∧ 2 < ps.length)
  deriving Inhabited, Hashable

/-- The zero-ness datum of a binder's codomain sort — the regime
discriminator of the validated-annotation design (task #161).  For
every level `l`, the set `Z(l) := {φ | eval φ l = 0}` of zeroing
valuations is either empty (`never`) or of the form "every parameter
in `ps` is zero" (`ifAllZero ps`; `ps = []` = always zero) — see
`Level.zeronessOf` and the mechanized battery in
`ConLeche.Verify.PropWhen`.

`ps` is a parameter *set*, and the datum is its **canonical**
representative (task #194): the smart constructor `ifAllZero` sorts
and deduplicates, `inter`/`bindZ` (hence `Level.substPW`) produce
canonical output from canonical input, and no other producer exists.
So syntactic equality decides zero-ness agreement at every valuation
(`eq_iff_holds`): the checker's validation and defeq sites compare
with `==`, the derived `Hashable` hashes the set, and the
level-instantiation identity law (`Level.substPW_self`) holds
unconditionally.

**The representation is hidden, not hidden by convention.**  The datum
is a one-field structure whose constructor *and* field are `private`,
wrapping the equally private `PropWhenRepr`.  Outside this module the
type is opaque: it cannot be pattern-matched, taken apart or built
except through the API below (`never`, `ifAllZero`, `toList`,
`toList?`, `casesZ`, the observers and their laws).  Nothing in this
module is `@[expose]`d either, so no `rfl`/`decide` downstream can
reach around the API and reduce through a body — every fact about the
datum is one of the exported theorems. -/
structure PropWhen where
  private ofRepr ::
  private repr : PropWhenRepr

namespace PropWhen

private theorem ofRepr_repr (a : PropWhen) : ofRepr a.repr = a := rfl

private theorem repr_inj {a b : PropWhen} (h : a.repr = b.repr) : a = b := by
  rw [← ofRepr_repr a, ← ofRepr_repr b, h]

/-! ### The comparison, and the instances

`DecidableEq` is structural equality spelled constructor-wise
(`equivR`) so that the name comparisons go through `Name.beq` (the
pointer-and-hash-guarded equality, `ConLeche/Kernel/Name.lean`) rather
than the derived structural walk; `equivR_iff_eq` says it *is*
equality.  `==` is the `DecidableEq`, so `=`, `==`, `decide` and every
checker comparison site run the same code.

`instance` bodies are always exposed, so they may not mention the
private representation; each therefore goes through a public (sealed)
helper that may. -/

/-- The comparison on the representation. -/
private def equivR : PropWhenRepr → PropWhenRepr → Bool
  | .never, .never => true
  | .always, .always => true
  | .one x, .one y => x == y
  | .two x y _, .two x' y' _ => x == x' && y == y'
  | .many ps _, .many qs _ => ps == qs
  | _, _ => false

private theorem equivR_iff_eq (x y : PropWhenRepr) : equivR x y = true ↔ x = y := by
  cases x <;> cases y <;> simp [equivR]

/-- Structural equality, decided constructor-wise on the hidden
representation. -/
def decEq (a b : PropWhen) : Decidable (a = b) :=
  decidable_of_iff (equivR a.repr b.repr = true)
    ((equivR_iff_eq _ _).trans ⟨repr_inj, fun h => h ▸ rfl⟩)

instance : DecidableEq PropWhen := decEq

/-- The hash of a datum — a hash of the parameter *set*, by
canonicity. -/
def hash' (pw : PropWhen) : UInt64 := hash pw.repr

instance : Hashable PropWhen := ⟨hash'⟩

/-! ### The encapsulation boundary

`never`, `ifAllZero`, `toList`, `toList?` and `casesZ` are the whole
interface to the shape; every observer below is stated over them, and
every fact anyone downstream needs is one of the exported equations.
-/

/-- "The codomain sort is nonzero at every valuation."  A *definition*
now, not a constructor — but `.never` reads the same at every use
site. -/
def never : PropWhen := ofRepr .never

instance : Inhabited PropWhen := ⟨never⟩

private theorem sorted_pair {p q : Name} (h : Sorted [p, q]) : p < q :=
  (List.pairwise_cons.mp h).1 q (List.mem_singleton.mpr rfl)

/-- Build the datum of a *sorted* list: the dedicated small
constructors for length ≤ 2, the `many` chain above, its invariant
discharged from the sortedness proof. -/
private def ofSorted : (ps : List Name) → Sorted ps → PropWhen
  | [], _ => ofRepr .always
  | [p], _ => ofRepr (.one p)
  | [p, q], h => ofRepr (.two p q (sorted_pair h))
  | p :: q :: r :: rest, h => ofRepr (.many (p :: q :: r :: rest) ⟨h, by simp⟩)

/-- The two-name datum from two arbitrary names: one comparison,
no list cell. -/
private def two' (p q : Name) : PropWhen :=
  match h : Name.cmp p q with
  | .lt => ofRepr (.two p q h)
  | .eq => ofRepr (.one p)
  | .gt => ofRepr (.two q p (Name.lt_of_gt h))

/-- **Smart constructor**: "every parameter in `ps` is zero".
Normalizing: the result is the canonical representative of the *set*
of `ps` (`toList_ifAllZero : (ifAllZero ps).toList = canon ps`, and
`ifAllZero_eq_iff`).  The empty and singleton cases touch no list
cell and no comparison; the pair case is one comparison; only lists
of length ≥ 3 run the sort. -/
@[inline] def ifAllZero : List Name → PropWhen
  | [] => ofRepr .always
  | [p] => ofRepr (.one p)
  | [p, q] => two' p q
  | ps => ofSorted (canon ps) (sorted_canon ps)

/-- The parameter list of a datum — sorted and duplicate-free
(`sorted_toList`); `never` reads as `[]` (use `toList?` where the
distinction matters). -/
def toList (pw : PropWhen) : List Name :=
  match pw.repr with
  | .never => []
  | .always => []
  | .one p => [p]
  | .two p q _ => [p, q]
  | .many ps _ => ps

/-- The parameter list of a non-`never` datum; `none` at `never`.  The
view that inverts `ifAllZero`. -/
def toList? (pw : PropWhen) : Option (List Name) :=
  match pw.repr with
  | .never => none
  | _ => some pw.toList

/-- The invariant, read off any datum. -/
theorem sorted_toList (pw : PropWhen) : Sorted pw.toList := by
  obtain ⟨x⟩ := pw
  cases x with
  | two p q h => simp [toList, Sorted, h]
  | many ps h => exact h.1
  | _ => simp [toList, Sorted]

@[simp] theorem toList_never : toList .never = [] := by
  simp [toList, never]

private theorem toList_ofSorted (ps : List Name) (h : Sorted ps) :
    (ofSorted ps h).toList = ps := by
  match ps, h with
  | [], _ | [_], _ | [_, _], _ | _ :: _ :: _ :: _, _ => simp [ofSorted, toList]

private theorem toList_two' (p q : Name) : (two' p q).toList = merge [p] [q] := by
  unfold two'
  split <;> simp [toList, merge, *]

/-- The smart constructor's list is the canonical form of its input. -/
@[simp] theorem toList_ifAllZero (ps : List Name) :
    (ifAllZero ps).toList = canon ps := by
  match ps with
  | [] => simp [ifAllZero, toList]
  | [p] => simp [ifAllZero, toList]
  | [p, q] => rw [ifAllZero, toList_two', canon_pair]
  | p :: q :: r :: rest =>
    show (ofSorted (canon (p :: q :: r :: rest)) _).toList = _
    exact toList_ofSorted _ _

/-- Membership in the smart constructor's list is membership in its
input. -/
theorem mem_toList_ifAllZero {n : Name} {ps : List Name} :
    n ∈ (ifAllZero ps).toList ↔ n ∈ ps := by
  rw [toList_ifAllZero, mem_canon]

private theorem two'_ne_never (p q : Name) : two' p q ≠ never := by
  unfold two'
  split <;> simp [never]

private theorem ofSorted_ne_never (ps : List Name) (h : Sorted ps) :
    ofSorted ps h ≠ never := by
  match ps, h with
  | [], _ | [_], _ | [_, _], _ | _ :: _ :: _ :: _, _ => simp [ofSorted, never]

/-- The smart constructor never produces `never`. -/
@[simp] theorem ifAllZero_ne_never (ps : List Name) : ifAllZero ps ≠ .never := by
  match ps with
  | [] | [_] => simp [ifAllZero, never]
  | [p, q] => exact two'_ne_never p q
  | _ :: _ :: _ :: _ => exact ofSorted_ne_never _ _

@[simp] theorem toList?_never : toList? .never = none := by
  simp [toList?, never]

private theorem toList?_eq {pw : PropWhen} (h : pw ≠ never) :
    pw.toList? = some pw.toList := by
  obtain ⟨x⟩ := pw
  cases x with
  | never => exact absurd rfl h
  | _ => simp [toList?]

@[simp] theorem toList?_ifAllZero (ps : List Name) :
    (ifAllZero ps).toList? = some (canon ps) := by
  rw [toList?_eq (ifAllZero_ne_never ps), toList_ifAllZero]

/-- **Extensionality on the list**: two non-`never` data with the same
parameter list are the same datum — the representation has one value
per list. -/
theorem eq_of_toList {a b : PropWhen} (ha : a ≠ never) (hb : b ≠ never)
    (h : a.toList = b.toList) : a = b := by
  obtain ⟨x⟩ := a
  obtain ⟨y⟩ := b
  cases x <;> cases y <;> simp_all [toList, never] <;> (subst h; simp_all)

/-- **Extensionality on the set**: two non-`never` data with the same
parameters are the same datum — the canonicity theorem at the datum
level. -/
theorem eq_of_mem_iff {a b : PropWhen} (ha : a ≠ never) (hb : b ≠ never)
    (h : ∀ n, n ∈ a.toList ↔ n ∈ b.toList) : a = b :=
  eq_of_toList ha hb (sorted_ext (sorted_toList a) (sorted_toList b) h)

/-- Reassembling a datum from its list — the `casesZ` companion. -/
theorem ifAllZero_toList {pw : PropWhen} (h : pw ≠ .never) :
    ifAllZero pw.toList = pw :=
  eq_of_toList (ifAllZero_ne_never _) h
    (by rw [toList_ifAllZero, canon_eq_self (sorted_toList pw)])

/-- **Unique representatives**: two smart-constructor applications are
equal exactly when their inputs have the same members. -/
theorem ifAllZero_eq_iff (ps qs : List Name) :
    ifAllZero ps = ifAllZero qs ↔ ∀ n, n ∈ ps ↔ n ∈ qs := by
  constructor
  · intro h n
    have h1 := mem_toList_ifAllZero (n := n) (ps := ps)
    rw [h, mem_toList_ifAllZero] at h1
    exact h1.symm
  · intro h
    exact eq_of_mem_iff (ifAllZero_ne_never ps) (ifAllZero_ne_never qs)
      fun n => by rw [mem_toList_ifAllZero, mem_toList_ifAllZero]; exact h n

/-- Canonicalizing the input changes nothing. -/
@[simp] theorem ifAllZero_canon (ps : List Name) :
    ifAllZero (canon ps) = ifAllZero ps :=
  (ifAllZero_eq_iff _ _).mpr fun _ => mem_canon

private theorem ifAllZero_two {p q : Name} (h : p < q) :
    ifAllZero [p, q] = ofRepr (.two p q h) :=
  ifAllZero_toList (pw := ofRepr (.two p q h)) (by simp [never])

private theorem ifAllZero_many {ps : List Name}
    (h : Sorted ps ∧ 2 < ps.length) :
    ifAllZero ps = ofRepr (.many ps h) :=
  ifAllZero_toList (pw := ofRepr (.many ps h)) (by simp [never])

/-- **The view**: every datum is `never` or `ifAllZero ps`.  Registered
as the `cases`/`induction` eliminator, so case analysis outside this
module is written — and reads — exactly as it did against the
two-constructor datum.  (The `ifAllZero` case is offered for *every*
list `ps`, canonical or not: the smart constructor normalizes, so
`ifAllZero ps` names every non-`never` datum, and a proof for all
`ps` is a proof for the canonical ones.) -/
@[elab_as_elim, cases_eliminator, induction_eliminator]
def casesZ {motive : PropWhen → Sort u} (never : motive .never)
    (ifAllZero : (ps : List Name) → motive (PropWhen.ifAllZero ps)) :
    (pw : PropWhen) → motive pw
  | .ofRepr .never => never
  | .ofRepr .always => ifAllZero []
  | .ofRepr (.one p) => ifAllZero [p]
  | .ofRepr (.two p q h) =>
    Eq.mpr (congrArg motive (ifAllZero_two h).symm) (ifAllZero [p, q])
  | .ofRepr (.many ps h) =>
    Eq.mpr (congrArg motive (ifAllZero_many h).symm) (ifAllZero ps)

/-- The old datum's `Repr`, kept **byte-identical** in shape.  It was
written for the `annotate-basis` generator, whose `repr` output was
pasted into `Basis/*.lean`, `StdAxioms.lean` and `TrustAxioms.lean` as
the annotated literals; that generator is gone (2026-09-06 — the
literals are computed by `#annotate_basis` at elaboration time now),
but the spelling stays: it is what a `#eval (repr …)` of a stored pin
prints, and it names the smart constructor rather than the private
representation.  This reproduces exactly what `deriving Repr` emitted
for the old `never | ifAllZero (ps : List Name)` datum (the list is
the canonical one now). -/
def reprPrec' (pw : PropWhen) (prec : Nat) : Std.Format :=
  Repr.addAppParen
    (Std.Format.group (Std.Format.nest (if prec ≥ 1024 then 1 else 2)
      (match pw.toList? with
        | none => Std.Format.text "ConLeche.PropWhen.never"
        | some ps =>
          Std.Format.text "ConLeche.PropWhen.ifAllZero" ++ Std.Format.line ++
            reprArg ps)))
    prec

instance : Repr PropWhen := ⟨reprPrec'⟩

/-! ### The observers

Each is defined representation-wise (so the small cases touch no list
cells), characterized once through `toList`, and re-stated in the
`never`/`ifAllZero` form — those equations, not the definitions, are
the whole downstream surface. -/

/-- Does the datum hold at a valuation — is the codomain sort zero
there?  (The model side's dispatch bit; the kernel never evaluates
this, it only compares data by `==`.) -/
def holds (φ : Name → Nat) (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => false
  | .always => true
  | .one p => φ p == 0
  | .two p q _ => (φ p == 0) && (φ q == 0)
  | .many ps _ => ps.all fun n => φ n == 0

@[simp] theorem holds_never (φ : Name → Nat) : holds φ .never = false := by
  simp [holds, never]

private theorem holds_eq_toList (φ : Name → Nat) {pw : PropWhen} (h : pw ≠ never) :
    holds φ pw = pw.toList.all fun n => φ n == 0 := by
  obtain ⟨x⟩ := pw
  cases x with
  | never => exact absurd rfl h
  | _ => simp [holds, toList]

@[simp] theorem holds_ifAllZero (φ : Name → Nat) (ps : List Name) :
    holds φ (ifAllZero ps) = ps.all fun n => φ n == 0 := by
  rw [holds_eq_toList φ (ifAllZero_ne_never ps), toList_ifAllZero, all_canon]

/-- Is the datum `never` — "the codomain sort is nonzero at *every*
valuation", the graph regime everywhere?  This is the **only**
kernel-decidable reading of the annotation that the verification tier
licenses a check-skip on (task #161 bucket 2): the P-tier claims split
their certificate cases on `pwBit φ m.pw = 0`, and `isNever` is
exactly the ∀-`φ` uniform version of the positive branch —
`pwBit φ .never = 1` at every `φ`, and no other datum has that
property (`.ifAllZero ps` holds at the all-zero valuation).  Sound
*and* exact: `isNever_iff_forall_pwBit_ne_zero` (`Model/Annot/Bit.lean`)
rests on `holds_never`/`holds_ifAllZero` here.

The datum may be read **only** to skip a re-check; it must never
select a reduct, a computed type, or a comparison result (law 1 as
amended at task #161: "annotations never change a reduct or a computed
type; annotation-gated check-skipping is permitted where the skip's
soundness is a P-tier theorem *and* the gate fires only where the
licensing theorems' hypotheses hold — `μ.verifiedChecks = true`").  Every
executable call site therefore carries the `μ.verifiedChecks` conjunct; see
`inferBodyIO` (`Kernel/CoreIO.lean`). -/
@[inline] def isNever (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => true
  | _ => false

theorem isNever_iff {pw : PropWhen} : isNever pw = true ↔ pw = never := by
  obtain ⟨x⟩ := pw
  cases x <;> simp [isNever, never]

@[simp] theorem isNever_never : isNever .never = true := isNever_iff.mpr rfl

@[simp] theorem isNever_ifAllZero (ps : List Name) :
    isNever (ifAllZero ps) = false := by
  rw [Bool.eq_false_iff]
  exact fun h => ifAllZero_ne_never ps (isNever_iff.mp h)

/-- Does the datum mention any level parameter — is `Level.substPW`
ever non-trivial on it?  Folded into `Expr.hasLevelParam` and the
`hasLP` field's recurrence, so the has-param shortcut of
the level-instantiation walk stays exact. -/
@[inline] def hasParams (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => false
  | .always => false
  | _ => true

private theorem hasParams_eq_toList (pw : PropWhen) :
    hasParams pw = !pw.toList.isEmpty := by
  obtain ⟨x⟩ := pw
  cases x with
  | many ps h =>
    have : ps ≠ [] := by
      intro he; rw [he] at h; simp at h
    simp [hasParams, toList, this]
  | _ => simp [hasParams, toList]

@[simp] theorem hasParams_never : hasParams .never = false := by
  simp [hasParams, never]

@[simp] theorem hasParams_ifAllZero (ps : List Name) :
    hasParams (ifAllZero ps) = !ps.isEmpty := by
  rw [hasParams_eq_toList, toList_ifAllZero, isEmpty_canon]

/-- Are all parameters of the datum among `params`?  Folded into
`Expr.allLevelParamsDefined` (task #161): level instantiation's
composition law (`Level.substPW_comp`) is *false* for data whose
parameters escape the declaration's — exactly as for the levels
themselves. -/
def paramsDefined (params : List Name) (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => true
  | .always => true
  | .one p => params.contains p
  | .two p q _ => params.contains p && params.contains q
  | .many ps _ => ps.all params.contains

private theorem paramsDefined_eq_toList (params : List Name) (pw : PropWhen) :
    paramsDefined params pw = pw.toList.all params.contains := by
  obtain ⟨x⟩ := pw
  cases x <;> simp [paramsDefined, toList]

@[simp] theorem paramsDefined_never (params : List Name) :
    paramsDefined params .never = true := by simp [paramsDefined, never]

@[simp] theorem paramsDefined_ifAllZero (params ps : List Name) :
    paramsDefined params (ifAllZero ps) = ps.all params.contains := by
  rw [paramsDefined_eq_toList, toList_ifAllZero, all_canon]

/-! ### Extensionality at the valuations

The canonicity payoff in its semantic form: data that agree at every
valuation are equal.  Everything about the producers (`inter`,
`bindZ`) is proved through it — a `holds` computation on each side,
and the representation never appears. -/

private theorem mem_of_all_eq {ps qs : List Name}
    (h : ∀ φ : Name → Nat, (ps.all fun n => φ n == 0) = (qs.all fun n => φ n == 0)) :
    ∀ n, n ∈ ps → n ∈ qs := by
  intro n hin
  by_cases hout : n ∈ qs
  · exact hout
  exfalso
  have hn := h fun m => if m = n then 1 else 0
  have hbs : (qs.all fun m => (if m = n then (1 : Nat) else 0) == 0)
      = true :=
    List.all_eq_true.mpr fun m hm => by
      have hne : m ≠ n := fun he => hout (he ▸ hm)
      simp [hne]
  have has : (ps.all fun m => (if m = n then (1 : Nat) else 0) == 0)
      = false :=
    List.all_eq_false.mpr ⟨n, hin, by simp⟩
  rw [has, hbs] at hn
  exact Bool.false_ne_true hn

/-- **Canonicity, semantically**: zero-ness agreement at every
valuation *is* equality of the data.  The separating valuations: the
all-zero valuation separates `never` from every `ifAllZero`, and
`φ n := 1, else 0` separates parameter sets that disagree on `n`. -/
theorem eq_iff_holds (p q : PropWhen) :
    p = q ↔ ∀ φ, p.holds φ = q.holds φ := by
  constructor
  · rintro rfl _; rfl
  · intro h
    by_cases hp : p = never
    · subst hp
      by_cases hq : q = never
      · exact hq.symm
      · have := h fun _ => 0
        rw [holds_never, holds_eq_toList _ hq] at this
        simp at this
    · by_cases hq : q = never
      · subst hq
        have := h fun _ => 0
        rw [holds_never, holds_eq_toList _ hp] at this
        simp at this
      · have h' : ∀ φ : Name → Nat, (p.toList.all fun n => φ n == 0)
            = (q.toList.all fun n => φ n == 0) := fun φ => by
          rw [← holds_eq_toList φ hp, ← holds_eq_toList φ hq]; exact h φ
        exact eq_of_mem_iff hp hq fun n =>
          ⟨mem_of_all_eq h' n, mem_of_all_eq (fun φ => (h' φ).symm) n⟩

theorem eq_of_holds {p q : PropWhen} (h : ∀ φ, p.holds φ = q.holds φ) : p = q :=
  (eq_iff_holds p q).mpr h

/-! ### The producers -/

/-- Intersection of two zero-ness predicates (the `max` rule: a `max`
is zero iff both sides are): `never` absorbs, sets unite — the
ordered merge, so the output is canonical.  The `always`/singleton
cases are answered without touching a list cell — they are 99.99 % of
the calls (the census). -/
def inter (a b : PropWhen) : PropWhen :=
  match a.repr, b.repr with
  | .never, _ => never
  | _, .never => never
  | .always, _ => b
  | _, .always => a
  | .one x, .one y => two' x y
  | _, _ => ofSorted (merge a.toList b.toList)
      (sorted_merge (sorted_toList a) (sorted_toList b))

@[simp] theorem inter_never_left (q : PropWhen) : inter .never q = .never := by
  simp [inter, never]

/-- `never` absorbs on the right too. -/
@[simp] theorem inter_never_right (p : PropWhen) : p.inter .never = .never := by
  obtain ⟨x⟩ := p
  cases x <;> simp [inter, never]

private theorem inter_ne_never {p q : PropWhen} (hp : p ≠ never) (hq : q ≠ never) :
    p.inter q ≠ never := by
  obtain ⟨x⟩ := p
  obtain ⟨y⟩ := q
  cases x <;> cases y <;> simp only [inter] <;>
    first
    | exact two'_ne_never _ _
    | exact ofSorted_ne_never _ _
    | simp_all [never]

private theorem toList_inter {p q : PropWhen} (hp : p ≠ never) (hq : q ≠ never) :
    (p.inter q).toList = merge p.toList q.toList := by
  obtain ⟨x⟩ := p
  obtain ⟨y⟩ := q
  cases x <;> cases y <;> simp only [inter] <;>
    first
    | exact toList_two' _ _
    | exact toList_ofSorted _ _
    | simp_all [never, toList]

theorem holds_inter (φ : Name → Nat) (p q : PropWhen) :
    (p.inter q).holds φ = (p.holds φ && q.holds φ) := by
  by_cases hp : p = never
  · subst hp; simp
  by_cases hq : q = never
  · subst hq; simp
  rw [holds_eq_toList φ (inter_ne_never hp hq), toList_inter hp hq, all_merge,
    holds_eq_toList φ hp, holds_eq_toList φ hq]

@[simp] theorem inter_ifAllZero (ps qs : List Name) :
    inter (ifAllZero ps) (ifAllZero qs) = ifAllZero (ps ++ qs) :=
  eq_of_holds fun φ => by
    rw [holds_inter, holds_ifAllZero, holds_ifAllZero, holds_ifAllZero,
      List.all_append]

/-- `ifAllZero []` is the right unit of `inter`. -/
@[simp] theorem inter_nil (p : PropWhen) : p.inter (ifAllZero []) = p := by
  cases p with
  | never => simp
  | ifAllZero ps => rw [inter_ifAllZero, List.append_nil]

/-- `ifAllZero []` is the left unit of `inter`. -/
@[simp] theorem nil_inter (q : PropWhen) : (ifAllZero []).inter q = q := by
  cases q with
  | never => simp
  | ifAllZero qs => rw [inter_ifAllZero, List.nil_append]

/-- The list-level `bindZ` fold. -/
def bindZ.go (f : Name → PropWhen) : List Name → PropWhen
  | [] => ifAllZero []
  | n :: rest => (f n).inter (go f rest)

/-- Substitute each parameter of the datum by a whole datum and
intersect ("all of `ps` zero" becomes "all replacements zero") — the
monadic bind of the zero-ness reading.  Canonical on output because
`inter` is; parameters mapped to `ifAllZero [n]` reproduce the datum
(`bindZ_unit`), which is what the unconditional identity law of level
instantiation rests on. -/
def bindZ (f : Name → PropWhen) (pw : PropWhen) : PropWhen :=
  match pw.repr with
  | .never => never
  | .always => ifAllZero []
  | .one p => f p
  | .two p q _ => (f p).inter (f q)
  | .many ps _ => bindZ.go f ps

@[simp] theorem bindZ_never (f : Name → PropWhen) :
    bindZ f .never = .never := by simp [bindZ, never]

@[simp] theorem bindZ_go_nil (f : Name → PropWhen) :
    bindZ.go f [] = ifAllZero [] := by simp [bindZ.go]

theorem holds_bindZ_go (φ : Name → Nat) (f : Name → PropWhen) :
    ∀ ps : List Name,
      (bindZ.go f ps).holds φ = ps.all fun n => (f n).holds φ
  | [] => by rw [bindZ_go_nil, holds_ifAllZero]; rfl
  | n :: rest => by
    simp [bindZ.go, holds_inter, holds_bindZ_go φ f rest]

private theorem bindZ_eq_go (f : Name → PropWhen) {pw : PropWhen} (h : pw ≠ never) :
    bindZ f pw = bindZ.go f pw.toList := by
  obtain ⟨x⟩ := pw
  cases x with
  | never => exact absurd rfl h
  | always => simp [bindZ, toList]
  | one p => simp [bindZ, toList, bindZ.go]
  | two p q _ => simp [bindZ, toList, bindZ.go]
  | many ps _ => simp [bindZ, toList]

private theorem bindZ_go_canon (f : Name → PropWhen) (ps : List Name) :
    bindZ.go f (canon ps) = bindZ.go f ps :=
  eq_of_holds fun φ => by
    rw [holds_bindZ_go, holds_bindZ_go]
    exact all_eq_of_mem_iff (fun _ => mem_canon) _

@[simp] theorem bindZ_ifAllZero (f : Name → PropWhen) (ps : List Name) :
    bindZ f (ifAllZero ps) = bindZ.go f ps := by
  rw [bindZ_eq_go f (ifAllZero_ne_never ps), toList_ifAllZero, bindZ_go_canon]

end PropWhen

/-! ## The law battery

Everything below is a fact about the datum alone; it needs no `Level`
and no `Expr`.  Moved here from `ConLeche/Verify/PropWhen.lean` on
2026-09-06 (the `Std.HashMap` pattern: the structure carries its
laws), statements unchanged — and unchanged again at task #194, when
the representation became canonical: the proofs below go through the
exported `never`/`ifAllZero` equations only, and those kept their
statements. -/

namespace PropWhen

/-! ### `paramsDefined` -/

theorem paramsDefined_inter_of {params : List Name} {p q : PropWhen}
    (hp : p.paramsDefined params = true)
    (hq : q.paramsDefined params = true) :
    (p.inter q).paramsDefined params = true := by
  cases p <;> cases q <;>
    simp_all [List.all_append]

/-- **Parameter locality**: a datum reads its valuation only at its
own parameters (the `paramsDefined` footprint) — `denoteMeta`'s
φ-congruence walk (`denoteMeta_params_ext`) rides this at every binder. -/
theorem holds_ext {ps : List Name} {pw : PropWhen}
    (hdef : pw.paramsDefined ps = true) {φ₁ φ₂ : Name → Nat}
    (hφ : ∀ p ∈ ps, φ₁ p = φ₂ p) : pw.holds φ₁ = pw.holds φ₂ := by
  cases pw with
  | never => rfl
  | ifAllZero qs =>
    simp only [paramsDefined_ifAllZero, List.all_eq_true] at hdef
    rw [holds_ifAllZero, holds_ifAllZero]
    induction qs with
    | nil => rfl
    | cons n rest ih =>
      simp only [List.all_cons]
      rw [hφ n (by simpa [List.contains_iff_mem] using hdef n (by simp)),
        ih fun m hm => hdef m (by simp [hm])]

/-! ### `inter` / `bindZ` algebra -/

/-- `inter` is associative (the datum is a set union). -/
theorem inter_assoc (a b c : PropWhen) :
    (a.inter b).inter c = a.inter (b.inter c) := by
  cases a <;> cases b <;> cases c <;> simp [List.append_assoc]

/-- `inter` is commutative (a set union; canonicity makes it an
equality). -/
theorem inter_comm (a b : PropWhen) : a.inter b = b.inter a :=
  eq_of_holds fun φ => by rw [holds_inter, holds_inter, Bool.and_comm]

/-- `inter` is idempotent. -/
theorem inter_self (a : PropWhen) : a.inter a = a :=
  eq_of_holds fun φ => by rw [holds_inter, Bool.and_self]

/-- The `bindZ` fold over an append splits — the list-level half of
`bindZ_inter`. -/
theorem bindZ_go_append (g : Name → PropWhen) : ∀ ps qs : List Name,
    bindZ.go g (ps ++ qs) = (bindZ.go g ps).inter (bindZ.go g qs)
  | [], qs => (nil_inter (bindZ.go g qs)).symm
  | n :: rest, qs => by
    show (g n).inter (bindZ.go g (rest ++ qs))
      = ((g n).inter (bindZ.go g rest)).inter (bindZ.go g qs)
    rw [bindZ_go_append g rest qs, inter_assoc]

theorem bindZ_inter (g : Name → PropWhen) (p q : PropWhen) :
    (p.inter q).bindZ g = (p.bindZ g).inter (q.bindZ g) := by
  cases p with
  | never => simp
  | ifAllZero ps =>
    cases q with
    | never => simp
    | ifAllZero qs => simp [bindZ_go_append]

theorem bindZ_congr_names {f g : Name → PropWhen} :
    ∀ {ps : List Name}, (∀ n ∈ ps, f n = g n) →
      bindZ.go f ps = bindZ.go g ps
  | [], _ => rfl
  | n :: rest, h => by
    show (f n).inter _ = (g n).inter _
    rw [h n (by simp), bindZ_congr_names fun m hm => h m (by simp [hm])]

/-- `bindZ` at the unit (`n ↦ ifAllZero [n]`) reproduces the datum —
an equality, by canonicity.  This is the datum half of the level
instantiation identity law (`Level.substPW_self`). -/
theorem bindZ_unit : ∀ pw : PropWhen,
    pw.bindZ (fun n => .ifAllZero [n]) = pw := by
  intro pw
  cases pw with
  | never => simp
  | ifAllZero ps => rw [bindZ_ifAllZero]; exact bindZ_unit.go ps
where
  go : ∀ ps : List Name,
      bindZ.go (fun n => PropWhen.ifAllZero [n]) ps = .ifAllZero ps
  | [] => rfl
  | n :: rest => by
    show (PropWhen.ifAllZero [n]).inter _ = _
    rw [go rest, inter_ifAllZero]
    rfl

end PropWhen

end ConLeche

end -- original EOF public section of ConLeche.Kernel.PropWhen
/- END exact source origin ConLeche.Kernel.PropWhen -/

/- BEGIN exact source origin ConLeche.Kernel.Exclusive -/
-- Bundled origin 02, header line 1: module

/- Compatibility variant for the source-only operational-refinement experiment.
The upstream documentation below describes its original native alternative.
This variant removes that alternative and its substitution attribute;
withExclusive retains exactly its original logical body, k false.
Universe binders are explicit and unused value/proof binders are renamed. -/

@[expose] public section

/-!
# `withExclusive`: the reference-count read behind the walk memo

**What it is.**  `withExclusive a k h` runs the continuation `k` on
whether the object `a` is *exclusive* — single-threaded with reference
count exactly 1, so that no other reference to it exists.  In the logic
it is `k false` ("not known to be exclusive", the conservative answer);
in compiled code `@[implemented_by]` substitutes `k
(isExclusiveUnsafe a)`, the real count read off the object header
(`Init/Util.lean`, `@[extern "lean_is_exclusive_obj"]`, a BORROWED
parameter; `lean_is_exclusive` in `lean.h`).  A multi-threaded object
(count `< 0`) and a persistent one (count `0` — the installed
environment after the driver's `Runtime.markPersistent`) answer
`false`, which is the safe side.

**What licenses the substitution** is the obligation

```
h : k true = k false
```

— the continuation's value does not depend on the answer, so the
compiled program computes the very value the definition names.  A
caller may use the answer to choose *how* to compute a value, never
*which* value.  `Init.Util`'s `withPtrAddr` is the same arrangement
(`k 0` in the model, the address in the binary, the continuation
address-blind by obligation), and `Bool` being two-valued makes
`k true = k false` the whole of `∀ b₁ b₂, k b₁ = k b₂`.

**What it is for.**  The per-walk memo tables of the substitution walks
(`ConLeche/Cached/ExprOpsC.lean`) exist for one reason: a node reached
twice — a shared sub-DAG — must be rebuilt once, so that the walk is
`O(DAG)` and its OUTPUT stays shared.  A node with exactly one
reference cannot be reached twice, so recording it is pure loss: the
key, the entry, the probe.  The official kernel's `replace_fn`
(`src/kernel/replace_fn.cpp`) therefore caches a node's replacement
only when `!is_likely_unshared(e)` — the same read.  The walks memoise
exactly the nodes this primitive reports shared.

**How the walks discharge `h`.**  Their result is a `Squash` — a
`Subsingleton`, exactly as `Expr.beqGoX`'s `BeqOutX` is — carrying the
rebuilt term with its proof of correctness beside an unobservable
memo, so `h` is `Subsingleton.elim` (`withExcl` below).

**The obligation cannot be weakened to the visible component.**  A
continuation returning the term beside a *bare* memo has
`k true ≠ k false` (the memo differs), and an obligation on the term
alone would leave the compiled memo — which later nodes probe —
outside the theorem.  The quotient is what makes the proof honest: the
memo's content is invisible to the type, its correctness is carried in
the memo's own type (`ConLeche/Cached/ExprOpsC.lean`: each entry
carries its proof), and the result's term is fixed by its subtype.

**The borrowed-parameter requirement.**  An owned parameter, a `let`
keeping the object alive across the call, a closure capturing it or a
`Prod` holding it is a second reference, and the read then answers
`false` for every node.  This module is `@[inline]` all the way to the
`@[extern]` call with the borrowed parameter, and the walks pass their
node BORROWED (`@&`) so that the count read is the count of references
*inside the term*.  The check is the IR audit of the tasks #314 and
#316 records (DESIGN.md): the generated C of every walk must show no
`lean_inc_ref` of the node before `lean_is_exclusive_obj`.

**Trust.**  This is the ONE `unsafe`-implemented primitive of the
substitution walks, and the only escape they add to the trust surface:
`tests/trust-surface.sh` allowlists this file for `unsafe` and
`implemented_by`, and that entry's justification is this docstring.
Nothing here is taken on faith beyond what `withPtrAddr` already asks —
the runtime's promise that `lean_is_exclusive_obj` returns a `Bool` and
has no other effect.  *Which* `Bool` is irrelevant to every theorem,
by `h`.

**Upstream.**  The primitive is proposed for `Init/Util.lean` in the
Lean RFC <https://github.com/leanprover/lean4/issues/15235>; the two
definitions below are written to be lifted there verbatim and have no
dependency on this tree.  When upstream ships it, this module becomes a
re-export.
-/

namespace ConLeche

universe u v

/-- Run `k` on whether `a` is an exclusive object — single-threaded
with reference count 1, so that no other reference to it exists — in
compiled code; in the logic, on `false`.

The obligation `h : k true = k false` says the continuation's value does
not depend on the answer, so the substitution is invisible: a caller
may use the answer only to choose *how* to compute a value, never
*which* value — typically to skip a memo probe for an object that
cannot be reached again.  The pattern of `withPtrAddr`. -/
def withExclusive {α : Type u} {β : Type v} (_a : α) (k : Bool → β)
    (_h : k true = k false) : β :=
  k false

/-- `withExclusive` into a subsingleton: the obligation is
`Subsingleton.elim` (the `Expr.withAddr` shape). -/
@[inline] def withExcl {α : Type u} {β : Type v} [Subsingleton β] (a : α)
    (k : Bool → β) : β :=
  withExclusive a k (Subsingleton.elim _ _)

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Exclusive
/- END exact source origin ConLeche.Kernel.Exclusive -/

/- BEGIN exact source origin ConLeche.Kernel.Expr -/
-- Bundled origin 03, header line 1: module

/-
Source-only compact reference: optional packed-field laws/memo equality or
lockstep canonical comparisons are omitted. Retained logical declarations
are unchanged. Historical comments describing removed implementations refer
to the full upstream source. Native compiler substitutions differ; no
native speedup or whole cached-checker compatibility is claimed.
-/

-- Bundled origin 03, header line 11: public import ConLeche.Kernel.PropWhen
-- Bundled origin 03, header line 12: public import ConLeche.Kernel.Exclusive
/- `withPtrEq` is `public` but not `@[expose]`, and its whole point here
is that it is *definitionally* `k ()` — which is what
`Level.beqPtr_eq` and `Expr.beqMemo_eq` prove.  `import all` makes that
body visible **in this module only**; those theorems are the public
relays, so no importer needs it, and the executed `Level.beq` and
`Expr.beq` stay the plain `decide (· = ·)` that the kernel can still
reduce. -/
-- Bundled origin 03, header line 20: import all Init.Util

/-!
# Kernel expressions

The checker's own term representation, mirroring Lean's kernel expressions.
We deliberately do not reuse `Lean.Expr`: our own inductive has no cached
metadata, which keeps the verification story clean.

Design decisions (see DESIGN.md):
* Free variables (`fvar`) follow nanoda's representation: a de Bruijn *level*
  together with the variable's type (and binder name, for error messages).
  The type is part of the variable's identity, so a local context is implicit
  in every open term.  Input terms coming from declarations are closed and
  use only `bvar` (de Bruijn *indices*).
* No metavariables, no `mdata`: those never reach a kernel.
-/

@[expose] public section

namespace ConLeche

-- Compatibility edit: explicitly declare the formerly implicit universes.
universe u v

/-- Universe levels, mirroring `Lean.Level` without metavariables —
including the cached hash, which `Lean.Level` also keeps in a
`@[computed_field]` (`data`, `Lean/Level.lean`) and the C++ kernel in
the level's packed data word (`level::hash()`).  As for `Name`, the
field is a function of the value and no statement sees it. -/
inductive Level where
  | zero
  | succ (u : Level)
  | max (u v : Level)
  | imax (u v : Level)
  | param (n : Name)
with
  /-- The cached hash of a level. -/
  @[computed_field] hashData : Level → UInt64
    | .zero => 1
    | .succ u => mixHash 3 u.hashData
    | .max u v => mixHash 5 (mixHash u.hashData v.hashData)
    | .imax u v => mixHash 7 (mixHash u.hashData v.hashData)
    | .param n => mixHash 11 (hash n)
deriving DecidableEq, Repr, Inhabited

/-- Hashing a level is an `O(1)` field read (the memo maps keyed by
`Level` — `lsimpC`, `lnzC`, `eqvC` — probe with this). -/
instance : Hashable Level := ⟨Level.hashData⟩

/-- Level equality in the official kernel's shape (task #176 P2):
the cached **hash** and the **pointer** before the structural walk —
`level.cpp:125` is `kind` → `hash` → `is_eqp` → structural.  The
implementation of `Level.beq`; `Level.beqPtr_eq` proves both guards
redundant. -/
@[inline] def Level.beqPtr (a b : Level) : Bool :=
  withPtrEq a b (fun _ => a.hashData == b.hashData && decide (a = b))
    (fun h => by subst h; simp)

/-- Both guards are redundant (see `Name.beqPtr_eq`). -/
theorem Level.beqPtr_eq (a b : Level) : Level.beqPtr a b = decide (a = b) := by
  show (a.hashData == b.hashData && decide (a = b)) = decide (a = b)
  by_cases h : a = b
  · subst h; simp
  · simp [h]

/-- The executed level equality: definitionally `decide (a = b)`, with
`beqPtr` substituted by the compiler on the `@[csimp]` equation below
(see `Name.beq_eq_beqPtr` for why this is not an escape). -/
def Level.beq (a b : Level) : Bool := decide (a = b)

/-- The `Level` twin of `Name.beq_eq_beqPtr`: `@[csimp]`, not
`@[implemented_by]`, on a kernel-checked equality. -/
@[csimp] theorem Level.beq_eq_beqPtr : @Level.beq = @Level.beqPtr := by
  funext a b; exact (Level.beqPtr_eq a b).symm

instance : BEq Level := ⟨Level.beq⟩

/-- `Level.beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Level where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Level.beq]

/-- Metadata carried by a binder (`forallE`, `lam`): the codomain
prop-ness annotation `pw` (task #161 — the validated-annotation design;
one datum per binder, written by the untrusted annotate pass or the
input stream and *validated* by the checker; the reduction rules never
read it).  Unannotated input defaults to `.never` at the parser — a
definite, validatable claim.  There is no display `BinderInfo`
(task #205): the official kernel's equality and hash ignore it — the
frontend validates a stream's spelling and drops it (`scanBinderInfo`). -/
structure BinderMeta where
  pw : PropWhen
  deriving DecidableEq, Repr, Hashable

instance : Inhabited BinderMeta := ⟨⟨.never⟩⟩

/-- Literals. -/
inductive Literal where
  | natVal (n : Nat)
  | strVal (s : String)
  deriving DecidableEq, Repr, Inhabited, Hashable

/-- Does the level mention a parameter (the official kernel's
`level.has_param`)?  There is no interned level table here, so this is
an `O(|u|)` walk — paid once per `.sort`/`.const` node construction,
never per memo touch. -/
def levelHasParam : Level → Bool
  | .zero => false
  | .param _ => true
  | .succ u => levelHasParam u
  | .max u v | .imax u v => levelHasParam u || levelHasParam v

/-- `levelHasParam` over a `const` node's level arguments. -/
def levelsHaveParam : List Level → Bool
  | [] => false
  | u :: us => levelHasParam u || levelsHaveParam us

/-- A level's hash: the cached `@[computed_field]`, so a `.sort`/`.const`
node's `hash` field is `O(1)` in the level's size *and* exact. -/
@[inline] def levelHash (u : Level) : UInt64 := u.hashData

/-- `levelHash` folded over a level list. -/
def levelsHash : List Level → UInt64
  | [] => 13
  | u :: us => mixHash (levelHash u) (levelsHash us)

/-! ## The packed node word (task #167)

`Lean.Expr` stores its derived data in one `UInt64` (`Lean.Expr.Data`:
a 32-bit hash, a 20-bit `looseBVarRange`, flags).  `ConLeche.Expr` does
the same, with one `@[computed_field] data : Expr → UInt64` whose
layout is

| bits | field | width |
|---|---|---|
| 63…32 | `hash` | 32 |
| 31 | *reserved* (always 0) | 1 |
| 30…16 | `bvarB`, the loose-bvar bound | 15 |
| 15…1 | `fvarB`, the fvar range | 15 |
| 0 | `hasLP` | 1 |

The two ranges **saturate** at `satRange = 2^15 - 1`: a node whose
bound would not fit stores `satRange`, which reads as "*at least*
`satRange`".  Saturation is a *representation* decision and costs
nothing logically — `Expr.bvarB`/`Expr.fvarB` remain the exact
functions `Expr.bvarBound`/`Expr.fvarRange` (`bvarB_eq`, `fvarB_eq`),
because the accessors fall back to a memoized exact walk on the
saturated branch.  What saturation costs is *performance*, and only
on terms that saturate: the `O(1)` field read becomes an `O(DAG)`
walk.  Measured maxima on the real streams — `init-full` 213,
`grind-ring-5` 488, `app-lam` (the deepest artificial workload) 4000 —
leave the branch unreached with 8× headroom.

The packing is written with **arithmetic**, not bitwise, operators
(`* 65536` for a shift, `/ 65536 % 32768` for a field read): the code
LLVM emits is the same shift-and-mask, and every roundtrip lemma
below is then `omega` after `UInt64.toNat`. -/

/-- Saturation value of the two 15-bit range fields: a stored
`satRange` reads as "at least `satRange`". -/
def satRange : Nat := 32767

/-- Assemble the packed word from a 32-bit hash, two 15-bit ranges and
the level-param flag.  Sums, not `|||`: the fields are disjoint, so
addition *is* the bitwise join, and the arithmetic form is what makes
the roundtrip lemmas `omega`-provable. -/
@[inline] def packData (h b f : UInt64) (lp : Bool) : UInt64 :=
  h * 4294967296 + b * 65536 + f * 2 + (if lp then 1 else 0)

/-- Hash field of a packed word (bits 63…32). -/
@[inline] def hashOfData (w : UInt64) : UInt64 := w / 4294967296

/-- Loose-bvar-bound field of a packed word (bits 30…16). -/
@[inline] def bvarOfData (w : UInt64) : UInt64 := w / 65536 % 32768

/-- Fvar-range field of a packed word (bits 15…1). -/
@[inline] def fvarOfData (w : UInt64) : UInt64 := w / 2 % 32768

/-- Has-level-param field of a packed word (bit 0). -/
@[inline] def lpOfData (w : UInt64) : Bool := w % 2 == 1

/-- Truncate a mixed hash to the packed word's 32 bits. -/
@[inline] def hash32 (w : UInt64) : UInt64 := w % 4294967296

/-- A leaf's range field: `n + 1`, saturating. -/
@[inline] def satSucc (n : Nat) : UInt64 := UInt64.ofNat (min (n + 1) satRange)

/-- A binder's range field: the body's bound less one, saturating
(a saturated body keeps a saturated bound — the stored value means
"at least", and subtracting from it would under-approximate). -/
@[inline] def satPred (x : UInt64) : UInt64 :=
  if x == 32767 then 32767 else if x == 0 then 0 else x - 1

/- Source-only optional cut: packed-field-laws. -/

/-- Kernel expressions.

`fvar idx type`: an opened variable, identified by its de Bruijn level
`idx` *and* its type.  Closed input terms contain no `fvar`s.

## No display data (task #205, user ruling)

The official kernel's `is_equal` and `hash` ignore binder names and
`BinderInfo`s (`expr_eq_fn.cpp:52, :100-103`).  Task #203 first made
every term the checker holds carry them at one normal form; the user's
ruling on that — *"if we don't keep the names we should drop the
fields!"* — is why `lam`/`forallE`/`letE` carry no binder name,
`fvar` no display name and `BinderMeta` no `BinderInfo`: there is
nothing α-irrelevant in a node, so structural `=`/`==` and the packed
`hash` ARE α-equivalence, with nothing to normalise and nothing a
fabricated term could get wrong.  The frontend still *validates* a
stream's `name` and `binderInfo` fields (a malformed record is
malformed) and drops them (`ConLeche/Frontend/ExportC.lean`); the pin
builder's `pi "a"`/`piI "α"` keep the `Init.Prelude` spelling as a
reader-facing argument (`ConLeche/Kernel/Basis/Builder.lean`).  Error
messages never printed a binder name; positions (de Bruijn level,
constant name) are what they carry.

## The computed field (task #172 B3a; packed at task #167)

Every node carries a block of derived data, **computed once at
construction time** by Lean's `@[computed_field]` feature — exactly
`Lean.Expr`'s own arrangement, down to the packing:

* `hash`  — the node's hash, so hashing a term for a memo lookup is a
  field read instead of a traversal;
* `bvarB` — the loose-bvar *bound*: the least `k` with
  `looseBVarsBounded k` (`Expr.bvarBound` is the same recurrence
  spelled as an ordinary function; `bvarB_eq` proves them equal).
  Instantiation at or above the bound is the identity;
* `fvarB` — the fvar *range*: max fvar index + 1 (`0` = fvar-free;
  `fvar` type annotations are not descended, matching the abstraction
  traversals — `Expr.fvarRange`).  Abstraction at or above the range
  is the identity;
* `hasLP` — has-level-param (`Expr.hasLevelParam`; the official
  kernel's `has_univ_param`).  Level instantiation on a node without
  it is the identity.

**One word holds all four** (`data`, the layout table above
`satRange`), which is where the node's memory goes: four separate
fields cost a `UInt64`, two boxed `Nat` pointers and a `Bool`; one
word costs eight bytes.  `bvarB` and `fvarB` *saturate* at
`satRange`; the accessors stay **exact** by falling back, on the
saturated branch alone, to a memoized walk (`bvarBoundMemo`,
`fvarRangeMemo` in `Kernel/ExprOps.lean`).  So no lemma anywhere
weakens and no invariant is threaded: saturation buys memory and
costs performance, and only on terms that saturate.

The *storage* is the compiler's: `Lean/Elab/ComputedFields.lean:33` —
*"This file implements the computed fields feature by simulating it
via `implemented_by`."*  That is a named trust escape; it is
enumerated, with the user ruling that adopted it, in the trust census
in `ConLeche/Cached/ExprNodes.lean`'s module docstring. -/
inductive Expr where
  | bvar (i : Nat)
  | fvar (idx : Nat) (type : Expr)
  | sort (u : Level)
  | const (n : Name) (us : List Level)
  | app (f a : Expr)
  | lam (type body : Expr) (m : BinderMeta)
  | forallE (type body : Expr) (m : BinderMeta)
  | letE (type value body : Expr)
  | lit (l : Literal)
  | proj (structName : Name) (idx : Nat) (e : Expr)
with
  /-- The packed derived-data word: `hash` (32) ǀ reserved (1) ǀ
  `bvarB` (15, saturating) ǀ `fvarB` (15, saturating) ǀ `hasLP` (1). -/
  @[computed_field] data : Expr → UInt64
    | .bvar i =>
      packData (hash32 (mixHash 3 (Hashable.hash i))) (satSucc i) 0 false
    | .fvar idx ty =>
      packData (hash32 (mixHash 5 (mixHash (Hashable.hash idx)
          (hashOfData ty.data))))
        0 (satSucc idx) (lpOfData ty.data)
    | .sort u =>
      packData (hash32 (mixHash 7 (levelHash u))) 0 0 (levelHasParam u)
    | .const n us =>
      packData (hash32 (mixHash 11 (mixHash (Hashable.hash n)
          (levelsHash us)))) 0 0 (levelsHaveParam us)
    | .app f a =>
      packData (hash32 (mixHash 17
          (mixHash (hashOfData f.data) (hashOfData a.data))))
        (max (bvarOfData f.data) (bvarOfData a.data))
        (max (fvarOfData f.data) (fvarOfData a.data))
        (lpOfData f.data || lpOfData a.data)
    | .lam ty b m =>
      packData (hash32 (mixHash 19
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData b.data) (Hashable.hash m.pw)))))
        (max (bvarOfData ty.data) (satPred (bvarOfData b.data)))
        (max (fvarOfData ty.data) (fvarOfData b.data))
        (lpOfData ty.data || lpOfData b.data || m.pw.hasParams)
    | .forallE ty b m =>
      packData (hash32 (mixHash 23
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData b.data) (Hashable.hash m.pw)))))
        (max (bvarOfData ty.data) (satPred (bvarOfData b.data)))
        (max (fvarOfData ty.data) (fvarOfData b.data))
        (lpOfData ty.data || lpOfData b.data || m.pw.hasParams)
    | .letE ty v b =>
      packData (hash32 (mixHash 29
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData v.data) (hashOfData b.data)))))
        (max (max (bvarOfData ty.data) (bvarOfData v.data))
          (satPred (bvarOfData b.data)))
        (max (max (fvarOfData ty.data) (fvarOfData v.data))
          (fvarOfData b.data))
        (lpOfData ty.data || lpOfData v.data || lpOfData b.data)
    | .lit l => packData (hash32 (mixHash 31 (Hashable.hash l))) 0 0 false
    | .proj s i e =>
      packData (hash32 (mixHash 37 (mixHash (Hashable.hash s)
          (mixHash (Hashable.hash i) (hashOfData e.data)))))
        (bvarOfData e.data) (fvarOfData e.data) (lpOfData e.data)
deriving DecidableEq, Repr, Inhabited

/-! ## The packed word's accessors

`hash` and `hasLP` are exact bit reads.  `bvarBRaw`/`fvarBRaw` are the
*saturating* reads: below `satRange` they are the exact bound
(`bvarBRaw_exact` in `Kernel/ExprOps.lean`, `fvarBRaw_exact` in
`Verify/Cached/Erase.lean`); at
`satRange` they mean "at least that", and `Expr.bvarB`/`Expr.fvarB`
(`Kernel/ExprOps.lean`) recover exactness there with a memoized
walk. -/

namespace Expr

/-- The node's 32-bit hash (`O(1)`).  The recurrence reads exactly
what `is_equal` in the official kernel reads (`expr_eq_fn.cpp`) plus
the validated `pw` datum; there is no display data in a node (task
#205), so hashing and `DecidableEq` are α-equivalence outright. -/
@[inline] def hash (e : Expr) : UInt64 := hashOfData e.data

/-- Has-level-param: is level instantiation ever non-trivial here?
One bit, so this read is *exact*. -/
@[inline] def hasLP (e : Expr) : Bool := lpOfData e.data

/-- The stored loose-bvar bound, saturating at `satRange`. -/
@[inline] def bvarBRaw (e : Expr) : Nat := (bvarOfData e.data).toNat

/-- The stored fvar range, saturating at `satRange`. -/
@[inline] def fvarBRaw (e : Expr) : Nat := (fvarOfData e.data).toNat

end Expr

/-- Hashing is the computed field: `O(1)`, no traversal; no hash in
the tree is budgeted. -/
instance : Hashable Expr := ⟨Expr.hash⟩

namespace Expr

/- Source-only optional cut: constructor-field-laws-and-memo-equality. -/

/-- The executed structural equality.  Definitionally `decide (a = b)`,
hence definitionally the `BEq` any `DecidableEq` type has, with
`beqMemo` substituted by the compiler on the `@[csimp]` equation
below. -/
def beq (a b : Expr) : Bool := decide (a = b)

/- Source-only optional cut: memo-equality-compiler-substitution. -/

instance : BEq Expr := ⟨Expr.beq⟩

/-- `beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Expr where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Expr.beq]

/-! ## The shared `bvar` pool (task #177)

A `bvar` node is the smallest thing this checker builds and the one it
builds most: every substitution shifts loose indices, every abstraction
introduces one, the parser reads one per occurrence.  Each of those was
a fresh allocation — and, since the substitution walks stopped
recording their atoms in the per-walk memo, a fresh allocation that
nothing shared afterwards.

`bvarPool` is one **static** table of the first `bvarPoolSize` of them.
It is a closed top-level `def`, so the runtime builds it once at module
initialization and marks it persistent (`lean_mark_persistent` in the
generated C): handing out `bvarPool[i]` costs a bounds check and a
borrowed read, and its reference counting is free.  `mkBvar` is
representation-transparent (`mkBvar_eq`, `@[simp]`), so pattern
matching stays on `.bvar` and no statement anywhere changes.

**Where it is used.**  Every *runtime* `bvar` construction goes through
it, and the routing is one line: `ConLeche.Expr.mkBVar` is the
cached tier's only `bvar` builder, so the substitution and abstraction
walks and the frontend's parser are all covered at once.  The
remaining `.bvar` literals in the tree are either the pure *spec*
functions of `ConLeche/Kernel/ExprOps.lean` (which must keep the bare
constructor — they are what the pool is proved transparent against) or
closed constants such as the cores' `.bvar 0`, which the compiler
already lifts to a per-module `_init_…_closed__n` and marks persistent
itself.

The bound covers the corpus with room to spare: the deepest de Bruijn
index the battery produces is the 4 000-binder λ tower of
`good/perf/app-lam`. -/

/-- Size of the static `bvar` pool. -/
def bvarPoolSize : Nat := 4096

@[inherit_doc bvarPoolSize]
def bvarPool : Array Expr := (Array.range bvarPoolSize).map Expr.bvar

/-- The `bvar` smart constructor: the pooled node below `bvarPoolSize`,
a fresh one above it.  Same value either way (`mkBvar_eq`). -/
@[inline] def mkBvar (i : Nat) : Expr :=
  if h : i < bvarPool.size then bvarPool[i] else .bvar i

@[simp] theorem mkBvar_eq (i : Nat) : mkBvar i = .bvar i := by
  unfold mkBvar
  split
  · simp [bvarPool]
  · rfl

end Expr

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Expr
/- END exact source origin ConLeche.Kernel.Expr -/

/- BEGIN exact source origin ConLeche.Kernel.Level -/
-- Bundled origin 04, header line 1: module

/- Logical-reference source slice for an actual ConLeche reducer proof.
Selected optional memo/field/one-pass implementations and their csimp proofs
are omitted here; all retained logical definition and theorem bodies are
unchanged. The upstream comments that mention those native substitutions
describe the unsliced source. This variant does not retain those compiler
optimizations, and no native performance claim is made.
The exact omissions and full inverse are in UPSTREAM-COMPATIBILITY.json. -/

-- Bundled origin 04, header line 11: public import ConLeche.Kernel.Expr

@[expose] public section

/-!
# Level operations

Implementation of universe level comparison, following the official kernel /
nanoda (`level.rs` there): `simplify` normalizes, `leqCore` decides
`eval l ≤ eval r + diff` with the same case order as nanoda's `leq_core`
(so reduction happens the same way), and antisymmetry gives equivalence.

`leqCore`'s termination argument is nontrivial (the `imax` by-cases rule
substitutes into both sides), so it takes fuel.  Running out of fuel — or
hitting a case that is unreachable for simplified input — is reported as
`none`, which callers must never read as a verdict: a check that REQUIRES
a comparison lifts it with `liftFueled`, which DECLINES (our resource
limit).  A comparison against `zero` may read `none` as
"no": `simplify` sends every always-zero level to `zero`, where
`isEquiv` answers on its syntactic fast path.

Soundness of all of this (w.r.t. evaluation of levels into `Nat`) is proved
in `ConLeche.Verify.Level`.
-/

namespace ConLeche.Level

/-- Substitute level parameters: `subst ks vs l` replaces `param k` by the
corresponding `v`.  Unlisted parameters remain. -/
def subst (ks : List Name) (vs : List Level) : Level → Level
  | .zero => .zero
  | .succ l => .succ (subst ks vs l)
  | .max l r => .max (subst ks vs l) (subst ks vs r)
  | .imax l r => .imax (subst ks vs l) (subst ks vs r)
  | .param n => go ks vs n
where
  go : List Name → List Level → Name → Level
  | k :: ks, v :: vs, n => if k = n then v else go ks vs n
  | _, _, n => .param n

/-- Are all parameters of `l` among `params`? -/
def allParamsDefined (params : List Name) : Level → Bool
  | .zero => true
  | .succ l => allParamsDefined params l
  | .max l r | .imax l r => allParamsDefined params l && allParamsDefined params r
  | .param n => params.contains n

/-- Is this level provably nonzero at every parameter assignment
(official kernel `is_never_zero`)?  Syntactic and incomplete, exactly
as the reference: `succ` is, `max` if either side is, `imax` if the
right side is; `zero` and `param` are not. -/
def isNeverZero : Level → Bool
  | .zero => false
  | .param _ => false
  | .succ _ => true
  | .max l r => isNeverZero l || isNeverZero r
  | .imax _ r => isNeverZero r

/-- `max` of two simplified levels, pulling out common `succ`s. -/
def combining : Level → Level → Level
  | .zero, r => r
  | l, .zero => l
  | .succ l, .succ r => .succ (combining l r)
  | l, r => .max l r

/-- Normalize a level: resolve `max`/`imax` where possible. -/
def simplify : Level → Level
  | .zero => .zero
  | .param n => .param n
  | .succ l => .succ (simplify l)
  | .max l r => combining (simplify l) (simplify r)
  | .imax l r =>
    let ls := simplify l
    let rs := simplify r
    if ls = .zero || ls = .succ .zero then rs
    else match rs with
      | .zero => .zero
      | .succ _ => combining ls rs
      | _ => .imax ls rs

mutual

/-- Decide `eval l ≤ eval r + diff` for simplified `l`, `r`. -/
def leqCore (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match fuel with
  | 0 => none
  | fuel + 1 =>
    if l = .zero ∧ diff ≥ 0 then some true
    else if r = .zero ∧ diff < 0 then some false
    else rest fuel l r diff

/-- The cases after the cheap `zero` short-cuts, in nanoda's order. -/
def rest (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match l, r with
  | .param a, .param x => some (a = x && diff ≥ 0)
  | .param _, .zero => some false
  | .zero, .param _ => some (diff ≥ 0)
  | .succ s, _ => leqCore fuel s r (diff - 1)
  | _, .succ s => leqCore fuel l s (diff + 1)
  | .max a b, _ => do
    if ← leqCore fuel a r diff then leqCore fuel b r diff else pure false
  | .param _, .max x y => do
    if ← leqCore fuel l x diff then pure true else leqCore fuel l y diff
  | .zero, .max x y => do
    if ← leqCore fuel l x diff then pure true else leqCore fuel l y diff
  | _, _ =>
    match l, r with
    | .imax a b, .imax x y =>
      if a = x && b = y && diff ≥ 0 then some true else imaxRules fuel l r diff
    | _, _ => imaxRules fuel l r diff

/-- The `imax` rules (nanoda's cases 10–15): case-split on a parameter, or
distribute a nested `max`/`imax` on the right of an `imax`. -/
def imaxRules (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match l, r with
  | .imax _ (.param p), _ => byCases fuel p l r diff
  | _, .imax _ (.param p) => byCases fuel p l r diff
  | .imax a (.imax x y), _ => leqCore fuel (.max (.imax a y) (.imax x y)) r diff
  | .imax a (.max x y), _ => leqCore fuel (simplify (.max (.imax a x) (.imax a y))) r diff
  | _, .imax x (.imax j k) => leqCore fuel l (.max (.imax x k) (.imax j k)) diff
  | _, .imax x (.max j k) => leqCore fuel l (simplify (.max (.imax x j) (.imax x k))) diff
  | _, _ => none  -- unreachable for simplified input; an internal error

/-- Split on the parameter `p` being zero or positive. -/
def byCases (fuel : Nat) (p : Name) (l r : Level) (diff : Int) : Option Bool := do
  let l0 := simplify (subst [p] [.zero] l)
  let r0 := simplify (subst [p] [.zero] r)
  if ← leqCore fuel l0 r0 diff then
    let ls := simplify (subst [p] [.succ (.param p)] l)
    let rs := simplify (subst [p] [.succ (.param p)] r)
    leqCore fuel ls rs diff
  else pure false

end

/-- A generous fuel bound for `leqCore`; exceeded only by pathological input
(a `max` chain deeper than the bound: `tests/e2e/level_fuel_*`), which
the checker then DECLINES — never a verdict. -/
def defaultFuel : Nat := 10000

/-- Decide `l ≤ r` semantically; `none` is an exhausted comparison. -/
def leq (l r : Level) : Option Bool :=
  leqCore defaultFuel (simplify l) (simplify r) 0

/-- Decide semantic equality of two levels; `none` is an exhausted comparison.
Syntactic equality decides directly — first on the levels themselves
(`l == r`, which is pointer- and hash-first, task #176 P2), then on
their simplified forms (the reference kernels' fast path); otherwise
antisymmetric `leq`, short-circuited.

**Conformance note (restrictions-are-findings, task #176 P2).**  The
first disjunct is what official's `is_equivalent` does and con-leche did
not: `bool is_equivalent(level const & lhs, level const & rhs) {
return lhs == rhs || normalize(lhs) == normalize(rhs); }`
(`level.cpp:518`).  It is *provably redundant* here — `l = r` implies
`simplify l = simplify r` — so the alignment is verdict-neutral by
construction, not merely accept-superset: `isEquiv_eq_withoutPtr` and
`isEquiv_of_beq` (`Verify/Level.lean`) pin both directions.  What it
buys is speed: `simplify` allocates, `l == r` on a shared level is one
pointer compare. -/
def isEquiv (l r : Level) : Option Bool := do
  if l == r then pure true
  else if simplify l = simplify r then pure true
  else if ← leq l r then leq r l else pure false

/-- Decide pointwise semantic equality of two level lists (`false` on length
mismatch). -/
def isEquivList : List Level → List Level → Option Bool
  | [], [] => some true
  | l :: ls, r :: rs => do
    if ← isEquiv l r then isEquivList ls rs else pure false
  | _, _ => some false

/-- Certainly nonzero under *every* level assignment (`succ`-headed
somewhere along every `max`, and along the `imax` right spine).
Conservative: `false` does not mean "can be zero". -/
def isNonZero : Level → Bool
  | .zero => false
  | .succ _ => true
  | .max a b => a.isNonZero || b.isNonZero
  | .imax _ b => b.isNonZero
  | .param _ => false

/-- The zero-ness datum of a level (task #161): the exact reading of
`{φ | eval φ l = 0}`.  `ConLeche.Verify.PropWhen` proves
`(zeronessOf l).holds φ = (eval φ l == 0)`.  Case notes: a `max` is
zero iff both sides are (`inter`); an `imax` is zero iff its right
side is (`eval (imax a b) = if eval b = 0 then 0 else max …`). -/
def zeronessOf : Level → PropWhen
  | .zero => .ifAllZero []
  | .succ _ => .never
  | .param n => .ifAllZero [n]
  | .max a b => (zeronessOf a).inter (zeronessOf b)
  | .imax _ b => zeronessOf b

/-- Push a level-parameter substitution through a zero-ness datum
(task #161): each parameter becomes its replacement's datum,
intersected — `Z(subst ks vs l)` is exactly
`substPW ks vs (zeronessOf l)` (`Verify.PropWhen.zeronessOf_subst`).
Canonical on output (`PropWhen.bindZ`, task #194): an unlisted
parameter reproduces `ifAllZero [n]`, so instantiating a declaration
at its own parameters is the identity here too (`substPW_self`) —
unconditionally, because every datum is canonical by construction. -/
def substPW (ks : List Name) (vs : List Level) (pw : PropWhen) :
    PropWhen :=
  pw.bindZ fun n => zeronessOf (subst.go ks vs n)

end ConLeche.Level

namespace ConLeche

/-- No duplicates in a list of names. -/
def Name.nodup : List Name → Bool
  | [] => true
  | n :: ns => !ns.contains n && Name.nodup ns

/-- Is this shaped like an installed projection function's name
(`(T.proj).i`) or a
projection table's (`(T.projTable).0`, task #175 S1)?  Both shapes
are reserved for the checker's own installs. -/
def Name.isProjFnShape : Name → Bool
  | .num (.str _ "proj") _ => true
  | .num (.str _ "projTable") _ => true
  | _ => false

/-- Substitute level parameters throughout an expression (sorts and
constant level arguments). -/
def Expr.instantiateLevelParams (ks : List Name) (us : List Level) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar idx ty => .fvar idx (ty.instantiateLevelParams ks us)
  | .sort u => .sort (Level.subst ks us u)
  | .const n vs => .const n (vs.map (Level.subst ks us))
  | .app f a => .app (f.instantiateLevelParams ks us) (a.instantiateLevelParams ks us)
  | .lam ty body m =>
    .lam (ty.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
      ⟨Level.substPW ks us m.pw⟩
  | .forallE ty body m =>
    .forallE (ty.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
      ⟨Level.substPW ks us m.pw⟩
  | .letE ty val body => .letE (ty.instantiateLevelParams ks us)
      (val.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
  | .lit l => .lit l
  | .proj s i e => .proj s i (e.instantiateLevelParams ks us)

/-- Are all level parameters occurring in `e` among `params`?  Binder
prop-ness data included (task #161): their parameters are level
parameters of the term — `instantiateLevelParams` substitutes into
them, and its composition law needs them covered exactly as it needs
the levels'. -/
def Expr.allLevelParamsDefined (params : List Name) : Expr → Bool
  | .bvar _ => true
  | .fvar _ t => t.allLevelParamsDefined params
  | .sort u => u.allParamsDefined params
  | .const _ us => us.all (Level.allParamsDefined params)
  | .app f a => f.allLevelParamsDefined params && a.allLevelParamsDefined params
  | .lam t b m | .forallE t b m =>
    t.allLevelParamsDefined params && b.allLevelParamsDefined params
      && m.pw.paramsDefined params
  | .letE t v b => t.allLevelParamsDefined params && v.allLevelParamsDefined params
      && b.allLevelParamsDefined params
  | .lit _ => true
  | .proj _ _ e => e.allLevelParamsDefined params

/- Logical-reference slice: level-parameters-memo omitted; exact inverse retained. -/

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Level
/- END exact source origin ConLeche.Kernel.Level -/

/- BEGIN exact source origin ConLeche.Kernel.ExprOps -/
-- Bundled origin 05, header line 1: module

/- Logical-reference source slice for an actual ConLeche reducer proof.
Selected optional memo/field/one-pass implementations and their csimp proofs
are omitted here; all retained logical definition and theorem bodies are
unchanged. The upstream comments that mention those native substitutions
describe the unsliced source. This variant does not retain those compiler
optimizations, and no native performance claim is made.
The exact omissions and full inverse are in UPSTREAM-COMPATIBILITY.json. -/

-- Bundled origin 05, header line 11: public import ConLeche.Kernel.Level
/- `ConLeche.Kernel.PropWhen` seals its representation on purpose (the
`Std.HashMap` pattern): its constructors are `public` but the module is
not `@[expose]`d, so a `cases`-then-`rfl` proof about a datum cannot
see the reduct.  `import all` gives that view HERE only; nothing this
module exports depends on it. -/
-- Bundled origin 05, header line 17: import all ConLeche.Kernel.PropWhen

@[expose] public section

/-!
# Expression operations

`instantiate1` opens a binder body: the bound variable `bvar 0` is replaced
by a given expression (in practice an `fvar`, which is closed, so no
de Bruijn shifting of the replacement is needed).

`sizeB` is the termination measure for functions that recurse into
instantiated binder bodies: it counts expression nodes but gives every
`fvar` size 1 regardless of its annotated type.  Instantiating a `bvar`
(size 1) with an `fvar` (size 1) preserves it (`sizeB_instantiate1`), so
`sizeB body < sizeB (forallE n ty body)` keeps holding after opening.
-/

namespace ConLeche.Expr

/-- Replace `bvar d` by `v` in `e`, where `d` counts the binders passed on
the way (callers start at the default `d = 0`).  `v` must be closed with
respect to bound variables (an `fvar`, a constant, …); it is not shifted.
Loose `bvar`s above `d` are lowered by one. -/
def instantiate1 (e : Expr) (v : Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar i => if i = d then v else if i > d then .bvar (i - 1) else .bvar i
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiate1 f v d) (instantiate1 a v d)
  | .lam ty body bi => .lam (instantiate1 ty v d) (instantiate1 body v (d + 1)) bi
  | .forallE ty body bi => .forallE (instantiate1 ty v d) (instantiate1 body v (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiate1 ty v d) (instantiate1 val v d) (instantiate1 body v (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiate1 e v d)

/- Logical-reference slice: instantiate1-memo omitted; exact inverse retained. -/

/-- Bulk instantiation (task #50): substitute the replacement list `vs`
for the bound variables `bvar d, bvar (d + 1), …` in one traversal —
`vs[0]` replaces `bvar d` (the *innermost* binder of a peeled
telescope), `vs[i]` replaces `bvar (d + i)`; loose `bvar`s above the
range are lowered by `vs.length`.

The semantics is by construction the *fold* of `instantiate1`:

  `instantiateList e (v :: vs) d
     = (instantiateList e vs (d + 1)).instantiate1 v d`

(`instantiateList_cons`, unconditional) — so a chain that consumes a
spine `a₁ … aₖ` outermost-first equals one call at the accumulator list
`[aₖ, …, a₁]`.  In the fold, a replacement inserted early is traversed
again by the later `instantiate1` passes; the `bvar` case reproduces
this by recursing into the replacement with the *earlier-listed*
entries (`vs.take i` — the substitutions the fold applies after
inserting `vs[i]`).  On `bvar`-closed replacements (every checker call
site) that recursion is the identity, and the cost is a single
traversal of `e` instead of `vs.length` traversals. -/
def instantiateList (e : Expr) (vs : List Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar j =>
    if j < d then .bvar j
    else if h : j - d < vs.length then
      instantiateList vs[j - d] (vs.take (j - d)) d
    else .bvar (j - vs.length)
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiateList f vs d) (instantiateList a vs d)
  | .lam ty body bi =>
    .lam (instantiateList ty vs d) (instantiateList body vs (d + 1)) bi
  | .forallE ty body bi =>
    .forallE (instantiateList ty vs d) (instantiateList body vs (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiateList ty vs d) (instantiateList val vs d)
      (instantiateList body vs (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiateList e vs d)
termination_by (vs.length, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp [List.length_take]; omega)
    | (apply Prod.Lex.right; simp; omega)

/- Logical-reference slice: instantiateList-memo omitted; exact inverse retained. -/

/-! ### `instantiateList` as the `instantiate1` fold (task #50)

The two laws the one-pass telescope opening (`openPisAtFvarsF`,
`ConLeche/Kernel/CheckerBase.lean`) needs for its `@[csimp]`; the rest
of the family is in `ConLeche/Verify/InstList.lean`. -/

set_option linter.unusedSimpArgs false in
theorem instantiateList_nil : ∀ (e : Expr) (d : Nat),
    e.instantiateList [] d = e := by
  intro e
  induction e <;> intro d <;> simp [instantiateList, *] <;> omega

set_option linter.unusedSimpArgs false in
theorem instantiateList_cons :
    ∀ (vs : List Expr) (e : Expr) (v : Expr) (d : Nat),
      e.instantiateList (v :: vs) d
        = (e.instantiateList vs (d + 1)).instantiate1 v d
  | vs, .bvar j, v, d => by
    by_cases hjd : j < d
    · have hjd1 : j < d + 1 := by omega
      simp [instantiateList, instantiate1, hjd, hjd1,
        show ¬ j = d by omega, show ¬ j > d by omega]
    · by_cases hje : j = d
      · subst hje
        simp [instantiateList, hjd, instantiate1, instantiateList_nil]
      · -- j > d: either a replacement from the tail, or above the range
        obtain ⟨i, rfl⟩ : ∃ i, j = d + 1 + i := ⟨j - d - 1, by omega⟩
        have hd1 : ¬ d + 1 + i < d + 1 := by omega
        have hsub : d + 1 + i - d = i + 1 := by omega
        have hsub2 : d + 1 + i - (d + 1) = i := by omega
        by_cases hin : i < vs.length
        · -- in range: the replacement, recursively substituted
          have hin' : d + 1 + i - d < (v :: vs).length := by simp; omega
          have hin2 : d + 1 + i - (d + 1) < vs.length := by omega
          have hr : (Expr.bvar (d + 1 + i)).instantiateList vs (d + 1)
              = vs[i].instantiateList (vs.take i) (d + 1) := by
            rw [instantiateList, ite_eq_right hd1, dite_eq_left hin2]
            simp only [hsub2]
          rw [instantiateList, ite_eq_right hjd, dite_eq_left hin', hr]
          simp only [hsub, List.getElem_cons_succ, List.take_succ_cons]
          exact instantiateList_cons (vs.take i) vs[i] v d
        · -- above the range: lowered
          have hnin : ¬ d + 1 + i - d < (v :: vs).length := by simp; omega
          have hnin2 : ¬ d + 1 + i - (d + 1) < vs.length := by omega
          have hr : (Expr.bvar (d + 1 + i)).instantiateList vs (d + 1)
              = .bvar (d + 1 + i - vs.length) := by
            rw [instantiateList, ite_eq_right hd1, dite_eq_right hnin2]
          rw [instantiateList, ite_eq_right hjd, dite_eq_right hnin, hr]
          have hgt2 : d + 1 + i - vs.length > d := by omega
          simp [instantiate1, show ¬ d + 1 + i - vs.length = d by omega,
            hgt2]
          omega
  | vs, .fvar idx ty, v, d => by simp [instantiateList, instantiate1]
  | vs, .sort u, v, d => by simp [instantiateList, instantiate1]
  | vs, .const n us, v, d => by simp [instantiateList, instantiate1]
  | vs, .app f a, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs f v d, instantiateList_cons vs a v d]
  | vs, .lam ty body bi, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs body v (d + 1)]
  | vs, .forallE ty body bi, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs body v (d + 1)]
  | vs, .letE ty val body, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs val v d,
      instantiateList_cons vs body v (d + 1)]
  | vs, .lit l, v, d => by simp [instantiateList, instantiate1]
  | vs, .proj s i e, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs e v d]
termination_by vs e => (vs.length, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp [List.length_take]; omega)
    | (apply Prod.Lex.right; simp; omega)

/-- Bump every loose bound variable `≥ cutoff` by `amount`.  Used to
transport a constructor-telescope field domain (parameters, then prior
fields) into a recursor-rule telescope (parameters, motive, minors,
then prior fields): parameter references must skip the extra motive
and minor binders, and by the zeta expansion's substitution to carry
open let-values under binders. -/
def liftLooseBVars (amount : Nat) : (cutoff : Nat) → Expr → Expr
  | c, .bvar i => if i ≥ c then .bvar (i + amount) else .bvar i
  | _, .fvar i ty => .fvar i ty
  | _, .sort u => .sort u
  | _, .const n us => .const n us
  | c, .app a b => .app (liftLooseBVars amount c a) (liftLooseBVars amount c b)
  | c, .lam ty body m =>
    .lam (liftLooseBVars amount c ty) (liftLooseBVars amount (c + 1) body) m
  | c, .forallE ty body m =>
    .forallE (liftLooseBVars amount c ty) (liftLooseBVars amount (c + 1) body) m
  | c, .letE ty v body =>
    .letE (liftLooseBVars amount c ty) (liftLooseBVars amount c v)
      (liftLooseBVars amount (c + 1) body)
  | _, .lit l => .lit l
  | c, .proj s i e => .proj s i (liftLooseBVars amount c e)

/- Logical-reference slice: liftLooseBVars-memo omitted; exact inverse retained. -/

/-! ### `resetMeta` (task #210 Part D)

Every binder's datum reset to the parse placeholder `⟨.never⟩`: the
stream's recursor rules are compared syntactically against the
generated ones (official's replay compares an exported recursor
structurally with the one it generates), and the generated body is
built from ANNOTATED pieces — the stored constructor's normalised field
telescopes and index expressions — while the stream's carries the
placeholder everywhere.  The pure walk is the spec; the executed one is
memoized by `@[csimp]` (the `mentionsConst` arrangement). -/

def resetMeta : Expr → Expr
  | .app f a => .app (resetMeta f) (resetMeta a)
  | .lam ty b _ => .lam (resetMeta ty) (resetMeta b) ⟨.never⟩
  | .forallE ty b _ => .forallE (resetMeta ty) (resetMeta b) ⟨.never⟩
  | .letE ty v b => .letE (resetMeta ty) (resetMeta v) (resetMeta b)
  | .proj s i e => .proj s i (resetMeta e)
  | .fvar i ty => .fvar i (resetMeta ty)
  | e => e

/- Logical-reference slice: resetMeta-memo omitted; exact inverse retained. -/

/-- Lower every loose bound variable `≥ cutoff + amount` by `amount`
(loose variables inside the window `[cutoff, cutoff + amount)` are left
untouched — callers certify their absence by the `liftLooseBVars`
roundtrip).  Used by the nested-rule shape certification to read a
recursor's constructor-parameter instantiations out of the
major-premise domain (an `mI`-binder context) into the rule-prefix
context (`rP` binders): `p = (p.lowerBVars (mI - rP) 0).liftLooseBVars
(mI - rP) 0` holds exactly when `p` mentions no index variable. -/
def lowerBVars (amount : Nat) : (cutoff : Nat) → Expr → Expr
  | c, .bvar i => if i ≥ c + amount then .bvar (i - amount) else .bvar i
  | _, .fvar i ty => .fvar i ty
  | _, .sort u => .sort u
  | _, .const n us => .const n us
  | c, .app a b => .app (lowerBVars amount c a) (lowerBVars amount c b)
  | c, .lam ty body m =>
    .lam (lowerBVars amount c ty) (lowerBVars amount (c + 1) body) m
  | c, .forallE ty body m =>
    .forallE (lowerBVars amount c ty) (lowerBVars amount (c + 1) body) m
  | c, .letE ty v body =>
    .letE (lowerBVars amount c ty) (lowerBVars amount c v)
      (lowerBVars amount (c + 1) body)
  | _, .lit l => .lit l
  | c, .proj s i e => .proj s i (lowerBVars amount c e)

/-- Replace `bvar d` by `v`, *lifting* `v`'s loose `bvar`s past the
binders crossed on the way — the general capture-avoiding substitution
for an open `v` (unlike `instantiate1`, which requires `v` to be
`bvar`-closed).  Let-values are open terms. -/
def instantiate1Lift (e : Expr) (v : Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar i =>
    if i = d then Expr.liftLooseBVars d 0 v
    else if i > d then .bvar (i - 1) else .bvar i
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiate1Lift f v d) (instantiate1Lift a v d)
  | .lam ty body bi =>
    .lam (instantiate1Lift ty v d) (instantiate1Lift body v (d + 1)) bi
  | .forallE ty body bi =>
    .forallE (instantiate1Lift ty v d) (instantiate1Lift body v (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiate1Lift ty v d) (instantiate1Lift val v d)
      (instantiate1Lift body v (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiate1Lift e v d)

/-- Node count with `fvar` counted as a leaf (its annotated type ignored).
Termination measure for recursion into instantiated binder bodies. -/
def sizeB : Expr → Nat
  | .bvar _ | .fvar .. | .sort _ | .const .. | .lit _ => 1
  | .app f a => sizeB f + sizeB a + 1
  | .lam ty body _ | .forallE ty body _ => sizeB ty + sizeB body + 1
  | .letE ty val body => sizeB ty + sizeB val + sizeB body + 1
  | .proj _ _ e => sizeB e + 1

/-- Instantiating with a size-1 replacement preserves `sizeB`. -/
theorem sizeB_instantiate1 (v : Expr) (hv : sizeB v = 1) :
    ∀ (e : Expr) (d : Nat), sizeB (instantiate1 e v d) = sizeB e := by
  intro e
  induction e <;> intro d <;> simp [instantiate1, sizeB, *]
  case bvar i =>
    split
    · exact hv
    · split <;> rfl

/-- Close a binder body: replace `fvar d …` leaves by `bvar k`, bumping
`k` under binders — the inverse of `instantiate1` with a fresh variable
(`fvar` type annotations are not descended into; a well-scoped term has no
`fvar d` inside another variable's annotation). -/
def abstract1 (e : Expr) (d : Nat) (k : Nat := 0) : Expr :=
  match e with
  | .bvar i => .bvar i
  | .fvar idx ty => if idx = d then .bvar k else .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (abstract1 f d k) (abstract1 a d k)
  | .lam ty body m => .lam (abstract1 ty d k) (abstract1 body d (k + 1)) m
  | .forallE ty body m => .forallE (abstract1 ty d k) (abstract1 body d (k + 1)) m
  | .letE ty val body =>
    .letE (abstract1 ty d k) (abstract1 val d k) (abstract1 body d (k + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (abstract1 e d k)

/-- Bulk abstraction (task #72): close `k` binders in one traversal —
replace `fvar (d + i) …` leaves (`i < k`) by the bound variable of the
`i`-th binder counted outermost-first, i.e. `bvar (c + (d + k - 1 - idx))`
at the traversal cursor `c` (bumped under binders; `fvar` type
annotations are not descended into, as in `abstract1`).  The semantics
is by construction the *fold* of `abstract1`, innermost binder first:

  `abstractRange e d (k + 1) c
     = abstractRange (e.abstract1 (d + k) c) d k (c + 1)`

(`abstractRange_succ`, `ConLeche/Verify/Abstract.lean`) — so the nested
per-binder `abstract1` chain of a telescope rebuild equals one
`abstractRange` pass per binder domain and one over the leaf. -/
def abstractRange (e : Expr) (d k : Nat) (c : Nat := 0) : Expr :=
  match e with
  | .bvar i => .bvar i
  | .fvar idx ty =>
    if d ≤ idx ∧ idx < d + k then .bvar (c + (d + k - 1 - idx))
    else .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (abstractRange f d k c) (abstractRange a d k c)
  | .lam ty body m =>
    .lam (abstractRange ty d k c) (abstractRange body d k (c + 1)) m
  | .forallE ty body m =>
    .forallE (abstractRange ty d k c) (abstractRange body d k (c + 1)) m
  | .letE ty val body =>
    .letE (abstractRange ty d k c) (abstractRange val d k c)
      (abstractRange body d k (c + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (abstractRange e d k c)

/-- Full node count, including `fvar` type annotations.  Termination
measure for predicates that recurse into annotations (but never into
instantiated bodies). -/
def sizeF : Expr → Nat
  | .bvar _ | .sort _ | .const .. | .lit _ => 1
  | .fvar _ ty => sizeF ty + 1
  | .app f a => sizeF f + sizeF a + 1
  | .lam ty body _ | .forallE ty body _ => sizeF ty + sizeF body + 1
  | .letE ty val body => sizeF ty + sizeF val + sizeF body + 1
  | .proj _ _ e => sizeF e + 1

/-- All reachable `fvar` leaves, including (hereditarily) those inside
their type annotations. -/
def fvarLeaves : Expr → List (Nat × Expr)
  | .fvar idx ty => (idx, ty) :: fvarLeaves ty
  | .app f a => fvarLeaves f ++ fvarLeaves a
  | .lam ty b _ | .forallE ty b _ => fvarLeaves ty ++ fvarLeaves b
  | .letE t v b => fvarLeaves t ++ fvarLeaves v ++ fvarLeaves b
  | .proj _ _ e => fvarLeaves e
  | _ => []
termination_by e => e.sizeF
decreasing_by all_goals first
  | (simp [Expr.sizeF]; omega)
  | simp [Expr.sizeF]

/-- Scope check: every reachable `fvar` index is below `d`,
hereditarily through annotations (the `Bool` mirror of the
verification-side `WScoped`).

Not on any per-memo-op path (task #43): the executed knot's cache
operations run unguarded, justified by the proven call discipline
(`ConLeche/Verify/Cached/DiscC*.lean`).  Remaining executable call sites are the
scope guards on checker-fabricated terms in `ConLeche/Kernel/Core.lean`
(the stuck-major rescues in `majorToCtor`), each O(small
fabricated term) once per fabrication.  TODO(cleanup, task #26):
interning should cache the fvar range per node, making those O(1). -/
def wscopedB : (d : Nat) → Expr → Bool
  | d, .fvar idx ty => idx < d && wscopedB idx ty
  | d, .app f a => wscopedB d f && wscopedB d a
  | d, .lam ty body _ => wscopedB d ty && wscopedB d body
  | d, .forallE ty body _ => wscopedB d ty && wscopedB d body
  | d, .letE ty val body =>
    wscopedB d ty && wscopedB d val && wscopedB d body
  | d, .proj _ _ e => wscopedB d e
  | _, .bvar _ | _, .sort _ | _, .const _ _ | _, .lit _ => true
termination_by _ e => e.sizeF
decreasing_by all_goals first
  | (simp [Expr.sizeF]; omega)
  | simp [Expr.sizeF]

/-- Are all bound-variable references bound within the expression (below
`k` at the root)?  Input declarations must satisfy `looseBVarsBounded 0`.
The pure walk is the specification; the executed function is the
`O(1)` loose-bvar field read (`looseBVarsBoundedFast`, `@[csimp]`
below, task #210 Part B). -/
def looseBVarsBounded (k : Nat) : Expr → Bool
  | .bvar i => i < k
  | .fvar _ _ => true
  | .sort _ | .const _ _ | .lit _ => true
  | .app f a => looseBVarsBounded k f && looseBVarsBounded k a
  | .lam ty body _ | .forallE ty body _ =>
    looseBVarsBounded k ty && looseBVarsBounded (k + 1) body
  | .letE ty val body =>
    looseBVarsBounded k ty && looseBVarsBounded k val && looseBVarsBounded (k + 1) body
  | .proj _ _ e => looseBVarsBounded k e

/-- Is the expression a λ?  The λ-rule's codomain-sort check (task
#152) fires once per λ *chain* — at the innermost binder, whose body
is not itself a λ — because that is the granularity the interned
binder-telescope loop (task #72) can reproduce. -/
def isLam : Expr → Bool
  | .lam .. => true
  | _ => false

/-- The prop-ness annotation of a λ node's meta, `none` off λs — the
head reading the task-#161 chain rule consumes (an outer λ's codomain
prop-ness is its body-λ's own annotation).  Total, so the walks
commute with it structurally (`lamPw_instantiateList_fvars`,
`lamPw_shiftFrom` in `ConLeche/Verify`). -/
def lamPw : Expr → Option PropWhen
  | .lam _ _ mbI => some mbI.pw
  | _ => none

/-- Does the expression contain any free variable (`fvar`)?  Input
declarations must be `fvar`-free; the checker introduces `fvar`s only
internally when opening binders. -/
def hasFvar : Expr → Bool
  | .bvar _ | .sort _ | .const .. | .lit _ => false
  | .fvar .. => true
  | .app f a => hasFvar f || hasFvar a
  | .lam ty body _ | .forallE ty body _ => hasFvar ty || hasFvar body
  | .letE ty val body => hasFvar ty || hasFvar val || hasFvar body
  | .proj _ _ e => hasFvar e

/-- The head of an application spine. -/
def getAppFn : Expr → Expr
  | .app f _ => getAppFn f
  | e => e

/-- The arguments of an application spine, outermost last. -/
def getAppArgs : Expr → List Expr
  | .app f a => getAppArgs f ++ [a]
  | _ => []

/-- Apply to a list of arguments. -/
def mkAppN (f : Expr) : List Expr → Expr
  | [] => f
  | a :: as => mkAppN (.app f a) as

/-- Rename constants throughout (including inside `fvar` type
annotations and `proj` type names); levels and binders untouched. -/
def renameConsts (f : Name → Name) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar i ty => .fvar i (renameConsts f ty)
  | .sort u => .sort u
  | .const n us => .const (f n) us
  | .app a b => .app (renameConsts f a) (renameConsts f b)
  | .lam ty body m => .lam (renameConsts f ty) (renameConsts f body) m
  | .forallE ty body m =>
    .forallE (renameConsts f ty) (renameConsts f body) m
  | .letE ty v body =>
    .letE (renameConsts f ty) (renameConsts f v) (renameConsts f body)
  | .lit l => .lit l
  -- Task #175 wiring W5: a `.proj` node's struct name is NOT renamed.
  -- Fixing the name keeps the entry-kind readings
  -- (`denote`/`denoteMeta`, which consult the table at the struct name)
  -- rename-invariant by construction (DESIGN, "W5 opening seam").
  | .proj s i e => .proj s i (renameConsts f e)

/- Logical-reference slice: renameConsts-memo omitted; exact inverse retained. -/

/-! ### `replaceConsts`: constants to terms

The member abstraction of the positivity function (charter item 2:
"the holes are ordinary open terms (members abstracted to fvars)"):
every constant `c.{us}` with `f c us = some e` becomes `e`, inside
`fvar` annotations too; a `.proj` node's structure name is untouched.
Memoized exactly as `renameConsts` (the memo keyed by the node, dropped
after each call; `@[csimp]`, kernel-checked, no trust point). -/

/-- Replace the constants `f` maps. -/
def replaceConsts (f : Name → List Level → Option Expr) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar i ty => .fvar i (replaceConsts f ty)
  | .sort u => .sort u
  | .const n us => (f n us).getD (.const n us)
  | .app a b => .app (replaceConsts f a) (replaceConsts f b)
  | .lam ty body m => .lam (replaceConsts f ty) (replaceConsts f body) m
  | .forallE ty body m => .forallE (replaceConsts f ty) (replaceConsts f body) m
  | .letE ty v body =>
    .letE (replaceConsts f ty) (replaceConsts f v) (replaceConsts f body)
  | .lit l => .lit l
  | .proj s i e => .proj s i (replaceConsts f e)

/- Logical-reference slice: replaceConsts-memo omitted; exact inverse retained. -/

/-- Strip `k` leading lambdas: the binder list (outermost first) and
the body. -/
def stripLams : Nat → Expr → Option (List (Expr × BinderMeta) × Expr)
  | 0, e => some ([], e)
  | k + 1, .lam ty b m =>
    (stripLams k b).map fun (bs, e) => ((ty, m) :: bs, e)
  | _ + 1, _ => none

/-- Strip `k` leading `∀`s: the binder list (outermost first) and the
body. -/
def stripPis : Nat → Expr → Option (List (Expr × BinderMeta) × Expr)
  | 0, e => some ([], e)
  | k + 1, .forallE ty b m =>
    (stripPis k b).map fun (bs, e) => ((ty, m) :: bs, e)
  | _ + 1, _ => none

/-- The body of a syntactic `∀`-telescope (the expression itself when
it is not a `∀`). -/
def piResult : Expr → Expr
  | .forallE _ b _ => piResult b
  | e => e

/-- Instantiate the leading `∀`-binders at the given arguments,
returning each binder's (progressively instantiated) domain together
with the fully instantiated residual. -/
def instPisAt : List Expr → Expr → Option (List Expr × Expr)
  | [], e => some ([], e)
  | a :: as, .forallE dom body _ =>
    (instPisAt as (body.instantiate1 a)).map fun (ds, rest) =>
      (dom :: ds, rest)
  | _ :: _, _ => none

/-- `instPisAt` for `λ`-binders. -/
def instLamsAt : List Expr → Expr → Option (List Expr × Expr)
  | [], e => some ([], e)
  | a :: as, .lam dom body _ =>
    (instLamsAt as (body.instantiate1 a)).map fun (ds, rest) =>
      (dom :: ds, rest)
  | _ :: _, _ => none

/- Logical-reference slice: bulk-telescope-substitution omitted; exact inverse retained. -/

/-- The type annotation of a free-variable leaf (the expression itself
otherwise; used to read the domains off an opened telescope's
variables). -/
def fvarTypeD : Expr → Expr
  | .fvar _ ty => ty
  | e => e

/-- Instantiate a telescope-context expression at an argument spine:
`bvar t` is replaced by the first argument, descending (the per-domain
effect of peeling a `t + 1`-binder telescope at the spine; the
verification's `instSeq`).  Used to evaluate a nested-auxiliary rule's
stored constructor-parameter instantiations at the recursor's actual
arguments. -/
def instSpine : List Expr → Nat → Expr → Expr
  | [], _, e => e
  | a :: as, t, e => instSpine as (t - 1) (e.instantiate1 a t)

/-- A recursor rule is *canonical* when its constructor's parameters
are exactly the recursor's own leading arguments: the major premise's
type applies the eliminated family to the first `cnP` telescope
variables.  Rules for nested auxiliary constructors (whose parameters
are instantiations like `Array Syntax`) are not canonical; they are
stored `.nested` when the syntactic reading succeeds (`nestedRuleSyn`
below) and `.inert` otherwise —
`iotaRec` never fires an inert rule, so it carries no fold
obligation. -/
def recRulePlain (recTy : Expr) (mI rP cnP : Nat) : Bool :=
  decide (cnP ≤ rP) && decide (rP ≤ mI) &&
  match recTy.stripPis mI with
  | some (_, .forallE dom _ _) =>
    dom.getAppArgs.take cnP ==
      (List.range cnP).map (fun k => Expr.bvar (mI - 1 - k))
  | _ => false

/-- **The syntactic reading of a nested rule's instantiation**: the
major's level and parameter instantiations, read off the
recursor type's major-premise domain
(`∀ …prefix… …indices…, ∀ (t : D.{lvls} p₁ … p_cnP i₁ … i_k), …`,
`k = mI - rP`).  The parameter instantiations are returned *lowered into
the rule-prefix context* (`rP` binders; `lowerBVars`) — the lift-back
roundtrip certifies that no index variable occurs in them — and the
domain's trailing arguments must be exactly the index variables in
order.  `none` when the prefix exceeds the major's position, the major
domain is not a constant-headed application of exactly `cnP + k`
arguments of this split shape, or an instantiation fails the syntactic
well-formedness guards (closed, bounded by the prefix telescope,
constants resolving by `resolves`, levels declared in `lps`) — the
facts `EnvWF` records for a stored `.nested` rule
(`nestedRuleSyn_inv`).  The installer stores it
for the rules of a recursor whose major is outside its block
(`tgtStoredRules`, `auxRuleFireR`). -/
def nestedRuleSyn (resolves : Expr → Bool) (lps : List Name) (tyA : Expr) (mI rP cnP : Nat) :
    Option (List Level × List Expr) :=
  if rP ≤ mI then
    match tyA.stripPis mI with
    | some (_, .forallE dom _ _) =>
      match dom.getAppFn with
      | .const _D lvls =>
        let args := dom.getAppArgs
        let k := mI - rP
        let pins := (args.take cnP).map (lowerBVars k 0)
        if args.length = cnP + k ∧
            args.take cnP == pins.map (liftLooseBVars k 0) ∧
            args.drop cnP ==
              (List.range k).map (fun i => Expr.bvar (k - 1 - i)) ∧
            pins.all (fun p => !p.hasFvar && p.looseBVarsBounded rP &&
              resolves p && p.allLevelParamsDefined lps) ∧
            lvls.all (Level.allParamsDefined lps) then
          some (lvls, pins)
        else none
      | _ => none
    | _ => none
  else none

/- Logical-reference slice: range-fields-and-guarded-memos omitted; exact inverse retained. -/

/-- Instantiate the leading `∀`-binders at *open* arguments, returning
the residual.  Unlike `instPisAt` this uses the general
capture-avoiding substitution (`instantiate1Lift`), so an argument may
mention loose `bvar`s of the surrounding context — which is what
building a projection's type out of the constructor telescope needs.

It sits BELOW the `@[csimp]` equation above deliberately: a `csimp`
replacement reaches the code generated for declarations elaborated
after it, so a caller written earlier in this file would compile
against the unguarded walk. -/
def instPisAtLift : List Expr → Expr → Option Expr
  | [], e => some e
  | a :: as, .forallE _ body _ => instPisAtLift as (body.instantiate1Lift a)
  | _ :: _, _ => none

/-! ## Pointer-equality shortcut -/

/-- Structural expression equality with a physical-equality shortcut
(definitionally `a == b`).  Used to validate interned-environment
entries against the stored constant they cache: the entry was created
from the very object stored in the environment, so the pointer test
succeeds without walking either expression. -/
@[inline] def exprPtrBEq (a b : Expr) : Bool :=
  withPtrEq a b (fun _ => a == b) (fun h => by subst h; simp)

/- Logical-reference slice: level-parameter-shortcuts omitted; exact inverse retained. -/

end ConLeche.Expr

end -- original EOF public section of ConLeche.Kernel.ExprOps
/- END exact source origin ConLeche.Kernel.ExprOps -/

/- BEGIN exact source origin ConLeche.Kernel.Env -/
-- Bundled origin 06, header line 1: module

-- Bundled origin 06, header line 3: public import ConLeche.Kernel.Expr

@[expose] public section

/-!
# Declarations and the global environment

Input declarations mirror `Lean.Declaration` (only the kinds the checker
supports so far are present; more are added feature by feature).

The environment is, for now, a simple association list of checked constants.
This is the *verified* reference representation; a faster indexed structure
can replace it later, with a proof that it refines this one.
-/

namespace ConLeche

/-- **The checker's mode setting** — two values, validated once at
startup and threaded as configuration, never re-read at runtime.

* `.verified` (the default, `--verified`): the verified lane.  The
  surface the **graded** set-theoretic
  model proves — `no_proof_of_Empty_cached`
  (`ConLeche/Verify/Cached/MainC.lean`) is its letter over the driver
  this binary runs.  The seven TT-lane checks (tasks #126, #129, #130,
  #135, #136, #137, #146) are off; the β-certificate gate is on — at a
  λ-binder whose **validated** annotation is `.never` the per-redex
  argument certificate is skipped (`betaGateFires`,
  `ConLeche/Kernel/CoreDefs.lean`) — and the io-graded knot slot skips the
  per-argument application certificate under the same licence.  Every
  other certificate family runs unconditionally.
* `.trusted` (`--trusted`): the unverified lane — the same checker
  with the work that exists **for certification only** omitted.
  What must not be dropped is everything believed necessary for
  *soundness* (which is different from "necessary for our soundness
  proof to go through"), so the lane is never optimized on its own:
  it is the real mode with certain steps omitted (DESIGN.md, "MODE
  RENAME").  Since 2026-09-06 it is literally that: the one cached
  driver (`ConLeche/Cached/ParsedC.lean`) at `.trusted`, where
  `verifiedChecks` and `certs` are `false` — so what it omits is
  exactly what those two functions gate in `ConLeche/Cached/CoreC.lean`
  (DESIGN.md, "CORET RETIRED").

**The mode is the cores' only parameter** (task #185, 2026-09-06).
The configuration record that stood between the mode and the
shipped cores from task #172 B2 to task #185 is gone: every field it
carried is a function on `CheckMode` below (`ttChecks`,
`verifiedChecks`, `betaGate`, `ioGate`, `certs`), each a `match` on
the two constructors, so each read reduces by `rfl` at either mode —
the record's `rfl`-eliminability argument, at the enum itself.

The two values are spelled `--verified` and `--trusted` on the command
line, and they say what the modes are FOR rather than which artefact
proves them. -/
inductive CheckMode where
  | verified
  | trusted
  deriving DecidableEq, Repr, Inhabited

/-- Are the seven TT-lane checks enabled?  **Constantly `false`**: the
declarative verification lane they served is retired (task #148).
The gated call sites are kept, statically unreachable, so
that the checks themselves survive as reviewed code and the accessor
stays the single place a future lane would turn them back on. -/
def CheckMode.ttChecks : CheckMode → Bool
  | _ => false

/-- Are the *verified* mode's extra checks enabled — the checks the
model lane wants and the trusted lane must not run, because they are
needed for the soundness *proof* rather than for soundness?  The
second accessor the kernel branches on
(task #152: the λ-rule's codomain-sort check, `inferBody`'s `.lam`
clause).  This is deliberately **not** `ttChecks`: the λ codomain sort
is a premise of the set lane's annotation pass (`ConLeche/Model`), so it
must run at `.verified`; and it is a check the reference kernel's
`infer_lambda` does not run, so it must not run at `.trusted`. -/
def CheckMode.verifiedChecks : CheckMode → Bool
  | .trusted => false
  | _ => true

/-- Is the **β-certificate gate** on (task #161)?  The third accessor
the kernel branches on: at a λ-binder whose validated annotation datum
is `.never` the per-redex argument certificate is skipped
(`betaGateFires`, `ConLeche/Kernel/CoreDefs.lean`).

Two disciplines ride on this accessor being a *mode* accessor rather
than a second knot:

* **the establishment/consumption asymmetry fence** — the gate reads a
  *validated* annotation (only meaningful where
  `verifiedChecks = true`) and
  wraps the **test** only, so no certificate a possibly-zero datum
  needs is ever skipped;
* **the dead-branch collapse** — at `betaGate = false` the gated test
  is definitionally the ungated one (`betaGateFires_off`), which is
  what keeps the trusted lane's proofs one rewrite away from their
  pre-gate form.

Since the R core's retirement the gate is on at the *only* verified
mode, so `betaGate` and `verifiedChecks` now agree except at
`.trusted`.
They stay two accessors because they gate different checks and the
kernel reads them at different sites. -/
def CheckMode.betaGate : CheckMode → Bool
  | .verified => true
  | _ => false

/-- Is the **io-grade knot slot** the io body (task #170 / #172 B4)?
Read once per knot level by the cached knot (`coreKnotI`,
`ConLeche/Cached/CoreC.lean`) to select what the internal inference call
sites run: the io body, whose application clause skips the
per-argument certificate at a `.never` binder under the graph-regime
licence (`ConLeche/Model/IOLicense.lean`) — official's `infer_only`.
**`true` at both modes** since the licence ruling of 2026-09-06 (the
trusted mode is defined as the verified one minus certification-only
work, and the io grade is a *licence*, not a certificate; the retired
trusted configuration record had it `true` too).  It is its own
function, and not `betaGate`, so that an attribution probe can flip
one without the other; the
mode-parametric spec knot (`coreKnot`, `ConLeche/Kernel/Core.lean`)
selects its io slot on `betaGate`, the P tier's own bit, so the two
agree exactly at `.verified` — the one instance the simulation tower
is stated at (`memoEI_inferIO_sim`, `ConLeche/Verify/Cached/KnotC.lean`).
Spelled with a wildcard so it is the literal `true` at a *variable*
mode too. -/
def CheckMode.ioGate : CheckMode → Bool
  | _ => true

/-- **The certificate families** (task #76's skip list; the twin's
retirement, 2026-09-06): the work the checker does *only* so the
soundness proof can consume it, and that the reference kernel does not
do — the β-redex argument certificate (`whnfAppI`/`betaPeelI`, through
`betaSkip`), the io-grade application argument certificate
(`inferSpineIOI`, through `ioSkip`), the recursor/constructor telescope
certificates and the canonical-index comparison of ι (`iotaRecI`), the
plain-rule parameter re-comparison, the type-former and per-projection
telescope certificates of structure η and unit-like conversion
(`structEtaCertWithI`, `structUnitCertI`), and the K/η rescue's
synthetic-spine and proof-irrelevance certificates (`majorToCtorI`).
Read through `ConLeche/Cached/CoreC.lean`'s `certAtI`/`certUnlessI` and
the two skip predicates below; `true` runs them, `false` (the trusted
mode) skips them outright.

**Why a second function beside `verifiedChecks`**, when the two agree
at both constructors.  Both are certification-only work; they differ
in what the proof towers need of them.  `verifiedChecks` gates checks
the P tier's *premises* rest on (the λ-codomain sort, the annotation
validations), so the mode-parametric spec (`ConLeche/Kernel/Core.lean`)
reads it at the same sites the cached core does.  The certificate
families have **no switch in the spec** — no proved instance ever
omits them — so the cached core's reads of `certs` are what the
simulation tower (`ConLeche/Verify/Cached/*`) must see through: it is
stated under `hμ : mode.verifiedChecks = true`, and
`certs_of_verifiedChecks` (`ConLeche/Verify/BetaGate.lean`) turns every
read into the literal `true` there.  The `.trusted` instance of the
cached-vs-spec simulation is false, deliberately: the trusted core
skips what the spec runs. -/
def CheckMode.certs : CheckMode → Bool
  | .verified => true
  | .trusted => false

/-- **The β site's read** (`whnfAppI`/`betaPeelI`): skip the per-redex
argument certificate wholesale when the certificate families are off,
else exactly when the β gate is on and the (validated) annotation
datum is `.never`.  At `.verified` it is the datum (`pw.isNever`, the
same predicate as the spec's `betaGateFires .verified pw`); at
`.trusted` the literal `true` — the β certificate is a certificate
family, skipped outright, so the licence is moot there. -/
@[inline] def CheckMode.betaSkip (mode : CheckMode) (pw : PropWhen) : Bool :=
  !mode.certs || (mode.betaGate && pw.isNever)

/-- **The io site's read** (`inferSpineIOI`): skip the per-argument
application certificate at a `.never` binder (the graph-regime
licence, `ConLeche/Model/IOLicense.lean`), or wholesale when the
certificate families are off.  At `.verified` it is `pw.isNever` — the
licence reads the datum and nothing else, as the licence ruling of
2026-09-06 has it — and at `.trusted` it is `true`. -/
@[inline] def CheckMode.ioSkip (mode : CheckMode) (pw : PropWhen) : Bool :=
  !mode.certs || pw.isNever

/-- Data common to all constants: name, universe parameters, type. -/
structure ConstantVal where
  name : Name
  levelParams : List Name
  type : Expr
  deriving DecidableEq, Repr, Inhabited

/-- How a stored recursor rule may fire (install-computed; parse
placeholder `.inert`).

* `.plain` — a canonical rule (`Expr.recRulePlain`): the constructor's
  parameters are the recursor's leading arguments and its levels link
  to the recursor's by name.
* `.nested lvls pins` — a certified nested-auxiliary rule: the
  constructor's levels and parameters are *fixed instantiations*, read
  at install off the recursor type's major-premise domain — `lvls`
  are levels over the recursor's level parameters, `pins` expressions
  in the recursor's `rulePrefix`-binder telescope context (index
  premises between the prefix and the major are supported: the shape
  certification lowers the stored instantiations out of the
  `majorIdx`-binder context after checking that no index variable
  occurs in them).  At fire time the constructor's levels and
  parameters are checked against these, instantiated at the recursor's
  actual level and leading-argument spine.
* `.inert` — never fires; a *matched* inert rule is a positive
  decline in `iotaRec` (an uncertified nested auxiliary rule).

**Why the fire compares parameters, levels and indices at all** (the
official kernel's `inductive_reduce_rec` and lean4lean fire by
constructor name plus `nfields` and compare nothing — typing justifies
it).  Our soundness argument for a fire is the stored rule law
(`RecRuleLaw`) at the recursor's own parameters, and the P lane has no
typing derivation in hand: the redex is only `WellDenotedV`, and since the
ι-slot licence (2026-09-05) the major slot of a data-motive recursor is
not even inferred, so nothing but these comparisons relates the
constructor's `p⃗'`/`idx'` to the recursor's `p⃗`/`idx`.  Moving them
into a licence was investigated (2026-09-06, `_tmp/iota-uniform/`):
for *indices* it is refuted at the squash regime (`Acc.rec.{1}` on a
cross-index `Acc.intro`: the licensed major's membership in `{pt}`
carries no information, so the uniform fire's law is false); for
*parameters* see `RecRule.paramsBlind`.
Stake: ≤ 0.8 % of init-full instructions. -/
inductive RecRuleFire where
  | inert
  | plain
  | nested (lvls : List Level) (pins : List Expr)
  deriving DecidableEq, Repr, Inhabited

/-- One iota rule of a recursor: applying the recursor (with its
parameters, motives and minors) to a `ctor`-headed major premise reduces
to `rhs` applied to the parameters, motives, minors and the constructor's
`nfields` fields.  `ctorParams` (the constructor's parameter count) and
`fire` (the canonical/nested/inert firing mode), the two rescue
bits `k`/`eta` and the parameter-comparison bit `paramsBlind` are
*computed at install* from the stored constructor, its inductive's
capabilities, the recursor type and the installing route — input rules
carry the parse placeholders `0`/`.inert`/`false`; reduction reads only
the installed values, never re-deriving them per fire. -/
structure RecRule where
  ctor : Name
  nfields : Nat
  /-- The constructor's parameter count (install-computed; parse
  placeholder `0`). -/
  ctorParams : Nat
  /-- The firing mode (install-computed, parse placeholder `.inert`):
  `.plain` for canonical rules (`Expr.recRulePlain`), `.nested` for
  certified nested-auxiliary rules, `.inert` otherwise. -/
  fire : RecRuleFire
  rhs : Expr
  /-- **The K bit** (install-computed, parse placeholder `false`;
  official `recursor_val::is_k`): this rule is its recursor's only
  one, its constructor has no fields, and that constructor's
  inductive is stored with the K capability — the standing condition
  of `majorToCtor`'s K rescue, decided once at the block's install
  instead of at every recursor application. -/
  k : Bool := false
  /-- **The η-rescue bit** (install-computed, parse placeholder
  `false`): this rule is its recursor's only one, its constructor is
  the η constructor of a stored η-capable inductive, and the recursor
  is not itself a projection function (whose rescue would loop) — the
  standing condition of `majorToCtor`'s structure-η rescue. -/
  eta : Bool := false
  /-- **The parameter-comparison bit** (install-computed, parse
  placeholder `false`): the ι step fires this rule without comparing
  the recursor's parameter arguments with the constructor's.  The
  installer and the pinned basis blocks set it, because their rule
  laws hold at any pair of fitting parameter spines; the projection
  functions do not, because their laws read the comparison.  The official
  kernel compares nothing here
  (`inductive_reduce_rec`), so a set bit is a step towards it. -/
  paramsBlind : Bool := false
  deriving DecidableEq, Repr, Inhabited

/-- Whether the ι step compares this rule's parameter comparands.  A
`.plain` rule marked `paramsBlind` fires without them; a `.nested`
rule's comparands are its stored pins and are compared at every
route. -/
def RecRule.compareParams (rl : RecRule) : Bool :=
  match rl.fire with
  | .plain => !rl.paramsBlind
  | _ => true

theorem RecRule.compareParams_plain {rl : RecRule} (hf : rl.fire = .plain)
    (hb : rl.paramsBlind = false) : rl.compareParams = true := by
  unfold RecRule.compareParams; rw [hf, hb]; rfl

theorem RecRule.compareParams_nested {rl : RecRule} {lvls : List Level}
    {pins : List Expr} (hf : rl.fire = .nested lvls pins) :
    rl.compareParams = true := by
  unfold RecRule.compareParams; rw [hf]

/-- Reducibility hint of a definition, mirroring Lean's
`ReducibilityHints`: `abbrev` unfolds first, `opaque` last, `regular`
definitions compare by their definitional height.  The hints steer only
the *order* of lazy delta unfolding in `isDefEq` — never whether two
terms are definitionally equal — so the model and all soundness proofs
are independent of them. -/
inductive ReducibilityHint where
  | «opaque»
  | «abbrev»
  | regular (height : Nat)
  deriving DecidableEq, Repr, Inhabited

namespace ReducibilityHint

/-- `h₁.lt h₂`: `h₁` is strictly less eager to unfold than `h₂` (the
lazy delta step unfolds the greater side to bring the two closer;
`opaque < regular h < abbrev`, regular heights compare by `<`). -/
def lt : ReducibilityHint → ReducibilityHint → Bool
  | _, .opaque => false
  | .abbrev, _ => false
  | .opaque, _ => true
  | _, .abbrev => true
  | .regular h₁, .regular h₂ => h₁ < h₂

/-- Both hints are `regular` at the *same* height — the only situation
in which the reference kernels (nanoda `try_eq_const_app`, the official
kernel) attempt the same-head congruence short-circuit instead of
unfolding.  Deliberately NOT generalized to other equal hints: proof
authors rely on `abbrev` definitions unfolding eagerly, and trying
spine defeq first on `abbrev`-headed applications risks reduction bombs
(spines that are only equal after reduction, retried at every
congruence level). -/
def sameRegular : ReducibilityHint → ReducibilityHint → Bool
  | .regular h₁, .regular h₂ => h₁ == h₂
  | _, _ => false

end ReducibilityHint

/-- The trusted basis inductives (hand-written set models). -/
inductive BasisKind where
  | eqK | natK | emptyK | falseK | quotK
  deriving DecidableEq, Repr, Inhabited

/-- Definitional capabilities of a stored inductive type, recorded at
install: structural eta for its (single-constructor) values, unit-like
collapse (all inhabitants definitionally equal), and rule K for its
recursor.  The pinned basis blocks carry pinned capabilities. -/
structure IndCaps where
  eta : Bool := false
  /-- The single constructor the eta law reconstructs through
  (meaningful only when `eta`). -/
  etaCtor : Name := .anonymous
  /-- Its parameter count (meaningful only when `eta`). -/
  etaParams : Nat := 0
  /-- Its field count (meaningful only when `eta`). -/
  etaFields : Nat := 0
  unitlike : Bool := false
  /-- The parameter count of the unit-like family (meaningful only
  when `unitlike`). -/
  unitParams : Nat := 0
  ruleK : Bool := false
  /-- **The family's result-sort zero-ness datum** (install-computed
  from the stored type; the default `ifAllZero []` reads
  "zero at every valuation", which no rescue passes).  The structure-η
  rescue fires only where the official kernel's `is_never_zero` holds
  of the *instantiated* result sort, and this datum decides that at a
  use by one level substitution (`capsNeverZero`) instead of a walk
  down the family's type at every rescue. -/
  sortZ : PropWhen := .ifAllZero []
  /-- **The block's members** (official's `all`): the formers installed
  together with this one, in block
  order, itself included.  Read by nested positivity alone — a container
  frame's restart (`nestFrame`) abstracts only group-mates listed here,
  so an accepted frame's holes are members of ONE recorded block (a pinned
  basis type records `[T]`, as official does; `Quot` alone keeps `[]`). -/
  all : List Name := []
  /-- **The family's parameter count** (official's `inductive_val.nparams`):
  the block's declared parameter count, recorded at every install
  (uniform: `BlockShape.nP`; basis: the pin's).  Read by nested positivity
  alone, and only for a
  container WITHOUT constructors (`nestContainer`), whose parameter count
  no constructor record carries. -/
  nparams : Nat := 0
  /-- **The family's constructors, in declaration order** (official's
  `inductive_val.cnstrs`): recorded at install (uniform: the member's
  constructors; basis: the pin's).  Read by nested positivity alone
  (`nestContainer`): a container's constructors are looked up by name,
  never by a scan of the environment.  `Quot` records none (it is no
  container). -/
  ctors : List Name := []
  deriving DecidableEq, Repr, Inhabited

/-- **One structure's projection table** (task #175 S1, 2026-09-06):
everything the checker's `.proj` rules consume about a structure `T`,
stored once at the structure's install as ONE constant (keyed on the
structure: `projTableName structName`; see `Env.findProj?`).

A table is installed by the direct simple-structure install alone.
The `.proj T i` node is first-class — typed by `bodies[i]`, the
field's result-type **body** `F_i[p⃗ ↦ bvars, f_j ↦ .proj T j (bvar
0)]`, scoped at `numParams + 1` (the parameters and the subject are
loose `bvar`s, the subject at `bvar 0`, the earlier fields already
spelled as projections of the subject), instantiated at a use by ONE
`instantiateList` along the subject type's arguments and the subject
(`ProjEntry.typeAt`); reduced by the generic structural rule `proj_i
(ctor p⃗ x⃗) ↦ x_i`, guarded at possibly-Prop instances by the stored
`guards[i]`/`structSort` levels.  The bodies are taken from the
annotated constructor type by substitution alone (`structProjBodies`)
— no annotate, no infer, no pins: a slot with no legal instantiation
simply fails the guard at every use.

**No table kinds** (task #175 tower-flag): every stored table carries
bodies, types its nodes and fires its rule, and the projection typing and iota laws
hold uniformly over every entry of every stored table. -/
structure ProjTable where
  structName : Name
  /-- the parent type former's level parameters -/
  levelParams : List Name
  /-- the parent's parameter count -/
  numParams : Nat
  /-- the single constructor (the structural rule's head) -/
  ctor : Name
  /-- its field count -/
  numFields : Nat
  /-- the parent's result sort -/
  structSort : Level
  /-- per field, the projection's result-type body (see above) -/
  bodies : Array Expr
  /-- per field, **the projection's `Prop` guard level**: the
  projected field's sort joined with the sorts of the earlier fields
  that a later field's type uses — exactly the sorts the official
  `infer_proj` requires to be `Prop` when projecting from a
  propositional structure (task #175 W4c/O4, `structProjGuards`); the
  infer branch checks it at every use of a `Prop`-declared
  structure. -/
  guards : List Level
  /-- **The projection offset** (task #210 Part A): the position of
  field `0` in the carrier's pair chain — `1` at the installer's
  TAGGED tower (`inj 0 (mkTower (fs ++ [pt]))`, the tag in front),
  which is the only value the installer stores (`checkBlockTables`);
  `0` would read a bare tuple tower `mkTower fs` — so that the model
  reads `.proj T i` as `projS (i + off)`.  Syntactic to the kernel: the typing, iota and
  eta rules never look at it. -/
  off : Nat
  deriving DecidableEq, Repr, Inhabited

/-- **One projection-table entry** — the per-field VIEW of a
`ProjTable` (`ProjTable.entry`), what `Env.findProj? T i` returns:
the table's data at field `idx`.  `body` is `bodies[idx]` and
`fieldSort` is `guards[idx]`. -/
structure ProjEntry where
  structName : Name
  idx : Nat
  levelParams : List Name
  numParams : Nat
  ctor : Name
  numFields : Nat
  /-- the projection's result-type body, scoped at `numParams + 1`
  (see `ProjTable.bodies`) -/
  body : Expr
  /-- the projection's `Prop` guard level (see `ProjTable.guards`) -/
  fieldSort : Level
  structSort : Level
  /-- the table's projection offset (see `ProjTable.off`) -/
  off : Nat
  deriving DecidableEq, Repr, Inhabited

/-- The per-field view of a table at field `i` (meaningful for `i <
numFields`). -/
def ProjTable.entry (tbl : ProjTable) (i : Nat) : ProjEntry :=
  ⟨tbl.structName, i, tbl.levelParams, tbl.numParams, tbl.ctor, tbl.numFields,
    tbl.bodies.getD i default, tbl.guards.getD i .zero, tbl.structSort, tbl.off⟩

/-- Information stored about an accepted constant. -/
inductive ConstantInfo where
  | axiomInfo (val : ConstantVal)
  | defnInfo (val : ConstantVal) (value : Expr) (hint : ReducibilityHint)
  | thmInfo (val : ConstantVal) (value : Expr)
  /-- An inductive type former (whnf-stuck) with its capabilities. -/
  | indInfo (val : ConstantVal) (caps : IndCaps)
  /-- A basis constructor (whnf-stuck; the iota target). -/
  | ctorInfo (val : ConstantVal) (numParams numFields : Nat)
  /-- A basis recursor with its iota rules.  Only the two sums the
  firing path reads are stored: `majorIdx` (= numParams + numMotives +
  numMinors + numIndices, the major premise's argument position) and
  `rulePrefix` (= numParams + numMotives + numMinors, the length of the
  argument prefix a rule's rhs is applied to).  The individual counts
  are consumed at install time only and are not stored. -/
  | recInfo (val : ConstantVal) (majorIdx rulePrefix : Nat)
      (rules : List RecRule)
  /-- A structure's projection table (see `ProjTable`), stored under
  the reserved name `projTableName tbl.structName` so lookups,
  freshness and environment extension are uniform with constants.  Its
  `toConstantVal` carries the closed dummy type `Sort 1` (the table is
  not a term: no `.const` names it, `inferTypeCore` rejects one), so
  the environment well-formedness and model machinery cover the
  constant uniformly; the bodies' own well-formedness is `EnvWF`'s
  table clause. -/
  | projInfo (tbl : ProjTable)
  deriving DecidableEq, Repr, Inhabited

/-- **Which of the four quotient constants a `#QUOT` record declares**
(task #293): the `kind` field of the export record, decoded.  The
order is the pinned block's (`quotBasis`): `Quot`, `Quot.mk`,
`Quot.lift`, `Quot.ind`. -/
inductive QuotKind where
  | type | ctor | lift | ind
  /-- `Quot.sound`, which the export writes as an ordinary axiom record
  beside the four `#QUOT` ones: not a `kind` the decoder ever reads, but
  a slot of the pinned block, and the kind `preparePrelude` gives that
  record when it is not the pinned one. -/
  | sound
  deriving DecidableEq, Repr, Inhabited

/-- The quotient constant's position in the pinned block
(`BasisKind.quotK.decls`). -/
def QuotKind.slot : QuotKind → Nat
  | .type => 0 | .ctor => 1 | .lift => 2 | .ind => 3 | .sound => 4

/-- A declaration presented to the checker. -/
inductive Declaration where
  | axiomDecl (val : ConstantVal)
  | defnDecl (val : ConstantVal) (value : Expr) (hint : ReducibilityHint)
  | thmDecl (val : ConstantVal) (value : Expr)
  /-- An `opaque` declaration: exactly a theorem check without the
  is-a-proposition requirement — the value is checked against the
  type as a realizability witness and then discarded (stored as an
  `axiomInfo`): the constant is never delta-unfolded, as the official
  kernel's `is_delta` never unfolds an opaque.  (A theorem is the
  same here — stored by its statement, never unfolded — where
  official still unfolds theorems until
  https://github.com/leanprover/lean4/pull/14896.) -/
  | opaqueDecl (val : ConstantVal) (value : Expr)
  /-- **The fold's own record for "install the pinned basis block"**
  (task #293).  No frontend function produces one: the decoder emits
  the file's records, `preparePrelude` reorders them, and it is
  `checkDecl`'s `.indDecl` arm that RECOGNISES a block as one of the
  five pinned ones (`basisPinHit`, up to `ConstantInfo.canon`) and its
  `.quotDecl` arm that recognises the quotient package, both of which
  install through this kind.  It stays a constructor of `Declaration`
  because the install and every proof about it are written over the
  kind. -/
  | basisDecl (kind : BasisKind)
  /-- An inductive block: type formers, constructors and recursors,
  with **the parameter count the stream DECLARES** (task #228).
  Installed by the inductive installer (`checkBlock`).

  The count is official's own declaration shape: `add_inductive`
  takes `Declaration.inductDecl lparams nparams types` with ONE
  `nparams` for the whole block (the replay reads it off an inductive
  record's `numParams` field, `Lean4Checker/Replay.lean`), checks
  every former and every constructor against it and generates the
  recursor with it.  It is checked here by `indParamsOk` and used as
  the block's parameter count by the installer — before task #228 the
  count was read OFF the constructors, which agrees on every valid
  stream and cannot see a declaration that lies. -/
  | indDecl (block : List ConstantInfo) (numParams : Nat)
  /-- **A quotient declaration record, as the file declares it** (task
  #293).  `lean4export` writes the quotient package as four records —
  one per constant, each tagged with its `kind` — and the decoder emits
  one `quotDecl` per record: the constant the file declares and the
  slot it declares it at, and nothing else.  It mirrors official's
  `Declaration.quotDecl`, which is likewise the record's own kind and
  not a basis decision.

  What reaches the FOLD under this constructor is a quotient record
  that is **not** the pinned package: `preparePrelude`
  (`ConLeche/Frontend/Prepare.lean`) retags a record matching its pin
  to `basisDecl .quotK`, so `checkDecl`'s arm here is the mismatch —
  a positively detected unsupported feature, the decline the parser
  used to issue. -/
  | quotDecl (kind : QuotKind) (val : ConstantVal)
  deriving DecidableEq, Repr, Inhabited

namespace Declaration

end Declaration

/-- **The length of a syntactic Π-telescope ending in a SORT**:
`some n` when the expression is `n` Π binders with a `.sort`
residual, `none` when the residual is anything else — a constant that
only *unfolds* to a telescope, say (task #195).  A spine walk: one
child per step, never a tree.

The distinction is what makes `indParamsOk` one-sided.  Official's
telescope loop (`check_inductive_types`, `inductive.cpp`) reduces the
residual to weak head normal form before every binder; at a `.sort`
residual that reduction is the identity and no further binder can
appear, so `n` is exactly the number of binders official counts. -/
def Expr.piSortTeleLen? : Expr → Option Nat
  | .forallE _ body _ => (Expr.piSortTeleLen? body).map (· + 1)
  | .sort _ => some 0
  | _ => none

/-- **The stream's declared parameter count, checked as official
checks it** (task #228).  Official trusts the count the declaration
carries and checks the block AGAINST it, in two places:

* `check_inductive_types` peels `nparams` Π binders off every type
  former, reducing to weak head normal form before each, and throws
  *"number of parameters mismatch in inductive datatype declaration"*
  when the telescope runs out first;
* the replay compares every exported constructor record with the one
  the kernel GENERATES, whose `numParams` field is `nparams`, so a
  constructor record declaring a different count is *"Invalid
  constructor"* (`checkPostponedConstructors`).

Both halves are below, and both are ONE-SIDED on purpose: `false`
means official rejects, never merely that this checker cannot see
why.  A former whose declared type is a Π-telescope ending in a sort
and shorter than `nP` is one official cannot peel `nP` binders off
(`Expr.piSortTeleLen?`); a former with any other residual may still
unfold to a longer telescope and is left to the install stages, which
peel it with `whnf` exactly as official does (`whnfTelescope`).

The exported `numIndices` is deliberately NOT checked: nothing ever
compares an inductive record against the generated `InductiveVal`
(only constructors and recursors are postponed and compared), so a
declared index count is not input official reads, and checking it
would reject blocks official accepts. -/
def indParamsOk (nP : Nat) (block : List ConstantInfo) : Bool :=
  block.all fun ci => match ci with
    | .indInfo cvT _ =>
      match cvT.type.piSortTeleLen? with
      | some n => decide (nP ≤ n)
      | none => true
    | .ctorInfo _ nPc _ => nPc == nP
    | _ => true

/-- The public projection-*function* name for field `i` of structure
`T` (a `Nat` component keeps it out of the way of exported
identifiers; installs are duplicate-checked regardless).  Since task
#175 S1 no table entry lives under this name: the direct install's
table is one constant per structure, `projTableName`. -/
def projFnName (T : Name) (i : Nat) : Name := (T.str "proj").num i

/-- The reserved name of structure `T`'s projection table (task #175
S1): one constant per structure, a `Nat` component keeping it out of
the way of exported identifiers (the front door rejects the shape,
`Name.isProjFnShape`), distinct from every `projFnName` name. -/
def projTableName (T : Name) : Name := (T.str "projTable").num 0

namespace ConstantInfo

def toConstantVal : ConstantInfo → ConstantVal
  | .axiomInfo v | .defnInfo v _ _ | .thmInfo v _ => v
  | .indInfo v _ | .ctorInfo v _ _ | .recInfo v _ _ _ => v
  | .projInfo tbl => ⟨projTableName tbl.structName, tbl.levelParams, .sort (.succ .zero)⟩

def name (c : ConstantInfo) : Name := c.toConstantVal.name

/-- A projection table (task #175 W4c): a table, not a term — no
`.const` node names it (`inferTypeCore` rejects one), so the model
owes it no leaf. -/
def isTowerEntry : ConstantInfo → Bool
  | .projInfo _ => true
  | _ => false

end ConstantInfo

namespace Declaration

/-- **The names a declaration record declares**: the hoist's name index
and `preparePrelude`'s lookup of the stream's own copy of a prelude
declaration read it (`ConLeche/Frontend/{NatOpGround,Prepare}.lean`).
A quotient record declares the one constant it carries — the other
three constants of the pinned block are other records' — and a
`basisDecl`, which no frontend function produces (it is the fold's own
record for "install the pinned block"), declares the pin's. -/
def names : Declaration → List Name
  | .axiomDecl cv | .defnDecl cv .. | .thmDecl cv .. | .opaqueDecl cv .. => [cv.name]
  | .quotDecl _ cv => [cv.name]
  | .indDecl block _ => block.map (·.name)
  | .basisDecl _ => []

end Declaration

/-- The global environment: the list of constants accepted so far, newest
first.  Names are unique (the checker rejects duplicates), so the order is
irrelevant for lookup. -/
structure Env where
  consts : List ConstantInfo
  deriving Repr, Inhabited

namespace Env

/-- The empty environment; the starting point of every checker run. -/
def empty : Env := ⟨[]⟩

def find? (env : Env) (n : Name) : Option ConstantInfo :=
  env.consts.find? (·.name == n)

/-- Look up the projection-table entry for field `i` of `T`: the
structure's table (`projTableName T`), viewed at field `i` (task #175
S1; `none` beyond the table's field count). -/
def findProj? (env : Env) (T : Name) (i : Nat) : Option ProjEntry :=
  match env.find? (projTableName T) with
  | some (.projInfo tbl) => if i < tbl.numFields then some (tbl.entry i) else none
  | _ => none

end Env

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Env
/- END exact source origin ConLeche.Kernel.Env -/

/- BEGIN exact source origin ConLeche.Kernel.PropRead -/
-- Bundled origin 07, header line 1: module

-- Bundled origin 07, header line 3: public import ConLeche.Kernel.Env
-- Bundled origin 07, header line 4: public import ConLeche.Kernel.ExprOps

@[expose] public section

/-!
# Fast prop-ness off the head symbol (task #168)

Two pure readers that answer "is this type a proposition?" / "is this
term a proof?" from the **head symbol, the arity and the validated
`pw` annotations** — no inference, no reduction, no memo.

Prop-ness is invariant under application: `zeronessOf (imax u v) =
zeronessOf v`, so the zero-ness of the sort of the type of `c a⃗` is
that of `c`'s *stored* type at every arity, over-application included.
The datum a head-symbol reader needs is therefore **one `PropWhen` per
constant** — the zero-ness of the sort of its type, read off the
stored (annotated, validated) type and instantiated at the use's
levels by `substPW`.

Both readers are three-valued (`some pw` = the datum, `none` = unknown,
fall back to inference).  The kernel's verdict on a datum is exactly the
slow path's `Level.isEquiv u .zero`: `pw == (.ifAllZero [])` ⟺ the
sort is zero at every valuation.

Trust: the readers consume annotations the checker validates
(`(forall-cod)`, `(lam-cod-leaf)`/`(lam-cod-chain)` in `inferBody`;
the stored types were validated at install), so they may only be
*consulted* at the verified modes (`mode.verifiedChecks`) — the trusted core
writes no data and the parser default stays.  The **"definitely not a
proof" arm** (`notProofFast`) needs no model theorem: refusing the
proof-irrelevance shortcut is always sound; its obligation is
kernel-level agreement with the slow path, which the landing census
records (DESIGN.md, task #168).  The **"definitely a proof" arm** is a
squash-regime licence (`prf_of_isProofFast`, `ConLeche/Model/Rules/DefEqSoundKit.lean`).
-/

namespace ConLeche

namespace Expr

/-- The residual after peeling `k` *syntactic* ∀ binders whose data
are all `.never` (no substitution — the residual may mention the
peeled binders; the readers only look at its head shape).  The
`.never` requirement costs no coverage on validated types — the
binders of a type former `∀ p⃗, Sort u` all carry the datum of a
`succ` codomain sort — and it is what licenses the "yes" arm's
telescope walk without a certificate (`neverChain_of_peel`,
`ConLeche/Model/Rules/DefEqSoundKit.lean`: every slot is in the graph
regime, `io_domain_transfer`). -/
def peelNeverPis : Nat → Expr → Option Expr
  | 0, e => some e
  | k + 1, .forallE _ b m => if m.pw.isNever then peelNeverPis k b else none
  | _ + 1, _ => none

/-- The number of arguments of an application spine. -/
def numArgs : Expr → Nat
  | .app f _ => numArgs f + 1
  | _ => 0

end Expr

/-- The zero-ness datum of the sort of a *residual type*: a `Sort u`
residual says the type inhabits `Sort u`.  (A ∀ residual would mean
the applied head is a function, not a type — unreachable on
well-typed input, and unknown here.) -/
def residualPW : Option Expr → Option PropWhen
  | some (.sort u) => some (Level.zeronessOf u)
  | _ => none

/-- The datum of a type-former application's *head* at `n` arguments:
a constant head reads its stored type (level-instantiated), an fvar
head its declared type; the residual after `n` syntactic binders is
read by `residualPW`. -/
def headTypePW (find? : Name → Option ConstantInfo) : Expr → Nat →
    Option PropWhen
  | .const I us, n =>
    match find? I with
    | some ci =>
      if ci.isTowerEntry then none else
      let cv := ci.toConstantVal
      if us.length = cv.levelParams.length then
        (residualPW (cv.type.peelNeverPis n)).map
          (Level.substPW cv.levelParams us)
      else none
    | none => none
  | .fvar _ ty, n => residualPW (ty.peelNeverPis n)
  | _, _ => none

/-- The zero-ness datum of the sort of the *type* `T` ("is `T` a
proposition?"), read off `T`'s head symbol and the annotations: a ∀
carries it on its binder (`(forall-cod)`); a sort's sort is never zero;
a constant- or fvar-headed type-former application reads the head's
stored/declared type, peels the arity syntactically and reads the
residual, level-instantiated for a constant.  `none` = unknown. -/
def typeSortPW (find? : Name → Option ConstantInfo) (T : Expr) :
    Option PropWhen :=
  match T with
  | .forallE _ _ m => some m.pw
  | .sort _ => some .never
  | T => headTypePW find? T.getAppFn T.numArgs

/-- The datum of a term's *head* (any arity): a constant head answers
from its stored type (prop-ness is invariant under application), an
fvar head from its declared type; sorts, ∀s and literals are never
proofs. -/
def headProofPW (find? : Name → Option ConstantInfo) : Expr →
    Option PropWhen
  | .const c us =>
    match find? c with
    | some ci =>
      if ci.isTowerEntry then none else
      let cv := ci.toConstantVal
      if us.length = cv.levelParams.length then
        (typeSortPW find? cv.type).map (Level.substPW cv.levelParams us)
      else none
    | none => none
  | .fvar _ ty => typeSortPW find? ty
  | .sort _ | .forallE .. | .lit _ => some .never
  | _ => none

/-- The zero-ness datum of the sort of the *type* of `a` ("is `a` a
proof?"), read off `a`'s head symbol at any arity: a constant or fvar
head answers from its stored/declared type; an unapplied λ answers from
its own datum (the zero-ness of the sort of the body's type,
`(lam-cod-leaf)`); sorts, ∀s and literals are never proofs.  `none` =
unknown. -/
def proofPW (find? : Name → Option ConstantInfo) (a : Expr) :
    Option PropWhen :=
  match a with
  | .lam _ _ m => some m.pw
  | a => headProofPW find? a.getAppFn

/-- Is the datum "always zero" — the sort is `Prop` at every
valuation? -/
@[inline] def PropWhen.isProp (pw : PropWhen) : Bool :=
  pw == (.ifAllZero [])

/-- **Definitely not a proof** (the no arm): the datum is known and is
not always-zero. -/
def notProofFast (find? : Name → Option ConstantInfo) (a : Expr) : Bool :=
  match proofPW find? a with
  | some pw => !pw.isProp
  | none => false

/-- **Definitely a proof** (the yes arm): the datum is known and
always-zero. -/
def isProofFast (find? : Name → Option ConstantInfo) (a : Expr) : Bool :=
  match proofPW find? a with
  | some pw => pw.isProp
  | none => false

end ConLeche

end -- original EOF public section of ConLeche.Kernel.PropRead
/- END exact source origin ConLeche.Kernel.PropRead -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Names -/
-- Bundled origin 08, header line 1: module

-- Bundled origin 08, header line 3: public import ConLeche.Kernel.Env

@[expose] public section

/-!
# Basis names

The reserved names of the pinned basis blocks (see `ConLeche.Kernel.Basis`).
-/

namespace ConLeche

open Name (anonymous)

/-- The name of the basis equality type. -/
def eqName : Name := anonymous |>.str "Eq"

/-- The name of the basis equality constructor. -/
def eqReflName : Name := eqName |>.str "refl"

/-- The name `Nat`. -/
def natName : Name := anonymous |>.str "Nat"

/-- The name `Nat.zero`. -/
def natZeroName : Name := natName |>.str "zero"

/-- The name `Nat.succ`. -/
def natSuccName : Name := natName |>.str "succ"

def emptyName : Name := anonymous |>.str "Empty"

/-- The name of the pinned `False` basis type (task #181): the
zero-constructor `Prop`, pinned like `Empty` so that the consistency
corollary about `False` needs no hypothesis about how a stream declares
it. -/
def falseName : Name := anonymous |>.str "False"

/-- The name of the basis quotient type. -/
def quotName : Name := anonymous |>.str "Quot"

/-- The name of the basis quotient constructor. -/
def quotMkName : Name := quotName |>.str "mk"

/-- The name of the basis quotient lift eliminator. -/
def quotLiftName : Name := quotName |>.str "lift"

/-- The name of the basis quotient induction eliminator. -/
def quotIndName : Name := quotName |>.str "ind"

/-- The name of the basis quotient soundness axiom. -/
def quotSoundName : Name := quotName |>.str "sound"

/-! The names of the string-literal support constants (see
`strLitSupported` in `ConLeche.Kernel.Core`).  These are *not* basis
names — the constants are ordinary stream-installed declarations
(inductive blocks and plain definitions); the names are
pinned only so that a string literal knows what it unfolds to
(`strLitToConstructor`), exactly like the `Nat` literal names above. -/

/-- The name `String`. -/
def stringName : Name := anonymous |>.str "String"

/-- The name `String.ofList`. -/
def stringOfListName : Name := stringName.str "ofList"

/-- The name `List`. -/
def listName : Name := anonymous |>.str "List"

/-- The name `List.nil`. -/
def listNilName : Name := listName.str "nil"

/-- The name `List.cons`. -/
def listConsName : Name := listName.str "cons"

/-- The name `Char`. -/
def charName : Name := anonymous |>.str "Char"

/-- The name `And`: the one propositional structure whose recursor is
rescued on a stuck proof (`majorToCtor`'s `And` branch,
`ConLeche/Kernel/Core.lean`, gated by `andRescueSlots`).  `And` is
pinned (`andPin`, `ConLeche/Kernel/Basis/And.lean`): a record that
declares one of its names and is not the toolchain's block is rejected
(`andPinOk`), the matching block installs through the ordinary
installer, and the built-in prelude supplies it to a stream that does
not declare it — so the name always denotes the toolchain's `And` and
the rescue is always available.  (The rescue's soundness does not rest
on the pin: its certificate is proof irrelevance.) -/
def andName : Name := anonymous |>.str "And"

/-- The name `Char.ofNat`. -/
def charOfNatName : Name := charName.str "ofNat"

/-- Names reserved for the pinned basis blocks; no other declaration
may use them. -/
def reservedBasisNames : List Name :=
  [eqName, eqReflName, eqName.str "rec",
   natName, natZeroName, natSuccName, natName.str "rec",
   emptyName, emptyName.str "rec",
   falseName, falseName.str "rec",
   quotName, quotMkName, quotLiftName, quotIndName, quotSoundName]

/-! ## The tolerated axiom

`sorryAx` is the one axiom the checker tolerates as a *declaration*:
an export declares it whenever the module it came from mentions
`sorry`, whether or not anything uses it, so a stream that merely
DECLARES it must not be turned away.  Its record installs nothing —
there is no set model for `∀ (α : Sort u), Bool → α` and there cannot
be one — and therefore any USE of it is a positively detected
unsupported feature: a decline, at the record that uses it
(`unknownConstError`, `ConLeche/Kernel/Core.lean`).  The name lives
here, at the bottom of the kernel, because the decline is decided
where a constant fails to resolve — inside the inference body. -/

/-- The name `sorryAx`. -/
def sorryAxName : Name := anonymous |>.str "sorryAx"

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Names
/- END exact source origin ConLeche.Kernel.Basis.Names -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Builder -/
-- Bundled origin 09, header line 1: module

-- Bundled origin 09, header line 3: public import ConLeche.Kernel.Basis.Names

@[expose] public section

/-!
# A tiny builder for the hand-written raw pins

The pinned basis blocks, the standard-axiom prerequisite families and
the compiler-trust pins are all *raw* `ConstantInfo`s: exactly what an
export carries for them, which is exactly the toolchain's own
`Init.Prelude` declaration — binder names and infos
are not part of an `Expr` (task #205; `piI`/`lmI` mark where the
signature says `{…}`, for the reader), the `pw` datum at the parse
placeholder `.never` — and every install-computed recursor-rule
field at its parse placeholder (`ctorParams := 0`, `fire := .inert`).

Written out with `ConLeche.Expr`'s constructors and `Name.str` chains,
one such declaration is a single unreadable line.  The helpers below —
`pi`/`piI`/`piA`, `lm`/`lmI`, `bv`, `cnst`, `srt`, `ap2`…`ap4` — are a
one-to-one, non-abbreviating renaming of those constructors at the
*raw* binder annotations, so a reader can line the pin up against
`Init.Prelude` binder by binder and index by index.  They introduce no
new notion: every one of them is a `def` whose body is a single `Expr`
constructor application.

The annotated forms are NOT written here: they are computed from these
raw pins by the checker's own annotation pass at elaboration time
(`#annotate_basis`, `ConLeche/Kernel/BasisGen.lean`).
-/

namespace ConLeche

/-! The raw-pin builder: `Expr` constructors under the raw binder
annotations.  Opened by the pin modules (`ConLeche/Kernel/Basis/*`,
`ConLeche/Kernel/StdAxioms.lean`, `ConLeche/Kernel/TrustAxioms.lean`). -/

namespace BasisDSL

/-- A top-level (single-component) name: `bn "Eq"` is `Eq`. -/
def bn (s : String) : Name := .str .anonymous s

/-- The universe parameter `u` — every basis block's first one. -/
def uN : Name := bn "u"

/-- The universe parameter `u`, as a level. -/
def u : Level := .param uN

/-- The universe parameter `v` (`Quot.lift`'s target sort). -/
def vN : Name := bn "v"

/-- The universe parameter `v`, as a level. -/
def v : Level := .param vN

/-- The universe parameter `u_1` — the motive sort the exporter names
for a recursor whose type former already spends `u`. -/
def u1N : Name := bn "u_1"

/-- The universe parameter `u_1`, as a level. -/
def u1 : Level := .param u1N

/-- A bound variable, by de Bruijn index. -/
def bv (i : Nat) : Expr := .bvar i

/-- `Sort u`. -/
def srt (u : Level) : Expr := .sort u

/-- `Prop` = `Sort 0`. -/
def prop : Expr := .sort .zero

/-- `Type` = `Sort 1`. -/
def type1 : Expr := .sort (.succ .zero)

/-- A constant, at the given universe arguments. -/
def cnst (n : Name) (us : List Level := []) : Expr := .const n us

/-! **Binder names and binder infos are for the reader only** (tasks
#203/#205).  `Expr` carries neither (task #205: the official kernel's
equality and hash ignore both, so the fields were dropped outright), so
`pi "a"`/`piI "α"`/`lm`/`lmI` take the `Init.Prelude` spelling purely
so a reader can line the pin up binder by binder; `piI`/`lmI` mark
where the signature says `{…}`.  All five build the same node shape. -/

/-- `∀ (x : ty), body` — an explicit binder (`x` documents the
`Init.Prelude` spelling). -/
def pi (_x : String) (ty body : Expr) : Expr :=
  .forallE ty body ⟨.never⟩

/-- `∀ {x : ty}, body` — an implicit binder in `Init.Prelude` (the
same node as `pi`; the braces are for the reader). -/
def piI (_x : String) (ty body : Expr) : Expr :=
  .forallE ty body ⟨.never⟩

/-- `∀ (_ : ty), body` — an anonymous explicit binder (`ty → body`). -/
def piA (ty body : Expr) : Expr :=
  .forallE ty body ⟨.never⟩

/-- `fun (x : ty) => body` — an explicit binder (name for the reader). -/
def lm (_x : String) (ty body : Expr) : Expr :=
  .lam ty body ⟨.never⟩

/-- `fun {x : ty} => body` — an implicit binder in `Init.Prelude` (the
same node as `lm`). -/
def lmI (_x : String) (ty body : Expr) : Expr :=
  .lam ty body ⟨.never⟩

/-- Binary application. -/
def ap2 (f a b : Expr) : Expr := .app (.app f a) b

/-- Ternary application. -/
def ap3 (f a b c : Expr) : Expr := .app (.app (.app f a) b) c

/-- Quaternary application. -/
def ap4 (f a b c d : Expr) : Expr := .app (.app (.app (.app f a) b) c) d

/-- A raw iota rule: the install-computed fields (`ctorParams`,
`fire`, `k`, `eta`, `paramsBlind`) at their parse placeholders, which
is what the exporter emits and what `#annotate_basis` recomputes. -/
def rule (ctor : Name) (nfields : Nat) (rhs : Expr) : RecRule :=
  ⟨ctor, nfields, 0, .inert, rhs, false, false, false⟩

end BasisDSL

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Builder
/- END exact source origin ConLeche.Kernel.Basis.Builder -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Eq -/
-- Bundled origin 10, header line 1: module

-- Bundled origin 10, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `Eq` basis block

The raw pin — the `Eq` block exactly as an export carries it: the
toolchain's `Init.Prelude` declaration at the parser's raw binder
annotations.  The *annotated*
forms (`eqA`, `eqReflA`, `eqRecA`) are computed from these by the
checker's own annotation pass at elaboration time; see
`ConLeche/Kernel/BasisA.lean`.
-/

namespace ConLeche

open BasisDSL

/-- `Eq.{u} {α : Sort u} : α → α → Prop`. -/
def eqRaw : ConstantInfo :=
  .indInfo ⟨eqName, [uN],
    piI "α" (srt u) <|
    pi "a" (bv 0) <|
    pi "b" (bv 1) prop⟩
    { ruleK := true, all := [eqName], nparams := 2, ctors := [eqReflName] }

/-- `Eq.refl.{u} {α : Sort u} (a : α) : Eq α a a`. -/
def eqReflRaw : ConstantInfo :=
  .ctorInfo ⟨eqReflName, [uN],
    piI "α" (srt u) <|
    pi "a" (bv 0) <|
    ap3 (cnst eqName [u]) (bv 1) (bv 0) (bv 0)⟩
    2 0

/-- The motive of `Eq.rec`: `∀ (b : α) (t : Eq α a b), Sort u_1`, in
the `α`/`a` binder context (`α` is `#1`, `a` is `#0` at its head). -/
def eqRecMotive : Expr :=
  pi "b" (bv 1) <|
  pi "t" (ap3 (cnst eqName [u]) (bv 2) (bv 1) (bv 0)) (srt u1)

/-- `Eq.rec.{u_1, u} {α : Sort u} {a : α} {motive : ∀ b, Eq α a b → Sort u_1}
(refl : motive a (Eq.refl α a)) {b : α} (t : Eq α a b) : motive b t`. -/
def eqRecRaw : ConstantInfo :=
  .recInfo ⟨eqName.str "rec", [u1N, uN],
    piI "α" (srt u) <|
    piI "a" (bv 0) <|
    piI "motive" eqRecMotive <|
    pi "refl" (ap2 (bv 0) (bv 1) (ap2 (cnst eqReflName [u]) (bv 2) (bv 1))) <|
    piI "b" (bv 3) <|
    pi "t" (ap3 (cnst eqName [u]) (bv 4) (bv 3) (bv 0)) <|
    ap2 (bv 3) (bv 1) (bv 0)⟩
    5 4
    [rule eqReflName 0 <|
      lmI "α" (srt u) <|
      lm "a" (bv 0) <|
      lm "motive" eqRecMotive <|
      lm "refl" (ap2 (bv 0) (bv 1) (ap2 (cnst eqReflName [u]) (bv 2) (bv 1))) <|
      bv 0]

/-- The pinned `Eq` basis block, in install order. -/
def eqBasis : List ConstantInfo := [eqRaw, eqReflRaw, eqRecRaw]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Eq
/- END exact source origin ConLeche.Kernel.Basis.Eq -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Nat -/
-- Bundled origin 11, header line 1: module

-- Bundled origin 11, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `Nat` basis block

The raw pin — the `Nat` block exactly as an export carries it: the
toolchain's `Init.Prelude` declaration at the parser's raw binder
annotations.  The *annotated*
forms (`natA`, …) are computed from these by the checker's own
annotation pass at elaboration time; see `ConLeche/Kernel/BasisA.lean`.
-/

namespace ConLeche

open BasisDSL

/-- The type `Nat`, as a closed constant. -/
def natT : Expr := cnst natName

/-- `Nat : Type`. -/
def natRaw : ConstantInfo :=
  .indInfo ⟨natName, [], type1⟩ { all := [natName], ctors := [natZeroName, natSuccName] }

/-- `Nat.zero : Nat`. -/
def natZeroRaw : ConstantInfo :=
  .ctorInfo ⟨natZeroName, [], natT⟩ 0 0

/-- `Nat.succ (n : Nat) : Nat`. -/
def natSuccRaw : ConstantInfo :=
  .ctorInfo ⟨natSuccName, [], pi "n" natT natT⟩ 0 1

/-- The motive of `Nat.rec`: `∀ (t : Nat), Sort u`. -/
def natRecMotive : Expr := pi "t" natT (srt u)

/-- The successor minor premise of `Nat.rec`, in the `motive`/`zero`
binder context: `∀ (n : Nat), motive n → motive (Nat.succ n)`. -/
def natRecSucc : Expr :=
  pi "n" natT <|
  pi "n_ih" (.app (bv 2) (bv 0)) <|
  .app (bv 3) (.app (cnst natSuccName) (bv 1))

/-- `Nat.rec.{u} {motive : Nat → Sort u} (zero : motive Nat.zero)
(succ : ∀ n, motive n → motive n.succ) (t : Nat) : motive t`. -/
def natRecRaw : ConstantInfo :=
  .recInfo ⟨natName.str "rec", [uN],
    piI "motive" natRecMotive <|
    pi "zero" (.app (bv 0) (cnst natZeroName)) <|
    pi "succ" natRecSucc <|
    pi "t" natT (.app (bv 3) (bv 0))⟩
    3 3
    [rule natZeroName 0 <|
      lm "motive" natRecMotive <|
      lm "zero" (.app (bv 0) (cnst natZeroName)) <|
      lm "succ" natRecSucc <|
      bv 1,
     rule natSuccName 1 <|
      lm "motive" natRecMotive <|
      lm "zero" (.app (bv 0) (cnst natZeroName)) <|
      lm "succ" natRecSucc <|
      lm "n" natT <|
      ap2 (bv 1) (bv 0) (ap4 (cnst (natName.str "rec") [u]) (bv 3) (bv 2) (bv 1) (bv 0))]

/-- The pinned `Nat` basis block, in install order. -/
def natBasis : List ConstantInfo := [natRaw, natZeroRaw, natSuccRaw, natRecRaw]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Nat
/- END exact source origin ConLeche.Kernel.Basis.Nat -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Empty -/
-- Bundled origin 12, header line 1: module

-- Bundled origin 12, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `Empty` basis block

The raw pin — the `Empty` block exactly as an export carries it (no
constructors, hence no iota rules): the toolchain's `Init.Prelude`
declaration at the parser's raw binder annotations.  The *annotated* forms (`emptyA`, `emptyRecA`) are
computed from these by the checker's own annotation pass at
elaboration time; see `ConLeche/Kernel/BasisA.lean`.
-/

namespace ConLeche

open BasisDSL

/-- `Empty : Type`. -/
def emptyRaw : ConstantInfo :=
  .indInfo ⟨emptyName, [], type1⟩ { all := [emptyName] }

/-- `Empty.rec.{u} (motive : Empty → Sort u) (t : Empty) : motive t`.
The exporter emits the motive as an *explicit* binder here (there is
no major premise to infer it from). -/
def emptyRecRaw : ConstantInfo :=
  .recInfo ⟨emptyName.str "rec", [uN],
    pi "motive" (pi "t" (cnst emptyName) (srt u)) <|
    pi "t" (cnst emptyName) (.app (bv 1) (bv 0))⟩
    1 1 []

/-- The pinned `Empty` basis block, in install order. -/
def emptyBasis : List ConstantInfo := [emptyRaw, emptyRecRaw]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Empty
/- END exact source origin ConLeche.Kernel.Basis.Empty -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.False -/
-- Bundled origin 13, header line 1: module

-- Bundled origin 13, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `False` basis block (task #181)

The raw pin — the `False` block exactly as an export carries it: the
toolchain's `Init.Prelude` declaration, no constructors, hence no iota
rules, at the parser's raw binder annotations.  It is the `Empty` pin
(`ConLeche/Kernel/Basis/Empty.lean`) one universe down: `False : Prop`
where `Empty : Type`, and `False.rec` eliminates into every `Sort u`
exactly as `Empty.rec` does (the official kernel lets a
zero-constructor `Prop` eliminate large).

**Why a pin, when the direct sum route installs any zero-constructor
inductive natively (task #175, `n ≠ 1`)?**  So that the consistency
corollary about `False` — `no_proof_of_False_pure`, the statement the
project exists to make — carries no hypothesis about how the stream
declared `False`.  A pinned name cannot be redeclared (the frontend
matches the incoming block against this pin and the recognisers reject
reserved names), so "no constant of type `False`" is a theorem about
the accepted environment alone, exactly as for `Empty`.  The *value*
is the empty set in both cases; `False`'s lives in `Prop`, where the
empty set is the false proposition.

The *annotated* forms (`falseA`, `falseRecA`) are computed from these
by the checker's own annotation pass at elaboration time; see
`ConLeche/Kernel/BasisA.lean`.
-/

namespace ConLeche

open BasisDSL

/-- `False : Prop`. -/
def falseRaw : ConstantInfo :=
  .indInfo ⟨falseName, [], prop⟩ { all := [falseName] }

/-- `False.rec.{u} (motive : False → Sort u) (t : False) : motive t`.
The exporter emits the motive as an *explicit* binder here (there is
no major premise to infer it from), as for `Empty.rec`. -/
def falseRecRaw : ConstantInfo :=
  .recInfo ⟨falseName.str "rec", [uN],
    pi "motive" (pi "t" (cnst falseName) (srt u)) <|
    pi "t" (cnst falseName) (.app (bv 1) (bv 0))⟩
    1 1 []

/-- The pinned `False` basis block, in install order. -/
def falseBasis : List ConstantInfo := [falseRaw, falseRecRaw]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.False
/- END exact source origin ConLeche.Kernel.Basis.False -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Quot -/
-- Bundled origin 14, header line 1: module

-- Bundled origin 14, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `Quot` basis block

Lean's kernel quotient bundle, pinned as an installed basis block:
`Quot` as a stored inductive with the single constructor `Quot.mk`,
the eliminators `Quot.lift`/`Quot.ind` as stored recursors with one
synthetic rule each (applying the lift/ind slot to the packed
element), and `Quot.sound` as a stored axiom (true in the set model).

The raw pins below match the exporter's `quot` records (and
`Quot.sound`'s `axiom` record) verbatim; the *annotated* forms
(`quotA`, …) are computed from them by the checker's own annotation
pass at elaboration time; see `ConLeche/Kernel/BasisA.lean`.
-/

namespace ConLeche

open BasisDSL

/-- The relation argument's type in the `α` binder context:
`α → α → Prop`. -/
def quotRel : Expr := piA (bv 0) (piA (bv 1) prop)

/-- `Quot.{u} {α : Sort u} (r : α → α → Prop) : Sort u`. -/
def quotRaw : ConstantInfo :=
  .indInfo ⟨quotName, [uN],
    piI "α" (srt u) <|
    pi "r" quotRel (srt u)⟩ {}

/-- `Quot.mk.{u} {α : Sort u} (r : α → α → Prop) (a : α) : Quot α r`. -/
def quotMkRaw : ConstantInfo :=
  .ctorInfo ⟨quotMkName, [uN],
    piI "α" (srt u) <|
    pi "r" quotRel <|
    pi "a" (bv 1) (ap2 (cnst quotName [u]) (bv 2) (bv 1))⟩
    2 1

/-- `Quot.lift`'s function slot, in the `α`/`r`/`β` context: `α → β`. -/
def quotLiftF : Expr := pi "a" (bv 2) (bv 1)

/-- `Quot.lift`'s coherence slot, in the `α`/`r`/`β`/`f` context:
`∀ a b, r a b → f a = f b`. -/
def quotLiftH : Expr :=
  pi "a" (bv 3) <|
  pi "b" (bv 4) <|
  pi "a" (ap2 (bv 4) (bv 1) (bv 0)) <|
  ap3 (cnst eqName [v]) (bv 4) (.app (bv 3) (bv 2)) (.app (bv 3) (bv 1))

/-- `Quot.lift.{u, v} {α : Sort u} {r : α → α → Prop} {β : Sort v}
(f : α → β) (h : ∀ a b, r a b → f a = f b) (q : Quot α r) : β`. -/
def quotLiftRaw : ConstantInfo :=
  .recInfo ⟨quotLiftName, [uN, vN],
    piI "α" (srt u) <|
    piI "r" quotRel <|
    piI "β" (srt v) <|
    pi "f" quotLiftF <|
    pi "a" quotLiftH <|
    pi "a" (ap2 (cnst quotName [u]) (bv 4) (bv 3)) (bv 3)⟩
    5 5
    [rule quotMkName 1 <|
      lm "α" (srt u) <|
      lm "r" quotRel <|
      lm "β" (srt v) <|
      lm "f" quotLiftF <|
      lm "h" quotLiftH <|
      lm "a" (bv 4) (.app (bv 2) (bv 0))]

/-- `Quot.ind`'s motive slot, in the `α`/`r` context:
`Quot α r → Prop`. -/
def quotIndMotive : Expr :=
  pi "a" (ap2 (cnst quotName [u]) (bv 1) (bv 0)) prop

/-- `Quot.ind`'s minor premise, in the `α`/`r`/`β` context:
`∀ a, β (Quot.mk α r a)`. -/
def quotIndMk : Expr :=
  pi "a" (bv 2) <|
  .app (bv 1) (ap3 (cnst quotMkName [u]) (bv 3) (bv 2) (bv 0))

/-- `Quot.ind.{u} {α : Sort u} {r : α → α → Prop} {β : Quot α r → Prop}
(mk : ∀ a, β (Quot.mk α r a)) (q : Quot α r) : β q`. -/
def quotIndRaw : ConstantInfo :=
  .recInfo ⟨quotIndName, [uN],
    piI "α" (srt u) <|
    piI "r" quotRel <|
    piI "β" quotIndMotive <|
    pi "mk" quotIndMk <|
    pi "q" (ap2 (cnst quotName [u]) (bv 3) (bv 2)) (.app (bv 2) (bv 0))⟩
    4 4
    [rule quotMkName 1 <|
      lm "α" (srt u) <|
      lm "r" quotRel <|
      lm "β" quotIndMotive <|
      lm "mk" quotIndMk <|
      lm "a" (bv 3) (.app (bv 1) (bv 0))]

/-- `Quot.sound.{u} {α : Sort u} {r : α → α → Prop} {a b : α} :
r a b → Quot.mk α r a = Quot.mk α r b`. -/
def quotSoundRaw : ConstantInfo :=
  .axiomInfo ⟨quotSoundName, [uN],
    piI "α" (srt u) <|
    piI "r" quotRel <|
    piI "a" (bv 1) <|
    piI "b" (bv 2) <|
    piA (ap2 (bv 2) (bv 1) (bv 0)) <|
    ap3 (cnst eqName [u])
      (ap2 (cnst quotName [u]) (bv 4) (bv 3))
      (ap3 (cnst quotMkName [u]) (bv 4) (bv 3) (bv 2))
      (ap3 (cnst quotMkName [u]) (bv 4) (bv 3) (bv 1))⟩

/-- The pinned `Quot` basis block, in install order. -/
def quotBasis : List ConstantInfo :=
  [quotRaw, quotMkRaw, quotLiftRaw, quotIndRaw, quotSoundRaw]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Quot
/- END exact source origin ConLeche.Kernel.Basis.Quot -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.And -/
-- Bundled origin 15, header line 1: module

-- Bundled origin 15, header line 3: public import ConLeche.Kernel.Basis.Builder

@[expose] public section

/-!
# The pinned `And` block

The raw pin — the `And` block exactly as an export carries it: the
toolchain's `Init.Prelude` structure

    structure And (a b : Prop) : Prop where
      intro :: (left : a) (right : b)

at the parser's raw binder annotations (its projection functions
`And.left`/`And.right` are ordinary definition records of their own).

**Why `And` is pinned, and how that differs from the basis blocks.**
The checker has code for "the" `And`: the stuck-proof rescue
(`majorToCtor`'s `And` branch, `ConLeche/Kernel/Core.lean`) fabricates
`And.intro a b h.1 h.2` for an `And.rec` whose major is a proof that
does not reduce to a constructor.  That branch must be available in
every accepted run, so the name must denote the toolchain's `And`.
Unlike `Eq`, `Nat`, `Empty` and `False`, `And` has no hand-written set
model and is not installed from literals: the fold only RECOGNISES the
block (`andPinOk`, `ConLeche/Kernel/Basis.lean`) and rejects any other
record claiming one of its three names; the matching block then goes
through the ordinary inductive installer, which stores its projection
table like any structure's.  The rescue's soundness needs none of this
(its certificate is proof irrelevance, sound whatever `And` is); the
pin is what makes it *present*.
-/

namespace ConLeche

open BasisDSL

/-- The name `And.intro`. -/
def andIntroName : Name := andName.str "intro"

/-- The name `And.rec`. -/
def andRecName : Name := andName.str "rec"

/-- `And (a b : Prop) : Prop`. -/
def andRaw : ConstantInfo :=
  .indInfo ⟨andName, [], pi "a" prop (pi "b" prop prop)⟩
    { all := [andName], nparams := 2, ctors := [andIntroName] }

/-- `And.intro {a b : Prop} (left : a) (right : b) : And a b`. -/
def andIntroRaw : ConstantInfo :=
  .ctorInfo ⟨andIntroName, [],
    piI "a" prop <|
    piI "b" prop <|
    pi "left" (bv 1) <|
    pi "right" (bv 1) <|
    ap2 (cnst andName) (bv 3) (bv 2)⟩
    2 2

/-- The motive of `And.rec`: `And a b → Sort u`, in the `a`/`b` binder
context (`a` is `#1`, `b` is `#0`). -/
def andRecMotive : Expr :=
  pi "t" (ap2 (cnst andName) (bv 1) (bv 0)) (srt u)

/-- The minor premise of `And.rec`:
`(left : a) → (right : b) → motive (And.intro left right)`, in the
`a`/`b`/`motive` binder context. -/
def andRecMinor : Expr :=
  pi "left" (bv 2) <|
  pi "right" (bv 2) <|
  .app (bv 2) (ap4 (cnst andIntroName) (bv 4) (bv 3) (bv 1) (bv 0))

/-- `And.rec.{u} {a b : Prop} {motive : And a b → Sort u}
(intro : (left : a) → (right : b) → motive ⟨left, right⟩)
(t : And a b) : motive t`. -/
def andRecRaw : ConstantInfo :=
  .recInfo ⟨andRecName, [uN],
    piI "a" prop <|
    piI "b" prop <|
    piI "motive" andRecMotive <|
    pi "intro" andRecMinor <|
    pi "t" (ap2 (cnst andName) (bv 3) (bv 2)) <|
    .app (bv 2) (bv 0)⟩
    4 4
    [rule andIntroName 2 <|
      lmI "a" prop <|
      lmI "b" prop <|
      lmI "motive" andRecMotive <|
      lm "intro" andRecMinor <|
      lm "left" (bv 3) <|
      lm "right" (bv 3) <|
      ap2 (bv 2) (bv 1) (bv 0)]

/-- The pinned `And` block, in the order an export lists it. -/
def andPin : List ConstantInfo := [andRaw, andIntroRaw, andRecRaw]

/-- The names the pinned `And` block declares: no other record may
declare any of them (`andPinOk`). -/
def andPinNames : List Name := [andName, andIntroName, andRecName]

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.And
/- END exact source origin ConLeche.Kernel.Basis.And -/

/- BEGIN exact source origin ConLeche.Kernel.Canon -/
-- Bundled origin 16, header line 1: module

/-
Source-only compact reference: optional packed-field laws/memo equality or
lockstep canonical comparisons are omitted. Retained logical declarations
are unchanged. Historical comments describing removed implementations refer
to the full upstream source. Native compiler substitutions differ; no
native speedup or whole cached-checker compatibility is claimed.
-/

-- Bundled origin 16, header line 11: public import ConLeche.Kernel.Env

@[expose] public section

/-!
# The level-parameter canonical form the pinned blocks are matched up to

A stream's `Nat` block and the checker's pinned one are the same
declaration when they agree up to the names Lean's exporter picks
freely: binder names, binder annotations and level-parameter names.
This module is that canonical form and the lockstep comparisons built
on it.

It sits in the KERNEL because the matching does (task #293): the
decoder emits the file's records and nothing else, and it is
`checkDecl` that recognises a block as one of the five pinned basis
blocks, and a `#QUOT` record (or the `Quot.sound` axiom record) as the
pinned quotient package's.  Until then this lived in
`ConLeche/Frontend/Export.lean`, beside the parser that did the
matching.
-/

namespace ConLeche

/-- Rename level parameters (for basis-block matching up to
level-parameter names). -/
def canonLevel (m : Name → Name) : Level → Level
  | .zero => .zero
  | .succ u => .succ (canonLevel m u)
  | .max u v => .max (canonLevel m u) (canonLevel m v)
  | .imax u v => .imax (canonLevel m u) (canonLevel m v)
  | .param n => .param (m n)

/-- Erase binder names *and binder annotations* and rename level
parameters: the alpha/renaming canonical form used to match a parsed
inductive block against a pinned basis block (Lean's exports use
auto-bound universe names and hygienic binder names, both semantically
irrelevant).

Task #142, pin-side normalization: the parser already maps every
stream binder to `.default`, and both sides of every
`ConstantInfo.canon` comparison go through here, so erasing the
annotation here is what kept the two sides consistent while the pinned
literals still carried the real `BinderInfo`s of their `Init.Prelude`
signatures.  Since task #203 the pin builder
(`ConLeche/Kernel/Basis/Builder.lean`) emits `.anonymous` at `.default`
and the parser emits `.anonymous` too, so the name/annotation erasure
here is the identity on both sides; what this canonical form still
*does* is rename level parameters and reset `pw` (the pin side is
annotated, the stream side is at the parse placeholder). -/
def canonExpr (m : Name → Name) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar idx ty => .fvar idx (canonExpr m ty)
  | .sort u => .sort (canonLevel m u)
  | .const n us => .const n (us.map (canonLevel m))
  | .app f a => .app (canonExpr m f) (canonExpr m a)
  | .lam ty b _ => .lam (canonExpr m ty) (canonExpr m b) ⟨.never⟩
  | .forallE ty b _ =>
      .forallE (canonExpr m ty) (canonExpr m b) ⟨.never⟩
  | .letE ty v b => .letE (canonExpr m ty) (canonExpr m v)
      (canonExpr m b)
  | .lit l => .lit l
  | .proj s i e => .proj s i (canonExpr m e)

/-- The level-parameter renaming a constant's own parameter list
induces: the `i`-th parameter becomes `⟨i⟩`, anything else is left
alone. -/
def canonNameMap (ps : List Name) : Name → Name := fun n =>
  match ps.findIdx? (fun p => p == n) with
  | some i => .num .anonymous i
  | none => n

/-- Canonical form of a constant's common data (name kept, level
parameters numbered, type renamed). -/
def ConstantVal.canon (cv : ConstantVal) : ConstantVal :=
  { cv with
    levelParams := (List.range cv.levelParams.length).map (.num .anonymous ·),
    type := canonExpr (canonNameMap cv.levelParams) cv.type }

/-- Canonical form of a stored constant for basis matching. -/
def ConstantInfo.canon (ci : ConstantInfo) : ConstantInfo :=
  let ps := ci.toConstantVal.levelParams
  let m : Name → Name := canonNameMap ps
  let cv : ConstantVal := ConstantVal.canon ci.toConstantVal
  match ci with
  | .axiomInfo _ => .axiomInfo cv
  | .defnInfo _ v hint => .defnInfo cv (canonExpr m v) hint
  | .thmInfo _ v => .thmInfo cv (canonExpr m v)
  | .indInfo _ _ => .indInfo cv {}
  | .ctorInfo _ nP nF => .ctorInfo cv nP nF
  | .recInfo _ mI rP rules => .recInfo cv mI rP
      (rules.map fun r => { r with rhs := canonExpr m r.rhs })
  -- table entries never occur in parsed input; identity keeps the
  -- match total
  | .projInfo e => .projInfo e

/- Source-only optional cut: expression-lockstep-comparison. -/

/-- Two constants have the same canonical common data.  (`decide (· =
·)` is what `==` unfolds to at these `DecidableEq` types, so this is
the comparison the call sites used to spell inline.) -/
def ConstantVal.canonEq (cv cv' : ConstantVal) : Bool :=
  decide (ConstantVal.canon cv = ConstantVal.canon cv')

/- Source-only optional cut: constant-and-rule-lockstep-comparison. -/

/-- Two stored constants have the same canonical form. -/
def ConstantInfo.canonEq (ci ci' : ConstantInfo) : Bool :=
  decide (ConstantInfo.canon ci = ConstantInfo.canon ci')

/- Source-only optional cut: stored-info-lockstep-comparison. -/

/-- Two blocks are the same, member for member, up to the canonical
form. -/
def canonEqList (xs ys : List ConstantInfo) : Bool :=
  decide (xs.map ConstantInfo.canon = ys.map ConstantInfo.canon)

/- Source-only optional cut: block-lockstep-comparison. -/

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Canon
/- END exact source origin ConLeche.Kernel.Canon -/

/- BEGIN exact source origin ConLeche.Kernel.Basis -/
-- Bundled origin 17, header line 1: module

-- Bundled origin 17, header line 3: public import ConLeche.Kernel.Basis.Names
-- Bundled origin 17, header line 4: public import ConLeche.Kernel.Basis.Builder
-- Bundled origin 17, header line 5: public import ConLeche.Kernel.Basis.Eq
-- Bundled origin 17, header line 6: public import ConLeche.Kernel.Basis.Nat
-- Bundled origin 17, header line 7: public import ConLeche.Kernel.Basis.Empty
-- Bundled origin 17, header line 8: public import ConLeche.Kernel.Basis.False
-- Bundled origin 17, header line 9: public import ConLeche.Kernel.Basis.Quot
-- Bundled origin 17, header line 10: public import ConLeche.Kernel.Basis.And
-- Bundled origin 17, header line 11: public import ConLeche.Kernel.Canon

@[expose] public section

/-!
# The pinned basis inductives

The checker pins `Eq`, `Nat`, `Quot`, `Empty` and `False`
natively (hand-written set models), and pins `And` by recognition
alone (below).  The pinned declarations are the toolchain's own — the
fold compares incoming records against these (a differing block under
a pinned name is rejected, a differing quotient record declined).  One
module per pinned type under `ConLeche/Kernel/Basis/`, hand-written
against the toolchain's `Init.Prelude` through the small builder in
`Basis/Builder.lean`.

**Raw only.**  The *annotated* forms — what the installation actually
stores — are computed from these by the checker's own annotation pass
in `ConLeche/Kernel/BasisA.lean`, which therefore sits above
`ConLeche.Kernel.TypeChecker`.  This module sits below it: the kernel
core needs the raw pins (the fold matches incoming records against
them) and nothing else.
-/

namespace ConLeche

/-- The constants of one basis block, in dependency order. -/
def BasisKind.decls : BasisKind → List ConstantInfo
  | .eqK => eqBasis
  | .natK => natBasis
  | .emptyK => emptyBasis
  | .falseK => falseBasis
  | .quotK => quotBasis

/-! ## Recognising a pinned block in a stream record (task #293)

The decoder emits the file's records and nothing else, and
`preparePrelude` only reorders them, so a stream's `Nat` block reaches
`checkDecl` as an ordinary `indDecl`.  These are the two tests that
recognise it as the pinned block — the matching the parser used to do,
where it belongs.  A block under a pinned name that does NOT match is
left to the ordinary route, where the reserved-name check rejects it
(a basis redefinition is invalid input); a quotient record that does
not match its pin is a decline. -/

/-- **The basis-pin match**, with task #215's NAME pre-filter.
`ConstantInfo.canon` rebuilds the whole block as an unshared tree — on
a heavily DAG-shared block that was the frontend's single largest cost
— so a block that is not one of the four pinned ones must not reach it.
`canon` renames only *level parameters*, leaving every constant name
alone, so a block can match a pin only when its members' names are the
pin's, member for member, and that test is a handful of `Name`
comparisons. -/
def basisPinHit (block : List ConstantInfo) : Option BasisKind :=
  ([BasisKind.eqK, .natK, .emptyK, .falseK].find? fun k =>
      k.decls.map (·.name) == block.map (·.name)).filter fun k =>
    canonEqList block k.decls

/-- **The quotient-pin match**: the record is the pinned package's
constant at the slot it declares itself at.  The two are compared at
`toConstantVal`. -/
def quotPinHit (k : QuotKind) (cv : ConstantVal) : Bool :=
  ConstantVal.canonEq cv (BasisKind.quotK.decls.getD k.slot (.axiomInfo default)).toConstantVal

/-! ## The pinned `And`

`And` is recognised, not installed from literals
(`ConLeche/Kernel/Basis/And.lean`): the block that matches the pin goes
through the ordinary inductive installer.  What the pin adds is a
REJECT — a record that declares `And`, `And.intro` or `And.rec` and is
not the pinned block is invalid input, as a basis redefinition is — so
that in every accepted environment the name `And` is the toolchain's
`And` and the stuck-proof rescue that serves it (`majorToCtor`'s `And`
branch) is available.  The fold asks this of every record before its
dispatch (`annotDeclStep`, `ConLeche/Cached/Installed.lean`). -/

/-- **The `And` pin's test**: the record declares none of the pinned
`And` block's names, or it IS that block — two parameters, and equal
to `andPin` up to `ConstantInfo.canon`. -/
def andPinOk : Declaration → Bool
  | .indDecl block nP =>
    !(block.any fun c => andPinNames.contains c.name) ||
      (nP == 2 && canonEqList block andPin)
  | .axiomDecl cv | .defnDecl cv .. | .thmDecl cv .. | .opaqueDecl cv ..
  | .quotDecl _ cv => !andPinNames.contains cv.name
  | .basisDecl _ => true

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis
/- END exact source origin ConLeche.Kernel.Basis -/

/- BEGIN exact source origin ConLeche.Kernel.CoreDefs -/
-- Bundled origin 18, header line 1: module

-- Bundled origin 18, header line 3: import ConLeche.Kernel.Env
-- Bundled origin 18, header line 4: public import ConLeche.Kernel.PropRead
-- Bundled origin 18, header line 5: import ConLeche.Kernel.Level
-- Bundled origin 18, header line 6: import ConLeche.Kernel.ExprOps
-- Bundled origin 18, header line 7: public import ConLeche.Kernel.Basis

@[expose] public section

/-!
# The checker core's fuel-free helpers

The definitions of the core checker that mention no monad, no
`CoreFns` record and no fuel: the delta step and its readers
(`unfoldDefinition`, `unfoldableHead`, `headHint`, `sameConstHeads`),
the literal shapes and their guards (`natLitToConstructor`,
`natLitSupported`, `strLitToConstructor`, `strLitSupported`,
`rawNatLit?`), the certified `Nat` operations' names, recurrences,
reducts and pins (`natOpNames`, `natDivModNames`, `natOpEquations`,
`natOpResult`, `natOpStoredOk`, …), the structure-η fabrications
(`etaProjs`, `etaFabArgsE`, `andRescueSlots`), the install-time rule
bits (`recRuleBits`, `recRuleK`, `recFireComparands`),
the tower entry's readers (`ProjEntry.fireOk`, `ProjEntry.typeAt`), the
β gate (`betaGateFires`) and the annotation datum's writer
(`annotBinderMeta`).

Split out of `ConLeche/Kernel/Core.lean` at task #305 (prep): a
relational description of the core's moves — a relation over `Expr`
and `Env` — must name these without importing the executable bodies,
and every one of them is exactly what such a relation needs.  The
bodies (`whnfCoreBody`, `whnfBody`, `inferBody`, `defeqBody`,
`annotateBody`, the knot and the fuel constants) stay in `Core.lean`,
which re-exports this module, so every importer of `Core` sees the
names unchanged.  Nothing here was rewritten: the definitions keep
their names, docstrings, attributes and relative order.
-/

namespace ConLeche

/-- Is the expression headed by a stored constructor? -/
def isCtorApp (env : Env) (e : Expr) : Bool :=
  match e.getAppFn with
  | .const c _ =>
    match env.find? c with
    | some (.ctorInfo _ _ _) => true
    | _ => false
  | _ => false

/-- Is a stored inductive's result sort, at the given level
instantiation, provably nonzero (official `is_never_zero`)?  The
official kernel's structure rescue (`to_cnstr_when_structure`)
requires this of the major's type; `majorToCtor`'s structure-η
rescue mirrors it (`Sort u` at a concrete level such as `Unit`'s `1` passes, the
parameter `u` itself does not).  Read off the stored datum: the
instantiated datum is unsatisfiable exactly where the instantiated
sort is never zero. -/
def capsNeverZero (lps : List Name) (us : List Level) (caps : IndCaps) :
    Bool :=
  (Level.substPW lps us caps.sortZ).isNever

/-- Unfold the (application of a) definition at the head, one step.
`none` when the head is not an unfoldable constant.  **Theorems are
opaque to reduction**: a stored `thmInfo` never unfolds, so whether a
declaration type-checks never depends on a theorem's value — this
anticipates https://github.com/leanprover/lean4/pull/14896 (theorems
become opaque to the kernel: `is_delta` stops unfolding them).  The
one known input whose typing needs a theorem to unfold, the arena's
`subject-reduction-redex`, is rejected (an accept-subset of the
reference kernels until that PR lands). -/
def unfoldDefinition (env : Env) (e : Expr) : Option Expr :=
  match e.getAppFn with
  | .const n us =>
    match env.find? n with
    | some (.defnInfo cv value _) =>
      if us.length = cv.levelParams.length then
        some (Expr.mkAppN (value.instantiateLevelParams cv.levelParams us)
          e.getAppArgs)
      else none
    | _ => none
  | _ => none

/-- May the delta step unfold `e`'s head — is it a constant whose
stored declaration carries a value at a matching level-parameter count
(the official kernel's `is_delta`)?  This is the *decision* the lazy
delta step takes; the unfolding itself is materialized only inside the
branch that consumes it (`unfoldDefinition`), never in both slots of a
match scrutinee.  By construction
`unfoldableHead env e = (unfoldDefinition env e).isSome`. -/
def unfoldableHead (env : Env) (e : Expr) : Bool :=
  match e.getAppFn with
  | .const n us =>
    match env.find? n with
    | some (.defnInfo cv _ _) => us.length == cv.levelParams.length
    | _ => false
  | _ => false

/-- The reducibility hint of the constant at the head of `e` (`opaque`
when the head is not a stored definition — a theorem included, which
never unfolds). -/
def headHint (env : Env) (e : Expr) : ReducibilityHint :=
  match e.getAppFn with
  | .const n _ =>
    match env.find? n with
    | some (.defnInfo _ _ hint) => hint
    | _ => .opaque
  | _ => .opaque

/-- Are `a` and `b` applications of the *same* constant (the lazy delta
same-head short-circuit: try level and spine congruence before
unfolding both sides)?  Mirrors the official kernel's
`try_eq_const_app`: both sides must actually be applications. -/
def sameConstHeads : Expr → Expr → Bool
  | .app f₁ _, .app f₂ _ =>
    match f₁.getAppFn, f₂.getAppFn with
    | .const n₁ _, .const n₂ _ => n₁ == n₂
    | _, _ => false
  | _, _ => false

/-- The constructor form of a `Nat` literal, one layer:
`n + 1` becomes `Nat.succ (lit n)`, `0` becomes `Nat.zero` (the
official kernel's `natLitToConstructor`, used on recursor majors). -/
def natLitToConstructor (n : Nat) : Expr :=
  match n with
  | 0 => .const natZeroName []
  | k + 1 => .app (.const natSuccName []) (.lit (.natVal k))

/-- The stored `Nat` declaration has the expected shape. -/
def natIndOk : Option ConstantInfo → Bool
  | some (.indInfo cv _) =>
    cv.levelParams.isEmpty && cv.type == .sort (.succ .zero)
  | _ => false

/-- The stored `Nat.zero` declaration has the expected shape. -/
def natZeroOk : Option ConstantInfo → Bool
  | some (.ctorInfo cv _ _) =>
    cv.levelParams.isEmpty && cv.type == .const natName []
  | _ => false

/-- The stored `Nat.succ` declaration has the expected (annotated)
shape. -/
def natSuccOk : Option ConstantInfo → Bool
  | some (.ctorInfo cv _ _) =>
    cv.levelParams.isEmpty &&
    (match cv.type with
     | .forallE (.const c1 []) (.const c2 []) _mb =>
       c1 == natName && c2 == natName
     | _ => false)
  | _ => false

/-- Whether the environment supports `Nat` literals: `Nat`, `Nat.zero`
and `Nat.succ` are stored with exactly the expected kinds, level
parameters and (annotated) types.  Every literal code path is guarded
on this — the model interprets a literal by iterating the `Nat.succ`
value on the `Nat.zero` value, and the soundness proofs read the
declaration shapes off this guard. -/
def natLitSupported (env : Env) : Bool :=
  natIndOk (env.find? natName) && natZeroOk (env.find? natZeroName) &&
    natSuccOk (env.find? natSuccName)

/-- Do all constants referenced in `e` (including inside `fvar` type
annotations) resolve in `env`?  A `Nat` literal implicitly references
the `Nat` basis constants (and a `String` literal additionally the
string-support constants).  Checked once per declaration; keeps the
environment well-formedness invariant syntactic. -/
def Expr.constsResolve (env : Env) : Expr → Bool
  | .bvar _ | .sort _ => true
  | .lit (.natVal _) =>
    (env.find? natName).isSome && (env.find? natZeroName).isSome &&
      (env.find? natSuccName).isSome
  | .lit (.strVal _) =>
    -- a string literal implicitly references the `Nat` trio (its
    -- character numerals) and the seven string-support constants
    (env.find? natName).isSome && (env.find? natZeroName).isSome &&
      (env.find? natSuccName).isSome && (env.find? stringName).isSome &&
      (env.find? stringOfListName).isSome && (env.find? listName).isSome &&
      (env.find? listNilName).isSome && (env.find? listConsName).isSome &&
      (env.find? charName).isSome && (env.find? charOfNatName).isSome
  | .const n _ => (env.find? n).isSome
  | .fvar _ ty => ty.constsResolve env
  | .app f a => f.constsResolve env && a.constsResolve env
  | .lam ty body _ | .forallE ty body _ =>
    ty.constsResolve env && body.constsResolve env
  | .letE ty val body =>
    ty.constsResolve env && val.constsResolve env && body.constsResolve env
  | .proj s _ e => (env.find? s).isSome && e.constsResolve env

/-- Convert a `Nat`-literal major premise to constructor form, one
layer; anything else passes through. -/
def litToCtorIfNat (env : Env) : Expr → Expr
  | .lit (.natVal n) =>
    if natLitSupported env then natLitToConstructor n else .lit (.natVal n)
  | e => e

/-- A `Nat` literal reading of a whnf'd expression: literals and the
`Nat.zero` constant (the official kernel's `rawNatLitExt?`). -/
def rawNatLit? : Expr → Option Nat
  | .lit (.natVal n) => some n
  | .const c [] => if c = natZeroName then some 0 else none
  | _ => none

/-! ## String literals

A string literal unfolds on demand to `String.ofList [c₁, …, cₙ]` with
each character built by `Char.ofNat` from a `Nat` literal — the
reference kernels' `strLitToConstructor` (lean4lean `Expr.lean`, nanoda
`expr.rs`), mirrored exactly.  The names below are *pinned* like the
`Nat` literal names: the guard `strLitSupported` checks that the stored
declarations have exactly the expected (annotated) types, which is what
the model's interpretation of a string literal reads its meaning off.
A string literal in the input while the guard fails is a positively
detected unsupported feature — annotation *declines* (exit 2). -/

/-- The constructor form of a `String` literal:
`String.ofList (List.cons.{0} Char (Char.ofNat (lit c₁)) (… (List.nil.{0}
Char)))` — the official kernel's `strLitToConstructor`, spelling as in
lean4lean (`Expr.strLitToConstructor`) and nanoda
(`str_lit_to_constructor`). -/
def strLitToConstructor (s : String) : Expr :=
  .app (.const stringOfListName []) <|
    s.toList.foldr
      (init := .app (.const listNilName [.zero]) (.const charName []))
      fun c e =>
        .app (.app (.app (.const listConsName [.zero]) (.const charName []))
          (.app (.const charOfNatName []) (.lit (.natVal c.toNat)))) e

/-- The stored `String` declaration has the expected shape
(`String : Type`, no level parameters; any constant kind). -/
def stringTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      ci.toConstantVal.type == .sort (.succ .zero)
  | none => false

/-- The stored `Char` declaration has the expected shape (`Char : Type`,
no level parameters). -/
def charTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      ci.toConstantVal.type == .sort (.succ .zero)
  | none => false

/-- The stored `List` declaration has the expected (annotated) shape
`List.{p} : Type p → Type p`. -/
def listTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1) (.sort u2) _mb =>
         u1 == .succ (.param p) && u2 == .succ (.param p)
       | _ => false)
    | _ => false
  | none => false

/-- The stored `List.nil` declaration has the expected (annotated) shape
`List.nil.{p} : ∀ (α : Type p), List.{p} α`. -/
def listNilTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1) (.app (.const l1 us1) (.bvar 0)) _mb =>
         u1 == .succ (.param p) && l1 == listName && us1 == [.param p]
       | _ => false)
    | _ => false
  | none => false

/-- The stored `List.cons` declaration has the expected (annotated) shape
`List.cons.{p} : ∀ (α : Type p) (head : α) (tail : List.{p} α),
List.{p} α` (with the codomain-sort annotations the annotation pass
produces on that type). -/
def listConsTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1)
           (.forallE (.bvar 0)
             (.forallE (.app (.const l1 us1) (.bvar 1))
               (.app (.const l2 us2) (.bvar 2)) _mb3) _mb2) _mb1 =>
         u1 == .succ (.param p) && l1 == listName && l2 == listName &&
           us1 == [.param p] && us2 == [.param p]
       | _ => false)
    | _ => false
  | none => false

/-- The stored `Char.ofNat` declaration has the expected (annotated)
shape `Char.ofNat : Nat → Char`. -/
def charOfNatTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      (match ci.toConstantVal.type with
       | .forallE (.const c1 []) (.const c2 []) _mb =>
         c1 == natName && c2 == charName
       | _ => false)
  | none => false

/-- The stored `String.ofList` declaration has the expected (annotated)
shape `String.ofList : List.{0} Char → String`. -/
def stringOfListTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      (match ci.toConstantVal.type with
       | .forallE (.app (.const l1 us1) (.const c1 [])) (.const c2 []) _mb =>
         l1 == listName && us1 == [.zero] && c1 == charName &&
           c2 == stringName
       | _ => false)
  | none => false

/-- Whether the environment supports `String` literals: the `Nat`
literal guard plus `String`, `String.ofList`, `List`, `List.nil`,
`List.cons`, `Char` and `Char.ofNat` stored with exactly the expected
level parameters and (annotated) types.  Every string-literal code path
is guarded on this; the model interprets a string literal through the
values of these constants, and the soundness proofs read the
declaration shapes off this guard.  (The reference kernels only check
*existence* of `Char.ofNat` and `String.ofList`; the type pins are what
makes the interpretation well-defined, in the spirit of the `Nat`
literal guard.) -/
def strLitSupported (env : Env) : Bool :=
  natLitSupported env &&
    stringTyOk (env.find? stringName) &&
    stringOfListTyOk (env.find? stringOfListName) &&
    listTyOk (env.find? listName) &&
    listNilTyOk (env.find? listNilName) &&
    listConsTyOk (env.find? listConsName) &&
    charTyOk (env.find? charName) &&
    charOfNatTyOk (env.find? charOfNatName)

/-! ## Structural-Nat literal acceleration

The official kernel accelerates the structural `Nat` operations on
literals (GMP-backed there).  Here the fast path is *certified*: an
operation participates only when its defining recurrence equations
hold by definitional equality — checked once, at install: `checkDecl`
positively rejects a nonstandard definition under one of these names,
so *presence in the store is the certificate* (no runtime flag, no
re-checking; a reduction-time re-check would in fact livelock — the
certification's own `pred zero` equation re-enters the fast path).

The certification runs in the environment *before* the operation is
stored, on the equations with the operation's self-references replaced
by its (annotated) definition value (`Expr.substConst0`): running it
after insertion would let the operation's own just-enabled fast path
discharge its all-literal-argument equations (`pred zero ≡ zero`,
`beq zero zero ≡ true`) vacuously — accepting definitions that
disagree with the fast path on those points, which is unsound.  The
install also pins the operation's and its dependencies' types to the
expected `Nat → … → Nat`/`Bool` shapes (`natOpStoredOk`): the model
reads the operations' function-space memberships off these shapes.

The environment model carries the matching semantic clause: a stored
definition under one of these names satisfies its recurrences, from
which meta-level induction over the literal yields the computed
value.  WF-recursive operations (`div`, `mod`, `gcd`) and string
literals are deferred. -/

def natPredName : Name := natName.str "pred"
def natAddName : Name := natName.str "add"
def natSubName : Name := natName.str "sub"
def natMulName : Name := natName.str "mul"
def natPowName : Name := natName.str "pow"
def natBeqName : Name := natName.str "beq"
def natBleName : Name := natName.str "ble"
def natDivName : Name := natName.str "div"
def natModName : Name := natName.str "mod"
def natGcdName : Name := natName.str "gcd"
def natLandName : Name := natName.str "land"
def natLorName : Name := natName.str "lor"
def natXorName : Name := natName.str "xor"
def natShiftLeftName : Name := natName.str "shiftLeft"
def natShiftRightName : Name := natName.str "shiftRight"
def boolName : Name := .str .anonymous "Bool"
def boolTrueName : Name := boolName.str "true"
def boolFalseName : Name := boolName.str "false"

/-- Is `e` the constant `Bool.true` — the official kernel's
`is_constant(e, Bool.true)` (`type_checker.cpp:1097`): the name, no
universe levels. -/
def Expr.isBoolTrue : Expr → Bool
  | .const c [] => c == boolTrueName
  | _ => false

/-- The certified structural-`Nat` operations.  Six of them
(`add sub mul pow beq ble`) carry a literal fast path; `Nat.pred` is
here without one — it has no fast path (official's `reduce_nat` folds
nothing unary but `Nat.succ`), but `Nat.sub`'s recurrence
`sub x (succ y) = pred (sub x y)` names it, so its own recurrences
must be certified for `sub`'s literal fold to be sound. -/
def natOpNames : List Name :=
  [natPredName, natAddName, natSubName, natMulName, natPowName,
   natBeqName, natBleName]

/-- The WF-recursive operations with a *pinned-declaration* certified
fast path: at install, `checkDecl` compares the stream's definition
against a vendored pin of the toolchain's own (helper-unfolded)
definition by definitional equality, and then checks the pinned
`Nat.ble`-guarded characterization certificates
(`ConLeche/Kernel/NatOpPins.lean`) like theorem declarations — without
installing them.  Presence in the store is therefore again the
capability: a stored operation under one of these names has passed pin
and certificates, or the install declined.  (The name is historic:
the family started with `Nat.div`/`Nat.mod` and now covers every
pin-certified WF-recursive kernel-accelerated `Nat` operation —
`Nat.log2` left the list when its fast path did, official folding no
unary operation but `Nat.succ`.) -/
def natDivModNames : List Name :=
  [natDivName, natModName, natGcdName, natLandName, natLorName,
   natXorName, natShiftLeftName, natShiftRightName]

/-! ## The names the environment's own guards look up

`natLitSupported` and `strLitSupported` decide whether a literal may
be READ, and they decide it by looking ten fixed names up in the
store.  Three of them (`Nat`, `Nat.zero`, `Nat.succ`) are reserved
basis names, so no stream declaration can ever fill or change them;
the other seven — `String`, `String.ofList`, `List`, `List.nil`,
`List.cons`, `Char`, `Char.ofNat` — are ORDINARY stream declarations,
and a stream is free to install them (it must: that is how a stream
earns string literals).

What must not happen is a *recursor* taking one of these names.  A
recursor's name is the stream's business, so nothing else stops a block from
declaring, say, a recursor called
`List.cons` of `List.cons`'s type; consing it would flip
`strLitSupported` from `false` to `true` and a string literal would
read as one thing below the block's recursors and as another above
them.  The block install therefore refuses such a name outright
(`blockRecNamesUnreserved`, `ConLeche/Kernel/Inductives/BlockParts.lean`),
which makes both guards CONGRUENT across the recursors' cons
(`strLitSupported_consBlockRecsR`, `ConLeche/Verify/Inductives/BlockWF.lean`)
— the equation the model's reading law needs. -/

/-- The ten names the two literal guards look up: the `Nat` guard's
three and the `String` guard's seven. -/
def litGuardNames : List Name :=
  [natName, natZeroName, natSuccName,
   stringName, stringOfListName, listName, listNilName, listConsName,
   charName, charOfNatName]

/-- **A name no block RECURSOR may take**: one the pinned basis blocks
reserve, one a literal guard looks up, or one of the certified `Nat`
operations (whose presence in the store IS their certificate, so a
recursor stored under such a name would claim a capability nothing
certified).  Type formers and constructors are NOT held to this — a
stream must be able to declare `List`, `List.cons` and `Nat.add` —
which is why the block install spends this predicate on the recursors
alone and keeps `reservedBasisNames` for every declaration. -/
def reservedRecName (n : Name) : Bool :=
  reservedBasisNames.contains n || litGuardNames.contains n ||
    natOpNames.contains n || natDivModNames.contains n

/-- The operations (transitively) involved in `c`'s recurrences. -/
def natOpDeps (c : Name) : List Name :=
  if c = natPredName then [natPredName]
  else if c = natAddName then [natAddName]
  else if c = natSubName then [natPredName, natSubName]
  else if c = natMulName then [natAddName, natMulName]
  else if c = natPowName then [natAddName, natMulName, natPowName]
  else if c = natBeqName then [natBeqName]
  else if c = natBleName then [natBleName]
  else if c = natDivName then [natPredName, natSubName, natBleName, natDivName]
  else if c = natModName then [natPredName, natSubName, natBleName, natModName]
  else if c = natGcdName then [natBleName, natModName, natGcdName]
  else if c = natLandName then
    [natAddName, natMulName, natBleName, natDivName, natModName, natLandName]
  else if c = natLorName then
    [natAddName, natSubName, natMulName, natBleName, natDivName, natModName,
     natLorName]
  else if c = natXorName then
    [natAddName, natMulName, natBleName, natDivName, natModName, natXorName]
  else if c = natShiftLeftName then
    [natSubName, natMulName, natBleName, natShiftLeftName]
  else if c = natShiftRightName then
    [natSubName, natBleName, natDivName, natShiftRightName]
  else []

/-- The defining recurrence equations of a structural-Nat operation,
over constructor forms with free variables `d`, `d + 1` (binder-free,
so the equation sides carry no annotations). -/
def natOpEquations (d : Nat) (c : Name) : List (Expr × Expr) :=
  let natTy : Expr := .const natName []
  let x : Expr := .fvar d natTy
  let y : Expr := .fvar (d + 1) natTy
  let z : Expr := .const natZeroName []
  let s : Expr → Expr := (.app (.const natSuccName []) ·)
  let ap1 : Name → Expr → Expr := fun n a => .app (.const n []) a
  let ap2 : Name → Expr → Expr → Expr := fun n a b =>
    .app (.app (.const n []) a) b
  let bT : Expr := .const boolTrueName []
  let bF : Expr := .const boolFalseName []
  if c = natPredName then
    [(ap1 c z, z), (ap1 c (s x), x)]
  else if c = natAddName then
    [(ap2 c x z, x), (ap2 c x (s y), s (ap2 c x y))]
  else if c = natSubName then
    [(ap2 c x z, x), (ap2 c x (s y), ap1 natPredName (ap2 c x y))]
  else if c = natMulName then
    [(ap2 c x z, z), (ap2 c x (s y), ap2 natAddName (ap2 c x y) x)]
  else if c = natPowName then
    [(ap2 c x z, s z), (ap2 c x (s y), ap2 natMulName (ap2 c x y) x)]
  else if c = natBeqName then
    [(ap2 c z z, bT), (ap2 c z (s y), bF), (ap2 c (s x) z, bF),
     (ap2 c (s x) (s y), ap2 c x y)]
  else if c = natBleName then
    [(ap2 c z y, bT), (ap2 c (s x) z, bF), (ap2 c (s x) (s y), ap2 c x y)]
  else []

/-- The reduct of op `c` on literal arguments (`pred` ignores the
second slot). -/
def natOpResult (c : Name) (a b : Nat) : Option Expr :=
  if c = natPredName then some (.lit (.natVal (a - 1)))
  else if c = natAddName then some (.lit (.natVal (a + b)))
  else if c = natSubName then some (.lit (.natVal (a - b)))
  else if c = natMulName then some (.lit (.natVal (a * b)))
  else if c = natPowName then
    -- the divergence audit's S2: official `reduce_pow` refuses exponents
    -- above `ReducePowMaxExp = 1 << 24` (`type_checker.cpp:616-627`) and
    -- lets `Nat.pow` unfold instead — the blow-up protection, mirrored
    if b > 16777216 then none else some (.lit (.natVal (a ^ b)))
  else if c = natDivName then some (.lit (.natVal (a / b)))
  else if c = natModName then some (.lit (.natVal (a % b)))
  else if c = natGcdName then some (.lit (.natVal (Nat.gcd a b)))
  else if c = natLandName then some (.lit (.natVal (Nat.land a b)))
  else if c = natLorName then some (.lit (.natVal (Nat.lor a b)))
  else if c = natXorName then some (.lit (.natVal (Nat.xor a b)))
  else if c = natShiftLeftName then
    some (.lit (.natVal (Nat.shiftLeft a b)))
  else if c = natShiftRightName then
    some (.lit (.natVal (Nat.shiftRight a b)))
  else if c = natBeqName then
    some (.const (if a = b then boolTrueName else boolFalseName) [])
  else if c = natBleName then
    some (.const (if a <= b then boolTrueName else boolFalseName) [])
  else none

/-- Stored-constant guards for op `c`: the `Nat` basis, every
dependency stored as a definition, and (for the `Bool`-valued ops and
the `ble`-guarded `div`/`mod`, whose semantic clauses mention the
`Bool` constructor values) the `Bool` constructors stored. -/
def natOpGuard (env : Env) (c : Name) : Bool :=
  natLitSupported env &&
  (natOpDeps c).all (fun n => match env.find? n with
    | some (.defnInfo cv _ _) => cv.levelParams.isEmpty
    | _ => false) &&
  (if c = natBeqName || c = natBleName || natDivModNames.contains c then
    (match env.find? boolTrueName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false) &&
    (match env.find? boolFalseName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false)
   else true)

/-- The pin-certified WF-recursive `Nat` operations, as a *safety
net*: the preceding certified branches normally intercept literal
applications, so this list only fires when a capability is absent
(op not stored, or a dependency missing — a mismatching declaration
already declined at install); such a *literal application* is then
positively declined (arena exit 2) rather than ground unary through
the fuel recursion.  Declaring the functions themselves is
unaffected: only the reduction path declines. -/
def natOpWfNames : List Name :=
  [natDivName, natModName, natGcdName, natLandName, natLorName,
   natXorName, natShiftLeftName, natShiftRightName]

/-- Substitute the level-monomorphic constant `n` by `r` through an
application spine (the certification equations' self-references; the
equation sides are binder-free, so only `app` recurses). -/
def Expr.substConst0 (n : Name) (r : Expr) : Expr → Expr
  | .const c us => if c = n ∧ us = [] then r else .const c us
  | .app f a => .app (Expr.substConst0 n r f) (Expr.substConst0 n r a)
  | e => e

/-- Substitute the level-monomorphic constant `n` by the *closed* term
`r` everywhere, including under binders (the div/mod certificate
statements' and proofs' references to the pinned operation; `r` being
closed, no lifting is needed).  `fvar` annotations are not entered:
the substitution runs on closed input terms only. -/
def Expr.substConstAll (n : Name) (r : Expr) : Expr → Expr
  | .const c us => if c = n ∧ us = [] then r else .const c us
  | .app f a => .app (Expr.substConstAll n r f) (Expr.substConstAll n r a)
  | .lam ty b mb =>
    .lam (Expr.substConstAll n r ty) (Expr.substConstAll n r b) mb
  | .forallE ty b mb =>
    .forallE (Expr.substConstAll n r ty) (Expr.substConstAll n r b) mb
  | .letE ty v b =>
    .letE (Expr.substConstAll n r ty) (Expr.substConstAll n r v)
      (Expr.substConstAll n r b)
  | .proj s i e => .proj s i (Expr.substConstAll n r e)
  | e => e

/-- The pinned codomain of a structural-Nat operation: `Bool` (itself
stored level-monomorphically at type `Sort 1`) for the comparisons,
`Nat` otherwise. -/
def natOpCod (env : Env) (c : Name) (e : Expr) : Bool :=
  if c = natBeqName || c = natBleName then
    e == .const boolName [] &&
    (match env.find? boolName with
     | some ci => ci.toConstantVal.levelParams.isEmpty &&
         ci.toConstantVal.type == .sort (.succ .zero)
     | none => false)
  else e == .const natName []

/-- The pinned type of a certified `Nat` operation:
`Nat → Nat` for the unary `pred`, `Nat → Nat → Nat` for the arithmetic
operations, `Nat → Nat → Bool` for the comparisons.  The model reads
the operations' function-space memberships off this shape. -/
def natOpTyPinned (env : Env) (c : Name) (ty : Expr) : Bool :=
  if c = natPredName then
    match ty with
    | .forallE dom body _mb =>
      dom == .const natName [] && natOpCod env c body
    | _ => false
  else
    match ty with
    | .forallE dom (.forallE dom2 body _mb2) _mb =>
      dom == .const natName [] && dom2 == .const natName [] &&
      natOpCod env c body
    | _ => false

/-- Op `n` is stored as a level-monomorphic definition with the pinned
type. -/
def natOpStoredOk (env : Env) (n : Name) : Bool :=
  match env.find? n with
  | some (.defnInfo cv _ _) =>
    cv.levelParams.isEmpty && natOpTyPinned env n cv.type
  | _ => false

/-- **The reduction-time test for a certified `Nat` operation** (task
#161 de-gating round A+B+C, item B3; harvest site 37, list entry P7):
is `c` stored as a definition at all?

`reduceNat` used to re-derive the whole `natOpGuard` at every literal
hit — `natLitSupported` (three `Env.find?`s), a `natOpDeps c` list
build plus a lookup per dependency (up to seven), and two more lookups
for the `Bool` constructors.  That conclusion is *carried by the
install fold invariant*, for every one
of the sixteen guarded names: `NatOps` (the seven structural
ops, `natOpNames`) and `DivMod` (the nine WF-pinned ops,
`natDivModNames`) both read

  `env.find? c = some (.defnInfo cv v hint) → natOpGuard env c = true ∧ …`

and `checkDecl` is what establishes them: it *declines* a stream that
stores one of these names without `natOpGuard env₂ c` (Checker.lean's
`.defnDecl` clause).  The converse is by computation — `c ∈ natOpDeps
c` for all sixteen — so on every environment the checker builds the two
tests agree, and the cheap one is a single `find?`. -/
def natOpStored (env : Env) (c : Name) : Bool :=
  match env.find? c with
  | some (.defnInfo _ _ _) => true
  | _ => false

/-- Peel a `∀`-telescope along an argument list (the residual type of
a fully applied telescope). -/
def piResidual : Expr → List Expr → Option Expr
  | e, [] => some e
  | .forallE _ b _, a :: as => piResidual (b.instantiate1 a) as
  | _, _ :: _ => none

/-- Are all `nF` projection slots of `T` table entries — i.e. does
`T`'s projection table exist and cover them?  (Task #175 tower-flag:
a stored table always carries bodies, so "the entry exists" is the
whole test.) -/
def towerSlotsAll (env : Env) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j => (env.findProj? T j).isSome

/-- Are all `nF` projection slots of `T` recursor-backed projection
functions?  With `towerSlotsAll` the eta
certificate's slot discipline: a family's slots are all of one kind,
so the fabricated spine and the per-slot certificates agree. -/
def recSlotsAll (env : Env) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j =>
    match env.find? (projFnName T j) with
    | some (.recInfo _ _ _ _) => true
    | _ => false

/-- The fabricated projections of a structure-eta spine (task #175
W4c): `.proj T j b` nodes when every slot has a table entry (the
direct install's structures — the node is what the table types and
reduces), else projection-function applications. -/
def etaProjs (env : Env) (T : Name) (us : List Level) (targs : List Expr)
    (b : Expr) (nF : Nat) : List Expr :=
  if towerSlotsAll env T nF then
    (List.range nF).map fun j => Expr.proj T j b
  else
    (List.range nF).map fun j =>
      Expr.mkAppN (.const (projFnName T j) us) (targs ++ [b])

/-- The constructor shape official's `try_eta_struct_core` tests before
inferring anything (`type_checker.cpp:824-829`): the candidate's head is
a stored constructor applied to exactly its parameters and fields.
(`structEtaCertWith` re-reads the same head; this is the gate that
keeps the inferences behind it.) -/
def etaCtorShape (env : Env) (a : Expr) : Bool :=
  match a.getAppFn with
  | .const c _ =>
    match env.find? c with
    | some (.ctorInfo _ cnP cnF) => a.getAppArgs.length == cnP + cnF
    | _ => false
  | _ => false

/-- The eta-rescue fabrication's argument spine (task #175 W4c): the projections
are `etaProjs`' — `.proj` nodes at an all-tower slot family,
projection-function applications otherwise. -/
def etaFabArgsE (env : Env) (T : Name) (ust : List Level)
    (targs : List Expr) (major : Expr) (nF : Nat) : List Expr :=
  targs ++ etaProjs env T ust targs major nF

/-- **The tower-fire guard** (task #175 W4c/O4, restated at W6):
`whnfCore` fires the structural rule `proj_i (ctor p⃗ x⃗) ↦ x_i` at a
tower-backed entry under exactly the guard the tower infer branch
types the node with — at a `Prop`-declared structure the field's guard
level must be a proposition at this instantiation; at every other
family the rule fires unconditionally.

A guard "the structure's sort is provably nonzero at this
instantiation" is *not* what the official kernel does (`reduce_proj`
reduces every constructor redex): it rejects
`PSigma'.fst (PSigma'.mk a b) ≡ a` at symbolic `u v`, where `max u v`
is neither provably zero nor nonzero.  The model licence: at a squash
instance (the structure's
sort is `0` at the valuation) the constructor application reads as
the point, and so does the selected field — for a non-`Prop`-declared
family every field's sort is bounded by the structure's (the O5 bound
`checkStructFieldSortsI` checks), so at a zero instantiation every
field is a proposition; for a `Prop`-declared family the guard says
so of the projected field directly (`TowerEntryLaw`'s iota clause,
`ConLeche/Model/Annot/EnvModelM.lean`).  Ungated rules on a data field of a
`Prop`-declared structure stay out: such a node is not even typed
(`inferBody`'s guard). -/
def ProjEntry.fireOk (entry : ProjEntry) (us : List Level) : Bool :=
  !(Level.isEquiv entry.structSort .zero == some true) ||
    (Level.isEquiv (Level.subst entry.levelParams us entry.fieldSort) .zero
      == some true)

/-- **`And`'s projection slots, ready to fire**: the two
tower entries of `And` are stored, name the rule's constructor at the
major's parameter count, and their `Prop` guards pass at the levels
`ust` (`ProjEntry.fireOk`: `And`'s fields are propositions, so a
`.proj And j h` node is typed by the tower infer branch).  The gate of
`majorToCtor`'s `And` branch; abstracted over the lookup so the
indexed twin (`FEnv.andRescueSlotsF`) shares the body. -/
def andRescueSlotsOf (findProj? : Name → Nat → Option ProjEntry)
    (ctor : Name) (nP : Nat) (ust : List Level) : Bool :=
  (List.range 2).all fun j =>
    match findProj? andName j with
    | some e => e.ctor == ctor && e.numParams == nP && e.numFields == 2 &&
        e.fireOk ust
    | none => false

/-- `andRescueSlotsOf` at the plain environment. -/
def andRescueSlots (env : Env) (ctor : Name) (nP : Nat) (ust : List Level) : Bool :=
  andRescueSlotsOf env.findProj? ctor nP ust

/-- **The K bit at install** (`RecRule.k`): the rule's constructor has
no fields and belongs to an inductive stored with the K capability (an
inductive proposition).  Together with the recursor's rule list being
a singleton — which the reader `recRuleK` and `majorToCtor` match on
— this is the official kernel's `recursor_val::is_k()`.  Abstracted
over the lookup so the interned twin (`FEnv.find?`) shares the body. -/
def recRuleKOf (find? : Name → Option ConstantInfo) (ctor : Name) : Bool :=
  match find? ctor with
  | some (.ctorInfo cvj _ cnF) =>
    match (cvj.type.piResult).getAppFn with
    | .const T _ =>
      match find? T with
      | some (.indInfo _ caps) => caps.ruleK && cnF == 0
      | _ => false
    | _ => false
  | _ => false

/-- **The η-rescue bit at install** (`RecRule.eta`): the rule's
constructor is the η constructor of a stored η-capable inductive,
carries that inductive's own level parameters, and the recursor is not
itself a projection function (whose rescue would reduce to its own
reduct and loop).  Together with the singleton rule list this is the
standing condition of `majorToCtor`'s structure-η rescue.

The level-parameter conjunct is what lets the rescue fabricate the
constructor application at the major type's levels without comparing
the two lists per call: the installer grants η only at a
constructor stored with the former's level parameters (the
recogniser pins `c.1.levelParams == lps`), so the conjunct holds
wherever the rest does. -/
def recRuleEtaOf (find? : Name → Option ConstantInfo) (recName ctor : Name) :
    Bool :=
  match find? ctor with
  | some (.ctorInfo cvj _ _) =>
    match (cvj.type.piResult).getAppFn with
    | .const T _ =>
      match find? T with
      | some (.indInfo cvT caps) =>
        caps.eta && caps.etaCtor == ctor && !Name.isProjFnShape recName &&
          cvj.levelParams == cvT.levelParams
      | _ => false
    | _ => false
  | _ => false

/-- **Stamp a rule's two rescue bits at install** — the one place the
K and η-rescue conditions are decided.  Every rule is stored
through this (the pinned basis blocks, the installer's generated
rules, the projection functions):
the reduction then reads `RecRule.k`/`RecRule.eta` and re-derives
nothing, and the environment invariant `RecCtorsStored` records that a
set bit is the lookup's own verdict. -/
def recRuleBits (find? : Name → Option ConstantInfo) (recName : Name)
    (rl : RecRule) : RecRule :=
  { rl with k := recRuleKOf find? rl.ctor,
            eta := recRuleEtaOf find? recName rl.ctor }

@[simp] theorem recRuleBits_ctor (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).ctor
      = rl.ctor := rfl

@[simp] theorem recRuleBits_rhs (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).rhs
      = rl.rhs := rfl

@[simp] theorem recRuleBits_nfields (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).nfields
      = rl.nfields := rfl

@[simp] theorem recRuleBits_ctorParams (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) :
    (recRuleBits find? recName rl).ctorParams = rl.ctorParams := rfl

@[simp] theorem recRuleBits_fire (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).fire
      = rl.fire := rfl

@[simp] theorem recRuleBits_k (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).k
      = recRuleKOf find? rl.ctor := rfl

@[simp] theorem recRuleBits_paramsBlind (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) :
    (recRuleBits find? recName rl).paramsBlind = rl.paramsBlind := rfl

@[simp] theorem recRuleBits_eta (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).eta
      = recRuleEtaOf find? recName rl.ctor := rfl

@[simp] theorem map_ctor_recRuleBits (find? : Name → Option ConstantInfo)
    (recName : Name) (rs : List RecRule) :
    (rs.map (recRuleBits find? recName)).map (·.ctor) = rs.map (·.ctor) := by
  simp [List.map_map, Function.comp_def]

/-- Is a recursor K-flagged?  The stored bit of its single rule
(`RecRule.k`, computed at the block's install by `recRuleKOf`); the
official kernel reads `recursor_val::is_k()` here in just the same
way. -/
def recRuleK (rules : List RecRule) : Bool :=
  match rules with
  | [rl] => rl.k
  | _ => false

/-- The level and constructor-parameter comparands a firing rule's
checks compare the major's constructor levels and parameters against:
for a canonical (`.plain`) rule the constructor's levels link to the
recursor's by name and its parameters are the recursor's leading
arguments; for a certified nested (`.nested`) rule both are the stored
major-domain instantiations, at the recursor's level instantiation and
(for the parameters) instantiated at the recursor's leading-argument
spine (the stored pins live in the `rP`-binder prefix context — index
arguments never occur in them, by the shape certification).
(Junk for `.inert` rules — `iotaRec` declines before reading it.) -/
def recFireComparands (rl : RecRule) (lps : List Name)
    (us : List Level) (cvjLps : List Name) (args : List Expr)
    (rP : Nat) : List Level × List Expr :=
  match rl.fire with
  | .nested lvls pins =>
    (lvls.map (Level.subst lps us),
     pins.map fun p => Expr.instSpine (args.take rP) (rP - 1)
       (p.instantiateLevelParams lps us))
  | _ =>
    (cvjLps.map fun p => Level.subst lps us (.param p),
     args.take rl.ctorParams)

/-- **The type of a `.proj` node at a tower-backed entry** (task #175
S1): the stored body `F_i[p⃗ ↦ bvars, f_j ↦ .proj T j (bvar 0)]`,
level-instantiated at the subject type's levels, with the subject
type's arguments and the subject substituted for its `numParams + 1`
loose variables in ONE traversal (`instantiateList`: `bvar 0` is the
subject, `bvar (numParams - k)` parameter `k`). -/
def ProjEntry.typeAt (entry : ProjEntry) (us : List Level) (targs : List Expr)
    (pe : Expr) : Expr :=
  (entry.body.instantiateLevelParams entry.levelParams us).instantiateList
    (pe :: targs.reverse)

/-- **THE β SITE'S GATE** (task #161): does the mode's β gate fire at
this binder?

At `mode.betaGate` (i.e. at `.verified`, and nowhere else) a λ-binder
whose *validated* annotation datum is `.never` — "the codomain sort is
nonzero at every valuation" — licenses skipping the certificate: the
`Red.betaGate` rule's soundness (`Red.betaGate_sound`,
`ConLeche/Model/Rules/RedSound.lean`) derives the domain membership from the
redex's own `WellDenoted` slot and consumes no certificate at all.

At a possibly-zero datum, and at every non-gated mode, the certificate
runs unconditionally — the establishment/consumption asymmetry fence,
and task #100's de-gating ruling, both untouched: *that* gate read a
**computed** nonzero sort (unsound-to-model under the domain-relative
collapse); this one reads a **validated annotation**.

Both arms hand back the same reduct, so reducts stay
annotation-blind; the dead-branch collapse is `betaGateFires_off`
(`Verify/BetaGate.lean`).

The gate is a **pure early return**, not a wrapper around the test's
`Bool`, and that shape is load-bearing: the `else` arm is then the
pre-gate clause *byte-for-byte*, so every existing proof of every
non-gated mode continues verbatim after one `simp only` on the
condition.  (A wrapper around the test would have re-associated the
certificate's binds and cost every site a `bind_assoc` as well.)

`betaGateFires` is deliberately mode-and-datum only — it reads no
expression and runs no computation, so it is decidable *before* the
certificate would have started, which is the whole performance
point. -/
@[inline] def betaGateFires (mode : CheckMode) (pw : PropWhen) : Bool :=
  mode.betaGate && pw.isNever

/-- Is this datum a real (non-placeholder) input annotation? -/
@[inline] def pwWritten (pw : PropWhen) : Bool := !pw.isNever

/-- The datum a rebuilt binder ends up with: the one threaded in from
the node below (the chain rule), unless it carries a real input
annotation — those are judged by validation, never overwritten. -/
def annotBinderMeta (pw? : Option PropWhen) (mb : BinderMeta) : BinderMeta :=
  match pw? with
  | some pw => if pwWritten mb.pw then mb else ⟨pw⟩
  | none => mb

end ConLeche

end -- original EOF public section of ConLeche.Kernel.CoreDefs
/- END exact source origin ConLeche.Kernel.CoreDefs -/

/- BEGIN exact source origin ConLeche.Kernel.Core -/
-- Bundled origin 19, header line 1: module

-- Bundled origin 19, header line 3: import ConLeche.Kernel.Level
-- Bundled origin 19, header line 4: import ConLeche.Kernel.ExprOps
-- Bundled origin 19, header line 5: public import ConLeche.Kernel.CoreDefs

@[expose] public section

/-!
# The checker core, in open-recursion style

Every core function is written **once**, as a non-recursive *body*
parameterized over a record of the mutually recursive entry points
(`CoreFns`) and polymorphic in the monad.  All recursion is routed
through the record — bodies never call themselves, and the few helpers
that do recurse (`iotaCerts`, `defEqList`, `structEtaProjCerts`) do so
structurally on a list.  Fuel lives only in the *knots* that tie the
record: the pure knot (`ConLeche.Kernel.TypeChecker`) instantiates the
bodies at `CheckM` and is the verification's subject; the cached knot
(`ConLeche.Cached.CoreC`) instantiates them over the cached
representation with the memo caches and is what the checker executes.
A refinement bridge relates the two (see DESIGN.md).

The reduction loop follows the official kernel (`whnfCore` never
delta-unfolds; `whnf` iterates `whnfCore → reduceNat → unfold one
definition`), and definitional equality starts with the syntactic fast
path and tries proof irrelevance before structural congruence.
Inference re-checks the application argument and the λ-annotation: the
soundness claims re-derive their membership slots from those checks at
their own fuel.  The official kernel's *infer-only* mode is deferred
until the refinement bridge's fuel-determinism machinery lands
(DESIGN.md).

Verification: `ConLeche.Model.*` and `ConLeche.Verify.*` (claims),
`ConLeche.Verify.*` (inversions), both stated against the bodies with
hypotheses about the record and discharged by one induction at the
knot.

The core's **fuel-free helpers** — everything a body reads that
mentions no monad, no record and no fuel (`unfoldDefinition`, the
literal guards, the certified `Nat` operations' tables, the η
fabrications, the install-time rule bits, `betaGateFires`, …) — live
in `ConLeche/Kernel/CoreDefs.lean` since task #305 (prep) and are
re-exported here, so that a relational description of the core's
moves can name them without importing the bodies.
-/

namespace ConLeche

-- Compatibility edits: explicit universe and liftFueled type binders.
universe u

/-- **The verdict of a failure, everywhere in the binary** — the one
error type the whole accept path reports (task #295): the kernel's
steps, the fold, and the frontend's parse and prelude alike.  The
three cases are the three verdicts the driver exits with
(`CheckError.exitCode`, `Main.lean`): 2 declined, 1 rejected, 3 an
error of unclear cause or a malformed input.

Where a failure has a POSITION the type is `CheckError × Nat`, and the
`Nat` is read in the step's own unit: the input's LINE number in the
frontend (`ConLeche/Frontend/Export.lean`; 0 where no line is meant,
as in the size guard, which refuses the input before reading it) and
the record's position in the list the fold folds
(`ConLeche.Cached.checkDecls`).  The two are in the same type because
the driver chains the steps, and the main corollary states that chain
(`ConLeche/MainTheorem.lean`). -/
inductive CheckError where
  | notImplemented (what : String)
  | invalid (msg : String)
  | internal (msg : String)
  deriving Repr

instance : ToString CheckError where
  toString
    | .notImplemented what => s!"not implemented yet: {what}"
    | .invalid msg => s!"invalid: {msg}"
    | .internal msg => s!"internal error: {msg}"

abbrev CheckM := Except CheckError

/-- **The verdict at a constant the environment does not know.**

`sorryAx` is the one axiom the checker tolerates as a *declaration*
and installs nothing for (`sorryAxName`,
`ConLeche/Kernel/Basis/Names.lean`): an export declares it whenever
its module mentions `sorry`, so the record is skipped and the stream
goes on — but there is no set model for it, so a *use* is a
positively detected unsupported feature and the run DECLINES, at the
record that uses it.  Every other unresolved name is a malformed
stream: a REJECT, with the message unchanged.

This is the choke point, because the guard that keeps unresolved
constants out of stored terms (`Expr.constsResolve`) runs *after* the
annotation pass, and annotation infers every binder domain's sort —
so a `sorryAx` in a domain reaches inference first.  Its companion
`unresolvedConstsError` (`ConLeche/Kernel/CheckerBase.lean`) decides
the same question at the guard, for the `sorryAx` occurrences
inference never reaches. -/
def unknownConstError (n : Name) : CheckError :=
  if n = sorryAxName then .notImplemented "use of the sorryAx axiom"
  else .invalid s!"unknown constant {n}"

/-- **Could official's `infer_proj` type `.proj sn i _` at a subject
of type `T a⃗` where we store no projection table for `T`?**  Only at a
single-constructor inductive `T` named by the node, applied to MORE
arguments than its parameters (official's premise is `#ctors = 1` and
`#args = nparams + nindices`, so indices are allowed), at a field index
below the constructor's field count: an INDEXED structure-like type,
where official projects and we store no table (the installer stores
one at every index-free single-constructor member and only there,
`checkBlockTables`).  Every other shape official rejects
(`invalid_proj_exception`): a head that is no inductive (an axiom, an
opaque, `Quot`), a constructor count other than one, a node naming
another type, a field index beyond the fields (`PUnit`, `Eq`: no
fields; an index-free one-constructor type always has a table). -/
def projIndexedStructLike (find? : Name → Option ConstantInfo) (T sn : Name)
    (i nArgs : Nat) : Bool :=
  T == sn &&
    match find? T with
    | some (.indInfo _ caps) =>
      match caps.ctors with
      | [c] =>
        caps.nparams < nArgs &&
          match find? c with
          | some (.ctorInfo _ _ nF) => decide (i < nF)
          | _ => false
      | _ => false
    | _ => false

/-- **The verdict at a `.proj sn i _` whose subject type is headed by
the constant `T` (applied to `nArgs` arguments) and has no
projection-table entry at field `i`** (`hasTable`: whether `T` has a
table at all).  A table without field `i` is an out-of-range index; a
positively detected indexed structure-like type (`projIndexedStructLike`)
is the one shape official accepts and we do not support (DECLINE, on
purpose: https://github.com/leanprover/lean4/issues/14977 removes
projections from indexed inductives); everything else rejects. -/
def projMissError (find? : Name → Option ConstantInfo) (hasTable : Bool)
    (T sn : Name) (i nArgs : Nat) : CheckError :=
  if hasTable then .invalid "projection index out of range"
  else if projIndexedStructLike find? T sn i nArgs then
    .notImplemented "projection on an indexed structure-like type"
  else .invalid "invalid projection: not a structure-like type, or no such field"

/-- The record of mutually recursive core entry points.  `whnfCore`
computes a head normal form without delta — its first argument is the
official kernel's `cheap_proj` flag (`whnfCoreBody`); `whnf` is the full reduction
loop; `infer` is type inference;
`defeq` is definitional equality; `annotate` computes binder
annotations (and is the one place typing is checked). -/
structure CoreFns (m : Type → Type u) where
  whnfCore : Bool → Nat → Expr → m Expr
  whnf : Nat → Expr → m Expr
  infer : Nat → Expr → m Expr
  defeq : Nat → Expr → Expr → m Bool
  annotate : Nat → Expr → m Expr
  /-- Type inference at the **infer-only grade** (task #170): the
  official kernel's `infer_type_core(e, infer_only = true)`, the entry
  every *internal* inference call site uses — a subject that already
  carries a validated annotation invariant (`WellDenotedV` in the P
  claims) is re-inferred without re-establishing it.  The knot decides
  the grade's meaning per mode: at a gate-off mode (`μ.betaGate =
  false`) this is the full `infer`, verbatim (the flag is ignored,
  task #170's R clause); at the gated mode (`.verified`, the P core)
  it is the io body, whose application clause skips the per-argument
  certificate at a `.never` binder under the graph-regime license
  (`ConLeche/Model/IOLicense.lean`).  The **shipped** trusted core
  selects the io body too (`CheckMode.ioGate` is `true` at both
  modes, the licence ruling of 2026-09-06); this mode-parametric
  spelling is not the thing that ships, so `μ.betaGate` here stays the
  P tier's own bit, and the two agree at `.verified`. -/
  inferIO : Nat → Expr → m Expr

/-- The **io-grade view** of a core record: the record whose full-grade
`infer` slot is the io slot, so that a body written against `r.infer`
recurses at the io grade when handed `r.ioView`.  This is how the io
inference body propagates its own grade (official: `infer_type_core`
passes `infer_only` down) without a textual twin. -/
def CoreFns.ioView {m : Type → Type u} (r : CoreFns m) : CoreFns m :=
  { r with infer := r.inferIO }

section Bodies

variable {m : Type → Type} [Monad m] [MonadExceptOf CheckError m]

/- The mode setting (`CheckMode`, `ConLeche/Kernel/Env.lean`):
definitions below that mention `mode` take it as their first explicit
argument (after the monad instances). -/
variable (mode : CheckMode)

/-- Lift a fuel-style partial result.  Its only client is the level
comparison (`Level.leq`/`isEquiv`), whose `none` is its fuel running out
(`Level.defaultFuel`) — OUR resource limit, so a DECLINE (exit 2), never
a verdict (charter item 9).  Every check that REQUIRES a comparison between two
levels neither of which is `zero` goes through here, so an exhausted
comparison cannot read as "not equivalent".  (A comparison against
`zero` cannot misread: `simplify` sends every always-zero level to
`zero`, and `isEquiv` answers `true` on that fast path, so its `none`
only ever stands for a true "no".) -/
def liftFueled {α : Type} (what : String) : Option α → m α
  | some a => pure a
  | none => throw (.notImplemented s!"resource limit: fuel exhausted: {what}")

/-- Literal acceleration (the official kernel's `reduceNat`, run in the
`whnf` loop *before* delta-unfolding): pack `Nat.succ` applied to a
literal back into a literal.  Binary operations on literal arguments
are added with the verified fast-path capabilities (see DESIGN.md);
until then only the constructor packing reduces. -/
def reduceNat (r : CoreFns m) (env : Env) (depth : Nat) (e : Expr) :
    m (Option Expr) := do
  match e with
  | .app (.const c []) a =>
    if c = natSuccName ∧ natLitSupported env then
      -- the argument is reduced first (as for the operations below):
      -- literals reach `succ` wrapped in `OfNat`/instance towers, and a
      -- missed packing here defeats the binary fast paths downstream,
      -- which then delta-grind the `brecOn` below-tower unarily
      match rawNatLit? (← r.whnf depth a) with
      | some n => pure (some (.lit (.natVal (n + 1))))
      | none => pure none
    -- (the audit's S1: the `Nat.pred` and `Nat.log2` literal fast paths
    -- are gone — official `reduce_nat` (`type_checker.cpp:639-668`) has
    -- `Nat.succ` and the fourteen binary operations, nothing else.
    -- `Nat.pred` stays a certified structural operation because
    -- `Nat.sub`'s recurrence names it; `Nat.log2` is gone entirely)
    else pure none
  | .app (.app (.const c []) a) b =>
    if (c = natAddName ∨ c = natSubName ∨ c = natMulName ∨
        c = natPowName ∨ c = natBeqName ∨ c = natBleName ∨
        c = natDivName ∨ c = natModName ∨ c = natGcdName ∨
        c = natLandName ∨ c = natLorName ∨ c = natXorName ∨
        c = natShiftLeftName ∨ c = natShiftRightName) ∧
        natOpStored env c = true then
      -- Official `reduce_bin_nat_op` (`type_checker.cpp:606-614`):
      -- the FIRST argument is head-normalised and, unless it is a
      -- literal, the step fails WITHOUT touching the second.  The
      -- former two-scrutinee `match` whnf'd both up front — a cost
      -- divergence (DESIGN.md "THE DIVERGENCE AUDIT", D15): on
      -- `Nat.add o (slow n)` with `o` opaque it evaluated `slow n`
      -- where official never does (fuel death at `n = 80000`; the fixture).
      match rawNatLit? (← r.whnf depth a) with
      | some n₁ =>
        match rawNatLit? (← r.whnf depth b) with
        | some n₂ => pure (natOpResult c n₁ n₂)
        | none => pure none
      | none => pure none
    else if natOpWfNames.contains c ∧ natLitSupported env then
      match rawNatLit? (← r.whnf depth a) with
      | some _ =>
        match rawNatLit? (← r.whnf depth b) with
        | some _ => throw (.notImplemented
            s!"native Nat computation on literals ({c})")
        | none => pure none
      | none => pure none
    else pure none
  | _ => pure none

/-- Certify a spine against a recursor telescope: each argument's
inferred type is defeq to the corresponding (instantiated) domain.
This is what hands the soundness proof the memberships the iota
equations need, at every level assignment.

**The ι-slot licence** (the ι batch, 2026-09-05; DESIGN.md "THE ι
AUDIT" §9.1): at a *licensed* walk (`lic = true`, set only by
`iotaRec`'s two calls — the fire-time telescope runs, where the redex
is a subterm of the subject and carries its own `WellDenoted` app slots)
a slot whose `∀`-binder datum is `.never` is skipped: the membership
the run would establish follows from the slot and the head's
membership in the telescope's reading (`io_domain_transfer`,
`Model/IOLicense.lean`, consumed by `Certs.skip_sound` in
`Model/Rules/CertsSound.lean`).  The rescue's
synthetic-spine certifications (`majorToCtor`, the η/unit/K
fabrications) run at `lic = false`: a fabricated spine is not a
subterm of the subject and its grading is *produced* by this very
run, so gating it would be circular.  The fence is
`io_squash_no_transfer`'s witness: at a possibly-zero datum the skip
is unsound model-class-wide, so the licensed fragment is exactly
`.never`. -/
def iotaCerts (r : CoreFns m) (env : Env) (depth : Nat) (lic : Bool) :
    Expr → List Expr → m Bool
  | _, [] => pure true
  | .forallE ty body mb, arg :: rest =>
    if lic && mb.pw.isNever then
      iotaCerts r env depth lic (body.instantiate1 arg) rest
    else do
      -- task #172 B4: the spine certificate's inference at the io grade
      let ta ← r.inferIO depth arg
      if ← r.defeq depth ta ty then
        iotaCerts r env depth lic (body.instantiate1 arg) rest
      else pure false
  | _, _ :: _ => pure false

/-- Pairwise definitional equality of two spines (used to check a
major's constructor parameters against the recursor's). -/
def defEqList (r : CoreFns m) (env : Env) (depth : Nat) :
    List Expr → List Expr → m Bool
  | [], [] => pure true
  | a :: as, b :: bs => do
    if ← r.defeq depth a b then
      defEqList r env depth as bs
    else pure false
  | _, _ => pure false

/-- The canonical-index comparison of a firing ι redex (the ι batch,
2026-09-05).  Where the recursor has indices (`rP < mI`) the residual of
the constructor's telescope `tyCtor` along the major's spine `margs`
must agree, past the `cnP` parameters, with the recursor's index
arguments `idx` — the model's iota equation only speaks about the
canonical indices.  At `mI = rP` there is nothing to compare (the law's
`IotaIndexPin` is discharged by `Or.inl rfl`) and the block is
skipped.  The residual-head test that once stood beside the comparison
(`stripPis` + "the body's head is a constant") was consumed by nothing
in the P lane and is gone. -/
def iotaIndexOk (r : CoreFns m) (env : Env) (depth : Nat) (mI rP cnP : Nat)
    (tyCtor : Expr) (margs idx : List Expr) : m Bool :=
  if mI = rP then pure true
  else
    match piResidual tyCtor margs with
    | some residual => defEqList r env depth (residual.getAppArgs.drop cnP) idx
    | none => pure false

/-- Proof irrelevance certification: both sides' types' *sorts* are
`Prop`.  In the model everything inhabiting a proposition is the proof
point, so any two such terms are equal — no common-type check is needed: soundness holds
without it, and the annotation-first discipline (every subterm is
checked before definitional equality compares it; congruence compares
argument pairs only after the earlier arguments matched) makes a
heterogeneous comparison unreachable, so the official kernel's check is
implied (see DESIGN.md, design-review triage). -/
def proofIrrel (r : CoreFns m) (depth : Nat) (a b : Expr) :
    m Bool := do
  -- task #172 B4: every inference here is at the io grade (official's
  -- is_def_eq_proof_irrel runs infer_type — always infer_only)
  let ta ← r.inferIO depth a
  match ← r.whnf depth (← r.inferIO depth ta) with
  | .sort uT =>
    let okA ← liftFueled "level comparison" (Level.isEquiv uT .zero)
    let tb ← r.inferIO depth b
    match ← r.whnf depth (← r.inferIO depth tb) with
    | .sort vT =>
      let okB ← liftFueled "level comparison" (Level.isEquiv vT .zero)
      pure (okA && okB)
    | _ => pure false
  | _ => pure false

/-- **The hoisted proof-irrelevance test** (task #168, Option U):
`proofIrrel` behind the head-symbol fast arms — official's
`is_def_eq_proof_irrel`; the unit-like test is `stuckIrrel`'s
`structUnitCert` (official's `is_def_eq_unit_like`, the last test of
`is_def_eq_core`).

Before the io inferences, the head-symbol readers decide both fast
arms, **in both modes** (user ruling, 2026-09-06: the fast readers are
part of the real checker, and the trusted mode is the real checker
with certification-only work omitted — a reader that replaces
inference is not certification-only work).  The **"not a proof" arm**:
a side whose annotation datum says "not a proposition" refuses the
shortcut outright (`notProofFast`, `ConLeche/Kernel/PropRead.lean`).
Refusing is always sound — the P row is stated at `.ok true` — and the
arm's obligation is *agreement* with the slow path, recorded by the
landing census (DESIGN.md, task #168: 0 disagreements in 7.5 M calls).
The **"yes" arm** (`isProofFast` on both sides → `true`) is the
squash-regime licence, stage 3 of the same design
(`prf_of_isProofFast`, `ConLeche/Model/Rules/DefEqSoundKit.lean`), which the
verified mode's `DefEq.proofFast` rule consumes; the trusted mode is unverified and
inherits the arm without a row, as it inherits every other body. -/
def propIrrel (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool := do
  if notProofFast env.find? a || notProofFast env.find? b then
    pure false
  else if isProofFast env.find? a && isProofFast env.find? b then
    -- the yes arm (task #168 stage 3): both heads' validated data say
    -- "a proposition at every valuation" — the squash-regime licence
    -- (`prf_of_isProofFast`, `ConLeche/Model/Rules/DefEqSoundKit.lean`)
    pure true
  else
  -- task #172 B4: every inference here is at the io grade
  let ta ← r.inferIO depth a
  match ← r.whnf depth (← r.inferIO depth ta) with
  | .sort uT =>
    let okA ← liftFueled "level comparison" (Level.isEquiv uT .zero)
    let tb ← r.inferIO depth b
    match ← r.whnf depth (← r.inferIO depth tb) with
    | .sort vT =>
      let okB ← liftFueled "level comparison" (Level.isEquiv vT .zero)
      pure (okA && okB)
    | _ => pure false
  | _ => pure false

/-- The per-projection telescope certificates of a structural eta
certification at a **projection-function** slot family: for every field
index, the installed projection function's
telescope is certified against the type's arguments and the stuck
side.  A tower-backed family (the direct install's table, task #175
S1) has no per-field telescope and needs no certificate: its η law
(`TowerEtaLaw`) is keyed on the family's typing of the stuck side,
which the caller already holds. -/
def structEtaProjCerts (r : CoreFns m) (env : Env) (depth : Nat)
    (T : Name) (us' : List Level) (targs : List Expr) (b : Expr)
    (lpsT : List Name) : List Nat → m Bool
  | [] => pure true
  | i :: rest => do
    match env.find? (projFnName T i) with
    | some (.recInfo cvp _ _ _) =>
      if cvp.levelParams = lpsT ∧
          (cvp.type.stripPis (targs.length + 1)).isSome = true then
        if ← iotaCerts r env depth false
            (cvp.type.instantiateLevelParams cvp.levelParams us')
            (targs ++ [b]) then
          structEtaProjCerts r env depth T us' targs b lpsT rest
        else pure false
      else pure false
    | _ => pure false

/-- The structure-eta certificate against a *given* weak-head-normal
type of the stuck side (callers that already reduced it — the
stuck-major rescue — pass their own copy, so the certificate's facts
are in terms of that expression). -/
def structEtaCertWith (r : CoreFns m) (env : Env) (depth : Nat)
    (a b wtb : Expr) : m Bool := do
  match a.getAppFn with
  | .const c us =>
    match env.find? c with
    | some (.ctorInfo cvc cnP cnF) =>
      if a.getAppArgs.length = cnP + cnF then
        match wtb.getAppFn with
        | .const T us' =>
          match env.find? T with
          | some (.indInfo cvT caps) =>
            if caps.eta = true ∧ caps.etaCtor = c ∧
                reservedBasisNames.contains T = false ∧
                reservedBasisNames.contains c = false ∧
                wtb.getAppArgs.length = caps.etaParams ∧
                us'.length = cvT.levelParams.length ∧
                cvc.levelParams = cvT.levelParams ∧
                -- the former's telescope arity
                -- `(cvT.type.stripPis caps.etaParams).isSome` is
                -- `EnvWF`'s `IndCapsWF` clause: established at the
                -- block's install, read by the η row from the
                -- invariant
                -- the slot discipline (task #175 W4c): one entry kind
                (towerSlotsAll env T caps.etaFields ||
                  recSlotsAll env T caps.etaFields) = true then
              if ← liftFueled "level comparison"
                  (Level.isEquivList us us') then
                if ← iotaCerts r env depth false
                    (cvT.type.instantiateLevelParams cvT.levelParams
                      us') wtb.getAppArgs then
                  -- the per-slot certificates are the projection-function
                  -- kind's; a tabled family has none (task #175 S1)
                  if ← (if towerSlotsAll env T caps.etaFields then pure true
                      else structEtaProjCerts r env depth T us'
                        wtb.getAppArgs b cvT.levelParams
                        (List.range caps.etaFields)) then
                    if ← defEqList r env depth
                        (a.getAppArgs.take caps.etaParams) wtb.getAppArgs then
                      -- synthetic-spine certification (task #137): the
                      -- fabricated constructor application is certified
                      -- against the constructor's own telescope, here
                      -- rather than at the callers, so that both
                      -- consumers get it (`majorToCtor`'s eta rescue ran
                      -- it already, task #71; `defeq`'s `structEtaCert`
                      -- did not).  TT-lane check (task #147): skipped
                      -- unless `mode.ttChecks`.
                      if ← (if mode.ttChecks then
                          iotaCerts r env depth false
                            (cvc.type.instantiateLevelParams
                              cvc.levelParams us)
                            (wtb.getAppArgs ++
                              etaProjs env T us' wtb.getAppArgs b
                                caps.etaFields)
                        else pure true) then
                        defEqList r env depth
                          (a.getAppArgs.drop caps.etaParams)
                          (etaProjs env T us' wtb.getAppArgs b
                            caps.etaFields)
                      else pure false
                    else pure false
                  else pure false
                else pure false
              else pure false
            else pure false
          | _ => pure false
        | _ => pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- Structural eta certification for a stored eta-capable structure:
`a` is a fully applied constructor of a structure whose recorded
capabilities include eta, `b` inhabits that structure type, the
constructor's parameters are the type's arguments, and every field is
the corresponding installed projection function applied to `b`.  The
type application is additionally certified against the type former's
telescope (the memberships the stored eta law consumes).  The
parameter and field counts the certificate works at are the
capability RECORD's, which is what the stored law speaks; the
constructor's own counts gate the redex's shape and nothing else
(`etaCtorShape`). -/
def structEtaCert (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool := do
  -- The constructor-shape test FIRST (the divergence audit's D13):
  -- official `try_eta_struct_core` (`type_checker.cpp:824-829`) reads
  -- `s`'s head and arity syntactically and infers nothing unless they
  -- fit; ours inferred and whnf'd `b`'s type on every stuck pair, both
  -- directions, before `structEtaCertWith` looked at `a`'s head.
  if etaCtorShape env a then
    -- task #172 B4: io grade
    let tb ← r.inferIO depth b
    let wtb ← r.whnf depth tb
    structEtaCertWith mode r env depth a b wtb
  else pure false

/-- Unit-likeness certification: `a` and `b` inhabit the same stored
unit-like family (the types are definitionally equal and the type
application is certified against the family's telescope), so their
values coincide by the stored unit law. -/
def structUnitCert (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool := do
  -- task #172 B4: io grade
  let ta ← r.inferIO depth a
  let wta ← r.whnf depth ta
  match wta.getAppFn with
  | .const T us' =>
    match env.find? T with
    | some (.indInfo cvT caps) =>
      if caps.unitlike = true ∧
          reservedBasisNames.contains T = false ∧
          wta.getAppArgs.length = caps.unitParams ∧
          -- `(cvT.type.stripPis caps.unitParams).isSome` is `EnvWF`'s
          -- `IndCapsWF` clause, established at the block's install
          us'.length = cvT.levelParams.length then
        let tb ← r.inferIO depth b
        let wtb ← r.whnf depth tb
        if ← r.defeq depth wta wtb then
          iotaCerts r env depth false
            (cvT.type.instantiateLevelParams cvT.levelParams us')
            wta.getAppArgs
        else pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- Eta certification for a one-sided λ against a stuck term `b`: `b`'s
type whnfs to a `∀` whose domain is defeq to the λ's, and the λ's body
is pointwise the application of `b`.  The λ is then `b`'s eta-expansion
(soundness: `SetTheory.lam_eta`). -/
def etaCert (mode : CheckMode) (r : CoreFns m) (_env : Env) (depth : Nat)
    (ty₁ body₁ : Expr) (m₁ : BinderMeta) (b : Expr) :
    m Bool := do
  -- task #172 B4: io grade
  let tb ← r.inferIO depth b
  match ← r.whnf depth tb with
  | .forallE ty₂ _ m₂ =>
    -- Task #161: the λ's prop-ness annotation must agree with the
    -- product it η-expands (`lamR_eta`'s regime agreement) — checked
    -- LAST, like the defeq binder arms, so a mismatch fires only on
    -- an otherwise-successful η certification.  (This is the
    -- validated successor of the cod-agreement comparison task #100
    -- stage 6 deleted.)
    if ← r.defeq depth ty₂ ty₁ then
      unless ← r.defeq (depth + 1)
          (body₁.instantiate1 (.fvar depth ty₁))
          (.app b (.fvar depth ty₁)) do return false
      if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
        throw (.notImplemented "sort-annotation mismatch (eta)")
      pure true
    else pure false
  | _ => pure false

/-- The fallback for structurally distinct stuck terms: structural eta
in either direction, unit-likeness, else proof irrelevance. -/
def stuckIrrel (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool := do
  if ← structEtaCert mode r env depth a b then pure true
  else if ← structEtaCert mode r env depth b a then pure true
  else if ← structUnitCert r env depth a b then pure true
  else proofIrrel r depth a b

/-- Stuck-major rescue (`to_cnstr_when_K` and `to_cnstr_when_structure`
in the official kernel): a recursor's major premise that does not whnf
to a constructor application may still be *replaced* by one.  For a
K-flagged inductive proposition the parameters-only application of the
single constructor is fabricated from the major's type and certified by
proof irrelevance (in the model both are the proof point); for an
eta-capable structure the constructor of the major's projections is
fabricated and certified by the structure-eta certificate (in the model
both are the tuple of the major's components); for `And` —
a proposition, which official never η-rescues — the constructor of the
major's projections is fabricated and certified by proof irrelevance
(the `And` branch below).  An uncertified major stays put — sound, the
reduction simply stays stuck. -/
def majorToCtor (r : CoreFns m) (env : Env) (depth : Nat)
    (_recName : Name) (rules : List RecRule) (major : Expr) : m Expr := do
  -- cheap syntactic gates before any inference: a rescue needs a
  -- single-rule recursor whose rule carries the matching install-time
  -- rescue bit (`RecRule.k`/`RecRule.eta`)
  if isCtorApp env major then pure major else
  match rules with
  | [rl] =>
    match env.find? rl.ctor with
    | some (.ctorInfo cvj cnP _cnF) =>
      match (cvj.type.piResult).getAppFn with
      | .const T _ =>
        match env.find? T with
        | some (.indInfo cvT caps) =>
          if rl.k = true then
            -- task #172 B4: io grade (lean4lean toCtorWhenK inferType)
            let tmaj ← r.whnf depth (← r.inferIO depth major)
            match tmaj.getAppFn with
            | .const T' ust =>
              if T' = T ∧ cvj.levelParams.length = ust.length then
                -- no constructor-telescope arity pin: the fabrication
                -- is typed by `iotaCerts` below, and the model proof
                -- consumes no such fact
                if cnP ≤ tmaj.getAppArgs.length then
                  let fab := Expr.mkAppN (.const rl.ctor ust)
                    (tmaj.getAppArgs.take cnP)
                  -- scope guard: scoping of
                  -- the fabricated major is checked syntactically,
                  -- keeping its verification local
                  if fab.wscopedB depth && fab.looseBVarsBounded 0 &&
                      fab.fvarLeaves.all
                        (fun l => major.fvarLeaves.contains l) then
                    -- Synthetic-spine certification (task #71): a
                    -- fabricated constructor spine has no annotated
                    -- application chain for the gated fire-path
                    -- certificates to recover memberships from, so
                    -- the *ungated* telescope certificate runs here,
                    -- relocated from the fire path.
                    if ← iotaCerts r env depth false
                        (cvj.type.instantiateLevelParams
                          cvj.levelParams ust)
                        (tmaj.getAppArgs.take cnP) then
                      -- The official `to_cnstr_when_K` type check on
                      -- the fabrication: the constructor
                      -- application's type must be defeq to the
                      -- major's (for `Eq` this is the endpoint
                      -- condition — `Eq.refl a : Eq a a` against the
                      -- major's `Eq a b` forces `a ≡ b`).  A
                      -- reference-kernel check, kept independently of
                      -- the per-fire iota certificates (during the
                      -- gated era of tasks #49/#71 it was load-bearing
                      -- on its own — arena bad/098_ruleKbad fires at
                      -- `Eq.rec.{3,3}`).  `proofIrrel` stays as the
                      -- soundness certificate (in the model both
                      -- sides are the proof point).
                      if ← r.defeq depth tmaj (← r.inferIO depth fab) then
                        if ← proofIrrel r depth fab major then
                          pure fab
                        else pure major
                      else pure major
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else if rl.eta = true then
            let tmaj ← r.whnf depth (← r.inferIO depth major)
            match tmaj.getAppFn with
            | .const T' ust =>
              -- The official kernel does not eta-rescue propositional
              -- structures (`to_cnstr_when_structure` requires the
              -- structure's result sort to be provably nonzero).  The
              -- test is the *instantiated* one (task #61): a static
              -- test of the declared type's result sort passes a
              -- parametric `Sort u` that a `Prop` instantiation
              -- collapses, which is exactly the case the guard exists
              -- for.
              if T' = T ∧ tmaj.getAppArgs.length = caps.etaParams ∧
                  ust.length = cvT.levelParams.length ∧
                  capsNeverZero cvT.levelParams ust caps = true then
                -- no constructor-telescope arity pin, as in the K
                -- branch, and no level-count pin: the η bit is set
                -- only at a constructor stored with the former's own
                -- level parameters (`RecCtorsStored`), which the
                -- fabrication's levels are those of
                let fab := Expr.mkAppN (.const caps.etaCtor ust)
                    (etaFabArgsE env T ust tmaj.getAppArgs major
                      caps.etaFields)
                -- scope guard, as in the K branch
                if fab.wscopedB depth && fab.looseBVarsBounded 0 &&
                    fab.fvarLeaves.all
                      (fun l => major.fvarLeaves.contains l) then
                  -- synthetic-spine certification, as in the K
                  -- branch (task #71)
                  if ← iotaCerts r env depth false
                      (cvj.type.instantiateLevelParams
                        cvj.levelParams ust)
                      (etaFabArgsE env T ust tmaj.getAppArgs major
                        caps.etaFields) then
                    if ← structEtaCertWith mode r env depth fab major
                        tmaj then
                      pure fab
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else if T = andName then
            -- THE `And`-ONLY η RESCUE (user ruling: `And` and nothing
            -- else — "this is a hack and we want its blast radius
            -- limited").  `And.rec F h` at a stuck PROOF `h` (a theorem
            -- is opaque to reduction) fires through the fabrication
            -- `And.intro a b (.proj And 0 h) (.proj And 1 h)`,
            -- certified the K branch's way: the synthetic spine against
            -- the constructor's telescope (which types the two `.proj`
            -- nodes through `And`'s projection table), the
            -- fabrication's type against the major's, and proof
            -- irrelevance — sound because in the model every proof is
            -- the point.  Official does not η-rescue a proposition
            -- (`to_cnstr_when_structure` requires a never-zero sort),
            -- so this is an accept-superset there, reported per the
            -- `proofIrrel` ruling; it WORKS AROUND the absence of
            -- https://github.com/leanprover/lean4/pull/14925 (upstream
            -- builds `casesOn`/`recOn` of such a proposition from
            -- projections, so no `And.rec` on a proof is emitted), on
            -- top of opaque theorems, which ANTICIPATE
            -- https://github.com/leanprover/lean4/pull/14896.
            let tmaj ← r.whnf depth (← r.inferIO depth major)
            match tmaj.getAppFn with
            | .const T' ust =>
              if T' = T ∧ tmaj.getAppArgs.length = cnP ∧
                  cvj.levelParams.length = ust.length ∧
                  andRescueSlots env rl.ctor cnP ust = true then
                let fab := Expr.mkAppN (.const rl.ctor ust)
                  (tmaj.getAppArgs ++ [.proj T 0 major, .proj T 1 major])
                -- scope guard, as in the K branch
                if fab.wscopedB depth && fab.looseBVarsBounded 0 &&
                    fab.fvarLeaves.all
                      (fun l => major.fvarLeaves.contains l) then
                  -- synthetic-spine certification, as in the K branch
                  if ← iotaCerts r env depth false
                      (cvj.type.instantiateLevelParams
                        cvj.levelParams ust)
                      (tmaj.getAppArgs ++ [.proj T 0 major, .proj T 1 major]) then
                    -- the fabrication's type against the major's, then
                    -- proof irrelevance as the soundness certificate
                    if ← r.defeq depth tmaj (← r.inferIO depth fab) then
                      if ← proofIrrel r depth fab major then
                        pure fab
                      else pure major
                    else pure major
                  else pure major
                else pure major
              else pure major
            | _ => pure major
          else pure major
        | _ => pure major
      | _ => pure major
    | _ => pure major
  | _ => pure major

/-- Convert a literal major premise to constructor form: a `Nat`
literal one layer (`litToCtorIfNat`); a `String` literal to its
*reduced* constructor form — the reference kernels re-reduce after
`strLitToConstructor` (lean4lean `Inductive/Reduce.lean`, nanoda
`str_lit_to_ctor_reducing`) since `String.ofList` is a definition, not
a constructor.  An unsupported literal passes through (stuck; sound,
and unreachable for annotated input). -/
def litMajorToCtor (r : CoreFns m) (env : Env) (depth : Nat) :
    Expr → m Expr
  | .lit (.strVal s) =>
    if strLitSupported env then r.whnf depth (strLitToConstructor s)
    else pure (.lit (.strVal s))
  | e => pure (litToCtorIfNat env e)

/-- Convert a string-literal projection scrutinee to its *reduced*
constructor form — the references' proj expansion site (official
`reduce_proj_core`, `type_checker.cpp:383-384`; lean4lean
`TypeChecker.lean` proj clause; nanoda `tc.rs` `reduce_proj`): the
expansion's head `String.ofList` is a definition, so the whnf grinds it
to the real `String.ofByteArray` constructor form.  Only `String`
literals — no reference touches other scrutinees here.  An unsupported
literal passes through (stuck; sound, and unreachable for annotated
input). -/
def projLitToCtor (r : CoreFns m) (env : Env) (depth : Nat) :
    Expr → m Expr
  | .lit (.strVal s) =>
    if strLitSupported env then r.whnf depth (strLitToConstructor s)
    else pure (.lit (.strVal s))
  | e => pure e

/-- The major premise's preparation before a rule fires, in the
official kernel's order (`inductive_reduce_rec`,
`src/kernel/inductive.cpp`; lean4lean `Inductive/Reduce.lean:66-72`):

* at a K-flagged recursor the K rescue (`to_ctor_when_K`) runs on the
  **raw** major — it reads only the major's *type* and fabricates the
  constructor from it — and only then is the major head-normalized
  (and its literal converted; a no-op on a proof, kept for the
  site-by-site mirror);
* elsewhere the major is head-normalized first, its literal
  converted, and the structure-eta rescue (`to_ctor_when_structure`)
  tried on the reduct.

The two rescues live in one function (`majorToCtor`); the K branch is
reachable exactly at `recRuleK`, the eta branch never is there (an
inductive proposition fails its provably-nonzero guard), so the split
below dispatches each to its official site and neither is attempted
twice.

Why the order matters (2026-09-06, the Mathlib `decide`-over-`Rat`
frontier): with the whnf *first*, an `Eq.rec` whose major is a
theorem application — `Eq.ndrec … (Int.decEq._proof_1 a b h)` with
`h := Nat.eq_of_beq_eq_true …`, the shape `instDecidableEqRat`'s
`h ▸` produces — delta-unfolds the proofs and iota-grinds
`Nat.eq_of_beq_eq_true`'s `Nat.brecOn` tower unarily down the
`604800` literal: one knot level per `succ`, fuel exhaustion.  The
official order fabricates `Eq.refl` from the type (`a ≡ b` by the
`Nat` literal fast paths) and never opens either proof. -/
def prepareMajor (r : CoreFns m) (env : Env) (depth : Nat)
    (recName : Name) (rules : List RecRule) (major : Expr) : m Expr := do
  if recRuleK rules then
    let majorK ← majorToCtor mode r env depth recName rules major
    let major₀ ← r.whnf depth majorK
    litMajorToCtor r env depth major₀
  else
    let major₀ ← r.whnf depth major
    let major₁ ← litMajorToCtor r env depth major₀
    majorToCtor mode r env depth recName rules major₁

/-- One iota step: the expression is a stored recursor applied to
exactly its telescope (params, motives, minors, indices, major), the
major premise whnfs to a fully applied constructor with a matching
rule (a literal major converts to constructor form — see
`litMajorToCtor` —, a
stuck major may be rescued — see `majorToCtor`), and the spine is
certified against the recursor's own (pinned, annotated) type with
`iotaCerts` (per-slot infer+defeq; task #100 de-gating retired the
possibly-Prop annotation gate of tasks #49/#71 — unsound-to-model
under the domain-relative collapse, DESIGN.md).  The
result is the rule's rhs applied to the non-index prefix and the
constructor's fields; over-application is handled by the outer app
recursion. -/
def iotaRec (r : CoreFns m) (env : Env) (depth : Nat) (e : Expr) :
    m (Option Expr) := do
  match e.getAppFn with
  | .const c us =>
    match env.find? c with
    | some (.recInfo cv mI rP rules) =>
      let args := e.getAppArgs
      -- checker change #9: the recursor's level arity, guarded as
      -- `unfoldDefinition` guards it (`Core.lean:174`).  The official
      -- kernel tests this immediately before instantiating the rule's
      -- RHS (`src/kernel/inductive.h:105`, present since v4.0.0);
      -- lean4lean does the same (`Inductive/Reduce.lean:98`) and
      -- nanoda's `subst_expr_levels` asserts it.  Without it
      -- `rl.rhs.instantiateLevelParams cv.levelParams us` can leak a
      -- level parameter the subject never had.  Ungated: the reference has it
      -- unconditionally, so a mode gate would break parity.
      if args.length = mI + 1 ∧ us.length = cv.levelParams.length then
        -- the major's preparation (K rescue / whnf / literal / eta) in
        -- the official order — `prepareMajor`'s docstring
        let major ← prepareMajor mode r env depth c rules
          (args.getD mI (.bvar 0))
        match major.getAppFn with
        | .const cj usj =>
          match env.find? cj with
          | some (.ctorInfo cvj _ _) =>
            match rules.find? (fun r' => r'.ctor == cj) with
            | some rl =>
              let margs := major.getAppArgs
              -- the constructor's counts are read off the stored rule
              -- (install-computed); the defensive spine-length check
              -- stays
              if margs.length = rl.ctorParams + rl.nfields then
               -- A matched *inert* rule is a positive detection of an
               -- unsupported feature: the redex demands firing an
               -- uncertified nested-auxiliary rule (e.g.
               -- `Syntax.rec_1` on an `Array.mk` major with the
               -- nested certification absent).  Staying silently
               -- stuck would surface as a spurious *reject*
               -- downstream (defeq failure in the app rule), so
               -- decline here instead.
               if rl.fire = .inert then
                 throw (.notImplemented
                   "iota reduction over a nested auxiliary recursor rule")
               else
                -- The ι batch (2026-09-05): the two `stripPis` arity
                -- pins that stood here were an environment invariant
                -- re-checked per fire (every install route establishes
                -- them; the P lane bound and never used them) — deleted
                -- per the "invariants over runtime gates" ruling.
                --
                -- the constructor's levels and parameters must agree
                -- with the rule's comparands (canonical: the
                -- recursor's own instantiation and leading arguments;
                -- nested: the stored major-domain instantiations) —
                -- the firing mode was computed once at install
                -- (`Expr.recRulePlain` / the nested certification),
                -- never re-derived per fire
                if ← liftFueled "level comparison" (Level.isEquivList usj
                    (recFireComparands rl cv.levelParams us
                      cvj.levelParams args rP).1) then
                 -- the parameter comparison, run unless the rule is a
                 -- `.plain` one the installing route marked
                 -- `paramsBlind` (`RecRule.compareParams`)
                 if ← (if rl.compareParams then
                    defEqList r env depth (margs.take rl.ctorParams)
                      (recFireComparands rl cv.levelParams us
                        cvj.levelParams args rP).2
                    else pure true) then
                  -- the two telescope runs, *licensed* (`iotaCerts`'
                  -- docstring): the redex is a subterm of the subject.
                  -- The mode read is the β gate's accessor — the one
                  -- place a certificate-skip may read the validated
                  -- datum (`CheckMode.betaGate`'s docstring)
                  if ← iotaCerts r env depth mode.betaGate
                     (cv.type.instantiateLevelParams cv.levelParams us)
                     (args.take mI ++ [major]) then
                   if ← iotaCerts r env depth mode.betaGate
                      (cvj.type.instantiateLevelParams cvj.levelParams usj)
                      margs then
                    -- the recursor's index arguments must match the
                    -- constructor's canonical index tuple, where the
                    -- recursor has indices (`iotaIndexOk`)
                    if ← iotaIndexOk r env depth mI rP rl.ctorParams
                        (cvj.type.instantiateLevelParams cvj.levelParams usj)
                        margs ((args.take mI).drop rP) then
                      pure (some (Expr.mkAppN
                        (rl.rhs.instantiateLevelParams cv.levelParams us)
                        (args.take rP ++ margs.drop rl.ctorParams)))
                    else pure none
                   else pure none
                  else pure none
                 else pure none
                else pure none
              else pure none
            | none => pure none
          | _ => pure none
        | _ => pure none
      else pure none
    | _ => pure none
  | _ => pure none

/-- **The structural projection's certificate** (task #175 W6, the
squash-regime licence): the redex `proj_i (C p⃗ x⃗)` fires only after
its constructor spine is certified against `C`'s stored type at the
redex's own levels — `iotaCerts`, each argument's inferred type defeq
to its binder domain, the domains instantiated along the spine.  This
is what makes the rule sound-to-model at a squash instantiation: there
the constructor application is the point and so is every field
(every field of a non-`Prop`-declared family is a proposition where
the family is one, by the O5 bound; at a `Prop`-declared family the
fire guard says so of the projected field), and the certified fit is
what pins the selected argument to its domain — a grading alone pins
nothing at bit `0`.  In the graph regime the fit is redundant with
the application's grading, which the tower law consumes there.

The telescope certificate is the same per-argument `inferIO` + `defeq`
work the subject's run performed inside `inferSpine`.  The official
kernel's `reduce_proj` certifies nothing — this is a conformance
residue the model's projection step consumes.  The spine is a subterm of the
subject, so the certificate is *licensed* like the ι slot's
(`iotaCerts`' docstring): at the verified mode a `.never` binder's
certificate is skipped — every field binder of an ordinary `structure`. -/
def projCert (r : CoreFns m) (env : Env) (depth : Nat) (lic : Bool)
    (c : Name) (us : List Level) (args : List Expr) : m Bool := do
  match env.find? c with
  | some (.ctorInfo cvC _ _) =>
    iotaCerts r env depth lic
      (cvC.type.instantiateLevelParams cvC.levelParams us) args
  | _ => pure false

/-- **The fire certificate as the mode runs it** (parity mirrors
official, 2026-09-06).  The P core (`verified = true`) certifies the
constructor spine (`projCert`, licensed by the mode's β gate) — the
model's licence for the fire at a squash instantiation.  The parity
core is the official kernel's: `reduce_proj` reduces every
constructor redex with no certificate (`type_checker.cpp`), so at
`verified = false` no certificate runs and the rule fires
unconditionally.  The trusted lane stays an accept-superset of the P
lane, which is all the agreement floor
(`Verify/Cached/AgreeFloor.lean`) asks of it. -/
def projCertAt (r : CoreFns m) (env : Env) (depth : Nat) (verified lic : Bool)
    (c : Name) (us : List Level) (args : List Expr) : m Bool :=
  if verified then projCert r env depth lic c us args else pure true

/-- **The projection rule on a reduced scrutinee** (the official
kernel's `reduce_proj_core`): `proj_i (ctor p⃗ x⃗) ↦ x_i`, driven by the
projection table (never by basis names) — the table entry for
(structName, i) supplies the constructor, the counts and the
possibly-Prop level guard.  A string-literal scrutinee first expands to
its reduced constructor form (`projLitToCtor`, official: `whnf
(string_lit_to_constructor c)`).  At the verified mode the fire is
certified (`projCertAt`: the constructor spine against the
constructor's stored type, task #175 W6; official certifies nothing).
`none` when the rule does not fire.  Callers: `whnfCoreBody`'s `.proj`
clause and `lazyDeltaProjReduction`. -/
def reduceProjCore (r : CoreFns m) (env : Env) (depth : Nat) (sn : Name)
    (i : Nat) (c : Expr) : m (Option Expr) := do
  let c ← projLitToCtor r env depth c
  match env.findProj? sn i with
  | some entry =>
    match c.getAppFn with
    | .const k us =>
      let args := c.getAppArgs
      if k = entry.ctor ∧ i < entry.numFields ∧
          args.length = entry.numParams + entry.numFields ∧
          us.length = entry.levelParams.length ∧
          entry.fireOk us = true then
        -- Task #100 de-gating: the former nonzero-sort gate is
        -- unsound-to-model under the domain-relative collapse, so the
        -- certificate runs unconditionally at the verified mode; the
        -- trusted mode runs none (`projCertAt`).
        if ← projCertAt r env depth mode.verifiedChecks mode.betaGate k us args then
          pure (some (args.getD (entry.numParams + i) (.bvar 0)))
        else pure none
      else pure none
    | _ => pure none
  | none => pure none

/-- The head-normalization body: beta (with the per-redex argument
certificate, unconditional since the task-#100 de-gating), iota (with
the stuck-major machinery) and the native basis pair projection — but
**no delta**; unfolding happens in the `whnf` loop.  Values (sorts,
binders, constants, literals) return themselves.

`cheap` is the official kernel's `cheap_proj` (`whnf_core(e,
cheap_rec = false, cheap_proj)`): a projection's scrutinee is reduced
with `whnfCore` itself instead of `whnf`, and the flag propagates to
every recursive head normalization.  `whnf` runs the full mode;
definitional equality runs the cheap mode on its entry and after every
lazy-delta unfolding, so that `a.i =?= b.i` compares `a =?= b` before
reducing either scrutinee (`tests/e2e/src/proj_cheap_struct.lean`). -/
def whnfCoreBody (r : CoreFns m) (env : Env) : Bool → Nat → Expr → m Expr :=
  fun cheap depth e =>
    match e with
    | .sort u => pure (.sort u)
    | .fvar idx ty => pure (.fvar idx ty)
    | .forallE ty body bi => pure (.forallE ty body bi)
    | .lam ty body mb => pure (.lam ty body mb)
    | .const n us => pure (.const n us)
    | .lit l => pure (.lit l)
    | .app f a => do
      match ← r.whnfCore cheap depth f with
      | .lam ty body mb => do
        -- Certify the argument against the domain before reducing
        -- (the soundness proof needs `⟦a⟧ ∈ ⟦ty⟧` at every level
        -- assignment).  An uncertified redex stays stuck — sound, and
        -- unreachable for well-typed input.  Task #100 de-gating: the
        -- former possibly-Prop annotation gate (skip the certificate
        -- at a provably nonzero codomain sort) is unsound-to-model
        -- under the domain-relative collapse (DESIGN.md), so the
        -- certificate now runs unconditionally — except at the task
        -- #161 β gate, which reads a *validated* annotation instead
        -- (`betaGateFires`, and only at `mode.betaGate`).
        if betaGateFires mode mb.pw then
          r.whnfCore cheap depth (body.instantiate1 a)
        else do
          -- task #172 B4: the certificate's inference runs at the io
          -- grade — the argument sits inside a subject whose WellDenotedV
          -- the P claims carry (the user's criterion: WellDenoted is
          -- around), and official's whnf never infers here at all
          let ta ← r.inferIO depth a
          if ← r.defeq depth ta ty then
            r.whnfCore cheap depth (body.instantiate1 a)
          else pure (.app (.lam ty body mb) a)
      | f' => do
        match ← iotaRec mode r env depth (.app f' a) with
        | some e'' => r.whnfCore cheap depth e''
        | none => pure (.app f' a)
    | .proj sn i pe => do
      -- official `reduce_proj`: the scrutinee by `whnf`, or by the
      -- cheap `whnf_core` in the cheap mode; then `reduce_proj_core`.
      -- When it does not fire, the INPUT is returned — its scrutinee as
      -- it was, not the WHNF computed here (official `whnf_core`:
      -- `reduce_proj` fails, `r = e`).  The WHNF has lost the
      -- scrutinee's head constant, and with it the defeq check's
      -- arguments-first comparison of `a.i =?= b.i` (lane KEEPPROJ:
      -- exponential on the self-check's `nestRoot_datF._f`,
      -- `tests/e2e/src/proj_stuck_struct.lean`).
      let c ← if cheap then r.whnfCore true depth pe else r.whnf depth pe
      match ← reduceProjCore mode r env depth sn i c with
      | some m' => r.whnfCore cheap depth m'
      | none => pure (.proj sn i pe)
    | .letE _ _ _ =>
      -- **Unreachable by construction** (task #241).  The former ζ step
      -- (official kernel `whnf_core`, `case expr_kind::Let`; nanoda
      -- `whnf_no_unfolding_aux` `Let`; lean4lean `whnfCore'` `.letE`)
      -- is gone: every expression reduction sees is annotate output or
      -- stored rule data, and both are let-free, because
      -- `annotateBody`'s own `.letE` clause runs the official
      -- `infer_let` triple and returns the ζ *reduct* (task #217).
      -- A `letE` here is an invariant violation, not an unsupported
      -- feature, so it is `.internal` (exit 3), never a decline and
      -- never a silent accept.
      throw (.internal "whnfCore: `let` in an annotated expression")
    | .bvar _ =>
      throw (.notImplemented "whnf beyond the supported fragment")

/-- Step budget of the `whnfCore` head-normalization loop (task #106).
Beta, iota and projection steps are *iteration*: the interned
`whnfCoreLoopI` runs them on this budget instead of charging each step
to the shared recursion-depth budget (and to the native stack).  The
`Expr`-level specification below stays chained — the refinement bridge
reproduces a loop run by the chained recursion *at some knot fuel*
(`ConLeche/Verify/BetaSpine.lean`), so the specification and everything
above it are unchanged. -/
@[irreducible] def whnfCoreLoopFuel : Nat := 1000000

/-- Step budget of the `whnf` reduction loop (lean4lean's
`FuelConfig.whnf`, same value).  Literal-acceleration and delta steps
are *iteration*, not recursion: the official kernel's loop is a
`while (true)` and lean4lean's is a fixed-fuel local loop.  Task #106:
routing them through the knot instead charged every unfolding step to
the shared *recursion depth* budget (and to the native stack), so a
long-but-perfectly-ordinary unfolding chain exhausted `checkFuel`. -/
@[irreducible] def whnfLoopFuel : Nat := 100000

/-- One iteration of the reduction loop (the official kernel's `whnf`
body, lean4lean's `whnf'` loop body): head-normalize, try literal
acceleration, unfold one definition — and hand the reduct to the
loop's continuation `k`.  As everywhere in this module, the body never
calls itself: the continuation is abstracted exactly like the record
`r`, so every lemma about the body is proven once, with a hypothesis
about `k`, and the loop lemma is one induction on the budget. -/
def whnfStep (r : CoreFns m) (env : Env) (depth : Nat)
    (k : Expr → m Expr) (e : Expr) : m Expr := do
  let e₁ ← r.whnfCore false depth e
  match ← reduceNat r env depth e₁ with
  | some e₂ => k e₂
  | none =>
    match unfoldDefinition env e₁ with
    | some e₂ => k e₂
    | none => pure e₁

/-- The reduction loop: iterate `whnfStep` on its own step budget, so
the whole chain costs one knot level however many steps it takes. -/
def whnfLoop (r : CoreFns m) (env : Env) (depth : Nat) :
    Nat → Expr → m Expr
  | 0, _ => throw (.internal "fuel exhausted: whnf loop")
  | n + 1, e => whnfStep r env depth (whnfLoop r env depth n) e

/-- The reduction loop's body: run `whnfLoop` at its own step budget. -/
def whnfBody (r : CoreFns m) (env : Env) : Nat → Expr → m Expr :=
  fun depth e => whnfLoop r env depth whnfLoopFuel e

/-- Ensure `e` (the type of some expression) is a sort, returning its
level. -/
def ensureSort (r : CoreFns m) (_env : Env) (depth : Nat) (e : Expr) :
    m Level := do
  match ← r.whnf depth e with
  | .sort u => pure u
  | _ => throw (.invalid "expected a sort")

/-- The inference body — **infer-only**: the application rule's
argument check ran once, in the annotation pass, and is trusted here
(so speculative inference inside reduction cannot reject). -/
def inferBody (r : CoreFns m) (env : Env) : Nat → Expr → m Expr :=
  fun depth e => do
    match e with
    | .sort u => pure (.sort (.succ u))
    | .fvar idx ty =>
      -- Scope check at the leaf of a traversal that happens anyway
      -- (O(1); never a fresh walk): a free variable must refer to an
      -- enclosing opened binder.  On raw (closed) input at depth 0 this
      -- rejects any `fvar` outright; internally the checker only opens
      -- variables below the ambient depth, so for disciplined calls the
      -- check always passes (and inference success implies
      -- well-scopedness, the base case of the cache discipline).
      if idx < depth then pure ty
      else throw (.invalid "free variable out of scope")
    | .const n us => do
      match env.find? n with
      | none => throw (unknownConstError n)
      | some ci =>
        -- a projection table is not a term (task #175 W4c): `.proj`
        -- nodes read it, no constant names it
        unless !ci.isTowerEntry do
          throw (.invalid s!"projection table entry used as a constant {n}")
        let cv := ci.toConstantVal
        unless us.length = cv.levelParams.length do
          throw (.invalid s!"incorrect number of universe levels for {n}")
        pure (cv.type.instantiateLevelParams cv.levelParams us)
    | .lit (.natVal _) => do
      if natLitSupported env then pure (.const natName [])
      else throw (.invalid "Nat literal without the Nat basis declarations")
    | .lit (.strVal _) => do
      -- a string literal types as `String` (the reference kernels'
      -- `Literal.typeName`); without the pinned support declarations
      -- this is a positively detected unsupported feature: decline
      if strLitSupported env then pure (.const stringName [])
      else throw (.notImplemented
        "string literals before the String support declarations")
    | .forallE ty body mb => do
      -- The ∀-formation rule, official-kernel style (task #100 stage 6):
      -- the codomain sort is *inferred* from the opened body.  Task
      -- #161: at the verified modes the node's prop-ness annotation is
      -- VALIDATED against the inferred codomain sort — the datum is
      -- canonical, so `==` decides zero-ness agreement, and a mismatch is a decline
      -- (a positively detected annotation the checker cannot certify),
      -- never a reject.  The annotation is never read by reduction.
      match ← r.whnf depth (← r.infer depth ty) with
      | .sort u => do
        let v ← ensureSort r env (depth + 1)
          (← r.infer (depth + 1) (body.instantiate1 (.fvar depth ty)))
        if mode.verifiedChecks then
          unless Level.zeronessOf v == mb.pw do
            throw (.notImplemented "sort-annotation mismatch (forall-cod)")
        pure (.sort (.imax u v))
      | _ => throw (.invalid "expected a sort")
    | .lam ty body mb => do
      -- The domain must be a type (and the model needs its
      -- interpretation defined), exactly as in the ∀ rule.
      match ← r.whnf depth (← r.infer depth ty) with
      | .sort _ => do
        let bt ← r.infer (depth + 1)
          (body.instantiate1 (.fvar depth ty))
        -- The *codomain* sort, at the verified modes only (task #152,
        -- restoring the I6/I7 symmetry task #100 stage 6 broke): the
        -- ∀ clause's own `ensureSort` move, on the body's inferred
        -- type.  It is what the model's annotation invariant needs —
        -- the codomain's sort — and what no metatheorem supplies:
        -- validity for `Infer` ("every inferred type has a sort") is
        -- refuted at the application clause, and nothing else in the
        -- checker computes a λ's codomain sort, so the fact has to be
        -- computed here.  The reference kernel's `infer_lambda`
        -- does not run it, so `.trusted` — the trusted lane —
        -- does not either.
        --
        -- It fires once per λ **chain**, at the innermost binder (the
        -- `!body.isLam` guard).  At an outer binder the codomain is
        -- the inner λ's own `∀`-type, whose sort is `imax` of the
        -- inner domain's (checked at that binder) and the chain's
        -- (checked here) — so no fact is lost, and this is the
        -- granularity the interned telescope loop (task #72) can
        -- reproduce: it opens a whole λ-chain in bulk and never
        -- materializes the intermediate opened types.
        if mode.verifiedChecks then
          match body.lamPw with
          | some pwI =>
            -- Task #161, the chain rule: an outer λ's codomain is the
            -- inner λ's own ∀-type, whose sort's zero-ness is the
            -- inner codomain's — datum equality with the neighbour,
            -- no inference (this dissolves the #152 chain guard's
            -- information loss: the per-node fact is now checked at
            -- every node, at O(1) each).
            unless mb.pw == pwI do
              throw (.notImplemented
                "sort-annotation mismatch (lam-cod-chain)")
          | none =>
            -- The innermost binder: the task-#152 codomain-sort
            -- computation, now also validating the node's annotation.
            -- task #172 B4: the type-of-a-type leaf at the io grade
            -- (the recursive call just established the body type)
            let btt ← r.inferIO (depth + 1) bt
            let vb ← ensureSort r env (depth + 1) btt
            unless Level.zeronessOf vb == mb.pw do
              throw (.notImplemented
                "sort-annotation mismatch (lam-cod-leaf)")
        pure (.forallE ty (bt.abstract1 depth) mb)
      | _ => throw (.invalid "expected a sort")
    | .app f a => do
      let tf ← r.infer depth f
      match ← r.whnf depth tf with
      | .forallE ty body _mt => do
        -- Per-argument re-check (task #100 de-gating: the former
        -- possibly-Prop annotation gate of task #49 is unsound-to-model
        -- under the domain-relative collapse, so the certificate runs
        -- unconditionally; the soundness proof needs `⟦a⟧ ∈ ⟦ty⟧`).
        let ta ← r.infer depth a
        unless ← r.defeq depth ta ty do
          throw (.invalid "application type mismatch")
        pure (body.instantiate1 a)
      | _ => throw (.invalid "function expected")
    | .proj sn i pe => do
      -- A `.proj` node is typed by its projection-table entry: the
      -- stored body, level-instantiated at the subject type's levels
      -- and instantiated at its arguments and the subject (task #175
      -- S1).  Only stored table entries type bare nodes (task #175
      -- W6: the pinned pair entries and their computed two-member
      -- fast path are retired; tower-flag: every stored table is a
      -- real one).
      let te ← r.whnf depth (← r.infer depth pe)
      match te.getAppFn with
      | .const T us =>
        match env.findProj? T i with
        | some entry =>
          -- task #175 wiring W5: the node's struct name must be the
          -- subject type's head (official `infer_proj`'s
          -- `const_name(I) == proj_sname(e)`); the readings key the
          -- table on the node's name, the checker on the head's
          if T = sn ∧ te.getAppArgs.length = entry.numParams ∧
              us.length = entry.levelParams.length then do
            -- the official `infer_proj` restriction (task #175
            -- W4c/O4): at a `Prop`-declared structure the field —
            -- and every earlier field a later field uses — must be
            -- a proposition at this instantiation; the entry's
            -- guard level joins exactly those sorts
            if Level.isEquiv entry.structSort .zero == some true then
              unless Level.isEquiv
                  (Level.subst entry.levelParams us entry.fieldSort) .zero
                  == some true do
                throw (.invalid
                  "projection from a propositional structure must be a proposition")
            -- the body at the subject type's arguments and the
            -- subject, one `instantiateList` (task #175 S1)
            pure (entry.typeAt us te.getAppArgs pe)
          else throw (.notImplemented "projection without a native entry")
        | none => throw (.notImplemented "projection without a native entry")
      | _ => throw (.notImplemented "projection without a native entry")
    | .letE _ _ _ =>
      -- **Unreachable by construction** (task #241).  The official
      -- kernel's `infer_let` triple (`!infer_only`) is not lost: it is
      -- `annotateBody`'s `.letE` clause, which is the one pass that
      -- meets a `let` from the stream and which returns the ζ reduct
      -- (task #217).  Inference therefore only ever sees annotate
      -- output, which is let-free; see the `whnfCore` arm.
      throw (.internal "inferType: `let` in an annotated expression")
    | .bvar _ =>
      throw (.notImplemented "inferType beyond the supported fragment")

/-- **The io inference body** (task #161 stage 2 / task #170): `inferBody`
with one clause changed — the application rule's per-argument
certificate is skipped when the ∀'s validated annotation licenses it
(`ConLeche/Kernel/CoreIO.lean`'s module docstring holds the design
record).  The gate wraps the *test* only; the computed type
(`body.instantiate1 a`) and the "function expected" rejection are
`inferBody`'s, verbatim, so the lane is annotation-blind in its
results (law 1 (iii)).  Recursion is through `r.infer`: the io knot
ties this body to an io-grade record (`CoreFns.ioView` at the knot's
io slot, or `coreKnotIO`'s leaf lane), which is how the grade
propagates — official's `infer_type_core(e, infer_only)` passing
`infer_only` to every recursive call.

Moved here from `ConLeche/Kernel/CoreIO.lean` (task #172 B4) so the knot
can tie the io slot; the definition is byte-identical to the io-license
batch's. -/
def inferBodyIO (r : CoreFns m) (env : Env) : Nat → Expr → m Expr :=
  fun depth e => do
    match e with
    | .sort u => pure (.sort (.succ u))
    | .fvar idx ty =>
      if idx < depth then pure ty
      else throw (.invalid "free variable out of scope")
    | .const n us => do
      match env.find? n with
      | none => throw (unknownConstError n)
      | some ci =>
        -- a projection table is not a term (task #175 W4c): `.proj`
        -- nodes read it, no constant names it
        unless !ci.isTowerEntry do
          throw (.invalid s!"projection table entry used as a constant {n}")
        let cv := ci.toConstantVal
        unless us.length = cv.levelParams.length do
          throw (.invalid s!"incorrect number of universe levels for {n}")
        pure (cv.type.instantiateLevelParams cv.levelParams us)
    | .lit (.natVal _) => do
      if natLitSupported env then pure (.const natName [])
      else throw (.invalid "Nat literal without the Nat basis declarations")
    | .lit (.strVal _) => do
      if strLitSupported env then pure (.const stringName [])
      else throw (.notImplemented
        "string literals before the String support declarations")
    | .forallE ty body mb => do
      match ← r.whnf depth (← r.infer depth ty) with
      | .sort u => do
        let v ← ensureSort r env (depth + 1)
          (← r.infer (depth + 1) (body.instantiate1 (.fvar depth ty)))
        if mode.verifiedChecks then
          unless Level.zeronessOf v == mb.pw do
            throw (.notImplemented "sort-annotation mismatch (forall-cod)")
        pure (.sort (.imax u v))
      | _ => throw (.invalid "expected a sort")
    | .lam ty body mb => do
      -- Task #168: no domain-sort run at the io grade —
      -- official's `infer_lambda` skips it at `infer_only`
      -- (`type_checker.cpp:131`), and the model proof
      -- never consumes it: the domain's grading comes from the
      -- premise (`WellDenoted.hoist_lam`).  The codomain validation stays
      -- — it is what makes the λ datum trustworthy.
      let bt ← r.infer (depth + 1)
        (body.instantiate1 (.fvar depth ty))
      if mode.verifiedChecks then
        match body.lamPw with
        | some pwI =>
          unless mb.pw == pwI do
            throw (.notImplemented
              "sort-annotation mismatch (lam-cod-chain)")
        | none =>
          let btt ← r.infer (depth + 1) bt
          let vb ← ensureSort r env (depth + 1) btt
          unless Level.zeronessOf vb == mb.pw do
            throw (.notImplemented
              "sort-annotation mismatch (lam-cod-leaf)")
      pure (.forallE ty (bt.abstract1 depth) mb)
    | .app f a => do
      let tf ← r.infer depth f
      match ← r.whnf depth tf with
      | .forallE ty body mt => do
        -- **THE io SITE.**  At a ∀ whose datum is `never` the
        -- certificate is dead weight: the premise-form io claim
        -- derives `⟦a⟧ ∈ ⟦ty⟧` from the subject's own `WellDenoted` app
        -- slot (`io_domain_transfer` + `piR_dom_unique`,
        -- side-condition free).  At a possibly-zero datum the
        -- certificate runs unconditionally — the squash regime's
        -- membership is model-class-wide unrecoverable
        -- (`io_membership_fails_at_squash`), and that fence is
        -- absolute.  The read is the DATUM ALONE (the licence ruling
        -- of 2026-09-06): it used to carry a `mode.verifiedChecks`
        -- conjunct, which inverted the trusted mode into running a
        -- certificate the verified mode skips.  Validating the datum
        -- is certification-only work; consuming it is not.  The
        -- licensing theorem never read the mode either.
        unless mt.pw.isNever do
          let ta ← r.infer depth a
          unless ← r.defeq depth ta ty do
            throw (.invalid "application type mismatch")
        pure (body.instantiate1 a)
      | _ => throw (.invalid "function expected")
    | .proj sn i pe => do
      let te ← r.whnf depth (← r.infer depth pe)
      match te.getAppFn with
      | .const T us =>
        match env.findProj? T i with
        | some entry =>
          -- task #175 wiring W5: the node's struct name must be the
          -- subject type's head (official `infer_proj`'s
          -- `const_name(I) == proj_sname(e)`); the readings key the
          -- table on the node's name, the checker on the head's
          if T = sn ∧ te.getAppArgs.length = entry.numParams ∧
              us.length = entry.levelParams.length then do
            -- the official `infer_proj` restriction (task #175
            -- W4c/O4), as in `inferBody`
            if Level.isEquiv entry.structSort .zero == some true then
              unless Level.isEquiv
                  (Level.subst entry.levelParams us entry.fieldSort) .zero
                  == some true do
                throw (.invalid
                  "projection from a propositional structure must be a proposition")
            -- the body at the arguments and the subject, as in
            -- `inferBody` (task #175 S1)
            pure (entry.typeAt us te.getAppArgs pe)
          else throw (.notImplemented "projection without a native entry")
        | none => throw (.notImplemented "projection without a native entry")
      | _ => throw (.notImplemented "projection without a native entry")
    | .letE _ _ _ =>
      -- unreachable by construction, as in `inferBody` (task #241)
      throw (.internal "inferType: `let` in an annotated expression")
    | .bvar _ =>
      throw (.notImplemented "inferType beyond the supported fragment")

/-- **The eq-true shortcut** (the divergence audit's E2): official
`is_def_eq_core`'s second clause (`type_checker.cpp:1093-1101`) — when
the right side is the constant `Bool.true` and the left side has no
free variables, the left side is fully head-normalised (`whnf`, the
cached loop) and the verdict is `true` iff the reduct is `Bool.true`; on
failure the comparison continues.  Only the reduction is here; the
guard is `defeqBody`'s.
Verdict-neutral against lazy delta (a `whnf` reduct is what the
unfolding loop reaches, one step at a time), one memoised `whnf`
instead of one loop iteration per unfolding. -/
def boolTrueShortcut (r : CoreFns m) (depth : Nat) (a : Expr) : m Bool := do
  let w ← r.whnf depth a
  pure w.isBoolTrue

/-- Levels-and-spine congruence for two applications of the same
stored constant — the lazy delta *same-head short-circuit* (the
official kernel's `try_eq_const_app`): before unfolding both sides of
`f as ≡ f bs`, try pairwise definitional equality of the levels and
the spine arguments.  A `false` verdict is never final — the caller
falls back to unfolding — so an inconclusive level comparison simply
answers `false` here. -/
def defeqSpine (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool := do
  match a.getAppFn with
  | .const n us =>
    match b.getAppFn with
    | .const n' us' =>
      if n = n' ∧ a.getAppArgs.length = b.getAppArgs.length then
        match Level.isEquivList us us' with
        | some true => defEqList r env depth a.getAppArgs b.getAppArgs
        | _ => pure false
      else pure false
    | _ => pure false
  | _ => pure false

/-- **The easy cases** (the official kernel's `quick_is_def_eq`): the
syntactic fast path, and the pairs whose verdict is decided on the spot
— two sorts (level equivalence), two literals, two `∀`s and two `λ`s
(binder congruence: domains, then bodies opened at the RIGHT domain,
then, at the verified modes, the prop-ness annotations, task #161).
`none` is "not an easy case".  `defeqBody` runs it after the cheap
head normalization, and `lazyDeltaStep` after every unfolding.  (The
positive `is_def_eq` cache of official's version is the cached core's
`defeq` memo.)

The annotation comparison runs LAST — only a pair that is otherwise
definitionally equal can reach it, so a firing mismatch is exactly the
cross-provenance coherence corner, declined loudly.  (The official
kernel compares no annotations.) -/
def quickDefEq (r : CoreFns m) (depth : Nat) (a b : Expr) : m (Option Bool) :=
  if a == b then pure (some true) else
  match a, b with
  | .sort u, .sort v => do
    let ok ← liftFueled "level comparison" (Level.isEquiv u v)
    pure (some ok)
  | .lit l₁, .lit l₂ => pure (some (l₁ == l₂))
  | .forallE ty₁ body₁ m₁, .forallE ty₂ body₂ m₂ => do
    unless ← r.defeq depth ty₁ ty₂ do return some false
    unless ← r.defeq (depth + 1)
        (body₁.instantiate1 (.fvar depth ty₂))
        (body₂.instantiate1 (.fvar depth ty₂)) do return some false
    if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
      throw (.notImplemented "sort-annotation mismatch (defeq-forall)")
    pure (some true)
  | .lam ty₁ body₁ m₁, .lam ty₂ body₂ m₂ => do
    unless ← r.defeq depth ty₁ ty₂ do return some false
    unless ← r.defeq (depth + 1)
        (body₁.instantiate1 (.fvar depth ty₂))
        (body₂.instantiate1 (.fvar depth ty₂)) do return some false
    if mode.verifiedChecks && !(m₁.pw == m₂.pw) then
      throw (.notImplemented "sort-annotation mismatch (defeq-lam)")
    pure (some true)
  | _, _ => pure none

/-- `Nat.zero` or the literal `0` (official `is_nat_zero`). -/
def Expr.isNatZero : Expr → Bool
  | .lit (.natVal 0) => true
  | .const c [] => c == natZeroName
  | _ => false

/-- Is `e` a literal? -/
def Expr.isLit : Expr → Bool
  | .lit _ => true
  | _ => false

/-- The predecessor of a successor form (official `is_nat_succ`): a
nonzero literal, or `Nat.succ x`. -/
def Expr.natPred? : Expr → Option Expr
  | .lit (.natVal (n + 1)) => some (.lit (.natVal n))
  | .app (.const c []) x => if c = natSuccName then some x else none
  | _ => none

/-- **Offsets** (the official kernel's `is_def_eq_offset`, the first
check of each lazy-delta iteration): two zeros are equal, two
successor forms compare their predecessors.  Two literals never reach
it (`quickDefEq` decides them first), and are left out so that the
predecessor comparison only ever pairs a literal with a `Nat.succ`. -/
def defeqOffset (r : CoreFns m) (depth : Nat) (a b : Expr) : m (Option Bool) :=
  if a.isNatZero && b.isNatZero then pure (some true) else
  if a.isLit && b.isLit then pure none else
  match a.natPred?, b.natPred? with
  | some x, some y => do
    let ok ← r.defeq depth x y
    pure (some ok)
  | _, _ => pure none

/-- Is the head of the application spine a projection? -/
def Expr.headIsProj (e : Expr) : Bool :=
  match e.getAppFn with
  | .proj _ _ _ => true
  | _ => false

/-- Official `try_unfold_proj_app`: a term whose head is a projection
is put through the FULL `whnfCore` (the scrutinee reduced with
`whnf`); `some` whenever that changed it — also when only the
scrutinee moved and the projection did not fire. -/
def tryUnfoldProjApp (r : CoreFns m) (depth : Nat) (e : Expr) : m (Option Expr) :=
  if e.headIsProj then do
    let e' ← r.whnfCore false depth e
    if e' == e then pure none else pure (some e')
  else pure none

/-- The outcome of one lazy-delta step (official `reduction_status`):
continue with the reduced pair, or a verdict, or "neither side
unfolds". -/
inductive DeltaStep where
  | cont (a b : Expr)
  | eq
  | diff
  | unknown

/-- The end of a lazy-delta step: `quick_is_def_eq` on the new pair. -/
def deltaQuick (r : CoreFns m) (depth : Nat) (a b : Expr) : m DeltaStep := do
  match ← quickDefEq mode r depth a b with
  | some true => pure .eq
  | some false => pure .diff
  | none => pure (.cont a b)

/-- **One lazy-delta step** (the official kernel's
`lazy_delta_reduction_step`): read the two heads' unfoldability and
hints, unfold the side with the greater height (both at equal hints,
after the same-head argument shortcut at equal *regular* hints), put
the unfolded side through the cheap `whnfCore`, and finish with
`quickDefEq`.  With one side unfoldable, a projection application on
the other side is reduced instead (`tryUnfoldProjApp`): `expensive =?=
inst.1 a` must not unfold `expensive` lazily to the bottom.

The same-head shortcut's `sameRegular` guard mirrors the reference
kernels and is deliberate: at equal `abbrev` (or `opaque`) hints both
sides unfold eagerly instead (abbrevs are meant to unfold; a spine
attempt on abbrev-headed applications risks reduction bombs).  Do not
generalize it.  The `.unknown` exits under a successful
`unfoldableHead` are unreachable (`unfoldableHead env e` is
`(unfoldDefinition env e).isSome`). -/
def lazyDeltaStep (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m DeltaStep := do
  match unfoldableHead env a, unfoldableHead env b with
  | false, false => pure .unknown
  | true, false =>
    match ← tryUnfoldProjApp r depth b with
    | some b₂ => deltaQuick mode r depth a b₂
    | none =>
      match unfoldDefinition env a with
      | some a₂ => do
        let a₃ ← r.whnfCore true depth a₂
        deltaQuick mode r depth a₃ b
      | none => pure .unknown
  | false, true =>
    match ← tryUnfoldProjApp r depth a with
    | some a₂ => deltaQuick mode r depth a₂ b
    | none =>
      match unfoldDefinition env b with
      | some b₂ => do
        let b₃ ← r.whnfCore true depth b₂
        deltaQuick mode r depth a b₃
      | none => pure .unknown
  | true, true =>
    let ha := headHint env a
    let hb := headHint env b
    if ReducibilityHint.lt hb ha then
      match unfoldDefinition env a with
      | some a₂ => do
        let a₃ ← r.whnfCore true depth a₂
        deltaQuick mode r depth a₃ b
      | none => pure .unknown
    else if ReducibilityHint.lt ha hb then
      match unfoldDefinition env b with
      | some b₂ => do
        let b₃ ← r.whnfCore true depth b₂
        deltaQuick mode r depth a b₃
      | none => pure .unknown
    else if ← (if ReducibilityHint.sameRegular ha hb && sameConstHeads a b then
        defeqSpine r env depth a b else pure false) then pure .eq
    else
      match unfoldDefinition env a, unfoldDefinition env b with
      | some a₂, some b₂ => do
        let a₃ ← r.whnfCore true depth a₂
        let b₃ ← r.whnfCore true depth b₂
        deltaQuick mode r depth a₃ b₃
      | _, _ => pure .unknown

/-- The outcome of the lazy-delta loop: a verdict, or the pair it got
stuck on (official `lazy_delta_reduction` returns `l_undef` and updates
`t_n`, `s_n`). -/
inductive LazyRes where
  | verdict (v : Bool)
  | unknown (a b : Expr)

/-- Step budget of the two lazy-delta loops (lean4lean's
`FuelConfig.lazyDelta`, generously sized).  Exhaustion is an internal
error, never a verdict. -/
@[irreducible] def defeqLoopFuel : Nat := 100000

/-- **The lazy-delta loop** (the official kernel's
`lazy_delta_reduction`): per iteration the offset check, the literal
acceleration — guarded on both sides being free of free variables, as
in the official kernel and lean4lean (an open `Int32`/`Int64` pair
would otherwise delta-grind the `Nat.brecOn` tower; the whnf-loop
`reduceNat` stays unguarded, as the official whnf loop is) — whose
reduct restarts the comparison (`defeq`, official `is_def_eq_core`),
then one `lazyDeltaStep`.  Each unfolding is one iteration of this
loop on its own step budget (task #106: not one unit of the knot's
recursion depth). -/
def lazyDeltaReduction (r : CoreFns m) (env : Env) (depth : Nat) :
    Nat → Expr → Expr → m LazyRes
  | 0, _, _ => throw (.internal "fuel exhausted: defeq loop")
  | n + 1, a, b => do
    match ← defeqOffset r depth a b with
    | some v => pure (.verdict v)
    | none =>
    match ← (if !a.hasFvar && !b.hasFvar then reduceNat r env depth a
        else pure none) with
    | some a₂ => do
      let v ← r.defeq depth a₂ b
      pure (.verdict v)
    | none =>
    match ← (if !a.hasFvar && !b.hasFvar then reduceNat r env depth b
        else pure none) with
    | some b₂ => do
      let v ← r.defeq depth a b₂
      pure (.verdict v)
    | none =>
    match ← lazyDeltaStep mode r env depth a b with
    | .cont a' b' => lazyDeltaReduction r env depth n a' b'
    | .eq => pure (.verdict true)
    | .diff => pure (.verdict false)
    | .unknown => pure (.unknown a b)

/-- **`a.i =?= b.i` by its scrutinees** (the official kernel's
`lazy_delta_proj_reduction`): lazy-delta steps on the two scrutinees;
when neither unfolds any more (or the step found them different), the
projection is tried on both (`reduceProjCore`) and only the projected
fields are compared; failing that, the scrutinees themselves. -/
def lazyDeltaProjReduction (r : CoreFns m) (env : Env) (depth : Nat)
    (sn : Name) (i : Nat) : Nat → Expr → Expr → m Bool
  | 0, _, _ => throw (.internal "fuel exhausted: lazy delta projection loop")
  | n + 1, a, b => do
    match ← lazyDeltaStep mode r env depth a b with
    | .cont a' b' => lazyDeltaProjReduction r env depth sn i n a' b'
    | .eq => pure true
    | .diff | .unknown =>
      match ← reduceProjCore mode r env depth sn i a with
      | some x =>
        match ← reduceProjCore mode r env depth sn i b with
        | some y => r.defeq depth x y
        | none => r.defeq depth a b
      | none => r.defeq depth a b

/-- The proj/proj check of `is_def_eq_core`: two projections at the
same slot go through `lazyDeltaProjReduction` on their scrutinees. -/
def defeqProjPair (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool :=
  match a, b with
  | .proj s₁ i₁ e₁, .proj s₂ i₂ e₂ =>
    if s₁ == s₂ && i₁ == i₂ then
      lazyDeltaProjReduction mode r env depth s₁ i₁ defeqLoopFuel e₁ e₂
    else pure false
  | _, _ => pure false

/-- **The stuck comparison** (the tail of the official kernel's
`is_def_eq_core`, after lazy delta, the proj/proj check and the full
`whnf_core` restart): the same constant at equivalent levels, the same
free variable, a string literal against `String.ofList`
(`try_string_lit_expansion`), the application spine
(`is_def_eq_app`), η on a one-sided λ; every failing arm ends in
`stuckIrrel` (proof irrelevance, structure η, unit-likeness).  Two
constants or two free variables are inert under `whnfCore`, so checking
them here, after the restart, instead of before it is the same
verdict. -/
def defeqStuck (r : CoreFns m) (env : Env) (depth : Nat) (a b : Expr) :
    m Bool :=
  match a, b with
  -- a string literal against a unary `String.ofList` application:
  -- expand the literal to its constructor form and compare — the
  -- reference kernels' `tryStringLitExpansion` (lean4lean
  -- `TypeChecker.lean`, nanoda `try_string_lit_expansion`), which
  -- fires exactly when the other side's function part is the bare
  -- `String.ofList` constant
  | .lit l, .app f x =>
    match l, f with
    | .strVal st, .const cO usO =>
      if cO = stringOfListName ∧ usO = [] ∧ strLitSupported env then
        r.defeq depth (strLitToConstructor st) (.app (.const cO usO) x)
      else stuckIrrel mode r env depth (.lit (.strVal st)) (.app (.const cO usO) x)
    | _, _ => stuckIrrel mode r env depth (.lit l) (.app f x)
  | .app f x, .lit l =>
    match l, f with
    | .strVal st, .const cO usO =>
      if cO = stringOfListName ∧ usO = [] ∧ strLitSupported env then
        r.defeq depth (.app (.const cO usO) x) (strLitToConstructor st)
      else stuckIrrel mode r env depth (.app (.const cO usO) x) (.lit (.strVal st))
    | _, _ => stuckIrrel mode r env depth (.app f x) (.lit l)
  | .fvar i ty₁, .fvar j ty₂ =>
    if i == j then pure true
    else stuckIrrel mode r env depth (.fvar i ty₁) (.fvar j ty₂)
  | .const n us, .const n' us' =>
    if n = n' then do
      if ← liftFueled "level comparison" (Level.isEquivList us us') then
        pure true
      else stuckIrrel mode r env depth (.const n us) (.const n' us')
    else stuckIrrel mode r env depth (.const n us) (.const n' us')
  | .app f₁ a₁, .app f₂ a₂ => do
    -- Stuck applications: **spine-wise** congruence (the official
    -- kernel's `is_def_eq_app`, lean4lean's `isDefEqApp`, nanoda's
    -- `def_eq_app`): equal spine lengths, one head comparison, then
    -- the argument lists pairwise (task #106: never the partial
    -- applications one by one).
    if (Expr.app f₁ a₁).getAppArgs.length =
        (Expr.app f₂ a₂).getAppArgs.length then
      if ← r.defeq depth (Expr.app f₁ a₁).getAppFn
          (Expr.app f₂ a₂).getAppFn then
        if ← defEqList r env depth (Expr.app f₁ a₁).getAppArgs
            (Expr.app f₂ a₂).getAppArgs then pure true
        else stuckIrrel mode r env depth (.app f₁ a₁) (.app f₂ a₂)
      else stuckIrrel mode r env depth (.app f₁ a₁) (.app f₂ a₂)
    else stuckIrrel mode r env depth (.app f₁ a₁) (.app f₂ a₂)
  -- One-sided λ: eta, else the stuck fallbacks.  (Two λs never get
  -- here: `quickDefEq` decides them.)
  | .lam ty₁ body₁ m₁, b₂ => do
    if ← etaCert mode r env depth ty₁ body₁ m₁ b₂ then pure true
    else stuckIrrel mode r env depth (.lam ty₁ body₁ m₁) b₂
  | a₁, .lam ty₂ body₂ m₂ => do
    if ← etaCert mode r env depth ty₂ body₂ m₂ a₁ then pure true
    else stuckIrrel mode r env depth a₁ (.lam ty₂ body₂ m₂)
  -- Distinct whnf-stuck head symbols: only the stuck fallbacks can
  -- equate them; `false` is always sound.
  | e₁, e₂ => stuckIrrel mode r env depth e₁ e₂

/-- **The definitional-equality body** (the official kernel's
`is_def_eq_core`, clause for clause): the syntactic fast path; the
`Bool.true` shortcut (E2, `boolTrueShortcut`: right side `Bool.true`,
left side fvar-free — official's `(!has_fvar(t) || m_eager_reduce) &&
is_constant(s, Bool.true)`; the eager flag is not mirrored); the cheap
head normalization of both sides (`whnfCore` with `cheap_proj`);
`quickDefEq`; proof irrelevance (`is_def_eq_proof_irrel`, before any
delta — with theorem values delta-unfolding, task #66, a later probe
would grind through proof bodies first); the lazy-delta loop
(`lazyDeltaReduction`); the proj/proj check (`defeqProjPair`); the
FULL `whnfCore` of both sides and, if either changed, a restart; and
the stuck comparison (`defeqStuck`).  The restarts — after a literal
acceleration in the loop and after the full `whnfCore` — are `defeq`
calls, as official's are `is_def_eq_core` calls, so every entry runs
the prefix (proof irrelevance included) exactly once (the divergence
audit's D3 holds by construction); the long chains — the unfoldings —
are iterations of the lazy loops. -/
def defeqBody (r : CoreFns m) (env : Env) : Nat → Expr → Expr → m Bool :=
  fun depth a b => do
    if a == b then pure true else
    if ← (if b.isBoolTrue && !a.hasFvar then boolTrueShortcut r depth a
        else pure false) then pure true else
    let a' ← r.whnfCore true depth a
    let b' ← r.whnfCore true depth b
    match ← quickDefEq mode r depth a' b' with
    | some v => pure v
    | none =>
    if ← propIrrel r env depth a' b' then pure true else
    match ← lazyDeltaReduction mode r env depth defeqLoopFuel a' b' with
    | .verdict v => pure v
    | .unknown a₁ b₁ =>
    if ← defeqProjPair mode r env depth a₁ b₁ then pure true else
    -- the full `whnfCore` can only differ from the cheap one where the
    -- cheap mode left a projection stuck, which is then the spine head
    -- (`whnfCore` stops there); without one, the restart's test
    -- would find both sides unchanged, so it is skipped (cost only)
    if !a₁.headIsProj && !b₁.headIsProj then defeqStuck mode r env depth a₁ b₁ else
    let a₂ ← r.whnfCore false depth a₁
    let b₂ ← r.whnfCore false depth b₁
    if a₂ == a₁ && b₂ == b₁ then defeqStuck mode r env depth a₁ b₁
    else r.defeq depth a₂ b₂

/-! ### The untrusted annotation writes (task #161 P5)

The pass is the existing normalizer: at the verified modes its ∀/λ
clauses *write* the `pw` datum the front door then *validates*.  The
write is untrusted by design — a wrong datum declines, never
unsoundness — and it is a no-op wherever the input already carries a
non-placeholder annotation (`pwWritten`): explicit input annotations
are judged by validation, never overwritten.  The parser's placeholder
for an absent `"pw"` field is `.never`, which is also a legitimate
value; the pass therefore recomputes over `.never` unconditionally
(harmless: a genuinely never-zero codomain recomputes to `.never`),
and the *only* input annotations preserved are the `ifAllZero` ones.
-/

/-- The ∀ node's datum: the zero-ness of the *codomain*'s sort, on the
already-annotated opened body — exactly the value `inferBody`'s ∀
clause validates against (`(forall-cod)`).

**The chain read (task #161 P5, proof-lane repair).**  A ∀ body that is
itself a ∀ reuses its inner neighbour's datum instead of inferring:
`zeronessOf (imax u v) = zeronessOf v`, so every node of a telescope
carries the *leaf* codomain sort's zero-ness.  This is the same rule
`annotPwLam` already applies through `lamPw`, and it is what makes the
spec pass pay **one** inference per ∀ telescope, as the design's
telescope-collapse paragraph claims — and what makes it agree with the
interned pass, which computes at the leaf and threads outward
(`annotateBindersOutI`).

Without it the spec inferred the whole inner telescope at every node,
so it *failed* on terms the interned pass accepts — e.g.
`∀ (x : Prop), ∀ (y : Foo), Prop` with `Foo` absent from the
environment: `annotate` never looks a constant up, but inferring the
inner ∀ node does.  See DESIGN.md, task #161 P5 proof-lane finding. -/
def annotPwPi (r : CoreFns m) (env : Env) (depth : Nat) (body' : Expr) :
    m PropWhen := do
  -- Task #168 stage 2: the head-symbol reader first.  It subsumes the
  -- chain read (`typeSortPW` of a ∀ IS its codomain datum) and answers
  -- most leaves without inference; the pass is untrusted — `infer`
  -- validates every datum it writes — so the reader owes no licence
  -- here, only the datum's agreement (census: 0 non-equivalent data).
  match typeSortPW env.find? body' with
  | some pw => pure pw
  | none => do
    -- io grade: `body'` is already annotated (bottom-up)
    let v ← ensureSort r env depth (← r.inferIO depth body')
    pure (Level.zeronessOf v)

/-- The λ node's datum: the zero-ness of the sort of the *body's type*.
Mirrors `inferBody`'s λ clause exactly — a λ body reuses its inner
neighbour's datum (the chain rule, no inference), any other body pays
one leaf computation (`(lam-cod-leaf)`). -/
def annotPwLam (r : CoreFns m) (env : Env) (depth : Nat) (body' : Expr) :
    m PropWhen := do
  -- task #168 stage 2: the reader first (it subsumes the `lamPw`
  -- chain read), as in `annotPwPi`
  match proofPW env.find? body' with
  | some pw => pure pw
  | none => do
    -- io grade: `body'` is already annotated (bottom-up)
    let bt ← r.inferIO depth body'
    let vb ← ensureSort r env depth (← r.inferIO depth bt)
    pure (Level.zeronessOf vb)

/-- The annotation body: compute the codomain-sort annotations of every
binder, bottom-up, by real inference on the opened (already annotated)
body.  For a `forallE` the annotation is the body's sort (so this also
checks that the body *is* a type — the ∀-formation rule); for a `lam`
it is the sort of the body's type.  The `.app` clause is structural:
the application rule is not checked here.  The inference sweep that
follows re-checks every application and every binder body and
validates each annotation against its own result; what it takes from
the annotations is a licence to skip a *certificate* at a binder whose
datum is `never`, never a typing it does not redo. -/
def annotateBody (r : CoreFns m) (env : Env) : Nat → Expr → m Expr :=
  fun depth e =>
    match e with
    | .bvar i => pure (.bvar i)
    | .fvar idx ty =>
      -- Leaf scope check, as in `inferBody`: annotation is the pass raw
      -- input enters through, so a dangling free variable in the input
      -- is rejected here (depth 0: any `fvar` fails).
      if idx < depth then pure (.fvar idx ty)
      else throw (.invalid "free variable out of scope")
    | .sort u => pure (.sort u)
    | .const n us => pure (.const n us)
    | .lit (.natVal n) => do
      -- a literal is well-formed exactly when its type's declarations
      -- are stored in the expected shape
      if natLitSupported env then pure (.lit (.natVal n))
      else throw (.invalid "Nat literal without the Nat basis declarations")
    | .lit (.strVal s) => do
      -- as for `Nat` literals; the missing-support verdict is a
      -- decline (exit 2), the feature being positively detected
      if strLitSupported env then pure (.lit (.strVal s))
      else throw (.notImplemented
        "string literals before the String support declarations")
    | .app f a => do
      -- structural (task #100 stage 6: the application rule's checks
      -- moved to the driver's inference sweep — `inferBody`'s app
      -- clause re-checks every argument unconditionally)
      let f' ← r.annotate depth f
      let a' ← r.annotate depth a
      pure (.app f' a')
    | .forallE ty body mb => do
      -- structural (task #100 stage 6: no annotation to compute and no
      -- checks — the driver's inference sweep re-checks every binder
      -- body via the ∀/λ rules)
      let ty' ← r.annotate depth ty
      let body' ← r.annotate (depth + 1) (body.instantiate1 (.fvar depth ty'))
      let pw ← if !pwWritten mb.pw then
          annotPwPi r env (depth + 1) body'
        else pure mb.pw
      pure (.forallE ty' (body'.abstract1 depth) ⟨pw⟩)
    | .lam ty body mb => do
      let ty' ← r.annotate depth ty
      let body' ← r.annotate (depth + 1) (body.instantiate1 (.fvar depth ty'))
      let pw ← if !pwWritten mb.pw then
          annotPwLam r env (depth + 1) body'
        else pure mb.pw
      pure (.lam ty' (body'.abstract1 depth) ⟨pw⟩)
    | .letE ty v b => do
      -- The body is annotated *with the value transparent* — nanoda's
      -- `infer_let` instantiates the body with the value and recurses
      -- (the official kernel gets the same transparency from valued
      -- let-fvars in its local context).  ConLeche fvars carry no value,
      -- so the body is annotated as its zeta reduct; an opened opaque
      -- variable was tried and rejects real streams (elaborated `let`
      -- bodies rely on the value definitionally — see DESIGN.md).
      --
      -- Task #217 (audit follow-up #206-S1): the official `infer_let`
      -- triple — `ensure_sort_core(infer(type))`, `infer(val)`,
      -- `is_def_eq(val_type, type)` — runs HERE, on the annotated
      -- annotation and the annotated value, before the reduct is taken.
      --
      -- Task #161 item C2 dropped it as redundant with `inferBody`'s
      -- own `.letE` clause.  That was wrong: this clause returns the ζ
      -- reduct, so the stored term is let-free and `inferBody`'s
      -- `.letE` arm never sees a `letE` node the driver produced —
      -- `def x : Nat := let y : Nat := Bool.true; Nat.zero` was
      -- accepted where the official kernel rejects ("(kernel)
      -- let-declaration type mismatch").  The annotation pass is the
      -- only pass that meets a `letE`, so it is where the triple must
      -- run.
      let ty' ← r.annotate depth ty
      let _ ← ensureSort r env depth (← r.infer depth ty')
      let v' ← r.annotate depth v
      let tv ← r.infer depth v'
      unless ← r.defeq depth tv ty' do
        throw (.invalid "let value type mismatch")
      r.annotate depth (b.instantiate1 v)
    | .proj sn i pe => do
      let e' ← r.annotate depth pe
      -- Run the projection rule (the one place it is checked).  A table
      -- entry types the node directly (the display name is normalized
      -- to the type's head, so reduction's table lookup is complete on
      -- annotated terms); a family without a table has no `.proj`
      -- typing at all.
      let te ← r.whnf depth (← r.inferIO depth e')
      match te.getAppFn with
      | .const T _ =>
        match env.findProj? T i with
        | some entry => do
          -- TASK #271 (issue #7): the node's OWN structure name is
          -- official's `infer_proj` premise `const_name(I) ==
          -- proj_sname(e)`, and it is checked HERE and not only on the
          -- annotated term: the normalization to the type's head below
          -- would otherwise repair a node that names another
          -- inductive, and official rejects it ("invalid projection").
          unless T = sn do
            throw (.invalid "invalid projection: the node names another structure")
          unless te.getAppArgs.length = entry.numParams do
            throw (.invalid "projection parameter mismatch")
          pure (.proj T i e')
        | none =>
          -- task #175 wiring W5: the elimination fallbacks are gone —
          -- every supported projection is a native table entry.
          -- Without one, official's `infer_proj` verdict
          -- (`projMissError`): reject, except at an indexed
          -- structure-like type, which declines
          throw (projMissError env.find? (env.find? (projTableName T)).isSome T sn i
            te.getAppArgs.length)
      -- official `infer_proj`: the whnf'd type's head is no constant
      | _ => throw (.invalid "invalid projection: not a structure-like type, or no such field")

end Bodies

/-- Tie the bodies together at a monad: the record whose entry points
are the bodies applied to the record one fuel level down.  Fuel is
*only* here — exhaustion is an internal error, never a verdict.  The
next level is constructed lazily, inside each entry point's closure
(constant work per call; an eager tower would cost `fuel` allocations
per instantiation). -/
def coreKnot {m : Type → Type} [Monad m] [MonadExceptOf CheckError m]
    (mode : CheckMode) (env : Env)
    (wrap : CoreFns m → CoreFns m) : Nat → CoreFns m
  | 0 =>
    { whnfCore := fun _ _ _ => throw (.internal "fuel exhausted: whnfCore")
      whnf := fun _ _ => throw (.internal "fuel exhausted: whnf")
      infer := fun _ _ => throw (.internal "fuel exhausted: infer")
      defeq := fun _ _ _ => throw (.internal "fuel exhausted: defeq")
      annotate := fun _ _ => throw (.internal "fuel exhausted: annotate")
      inferIO := fun _ _ => throw (.internal "fuel exhausted: infer") }
  | fuel + 1 =>
    wrap
      { whnfCore := fun c d e =>
          whnfCoreBody mode (coreKnot mode env wrap fuel) env c d e
        whnf := fun d e => whnfBody (coreKnot mode env wrap fuel) env d e
        infer := fun d e =>
          inferBody mode (coreKnot mode env wrap fuel) env d e
        defeq := fun d a b =>
          defeqBody mode (coreKnot mode env wrap fuel) env d a b
        annotate := fun d e =>
          annotateBody (coreKnot mode env wrap fuel) env d e
        -- **The io slot** (task #170 / #172 B4).  The grade's meaning is
        -- the mode's: at the gated mode the io body, tied to the io-grade
        -- view of the knot one level down (the grade propagates, as
        -- official's `infer_only` does); at every other mode the full
        -- inference body, verbatim — "in R mode infer_only is just
        -- equivalent to infer" (the task-#170 order).  The selection
        -- reads mode-and-datum-free data (`mode.betaGate`, the same bit
        -- the β gate reads) and is made once per knot level.
        inferIO := fun d e =>
          if mode.betaGate then
            inferBodyIO mode
              (CoreFns.ioView (coreKnot mode env wrap fuel)) env d e
          else inferBody mode (coreKnot mode env wrap fuel) env d e }

/-- The shared fuel for the checker core: bounds the recursion depth of
reduction, inference and definitional equality.  Exhaustion is an
internal error, never a verdict. -/
def checkFuel : Nat := 100000

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Core
/- END exact source origin ConLeche.Kernel.Core -/

/- BEGIN exact source origin ConLeche.Kernel.TypeChecker -/
-- Bundled origin 20, header line 1: module

-- Bundled origin 20, header line 3: public import ConLeche.Kernel.Core

@[expose] public section

/-!
# The pure knot

The core bodies (`ConLeche.Kernel.Core`) tied together at `CheckM`, with
no memoization: this instance is the **specification** — all semantic
verification (`ConLeche/Verify/*`, `ConLeche/Semantics/*`, `ConLeche/Model/*`)
reasons about these
fueled entry points, and the refinement bridge (see DESIGN.md) carries
every claim over to the cached instance the checker executes
(`ConLeche.Cached.CoreC`).
-/

namespace ConLeche

variable (mode : CheckMode)

/-- The pure core: the bodies tied at `CheckM`, fuel in the knot. -/
def pureFns (env : Env) : Nat → CoreFns CheckM :=
  coreKnot mode env id

/-- Head normalization without delta (fueled); `cheap` is the official
kernel's `cheap_proj` (`whnfCoreBody`), off by default. -/
def whnfCore (env : Env) (fuel depth : Nat) (e : Expr) (cheap : Bool := false) :
    CheckM Expr :=
  (pureFns mode env fuel).whnfCore cheap depth e

/-- The full reduction loop (fueled). -/
def whnf (env : Env) (fuel depth : Nat) (e : Expr) : CheckM Expr :=
  (pureFns mode env fuel).whnf depth e

/-- Full-grade type inference (fueled): the declaration front door's
entry — official's `infer_type_core(e, infer_only = false)`. -/
def inferTypeCore (env : Env) (fuel depth : Nat) (e : Expr) : CheckM Expr :=
  (pureFns mode env fuel).infer depth e

/-- Type inference at the io grade (fueled): the knot's `inferIO` slot
— what every internal inference call site runs (task #170).  At a
gate-off mode this **is** `inferTypeCore` (`inferTypeIO_off`,
`Verify/Knot.lean`); at the gated mode it is the io lane
(`inferTypeIO_on`). -/
def inferTypeIO (env : Env) (fuel depth : Nat) (e : Expr) : CheckM Expr :=
  (pureFns mode env fuel).inferIO depth e

/-- Definitional equality (fueled). -/
def isDefEqCore (env : Env) (fuel depth : Nat) (a b : Expr) : CheckM Bool :=
  (pureFns mode env fuel).defeq depth a b

/-- The annotation pass (fueled). -/
def annotateCore (env : Env) (fuel depth : Nat) (e : Expr) : CheckM Expr :=
  (pureFns mode env fuel).annotate depth e

/-- `ensureSort` over the pure knot (fueled). -/
def ensureSortCore (env : Env) (fuel depth : Nat) (e : Expr) : CheckM Level :=
  ensureSort (pureFns mode env fuel) env depth e

end ConLeche

end -- original EOF public section of ConLeche.Kernel.TypeChecker
/- END exact source origin ConLeche.Kernel.TypeChecker -/

