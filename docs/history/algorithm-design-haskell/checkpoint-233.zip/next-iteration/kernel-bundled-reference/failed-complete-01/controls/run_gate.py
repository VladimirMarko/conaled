#!/usr/bin/env python3
"""Fresh eight-module source consolidation of the exact 28-origin kernel closure.

Only --run invokes Lean. All origin identities, source assembly inverses and
scope review are checked as data before a single permanent source-keyed gate.
No old compiled upstream or experimental object is an input.
"""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'source-manifest.json'
PREVIOUS = ROOT / 'next-iteration/kernel-compact-reference'
PREVIOUS_CONTROLS = PREVIOUS / 'failed-complete-01/controls'
PREVIOUS_MANIFEST = PREVIOUS_CONTROLS / 'source-manifest.json'
PREVIOUS_REPORT = PREVIOUS / 'gate/attempts/complete-01/report.json'
BUNDLE = CANDIDATE / 'SOURCE-BUNDLE.json'
SCOPE_SOURCE = CANDIDATE / 'primary-source/Lean__Elab__BuiltinCommand.lean'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
OUTPUT_SOURCE_ROOT = ROOT / 'next-iteration/kernel-low-operation-refinement/gate/primary-source'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
BASELINE = ROOT / 'next-iteration/kernel-logical-reference'
RECURSION = ROOT / 'next-iteration/kernel-recursion-reference'
REFERENCE_RESOLUTIONS = {
    str(PREVIOUS / 'gate/source-manifest.json'): PREVIOUS_MANIFEST,
    str(PREVIOUS / 'source/ConLeche/Kernel/Expr.lean'):
        PREVIOUS / 'failed-complete-01/source/ConLeche/Kernel/Expr.lean',
    str(PREVIOUS / 'source/ConLeche/Kernel/Canon.lean'):
        PREVIOUS / 'failed-complete-01/source/ConLeche/Kernel/Canon.lean',
}
FIXED = {
    PREVIOUS_REPORT: 'e955b88b4b5b9a87b7f37c85253fb7f74b0db660eadd186595249104b78c1252',
    PREVIOUS_MANIFEST: '7aeb00b27645d1c791d2fed7a7e4ab71cd3bfc51665fc03157a44040e68fc8e6',
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
    OUTPUT_SOURCE_ROOT / 'Lean__Environment.lean': '6c90105aecc4d28efe94cc9aef1704c284e7a748b28270b5f8513d2562331e43',
    OUTPUT_SOURCE_ROOT / 'Lean__Elab__Frontend.lean': '423d17e49722e901e5f82bd4b86e7cf2dd80c352fc55b3d72ac1301a79ead634',
    OUTPUT_SOURCE_ROOT / 'Lean__Compiler__Options.lean': '26077071ffc64e4032d2d573c4013e96078367dc832a677afc981fb16c7496f2',
    SCOPE_SOURCE: 'a22a93f95b44299068f8c754acae760bd1dc538db82f4504bf3c780a753e7c3f',
}
UPSTREAM_MODULES = ['ConLeche.Kernel.Name',
 'ConLeche.Kernel.PropWhen',
 'ConLeche.Kernel.Exclusive',
 'ConLeche.Kernel.Expr',
 'ConLeche.Kernel.Level',
 'ConLeche.Kernel.ExprOps',
 'ConLeche.Kernel.Env',
 'ConLeche.Kernel.PropRead',
 'ConLeche.Kernel.Basis.Names',
 'ConLeche.Kernel.Basis.Builder',
 'ConLeche.Kernel.Basis.Eq',
 'ConLeche.Kernel.Basis.Nat',
 'ConLeche.Kernel.Basis.Empty',
 'ConLeche.Kernel.Basis.False',
 'ConLeche.Kernel.Basis.Quot',
 'ConLeche.Kernel.Basis.And',
 'ConLeche.Kernel.Canon',
 'ConLeche.Kernel.Basis',
 'ConLeche.Kernel.CoreDefs',
 'ConLeche.Kernel.Core',
 'ConLeche.Kernel.TypeChecker']
PROJECT_MODULES = ['FiniteFold',
 'FirstOrderNat',
 'SaturatingUInt64',
 'UInt64MaskOps',
 'KernelLowOperation',
 'KernelScalarSteps',
 'KernelNatRecursor']
ORIGIN_MODULES = UPSTREAM_MODULES + PROJECT_MODULES
MODULES = ['KernelCompactCore'] + PROJECT_MODULES
ORIGIN_IMPORTS = {'ConLeche.Kernel.Basis': ['ConLeche.Kernel.Basis.Names',
                           'ConLeche.Kernel.Basis.Builder',
                           'ConLeche.Kernel.Basis.Eq',
                           'ConLeche.Kernel.Basis.Nat',
                           'ConLeche.Kernel.Basis.Empty',
                           'ConLeche.Kernel.Basis.False',
                           'ConLeche.Kernel.Basis.Quot',
                           'ConLeche.Kernel.Basis.And',
                           'ConLeche.Kernel.Canon'],
 'ConLeche.Kernel.Basis.And': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Basis.Builder': ['ConLeche.Kernel.Basis.Names'],
 'ConLeche.Kernel.Basis.Empty': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Basis.Eq': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Basis.False': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Basis.Names': ['ConLeche.Kernel.Env'],
 'ConLeche.Kernel.Basis.Nat': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Basis.Quot': ['ConLeche.Kernel.Basis.Builder'],
 'ConLeche.Kernel.Canon': ['ConLeche.Kernel.Env'],
 'ConLeche.Kernel.Core': ['ConLeche.Kernel.Level',
                          'ConLeche.Kernel.ExprOps',
                          'ConLeche.Kernel.CoreDefs'],
 'ConLeche.Kernel.CoreDefs': ['ConLeche.Kernel.Env',
                              'ConLeche.Kernel.PropRead',
                              'ConLeche.Kernel.Level',
                              'ConLeche.Kernel.ExprOps',
                              'ConLeche.Kernel.Basis'],
 'ConLeche.Kernel.Env': ['ConLeche.Kernel.Expr'],
 'ConLeche.Kernel.Exclusive': [],
 'ConLeche.Kernel.Expr': ['ConLeche.Kernel.PropWhen', 'ConLeche.Kernel.Exclusive', 'Init.Util'],
 'ConLeche.Kernel.ExprOps': ['ConLeche.Kernel.Level', 'ConLeche.Kernel.PropWhen'],
 'ConLeche.Kernel.Level': ['ConLeche.Kernel.Expr'],
 'ConLeche.Kernel.Name': ['Std.Data.HashMap', 'Init.Util'],
 'ConLeche.Kernel.PropRead': ['ConLeche.Kernel.Env', 'ConLeche.Kernel.ExprOps'],
 'ConLeche.Kernel.PropWhen': ['ConLeche.Kernel.Name'],
 'ConLeche.Kernel.TypeChecker': ['ConLeche.Kernel.Core'],
 'FiniteFold': ['Init'],
 'FirstOrderNat': ['FiniteFold'],
 'KernelLowOperation': ['ConLeche.Kernel.TypeChecker', 'UInt64MaskOps'],
 'KernelNatRecursor': ['KernelScalarSteps'],
 'KernelScalarSteps': ['KernelLowOperation'],
 'SaturatingUInt64': ['Init.Data.UInt.Lemmas', 'Init.Omega'],
 'UInt64MaskOps': ['SaturatingUInt64', 'FirstOrderNat', 'Init.Data.UInt.Bitwise']}
IMPORTS = {'KernelCompactCore': ['Std.Data.HashMap', 'Init.Util'],
 'FiniteFold': ['Init'],
 'FirstOrderNat': ['FiniteFold'],
 'SaturatingUInt64': ['Init.Data.UInt.Lemmas', 'Init.Omega'],
 'UInt64MaskOps': ['SaturatingUInt64', 'FirstOrderNat', 'Init.Data.UInt.Bitwise'],
 'KernelLowOperation': ['KernelCompactCore', 'UInt64MaskOps'],
 'KernelScalarSteps': ['KernelLowOperation'],
 'KernelNatRecursor': ['KernelScalarSteps']}
RAW_ROOTS = {'KernelCompactCore': [],
 'FiniteFold': ['loop_zero',
                'loop_succ',
                'fold_zero',
                'fold_succ',
                'canonical_equations',
                'loop_unique_of_equations',
                'fold_unique_of_equations',
                'branches_unique_of_equations',
                'implementations_agree'],
 'FirstOrderNat': ['shiftLeft_one',
                   'count_zero',
                   'count_succ',
                   'branches_zero',
                   'branches_succ',
                   'equations',
                   'count_eq_fold',
                   'branches_eq_loop',
                   'evaluate_eq_fold'],
 'SaturatingUInt64': ['min_add_min',
                      'min_eq_self_of_ne_cap',
                      'wrapped_sum_lt_iff',
                      'maximum_toNat',
                      'toNat_le_limit',
                      'satAdd_toNat',
                      'satAdd_refines',
                      'exact_of_not_maximum'],
 'UInt64MaskOps': ['modulus_toNat',
                   'ofNat_toNat_of_range',
                   'ofNat_inRange',
                   'low_le_cursor',
                   'low_inRange',
                   'low_toNat',
                   'remainder_toNat',
                   'remainder_inRange',
                   'available_inRange',
                   'available_toNat',
                   'nextLeft_toNat',
                   'nextLeft_inRange',
                   'nextColumns_toNat',
                   'nextColumns_inRange',
                   'nextRight_toNat',
                   'nextRight_inRange'],
 'KernelLowOperation': ['whnf_nat_literal',
                        'whnf_binary_of_runs',
                        'lowExpr_whnf',
                        'lowExpr_whnf_uint64',
                        'lowExpr_whnf_uint64_exists'],
 'KernelScalarSteps': ['whnfCore_binary',
                       'whnf_of_scalar_head',
                       'whnf_constructor',
                       'whnf_binary_of_runs'],
 'KernelNatRecursor': ['iotaCerts_never_prefix',
                       'iota_nat_zero',
                       'iota_nat_succ',
                       'whnfCore_nat_zero',
                       'whnfCore_nat_succ',
                       'headRunsAbove_nat_zero',
                       'headRunsAbove_nat_succ',
                       'headRunsAbove_apply',
                       'runsAbove_of_head_nat',
                       'runsAbove_nat_zero',
                       'runsAbove_nat_succ']}
ROOTS = {'KernelCompactCore': [],
 'FiniteFold': ['ADWH.Experiments.Chapter15.FiniteFold.loop_zero',
                'ADWH.Experiments.Chapter15.FiniteFold.loop_succ',
                'ADWH.Experiments.Chapter15.FiniteFold.fold_zero',
                'ADWH.Experiments.Chapter15.FiniteFold.fold_succ',
                'ADWH.Experiments.Chapter15.FiniteFold.canonical_equations',
                'ADWH.Experiments.Chapter15.FiniteFold.loop_unique_of_equations',
                'ADWH.Experiments.Chapter15.FiniteFold.fold_unique_of_equations',
                'ADWH.Experiments.Chapter15.FiniteFold.branches_unique_of_equations',
                'ADWH.Experiments.Chapter15.FiniteFold.implementations_agree'],
 'FirstOrderNat': ['ADWH.Experiments.Chapter15.FirstOrderNat.shiftLeft_one',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.count_zero',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.count_succ',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.branches_zero',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.branches_succ',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.equations',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.count_eq_fold',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.branches_eq_loop',
                   'ADWH.Experiments.Chapter15.FirstOrderNat.evaluate_eq_fold'],
 'SaturatingUInt64': ['ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.min_add_min',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.min_eq_self_of_ne_cap',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.wrapped_sum_lt_iff',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.maximum_toNat',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.toNat_le_limit',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.satAdd_toNat',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.satAdd_refines',
                      'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.exact_of_not_maximum'],
 'UInt64MaskOps': ['ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.modulus_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.ofNat_toNat_of_range',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.ofNat_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.low_le_cursor',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.low_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.low_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.remainder_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.remainder_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.available_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.available_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextLeft_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextLeft_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextColumns_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextColumns_inRange',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextRight_toNat',
                   'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator.nextRight_inRange'],
 'KernelLowOperation': ['ADWH.Experiments.Chapter15.KernelLowOperation.whnf_nat_literal',
                        'ADWH.Experiments.Chapter15.KernelLowOperation.whnf_binary_of_runs',
                        'ADWH.Experiments.Chapter15.KernelLowOperation.lowExpr_whnf',
                        'ADWH.Experiments.Chapter15.KernelLowOperation.lowExpr_whnf_uint64',
                        'ADWH.Experiments.Chapter15.KernelLowOperation.lowExpr_whnf_uint64_exists'],
 'KernelScalarSteps': ['ADWH.Experiments.Chapter15.KernelScalarSteps.whnfCore_binary',
                       'ADWH.Experiments.Chapter15.KernelScalarSteps.whnf_of_scalar_head',
                       'ADWH.Experiments.Chapter15.KernelScalarSteps.whnf_constructor',
                       'ADWH.Experiments.Chapter15.KernelScalarSteps.whnf_binary_of_runs'],
 'KernelNatRecursor': ['ADWH.Experiments.Chapter15.KernelNatRecursor.iotaCerts_never_prefix',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.iota_nat_zero',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.iota_nat_succ',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.whnfCore_nat_zero',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.whnfCore_nat_succ',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.headRunsAbove_nat_zero',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.headRunsAbove_nat_succ',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.headRunsAbove_apply',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.runsAbove_of_head_nat',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.runsAbove_nat_zero',
                       'ADWH.Experiments.Chapter15.KernelNatRecursor.runsAbove_nat_succ']}
ORIGIN_ROOTS = {module: [] for module in UPSTREAM_MODULES} | {module: ROOTS[module] for module in PROJECT_MODULES}
ORIGIN_RAW_ROOTS = {module: [] for module in UPSTREAM_MODULES} | {module: RAW_ROOTS[module] for module in PROJECT_MODULES}
NAMESPACES = {'FiniteFold': 'ADWH.Experiments.Chapter15.FiniteFold',
    'FirstOrderNat': 'ADWH.Experiments.Chapter15.FirstOrderNat',
    'SaturatingUInt64': 'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator',
    'UInt64MaskOps': 'ADWH.Experiments.Chapter15.UInt64SaturatingEvaluator',
    'KernelLowOperation': 'ADWH.Experiments.Chapter15.KernelLowOperation',
    'KernelScalarSteps': 'ADWH.Experiments.Chapter15.KernelScalarSteps',
    'KernelNatRecursor': 'ADWH.Experiments.Chapter15.KernelNatRecursor'}

ORIGIN_PATHS = {module: BASELINE / 'source' / (module.replace('.', '/') + '.lean')
                for module in UPSTREAM_MODULES + ['KernelLowOperation']}
ORIGIN_PATHS.update({
    'ConLeche.Kernel.Expr': PREVIOUS / 'failed-complete-01/source/ConLeche/Kernel/Expr.lean',
    'ConLeche.Kernel.Canon': PREVIOUS / 'failed-complete-01/source/ConLeche/Kernel/Canon.lean',
    'KernelScalarSteps': RECURSION / 'failed-complete-02/source/KernelScalarSteps.lean',
    'KernelNatRecursor': RECURSION / 'failed-complete-05/source/KernelNatRecursor.lean',
    'FiniteFold': ROOT / 'next-iteration/finite-fold-evaluator/source/FiniteFold.lean',
    'FirstOrderNat': ROOT / 'next-iteration/first-order-nat-evaluator/source/FirstOrderNat.lean',
    'SaturatingUInt64': ROOT / 'next-iteration/uint64-saturating-evaluator/source/SaturatingUInt64.lean',
    'UInt64MaskOps': ROOT / 'next-iteration/uint64-saturating-evaluator/source/UInt64MaskOps.lean',
})
SOURCE_PATHS = {module: ORIGIN_PATHS[module] for module in PROJECT_MODULES}
SOURCE_PATHS.update({module: CANDIDATE / 'source' / (module + '.lean')
                     for module in ['KernelCompactCore', 'KernelLowOperation']})
CURRENT = [
    ('runner', HERE / 'run_gate.py'), ('protocol', HERE / 'PROTOCOL.md'),
    ('source_manifest', MANIFEST), ('bundle_author_plan', CANDIDATE / 'PLAN.md'),
    ('source_bundle_script', CANDIDATE / 'prepare_source_bundle.py'), ('source_bundle', BUNDLE),
    ('bundle_source_review', CANDIDATE / 'SOURCE-REVIEW.md'),
    ('bundle_source_audit', CANDIDATE / 'SOURCE-AUDIT.json'),
]
BASE_HISTORY = [('resource_helper', HELPER), ('source_guard', GUARD),
    ('toolchain_pin', PIN), ('runtime_reference', RUNTIME_REFERENCE),
    ('module_environment_source', OUTPUT_SOURCE_ROOT / 'Lean__Environment.lean'),
    ('module_frontend_source', OUTPUT_SOURCE_ROOT / 'Lean__Elab__Frontend.lean'),
    ('module_compiler_options_source', OUTPUT_SOURCE_ROOT / 'Lean__Compiler__Options.lean'),
    ('scope_command_source', SCOPE_SOURCE),
    ('compact01_report', PREVIOUS_REPORT), ('compact01_manifest', PREVIOUS_MANIFEST),
    ('compact01_runner', PREVIOUS_CONTROLS / 'run_gate.py'),
    ('compact01_protocol', PREVIOUS_CONTROLS / 'PROTOCOL.md'),
    ('compact01_author_plan', PREVIOUS_CONTROLS / 'PLAN.md'),
    ('compact01_source_cut_script', PREVIOUS_CONTROLS / 'prepare_source_cut.py'),
    ('compact01_source_cuts', PREVIOUS_CONTROLS / 'SOURCE-CUTS.json'),
    ('compact01_source_review', PREVIOUS_CONTROLS / 'SOURCE-REVIEW.md'),
    ('compact01_source_audit', PREVIOUS_CONTROLS / 'SOURCE-AUDIT.json')]
BASE_HISTORY += [('source_origin_' + module, ORIGIN_PATHS[module])
                 for module in UPSTREAM_MODULES + ['KernelLowOperation']]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
FORMAT = 'adwh-kernel-bundled-reference-full-gate-v1'
MANIFEST_FORMAT = 'adwh-kernel-bundled-reference-full-manifest-v1'
REQUIRED_ROOTS = 62
EXPECTED_ARTIFACTS = 20
POLICY = {'cumulative_wall_seconds': 30, 'resident_memory_kib': 1048576,
    'lean_memory_mib': 1024, 'compiler_threads': 1, 'autoImplicit': False,
    'warningAsError': True, 'Elab.async': False,
    'default_heartbeats_recursion_and_compiler_options': True}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and not path.is_symlink()
                  and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                  'Input/output identity differs: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable frozen evidence: ' + str(path))


def resolve_binding(row, path, h):
    h.require((ROOT / row['path']).resolve() == path.resolve(), 'Source/control role mismatch: ' + str(path))
    actual = h.binding(path)
    h.require(all(actual[k] == row[k] for k in ('bytes', 'sha256')), 'Binding differs: ' + str(path))
    verify([actual], h)
    return actual


def module_file(base, module, suffix):
    return base / (module.replace('.', '/') + suffix)


def suffixes(module):
    return ('.olean', '.olean.server', '.olean.private', '.ir.sig', '.ir', '.ilean') \
        if module == 'KernelCompactCore' else ('.olean', '.ilean')


def source_fingerprint(sources):
    identity = {'stage': 'complete', 'policy': POLICY,
                'sources': [{'module': row['module'], 'sha256': row['sha256']} for row in sources]}
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def parse_imports(code):
    return [name for group in re.findall(
        r'^\s*(?:(?:public|private|meta)\s+)*import[ \t]+(?:all[ \t]+)?([^\n]+)', code, re.M)
        for name in group.split()]


def check_source(module, path, guard, h, origin=False):
    code = guard.check_lean_source(path, path.read_text())
    expected_imports = ORIGIN_IMPORTS[module] if origin else IMPORTS[module]
    expected_raw = ORIGIN_RAW_ROOTS[module] if origin else RAW_ROOTS[module]
    module_format = module in UPSTREAM_MODULES if origin else module == 'KernelCompactCore'
    h.require(parse_imports(code) == expected_imports, 'Exact import census differs: ' + module)
    h.require(bool(re.search(r'^\s*module\s*$', code, re.M)) == module_format,
              'Module-format/output contract differs: ' + module)
    expected_options = [('linter.unusedSimpArgs', 'false')] * 2 \
        if module in {'ConLeche.Kernel.ExprOps', 'KernelCompactCore'} else []
    if not module_format:
        expected_options = [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]
    h.require(re.findall(r'\bset_option\s+(\S+)\s+(\S+)', code) == expected_options,
              'A source option is new, bypassing strict settings, or overriding resources: ' + module)
    h.require(not re.search(r'^\s*(?:run_cmd|run_elab|#eval|initialize|builtin_initialize)\b', code, re.M),
              'Unexpected executable elaborator command: ' + module)
    h.require(re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M) == expected_raw,
              'Source print inventory differs: ' + module)
    if not module_format:
        h.require(re.findall(r'^\s*namespace\s+(\S+)', code, re.M) == [NAMESPACES[module]],
                  'Project/helper namespace differs: ' + module)


def reference_path(recorded):
    original = (ROOT / recorded).resolve()
    return REFERENCE_RESOLUTIONS.get(str(original), original)


def resolve_reference(row, path, h):
    # Only the three immutable compact01 resolutions above may change a recorded path.
    h.require(reference_path(row['path']) == path.resolve(), 'Historical reference role differs')
    actual = h.binding(path)
    h.require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
              'Historical reference bytes differ: ' + str(path))
    verify([actual], h)
    return actual


def verify_bundle(bundle, previous_manifest, guard, h):
    h.require(bundle['format'] == 'adwh-kernel-bundled-reference-source-bundle-v1'
              and bundle['status'] == 'source_only_unreviewed_uncompiled'
              and bundle['origin_unit_count'] == 21
              and bundle['physical_compiler_units'] == 8
              and bundle['mathematical_origin_units'] == 28
              and bundle['same_required_roots'] == REQUIRED_ROOTS
              and bundle['expected_default_artifacts'] == EXPECTED_ARTIFACTS
              and bundle['mathematical_definition_or_proof_body_edits'] == 0
              and bundle['compiled_objects_used'] is False
              and bundle['mathematical_or_native_execution'] is False
              and bundle['measured_speedup_claimed'] is False
              and bundle['whole_cached_checker_compatibility_claimed'] is False,
              'The bundle record describes another source-only candidate')
    resolve_reference(bundle['previous_manifest'], PREVIOUS_MANIFEST, h)
    resolve_binding(bundle['bundle'], SOURCE_PATHS['KernelCompactCore'], h)
    header = (b'module\n\npublic import Std.Data.HashMap\nimport all Init.Util\n\n'
              b'/-! This is a fresh source bundle of the 21 exact compact logical\n'
              b'kernel units. No compiled objects are inputs. Each original public\n'
              b'section is closed explicitly at its former end of file. See the\n'
              b'exact reversible SOURCE-BUNDLE.json origin and edit map. -/\n\n')
    h.require(bundle['bundle_header'].encode() == header
              and [row['module'] for row in bundle['origin_units']] == UPSTREAM_MODULES,
              'The exact bundle header or source order differs')
    actual = SOURCE_PATHS['KernelCompactCore'].read_bytes()
    assembled = bytearray(header)
    inverse_records = []
    for index, row in enumerate(bundle['origin_units']):
        module = row['module']
        original_path = ORIGIN_PATHS[module]
        resolve_reference(row['original'], original_path, h)
        old_row = previous_manifest['sources'][index]
        h.require(old_row['module'] == module
                  and all(old_row[key] == row['original'][key] for key in ('bytes', 'sha256')),
                  'A bundled origin is not the exact compact01 source')
        original = original_path.read_bytes()
        h.require(original.startswith(b'module\n') and original.endswith(b'\n'),
                  'Origin module header or EOF differs')
        replacements, imports, pieces, offset, sections = [], [], [], 0, 0
        for line_number, line in enumerate(original.splitlines(keepends=True), 1):
            text = line.decode()
            imported = re.fullmatch(r'((?:(?:public|private|meta) )*import )(all )?([A-Za-z0-9_. ]+)\n', text)
            if re.fullmatch(r'(?:@\[expose\] )?public section\n', text):
                sections += 1
            if line_number == 1 or imported:
                if imported:
                    names = imported[3].split()
                    h.require(len(names) == 1 and names[0] in set(UPSTREAM_MODULES) | {'Std.Data.HashMap', 'Init.Util'},
                              'A removed import has an undeclared dependency')
                    imports.extend(names)
                replacement = (f'-- Bundled origin {index:02d}, header line {line_number}: '
                               + text.rstrip('\n') + '\n').encode()
                replacements.append({'original_offset': offset, 'original_text': text,
                                     'replacement_text': replacement.decode()})
                pieces.append(replacement)
            else:
                pieces.append(line)
            offset += len(line)
        body = b''.join(pieces)
        before = f'/- BEGIN exact source origin {module} -/\n'.encode()
        after = (f'\nend -- original EOF public section of {module}\n'
                 f'/- END exact source origin {module} -/\n\n').encode()
        h.require(sections == row['original_eof_public_sections_explicitly_closed'] == 1
                  and row['edits'] == replacements and row['imports'] == imports == ORIGIN_IMPORTS[module]
                  and row['prefix_text'].encode() == before and row['suffix_text'].encode() == after,
                  'Origin header edits, EOF closure, or exact source import list differs')
        assembled.extend(before)
        h.require(row['bundle_body_start_byte'] == len(assembled)
                  and row['bundle_body_bytes'] == len(body)
                  and row['bundle_body_sha256'] == hashlib.sha256(body).hexdigest()
                  and actual[len(assembled):len(assembled) + len(body)] == body,
                  'A mapped source body or its exact byte interval differs')
        inverse = body
        for edit in replacements:
            old, new = edit['original_text'].encode(), edit['replacement_text'].encode()
            h.require(inverse.count(new) == 1, 'Ambiguous source bundle inverse')
            inverse = inverse.replace(new, old, 1)
        h.require(inverse == original and row['exact_inverse_verified'] is True,
                  'Source bundle inverse fails to recover an exact original')
        assembled.extend(body)
        assembled.extend(after)
        inverse_records.append({'module': module, 'header_edit_count': len(replacements),
            'explicit_eof_section_closures': sections, 'original_bytes': len(original),
            'original_sha256': hashlib.sha256(inverse).hexdigest(),
            'source_text_inverse_verified': True})
    h.require(bytes(assembled) == actual, 'Assembly leaves extra, missing, or modified source text')
    h.require(bundle['remaining_project_origins'] == previous_manifest['sources'][21:],
              'The seven project mathematical origins differ')
    edit = bundle['project_import_edit']
    resolve_reference(edit['original'], ORIGIN_PATHS['KernelLowOperation'], h)
    resolve_binding(edit['candidate'], SOURCE_PATHS['KernelLowOperation'], h)
    old, new = b'import ConLeche.Kernel.TypeChecker\n', b'import KernelCompactCore\n'
    original = ORIGIN_PATHS['KernelLowOperation'].read_bytes()
    candidate = SOURCE_PATHS['KernelLowOperation'].read_bytes()
    h.require(edit['original_text'].encode() == old and edit['replacement_text'].encode() == new
              and original.count(old) == candidate.count(new) == 1
              and original.replace(old, new, 1) == candidate
              and candidate.replace(new, old, 1) == original
              and edit['exact_inverse_verified'] is True,
              'The project adapter is not exactly the single import substitution')
    # This proves source text correspondence, not identical elaborated private names.
    return inverse_records


def preflight(args, h, guard):
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    manifest = read(MANIFEST)
    previous_manifest, previous_report = read(PREVIOUS_MANIFEST), read(PREVIOUS_REPORT)
    bundle, audit = read(BUNDLE), read(CANDIDATE / 'SOURCE-AUDIT.json')
    h.require(manifest['format'] == MANIFEST_FORMAT
              and manifest['status'] == 'frozen_source_only_ready_for_root_review'
              and manifest['module_order'] == MODULES and manifest['root_module'] == MODULES[-1]
              and manifest['mathematical_origin_order'] == ORIGIN_MODULES
              and manifest['physical_module_count'] == 8 and manifest['mathematical_origin_count'] == 28
              and manifest['imports'] == IMPORTS and manifest['raw_source_print_identifiers'] == RAW_ROOTS
              and manifest['required_prints'] == ROOTS and manifest['required_axiom_report_count'] == REQUIRED_ROOTS
              and manifest['expected_artifact_count'] == EXPECTED_ARTIFACTS
              and manifest['policy'] == POLICY and manifest['prepared_objects'] == [],
              'Whole source/root/import/resource manifest differs')
    h.require(len(manifest['sources']) == 8 and len(manifest['origin_sources']) == 28
              and sum(map(len, ROOTS.values())) == REQUIRED_ROOTS
              and len({name for names in ROOTS.values() for name in names}) == REQUIRED_ROOTS,
              'Whole fresh physical-source/origin/root census differs')
    sources = []
    for row, module in zip(manifest['sources'], MODULES):
        h.require(row['module'] == module and row['imports'] == IMPORTS[module]
                  and row['fully_qualified_roots'] == ROOTS[module]
                  and row['raw_source_print_identifiers'] == RAW_ROOTS[module]
                  and row['module_format'] is (module == 'KernelCompactCore'),
                  'Source/module/root order differs')
        sources.append({**resolve_binding(row, SOURCE_PATHS[module], h),
            'module': module, 'imports': IMPORTS[module], 'output_suffixes': list(suffixes(module))})
        check_source(module, SOURCE_PATHS[module], guard, h)
    h.require(manifest['source_fingerprint'] == source_fingerprint(sources), 'Source/policy fingerprint differs')
    origins = []
    for row, module in zip(manifest['origin_sources'], ORIGIN_MODULES):
        h.require(row['module'] == module and row['imports'] == ORIGIN_IMPORTS[module]
                  and row['fully_qualified_roots'] == ORIGIN_ROOTS[module]
                  and row['raw_source_print_identifiers'] == ORIGIN_RAW_ROOTS[module]
                  and row['module_format'] is (module in UPSTREAM_MODULES),
                  'Origin module/import/root order differs')
        origins.append({**resolve_binding(row, ORIGIN_PATHS[module], h), 'module': module,
                        'imports': ORIGIN_IMPORTS[module]})
        check_source(module, ORIGIN_PATHS[module], guard, h, origin=True)
    done = set()
    for module in MODULES:
        h.require(all(name in done for name in IMPORTS[module] if name in SOURCE_PATHS),
                  'A fresh physical import appears after its consumer')
        h.require(all(name in SOURCE_PATHS or name == 'Init' or name.startswith(('Init.', 'Std.'))
                      for name in IMPORTS[module]), 'Undeclared nonstandard import')
        done.add(module)
    reachable, pending = set(), [MODULES[-1]]
    while pending:
        module = pending.pop()
        if module not in reachable:
            reachable.add(module)
            pending.extend(name for name in IMPORTS[module] if name in SOURCE_PATHS)
    h.require(reachable == set(MODULES), 'The physical closure is not exactly reachable from the final module')

    # The failed compact attempt supplies exact source provenance, never accepted Natrec proofs.
    h.require(previous_manifest['format'] == 'adwh-kernel-compact-reference-full-manifest-v1'
              and previous_manifest['module_order'] == ORIGIN_MODULES
              and previous_manifest['imports'] == ORIGIN_IMPORTS
              and previous_manifest['required_prints'] == ORIGIN_ROOTS
              and previous_manifest['raw_source_print_identifiers'] == ORIGIN_RAW_ROOTS
              and previous_manifest['policy'] == POLICY and previous_manifest['prepared_objects'] == []
              and previous_manifest['required_axiom_report_count'] == REQUIRED_ROOTS
              and previous_manifest['expected_artifact_count'] == 140
              and previous_manifest['source_fingerprint'] == source_fingerprint(previous_manifest['sources'])
              and previous_report['format'] == 'adwh-kernel-compact-reference-full-gate-v1'
              and previous_report['status'] == 'failed' and previous_report['attempt'] == 'complete-01'
              and previous_report['stage'] == 'complete' and previous_report['module_order'] == ORIGIN_MODULES
              and previous_report['required_prints'] == ORIGIN_ROOTS
              and previous_report['required_axiom_report_count'] == REQUIRED_ROOTS
              and previous_report['accepted_axiom_report_count'] == 51
              and previous_report['observed_axiom_report_count'] == 51
              and len(previous_report['artifacts']) == 138
              and previous_report['prepared_objects'] == []
              and previous_report['all_sources_snapshots_controls_runtime_unchanged'] is True
              and previous_report['all_selected_mathematical_sources_freshly_checked'] is False
              and previous_report['source_fingerprint'] == previous_manifest['source_fingerprint'],
              'Immutable compact01 provenance or failed-acceptance boundary differs')
    last = previous_report['modules'][-1]
    h.require([row['module'] for row in previous_report['modules']] == ORIGIN_MODULES
              and all(row['status'] == 'passed' for row in previous_report['modules'][:-1])
              and last['module'] == 'KernelNatRecursor' and last['status'] == 'failed'
              and last['exit_code'] == -9 and last['limit_exceeded'] == 'wall_time'
              and last['axiom_audit']['observed_count'] == 0
              and last['stdout']['bytes'] == last['stderr']['bytes'] == 0,
              'The actual compact01 failure prefix or silent terminal module differs')
    h.require(all(previous_report['source_manifest'][key] == h.binding(PREVIOUS_MANIFEST)[key]
                  for key in ('bytes', 'sha256'))
              and len(previous_report['source_bindings']) == len(previous_manifest['sources']) == 28,
              'Failed compact01 report/source-manifest crosslink differs')
    for saved, old, current in zip(previous_report['source_bindings'], previous_manifest['sources'], origins):
        h.require(saved['module'] == old['module'] == current['module']
                  and all(saved[key] == old[key] == current[key] for key in ('bytes', 'sha256', 'imports')),
                  'A mathematical origin is not exactly the executed compact01 source')
        resolve_reference(old, ORIGIN_PATHS[current['module']], h)
    for module in PROJECT_MODULES:
        if module != 'KernelLowOperation':
            h.require(SOURCE_PATHS[module] == ORIGIN_PATHS[module],
                      'One of the six unchanged project sources was substituted')
    inverse_records = verify_bundle(bundle, previous_manifest, guard, h)
    for key, path in [('previous_compact_manifest', PREVIOUS_MANIFEST), ('previous_compact_report', PREVIOUS_REPORT),
                      ('source_bundle', BUNDLE), ('scope_command_source', SCOPE_SOURCE)]:
        resolve_binding(manifest[key], path, h)
    expected_resolutions = [{'recorded_path': str(Path(old).relative_to(ROOT)),
                            'canonical_path': str(new.relative_to(ROOT))}
                           for old, new in REFERENCE_RESOLUTIONS.items()]
    h.require(manifest['immutable_reference_resolutions'] == expected_resolutions,
              'The explicit immutable compact01 resolution list differs')

    for key, expected in [('execution_controls', CURRENT[:2]), ('current_controls', CURRENT[3:]),
                           ('historical_controls', BASE_HISTORY)]:
        h.require(len(manifest[key]) == len(expected), 'Control count differs: ' + key)
        for row, (role, path) in zip(manifest[key], expected):
            h.require(row['role'] == role, 'Control role/order differs: ' + key)
            resolve_binding(row, path, h)
    controls = [{**h.binding(path), 'role': role, 'snapshot_required': True,
                 'retained_historical_reference': False} for role, path in CURRENT]
    controls += [{**h.binding(path), 'role': role, 'snapshot_required': False,
                  'retained_historical_reference': True} for role, path in BASE_HISTORY]
    h.require(len(controls) == 47 and len({row['path'] for row in controls}) == 47
              and len({row['role'] for row in controls}) == 47, 'Duplicate or missing control identity')
    bound = {row['path']: row for row in sources + controls}
    h.require(len(bound) == 55 and all(str(path) in bound for path in ORIGIN_PATHS.values()),
              'Physical and origin-source bindings are incomplete or duplicated')
    # Original compact controls are immutable provenance. They are not loaded or executed.
    old_roles = {'runner': 'run_gate.py', 'protocol': 'PROTOCOL.md', 'source_manifest': 'source-manifest.json',
        'compact_author_plan': 'PLAN.md', 'source_cut_script': 'prepare_source_cut.py',
        'source_cuts': 'SOURCE-CUTS.json', 'compact_source_review': 'SOURCE-REVIEW.md',
        'compact_source_audit': 'SOURCE-AUDIT.json'}
    for role, name in old_roles.items():
        matches = [row for row in previous_report['controls'] if row['role'] == role]
        h.require(len(matches) == 1 and matches[0]['snapshot_required'] is True,
                  'Missing immutable compact01 control role: ' + role)
        old = matches[0]
        canonical = h.binding(PREVIOUS_CONTROLS / name)
        h.require(all(old[key] == canonical[key] == old['snapshot'][key] for key in ('bytes', 'sha256')),
                  'The failed compact01 control text was not retained exactly')
    omissions = {'additional_csimp': 4, 'total_csimp': 19, 'additional_simp': 30,
                 'additional_inline': 9, 'source_cut_count': 7}
    cuts = read(PREVIOUS_CONTROLS / 'SOURCE-CUTS.json')
    h.require(previous_manifest['compact_omissions'] == manifest['compact_omissions'] == omissions
              and previous_report['omitted_compiler_substitution_count'] == 19
              and previous_report['additional_compact_compiler_substitutions_omitted'] == 4
              and previous_report['additional_simp_registrations_omitted'] == 30
              and previous_report['additional_inline_registrations_omitted'] == 9
              and cuts['omitted_compiler_substitutions'] == 4
              and cuts['omitted_simp_registrations'] == 30
              and cuts['omitted_inline_registrations'] == 9,
              'Inherited source-cut/registration disclosure differs')

    # The independent source/scope review must cover the exact 28 origins, both
    # new physical source files, assembly controls and pinned scope semantics.
    h.require(audit['format'] == 'adwh-kernel-bundled-reference-independent-source-audit-v1'
              and audit['status'] == 'passed_source_only_review_not_compiled'
              and audit['physical_module_order'] == MODULES
              and audit['physical_compiler_unit_count'] == 8
              and audit['mathematical_origin_unit_count'] == 28
              and audit['origin_unit_count'] == 21
              and audit['required_axiom_report_count'] == REQUIRED_ROOTS
              and audit['expected_default_artifact_count'] == EXPECTED_ARTIFACTS
              and audit['fully_qualified_roots'] == [name for module in MODULES for name in ROOTS[module]]
              and audit['physical_sources'] == manifest['sources']
              and audit['header_replacement_count'] == 60
              and audit['project_import_edit_count'] == 1
              and audit['explicit_private_declaration_count'] == 24
              and audit['lexical_named_declaration_count'] == 501
              and audit['private_declaration_modules'] == ['ConLeche.Kernel.PropWhen']
              and audit['cross_unit_private_name_collisions'] == {}
              and len(audit['checks']) == 14 and all(value is True for value in audit['checks'].values())
              and len(audit['execution']) == 5 and all(value is False for value in audit['execution'].values()),
              'Independent bundle/source review is absent or describes another candidate')
    expected_review_limits = {'Elab.async': False, 'allowed_axioms': ['propext', 'Quot.sound', 'Classical.choice'],
        'autoImplicit': False, 'cpu_threads': 1, 'default_heartbeat_and_recursion_limits': True,
        'lean_M_MiB': 1024, 'lean_threads': 1, 'prepared_objects': 0, 'rss_kib': 1048576,
        'wall_seconds': 30, 'warningAsError': True}
    h.require(audit['limits'] == expected_review_limits
              and audit['existing_omissions'] == {'additional_omissions_from_bundling': 0,
                  'last_compact_additional_csimp': 4, 'last_compact_inline': 9,
                  'last_compact_simp': 30, 'total_csimp': 19},
              'Independent review resources or omission disclosure differs')
    resolve_binding(audit['review'], CANDIDATE / 'SOURCE-REVIEW.md', h)
    resolve_binding(audit['failed_compact01_provenance'], PREVIOUS_REPORT, h)
    resolve_binding(audit['scope_primary_source'], SCOPE_SOURCE, h)
    h.require([row['module'] for row in audit['reference_source_scope']] == ORIGIN_MODULES
              and [row['module'] for row in audit['origin_units']] == UPSTREAM_MODULES,
              'Independent origin source/scope census differs')
    for row, old in zip(audit['reference_source_scope'], previous_manifest['sources']):
        h.require(row == old, 'Independent review does not describe the exact compact01 source row')
        resolve_reference(row, ORIGIN_PATHS[row['module']], h)
    for row, mapped, checked in zip(audit['origin_units'], bundle['origin_units'], inverse_records):
        h.require(row['module'] == mapped['module'] == checked['module']
                  and row['header_edit_count'] == checked['header_edit_count']
                  and row['body_bytes'] == mapped['bundle_body_bytes']
                  and row['body_sha256'] == mapped['bundle_body_sha256']
                  and row['exact_forward_and_inverse'] is True
                  and row['all_explicit_namespaces_and_inner_scopes_closed'] is True
                  and row['one_public_section_closed'] is True
                  and len(row['eof_scope_stack']) == 1
                  and row['eof_scope_stack'][0] == {'header': '', 'kind': 'section', 'public': True},
                  'Independent EOF scope or source-inverse record differs')
        resolve_reference(row['original'], ORIGIN_PATHS[row['module']], h)
    reviewed = []
    for row in audit['inputs']:
        path = reference_path(row['path'])
        h.require(str(path) in bound, 'Bundle review input is absent from the whole gate')
        resolve_reference(row, path, h)
        reviewed.append(str(path))
    required_review = {str(path) for path in [*ORIGIN_PATHS.values(),
        SOURCE_PATHS['KernelCompactCore'], SOURCE_PATHS['KernelLowOperation'],
        CANDIDATE / 'PLAN.md', CANDIDATE / 'prepare_source_bundle.py', BUNDLE,
        SCOPE_SOURCE, PREVIOUS_MANIFEST, PREVIOUS_REPORT]}
    h.require(len(reviewed) == len(set(reviewed)) == audit['input_count'] == 36
              and set(reviewed) == required_review, 'Independent direct-input source/scope coverage differs')

    compiler_path = args.lean.resolve()
    h.TOOLCHAIN = compiler_path.parent.parent
    pin = read(PIN)
    compiler = h.binding(compiler_path)
    h.require(compiler_path.name == 'lean' and pin['version'] == '4.35.0'
              and pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
              and all(compiler[k] == pin['binaries']['lean'][k] for k in ('bytes', 'sha256')),
              'Pinned compiler differs')
    reference = read(RUNTIME_REFERENCE)
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in reference['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((h.TOOLCHAIN / 'lib/lean').glob('*.so'))]
    h.require(len(runtime) == 5 and {Path(row['path']).name: (row['bytes'], row['sha256'])
                                   for row in runtime} == expected_runtime, 'Pinned runtime differs')
    verify(sources + controls + [compiler] + runtime, h)
    return {'sources': sources, 'origins': origins, 'controls': controls,
            'source_fingerprint': source_fingerprint(sources), 'source_inverse_checks': inverse_records,
            'compiler': compiler, 'runtime_libraries': runtime,
            'compiler_release': pin['version'], 'compiler_commit': pin['commit']}


def audit_logs(module, stdout_path, stderr_path):
    out = stdout_path.read_text() if stdout_path.is_file() else ''
    err = stderr_path.read_text() if stderr_path.is_file() else ''
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [row['root'] for row in raw]
    allowed = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'passed': stdout_path.is_file() and stderr_path.is_file() and names == ROOTS[module]
                and allowed and not err and not pattern.sub('', out).strip(),
            'required_count': len(ROOTS[module]), 'observed_count': len(raw),
            'observed_unique_count': len(set(names)), 'raw_reports': raw,
            'reports': {row['root']: row['axioms'] for row in raw},
            'duplicate_names': [name for name, n in Counter(names).items() if n > 1],
            'exact_ordered_names': names == ROOTS[module], 'all_raw_axiom_names_permitted': allowed,
            'stderr_empty': not err, 'unparsed_stdout': pattern.sub('', out).strip()}



def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker.exists(), 'Attempt or unchanged closure already executed')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, inputs = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    inputs.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'stage': 'complete', 'attempt': args.attempt,
        'module_order': MODULES, 'root_module': 'KernelNatRecursor',
        'physical_module_count': 8, 'mathematical_origin_count': 28,
        'mathematical_origin_order': ORIGIN_MODULES, 'origin_source_bindings': plan['origins'],
        'source_inverse_checks': plan['source_inverse_checks'],
        'source_module_consolidation_checked': False,
        'all_mathematical_origins_covered_by_fresh_sources': False,
        'original_units_compiled_separately': False,
        'identical_elaborated_private_names_claimed': False,
        'source_bindings': plan['sources'], 'controls': plan['controls'],
        'source_manifest': h.binding(MANIFEST), 'source_fingerprint': plan['source_fingerprint'],
        'compiler': plan['compiler'], 'compiler_release': plan['compiler_release'],
        'compiler_commit': plan['compiler_commit'], 'runtime_libraries': plan['runtime_libraries'],
        'constraints': {**POLICY, 'cpu_affinity': []}, 'execution_marker': None,
        'required_prints': ROOTS, 'raw_source_print_identifiers': RAW_ROOTS,
        'required_axiom_report_count': REQUIRED_ROOTS, 'observed_axiom_report_count': 0,
        'observed_unique_axiom_root_count': 0, 'accepted_axiom_report_count': 0,
        'modules': [], 'seconds': None, 'peak_child_rss_kib': 0, 'artifacts': [],
        'expected_artifact_count': EXPECTED_ARTIFACTS, 'prepared_objects': [],
        'object_search_path': str(build), 'current_control_snapshot_count': len(CURRENT),
        'historical_reference_count': len(plan['controls']) - len(CURRENT),
        'all_selected_mathematical_sources_freshly_checked': False,
        'actual_reducer_operation_refinement_proved': False,
        'logical_reference_slice_checked': False,
        'failed_compact01_source_provenance_only': h.binding(PREVIOUS_REPORT),
        'failed_compact01_mathematical_acceptance_assumed': False,
        'general_scalar_step_contract_proved': False,
        'conditional_nat_recursor_step_contract_proved': False,
        'fuel_uniform_run_composition_proved': False,
        'actual_recursor_pins_discharged': False,
        'whole_structural_evaluator_normalization_proved': False,
        'omitted_compiler_substitution_count': 19,
        'additional_compact_compiler_substitutions_omitted': 4,
        'additional_simp_registrations_omitted': 30,
        'additional_inline_registrations_omitted': 9,
        'compact_source_cut_count': 7,
        'compact_optional_source_slice_checked': False,
        'native_speedup_claimed': False,
        'native_compilation_optimization_choices_changed': True,
        'whole_cached_engine_compatibility_proved': False,
        'exact_build_artifact_inventory': False, 'all_sources_snapshots_controls_runtime_unchanged': False,
        'compiled_experimental_or_upstream_imports_reused': False,
        'native_program_or_counter_executed': False, 'stock_numeral_theorem_proved': False,
        'source_constant_recognition_proved': False, 'universal_count_reducer_refinement_proved': False,
        'optimized_kernel_installed': False, 'source_count_proved': False,
        'integrated_project_modified': False,
        'authorship': {'source_bundle': 'root', 'compact_source_cut': 'root',
                      'scalar_source': 'root', 'recursor_source': 'regression_audit',
                      'independent_source_and_scope_reviewer': 'validity_contracts',
                      'exact_origin_source_provenance': 'kernel-compact-reference complete-01 (failed)',
                      'gate_author': 'counting_route', 'executor': 'root'}}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings']:
            destination = module_file(frozen, row['module'], '.lean')
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            destination.chmod(0o444)
            row['snapshot'] = h.binding(destination)
            h.require(all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')), 'Source snapshot differs')
        for row in report['controls']:
            if row['snapshot_required']:
                destination = inputs / Path(row['path']).relative_to(ROOT)
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as stream:
                    stream.write(Path(row['path']).read_bytes())
                destination.chmod(0o444)
                row['snapshot'] = h.binding(destination)
                h.require(all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')), 'Control snapshot differs')
        all_inputs = report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']]
        verify(all_inputs, h)
        verify([row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row], h, True)
        marker.parent.mkdir(exist_ok=True)
        marker_body = {'format': FORMAT, 'attempt': args.attempt, 'source_fingerprint': plan['source_fingerprint'],
            'module_order': MODULES, 'source_bindings': report['source_bindings'], 'controls': report['controls'],
            'mathematical_origin_order': ORIGIN_MODULES, 'origin_source_bindings': report['origin_source_bindings'],
            'compiler': report['compiler'], 'runtime_libraries': report['runtime_libraries'], 'policy': POLICY,
            'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        with marker.open('x') as stream:
            stream.write(json.dumps(marker_body, indent=2, sort_keys=True) + '\n')
        marker.chmod(0o444)
        report['execution_marker'] = h.binding(marker)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for name in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(name, None)
        env['LEAN_IMPORT_WORKERS'] = '1'
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        for module in MODULES:
            olean = module_file(build, module, '.olean')
            olean.parent.mkdir(parents=True, exist_ok=True)
            command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                '-DwarningAsError=true', '-DElab.async=false', '-o', str(olean),
                '-i', str(module_file(build, module, '.ilean')), module.replace('.', '/') + '.lean']
            stdout_path, stderr_path = attempt / (module + '.stdout.log'), attempt / (module + '.stderr.log')
            record = {'module': module, 'command': command, 'status': 'running',
                      'required_output_suffixes': list(suffixes(module))}
            report['modules'].append(record)
            h.save(report_path, report)
            try:
                result = h.child(command, frozen, env, stdout_path, stderr_path, cpu, deadline)
                record.update(result)
            finally:
                for key, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                    if path.is_file():
                        record[key] = h.binding(path)
                audit = audit_logs(module, stdout_path, stderr_path)
                record['axiom_audit'] = audit
                objects = all(module_file(build, module, suffix).is_file() for suffix in suffixes(module))
                good = record.get('exit_code') == 0 and record.get('within_limits') is True and audit['passed'] and objects
                record['required_outputs_present'] = objects
                record['status'] = 'passed' if good else 'failed'
                report['observed_axiom_report_count'] = sum(m['axiom_audit']['observed_count'] for m in report['modules'])
                report['observed_unique_axiom_root_count'] = len({r['root'] for m in report['modules']
                                                                 for r in m['axiom_audit']['raw_reports']})
                report['accepted_axiom_report_count'] = sum(m['axiom_audit']['observed_count']
                                                           for m in report['modules'] if m['status'] == 'passed')
                h.save(report_path, report)
            h.require(record['status'] == 'passed', 'Fresh module/axiom/output/resource failure: ' + module)
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            h.require(len(snapshots) == len(MODULES) + len(CURRENT), 'Incomplete source/control snapshots')
            verify(snapshots, h, True)
            for row in report['source_bindings'] + report['controls']:
                if row in report['source_bindings'] or row['snapshot_required']:
                    h.require('snapshot' in row and all(row['snapshot'][k] == row[k] for k in ('bytes', 'sha256')),
                              'Missing or substituted snapshot identity')
            verify([m[key] for m in report['modules'] for key in ('stdout', 'stderr') if key in m], h)
            h.require(report['execution_marker'] is not None, 'No execution marker was reserved')
            verify([report['execution_marker']], h, True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            expected = {str(module_file(build, module, suffix)) for module in MODULES for suffix in suffixes(module)}
            report['exact_build_artifact_inventory'] = len(expected) == EXPECTED_ARTIFACTS \
                and {row['path'] for row in report['artifacts']} == expected
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((m.get('sampled_tree_and_wait4_peak_rss_kib', 0)
                                           for m in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
            and [m['module'] for m in report['modules']] == MODULES
            and all(m['status'] == 'passed' for m in report['modules'])
            and report['accepted_axiom_report_count'] == REQUIRED_ROOTS
            and report['seconds'] is not None and report['seconds'] <= 30
            and report['peak_child_rss_kib'] <= 1048576
            and report['exact_build_artifact_inventory']
            and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['actual_reducer_operation_refinement_proved'] = passed
        report['logical_reference_slice_checked'] = passed
        report['compact_optional_source_slice_checked'] = passed
        report['source_module_consolidation_checked'] = passed
        report['all_mathematical_origins_covered_by_fresh_sources'] = passed
        report['general_scalar_step_contract_proved'] = passed
        report['conditional_nat_recursor_step_contract_proved'] = passed
        report['fuel_uniform_run_composition_proved'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
        'seconds': report['seconds'], 'peak_rss_kib': report['peak_child_rss_kib'],
        'observed_roots': report['observed_axiom_report_count'],
        'accepted_roots': report['accepted_axiom_report_count']}, sort_keys=True))
    return 0 if report['status'] == 'passed' else 1



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, default=ROOT.parent / 'toolchains/lean-4.35.0-linux/bin/lean')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt):
        raise ValueError('Attempt must be complete-01 through complete-99')
    for path, expected in FIXED.items():
        if sha(path) != expected:
            raise ValueError('Pinned code/evidence differs before loading: ' + str(path))
    h = load(HELPER, 'kernel_bundled_reference_resource_helper')
    guard = load(GUARD, 'kernel_bundled_reference_source_guard')
    h.require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Pinned helper contract differs')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': MODULES,
            'required_axiom_report_count': REQUIRED_ROOTS, 'expected_artifact_count': EXPECTED_ARTIFACTS,
            'physical_module_count': 8, 'mathematical_origin_count': 28,
            'prepared_objects': 0, 'source_fingerprint': plan['source_fingerprint'],
            'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)



if __name__ == '__main__':
    raise SystemExit(main())
