# Fresh source-bundle proof gate

Status: prepared for independent control review and root execution. No gate,
preflight, compiler, exporter, native program or counter was executed by the
gate author. Only root may perform the selected execution.

## Exact selected change

The actual `kernel-compact-reference` complete-01 failed after its 27-module
successful prefix, with 51 accepted reports, 138 outputs and no Natrec output
before the shared deadline. Its report, logs, marker and source/control texts
remain immutable. This candidate changes the physical source layout, retaining
all 28 mathematical source origins. It does not assume a successful result
from the failed attempt or attribute that failure to any one theorem.

`KernelCompactCore` contains the 21 upstream source units in their previous
topological order. The exact source map replaces only each module/import header
with a comment and adds one explicit `end` at each former EOF to close that
unit's retained public section. It imports `Std.Data.HashMap` and
`import all Init.Util` once. The six unchanged project sources retain their
exact canonical bytes; the seventh, `KernelLowOperation`, has exactly one
import changed from `ConLeche.Kernel.TypeChecker` to `KernelCompactCore`.

The gate independently reconstructs the exact bundle bytes from the retained
origins, verifies every mapped byte interval, inverts every header replacement,
checks every EOF closure, and inverts the one project import edit. The assembly
script is a hash-bound source control and is never imported or run by the gate.

Text correspondence does not establish identical elaborated private names or
module ownership. Import visibility and preceding persistent registrations
also change. The independent source/scope review is mandatory and must bind
all 28 origins, both new physical sources, the assembly map/script/plan,
pinned scope-command semantics, and the actual preceding manifest/report.
Fresh acceptance remains required. No claim of complete cached-engine
compatibility follows from source concatenation or from a successful gate.

## Eight physical compiler inputs

| Order | Fresh module | Exact ordered axiom reports | Default outputs |
|---:|---|---:|---:|
| 1 | `KernelCompactCore` | 0 | 6 |
| 2 | `FiniteFold` | 9 | 2 |
| 3 | `FirstOrderNat` | 9 | 2 |
| 4 | `SaturatingUInt64` | 8 | 2 |
| 5 | `UInt64MaskOps` | 16 | 2 |
| 6 | `KernelLowOperation` | 5 | 2 |
| 7 | `KernelScalarSteps` | 4 | 2 |
| 8 | `KernelNatRecursor` | 11 | 2 |
| **Total** | **8 physical / 28 origin units** | **62** | **20** |

The final module reaches exactly these eight physical inputs through the
checked import graph. Only pinned standard `Init`/`Std` imports are external.
There are no prepared experimental or upstream objects. All eight modules
compile freshly in a new build directory in the displayed order.

The module-format bundle produces `.olean`, `.olean.server`, `.olean.private`,
`.ir.sig`, `.ir`, and `.ilean`. Each legacy project input produces `.olean`
and `.ilean`. The entire final build inventory must equal those 20 paths;
default outputs are neither disabled nor omitted from accounting. The pinned
Lean environment/frontend/compiler-option sources documenting this output
contract are retained as historical controls.

The source guard checks both the eight physical inputs and all 28 origins.
It rejects admissions, unsafe/kernel-bypass mechanisms and unexpected executable
elaborator commands. Exact imports, namespace/print inventories, module format
and options must match. The two existing scoped `linter.unusedSimpArgs false`
commands from original `ExprOps` occur unchanged in the bundle. No new lint
suppression is permitted. Every project source retains the three strict
`autoImplicit`, `warningAsError`, and `Elab.async` settings.

## Immutable provenance and direct bindings

The previous manifest and report are pinned to:

- Manifest SHA256 `7aeb00b27645d1c791d2fed7a7e4ab71cd3bfc51665fc03157a44040e68fc8e6`.
- Failed report SHA256 `e955b88b4b5b9a87b7f37c85253fb7f74b0db660eadd186595249104b78c1252`.

The manifest's source bindings must match the actual report's ordered 28 rows.
The preserved prefix/failure classification must remain 51 accepted reports,
no Natrec reports, empty Natrec stdout/stderr, exit minus nine at the wall-time
limit, and 138 partial outputs. These are source provenance facts, not new
acceptance premises.

Exactly three recorded locations are resolved to canonical immutable copies:
the compact manifest and its `Expr`/`Canon` variants. The new manifest lists
these path resolutions explicitly. Scalar comes from failed recursion02 and
Natrec from failed recursion05 at their already-canonical paths. No living
predecessor control is used as an assumed immutable reference.

The current eight snapshot controls are the runner, protocol, source manifest,
author plan, assembly script/map, and independent source review/audit. The gate
also binds 39 historical inputs: 22 nonphysical origin sources, nine retained
compact01 report/control files, the resource helper/source guard/toolchain and
runtime references, three module-output API sources, and the retained scope
command source. Six remaining origins coincide with physical source rows.
Thus there are 55 unique source/control file bindings. The independent bundle
review's exact 36 direct inputs must all appear in this bound set.

The source-cut history remains disclosed: 15 earlier compiler substitutions
and four additional compact substitutions are omitted (19 total); the compact
variant also omits 30 simp registrations and nine inline registrations in
seven source cuts. Consolidation removes no further mathematical declarations
or proof bodies. The saved compact map and independent review are retained as
historical controls, without importing their old gate or rerunning it.

## Fixed resource and execution policy

One absolute deadline covers the eight fresh compiler commands and final
integrity/artifact checks: **30 seconds cumulative, one CPU, one compiler
thread, 1 GiB resident memory**, with Lean's `-M1024`. The exact unchanged
`run_comparison.py` resource helper enforces process-group limits and measures
sampled tree RSS plus wait4 peak RSS. No per-module deadline reset, resource
increase, alternate compiler mode or independently timed proof subgate is
available.

Every command is:

```text
lean -j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false \
  -o <fresh-build>/<Module>.olean -i <fresh-build>/<Module>.ilean <Module>.lean
```

Heartbeats, recursion depth and compiler options retain their defaults. The
compiler and five shared runtime libraries match the pinned Lean4.35.0 commit
`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. `LEAN_PATH` contains only the fresh
build directory; import workers are set to one. The resource helper cleans the
environment, and the gate removes `LD_PRELOAD`, `LD_AUDIT`, and
`LD_LIBRARY_PATH`. One existing compile lock serializes mathematical work.

Before any compiler starts, eight physical sources and eight current controls
are snapshotted read-only (16 snapshots). All historical sources/controls stay
hash-bound in place. An exclusive permanent marker uses the SHA256 of the
ordered physical source hashes and fixed policy. Those sources are required
to reconstruct all 28 mathematical origins exactly; a mere control-file or
attempt-label change does not yield a new source key. The marker contains both
physical and origin bindings and is reserved before compilation. Failed
attempts consume the key and cannot be retried unchanged. Earlier markers are
never touched.

## Raw reports, acceptance and failure

The raw stdout/stderr and all observed axiom reports are retained even when a
module fails. Observed, unique and accepted report counts are separate. A
module contributes accepted reports only when it exits zero within limits,
produces its exact ordered print inventory with permitted axioms only, has no
unparsed output or stderr, and produces every required default output.
Permitted axioms remain exactly `propext`, `Quot.sound`, and `Classical.choice`.

Overall success requires all eight modules, all 62 accepted reports, the exact
20-file build inventory, the one shared time/RSS limits, and successful
postchecks of sources, controls, snapshots, marker, logs, compiler and runtime.
A failure preserves its partial report/logs/artifacts and does not accept an
unreached or failed theorem. Silent logs do not demonstrate partial proof
progress.

On success, the report may mark the conditional low/scalar/Natrec contracts,
fuel-uniform composition and the checked source consolidation as proved in
this fresh physical closure. Actual installed pins, whole structural-fold
normalization, a cache insertion rule for that fold, optimized-kernel
installation, the source count and a stock numeral theorem all remain false.
No native program or counter is part of this gate, and no timing improvement
is claimed before or solely from source preparation.

## Root dispatch

After independent control review, root may run a nonexecuting preflight:

```text
python3 -I next-iteration/kernel-bundled-reference/gate/run_gate.py --attempt complete-01
```

Only root may select the single actual attempt:

```text
python3 -I next-iteration/kernel-bundled-reference/gate/run_gate.py --attempt complete-01 --run
```

The gate author and independent reviewer do not import, preflight or execute
the runner. A later source correction requires explicit new reviewed source
bytes and a new named attempt; the old marker/evidence remain immutable.
