#!/usr/bin/env python3
"""Assemble exact saved Lean source text; never import a gate or execute Lean."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PREVIOUS = ROOT / 'next-iteration/kernel-compact-reference'
MANIFEST = PREVIOUS / 'gate/source-manifest.json'
HEADER = (b'module\n\npublic import Std.Data.HashMap\nimport all Init.Util\n\n'
          b'/-! This is a fresh source bundle of the 21 exact compact logical\n'
          b'kernel units. No compiled objects are inputs. Each original public\n'
          b'section is closed explicitly at its former end of file. See the\n'
          b'exact reversible SOURCE-BUNDLE.json origin and edit map. -/\n\n')


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def binding(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': digest(data)}


def main() -> None:
    manifest = json.loads(MANIFEST.read_text())
    assert len(manifest['sources']) == 28
    origins = manifest['sources'][:21]
    internal = {row['module'] for row in origins}
    bundle = bytearray(HEADER)
    rows = []
    for index, row in enumerate(origins):
        path = ROOT / row['path']
        original = path.read_bytes()
        assert len(original) == row['bytes'] and digest(original) == row['sha256']
        assert original.startswith(b'module\n') and original.endswith(b'\n')
        lines = original.splitlines(keepends=True)
        edits, segments, offset, imports = [], [], 0, []
        public_sections = 0
        for line_number, line in enumerate(lines, 1):
            text = line.decode()
            import_match = re.fullmatch(r'((?:(?:public|private|meta) )*import )(all )?([A-Za-z0-9_. ]+)\n', text)
            is_header = line_number == 1
            if re.fullmatch(r'(?:@\[expose\] )?public section\n', text):
                public_sections += 1
            if is_header or import_match:
                if import_match:
                    names = import_match[3].split()
                    assert len(names) == 1
                    assert names[0] in internal or names[0] in {'Std.Data.HashMap', 'Init.Util'}
                    imports.extend(names)
                replacement = (f'-- Bundled origin {index:02d}, header line {line_number}: '
                               + text.rstrip('\n') + '\n').encode()
                edits.append({'original_offset': offset, 'original_text': text,
                              'replacement_text': replacement.decode()})
                segments.append(replacement)
            else:
                segments.append(line)
            offset += len(line)
        assert imports == row['imports'] and public_sections == 1
        body = b''.join(segments)
        forward = original
        for edit in reversed(edits):
            at = edit['original_offset']
            old, new = edit['original_text'].encode(), edit['replacement_text'].encode()
            assert forward[at:at + len(old)] == old
            forward = forward[:at] + new + forward[at + len(old):]
        assert forward == body
        inverse = body
        for edit in edits:
            old, new = edit['original_text'].encode(), edit['replacement_text'].encode()
            assert inverse.count(new) == 1
            inverse = inverse.replace(new, old, 1)
        assert inverse == original
        before = f'/- BEGIN exact source origin {row["module"]} -/\n'.encode()
        after = (f'\nend -- original EOF public section of {row["module"]}\n'
                 f'/- END exact source origin {row["module"]} -/\n\n').encode()
        bundle.extend(before)
        start = len(bundle)
        bundle.extend(body)
        bundle.extend(after)
        rows.append({'module': row['module'], 'original': binding(path), 'imports': imports,
                     'bundle_body_start_byte': start, 'bundle_body_bytes': len(body),
                     'bundle_body_sha256': digest(body), 'edits': edits,
                     'prefix_text': before.decode(), 'suffix_text': after.decode(),
                     'original_eof_public_sections_explicitly_closed': 1,
                     'exact_inverse_verified': True})

    destination = HERE / 'source/KernelCompactCore.lean'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(bundle)
    low_row = next(row for row in manifest['sources'] if row['module'] == 'KernelLowOperation')
    low_path = ROOT / low_row['path']
    original_low = low_path.read_bytes()
    old = b'import ConLeche.Kernel.TypeChecker\n'
    new = b'import KernelCompactCore\n'
    assert original_low.count(old) == 1
    low_source = original_low.replace(old, new, 1)
    low_destination = HERE / 'source/KernelLowOperation.lean'
    low_destination.write_bytes(low_source)
    assert low_source.replace(new, old, 1) == original_low
    record = {'format': 'adwh-kernel-bundled-reference-source-bundle-v1',
              'status': 'source_only_unreviewed_uncompiled',
              'previous_manifest': binding(MANIFEST),
              'bundle_header': HEADER.decode(), 'bundle': binding(destination),
              'origin_unit_count': 21, 'origin_units': rows,
              'project_import_edit': {'original': binding(low_path),
                  'candidate': binding(low_destination), 'original_text': old.decode(),
                  'replacement_text': new.decode(), 'exact_inverse_verified': True},
              'remaining_project_origins': manifest['sources'][21:],
              'physical_compiler_units': 8, 'mathematical_origin_units': 28,
              'same_required_roots': 62, 'expected_default_artifacts': 20,
              'mathematical_definition_or_proof_body_edits': 0,
              'compiled_objects_used': False, 'mathematical_or_native_execution': False,
              'measured_speedup_claimed': False,
              'whole_cached_checker_compatibility_claimed': False}
    target = HERE / 'SOURCE-BUNDLE.json'
    target.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'source_text_assembly_only', 'bundle': binding(destination),
                      'import_adapter': binding(low_destination), 'record': binding(target)}))


if __name__ == '__main__':
    main()
