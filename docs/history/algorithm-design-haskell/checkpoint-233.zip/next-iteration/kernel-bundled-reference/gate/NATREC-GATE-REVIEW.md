# Independent control review: bundled Natrec correction gate

**No control-level blocker found for root's complete02 preflight and fresh execution.** This review is a separate overlay on the unchanged initial GATE-REVIEW/AUDIT. It does not revise their historical complete01 scope. The reviewer read the full runner/protocol diffs, the new correction-verification function and manifest, and performed data/AST/hash checks only. No runner import, preflight, gate, Lean/compiler or native execution occurred.

## Frozen corrected controls

| Control | Bytes | SHA256 |
|---|---:|---|
| run_gate.py | 76,605 | `a98566b93da2d220db8d4b4bc63ea9bff750b9d0d80d0d5c7c0aed9bdadee297` |
| PROTOCOL.md | 12,086 | `c1384d817886c63fa4cc524a91d0c9b0caefbdaf995b858a1bec75bc20683bcf` |
| source-manifest.json | 63,831 | `8a89b6192e285d9b27c7226087cfc7e984be888b95e1480fed0b56ada7661018` |

The recomputed source/policy fingerprint is `29f7b750eb73376afbe5f6b23f26df63d8fc94fac1125aa695f7e64bf7e7aad4`, distinct from complete01 because the selected Natrec source bytes changed. All 66 source/control bindings were independently rehashed. The scope is still eight fresh physical modules, 28 mathematical origins, 62 ordered roots and 20 default outputs. Twelve current controls and eight sources require 20 read-only snapshots; 46 historical controls remain bound in place.

## Exact correction and predecessor evidence

Only physical KernelNatRecursor changes from the initial source manifest. It now selects the reviewed local 31,624-byte source. The original canonical Nat05 source remains an explicit historical origin. All seven other physical source rows are exactly equal to the complete01 manifest; all 28 origin rows, root inventories and resource policy are unchanged.

The initial bundle source audit is correctly compared to the immutable complete01 manifest, not to the corrected physical-source list. The new correction audit separately supplies the nine current inputs, three exact proof-subterm edits, 25 preserved theorem headers and eleven unchanged roots. All 36 initial-review inputs and all nine correction-review inputs are present with their exact identities in the 66-file gate scope.

The new verification function binds the actual complete01 report and canonical manifest, compares all eight actually attempted source identities, and verifies the preserved runner/protocol/manifest against the old report's original snapshots. It reparses the actual Natrec stdout/stderr using the unchanged raw-log auditor, verifies precisely the three free-variable diagnostics, and requires exit1 without a resource event. Six recovery reports and five clean reports are all retained as unaccepted under the failed-module policy. The 51 accepted prefix roots are not promoted to whole-closure acceptance.

Forward application of the three permitted substitutions must recover the current Natrec text exactly; the inverse must recover the actually attempted Nat05 text exactly. The function verifies the independent correction status, all 25 recorded headers, eleven root names, strict options, sole import, report/log identities and exact nine-input coverage. The author map's success flags alone are insufficient. Unrelated mathematical source edits cannot pass this rule.

## Execution and resource enforcement remain unchanged

Fourteen existing functions, including main, the source guard, bundle reconstruction, path resolvers and raw-log auditor, are AST-identical to complete01. The sole new function verifies the correction provenance. Preflight changes add the current local source and explicit historical/review bindings. After removing exactly the three new report metadata entries and one descriptive postcheck flag, run is AST-identical to the frozen complete01 implementation.

Consequently the child-command loop, permanent source/policy-keyed marker, compile lock, read-only snapshot handling, cleaned fresh-only LEAN_PATH, pinned compiler/five-runtime checks, single absolute deadline, RSS enforcement, exact output inventory, failed-module root policy and final integrity checks are unchanged. Every module still builds freshly with `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`, one CPU/import worker and default heartbeat/recursion/compiler-output options. All compilation and final postchecks must finish within the same cumulative30-second/1-GiB allowance.

The old attempt's successful objects are not inputs. Its marker and evidence remain immutable. The new report explicitly states that complete01 mathematical acceptance is not assumed. The additional correction flag becomes true only when the complete corrected closure passes all existing acceptance conditions.

## Limits of this review

The source-level proof repair was reviewed separately in NATREC-CORRECTION-REVIEW/AUDIT. This control review establishes neither its elaboration nor a passing run. The new module-layout qualification remains: literal original source preservation does not alone certify identical elaborated declarations across changed visibility and persistent registration contexts. Installed pins, whole-fold normalization, actual cache/checker integration and the ordinary stock cqueens16 numeral theorem remain outside this gate's acceptance claim.
