# Fresh source-bundle proof gate

Status: the corrected complete-02 variant is prepared for independent control
review and root execution. Root executed the preserved complete-01 variant.
No gate, preflight, compiler, exporter, native program or counter was executed
by the gate author. Only root may perform the selected new execution.

## Exact selected change

The actual `kernel-compact-reference` complete-01 failed after its 27-module
successful prefix, with 51 accepted reports, 138 outputs and no Natrec output
before the shared deadline. Its report, logs, marker and source/control texts
remain immutable. This candidate changes the physical source layout, retaining
all 28 mathematical source origins. It does not assume a successful result
from the failed attempt or attribute that failure to any one theorem.

`KernelCompactCore` contains the 21 upstream source units in their previous
topological order. The exact source map replaces only each module/import header
with a comment and adds one explicit `end` at each former EOF to close that
unit's retained public section. It imports `Std.Data.HashMap` and
`import all Init.Util` once. The initial source-bundle map keeps six project
origins exact and changes only KernelLowOperation's TypeChecker import to
KernelCompactCore. The current corrected physical closure additionally uses
a local Natrec copy with exactly three reviewed proof-subterm corrections;
its original canonical Nat05 remains one of the 28 bound origins. The other
five project source files, the bundle, and the Low import adapter are unchanged.

The gate independently reconstructs the exact bundle bytes from the retained
origins, verifies every mapped byte interval, inverts every header replacement,
checks every EOF closure, and inverts the one project import edit. The assembly
script is a hash-bound source control and is never imported or run by the gate.

Text correspondence does not establish identical elaborated private names or
module ownership. Import visibility and preceding persistent registrations
also change. The independent source/scope review is mandatory and must bind
all 28 origins, both new physical sources, the assembly map/script/plan,
pinned scope-command semantics, and the actual preceding manifest/report.
Fresh acceptance remains required. No claim of complete cached-engine
compatibility follows from source concatenation or from a successful gate.

## Exact correction after bundled complete-01

The actual first bundled attempt finished in 28.879820896007004 seconds,
within limits, and failed in Natrec with three `decide` free-variable
errors. All eleven Natrec reports were printed: six contain `sorryAx` and
five have only allowed axioms, but all eleven are unaccepted because the
module exited 1. The report retains 51 accepted prefix reports and 18 partial
outputs. Raw report SHA256 is
`d7662ad372b19828e830d1911bc9690fb642e2b6d2fbc3e2f7b753893470c7ba`;
its original source manifest is canonically retained under `failed-complete-01/`
with SHA256
`91e7a2f124a9433bae56d9eec6f6dbbe7fa34de2d0414f3b4dd67901ee8e2ea8`.

The current local `KernelNatRecursor` changes exactly the three affected
`by decide` subterms to first `change (1 : Nat) ≠ 4`, `change (2 : Nat) ≠ 4`
and `change (3 : Nat) ≠ 4`, respectively. Every definition, installed-rule
pin, all 25 public/private theorem headers, eleven prints, fuel condition,
import and option remains exact. The gate reconstructs the current bytes
with the three literal edits and reverses them to the actual attempted
canonical Nat05. The whole corrected closure must compile afresh.

Initial PLAN/script/SOURCE-BUNDLE and SOURCE-REVIEW/AUDIT remain frozen as
the exact bundle-base contract. In particular, their physical-source list
is compared to the immutable complete-01 manifest, not silently treated as
a review of the current corrected Natrec. The separate
NATREC-LENGTH-CORRECTION note/map and NATREC-CORRECTION review/audit bind
nine exact inputs, including the actual failure streams and the new source.
Those direct inputs and all 36 initial bundle-review inputs must be present
in the new gate's bound input set. No failed Natrec report becomes an accepted
premise, and no prior successful object is reused.

## Eight physical compiler inputs

| Order | Fresh module | Exact ordered axiom reports | Default outputs |
|---:|---|---:|---:|
| 1 | `KernelCompactCore` | 0 | 6 |
| 2 | `FiniteFold` | 9 | 2 |
| 3 | `FirstOrderNat` | 9 | 2 |
| 4 | `SaturatingUInt64` | 8 | 2 |
| 5 | `UInt64MaskOps` | 16 | 2 |
| 6 | `KernelLowOperation` | 5 | 2 |
| 7 | `KernelScalarSteps` | 4 | 2 |
| 8 | `KernelNatRecursor` | 11 | 2 |
| **Total** | **8 physical / 28 origin units** | **62** | **20** |

The final module reaches exactly these eight physical inputs through the
checked import graph. Only pinned standard `Init`/`Std` imports are external.
There are no prepared experimental or upstream objects. All eight modules
compile freshly in a new build directory in the displayed order.

The module-format bundle produces `.olean`, `.olean.server`, `.olean.private`,
`.ir.sig`, `.ir`, and `.ilean`. Each legacy project input produces `.olean`
and `.ilean`. The entire final build inventory must equal those 20 paths;
default outputs are neither disabled nor omitted from accounting. The pinned
Lean environment/frontend/compiler-option sources documenting this output
contract are retained as historical controls.

The source guard checks both the eight physical inputs and all 28 origins.
It rejects admissions, unsafe/kernel-bypass mechanisms and unexpected executable
elaborator commands. Exact imports, namespace/print inventories, module format
and options must match. The two existing scoped `linter.unusedSimpArgs false`
commands from original `ExprOps` occur unchanged in the bundle. No new lint
suppression is permitted. Every project source retains the three strict
`autoImplicit`, `warningAsError`, and `Elab.async` settings.

## Immutable provenance and direct bindings

The previous manifest and report are pinned to:

- Manifest SHA256 `7aeb00b27645d1c791d2fed7a7e4ab71cd3bfc51665fc03157a44040e68fc8e6`.
- Failed report SHA256 `e955b88b4b5b9a87b7f37c85253fb7f74b0db660eadd186595249104b78c1252`.

The manifest's source bindings must match the actual report's ordered 28 rows.
The preserved prefix/failure classification must remain 51 accepted reports,
no Natrec reports, empty Natrec stdout/stderr, exit minus nine at the wall-time
limit, and 138 partial outputs. These are source provenance facts, not new
acceptance premises.

Exactly three recorded locations are resolved to canonical immutable copies:
the compact manifest and its `Expr`/`Canon` variants. The new manifest lists
these path resolutions explicitly. Scalar comes from failed recursion02 and
Natrec from failed recursion05 at their already-canonical paths. The actual bundled01 report, manifest, logs and original runner/protocol are
separately bound at their retained immutable locations. No living predecessor
control is used as an assumed immutable reference.

The twelve current snapshot controls are the initial eight (runner, protocol,
source manifest, author plan, assembly script/map, independent bundle source
review/audit) plus the correction note/map and independent correction
review/audit. The gate also binds 46 historical inputs: 23 nonphysical origin
sources, nine compact01 report/control files, eight resource/runtime/output/scope
inputs, and six actual bundled01 report/manifest/log/control files. Five
remaining origins coincide with physical source rows. There are 66 unique
source/control bindings. Both independent review-input sets are verified
against this complete bound set.

The source-cut history remains disclosed: 15 earlier compiler substitutions
and four additional compact substitutions are omitted (19 total); the compact
variant also omits 30 simp registrations and nine inline registrations in
seven source cuts. Consolidation removes no further mathematical declarations or proof bodies;
the separate local Natrec correction changes only the three disclosed proof
subterms. The saved compact map and independent review are retained as
historical controls, without importing their old gate or rerunning it.

## Fixed resource and execution policy

One absolute deadline covers the eight fresh compiler commands and final
integrity/artifact checks: **30 seconds cumulative, one CPU, one compiler
thread, 1 GiB resident memory**, with Lean's `-M1024`. The exact unchanged
`run_comparison.py` resource helper enforces process-group limits and measures
sampled tree RSS plus wait4 peak RSS. No per-module deadline reset, resource
increase, alternate compiler mode or independently timed proof subgate is
available.

Every command is:

```text
lean -j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false \
  -o <fresh-build>/<Module>.olean -i <fresh-build>/<Module>.ilean <Module>.lean
```

Heartbeats, recursion depth and compiler options retain their defaults. The
compiler and five shared runtime libraries match the pinned Lean4.35.0 commit
`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. `LEAN_PATH` contains only the fresh
build directory; import workers are set to one. The resource helper cleans the
environment, and the gate removes `LD_PRELOAD`, `LD_AUDIT`, and
`LD_LIBRARY_PATH`. One existing compile lock serializes mathematical work.

Before any compiler starts, eight physical sources and twelve current controls
are snapshotted read-only (20 snapshots). All historical sources/controls stay
hash-bound in place. An exclusive permanent marker uses the SHA256 of the
ordered physical source hashes and fixed policy. Those sources are required
to reconstruct all 28 mathematical origins exactly through the assembly and
three-subterm correction inverses; a mere control-file or
attempt-label change does not yield a new source key. The marker contains both
physical and origin bindings and is reserved before compilation. Failed
attempts consume the key and cannot be retried unchanged. Earlier markers are
never touched.

## Raw reports, acceptance and failure

The raw stdout/stderr and all observed axiom reports are retained even when a
module fails. Observed, unique and accepted report counts are separate. A
module contributes accepted reports only when it exits zero within limits,
produces its exact ordered print inventory with permitted axioms only, has no
unparsed output or stderr, and produces every required default output.
Permitted axioms remain exactly `propext`, `Quot.sound`, and `Classical.choice`.

Overall success requires all eight modules, all 62 accepted reports, the exact
20-file build inventory, the one shared time/RSS limits, and successful
postchecks of sources, controls, snapshots, marker, logs, compiler and runtime.
A failure preserves its partial report/logs/artifacts and does not accept an
unreached or failed theorem. Silent logs do not demonstrate partial proof
progress.

On success, the report may mark the conditional low/scalar/Natrec contracts,
fuel-uniform composition and the checked source consolidation and exact proof correction as checked in
this fresh physical closure. Actual installed pins, whole structural-fold
normalization, a cache insertion rule for that fold, optimized-kernel
installation, the source count and a stock numeral theorem all remain false.
No native program or counter is part of this gate, and no timing improvement
is claimed before or solely from source preparation.

## Root dispatch

After independent control review, root may run a nonexecuting preflight:

```text
python3 -I next-iteration/kernel-bundled-reference/gate/run_gate.py --attempt complete-02
```

Only root may select the single actual attempt:

```text
python3 -I next-iteration/kernel-bundled-reference/gate/run_gate.py --attempt complete-02 --run
```

The gate author and independent reviewer do not import, preflight or execute
the runner. A later source correction requires explicit new reviewed source
bytes and a new named attempt; the old marker/evidence remain immutable.
