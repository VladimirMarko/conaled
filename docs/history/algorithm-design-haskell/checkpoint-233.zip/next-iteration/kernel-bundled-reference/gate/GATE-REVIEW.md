# Independent control review: bundled kernel gate

**No control-level blocker found for root's selected preflight and one fresh execution.** This is a source-only review of the frozen runner, protocol and manifest. The reviewer did not import the runner, execute its preflight or guards, run the source assembly script, or invoke Lean/compiler/native code. Root authored the bundle; counting_route authored this gate; validity_contracts independently reviewed both source correspondence and gate controls.

## Frozen controls

| Control | Bytes | SHA256 |
|---|---:|---|
| run_gate.py | 62,353 | `489c2268b01a640774e9fc45f692439622b9db269b7141a46b6c09d459cded43` |
| PROTOCOL.md | 9,599 | `c034dd6c48fb5df97464eb5d981f1bcea08a980632bd1fe40170caaa57a029d0` |
| source-manifest.json | 60,098 | `91e7a2f124a9433bae56d9eec6f6dbbe7fa34de2d0414f3b4dd67901ee8e2ea8` |

The independently recomputed source/policy fingerprint is `adfbe5cee0c7c79656a6ca6f48b81bf268690742b813f029e535ba73465b5c40`. All 55 distinct source/control bindings were read and hashed as data: eight physical sources, eight current controls including the manifest itself, and 39 historical controls. Exactly 16 current source/control snapshots are required. Historical origins are hash-bound in place.

## Whole-source coverage and historical roles

The runner requires eight fresh physical modules, 28 exact mathematical origins, 62 exact ordered axiom reports and 20 default outputs. All eight physical modules are reachable from the final Natrec module, in topological order. Nonselected imports are restricted to the pinned standard library. No upstream or experimental object is an input.

I checked the new manifest against the frozen source audit and actual compact01 manifest/report. All 28 origin hashes, lengths, imports and names agree. The 36 direct independent source-review inputs are completely covered by the 55 gate bindings. Exactly three old locations resolve to immutable canonical copies: the compact manifest and compact Expr/Canon sources. These substitutions preserve the recorded bytes. Scalar02 and Natrec05 already use their immutable canonical sources.

The failed compact01 report is pinned by exact hash and role. Preflight requires its actual 51-root prefix, failed Natrec exit minus nine with wall-time limit, zero terminal reports and empty logs, 138 partial artifacts, source manifest and unchanged integrity bindings. It supplies provenance only; no successful Natrec premise or missing generic report is substituted. The eight historical compact control roles are separately checked against the old report's recorded read-only snapshots. The old runner, assembly scripts and old gates are never imported or executed.

The new `verify_bundle` reconstructs every header substitution, origin interval and EOF closure directly from the retained sources, verifies all 21 inverse reconstructions, compares the complete bundle, and reverses the single Low import edit. It does not rely only on a JSON success flag. The source/scope audit must have the exact successful source-only status, all 36 current input identities, all 28 origin rows and 21 scope records. The previous 19 omitted csimp registrations and the compact cut's 30 simp/nine inline omissions remain explicit.

These checks establish source correspondence. They do not establish identical elaborated private names, public declaration bodies under changed resolution, or full cached-checker compatibility. The source review's qualification about the new module/global-attribute environment remains applicable to this gate and to any result report.

## Freshness, resource and acceptance enforcement

The execution body retains the preceding reviewed enforcement. An AST comparison found ten support functions unchanged, including hash/binding verification, source fingerprinting, import parsing, log auditing and the two historical-path resolvers. After removing only reviewed report/marker metadata and the two new descriptive acceptance flags, the entire `run` function is AST-identical to the frozen compact01 runner. Its child-command loop, deadline, exception handling and final acceptance test are unchanged.

Before compilation, the runner writes the eight source snapshots and eight current control snapshots with exclusive creation, checks their bytes and read-only modes, reserves an exclusive permanent marker keyed by the physical source hashes plus fixed policy, and includes both physical and origin bindings in that marker. An existing attempt or marker rejects an unchanged retry. The shared compile lock is retained.

Every compiler uses `-j1 -M1024 -DautoImplicit=false -DwarningAsError=true -DElab.async=false`, one CPU affinity and one import worker. LEAN_PATH contains only the fresh build directory. The pinned resource helper enforces the one absolute 30-second deadline and 1-GiB RSS limit across all eight commands; the final postchecks and acceptance calculation remain inside the recorded elapsed interval. Default heartbeat, recursion and compiler-output settings remain unchanged. The compiler and exactly five runtime libraries must match the pinned Lean4.35 release/commit. Loader-injection environment variables are removed.

KernelCompactCore must produce all six module-format outputs; each of the seven project modules must produce its default two outputs. The final build must contain exactly those 20 files. A module contributes accepted reports only after exit zero, within-limit status, the exact ordered raw root list, permitted axioms, empty stderr, no unparsed stdout and all required outputs. Any failed-module reports remain merely observed. Allowed axioms remain exactly propext, Quot.sound and Classical.choice.

Postchecks rehash physical sources, every current/historical control, snapshots, marker, logs, compiler and runtime. All mathematical origins are covered by those sources or controls. Overall success also requires all eight modules, all 62 accepted reports, exact artifact inventory, elapsed time at most 30 seconds and peak RSS at most 1,048,576 KiB. Integrity or affinity-restoration failures reject the attempt.

## Result boundary

No timing benefit or new mathematical acceptance follows from this source-only review. A successful run would establish the conditional low/scalar/Natrec contracts in the fresh bundled layout. Installed recursor/source guards, whole-fold normalization, actual cache integration, an optimized-checker installation and the ordinary stock numeral theorem for cqueens16 remain false in the report. The native evaluator/count is not part of this gate. The prior failed compact result and all earlier permanent markers remain untouched.
