# One fresh source bundle of the actual compact kernel

Status: source preparation only; no compiler or gate has run for this candidate.

The compact closure's first complete attempt reached the same 51 accepted
prefix reports, then ran out of its shared 30-second budget in Natrec. Its
empty Natrec logs do not identify a costly theorem or prove partial success.
This candidate changes the physical compilation strategy to reduce repeated
compiler startup, imported-environment loading and module-output work. It is
not an unchanged retry and changes no execution allowance.

## Exact mathematical coverage

All 21 upstream units from the actual compact attempt are assembled in their
existing topological order into `KernelCompactCore.lean`. Every mathematical
declaration and proof body is retained byte for byte. The only transformations
are removal of the individual module/import headers and explicit closure of
the public section which each original file left open at EOF. External
`Std.Data.HashMap` and `import all Init.Util` are imported once at the top.

The seven project units remain separate. The only project edit replaces
KernelLowOperation's TypeChecker import with the source bundle. Its other
import and complete mathematical text remain exact. Scalar and Natrec use
the immutable canonical sources from failed recursion02 and recursion05;
neither failure supplies a successful proof premise.

Thus the candidate has eight physical compiler units, still covering all
28 selected mathematical source origins and all 62 ordered public axiom
reports. The bundle's default module outputs number six and the seven
legacy project files each produce their default two outputs: 20 in total.
Every physical unit is rebuilt from source in the same single 30-second,
one-CPU, 1-GiB gate. No previously compiled upstream or experimental module
is imported, and no heartbeat, recursion or output option is changed.

`prepare_source_bundle.py` performs byte assembly, JSON and hash operations
only. `SOURCE-BUNDLE.json` records the original identities, each small header
edit, exact byte ranges in the bundle, and successful inverse reconstruction
of every original unit. It neither imports a runner nor executes Lean.

## Visibility and elaboration qualifications

This is a new Lean module layout. Private generated declaration names and
module ownership change. The internal units can see preceding definitions
without an import visibility boundary. `import all Init.Util` is available
throughout the bundle. Preceding persistent registrations are present in
topological order, including those of sibling units. These facts may affect
elaboration or native compiler choices, and fresh acceptance is required.

Every original `public section` and `@[expose] public section` is kept and
closed before the next unit, so local section variables, namespace opens and
exposure defaults are not deliberately carried across former EOFs. This
uses the pinned Lean4.35 command semantics: public sections push an ordinary
scope; `end` closes it. The independent review must inspect the exact original
section boundaries and detect any accidental context leakage.

The intended public logical declarations, types, definitions and proof terms
are those in the existing compact sources; the retained source text is an
exact recoverable witness of this claim, not a promise of identical private
names or compiled bytes. There is no full cached-checker compatibility claim,
no native speedup claim, and no installed-environment or numeral theorem.

## Acceptance boundary

The gate must bind the actual failed compact01 report, exact previous source
manifest, all 28 original source units, the assembly script and inverse map,
and an independent review. It must check each origin, each reversible edit,
all mathematical coverage and the entire eight-unit import closure before
one source/policy-keyed execution. Existing failed markers remain permanent.

A passing result would establish exactly the same 62 conditional primitive
and recursor reports in this new fresh closure. The whole structural fold,
installed pins, actual optimized-checker integration and concrete stock
`cqueens 16 = 14772512` remain separate obligations.
