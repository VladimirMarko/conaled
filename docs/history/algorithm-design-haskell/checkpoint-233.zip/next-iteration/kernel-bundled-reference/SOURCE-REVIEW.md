# Independent review: bundled actual kernel source

## Disposition and exact scope

**No source-level blocker found for a fresh bounded gate. This review does not compile or accept the bundle.** Root authored the assembly and plan; `/root/validity_contracts` independently read the actual sources, command implementation and assembly recipe, and checked the byte transformations as data. No Lean, candidate assembly script, gate, preflight, compiler or native evaluator was executed by this reviewer.

The companion `SOURCE-AUDIT.json` binds exactly 36 direct inputs: all 28 compact source origins, the two new physical sources, the plan, assembly script, origin map, pinned command source, actual compact manifest and failed compact01 report. The source bundle is 342,555 bytes, SHA256 `ef7905f13dd7236f38c19597f22e79f0cdc7e06d4015881de8a47f3658af8618`; the Low import adapter is 11,343 bytes, SHA256 `a96e6a4fc835db9deba22ce9be27f66546195f5d56f641b369ea255061083e27`.

The previous compact report (`kernel-compact-reference/gate/attempts/complete-01/report.json`, SHA256 `e955b88b4b5b9a87b7f37c85253fb7f74b0db660eadd186595249104b78c1252`) supplies source provenance and a recorded failed attempt. It accepted 51 prefix roots before the deadline and supplies no accepted Natrec theorem or whole-closure premise. Empty Natrec logs do not identify an expensive declaration.

## Exact source and inverse checks

All 21 upstream origin identities match the actual compact manifest, in its existing topological order. Independent reconstruction matches every byte of the proposed bundle. Each origin has only its initial `module` directive and import lines replaced by identifiable comments: 60 such header substitutions in total. Every body range, edit offset, prefix and suffix agrees with `SOURCE-BUNDLE.json`; reversing the edits recovers all 21 original files exactly. The added suffix is one bare `end` for that origin's open public section. No declaration, type annotation, definition body, proof body or attribute within an origin is removed or edited.

The seven project-origin records match the compact manifest exactly. KernelLowOperation changes its single TypeChecker import to KernelCompactCore; reversing that edit recovers the accepted logical-reference Low source byte for byte. Its other import, all five statements/proofs and axiom prints remain exact. The other six project units are unchanged, including Scalar and Natrec05 at their immutable failed-attempt canonical paths. The complete ordered 62 printed names are preserved.

The assembly script was inspected without importing or executing it. Its imports are Python standard-library path/hash/JSON/text facilities. Its operations assemble source and provenance data; it does not invoke Lean, a gate or a counter. Independent reconstruction, rather than the script's own success flags, supports the checks above.

## EOF scopes and retained public declarations

The comment/string-masked census tracks explicit namespaces, sections and mutual blocks. Every origin finishes with exactly one anonymous public section open; all explicit namespaces and inner sections/mutual blocks are closed. All 21 added `end` commands therefore close the intended section. The original `public section` or `@[expose] public section` command remains in place, and no outer namespace is introduced around the units.

The retained official Lean4.35 source `primary-source/Lean__Elab__BuiltinCommand.lean` is byte-identical to the pinned toolchain source, SHA256 `a22a93f95b44299068f8c754acae760bd1dc538db82f4504bf3c780a753e7c3f`. Its `addScope` at lines 44–57 and `elabSection` at 106–117 push the public/exposure scope; `elabEnd` at 241–270 makes a bare `end` pop one anonymous scope. This is the actual command implementation supporting the reset, rather than an assumption that EOF and concatenation are interchangeable.

The two external imports, `public import Std.Data.HashMap` and `import all Init.Util`, are already exactly the first origin's external imports. Hoisting them does not introduce a new external import before that first origin. The census finds no standalone attribute command or local/scoped syntax/notation command requiring another explicit reset. The only option commands are the two original declaration-local `set_option linter.unusedSimpArgs false in` lines in ExprOps.

There are 501 lexically named declarations and 24 explicitly private declarations; all 24 private declarations occur in PropWhen. The lexical namespace/name census finds no cross-origin name collision. This census does not enumerate generated declarations or prove name-resolution equality.

## Material elaboration-context change

**Byte-identical declaration source does not establish identical elaborated declarations, types, proof terms, generated names, opacity or machine code.** This is a new module layout. Private names and module ownership change. Later origins can see preceding declarations without the old import boundary. Persistent instances and attributes from earlier sibling origins remain in the sequential environment; closing a section does not delete those global registrations. Name resolution, instance search, simplification and compilation may consequently behave differently.

The scope closures protect local section context and exposure defaults; they do not prove a complete imported-environment equivalence theorem. The intended public logical definitions remain represented by exact original source, and all required project statements are retained, but their elaboration and ordinary kernel acceptance must be checked afresh. No compatibility claim for the full cached checker or all private upstream APIs follows from this review.

The inherited logical/compact cuts remain disclosed: 19 omitted `csimp` registrations in total, of which the last compact cut omitted four, together with 30 `simp` and nine `inline` registrations. Bundling removes no additional registration from an origin. The fresh proof gate must run in the resulting simplifier and instance environment.

## Gate contract and remaining obligations

The physical order is KernelCompactCore, FiniteFold, FirstOrderNat, SaturatingUInt64, UInt64MaskOps, KernelLowOperation, KernelScalarSteps and KernelNatRecursor: eight fresh compiler units, 28 mathematical source origins and 62 ordered roots. KernelCompactCore retains module format and its six default outputs; the seven legacy-format project units retain their two default outputs each, for 20 outputs. The lower file count comes from the declared module-layout change, not an output suppression option.

All eight units must be freshly built in one cumulative 30-second gate, on one CPU with `-j1 -M1024`, the existing 1-GiB RSS limit, default heartbeat/recursion settings, strict source options and only the three allowed axioms. No previous upstream/experimental objects are reusable inputs. The gate must bind this review, the exact origin map and actual failed compact report, preserve prior markers, snapshot current inputs, and compare source/runtime/log/artifact bindings. No elapsed-time or memory benefit has been measured for this layout.

A successful 62-root result would establish only the stated conditional actual-reducer contracts in this fresh layout. It would not discharge installed Natrec/Bool/source pins, prove whole-fold normalization or environment validity, install an optimized checker, or produce the stock numeral theorem for `cqueens 16`. Those remain separate mathematical and integration obligations.
