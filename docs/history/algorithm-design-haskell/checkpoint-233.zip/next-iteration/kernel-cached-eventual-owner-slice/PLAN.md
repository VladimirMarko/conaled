# A smaller actual-cached owner for the eventual-run pilot

This is a new, source-only owner selection. It removes the pure evaluator and unused project proofs from the ordinary Core/Cached bundle while preserving the actual cached evaluator. It does not replace an evaluator, seed a memo, change a theorem statement, introduce a successful-run assumption, or increase a resource limit. Fresh complete compilation is still required.

## Selected source boundary

The immediate source closure consists of three owners:

| Owner | Source bytes | Ordered reports | Role |
| --- | ---: | ---: | --- |
| `KernelCompactCore` | 208,582 | 2 | Existing representations and helpers, plus the shared Core runtime declarations |
| `KernelCachedForward` | 202,799 | 6 | The complete current cached implementation and the six actual memo equations |
| Unchanged `KernelCachedMemoRelation` | 11,887 | 16 | Relation-parametric validity of the two normal-form maps |

These three owners total 423,268 bytes, 24 distinct reports and six ordinary `.olean`/`.ilean` outputs. Their original three-owner context totaled 523,203 bytes and 43 reports. The net text reduction is 99,935 bytes. These are source counts, not a timing prediction.

Root's intended next complete selection adds Nat's separately authored eventual-empty and atom leaves, provisionally eight and nine reports. That would give five owners, 41 reports and ten ordinary outputs. The two new leaves have their own exact source inventory and independent review; their definitions and results are not part of this owner-slice claim. No gate is selected or run by this package.

## Exact Core omissions

The baseline is the reviewed 299,338-byte explicit-modifier Core. Its `DECLARATION-SCOPE.json` already identifies 44 pure `ConLeche.Kernel.Core` definitions and eight pure `ConLeche.Kernel.TypeChecker` wrappers. This candidate omits precisely those 52 definitions. It removes the complete TypeChecker origin because all eight of its declarations are the omitted pure wrappers.

The Core map contains one ordinary explanatory comment insertion, 44 definition-and-attached-documentation omissions, and one complete TypeChecker-origin omission: 46 edits with 47 unchanged complements. The map includes every removed byte and both source identities, so the complete predecessor reconstructs exactly. All unaffected declarations, proofs, attributes, imports and source options remain literal. The two existing report commands remain literal and in order.

All 16 shared declarations from the earlier dependency census remain, along with the full `ToString CheckError` instance and the six-field `CoreFns` structure. In particular the actual error type, `CheckM`, projection errors, `liftFueled`, `DeltaStep`, `LazyRes`, the four `Expr` observers and all three loop budgets plus `checkFuel` retain their current source. The inherited explicit type binder on `liftFueled` and the previous presentation-only `Repr` cut are preserved as earlier transformations, not asserted equal to the complete upstream header.

Removing these definitions is a genuine source-ownership change. It does not rely on proof erasure or on a compiler modifier suppressing all work. The consumed interface111 run did not show an improvement from the earlier 52 `noncomputable` modifiers; this package does not relabel that run or infer a speedup from it. The new omission's effect is unmeasured.

## Exact Cached proof selection

Every byte of the current 196,259-byte cached implementation prefix, ending before the project `CachedForwardRuns` origin, is copied literally. This includes all existing runtime definitions, intrinsic proof-carrying traversals, fields, helper caches, keys, guards, error paths, all six `CoreFnsI` slots and the entire actual `coreKnotI`. It includes the complete Lift family and `Expr.resBool_eq` needed by later driver work.

The project suffix retains exactly these previously existing proof bodies and reports:

1. `memoEI_hit`
2. `memoEI_miss`
3. `whnf_hit`
4. `whnf_miss`
5. `whnfCore_hit`
6. `whnfCore_miss`

The unchanged generic memo leaf references only the last four; their proofs use the first two. The real miss-body equation, its actual returned state, the detach/insert sequence and positive outer fuel are unchanged.

The unused `Succeeds` definition, its four elementary proofs, `whnf_zero`, seven helper-success proofs, and the complete `CachedForwardLicensed` project origin are omitted. The latter contains one proposition and seven proofs. Thus 21 project declarations and 19 project reports are removed, leaving six reports. The Cached map has 27 edits and 28 unchanged complements. Three duplicate strict `set_option` commands disappear with the whole unused Licensed origin; the same strict settings already precede the retained source and remain effective. No option is weakened or introduced.

## Dependency and native context

`CONSUMER-CENSUS.json` scans all three selected source texts after masking nested comments and ordinary strings. The only matching bare omitted names are eight retained record-field labels named `whnf` or `whnfCore`; they are not references to the omitted pure functions. The actual `CoreFnsI.ioView` definition and its typed cached-knot call remain present. No new proof can be inferred merely from this lexical census: it is a review aid, and the complete fresh gate must still resolve every reference and kernel-check every declaration.

The complete native `CoreC` namespace is an exact byte match inside the selected Cached owner. Twenty-one native or reviewed-native-companion interval pairs cover the shared declarations, the full cached core, the Lift family and `resBool_eq`; one further interval records the generic forwarding consumers. Ten complete pinned native files and three complete pinned SDK files are retained. The broader ordinary-field, module-header, proof, presentation and driver transformations are inherited from their distinct reviewed predecessors; native representation or generated helper identity is not claimed unchanged.

The current `KernelCachedRecordDriverCore` source has no lexical reference to the 52 omitted pure functions. Its existing runtime supplement remains the route that restores the cached `constsResolve` guard family, `recordCConst` and the original `checkPending` body. That supplement is context here, not an additional selected or newly accepted owner.

The old `KernelCachedRecordDriverForward` proof leaf does use pure sort/loop backing. Native `BasisGen` executes `ConLeche.annotateCore`, and the full original `CheckerBase` also exposes pure operations. Those contexts cannot simply import this reduced owner and inherit their previous claims. A later proof architecture must either restore the exact missing pure definitions in its complete fresh closure or supply independently reviewed actual-cached proofs. This package makes no full native BasisGen, Installed, Phase-A, pure-model or current DriverForward build claim.

The earlier evaluator-scope omissions remain exactly as disclosed: Basis/Canon construction origins and installation interfaces in Core, plus the cached parsed-driver guard/record APIs. No additional current cached runtime API is removed here. The actual full native sources and separate driver restoration package remain available and separately bound.

## Preservation and execution boundary

`SOURCE-CORRESPONDENCE.json` supplies exact forward and inverse edits and all complements. `DECLARATION-SCOPE.json` binds the previous 52-definition census, the 18 shared/interface spans and the six unchanged proof spans. `SOURCE-CENSUS.json` records actual imports, origin ownership and ordered report names. `HISTORICAL-CONTEXT.json` binds the original author/reviewer arrays without rebasing them and retains the consumed interface111 controls and its 29 separate historical review scopes.

Six external historical context identities are mapped only to their exact retained source copies in `EXTERNAL-CONTEXT-RECOVERY.json`. Original review arrays remain unchanged. This is not arbitrary parent-path resolution, and no compiled object is copied or selected.

Only static reading, byte comparison, source authoring and hashing occurred. There was no Lean/compiler, gate/preflight, evaluator, exporter, profiler, native mathematical program, retained mathematical generator or dedicated saved-result reader. The parent remains the sole executor. Any future gate retains the fixed cumulative 30-second, one-CPU/thread, 1-GiB, default-heartbeat/strict-options, three-axiom and permanent no-retry source-key policy.

This package proves no functionality of an eventual-run relation, no full query, no original `GroupChecked` result, and no stock numeral theorem. Its purpose is to make the next independently stated actual-cached proof closure smaller without changing the evaluator it discusses.
