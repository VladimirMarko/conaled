#!/usr/bin/env python3
"""Independent static source checks only; never imports or runs a gate/Lean."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
UPSTREAM = ROOT.parent / 'upstream-source/con-leche-67f04630d88718e81aa4d07ab64501f68f105398'
SDK = ROOT.parent / 'toolchains/lean-4.35.0-linux/src/lean'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((HERE / name).read_text())

def binding(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}

recovery = read('EXTERNAL-CONTEXT-RECOVERY.json')
routes = {(r['original_context']['path'], r['original_context']['bytes'], r['original_context']['sha256']): r['retained_copy'] for r in recovery['mappings']}
assert len(routes) == 6 and not recovery['arbitrary_parent_path_resolution_permitted']

def checked(row):
    name = row['path']
    if name.startswith('../'):
        alias = routes[(name, row['bytes'], row['sha256'])]
        data = checked(alias)
        assert (ROOT / name).read_bytes() == data
    else:
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        data = (ROOT / name).read_bytes()
    assert (len(data), sha(data)) == (row['bytes'], row['sha256']), name
    return data

inv = read('SOURCE-INVENTORY.json')
assert len(inv['inputs']) == inv['input_count'] == 514
assert len({r['path'] for r in inv['inputs']}) == 514
for row in inv['inputs']:
    checked(row)

corr = read('SOURCE-CORRESPONDENCE.json')
sources = {}
transform_results = []
for transform, n_edits, n_complements in zip(corr['source_transformations'], [46, 27], [47, 28]):
    old, new = checked(transform['baseline']), checked(transform['candidate'])
    sources[transform['module']] = (old, new)
    edits = transform['edits']
    complements = transform['unchanged_complements']
    assert len(edits) == transform['edit_count'] == n_edits
    assert len(complements) == transform['unchanged_complement_count'] == n_complements
    old_pos = new_pos = 0
    forward = bytearray()
    inverse = bytearray()
    for index in range(len(complements)):
        comp = complements[index]
        a, b = comp['base_start_byte'], comp['base_end_byte_exclusive']
        c, d = comp['candidate_start_byte'], comp['candidate_end_byte_exclusive']
        assert a == old_pos and c == new_pos
        assert old[a:b] == new[c:d]
        assert (b-a, d-c, sha(old[a:b])) == (comp['bytes'], comp['bytes'], comp['sha256'])
        forward.extend(old[a:b]); inverse.extend(new[c:d])
        old_pos, new_pos = b, d
        if index == len(edits):
            break
        edit = edits[index]
        a, b = edit['base_start_byte'], edit['base_end_byte_exclusive']
        c, d = edit['candidate_start_byte'], edit['candidate_end_byte_exclusive']
        assert a == old_pos and c == new_pos
        assert old[a:b] == edit['old_text'].encode()
        assert new[c:d] == edit['new_text'].encode()
        assert (b-a, sha(old[a:b])) == (edit['old_bytes'], edit['old_sha256'])
        assert (d-c, sha(new[c:d])) == (edit['new_bytes'], edit['new_sha256'])
        # Every inserted replacement is an ordinary explanatory comment, or empty.
        replacement = new[c:d].strip()
        assert not replacement or (replacement.startswith(b'/-') and replacement.endswith(b'-/'))
        forward.extend(new[c:d]); inverse.extend(old[a:b])
        old_pos, new_pos = b, d
    assert old_pos == len(old) and new_pos == len(new)
    assert bytes(forward) == new and bytes(inverse) == old
    transform_results.append({'module': transform['module'], 'edits': n_edits, 'complements': n_complements, 'forward_and_inverse': True})

def pair(row, module):
    old, new = sources[module]
    left = old[row['base_start_byte']:row['base_end_byte_exclusive']]
    right = new[row['candidate_start_byte']:row['candidate_end_byte_exclusive']]
    assert left == right
    assert (len(left), sha(left)) == (row['bytes'], row['sha256'])

for row in corr['shared_runtime_and_CoreFns_pairs']:
    pair(row, 'KernelCompactCore')
for row in corr['retained_project_proof_pairs']:
    pair(row, 'KernelCachedForward')
pair(corr['complete_cached_computational_prefix_pair'], 'KernelCachedForward')
assert corr['complete_cached_computational_prefix_pair']['bytes'] == 196259

scope = read('DECLARATION-SCOPE.json')
prior = json.loads(checked(scope['prior_52_modifier_scope']))
assert [r['source_scope_row'] for r in scope['omitted_pure_declarations']] == prior['definitions']
assert len(prior['definitions']) == 52
old_core = sources['KernelCompactCore'][0]
core_edits = corr['source_transformations'][0]['edits']
def trivia_only(data):
    i = 0
    while i < len(data):
        if data[i:i+1].isspace():
            i += 1
        elif data[i:i+2] == b'--':
            stop = data.find(b'\n', i)
            i = len(data) if stop < 0 else stop
        elif data[i:i+2] == b'/-':
            i += 2; depth = 1
            while depth:
                assert i < len(data)
                if data[i:i+2] == b'/-': depth += 1; i += 2
                elif data[i:i+2] == b'-/': depth -= 1; i += 2
                else: i += 1
        else:
            return False
    return True

for row in scope['omitted_pure_declarations']:
    old_row = row['source_scope_row']
    start, end = row['omission_start_byte'], row['omission_end_byte_exclusive']
    assert any(e['base_start_byte'] == start and e['base_end_byte_exclusive'] == end and row['name'] in e['declarations'] for e in core_edits)
    assert start <= old_row['candidate_header_after_modifier_start_byte'] < end
    assert end >= old_row['candidate_header_end_byte_exclusive']
    tail = old_core[end:old_row['candidate_body_end_byte_exclusive']]
    # The earlier modifier census included the following declaration's docs.
    # Check executable/token content, rather than demanding those docs be cut twice.
    assert trivia_only(tail), row['name']

primary = read('PRIMARY-SOURCE-INTERVALS.json')
assert len(primary['complete_native_copies']) == 10
for row in primary['complete_native_copies']:
    assert checked(row['retained_complete_source']) == (UPSTREAM / row['upstream_path']).read_bytes()
for path in sorted((HERE / 'sdk').rglob('*.lean')):
    assert path.read_bytes() == (SDK / path.relative_to(HERE / 'sdk')).read_bytes()
assert len(list((HERE / 'sdk').rglob('*.lean'))) == 3
native_pairs = 0
assert len(primary['intervals']) == primary['source_interval_count'] == 22
for row in primary['intervals']:
    whole = checked(row['source'])
    data = whole[row['start_byte']:row['end_byte_exclusive']]
    assert (len(data), sha(data)) == (row['bytes'], row['sha256'])
    assert data == row['text'].encode()
    assert whole[:row['start_byte']].count(b'\n') + 1 == row['start_line']
    assert whole[:max(row['start_byte'], row['end_byte_exclusive']-1)].count(b'\n') + 1 == row['end_line_inclusive']
    if 'literal_pair' in row:
        other = row['literal_pair']
        full_other = checked(other['source'])
        data_other = full_other[other['start_byte']:other['end_byte_exclusive']]
        assert data == data_other
        assert (len(data_other), sha(data_other)) == (other['bytes'], other['sha256'])
        native_pairs += 1
assert native_pairs == primary['literal_native_or_reviewed_native_companion_pair_count'] == 21

def mask(data):
    out = bytearray(data)
    i = 0
    def blank(a, b):
        for j in range(a, b):
            if out[j] not in (10, 13):
                out[j] = 32
    while i < len(data):
        if data[i:i+2] == b'--':
            end = data.find(b'\n', i)
            end = len(data) if end < 0 else end
            blank(i, end); i = end
        elif data[i:i+2] == b'/-':
            start = i; i += 2; depth = 1
            while depth:
                assert i < len(data), 'unclosed comment'
                if data[i:i+2] == b'/-': depth += 1; i += 2
                elif data[i:i+2] == b'-/': depth -= 1; i += 2
                else: i += 1
            blank(start, i)
        elif data[i:i+1] == b'"':
            start = i; i += 1
            while i < len(data):
                if data[i:i+1] == b'\\': i += 2
                elif data[i:i+1] == b'"': i += 1; break
                else: i += 1
            blank(start, i)
        else:
            i += 1
    return bytes(out)

decl_pattern = re.compile(rb'(?m)^[ \t]*((?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|unsafe|partial)\s+)*(def|theorem|inductive|structure|abbrev|opaque|axiom)\s+([A-Za-z_][A-Za-z0-9_\x27.?]*))')
def declarations(data):
    return [{'kind': m[2].decode(), 'name': m[3].decode(), 'line': data[:m.start(1)].count(b'\n')+1, 'byte': m.start(1)} for m in decl_pattern.finditer(mask(data))]

declaration_counts = {}
census_corrections = []
for module, field, before, after in [('KernelCompactCore', 'current_Core_declaration_census', 392, 340), ('KernelCachedForward', 'current_Cached_declaration_census', 267, 246)]:
    old, new = sources[module]
    old_decls, new_decls = declarations(old), declarations(new)
    assert len(old_decls) == before and len(new_decls) == after, (module, len(old_decls), len(new_decls))
    # The frozen author's name regex omitted the three `_root_` spellings.
    # Preserve that metadata and record a separate, explicit review correction.
    if module == 'KernelCompactCore':
        additions = [r for r in new_decls if r['name'].startswith('_root_.')]
        assert [r['name'] for r in additions] == ['_root_.ConLeche.Name.hashData', '_root_.ConLeche.Level.hashData', '_root_.ConLeche.Expr.data']
        assert [r for r in new_decls if not r['name'].startswith('_root_.')] == scope[field]
        old_additions = [r for r in old_decls if r['name'].startswith('_root_.')]
        assert [r['name'] for r in old_additions] == [r['name'] for r in additions]
        census_corrections.append({'module': module, 'frozen_author_counts': [389, 337], 'corrected_counts': [392, 340], 'previously_unlisted_retained_declarations': additions, 'original_metadata_modified': False})
    else:
        assert new_decls == scope[field], module
    edits = next(t['edits'] for t in corr['source_transformations'] if t['module'] == module)
    retained = [r for r in old_decls if not any(e['base_start_byte'] <= r['byte'] < e['base_end_byte_exclusive'] for e in edits)]
    assert [(r['kind'], r['name']) for r in retained] == [(r['kind'], r['name']) for r in new_decls]
    declaration_counts[module] = [before, after]

consumer = read('CONSUMER-CENSUS.json')
def omitted_hits(data):
    masked = mask(data)
    result = []
    for row in scope['omitted_pure_declarations']:
        for name in dict.fromkeys([row['name'], row['source_spelling']]):
            pattern = rb"(?<![A-Za-z0-9_'.])" + re.escape(name.encode()) + rb"(?![A-Za-z0-9_'.])"
            for match in re.finditer(pattern, masked):
                result.append((row['name'], name, match.start()))
    return sorted(result)

for row in consumer['current_selected_source_checks']:
    found = omitted_hits(checked(row['source']))
    expected = sorted((x['omitted_name'], x['matched_spelling'], x['start_byte']) for x in row['matching_tokens'])
    assert found == expected, (row['source']['path'], found, expected)
    for hit in row['matching_tokens']:
        assert hit['classification'] == 'retained_record_field_label_not_the_omitted_function'
        assert re.search(r'\b' + re.escape(hit['matched_spelling']) + r'\s*:', hit['text'])

pilots = []
for name in ['KernelCachedEventualEmpty', 'KernelCachedEventualAtoms']:
    path = ROOT / f'next-iteration/kernel-cached-eventual-empty/source/{name}.lean'
    row = binding(path); pilots.append(row)
    assert omitted_hits(checked(row)) == [], name

census = read('SOURCE-CENSUS.json')
for row in census['physical_modules']:
    data = checked(row['source'])
    imports = re.findall(rb'(?m)^import\s+(\S+)\s*$', mask(data))
    reports = re.findall(rb'(?m)^#print axioms\s+(\S+)\s*$', mask(data))
    assert [x.decode() for x in imports] == row['imports']
    if row['module'] == 'KernelCompactCore':
        resolved = [x.decode() for x in reports]
    else:
        namespace = 'ADWH.Experiments.Chapter15.' + row['module']
        assert ('namespace ' + namespace).encode() in mask(data)
        resolved = [namespace + '.' + x.decode() for x in reports]
    assert resolved == row['ordered_report_roots']
    assert len(reports) == row['ordered_report_count']
assert census['source_bytes'] == 423268 and census['ordered_report_count'] == 24

historical = read('HISTORICAL-CONTEXT.json')
array_refs = []
def walk(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            checked(value)
        if 'canonical_json_sha256' in value:
            source = json.loads(checked(value['source']))
            selected = source[value['json_field']]
            raw = json.dumps(selected, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
            assert (len(selected), len(raw), sha(raw)) == (value['item_count'], value['canonical_json_bytes'], value['canonical_json_sha256'])
            array_refs.append(value['item_count'])
        for child in value.values(): walk(child)
    elif isinstance(value, list):
        for child in value: walk(child)
walk(historical)
assert array_refs == [134, 140, 264, 30, 405, 409, 5, 3, 22]

inputs = {r['path']: r for r in inv['inputs']}
for row in [binding(HERE / 'SOURCE-INVENTORY.json'), *pilots]:
    assert row['path'] not in inputs
    inputs[row['path']] = row
assert len(inputs) == 517

summary = {'status': 'passed_static_source_checks_only', 'author_inputs_verified': 514, 'review_direct_inputs': 517, 'transformations': transform_results, 'literal_cached_runtime_prefix_bytes': 196259, 'shared_Core_spans': 18, 'literal_Cached_project_proofs': 6, 'omitted_pure_definitions_exactly_prior_scope': 52, 'declaration_counts': declaration_counts, 'explicit_source_census_correction': census_corrections, 'complete_native_copies': 10, 'complete_SDK_copies': 3, 'primary_intervals': 22, 'literal_native_or_companion_pairs': 21, 'selected_source_consumer_censuses': 3, 'additional_pilot_sources_no_omitted_function_reference': 2, 'exact_historical_array_sizes': array_refs, 'portable_external_identity_routes': 6, 'compiler_gate_preflight_or_mathematical_execution': False}
(HERE / 'REVIEW-STATIC-RESULT.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
(HERE / 'REVIEW-DIRECT-INPUTS.json').write_text(json.dumps(sorted(inputs.values(), key=lambda r:r['path']), indent=2, sort_keys=True)+'\n')
print(json.dumps(summary, indent=2))
