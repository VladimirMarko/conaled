# Independent review of the eventual-run owner selection

Reviewer: `/root`. Result: **passed for this source selection, with the explicit declaration-census correction below**. The new sources have not been compiled. Neither a timing improvement nor completion of the query or numeral theorem follows from this review.

## Scope and identities

I checked all 514 exact author inputs, the author inventory itself, and the two separately frozen eventual-run pilot sources. This gives 517 direct inputs. The latter two inputs were inspected here only for imports and references to removed functions; their mathematical source review remains a separate scope.

The two selected sources are:

| Owner | Bytes | SHA-256 |
| --- | ---: | --- |
| `KernelCompactCore` | 208,582 | `6aacedb54c0facfe362112a156c2e3a877b83ccca043d55f8e22f99cd4404447` |
| `KernelCachedForward` | 202,799 | `323da5194486ccf72b8732869415b6d27a9ff2c0dc57406c17c1cd83ef742804` |

The unchanged generic memo source has 11,887 bytes and SHA-256 `acbbdc6f57d34f582bf422e49fca973127575c830a3ae58de2243ac8626ac2b9`. These three owners contain 423,268 bytes, 24 ordered reports and six ordinary outputs. Adding the separately reviewed 8-report and 9-report pilot leaves would give 442,548 bytes, five owners, 41 reports and ten ordinary outputs. These figures describe source selection, not accepted outputs.

## Exact omissions and preserved code

Independent reconstruction checked all 46 Core edits and 47 complementary intervals, and all 27 Cached edits and 28 complementary intervals. Both forward and inverse reconstructions match the complete pinned files. Each inserted replacement is an ordinary explanatory block comment or empty text. There is no new executable definition, theorem statement, proof, option, recursion limit, runtime branch or resource exemption in these transformations.

All 52 omitted pure definitions match the exact prior explicit-modifier declaration scope. The omissions cover each complete definition. The previous census's following-source range sometimes includes the next declaration's documentation; I checked that any trailing material outside an individual omission is exclusively whitespace or comments. It contains no remaining fragment of a removed definition. The complete TypeChecker origin contains the eight specified pure wrappers and is omitted as one disclosed interval.

All 18 shared Core/interface spans are literal: the 16 shared declarations, the error-printing instance and the complete six-field `CoreFns` structure. This includes the real error type, monad, projection errors, `liftFueled`, `DeltaStep`, `LazyRes`, expression observers and fixed fuel definitions. Earlier representation changes and the explicit binder on `liftFueled` are inherited historical transformations; this review does not relabel them as native-source equality.

Every byte of the 196,259-byte current cached implementation prefix is retained. The full cached knot, all six slots, all guards, cache keys, helper operations, state fields, errors and intrinsic proofs remain. In particular the Lift family and `Expr.resBool_eq` remain available; dropping them would break identified later runtime/proof consumers. The six retained project proof bodies are literal, including the actual miss equations, their returned states and detach/insert behavior. The unchanged GenericMemo source uses the four root hit/miss equations, which use the two retained `memoEI` equations.

The 21 removed Cached project declarations are the disclosed unused Runs/Licensed declarations. Their 19 reports disappear; the six retained reports remain in order. The three duplicate strict-option commands vanish with the omitted Licensed origin. Earlier identical strict settings still govern all retained source. No effective strict setting is weakened.

## Independent census correction

The frozen author's Core census lists 389 predecessor and 337 candidate named declarations. My independent lexical scan also recognizes three `_root_`-qualified declarations that its name filter excluded in both files:

- `_root_.ConLeche.Name.hashData`
- `_root_.ConLeche.Level.hashData`
- `_root_.ConLeche.Expr.data`

All three are retained literally. The corrected lexical totals are **392 to 340**, still exactly 52 removed definitions. The Cached totals **267 to 246** agree with the author. Independently removing declarations whose command starts lie inside the exact edit intervals leaves precisely the candidate kind/name sequence for both files. The original author metadata is preserved; `REVIEW-STATIC-RESULT.json` records the separate correction and exact candidate positions. Neither lexical census claims to enumerate Lean-generated declarations.

The review script initially used an overly narrow whitespace-only trailing-source check and a lexer that did not recognize inline attributes. Those reviewer assertions were corrected after inspecting the actual following documentation and declaration syntax. A further report check was qualified with the actual namespace because two sources print local theorem names. These were static review-tool corrections; no source, frozen author file, gate or mathematical execution changed.

## Consumer and primary-source checks

I independently masked nested comments and ordinary strings, checked every omitted qualified/source spelling in the three selected owners, and reproduced the eight recorded matches. They are the retained `whnf`/`whnfCore` record-field labels, not calls to omitted pure functions. The two pilot sources have no such omitted-function reference. This is a lexical aid; a fresh compiler must still resolve the complete import closure.

All 22 primary intervals match their exact bytes and hashes. All 21 literal native or reviewed-native-companion pairs compare equal. Ten complete retained native sources match the pinned upstream checkout; three complete retained SDK sources match the pinned toolchain. The full native cached-Core namespace is among the literal pairs. The previously reviewed native ExprOpsC companion remains a distinct provenance step.

The six external historical identities route only to exact retained copies, and each copy also matches the available original path. The original author/reviewer arrays remain literal and separately bound: 134/140 for the explicit-modifier scope, 264/30 for the terminal-Boolean scope, and 405/409 for GenericMemo. I checked their canonical-array hashes and the three recorded interface111 manifest sections. The consumed interface111 result remains failed; none of its acceptance is transferred to these new sources.

## Remaining boundaries

The runtime DriverCore supplement has no identified reference to these omitted pure functions, but it is not selected or accepted by this review. The old DriverForward proof, full native BasisGen and CheckerBase do have genuine pure dependencies. They cannot inherit compatibility merely by importing these smaller owners. Later work must restore their necessary definitions or prove new actual-cached interfaces, under a newly reviewed complete closure.

Earlier omissions of installation/Basis/Canon interfaces and cached parsed-driver guard/record interfaces remain as previously disclosed. This change does not supply `InstalledEnv.run`, an original `GroupChecked` result, the model bridge, the full numeric-query proof or `cqueens 16 = 14772512`.

Only source reads, JSON/byte/lexical checks and review artifact writes occurred. No Lean/compiler, gate or metadata preflight, mathematical evaluator, exporter, native computation, retained generator or dedicated saved-result reader was run. Root may now review a complete pilot control selection, preserving the cumulative 30-second, one-CPU/thread, 1-GiB, default-limit, strict-option, permitted-axiom and permanent no-retry requirements.
