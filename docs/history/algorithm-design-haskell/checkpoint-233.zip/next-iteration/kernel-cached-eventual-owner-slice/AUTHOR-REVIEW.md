# Author's source check

Status: exact omission candidate, awaiting independent source review and a fresh complete gate. No compilation or measured cost claim.

The two candidate sources were reconstructed from their current frozen predecessors using only the edits in `SOURCE-CORRESPONDENCE.json`. Both complete inverses reconstruct the original files. All 47 Core and 28 Cached complementary spans match exactly, including the empty spans required by adjacent edits. The source prefixes use ordinary block comments before imports, preserving the header grammar required by the earlier diagnosed comment repair.

The Core declaration census changes from 389 to 337 named source declarations, precisely the 52 pure definitions already identified by the reviewed explicit-modifier scope. The Cached census changes from 267 to 246, precisely the 21 omitted project declarations. The 240 named declarations in the actual cached implementation prefix are untouched; the six retained project proof bodies and report commands are literal. The census is lexical source bookkeeping, not a claim to enumerate generated elaborated declarations.

All 16 shared Core declarations and the separately recorded error-print instance and full `CoreFns` structure are exact spans in the new source. The whole current cached implementation prefix is a single 196,259-byte literal pair. Explicit checks retain `instantiate1LiftP`, its cutoff proof, `enterLiftP`, `instantiate1LiftXP`, `instantiate1LiftC`, `Expr.resBool_eq`, all actual cached helpers and all six knot slots.

The consumer census checks each omitted spelling and its fully qualified name in the two retained owners and unchanged generic memo leaf. Eight matches are the preserved record fields `whnf` and `whnfCore`. The ordinary runtime driver supplement has no omitted-function match. The historical DriverForward proof and full native BasisGen/CheckerBase contexts have real pure dependencies and are explicitly excluded from compatibility claims.

The complete native CoreC namespace and the recorded 21 native/companion pairs match their selected-source spans. The inherited ordinary representation, explicit binder, proof, presentation, driver and Basis cuts are not attributed to this omission. Whole native files are retained to make that distinction inspectable.

The original 134-input Core modifier author scope and 140-input review, 264-input terminal-Boolean author scope and 30-input review, and 405-input generic author scope and 409-input review remain separate, exact historical arrays. The new inventory uses six exact portable context-copy mappings rather than rewriting any prior path. The consumed interface111 control/result context is retained as historical evidence; none of its acceptance or timing is transferred to the newly omitted source.

The source change creates no new proof, theorem statement, runtime branch, key, field, fuel constant, acceptance criterion or resource option. The remaining strict option values are unchanged. No compiler or mathematical execution was performed. An independent reviewer must check the exact omission boundary, import closure and runtime preservation before root selects and executes a new complete pilot gate.
