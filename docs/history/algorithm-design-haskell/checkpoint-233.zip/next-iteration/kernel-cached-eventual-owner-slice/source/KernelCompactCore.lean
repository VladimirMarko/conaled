/- Eventual-cached pilot owner. This distinct omission-only selection removes
the 44 pure evaluator definitions and eight TypeChecker wrappers listed in
SOURCE-CORRESPONDENCE.json. Shared runtime declarations, CoreFns and all
other retained source are literal. The historical notices below describe
predecessor layers. This is not a pure-model, native BasisGen or Installed
assembly; those APIs require a separately reviewed restoration. No runtime
branch, proof, option, fuel constant or resource policy is replaced. -/

/- Evaluator-scope extraction. The historical notices below describe retained
predecessor transformations. This variant additionally omits nine complete
Basis/Canon construction origins and the unused declaration-install interface.
All remaining declaration bodies, fields, proofs, imports and options are exact.
This is not the complete record driver: its removed API needs an explicit
restoration before Parsed/Installed integration. No speedup or acceptance is
claimed from this source-only extraction. -/

/- Presentation-only source slice over the frozen observer-law Core. The
actual algorithmic definitions, data fields, proof declarations and required
report are retained. Nineteen unused Repr deriving requests and the explicit
PropWhen display formatter/instance are omitted; PRESENTATION-OMISSIONS.json
records the exact inverse. This candidate has not been compiled or timed. -/

/- Ordinary-field layer over the frozen legacy-format logical Core.
Name.hashData, Level.hashData and Expr.data are now safe ordinary recursive
functions with exactly the same logical match alternatives; deriving follows
each function in its original namespace and class order. All other declaration
bodies, proof scripts, imports, options and private modifiers are unchanged.
Inherited comments below about cached storage/O(1) reads and predecessor-only
edit counts describe earlier layers, not this variant. Native representation
and generated helper identities are not claimed identical. The current
SOURCE-CORRESPONDENCE.json records four exact edits and separately retains
the prior legacy-format and 21-origin inverse layers. No gate or measured
performance result is claimed by this source-only preparation. -/

/- Legacy-format compatibility variant of the frozen sliced-selector Core.
Only the module/import header and section visibility/exposure commands differ.
All declarations, proof bodies and explicit private modifiers are unchanged.
Legacy imports load private transitive data; module-mode exposure/sealing
comments below describe the predecessor, not this variant's visibility regime.
No identical elaborated API or performance result is asserted. Source-only,
uncompiled preparation; SOURCE-CORRESPONDENCE.json records the 24-edit inverse. -/

import Std.Data.HashMap
import Init.Util

/-! This is a fresh source bundle of the 21 exact compact logical
kernel units. No compiled objects are inputs. Each original public
section is closed explicitly at its former end of file. See the
exact reversible SOURCE-BUNDLE.json origin and edit map. -/

/- BEGIN exact source origin ConLeche.Kernel.Name -/
-- Bundled origin 00, header line 1: module

-- Bundled origin 00, header line 3: public import Std.Data.HashMap
/- `withPtrEq` is `public` but not `@[expose]`, and its whole point here
is that it is *definitionally* `k ()` — which is what
`Name.beqPtr_eq` proves.  `import all` makes that body visible **in
this module only**; that theorem is the public relay, so no importer
needs it, and the executed `Name.beq` stays the plain
`decide (· = ·)` that the kernel can still reduce. -/
-- Bundled origin 00, header line 10: import all Init.Util

/-!
# Hierarchical names

`ConLeche.Name`, the checker's own mirror of `Lean.Name` (cached hash in
a `@[computed_field]`, pointer-and-hash-guarded equality substituted by
`@[csimp]`).  Split out of `ConLeche/Kernel/Expr.lean` on 2026-09-06 so
that `ConLeche/Kernel/PropWhen.lean` — which needs names and nothing
else — can sit *below* the expression type it annotates.
-/

section

namespace ConLeche

/-- Hierarchical names, same shape as `Lean.Name` — including the
cached hash, which lives in a `@[computed_field]` exactly as
`Lean.Name`'s does (`@[computed_field, inline] hash : Name → UInt64`,
`Init/Prelude.lean`; the C runtime stores it in the object header and
reads it with `lean_name_hash_ptr`).  Logically the field is a
*function of the value*, so it is invisible to every statement:
`DecidableEq` is still the derived structural equality, and the field
only spares the `Hashable` instance a walk (task #176 P3). -/
inductive Name where
  | anonymous
  | str (pre : Name) (s : String)
  | num (pre : Name) (n : Nat)

mutual
  /-- The cached hash of a name (official: the `uint64` in the `Name`
  object's header). -/
  def _root_.ConLeche.Name.hashData : Name → UInt64
    | .anonymous => 1723
    | .str p s => mixHash (mixHash 1 p.hashData) (hash s)
    | .num p n => mixHash (mixHash 2 p.hashData) (hash n)
end

deriving instance DecidableEq, Inhabited for Name

/-- Hashing a name is an `O(1)` field read, not a structural walk with
a byte-wise `String` hash per limb. -/
instance : Hashable Name := ⟨Name.hashData⟩

/-- Name equality in the official kernel's shape (task #176 P1):
**pointer** (`lean_name_eq`'s `if (n1 == n2) return true`), then the
**cached hash** (`lean_name_hash_ptr`), then the structural walk —
`_tmp/lean4-master-kernel/lean4_object.cpp:2762`.  This is the
*implementation* of `Name.beq`; `Name.beqPtr_eq` proves the two guards
redundant. -/
@[inline] def Name.beqPtr (a b : Name) : Bool :=
  withPtrEq a b (fun _ => a.hashData == b.hashData && decide (a = b))
    (fun h => by subst h; simp)

/-- Both guards are redundant: `withPtrEq a b k h` is *defined* as
`k ()`, and `hashData` is a function of the value, so a hash mismatch
**is** an inequality. -/
theorem Name.beqPtr_eq (a b : Name) : Name.beqPtr a b = decide (a = b) := by
  show (a.hashData == b.hashData && decide (a = b)) = decide (a = b)
  by_cases h : a = b
  · subst h; simp
  · simp [h]

/-- The executed name equality.  Definitionally `decide (a = b)` — so
the kernel, `by decide` and `#guard` still see plain structural
equality — with `beqPtr` substituted by the compiler on the strength
of the `@[csimp]` equation below. -/
def Name.beq (a b : Name) : Bool := decide (a = b)

/-- **The compiler substitution, on a kernel-checked equality.**
`@[csimp]` (not `@[implemented_by]`) is what replaces `Name.beq` by
`Name.beqPtr` in compiled code — *"do not use `implemented_by`.  If
you can prove them equal, use `csimp`"* (user ruling, 2026-09-05).
Nothing here is taken on faith: `withPtrEq a b k h` is *defined* as
`k ()` and its obligation is discharged at `beqPtr`, and `hashData` is
a function of the value, so the hash guard cannot reject an equal
pair.  `Expr.beq` is substituted the same way (`Expr.beq_eq_beqMemo`),
so no equality in the tree is an escape. -/
@[csimp] theorem Name.beq_eq_beqPtr : @Name.beq = @Name.beqPtr := by
  funext a b; exact (Name.beqPtr_eq a b).symm

instance : BEq Name := ⟨Name.beq⟩

/-- `Name.beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Name where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Name.beq]

namespace Name

/-- Conversion from `Lean.Name` (dropping macro scopes is the caller's duty). -/
def ofLeanName : Lean.Name → Name
  | .anonymous => .anonymous
  | .str p s => .str (ofLeanName p) s
  | .num p n => .num (ofLeanName p) n

protected def toString : Name → String
  | .anonymous => "[anonymous]"
  | .str .anonymous s => s
  | .str p s => p.toString ++ "." ++ s
  | .num .anonymous n => toString n
  | .num p n => p.toString ++ "." ++ toString n

instance : ToString Name := ⟨Name.toString⟩

end Name

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Name
/- END exact source origin ConLeche.Kernel.Name -/

/- BEGIN exact source origin ConLeche.Kernel.PropWhen -/
-- Bundled origin 01, header line 1: module

-- Bundled origin 01, header line 3: public import ConLeche.Kernel.Name

/- Source-only optional-law slice for the actual reducer's operational proof.
All computational declarations, instances, representation/invariant proofs,
casesZ, isNever_iff and isNever_never retain their exact original text.
Thirty-six later observer/algebra laws are omitted, including fifteen simp
registrations; PROOF-CUTS.json recovers every original byte. The original
overview and remaining comments describe the full upstream API, including
those omitted laws. This slice does not provide that full metatheory API or
assert that the changed simplifier environment has already been checked. -/

/-!
# The zero-ness datum `PropWhen` — representation, API and laws
(task #161; the small-list constructors, 2026-09-06; the canonical
representation, task #194, 2026-09-06)

The binder annotation of the validated-annotation design: the reading
of a codomain sort's zero-ness predicate `Z(l) = {φ | eval φ l = 0}`.

**This module is the datum's whole boundary.**  It owns the
representation, the API that is the only way to build, read and
compare a datum, and — following the `Std.HashMap` pattern that
`CLAUDE.md` licenses for a self-contained data-structure verification
— every law about the datum *alone*.  Downstream never re-proves them
and never sees a constructor:

* the readout `holds` and its algebra (`holds_inter`,
  `holds_bindZ_go`, `holds_ext`);
* the comparison — which is **equality**: `=`/`==`/`DecidableEq`
  decide zero-ness agreement at every valuation (`eq_iff_holds`), so
  the checker's validation and defeq sites compare with `==` and no
  separate comparison exists (task #197);
* the `inter`/`bindZ` algebra the substitution laws rest on
  (`inter_assoc`, `bindZ_inter`, `bindZ_go_append`,
  `bindZ_congr_names`, `bindZ_unit`, `paramsDefined_inter_of`).

**Canonical by construction (task #194).**  Every value of the type is
the unique representative of its parameter *set*: the parameter list
is strictly ascending in a total order on names (`Name.cmp`, defined
here), the invariant is carried by the constructors themselves, and
every producer (`ifAllZero`, `inter`, `bindZ`, hence
`Level.zeronessOf`/`Level.substPW`) normalizes.  Consequently
`ifAllZero ps = ifAllZero qs ↔ (∀ n, n ∈ ps ↔ n ∈ qs)`
(`ifAllZero_eq_iff`), `=`/`==`/`DecidableEq`/`Hashable` all decide
zero-ness agreement, and the level-instantiation identity law
(`Level.substPW_self`, `ConLeche/Verify/PropWhen.lean`) holds
unconditionally — amendment 2's counterexample (DESIGN.md, task #161
P1) was a *normalizing* substitution meeting a *non-canonical* input,
and non-canonical inputs no longer exist.

What is *not* here is what is not about the datum alone: the laws
relating it to `Level` (`Level.zeronessOf`, `Level.substPW` —
`zeronessOf_sound`, `zeronessOf_subst`, `substPW_self`,
`substPW_comp`, `holds_substPW`) live in `ConLeche/Verify/PropWhen.lean`,
because `Level` is defined *above* this module, and they are proved
purely through the API exported here.

Layering: this module imports `ConLeche.Kernel.Name` and nothing else.
-/

section

namespace ConLeche

-- Compatibility edit: explicitly declare the formerly implicit universe.
universe u

/-! ## A strict total order on names

There is no order on `ConLeche.Name` elsewhere in the tree, so
the canonical form needs one.  `Name.cmp` is the structural
lexicographic order — the shape of `Lean.Name.quickLt` minus the hash
short-cut, which would make the order depend on hashing.  Constructor
order is `anonymous < str < num`; equal constructors compare the
prefix first, then the payload with the core `Ord` instances
(`String`/`Nat`), whose `Std.TransCmp`/`Std.LawfulEqCmp` instances
supply the payload half of every law below.  `a < b` is `cmp a b =
.lt`; it is decidable, irreflexive, transitive, asymmetric and
trichotomous (`lt_irrefl`, `lt_trans`, `lt_asymm`, `lt_trichotomy`) —
a strict total order. -/

namespace Name

/-- Structural lexicographic comparison of names. -/
def cmp : Name → Name → Ordering
  | .anonymous, .anonymous => .eq
  | .anonymous, .str _ _ => .lt
  | .anonymous, .num _ _ => .lt
  | .str _ _, .anonymous => .gt
  | .num _ _, .anonymous => .gt
  | .str _ _, .num _ _ => .lt
  | .num _ _, .str _ _ => .gt
  | .str p s, .str q t => (cmp p q).then (compare s t)
  | .num p m, .num q n => (cmp p q).then (compare m n)

/-- The strict order: `cmp` reading `lt`. -/
instance : LT Name := ⟨fun a b => cmp a b = .lt⟩

instance (a b : Name) : Decidable (a < b) :=
  inferInstanceAs (Decidable (cmp a b = .lt))

theorem lt_def {a b : Name} : a < b ↔ cmp a b = .lt := Iff.rfl

theorem cmp_self : ∀ a : Name, cmp a a = .eq
  | .anonymous => rfl
  | .str p s => by
    simp [cmp, cmp_self p, Ordering.then, Std.ReflCmp.compare_self]
  | .num p n => by
    simp [cmp, cmp_self p, Ordering.then, Std.ReflCmp.compare_self]

theorem eq_of_cmp : ∀ {a b : Name}, cmp a b = .eq → a = b
  | .anonymous, .anonymous, _ => rfl
  | .str p s, .str q t, h => by
    rw [cmp, Ordering.then_eq_eq] at h
    rw [eq_of_cmp h.1, Std.LawfulEqCmp.compare_eq_iff_eq.mp h.2]
  | .num p m, .num q n, h => by
    rw [cmp, Ordering.then_eq_eq] at h
    rw [eq_of_cmp h.1, Std.LawfulEqCmp.compare_eq_iff_eq.mp h.2]

theorem cmp_swap : ∀ a b : Name, cmp a b = (cmp b a).swap
  | .anonymous, .anonymous => rfl
  | .anonymous, .str _ _ => rfl
  | .anonymous, .num _ _ => rfl
  | .str _ _, .anonymous => rfl
  | .num _ _, .anonymous => rfl
  | .str _ _, .num _ _ => rfl
  | .num _ _, .str _ _ => rfl
  | .str p s, .str q t => by
    rw [cmp, cmp, Ordering.swap_then, ← cmp_swap p q,
      ← Std.OrientedCmp.eq_swap (cmp := compare)]
  | .num p m, .num q n => by
    rw [cmp, cmp, Ordering.swap_then, ← cmp_swap p q,
      ← Std.OrientedCmp.eq_swap (cmp := compare)]

theorem cmp_trans : ∀ {a b c : Name}, cmp a b = .lt → cmp b c = .lt →
    cmp a c = .lt
  | .anonymous, .str _ _, .str _ _, _, _ => rfl
  | .anonymous, .str _ _, .num _ _, _, _ => rfl
  | .anonymous, .num _ _, .num _ _, _, _ => rfl
  | .str _ _, .num _ _, .num _ _, _, _ => rfl
  | .anonymous, .anonymous, _, h, _ => by simp [cmp] at h
  | .str _ _, .str _ _, .num _ _, _, _ => rfl
  | .str p s, .str q t, .str r u, h1, h2 => by
    rw [cmp, Ordering.then_eq_lt] at h1 h2 ⊢
    rcases h1 with h1 | ⟨h1, hs⟩
    · rcases h2 with h2 | ⟨h2, _⟩
      · exact Or.inl (cmp_trans h1 h2)
      · exact Or.inl (eq_of_cmp h2 ▸ h1)
    · rcases h2 with h2 | ⟨h2, ht⟩
      · exact Or.inl (eq_of_cmp h1 ▸ h2)
      · have hpq : p = q := eq_of_cmp h1
        have hqr : q = r := eq_of_cmp h2
        subst hpq; subst hqr
        exact Or.inr ⟨cmp_self p, Std.TransCmp.lt_trans hs ht⟩
  | .num p m, .num q n, .num r k, h1, h2 => by
    rw [cmp, Ordering.then_eq_lt] at h1 h2 ⊢
    rcases h1 with h1 | ⟨h1, hs⟩
    · rcases h2 with h2 | ⟨h2, _⟩
      · exact Or.inl (cmp_trans h1 h2)
      · exact Or.inl (eq_of_cmp h2 ▸ h1)
    · rcases h2 with h2 | ⟨h2, ht⟩
      · exact Or.inl (eq_of_cmp h1 ▸ h2)
      · have hpq : p = q := eq_of_cmp h1
        have hqr : q = r := eq_of_cmp h2
        subst hpq; subst hqr
        exact Or.inr ⟨cmp_self p, Std.TransCmp.lt_trans hs ht⟩

theorem lt_irrefl (a : Name) : ¬ a < a := by
  simp [lt_def, cmp_self]

theorem lt_trans {a b c : Name} (h1 : a < b) (h2 : b < c) : a < c :=
  cmp_trans h1 h2

theorem lt_asymm {a b : Name} (h : a < b) : ¬ b < a := by
  have h' : cmp a b = .lt := h
  have : cmp b a = .gt := by
    rw [cmp_swap b a, h']; rfl
  simp [lt_def, this]

/-- `gt` read backwards. -/
theorem lt_of_gt {a b : Name} (h : cmp a b = .gt) : b < a := by
  rw [lt_def, cmp_swap b a, h]; rfl

/-- Trichotomy: names are linearly ordered by `<`. -/
theorem lt_trichotomy (a b : Name) : a = b ∨ a < b ∨ b < a := by
  cases h : cmp a b with
  | eq => exact Or.inl (eq_of_cmp h)
  | lt => exact Or.inr (Or.inl h)
  | gt => exact Or.inr (Or.inr (lt_of_gt h))

end Name

/-! ## The sorted-list layer

The representation invariant is one predicate: `Sorted` — strictly
ascending, which is sortedness and duplicate-freeness in a single
clause (`List.Pairwise (· < ·)`).  `merge` is the ordered union of two
sorted lists, `canon` sorts-and-deduplicates an arbitrary list by
folding singletons in, and `sorted_ext` is the canonical-form theorem
the whole module rests on: two sorted lists with the same members are
the same list. -/

namespace PropWhen

/-- Strictly ascending: sorted **and** duplicate-free, in one clause. -/
abbrev Sorted (ps : List Name) : Prop := List.Pairwise (· < ·) ps

/-- Membership-equal lists agree on every `all`. -/
private theorem all_eq_of_mem_iff {ps qs : List Name}
    (h : ∀ n, n ∈ ps ↔ n ∈ qs) (f : Name → Bool) :
    ps.all f = qs.all f := by
  rw [Bool.eq_iff_iff]
  simp only [List.all_eq_true]
  exact ⟨fun hp n hn => hp n ((h n).mpr hn), fun hq n hn => hq n ((h n).mp hn)⟩

/-- The ordered merge of two sorted lists — the union of the two sets,
sorted again (`sorted_merge`). -/
def merge : List Name → List Name → List Name
  | [], bs => bs
  | a :: as, [] => a :: as
  | a :: as, b :: bs =>
    match Name.cmp a b with
    | .lt => a :: merge as (b :: bs)
    | .eq => a :: merge as bs
    | .gt => b :: merge (a :: as) bs
termination_by as bs => as.length + bs.length

@[simp] theorem merge_nil : ∀ as : List Name, merge as [] = as
  | [] => by simp [merge]
  | _ :: _ => by simp [merge]

@[simp] theorem nil_merge (bs : List Name) : merge [] bs = bs := by
  simp [merge]

@[simp] theorem mem_merge : ∀ (as bs : List Name) {n : Name},
    n ∈ merge as bs ↔ n ∈ as ∨ n ∈ bs := by
  intro as bs
  fun_induction merge as bs with
  | case1 bs => simp
  | case2 a as => simp
  | case3 a as b bs hc ih =>
    intro n; simp only [List.mem_cons, ih]; grind
  | case4 a as b bs hc ih =>
    intro n
    have hab : a = b := Name.eq_of_cmp hc
    simp only [List.mem_cons, ih, hab]; grind
  | case5 a as b bs hc ih =>
    intro n; simp only [List.mem_cons, ih]; grind

theorem all_merge (P : Name → Bool) (as bs : List Name) :
    (merge as bs).all P = (as.all P && bs.all P) := by
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, List.all_eq_true, mem_merge]
  exact ⟨fun h => ⟨fun x hx => h x (.inl hx), fun x hx => h x (.inr hx)⟩,
    fun h x hx => hx.elim (h.1 x) (h.2 x)⟩

theorem sorted_merge : ∀ {as bs : List Name}, Sorted as → Sorted bs →
    Sorted (merge as bs) := by
  intro as bs
  fun_induction merge as bs with
  | case1 bs => intro _ h; exact h
  | case2 a as => intro h1 _; exact h1
  | case3 a as b bs hc ih =>
    intro h1 h2
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih h1.2 (List.pairwise_cons.mpr h2)⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · exact h1.1 m hm
    · rcases List.mem_cons.mp hm with rfl | hm
      · exact hc
      · exact Name.lt_trans hc (h2.1 m hm)
  | case4 a as b bs hc ih =>
    intro h1 h2
    have hab : a = b := Name.eq_of_cmp hc
    subst hab
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih h1.2 h2.2⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · exact h1.1 m hm
    · exact h2.1 m hm
  | case5 a as b bs hc ih =>
    intro h1 h2
    have hba : b < a := Name.lt_of_gt hc
    simp only [Sorted, List.pairwise_cons] at h1 h2 ⊢
    refine ⟨fun m hm => ?_, ih (List.pairwise_cons.mpr h1) h2.2⟩
    rcases (mem_merge _ _).mp hm with hm | hm
    · rcases List.mem_cons.mp hm with rfl | hm
      · exact hba
      · exact Name.lt_trans hba (h1.1 m hm)
    · exact h2.1 m hm

/-- Canonicalize a raw list: sort and deduplicate, by folding the
singletons together. -/
def canon (ps : List Name) : List Name :=
  ps.foldr (fun n s => merge [n] s) []

@[simp] theorem canon_nil : canon [] = [] := by simp [canon]

@[simp] theorem canon_cons (n : Name) (ps : List Name) :
    canon (n :: ps) = merge [n] (canon ps) := by simp [canon]

@[simp] theorem mem_canon {n : Name} : ∀ {ps : List Name},
    n ∈ canon ps ↔ n ∈ ps
  | [] => by simp
  | m :: rest => by simp [mem_canon (ps := rest)]

theorem sorted_canon : ∀ ps : List Name, Sorted (canon ps)
  | [] => List.Pairwise.nil
  | m :: rest => sorted_merge (by simp [Sorted]) (sorted_canon rest)

theorem all_canon (P : Name → Bool) (ps : List Name) :
    (canon ps).all P = ps.all P :=
  all_eq_of_mem_iff (fun _ => mem_canon) P

theorem canon_eq_nil_iff {ps : List Name} : canon ps = [] ↔ ps = [] := by
  rw [List.eq_nil_iff_forall_not_mem, List.eq_nil_iff_forall_not_mem]
  simp only [mem_canon]

theorem isEmpty_canon (ps : List Name) : (canon ps).isEmpty = ps.isEmpty := by
  rw [Bool.eq_iff_iff, List.isEmpty_iff, List.isEmpty_iff, canon_eq_nil_iff]

/-- **The canonical-form theorem**: two sorted lists with the same
members are the same list. -/
theorem sorted_ext : ∀ {as bs : List Name}, Sorted as → Sorted bs →
    (∀ n, n ∈ as ↔ n ∈ bs) → as = bs
  | [], [], _, _, _ => rfl
  | [], b :: _, _, _, h => by simpa using (h b).mpr (by simp)
  | a :: _, [], _, _, h => by simpa using (h a).mp (by simp)
  | a :: as, b :: bs, ha, hb, h => by
    simp only [Sorted, List.pairwise_cons] at ha hb
    have hab : a = b := by
      rcases List.mem_cons.mp ((h a).mp (by simp)) with hx | hx
      · exact hx
      rcases List.mem_cons.mp ((h b).mpr (by simp)) with hy | hy
      · exact hy.symm
      exact absurd (hb.1 a hx) (Name.lt_asymm (ha.1 b hy))
    subst hab
    have htail : ∀ n, n ∈ as ↔ n ∈ bs := by
      intro n
      constructor
      · intro hn
        rcases List.mem_cons.mp ((h n).mp (by simp [hn])) with rfl | hn'
        · exact absurd (ha.1 n hn) (Name.lt_irrefl n)
        · exact hn'
      · intro hn
        rcases List.mem_cons.mp ((h n).mpr (by simp [hn])) with rfl | hn'
        · exact absurd (hb.1 n hn) (Name.lt_irrefl n)
        · exact hn'
    rw [sorted_ext ha.2 hb.2 htail]

/-- Canonicalizing a sorted list is the identity. -/
theorem canon_eq_self {ps : List Name} (h : Sorted ps) : canon ps = ps :=
  sorted_ext (sorted_canon ps) h fun _ => mem_canon

/-- `canon` is idempotent. -/
theorem canon_canon (ps : List Name) : canon (canon ps) = canon ps :=
  canon_eq_self (sorted_canon ps)

theorem canon_pair (p q : Name) : canon [p, q] = merge [p] [q] := by
  simp

end PropWhen

/-- The private representation of the zero-ness datum (canonical since
task #194).  The census (DESIGN.md, "THE PACKED `pw` DATUM" §1) found
the parameter lists tiny: on init-full 605 492 data are `ifAllZero
[]`, 123 332 are one name, 16 are two names and **none** is longer.
So the small cases get dedicated, allocation-free constructors, and
only lists of length ≥ 3 keep a `List` cell chain.

**Every constructor carries its invariant**: `two p q` requires
`p < q`, and `many ps` requires `ps` strictly ascending (sorted and
duplicate-free — `PropWhen.Sorted`) *and* of length > 2, so that no
list a small constructor could hold is ever a `many`.  Together with
`never`/`always`/`one` (which have nothing to get wrong) this makes
the representation a bijection with {`never`} ∪ {finite sets of
names}: **equal sets are equal values**, by construction rather than
by a normalization pass anyone could forget.

This type is `private`: it cannot be named, matched on or constructed
outside this module. -/
private inductive PropWhenRepr where
  | never
  | always
  | one (p : Name)
  | two (p q : Name) (h : p < q)
  | many (ps : List Name) (h : PropWhen.Sorted ps ∧ 2 < ps.length)
  deriving Inhabited, Hashable

/-- The zero-ness datum of a binder's codomain sort — the regime
discriminator of the validated-annotation design (task #161).  For
every level `l`, the set `Z(l) := {φ | eval φ l = 0}` of zeroing
valuations is either empty (`never`) or of the form "every parameter
in `ps` is zero" (`ifAllZero ps`; `ps = []` = always zero) — see
`Level.zeronessOf` and the mechanized battery in
`ConLeche.Verify.PropWhen`.

`ps` is a parameter *set*, and the datum is its **canonical**
representative (task #194): the smart constructor `ifAllZero` sorts
and deduplicates, `inter`/`bindZ` (hence `Level.substPW`) produce
canonical output from canonical input, and no other producer exists.
So syntactic equality decides zero-ness agreement at every valuation
(`eq_iff_holds`): the checker's validation and defeq sites compare
with `==`, the derived `Hashable` hashes the set, and the
level-instantiation identity law (`Level.substPW_self`) holds
unconditionally.

**The representation is hidden, not hidden by convention.**  The datum
is a one-field structure whose constructor *and* field are `private`,
wrapping the equally private `PropWhenRepr`.  Outside this module the
type is opaque: it cannot be pattern-matched, taken apart or built
except through the API below (`never`, `ifAllZero`, `toList`,
`toList?`, `casesZ`, the observers and their laws).  Nothing in this
module is `@[expose]`d either, so no `rfl`/`decide` downstream can
reach around the API and reduce through a body — every fact about the
datum is one of the exported theorems. -/
structure PropWhen where
  private ofRepr ::
  private repr : PropWhenRepr

namespace PropWhen

private theorem ofRepr_repr (a : PropWhen) : ofRepr a.repr = a := rfl

private theorem repr_inj {a b : PropWhen} (h : a.repr = b.repr) : a = b := by
  rw [← ofRepr_repr a, ← ofRepr_repr b, h]

/-! ### The comparison, and the instances

`DecidableEq` is structural equality spelled constructor-wise
(`equivR`) so that the name comparisons go through `Name.beq` (the
pointer-and-hash-guarded equality, `ConLeche/Kernel/Name.lean`) rather
than the derived structural walk; `equivR_iff_eq` says it *is*
equality.  `==` is the `DecidableEq`, so `=`, `==`, `decide` and every
checker comparison site run the same code.

`instance` bodies are always exposed, so they may not mention the
private representation; each therefore goes through a public (sealed)
helper that may. -/

/-- The comparison on the representation. -/
private def equivR : PropWhenRepr → PropWhenRepr → Bool
  | .never, .never => true
  | .always, .always => true
  | .one x, .one y => x == y
  | .two x y _, .two x' y' _ => x == x' && y == y'
  | .many ps _, .many qs _ => ps == qs
  | _, _ => false

private theorem equivR_iff_eq (x y : PropWhenRepr) : equivR x y = true ↔ x = y := by
  cases x <;> cases y <;> simp [equivR]

/-- Structural equality, decided constructor-wise on the hidden
representation. -/
def decEq (a b : PropWhen) : Decidable (a = b) :=
  decidable_of_iff (equivR a.repr b.repr = true)
    ((equivR_iff_eq _ _).trans ⟨repr_inj, fun h => h ▸ rfl⟩)

instance : DecidableEq PropWhen := decEq

/-- The hash of a datum — a hash of the parameter *set*, by
canonicity. -/
def hash' (pw : PropWhen) : UInt64 := hash pw.repr

instance : Hashable PropWhen := ⟨hash'⟩

/-! ### The encapsulation boundary

`never`, `ifAllZero`, `toList`, `toList?` and `casesZ` are the whole
interface to the shape; every observer below is stated over them, and
every fact anyone downstream needs is one of the exported equations.
-/

/-- "The codomain sort is nonzero at every valuation."  A *definition*
now, not a constructor — but `.never` reads the same at every use
site. -/
def never : PropWhen := ofRepr .never

instance : Inhabited PropWhen := ⟨never⟩

private theorem sorted_pair {p q : Name} (h : Sorted [p, q]) : p < q :=
  (List.pairwise_cons.mp h).1 q (List.mem_singleton.mpr rfl)

/-- Build the datum of a *sorted* list: the dedicated small
constructors for length ≤ 2, the `many` chain above, its invariant
discharged from the sortedness proof. -/
private def ofSorted : (ps : List Name) → Sorted ps → PropWhen
  | [], _ => ofRepr .always
  | [p], _ => ofRepr (.one p)
  | [p, q], h => ofRepr (.two p q (sorted_pair h))
  | p :: q :: r :: rest, h => ofRepr (.many (p :: q :: r :: rest) ⟨h, by simp⟩)

/-- The two-name datum from two arbitrary names: one comparison,
no list cell. -/
private def two' (p q : Name) : PropWhen :=
  match h : Name.cmp p q with
  | .lt => ofRepr (.two p q h)
  | .eq => ofRepr (.one p)
  | .gt => ofRepr (.two q p (Name.lt_of_gt h))

/-- **Smart constructor**: "every parameter in `ps` is zero".
Normalizing: the result is the canonical representative of the *set*
of `ps` (`toList_ifAllZero : (ifAllZero ps).toList = canon ps`, and
`ifAllZero_eq_iff`).  The empty and singleton cases touch no list
cell and no comparison; the pair case is one comparison; only lists
of length ≥ 3 run the sort. -/
@[inline] def ifAllZero : List Name → PropWhen
  | [] => ofRepr .always
  | [p] => ofRepr (.one p)
  | [p, q] => two' p q
  | ps => ofSorted (canon ps) (sorted_canon ps)

/-- The parameter list of a datum — sorted and duplicate-free
(`sorted_toList`); `never` reads as `[]` (use `toList?` where the
distinction matters). -/
def toList (pw : PropWhen) : List Name :=
  match pw.repr with
  | .never => []
  | .always => []
  | .one p => [p]
  | .two p q _ => [p, q]
  | .many ps _ => ps

/-- The parameter list of a non-`never` datum; `none` at `never`.  The
view that inverts `ifAllZero`. -/
def toList? (pw : PropWhen) : Option (List Name) :=
  match pw.repr with
  | .never => none
  | _ => some pw.toList

/-- The invariant, read off any datum. -/
theorem sorted_toList (pw : PropWhen) : Sorted pw.toList := by
  obtain ⟨x⟩ := pw
  cases x with
  | two p q h => simp [toList, Sorted, h]
  | many ps h => exact h.1
  | _ => simp [toList, Sorted]

@[simp] theorem toList_never : toList .never = [] := by
  simp [toList, never]

private theorem toList_ofSorted (ps : List Name) (h : Sorted ps) :
    (ofSorted ps h).toList = ps := by
  match ps, h with
  | [], _ | [_], _ | [_, _], _ | _ :: _ :: _ :: _, _ => simp [ofSorted, toList]

private theorem toList_two' (p q : Name) : (two' p q).toList = merge [p] [q] := by
  unfold two'
  split <;> simp [toList, merge, *]

/-- The smart constructor's list is the canonical form of its input. -/
@[simp] theorem toList_ifAllZero (ps : List Name) :
    (ifAllZero ps).toList = canon ps := by
  match ps with
  | [] => simp [ifAllZero, toList]
  | [p] => simp [ifAllZero, toList]
  | [p, q] => rw [ifAllZero, toList_two', canon_pair]
  | p :: q :: r :: rest =>
    show (ofSorted (canon (p :: q :: r :: rest)) _).toList = _
    exact toList_ofSorted _ _

/-- Membership in the smart constructor's list is membership in its
input. -/
theorem mem_toList_ifAllZero {n : Name} {ps : List Name} :
    n ∈ (ifAllZero ps).toList ↔ n ∈ ps := by
  rw [toList_ifAllZero, mem_canon]

private theorem two'_ne_never (p q : Name) : two' p q ≠ never := by
  unfold two'
  split <;> simp [never]

private theorem ofSorted_ne_never (ps : List Name) (h : Sorted ps) :
    ofSorted ps h ≠ never := by
  match ps, h with
  | [], _ | [_], _ | [_, _], _ | _ :: _ :: _ :: _, _ => simp [ofSorted, never]

/-- The smart constructor never produces `never`. -/
@[simp] theorem ifAllZero_ne_never (ps : List Name) : ifAllZero ps ≠ .never := by
  match ps with
  | [] | [_] => simp [ifAllZero, never]
  | [p, q] => exact two'_ne_never p q
  | _ :: _ :: _ :: _ => exact ofSorted_ne_never _ _

@[simp] theorem toList?_never : toList? .never = none := by
  simp [toList?, never]

private theorem toList?_eq {pw : PropWhen} (h : pw ≠ never) :
    pw.toList? = some pw.toList := by
  obtain ⟨x⟩ := pw
  cases x with
  | never => exact absurd rfl h
  | _ => simp [toList?]

@[simp] theorem toList?_ifAllZero (ps : List Name) :
    (ifAllZero ps).toList? = some (canon ps) := by
  rw [toList?_eq (ifAllZero_ne_never ps), toList_ifAllZero]

private theorem ofSorted_toList {pw : PropWhen} (hn : pw ≠ never) :
    ofSorted pw.toList (sorted_toList pw) = pw := by
  obtain ⟨x⟩ := pw
  cases x with
  | never => exact False.elim (hn rfl)
  | always => rfl
  | one p => rfl
  | two p q h => rfl
  | many ps hp =>
    cases ps with
    | nil =>
      have impossible := hp.2
      simp at impossible
    | cons p ps =>
      cases ps with
      | nil =>
        have impossible := hp.2
        simp at impossible
      | cons q ps =>
        cases ps with
        | nil =>
          have impossible := hp.2
          simp at impossible
        | cons r rest => rfl

private theorem ofSorted_congr {ps qs : List Name} (h : ps = qs)
    (hp : Sorted ps) (hq : Sorted qs) : ofSorted ps hp = ofSorted qs hq := by
  subst qs
  rfl

/-- **Extensionality on the list**: two non-`never` data with the same
parameter list are the same datum — the representation has one value
per list. -/
theorem eq_of_toList {a b : PropWhen} (ha : a ≠ never) (hb : b ≠ never)
    (h : a.toList = b.toList) : a = b := by
  exact (ofSorted_toList (pw := a) ha).symm.trans
    ((ofSorted_congr h (sorted_toList a) (sorted_toList b)).trans
      (ofSorted_toList (pw := b) hb))

/-- **Extensionality on the set**: two non-`never` data with the same
parameters are the same datum — the canonicity theorem at the datum
level. -/
theorem eq_of_mem_iff {a b : PropWhen} (ha : a ≠ never) (hb : b ≠ never)
    (h : ∀ n, n ∈ a.toList ↔ n ∈ b.toList) : a = b :=
  eq_of_toList ha hb (sorted_ext (sorted_toList a) (sorted_toList b) h)

/-- Reassembling a datum from its list — the `casesZ` companion. -/
theorem ifAllZero_toList {pw : PropWhen} (h : pw ≠ .never) :
    ifAllZero pw.toList = pw :=
  eq_of_toList (ifAllZero_ne_never _) h
    (by rw [toList_ifAllZero, canon_eq_self (sorted_toList pw)])

/-- **Unique representatives**: two smart-constructor applications are
equal exactly when their inputs have the same members. -/
theorem ifAllZero_eq_iff (ps qs : List Name) :
    ifAllZero ps = ifAllZero qs ↔ ∀ n, n ∈ ps ↔ n ∈ qs := by
  constructor
  · intro h n
    have h1 := mem_toList_ifAllZero (n := n) (ps := ps)
    rw [h, mem_toList_ifAllZero] at h1
    exact h1.symm
  · intro h
    exact eq_of_mem_iff (ifAllZero_ne_never ps) (ifAllZero_ne_never qs)
      fun n => by rw [mem_toList_ifAllZero, mem_toList_ifAllZero]; exact h n

/-- Canonicalizing the input changes nothing. -/
@[simp] theorem ifAllZero_canon (ps : List Name) :
    ifAllZero (canon ps) = ifAllZero ps :=
  (ifAllZero_eq_iff _ _).mpr fun _ => mem_canon

private theorem ifAllZero_two {p q : Name} (h : p < q) :
    ifAllZero [p, q] = ofRepr (.two p q h) :=
  ifAllZero_toList (pw := ofRepr (.two p q h)) (by simp [never])

private theorem ifAllZero_many {ps : List Name}
    (h : Sorted ps ∧ 2 < ps.length) :
    ifAllZero ps = ofRepr (.many ps h) :=
  ifAllZero_toList (pw := ofRepr (.many ps h)) (by simp [never])

/-- **The view**: every datum is `never` or `ifAllZero ps`.  Registered
as the `cases`/`induction` eliminator, so case analysis outside this
module is written — and reads — exactly as it did against the
two-constructor datum.  (The `ifAllZero` case is offered for *every*
list `ps`, canonical or not: the smart constructor normalizes, so
`ifAllZero ps` names every non-`never` datum, and a proof for all
`ps` is a proof for the canonical ones.) -/
@[elab_as_elim, cases_eliminator, induction_eliminator]
def casesZ {motive : PropWhen → Sort u} (never : motive .never)
    (ifAllZero : (ps : List Name) → motive (PropWhen.ifAllZero ps)) :
    (pw : PropWhen) → motive pw
  | .ofRepr .never => never
  | .ofRepr .always => ifAllZero []
  | .ofRepr (.one p) => ifAllZero [p]
  | .ofRepr (.two p q h) =>
    Eq.mpr (congrArg motive (ifAllZero_two h).symm) (ifAllZero [p, q])
  | .ofRepr (.many ps h) =>
    Eq.mpr (congrArg motive (ifAllZero_many h).symm) (ifAllZero ps)

/- Presentation-only slice: PropWhen.reprPrec' and its Repr instance
are omitted together with the now-unused display documentation. All
PropWhen representation data, observers and semantic proofs are retained. -/

/-! ### The observers

Each is defined representation-wise (so the small cases touch no list
cells), characterized once through `toList`, and re-stated in the
`never`/`ifAllZero` form — those equations, not the definitions, are
the whole downstream surface. -/

/-- Does the datum hold at a valuation — is the codomain sort zero
there?  (The model side's dispatch bit; the kernel never evaluates
this, it only compares data by `==`.) -/
def holds (φ : Name → Nat) (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => false
  | .always => true
  | .one p => φ p == 0
  | .two p q _ => (φ p == 0) && (φ q == 0)
  | .many ps _ => ps.all fun n => φ n == 0

/- Optional law omitted: holds_never. -/

/- Optional law omitted: holds_eq_toList. -/

/- Optional law omitted: holds_ifAllZero. -/

/-- Is the datum `never` — "the codomain sort is nonzero at *every*
valuation", the graph regime everywhere?  This is the **only**
kernel-decidable reading of the annotation that the verification tier
licenses a check-skip on (task #161 bucket 2): the P-tier claims split
their certificate cases on `pwBit φ m.pw = 0`, and `isNever` is
exactly the ∀-`φ` uniform version of the positive branch —
`pwBit φ .never = 1` at every `φ`, and no other datum has that
property (`.ifAllZero ps` holds at the all-zero valuation).  Sound
*and* exact: `isNever_iff_forall_pwBit_ne_zero` (`Model/Annot/Bit.lean`)
rests on `holds_never`/`holds_ifAllZero` here.

The datum may be read **only** to skip a re-check; it must never
select a reduct, a computed type, or a comparison result (law 1 as
amended at task #161: "annotations never change a reduct or a computed
type; annotation-gated check-skipping is permitted where the skip's
soundness is a P-tier theorem *and* the gate fires only where the
licensing theorems' hypotheses hold — `μ.verifiedChecks = true`").  Every
executable call site therefore carries the `μ.verifiedChecks` conjunct; see
`inferBodyIO` (`Kernel/CoreIO.lean`). -/
@[inline] def isNever (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => true
  | _ => false

theorem isNever_iff {pw : PropWhen} : isNever pw = true ↔ pw = never := by
  obtain ⟨x⟩ := pw
  cases x <;> simp [isNever, never]

@[simp] theorem isNever_never : isNever .never = true := isNever_iff.mpr rfl

/- Optional law omitted: isNever_ifAllZero. -/

/-- Does the datum mention any level parameter — is `Level.substPW`
ever non-trivial on it?  Folded into `Expr.hasLevelParam` and the
`hasLP` field's recurrence, so the has-param shortcut of
the level-instantiation walk stays exact. -/
@[inline] def hasParams (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => false
  | .always => false
  | _ => true

private theorem hasParams_eq_toList (pw : PropWhen) :
    hasParams pw = !pw.toList.isEmpty := by
  obtain ⟨x⟩ := pw
  cases x with
  | many ps h =>
    have : ps ≠ [] := by
      intro he; rw [he] at h; simp at h
    simp [hasParams, toList, this]
  | _ => simp [hasParams, toList]

/- Optional law omitted: hasParams_never. -/

@[simp] theorem hasParams_ifAllZero (ps : List Name) :
    hasParams (ifAllZero ps) = !ps.isEmpty := by
  rw [hasParams_eq_toList, toList_ifAllZero, isEmpty_canon]

/-- Are all parameters of the datum among `params`?  Folded into
`Expr.allLevelParamsDefined` (task #161): level instantiation's
composition law (`Level.substPW_comp`) is *false* for data whose
parameters escape the declaration's — exactly as for the levels
themselves. -/
def paramsDefined (params : List Name) (pw : PropWhen) : Bool :=
  match pw.repr with
  | .never => true
  | .always => true
  | .one p => params.contains p
  | .two p q _ => params.contains p && params.contains q
  | .many ps _ => ps.all params.contains

/- Optional law omitted: paramsDefined_eq_toList. -/

/- Optional law omitted: paramsDefined_never. -/

/- Optional law omitted: paramsDefined_ifAllZero. -/

/-! ### Extensionality at the valuations

The canonicity payoff in its semantic form: data that agree at every
valuation are equal.  Everything about the producers (`inter`,
`bindZ`) is proved through it — a `holds` computation on each side,
and the representation never appears. -/

/- Optional law omitted: mem_of_all_eq. -/

/- Optional law omitted: eq_iff_holds. -/

/- Optional law omitted: eq_of_holds. -/

/-! ### The producers -/

/-- Intersection of two zero-ness predicates (the `max` rule: a `max`
is zero iff both sides are): `never` absorbs, sets unite — the
ordered merge, so the output is canonical.  The `always`/singleton
cases are answered without touching a list cell — they are 99.99 % of
the calls (the census). -/
def inter (a b : PropWhen) : PropWhen :=
  match a.repr, b.repr with
  | .never, _ => never
  | _, .never => never
  | .always, _ => b
  | _, .always => a
  | .one x, .one y => two' x y
  | _, _ => ofSorted (merge a.toList b.toList)
      (sorted_merge (sorted_toList a) (sorted_toList b))

/- Optional law omitted: inter_never_left. -/

/- Optional law omitted: inter_never_right. -/

/- Optional law omitted: inter_ne_never. -/

/- Optional law omitted: toList_inter. -/

/- Optional law omitted: holds_inter. -/

/- Optional law omitted: inter_ifAllZero. -/

/- Optional law omitted: inter_nil. -/

/- Optional law omitted: nil_inter. -/

/-- The list-level `bindZ` fold. -/
def bindZ.go (f : Name → PropWhen) : List Name → PropWhen
  | [] => ifAllZero []
  | n :: rest => (f n).inter (go f rest)

/-- Substitute each parameter of the datum by a whole datum and
intersect ("all of `ps` zero" becomes "all replacements zero") — the
monadic bind of the zero-ness reading.  Canonical on output because
`inter` is; parameters mapped to `ifAllZero [n]` reproduce the datum
(`bindZ_unit`), which is what the unconditional identity law of level
instantiation rests on. -/
def bindZ (f : Name → PropWhen) (pw : PropWhen) : PropWhen :=
  match pw.repr with
  | .never => never
  | .always => ifAllZero []
  | .one p => f p
  | .two p q _ => (f p).inter (f q)
  | .many ps _ => bindZ.go f ps

/- Optional law omitted: bindZ_never. -/

/- Optional law omitted: bindZ_go_nil. -/

/- Optional law omitted: holds_bindZ_go. -/

/- Optional law omitted: bindZ_eq_go. -/

/- Optional law omitted: bindZ_go_canon. -/

/- Optional law omitted: bindZ_ifAllZero. -/

end PropWhen

/-! ## The law battery

Everything below is a fact about the datum alone; it needs no `Level`
and no `Expr`.  Moved here from `ConLeche/Verify/PropWhen.lean` on
2026-09-06 (the `Std.HashMap` pattern: the structure carries its
laws), statements unchanged — and unchanged again at task #194, when
the representation became canonical: the proofs below go through the
exported `never`/`ifAllZero` equations only, and those kept their
statements. -/

namespace PropWhen

/-! ### `paramsDefined` -/

/- Optional law omitted: paramsDefined_inter_of. -/

/- Optional law omitted: holds_ext. -/

/-! ### `inter` / `bindZ` algebra -/

/- Optional law omitted: inter_assoc. -/

/- Optional law omitted: inter_comm. -/

/- Optional law omitted: inter_self. -/

/- Optional law omitted: bindZ_go_append. -/

/- Optional law omitted: bindZ_inter. -/

/- Optional law omitted: bindZ_congr_names. -/

/- Optional law omitted: bindZ_unit. -/

end PropWhen

end ConLeche

end -- original EOF public section of ConLeche.Kernel.PropWhen
/- END exact source origin ConLeche.Kernel.PropWhen -/

/- BEGIN exact source origin ConLeche.Kernel.Exclusive -/
-- Bundled origin 02, header line 1: module

/- Compatibility variant for the source-only operational-refinement experiment.
The upstream documentation below describes its original native alternative.
This variant removes that alternative and its substitution attribute;
withExclusive retains exactly its original logical body, k false.
Universe binders are explicit and unused value/proof binders are renamed. -/

section

/-!
# `withExclusive`: the reference-count read behind the walk memo

**What it is.**  `withExclusive a k h` runs the continuation `k` on
whether the object `a` is *exclusive* — single-threaded with reference
count exactly 1, so that no other reference to it exists.  In the logic
it is `k false` ("not known to be exclusive", the conservative answer);
in compiled code `@[implemented_by]` substitutes `k
(isExclusiveUnsafe a)`, the real count read off the object header
(`Init/Util.lean`, `@[extern "lean_is_exclusive_obj"]`, a BORROWED
parameter; `lean_is_exclusive` in `lean.h`).  A multi-threaded object
(count `< 0`) and a persistent one (count `0` — the installed
environment after the driver's `Runtime.markPersistent`) answer
`false`, which is the safe side.

**What licenses the substitution** is the obligation

```
h : k true = k false
```

— the continuation's value does not depend on the answer, so the
compiled program computes the very value the definition names.  A
caller may use the answer to choose *how* to compute a value, never
*which* value.  `Init.Util`'s `withPtrAddr` is the same arrangement
(`k 0` in the model, the address in the binary, the continuation
address-blind by obligation), and `Bool` being two-valued makes
`k true = k false` the whole of `∀ b₁ b₂, k b₁ = k b₂`.

**What it is for.**  The per-walk memo tables of the substitution walks
(`ConLeche/Cached/ExprOpsC.lean`) exist for one reason: a node reached
twice — a shared sub-DAG — must be rebuilt once, so that the walk is
`O(DAG)` and its OUTPUT stays shared.  A node with exactly one
reference cannot be reached twice, so recording it is pure loss: the
key, the entry, the probe.  The official kernel's `replace_fn`
(`src/kernel/replace_fn.cpp`) therefore caches a node's replacement
only when `!is_likely_unshared(e)` — the same read.  The walks memoise
exactly the nodes this primitive reports shared.

**How the walks discharge `h`.**  Their result is a `Squash` — a
`Subsingleton`, exactly as `Expr.beqGoX`'s `BeqOutX` is — carrying the
rebuilt term with its proof of correctness beside an unobservable
memo, so `h` is `Subsingleton.elim` (`withExcl` below).

**The obligation cannot be weakened to the visible component.**  A
continuation returning the term beside a *bare* memo has
`k true ≠ k false` (the memo differs), and an obligation on the term
alone would leave the compiled memo — which later nodes probe —
outside the theorem.  The quotient is what makes the proof honest: the
memo's content is invisible to the type, its correctness is carried in
the memo's own type (`ConLeche/Cached/ExprOpsC.lean`: each entry
carries its proof), and the result's term is fixed by its subtype.

**The borrowed-parameter requirement.**  An owned parameter, a `let`
keeping the object alive across the call, a closure capturing it or a
`Prod` holding it is a second reference, and the read then answers
`false` for every node.  This module is `@[inline]` all the way to the
`@[extern]` call with the borrowed parameter, and the walks pass their
node BORROWED (`@&`) so that the count read is the count of references
*inside the term*.  The check is the IR audit of the tasks #314 and
#316 records (DESIGN.md): the generated C of every walk must show no
`lean_inc_ref` of the node before `lean_is_exclusive_obj`.

**Trust.**  This is the ONE `unsafe`-implemented primitive of the
substitution walks, and the only escape they add to the trust surface:
`tests/trust-surface.sh` allowlists this file for `unsafe` and
`implemented_by`, and that entry's justification is this docstring.
Nothing here is taken on faith beyond what `withPtrAddr` already asks —
the runtime's promise that `lean_is_exclusive_obj` returns a `Bool` and
has no other effect.  *Which* `Bool` is irrelevant to every theorem,
by `h`.

**Upstream.**  The primitive is proposed for `Init/Util.lean` in the
Lean RFC <https://github.com/leanprover/lean4/issues/15235>; the two
definitions below are written to be lifted there verbatim and have no
dependency on this tree.  When upstream ships it, this module becomes a
re-export.
-/

namespace ConLeche

universe u v

/-- Run `k` on whether `a` is an exclusive object — single-threaded
with reference count 1, so that no other reference to it exists — in
compiled code; in the logic, on `false`.

The obligation `h : k true = k false` says the continuation's value does
not depend on the answer, so the substitution is invisible: a caller
may use the answer only to choose *how* to compute a value, never
*which* value — typically to skip a memo probe for an object that
cannot be reached again.  The pattern of `withPtrAddr`. -/
def withExclusive {α : Type u} {β : Type v} (_a : α) (k : Bool → β)
    (_h : k true = k false) : β :=
  k false

/-- `withExclusive` into a subsingleton: the obligation is
`Subsingleton.elim` (the `Expr.withAddr` shape). -/
@[inline] def withExcl {α : Type u} {β : Type v} [Subsingleton β] (a : α)
    (k : Bool → β) : β :=
  withExclusive a k (Subsingleton.elim _ _)

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Exclusive
/- END exact source origin ConLeche.Kernel.Exclusive -/

/- BEGIN exact source origin ConLeche.Kernel.Expr -/
-- Bundled origin 03, header line 1: module

/-
Source-only compact reference: optional packed-field laws/memo equality or
lockstep canonical comparisons are omitted. Retained logical declarations
are unchanged. Historical comments describing removed implementations refer
to the full upstream source. Native compiler substitutions differ; no
native speedup or whole cached-checker compatibility is claimed.
-/

-- Bundled origin 03, header line 11: public import ConLeche.Kernel.PropWhen
-- Bundled origin 03, header line 12: public import ConLeche.Kernel.Exclusive
/- `withPtrEq` is `public` but not `@[expose]`, and its whole point here
is that it is *definitionally* `k ()` — which is what
`Level.beqPtr_eq` and `Expr.beqMemo_eq` prove.  `import all` makes that
body visible **in this module only**; those theorems are the public
relays, so no importer needs it, and the executed `Level.beq` and
`Expr.beq` stay the plain `decide (· = ·)` that the kernel can still
reduce. -/
-- Bundled origin 03, header line 20: import all Init.Util

/-!
# Kernel expressions

The checker's own term representation, mirroring Lean's kernel expressions.
We deliberately do not reuse `Lean.Expr`: our own inductive has no cached
metadata, which keeps the verification story clean.

Design decisions (see DESIGN.md):
* Free variables (`fvar`) follow nanoda's representation: a de Bruijn *level*
  together with the variable's type (and binder name, for error messages).
  The type is part of the variable's identity, so a local context is implicit
  in every open term.  Input terms coming from declarations are closed and
  use only `bvar` (de Bruijn *indices*).
* No metavariables, no `mdata`: those never reach a kernel.
-/

section

namespace ConLeche

-- Compatibility edit: explicitly declare the formerly implicit universes.
universe u v

/-- Universe levels, mirroring `Lean.Level` without metavariables —
including the cached hash, which `Lean.Level` also keeps in a
`@[computed_field]` (`data`, `Lean/Level.lean`) and the C++ kernel in
the level's packed data word (`level::hash()`).  As for `Name`, the
field is a function of the value and no statement sees it. -/
inductive Level where
  | zero
  | succ (u : Level)
  | max (u v : Level)
  | imax (u v : Level)
  | param (n : Name)

mutual
  /-- The cached hash of a level. -/
  def _root_.ConLeche.Level.hashData : Level → UInt64
    | .zero => 1
    | .succ u => mixHash 3 u.hashData
    | .max u v => mixHash 5 (mixHash u.hashData v.hashData)
    | .imax u v => mixHash 7 (mixHash u.hashData v.hashData)
    | .param n => mixHash 11 (hash n)
end

deriving instance DecidableEq, Inhabited for Level

/-- Hashing a level is an `O(1)` field read (the memo maps keyed by
`Level` — `lsimpC`, `lnzC`, `eqvC` — probe with this). -/
instance : Hashable Level := ⟨Level.hashData⟩

/-- Level equality in the official kernel's shape (task #176 P2):
the cached **hash** and the **pointer** before the structural walk —
`level.cpp:125` is `kind` → `hash` → `is_eqp` → structural.  The
implementation of `Level.beq`; `Level.beqPtr_eq` proves both guards
redundant. -/
@[inline] def Level.beqPtr (a b : Level) : Bool :=
  withPtrEq a b (fun _ => a.hashData == b.hashData && decide (a = b))
    (fun h => by subst h; simp)

/-- Both guards are redundant (see `Name.beqPtr_eq`). -/
theorem Level.beqPtr_eq (a b : Level) : Level.beqPtr a b = decide (a = b) := by
  show (a.hashData == b.hashData && decide (a = b)) = decide (a = b)
  by_cases h : a = b
  · subst h; simp
  · simp [h]

/-- The executed level equality: definitionally `decide (a = b)`, with
`beqPtr` substituted by the compiler on the `@[csimp]` equation below
(see `Name.beq_eq_beqPtr` for why this is not an escape). -/
def Level.beq (a b : Level) : Bool := decide (a = b)

/-- The `Level` twin of `Name.beq_eq_beqPtr`: `@[csimp]`, not
`@[implemented_by]`, on a kernel-checked equality. -/
@[csimp] theorem Level.beq_eq_beqPtr : @Level.beq = @Level.beqPtr := by
  funext a b; exact (Level.beqPtr_eq a b).symm

instance : BEq Level := ⟨Level.beq⟩

/-- `Level.beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Level where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Level.beq]

/-- Metadata carried by a binder (`forallE`, `lam`): the codomain
prop-ness annotation `pw` (task #161 — the validated-annotation design;
one datum per binder, written by the untrusted annotate pass or the
input stream and *validated* by the checker; the reduction rules never
read it).  Unannotated input defaults to `.never` at the parser — a
definite, validatable claim.  There is no display `BinderInfo`
(task #205): the official kernel's equality and hash ignore it — the
frontend validates a stream's spelling and drops it (`scanBinderInfo`). -/
structure BinderMeta where
  pw : PropWhen
  deriving DecidableEq, Hashable

instance : Inhabited BinderMeta := ⟨⟨.never⟩⟩

/-- Literals. -/
inductive Literal where
  | natVal (n : Nat)
  | strVal (s : String)
  deriving DecidableEq, Inhabited, Hashable

/-- Does the level mention a parameter (the official kernel's
`level.has_param`)?  There is no interned level table here, so this is
an `O(|u|)` walk — paid once per `.sort`/`.const` node construction,
never per memo touch. -/
def levelHasParam : Level → Bool
  | .zero => false
  | .param _ => true
  | .succ u => levelHasParam u
  | .max u v | .imax u v => levelHasParam u || levelHasParam v

/-- `levelHasParam` over a `const` node's level arguments. -/
def levelsHaveParam : List Level → Bool
  | [] => false
  | u :: us => levelHasParam u || levelsHaveParam us

/-- A level's hash: the cached `@[computed_field]`, so a `.sort`/`.const`
node's `hash` field is `O(1)` in the level's size *and* exact. -/
@[inline] def levelHash (u : Level) : UInt64 := u.hashData

/-- `levelHash` folded over a level list. -/
def levelsHash : List Level → UInt64
  | [] => 13
  | u :: us => mixHash (levelHash u) (levelsHash us)

/-! ## The packed node word (task #167)

`Lean.Expr` stores its derived data in one `UInt64` (`Lean.Expr.Data`:
a 32-bit hash, a 20-bit `looseBVarRange`, flags).  `ConLeche.Expr` does
the same, with one `@[computed_field] data : Expr → UInt64` whose
layout is

| bits | field | width |
|---|---|---|
| 63…32 | `hash` | 32 |
| 31 | *reserved* (always 0) | 1 |
| 30…16 | `bvarB`, the loose-bvar bound | 15 |
| 15…1 | `fvarB`, the fvar range | 15 |
| 0 | `hasLP` | 1 |

The two ranges **saturate** at `satRange = 2^15 - 1`: a node whose
bound would not fit stores `satRange`, which reads as "*at least*
`satRange`".  Saturation is a *representation* decision and costs
nothing logically — `Expr.bvarB`/`Expr.fvarB` remain the exact
functions `Expr.bvarBound`/`Expr.fvarRange` (`bvarB_eq`, `fvarB_eq`),
because the accessors fall back to a memoized exact walk on the
saturated branch.  What saturation costs is *performance*, and only
on terms that saturate: the `O(1)` field read becomes an `O(DAG)`
walk.  Measured maxima on the real streams — `init-full` 213,
`grind-ring-5` 488, `app-lam` (the deepest artificial workload) 4000 —
leave the branch unreached with 8× headroom.

The packing is written with **arithmetic**, not bitwise, operators
(`* 65536` for a shift, `/ 65536 % 32768` for a field read): the code
LLVM emits is the same shift-and-mask, and every roundtrip lemma
below is then `omega` after `UInt64.toNat`. -/

/-- Saturation value of the two 15-bit range fields: a stored
`satRange` reads as "at least `satRange`". -/
def satRange : Nat := 32767

/-- Assemble the packed word from a 32-bit hash, two 15-bit ranges and
the level-param flag.  Sums, not `|||`: the fields are disjoint, so
addition *is* the bitwise join, and the arithmetic form is what makes
the roundtrip lemmas `omega`-provable. -/
@[inline] def packData (h b f : UInt64) (lp : Bool) : UInt64 :=
  h * 4294967296 + b * 65536 + f * 2 + (if lp then 1 else 0)

/-- Hash field of a packed word (bits 63…32). -/
@[inline] def hashOfData (w : UInt64) : UInt64 := w / 4294967296

/-- Loose-bvar-bound field of a packed word (bits 30…16). -/
@[inline] def bvarOfData (w : UInt64) : UInt64 := w / 65536 % 32768

/-- Fvar-range field of a packed word (bits 15…1). -/
@[inline] def fvarOfData (w : UInt64) : UInt64 := w / 2 % 32768

/-- Has-level-param field of a packed word (bit 0). -/
@[inline] def lpOfData (w : UInt64) : Bool := w % 2 == 1

/-- Truncate a mixed hash to the packed word's 32 bits. -/
@[inline] def hash32 (w : UInt64) : UInt64 := w % 4294967296

/-- A leaf's range field: `n + 1`, saturating. -/
@[inline] def satSucc (n : Nat) : UInt64 := UInt64.ofNat (min (n + 1) satRange)

/-- A binder's range field: the body's bound less one, saturating
(a saturated body keeps a saturated bound — the stored value means
"at least", and subtracting from it would under-approximate). -/
@[inline] def satPred (x : UInt64) : UInt64 :=
  if x == 32767 then 32767 else if x == 0 then 0 else x - 1

/- Source-only optional cut: packed-field-laws. -/

/-- Kernel expressions.

`fvar idx type`: an opened variable, identified by its de Bruijn level
`idx` *and* its type.  Closed input terms contain no `fvar`s.

## No display data (task #205, user ruling)

The official kernel's `is_equal` and `hash` ignore binder names and
`BinderInfo`s (`expr_eq_fn.cpp:52, :100-103`).  Task #203 first made
every term the checker holds carry them at one normal form; the user's
ruling on that — *"if we don't keep the names we should drop the
fields!"* — is why `lam`/`forallE`/`letE` carry no binder name,
`fvar` no display name and `BinderMeta` no `BinderInfo`: there is
nothing α-irrelevant in a node, so structural `=`/`==` and the packed
`hash` ARE α-equivalence, with nothing to normalise and nothing a
fabricated term could get wrong.  The frontend still *validates* a
stream's `name` and `binderInfo` fields (a malformed record is
malformed) and drops them (`ConLeche/Frontend/ExportC.lean`); the pin
builder's `pi "a"`/`piI "α"` keep the `Init.Prelude` spelling as a
reader-facing argument (`ConLeche/Kernel/Basis/Builder.lean`).  Error
messages never printed a binder name; positions (de Bruijn level,
constant name) are what they carry.

## The computed field (task #172 B3a; packed at task #167)

Every node carries a block of derived data, **computed once at
construction time** by Lean's `@[computed_field]` feature — exactly
`Lean.Expr`'s own arrangement, down to the packing:

* `hash`  — the node's hash, so hashing a term for a memo lookup is a
  field read instead of a traversal;
* `bvarB` — the loose-bvar *bound*: the least `k` with
  `looseBVarsBounded k` (`Expr.bvarBound` is the same recurrence
  spelled as an ordinary function; `bvarB_eq` proves them equal).
  Instantiation at or above the bound is the identity;
* `fvarB` — the fvar *range*: max fvar index + 1 (`0` = fvar-free;
  `fvar` type annotations are not descended, matching the abstraction
  traversals — `Expr.fvarRange`).  Abstraction at or above the range
  is the identity;
* `hasLP` — has-level-param (`Expr.hasLevelParam`; the official
  kernel's `has_univ_param`).  Level instantiation on a node without
  it is the identity.

**One word holds all four** (`data`, the layout table above
`satRange`), which is where the node's memory goes: four separate
fields cost a `UInt64`, two boxed `Nat` pointers and a `Bool`; one
word costs eight bytes.  `bvarB` and `fvarB` *saturate* at
`satRange`; the accessors stay **exact** by falling back, on the
saturated branch alone, to a memoized walk (`bvarBoundMemo`,
`fvarRangeMemo` in `Kernel/ExprOps.lean`).  So no lemma anywhere
weakens and no invariant is threaded: saturation buys memory and
costs performance, and only on terms that saturate.

The *storage* is the compiler's: `Lean/Elab/ComputedFields.lean:33` —
*"This file implements the computed fields feature by simulating it
via `implemented_by`."*  That is a named trust escape; it is
enumerated, with the user ruling that adopted it, in the trust census
in `ConLeche/Cached/ExprNodes.lean`'s module docstring. -/
inductive Expr where
  | bvar (i : Nat)
  | fvar (idx : Nat) (type : Expr)
  | sort (u : Level)
  | const (n : Name) (us : List Level)
  | app (f a : Expr)
  | lam (type body : Expr) (m : BinderMeta)
  | forallE (type body : Expr) (m : BinderMeta)
  | letE (type value body : Expr)
  | lit (l : Literal)
  | proj (structName : Name) (idx : Nat) (e : Expr)

mutual
  /-- The packed derived-data word: `hash` (32) ǀ reserved (1) ǀ
  `bvarB` (15, saturating) ǀ `fvarB` (15, saturating) ǀ `hasLP` (1). -/
  def _root_.ConLeche.Expr.data : Expr → UInt64
    | .bvar i =>
      packData (hash32 (mixHash 3 (Hashable.hash i))) (satSucc i) 0 false
    | .fvar idx ty =>
      packData (hash32 (mixHash 5 (mixHash (Hashable.hash idx)
          (hashOfData ty.data))))
        0 (satSucc idx) (lpOfData ty.data)
    | .sort u =>
      packData (hash32 (mixHash 7 (levelHash u))) 0 0 (levelHasParam u)
    | .const n us =>
      packData (hash32 (mixHash 11 (mixHash (Hashable.hash n)
          (levelsHash us)))) 0 0 (levelsHaveParam us)
    | .app f a =>
      packData (hash32 (mixHash 17
          (mixHash (hashOfData f.data) (hashOfData a.data))))
        (max (bvarOfData f.data) (bvarOfData a.data))
        (max (fvarOfData f.data) (fvarOfData a.data))
        (lpOfData f.data || lpOfData a.data)
    | .lam ty b m =>
      packData (hash32 (mixHash 19
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData b.data) (Hashable.hash m.pw)))))
        (max (bvarOfData ty.data) (satPred (bvarOfData b.data)))
        (max (fvarOfData ty.data) (fvarOfData b.data))
        (lpOfData ty.data || lpOfData b.data || m.pw.hasParams)
    | .forallE ty b m =>
      packData (hash32 (mixHash 23
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData b.data) (Hashable.hash m.pw)))))
        (max (bvarOfData ty.data) (satPred (bvarOfData b.data)))
        (max (fvarOfData ty.data) (fvarOfData b.data))
        (lpOfData ty.data || lpOfData b.data || m.pw.hasParams)
    | .letE ty v b =>
      packData (hash32 (mixHash 29
          (mixHash (hashOfData ty.data)
            (mixHash (hashOfData v.data) (hashOfData b.data)))))
        (max (max (bvarOfData ty.data) (bvarOfData v.data))
          (satPred (bvarOfData b.data)))
        (max (max (fvarOfData ty.data) (fvarOfData v.data))
          (fvarOfData b.data))
        (lpOfData ty.data || lpOfData v.data || lpOfData b.data)
    | .lit l => packData (hash32 (mixHash 31 (Hashable.hash l))) 0 0 false
    | .proj s i e =>
      packData (hash32 (mixHash 37 (mixHash (Hashable.hash s)
          (mixHash (Hashable.hash i) (hashOfData e.data)))))
        (bvarOfData e.data) (fvarOfData e.data) (lpOfData e.data)
end

deriving instance DecidableEq, Inhabited for Expr

/-! ## The packed word's accessors

`hash` and `hasLP` are exact bit reads.  `bvarBRaw`/`fvarBRaw` are the
*saturating* reads: below `satRange` they are the exact bound
(`bvarBRaw_exact` in `Kernel/ExprOps.lean`, `fvarBRaw_exact` in
`Verify/Cached/Erase.lean`); at
`satRange` they mean "at least that", and `Expr.bvarB`/`Expr.fvarB`
(`Kernel/ExprOps.lean`) recover exactness there with a memoized
walk. -/

namespace Expr

/-- The node's 32-bit hash (`O(1)`).  The recurrence reads exactly
what `is_equal` in the official kernel reads (`expr_eq_fn.cpp`) plus
the validated `pw` datum; there is no display data in a node (task
#205), so hashing and `DecidableEq` are α-equivalence outright. -/
@[inline] def hash (e : Expr) : UInt64 := hashOfData e.data

/-- Has-level-param: is level instantiation ever non-trivial here?
One bit, so this read is *exact*. -/
@[inline] def hasLP (e : Expr) : Bool := lpOfData e.data

/-- The stored loose-bvar bound, saturating at `satRange`. -/
@[inline] def bvarBRaw (e : Expr) : Nat := (bvarOfData e.data).toNat

/-- The stored fvar range, saturating at `satRange`. -/
@[inline] def fvarBRaw (e : Expr) : Nat := (fvarOfData e.data).toNat

end Expr

/-- Hashing is the computed field: `O(1)`, no traversal; no hash in
the tree is budgeted. -/
instance : Hashable Expr := ⟨Expr.hash⟩

namespace Expr

/- Source-only optional cut: constructor-field-laws-and-memo-equality. -/

/-- The executed structural equality.  Definitionally `decide (a = b)`,
hence definitionally the `BEq` any `DecidableEq` type has, with
`beqMemo` substituted by the compiler on the `@[csimp]` equation
below. -/
def beq (a b : Expr) : Bool := decide (a = b)

/- Source-only optional cut: memo-equality-compiler-substitution. -/

instance : BEq Expr := ⟨Expr.beq⟩

/-- `beq` is lawful — it *is* `decide (· = ·)`. -/
instance : LawfulBEq Expr where
  eq_of_beq h := of_decide_eq_true h
  rfl := by simp [BEq.beq, Expr.beq]

/-! ## The shared `bvar` pool (task #177)

A `bvar` node is the smallest thing this checker builds and the one it
builds most: every substitution shifts loose indices, every abstraction
introduces one, the parser reads one per occurrence.  Each of those was
a fresh allocation — and, since the substitution walks stopped
recording their atoms in the per-walk memo, a fresh allocation that
nothing shared afterwards.

`bvarPool` is one **static** table of the first `bvarPoolSize` of them.
It is a closed top-level `def`, so the runtime builds it once at module
initialization and marks it persistent (`lean_mark_persistent` in the
generated C): handing out `bvarPool[i]` costs a bounds check and a
borrowed read, and its reference counting is free.  `mkBvar` is
representation-transparent (`mkBvar_eq`, `@[simp]`), so pattern
matching stays on `.bvar` and no statement anywhere changes.

**Where it is used.**  Every *runtime* `bvar` construction goes through
it, and the routing is one line: `ConLeche.Expr.mkBVar` is the
cached tier's only `bvar` builder, so the substitution and abstraction
walks and the frontend's parser are all covered at once.  The
remaining `.bvar` literals in the tree are either the pure *spec*
functions of `ConLeche/Kernel/ExprOps.lean` (which must keep the bare
constructor — they are what the pool is proved transparent against) or
closed constants such as the cores' `.bvar 0`, which the compiler
already lifts to a per-module `_init_…_closed__n` and marks persistent
itself.

The bound covers the corpus with room to spare: the deepest de Bruijn
index the battery produces is the 4 000-binder λ tower of
`good/perf/app-lam`. -/

/-- Size of the static `bvar` pool. -/
def bvarPoolSize : Nat := 4096

@[inherit_doc bvarPoolSize]
def bvarPool : Array Expr := (Array.range bvarPoolSize).map Expr.bvar

/-- The `bvar` smart constructor: the pooled node below `bvarPoolSize`,
a fresh one above it.  Same value either way (`mkBvar_eq`). -/
@[inline] def mkBvar (i : Nat) : Expr :=
  if h : i < bvarPool.size then bvarPool[i] else .bvar i

@[simp] theorem mkBvar_eq (i : Nat) : mkBvar i = .bvar i := by
  unfold mkBvar
  split
  · simp [bvarPool]
  · rfl

end Expr

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Expr
/- END exact source origin ConLeche.Kernel.Expr -/

/- BEGIN exact source origin ConLeche.Kernel.Level -/
-- Bundled origin 04, header line 1: module

/- Logical-reference source slice for an actual ConLeche reducer proof.
Selected optional memo/field/one-pass implementations and their csimp proofs
are omitted here; all retained logical definition and theorem bodies are
unchanged. The upstream comments that mention those native substitutions
describe the unsliced source. This variant does not retain those compiler
optimizations, and no native performance claim is made.
The exact omissions and full inverse are in UPSTREAM-COMPATIBILITY.json. -/

-- Bundled origin 04, header line 11: public import ConLeche.Kernel.Expr

section

/-!
# Level operations

Implementation of universe level comparison, following the official kernel /
nanoda (`level.rs` there): `simplify` normalizes, `leqCore` decides
`eval l ≤ eval r + diff` with the same case order as nanoda's `leq_core`
(so reduction happens the same way), and antisymmetry gives equivalence.

`leqCore`'s termination argument is nontrivial (the `imax` by-cases rule
substitutes into both sides), so it takes fuel.  Running out of fuel — or
hitting a case that is unreachable for simplified input — is reported as
`none`, which callers must never read as a verdict: a check that REQUIRES
a comparison lifts it with `liftFueled`, which DECLINES (our resource
limit).  A comparison against `zero` may read `none` as
"no": `simplify` sends every always-zero level to `zero`, where
`isEquiv` answers on its syntactic fast path.

Soundness of all of this (w.r.t. evaluation of levels into `Nat`) is proved
in `ConLeche.Verify.Level`.
-/

namespace ConLeche.Level

/-- Substitute level parameters: `subst ks vs l` replaces `param k` by the
corresponding `v`.  Unlisted parameters remain. -/
def subst (ks : List Name) (vs : List Level) : Level → Level
  | .zero => .zero
  | .succ l => .succ (subst ks vs l)
  | .max l r => .max (subst ks vs l) (subst ks vs r)
  | .imax l r => .imax (subst ks vs l) (subst ks vs r)
  | .param n => go ks vs n
where
  go : List Name → List Level → Name → Level
  | k :: ks, v :: vs, n => if k = n then v else go ks vs n
  | _, _, n => .param n

/-- Are all parameters of `l` among `params`? -/
def allParamsDefined (params : List Name) : Level → Bool
  | .zero => true
  | .succ l => allParamsDefined params l
  | .max l r | .imax l r => allParamsDefined params l && allParamsDefined params r
  | .param n => params.contains n

/-- Is this level provably nonzero at every parameter assignment
(official kernel `is_never_zero`)?  Syntactic and incomplete, exactly
as the reference: `succ` is, `max` if either side is, `imax` if the
right side is; `zero` and `param` are not. -/
def isNeverZero : Level → Bool
  | .zero => false
  | .param _ => false
  | .succ _ => true
  | .max l r => isNeverZero l || isNeverZero r
  | .imax _ r => isNeverZero r

/-- `max` of two simplified levels, pulling out common `succ`s. -/
def combining : Level → Level → Level
  | .zero, r => r
  | l, .zero => l
  | .succ l, .succ r => .succ (combining l r)
  | l, r => .max l r

/-- Normalize a level: resolve `max`/`imax` where possible. -/
def simplify : Level → Level
  | .zero => .zero
  | .param n => .param n
  | .succ l => .succ (simplify l)
  | .max l r => combining (simplify l) (simplify r)
  | .imax l r =>
    let ls := simplify l
    let rs := simplify r
    if ls = .zero || ls = .succ .zero then rs
    else match rs with
      | .zero => .zero
      | .succ _ => combining ls rs
      | _ => .imax ls rs

mutual

/-- Decide `eval l ≤ eval r + diff` for simplified `l`, `r`. -/
def leqCore (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match fuel with
  | 0 => none
  | fuel + 1 =>
    if l = .zero ∧ diff ≥ 0 then some true
    else if r = .zero ∧ diff < 0 then some false
    else rest fuel l r diff

/-- The cases after the cheap `zero` short-cuts, in nanoda's order. -/
def rest (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match l, r with
  | .param a, .param x => some (a = x && diff ≥ 0)
  | .param _, .zero => some false
  | .zero, .param _ => some (diff ≥ 0)
  | .succ s, _ => leqCore fuel s r (diff - 1)
  | _, .succ s => leqCore fuel l s (diff + 1)
  | .max a b, _ => do
    if ← leqCore fuel a r diff then leqCore fuel b r diff else pure false
  | .param _, .max x y => do
    if ← leqCore fuel l x diff then pure true else leqCore fuel l y diff
  | .zero, .max x y => do
    if ← leqCore fuel l x diff then pure true else leqCore fuel l y diff
  | _, _ =>
    match l, r with
    | .imax a b, .imax x y =>
      if a = x && b = y && diff ≥ 0 then some true else imaxRules fuel l r diff
    | _, _ => imaxRules fuel l r diff

/-- The `imax` rules (nanoda's cases 10–15): case-split on a parameter, or
distribute a nested `max`/`imax` on the right of an `imax`. -/
def imaxRules (fuel : Nat) (l r : Level) (diff : Int) : Option Bool :=
  match l, r with
  | .imax _ (.param p), _ => byCases fuel p l r diff
  | _, .imax _ (.param p) => byCases fuel p l r diff
  | .imax a (.imax x y), _ => leqCore fuel (.max (.imax a y) (.imax x y)) r diff
  | .imax a (.max x y), _ => leqCore fuel (simplify (.max (.imax a x) (.imax a y))) r diff
  | _, .imax x (.imax j k) => leqCore fuel l (.max (.imax x k) (.imax j k)) diff
  | _, .imax x (.max j k) => leqCore fuel l (simplify (.max (.imax x j) (.imax x k))) diff
  | _, _ => none  -- unreachable for simplified input; an internal error

/-- Split on the parameter `p` being zero or positive. -/
def byCases (fuel : Nat) (p : Name) (l r : Level) (diff : Int) : Option Bool := do
  let l0 := simplify (subst [p] [.zero] l)
  let r0 := simplify (subst [p] [.zero] r)
  if ← leqCore fuel l0 r0 diff then
    let ls := simplify (subst [p] [.succ (.param p)] l)
    let rs := simplify (subst [p] [.succ (.param p)] r)
    leqCore fuel ls rs diff
  else pure false

end

/-- A generous fuel bound for `leqCore`; exceeded only by pathological input
(a `max` chain deeper than the bound: `tests/e2e/level_fuel_*`), which
the checker then DECLINES — never a verdict. -/
def defaultFuel : Nat := 10000

/-- Decide `l ≤ r` semantically; `none` is an exhausted comparison. -/
def leq (l r : Level) : Option Bool :=
  leqCore defaultFuel (simplify l) (simplify r) 0

/-- Decide semantic equality of two levels; `none` is an exhausted comparison.
Syntactic equality decides directly — first on the levels themselves
(`l == r`, which is pointer- and hash-first, task #176 P2), then on
their simplified forms (the reference kernels' fast path); otherwise
antisymmetric `leq`, short-circuited.

**Conformance note (restrictions-are-findings, task #176 P2).**  The
first disjunct is what official's `is_equivalent` does and con-leche did
not: `bool is_equivalent(level const & lhs, level const & rhs) {
return lhs == rhs || normalize(lhs) == normalize(rhs); }`
(`level.cpp:518`).  It is *provably redundant* here — `l = r` implies
`simplify l = simplify r` — so the alignment is verdict-neutral by
construction, not merely accept-superset: `isEquiv_eq_withoutPtr` and
`isEquiv_of_beq` (`Verify/Level.lean`) pin both directions.  What it
buys is speed: `simplify` allocates, `l == r` on a shared level is one
pointer compare. -/
def isEquiv (l r : Level) : Option Bool := do
  if l == r then pure true
  else if simplify l = simplify r then pure true
  else if ← leq l r then leq r l else pure false

/-- Decide pointwise semantic equality of two level lists (`false` on length
mismatch). -/
def isEquivList : List Level → List Level → Option Bool
  | [], [] => some true
  | l :: ls, r :: rs => do
    if ← isEquiv l r then isEquivList ls rs else pure false
  | _, _ => some false

/-- Certainly nonzero under *every* level assignment (`succ`-headed
somewhere along every `max`, and along the `imax` right spine).
Conservative: `false` does not mean "can be zero". -/
def isNonZero : Level → Bool
  | .zero => false
  | .succ _ => true
  | .max a b => a.isNonZero || b.isNonZero
  | .imax _ b => b.isNonZero
  | .param _ => false

/-- The zero-ness datum of a level (task #161): the exact reading of
`{φ | eval φ l = 0}`.  `ConLeche.Verify.PropWhen` proves
`(zeronessOf l).holds φ = (eval φ l == 0)`.  Case notes: a `max` is
zero iff both sides are (`inter`); an `imax` is zero iff its right
side is (`eval (imax a b) = if eval b = 0 then 0 else max …`). -/
def zeronessOf : Level → PropWhen
  | .zero => .ifAllZero []
  | .succ _ => .never
  | .param n => .ifAllZero [n]
  | .max a b => (zeronessOf a).inter (zeronessOf b)
  | .imax _ b => zeronessOf b

/-- Push a level-parameter substitution through a zero-ness datum
(task #161): each parameter becomes its replacement's datum,
intersected — `Z(subst ks vs l)` is exactly
`substPW ks vs (zeronessOf l)` (`Verify.PropWhen.zeronessOf_subst`).
Canonical on output (`PropWhen.bindZ`, task #194): an unlisted
parameter reproduces `ifAllZero [n]`, so instantiating a declaration
at its own parameters is the identity here too (`substPW_self`) —
unconditionally, because every datum is canonical by construction. -/
def substPW (ks : List Name) (vs : List Level) (pw : PropWhen) :
    PropWhen :=
  pw.bindZ fun n => zeronessOf (subst.go ks vs n)

end ConLeche.Level

namespace ConLeche

/-- No duplicates in a list of names. -/
def Name.nodup : List Name → Bool
  | [] => true
  | n :: ns => !ns.contains n && Name.nodup ns

/-- Is this shaped like an installed projection function's name
(`(T.proj).i`) or a
projection table's (`(T.projTable).0`, task #175 S1)?  Both shapes
are reserved for the checker's own installs. -/
def Name.isProjFnShape : Name → Bool
  | .num (.str _ "proj") _ => true
  | .num (.str _ "projTable") _ => true
  | _ => false

/-- Substitute level parameters throughout an expression (sorts and
constant level arguments). -/
def Expr.instantiateLevelParams (ks : List Name) (us : List Level) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar idx ty => .fvar idx (ty.instantiateLevelParams ks us)
  | .sort u => .sort (Level.subst ks us u)
  | .const n vs => .const n (vs.map (Level.subst ks us))
  | .app f a => .app (f.instantiateLevelParams ks us) (a.instantiateLevelParams ks us)
  | .lam ty body m =>
    .lam (ty.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
      ⟨Level.substPW ks us m.pw⟩
  | .forallE ty body m =>
    .forallE (ty.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
      ⟨Level.substPW ks us m.pw⟩
  | .letE ty val body => .letE (ty.instantiateLevelParams ks us)
      (val.instantiateLevelParams ks us) (body.instantiateLevelParams ks us)
  | .lit l => .lit l
  | .proj s i e => .proj s i (e.instantiateLevelParams ks us)

/-- Are all level parameters occurring in `e` among `params`?  Binder
prop-ness data included (task #161): their parameters are level
parameters of the term — `instantiateLevelParams` substitutes into
them, and its composition law needs them covered exactly as it needs
the levels'. -/
def Expr.allLevelParamsDefined (params : List Name) : Expr → Bool
  | .bvar _ => true
  | .fvar _ t => t.allLevelParamsDefined params
  | .sort u => u.allParamsDefined params
  | .const _ us => us.all (Level.allParamsDefined params)
  | .app f a => f.allLevelParamsDefined params && a.allLevelParamsDefined params
  | .lam t b m | .forallE t b m =>
    t.allLevelParamsDefined params && b.allLevelParamsDefined params
      && m.pw.paramsDefined params
  | .letE t v b => t.allLevelParamsDefined params && v.allLevelParamsDefined params
      && b.allLevelParamsDefined params
  | .lit _ => true
  | .proj _ _ e => e.allLevelParamsDefined params

/- Logical-reference slice: level-parameters-memo omitted; exact inverse retained. -/

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Level
/- END exact source origin ConLeche.Kernel.Level -/

/- BEGIN exact source origin ConLeche.Kernel.ExprOps -/
-- Bundled origin 05, header line 1: module

/- Logical-reference source slice for an actual ConLeche reducer proof.
Selected optional memo/field/one-pass implementations and their csimp proofs
are omitted here; all retained logical definition and theorem bodies are
unchanged. The upstream comments that mention those native substitutions
describe the unsliced source. This variant does not retain those compiler
optimizations, and no native performance claim is made.
The exact omissions and full inverse are in UPSTREAM-COMPATIBILITY.json. -/

-- Bundled origin 05, header line 11: public import ConLeche.Kernel.Level
/- `ConLeche.Kernel.PropWhen` seals its representation on purpose (the
`Std.HashMap` pattern): its constructors are `public` but the module is
not `@[expose]`d, so a `cases`-then-`rfl` proof about a datum cannot
see the reduct.  `import all` gives that view HERE only; nothing this
module exports depends on it. -/
-- Bundled origin 05, header line 17: import all ConLeche.Kernel.PropWhen

section

/-!
# Expression operations

`instantiate1` opens a binder body: the bound variable `bvar 0` is replaced
by a given expression (in practice an `fvar`, which is closed, so no
de Bruijn shifting of the replacement is needed).

`sizeB` is the termination measure for functions that recurse into
instantiated binder bodies: it counts expression nodes but gives every
`fvar` size 1 regardless of its annotated type.  Instantiating a `bvar`
(size 1) with an `fvar` (size 1) preserves it (`sizeB_instantiate1`), so
`sizeB body < sizeB (forallE n ty body)` keeps holding after opening.
-/

namespace ConLeche.Expr

/-- Replace `bvar d` by `v` in `e`, where `d` counts the binders passed on
the way (callers start at the default `d = 0`).  `v` must be closed with
respect to bound variables (an `fvar`, a constant, …); it is not shifted.
Loose `bvar`s above `d` are lowered by one. -/
def instantiate1 (e : Expr) (v : Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar i => if i = d then v else if i > d then .bvar (i - 1) else .bvar i
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiate1 f v d) (instantiate1 a v d)
  | .lam ty body bi => .lam (instantiate1 ty v d) (instantiate1 body v (d + 1)) bi
  | .forallE ty body bi => .forallE (instantiate1 ty v d) (instantiate1 body v (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiate1 ty v d) (instantiate1 val v d) (instantiate1 body v (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiate1 e v d)

/- Logical-reference slice: instantiate1-memo omitted; exact inverse retained. -/

/-- Bulk instantiation (task #50): substitute the replacement list `vs`
for the bound variables `bvar d, bvar (d + 1), …` in one traversal —
`vs[0]` replaces `bvar d` (the *innermost* binder of a peeled
telescope), `vs[i]` replaces `bvar (d + i)`; loose `bvar`s above the
range are lowered by `vs.length`.

The semantics is by construction the *fold* of `instantiate1`:

  `instantiateList e (v :: vs) d
     = (instantiateList e vs (d + 1)).instantiate1 v d`

(`instantiateList_cons`, unconditional) — so a chain that consumes a
spine `a₁ … aₖ` outermost-first equals one call at the accumulator list
`[aₖ, …, a₁]`.  In the fold, a replacement inserted early is traversed
again by the later `instantiate1` passes; the `bvar` case reproduces
this by recursing into the replacement with the *earlier-listed*
entries (`vs.take i` — the substitutions the fold applies after
inserting `vs[i]`).  On `bvar`-closed replacements (every checker call
site) that recursion is the identity, and the cost is a single
traversal of `e` instead of `vs.length` traversals. -/
def instantiateList (e : Expr) (vs : List Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar j =>
    if j < d then .bvar j
    else if h : j - d < vs.length then
      instantiateList vs[j - d] (vs.take (j - d)) d
    else .bvar (j - vs.length)
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiateList f vs d) (instantiateList a vs d)
  | .lam ty body bi =>
    .lam (instantiateList ty vs d) (instantiateList body vs (d + 1)) bi
  | .forallE ty body bi =>
    .forallE (instantiateList ty vs d) (instantiateList body vs (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiateList ty vs d) (instantiateList val vs d)
      (instantiateList body vs (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiateList e vs d)
termination_by (vs.length, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp [List.length_take]; omega)
    | (apply Prod.Lex.right; simp; omega)

/- Logical-reference slice: instantiateList-memo omitted; exact inverse retained. -/

/-! ### `instantiateList` as the `instantiate1` fold (task #50)

The two laws the one-pass telescope opening (`openPisAtFvarsF`,
`ConLeche/Kernel/CheckerBase.lean`) needs for its `@[csimp]`; the rest
of the family is in `ConLeche/Verify/InstList.lean`. -/

set_option linter.unusedSimpArgs false in
theorem instantiateList_nil : ∀ (e : Expr) (d : Nat),
    e.instantiateList [] d = e := by
  intro e
  induction e <;> intro d <;> simp [instantiateList, *] <;> omega

set_option linter.unusedSimpArgs false in
theorem instantiateList_cons :
    ∀ (vs : List Expr) (e : Expr) (v : Expr) (d : Nat),
      e.instantiateList (v :: vs) d
        = (e.instantiateList vs (d + 1)).instantiate1 v d
  | vs, .bvar j, v, d => by
    by_cases hjd : j < d
    · have hjd1 : j < d + 1 := by omega
      simp [instantiateList, instantiate1, hjd, hjd1,
        show ¬ j = d by omega, show ¬ j > d by omega]
    · by_cases hje : j = d
      · subst hje
        simp [instantiateList, hjd, instantiate1, instantiateList_nil]
      · -- j > d: either a replacement from the tail, or above the range
        obtain ⟨i, rfl⟩ : ∃ i, j = d + 1 + i := ⟨j - d - 1, by omega⟩
        have hd1 : ¬ d + 1 + i < d + 1 := by omega
        have hsub : d + 1 + i - d = i + 1 := by omega
        have hsub2 : d + 1 + i - (d + 1) = i := by omega
        by_cases hin : i < vs.length
        · -- in range: the replacement, recursively substituted
          have hin' : d + 1 + i - d < (v :: vs).length := by simp; omega
          have hin2 : d + 1 + i - (d + 1) < vs.length := by omega
          have hr : (Expr.bvar (d + 1 + i)).instantiateList vs (d + 1)
              = vs[i].instantiateList (vs.take i) (d + 1) := by
            rw [instantiateList, ite_eq_right hd1, dite_eq_left hin2]
            simp only [hsub2]
          rw [instantiateList, ite_eq_right hjd, dite_eq_left hin', hr]
          simp only [hsub, List.getElem_cons_succ, List.take_succ_cons]
          exact instantiateList_cons (vs.take i) vs[i] v d
        · -- above the range: lowered
          have hnin : ¬ d + 1 + i - d < (v :: vs).length := by simp; omega
          have hnin2 : ¬ d + 1 + i - (d + 1) < vs.length := by omega
          have hr : (Expr.bvar (d + 1 + i)).instantiateList vs (d + 1)
              = .bvar (d + 1 + i - vs.length) := by
            rw [instantiateList, ite_eq_right hd1, dite_eq_right hnin2]
          rw [instantiateList, ite_eq_right hjd, dite_eq_right hnin, hr]
          have hgt2 : d + 1 + i - vs.length > d := by omega
          simp [instantiate1, show ¬ d + 1 + i - vs.length = d by omega,
            hgt2]
          omega
  | vs, .fvar idx ty, v, d => by simp [instantiateList, instantiate1]
  | vs, .sort u, v, d => by simp [instantiateList, instantiate1]
  | vs, .const n us, v, d => by simp [instantiateList, instantiate1]
  | vs, .app f a, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs f v d, instantiateList_cons vs a v d]
  | vs, .lam ty body bi, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs body v (d + 1)]
  | vs, .forallE ty body bi, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs body v (d + 1)]
  | vs, .letE ty val body, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs ty v d, instantiateList_cons vs val v d,
      instantiateList_cons vs body v (d + 1)]
  | vs, .lit l, v, d => by simp [instantiateList, instantiate1]
  | vs, .proj s i e, v, d => by
    simp only [instantiateList, instantiate1]
    rw [instantiateList_cons vs e v d]
termination_by vs e => (vs.length, sizeOf e)
decreasing_by
  all_goals first
    | (apply Prod.Lex.left; simp [List.length_take]; omega)
    | (apply Prod.Lex.right; simp; omega)

/-- Bump every loose bound variable `≥ cutoff` by `amount`.  Used to
transport a constructor-telescope field domain (parameters, then prior
fields) into a recursor-rule telescope (parameters, motive, minors,
then prior fields): parameter references must skip the extra motive
and minor binders, and by the zeta expansion's substitution to carry
open let-values under binders. -/
def liftLooseBVars (amount : Nat) : (cutoff : Nat) → Expr → Expr
  | c, .bvar i => if i ≥ c then .bvar (i + amount) else .bvar i
  | _, .fvar i ty => .fvar i ty
  | _, .sort u => .sort u
  | _, .const n us => .const n us
  | c, .app a b => .app (liftLooseBVars amount c a) (liftLooseBVars amount c b)
  | c, .lam ty body m =>
    .lam (liftLooseBVars amount c ty) (liftLooseBVars amount (c + 1) body) m
  | c, .forallE ty body m =>
    .forallE (liftLooseBVars amount c ty) (liftLooseBVars amount (c + 1) body) m
  | c, .letE ty v body =>
    .letE (liftLooseBVars amount c ty) (liftLooseBVars amount c v)
      (liftLooseBVars amount (c + 1) body)
  | _, .lit l => .lit l
  | c, .proj s i e => .proj s i (liftLooseBVars amount c e)

/- Logical-reference slice: liftLooseBVars-memo omitted; exact inverse retained. -/

/-! ### `resetMeta` (task #210 Part D)

Every binder's datum reset to the parse placeholder `⟨.never⟩`: the
stream's recursor rules are compared syntactically against the
generated ones (official's replay compares an exported recursor
structurally with the one it generates), and the generated body is
built from ANNOTATED pieces — the stored constructor's normalised field
telescopes and index expressions — while the stream's carries the
placeholder everywhere.  The pure walk is the spec; the executed one is
memoized by `@[csimp]` (the `mentionsConst` arrangement). -/

def resetMeta : Expr → Expr
  | .app f a => .app (resetMeta f) (resetMeta a)
  | .lam ty b _ => .lam (resetMeta ty) (resetMeta b) ⟨.never⟩
  | .forallE ty b _ => .forallE (resetMeta ty) (resetMeta b) ⟨.never⟩
  | .letE ty v b => .letE (resetMeta ty) (resetMeta v) (resetMeta b)
  | .proj s i e => .proj s i (resetMeta e)
  | .fvar i ty => .fvar i (resetMeta ty)
  | e => e

/- Logical-reference slice: resetMeta-memo omitted; exact inverse retained. -/

/-- Lower every loose bound variable `≥ cutoff + amount` by `amount`
(loose variables inside the window `[cutoff, cutoff + amount)` are left
untouched — callers certify their absence by the `liftLooseBVars`
roundtrip).  Used by the nested-rule shape certification to read a
recursor's constructor-parameter instantiations out of the
major-premise domain (an `mI`-binder context) into the rule-prefix
context (`rP` binders): `p = (p.lowerBVars (mI - rP) 0).liftLooseBVars
(mI - rP) 0` holds exactly when `p` mentions no index variable. -/
def lowerBVars (amount : Nat) : (cutoff : Nat) → Expr → Expr
  | c, .bvar i => if i ≥ c + amount then .bvar (i - amount) else .bvar i
  | _, .fvar i ty => .fvar i ty
  | _, .sort u => .sort u
  | _, .const n us => .const n us
  | c, .app a b => .app (lowerBVars amount c a) (lowerBVars amount c b)
  | c, .lam ty body m =>
    .lam (lowerBVars amount c ty) (lowerBVars amount (c + 1) body) m
  | c, .forallE ty body m =>
    .forallE (lowerBVars amount c ty) (lowerBVars amount (c + 1) body) m
  | c, .letE ty v body =>
    .letE (lowerBVars amount c ty) (lowerBVars amount c v)
      (lowerBVars amount (c + 1) body)
  | _, .lit l => .lit l
  | c, .proj s i e => .proj s i (lowerBVars amount c e)

/-- Replace `bvar d` by `v`, *lifting* `v`'s loose `bvar`s past the
binders crossed on the way — the general capture-avoiding substitution
for an open `v` (unlike `instantiate1`, which requires `v` to be
`bvar`-closed).  Let-values are open terms. -/
def instantiate1Lift (e : Expr) (v : Expr) (d : Nat := 0) : Expr :=
  match e with
  | .bvar i =>
    if i = d then Expr.liftLooseBVars d 0 v
    else if i > d then .bvar (i - 1) else .bvar i
  | .fvar idx ty => .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (instantiate1Lift f v d) (instantiate1Lift a v d)
  | .lam ty body bi =>
    .lam (instantiate1Lift ty v d) (instantiate1Lift body v (d + 1)) bi
  | .forallE ty body bi =>
    .forallE (instantiate1Lift ty v d) (instantiate1Lift body v (d + 1)) bi
  | .letE ty val body =>
    .letE (instantiate1Lift ty v d) (instantiate1Lift val v d)
      (instantiate1Lift body v (d + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (instantiate1Lift e v d)

/-- Node count with `fvar` counted as a leaf (its annotated type ignored).
Termination measure for recursion into instantiated binder bodies. -/
def sizeB : Expr → Nat
  | .bvar _ | .fvar .. | .sort _ | .const .. | .lit _ => 1
  | .app f a => sizeB f + sizeB a + 1
  | .lam ty body _ | .forallE ty body _ => sizeB ty + sizeB body + 1
  | .letE ty val body => sizeB ty + sizeB val + sizeB body + 1
  | .proj _ _ e => sizeB e + 1

/-- Instantiating with a size-1 replacement preserves `sizeB`. -/
theorem sizeB_instantiate1 (v : Expr) (hv : sizeB v = 1) :
    ∀ (e : Expr) (d : Nat), sizeB (instantiate1 e v d) = sizeB e := by
  intro e
  induction e <;> intro d <;> simp [instantiate1, sizeB, *]
  case bvar i =>
    split
    · exact hv
    · split <;> rfl

/-- Close a binder body: replace `fvar d …` leaves by `bvar k`, bumping
`k` under binders — the inverse of `instantiate1` with a fresh variable
(`fvar` type annotations are not descended into; a well-scoped term has no
`fvar d` inside another variable's annotation). -/
def abstract1 (e : Expr) (d : Nat) (k : Nat := 0) : Expr :=
  match e with
  | .bvar i => .bvar i
  | .fvar idx ty => if idx = d then .bvar k else .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (abstract1 f d k) (abstract1 a d k)
  | .lam ty body m => .lam (abstract1 ty d k) (abstract1 body d (k + 1)) m
  | .forallE ty body m => .forallE (abstract1 ty d k) (abstract1 body d (k + 1)) m
  | .letE ty val body =>
    .letE (abstract1 ty d k) (abstract1 val d k) (abstract1 body d (k + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (abstract1 e d k)

/-- Bulk abstraction (task #72): close `k` binders in one traversal —
replace `fvar (d + i) …` leaves (`i < k`) by the bound variable of the
`i`-th binder counted outermost-first, i.e. `bvar (c + (d + k - 1 - idx))`
at the traversal cursor `c` (bumped under binders; `fvar` type
annotations are not descended into, as in `abstract1`).  The semantics
is by construction the *fold* of `abstract1`, innermost binder first:

  `abstractRange e d (k + 1) c
     = abstractRange (e.abstract1 (d + k) c) d k (c + 1)`

(`abstractRange_succ`, `ConLeche/Verify/Abstract.lean`) — so the nested
per-binder `abstract1` chain of a telescope rebuild equals one
`abstractRange` pass per binder domain and one over the leaf. -/
def abstractRange (e : Expr) (d k : Nat) (c : Nat := 0) : Expr :=
  match e with
  | .bvar i => .bvar i
  | .fvar idx ty =>
    if d ≤ idx ∧ idx < d + k then .bvar (c + (d + k - 1 - idx))
    else .fvar idx ty
  | .sort u => .sort u
  | .const n us => .const n us
  | .app f a => .app (abstractRange f d k c) (abstractRange a d k c)
  | .lam ty body m =>
    .lam (abstractRange ty d k c) (abstractRange body d k (c + 1)) m
  | .forallE ty body m =>
    .forallE (abstractRange ty d k c) (abstractRange body d k (c + 1)) m
  | .letE ty val body =>
    .letE (abstractRange ty d k c) (abstractRange val d k c)
      (abstractRange body d k (c + 1))
  | .lit l => .lit l
  | .proj s i e => .proj s i (abstractRange e d k c)

/-- Full node count, including `fvar` type annotations.  Termination
measure for predicates that recurse into annotations (but never into
instantiated bodies). -/
def sizeF : Expr → Nat
  | .bvar _ | .sort _ | .const .. | .lit _ => 1
  | .fvar _ ty => sizeF ty + 1
  | .app f a => sizeF f + sizeF a + 1
  | .lam ty body _ | .forallE ty body _ => sizeF ty + sizeF body + 1
  | .letE ty val body => sizeF ty + sizeF val + sizeF body + 1
  | .proj _ _ e => sizeF e + 1

/-- All reachable `fvar` leaves, including (hereditarily) those inside
their type annotations. -/
def fvarLeaves : Expr → List (Nat × Expr)
  | .fvar idx ty => (idx, ty) :: fvarLeaves ty
  | .app f a => fvarLeaves f ++ fvarLeaves a
  | .lam ty b _ | .forallE ty b _ => fvarLeaves ty ++ fvarLeaves b
  | .letE t v b => fvarLeaves t ++ fvarLeaves v ++ fvarLeaves b
  | .proj _ _ e => fvarLeaves e
  | _ => []
termination_by e => e.sizeF
decreasing_by all_goals first
  | (simp [Expr.sizeF]; omega)
  | simp [Expr.sizeF]

/-- Scope check: every reachable `fvar` index is below `d`,
hereditarily through annotations (the `Bool` mirror of the
verification-side `WScoped`).

Not on any per-memo-op path (task #43): the executed knot's cache
operations run unguarded, justified by the proven call discipline
(`ConLeche/Verify/Cached/DiscC*.lean`).  Remaining executable call sites are the
scope guards on checker-fabricated terms in `ConLeche/Kernel/Core.lean`
(the stuck-major rescues in `majorToCtor`), each O(small
fabricated term) once per fabrication.  TODO(cleanup, task #26):
interning should cache the fvar range per node, making those O(1). -/
def wscopedB : (d : Nat) → Expr → Bool
  | d, .fvar idx ty => idx < d && wscopedB idx ty
  | d, .app f a => wscopedB d f && wscopedB d a
  | d, .lam ty body _ => wscopedB d ty && wscopedB d body
  | d, .forallE ty body _ => wscopedB d ty && wscopedB d body
  | d, .letE ty val body =>
    wscopedB d ty && wscopedB d val && wscopedB d body
  | d, .proj _ _ e => wscopedB d e
  | _, .bvar _ | _, .sort _ | _, .const _ _ | _, .lit _ => true
termination_by _ e => e.sizeF
decreasing_by all_goals first
  | (simp [Expr.sizeF]; omega)
  | simp [Expr.sizeF]

/-- Are all bound-variable references bound within the expression (below
`k` at the root)?  Input declarations must satisfy `looseBVarsBounded 0`.
The pure walk is the specification; the executed function is the
`O(1)` loose-bvar field read (`looseBVarsBoundedFast`, `@[csimp]`
below, task #210 Part B). -/
def looseBVarsBounded (k : Nat) : Expr → Bool
  | .bvar i => i < k
  | .fvar _ _ => true
  | .sort _ | .const _ _ | .lit _ => true
  | .app f a => looseBVarsBounded k f && looseBVarsBounded k a
  | .lam ty body _ | .forallE ty body _ =>
    looseBVarsBounded k ty && looseBVarsBounded (k + 1) body
  | .letE ty val body =>
    looseBVarsBounded k ty && looseBVarsBounded k val && looseBVarsBounded (k + 1) body
  | .proj _ _ e => looseBVarsBounded k e

/-- Is the expression a λ?  The λ-rule's codomain-sort check (task
#152) fires once per λ *chain* — at the innermost binder, whose body
is not itself a λ — because that is the granularity the interned
binder-telescope loop (task #72) can reproduce. -/
def isLam : Expr → Bool
  | .lam .. => true
  | _ => false

/-- The prop-ness annotation of a λ node's meta, `none` off λs — the
head reading the task-#161 chain rule consumes (an outer λ's codomain
prop-ness is its body-λ's own annotation).  Total, so the walks
commute with it structurally (`lamPw_instantiateList_fvars`,
`lamPw_shiftFrom` in `ConLeche/Verify`). -/
def lamPw : Expr → Option PropWhen
  | .lam _ _ mbI => some mbI.pw
  | _ => none

/-- Does the expression contain any free variable (`fvar`)?  Input
declarations must be `fvar`-free; the checker introduces `fvar`s only
internally when opening binders. -/
def hasFvar : Expr → Bool
  | .bvar _ | .sort _ | .const .. | .lit _ => false
  | .fvar .. => true
  | .app f a => hasFvar f || hasFvar a
  | .lam ty body _ | .forallE ty body _ => hasFvar ty || hasFvar body
  | .letE ty val body => hasFvar ty || hasFvar val || hasFvar body
  | .proj _ _ e => hasFvar e

/-- The head of an application spine. -/
def getAppFn : Expr → Expr
  | .app f _ => getAppFn f
  | e => e

/-- The arguments of an application spine, outermost last. -/
def getAppArgs : Expr → List Expr
  | .app f a => getAppArgs f ++ [a]
  | _ => []

/-- Apply to a list of arguments. -/
def mkAppN (f : Expr) : List Expr → Expr
  | [] => f
  | a :: as => mkAppN (.app f a) as

/-- Rename constants throughout (including inside `fvar` type
annotations and `proj` type names); levels and binders untouched. -/
def renameConsts (f : Name → Name) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar i ty => .fvar i (renameConsts f ty)
  | .sort u => .sort u
  | .const n us => .const (f n) us
  | .app a b => .app (renameConsts f a) (renameConsts f b)
  | .lam ty body m => .lam (renameConsts f ty) (renameConsts f body) m
  | .forallE ty body m =>
    .forallE (renameConsts f ty) (renameConsts f body) m
  | .letE ty v body =>
    .letE (renameConsts f ty) (renameConsts f v) (renameConsts f body)
  | .lit l => .lit l
  -- Task #175 wiring W5: a `.proj` node's struct name is NOT renamed.
  -- Fixing the name keeps the entry-kind readings
  -- (`denote`/`denoteMeta`, which consult the table at the struct name)
  -- rename-invariant by construction (DESIGN, "W5 opening seam").
  | .proj s i e => .proj s i (renameConsts f e)

/- Logical-reference slice: renameConsts-memo omitted; exact inverse retained. -/

/-! ### `replaceConsts`: constants to terms

The member abstraction of the positivity function (charter item 2:
"the holes are ordinary open terms (members abstracted to fvars)"):
every constant `c.{us}` with `f c us = some e` becomes `e`, inside
`fvar` annotations too; a `.proj` node's structure name is untouched.
Memoized exactly as `renameConsts` (the memo keyed by the node, dropped
after each call; `@[csimp]`, kernel-checked, no trust point). -/

/-- Replace the constants `f` maps. -/
def replaceConsts (f : Name → List Level → Option Expr) : Expr → Expr
  | .bvar i => .bvar i
  | .fvar i ty => .fvar i (replaceConsts f ty)
  | .sort u => .sort u
  | .const n us => (f n us).getD (.const n us)
  | .app a b => .app (replaceConsts f a) (replaceConsts f b)
  | .lam ty body m => .lam (replaceConsts f ty) (replaceConsts f body) m
  | .forallE ty body m => .forallE (replaceConsts f ty) (replaceConsts f body) m
  | .letE ty v body =>
    .letE (replaceConsts f ty) (replaceConsts f v) (replaceConsts f body)
  | .lit l => .lit l
  | .proj s i e => .proj s i (replaceConsts f e)

/- Logical-reference slice: replaceConsts-memo omitted; exact inverse retained. -/

/-- Strip `k` leading lambdas: the binder list (outermost first) and
the body. -/
def stripLams : Nat → Expr → Option (List (Expr × BinderMeta) × Expr)
  | 0, e => some ([], e)
  | k + 1, .lam ty b m =>
    (stripLams k b).map fun (bs, e) => ((ty, m) :: bs, e)
  | _ + 1, _ => none

/-- Strip `k` leading `∀`s: the binder list (outermost first) and the
body. -/
def stripPis : Nat → Expr → Option (List (Expr × BinderMeta) × Expr)
  | 0, e => some ([], e)
  | k + 1, .forallE ty b m =>
    (stripPis k b).map fun (bs, e) => ((ty, m) :: bs, e)
  | _ + 1, _ => none

/-- The body of a syntactic `∀`-telescope (the expression itself when
it is not a `∀`). -/
def piResult : Expr → Expr
  | .forallE _ b _ => piResult b
  | e => e

/-- Instantiate the leading `∀`-binders at the given arguments,
returning each binder's (progressively instantiated) domain together
with the fully instantiated residual. -/
def instPisAt : List Expr → Expr → Option (List Expr × Expr)
  | [], e => some ([], e)
  | a :: as, .forallE dom body _ =>
    (instPisAt as (body.instantiate1 a)).map fun (ds, rest) =>
      (dom :: ds, rest)
  | _ :: _, _ => none

/-- `instPisAt` for `λ`-binders. -/
def instLamsAt : List Expr → Expr → Option (List Expr × Expr)
  | [], e => some ([], e)
  | a :: as, .lam dom body _ =>
    (instLamsAt as (body.instantiate1 a)).map fun (ds, rest) =>
      (dom :: ds, rest)
  | _ :: _, _ => none

/- Logical-reference slice: bulk-telescope-substitution omitted; exact inverse retained. -/

/-- The type annotation of a free-variable leaf (the expression itself
otherwise; used to read the domains off an opened telescope's
variables). -/
def fvarTypeD : Expr → Expr
  | .fvar _ ty => ty
  | e => e

/-- Instantiate a telescope-context expression at an argument spine:
`bvar t` is replaced by the first argument, descending (the per-domain
effect of peeling a `t + 1`-binder telescope at the spine; the
verification's `instSeq`).  Used to evaluate a nested-auxiliary rule's
stored constructor-parameter instantiations at the recursor's actual
arguments. -/
def instSpine : List Expr → Nat → Expr → Expr
  | [], _, e => e
  | a :: as, t, e => instSpine as (t - 1) (e.instantiate1 a t)

/-- A recursor rule is *canonical* when its constructor's parameters
are exactly the recursor's own leading arguments: the major premise's
type applies the eliminated family to the first `cnP` telescope
variables.  Rules for nested auxiliary constructors (whose parameters
are instantiations like `Array Syntax`) are not canonical; they are
stored `.nested` when the syntactic reading succeeds (`nestedRuleSyn`
below) and `.inert` otherwise —
`iotaRec` never fires an inert rule, so it carries no fold
obligation. -/
def recRulePlain (recTy : Expr) (mI rP cnP : Nat) : Bool :=
  decide (cnP ≤ rP) && decide (rP ≤ mI) &&
  match recTy.stripPis mI with
  | some (_, .forallE dom _ _) =>
    dom.getAppArgs.take cnP ==
      (List.range cnP).map (fun k => Expr.bvar (mI - 1 - k))
  | _ => false

/-- **The syntactic reading of a nested rule's instantiation**: the
major's level and parameter instantiations, read off the
recursor type's major-premise domain
(`∀ …prefix… …indices…, ∀ (t : D.{lvls} p₁ … p_cnP i₁ … i_k), …`,
`k = mI - rP`).  The parameter instantiations are returned *lowered into
the rule-prefix context* (`rP` binders; `lowerBVars`) — the lift-back
roundtrip certifies that no index variable occurs in them — and the
domain's trailing arguments must be exactly the index variables in
order.  `none` when the prefix exceeds the major's position, the major
domain is not a constant-headed application of exactly `cnP + k`
arguments of this split shape, or an instantiation fails the syntactic
well-formedness guards (closed, bounded by the prefix telescope,
constants resolving by `resolves`, levels declared in `lps`) — the
facts `EnvWF` records for a stored `.nested` rule
(`nestedRuleSyn_inv`).  The installer stores it
for the rules of a recursor whose major is outside its block
(`tgtStoredRules`, `auxRuleFireR`). -/
def nestedRuleSyn (resolves : Expr → Bool) (lps : List Name) (tyA : Expr) (mI rP cnP : Nat) :
    Option (List Level × List Expr) :=
  if rP ≤ mI then
    match tyA.stripPis mI with
    | some (_, .forallE dom _ _) =>
      match dom.getAppFn with
      | .const _D lvls =>
        let args := dom.getAppArgs
        let k := mI - rP
        let pins := (args.take cnP).map (lowerBVars k 0)
        if args.length = cnP + k ∧
            args.take cnP == pins.map (liftLooseBVars k 0) ∧
            args.drop cnP ==
              (List.range k).map (fun i => Expr.bvar (k - 1 - i)) ∧
            pins.all (fun p => !p.hasFvar && p.looseBVarsBounded rP &&
              resolves p && p.allLevelParamsDefined lps) ∧
            lvls.all (Level.allParamsDefined lps) then
          some (lvls, pins)
        else none
      | _ => none
    | _ => none
  else none

/- Logical-reference slice: range-fields-and-guarded-memos omitted; exact inverse retained. -/

/-- Instantiate the leading `∀`-binders at *open* arguments, returning
the residual.  Unlike `instPisAt` this uses the general
capture-avoiding substitution (`instantiate1Lift`), so an argument may
mention loose `bvar`s of the surrounding context — which is what
building a projection's type out of the constructor telescope needs.

It sits BELOW the `@[csimp]` equation above deliberately: a `csimp`
replacement reaches the code generated for declarations elaborated
after it, so a caller written earlier in this file would compile
against the unguarded walk. -/
def instPisAtLift : List Expr → Expr → Option Expr
  | [], e => some e
  | a :: as, .forallE _ body _ => instPisAtLift as (body.instantiate1Lift a)
  | _ :: _, _ => none

/-! ## Pointer-equality shortcut -/

/-- Structural expression equality with a physical-equality shortcut
(definitionally `a == b`).  Used to validate interned-environment
entries against the stored constant they cache: the entry was created
from the very object stored in the environment, so the pointer test
succeeds without walking either expression. -/
@[inline] def exprPtrBEq (a b : Expr) : Bool :=
  withPtrEq a b (fun _ => a == b) (fun h => by subst h; simp)

/- Logical-reference slice: level-parameter-shortcuts omitted; exact inverse retained. -/

end ConLeche.Expr

end -- original EOF public section of ConLeche.Kernel.ExprOps
/- END exact source origin ConLeche.Kernel.ExprOps -/

/- BEGIN exact source origin ConLeche.Kernel.Env -/
-- Bundled origin 06, header line 1: module

-- Bundled origin 06, header line 3: public import ConLeche.Kernel.Expr

section

/-!
# Declarations and the global environment

Input declarations mirror `Lean.Declaration` (only the kinds the checker
supports so far are present; more are added feature by feature).

The environment is, for now, a simple association list of checked constants.
This is the *verified* reference representation; a faster indexed structure
can replace it later, with a proof that it refines this one.
-/

namespace ConLeche

/-- **The checker's mode setting** — two values, validated once at
startup and threaded as configuration, never re-read at runtime.

* `.verified` (the default, `--verified`): the verified lane.  The
  surface the **graded** set-theoretic
  model proves — `no_proof_of_Empty_cached`
  (`ConLeche/Verify/Cached/MainC.lean`) is its letter over the driver
  this binary runs.  The seven TT-lane checks (tasks #126, #129, #130,
  #135, #136, #137, #146) are off; the β-certificate gate is on — at a
  λ-binder whose **validated** annotation is `.never` the per-redex
  argument certificate is skipped (`betaGateFires`,
  `ConLeche/Kernel/CoreDefs.lean`) — and the io-graded knot slot skips the
  per-argument application certificate under the same licence.  Every
  other certificate family runs unconditionally.
* `.trusted` (`--trusted`): the unverified lane — the same checker
  with the work that exists **for certification only** omitted.
  What must not be dropped is everything believed necessary for
  *soundness* (which is different from "necessary for our soundness
  proof to go through"), so the lane is never optimized on its own:
  it is the real mode with certain steps omitted (DESIGN.md, "MODE
  RENAME").  Since 2026-09-06 it is literally that: the one cached
  driver (`ConLeche/Cached/ParsedC.lean`) at `.trusted`, where
  `verifiedChecks` and `certs` are `false` — so what it omits is
  exactly what those two functions gate in `ConLeche/Cached/CoreC.lean`
  (DESIGN.md, "CORET RETIRED").

**The mode is the cores' only parameter** (task #185, 2026-09-06).
The configuration record that stood between the mode and the
shipped cores from task #172 B2 to task #185 is gone: every field it
carried is a function on `CheckMode` below (`ttChecks`,
`verifiedChecks`, `betaGate`, `ioGate`, `certs`), each a `match` on
the two constructors, so each read reduces by `rfl` at either mode —
the record's `rfl`-eliminability argument, at the enum itself.

The two values are spelled `--verified` and `--trusted` on the command
line, and they say what the modes are FOR rather than which artefact
proves them. -/
inductive CheckMode where
  | verified
  | trusted
  deriving DecidableEq, Inhabited

/-- Are the seven TT-lane checks enabled?  **Constantly `false`**: the
declarative verification lane they served is retired (task #148).
The gated call sites are kept, statically unreachable, so
that the checks themselves survive as reviewed code and the accessor
stays the single place a future lane would turn them back on. -/
def CheckMode.ttChecks : CheckMode → Bool
  | _ => false

/-- Are the *verified* mode's extra checks enabled — the checks the
model lane wants and the trusted lane must not run, because they are
needed for the soundness *proof* rather than for soundness?  The
second accessor the kernel branches on
(task #152: the λ-rule's codomain-sort check, `inferBody`'s `.lam`
clause).  This is deliberately **not** `ttChecks`: the λ codomain sort
is a premise of the set lane's annotation pass (`ConLeche/Model`), so it
must run at `.verified`; and it is a check the reference kernel's
`infer_lambda` does not run, so it must not run at `.trusted`. -/
def CheckMode.verifiedChecks : CheckMode → Bool
  | .trusted => false
  | _ => true

/-- Is the **β-certificate gate** on (task #161)?  The third accessor
the kernel branches on: at a λ-binder whose validated annotation datum
is `.never` the per-redex argument certificate is skipped
(`betaGateFires`, `ConLeche/Kernel/CoreDefs.lean`).

Two disciplines ride on this accessor being a *mode* accessor rather
than a second knot:

* **the establishment/consumption asymmetry fence** — the gate reads a
  *validated* annotation (only meaningful where
  `verifiedChecks = true`) and
  wraps the **test** only, so no certificate a possibly-zero datum
  needs is ever skipped;
* **the dead-branch collapse** — at `betaGate = false` the gated test
  is definitionally the ungated one (`betaGateFires_off`), which is
  what keeps the trusted lane's proofs one rewrite away from their
  pre-gate form.

Since the R core's retirement the gate is on at the *only* verified
mode, so `betaGate` and `verifiedChecks` now agree except at
`.trusted`.
They stay two accessors because they gate different checks and the
kernel reads them at different sites. -/
def CheckMode.betaGate : CheckMode → Bool
  | .verified => true
  | _ => false

/-- Is the **io-grade knot slot** the io body (task #170 / #172 B4)?
Read once per knot level by the cached knot (`coreKnotI`,
`ConLeche/Cached/CoreC.lean`) to select what the internal inference call
sites run: the io body, whose application clause skips the
per-argument certificate at a `.never` binder under the graph-regime
licence (`ConLeche/Model/IOLicense.lean`) — official's `infer_only`.
**`true` at both modes** since the licence ruling of 2026-09-06 (the
trusted mode is defined as the verified one minus certification-only
work, and the io grade is a *licence*, not a certificate; the retired
trusted configuration record had it `true` too).  It is its own
function, and not `betaGate`, so that an attribution probe can flip
one without the other; the
mode-parametric spec knot (`coreKnot`, `ConLeche/Kernel/Core.lean`)
selects its io slot on `betaGate`, the P tier's own bit, so the two
agree exactly at `.verified` — the one instance the simulation tower
is stated at (`memoEI_inferIO_sim`, `ConLeche/Verify/Cached/KnotC.lean`).
Spelled with a wildcard so it is the literal `true` at a *variable*
mode too. -/
def CheckMode.ioGate : CheckMode → Bool
  | _ => true

/-- **The certificate families** (task #76's skip list; the twin's
retirement, 2026-09-06): the work the checker does *only* so the
soundness proof can consume it, and that the reference kernel does not
do — the β-redex argument certificate (`whnfAppI`/`betaPeelI`, through
`betaSkip`), the io-grade application argument certificate
(`inferSpineIOI`, through `ioSkip`), the recursor/constructor telescope
certificates and the canonical-index comparison of ι (`iotaRecI`), the
plain-rule parameter re-comparison, the type-former and per-projection
telescope certificates of structure η and unit-like conversion
(`structEtaCertWithI`, `structUnitCertI`), and the K/η rescue's
synthetic-spine and proof-irrelevance certificates (`majorToCtorI`).
Read through `ConLeche/Cached/CoreC.lean`'s `certAtI`/`certUnlessI` and
the two skip predicates below; `true` runs them, `false` (the trusted
mode) skips them outright.

**Why a second function beside `verifiedChecks`**, when the two agree
at both constructors.  Both are certification-only work; they differ
in what the proof towers need of them.  `verifiedChecks` gates checks
the P tier's *premises* rest on (the λ-codomain sort, the annotation
validations), so the mode-parametric spec (`ConLeche/Kernel/Core.lean`)
reads it at the same sites the cached core does.  The certificate
families have **no switch in the spec** — no proved instance ever
omits them — so the cached core's reads of `certs` are what the
simulation tower (`ConLeche/Verify/Cached/*`) must see through: it is
stated under `hμ : mode.verifiedChecks = true`, and
`certs_of_verifiedChecks` (`ConLeche/Verify/BetaGate.lean`) turns every
read into the literal `true` there.  The `.trusted` instance of the
cached-vs-spec simulation is false, deliberately: the trusted core
skips what the spec runs. -/
def CheckMode.certs : CheckMode → Bool
  | .verified => true
  | .trusted => false

/-- **The β site's read** (`whnfAppI`/`betaPeelI`): skip the per-redex
argument certificate wholesale when the certificate families are off,
else exactly when the β gate is on and the (validated) annotation
datum is `.never`.  At `.verified` it is the datum (`pw.isNever`, the
same predicate as the spec's `betaGateFires .verified pw`); at
`.trusted` the literal `true` — the β certificate is a certificate
family, skipped outright, so the licence is moot there. -/
@[inline] def CheckMode.betaSkip (mode : CheckMode) (pw : PropWhen) : Bool :=
  !mode.certs || (mode.betaGate && pw.isNever)

/-- **The io site's read** (`inferSpineIOI`): skip the per-argument
application certificate at a `.never` binder (the graph-regime
licence, `ConLeche/Model/IOLicense.lean`), or wholesale when the
certificate families are off.  At `.verified` it is `pw.isNever` — the
licence reads the datum and nothing else, as the licence ruling of
2026-09-06 has it — and at `.trusted` it is `true`. -/
@[inline] def CheckMode.ioSkip (mode : CheckMode) (pw : PropWhen) : Bool :=
  !mode.certs || pw.isNever

/-- Data common to all constants: name, universe parameters, type. -/
structure ConstantVal where
  name : Name
  levelParams : List Name
  type : Expr
  deriving DecidableEq, Inhabited

/-- How a stored recursor rule may fire (install-computed; parse
placeholder `.inert`).

* `.plain` — a canonical rule (`Expr.recRulePlain`): the constructor's
  parameters are the recursor's leading arguments and its levels link
  to the recursor's by name.
* `.nested lvls pins` — a certified nested-auxiliary rule: the
  constructor's levels and parameters are *fixed instantiations*, read
  at install off the recursor type's major-premise domain — `lvls`
  are levels over the recursor's level parameters, `pins` expressions
  in the recursor's `rulePrefix`-binder telescope context (index
  premises between the prefix and the major are supported: the shape
  certification lowers the stored instantiations out of the
  `majorIdx`-binder context after checking that no index variable
  occurs in them).  At fire time the constructor's levels and
  parameters are checked against these, instantiated at the recursor's
  actual level and leading-argument spine.
* `.inert` — never fires; a *matched* inert rule is a positive
  decline in `iotaRec` (an uncertified nested auxiliary rule).

**Why the fire compares parameters, levels and indices at all** (the
official kernel's `inductive_reduce_rec` and lean4lean fire by
constructor name plus `nfields` and compare nothing — typing justifies
it).  Our soundness argument for a fire is the stored rule law
(`RecRuleLaw`) at the recursor's own parameters, and the P lane has no
typing derivation in hand: the redex is only `WellDenotedV`, and since the
ι-slot licence (2026-09-05) the major slot of a data-motive recursor is
not even inferred, so nothing but these comparisons relates the
constructor's `p⃗'`/`idx'` to the recursor's `p⃗`/`idx`.  Moving them
into a licence was investigated (2026-09-06, `_tmp/iota-uniform/`):
for *indices* it is refuted at the squash regime (`Acc.rec.{1}` on a
cross-index `Acc.intro`: the licensed major's membership in `{pt}`
carries no information, so the uniform fire's law is false); for
*parameters* see `RecRule.paramsBlind`.
Stake: ≤ 0.8 % of init-full instructions. -/
inductive RecRuleFire where
  | inert
  | plain
  | nested (lvls : List Level) (pins : List Expr)
  deriving DecidableEq, Inhabited

/-- One iota rule of a recursor: applying the recursor (with its
parameters, motives and minors) to a `ctor`-headed major premise reduces
to `rhs` applied to the parameters, motives, minors and the constructor's
`nfields` fields.  `ctorParams` (the constructor's parameter count) and
`fire` (the canonical/nested/inert firing mode), the two rescue
bits `k`/`eta` and the parameter-comparison bit `paramsBlind` are
*computed at install* from the stored constructor, its inductive's
capabilities, the recursor type and the installing route — input rules
carry the parse placeholders `0`/`.inert`/`false`; reduction reads only
the installed values, never re-deriving them per fire. -/
structure RecRule where
  ctor : Name
  nfields : Nat
  /-- The constructor's parameter count (install-computed; parse
  placeholder `0`). -/
  ctorParams : Nat
  /-- The firing mode (install-computed, parse placeholder `.inert`):
  `.plain` for canonical rules (`Expr.recRulePlain`), `.nested` for
  certified nested-auxiliary rules, `.inert` otherwise. -/
  fire : RecRuleFire
  rhs : Expr
  /-- **The K bit** (install-computed, parse placeholder `false`;
  official `recursor_val::is_k`): this rule is its recursor's only
  one, its constructor has no fields, and that constructor's
  inductive is stored with the K capability — the standing condition
  of `majorToCtor`'s K rescue, decided once at the block's install
  instead of at every recursor application. -/
  k : Bool := false
  /-- **The η-rescue bit** (install-computed, parse placeholder
  `false`): this rule is its recursor's only one, its constructor is
  the η constructor of a stored η-capable inductive, and the recursor
  is not itself a projection function (whose rescue would loop) — the
  standing condition of `majorToCtor`'s structure-η rescue. -/
  eta : Bool := false
  /-- **The parameter-comparison bit** (install-computed, parse
  placeholder `false`): the ι step fires this rule without comparing
  the recursor's parameter arguments with the constructor's.  The
  installer and the pinned basis blocks set it, because their rule
  laws hold at any pair of fitting parameter spines; the projection
  functions do not, because their laws read the comparison.  The official
  kernel compares nothing here
  (`inductive_reduce_rec`), so a set bit is a step towards it. -/
  paramsBlind : Bool := false
  deriving DecidableEq, Inhabited

/-- Whether the ι step compares this rule's parameter comparands.  A
`.plain` rule marked `paramsBlind` fires without them; a `.nested`
rule's comparands are its stored pins and are compared at every
route. -/
def RecRule.compareParams (rl : RecRule) : Bool :=
  match rl.fire with
  | .plain => !rl.paramsBlind
  | _ => true

theorem RecRule.compareParams_plain {rl : RecRule} (hf : rl.fire = .plain)
    (hb : rl.paramsBlind = false) : rl.compareParams = true := by
  unfold RecRule.compareParams; rw [hf, hb]; rfl

theorem RecRule.compareParams_nested {rl : RecRule} {lvls : List Level}
    {pins : List Expr} (hf : rl.fire = .nested lvls pins) :
    rl.compareParams = true := by
  unfold RecRule.compareParams; rw [hf]

/-- Reducibility hint of a definition, mirroring Lean's
`ReducibilityHints`: `abbrev` unfolds first, `opaque` last, `regular`
definitions compare by their definitional height.  The hints steer only
the *order* of lazy delta unfolding in `isDefEq` — never whether two
terms are definitionally equal — so the model and all soundness proofs
are independent of them. -/
inductive ReducibilityHint where
  | «opaque»
  | «abbrev»
  | regular (height : Nat)
  deriving DecidableEq, Inhabited

namespace ReducibilityHint

/-- `h₁.lt h₂`: `h₁` is strictly less eager to unfold than `h₂` (the
lazy delta step unfolds the greater side to bring the two closer;
`opaque < regular h < abbrev`, regular heights compare by `<`). -/
def lt : ReducibilityHint → ReducibilityHint → Bool
  | _, .opaque => false
  | .abbrev, _ => false
  | .opaque, _ => true
  | _, .abbrev => true
  | .regular h₁, .regular h₂ => h₁ < h₂

/-- Both hints are `regular` at the *same* height — the only situation
in which the reference kernels (nanoda `try_eq_const_app`, the official
kernel) attempt the same-head congruence short-circuit instead of
unfolding.  Deliberately NOT generalized to other equal hints: proof
authors rely on `abbrev` definitions unfolding eagerly, and trying
spine defeq first on `abbrev`-headed applications risks reduction bombs
(spines that are only equal after reduction, retried at every
congruence level). -/
def sameRegular : ReducibilityHint → ReducibilityHint → Bool
  | .regular h₁, .regular h₂ => h₁ == h₂
  | _, _ => false

end ReducibilityHint

/- Evaluator extraction: BasisKind and its deriving requests are retained only
   in the historical installer source. -/

/-- Definitional capabilities of a stored inductive type, recorded at
install: structural eta for its (single-constructor) values, unit-like
collapse (all inhabitants definitionally equal), and rule K for its
recursor.  The pinned basis blocks carry pinned capabilities. -/
structure IndCaps where
  eta : Bool := false
  /-- The single constructor the eta law reconstructs through
  (meaningful only when `eta`). -/
  etaCtor : Name := .anonymous
  /-- Its parameter count (meaningful only when `eta`). -/
  etaParams : Nat := 0
  /-- Its field count (meaningful only when `eta`). -/
  etaFields : Nat := 0
  unitlike : Bool := false
  /-- The parameter count of the unit-like family (meaningful only
  when `unitlike`). -/
  unitParams : Nat := 0
  ruleK : Bool := false
  /-- **The family's result-sort zero-ness datum** (install-computed
  from the stored type; the default `ifAllZero []` reads
  "zero at every valuation", which no rescue passes).  The structure-η
  rescue fires only where the official kernel's `is_never_zero` holds
  of the *instantiated* result sort, and this datum decides that at a
  use by one level substitution (`capsNeverZero`) instead of a walk
  down the family's type at every rescue. -/
  sortZ : PropWhen := .ifAllZero []
  /-- **The block's members** (official's `all`): the formers installed
  together with this one, in block
  order, itself included.  Read by nested positivity alone — a container
  frame's restart (`nestFrame`) abstracts only group-mates listed here,
  so an accepted frame's holes are members of ONE recorded block (a pinned
  basis type records `[T]`, as official does; `Quot` alone keeps `[]`). -/
  all : List Name := []
  /-- **The family's parameter count** (official's `inductive_val.nparams`):
  the block's declared parameter count, recorded at every install
  (uniform: `BlockShape.nP`; basis: the pin's).  Read by nested positivity
  alone, and only for a
  container WITHOUT constructors (`nestContainer`), whose parameter count
  no constructor record carries. -/
  nparams : Nat := 0
  /-- **The family's constructors, in declaration order** (official's
  `inductive_val.cnstrs`): recorded at install (uniform: the member's
  constructors; basis: the pin's).  Read by nested positivity alone
  (`nestContainer`): a container's constructors are looked up by name,
  never by a scan of the environment.  `Quot` records none (it is no
  container). -/
  ctors : List Name := []
  deriving DecidableEq, Inhabited

/-- **One structure's projection table** (task #175 S1, 2026-09-06):
everything the checker's `.proj` rules consume about a structure `T`,
stored once at the structure's install as ONE constant (keyed on the
structure: `projTableName structName`; see `Env.findProj?`).

A table is installed by the direct simple-structure install alone.
The `.proj T i` node is first-class — typed by `bodies[i]`, the
field's result-type **body** `F_i[p⃗ ↦ bvars, f_j ↦ .proj T j (bvar
0)]`, scoped at `numParams + 1` (the parameters and the subject are
loose `bvar`s, the subject at `bvar 0`, the earlier fields already
spelled as projections of the subject), instantiated at a use by ONE
`instantiateList` along the subject type's arguments and the subject
(`ProjEntry.typeAt`); reduced by the generic structural rule `proj_i
(ctor p⃗ x⃗) ↦ x_i`, guarded at possibly-Prop instances by the stored
`guards[i]`/`structSort` levels.  The bodies are taken from the
annotated constructor type by substitution alone (`structProjBodies`)
— no annotate, no infer, no pins: a slot with no legal instantiation
simply fails the guard at every use.

**No table kinds** (task #175 tower-flag): every stored table carries
bodies, types its nodes and fires its rule, and the projection typing and iota laws
hold uniformly over every entry of every stored table. -/
structure ProjTable where
  structName : Name
  /-- the parent type former's level parameters -/
  levelParams : List Name
  /-- the parent's parameter count -/
  numParams : Nat
  /-- the single constructor (the structural rule's head) -/
  ctor : Name
  /-- its field count -/
  numFields : Nat
  /-- the parent's result sort -/
  structSort : Level
  /-- per field, the projection's result-type body (see above) -/
  bodies : Array Expr
  /-- per field, **the projection's `Prop` guard level**: the
  projected field's sort joined with the sorts of the earlier fields
  that a later field's type uses — exactly the sorts the official
  `infer_proj` requires to be `Prop` when projecting from a
  propositional structure (task #175 W4c/O4, `structProjGuards`); the
  infer branch checks it at every use of a `Prop`-declared
  structure. -/
  guards : List Level
  /-- **The projection offset** (task #210 Part A): the position of
  field `0` in the carrier's pair chain — `1` at the installer's
  TAGGED tower (`inj 0 (mkTower (fs ++ [pt]))`, the tag in front),
  which is the only value the installer stores (`checkBlockTables`);
  `0` would read a bare tuple tower `mkTower fs` — so that the model
  reads `.proj T i` as `projS (i + off)`.  Syntactic to the kernel: the typing, iota and
  eta rules never look at it. -/
  off : Nat
  deriving DecidableEq, Inhabited

/-- **One projection-table entry** — the per-field VIEW of a
`ProjTable` (`ProjTable.entry`), what `Env.findProj? T i` returns:
the table's data at field `idx`.  `body` is `bodies[idx]` and
`fieldSort` is `guards[idx]`. -/
structure ProjEntry where
  structName : Name
  idx : Nat
  levelParams : List Name
  numParams : Nat
  ctor : Name
  numFields : Nat
  /-- the projection's result-type body, scoped at `numParams + 1`
  (see `ProjTable.bodies`) -/
  body : Expr
  /-- the projection's `Prop` guard level (see `ProjTable.guards`) -/
  fieldSort : Level
  structSort : Level
  /-- the table's projection offset (see `ProjTable.off`) -/
  off : Nat
  deriving DecidableEq, Inhabited

/-- The per-field view of a table at field `i` (meaningful for `i <
numFields`). -/
def ProjTable.entry (tbl : ProjTable) (i : Nat) : ProjEntry :=
  ⟨tbl.structName, i, tbl.levelParams, tbl.numParams, tbl.ctor, tbl.numFields,
    tbl.bodies.getD i default, tbl.guards.getD i .zero, tbl.structSort, tbl.off⟩

/-- Information stored about an accepted constant. -/
inductive ConstantInfo where
  | axiomInfo (val : ConstantVal)
  | defnInfo (val : ConstantVal) (value : Expr) (hint : ReducibilityHint)
  | thmInfo (val : ConstantVal) (value : Expr)
  /-- An inductive type former (whnf-stuck) with its capabilities. -/
  | indInfo (val : ConstantVal) (caps : IndCaps)
  /-- A basis constructor (whnf-stuck; the iota target). -/
  | ctorInfo (val : ConstantVal) (numParams numFields : Nat)
  /-- A basis recursor with its iota rules.  Only the two sums the
  firing path reads are stored: `majorIdx` (= numParams + numMotives +
  numMinors + numIndices, the major premise's argument position) and
  `rulePrefix` (= numParams + numMotives + numMinors, the length of the
  argument prefix a rule's rhs is applied to).  The individual counts
  are consumed at install time only and are not stored. -/
  | recInfo (val : ConstantVal) (majorIdx rulePrefix : Nat)
      (rules : List RecRule)
  /-- A structure's projection table (see `ProjTable`), stored under
  the reserved name `projTableName tbl.structName` so lookups,
  freshness and environment extension are uniform with constants.  Its
  `toConstantVal` carries the closed dummy type `Sort 1` (the table is
  not a term: no `.const` names it, `inferTypeCore` rejects one), so
  the environment well-formedness and model machinery cover the
  constant uniformly; the bodies' own well-formedness is `EnvWF`'s
  table clause. -/
  | projInfo (tbl : ProjTable)
  deriving DecidableEq, Inhabited

/- Evaluator extraction: QuotKind, Declaration, piSortTeleLen? and indParamsOk
   belong to the separately retained original record-install interface. -/

/-- The public projection-*function* name for field `i` of structure
`T` (a `Nat` component keeps it out of the way of exported
identifiers; installs are duplicate-checked regardless).  Since task
#175 S1 no table entry lives under this name: the direct install's
table is one constant per structure, `projTableName`. -/
def projFnName (T : Name) (i : Nat) : Name := (T.str "proj").num i

/-- The reserved name of structure `T`'s projection table (task #175
S1): one constant per structure, a `Nat` component keeping it out of
the way of exported identifiers (the front door rejects the shape,
`Name.isProjFnShape`), distinct from every `projFnName` name. -/
def projTableName (T : Name) : Name := (T.str "projTable").num 0

namespace ConstantInfo

def toConstantVal : ConstantInfo → ConstantVal
  | .axiomInfo v | .defnInfo v _ _ | .thmInfo v _ => v
  | .indInfo v _ | .ctorInfo v _ _ | .recInfo v _ _ _ => v
  | .projInfo tbl => ⟨projTableName tbl.structName, tbl.levelParams, .sort (.succ .zero)⟩

def name (c : ConstantInfo) : Name := c.toConstantVal.name

/-- A projection table (task #175 W4c): a table, not a term — no
`.const` node names it (`inferTypeCore` rejects one), so the model
owes it no leaf. -/
def isTowerEntry : ConstantInfo → Bool
  | .projInfo _ => true
  | _ => false

end ConstantInfo

/- Evaluator extraction: Declaration.names belongs to the retained driver API. -/

/-- The global environment: the list of constants accepted so far, newest
first.  Names are unique (the checker rejects duplicates), so the order is
irrelevant for lookup. -/
structure Env where
  consts : List ConstantInfo
  deriving Inhabited

namespace Env

/-- The empty environment; the starting point of every checker run. -/
def empty : Env := ⟨[]⟩

def find? (env : Env) (n : Name) : Option ConstantInfo :=
  env.consts.find? (·.name == n)

/-- Look up the projection-table entry for field `i` of `T`: the
structure's table (`projTableName T`), viewed at field `i` (task #175
S1; `none` beyond the table's field count). -/
def findProj? (env : Env) (T : Name) (i : Nat) : Option ProjEntry :=
  match env.find? (projTableName T) with
  | some (.projInfo tbl) => if i < tbl.numFields then some (tbl.entry i) else none
  | _ => none

end Env

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Env
/- END exact source origin ConLeche.Kernel.Env -/

/- BEGIN exact source origin ConLeche.Kernel.PropRead -/
-- Bundled origin 07, header line 1: module

-- Bundled origin 07, header line 3: public import ConLeche.Kernel.Env
-- Bundled origin 07, header line 4: public import ConLeche.Kernel.ExprOps

section

/-!
# Fast prop-ness off the head symbol (task #168)

Two pure readers that answer "is this type a proposition?" / "is this
term a proof?" from the **head symbol, the arity and the validated
`pw` annotations** — no inference, no reduction, no memo.

Prop-ness is invariant under application: `zeronessOf (imax u v) =
zeronessOf v`, so the zero-ness of the sort of the type of `c a⃗` is
that of `c`'s *stored* type at every arity, over-application included.
The datum a head-symbol reader needs is therefore **one `PropWhen` per
constant** — the zero-ness of the sort of its type, read off the
stored (annotated, validated) type and instantiated at the use's
levels by `substPW`.

Both readers are three-valued (`some pw` = the datum, `none` = unknown,
fall back to inference).  The kernel's verdict on a datum is exactly the
slow path's `Level.isEquiv u .zero`: `pw == (.ifAllZero [])` ⟺ the
sort is zero at every valuation.

Trust: the readers consume annotations the checker validates
(`(forall-cod)`, `(lam-cod-leaf)`/`(lam-cod-chain)` in `inferBody`;
the stored types were validated at install), so they may only be
*consulted* at the verified modes (`mode.verifiedChecks`) — the trusted core
writes no data and the parser default stays.  The **"definitely not a
proof" arm** (`notProofFast`) needs no model theorem: refusing the
proof-irrelevance shortcut is always sound; its obligation is
kernel-level agreement with the slow path, which the landing census
records (DESIGN.md, task #168).  The **"definitely a proof" arm** is a
squash-regime licence (`prf_of_isProofFast`, `ConLeche/Model/Rules/DefEqSoundKit.lean`).
-/

namespace ConLeche

namespace Expr

/-- The residual after peeling `k` *syntactic* ∀ binders whose data
are all `.never` (no substitution — the residual may mention the
peeled binders; the readers only look at its head shape).  The
`.never` requirement costs no coverage on validated types — the
binders of a type former `∀ p⃗, Sort u` all carry the datum of a
`succ` codomain sort — and it is what licenses the "yes" arm's
telescope walk without a certificate (`neverChain_of_peel`,
`ConLeche/Model/Rules/DefEqSoundKit.lean`: every slot is in the graph
regime, `io_domain_transfer`). -/
def peelNeverPis : Nat → Expr → Option Expr
  | 0, e => some e
  | k + 1, .forallE _ b m => if m.pw.isNever then peelNeverPis k b else none
  | _ + 1, _ => none

/-- The number of arguments of an application spine. -/
def numArgs : Expr → Nat
  | .app f _ => numArgs f + 1
  | _ => 0

end Expr

/-- The zero-ness datum of the sort of a *residual type*: a `Sort u`
residual says the type inhabits `Sort u`.  (A ∀ residual would mean
the applied head is a function, not a type — unreachable on
well-typed input, and unknown here.) -/
def residualPW : Option Expr → Option PropWhen
  | some (.sort u) => some (Level.zeronessOf u)
  | _ => none

/-- The datum of a type-former application's *head* at `n` arguments:
a constant head reads its stored type (level-instantiated), an fvar
head its declared type; the residual after `n` syntactic binders is
read by `residualPW`. -/
def headTypePW (find? : Name → Option ConstantInfo) : Expr → Nat →
    Option PropWhen
  | .const I us, n =>
    match find? I with
    | some ci =>
      if ci.isTowerEntry then none else
      let cv := ci.toConstantVal
      if us.length = cv.levelParams.length then
        (residualPW (cv.type.peelNeverPis n)).map
          (Level.substPW cv.levelParams us)
      else none
    | none => none
  | .fvar _ ty, n => residualPW (ty.peelNeverPis n)
  | _, _ => none

/-- The zero-ness datum of the sort of the *type* `T` ("is `T` a
proposition?"), read off `T`'s head symbol and the annotations: a ∀
carries it on its binder (`(forall-cod)`); a sort's sort is never zero;
a constant- or fvar-headed type-former application reads the head's
stored/declared type, peels the arity syntactically and reads the
residual, level-instantiated for a constant.  `none` = unknown. -/
def typeSortPW (find? : Name → Option ConstantInfo) (T : Expr) :
    Option PropWhen :=
  match T with
  | .forallE _ _ m => some m.pw
  | .sort _ => some .never
  | T => headTypePW find? T.getAppFn T.numArgs

/-- The datum of a term's *head* (any arity): a constant head answers
from its stored type (prop-ness is invariant under application), an
fvar head from its declared type; sorts, ∀s and literals are never
proofs. -/
def headProofPW (find? : Name → Option ConstantInfo) : Expr →
    Option PropWhen
  | .const c us =>
    match find? c with
    | some ci =>
      if ci.isTowerEntry then none else
      let cv := ci.toConstantVal
      if us.length = cv.levelParams.length then
        (typeSortPW find? cv.type).map (Level.substPW cv.levelParams us)
      else none
    | none => none
  | .fvar _ ty => typeSortPW find? ty
  | .sort _ | .forallE .. | .lit _ => some .never
  | _ => none

/-- The zero-ness datum of the sort of the *type* of `a` ("is `a` a
proof?"), read off `a`'s head symbol at any arity: a constant or fvar
head answers from its stored/declared type; an unapplied λ answers from
its own datum (the zero-ness of the sort of the body's type,
`(lam-cod-leaf)`); sorts, ∀s and literals are never proofs.  `none` =
unknown. -/
def proofPW (find? : Name → Option ConstantInfo) (a : Expr) :
    Option PropWhen :=
  match a with
  | .lam _ _ m => some m.pw
  | a => headProofPW find? a.getAppFn

/-- Is the datum "always zero" — the sort is `Prop` at every
valuation? -/
@[inline] def PropWhen.isProp (pw : PropWhen) : Bool :=
  pw == (.ifAllZero [])

/-- **Definitely not a proof** (the no arm): the datum is known and is
not always-zero. -/
def notProofFast (find? : Name → Option ConstantInfo) (a : Expr) : Bool :=
  match proofPW find? a with
  | some pw => !pw.isProp
  | none => false

/-- **Definitely a proof** (the yes arm): the datum is known and
always-zero. -/
def isProofFast (find? : Name → Option ConstantInfo) (a : Expr) : Bool :=
  match proofPW find? a with
  | some pw => pw.isProp
  | none => false

end ConLeche

end -- original EOF public section of ConLeche.Kernel.PropRead
/- END exact source origin ConLeche.Kernel.PropRead -/

/- BEGIN exact source origin ConLeche.Kernel.Basis.Names -/
-- Bundled origin 08, header line 1: module

-- Bundled origin 08, header line 3: public import ConLeche.Kernel.Env

section

/-!
# Basis names

The reserved names of the pinned basis blocks (see `ConLeche.Kernel.Basis`).
-/

namespace ConLeche

open Name (anonymous)

/-- The name of the basis equality type. -/
def eqName : Name := anonymous |>.str "Eq"

/-- The name of the basis equality constructor. -/
def eqReflName : Name := eqName |>.str "refl"

/-- The name `Nat`. -/
def natName : Name := anonymous |>.str "Nat"

/-- The name `Nat.zero`. -/
def natZeroName : Name := natName |>.str "zero"

/-- The name `Nat.succ`. -/
def natSuccName : Name := natName |>.str "succ"

def emptyName : Name := anonymous |>.str "Empty"

/-- The name of the pinned `False` basis type (task #181): the
zero-constructor `Prop`, pinned like `Empty` so that the consistency
corollary about `False` needs no hypothesis about how a stream declares
it. -/
def falseName : Name := anonymous |>.str "False"

/-- The name of the basis quotient type. -/
def quotName : Name := anonymous |>.str "Quot"

/-- The name of the basis quotient constructor. -/
def quotMkName : Name := quotName |>.str "mk"

/-- The name of the basis quotient lift eliminator. -/
def quotLiftName : Name := quotName |>.str "lift"

/-- The name of the basis quotient induction eliminator. -/
def quotIndName : Name := quotName |>.str "ind"

/-- The name of the basis quotient soundness axiom. -/
def quotSoundName : Name := quotName |>.str "sound"

/-! The names of the string-literal support constants (see
`strLitSupported` in `ConLeche.Kernel.Core`).  These are *not* basis
names — the constants are ordinary stream-installed declarations
(inductive blocks and plain definitions); the names are
pinned only so that a string literal knows what it unfolds to
(`strLitToConstructor`), exactly like the `Nat` literal names above. -/

/-- The name `String`. -/
def stringName : Name := anonymous |>.str "String"

/-- The name `String.ofList`. -/
def stringOfListName : Name := stringName.str "ofList"

/-- The name `List`. -/
def listName : Name := anonymous |>.str "List"

/-- The name `List.nil`. -/
def listNilName : Name := listName.str "nil"

/-- The name `List.cons`. -/
def listConsName : Name := listName.str "cons"

/-- The name `Char`. -/
def charName : Name := anonymous |>.str "Char"

/-- The name `And`: the one propositional structure whose recursor is
rescued on a stuck proof (`majorToCtor`'s `And` branch,
`ConLeche/Kernel/Core.lean`, gated by `andRescueSlots`).  `And` is
pinned (`andPin`, `ConLeche/Kernel/Basis/And.lean`): a record that
declares one of its names and is not the toolchain's block is rejected
(`andPinOk`), the matching block installs through the ordinary
installer, and the built-in prelude supplies it to a stream that does
not declare it — so the name always denotes the toolchain's `And` and
the rescue is always available.  (The rescue's soundness does not rest
on the pin: its certificate is proof irrelevance.) -/
def andName : Name := anonymous |>.str "And"

/-- The name `Char.ofNat`. -/
def charOfNatName : Name := charName.str "ofNat"

/-- Names reserved for the pinned basis blocks; no other declaration
may use them. -/
def reservedBasisNames : List Name :=
  [eqName, eqReflName, eqName.str "rec",
   natName, natZeroName, natSuccName, natName.str "rec",
   emptyName, emptyName.str "rec",
   falseName, falseName.str "rec",
   quotName, quotMkName, quotLiftName, quotIndName, quotSoundName]

/-! ## The tolerated axiom

`sorryAx` is the one axiom the checker tolerates as a *declaration*:
an export declares it whenever the module it came from mentions
`sorry`, whether or not anything uses it, so a stream that merely
DECLARES it must not be turned away.  Its record installs nothing —
there is no set model for `∀ (α : Sort u), Bool → α` and there cannot
be one — and therefore any USE of it is a positively detected
unsupported feature: a decline, at the record that uses it
(`unknownConstError`, `ConLeche/Kernel/Core.lean`).  The name lives
here, at the bottom of the kernel, because the decline is decided
where a constant fails to resolve — inside the inference body. -/

/-- The name `sorryAx`. -/
def sorryAxName : Name := anonymous |>.str "sorryAx"

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Basis.Names
/- END exact source origin ConLeche.Kernel.Basis.Names -/

/- Evaluator extraction: nine complete historical origins are omitted here:
   Basis.Builder, Basis.Eq, Basis.Nat, Basis.Empty, Basis.False, Basis.Quot,
   Basis.And, Canon and Basis. Their exact original sources and omission spans
   remain in SOURCE-OMISSIONS.json; Basis.Names and every reducer body remain. -/

/- BEGIN exact source origin ConLeche.Kernel.CoreDefs -/
-- Bundled origin 18, header line 1: module

-- Bundled origin 18, header line 3: import ConLeche.Kernel.Env
-- Bundled origin 18, header line 4: public import ConLeche.Kernel.PropRead
-- Bundled origin 18, header line 5: import ConLeche.Kernel.Level
-- Bundled origin 18, header line 6: import ConLeche.Kernel.ExprOps
-- Bundled origin 18, header line 7: public import ConLeche.Kernel.Basis

section

/-!
# The checker core's fuel-free helpers

The definitions of the core checker that mention no monad, no
`CoreFns` record and no fuel: the delta step and its readers
(`unfoldDefinition`, `unfoldableHead`, `headHint`, `sameConstHeads`),
the literal shapes and their guards (`natLitToConstructor`,
`natLitSupported`, `strLitToConstructor`, `strLitSupported`,
`rawNatLit?`), the certified `Nat` operations' names, recurrences,
reducts and pins (`natOpNames`, `natDivModNames`, `natOpEquations`,
`natOpResult`, `natOpStoredOk`, …), the structure-η fabrications
(`etaProjs`, `etaFabArgsE`, `andRescueSlots`), the install-time rule
bits (`recRuleBits`, `recRuleK`, `recFireComparands`),
the tower entry's readers (`ProjEntry.fireOk`, `ProjEntry.typeAt`), the
β gate (`betaGateFires`) and the annotation datum's writer
(`annotBinderMeta`).

Split out of `ConLeche/Kernel/Core.lean` at task #305 (prep): a
relational description of the core's moves — a relation over `Expr`
and `Env` — must name these without importing the executable bodies,
and every one of them is exactly what such a relation needs.  The
bodies (`whnfCoreBody`, `whnfBody`, `inferBody`, `defeqBody`,
`annotateBody`, the knot and the fuel constants) stay in `Core.lean`,
which re-exports this module, so every importer of `Core` sees the
names unchanged.  Nothing here was rewritten: the definitions keep
their names, docstrings, attributes and relative order.
-/

namespace ConLeche

/-- Is the expression headed by a stored constructor? -/
def isCtorApp (env : Env) (e : Expr) : Bool :=
  match e.getAppFn with
  | .const c _ =>
    match env.find? c with
    | some (.ctorInfo _ _ _) => true
    | _ => false
  | _ => false

/-- Is a stored inductive's result sort, at the given level
instantiation, provably nonzero (official `is_never_zero`)?  The
official kernel's structure rescue (`to_cnstr_when_structure`)
requires this of the major's type; `majorToCtor`'s structure-η
rescue mirrors it (`Sort u` at a concrete level such as `Unit`'s `1` passes, the
parameter `u` itself does not).  Read off the stored datum: the
instantiated datum is unsatisfiable exactly where the instantiated
sort is never zero. -/
def capsNeverZero (lps : List Name) (us : List Level) (caps : IndCaps) :
    Bool :=
  (Level.substPW lps us caps.sortZ).isNever

/-- Unfold the (application of a) definition at the head, one step.
`none` when the head is not an unfoldable constant.  **Theorems are
opaque to reduction**: a stored `thmInfo` never unfolds, so whether a
declaration type-checks never depends on a theorem's value — this
anticipates https://github.com/leanprover/lean4/pull/14896 (theorems
become opaque to the kernel: `is_delta` stops unfolding them).  The
one known input whose typing needs a theorem to unfold, the arena's
`subject-reduction-redex`, is rejected (an accept-subset of the
reference kernels until that PR lands). -/
def unfoldDefinition (env : Env) (e : Expr) : Option Expr :=
  match e.getAppFn with
  | .const n us =>
    match env.find? n with
    | some (.defnInfo cv value _) =>
      if us.length = cv.levelParams.length then
        some (Expr.mkAppN (value.instantiateLevelParams cv.levelParams us)
          e.getAppArgs)
      else none
    | _ => none
  | _ => none

/-- May the delta step unfold `e`'s head — is it a constant whose
stored declaration carries a value at a matching level-parameter count
(the official kernel's `is_delta`)?  This is the *decision* the lazy
delta step takes; the unfolding itself is materialized only inside the
branch that consumes it (`unfoldDefinition`), never in both slots of a
match scrutinee.  By construction
`unfoldableHead env e = (unfoldDefinition env e).isSome`. -/
def unfoldableHead (env : Env) (e : Expr) : Bool :=
  match e.getAppFn with
  | .const n us =>
    match env.find? n with
    | some (.defnInfo cv _ _) => us.length == cv.levelParams.length
    | _ => false
  | _ => false

/-- The reducibility hint of the constant at the head of `e` (`opaque`
when the head is not a stored definition — a theorem included, which
never unfolds). -/
def headHint (env : Env) (e : Expr) : ReducibilityHint :=
  match e.getAppFn with
  | .const n _ =>
    match env.find? n with
    | some (.defnInfo _ _ hint) => hint
    | _ => .opaque
  | _ => .opaque

/-- Are `a` and `b` applications of the *same* constant (the lazy delta
same-head short-circuit: try level and spine congruence before
unfolding both sides)?  Mirrors the official kernel's
`try_eq_const_app`: both sides must actually be applications. -/
def sameConstHeads : Expr → Expr → Bool
  | .app f₁ _, .app f₂ _ =>
    match f₁.getAppFn, f₂.getAppFn with
    | .const n₁ _, .const n₂ _ => n₁ == n₂
    | _, _ => false
  | _, _ => false

/-- The constructor form of a `Nat` literal, one layer:
`n + 1` becomes `Nat.succ (lit n)`, `0` becomes `Nat.zero` (the
official kernel's `natLitToConstructor`, used on recursor majors). -/
def natLitToConstructor (n : Nat) : Expr :=
  match n with
  | 0 => .const natZeroName []
  | k + 1 => .app (.const natSuccName []) (.lit (.natVal k))

/-- The stored `Nat` declaration has the expected shape. -/
def natIndOk : Option ConstantInfo → Bool
  | some (.indInfo cv _) =>
    cv.levelParams.isEmpty && cv.type == .sort (.succ .zero)
  | _ => false

/-- The stored `Nat.zero` declaration has the expected shape. -/
def natZeroOk : Option ConstantInfo → Bool
  | some (.ctorInfo cv _ _) =>
    cv.levelParams.isEmpty && cv.type == .const natName []
  | _ => false

/-- The stored `Nat.succ` declaration has the expected (annotated)
shape. -/
def natSuccOk : Option ConstantInfo → Bool
  | some (.ctorInfo cv _ _) =>
    cv.levelParams.isEmpty &&
    (match cv.type with
     | .forallE (.const c1 []) (.const c2 []) _mb =>
       c1 == natName && c2 == natName
     | _ => false)
  | _ => false

/-- Whether the environment supports `Nat` literals: `Nat`, `Nat.zero`
and `Nat.succ` are stored with exactly the expected kinds, level
parameters and (annotated) types.  Every literal code path is guarded
on this — the model interprets a literal by iterating the `Nat.succ`
value on the `Nat.zero` value, and the soundness proofs read the
declaration shapes off this guard. -/
def natLitSupported (env : Env) : Bool :=
  natIndOk (env.find? natName) && natZeroOk (env.find? natZeroName) &&
    natSuccOk (env.find? natSuccName)

/-- Do all constants referenced in `e` (including inside `fvar` type
annotations) resolve in `env`?  A `Nat` literal implicitly references
the `Nat` basis constants (and a `String` literal additionally the
string-support constants).  Checked once per declaration; keeps the
environment well-formedness invariant syntactic. -/
def Expr.constsResolve (env : Env) : Expr → Bool
  | .bvar _ | .sort _ => true
  | .lit (.natVal _) =>
    (env.find? natName).isSome && (env.find? natZeroName).isSome &&
      (env.find? natSuccName).isSome
  | .lit (.strVal _) =>
    -- a string literal implicitly references the `Nat` trio (its
    -- character numerals) and the seven string-support constants
    (env.find? natName).isSome && (env.find? natZeroName).isSome &&
      (env.find? natSuccName).isSome && (env.find? stringName).isSome &&
      (env.find? stringOfListName).isSome && (env.find? listName).isSome &&
      (env.find? listNilName).isSome && (env.find? listConsName).isSome &&
      (env.find? charName).isSome && (env.find? charOfNatName).isSome
  | .const n _ => (env.find? n).isSome
  | .fvar _ ty => ty.constsResolve env
  | .app f a => f.constsResolve env && a.constsResolve env
  | .lam ty body _ | .forallE ty body _ =>
    ty.constsResolve env && body.constsResolve env
  | .letE ty val body =>
    ty.constsResolve env && val.constsResolve env && body.constsResolve env
  | .proj s _ e => (env.find? s).isSome && e.constsResolve env

/-- Convert a `Nat`-literal major premise to constructor form, one
layer; anything else passes through. -/
def litToCtorIfNat (env : Env) : Expr → Expr
  | .lit (.natVal n) =>
    if natLitSupported env then natLitToConstructor n else .lit (.natVal n)
  | e => e

/-- A `Nat` literal reading of a whnf'd expression: literals and the
`Nat.zero` constant (the official kernel's `rawNatLitExt?`). -/
def rawNatLit? : Expr → Option Nat
  | .lit (.natVal n) => some n
  | .const c [] => if c = natZeroName then some 0 else none
  | _ => none

/-! ## String literals

A string literal unfolds on demand to `String.ofList [c₁, …, cₙ]` with
each character built by `Char.ofNat` from a `Nat` literal — the
reference kernels' `strLitToConstructor` (lean4lean `Expr.lean`, nanoda
`expr.rs`), mirrored exactly.  The names below are *pinned* like the
`Nat` literal names: the guard `strLitSupported` checks that the stored
declarations have exactly the expected (annotated) types, which is what
the model's interpretation of a string literal reads its meaning off.
A string literal in the input while the guard fails is a positively
detected unsupported feature — annotation *declines* (exit 2). -/

/-- The constructor form of a `String` literal:
`String.ofList (List.cons.{0} Char (Char.ofNat (lit c₁)) (… (List.nil.{0}
Char)))` — the official kernel's `strLitToConstructor`, spelling as in
lean4lean (`Expr.strLitToConstructor`) and nanoda
(`str_lit_to_constructor`). -/
def strLitToConstructor (s : String) : Expr :=
  .app (.const stringOfListName []) <|
    s.toList.foldr
      (init := .app (.const listNilName [.zero]) (.const charName []))
      fun c e =>
        .app (.app (.app (.const listConsName [.zero]) (.const charName []))
          (.app (.const charOfNatName []) (.lit (.natVal c.toNat)))) e

/-- The stored `String` declaration has the expected shape
(`String : Type`, no level parameters; any constant kind). -/
def stringTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      ci.toConstantVal.type == .sort (.succ .zero)
  | none => false

/-- The stored `Char` declaration has the expected shape (`Char : Type`,
no level parameters). -/
def charTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      ci.toConstantVal.type == .sort (.succ .zero)
  | none => false

/-- The stored `List` declaration has the expected (annotated) shape
`List.{p} : Type p → Type p`. -/
def listTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1) (.sort u2) _mb =>
         u1 == .succ (.param p) && u2 == .succ (.param p)
       | _ => false)
    | _ => false
  | none => false

/-- The stored `List.nil` declaration has the expected (annotated) shape
`List.nil.{p} : ∀ (α : Type p), List.{p} α`. -/
def listNilTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1) (.app (.const l1 us1) (.bvar 0)) _mb =>
         u1 == .succ (.param p) && l1 == listName && us1 == [.param p]
       | _ => false)
    | _ => false
  | none => false

/-- The stored `List.cons` declaration has the expected (annotated) shape
`List.cons.{p} : ∀ (α : Type p) (head : α) (tail : List.{p} α),
List.{p} α` (with the codomain-sort annotations the annotation pass
produces on that type). -/
def listConsTyOk : Option ConstantInfo → Bool
  | some ci =>
    match ci.toConstantVal.levelParams with
    | [p] =>
      (match ci.toConstantVal.type with
       | .forallE (.sort u1)
           (.forallE (.bvar 0)
             (.forallE (.app (.const l1 us1) (.bvar 1))
               (.app (.const l2 us2) (.bvar 2)) _mb3) _mb2) _mb1 =>
         u1 == .succ (.param p) && l1 == listName && l2 == listName &&
           us1 == [.param p] && us2 == [.param p]
       | _ => false)
    | _ => false
  | none => false

/-- The stored `Char.ofNat` declaration has the expected (annotated)
shape `Char.ofNat : Nat → Char`. -/
def charOfNatTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      (match ci.toConstantVal.type with
       | .forallE (.const c1 []) (.const c2 []) _mb =>
         c1 == natName && c2 == charName
       | _ => false)
  | none => false

/-- The stored `String.ofList` declaration has the expected (annotated)
shape `String.ofList : List.{0} Char → String`. -/
def stringOfListTyOk : Option ConstantInfo → Bool
  | some ci =>
    ci.toConstantVal.levelParams.isEmpty &&
      (match ci.toConstantVal.type with
       | .forallE (.app (.const l1 us1) (.const c1 [])) (.const c2 []) _mb =>
         l1 == listName && us1 == [.zero] && c1 == charName &&
           c2 == stringName
       | _ => false)
  | none => false

/-- Whether the environment supports `String` literals: the `Nat`
literal guard plus `String`, `String.ofList`, `List`, `List.nil`,
`List.cons`, `Char` and `Char.ofNat` stored with exactly the expected
level parameters and (annotated) types.  Every string-literal code path
is guarded on this; the model interprets a string literal through the
values of these constants, and the soundness proofs read the
declaration shapes off this guard.  (The reference kernels only check
*existence* of `Char.ofNat` and `String.ofList`; the type pins are what
makes the interpretation well-defined, in the spirit of the `Nat`
literal guard.) -/
def strLitSupported (env : Env) : Bool :=
  natLitSupported env &&
    stringTyOk (env.find? stringName) &&
    stringOfListTyOk (env.find? stringOfListName) &&
    listTyOk (env.find? listName) &&
    listNilTyOk (env.find? listNilName) &&
    listConsTyOk (env.find? listConsName) &&
    charTyOk (env.find? charName) &&
    charOfNatTyOk (env.find? charOfNatName)

/-! ## Structural-Nat literal acceleration

The official kernel accelerates the structural `Nat` operations on
literals (GMP-backed there).  Here the fast path is *certified*: an
operation participates only when its defining recurrence equations
hold by definitional equality — checked once, at install: `checkDecl`
positively rejects a nonstandard definition under one of these names,
so *presence in the store is the certificate* (no runtime flag, no
re-checking; a reduction-time re-check would in fact livelock — the
certification's own `pred zero` equation re-enters the fast path).

The certification runs in the environment *before* the operation is
stored, on the equations with the operation's self-references replaced
by its (annotated) definition value (`Expr.substConst0`): running it
after insertion would let the operation's own just-enabled fast path
discharge its all-literal-argument equations (`pred zero ≡ zero`,
`beq zero zero ≡ true`) vacuously — accepting definitions that
disagree with the fast path on those points, which is unsound.  The
install also pins the operation's and its dependencies' types to the
expected `Nat → … → Nat`/`Bool` shapes (`natOpStoredOk`): the model
reads the operations' function-space memberships off these shapes.

The environment model carries the matching semantic clause: a stored
definition under one of these names satisfies its recurrences, from
which meta-level induction over the literal yields the computed
value.  WF-recursive operations (`div`, `mod`, `gcd`) and string
literals are deferred. -/

def natPredName : Name := natName.str "pred"
def natAddName : Name := natName.str "add"
def natSubName : Name := natName.str "sub"
def natMulName : Name := natName.str "mul"
def natPowName : Name := natName.str "pow"
def natBeqName : Name := natName.str "beq"
def natBleName : Name := natName.str "ble"
def natDivName : Name := natName.str "div"
def natModName : Name := natName.str "mod"
def natGcdName : Name := natName.str "gcd"
def natLandName : Name := natName.str "land"
def natLorName : Name := natName.str "lor"
def natXorName : Name := natName.str "xor"
def natShiftLeftName : Name := natName.str "shiftLeft"
def natShiftRightName : Name := natName.str "shiftRight"
def boolName : Name := .str .anonymous "Bool"
def boolTrueName : Name := boolName.str "true"
def boolFalseName : Name := boolName.str "false"

/-- Is `e` the constant `Bool.true` — the official kernel's
`is_constant(e, Bool.true)` (`type_checker.cpp:1097`): the name, no
universe levels. -/
def Expr.isBoolTrue : Expr → Bool
  | .const c [] => c == boolTrueName
  | _ => false

/-- The certified structural-`Nat` operations.  Six of them
(`add sub mul pow beq ble`) carry a literal fast path; `Nat.pred` is
here without one — it has no fast path (official's `reduce_nat` folds
nothing unary but `Nat.succ`), but `Nat.sub`'s recurrence
`sub x (succ y) = pred (sub x y)` names it, so its own recurrences
must be certified for `sub`'s literal fold to be sound. -/
def natOpNames : List Name :=
  [natPredName, natAddName, natSubName, natMulName, natPowName,
   natBeqName, natBleName]

/-- The WF-recursive operations with a *pinned-declaration* certified
fast path: at install, `checkDecl` compares the stream's definition
against a vendored pin of the toolchain's own (helper-unfolded)
definition by definitional equality, and then checks the pinned
`Nat.ble`-guarded characterization certificates
(`ConLeche/Kernel/NatOpPins.lean`) like theorem declarations — without
installing them.  Presence in the store is therefore again the
capability: a stored operation under one of these names has passed pin
and certificates, or the install declined.  (The name is historic:
the family started with `Nat.div`/`Nat.mod` and now covers every
pin-certified WF-recursive kernel-accelerated `Nat` operation —
`Nat.log2` left the list when its fast path did, official folding no
unary operation but `Nat.succ`.) -/
def natDivModNames : List Name :=
  [natDivName, natModName, natGcdName, natLandName, natLorName,
   natXorName, natShiftLeftName, natShiftRightName]

/-! ## The names the environment's own guards look up

`natLitSupported` and `strLitSupported` decide whether a literal may
be READ, and they decide it by looking ten fixed names up in the
store.  Three of them (`Nat`, `Nat.zero`, `Nat.succ`) are reserved
basis names, so no stream declaration can ever fill or change them;
the other seven — `String`, `String.ofList`, `List`, `List.nil`,
`List.cons`, `Char`, `Char.ofNat` — are ORDINARY stream declarations,
and a stream is free to install them (it must: that is how a stream
earns string literals).

What must not happen is a *recursor* taking one of these names.  A
recursor's name is the stream's business, so nothing else stops a block from
declaring, say, a recursor called
`List.cons` of `List.cons`'s type; consing it would flip
`strLitSupported` from `false` to `true` and a string literal would
read as one thing below the block's recursors and as another above
them.  The block install therefore refuses such a name outright
(`blockRecNamesUnreserved`, `ConLeche/Kernel/Inductives/BlockParts.lean`),
which makes both guards CONGRUENT across the recursors' cons
(`strLitSupported_consBlockRecsR`, `ConLeche/Verify/Inductives/BlockWF.lean`)
— the equation the model's reading law needs. -/

/-- The ten names the two literal guards look up: the `Nat` guard's
three and the `String` guard's seven. -/
def litGuardNames : List Name :=
  [natName, natZeroName, natSuccName,
   stringName, stringOfListName, listName, listNilName, listConsName,
   charName, charOfNatName]

/-- **A name no block RECURSOR may take**: one the pinned basis blocks
reserve, one a literal guard looks up, or one of the certified `Nat`
operations (whose presence in the store IS their certificate, so a
recursor stored under such a name would claim a capability nothing
certified).  Type formers and constructors are NOT held to this — a
stream must be able to declare `List`, `List.cons` and `Nat.add` —
which is why the block install spends this predicate on the recursors
alone and keeps `reservedBasisNames` for every declaration. -/
def reservedRecName (n : Name) : Bool :=
  reservedBasisNames.contains n || litGuardNames.contains n ||
    natOpNames.contains n || natDivModNames.contains n

/-- The operations (transitively) involved in `c`'s recurrences. -/
def natOpDeps (c : Name) : List Name :=
  if c = natPredName then [natPredName]
  else if c = natAddName then [natAddName]
  else if c = natSubName then [natPredName, natSubName]
  else if c = natMulName then [natAddName, natMulName]
  else if c = natPowName then [natAddName, natMulName, natPowName]
  else if c = natBeqName then [natBeqName]
  else if c = natBleName then [natBleName]
  else if c = natDivName then [natPredName, natSubName, natBleName, natDivName]
  else if c = natModName then [natPredName, natSubName, natBleName, natModName]
  else if c = natGcdName then [natBleName, natModName, natGcdName]
  else if c = natLandName then
    [natAddName, natMulName, natBleName, natDivName, natModName, natLandName]
  else if c = natLorName then
    [natAddName, natSubName, natMulName, natBleName, natDivName, natModName,
     natLorName]
  else if c = natXorName then
    [natAddName, natMulName, natBleName, natDivName, natModName, natXorName]
  else if c = natShiftLeftName then
    [natSubName, natMulName, natBleName, natShiftLeftName]
  else if c = natShiftRightName then
    [natSubName, natBleName, natDivName, natShiftRightName]
  else []

/-- The defining recurrence equations of a structural-Nat operation,
over constructor forms with free variables `d`, `d + 1` (binder-free,
so the equation sides carry no annotations). -/
def natOpEquations (d : Nat) (c : Name) : List (Expr × Expr) :=
  let natTy : Expr := .const natName []
  let x : Expr := .fvar d natTy
  let y : Expr := .fvar (d + 1) natTy
  let z : Expr := .const natZeroName []
  let s : Expr → Expr := (.app (.const natSuccName []) ·)
  let ap1 : Name → Expr → Expr := fun n a => .app (.const n []) a
  let ap2 : Name → Expr → Expr → Expr := fun n a b =>
    .app (.app (.const n []) a) b
  let bT : Expr := .const boolTrueName []
  let bF : Expr := .const boolFalseName []
  if c = natPredName then
    [(ap1 c z, z), (ap1 c (s x), x)]
  else if c = natAddName then
    [(ap2 c x z, x), (ap2 c x (s y), s (ap2 c x y))]
  else if c = natSubName then
    [(ap2 c x z, x), (ap2 c x (s y), ap1 natPredName (ap2 c x y))]
  else if c = natMulName then
    [(ap2 c x z, z), (ap2 c x (s y), ap2 natAddName (ap2 c x y) x)]
  else if c = natPowName then
    [(ap2 c x z, s z), (ap2 c x (s y), ap2 natMulName (ap2 c x y) x)]
  else if c = natBeqName then
    [(ap2 c z z, bT), (ap2 c z (s y), bF), (ap2 c (s x) z, bF),
     (ap2 c (s x) (s y), ap2 c x y)]
  else if c = natBleName then
    [(ap2 c z y, bT), (ap2 c (s x) z, bF), (ap2 c (s x) (s y), ap2 c x y)]
  else []

/-- The reduct of op `c` on literal arguments (`pred` ignores the
second slot). -/
def natOpResult (c : Name) (a b : Nat) : Option Expr :=
  if c = natPredName then some (.lit (.natVal (a - 1)))
  else if c = natAddName then some (.lit (.natVal (a + b)))
  else if c = natSubName then some (.lit (.natVal (a - b)))
  else if c = natMulName then some (.lit (.natVal (a * b)))
  else if c = natPowName then
    -- the divergence audit's S2: official `reduce_pow` refuses exponents
    -- above `ReducePowMaxExp = 1 << 24` (`type_checker.cpp:616-627`) and
    -- lets `Nat.pow` unfold instead — the blow-up protection, mirrored
    if b > 16777216 then none else some (.lit (.natVal (a ^ b)))
  else if c = natDivName then some (.lit (.natVal (a / b)))
  else if c = natModName then some (.lit (.natVal (a % b)))
  else if c = natGcdName then some (.lit (.natVal (Nat.gcd a b)))
  else if c = natLandName then some (.lit (.natVal (Nat.land a b)))
  else if c = natLorName then some (.lit (.natVal (Nat.lor a b)))
  else if c = natXorName then some (.lit (.natVal (Nat.xor a b)))
  else if c = natShiftLeftName then
    some (.lit (.natVal (Nat.shiftLeft a b)))
  else if c = natShiftRightName then
    some (.lit (.natVal (Nat.shiftRight a b)))
  else if c = natBeqName then
    some (.const (if a = b then boolTrueName else boolFalseName) [])
  else if c = natBleName then
    some (.const (if a <= b then boolTrueName else boolFalseName) [])
  else none

/-- Stored-constant guards for op `c`: the `Nat` basis, every
dependency stored as a definition, and (for the `Bool`-valued ops and
the `ble`-guarded `div`/`mod`, whose semantic clauses mention the
`Bool` constructor values) the `Bool` constructors stored. -/
def natOpGuard (env : Env) (c : Name) : Bool :=
  natLitSupported env &&
  (natOpDeps c).all (fun n => match env.find? n with
    | some (.defnInfo cv _ _) => cv.levelParams.isEmpty
    | _ => false) &&
  (if c = natBeqName || c = natBleName || natDivModNames.contains c then
    (match env.find? boolTrueName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false) &&
    (match env.find? boolFalseName with
      | some ci => ci.toConstantVal.levelParams.isEmpty
      | none => false)
   else true)

/-- The pin-certified WF-recursive `Nat` operations, as a *safety
net*: the preceding certified branches normally intercept literal
applications, so this list only fires when a capability is absent
(op not stored, or a dependency missing — a mismatching declaration
already declined at install); such a *literal application* is then
positively declined (arena exit 2) rather than ground unary through
the fuel recursion.  Declaring the functions themselves is
unaffected: only the reduction path declines. -/
def natOpWfNames : List Name :=
  [natDivName, natModName, natGcdName, natLandName, natLorName,
   natXorName, natShiftLeftName, natShiftRightName]

/-- Substitute the level-monomorphic constant `n` by `r` through an
application spine (the certification equations' self-references; the
equation sides are binder-free, so only `app` recurses). -/
def Expr.substConst0 (n : Name) (r : Expr) : Expr → Expr
  | .const c us => if c = n ∧ us = [] then r else .const c us
  | .app f a => .app (Expr.substConst0 n r f) (Expr.substConst0 n r a)
  | e => e

/-- Substitute the level-monomorphic constant `n` by the *closed* term
`r` everywhere, including under binders (the div/mod certificate
statements' and proofs' references to the pinned operation; `r` being
closed, no lifting is needed).  `fvar` annotations are not entered:
the substitution runs on closed input terms only. -/
def Expr.substConstAll (n : Name) (r : Expr) : Expr → Expr
  | .const c us => if c = n ∧ us = [] then r else .const c us
  | .app f a => .app (Expr.substConstAll n r f) (Expr.substConstAll n r a)
  | .lam ty b mb =>
    .lam (Expr.substConstAll n r ty) (Expr.substConstAll n r b) mb
  | .forallE ty b mb =>
    .forallE (Expr.substConstAll n r ty) (Expr.substConstAll n r b) mb
  | .letE ty v b =>
    .letE (Expr.substConstAll n r ty) (Expr.substConstAll n r v)
      (Expr.substConstAll n r b)
  | .proj s i e => .proj s i (Expr.substConstAll n r e)
  | e => e

/-- The pinned codomain of a structural-Nat operation: `Bool` (itself
stored level-monomorphically at type `Sort 1`) for the comparisons,
`Nat` otherwise. -/
def natOpCod (env : Env) (c : Name) (e : Expr) : Bool :=
  if c = natBeqName || c = natBleName then
    e == .const boolName [] &&
    (match env.find? boolName with
     | some ci => ci.toConstantVal.levelParams.isEmpty &&
         ci.toConstantVal.type == .sort (.succ .zero)
     | none => false)
  else e == .const natName []

/-- The pinned type of a certified `Nat` operation:
`Nat → Nat` for the unary `pred`, `Nat → Nat → Nat` for the arithmetic
operations, `Nat → Nat → Bool` for the comparisons.  The model reads
the operations' function-space memberships off this shape. -/
def natOpTyPinned (env : Env) (c : Name) (ty : Expr) : Bool :=
  if c = natPredName then
    match ty with
    | .forallE dom body _mb =>
      dom == .const natName [] && natOpCod env c body
    | _ => false
  else
    match ty with
    | .forallE dom (.forallE dom2 body _mb2) _mb =>
      dom == .const natName [] && dom2 == .const natName [] &&
      natOpCod env c body
    | _ => false

/-- Op `n` is stored as a level-monomorphic definition with the pinned
type. -/
def natOpStoredOk (env : Env) (n : Name) : Bool :=
  match env.find? n with
  | some (.defnInfo cv _ _) =>
    cv.levelParams.isEmpty && natOpTyPinned env n cv.type
  | _ => false

/-- **The reduction-time test for a certified `Nat` operation** (task
#161 de-gating round A+B+C, item B3; harvest site 37, list entry P7):
is `c` stored as a definition at all?

`reduceNat` used to re-derive the whole `natOpGuard` at every literal
hit — `natLitSupported` (three `Env.find?`s), a `natOpDeps c` list
build plus a lookup per dependency (up to seven), and two more lookups
for the `Bool` constructors.  That conclusion is *carried by the
install fold invariant*, for every one
of the sixteen guarded names: `NatOps` (the seven structural
ops, `natOpNames`) and `DivMod` (the nine WF-pinned ops,
`natDivModNames`) both read

  `env.find? c = some (.defnInfo cv v hint) → natOpGuard env c = true ∧ …`

and `checkDecl` is what establishes them: it *declines* a stream that
stores one of these names without `natOpGuard env₂ c` (Checker.lean's
`.defnDecl` clause).  The converse is by computation — `c ∈ natOpDeps
c` for all sixteen — so on every environment the checker builds the two
tests agree, and the cheap one is a single `find?`. -/
def natOpStored (env : Env) (c : Name) : Bool :=
  match env.find? c with
  | some (.defnInfo _ _ _) => true
  | _ => false

/-- Peel a `∀`-telescope along an argument list (the residual type of
a fully applied telescope). -/
def piResidual : Expr → List Expr → Option Expr
  | e, [] => some e
  | .forallE _ b _, a :: as => piResidual (b.instantiate1 a) as
  | _, _ :: _ => none

/-- Are all `nF` projection slots of `T` table entries — i.e. does
`T`'s projection table exist and cover them?  (Task #175 tower-flag:
a stored table always carries bodies, so "the entry exists" is the
whole test.) -/
def towerSlotsAll (env : Env) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j => (env.findProj? T j).isSome

/-- Are all `nF` projection slots of `T` recursor-backed projection
functions?  With `towerSlotsAll` the eta
certificate's slot discipline: a family's slots are all of one kind,
so the fabricated spine and the per-slot certificates agree. -/
def recSlotsAll (env : Env) (T : Name) (nF : Nat) : Bool :=
  (List.range nF).all fun j =>
    match env.find? (projFnName T j) with
    | some (.recInfo _ _ _ _) => true
    | _ => false

/-- The fabricated projections of a structure-eta spine (task #175
W4c): `.proj T j b` nodes when every slot has a table entry (the
direct install's structures — the node is what the table types and
reduces), else projection-function applications. -/
def etaProjs (env : Env) (T : Name) (us : List Level) (targs : List Expr)
    (b : Expr) (nF : Nat) : List Expr :=
  if towerSlotsAll env T nF then
    (List.range nF).map fun j => Expr.proj T j b
  else
    (List.range nF).map fun j =>
      Expr.mkAppN (.const (projFnName T j) us) (targs ++ [b])

/-- The constructor shape official's `try_eta_struct_core` tests before
inferring anything (`type_checker.cpp:824-829`): the candidate's head is
a stored constructor applied to exactly its parameters and fields.
(`structEtaCertWith` re-reads the same head; this is the gate that
keeps the inferences behind it.) -/
def etaCtorShape (env : Env) (a : Expr) : Bool :=
  match a.getAppFn with
  | .const c _ =>
    match env.find? c with
    | some (.ctorInfo _ cnP cnF) => a.getAppArgs.length == cnP + cnF
    | _ => false
  | _ => false

/-- The eta-rescue fabrication's argument spine (task #175 W4c): the projections
are `etaProjs`' — `.proj` nodes at an all-tower slot family,
projection-function applications otherwise. -/
def etaFabArgsE (env : Env) (T : Name) (ust : List Level)
    (targs : List Expr) (major : Expr) (nF : Nat) : List Expr :=
  targs ++ etaProjs env T ust targs major nF

/-- **The tower-fire guard** (task #175 W4c/O4, restated at W6):
`whnfCore` fires the structural rule `proj_i (ctor p⃗ x⃗) ↦ x_i` at a
tower-backed entry under exactly the guard the tower infer branch
types the node with — at a `Prop`-declared structure the field's guard
level must be a proposition at this instantiation; at every other
family the rule fires unconditionally.

A guard "the structure's sort is provably nonzero at this
instantiation" is *not* what the official kernel does (`reduce_proj`
reduces every constructor redex): it rejects
`PSigma'.fst (PSigma'.mk a b) ≡ a` at symbolic `u v`, where `max u v`
is neither provably zero nor nonzero.  The model licence: at a squash
instance (the structure's
sort is `0` at the valuation) the constructor application reads as
the point, and so does the selected field — for a non-`Prop`-declared
family every field's sort is bounded by the structure's (the O5 bound
`checkStructFieldSortsI` checks), so at a zero instantiation every
field is a proposition; for a `Prop`-declared family the guard says
so of the projected field directly (`TowerEntryLaw`'s iota clause,
`ConLeche/Model/Annot/EnvModelM.lean`).  Ungated rules on a data field of a
`Prop`-declared structure stay out: such a node is not even typed
(`inferBody`'s guard). -/
def ProjEntry.fireOk (entry : ProjEntry) (us : List Level) : Bool :=
  !(Level.isEquiv entry.structSort .zero == some true) ||
    (Level.isEquiv (Level.subst entry.levelParams us entry.fieldSort) .zero
      == some true)

/-- **`And`'s projection slots, ready to fire**: the two
tower entries of `And` are stored, name the rule's constructor at the
major's parameter count, and their `Prop` guards pass at the levels
`ust` (`ProjEntry.fireOk`: `And`'s fields are propositions, so a
`.proj And j h` node is typed by the tower infer branch).  The gate of
`majorToCtor`'s `And` branch; abstracted over the lookup so the
indexed twin (`FEnv.andRescueSlotsF`) shares the body. -/
def andRescueSlotsOf (findProj? : Name → Nat → Option ProjEntry)
    (ctor : Name) (nP : Nat) (ust : List Level) : Bool :=
  (List.range 2).all fun j =>
    match findProj? andName j with
    | some e => e.ctor == ctor && e.numParams == nP && e.numFields == 2 &&
        e.fireOk ust
    | none => false

/-- `andRescueSlotsOf` at the plain environment. -/
def andRescueSlots (env : Env) (ctor : Name) (nP : Nat) (ust : List Level) : Bool :=
  andRescueSlotsOf env.findProj? ctor nP ust

/-- **The K bit at install** (`RecRule.k`): the rule's constructor has
no fields and belongs to an inductive stored with the K capability (an
inductive proposition).  Together with the recursor's rule list being
a singleton — which the reader `recRuleK` and `majorToCtor` match on
— this is the official kernel's `recursor_val::is_k()`.  Abstracted
over the lookup so the interned twin (`FEnv.find?`) shares the body. -/
def recRuleKOf (find? : Name → Option ConstantInfo) (ctor : Name) : Bool :=
  match find? ctor with
  | some (.ctorInfo cvj _ cnF) =>
    match (cvj.type.piResult).getAppFn with
    | .const T _ =>
      match find? T with
      | some (.indInfo _ caps) => caps.ruleK && cnF == 0
      | _ => false
    | _ => false
  | _ => false

/-- **The η-rescue bit at install** (`RecRule.eta`): the rule's
constructor is the η constructor of a stored η-capable inductive,
carries that inductive's own level parameters, and the recursor is not
itself a projection function (whose rescue would reduce to its own
reduct and loop).  Together with the singleton rule list this is the
standing condition of `majorToCtor`'s structure-η rescue.

The level-parameter conjunct is what lets the rescue fabricate the
constructor application at the major type's levels without comparing
the two lists per call: the installer grants η only at a
constructor stored with the former's level parameters (the
recogniser pins `c.1.levelParams == lps`), so the conjunct holds
wherever the rest does. -/
def recRuleEtaOf (find? : Name → Option ConstantInfo) (recName ctor : Name) :
    Bool :=
  match find? ctor with
  | some (.ctorInfo cvj _ _) =>
    match (cvj.type.piResult).getAppFn with
    | .const T _ =>
      match find? T with
      | some (.indInfo cvT caps) =>
        caps.eta && caps.etaCtor == ctor && !Name.isProjFnShape recName &&
          cvj.levelParams == cvT.levelParams
      | _ => false
    | _ => false
  | _ => false

/-- **Stamp a rule's two rescue bits at install** — the one place the
K and η-rescue conditions are decided.  Every rule is stored
through this (the pinned basis blocks, the installer's generated
rules, the projection functions):
the reduction then reads `RecRule.k`/`RecRule.eta` and re-derives
nothing, and the environment invariant `RecCtorsStored` records that a
set bit is the lookup's own verdict. -/
def recRuleBits (find? : Name → Option ConstantInfo) (recName : Name)
    (rl : RecRule) : RecRule :=
  { rl with k := recRuleKOf find? rl.ctor,
            eta := recRuleEtaOf find? recName rl.ctor }

@[simp] theorem recRuleBits_ctor (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).ctor
      = rl.ctor := rfl

@[simp] theorem recRuleBits_rhs (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).rhs
      = rl.rhs := rfl

@[simp] theorem recRuleBits_nfields (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).nfields
      = rl.nfields := rfl

@[simp] theorem recRuleBits_ctorParams (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) :
    (recRuleBits find? recName rl).ctorParams = rl.ctorParams := rfl

@[simp] theorem recRuleBits_fire (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).fire
      = rl.fire := rfl

@[simp] theorem recRuleBits_k (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).k
      = recRuleKOf find? rl.ctor := rfl

@[simp] theorem recRuleBits_paramsBlind (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) :
    (recRuleBits find? recName rl).paramsBlind = rl.paramsBlind := rfl

@[simp] theorem recRuleBits_eta (find? : Name → Option ConstantInfo)
    (recName : Name) (rl : RecRule) : (recRuleBits find? recName rl).eta
      = recRuleEtaOf find? recName rl.ctor := rfl

@[simp] theorem map_ctor_recRuleBits (find? : Name → Option ConstantInfo)
    (recName : Name) (rs : List RecRule) :
    (rs.map (recRuleBits find? recName)).map (·.ctor) = rs.map (·.ctor) := by
  simp [List.map_map, Function.comp_def]

/-- Is a recursor K-flagged?  The stored bit of its single rule
(`RecRule.k`, computed at the block's install by `recRuleKOf`); the
official kernel reads `recursor_val::is_k()` here in just the same
way. -/
def recRuleK (rules : List RecRule) : Bool :=
  match rules with
  | [rl] => rl.k
  | _ => false

/-- The level and constructor-parameter comparands a firing rule's
checks compare the major's constructor levels and parameters against:
for a canonical (`.plain`) rule the constructor's levels link to the
recursor's by name and its parameters are the recursor's leading
arguments; for a certified nested (`.nested`) rule both are the stored
major-domain instantiations, at the recursor's level instantiation and
(for the parameters) instantiated at the recursor's leading-argument
spine (the stored pins live in the `rP`-binder prefix context — index
arguments never occur in them, by the shape certification).
(Junk for `.inert` rules — `iotaRec` declines before reading it.) -/
def recFireComparands (rl : RecRule) (lps : List Name)
    (us : List Level) (cvjLps : List Name) (args : List Expr)
    (rP : Nat) : List Level × List Expr :=
  match rl.fire with
  | .nested lvls pins =>
    (lvls.map (Level.subst lps us),
     pins.map fun p => Expr.instSpine (args.take rP) (rP - 1)
       (p.instantiateLevelParams lps us))
  | _ =>
    (cvjLps.map fun p => Level.subst lps us (.param p),
     args.take rl.ctorParams)

/-- **The type of a `.proj` node at a tower-backed entry** (task #175
S1): the stored body `F_i[p⃗ ↦ bvars, f_j ↦ .proj T j (bvar 0)]`,
level-instantiated at the subject type's levels, with the subject
type's arguments and the subject substituted for its `numParams + 1`
loose variables in ONE traversal (`instantiateList`: `bvar 0` is the
subject, `bvar (numParams - k)` parameter `k`). -/
def ProjEntry.typeAt (entry : ProjEntry) (us : List Level) (targs : List Expr)
    (pe : Expr) : Expr :=
  (entry.body.instantiateLevelParams entry.levelParams us).instantiateList
    (pe :: targs.reverse)

/-- **THE β SITE'S GATE** (task #161): does the mode's β gate fire at
this binder?

At `mode.betaGate` (i.e. at `.verified`, and nowhere else) a λ-binder
whose *validated* annotation datum is `.never` — "the codomain sort is
nonzero at every valuation" — licenses skipping the certificate: the
`Red.betaGate` rule's soundness (`Red.betaGate_sound`,
`ConLeche/Model/Rules/RedSound.lean`) derives the domain membership from the
redex's own `WellDenoted` slot and consumes no certificate at all.

At a possibly-zero datum, and at every non-gated mode, the certificate
runs unconditionally — the establishment/consumption asymmetry fence,
and task #100's de-gating ruling, both untouched: *that* gate read a
**computed** nonzero sort (unsound-to-model under the domain-relative
collapse); this one reads a **validated annotation**.

Both arms hand back the same reduct, so reducts stay
annotation-blind; the dead-branch collapse is `betaGateFires_off`
(`Verify/BetaGate.lean`).

The gate is a **pure early return**, not a wrapper around the test's
`Bool`, and that shape is load-bearing: the `else` arm is then the
pre-gate clause *byte-for-byte*, so every existing proof of every
non-gated mode continues verbatim after one `simp only` on the
condition.  (A wrapper around the test would have re-associated the
certificate's binds and cost every site a `bind_assoc` as well.)

`betaGateFires` is deliberately mode-and-datum only — it reads no
expression and runs no computation, so it is decidable *before* the
certificate would have started, which is the whole performance
point. -/
@[inline] def betaGateFires (mode : CheckMode) (pw : PropWhen) : Bool :=
  mode.betaGate && pw.isNever

/-- Is this datum a real (non-placeholder) input annotation? -/
@[inline] def pwWritten (pw : PropWhen) : Bool := !pw.isNever

/-- The datum a rebuilt binder ends up with: the one threaded in from
the node below (the chain rule), unless it carries a real input
annotation — those are judged by validation, never overwritten. -/
def annotBinderMeta (pw? : Option PropWhen) (mb : BinderMeta) : BinderMeta :=
  match pw? with
  | some pw => if pwWritten mb.pw then mb else ⟨pw⟩
  | none => mb

end ConLeche

end -- original EOF public section of ConLeche.Kernel.CoreDefs
/- END exact source origin ConLeche.Kernel.CoreDefs -/

/- BEGIN exact source origin ConLeche.Kernel.Core -/
-- Bundled origin 19, header line 1: module

-- Bundled origin 19, header line 3: import ConLeche.Kernel.Level
-- Bundled origin 19, header line 4: import ConLeche.Kernel.ExprOps
-- Bundled origin 19, header line 5: public import ConLeche.Kernel.CoreDefs

section

/-!
# The checker core, in open-recursion style

Every core function is written **once**, as a non-recursive *body*
parameterized over a record of the mutually recursive entry points
(`CoreFns`) and polymorphic in the monad.  All recursion is routed
through the record — bodies never call themselves, and the few helpers
that do recurse (`iotaCerts`, `defEqList`, `structEtaProjCerts`) do so
structurally on a list.  Fuel lives only in the *knots* that tie the
record: the pure knot (`ConLeche.Kernel.TypeChecker`) instantiates the
bodies at `CheckM` and is the verification's subject; the cached knot
(`ConLeche.Cached.CoreC`) instantiates them over the cached
representation with the memo caches and is what the checker executes.
A refinement bridge relates the two (see DESIGN.md).

The reduction loop follows the official kernel (`whnfCore` never
delta-unfolds; `whnf` iterates `whnfCore → reduceNat → unfold one
definition`), and definitional equality starts with the syntactic fast
path and tries proof irrelevance before structural congruence.
Inference re-checks the application argument and the λ-annotation: the
soundness claims re-derive their membership slots from those checks at
their own fuel.  The official kernel's *infer-only* mode is deferred
until the refinement bridge's fuel-determinism machinery lands
(DESIGN.md).

Verification: `ConLeche.Model.*` and `ConLeche.Verify.*` (claims),
`ConLeche.Verify.*` (inversions), both stated against the bodies with
hypotheses about the record and discharged by one induction at the
knot.

The core's **fuel-free helpers** — everything a body reads that
mentions no monad, no record and no fuel (`unfoldDefinition`, the
literal guards, the certified `Nat` operations' tables, the η
fabrications, the install-time rule bits, `betaGateFires`, …) — live
in `ConLeche/Kernel/CoreDefs.lean` since task #305 (prep) and are
re-exported here, so that a relational description of the core's
moves can name them without importing the bodies.
-/

namespace ConLeche

-- Compatibility edits: explicit universe and liftFueled type binders.
universe u

/-- **The verdict of a failure, everywhere in the binary** — the one
error type the whole accept path reports (task #295): the kernel's
steps, the fold, and the frontend's parse and prelude alike.  The
three cases are the three verdicts the driver exits with
(`CheckError.exitCode`, `Main.lean`): 2 declined, 1 rejected, 3 an
error of unclear cause or a malformed input.

Where a failure has a POSITION the type is `CheckError × Nat`, and the
`Nat` is read in the step's own unit: the input's LINE number in the
frontend (`ConLeche/Frontend/Export.lean`; 0 where no line is meant,
as in the size guard, which refuses the input before reading it) and
the record's position in the list the fold folds
(`ConLeche.Cached.checkDecls`).  The two are in the same type because
the driver chains the steps, and the main corollary states that chain
(`ConLeche/MainTheorem.lean`). -/
inductive CheckError where
  | notImplemented (what : String)
  | invalid (msg : String)
  | internal (msg : String)
  -- Presentation-only slice: unused Repr deriving request omitted.

instance : ToString CheckError where
  toString
    | .notImplemented what => s!"not implemented yet: {what}"
    | .invalid msg => s!"invalid: {msg}"
    | .internal msg => s!"internal error: {msg}"

abbrev CheckM := Except CheckError

/-- **The verdict at a constant the environment does not know.**

`sorryAx` is the one axiom the checker tolerates as a *declaration*
and installs nothing for (`sorryAxName`,
`ConLeche/Kernel/Basis/Names.lean`): an export declares it whenever
its module mentions `sorry`, so the record is skipped and the stream
goes on — but there is no set model for it, so a *use* is a
positively detected unsupported feature and the run DECLINES, at the
record that uses it.  Every other unresolved name is a malformed
stream: a REJECT, with the message unchanged.

This is the choke point, because the guard that keeps unresolved
constants out of stored terms (`Expr.constsResolve`) runs *after* the
annotation pass, and annotation infers every binder domain's sort —
so a `sorryAx` in a domain reaches inference first.  Its companion
`unresolvedConstsError` (`ConLeche/Kernel/CheckerBase.lean`) decides
the same question at the guard, for the `sorryAx` occurrences
inference never reaches. -/
def unknownConstError (n : Name) : CheckError :=
  if n = sorryAxName then .notImplemented "use of the sorryAx axiom"
  else .invalid s!"unknown constant {n}"

/-- **Could official's `infer_proj` type `.proj sn i _` at a subject
of type `T a⃗` where we store no projection table for `T`?**  Only at a
single-constructor inductive `T` named by the node, applied to MORE
arguments than its parameters (official's premise is `#ctors = 1` and
`#args = nparams + nindices`, so indices are allowed), at a field index
below the constructor's field count: an INDEXED structure-like type,
where official projects and we store no table (the installer stores
one at every index-free single-constructor member and only there,
`checkBlockTables`).  Every other shape official rejects
(`invalid_proj_exception`): a head that is no inductive (an axiom, an
opaque, `Quot`), a constructor count other than one, a node naming
another type, a field index beyond the fields (`PUnit`, `Eq`: no
fields; an index-free one-constructor type always has a table). -/
def projIndexedStructLike (find? : Name → Option ConstantInfo) (T sn : Name)
    (i nArgs : Nat) : Bool :=
  T == sn &&
    match find? T with
    | some (.indInfo _ caps) =>
      match caps.ctors with
      | [c] =>
        caps.nparams < nArgs &&
          match find? c with
          | some (.ctorInfo _ _ nF) => decide (i < nF)
          | _ => false
      | _ => false
    | _ => false

/-- **The verdict at a `.proj sn i _` whose subject type is headed by
the constant `T` (applied to `nArgs` arguments) and has no
projection-table entry at field `i`** (`hasTable`: whether `T` has a
table at all).  A table without field `i` is an out-of-range index; a
positively detected indexed structure-like type (`projIndexedStructLike`)
is the one shape official accepts and we do not support (DECLINE, on
purpose: https://github.com/leanprover/lean4/issues/14977 removes
projections from indexed inductives); everything else rejects. -/
def projMissError (find? : Name → Option ConstantInfo) (hasTable : Bool)
    (T sn : Name) (i nArgs : Nat) : CheckError :=
  if hasTable then .invalid "projection index out of range"
  else if projIndexedStructLike find? T sn i nArgs then
    .notImplemented "projection on an indexed structure-like type"
  else .invalid "invalid projection: not a structure-like type, or no such field"

/-- The record of mutually recursive core entry points.  `whnfCore`
computes a head normal form without delta — its first argument is the
official kernel's `cheap_proj` flag (`whnfCoreBody`); `whnf` is the full reduction
loop; `infer` is type inference;
`defeq` is definitional equality; `annotate` computes binder
annotations (and is the one place typing is checked). -/
structure CoreFns (m : Type → Type u) where
  whnfCore : Bool → Nat → Expr → m Expr
  whnf : Nat → Expr → m Expr
  infer : Nat → Expr → m Expr
  defeq : Nat → Expr → Expr → m Bool
  annotate : Nat → Expr → m Expr
  /-- Type inference at the **infer-only grade** (task #170): the
  official kernel's `infer_type_core(e, infer_only = true)`, the entry
  every *internal* inference call site uses — a subject that already
  carries a validated annotation invariant (`WellDenotedV` in the P
  claims) is re-inferred without re-establishing it.  The knot decides
  the grade's meaning per mode: at a gate-off mode (`μ.betaGate =
  false`) this is the full `infer`, verbatim (the flag is ignored,
  task #170's R clause); at the gated mode (`.verified`, the P core)
  it is the io body, whose application clause skips the per-argument
  certificate at a `.never` binder under the graph-regime license
  (`ConLeche/Model/IOLicense.lean`).  The **shipped** trusted core
  selects the io body too (`CheckMode.ioGate` is `true` at both
  modes, the licence ruling of 2026-09-06); this mode-parametric
  spelling is not the thing that ships, so `μ.betaGate` here stays the
  P tier's own bit, and the two agree at `.verified`. -/
  inferIO : Nat → Expr → m Expr

/- Pure-only declaration ConLeche.CoreFns.ioView omitted in this cached pilot owner. -/

section Bodies

variable {m : Type → Type} [Monad m] [MonadExceptOf CheckError m]

/- The mode setting (`CheckMode`, `ConLeche/Kernel/Env.lean`):
definitions below that mention `mode` take it as their first explicit
argument (after the monad instances). -/
variable (mode : CheckMode)

/-- Lift a fuel-style partial result.  Its only client is the level
comparison (`Level.leq`/`isEquiv`), whose `none` is its fuel running out
(`Level.defaultFuel`) — OUR resource limit, so a DECLINE (exit 2), never
a verdict (charter item 9).  Every check that REQUIRES a comparison between two
levels neither of which is `zero` goes through here, so an exhausted
comparison cannot read as "not equivalent".  (A comparison against
`zero` cannot misread: `simplify` sends every always-zero level to
`zero`, and `isEquiv` answers `true` on that fast path, so its `none`
only ever stands for a true "no".) -/
def liftFueled {α : Type} (what : String) : Option α → m α
  | some a => pure a
  | none => throw (.notImplemented s!"resource limit: fuel exhausted: {what}")

/- Pure-only declaration ConLeche.reduceNat omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.iotaCerts omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.defEqList omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.iotaIndexOk omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.proofIrrel omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.propIrrel omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.structEtaProjCerts omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.structEtaCertWith omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.structEtaCert omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.structUnitCert omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.etaCert omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.stuckIrrel omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.majorToCtor omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.litMajorToCtor omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.projLitToCtor omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.prepareMajor omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.iotaRec omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.projCert omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.projCertAt omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.reduceProjCore omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.whnfCoreBody omitted in this cached pilot owner. -/

/-- Step budget of the `whnfCore` head-normalization loop (task #106).
Beta, iota and projection steps are *iteration*: the interned
`whnfCoreLoopI` runs them on this budget instead of charging each step
to the shared recursion-depth budget (and to the native stack).  The
`Expr`-level specification below stays chained — the refinement bridge
reproduces a loop run by the chained recursion *at some knot fuel*
(`ConLeche/Verify/BetaSpine.lean`), so the specification and everything
above it are unchanged. -/
@[irreducible] def whnfCoreLoopFuel : Nat := 1000000

/-- Step budget of the `whnf` reduction loop (lean4lean's
`FuelConfig.whnf`, same value).  Literal-acceleration and delta steps
are *iteration*, not recursion: the official kernel's loop is a
`while (true)` and lean4lean's is a fixed-fuel local loop.  Task #106:
routing them through the knot instead charged every unfolding step to
the shared *recursion depth* budget (and to the native stack), so a
long-but-perfectly-ordinary unfolding chain exhausted `checkFuel`. -/
@[irreducible] def whnfLoopFuel : Nat := 100000

/- Pure-only declaration ConLeche.whnfStep omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.whnfLoop omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.whnfBody omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.ensureSort omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.inferBody omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.inferBodyIO omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.boolTrueShortcut omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.defeqSpine omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.quickDefEq omitted in this cached pilot owner. -/

/-- `Nat.zero` or the literal `0` (official `is_nat_zero`). -/
def Expr.isNatZero : Expr → Bool
  | .lit (.natVal 0) => true
  | .const c [] => c == natZeroName
  | _ => false

/-- Is `e` a literal? -/
def Expr.isLit : Expr → Bool
  | .lit _ => true
  | _ => false

/-- The predecessor of a successor form (official `is_nat_succ`): a
nonzero literal, or `Nat.succ x`. -/
def Expr.natPred? : Expr → Option Expr
  | .lit (.natVal (n + 1)) => some (.lit (.natVal n))
  | .app (.const c []) x => if c = natSuccName then some x else none
  | _ => none

/- Pure-only declaration ConLeche.defeqOffset omitted in this cached pilot owner. -/

/-- Is the head of the application spine a projection? -/
def Expr.headIsProj (e : Expr) : Bool :=
  match e.getAppFn with
  | .proj _ _ _ => true
  | _ => false

/- Pure-only declaration ConLeche.tryUnfoldProjApp omitted in this cached pilot owner. -/

/-- The outcome of one lazy-delta step (official `reduction_status`):
continue with the reduced pair, or a verdict, or "neither side
unfolds". -/
inductive DeltaStep where
  | cont (a b : Expr)
  | eq
  | diff
  | unknown

/- Pure-only declaration ConLeche.deltaQuick omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.lazyDeltaStep omitted in this cached pilot owner. -/

/-- The outcome of the lazy-delta loop: a verdict, or the pair it got
stuck on (official `lazy_delta_reduction` returns `l_undef` and updates
`t_n`, `s_n`). -/
inductive LazyRes where
  | verdict (v : Bool)
  | unknown (a b : Expr)

/-- Step budget of the two lazy-delta loops (lean4lean's
`FuelConfig.lazyDelta`, generously sized).  Exhaustion is an internal
error, never a verdict. -/
@[irreducible] def defeqLoopFuel : Nat := 100000

/- Pure-only declaration ConLeche.lazyDeltaReduction omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.lazyDeltaProjReduction omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.defeqProjPair omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.defeqStuck omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.defeqBody omitted in this cached pilot owner. -/

/-! ### The untrusted annotation writes (task #161 P5)

The pass is the existing normalizer: at the verified modes its ∀/λ
clauses *write* the `pw` datum the front door then *validates*.  The
write is untrusted by design — a wrong datum declines, never
unsoundness — and it is a no-op wherever the input already carries a
non-placeholder annotation (`pwWritten`): explicit input annotations
are judged by validation, never overwritten.  The parser's placeholder
for an absent `"pw"` field is `.never`, which is also a legitimate
value; the pass therefore recomputes over `.never` unconditionally
(harmless: a genuinely never-zero codomain recomputes to `.never`),
and the *only* input annotations preserved are the `ifAllZero` ones.
-/

/- Pure-only declaration ConLeche.annotPwPi omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.annotPwLam omitted in this cached pilot owner. -/

/- Pure-only declaration ConLeche.annotateBody omitted in this cached pilot owner. -/

end Bodies

/- Pure-only declaration ConLeche.coreKnot omitted in this cached pilot owner. -/

/-- The shared fuel for the checker core: bounds the recursion depth of
reduction, inference and definitional equality.  Exhaustion is an
internal error, never a verdict. -/
def checkFuel : Nat := 100000

end ConLeche

end -- original EOF public section of ConLeche.Kernel.Core
/- END exact source origin ConLeche.Kernel.Core -/

/- Pure-only ConLeche.Kernel.TypeChecker origin (eight wrappers) omitted.
Its complete original source and exact inverse remain in this package map. -/


#print axioms ConLeche.PropWhen.hasParams_ifAllZero

#print axioms ConLeche.PropWhen.eq_of_toList
