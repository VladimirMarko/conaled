# Continue the unified ADWH mathematical library

This is a living guide to the current library and next work. Update superseded
directions in place; do not turn it into a chronological development log.

The current library retains the checked mathematics and distinct interfaces of
its integrated source trees. The compact `MERGE-REPORT.json` records preservation
and the few deliberate interface relocations. The task is completion of book
coverage; no recovery work remains.

Start with `adwh-lean/README.md`, `BOOK-COVERAGE.md`, and the current
`adwh-lean/reports/verification.json`. All current mathematical modules are
imported by `adwh-lean/ADWH.lean` and each has an ordinary source-context record
in `adwh-lean/correspondence/`. Current status and the source inventory are
derived from these records and the latest successful ownership/axiom/reference
gate. Old historical completion statements are not needed.

## Active completion work — checkpoint 232

Continue the user's instruction to complete `cqueens 16 = 14772512`, publish
standalone durability checkpoints, expose/upload them promptly, and keep working.
**The stock numeral and original installed-kernel endpoints remain open.** Read
`next-iteration/checkpoint232-current-state.md` for the exact handoff.

### Actual proof results and consumed keys

The complete corrected word foundation passed all59 reports across six fresh
owners in2.9150907550065313seconds, peak509208KiB. The exact Routing two-proof
and Addition one-line repairs have separate reviews. All194 actual snapshots,
twelve logs and the permanent marker are preserved. See
`kernel-word-major-addition-proof-repair/gate/RESULT-AND-NEXT.md`.

The corrected Interpreter185 attempt failed after25.563569123994967seconds,
peak876708KiB:8accepted/185observed. Its single error remains in
`iota_plain_of_prepared`, now at the first state-run rewrite after explicit
Boolean reduction. All177 roots of that owner are rejected. All1415 snapshots,
six logs and the marker are preserved. See
`kernel-cached-eventual-iota-proof-repair/gate/RESULT-AND-NEXT.md`.

Both source keys are consumed. Retain every older pass/failure and separate
review scope. No unchanged retry, prepared dependency reuse, renamed attempt,
split budget or weakened theorem is authorized. Every new selected closure
must compile all its dependencies inside the unchanged cumulative30-second,
one-CPU/thread/import-worker,1-GiB/default-resource/strict-warning/three-axiom
policy. Root alone executes mathematical work, preflights and saved readers.

### Source milestones and route priority

PendingCertifier now has1545/1549 independent review; it retains complete pins,
real restricted lookup and compute-before-compare, without a selected numerical
backend or claimed result. Integration26 and Adjacency19 now have independent
139/140 and184/185 reviews. The combined112 source selection has279/280 review,
eleven canonical owners/107501bytes/22outputs. It explicitly selects the two
accepted repairs while preserving all six historical mathematical scopes.
Its new controls are outside this cut unless named in the selection review.

The exact141-input small-certificate census finds17owners/4256450bytes/479roots
for the current all-fresh n6 graph. Earlier timings prepared seven original
imports separately. Word packing reduces repeated proof operations, not the
ADD search-state count; it supplies no complete n16 certificate. Prioritize
the stronger residual-CSP quotient and a complete source-linked witness.

The frozen strong-CSP package passed76/77 independent review of17 new reports. Its
generic closure is8owners/32roots/58404bytes. It preserves exact occurrence
multiplicity, checked unsupported-candidate witnesses, sequential propagation,
complete branches and prior-count references built from an empty environment.
The original-cqueens endpoint is a separate three-report leaf with an explicitly
unselected raw32-owner closure; historical resource-owner repairs must be bound
before a current endpoint gate. No producer or concrete count is supplied.
The final independent source audit is preserved in this cut. Subsequent
producer/iota repair work remains outside
the frozen cut unless explicitly selected.

### Continue and preserve

Review/run the complete112 controls once; prepare the exact strong-CSP
producer/endpoint selection; diagnose the retained iota rewrite failure
with a separate proof-only variant. The prior accepted Foundation134 and native
reflection n16 result remain useful evidence, not a whole-query/installation
or stock numeral proof. Preserve both completion routes and their obligations.

All231 payload paths and its publication/clean-restoration receipt are retained.
The archive is source/evidence recovery, not a compiler image. SDK binaries,
prepared objects, duplicate attempt trees, full textbook and full upstream
metatheory are omitted. Use the exact runtime pins; the measured storage guard
in checkpoint232-selection-review.json changes no mathematical limit.

## Prior status review — checkpoint 214

Read `../next-iteration/status-review-214/REPORT.md` for the 25 October 2026
source-based assessment and prioritized completion plan. The supplied 213 ZIP
passed fresh clean restoration and a separately reviewed narrow source/evidence
identity audit. No new compiler, exporter, native count or mathematical gate
ran in this review; mathematical sources and the integrated ledger are unchanged.

The accepted reflection result is retained: 24 fresh modules,154 reports,
23.36454244100605 seconds complete and 7.666948686004616 seconds for the actual
n16 native call. The stock numeral and installed validating-kernel result are
still open. The user's later 36-report Nat-only proof/export success in3.37
seconds is recorded as post-cut handoff evidence; its report/export/marker are
not in the supplied archive. Actual body inspection was reported as beginning,
not finished. Do not reset or infer a fresh slot from the absent later marker.

Next work: exact new source/export/annotation correspondence; explicit Nat-only
guard adaptation; accepted complete Nat-only operational closure; a focused
cached forward-success theorem with true-prefix EnvWF and actual state/fuel;
then the original fixed-fuel GroupChecked record and installation contract.
The drafted pure bound is5053 at width/depth16, not a cached-success theorem.
The existing success-to-pure simulation cannot be used in the opposite direction.

Chapters1–14 and16 remain complete within their recorded scopes. After n16,
reconcile the integrated evidence and textbook account; preserve Chapter6's
accepted research limitation and the existing model exclusions. Older lower
sections and chapter prose retain historical checkpoint claims superseded by
these current findings. The complete report names the stale summaries without
silently rebinding them. All fixed execution/axiom/resource rules remain intact.

## Durable priority clarification — 25 October 2026

The user explicitly wants value beyond a fast proof of one n16 numeral:
algorithmic generation for different inputs, reusable proof infrastructure,
and a renewed focus on the approved optimized-kernel/evaluator direction.
The Chapter 15 numeral remains open, but fixture-specific tuning is not the
success criterion. The user authorized the identified padding repairs, now
verified separately in `../next-iteration/common-payload-padding/`,
together with input-independent Lean codec/padding theorems. Preserve all
older accepted sources, failures and markers; retain the fixed gate limits.

The existing mathematical checker and board correspondence are largely generic;
the source emitters and small-board driver remain specialized. No known answer
is required to compute the count: the retained line producer derives its final
constant from arithmetic and uses known small answers only as diagnostics.
Also distinguish board semantics from this implementation: the current original
counter uses Word16 and a depth of sixteen, with correctness for n<=16. A useful
API for larger n needs a separate width/depth-parametric implementation and a
proved compatibility bridge, rather than silently changing the source counter.

No custom kernel has been implemented. The former compression-witness condition
governs another local capped ADD-producer trial; it does not prohibit a justified
general evaluator/kernel optimization. That route needs an actual measured
operation and proof of its refinement, plus honest executable/source boundaries.

All checkpoints are standalone source/evidence recovery archives. The earlier
"mathematical-result" label did not designate a second backup format. Prefer
the latest archive for safekeeping and new-chat transfer; restore its external
compiler/environment separately. Current goals and decisions must be recorded
here so recovery does not depend on conversational memory.

## Latest continuation — checkpoint 210

Checkpoint 210, `adwh-lean-210-seeded-model-bridge-reviewed.zip`, is a standalone
source/evidence snapshot. It retains every checkpoint 209 payload path and the
earlier accepted mathematical results. The integrated project and accepted
ledger are unchanged. The stock `cqueens 16 = 14772512` theorem remains open.
Continue the authorized work; publication of a checkpoint is not completion.

### Exact numerical result remains preserved

The accepted masked native workload remains the checkpoint 209 result:
22 fresh Lean/C modules, 141 accepted roots, 25.57449162499688 seconds for the
complete proof/C/link/native workload and 13.22057051298907 seconds for the
actual n16 call. It prints the canonical original-source ACCEPT with result
14772512. This is external numerical acceptance, not a stock numeral theorem
or an installed validating-kernel result.

The dedicated success auditor and independent recovery review are now complete.
Root read the auditor and ran both live and source-only modes successfully;
the actual tool results are in `uint64-masked-count-lintfix/ROOT-AUDIT-RECEIPT.json`.
It verifies 59 current snapshot mappings, 48 logs, 88 recorded artifacts and
the 141 ordered reports, together with the original-only pool and historical
source-review scopes. The two actual generated C files remain retained. Keep
the earlier failed worker snapshot at its actual attempt path. Historical
RESULTS/map descriptions retain their preparation-time status; the later receipt
records completion rather than retroactively rewriting them.

### Shared-iota attempt failed; no new selector acceptance

The newly reviewed shared-iota candidate adds one actual reducer theorem and
specializes it in four existing cases, preserving every old public statement
and runtime definition. Its three-module, 29-origin, 87-root complete-01 gate
failed at 30.21896726200066 seconds and 908,764 KiB. Core passed in
14.962436557005276 seconds; Foundation passed in 1.5698740380030358 seconds
with 56 reports; the selector was killed after 13.476049285003683 seconds,
with empty logs and no output files. No theorem position or individual proof
cost follows from that silence.

Raw report: 166,852 bytes, SHA-256
`51f3a94fc15a53636ce47ae1509f2d33847a1c4502b882a8c7b5e4088cff78fe`.
The source key `6b316fd4a57c35d7f79ab23e7bc10e34eb786d671a6b72735df52d3a613d8dab`
is permanently consumed. All identity postchecks passed; the complete output
inventory and mathematical gate failed. Root's live and source-only evidence
audits passed 18 canonical snapshot mappings, 154 direct bindings, 136
historical references, six logs and four artifact identities. Their actual
receipt is in `kernel-shared-iota-selector/ROOT-AUDIT-RECEIPT.json`.

The component's five proof edits, current two import edits, predecessor
29-origin assembly and 24-edit legacy Core overlay retain distinct inverses.
The six reviewed scopes are 57/17/48/25/25/52, totaling 224 input occurrences
over 116 canonical paths. No failed prefix objects may be reused as acceptance.

### Concrete checker integration is reviewed, not compiled

`kernel-seeded-pending-check/` contains the actual post-flush, prefix-restricted
cache update and pending checker. It preserves the original inference,
annotation and equality checks. Its distinct `SeededGroupChecked` proposition
records success of the new driver and implies the actual pure pending check
at some fuel; it does not manufacture old fixed-fuel `GroupChecked` success.
Root's independent source review binds 26 inputs and nine prospective roots.

`kernel-seeded-install-run/` adds deterministic exact-query discovery in the
actual pending type/value and an ordered all-record checking function that
constructs its own typed `SeededFullyChecked` evidence. The actual upstream
installation-model argument is adapted at its one phase-B simulation call.
The model and real push chain derive prefix validity and full lookup agreement;
an arbitrary valid prefix is not assumed instead. Root reviewed both sources,
all six proof-slice inverses, 27 inputs and the thirteen new report commands.
The upstream SetTheory hypothesis remains explicit. Frontend/CLI wiring,
actual exported-declaration checks and all fresh proof acceptance remain open.

The exact dependency inventory is now independently recomputed. A proposed
phase-B extraction reaches 101 upstream modules and 16 existing resource-option
occurrences. The new model's direct upstream union reaches 509 modules,
9,945,616 source bytes and 114 resource-option occurrences; original InstallRun
reaches 510/115. These are source counts, not measured build costs. Project
query/evaluator dependencies are additional. Raw upstream overrides and other
source compatibility have no exception under current policy. The local
insertion-law/phase-B extraction opportunities do not remove the full model
obligation. No smaller complete installation-soundness theorem was established.

`kernel-masked-count-query-guard/` is a separately reviewed three-substitution
overlay selecting the accepted masked evaluator in the existing query interface.
All other source bytes and contracts remain exact. Its seven roots and seventeen
review inputs are uncompiled at this combined boundary. A future closure must
select exactly one query module version; old review scopes remain unchanged.

### Next substantive proof-cost experiment and fixed policy

`kernel-core-proof-census/` found only a small closed unused seven-law subset
of 1,381 declaration bytes. The large remaining substitution proofs are used by
the whole-count chain. It does not justify another tiny-cut gate or a timing
claim. The current next source hypothesis shares five beta-reduction chains
through generic three/four-argument spine lemmas and a known-lambda head lemma.
This work is in progress and not an accepted result in this checkpoint.

Root alone runs compilers, gates, mathematical generators, native programs and
saved-evidence auditors. Every selected complete new closure remains fresh
within one cumulative 30-second, one-CPU/thread, 1-GiB gate, with default resource
settings and only propext, Quot.sound and Classical.choice. Preserve all permanent
markers and meaningful failures. No unchanged retry, upstream-metatheory
exemption, budget split or resource override has been authorized.

Checkpoint 209's actual saved-copy and clean-restoration receipt is included.
Source/evidence recovery needs no previous ZIP. The pinned compiler, omitted
objects and full external upstream proof checkout remain reproducible build
dependencies, separately identified in RESTORE and the new source inventories.

## Previous continuation — checkpoint 209

Checkpoint 209, `adwh-lean-209-masked-evaluator-native-accepted.zip`, is a standalone source/evidence snapshot. It retains every checkpoint 208 payload path and all earlier mathematical achievements. The integrated project and accepted ledger remain unchanged. The stock Lean numeral theorem `cqueens 16 = 14772512` remains open; do not stop at this checkpoint.

### Actual reusable masked-evaluator success

The corrected masked evaluator complete01 passed all 22 fresh experimental Lean/C modules and 141 ordered axiom reports, native compile/link and the canonical original-source n16 certificate. The exact output is `ACCEPT ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512`. The complete workload took 25.57449162499688seconds at 793,388KiB; the native call took 13.22057051298907seconds at 13,888KiB. There were24 commands,88 artifacts and59 read-only source/control snapshots. All final identity/output checks passed. Raw report 319,825 bytes SHA256 `229b123eeda36f20cd1e2edb7f70fde30e22a2c4800c96e5174f3435d1c44828`.

The source key `ff976527a651e033c99d83ef3641e63e37f205a0bad77587bf2adfcf82dc45a8` is permanently consumed. Only the existing seven-original ADWH pool supplied 21 copied objects; its separately recorded preparation cost is unchanged. No experimental object was reused. Checkpoint200's older recorded whole/native times were 29.918614695998258/18.04023222399701seconds. These are individual observations, not repeated statistical timing or larger-board evidence.

The universal operation/worker/source refinements are ordinary freshly checked Lean proofs. They preserve arbitrary Nat depth/budget/fuel, the stated width/range domain, saturation and the total exact Nat fallback. The original adapter remains Word16/depth16; a broader classical-board interface requires a separate width-parametric bridge. The compiler's actual generated worker/helper C is retained in `uint64-masked-count-lintfix/emitted-c-evidence/`: the targeted dynamic moduli are replaced by bit operations. No expected-answer premise or hand-tuned count fixture was added to these proofs.

The earlier masked complete01 failed on the strict unused `hl` binder diagnostic after 108 accepted / 120 observed reports, 10.681264573009685seconds, without native execution. It is retained unchanged. The separate one-character `hl` to `_hl` correction keeps the hypothesis and all proof/executable bytes, except that binder spelling. All other 21 source rows are exact; named-argument ABI identity is not claimed. The old 33/53/22-input review scopes remain at their old worker, supplemented by an 18-input focused correction review. Root reviewed the new controls and ran the successful preflight/complete attempt. External native ACCEPT is not a stock proof of its concrete acceptance equation and not a validating-kernel installation.

`uint64-masked-count-lintfix/` retains the exact sources, correction, reviews, controls, actual preflight/execution receipt, report, 48 raw logs, marker, generated C and canonical 59-snapshot map. The old failed worker snapshot must remain physically at its actual attempt path because the new gate binds it. All binary/object omissions are explicit. A dedicated new-success saved-result auditor is being prepared separately; do not invent a completed audit from this preparation status. Root's live/source-only auditors for the original masked failure both passed and their actual receipts are included.

### Actual legacy selector failure and next proof-cost change

The legacy-format three-module selector attempt failed at 30.219782653002767seconds, 908,596 KiB. Core passed 12.665476419002516seconds with 2 outputs; Foundation passed 1.4809488659957424seconds with 56 reports and 2 outputs. RecursorSelectors was killed after 15.868104270004551seconds, with empty logs and no outputs. No theorem position or individual proof cost follows from those empty buffers. The complete 86-root closure remains unaccepted. Raw report 148,244 bytes SHA256 `4fdfe328365c7c9ebbed0afe0d6bc1af8615cdb904e38862e392bb152f55d676`; key `106e1062f715d56c049ca4c199a34de072ed2e9e88614f582af4844a7d0b2f68` consumed.

The 24 command-only Core overlay, old 29-origin assembly/five overlays, reviews and all 126 bindings remain distinct. Legacy visibility/private imports differ; module-format consumers cannot directly import this legacy Core. Root's live/source-only recovery audits passed 15 snapshot mappings,111 historical references,6 logs,4 actual output identities and147 review-input occurrences over 98 canonical paths. The exact receipts are included.

The whole-count source bundle is independently reviewed but uncompiled: 43 logical origins,148 roots,4 physical modules and8 prospective outputs. It introduces one higher assembly 182,909 bytes SHA256 `f359b7aa954c12045321e5f0d69b228d66285c4a5ec26f3c8b181dc99efc4b08`, with 24 exact import substitutions,216 declarations / 95 private declarations and no new foreign private references in the lexical census. No whole gate has been selected. Its historical reviews retain their exact scopes; a failed base cannot be reused as acceptance.

The next concrete source-cost hypothesis shares four repeated full `iotaRec` proof walks through one ordinary lemma with the same actual stored-record, constructor-spine, preparation and certificate premises. No current timing benefit or new acceptance is assumed. Separately, concrete post-flush query-cache seeding and a separately named pending-check contract are being developed against the real checker. Preserve the actual prefix lookup boundary and distinguish the changed driver from old fixed-fuel GroupChecked. Neither work in progress closes installed source recognition, whole operational normalization or the installation/model bridge.

### Unchanged execution and recovery policy

Root alone executes compilers, native programs, generators, gates and saved-result auditors. All selected new mathematical dependencies remain fresh within one cumulative 30-second / one-CPU / 1-GiB gate, with default resource settings, strict options and only propext, Quot.sound and Classical.choice. Keep all permanent markers and meaningful failures. No unchanged retry, upstream metatheory exemption or budget splitting is authorized.

Checkpoint 208's actual upload and clean-extraction receipt is retained. Recovery needs no previous ZIP; compiler/runtime and any live original-only object materialization remain separate. Continue the promised mathematical/kernel work after publishing 209. The user's goal is a reusable trustworthy computational-proof route and the actual n16 theorem, not merely another external count.

## Previous continuation — checkpoint 208

Checkpoint 208, `adwh-lean-208-selector-prefix-and-lookup-transport.zip`, is a
standalone source/evidence snapshot. It preserves every checkpoint 207 payload
path and earlier mathematical achievement. The integrated project and accepted
ledger are unchanged. The stock `cqueens 16 = 14772512` theorem remains open;
checkpoint 200's actual source-connected native acceptance and checkpoint 205's
62-root Natrec closure remain valid at their recorded boundaries.

### Actual sliced-selector result

The new three-module, 29-origin, 86-report selector experiment failed at the
cumulative wall deadline in 30.216433003006387 seconds, peak 831,156 KiB.
Core passed in 14.896235230989987 seconds with its six outputs. Foundation
passed in 1.6523940240003867 seconds with both outputs and all 56 exact reports.
RecursorSelectors was killed at exit -9 after 13.462481689988635 seconds and
produced neither reports nor outputs. Both its raw logs are empty. This does
not identify a theorem position, diagnose an individual proof or show a
speedup. The complete candidate is unaccepted; its 56-report prefix is accepted.

The exact raw report is 131,915 bytes, SHA256
`a32db0151f86bf0a0d4e5ac3609e3f7abbc760831d16603e2e106906b116e8be`.
All source, snapshot, control and runtime postchecks passed. The source-policy
key `d4ec79bc098030e20ba7221eccdddcda50e6c5a6e96921029a0e2cd394067af0`
is permanently consumed. No unchanged mathematical retry is permitted.

`kernel-sliced-selector/` retains its source assembly, all 29 origin inverses,
five source overlays, independent component/layout/control reviews, actual
preflight, raw report and six logs, permanent marker and exact recovery map.
Root read the saved-evidence auditor in full and ran live and source-only
modes successfully: 103 bindings, 30 snapshot mappings, six logs and eight
actual artifact identities. Compiled artifacts and duplicate snapshots are
omitted from the archive; their exact canonical source/evidence recovery is
retained. These audits preserve the failure and accepted prefix, not a whole
selector or numeral success.

### Reviewed source preparation

The finite-lookup implementation and its lookup-query bridge have independent
source reviews. The collector checks internal names, preserves full records
and derives agreement on exactly twenty requested keys. Guard evidence is
transported to a caller's actual prefix through explicit agreement. The bridge
copies all six fields between the distinct pin structures, recognizes the
entire query, computes its answer and supplies the actual pure-reducer run and
uniform-depth cache premise. It has no expected-answer or fixture argument.
The prefix is used only in the proof field of the lookup optimizer; no runtime
full-prefix construction is required by that interface. Successful installed
agreement, higher normalization and cache/checker integration remain unproved.

The branch-loop sharing variant is independently reviewed. One induction on
strictly smaller branch fuel supplies local bound three; the former full-WHNF
theorem is a short corollary. Exact public headers and the complete named-call
bridge are unchanged. The two contract definitions and six private helpers
move with explicitly recorded ownership; reporting locations stay unchanged.
With the separately reviewed shared-operation base it would have 43 logical
origins and 148 reports. No physical higher closure or compiled acceptance is
claimed. All source variants and full inverse records remain distinct.

The retained masked UInt64 implementation now has a completed independent
source review. It replaces two dynamic modulus operations by proved power-two
mask operations and preserves terminal priority, arbitrary Nat depth/budget,
saturating addition and the total exact Nat fallback. Its refinement is generic
on the stated width/range domain. The old emitted C already shared the low bit
with the tail, so no additional CSE gain is attributed to the new explicit let.
No new generated code, runtime gain or numerical acceptance is claimed yet.

The new masked original-counter endpoint/driver has root's independent source
review and exact inverses to the old endpoint/driver. The prospective complete
native closure has 22 fresh modules, 141 reports, 24 subprocesses and 88 final
artifacts, including the explicit ten-report source-audit module. All selected
experimental proof and code generation, native compile/link, actual n16 call
and final checks must fit one unchanged budget. Only the exact seven-original
native pool is eligible for reuse; its separate historical cost and 21 copied
files are disclosed. Frozen native controls and their completed independent control review are
retained; no native attempt or marker exists at this checkpoint. Root must
complete its own inspection and preflight before dispatch.

### Next work and unchanged boundary

Continue the justified selector/whole-evaluator route and the changed masked
evaluator experiment. A new isolated legacy-format Core source-cost variant
is being investigated after the measured Core cost. It must preserve all
declaration bodies and disclose every module/import/exposure change; changing
the imported visibility regime is not an identical exported-API claim. The
pinned parser rejects `import all` without a module header, so any legacy
variant must explicitly address that import. No such candidate's acceptance
or performance is inherited from this checkpoint's failed run.

Root alone executes compilers, gates, generators, native programs and saved
auditors. Every complete selected new mathematical/native closure remains
fresh within one cumulative 30-second, one-CPU/thread, 1-GiB gate, with default
heartbeat/recursion behavior, strict options and only the three permitted
axioms. Keep every used source marker and meaningful failure. No upstream
metatheory exemption, unchanged retry or budget splitting is authorized.

The user explicitly requested autonomous continuation until the n16 target
and continued uploads. Do not stop merely because this checkpoint is published.
Actual source/prefix recognition, whole operational refinement, a justified
validating checker and its concrete accepted artifact remain necessary for an
optimized-kernel result. External native ACCEPT is not a stock Lean proof of
the concrete acceptance equation. Preserve these evidence boundaries.

Checkpoint 207's actual saved-copy and clean-restoration receipt is included.
The archive needs no earlier ZIP. Compiler/runtime restoration and, for a new
live native gate, validated original-only dependency materialization remain
external build requirements. Source-only recovery audits do not require them.


## Previous continuation — checkpoint 207

Checkpoint 207, `adwh-lean-207-selector-recovery-and-query-interface.zip`,
preserves every checkpoint 206 payload path and mathematical achievement.
The stock `cqueens 16 = 14772512` theorem remains open. Checkpoint 200's native
source-connected acceptance and checkpoint 205's accepted 62-root Natrec
closure remain the latest respective execution and operational-proof successes.
The integrated project sources and its accepted ledger are unchanged.

### Actual shared-selector result

The shared-selector complete-01 attempt failed at the cumulative deadline in
30.211182990009547 seconds, peak 861,100 KiB. Core finished in
13.547379287003423 seconds; the combined proof module was killed after
16.46732915400935 seconds and produced neither required output. It accepted
zero of 78 required roots. Its 4096-byte buffered stdout contains 38 complete
permitted reports and an incomplete fragment; this cannot identify a slow
proof, prove later diagnostic absence or establish the refactor's speed.
The exact raw report is 103,975 bytes, SHA256
`0c1c6bfaea726b1705ce44b4c308e5a0058e3942b6924c73968a632b9f304908`.

`kernel-shared-selector-bundle/RESULTS.md`, the raw logs/report, permanent
marker, exact source maps, reviews and two control-correction inverse chains
are retained. The first no-run preflight found a schema-field mismatch before
any attempt reservation; its focused correction and second passing preflight
are saved separately. Root inspected the saved-evidence auditor and ran both
live and source-only modes successfully: 103 bindings, 18 snapshot mappings,
four raw logs and six actual Core artifact identities. These audits preserve
the failure, not mathematical acceptance. The source-policy key is consumed.

### Prepared reusable interfaces

The four-file higher shared-substitution variant has independent source
review. Twelve repeated proof bodies now apply the shared Nat lemmas; all
68 original statement headers and 20 reports remain unchanged. The coherent
thirteen-module higher order selects KernelCountLoop and excludes the original
KernelCountInduction module. With the shared selector base it would contain
42 origins and 140 reports. This is a logical plan, not an accepted physical
build or a resource-feasibility result.

CountQueryGuard has independent source review. It recognizes the entire
six-literal structural evaluator expression, checks actual typed Nat/Bool/
program/arithmetic guards, computes its answer using the proved total UInt64/
Nat evaluator and derives the actual pure-reducer run. There is no expected
answer or count fixture parameter. Its cacheClause supplies the uniform-fuel
premise of the retained cache insertion law; no cache insertion or checker
patch has been performed. The guard and higher operational chain remain
uncompiled, and successful recognition of actual installed exports is unproved.

The restricted-lookup assessment identifies exactly 20 queried names. A future
checked finite extraction must verify returned records' internal names and
prove requested-key agreement. The guard evidence must then be transported
to the true declaration prefix using actual restricted-lookup agreement.
The full underlying Env of a restricted FEnv is not that prefix; the reducer
must not be run in the finite inspection environment. Source implementation
still being prepared outside this publication is not a recovery prerequisite.

### Next source-cost revision

The isolated kernel-shared-operations candidate adds eight public aliases to
unchanged existing operational proofs and replaces eight duplicate later
bodies with qualified applications. Original headers, visibility, definitions,
pins, arguments, fuel bounds, imports and options remain unchanged. It has
independent source review and exact full inverses. Selecting it with the
previous eight-origin layout would require 86 reports. No measured speedup or
compiled acceptance is claimed. Preserve the frozen predecessor attempts.

The separate optional PropWhen-law slice is retained as an author-prepared,
uncompiled candidate. It omits 36 proofs and fifteen simp registrations while
retaining every computational declaration, constructor invariant and required
isNever fact. Its exact inverse and explicit-reference census are retained;
implicit simplifier use still needs actual elaboration. The broader checker
assessment distinguishes a small insertion lemma from complete acceptance.

Continue the actual selector/whole-count path with substantive, reviewed
source or dependency improvements. Every selected new mathematical dependency
must compile freshly in the same 30-second, one-CPU/thread, 1-GiB gate, with
default heartbeat/recursion/output behavior and the three permitted axioms.
No unchanged retry, upstream metatheory exemption or splitting a selected
closure across budgets is authorized. Actual prefix recognition, the revised
validating checker and its complete success/soundness connection remain open.
Existential pure-run/cache premises alone do not prove the existing driver's
fixed-fuel success. Read the cache-seam assessment before integration.

This snapshot includes checkpoint 206's actual saved-copy and clean-restoration
receipts. It remains standalone source/evidence recovery, with no earlier ZIP
dependency and with external compiler/runtime restoration required. The older
accepted Natrec section below remains valid historical evidence.


## Previous accepted recursor checkpoint — 205

Checkpoint 205, `adwh-lean-205-nat-recursor-verified.zip`, is a standalone
source/evidence recovery snapshot. It retains every checkpoint 204 achievement
and adds the first accepted actual Nat-recursor contracts, the exact preceding
compact/bundled failures, and reviewed source proofs for the inner counting
fold. The integrated chapter sources and successful project ledger are
unchanged. The stock Lean theorem `cqueens 16 = 14772512` remains open; the
actual native result from checkpoint 200 is preserved and has not been rerun.

### Actual Nat-recursor closure accepted

`next-iteration/kernel-bundled-reference/gate/attempts/complete-02/report.json`
records a passing fresh build of eight physical modules covering all 28
mathematical source origins. All 62 required reports and all 20 default outputs
were accepted in **27.806141771987313 seconds**, peak **834,908 KiB**. Raw report:
105,714 bytes, SHA256
`f44b12bcdb20a4ec5171556d55eda94aa9d766ea34666b0257ae8bcd3e8f26e4`.
The unchanged resource policy is one cumulative 30-second budget, one CPU and
compiler thread, 1 GiB, default heartbeats/recursion/compiler options, strict
warnings, and only `propext`, `Quot.sound`, `Classical.choice`.

All eleven Natrec roots now pass, alongside the 51-root foundation. The local
accepted `source/KernelNatRecursor.lean` is 31,624 bytes, SHA256
`126beff77f617603e5da5bc0662d3c64ee8962645e9ca6262cbf7dda79e358df`.
These are conditional theorems about the actual ConLeche verified reducer:
zero/successor iota, head reduction, application, and fuel-uniform full runs.
They do not discharge the stored environment pins or establish the whole
counter. No count, optimized kernel installation or stock numeral theorem was
part of this run.

The source bundle consolidates 21 upstream units into `KernelCompactCore`.
Exact source maps retain the original declaration/proof text except the
previously disclosed optional cuts, module/import headers and explicit EOF
scope closures. The Low import adapter and the separate three-proof Natrec
correction have exact inverses. Changed module ownership/visibility and
persistent registrations are disclosed; literal source correspondence is not
claimed to establish identical elaborated private names or full cached-engine
compatibility. Every selected module compiled freshly; no old object was an
input.

### Exact failed attempts remain failures

The compact 28-module attempt failed at 30.23736371799896 seconds with 51
accepted prefix roots and 138 partial outputs. Natrec stdout/stderr were empty.
Its failure supplies no theorem-level timing or diagnostic attribution.

The first bundled attempt finished within limits in 28.879820896007004 seconds.
It accepted the same 51-root prefix and exposed three actual free-variable
errors in `decide` calls for application-spine lengths. All eleven Natrec
reports were printed but unaccepted because that module failed; six included
error-recovery `sorryAx`. The local correction changes exactly those three
proof subterms to first expose the literal lengths 1, 2 and 3. All 25 theorem
headers, eleven roots, definitions, pins, fuel conditions and strict options
are unchanged. Independent source and gate reviews bind the actual failure
and verify both directions of the exact correction. Its passing complete-02
result does not relabel complete-01.

The earlier five recursor attempts and all exact unique source/control texts,
raw reports/logs and permanent markers remain retained. Their canonical
recovery maps preserve failed outcomes and omitted compiled-artifact identities.
Read the compact, bundled and recursion RESULTS and saved-evidence auditors.
Do not rerun accepted or failed unchanged source/policy keys, including after
restoration.

### Reviewed whole-fold source work remains uncompiled

The retained `kernel-structural-head` module exposes the actual inner
function-valued recursor at zero and successor fuel. `kernel-branch-composition`
composes the actual selector, arithmetic, child and predecessor expressions.
`kernel-arithmetic-runs` gives pointwise existential fuel thresholds for actual
operand expressions and all state updates. Its power lemma explicitly retains
the actual reducer's exponent support bound, `n ≤ 16777216`.

`kernel-count-head` exposes the outer recursor's three state lambdas and the
exact terminal selectors after their three actual argument substitutions. Its
eight proposed roots and independent review are retained, still uncompiled.

`kernel-branch-induction` proves the proposed inner-fuel induction against
those operational interfaces. Its child contract is pointwise over actual
closed argument expressions and their actual runs; the outer-depth induction
must discharge it at a strictly smaller depth. The recursive predecessor uses
the exact remaining-cursor expression and smaller fuel. No current whole-call
normalization is assumed. These source reviews found no mathematical blocker,
but none of these candidate modules has been compiled. Their historical
Natrec/Bool dependency bindings remain explicit, and a selected fresh gate
must rebind the actual accepted variant rather than silently changing review
scope.

The earlier Bool, delta, ordinary-definition spine and exact source-body work
is also retained as reviewed, uncompiled source. The three actual export-tree
comparisons establish syntax correspondence only. They do not establish
annotation, installation, environment validity or whole execution. In-progress
Bool staging, explicit Natrec proof preparation and outer-depth work outside
this checkpoint's explicit
selection are not prerequisites for recovery; continue them from the saved
interfaces and handoff if they are absent.

### Next action and kernel-integration boundary

Continue the actual Bool/selector path and whole outer-depth proof, selecting
reviewed source/build optimizations where the complete fresh closure needs
more headroom. The accepted recursor closure leaves only about two seconds
under the fixed budget; this is a measured closure cost, not a license to
exempt dependencies, enlarge limits, split unchanged work or assume uncompiled
proofs. The three Bool arity decisions have the same open-expression pattern
as the actual Natrec diagnostics. Preserve frozen source/review history when
preparing a corrected variant.

The cache-seam assessment remains a separate open obligation. Successful
`CSOK.insertWhnfC` use needs an actual pure full-WHNF run under the appropriate
environment/scoping premises. `FEnv.restrictTo` changes visibility without
removing the full underlying environment. Installation queues checks; it does
not establish their validity. Source annotations, environment pins, the
outer-fold result and actual cached-checker/driver integration must all be
connected before claiming an optimized validating kernel. The full metatheory
closure has not been shown to fit this policy.

Both accepted primitive-reference exports, the accepted structural Nat and
logical reducer foundations, the exact native sixteen-queen check, all earlier
stock numerical proofs and the current integrated project evidence remain
recoverable without an earlier ZIP. Checkpoint 204's actual clean extraction,
saved-copy receipt and source/review-input audit are retained. Compiler/runtime
binaries and compiled outputs are deliberately excluded and restored from pins.

## Exact numerical checker result — checkpoint 200

Checkpoint 200, `adwh-lean-200-cqueens16-external-check-verified.zip`, established
the following result, fully retained in checkpoint 203. The exact target
has been **accepted by a compiled, source-connected verified checker**:

```text
ACCEPT ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512
```

**The stock Lean numeral theorem is still open.** This external acceptance is
not an ordinary proof term of the concrete equality or of the checker's
concrete acceptance premise. The integrated project and its accepted Lean 4.35
whole-project gate remain unchanged; the chapter ledger is not silently closed.
The user requested continued pursuit until the target is reached and continued
checkpoint publication/upload. Do not ask for renewed permission. Preserve the
exact external result and continue the justified proof/kernel integration work.

### Complete actual16 external check

`../next-iteration/uint64-restricted-nat-checker/native-gate/attempts/complete-01/`
contains the first and only actual16 execution. Its complete gate rebuilt all
18 selected mathematical/driver modules, checked all 119 exact theorem reports,
generated fresh C, compiled/linked it, ran the exact four-token certificate,
and performed final integrity checks. The whole gate passed in
**29.918614695998258 seconds**, peak **790,848 KiB**. The concrete certificate
process took **18.04023222399701 seconds**, peak **11,952 KiB**, exited zero,
printed precisely the line above and had empty stderr. The raw report is
260,223 bytes, SHA256
ed6b8c8f8162ee0027900ca8df267cbc3227c4101ec1b362fbb3f200355fef88.

The 20 commands and all 76 final artifacts were checked. There were 37 immutable
input snapshots and 44 pinned compiler/runtime/header bindings. All 119 roots
use only propext, Quot.sound and Classical.choice as allowed. The actual
original-source UInt64 adapter and its checker instantiation passed in this
fresh closure. No prior experimental object, generated C or executable was
used. The final elapsed observation leaves only about 0.0814 seconds under the
fixed 30-second cap; it is not a robust performance margin or a larger-n scaling
result. Do not rerun the unchanged source/claim to obtain another timing.

Only 21 prepared objects for seven unchanged original ADWH modules were copied:
seven each of .olean, .ilean and native .o. Their explicit separate preparation
completed in 10.480943722002849 seconds, peak 799,192 KiB, with fourteen compiler
commands and 28 outputs. It ran no program or count. Its raw report SHA256 is
fbbe1e697b389feb4baf0504fa3bc2474576ab51ee69bb36b2a0a7f4f50d0ed5.
Read `../next-iteration/first-order-nat-evaluator/original-native-preparation/`.
That preparation budget is disclosed separately, not hidden in the count time.
It exempts no new mathematical module from the fresh complete execution.

### Reusable mathematics now established

`../next-iteration/uint64-saturating-evaluator/` now has accepted ordinary Lean
proofs for its scalar implementation and exact fallback wrapper. Its generic-03
gate freshly rebuilt six modules and accepted all 53 roots in
2.8234893230037414 seconds, peak 503,512 KiB. Raw report SHA256:
da4760d6399ef531a109371a1c6cdb49185fec2249d3b252f80c6d29bf6a372f.
Nine roots use no axioms; the remaining profiles use only the allowed names.
The separate four-root actual-source adapter also passed in the complete native
gate, together with the canonical parser and concrete checker soundness laws.

The recursive invariant is
`UInt64Result.toNat = min ExactNatResult (2^64 - 1)`.
The total Nat-valued wrapper falls back to exact Nat computation on the sentinel
(including equality to it), unsupported widths or out-of-range masks. It
therefore assumes neither the desired answer nor an upper bound on the count.
The fast-path representation laws cover widths zero through 63, with arbitrary
budget/depth/fuel. The wrapper theorem is unconditional for all natural inputs.
The actual source adapter retains Word16 masks and depth/budget 16. Its equality
covers every input to the original source definition; board semantics beyond
that implementation's established n<=16 domain are not thereby proved.

Generic-01 and generic-02 were genuine failed proof attempts, not timings to
ignore. The first accepted 26 / observed 42 roots before two UInt64 literal-one
normalizations failed in mask proofs. The second accepted 42 / observed 51 before
two analogous terminal-case proof steps failed. Explicit rfl/local literal
facts repaired exactly those four proof steps; executable definitions and all
39 candidate theorem statements stayed unchanged. Preserve both failed reports,
logs, source/control snapshots and permanent markers. The recovery map retains
12 unique superseded inputs, mapping all 42 snapshots across the three attempts.
No recovery sorryAx diagnostic from either rejected module is an accepted root.

The earlier accepted reusable foundations remain:

- FiniteFold: nine axiom-free finite-fold equations and uniqueness laws.
- FirstOrderNat generic: two fresh modules, 18 roots, 1.1119027979948441 seconds.
- FirstOrderNat actual-source adapter: ten fresh modules, 67 roots,
  5.742802972003119 seconds; equality to the original cqueens for every input.
- RestrictedNatChecker: thirteen fresh modules, 80 roots,
  6.574911215000611 seconds; typed endpoint, canonical parser and source soundness.
- First-order native n8/n10/n12 diagnostic: outputs 92, 724 and 14,200 in the fixed
  complete 2.5806708649979555-second run. Its n12 internal interval was 21,655,703 ns,
  versus 105,247,886 ns in the retained original-shape baseline, about 4.860 times
  faster in those single observations. Those runs remain diagnostics.

The successful actual16 run uses the UInt64 evaluator, not that earlier Nat-only
native executable. Its emitted C has unboxed scalar count/branch workers and
ordinary direct recursion. Retained C permits review without rerunning the
count. Native compiler and standard primitive/runtime correctness remain the
explicit execution boundary; the Lean source proofs do not verify machine code.

### What the successful certificate does and does not establish

The endpoint type contains the actual original cqueens function. Its executable
field is the refined evaluator, and its correctness field is the proved universal
source equality. The canonical four-token parser fixes the declaration name,
input, equality sign and decimal value before evaluation. The claimed value is
only compared with the computed result; it does not control sizing, branching,
refinement hypotheses or the count. No hand-designed instance fixture or
expected-answer premise is used in this algorithmic route.

The freshly checked `UInt64QueensNatChecker.accepts_original` theorem connects
successful safe checker acceptance to the exact original equation. The pinned
native run supplies external computational validation under its recorded
compiler/runtime/I/O boundary. The report deliberately keeps universal proof
success, native invocation, canonical output, complete-gate success and stock
numeral theorem fields separate; the stock-theorem fields remain false.

Applying that theorem inside stock Lean still requires an ordinary proof of the
concrete acceptance equation. The native exit code cannot be inserted as such
a proof. `native_decide`, a new axiom, unsafe override, unchecked kernel insertion
or a name-only evaluator hook is not permitted. Adding another certificate/AST
wrapper around the same external call does not by itself close this gap.
A justified optimized kernel must validate actual source recognition/installation
and successful reduction, and connect that path to its concrete checked proof
artifact. A custom accepted export must also be distinguished from a stock
.olean recheck. The source-based concrete completion assessment is the next
research direction, not another unmodified numerical run.

`../next-iteration/reusable-evaluator-direction/` retains the pinned integration
and kernel contracts. The full upstream project has not been built or
executed. The selected 21-module logical kernel reference is now freshly
checked with the disclosed compatibility/optional-optimization changes. The
large full checkout/archive remains an omitted reproducible external dependency. There is no established generic program-hook theorem and no proven
default-limit compatibility for its full proof closure. Do not silently exempt
upstream metatheory or split a selected new proof closure across fresh budgets.


The low-operation bridge proposed after the external result is now accepted in
checkpoint 202's logical-reference complete-02 gate, as detailed above. Its
original deadline failure and later proof-script failure remain preserved.
The next construction is the whole structural-reference connection through
actual annotated recursor/beta steps and exact source recognition. A separate
power-of-two operation candidate remains independently reviewed but uncompiled;
it has no selected numerical rerun or measured speedup. Preserve these scopes
and every genuine attempt when continuing after restoration.

### Fixed execution and recovery rules

Only root executes Lean, native programs, counters and computation generators;
review agents inspect source and saved evidence. Each selected complete fresh
mathematical/native closure shares one 30-second, one-CPU, 1-GiB budget, default
heartbeats/recursion, strict warnings, Lean `-j1 -M1024` and the permitted axioms.
The source-keyed markers and all failed attempts remain permanent. The actual16
identity includes its exact canonical argv. Reacquiring external dependencies
is not authorization to erase markers or rerun accepted instances unchanged.

All earlier accepted work, source-bound evidence and standalone recovery maps
remain selected, including checkpoint 195's stock cqueens6 source proof and the
common-payload codec repair. Source-only saved-evidence auditors do not execute
Lean, native checkers or counters. The checkpoint 199 clean extraction and all
six then-current auditors passed; its separate recovery-validation JSON is
retained. The documented 198 ZIP-mode auditor correction and original scripts
remain available. Read RESTORE and the current RESULTS/recovery maps for the
new generic, original-native and actual16 evidence. Compiler/runtime objects
and executables are deliberately omitted; all needed source and exact evidence
identities are retained without any earlier ZIP dependency.

## Prior checkpoint 197

The preceding standalone snapshot was
`adwh-lean-197-common-payload-padding-verified.zip`; no earlier
archive is needed for recovery. Integrated Lean 4.35 sources and the accepted
whole-project gate remain unchanged.

The common-payload padding repair now has two completed checks. The ordinary
Lean gate freshly rebuilt three modules and accepted all 239 required roots in
7.89377424599661 seconds, peak 700,396 KiB; its report SHA256 is
292b6b70df88fbb4a339d4e3c3e8b54ba850cdf4ece198cec509387851f282e8.
All nine new universal padding/codec roots use exactly propext and Quot.sound,
with no board-size or expected-answer premise. The separate producer/replayer
repair passed all twelve synthetic scalar-codec tests and exact source-inverse
checks in 0.19858322300569853 seconds, peak 38,616 KiB; its report SHA256 is
dc6254ec03d56f16550507d2aa4c83ec48b3b11bd237a35ca29d6c256ccc0838.
The original main() bodies, small-board guards and frozen original sources stay
unchanged. Wider node values now receive a common payload width, with zero
padding checked independently and invalid natural inputs rejected before
width/shift calculations. Read the candidate README, result reports, independent
reviews, SNAPSHOT-RECOVERY, and RESEARCH-DIRECTION. Preserve its two markers.

This is reusable representation mathematics plus finite Python regression
evidence, not a formal Python correspondence proof, general producer, new count,
compression result or optimized kernel. The latest complete numerical
source-count fixture remains checkpoint 195's packed-row cqueens6 result.
The original n16 goal remains open. Do not rerun an unchanged n6 fixture to
market this generic helper as a larger-board result.

The source-only `../next-iteration/instance-schema-contract/` records the
exact larger-instance adaptation boundary, with an independent review.
Most semantics and the source bridge are already generic; the minimal route
can preserve ConsolidatedGeneric and put fixture-local codecs plus four field
transport proofs in new Arithmetic. The new generic padding helper is now an
accepted option. The frozen packer and replay's claim-dominates-node payload
restriction is repaired in separate variants when actual constants are too wide; conditionally,
14772512 alone requires 24 bits. Neither the expected numeral nor a successful
packing pass is a source-count premise. Every factor, site/wire occurrence,
claim, final constant and source clause still needs its actual checked evidence.

No new producer, compiler or count ran for that earlier contract. The existing direction
review still requires a distinct compression mechanism with a fixed actual
boundary witness before another nearby capped ADD producer, followed by a complete
trace for its proof. This is not a prerequisite for a measured, proved generic
evaluator/kernel optimization. No n7 switch or unchanged n8 retry is selected.
This is an evidence boundary, not a request for renewed user permission.

The previously missing report and its invalid-export attachment are now supplied
and retained in `../next-iteration/kernel-validity-reconciliation/attachments/`.
Read that parent's README, formal-contract review and regression results. The
fixed six-checker negative control reproduced nanoda's acceptance of `bad : False`
with no axioms; all five other processes diagnosed an application type mismatch.
This is negative assurance evidence, not an ADWH proof premise. The existing
ordinary-kernel and all-six accepted certificate results remain valid evidence.

The updated report and source reconciliation are retained in
`../next-iteration/kernel-validity-reconciliation/upstream-update/`. Pinned
upstream source corroborates both nested-recursor repairs by nanoda 0.4.28,
also present in the assessed 0.4.29; the distributed 4.35 binary is still the
older 0.4.19. The newer regression matrix was reported by the attachment,
not rerun here. Its added paranoid-mode sentence overstates the original
execution evidence: six individual checker outcomes imply rejection of the
conjunction, not a separately observed Lake workflow. Axiom-name flattening
and the standard native-primitive profile remain relevant trust boundaries.
No kernel replacement or new performance result follows from this update.

The completed exact source refinement is
`../next-iteration/packed-equality-refinement/`: a union-of-XORs equality
comparator, with unconditional evaluator/checker equality, replacing only the
two node/claim checking proof bodies and adding one import. All literals,
statements and the final source module are preserved. Generic-01 passed all
233 roots in 8.643420584 seconds. Full-01 freshly checked all ten modules and
381 roots in 28.854135757 seconds, peak 972,692 KiB, preserving the original
cqueens6 conclusion. Its report is SHA-256
edc7a0d339267ee92324855ddd9d73b26adbd827fb78968b2429e424739a4882.
The correct generic report is explicitly bound and snapshotted before full
execution; the earlier metadata defect is not repeated. This successful
refinement supplies no useful new headroom against the previous observation,
and is not a controlled performance comparison. Preserve it without reruns.
The structural paged-cache experiment used checkpoint191's accepted baseline.
Generic-02 accepted its three-root universal helper and dependencies (233
roots, 8.282702034 seconds). Generic-01's nine deprecated alias errors and
the exact correction remain preserved. Full-01 failed at the explicit-lookup
versus `pagedNodes` alias bridge in Arithmetic: 27.067857685 seconds,
1,041,852 KiB, no resource-watchdog event. It has 361 observed / 270 accepted /
385 required reports; all 91 reports from the failed module are unaccepted,
including 43 with error-recovery `sorryAx`. The final Source was not attempted.
No concrete cache or new count is accepted. The complete raw evidence,
correct generic-report provenance, unique sources and snapshot recovery are
in `../next-iteration/paged-descriptor-cache/`. Read RESULTS and independent
reviews; preserve the full marker and do not relabel a simple proof fix as a
new experiment. Its failure remains frozen.

The distinct `../next-iteration/page-composed-descriptor-cache/` route is now
accepted: 93 checked leaves and one balanced term with 92 applications of a
universal composition lemma, preserving the same data and source meaning.
Two generic proof-script failures remain recorded; generic-03 accepted all
234 roots in 8.526747557 seconds. Full-01 freshly checked all ten mathematical
modules and all 479 required roots in 27.527305750 seconds, peak 945,328 KiB.
It rechecked the original cqueens6 endpoint with only the allowed three axioms.
The actual generic-03 report/snapshot and all source/control/runtime/object
bindings verify; full report SHA-256 is
4a3e052ebf38ee498ed0061b1e6a3265b864407d2960a91e95612e3d0c5272b7.
Read its RESULTS and independent reviews. Preserve all execution markers.
This complete result supplies no useful new headroom over baseline191 and is
not a matched performance comparison or larger-board result.

The latest `../next-iteration/packed-row-descriptor-cache/` route is also
accepted. One row-packed Nat, an immediate small left row mask and fixed
field extraction replace tree dispatch. Ninety-three checked short ranges
and 92 balanced semantic joins recover every original expansion proposition
and the unchanged source endpoint. Generic-01 accepted 234 roots in
7.765072037 seconds; full-01 freshly checked ten mathematical modules and
479 roots in 25.786490249 seconds, peak 981,228 KiB. Full report SHA-256:
2c471bf8d936228009ca6233948b5a4fc38b0d1175131d167cc3132f5f602fd3.
The actual generic report/snapshot/marker, all 34 objects and exact source
inverse are independently verified. The observed time margin is larger and
RSS margin smaller than baseline191; this is no matched speedup or n16
headroom claim. Preserve the completed gates without parameter sweeps.

Its NEXT-SCALING-ASSESSMENT identified the now completed source-only instance
contract: every node/claim field width, witness/routing capacity and source
geometry obligation is exposed, while optional abstraction is kept separate
from the missing compression/trace evidence. No complete n7 fixture was found in the inspected retained files,
and n8 ADD prefixes remain incomplete at the 50,000-operation cap. The n6
seven-bit rank field cannot represent the retained n8 trace's 210 variables.
The historical compact n8 proof reaches actual cqueens8, but replays a fixed
409-node tree with six reuse sites and 80 singleton leaves; it is not a
general ADD input producer or a new4.35 result. The separate explicit-proof-source
assessment defers whole-module export/replay, since neither source recovery
nor a relevant measured elaboration bottleneck is established. The integrated
project stays unchanged, projected-context remains paused, and n16 is open.

Isolated split-formula factoring was rejected after source review found existing
kernel sharing; the static formula census makes no timing claim.

The report confirms that con-leche/con-ron semantic or modeled-execution theorems
do not discharge the actual ordinary acceptance equation or remaining count
bridge. Newly inspected source also shows bounded instantiation-cache eviction
is already implemented and proved in con-leche. Do not duplicate it or select a
new cache cap without operation-level evidence of the actual pressure.

The new `../next-iteration/hoisted-view-checks/` route is fully accepted.
After the recorded proof-only development correction, `full-01` rebuilt all nine
sources freshly together in 23.727831765 seconds, peak 763,460 KiB, with all 121
required reports and only the three allowed axioms. The new generic refinement
uses the already checked view table to remove repeated local cofactor validity
checks while proving equality with the actual original Boolean checker. Seven
original modules and all records are unchanged, and the original proofs_checked
proposition and all sixteen semantic endpoints are preserved. Independent audit
verified all 69 distinct recorded bindings, frozen sources and raw axiom reports
without log recovery. Read its RESULTS and FULL-RESULT-REVIEW. Do not repeat this
unchanged gate or reset its full execution marker; no causal speedup is claimed.

The follow-up `../next-iteration/hoisted-expansion-count/` proposal is blocked.
Its fixed original-import preparation stopped at the enumerative primitive
certificate, with 30.042108718 cumulative seconds and 1,168,564 KiB recorded
peak RSS. Five earlier objects are partial output, not a complete accepted
import pool. Its separate generic-01 attempt then failed on the changed Lean
4.35 CNF clause interface, with zero accepted reports; the new expansion
helper never compiled. No complete count gate ran. Both failed attempts and
their independent reviews are retained. The source dependency audit confirms
that the actual cqueens theorem needs the universal primitive certificate.

`../next-iteration/symbolic-word16-primitives/` now contains an accepted symbolic
proof of that exact certificate in an isolated namespace. Word, bit, low, bits2
and PrimitiveCertificate have the identical original declaration bodies. The
proof establishes the least set bit, non-wrapping subtraction decrease, and
the exact increasing-order list recurrence, without enumerating the 65,536
words. Complete-02 freshly checked both modules in 0.776588671 seconds, peak
491,036 KiB, with all seventeen required reports and only the three allowed
axioms. Read its RESULTS, source review and independent result review. The
development failures and proof-only corrections remain explicit evidence.

The original-namespace refinement under its source-refinement/ directory is
now accepted. Refinement-01 rebuilt all eight selected sources freshly in
7.285628826 seconds, peak 794,400 KiB, with 24 accepted reports. Its reversible
generator preserves all 64 private chunk propositions, all 79 declaration
headers, the original dispatch and complete public suffix. Only chunk proof
bodies and explicitly disclosed imports/control/documentation/audit text
change. The generated copy removes the two old resource overrides and checks
under defaults; the original integrated source stays untouched. The kernel
checks the actual cross-namespace certificate applications and original bits
program. Independent review verified all 75 distinct recorded bindings.

The accepted ../next-iteration/legacy-list-clause-compatibility/ helper proves
exact round trips between old list clauses and current packed clauses, and
clause/formula evaluation preservation for arbitrary assignments. Its sole
generic-01 run passed in 0.310033594 seconds, peak 492,660 KiB, with all six
reports. It uses explicit compatibility names, never shadows Std, and retains
the exact old/current primary-source and license evidence. The independent
result audit verified all 29 recorded bindings. Read both result reviews;
do not rerun these accepted gates unchanged.

The combined complete route is accepted under
../next-iteration/legacy-list-clause-compatibility/count-migration/. Its single
full-01 freshly rebuilt all nine new mathematical sources in 27.281189544
seconds, peak 908,020 KiB, and accepted all 378 required roots. The original
source_cqueens_six theorem, BitRepresentation.cqueens 6 = 4, was checked on
Lean 4.35. The final statement/proof suffix and six original executor
definitions are unchanged. The scoped original counting module retains the
complete generic prefix through cqueens_eq_queens_count; the Examples import
and three convenience suffix theorems are explicitly omitted. Exact inverse
checks recover the original counting source and all historical count bundles.

Seven unchanged original prerequisites were prepared separately in
7.278098570 seconds, peak 797,832 KiB. Their fourteen objects contain no new
mathematical dependency. The full gate copied only those objects and freshly
produced all eighteen new outputs; the complete artifact inventory is exact.
The generic stage's first strict-warning failure, one-argument proof-only
correction, and accepted 233-root generic-02 remain explicit. All limits and
the three-axiom policy stayed fixed. Read RESULTS, FULL-RESULT-REVIEW and
NEXT-STEPS before choosing another experiment; never reset the full marker.

The full run has one disclosed provenance-recording defect: a shadowed Python
path variable recorded the older kernel-comparison report in place of the
actual generic-02 report, which consequently was absent from the full control
snapshots. Actual generic-02 validation and all nine fresh compiler checks
still completed. The independent full audit verifies the mathematical result
and separately rechecks the correct generic evidence in
GENERIC-PROVENANCE-ADDENDUM.md and GENERIC-PROVENANCE-AUDIT.json. That supplement
is post-execution; it does not retrospectively claim a missing snapshot.
Raw historical runner/report/markers are preserved, with a separate patch
for future runner use. Keep this qualification in any account of the result.

This provides a current-toolchain complete source-count baseline for n6. The
old three-bundle proof remains historical Lean 4.33 evidence, and integrated
project sources and their whole-project gate remain unchanged. No controlled
performance comparison, n16-scale certificate, or proof of cqueens16 follows.
Continue toward the actual remaining count/certificate-scale problem with a
new reviewed design, preserving accepted useful proofs and the fixed resource
policy. The projected-context experiment remains paused; the n16 target is
still the sole open Chapter 15 numeral.

Checkpoint 186's lookup refinement, completed probe and rejected congruence
variant remain preserved. Do not repeat any completed experiment unchanged or
raise limits. No new count, kernel modification or n16 scaling result is claimed.
The private library remains uninspected. The projected-context experiment stays
paused, and no board above eight has been attempted.

## Current durable intent — approved 24 October 2026

The user approved upgrading the **whole project to Lean 4.35.0**. This supersedes
the earlier instruction to retain Lean 4.33.0-rc1. Complete the migration and
its ordinary full-project audit, then compare the bundled kernels on the same
representative proof workloads. If they do not provide substantial improvement,
investigate a proved optimization or replacement checker. Record an exact
refinement/soundness contract; do not equate agreement on examples with universal
equivalence to the official C++ kernel.

The user has a private library in mind that may help generalize this
infrastructure. Research the existing infrastructure and request the library
when a concrete gap makes inspection useful. Its contents are not yet available.

Checkpoint 180 was secured by the user and restored after automated workspace
maintenance. No later pre-restoration checkpoint was found. It **does contain**
this file at `project/CONTINUATION.md`; the root `CONTINUATION.md` is a short
entry point added to make durable intent easy to find. Checkpoints remain
standalone durability snapshots, with a 32 MiB guard, rather than accumulating
version history. Preserve useful certificate work even if another route succeeds.

Before the supplied checkpoint 184, the user had confirmed securing checkpoint
183, `adwh-lean-183-lean435-migration-reviewed-sources.zip`, on 24 October 2026.
The current continuation above supersedes that earlier durability status. The workspace survived the subsequent execution interruption.
The saved migration log completed target 1,223 of 1,240 and stopped at the start
of target 1,224 without a recorded build error. A new `core-23` attempt resumed
there without source changes and completed the full unchanged gate on
24 October 2026. Do not treat a stale `running` report as a live process.

The projected-context experiment is paused while this kernel direction is
evaluated. Its fixed design is retained; no semantic run is authorized merely
by the old next-step wording below. The ultimate Chapter 15 goal remains open.

Migration evidence and the accepted current source binding are in
`../next-iteration/lean435-migration/`. The complete Lean 4.35 gate passed as
run `6e376337ca5b4b34a679cd9588e3bfc1`: 1,240 source modules, 83,281 owned
declarations, and all 17,846 selected theorem references. All sixteen chapter
validations, current status, inventory, floating validation and book assessment
now bind this run. Chapter 15 remains incomplete. Historical 4.33 experiment
evidence retains its original version and is not relabelled as 4.35.

The fixed guarded-identity comparison is complete. All eight active experimental
modules passed a fresh cumulative 4.35 gate in 25.223733357 seconds, and all six
bundled checkers accepted the same export. Con-ron used 9.969159 seconds versus
the ordinary official checker's 13.945121 seconds: 28.51% less wall time on this
one input. None met the predeclared twofold screen. This is a single-workload
measurement, not a proof of a general speedup or a result for sixteen queens.
No replacement kernel has been adopted. Preserve the protocol and exact-source
proof reviews in `../next-iteration/lean435-kernel-comparison/` and
`../next-iteration/lean435-kernel-research/`.

The fixed supplemental comparison of the existing 1,024-case primitive page
is also complete. All six checkers returned process success, but con-ron's
1,501.26 MiB peak exceeded the fixed 1 GiB policy. The other five passed that
policy; the ordinary official checker was fastest at 5.624565 seconds. No
alternative established the twofold improvement screen. Preserve its immutable
protocol, binding and results in
`../next-iteration/lean435-primitive-kernel-comparison/`. It performed no new
source compilation, queen count or kernel adoption. Do not repeat the fixed
experiment or increase its limits to obtain a different outcome.

Existing con-leche and con-ron infrastructure already proves substantial
successful-run refinement and semantic soundness under explicit premises; it
does not prove universal equivalence to the C++ implementation. A useful next
research milestone is a measured kernel operation together with a precise
representation/refinement contract. Inspect the offered private library's API
and a representative proof to assess whether it helps with different state or
expression representations, cache invariants, or nonmatching control flow.
Do not infer that an externally observed result is itself a Lean proof of the
acceptance premise. Keep source/statement binding and executable trust explicit.

Preserve the Std-only core manifest and the optional unused Mathlib revision
`169c26b52a38b704fad2c009372d76844a059bdf`. Keep total definitions,
`autoImplicit=false`, `warningAsError=true`, no admitted proofs/custom axioms or
kernel bypass, and only `propext`, `Quot.sound`, `Classical.choice` transitively.

Keep functional correctness, invariants/termination, exact source
correspondence, global optimality, and operation/complexity claims separate.
Retain precise hypotheses, failed-operation behavior, ties, occurrence/order
information, and optimized algorithms. Do not replace an optimized executor
with exhaustive search or reinterpret a selected event count as runtime.

Two useful pairs of interfaces remain separate: broad `CoinChange` versus
`CoinChangeDecreasing`, and the original Chapter 14 matrix family versus
`Chapter 14.ExplicitDomain`. Existing theorems in one interface do not prove a
bridge to the other automatically. The README explains the differences.

## Chapter completion and modeling scope

Complete coverage chapter by chapter. Chapters 1–14 and 16 retain their recorded
mathematical scopes, including the accepted Exercise 6.11 research limitation.
Chapter 15 has one open obligation under the renewed full-completion request:
`BitRepresentation.cqueens 16 = 14772512`. Its prior accepted numeral deferral
is preserved as history, not used to mark the current request complete. Neither
research statement is proved or refuted. The requested floating analysis and Chapters 1–5 scope audit are
complete in their explicit mathematical domain. Chapter 6 is complete under the
user-accepted scope: the unsupported groups3 superlinearity claim is documented
but remains unproved as a separate research question. Chapter 7 is complete in
the scope recorded in `docs/chapter07.md` and its item ledger. Chapter 8 is complete
in `docs/chapter08.md` and its ledger. Chapter 9 is complete in
`docs/chapter09.md` and its ledger. Chapter 10 is complete in
`docs/chapter10.md` and its ledger. Chapter 11 is complete in
`docs/chapter11.md` and its ledger. Chapter 12 is complete in
`docs/chapter12.md` and its ledger. Chapter 13 is complete in
`docs/chapter13.md` and its ledger. Chapter14 is complete within `docs/chapter14.md` and its validated item ledger, including explicit source corrections and representation costs.
Do not make all later-chapter cost backlogs, interface bridges, or a universal
semantic framework prerequisites. Reuse checked helpers
from any chapter; develop shared tools when an actual current obligation needs
them. Reuse Chapter 2's checked asymptotic, finite-sum, recurrence, demand and
potential tools without rewriting existing counters or importing their model
assumptions into another representation silently.

For each chapter, reconcile the actual book passages, official extraction and
errata at the level of algorithms, variants, exercise subquestions, derivations
and stated cost claims. Reuse unchanged source reviews. For each applicable
obligation record proved, open, not applicable, or explicitly excluded from the
agreed model. Separate literal book obligations, the user's requested rational
and floating-point developments, and optional generalizations. A documented
counterexample and corrected statement can resolve a false source claim, but
must never be presented as a proof of the original statement. Chapter completion
must state its scope and any exclusions; counts of modules or theorems are not
completion criteria.

Hardware architecture is outside the current scope by the user's instruction.
Exclude instruction sequences, processor timing, pipelines, caches, compiler to
machine-code correctness, and architecture-specific performance. Disclose an
abstraction or omission where it affects a source claim; do not label an omitted
claim proved. No hardware model is required for an abstract algorithmic bound.

Use explicit mathematical cost models. State whether arithmetic and comparisons
have unit or size-dependent costs. Retain list traversal, tree paths, immutable
array copying and other representation costs when they affect the claimed
bound, including the printed array disjoint-set n^2 update contribution. Abstract
space bounds can count cells or nodes, but capacity alone is not peak live
storage. Physical bytes, garbage-collector behavior and wall-clock performance
are excluded. Full bit-complexity results are separate obligations where the
book or a selected theorem actually requires them.

## Pure Haskell semantics and useful Lean mathematics

Treat the semantics of pure Haskell as a positive mathematical development, not
as a blanket exclusion. Build small compositional models of values, partiality,
non-strictness, demand, sharing and productive infinite structures as actual book
claims require them. All Lean definitions must remain total: an explicit
undefined value in a semantic datatype is different from an admitted or partial
Lean definition. A whole-language interpreter or GHC semantics is not a global
prerequisite.

Keep the executable finite algorithms and reusable laws convenient for ordinary
Lean programming. Connect semantic models to standard Lean datatypes and existing
executors by explicit embedding, erasure or refinement theorems. Do not force
every finite-list theorem through a heavy semantic encoding. State where a law
needs definedness, strictness, continuity or an evaluation assumption. Finite
partial spines do not establish a theorem for infinite lists; keep that extension
open until a suitable model and proof exist. Distinguish denotational value laws
from sharing, demand and operation-cost claims.

Preserve both rational and Float/Float32 mathematics. Rounding, representable
ranges and exceptional values are mathematical floating semantics; excluding
processor models does not discharge their open obligations. Native implementation
correspondence and hardware exception behavior are outside scope.

## Book references

The exact textbook PDF, private text extraction, errata HTML, upstream Haskell ZIP
and all 18 extracted source files are byte-pinned in the current provenance and
inventory. Use `docs/source-references.md` and `adwh-lean/scripts/source_refs.py`
to resolve and verify them. Printed pages, PDF page indexes, extracted-file lines
and original literate LINE anchors are distinct coordinates. A verified file or
coordinate is not by itself a reviewed correspondence claim.

The current original chapter companion and item ledger summarize our contracts
and outstanding obligations; they are not a textbook transcript. Preserve the official Haskell ZIP, all extracted source files and the complete
errata under `sources/adwh/` in every checkpoint, as explicitly requested by the
user. These exact inputs are now included and their hashes match the existing
pins. Include a full user-attached book copy there when provided; until then,
record its absence explicitly rather than implying all research inputs are
self-contained. Reuse exact unchanged source reviews and read affected passages
for new correspondence claims.

## Current work and next action

The current durability snapshot uses an explicit selection of current sources
and useful evidence. Read `../RESTORE.md` and `../CHECKPOINT-POLICY.md`.
Checkpoints are not version control: do not carry forward all earlier attempts,
source/input snapshots, partial outputs or preservation manifests. Existing
historical archives remain intact. Use the new root `durability_checkpoint.py`;
`adwh-lean/scripts/checkpoint.py` delegates to it. The default archive size guard
is 32 MiB. The archive is a standalone recovery point, not a delta chain.

### What is established

The integrated library's current accepted gate is the complete Lean 4.35 run
`6e376337ca5b4b34a679cd9588e3bfc1`, completed on 24 October 2026. It checks
1,240 source modules and all 17,846 selected references under the unchanged
three-axiom policy. Its exact sources, controls, correspondence and current
coverage are retained. Packaging verifies these bindings but does not rerun Lean.

The complete packed ADD source proof establishes the original `cqueens 6 = 4`.
Its three bundles and 58 modular source inputs are in
`experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated/`.
The fresh three-bundle gate took 27.329427591 seconds; the separately bounded
actual dependency audit checked 771 required paths. Only `propext`,
`Classical.choice`, and `Quot.sound` occur. The complete concrete data is in
Lean source; the enormous external JSON and repeated copies are not needed to
recover this proof. Earlier n4/n8 certificate methods and their generators are
also retained. None establishes the n16 target.

The current lazy common-factor diagnostic saves 3,499 claims at the completed
153-variable frontier (42,402 versus 45,901), but still stops at the fixed
50,000-request cap before all 210 variables. Its n4 result and entire stopped
n8 prefix independently replay. These are external diagnostics, not a new Lean
source count. See `../next-iteration/lazy-factored-circuit/`.

The fixed cut audit reconstructs all 128 choices: 67 zero cases and 61 retained
occurrences grouped into 35 right views. Its 23,591 charged requests fully
replay. The predetermined samples have rank 35 on the left and 19 on the right;
all 19 sampled right rows are independent. This does not prove a global right
relation or a reduced exact basis. See `../next-iteration/cut-rank-review/`.

Fresh generic Lean gates establish the factor-node laws (1.791525821 seconds),
product-grouping laws (1.734835079 seconds), and signed-relation laws
(0.917771643 seconds). The last gate checks 27 new lemmas and six reused-source
axiom prints. It supplies generic Boolean splitting, integer coefficient
collection, transport and earlier-proof DAG soundness, with only the allowed
axioms. It is not a concrete guarded-descriptor checker or a discovered identity.
See `../next-iteration/signed-relation-laws/`.

### Completed exact basis and concrete proof milestone

The earlier fixed sixteen-candidate batch completed in 11,366 requests and all
sixteen roots were refuted. Its negative-result reports and regenerable source
remain. Those individual refutations did not exclude their linear combinations.

The new fixed empty-basis algorithm has now completed all 35 original B columns
in 29,360 charged requests, with no pending work. The producer took 0.867624397
seconds and independent replay accepted the complete transcript in 2.310043218
seconds. The exact rational span dimension is 31. Four global identities have
scale one and coefficients only +1 and -1:

```text
B0  + B3  = B1  + B2
B6  + B9  = B7  + B8
B11 + B14 = B12 + B13
B17 + B20 = B18 + B19
```

All 31 retained directions have source-bound triangular witnesses, and final
coverage includes every original column. No old sample values or previous
counterexamples were used as inputs. See
`../next-iteration/exact-basis-diagnostic/RESULTS.md` and `RESULTS.json` for
exact sources, coefficients, outcomes, costs and bindings. This is an accepted
external diagnostic. The four identities now also have the separate Lean
proofs described below; the rank-31 result remains external, and there is no new
queens count.

Conditional on the existing fixed-cut equality, disjoint domains and the
35 grouped A functions' independence, 31 is also the minimum rational separated
term count at this cut. Stop seeking further unconditional basis reduction here.
The available four-term reduction is only about 11.4%; it gives no running-time
or certificate-size improvement bound. Other partitions and context-dependent
relations are separate possibilities. The inspected outside-factor union has
50 variables and no demonstrated shortcut.

The selected guarded-identity milestone is complete: Lean has checked the four
fixed identities and their exact signed block rewrites. The adaptive basis
search itself has not been formalized.
Their recorded proof closure has 332 zero-proof nodes, at most four terms per
state, and one empty terminal. The 16 original B slots use 866 validated source
descriptors. The accepted work is in `../next-iteration/guarded-relation-proof/`.
Use an internally interpreted constant/ite/guard source and a sound cofactor,
normalization and earlier-proof checker. Do not treat an externally supplied
function, sampled value or Python replay result as a Lean premise. Guards may
occur after the bare core's head variable and cannot be blindly wrapped as an
ordered branch chain.

`complete-07` passed all eight freshly rebuilt generic and concrete modules in
28.019105930 seconds, with 779,936 KiB peak child RSS. All 113 required axiom
reports passed with only the three allowed axioms. The source, view and proof
tables are fully checked; the 133 local checks and 130 joins share the original
cumulative 30-second gate. No compiled experimental helpers were reused, and
all exact source/control bindings remained unchanged. The report SHA256 is
`7968f91374b02e1e052f552ab070b29b6d03c79b7b33208d8560cb9a89080314`.

The successful representation uses 8-entry literal pages instead of 32. The
16-entry checking ranges, generic mathematics, complete data, original bindings
and concrete theorem statements were preserved by independent review. The
accepted eight sources and two-stage generators are frozen for recovery. Read
`guarded-relation-proof/README.md`, `RESULTS.md` and `DEVELOPMENT.md` under
`../next-iteration/`. The concise development record preserves useful negative
outcomes and the corrected profiling interpretation; superseded attempt trees
are unnecessary in the next durability archive. Do not repeat this unchanged
gate or increase limits.

A relation Bp+Bs=Bq+Br rewrites its four weighted terms as
(Ap-As)*Bp + (Aq+As)*Bq + (Ar+As)*Br over integers. It need not give natural
coefficients; natural truncated subtraction is invalid. This avoids the
normalized rational basis vectors, but a simple binary-operation tally does
not yet show a saving. The current lazy counter has different descriptor roots
at the same frontier, so a lineage/equality bridge to its actual factor
occurrence is required before replacement. Do not launch another counter on
the strength of the rank result alone.

The paused discriminator is prepared in
`../next-iteration/projected-context-plan/DESIGN.md`. It uses the Boolean
existential support of the fixed four-cell outside factor190/root26428, retaining
ten Y wires and projecting twelve others only from an auxiliary support mask.
The original count weights and all counted variables remain. Its predetermined
necessary screen is a complete conditional dimension at most15, with every
validation/projection/basis/cache request inside one fixed50,000-request budget
and successful independent replay. This is a plan, not an executed result;
implementation requires the fixed protocol review before execution.

All selected generic and concrete mathematical sources must fit one fresh
cumulative 30-second Lean gate. A complete source-linked small counting case
remains necessary before larger-board scaling. Preserve accepted earlier
certificates and their useful generators, while retiring superseded diagnostic
transcripts from future checkpoint selection rather than carrying history.

### Fixed constraints

Continue toward `BitRepresentation.cqueens 16 = 14772512` until a breakthrough
or user interruption. No n greater than eight has been attempted.

For a new mathematical route, check all selected new generic and concrete
sources under one cumulative 30-second fresh Lean gate, one CPU/thread, and
`-j1 -M1024`. Reusing exact original ADWH imports is disclosed preparation;
compiled experimental helpers must not be reused to claim a fresh gate. Keep
only the three allowed axioms, with no `native_decide`, compiler-trust axiom,
custom axiom or kernel bypass. A new arithmetic route needs its generic
soundness and a complete bounded small source proof before scaling. Do not
raise limits, relabel incomplete work, shard unchanged enumeration, or confuse
certificate-checking time with the running time of the book's algorithm.

The shared process lock is
`experiments/chapter15-queens-model-counting/residual-dag/compile.lock`.
Keep failed mathematical outcomes in concise result notes; retain unique useful
code and essential inputs, not every transient copy in every checkpoint.
