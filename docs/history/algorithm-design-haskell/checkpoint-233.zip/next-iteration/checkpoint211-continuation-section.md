## Latest continuation — checkpoint 211

Checkpoint 211, `adwh-lean-211-beta-failure-and-ordinary-fields-reviewed.zip`, preserves the complete checkpoint 210 payload and the next substantive source/evidence work. It is a standalone recovery snapshot; no earlier ZIP is needed. The integrated library and accepted achievements are unchanged. The stock `cqueens 16 = 14772512` theorem remains open. Continue the authorized work after publishing a checkpoint.

### Actual beta experiment and recovery

The complete shared-beta selector attempt failed at 30.22363517100166 seconds and 908,292 KiB. Fresh Core and Foundation completed, with 56 accepted Foundation reports. The final selector was killed at the wall limit with empty stdout/stderr and no output files. The 90-root complete closure, including three new generic beta helpers, is unaccepted. This supplies no individual theorem timing or measured beta speedup.

The raw report, six logs, permanent marker, exact sources, reviews, controls and 19 canonical snapshot mappings are retained under `kernel-shared-beta-selector/`. Root reviewed the standalone saved-evidence reader and successfully ran live and source-only modes. Its actual receipt and independent review are included. Source key `6532e9d4739bdf260f6dfe719f51829e00d9625cd54487dfb0e5a03d5a8d7fc4` is permanently consumed.

The first metadata preflight had failed before any Lean process or marker reservation: short theorem names were compared with qualified names. Exactly three schema comparisons were corrected without changing any mathematical source, policy, source fingerprint or execution lifecycle. Eight old controls have explicit recovery mappings; six unique old metadata files are retained physically. The successful second metadata preflight and actual mathematical attempt are separate evidence. Restoration does not authorize an unchanged retry.

### Next source-cost candidate

`kernel-ordinary-fields-core/` replaces three computed-field blocks (Name.hashData, Level.hashData, Expr.data) with ordinary safe computable definitions and the same deriving handlers. All eighteen constructor equations and all other Core proof/executable bytes remain exact. Four full inverse edits are independently reviewed, including the explanatory notice. Root's review binds 71 direct inputs. No candidate compilation has occurred in this checkpoint.

The pinned Lean compiler source assessment explains the additional computed-field implementation types, constructors and overrides, while recording that ordinary recursive functions have their own compilation costs. There is no measured speed claim and no claim of identical native representation or generated private names. Ordinary recursive Expr.data could be slower during native checking. The prospective next full selector still requires all 29 origins, 90 roots and six outputs freshly in one gate. Its physical layout/gate is being prepared separately; consult current files before execution.

A proposed noncomputable pure-reference shortcut was rejected for the unchanged full checker: BasisGen actually executes pure annotateCore during #annotate_basis/#annotate_pins elaboration. The exact source obstruction is retained in `kernel-pure-reference-codegen-assessment/`. No source or gate implements that shortcut.

### Concrete checker contract and further work

`kernel-original-record-contract/` records a smaller relative integration target: produce the original typed GroupChecked result, then use an exact macro/fallback worker equality to preserve the existing installation theorem. This is a contract, not an implemented macro or completed soundness proof. Fixed-fuel success remains a real obligation.

A source trace identifies an important query shape: an auxiliary equality with `Nat.add (StructuralPrimitiveReference.evaluate ...) 0` forces the cached full-WHNF call used by the proposed seed. A direct equality on the evaluator follows a different reduction path and does not establish that outer cache lookup. The answer is computed data, never a proof premise. Actual Eq/Eq.refl typing, restricted-prefix pins, annotation and complete fixed-fuel pending checking remain to be proved.

An isolated additive higher-proof draft is being developed toward explicit pure fuel bound `29 + (41 + 17 * width) * depth` (5037 at width/depth 16). It is not frozen or included in this checkpoint, and is not a compiled theorem or cached-checker bound. A separate general first-row column-reflection assessment is in progress; its list theorem can be general in n while this book's fixed-width bridge must retain n≤16. Neither work item is accepted or measured yet.

### Exact boundary and execution policy

The latest accepted numerical workload remains checkpoint 209: 22 fresh Lean/C modules, 141 roots, 25.57449162499688 seconds total, 13.22057051298907 seconds for the n16 native call. Its canonical external ACCEPT is preserved. It is not the stock numeral theorem or an installed validating-kernel result.

Root alone runs gates, compilers, generators, native mathematics and saved-evidence auditors. Each selected complete new closure remains fresh within a cumulative 30-second, one-CPU/thread, 1-GiB gate with default resource settings and only propext, Quot.sound and Classical.choice. No upstream exemption, object reuse, budget split, unchanged retry or resource override is authorized.

Checkpoint 210's actual upload and clean restoration receipt is included. Compiler binaries, compiled objects and the full external upstream proof checkout remain reproducible separately pinned dependencies. The new retained primary-source excerpts make their particular assessments readable without that checkout. Publication is a durability action, not completion of the user's mathematical goal.
