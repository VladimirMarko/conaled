# Independent review: staged Bool selector proofs

**No mathematical or source-level blocker found in the five changed proofs.**
Root read the complete source diff, the changed proofs in context, the author
plan/inventory and the actual accepted Natrec proof pattern. This is an
independent review of validity_contracts' variant. No Bool gate, compiler,
preflight, exporter, native evaluator or counter ran.

The candidate is 40,273 bytes, SHA256
`fea919a9c0044f3d8500f97cbe896d1cace3d3e36d49b3d0376a8b14bbc0574d`.
The audit rehashes all 25 direct review inputs. It verifies the two ordered
edit layers in both directions, all 30 theorem headers, eighteen definitions,
the complete 26-field BoolPins structure, the thirteen ordered roots and
strict options. Exact inversion recovers the unchanged original Bool source.
The old source review remains historical provenance, with its original failed04
Natrec binding; it is not relabelled as a review of this variant.

## Proof changes

The three `rec_prefix` changes explicitly reduce the fixed application-spine
length goals to the natural numerals one, two and three before `decide`.
The outer spine collector does not inspect the arbitrary argument expressions.
This is the same pattern repaired in the actual, later accepted Natrec source.
There has been no Bool diagnostic; the change is preventive and source-justified.

`prepare_bool` exposes the complete non-K branch for the actual two-rule list.
The major is normalized only through its supplied actual child run. A separate
reflexive equation records that literal conversion leaves the Bool constructor
unchanged. The final two-rule constructor conversion is the same actual
operation as before. No successful whole-selector run is assumed.

`iota_bool` separates the recursor head, four arguments and major position
from the environment and constructor checks. Each Boolean case uses the
actual nullary constructor, its empty argument list and the matching rule in
the two-element list. The stored recursor/constructor forms, universe arities,
annotated recursor certificate and instantiated RHS are still required.
The staged `change` goals retain the entire remaining monadic computation.
The result has the original order: motive, false branch, true branch.

`iota_short` restores an ordinary arity rewrite after the exact stored-record
match. `cases_unfold` supplies exact head/argument equations and exposes the
whole universe-arity conditional before applying its guard. Its output is the
same four-lambda ordinary abbreviation body applied to motive, major, false
branch and true branch. The proof does not use a partially simplified decision
instance as an assumed guard.

All fourteen explicit default-transparency rewrites are removed. This is an
elaboration strategy, not a measured speedup or a diagnosis of a previously
silent Bool build. No other theorem body, definition, pin, fuel requirement,
import, option or print is changed by the exact inverse map.

## Unchanged operational and execution boundary

The original selector contracts, closed-substitution conditions and separate
knot/local-loop thresholds remain intact. The ordinary wrapper spends one
local iteration; scalar/binary contracts keep their original local bounds.
The result of a child full-WHNF invocation is not reused at a smaller local
budget. Installed annotations and semantic environment validity remain
obligations, distinct from the raw export's source-shape evidence.

The inventory's nine physical modules, 29 mathematical origins, 75 roots and
22 default outputs describe the proposed accepted-Natrec dependency scope.
All eight dependency source rows match the actual bundled complete-02 report.
That historical acceptance does not authorize object reuse or prove that the
larger closure fits the cumulative limit. A new physical layout or Natrec
proof variant requires its own explicit source mapping and review; this audit
must not silently become a review of those future choices.

The unchanged ordinary gate policy applies to the complete selected closure:
30 seconds cumulative, one CPU/thread, 1 GiB, default heartbeat/recursion/output
settings, strict warnings and the three permitted axioms. This source review
does not claim all possible Bool elaboration errors are resolved, whole-fold
normalization, installed guard discharge, an optimized validating kernel or
the stock `cqueens 16` numeral theorem.
